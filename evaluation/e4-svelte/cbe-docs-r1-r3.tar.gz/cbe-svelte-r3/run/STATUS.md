# CBE run status

Run `659c89` · status **complete** · updated 2026-10-17T19:28:17Z · review sample · jobs 2 · host api

Semantic review: mode **sample**; 1/1 reviewed by a separate reader of the source. This is independent of the deterministic structure/coverage checks and does not prove whole-map truth.

Counts: done 75

id_corrected 3

- module_52: ` packages/svelte/src/internal/client/dom/elements/bindings/universal.js::function::bind_focused::71 ` → ` packages/svelte/src/internal/client/dom/elements/bindings/universal.js::function::bind_focused::1521 ` (units[35].id)
- module_52: ` packages/svelte/src/internal/client/dom/elements/bindings/universal.js::function::bind_focused::71 ` → ` packages/svelte/src/internal/client/dom/elements/bindings/universal.js::function::bind_focused::1521 ` (dispositions[packages/svelte/src/internal/client/dom/elements/bindings/universal.js::function::bind_focused::71].unit)
- module_52: ` packages/svelte/src/internal/client/dom/elements/bindings/universal.js::function::bind_focused::71 ` → ` packages/svelte/src/internal/client/dom/elements/bindings/universal.js::function::bind_focused::1521 ` (dispositions[packages/svelte/src/internal/client/dom/elements/bindings/universal.js::function::bind_focused::71] key)

index_only_filled 0


| Task | Module | State | Attempts | Seconds | Output | Note |
|---|---|---|---:|---:|---|---|
| names |  | done | 2 | 14.0 | host/accepted/names.json |  |
| module_1 | Benchmark run orchestration and utilities | done | 3 | 41.0 | host/accepted/module_1.json |  |
| module_2 | Reactivity and SSR benchmark suites (Kairo, Mol, Sbench, wrapper) | done | 1 | 136.0 | host/accepted/module_2.json |  |
| module_3 | Benchmark comparison runner | done | 2 | 15.0 | host/accepted/module_3.json |  |
| module_4 | ESLint configuration | done | 1 | 23.0 | host/accepted/module_4.json |  |
| module_5 | Svelte sandbox playground with SSR and setup scripts | done | 2 | 38.0 | host/accepted/module_5.json |  |
| module_6 | DOM element and attribute type definitions | done | 2 | 110.0 | host/accepted/module_6.json |  |
| module_7 | Rollup build config and HTML typing entry | done | 1 | 33.0 | host/accepted/module_7.json |  |
| module_8 | Build and type-generation maintenance scripts | done | 2 | 127.0 | host/accepted/module_8.json |  |
| module_9 | Core constants, escaping, and shared utilities | done | 2 | 165.0 | host/accepted/module_9.json |  |
| module_10 | Client/server public entry points and HTML tree validation | done | 1 | 74.0 | host/accepted/module_10.json |  |
| module_11 | Compiler error message definitions | done | 1 | 153.0 | host/accepted/module_11.json |  |
| module_12 | Compiler type surface and warning definitions | done | 5 | 127.0 | host/accepted/module_12.json |  |
| module_13 | Compiler entry with options validation and legacy API | done | 3 | 131.0 | host/accepted/module_13.json |  |
| module_14 | Svelte 4 to 5 migration codemod | done | 1 | 247.0 | host/accepted/module_14.json |  |
| module_15 | AST node definitions and scope tracking | done | 2 | 164.0 | host/accepted/module_15.json |  |
| module_16 | Svelte template parser core with TypeScript stripping | done | 2 | 103.0 | host/accepted/module_16.json |  |
| module_17 | Parsers for expressions, script, style, and options | done | 1 | 128.0 | host/accepted/module_17.json |  |
| module_18 | Parser states for elements, fragments, and text | done | 1 | 71.0 | host/accepted/module_18.json |  |
| module_19 | Parser state for tags | done | 2 | 47.0 | host/accepted/module_19.json |  |
| module_20 | HTML entity decoding table | done | 2 | 15.0 | host/accepted/module_20.json |  |
| module_21 | Parser helpers: brackets, node creation, fuzzy matching, HTML metadata | done | 2 | 115.0 | host/accepted/module_21.json |  |
| module_22 | Analysis phase driver and types | done | 1 | 84.0 | host/accepted/module_22.json |  |
| module_23 | CSS pruning analysis and utilities | done | 2 | 143.0 | host/accepted/module_23.json |  |
| module_24 | Analyze-phase visitors for attributes, bindings, events, and snippets | done | 1 | 106.0 | host/accepted/module_24.json |  |
| module_25 | Analyze-phase visitors for blocks, expressions, and statements | done | 1 | 148.0 | host/accepted/module_25.json |  |
| module_26 | Shared analyze-phase visitor helpers | done | 1 | 129.0 | host/accepted/module_26.json |  |
| module_27 | Accessibility warning checks | done | 2 | 84.0 | host/accepted/module_27.json |  |
| module_28 | Analyze-phase visitors for components, CSS, and remaining nodes | done | 2 | 137.0 | host/accepted/module_28.json |  |
| module_29 | Transform phase driver, types, and utilities | done | 1 | 79.0 | host/accepted/module_29.json |  |
| module_30 | Client-side code generation core | done | 1 | 101.0 | host/accepted/module_30.json |  |
| module_31 | Client transform visitors for events, elements, and boundaries | done | 3 | 89.0 | host/accepted/module_31.json |  |
| module_32 | Client transform visitors for bindings and blocks | done | 1 | 109.0 | host/accepted/module_32.json |  |
| module_33 | Client transform visitors for awaits, snippets, and control flow | done | 1 | 133.0 | host/accepted/module_33.json |  |
| module_34 | Shared client transform visitor helpers | done | 2 | 138.0 | host/accepted/module_34.json |  |
| module_35 | Client template generation and remaining element/component visitors | done | 2 | 168.0 | host/accepted/module_35.json |  |
| module_36 | Server-side code generation visitors | done | 1 | 144.0 | host/accepted/module_36.json |  |
| module_37 | Shared server transform visitor helpers | done | 2 | 77.0 | host/accepted/module_37.json |  |
| module_38 | Server transform core with CSS and assignment handling | done | 2 | 92.0 | host/accepted/module_38.json |  |
| module_39 | Preprocessing pipeline with sourcemap decoding | done | 2 | 95.0 | host/accepted/module_39.json |  |
| module_40 | Compiler type declarations (AST, CSS, template, legacy) | done | 2 | 160.0 | host/accepted/module_40.json |  |
| module_41 | Compiler AST utilities, builders, and diagnostics | done | 2 | 191.0 | host/accepted/module_41.json |  |
| module_42 | Small compiler utility helpers | done | 3 | 102.0 | host/accepted/module_42.json |  |
| module_43 | Client runtime core with error messages | done | 1 | 129.0 | host/accepted/module_43.json |  |
| module_44 | Client rendering entry, proxies, and warnings | done | 1 | 97.0 | host/accepted/module_44.json |  |
| module_45 | Client context, scheduling, and legacy support | done | 2 | 119.0 | host/accepted/module_45.json |  |
| module_46 | Development-mode checks, HMR, and tracing | done | 1 | 150.0 | host/accepted/module_46.json |  |
| module_47 | DOM operations: hydration, templates, and reconciliation | done | 1 | 144.0 | host/accepted/module_47.json |  |
| module_48 | Client block implementations for await, boundary, each, if | done | 3 | 110.0 | host/accepted/module_48.json | normalized (17) |
| module_49 | Client block implementations for snippets, slots, and special elements | done | 1 | 98.0 | host/accepted/module_49.json |  |
| module_50 | Client element handling for attributes, styles, and transitions | done | 3 | 142.0 | host/accepted/module_50.json | normalized (50) |
| module_51 | Client element handling for actions, attachments, events, custom elements | done | 2 | 107.0 | host/accepted/module_51.json |  |
| module_52 | Client element bindings (inputs, media, size, window) | done | 3 | 161.0 | host/accepted/module_52.json | normalized (36); id_corrected 3 |
| module_53 | Client reactivity: async, batching, effects | done | 3 | 186.0 | host/accepted/module_53.json | normalized (104) |
| module_54 | Client reactivity: deriveds, props, sources, stores | done | 1 | 217.0 | host/accepted/module_54.json |  |
| module_55 | Server-side rendering core and context | done | 1 | 166.0 | host/accepted/module_55.json |  |
| module_56 | Shared internal utilities and validation | done | 2 | 103.0 | host/accepted/module_56.json |  |
| module_57 | Motion primitives: spring and tweened animations | done | 2 | 98.0 | host/accepted/module_57.json |  |
| module_58 | Reactive built-ins: Map, Set, media queries, URL | done | 4 | 113.0 | host/accepted/module_58.json |  |
| module_59 | Reactive value base and reactive wrapper classes with tests | done | 2 | 65.0 | host/accepted/module_59.json |  |
| module_60 | Miscellaneous core: easing, transitions, stores, legacy bindings | done | 1 | 186.0 | host/accepted/module_60.json |  |
| module_61 | Public API surfaces for actions, animate, attachments, stores, transitions | done | 1 | 192.0 | host/accepted/module_61.json |  |
| module_62 | Public package type entry | done | 2 | 435.0 | host/accepted/module_62.json |  |
| module_63 | Server rendering entry with flags and shared helpers | done | 2 | 40.0 | host/accepted/module_63.json |  |
| module_64 | Svelte configuration file | done | 1 | 8.0 | host/accepted/module_64.json |  |
| module_65 | Vitest test configuration | done | 1 | 16.0 | host/accepted/module_65.json |  |
| repair_62 | Public package type entry | done | 3 | 270.0 | host/accepted/repair_62.json |  |
| tree |  | done | 2 | 65.0 | host/accepted/tree.json |  |
| tree_region-0001 |  | done | 2 | 191.0 | host/accepted/tree_region-0001.json |  |
| tree_region-0002 |  | done | 2 | 149.0 | host/accepted/tree_region-0002.json | normalized (1) |
| tree_region-0003 |  | done | 2 | 201.0 | host/accepted/tree_region-0003.json | normalized (1) |
| tree_region-0004 |  | done | 2 | 134.0 | host/accepted/tree_region-0004.json |  |
| tree_region-0005 |  | done | 1 | 189.0 | host/accepted/tree_region-0005.json |  |
| review_62 | Public package type entry | done | 1 | 58.0 | host/accepted/review_62.json |  |
| system |  | done | 3 | 57.0 | host/accepted/system.json |  |
