# Effect System

**Capability.** Core client effect lifecycle: a single factory wires effect objects into the reactive graph, specialized constructors (root, branch, block, render, template, user, inspect, async, legacy) select flags and scheduling, and destroy/pause/resume machinery tears down or suspends subtrees including out transitions and DOM removal.

Start at create_effect for graph wiring, then the per-flavor constructors for scheduling semantics, then destroy/pause/resume for teardown and transition-aware outro. validate_effect enforces rune placement invariants at runtime; DOM blocks and bindings throughout the runtime build on these constructors.

**Depends on.**

- [Runtime Dev-Mode Instrumentation](r4-runtime-dev.md) · model-inferred · 0 edge(s)
- [Reactivity Core & Batching](r2-reactivity-core.md) · graph-only · 17 edge(s)

**Depended on by.**

- [Runtime DOM Blocks](r4-runtime-dom-blocks.md) · graph-confirmed · 11 edge(s)
- [Element Bindings and Behaviors](r4-runtime-element-bindings.md) · graph-confirmed · 7 edge(s)
- [Signals, Deriveds, and Proxies](r4-runtime-signals.md) · graph-confirmed · 2 edge(s)
- [DOM Template Blocks](r1-dom-blocks.md) · graph-only · 20 edge(s)
- [Error & Pending Boundaries](r5-client-boundary.md) · graph-only · 13 edge(s)
- [Each Block Runtime](r2-dom-blocks.md) · graph-only · 11 edge(s)
- [Client Control Blocks and CSS](r3-client-blocks.md) · graph-only · 9 edge(s)
- [Element Bindings](r5-client-bindings.md) · graph-only · 9 edge(s)

Parent: [Svelte Compiler and Runtime](r4-svelte-monorepo.md)

## Units (33)

<a id="u-e76707ac36a4"></a>
### `effects-js-module-regions`

`group` · [packages/svelte/src/internal/client/reactivity/effects.js:L1-L49][f1]

Non-behavioral regions of effects.js: import headers and inter-symbol gaps containing only type annotations and blank lines.

<a id="u-028f962a5fe6"></a>
### `aborted`

`export function aborted(effect = /** @type {Effect} */ (active_effect))` · [packages/svelte/src/internal/client/reactivity/effects.js:L662-L664][f1]

Returns true when the given effect (defaulting to the active effect) has the DESTROYED flag, i.e. its owner was torn down while async work was in flight.

<a id="u-82596e20cef8"></a>
### `async_effect`

`export function async_effect(fn)` · [packages/svelte/src/internal/client/reactivity/effects.js:L349-L351][f1]

Creates an ASYNC | EFFECT_PRESERVED effect that runs synchronously on creation; used by `async_derived` for async effect bodies.

<a id="u-75d755e7c63c"></a>
### `packages/svelte/src/internal/client/reactivity/effects.js:block`

`export function block(fn, flags = 0)` · [packages/svelte/src/internal/client/reactivity/effects.js:L376-L382][f1]

Creates a synchronously-run BLOCK_EFFECT with optional extra flags; in DEV records the current `dev_stack` on the effect for debugging.

<a id="u-cfe4a1f5ddba"></a>
### `branch`

`export function branch(fn, push = true)` · [packages/svelte/src/internal/client/reactivity/effects.js:L388-L390][f1]

Creates a BRANCH_EFFECT | EFFECT_PRESERVED effect run synchronously, with `push` controllable so callers can create branches outside the tree.

<a id="u-42e380f9794b"></a>
### `component_root`

`export function component_root(fn)` · [packages/svelte/src/internal/client/reactivity/effects.js:L268-L285][f1]

Creates a component's root effect like `effect_root` (batch ensured, ROOT_EFFECT | EFFECT_PRESERVED run synchronously) and returns a teardown function returning a Promise.

With `outro: true` it first pauses the effect (playing out transitions) then destroys and fulfils; otherwise it destroys immediately and fulfils.

calls: [pause_effect](r4-runtime-effects.md#u-340d218bcd6f), [destroy_effect](r4-runtime-effects.md#u-214ad59ce57a)

<a id="u-b219b5c574b1"></a>
### `create_effect`

`function create_effect(type, fn, sync, push = true)` · [packages/svelte/src/internal/client/reactivity/effects.js:L86-L174][f1]

Core effect factory that builds the effect object (context, flags `type | DIRTY`, null tree links, parent pointer, inherited `b` boundary) and wires it into the graph.

In DEV the parent chain skips inspect effects, and `component_function` is recorded. If the parent is INERT the new effect inherits INERT. Behavior branches on `sync`: when true it runs `update_effect` immediately and marks EFFECT_RAN, destroying the effect on throw before rethrowing; when false with non-null `fn` it schedules the effect instead. When `push` is true it attaches the effect (or, for a sync effect that already ran, is dependency-free, has no teardown/DOM, and has exactly one child and is not EFFECT_PRESERVED, its single child) to the parent's child list, and additionally registers it on the active DERIVED reaction's `effects` list when the type is not a ROOT_EFFECT.

calls: [update_effect](r2-reactivity-core.md#u-e2ea8c85735e), [schedule_effect](r2-reactivity-core.md#u-ce4f8d895426), [destroy_effect](r4-runtime-effects.md#u-214ad59ce57a)

**Uncertainties.**

- The child-substitution heuristic (`first === e.last`) assumes at most one surviving child; behavior when the child list changes during the sync run is not provable here.

<a id="u-034bebae7dc6"></a>
### `create_user_effect`

`export function create_user_effect(fn)` · [packages/svelte/src/internal/client/reactivity/effects.js:L225-L227][f1]

Creates an immediate user effect with EFFECT | USER_EFFECT flags, not synced (scheduled rather than run inline).

<a id="u-9c9ddd7647fa"></a>
### `destroy_block_effect_children`

`export function destroy_block_effect_children(signal)` · [packages/svelte/src/internal/client/reactivity/effects.js:L446-L456][f1]

Destroys the non-branch children of a block effect, skipping BRANCH_EFFECT children (which are managed by block logic) and iterating via captured `next` pointers since destruction mutates links.

<a id="u-214ad59ce57a"></a>
### `destroy_effect`

`export function destroy_effect(effect, remove_dom = true)` · [packages/svelte/src/internal/client/reactivity/effects.js:L463-L512][f1]

Fully destroys an effect.

DOM removal happens when `remove_dom` is true or the effect is a HEAD_EFFECT and both node pointers exist, walking nodes via `remove_effect_dom` (tracked so descendants skip redundant DOM removal). It then recursively destroys children, removes reactions, and marks the effect DESTROYED. Active transitions are stopped, the teardown executes (with destroying-state flags set), and the effect is unlinked from its parent only if the parent still has other children. In DEV `component_function` is cleared. Finally all links, teardown, context, deps, fn, node pointers, and abort controller are nulled; `parent` is deliberately kept for error propagation.

calls: [remove_reactions](r2-reactivity-core.md#u-b457a655a682), [execute_effect_teardown](r4-runtime-effects.md#u-e4bc784214d0), [unlink_effect](r4-runtime-effects.md#u-519e1d7b7b2b)

<a id="u-8ac46761ce64"></a>
### `destroy_effect_children`

`export function destroy_effect_children(signal, remove_dom = false)` · [packages/svelte/src/internal/client/reactivity/effects.js:L416-L440][f1]

Destroys all children of an effect, first detaching the child list (`first`/`last` nulled).

For each child: any abort controller is aborted with STALE_REACTION inside `without_reactive_context`; ROOT_EFFECT children are simply unparented (now independent roots), all others are destroyed (passing `remove_dom` only when DOM was not already removed at this level). Iteration uses `next` captured before destruction.

calls: [destroy_effect](r4-runtime-effects.md#u-214ad59ce57a)

<a id="u-68382c2a31f5"></a>
### `effect`

`export function effect(fn)` · [packages/svelte/src/internal/client/reactivity/effects.js:L291-L293][f1]

Creates a plain EFFECT (scheduled, not run synchronously); the non-user-flavored internal effect variant.

<a id="u-188599523a26"></a>
### `effect_root`

`export function effect_root(fn)` · [packages/svelte/src/internal/client/reactivity/effects.js:L254-L261][f1]

Implements `$effect.root(...)`: ensures a batch exists, creates a synchronously-run ROOT_EFFECT | EFFECT_PRESERVED, and returns a cleanup closure that destroys it.

<a id="u-c4dc07dc96fc"></a>
### `effect_tracking`

`export function effect_tracking()` · [packages/svelte/src/internal/client/reactivity/effects.js:L180-L182][f1]

Implements `$effect.tracking()`: true when there is an active reaction and `untracking` is false; false otherwise.

<a id="u-e4bc784214d0"></a>
### `execute_effect_teardown`

`export function execute_effect_teardown(effect)` · [packages/svelte/src/internal/client/reactivity/effects.js:L395-L409][f1]

Runs an effect's teardown function if present, with `is_destroying_effect` set true and `active_reaction` cleared for the duration, restoring both afterwards even if the teardown throws (via `finally`).

<a id="u-b327f388eca5"></a>
### `inspect_effect`

`export function inspect_effect(fn)` · [packages/svelte/src/internal/client/reactivity/effects.js:L245-L247][f1]

Creates an INSPECT_EFFECT that runs synchronously; used for `$inspect` so it fires without affecting normal effect semantics.

<a id="u-d9a59d025a48"></a>
### `legacy_pre_effect`

`export function legacy_pre_effect(deps, fn)` · [packages/svelte/src/internal/client/reactivity/effects.js:L300-L318][f1]

Implements `$: statement` pre-effects in legacy mode.

It registers a token (`effect`, `ran` flag, `deps`) in the legacy component context, then creates a render effect that first evaluates `deps` (registering dependencies), and unless the reset effect already ran this token (`token.ran` true, bailing to emulate ordering), sets `ran` and runs `fn` untracked.

contract: [legacy_pre_effect_reset](r4-runtime-effects.md#u-b86eec9e6793)

**Uncertainties.**

- The precise interleaving guarantee between the token's render effect and the reset effect relies on scheduling order established elsewhere.

<a id="u-b86eec9e6793"></a>
### `legacy_pre_effect_reset`

`export function legacy_pre_effect_reset()` · [packages/svelte/src/internal/client/reactivity/effects.js:L320-L343][f1]

Creates a render effect that re-runs dirty `$:` statements: for each legacy token it evaluates `deps`, promotes a CLEAN effect to MAYBE_DIRTY so dependency traversal happens, runs it via `update_effect` only if dirty, and resets `token.ran` to false so the token's own effect can run again on the next cycle.

calls: [update_effect](r2-reactivity-core.md#u-e2ea8c85735e)

<a id="u-2f3c3d6372e6"></a>
### `pause_children`

`export function pause_children(effect, transitions, local)` · [packages/svelte/src/internal/client/reactivity/effects.js:L590-L613][f1]

Recursively marks an effect subtree INERT and gathers transitions for outro.

Returns immediately for already-inert effects. Transitions are collected when `is_global` or when `local` holds; `local` propagates into children that are EFFECT_TRANSPARENT or branches, otherwise resets to false for deeper children.

<a id="u-340d218bcd6f"></a>
### `pause_effect`

`export function pause_effect(effect, callback)` · [packages/svelte/src/internal/client/reactivity/effects.js:L557-L567][f1]

Implements delayed destruction for block effects with transitions: it collects the subtree's transitions via `pause_children`, then runs their out transitions; once all complete (or none exist) the effect is destroyed and the optional callback fires.

While paused the effect stays in memory and DOM but does not update.

calls: [pause_children](r4-runtime-effects.md#u-2f3c3d6372e6), [run_out_transitions](r4-runtime-effects.md#u-a51d37cf57ad)

<a id="u-34956c8e3e11"></a>
### `push_effect`

`function push_effect(effect, parent_effect)` · [packages/svelte/src/internal/client/reactivity/effects.js:L68-L77][f1]

Appends an effect to the end of its parent's doubly linked child list, setting both `first` and `last` when the parent had no children, otherwise linking after the current `last`.

<a id="u-92a1603726c9"></a>
### `remove_effect_dom`

`export function remove_effect_dom(node, end)` · [packages/svelte/src/internal/client/reactivity/effects.js:L519-L527][f1]

Removes DOM nodes from `node` up to (and including) `end`: each iteration removes the current node and advances via `get_next_sibling`, stopping when the end node was reached (next becomes null).

<a id="u-bbe822faa096"></a>
### `render_effect`

`export function render_effect(fn, flags = 0)` · [packages/svelte/src/internal/client/reactivity/effects.js:L357-L359][f1]

Creates a RENDER_EFFECT (plus optional extra flags) that runs synchronously on creation; the workhorse for internal template/binding effects.

<a id="u-f5814c70931b"></a>
### `resume_children`

`function resume_children(effect, local)` · [packages/svelte/src/internal/client/reactivity/effects.js:L628-L660][f1]

Recursively un-flags INERT over a paused subtree (returning early if not inert).

If the effect is not CLEAN — a dependency changed while paused — it is marked DIRTY and scheduled, deliberately without using `is_dirty` to avoid eagerly recomputing deriveds. `local` propagates into EFFECT_TRANSPARENT/branch children as in `pause_children`. Finally each transition that is global or covered by `local` has `in()` invoked for the intro.

calls: [schedule_effect](r2-reactivity-core.md#u-ce4f8d895426)

<a id="u-199bf40112ce"></a>
### `resume_effect`

`export function resume_effect(effect)` · [packages/svelte/src/internal/client/reactivity/effects.js:L620-L622][f1]

Resumes a previously paused effect by resuming its children starting with `local` true; the inverse of `pause_effect` for cases like an `{#if}` toggling back to truthy.

<a id="u-a51d37cf57ad"></a>
### `run_out_transitions`

`export function run_out_transitions(transitions, fn)` · [packages/svelte/src/internal/client/reactivity/effects.js:L573-L576][f1]

Runs each transition's `out` with a shared countdown `check`; when all out transitions finish (`remaining` hits zero) or the list is empty, invokes `fn` exactly once.

<a id="u-7bb0885eb235"></a>
### `check`

`var check = () =>` · [packages/svelte/src/internal/client/reactivity/effects.js:L576-L576][f1]

Decrementing countdown closure: decrements `remaining` and calls the completion `fn` only when it reaches zero.

<a id="u-afcffe6190df"></a>
### `teardown`

`export function teardown(fn)` · [packages/svelte/src/internal/client/reactivity/effects.js:L187-L192][f1]

Creates a non-sync RENDER_EFFECT with no function, marks it CLEAN, and stores `fn` as its teardown, so the function runs when the effect is destroyed.

<a id="u-5f7f1fcbe917"></a>
### `template_effect`

`export function template_effect(fn, sync = [], async = [])` · [packages/svelte/src/internal/client/reactivity/effects.js:L366-L370][f1]

Implements compiled template effects with async support.

It hands the sync and async expression getters to `flatten`, and in the resulting callback creates a synchronously-run RENDER_EFFECT whose function spreads the resolved values (each passed through `get`) into the compiled update function `fn`.

calls: [flatten](r1-async-reactivity.md#u-c50793421b66)

<a id="u-519e1d7b7b2b"></a>
### `unlink_effect`

`export function unlink_effect(effect)` · [packages/svelte/src/internal/client/reactivity/effects.js:L534-L546][f1]

Detaches an effect from the doubly linked effect tree: splices `prev`/`next` neighbors together and fixes the parent's `first`/`last` pointers when they pointed at this effect.

Frees traversal work without destroying.

<a id="u-2ecd21794ced"></a>
### `user_effect`

`export function user_effect(fn)` · [packages/svelte/src/internal/client/reactivity/effects.js:L198-L220][f1]

Implements `$effect(...)`.

Validates placement and, in DEV, renames `fn` to `$effect`. If there is no active reaction and the active effect is a branch effect that has not yet run (top-level `$effect` in an unmounted component), the function is deferred by pushing it onto the component context's effect list instead of creating an effect; otherwise it creates the effect immediately.

calls: [create_user_effect](r4-runtime-effects.md#u-034bebae7dc6)

<a id="u-53bf5464d746"></a>
### `user_pre_effect`

`export function user_pre_effect(fn)` · [packages/svelte/src/internal/client/reactivity/effects.js:L234-L242][f1]

Implements `$effect.pre(...)`: validates placement, renames `fn` in DEV, and creates a RENDER_EFFECT | USER_EFFECT that runs synchronously on creation.

<a id="u-4f3a8befe7fd"></a>
### `validate_effect`

`export function validate_effect(rune)` · [packages/svelte/src/internal/client/reactivity/effects.js:L50-L62][f1]

Enforces compile-time-like invariants for rune-created effects at runtime: throws `effect_orphan` when neither active effect nor reaction exists, `effect_in_unowned_derived` when the active reaction is UNOWNED with no active effect, and `effect_in_teardown` when called while an effect teardown is in progress.

The rune name is passed to the error for messaging.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/reactivity/effects.js
