# Server Runtime

**Capability.** Renders compiled components to HTML strings on the server: the render entry, element/markup serialization, templating constructs (slots, each/await, legacy reactive statements), store helpers, hydration comment markers, and dev-time validation.

server-render-entry is the API surface (render/head); server-markup and server-templating hold the $.-style helpers the server transform emits calls to; server-stores and server-dev round out store and validation behavior.

**Children.**

- [Server Render Entry](r3-server-render-entry.md) `r3-server-render-entry` · 11 unit(s)
- [Server Dev Validation](r3-server-dev.md) `r3-server-dev` · 8 unit(s)
- [Server Markup Serialization](r3-server-markup.md) `r3-server-markup` · 16 unit(s)
- [Server Templating Helpers](r3-server-templating.md) `r3-server-templating` · 22 unit(s)
- [Server Store Helpers](r3-server-stores.md) `r3-server-stores` · 12 unit(s)

**Depended on by.**

- [Server Transform Phase](r3-server-transform.md) · model-inferred · 0 edge(s)

Parent: [Runtime](r3-runtime.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
