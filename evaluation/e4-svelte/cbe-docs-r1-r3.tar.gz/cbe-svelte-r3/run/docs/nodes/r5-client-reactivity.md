# Signal Reactivity Core

**Capability.** Source signal creation and writes: source/state/mutable_source factories, the set/internal_set write path with equality-driven propagation (mark_reactions, flush_inspect_effects), equality strategies, and the reactive SvelteSet collection built on those writes.

Use when changing how writes propagate to effects and deriveds. internal_set is the core primitive; set() validates and delegates; SvelteSet registers dependencies on reads and funnels mutations through source set/state.

**Depends on.**

- [Shared Runtime Infrastructure](r5-runtime-shared.md) · model-inferred · 0 edge(s)
- [Reactivity Core & Batching](r2-reactivity-core.md) · graph-only · 22 edge(s)

**Depended on by.**

- [Reactivity Benchmarks](r5-benchmarks.md) · model-inferred · 0 edge(s)
- [Error & Pending Boundaries](r5-client-boundary.md) · graph-confirmed · 2 edge(s)
- [DOM Operations & Elements](r5-client-dom.md) · graph-confirmed · 1 edge(s)
- [Spring Motion](r5-client-motion.md) · graph-confirmed · 7 edge(s)
- [Server Runtime](r5-runtime-server.md) · model-inferred · 0 edge(s)
- [Shared Runtime Infrastructure](r5-runtime-shared.md) · graph-confirmed · 1 edge(s)
- [Reactive Wrapper Classes](r1-reactive-collections.md) · graph-only · 37 edge(s)
- [Signals, Deriveds, and Proxies](r4-runtime-signals.md) · graph-only · 18 edge(s)
- [Reactive Primitives](r2-reactive-primitives.md) · graph-only · 12 edge(s)

Parent: [Client Runtime](r5-runtime-client.md)

## Units (16)

<a id="u-3d5a1739f21d"></a>
### `set-js-svelteset`

`class SvelteSet extends Set` · [packages/svelte/src/reactivity/set.js:L47-L57][f1]

Reactive Set subclass: reading contents (has/iteration/size/read methods) registers dependencies so effects and deriveds re-run on mutation; values are not deeply reactive.

It keeps a per-element Map of boolean sources, a version source, and a size source; #update_version snapshots update_version so #source picks state (same-reaction creation, non-dependency) versus source. has: if a source exists it reads it; if the element is absent it reads the version (so a later add re-runs the reader) and returns false without creating a source; if newly present it creates and caches a source (initial value true) and reads it. add only mutates and bumps version when super.has is false; delete and clear reset affected sources to false, resync #size, and bump version; clear is a no-op on an empty set and clears the backing set first so $inspect output looks clean. values/entries/keys (keys delegates to values) and the prototype-level read methods installed once by #init track the version then delegate to Set.prototype; set-like methods (difference, intersection, symmetricDifference, union) return a new SvelteSet. size returns get(#size). The constructor copies the iterable through the native Set in DEV (invalid input throws the native exception), seeds #size, and runs #init on first instance so the class can be tree-shaken when unused.

**Uncertainties.**

- #init mutates SvelteSet.prototype once, module-wide via the `inited` flag; semantics of get/increment/set in sources.js/runtime.js are inferred, not visible
- Unlike SvelteMap, iteration here tracks only the version, not per-element sources; element-level invalidation therefore depends on version bumps on add/delete/clear

<a id="u-cecd1288571c"></a>
### `sources.js-update-helpers`

`export function update(source, d = 1)` · [packages/svelte/src/internal/client/reactivity/sources.js:L271-L279][f2]

Numeric convenience writes over sources.

update reads the current value with get, writes value incremented or decremented by d (default 1 / -1 for d=other), and returns the pre-write value. update_pre writes the already-adjusted value and returns it. increment is a silent shortcut — it reads source.v directly without get — and sets source to v + 1; it is used where a tracked read is undesirable, such as proxy bookkeeping.

calls: [packages/svelte/src/internal/client/runtime.js:get](r2-reactivity-core.md#u-98099fbbf12a), [packages/svelte/src/internal/client/reactivity/sources.js:set](r5-client-reactivity.md#u-452914169f68)

**Uncertainties.**

- update on a non-numeric value yields NaN through ++/--; no type guard is present.

<a id="u-57d9601c89ba"></a>
### `sources.js-inspect-effects-state`

`export function set_inspect_effects(v)` · [packages/svelte/src/internal/client/reactivity/sources.js:L49-L51][f2]

Module-level toggles for inspect-effect flushing.

set_inspect_effects replaces the exported inspect_effects set wholesale (used by execute_derived to isolate effects created inside a derived evaluation). set_inspect_effects_deferred flips a private flag that internal_set consults to postpone flush_inspect_effects; the flag itself is reset by flush_inspect_effects.

<a id="u-d069e3e7a0b4"></a>
### `packages/svelte/src/internal/client/reactivity/equality.js:equals`

`export function equals(value)` · [packages/svelte/src/internal/client/reactivity/equality.js:L4-L6][f3]

Strict equality against this.v, the value stored on the calling context object; used as an Equals strategy where `this` is a reactive signal or similar holder.

Returns true only when value and this.v are identical.

**Notes.**

- contract: Typed as Equals, so callers must invoke it with the owning signal as `this`.

**Uncertainties.**

- Depends on `this` being an object with a `v` property; behavior when called unbound is not visible in this file.

<a id="u-80bb0808e8b1"></a>
### `not_equal`

`export function not_equal(a, b)` · [packages/svelte/src/internal/client/reactivity/equality.js:L24-L26][f3]

Plain strict inequality (a !== b); the reference-based comparison used when NaN and object-identity heuristics are not wanted.

<a id="u-371c4a3b72d6"></a>
### `safe_equals`

`export function safe_equals(value)` · [packages/svelte/src/internal/client/reactivity/equality.js:L29-L31][f3]

Complement of safe_not_equal bound to context: returns !safe_not_equal(value, this.v), i.e. true when the value is 'safe equal' to the stored value.

Used as an Equals strategy where `this` supplies the prior value.

calls: [safe_not_equal](r5-client-reactivity.md#u-3775acbc409e)

**Uncertainties.**

- Requires a bound `this` with a `v` property, mirroring equals; unbound call behavior is not visible here.

<a id="u-3775acbc409e"></a>
### `safe_not_equal`

`export function safe_not_equal(a, b)` · [packages/svelte/src/internal/client/reactivity/equality.js:L13-L17][f3]

Decides whether a new value should propagate.

If a is NaN (a != a), it returns true only when b is also NaN, else false. Otherwise it returns true when the values differ strictly, or when a is a non-null object or function — so any object or function replacement always counts as 'not equal' even if structurally identical, while identical primitives and NaN-vs-NaN comparisons suppress updates.

<a id="u-8313e354c312"></a>
### `flush_inspect_effects`

`export function flush_inspect_effects()` · [packages/svelte/src/internal/client/reactivity/sources.js:L245-L263][f2]

Runs pending inspect effects immediately.

It clears the deferred flag, snapshots inspect_effects, and for each effect: if it is CLEAN it is demoted to MAYBE_DIRTY rather than force-updated, then only effects for which is_dirty reports true are updated via update_effect; finally the set is cleared. This avoids overfiring clean inspect effects while guaranteeing dirty ones run now.

calls: [is_dirty](r2-reactivity-core.md#u-6236bf4a1a35), [runtime-js-state-and-helpers](r2-reactivity-core.md#u-6cd2387802ec), [update_effect](r2-reactivity-core.md#u-e2ea8c85735e)

<a id="u-0dae6a8d64cd"></a>
### `internal_set`

`export function internal_set(source, value)` · [packages/svelte/src/internal/client/reactivity/sources.js:L171-L243][f2]

Core write primitive; a no-op pass-through (returns value) when equals says the value is unchanged.

On change: it records the old value in old_values — or the new value when a destroying effect is running — then assigns source.v, ensures a Batch exists and captures the (source, old value) pair for rollback. In dev tracing (or any write inside an effect) it records an UpdatedAt stack entry keyed by stack string with a hit counter, and sets set_during_effect when active_effect is non-null. For derived sources it eagerly executes a DIRTY derived to track dependencies, then sets status to CLEAN, or MAYBE_DIRTY when the derived is UNOWNED. It bumps the write version, marks all reactions DIRTY, and appends the source to untracked_writes when the currently running clean effect (non-branch/root) might miss the change, e.g. `$effect(() => x++)`. In dev, non-deferred pending inspect effects are flushed immediately.

calls: [Batch](r2-reactivity-core.md#u-43c969fbb82e), [runtime-js-state-and-helpers](r2-reactivity-core.md#u-6cd2387802ec), [execute_derived](r4-runtime-signals.md#u-193107029d03), [flush_inspect_effects](r5-client-reactivity.md#u-8313e354c312)

**Uncertainties.**

- Whether untracked_writes is null versus already populated depends on concurrent writes elsewhere in runtime.js.

<a id="u-a19ed62d3d7e"></a>
### `mark_reactions`

`function mark_reactions(signal, status)` · [packages/svelte/src/internal/client/reactivity/sources.js:L307-L346][f2]

Propagates dirtiness from a source to its reactions, recursively.

With no reactions it returns immediately. Per reaction: in legacy mode the currently running effect is skipped to prevent infinite loops; in dev, inspect effects are collected into inspect_effects for immediate/deferred flushing instead of being scheduled. Reactions that are not already DIRTY get the given status (DIRTY or MAYBE_DIRTY) via set_signal_status; derived reactions are recursed into with MAYBE_DIRTY so their dependents hear about it; non-derived reactions that were not dirty are scheduled (schedule_effect), with block effects additionally appended to eager_block_effects when that list is active. Already-DIRTY reactions are left alone and not rescheduled.

calls: [is_runes](r2-component-context.md#u-71aba13a168a), [schedule_effect](r2-reactivity-core.md#u-ce4f8d895426), [runtime-js-state-and-helpers](r2-reactivity-core.md#u-6cd2387802ec)

**Uncertainties.**

- Whether MAYBE_DIRTY block effects reach schedule_effect: only not_dirty reactions are scheduled, so a MAYBE_DIRTY-propagating call (status MAYBE_DIRTY) schedules them with MAYBE_DIRTY; correctness depends on batch scheduling.

<a id="u-32c84d6fdda4"></a>
### `mutable_source`

`export function mutable_source(initial_value, immutable = false, trackable = true)` · [packages/svelte/src/internal/client/reactivity/sources.js:L108-L121][f2]

Creates a source intended to be mutated in place: unless immutable is passed, its equals is switched to safe_equals so mutation writes always count as changes.

In legacy mode, when trackable is true and there is a component context with a lifecycle list, the signal is appended to component_context.l.s (creating it) so updates can trigger beforeUpdate/afterUpdate callbacks.

**Notes.**

- side_effect: Registers the signal into component_context.l.s in legacy mode; that list is consumed elsewhere.

<a id="u-1be316a4a069"></a>
### `mutate`

`export function mutate(source, value)` · [packages/svelte/src/internal/client/reactivity/sources.js:L128-L134][f2]

Used for `$state` object/array mutations: it re-sets the source to its own current value, read untracked so the read does not register a dependency, thereby notifying reactions of the deep mutation.

Returns the value argument unchanged, mirroring the mutation expression's value.

calls: [packages/svelte/src/internal/client/runtime.js:get](r2-reactivity-core.md#u-98099fbbf12a), [packages/svelte/src/internal/client/reactivity/sources.js:set](r5-client-reactivity.md#u-452914169f68)

<a id="u-452914169f68"></a>
### `packages/svelte/src/internal/client/reactivity/sources.js:set`

`export function set(source, value, should_proxy = false)` · [packages/svelte/src/internal/client/reactivity/sources.js:L143-L163][f2]

Public write path for sources; validates the write and delegates to internal_set.

It throws state_unsafe_mutation when in runes mode and the write happens while the active reaction is a derived, block effect, async, or inspect effect (unless untracking is in effect for non-inspect reactions, or the source is in current_sources). The value is proxied first when should_proxy is set, and in dev tag_proxy labels it with the source's label before internal_set commits it and returns the stored value.

**Notes.**

- failure: Writing to state inside a derived or inspect effect throws state_unsafe_mutation; untracking exempts ordinary reactions but not inspect effects.

calls: [is_runes](r2-component-context.md#u-71aba13a168a), [proxy.js-proxy](r4-runtime-signals.md#u-100d26a5c84c), [tag_proxy](r4-runtime-dev.md#u-3eb12a735d06), [internal_set](r5-client-reactivity.md#u-0dae6a8d64cd)

<a id="u-97497b70f31b"></a>
### `source`

`export function source(v, stack)` · [packages/svelte/src/internal/client/reactivity/sources.js:L66-L85][f2]

Creates the base mutable source signal: a plain object with the given value, reference equality (equals), no reactions, and zero read/write versions.

In dev tracing mode it attaches CreatedAt/UpdatedAt bookkeeping fields (created stack from the argument or get_stack, updated map, set_during_effect, trace). It does not register anything and does not evaluate anything.

calls: [get_stack](r4-runtime-dev.md#u-507749353e33)

<a id="u-acd426d0030b"></a>
### `state`

`export function state(v, stack)` · [packages/svelte/src/internal/client/reactivity/sources.js:L93-L99][f2]

Creates a source like source(v, stack) but additionally registers it via push_reaction_value, marking it as component state in the current reaction context, and returns it.

Marked NO_SIDE_EFFECTS.

calls: [runtime-js-state-and-helpers](r2-reactivity-core.md#u-6cd2387802ec)

<a id="u-55ae66fdfd50"></a>
### `ReactiveValue`

`class ReactiveValue` · [packages/svelte/src/reactivity/reactive-value.js:L6-L15][f4]

Generic wrapper pairing a value-producing function with an external subscription.

The constructor stores fn and builds #subscribe via createSubscriber(onsubscribe), so when current is first read inside a tracked effect, onsubscribe is invoked with an update callback and cleaned up when the last such effect is destroyed. The current getter calls #subscribe() to register the effect, then returns fn(); outside effect tracking the subscribe call is inert and current simply evaluates fn on each read.

calls: [createSubscriber](r2-reactive-primitives.md#u-44838dbc4415)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/reactivity/set.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/reactivity/sources.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/reactivity/equality.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/reactivity/reactive-value.js
