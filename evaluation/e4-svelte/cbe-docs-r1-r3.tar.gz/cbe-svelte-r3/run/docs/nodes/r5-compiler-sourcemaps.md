# Source Maps & Preprocessing

**Capability.** Keeps source maps accurate across preprocessing and transformation: MappedCode pairs strings with decoded maps through concatenation, replace_in_code applies regex replacements as mapped slices, and helpers chain, offset, and merge preprocessor maps into the final compile map.

Use when touching preprocessing or map fidelity. MappedCode (with from_source/from_processed/concat) is the carrier; replace_in_code consumes it; merge/apply/combine helpers integrate preprocessor maps in transform_component; parse_attached_sourcemap adopts inline sourceMappingURLs.

**Depends on.**

- [Compiler State & AST Utilities](r5-compiler-state-utils.md) · model-inferred · 0 edge(s)

**Depended on by.**

- [Transform Entry & Result Assembly](r5-transform-entry.md) · graph-confirmed · 3 edge(s)
- [Preprocessing](r1-preprocess.md) · graph-only · 15 edge(s)

Parent: [Compiler Pipeline](r5-compiler.md)

## Units (19)

<a id="u-9ed57a767ba0"></a>
### `mapped_code.js-mapped-code`

`class MappedCode` · [packages/svelte/src/compiler/utils/mapped_code.js:L75-L90][f1]

Carries a code string plus a decoded source map through preprocessing and transformation, so mappings stay accurate across string rewrites.

Instances hold `string` and `map` (an empty version-3 map is substituted when none is given). The static factories build instances from already-processed code or directly from raw source, and `concat` merges fragments in place; each has its own unit.

<a id="u-292b18a7971e"></a>
### `mapped_code.js-parse-attached-sourcemap`

`export function parse_attached_sourcemap(processed, tag_name)` · [packages/svelte/src/compiler/utils/mapped_code.js:L341-L351][f1]

Strips an attached sourceMappingURL from processed.code and, when it is a base64 data URI, adopts it as processed.map.

The regex is built from the tag name: for 'script' both a `//#...` line comment or a `/*#... */` trailing block comment match; otherwise only a block comment at the end matches. The nested log_warning prints a console warning that includes the first 100 characters of processed.code (or the whole code when shorter) to help locate the preprocessor. In the replacement callback: if the URL is a data URI and processed.map already exists, it warns that only one sourcemap may be returned and ignores the attached map; if no processed.map exists it decodes via b64dec into processed.map; if the URL is a path/URL rather than data, it warns when no map data is present. In all cases the directive is removed from processed.code by returning ''.

**Uncertainties.**

- b64dec behavior for malformed data is unproven (node/browser branches differ).
- A relative sourceMappingURL path is only warned about and never loaded.

<a id="u-8eab9628969e"></a>
### `replace_in_code`

`export async function replace_in_code(regex, get_replacement, location)` · [packages/svelte/src/compiler/preprocess/replace_in_code.js:L69-L72][f2]

Replaces all regex matches in a source's text with MappedCode results produced asynchronously by get_replacement.

It awaits calculate_replacements to gather one Replacement per match, then passes the list to perform_replacements, which stitches unchanged text and replacements into one mapped output. Returns that combined MappedCode as a promise.

calls: [calculate_replacements](r5-compiler-sourcemaps.md#u-8a9b3380f617), [perform_replacements](r5-compiler-sourcemaps.md#u-35d5b911e638)

<a id="u-8a9b3380f617"></a>
### `calculate_replacements`

`function calculate_replacements(re, get_replacement, source)` · [packages/svelte/src/compiler/preprocess/replace_in_code.js:L24-L40][f2]

Collects asynchronous replacements for every regex match in source.

String.replace invokes the callback per match and always returns '' (the actual splicing happens later in perform_replacements). Each match triggers get_replacement(...match) and its promise is chained to produce a Replacement record: the matched string's length and the offset taken from the second-to-last match-array element (the standard String.replace offset argument). Returns Promise.all of all replacement promises, so the result resolves only when every get_replacement has finished.

**Notes.**

- failure: If any get_replacement promise rejects, the returned Promise.all rejects and no replacement is performed.

<a id="u-35d5b911e638"></a>
### `perform_replacements`

`function perform_replacements(replacements, source)` · [packages/svelte/src/compiler/preprocess/replace_in_code.js:L47-L61][f2]

Rebuilds the source as a single MappedCode from an ordered list of Replacement records.

It walks replacements in order: for each, the unchanged text between the previous end and the replacement's offset is wrapped with MappedCode.from_source via slice_source and concatenated, followed by the replacement MappedCode itself; last_end then advances past the matched span. After the loop the trailing unchanged suffix is appended. The result preserves source-map segments for all unchanged regions while replacements carry their own mappings.

calls: [MappedCode.from_source](r5-compiler-sourcemaps.md#u-60c4a1a9f36f), [slice_source](r5-compiler-sourcemaps.md#u-b98556db32bb)

**Uncertainties.**

- Behavior when replacements overlap or are not sorted by offset is not guarded in this code; output would interleave slices incorrectly.

<a id="u-b98556db32bb"></a>
### `slice_source`

`export function slice_source(code_slice, offset, { file_basename, filename, get_locat…` · [packages/svelte/src/compiler/preprocess/replace_in_code.js:L10-L17][f2]

Derives a sub-Source for a code slice taken at a byte offset within a larger source.

The returned object keeps file_basename and filename and wraps get_location so index is shifted by offset before delegating to the parent locator, letting mapping code treat the slice as if it started at position 0 while still resolving absolute positions.

**Notes.**

- contract: Callers pass offsets in the parent source's coordinate system; all locator indexes given relative to the slice are transparently rebased.

<a id="u-389a85833371"></a>
### `apply_preprocessor_sourcemap`

`function apply_preprocessor_sourcemap(filename, svelte_map, preprocessor_map_input)` · [packages/svelte/src/compiler/utils/mapped_code.js:L308-L332][f1]

Merges a preprocessor source map into Svelte's map and returns the enriched map; returns `svelte_map` unchanged when either map is missing.

A string input is JSON.parse'd into a map. The merge is delegated to combine_sourcemaps with `[svelte_map, preprocessor_map]`. Instead of wrapping the result, it defines non-enumerable `toString` (JSON.stringify of this) and `toUrl` (data URI with base64 of the JSON) directly on the result map, satisfying Svelte's SourceMap expectation.

calls: [combine_sourcemaps](r5-compiler-sourcemaps.md#u-6270a2fbedb9)

**Uncertainties.**

- JSON.parse on a malformed string map will throw; no handling is visible.

<a id="u-6270a2fbedb9"></a>
### `combine_sourcemaps`

`export function combine_sourcemaps(filename, sourcemap_list)` · [packages/svelte/src/compiler/utils/mapped_code.js:L265-L300][f1]

Chains a list of source maps (oldest first) into one map via `@jridgewell/remapping`, returning null for an empty list.

If every map except the last has exactly one source, the array interface is used with a null loader and `sourcesContent` skipped. Otherwise the loader interface is used: only `sourcemap_list[0]` is given directly, and the loader returns the next map (advancing `map_idx`) when the sourcefile equals `filename` and a next map exists, else null — the source file becomes the leaf node. After remapping, an absent `file` field is deleted, and when `sources` is empty (a possible remapping outcome with an empty leading map) it is set to `[filename]`.

**Notes.**

- contract: Per the in-code TODO, the equality check assumes `filename` is the basename of the input file and that the preprocessor map lists that basename in sources; this is flagged as brittle.

contract: [get_basename](r5-compiler-sourcemaps.md#u-10b75c582411)

**Uncertainties.**

- Behavior depends on @jridgewell/remapping internals not present in this source.

<a id="u-10b75c582411"></a>
### `get_basename`

`export function get_basename(filename)` · [packages/svelte/src/compiler/utils/mapped_code.js:L443-L445][f1]

Returns the last segment of a filename after splitting on / or \, a browser-safe substitute for Node's `basename`.

<a id="u-a263794e6dc6"></a>
### `get_relative_path`

`function get_relative_path(from, to)` · [packages/svelte/src/compiler/utils/mapped_code.js:L423-L437][f1]

Computes a path for `to` relative to `from`'s directory without Node APIs, so the compiler stays browser-usable.

Both paths are split on / or \; `from`'s last segment (filename) is popped, then common leading segments of both are shifted off. Remaining `from` segments are each replaced with '..'. The result is the '..'-prefixed remainder joined with the remaining `to` segments using '/'.

**Uncertainties.**

- No drive-letter or absolute-path special casing is visible; correctness on such paths is unproven.

<a id="u-61dfd78a863b"></a>
### `get_source_name`

`export function get_source_name(filename, output_filename, fallback)` · [packages/svelte/src/compiler/utils/mapped_code.js:L452-L454][f1]

Chooses the name used for the source in a generated map: when `output_filename` is given it is the input filename made relative to the output via get_relative_path; otherwise it is just the basename of the input filename.

calls: [get_relative_path](r5-compiler-sourcemaps.md#u-a263794e6dc6), [get_basename](r5-compiler-sourcemaps.md#u-10b75c582411)

<a id="u-e8017193524a"></a>
### `last_line_length`

`function last_line_length(s)` · [packages/svelte/src/compiler/utils/mapped_code.js:L12-L14][f1]

Returns the length of a string's last line: total length minus the index of the final newline minus one.

If the string contains no newline this yields the full string length.

<a id="u-a97c97e7b9a7"></a>
### `merge_tables`

`function merge_tables(this_table, other_table)` · [packages/svelte/src/compiler/utils/mapped_code.js:L48-L72][f1]

Merges a second table (sources or names) into a first, returning the combined table, an index remap for the second table, and two changed flags.

`other_table` is treated as empty when nullish. For each value in `other_table`, an existing index in `this_table` (found via strict first-match `indexOf`) is reused; otherwise the value is appended to a copy of `this_table` and `val_changed` becomes true. `idx_changed` starts equal to `val_changed`; if the resulting index map is the identity [0,1,2,...] it is reset to false so callers can skip segment rewriting.

**Uncertainties.**

- Duplicate values within `other_table` rely on `indexOf` first-match semantics; downstream effect of that path was not traced.

<a id="u-58c664c9f3e7"></a>
### `merge_with_preprocessor_map`

`export function merge_with_preprocessor_map(result, options, source_name)` · [packages/svelte/src/compiler/utils/mapped_code.js:L394-L417][f1]

Integrates a preprocessor source map (from compile options) into a compile result's map; does nothing unless `options.sourcemap` is set.

When enabled, it first computes the basename of `options.filename` and rewrites `result.map.sources` to that basename so both maps agree on the source name, then applies the preprocessor map via apply_preprocessor_sourcemap, Object.assigning the returned enriched map into result.map. If the basename differs from `source_name`, sources are converted back to paths relative to `source_name` via get_relative_path.

calls: [apply_preprocessor_sourcemap](r5-compiler-sourcemaps.md#u-389a85833371), [get_basename](r5-compiler-sourcemaps.md#u-10b75c582411), [get_relative_path](r5-compiler-sourcemaps.md#u-a263794e6dc6)

<a id="u-6ba9b18d03ed"></a>
### `sourcemap_add_offset`

`export function sourcemap_add_offset(map, offset, source_index)` · [packages/svelte/src/compiler/utils/mapped_code.js:L22-L40][f1]

Shifts a decoded source map's segment source positions by a line/column offset, mutating the map in place; returns immediately when `mappings` is empty.

For each segment whose source index (index 1) equals `source_index` — i.e. segments pointing at the component source — it adds `offset.line` to the source line (index 2) and, only when the source line is 0, adds `offset.column` to the source column (index 3). Segments referencing other sources are left unchanged.

**Notes.**

- side_effect: Mutates segment arrays of `map` in place; comment notes shifting also ensures segment length >= 4 semantics for the touched entries.

<a id="u-1bc94121324a"></a>
### `MappedCode.concat`

`concat(other)` · [packages/svelte/src/compiler/utils/mapped_code.js:L109-L184][f1]

Concatenates another MappedCode into this one in place, merging strings and maps, returning `this` for chaining; `other` is also mutated.

If `other`'s string is empty the call is a no-op; if this string is empty, this instance adopts the other's string and map. Otherwise the column offset (this string's last-line length) is captured before appending. When the other map has no mappings, only the string changes. Sources and names tables are merged via merge_tables; changed tables are written back, and `other`'s segment source/name indices (indices 1 and 4, each only when >= 0) are rewritten through the index maps, with three loop variants selected by which index maps are non-identity. If both maps have mappings and the column offset is positive, the other map's first-line generated columns are shifted right by the offset; that first line is appended to this map's last mappings line, and remaining lines are appended via push_array.

**Notes.**

- side_effect: Mutates both `this` and `other`; `other`'s mappings array is consumed via shift, so callers must not reuse it.

calls: [last_line_length](r5-compiler-sourcemaps.md#u-e8017193524a), [merge_tables](r5-compiler-sourcemaps.md#u-a97c97e7b9a7), [push_array](r2-compiler-foundations.md#u-4f8a7deedb7c)

<a id="u-5bfe07934570"></a>
### `MappedCode.constructor`

`constructor(string = '', map = null)` · [packages/svelte/src/compiler/utils/mapped_code.js:L90-L102][f1]

Initializes a MappedCode with the given string (defaulting to '').

When a map argument is supplied it is stored as-is; otherwise a fresh empty decoded map ({version:3, mappings:[], sources:[], names:[]}) is created so consumers never see a null map.

group: [mapped_code.js-mapped-code](r5-compiler-sourcemaps.md#u-9ed57a767ba0)

<a id="u-55e9f4707897"></a>
### `MappedCode.from_processed`

`static from_processed(string, map)` · [packages/svelte/src/compiler/utils/mapped_code.js:L192-L209][f1]

Builds a MappedCode from generated code and an optional existing map, padding the map so mappings lines match the generated line count.

With a map, empty mapping lines are appended until its length equals the number of lines in `string` (some tools produce fewer). Without a map, an empty string returns a default empty MappedCode; otherwise a fresh empty version-3 map with one empty mapping line per generated line is created.

calls: [mapped_code.js-mapped-code](r5-compiler-sourcemaps.md#u-9ed57a767ba0)

<a id="u-60c4a1a9f36f"></a>
### `MappedCode.from_source`

`static from_source({ source, file_basename, get_location })` · [packages/svelte/src/compiler/utils/mapped_code.js:L216-L248][f1]

Builds a MappedCode from raw source text by generating a high-resolution identity map back to the original file; resolution decreases later when merged with Svelte's map.

The offset comes from `get_location(0)`, falling back to {line:0, column:0} when absent; the map's `sources` is `[file_basename]`. An empty source short-circuits with that empty map. Otherwise the source is split on newlines; each line is split into tokens by `regex_line_token` (punctuation or whitespace runs), and every non-empty token yields a segment `[column, 0, offset.line + line, column]`, with the column advanced by token length. Finally all first-line generated columns are shifted by `offset.column`.

**Notes.**

- contract: Depends on the `Source` shape {source, file_basename, get_location} provided by the preprocessor.

calls: [mapped_code.js-mapped-code](r5-compiler-sourcemaps.md#u-9ed57a767ba0)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/utils/mapped_code.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/preprocess/replace_in_code.js
