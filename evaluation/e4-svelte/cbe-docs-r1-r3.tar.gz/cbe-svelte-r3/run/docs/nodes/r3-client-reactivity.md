# Client Reactivity: Props and Stores

**Capability.** The reactive data plane for compiled components: prop accessors and their proxy-based variants (spread, rest, legacy $$props/$$restProps), and per-component store subscription/usage helpers including the store-binding mutability flag.

client-props implements how compiled prop reads/writes behave; client-stores implements store_get/store_set machinery the compiler emits. props.js depends on the store-binding flag, linking the two.

**Children.**

- [Client Prop Accessors](r3-client-props.md) `r3-client-props` · 6 unit(s)
- [Client Store Integration](r3-client-stores.md) `r3-client-stores` · 5 unit(s)

Parent: [Client Runtime](r3-client-runtime.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
