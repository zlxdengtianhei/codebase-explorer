# Runtime Dev-Mode Instrumentation

**Capability.** Development-only diagnostics: dev CSS style registration/cleanup keyed by hash, source-location annotation of created DOM, $inspect effect implementation, and reactive tracing that captures stacks, labels sources, and logs read signals during expression evaluation.

Everything here is compiled-out or inert in production builds. tracing.js and proxy.js cooperate: proxies accept label paths via tag/tag_proxy, and trace/log_entry report what an expression read. elements.js and css.js support location and style dev checks.

**Depends on.**

- [Signals, Deriveds, and Proxies](r4-runtime-signals.md) · model-inferred · 0 edge(s)

**Depended on by.**

- [Effect System](r4-runtime-effects.md) · model-inferred · 0 edge(s)
- [Reactive Wrapper Classes](r1-reactive-collections.md) · graph-only · 19 edge(s)
- [Signals, Deriveds, and Proxies](r4-runtime-signals.md) · graph-only · 10 edge(s)

Parent: [Svelte Compiler and Runtime](r4-svelte-monorepo.md)

## Units (13)

<a id="u-5a39dee4043b"></a>
### `cleanup_styles`

`export function cleanup_styles(hash)` · [packages/svelte/src/internal/client/dev/css.js:L22-L31][f1]

Removes all style elements registered under a hash and deletes the hash entry from the registry.

If no styles were registered for the hash it returns immediately without error. Each element's DOM remove() detaches it from the document.

uses: [register_style](r4-runtime-dev.md#u-9179e17842d4)

<a id="u-9179e17842d4"></a>
### `register_style`

`export function register_style(hash, style)` · [packages/svelte/src/internal/client/dev/css.js:L8-L17][f1]

Records a compiled component's style element in a module-level Map keyed by the style hash, creating a Set per hash on first registration.

Enables later removal of all style elements for a component on cleanup or HMR invalidation. Has no return value; multiple style elements with the same hash accumulate in the set.

uses: [cleanup_styles](r4-runtime-dev.md#u-5a39dee4043b)

<a id="u-bcaf51568270"></a>
### `add_locations`

`export function add_locations(fn, filename, locations)` · [packages/svelte/src/internal/client/dev/elements.js:L13-L22][f2]

Wraps a template-building function so the DOM it creates is annotated with source locations.

Returns a variadic wrapper that calls the original fn, then picks the starting node: the fragment's firstChild when not hydrating and the result is a document fragment, the node itself otherwise (hydration skips this selection because comments mark structure), and delegates to assign_locations with the compile-time locations array before returning the original DOM result unchanged.

calls: [assign_locations](r4-runtime-dev.md#u-b9f6253012a3); uses: [function::hydrating::0][f3]

**Uncertainties.**

- When hydrating, the code passes dom itself to assign_locations; correctness there depends on hydration comment handling in assign_locations.

<a id="u-b16906152b4f"></a>
### `assign_location`

`function assign_location(element, filename, location)` · [packages/svelte/src/internal/client/dev/elements.js:L29-L39][f2]

Attaches an __svelte_meta object to a single element recording the enclosing dev stack and the file/line/column of its template location, then, if the location carries a third entry (child locations), recursively assigns them to the element's firstChild subtree.

calls: [assign_locations](r4-runtime-dev.md#u-b9f6253012a3); uses: [function::dev_stack::0][f4]

<a id="u-b9f6253012a3"></a>
### `assign_locations`

`function assign_locations(node, filename, locations)` · [packages/svelte/src/internal/client/dev/elements.js:L46-L63][f2]

Walks a sibling chain assigning template source locations to elements in order.

While hydrating, comment nodes are inspected to track template-boundary depth: HYDRATION_START or HYDRATION_START_ELSE increments it, HYDRATION_END decrements it, so comments inside hydration blocks are skipped. Only when depth is zero and the node is an element does it call assign_location with the next location, consuming locations strictly in order; traversal stops when the chain ends or locations are exhausted. Excess elements or excess locations are silently ignored.

**Notes.**

- condition: A HYDRATION_END check uses data[0], matching prefix-style end markers; other comment data is ignored.

calls: [assign_location](r4-runtime-dev.md#u-b16906152b4f)

**Uncertainties.**

- Whether hydration start/end comment data matching is exhaustive for all template kinds depends on the constants' exact values, not visible here.

<a id="u-da1d251f1f86"></a>
### `inspect`

`export function inspect(get_value, inspector = console.log)` · [packages/svelte/src/internal/client/dev/inspect.js:L11-L55][f5]

Implements $inspect: registers an inspect effect that synchronously reads get_value(), snapshots it (non-reactively via untrack), and calls the inspector (default console.log) with 'init' on the first run and 'update' thereafter.

If reading the value throws — possible because inspect effects run synchronously and the value may reference not-yet-created state — the error is captured and the inspector call skipped. A companion render effect re-reads get_value() to stay scheduled alongside the inspect effect; when it runs and an error was captured, it console.errors the error and resets the sentinel to UNINITIALIZED, so errors are reported once. validate_effect('$inspect') enforces valid usage context first.

**Notes.**

- failure: get_value errors inside the render effect's re-read are deliberately swallowed; only the inspect effect's captured error is reported.

calls: [inspect_effect](r4-runtime-effects.md#u-b327f388eca5), [render_effect](r4-runtime-effects.md#u-bbe822faa096), [runtime-js-state-and-helpers](r2-reactivity-core.md#u-6cd2387802ec), [packages/svelte/src/internal/shared/clone.js:snapshot](r1-shared-runtime.md#u-bfcc537be9f1)

**Uncertainties.**

- If the render effect never re-runs after an error, the captured error is never reported; the comment states this corresponds to the $inspect being destroyed.

<a id="u-507749353e33"></a>
### `get_stack`

`export function get_stack(label)` · [packages/svelte/src/internal/client/dev/tracing.js:L136-L174][f6]

Captures a cleaned Error stack for tracing.

Returns null immediately when the environment provides no stack. Otherwise it filters lines: drops bare 'Error' headers and any internal svelte frames (paths containing 'svelte/src/internal'), but aborts with null if a validate_each_keys frame appears, signalling the stack came from a warned path not worth attributing. If nothing survives filtering it also returns null. On success it rewrites the error's stack to the filtered lines and renames it '<label>Error' (the suffix being required for stack rendering), returning the error.

**Notes.**

- side_effect: define_property overrides the error's own stack and name properties.

**Uncertainties.**

- The 'Error' header comparison and 'svelte/src/internal' substring assume a specific engine stack format; other engines may produce different line shapes.

<a id="u-60ad1c0a04b0"></a>
### `get_type`

`function get_type(signal)` · [packages/svelte/src/internal/client/dev/tracing.js:L80-L83][f6]

Classifies a traced signal for display: DERIVED or ASYNC flags yield '$derived'; otherwise a label starting with '$' indicates 'store'; everything else is '$state'.

uses: [log_entry](r4-runtime-dev.md#u-28361dd4c3b4)

<a id="u-6200b3434a44"></a>
### `label`

`export function label(value)` · [packages/svelte/src/internal/client/dev/tracing.js:L200-L205][f6]

Formats a value for trace labels: symbols render as Symbol(description), functions as '<function>', non-null objects as '<object>', and everything else via String(value); null falls through to String, yielding 'null'.

uses: [map-js-sveltemap](r1-reactive-collections.md#u-a8d1fced426f)

<a id="u-28361dd4c3b4"></a>
### `log_entry`

`function log_entry(signal, entry)` · [packages/svelte/src/internal/client/dev/tracing.js:L22-L74][f6]

Prints one traced signal as a collapsed console group during expression tracing.

Skips signals whose value is still UNINITIALIZED. Classifies the signal via get_type, computes dirtiness as signal.wv exceeding the active reaction's wv or the reaction's wv being 0, and styles bold blue when dirty versus grey when clean. Grouped value uses a snapshot for state objects, the raw value otherwise. For $derived signals it recursively logs each unique dep. It then logs signal.created, each update's error stack when dirty, and any traces recorded for the entry before closing the group.

**Notes.**

- side_effect: signal.updated is treated as a Map of entries exposing .error stacks; a differently shaped updated value would throw.

calls: [get_type](r4-runtime-dev.md#u-60ad1c0a04b0), [packages/svelte/src/internal/shared/clone.js:snapshot](r1-shared-runtime.md#u-bfcc537be9f1); uses: [packages/svelte/src/internal/client/dev/tracing.js:trace](r4-runtime-dev.md#u-ba4e4c464b32)

**Uncertainties.**

- Reading current_reaction.wv assumes active_reaction is non-null; the cast asserts this but null would throw at the comparison.

<a id="u-8f0bd6f00a08"></a>
### `packages/svelte/src/internal/client/dev/tracing.js:tag`

`export function tag(source, label)` · [packages/svelte/src/internal/client/dev/tracing.js:L180-L185][f6]

Labels a reactive source for trace output: stores label on source.label and forwards the source's current value to tag_proxy so proxied values register the label path.

Returns the source unchanged.

calls: [tag_proxy](r4-runtime-dev.md#u-3eb12a735d06)

<a id="u-3eb12a735d06"></a>
### `tag_proxy`

`export function tag_proxy(value, label)` · [packages/svelte/src/internal/client/dev/tracing.js:L191-L195][f6]

Forwards a label into a possibly-proxied value by invoking value?.[PROXY_PATH_SYMBOL]?.(label) when present; proxies use this hook to record label paths for dev output.

Returns the value unchanged regardless of whether the hook existed.

<a id="u-ba4e4c464b32"></a>
### `packages/svelte/src/internal/client/dev/tracing.js:trace`

`export function trace(label, fn)` · [packages/svelte/src/internal/client/dev/tracing.js:L90-L130][f6]

Runs fn() while recording which reactive signals it reads, then reports them for dev tracing.

Installs a fresh tracing_expressions record (saving and finally restoring any previous one), times fn with performance.now, and untracks the label getter. Reporting branches: if no effect is currently tracking it logs that the expression ran outside an effect; if no signals were recorded it logs that there are no reactive dependencies; otherwise it opens a console group and logs each recorded signal's entry via log_entry, clearing tracing_expressions before closing the group. Always returns fn's value; the finally block guarantees the previous tracing context is restored even if fn or logging throws.

**Notes.**

- side_effect: Console timing uses performance.now; output includes elapsed milliseconds formatted to two decimals.

calls: [log_entry](r4-runtime-dev.md#u-28361dd4c3b4), [effect_tracking](r4-runtime-effects.md#u-c4dc07dc96fc), [runtime-js-state-and-helpers](r2-reactivity-core.md#u-6cd2387802ec)

**Uncertainties.**

- How entries get populated during fn() depends on readers of tracing_expressions elsewhere (e.g. runtime get), not shown in this file.
- In the group branch tracing_expressions is set to null before finally restores the saved value; the null interval's effect on concurrent readers is not specified here.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dev/css.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dev/elements.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/hydration.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/context.js
[f5]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dev/inspect.js
[f6]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dev/tracing.js
