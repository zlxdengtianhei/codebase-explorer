# CSS Selector Pruning

**Capability.** Decides which complex selectors in a stylesheet can match an element in the component tree, using combinator walking, sibling-existence certainty maps, and conservative attribute matching, so unused CSS can be pruned.

Start at prune and follow apply_selector/apply_combinator for matching; the candidate-map helpers (get_possible_element_siblings, add_to_map, higher_existence) model existence certainty. All helpers here are internal to this one capability.

Parent: [Analyze Phase](r1-compiler-analyze.md)

## Units (19)

<a id="u-41775043a205"></a>
### `prune`

`export function prune(stylesheet, element)` · [packages/svelte/src/compiler/phases/2-analyze/css/css-prune.js:L86-L88][f1]

Walks a stylesheet to decide which complex selectors match one element, marking matching selectors used so pruning keeps them.

For each Rule: if the rule is a global block only its prelude is visited (block contents skipped); otherwise normal recursion proceeds. For each ComplexSelector: the module-level snippet seen-set is cleared, its relative selectors are computed and matched against the element in BACKWARD direction, and a match sets metadata.used = true. context.next() is deliberately not called for ComplexSelector; nested selectors inside :is/:where are only reached via the ComplexSelector visitor itself.

calls: [get_relative_selectors](r1-css-prune.md#u-5f13be96e649), [apply_selector](r1-css-prune.md#u-ca0893fe0929)

**Uncertainties.**

- How metadata.used is consumed downstream is outside this file

<a id="u-ca0893fe0929"></a>
### `apply_selector`

`function apply_selector(relative_selectors, rule, element, direction)` · [packages/svelte/src/compiler/phases/2-analyze/css/css-prune.js:L195-L213][f1]

Matches one relative selector against an element, consuming selectors from the front (FORWARD) or back (BACKWARD).

matched is true only if a relative selector exists, it might apply to the node, and its combinator links to a further match. On success, the relative selector is marked scoped unless it is an outer global, and element.metadata.scoped is set true — the point where scoping flags are written. An empty rest list yields matched false.

calls: [relative_selector_might_apply_to_node](r1-css-prune.md#u-8cf24a10b3c2), [apply_combinator](r1-css-prune.md#u-0baa697559cd), [is_outer_global](r2-css-analyze.md#u-a5fd8a871e73)

<a id="u-0baa697559cd"></a>
### `apply_combinator`

`function apply_combinator(relative_selector, rest_selectors, rule, node, direction)` · [packages/svelte/src/compiler/phases/2-analyze/css/css-prune.js:L223-L285][f1]

Checks the structural relation implied by a matched selector's combinator.

Without a combinator it returns true. For ' ' and '>': it collects ancestors (BACKWARD) or descendants (FORWARD, adjacent-only for '>'), recursing with apply_selector on each; BACKWARD also succeeds when all remaining selectors are global and the traversal is a descendant relation or no candidates exist. For '+' and '~': it gathers possible element siblings; element siblings are recursed on, while RenderTag/SlotElement/Component siblings match only when exactly one global selector remains (e.g. :global(.x) + p against {@render foo()}<p>); BACKWARD additionally succeeds when the node has no element parent and all remaining selectors are global. Any other combinator name returns true (TODO in source).

calls: [apply_selector](r1-css-prune.md#u-ca0893fe0929), [get_descendant_elements](r1-css-prune.md#u-f417ee58086c), [get_ancestor_elements](r1-css-prune.md#u-f22cb866ff97), [get_possible_element_siblings](r1-css-prune.md#u-8bc72661b27e), [get_element_parent](r1-css-prune.md#u-16466c9d33bc), [is_global](r1-css-prune.md#u-b61f649ec5db)

**Uncertainties.**

- The .next() edges in the graph evidence are for-of iterator artifacts, not cross-module calls

<a id="u-5f13be96e649"></a>
### `get_relative_selectors`

`function get_relative_selectors(node)` · [packages/svelte/src/compiler/phases/2-analyze/css/css-prune.js:L125-L135][f1]

Builds the scoping-relevant selector list of a complex selector, adding implicit CSS nesting when needed.

It truncates trailing global selectors; if the selector belongs to a rule with a parent rule and any selectors remain, it walks each relative selector (including pseudo-class arguments) looking for a NestingSelector, stopping at the first found. If none exists, the first selector gets a descendant combinator when it lacks one and the shared synthetic nesting_selector (&) is unshifted, so matching will also check the parent rule. The synthetic nesting_selector and descendant_combinator are module-level shared objects.

calls: [truncate](r1-css-prune.md#u-2de4cf200800)

<a id="u-8cf24a10b3c2"></a>
### `relative_selector_might_apply_to_node`

`function relative_selector_might_apply_to_node(relative_selector, rule, element, dire…` · [packages/svelte/src/compiler/phases/2-analyze/css/css-prune.js:L348-L453][f1]

Tests whether an element satisfies each simple selector of a relative selector.

:has(...) selectors are split out first and handled like a downward match: each truncated complex selector inside :has is applied FORWARD both including and excluding the element itself (element inclusion is forced when ancestor rules involve globals or :root/:global); a truncated-empty :global argument is marked used and matched; if any :has fails to match, the whole selector returns false. Remaining selectors: Percentage and Nth are skipped; :host/:root return false; a :global(...) as sole selector applies its inner selectors BACKWARD; bare :global returns true; :not(...) contents are walked and marked used (multi-child :not complex selectors are assumed matched, scoping the element chain); :is/:where try each truncated complex selector BACKWARD, or assume a match for multi-child complex selectors, returning false if none match; pseudo elements always pass; attribute selectors consult the whitelist (details/dialog open) or attribute_matches; class and id selectors match via attribute_matches against class/~/id/=; type selectors match on case-insensitive name or '*' or SvelteElement; a NestingSelector matches if any parent-rule prelude complex selector applies BACKWARD or is entirely global, otherwise false. The default outcome is true (possible match).

calls: [apply_selector](r1-css-prune.md#u-ca0893fe0929), [truncate](r1-css-prune.md#u-2de4cf200800), [attribute_matches](r1-css-prune.md#u-5f19512cd934), [is_global](r1-css-prune.md#u-b61f649ec5db), [get_element_parent](r1-css-prune.md#u-16466c9d33bc); uses: [function::get_parent_rules_placeholder][f1]

<a id="u-2de4cf200800"></a>
### `truncate`

`function truncate(node)` · [packages/svelte/src/compiler/phases/2-analyze/css/css-prune.js:L163-L186][f1]

Discards trailing :global selectors that are irrelevant for scoping.

findLastIndex locates the last child that is not global-like, not a bare :global (no args), and not metadata.is_global; children up to and including it are returned. For retained children that reference :root and are not global-like, the returned child keeps only :has(...) selectors, because with e.g. :root.y:has(...) the root part is unscoped while :has contents should still be scoped.

<a id="u-b61f649ec5db"></a>
### `is_global`

`function is_global(selector, rule)` · [packages/svelte/src/compiler/phases/2-analyze/css/css-prune.js:L296-L335][f1]

Recursively decides whether a relative selector counts as global for scoping.

Returns true immediately for metadata.is_global or is_global_like. Otherwise every simple selector must be global-capable: :is/:where with args are global-capable when every complex selector in their args is recursively global (checked against the same rule); a NestingSelector is evaluated against the parent rule's prelude as owner; other pseudo classes only via is_unscoped_pseudo_class. If any selector is neither explicitly-global-bearing nor can-be-global, the result is false; otherwise true when some selector was explicitly global or the selector list is empty.

calls: [is_unscoped_pseudo_class](r2-css-analyze.md#u-2d29e82903c1)

<a id="u-5f19512cd934"></a>
### `attribute_matches`

`function attribute_matches(node, name, expected_value, operator, case_insensitive)` · [packages/svelte/src/compiler/phases/2-analyze/css/css-prune.js:L626-L735][f1]

Decides whether an element's attributes could satisfy an attribute selector, conservatively returning true when the answer cannot be determined.

Spread attributes, a matching bind directive, a style directive for 'style', and a class directive for 'class' (always for non-'~=' operators, or when the directive name equals the expected value) match immediately. Real attributes are compared by lowercased name; a bare attribute (value === true) matches only with a null operator, and a null expected value matches anything. Static text attributes are tested directly via test_attribute, except class/style keep scanning later attributes when not matched. Dynamic values are expanded through get_attribute_chunks and get_possible_values; an unknown chunk value or more than 20 pending partial combinations returns true because combinations cannot be enumerated. Chunk values containing boundary whitespace are combined pairwise with previous values; values fully bounded by whitespace go straight to the result set. Finally any computed value matching via test_attribute returns true; exhausting all attributes returns false.

calls: [test_attribute](r1-css-prune.md#u-5aa194851017), [get_possible_values](r2-css-analyze.md#u-cb59d8ba04c6), [ast-js-attribute-helpers](r4-compiler-ast-utils.md#u-e05972fa52ab)

**Uncertainties.**

- get_possible_values and get_attribute_chunks semantics are only partially visible here; their exact value sets come from utils.js/ast.js

<a id="u-5aa194851017"></a>
### `test_attribute`

`function test_attribute(operator, expected_value, case_insensitive, value)` · [packages/svelte/src/compiler/phases/2-analyze/css/css-prune.js:L596-L617][f1]

Evaluates one CSS attribute-matcher operator against a concrete value.

With case_insensitive both sides are lowercased first. Operators: '=' exact equality, '~=' whitespace-split membership, '|=' hyphen-prefix comparison, '^=' prefix, '$=' suffix, '*=' substring. Any other operator throws Error("this shouldn't happen").

**Notes.**

- failure: Unknown operator throws rather than returning false.

<a id="u-f22cb866ff97"></a>
### `get_ancestor_elements`

`function get_ancestor_elements(node, adjacent_only, seen = new Set())` · [packages/svelte/src/compiler/phases/2-analyze/css/css-prune.js:L750-L781][f1]

Collects ancestor elements by walking node.metadata.path backwards.

RegularElement/SvelteElement parents are appended, stopping immediately for adjacent_only. On encountering a SnippetBlock parent, its render sites are recursed (sharing a seen-set to prevent infinite recursion) and the path walk stops there. The default fresh seen-set is shared across recursive snippet calls.

<a id="u-f417ee58086c"></a>
### `get_descendant_elements`

`function get_descendant_elements(node, adjacent_only, seen = new Set())` · [packages/svelte/src/compiler/phases/2-analyze/css/css-prune.js:L788-L795][f1]

Collects descendant elements of a node.

It walks the node's fragment (or the RenderTag itself) with zimmerframe; the generic visitor pushes RegularElement/SvelteElement nodes and only recurses into them when not adjacent_only. RenderTags recurse into each unseen snippet body (tracked in a shared seen-set to avoid loops); all other nodes recurse normally. For a RenderTag input the tag itself is walked rather than its fragment.

group: [get_descendant_elements](r1-css-prune.md#u-f417ee58086c)

<a id="u-16466c9d33bc"></a>
### `get_element_parent`

`function get_element_parent(node)` · [packages/svelte/src/compiler/phases/2-analyze/css/css-prune.js:L827-L840][f1]

Returns the nearest RegularElement or SvelteElement found by scanning node.metadata.path backwards, or null when none exists.

Non-element ancestors such as fragments and blocks are skipped without stopping.

<a id="u-8bc72661b27e"></a>
### `get_possible_element_siblings`

`function get_possible_element_siblings(node, direction, adjacent_only, seen = new Set())` · [packages/svelte/src/compiler/phases/2-analyze/css/css-prune.js:L849-L941][f1]

Enumerates the possible element siblings of a node in the given direction, returning a map of candidate nodes to an existence certainty.

It walks the node's ancestor path backwards, scanning each enclosing fragment's nodes in direction order. RegularElement siblings without a slot attribute are NODE_DEFINITELY_EXISTS (returned immediately when adjacent_only); SlotElement and Component contribute themselves as NODE_PROBABLY_EXISTS plus their nested siblings; other blocks contribute nested siblings via get_possible_nested_siblings, stopping early under adjacent_only only when definite elements were found — slot/render/svelte:element candidates may resolve to nothing, so scanning continues. SvelteElement and RenderTag siblings are NODE_PROBABLY_EXISTS, with RenderTag snippet bodies also contributing nested siblings. When the fragment is exhausted, the walk moves to the next outer ancestor; Component/SvelteComponent/SvelteSelf ancestors are skipped, a SnippetBlock ancestor recurses into its render sites (seen-set guarded, early return when adjacent_only with a single site and definite elements), non-block ancestors stop the walk, and an EachBlock whose body is the current fragment contributes its nested siblings since later siblings can act as earlier ones.

calls: [get_possible_nested_siblings](r1-css-prune.md#u-776b8802874e), [has_definite_elements](r1-css-prune.md#u-41937f37bf51), [add_to_map](r1-css-prune.md#u-6a4f9f3a80c1), [is_block](r1-css-prune.md#u-a2e749949279)

**Uncertainties.**

- The path[i--] double-decrement sequencing means current is the node after the fragment in the path; correctness relies on path layout not visible here

<a id="u-776b8802874e"></a>
### `get_possible_nested_siblings`

`function get_possible_nested_siblings(node, direction, adjacent_only, seen = new Set())` · [packages/svelte/src/compiler/phases/2-analyze/css/css-prune.js:L950-L1009][f1]

Collects possible element siblings reachable inside a block-like node's branches, in the given direction.

Each node type contributes its fragments: EachBlock body+fallback, IfBlock consequent+alternate, AwaitBlock pending/then/catch, KeyBlock and SlotElement their fragment, SnippetBlock its body (returning empty when already seen, then recording it), and Component its fragment plus snippet bodies. Each fragment is scanned with loop_child; a null/missing fragment or non-definite results mark the search non-exhaustive, and SlotElement/SnippetBlock start non-exhaustive. When not exhaustive, every result is downgraded to NODE_PROBABLY_EXISTS because a real sibling might not exist at runtime.

calls: [loop_child](r1-css-prune.md#u-0a565ad64fac), [has_definite_elements](r1-css-prune.md#u-41937f37bf51), [add_to_map](r1-css-prune.md#u-6a4f9f3a80c1)

<a id="u-41937f37bf51"></a>
### `has_definite_elements`

`function has_definite_elements(result)` · [packages/svelte/src/compiler/phases/2-analyze/css/css-prune.js:L1015-L1023][f1]

Returns true only when the given candidate map contains at least one NODE_DEFINITELY_EXISTS entry; empty maps return false.

<a id="u-7ab616fd59eb"></a>
### `higher_existence`

`function higher_existence(exist1, exist2)` · [packages/svelte/src/compiler/phases/2-analyze/css/css-prune.js:L1043-L1046][f1]

Picks the stronger NodeExistsValue: the first value when the second is undefined, otherwise the larger of the two (NODE_DEFINITELY_EXISTS = 1 beats NODE_PROBABLY_EXISTS = 0).

<a id="u-a2e749949279"></a>
### `is_block`

`function is_block(node)` · [packages/svelte/src/compiler/phases/2-analyze/css/css-prune.js:L1092-L1100][f1]

Type guard reporting whether a node is one of IfBlock, EachBlock, AwaitBlock, KeyBlock, or SlotElement.

<a id="u-0a565ad64fac"></a>
### `loop_child`

`function loop_child(children, direction, adjacent_only, seen)` · [packages/svelte/src/compiler/phases/2-analyze/css/css-prune.js:L1054-L1086][f1]

Scans a fragment's children in direction order, accumulating possible sibling elements.

RegularElement children are definite (breaking immediately under adjacent_only); SvelteElement children are probable; RenderTag children contribute each snippet's nested siblings; block children contribute get_possible_nested_siblings results, breaking early only when adjacent_only and definite elements were found. Other child types are skipped and the scan continues.

calls: [get_possible_nested_siblings](r1-css-prune.md#u-776b8802874e)

<a id="u-6a4f9f3a80c1"></a>
### `add_to_map`

`function add_to_map(from, to)` · [packages/svelte/src/compiler/phases/2-analyze/css/css-prune.js:L1032-L1036][f1]

Merges one existence map into another, keeping the higher certainty for nodes already present via higher_existence.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/css/css-prune.js
