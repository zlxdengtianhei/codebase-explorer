# Compiler Public Entry

**Capability.** Public compiler API surface (compile, compileModule, parse) that strips BOMs, drives the phase pipeline, and converts internal ASTs to public shape; includes the deprecated walk stub.

Call compile for components, compileModule for runes-only JS, and parse for AST-only access. All three funnel through remove_bom and to_public_ast.

**Depends on.**

- [Analysis Driver](r3-analyze-driver.md) · graph-confirmed · 2 edge(s) · compile and compileModule invoke the analysis driver to scope and validate the AST before transformation.

Parent: [Compiler Pipeline](r3-compiler.md)

## Units (6)

<a id="u-a54e3b374c84"></a>
### `compile`

`export function compile(source, options)` · [packages/svelte/src/compiler/index.js:L21-L55][f1]

Compile Svelte component source into a JavaScript module by running the parse–analyze–transform pipeline.

It strips a byte-order mark, resets compiler state from the options (warningFilter, filename), and validates options. After parsing, svelte:options are split: customElement becomes customElementOptions while other parsed options spread over the validated ones so parsed values win. If parsed.metadata.ts is truthy, remove_typescript_nodes is applied to fragment, instance, and module (each only when present) and to customElementOptions.extend when set. It then runs analyze_component and transform_component, and attaches the public AST via to_public_ast, choosing modern or legacy shape from options.modernAst.

calls: [to_public_ast](r3-compiler-entry.md#u-bbe3d8bf2fb6), [remove_bom](r3-compiler-entry.md#u-2ee755d4c746)

**Uncertainties.**

- Behavior of remove_typescript_nodes, analyze_component, and transform_component lies outside this file

<a id="u-5cd4b4bd0816"></a>
### `compileModule`

`export function compileModule(source, options)` · [packages/svelte/src/compiler/index.js:L64-L71][f1]

Compile plain JavaScript source containing runes into a module, with no template parsing.

It strips a byte-order mark, resets compiler state with the caller's warning filter and filename, validates module options, then returns transform_module(analysis) where analysis comes from analyze_module(source, validated). No AST conversion step runs.

<a id="u-08797705aefb"></a>
### `parse`

`export function parse(source, { modern, loose } = {})` · [packages/svelte/src/compiler/index.js:L112-L118][f1]

Parse a component and return only its AST, without analysis or code generation.

Removes a byte-order mark, resets state with a warning filter that suppresses every warning and an undefined filename, parses with _parse passing the loose flag (per docs, tries to return an AST even for non-compilable input), and returns to_public_ast(source, ast, modern): the modern AST when modern is truthy, otherwise the legacy Svelte 4 AST. The docstrings note `filename` is unused and slated for removal.

<a id="u-2ee755d4c746"></a>
### `remove_bom`

`function remove_bom(source)` · [packages/svelte/src/compiler/index.js:L155-L160][f1]

Strip a leading byte-order mark: if the first character code is 0xFEFF the string minus its first character is returned, otherwise the input unchanged.

<a id="u-bbe3d8bf2fb6"></a>
### `to_public_ast`

`function to_public_ast(source, ast, modern)` · [packages/svelte/src/compiler/index.js:L125-L127][f1]

Convert an internal AST root into its public shape.

In the modern path it first cleans svelte:options attributes — deleting metadata from each attribute, its value, and each array element — then walks the whole tree with zimmerframe using a generic handler that deletes node.metadata from every node before recursing via next(); the walk result is returned. In the non-modern path it delegates to convert(source, ast), rebuilding the Svelte 4 legacy AST. The modern path mutates nodes in place with delete rather than copying.

calls: [legacy-js-convert](r1-legacy-ast-conversion.md#u-4723dd340fbf)

<a id="u-c9e4085285ea"></a>
### `walk`

`export function walk()` · [packages/svelte/src/compiler/index.js:L166-L170][f1]

Deprecated stub that always throws an error telling callers to import walk from estree-walker instead of svelte/compiler; it never returns.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/index.js
