# Server Transform Phase

**Capability.** Code generation for server-side rendering: renders elements, components, attributes (including spread, class, and style), {@debug}, legacy reactive-statement capture, and identifier rewriting into SSR output code.

RegularElement and shared/element.js own attribute serialization; Component, DebugTag, Identifier, and LabeledStatement handle their respective nodes. All emit code that calls the server runtime.

**Depends on.**

- [Server Runtime](r3-server-runtime.md) · model-inferred · 0 edge(s)
- [Shared Predicates and Hash](r3-shared-utils.md) · graph-confirmed · 7 edge(s)
- [Server Transform](r2-server-transform.md) · graph-only · 16 edge(s)

Parent: [Compiler Pipeline](r3-compiler.md)

## Units (11)

<a id="u-fb63ecc7b839"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/Component.js:Component`

`export function Component(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/Component.js:L10-L12][f1]

Handles a <Component /> node by delegating to build_inline_component with an identifier for the component's name.

calls: [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/component.js:build_inline_component](r5-transform-server.md#u-cca955f8230f)

<a id="u-20e9980643b4"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/DebugTag.js:DebugTag`

`export function DebugTag(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/DebugTag.js:L10-L24][f2]

Emits a {@debug} tag as a `console.log` of an object literal mapping each listed identifier to its visited value, appended to the template, followed by a `debugger` statement so server rendering pauses in a debugger.

<a id="u-3c30c4f1dadd"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/Identifier.js:Identifier`

`export function Identifier(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/Identifier.js:L11-L19][f3]

Rewrites referenced identifiers during server transformation.

Non-references (property keys, member properties) return undefined so traversal continues. `$$props` references become `$$sanitized_props`; any other reference is turned into a getter expression via build_getter, which resolves stores/state appropriately based on transform state.

calls: [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/utils.js:build_getter](r2-server-transform.md#u-25646e8536b2)

**Uncertainties.**

- Exact getter forms produced by build_getter are defined in shared/utils.js.

<a id="u-42a7cea77ed0"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/LabeledStatement.js:LabeledStatement`

`export function LabeledStatement(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/LabeledStatement.js:L9-L24][f4]

Captures legacy `$:` reactive statements for later topological ordering.

If the analysis is in runes mode, the statement is at path length 1 or less meaning top-level? actually the condition skips when runes mode, path length > 1, or the label is not `$`: in those cases it returns undefined and traversal proceeds normally. Otherwise the labeled body is visited, re-wrapped in a `$:`-style labeled statement (preserving the label so `break $` still works), and stored in context.state.legacy_reactive_statements keyed by the node; the statement itself is replaced by b.empty in output.

**Uncertainties.**

- The exact semantics of path length as a top-level test, and how legacy_reactive_statements is consumed, are outside this file; the TODO comment notes module-context bailing out is not implemented.

<a id="u-7055b95dd599"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/RegularElement.js:RegularElement`

`export function RegularElement(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/RegularElement.js:L17-L188][f5]

Renders a regular HTML element to server output: opening tag literal, attributes via build_element_attributes, closing tag or XHTML self-closing for void elements.

Namespaces are determined for children, and `pre`/`textarea` force whitespace preservation. `script`/`style` with a single text child emit the raw text verbatim and return early, skipping dev instrumentation and children processing. In dev, `$.push_element`/`$.pop_element` statements bracket the element with source location. Special `<select value=...>` handling: with spread attributes it assigns `$$payload.select_value` from a spread-object's `value`; with a plain Attribute or BindDirective named `value` it assigns the visited value (bind directives with sequence expressions visit the first expression as a getter call). A valueless `<option>` renders children into a thunk passed to `$.valueless_option`. When build_element_attributes returned a body expression (textarea value or contenteditable binding), children render into a `if (body) ... else ...` selecting between body content and normal children, hoisting non-identifier body expressions into a const. Otherwise children render inline. If a select value was set, `$$payload.select_value` is reset to void 0 afterward.

calls: [build_element_attributes](r3-server-transform.md#u-50884bbfafdd), [build_spread_object](r3-server-transform.md#u-3629ffc7b235), [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/utils.js:build_attribute_value](r2-server-transform.md#u-8ce176223a22), [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/utils.js:process_children (2)](r2-server-transform.md#u-21d2acc05779), [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/utils.js:build_template](r2-server-transform.md#u-303aa62127d6), [clean_nodes](r2-client-transform.md#u-2ed26069223c), [determine_namespace_for_children](r2-client-transform.md#u-fca641f4927b), [utils-js-predicates](r3-shared-utils.md#u-7eb274f609ad)

**Uncertainties.**

- The semantics of build_element_attributes' return value (null vs body expression) are defined in shared/element.js.
- The exact behavior of $$payload.select_value at render time is a runtime concern not visible here.

<a id="u-b758ea3e0e3a"></a>
### `build_attr_class`

`function build_attr_class(class_directives, expression, context, hash)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/element.js:L424-L451][f6]

Builds the expression for a dynamic class attribute.

Class directives become an object mapping directive names to their visited expressions, passed as the directives argument. When a css hash is given and the expression is a string literal, the hash is appended and trimmed into the literal itself; otherwise the hash becomes a separate literal argument. Returns $.attr_class(expression, css_hash, directives).

<a id="u-9bfb6c1f061d"></a>
### `build_attr_style`

`function build_attr_style(style_directives, expression, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/element.js:L459-L494][f6]

Builds the expression for a dynamic style attribute.

Style directives become properties (value true yields the name identifier, otherwise build_attribute_value); names are lowercased unless they start with '--'. Directives with the 'important' modifier are split into a second object, so the directives argument is a [normal, important] array when any important directives exist, otherwise a single object of normal properties, or undefined when there are no directives. Returns $.attr_style(expression, directives).

<a id="u-50884bbfafdd"></a>
### `build_element_attributes`

`export function build_element_attributes(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/element.js:L33-L310][f6]

Transforms a regular or svelte element's attributes into template output and returns a content expression for bindings rendered as element children.

Per Attribute: 'value' on textarea becomes escaped content, prepending a newline when the text starts with one (HTML element restrictions); 'value' on select is dropped; other 'value' attributes are kept. Event attributes are skipped, but onload/onerror on is_load_error_element names are recorded for capture. defaultValue/defaultChecked are dropped; class is wrapped in $.clsx when metadata.needs_clsx. BindDirectives: value on select, value on file inputs, 'this', and bindings with omit_in_ssr are skipped; a visited SequenceExpression collapses to a call of its first expression; contenteditable bindings and textarea value become the returned content (textarea escaped); a non-sequence 'group' binding emits a synthetic checked attribute — a b.includes call for checkbox type, otherwise a strict-equality against the element's value attribute — skipped if no value attribute exists; other bindings become synthetic attributes. SpreadAttribute marks has_spread and on load/error elements captures both events; UseDirective likewise triggers capture; ClassDirective/StyleDirective are collected; LetDirective is ignored; anything else is visited. With a spread, build_element_spread_attributes emits $.spread_attributes, and option elements emit $.maybe_selected reading value from a rebuilt spread object. Without a spread: literal or text attributes with no conflicting class/style directives are inlined as string literals — boolean attributes with true value render as the bare name, class gets the scoped css hash appended, and empty class values are omitted; option/value additionally emits $.maybe_selected. Dynamic values: string literals are pre-escaped inline with escape_html; class uses build_attr_class, style uses build_attr_style, others use $.attr. Finally each captured event emits a literal ` name="this.__e=event"`.

calls: [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/element.js:get_attribute_name](r3-server-transform.md#u-5ee6cbf26623), [build_element_spread_attributes](r3-server-transform.md#u-f66dce05e822), [build_spread_object](r3-server-transform.md#u-3629ffc7b235), [build_attr_class](r3-server-transform.md#u-b758ea3e0e3a), [build_attr_style](r3-server-transform.md#u-9bfb6c1f061d), [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/utils.js:build_attribute_value](r2-server-transform.md#u-8ce176223a22)

**Uncertainties.**

- Runtime semantics of $.escape, $.clsx, $.attr, $.maybe_selected etc. live in the server runtime, outside this source scope

<a id="u-f66dce05e822"></a>
### `build_element_spread_attributes`

`function build_element_spread_attributes( element, attributes, style_directives, clas…` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/element.js:L364-L415][f6]

Emits a single $.spread_attributes call for elements that contain a spread.

Class directives become an object of name-to-expression properties (shorthand identifier when the expression is an identifier matching the directive name); style directives become an object using the directive's own name as key with build_attribute_value values (directive.value === true yields the name identifier). Namespace flags: svg or mathml set both ELEMENT_IS_NAMESPACED and ELEMENT_PRESERVE_ATTRIBUTE_CASE; a custom element sets only ELEMENT_PRESERVE_ATTRIBUTE_CASE. The css hash is a literal when the element is scoped and a hash exists, otherwise null. The call receives the built spread object, css hash, classes, styles, and the flags literal only when nonzero.

calls: [build_spread_object](r3-server-transform.md#u-3629ffc7b235)

<a id="u-3629ffc7b235"></a>
### `build_spread_object`

`export function build_spread_object(element, attributes, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/element.js:L331-L354][f6]

Builds an object expression representing the element's attributes for spread serialization.

Attribute entries become init properties using get_attribute_name and build_attribute_value (whitespace-insensitive for class/style); BindDirective entries become properties whose value is a call of the first expression for SequenceExpressions, otherwise the visited expression; any other attribute type (e.g. SpreadAttribute) becomes a spread of its visited expression.

**Uncertainties.**

- Whether attributes other than the three listed types can reach the spread branch depends on callers

<a id="u-5ee6cbf26623"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/element.js:get_attribute_name`

`function get_attribute_name(element, attribute)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/element.js:L316-L324][f6]

Returns the output attribute name: lowercased for elements that are neither svg nor mathml; case preserved for svg/mathml elements.

Boolean-attribute aliases are deliberately not resolved here since the server runtime only checks lowercase variants.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/Component.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/DebugTag.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/Identifier.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/LabeledStatement.js
[f5]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/RegularElement.js
[f6]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/element.js
