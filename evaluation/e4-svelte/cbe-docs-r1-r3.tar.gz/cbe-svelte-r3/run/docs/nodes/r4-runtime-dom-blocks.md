# Runtime DOM Blocks

**Capability.** Client-side implementations of block constructs: {@html} insertion with hydration hash checks, dynamic svelte:component swapping, svelte:head coordination, and CSS custom-property application, all layered on block/branch/render effects.

Use this subtree to see how compiled block constructs behave at runtime, including hydration edge cases. Each block wraps effect machinery from the effect-system subtree.

**Depends on.**

- [Effect System](r4-runtime-effects.md) · graph-confirmed · 11 edge(s)
- [DOM Operations & Elements](r5-client-dom.md) · graph-only · 12 edge(s)
- [Client Hydration State](r3-client-hydration.md) · graph-only · 9 edge(s)

Parent: [Svelte Compiler and Runtime](r4-svelte-monorepo.md)

## Units (7)

<a id="u-c71adbe36cde"></a>
### `css_props`

`export function css_props(element, get_styles)` · [packages/svelte/src/internal/client/dom/blocks/css-props.js:L11-L29][f1]

Applies dynamic CSS custom properties to an element via a render effect.

During hydration it advances the hydrate node to the element's first child before anything else, so hydration resumes after the placeholder. The render effect reads get_styles and, for each key, sets the property when the value is truthy and removes it otherwise, so falsy values clear previously set properties.

calls: [set_hydrate_node](r3-client-hydration.md#u-053b251d50dd), [render_effect](r4-runtime-effects.md#u-bbe822faa096)

<a id="u-1df4a5c06d12"></a>
### `check_hash`

`function check_hash(element, server_hash, value)` · [packages/svelte/src/internal/client/dom/blocks/html.js:L20-L34][f2]

During hydration in dev, verifies a server-rendered {@html} block against its hash comment and warns on mismatch.

It returns silently when there is no server hash or the hash matches hash(String(value ?? '')). On mismatch it builds a location string from the element's __svelte_meta.loc (file:line:column), or from the current dev component's FILENAME if no metadata exists, and emits hydration_html_changed with a sanitized location (which may be undefined if neither source is available).

**Notes.**

- failure: A hash mismatch only produces a warning; hydration is not aborted.

calls: [hash](r3-shared-utils.md#u-a8a8fa6d6333), [utils-js-predicates](r3-shared-utils.md#u-7eb274f609ad); uses: [packages/svelte/src/internal/client/context.js][f3]

<a id="u-72a5d8905202"></a>
### `html`

`export function html(node, get_value, svg = false, mathml = false, skip_warning = false)` · [packages/svelte/src/internal/client/dom/blocks/html.js:L44-L119][f2]

Implements the {@html} block: renders a string as raw DOM inside a template effect keyed on the previous value.

When the value is unchanged it only advances hydration (hydrate_next) and returns. When it changes, it first removes previously rendered nodes from the active effect's node range and resets nodes_start/nodes_end; an empty new value then ends without rendering. During hydration it walks sibling nodes from the hydration position until an empty-data comment terminator is found; if the terminator is missing it warns hydration_mismatch and throws HYDRATION_ERROR, and in dev (unless skip_warning) checks the server hash via check_hash. Otherwise it parses the value as HTML — wrapping in <svg> or <math> when those flags are set — creates a fragment via create_fragment_from_html (so script tags are never executed, matching innerHTML semantics), assigns the fragment's first and last child as the effect's node range, and inserts the nodes before the anchor, moving children individually for svg/mathml.

**Notes.**

- side_effect: Mutates the active effect's nodes_start/nodes_end to track the rendered range for later removal.
- failure: Missing hydration terminator comment throws HYDRATION_ERROR after warning hydration_mismatch.

calls: [check_hash](r4-runtime-dom-blocks.md#u-1df4a5c06d12), [create_fragment_from_html](r1-dom-blocks.md#u-f51e86a3ef3c), [assign_nodes](r3-client-template.md#u-081194bea535), [remove_effect_dom](r4-runtime-effects.md#u-92a1603726c9), [hydration-js-state](r3-client-hydration.md#u-c504e0cdf2f3), [template_effect](r4-runtime-effects.md#u-5f7f1fcbe917)

**Uncertainties.**

- check_hash reads the hash comment's data from hydrate_node before hydrate_next; whether that is always the hash comment for valid server output is not verifiable here.

<a id="u-cf4f655ef743"></a>
### `component`

`export function component(node, get_component, render_fn)` · [packages/svelte/src/internal/client/dom/blocks/svelte-component.js:L17-L36][f4]

Implements dynamic <svelte:component>: a transparent block effect that swaps the rendered component when get_component returns a different value (reference comparison, so the initial undefined to component transition renders it).

During hydration it advances past the anchor and afterwards repositions the anchor to hydrate_node. When the component changes, a new branch runs render_fn with the anchor and component. When appends are deferred, the branch renders into an offscreen fragment with a text anchor, the currently mounted effect is added to current_batch.skipped_effects so it is not torn down by the batch, and commit is scheduled via a batch callback; otherwise commit runs immediately. commit pauses the old effect, removes the fragment's text anchor, inserts the fragment before the real anchor, and promotes pending_effect to the current effect.

**Notes.**

- condition: When get_component returns a falsy value, no pending effect is created and commit only pauses/removes the old content.

calls: [packages/svelte/src/internal/client/reactivity/effects.js:block](r4-runtime-effects.md#u-75d755e7c63c), [branch](r4-runtime-effects.md#u-cfe4a1f5ddba), [pause_effect](r4-runtime-effects.md#u-340d218bcd6f), [should_defer_append](r5-client-dom.md#u-46ab51c8fe62), [operations-js-node-lookups](r5-client-dom.md#u-07b45637bc3d), [hydration-js-state](r3-client-hydration.md#u-c504e0cdf2f3); uses: [packages/svelte/src/internal/client/reactivity/batch.js][f5]

<a id="u-917be05a6f13"></a>
### `head`

`export function head(render_fn)` · [packages/svelte/src/internal/client/dom/blocks/svelte-head.js:L21-L68][f6]

Implements <svelte:head>: runs render_fn inside a HEAD_EFFECT block targeting document.head, coordinating hydration state across multiple head blocks via the shared module-level head_anchor.

During hydration it saves the current hydrate node, scans from head_anchor (initialized to head's first child) for a HYDRATION_START comment, and either disables hydration when no marker exists (framework rendered a body without head content) or advances hydration to the node after the marker. Outside hydration it appends a fresh text anchor to document.head. The block effect runs in a try/finally: if hydration was active, the finally restores hydrating mode, sets head_anchor to the current hydrate node so the next head block starts after this one, and restores the previous hydrate node, so nested or sequential head blocks hydrate independently and render_fn exceptions still restore hydration state.

**Notes.**

- failure: Errors thrown by render_fn propagate after the finally restores hydration state; head_anchor is still updated to the post-block node.

calls: [packages/svelte/src/internal/client/reactivity/effects.js:block](r4-runtime-effects.md#u-75d755e7c63c), [set_hydrate_node](r3-client-hydration.md#u-053b251d50dd), [hydration-js-state](r3-client-hydration.md#u-c504e0cdf2f3)

<a id="u-484aa5d18aec"></a>
### `reset_head_anchor`

`export function reset_head_anchor()` · [packages/svelte/src/internal/client/dom/blocks/svelte-head.js:L13-L15][f6]

Clears the module-level head_anchor so subsequent head blocks re-scan document.head for the hydration marker; called by hydrate to reset state between hydration passes.

<a id="u-89b96e9f81b2"></a>
### `attach`

`export function attach(node, get_fn)` · [packages/svelte/src/internal/client/dom/elements/attachments.js:L12-L33][f7]

Attaches a dynamically chosen attachment function to a DOM node inside a block/branch structure.

A block re-runs whenever get_fn returns a different function than before (compared by reference against the previous value, starting from undefined); on each change it destroys the previous effect, and if the new fn is truthy, creates a branch containing an effect that calls fn(node). Re-running the effect re-invokes the attachment, so attachments can re-execute. A falsy fn tears down without installing a new one. The block/branch nesting exists to support legacy-mode teardown semantics.

calls: [packages/svelte/src/internal/client/reactivity/effects.js:block](r4-runtime-effects.md#u-75d755e7c63c), [branch](r4-runtime-effects.md#u-cfe4a1f5ddba), [destroy_effect](r4-runtime-effects.md#u-214ad59ce57a), [effect](r4-runtime-effects.md#u-68382c2a31f5)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/blocks/css-props.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/blocks/html.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/context.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/blocks/svelte-component.js
[f5]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/reactivity/batch.js
[f6]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/blocks/svelte-head.js
[f7]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/elements/attachments.js
