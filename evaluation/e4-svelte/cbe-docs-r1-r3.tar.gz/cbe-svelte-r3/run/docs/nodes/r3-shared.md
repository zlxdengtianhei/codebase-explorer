# Shared Utilities and Public Contracts

**Capability.** Cross-cutting, consumer-agnostic code: pure lookup/string helpers, hashing, easing functions, runtime mode flags, and the TypeScript contracts for actions and animations.

Nothing here knows about compilation or rendering internals. Consumers across compiler and runtime import these; the public d.ts units declare types consumed by user code.

**Children.**

- [Shared Predicates and Hash](r3-shared-utils.md) `r3-shared-utils` · 2 unit(s)
- [Public Animation and Action Contracts](r3-public-animation-and-actions.md) `r3-public-animation-and-actions` · 4 unit(s)
- [Easing Functions](r3-shared-easing.md) `r3-shared-easing` · 1 unit(s)
- [Runtime Mode Flags](r3-runtime-mode-flags.md) `r3-runtime-mode-flags` · 4 unit(s)

**Depended on by.**

- [Reactivity Benchmarks](r3-benchmarks.md) · model-inferred · 0 edge(s)

Parent: [Svelte Compiler and Runtime](r3-svelte.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
