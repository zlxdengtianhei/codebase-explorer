# Runtime Mode Flags

**Capability.** Module-level mutable flags (async, legacy, tracing) with enable/disable functions that switch internal runtime behavior wherever the flags are read.

Test and internal setup code toggles these flags; the docstrings restrict some to testing, which is stated but not verified at runtime here.

Parent: [Shared Utilities and Public Contracts](r3-shared.md)

## Units (4)

<a id="u-8e5eb2967954"></a>
### `enable_async_mode_flag`

`export function enable_async_mode_flag()` · [packages/svelte/src/internal/flags/index.js:L5-L7][f1]

Sets the module-level mutable async_mode_flag to true, switching internal runtime behavior wherever that export is read.

Mutates shared module state; no other effects.

<a id="u-2c7340b211d4"></a>
### `disable_async_mode_flag`

`export function disable_async_mode_flag()` · [packages/svelte/src/internal/flags/index.js:L10-L12][f1]

Resets async_mode_flag to false; its docstring restricts use to testing.

Mutates the same shared module state as the enable counterpart.

<a id="u-0c177e01fbd2"></a>
### `enable_legacy_mode_flag`

`export function enable_legacy_mode_flag()` · [packages/svelte/src/internal/flags/index.js:L14-L16][f1]

Sets legacy_mode_flag to true, enabling legacy compatibility paths in the runtime that read this export.

<a id="u-76b26958c1d1"></a>
### `enable_tracing_mode_flag`

`export function enable_tracing_mode_flag()` · [packages/svelte/src/internal/flags/index.js:L18-L20][f1]

Sets tracing_mode_flag to true, enabling tracing instrumentation wherever the flag is consulted.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/flags/index.js
