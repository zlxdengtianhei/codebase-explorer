# Compiler State & AST Utilities

**Capability.** Module-scoped compiler state (warnings, filename, ignore stack, locator) plus pure ESTree node factories and assertion helpers that all compiler phases use to build and locate AST nodes.

Use when compiler code needs to build nodes, emit located diagnostics, or respect svelte-ignore scoping. builders.js is side-effect-free node construction; state.js is per-compilation mutable state; types.d.ts documents the analysis-phase shapes.

**Depended on by.**

- [Template Parsing](r5-compiler-parse.md) · graph-confirmed · 1 edge(s)
- [Source Maps & Preprocessing](r5-compiler-sourcemaps.md) · model-inferred · 0 edge(s)
- [Client Codegen Visitors](r5-transform-client.md) · graph-confirmed · 4 edge(s)
- [Server Codegen Visitors](r5-transform-server.md) · graph-confirmed · 1 edge(s)

Parent: [Compiler Pipeline](r5-compiler.md)

## Units (16)

<a id="u-f0ea3a9aa39d"></a>
### `builders-js-node-factories`

`export function array(elements = [])` · [packages/svelte/src/compiler/utils/builders.js:L10-L12][f1]

Factory helpers that construct plain ESTree node objects for code generation; each returns a fresh literal object with no side effects.

Object shapes follow the standard AST: `array`, `array_pattern`, `assignment_pattern`, `binary`, `block`, `conditional`, `logical`, `declaration` (kind + declarators), `export_default`, `for_of` (with optional await flag), `function_declaration`, `unary` (prefix true), `update`, `do_while`, `sequence`, `spread`, `rest`, `stmt`, `template`, `object`, `object_pattern`, `prop` (method/shorthand false, computed default false), `prop_def`, `method`, `prop_def`-style class members, and the re-exported aliases `await`, `let`/`const`/`var` (single declarator declarations), `for`, `if`, `return` (argument defaults to null), `function`, plus shared constant nodes `true`/`false`/`null`/`this`/`debugger`. Convenience coercions: `id` and `private_id` build named nodes from strings; `declarator` and `member` accept a string and convert via `id`; `assignment` pairs an operator with left/right; `arrow` sets `expression: body.type !== 'BlockStatement'` and nulls `metadata` (explicitly not for codegen); `literal` passes the value straight through (bigint excluded by cast); `void0` is a prebuilt `void 0`; `init`, `get`, `set` build object properties, where `set` gives the accessor a `$$value` parameter and both wrap statements in a block via `function_builder`; `import_namespace` (private) builds a namespace specifier used by `import_all`; `imports` builds an ImportDeclaration from `[imported, local]` pairs. `key` chooses an Identifier for valid identifier names and a Literal otherwise, using `regex_is_valid_identifier`.

**Uncertainties.**

- Whether `arrow`/`function_declaration`/`function_builder` metadata being null is safe for all downstream consumers is asserted only by comments

<a id="u-eb7317ff07c1"></a>
### `types-d-ts`

`export interface Js` · [packages/svelte/src/compiler/phases/types.d.ts:L12-L17][f2]

Type-only analysis shapes for the compiler phases, with no runtime code.

`Js` carries the parsed ESTree `Program`, its `Scope`, a node-to-scope map, and `has_await`. `Template` carries the AST fragment plus scope data. `ReactiveStatement` holds assigned bindings (Set) and dependency bindings (array). `Analysis` is shared by modules and components (module `Js`, deprecated `name`/`runes`, `immutable`, `tracing`, comments, class state fields, `accessors`, and a set of deriveds containing await expressions); `ComponentAnalysis` extends it with the instance/template JS, root scope, collected elements for CSS pruning, runes flags, export/prop/restProps/slots usage flags, event directive info, `custom_element` option content, style injection, reactive statement and bind:group maps, slot names, CSS ast/hash/keyframes, deprecated `source`, and snippet/render-tag tracking. The `declare module 'estree'` block augments arrow/function expressions and declarations with `metadata` (`hoisted`, `hoisted_params`, `scope`).

imports: [./scope.js](../../catalog.json), [estree](../../catalog.json)

<a id="u-f5d17409beb9"></a>
### `state.js module code (L1–L45)`

`module_region` · [packages/svelte/src/compiler/state.js:L1-L45][f3]

Module-level compiler state: warnings list, filename, UNKNOWN_FILENAME constant, component_name, source string, dev and runes flags, and a locator built with getLocator.

These are mutable exports shared across a compilation.

**Notes.**

- side_effect: All state is module-global mutable state; concurrency across compilations is not addressed in this file.

<a id="u-cdd07af3c7f6"></a>
### `set_source`

`export function set_source(value)` · [packages/svelte/src/compiler/state.js:L46-L49][f3]

Store the source string and rebuild the locator from it with offsetLine 1, so subsequent locate_node calls map character offsets to line/column positions of this source.

<a id="u-b35212eb6968"></a>
### `locate_node`

`export function locate_node(node)` · [packages/svelte/src/compiler/state.js:L54-L57][f3]

Return a human-readable location string for a node's start offset: the sanitized filename, then line and column from the current locator (built with offsetLine 1).

Relies on locator having been created for the active source via set_source or reset; if the locator yields nothing, line/column render as undefined.

calls: [utils-js-predicates](r3-shared-utils.md#u-7eb274f609ad)

**Uncertainties.**

- Output when locator returns undefined (e.g. after reset) is a string containing 'undefined'; not guarded

<a id="u-a26d5dd25c33"></a>
### `push_ignore`

`export function push_ignore(ignores)` · [packages/svelte/src/compiler/state.js:L79-L82][f3]

Push a new ignore set onto the stack, seeded with all codes from the current top set (or none if empty) plus the given ignores, so ignoring is scoped hierarchically.

<a id="u-43922869e1b9"></a>
### `pop_ignore`

`export function pop_ignore()` · [packages/svelte/src/compiler/state.js:L84-L86][f3]

Pop the top set off the ignore stack, restoring the enclosing ignore scope; pops from an empty stack leave it empty.

<a id="u-468324b42cee"></a>
### `is_ignored`

`export function is_ignored(node, code)` · [packages/svelte/src/compiler/state.js:L93-L95][f3]

Report whether a runtime warning code should be suppressed for a node: only when dev is true and the node has an entry in ignore_map whose list contains a set holding the code.

Outside dev mode it always returns false.

<a id="u-0d9f0b886c2d"></a>
### `reset`

`export function reset(state)` · [packages/svelte/src/compiler/state.js:L101-L110][f3]

Reset the compiler state before each compilation: dev and runes to false, component_name to UNKNOWN_FILENAME, source to '', locator to a function returning undefined, filename to the given filename (defaulting to UNKNOWN_FILENAME) with backslashes normalized to forward slashes, warning_filter to the given filter or a pass-through, and warnings to an empty array.

<a id="u-0298dbcfed58"></a>
### `adjust`

`export function adjust(state)` · [packages/svelte/src/compiler/state.js:L122-L136][f3]

Refine the compiler state after parsing and basic analysis.

Sets dev, runes, and component_name (defaulting to UNKNOWN_FILENAME) from the given state; when a rootDir string is present and filename starts with it, filename is rewritten relative to rootDir with any leading slash or backslash stripped. Also clears ignore_stack and ignore_map so per-node ignore data does not leak between phases or compilations.

**Uncertainties.**

- The rootDir replacement uses String.replace, so only the first occurrence is replaced and regex-special characters in rootDir would be interpreted as a pattern

<a id="u-2a153dd9dab6"></a>
### `equal`

`export function equal(actual, expected)` · [packages/svelte/src/compiler/utils/assert.js:L7-L9][f4]

Throws an Error when two values are not strictly equal, acting as a compile-time assertion helper.

Comparison uses `!==`, so no coercion occurs; the JSDoc assertion signature narrows `actual` to `T` after the call for type checking only.

<a id="u-b3e77b1d8760"></a>
### `call`

`export function call(callee, ...args)` · [packages/svelte/src/compiler/utils/builders.js:L99-L124][f1]

Builds a CallExpression, coercing a string callee to an Identifier.

Trailing falsy arguments are popped off; interior falsy arguments are replaced with an `undefined` Identifier, so call arity and argument positions are preserved for holes while avoiding trailing `undefined`s. Scanning runs right-to-left with a `popping` flag that turns off at the first truthy argument. The result has `optional: false`.

<a id="u-7b974afef5ad"></a>
### `key`

`export function key(name)` · [packages/svelte/src/compiler/utils/builders.js:L682-L684][f1]

Chooses an AST key node for a property name: an Identifier when the name matches `regex_is_valid_identifier`, otherwise a string Literal.

<a id="u-ca805d7f76b1"></a>
### `member_id`

`export function member_id(path)` · [packages/svelte/src/compiler/utils/builders.js:L317-L327][f1]

Converts a dotted path string like `a.b.c` into a chained non-computed MemberExpression rooted at an Identifier for the first segment.

**Uncertainties.**

- Segments are never validated as identifiers; invalid names yield Identifier nodes with those names

<a id="u-44404e861756"></a>
### `quasi`

`export function quasi(cooked, tail = false)` · [packages/svelte/src/compiler/utils/builders.js:L374-L377][f1]

Builds a TemplateElement from cooked string content, computing the raw form with `sanitize_template_string` so escapes are preserved correctly; `tail` marks the final element.

calls: [sanitize_template_string](r2-compiler-foundations.md#u-01781e43d6ff)

<a id="u-98dc49f1a7a8"></a>
### `unthunk`

`export function unthunk(expression)` · [packages/svelte/src/compiler/utils/builders.js:L443-L449][f1]

Simplifies arrow functions produced by `thunk`.

If the arrow is async and its body is a single AwaitExpression, it scans the awaited argument for nested awaits; when none exist it recurses on a non-async arrow of the same params returning the awaited expression (so `async () => await x()` collapses to `() => x()`, but `async () => await x(await y)` is kept). Independently, a non-async arrow whose body is a CallExpression with an Identifier callee, whose parameter count matches the argument count, and whose params and arguments are identically named Identifiers pairwise, is replaced by the callee itself (`(arg) => func(arg)` becomes `func`). Otherwise the expression is returned unchanged.

calls: [unthunk](r5-compiler-state-utils.md#u-98dc49f1a7a8)

**Uncertainties.**

- The visitor only stops at top-level AwaitExpressions of the argument walk; deeper nesting semantics rely on zimmerframe's walk order

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/utils/builders.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/types.d.ts
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/state.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/utils/assert.js
