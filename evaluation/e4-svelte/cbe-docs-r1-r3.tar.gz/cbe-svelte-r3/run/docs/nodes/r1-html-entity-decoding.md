# HTML Entity Decoding

**Capability.** Builds the entity decode regex from the entity table and replaces character references in text and attribute values, mapping numeric code points to safe output values.

Consult when decoded text or attribute values look wrong or when adding entity handling. decode_character_references is the entry; the other functions build and validate its inputs.

**Depended on by.**

- [Markup & Attribute Parsing](r1-markup-tag-parsing.md) · graph-confirmed · 2 edge(s)
- [Preprocessing](r1-preprocess.md) · model-inferred · 0 edge(s)

Parent: [Parse Phase](r1-compiler-parse.md)

## Units (4)

<a id="u-a03f13997ae5"></a>
### `decode_character_references`

`export function decode_character_references(html, is_attribute_value)` · [packages/svelte/src/compiler/phases/1-parse/utils/html.js:L40-L66][f1]

Replaces HTML character references in `html` with their literal characters, selecting the content or attribute-value pattern built by get_entity_pattern.

Named entities look up the entities table; '#x...' hex and '#...' decimal forms are parsed with parseInt. If the resolved code point is falsy (0 or lookup miss), the original match text is returned unchanged; otherwise String.fromCodePoint(validate_code(code)) produces the replacement.

calls: [validate_code](r1-html-entity-decoding.md#u-93702e15ee48)

**Uncertainties.**

- The entities table comes from './entities.js', not supplied here, so named-entity coverage is assumed from its keys.

<a id="u-9eba4a60cf55"></a>
### `get_entity_pattern`

`function get_entity_pattern(is_attribute_value)` · [packages/svelte/src/compiler/phases/1-parse/utils/html.js:L22-L31][f1]

Builds the global regex `&(num|entities)` used for character-reference decoding.

Numeric references match `#x hex`, `#decimal`, with an optional ';'; named alternatives come from all keys of the entities table, transformed by reg_exp_entity per the attribute flag. Module-level constants entity_pattern_content and entity_pattern_attr_value cache both variants at load time.

calls: [reg_exp_entity](r1-html-entity-decoding.md#u-f66ddc0a405e)

<a id="u-f66ddc0a405e"></a>
### `reg_exp_entity`

`function reg_exp_entity(entity_name, is_attribute_value)` · [packages/svelte/src/compiler/phases/1-parse/utils/html.js:L12-L19][f1]

Formats one entity name for the decode regex.

In attribute values, per the WHATWG named-character-reference state, a named entity lacking a trailing ';' must not decode when followed by '=', a digit, or a letter, so it becomes `name\b(?!=)`; otherwise the name is returned as-is.

<a id="u-93702e15ee48"></a>
### `validate_code`

`function validate_code(code)` · [packages/svelte/src/compiler/phases/1-parse/utils/html.js:L79-L127][f1]

Maps numeric character-reference code points to safe output values.

Line feed (10) becomes space (32); code points under 128 pass through; 128–159 are reinterpreted through the windows_1252 table so entities like &euro; survive; BMP code points below 55296 and up to 65535 pass through; UTF-16 surrogate halves (55296–57343) become NUL (0); supplementary planes 0x10000–0x1ffff, 0x20000–0x2ffff, and the special-purpose ranges 0xe0000–0xe07f and 0xe0100–0xe01ef pass through; all other code points return NUL (0), which the caller treats as an unmatched reference.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/1-parse/utils/html.js
