# DOM Operations & Elements

**Capability.** Template construction and traversal primitives: element/fragment factories, hydration-aware child/sibling navigation, deferred branch insertion, environment-safe global capture, plus class application and action lifecycle management.

Use when changing how compiled templates create and move DOM. operations.js helpers are the low-level vocabulary used by blocks (including boundary's move_effect); actions.js and class.js implement use: directives and class handling.

**Depends on.**

- [Dev-Mode Diagnostics](r5-client-dev.md) · graph-confirmed · 1 edge(s)
- [Signal Reactivity Core](r5-client-reactivity.md) · graph-confirmed · 1 edge(s)

**Depended on by.**

- [Error & Pending Boundaries](r5-client-boundary.md) · graph-confirmed · 1 edge(s)
- [Custom Element Hosting](r5-client-custom-elements.md) · model-inferred · 0 edge(s)
- [Client Template Factories](r3-client-template.md) · graph-only · 17 edge(s)
- [Runtime DOM Blocks](r4-runtime-dom-blocks.md) · graph-only · 12 edge(s)

Parent: [Client Runtime](r5-runtime-client.md)

## Units (9)

<a id="u-3edbb11427a1"></a>
### `operations-js-node-factories`

`export function create_element(tag, namespace, is)` · [packages/svelte/src/internal/client/dom/operations.js:L231-L237][f1]

Element and fragment construction helpers.

create_element creates an element via createElementNS when a namespace is given (passing an {is} option when `is` is supplied) or createElement otherwise. create_fragment returns an empty DocumentFragment, create_comment an empty-by-default comment node. set_attribute sets an attribute, routing keys starting with 'xlink:' through setAttributeNS with the XLink namespace; a default-empty value is applied when the value argument is omitted.

<a id="u-07b45637bc3d"></a>
### `operations-js-node-lookups`

`export function get_first_child(node)` · [packages/svelte/src/internal/client/dom/operations.js:L89-L91][f1]

Thin DOM access and construction helpers.

get_first_child and get_next_sibling invoke the Node.prototype getter references captured by init_operations, avoiding dynamic property lookups; they return Node or null and are marked side-effect-free for compiler optimizations. create_text creates a DOM text node (empty by default). clear_text_content empties a node's textContent. These helpers assume init_operations has run; otherwise the getter variables are undefined.

**Uncertainties.**

- Behavior before init_operations has populated the getter bindings is not guarded here.

<a id="u-eb7a9f0e7810"></a>
### `init_operations`

`export function init_operations()` · [packages/svelte/src/internal/client/dom/operations.js:L30-L73][f1]

Lazily captures window/document globals and DOM prototype accessors so the runtime works in server contexts where these are absent.

Idempotent: returns early if `$window` is already set. Records the Node.prototype firstChild/nextSibling getters used by the lookup helpers, detects Firefox via userAgent, and — when the prototypes are extensible — pre-defines hidden per-element fields (__click, __className, __attributes, __style, __e, and __t on Text) to speed later writes. In DEV it also initializes __svelte_meta and turns on Array prototype mutation warnings.

calls: [init_operations](r5-client-dom.md#u-eb7a9f0e7810)

**Uncertainties.**

- The exact behavior of init_array_prototype_warnings lives in dev/equality.js and is not shown here.

<a id="u-156555a05481"></a>
### `child`

`export function child(node, is_text)` · [packages/svelte/src/internal/client/dom/operations.js:L110-L129][f1]

Moves to the first child of `node`, reconciling with server HTML while hydrating.

When not hydrating it simply returns get_first_child(node). While hydrating it reads the first child of `hydrate_node`: if null (e.g. an element whose only text expression was empty in SSR) it appends a fresh empty text node; if a text node is expected but the child is not text, it inserts a new empty text node before the child, advances the cursor to it via set_hydrate_node, and returns it. Otherwise it advances the cursor to the child and returns it.

calls: [set_hydrate_node](r3-client-hydration.md#u-053b251d50dd)

<a id="u-7752b6debbf3"></a>
### `first_child`

`export function first_child(fragment, is_text)` · [packages/svelte/src/internal/client/dom/operations.js:L137-L159][f1]

Resolves the first child of a block's fragment or node list, with hydration-aware behavior.

Not hydrating: returns the fragment's first child, skipping an empty-string Comment (used as a placeholder), returning its next sibling instead. Hydrating: if a text node is expected and `hydrate_node` is not a text node (the SSR expression was empty), it creates an empty text node, inserts it before `hydrate_node`, moves the cursor there and returns it; otherwise returns `hydrate_node` unchanged. Deliberately not marked side-effect-free because hydration walks nodes.

**Uncertainties.**

- The non-hydrating input is documented as the result of open_frag; how fragments are produced is outside this file.

<a id="u-dfa8c3eb25d7"></a>
### `sibling`

`export function sibling(node, count = 1, is_text = false)` · [packages/svelte/src/internal/client/dom/operations.js:L168-L199][f1]

Advances `count` siblings (default 1) from the current position.

Not hydrating, it walks from `node` and returns the resulting sibling. Hydrating, it walks from `hydrate_node`, then: if a text node is expected but the reached node is not text (SSR expression was empty), it creates an empty text node — inserting it after the last visited sibling when the walk hit null, otherwise before the reached node — moves the cursor there and returns it. Otherwise it sets the cursor to the reached node and returns it. Casting hides null results from the type system.

calls: [set_hydrate_node](r3-client-hydration.md#u-053b251d50dd)

**Uncertainties.**

- If siblings run out before `count` is exhausted and is_text is false, a null cursor is stored via set_hydrate_node, which would then throw HYDRATION_ERROR — the intended path for short SSR output is inferred, not proven.

<a id="u-46ab51c8fe62"></a>
### `should_defer_append`

`export function should_defer_append()` · [packages/svelte/src/internal/client/dom/operations.js:L216-L222][f1]

Reports whether block branch insertion/removal should be deferred to batch with other updates in the current <svelte:boundary>.

False when the async-mode flag is off, false when `eager_block_effects` is non-null, and otherwise true only if the active effect's flags include EFFECT_RAN — i.e. the effect has already run, indicating an in-place update like a changed {#if} condition.

**Uncertainties.**

- Semantics of eager_block_effects and EFFECT_RAN are defined in reactivity/batch.js and constants, not shown here.

<a id="u-085f1a439acb"></a>
### `set_class`

`export function set_class(dom, is_html, value, hash, prev_classes, next_classes)` · [packages/svelte/src/internal/client/dom/elements/class.js:L13-L51][f2]

Applies a class value plus optional scoped-CSS hash and class-directive maps to an element.

It tracks the raw value in dom.__className. When hydrating, the tracked value differs, or it is undefined, it computes the full class name with to_class(value, hash, next_classes); during hydration it only writes if that differs from the server-rendered class attribute. A nullish result removes the class attribute (empty strings are kept as className for performance); HTML elements get dom.className, others setAttribute. Otherwise, when only the directive map changed, it toggles each key in next_classes via classList only when its presence differs from prev_classes. Returns next_classes. During hydration the directive-toggle branch never runs because the first condition holds.

calls: [to_class](r2-svelte-codebase.md#u-bb0adfe2b192)

**Uncertainties.**

- Exact semantics of to_class (hash and directive-map combination) live in shared/attributes.js, not supplied

<a id="u-e8c39de2a586"></a>
### `action`

`export function action(dom, action, get_value)` · [packages/svelte/src/internal/client/dom/elements/actions.js:L13-L43][f3]

Runs a Svelte action on an element inside an effect and manages its optional update and destroy lifecycle.

The action itself runs untracked, so it never captures reactive reads at init; a falsy return becomes {} so payload?.update/destroy checks fail safely. If a value getter was supplied and the payload exposes update, a nested render effect tracks the getter: on each run it deep-reads the value (so $state mutations are noticed), and after the first run calls payload.update only when safe_not_equal says the value changed from prev; the first run never calls update because prev is initialized to a fresh object that never compares equal. If the payload exposes destroy, the outer effect returns a teardown calling destroy when the effect is destroyed.

**Notes.**

- side_effect: destroy runs only via the outer effect's teardown, not on update.

calls: [effect](r4-runtime-effects.md#u-68382c2a31f5), [runtime-js-state-and-helpers](r2-reactivity-core.md#u-6cd2387802ec), [render_effect](r4-runtime-effects.md#u-bbe822faa096), [safe_not_equal](r5-client-reactivity.md#u-3775acbc409e), [deep_read_state](r2-reactivity-core.md#u-031649ca68f4)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/operations.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/elements/class.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/elements/actions.js
