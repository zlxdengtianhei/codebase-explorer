# Signals, Deriveds, and Proxies

**Capability.** State-holding reactive primitives: synchronous derived signal creation and evaluation with effect-management for nested effects, async deriveds fed by async effects, animation-frame loop tasks, and $state proxies whose per-property signals make template reads/writes tracked.

deriveds.js owns derived evaluation and its effect bookkeeping; proxy.js owns the reactive Proxy wrapper plus unwrapping/equality helpers; loop.js provides the rAF task runner. Dev tracing labels from the runtime-dev subtree attach to these sources.

**Depends on.**

- [Effect System](r4-runtime-effects.md) · graph-confirmed · 2 edge(s)
- [Signal Reactivity Core](r5-client-reactivity.md) · graph-only · 18 edge(s)
- [Reactivity Core & Batching](r2-reactivity-core.md) · graph-only · 16 edge(s)
- [Runtime Dev-Mode Instrumentation](r4-runtime-dev.md) · graph-only · 10 edge(s)

**Depended on by.**

- [Runtime Dev-Mode Instrumentation](r4-runtime-dev.md) · model-inferred · 0 edge(s)
- [Element Bindings and Behaviors](r4-runtime-element-bindings.md) · model-inferred · 0 edge(s)
- [Legacy Public API](r4-runtime-legacy.md) · model-inferred · 0 edge(s)

Parent: [Svelte Compiler and Runtime](r4-svelte-monorepo.md)

## Units (13)

<a id="u-0dbfaaba8bef"></a>
### `deriveds-async-derived`

`export function async_derived(fn, location)` · [packages/svelte/src/internal/client/reactivity/deriveds.js:L100-L132][f1]

Creates an async derived: a source signal fed by an async_effect that repeatedly calls fn, tracks its promise, and pushes resolved values or errors into the source via internal_set.

Requires an active effect (throws async_derived_orphan otherwise); boundary is taken from parent.b. The effect body converts a synchronous fn throw into a rejected promise, chains each new promise onto the previous one so only the latest value wins, and manages suspension only when created outside a reaction (should_suspend): it bumps boundary pending count and batch increment, and in the handler decrements them again, batch.activate() when no boundary pending, and unset_context(). The handler sets ERROR_VALUE and stores the error on the signal for non-STALE_REACTION failures, clears ERROR_VALUE and stores the value on success, and in dev with a location warns about await waterfalls via a timeout on recent_async_deriveds. The effect teardown queues a microtask that neuters the batch. The returned promise resolves with the source signal once the promise that is current at resolution time settles; if the effect re-ran before the initial promise resolved, next() re-chains onto the newer promise. In dev the source gets the ASYNC flag so $inspect.trace can print it as a derived.

**Notes.**

- failure: Rejection handler normalizes falsy errors to the string 'unknown' before invoking handler.
- side_effect: If prev exists, Promise.resolve(p).catch(() => {}) suppresses unhandled rejections of superseded promises.

calls: [async_effect](r4-runtime-effects.md#u-82596e20cef8), [boundary-js-boundary-class](r5-client-boundary.md#u-4e4a6d345016), [source](r5-client-reactivity.md#u-97497b70f31b), [internal_set](r5-client-reactivity.md#u-0dae6a8d64cd), [Batch](r2-reactivity-core.md#u-43c969fbb82e), [unset_context](r1-async-reactivity.md#u-2e39d8f937d3); uses: [flatten](r1-async-reactivity.md#u-c50793421b66)

**Uncertainties.**

- Exact effect of batch.neuter/activate/decrement on scheduling is defined in batch.js, not visible here.
- The meaning of STALE_REACTION error skipping depends on runtime constants outside this file.

<a id="u-1dbd358a460d"></a>
### `deriveds-derived-factories`

`export function user_derived(fn)` · [packages/svelte/src/internal/client/reactivity/deriveds.js:L231-L237][f1]

Two thin wrappers over derived for user-facing variants.

user_derived creates a derived and registers it as a pushed reaction value (used for dev-time value tracking) before returning it. derived_safe_equal creates a derived and swaps its equals to safe_equals, so re-evaluation that produces an equal value does not count as a change.

calls: [derived](r4-runtime-signals.md#u-d386336ed5eb)

<a id="u-d386336ed5eb"></a>
### `derived`

`export function derived(fn)` · [packages/svelte/src/internal/client/reactivity/deriveds.js:L55-L91][f1]

Creates the plain derived signal object for a synchronous computation, without evaluating fn.

Flag setup: DERIVED|DIRTY always; if there is no active effect, or the parent is an UNOWNED derived, UNOWNED is added; otherwise the active effect gets EFFECT_PRESERVED so effects created lazily inside the derived keep the parent in the tree. parent is the enclosing derived if active_reaction is a derived, else the active effect; ctx captures component_context, equals defaults to reference equality, and v starts as UNINITIALIZED. In dev tracing mode it attaches a CreatedAt stack. Uncertainty: the flags interplay with runtime scheduling lives outside this file.

calls: [get_stack](r4-runtime-dev.md#u-507749353e33); uses: [props.js-prop](r3-client-props.md#u-2e500006b90d)

**Uncertainties.**

- Whether EFFECT_PRESERVED on active_effect is ever cleared is decided elsewhere.

<a id="u-a30c1fdac161"></a>
### `destroy_derived_effects`

`export function destroy_derived_effects(derived)` · [packages/svelte/src/internal/client/reactivity/deriveds.js:L255-L265][f1]

Destroys all effects created during a derived's previous evaluation.

If derived.effects is non-null it nulls the array first (preventing re-entrant destruction) and calls destroy_effect on each element; a null list is a no-op.

calls: [destroy_effect](r4-runtime-effects.md#u-214ad59ce57a)

<a id="u-193107029d03"></a>
### `execute_derived`

`export function execute_derived(derived)` · [packages/svelte/src/internal/client/reactivity/deriveds.js:L294-L327][f1]

Re-runs a derived's function and returns its new value, walking up the parent chain (get_derived_parent_effect) to the nearest non-derived ancestor and temporarily making that the active effect so nested effects attach to a real parent.

In dev it guards infinite self-recursion: if the derived is already on the module-level stack it throws derived_references_self, otherwise pushes it; a finally block always restores the previous active effect, restores the previous inspect_effects set, and pops the stack. In both modes destroy_derived_effects runs first so effects from the prior run are torn down, then update_reaction computes the value; the value is returned even if a later stage discards it.

calls: [update_reaction](r2-reactivity-core.md#u-f6b808e008e3), [runtime-js-state-and-helpers](r2-reactivity-core.md#u-6cd2387802ec), [destroy_derived_effects](r4-runtime-signals.md#u-a30c1fdac161)

**Uncertainties.**

- get_derived_parent_effect returning null (no non-derived ancestor) means set_active_effect(null); downstream behavior of a null active effect is defined in runtime.js.

<a id="u-7529e3342efc"></a>
### `set_from_async_derived`

`export function set_from_async_derived(v)` · [packages/svelte/src/internal/client/reactivity/deriveds.js:L43-L45][f1]

Stores the currently running async-derived effect in module state for dev-mode attribution.

It simply assigns the argument (or null) to the exported current_async_effect variable; no validation, no return value.

<a id="u-637b94af51bf"></a>
### `update_derived`

`export function update_derived(derived)` · [packages/svelte/src/internal/client/reactivity/deriveds.js:L333-L355][f1]

Evaluates a derived via execute_derived and commits the result.

It writes derived.v and bumps the write version only when equals reports a change; when the value is unchanged, cached state is left untouched. If a cleanup function is currently running (is_destroying_effect) it returns without marking clean, avoiding caching a stale value. Otherwise: if batch_deriveds is active it records derived -> v in that map for batch processing; if not, it computes the next status as MAYBE_DIRTY when the derived is unowned (or reactions are being skipped) and has deps, CLEAN otherwise, and applies it via set_signal_status.

calls: [execute_derived](r4-runtime-signals.md#u-193107029d03), [runtime-js-state-and-helpers](r2-reactivity-core.md#u-6cd2387802ec)

<a id="u-100d26a5c84c"></a>
### `proxy.js-proxy`

`export function proxy(value)` · [packages/svelte/src/internal/client/proxy.js:L39-L64][f2]

Wraps plain objects/arrays in a reactive Proxy backing each own property with a lazily created signal source, so template reads and writes are tracked and triggered.

Non-object, null, already-proxied (STATE_SYMBOL present), or exotic-prototype values pass through unchanged. Every method routes work through with_parent, which temporarily restores the proxy's creation-time reaction and update version when a source is created later, preventing association with the currently active reaction. The dev path records labels and creation stacks via get_stack/tag when tracing_mode_flag is on. defineProperty rejects non-basic descriptors (missing value, or non-configurable/enumerable/writable) with state_descriptors_fixed, then creates or sets the source. deleteProperty sets the source to UNINITIALIZED (creating one if the prop exists only on the target) and increments the version. get returns the raw value for STATE_SYMBOL and update_path for PROXY_PATH_SYMBOL, creates a source (only for own writable or absent props, wrapping nested objects in a nested proxy), and returns undefined for UNINITIALIZED, falling back to Reflect.get for prototype props. getOwnPropertyDescriptor splices live source values into value descriptors and synthesizes an enumerable/writable descriptor for source-only props. has treats STATE_SYMBOL as always present, creates sources when in an active effect, and reports false for UNINITIALIZED. set truncates array entries beyond a new length, creates-or-sets sources, calls any target setter before signaling, and updates the array length source and version for new numeric indices. ownKeys reads the version (tracking), filters deleted props, and appends source-only keys. setPrototypeOf always throws state_prototype_fixed.

**Notes.**

- side_effect: Array length assignment clears or synthesizes UNINITIALIZED sources for indices >= the new length so later reads do not resurrect old values.
- condition: get only auto-creates sources for own properties that are writable or missing; non-writable own props fall through to Reflect.get untracked.

uses: [source](r5-client-reactivity.md#u-97497b70f31b); calls: [runtime-js-state-and-helpers](r2-reactivity-core.md#u-6cd2387802ec), [packages/svelte/src/internal/client/dev/tracing.js:tag](r4-runtime-dev.md#u-8f0bd6f00a08)

**Uncertainties.**

- Behavior of setters defined on the target (descriptor.set.call) interacting with the just-written source is observable only through the target, not shown here.

<a id="u-51040fd3e0a9"></a>
### `get_label`

`function get_label(path, prop)` · [packages/svelte/src/internal/client/proxy.js:L359-L363][f2]

Builds a dev tracing label for a property path: symbols render as path[Symbol(desc)], valid identifiers as path.prop, numeric strings as path[index], and other strings as path['prop'].

<a id="u-0468b533d5f3"></a>
### `get_proxied_value`

`export function get_proxied_value(value)` · [packages/svelte/src/internal/client/proxy.js:L368-L384][f2]

Unwraps a $state proxy: if the value is a non-null object holding STATE_SYMBOL, returns the raw proxied target; otherwise returns the value unchanged.

The membership test is wrapped in try/catch because probing cross-origin iframe contentWindow objects throws; in that case the original value is returned, since it is never a proxy.

<a id="u-e9711f04f87f"></a>
### `inspectable_array`

`function inspectable_array(array)` · [packages/svelte/src/internal/client/proxy.js:L411-L413][f2]

Dev-only wrapper around an array used when the state proxy is created, so $inspect sees a consistent state: mutating array methods (copyWithin, fill, pop, push, reverse, shift, sort, splice, unshift) are deferred — the wrapper marks inspect effects deferred, runs the mutation, then flushes inspect effects — ensuring one inspection per mutation instead of per intermediate step.

Non-mutating property reads return the underlying value untouched.

calls: [flush_inspect_effects](r5-client-reactivity.md#u-8313e354c312), [sources.js-inspect-effects-state](r5-client-reactivity.md#u-57d9601c89ba)

<a id="u-dcae92a399e9"></a>
### `is`

`export function is(a, b)` · [packages/svelte/src/internal/client/proxy.js:L390-L392][f2]

Equality check equivalent to Object.is but applied to the raw values behind any $state proxies, so a proxy and its target compare as equal.

calls: [get_proxied_value](r4-runtime-signals.md#u-0468b533d5f3)

<a id="u-4df1fec218a0"></a>
### `loop`

`export function loop(callback)` · [packages/svelte/src/internal/client/loop.js:L32-L44][f3]

Creates a task that runs its callback on every animation frame until the callback returns falsy or the task is aborted.

If the task set is empty it schedules raf.tick(run_tasks) to start the cycle. It returns a Task whose promise is fulfilled when the callback first returns falsy, and whose abort() removes the task from raf.tasks so it stops running. run_tasks reads raf.now() (not the rAF callback timestamp, per a documented upstream fix), invokes each task's callback; a truthy result keeps the task, a falsy result deletes it and fulfills its promise; after iteration, if tasks remain it re-schedules raf.tick(run_tasks). Note that tasks added during run_tasks iteration may or may not be visited in the same pass depending on Set.forEach semantics for entries added mid-iteration.

**Notes.**

- side_effect: The task object is added to the shared raf.tasks set, so abort only works while the set still holds that exact object.

group: [loop](r4-runtime-signals.md#u-4df1fec218a0)

**Uncertainties.**

- Whether a task added during run_tasks' forEach is executed in the same frame is not explicitly handled here

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/reactivity/deriveds.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/proxy.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/loop.js
