# Client Runtime

**Capability.** The browser-side execution engine compiled output calls into: fine-grained signal reactivity, DOM template operations and hydration-aware traversal, error/pending boundaries, element bindings and actions, custom-element hosting, dev-mode diagnostics, and spring motion.

Use when changing runtime behavior of compiled client code. Reactivity primitives underpin everything; DOM operations and bindings implement templates; boundaries handle errors and pending state; dev modules add warnings only in development builds.

**Children.**

- [Signal Reactivity Core](r5-client-reactivity.md) `r5-client-reactivity` · 16 unit(s)
- [DOM Operations & Elements](r5-client-dom.md) `r5-client-dom` · 9 unit(s)
- [Error & Pending Boundaries](r5-client-boundary.md) `r5-client-boundary` · 7 unit(s)
- [Element Bindings](r5-client-bindings.md) `r5-client-bindings` · 11 unit(s)
- [Custom Element Hosting](r5-client-custom-elements.md) `r5-client-custom-elements` · 4 unit(s)
- [Dev-Mode Diagnostics](r5-client-dev.md) `r5-client-dev` · 5 unit(s)
- [Spring Motion](r5-client-motion.md) `r5-client-motion` · 4 unit(s)

Parent: [Svelte Monorepo](r5-svelte.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
