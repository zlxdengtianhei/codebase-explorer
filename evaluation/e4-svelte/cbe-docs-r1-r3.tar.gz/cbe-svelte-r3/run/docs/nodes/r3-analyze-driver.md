# Analysis Driver

**Capability.** Main component/module analysis entries: builds the Js records, derives component names, orders legacy $: statements topologically, and hands the visitor map to the walker.

Use analyze_component via the compile pipeline and analyze_module for compileModule. The visitor map and reactive-statement ordering are internal to this node.

**Depends on.**

- [Analysis Visitors](r3-analyze-visitors.md) · model-inferred · 0 edge(s)
- [Shared Predicates and Hash](r3-shared-utils.md) · graph-confirmed · 3 edge(s)

**Depended on by.**

- [Client Transform Phase](r3-client-transform.md) · model-inferred · 0 edge(s)
- [Compiler Public Entry](r3-compiler-entry.md) · graph-confirmed · 2 edge(s) · compile and compileModule invoke the analysis driver to scope and validate the AST before transformation.
- [Migration Driver and Helpers](r3-migrate-entry.md) · graph-confirmed · 1 edge(s)

Parent: [Analysis Phase](r3-analyze-phase.md)

## Units (6)

<a id="u-ff1515d9bcd2"></a>
### `index-js-analyze-component`

`export function analyze_component(root, source, options)` · [packages/svelte/src/compiler/phases/2-analyze/index.js:L321-L623][f1]

Main analysis entry for a component, combining pre-walk setup, the visitor walk over module/instance/template ASTs, and post-walk CSS/element fixups.

It first builds Js records for the module and instance scripts plus template scopes sharing one ScopeRoot. Then, for each `$name` reference in the module scope (excluding reserved `$$props`/`$$restProps`/`$$slots`): bare `$`/`$$x` raises global_reference_invalid; when the compiler is not explicitly in legacy mode (options.runes === false), the name is not a rune, or the referenced declaration looks rune-like (null rune, `$props` prop names other than `props`, or `$derived` imported from svelte/store), a synthetic `store_sub` binding is created in the instance scope; nested (non-module/instance) ownership of the store name raises store_invalid_scoped_subscription, references inside the module AST raise store_invalid_subscription, lowercase undeclared store names under runes raise global_reference_invalid, and rune-named declarations called as functions warn store_rune_conflict. Deferred legacy fixups (promoting reassigned `let` store sources to `state`) run only when runes are finally off. Runes mode is options.runes, or inferred from top-level/instance await or any remaining rune-named module reference; if inferred off, the deferred checks run. A deprecated `context=` module attribute warns. Analysis defaults follow: maybe_runes is true only when not runes, not explicitly disabled, no `$$props`/`$$restProps` references, and the instance script has no `$:` labels or `export let`. immutable is runes || options.immutable; accessors true for custom elements, legacy options.accessors, or componentApi 4; inject_styles for injected CSS or custom elements; the CSS hash is computed via options.cssHash when CSS exists. In legacy mode (not runes), exported `let`/`var` declarations become bindable_prop bindings (with prop_alias on renames), const/function/class exports become analysis.exports, reassigned bindings referenced from templates, StyleDirectives, or `$:` blocks become `state`, and each-block bindings that are reassigned mark referenced identifiers in the block expression as mutated state. In runes mode, `$$props`/`$$restProps` in the module scope raise legacy_props_invalid/legacy_rest_props_invalid; module, instance, and template ASTs are each walked with an AnalysisState (ast_type distinguishing the three), and afterwards any reassigned `normal` binding referenced from the template warns non_reactive_update, except inside function boundaries, or for `bind:this` unless the path is inside a conditional/repeating block (IfBlock/EachBlock/AwaitBlock/KeyBlock). Legacy mode instead synthesizes `$$props`/`$$restProps` as rest_prop bindings, walks all three ASTs, warns export_let_unused for props never referenced (and with no matching `$name` declaration), and topologically orders reactive statements. Then named local export specifiers without bindings raise snippet_invalid_export (if the name matches an analyzed snippet) or export_undefined. Mixing `on:` directives with event attributes raises mixed_event_handler_syntaxes; unresolved snippet renderers get the component's snippet set and record render sites; slot snippets combined with render tags raise slot_snippet_conflict. Finally, when CSS exists, analyze_css runs, each element is pruned against the stylesheet, unused-selector warnings are skipped only if the CSS comment carries a `css_unused_selector` ignore, and every element: scoped custom elements get their subtree marked dynamic; elements lacking a class/style attribute but needing one (scoped, class/style directive, or spread-absent conditions) receive synthetic empty `class`/`style` Text attributes so codegen can emit set_class/set_style. Returns the ComponentAnalysis.

**Notes.**

- side_effect: Mutates global compiler state via state.adjust, state.set of analysis fields, ignore_map/ignore_stack through visitors, and mutates bindings in place (kind, prop_alias, mutated, references).
- condition: The synthetic store binding block reads options.runes explicitly; only `false` (legacy opt-in) suppresses rune assumptions, undefined still treats `$name` as a rune.

calls: [create_scopes](r4-compiler-scope.md#u-a24fbf023b97), [get_rune](r4-compiler-scope.md#u-5204b6ce4f7a), [extract_identifiers](r4-compiler-ast-utils.md#u-90eb95affc00), [analyze_css](r5-analyze-css.md#u-f762711e5ae7), [prune](r1-css-prune.md#u-41775043a205), [warn_unused](r2-css-analyze.md#u-6a7a7b443898), [mark_subtree_dynamic](r1-analysis-visitors.md#u-3e6e9a44c2b4), [create_attribute](r4-compiler-node-model.md#u-16d11cbbd59b), [is_custom_element_node](r4-compiler-node-model.md#u-ea1f0b51e1e8), [extract_svelte_ignore](r2-compiler-foundations.md#u-4a9ee4fb9b67), [js](r3-analyze-driver.md#u-1d167d10f6f2), [get_component_name](r3-analyze-driver.md#u-b77f317897f5), [index-js-order-reactive-statements](r3-analyze-driver.md#u-ab70ae446bea); uses: [index-js-visitors-map](r3-analyze-driver.md#u-5688e1955bcf)

**Uncertainties.**

- The exact error/warning behavior of inner visitors walked here (CallExpression, Identifier, etc.) is outside this file's source
- Deferred synthetic_stores_legacy_check closures assume declaration objects are stable and runes detection cannot change after this point; ordering relative to other ScopeRoot mutations is not visible here

<a id="u-5688e1955bcf"></a>
### `index-js-visitors-map`

`const visitors = { _(node, { state, next, path })` · [packages/svelte/src/compiler/phases/2-analyze/index.js:L86-L139][f1]

Defines the visitor map handed to zimmerframe's walk, combining a universal `_` visitor with per-node-type visitors imported from ./visitors.

The `_` visitor collects `svelte-ignore` directives: for template children of a Fragment (excluding Comment/Text nodes) it scans backwards over preceding Comment/Text siblings, extracting ignores from comments (offset by `<!--`); otherwise it reads the node's `leadingComments` (offset by `//`). Non-empty ignore lists are pushed via push_ignore before descent and popped after; the cloned ignore stack is recorded in ignore_map per node. It resolves the node's scope from state.scopes and descends with that scope switched in only when it differs from state.scope, via next(). The shorthand entries delegate each node type to its dedicated visitor module, so none of their logic lives here.

calls: [extract_svelte_ignore](r2-compiler-foundations.md#u-4a9ee4fb9b67), [push_ignore](r5-compiler-state-utils.md#u-a26d5dd25c33), [pop_ignore](r5-compiler-state-utils.md#u-43922869e1b9); uses: [analyze_module](r3-analyze-driver.md#u-92d8ef78fb8c)

**Uncertainties.**

- Whether structuredClone(ignore_stack) is required for correctness (snapshot semantics) versus incidental cannot be established from this file alone

<a id="u-ab70ae446bea"></a>
### `index-js-order-reactive-statements`

`const add_declaration = (node, declaration) =>` · [packages/svelte/src/compiler/phases/2-analyze/index.js:L961-L972][f1]

Topologically orders legacy `$:` reactive statements by their dataflow.

It builds a lookup from each assigned binding name to the statements that assign it, then creates edges assignment-name → dependency-name for every dependency not assigned by the same statement. If check_graph_for_cycles reports a cycle, reactive_declaration_cycle is raised with the first involved statement and an `a → b` rendering. Output order is built by add_declaration, which first emits (recursively) the statements producing each dependency not assigned by the current statement, skips already-inserted declarations, and finally appends the current one; iterating the unsorted map therefore yields a dependency-first ordering, and the returned Map preserves that insertion order. Self-referencing assignments are excluded from edges, so a statement assigning and reading the same binding is not a cycle.

calls: [check_graph_for_cycles](r5-analyze-visitors.md#u-9450956ffc9b); uses: [index-js-analyze-component](r3-analyze-driver.md#u-ff1515d9bcd2)

**Uncertainties.**

- Recursion in add_declaration has no explicit cycle guard in this source; the pre-check via check_graph_for_cycles is presumed to prevent infinite recursion, but that guard's completeness lives in another file

<a id="u-92d8ef78fb8c"></a>
### `analyze_module`

`export function analyze_module(source, options)` · [packages/svelte/src/compiler/phases/2-analyze/index.js:L249-L313][f1]

Analyzes a standalone module (compileModule path): parses the source with comment collection, builds scopes under a fresh ScopeRoot with runes always enabled, then validates `$`-prefixed references.

For each module-scope reference whose name starts with `$` and is not reserved (`$$props`, `$$restProps`, `$$slots`): bare `$` or `$$x` names raise global_reference_invalid; if a non-rune `$name` resolves to an existing binding, store_invalid_subscription_module is raised. It assembles an Analysis with runes/immutable/accessors fixed (true/true/false), adjusts global state (dev/rootDir/runes), and walks the AST with the shared visitors map, supplying component-only state fields as empty placeholders solely to satisfy types. Returns the completed Analysis.

calls: [packages/svelte/src/compiler/phases/1-parse/acorn.js:parse](r5-compiler-parse.md#u-2464d5720df7), [create_scopes](r4-compiler-scope.md#u-a24fbf023b97), [utils-js-predicates](r3-shared-utils.md#u-7eb274f609ad); uses: [index-js-visitors-map](r3-analyze-driver.md#u-5688e1955bcf)

<a id="u-b77f317897f5"></a>
### `get_component_name`

`function get_component_name(filename)` · [packages/svelte/src/compiler/phases/2-analyze/index.js:L231-L240][f1]

Derives a PascalCase-ish component name from a filename.

It splits on either path separator, drops the basename, strips a `.svelte` extension, and capitalizes the first character. If the basename is `index` (or `index.svelte`) and the containing directory exists and is not `src`, the directory name is used instead of `index`. Assumes parts.pop and parts.at(-1) succeed; an empty or extension-less filename would still be capitalized but may yield odd names.

**Uncertainties.**

- Behavior for filenames without a `.svelte` extension or with empty segments is not guarded in this code

<a id="u-1d167d10f6f2"></a>
### `js`

`function js(script, root, allow_reactive_declarations, parent)` · [packages/svelte/src/compiler/phases/2-analyze/index.js:L208-L226][f1]

Builds a Js record for one of a component's script chunks (module or instance).

It accepts a possibly-null script and substitutes an empty synthetic Program (start/end -1) when absent, then creates scopes for that AST under the shared ScopeRoot with the allow_reactive_declarations flag (true only for the instance script, as callers choose) and an optional parent scope. Returns the ast, its scope, the node-to-scope map, and whether a top-level await was found; exception behavior is whatever create_scopes raises.

calls: [create_scopes](r4-compiler-scope.md#u-a24fbf023b97)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/index.js
