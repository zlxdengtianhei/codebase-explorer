# Shared Runtime Infrastructure

**Capability.** Environment-agnostic pieces used by both runtimes: the writable/readable/derived store contract, generated dev/prod error throwers embedded in compiled output, and runtime validation helpers for stores, dynamic element tags, and snippet stringification.

Use when behavior must hold on client and server. Store shared/index.js is the canonical store implementation (writable built on safe_not_equal); errors.js throwers are referenced by shared/validate.js guards; validate.js is called from compiled output.

**Depends on.**

- [Signal Reactivity Core](r5-client-reactivity.md) · graph-confirmed · 1 edge(s)

**Depended on by.**

- [Spring Motion](r5-client-motion.md) · graph-confirmed · 1 edge(s)
- [Signal Reactivity Core](r5-client-reactivity.md) · model-inferred · 0 edge(s)
- [Server Runtime](r5-runtime-server.md) · graph-confirmed · 5 edge(s)

Parent: [Svelte Monorepo](r5-svelte.md)

## Units (10)

<a id="u-aa3a4430105f"></a>
### `errors.js-generated-error-throwers`

`export function await_outside_boundary()` · [packages/svelte/src/internal/shared/errors.js:L9-L19][f1]

Generated error-throwing helpers used by compiled output, all following one pattern: in dev (DEV from esm-env) they throw an Error whose name is 'Svelte error' and whose message is '<code>\n<long description>\n<doc url>'; in production they throw a bare Error whose message is only the doc URL.

lifecycle_outside_component and store_invalid_shape interpolate a name parameter into the message; the others are parameterless. Every function returns never — control never returns, the error always propagates to the caller. await_outside_boundary, invalid_default_snippet, invalid_snippet_arguments, snippet_without_render_tag, and svelte_element_invalid_this_value cover await outside a pending boundary, default-snippet misuse with let: directives, invalid snippet instantiation, rendering a snippet without {@render}, and a non-string this on <svelte:element> respectively.

<a id="u-1787859057c4"></a>
### `validate_void_dynamic_element`

`export function validate_void_dynamic_element(tag_fn)` · [packages/svelte/src/internal/shared/validate.js:L11-L16][f2]

Warns when a dynamic <svelte:element> tag names a void element.

It calls the supplied tag_fn to obtain the tag; if the tag is truthy and is_void(tag) classifies it as void, it emits w.dynamic_void_element_content(tag). A falsy tag (tag not yet known) skips the check.

calls: [utils-js-predicates](r3-shared-utils.md#u-7eb274f609ad), [warnings.js-console-warners](r1-shared-runtime.md#u-977b55ca7478)

<a id="u-718446e58f9d"></a>
### `validate_dynamic_element_tag`

`export function validate_dynamic_element_tag(tag_fn)` · [packages/svelte/src/internal/shared/validate.js:L19-L25][f2]

Validates the this value of a dynamic <svelte:element>.

It calls tag_fn to get the tag and throws e.svelte_element_invalid_this_value only when the tag is truthy and not a string. Falsy tags (null/undefined) are allowed without error.

raises: [errors.js-generated-error-throwers](r5-runtime-shared.md#u-aa3a4430105f)

<a id="u-f09c2e0aa53c"></a>
### `validate_store`

`export function validate_store(store, name)` · [packages/svelte/src/internal/shared/validate.js:L31-L35][f2]

Checks that an auto-subscribed value is a store.

When store is neither null nor undefined and lacks a function-valued subscribe property, it throws e.store_invalid_shape(name); null/undefined and anything with callable subscribe pass without error.

raises: [errors.js-generated-error-throwers](r5-runtime-shared.md#u-aa3a4430105f)

<a id="u-f0c8633de633"></a>
### `prevent_snippet_stringification`

`export function prevent_snippet_stringification(fn)` · [packages/svelte/src/internal/shared/validate.js:L41-L47][f2]

Arms a snippet function against accidental stringification.

It assigns fn.toString to a thunk that throws e.snippet_without_render_tag (and, unreachable after the throw, returns ''), then returns fn unchanged otherwise. Any attempt to coerce the snippet to a string therefore raises the snippet_without_render_tag error instead of producing source text.

raises: [errors.js-generated-error-throwers](r5-runtime-shared.md#u-aa3a4430105f)

<a id="u-dc45d71b793b"></a>
### `writable`

`export function writable(value, start = noop)` · [packages/svelte/src/store/shared/index.js:L34-L45][f3]

Creates a Writable store holding `value` with an optional StartStopNotifier (`start`, defaulting to noop) invoked with (set, update) when the first subscriber arrives and whose return value (if a function) becomes the stop cleanup.

`set(new_value)` updates only when safe_not_equal(current, new_value) says the value meaningfully changed; if the store has subscribers, it calls each subscriber's invalidate callback, queues [subscriber, value] pairs, and — only if the queue was empty when set began (outermost call) — synchronously drains the queue calling each run function, then empties it. Nested sets during that drain thus defer their own invalidations to the already-running drain. `update(fn)` applies fn to the current value and forwards to set. `subscribe(run, invalidate=noop)` adds the [run, invalidate] tuple, starts the notifier when this is the first subscriber, immediately calls run(value) with the current value, and returns an unsubscriber that removes the tuple and, when the last subscriber leaves and a stop exists, calls stop and clears it. Subscribers are stored in a Set, so subscribing the same tuple twice is deduplicated by identity.

calls: [writable](r5-runtime-shared.md#u-dc45d71b793b)

**Uncertainties.**

- safe_not_equal's exact equality rules live in equality.js and are not visible here.
- Whether start may synchronously call set before subscribers exist (set's `if (stop)` guard means such sets are dropped from notification) — behavior follows the code but downstream notifier contracts are external.

<a id="u-e3031b84c99c"></a>
### `readable`

`export function readable(value, start)` · [packages/svelte/src/store/shared/index.js:L20-L24][f3]

Creates a Readable store by constructing a writable(value, start) and exposing only its subscribe method.

Read operations therefore go through the full writable subscription lifecycle (start notifier on first subscriber, stop on last unsubscribe) while external mutation is impossible from the returned object.

calls: [writable](r5-runtime-shared.md#u-dc45d71b793b)

<a id="u-d2fec82a964b"></a>
### `packages/svelte/src/store/shared/index.js:derived`

`export function derived(stores, fn, initial_value)` · [packages/svelte/src/store/shared/index.js:L129-L143][f3]

Creates a Readable store whose value is computed from one or more input stores.

Accepts a single store or an array; a falsy entry in the store array throws `Error('derived() expects stores as input, got a falsy value')`. `auto` is true when fn takes fewer than two declared parameters, meaning fn returns the value directly; otherwise fn receives (values, set, update) and may return a cleanup function that is stored as `cleanup` and invoked before each recomputation and on stop. It is built on readable(initial_value, start): the start callback subscribes to every input via subscribe_to_store, recording each latest value by index; an invalidate callback sets a per-store pending bit, and the value callback clears that bit and — only after start completed (`started`) — runs `sync`, which no-ops while any bit is pending, calls cleanup, invokes fn with the single value or the values array, and either sets the returned value (auto mode) or registers a returned function as the next cleanup. After subscribing, `started = true` and sync runs once so the initial value is computed. The returned stop function unsubscribes all inputs (run_all), calls cleanup, and resets started to false so late-queued callbacks from the input stores cannot recompute after resubscription cycles.

calls: [subscribe_to_store](r1-store-compat.md#u-863f9153e183), [utils.js-small-helpers](r1-shared-runtime.md#u-aa0ed6112e71), [readable](r5-runtime-shared.md#u-e3031b84c99c)

**Uncertainties.**

- Whether sync's use of `pending` bitmasks correctly for more than 31 stores depends on JS bitwise semantics; no guard appears in the source.
- Behavior when fn's manual set is called without ever returning a value in non-auto mode is not explicitly handled beyond cleanup=noop.

<a id="u-624938d77758"></a>
### `packages/svelte/src/store/shared/index.js:get`

`export function get(store)` · [packages/svelte/src/store/shared/index.js:L204-L209][f3]

Synchronously reads a store's current value by subscribing with a callback that captures each emitted value into a local, then immediately invoking the returned unsubscriber.

It returns the last captured value, so for well-behaved stores that emit immediately on subscribe this is the current value; for stores that emit asynchronously the result is undefined (cast away via @ts-expect-error).

calls: [subscribe_to_store](r1-store-compat.md#u-863f9153e183)

**Uncertainties.**

- If the store never calls the subscriber synchronously, the function returns undefined rather than waiting; this depends on subscribe_to_store semantics in store/utils.js.

<a id="u-01eea88b3e69"></a>
### `readonly`

`export function readonly(store)` · [packages/svelte/src/store/shared/index.js:L190-L195][f3]

Returns `{ subscribe: store.subscribe.bind(store) }`, hiding any other store methods (notably set/update) so the result can only be read.

The bind preserves the original store as `this` for subscribe.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/shared/errors.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/shared/validate.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/store/shared/index.js
