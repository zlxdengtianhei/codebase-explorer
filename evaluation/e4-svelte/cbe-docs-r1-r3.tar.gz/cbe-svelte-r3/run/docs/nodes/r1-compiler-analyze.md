# Analyze Phase

**Capability.** Annotates the AST and emits diagnostics: CSS selector pruning, accessibility checks, and shared visitor helpers reused across analysis visitors.

Readers adding warnings or metadata should look here. css-prune and a11y are independent check families; shared analysis visitors hold helpers reused by many visitors.

**Children.**

- [CSS Selector Pruning](r1-css-prune.md) `r1-css-prune` · 19 unit(s)
- [Accessibility Checks](r1-a11y-checks.md) `r1-a11y-checks` · 4 unit(s)
- [Shared Analysis Visitors & Helpers](r1-analysis-visitors.md) `r1-analysis-visitors` · 10 unit(s)

Parent: [Compiler](r1-compiler.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
