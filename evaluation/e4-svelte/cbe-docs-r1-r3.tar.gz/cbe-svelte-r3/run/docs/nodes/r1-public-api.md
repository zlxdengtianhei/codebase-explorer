# Public & Authoring APIs

**Capability.** User-facing modules: motion (spring/tween), built-in transitions, reactive wrapper classes (SvelteDate/SvelteMap/SvelteURL), the store contract utilities, attachments, ambient rune typings, and the legacy class-component adapter.

Use this subtree for behavior of exported authoring APIs rather than compiled internals. Each child is a self-contained public feature area with its own helpers and, where present, tests.

**Children.**

- [Motion \(Spring & Tween\)](r1-motion.md) `r1-motion` · 5 unit(s)
- [Transitions](r1-transitions.md) `r1-transitions` · 8 unit(s)
- [Reactive Wrapper Classes](r1-reactive-collections.md) `r1-reactive-collections` · 4 unit(s)
- [Store Contract](r1-store-compat.md) `r1-store-compat` · 2 unit(s)
- [Attachments](r1-attachments.md) `r1-attachments` · 2 unit(s)
- [Rune Ambient Typings](r1-rune-ambient-typings.md) `r1-rune-ambient-typings` · 8 unit(s)
- [Legacy Class-Component Adapter \(Server\)](r1-legacy-component-adapter.md) `r1-legacy-component-adapter` · 1 unit(s)

Parent: [Svelte Repository](r1-svelte-monorepo.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
