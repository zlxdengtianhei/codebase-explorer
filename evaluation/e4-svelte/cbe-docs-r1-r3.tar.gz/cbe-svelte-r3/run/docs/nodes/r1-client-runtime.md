# Client Runtime

**Capability.** The browser-side `svelte` internal runtime: DOM template blocks and snippets, element bindings, the delegated event system, task scheduling, async reactivity plumbing, dev diagnostics and HMR, legacy-mode support, and the reactive core type contracts.

Navigate by concern: blocks render template control flow, bindings wire two-way element state, events owns delegation, async-reactivity preserves reactive context across awaits, and dev tooling covers warnings, errors, and HMR.

**Children.**

- [DOM Template Blocks](r1-dom-blocks.md) `r1-dom-blocks` · 11 unit(s)
- [Element Bindings](r1-element-bindings.md) `r1-element-bindings` · 8 unit(s)
- [Event System & Delegation](r1-event-system.md) `r1-event-system` · 7 unit(s)
- [Task Scheduling](r1-task-scheduling.md) `r1-task-scheduling` · 2 unit(s)
- [Async Reactivity](r1-async-reactivity.md) `r1-async-reactivity` · 8 unit(s)
- [Reactivity Type Contracts](r1-client-reactivity-types.md) `r1-client-reactivity-types` · 8 unit(s)
- [Dev Diagnostics & HMR](r1-client-dev-diagnostics.md) `r1-client-dev-diagnostics` · 11 unit(s)
- [Legacy Client Compatibility](r1-legacy-compat-client.md) `r1-legacy-compat-client` · 4 unit(s)

**Depended on by.**

- [Client Transform](r1-client-transform.md) · model-inferred · 0 edge(s)
- [Legacy Class-Component Adapter \(Server\)](r1-legacy-component-adapter.md) · model-inferred · 0 edge(s)

Parent: [Svelte Repository](r1-svelte-monorepo.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
