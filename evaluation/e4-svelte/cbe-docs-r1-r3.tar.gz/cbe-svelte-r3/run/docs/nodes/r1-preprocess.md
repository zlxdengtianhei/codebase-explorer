# Preprocessing

**Capability.** Runs user preprocessor groups over component source: the mutable PreprocessResult accumulator implementing Source, script/style tag processing via parse/stringify of tag attributes, markup processing, MappedCode assembly, and sourcemap decoding/merging of processed results.

Use this subtree to understand how svelte-preprocessor output is stitched back into source with valid maps. preprocess is the entry; decode_sourcemap owns map normalization consumed when building processed tag code.

**Depends on.**

- [HTML Entity Decoding](r1-html-entity-decoding.md) · model-inferred · 0 edge(s)
- [Source Maps & Preprocessing](r5-compiler-sourcemaps.md) · graph-only · 15 edge(s)

Parent: [Compiler](r1-compiler.md)

## Units (10)

<a id="u-049035fc1450"></a>
### `preprocess`

`export default async function preprocess(source, preprocessor, options)` · [packages/svelte/src/compiler/preprocess/index.js:L338-L368][f1]

Entry point that runs a preprocessor group or list of groups over component source and returns the combined Processed result.

The filename comes from options.filename, falling back to a legacy preprocessor.filename property. Groups are normalized to an array (empty when preprocessor is falsy), then applied in order against a shared PreprocessResult: for each group, markup runs first via process_markup, then script and style tag processing via process_tag, each result merged with result.update_source so code, sourcemaps, and dependencies accumulate. Finally result.to_processed() combines all collected sourcemaps into one and returns code, deduplicated dependencies, the combined map, and a toString.

uses: [index-js-preprocessresult-class](r1-preprocess.md#u-f41d2d2dd7e7); calls: [process_markup](r1-preprocess.md#u-4ab1a1bb5a53), [index-js-process-tag](r1-preprocess.md#u-bcb3f1cc2e12)

**Uncertainties.**

- The legacy fallback reads filename off a possibly non-object preprocessor via a cast; behavior when preprocessor is a non-object is undefined by the types.

<a id="u-4ab1a1bb5a53"></a>
### `process_markup`

`async function process_markup(process, source)` · [packages/svelte/src/compiler/preprocess/index.js:L308-L327][f1]

Applies a markup preprocessor to the entire source and converts its result to a SourceUpdate.

The preprocessor receives the whole content and filename. When it returns nothing the function returns an empty object, meaning no change. Otherwise it returns the new code as string, the map (JSON.parse'd when it is a string, otherwise passed through, undefined when absent), and the preprocessor's dependencies.

**Notes.**

- condition: A string map is JSON-parsed here inline; the code comment questions whether decode_map could be reused instead.

<a id="u-f41d2d2dd7e7"></a>
### `index-js-preprocessresult-class`

`constructor(source, filename)` · [packages/svelte/src/compiler/preprocess/index.js:L56-L62][f1]

Mutable accumulator of intermediate preprocessing state implementing the Source interface: the current source string, the filename, a reversed sourcemap list, accumulated dependencies, and a file_basename.

The constructor stores source/filename and calls update_source with the initial string, then sets file_basename to null when filename is null, otherwise get_basename(filename). update_source replaces this.source and rebuilds get_location via getLocator when a new string is given, unshifts a map onto sourcemap_list so the list is ordered last map first for later remapping, and appends dependencies. to_processed combines sourcemap_list with combine_sourcemaps(this.file_basename, ...) and returns a Processed object containing code, dependencies deduplicated through a Set, the combined map, and a toString bound to the current source.

calls: [get_basename](r5-compiler-sourcemaps.md#u-10b75c582411), [combine_sourcemaps](r5-compiler-sourcemaps.md#u-6270a2fbedb9)

**Uncertainties.**

- Two @ts-expect-error comments in to_processed note possible type-level bugs; runtime impact is not established from this source.

<a id="u-bcb3f1cc2e12"></a>
### `index-js-process-tag`

`async function process_tag(tag_name, preprocessor, source)` · [packages/svelte/src/compiler/preprocess/index.js:L265-L279][f1]

Processes every script or style tag in the current source via the given preprocessor and returns a SourceUpdate.

The tag regex (style or script variant, both skipping HTML comments) is applied by replace_in_code with an async per-match callback process_single_tag. process_single_tag returns a no_change MappedCode (the original tag text sliced at tag_offset) when attributes and content are both empty, when the preprocessor returns nothing, or when there is no map and processed.code equals the content. Otherwise it collects processed.dependencies into the shared dependencies array and builds the replacement via processed_tag_to_code, passing stringify_tag_attributes(processed.attributes) when attributes were updated or the original attributes otherwise, and a source slice of just the content. The final SourceUpdate carries the new string, map, and accumulated dependencies.

calls: [replace_in_code](r5-compiler-sourcemaps.md#u-8eab9628969e), [index-js-processed-tag-to-code](r1-preprocess.md#u-dbe64f3e27bf), [parse_tag_attributes](r1-preprocess.md#u-fb2fa12e3a03), [stringify_tag_attributes](r1-preprocess.md#u-348e22d5d13f)

<a id="u-dbe64f3e27bf"></a>
### `index-js-processed-tag-to-code`

`function processed_tag_to_code( processed, tag_name, original_attributes, generated_a…` · [packages/svelte/src/compiler/preprocess/index.js:L137-L150][f1]

Builds the MappedCode representing a whole processed script/style tag: generated open tag, processed content, and close tag.

build_mapped_code slices source-relative code via slice_source and wraps it with MappedCode.from_source. When the generated open tag's length differs from the original (attributes were rewritten), a hand-built version-3 decoded map is produced: segment [0,0,0,0] maps the tag start, a segment at the length of `<tag` maps the end of the tag start, additional single-segment lines are inserted while mappings.length <= line for multi-line tags, and a final segment maps the tag end to the original tag's last line/column; the map is offset by get_location(0) and attached via MappedCode.from_processed. If the lengths match, the open tag is sliced from the original source unchanged. The close tag is sliced at original_tag_open.length + content length. parse_attached_sourcemap validates the preprocessor's map, and the content is converted with processed_content_to_code at the offset just after the original open tag; all three parts are concatenated.

calls: [MappedCode.from_source](r5-compiler-sourcemaps.md#u-60c4a1a9f36f), [mapped_code.js-parse-attached-sourcemap](r5-compiler-sourcemaps.md#u-292b18a7971e), [sourcemap_add_offset](r5-compiler-sourcemaps.md#u-6ba9b18d03ed), [processed_content_to_code](r1-preprocess.md#u-f5d36b72e8e4), [slice_source](r5-compiler-sourcemaps.md#u-b98556db32bb)

**Uncertainties.**

- The column arithmetic for multi-line generated tags uses tag_open.lastIndexOf('\n') rather than its length-relative offset; correctness for generated attributes spanning lines is not separately validated here.

<a id="u-f5d36b72e8e4"></a>
### `processed_content_to_code`

`function processed_content_to_code(processed, location, file_basename)` · [packages/svelte/src/compiler/preprocess/index.js:L107-L126][f1]

Wraps a tag-content preprocessor result as a MappedCode.

If processed.map exists it is decoded with decode_map; when the decoded map has a sources array and file_basename appears in it, sourcemap_add_offset shifts only the segments referencing that source by the tag's location, so segments pointing at other files are untouched. The result is MappedCode.from_processed(processed.code, decoded_map), where decoded_map is undefined when the preprocessor supplied no map.

**Notes.**

- condition: Maps without a sources array, such as { mappings: '' }, are decoded but not offset.

calls: [decode_map](r1-preprocess.md#u-c6f821c0ed6a), [sourcemap_add_offset](r5-compiler-sourcemaps.md#u-6ba9b18d03ed)

<a id="u-fb2fa12e3a03"></a>
### `parse_tag_attributes`

`function parse_tag_attributes(str)` · [packages/svelte/src/compiler/preprocess/index.js:L223-L236][f1]

Extracts tag attributes from a raw attribute string using the module-level attribute_pattern regex, iterated with exec until it no longer matches.

Each match yields a name (match[1]) and an optional value from double-quoted, single-quoted, or bare match groups; the value defaults to true when absent, so valueless attributes map to true. Returns the accumulated record. Note the regex has the global flag and lastIndex state is reused across calls on this shared pattern.

**Notes.**

- side_effect: The module-level global regex attribute_pattern retains lastIndex between calls, which String.replace/exec mixing could affect; calls here always run to null so lastIndex is reset per invocation.

<a id="u-348e22d5d13f"></a>
### `stringify_tag_attributes`

`function stringify_tag_attributes(attributes)` · [packages/svelte/src/compiler/preprocess/index.js:L241-L251][f1]

Serializes an attributes record back into a tag-attribute string.

Returns undefined when attributes is falsy (meaning attributes stay unchanged). Boolean-true entries render as bare names; all others render as key="value". Entries are joined with spaces and the result is prefixed with a single space when non-empty, so it can be inlined directly after the tag name.

**Notes.**

- contract: Returning undefined signals 'keep original attributes'; callers substitute the original attribute string.

<a id="u-c6f821c0ed6a"></a>
### `decode_map`

`export function decode_map(processed)` · [packages/svelte/src/compiler/preprocess/decode_sourcemap.js:L86-L96][f2]

Normalizes the map attached to a Processed result into a decoded sourcemap.

If processed.map is a string it is JSON.parse'd. If the resulting mappings is still a string it is decoded with @jridgewell/sourcemap-codec's decode. If the object is a SourceMapGenerator instance (detected via a _mappings field and constructor.name === 'SourceMapGenerator'), it is replaced by decoded_sourcemap_from_generator's output. The possibly transformed object is returned.

calls: [decoded_sourcemap_from_generator](r1-preprocess.md#u-032387dae287)

**Uncertainties.**

- Detection of a SourceMapGenerator depends on constructor.name, which minification or subclassing could break.

<a id="u-032387dae287"></a>
### `decoded_sourcemap_from_generator`

`function decoded_sourcemap_from_generator(generator)` · [packages/svelte/src/compiler/preprocess/decode_sourcemap.js:L11-L81][f2]

Converts a mozilla/source-map SourceMapGenerator instance's private fields into a plain decoded sourcemap object.

It builds index lookups from generator._sources and generator._names, then walks generator._mappings in order: pushing new empty line arrays while generatedLine exceeds the previous line (lines are one-based, converted_mappings is zero-based), skipping any mapping identical to its predecessor across all six compared fields, and pushing each kept segment as [generatedColumn], extended with source index, originalLine-1, originalColumn, and the name index when a name exists. It returns version, sources, names, and the converted mappings, adding file only when generator._file != null; sourcesContent and sourceRoot are intentionally not produced.

calls: [decode_map](r1-preprocess.md#u-c6f821c0ed6a)

**Uncertainties.**

- Relies on undocumented private fields _sources, _names, _mappings, _version, _file of the generator; their runtime shape is not visible here.
- The one-based generatedLine indexing assumes mappings are already sorted; sorting is not enforced in this code.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/preprocess/index.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/preprocess/decode_sourcemap.js
