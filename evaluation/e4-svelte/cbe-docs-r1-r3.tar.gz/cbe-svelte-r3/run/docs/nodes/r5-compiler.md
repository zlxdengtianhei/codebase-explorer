# Compiler Pipeline

**Capability.** Turns Svelte source text into printed JavaScript and CSS by parsing, analyzing (validation, references, metadata), and transforming for client or server targets, supported by shared compiler state and AST/sourcemap utilities.

Use this subtree when changing how templates and modules are compiled. The three phases are sequential: parse produces the AST, analyze annotates and validates it, transform emits output. Shared utilities are kept apart from the phase visitors that consume them.

**Children.**

- [Template Parsing](r5-compiler-parse.md) `r5-compiler-parse` · 17 unit(s)
- [Analysis Phase](r5-compiler-analyze.md) `r5-compiler-analyze` · 0 unit(s)
- [Transform Phase](r5-compiler-transform.md) `r5-compiler-transform` · 0 unit(s)
- [Compiler State & AST Utilities](r5-compiler-state-utils.md) `r5-compiler-state-utils` · 16 unit(s)
- [Source Maps & Preprocessing](r5-compiler-sourcemaps.md) `r5-compiler-sourcemaps` · 19 unit(s)

**Depended on by.**

- [Sandbox Playground](r5-playgrounds.md) · model-inferred · 0 edge(s)

Parent: [Svelte Monorepo](r5-svelte.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
