# Build Scripts and Generated Sources

**Capability.** Release-time source generation: expands message templates into error modules, regenerates package .d.ts bundles, and rewrites version constants from package.json.

Read the templates here as the source of truth for generated error files; read the generator scripts to understand what is produced at release time. Nothing here runs in the compiled output or the runtime.

**Depends on.**

- [Compiler Pipeline](r4-compiler.md) · model-inferred · 0 edge(s)

Parent: [Svelte Compiler and Runtime](r4-svelte-monorepo.md)

## Units (7)

<a id="u-a7ff57214266"></a>
### `generate-types.js module code (L1–L85)`

`module_region` · [packages/svelte/scripts/generate-types.js:L1-L85][f1]

Top-level .d.ts generation for the svelte package.

It writes thin stub files (`import './types/index.js';`) for action, animate, easing, motion, store, transition, legacy, plus index.d.ts and compiler.d.ts, and creates types/compiler/preprocess.d.ts and types/compiler/interfaces.d.ts re-exporting '../index.js' — compatibility shims for users not on moduleResolution 'bundler' (comment marks them for possible removal in Svelte 6/7). It then awaits dts-buddy's createBundle to emit types/index.d.ts with stripInternal enabled and a paths map built from pkg.imports (each entry resolving to types ?? default ?? value), mapping every public subpackage to its source .d.ts or .js. After appending a newline, it validates the output: any JSDoc markdown link starting with '/' (missing the https://svelte.dev prefix) is listed and the process exits 1; a '\texport { ' occurrence exits 1 with guidance to export interfaces directly, because re-export statements break downstream d.ts generation.

**Uncertainties.**

- createBundle is an external dts-buddy API awaited at top level; its failure modes are not visible in this file.

<a id="u-5c80dbc18b0c"></a>
### `generate-version.js module code (L1–L16)`

`module_region` · [packages/svelte/scripts/generate-version.js:L1-L16][f2]

Release-time generator that reads version from package.json and overwrites src/version.js with a generated module exporting VERSION as the full version string and PUBLIC_VERSION as only the first dot-separated component (pkg.version.split('.')[0]).

The written file is headed 'generated during release, do not modify'. Runs once at import time; fs errors propagate uncaught.

**Notes.**

- side_effect: Overwrites src/version.js unconditionally on every run.

<a id="u-ee91b7104f1f"></a>
### `client-errors.js-code-template`

`export function CODE(PARAMETER)` · [packages/svelte/scripts/process-messages/templates/client-errors.js:L10-L18][f3]

Code-generator template for client-side error throwing functions (the real src/internal/client/errors.js is produced from it by scripts/process-messages/index.js).

It re-exports everything from ../shared/errors.js. The exported CODE function is a template: its `DEV`-guarded body throws a rich Error in development — name 'Svelte error' with the literal code string, the message, and an https://svelte.dev/e/<code> link — and in production throws an Error carrying only the link URL. At runtime in the shipped source the generator substitutes each `${'CODE'}` literal with the real code string and replaces MESSAGE with the per-code message expression and PARAMETER with the declared parameters, emitting one function per message code.

contract: [index.js-run](r2-message-codegen.md#u-f2d5f8b6c5f2)

**Uncertainties.**

- DEV comes from esm-env; its production/dev resolution is external to this file.

<a id="u-56147311b6b6"></a>
### `compile-errors.js-template`

`class InternalCompileError extends Error` · [packages/svelte/scripts/process-messages/templates/compile-errors.js:L5-L14][f4]

Template for compiler error construction (expanded into src/compiler/errors.js by process-messages).

InternalCompileError extends Error so bundler plugins recognize it, but keeps an enumerable `message` property and a blank `this.stack` assigned in the constructor (deliberately not a class property, which would make it enumerable). It holds a private #diagnostic CompileDiagnostic built from code/message/position, copies the diagnostic's own properties onto itself via Object.assign so both share one object shape (matching warnings), sets name 'CompileError', and delegates toString() and toJSON() to the diagnostic. The internal helper e() normalizes its node argument: a number is used as start and end, an object contributes its start/end fields, and null/undefined yields no position; when a start exists the position becomes [start, end ?? start], otherwise undefined, and the constructed error is thrown — e() never returns. The exported CODE function is the per-message template: it calls e() with the node, the code string, and the message text plus the https://svelte.dev/e/<code> link; the generator rewrites MESSAGE, PARAMETER and the code literals into one throwing function per compile error.

contract: [index.js-run](r2-message-codegen.md#u-f2d5f8b6c5f2); calls: [compile-errors.js-template](r4-build-codegen.md#u-56147311b6b6)

**Uncertainties.**

- CompileDiagnostic's constructor, toString and toJSON live in ./utils/compile_diagnostic.js, outside this batch.

<a id="u-0a643ee662f2"></a>
### `shared-errors.js-code-template`

`export function CODE(PARAMETER)` · [packages/svelte/scripts/process-messages/templates/shared-errors.js:L8-L16][f5]

Code-generator template for shared (client-and-server) error functions (expanded into src/internal/shared/errors.js by process-messages).

The exported CODE function template is DEV-gated: in development it throws an Error named 'Svelte error' containing the code string, the message, and the https://svelte.dev/e/<code> link; in production it throws an Error carrying only the link URL. The generator replaces the code literals, MESSAGE, and PARAMETER to emit one function per code.

contract: [index.js-run](r2-message-codegen.md#u-f2d5f8b6c5f2)

**Uncertainties.**

- DEV resolution from esm-env is external to this file.

<a id="u-db1f089a6c13"></a>
### `index.d.ts-ambient-declaration-bundle`

`export function getAbortSignal(): AbortSignal;` · [packages/svelte/types/index.d.ts:L374-L374][f6]

This file is an ambient TypeScript declaration bundle: `declare module` blocks for `svelte` and its subpath exports (`svelte/action`, `svelte/animate`, `svelte/attachments`, `svelte/compiler`, `svelte/easing`, `svelte/legacy`, `svelte/motion`, `svelte/reactivity`, `svelte/reactivity/window`, `svelte/server`, `svelte/store`, `svelte/transition`, `svelte/events`, plus deprecated `svelte/types/compiler/*` shims), a `declare module '*.svelte'` ambient module, and global rune declarations (`$state`, `$derived`, `$effect`, `$props`, `$bindable`, `$inspect`, `$host`) with their namespaces.

It contains only types, function signatures, and doc comments — no executable code — so per-symbol prose would only restate signatures. Cross-cutting facts: many declarations carry `@deprecated` markers pointing to Svelte 5 replacements (`SvelteComponent`/`SvelteComponentTyped` → `Component`/`mount`, legacy motion stores → `Spring`/`Tween`, event-modifier helpers in `svelte/legacy`, preprocess re-exports, compiler `parse` `modern` flag); several members are documented as type-checking only with no runtime existence (`$$prop_def`, `z_$$bindings`, `$$_attributes`); rune namespaces include `never`-typed members purely to suppress unhelpful intellisense; compiler AST interfaces (template and `_CSS`) describe parse output shapes only; the `*.svelte` module default-exports a `Comp` declared as a `LegacyComponentType` const with a `SvelteComponent` type alias, bridging legacy and modern component typing. In `svelte/reactivity/window`, all window bindings are typed as `ReactiveValue<T | undefined>` except `devicePixelRatio`, which is typed as a plain object exposing only a `get current(): number | undefined` getter.

**Uncertainties.**

- Signatures document intended runtime behavior in doc comments (e.g. `unmount` outro promise semantics, `settled` resolution timing), but implementations are not in this file, so those claims cannot be verified from this source.

<a id="u-97e239d86a6a"></a>
### `packages/svelte/types/index.d.ts:current`

`declare module 'svelte/reactivity/window' { /** * scrollX.current is a reactive vie…` · [packages/svelte/types/index.d.ts:L2403-L2456][f6]

Declares the exported `devicePixelRatio` binding of `svelte/reactivity/window` as an anonymous object type whose only member is a `get current(): number | undefined` getter.

This is a declaration-only signature with no body, so no runtime behavior exists in this file; the doc comment states that `current` reactively mirrors `window.devicePixelRatio`, is `undefined` on the server, and that behavior differs across browsers (Chrome responds to the current zoom level, Firefox and Safari do not). Structurally it differs from the sibling exports in the same module (`scrollX`, `innerWidth`, `online`, etc.), which are declared as `ReactiveValue<...>` instances; `devicePixelRatio` is typed as a bare object with only this getter. A non-exported `ReactiveValue<T>` class is declared in the same module, so an implementation could back this getter with it, but the public type does not promise that.

**Uncertainties.**

- The getter has no implementation here; whether the runtime value is ReactiveValue-backed cannot be established from this declaration file.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/scripts/generate-types.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/scripts/generate-version.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/scripts/process-messages/templates/client-errors.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/scripts/process-messages/templates/compile-errors.js
[f5]: ../../../../../../eval/svelte-be645b4/packages/svelte/scripts/process-messages/templates/shared-errors.js
[f6]: ../../../../../../eval/svelte-be645b4/packages/svelte/types/index.d.ts
