# Semantic Analysis Visitors

**Capability.** Phase-2 per-node analysis: each visitor inspects one AST node kind to record expression metadata (state, calls, await), assign binding semantics, and emit errors or warnings for illegal usage of tags, directives, and components.

Look up a visitor by AST node kind to see what a construct requires and which diagnostics it produces. Visitors delegate rule enforcement to the shared-validation subtree and consult scope/rune information to classify bindings.

**Depends on.**

- [Shared Analysis Validation](r4-analyze-shared-validation.md) · graph-confirmed · 7 edge(s)
- [AST Manipulation Utilities](r4-compiler-ast-utils.md) · graph-confirmed · 12 edge(s)
- [Node Factories and Metadata Model](r4-compiler-node-model.md) · graph-confirmed · 2 edge(s)
- [Parsing and Lexical Helpers](r4-compiler-parse.md) · graph-confirmed · 1 edge(s)
- [Scope and Binding Model](r4-compiler-scope.md) · graph-confirmed · 2 edge(s)
- [Shared Source Utilities](r4-shared-source-utilities.md) · graph-confirmed · 1 edge(s)

Parent: [Compiler Pipeline](r4-compiler.md)

## Units (19)

<a id="u-cda1a6710afe"></a>
### `AttachTag`

`export function AttachTag(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/AttachTag.js:L10-L13][f1]

Marks the enclosing fragment subtree dynamic (an attach tag cannot be statically hoisted) and continues traversal with state.expression set to the node's metadata.expression so descendant expressions record call/state flags onto it.

calls: [mark_subtree_dynamic](r1-analysis-visitors.md#u-3e6e9a44c2b4)

<a id="u-1731905f5fa9"></a>
### `AwaitExpression`

`export function AwaitExpression(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/AwaitExpression.js:L9-L39][f2]

Analyzes await expressions and decides whether the await suspends.

suspend is initially true only in instance code at function depth 1. If expression metadata exists it flags has_await, also flags fragment.metadata.has_await when a ConstTag is on the path, and forces suspend to true. When suspended, it throws experimental_async if the experimental.async option is off, and legacy_await_invalid if not in runes mode; these are raised unconditionally in that order. context.next() proceeds otherwise.

**Notes.**

- condition: An await inside any tracked expression (context.state.expression set) always counts as suspending, regardless of function depth.

raises: [AwaitExpression.js module code (L1–L8)][f2]

**Uncertainties.**

- Which surrounding syntax sets context.state.expression is defined elsewhere; this file only reads it.

<a id="u-95b9d2cc9f5c"></a>
### `BindDirective`

`export function BindDirective(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/BindDirective.js:L20-L254][f3]

Validates bind: directives against their parent element and the bound expression.

When the parent is a RegularElement/SvelteElement/SvelteWindow/SvelteDocument/SvelteBody and the name exists in binding_properties, it errors on invalid target elements, on names invalid for the element (suggesting valid bindings), on dynamic input type attributes, on checked/files bindings with mismatched static types, on dynamic multiple attributes of select, on offsetWidth bound to svg, and on contenteditable bindings missing or with a dynamic contenteditable attribute. Unknown names get a fuzzymatch suggestion (only if applicable to the element) then an error. For a SequenceExpression (getter/setter form), bind:group errors, parenthesized syntax is rejected by scanning source backwards (ignoring parentheses inside leading comments), exactly two expressions are required, the subtree is marked dynamic, and validation ends early. Otherwise validate_assignment runs, non-identifier assignees require a resolvable object root, and plain identifiers must bind state/raw_state/prop/bindable_prop/each/store_sub or an already-updated binding (bind:this exempt). bind:group requires a binding, rejects snippet bindings, walks the ancestor path collecting contributing EachBlocks to build parent_each_blocks, and computes or creates a shared binding group keyed by the expression's identifier keypath and bindings, storing group metadata. Finally each-rest bindings warn and children are visited.

**Notes.**

- failure: bind:group with no resolvable declaration throws a plain Error('Cannot find declaration for bind:group') rather than a compiler error.
- side_effect: Registers new binding groups in context.state.analysis.binding_groups and writes node.metadata for group bindings.
- side_effect: Marks EachBlock metadata.contains_group_binding for each blocks contributing identifiers to a group binding.

calls: [fuzzymatch](r4-compiler-parse.md#u-4d517976b3f9), [validate_assignment](r4-analyze-shared-validation.md#u-83497fe81c11), [mark_subtree_dynamic](r1-analysis-visitors.md#u-3e6e9a44c2b4)

<a id="u-3462d134e7cb"></a>
### `packages/svelte/src/compiler/phases/2-analyze/visitors/Component.js:Component`

`export function Component(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/Component.js:L9-L20][f4]

Analyzes a component usage and decides whether it is dynamically switched.

It looks up the binding for the component name, stripping a leading member path down to the first dot when the name contains one. metadata.dynamic is true only when the component is in runes mode, the binding exists, and either the binding is not 'normal' or the name contains a dot (member access implies dynamic); in non-runes mode svelte:component governs, so dynamic is false. Delegates the rest to visit_component.

**Notes.**

- condition: binding === null forces metadata.dynamic to false even in runes mode.

calls: [visit_component](r3-analyze-visitors.md#u-3bbf2fbef9a0)

<a id="u-c1ba3ccb02a9"></a>
### `packages/svelte/src/compiler/phases/2-analyze/visitors/ConstTag.js:ConstTag`

`export function ConstTag(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/ConstTag.js:L10-L39][f5]

Analyzes {@const} tags.

In runes mode it validates the '@' opening tag. It then enforces placement: the tag's parent must be a Fragment whose grandparent is IfBlock, SvelteFragment, Component, SvelteComponent, EachBlock, AwaitBlock, SnippetBlock, SvelteBoundary, KeyBlock, or an element with a `slot` attribute; otherwise it throws const_tag_invalid_placement. It visits the declaration id and its initializer, the latter with the tag's expression metadata so inner awaits/assignments are attributed to the const tag.

calls: [validate_opening_tag](r4-analyze-shared-validation.md#u-8a95b3b7e6dc)

<a id="u-64d8ee790c77"></a>
### `packages/svelte/src/compiler/phases/2-analyze/visitors/ExportDefaultDeclaration.js:ExportDefaultDeclaration`

`export function ExportDefaultDeclaration(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/ExportDefaultDeclaration.js:L10-L20][f6]

Handles default exports.

Outside a .svelte.js module context (ast_type falsy), an identifier default export is validated via validate_export against the current scope; a non-identifier declaration is not validated here. Inside a component's script (ast_type set), any default export raises module_illegal_default_export. Traversal continues afterwards.

calls: [validate_export](r4-analyze-shared-validation.md#u-1535dc101000)

<a id="u-04014907462f"></a>
### `ExpressionStatement`

`export function ExpressionStatement(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/ExpressionStatement.js:L9-L38][f7]

Analyzes expression statements, warning on legacy component instantiation.

If the statement is `new X({ target: ... })` — a single ObjectExpression argument containing a 'target' property — it looks up X's binding; only normal imported bindings whose import declaration source ends in '.svelte' and which were imported as a default specifier trigger the legacy_component_creation warning. The comment explicitly excludes .svelte.js module imports as too rare. Always continues with context.next().

<a id="u-548da3ff718c"></a>
### `ExpressionTag`

`export function ExpressionTag(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/ExpressionTag.js:L11-L26][f8]

Analyzes template expression tags like {expr}.

If the tag is directly in a Fragment and a parent element is known, it checks HTML content-model validity for '#text' against that parent and raises node_invalid_placement on an invalid message. It then marks the subtree dynamic (needed because even constant expressions like {42} render), and continues visiting with the tag's expression metadata in state.

calls: [is_tag_valid_with_parent](r4-shared-source-utilities.md#u-a93dfa56dc6d), [mark_subtree_dynamic](r1-analysis-visitors.md#u-3e6e9a44c2b4)

<a id="u-a8a29531c5a9"></a>
### `packages/svelte/src/compiler/phases/2-analyze/visitors/HtmlTag.js:HtmlTag`

`export function HtmlTag(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/HtmlTag.js:L10-L19][f9]

In runes mode, validates the {@html ...} tag contents via validate_opening_tag with '@'.

It then unconditionally marks the subtree dynamic because raw HTML output can fix otherwise invalid HTML, and continues traversal with state.expression set to the tag's metadata.expression.

calls: [mark_subtree_dynamic](r1-analysis-visitors.md#u-3e6e9a44c2b4), [validate_opening_tag](r4-analyze-shared-validation.md#u-8a95b3b7e6dc)

<a id="u-a9f55b312aed"></a>
### `packages/svelte/src/compiler/phases/2-analyze/visitors/LabeledStatement.js:LabeledStatement`

`export function LabeledStatement(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/LabeledStatement.js:L12-L95][f10]

Analyzes labeled statements, implementing legacy `$:` reactive statements.

A `$` label is a reactive statement only in instance code whose parent is Program; otherwise in non-runes mode it warns reactive_declaration_invalid_placement, and in runes mode an invalid placement throws legacy_reactive_statement_invalid. For a real reactive statement in runes mode it errors first; in legacy mode it creates a ReactiveStatement, visits the body with it in state (function_depth incremented), then derives dependencies: every scope reference whose usage is not the left side of a plain `=` assignment (walking down MemberExpression chains to the assignment root) contributes its binding; the mapping is stored in analysis.reactive_statements. If the body is a direct assignment, bindings of the assigned identifiers (for MemberExpression targets, only the base object identifier) that are legacy_reactive get their legacy_dependencies set to the collected dependencies. A final context.next() covers non-`$` labels.

**Uncertainties.**

- The dependency loop iterates context.state.scope.references, which reflects references added during the nested visit; whether self-references (e.g. `$: double = x * 2` seeing `double`) count is flagged by the in-code TODO and not determinable here.

<a id="u-f5a889520a52"></a>
### `LetDirective`

`export function LetDirective(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/LetDirective.js:L9-L24][f11]

Analyzes let: directives and validates placement only.

The directive's immediate parent must exist and be a Component, RegularElement, SlotElement, SvelteElement, SvelteComponent, SvelteSelf, or SvelteFragment; anything else throws let_directive_invalid_placement. No child visiting occurs in this visitor.

**Uncertainties.**

- Attribute-level validation of the let value happens elsewhere; this visitor checks placement only.

<a id="u-61f80c72baef"></a>
### `NewExpression`

`export function NewExpression(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/NewExpression.js:L9-L17][f12]

Warns when a class is instantiated inside a function body: if the callee is a ClassExpression and scope.function_depth > 0, emits perf_avoid_inline_class.

It then unconditionally sets analysis.needs_context to true, forcing reactive context creation for the component, and continues traversal.

**Notes.**

- side_effect: Always sets context.state.analysis.needs_context = true, whatever the node shape.

<a id="u-fd5ac76065e4"></a>
### `packages/svelte/src/compiler/phases/2-analyze/visitors/PropertyDefinition.js:PropertyDefinition`

`export function PropertyDefinition(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/PropertyDefinition.js:L10-L21][f13]

Prevents illegal assignments to $state fields.

It resolves the property key's name via get_name and looks it up in state_fields; when a matching state field exists, this node is not the field's own declaration node, and the node has a value, a position comparison decides the outcome: if this definition starts before the registered field node, state_field_invalid_assignment is raised. Otherwise traversal continues normally.

calls: [get_name](r4-compiler-node-model.md#u-99af92983a86)

**Uncertainties.**

- node.start/field.node.start are cast to number; behavior when either is undefined is not determined here.

<a id="u-5ba7dfee6f56"></a>
### `RenderTag`

`export function RenderTag(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/RenderTag.js:L14-L68][f14]

Analyzes {@render} tags.

It validates the '@' opening tag, snapshots the path into metadata, and unwraps optional chaining on the expression. For an Identifier callee it looks up the binding: metadata.dynamic is true unless the binding kind is 'normal'; resolved is true only when is_resolved_snippet confirms an unambiguous snippet declaration, and if the binding's initial is a SnippetBlock that snippet is added to metadata.snippets. The render tag is registered in analysis.snippet_renderers with the resolved flag and analysis.uses_render_tags is set. Spread arguments throw render_tag_invalid_spread_argument; call/bind/apply member calls throw render_tag_invalid_call_expression. It marks the subtree dynamic, visits the callee with the tag's expression metadata, then visits each argument with fresh expression metadata appended to metadata.arguments.

calls: [is_resolved_snippet](r1-analysis-visitors.md#u-5fc246db911c), [create_expression_metadata](r4-compiler-node-model.md#u-32bbb434f744), [unwrap_optional](r4-compiler-ast-utils.md#u-aa95700b7c80)

**Uncertainties.**

- Behavior when resolved is false (linking to every snippet) is described by the in-code comment; the linking itself happens in later phases outside this file.

<a id="u-f5aa541ce160"></a>
### `SvelteBoundary`

`export function SvelteBoundary(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/SvelteBoundary.js:L11-L27][f15]

Analyzes <svelte:boundary> attributes.

Every attribute must be a plain Attribute named onerror, failed, or pending, else svelte_boundary_invalid_attribute. Its value must be a single ExpressionTag — value === true (shorthand) or any other shape, including multi-chunk or non-expression values, throws svelte_boundary_invalid_attribute_value. Continues with context.next().

<a id="u-92b20617b51f"></a>
### `packages/svelte/src/compiler/phases/2-analyze/visitors/SvelteComponent.js:SvelteComponent`

`export function SvelteComponent(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/SvelteComponent.js:L10-L18][f16]

In runes mode, warns that <svelte:component> is deprecated; outside runes mode no warning is emitted.

It visits the component's expression (the dynamic component value) and then delegates the rest of analysis to visit_component.

calls: [visit_component](r3-analyze-visitors.md#u-3bbf2fbef9a0)

<a id="u-7502f1ce8b9a"></a>
### `SvelteHead`

`export function SvelteHead(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/SvelteHead.js:L10-L18][f17]

Rejects every attribute on <svelte:head> by raising svelte_head_illegal_attribute for each one, marks the subtree dynamic (head content participates in rendering), and continues traversal.

<a id="u-de902d0a63f3"></a>
### `packages/svelte/src/compiler/phases/2-analyze/visitors/SvelteWindow.js:SvelteWindow`

`export function SvelteWindow(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/SvelteWindow.js:L11-L24][f18]

Validates <svelte:window>: disallows child elements, then rejects any spread attribute or non-event attribute with illegal_element_attribute carrying the 'svelte:window' label; event attributes pass.

Traversal continues afterwards.

calls: [disallow_children](r1-analysis-visitors.md#u-43b79d8932ce), [ast-js-attribute-helpers](r4-compiler-ast-utils.md#u-e05972fa52ab)

<a id="u-8e1ff75e5298"></a>
### `VariableDeclarator`

`export function VariableDeclarator(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/VariableDeclarator.js:L16-L135][f19]

Analyzes variable declarators, assigning binding kinds from runes and validating props.

It first ensures no module import conflict. In runes mode it reads the initializer's rune and extracts destructuring paths (against a dummy id) to validate each declared identifier's name. Runes $state, $state.raw, $derived, $derived.by, and $props retype every path's binding to 'state', 'raw_state', 'derived', or for $props 'rest_prop'/'prop' depending on the path. For $props: a non-ObjectPattern/non-Identifier id throws props_invalid_identifier; under custom elements with no explicit props option it warns custom_element_props_identifier on an identifier id or a RestElement; analysis.needs_props is set. An Identifier id becomes a rest_prop binding with initial cleared. For ObjectPattern properties: computed keys throw props_invalid_pattern, `$$`-prefixed names throw props_illegal_name, and non-identifier values (after unwrapping defaults) throw props_invalid_pattern. Each value binding gets prop_alias from the key; an $bindable(...) default rewires initial to the $bindable argument and sets kind 'bindable_prop', otherwise initial is the default or null. Outside runes mode, calling $state/$derived/$props as an initializer throws rune_invalid_usage unless the callee is a store_sub binding. Continues with context.next().

calls: [get_rune](r4-compiler-scope.md#u-5204b6ce4f7a), [extract_paths](r4-compiler-ast-utils.md#u-34f2fcb20c62), [ensure_no_module_import_conflict](r4-analyze-shared-validation.md#u-ddca3e44b963)

**Uncertainties.**

- Non-Property ObjectPattern entries (RestElement) are skipped in the props loop, so their bindings are typed earlier via the paths pass ('rest_prop' via path.is_rest); interaction details span both passes.
- The equal() assertion on ObjectPattern can only fail if the earlier guard is bypassed; exact assert failure semantics live in assert.js.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/AttachTag.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/AwaitExpression.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/BindDirective.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/Component.js
[f5]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/ConstTag.js
[f6]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/ExportDefaultDeclaration.js
[f7]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/ExpressionStatement.js
[f8]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/ExpressionTag.js
[f9]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/HtmlTag.js
[f10]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/LabeledStatement.js
[f11]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/LetDirective.js
[f12]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/NewExpression.js
[f13]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/PropertyDefinition.js
[f14]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/RenderTag.js
[f15]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/SvelteBoundary.js
[f16]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/SvelteComponent.js
[f17]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/SvelteHead.js
[f18]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/SvelteWindow.js
[f19]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/VariableDeclarator.js
