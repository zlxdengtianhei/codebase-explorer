# Error & Pending Boundaries

**Capability.** Implements <svelte:boundary>: a Boundary class coordinating main, pending, and failed effects inside a preserved transparent effect, with error capture/reset, fallback rendering, $effect.pending, and nearest-boundary lookup for await.

Use when changing error handling or pending-state semantics. The class node owns the effect structure; error handling and constructor methods hang off it; get_pending_boundary and pending expose boundary state to user code.

**Depends on.**

- [DOM Operations & Elements](r5-client-dom.md) · graph-confirmed · 1 edge(s)
- [Signal Reactivity Core](r5-client-reactivity.md) · graph-confirmed · 2 edge(s)
- [Effect System](r4-runtime-effects.md) · graph-only · 13 edge(s)
- [Reactivity Core & Batching](r2-reactivity-core.md) · graph-only · 9 edge(s)

Parent: [Client Runtime](r5-runtime-client.md)

## Units (7)

<a id="u-4e4a6d345016"></a>
### `boundary-js-boundary-class`

`class Boundary` · [packages/svelte/src/internal/client/dom/blocks/boundary.js:L51-L119][f1]

Boundary class coordinating a boundary's main, pending, and failed effects inside one preserved, transparent block effect (flags EFFECT_TRANSPARENT | EFFECT_PRESERVED | BOUNDARY_EFFECT); the exported boundary(node, props, children) merely constructs it.

State: main/pending/failed effect slots, an offscreen document fragment holding main DOM while pending shows, a pending counter, and a lazily created #effect_pending source. has_pending_snippet reports props.pending. #run swaps active effect/reaction and component context for the boundary effect, returning null after handle_error on throw and restoring all three in finally. #show_pending_snippet moves the main effect's DOM into a fragment via move_effect and branches the pending snippet if absent. #update_pending_count(d) adjusts the counter; at zero it clears pending, pauses the pending effect, and reinserts the offscreen fragment before the anchor. Public update_pending_count routes the delta to this boundary when it has a pending snippet, otherwise to the parent boundary's private counter, and always adds #effect_pending_update to the shared effect_pending_updates set. get_effect_pending lazily creates the source via #effect_pending_subscriber (createSubscriber; DEV-tagged '$effect.pending()') and returns its current value, so boundaries without $effect.pending() never create the source.

**Notes.**

- side_effect: #effect_pending is created on first subscriber and set back to null when the last subscriber unsubscribes.

group: [Boundary.constructor](r5-client-boundary.md#u-078c9b337ba6), [boundary-js-boundary-class](r5-client-boundary.md#u-4e4a6d345016), [Boundary.error](r5-client-boundary.md#u-6da36536328d), [packages/svelte/src/internal/client/dom/blocks/boundary.js:Boundary.error](r5-client-boundary.md#u-c564ebef3bcc)

**Uncertainties.**

- Whether parent (active_effect.b) is always a Boundary instance is not proven in this file

<a id="u-078c9b337ba6"></a>
### `Boundary.constructor`

`constructor(node, props, children)` · [packages/svelte/src/internal/client/dom/blocks/boundary.js:L119-L180][f1]

Builds the boundary's root effect.

Stores anchor, props, and children, remembers the current hydration node as #hydrate_open, links the parent boundary via active_effect.b, and sets pending from props.pending. Inside the block effect it sets active_effect.b = this, advances hydration, then branches: while hydrating with a pending snippet it branches the pending effect and enqueues a Batch callback that runs the children through #run (with Batch.ensure()) and then either shows the pending snippet (pending_count > 0) or pauses the pending effect and clears pending. Otherwise it branches children directly, catching any render error into this.error(error), and likewise shows pending or clears pending based on the counter. After the block, hydrating reassigns #anchor to hydrate_node.

uses: [boundary-js-boundary-class](r5-client-boundary.md#u-4e4a6d345016)

<a id="u-6da36536328d"></a>
### `Boundary.error`

`error(error)` · [packages/svelte/src/internal/client/dom/blocks/boundary.js:L260-L288][f1]

Handles an error caught by this boundary and defines the reset closure.

It first destroys and nulls the main, pending, and failed effects; while hydrating it rewinds to #hydrate_open, advances past it with next(), and removes the server-rendered nodes. reset() is idempotent per error: a second call warns via svelte_boundary_reset_noop and does nothing, and calling reset from inside onerror throws svelte_boundary_reset_onerror. reset zeroes #pending_count, pauses the failed effect, sets pending true, re-renders children through #run (clearing #is_creating_fallback first), then either shows the pending snippet or clears pending. If the boundary was already rendering its fallback, or has neither onerror nor failed, error re-throws for an outer boundary.

uses: [boundary-js-boundary-class](r5-client-boundary.md#u-4e4a6d345016); calls: [boundary-js-boundary-class](r5-client-boundary.md#u-4e4a6d345016)

<a id="u-c564ebef3bcc"></a>
### `packages/svelte/src/internal/client/dom/blocks/boundary.js:Boundary.error`

`error(error)` · [packages/svelte/src/internal/client/dom/blocks/boundary.js:L320-L363][f1]

Dispatches the error to props and renders the fallback.

With active_reaction temporarily cleared and calling_on_error set, it invokes onerror?.(error, reset); if onerror itself throws, the thrown value is passed to invoke_error_boundary with the boundary effect's parent, and active_reaction is restored in finally. If a failed snippet exists, it is rendered in a queued microtask via #run with #is_creating_fallback true while rendering; an error thrown there goes to invoke_error_boundary with the effect's parent and yields null, and #is_creating_fallback is reset in finally. The failed snippet receives the original error and reset through getter closures.

group: [Boundary.error](r5-client-boundary.md#u-6da36536328d); calls: [boundary-js-boundary-class](r5-client-boundary.md#u-4e4a6d345016)

<a id="u-662729eaf177"></a>
### `get_pending_boundary`

`export function get_pending_boundary()` · [packages/svelte/src/internal/client/dom/blocks/boundary.js:L384-L396][f1]

Finds the nearest enclosing boundary (walking active_effect.b through parent links) that has a pending snippet; if none exists it throws via e.await_outside_boundary(), otherwise returns that boundary.

raises: [packages/svelte/src/internal/client/errors.js][f2]

<a id="u-71a170980fd0"></a>
### `move_effect`

`function move_effect(effect, fragment)` · [packages/svelte/src/internal/client/dom/blocks/boundary.js:L371-L382][f1]

Moves an effect's rendered DOM range into a fragment: starting at effect.nodes_start and stopping after effect.nodes_end, it appends each node to the fragment and advances via get_next_sibling until nodes_end is appended.

calls: [operations-js-node-lookups](r5-client-dom.md#u-07b45637bc3d)

<a id="u-8bef95411436"></a>
### `packages/svelte/src/internal/client/dom/blocks/boundary.js:pending`

`export function pending()` · [packages/svelte/src/internal/client/dom/blocks/boundary.js:L398-L410][f1]

Implements $effect.pending: throws via e.effect_pending_outside_reaction when there is no active effect; if the active effect has no boundary it returns 0; otherwise returns the boundary's get_effect_pending() value.

calls: [boundary-js-boundary-class](r5-client-boundary.md#u-4e4a6d345016); raises: [packages/svelte/src/internal/client/errors.js][f2]

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/blocks/boundary.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/errors.js
