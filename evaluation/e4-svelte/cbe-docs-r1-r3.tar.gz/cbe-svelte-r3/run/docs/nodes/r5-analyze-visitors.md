# AST Analysis Visitors

**Capability.** Per-node analysis of the template/JS tree: scopes and function setup, identifier reference resolution, attribute and directive validation, event-delegation classification, snippet registration/hoisting checks, and element-specific validation.

Use when changing validation, warnings, or reference analysis. Element visitors (SvelteElement, TitleElement) share validate_element from shared/element.js; Attribute.js decides delegatable events; SnippetBlock checks whether snippets can hoist to module scope.

**Depends on.**

- [CSS Analysis](r5-analyze-css.md) · model-inferred · 0 edge(s)
- [AST Manipulation Utilities](r4-compiler-ast-utils.md) · graph-only · 12 edge(s)
- [Shared Analysis Visitors & Helpers](r1-analysis-visitors.md) · graph-only · 11 edge(s)

Parent: [Analysis Phase](r5-compiler-analyze.md)

## Units (19)

<a id="u-9450956ffc9b"></a>
### `check_graph_for_cycles`

`export default function check_graph_for_cycles(edges)` · [packages/svelte/src/compiler/phases/2-analyze/utils/check_graph_for_cycles.js:L6-L25][f1]

Detects a cycle in a directed graph given as an edge list and returns one cycle's nodes, or undefined if acyclic.

It builds an adjacency Map (creating entries for both endpoints of every edge), then depth-first searches from each unvisited node using a visited set and an on-stack set.

**Uncertainties.**

- The returned cycle list is the on-stack path plus the revisited node; it reflects DFS order, not necessarily the minimal cycle.

<a id="u-5a0755c3b44f"></a>
### `ArrowFunctionExpression`

`export function ArrowFunctionExpression(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/ArrowFunctionExpression.js:L9-L11][f2]

Visitor for arrow function expressions that delegates entirely to the shared visit_function helper, which sets up function scope and related analysis state.

calls: [visit_function](r1-analysis-visitors.md#u-98e829315086)

<a id="u-57ff0d312a51"></a>
### `AssignmentExpression`

`export function AssignmentExpression(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/AssignmentExpression.js:L10-L31][f3]

Analyzes assignment expressions, validating the target and recording assignments for legacy reactivity and expression metadata.

It first validates the left-hand side via validate_assignment. When inside a reactive statement, it collects the bindings assigned on the left into reactive_statement.assignments (for MemberExpression targets it uses object() to find the base identifier, and skips if that yields null). If an expression metadata object is present it flags has_assignment. Finally it continues visiting children; errors come from validate_assignment and propagate.

calls: [validate_assignment](r4-analyze-shared-validation.md#u-83497fe81c11)

**Uncertainties.**

- The local shadowing of `id` inside the loop makes the outer null check largely redundant; whether a non-Identifier, non-MemberExpression left can pass extract_identifiers is not shown here.

<a id="u-a8d2e390ed17"></a>
### `Attribute`

`export function Attribute(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/Attribute.js:L16-L79][f4]

Analyzes element attributes during Svelte's analyze phase, flagging attributes that force dynamic rendering and classifying event handlers as delegatable.

After delegating to child visitors via context.next(), it marks the subtree dynamic in several independent cases: an option element's value attribute, any on* event attribute, any attribute name that cannot be set statically, and a class attribute whose value is a dynamic expression that is not a Literal, TemplateLiteral, or BinaryExpression — that last case also sets node.metadata.needs_clsx. When the attribute has a value, chunks are iterated (skipping ExpressionTag function expressions without effect in this excerpt); for event attributes on RegularElement/SvelteElement parents it records uses_event_attributes in analysis state, resolves the handler with get_delegated_event, and if delegated, marks hoisted functions and stores the DelegatedEvent in node.metadata.delegated.

**Notes.**

- side_effect: Sets node.metadata.needs_clsx, node.metadata.delegated, delegated function metadata.hoisted, and context.state.analysis.uses_event_attributes.

calls: [get_delegated_event](r5-analyze-visitors.md#u-462828f3596d), [mark_subtree_dynamic](r1-analysis-visitors.md#u-3e6e9a44c2b4)

**Uncertainties.**

- The loop over attribute chunks skips function expressions without performing any work in this listing; any effect is not visible here.

<a id="u-95a93395ab75"></a>
### `get_attribute_event_name`

`function get_attribute_event_name(event_name)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/Attribute.js:L238-L244][f4]

Normalizes an attribute name like onclickcapture into a base event name: it strips the leading two characters (on) and, if the remaining name is recognized as a capture event, additionally removes the trailing seven-character capture suffix.

calls: [utils-js-predicates](r3-shared-utils.md#u-7eb274f609ad)

<a id="u-462828f3596d"></a>
### `get_delegated_event`

`function get_delegated_event(event_name, handler, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/Attribute.js:L91-L233][f4]

Decides whether an event handler qualifies for Svelte's delegation/hoisting optimization, returning a DelegatedEvent or null.

It bails (returns null) when the handler is missing or the event is not delegatable, and when the enclosing element is not a RegularElement. It returns the shared unhoisted object when the element has a spread, when an identifier handler is also referenced in module scope, when any reference of an identifier binding resolves to a non-RegularElement/spread/non-delegated usage site (OnDirective or event-attribute ExpressionTag parents), when the reference's parent is neither a declaration nor a function declaration, when the identifier is exported, when no target function is found or it takes more than one parameter, and when scanning the function's scope references it encounters arguments or $host, a store subscription, an unhoistable snippet binding, shadowed bindings, multiple references to the same store, each-block index bindings, rest params, or mutated each/normal bindings (mutating each bindings only bails in non-runes mode). Otherwise it returns {hoisted: true, function}.

**Notes.**

- contract: All bail-out paths return the module-level shared unhoisted constant ({hoisted: false}); only the fully validated path returns hoisted: true.
- field: Shadowing check compares local_binding.node to binding.node and exempts bindings declared within the function itself via scope.declarations.

calls: [get_attribute_event_name](r5-analyze-visitors.md#u-95a93395ab75); uses: [validate_assignment](r4-analyze-shared-validation.md#u-83497fe81c11)

**Uncertainties.**

- Relation to validate_assignment is not supported by this function's visible code; treated as uncertain graph evidence.

<a id="u-dbb0147495c2"></a>
### `EachBlock`

`export function EachBlock(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/EachBlock.js:L13-L72][f5]

Analyzes {#each} blocks.

It validates the '#' opening tag and that body and fallback are non-empty; a context named $state/$derived raises state_invalid_placement. The keyed flag is set unless the key expression is exactly the index identifier (indexed, not keyed). The list expression is visited in the parent scope so its dependencies land in the outer scope. In legacy (non-runes) mode it detects whether the loop context is mutated, collects transitive dependencies of the expression's bindings through collect_transitive_dependencies, and if mutated promotes transitive normal const/let/var bindings to 'state' so they become invalidatable sources. Ends by marking the subtree dynamic.

calls: [validate_block_not_empty](r4-analyze-shared-validation.md#u-b877c3a87dc5), [extract_identifiers](r4-compiler-ast-utils.md#u-90eb95affc00)

**Uncertainties.**

- collect_transitive_dependencies recurses only through legacy_reactive bindings' legacy_dependencies; how those are populated is defined elsewhere.

<a id="u-229553bec4c3"></a>
### `Fragment`

`export function Fragment(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/Fragment.js:L8-L10][f6]

Updates traversal state so descendants know their enclosing fragment, then continues visiting children with the fragment set on state.

<a id="u-0527ca5efcfc"></a>
### `FunctionExpression`

`export function FunctionExpression(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/FunctionExpression.js:L9-L11][f7]

Visitor for function expressions that delegates entirely to the shared visit_function helper for scope setup and traversal.

calls: [visit_function](r1-analysis-visitors.md#u-98e829315086)

<a id="u-ac6549f7c9f9"></a>
### `packages/svelte/src/compiler/phases/2-analyze/visitors/Identifier.js:Identifier`

`export function Identifier(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/Identifier.js:L16-L192][f8]

Analyzes identifier references, ignoring non-references entirely.

Every reference marks the subtree dynamic; bare arguments outside any FunctionDeclaration/FunctionExpression is an error, and $$slots sets analysis.uses_slots. In runes mode, an unbound rune-shaped name is validated as a rune chain: computed member access is rejected, non-rune member names trigger removal/renaming errors ($effect.active → $effect.tracking, $state.frozen → $state.raw, $state.is removed) or an invalid-name error, and the chain must end in a CallExpression or parentheses are required. Outside runes mode, $$props/$$restProps record usage flags. When a binding resolves: it registers dependencies/references on the current expression context, marking state when the binding is a reactive kind (prop/bindable_prop/rest_prop or non-function) and its value is not statically known; it warns state_referenced_locally for reads of state/raw_state/derived bindings within the same function depth that are reassigned or unproxied $state calls (classified as 'derived' when read inside a $state/$state.raw rune call argument, otherwise 'closure'), skipping assignment/update targets; a reassigned module-scope binding inside a reactive statement warns reactive_declaration_module_postscript (name per warnings module); and under experimental async, a {#const} in an implicit children/boundary snippet referencing its template declaration errors unless the scopes differ.

**Notes.**

- side_effect: Adds bindings to context.state.expression.dependencies/references and sets has_state.
- failure: rune chain errors and invalid_arguments_usage are compiler errors that abort analysis.

calls: [get_rune](r4-compiler-scope.md#u-5204b6ce4f7a), [should_proxy](r3-client-transform-utils.md#u-d089d4da67c8), [is_component_node](r4-compiler-node-model.md#u-1354bdeaaf38)

<a id="u-6cad4b795a74"></a>
### `Literal`

`export function Literal(node)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/Literal.js:L8-L14][f9]

Warns when a string literal contains bidirectional control characters: only when node.value is a string does it test the value against regex_bidirectional_control_characters and, on match, emit the bidirectional_control_characters warning.

Non-string literals are ignored.

<a id="u-5d5cb13598f7"></a>
### `OnDirective`

`export function OnDirective(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/OnDirective.js:L10-L28][f10]

Analyzes on:event directives: in runes mode it warns event_directive_deprecated for element parents (not component parents, since component events may be out of the author's control), records the first element event directive in analysis.event_directive_node, marks the subtree dynamic, and continues traversal with the directive's own expression metadata as the expression state.

calls: [mark_subtree_dynamic](r1-analysis-visitors.md#u-3e6e9a44c2b4)

<a id="u-35398f6374ab"></a>
### `SnippetBlock`

`export function SnippetBlock(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/SnippetBlock.js:L11-L75][f11]

Registers a snippet block in analysis.snippets, rejects an empty body and, in runes mode, validates the opening tag; rest parameters in the parameter list are errors.

Traversal proceeds with parent_element reset to null. Afterwards it decides hoistability: only a snippet whose path is exactly [Fragment] and whose scope passes can_hoist_snippet can be hoisted; if so, its binding is copied into the module scope declarations so module-level references resolve. Shadowing checks: a snippet whose name matches an attribute of a parent component errors snippet_shadowing_prop; a snippet named children on a Component/SvelteComponent/SvelteSelf errors snippet_conflict if that component has any other non-comment, non-whitespace content besides snippet blocks.

**Notes.**

- side_effect: Sets node.metadata.can_hoist and, when hoistable, inserts the binding into context.state.analysis.module.scope.declarations.

calls: [can_hoist_snippet](r5-analyze-visitors.md#u-4e8662011f13), [validate_block_not_empty](r4-analyze-shared-validation.md#u-b877c3a87dc5), [validate_opening_tag](r4-analyze-shared-validation.md#u-8a95b3b7e6dc)

<a id="u-4e8662011f13"></a>
### `can_hoist_snippet`

`function can_hoist_snippet(scope, scopes, visited = new Set())` · [packages/svelte/src/compiler/phases/2-analyze/visitors/SnippetBlock.js:L81-L108][f11]

Recursively checks whether all references in a scope can be resolved if the snippet is hoisted to module scope.

It skips unresolvable references and those at function depth 0, ignores bindings declared inside the snippet itself (function depth at or beyond the snippet's), and for references to other snippet blocks recurses with cycle protection via the visited set of bindings. Any other reference to a binding declared in an outer function depth fails, making the snippet non-hoistable; only when every reference passes does it return true.

**Notes.**

- contract: The visited Set prevents infinite recursion on mutually referencing snippets.

<a id="u-e568340fb504"></a>
### `packages/svelte/src/compiler/phases/2-analyze/visitors/SvelteElement.js:SvelteElement`

`export function SvelteElement(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/SvelteElement.js:L13-L78][f12]

Analyzes <svelte:element> tags: runs validate_element and a11y check_element, records the node's path and registers it in analysis.elements.

Namespace resolution: an explicit static xmlns attribute sets metadata.svg/mathml by comparing its text to the SVG/MathML namespace constants. Without xmlns, it walks ancestors: at a component/fragment boundary, snippet, or the root it resets to the component's configured namespace (options.namespace === 'svg'/'mathml'); at an enclosing element it inherits that element's flags, except entering a foreignObject clears both. It marks the subtree dynamic, visits the dynamic tag expression, all attributes, and the fragment with parent_element cleared so inner content-model checks do not use the svelte:element tag as parent.

calls: [validate_element](r5-analyze-visitors.md#u-7d4fa5b13c15), [check_element](r1-a11y-checks.md#u-0f7a175a707e), [ast-js-attribute-helpers](r4-compiler-ast-utils.md#u-e05972fa52ab)

**Uncertainties.**

- The ancestor loop assumes an element/SvelteElement/Component/SvelteComponent/SvelteFragment/SnippetBlock will eventually be hit (i===0 as fallback); whether every path type is covered is not proven here.
- dynamic tag visit happens before attributes; ordering effects on scope are not visible in this file.

<a id="u-573785eeaa9d"></a>
### `TitleElement`

`export function TitleElement(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/TitleElement.js:L9-L21][f13]

Validates <svelte:title>: raises title_illegal_attribute for every attribute, and raises title_invalid_content for any fragment child that is neither Text nor an ExpressionTag, so only plain text and expressions are allowed.

Traversal continues afterwards.

<a id="u-c7e949fd4745"></a>
### `UseDirective`

`export function UseDirective(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/UseDirective.js:L9-L12][f14]

Marks the enclosing fragment subtree dynamic because an action directive runs at runtime, then continues traversal.

calls: [mark_subtree_dynamic](r1-analysis-visitors.md#u-3e6e9a44c2b4)

<a id="u-7d4fa5b13c15"></a>
### `validate_element`

`export function validate_element(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/shared/element.js:L29-L155][f15]

Per-attribute validation for regular and svelte elements, covering attribute values/names, animate/transition placement, and event-handler modifiers.

For Attribute nodes under runes mode it calls validate_attribute and rejects unparenthesized sequence expressions inline (same backward '(' vs '{' scan as component.js). It throws attribute_invalid_name when the name matches regex_illegal_attribute_character. Names starting with 'on' (length > 2) must be expression attributes or throw attribute_invalid_event_handler; an identifier equal to the attribute name with no scope binding warns attribute_global_event_reference. A slot attribute is validated with validate_slot_attribute (is_component defaults false, so element slots require an owning component/element ancestor). The 'is' attribute warns attribute_avoid_is; React-style names (className, htmlFor) warn attribute_invalid_property_name with the corrected name; then validate_attribute_name runs. AnimateDirective must sit directly inside a keyed EachBlock whose body has at most one meaningful (non-Comment, non-ConstTag, non-whitespace-Text) child, else animation_invalid_placement / animation_missing_key; a second animate directive throws animation_duplicate. TransitionDirective: an existing in- or out-transition on the same direction kind throws transition_duplicate (same kind) or transition_conflict (e.g. in vs transition); the directive then records itself as in_transition/out_transition per its intro/outro flags. OnDirective modifiers must be in the known EVENT_MODIFIERS list or throw event_handler_invalid_modifier; combining 'passive' with 'nonpassive' or 'preventDefault' throws event_handler_invalid_modifier_combination. Trackers (has_animate_directive, in/out_transition) are local per element.

calls: [validate_attribute](r2-analyze-phase.md#u-001c69caf1f6), [validate_attribute_name](r2-analyze-phase.md#u-c4e14f91c1c8), [validate_slot_attribute](r2-analyze-phase.md#u-be5b4cd34d6a), [ast-js-attribute-helpers](r4-compiler-ast-utils.md#u-e05972fa52ab)

**Uncertainties.**

- react_attributes is a module-level Map defined after the function; its initialization timing is fine for calls at module use, but no other code in this file references it.
- The EachBlock 'more than one meaningful child' rule counts children of parent.body.nodes; whether comments/const tags are intentionally excluded beyond the filter shown is inferred from the filter itself.

<a id="u-aa5fdde62415"></a>
### `element-js-imports-and-residuals`

`group` · [packages/svelte/src/compiler/phases/2-analyze/visitors/shared/element.js:L1-L28][f15]

Module scaffolding of element.js: JSDoc imports plus errors/warnings/ast/patterns imports and the react_attributes Map (className→class, htmlFor→for) used by validate_element for property-name warnings.

The Map itself is a pure constant; its consumption is covered in the validate_element unit.

uses: [validate_element](r5-analyze-visitors.md#u-7d4fa5b13c15)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/utils/check_graph_for_cycles.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/ArrowFunctionExpression.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/AssignmentExpression.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/Attribute.js
[f5]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/EachBlock.js
[f6]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/Fragment.js
[f7]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/FunctionExpression.js
[f8]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/Identifier.js
[f9]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/Literal.js
[f10]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/OnDirective.js
[f11]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/SnippetBlock.js
[f12]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/SvelteElement.js
[f13]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/TitleElement.js
[f14]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/UseDirective.js
[f15]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/shared/element.js
