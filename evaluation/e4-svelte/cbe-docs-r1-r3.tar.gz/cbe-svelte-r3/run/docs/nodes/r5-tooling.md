# Repository Tooling

**Capability.** Developer infrastructure around the library: reactivity benchmark scenarios and their forked runner, and the playground sandbox scripts that seed test apps and export sandbox compiler options.

Use when working on repo workflow rather than shipped code. Benchmarks exercise reactive graph shapes (deep chains, triangles, many-owner patterns); playground scripts package the sandbox app into a test directory.

**Children.**

- [Reactivity Benchmarks](r5-benchmarks.md) `r5-benchmarks` · 4 unit(s)
- [Sandbox Playground](r5-playgrounds.md) `r5-playgrounds` · 5 unit(s)

Parent: [Svelte Monorepo](r5-svelte.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
