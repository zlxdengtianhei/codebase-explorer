# Client Template Factories

**Capability.** Builds and inserts template DOM: HTML/svg/mathml/tree-based factory constructors, comment and text nodes, block boundary recording, script execution inside template HTML, and hydration-aware instance ids.

Compiled components call these factories to create template clones cheaply. from_namespace is wrapped by the svg/mathml one-liners; assign_nodes records block boundaries used elsewhere.

**Depends on.**

- [Client Hydration State](r3-client-hydration.md) · graph-confirmed · 3 edge(s)
- [DOM Operations & Elements](r5-client-dom.md) · graph-only · 17 edge(s)

**Depended on by.**

- [Client Control Blocks and CSS](r3-client-blocks.md) · graph-confirmed · 1 edge(s)
- [Client Render Lifecycle](r3-client-render.md) · graph-confirmed · 1 edge(s)

Parent: [Client Runtime](r3-client-runtime.md)

## Units (11)

<a id="u-5821b8bff12d"></a>
### `template-js-namespace-wrappers`

`export function from_svg(content, flags)` · [packages/svelte/src/internal/client/dom/template.js:L144-L146][f1]

Public one-line wrappers around from_namespace: from_svg passes the 'svg' namespace and from_mathml passes 'math', both forwarding content and flags unchanged.

No additional behavior.

calls: [from_namespace](r3-client-template.md#u-7fbca348f563)

<a id="u-1f86a26b5b8b"></a>
### `template-js-script-execution`

`export function with_script(fn)` · [packages/svelte/src/internal/client/dom/template.js:L254-L256][f1]

Makes scripts inside template HTML actually execute.

with_script wraps a template factory so the produced node passes through run_scripts. run_scripts returns the node untouched while hydrating (SSR scripts already ran). Otherwise it collects the scripts — the node itself if it is a <script>, else all descendant scripts — and for each creates a fresh <script> element copying all attributes and textContent (new elements created via DOM APIs do execute). If a replaced script sits at the fragment's first/last position, or the whole node is the script, the active effect's nodes_start/nodes_end are repointed at the clone so anchors stay live.

**Uncertainties.**

- Scripts replaced but not at the edges leave the effect's anchors untouched; correctness relies on those interior scripts not being anchors, which is not proven here.

<a id="u-daaa1d70e416"></a>
### `append`

`export function append(anchor, dom)` · [packages/svelte/src/internal/client/dom/template.js:L342-L355][f1]

Inserts a template's DOM into the live tree at the given anchor.

Hydrating: records the current hydrate_node as the effect's nodes_end, advances the cursor via hydrate_next, and returns without inserting. Not hydrating with a null anchor (void <svelte:element> with content edge case), it returns without inserting. Otherwise it inserts the fragment/element before the anchor.

calls: [hydration-js-state](r3-client-hydration.md#u-c504e0cdf2f3)

<a id="u-081194bea535"></a>
### `assign_nodes`

`export function assign_nodes(start, end)` · [packages/svelte/src/internal/client/dom/template.js:L29-L35][f1]

Records a block's DOM boundaries on the currently active effect.

Only assigns when the effect's nodes_start is still null, so the first template created in an effect wins; later calls are ignored. Takes the anchor as start and may record a null end (used during hydration where the end is fixed up later).

<a id="u-2c649b4b25d0"></a>
### `comment`

`export function comment()` · [packages/svelte/src/internal/client/dom/template.js:L319-L334][f1]

Creates a comment block placeholder, deliberately inlined rather than reusing template factories for performance.

Hydrating: assigns hydrate_node as start (end null) and returns it. Otherwise builds a DocumentFragment containing an empty comment plus an empty text anchor, assigns those as the effect's bounds, and returns the fragment.

calls: [assign_nodes](r3-client-template.md#u-081194bea535)

<a id="u-2d74ac8bccad"></a>
### `fragment_from_tree`

`function fragment_from_tree(structure, ns)` · [packages/svelte/src/internal/client/dom/template.js:L161-L201][f1]

Recursively builds a DocumentFragment from a TemplateStructure tree.

String items become text nodes. Undefined items, or arrays whose first element starts with '/' (comment markers used when preserveComments is on), become comment nodes — with the marker's first three characters stripped, or empty for undefined. Element items are destructured into name, attributes and children; the namespace is SVG for 'svg', MathML for 'math', otherwise inherited, and attributes are applied via set_attribute (with attributes.is as the custom-element `is` option). Children are appended into the element's content for <template> elements, into the element itself otherwise, recursing with an undefined namespace inside foreignObject. The element is then appended to the fragment.

calls: [fragment_from_tree](r3-client-template.md#u-2d74ac8bccad)

<a id="u-7aedb33d1cff"></a>
### `from_html`

`export function from_html(content, flags)` · [packages/svelte/src/internal/client/dom/template.js:L43-L82][f1]

Builds a factory for HTML templates.

Flags select fragment vs single-node output and importNode vs cloneNode. On first call (non-hydrating) it lazily parses the content via create_fragment_from_html, prefixing '<!>' when the content does not start with '<!>' so a leading comment/text anchor exists; if not a fragment it narrows to the first child. Each call then clones (importNode when flagged or Firefox), and records bounds on the active effect via assign_nodes — first/last child for fragments, the clone itself otherwise. While hydrating it skips construction entirely, assigning hydrate_node as start and returning it.

calls: [create_fragment_from_html](r1-dom-blocks.md#u-f51e86a3ef3c), [operations-js-node-lookups](r5-client-dom.md#u-07b45637bc3d)

**Uncertainties.**

- Reusing a factory across hydrating and non-hydrating phases mixes cached template state with hydration returns; not guarded here.

<a id="u-7fbca348f563"></a>
### `from_namespace`

`function from_namespace(content, flags, ns = 'svg')` · [packages/svelte/src/internal/client/dom/template.js:L91-L137][f1]

Factory builder for namespaced (svg/math) templates.

Wraps the content in <svg> or <math> tags (prefixing '<!>' when content lacks a leading anchor), parses via create_fragment_from_html, and on first call caches either the inner root element or, for fragment flags, a DocumentFragment holding the root's children moved out one by one. Each call clones the cached node, records bounds via assign_nodes (first/last child for fragments), and returns the clone. While hydrating it assigns hydrate_node and returns it without building anything.

calls: [create_fragment_from_html](r1-dom-blocks.md#u-f51e86a3ef3c)

<a id="u-4b6a1b3dac13"></a>
### `from_tree`

`export function from_tree(structure, flags)` · [packages/svelte/src/internal/client/dom/template.js:L209-L249][f1]

Factory form of fragment_from_tree with template flags.

While hydrating it assigns hydrate_node as start and returns it. Otherwise it lazily builds the structure once, choosing SVG or MathML namespace from TEMPLATE_USE_SVG/TEMPLATE_USE_MATHML flags; for non-fragment output it narrows to the fragment's first child. Each call clones (importNode when flagged or on Firefox), records bounds via assign_nodes (first/last child for fragments, the clone otherwise) and returns the clone.

calls: [fragment_from_tree](r3-client-template.md#u-2d74ac8bccad)

<a id="u-fafca980132c"></a>
### `props_id`

`export function props_id()` · [packages/svelte/src/internal/client/dom/template.js:L360-L377][f1]

Produces a unique id for a component instance, reusing the server-rendered one during hydration.

If hydrating and the current hydrate_node is a comment whose text starts with '#', the id is the text after '#' and the cursor advances via hydrate_next. Otherwise a shared counter is ensured on window.__svelte (created if absent, initialized to 1) and the id 'c' plus the post-increment value is returned, keeping ids unique across multiple Svelte runtimes on the page.

calls: [hydration-js-state](r3-client-hydration.md#u-c504e0cdf2f3)

**Uncertainties.**

- The exact comment format written by SSR is not in this file; only the '#'-prefix convention is visible.

<a id="u-e16a3d523a46"></a>
### `packages/svelte/src/internal/client/dom/template.js:text`

`export function text(value = '')` · [packages/svelte/src/internal/client/dom/template.js:L300-L317][f1]

Creates (or hydrates) a text node for an expression and records it as the block's bounds.

Not hydrating: builds a text node from the stringified value, assigns start and end to it, and returns it. Hydrating: takes `hydrate_node`; if it is not a text node (empty SSR expression), inserts a fresh empty text node before it, advances the cursor there via set_hydrate_node, then assigns and returns that node. Not marked side-effect-free because hydration mutates the DOM.

calls: [assign_nodes](r3-client-template.md#u-081194bea535)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/template.js
