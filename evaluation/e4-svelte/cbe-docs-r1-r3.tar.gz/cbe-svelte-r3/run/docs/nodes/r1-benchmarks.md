# Benchmarks

**Capability.** Performance benchmarks: kairo reactivity graphs (broad 50-pair fan-out and 100-signal mux/demux in one effect_root) and an SSR wrapper benchmark that compiles App.svelte and times repeated server renders with warm-up and gc timing.

Run these to measure signal-graph and SSR-render performance; wrapper_bench times render(App) loops after JIT warm-up via compile_svelte.

**Depends on.**

- [Server Runtime](r1-server-runtime.md) · model-inferred · 0 edge(s)
- [Benchmarking Harness](r4-benchmarking.md) · graph-only · 11 edge(s)

Parent: [Repository Tooling](r1-tooling.md)

## Units (4)

<a id="u-813578b5fd39"></a>
### `kairo_broad.js`

`function setup()` · [benchmarking/benchmarks/reactivity/kairo/kairo_broad.js:L4-L27][f1]

Benchmarks a wide fan-out graph: setup() creates 50 derived pairs (each current = head + i, current2 = current + 1) each with a render effect incrementing a shared counter, all inside one effect_root.

run() flushes head to 1, resets the counter, then for i in 0..49 flushes head to i asserting the last current2 equals i + 50, and finally asserts the counter hit 50*50, proving every branch recomputed per write. The unowned variant destroys each warm-up graph before timing 10 iterations of 1000 runs; the owned variant performs warm-up and final setup inside an outer effect_root and destroys the inner graph then the outer root after timing. Both return {benchmark, time, gc_time} rounded to two decimals; failed assertions throw and abort the benchmark.

calls: [fastest_test](r4-benchmarking.md#u-0bbe8c671495), [assert](r4-benchmarking.md#u-823bd0dd0cd8)

**Uncertainties.**

- Behavior of $.flush batching and effect ownership is defined in svelte/internal/client, not supplied here

<a id="u-3f4c12b77a45"></a>
### `kairo_mux.js`

`function setup()` · [benchmarking/benchmarks/reactivity/kairo/kairo_mux.js:L4-L23][f2]

Benchmarks a mux/demux pattern: setup() creates 100 state signals, one derived (mux) that packages all head values into an object keyed by index, 100 deriveds each reading mux[index], and 100 more each adding 1, with a render effect per final derived inside one effect_root.

run() sets heads[0..9] to i asserting splited[i] is i+1, then sets them to i*2 asserting splited[i] is i*2+1, testing that a single aggregate derived can be split back into per-index signals without unnecessary recomputation. Unowned and owned variants use the standard harness (10 warm-up cycles, fastest_test over 10 iterations of 1000 runs, teardown inner-then-outer for owned) and return {benchmark, time, gc_time} with two-decimal timings; assertion failure throws.

calls: [fastest_test](r4-benchmarking.md#u-0bbe8c671495), [assert](r4-benchmarking.md#u-823bd0dd0cd8)

**Uncertainties.**

- Whether the mux derived recomputes wholly or per-key on each head write depends on svelte/internal/client equality semantics not supplied here

<a id="u-e49d890081fc"></a>
### `compile_svelte`

`async function compile_svelte()` · [benchmarking/benchmarks/ssr/wrapper/wrapper_bench.js:L7-L16][f3]

Compiles App.svelte for server-side rendering and returns the compiled default export.

It reads the file from a directory derived from process.cwd(), compiles it with svelte's compile() using generate: 'server', writes the generated JS code to output/App.js, then dynamically imports that written module and returns module.default. Because the import is dynamic with a path variable, cache-busting between repeated calls is not visible here; failures in read, compile, write, or import propagate to the caller.

calls: [read_file](r4-benchmarking.md#u-19c8243b4a22), [write](r4-benchmarking.md#u-ccb2ac8173a1)

**Uncertainties.**

- Whether repeated invocations recompile or reuse the Node module cache for output/App.js is not determinable from this source

<a id="u-2f9f0e0c3125"></a>
### `wrapper_bench`

`export async function wrapper_bench()` · [benchmarking/benchmarks/ssr/wrapper/wrapper_bench.js:L18-L36][f3]

Runs the SSR wrapper benchmark: it awaits compile_svelte() to obtain the compiled App component, renders it 3 times with svelte/server's render() to warm the JIT, then times 10 iterations of 100 render(App) calls via fastest_test and returns {benchmark: 'wrapper_bench', time, gc_time} with timings fixed to two decimals.

Errors from compilation or rendering propagate to the caller.

calls: [compile_svelte](r1-benchmarks.md#u-e49d890081fc), [fastest_test](r4-benchmarking.md#u-0bbe8c671495)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/benchmarking/benchmarks/reactivity/kairo/kairo_broad.js
[f2]: ../../../../../../eval/svelte-be645b4/benchmarking/benchmarks/reactivity/kairo/kairo_mux.js
[f3]: ../../../../../../eval/svelte-be645b4/benchmarking/benchmarks/ssr/wrapper/wrapper_bench.js
