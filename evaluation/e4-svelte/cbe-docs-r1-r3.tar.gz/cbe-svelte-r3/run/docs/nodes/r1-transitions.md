# Transitions

**Capability.** The built-in transition functions (blur, fade, fly, scale, slide, draw, crossfade) each returning a TransitionConfig, plus shared easing and CSS-unit helpers including the shallow-merge assign used by crossfade defaults.

Consult when a specific transition's computed CSS or params handling is wrong. All functions draw on the internal helper group for easing and unit splitting.

Parent: [Public & Authoring APIs](r1-public-api.md)

## Units (8)

<a id="u-bc2c7a4069fc"></a>
### `blur`

`export function blur( node, { delay = 0, duration = 400, easing = cubic_in_out, amoun…` · [packages/svelte/src/transition/index.js:L38-L53][f1]

Builds a TransitionConfig animating opacity and a CSS blur filter.

Defaults: delay 0, duration 400ms, easing cubic_in_out, amount 5, opacity 0 (fade to fully transparent). At creation it reads computed opacity as the target and the current filter string (treating 'none' as empty), splits amount into value/unit, and returns css(t,u) producing `opacity: target - target*(1-opacity)*u` and `filter: <existing> blur(u*value unit)`. No style is written here; the returned css callback is applied by the transition runtime.

<a id="u-e08c53790eff"></a>
### `fade`

`export function fade(node, { delay = 0, duration = 400, easing = linear } = {})` · [packages/svelte/src/transition/index.js:L62-L70][f1]

Builds a TransitionConfig animating opacity with defaults delay 0, duration 400, easing linear.

Reads the element's computed opacity once and returns css(t) = `opacity: ${t * o}`, so in transitions go 0→current opacity and out transitions reverse.

<a id="u-0bc0dd3f8a1e"></a>
### `fly`

`export function fly( node, { delay = 0, duration = 400, easing = cubic_out, x = 0, y …` · [packages/svelte/src/transition/index.js:L79-L97][f1]

Builds a TransitionConfig animating x/y translation plus opacity.

Defaults: delay 0, duration 400, easing cubic_out, x=0, y=0, opacity=0. Captures computed target opacity, the existing transform ('none' becomes ''), and splits x and y into value/unit pairs. css(t,u) emits `transform: <existing> translate((1-t)*x_value x_unit, (1-t)*y_value y_unit)` and `opacity: target - target*(1-opacity)*u`, so offsets interpolate between the element's position and the given x/y.

uses: [index.js-transition-helpers](r1-transitions.md#u-acdaaed736b2)

<a id="u-10ebbce29874"></a>
### `scale`

`export function scale( node, { delay = 0, duration = 400, easing = cubic_out, start =…` · [packages/svelte/src/transition/index.js:L159-L177][f1]

Builds a TransitionConfig animating scale and opacity.

Defaults: delay 0, duration 400, easing cubic_out, start=0 (initial scale), opacity=0. Captures computed target opacity and existing transform ('none' → ''), computes sd = 1-start and od = target*(1-opacity), and css(_t,u) emits `transform: <existing> scale(1 - sd*u)` and `opacity: target - od*u`.

<a id="u-56eca0fbad21"></a>
### `slide`

`export function slide(node, { delay = 0, duration = 400, easing = cubic_out, axis = '…` · [packages/svelte/src/transition/index.js:L108-L150][f1]

Builds a TransitionConfig that slides an element in/out by animating its height (axis 'y', default) or width (axis 'x').

In DEV only, if the computed display is contents/inline/table and this is the first such warning (module-level `slide_warning` latch), it emits w.transition_slide_display and schedules clearing the latch in a microtask, so the warning fires once per burst. It reads computed opacity, the primary dimension, and the padding/margin/border-width of the two secondary sides (top/bottom or left/right per axis). css(t) emits overflow:hidden, `opacity: min(t*20,1)*opacity` (quick fade at the start), the primary dimension scaled by t, each padding/margin/border width scaled by t, and min-primary:0.

uses: [slide](r1-transitions.md#u-56eca0fbad21)

**Uncertainties.**

- The Promise.resolve().then latch reset assumes microtask timing clears the flag after a batch of transitions; exact batching behavior of callers is external.

<a id="u-72385efb0ac6"></a>
### `draw`

`export function draw(node, { delay = 0, speed, duration, easing = cubic_in_out } = {})` · [packages/svelte/src/transition/index.js:L186-L210][f1]

Builds a TransitionConfig animating an SVG path's stroke drawing via stroke-dasharray/dashoffset.

Requires a node with getTotalLength; length is that value, plus parseInt(strokeWidth) when the computed stroke-linecap is not 'butt'. Duration resolution: if duration is undefined, it becomes 800 when speed is also undefined, else len/speed; if duration is a function, it becomes duration(len). css(_,u) emits `stroke-dasharray: len; stroke-dashoffset: u*len`, so u goes from full offset (invisible) to 0 (drawn).

**Uncertainties.**

- No check that duration ends up numeric when both duration and speed are odd values (e.g. speed 0 → Infinity); follows arithmetic as written.

<a id="u-604bb627ffc1"></a>
### `packages/svelte/src/transition/index.js:crossfade`

`export function crossfade({ fallback, ...defaults })` · [packages/svelte/src/transition/index.js:L233-L245][f1]

Creates a matched pair of send/receive transition factories coordinating element crossfades by key.

It keeps two module-instance Maps (to_send, to_receive) and returns [transition(to_send, to_receive, false), transition(to_receive, to_send, true)]. Each factory, when applied to (node, params), records node under params.key in its own map and returns a lazy initializer that, on invocation, checks the counterpart map: if a counterpart exists for the key it is removed and crossfade(other_node, node, params) produces the matching transform+fade config; otherwise the node is unclaimed, its key is deleted from the own map, and the user-provided `fallback(node, params, intro)` config is used (undefined if no fallback). Remaining params override the crossfade defaults via assign-merge; inner defaults are delay 0, duration d => Math.sqrt(d)*30, easing cubic_out. The inner crossfade measures both rects, computes dx/dy offsets and width/height ratios, and returns css(t,u) emitting opacity t*opacity, transform-origin top left, and a translate(u*dx,u*dy) plus scale(t + (1-t)*dw, t + (1-t)*dh) prepended to the node's existing transform.

calls: [packages/svelte/src/transition/index.js:crossfade](r1-transitions.md#u-604bb627ffc1); uses: [index.js-transition-helpers](r1-transitions.md#u-acdaaed736b2)

**Uncertainties.**

- Correctness when the same key is sent/received multiple times concurrently (map delete races) is not guarded in this source.
- fallback may be undefined, in which case unclaimed nodes return undefined from the initializer — downstream handling is external.

<a id="u-acdaaed736b2"></a>
### `index.js-transition-helpers`

`const linear = (x) =>` · [packages/svelte/src/transition/index.js:L7-L7][f1]

Internal helpers for the transition module: `linear` is the identity easing; `cubic_out` returns (t-1)³+1; `cubic_in_out` returns 4t³ for t<0.5 else 0.5·(2t-2)³+1; `split_css_unit(value)` splits a number-or-string CSS value into [numeric, unit], matching `^\s*(-?[\d.]+)([^	 ]*)	 	$` for strings (empty unit becomes 'px') and defaulting to [value, 'px'] for numbers or unmatched strings; `assign(tar, src)` shallow-copies all enumerable own-ish keys of src onto tar and returns tar (used to merge crossfade defaults with per-call params, mutating the fresh intermediate object).

None have side effects beyond assign's writes to its first argument.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/transition/index.js
