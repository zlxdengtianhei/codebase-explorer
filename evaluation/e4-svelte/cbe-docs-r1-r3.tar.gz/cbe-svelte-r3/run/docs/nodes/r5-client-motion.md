# Spring Motion

**Capability.** Spring animation built on signals: a Spring class whose target/current are signals with a ticking simulation, clamped stiffness/damping, plus the deprecated spring() store factory wrapping writable with spring-animated updates.

Use when changing spring physics or the legacy store API. tick_spring advances the simulation; Spring reads state() signals so assigning .target animates .current; spring() delegates to the shared store writable.

**Depends on.**

- [Signal Reactivity Core](r5-client-reactivity.md) · graph-confirmed · 7 edge(s)
- [Shared Runtime Infrastructure](r5-runtime-shared.md) · graph-confirmed · 1 edge(s)

Parent: [Client Runtime](r5-runtime-client.md)

## Units (4)

<a id="u-6e9a0bc3364a"></a>
### `packages/svelte/src/motion/spring.js:Spring`

`class Spring` · [packages/svelte/src/motion/spring.js:L172-L196][f1]

Reactive spring class whose #target and #current are signals; assigning spring.target animates spring.current toward it.

The constructor seeds both signals with the initial value, clamps numeric options.stiffness/damping into [0,1] (precision unclamped), and tags all signals in DEV. set(value, options) first rejects the previous deferred with Error('Aborted') (internally swallowed by a noop catch); with options.instant or when #current is undefined it aborts any task, jumps both current and target to value, and returns a resolved promise. With options.preserveMomentum it sets inverse_mass to 0 and records the momentum milliseconds, so the spring keeps its trajectory while inverse_mass recovers in the loop. Otherwise it creates a fresh deferred and calls #update, which writes #target, defaults #current/#last_value if still undefined, and if no task runs starts a loop that each frame restores inverse_mass toward 1, clamps elapsed time to 1/30 s, builds a TickContext from the current signal values, ticks via tick_spring, writes the next value to #current, clears #task on settle, and returns !settled to keep looping. The deferred resolves only if it is still the latest one. Static of(fn, options) constructs a spring and re-sets it from fn() inside a render_effect, so reactive changes to fn's dependencies drive the target; it must run inside an effect root. Getters read the signals; the damping and stiffness setters clamp to [0,1], precision is unclamped, and the target setter delegates to set(v).

**Notes.**

- failure: Each new set() rejects the prior deferred with Error('Aborted'); awaiting a superseded set() promise rejects, while the class itself attaches a noop catch so it never becomes an unhandled rejection internally.

calls: [tick_spring](r5-client-motion.md#u-6d7266b4a494), [loop](r4-runtime-signals.md#u-4df1fec218a0), [render_effect](r4-runtime-effects.md#u-bbe822faa096)

**Uncertainties.**

- task.abort() semantics (how the loop promise settles) live in internal/client/loop.js and are not visible in this file.
- Whether #update returning this.#task.promise can race with set() replacing #deferred between loop completion and .then is guarded only by the d !== this.#deferred check visible in set.

<a id="u-ba5d7afebe6e"></a>
### `clamp`

`function clamp(n, min, max)` · [packages/svelte/src/motion/spring.js:L367-L369][f1]

Restricts n to the inclusive range [min, max] via Math.max(min, Math.min(max, n)); used to bound spring stiffness and damping values.

<a id="u-65703c942e2e"></a>
### `spring`

`export function spring(value, opts = {})` · [packages/svelte/src/motion/spring.js:L68-L89][f1]

Deprecated store factory that wraps a writable store with spring-animated updates, defaulting to stiffness 0.15, damping 0.8, precision 0.01.

Its set(new_value, opts) takes an immediate path — sets the store to the new value and returns a resolved promise — when the initial value is null, opts.hard is set, or both spring.stiffness and spring.damping are >= 1. Otherwise, if opts.soft is set it grants infinite mass (inv_mass = 0) with a recovery rate of 1/(rate*60), where rate is 0.5 for opts.soft === true or the numeric value of opts.soft. If no task is running it starts a loop callback that each frame restores inv_mass toward 1, clamps elapsed time to 1/30 s so blocked tabs do not overshoot, ticks via tick_spring with the shared options as ctx.opts, publishes the next value through store.set, clears the task when ctx.settled, and returns false to stop the loop. A cancel_task flag lets the immediate path abort a running loop on its next frame. The returned promise resolves only if its per-set token is still the current token, so superseded sets never resolve. The returned object also exposes update(fn, opts) delegating to set(fn(target_value, current value), opts), subscribe from the underlying store, and the stiffness/damping/precision options.

calls: [tick_spring](r5-client-motion.md#u-6d7266b4a494), [loop](r4-runtime-signals.md#u-4df1fec218a0)

**Uncertainties.**

- Whether hard/soft options combine in ways beyond the branch order shown (hard short-circuits before soft) depends only on the if/else ordering visible here.

<a id="u-6d7266b4a494"></a>
### `tick_spring`

`function tick_spring(ctx, last_value, current_value, target_value)` · [packages/svelte/src/motion/spring.js:L23-L57][f1]

Advances a spring simulation one tick and reports settlement through ctx.settled.

For numbers and Dates it derives velocity as (current - last) / (ctx.dt || 1/60) (guarding division by zero), applies stiffness*delta and damping*velocity forces scaled by inv_mass; if both the resulting step and the remaining delta are below opts.precision it returns target_value (settled), otherwise it sets ctx.settled = false and returns a new Date or the incremented number. Arrays recurse element-wise and plain objects recurse per key, so ctx.settled is false if any component is unsettled. Any other typeof throws `Cannot spring <type> values`.

calls: [is_date](r1-motion.md#u-c15d4b363055)

**Uncertainties.**

- Mismatched shapes between last/current/target in array or object recursion are not validated in this function.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/motion/spring.js
