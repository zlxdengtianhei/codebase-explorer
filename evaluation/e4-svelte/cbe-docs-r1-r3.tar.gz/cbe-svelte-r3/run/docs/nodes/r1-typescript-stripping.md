# TypeScript Node Stripping

**Capability.** Entry point plus zimmerframe visitor set that removes TypeScript constructs from a parsed module so downstream JS-only code generation is not confused.

Use when a TypeScript-specific construct reaches code generation. remove_typescript_nodes is the entry point; the visitor group owns the per-node rewrites.

Parent: [Parse Phase](r1-compiler-parse.md)

## Units (2)

<a id="u-1e95bda7f290"></a>
### `remove_typescript_nodes`

`export function remove_typescript_nodes(ast)` · [packages/svelte/src/compiler/phases/1-parse/remove_typescript_nodes.js:L168-L170][f1]

Entry point that walks the given AST with zimmerframe using the module's TypeScript-stripping visitors and no state, returning the transformed tree of the same nominal type.

uses: [remove_typescript_nodes.js-visitors](r1-typescript-stripping.md#u-45ebf0d9ad24)

<a id="u-45ebf0d9ad24"></a>
### `remove_typescript_nodes.js-visitors`

`function remove_this_param(node, context)` · [packages/svelte/src/compiler/phases/1-parse/remove_typescript_nodes.js:L11-L16][f1]

Zimmerframe visitor set that strips TypeScript constructs from a parsed module so downstream JS-only code generation (esrap) is not confused.

The fallback `_` visitor calls next() and then deletes typeAnnotation, typeParameters, typeArguments, returnType, accessibility from every returned node. Type-only syntax is replaced with `b.empty`: TSInterfaceDeclaration, TSTypeAliasDeclaration, TSDeclareFunction, `import type`/`export type` declarations, and type-only specifiers (a declaration with zero remaining specifiers collapses to empty). Type wrappers unwrap to their inner expression: TSAsExpression, TSSatisfiesExpression, TSNonNullExpression, TSTypeAssertion, TSInstantiationExpression all visit node.expression. Invalid non-stage-4 features throw `e.typescript_invalid_feature`: Decorator, TSEnumDeclaration, PropertyDefinition with `accessor`, and TSParameterProperty with readonly/accessibility when the enclosing constructor path applies; TSModuleDeclaration throws the same error if any visited namespace member survives as non-empty, and returns empty regardless (no body → empty). remove_this_param, shared by FunctionExpression and FunctionDeclaration, drops a leading `this` parameter when present. ClassBody rebuilds the body dropping `declare` PropertyDefinitions; ClassDeclaration returns empty when `declare` and otherwise deletes `implements`; MethodDefinition returns empty when abstract; VariableDeclaration returns empty when declare. ExportNamedDeclaration visits a declaration and returns empty if it degraded to EmptyStatement.

**Uncertainties.**

- TSModuleDeclaration's namespace check compares visited entries against b.empty by identity; whether context.visit returns the shared b.empty value for all empty results depends on zimmerframe behavior not visible here.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/1-parse/remove_typescript_nodes.js
