# Element Bindings and Behaviors

**Capability.** Two-way bindings and element behaviors for concrete DOM APIs: media element bindings (currentTime, volume, playback state, ranges), document activeElement binding, autofocus handling, form reset listeners, and hydration textarea cleanup.

Each bind_* function pairs DOM events with render effects/effect teardown to keep state and element properties in sync. Consult media.js per property; misc.js holds one-off element behaviors used by compiled attribute handlers.

**Depends on.**

- [Effect System](r4-runtime-effects.md) · graph-confirmed · 7 edge(s)
- [Signals, Deriveds, and Proxies](r4-runtime-signals.md) · model-inferred · 0 edge(s)
- [DOM Elements](r2-dom-elements.md) · graph-only · 11 edge(s)

Parent: [Svelte Compiler and Runtime](r4-svelte-monorepo.md)

## Units (16)

<a id="u-63ddea66ca81"></a>
### `bind_active_element`

`export function bind_active_element(update)` · [packages/svelte/src/internal/client/dom/elements/bindings/document.js:L7-L17][f1]

Binds a callback to changes of document.activeElement via focusin/focusout listeners on document.

On focusout with a relatedTarget the update is skipped, because focus moved between elements and activeElement would transiently report document.body; otherwise update is called with the current document.activeElement. Listener removal is handled by listen's teardown.

calls: [listen](r2-dom-elements.md#u-8f0d8dd6601b)

<a id="u-5f07941d0504"></a>
### `bind_buffered`

`export function bind_buffered(media, set)` · [packages/svelte/src/internal/client/dom/elements/bindings/media.js:L64-L82][f2]

Pushes the media's buffered ranges into state.

Because `buffered` can change without any event and always returns a fresh object, the handler runs on loadedmetadata, progress, timeupdate and seeking and compares deeply: it re-emits only when there is no cached value, the range count changed, or some start/end differs, storing the new time_ranges_to_array output as the comparison baseline.

calls: [listen](r2-dom-elements.md#u-8f0d8dd6601b), [time_ranges_to_array](r4-runtime-element-bindings.md#u-813d089e78b3)

<a id="u-ff4af77f53b3"></a>
### `bind_current_time`

`export function bind_current_time(media, get, set = get)` · [packages/svelte/src/internal/client/dom/elements/bindings/media.js:L21-L30][f2]

Two-way binds media.currentTime.

A requestAnimationFrame loop reschedules itself only while the media is playing and cancels any pending frame first; it calls set whenever currentTime changed. The same callback is also attached as a 'timeupdate' listener so scrubbing via native controls is caught while paused. A render effect pushes state to the DOM: it assigns media.currentTime only when the numeric get() differs from the last seen value and is not NaN. Teardown cancels the animation frame and removes the timeupdate listener.

uses: [time_ranges_to_array](r4-runtime-element-bindings.md#u-813d089e78b3), [listen](r2-dom-elements.md#u-8f0d8dd6601b)

<a id="u-fcd1246de591"></a>
### `bind_ended`

`export function bind_ended(media, set)` · [packages/svelte/src/internal/client/dom/elements/bindings/media.js:L112-L114][f2]

On timeupdate and ended events, calls set with the current media.ended boolean.

calls: [listen](r2-dom-elements.md#u-8f0d8dd6601b)

<a id="u-7fefb5f7789c"></a>
### `bind_muted`

`export function bind_muted(media, get, set = get)` · [packages/svelte/src/internal/client/dom/elements/bindings/media.js:L216-L217][f2]

Two-way binds media.muted.

Mirrors bind_volume: a callback pushes media.muted into state, invoked immediately when the initial get() is nullish and on every volumechange; a render effect assigns !!get() to media.muted when it differs from the DOM value.

calls: [listen](r2-dom-elements.md#u-8f0d8dd6601b)

<a id="u-ff3b55389a53"></a>
### `bind_paused`

`export function bind_paused(media, get, set = get)` · [packages/svelte/src/internal/client/dom/elements/bindings/media.js:L158-L161][f2]

Two-way binds media.paused.

A local update callback pushes media.paused into state whenever it differs from the cached value; it listens to play, pause and canplay (canplay covers src switches that pause playback), and the listener registration is suppressed via call_handler_immediately=false when the initial get() is nullish. An effect pushes state to the media: it re-reads get() and pauses or plays accordingly; playing requires the element to be mounted (hence effect) to avoid 'play() interrupted by load' errors, and a rejected play() promise falls back by setting paused back to true.

calls: [listen](r2-dom-elements.md#u-8f0d8dd6601b)

<a id="u-4820026af89c"></a>
### `bind_playback_rate`

`export function bind_playback_rate(media, get, set = get)` · [packages/svelte/src/internal/client/dom/elements/bindings/media.js:L133-L151][f2]

Two-way binds media.playbackRate.

One effect assigns Number(get()) to media.playbackRate only when it differs and is not NaN; it runs as an effect (not render_effect) so the element is mounted first, otherwise the browser resets the rate to 1. A second effect registers a ratechange listener (also after mount) that calls set with media.playbackRate on user rate changes.

calls: [listen](r2-dom-elements.md#u-8f0d8dd6601b)

<a id="u-4919c59e2ded"></a>
### `bind_played`

`export function bind_played(media, set)` · [packages/svelte/src/internal/client/dom/elements/bindings/media.js:L96-L98][f2]

On each timeupdate, calls set with time_ranges_to_array(media.played).

calls: [listen](r2-dom-elements.md#u-8f0d8dd6601b)

<a id="u-266203020cd0"></a>
### `bind_ready_state`

`export function bind_ready_state(media, set)` · [packages/svelte/src/internal/client/dom/elements/bindings/media.js:L120-L126][f2]

Calls set with media.readyState whenever any of loadedmetadata, loadeddata, canplay, canplaythrough, playing, waiting or emptied fires.

calls: [listen](r2-dom-elements.md#u-8f0d8dd6601b)

<a id="u-36603b8a0aeb"></a>
### `bind_seekable`

`export function bind_seekable(media, set)` · [packages/svelte/src/internal/client/dom/elements/bindings/media.js:L88-L90][f2]

On loadedmetadata, calls set with time_ranges_to_array(media.seekable); one-shot per event, listener removed by listen's teardown.

calls: [listen](r2-dom-elements.md#u-8f0d8dd6601b)

<a id="u-dba15fb360e8"></a>
### `bind_seeking`

`export function bind_seeking(media, set)` · [packages/svelte/src/internal/client/dom/elements/bindings/media.js:L104-L106][f2]

On seeking and seeked events, calls set with the current media.seeking boolean.

calls: [listen](r2-dom-elements.md#u-8f0d8dd6601b)

<a id="u-9a0b45d9b402"></a>
### `bind_volume`

`export function bind_volume(media, get, set = get)` · [packages/svelte/src/internal/client/dom/elements/bindings/media.js:L191-L192][f2]

Two-way binds media.volume.

A callback pushes media.volume into state; it runs immediately when the initial get() is nullish (pushing the DOM value into state) and on every volumechange. A render effect assigns Number(get()) to media.volume only when it differs and is not NaN.

calls: [listen](r2-dom-elements.md#u-8f0d8dd6601b)

<a id="u-813d089e78b3"></a>
### `time_ranges_to_array`

`function time_ranges_to_array(ranges)` · [packages/svelte/src/internal/client/dom/elements/bindings/media.js:L5-L13][f2]

Converts a TimeRanges object into an array of {start, end} pairs by iterating its length and calling ranges.start(i) and ranges.end(i).

<a id="u-3524dfa24535"></a>
### `add_form_reset_listener`

`export function add_form_reset_listener()` · [packages/svelte/src/internal/client/dom/elements/misc.js:L37-L58][f3]

Installs a single global capture-phase 'reset' listener on document, guarded by a module-level flag so it registers at most once.

On reset, it waits one microtask (form element properties have not reset yet in the same tick) and, if the event was not defaultPrevented, calls each element's __on_r callback — the hook that remove_input_defaults installs to re-clear value/checked defaults. Capture phase is used so stopPropagation cannot suppress it.

<a id="u-7f00a79795f4"></a>
### `autofocus`

`export function autofocus(dom, value)` · [packages/svelte/src/internal/client/dom/elements/misc.js:L10-L21][f3]

Implements autofocus as a spread/attribute handler: when value is truthy it sets dom.autofocus = true and queues a micro task that calls dom.focus() only if the document body is still the active element, i.e. the user has not already focused something else.

Non-truthy values do nothing.

<a id="u-d9f3f6cd0345"></a>
### `remove_textarea_child`

`export function remove_textarea_child(dom)` · [packages/svelte/src/internal/client/dom/elements/misc.js:L29-L33][f3]

During hydration, clears server-rendered textarea children because a textarea's DOM children correspond to its default value; removing them prevents a form reset from restoring stale content.

It only clears when the element has a first child; outside hydration it does nothing.

calls: [operations-js-node-lookups](r5-client-dom.md#u-07b45637bc3d)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/elements/bindings/document.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/elements/bindings/media.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/elements/misc.js
