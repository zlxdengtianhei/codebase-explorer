# Shared Source Utilities

**Capability.** Language-level helpers consumed by both compiler and runtime: HTML escaping for safe string insertion and HTML content-model validation tables deciding legal parent/child/ancestor tag relationships.

Consult escaping.js before emitting or serializing markup strings, and html-tree-validation.js when reasoning about tag nesting legality. These are pure utilities with no component pipeline responsibilities of their own.

**Depended on by.**

- [Semantic Analysis Visitors](r4-analyze-visitors.md) · graph-confirmed · 1 edge(s)
- [Client Code Transformation](r4-transform-client.md) · graph-confirmed · 1 edge(s)
- [Client Static Template Emission](r4-transform-template.md) · graph-confirmed · 1 edge(s)

Parent: [Svelte Compiler and Runtime](r4-svelte-monorepo.md)

## Units (4)

<a id="u-0f499dd45547"></a>
### `escape_html`

`export function escape_html(value, is_attr)` · [packages/svelte/src/escaping.js:L9-L26][f1]

Escapes HTML-sensitive characters in a stringified value for safe insertion into markup or attribute strings.

The value is coerced with `String(value ?? '')`, so null and undefined become ''. is_attr selects between two shared module-level /g regexes: ATTR_REGEX matches &, " and <, CONTENT_REGEX matches only & and <, so a double quote passes through unescaped in content mode. pattern.lastIndex is reset to 0 at each call because the regexes carry state across calls. The loop advances via pattern.test, splicing '&amp;', '&quot;', or '&lt;' at each match position and concatenating the untouched tail at the end. No explicit exception handling; a throwing String coercion would propagate. Compiler serialization passes and the server runtime use it for text, class/style, and attribute output.

**Notes.**

- side_effect: Mutates the shared global regexes' lastIndex, resetting it to 0 on entry, safe for sequential single-threaded use.
- condition: Double quotes are only escaped when is_attr is truthy; in content mode they are emitted verbatim.

uses: [attr](r2-svelte-codebase.md#u-12a88532ea06)

**Uncertainties.**

- A String coercion that throws (e.g. for a Symbol not caught by the ?? check) propagates; no caller-side handling is visible in this file.

<a id="u-10b29d40ea2b"></a>
### `closing_tag_omitted`

`export function closing_tag_omitted(current, next)` · [packages/svelte/src/html-tree-validation.js:L63-L74][f2]

Decides whether a closing tag can be omitted because the element autocloses.

Looks up `current` in the `autoclosing_children` map; if absent it returns false. If present, it returns true either when `next` is undefined (element is the last sibling, so the browser autocloses it) or when `next` appears in the entry's `direct` list (or `descendant` list for entries shaped with `descendant`).

**Notes.**

- condition: Only entries whose list ('direct' or 'descendant') contains `next`, or a missing `next`, yield true; the two list kinds are distinguished by the 'direct' in disallowed check.

uses: [html-tree-validation.js module code (L1–L62)][f2]

<a id="u-c5a7f2f803ff"></a>
### `is_tag_valid_with_ancestor`

`export function is_tag_valid_with_ancestor(child_tag, ancestors, child_loc, ancestor_…` · [packages/svelte/src/html-tree-validation.js:L146-L175][f2]

Validates that a tag may appear as a descendant of its ancestor, returning an error message string or null.

Custom-element child tags (containing '-') are always allowed. It takes the nearest-named ancestor as `ancestors`' last entry and reads `disallowed_children` for it; no entry means valid. For entries with `reset_by`, it walks the remaining ancestors backwards, returning null (valid) if any is a custom element or a reset tag, since a reset re-permits forbidden descendants. Only entries with a `descendant` list produce an error, formatted with optional `child_loc`/`ancestor_loc` locations; otherwise null is returned. Note the type also allows `only`-shaped entries, which this function silently treats as valid.

uses: [html-tree-validation.js module code (L74–L145)][f2]

**Uncertainties.**

- 'reset_by' only short-circuits validation; an 'only'-shaped ancestor entry never produces an ancestor-level error, which may or may not be intended.

<a id="u-a93dfa56dc6d"></a>
### `is_tag_valid_with_parent`

`export function is_tag_valid_with_parent(child_tag, parent_tag, child_loc, parent_loc)` · [packages/svelte/src/html-tree-validation.js:L186-L240][f2]

Validates a direct parent/child tag pair, returning an error message or null.

Custom elements on either side, and a `template` parent, are always allowed. It looks up `disallowed_children[parent_tag]`; if found, the outcome depends on entry shape: a `direct` hit reports 'cannot be a direct child of'; a `descendant` hit reports 'cannot be a child of'; an `only` entry allows listed children and otherwise reports 'cannot be a child of' plus the allowed-children list. When no map entry matched, structural tags are still rejected by a switch: body/caption/col/colgroup/frameset/frame/head/html are rejected outright; thead/tbody/tfoot must be in a table; td/th must be in a tr; tr must be in thead/tbody/tfoot. Any other child passes (null). Error strings embed optional location info.

uses: [html-tree-validation.js module code (L74–L145)][f2]

**Uncertainties.**

- Behavior when parent_tag is undefined besides the custom-element check is unverified: `disallowed_children[undefined]` would be undefined, but the switch messages would render 'undefined' as the parent.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/escaping.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/html-tree-validation.js
