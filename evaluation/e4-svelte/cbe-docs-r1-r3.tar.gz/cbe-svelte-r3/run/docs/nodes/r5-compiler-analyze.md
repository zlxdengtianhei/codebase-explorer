# Analysis Phase

**Capability.** Walks the parsed AST to validate template and CSS correctness, resolve references, and attach metadata (dynamic flags, global selectors, delegatable events, snippet hoisting) that the transform phases rely on.

Use when adding validation or metadata propagation. CSS analysis is its own visitor set over the stylesheet; JS/template visitors handle expressions, attributes, blocks, and shared element checks. check_graph_for_cycles is a generic helper used within this phase.

**Children.**

- [CSS Analysis](r5-analyze-css.md) `r5-analyze-css` · 10 unit(s)
- [AST Analysis Visitors](r5-analyze-visitors.md) `r5-analyze-visitors` · 19 unit(s)

**Depends on.**

- [Template Parsing](r5-compiler-parse.md) · model-inferred · 0 edge(s)

**Depended on by.**

- [Client Codegen Visitors](r5-transform-client.md) · model-inferred · 0 edge(s)

Parent: [Compiler Pipeline](r5-compiler.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
