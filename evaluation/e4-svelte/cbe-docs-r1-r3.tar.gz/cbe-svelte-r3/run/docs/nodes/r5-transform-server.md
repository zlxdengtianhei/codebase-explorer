# Server Codegen Visitors

**Capability.** Serializes components into synchronous server payload statements: rune call substitution, $derived field reads as method calls, slot rendering, and inline component/svelte:self serialization into the shared payload template.

Use when changing SSR output. build_inline_component is the shared serializer that SvelteComponent and SvelteSelf delegate to; CallExpression and MemberExpression rewrite runes and derived fields for the non-reactive server target.

**Depends on.**

- [Compiler State & AST Utilities](r5-compiler-state-utils.md) · graph-confirmed · 1 edge(s)
- [Server Runtime](r5-runtime-server.md) · model-inferred · 0 edge(s)

**Depended on by.**

- [Transform Entry & Result Assembly](r5-transform-entry.md) · model-inferred · 0 edge(s)

Parent: [Transform Phase](r5-compiler-transform.md)

## Units (6)

<a id="u-095e9ef68802"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/CallExpression.js:CallExpression`

`export function CallExpression(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/CallExpression.js:L12-L54][f1]

Replaces server-side rune calls with static or runtime substitutes.

`$host` becomes void 0, `$effect.tracking` false, `$effect.root` an empty arrow (mimicking a cleanup function), `$effect.pending` literal 0. `$state`/`$state.raw` return the visited first argument or void 0 when argumentless. `$derived` wraps the visited argument in a thunk passed to `$.derived`; `$derived.by` passes the function directly. `$state.snapshot` becomes `$.snapshot(arg)` with a trailing `true` only when the `state_snapshot_uncloneable` warning is ignored. `$inspect`/`$inspect().with` delegates to transform_inspect_rune. Any other call falls through to context.next() with no return value, so the result of the default visitor is used.

calls: [transform_inspect_rune](r2-client-transform.md#u-f64464c8fc01), [is_ignored](r5-compiler-state-utils.md#u-468324b42cee), [get_rune](r4-compiler-scope.md#u-5204b6ce4f7a)

**Uncertainties.**

- Argument-count assumptions (e.g. node.arguments[0] typed but unguarded for $derived/$state.snapshot) are not validated in this file.

<a id="u-21f5ba0822c6"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/MemberExpression.js:MemberExpression`

`export function MemberExpression(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/MemberExpression.js:L9-L23][f2]

Turns reads of private `$derived` class fields into method calls in runes mode.

When the object is `this`, the property is a PrivateIdentifier, and state_fields contains a `#name` entry of kind `$derived` or `$derived.by`, the member expression is wrapped as `b.call(node)`, i.e. `this.#x()` invoking the generated getter/setter method. All other member expressions continue via context.next().

**Uncertainties.**

- Optional chaining on context.state.state_fields implies it may be absent; behavior in that case is the default traversal.

<a id="u-d7c757c85a8a"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/SlotElement.js:SlotElement`

`export function SlotElement(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/SlotElement.js:L11-L54][f3]

Renders a <slot> element as a `$.slot($$payload, $$props, name, props, fallback)` call surrounded by empty hydration comments.

Attributes split into spreads and normal attributes: the `name` attribute becomes the slot-name literal (defaulting to 'default'); the `slot` attribute is ignored; others become object properties via build_attribute_value. With spreads, props become `$.spread_props([propsObject, ...spreadVisits])`. Fallback content becomes a thunk of the visited fragment, or null when the fragment is empty.

calls: [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/utils.js:build_attribute_value](r2-server-transform.md#u-8ce176223a22)

<a id="u-f0eb98c41b5a"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/SvelteComponent.js:SvelteComponent`

`export function SvelteComponent(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/SvelteComponent.js:L10-L12][f4]

Handles a <svelte:component> node by visiting its expression (the dynamic component reference) and delegating to build_inline_component with the resulting expression.

calls: [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/component.js:build_inline_component](r5-transform-server.md#u-cca955f8230f)

<a id="u-e627a2f894c8"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/SvelteSelf.js:SvelteSelf`

`export function SvelteSelf(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/SvelteSelf.js:L10-L12][f5]

Handles a <svelte:self> node by delegating to build_inline_component with an identifier of the enclosing component's name from state.analysis.

calls: [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/component.js:build_inline_component](r5-transform-server.md#u-cca955f8230f)

<a id="u-cca955f8230f"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/component.js:build_inline_component`

`export function build_inline_component(node, expression, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/component.js:L73-L317][f6]

Serializes an inline component into server payload statements: collects attributes into a props expression, groups children into slot functions, and emits a call into context.state.template.

Attribute handling: LetDirectives go into lets.default unless a 'slot' attribute exists on the component itself; SpreadAttributes are visited and pushed as raw expressions; Attributes named '--*' become custom_css_props entries; a 'children' attribute sets has_children_prop; other attributes are built via build_attribute_value and pushed as init props. BindDirective (not 'this'): a SequenceExpression yields get/set pairs hoisted into vars in context.state.init pushed immediately; otherwise getter/setter props are delayed (via push_prop delay) until after all other props so spreads cannot overwrite them; setters assign $$value and set $$settled = false. Children: SnippetBlocks are visited into a separate snippet_declarations list and pushed as name: name props plus $$slots entries ('children' maps to 'default'). Element children are grouped by their 'slot' attribute (default otherwise); SvelteFragment LetDirectives join lets.default. Each non-empty slot is visited as a synthetic fragment — default slot uses the component scope (child_state), named slots use node.metadata.scopes[slot_name] — producing an arrow function with a $$payload parameter plus an object pattern from its LetDirectives (shorthand, object/array destructuring, or plain expression). Default-slot output: with no children prop, no lets.default, and no fragment LetDirectives, the slot function becomes the children prop (wrapped in $.prevent_snippet_stringification when dev) and $$slots.default is set true; if lets exist, $$slots.default gets the slot and children becomes $.invalid_default_snippet; with a children prop the plain $$slots route is used. The call uses b.maybe_call for SvelteComponent, b.call otherwise, wrapped in $.spread_props when spreads exist. Output: custom_css_props trigger a $.css_props call (namespace 'svg' yields literal false, otherwise true; final arg true only when dynamic); otherwise an empty_comment is pushed only when dynamic (SvelteComponent or dynamic Component), the statement always, and a trailing empty_comment unless skip_hydration_boundaries.

calls: [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/utils.js:build_attribute_value](r2-server-transform.md#u-8ce176223a22), [is_element_node](r4-compiler-node-model.md#u-0d9a79ad394a)

**Uncertainties.**

- Output of context.visit for spreads and slot fragments depends on visitors outside this file

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/CallExpression.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/MemberExpression.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/SlotElement.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/SvelteComponent.js
[f5]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/SvelteSelf.js
[f6]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/component.js
