# Svelte Repository

**Capability.** Umbrella for the Svelte 5 codebase: a multi-phase compiler, client and server runtimes, shared runtime utilities, public reactive APIs and typings, and repository tooling. Children are grouped by responsibility rather than directory layout.

Start here to navigate. Compiler subtrees cover source-to-output compilation; runtime subtrees cover client and server execution; public-api covers user-facing modules; tooling covers benchmarks, playground scripts, and lint configuration.

**Children.**

- [Compiler](r1-compiler.md) `r1-compiler` · 0 unit(s)
- [Client Runtime](r1-client-runtime.md) `r1-client-runtime` · 0 unit(s)
- [Server Runtime](r1-server-runtime.md) `r1-server-runtime` · 12 unit(s)
- [Shared Runtime Utilities](r1-shared-runtime.md) `r1-shared-runtime` · 6 unit(s)
- [Public & Authoring APIs](r1-public-api.md) `r1-public-api` · 0 unit(s)
- [Repository Tooling](r1-tooling.md) `r1-tooling` · 0 unit(s)

Parent: [Svelte Repository](svelte-repo.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
