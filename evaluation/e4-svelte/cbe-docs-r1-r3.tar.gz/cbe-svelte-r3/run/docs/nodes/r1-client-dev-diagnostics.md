# Dev Diagnostics & HMR

**Capability.** Development-mode diagnostics and hot reloading: generated console.warn emitters with svelte.dev links, generated internal error throwers, dev-time validation of bindings and each-block keys, state-aware console logging, effect-tree debug printing, and HMR component wrappers with metadata sources.

Use when a dev-mode warning, internal error, or HMR update misbehaves. The warning/error emitters are generated code keyed by message code; hmr creates replaceable component wrappers.

**Depends on.**

- [Reactivity Type Contracts](r1-client-reactivity-types.md) · model-inferred · 0 edge(s)
- [Client Transform](r1-client-transform.md) · graph-confirmed · 1 edge(s)
- [Shared Runtime Utilities](r1-shared-runtime.md) · graph-confirmed · 1 edge(s) · state-aware console logging snapshots values via the shared $state.snapshot helper.

Parent: [Client Runtime](r1-client-runtime.md)

## Units (11)

<a id="u-a21b565811ae"></a>
### `warnings.js-warning-emitters`

`export function assignment_value_stale(property, location)` · [packages/svelte/src/internal/client/warnings.js:L13-L19][f1]

Generated dev-mode warning emitters; each function prints a formatted console.warn when DEV is true — with %c bold/normal styling, the message text, and a https://svelte.dev/e/<code> link — and otherwise a single-line console.warn of just the URL.

They never throw and return nothing. Two functions vary their message on an optional location argument: binding_property_non_reactive and hydration_html_changed include the location only when truthy; hydration_mismatch similarly interpolates a location when provided. invalid_raw_snippet_render, select_multiple_invalid_value, lifecycle_double_unmount, and svelte_boundary_reset_noop take no parameters; the rest interpolate their arguments (property names, operators, handlers, display values, etc.) into the message.

<a id="u-975a4343c8d1"></a>
### `errors-js`

`export function async_derived_orphan()` · [packages/svelte/src/internal/client/errors.js:L11-L21][f2]

Generated error-throwing helpers for the Svelte client runtime; each function raises a single internal error for a specific misuse (orphan async $derived, invalid binds, legacy component API use, effect-lifecycle violations, state mutations, hydration failure, and so on).

Every function shares one shape: under DEV it builds an Error whose message contains the error code, a full human-readable explanation, and a docs URL, sets error.name to 'Svelte error', and throws it; in production builds it throws a bare Error containing only the docs URL. Parameterized helpers interpolate their arguments into the DEV message (e.g. each_key_duplicate omits the key text when its third argument is falsy). All functions are typed @returns {never}, so callers can treat them as terminal; they never return and never swallow errors. The file also re-exports everything from '../shared/errors.js'.

imports: [errors.js module code (L1–L10)][f2]

**Uncertainties.**

- Whether callers rely on the 'never' return for control-flow narrowing is not visible in this file.

<a id="u-c7a0dea89b16"></a>
### `packages/svelte/src/internal/client/validate.js:validate_binding`

`export function validate_binding(binding, get_object, get_property, line, column)` · [packages/svelte/src/internal/client/validate.js:L48-L83][f3]

Development-time check that a bound property is reactive, running inside an outer render_effect that short-circuits once a warning was issued (warned flag) and skips store subscriptions entirely, because capture_store_binding reports is_store_sub for store bindings.

The filename comes from dev_current_component_function[FILENAME] and may be undefined. It builds an inner render_effect that reads object[property] guarded by a ran flag (so it reads at most once), then inspects effect.deps: when null, the read created no dependency, so the property is deemed non-reactive and w.binding_property_non_reactive is called with a location string filename:line:column, and warned is set to suppress repeats.

**Notes.**

- contract: The technique assumes a getter has a corresponding setter; the code comments acknowledge this can misclassify in extreme edge cases.

calls: [render_effect](r4-runtime-effects.md#u-bbe822faa096), [store.js-store-binding-flag](r3-client-stores.md#u-cba0e706248c)

**Uncertainties.**

- Whether effect.deps is reliably null exactly for non-reactive properties depends on render_effect internals not shown here

<a id="u-8e0376d25fe3"></a>
### `validate_each_keys`

`export function validate_each_keys(collection, key_fn)` · [packages/svelte/src/internal/client/validate.js:L14-L39][f3]

Detects duplicate each-block keys by running the check inside a render_effect, so it re-runs whenever the collection changes.

Each pass evaluates collection(); non-array iterables are converted with Array.from and null/undefined becomes an empty array. It computes key_fn(item, i) per element; on the first repeated key it reports the earlier index and current index as strings via e.each_key_duplicate, passing a null key when the stringified key starts with '[object ' (so object keys are not dumped into the message). It records the latest index per key and continues scanning, potentially reporting multiple duplicates in one pass.

calls: [render_effect](r4-runtime-effects.md#u-bbe822faa096); raises: [validate_each_keys](r1-client-dev-diagnostics.md#u-8e0376d25fe3)

**Uncertainties.**

- Whether the render_effect teardown removes the check when the each block is destroyed is not shown here

<a id="u-5bbd41443b98"></a>
### `log_if_contains_state`

`export function log_if_contains_state(method, ...objects)` · [packages/svelte/src/internal/client/dev/console-log.js:L10-L35][f4]

Logs a dev console snapshot only if at least one logged argument contains reactive state.

Inside untrack and a try/catch (swallowing all errors, e.g. from snapshotting), each object argument is tested for STATE_SYMBOL: matching objects are deep-copied via snapshot(obj, true) so the log is not a live reference, others pass through unchanged. If any object contained state, it warns via console_log_state(method) and console.logs the transformed values with a grey '[snapshot]' prefix. Returns the original arguments object unchanged, so the forwarded console call behaves normally.

**Notes.**

- side_effect: Errors thrown while transforming or logging are silently discarded by the empty catch.

calls: [runtime-js-state-and-helpers](r2-reactivity-core.md#u-6cd2387802ec), [packages/svelte/src/internal/shared/clone.js:snapshot](r1-shared-runtime.md#u-bfcc537be9f1)

**Uncertainties.**

- Whether STATE_SYMBOL detection is authoritative for all reactive objects depends on the constant's placement, defined outside this file.

<a id="u-6ce1166c77be"></a>
### `packages/svelte/src/internal/client/dev/debug.js:root`

`export function root(effect)` · [packages/svelte/src/internal/client/dev/debug.js:L20-L26][f5]

Walks the effect parent chain until it reaches the effect whose parent is null and returns it, yielding the root of an effect tree for debug output.

<a id="u-59857bcd3283"></a>
### `log_dep`

`function log_dep(dep)` · [packages/svelte/src/internal/client/dev/debug.js:L101-L119][f5]

Prints one dependency in the effect-tree debug output.

If the dep has the DERIVED flag, it opens a collapsed console group showing the derived's current value and recursively logs its own deps; otherwise it logs 'state' with the value. Recursion terminates because derived dependency chains are finite.

uses: [log_effect_tree](r1-client-dev-diagnostics.md#u-ab08fa8f28ca)

<a id="u-ab08fa8f28ca"></a>
### `log_effect_tree`

`export function log_effect_tree(effect, depth = 0)` · [packages/svelte/src/internal/client/dev/debug.js:L32-L95][f5]

Recursively prints an effect tree to the console as nested console groups for dev debugging.

Chooses a label by flag priority (root, boundary, block, async, branch, render effect, effect; otherwise '(unknown)') and a status of clean/maybe dirty/dirty from the CLEAN and MAYBE_DIRTY flags, bolding non-clean groups. At depth 0 it logs a callsite extracted from a synthetic Error stack (stripping query strings); deeper levels log the effect function inside a collapsed group. If deps exist, each is printed via the recursive log_dep. Children are traversed via first/next sibling pointers, and each recursion level opens and closes exactly one console.group.

**Notes.**

- side_effect: Unbalanced console groups would result if console.group/groupEnd calls throw, but the code assumes they do not.

calls: [log_dep](r1-client-dev-diagnostics.md#u-59857bcd3283)

**Uncertainties.**

- The callsite regex assumes the V8 stack frame layout; on engines with different stack formats the second line may not parse as intended.

<a id="u-0e08a21e78a3"></a>
### `hmr`

`export function hmr(original, get_source)` · [packages/svelte/src/internal/client/dev/hmr.js:L15-L20][f6]

Creates an HMR-compatible replacement component function for a compiled component.

Returns a wrapper that renders the current component into a shared instance object and exposes HMR metadata (the original component and a reactive source) that the update machinery writes to trigger re-rendering.

uses: [packages/svelte/src/internal/client/dev/hmr.js:hmr](r1-client-dev-diagnostics.md#u-b4a8f0df9ee8)

<a id="u-b4a8f0df9ee8"></a>
### `packages/svelte/src/internal/client/dev/hmr.js:hmr`

`export function hmr(original, get_source)` · [packages/svelte/src/internal/client/dev/hmr.js:L62-L78][f6]

After defining the wrapper, hmr stamps it with the original's FILENAME and an HMR metadata object holding the original component and a reactive source created from it; per the inline comment, update tooling reassigns this source, and the wrapper's block reads it to re-instantiate the component.

calls: [source](r5-client-reactivity.md#u-97497b70f31b); uses: [wrapper](r1-client-dev-diagnostics.md#u-03c1cd54bccf)

<a id="u-03c1cd54bccf"></a>
### `wrapper`

`function wrapper(anchor, props)` · [packages/svelte/src/internal/client/dev/hmr.js:L20-L62][f6]

The component stand-in created by hmr.

Renders inside an EFFECT_TRANSPARENT block that reads the current component from get_source(); on each re-run it deletes all keys of the shared instance object, destroys the previous branch effect, and creates a new branch instantiating the component (with new when the wrapper is new'd, per new.target), copying its property descriptors onto the instance so getters/setters survive replacement. On re-renders after the first, set_should_intro(false/true) suppresses transitions around replacement. If hydrating, the anchor is replaced by hydrate_node before returning. Returns the instance object, which stays identity-stable across updates. The wrapper also carries FILENAME copied from the original.

**Notes.**

- side_effect: Mutates the shared instance object in place rather than replacing it, preserving references held by consumers.

calls: [packages/svelte/src/internal/client/reactivity/effects.js:block](r4-runtime-effects.md#u-75d755e7c63c), [branch](r4-runtime-effects.md#u-cfe4a1f5ddba), [destroy_effect](r4-runtime-effects.md#u-214ad59ce57a), [set_should_intro](r3-client-render.md#u-cbadffbbf083), [packages/svelte/src/internal/client/runtime.js:get](r2-reactivity-core.md#u-98099fbbf12a); uses: [function::hydrating::0][f7]

**Uncertainties.**

- Whether instance retains prototype methods other than own enumerable properties depends on Object.getOwnPropertyDescriptors coverage, which only copies own properties.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/warnings.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/errors.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/validate.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dev/console-log.js
[f5]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dev/debug.js
[f6]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dev/hmr.js
[f7]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/hydration.js
