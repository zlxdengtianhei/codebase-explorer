# Repository Tooling

**Capability.** Developer tooling around the library: reactivity and SSR benchmarks, playground sandbox scripts for downloading apps and generating share URLs with a dev SSR server, and the repository's flat ESLint configuration including a rule that reports compiler references in scanned source.

Use this subtree when working on repo workflows rather than library behavior; none of it ships in the compiled packages.

**Children.**

- [Benchmarks](r1-benchmarks.md) `r1-benchmarks` · 4 unit(s)
- [Playground Sandbox](r1-playground-sandbox.md) `r1-playground-sandbox` · 6 unit(s)
- [ESLint Configuration](r1-eslint-config.md) `r1-eslint-config` · 2 unit(s)

Parent: [Svelte Repository](r1-svelte-monorepo.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
