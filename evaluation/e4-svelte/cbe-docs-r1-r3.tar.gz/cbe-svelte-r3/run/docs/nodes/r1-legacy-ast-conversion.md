# Legacy AST Conversion

**Capability.** Walks the modern Svelte AST with zimmerframe and rebuilds the Svelte 4 legacy AST node by node, trimming surrounding whitespace text nodes along the way.

Use for Svelte 4 compatibility output. The convert group drives the rewrite; remove_surrounding_whitespace_nodes is its whitespace-normalization helper, called repeatedly from it.

Parent: [Parse Phase](r1-compiler-parse.md)

## Units (2)

<a id="u-4723dd340fbf"></a>
### `legacy-js-convert`

`export function convert(source, ast)` · [packages/svelte/src/compiler/legacy.js:L42-L47][f1]

convert walks the modern Svelte AST with zimmerframe and rebuilds the Svelte 4 legacy AST node by node.

A generic `_(node, { next })` handler deletes node.metadata from every visited node. Simple handlers spread the node with a renamed legacy type: AnimateDirective→Animation, BindDirective→Binding, ClassDirective→Class, HtmlTag→RawMustacheTag, OnDirective→EventHandler, SpreadAttribute→Spread, TransitionDirective→Transition, UseDirective→Action, LetDirective→Let. Root reinserts the raw svelte:options node into the fragment at the first child whose start is at or after options.end (appending when none fits), computes html start/end by skipping whitespace in the source around the first/last child, strips attributes from instance and module, and returns {html, instance, module, css}. AwaitBlock builds Pending/Then/Catch child blocks with null start/end and skip=true, filling positions from child nodes when present, otherwise guessing from the source via indexOf/lastIndexOf of '}' after the expression, chaining earlier blocks' ends as fallbacks and setting skip=false when a block exists. EachBlock and IfBlock build an ElseBlock (IfBlock collapsing a single elseif IfBlock into the alternate's consequent nodes), trim surrounding whitespace via remove_surrounding_whitespace_nodes, and derive start/end by scanning the source for the preceding '{'; an elseif IfBlock's start comes from its consequent's first node or that fallback. ConstTag returns the node unchanged when expression is already set, otherwise converts the const declaration into an AssignmentExpression whose start offsets past 'const '. ExpressionTag becomes AttributeShorthand when its parent is an Attribute whose source starts with '{', otherwise MustacheTag. Text returns a fresh node (without raw) only inside a style RegularElement and otherwise lets the default walk proceed. Comment adds ignores from extract_svelte_ignore of the comment text. ComplexSelector calls next() first, then flattens children into combinators plus selectors as a 'Selector'. Attribute and StyleDirective wrap a non-true, non-array value into a single-element array — pushing/popping the node on the walk path around visit — and otherwise pass through via next(). StyleSheet spreads its node with context.next()'s result and type 'Style'. SvelteElement unwraps a string Literal tag to a plain string unless the preceding source character is '{'. Element-like nodes (Component, RegularElement, SlotElement, SvelteBody/Component/Document/Fragment/Head/Options/Self/Window, TitleElement, SvelteBoundary, SnippetBlock, KeyBlock) map attributes and fragment/body children through visit into legacy-typed containers; SvelteBoundary and SnippetBlock also trim surrounding whitespace, and SnippetBlock carries typeParams.

calls: [remove_surrounding_whitespace_nodes](r1-legacy-ast-conversion.md#u-f51ce07da951), [extract_svelte_ignore](r2-compiler-foundations.md#u-4a9ee4fb9b67)

**Uncertainties.**

- AwaitBlock start/end guessing via indexOf/lastIndexOf assumes '}' occurrences in the source correspond to block delimiters; edge cases for empty blocks are inferred, not proven

<a id="u-f51ce07da951"></a>
### `remove_surrounding_whitespace_nodes`

`function remove_surrounding_whitespace_nodes(nodes)` · [packages/svelte/src/compiler/legacy.js:L16-L34][f1]

Trim surrounding whitespace Text nodes from a children array in place.

If the first node is Text whose data has no non-whitespace it is shifted off; otherwise leading whitespace is cut from its data. The same is applied to the last node with trailing whitespace. Mutates the array and Text nodes rather than copying.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/legacy.js
