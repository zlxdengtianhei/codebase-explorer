# Accessibility Checks

**Capability.** Runs the full family of a11y warning checks on element nodes during analysis, backed by a module-load-time dataset of roles, ARIA/AXObject classifications, and implicit-role maps built from aria-query and axobject-query.

Use when an accessibility warning is wrong or missing. check_element orchestrates all checks via the private helper group; constants.js owns the rule data.

**Depends on.**

- [Compiler Warning Infrastructure](r1-compiler-diagnostics-infrastructure.md) · model-inferred · 0 edge(s)

Parent: [Analyze Phase](r1-compiler-analyze.md)

## Units (4)

<a id="u-0f7a175a707e"></a>
### `check_element`

`export function check_element(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/shared/a11y/index.js:L56-L454][f1]

Runs the full set of a11y warning checks on one element node during analysis.

It first scans attributes once to build an attribute map, a handler-name set (from on:* attributes via is_event_attribute and OnDirective names), and flags: spread present, contenteditable attribute, contenteditable binding. A second pass per static Attribute applies rule families: for aria-* names it warns on invisible elements, unknown attributes (with a fuzzymatch suggestion), aria-hidden on headings, validates the value against the aria schema, and requires tabindex for aria-activedescendant on non-interactive, non-spread elements. For name='role' it splits the static value on whitespace and, per role token, checks abstract/unknown roles, redundant roles (with exceptions for ul/ol/li, href-less anchors, and header/footer nested under section/article via is_parent), required ARIA props per role (skipped for dynamic elements, spreads, or is_semantic_role_element matches), interactive-supports-focus, and interactive↔noninteractive role misuse. Element-level checks follow: click-events-have-key-events (click handler without keydown/keyup/keypress), no-noninteractive-tabindex (tabindex >= 0 or dynamic), role-supports-aria-props against explicit or implicit role, no-noninteractive-element-interactions and no-static-element-interactions when recommended/interactive handlers appear, mouseover/mouseout without focus/blur, and positive tabindex. The per-tag switch (the s1 region) adds: anchor/button explicit-label and href validity ('', '#', or javascript:-prefixed), falling back to missing-href unless id/name/aria-disabled are set; input type=image alt requirements and autocomplete validity; img redundant alt; label requiring for or a labelable/slot child (walked by the nested has_input_child); video caption-track check that returns early when muted or aria-hidden; figcaption parent/index placement. Finally it checks a11y_required_attributes (skipped for anchors), distracting elements, and required content for headings unless labelled, spread, or contenteditable-bound. Warnings are emitted via w.* functions; no exceptions are caught.

**Notes.**

- condition: Any SpreadAttribute suppresses most checks (has_spread), and SvelteElement nodes (dynamic elements) suppress dynamic-sensitive checks like role required props and interactivity checks.
- side_effect: Sole observable effect is emission of compiler warnings; no node mutation occurs.

calls: [index-js-check-element-helpers](r1-a11y-checks.md#u-f54c287400bc), [fuzzymatch](r4-compiler-parse.md#u-4d517976b3f9), [ast-js-attribute-helpers](r4-compiler-ast-utils.md#u-e05972fa52ab), [utils-js-predicates](r3-shared-utils.md#u-7eb274f609ad), [list](r2-compiler-foundations.md#u-5617f591c677)

**Uncertainties.**

- Behavior of the w.* warning functions and of non-static (expression) attribute values depends on code outside this file; only static-value semantics visible here are described.
- The split between check_element regions s0 and s1 is a listing artifact; both belong to one function and are documented together.

<a id="u-4f7bb2386515"></a>
### `packages/svelte/src/compiler/phases/2-analyze/visitors/shared/a11y/index.js:index.js module code (L1–L55)`

`module_region` · [packages/svelte/src/compiler/phases/2-analyze/visitors/shared/a11y/index.js:L1-L55][f1]

Import declarations for constants, aria-query/axobject-query data, regex patterns, AST utilities, and warning functions used by the a11y checks.

<a id="u-0304f5d2800a"></a>
### `constants.js module code (L1–L319)`

`module_region` · [packages/svelte/src/compiler/phases/2-analyze/visitors/shared/a11y/constants.js:L1-L319][f2]

Builds the a11y rule dataset: static token lists, implicit-role maps, and role/AXObject classification schemas derived from aria-query and axobject-query at module load.

**Notes.**

- side_effect: Module initialization iterates elementRoles/elementAXObjects and mutates exported schema arrays; classification depends on the installed aria-query/axobject-query package data.
- condition: non_interactive_roles excludes 'toolbar','tabpanel','generic','cell' (treated as interactive) and appends 'progressbar' despite widget descent; interactive_roles additionally drops 'generic'.

**Uncertainties.**

- Exact contents of roles_map/AXObjects and thus the derived role/AXObject schema arrays are not visible; they depend on the aria-query/axobject-query package data.

<a id="u-f54c287400bc"></a>
### `index-js-check-element-helpers`

`function is_presentation_role(role)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/shared/a11y/index.js:L557-L559][f1]

Private helpers in index.js that check_element relies on.

Interactivity classifiers: element_interactivity returns Interactive, NonInteractive, or Static by probing interactive/AXObject role schemas via match_schema, which matches the tag name and, when the schema lists attributes, requires each to exist and (if the schema has a value) to equal its static text value; 'header' is excluded from the non-interactive role-schema branch. is_interactive_element, is_non_interactive_element, and is_static_element are thin comparisons against that result. Role tests is_presentation_role, is_non_interactive_roles, is_interactive_roles, and is_abstract_role are membership checks into the constants.js arrays. is_semantic_role_element walks elementAXObjects: when the schema tag matches and every schema attribute is present with the expected static value, it checks whether any AXObject role list contains the queried role. is_hidden_from_screen_reader is true for input type=hidden, and for aria-hidden when its value is dynamic (returns true to play safe), true, or 'true'. has_disabled_attribute is true when disabled is truthy or aria-disabled is the string 'true'. Static readers: get_static_value returns true for a bare attribute, the first text-chunk data for text attributes, otherwise null; get_static_text_value additionally maps true to null. Implicit roles: get_implicit_role dispatches menuitem and input to menuitem_implicit_role and input_implicit_role (which map static type values through the constants maps, with 'combobox' when a list attribute coexists with an email/search/tel/text/url type) and falls back to a11y_implicit_semantics. is_valid_autocomplete rejects bare-true values, trims/lowercases and strips optional section-*, address-type, and autofill field tokens (or contact-type plus contact field tokens, failing otherwise), optionally strips 'webauthn', and passes only when no tokens remain. has_content recursively scans fragment nodes: whitespace-only text is skipped; an img with an alt attribute counts as content; child elements recurse, and non-element nodes count as content by assumption. is_parent scans the path backwards, returning true on any SvelteElement (unknown, so suppress warnings), otherwise whether the nearest RegularElement is in the list, false at the root. validate_aria_attribute_value type-checks a static aria value against the schema: a bare-true value becomes ''; per schema type it warns on empty strings (id/string/idlist), non-numbers, non-'true'/'false' booleans, non-integers, tokens or tokenlist words outside schema.values (case-insensitive), and tristate values other than true/false/mixed; a null (dynamic or absent) value skips validation. warn_missing_attribute formats the a11y_missing_attribute warning, choosing 'an'/'a' by vowel or href and joining multiple attribute names with 'or'.

**Notes.**

- contract: has_input_child walks the label subtree with zimmerframe, treating SvelteElement, SlotElement, Component, RenderTag, labelable RegularElements, and plain slot elements as an associated control; the walk's next() callback continues descent only otherwise.
- condition: has_content deliberately counts unknown nodes as content (per its comment) so empty dynamic blocks can produce false negatives in missing-content warnings.

uses: [constants.js module code (L1–L319)](r1-a11y-checks.md#u-0304f5d2800a); calls: [ast-js-attribute-helpers](r4-compiler-ast-utils.md#u-e05972fa52ab), [list](r2-compiler-foundations.md#u-5617f591c677)

**Uncertainties.**

- has_content returns undefined when the loop finishes without a decisive node; callers compare only with truthiness, so the effective result is boolean.
- AXObjectRoles/elementAXObjects semantics come from the axobject-query package and are not visible here.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/shared/a11y/index.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/shared/a11y/constants.js
