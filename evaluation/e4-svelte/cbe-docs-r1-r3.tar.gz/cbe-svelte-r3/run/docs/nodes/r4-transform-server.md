# Server (SSR) Code Transformation

**Capability.** Phase-3 server lowering: emits snippets as $$payload functions, renders dynamic svelte:element statements, strips rune wrappers from class properties, and expands $state destructuring declarations into server-side declarators.

Use these visitors to understand what SSR output looks like for a given construct. The variable-declaration path is mode-aware (runes vs legacy) and relies on scope-generated temporaries and AST path extraction.

**Depends on.**

- [AST Manipulation Utilities](r4-compiler-ast-utils.md) · graph-confirmed · 4 edge(s)
- [Scope and Binding Model](r4-compiler-scope.md) · graph-confirmed · 9 edge(s)

Parent: [Compiler Pipeline](r4-compiler.md)

## Units (5)

<a id="u-518018776eef"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/PropertyDefinition.js:PropertyDefinition`

`export function PropertyDefinition(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/PropertyDefinition.js:L10-L37][f1]

Strips rune wrappers from class property initializers in runes mode.

For a value that is a CallExpression: `$state`/`$state.raw` keep the property with its first argument visited as the initializer, or null (no initializer) when argumentless; `$derived`/`$derived.by` visit the first argument (a function) and wrap it in `$.derived(...)`, again null when argumentless — note the argument is visited before the argumentless check, so a `$derived.by` with no args would visit undefined's arguments[0] path first, an ordering quirk. Non-rune properties and non-runes mode continue via context.next().

calls: [get_rune](r4-compiler-scope.md#u-5204b6ce4f7a)

**Uncertainties.**

- For $derived/$derived.by, node.value.arguments[0] is visited before the length===0 null check; behavior with zero arguments is therefore questionable but not exercised here.

<a id="u-80641b90f11d"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/SnippetBlock.js:SnippetBlock`

`export function SnippetBlock(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/SnippetBlock.js:L11-L29][f2]

Emits a snippet as a function declaration taking `$$payload` plus the declared parameters, with the visited body.

The function is pushed either to hoisted statements (when metadata.can_hoist) or component init. A `___snippet` flag is set on the function for legacy `$$render_inner` binding support. In dev, a `$.validate_snippet_args($$payload)` check is prepended to the body and `$.prevent_snippet_stringification(fn.id)` is pushed alongside.

**Uncertainties.**

- Consumers of the `___snippet` hack are outside this file.

<a id="u-efff830ecb5a"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/SvelteElement.js:SvelteElement`

`export function SvelteElement(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/SvelteElement.js:L15-L75][f3]

Renders a dynamic <svelte:element> as a `$.element($$payload, tag, attributesThunk?, childrenThunk?)` statement.

The tag expression is visited; in dev, non-identifier tags are cached in a const (to avoid double-evaluating getters/calls) and validation calls `$.validate_void_dynamic_element` (only when the fragment has nodes) and `$.validate_dynamic_element_tag` are pushed to init. Attributes are rendered via build_element_attributes into a fresh state; dev also brackets with `$.push_element`/`$.pop_element` including source location. The attributes and children blocks are each passed as thunks only when non-empty, otherwise false.

calls: [build_element_attributes](r3-server-transform.md#u-50884bbfafdd), [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/utils.js:build_template](r2-server-transform.md#u-303aa62127d6), [determine_namespace_for_children](r2-client-transform.md#u-fca641f4927b), [Scope](r4-compiler-scope.md#u-01a82e58170d)

<a id="u-4d51e6360b98"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/VariableDeclaration.js:VariableDeclaration`

`export function VariableDeclaration(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/VariableDeclaration.js:L15-L36][f4]

Transforms variable declarations differently for runes and legacy modes, returning b.empty when all declarations are eliminated.

In runes mode each declarator is dispatched by its initializer's rune: no rune, or `$effect.tracking`/`$inspect`/`$effect.root`, keeps the visited declarator as-is; `$props.id` is dropped entirely; `$props` rewrites the pattern to bind from `$$props`, stripping `$bindable()` defaults to their argument (or void 0), and — to hide internals — splices `$$slots`/`$$events` properties into a rest-bearing ObjectPattern or, for a plain identifier, rebuilds the pattern as `{ $$slots, $$events, ...name }` (using `$$slots_` as the local slots name when the analysis uses slots). `$derived.by` becomes a call of the visited function; an Identifier id for other runes keeps `id = value` (value being the visited first argument or void 0); `$derived` with a pattern visits the pattern; remaining `$state` cases destructure via create_state_declarators. In legacy mode, bindings decide: no state/prop bindings keep the declarator; bindable props become `$$props` reads with `??` fallbacks (build_fallback), honoring prop_alias and, for non-identifier patterns, extracting leaf paths into temp/`$$array` declarators; state bindings go through create_state_declarators.

**Notes.**

- side_effect: The inner walk visitors mutate declarator structure only via return values; RestElement/AssignmentPattern visitors inside the $props branch set has_rest and rewrite $bindable defaults.

calls: [get_rune](r4-compiler-scope.md#u-5204b6ce4f7a)

**Uncertainties.**

- Whether the ArgumentCount assumption (rune calls always CallExpression inits) holds is guaranteed by analysis, not visible here.

<a id="u-26d37038317b"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/VariableDeclaration.js:create_state_declarators`

`function create_state_declarators(declarator, scope, value)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/VariableDeclaration.js:L194-L212][f4]

Expands a destructuring `$state` declarator into multiple declarators: a `tmp` identifier (scope-generated) holding the value, per-insert array temporaries renamed via scope.generate('$$array'), and one declarator per extracted path bound to its computed expression.

An identifier id short-circuits to a single declarator.

calls: [extract_paths](r4-compiler-ast-utils.md#u-34f2fcb20c62)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/PropertyDefinition.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/SnippetBlock.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/SvelteElement.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/VariableDeclaration.js
