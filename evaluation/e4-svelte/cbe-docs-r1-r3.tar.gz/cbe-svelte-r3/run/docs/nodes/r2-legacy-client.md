# Legacy Client Compatibility

**Capability.** Svelte 4 compatibility at runtime: the Svelte4Component class adapter (asClassComponent/createClassComponent), $on/$set simulation and event bubbling, reactive imports, and the $: run() shim, plus deprecated handler/bubbler helpers.

Use this subtree when a consumer still uses the class component API or legacy reactive statements. Svelte4Component wraps a Svelte 5 component and relies on flushSync; misc.js bridges $$props.$$events and reactive imports through the reactivity core.

**Depends on.**

- [Reactivity Core & Batching](r2-reactivity-core.md) · graph-confirmed · 4 edge(s)

Parent: [Client Runtime](r2-client-runtime.md)

## Units (10)

<a id="u-f604417484a2"></a>
### `Svelte4Component`

`class Svelte4Component` · [packages/svelte/src/legacy/legacy-client.js:L67-L79][f1]

Adapter class exposing a Svelte 5 component through the Svelte 4 class API (props proxy, $set/$on/$destroy, enumerable export accessors).

The constructor builds a Proxy over `{...options.props, $$events: {}}` that creates one mutable source per property on first access: `get` and `has` read through the source (has special-cases LEGACY_PROPS to return true, avoiding invalid-binding validation), and `set` writes the new value into the source before reflecting onto the target, reproducing coarse-grained reactivity. It mounts or (with options.hydrate) hydrates `options.component` against target/anchor/props/context/intro (default false)/recover, then conditionally calls flushSync — skipped when async_mode_flag is set, when options.props.$$host exists (custom element wrapper), or when options.sync === false. Every key of the resulting instance except $set/$destroy/$on becomes an enumerable accessor on the adapter delegating to the instance; finally `$set` is installed as `Object.assign(props, next)` and `$destroy` as `unmount(this.#instance)`. `$set` delegates to the instance's `$set`; `$on(event, callback)` appends a wrapped callback (`callback.call(this, ...)`), keyed off `props.$$events`, and returns an unsubscriber that filters the wrapper out of the event array; `$destroy` calls the instance's `$destroy`, which unmounts. Events stored in `props.$$events` (populated by the component) are read via `this.#events = props.$$events` after mount.

calls: [Svelte4Component](r2-legacy-client.md#u-f604417484a2), [render.js-mount](r3-client-render.md#u-751f047b7883), [flushSync](r2-reactivity-core.md#u-f4c4d1829672)

**Uncertainties.**

- Exact trap behavior when a prop source is set before mount (stop/start lifecycle of mutable_source) depends on internal client code not supplied.
- Behavior of hydrate vs mount argument differences beyond the visible options mapping is external.

<a id="u-0c8e95825ebe"></a>
### `asClassComponent`

`export function asClassComponent(component)` · [packages/svelte/src/legacy/legacy-client.js:L49-L51][f1]

Wraps a component function into a Svelte 4-compatible class constructor.

It returns an anonymous subclass of Svelte4Component whose constructor merges the captured `component` with any options passed to `new` and forwards them to the superclass constructor. Marked deprecated for imperative-migration use only; error paths and rendering behavior are those of Svelte4Component.

inherits: [Svelte4Component](r2-legacy-client.md#u-f604417484a2)

<a id="u-f1a6026980f8"></a>
### `createClassComponent`

`export function createClassComponent(options)` · [packages/svelte/src/legacy/legacy-client.js:L31-L34][f1]

Returns a Svelte 4-compatible component instance created by `new Svelte4Component(options)`, accepting legacy ComponentConstructorOptions plus a `component` field.

Marked deprecated as a temporary migration aid; all behavior lives in Svelte4Component's constructor. No validation is performed here.

calls: [Svelte4Component](r2-legacy-client.md#u-f604417484a2)

<a id="u-f145d0cb7490"></a>
### `createBubbler`

`export function createBubbler()` · [packages/svelte/src/legacy/legacy-client.js:L248-L268][f1]

Deprecated creator of Svelte 4-style event bubbling functions.

On creation it captures the current component_context; if none is active it raises e.lifecycle_outside_component('createBubbler'), so calling outside a component initialization fails immediately. The returned factory takes an event type and yields an event handler that looks up `active_component_context.s.$$events[type]`; if found, it snapshots the handlers (slicing arrays so mutation during dispatch is safe), invokes each with the captured component as `this`, and returns `!event.defaultPrevented`. If no handlers exist for the type, it returns true.

raises: [createBubbler](r2-legacy-client.md#u-f145d0cb7490)

**Uncertainties.**

- Whether lifecycle_outside_component throws or only reports depends on errors.js, not supplied.

<a id="u-59b2e05812ff"></a>
### `handlers`

`export function handlers(...handlers)` · [packages/svelte/src/legacy/legacy-client.js:L211-L242][f1]

Deprecated helper combining multiple EventListeners into one.

The returned function patches `event.stopImmediatePropagation` so that calling it sets a `stopped` flag and delegates to the original method, then invokes each handler with the original `this` sequentially inside try/catch. If a handler throws, the error is collected and processing continues; if stopImmediatePropagation was called, the loop breaks and later handlers are skipped. After the loop, each collected error is rethrown asynchronously via `queueMicrotask(() => { throw error })`, so handler exceptions surface as uncaught errors without preventing other handlers from running.

<a id="u-8f7bc3d6b657"></a>
### `packages/svelte/src/legacy/legacy-client.js:run`

`export function run(fn)` · [packages/svelte/src/legacy/legacy-client.js:L188-L203][f1]

Deprecated compat for the legacy `$:` reactive statement: wraps fn in a `user_pre_effect`, so on the server it runs once immediately and on the client it behaves like $effect.pre.

Inside the effect, after fn runs, if the effect was already marked DIRTY (re-dirtied during its own execution, i.e. potential infinite loop), it emulates legacy behavior: in DEV it reads the current component's FILENAME (falling back to a generic placeholder string if unavailable) and warns via w.legacy_recursive_reactive_block, then downgrades the effect status from DIRTY to MAYBE_DIRTY so it re-runs instead of erroring.

calls: [user_pre_effect](r4-runtime-effects.md#u-53bf5464d746), [runtime-js-state-and-helpers](r2-reactivity-core.md#u-6cd2387802ec)

**Uncertainties.**

- Consequences of MAYBE_DIRTY downgrade in the scheduler are defined in runtime.js, not visible here.

<a id="u-90e956bb4b67"></a>
### `reactive_import`

`export function reactive_import(fn)` · [packages/svelte/src/internal/client/dom/legacy/misc.js:L10-L22][f2]

Makes a legacy reactive import observable: creates a `source(0)` counter and returns a wrapper for the imported binding's accessor.

When called with exactly one argument it treats the call as a write: increments the source via `set(s, get(s) + 1)` and returns the argument. With zero or multiple arguments it reads the source via `get(s)` (registering the dependency in the active effect) and returns `fn()`'s value. The counter exists purely so reads create a reactive dependency.

**Notes.**

- side_effect: The one-argument path mutates the shared source, triggering dependents.

calls: [../../reactivity/sources.js](../../catalog.json), [../../runtime.js](../../catalog.json)

<a id="u-65fd4565fbf1"></a>
### `bubble_event`

`export function bubble_event($$props, event)` · [packages/svelte/src/internal/client/dom/legacy/misc.js:L30-L41][f2]

Forwards a DOM event to handlers registered on `$$props.$$events` for the event's type, with `this` preserved from the call site.

It reads the entry, which may be a single function, an array, or absent, and normalizes it to a copy of the callback list (`slice` for arrays, `[]` for null/undefined, `[fn]` otherwise), so mutation during dispatch cannot affect the current iteration. It then invokes each callback with `.call(this, event)`; exceptions from a handler abort the loop and propagate.

**Notes.**

- side_effect: Slicing arrays means handlers added during bubbling are not invoked for the in-flight event.

calls: [../../../shared/utils.js](../../catalog.json)

**Uncertainties.**

- The graph's `next()` mapping for the for-of loop has multiple unrelated candidates and does not resolve the iteration target

<a id="u-c8ba8dfaddc7"></a>
### `add_legacy_event_listener`

`export function add_legacy_event_listener($$props, event_name, event_callback)` · [packages/svelte/src/internal/client/dom/legacy/misc.js:L49-L53][f2]

Simulates `$on` for `compatibility.componentApi === 4`: ensures `$$props.$$events` exists (defaulting to `{}`), ensures a per-event array exists (defaulting to `[]`), and pushes the callback.

Mutates `$$props` in place; the created arrays are plain arrays consumed by `bubble_event`.

**Notes.**

- side_effect: Lazily creates `$$events` and its per-event arrays on `$$props`.

**Uncertainties.**

- The graph maps the `.push` receiver ambiguously to unrelated `push` functions; here it is clearly Array.prototype.push

<a id="u-d240c6a10e13"></a>
### `update_legacy_props`

`export function update_legacy_props($$new_props)` · [packages/svelte/src/internal/client/dom/legacy/misc.js:L62-L68][f2]

Simulates `$set` for `compatibility.componentApi === 4`: iterates the keys of `$$new_props` and, for each key already present on `this`, assigns the new value through normal property assignment so an accessor setter (component accessors) runs.

Keys not already on `this` are skipped, so this cannot introduce new props or update `$$props`/`$$restProps` entries, as the docstring states.

**Notes.**

- contract: Requires component accessors; plain `$$props`/`$$restProps` members are not settable this way.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/legacy/legacy-client.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/legacy/misc.js
