# Server Markup Serialization

**Capability.** Turns values into attribute markup: class/style attribute strings, spread-attribute serialization with filtering, value stringification, style-object serialization, and option-selection markers during buffering.

The server transform emits calls to these helpers for every dynamic attribute. maybe_selected/valueless_option handle <option> selection while output is buffered.

**Depends on.**

- [Shared Predicates and Hash](r3-shared-utils.md) · graph-confirmed · 1 edge(s)

**Depended on by.**

- [Server Templating Helpers](r3-server-templating.md) · model-inferred · 0 edge(s)

Parent: [Server Runtime](r3-server-runtime.md)

## Units (16)

<a id="u-a9cb571edc90"></a>
### `attr_class`

`export function attr_class(value, hash, directives)` · [packages/svelte/src/internal/server/index.js:L253-L256][f1]

Render a class attribute string from a value, scoping hash, and class directives; empty result yields ''.

**Notes.**

- condition: Result of to_class is HTML-escaped and wrapped as ' class="..."' only when non-empty.

calls: [to_class](r2-svelte-codebase.md#u-bb0adfe2b192), [escape_html](r4-shared-source-utilities.md#u-0f499dd45547)

<a id="u-1a3f35d1ee98"></a>
### `attr_style`

`export function attr_style(value, directives)` · [packages/svelte/src/internal/server/index.js:L262-L265][f1]

Render a style attribute string from a value and style directives; empty result yields ''.

calls: [to_style](r2-svelte-codebase.md#u-50b25ac26373), [escape_html](r4-shared-source-utilities.md#u-0f499dd45547)

<a id="u-809bef1eecf5"></a>
### `spread_attributes`

`export function spread_attributes(attrs, css_hash, classes, styles, flags = 0)` · [packages/svelte/src/internal/server/index.js:L172-L207][f1]

Serialize a spread attribute object into an HTML attribute string with filtering and normalization.

**Notes.**

- condition: styles are merged via to_style, class via clsx and then to_class (css_hash/classes) before iteration.
- condition: Skipped entries: function values, names starting with $$, and names matching INVALID_ATTR_NAME_CHAR_REGEX.
- condition: flags control normalization: without ELEMENT_IS_NAMESPACED names may get boolean-attribute handling, and without ELEMENT_PRESERVE_ATTRIBUTE_CASE names are lowercased.

calls: [attr](r2-svelte-codebase.md#u-12a88532ea06), [to_class](r2-svelte-codebase.md#u-bb0adfe2b192), [to_style](r2-svelte-codebase.md#u-50b25ac26373), [clsx](r2-svelte-codebase.md#u-2274c46486ff), [utils-js-predicates](r3-shared-utils.md#u-7eb274f609ad)

**Uncertainties.**

- Exact semantics of attr() (escaping, boolean rendering) live in shared attributes.js, not supplied.

<a id="u-82b1ac47166e"></a>
### `packages/svelte/src/internal/server/index.js:spread_props`

`export function spread_props(props)` · [packages/svelte/src/internal/server/index.js:L213-L230][f1]

Merge an array of prop objects left-to-right, later objects overriding earlier keys.

**Notes.**

- condition: Uses Object.getOwnPropertyDescriptor/defineProperty so getters/setters are copied with their descriptors when present; plain assignment otherwise.

<a id="u-1d4fa3ac5094"></a>
### `packages/svelte/src/internal/server/index.js:stringify`

`export function stringify(value)` · [packages/svelte/src/internal/server/index.js:L236-L238][f1]

Coerce a value to attribute text: strings pass through, null/undefined become empty, others use String concatenation.

<a id="u-5168ebd4b162"></a>
### `style_object_to_string`

`function style_object_to_string(style_object)` · [packages/svelte/src/internal/server/index.js:L241-L246][f1]

Serialize a style object, dropping null/undefined/empty values and escaping each declaration value.

**Notes.**

- condition: Keys whose value is null, undefined, or '' are filtered out; each entry is emitted as 'key: value;' with escape_html(value, true), joined by spaces.

calls: [escape_html](r4-shared-source-utilities.md#u-0f499dd45547)

<a id="u-2c8b13b9bc4e"></a>
### `maybe_selected`

`export function maybe_selected(payload, value)` · [packages/svelte/src/internal/server/index.js:L553-L555][f1]

Return ' selected' when the value equals the payload's tracked select_value, else ''.

<a id="u-8a42e56302a7"></a>
### `valueless_option`

`export function valueless_option(payload, children)` · [packages/svelte/src/internal/server/index.js:L562-L576][f1]

Mark the matching <option> as selected by rewriting already-buffered output for valueless options.

**Notes.**

- condition: Children are rendered, then the buffered slice with <!----> markers stripped is compared to payload.select_value.
- side_effect: On match: the previous output item has its trailing '>' replaced with ' selected>' and the buffered items are collapsed into one at position i.

**Uncertainties.**

- If i is 0, out[i-1] would be undefined and throw; source assumes an opening tag precedes the children.

<a id="u-10667406d2fa"></a>
### `index.js module code (L162–L171)`

`module_region` · [packages/svelte/src/internal/server/index.js:L162-L171][f1]

Non-behavioral gap between css_props and spread_attributes.

<a id="u-927c9f4a6cb3"></a>
### `index.js module code (L207–L212)`

`module_region` · [packages/svelte/src/internal/server/index.js:L207-L212][f1]

Non-behavioral gap between spread_attributes and spread_props.

<a id="u-61ce7f788f09"></a>
### `index.js module code (L230–L235)`

`module_region` · [packages/svelte/src/internal/server/index.js:L230-L235][f1]

Non-behavioral gap between spread_props and stringify.

<a id="u-dbb0550aa06a"></a>
### `index.js module code (L238–L240)`

`module_region` · [packages/svelte/src/internal/server/index.js:L238-L240][f1]

Non-behavioral gap between stringify and style_object_to_string.

<a id="u-1a89e17956f7"></a>
### `index.js module code (L246–L252)`

`module_region` · [packages/svelte/src/internal/server/index.js:L246-L252][f1]

Non-behavioral gap between style_object_to_string and attr_class.

<a id="u-84d67f426334"></a>
### `index.js module code (L256–L261)`

`module_region` · [packages/svelte/src/internal/server/index.js:L256-L261][f1]

Non-behavioral gap between attr_class and attr_style.

<a id="u-02cc641a04c8"></a>
### `index.js module code (L546–L552)`

`module_region` · [packages/svelte/src/internal/server/index.js:L546-L552][f1]

Non-behavioral gap between derived and maybe_selected.

<a id="u-f806a77a3ac4"></a>
### `index.js module code (L555–L561)`

`module_region` · [packages/svelte/src/internal/server/index.js:L555-L561][f1]

Non-behavioral gap between maybe_selected and valueless_option.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/server/index.js
