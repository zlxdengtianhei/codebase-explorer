# Template Parsing

**Capability.** Reads raw Svelte source into an AST: a recursive-descent template parser dispatches on tag/fragment/text state, Acorn wrappers parse embedded JS/TS expressions with comment support, and <svelte:options> attributes are statically validated.

Use when template syntax reading or expression parsing changes. The state functions in state/tag.js and state/fragment.js drive the parser; read/context.js supplies pattern and type-annotation readers; read/options.js converts svelte:options attributes into validated AST options.

**Depends on.**

- [Compiler State & AST Utilities](r5-compiler-state-utils.md) · graph-confirmed · 1 edge(s)
- [Parsing and Lexical Helpers](r4-compiler-parse.md) · graph-only · 15 edge(s)
- [Expression & Script Reading](r1-script-expression-parsing.md) · graph-only · 12 edge(s)

**Depended on by.**

- [Analysis Phase](r5-compiler-analyze.md) · model-inferred · 0 edge(s)

Parent: [Compiler Pipeline](r5-compiler.md)

## Units (17)

<a id="u-25b8c96fd2a2"></a>
### `acorn.js-comment-handlers`

`function get_comment_handlers(source, comments, index = 0)` · [packages/svelte/src/compiler/phases/1-parse/acorn.js:L104-L139][f1]

Factory returning two collaborating closures that give Acorn comment support, which it lacks natively; comments back `svelte-ignore` handling in JS code and preservation for formatters.

`onComment` is the Acorn callback: for block comments containing a newline it dedents the value by locating the line's indentation in `source` (walking back to the preceding newline, then forward over spaces/tabs) and stripping that prefix from every line via a global multiline regex, then pushes `{type: 'Block'|'Line', value, start, end, loc}` into the shared `comments` array. `add_comments(ast)` runs after parsing: it filters out comments before the configured `index` and clones remaining ones, then walks the AST once. Per node it first attaches every pending comment starting before the node as `leadingComments`; after descending via next(), if a comment remains and the node does not share its parent's end, it decides trailing attachment: when the node is the last entry of a BlockStatement/Program body, ArrayExpression elements, or ObjectExpression properties, all subsequent comments up to the parent's end become trailingComments (newlines allowed between them); otherwise exactly one comment becomes trailing only if the text between node end and comment start is solely `,`, `)`, spaces, or tabs. Finally, comments remaining after the root's end — or any comments when the root is a Program — are spliced onto the root's trailingComments so the true end of an expression tag can be located later.

**Uncertainties.**

- The indentation string is interpolated unescaped into a RegExp; regex metacharacters in indentation would alter the pattern.
- The trailing heuristic keys on the listed parent types only; trailing comments under other parent shapes stay unattached unless the root case catches them.

<a id="u-5ceb409db775"></a>
### `index.js-parser`

`class Parser` · [packages/svelte/src/compiler/phases/1-parse/index.js:L18-L57][f2]

Recursive-descent parser for Svelte templates.

The constructor trims trailing whitespace from the template (throwing TypeError for non-string input), detects a `lang=ts` attribute on a `<script` tag via a global regex (looping until a match beginning with '<s', then resetting the regex lastIndex), and seeds a Root node with an empty fragment, js, css, and comments, pushing it onto the node stack. It then drives a state-machine loop: `state` starts at the fragment reader and each iteration calls the current state function with the parser, which consumes characters and advances `index` until the template is exhausted. On termination, leftover stack entries mean unclosed content: in loose mode the current node's end is set to template length; otherwise for RegularElement and other nodes it sets end to start+1 and throws `e.element_unclosed` or `e.block_unclosed`. If the final state is not the fragment state, `e.unexpected_eof` throws. The Root's start/end are then computed from the first/last fragment child positions, skipping leading and trailing whitespace, or set to null when the fragment is empty. If the fragment contains an `SvelteOptions` node, it is spliced out, validated by read_options, checked by disallow_children, stored as root.options, and its raw node is attached via a non-enumerable `__raw__` property. Helper methods: `current` returns the top of the stack; `acorn_error` rethrows Acorn failures as js_parse_error with a trailing ` (line:col)` position indicator stripped; `match`/`eat` test and optionally consume literal strings, with eat throwing `e.expected_token` when required and (not loose or required_in_loose); `match_regex`/`read` match an anchored regex at the index, returning null or advancing past the match; `allow_whitespace`/`require_whitespace` skip whitespace, the latter throwing `e.expected_whitespace`; `read_identifier` scans Unicode identifier characters via acorn predicates (advancing 1–2 units per code point) and throws `e.unexpected_reserved_word` for reserved words unless allowed, returning null when not at an identifier start; `read_until` consumes up to the next regex match (throwing `e.unexpected_eof` at end of input unless loose, where it returns ''); `pop` removes the top stack entry and its fragment; `append` pushes a node into the innermost fragment and returns it.

**Uncertainties.**

- The lang-detection loop compares match_lang[0][1] against 's' but the ts decision uses capture group 2, so a lang attribute elsewhere in a tag starting '<s' could set ts incorrectly; exact tag-shape coverage depends on the regex.

<a id="u-2464d5720df7"></a>
### `packages/svelte/src/compiler/phases/1-parse/acorn.js:parse`

`export function parse(source, comments, typescript, is_script)` · [packages/svelte/src/compiler/phases/1-parse/acorn.js:L22-L66][f1]

Parses a JS or TypeScript module source into an estree Program while collecting comments into the caller's array.

Chooses the TS-extended acorn parser when `typescript` is true, otherwise plain acorn.Parser. When `is_script` is set, it temporarily replaces `parser.prototype.parseStatement` so each parsed statement resets `this.undefinedExports` to an empty object, preventing Acorn from rejecting exports that resolve inside the component rather than the script; the original prototype method is restored in a `finally` block even if parsing throws. Parses with `sourceType: 'module'`, `ecmaVersion: 16`, `locations: true`, and the comment-recording `onComment` handler, then attaches collected comments to AST nodes via `add_comments` before returning the Program.

calls: [acorn.js-comment-handlers](r5-compiler-parse.md#u-25b8c96fd2a2); uses: [acorn.js-comment-handlers](r5-compiler-parse.md#u-25b8c96fd2a2)

**Uncertainties.**

- Mutating the shared parser prototype is unsafe under concurrent parsing while the patch is active; no synchronization is visible in this file.

<a id="u-730e2a662101"></a>
### `parse_expression_at`

`export function parse_expression_at(source, comments, typescript, index)` · [packages/svelte/src/compiler/phases/1-parse/acorn.js:L75-L94][f1]

Parses a single expression starting at `index` within `source`, returning the Acorn expression node optionally extended with leading/trailing comment arrays.

Selects the TS-extended parser when `typescript` is true. Comment recording begins only at `index`: the returned add_comments handler drops comments starting before it. Parses with `onComment`, `sourceType: 'module'`, `ecmaVersion: 16`, `locations: true`, attaches comments via add_comments, and returns the node.

calls: [acorn.js-comment-handlers](r5-compiler-parse.md#u-25b8c96fd2a2)

<a id="u-53ab5f2b9b37"></a>
### `packages/svelte/src/compiler/phases/1-parse/index.js:parse`

`export function parse(template, loose = false)` · [packages/svelte/src/compiler/phases/1-parse/index.js:L296-L301][f2]

Entry point that parses a Svelte template string into an AST Root.

It first records the source in compiler state via state.set_source (used for later diagnostics/mapping), then constructs a Parser whose constructor performs the entire parse, and returns parser.root.

uses: [index.js-parser](r5-compiler-parse.md#u-5ceb409db775)

<a id="u-eaf948574d56"></a>
### `read_pattern`

`export default function read_pattern(parser)` · [packages/svelte/src/compiler/phases/1-parse/read/context.js:L14-L79][f3]

Reads a binding pattern (identifier or destructuring pattern) for template syntax like each-key and snippets.

If parser.read_identifier yields a name, it reads an optional type annotation and returns an Identifier node with start/end loc from the locator. Otherwise the current char must be '{' or '[' (e.expected_pattern(i) throws otherwise); match_bracket consumes the matching bracket, and parser.index is set to the closing index. The bracketed pattern is reparsed by tricking Acorn with the string `pattern = 1`, offset so columns stay correct (the first space in the whitespace-masked prefix is removed to cancel the inserted '('). After parsing, the left side is taken as the pattern, a type annotation is read from the real template, and the end is extended to the annotation end when present. Any Acorn error is rethrown via parser.acorn_error.

**Notes.**

- failure: If the identifier branch fails and the next character is not '{' or '[', e.expected_pattern throws before bracket matching.
- failure: On parse failure of the synthetic expression, the caught error is converted through parser.acorn_error; there is no fallback return.

calls: [read_type_annotation](r5-compiler-parse.md#u-e32a5aa85acf), [parse_expression_at](r5-compiler-parse.md#u-730e2a662101), [match_bracket](r4-compiler-parse.md#u-cf3966ee18ec)

**Uncertainties.**

- Behavior when match_bracket returns without a match is not visible here; only that parser.index is set to its result.

<a id="u-e32a5aa85acf"></a>
### `read_type_annotation`

`function read_type_annotation(parser)` · [packages/svelte/src/compiler/phases/1-parse/read/context.js:L85-L125][f3]

Reads an optional TypeScript type annotation starting at the current index.

If the next non-whitespace character is not ':', parser.index is rewound and undefined is returned. Otherwise the template is rewritten for Acorn-TS: the prefix is whitespace-masked, the literal '_ as ' is inserted, and optional markers `?:` are replaced with ':' so a function-parameter sequence like `foo: bar?: baz` does not error. After parsing, an AssignmentExpression result is repaired by reparsing up to the '=' before its right side, and a SequenceExpression (from a trailing `, more-params`) is reduced to its first expression. parser.index is moved to the parsed expression's end and a TSTypeAnnotation node is returned wrapping expression.typeAnnotation.

calls: [parse_expression_at](r5-compiler-parse.md#u-730e2a662101)

**Uncertainties.**

- If parse_expression_at throws, the error propagates uncaught from this function; no local handling is visible.

<a id="u-afa9e7c8c98c"></a>
### `get_boolean_value`

`function get_boolean_value(attribute)` · [packages/svelte/src/compiler/phases/1-parse/read/options.js:L222-L228][f4]

Wraps get_static_value and enforces that the result is a boolean, throwing e.svelte_options_invalid_attribute_value(attribute, 'true or false') otherwise; returns the boolean on success.

calls: [get_static_value](r5-compiler-parse.md#u-6d5fb04e54eb)

<a id="u-6d5fb04e54eb"></a>
### `get_static_value`

`function get_static_value(attribute)` · [packages/svelte/src/compiler/phases/1-parse/read/options.js:L200-L217][f4]

Extracts a compile-time constant value from an attribute.

Returns true for shorthand (value === true or empty chunk), null when the value has multiple chunks or the single chunk is a non-Literal expression, the text data for a Text chunk, and the literal's value otherwise.

**Notes.**

- contract: Callers must distinguish true (shorthand), null (not static), and other values.

<a id="u-d4c4a2170fce"></a>
### `read_options`

`export default function read_options(node)` · [packages/svelte/src/compiler/phases/1-parse/read/options.js:L10-L195][f4]

Converts the raw attributes of a `<svelte:options>` node into a validated AST.SvelteOptions object.

Every attribute must have type 'Attribute' (else e.svelte_options_invalid_attribute) and a known name; unknown names throw e.svelte_options_unknown_attribute, and `tag` always throws e.svelte_options_deprecated_tag. Boolean options (runes, immutable, preserveWhitespace, accessors) go through get_boolean_value. `namespace` accepts the SVG/MathML constants or the literals html/mathml/svg, else throws. `css` only accepts 'injected'. For `customElement`, a plain text value is validated as a tag; `null` is silently accepted for backwards compatibility with Svelte 4; anything else must be an ObjectExpression whose properties are non-computed identifier keys: `tag` (validated), `props` (each prop must be an ObjectExpression of non-computed identifier keys whose values are Literals constrained to type in String/Number/Boolean/Array/Object, reflect boolean, attribute string — any violation throws e.svelte_options_invalid_customelement_props), `shadow` limited to 'open'/'none', and `extend` stored as-is.

**Notes.**

- failure: The `if (!node)` guard after building component_options is dead in practice since the parameter is already dereferenced above; as written it can only return the partially built options if node were falsy before the dereference.
- side_effect: Mutates only the locally constructed component_options object; the input node's attributes array is referenced, not copied.

calls: [get_static_value](r5-compiler-parse.md#u-6d5fb04e54eb), [get_boolean_value](r5-compiler-parse.md#u-afa9e7c8c98c), [validate_tag](r5-compiler-parse.md#u-5802e1b7bde8)

**Uncertainties.**

- When customElement's value[0].expression is neither Text, null Literal, nor ObjectExpression, e.svelte_options_invalid_customelement throws; the loop after it assumes ObjectExpression otherwise.

<a id="u-5802e1b7bde8"></a>
### `validate_tag`

`function validate_tag(attribute, tag)` · [packages/svelte/src/compiler/phases/1-parse/read/options.js:L250-L261][f4]

Asserts a custom-element tag name is valid.

A non-string tag throws e.svelte_options_invalid_tagname. A non-empty string must match regex_valid_tag_name (lowercase custom-element grammar per the WHATWG spec regex, requiring a dash) or the same error throws; a name in the reserved list (annotation-xml, font-face variants, etc.) throws e.svelte_options_reserved_tagname. The empty string passes without error.

**Notes.**

- condition: An empty-string tag bypasses both the regex and reserved-name checks.

<a id="u-26ec42ae9fe1"></a>
### `fragment`

`export default function fragment(parser)` · [packages/svelte/src/compiler/phases/1-parse/state/fragment.js:L7-L17][f5]

State selector for fragment content: returns the element parser state when the next character is '<', the tag state when it is '{', and the text state otherwise.

It does not consume input; it only chooses the next state function.

uses: [element](r1-markup-tag-parsing.md#u-bc08cb4e57fa), [text](r4-compiler-parse.md#u-36401d8c3a23)

<a id="u-9c915ba5cbbf"></a>
### `tag`

`export default function tag(parser)` · [packages/svelte/src/compiler/phases/1-parse/state/tag.js:L18-L48][f6]

Dispatches the token after an opening `{` in the template.

It consumes the `{`, skips whitespace, and routes: `#` to `open`, `:` to `next`, `@` to `special`, and a lone `/` to `close` — but only when the slash does not begin a JS comment (`/*` or `//`), in which case the slash falls through to expression parsing. Otherwise it reads an expression, requires a closing `}`, and appends an `ExpressionTag` node spanning from the `{`. Side effects: advances `parser.index` past the `{`, appends a node, and delegates further parser mutation to the callee.

calls: [tag.js-open](r5-compiler-parse.md#u-c3bb69761a6b), [next](r5-compiler-parse.md#u-3119a97fbde8), [special](r5-compiler-parse.md#u-4f88ba6dfbca), [close](r5-compiler-parse.md#u-8d9da699a16c), [read_expression](r1-script-expression-parsing.md#u-793d43872467), [create_expression_metadata](r4-compiler-node-model.md#u-32bbb434f744)

**Uncertainties.**

- The behavior of `parser.eat('}', true)` when `}` is missing (error type/threshold) is defined by the parser, outside this file.

<a id="u-8d9da699a16c"></a>
### `close`

`function close(parser)` · [packages/svelte/src/compiler/phases/1-parse/state/tag.js:L556-L624][f6]

Parses `{/...}` closing tags by matching the current block's keyword: IfBlock expects `if`, EachBlock `each`, KeyBlock `key`, AwaitBlock `await`, SnippetBlock `snippet`.

RegularElement is an error (`e.block_unexpected_close`) unless loose mode, where it is treated as unmatched so parsing can continue; the comment notes implicitly closed elements are unhandled. Any other block type raises `e.block_unexpected_close`. When the keyword does not match, the block is ended at `start - 1`, popped, and `close` recurses to try the enclosing block — per the source comment this pop-and-retry path is only reached in loose parsing mode. After a keyword match it consumes `}` and sets `block.end = parser.index` before popping. For IfBlock specifically, a failed `if` match immediately recurses; after a match, while the closed block has `elseif: true`, the stack keeps being popped so the end position propagates to the parent if chain.

calls: [close](r5-compiler-parse.md#u-8d9da699a16c)

**Uncertainties.**

- Recursion terminates only when some enclosing block's keyword matches or an error helper fires; whether deeper parser state guarantees termination is outside this file.
- Exact loose-mode conditions under which the pop-and-retry path is entered depend on `parser.loose` semantics not defined here.

<a id="u-3119a97fbde8"></a>
### `next`

`function next(parser)` · [packages/svelte/src/compiler/phases/1-parse/state/tag.js:L442-L553][f6]

Parses block continuations introduced by `{:`.

It inspects `parser.current()` to determine the block being continued. For IfBlock: `else` is required (`e.expected_token` otherwise); `{:else if}` is rejected with `e.block_invalid_elseif`. The current fragment is popped and an `alternate` fragment pushed; if `if` follows, a new IfBlock with `elseif: true` is appended, its start rewound to the enclosing `{`, and it replaces the active fragment; otherwise plain `{:else}` just consumes `}`. For EachBlock: `else` is required and `block.fallback` becomes the active fragment. For AwaitBlock: `then` sets `block.then` (duplicate raises `e.block_duplicate_clause`), reading `block.value` via a pattern unless `}` immediately follows; `catch` behaves identically for `block.catch`/`block.error`; neither keyword raises `e.expected_token`. Any other block type raises `e.block_invalid_continuation_placement`.

calls: [read_pattern](r5-compiler-parse.md#u-eaf948574d56), [read_expression](r1-script-expression-parsing.md#u-793d43872467), [create_fragment](r4-compiler-parse.md#u-6f16c2773335)

**Uncertainties.**

- Whether the parser guarantees `parser.current()` is one of the handled block types when a `:` tag is reached for IfBlock/EachBlock error ordering is not provable here.

<a id="u-4f88ba6dfbca"></a>
### `special`

`function special(parser)` · [packages/svelte/src/compiler/phases/1-parse/state/tag.js:L627-L759][f6]

Parses `{@...}` special tags after rewinding to the opening `{`.

`{@html}` reads an expression and appends an `HtmlTag`. `{@debug}` with only whitespace before `}` appends a DebugTag with an empty identifier list (debug-all); otherwise it reads an expression, splitting a SequenceExpression into its member expressions as the identifier list, and raises `e.debug_tag_invalid_arguments` for any non-Identifier member. `{@const}` reads a pattern, requires `=`, reads the initializer, and raises `e.const_tag_invalid_expression` when the initializer is a SequenceExpression unless the source between it and the initializer start contains `(` — so `const a = (b, c)` is allowed but `const a = b, c` is not; it appends a ConstTag whose declaration spans from `const` to just before `}`. `{@render}` requires a CallExpression or a ChainExpression wrapping one (`e.render_tag_invalid_expression` otherwise) and appends a RenderTag. If no keyword matches, the function falls through silently: nothing is appended and no error is raised in this source.

calls: [read_expression](r1-script-expression-parsing.md#u-793d43872467), [read_pattern](r5-compiler-parse.md#u-eaf948574d56), [create_expression_metadata](r4-compiler-node-model.md#u-32bbb434f744)

**Uncertainties.**

- An unrecognized `@` keyword produces no error in this function; whether the surrounding parser detects it later is not visible here.

<a id="u-c3bb69761a6b"></a>
### `tag.js-open`

`function open(parser)` · [packages/svelte/src/compiler/phases/1-parse/state/tag.js:L51-L137][f6]

Parses `{#...}` opening blocks, rewinding first to the true start of the block by scanning back to the `{`.

It dispatches on the keyword after `#`: `if`, `each`, `await`, `key`, `snippet`; any other keyword raises `e.expected_block_type`.

calls: [read_expression](r1-script-expression-parsing.md#u-793d43872467), [get_loose_identifier](r1-script-expression-parsing.md#u-f85dafe8159e), [read_pattern](r5-compiler-parse.md#u-eaf948574d56), [create_fragment](r4-compiler-parse.md#u-6f16c2773335), [match_bracket](r4-compiler-parse.md#u-cf3966ee18ec), [parse_expression_at](r5-compiler-parse.md#u-730e2a662101), [create_expression_metadata](r4-compiler-node-model.md#u-32bbb434f744)

**Uncertainties.**

- Semantics of `parser.stack`, `parser.fragments`, `parser.pop`, `parser.loose`, and `parser.ts` are inferred from usage here; their definitions are outside this file.
- Whether `e.*` helpers throw or record is not visible in this file.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/1-parse/acorn.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/1-parse/index.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/1-parse/read/context.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/1-parse/read/options.js
[f5]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/1-parse/state/fragment.js
[f6]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/1-parse/state/tag.js
