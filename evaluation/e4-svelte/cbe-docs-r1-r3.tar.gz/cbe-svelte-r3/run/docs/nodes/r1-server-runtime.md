# Server Runtime

**Capability.** The `svelte/server` internal runtime: component frame push/pop with the linked component stack, component context maps seeded from ancestors, a shared module-level AbortController signalling stale server reactions, and server-side raw snippet wrapping that appends rendered HTML to the payload.

Use when SSR context lookup, component-stack errors, stale-reaction aborts, or raw snippets render incorrectly on the server. All context accessors funnel through get_or_init_context_map.

**Depended on by.**

- [Benchmarks](r1-benchmarks.md) · model-inferred · 0 edge(s)
- [Server Transform](r1-server-transform.md) · model-inferred · 0 edge(s)

Parent: [Svelte Repository](r1-svelte-monorepo.md)

## Units (12)

<a id="u-520828fc5cd8"></a>
### `packages/svelte/src/internal/server/context.js:context.js module code (L1–L13)`

`module_region` · [packages/svelte/src/internal/server/context.js:L1-L13][f1]

Module imports and the exported current_component state variable for the server component stack.

<a id="u-38e06b351976"></a>
### `packages/svelte/src/internal/server/context.js:push`

`export function push(fn)` · [packages/svelte/src/internal/server/context.js:L60-L66][f1]

Push a new component frame onto the linked component stack, making it current.

**Notes.**

- side_effect: Creates { p: previous, c: null, d: null } and assigns current_component; in DEV also records the component function.

<a id="u-b3ad8cba6058"></a>
### `packages/svelte/src/internal/server/context.js:pop`

`export function pop()` · [packages/svelte/src/internal/server/context.js:L68-L78][f1]

Pop the current component frame, deferring its onDestroy callbacks to render teardown.

**Notes.**

- side_effect: If component.d is set, its callbacks are pushed onto on_destroy; current_component is restored to component.p.

**Uncertainties.**

- Casting current_component to Component without a null check implies pop is only valid after push; behavior on unbalanced pop is undefined by source.

<a id="u-23128ee48fc4"></a>
### `packages/svelte/src/internal/server/context.js:get_or_init_context_map`

`function get_or_init_context_map(name)` · [packages/svelte/src/internal/server/context.js:L49-L55][f1]

Ensure the current component has a context Map, seeding it from ancestors; throw outside a component.

**Notes.**

- failure: If current_component is null, calls e.lifecycle_outside_component(name), which throws.
- condition: The Map is lazily assigned to current_component.c and initialized with the nearest ancestor context map (via get_parent_context) as seed entries; a null parent context yields an empty Map.

calls: [packages/svelte/src/internal/server/context.js:get_parent_context](r1-server-runtime.md#u-6c070cbfaf56); uses: [lifecycle_function_unavailable](r3-server-render-entry.md#u-af8d810f9167)

<a id="u-6c070cbfaf56"></a>
### `packages/svelte/src/internal/server/context.js:get_parent_context`

`function get_parent_context(component_context)` · [packages/svelte/src/internal/server/context.js:L84-L96][f1]

Walk the parent chain to find the nearest ancestor context Map, or return null.

**Notes.**

- condition: Skips ancestors whose c is null and returns null when the chain is exhausted.

<a id="u-9d2873c370b6"></a>
### `packages/svelte/src/internal/server/context.js:setContext`

`export function setContext(key, context)` · [packages/svelte/src/internal/server/context.js:L27-L30][f1]

Set a key/value pair on the current component's context map and return the value.

calls: [packages/svelte/src/internal/server/context.js:get_or_init_context_map](r1-server-runtime.md#u-23128ee48fc4)

<a id="u-590d884e05a5"></a>
### `packages/svelte/src/internal/server/context.js:getContext`

`export function getContext(key)` · [packages/svelte/src/internal/server/context.js:L14-L19][f1]

Read a context value from the current component's context map, or undefined when absent.

**Notes.**

- failure: Relies on get_or_init_context_map, which throws lifecycle_outside_component when called outside a component.

calls: [packages/svelte/src/internal/server/context.js:get_or_init_context_map](r1-server-runtime.md#u-23128ee48fc4)

<a id="u-d714cd56dee8"></a>
### `packages/svelte/src/internal/server/context.js:hasContext`

`export function hasContext(key)` · [packages/svelte/src/internal/server/context.js:L36-L38][f1]

Return whether the current component's context map contains the key.

calls: [packages/svelte/src/internal/server/context.js:get_or_init_context_map](r1-server-runtime.md#u-23128ee48fc4)

<a id="u-ebffdeebb3a9"></a>
### `packages/svelte/src/internal/server/context.js:getAllContexts`

`export function getAllContexts()` · [packages/svelte/src/internal/server/context.js:L41-L43][f1]

Return the current component's full context Map, creating it if needed.

calls: [packages/svelte/src/internal/server/context.js:get_or_init_context_map](r1-server-runtime.md#u-23128ee48fc4)

<a id="u-9654b4650543"></a>
### `abort`

`export function abort()` · [packages/svelte/src/internal/server/abort-signal.js:L6-L9][f2]

Abort the module-level AbortController and reset it, signalling stale server reactions.

**Notes.**

- side_effect: Aborts with STALE_REACTION as reason only if a controller exists, then clears the module-level reference.

uses: [packages/svelte/src/internal/server/abort-signal.js:getAbortSignal](r1-server-runtime.md#u-fbe9939ec5b9)

**Uncertainties.**

- Consumers of the signal (who calls getAbortSignal) are outside this file's source, so the full effect of aborting is inferred.

<a id="u-fbe9939ec5b9"></a>
### `packages/svelte/src/internal/server/abort-signal.js:getAbortSignal`

`export function getAbortSignal()` · [packages/svelte/src/internal/server/abort-signal.js:L11-L13][f2]

Lazily create a shared module-level AbortController and return its signal.

<a id="u-9b7114ceb220"></a>
### `packages/svelte/src/internal/server/blocks/snippet.js:createRawSnippet`

`export function createRawSnippet(fn)` · [packages/svelte/src/internal/server/blocks/snippet.js:L14-L24][f3]

Wrap a raw-snippet function into a server-side snippet callable that appends its rendered HTML to the payload.

**Notes.**

- contract: Each argument is converted to a getter closure returning the original value, so fn can re-read params.
- side_effect: fn's render() result is trimmed and pushed onto payload.out; the optional setup/cleanup hooks declared in the type are never invoked by this implementation.

**Uncertainties.**

- Whether setup/teardown returned by fn is honored elsewhere is not visible in this file.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/server/context.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/server/abort-signal.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/server/blocks/snippet.js
