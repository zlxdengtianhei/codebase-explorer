# Reactivity Benchmarks

**Capability.** Benchmark workloads that stress specific reactive graph topologies — a 50-deep derivation chain, a triangular cumulative graph, and the 'mol' many-owner pattern — executed by a child-process runner that reports results upward.

Use to measure propagation performance changes. Each kairo/mol file is self-contained; runner.js forks and collects the results.

**Depends on.**

- [Signal Reactivity Core](r5-client-reactivity.md) · model-inferred · 0 edge(s)
- [Benchmarking Harness](r4-benchmarking.md) · graph-only · 12 edge(s)

Parent: [Repository Tooling](r5-tooling.md)

## Units (4)

<a id="u-0b0dc218fb67"></a>
### `runner.js module code (L1–L10)`

`module_region` · [benchmarking/compare/runner.js:L1-L10][f1]

Forked child-process runner that executes each reactivity benchmark and reports results to the parent process.

It imports reactivity_benchmarks, iterates the list awaiting each benchmark call, logs the result's benchmark name to stderr, and accumulates results. Once all benchmarks finish it sends the results array to the parent via process.send; if a benchmark rejects, the awaited promise rejection propagates and results are never sent.

**Uncertainties.**

- Whether benchmark() can throw synchronously rather than returning a rejected promise is not visible here; a synchronous throw would abort the loop before any process.send
- How the parent interprets 'message' payloads with failures is outside this file

<a id="u-de8f5901c41c"></a>
### `kairo_deep.js`

`function setup()` · [benchmarking/benchmarks/reactivity/kairo/kairo_deep.js:L7-L27][f2]

Benchmarks a 50-deep chain of derived signals, each adding 1 to its predecessor, ending in a render effect that counts recomputations.

setup() links head through len (50) deriveds iteratively, and run() flushes head to 1, resets the counter, then flushes head to 0..49 asserting the tail equals len + i and that the render effect ran exactly iter (50) times — one propagation per write. The unowned variant tears down each warm-up graph; the owned variant holds warm-up plus final setup inside an outer effect_root and destroys inner then outer after timing 10 iterations of 1000 runs. Both return {benchmark, time, gc_time} with two-decimal timing strings; a failed assertion throws out of the benchmark.

calls: [fastest_test](r4-benchmarking.md#u-0bbe8c671495), [assert](r4-benchmarking.md#u-823bd0dd0cd8)

<a id="u-2f2516e7767f"></a>
### `kairo_triangle.js`

`function count(number)` · [benchmarking/benchmarks/reactivity/kairo/kairo_triangle.js:L6-L11][f3]

Benchmarks a triangular cumulative graph: count(n) computes 1+2+...+n via a filled array reduce.

setup() chains width (10) deriveds, each adding 1 to the previous link (starting from head) while collecting all links including head in a list; a sum derived reduces the list, and a render effect counts recomputations. run() computes the constant triangle total, flushes head to 1 asserting sum equals it, resets the counter, then for i in 0..99 flushes head to i asserting sum equals constant - width + i*width, and finally asserts the counter is 100. Unowned and owned variants use the standard harness (10 warm-up cycles; fastest_test over 10 iterations of 1000 runs; owned teardown inside an outer effect_root, inner before outer) and return {benchmark, time, gc_time} as two-decimal strings; failed assertions throw.

calls: [fastest_test](r4-benchmarking.md#u-0bbe8c671495), [assert](r4-benchmarking.md#u-823bd0dd0cd8), [kairo_triangle.js](r5-benchmarks.md#u-2f2516e7767f)

<a id="u-a12651df59d5"></a>
### `mol_bench.js`

`function fib(n)` · [benchmarking/benchmarks/reactivity/mol_bench.js:L7-L10][f4]

Benchmarks the 'mol' (many-owners / mixed dependency) graph pattern: fib(n) is naive recursion returning 1 for n<2; hard(n) adds fib(16) (a constant 1597 under this definition, plus n).

setup() builds states A and B; deriveds C = A%2 + B%2, D = numbers.map(...) with a custom D.equals performing a length-and-elementwise comparison (needed because arrays default to identity equality), E = hard(C + A + D[0]), F = hard(D[0] && B), and G combining C, E, D[0] and F; three render effects push hard(G), G and hard(F) into a shared res array inside one effect_root. run(i) clears res, performs two flushes (B=1,A=1+2i then A=2+2i,B=2) and asserts res is [3198, 1601, 3195, 1598], verifying exact propagation order and values. mol_bench_owned and mol_bench_unowned use the standard harness but with 1e4 run(i) calls per timed iteration (10 iterations); owned creates its warm-up and final graphs inside an outer effect_root and destroys inner then outer. Both return {benchmark, time, gc_time} as two-decimal strings; failed assertions throw.

calls: [fastest_test](r4-benchmarking.md#u-0bbe8c671495), [assert](r4-benchmarking.md#u-823bd0dd0cd8), [mol_bench.js](r5-benchmarks.md#u-a12651df59d5)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/benchmarking/compare/runner.js
[f2]: ../../../../../../eval/svelte-be645b4/benchmarking/benchmarks/reactivity/kairo/kairo_deep.js
[f3]: ../../../../../../eval/svelte-be645b4/benchmarking/benchmarks/reactivity/kairo/kairo_triangle.js
[f4]: ../../../../../../eval/svelte-be645b4/benchmarking/benchmarks/reactivity/mol_bench.js
