# Migration Script Visitors

**Capability.** Rewrites the instance script for runes: legacy variable declarations become $props/$state, top-level $: statements migrate or are skipped, imports/exports are sanitized, and implicit legacy prop identifiers are rewritten.

Read these for how `export let` and `$:` code becomes runes-mode code. handle_identifier is shared with the template walk, hence the reverse dependency from migrate-template-visitors.

**Depends on.**

- [Migration Driver and Helpers](r3-migrate-entry.md) · model-inferred · 0 edge(s)
- [Shared Predicates and Hash](r3-shared-utils.md) · model-inferred · 0 edge(s)

**Depended on by.**

- [Migration Template Visitors](r3-migrate-template-visitors.md) · graph-confirmed · 1 edge(s) · template visitors call handle_identifier owned by the script visitors during the shared migration walk.

Parent: [Svelte 4 to 5 Migration](r3-migration.md)

## Units (7)

<a id="u-7ca9a10d7605"></a>
### `index-js-variabledeclaration`

`VariableDeclaration(node, { state, path, visit, next })` · [packages/svelte/src/compiler/migrate/index.js:L565-L712][f1]

Rewrites legacy variable declarations in the instance scope into runes (the visitor does nothing outside the instance scope, and when `analysis.runes` is already true it only records an existing `$props` rune's position and sets `has_props_rune`).

Props path (bindings include a `bindable_prop`): a non-Identifier declarator id throws MigrationError; combining $$props usage with a named prop that has an initializer or is reassigned throws MigrationError; if a prop entry already exists (from $$Props typing) it is updated in place with the snipped initializer and reassigned-as-bindable, otherwise a new entry is pushed with local/exported name (respecting prop_alias), snipped initializer, `optional` true only with an initializer, and type/comment from extract_type_and_comment — in both cases after calling `next()` so children are still visited. The declarator's source text is blanked; for multi-declaration statements the insertion point moves past the whole statement and the removal range is adjusted by commas so `let a,b,c` keeps non-prop siblings; single declarations move the insertion point to the declarator end. When every declaration was a prop, the entire line (including an enclosing ExportNamedDeclaration) is removed. State path (state bindings, no props): with an initializer, `check_rune_binding('state')` throws a MigrationError when a variable named `state` exists, then `$state(` / `)` wrap the init (a SequenceExpression's range is widened to its enclosing parentheses first). Without an initializer, references are analyzed: an assignment inside a `$:` labeled statement qualifies only when it is not merely the labeled statement's own `x = ...` form targeting the binding; all references must avoid UpdateExpressions and be either declared-with-initial, labeled-assignments, or plain. If the labeled statement is a bare `$: foo = <literal-free expression with no identifiers>`, the statement is recorded in derived_labeled_statements and becomes `$state(<rhs>)`. Otherwise, if the labeled statement is single-assignment (block with one ExpressionStatement or a direct assignment) the declaration becomes `= $derived(<rhs>)`: leading/trailing comments of the labeled body are re-emitted around the declaration, check_rune_binding('derived') guards the name, the labeled statement text is removed, and the visited RHS snippet is inlined; else the declaration gets `= $state(`, inlining the labeled assignment's RHS when should_be_state, and `)`.

**Notes.**

- failure: Declarators whose bindings cannot be computed (get_bindings throws) are skipped via next() and left unchanged.
- condition: All rune-name conflicts abort the whole migration because MigrationError propagates to migrate's catch.

calls: [get_rune](r4-compiler-scope.md#u-5204b6ce4f7a), [extract_all_identifiers_from_expression](r4-compiler-ast-utils.md#u-4fc74297abd5), [extract_type_and_comment](r3-migrate-script-visitors.md#u-081e94041a1f); raises: [MigrationError](r3-migrate-entry.md#u-18abcf9a9523)

<a id="u-4f9c3ef700db"></a>
### `index-js-labeled-statement`

`LabeledStatement(node, { path, state, next })` · [packages/svelte/src/compiler/migrate/index.js:L925-L936][f1]

Migrates top-level `$:` reactive statements in the instance script (skipped entirely when analysis.runes, when nested — path length > 1 — or when already converted by the VariableDeclaration visitor and present in derived_labeled_statements).

For `$: lhs = rhs` where every left-hand binding is `legacy_reactive`: when the RHS is not a Literal, no binding is a store subscription, and the left side is not a MemberExpression, it becomes `let lhs = $derived(rhs)` — check_rune_binding('derived') aborts on a `derived` variable, `let ` replaces `$:` in the output, SequenceExpression RHS is widened to its parentheses, and a closing `)` is added unless the statement already starts with `(` (as in `$: ({ a } = b())`). Otherwise, for each reassigned binding whose identifiers appear on the left (or with an empty RHS), a `let <name>` declaration is prepended — with `= $state()` for state bindings, `= $state(<rhs>)` when the RHS has no identifiers, or nothing otherwise; and when the RHS has no identifiers and there are no store subscriptions the whole statement is removed since it is now redundant. Anything not covered falls through to the generic form: `run` is added to legacy_imports, and the body is wrapped in `<run>(() => { ... })` — a block body's braces are rewritten directly, while an expression body is rewritten with the generated run name, its lines re-indented (excluding text before the body and after the statement), and `});` appended. The local check_rune_binding guards both 'derived' and 'state' names and throws MigrationError on conflicts.

calls: [extract_identifiers](r4-compiler-ast-utils.md#u-90eb95affc00), [extract_all_identifiers_from_expression](r4-compiler-ast-utils.md#u-4fc74297abd5)

<a id="u-6d05e73ebe34"></a>
### `index-js-instance-script-simple`

`const instance_script = { _(node, { state, next })` · [packages/svelte/src/compiler/migrate/index.js:L485-L500][f1]

Small shared visitors of the instance-script walk.

`_` inspects each node's `leadingComments`: for `Line` comments it runs migrate_svelte_ignore and overwrites the comment text (after `//`) only when the migration changed it. `Identifier` delegates entirely to handle_identifier, which rewrites $$props/$$restProps/$$slots references inside the script. `BreakStatement` only acts when the break is the direct child of a LabeledStatement (path[1]) labeled `$` and carries that `$` label, replacing the `break $;` statement text with `return;`; all other breaks are left untouched.

calls: [migrate_svelte_ignore](r2-compiler-foundations.md#u-22cdd6c7c71c), [handle_identifier](r3-migrate-script-visitors.md#u-f31d2d5b26f5)

<a id="u-9982c4ec79f5"></a>
### `ImportDeclaration`

`ImportDeclaration(node, { state })` · [packages/svelte/src/compiler/migrate/index.js:L504-L541][f1]

Tracks import position and sanitizes svelte imports in the instance script.

It first moves `props_insertion_point` to this import's end so later prop declarations are inserted after imports. For imports from 'svelte': a `beforeUpdate`/`afterUpdate` specifier with no references in scope is physically removed — the removal end is the following comma (when that comma precedes the closing brace, so a separator is also eaten) or the specifier end, extended over whitespace; when every specifier was removed the whole import statement is removed. Any beforeUpdate/afterUpdate specifier that is still referenced is collected, and if any exist a MigrationError is thrown listing them, telling the user to migrate by hand.

raises: [MigrationError](r3-migrate-entry.md#u-18abcf9a9523)

<a id="u-d450a84d8bbe"></a>
### `ExportNamedDeclaration`

`ExportNamedDeclaration(node, { state, next })` · [packages/svelte/src/compiler/migrate/index.js:L542-L564][f1]

Cleans bare export lists in the instance script.

If the export has a declaration it is left to the normal variable visitor. Otherwise each Identifier specifier whose binding is a `bindable_prop` (i.e. `export { x }` of an `export let x`) is removed from the output; when all specifiers were removed the entire export statement is removed too.

<a id="u-081e94041a1f"></a>
### `extract_type_and_comment`

`function extract_type_and_comment(declarator, state, path)` · [packages/svelte/src/compiler/migrate/index.js:L1587-L1707][f1]

Derives a prop's type and documentation from a `let`/`export let` declarator, removing consumed comments from the output via str.update.

It takes the parent's last leading comment as the JSDoc (blanked in the source) and the first trailing comment similarly. With a typeAnnotation it sets has_type_or_fallback, skips the colon and spaces, and returns the exact annotation text. Otherwise comments are cleaned line-by-line (stripping `//`, `/**`, trailing `*/`, and leading `*`, dropping empty lines) and truncated at the first `@`-tag. For an export declaration whose leading comment contains `@type {T}`, has_type_or_fallback is set and T is returned as the type, with any `- description` after the type appended to the cleaned comment. A Literal initializer of type string, number, or boolean yields that primitive as the inferred type (also setting has_type_or_fallback). Everything else returns `'any'`. When `state.uses_ts` is true the raw comment strings are returned; otherwise the cleaned versions.

uses: [Program](r1-client-transform.md#u-ba1f8c9b6c22)

<a id="u-f31d2d5b26f5"></a>
### `handle_identifier`

`function handle_identifier(node, state, path)` · [packages/svelte/src/compiler/migrate/index.js:L1848-L1967][f1]

Rewrites legacy implicit-prop identifiers in both scripts and template.

As a MemberExpression property it is skipped. When the analysis uses $$props and the name is not `$$slots`: `$$props` and `$$restProps` are replaced outright with the generated props name (the note in-source admits $$restProps is not fully precise here), while any other identifier bound as a `bindable_prop` (and not its own declaration node) is prefixed with `<props>.` to read from the props object. Otherwise `$$restProps` under uses_rest_props becomes the rest name. `$$slots` under uses_slots must be a MemberExpression (custom elements return early): the property name (Literal value or identifier) names a slot; an existing prop with that slot_name is reused, non-default names are scope-generated and a MigrationError is thrown if generation would rename them; 'default' renders as 'children'; a new prop is pushed typed `import('svelte').Snippet<[any]>` with needs_refine_type so a later render refines it; the access `$$slots.x` is rewritten to `<props.>x` (props-prefixed under $$props usage). If `$$slots` appears as a bare identifier the code is left to error at compile time. Finally, `$$Props` inside a TSInterfaceDeclaration or TSTypeAliasDeclaration: each member's type annotation, optionality, leading block comment, and first trailing comment are harvested into props — updating matching exported props or pushing `type_only` entries — sets has_type_or_fallback, and the whole declaration is removed from the output.

raises: [MigrationError](r3-migrate-entry.md#u-18abcf9a9523)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/migrate/index.js
