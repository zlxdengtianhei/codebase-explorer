# Client Transform Visitors

**Capability.** Per-node client code generation: statements, calls (runes), event directives, {@html}, legacy $: statements, and the RegularElement builder covering attributes, class/style directives, custom elements, and select synchronization.

Each visitor converts one AST node type into client JS. RegularElement groups the attribute-update builders it calls; consult it for how attributes and directives become template effects.

**Depends on.**

- [Client Transform Utilities](r3-client-transform-utils.md) · graph-confirmed · 5 edge(s)
- [Shared Predicates and Hash](r3-shared-utils.md) · graph-confirmed · 4 edge(s)
- [Client Code Transformation](r4-transform-client.md) · graph-only · 10 edge(s)

Parent: [Client Transform Phase](r3-client-transform.md)

## Units (14)

<a id="u-113cc5a16382"></a>
### `BlockStatement`

`export function BlockStatement(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/BlockStatement.js:L10-L32][f1]

Serializes a plain block statement.

It first applies state transformers via add_state_transformers. When the enclosing scope carries a tracing expression (scope.tracing non-null), the block's statements are visited inside a thunk and wrapped in a `$.trace(tracing, ...)` call, returned as a block whose value is the call — awaited when the parent function is async — plus a return. Without tracing it falls through to context.next().

calls: [add_state_transformers](r1-client-transform.md#u-32bec314643f)

**Uncertainties.**

- The parent is assumed to be a function node and `parent.async` is read unconditionally; source contains no guard against other parent types.

<a id="u-affe00ad1f18"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/BreakStatement.js:BreakStatement`

`export function BreakStatement(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/BreakStatement.js:L9-L20][f2]

Special-cases `break $` inside legacy-mode reactive statements.

In runes mode, or when the label is absent or not '$', it returns undefined and normal processing proceeds. Only when not in runes mode and the label is '$', and the statement is directly inside a '$:'-labeled statement (context.path[1] is a LabeledStatement labeled '$'), does it return b.return() — compiling `break $` into exiting the reactive-statement function early. Note the return value is only produced in that narrow case; otherwise undefined is returned, and the function never calls context.next().

**Uncertainties.**

- Since it returns undefined in the common case, whether the walker then applies default handling is a walker contract not visible here.

<a id="u-a7da2a1bef1e"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/CallExpression.js:CallExpression`

`export function CallExpression(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/CallExpression.js:L13-L102][f3]

Serializes call expressions, first resolving runes.

`$host` becomes `$$props.$$host`; `$effect.tracking` becomes `$.effect_tracking()`; `$state`/`$state.raw` in constructors become `$.state(value)` where the argument is visited and, for non-raw `$state`, wrapped in `$.proxy` when should_proxy says the value needs proxying; `$derived` wraps the visited (in_derived) argument in a thunk inside `$.derived`, `$derived.by` passes the function directly; `$state.snapshot` becomes `$.snapshot(arg, true?)` with the flag when `state_snapshot_uncloneable` is ignored; `$effect.root` spreads visited args into `$.effect_root`; `$effect.pending` becomes `$.pending()`; `$inspect` variants delegate to transform_inspect_rune. Non-rune calls: in dev, a `console.<method>` call (method in a fixed list, console not shadowed) with a spread or an argument that scope.evaluate reports as unknown gets its args wrapped in `$.log_if_contains_state(method, ...)` via a spread so devtools can highlight state. Everything else goes through context.next().

calls: [function::get_rune::34200](../../catalog.json), [transform_inspect_rune](r2-client-transform.md#u-f64464c8fc01), [should_proxy](r3-client-transform-utils.md#u-d089d4da67c8), [is_ignored](r5-compiler-state-utils.md#u-468324b42cee)

**Uncertainties.**

- Exact identification of `$inspect().with` etc. depends on get_rune behavior outside this file.

<a id="u-9d7a76679f62"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/FunctionDeclaration.js:FunctionDeclaration`

`export function FunctionDeclaration(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/FunctionDeclaration.js:L10-L23][f4]

Handles function declarations, with special support for hoisted functions.

It first builds a state copy with in_constructor and in_derived set to false. When node.metadata?.hoisted is true, parameters are rebuilt via build_hoisted_params, the body is visited with that state, and the modified declaration is pushed into state.hoisted while the original site compiles to b.empty. Non-hoisted declarations proceed via context.next(state).

calls: [build_hoisted_params](r3-client-transform-utils.md#u-a89fb605f1f4)

<a id="u-f48625ba1690"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/HtmlTag.js:HtmlTag`

`export function HtmlTag(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/HtmlTag.js:L11-L47][f5]

Serializes {@html ...} insertion.

It pushes a template comment, builds the expression, and computes the html thunk: when the expression has awaits, the thunk reads `$$html` (supplied asynchronously) instead of the raw expression. It emits a `$.html(node, thunk, isSvg?, isMathml?, ignoreHydrationChanged?)` statement where the boolean flags come from the svg/mathml namespace metadata and the `hydration_html_changed` ignore state. When has_await is set, the statement is deferred inside a `$.async(node, [thunk], (node, $$html) => ...)` pushed to init so bindings already in init run first and can override hydration; otherwise the statement is pushed to init directly.

calls: [is_ignored](r5-compiler-state-utils.md#u-468324b42cee), [build_expression](r5-transform-client.md#u-cd5eb51d389f)

<a id="u-5cb26cf0f344"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/LabeledStatement.js:LabeledStatement`

`export function LabeledStatement(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/LabeledStatement.js:L11-L64][f6]

Handles Svelte 4 `$:` reactive statements.

It only intervenes for a top-level label named `$` in legacy (non-runes) mode; anything else continues traversal. If no matching reactive statement exists in the analysis (not the instance context) it returns undefined, dropping the statement from output. The body is visited and block-wrapped, then for each statically visible dependency (skipping `normal` bindings that are imports) a getter is built; props (`$$props`, `$$restProps`) and bindable props are wrapped in `$.deep_read_state` so fine-grained child state mutations trigger the effect. The result is registered as a `$.legacy_pre_effect(reads, body)` statement in state.legacy_reactive_statements for later topological ordering, and `b.empty` is returned so the original statement produces no output.

calls: [build_getter](r3-client-transform-utils.md#u-66a19e20e1f1)

<a id="u-3abb91ec17dc"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/OnDirective.js:OnDirective`

`export function OnDirective(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/OnDirective.js:L19-L38][f7]

Serializes an `on:` directive into an event-listener registration for the current template node.

With no expression it sets analysis.needs_props (forwarded-handler case) and still builds a handler. The handler is serialized via build_event_handler, then for each of the six recognized modifiers, in the fixed module-array order, it is nested in a `$.<modifier>` call, so `|once|preventDefault` nests. capture yields a boolean flag; passive is true with `|passive`, explicitly false with `|nonpassive`, otherwise undefined. build_event emits the final registration keyed on the directive name.

**Notes.**

- side_effect: Sets context.state.analysis.needs_props = true when the directive lacks an expression.

calls: [build_event](r2-client-transform.md#u-0bee50cc5235), [build_event_handler](r2-client-transform.md#u-227977f005ec)

**Uncertainties.**

- The handler produced when node.expression is undefined is decided inside build_event_handler, not in this file.

<a id="u-f2ea5a46376e"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/RegularElement.js:RegularElement`

`export function RegularElement(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/RegularElement.js:L32-L404][f8]

Transforms a regular HTML/SVG element into template creation plus attribute, directive, and child rendering code.

It pushes the element onto the template stack and returns early for `noscript`. It flags the template to use importNode instead of cloneNode for `video` and custom elements (cloneNode would not instantiate the custom element class; Webkit needs importNode for video autoplay), and flags contained script tags. Attributes are partitioned into attributes/class/style/other buckets with a name lookup map; an `is` attribute with a static string value in the html namespace becomes a template prop; `let:` directives are visited first. Other directives are then visited: OnDirective handlers go into element init wrapped in `$.effect` when a `use:` directive exists, otherwise into after_update. For `input`, `$.remove_input_defaults` is emitted when there is a spread or value/checked/group binding (or a dynamic value without group) and no defaultValue/defaultChecked; for `textarea`, `$.remove_textarea_child` on spread, value binding, or a non-text value/checked attribute; `<select bind:value>` triggers setup_select_synchronization. Attribute serialization: with a spread, build_attribute_effect handles everything; otherwise per attribute — event attributes via visit_event_attribute; `value` skipped when special value handling applies; static text/boolean attributes become template props (scoped-CSS hash appended to class, boolean attrs valueless when true, empty class skipped); `autofocus` becomes an init `$.autofocus` call; class/style go through build_set_class/build_set_style; custom-element attributes through build_custom_element_attribute_update_assignment; the rest through build_element_attribute_update, pushed to update or init depending on has_state, with call/await values memoized. Load/error elements with spread, use:, or onload/onerror get `$.replay_events` after update. Child handling: metadata gains the children's namespace, and bound_contenteditable when contenteditable is statically true alongside an innerHTML/innerText/textContent binding; clean_nodes trims/hoists children (whitespace preserved for `pre`/`textarea`/script); hoisted nodes are visited first. If all trimmed children are Text/ExpressionTag with at least one ExpressionTag that is stateless and await-free, one template chunk is assigned to `textContent` (skipped when the value is the empty string literal); otherwise children are processed with `$.child`, with `$.hydrate_template` plus descent into `.content` for `<template>`, and a `$.reset` after hydration when any non-Text child exists. Merging: if the fragment contains snippet blocks, child and element statements are wrapped in a block in init (declaration-conflict avoidance, with a render statement when updates exist); if the fragment is dynamic they are spread into parent state; otherwise only element statements are kept. Finally a `dir = dir` self-assignment update works around a Chromium direction bug, a `value` attribute needing `__value` (option/select/group/checked, no spread) is emitted via build_element_special_value_attribute, and the element is popped from the template.

**Notes.**

- side_effect: Mutates shared template flags: needs_import_node (video/custom elements), contains_script_tag, plus template prop, init/update/after_update and hoisted arrays.
- condition: Snippet-block children force the whole child/element statement set into a block expression in init even when the fragment is otherwise static.

calls: [build_attribute_effect](r4-transform-client.md#u-0abd8487f7a1), [build_set_class](r4-transform-client.md#u-d08767f6fc10), [build_set_style](r4-transform-client.md#u-b481933571c2), [get_attribute_name](r4-transform-client.md#u-794bd7468f40), [visit_event_attribute](r2-client-transform.md#u-8ff2bf148b08), [process_children](r1-client-transform.md#u-7091653bb501), [build_render_statement](r5-transform-client.md#u-b84b76b77b0e), [build_template_chunk](r5-transform-client.md#u-d8d503fc4b7b), [clean_nodes](r2-client-transform.md#u-2ed26069223c), [determine_namespace_for_children](r2-client-transform.md#u-fca641f4927b), [setup_select_synchronization](r3-client-transform-visitors.md#u-97c8dc804a3c), [build_custom_element_attribute_update_assignment](r3-client-transform-visitors.md#u-4cdf2f9f4041), [build_element_attribute_update](r3-client-transform-visitors.md#u-b303d9b490e9), [build_element_special_value_attribute](r3-client-transform-visitors.md#u-d69720843218)

**Uncertainties.**

- Whether context.visit on OnDirective directives returns an Expression as asserted is guaranteed by the visitor contract, not by this file.

<a id="u-93d4778b5497"></a>
### `build_class_directives_object`

`export function build_class_directives_object( class_directives, context, memoizer = …` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/RegularElement.js:L468-L487][f8]

Builds an object literal mapping each class: directive name to its visited expression, tracking whether any expression has a call, state, or await.

When it does, the object is registered with the memoizer (so a stable identifier is reused across init/update) and that identifier is returned; otherwise the literal is returned directly.

<a id="u-4cdf2f9f4041"></a>
### `build_custom_element_attribute_update_assignment`

`function build_custom_element_attribute_update_assignment(node_id, attribute, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/RegularElement.js:L613-L624][f8]

Serializes one attribute of a custom element as `$.set_custom_element_data(node, name, value)`, preserving the attribute name's case since the runtime may set a case-sensitive property.

When the value is dynamic the call is wrapped in `$.template_effect`; because set_custom_element_data may not be idempotent, this statement is pushed to init ungrouped rather than merged with other updates.

**Notes.**

- side_effect: Always pushes a statement into context.state.init; never into update.

<a id="u-b303d9b490e9"></a>
### `build_element_attribute_update`

`function build_element_attribute_update(element, node_id, name, value, attributes)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/RegularElement.js:L552-L605][f8]

Chooses the update expression for one non-static attribute, by name.

`muted` becomes a direct property assignment (Firefox needs the property); `value`, `checked`, and `selected` route to `$.set_value`/`$.set_checked`/`$.set_selected`. `defaultValue`/`defaultChecked` route to `$.set_default_value`/`$.set_default_checked` only when a sibling static value/checked attribute exists (or the textarea has content), preventing the default from overriding the live value; otherwise they fall through. DOM properties (is_dom_property) become property assignments; everything else becomes `$.set_attribute` or `$.set_xlink_attribute` for xlink-prefixed names, with a hydration_attribute_changed ignore flag passed as a final boolean.

uses: [is_ignored](r5-compiler-state-utils.md#u-468324b42cee)

<a id="u-d69720843218"></a>
### `build_element_special_value_attribute`

`function build_element_special_value_attribute(element, node_id, attribute, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/RegularElement.js:L635-L685][f8]

Serializes the `value` attribute of select/option/input elements that need the hidden `__value` property.

The value is built with memoization, evaluated in scope, and assigned as `node.__value = value`; `node.value` then receives either that assignment or a `?? ''` fallback when the evaluated value may be undefined. For a select with a non-static value, the sequence additionally calls `$.select_option` to force the DOM one-way update (the select value is not reflected as an attribute, so a mutation observer would miss it). Dynamic values get a generated cache variable and an `if (cache !== (cache = value))` guard in update; for `option` the cache initializes to `{}` so an initial undefined still counts as a change. Static values emit once in init, and a select additionally gets `$.init_select` in init.

**Notes.**

- side_effect: Pushes into state.init and state.update, and generates a scope-unique variable name for the reactive cache.

<a id="u-29f008b00f20"></a>
### `build_style_directives_object`

`export function build_style_directives_object( style_directives, context, memoizer = …` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/RegularElement.js:L495-L522][f8]

Builds the style-directive payload for `style:` attributes.

Each directive value is either a getter for the implicit variable (when the directive has no value) or a visited attribute value; `!important` directives collect into a second object. The result is the normal object, or a `[normal, important]` array when important properties exist. As with classes, any call/state/await metadata causes the result to be memoized and returned as an identifier.

calls: [build_getter](r3-client-transform-utils.md#u-66a19e20e1f1)

<a id="u-97c8dc804a3c"></a>
### `setup_select_synchronization`

`function setup_select_synchronization(value_binding, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/RegularElement.js:L412-L460][f8]

For `<select bind:value>`, emits a `$.template_effect` in init that re-reads the bound expression and calls `$.invalidate_inner_signals` over every scope reference whose name differs from the bound root, keeping indirect updates of options in sync.

In runes mode it does nothing; a SequenceExpression binding also aborts. MemberExpression chains are unwrapped to the root object to find the bound name.

**Notes.**

- condition: Returns immediately in runes mode; the synchronization code is legacy-mode only.

group: [packages/svelte/src/compiler/phases/3-transform/client/visitors/RegularElement.js:RegularElement](r3-client-transform-visitors.md#u-f2ea5a46376e)

**Uncertainties.**

- bound.name is read after unwrapping MemberExpressions, so the bound root is assumed to be a named identifier; a different root kind would fail at runtime, not here.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/BlockStatement.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/BreakStatement.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/CallExpression.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/FunctionDeclaration.js
[f5]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/HtmlTag.js
[f6]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/LabeledStatement.js
[f7]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/OnDirective.js
[f8]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/RegularElement.js
