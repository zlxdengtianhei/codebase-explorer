# Expression & Script Reading

**Capability.** Parses JavaScript expressions (with Acorn-quirk index repair and a loose-identifier bracket fallback) and reads `<script>` element content up to its closing tag.

Use when investigating how inline `{expressions}` and script bodies are extracted. read_expression is the shared entry consumed by markup and attribute parsing; get_loose_identifier is its degraded-mode fallback.

**Depended on by.**

- [Markup & Attribute Parsing](r1-markup-tag-parsing.md) · graph-confirmed · 4 edge(s)
- [Template Parsing](r5-compiler-parse.md) · graph-only · 12 edge(s)

Parent: [Parse Phase](r1-compiler-parse.md)

## Units (3)

<a id="u-793d43872467"></a>
### `read_expression`

`export default function read_expression(parser, opening_token, disallow_loose)` · [packages/svelte/src/compiler/phases/1-parse/read/expression.js:L35-L93][f1]

Parses a JS expression at the parser's index using parse_expression_at, then repairs the index around Acorn quirks.

After parsing, the parser index is rewound to the end of any comment that ends before the node starts; the number of '(' characters between the old index and node.start is counted and each must be closed by a ')' (only whitespace allowed between them, else e.expected_token throws), and the index is advanced past those closers, also past a trailing comment if it ends later. On parse error: if parser.loose is set and disallow_loose is not, get_loose_identifier is tried and its empty Identifier returned; if that also fails (or loose mode is off/disallowed), parser.acorn_error rethrows. The loose path exists for each-loop destructuring like `as { y = z }`.

**Notes.**

- condition: disallow_loose suppresses the loose fallback even when parser.loose is set.

calls: [parse_expression_at](r5-compiler-parse.md#u-730e2a662101), [get_loose_identifier](r1-script-expression-parsing.md#u-f85dafe8159e)

<a id="u-f85dafe8159e"></a>
### `get_loose_identifier`

`export function get_loose_identifier(parser, opening_token)` · [packages/svelte/src/compiler/phases/1-parse/read/expression.js:L13-L27][f1]

Fallback reader used in 'loose' parsing: finds the next matching closing bracket (default '{') and returns an empty-named Identifier spanning to it, advancing parser.index.

Returns undefined when no matching bracket exists, signaling the caller to keep the original error.

calls: [find_matching_bracket](r4-compiler-parse.md#u-3e5597267416)

<a id="u-086699ac3458"></a>
### `read_script`

`export function read_script(parser, start, attributes)` · [packages/svelte/src/compiler/phases/1-parse/read/script.js:L22-L90][f2]

Reads the content of a `<script>` element up to the first `</script>` tag.

If the end of template is reached first, e.element_unclosed throws. The source handed to acorn.parse is the template prefix whitespace-masked (newlines preserved) plus the raw script data, so Acorn positions map back to the component file. Parse errors become parser.acorn_error. Attributes are then validated in order: reserved names (server, client, worker, test, default) throw e.script_reserved_attribute; unknown names emit w.script_unknown_attribute; `module` must be a shorthand (value === true) else e.script_invalid_attribute_value, and sets context to 'module'; `context` must be a text attribute with exactly the value 'module' else e.script_invalid_context, also yielding 'module'. Default context is 'default'. Returns an AST.Script node with the parsed Program as content.

**Notes.**

- side_effect: parser.index advances past the script data and the consumed closing tag via read_until/read.

calls: [ast-js-attribute-helpers](r4-compiler-ast-utils.md#u-e05972fa52ab)

**Uncertainties.**

- Which acorn.parse entry is invoked depends on ../acorn.js, not visible here; only that errors are converted by parser.acorn_error.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/1-parse/read/expression.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/1-parse/read/script.js
