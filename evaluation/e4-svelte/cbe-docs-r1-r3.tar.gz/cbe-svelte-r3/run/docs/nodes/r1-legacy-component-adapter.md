# Legacy Class-Component Adapter (Server)

**Capability.** Server-side adapter converting a Svelte 5 component into a Svelte 4-style class constructor, delegating construction to the legacy-client helper and attaching a `render(props, { context })` method.

Use when supporting legacy class-component consumption in SSR; it is the server half of the legacy interop layer.

**Depends on.**

- [Client Runtime](r1-client-runtime.md) · model-inferred · 0 edge(s)

Parent: [Public & Authoring APIs](r1-public-api.md)

## Units (1)

<a id="u-97e8d38a4382"></a>
### `packages/svelte/src/legacy/legacy-server.js:asClassComponent`

`export function asClassComponent(component)` · [packages/svelte/src/legacy/legacy-server.js:L22-L25][f1]

Server-side adapter converting a Svelte 5 component into a Svelte 4-style class constructor: delegates construction to `as_class_component` from legacy-client, then attaches a `render(props, { context })` method to the constructor.

`render` calls the SSR `render(component, { props, context })` and reshapes its result into `{ css: { code: '', map: null }, head: result.head, html: result.body }` — CSS is intentionally empty since styles are handled elsewhere in SSR. Returns the augmented constructor (with type-suppressing casts around both the render attachment and the return).

calls: [./legacy-client.js](../../catalog.json), [../internal/server/index.js](../../catalog.json), [packages/svelte/src/legacy/legacy-server.js:asClassComponent](r1-legacy-component-adapter.md#u-97e8d38a4382)

**Uncertainties.**

- The cast comment says the component must be compiled in SSR mode for `render` to work; failure behavior otherwise is not defined here

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/legacy/legacy-server.js
