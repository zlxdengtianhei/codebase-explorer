# Parse Phase

**Capability.** Turns raw Svelte template text into an AST: tags, attributes, directives, inline expressions, script content, HTML entity decoding, TypeScript-node stripping, and legacy AST conversion.

Use this subtree for anything about reading source text into AST nodes. Entity decoding and TypeScript stripping are supporting capabilities consumed by the parsing readers.

**Children.**

- [Markup & Attribute Parsing](r1-markup-tag-parsing.md) `r1-markup-tag-parsing` · 8 unit(s)
- [Expression & Script Reading](r1-script-expression-parsing.md) `r1-script-expression-parsing` · 3 unit(s)
- [HTML Entity Decoding](r1-html-entity-decoding.md) `r1-html-entity-decoding` · 4 unit(s)
- [TypeScript Node Stripping](r1-typescript-stripping.md) `r1-typescript-stripping` · 2 unit(s)
- [Legacy AST Conversion](r1-legacy-ast-conversion.md) `r1-legacy-ast-conversion` · 2 unit(s)

Parent: [Compiler](r1-compiler.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
