# Node Factories and Metadata Model

**Capability.** Lightweight AST node construction and classification used across phases: attribute/fragment factories, expression metadata, node-kind predicates, vendor-prefix handling for keyframes, and the compiler's element binding descriptor table.

Use this subtree when a phase needs to synthesize AST nodes, query expression metadata defaults, or classify a node as element/component/custom-element. bindings.js is a data table consulted when lowering bind: directives.

**Depends on.**

- [Scope and Binding Model](r4-compiler-scope.md) · model-inferred · 0 edge(s)

**Depended on by.**

- [Shared Analysis Validation](r4-analyze-shared-validation.md) · graph-confirmed · 1 edge(s)
- [Semantic Analysis Visitors](r4-analyze-visitors.md) · graph-confirmed · 2 edge(s)
- [Scope and Binding Model](r4-compiler-scope.md) · graph-confirmed · 1 edge(s)
- [Markup & Attribute Parsing](r1-markup-tag-parsing.md) · graph-only · 11 edge(s)

Parent: [Compiler Pipeline](r4-compiler.md)

## Units (9)

<a id="u-16d11cbbd59b"></a>
### `create_attribute`

`export function create_attribute(name, start, end, value)` · [packages/svelte/src/compiler/phases/nodes.js:L54-L66][f1]

Factory building a plain AST.Attribute node from a name, start/end positions and a value, with fresh metadata: delegated is null and needs_clsx is false.

Used by parsing, analysis and transform to synthesize attributes; delegation and clsx decisions must be re-derived after creation.

<a id="u-32bbb434f744"></a>
### `create_expression_metadata`

`export function create_expression_metadata()` · [packages/svelte/src/compiler/phases/nodes.js:L71-L81][f1]

Creates a blank ExpressionMetadata: empty dependencies and references Sets and all boolean flags (has_state, has_call, has_member_expression, has_assignment, has_await) false.

Each call returns an independent object used to seed per-node metadata that later analysis fills in.

<a id="u-99af92983a86"></a>
### `get_name`

`export function get_name(node)` · [packages/svelte/src/compiler/phases/nodes.js:L86-L92][f1]

Extracts a printable name from an expression node: String(node.value) for a Literal, '#' prefixed to the name for a PrivateIdentifier, the name for an Identifier, and null for any other node type.

Pure and total.

<a id="u-1354bdeaaf38"></a>
### `is_component_node`

`export function is_component_node(node)` · [packages/svelte/src/compiler/phases/nodes.js:L31-L33][f1]

Reports whether a node is component-like: its type is exactly Component, SvelteComponent, or SvelteSelf.

Unlike is_element_node it excludes RegularElement, SvelteElement, SlotElement and SvelteFragment. Pure predicate over node.type only.

<a id="u-ea1f0b51e1e8"></a>
### `is_custom_element_node`

`export function is_custom_element_node(node)` · [packages/svelte/src/compiler/phases/nodes.js:L39-L45][f1]

Detects custom elements.

Returns false unless the node is a RegularElement; a RegularElement counts as custom when its name contains a hyphen or any Attribute-typed attribute is literally named 'is'. SvelteElement nodes always yield false.

<a id="u-0d9a79ad394a"></a>
### `is_element_node`

`export function is_element_node(node)` · [packages/svelte/src/compiler/phases/nodes.js:L22-L24][f1]

Reports whether a node is element-like: it can carry attributes and children outside the top level.

Returns true when node.type is in the module-level element_nodes list (SvelteElement, RegularElement, SvelteFragment, Component, SvelteComponent, SvelteSelf, SlotElement); false otherwise. Pure predicate.

uses: [nodes.js module code (L1–L21)][f1]

<a id="u-8dc3955e3495"></a>
### `is_keyframes_node`

`export const is_keyframes_node = (node) =>` · [packages/svelte/src/compiler/phases/css.js:L14-L14][f2]

Reports whether an AST at-rule node is a keyframes rule by removing any vendor prefix from node.name and comparing to 'keyframes', so @-webkit-keyframes counts as keyframes.

Purely derived from the single node argument.

calls: [remove_css_prefix](r4-compiler-node-model.md#u-e3a939a3b9f2)

<a id="u-e3a939a3b9f2"></a>
### `remove_css_prefix`

`export function remove_css_prefix(name)` · [packages/svelte/src/compiler/phases/css.js:L9-L11][f2]

Strips a vendor prefix from a CSS name by replacing the first match of the browser-prefix regex (-webkit-, -moz-, -o-, -ms-) with the empty string.

Non-prefixed names pass through unchanged; only a leading prefix is removed.

<a id="u-316717409580"></a>
### `bindings.js-binding-properties`

`module_region` · [packages/svelte/src/compiler/phases/bindings.js:L1-L227][f3]

Declares the compiler's table of Svelte element binding descriptors keyed by binding name.

Each entry records optional metadata: an `event` naming the DOM event that signals changes, `bidirectional` when user input writes back to the property, `omit_in_ssr` to skip server-side rendering of the binding, and element restrictions via `valid_elements` (binding allowed only on listed tags, including pseudo-tags like svelte:window/svelte:document) or `invalid_elements` (forbidden tags). Entries range from media properties (currentTime, volume, muted as bidirectional on audio/video), document/window observables, dimension bindings (clientWidth etc., valid everywhere except svelte:window/svelte:document), form bindings (checked, group, indeterminate, value, files on input/textarea/select), to `this` and content bindings. `focused` is an empty object, so it carries no restrictions or SSR suppression. The table is consumed by later compile phases; this file contains no logic beyond the data.

**Uncertainties.**

- How consumers weigh each flag (e.g. precedence between valid_elements and invalid_elements) is not visible in this file.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/nodes.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/css.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/bindings.js
