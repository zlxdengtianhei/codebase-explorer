# Repository Tooling

**Capability.** Developer tooling around the library: branch-comparison benchmarking with a forked runner, reactivity microbenchmarks, the Rollup UMD build of the compiler, the tree-shakeability audit script, and the shared Vitest configuration.

Nothing here ships to users. benchmarks measure runtime behavior; build-tooling builds and audits the published artifacts and test setup.

**Children.**

- [Reactivity Benchmarks](r3-benchmarks.md) `r3-benchmarks` · 4 unit(s)
- [Build and Audit Tooling](r3-build-tooling.md) `r3-build-tooling` · 5 unit(s)

Parent: [Svelte Compiler and Runtime](r3-svelte.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
