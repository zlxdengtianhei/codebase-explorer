# Client Static Template Emission

**Capability.** Accumulates a component's static template as a lightweight node tree and emits it either as an HTML string (with escaping) or as a JS array literal for tree-mode hydration.

Read Template to understand how static markup is collected during client transformation; stringify and objectify are the two serialization backends. Dynamic parts are added by transform visitors as effects referencing template positions.

**Depends on.**

- [Shared Source Utilities](r4-shared-source-utilities.md) · graph-confirmed · 1 edge(s)

**Depended on by.**

- [Client Code Transformation](r4-transform-client.md) · graph-confirmed · 2 edge(s)

Parent: [Compiler Pipeline](r4-compiler.md)

## Units (3)

<a id="u-f09b36ebd45e"></a>
### `Template`

`class Template` · [packages/svelte/src/compiler/phases/3-transform/client/transform-template/template.js:L9-L34][f1]

Accumulates a component's static template as a lightweight node tree and emits it as an HTML string or a JS array literal.

State: nodes holds top-level nodes, #fragment points at the current children array (initially nodes), #element at the innermost element, #stack tracks nesting; contains_script_tag and needs_import_node are flags read by transform_template's caller. push_element creates an element node with empty attributes/children, appends it, and descends into its children; pop_element pops the stack so later nodes become siblings (a pop on the root stack would leave #fragment as the last array from at(-1), i.e. it does not guard under-popping); set_prop writes attributes[key] on the innermost element, with undefined meaning a bare attribute; push_comment/push_text append comment/text nodes verbatim. as_html returns a single-quasi template of the stringified nodes. as_tree returns an array of objectified nodes, unshifting an extra data-less comment when the first node is a comment so effect.start has an anchor.

**Notes.**

- failure: as_tree dereferences this.nodes[0].type without an empty-nodes guard.
- side_effect: as_tree mutates this.nodes via unshift; calling it twice on the same Template would add another anchor comment each time.
- field: contains_script_tag must be set by another visitor to take effect; it is only declared here.

calls: [fix_attribute_casing](r5-transform-client.md#u-799dccdfecc2); uses: [stringify](r4-transform-template.md#u-61b15a4cd312), [objectify](r4-transform-template.md#u-c628bcd2b8ab)

**Uncertainties.**

- Where contains_script_tag/needs_import_node are set is not visible in this file.

<a id="u-c628bcd2b8ab"></a>
### `objectify`

`function objectify(item)` · [packages/svelte/src/compiler/phases/3-transform/client/transform-template/template.js:L119-L162][f1]

Converts one template node into JS AST for tree-mode templates.

Text becomes a literal of concatenated node data; a comment with data becomes an array containing the literal '// data', a data-less comment becomes null. Elements become [name, attributes-or-null, ...children]: attribute keys pass through fix_attribute_casing and undefined values become void 0; the attributes slot is emitted (as the object, or null when empty) whenever there are attributes or children. For pre/textarea elements a leading newline is stripped from a literal first child, matching HTML parsing rules; non-literal first children are left untouched.

calls: [fix_attribute_casing](r5-transform-client.md#u-799dccdfecc2)

**Uncertainties.**

- The exact tree encoding consumed by $.from_tree lives outside this file.

<a id="u-61b15a4cd312"></a>
### `stringify`

`function stringify(item)` · [packages/svelte/src/compiler/phases/3-transform/client/transform-template/template.js:L89-L116][f1]

Serializes one template node to HTML.

Text nodes concatenate raw source; comments render as <!--data--> or, when data is absent, the '<!>' empty-comment marker. Elements emit an open tag with each attribute (no ="..." when the value is undefined, i.e. a bare attribute), escaping defined values with escape_html(value, true); void element names self-close as '/>' for XHTML compliance, otherwise children are recursively stringified between open and close tags.

calls: [escape_html](r4-shared-source-utilities.md#u-0f499dd45547), [utils-js-predicates](r3-shared-utils.md#u-7eb274f609ad)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/transform-template/template.js
