# Task Scheduling

**Capability.** Micro-task and idle-task scheduling queues plus the shared raf frame-loop object used across the client runtime.

Treat as shared infrastructure: bindings, events, and block effects all enqueue work here rather than scheduling directly.

**Depends on.**

- [Shared Runtime Utilities](r1-shared-runtime.md) · graph-confirmed · 2 edge(s)

**Depended on by.**

- [DOM Template Blocks](r1-dom-blocks.md) · graph-confirmed · 1 edge(s)
- [Element Bindings](r1-element-bindings.md) · graph-confirmed · 3 edge(s)
- [Event System & Delegation](r1-event-system.md) · graph-confirmed · 1 edge(s)

Parent: [Client Runtime](r1-client-runtime.md)

## Units (2)

<a id="u-08b6b6ebaf85"></a>
### `task-js-queues`

`function run_micro_tasks()` · [packages/svelte/src/internal/client/dom/task.js:L15-L19][f1]

Micro-task and idle-task scheduling queues.

queue_micro_task pushes a callback onto `micro_tasks`, scheduling run_micro_tasks via queueMicrotask only when the queue was empty; run_micro_tasks swaps out the array and runs all callbacks via run_all, so callbacks queued during the flush run in a later micro-task. queue_idle_task is analogous with `idle_tasks`, scheduling run_idle_tasks through requestIdleCallback, with a setTimeout(cb, 1) fallback when that API is undefined. flush_tasks synchronously drains both queues, micro first then idle, when non-empty.

**Notes.**

- side_effect: run_micro_tasks/run_idle_tasks reassign the module arrays before running, so tasks enqueued while flushing do not recurse into the current flush.

imports: [task.js module code (L1–L14)][f1]

**Uncertainties.**

- run_all's error behavior (whether a throwing task aborts the rest) is defined in shared/utils.js and not visible here.

<a id="u-b023d8ac85e3"></a>
### `timing.js module code (L1–L16)`

`module_region` · [packages/svelte/src/internal/client/timing.js:L1-L16][f2]

Defines the shared raf object used by the frame loop.

now() returns performance.now() in the browser and Date.now() otherwise. tick delegates to requestAnimationFrame in the browser and to noop otherwise, resolved at call time (deliberately not eagerly, so code can run without JSDOM in tests). tasks is a Set of frame tasks that loop.js iterates and mutates.

**Notes.**

- field: raf.tick and raf.now are deliberately indirect so tests can override them.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/task.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/timing.js
