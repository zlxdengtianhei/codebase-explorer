# Server Runtime

**Capability.** Non-reactive server-side execution: Payload/HeadPayload output buffers for SSR body and head content, payload cloning for legacy bindings, id generation, and inert server stand-ins for reactive classes and store conversions typed by the render() entry.

Use when changing SSR output plumbing. payload.js is the rendering accumulator consumed by server codegen; index-server reactivity/store modules intentionally do nothing reactive; server/index.d.ts types the public render entry.

**Depends on.**

- [Signal Reactivity Core](r5-client-reactivity.md) · model-inferred · 0 edge(s)
- [Shared Runtime Infrastructure](r5-runtime-shared.md) · graph-confirmed · 5 edge(s)

**Depended on by.**

- [Server Codegen Visitors](r5-transform-server.md) · model-inferred · 0 edge(s)

Parent: [Svelte Monorepo](r5-svelte.md)

## Units (13)

<a id="u-88f15d8dfda3"></a>
### `Payload`

`class Payload` · [packages/svelte/src/internal/server/payload.js:L22-L32][f1]

Server render output buffer holding body HTML, CSS entries, select_value tracking, and an owned HeadPayload.

**Notes.**

- field: Constructor wires the id generator (props_id_generator(id_prefix)) into both this.uid and head.uid, so ids generated in body and head share one counter and prefix.

<a id="u-0180f968bb91"></a>
### `HeadPayload`

`class HeadPayload` · [packages/svelte/src/internal/server/payload.js:L1-L9][f1]

Collect head output for a server render: CSS source entries, head HTML lines, an id generator, and the title.

**Notes.**

- field: Defaults are fresh instances; constructor parameters allow sharing css/out/uid with a parent Payload so head fragments accumulate in the right buffers.

<a id="u-bbeddcad611f"></a>
### `assign_payload`

`export function assign_payload(p1, p2)` · [packages/svelte/src/internal/server/payload.js:L65-L70][f1]

Copy the second payload's contents into the first, cloning out but sharing css, head, and uid by reference.

**Notes.**

- side_effect: p1.out gets a snapshot copy of p2.out; p1.head becomes p2.head itself, so later head writes via p1 affect p2's head.

<a id="u-ab7dea894e0f"></a>
### `copy_payload`

`export function copy_payload({ out, css, head, uid })` · [packages/svelte/src/internal/server/payload.js:L43-L57][f1]

Clone a payload for legacy binding handling, duplicating out arrays and CSS sets but sharing the uid generator.

**Notes.**

- side_effect: out arrays and css Sets (including head's) are copied into fresh instances; head.title and head.uid are copied by reference/value; subsequent writes to the clone do not affect the original.

<a id="u-059a47caefaa"></a>
### `props_id_generator`

`function props_id_generator(prefix)` · [packages/svelte/src/internal/server/payload.js:L77-L80][f1]

Create an id generator producing prefix + 's' + an incrementing counter starting at 1.

<a id="u-e5d9c940c631"></a>
### `payload.js module code (L36–L42)`

`module_region` · [packages/svelte/src/internal/server/payload.js:L36-L42][f1]

Non-behavioral gap between the Payload class and copy_payload.

<a id="u-a983ca0847cb"></a>
### `payload.js module code (L57–L64)`

`module_region` · [packages/svelte/src/internal/server/payload.js:L57-L64][f1]

Non-behavioral gap between copy_payload and assign_payload.

<a id="u-ea90e93ca217"></a>
### `payload.js module code (L70–L76)`

`module_region` · [packages/svelte/src/internal/server/payload.js:L70-L76][f1]

Non-behavioral gap between assign_payload and props_id_generator.

<a id="u-8fae15838695"></a>
### `MediaQuery`

`class MediaQuery` · [packages/svelte/src/reactivity/index-server.js:L7-L13][f2]

Server-side inert stand-in for the reactive MediaQuery class: it stores only a boolean current field, set from the optional matches constructor argument (defaulting to false), and performs no media-query subscription.

This is the server companion of the client MediaQuery exported from index-client.js.

<a id="u-0c1b5a22246d"></a>
### `packages/svelte/src/reactivity/index-server.js:createSubscriber`

`export function createSubscriber(_)` · [packages/svelte/src/reactivity/index-server.js:L21-L23][f2]

Server-side no-op replacement for createSubscriber: it ignores its argument and returns a function that does nothing, so subscribe calls are inert outside a reactive client runtime.

<a id="u-2a69132bdb51"></a>
### `packages/svelte/src/store/index-server.js:fromStore`

`export function fromStore(store)` · [packages/svelte/src/store/index-server.js:L84-L87][f3]

Server (SSR) `fromStore`: returns an object whose `current` getter simply calls `get(store)` — no subscription machinery, correct for non-reactive server rendering.

When the store has a `set` property, the returned object additionally exposes `set current(v)` delegating to `store.set(v)`; otherwise `current` is read-only.

calls: [./shared/index.js](../../catalog.json)

**Uncertainties.**

- Same `'set' in store` discrimination caveat as the client variant

<a id="u-7280df9e1bf0"></a>
### `packages/svelte/src/store/index-server.js:toStore`

`export function toStore(get, set)` · [packages/svelte/src/store/index-server.js:L35-L49][f3]

Server (SSR) `toStore`: creates a `writable` seeded once with `get()` and no reactive plumbing — there is no effect tracking on the server.

With a `set` argument it returns a Writable-shaped object whose `update` is `set(fn(get()))` and which shares the store's `subscribe`; otherwise a Readable-shaped object exposing only `subscribe`. Values never update after creation in this build.

calls: [./shared/index.js](../../catalog.json)

<a id="u-d452e617d953"></a>
### `packages/svelte/src/server/index.d.ts:render`

`export function render< Comp extends SvelteComponent<any> | Component<any>, Props ext…` · [packages/svelte/src/server/index.d.ts:L8-L29][f4]

Server-only SSR entry point typed as a variadic overload pair.

When props are fully optional ({} extends Props), the options argument is optional; otherwise options with a props field (minus $$slots and $$events) is required. Options also accept a context Map and idPrefix. The component argument accepts either a component class (for SvelteComponent instances) or a component function. Returns RenderOutput with body and head used to populate server-rendered HTML.

**Uncertainties.**

- Runtime behavior lives in the implementation module; this declaration alone cannot confirm output shape beyond the RenderOutput type.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/server/payload.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/reactivity/index-server.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/store/index-server.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/server/index.d.ts
