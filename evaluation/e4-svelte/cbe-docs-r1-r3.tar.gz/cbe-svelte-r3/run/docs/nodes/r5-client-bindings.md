# Element Bindings

**Capability.** Two-way binding implementations for DOM targets: select value/options syncing, contenteditable and generic property bindings, focus tracking, window scroll/size, navigator online, and exposing component exports for bind: on $props.

Use when adding or fixing a bindable. Each binding wires an event/observer to a set() callback, often avoiding reactive-context reads (window bindings use without_reactive_context per their summaries). select.js decomposes into init/select_option/get_option_value helpers.

**Depends on.**

- [Effect System](r4-runtime-effects.md) · graph-only · 9 edge(s)

Parent: [Client Runtime](r5-runtime-client.md)

## Units (11)

<a id="u-40e4240d9329"></a>
### `bind_online`

`export function bind_online(update)` · [packages/svelte/src/internal/client/dom/elements/bindings/navigator.js:L7-L11][f1]

Calls update with navigator.onLine whenever the window fires online or offline.

calls: [listen](r2-dom-elements.md#u-8f0d8dd6601b)

<a id="u-7e3a8e97cbcd"></a>
### `bind_prop`

`export function bind_prop(props, prop, value)` · [packages/svelte/src/internal/client/dom/elements/bindings/props.js:L13-L22][f2]

Exposes a component's exported variable on the $$props object so consumers can bind to it.

It reads the property descriptor; only if a setter exists does it assign the value immediately and schedule teardown that assigns null back to props[prop] on destroy. Without a setter the call does nothing.

**Notes.**

- side_effect: Teardown writes null, not the original value, to props[prop].

calls: [teardown](r4-runtime-effects.md#u-afcffe6190df)

<a id="u-6cdee6c1aa0d"></a>
### `bind_select_value`

`export function bind_select_value(select, get, set = get)` · [packages/svelte/src/internal/client/dom/elements/bindings/select.js:L85-L128][f3]

Two-way binds a select's value.

The change handler queries '[selected]' after a form reset, otherwise ':checked'; for multiple selects it maps all matches to their option values into an array, for single selects it takes the checked option or falls back to the first non-disabled option, and calls set with its value (possibly undefined). An effect (not render_effect, so it runs after each-block updates) applies get() via select_option with a mounting flag; while mounting with an undefined value it adopts the DOM's checked option value by calling set, then stores value as select.__value and clears the mounting flag. init_select registers the option-mutation observer.

calls: [listen_to_event_and_reset_event](r2-dom-elements.md#u-adb7ad8d3643), [select_option](r5-client-bindings.md#u-fc6c91d49336), [get_option_value](r5-client-bindings.md#u-3a26469d61b5), [init_select](r5-client-bindings.md#u-f378be747d77)

<a id="u-3a26469d61b5"></a>
### `get_option_value`

`function get_option_value(option)` · [packages/svelte/src/internal/client/dom/elements/bindings/select.js:L131-L138][f3]

Returns option.__value when the option carries one (set by a value attribute), otherwise the option's text value property.

<a id="u-f378be747d77"></a>
### `init_select`

`export function init_select(select)` · [packages/svelte/src/internal/client/dom/elements/bindings/select.js:L55-L77][f3]

Keeps a select's DOM selection in sync when its options change outside the binding, e.g. options inside an #each block.

A MutationObserver on the select (childList with subtree for optgroup, plus value attribute changes filtered to 'value') re-runs select_option with the select's stored __value, deliberately not updating the model value. Teardown disconnects the observer.

calls: [select_option](r5-client-bindings.md#u-fc6c91d49336), [teardown](r4-runtime-effects.md#u-afcffe6190df)

<a id="u-fc6c91d49336"></a>
### `select_option`

`export function select_option(select, value, mounting = false)` · [packages/svelte/src/internal/client/dom/elements/bindings/select.js:L14-L45][f3]

Selects the option(s) matching value in a select element.

For a multiple select: a nullish value leaves the selection untouched; a non-array value warns via w.select_multiple_invalid_value and also leaves it untouched; otherwise each option's selected flag is set from membership of its option value in the array. For a single select, the first option whose value matches (via is) is selected and the function returns; if none matches, selectedIndex is set to -1 unless mounting with an undefined value, in which case the DOM's initial selection is preserved.

calls: [is](r4-runtime-signals.md#u-dcae92a399e9), [get_option_value](r5-client-bindings.md#u-3a26469d61b5)

<a id="u-08959d6f86b1"></a>
### `bind_content_editable`

`export function bind_content_editable(property, element, get, set = get)` · [packages/svelte/src/internal/client/dom/elements/bindings/universal.js:L11-L31][f4]

Two-way binds an element's contenteditable-driven property (innerHTML, textContent or innerText).

A raw input listener pushes element[property] into state. A render effect reads get() and, when it differs from the DOM: if the value is nullish it pushes the current DOM value back into state (a null cannot be assigned), otherwise it assigns value coerced with + ''. Note this binding adds its listener directly, not via listen, so no immediate handler call or teardown removal for the input listener occurs here.

calls: [render_effect](r4-runtime-effects.md#u-bbe822faa096); uses: [listen](r2-dom-elements.md#u-8f0d8dd6601b)

<a id="u-0d6d1a335820"></a>
### `bind_focused`

> **ID corrected by CBE.** CBE changed the unit ID from ` packages/svelte/src/internal/client/dom/elements/bindings/universal.js::function::bind_focused::71 ` to the inventory ID ` packages/svelte/src/internal/client/dom/elements/bindings/universal.js::function::bind_focused::1521 `. The model wrote this body under the wrong ID; it may be inaccurate.

`export function bind_focused(element, set)` · [packages/svelte/src/internal/client/dom/elements/bindings/universal.js:L71-L75][f4]

Calls set with whether the element is currently document.activeElement, on every focus or blur event, with an immediate initial call from listen.

calls: [listen](r2-dom-elements.md#u-8f0d8dd6601b)

<a id="u-b50b57e2cff1"></a>
### `bind_property`

`export function bind_property(property, event_name, element, set, get)` · [packages/svelte/src/internal/client/dom/elements/bindings/universal.js:L41-L42][f4]

Two-way binds an arbitrary DOM property via a custom event name.

A handler pushes element[property] into state and is added as a listener for event_name. When get is supplied, a render effect assigns get() to element[property]; when absent, the handler runs once immediately. Listener removal during teardown happens only when the element is document.body, window or document — for ordinary elements the listener intentionally outlives teardown per this source.

calls: [render_effect](r4-runtime-effects.md#u-bbe822faa096), [teardown](r4-runtime-effects.md#u-afcffe6190df)

<a id="u-d8dc2a0f3d67"></a>
### `bind_window_scroll`

`export function bind_window_scroll(type, get, set = get)` · [packages/svelte/src/internal/client/dom/elements/bindings/window.js:L10-L13][f5]

Two-way binds window scrollX (type 'x') or scrollY.

A passive global scroll handler runs inside without_reactive_context: it marks scrolling true and re-arms a 100ms timeout whose clear callback resets the flag, then pushes the current scroll value into state. A render effect pushes state to the window: the first run never scrolls (accessibility), afterwards when not scrolling and the value is non-null it sets scrolling, scrolls via scrollTo preserving the other axis, and re-arms the same timeout. An effect fires the handler once so the initial scroll position is reported (browsers do not fire scroll for the initial position); teardown removes the scroll listener.

calls: [without_reactive_context](r2-dom-elements.md#u-ff3a57d1f4f9), [teardown](r4-runtime-effects.md#u-afcffe6190df)

**Uncertainties.**

- The comment notes the scrollend event could replace the 100ms timeout; no scrollend logic exists in this source.

<a id="u-8c08fbfaa5cf"></a>
### `bind_window_size`

`export function bind_window_size(type, set)` · [packages/svelte/src/internal/client/dom/elements/bindings/window.js:L64-L66][f5]

On window resize, calls set with window[type] (innerWidth/innerHeight/outerWidth/outerHeight), computed inside without_reactive_context so the read registers no dependency; listen provides the immediate initial call and teardown.

calls: [listen](r2-dom-elements.md#u-8f0d8dd6601b), [without_reactive_context](r2-dom-elements.md#u-ff3a57d1f4f9)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/elements/bindings/navigator.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/elements/bindings/props.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/elements/bindings/select.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/elements/bindings/universal.js
[f5]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/elements/bindings/window.js
