# Client Transform Phase

**Capability.** Third compilation phase for client output: assembles the zimmerframe visitor map and transforms component analyses into DOM-creating client modules, using shared helpers that decide reactivity.

Entry points are client_component and client_module; utils build the reactive read expressions; visitors serialize each AST node. Utils are consumed by both entry points and visitors.

**Children.**

- [Client Transform Utilities](r3-client-transform-utils.md) `r3-client-transform-utils` · 8 unit(s)
- [Client Transform Visitors](r3-client-transform-visitors.md) `r3-client-transform-visitors` · 14 unit(s)

**Depends on.**

- [Analysis Driver](r3-analyze-driver.md) · model-inferred · 0 edge(s)
- [Client Transform Utilities](r3-client-transform-utils.md) · containment · → 4 / ← 0 edge(s) (ancestor direct units and descendant subtree; → follows ` r3-client-transform ` → ` r3-client-transform-utils `)

Parent: [Compiler Pipeline](r3-compiler.md)

## Units (3)

<a id="u-a04bf2770de7"></a>
### `transform-client-imports-and-visitors`

`module_region` · [packages/svelte/src/compiler/phases/3-transform/client/transform-client.js:L1-L147][f1]

Assembles the client-side visitor map used by zimmerframe walks and a special '_' visitor that re-scopes name transforms at scope boundaries.

The '_' handler looks up the scope for the node; if it differs from the current scope, it clones state.transform and deletes entries for declarations in that scope — always for 'normal' bindings, and for 'state' bindings only when is_state_source says the declaration is not a reassigned/accessed state source — then continues with the reduced transform and new scope; otherwise it continues unchanged. The remaining keys map node types one-to-one to imported visitor functions.

calls: [is_state_source](r3-client-transform-utils.md#u-4eba3d9b7ec5); contract: [types-d-ts-state-interfaces](r1-client-transform.md#u-57396322111a)

<a id="u-15bd8cef14fb"></a>
### `client_component`

`export function client_component(analysis, options)` · [packages/svelte/src/compiler/phases/3-transform/client/transform-client.js:L148-L698][f1]

Transforms a component analysis into a complete client-side ES module AST entry point.

It builds a ComponentClientTransformState seeded with a `svelte/internal/client` import-all, then walks the module AST, the instance AST (sharing the accumulated transform map, instance scope, is_instance=true), and the template AST (instance transform/scope, template scopes). It then synthesizes the component function body: legacy_reactive declarations as `$.mutable_source` consts; store subscriptions via `$.setup_stores` with a `$$cleanup` flag and dev-only `$.validate_store` wrapping; legacy reactive statements appended (throwing 'Could not find reactive statement' if a statement is missing from state.legacy_reactive_statements) plus `$.legacy_pre_effect_reset`; binding-group arrays; and an exported-properties object whose shape depends on binding kind — let/var identifiers get getter+setter, non-dev non-reactive identifiers get `init`, prop/bindable_prop get setter via `name($$value)`, state gets `$.set` with `$.proxy` wrapping (raw_state without), otherwise getter only. `analysis.accessors` adds getter/setter pairs (runes-mode setters default `$$value` to the binding's initial). componentApi===4 adds `$set`/`$on` legacy members, else dev mode spreads `$.legacy_api()`. If instance.has_await, the body is wrapped in `$.async_body` with a `$.aborted` early return and `$$exports` assigned after await; otherwise statements are inlined and non-runes contexts get `$.init`. Conditionally prepends `$.push`/`$.pop` (should_inject_context), ownership validator, rest/sanitized props, `$$slots`, styles via render_stylesheet when css.ast exists and inject_styles is set, and `$.bind_prop` for static exports in legacy mode. Hoisted statements and module body are merged with imports first; HMR mode wraps the component with `$.hmr` and import.meta.hot.accept (cleaning styles if a css hash exists); dev mode stamps the filename on the component. Custom-element options emit `$.create_custom_element` (inferring Boolean type from boolean literal initials, skipping already-declared props), calling `customElements.define` when a string tag is given (guarded under HMR); use_shadow_dom is true unless ce is a non-boolean object with shadow==='none'. Flag imports (async/legacy/tracing/disclose-version) are unshifted by option, and collected events produce a `$.delegate` call.

**Notes.**

- failure: A legacy reactive statement missing from state.legacy_reactive_statements throws Error('Could not find reactive statement') during emission.
- side_effect: Mutates node.metadata-like shared state via walks; the returned program is the module's export default (plus HMR and custom-element registration statements).

calls: [render_stylesheet](r2-css-transform.md#u-197b2d45aa0c), [build_getter](r3-client-transform-utils.md#u-66a19e20e1f1); uses: [transform-client-imports-and-visitors](r3-client-transform.md#u-a04bf2770de7)

**Uncertainties.**

- The exact runtime effect of `$.push`/`$.pop` and other internal calls is defined in svelte/internal/client, not in this file.
- iterators' `.next()` resolution was ambiguous in the graph; behavior here rests on reading the synchronous for-of loops over analysis collections.

<a id="u-1e0775efa9e3"></a>
### `client_module`

`export function client_module(analysis, options)` · [packages/svelte/src/compiler/phases/3-transform/client/transform-client.js:L705-L734][f1]

Transforms a `<script module>` analysis into a client ES module.

It builds a ClientTransformState (no component-level fields) from the module scope and walks the module AST with the shared visitors, then returns a Program whose body starts with a `svelte/internal/client` import-all, conditionally adds a tracing flag import when analysis.tracing is set, and appends the walked module body.

uses: [transform-client-imports-and-visitors](r3-client-transform.md#u-a04bf2770de7)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/transform-client.js
