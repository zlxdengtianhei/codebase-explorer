# Public API, Types & Reactive Primitives

**Capability.** The published type and authoring surface: Component/mount/snippet typings, per-element attribute maps, the svelteHTML namespace, and user-facing reactive value types (SvelteDate/SvelteMap/SvelteURL, media/window state, store↔reactive interop) layered over the internal signal system.

Use this subtree for consumer-facing behavior and typings rather than compiled internals. Each primitive wraps runtime reactivity with start/stop subscriptions; the d.ts surfaces are loaded by the language server and deliberately structured for extension. Region evidence shows it leans on the client runtime and compiler typings (region-0002→region-0004, region-0002→region-0005) and is consumed by them in return.

**Children.**

- [Svelte Codebase](r2-svelte-codebase.md) `r2-svelte-codebase` · 9 unit(s)

**Depends on.**

- [Client Runtime](client-runtime.md) · graph-confirmed · 112 edge(s)
- [Compiler Pipeline](compiler-pipeline.md) · graph-confirmed · 46 edge(s)
- [Server & Shared Runtime](server-and-shared-runtime.md) · graph-confirmed · 22 edge(s)

**Depended on by.**

- [Client Runtime](client-runtime.md) · graph-confirmed · 57 edge(s)
- [Compiler Pipeline](compiler-pipeline.md) · graph-confirmed · 71 edge(s)
- [Server & Shared Runtime](server-and-shared-runtime.md) · graph-confirmed · 59 edge(s)
- [Svelte Repository](svelte-repo.md) · containment · → 0 / ← 0 edge(s) (ancestor direct units and descendant subtree; → follows ` svelte-repo ` → ` public-api-types `)

Parent: [Svelte Repository](svelte-repo.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
