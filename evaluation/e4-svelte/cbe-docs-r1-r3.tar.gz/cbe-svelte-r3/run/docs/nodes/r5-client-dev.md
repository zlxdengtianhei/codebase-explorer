# Dev-Mode Diagnostics

**Capability.** Development-only validation: equality wrappers that warn when comparing reactive proxies differs from comparing unwrapped values (including patched Array.prototype methods), and an ownership validator enforcing cross-component prop mutation rules.

Use when improving developer-facing warnings. These modules are only active in dev builds; ownership validation is invoked from generated code via the compiler's validate_mutation wrappers.

**Depended on by.**

- [DOM Operations & Elements](r5-client-dom.md) · graph-confirmed · 1 edge(s)

Parent: [Client Runtime](r5-runtime-client.md)

## Units (5)

<a id="u-3c0065301141"></a>
### `init_array_prototype_warnings`

`export function init_array_prototype_warnings()` · [packages/svelte/src/internal/client/dev/equality.js:L4-L69][f1]

Patches Array.prototype.indexOf, lastIndexOf, and includes for dev builds to detect equality mismatches caused by reactive proxies: after delegating to the original method, if the result is a miss (-1 or false), it scans the array comparing items through get_proxied_value and warns state_proxy_equality_mismatch with the method name if an unwrapped item matches.

lastIndexOf passes from_index ?? this.length - 1 explicitly because the native method treats undefined differently from omission. The REPL calls this repeatedly, so a stored Array.__svelte_cleanup restores the originals before re-patching, and a new cleanup closure is saved each time; this is why calling it more than once does not stack wrappers.

**Notes.**

- side_effect: Mutates global Array.prototype; the cleanup function is the only way the originals are restored.

calls: [get_proxied_value](r4-runtime-signals.md#u-0468b533d5f3)

**Uncertainties.**

- Behavior of arrays whose length changes during the warning scan is not specified by the source.

<a id="u-28877320e4f3"></a>
### `strict_equals`

`export function strict_equals(a, b, equal = true)` · [packages/svelte/src/internal/client/dev/equality.js:L77-L87][f1]

Dev-mode strict equality that warns when comparing a reactive proxy directly differs from comparing its unwrapped value: if (a === b) !== (get_proxied_value(a) === get_proxied_value(b)) it emits state_proxy_equality_mismatch with '===' or '!==' depending on the equal flag.

Reads of a and b are wrapped in try/catch because property access can be disallowed in secure contexts; the warning is skipped on error. Returns (a === b) === equal, so callers invert the result for !==.

calls: [get_proxied_value](r4-runtime-signals.md#u-0468b533d5f3)

<a id="u-1016bd3303e1"></a>
### `equals`

`export function equals(a, b, equal = true)` · [packages/svelte/src/internal/client/dev/equality.js:L95-L101][f1]

Loose-equality counterpart of strict_equals: warns when (a == b) differs from comparing unwrapped values with ==, labeling the warning '==' or '!=' per the equal flag.

Unlike strict_equals there is no try/catch, so a throwing property read propagates. Returns (a == b) === equal.

calls: [get_proxied_value](r4-runtime-signals.md#u-0468b533d5f3)

<a id="u-cec8691d0119"></a>
### `create_ownership_validator`

`export function create_ownership_validator(props)` · [packages/svelte/src/internal/client/dev/ownership.js:L16-L66][f2]

Creates a dev validator enforcing cross-component ownership rules for props.

mutation(prop, path, result, line, column) allows the change and returns result unchanged when the root property is bound or unset, when there is no parent component, or when any intermediate value along the path lacks STATE_SYMBOL; otherwise it warns ownership_invalid_mutation with the current component's sanitized file:line:column location and the parent's FILENAME, still returning result so the mutation itself proceeds. binding(key, child_component, value) warns ownership_invalid_binding when the key is not bound/unset, a parent exists, and value() carries STATE_SYMBOL, indicating a state object leaked across a binding boundary. Both resolve component and parent from component_context.

calls: [is_bound_or_unset](r5-client-dev.md#u-cde78e1b7b26), [utils-js-predicates](r3-shared-utils.md#u-7eb274f609ad)

**Uncertainties.**

- value() in binding is invoked once; side effects of that getter are not controlled here.
- Whether the mutation warning blocks the mutation depends on callers, which are outside this file.

<a id="u-cde78e1b7b26"></a>
### `is_bound_or_unset`

`function is_bound_or_unset(props, prop_name)` · [packages/svelte/src/internal/client/dev/ownership.js:L72-L81][f2]

Determines whether a prop may legally be mutated or bound without ownership complaints.

Returns true when a property descriptor with a setter exists (a bound prop), when props is an entry-point props object (carrying STATE_SYMBOL or LEGACY_PROPS, e.g. from mount with $state props or createClassComponent) and the name is present, or when the name is not present at all. These cases exempt the caller from ownership warnings in create_ownership_validator.

uses: [create_ownership_validator](r5-client-dev.md#u-cec8691d0119)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dev/equality.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dev/ownership.js
