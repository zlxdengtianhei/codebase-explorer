# CSS Transform

**Capability.** Renders the analyzed stylesheet into final CSS text and a source map via a zimmerframe visitor pass that scopes selectors, strips :global, prunes unused/empty rules, and escapes comment boundaries.

render_stylesheet drives the visitor object; the small helpers (is_empty, is_used, is_in_global_block, remove_global_pseudo_class, remove_preceding_whitespace, escape_comment_close) implement the pruning and rewriting decisions. Use this subtree for output-CSS and source-map issues.

**Depends on.**

- [Compiler Foundations](r2-compiler-foundations.md) · model-inferred · 0 edge(s)
- [CSS Analysis](r2-css-analyze.md) · model-inferred · 0 edge(s)

Parent: [CSS Pipeline](r2-css-pipeline.md)

## Units (8)

<a id="u-fdc33a016f25"></a>
### `css-index-js-visitors`

`const visitors = { _: (node, context) => { context.state.code.addSourcemapLocation(no…` · [packages/svelte/src/compiler/phases/3-transform/css/index.js:L76-L99][f1]

The zimmerframe visitor object that scopes, prunes, and minifies the CSS AST.

Default `_`: records each node's start/end as sourcemap locations, then recurses. Atrule: for keyframes nodes it locates the name; if the prelude starts with '-global-' it removes that prefix, otherwise when not inside a global block it prepends the hash prefix; it then returns without transforming anything inside the at-rule; other at-rules recurse. Declaration: for 'animation'/'animation-name' it scans the value characters and prepends the hash to any name found in state.keyframes; when minifying it removes whitespace before the declaration and between property and value, except custom properties (leading '--') because Chromium < 99 treats '--foo: ;' and '--foo:;' differently. Rule: minifies surrounding whitespace; if not dev and the rule is empty, or the rule is unused and not inside a global block, it is removed (minify) or wrapped in a comment with escape_comment_close escaping inner '*/', and recursion stops; for a global block with exactly one ':global' selector, the selector is commented out and only the body is visited (no recursion into selectors). SelectorList: when not inside a global block (or it is a multi-selector list of a global-block Rule) and no ancestor ComplexSelector is unused, it comments out or removes unused selectors, tracking comma boundaries by scanning backwards for ',' and toggling a pruning flag; ends any trailing prune run at the last selector end. It then computes a specificity state: a fresh one for top-level Rule lists — bumped when any ancestor rule has local selectors, else false — or keeps the existing state inside :is()/similar, and passes it via next(). ComplexSelector: for global relative selectors it strips :global via remove_global_pseudo_class; with a parent rule and no args, it prepends '&' when there is no combinator (making 'div { :global.x }' into '&.x'), and when the rule has multiple selectors and this is the last used-adjacent one it updates away the comma up to the next used selector; non-global selectors have mid-compound bare :global stripped. For scoped selectors, it skips standalone :is/:where selectors and selectors containing nesting selectors; otherwise it appends the scoping class (or replaces a lone '*' with it), using the bare class for the first scoped occurrence and :where(class) afterwards once specificity.bumped is set, then sets bumped. The pre-visit bumped flag is restored after context.next(). PseudoClassSelector: recurses only for is/where/has/not; other pseudo-classes are dropped from output.

calls: [is_keyframes_node](r4-compiler-node-model.md#u-8dc3955e3495), [remove_css_prefix](r4-compiler-node-model.md#u-e3a939a3b9f2), [remove_global_pseudo_class](r2-css-transform.md#u-d582bf731db0), [packages/svelte/src/compiler/phases/3-transform/css/index.js:is_in_global_block](r2-css-transform.md#u-104caee60cc4), [is_empty](r2-css-transform.md#u-850d391518fa), [is_used](r2-css-transform.md#u-b3b67c9d0361), [escape_comment_close](r2-css-transform.md#u-8e64579cb2b1)

**Uncertainties.**

- The comma-deletion condition in ComplexSelector (children.length === findIndex(...) - 1) is intricate; its exact intent regarding selector-list position is inferred, not proven.
- Precise recursion semantics of context.next/visit rely on zimmerframe behavior not supplied here.

<a id="u-197b2d45aa0c"></a>
### `render_stylesheet`

`export function render_stylesheet(source, analysis, options)` · [packages/svelte/src/compiler/phases/3-transform/css/index.js:L29-L73][f1]

Renders a component's stylesheet into final CSS text plus a source map.

Builds a MagicString over the source and a State (hash, minify flag from analysis.inject_styles && !dev, scoped selector class, keyframes list, specificity bump flag), walks the CSS AST with the module visitors, then trims source before the stylesheet start and after its end, plus preceding whitespace when minifying. Produces { code, map, hasGlobal }, merges the preprocessor source map via merge_with_preprocessor_map, and in dev with css==='injected' and non-empty code appends a sourceMappingURL comment. Returns the css object.

calls: [merge_with_preprocessor_map](r5-compiler-sourcemaps.md#u-58c664c9f3e7); uses: [css-index-js-visitors](r2-css-transform.md#u-fdc33a016f25)

<a id="u-8e64579cb2b1"></a>
### `escape_comment_close`

`function escape_comment_close(node, code)` · [packages/svelte/src/compiler/phases/3-transform/css/index.js:L458-L479][f1]

Prevents comment-termination leaks when wrapping node text in /* ...

*/: scans the node's original characters tracking escape state and /* */ comment nesting, and inserts a backslash before any '*/' found inside a comment so the wrapping comment is not closed early. Backslash escapes and single '/' are consumed per CSS lexical rules.

**Notes.**

- side_effect: Mutates the MagicString in place by prepending '\\' characters; only correct when called before other edits reorder offsets.

<a id="u-850d391518fa"></a>
### `is_empty`

`function is_empty(rule, is_in_global_block)` · [packages/svelte/src/compiler/phases/3-transform/css/index.js:L424-L446][f1]

Recursively decides whether a Rule produces no CSS.

A global block is empty only when its block has no children. Otherwise any Declaration child makes it non-empty; a Rule child is non-empty only if it is used (or the caller reports a global block) and itself non-empty; an Atrule child makes it non-empty when its block is null or has children.

**Uncertainties.**

- Nested Rule children reuse the caller's is_in_global_block flag rather than a per-child recomputation; whether this matches semantics for deeply nested global blocks is not provable here.

<a id="u-104caee60cc4"></a>
### `packages/svelte/src/compiler/phases/3-transform/css/index.js:is_in_global_block`

`function is_in_global_block(path)` · [packages/svelte/src/compiler/phases/3-transform/css/index.js:L383-L385][f1]

Returns true when any node on the visitor path is a Rule flagged metadata.is_global_block, meaning the current node sits inside a :global rule body.

<a id="u-b3b67c9d0361"></a>
### `is_used`

`function is_used(rule)` · [packages/svelte/src/compiler/phases/3-transform/css/index.js:L449-L451][f1]

Returns true when any complex selector in the rule's prelude is flagged metadata.used.

<a id="u-d582bf731db0"></a>
### `remove_global_pseudo_class`

`function remove_global_pseudo_class(selector, combinator, state)` · [packages/svelte/src/compiler/phases/3-transform/css/index.js:L392-L407][f1]

Deletes ':global' text from the MagicString.

With no args: if the combinator is a descendant combinator (name ' '), it backscans preceding whitespace so 'div :global.x' becomes 'div.x'; it uses update rather than remove so a possibly-inserted closing comment of an unused selector at the end is preserved. With args, it removes ':global(' and the trailing ')', keeping the inner argument.

<a id="u-de1c1b6a47fb"></a>
### `remove_preceding_whitespace`

`function remove_preceding_whitespace(end, state)` · [packages/svelte/src/compiler/phases/3-transform/css/index.js:L414-L418][f1]

Scans backwards in the original source from `end` while preceding characters are whitespace and removes that run from the MagicString; no-op when the previous character is not whitespace.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/css/index.js
