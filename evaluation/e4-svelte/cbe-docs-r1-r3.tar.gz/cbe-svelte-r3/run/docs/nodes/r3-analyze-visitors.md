# Analysis Visitors

**Capability.** Per-node-type analysis: validates class/function/declarations in runes mode, marks fragments dynamic for spreads and class directives, validates component elements, slots, and <svelte:body>, and warns on bidirectional control characters.

Each visitor handles one AST node type during the analyze walk; shared component logic (visit_component) is reused by component-element visitors like SvelteSelf.

**Depends on.**

- [Shared Predicates and Hash](r3-shared-utils.md) · graph-confirmed · 1 edge(s)
- [Shared Analysis Validation](r4-analyze-shared-validation.md) · graph-only · 10 edge(s)
- [AST Manipulation Utilities](r4-compiler-ast-utils.md) · graph-only · 9 edge(s)

**Depended on by.**

- [Analysis Driver](r3-analyze-driver.md) · model-inferred · 0 edge(s)

Parent: [Analysis Phase](r3-analyze-phase.md)

## Units (18)

<a id="u-2a9d6ef13421"></a>
### `packages/svelte/src/compiler/phases/2-analyze/visitors/ClassBody.js:ClassBody`

`export function ClassBody(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/ClassBody.js:L15-L49][f1]

Analyzes class bodies in runes mode to inventory state fields and deconflict private keys.

Outside runes mode it just visits children. It collects existing private identifier names, creates a per-class StateField map registered on analysis.classes, and a field-kind map. The nested handle() resolves a key name and rune; when the rune is a state-creation rune it errors on duplicate state fields (state_field_duplicate) or on clashing methods/assigned fields (duplicate_class_field), and stores a StateField whose key is the PrivateIdentifier or null until filled later. The main pass walks PropertyDefinitions (non-computed, non-static) recording 'prop'/'assigned_prop' kinds with duplicate_class_field on collisions, and MethodDefinitions keyed by static prefix '@'; getter/setter pairs are allowed, anything else colliding errors. Constructor body statements that assign this.<prop> or this['literal'] are fed to handle so runtime state creation counts. Finally each public state field name is sanitized by replacing invalid identifier chars and prefixing '_' while it collides with existing private ids, then assigned a generated private key; visiting continues with state_fields in the state.

calls: [get_rune](r4-compiler-scope.md#u-5204b6ce4f7a), [get_name](r4-compiler-node-model.md#u-99af92983a86), [utils-js-predicates](r3-shared-utils.md#u-7eb274f609ad)

**Uncertainties.**

- The '@' static-prefix encoding and later consumers of fields/state_fields live outside this file.
- Computed PropertyDefinitions are skipped entirely; their state-field interaction is not handled here.
- The constructor scan only accepts Literal computed properties; other computed forms are silently ignored.

<a id="u-12bb8c39d56d"></a>
### `packages/svelte/src/compiler/phases/2-analyze/visitors/ClassDeclaration.js:ClassDeclaration`

`export function ClassDeclaration(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/ClassDeclaration.js:L10-L25][f2]

Analyzes named class declarations in runes mode: validates the class-name binding via validate_identifier_name, and warns perf_avoid_nested_class when the class is nested deeper than allowed — depth 0 in modules, depth 1 in components (the comment notes `new class` is also caught since the warning is depth-based).

Continues with context.next().

calls: [validate_identifier_name](r4-analyze-shared-validation.md#u-e442f835d467)

<a id="u-8d41d0decaea"></a>
### `ClassDirective`

`export function ClassDirective(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/ClassDirective.js:L10-L13][f3]

Marks the enclosing fragment subtree dynamic because a class directive depends on runtime state, then continues traversal with state.expression set to the directive's metadata.expression so descendant expressions track calls and state on it.

calls: [mark_subtree_dynamic](r1-analysis-visitors.md#u-3e6e9a44c2b4)

<a id="u-3976d5e73938"></a>
### `DebugTag`

`export function DebugTag(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/DebugTag.js:L9-L15][f4]

In runes mode, validates the {@debug ...} tag's contents via validate_opening_tag with the '@' prefix; outside runes mode no validation runs.

Then continues traversal.

calls: [validate_opening_tag](r4-analyze-shared-validation.md#u-8a95b3b7e6dc)

<a id="u-9e857900ba69"></a>
### `packages/svelte/src/compiler/phases/2-analyze/visitors/ExportNamedDeclaration.js:ExportNamedDeclaration`

`export function ExportNamedDeclaration(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/ExportNamedDeclaration.js:L10-L70][f5]

Analyzes named exports.

It visits children first so bindings are initialized, then rejects any specifier exported as 'default' with module_illegal_default_export when ast_type is set. For variable declarations: in runes-mode instance code `export let` raises legacy_export_invalid; each declared binding is checked — derived bindings raise derived_invalid_export, and reassigned state/raw_state bindings raise state_invalid_export. In runes mode at instance scope, exported function/class names and const declarator identifiers are recorded in analysis.exports with alias null.

**Uncertainties.**

- Exports of const declarators only record names, not their initializers' exports semantics; alias stays null here, unlike ExportSpecifier.

<a id="u-e5e44148727d"></a>
### `ExportSpecifier`

`export function ExportSpecifier(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/ExportSpecifier.js:L9-L30][f6]

Analyzes a single `export { a as b }` specifier, resolving local and exported names from Identifier names or Literal values.

In instance code under runes mode it records {name: local, alias: exported} in analysis.exports and marks the local binding reassigned. Otherwise (module or non-runes instance) it validates the export with validate_export. No child visiting occurs in the instance branch.

calls: [validate_export](r4-analyze-shared-validation.md#u-1535dc101000)

<a id="u-eab780869b30"></a>
### `FunctionDeclaration`

`export function FunctionDeclaration(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/FunctionDeclaration.js:L10-L16][f7]

In runes mode with a named function, validates the function's identifier name via validate_identifier_name using the scope's binding for that name; otherwise no name check runs.

Delegates scope setup and traversal to visit_function.

calls: [visit_function](r1-analysis-visitors.md#u-98e829315086), [validate_identifier_name](r4-analyze-shared-validation.md#u-e442f835d467)

<a id="u-9bef204c5de7"></a>
### `packages/svelte/src/compiler/phases/2-analyze/visitors/IfBlock.js:IfBlock`

`export function IfBlock(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/IfBlock.js:L10-L27][f8]

Analyzes {#if}/{:else if} blocks.

Validates that consequent and alternate are non-empty; in runes mode validates the opening tag with '#' or, for else-if blocks, ':'. Marks the subtree dynamic, visits the test expression with the block's expression metadata, then visits the consequent and any alternate.

calls: [validate_block_not_empty](r4-analyze-shared-validation.md#u-b877c3a87dc5), [mark_subtree_dynamic](r1-analysis-visitors.md#u-3e6e9a44c2b4)

<a id="u-97612de06878"></a>
### `MemberExpression`

`export function MemberExpression(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/MemberExpression.js:L10-L28][f9]

Analyzes member expressions.

If both object and property are identifiers and the object's binding is a rest_prop whose property name starts with '$$', it throws props_illegal_name. When expression metadata exists it flags has_member_expression and sets has_state if the member access is not pure (per is_pure). If the identifier is not a safe identifier (is_safe_identifier) it sets analysis.needs_context, forcing runtime context creation. Continues with context.next().

calls: [is_pure](r4-analyze-shared-validation.md#u-c8c562a3fb44), [is_safe_identifier](r4-analyze-shared-validation.md#u-63a6d609f552)

<a id="u-317efed2ef7a"></a>
### `packages/svelte/src/compiler/phases/2-analyze/visitors/SlotElement.js:SlotElement`

`export function SlotElement(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/SlotElement.js:L12-L42][f10]

Analyzes <slot> elements.

In runes mode outside custom elements it warns slot_element_deprecated. It marks the subtree dynamic, then inspects attributes: a `name` attribute must be a static text attribute (else slot_element_invalid_name) and must not be 'default' (slot_element_invalid_name_default); attributes other than name, spread, or let: directives throw slot_element_invalid_attribute. The resolved slot name (defaulting to 'default') is recorded in analysis.slot_names. Continues with context.next().

calls: [ast-js-attribute-helpers](r4-compiler-ast-utils.md#u-e05972fa52ab)

**Uncertainties.**

- Duplicate slot names recorded into the same map key: last one wins here; whether a duplicate warning exists elsewhere is not shown.

<a id="u-25d6f65abe59"></a>
### `SpreadAttribute`

`export function SpreadAttribute(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/SpreadAttribute.js:L10-L13][f11]

Marks the enclosing fragment subtree dynamic because spread attributes depend on runtime values, then continues traversal with state.expression set to the attribute's metadata.expression for call/state tracking in descendant expressions.

calls: [mark_subtree_dynamic](r1-analysis-visitors.md#u-3e6e9a44c2b4)

<a id="u-835ee6b14ea5"></a>
### `SpreadElement`

`export function SpreadElement(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/SpreadElement.js:L8-L16][f12]

Analyzes spread elements in expressions: when expression metadata exists it sets has_call and has_state to true, treating any spread as a potential state read and call (comment: `[...x]` equals `[...x.values()]`).

Continues with context.next().

<a id="u-4e2293e9dea9"></a>
### `packages/svelte/src/compiler/phases/2-analyze/visitors/SvelteBody.js:SvelteBody`

`export function SvelteBody(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/SvelteBody.js:L11-L22][f13]

Validates <svelte:body> usage: disallows child elements via disallow_children, then rejects any attribute that is a spread or a non-event attribute by raising svelte_body_illegal_attribute — only event attributes (per is_event_attribute) are permitted.

Traversal continues afterwards.

calls: [disallow_children](r1-analysis-visitors.md#u-43b79d8932ce), [ast-js-attribute-helpers](r4-compiler-ast-utils.md#u-e05972fa52ab)

<a id="u-44e387d55632"></a>
### `packages/svelte/src/compiler/phases/2-analyze/visitors/SvelteSelf.js:SvelteSelf`

`export function SvelteSelf(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/SvelteSelf.js:L12-L36][f14]

Analyzes <svelte:self>.

Valid only when some ancestor on the path is an IfBlock, EachBlock, Component, or SnippetBlock; otherwise svelte_self_invalid_placement is thrown. In runes mode it emits the svelte_self_deprecated warning, substituting 'Self'/'Self.svelte' when the filename is unknown, otherwise using the analysis name and the file's basename from a slash/backslash split. Delegates analysis to visit_component.

calls: [visit_component](r3-analyze-visitors.md#u-3bbf2fbef9a0)

<a id="u-2b8b56c3f427"></a>
### `TemplateElement`

`export function TemplateElement(node)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/TemplateElement.js:L8-L12][f15]

Warns when a template literal's cooked string value contains bidirectional control characters, testing node.value.cooked (falling back to the empty string when null) against the pattern and emitting the warning on match.

<a id="u-4c3d6ff897e3"></a>
### `UpdateExpression`

`export function UpdateExpression(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/UpdateExpression.js:L10-L29][f16]

Analyzes ++/-- update expressions.

The argument is validated with validate_assignment. Inside a reactive statement, when the argument is a MemberExpression the base object identifier is taken via object(); if that yields an Identifier its binding is added to reactive_statement.assignments (no-op otherwise, unlike AssignmentExpression which extracts all identifiers). Expression metadata, if present, gets has_assignment set. Continues with context.next().

calls: [validate_assignment](r4-analyze-shared-validation.md#u-83497fe81c11)

<a id="u-3bbf2fbef9a0"></a>
### `visit_component`

`export function visit_component(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/shared/component.js:L19-L162][f17]

Analyzes a component element: records metadata, resolves which snippets it might render, validates attributes/directives, and visits children grouped by slot.

It copies context.path into metadata.path, initializes metadata.snippets, and computes `resolved`: spread attributes and BindDirective force unresolved; for expression attributes, an Identifier whose binding is a snippet (added to metadata.snippets) or resolves externally keeps resolved true via is_resolved_snippet; Literals keep it true; any other expression forces false. If resolved, direct SnippetBlock children are added. The node and resolved flag are stored in analysis.snippet_renderers for later CSS pruning, then mark_subtree_dynamic makes the enclosing fragments dynamic. Attribute validation: non-Attribute/Spread/Let/On/Bind/AttachTag directives throw component_invalid_directive; On directives allow only 'once' (single) or throw event_handler_invalid_component_modifier. Under runes mode, Attribute values are checked with validate_attribute and sequence expressions are rejected via disallow_unparenthesized_sequences; names are checked with validate_attribute_name and slot="" with validate_slot_attribute(context, attribute, true). Non-`this` Bind directives set analysis.uses_component_bindings. AttachTag expressions also reject unparenthesized sequences. If determine_slot(node) is truthy, let: directives are visited in the current state; otherwise the default scope from metadata.scopes.default is used. Children are partitioned: comments accumulate and are prepended to the next slotted node; each slot's nodes are visited with a state using metadata.scopes[slot_name], parent_element null, and a shared component_slots set. Snippet resolution is only provisional when unresolved: the comment says metadata.snippets is completed after analysis elsewhere.

calls: [validate_attribute](r2-analyze-phase.md#u-001c69caf1f6), [validate_attribute_name](r2-analyze-phase.md#u-c4e14f91c1c8), [validate_slot_attribute](r2-analyze-phase.md#u-be5b4cd34d6a), [mark_subtree_dynamic](r1-analysis-visitors.md#u-3e6e9a44c2b4), [is_resolved_snippet](r1-analysis-visitors.md#u-5fc246db911c), [determine_slot](r2-compiler-foundations.md#u-ead26eb5b43f), [ast-js-attribute-helpers](r4-compiler-ast-utils.md#u-e05972fa52ab)

**Uncertainties.**

- How metadata.scopes and metadata.snippets are completed after analysis (post-processing) is not visible in this file.
- Failure ordering among the attribute-validation errors within a single attribute loop is sequential; which error fires first depends on attribute order in source.

<a id="u-67ff43322877"></a>
### `disallow_unparenthesized_sequences`

`function disallow_unparenthesized_sequences(expression, source)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/shared/component.js:L168-L177][f17]

Rejects sequence expressions used directly as attribute or attach-tag values when they are not wrapped in parentheses.

Only acts on SequenceExpression nodes: it scans source characters backwards from the expression start; finding '(' first means the sequence was parenthesized and is allowed, while finding '{' first (the attribute expression delimiter) throws attribute_invalid_sequence_expression. Reaching index 0 ends the scan silently.

uses: [visit_component](r3-analyze-visitors.md#u-3bbf2fbef9a0)

**Uncertainties.**

- If neither '(' nor '{' is encountered before index 0, the expression is silently accepted; whether that case is reachable depends on parser offsets not visible here.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/ClassBody.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/ClassDeclaration.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/ClassDirective.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/DebugTag.js
[f5]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/ExportNamedDeclaration.js
[f6]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/ExportSpecifier.js
[f7]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/FunctionDeclaration.js
[f8]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/IfBlock.js
[f9]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/MemberExpression.js
[f10]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/SlotElement.js
[f11]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/SpreadAttribute.js
[f12]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/SpreadElement.js
[f13]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/SvelteBody.js
[f14]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/SvelteSelf.js
[f15]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/TemplateElement.js
[f16]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/UpdateExpression.js
[f17]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/shared/component.js
