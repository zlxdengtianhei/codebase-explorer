# Client Control Blocks and CSS

**Capability.** Implements template control structures ({#key}, <svelte:element> with namespace swapping and outro handling) and injects compiled component styles into the document or shadow root.

Use key and element to understand how reactive re-creation of DOM blocks works; append_styles is the client CSS delivery mechanism.

**Depends on.**

- [Client Hydration State](r3-client-hydration.md) · graph-confirmed · 7 edge(s)
- [Client Render Lifecycle](r3-client-render.md) · graph-confirmed · 2 edge(s)
- [Client Template Factories](r3-client-template.md) · graph-confirmed · 1 edge(s)
- [Effect System](r4-runtime-effects.md) · graph-only · 9 edge(s)

Parent: [Client Runtime](r3-client-runtime.md)

## Units (3)

<a id="u-25a3a4f1f827"></a>
### `packages/svelte/src/internal/client/dom/blocks/key.js:key`

`export function key(node, get_key, render_fn)` · [packages/svelte/src/internal/client/dom/blocks/key.js:L18-L39][f1]

Implements the {#key} block: re-renders its content whenever the key expression changes under the selected equality check (not_equal in runes mode, safe_not_equal otherwise).

During hydration it advances past the anchor immediately; after the block is set up, the anchor is repositioned to hydrate_node so subsequent commits insert at the hydrated location. Inside a block effect, when the key changes it creates a new branch running render_fn at a target anchor. If appends are deferred (should_defer_append), the branch renders into an offscreen document fragment preceded by a text anchor and commit is scheduled as a batch callback; otherwise commit runs immediately, pausing the previous effect and splicing the fragment into the DOM.

**Notes.**

- side_effect: commit removes the text anchor from the offscreen fragment before inserting it before the real anchor, so the anchor node is not duplicated into the DOM.

calls: [packages/svelte/src/internal/client/reactivity/effects.js:block](r4-runtime-effects.md#u-75d755e7c63c), [branch](r4-runtime-effects.md#u-cfe4a1f5ddba), [pause_effect](r4-runtime-effects.md#u-340d218bcd6f), [is_runes](r2-component-context.md#u-71aba13a168a), [operations-js-node-lookups](r5-client-dom.md#u-07b45637bc3d), [should_defer_append](r5-client-dom.md#u-46ab51c8fe62), [hydration-js-state](r3-client-hydration.md#u-c504e0cdf2f3)

<a id="u-165ac079f0d2"></a>
### `packages/svelte/src/internal/client/dom/blocks/svelte-element.js:element`

`export function element(node, get_tag, is_svg, render_fn, get_namespace, location)` · [packages/svelte/src/internal/client/dom/blocks/svelte-element.js:L36-L166][f2]

Implements <svelte:element>: a transparent block effect that swaps the DOM element when the tag (or its namespace) changes, with outro/resume handling for transitions.

During hydration it advances past the anchor, adopts the hydrate_node as the element when it is already an element node, and restores hydration state (set_hydrating(true), hydrate node reset to the saved anchor) after the block is created. Namespace resolution: get_namespace() when provided, otherwise NAMESPACE_SVG for is_svg or the literal 'svg' tag, else null. Behavior on change: identical tag returns early (namespace changes alone are ignored by assumption); tag becoming null pauses the effect as an outro, resetting effect and current_tag in the pause callback; same tag as current_tag resumes the paused effect; a different tag destroys the effect immediately and disables intros while rendering the replacement. Element creation uses createElementNS or createElement, attaches dev __svelte_meta location data when location is provided, marks the element as the effect's node range via assign_nodes and active_effect.nodes_end, and renders children through render_fn — during hydration a comment is appended for raw-text elements and the child anchor is the first child, with hydration disabled if no child anchor exists; client-side it appends a text anchor. The element is inserted before the anchor, and the each-item block context is saved and restored around the update so animate: directives bind to the correct each block.

**Notes.**

- condition: Void elements have an undefined child_anchor; render_fn is still called for actions, and hydrated children would be silently discarded.
- side_effect: Sets active_effect.nodes_end to the element after render_fn so child effects cannot override it.
- field: DEV-only __svelte_meta records parent dev_stack plus file/line/column used by hydration mismatch warnings.

calls: [packages/svelte/src/internal/client/reactivity/effects.js:block](r4-runtime-effects.md#u-75d755e7c63c), [branch](r4-runtime-effects.md#u-cfe4a1f5ddba), [pause_effect](r4-runtime-effects.md#u-340d218bcd6f), [resume_effect](r4-runtime-effects.md#u-199bf40112ce), [destroy_effect](r4-runtime-effects.md#u-214ad59ce57a), [set_current_each_item][f3], [set_should_intro](r3-client-render.md#u-cbadffbbf083), [assign_nodes](r3-client-template.md#u-081194bea535), [utils-js-predicates](r3-shared-utils.md#u-7eb274f609ad)

**Uncertainties.**

- The early return when next_tag === tag means a namespace-only change is never applied; the code itself comments this as an assumption.

<a id="u-25ab046937f2"></a>
### `append_styles`

`export function append_styles(anchor, css)` · [packages/svelte/src/internal/client/dom/css.js:L9-L32][f4]

Injects a component's compiled CSS into the document or shadow root containing the anchor.

Wraps the work in an effect so it runs after the anchor is connected, letting getRootNode() resolve correctly. If the root has a host it targets that ShadowRoot, otherwise the root document's head. It queries for an existing style with the CSS hash id and skips injection when found; otherwise it creates a <style> with the hash as id and the code as content, appends it, and in DEV registers it.

imports: [packages/svelte/src/internal/client/dom/css.js:css.js module code (L1–L8)][f4]

**Uncertainties.**

- The timing of the wrapped effect (when it runs relative to insertion) depends on the effect implementation, which is outside this file.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/blocks/key.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/blocks/svelte-element.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/blocks/each.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/css.js
