# AST Manipulation Utilities

**Capability.** Generic estree manipulation shared by all phases: identifier and path extraction from patterns and expressions, destructuring fallback building, chain/pattern unwrapping, assignment-value reconstruction, and attribute-node predicates.

These are stateless helpers with no Svelte-specific semantics beyond node shapes. extract_paths/build_fallback power state destructuring transforms; extract_identifiers and unwrap_pattern power scope building and validation.

**Depended on by.**

- [Shared Analysis Validation](r4-analyze-shared-validation.md) · graph-confirmed · 2 edge(s)
- [Semantic Analysis Visitors](r4-analyze-visitors.md) · graph-confirmed · 12 edge(s)
- [Scope and Binding Model](r4-compiler-scope.md) · graph-confirmed · 11 edge(s)
- [Client Code Transformation](r4-transform-client.md) · graph-confirmed · 7 edge(s)
- [Server \(SSR\) Code Transformation](r4-transform-server.md) · graph-confirmed · 4 edge(s)
- [AST Analysis Visitors](r5-analyze-visitors.md) · graph-only · 12 edge(s)
- [Client Codegen Visitors](r5-transform-client.md) · graph-only · 11 edge(s)
- [Analysis Visitors](r3-analyze-visitors.md) · graph-only · 9 edge(s)

Parent: [Compiler Pipeline](r4-compiler.md)

## Units (14)

<a id="u-9013e97c276b"></a>
### `_extract_paths`

`function _extract_paths(paths, inserts, param, expression, update_expression, has_def…` · [packages/svelte/src/compiler/utils/ast.js:L269-L415][f1]

Recursively walks a destructuring pattern against an initial value expression, appending path records and intermediate inserts.

Identifier/MemberExpression records a path carrying the current expression and update_expression. ObjectPattern: a RestElement property builds `$.exclude_from_object(expression, [literal keys])` — non-computed Identifier keys and Literal keys become literals, other keys become a `String(key)` call — and either records the rest identifier directly or recurses; normal properties recurse with member expression `expression.key`, computed unless the key is a non-computed Identifier. ArrayPattern pushes an insert binding `#` to `$.to_array(expression, length-literal-or-undefined)` (argument omitted when the last element is a RestElement, so iterables are fully consumed), then per element: RestElement becomes `#.slice(i)` (identifier recorded directly or recursed), others become computed member `#[i]` paths. AssignmentPattern builds a fallback via `build_fallback(expression, right)`; an Identifier left side records a path with `has_default_value: true` and the fallback expression, otherwise it recurses into the left keeping the original update_expression.

calls: [build_fallback](r4-compiler-ast-utils.md#u-287d48fe390a)

**Uncertainties.**

- Runtime behavior of the generated `$.exclude_from_object`, `$.to_array`, and `$.slice` calls is defined elsewhere and not visible here

<a id="u-634ffef5ceee"></a>
### `build_assignment_value`

`export function build_assignment_value(operator, left, right)` · [packages/svelte/src/compiler/utils/ast.js:L604-L611][f1]

Converts a compound assignment into its equivalent right-hand expression.

For `=` the right side is returned as-is. For `||=`, `&&=`, `??=` it builds a logical expression with the operator minus the trailing `=` applied to left and right. For all other operators (arithmetic/bitwise compounds) it builds a binary expression the same way, e.g. `x += 1` becomes `x = x + 1`.

<a id="u-287d48fe390a"></a>
### `build_fallback`

`export function build_fallback(expression, fallback)` · [packages/svelte/src/compiler/utils/ast.js:L585-L597][f1]

Builds the runtime fallback call for a destructuring default, choosing among three shapes.

If the fallback is a simple expression it emits `$.fallback(expression, fallback)` directly. If the fallback is an AwaitExpression whose argument is simple, it emits an awaited `$.fallback(expression, argument)`. Otherwise the fallback is wrapped in a thunk: `$.fallback(expression, thunk, true)` — awaited first via `b.await` when `is_expression_async(fallback)` is true, plain when not — so evaluation is deferred and async defaults are supported.

calls: [is_simple_expression](r4-compiler-ast-utils.md#u-410082960042), [is_expression_async](r4-compiler-ast-utils.md#u-88399029ef9f)

<a id="u-4fc74297abd5"></a>
### `extract_all_identifiers_from_expression`

`export function extract_all_identifiers_from_expression(expr)` · [packages/svelte/src/compiler/utils/ast.js:L146-L156][f1]

Collects every free identifier of an expression plus a dotted string keypath describing its member-access shape, returning `[keypath, ids]`.

It walks the expression with zimmerframe. The Identifier visitor pushes an identifier into `nodes` only when it is not a non-computed MemberExpression property (so `a.b`'s `b` is skipped); for the keypath it appends `[name]` when the identifier is a computed member property and the bare name otherwise. The Literal visitor appends the value (strings quoted, otherwise `String(value)`) to the keypath, bracketed when it is a computed member property. The ThisExpression visitor appends 'this' and calls `next()` to continue into the member chain. The keypath segments are joined with '.'.

**Uncertainties.**

- An Identifier that is a computed member property is both pushed to nodes and bracketed in the keypath; whether that double-counting is intended is not provable from this file

<a id="u-90eb95affc00"></a>
### `extract_identifiers`

`export function extract_identifiers(pattern)` · [packages/svelte/src/compiler/utils/ast.js:L136-L138][f1]

Returns only the Identifier leaves of a pattern by running `unwrap_pattern` on a fresh array and filtering out MemberExpression nodes.

calls: [unwrap_pattern](r4-compiler-ast-utils.md#u-73018823c866)

<a id="u-f5e86bd3328c"></a>
### `extract_identifiers_from_destructuring`

`export function extract_identifiers_from_destructuring(node, nodes = [])` · [packages/svelte/src/compiler/utils/ast.js:L193-L220][f1]

Collects leaf identifiers from a destructuring-shaped node, mutating an optional accumulator and returning it.

Identifier nodes are pushed. ObjectExpression recurses into each Property's value or, for non-Property entries (RestElement), its argument. ArrayExpression recurses into each non-null element, skipping holes. Unrecognized node types contribute nothing. The source comments that this implementation is intentionally incomplete but sufficient for its callers.

**Uncertainties.**

- The source itself labels the traversal incomplete; exact gaps depend on input shapes not shown

<a id="u-34f2fcb20c62"></a>
### `extract_paths`

`export function extract_paths(param, initial)` · [packages/svelte/src/compiler/utils/ast.js:L243-L258][f1]

Decomposes a destructuring declaration or assignment into path descriptors plus intermediate declarations.

Returns `{ inserts, paths }`: `inserts` are `{ id, value }` pairs the consumer must emit (renaming the placeholder `#` identifier), and `paths` are DestructuredAssignment records. All tree recursion is delegated to the private `_extract_paths`, which fills both arrays.

calls: [_extract_paths](r4-compiler-ast-utils.md#u-9013e97c276b)

<a id="u-427249cf438e"></a>
### `get_parent`

`export function get_parent(path, at)` · [packages/svelte/src/compiler/utils/ast.js:L425-L432][f1]

Returns `path.at(at)` as a typed node, skipping TypeScript wrapper nodes: if the node at the index is a TSNonNullExpression or TSAsExpression, it returns the adjacent entry (`at - 1` for negative indices, otherwise `at + 1`).

It assumes `path.at(at)` is never undefined; no guard exists.

**Uncertainties.**

- No undefined check on `path.at(at)`; out-of-range indexes would throw on the `.type` access

<a id="u-88399029ef9f"></a>
### `is_expression_async`

`export function is_expression_async(expression)` · [packages/svelte/src/compiler/utils/ast.js:L484-L578][f1]

Recursively determines whether an expression or pattern contains an await.

AwaitExpression is trivially true. Composite nodes recurse over their children with type-specific guards: ArrayPattern over non-null elements; ArrayExpression treating SpreadElement by its argument and skipping holes; AssignmentPattern/AssignmentExpression/BinaryExpression/LogicalExpression skip a PrivateIdentifier left side; CallExpression/NewExpression skip a Super callee and recurse into arguments (spreads by their argument); ChainExpression unwraps; ConditionalExpression over all three branches; ImportExpression over its source; MemberExpression skips Super objects and PrivateIdentifier properties; Object patterns/expressions recurse into spreads and Property key/value (PrivateIdentifier keys skipped); RestElement over its argument; SequenceExpression and TemplateLiteral over their expressions; TaggedTemplateExpression over tag and quasi; Unary/Update over the argument; YieldExpression over its argument only when present. All other node types return false.

<a id="u-410082960042"></a>
### `is_simple_expression`

`export function is_simple_expression(node)` · [packages/svelte/src/compiler/utils/ast.js:L442-L469][f1]

Reports whether an expression is side-effect-free to evaluate eagerly: literals, identifiers, arrow and function expressions are simple.

ConditionalExpressions are simple when test, consequent and alternate are all simple. Binary and Logical expressions are simple when the left side is not a PrivateIdentifier and both sides are simple. Everything else returns false. Used to decide whether reading a value could trigger signal side effects.

<a id="u-2f2548aeaec6"></a>
### `object`

`export function object(expression)` · [packages/svelte/src/compiler/utils/ast.js:L11-L21][f1]

Finds the left-most identifier of a member-expression chain.

It loops while the node is a MemberExpression, replacing it with its `object`; if the resulting node is not an Identifier it returns null, otherwise the Identifier.

<a id="u-aa95700b7c80"></a>
### `unwrap_optional`

`export function unwrap_optional(node)` · [packages/svelte/src/compiler/utils/ast.js:L476-L478][f1]

Unwraps an optional-chain wrapper: if the node is a ChainExpression its inner expression is returned, otherwise the node itself.

<a id="u-73018823c866"></a>
### `unwrap_pattern`

`export function unwrap_pattern(pattern, nodes = [])` · [packages/svelte/src/compiler/utils/ast.js:L89-L129][f1]

Flattens a destructuring pattern into a list of its leaf Identifier and MemberExpression nodes, appending to an optional accumulator array and returning it.

Identifier and MemberExpression leaves are pushed directly. ObjectPattern recurses into `prop.value` for regular properties and `prop.argument` for RestElement. ArrayPattern recurses into each non-null element, skipping holes. RestElement recurses into its argument; AssignmentPattern into its left side. Member expressions are included because they are legal in assignment (not binding) patterns, per the source comment.

<a id="u-e05972fa52ab"></a>
### `ast-js-attribute-helpers`

`export function is_text_attribute(attribute)` · [packages/svelte/src/compiler/utils/ast.js:L28-L34][f1]

Predicates and accessors over Svelte template Attribute nodes.

`is_text_attribute` is true only when `attribute.value` is a single-element array whose sole node is a Text node. `is_expression_attribute` is true when `value` is a bare ExpressionTag (`value !== true && !Array.isArray`) or a single-element array containing an ExpressionTag; the bare form is a Svelte 5 compatibility case marked TODO. `get_attribute_expression` unwraps the array form and returns the tag's expression; it assumes the caller already established the single-expression shape. `get_attribute_chunks` normalizes a value into an array: arrays pass through, the boolean shorthand (`value === true`) yields an empty array, anything else becomes a one-element array. `is_event_attribute` requires `is_expression_attribute` plus a name starting with `on`.

calls: [ast-js-attribute-helpers](r4-compiler-ast-utils.md#u-e05972fa52ab)

**Uncertainties.**

- get_attribute_expression has no runtime guard for attribute shapes outside its type precondition

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/utils/ast.js
