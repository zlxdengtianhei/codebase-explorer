# Client Render Lifecycle

**Capability.** Public mount/hydrate/unmount lifecycle for compiled components, plus the small text-update and intro-flag primitives used by generated code.

Enter the runtime through grp:render.js-mount; set_text and set_should_intro are the low-level primitives it and block effects rely on.

**Depends on.**

- [Client Hydration State](r3-client-hydration.md) · graph-confirmed · 7 edge(s) · mount and hydrate drive their DOM work through the module-level hydration cursor helpers.
- [Client Template Factories](r3-client-template.md) · graph-confirmed · 1 edge(s)

**Depended on by.**

- [Client Control Blocks and CSS](r3-client-blocks.md) · graph-confirmed · 2 edge(s)

Parent: [Client Runtime](r3-client-runtime.md)

## Units (3)

<a id="u-751f047b7883"></a>
### `render.js-mount`

`export function mount(component, options)` · [packages/svelte/src/internal/client/render.js:L73-L75][f1]

Implements the public mount/hydrate/unmount lifecycle.

mount delegates to _mount. hydrate first enables DOM operations, defaults intro to false, then scans the target's children for the HYDRATION_START comment anchor — if none is found it throws HYDRATION_ERROR; otherwise it switches to hydrating mode, mounts the component at that anchor, verifies hydration ended at the HYDRATION_END comment (else warns hydration_mismatch and throws HYDRATION_ERROR), and returns the instance. On any error: Svelte's own errors (messages containing a https://svelte.dev/e/ line) are rethrown; HYDRATION_ERROR is silently passed; other errors are warned. If options.recover === false, hydration_failed throws; otherwise the target is cleared and the component is client-mounted from scratch via mount. A finally block restores the previous hydrating state and hydrate node and calls reset_head_anchor. _mount initializes DOM operations, registers global event handling: each mount adds container listeners for all registered events plus shared document listeners refcounted in document_listeners (document-level listener added only on first registration); the handle is stored in root_event_handles so later event registrations extend coverage. Inside a component_root effect branch it pushes optional context, attaches $$events to props, and calls the component function synchronously (with should_intro set from the intro option during this window, then reset to true), recording nodes_end during hydration; its teardown removes the container listener, decrements or removes document listeners, unregisters the event handle, and removes the anchor text node if _mount created it. _mount stores the teardown keyed by the component instance in mounted_components. unmount looks up that teardown: if found it deletes the entry and invokes it (returning its Promise, resolving after outros when outro is true); if absent in DEV it warns lifecycle_double_unmount and resolves immediately.

**Notes.**

- failure: hydrate's recovery path re-runs init_operations because the error may have occurred before initialization.
- side_effect: Document listeners are reference-counted across mounts so they persist while any mounted component needs them.

calls: [component_root](r4-runtime-effects.md#u-42e380f9794b), [push](r2-component-context.md#u-9761c5d7c2ee), [utils-js-predicates](r3-shared-utils.md#u-7eb274f609ad)

**Uncertainties.**

- The Promise semantics of unmount depend on the teardown returned by component_root, whose implementation is not in this batch.

<a id="u-cbadffbbf083"></a>
### `set_should_intro`

`export function set_should_intro(value)` · [packages/svelte/src/internal/client/render.js:L43-L45][f1]

Sets the module-level should_intro flag that controls whether block effects run intro transitions.

<a id="u-86b704dae3fa"></a>
### `set_text`

`export function set_text(text, value)` · [packages/svelte/src/internal/client/render.js:L52-L61][f1]

Updates a text node's content only when it changed: values are coerced to string first (objects via string concatenation so reactive proxies are touched, null/undefined become ''), and the previous value is cached on the node's __t property; the DOM is written only on a mismatch.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/render.js
