# Svelte Compiler

**Capability.** Owns translating .svelte source into client and server output: parsing, analysis/validation, and transformation, plus the shared foundations (errors, diagnostics, AST types, options validation) every phase consumes.

Enter here to understand how templates become executable code. Phases run roughly parse → analyze → transform, with CSS handled as its own sub-pipeline. Type declarations describing the AST and compile options anchor the phase implementations.

**Children.**

- [Compiler Foundations](r2-compiler-foundations.md) `r2-compiler-foundations` · 24 unit(s)
- [CSS Pipeline](r2-css-pipeline.md) `r2-css-pipeline` · 0 unit(s)
- [Template Analysis](r2-analyze-phase.md) `r2-analyze-phase` · 17 unit(s)
- [Client Transform](r2-client-transform.md) `r2-client-transform` · 32 unit(s)
- [Server Transform](r2-server-transform.md) `r2-server-transform` · 11 unit(s)

Parent: [Svelte Codebase](r2-svelte-codebase.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
