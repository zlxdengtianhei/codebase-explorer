# Server Store Helpers

**Capability.** Server-side store contract: cached subscription reads, value writes, template-value mutations, post/pre increment helpers, and end-of-render unsubscription of all cached stores.

Compiled server code reads stores via store_get and writes via store_set/mutate; update_store* implement compiled ++/--. unsubscribe_stores closes subscriptions at render end.

Parent: [Server Runtime](r3-server-runtime.md)

## Units (12)

<a id="u-5975ccb1491b"></a>
### `packages/svelte/src/internal/server/index.js:store_get`

`export function store_get(store_values, store_name, store)` · [packages/svelte/src/internal/server/index.js:L274-L293][f1]

Subscribe a store for template reads and return its current value, caching per store name.

**Notes.**

- failure: In DEV, validate_store is called with the name minus the leading $, throwing for invalid stores.
- condition: If the cached entry exists and its [0] is the same store, returns the cached value at [2] without resubscribing.
- side_effect: If the store was switched, the old subscription's unsubscriber at [1] is invoked; a fresh entry [store, unsub, value] is created via subscribe_to_store, which keeps [2] updated on emission.

calls: [subscribe_to_store](r1-store-compat.md#u-863f9153e183), [validate_store](r5-runtime-shared.md#u-f09c2e0aa53c)

<a id="u-809be478aa47"></a>
### `packages/svelte/src/internal/server/index.js:store_set`

`export function store_set(store, value)` · [packages/svelte/src/internal/server/index.js:L302-L305][f1]

Set a store's value and return it.

<a id="u-7d1dd4a2a3e6"></a>
### `packages/svelte/src/internal/server/index.js:store_mutate`

`export function store_mutate(store_values, store_name, store, expression)` · [packages/svelte/src/internal/server/index.js:L315-L318][f1]

Assign a store its current template value (read-then-set) and return the mutation expression result.

**Notes.**

- contract: store_set(store, store_get(...)) forces a re-set of the current value so mutations like store.x++ propagate; the expression value is returned for emission.

calls: [packages/svelte/src/internal/server/index.js:store_get](r3-server-stores.md#u-5975ccb1491b), [packages/svelte/src/internal/server/index.js:store_set](r3-server-stores.md#u-809be478aa47)

<a id="u-4157e614850a"></a>
### `packages/svelte/src/internal/server/index.js:update_store`

`export function update_store(store_values, store_name, store, d = 1)` · [packages/svelte/src/internal/server/index.js:L327-L331][f1]

Post-increment/decrement helper: set store to value + d, return the pre-update value.

<a id="u-7a134f57bf18"></a>
### `update_store_pre`

`export function update_store_pre(store_values, store_name, store, d = 1)` · [packages/svelte/src/internal/server/index.js:L340-L344][f1]

Pre-increment/decrement helper: set store to value + d and return the new value.

<a id="u-60498de8c911"></a>
### `unsubscribe_stores`

`export function unsubscribe_stores(store_values)` · [packages/svelte/src/internal/server/index.js:L347-L351][f1]

Unsubscribe every cached store entry at the end of a render.

**Notes.**

- side_effect: Calls entry[1]\() (the unsubscriber) for each key in store_values; entries without a stored unsubscriber would throw when invoked.

<a id="u-5ea0e143bb0a"></a>
### `index.js module code (L265–L273)`

`module_region` · [packages/svelte/src/internal/server/index.js:L265-L273][f1]

Non-behavioral gap between attr_style and store_get.

<a id="u-fc0b728a6490"></a>
### `index.js module code (L293–L301)`

`module_region` · [packages/svelte/src/internal/server/index.js:L293-L301][f1]

Non-behavioral gap between store_get and store_set.

<a id="u-d579a3ae411d"></a>
### `index.js module code (L305–L314)`

`module_region` · [packages/svelte/src/internal/server/index.js:L305-L314][f1]

Non-behavioral gap between store_set and store_mutate.

<a id="u-be4d4f75121c"></a>
### `index.js module code (L318–L326)`

`module_region` · [packages/svelte/src/internal/server/index.js:L318-L326][f1]

Non-behavioral gap between store_mutate and update_store.

<a id="u-a75387c493e7"></a>
### `index.js module code (L331–L339)`

`module_region` · [packages/svelte/src/internal/server/index.js:L331-L339][f1]

Non-behavioral gap between update_store and update_store_pre.

<a id="u-f7d1a4b5ae2b"></a>
### `index.js module code (L344–L346)`

`module_region` · [packages/svelte/src/internal/server/index.js:L344-L346][f1]

Non-behavioral gap between update_store_pre and unsubscribe_stores.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/server/index.js
