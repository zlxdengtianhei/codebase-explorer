# Element Bindings

**Capability.** Two-way bindings for DOM elements: input value/checked/files/group bindings with number coercion and binding-group value collection, and `bind:this` with its proxy-aware still-bound check.

Consult when a binding propagates values in the wrong direction or timing; bind_group and bind_this schedule work through the task queues, and bind_value uses the shared coercion helpers.

**Depends on.**

- [Task Scheduling](r1-task-scheduling.md) · graph-confirmed · 3 edge(s)

Parent: [Client Runtime](r1-client-runtime.md)

## Units (8)

<a id="u-01d2720075cb"></a>
### `bind_value`

`export function bind_value(input, get, set = get)` · [packages/svelte/src/internal/client/dom/elements/bindings/input.js:L19-L113][f1]

Two-way binds an input's value.

The 'input' handler reads input.value (or defaultValue on form reset), coerces number/range inputs via to_number, calls set, records the current batch in a local WeakSet, then awaits tick(); if get() then differs (accessor validation/coercion), it rewrites input.value (null as '') and restores the selection clamped to the new length. At setup, if hydrating with defaultValue diverged from input.value, or get() is nullish while input.value is set, the DOM value is pushed into state. A render effect pushes state to the DOM with these skip conditions: in DEV a checkbox binding calls e.bind_invalid_checkbox_value; if the input is focused and the batch of the user edit (previous_batch ?? current_batch) is recorded, the DOM is not overwritten so deferred async updates never clobber focus; numberlike inputs equal after coercion (0 vs 00) are skipped; a date input whose state and DOM value are both empty is skipped to preserve a partially typed date; otherwise input.value is assigned only when different, so minlength validation still works.

**Notes.**

- side_effect: The WeakSet of batches is local to each bind_value call, not shared state.
- failure: DEV-only checkbox bindings raise bind_invalid_checkbox_value from both the event handler and the render effect.

calls: [listen_to_event_and_reset_event](r2-dom-elements.md#u-adb7ad8d3643), [runtime-js-state-and-helpers](r2-reactivity-core.md#u-6cd2387802ec), [input.js-number-coercion-helpers](r1-element-bindings.md#u-f90fa851acf4)

**Uncertainties.**

- The comment 'in non-async mode, render effects run before previous_batch is set' describes flush ordering outside this file; the exact batch lifecycle is not provable here.

<a id="u-d6e0e6bda8ca"></a>
### `bind_checked`

`export function bind_checked(input, get, set = get)` · [packages/svelte/src/internal/client/dom/elements/bindings/input.js:L220-L240][f1]

Two-way binds a checkbox's checked state.

The change listener sets state from input.checked, or from defaultChecked when the form was reset. At setup, if hydrating with defaultChecked diverged from checked, or get() is nullish (meaning defaultChecked implies checked), input.checked is pushed into state. A render effect writes Boolean(get()) to input.checked.

calls: [listen_to_event_and_reset_event](r2-dom-elements.md#u-adb7ad8d3643), [runtime-js-state-and-helpers](r2-reactivity-core.md#u-6cd2387802ec)

<a id="u-00ad8cbfeb28"></a>
### `bind_files`

`export function bind_files(input, get, set = get)` · [packages/svelte/src/internal/client/dom/elements/bindings/input.js:L287-L304][f1]

Two-way binds input.files.

The change listener sets state from input.files; at setup, if hydrating and input.files is non-null, the DOM files are pushed into state. A render effect assigns get() to input.files, the writable direction of this property.

calls: [listen_to_event_and_reset_event](r2-dom-elements.md#u-adb7ad8d3643)

**Uncertainties.**

- Whether assigning input.files takes effect in all browsers is not established by this source.

<a id="u-dbd1fc23c7b5"></a>
### `bind_group`

`export function bind_group(inputs, group_index, input, get, set = get)` · [packages/svelte/src/internal/client/dom/elements/bindings/input.js:L126-L212][f1]

Two-way binds a radio/checkbox group sharing an inputs array.

The input is pushed into the nested array reached by indexing with group_index (creating sub-arrays via ??=). The change listener reads input.__value; for checkboxes it aggregates the whole group via get_binding_group_value before set, otherwise sets __value directly; the form-reset handler sets [] for checkboxes, null otherwise. A render effect pushes state to the DOM: if hydrating and input.defaultChecked !== input.checked, it sets hydration_mismatch and defers; for checkboxes it checks membership of __value in value (coerced to [] when falsy), for radios it compares with is(). Teardown splices the input out of its group. The first time a group is bound, a microtask sorts it by compareDocumentPosition to keep DOM order; a further microtask, only on hydration mismatch, derives the value from checked inputs (checkbox aggregate, or the first checked input's __value) and calls set.

calls: [listen_to_event_and_reset_event](r2-dom-elements.md#u-adb7ad8d3643), [get_binding_group_value](r1-element-bindings.md#u-1bfc194f94a2), [is](r4-runtime-signals.md#u-dcae92a399e9), [task-js-queues](r1-task-scheduling.md#u-08b6b6ebaf85); uses: [input.js module code (L113–L125)][f1]

**Uncertainties.**

- In the hydration-mismatch checkbox branch, `value` is passed uninitialized to get_binding_group_value; the deletion path for an unchecked input is not provable from this source.

<a id="u-1bfc194f94a2"></a>
### `get_binding_group_value`

`function get_binding_group_value(group, __value, checked)` · [packages/svelte/src/internal/client/dom/elements/bindings/input.js:L249-L265][f1]

Collects the __value of every checked input in the group into a Set and returns it as an array.

If the triggering input was just unchecked, its __value is deleted before conversion, so the result reflects the post-toggle selection.

<a id="u-f90fa851acf4"></a>
### `input.js-number-coercion-helpers`

`function is_numberlike_input(input)` · [packages/svelte/src/internal/client/dom/elements/bindings/input.js:L270-L273][f1]

Helpers shared by bind_value.

is_numberlike_input returns true only for input types 'number' and 'range'. to_number maps '' to null and otherwise applies unary plus, so non-numeric text becomes NaN which propagates through set.

<a id="u-7b1a63fed5a0"></a>
### `bind_this`

`export function bind_this(element_or_component = {}, update, get_value, get_parts)` · [packages/svelte/src/internal/client/dom/elements/bindings/this.js:L25-L61][f2]

Implements `bind:this` for elements or component instances; returns element_or_component unchanged.

An outer effect hosts a render_effect that tracks only the each-block parts (get_parts) to avoid reruns on value changes; untracked, if get_value(...parts) no longer equals element_or_component, it calls update(element_or_component, ...parts), and on a rerun (each context moved) it also nulls the previous position with update(null, ...old_parts) — but only if that slot still points at this binding per is_bound_this. The outer effect's teardown queues a microtask (effects cannot be created during teardown) that nulls the current slot when it still holds this binding.

calls: [is_bound_this](r1-element-bindings.md#u-46b14567d27a), [task-js-queues](r1-task-scheduling.md#u-08b6b6ebaf85), [runtime-js-state-and-helpers](r2-reactivity-core.md#u-6cd2387802ec)

<a id="u-46b14567d27a"></a>
### `is_bound_this`

`function is_bound_this(bound_value, element_or_component)` · [packages/svelte/src/internal/client/dom/elements/bindings/this.js:L11-L15][f2]

Returns true when the currently bound value is still the element/component itself, either by identity or because the value is a proxy whose STATE_SYMBOL target matches; used to decide whether a this-binding slot should be nulled out.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/elements/bindings/input.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/elements/bindings/this.js
