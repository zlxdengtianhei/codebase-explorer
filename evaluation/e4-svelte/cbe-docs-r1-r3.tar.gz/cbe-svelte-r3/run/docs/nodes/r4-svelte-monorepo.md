# Svelte Compiler and Runtime

**Capability.** Owns the Svelte toolchain end to end: compile-time parsing, analysis, and code transformation, the client runtime executing compiled output, legacy public APIs, shared source utilities, and supporting build, benchmark, and type-declaration artifacts.

Start here to orient across compiler and runtime. Compiler subtrees cover pipeline phases; runtime subtrees cover reactivity and DOM execution; build, benchmark, and declaration subtrees are supporting infrastructure.

**Children.**

- [Benchmarking Harness](r4-benchmarking.md) `r4-benchmarking` · 9 unit(s)
- [Build Scripts and Generated Sources](r4-build-codegen.md) `r4-build-codegen` · 7 unit(s)
- [Shared Source Utilities](r4-shared-source-utilities.md) `r4-shared-source-utilities` · 4 unit(s)
- [Compiler Pipeline](r4-compiler.md) `r4-compiler` · 0 unit(s)
- [Effect System](r4-runtime-effects.md) `r4-runtime-effects` · 33 unit(s)
- [Signals, Deriveds, and Proxies](r4-runtime-signals.md) `r4-runtime-signals` · 13 unit(s)
- [Runtime DOM Blocks](r4-runtime-dom-blocks.md) `r4-runtime-dom-blocks` · 7 unit(s)
- [Element Bindings and Behaviors](r4-runtime-element-bindings.md) `r4-runtime-element-bindings` · 16 unit(s)
- [Legacy Public API](r4-runtime-legacy.md) `r4-runtime-legacy` · 9 unit(s)
- [Runtime Dev-Mode Instrumentation](r4-runtime-dev.md) `r4-runtime-dev` · 13 unit(s)

**Depended on by.**

- [Benchmarking Harness](r4-benchmarking.md) · containment · → 0 / ← 0 edge(s) (ancestor direct units and descendant subtree; → follows ` r4-benchmarking ` → ` r4-svelte-monorepo `)

Parent: [Client Runtime](client-runtime.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
