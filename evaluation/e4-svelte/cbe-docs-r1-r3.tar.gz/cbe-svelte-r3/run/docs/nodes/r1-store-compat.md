# Store Contract

**Capability.** The public store type contracts (readable/writable/subscriber/unsubscriber shapes) and the tolerant subscribe_to_store helper used to subscribe callbacks to arbitrary store-like objects.

Use when interoperating with stores or validating store types; subscribe_to_store tolerates missing stores and non-Svelte subscriptions.

Parent: [Public & Authoring APIs](r1-public-api.md)

## Units (2)

<a id="u-e073ffe38ead"></a>
### `public-d-ts-store`

`export type Subscriber<T> = (value: T) => void;` · [packages/svelte/src/store/public.d.ts:L2-L2][f1]

Public store type contracts.

`Subscriber<T>` receives value updates, `Unsubscriber` is a teardown thunk, `Updater<T>` maps the current value to the next, and `StartStopNotifier<T>` is the callback run when the first subscriber subscribes — receiving `set` and `update` handles and optionally returning a cleanup run when the last subscriber leaves. `Readable<T>` requires `subscribe(this: void, run, invalidate?)` returning an `Unsubscriber`; `Writable<T>` extends it with `set(value)` and `update(updater)`, both `this: void` so implementations cannot capture an instance `this`. The file re-exports everything from `./index-client.js`.

imports: [./index-client.js](../../catalog.json)

<a id="u-863f9153e183"></a>
### `subscribe_to_store`

`export function subscribe_to_store(store, run, invalidate)` · [packages/svelte/src/store/utils.js:L12-L36][f2]

Subscribes a callback to a store, tolerating missing stores and non-Svelte subscriptions.

If store is null or undefined, it calls run(undefined), calls invalidate(undefined) when provided, and returns noop as the unsubscribe function. Otherwise it subscribes inside untrack — silencing validation errors because a StartStopNotifier could mutate state — passing the optional invalidate as the store's private second argument. If the returned handle has an unsubscribe method (RxJS style) it wraps that call, else it returns the handle directly as the unsubscriber.

uses: [store_get](r3-client-stores.md#u-6bf992bdbb59)

**Uncertainties.**

- Exact failure behavior when store.subscribe throws or returns something unexpected is not visible here.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/store/public.d.ts
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/store/utils.js
