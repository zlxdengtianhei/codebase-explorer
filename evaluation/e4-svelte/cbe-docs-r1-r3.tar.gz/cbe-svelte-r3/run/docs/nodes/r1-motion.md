# Motion (Spring & Tween)

**Capability.** Animates values over time: the Tween class whose current/target are signals, the get_interpolator builder (Date-aware via is_date), the deprecated tweened store factory, and the motion barrel re-exporting spring/tweened and eagerly creating the prefers-reduced-motion media query.

Use when tween/spring animation timing or value interpolation is wrong. Tween's setter drives current toward target; get_interpolator chooses numeric/array/object/Date interpolation.

**Depended on by.**

- [Reactive Wrapper Classes](r1-reactive-collections.md) · model-inferred · 0 edge(s)

Parent: [Public & Authoring APIs](r1-public-api.md)

## Units (5)

<a id="u-fe5771212e14"></a>
### `index.js module code (L1–L32)`

`module_region` · [packages/svelte/src/motion/index.js:L1-L32][f1]

Re-exports everything from spring.js and tweened.js and eagerly creates prefersReducedMotion, a reactive MediaQuery for '(prefers-reduced-motion: reduce)'.

Consumers read .current to learn whether the user prefers reduced motion; reactive updates come from the MediaQuery contract in svelte/reactivity, which is not part of this file.

imports: [spring](r5-client-motion.md#u-65703c942e2e), [tweened](r1-motion.md#u-a3154029292c)

**Uncertainties.**

- MediaQuery update semantics are defined in svelte/reactivity and not visible here.

<a id="u-ade423f2a64a"></a>
### `Tween`

`class Tween` · [packages/svelte/src/motion/tweened.js:L179-L193][f2]

Reactive tween class whose #current and #target are signals; assigning tween.target tweens tween.current toward it using the delay, duration and easing options.

The constructor seeds both signals with the initial value and stores the options as defaults, tagging the signals in DEV. set(value, options) writes #target immediately, merges defaults with the per-call options (delay 0, duration 400, easing linear, interpolate get_interpolator), and with duration === 0 aborts the running task, snaps #current to value, and returns a resolved promise. Otherwise it starts a loop from start = raf.now() + delay: frames before start keep looping; the first active frame reads the previous #current, builds the interpolator, resolves a function-valued duration as duration(prev, value), and aborts the previous task; when elapsed exceeds duration it snaps #current to value and stops the loop, otherwise it sets #current to fn(easing(elapsed/duration)) and keeps looping. The returned promise is the task's promise. Static of(fn, options) constructs a tween and re-sets it from fn() inside a render_effect, so reactive changes to fn's dependencies drive the target; it must run inside an effect root. The current and target getters read the signals; the target setter delegates to set(v).

calls: [get_interpolator](r1-motion.md#u-6d9737c2921d), [loop](r4-runtime-signals.md#u-4df1fec218a0); uses: [render_effect](r4-runtime-effects.md#u-bbe822faa096)

**Uncertainties.**

- task.abort() settlement semantics live in internal/client/loop.js and are not visible here.
- Unlike the deprecated tweened(), set() does not reject or replace a prior deferred; concurrent set() promises settle per the shared #task promise, which is only observable via loop.js.

<a id="u-6d9737c2921d"></a>
### `get_interpolator`

`function get_interpolator(a, b)` · [packages/svelte/src/motion/tweened.js:L20-L79][f2]

Builds an interpolator from a to b, returning t => value for t in [0,1].

If a === b or a is NaN it returns a constant-a function. If the typeof differs between a and b, or their Array-ness differs, it throws 'Cannot interpolate values of different type'. For arrays it recursively interpolates per index; for objects it throws 'Object cannot be null' if either is null/undefined, interpolates Dates via getTime deltas, and otherwise interpolates over the keys of b per key. For numbers it interpolates a + t * delta. For any other type it snaps: the returned function returns b immediately.

calls: [is_date](r1-motion.md#u-c15d4b363055)

**Uncertainties.**

- Array/object elements whose types differ between a and b throw at construction time via the recursive type check, not per-tick.

<a id="u-a3154029292c"></a>
### `tweened`

`export function tweened(value, defaults = {})` · [packages/svelte/src/motion/tweened.js:L90-L99][f2]

Deprecated store factory wrapping a writable store with tweened transitions.

Its set(new_value, opts) merges the factory defaults with per-call opts (delay 0, duration 400, easing linear, interpolate get_interpolator). If the initial value is null it jumps the store directly to new_value and resolves immediately; if duration === 0 it aborts any previous task, sets the store to the target, and resolves immediately. Otherwise it starts a loop with start = raf.now() + delay: frames before start keep looping; the first active frame builds the interpolator from the current value to new_value, resolves a function-valued duration as duration(from, to), and aborts the previous task; each frame either sets the store to the final value once elapsed exceeds duration (returning false to stop) or sets it to fn(easing(elapsed/duration)) and keeps looping. The returned promise is the task's promise, so it settles per the loop/task semantics. update(fn, opts) delegates to set(fn(target_value, current value), opts); subscribe comes from the underlying store.

calls: [get_interpolator](r1-motion.md#u-6d9737c2921d), [loop](r4-runtime-signals.md#u-4df1fec218a0)

**Uncertainties.**

- Whether task.promise resolves or rejects on abort() depends on loop.js and is not visible here.

<a id="u-c15d4b363055"></a>
### `is_date`

`export function is_date(obj)` · [packages/svelte/src/motion/utils.js:L5-L7][f3]

Type-guard returning true when Object.prototype.toString.call(obj) is exactly '[object Date]', i.e. obj looks like a Date regardless of its realm or constructor identity.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/motion/index.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/motion/tweened.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/motion/utils.js
