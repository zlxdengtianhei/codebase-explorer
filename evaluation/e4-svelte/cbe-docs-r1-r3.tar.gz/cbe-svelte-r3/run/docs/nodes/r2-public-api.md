# Public API Types

**Capability.** The published type surface: the Component/mount/snippet/dispatch types and utility-type helpers of index.d.ts with its branding and deprecated Svelte 4 aliases, server-side API stubs, attachment and event typings, and the language-server-only svelteHTML global namespace.

Use this subtree for consumer-facing typings rather than behavior. index.d.ts is the canonical surface (with deprecations pointing at mount/Component); svelte-html.d.ts is loaded directly by the Svelte language server and deliberately not exported by the package map.

Parent: [Svelte Codebase](r2-svelte-codebase.md)

## Units (10)

<a id="u-fe8809d98989"></a>
### `index-dts-branding`

`type Brand<B> = { [brand]: B };` · [packages/svelte/src/index.d.ts:L111-L111][f1]

Branding utilities used to make internal types nominally distinct.

A unique symbol `brand` backs Brand<B> (an object type carrying the brand) and Branded<T, B> (T intersected with Brand<B>). ComponentInternals is Branded<{}, 'ComponentInternals'> — the opaque token passed as a component's first argument, documented as an internal implementation detail that varies between environments and must not be used or modified by user code.

<a id="u-6c5d1ae3c69f"></a>
### `index-dts-legacy-component`

`export interface ComponentConstructorOptions< Props extends Record<string, any> = Rec…` · [packages/svelte/src/index.d.ts:L11-L24][f1]

Type declarations for the Svelte 4-style class component surface, all marked deprecated in favor of the Svelte 5 `Component` type and `mount`.

ComponentConstructorOptions describes the legacy constructor options: required target (Element | Document | ShadowRoot) plus optional anchor, props, context, hydrate, intro, recover, sync, idPrefix, and $$inline. Properties<Props, Slots> augments props with an optional `children` when the slots type has a default slot; when props is Record<string, never> it degrades to `any` because TypeScript index signatures would otherwise make the children type unsatisfiable. SvelteComponent declares static `element?: typeof HTMLElement` (present only when compiled with the customElement option), an index signature `[prop: string]: any`, a deprecated constructor taking ComponentConstructorOptions<Properties<Props, Slots>>, type-checking-only phantom fields ($$prop_def, $$events_def, $$slot_def, optional $$bindings) documented as not existing at runtime, and the deprecated lifecycle methods $destroy(), $on(type, callback) returning an unsubscribe function, and $set(partial props). These declarations carry no runtime implementation.

**Uncertainties.**

- Runtime behavior of these deprecated members is provided by compatibility helpers not included in this excerpt.

<a id="u-d65ee8957f62"></a>
### `index-dts-component`

`export interface Component< Props extends Record<string, any> = {}, Exports extends R…` · [packages/svelte/src/index.d.ts:L141-L160][f1]

The modern Component interface plus its deprecated SvelteComponentTyped alias.

Component<Props, Exports, Bindings> types components as callables `(internals: ComponentInternals, props: Props) => { $on?, $set? } & Exports`, where internals is the internal Svelte object callers must not touch; the returned $on and $set are deprecated legacy-compatibility hooks ($on takes an untyped string event name and returns an unsubscribe function, $set takes Partial<Props>). Like SvelteComponent it declares optional static `element?: typeof HTMLElement` for custom element builds, and the phantom optional field `z_$$bindings?: Bindings` documented as typing-only and not existing at runtime. SvelteComponentTyped is an empty deprecated class extending SvelteComponent with the same Props/Events/Slots generics, kept only for backwards compatibility.

**Uncertainties.**

- Whether compiled Svelte 5 components actually return $on/$set at runtime depends on the legacy compatibility helpers, which are outside this file.

<a id="u-7f94f3503f67"></a>
### `index-dts-utility-types`

`export type ComponentEvents<Comp extends SvelteComponent> = Comp extends SvelteCompon…` · [packages/svelte/src/index.d.ts:L201-L202][f1]

Conditional type helpers that extract information from a component type.

ComponentEvents<Comp extends SvelteComponent> infers the Events type parameter via `Comp extends SvelteComponent<any, infer Events> ? Events : never` and is deprecated because the new Component type has no dedicated Events parameter. ComponentProps<Comp> infers Props from either SvelteComponent<infer Props> or Component<infer Props, any>, yielding never otherwise; it works for both class-style and function-style components. ComponentType<Comp> types a component constructor: `new (options: ComponentConstructorOptions<inferred Props>) => Comp` intersected with `{ element?: typeof HTMLElement }`, useful for dynamic components with `<svelte:component>`; it is deprecated when used with the new Component type.

<a id="u-95cbbef2f964"></a>
### `index-dts-snippet-dispatch`

`export interface Snippet<Parameters extends unknown[] = []>` · [packages/svelte/src/index.d.ts:L286-L296][f1]

Types for snippet blocks and legacy event dispatch.

Snippet<Parameters extends unknown[]> is the type of a `#snippet` block, callable only through `{@render ...}`: its call signature accepts `...args: number extends Parameters['length'] ? never : Parameters`, a conditional that permits tuples but rejects unbounded arrays (rest-parameter shapes) — the return type is an object carrying a literal error-message key plus typeof SnippetReturn, so misusing a snippet as a plain function produces the message as a type error. DispatchOptions holds the single optional `cancelable?: boolean`. EventDispatcher<EventMap> types the dispatch callable with argument-shape conditionals: when the event type's payload extends null or undefined the parameter is optional (and may be null, since both produce a null detail on CustomEvent); otherwise the parameter is required. Implementation notes in the source explain the `undefined extends X` ordering works under both strict and non-strict modes.

**Uncertainties.**

- The unique symbol SnippetReturn is declared here but any runtime use is not visible in this file.

<a id="u-7a47464ec4a3"></a>
### `index-dts-mount-options`

`export type MountOptions<Props extends Record<string, any> = Record<string, any>> = {…` · [packages/svelte/src/index.d.ts:L318-L353][f1]

Options type for the mount() function.

Required `target: Document | Element | ShadowRoot`; optional anchor (a node inside target before which the component renders), deprecated `events` (callback map, superseded by callback props), context (a Map retrievable via getContext), and intro (whether transitions play on initial render, defaulting to true per the @default tag). Props optionality is conditional: `props` is optional when Props is `{}` (i.e. {} extends Props) and required otherwise.

<a id="u-f647fbd176ca"></a>
### `index-server-js-server-stubs`

`export function onDestroy(fn)` · [packages/svelte/src/index-server.js:L7-L10][f2]

Server-side replacements for client-only Svelte APIs.

`onDestroy` is real: it reads `current_component` as the active server Component and appends `fn` to the component's lazily-created `d` array, making it the only lifecycle hook that runs during SSR. `createEventDispatcher` returns `noop`. `mount`, `hydrate`, and `unmount` all throw `e.lifecycle_function_unavailable(<name>)`. `tick` and `settled` are async no-ops that resolve immediately. The remaining exports re-export client modules' symbols (noop-aliased beforeUpdate/afterUpdate/onMount/flushSync, run as untrack, abort-signal, context, and snippet helpers) and carry no logic.

**Notes.**

- field: onDestroy stores callbacks in `context.d`; the server component teardown mechanism that consumes `d` lives outside this file.

**Uncertainties.**

- Whether onDestroy on the server errors when current_component is null is not visible; the cast assumes an active component.

<a id="u-e7c34ae03fa0"></a>
### `Attachment`

`export interface Attachment<T extends EventTarget = Element>` · [packages/svelte/src/attachments/public.d.ts:L8-L10][f3]

Declares an attachment as a function invoked with the mounted element (type parameter defaulting to Element), optionally returning a cleanup callback run when the element is removed.

The docstring describes mounting/removal timing; the code only types the signature.

<a id="u-c02e60deb134"></a>
### `public-d-ts-events`

`export function on<Type extends keyof WindowEventMap>( window: Window, type: Type, ha…` · [packages/svelte/src/events/public.d.ts:L8-L13][f4]

Declares five overloads of the `on` helper (implementation lives elsewhere), each attaching an event handler to a target and returning an unsubscriber `() => void`.

Overloads cover `Window` with `keyof WindowEventMap`, `Document` with `DocumentEventMap`, `HTMLElement` with `HTMLElementEventMap`, `MediaQueryList` with `MediaQueryListEventMap`, and a generic `(EventTarget, string, EventListener)` fallback; all accept optional `AddEventListenerOptions`. Per the docs, using `on` preserves handler ordering relative to declarative attribute handlers, which rely on event delegation. `this` inside the handler is typed as the target. This file contains signatures only; runtime behavior cannot be read from it.

**Uncertainties.**

- Actual add/remove implementation is not in this file, so ordering and delegation claims rest on the docstrings

<a id="u-f0ba15b74e1f"></a>
### `svelte-html-d-ts-global-namespace`

`type HTMLProps<Property extends string, Override> = Omit< import('./elements.js').Sve…` · [packages/svelte/svelte-html.d.ts:L11-L15][f5]

Declares a global svelteHTML namespace, loaded directly by the Svelte language server and deliberately absent from the package exports map.

It exists only for typings. HTMLProps<Property, Override> computes an element's prop type as Omit(SvelteHTMLElements[Property], keyof Override) intersected with Override, letting consumers replace base props. mapElementTag has three overloads: tag names in ElementTagNameMap map to that element type, SVGElementTagNameMap names to SVG elements, and a fallback any overload supports <svelte:element> with dynamic tags. createElement has two overloads: a two-argument form taking element (Key | undefined | null, permitting svelte:element's dynamic null) and attrs typed as generic HTMLAttributes when Key is string, otherwise the element's specific prop type; and a three-argument form where attrsEnhancers of type T are intersected into attrs. Both return the mapped DOM element type for HTML/SVG tag names, else any. Empty HTMLAttributes and SVGAttributes interfaces exist for backwards compatibility so augmentations of svelte/elements' types flow through (marked for removal in Svelte 6). IntrinsicElements extends svelteElements.SvelteHTMLElements, enumerating HTMLProps overrides per tag (SVGAttributes for SVG tags), plus an index signature accepting arbitrary names, so custom element extensions type-check.

**Notes.**

- side_effect: The file is a declaration-only typing surface; nothing here executes at runtime.
- contract: IntrinsicElements' trailing string index signature makes any unknown tag name valid with { [name: string]: any } props.
- failure: The tree reports an ERROR node near line 1 per source diagnostics; chunk coverage is stated as preserved, so the exact syntax fault could not be verified from the excerpt.

uses: [svelte-html-d-ts-global-namespace](r2-public-api.md#u-f0ba15b74e1f)

**Uncertainties.**

- Exact cause of the reported ERROR tree node near line 1 (possibly the triple-slash reference or import in a .d.ts) cannot be determined from the source excerpt.
- How the language server loads this file and resolves ./elements.js is not shown here.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/index.d.ts
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/index-server.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/attachments/public.d.ts
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/events/public.d.ts
[f5]: ../../../../../../eval/svelte-be645b4/packages/svelte/svelte-html.d.ts
