# Client Store Integration

**Capability.** Per-component store subscription lifecycle: lazily subscribing store_get with caching, conditional resubscription via store_unsub, small write helpers, the stores container/destroy hook, and the store-binding mutability flag.

Compiled store reads route through store_get; writes through the setters. The binding flag relaxes prop-mutability validation for bind:x={$y}.

**Depended on by.**

- [Client Prop Accessors](r3-client-props.md) · graph-confirmed · 1 edge(s)

Parent: [Client Reactivity: Props and Stores](r3-client-reactivity.md)

## Units (5)

<a id="u-59b61f01da09"></a>
### `store.js-setup-stores`

`export function setup_stores()` · [packages/svelte/src/internal/client/reactivity/store.js:L124-L128][f1]

Creates the per-component store references container and its destroy hook.

Returns [stores, cleanup]; cleanup wraps teardown so that on effect teardown every entry's unsubscribe runs, and then defines the non-enumerable IS_UNMOUNTED symbol on the container — store_get checks this symbol to skip resubscription and read stores directly after unmount.

calls: [teardown](r4-runtime-effects.md#u-afcffe6190df)

<a id="u-cba0e706248c"></a>
### `store.js-store-binding-flag`

`export function mark_store_binding()` · [packages/svelte/src/internal/client/reactivity/store.js:L182-L184][f1]

Tracks whether the prop currently being read is a store binding (`bind:x={$y}`), which makes the prop mutable even in runes mode and skips binding_property_non_reactive validation.

mark_store_binding sets the module flag; it is called inside generated prop getters. capture_store_binding runs fn with the flag reset to false, returns [fn(), flag] so the caller sees whether fn's reads marked a binding, and restores the previous flag value in a finally block even when fn throws.

<a id="u-993a5ae5aec4"></a>
### `store.js-store-setters`

`export function store_set(store, value)` · [packages/svelte/src/internal/client/reactivity/store.js:L104-L107][f1]

Small store write helpers.

store_set calls store.set(value) and returns the value. invalidate_store pushes the entry's cached source value back into the cached store, doing nothing when entry.store is null. store_mutate calls store.set(new_value) and returns the mutation expression's value. update_store writes store_value + d (default 1, -1 for decrement) and returns the pre-write store_value; update_pre_store writes store_value + d and returns the new value. None of them read reactivity state.

<a id="u-6bf992bdbb59"></a>
### `store_get`

`export function store_get(store, store_name, stores)` · [packages/svelte/src/internal/client/reactivity/store.js:L30-L74][f1]

Reads a store's current value inside a component, lazily subscribing and caching per store name in the component's stores container.

It creates the entry { store, source, unsubscribe } on first use and labels the source in dev. If the store differs from the cached one and the container is not marked unmounted, it unsubscribes the old subscription; a null store clears the source value and uses a noop unsubscribe. Subscribing captures whether the callback fires synchronously: the first synchronous emissions write entry.source.v directly to avoid state_unsafe_mutation inside derivations, later ones go through set for proper reactivity. When the owning component is already unmounted (IS_UNMOUNTED symbol in the container) it bypasses the cached source and reads the store directly via get_store, keeping values consistent without leaking subscriptions. Otherwise it returns get(entry.source) so the reading reaction subscribes to the source signal.

calls: [subscribe_to_store](r1-store-compat.md#u-863f9153e183), [packages/svelte/src/internal/client/runtime.js:get](r2-reactivity-core.md#u-98099fbbf12a), [packages/svelte/src/internal/client/reactivity/sources.js:set](r5-client-reactivity.md#u-452914169f68)

**Uncertainties.**

- subscribe_to_store's immediate-call guarantee (synchronous first emission) is implemented in store/utils.js, not visible here.

<a id="u-acc685c0000a"></a>
### `store_unsub`

`export function store_unsub(store, store_name, stores)` · [packages/svelte/src/internal/client/reactivity/store.js:L84-L95][f1]

Conditionally unsubscribes a cached store entry: if an entry exists for store_name and its cached store differs from the passed store, it calls entry.unsubscribe and replaces it with noop, deliberately leaving entry.store intact so a subsequent store_get can resubscribe to the new store.

Returns the store argument unchanged either way.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/reactivity/store.js
