# Legacy Client Compatibility

**Capability.** Svelte 4 compatibility on the client: legacy signal invalidation via captured signal sets, the legacy component lifecycle bootstrap reading legacy callbacks from component context, and deprecated Svelte 4 event-modifier shims built as handler wrappers.

Use when compiled legacy output or `svelte/legacy` helpers behave unexpectedly. capture_signals/invalidate_inner_signals force reactions to re-run; event-modifiers delegate to the event system.

**Depends on.**

- [Event System & Delegation](r1-event-system.md) · graph-confirmed · 2 edge(s)

Parent: [Client Runtime](r1-client-runtime.md)

## Units (4)

<a id="u-901893964aa4"></a>
### `capture_signals`

`function capture_signals(fn)` · [packages/svelte/src/internal/client/legacy.js:L16-L34][f1]

Captures all signals read during fn by running untrack(fn) with the module-level captured_signals set to a new Set, so source writes record reads into that set instead of normal dependency tracking.

The previous set is saved and restored in a finally block; if there was a previous set, all newly captured signals are merged into it, so nested captures accumulate outward. Returns the new set.

**Notes.**

- side_effect: Reads and restores the module-level captured_signals variable, so this function must not be used re-entrantly across async boundaries.

calls: [runtime-js-state-and-helpers](r2-reactivity-core.md#u-6cd2387802ec)

<a id="u-4dc669135a61"></a>
### `invalidate_inner_signals`

`export function invalidate_inner_signals(fn)` · [packages/svelte/src/internal/client/legacy.js:L42-L46][f1]

Deprecated legacy helper: runs fn via capture_signals and then calls internal_set(signal, signal.v) for every captured signal, forcing each one's reactions to re-run even though the value is unchanged.

calls: [capture_signals](r1-legacy-compat-client.md#u-901893964aa4), [internal_set](r5-client-reactivity.md#u-0dae6a8d64cd)

<a id="u-d1fb3ea6618e"></a>
### `packages/svelte/src/internal/client/dom/legacy/lifecycle.js:init`

`export function init(immutable = false)` · [packages/svelte/src/internal/client/dom/legacy/lifecycle.js:L12-L18][f2]

Legacy-mode component lifecycle bootstrap: reads the current `component_context` and, if its legacy callbacks (`context.l.u`) are absent, returns immediately.

Otherwise it builds a `props` reader — by default `deep_read_state(context.s)`; in immutable mode it instead derives a version counter from a `derived` that compares each key of `context.s` against cached previous values and increments only on identity changes, so before/afterUpdate fire only when a prop object identity changes. It then installs three effects: a `user_pre_effect` running `observe_all(context, props)` then all `beforeUpdate` callbacks (only when `callbacks.b` is non-empty), a `user_effect` running all `onMount` callbacks untracked whose returned functions are invoked as teardown, and a `user_effect` running `observe_all` then all `afterUpdate` callbacks (only when `callbacks.a` is non-empty). On-mount intentionally runs before afterUpdate.

**Notes.**

- condition: In immutable mode the derived's prev cache is shared across firings, so only the first identity change per key bumps the version.
- failure: A missing `component_context` would throw on property access; the cast assumes it is present.

uses: [../../context.js](../../catalog.json); calls: [../../reactivity/deriveds.js](../../catalog.json), [../../reactivity/effects.js](../../catalog.json), [../../runtime.js](../../catalog.json), [../../../shared/utils.js](../../catalog.json), [packages/svelte/src/internal/client/dom/legacy/lifecycle.js:init](r1-legacy-compat-client.md#u-d1fb3ea6618e)

**Uncertainties.**

- The graph maps `_iterator_1.next()` to three unrelated `next` candidates; the for-of iteration targets are plain arrays/objects in this source, so the mapping is inconclusive

<a id="u-407a942f4693"></a>
### `event-modifiers-js`

`export function trusted(fn)` · [packages/svelte/src/internal/client/dom/legacy/event-modifiers.js:L11-L19][f3]

Deprecated shims reproducing Svelte 4 event modifiers as wrapper functions, for legacy compiled output.

`trusted(fn)` forwards to `fn` only when `event.isTrusted`; `self(fn)` forwards only when `event.target === this`; `stopPropagation`, `stopImmediatePropagation`, and `preventDefault` call the corresponding event method first and return `fn`'s result; `once(fn)` closes over a `ran` flag and returns immediately on every call after the first. All wrapper-based modifiers tolerate an undefined `fn` via `fn?.apply(this, args)` and preserve `this`. `passive(node, [event, handler])` and `nonpassive(node, ...)` instead attach the listener through a `user_pre_effect` calling the internal `on`, with `{ passive: true }` or `{ passive: false }` respectively; `handler` is invoked (it returns the listener) and a null result falls back to `noop`. The pre-effect's return value serves as teardown.

calls: [../elements/events.js](../../catalog.json), [../../reactivity/effects.js](../../catalog.json); imports: [../../../shared/utils.js](../../catalog.json)

**Uncertainties.**

- Whether once's `ran` flag is shared correctly across re-bound handlers is per-closure by construction; no reset path exists in this file

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/legacy.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/legacy/lifecycle.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/legacy/event-modifiers.js
