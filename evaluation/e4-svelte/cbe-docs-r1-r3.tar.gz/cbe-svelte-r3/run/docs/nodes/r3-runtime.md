# Runtime

**Capability.** Executes compiled Svelte output: the client runtime creates and hydrates DOM with fine-grained reactivity, and the server runtime renders components to HTML strings.

client-runtime covers DOM creation, hydration, reactive props/stores, rendering lifecycle, and dev checks; server-runtime covers SSR rendering, markup serialization, templating helpers, stores, and dev validation.

**Children.**

- [Client Runtime](r3-client-runtime.md) `r3-client-runtime` · 0 unit(s)
- [Server Runtime](r3-server-runtime.md) `r3-server-runtime` · 0 unit(s)

Parent: [Svelte Compiler and Runtime](r3-svelte.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
