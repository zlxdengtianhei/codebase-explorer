# Analysis Phase

**Capability.** Second compilation phase: walks module and instance/template ASTs with a visitor map, scopes bindings, and validates runes/template usage before any code is generated.

analyze-driver coordinates the walk and reactive-statement ordering; analyze-visitors holds the per-node-type validation and metadata collection. Consume its output via compiler-entry.

**Children.**

- [Analysis Driver](r3-analyze-driver.md) `r3-analyze-driver` · 6 unit(s)
- [Analysis Visitors](r3-analyze-visitors.md) `r3-analyze-visitors` · 18 unit(s)

Parent: [Compiler Pipeline](r3-compiler.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
