# ESLint Configuration

**Capability.** The repository's flat ESLint config array spreading @sveltejs/eslint-config plus appended config objects, including a rule visitor that scans each program's source text and reports references to the Svelte compiler.

Use when adjusting lint rules for this repo; the create method builds the compiler-reference-detecting rule visitor.

Parent: [Repository Tooling](r1-tooling.md)

## Units (2)

<a id="u-34b493301cfd"></a>
### `create`

`const no_compiler_imports = { meta: { type: /** @type {const} */ ('problem'), docs: {…` · [eslint.config.js:L4-L33][f1]

Creates a lint rule visitor that scans each program's full source text for references to the Svelte compiler and reports the first occurrence.

It runs once per Program node, fetching the whole file text with context.sourceCode.getText(), then does a plain string search — the comment explains this is because ESLint offers no API for JSDoc comment inspection, and possible false positives are accepted as unlikely. It takes the later of the two match positions ('../compiler/' and '#compiler') via Math.max, so whichever pattern appears is found; if neither matches (both indexOf return -1, max is -1) no report is made. When a match is found it reports at the location of the match start through start+12 characters with a fixed message forbidding compiler references in runtime code, for both type and value imports.

**Notes.**

- side_effect: Reports at most one diagnostic per file, at the position of whichever compiler-reference pattern occurs later in the text.

imports: [@sveltejs/eslint-config](../../catalog.json)

**Uncertainties.**

- The end location is start+12 regardless of which pattern matched, so the reported range may not exactly cover a '../compiler/' match (12 chars) versus '#compiler' (9 chars).

<a id="u-4c030f15b9c8"></a>
### `eslint.config.js-flat-config`

`group` · [eslint.config.js:L33-L109][f1]

Exports the flat ESLint configuration as an array that spreads @sveltejs/eslint-config and appends four config objects.

The first sets TypeScript project service with tsconfigRootDir at the file's directory, registers the lube plugin and the custom no_compiler_imports rule (the create method documented separately), and toggles rules: turns on await-thenable, require-await, no-console and lube/svelte-naming-convention (with fixSameNames), turns off object-shorthand and prefer-promise-reject-errors because ESLint misflags JSDoc cast patterns, leaves no-var off, and disables quotes, no-unused-vars and prefer-const pending a future lint fix pass. The second object targets **/*.svelte files and disables the three type-aware TypeScript rules there, per the comment explaining that type-aware rules fail when run through Svelte files. The third targets packages/svelte/src/** excluding packages/svelte/src/compiler/** and enables custom/no_compiler_imports while disabling svelte/no-svelte-internal. The final object is a global ignores list excluding declaration files, tests, generated/bundled scripts, error and warning modules, the compiler entry, benchmarking, coverage, playground, other config files, documentation, and tmp directories.

uses: [create](r1-eslint-config.md#u-34b493301cfd); imports: [@sveltejs/eslint-config](../../catalog.json), [eslint-plugin-lube](../../catalog.json)

**Uncertainties.**

- Whether later config objects fully override earlier rule severities follows flat-config merge semantics, which is assumed from the standard format rather than shown here.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/eslint.config.js
