# Sandbox Playground

**Capability.** Sandbox app maintenance scripts: seeding src/main.svelte from a template, converting the sandbox app into a Svelte test directory via recursive import-closure collection and file copying, and exporting the sandbox compiler options.

Use when adjusting the development sandbox. create-test.js owns the conversion flow (validate target, collect imports, copy with renames); svelte.config.js pins the experimental compiler flags.

**Depends on.**

- [Compiler Pipeline](r5-compiler.md) · model-inferred · 0 edge(s)

Parent: [Repository Tooling](r5-tooling.md)

## Units (5)

<a id="u-dde2e710e027"></a>
### `create-app-svelte.js module code (L1–L13)`

`module_region` · [playgrounds/sandbox/scripts/create-app-svelte.js:L1-L13][f1]

Seeds src/main.svelte from a template file when it does not already exist; directory creation errors are ignored, and nothing happens if the destination exists.

<a id="u-44dc189350cd"></a>
### `create-test.js module code (L1–L71)`

`module_region` · [playgrounds/sandbox/scripts/create-test.js:L1-L71][f2]

Turns the current sandbox app into a Svelte test directory, validating the target, confirming overrides, and clearing old samples except _config.js.

**Notes.**

- condition: Missing target or one not starting with 'runtime-' aborts with process.exit(1); a target without '/' is prefixed with 'runtime-runes/'.
- side_effect: Existing sample contents other than _config.js are recursively force-removed after a raw-mode stdin confirmation; 'n' cancels with exit 0.
- side_effect: When the target was newly created, an empty _config.js test stub is written at the end.

<a id="u-1a06a1a0bb15"></a>
### `collect_imports`

`function collect_imports(file_path)` · [playgrounds/sandbox/scripts/create-test.js:L72-L113][f2]

Recursively collects the sandbox App.svelte dependency closure by following relative import statements, memoizing visited paths and trying extension fallbacks.

**Notes.**

- condition: Skips already-processed or nonexistent files, and skips imports not starting with '.' (node_modules).
- contract: Resolution tries '', '.svelte', '.js', '.ts' suffixes in that order and recurses on the first existing path.

<a id="u-2f95b981947e"></a>
### `create-test.js module code (L113–L155)`

`module_region` · [playgrounds/sandbox/scripts/create-test.js:L113-L155][f2]

Copies collected files into the target folder, renaming App.svelte to main.svelte and creating target directories as needed.

<a id="u-a065383f67c4"></a>
### `svelte.config.js module code (L1–L9)`

`module_region` · [playgrounds/sandbox/svelte.config.js:L1-L9][f3]

Exports sandbox Svelte compiler options: HMR disabled and the experimental async feature enabled.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/playgrounds/sandbox/scripts/create-app-svelte.js
[f2]: ../../../../../../eval/svelte-be645b4/playgrounds/sandbox/scripts/create-test.js
[f3]: ../../../../../../eval/svelte-be645b4/playgrounds/sandbox/svelte.config.js
