# Compiler

**Capability.** Owns the full compilation pipeline: parsing Svelte source into an AST, analyzing it for warnings and metadata, transforming it into client and server output, and preprocessing component source before compilation.

Pick the phase of interest: parse, analyze, transform (client or server), or preprocess. Diagnostics infrastructure shared by analysis is kept separate from the checking visitors that consume it.

**Children.**

- [Parse Phase](r1-compiler-parse.md) `r1-compiler-parse` · 0 unit(s)
- [Analyze Phase](r1-compiler-analyze.md) `r1-compiler-analyze` · 0 unit(s)
- [Compiler Warning Infrastructure](r1-compiler-diagnostics-infrastructure.md) `r1-compiler-diagnostics-infrastructure` · 3 unit(s)
- [Transform Phase](r1-compiler-transform.md) `r1-compiler-transform` · 0 unit(s)
- [Preprocessing](r1-preprocess.md) `r1-preprocess` · 10 unit(s)

Parent: [Svelte Repository](r1-svelte-monorepo.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
