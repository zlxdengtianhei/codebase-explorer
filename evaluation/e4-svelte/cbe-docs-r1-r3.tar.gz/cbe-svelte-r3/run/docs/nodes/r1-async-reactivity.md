# Async Reactivity

**Capability.** Keeps reactive context correct across awaits: capture/restore of effect, reaction, and component context; context nulling; save() closures so post-await expressions track as if synchronous; reactivity-loss tracking for awaits and `for await`; flatten() of async template expressions; and the module's non-behavioral regions.

Read when debugging effects or deriveds that lose tracking after an await. flatten is consumed by async template blocks; save/track_reactivity_loss are compiled into awaited expressions.

**Depended on by.**

- [DOM Template Blocks](r1-dom-blocks.md) · graph-confirmed · 1 edge(s) · async template blocks call flatten to preserve reactive tracking across awaited expressions.

Parent: [Client Runtime](r1-client-runtime.md)

## Units (8)

<a id="u-c50793421b66"></a>
### `flatten`

`export function flatten(sync, async, fn)` · [packages/svelte/src/internal/client/reactivity/async.js:L30-L65][f1]

Flattens sync and async expression getters into derived-backed values passed to a callback, used by template and attribute effects.

With an empty `async` array it maps each sync getter through `derived` (runes mode) or `derived_safe_equal` and calls `fn` synchronously. Otherwise it snapshots context via `capture`, resolves the pending boundary, and wraps each async expression in `async_derived`; when `Promise.all` resolves it activates the captured batch, restores context, and calls `fn` inside try/catch — errors reach the error boundary only if the parent effect is not DESTROYED, otherwise they are ignored. It then deactivates the batch and clears context. Rejection of the combined promise (an async expression failing) is routed to the pending boundary's `error` instead.

calls: [capture](r1-async-reactivity.md#u-0edcd5d2a7c1), [unset_context](r1-async-reactivity.md#u-2e39d8f937d3), [deriveds-async-derived](r4-runtime-signals.md#u-0dbfaaba8bef)

**Uncertainties.**

- Whether `current_batch` being null mid-flush changes ordering beyond the optional `activate`/`deactivate` calls is not provable from this file alone.

<a id="u-0edcd5d2a7c1"></a>
### `capture`

`function capture()` · [packages/svelte/src/internal/client/reactivity/async.js:L72-L88][f1]

Snapshots active effect, active reaction, component context, and current batch, returning a `restore` closure.

Calling `restore` reinstates all four via the runtime/context setters, re-activates the previous batch if one existed, and in DEV clears async-derived tracking with `set_from_async_derived(null)`, so continuation code after an `await` re-registers dependencies in the original effect context.

contract: [unset_context](r1-async-reactivity.md#u-2e39d8f937d3)

<a id="u-2e39d8f937d3"></a>
### `unset_context`

`export function unset_context()` · [packages/svelte/src/internal/client/reactivity/async.js:L170-L175][f1]

Nulls active effect, active reaction, and component context, and in DEV the async-derived tracking value, so async continuation work does not leak stale reactive context into unrelated effects.

contract: [capture](r1-async-reactivity.md#u-0edcd5d2a7c1)

<a id="u-183453782dc0"></a>
### `save`

`export async function save(promise)` · [packages/svelte/src/internal/client/reactivity/async.js:L98-L106][f1]

Compiles `await a + b` into `(await $.save(a))() + b`: it captures the reactive context before awaiting, and once the promise resolves returns a closure that restores the context and yields the resolved value, so following expressions track dependencies as if synchronous.

calls: [capture](r1-async-reactivity.md#u-0edcd5d2a7c1)

<a id="u-f77b77ba957d"></a>
### `track_reactivity_loss`

`export async function track_reactivity_loss(promise)` · [packages/svelte/src/internal/client/reactivity/async.js:L115-L123][f1]

Captures `current_async_effect` before awaiting a promise; the returned closure re-establishes it via `set_from_async_derived` and yields the value, so reactivity-loss warnings can be emitted for state read after the await outside an async derived.

calls: [for_await_track_reactivity_loss](r1-async-reactivity.md#u-9b4068c7d68b)

<a id="u-9b4068c7d68b"></a>
### `for_await_track_reactivity_loss`

`export async function* for_await_track_reactivity_loss(iterable)` · [packages/svelte/src/internal/client/reactivity/async.js:L135-L168][f1]

Async generator wrapping `for await` loops so reactivity-loss tracking applies after each iteration and after iterator close (per ECMA-262 ForIn/OfBodyEvaluation and AsyncIteratorClose).

It obtains an iterator via `Symbol.asyncIterator`, falling back to `Symbol.iterator`; if neither yields an iterator it throws `TypeError('value is not async iterable')`. Each `iterator.next()` result is unwrapped through `track_reactivity_loss`; on `done` it sets `normal_completion` and breaks. In `finally`, only on normal completion (not `break` or early exit) and only when `iterator.return` is defined, it awaits the wrapped `return()` and returns its `.value` as the generator's return value.

**Notes.**

- failure: Early exit via `break` skips `iterator.return` because `normal_completion` remains false.

calls: [track_reactivity_loss](r1-async-reactivity.md#u-f77b77ba957d)

<a id="u-7844e4272e2c"></a>
### `async_body`

`export async function async_body(fn)` · [packages/svelte/src/internal/client/reactivity/async.js:L180-L193][f1]

Runs an async template block body.

It calls `suspend()` (holding batch/boundary pending state) and awaits `fn`. If `fn` rejects and the capturing effect is not DESTROYED (`aborted` false), the error goes to the error boundary; if the effect was destroyed the error is swallowed. The `finally` block always invokes `unsuspend`, which decrements pending counts and can trigger a batch flush.

uses: [suspend](r2-reactivity-core.md#u-aed941f29bc8); calls: [aborted](r4-runtime-effects.md#u-028f962a5fe6)

<a id="u-25fc0fa7192f"></a>
### `async-js-module-regions`

`group` · [packages/svelte/src/internal/client/reactivity/async.js:L1-L29][f1]

Non-behavioral regions of async.js: the type-only import header and the small inter-function gaps between exported helpers.

They contain only `@import` annotations and blank lines; no runtime logic.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/reactivity/async.js
