# DOM Elements

**Capability.** Element-level runtime behaviors: event-listening helpers with reactive-context suppression, element size bindings over a shared ResizeObserver, style/style-directive application, and transitions/animations driven through the Web Animations API.

Use this subtree for binding and visual-behavior questions: without_reactive_context keeps binding handlers dependency-free, size.js shares observers, and transitions.js builds managers that the effect pause/resume machinery triggers. set_style/update_styles apply style strings and directive maps.

**Depends on.**

- [Reactivity Core & Batching](r2-reactivity-core.md) · graph-confirmed · 6 edge(s)
- [Svelte Codebase](r2-svelte-codebase.md) · within containment · 1 edge(s)

**Depended on by.**

- [Element Bindings and Behaviors](r4-runtime-element-bindings.md) · graph-only · 11 edge(s)

Parent: [Client Runtime](r2-client-runtime.md)

## Units (15)

<a id="u-8f0d8dd6601b"></a>
### `listen`

`export function listen(target, events, handler, call_handler_immediately = true)` · [packages/svelte/src/internal/client/dom/elements/bindings/shared.js:L18-L32][f1]

Registers a handler on an EventTarget for each named event and removes all listeners during effect teardown.

Unless call_handler_immediately is false, the handler is invoked once right away with no event argument, which is how one-off bindings push their initial DOM value into state.

calls: [teardown](r4-runtime-effects.md#u-afcffe6190df)

<a id="u-ff3a57d1f4f9"></a>
### `without_reactive_context`

`export function without_reactive_context(fn)` · [packages/svelte/src/internal/client/dom/elements/bindings/shared.js:L38-L49][f1]

Runs fn with the active reaction and effect temporarily set to null, restoring both in a finally block.

This prevents reads inside event handlers (e.g. get() calls during scroll or input events) from registering dependencies on the surrounding effect.

calls: [runtime-js-state-and-helpers](r2-reactivity-core.md#u-6cd2387802ec)

<a id="u-adb7ad8d3643"></a>
### `listen_to_event_and_reset_event`

`export function listen_to_event_and_reset_event(element, event, handler, on_reset = h…` · [packages/svelte/src/internal/client/dom/elements/bindings/shared.js:L59-L76][f1]

Listens to a binding's event, running the handler inside without_reactive_context so its reads create no dependencies, and wires form-reset support.

It chains onto any existing element.__on_r handler (special case: a checkbox can carry both group and checked bindings, so the previous reset handler runs first, then on_reset(true)), or stores a fresh one calling on_reset(true); on_reset defaults to the main handler. Finally it ensures the global form reset listener exists via add_form_reset_listener.

calls: [without_reactive_context](r2-dom-elements.md#u-ff3a57d1f4f9), [add_form_reset_listener](r4-runtime-element-bindings.md#u-3524dfa24535)

**Uncertainties.**

- The invocation order of __on_r after a form reset depends on add_form_reset_listener, which is outside this file.

<a id="u-d29cfe379011"></a>
### `ResizeObserverSingleton`

`class ResizeObserverSingleton` · [packages/svelte/src/internal/client/dom/elements/bindings/size.js:L9-L23][f2]

Shares one native ResizeObserver per box option across many elements, so at most one observer callback exists per element per singleton.

The constructor only stores ResizeObserverOptions; three module-level singletons exist for content-box, border-box and device-pixel-content-box, and a static entries WeakMap caches the latest ResizeObserverEntry per element. observe adds the listener to a per-element Set, starts observing, and returns an unsubscribe function that removes the listener and, when the Set empties, deletes the entry and unobserves the element. #getObserver lazily creates the ResizeObserver; its callback stores each entry in the static entries map and dispatches it to that element's current listeners.

<a id="u-4086fd190663"></a>
### `bind_element_size`

`export function bind_element_size(element, type, set)` · [packages/svelte/src/internal/client/dom/elements/bindings/size.js:L100-L108][f2]

Observes the element via the border-box singleton, calling set(element[type]) on resize where type is clientWidth/clientHeight/offsetWidth/offsetHeight.

An effect performs an initial untracked set (so reads during the update are not tracked as dependencies) and returns the unsubscribe as its teardown.

uses: [ResizeObserverSingleton](r2-dom-elements.md#u-d29cfe379011); calls: [runtime-js-state-and-helpers](r2-reactivity-core.md#u-6cd2387802ec)

<a id="u-dd65fd2f8c17"></a>
### `bind_resize_observer`

`export function bind_resize_observer(element, type, set)` · [packages/svelte/src/internal/client/dom/elements/bindings/size.js:L83-L93][f2]

Routes the element to the singleton matching the requested entry type (contentRect/contentBoxSize to content-box, borderBoxSize to border-box, anything else to device-pixel-content-box), observes it, and calls set with entry[type] on each resize.

Teardown invokes the unsubscribe returned by observe.

uses: [ResizeObserverSingleton](r2-dom-elements.md#u-d29cfe379011); calls: [teardown](r4-runtime-effects.md#u-afcffe6190df)

<a id="u-24fad240d483"></a>
### `update_styles`

`function update_styles(dom, prev = {}, next, priority)` · [packages/svelte/src/internal/client/dom/elements/style.js:L10-L22][f3]

Applies per-key style property diffs: for each key in next whose value differs from prev's (prev defaults to {}), a nullish value removes the CSS property, otherwise it sets it via style.setProperty with the optional priority (used to pass 'important').

<a id="u-dd07311bde30"></a>
### `set_style`

`export function set_style(dom, value, prev_styles, next_styles)` · [packages/svelte/src/internal/client/dom/elements/style.js:L30-L57][f3]

Applies a style string plus optional style-directive maps to an element, tracking the raw value in dom.__style.

When hydrating or the value changed, it computes the combined style attribute with to_style(value, next_styles); during hydration it writes only if that differs from the server-rendered attribute, then either removes the style attribute when nullish or assigns style.cssText. When the string is unchanged but next_styles is present, it diffs incrementally: array-valued directive pairs update the normal styles then the 'important' styles via update_styles, otherwise a single map is diffed. Returns next_styles.

calls: [to_style](r2-svelte-codebase.md#u-50b25ac26373), [update_styles](r2-dom-elements.md#u-24fad240d483)

**Uncertainties.**

- to_style's combination rules live in shared/attributes.js, not supplied

<a id="u-397113669a45"></a>
### `css_property_to_camelcase`

`function css_property_to_camelcase(style)` · [packages/svelte/src/internal/client/dom/elements/transitions.js:L35-L52][f4]

Converts a CSS property name to the camelCase form needed by Element.animate: 'float' maps to cssFloat and 'offset' to cssOffset per spec; custom properties starting with '--' are returned unchanged; a single word is returned as-is; otherwise the first word is followed by each subsequent word capitalized.

<a id="u-fbaa1dadf713"></a>
### `css_to_keyframe`

`function css_to_keyframe(css)` · [packages/svelte/src/internal/client/dom/elements/transitions.js:L58-L70][f4]

Parses a css string into a Keyframe object by splitting on ';' then ':' and converting each property via css_property_to_camelcase with trimmed values.

If a part lacks a property or its value is undefined, the loop breaks, so malformed trailing parts are dropped rather than added.

<a id="u-24e771f73bd1"></a>
### `packages/svelte/src/internal/client/dom/elements/transitions.js:linear`

`const linear = (t) =>` · [packages/svelte/src/internal/client/dom/elements/transitions.js:L73-L73][f4]

Identity easing function returning t unchanged; the default easing for animations without one.

<a id="u-4fbd2318aa9b"></a>
### `dispatch_event`

`function dispatch_event(element, type)` · [packages/svelte/src/internal/client/dom/elements/transitions.js:L24-L28][f4]

Dispatches a CustomEvent of the given transition lifecycle type ('introstart' etc.) on the element, wrapped in without_reactive_context so dispatching does not register reads against the current reactive context.

calls: [without_reactive_context](r2-dom-elements.md#u-ff3a57d1f4f9)

<a id="u-ebc7650933de"></a>
### `animate`

`function animate(element, options, counterpart, t2, on_finish)` · [packages/svelte/src/internal/client/dom/elements/transitions.js:L314-L372][f4]

Drives an element's intro/outro using the Web Animations API and returns an Animation facade {abort, deactivate, reset, t}.

If options is a function (deferred transitions like crossfade), it queues a micro task to resolve the config after the DOM update, returning a synchronous facade that forwards to the eventual animation and whose abort sets an aborted flag. Otherwise it deactivates the counterpart; when options is missing or has zero duration it calls on_finish immediately and returns no-op stubs whose t() reports t2. For a real animation: an intro with no counterpart first invokes tick(0,1) and seeds keyframes from css(0,1). It then plays a dummy zero-ish animation lasting the delay with fill:'forwards' so keyframes are only created after the DOM update. Its onfinish cancels the dummy, takes the counterpart's current t as the start (so bidirectional transitions resume from their position), aborts the counterpart, computes delta and scaled duration, and for positive duration builds per-frame keyframes by sampling css at eased t values (n frames sized to 60fps, n forced integer), forces overflow:hidden inline when any keyframe uses it (Safari <18 workaround), and plays the main animation with fill:'forwards'; a tick callback loops while playing, reporting t from animation.currentTime through the easing. On the main animation's finish, t is pinned to t2, tick gets its final call, and on_finish runs. abort cancels the current animation, nulls its effect (Chromium leak prevention), and neutered onfinish (post-cancel fire prevention). deactivate turns on_finish into a noop; reset on an outro (t2===0) calls tick(1,0); t() reads the current get_t.

**Uncertainties.**

- Whether the closures call the same-file loop() is plausible but the call graph in this excerpt is ambiguous
- Behavior of element.animate and Web Animation timing guarantees are platform behavior, not source

<a id="u-d0d565c5637e"></a>
### `animation`

`export function animation(element, get_fn, get_params)` · [packages/svelte/src/internal/client/dom/elements/transitions.js:L83-L100][f4]

Creates or reuses a keyed-each animation manager attached to the current each item as item.a, so element moves after reconciliation can be animated.

The manager has four phases: measure captures the element's bounding rect into from; apply aborts any running animation, captures the destination rect, and when the rects differ in any edge calls the user's animate function with {from, to} and params, feeding the result into animate() with a completion callback that aborts and clears it; fix temporarily takes the element out of flow only when no Web Animations are already running (animation styles would otherwise override the fix), snapshotting position/width/height/transform, setting position absolute with fixed width/height, and applying a translate to bridge from the old to the new top-left if they moved; unfix restores the snapshot. The outer function also updates item.a.element on each call, since a changing <svelte:element> tag can reuse an existing manager.

**Uncertainties.**

- When measure/apply/fix/unfix are invoked by the each-block machinery is defined outside this file
- current_each_item's lifecycle is not visible here

<a id="u-61fe578d008d"></a>
### `transition`

`export function transition(flags, element, get_fn, get_params)` · [packages/svelte/src/internal/client/dom/elements/transitions.js:L184-L211][f4]

Builds a transition manager from flags (TRANSITION_IN/OUT/GLOBAL) and attaches it to the active effect's transitions list, where pause/resume effect logic later triggers intro/outro.

It computes direction ('both', 'in', or 'out'), stashes element.inert and the inline overflow style, and caches current_options. get_options resolves options through without_reactive_context and reuses cached options so an ongoing reversible transition continues smoothly rather than restarting with new config. in(): restores inert; a non-intro aborts/reset any outro and returns; a non-bidirectional intro aborts a prior intro; then dispatches 'introstart' and starts animate with target 1, whose finish callback dispatches 'introend', aborts and clears intro and current_options, and restores the overflow style. out(fn): a non-outro calls fn immediately and clears current_options; otherwise it sets inert true, dispatches 'outrostart', and animates to 0 with counterpart intro, finishing with 'outroend' then fn. stop() aborts both. Finally, if this is an intro that should run (should_intro), local (non-global) transitions only run when the owning block effect has already run, walking up past transparent blocks (snippets, else-if) to find the nearest block effect; if none exists or its EFFECT_RAN flag is set, transition.in() is invoked untracked inside a new effect.

uses: [transition](r2-dom-elements.md#u-61fe578d008d); calls: [without_reactive_context](r2-dom-elements.md#u-ff3a57d1f4f9), [effect](r4-runtime-effects.md#u-68382c2a31f5), [runtime-js-state-and-helpers](r2-reactivity-core.md#u-6cd2387802ec)

**Uncertainties.**

- Whether in()/out() invoke animate (same-file, not in the supplied call graph) is inferred from the code shape
- Behavior of pause_effect/resume_effect consuming e.transitions is defined elsewhere

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/elements/bindings/shared.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/elements/bindings/size.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/elements/style.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/elements/transitions.js
