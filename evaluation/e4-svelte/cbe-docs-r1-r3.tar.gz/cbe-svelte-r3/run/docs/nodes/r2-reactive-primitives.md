# Reactive Primitives

**Capability.** Public-facing reactive value types and bridges built on the internal runtime: SvelteURLSearchParams, MediaQuery, window-state exports, createSubscriber for lazy external subscriptions, store ↔ reactive interop (toStore/fromStore), and their test suite.

Use this subtree to see how user-facing reactivity is layered over the internal signal system. Each primitive wraps ReactiveValue-style reads with start/stop subscriptions; createSubscriber is the shared lazy-wiring mechanism; map.test.ts documents SvelteMap behavior.

**Depends on.**

- [Reactivity Core & Batching](r2-reactivity-core.md) · graph-confirmed · 6 edge(s) · public primitives like createSubscriber and toStore build on the internal runtime state helpers and get.
- [Signal Reactivity Core](r5-client-reactivity.md) · graph-only · 12 edge(s)

**Depended on by.**

- [Warning Message Codegen](r2-message-codegen.md) · graph-confirmed · 1 edge(s)

Parent: [Svelte Codebase](r2-svelte-codebase.md)

## Units (8)

<a id="u-44838dbc4415"></a>
### `createSubscriber`

`export function createSubscriber(start)` · [packages/svelte/src/reactivity/create-subscriber.js:L54-L95][f1]

Creates a subscribe function that lazily wires an external event source into Svelte's reactivity.

The returned function does nothing when called outside effect tracking. When called inside a tracked effect, it reads the version source (subscribing the caller to version changes) and creates a render effect that, on its first run while subscribers is 0, calls start with an update callback under untrack; start's return value (a cleanup function or void) is stored in stop. Each render-effect run increments subscribers. The render effect's teardown defers through queue_micro_task before decrementing subscribers, so a re-run of the same render effect does not pass through 0 and trigger a needless teardown/re-subscribe cycle (which would leak the old subscription); when the deferred decrement reaches 0 it invokes and clears stop, then increments the version so dependent deriveds compare dirty and re-run when the subscription is later re-established. Calling the update callback given to start increments the version, re-running any effects that read the returned subscribe function. In DEV the version source is tagged for tracing.

**Notes.**

- side_effect: start runs only once while any subscriber effect is alive; its cleanup runs when the last subscriber effect is destroyed.
- condition: The teardown's subscribers decrement is queued via queue_micro_task to avoid reaching 0 during a same-effect rerun.

uses: [ReactiveValue](r5-client-reactivity.md#u-55ae66fdfd50)

<a id="u-16bd40497c5c"></a>
### `url-search-params.js-svelteurlsearchparams`

`#update_url()` · [packages/svelte/src/reactivity/url-search-params.js:L41-L49][f2]

A URLSearchParams subclass that makes its contents reactive and, when the module captured a current URL via get_current_url at class-field initialization, mirrors changes back to that URL's search string.

Reactivity is driven by a version source (#version, tagged in DEV) incremented by mutations; all read paths (get, getAll, has, keys, values, entries, toString, size) call get(this.#version) first so effects reading them re-run on change; [Symbol.iterator] delegates to entries. Mutation paths append, delete, set, sort call super first, then update the URL and increment the version, but only some guard against no-op mutations: delete checks super.has(name, value) beforehand and skips syncing/incrementing when absent; set compares the joined super.getAll(name) before and after (deliberately not has(name, value), which would miss removals like foo=3 when setting foo); append, sort, and [REPLACE] always sync and increment, so append of a duplicate pair still invalidates readers. #update_url serializes via toString and assigns this.#url.search (empty string stays empty, otherwise '?'+search); it no-ops when there is no current URL or when #updating is set. The internal [REPLACE]\(params) method atomically swaps all entries: if #updating it returns immediately, otherwise it sets #updating, deletes all super keys, appends params' pairs, increments the version, and clears #updating — so a replace triggered from the URL's own href/search setters does not write back to the URL.

calls: [url-js-svelteurl-and-helpers](r1-reactive-collections.md#u-179058c594bc)

**Uncertainties.**

- The graph cannot resolve super.append/delete/keys/etc. calls; they are read here as URLSearchParams base-class invocations, which the extends clause supports.
- Whether [Symbol.iterator] forwards reactive get tracking identically to direct entries() use is not separately observable; it literally returns this.entries().

<a id="u-1f6c2b2fc560"></a>
### `packages/svelte/src/reactivity/media-query.js:MediaQuery`

`class MediaQuery extends ReactiveValue` · [packages/svelte/src/reactivity/media-query.js:L37-L42][f3]

Media query wrapper extending ReactiveValue<boolean> whose `current` reflects whether a media query matches, updating on change via a 'change' listener registered through on().

The constructor normalizes the query: if it already contains a parenthesized group (parenthesis_regex) or if every whitespace/comma-separated token is one of the non_parenthesized_keywords ('all','print','screen','and','or','not','only'), it is used verbatim; otherwise it is wrapped in parentheses. It then calls window.matchMedia and passes super a reader of q.matches and an update subscription on(q, 'change'). window.matchMedia on 'random,screen' still returns true per the comment, which is why keyword-composed queries skip auto-parenthesis.

**Uncertainties.**

- Module-level keyword regex/set behavior is folded here; the class docstring's SSR caveat is documented behavior, not code in this file

<a id="u-01d3b2b1bf3b"></a>
### `index.js module code (L1–L130)`

`module_region` · [packages/svelte/src/reactivity/window/index.js:L1-L130][f4]

Module-level reactive views of window state, each a `ReactiveValue` whose getter reads the value (returning `undefined` when not `BROWSER`) and whose start function subscribes to updates, with the returned unsubscriber acting as teardown.

`scrollX`/`scrollY` subscribe to window `scroll`; `innerWidth`/`innerHeight`/`outerWidth`/`outerHeight` to `resize`; `online` subscribes to both `online` and `offline` events and unsubscribes both on teardown. `screenLeft`/`screenTop` have no event, so their start functions poll inside a self-rescheduling `requestAnimationFrame(check)` chain, comparing the cached value and calling `update()` only on change; teardown cancels the pending frame.

calls: [../../events/index.js](../../catalog.json); uses: [../reactive-value.js](../../catalog.json)

**Uncertainties.**

- screenLeft/screenTop polling runs continuously while subscribed; no throttling beyond rAF is visible

<a id="u-c22347eadbab"></a>
### `DevicePixelRatio`

`class DevicePixelRatio` · [packages/svelte/src/reactivity/window/index.js:L131-L134][f4]

Immediately-instantiated class backing the `devicePixelRatio` reactive export.

A private `#dpr` source holds the initial `window.devicePixelRatio` (or `undefined` off-browser). `#update` subscribes via `on` to a `change` event on a media query matched to the current dppx; when it fires it sets `#dpr` to the new value, unsubscribes, and recurses to re-arm against the new resolution — handling dpr changes that invalidate the old query. The constructor calls `#update` only when `BROWSER` and, in `DEV`, tags the source for tracing. The `current` getter reads the source (registering the dependency) and returns `window.devicePixelRatio` on the browser, `undefined` otherwise; docstrings note browser differences (Chrome reflects zoom, Firefox/Safari do not).

calls: [../../internal/client/reactivity/sources.js](../../catalog.json), [../../events/index.js](../../catalog.json), [../../internal/client/dev/tracing.js](../../catalog.json), [../../internal/client/index.js](../../catalog.json)

**Uncertainties.**

- Whether a getter read outside an effect still arms a listener is governed by `on`/`get` internals, not visible here

<a id="u-49382b15058b"></a>
### `toStore`

`export function toStore(get, set)` · [packages/svelte/src/store/index-client.js:L47-L93][f5]

Client-side `toStore`: wraps a getter (and optional setter) in a store whose subscribe behavior is reactive.

It captures `active_effect`/`active_reaction` at creation time, reads the initial value, and creates a `writable` whose start notifier records whether the underlying value already changed before the first subscriber (`ran = init_value !== get()`). On first subscribe it temporarily restores the captured reaction/effect, creates an `effect_root` containing a `render_effect` that reads the getter and pushes new values into the store (skipping the first run when `ran` was false), restoring prior reaction/effect in a `finally`; the effect root's teardown is returned as the store's stop notifier. If a `set` was supplied the result is a Writable-shaped object delegating `update` to `set(fn(get()))`; otherwise a Readable-shaped object. Re-exported `derived`, `get`, `readable`, `readonly`, `writable` come from the shared module.

calls: [./shared/index.js](../../catalog.json), [../internal/client/reactivity/effects.js](../../catalog.json), [../internal/client/runtime.js](../../catalog.json); uses: [create-subscriber](../../catalog.json)

**Uncertainties.**

- The TODO comment questions whether a different server implementation is needed; client behavior on SSR is not settled in this file

<a id="u-706099be4040"></a>
### `fromStore`

`export function fromStore(store)` · [packages/svelte/src/store/index-client.js:L128-L144][f5]

Client-side `fromStore`: converts a store into an object with a reactive `current` property.

It builds `subscribe` via `createSubscriber`, whose start function subscribes to the store, caching each delivered value and calling `update()` on changes after the first delivery (`ran` flag); the store unsubscribe is returned as stop. The `current` getter checks `effect_tracking()`: inside a reactive effect it invokes `subscribe()` (starting the store subscription if needed) and returns the cached value; outside tracking it falls back to `get(store)`. If the store has a `set` property the returned object also has a `set current(v)` that calls `store.set(v)`, making it writable; otherwise `current` is read-only.

calls: [create-subscriber](../../catalog.json), [./shared/index.js](../../catalog.json), [../internal/client/reactivity/effects.js](../../catalog.json)

**Uncertainties.**

- The `'set' in store` check distinguishes Writable; a Readable object that happens to define a `set` property would be misclassified

<a id="u-4e96c589c3f1"></a>
### `map-test-ts-map-test-ts`

`group` · [packages/svelte/src/reactivity/map.test.ts:L1-L240][f6]

Vitest suite for SvelteMap.

Tests drive size/has/values in render effects across delete/clear/set mutations, verify get/has dependency changes for deleted and re-added keys, check forEach receives native arguments and thisArg, check delete's boolean return, exercise maps storing undefined values (version tracking keeps deletion and re-insertion reactive), verify no spurious effect firings when a value leaves and re-enters the map, and assert instanceof Map.

uses: [map-js-sveltemap](r1-reactive-collections.md#u-a8d1fced426f)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/reactivity/create-subscriber.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/reactivity/url-search-params.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/reactivity/media-query.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/reactivity/window/index.js
[f5]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/store/index-client.js
[f6]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/reactivity/map.test.ts
