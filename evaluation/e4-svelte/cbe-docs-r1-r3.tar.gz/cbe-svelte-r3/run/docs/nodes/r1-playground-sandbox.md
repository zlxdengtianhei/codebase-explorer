# Playground Sandbox

**Capability.** Sandbox tooling: downloading a playground app into src/ from a hash payload or API id, gzip+base64url payload compression and shareable URL generation, shared SSR runtime polyfills (Promise.withResolvers, delayed), and a dev SSR server rendering App.svelte through Vite middleware and svelte/server.

Use when the sandbox build, share-link hashing, or the dev SSR entry misbehaves; ssr-dev loads and renders App.svelte on demand.

**Depends on.**

- [Client Transform](r1-client-transform.md) · graph-confirmed · 2 edge(s)

Parent: [Repository Tooling](r1-tooling.md)

## Units (6)

<a id="u-3a2d44014938"></a>
### `download.js module code (L1–L52)`

`module_region` · [playgrounds/sandbox/scripts/download.js:L1-L52][f1]

Downloads a Svelte playground app from a URL argument and writes its files into src/, decoding either a hash payload or the API by id.

**Notes.**

- failure: Invalid URL or non-svelte.dev /playground/ URL exits with process.exit(1) after logging an error.
- condition: With a hash longer than 1, base64url-decoded gzipped JSON is decompressed via DecompressionStream and parsed for files; otherwise the API endpoint is fetched and components are mapped to file entries.
- failure: No fetch/response error handling is present; network or parse failures propagate unhandled.

<a id="u-515b35e99b78"></a>
### `compress`

`async function compress(payload)` · [playgrounds/sandbox/scripts/hash.js:L22-L42][f2]

Gzip-compresses a payload and returns a base64url string, converting bytes one at a time to a binary-safe string before btoa.

**Notes.**

- failure: Bytes are appended via String.fromCharCode individually because UTF-8 decoding would make btoa reject the string.

<a id="u-e8f1b39d4f70"></a>
### `hash.js module code (L1–L21)`

`module_region` · [playgrounds/sandbox/scripts/hash.js:L1-L21][f2]

Builds a playground payload from all files directly in src/ (skipping directories) and prints a shareable svelte.dev playground URL with the compressed hash.

calls: [compress](r1-playground-sandbox.md#u-515b35e99b78)

<a id="u-3f094098ef20"></a>
### `hash.js module code (L42–L45)`

`module_region` · [playgrounds/sandbox/scripts/hash.js:L42-L45][f2]

Computes the compressed payload and logs the resulting https://svelte.dev/playground/untitled#<hash> URL.

<a id="u-c9a44632b392"></a>
### `ssr-common.js module code (L1–L17)`

`module_region` · [playgrounds/sandbox/ssr-common.js:L1-L17][f3]

Installs runtime helpers used by SSR entry points: a Promise.withResolvers polyfill and a global delayed() promise utility.

**Notes.**

- condition: Promise.withResolvers is only assigned when not already defined (??=); delayed resolves v after ms (default 1000) via setTimeout.

<a id="u-00b4d70b764d"></a>
### `ssr-dev.js module code (L1–L39)`

`module_region` · [playgrounds/sandbox/ssr-dev.js:L1-L39][f4]

Dev SSR server: polka app using Vite middleware to transform index.html, load App.svelte on demand, render it with svelte/server, and respond with substituted HTML.

**Notes.**

- condition: PORT env var overrides the default '5173'; NODE_ENV is forced to 'development'.
- contract: Response replaces <!--ssr-head--> and <!--ssr-body--> placeholders, plus wraps a phone number in a tel link to guard Safari hydration.

**Uncertainties.**

- Error handling for missing index.html or failed module load is not visible; failures will propagate to the server uncaught here.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/playgrounds/sandbox/scripts/download.js
[f2]: ../../../../../../eval/svelte-be645b4/playgrounds/sandbox/scripts/hash.js
[f3]: ../../../../../../eval/svelte-be645b4/playgrounds/sandbox/ssr-common.js
[f4]: ../../../../../../eval/svelte-be645b4/playgrounds/sandbox/ssr-dev.js
