# Attachments

**Capability.** Programmatic element attachments: createAttachmentKey producing a spread-recognized Symbol key, and fromAction wrapping a Svelte 4 action function so it runs once per element as an attachment.

Use when migrating actions to attachments or building spread-based attachment objects; both functions are small public entry points.

Parent: [Public & Authoring APIs](r1-public-api.md)

## Units (2)

<a id="u-c36056169480"></a>
### `createAttachmentKey`

`export function createAttachmentKey()` · [packages/svelte/src/attachments/index.js:L30-L32][f1]

Returns a new `Symbol(ATTACHMENT_KEY)` that the spread system recognizes as an attachment when the containing object is spread onto an element, offering a programmatic alternative to `{@attach ...}`.

Each call yields a distinct symbol; no state is touched.

<a id="u-0433aefd7114"></a>
### `fromAction`

`export function fromAction(action, fn = /** @type {() => T} */ (noop))` · [packages/svelte/src/attachments/index.js:L96-L113][f1]

Wraps an action function so it can be used as an attachment: the returned attachment calls the action once per element with `fn()`'s value as the argument (defaulting `fn` to `noop`).

The initial call runs inside `untrack`, and its optional `update`/`destroy` return members are destructured; a missing return is normalized to `{}` via `?? {}`. If `update` exists, a `render_effect` re-invokes `update(fn())` on subsequent changes — the first run is suppressed by the `ran` flag set after setup, mirroring action semantics where `update` is not called initially. If `destroy` exists it is registered via `teardown` so it runs when the attachment is removed. `fn` is re-evaluated both at setup and inside the effect, so callers must pass a getter, not a value.

**Notes.**

- contract: The second parameter must be a function returning the action argument, not the argument itself.

imports: [../index-client.js](../../catalog.json), [svelte/internal/client](../../catalog.json); calls: [teardown](../../catalog.json)

**Uncertainties.**

- Whether errors thrown by the action during the untracked setup call are caught anywhere is not visible here; they propagate

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/attachments/index.js
