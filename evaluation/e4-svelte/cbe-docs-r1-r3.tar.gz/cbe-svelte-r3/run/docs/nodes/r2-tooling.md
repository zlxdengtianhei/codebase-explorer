# Tooling & Benchmarks

**Capability.** Developer infrastructure around the library: generated warning-message code from message templates, reactivity micro-benchmarks, the sandbox playground that compiles and serves a test app, and repo config.

Use this subtree when touching build/generation scripts or measuring performance. process-messages expands templates into source files; the sandbox compiles client and server outputs; benchmarks exercise the internal runtime directly.

**Children.**

- [Warning Message Codegen](r2-message-codegen.md) `r2-message-codegen` · 4 unit(s)
- [Reactivity Benchmarks](r2-benchmarks.md) `r2-benchmarks` · 3 unit(s)
- [Sandbox Playground](r2-playgrounds.md) `r2-playgrounds` · 8 unit(s)

Parent: [Svelte Codebase](r2-svelte-codebase.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
