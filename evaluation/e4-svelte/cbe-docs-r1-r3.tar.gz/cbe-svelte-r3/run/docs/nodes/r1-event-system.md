# Event System & Delegation

**Capability.** Attaches DOM event listeners integrated with Svelte's delegation system: create_event/on/event registration, the root-level handle_event_propagation walk over composedPath, delegate registration of event names, handler thunk application, and replay of SSR-captured events during hydration.

Use when event handlers do not fire, fire twice, or hydration replay misbehaves. create_event is the common attachment path; handle_event_propagation implements the delegated walk.

**Depends on.**

- [DOM Template Blocks](r1-dom-blocks.md) · model-inferred · 0 edge(s)
- [Task Scheduling](r1-task-scheduling.md) · graph-confirmed · 1 edge(s)

**Depended on by.**

- [Legacy Client Compatibility](r1-legacy-compat-client.md) · graph-confirmed · 2 edge(s)

Parent: [Client Runtime](r1-client-runtime.md)

## Units (7)

<a id="u-26b31b85b822"></a>
### `events.js-create-event`

`export function create_event(event_name, dom, handler, options = {})` · [packages/svelte/src/internal/client/dom/elements/events.js:L50-L54][f1]

Attaches a DOM event listener that integrates with Svelte's delegation system and returns the handler for later removal.

The inner target_handler: if the options are not capture-phase, it calls handle_event_propagation (bound to the element) so delegated listeners on ancestors run in correct order; then, unless the event's cancelBubble was set by that propagation, it invokes the user handler through without_reactive_context so the handler never runs inside an active reaction. For pointer/touch/wheel event names the actual addEventListener is deferred via queue_micro_task, working around a Chrome bug where such listeners fail on cloned, disconnected elements; other events attach synchronously. Default options is {}. The returned target_handler can be passed to removeEventListener.

calls: [events.js-handle-event-propagation](r1-event-system.md#u-25d3988473a0), [without_reactive_context](r2-dom-elements.md#u-ff3a57d1f4f9), [task-js-queues](r1-task-scheduling.md#u-08b6b6ebaf85)

<a id="u-25d3988473a0"></a>
### `events.js-handle-event-propagation`

`export function handle_event_propagation(event)` · [packages/svelte/src/internal/client/dom/elements/events.js:L156-L217][f1]

Implements Svelte's event delegation walk: called with `this` bound to the element (or document/window) that has the root listener, it walks the event's composedPath from the target upward, invoking the delegated handler stored as element['__' + eventName].

It stores the event in last_propagated_event (a module-level reference preventing Firefox GC of the event's __root expando between microtasks) and reads event.__root to skip parts of the path already handled: if a document/window listener sees the event already handled below it, it records __root = handler_element and returns; a handler not present in the path returns too; otherwise the walk resumes at the earlier of the handled index and the handler's index. If the current target equals the handler element it returns (that target's event was already handled or has no delegated listener). Before walking it defines a configurable currentTarget getter on the event returning the walking target (or ownerDocument), and nulls active_reaction/active_effect so handlers run outside any reaction/effect context, restoring them in finally. In the loop, each target's '__name' handler is invoked — arrays are applied as [fn, ...data], other values called — unless the target is disabled and the event's original target differs. Handler errors: the first is retained as throw_error, subsequent ones queued to throw individually via queueMicrotask; after the walk, throw_error is rethrown. finally sets event.__root = handler_element, deletes the currentTarget proxy, and restores the previous reaction and effect. cancelBubble or reaching the handler element or a null parent ends the walk.

calls: [runtime-js-state-and-helpers](r2-reactivity-core.md#u-6cd2387802ec)

**Uncertainties.**

- The currentTarget proxy is deleted in finally; behavior for handlers reading currentTarget asynchronously is not covered by visible code.

<a id="u-a97020bcbb33"></a>
### `event`

`export function event(event_name, dom, handler, capture, passive)` · [packages/svelte/src/internal/client/dom/elements/events.js:L111-L128][f1]

Attaches an event handler built by create_event with {capture, passive} options, registering a teardown-based removal only for special targets: document.body, window, document, or any HTMLMediaElement (the latter because Firefox can still emit canplay after removal).

For all other elements no removal is registered here, since element removal handles cleanup.

calls: [teardown](r4-runtime-effects.md#u-afcffe6190df), [events.js-create-event](r1-event-system.md#u-26b31b85b822)

<a id="u-d8e90951de4c"></a>
### `packages/svelte/src/internal/client/dom/elements/events.js:on`

`export function on(element, type, handler, options = {})` · [packages/svelte/src/internal/client/dom/elements/events.js:L95-L101][f1]

Attaches an event handler via create_event and returns a removal function that calls removeEventListener with the same type, handler, and options.

Using this instead of raw addEventListener keeps ordering correct relative to declaratively delegated handlers.

calls: [events.js-create-event](r1-event-system.md#u-26b31b85b822)

<a id="u-132e2aed8e9d"></a>
### `apply`

`export function apply( thunk, element, args, component, loc, has_side_effects = false…` · [packages/svelte/src/internal/client/dom/elements/events.js:L310-L343][f1]

Invokes a compiled event-handler thunk and applies its result to the element, with a dev-time validity check.

The thunk is called inside try/catch: a thrown error is captured and the handler stays undefined. If the resolved handler is not a function and (has_side_effects, or the handler is non-null, or an error occurred), it builds a warning describing the event name plus capture phase, the component filename with optional loc line/column, suggests removing the trailing `()` or adding a leading `() =>` based on remove_parens, emits it via w.event_handler_invalid, and rethrows any captured error. Finally handler?.apply(element, args) runs a valid handler.

imports: [events.js module code (L1–L25)][f1]

<a id="u-cf26b665744a"></a>
### `delegate`

`export function delegate(events)` · [packages/svelte/src/internal/client/dom/elements/events.js:L134-L142][f1]

Registers event names for the root-level delegation mechanism: it adds each name to all_registered_events and notifies every handle in root_event_handles by calling it with the events array.

Actual root listener installation is done by the registered handles, which live outside this file.

<a id="u-25eff3cd7825"></a>
### `replay_events`

`export function replay_events(dom)` · [packages/svelte/src/internal/client/dom/elements/events.js:L26-L42][f1]

Replays SSR-captured load/error events during hydration.

It returns immediately if not hydrating. Otherwise it removes the onload/onerror attributes SSR added, reads a captured event from the dom.__e expando, clears it, and in a microtask re-dispatches the event on the element only if it is still connected to the document.

uses: [hydration.js module code (L1–L19)][f2]

**Uncertainties.**

- dom.__e is written by SSR/hydration code outside this file; its producer is not verified here.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/elements/events.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/hydration.js
