# Migration Template Visitors

**Capability.** Rewrites template markup: on: directives become event attributes, slot/let usage becomes snippets, <slot>/<svelte:component>/<svelte:self>/<svelte:element> are modernized, plus small trivial visitors.

Each method migrates one element kind; shared rewrites live in handle_events, migrate_slot_usage, and trim_block. These helpers are called from multiple element visitors in this node.

**Depends on.**

- [Migration Driver and Helpers](r3-migrate-entry.md) · graph-confirmed · 1 edge(s)
- [Migration Script Visitors](r3-migrate-script-visitors.md) · graph-confirmed · 1 edge(s) · template visitors call handle_identifier owned by the script visitors during the shared migration walk.
- [Shared Predicates and Hash](r3-shared-utils.md) · graph-confirmed · 3 edge(s)

Parent: [Svelte 4 to 5 Migration](r3-migration.md)

## Units (9)

<a id="u-cb87d88ba279"></a>
### `index-js-trivial-template-visitors`

`const template = { Identifier(node, { state, path })` · [packages/svelte/src/compiler/migrate/index.js:L1056-L1059][f1]

Small template visitors.

`Identifier` forwards to handle_identifier; `SvelteFragment`, `Component`, and `SvelteFragment`-style slots call migrate_slot_usage (SvelteFragment and Component then call next(); Component visits children first). `SvelteWindow`, `SvelteBody`, and `SvelteDocument` only run handle_events to convert on: directives, then continue. `Comment` migrates `svelte-ignore` HTML comments via migrate_svelte_ignore, overwriting the inner comment text when changed. `HtmlTag` and `ConstTag` call trim_block over the tag range. `IfBlock` and `KeyBlock` trim the whitespace after the opening tag's closing brace (found after the test/expression). `AwaitBlock` additionally trims each branch separately: the main block after the pending/expression end, and, when present, the pending block around `value` and the catch block around `error`, each located by scanning back/forward for braces; all then continue the walk.

calls: [migrate_svelte_ignore](r2-compiler-foundations.md#u-22cdd6c7c71c), [handle_events](r3-migrate-template-visitors.md#u-11d2b2cd1c0c), [migrate_slot_usage](r3-migrate-template-visitors.md#u-4d888e7e32a9), [trim_block](r3-migrate-template-visitors.md#u-cad9e2b4a6a0)

<a id="u-447477721877"></a>
### `RegularElement`

`RegularElement(node, { state, path, next })` · [packages/svelte/src/compiler/migrate/index.js:L1060-L1073][f1]

Migrates slot usage and events on regular elements and converts self-closing syntax to explicit close tags.

After migrate_slot_usage and handle_events, the node name is stripped of any leading namespace prefix (`svg:` etc.). If the source two characters before the element's end are `/>` and the (de-namespaced) name is neither a void nor an SVG element, the slash (plus preceding spaces) is removed and an explicit `</name>` is appended after the element, since Svelte 5 no longer accepts self-closing non-void non-SVG elements.

calls: [utils-js-predicates](r3-shared-utils.md#u-7eb274f609ad), [migrate_slot_usage](r3-migrate-template-visitors.md#u-4d888e7e32a9), [handle_events](r3-migrate-template-visitors.md#u-11d2b2cd1c0c)

<a id="u-6be75180ef05"></a>
### `SlotElement`

`SlotElement(node, { state, path, next, visit })` · [packages/svelte/src/compiler/migrate/index.js:L1226-L1364][f1]

Converts `<slot>` elements into snippet rendering.

After migrate_slot_usage it bails for custom elements. It accumulates slot props: SpreadAttributes contribute their expression text; the `name` attribute sets slot_name (skipped for `slot` attributes); if an ancestor component/element/fragment — or the slot element itself — carries a `slot` attribute with the same text value, the slot is aliased to `<name>_render` and registered in derived_conflicting_slots so the derived snippet won't shadow the slot prop. Other attributes become props: valueless attributes yield `true`, text/expression values are visited (so expressions are migrated) and snipped, emitted as `value` alone when equal to the attribute name or `name: value` otherwise, joined into `{ ... }` (empty becomes no props). The rendered name reuses an existing prop with the same slot_name; otherwise the name is generated from the slot name and, if generation would rename it, a MigrationError is thrown; a new prop is pushed typed `import('svelte').Snippet<[any]>` or plain `Snippet` (an existing prop flagged needs_refine_type gets its type refined instead). A default slot inside a component chain using `let:` directives is likewise aliased to `<name>_render`. Rendering: with content, the region before the fragment becomes `{#if name}{@render name(props)}{:else}` and the region after becomes `{/if}` (prefixing the render target with the props object when the analysis uses $$props); without content it becomes `{@render name?.(props)}.`

calls: [ast-js-attribute-helpers](r4-compiler-ast-utils.md#u-e05972fa52ab); raises: [MigrationError](r3-migrate-entry.md#u-18abcf9a9523)

<a id="u-e57c073bc997"></a>
### `SvelteComponent`

`SvelteComponent(node, { state, next, path })` · [packages/svelte/src/compiler/migrate/index.js:L1140-L1209][f1]

Converts `<svelte:component this={X}>` to a dynamic `<X>` element.

After children are visited and slots migrated, the `this` expression is snipped; if it is not an Identifier or MemberExpression matching regex_valid_component_name, a new name `SvelteComponent<n>` is generated and bound either by inserting `{@const name = expr}` at the start of the nearest enclosing EachBlock/AwaitBlock/IfBlock/SnippetBlock/Component/SvelteComponent ancestor (searching backwards through the path, using the first subsequent node with a start position as insertion point and its line's indentation) or, when no such ancestor exists, as a `const name = $derived(expr)` recorded in state.derived_components (reusing an existing entry for the same expression). The open tag name is overwritten with the expression, the close tag is overwritten too when its text matches the original name, and the `this=` prefix (located by scanning back from the expression over whitespace) through the closing `}` is removed.

**Uncertainties.**

- The `this_pos` backscan assumes the nearest preceding `this` belongs to this component's attribute; interleaved `this` tokens could mislocate it

<a id="u-382ccc84af17"></a>
### `SvelteElement`

`SvelteElement(node, { state, path, next })` · [packages/svelte/src/compiler/migrate/index.js:L1111-L1135][f1]

Migrates slot usage and events on `<svelte:element>`, and makes a static string `tag` attribute dynamic.

For a Literal tag it scans backwards from the tag's start for `=`; if a `{` is encountered first the tag is already dynamic. When the tag is a static quoted string (quote mark present immediately after the tag end), it wraps the attribute value in `{`/`}` so the expression form is used, which is required for dynamic element tags after migration.

calls: [migrate_slot_usage](r3-migrate-template-visitors.md#u-4d888e7e32a9), [handle_events](r3-migrate-template-visitors.md#u-11d2b2cd1c0c)

<a id="u-5adc2dc68abc"></a>
### `SvelteSelf`

`SvelteSelf(node, { state, next })` · [packages/svelte/src/compiler/migrate/index.js:L1074-L1110][f1]

Replaces `<svelte:self>` with a self-import of the component.

Without a filename it cannot build a valid import, so it prepends a `@migration-task` comment (flagging the module-level task state via has_migration_task), guesses indentation from the tag source, and continues. With a filename it overwrites the tag name with the analysis name in the open tag; if the node has a fragment it also rewrites the matching close tag (last `<` before the node end), and when there is no fragment but the source ends with `</svelte:self>` it rewrites that close tag as well (covering `<svelte:self></svelte:self>`). Finally it sets `state.has_svelte_self` so migrate emits the self-import.

**Notes.**

- side_effect: Sets the module-level has_migration_task flag when no filename is available.

<a id="u-11d2b2cd1c0c"></a>
### `handle_events`

`function handle_events(element, state)` · [packages/svelte/src/compiler/migrate/index.js:L1723-L1810][f1]

Rewrites `on:event` directives into Svelte 5 event attributes, preserving Svelte 4 modifier semantics.

Directives are grouped by `on<event>` (plus a `capture` suffix when the capture modifier is present). Each handler body is the expression's source text, or, for expression-less directives, a `<bubble>('<event>')` call that also registers `createBubbler` in legacy_imports and a `const bubble = createBubbler();` script insertion. Modifier helpers are applied around the body in the fixed modifier_order (preventDefault, stopPropagation, stopImmediatePropagation, self, trusted, once), each added to legacy_imports. A `passive`/`nonpassive` directive cannot become a plain attribute: the whole attribute is overwritten with a `use:<passive|nonpassive={['event', () => body]}>` action and the corresponding legacy import is added. Among multiple same-event directives the first is kept and later ones are removed along with preceding whitespace; the kept attribute is overwritten with the single handler (`on:event={body}`, or shorthand `{body}` when the body text equals the attribute name) or, for several handlers, `on:event={handlers(h1, h2, ...)}` with the `handlers` legacy import.

uses: [MigrationError](r3-migrate-entry.md#u-18abcf9a9523)

<a id="u-4d888e7e32a9"></a>
### `migrate_slot_usage`

`function migrate_slot_usage(node, path, state)` · [packages/svelte/src/compiler/migrate/index.js:L1418-L1580][f1]

Converts slot/let component usage into snippets.

It only acts when the node itself or its parent (path.at(-2)) is a Component or SvelteComponent; everything else returns untouched. It reads the node's `slot` text attribute to name the target snippet ('default' maps to 'children'); if the name is not a valid identifier or is reserved, a `@migration-task` comment is prepended (flagging has_migration_task) and the function returns without removing anything. If the name would shadow an Attribute or BindDirective on the parent component, it likewise bails with a migration-task comment. Let-directives are collected (name plus optional expression text) into a removal queue that is only flushed once a valid name was found — so a bail keeps the lets — and the `slot` attribute is removed. For SvelteFragment with content, the fragment tags themselves are removed, keeping the children. For the implicit children slot (non-SvelteFragment) with lets present, default-slot content inside the fragment is located, reordering is handled when named-slot content sits between two runs of default content (the fragment node in between is moved back before the first named slot), and the default content is wrapped in `{#snippet children(...)}` with re-indentation; the closing `{/snippet}` is placed before any named slots that follow, or at the end otherwise. Named slots or svelte:fragment wrap the node itself in `{#snippet name(...)}` ... `{/snippet}` with matching indentation (appended via appendRight for SlotElement, appendLeft otherwise).

**Notes.**

- failure: Invalid or shadowing slot names leave the original markup in place plus a migration-task comment, deferring to manual migration.

calls: [ast-js-attribute-helpers](r4-compiler-ast-utils.md#u-e05972fa52ab), [utils-js-predicates](r3-shared-utils.md#u-7eb274f609ad)

<a id="u-cad9e2b4a6a0"></a>
### `trim_block`

`function trim_block(state, start, end)` · [packages/svelte/src/compiler/migrate/index.js:L1047-L1053][f1]

Normalizes whitespace inside a brace/paren-delimited range: it snips the text, drops the first and last characters, and if the interior had leading or trailing whitespace that trimming removes, updates the range interior with the trimmed text; otherwise the source is left unchanged.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/migrate/index.js
