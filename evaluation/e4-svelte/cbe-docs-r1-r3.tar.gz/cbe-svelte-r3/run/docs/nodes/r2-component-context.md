# Component Context

**Capability.** Component-scope push/pop, the context API (setContext/getContext/hasContext/getAllContexts) over lazily created parent-chained context maps, and dev-mode bookkeeping (dev stack, current component function, rune-mode detection).

Use this subtree to trace how a component enters/leaves its scope and how context lookups walk the parent chain. push/pop and set_component_context feed update_reaction's rune-mode check, so this module sits under the reactivity cycle's feet.

**Depends on.**

- [Reactivity Core & Batching](r2-reactivity-core.md) · model-inferred · 0 edge(s)

**Depended on by.**

- [Each Block Runtime](r2-dom-blocks.md) · model-inferred · 0 edge(s)
- [Reactivity Core & Batching](r2-reactivity-core.md) · graph-confirmed · 7 edge(s)
- [DOM Template Blocks](r1-dom-blocks.md) · graph-only · 9 edge(s)

Parent: [Client Runtime](r2-client-runtime.md)

## Units (13)

<a id="u-9761c5d7c2ee"></a>
### `push`

`export function push(props, runes = false, fn)` · [packages/svelte/src/internal/client/context.js:L145-L160][f1]

Enters a new component scope by replacing component_context with a fresh context object linked to the previous one via p.

The new context starts with null context map, deferred effects, and exports; it carries props in s, and when legacy_mode_flag is set and runes is false it gets an l object holding null signals and update callbacks plus an empty $: array (runes defaults to false). In DEV it also stores fn as the context's function property and sets dev_current_component_function to fn.

uses: [set_dev_current_component_function](r2-component-context.md#u-1de56d41fa38)

<a id="u-fe159451466a"></a>
### `pop`

`export function pop(component)` · [packages/svelte/src/internal/client/context.js:L167-L190][f1]

Leaves the current component scope: it first flushes deferred effects, then restores the parent context.

It reads context.e; when non-null it clears the array and calls create_user_effect(fn) for each deferred function, so those effects are created at scope exit rather than immediately. If component is provided it is stored as the context's exports (x). component_context is then set to context.p, and in DEV dev_current_component_function is restored from the parent context's function, or null when there is no parent. It returns component, or an empty object when component is undefined.

calls: [create_user_effect](r4-runtime-effects.md#u-034bebae7dc6); uses: [set_dev_current_component_function](r2-component-context.md#u-1de56d41fa38)

**Uncertainties.**

- Whether the empty-object fallback return shape matters to callers is not shown in this file

<a id="u-4155baf87729"></a>
### `set_component_context`

`export function set_component_context(context)` · [packages/svelte/src/internal/client/context.js:L14-L16][f1]

Assigns the module-level component_context variable to the supplied ComponentContext-or-null value, letting callers enter or leave a component scope.

<a id="u-71aba13a168a"></a>
### `is_runes`

`export function is_runes()` · [packages/svelte/src/internal/client/context.js:L193-L195][f1]

Reports whether the current scope uses rune mode: true whenever legacy_mode_flag is off, or when component_context is non-null and its l slot is null (push only allocates l in legacy mode without runes).

When the legacy flag is set and component_context is null it returns false.

<a id="u-64fe4521bdfe"></a>
### `setContext`

`export function setContext(key, context)` · [packages/svelte/src/internal/client/context.js:L98-L112][f1]

Stores context under key on the current component's context map and returns the same value.

In async mode it enforces an initialization-time-only rule: it reads the active effect's flags and calls e.set_context_after_init() (which throws) unless there is no active reaction, the effect has the BRANCH_EFFECT flag, and EFFECT_RAN is clear. Outside async mode no timing check happens and the value is stored unconditionally.

**Notes.**

- failure: In async mode, calling setContext after the branch effect has run, or while a reaction is active, throws the set_context_after_init error instead of storing the value.

calls: [get_or_init_context_map](r2-component-context.md#u-99872e9939fa)

<a id="u-abbef1c88791"></a>
### `getContext`

`export function getContext(key)` · [packages/svelte/src/internal/client/context.js:L80-L84][f1]

Returns the context value stored under key by the nearest parent component, or undefined if the key is unset.

It fetches the component's context map via get_or_init_context_map('getContext'), which throws the lifecycle error when no component context is active; the map is lazily seeded from the closest ancestor that already has one.

calls: [get_or_init_context_map](r2-component-context.md#u-99872e9939fa)

**Uncertainties.**

- Undefined for a missing key is inferred from Map.get, not from an explicit branch

<a id="u-3341dee08c97"></a>
### `hasContext`

`export function hasContext(key)` · [packages/svelte/src/internal/client/context.js:L121-L124][f1]

Returns whether key exists in the current component's context map, via get_or_init_context_map('hasContext'); throws the lifecycle error when called outside component initialization.

calls: [get_or_init_context_map](r2-component-context.md#u-99872e9939fa)

<a id="u-c05aabfae0d1"></a>
### `getAllContexts`

`export function getAllContexts()` · [packages/svelte/src/internal/client/context.js:L134-L137][f1]

Returns the whole context Map of the current component, obtained via get_or_init_context_map('getAllContexts'); throws the lifecycle error outside component initialization.

calls: [get_or_init_context_map](r2-component-context.md#u-99872e9939fa)

<a id="u-99872e9939fa"></a>
### `get_or_init_context_map`

`function get_or_init_context_map(name)` · [packages/svelte/src/internal/client/context.js:L201-L207][f1]

Returns the current component's context Map, creating it on first use.

If component_context is null it throws e.lifecycle_outside_component(name), naming the calling API (getContext, setContext, etc.). Otherwise it lazily assigns component_context.c with a new Map seeded from get_parent_context(component_context), so the component starts with a copy of the nearest ancestor's entries; the seed is undefined when no ancestor has a map, yielding an empty Map.

calls: [get_parent_context](r2-component-context.md#u-3b276f9d9206)

<a id="u-3b276f9d9206"></a>
### `get_parent_context`

`function get_parent_context(component_context)` · [packages/svelte/src/internal/client/context.js:L213-L223][f1]

Walks the p parent chain of a ComponentContext and returns the first non-null c context map found; returns null when no ancestor provides one.

<a id="u-946a777d9545"></a>
### `set_dev_stack`

`export function set_dev_stack(stack)` · [packages/svelte/src/internal/client/context.js:L22-L24][f1]

Assigns the module-level dev_stack variable to the supplied DevStackEntry-or-null value; development-mode bookkeeping only.

<a id="u-1de56d41fa38"></a>
### `set_dev_current_component_function`

`export function set_dev_current_component_function(fn)` · [packages/svelte/src/internal/client/context.js:L68-L70][f1]

Assigns the module-level dev_current_component_function variable to the given component function; development-mode bookkeeping only.

<a id="u-19355b3b3598"></a>
### `packages/svelte/src/internal/client/context.js:add_svelte_meta`

`export function add_svelte_meta(callback, type, component, line, column, additional)` · [packages/svelte/src/internal/client/context.js:L36-L53][f1]

Runs a callback with a temporary dev_stack entry describing a block or component location.

The entry records type, file (read from component[FILENAME]), line, column, the previous stack as parent, then spreads additional on top, so additional can override the base fields. The previous dev_stack is restored in a finally block even when the callback throws, and the callback's return value is returned unchanged.

uses: [set_dev_stack](r2-component-context.md#u-946a777d9545)

**Uncertainties.**

- Whether callers rely on the additional spread overriding base fields is not visible in this file

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/context.js
