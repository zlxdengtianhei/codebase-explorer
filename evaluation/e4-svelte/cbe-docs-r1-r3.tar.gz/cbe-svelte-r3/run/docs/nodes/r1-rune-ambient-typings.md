# Rune Ambient Typings

**Capability.** Ambient declarations of the compiler-recognized runes ($state, $derived, $effect, $props, $bindable, $inspect, $host) and the '*.svelte' module declaration — these are type shapes the compiler recognizes, not runtime implementations.

Consult for the accepted call signatures of each rune in user code; behavior lives in the compiler and runtime, not here.

Parent: [Public & Authoring APIs](r1-public-api.md)

## Units (8)

<a id="u-f90a1ae6e00e"></a>
### `ambient-dts-state`

`declare function $state<T>(initial: T): T;` · [packages/svelte/src/ambient.d.ts:L23-L23][f1]

Ambient declarations for the $state rune: the callable overloads return T for `($state(initial))` and `T | undefined` for the no-argument form; these are compiler-recognized shapes, not runtime functions implemented here.

The $state namespace supplies the type vocabulary: Primitive (string/number/boolean/null/undefined), TypedArray (all eleven typed-array variants), Cloneable (everything structuredClone handles per the referenced MDN definition), and NonReactive<T>, a conditional that maps Date/Map/Set (inferred element types via `infer`) back to their plain counterparts. Snapshot<T> computes the static-snapshot type through ordered conditionals: primitives pass through; Cloneable values map through NonReactive; values with a `toJSON(): infer R` member map to R; arrays map element-wise via Snapshot<U>; indexable objects map each property recursively; anything else resolves to never. The namespace also declares `raw<T>(initial?)` (returns the value unmodified, documented as requiring reassignment instead of mutation) and `snapshot<T>(state)` (returns a Snapshot<T>), plus deprecated never-typed constants (apply, arguments, bind, call, caller, length, name, prototype, toString) that exist only to stop IntelliSense from suggesting Function prototype members on the namespace.

**Uncertainties.**

- These are declarations only; the actual runtime behavior of $state, raw, and snapshot lives elsewhere and cannot be verified from this file.

<a id="u-f6a8e7849816"></a>
### `ambient-dts-derived`

`declare function $derived<T>(expression: T): T;` · [packages/svelte/src/ambient.d.ts:L177-L177][f1]

Ambient declarations for the $derived rune.

The callable signature `$derived<T>(expression: T): T` types an expression that recomputes when its state dependencies change; the docstring requires the expression be side-effect free. The namespace declares `by<T>(fn: () => T): T` for multi-statement derivations that do not fit one expression, plus the same set of deprecated never-typed constants that suppress IntelliSense suggestions of Function prototype members.

**Uncertainties.**

- Side-effect enforcement is documentation only; this declaration cannot enforce it.

<a id="u-c244e705899b"></a>
### `ambient-dts-effect`

`declare function $effect(fn: () => void | (() => void)): void;` · [packages/svelte/src/ambient.d.ts:L237-L237][f1]

Ambient declarations for the $effect rune family.

The root signature `$effect(fn: () => void | (() => void)): void` types code that runs after mount and re-runs after DOM updates when its $state/$derived dependencies change; a returned function acts as cleanup before the next run and on unmount, and the effect does not run during SSR. The namespace declares `pre` (same shape, runs before the DOM update), `pending(): number` (count of pending promises in the current boundary, excluding child boundaries), `tracking(): boolean` (true when running inside a tracking context such as an effect or template expression), and `root(fn): () => void` (creates a non-tracked, non-auto-cleanup scope; returns the cleanup function, which the example shows being invoked manually). Deprecated never-typed constants again suppress Function-prototype IntelliSense.

**Uncertainties.**

- Timing guarantees (post-DOM-update, pre-update, SSR skip) are stated in docstrings; no runtime source here confirms them.

<a id="u-1cdfc23ade7a"></a>
### `ambient-dts-props`

`declare function $props(): any;` · [packages/svelte/src/ambient.d.ts:L346-L346][f1]

Ambient declarations for the $props rune.

`$props(): any` types destructured component props. The namespace declares `id(): string`, which generates an identifier unique to the current component instance and consistent between server and client during hydration — useful for linking elements via `for`/`aria-labelledby` (marked @since 5.20.0). Deprecated never-typed constants suppress Function-prototype IntelliSense.

**Uncertainties.**

- The uniqueness and hydration-consistency guarantees are documentation claims; no implementation is visible here.

<a id="u-3a1a99aa3bc0"></a>
### `ambient-dts-bindable`

`declare function $bindable<T>(fallback?: T): T;` · [packages/svelte/src/ambient.d.ts:L389-L389][f1]

Ambient declaration for the $bindable rune: `$bindable<T>(fallback?: T): T` marks a destructured prop as bindable so parents can use `bind:propName={value}`; the optional argument supplies a fallback when the parent does not bind or pass a value.

The namespace contains only the deprecated never-typed constants that suppress Function-prototype IntelliSense.

**Uncertainties.**

- Fallback semantics when neither bound nor passed are documented but not implemented in this file.

<a id="u-b408804bcd0f"></a>
### `ambient-dts-inspect`

`declare function $inspect<T extends any[]>( ...values: T ): { with: (fn: (type: 'init…` · [packages/svelte/src/ambient.d.ts:L432-L434][f1]

Ambient declarations for the $inspect rune.

`$inspect<T extends any[]>(...values: T)` types a change watcher over one or more values that returns `{ with: (fn: (type: 'init' | 'update', ...values: T) => void) => void }`; by default values are logged, and `.with` replaces the handler (e.g. console.trace or a debugger statement). The namespace declares `trace(name?: string): void`, documented as reporting which reactive state changes caused an effect to re-run and required to be the first statement of the function body, plus the deprecated never-typed IntelliSense-suppressing constants.

**Uncertainties.**

- The 'must be first statement' constraint on $inspect.trace is a documented rule whose enforcement is not visible here.

<a id="u-16658cb09657"></a>
### `ambient-dts-host`

`declare function $host<El extends HTMLElement = HTMLElement>(): El;` · [packages/svelte/src/ambient.d.ts:L495-L495][f1]

Ambient declaration for the $host rune: `$host<El extends HTMLElement = HTMLElement>(): El` types access to the `this` reference of the containing custom element, documented as only available inside custom element components and only client-side; the docstring example dispatches a CustomEvent on it.

The namespace contains only the deprecated never-typed constants that suppress Function-prototype IntelliSense.

**Uncertainties.**

- Behavior outside custom element components (e.g. whether it throws) is not specified in this file.

<a id="u-87a9193cc556"></a>
### `ambient-dts-svelte-module-declaration`

`declare module '*.svelte' { // use prettier-ignore for a while because of https://git…` · [packages/svelte/src/ambient.d.ts:L1-L7][f1]

Ambient module declaration for '*.svelte' imports that types the default export of a Svelte file.

It declares `const Comp: LegacyComponentType` (imported from 'svelte/legacy') and `type Comp = SvelteComponent`, then exports Comp as the module default, so both modern function components and legacy class-style usage type-check when importing .svelte files. Purely type-level; no runtime behavior is declared here.

**Uncertainties.**

- How consumers resolve between LegacyComponentType and SvelteComponent depends on 'svelte/legacy' typings not supplied in this excerpt.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/ambient.d.ts
