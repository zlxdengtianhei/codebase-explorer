# Svelte 4 to 5 Migration

**Capability.** Best-effort automated migration of Svelte 4 source to runes, event attributes, and snippets, reusing the analysis phase and reporting unrecoverable cases via MigrationError.

migrate-entry drives the whole rewrite; script-side and template-side visitors handle their respective AST regions. Helpers like migrate_css and get_node_range support text edits across the file.

**Children.**

- [Migration Driver and Helpers](r3-migrate-entry.md) `r3-migrate-entry` · 6 unit(s)
- [Migration Script Visitors](r3-migrate-script-visitors.md) `r3-migrate-script-visitors` · 7 unit(s)
- [Migration Template Visitors](r3-migrate-template-visitors.md) `r3-migrate-template-visitors` · 9 unit(s)

Parent: [Compiler Pipeline](r3-compiler.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
