# Shared Analysis Visitors & Helpers

**Capability.** Small analysis-phase visitors and shared helpers: marking fragments dynamic, attaching function hoisting metadata, resolving snippet bindings, rejecting children on svelte special elements, tracking impure tagged templates, plus the type-only import headers of those helper modules.

Use this node for cross-cutting analysis helpers that individual template-node visitors call. The import-only groups carry no runtime behavior but document each helper module's type dependencies.

**Depends on.**

- [Compiler Warning Infrastructure](r1-compiler-diagnostics-infrastructure.md) · model-inferred · 0 edge(s)

**Depended on by.**

- [AST Analysis Visitors](r5-analyze-visitors.md) · graph-only · 11 edge(s)

Parent: [Analyze Phase](r1-compiler-analyze.md)

## Units (10)

<a id="u-7f3ea7461731"></a>
### `TransitionDirective`

`export function TransitionDirective(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/TransitionDirective.js:L10-L14][f1]

Marks the enclosing fragment subtree dynamic because a transition directive depends on runtime state, then continues traversal.

calls: [mark_subtree_dynamic](r1-analysis-visitors.md#u-3e6e9a44c2b4)

<a id="u-b2fd544bbb7e"></a>
### `TaggedTemplateExpression`

`export function TaggedTemplateExpression(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/TaggedTemplateExpression.js:L9-L16][f2]

Tracks impure tagged templates in expression state.

When the current state.expression exists and the tag is not pure (per is_pure), it sets has_call and has_state to true on that expression record, marking the surrounding expression as potentially calling and state-dependent. Traversal continues either way.

calls: [is_pure](r4-analyze-shared-validation.md#u-c8c562a3fb44)

<a id="u-3e6e9a44c2b4"></a>
### `mark_subtree_dynamic`

`export function mark_subtree_dynamic(path)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/shared/fragment.js:L6-L15][f3]

Marks every Fragment on the given path as dynamically rendered, stopping at the first already-dynamic fragment.

It walks context path backwards; for each Fragment node, if metadata.dynamic is already true it returns immediately (subtree above is already marked), otherwise it sets metadata.dynamic to true. Non-Fragment nodes are skipped. This propagates dynamism upward to all enclosing fragments so later phases know the subtree re-renders.

<a id="u-98e829315086"></a>
### `visit_function`

`export function visit_function(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/shared/function.js:L8-L31][f4]

Analyzes function-like nodes by attaching hoisting metadata and collecting cross-function references, then recursing with adjusted state.

It initializes node.metadata with hoisted false, empty hoisted_params, and the current scope. When context.state.expression is set (analysis inside a reactive expression), every scope reference whose binding lives at a shallower function_depth is added to state.expression.references, tracking which outer bindings the function captures. It then calls context.next with function_depth incremented and expression reset to null, so nested non-reactive function bodies do not accumulate reactive references. The comment notes the hoisting mechanism is a stopgap pending a binding-based solution.

uses: [visit_function](r1-analysis-visitors.md#u-98e829315086)

**Uncertainties.**

- The exact semantics of metadata.hoisted/hoisted_params consumers are elsewhere; this file only initializes them.
- Whether context.state.expression can be non-null on entry depends on callers not shown.

<a id="u-5fc246db911c"></a>
### `is_resolved_snippet`

`export function is_resolved_snippet(binding)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/shared/snippets.js:L8-L17][f5]

Decides whether a binding unambiguously identifies the snippet a component may render.

Returns true when the binding is null/undefined (external or unknown-free), is an import, is a prop, rest_prop, or bindable_prop, or its initial value is a SnippetBlock. Returns false for any other binding, meaning the caller must conservatively treat the component as rendering any local snippet. Pure predicate with no side effects.

<a id="u-43b79d8932ce"></a>
### `disallow_children`

`export function disallow_children(node)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/shared/special-element.js:L7-L16][f6]

Throws svelte_meta_invalid_content when a svelte special element (body, document, window, options) has any children.

If the fragment has nodes, it reports the error spanning from the first to the last child's positions, tagged with the element name; an empty fragment passes silently.

<a id="u-7292c8a1744c"></a>
### `fragment-js-imports`

`group` · [packages/svelte/src/compiler/phases/2-analyze/visitors/shared/fragment.js:L1-L5][f3]

Type-only JSDoc import of AST for fragment.js; no runtime behavior.

<a id="u-c131e5b5c9e0"></a>
### `function-js-imports`

`group` · [packages/svelte/src/compiler/phases/2-analyze/visitors/shared/function.js:L1-L7][f4]

Type-only JSDoc imports of estree function node types and Context for function.js; no runtime behavior.

<a id="u-cfe99217c49e"></a>
### `snippets-js-imports`

`group` · [packages/svelte/src/compiler/phases/2-analyze/visitors/shared/snippets.js:L1-L7][f5]

Type-only JSDoc import of Binding for snippets.js; no runtime behavior.

<a id="u-0589f048244c"></a>
### `special-element-js-imports`

`group` · [packages/svelte/src/compiler/phases/2-analyze/visitors/shared/special-element.js:L1-L6][f6]

JSDoc AST type import plus the errors module import used by disallow_children; no other behavior.

uses: [disallow_children](r1-analysis-visitors.md#u-43b79d8932ce)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/TransitionDirective.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/TaggedTemplateExpression.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/shared/fragment.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/shared/function.js
[f5]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/shared/snippets.js
[f6]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/shared/special-element.js
