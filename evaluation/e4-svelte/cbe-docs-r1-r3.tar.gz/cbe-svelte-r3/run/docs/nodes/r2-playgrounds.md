# Sandbox Playground

**Capability.** A local playground: run.js compiles every src module for client and server targets into output files, ssr-prod.js serves a pre-rendered production build, and vite.config.js wires the inspect/Svelte plugins against the workspace-local svelte.

Use this subtree to exercise the compiler end-to-end on sample sources. run.js owns CLI parsing, directory prep, and per-target compilation; the SSR server and Vite config consume its build output. svelte.config.js supplies the project's Svelte configuration.

**Depends on.**

- [Client Transform](r2-client-transform.md) · model-inferred · 0 edge(s)
- [Compiler Foundations](r2-compiler-foundations.md) · model-inferred · 0 edge(s)
- [Server Transform](r2-server-transform.md) · model-inferred · 0 edge(s)

Parent: [Tooling & Benchmarks](r2-tooling.md)

## Units (8)

<a id="u-2eee5a3b7690"></a>
### `run.js module code (L1–L22)`

`module_region` · [playgrounds/sandbox/run.js:L1-L22][f1]

Parses CLI args, resolves the sandbox cwd, and empties the output directory before generation.

imports: [svelte/compiler](../../catalog.json), [tinyglobby](../../catalog.json)

<a id="u-7792f9b7775b"></a>
### `mkdirp`

`function mkdirp(dir)` · [playgrounds/sandbox/run.js:L23-L27][f1]

Creates a directory (with parents) while silently swallowing any mkdir failure.

**Notes.**

- failure: Errors from fs.mkdirSync are caught and discarded, so a failed directory creation never surfaces here.

<a id="u-7e8e16bca8d0"></a>
### `playgrounds/sandbox/run.js:write`

`function write(file, contents)` · [playgrounds/sandbox/run.js:L33-L36][f1]

Writes file contents, first ensuring the parent directory exists via mkdirp.

calls: [mkdirp](r2-playgrounds.md#u-7792f9b7775b)

<a id="u-496b74260d47"></a>
### `run.js module code (L27–L32)`

`module_region` · [playgrounds/sandbox/run.js:L27-L32][f1]

Globs all .svelte and .js files under src as the generation inputs.

<a id="u-64412a345d1b"></a>
### `run.js module code (L36–L136)`

`module_region` · [playgrounds/sandbox/run.js:L36-L136][f1]

Compiles every src module for both 'client' and 'server' generate targets, writing JS, source maps, CSS, AST JSON, migrated output, and a 'tree'-fragment client variant under output/.

calls: [mkdirp](r2-playgrounds.md#u-7792f9b7775b), [playgrounds/sandbox/run.js:write](r2-playgrounds.md#u-7e8e16bca8d0)

**Uncertainties.**

- Only the migrate call for .svelte files is wrapped in try/catch; compile/compileModule failures for .js modules have no visible handler.

<a id="u-170a1c7ad4ed"></a>
### `ssr-prod.js module code (L1–L42)`

`module_region` · [playgrounds/sandbox/ssr-prod.js:L1-L42][f2]

Production SSR server: pre-renders App once at startup into the built index.html, then serves that HTML at '/' and static files from dist/client with 404 fallback.

**Notes.**

- condition: Content type comes from a .js/.css extension map, defaulting to application/octet-stream; unknown paths return 404 'not found'.
- side_effect: Static files are streamed via fs.createReadStream piped to the response.

**Uncertainties.**

- req.url is used unsanitized in path.resolve('./dist/client' + req.url); path traversal protection is not evident in this file.

<a id="u-05c7b53c4e26"></a>
### `vite.config.js module code (L1–L16)`

`module_region` · [playgrounds/sandbox/vite.config.js:L1-L16][f3]

Defines the sandbox Vite configuration: build minification disabled, inspect and Svelte plugins enabled, and workspace-local svelte excluded from dependency pre-optimization.

**Notes.**

- condition: optimizeDeps.exclude 'svelte' avoids dev-server restarts with --force on every change to the local workspace package.

<a id="u-092720d6382b"></a>
### `svelte.config.js module code (L1–L8)`

`module_region` · [svelte.config.js:L1-L8][f4]

Exports the default Svelte configuration object for this project.

It only sets compilerOptions.experimental.async to true, enabling Svelte's experimental async compilation feature; no other options, plugins, or preprocessors are configured. The leading comment indicates the file exists partly so tooling such as the VS Code extension does not flag a missing config.

**Uncertainties.**

- The runtime effect of experimental.async on compilation is defined by the Svelte compiler, not by this file; its exact behavior cannot be established from the supplied source.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/playgrounds/sandbox/run.js
[f2]: ../../../../../../eval/svelte-be645b4/playgrounds/sandbox/ssr-prod.js
[f3]: ../../../../../../eval/svelte-be645b4/playgrounds/sandbox/vite.config.js
[f4]: ../../../../../../eval/svelte-be645b4/svelte.config.js
