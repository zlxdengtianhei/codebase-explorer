# Server Dev Validation

**Capability.** Development-time SSR validation: a parent/ancestor element stack checking tag placement, once-per-message error reporting, stack snapshot/restore, and snippet-call payload validation.

Compiled server output calls push/pop_element around elements; render resets the stack per render. Errors are reported once and echoed into the payload head script.

**Depended on by.**

- [Server Render Entry](r3-server-render-entry.md) · graph-confirmed · 1 edge(s)

Parent: [Server Runtime](r3-server-runtime.md)

## Units (8)

<a id="u-52b52ceaef85"></a>
### `dev.js module code (L1–L32)`

`module_region` · [packages/svelte/src/internal/server/dev.js:L1-L32][f1]

Imports, the Element typedef, and module-level dev state (parent element stack, seen-message set).

<a id="u-73a0e82a47ce"></a>
### `print_error`

`function print_error(payload, message)` · [packages/svelte/src/internal/server/dev.js:L33-L44][f1]

Report a node-placement validation error once per message, to console and into the payload head script.

**Notes.**

- condition: A lazily created module-level seen Set deduplicates messages: subsequent identical messages are silently dropped.
- side_effect: Wraps the message with the node_invalid_placement_ssr prefix and hydration warning text, console.errors it, and injects a <script>console.error(JSON)</script> into payload.head.out.

**Uncertainties.**

- Graph evidence maps the seen Set check to client proxy 'has' methods; that mapping is not supported by the supplied source and is disregarded.

<a id="u-cc2fd0cc577f"></a>
### `reset_elements`

`export function reset_elements()` · [packages/svelte/src/internal/server/dev.js:L46-L52][f1]

Snapshot and clear the dev element stack, returning a restore function.

**Notes.**

- side_effect: Saves the current parent, sets parent to null; the returned closure reinstates the saved value, used by render to isolate nested renders.

<a id="u-4eb759f399d2"></a>
### `push_element`

`export function push_element(payload, tag, line, column)` · [packages/svelte/src/internal/server/dev.js:L60-L90][f1]

Track an element on the dev SSR stack and validate tag placement against parent and ancestors.

**Notes.**

- condition: Reads the component filename from current_component.function[FILENAME].
- condition: If parent is non-null: validates against the immediate parent with is_tag_valid_with_parent, then walks the ancestor chain pushing each tag onto the ancestors list and validating with is_tag_valid_with_ancestor; any returned message is passed to print_error, which emits it once.
- side_effect: Unconditionally sets parent to the new child element after validation.

calls: [is_tag_valid_with_parent](r4-shared-source-utilities.md#u-a93dfa56dc6d), [is_tag_valid_with_ancestor](r4-shared-source-utilities.md#u-c5a7f2f803ff), [print_error](r3-server-dev.md#u-73a0e82a47ce)

**Uncertainties.**

- Location strings are built only when the respective filename exists; consequences of missing filenames are limited to omitted location context.

<a id="u-c9f93e93e9bd"></a>
### `pop_element`

`export function pop_element()` · [packages/svelte/src/internal/server/dev.js:L92-L94][f1]

Restore the dev element stack pointer to the current element's parent.

**Uncertainties.**

- Assumes parent is non-null; an unbalanced pop would read .parent of null per the cast.

<a id="u-75d5182b7c0f"></a>
### `packages/svelte/src/internal/server/dev.js:validate_snippet_args`

`export function validate_snippet_args(payload)` · [packages/svelte/src/internal/server/dev.js:L99-L107][f1]

Validate that a snippet call received a Payload or HeadPayload, throwing otherwise.

**Notes.**

- failure: Throws via e.invalid_snippet_arguments() when payload is not an object or not an instance of Payload/HeadPayload.

<a id="u-90e8b653d454"></a>
### `dev.js module code (L52–L59)`

`module_region` · [packages/svelte/src/internal/server/dev.js:L52-L59][f1]

Non-behavioral gap between print_error and reset_elements declarations.

<a id="u-4d803ea80e60"></a>
### `dev.js module code (L94–L98)`

`module_region` · [packages/svelte/src/internal/server/dev.js:L94-L98][f1]

Non-behavioral gap between pop_element and validate_snippet_args.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/server/dev.js
