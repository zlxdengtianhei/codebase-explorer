# Reactivity Core & Batching

**Capability.** Signal reads, dependency tracking, derived dirtiness, and effect execution (runtime.js) together with the Batch machinery that groups source updates into transactions, schedules effect trees, guards against infinite loops, and supports async suspension.

Start at the runtime.js reaction cycle (get/update_reaction/update_effect/is_dirty) then read batch.js for how updates become synchronous or microtask flushes. The two modules are mutually recursive; module-state units here are the mutable spine both rely on. StaleReactionError and disclose-version are runtime satellites.

**Depends on.**

- [Component Context](r2-component-context.md) · graph-confirmed · 7 edge(s)

**Depended on by.**

- [Reactivity Benchmarks](r2-benchmarks.md) · model-inferred · 0 edge(s)
- [Component Context](r2-component-context.md) · model-inferred · 0 edge(s)
- [Each Block Runtime](r2-dom-blocks.md) · graph-confirmed · 3 edge(s) · the each block creates batches and reads reactive state through the reactivity core to coordinate keyed teardown.
- [DOM Elements](r2-dom-elements.md) · graph-confirmed · 6 edge(s)
- [Legacy Client Compatibility](r2-legacy-client.md) · graph-confirmed · 4 edge(s)
- [Reactive Primitives](r2-reactive-primitives.md) · graph-confirmed · 6 edge(s) · public primitives like createSubscriber and toStore build on the internal runtime state helpers and get.
- [Reactive Wrapper Classes](r1-reactive-collections.md) · graph-only · 26 edge(s)
- [Signal Reactivity Core](r5-client-reactivity.md) · graph-only · 22 edge(s)
- [Effect System](r4-runtime-effects.md) · graph-only · 17 edge(s)
- [Signals, Deriveds, and Proxies](r4-runtime-signals.md) · graph-only · 16 edge(s)
- [Error & Pending Boundaries](r5-client-boundary.md) · graph-only · 9 edge(s)

Parent: [Client Runtime](r2-client-runtime.md)

## Units (28)

<a id="u-6cd2387802ec"></a>
### `runtime-js-state-and-helpers`

`export function set_is_updating_effect(value)` · [packages/svelte/src/internal/client/runtime.js:L54-L56][f1]

Module-level mutable state and small helpers of the client reactivity runtime.

The set_* functions (set_is_updating_effect, set_is_destroying_effect, set_active_reaction, set_active_effect, set_untracked_writes, set_update_version) are direct assignments to exported 'let' variables that other runtime code reads to know the currently running reaction/effect, whether an effect is being updated or destroyed, pending untracked writes, and the current update version. increment_write_version pre-increments and returns write_version, the global counter used to version source writes. push_reaction_value records a value in current_sources (creating the array on first use) only when a reaction is active and, in async mode, only when that reaction is a DERIVED — this is how writes inside the owning reaction are suppressed from triggering re-runs. skip_reaction and current_sources are exported mutable flags; write_version starts at 1 so unowned deriveds can distinguish creation from a run during tracing. tick() returns a promise: in async mode it resolves on the next requestAnimationFrame; otherwise it awaits one microtask then calls flushSync() so pending state changes apply after one tick. settled() (since 5.36) returns Batch.ensure().settled(), resolving once state changes and resulting async work have settled and the DOM is updated. safe_get(signal) returns undefined for a null/undefined signal, otherwise delegates to get — used for var declarations read before assignment. untrack(fn) sets untracking to true, runs fn with reads excluded from dependency tracking, and restores the previous flag in a finally block. set_signal_status replaces only the DIRTY/MAYBE_DIRTY/CLEAN bits of signal.f via a status mask, leaving other flags intact. exclude_from_object copies all own enumerable keys of obj except those in the keys array into a fresh object and returns it.

calls: [packages/svelte/src/internal/client/runtime.js:get](r2-reactivity-core.md#u-98099fbbf12a), [runtime-js-state-and-helpers](r2-reactivity-core.md#u-6cd2387802ec); uses: [packages/svelte/src/internal/client/runtime.js:get](r2-reactivity-core.md#u-98099fbbf12a)

**Uncertainties.**

- The exact semantics of Batch.ensure().settled() live in batch.js, not shown here.

<a id="u-98099fbbf12a"></a>
### `packages/svelte/src/internal/client/runtime.js:get`

`export function get(signal)` · [packages/svelte/src/internal/client/runtime.js:L528-L682][f1]

Reads a signal's value while registering it as a dependency of the active reaction and handling derived recomputation, effect teardown, batching, and dev tracing.

With an active, un-untracked reaction and a non-destroyed active effect, the read is recorded: during a reaction update, a repeat of the same dependency in the same order only bumps skipped_deps, otherwise it appends to new_deps (de-duplicated only under skip_reaction); outside the update cycle (e.g. after an await) the signal is appended to reaction.deps and the reaction to signal.reactions. When there is no active reaction and the signal is a derived with no deps or effects, it is marked UNOWNED if its parent is not unowned. DEV-only behavior: reads inside a current async effect that were not previously tracked warn about reactivity loss with a captured stack; recent_async_deriveds entry for the signal is deleted; in tracing mode a stack trace is captured per signal (via signal.trace() or get_stack) and appended to tracing_expressions, skipping consecutive duplicates. If an effect is currently being destroyed, old_values are served: an old value for the signal is returned, and a dirty derived with reactions, or one depending on old values, is recomputed via execute_derived and cached in old_values. Otherwise a derived is read from batch_deriveds if present, or recomputed via update_derived when is_dirty. Finally, if the signal carries ERROR_VALUE its stored value is thrown; otherwise signal.v is returned.

**Notes.**

- failure: A signal flagged ERROR_VALUE causes get to throw its stored value rather than return it.

calls: [is_dirty](r2-reactivity-core.md#u-6236bf4a1a35), [depends_on_old_values](r2-reactivity-core.md#u-331dbfbca387); uses: [runtime-js-state-and-helpers](r2-reactivity-core.md#u-6cd2387802ec)

**Uncertainties.**

- execute_derived, update_derived, get_stack, and w.await_reactivity_loss bodies are in other modules; their failure modes cannot be confirmed here.
- The exact contract of captured_signals (legacy capture) is in legacy.js.

<a id="u-6236bf4a1a35"></a>
### `is_dirty`

`export function is_dirty(reaction)` · [packages/svelte/src/internal/client/runtime.js:L153-L224][f1]

Recursively determines whether a derived or effect needs re-execution, and as a side effect may reconnect it to the dependency graph.

A reaction flagged DIRTY is immediately dirty. When flagged MAYBE_DIRTY, it inspects each dependency: first, if the reaction is DISCONNECTED or is an unowned derived that is now connected (active_effect exists and skip_reaction is false), and no active effect exists or it is not DESTROYED, it re-registers the derived in every dependency's reactions list (re-adding duplicates only when disconnected, de-duplicating when unowned), clears DISCONNECTED, and clears UNOWNED once its parent is non-unowned. It then recurses: if a dependency is itself dirty, update_derived recomputes it; if any dependency's write version exceeds the reaction's, the reaction is dirty. Only non-unowned reactions (or unowned ones read under an active effect without skip_reaction) are reset to CLEAN; unowned signals otherwise stay not-clean so they re-evaluate per reader. A DIRTY-flagged reaction returns true without touching dependencies.

calls: [is_dirty](r2-reactivity-core.md#u-6236bf4a1a35), [runtime-js-state-and-helpers](r2-reactivity-core.md#u-6cd2387802ec); uses: [remove_reaction](r2-reactivity-core.md#u-b71ac6185599)

**Uncertainties.**

- update_derived's recompute semantics are defined in deriveds.js and only referenced here.

<a id="u-f6b808e008e3"></a>
### `update_reaction`

`export function update_reaction(reaction)` · [packages/svelte/src/internal/client/runtime.js:L256-L377][f1]

Runs a reaction's function while tracking its dependencies, then reconciles the old and new dependency lists.

It saves all module-level tracking state (new_deps, skipped_deps, untracked_writes, active_reaction, skip_reaction, current_sources, component context, untracking, update_version), resets them, sets skip_reaction for UNOWNED reactions that are untracked or outside an effect update, and clears active_reaction for BRANCH/ROOT effects. Any pending AbortController on the reaction is aborted with STALE_REACTION inside without_reactive_context. During fn(): new reads append to new_deps (fast-path: if dependencies repeat in the same order, only skipped_deps is incremented), and afterwards stale dependencies are removed via remove_reactions and the deps array is rebuilt; new dependencies register the reaction in each signal's reactions list unless skip_reaction (except deriveds that already have reactions). In runes mode, untracked writes on a non-derived, non-dirty effect trigger schedule_possible_effect_self_invalidation for each write. Returning to a different previous reaction bumps read_version and merges untracked_writes upward. An ERROR_VALUE flag is cleared once the function succeeds. On a thrown error it returns handle_error(error) — errors do not propagate from this function — and the finally block restores every saved tracking variable, toggling REACTION_IS_UPDATING off.

calls: [remove_reactions](r2-reactivity-core.md#u-b457a655a682), [schedule_possible_effect_self_invalidation](r2-reactivity-core.md#u-6645f71b9626); uses: [runtime-js-state-and-helpers](r2-reactivity-core.md#u-6cd2387802ec), [is_dirty](r2-reactivity-core.md#u-6236bf4a1a35)

**Uncertainties.**

- handle_error's return value semantics (whether it rethrows) live in error-handling.js and cannot be confirmed here.
- Exact interplay of is_runes() is in context.js.

<a id="u-e2ea8c85735e"></a>
### `update_effect`

`export function update_effect(effect)` · [packages/svelte/src/internal/client/runtime.js:L441-L495][f1]

Runs an effect's update cycle: destroys stale children, executes teardown and the effect body via update_reaction, and records the resulting teardown.

A DESTROYED effect is skipped entirely. The effect is marked CLEAN, previous active_effect and is_updating_effect are saved (is_updating_effect set true), and BLOCK_EFFECTs destroy only block-effect children while others destroy all effect children. In DEV the current component function and dev stack are swapped for the effect's (block effects have their own dev stack; others fall back to the current one), restored in finally along with active_effect and is_updating_effect. A function return value from update_reaction becomes effect.teardown, otherwise null; effect.wv is set to write_version. Under DEV tracing mode, when the effect was DIRTY, each dependency with set_during_effect gets its write version incremented and the flag cleared so it is correctly seen as dirty on the next run. Exceptions from the effect body propagate after state restoration.

calls: [update_reaction](r2-reactivity-core.md#u-f6b808e008e3), [runtime-js-state-and-helpers](r2-reactivity-core.md#u-6cd2387802ec); uses: [runtime-js-state-and-helpers](r2-reactivity-core.md#u-6cd2387802ec)

**Uncertainties.**

- Whether destroy_* / teardown helpers can throw synchronously is determined in effects.js, not shown.

<a id="u-b71ac6185599"></a>
### `remove_reaction`

`function remove_reaction(signal, dependency)` · [packages/svelte/src/internal/client/runtime.js:L385-L421][f1]

Removes one signal from a reaction's dependency list and, if the dependency is a derived that has lost its last reaction, disconnects it from the graph.

The removal uses index_of with a swap-with-last-then-pop; an empty list sets dependency.reactions to null. If reactions becomes null and the dependency is a DERIVED not present in new_deps (avoiding disconnecting something about to be re-read by an updating parent), it is marked MAYBE_DIRTY, flagged DISCONNECTED unless already UNOWNED or DISCONNECTED, its owned effects destroyed via destroy_derived_effects, and its own dependencies recursively cleared with remove_reactions(dependency, 0) — allowing later reconnection or garbage collection.

calls: [remove_reactions](r2-reactivity-core.md#u-b457a655a682); uses: [is_dirty](r2-reactivity-core.md#u-6236bf4a1a35)

**Uncertainties.**

- destroy_derived_effects' teardown behavior is in deriveds.js.

<a id="u-b457a655a682"></a>
### `remove_reactions`

`export function remove_reactions(signal, start_index)` · [packages/svelte/src/internal/client/runtime.js:L428-L435][f1]

Iterates a reaction's dependency array from start_index to the end and calls remove_reaction for each, so stale dependencies accumulated after that index are unlinked; no-op when the reaction has no dependencies.

calls: [remove_reaction](r2-reactivity-core.md#u-b71ac6185599)

<a id="u-6645f71b9626"></a>
### `schedule_possible_effect_self_invalidation`

`function schedule_possible_effect_self_invalidation(signal, effect, root = true)` · [packages/svelte/src/internal/client/runtime.js:L231-L253][f1]

Propagates an effect's own untracked writes back to itself so a self-invalidating effect re-runs.

Starting from a written signal, it walks the signal's reactions recursively through DERIVED reactions (with root=false below the top level); when a reaction is exactly the target effect, it marks it: at the top level always DIRTY, deeper only MAYBE_DIRTY if it was CLEAN, then queues it via schedule_effect. Returns early if the signal has no reactions, and — in non-async mode — if the signal is one of current_sources (a write the current reaction owns, which must not self-invalidate).

calls: [schedule_possible_effect_self_invalidation](r2-reactivity-core.md#u-6645f71b9626), [runtime-js-state-and-helpers](r2-reactivity-core.md#u-6cd2387802ec)

**Uncertainties.**

- schedule_effect's queueing behavior is in batch.js and not shown.

<a id="u-331dbfbca387"></a>
### `depends_on_old_values`

`function depends_on_old_values(derived)` · [packages/svelte/src/internal/client/runtime.js:L685-L700][f1]

Recursively decides whether a derived's cached value may be stale relative to values snapshotted during effect destruction.

A derived whose value is still UNINITIALIZED returns true (unknown, assume worst); no dependencies returns false. For each dependency, a presence in old_values, or being a derived that itself depends on old values, yields true; otherwise false after full traversal.

calls: [depends_on_old_values](r2-reactivity-core.md#u-331dbfbca387)

<a id="u-917581529c00"></a>
### `deep_read`

`export function deep_read(value, visited = new Set())` · [packages/svelte/src/internal/client/runtime.js:L797-L839][f1]

Recursively reads every property of an object graph so $state proxies record dependencies, guarding against cycles with a visited set and skipping EventTarget (DOM) nodes.

Dates get getTime() called to capture changes. Each key is read recursively inside try/catch, with getter exceptions silently ignored and traversal continuing. After own keys, if the prototype is not one of Object, Array, Map, Set, or Date prototypes, all getter descriptors on the prototype are invoked on the value, again with per-getter exception swallowing, so prototype-backed reactive getters are also registered.

**Notes.**

- side_effect: Reading properties triggers reactive dependency registration and may run arbitrary user getters; their exceptions are swallowed.

calls: [deep_read](r2-reactivity-core.md#u-917581529c00)

<a id="u-031649ca68f4"></a>
### `deep_read_state`

`export function deep_read_state(value)` · [packages/svelte/src/internal/client/runtime.js:L773-L788][f1]

Reads the reactive properties of a value's first object level so $state proxies are touched and become reactive, using a shallow heuristic for performance.

Non-objects (including null and EventTarget instances) are ignored. If the value itself carries STATE_SYMBOL, the full deep_read traversal runs on it; otherwise, for non-arrays, each first-level property that is an object containing STATE_SYMBOL is deep-read. Arrays are not descended at this level.

calls: [deep_read](r2-reactivity-core.md#u-917581529c00)

<a id="u-3e34f90fa02e"></a>
### `batch-js-module-regions`

`class Batch` · [packages/svelte/src/internal/client/reactivity/batch.js:L273-L280][f2]

Non-behavioral regions of batch.js: import headers, JSDoc `@type` declarations for module state (`batches`, `current_batch`, `previous_batch`, `batch_deriveds`, `effect_pending_updates`, `tasks`, `queued_root_effects`, `last_scheduled_effect`, `is_flushing`, `is_flushing_sync`, `eager_block_effects`), and inter-symbol gaps.

No executable logic beyond the initializers of these module-level variables.

<a id="u-43c969fbb82e"></a>
### `Batch`

`class Batch` · [packages/svelte/src/internal/client/reactivity/batch.js:L81-L179][f2]

Groups source updates into a transactional unit with its own current/previous source-value maps, commit callbacks, and pending-async accounting.

Fields: `current`/`#previous` record source values after/before updates (same key sets); `#callbacks` run branch append/remove work at commit; `#pending` counts in-flight async work; `#deferred` backs `settled()`; `#neutered` marks a batch whose async effect resolved after its branch died, suppressing commit callbacks; `#async_effects` and `#boundary_async_effects` run after the rest of the batch (boundary variants do not block committing); `#render_effects`/`#effects`/`#block_effects` hold staged effects; `#dirty_effects`/`#maybe_dirty_effects` hold effects deferred past async work; `skipped_effects` are branches skipped during traversal. Folded trivial members: `activate` sets `current_batch = this`; `neuter` sets `#neutered = true`; `#commit` runs all `#callbacks` unless neutered, then clears them; `increment` bumps `#pending`; `add_callback` adds to `#callbacks`; `settled` lazily creates `#deferred` and returns its promise; static `enqueue` unshifts a task and starts the microtask `dequeue` chain when the queue was empty. `deactivate` clears `current_batch` and `previous_batch`, then runs queued pending updates one at a time, breaking if a new batch became current. `capture(source, value)` records the pre-change value once and the current value. `#defer_effects` moves each effect into the dirty/maybe-dirty buckets by flag and marks it CLEAN so it gets rescheduled when async state settles. `decrement` on reaching zero `#pending` reschedules the deferred dirty/maybe-dirty effects with their original statuses, empties render/effect queues, and flushes; otherwise it just deactivates. `flush` runs `flush_effects` when root effects are queued, otherwise commits; if a nested `flushSync` replaced `current_batch` it returns early (permitted legacy behavior), and when `#pending` is zero the batch is removed from `batches` before deactivating. Static `ensure` creates and registers a batch when none is current, scheduling a microtask flush only outside `flushSync`; that flush no-ops if a `flushSync` replaced the batch meanwhile.

group: [Batch.process](r2-reactivity-core.md#u-311848830261), [Batch.#traverse_effect_tree](r2-reactivity-core.md#u-347dcfb98cb3), [Batch.#defer_effects](r2-reactivity-core.md#u-1e7bb9c313d3), [Batch.#commit](r2-reactivity-core.md#u-0f955d9846db)

**Uncertainties.**

- Whether `decrement`'s early `deactivate` branch (pending still > 0) interacts with `effect_pending_updates` ordering beyond what `deactivate` shows is not provable here.

<a id="u-311848830261"></a>
### `Batch.process`

`process(root_effects)` · [packages/svelte/src/internal/client/reactivity/batch.js:L179-L273][f2]

Processes queued root effects for this batch and decides whether to commit now or defer.

In async mode with multiple live batches it 'time travels': it snapshots the touched sources' current `v`/`wv` into `current_values`, sets each of this batch's `current` values onto the sources, and applies other batches' `#previous` values for sources not already handled; `batch_deriveds` is enabled for the temporary re-evaluation. It then traverses each root via `#traverse_effect_tree`. If no async effects were collected and `#pending` is zero, it commits, clears the batch pointer (`previous_batch = current_batch; current_batch = null`), flushes render then regular effects, reinstates itself as current batch if no new batch appeared (otherwise deregisters itself), and resolves `#deferred`. Otherwise it defers render, effect, and block-effect queues. Finally it restores time-travelled sources only if they did not receive newer values (`source.wv <= wv`), clears `batch_deriveds`, and runs the collected async and boundary-async effects via `update_effect`, resetting those queues.

calls: [Batch.#traverse_effect_tree](r2-reactivity-core.md#u-347dcfb98cb3), [flush_queued_effects](r2-reactivity-core.md#u-93f48e016c80)

**Uncertainties.**

- Interaction of time-travel restoration with sources written during effect execution is partially documented by the `source.wv <= wv` guard; finer ordering is not provable from this file.

<a id="u-a2102d9024ed"></a>
### `Batch.flush`

`flush()` · [packages/svelte/src/internal/client/reactivity/batch.js:L379-L397][f2]

See the class unit for folded behavior: it flushes queued root effects via `flush_effects` or commits directly, bails out early if a nested `flushSync` replaced the current batch, deregisters the batch from `batches` when `#pending` is zero, and deactivates.

<a id="u-0f955d9846db"></a>
### `Batch.#commit`

`#commit()` · [packages/svelte/src/internal/client/reactivity/batch.js:L402-L410][f2]

Runs all registered commit callbacks (branch DOM append/remove work) unless the batch was neutered, then clears the callback set regardless.

<a id="u-1e7bb9c313d3"></a>
### `Batch.#defer_effects`

`#defer_effects(effects)` · [packages/svelte/src/internal/client/reactivity/batch.js:L330-L340][f2]

Moves staged effects into the batch's deferred `#dirty_effects` or `#maybe_dirty_effects` buckets according to each effect's DIRTY flag, marks each CLEAN (so it gets scheduled again when async state settles), and empties the source array.

<a id="u-347dcfb98cb3"></a>
### `Batch.#traverse_effect_tree`

`#traverse_effect_tree(root)` · [packages/svelte/src/internal/client/reactivity/batch.js:L280-L325][f2]

Walks the effect tree from a root (first clearing the root's CLEAN bit) deciding per effect whether to run, stash, or skip.

An effect is skipped when it is a CLEAN branch/root (skippable branch), INERT, or listed in `skipped_effects`. For non-skipped effects with a `fn`: branch/root effects get CLEAN toggled off; EFFECT-flagged ones are pushed to `#effects`; in async mode RENDER_EFFECTs go to `#render_effects`; ASYNC effects go to `#boundary_async_effects` when `effect.b?.pending` else `#async_effects` (never run inline); otherwise if dirty, block effects are also pushed to `#block_effects` and the effect runs immediately via `update_effect`. Traversal descends to `effect.first` when present, otherwise advances to `next`, climbing parents until a sibling is found.

calls: [update_effect](r2-reactivity-core.md#u-e2ea8c85735e)

<a id="u-f4c4d1829672"></a>
### `flushSync`

`export function flushSync(fn)` · [packages/svelte/src/internal/client/reactivity/batch.js:L485-L523][f2]

Synchronously flushes all pending updates, optionally running `fn` mid-flush and returning its result.

In async mode with an active effect it throws `flush_sync_in_effect`. It sets `is_flushing_sync` (restored in `finally`), then loops: flushes microtasks via `flush_tasks`, and if no root effects remain flushes the current batch and — re-checking since `$effect.pending` updates may requeue — returns the accumulated result; otherwise runs `flush_effects` again. When `fn` is given, an initial `flush_effects` runs before invoking it so the callback sees settled state.

calls: [task-js-queues](r1-task-scheduling.md#u-08b6b6ebaf85); raises: [packages/svelte/src/internal/client/errors.js][f3]

**Uncertainties.**

- The exact semantics of re-entry via `fn` calling flushSync recursively are guarded only by the `is_flushing_sync` flag; deeper interactions are not visible here.

<a id="u-bb27f3ab5ca2"></a>
### `flush_effects`

`function flush_effects()` · [packages/svelte/src/internal/client/reactivity/batch.js:L525-L571][f2]

Drains `queued_root_effects` in a loop: ensures a batch exists, guards against runaway updates after 1000 iterations, processes the batch, and clears `old_values`.

When the guard trips in DEV it aggregates per-stack update counts from each batch source's `updated` list and logs the recorded errors before calling `infinite_loop_guard`. Preserves and restores `is_updating_effect` and the `last_scheduled_effect` pointer across the flush, with `is_flushing` set true for the duration.

calls: [infinite_loop_guard](r2-reactivity-core.md#u-a4b355b41c3e)

<a id="u-93f48e016c80"></a>
### `flush_queued_effects`

`function flush_queued_effects(effects)` · [packages/svelte/src/internal/client/reactivity/batch.js:L595-L642][f2]

Runs an array of staged effects in order, updating each non-destroyed, non-inert, dirty effect.

After `update_effect`, an effect with no deps, children, or nodes is pruned: fully unlinked from the graph when it has no teardown or abort controller, otherwise kept in the tree with `fn` nulled to free memory. If running an effect triggered a nested flush that populated `eager_block_effects`, those eager effects are updated in turn (clearing `old_values` first) — but only if a concurrent nested flush has not already consumed them by resetting the array to null. `eager_block_effects` ends null.

calls: [update_effect](r2-reactivity-core.md#u-e2ea8c85735e), [unlink_effect](r4-runtime-effects.md#u-519e1d7b7b2b)

**Uncertainties.**

- The TODO-marked `eager_block_effects` handling is acknowledged in-source as possibly incorrect; its precise cross-flush semantics are not fully derivable here.

<a id="u-a4b355b41c3e"></a>
### `infinite_loop_guard`

`function infinite_loop_guard()` · [packages/svelte/src/internal/client/reactivity/batch.js:L573-L586][f2]

Handles runaway update loops: throws `effect_update_depth_exceeded` inside try, catches it, strips the (useless) stack in DEV by redefining `stack` to an empty string, and best-effort routes the error to the error boundary of `last_scheduled_effect` — the effect nearest the loop.

calls: [invoke_error_boundary](r3-client-dev.md#u-8ed809bdafb5)

<a id="u-ce4f8d895426"></a>
### `schedule_effect`

`export function schedule_effect(signal)` · [packages/svelte/src/internal/client/reactivity/batch.js:L648-L668][f2]

Schedules an effect by recording it as `last_scheduled_effect`, climbing to its root ancestor and queuing that root in `queued_root_effects`.

While climbing: if flushing and the ancestor is the active effect with BLOCK_EFFECT flag, it bails (a parent block updating an internal source would otherwise cause a second flush); for ROOT/BRANCH ancestors, a non-clean one already queued causes bail-out, otherwise the CLEAN bit is toggled off before continuing.

<a id="u-aed941f29bc8"></a>
### `suspend`

`export function suspend()` · [packages/svelte/src/internal/client/reactivity/batch.js:L670-L690][f2]

Registers async work against the pending boundary and the current batch.

It increments the boundary's pending count always, and increments the batch's `#pending` only when the boundary was not already pending. The returned `unsuspend` decrements the boundary count; if the boundary was not previously pending it re-activates the batch and decrements `#pending` (which can trigger flush at zero), otherwise just deactivates the batch. In both cases it clears the reactive context via `unset_context`.

calls: [Batch](r2-reactivity-core.md#u-43c969fbb82e), [unset_context](r1-async-reactivity.md#u-2e39d8f937d3)

**Uncertainties.**

- The closure captures the `pending` value from call time; behavior if the boundary's pending state changes between suspend and unsuspend is not visible here.

<a id="u-dbbbce459e92"></a>
### `dequeue`

`function dequeue()` · [packages/svelte/src/internal/client/reactivity/batch.js:L62-L70][f2]

Pops the next task from the module-level `tasks` queue; if more tasks remain it schedules itself again via `queueMicrotask`, then runs the popped task.

Together with `Batch.enqueue` this forms the microtask drain that flushes batches outside `flushSync`.

<a id="u-6561acc7b015"></a>
### `packages/svelte/src/internal/client/reactivity/batch.js:clear`

`export function clear()` · [packages/svelte/src/internal/client/reactivity/batch.js:L695-L697][f2]

Test-only helper that empties the module-level `batches` set, forcibly removing all live batches to prevent cross-talk between tests.

<a id="u-40a134e2a457"></a>
### `StaleReactionError`

`class StaleReactionError extends Error` · [packages/svelte/src/internal/client/constants.js:L35-L38][f4]

Instantiates a singleton Error subclass identifying reactions re-run or destroyed after getAbortSignal().

The class is created and immediately constructed into the STALE_REACTION export; users can ignore abort errors by checking reason.name === 'StaleReactionError'.

<a id="u-ea8222e99174"></a>
### `disclose-version.js module code (L1–L6)`

`module_region` · [packages/svelte/src/internal/disclose-version.js:L1-L6][f5]

Side-effect-only module that records the public Svelte version in the browser.

When `window` exists, it lazily creates `window.__svelte` (if absent) and `window.__svelte.v` as a Set (if absent), then adds PUBLIC_VERSION imported from ../version.js. On the server (no window) it does nothing, so importing this module is safe in any environment.

imports: [disclose-version.js module code (L1–L6)](r2-reactivity-core.md#u-ea8222e99174)

**Uncertainties.**

- If window.__svelte.v already exists as a non-Set, `.add` behavior depends on that pre-existing object; not provable here.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/runtime.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/reactivity/batch.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/errors.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/constants.js
[f5]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/disclose-version.js
