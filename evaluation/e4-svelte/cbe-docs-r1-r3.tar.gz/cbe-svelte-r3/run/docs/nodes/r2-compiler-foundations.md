# Compiler Foundations

**Capability.** Shared infrastructure used by all compiler phases: error factories and the InternalCompileError they throw, the CompileDiagnostic formatter, svelte-ignore parsing, tiny AST/string/slot helpers, the CSS and legacy AST type declarations, and the validated compiler-options tables.

Read this subtree before debugging any compiler error or warning output: every phase throws through errors.js and formats through CompileDiagnostic. The d.ts files here define the CSS AST and legacy AST shapes the phases operate on. validate-options.js is the single gate for user-supplied compile options.

**Depended on by.**

- [Template Analysis](r2-analyze-phase.md) · graph-confirmed · 1 edge(s) · analysis visitors import error/warning factories and use extract_svelte_ignore from the shared compiler foundations.
- [Client Transform](r2-client-transform.md) · model-inferred · 0 edge(s)
- [CSS Transform](r2-css-transform.md) · model-inferred · 0 edge(s)
- [Warning Message Codegen](r2-message-codegen.md) · model-inferred · 0 edge(s)
- [Sandbox Playground](r2-playgrounds.md) · model-inferred · 0 edge(s)
- [Server Transform](r2-server-transform.md) · graph-confirmed · 1 edge(s)

Parent: [Svelte Compiler](r2-compiler.md)

## Units (24)

<a id="u-cef04d4352b1"></a>
### `errors-internal-error-and-throw-helper`

`class InternalCompileError extends Error` · [packages/svelte/src/compiler/errors.js:L6-L15][f1]

Defines InternalCompileError, the Error subclass thrown by every compiler error factory, and `e`, the shared helper that converts a node/position into a thrown InternalCompileError.

InternalCompileError extends Error so bundler plugins recognize it, but stores all payload in a private CompileDiagnostic: the constructor clears the stack, assigns a CompileDiagnostic built from (code, message, position) onto the instance via Object.assign (making diagnostic fields enumerable), and sets name to 'CompileError'; toString and toJSON delegate to the diagnostic. `e` accepts null, a number, or a {start,end} node; for a number it uses it as both start and end, otherwise reads node?.start/node?.end; it throws with a [start, end ?? start] position, or undefined when start is undefined.

**Notes.**

- side_effect: The constructor assigns diagnostic properties directly onto the error instance via Object.assign and explicitly clears `stack`, so the thrown object carries enumerable diagnostic fields but no stack.
- field: `message` is initialized as an enumerable class property to keep it visible to serialization; `#diagnostic` remains private and backs toString/toJSON.

calls: [errors-internal-error-and-throw-helper](r2-compiler-foundations.md#u-cef04d4352b1), [CompileDiagnostic](r2-compiler-foundations.md#u-49c3d847da08)

**Uncertainties.**

- The exact shape of CompileDiagnostic fields copied onto the error is defined in compile_diagnostic.js, not visible here.
- Only `super` and `require` appear as unresolved calls; behavior of Object.assign over pre-existing properties with the same names is inherited from CompileDiagnostic's own fields.

<a id="u-49c3d847da08"></a>
### `CompileDiagnostic`

`class CompileDiagnostic` · [packages/svelte/src/compiler/utils/compile_diagnostic.js:L52-L60][f2]

Represents a compile-time diagnostic implementing ICompileDiagnostic, with a fixed `name` of 'CompileDiagnostic'.

The constructor stores `code` and `message`; it records `filename` from compiler state only when it differs from `state.UNKNOWN_FILENAME`. When a `[start, end]` character position is given it stores `position`, resolves `start`/`end` Location objects via `state.locator`, and — only when both resolve — builds a source code frame with `get_code_frame(state.source, start.line - 1, end.column)`. `toString` renders `code: message`, then the filename (with `line:column` when `start` exists), then the frame when present. `toJSON` returns the plain serializable fields code, message, filename, start, end, position, frame. Fields are absent (undefined) when their preconditions fail, e.g. unknown filename or unresolvable locator results.

**Uncertainties.**

- Behavior of `state.locator` and `state.filename` when no compilation is active is defined in ../state.js and not visible here

<a id="u-89760501a656"></a>
### `compile-diagnostic-js-formatting`

`function tabs_to_spaces(str)` · [packages/svelte/src/compiler/utils/compile_diagnostic.js:L9-L11][f2]

Source-frame formatting helpers used by CompileDiagnostic.

`tabs_to_spaces` replaces leading tab runs with two spaces per tab, so column math and rendering are consistent. `get_code_frame` slices the source around a zero-based error line: from two lines before up to (but not including) three lines after, clamped to the file bounds. Each line is prefixed with its one-based number padded to the width of the last line number, followed by `: `. The error line additionally gets a caret indicator line whose indentation equals the padded-number width plus two plus the space-converted length of the text before the column, so the caret aligns under the error column after tab conversion.

**Uncertainties.**

- The caret is positioned using the end location's column (the caller passes `this.end.column`), not the start column

<a id="u-4a9ee4fb9b67"></a>
### `extract_svelte_ignore`

`export function extract_svelte_ignore(offset, text, runes)` · [packages/svelte/src/compiler/utils/extract_svelte_ignore.js:L28-L82][f3]

Parses the codes following a `svelte-ignore` comment at the given text offset and returns the recognized ignore codes.

If the text does not start with `svelte-ignore ` (after whitespace) it returns an empty array. In runes mode, codes must be comma-separated; iteration stops at the first token not followed by a comma, and the rest is treated as prose. Each token is accepted when it is a known warning/runtime code; otherwise a legacy code is mapped through the `replacements` table or dash-to-underscore conversion, and if that replacement is known a `legacy_code` warning is emitted, else an `unknown_code` warning with a fuzzy-match suggestion. In non-runes mode, parsing is lax: every word-like token is pushed as an ignore, and when a token is unknown its mapped replacement is additionally pushed (if known) without warnings.

calls: [fuzzymatch](r4-compiler-parse.md#u-4d517976b3f9)

**Uncertainties.**

- The exact warning texts/behavior of `w.legacy_code` and `w.unknown_code` live in ../warnings.js and are not shown here

<a id="u-22cdd6c7c71c"></a>
### `migrate_svelte_ignore`

`export function migrate_svelte_ignore(text)` · [packages/svelte/src/compiler/utils/extract_svelte_ignore.js:L89-L104][f3]

Rewrites legacy ignore codes inside a `svelte-ignore` comment to their modern underscore form.

If the text does not begin with `svelte-ignore ` it is returned unchanged. After the prefix, each hyphenated code token is replaced via the `replacements` table or dash-to-underscore conversion; a trailing comma is appended whenever another hyphenated token follows later in the comment, preserving separation.

**Uncertainties.**

- The lookahead regex tests the remainder of the whole comment, so a comma may be added even when the next token is prose rather than a code

<a id="u-4f8a7deedb7c"></a>
### `push_array`

`export function push_array(array, items)` · [packages/svelte/src/compiler/utils/push_array.js:L9-L13][f4]

Appends every item of `items` to `array` with individual push calls, mutating `array`.

Per the docstring this exists for memory/performance and to avoid the 'max call stack size exceeded' error that spread-based `array.push(...items)` hits with very large item lists (~65k).

<a id="u-01781e43d6ff"></a>
### `sanitize_template_string`

`export function sanitize_template_string(str)` · [packages/svelte/src/compiler/utils/sanitize_template_string.js:L5-L7][f5]

Escapes backticks, `${`, and backslashes in a string so it can be embedded safely inside a JS template literal, prefixing each match with a backslash.

<a id="u-ead26eb5b43f"></a>
### `determine_slot`

`export function determine_slot(node)` · [packages/svelte/src/compiler/utils/slot.js:L8-L20][f6]

Returns the slot name assigned to a node via a static `slot` attribute, or null.

Non-element nodes return null immediately (via is_element_node). Among the node's attributes, only plain 'Attribute' nodes named exactly 'slot' that are text attributes (is_text_attribute) qualify; the first such attribute's text value is returned. Any other attribute kind, name, or a non-text (dynamic) slot attribute is skipped and the scan continues, ultimately returning null.

calls: [is_element_node](r4-compiler-node-model.md#u-0d9a79ad394a), [ast-js-attribute-helpers](r4-compiler-ast-utils.md#u-e05972fa52ab)

<a id="u-5617f591c677"></a>
### `list`

`export function list(strings, conjunction = 'or')` · [packages/svelte/src/compiler/utils/string.js:L5-L9][f7]

Formats a string list for prose messages using a conjunction (default 'or').

One item returns it alone; two items join as 'a <conj> b'; three or more join all but the last with ', ' and append ' <conj> <last>'.

<a id="u-b61efd19fa24"></a>
### `css.d.ts-css-ast`

`export namespace _CSS { export interface BaseNode` · [packages/svelte/src/compiler/types/css.d.ts:L3-L7][f8]

Declares the `_CSS` namespace of TypeScript interfaces describing the compiler's internal CSS AST: style sheets, at-rules, rules, selector lists, complex/relative selectors, simple selectors, combinators, blocks, and declarations.

Every node carries `start`/`end` offsets. Rules and selectors carry internal `metadata` fields that downstream scoping/pruning phases set and read: `Rule.metadata.has_local_selectors`/`has_global_selectors`/`is_global_block`, `ComplexSelector.metadata.is_global` and `used` (set in css-analyze for global selectors, in css-prune for others), and `RelativeSelector.metadata.is_global`/`is_global_like`/`scoped`. The documented `is_global` semantics are specific: `:global(...).x` is not global because it still needs scoping; `:global(...):is/where/not/has(...)` counts as global only when all their children are global; `is_global_like` covers `:root`, `:host`, `::view-transition`, or selectors after a `:global`. `RelativeSelector.combinator` is `null` for the first selector in a complex selector. The `Node` union (commented 'for zimmerframe') enumerates the traverseable subset. These are pure type declarations with no runtime behavior.

uses: [template.d.ts-types](r4-compiler-types.md#u-d5bf4f9acf4a)

**Uncertainties.**

- Which phase actually assigns each metadata flag is stated only in doc comments; the css-analyze/css-prune implementations are not in this batch

<a id="u-12cde4f20754"></a>
### `legacy-nodes.d.ts-legacy-ast`

`interface BaseNode` · [packages/svelte/src/compiler/types/legacy-nodes.d.ts:L13-L17][f9]

Declares the legacy (Svelte 4-compatible) AST node types used for `modernAst: false` compiler output.

Local `BaseNode` gives every node `type`/`start`/`end`; `BaseElement` adds `name`, `attributes: LegacyAttributeLike[]`, and `children: LegacyElementLike[]`. Leaf interfaces mirror each legacy construct with doc-annotated directive parts (e.g. the `x` in `use:x`). Notable shapes: `LegacyAttribute.value` is `true` for boolean attributes or an array of `AST.Text`, `LegacyMustacheTag`, or `LegacyAttributeShorthand`; `LegacyTransition` derives `intro`/`outro` booleans from whether the directive was `transition:`/`in:`/`out:` and restricts modifiers to `'local' | 'global'`; `LegacyComment.ignores` parses `<!-- svelte-ignore a b c -->` into `['a', 'b', 'c']`; `LegacyElement` is a bare `{ type: 'Element' }` that does not extend `BaseElement`, yet is included in the `LegacyElementLike` union. `LegacyStyle` mirrors the CSS style-sheet shape loosely with `any`-typed attributes and children, and `LegacySelector.children` mix `AST.CSS.Combinator` and `AST.CSS.SimpleSelector`; `LegacyCssNode` and `LegacySvelteNode` are the top-level unions. These are pure type declarations with no runtime behavior.

uses: [template.d.ts-types](r4-compiler-types.md#u-d5bf4f9acf4a)

**Uncertainties.**

- Whether `LegacyElement` lacking `start`/`end`/`name`/`attributes` is intentional or a type gap cannot be determined from this file alone

<a id="u-9be87a51ccd3"></a>
### `legacy-interfaces.d.ts-deprecated-aliases`

`export type CompileOptions = C;` · [packages/svelte/src/compiler/types/legacy-interfaces.d.ts:L4-L4][f10]

Provides two deprecated type aliases, `CompileOptions` and `Warning`, that forward to the corresponding types imported from `#compiler`; deprecation comments direct consumers to import them from `svelte` instead.

Pure type re-exports with no behavior.

uses: [index.d.ts-compile-api](r4-compiler-types.md#u-9ca884f55142)

<a id="u-63df7e79622d"></a>
### `validate-options.js module code (L1–L171)`

`module_region` · [packages/svelte/src/compiler/validate-options.js:L1-L171][f11]

Defines the validator tables for compiler options.

common_options covers filename, rootDir (defaulting to process.cwd() or Deno.cwd() where available), dev, generate (mapping legacy 'dom'/'ssr' to 'client'/'server' with a one-time warning, and rejecting anything else except false), warningFilter, and experimental.async. component_options defines per-option validators: booleans with defaults, deprecated options (accessors, immutable) that warn once then still validate, removed options (legacy, format, tag, sveltePath, errorMode, varsReport) that error when set, warn-removed options (loopGuardTimeout, enableSourcemap, hydratable) that warn once when set, css restricted to 'external'/'injected' with booleans and 'none' rejected, a cssHash default, compatibility.componentApi limited to 4 or 5 defaulting to 5, and a permissive sourcemap pass-through. From these, validate_module_options accepts only the common option keys (ignoring others via no-op validators) and validate_component_options accepts common plus component options, both as object validators.

**Notes.**

- failure: Unknown keys under validate_component_options trigger e.options_unrecognised unless allowed; generate/css violations and wrong types raise errors via throw_error.

<a id="u-3dabd9340065"></a>
### `validator`

`function validator(fallback, fn)` · [packages/svelte/src/compiler/validate-options.js:L252-L256][f11]

Core validator combinator: when the input is undefined the fallback is returned unchanged; otherwise the given function decides validity and the transformed value.

<a id="u-0cdcb27df0bc"></a>
### `string`

`function string(fallback, allow_empty = true)` · [packages/svelte/src/compiler/validate-options.js:L263-L275][f11]

Build a string validator with a fallback: non-string inputs raise an error naming the keypath, and an empty string raises too when allow_empty is false (true by default).

<a id="u-a62cec4e56c4"></a>
### `boolean`

`function boolean(fallback)` · [packages/svelte/src/compiler/validate-options.js:L281-L288][f11]

Build a boolean validator with a fallback: any non-boolean input raises an error naming the keypath.

<a id="u-ecb419a3a561"></a>
### `fun`

`function fun(fallback)` · [packages/svelte/src/compiler/validate-options.js:L312-L319][f11]

Build a function-valued option validator with a fallback: non-function inputs raise an error naming the keypath.

<a id="u-2d79df0c8cfd"></a>
### `packages/svelte/src/compiler/validate-options.js:list`

`function list(options, fallback = options[0])` · [packages/svelte/src/compiler/validate-options.js:L294-L306][f11]

Build an enum validator over a fixed option list, defaulting to the first entry (or an explicit fallback).

Values outside the list raise an error naming the keypath, with wording that varies by list length: two options read 'either X or Y', longer lists enumerate all but the last with 'or' before it.

<a id="u-0dfc41eda888"></a>
### `packages/svelte/src/compiler/validate-options.js:object`

`function object(children, allow_unknown = false)` · [packages/svelte/src/compiler/validate-options.js:L219-L245][f11]

Build a validator for an object-shaped option.

It rejects non-object inputs and arrays with an options_invalid_value error naming the keypath. Unknown keys are copied through only when allow_unknown is set; otherwise an options_unrecognised error names the full keypath (or bare key at the root). Each declared child validator then runs with input[key] (undefined when input is absent) and an extended keypath, and its result is written into the output object, so defaults and errors come from the child validators.

<a id="u-57b26ac837bc"></a>
### `removed`

`function removed(msg)` · [packages/svelte/src/compiler/validate-options.js:L172-L179][f11]

Build a validator for an option that no longer exists: if the input is defined it raises an options_removed error with the given message; it always resolves to undefined.

<a id="u-d8df8fda6d4f"></a>
### `warn_removed`

`function warn_removed(fn)` · [packages/svelte/src/compiler/validate-options.js:L195-L200][f11]

Build a validator for an option that still parses but warns: if the input is defined it emits the given warning once (via warn_once) and returns undefined either way.

<a id="u-994889c21a32"></a>
### `deprecate`

`function deprecate(fn, validator)` · [packages/svelte/src/compiler/validate-options.js:L207-L212][f11]

Wrap a validator so that when the input is defined a deprecation warning is emitted once (via warn_once), after which the wrapped validator still runs and its result — including any errors it throws — determines the outcome.

<a id="u-1215fafafc03"></a>
### `warn_once`

`function warn_once(fn)` · [packages/svelte/src/compiler/validate-options.js:L184-L189][f11]

Emit a warning function once per process, tracked in a module-level Set keyed by the function itself; repeat calls with the same function are suppressed.

<a id="u-60c04920b636"></a>
### `packages/svelte/src/compiler/validate-options.js:throw_error`

`function throw_error(msg)` · [packages/svelte/src/compiler/validate-options.js:L322-L324][f11]

Raise an options_invalid_value error with the given message; the shared failure path for all type/enum validators in this module.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/errors.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/utils/compile_diagnostic.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/utils/extract_svelte_ignore.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/utils/push_array.js
[f5]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/utils/sanitize_template_string.js
[f6]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/utils/slot.js
[f7]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/utils/string.js
[f8]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/types/css.d.ts
[f9]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/types/legacy-nodes.d.ts
[f10]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/types/legacy-interfaces.d.ts
[f11]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/validate-options.js
