# CSS Analysis

**Capability.** Validates and annotates component stylesheets: :global detection in rules and selectors, keyframes collection, nesting-selector placement, and global/used metadata propagation across the CSS tree.

Use when changing scoping or :global semantics. analyze_css walks the stylesheet with css_visitors; the Rule/Atrule/selector visitors maintain CssState metadata (is_global_block, has_global_selectors) consumed by helpers like is_in_global_block and is_unscoped.

**Depended on by.**

- [AST Analysis Visitors](r5-analyze-visitors.md) · model-inferred · 0 edge(s)

Parent: [Analysis Phase](r5-compiler-analyze.md)

## Units (10)

<a id="u-f762711e5ae7"></a>
### `analyze_css`

`export function analyze_css(stylesheet, analysis)` · [packages/svelte/src/compiler/phases/2-analyze/css/css-analyze.js:L322-L331][f1]

Entry point that analyzes a component's stylesheet: builds a CssState sharing the analysis's keyframes array, with rule null and the component analysis, then walks the stylesheet with the css_visitors table so Atrule, ComplexSelector, RelativeSelector, Rule, and NestingSelector validation and metadata propagation run over the whole CSS tree.

uses: [Atrule](r5-analyze-css.md#u-e57d7d11437c)

<a id="u-b122f86baec1"></a>
### `is_global_block_selector`

`function is_global_block_selector(simple_selector)` · [packages/svelte/src/compiler/phases/2-analyze/css/css-analyze.js:L25-L31][f1]

Reports whether a simple selector is a bare `:global` pseudo-class with no argument list, used to detect :global block selectors in rule preludes.

Returns true only when the type is 'PseudoClassSelector', the name is 'global', and args is null; `:global(...)` with args returns false.

<a id="u-369b23b9e8cb"></a>
### `is_in_global_block`

`function is_in_global_block(path)` · [packages/svelte/src/compiler/phases/2-analyze/css/css-analyze.js:L46-L48][f1]

Checks whether any node on the given CSS path is a Rule whose metadata.is_global_block is true, i.e. whether the current node sits inside a `:global { ...

}` block. Returns that boolean via path.some.

<a id="u-eb466791d0eb"></a>
### `is_unscoped`

`function is_unscoped(path)` · [packages/svelte/src/compiler/phases/2-analyze/css/css-analyze.js:L36-L40][f1]

Determines whether the current CSS path is entirely unscoped by filtering the ancestor path to Rule nodes and requiring every such Rule to have metadata.has_global_selectors set.

If any enclosing rule has local selectors the result is false; an empty filtered list yields true via every(), so a path with no Rule ancestors counts as unscoped.

**Uncertainties.**

- Whether callers rely on the empty-path-true behavior is not established in this file.

<a id="u-e57d7d11437c"></a>
### `Atrule`

`const css_visitors = { Atrule(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/css/css-analyze.js:L51-L63][f1]

Collects keyframes names into analysis state and records global keyframe usage.

For an at-rule that is a keyframes node: if the prelude does not start with '-global-' and the node is not inside a :global block, the prelude name is pushed onto state.keyframes; if it does start with '-global-', the analysis is marked css.has_global when is_unscoped(context.path) holds, regardless of whether the keyframes block is empty. Non-keyframes at-rules only fall through. context.next() always runs so child nodes are visited.

**Notes.**

- side_effect: Mutates context.state.keyframes and context.state.analysis.css.has_global.

calls: [is_keyframes_node](r4-compiler-node-model.md#u-8dc3955e3495)

<a id="u-7665c45db5b3"></a>
### `ComplexSelector`

`ComplexSelector(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/css/css-analyze.js:L64-L141][f1]

Validates placement of :global in a complex selector, then propagates global/used metadata.

After visiting children, it finds the first child for which is_global is true; if one exists and is nested inside a PseudoClassSelector two frames up without args, it raises css_global_block_invalid_placement. If that global child has args but is neither first nor last, every following child must also be global or css_global_invalid_placement is raised (consecutive globals are allowed). Then for each relative selector's :global pseudo-class selectors: a TypeSelector first inside :global(...) at a non-zero compound position raises css_global_invalid_selector_list; a following TypeSelector raises css_type_selector_invalid_placement; args with more than one selector, when the complex selector has multiple children or the relative selector has multiple selectors, raises css_global_invalid_selector (standalone multi-selector :global() is allowed). It then sets metadata.rule from state, marks metadata.is_global when every child is global or global-like, defaults metadata.used to that value, and additionally marks the selector used when the enclosing rule has a parent rule, the first selector is a NestingSelector whose next selector is absent or an unscoped pseudo-class, and the parent rule's prelude consists solely of a global child.

calls: [packages/svelte/src/compiler/phases/2-analyze/css/utils.js:is_global](r2-css-analyze.md#u-022eb67172ae)

**Uncertainties.**

- The distinctions between the raised error functions' messages are not visible in this file.

<a id="u-103ef31ee70b"></a>
### `NestingSelector`

`NestingSelector(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/css/css-analyze.js:L287-L315][f1]

Validates where the CSS nesting selector `&` may appear.

With no parent rule, `&` is only legal when the enclosing rule has a single complex selector with a single simple selector that is `:global(...)` containing this nesting selector as its first selector; any other shape raises css_nesting_selector_invalid_placement. With a parent rule that is itself a top-level global block whose prelude is a lone `:global` selector (the `:global { &.foo }` case), css_global_block_invalid_modifier_start is raised. context.next() continues traversal afterwards.

<a id="u-7853ab08bc6e"></a>
### `RelativeSelector`

`RelativeSelector(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/css/css-analyze.js:L142-L187][f1]

Classifies a relative selector as global or global-like and marks nested selectors used so they are not reported unused.

A leading combinator raises css_selector_invalid when there is no parent rule, the node is the parent complex selector's first child, and the grandparent is not a PseudoClassSelector. metadata.is_global is set when the node has selectors and is_global(node) holds. Global-like is set when all selectors are pseudo-class/element selectors and the first is 'host' or one of the listed view-transition pseudo-elements, or when some selector is ':root' and none is ':has' (so :root.y:has(.x) stays local). When global or global-like, each child selector is walked with a ComplexSelector visitor setting metadata.used = true, so nested selectors like :root:not(.x) are not flagged unused. context.next() then continues traversal.

calls: [packages/svelte/src/compiler/phases/2-analyze/css/utils.js:is_global](r2-css-analyze.md#u-022eb67172ae)

<a id="u-7fee2f390291"></a>
### `Rule`

`Rule(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/css/css-analyze.js:L197-L226][f1]

Classifies a CSS rule's prelude as a :global block and records parent metadata before visiting children.

Sets node.metadata.parent_rule from state. For each complex selector child, a bare leading `:global` (found at simple-selector index 0) makes the rule a global block: if the child has more selectors, it is the first complex selector, and there is no parent rule, css_global_block_invalid_modifier_start is raised; otherwise remaining simple selectors are walked to set metadata.used = true, a non-space combinator raises css_global_block_invalid_combinator, a lone `:global` in a multi-selector prelude list raises css_global_block_invalid_list, and a direct Declaration inside a top-level lone-`:global` rule raises css_global_block_invalid_declaration. Any bare `:global` at a non-zero position raises css_global_block_invalid_modifier; selectors after a global one are marked is_global_like. If the rule was already a global block but this complex selector is not, css_global_block_invalid_list is raised.

**Uncertainties.**

- Behavior of the nested ComplexSelector fragment at lines 226-228 (sets used=true during the walk) is included here; it has no separate logic beyond that assignment.

<a id="u-9242418cf87e"></a>
### `packages/svelte/src/compiler/phases/2-analyze/css/css-analyze.js:Rule`

`Rule(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/css/css-analyze.js:L228-L286][f1]

Continues the Rule visitor after prelude classification: creates a child state with rule set to this node, visits the prelude first to populate selector metadata, then aggregates has_global_selectors/has_local_selectors from each complex selector's is_global metadata using ||=.

The component is marked css.has_global when the rule has global selectors, contains at least one direct Declaration, and is_unscoped(context.path) says all enclosing rules are unscoped. Finally it visits the block with the new state so nested rules pick up parent_rule metadata.

**Notes.**

- side_effect: Sets node.metadata.has_global_selectors, has_local_selectors, and possibly analysis.css.has_global.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/css/css-analyze.js
