# Client Transform Utilities

**Capability.** Shared expression-building and reactivity decisions for the client transform: state/prop source detection, getter construction, hoisted-function parameter rebuilding, derived wrapping, and proxy decisions.

Read these helpers to understand how identifiers become reactive reads. They are called from client_component, LabeledStatement, FunctionDeclaration, CallExpression, and RegularElement builders.

**Depended on by.**

- [Client Transform Phase](r3-client-transform.md) · containment · → 4 / ← 0 edge(s) (ancestor direct units and descendant subtree; → follows ` r3-client-transform ` → ` r3-client-transform-utils `)
- [Client Transform Visitors](r3-client-transform-visitors.md) · graph-confirmed · 5 edge(s)
- [Client Code Transformation](r4-transform-client.md) · graph-only · 10 edge(s)

Parent: [Client Transform Phase](r3-client-transform.md)

## Units (8)

<a id="u-66a19e20e1f1"></a>
### `build_getter`

`export function build_getter(node, state)` · [packages/svelte/src/compiler/phases/3-transform/client/utils.js:L36-L47][f1]

Builds the read expression for an identifier, or returns the node unchanged.

If state.transform has an own entry for the name and the identifier is not the binding's own declaration node, it delegates to that entry's read callback (e.g. producing `$.get(foo)`); otherwise — including when the binding cannot be resolved via state.scope — the identifier is returned as-is.

uses: [is_state_source](r3-client-transform-utils.md#u-4eba3d9b7ec5)

<a id="u-a89fb605f1f4"></a>
### `build_hoisted_params`

`export function build_hoisted_params(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/utils.js:L146-L166][f1]

Builds the rewritten parameter list for a function hoisted out of the component.

It calls get_hoisted_params, stores the result on node.metadata.hoisted_params, then appends: a generated `_<n>` context parameter when the function had no declared params but hoisted params exist (for the event object), otherwise the context-visited original params, and finally all hoisted params.

calls: [packages/svelte/src/compiler/phases/3-transform/client/utils.js:get_hoisted_params](r3-client-transform-utils.md#u-e75f8500d3ca)

<a id="u-d8c62e2be238"></a>
### `create_derived`

`export function create_derived(state, expression, async = false)` · [packages/svelte/src/compiler/phases/3-transform/client/utils.js:L295-L303][f1]

Wraps an expression in a derived-signal creation call.

The expression is thunked (async-capable). In async mode it emits `await $.save($.async_derived(thunk))`; otherwise it emits `$.derived(thunk)` in runes mode or `$.derived_safe_equal(thunk)` in legacy mode, reflecting legacy's need for safe equality checks.

<a id="u-e75f8500d3ca"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/utils.js:get_hoisted_params`

`function get_hoisted_params(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/utils.js:L68-L123][f1]

Collects the external bindings a hoisted function references, producing parameter identifiers for them.

For each scope reference whose binding exists, is not declared in the local scope, and whose initial is not the node itself: a store_sub reference contributes both the subscription identifier and the store (looked up by dropping the `$` prefix) so values can be read and updated; a transform read expression matching a destructured `$.get(x)` member shape contributes the inner signal identifier; a non-source prop/bindable_prop contributes `$$props`; otherwise, if not an import (imports need no hoisting), a copy of the binding identifier is pushed, plus `$$props` additionally for rest_prop bindings in runes mode. push_unique dedupes by name. In dev mode the function body is walked for Assignment/Update expressions; when validate_mutation returns something other than the node itself, `$$ownership_validator` is pushed and the walk stops. Returns the parameter identifier list.

**Notes.**

- contract: An in-code TODO flags the destructured-derived special case ('this code is bad, we need to kill it').

calls: [is_prop_source](r3-client-transform-utils.md#u-38b8a75ee741), [validate_mutation](r5-transform-client.md#u-a58215b09609)

**Uncertainties.**

- The shape check treats any read expression whose object is `$.get(<Identifier>)` as a destructured derived binding; other ways that shape can arise are not excluded here.

<a id="u-d03f333899de"></a>
### `get_prop_source`

`export function get_prop_source(binding, state, name, initial)` · [packages/svelte/src/compiler/phases/3-transform/client/utils.js:L175-L230][f1]

Builds a `$.prop($$props, name, flags?, initial?)` call for a prop or bindable_prop binding.

Flags accumulate: PROPS_IS_BINDABLE for bindable_prop, PROPS_IS_IMMUTABLE under analysis.immutable, PROPS_IS_RUNES under runes mode, and PROPS_IS_UPDATED when accessors are on or (immutable mode: reassigned, or mutated in runes mode; otherwise: updated) — i.e. someone may write the prop. When an initial value exists it is passed eagerly only if is_simple_expression; a zero-argument call's callee is passed directly, any other complex initial is wrapped in a thunk, and either lazy form sets PROPS_IS_LAZY_INITIAL. Flags and/or the initial argument are appended only when non-empty/defined.

**Notes.**

- condition: If neither flags nor initial arg apply, the call is just `$.prop($$props, name)`.

calls: [is_simple_expression](r4-compiler-ast-utils.md#u-410082960042)

<a id="u-38b8a75ee741"></a>
### `is_prop_source`

`export function is_prop_source(binding, state)` · [packages/svelte/src/compiler/phases/3-transform/client/utils.js:L238-L249][f1]

Decides whether a prop/bindable_prop binding needs an actual prop source rather than direct `$$props` access.

True in non-runes mode always (legacy props are sources); in runes mode true when the analysis has accessors, or the binding is reassigned, has an initial value, or was updated — the last because a legacy parent may provide coarse-grained reactivity.

<a id="u-4eba3d9b7ec5"></a>
### `is_state_source`

`export function is_state_source(binding, analysis)` · [packages/svelte/src/compiler/phases/3-transform/client/utils.js:L24-L29][f1]

Reports whether a `$state`/`raw_state` binding must keep its reactive read transformation.

Returns true only when the kind is state or raw_state and, in immutable mode, the binding was reassigned or the analysis enables accessors; in non-immutable mode it is always true for those kinds.

<a id="u-d089d4da67c8"></a>
### `should_proxy`

`export function should_proxy(node, scope)` · [packages/svelte/src/compiler/phases/3-transform/client/utils.js:L255-L287][f1]

Determines whether an expression's value should be wrapped in a reactivity proxy.

Returns false for missing nodes, literals, template literals, arrow/function expressions, unary and binary expressions, and the `undefined` identifier. For an identifier with a scope, the binding is inspected: if bound, never reassigned, and its initial is not a function/class declaration, import, EachBlock, or SnippetBlock, the decision recurses on that initial value (with null scope); otherwise it returns true, meaning unknown or mutable values get proxied.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/utils.js
