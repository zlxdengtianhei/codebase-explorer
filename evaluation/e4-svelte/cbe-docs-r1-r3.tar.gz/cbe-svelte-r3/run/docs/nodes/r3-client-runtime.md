# Client Runtime

**Capability.** Browser-side execution of compiled components: hydration cursors, template factories, attribute application, keyed/dynamic blocks, reactive prop and store access, mount/unmount lifecycle, and development-time diagnostics.

Navigate by concern: hydration/template/blocks/attributes own DOM mechanics; reactivity owns props and stores; render owns lifecycle entry; dev owns warnings and error boundaries.

**Children.**

- [Client Hydration State](r3-client-hydration.md) `r3-client-hydration` · 6 unit(s)
- [Client Template Factories](r3-client-template.md) `r3-client-template` · 11 unit(s)
- [Client Control Blocks and CSS](r3-client-blocks.md) `r3-client-blocks` · 3 unit(s)
- [Client Attribute Application](r3-client-attributes.md) `r3-client-attributes` · 17 unit(s)
- [Client Reactivity: Props and Stores](r3-client-reactivity.md) `r3-client-reactivity` · 0 unit(s)
- [Client Render Lifecycle](r3-client-render.md) `r3-client-render` · 3 unit(s)
- [Client Dev Diagnostics](r3-client-dev.md) `r3-client-dev` · 14 unit(s)

**Depended on by.**

- [Build and Audit Tooling](r3-build-tooling.md) · model-inferred · 0 edge(s)

Parent: [Runtime](r3-runtime.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
