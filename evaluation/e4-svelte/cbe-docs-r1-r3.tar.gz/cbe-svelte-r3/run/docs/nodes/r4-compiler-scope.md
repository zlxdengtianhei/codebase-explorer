# Scope and Binding Model

**Capability.** Builds and represents the lexical scope tree: per-name bindings with kinds and mutations, partial expression evaluation, rune recognition, and the AST walk that populates scopes and references.

Every analyze and transform phase queries scopes and bindings from here. Start with create_scopes to see how the tree is built, Scope/Binding for the data model, and get_rune/get_global_keypath for rune detection.

**Depends on.**

- [AST Manipulation Utilities](r4-compiler-ast-utils.md) · graph-confirmed · 11 edge(s)
- [Node Factories and Metadata Model](r4-compiler-node-model.md) · graph-confirmed · 1 edge(s)

**Depended on by.**

- [Shared Analysis Validation](r4-analyze-shared-validation.md) · graph-confirmed · 1 edge(s)
- [Semantic Analysis Visitors](r4-analyze-visitors.md) · graph-confirmed · 2 edge(s)
- [Node Factories and Metadata Model](r4-compiler-node-model.md) · model-inferred · 0 edge(s)
- [Client Code Transformation](r4-transform-client.md) · graph-confirmed · 16 edge(s)
- [Server \(SSR\) Code Transformation](r4-transform-server.md) · graph-confirmed · 9 edge(s)

Parent: [Compiler Pipeline](r4-compiler.md)

## Units (9)

<a id="u-0c91df12a429"></a>
### `Binding`

`class Binding` · [packages/svelte/src/compiler/phases/scope.js:L88-L140][f1]

Tracks one declared name: its declaring scope and identifier node, binding kind, declaration kind, initializer, references, and mutation flags.

`initial` records what the value was initialized with — for `let { foo = 'bar' } = $props()` it is 'bar', not the call. The constructor only assigns scope, node, initial, kind and declaration_kind; references and legacy_dependencies start empty, prop_alias and metadata start null. The `updated` getter returns true when either mutated or reassigned is set. is_function returns true only when the binding has never been updated and its initial is an ArrowFunctionExpression, FunctionExpression, or FunctionDeclaration; any mutation disqualifies it, since even reassignment to another function would make direct substitution (e.g. as an event handler) unsafe.

<a id="u-006193dba8b7"></a>
### `Evaluation`

`class Evaluation` · [packages/svelte/src/compiler/phases/scope.js:L172-L230][f1]

Result object of partial expression evaluation: a set of possible values plus derived query flags (is_known, has_unknown, is_defined, is_string, is_number, is_function) and `value`.

All flags are computed by the constructor from the populated values set; is_known holds only when exactly one non-symbol value is possible. Consumers use it to choose between an exact value and coarse type sentinels (STRING/NUMBER/FUNCTION).

<a id="u-ef478ddf5a1d"></a>
### `Evaluation.constructor`

`constructor(scope, expression, values)` · [packages/svelte/src/compiler/phases/scope.js:L230-L561][f1]

Partially evaluates one expression into a set of possible values, registering itself in the module-level current_evaluations map (removed at the end) so recursive Scope.evaluate calls on the same node cannot cycle.

Per expression type: Literal adds its value. Identifier resolves via scope.get: a binding initialized by a `$props.id()` call adds STRING; an EachBlock-initial binding where the node is the index adds NUMBER; if not updated, initialized, and not a prop/rest_prop/bindable_prop kind, it recursively evaluates the initializer; unresolved `undefined` adds undefined; otherwise UNKNOWN. BinaryExpression evaluates both sides: both known → exact value from the binary table; otherwise comparison operators (incl. in/instanceof) add {true,false}, arithmetic operators add NUMBER, and `+` adds STRING and/or NUMBER depending on operand type tags. ConditionalExpression picks the taken branch when the test is known, else unions both branches. LogicalExpression: both known → exact from the logical table; known left short-circuits for `&&` when falsy, `||` when truthy, `??` when non-null, else unions the right; unknown left unions both sides. UnaryExpression: known argument → unary table value; otherwise '!'/'delete' add {true,false}, '+','-','~' add NUMBER, typeof adds STRING, void adds undefined. CallExpression derives a keypath via get_global_keypath: runes are special-cased — $state/$state.raw/$derived evaluate the first argument (or add undefined), $props.id adds STRING, $effect.tracking adds {true,false}, $derived.by evaluates a concise arrow body else UNKNOWN, other runes UNKNOWN; known globals with no spread arguments call the recorded function when all args are known, else add the type tag; anything else UNKNOWN. TemplateLiteral concatenates cooked quasis with known values, degrading to STRING on the first unknown part. MemberExpression resolves only global constants like Math.PI. Functions add the FUNCTION tag; the default case adds UNKNOWN. Finally `value` becomes the last inserted value, the is_* flags are derived per value (symbol sentinels and UNKNOWN clear the respective flags; null/undefined/UNKNOWN clear is_defined), is_known is cleared when more than one value exists or the single value is a symbol, and the entry is removed from current_evaluations.

uses: [scope.js module code (L757–L809)][f1], [Scope](r4-compiler-scope.md#u-01a82e58170d); calls: [get_rune](r4-compiler-scope.md#u-5204b6ce4f7a)

**Uncertainties.**

- Prop-like binding kinds ('prop', 'rest_prop', 'bindable_prop') are matched by name only; their semantics live outside this file
- 'Math.f16round' is registered behind a @ts-ignore, so its runtime existence on all targets is unproven here

<a id="u-01a82e58170d"></a>
### `Scope`

`class Scope` · [packages/svelte/src/compiler/phases/scope.js:L564-L618][f1]

One lexical scope holding declarations, declarator-to-binding mappings and references, linked to a parent scope and a shared ScopeRoot.

The constructor stores root/parent/porous and computes function_depth as parent.depth + (porous ? 0 : 1), 0 at the root, so porous (var-like/block) scopes do not increase function depth. declare(node, kind, declaration_kind, initial): `var` in a porous scope recurses to the parent, and `import` declarations always recurse to the parent; at the destination scope a duplicate name raises e.declaration_duplicate unless either the existing or new declaration_kind is 'var'; then it creates a Binding, runs validate_identifier_name on it, stores it, and records the name in root.conflicts. child(porous=false) returns a new nested Scope. generate(preferred_name) delegates to the parent when porous; otherwise sanitizes the name (invalid chars to '_', leading digit to '_'), loops appending _n suffixes while the name collides with local references, local declarations, root.conflicts, or is_reserved; registers the chosen name and returns it. get(name) walks the parent chain and returns the Binding or null. get_bindings(node) returns the declarators entry for a VariableDeclarator or LetDirective and throws 'No binding found for declarator' if absent. owner(name) returns the nearest scope (this or an ancestor) that declares the name, else null. reference(node, path) copies the path (so later mutation does not affect the stored reference), appends the reference to this scope's references map, then either records it on a local binding's references list, recurses to the parent, or — at the top level with no binding — adds the name to root.conflicts as a global. evaluate(expression, values) returns the existing Evaluation when the same expression is already being evaluated (cycling guard recorded in current_evaluations) and otherwise constructs a new Evaluation that populates the values set.

calls: [Evaluation.constructor](r4-compiler-scope.md#u-ef478ddf5a1d); uses: [Binding](r4-compiler-scope.md#u-0c91df12a429)

**Uncertainties.**

- validate_identifier_name's error conditions are defined in another file

<a id="u-8f49475011d6"></a>
### `ScopeRoot`

`class ScopeRoot` · [packages/svelte/src/compiler/phases/scope.js:L810-L817][f1]

Per-component root holding a `conflicts` set of names that must stay unique across the whole component.

Its unique(preferred_name) sanitizes the name (invalid characters become '_'), loops appending _n suffixes while the name is in conflicts, registers the final name, and returns a builder identifier (b.id) for it. Unlike Scope.generate it does not consult reserved words or scope-local references — only the conflicts set.

<a id="u-a24fbf023b97"></a>
### `create_scopes`

`export function create_scopes(ast, root, allow_reactive_declarations, parent)` · [packages/svelte/src/compiler/phases/scope.js:L838-L868][f1]

Walks the AST once to build the scope tree, declaring bindings, collecting references, updates and legacy reactive declarations, and returns { has_await, scope, scopes } where scopes maps nodes to their associated Scope (a node in the map did not necessarily create a scope).

Declarations: ImportDeclaration specifiers declare with 'import' kind; FunctionDeclaration declares its id in the outer scope with its node as initial before opening a child scope, while FunctionExpression declares its own id inside its scope; ArrowFunctionExpression opens a scope without declaring; all three declare parameters via add_params, which extracts identifiers from each pattern using kind 'rest_param' for RestElement parameters else 'param'. ForStatement/ForInStatement/ForOfStatement/SwitchStatement open porous block scopes via create_block_scope; BlockStatement skips the extra scope when its parent is already a function. ClassDeclaration declares its id as 'let'. VariableDeclaration declares each extracted identifier with the declaration's kind ('template' binding kind under a ConstTag) and stores is_template_declaration metadata; CatchClause opens a porous scope and declares the caught param as 'let' only when a param exists. EachBlock first visits the expression, then opens a scope: context identifiers become 'each'/'const' bindings, each probed by a nested walk to record inside_rest metadata when the identifier sits after a RestElement; initializer references are picked up by visiting the context; node.index is declared as 'static' unless a differing key expression makes it 'template'; finally metadata is attached including a unique $$index name from scope.root.unique. AwaitBlock declares each value/error pattern in both the corresponding then/catch scope (as 'template') and a fresh child scope (as 'normal'). SnippetBlock declares the snippet expression as a function binding, opens a child scope, and declares parameters as 'snippet'/'let'. Fragment opens a child scope that is porous when metadata.transparent. SvelteFragment, SlotElement, SvelteElement and RegularElement each open a non-porous child scope. Component/SvelteSelf/SvelteComponent first reference the component name, store metadata.scopes.default, and route LetDirectives and slotted children through per-slot child scopes chosen via determine_slot; otherwise attributes and children visit under the default scope. References: the Identifier visitor collects only genuine is_reference identifiers whose parent is not TS-prefixed, deferring them to a post-pass (after the walk so declarations can precede uses); SvelteDirective (Transition/Animate/Use) references the directive name prefix immediately; StyleDirective references its name only in the shorthand `style:height` form (value === true). Updates: AssignmentExpression, UpdateExpression and BindDirective push their target; the post-pass unwraps each pattern, resolves the base object name to a binding, and marks it reassigned when the target is the binding's own identifier or mutated when it is a member expression. LabeledStatement creates a scope for top-level `$:` blocks (only when allow_reactive_declarations) and collects assignment targets not starting with '$' as possible implicit declarations, which afterwards are declared 'legacy_reactive'/'let' unless already bound. AwaitExpression sets has_await when every ancestor on the path is non-function, piggybacking runes-mode opt-in on this walk. SvelteFragment is a small helper opening a scope for element-like nodes.

uses: [Scope](r4-compiler-scope.md#u-01a82e58170d), [get_global_keypath](r4-compiler-scope.md#u-7baae8d843b4)

**Uncertainties.**

- SnippetBlock declares node.expression as a binding, which per its type is expected to be an identifier; validation of that assumption is elsewhere
- LetDirective references are recorded with a hand-built path slice, whose exact path semantics depend on the zimmerframe context shape

<a id="u-7baae8d843b4"></a>
### `get_global_keypath`

`function get_global_keypath(node, scope)` · [packages/svelte/src/compiler/phases/scope.js:L1359-L1382][f1]

Builds a dotted keypath from a callee or member chain to decide whether an expression names a global or rune.

Walking MemberExpressions leftward, a computed member or non-Identifier property aborts with null; each property accumulates as '.name'. If the innermost node is a CallExpression with an Identifier callee, '()' is prefixed (yielding e.g. 'Math.floor()'). Anything other than a final plain Identifier yields null, including Super. Finally the identifier is resolved in the scope: a local binding returns null (rune-like names referencing variables/stores are rejected); otherwise the composed 'name' + suffix is returned.

**Uncertainties.**

- The binding check uses `binding !== null`, but Scope.get can return undefined only via `?? null` so in practice null; relies on that contract

<a id="u-5204b6ce4f7a"></a>
### `get_rune`

`export function get_rune(node, scope)` · [packages/svelte/src/compiler/phases/scope.js:L1344-L1352][f1]

Returns the rune name (e.g. '$derived') when the given node is a CallExpression whose callee forms a rune keypath, else null.

Null/non-CallExpression input yields null immediately; otherwise the callee keypath comes from get_global_keypath and must pass is_rune. A name that looks like a rune but resolves to a local binding is rejected inside get_global_keypath, so shadowed runes return null.

calls: [get_global_keypath](r4-compiler-scope.md#u-7baae8d843b4)

<a id="u-2bb6e1e761ba"></a>
### `set_scope`

`export function set_scope(node, { next, state })` · [packages/svelte/src/compiler/phases/scope.js:L1334-L1337][f1]

Generic visitor helper that re-targets the traversal scope for a node: it looks the node up in state.scopes and calls next() with a shallow-copied state carrying that scope when a different scope was found, else continues with the unchanged state.

Nodes without a mapped scope keep the current scope.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/scope.js
