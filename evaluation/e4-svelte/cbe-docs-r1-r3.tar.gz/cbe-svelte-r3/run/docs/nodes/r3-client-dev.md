# Client Dev Diagnostics

**Capability.** Development-only safety nets: stale-assignment warnings for =/&&=/||=/??=, legacy component API guards, snippet argument validation, effect error routing through boundaries with cached diagnostics, and the reactive proxy test suite.

These units are compiled out of production paths in effect; use them to understand dev warnings and error boundaries. assign.js helpers share the compare-based warning wrapper.

Parent: [Client Runtime](r3-client-runtime.md)

## Units (14)

<a id="u-d4a793369eef"></a>
### `assign-js-stale-assignment-helpers`

`function compare(a, b, property, location)` · [packages/svelte/src/internal/client/dev/assign.js:L12-L18][f1]

Dev-mode helpers that execute reactive property assignments (=, &&=, ||=, ??=) and warn when the assignment result disagrees with an untracked re-read of the property.

Each wrapper assigns, then calls compare with an untracked getter so the warning check does not create reactive dependencies; compare always returns the written value so the assignment semantics are unchanged. All four wrappers share the identical shape and differ only in the compound-assignment operator.

<a id="u-bfbd0405b55e"></a>
### `assign`

`export function assign(object, property, value, location)` · [packages/svelte/src/internal/client/dev/assign.js:L26-L33][f1]

Performs object[property] = value, then compares the written value with an untracked re-read of object[property] via compare, warning if a stale/proxied value mismatch is detected.

The assignment is evaluated before the untracked read, so reactivity is intentionally not tracked during the comparison. Returns the value produced by the assignment (compare returns its first argument).

calls: [compare](r3-client-dev.md#u-26b67bf9b7a4), [runtime-js-state-and-helpers](r2-reactivity-core.md#u-6cd2387802ec)

<a id="u-dd5d7b9dc93a"></a>
### `assign_and`

`export function assign_and(object, property, value, location)` · [packages/svelte/src/internal/client/dev/assign.js:L41-L48][f1]

Implements object[property] &&= value with the same stale-value warning wrapper: performs the logical-AND assignment, then compares against an untracked re-read via compare.

Because &&= only writes when the current value is truthy, the untracked read only diverges from the written value in the same cases the compound assignment itself would warn about in other wrappers. Returns the resulting value of the assignment expression.

calls: [compare](r3-client-dev.md#u-26b67bf9b7a4), [runtime-js-state-and-helpers](r2-reactivity-core.md#u-6cd2387802ec)

<a id="u-45cc0179e4fb"></a>
### `assign_nullish`

`export function assign_nullish(object, property, value, location)` · [packages/svelte/src/internal/client/dev/assign.js:L71-L78][f1]

Implements object[property] ??= value with the same stale-value warning wrapper: performs the nullish-coalescing assignment, then compares the result against an untracked re-read via compare, warning on mismatch.

Returns the value of the assignment expression.

calls: [compare](r3-client-dev.md#u-26b67bf9b7a4), [runtime-js-state-and-helpers](r2-reactivity-core.md#u-6cd2387802ec)

<a id="u-4a4dece8eb22"></a>
### `assign_or`

`export function assign_or(object, property, value, location)` · [packages/svelte/src/internal/client/dev/assign.js:L56-L63][f1]

Implements object[property] ||= value with the same stale-value warning wrapper: performs the logical-OR assignment, then compares the result against an untracked re-read via compare, warning on mismatch.

Returns the value of the assignment expression.

calls: [compare](r3-client-dev.md#u-26b67bf9b7a4), [runtime-js-state-and-helpers](r2-reactivity-core.md#u-6cd2387802ec)

<a id="u-26b67bf9b7a4"></a>
### `compare`

`function compare(a, b, property, location)` · [packages/svelte/src/internal/client/dev/assign.js:L12-L18][f1]

Warns in dev builds when an assignment result differs from an untracked re-read of the property, indicating a stale reactive value was written.

Takes the written value, a freshly-read value, the property name, and a compile-time location string; when the two differ it emits assignment_value_stale with a sanitized location. Always returns the first argument, so callers preserve the assigned value regardless of the warning.

calls: [utils-js-predicates](r3-shared-utils.md#u-7eb274f609ad); uses: [assign](r3-client-dev.md#u-bfbd0405b55e)

<a id="u-bcccf8325ff4"></a>
### `check_target`

`export function check_target(target)` · [packages/svelte/src/internal/client/dev/legacy.js:L6-L10][f2]

Dev guard against calling a compiled component with new when the legacy class API is unsupported: if target is truthy it raises component_api_invalid_new using the component's FILENAME (or 'a component' when absent) and its function name.

uses: [packages/svelte/src/internal/client/dev/legacy.js:legacy_api](r3-client-dev.md#u-f5251f9e9e18)

<a id="u-f5251f9e9e18"></a>
### `packages/svelte/src/internal/client/dev/legacy.js:legacy_api`

`export function legacy_api()` · [packages/svelte/src/internal/client/dev/legacy.js:L18-L25][f2]

Builds the legacy component API surface for dev builds: resolves the current component's function from component_context and returns an object whose $destroy, $on, and $set members each throw component_api_changed naming the method and the component's FILENAME.

The inner error closure reads component[FILENAME] lazily at call time; if component_context was undefined, component is undefined and the read would throw a TypeError rather than the intended error.

**Notes.**

- contract: Every returned method unconditionally raises; none implement actual legacy behavior.

uses: [function::component_context::0][f3]

**Uncertainties.**

- Behavior when component_context is null: component is undefined, so error() would throw a TypeError instead of a Svelte error; source does not guard this.

<a id="u-a46097177ac6"></a>
### `validate_snippet_args`

`export function validate_snippet_args(anchor, ...args)` · [packages/svelte/src/internal/client/dev/validation.js:L6-L16][f4]

Dev validation for snippet invocations: raises invalid_snippet_arguments when the first argument is not a Node instance (a non-object also fails this check), and raises the same error for any subsequent argument that is not a function (snippet parameters must be snippets, i.e. functions).

Performs no validation beyond these two shapes and returns nothing; errors propagate from the shared errors module.

imports: [validation.js module code (L1–L5)][f4]

**Uncertainties.**

- Behavior when anchor is a Node from a different realm (different Node constructor) depends on instanceof across realms, not resolvable here.

<a id="u-1b3b4fa2c18e"></a>
### `handle_error`

`export function handle_error(error)` · [packages/svelte/src/internal/client/error-handling.js:L15-L44][f5]

Routes an error thrown during effect execution to the appropriate handler.

When there is no active effect, it flags the active reaction (cast to Derived) with ERROR_VALUE so the error surfaces later on read, and returns the error. In DEV, the first time an Error is handled for a given effect, diagnostics (component stack and filtered stack) are computed by get_adjustments and cached in the adjustments WeakMap. If the effect has not yet run: when it is not a boundary effect, apply_adjustments runs only when it has no parent, then the error is rethrown to bubble outward; when it is a boundary effect, the boundary's error method receives it. If the effect has already run, invoke_error_boundary walks the effect tree itself.

**Notes.**

- failure: Rethrowing when the effect has not run means callers up the stack receive the original error unless a boundary effect intercepts it.

calls: [get_adjustments](r3-client-dev.md#u-d2e928a5c137), [invoke_error_boundary](r3-client-dev.md#u-8ed809bdafb5), [apply_adjustments](r3-client-dev.md#u-1f031c007120)

**Uncertainties.**

- Behavior when active_reaction is not a Derived in the effect===null branch is not guarded in this code

<a id="u-1f031c007120"></a>
### `apply_adjustments`

`function apply_adjustments(error)` · [packages/svelte/src/internal/client/error-handling.js:L104-L116][f5]

Overwrites an Error's message and stack with previously cached diagnostics from the adjustments WeakMap, using define_property for each; errors with no cached entry are left untouched.

<a id="u-d2e928a5c137"></a>
### `get_adjustments`

`function get_adjustments(error, effect)` · [packages/svelte/src/internal/client/error-handling.js:L76-L99][f5]

Builds development-only diagnostics for an error thrown inside an effect.

If the error's message property is not configurable it returns undefined rather than risk a secondary error hiding the original. Otherwise it builds a component stack: the effect function's name (or '<unknown>'), then each ancestor context's filename basename, indented with two spaces on Firefox or a tab elsewhere. The result pairs an augmented message with a stack that has lines containing 'svelte/src/internal' filtered out.

**Uncertainties.**

- Whether error.stack is always a string is assumed by the optional chaining and empty-string fallback of the join

<a id="u-8ed809bdafb5"></a>
### `invoke_error_boundary`

`export function invoke_error_boundary(error, effect)` · [packages/svelte/src/internal/client/error-handling.js:L50-L69][f5]

Delivers an error to the nearest boundary effect, walking up the effect parent chain.

For each effect with the BOUNDARY_EFFECT flag it calls the boundary's error method inside try/catch; if that handler itself throws, the thrown value replaces the error and the walk continues upward. When no boundary handles the error, any Error gets its diagnostics applied via apply_adjustments, then the (possibly replaced) error is thrown to the caller.

**Notes.**

- failure: An exception thrown by a boundary's error handler is treated as a new error and propagates to the next ancestor boundary, or out of the tree entirely.

calls: [apply_adjustments](r3-client-dev.md#u-1f031c007120)

<a id="u-221593ac88d4"></a>
### `proxy.test.ts module code (L22–L133)`

`const original = { count: 0, get x()` · [packages/svelte/src/internal/client/proxy.test.ts:L16-L22][f6]

Vitest suite for the reactive proxy helper.

Observed expectations: mutating the proxy does not mutate the original object; getters on the original are preserved and re-invoked per read (counts incremented on each access) without affecting the original's own properties; defineProperty on the proxy produces a configurable, writable, enumerable descriptor on the proxy while the original gains nothing, and redefining a proxied property with accessors throws /state_descriptors_fixed/; wrapping an existing proxy does not re-proxy (nested reads and mutations stay shared); delete removes only the proxy's copy and deleting a non-existent key succeeds; array push and index writes append to the proxy without touching the original array; shrinking proxy length clears the proxy view only, leaving the original intact.

**Notes.**

- contract: The tests assert copy-on-write proxy semantics: reads and writes hit a copied state object while the original stays frozen at wrap time.

**Uncertainties.**

- These are test expectations; they constrain but do not prove proxy implementation behavior outside the tested cases

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dev/assign.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dev/legacy.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/context.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dev/validation.js
[f5]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/error-handling.js
[f6]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/proxy.test.ts
