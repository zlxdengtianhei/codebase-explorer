# Reactive Wrapper Classes

**Capability.** Framework wrapper classes whose reads register dependencies and writes trigger effects: SvelteDate tracking its time value, SvelteMap tracking contents (shallow), SvelteURL tracking URL properties, plus the SvelteDate behavior test suite.

Use when effects do not re-run (or over-run) on mutations of these classes. Reads are tracked; stored values inside SvelteMap are not made deeply reactive, and the date tests exercise that contract against SvelteMap semantics.

**Depends on.**

- [Motion \(Spring & Tween\)](r1-motion.md) · model-inferred · 0 edge(s)
- [Signal Reactivity Core](r5-client-reactivity.md) · graph-only · 37 edge(s)
- [Reactivity Core & Batching](r2-reactivity-core.md) · graph-only · 26 edge(s)
- [Runtime Dev-Mode Instrumentation](r4-runtime-dev.md) · graph-only · 19 edge(s)

Parent: [Public & Authoring APIs](r1-public-api.md)

## Units (4)

<a id="u-cb648e924acc"></a>
### `SvelteDate`

`class SvelteDate extends Date` · [packages/svelte/src/reactivity/date.js:L42-L51][f1]

A Date subclass that tracks its time value in a reactive source (#time, initialized from super.getTime()) so reads in effects/deriveds re-run when the date changes.

The constructor delegates to super, tags #time in DEV, and lazily runs #init once per module (module-level inited flag) to patch SvelteDate.prototype. #init walks Object.getOwnPropertyNames(Date.prototype) and installs two wrapper kinds on the subclass prototype: for methods named get*, to*, or valueOf, a reader that, when called with arguments, only reads #time and applies the native method unmemoized; when called with no arguments, it lazily creates a derived — created as though during instance construction by temporarily restoring this.#reaction (captured as active_reaction at construction) — that reads #time and applies the native method, caches it in #deriveds per method name, and returns get(d). For methods named set*, the wrapper applies the native mutator and then sets #time to the resulting getTime, invalidating dependent deriveds and effects. Result: no-argument getters are memoized per instance; mutating calls propagate reactivity.

**Uncertainties.**

- Whether every relevant Date method is covered depends on the runtime's own-property list of Date.prototype and the get/to/set/valueOf prefix heuristic; methods not matching those prefixes are not reactive.

<a id="u-73239a2f8b44"></a>
### `date-test-ts-date-test-ts`

`const expect_all_changes_to_be_false = () =>` · [packages/svelte/src/reactivity/date.test.ts:L478-L482][f2]

Vitest suite for SvelteDate reactivity.

Each test builds a SvelteDate from a fixed initial date, registers render effects inside an effect_root that log getter values, mutates via setters inside flushSync blocks, and asserts the accumulated log. It asserts that setters called with unchanged values fire no extra effects, that carryover mutations (setSeconds(60/61), setMonth(13), setFullYear with month arg) propagate to dependent getters, that each Date getter is tracked fine-grained (first-time-in-derived and shared-between-deriveds cases included), and valueOf/toLocaleString/instanceof behavior.

uses: [map-js-sveltemap](r1-reactive-collections.md#u-a8d1fced426f)

**Uncertainties.**

- SvelteDate is not in this batch; effect-firing granularity is asserted by tests, not verifiable from supplied source

<a id="u-a8d1fced426f"></a>
### `map-js-sveltemap`

`class SvelteMap extends Map` · [packages/svelte/src/reactivity/map.js:L53-L63][f3]

Reactive Map subclass: reading contents (get/has/iteration/size) registers dependencies so effects and deriveds re-run on mutation; stored values are not deeply reactive.

It keeps a per-key Map of numeric sources, a version source, and a size source; #update_version snapshots the global update_version so #source can pick state (non-dependency, same-reaction creation) versus source (dependency). Reads: get/has lazily create a per-key source when the backing value is defined; when absent-or-undefined they read the version instead (so later insertion re-runs the reader) and return false/undefined. Writes: set stores via super.set unconditionally; a new key creates a source, resyncs #size and increments the version; an existing key with a changed value increments its key source and also increments the version when some of the key source's reactions do not already watch the version (reaction-set comparison). delete and clear reset affected key sources to -1, resync size, and bump version; clear is a no-op on an empty map. forEach/values/entries track every key via #read_all (which fills missing per-key sources when #size and sources diverge); keys and [Symbol.iterator] track only the version via keys(). In DEV, the constructor copies the iterable through the native Map first, so invalid input throws the native exception, and sources are tagged for debugging.

uses: [map-test-ts-map-test-ts](r2-reactive-primitives.md#u-4e96c589c3f1)

**Uncertainties.**

- state/source/increment/get come from modules outside this batch; their invalidation semantics are inferred from tests and inline comments
- get/has key a key mapped to undefined as absent because the branch tests ret !== undefined
- set's version-increment decision assumes s.reactions entries are the same objects as version.reactions entries (runtime.js bookkeeping not visible)

<a id="u-179058c594bc"></a>
### `url-js-svelteurl-and-helpers`

`export function get_current_url()` · [packages/svelte/src/reactivity/url.js:L10-L13][f4]

Reactive URL subclass extending URL: reading properties (href, host, pathname, search, etc.) in effects/deriveds re-runs when the URL changes.

Eight component states (#protocol, #username, #password, #hostname, #port, #pathname, #hash, #search) are initialized from the parsed URL; #searchParams is a SvelteURLSearchParams seeded from the URL's searchParams. Getters get the relevant states before returning the super value (host reads hostname and port; origin reads protocol, hostname and port; href reads all eight). Setters assign to super and set the affected states from the re-parsed super values; href and search setters also call #searchParams[REPLACE]\(super.searchParams) so the params object stays in sync. toString and toJSON return this.href. The module keeps a current_url variable set during construction and cleared after; get_current_url returns it (exported as a function because, per the comment, Vitest does not respect live bindings). In DEV the constructor tags all eight states for debugging.

**Notes.**

- side_effect: The constructor mutates the module-level current_url while building #searchParams, so a SvelteURLSearchParams created during construction can observe which URL it belongs to via get_current_url.

uses: [set-js-svelteset](r5-client-reactivity.md#u-3d5a1739f21d)

**Uncertainties.**

- get_current_url is consumed by url-search-params.js (not fully supplied); the lifetime guarantee of current_url outside construction is unverified
- search setter passes the raw value to set(#search, value) while other setters normalize via super; whether that asymmetry is observable is unclear

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/reactivity/date.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/reactivity/date.test.ts
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/reactivity/map.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/reactivity/url.js
