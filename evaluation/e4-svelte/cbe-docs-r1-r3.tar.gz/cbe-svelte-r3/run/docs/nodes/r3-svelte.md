# Svelte Compiler and Runtime

**Capability.** The Svelte framework codebase: compiling component source through parse/analyze/transform phases, running the generated code on client and server runtimes, plus shared public utilities and repository tooling.

Start here to navigate the repository. The compiler subtree covers source-to-JS compilation and migration; the runtime subtree covers client and server execution of compiled output; shared utilities and tooling are kept separate from their consumers.

**Children.**

- [Compiler Pipeline](r3-compiler.md) `r3-compiler` · 0 unit(s)
- [Runtime](r3-runtime.md) `r3-runtime` · 0 unit(s)
- [Shared Utilities and Public Contracts](r3-shared.md) `r3-shared` · 0 unit(s)
- [Repository Tooling](r3-tooling.md) `r3-tooling` · 0 unit(s)

**Depended on by.**

- [Build and Audit Tooling](r3-build-tooling.md) · within containment · 2 edge(s)

Parent: [Server & Shared Runtime](server-and-shared-runtime.md)

## Units (1)

<a id="u-df4ca4955d27"></a>
### `check-treeshakeability.js-bundle-code`

`async function bundle_code(entry)` · [packages/svelte/scripts/check-treeshakeability.js:L12-L13][f1]

Builds a Rollup bundle from an in-memory entry source string and returns the bundled JavaScript so callers can test whether an import tree shakes to nothing.

The entry is served by @rollup/plugin-virtual as module '__entry__'. A custom 'resolve-svelte' plugin hook rewrites importees starting with 'svelte': it looks up pkg.exports with 'svelte' replaced by '.', resolves to an absolute path, and prefers the export's 'browser' entry over 'default'; importees not starting with 'svelte' return undefined and fall through to nodeResolve with exportConditions ['production','import','browser','default']. Warnings with code 'EMPTY_BUNDLE' or 'CIRCULAR_DEPENDENCY' are silently dropped; all others are passed to handle. After generate(), more than one output chunk throws a generic Error; otherwise the single chunk's code is returned trimmed. pkg is read from package.json at module scope before any bundling.

calls: [check-treeshakeability.js module code (L46–L124)](r3-build-tooling.md#u-65c13f088150)

**Uncertainties.**

- pkg.exports entry shape (browser/default fields) is assumed from usage; a missing entry would throw at path.resolve.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/scripts/check-treeshakeability.js
