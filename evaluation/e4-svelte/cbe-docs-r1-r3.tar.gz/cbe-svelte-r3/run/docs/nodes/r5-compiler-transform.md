# Transform Phase

**Capability.** Converts an analyzed component into printable output, choosing client-side reactive DOM code or server-side payload rendering, with entry points that assemble CompileResults and merge source maps.

Use when changing generated output. The entry node owns the public transform_component/transform_module API and sourcemap integration; client and server visitor subtrees own per-node code generation for their targets.

**Children.**

- [Transform Entry & Result Assembly](r5-transform-entry.md) `r5-transform-entry` · 4 unit(s)
- [Client Codegen Visitors](r5-transform-client.md) `r5-transform-client` · 25 unit(s)
- [Server Codegen Visitors](r5-transform-server.md) `r5-transform-server` · 6 unit(s)

Parent: [Compiler Pipeline](r5-compiler.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
