# Client Transform

**Capability.** Lowers the analyzed AST into client-side JS: the shared transform utilities (node cleaning, namespace inference, const-tag ordering, $inspect lowering, TransformState), the DOM-building client visitors, and the event-attribute serialization helpers.

Use this subtree to understand what JS a template compiles to in the browser. Fragment/SvelteElement/SnippetBlock visitors plus shared/events build the DOM template; transform/utils supplies clean_nodes and namespace decisions consumed by client and server passes alike.

**Depends on.**

- [Template Analysis](r2-analyze-phase.md) · model-inferred · 0 edge(s)
- [Compiler Foundations](r2-compiler-foundations.md) · model-inferred · 0 edge(s)

**Depended on by.**

- [Sandbox Playground](r2-playgrounds.md) · model-inferred · 0 edge(s)
- [Server Transform](r2-server-transform.md) · graph-confirmed · 2 edge(s) · the server transform reuses shared clean_nodes and infer_namespace helpers from the client transform utilities.

Parent: [Svelte Compiler](r2-compiler.md)

## Units (32)

<a id="u-163781a2b736"></a>
### `packages/svelte/src/compiler/phases/3-transform/types.d.ts:types.d.ts module code (L1–L4)`

`module_region` · [packages/svelte/src/compiler/phases/3-transform/types.d.ts:L1-L4][f1]

Declares TransformState, the shared state object threaded through the transform phase: the Analysis, validated compile options, current Scope, a per-node Map of scopes, and a map of reactive state_fields.

Type-only; no runtime behavior.

<a id="u-4d2ca4b916bc"></a>
### `packages/svelte/src/compiler/phases/3-transform/utils.js:utils.js module code (L1–L23)`

`module_region` · [packages/svelte/src/compiler/phases/3-transform/utils.js:L1-L23][f2]

Type-only JSDoc imports plus imports of regex patterns, builders, errors, zimmerframe walk, AST helpers, cycle detection, is-reference, scope, and dev state.

Non-behavioral.

<a id="u-2276424862bf"></a>
### `utils.js module code (L33–L39)`

`module_region` · [packages/svelte/src/compiler/phases/3-transform/utils.js:L33-L39][f2]

Residual region between is_hoisted_function and sort_const_tags (lines 33–39); no behavioral symbol listed.

<a id="u-c0d789fcc841"></a>
### `utils.js module code (L128–L144)`

`module_region` · [packages/svelte/src/compiler/phases/3-transform/utils.js:L128-L144][f2]

Residual region between sort_const_tags and clean_nodes (lines 128–144); no behavioral symbol listed.

<a id="u-b9dd511b4830"></a>
### `is_hoisted_function`

`export function is_hoisted_function(node)` · [packages/svelte/src/compiler/phases/3-transform/utils.js:L24-L33][f2]

Returns true only when the node is an arrow function, function expression, or function declaration whose metadata.hoisted flag is exactly true; all other node types return false.

<a id="u-ecb5f24829a9"></a>
### `utils.js-sort-const-tags`

`function sort_const_tags(nodes, state)` · [packages/svelte/src/compiler/phases/3-transform/utils.js:L40-L67][f2]

Reorders ConstTag nodes within a node list into topological order, matching Svelte 4 behavior, and is only invoked when the analysis is not in runes mode.

Each ConstTag's declared identifiers are resolved to bindings via state.scope.get, and its initializer is walked (with set_scope re-establishing scopes) collecting referenced bindings as dependencies. Non-ConstTag nodes are collected separately. If no const tags exist the input list is returned unchanged. Edges are built between tags whose dependencies are themselves const-tag bindings; check_graph_for_cycles detects dependency cycles and, when one exists, e.const_tag_cycle throws an error listing the binding names in a 'a → b' chain. Otherwise a recursive add() emits each tag after its dependencies, producing [...sorted, ...other]. A tag may map multiple declared bindings to the same Tag entry, and later duplicate bindings overwrite earlier map entries.

**Notes.**

- failure: A dependency cycle among const tags aborts compilation via e.const_tag_cycle rather than being resolved.
- condition: When the same binding is declared by two const tags, the later tag wins in the tags Map because Map.set overwrites.

calls: [extract_identifiers](r4-compiler-ast-utils.md#u-90eb95affc00), [check_graph_for_cycles](r5-analyze-visitors.md#u-9450956ffc9b); uses: [clean_nodes](r2-client-transform.md#u-2ed26069223c)

**Uncertainties.**

- extract_identifiers and check_graph_for_cycles internals are outside the supplied source.
- Whether the recursion in add() can infinitely recurse on malformed graphs is not proven; cycle detection should prevent it but that helper is unproven.

<a id="u-2ed26069223c"></a>
### `clean_nodes`

`export function clean_nodes( parent, nodes, path, namespace = 'html', state, // TODO …` · [packages/svelte/src/compiler/phases/3-transform/utils.js:L145-L324][f2]

Splits a node list into hoisted and regular nodes and trims whitespace according to fixed rules, returning {hoisted, trimmed, is_standalone, is_text_first}.

Unless runes mode is active the list is first topologically sorted via sort_const_tags. Comments are dropped unless preserve_comments; ConstTag, DebugTag, svelte:body/window/document/head, TitleElement, and SnippetBlock nodes are hoisted; everything else stays regular. When whitespace is not preserved: whitespace-only leading/trailing text nodes are removed, boundary text nodes are stripped of leading/trailing whitespace, and interior text nodes have their edge whitespace collapsed to a single space — except adjacent to an ExpressionTag or after a text ending in whitespace, where it is removed — and dropped entirely when can_remove_entirely (svg context outside any <text> element, or inside select/tr/table/tbody/thead/tfoot/colgroup/datalist). Additional special cases: a lone leading newline in a <pre> is discarded because the browser strips it; a lone script element gains an empty Comment sibling so runtime script-replacement logic always has a parent; a single non-dynamic RenderTag, or a non-dynamic Component without hmr and without dash-prefixed attributes, marks is_standalone; and for block/component parents whose first node is text or an expression tag, is_text_first signals that an anchor comment is needed.

**Notes.**

- side_effect: Mutates the input Text nodes' raw and data properties in place during trimming.
- contract: preserve_whitespace and preserve_comments have no defaults; callers must pass state.options values (per the TODO comment).

calls: [utils.js-sort-const-tags](r2-client-transform.md#u-ecb5f24829a9)

**Uncertainties.**

- Exact behavior of is_standalone/is_text_first consumers lives in Fragment/RegularElement visitors outside this source.
- The TODO comment implies state typing is not yet precise; consequences of passing partial state are unproven.

<a id="u-b0bc5038f26b"></a>
### `infer_namespace`

`export function infer_namespace(namespace, parent, nodes)` · [packages/svelte/src/compiler/phases/3-transform/utils.js:L332-L378][f2]

Infers the namespace for a node's children used when creating a fragment.

foreignObject always forces 'html'. Regular and Svelte elements use their computed metadata: svg metadata yields 'svg', mathml metadata yields 'mathml', otherwise 'html'. For namespace-resetting parents (Fragment, Root, Component, SvelteComponent, SvelteFragment, SnippetBlock, SlotElement) the children are scanned via check_nodes_for_namespace with 'keep'; a definite result other than 'keep'/'maybe_html' is returned. Otherwise the direct RegularElement children vote: any non-svg/mathml element returns 'html' immediately; consistent svg or mathml elements yield that namespace; mixed or no element results fall back to the passed-in namespace.

calls: [utils.js-check-nodes-for-namespace](r2-client-transform.md#u-8bded2d505aa)

**Uncertainties.**

- Whether the direct-children loop should recurse into non-element wrappers (e.g. blocks) is not visible; it iterates only top-level nodes.

<a id="u-ecf464c3b3b6"></a>
### `utils.js module code (L324–L331)`

`module_region` · [packages/svelte/src/compiler/phases/3-transform/utils.js:L324-L331][f2]

Residual region between clean_nodes and infer_namespace (lines 324–331); no behavioral symbol listed.

<a id="u-98867614e9b4"></a>
### `utils.js module code (L378–L386)`

`module_region` · [packages/svelte/src/compiler/phases/3-transform/utils.js:L378-L386][f2]

Residual region between infer_namespace and check_nodes_for_namespace (lines 378–386); no behavioral symbol listed.

<a id="u-8bded2d505aa"></a>
### `utils.js-check-nodes-for-namespace`

`function check_nodes_for_namespace(nodes, namespace)` · [packages/svelte/src/compiler/phases/3-transform/utils.js:L387-L392][f2]

Heuristic scan that returns either the current namespace, 'html', or 'maybe_html': if any non-svg/non-mathml regular or svelte element is found, the result becomes 'html' and traversal stops; if the incoming namespace is 'keep' and only svg/mathml elements are seen, it takes that namespace; any non-whitespace Text marks it 'maybe_html'.

Each top-level node is walked with a visitor that only descends into EachBlock, IfBlock, AwaitBlock, Fragment, KeyBlock, RegularElement, SvelteElement, and Text, so other node types are pruned. The loop short-circuits as soon as 'html' is determined.

**Uncertainties.**

- Because Text yields 'maybe_html' and the RegularElement handler can overwrite it back to 'html', the priority of these outcomes depends on visit order, which callers (infer_namespace) then interpret.

<a id="u-496603088283"></a>
### `utils.js module code (L434–L441)`

`module_region` · [packages/svelte/src/compiler/phases/3-transform/utils.js:L434-L441][f2]

Residual region between check_nodes_for_namespace and determine_namespace_for_children (lines 434–441); no behavioral symbol listed.

<a id="u-fca641f4927b"></a>
### `determine_namespace_for_children`

`export function determine_namespace_for_children(node, namespace)` · [packages/svelte/src/compiler/phases/3-transform/utils.js:L442-L452][f2]

Returns the child namespace for a RegularElement or SvelteElement from static metadata: foreignObject is 'html', svg metadata is 'svg', mathml metadata is 'mathml', otherwise 'html'.

Unlike infer_namespace it never inspects children.

**Notes.**

- condition: svg is checked before mathml, so an element marked both yields 'svg'.

<a id="u-98ebc37aad10"></a>
### `utils.js module code (L452–L458)`

`module_region` · [packages/svelte/src/compiler/phases/3-transform/utils.js:L452-L458][f2]

Residual region between determine_namespace_for_children and transform_inspect_rune (lines 452–458); no behavioral symbol listed.

<a id="u-f64464c8fc01"></a>
### `transform_inspect_rune`

`export function transform_inspect_rune(node, context)` · [packages/svelte/src/compiler/phases/3-transform/utils.js:L459-L481][f2]

Lowers $inspect runes into $.inspect calls, returning b.empty when not in dev mode (so inspection compiles to nothing in production).

For `$inspect(...).with(fn)` (MemberExpression callee) it visits the inspected arguments and the with-argument; for plain `$inspect(...)` it visits all arguments. In client generation the inspected values are wrapped as a thunked array (deferred evaluation), otherwise as a plain array expression.

**Notes.**

- condition: state.options.generate === 'client' controls whether the inspected array is lazy (b.thunk) or eager.

uses: [utils.js module code (L452–L458)](r2-client-transform.md#u-98ebc37aad10)

**Uncertainties.**

- The generic TransformState subtype T supplied by the caller is not constrained further in this source; how dev is set at build time is external.

<a id="u-0ec3860847c4"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/Attribute.js:Attribute`

`export function Attribute(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/Attribute.js:L10-L14][f3]

Handles regular attributes during client transform: only event attributes (is_event_attribute) are processed here, by forwarding to visit_event_attribute; all other attributes are ignored by this visitor (presumably handled elsewhere).

calls: [ast-js-attribute-helpers](r4-compiler-ast-utils.md#u-e05972fa52ab), [visit_event_attribute](r2-client-transform.md#u-8ff2bf148b08)

**Uncertainties.**

- What happens to non-event attributes (handled by other code paths) is not visible in this visitor.

<a id="u-f3de4a3c5909"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/AwaitExpression.js:AwaitExpression`

`export function AwaitExpression(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/AwaitExpression.js:L10-L29][f4]

Serializes an `await` expression, deciding when reactivity can be lost.

If the await is at top level of the instance script (is_instance and function_depth 1) or sits inside a reactive expression but is not the last-evaluated subexpression, it wraps the argument as `await $.save(arg)` to preserve the reactive context. Otherwise, in dev and when `await_reactivity_loss` is not ignored, it wraps as `await $.track_reactivity_loss(arg)`. If visiting did not change the argument node it returns the node unchanged, else a shallow copy with the new argument.

calls: [is_ignored](r5-compiler-state-utils.md#u-468324b42cee), [is_reactive_expression](r2-client-transform.md#u-cce61d3ebba0), [is_last_evaluated_expression](r2-client-transform.md#u-b83cfea00bba)

<a id="u-cce61d3ebba0"></a>
### `is_reactive_expression`

`function is_reactive_expression(context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/AwaitExpression.js:L34-L59][f4]

Determines whether an await occurs in a reactive context.

Returns true immediately if state.in_derived is set. Otherwise walks the path backwards: on reaching any function node it returns false (await is inside a fresh function scope); on reaching any node with metadata (template-owned node) it returns true; if the path is exhausted it returns false.

**Uncertainties.**

- Relies on a ts-expect-error heuristic (`parent.metadata`) as the reactivity marker; the comment itself notes it may not be robust.

<a id="u-b83cfea00bba"></a>
### `is_last_evaluated_expression`

`function is_last_evaluated_expression(context, node)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/AwaitExpression.js:L65-L126][f4]

Walks the ancestor path from the node upward, returning whether the node is the last value evaluated at every level, i.e. whether awaiting it cannot reorder with sibling evaluation.

It stops true when it hits a node with metadata. Each ancestor type imposes its own condition: arrays/objects/sequences/call args/tagged-template/template expressions require the node be the last element/argument/expression; assignment/binary/logical fail if the node is the left/test operand; conditional fails for the test; computed member access fails for the object; Property fails for the key; any other parent type returns false. When all ancestors pass, the while loop ends and the function returns undefined (falsy), so callers treat 'walked to root' as not-last — the implicit return value is not explicitly true.

**Uncertainties.**

- Function returns undefined rather than true when the full path passes; callers relying on truthiness must treat undefined as falsy — observable but likely intentional, unverified.

<a id="u-7baf7e9461f9"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/Comment.js:Comment`

`export function Comment(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/Comment.js:L8-L11][f5]

Appends a comment node to the template via state.template.push_comment(node.data).

Per the inline note, this visitor is reached only when comments are preserved (preserveComments).

calls: [Template](r4-transform-template.md#u-f09b36ebd45e)

<a id="u-9ed746e0d1ee"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/Component.js:Component`

`export function Component(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/Component.js:L10-L13][f6]

Compiles a component tag by delegating to build_component with the component's name, then pushing the resulting declaration into state.init.

calls: [component-js-build-component](r5-transform-client.md#u-af8f6b0917f6)

<a id="u-096c3cb09027"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/ExpressionStatement.js:ExpressionStatement`

`export function ExpressionStatement(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/ExpressionStatement.js:L10-L30][f7]

Rewrites rune calls made as bare statements.

For a CallExpression whose rune (via get_rune) is `$effect` or `$effect.pre`, the first argument is visited and wrapped in `$.user_effect` / `$.user_pre_effect`; the callee's loc is copied from the original callee to preserve source mapping, and the call is returned as a statement. `$inspect.trace` statements compile to b.empty (dropped). Any other statement falls through to context.next() for default handling.

**Uncertainties.**

- An `$effect`/`$effect.pre` call with no arguments would make context.visit(node.expression.arguments[0]) visit undefined; no guard exists here.

<a id="u-7a4dc7847558"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/Fragment.js:Fragment`

`export function Fragment(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/Fragment.js:L16-L128][f8]

Transforms a fragment into a block that instantiates a hoisted template (or reuses an anchor) and appends it.

It infers the namespace for the parent context, cleans the child nodes into hoisted/trimmed lists with is_standalone and is_text_first flags, and returns an empty block when nothing remains. It builds a fresh child state (own init/consts/update/after_update, Memoizer, Template, copied transforms, propagated namespace and bound_contenteditable) and visits hoisted nodes first. Output shape depends on the trimmed nodes: a single RegularElement gets an element id, its template is hoisted via transform_template (flags include TEMPLATE_USE_IMPORT_NODE when needed) and the init is unshifted with instantiation plus an `$.append` close; a single SvelteFragment/TitleElement is visited directly with no template; a single Text becomes a `$.text` node plus append; multiple nodes either use a shared `$.text` template when all children are Text/ExpressionTag including at least one ExpressionTag, reuse `$$anchor` when standalone, or otherwise create a fragment template — replaced by `$.comment` when the template contains exactly one comment node. The `expression` inline helper builds the `$.first_child` anchor expression for the non-standalone case. Body assembly: consts, an early `$.aborted` return when the fragment has awaits, `$.next` to skip the text-first placeholder comment, init, the render effect via build_render_statement when updates exist, after_update, and finally the close append (it must be last so element insertions into the template are accounted for). Awaited fragments wrap the body in `$.async_body`; has_await comes from node.metadata and non-null init.

calls: [transform_template](r5-transform-client.md#u-e8f6b714535e), [process_children](r1-client-transform.md#u-7091653bb501), [infer_namespace](r2-client-transform.md#u-b0bc5038f26b), [clean_nodes](r2-client-transform.md#u-2ed26069223c)

**Uncertainties.**

- Whether transform_template ever returns a non-hoisted result is hidden in the transform-template module.
- clean_nodes' trimming and whitespace rules are defined in another file.

<a id="u-f91f27df0412"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/LetDirective.js:LetDirective`

`export function LetDirective(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/LetDirective.js:L11-L51][f9]

Serializes `let:` slot bindings into derived consts.

For non-Identifier expressions (destructuring), a generated alias name is used: all bindings of the directive get transformers reading `$.get(alias).<binding>`, and a `$.derived` const is returned whose thunk destructures `$$slotProps.<name>` with an object or array pattern and returns an object of the bound names. For an Identifier expression (or null expression), the transformer reads `$.get(name)` directly and a simpler `const name = $.derived(() => $$slotProps.<directive name>)` is produced via create_derived. The returned const node is emitted by the caller (the element visitor pushes let results into init).

calls: [create_derived](r3-client-transform-utils.md#u-d8c62e2be238)

**Uncertainties.**

- The comment says `$.derived` but the code calls local create_derived; the emitted helper name depends on create_derived's implementation outside this file.

<a id="u-ab4813441bd1"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/SnippetBlock.js:SnippetBlock`

`export function SnippetBlock(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/SnippetBlock.js:L13-L100][f10]

Serializes {#snippet name(params)} declarations into a const bound to a function.

Parameters become `$$anchor` plus argument slots: Identifier parameters get a `$.noop` default and a `b.call` read transformer; pattern parameters are aliased `$$arg<i>`, destructured via extract_paths into per-path declarations — inserted identifiers become `$.derived` consts with get_value transformers, and normal paths become lets, wrapped in `$.derived_safe_equal` when they carry a default (so the default evaluates once), with dev-time eager reads to surface initialization-order errors. The visited body is prefixed with declarations and, in dev, a `$.validate_snippet_args(...arguments)` check. In dev the snippet is a FunctionExpression wrapped by `$.wrap_snippet(analysisName, fn)`; in production it is an arrow. The const declaration is pushed to module_level_snippets when top-level and hoistable, instance_level_snippets for other top-level snippets, or init for nested snippets — top-level snippets are hoisted so script code can reference them.

calls: [extract_paths](r4-compiler-ast-utils.md#u-34f2fcb20c62)

**Uncertainties.**

- `has_await` derives from node.body.metadata.has_await with a false fallback; what sets that metadata is not visible here.

<a id="u-7506ce95c563"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/SpreadAttribute.js:SpreadAttribute`

`export function SpreadAttribute(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/SpreadAttribute.js:L8-L10][f11]

Compiles a spread attribute by visiting and returning its expression; no extra transformation.

<a id="u-af73e301b19f"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/SvelteDocument.js:SvelteDocument`

`export function SvelteDocument(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/SvelteDocument.js:L9-L11][f12]

Compiles <svelte:document> by delegating to visit_special_element with the target '$.document'.

calls: [visit_special_element](r5-transform-client.md#u-5f6160c62286)

<a id="u-fa257fa55ed4"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/SvelteElement.js:SvelteElement`

`export function SvelteElement(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/SvelteElement.js:L19-L156][f13]

Transforms a svelte:<...> dynamic element into a `$.element` runtime call.

A template comment is pushed and a temporary inner context with a generated `$$element` id collects init/update/after_update statements from the element's attributes. Attribute handling: xmlns attributes with non-text values are captured as a dynamic namespace; Attributes and SpreadAttributes go into a shared list, Class/Style directives into their own lists; LetDirective statements are visited in the outer context (as statements), OnDirective handlers are visited in the inner context and pushed to after_update, and other attribute types are visited in the inner context. If the element's only attribute is a static class text attribute, build_set_class emits the class directly; otherwise any attributes go through build_attribute_effect as a runtime spread, because whether the element is a custom element is only known at runtime. The tag expression is visited and wrapped in a thunk (a `$.get` thunk when the tag expression contains an await). Inner statements append the render effect (when updates exist), after_update handlers, and the visited fragment body with the child namespace determined by determine_namespace_for_children. In dev, `$.validate_void_dynamic_element` is emitted when the fragment has children and `$.validate_dynamic_element_tag` always; a locator supplies line/column. The `$.element` call receives the anchor node, the tag thunk, an svg/mathml boolean, the inner arrow when inner statements exist, the dynamic-namespace thunk when present, and the dev location array. With an awaited tag the statements are wrapped in `$.async`; otherwise the single statement or a block of them is pushed to init.

calls: [build_attribute_effect](r4-transform-client.md#u-0abd8487f7a1), [build_set_class](r4-transform-client.md#u-d08767f6fc10), [build_attribute_value](r4-transform-client.md#u-2462157783c9), [determine_namespace_for_children](r2-client-transform.md#u-fca641f4927b)

**Uncertainties.**

- The runtime behavior of build_attribute_effect (spread vs individual sets) is in a shared helper not supplied.
- Whether the tag expression's metadata.has_await can be true alongside non-await parents is determined upstream.

<a id="u-8ff2bf148b08"></a>
### `visit_event_attribute`

`export function visit_event_attribute(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/events.js:L12-L84][f14]

Compiles event attributes like onclick.

The event name is node.name minus 'on:'-style prefix (slice(2)); names recognized by is_capture_event lose their 'capture' suffix (slice(0, -7)) and set capture. The handler expression is built with build_event_handler from the attribute's expression tag (array-valued attributes take the first tag, supporting the `onclick="{fn}"` form). If node.metadata.delegated: the event name is added to state.events, and when metadata.delegated.hoisted, the handler is hoisted — if the delegated function is the tag expression itself, a uniquely named `on_<event>` var holding the handler is pushed to state.hoisted and used instead; when the hoisted function has hoisted_params, the assignment value is an array of [handler, ...params]. The result is assigned to `node.__<event>` in state.init. Otherwise a `$.event(...)` call is built via build_event with capture true-literal and passive=true when is_passive_event matches; that statement goes to state.init for SvelteDocument/SvelteWindow/SvelteBody parents (so events run parent-first above the component tree) and to state.after_update otherwise.

calls: [build_event_handler](r2-client-transform.md#u-227977f005ec), [build_event](r2-client-transform.md#u-0bee50cc5235), [utils-js-predicates](r3-shared-utils.md#u-7eb274f609ad), [ScopeRoot](r4-compiler-scope.md#u-8f49475011d6)

**Uncertainties.**

- The meaning of node.metadata.delegated.function identity vs tag.expression (when they differ, the handler is not renamed) depends on analysis set elsewhere.

<a id="u-0bee50cc5235"></a>
### `build_event`

`export function build_event(event_name, node, handler, capture, passive)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/events.js:L94-L103][f14]

Constructs the `$.event(name, node, handler, capture, passive)` call for non-delegated handlers.

capture is passed as b.true only when true (otherwise a true literal is still emitted per code: `capture && b.true`, yielding false); passive undefined is omitted, otherwise its literal value is passed.

**Uncertainties.**

- When capture is false, `capture && b.true` evaluates to false (not undefined), so a false literal argument is emitted; how $.event treats false vs omitted capture is outside this file.

<a id="u-227977f005ec"></a>
### `build_event_handler`

`export function build_event_handler(node, metadata, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/events.js:L112-L177][f14]

Builds the handler expression for an event.

A null expression becomes a function calling `$.bubble_event.call(this, $$props, $$arg)` (event bubbling). The expression is visited; if the result is already a function (arrow/function expression) it is returned as-is; if an identifier bound to a function it is returned as-is; a non-import identifier binding is also returned directly when not in dev (dev requires `$.apply` for warnings). When metadata.has_call, the handler is memoized: a uniquely named `event_handler` var wrapping `$.derived` is pushed to state.init and read via `$.get`. The default path wraps the handler in a function calling `handler.apply(this, $$args)` so the expression re-evaluates per event. In dev, the wrapper instead calls `$.apply` with a thunk of the handler, this, $$args, the component name, a [line, column] location array when locator resolves, a true flag when the node has side effects (has_side_effects), and a true flag when the node is a zero-argument identifier call (so runtime output can drop parentheses).

**Notes.**

- failure: In dev, locator(node.start) may return a falsy value; the location array argument is then undefined via `loc && ...`.

calls: [Scope](r4-compiler-scope.md#u-01a82e58170d)

**Uncertainties.**

- The exact runtime semantics of $.apply's flags (side_effects, remove_parens) are outside this file.

<a id="u-229b6845de57"></a>
### `has_side_effects`

`function has_side_effects(node)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/events.js:L182-L197][f14]

Conservative syntactic check: returns true for CallExpression, NewExpression, AssignmentExpression, and UpdateExpression nodes; for SequenceExpression it recurses and returns true if any sub-expression qualifies; everything else is false.

It performs no semantic analysis.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/types.d.ts
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/utils.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/Attribute.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/AwaitExpression.js
[f5]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/Comment.js
[f6]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/Component.js
[f7]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/ExpressionStatement.js
[f8]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/Fragment.js
[f9]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/LetDirective.js
[f10]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/SnippetBlock.js
[f11]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/SpreadAttribute.js
[f12]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/SvelteDocument.js
[f13]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/SvelteElement.js
[f14]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/events.js
