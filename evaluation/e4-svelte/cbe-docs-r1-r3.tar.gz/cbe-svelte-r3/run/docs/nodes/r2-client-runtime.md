# Client Runtime

**Capability.** The browser-side execution engine: the fine-grained reactivity core, batched effect scheduling, component context/lifecycle bookkeeping, DOM block and element behavior, and the Svelte 4 compatibility layer.

Enter here for anything that happens at runtime in the browser. reactivity-core and batching are the heart; context, DOM blocks/elements, and legacy adapters build on them. Public reactive primitives depend on the runtime core but live in their own tree.

**Children.**

- [Reactivity Core & Batching](r2-reactivity-core.md) `r2-reactivity-core` · 28 unit(s)
- [Component Context](r2-component-context.md) `r2-component-context` · 13 unit(s)
- [Each Block Runtime](r2-dom-blocks.md) `r2-dom-blocks` · 7 unit(s)
- [DOM Elements](r2-dom-elements.md) `r2-dom-elements` · 15 unit(s)
- [Legacy Client Compatibility](r2-legacy-client.md) `r2-legacy-client` · 10 unit(s)

Parent: [Svelte Codebase](r2-svelte-codebase.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
