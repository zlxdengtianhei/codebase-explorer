# Server Templating Helpers

**Capability.** Server implementations of template constructs: named slots and fallbacks, props sanitization/rest extraction, legacy binding propagation, await and each blocks, {@debug} logging, lazy derived/once getters, props ids, and payload id markers.

These are the $.-namespace template helpers for slots, blocks, and legacy reactivity on the server. The residual gap regions here sit between these declarations in server/index.js.

**Depends on.**

- [Server Markup Serialization](r3-server-markup.md) · model-inferred · 0 edge(s)

Parent: [Server Runtime](r3-server-runtime.md)

## Units (22)

<a id="u-c8b85b1bb23a"></a>
### `packages/svelte/src/internal/server/index.js:slot`

`export function slot(payload, $$props, name, slot_props, fallback_fn)` · [packages/svelte/src/internal/server/index.js:L361-L373][f1]

Render a named slot: call the provided slot function with slot props, or the fallback.

**Notes.**

- condition: Interop: if $$slots[name] is true (snippet-filled slot), the slot function is taken from $$props.children for the default slot, else $$props[name].
- condition: When no slot function exists, fallback_fn is invoked if non-null; otherwise nothing is emitted.

<a id="u-fa79149bdee0"></a>
### `packages/svelte/src/internal/server/index.js:rest_props`

`export function rest_props(props, rest)` · [packages/svelte/src/internal/server/index.js:L380-L390][f1]

Build an object of props excluding the named keys (the $$restProps pattern).

<a id="u-4abf93ac9587"></a>
### `sanitize_props`

`export function sanitize_props(props)` · [packages/svelte/src/internal/server/index.js:L396-L399][f1]

Strip children and $$slots from props before passing them onward.

<a id="u-5e5630e14f22"></a>
### `packages/svelte/src/internal/server/index.js:sanitize_slots`

`export function sanitize_slots(props)` · [packages/svelte/src/internal/server/index.js:L405-L413][f1]

Compute the $$slots boolean map: default true when children prop exists, plus each $$slots key.

**Notes.**

- condition: Presence of props.children (truthy) marks the default slot; iterating props.$$slots assumes it exists.

<a id="u-f2ea71698e42"></a>
### `bind_props`

`export function bind_props(props_parent, props_now)` · [packages/svelte/src/internal/server/index.js:L421-L433][f1]

Legacy binding support: propagate a fallback-filled prop value back to the parent props object.

**Notes.**

- condition: Only when the parent value is undefined, the current value is defined, and the parent property has a setter does props_parent[key] receive the current value.

<a id="u-1a337df4b94c"></a>
### `packages/svelte/src/internal/server/index.js:await_block`

`function await_block(payload, promise, pending_fn, then_fn)` · [packages/svelte/src/internal/server/index.js:L443-L454][f1]

Server await block: render pending content for a promise, or immediate content for a resolved value.

**Notes.**

- condition: is_promise path pushes BLOCK_OPEN, attaches promise.then(null, noop) to swallow rejections, and runs pending_fn when non-null.
- condition: Non-promise path pushes BLOCK_OPEN_ELSE and runs then_fn(promise) when then_fn is non-null; both null fns mean no content beyond the marker.

calls: [utils.js-small-helpers](r1-shared-runtime.md#u-aa0ed6112e71)

<a id="u-01a3113f1c5f"></a>
### `ensure_array_like`

`export function ensure_array_like(array_like_or_iterator)` · [packages/svelte/src/internal/server/index.js:L459-L466][f1]

Normalize an iterable for each-blocks: pass arrays through, materialize other iterables, default to [].

**Notes.**

- condition: Falsy input returns []; truthy values with a length property are returned as-is; others go through Array.from.

<a id="u-7e5028a0fda0"></a>
### `packages/svelte/src/internal/server/index.js:inspect`

`export function inspect(args, inspect = console.log)` · [packages/svelte/src/internal/server/index.js:L473-L475][f1]

{@debug} helper: log 'init' plus the inspected values via console.log by default.

<a id="u-a5b0cc827a44"></a>
### `packages/svelte/src/internal/server/index.js:once`

`export function once(get_value)` · [packages/svelte/src/internal/server/index.js:L481-L489][f1]

Create a lazily-evaluated, cached getter that computes its value only on first call.

**Notes.**

- contract: Uses the UNINITIALIZED sentinel; repeated calls return the memoized value without re-running get_value.

**Uncertainties.**

- A get_value returning the UNINITIALIZED sentinel value itself would be recomputed each call; not guarded by source.

<a id="u-2eb01f29fdab"></a>
### `packages/svelte/src/internal/server/index.js:props_id`

`export function props_id(payload)` · [packages/svelte/src/internal/server/index.js:L496-L500][f1]

Generate a unique id from the payload's uid generator and emit an <!--#id--> marker.

<a id="u-7bb944bfaa2a"></a>
### `packages/svelte/src/internal/server/index.js:derived`

`export function derived(fn)` · [packages/svelte/src/internal/server/index.js:L532-L546][f1]

Legacy server derived: a getter/setter function caching the first computed value until set.

**Notes.**

- contract: With no arguments returns updated_value if set, otherwise the memoized once(fn) result; with an argument stores it and returns it, bypassing fn thereafter.

calls: [packages/svelte/src/internal/server/index.js:once](r3-server-templating.md#u-a5b0cc827a44)

<a id="u-2dabb3e57b95"></a>
### `index.js module code (L351–L360)`

`module_region` · [packages/svelte/src/internal/server/index.js:L351-L360][f1]

Non-behavioral gap between unsubscribe_stores and slot.

<a id="u-ea23df453687"></a>
### `index.js module code (L373–L379)`

`module_region` · [packages/svelte/src/internal/server/index.js:L373-L379][f1]

Non-behavioral gap between slot and rest_props.

<a id="u-c3b2c9381e74"></a>
### `index.js module code (L390–L395)`

`module_region` · [packages/svelte/src/internal/server/index.js:L390-L395][f1]

Non-behavioral gap between rest_props and sanitize_props.

<a id="u-b203aab79979"></a>
### `index.js module code (L399–L404)`

`module_region` · [packages/svelte/src/internal/server/index.js:L399-L404][f1]

Non-behavioral gap between sanitize_props and sanitize_slots.

<a id="u-90a1b11fc268"></a>
### `index.js module code (L413–L420)`

`module_region` · [packages/svelte/src/internal/server/index.js:L413-L420][f1]

Non-behavioral gap between sanitize_slots and bind_props.

<a id="u-b81b830fa062"></a>
### `index.js module code (L433–L442)`

`module_region` · [packages/svelte/src/internal/server/index.js:L433-L442][f1]

Non-behavioral gap between bind_props and await_block.

<a id="u-0daaea17cf20"></a>
### `index.js module code (L454–L458)`

`module_region` · [packages/svelte/src/internal/server/index.js:L454-L458][f1]

Non-behavioral gap between await_block (exported as await) and ensure_array_like.

<a id="u-e6ddfab0cc10"></a>
### `index.js module code (L466–L472)`

`module_region` · [packages/svelte/src/internal/server/index.js:L466-L472][f1]

Non-behavioral gap between ensure_array_like and inspect.

<a id="u-2b30edfbbbcd"></a>
### `index.js module code (L475–L480)`

`module_region` · [packages/svelte/src/internal/server/index.js:L475-L480][f1]

Non-behavioral gap between inspect and once.

<a id="u-b68e973631c5"></a>
### `index.js module code (L489–L495)`

`module_region` · [packages/svelte/src/internal/server/index.js:L489-L495][f1]

Non-behavioral gap between once and props_id.

<a id="u-40972cd42b5c"></a>
### `index.js module code (L500–L531)`

`module_region` · [packages/svelte/src/internal/server/index.js:L500-L531][f1]

Re-export block: attr/clsx, html, push/pop, dev element helpers, payload helpers, shared utils/validators, escape, await_outside_boundary.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/server/index.js
