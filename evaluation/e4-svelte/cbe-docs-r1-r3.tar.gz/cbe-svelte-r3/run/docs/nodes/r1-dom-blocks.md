# DOM Template Blocks

**Capability.** Implements client-side template control flow: {#if}, {#await} (with its branch-swapping effect), {#snippet} and raw snippets with dev ownership wrapping, slot rendering and sanitization, async blocks, and HTML-string fragment creation via the reconciler.

Use when a template block renders incorrectly or its update semantics are in question. The await block effect re-runs on input change and calls update to swap branches; raw snippets build fragments through the reconciler.

**Depends on.**

- [Async Reactivity](r1-async-reactivity.md) · graph-confirmed · 1 edge(s) · async template blocks call flatten to preserve reactive tracking across awaited expressions.
- [Shared Runtime Utilities](r1-shared-runtime.md) · graph-confirmed · 2 edge(s)
- [Task Scheduling](r1-task-scheduling.md) · graph-confirmed · 1 edge(s)
- [Effect System](r4-runtime-effects.md) · graph-only · 20 edge(s)
- [Client Hydration State](r3-client-hydration.md) · graph-only · 13 edge(s)
- [Component Context](r2-component-context.md) · graph-only · 9 edge(s)

**Depended on by.**

- [Event System & Delegation](r1-event-system.md) · model-inferred · 0 edge(s)

Parent: [Client Runtime](r1-client-runtime.md)

## Units (11)

<a id="u-e0280b89cb0f"></a>
### `if-js-if-block`

`const set_branch = (/** @type {(anchor: Node) => void} */ fn, flag = true) =>` · [packages/svelte/src/internal/client/dom/blocks/if.js:L46-L49][f1]

Implements {#if}/{:else if} blocks.

On entry while hydrating it consumes the next hydration node. The block effect runs the user fn, which registers branches through set_branch; if no branch registered, update_branch(null, null) clears the condition. set_branch delegates to update_branch(flag, fn). update_branch returns early when the condition is unchanged; otherwise, during hydration, a mismatch is detected when the else-marker presence equals the new truthiness — it then removes the server DOM via remove_nodes(), adopts the new anchor, and suspends hydrating. When should_defer_append() holds, the new branch renders into an offscreen fragment (with a text anchor later inserted before the real anchor); otherwise it renders directly. Consequent or alternate effect slots are created lazily, the batch's skipped_effects set is adjusted, and commit is deferred via batch.add_callback or run immediately: commit resumes the now-active effect and pauses the inactive one (nulling its slot on completion), or reinserts the offscreen fragment (dropping its temporary text anchor). A mismatch re-enables hydrating at the end. EFFECT_TRANSPARENT is used when this is an {:else if} chain, affecting transition locality.

group: [if-js-if-block](r1-dom-blocks.md#u-e0280b89cb0f)

**Uncertainties.**

- The conditions under which should_defer_append() returns true are defined in operations.js, not here

<a id="u-09d83c059a62"></a>
### `await-js-await-block`

`function update(state, restore)` · [packages/svelte/src/internal/client/dom/blocks/await.js:L76-L132][f2]

Implements the {#await} template block: it creates value/error sources and a block() effect that re-runs whenever get_input() changes, rendering pending, then, or catch branches around an anchor.

On entry while hydrating it consumes the next hydration node. It captures component_context and, under DEV, the current component function and dev stack so async updates can restore them. Sources use source() when is_runes() is true, otherwise mutable_source(undefined, false, false).

group: [packages/svelte/src/internal/client/dom/blocks/await.js:update](r1-dom-blocks.md#u-05916687a6e9)

<a id="u-78ece381afeb"></a>
### `await-js-await-block-effect`

`export function await_block(node, get_input, pending_fn, then_fn, catch_fn)` · [packages/svelte/src/internal/client/dom/blocks/await.js:L132-L204][f2]

The await block's effect body: re-runs when the awaited input changes, returning early if get_input() yields the identical value.

During hydration, a mismatch is detected when is_promise(input) equals whether the anchor comment is a HYDRATION_START_ELSE marker; it then removes server nodes via remove_nodes(), adopts the new anchor, and stops hydrating until the end of the run. For a promise it clears resolved and attaches handlers that ignore settlement of a superseded promise (promise !== input), write via internal_set into the value/error source, and call update(THEN, true) or update(CATCH, true); the catch handler rethrows error_source.v when catch_fn is null. While hydrating with pending_fn it branches the pending snippet immediately; otherwise a microtask shows the pending state only if the promise has not resolved by then. For non-promise input it writes the value and calls update(THEN, false). After a mismatch it re-enables hydrating, and the returned cleanup sets input to UNINITIALIZED, disabling stale promise callbacks. After block creation, hydrating sets anchor = hydrate_node.

**Notes.**

- side_effect: The returned cleanup sets input to UNINITIALIZED so promise callbacks from a previous run become inert.

calls: [packages/svelte/src/internal/client/dom/blocks/await.js:update](r1-dom-blocks.md#u-05916687a6e9)

**Uncertainties.**

- Whether internal_set versus set changes scheduling is asserted only by inline comments; scheduling lives outside this file

<a id="u-05916687a6e9"></a>
### `packages/svelte/src/internal/client/dom/blocks/await.js:update`

`function update(state, restore)` · [packages/svelte/src/internal/client/dom/blocks/await.js:L76-L132][f2]

Swaps the rendered await branch to the given state (PENDING, THEN, or CATCH) and sets resolved.

When restore is true it first re-establishes the outer effect as active effect/reaction and restores the captured component context and DEV stack, so render functions run with correct ownership. For the matching state it resumes an existing effect or creates one via branch() calling pending_fn, then_fn(anchor, input_source), or catch_fn(anchor, error_source); every state other than the new one has its effect paused with a cleanup nulling the slot. The finally block clears the restored context/effect/reaction (and DEV fields) and, when restore is true, calls flushSync() so the DOM updates in the same tick the promise settles. Errors thrown by render functions propagate after the finally cleanup runs.

uses: [await-js-await-block](r1-dom-blocks.md#u-09d83c059a62)

**Uncertainties.**

- branch/resume_effect/pause_effect failure behavior is defined outside this file

<a id="u-398a190f3765"></a>
### `snippet`

`export function snippet(node, get_snippet, ...args)` · [packages/svelte/src/internal/client/dom/blocks/snippet.js:L27-L55][f3]

Implements the {#snippet} render slot: a transparent block effect that re-renders a snippet when get_snippet returns a different function.

The current snippet starts as noop so the first non-null value triggers rendering. When the snippet identity changes, any existing snippet effect is destroyed; if the new snippet is null/undefined in dev, invalid_snippet is raised before branching — meaning in production a null snippet is still invoked as a function via branch and would throw. Because the block is EFFECT_TRANSPARENT, the snippet's effects attach to the parent effect. During hydration the anchor moves to hydrate_node after setup.

**Notes.**

- failure: invalid_snippet is dev-only; in production a null snippet reaches branch and will throw when called.

calls: [packages/svelte/src/internal/client/reactivity/effects.js:block](r4-runtime-effects.md#u-75d755e7c63c), [branch](r4-runtime-effects.md#u-cfe4a1f5ddba), [destroy_effect](r4-runtime-effects.md#u-214ad59ce57a); raises: [packages/svelte/src/internal/errors.js](../../catalog.json)

<a id="u-2edc4e7a14f5"></a>
### `createRawSnippet`

`export function createRawSnippet(fn)` · [packages/svelte/src/internal/client/dom/blocks/snippet.js:L89-L119][f3]

Creates a programmatic snippet from a render/setup factory: calling the returned snippet evaluates fn with getter params, producing an object with a render() string and optional setup.

During hydration the element is the current hydrate_node and hydration advances; otherwise the trimmed render string is parsed into a fragment, its first child is taken as the element (in dev a warning invalid_raw_snippet_render fires if there are extra siblings or it is not an element node), and it is inserted before the anchor. setup is then invoked on the element, assign_nodes marks the element as both start and end of the effect's node range, and if setup returned a function it is registered as teardown cleanup.

**Notes.**

- side_effect: assign_nodes(element, element) makes the raw element the effect's whole node range; it runs after setup so setup-created children are not included.

calls: [create_fragment_from_html](r1-dom-blocks.md#u-f51e86a3ef3c), [assign_nodes](r3-client-template.md#u-081194bea535), [teardown](r4-runtime-effects.md#u-afcffe6190df), [hydration-js-state](r3-client-hydration.md#u-c504e0cdf2f3)

<a id="u-4a27c635b68b"></a>
### `wrap_snippet`

`export function wrap_snippet(component, fn)` · [packages/svelte/src/internal/client/dom/blocks/snippet.js:L63-L64][f3]

Wraps a snippet function for development use: the wrapper saves dev_current_component_function, switches it to the owning component while the snippet runs, and restores the previous value in a finally block, so ownership validation uses the right component even when the snippet is passed across components.

The wrapper is additionally marked with prevent_snippet_stringification so accidental string coercion of the snippet is rejected.

calls: [set_dev_current_component_function](r2-component-context.md#u-1de56d41fa38), [prevent_snippet_stringification](r5-runtime-shared.md#u-f0c8633de633)

<a id="u-0553de12b651"></a>
### `slot`

`export function slot(anchor, $$props, name, slot_props, fallback_fn)` · [packages/svelte/src/internal/client/dom/blocks/slot.js:L10-L30][f4]

Renders a named slot from the parent's $$props at the given comment anchor.

During hydration it advances past the anchor first. If $$props.$$slots[name] is true, slot interop mode is used and the snippet is taken from $$props.children (for the default slot) or $$props[name], invoked with a getter returning slot_props; otherwise the slot function is invoked directly with slot_props. When no slot function exists, fallback_fn is called at the anchor if it is not null; a missing slot with no fallback renders nothing.

calls: [hydration-js-state](r3-client-hydration.md#u-c504e0cdf2f3)

<a id="u-16ae26a1cb4b"></a>
### `sanitize_slots`

`export function sanitize_slots(props)` · [packages/svelte/src/internal/client/dom/blocks/slot.js:L36-L44][f4]

Builds a record of which slots a component exposes: the default slot is marked when props.children is truthy, and every key of props.$$slots is marked true.

Returns the plain boolean record.

**Uncertainties.**

- If props.$$slots is undefined the for-in loop iterates nothing; whether callers guarantee $$slots exists is not visible here.

<a id="u-0ce28dacb587"></a>
### `async`

`export function async(node, expressions, fn)` · [packages/svelte/src/internal/client/dom/blocks/async.js:L11-L26][f5]

Renders an async block once all its awaited expressions resolve, tracking pending state on the enclosing boundary.

It increments the pending boundary's count immediately, then flattens the expression promises; the completion callback eagerly reads each derived value with get so rejections surface before any DOM is created, calls fn with the anchor and resolved values, and always decrements the pending count in a finally block so the counter stays balanced even if get or fn throws.

calls: [get_pending_boundary](r5-client-boundary.md#u-662729eaf177), [flatten](r1-async-reactivity.md#u-c50793421b66), [packages/svelte/src/internal/client/runtime.js:get](r2-reactivity-core.md#u-98099fbbf12a)

**Uncertainties.**

- Behavior when no boundary is pending depends on get_pending_boundary, which is outside this file.

<a id="u-f51e86a3ef3c"></a>
### `create_fragment_from_html`

`export function create_fragment_from_html(html)` · [packages/svelte/src/internal/client/dom/reconciler.js:L2-L6][f6]

Parses an HTML string into a DocumentFragment by placing it in a <template> element's innerHTML and returning its content.

Replaces every '<!>' with '<!---->' first, noted as XHTML compliance, so empty placeholder comments survive parsing.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/blocks/if.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/blocks/await.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/blocks/snippet.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/blocks/slot.js
[f5]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/blocks/async.js
[f6]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/reconciler.js
