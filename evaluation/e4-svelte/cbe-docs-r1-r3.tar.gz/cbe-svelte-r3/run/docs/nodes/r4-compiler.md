# Compiler Pipeline

**Capability.** Transforms Svelte component source into executable code through sequential phases: parsing helpers, semantic analysis with validation, scope construction, node/AST infrastructure, and client/server transformation, backed by public compiler type declarations.

Navigate by phase: parse helpers, analyze visitors and their shared validation, transform visitors, and cross-cutting infrastructure (scope, node model, AST utilities, types). Later phases depend on the scope and AST utility subtrees.

**Children.**

- [Compiler Type Declarations](r4-compiler-types.md) `r4-compiler-types` · 3 unit(s)
- [Parsing and Lexical Helpers](r4-compiler-parse.md) `r4-compiler-parse` · 23 unit(s)
- [Shared Analysis Validation](r4-analyze-shared-validation.md) `r4-analyze-shared-validation` · 10 unit(s)
- [Semantic Analysis Visitors](r4-analyze-visitors.md) `r4-analyze-visitors` · 19 unit(s)
- [Scope and Binding Model](r4-compiler-scope.md) `r4-compiler-scope` · 9 unit(s)
- [Node Factories and Metadata Model](r4-compiler-node-model.md) `r4-compiler-node-model` · 9 unit(s)
- [AST Manipulation Utilities](r4-compiler-ast-utils.md) `r4-compiler-ast-utils` · 14 unit(s)
- [Client Static Template Emission](r4-transform-template.md) `r4-transform-template` · 3 unit(s)
- [Client Code Transformation](r4-transform-client.md) `r4-transform-client` · 16 unit(s)
- [Server \(SSR\) Code Transformation](r4-transform-server.md) `r4-transform-server` · 5 unit(s)

**Depends on.**

- [Compiler Type Declarations](r4-compiler-types.md) · containment · → 0 / ← 0 edge(s) (ancestor direct units and descendant subtree; → follows ` r4-compiler ` → ` r4-compiler-types `)

**Depended on by.**

- [Build Scripts and Generated Sources](r4-build-codegen.md) · model-inferred · 0 edge(s)

Parent: [Svelte Compiler and Runtime](r4-svelte-monorepo.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
