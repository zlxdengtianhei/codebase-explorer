# Reactivity Type Contracts

**Capability.** Type-only declarations of the reactive core's data shapes: Signal, Value, Reaction, Effect, Derived, the Source/MaybeSource aliases, and the shared type imports — defining the flag bitmasks, dependency links, and effect-tree fields used throughout the client runtime.

Consult for the shape of signals, reactions, and effects when reading runtime code; this module declares no runtime behavior.

**Depended on by.**

- [Dev Diagnostics & HMR](r1-client-dev-diagnostics.md) · model-inferred · 0 edge(s)

Parent: [Client Runtime](r1-client-runtime.md)

## Units (8)

<a id="u-d7be5ea90299"></a>
### `Signal`

`export interface Signal` · [packages/svelte/src/internal/client/reactivity/types.d.ts:L10-L15][f1]

Type declaration only: Signal defines the flag bitmask f and write version wv shared by all signals.

<a id="u-4c170930dd4a"></a>
### `Value`

`export interface Value<V = unknown> extends Signal` · [packages/svelte/src/internal/client/reactivity/types.d.ts:L17-L41][f1]

Type declaration only: Value extends Signal with equals, reactions, rv, v, plus optional dev-only tracing fields (label, created, updated, set_during_effect, trace).

<a id="u-dbffae4ef8ef"></a>
### `Reaction`

`export interface Reaction extends Signal` · [packages/svelte/src/internal/client/reactivity/types.d.ts:L43-L52][f1]

Type declaration only: Reaction extends Signal with ctx, fn, deps, and an abort controller ac.

<a id="u-2710975de280"></a>
### `Effect`

`export interface Effect extends Reaction` · [packages/svelte/src/internal/client/reactivity/types.d.ts:L63-L94][f1]

Type declaration only: Effect extends Reaction with DOM nodes_start/nodes_end, fn, teardown, transitions, effect-tree links (prev/next/first/last/parent), owning boundary b, and optional dev fields.

<a id="u-9d57285747d5"></a>
### `Derived`

`export interface Derived<V = unknown> extends Value<V>, Reaction` · [packages/svelte/src/internal/client/reactivity/types.d.ts:L54-L61][f1]

Type declaration only: Derived extends Value and Reaction, narrowing fn to () => V and adding effects and parent (effect or derived).

<a id="u-7d1c64b4718d"></a>
### `packages/svelte/src/internal/client/reactivity/types.d.ts:Source`

`export type Source<V = unknown> = Value<V>;` · [packages/svelte/src/internal/client/reactivity/types.d.ts:L96-L96][f1]

Type alias only: Source<V> is Value<V>.

<a id="u-09d9619b4ae2"></a>
### `MaybeSource`

`export type MaybeSource<T = unknown> = T | Source<T>;` · [packages/svelte/src/internal/client/reactivity/types.d.ts:L98-L98][f1]

Type alias only: MaybeSource<T> is T or Source<T>.

<a id="u-44fb259a3b22"></a>
### `types.d.ts module code (L1–L9)`

`module_region` · [packages/svelte/src/internal/client/reactivity/types.d.ts:L1-L9][f1]

Type-only module: imports shared types for the interface declarations below.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/reactivity/types.d.ts
