# Benchmarking Harness

**Capability.** Executes benchmark suites with wall-clock and GC-attributed timing: one module drives suite runs, the other provides timed/GC-tracked measurement, file I/O, assertion, and delay utilities.

Use run.js to reproduce suite execution; use utils.js for timed, GC-tracked measurement helpers and file read/write. All measurement semantics (elapsed time, GC windows, tie-breaking on fastest time) live here, isolated from production code.

**Depends on.**

- [Svelte Compiler and Runtime](r4-svelte-monorepo.md) · containment · → 0 / ← 0 edge(s) (ancestor direct units and descendant subtree; → follows ` r4-benchmarking ` → ` r4-svelte-monorepo `)

**Depended on by.**

- [Reactivity Benchmarks](r2-benchmarks.md) · graph-only · 19 edge(s)
- [Reactivity Benchmarks](r5-benchmarks.md) · graph-only · 12 edge(s)
- [Benchmarks](r1-benchmarks.md) · graph-only · 11 edge(s)
- [Reactivity Benchmarks](r3-benchmarks.md) · graph-only · 9 edge(s)

Parent: [Svelte Compiler and Runtime](r4-svelte-monorepo.md)

## Units (9)

<a id="u-8a0ea15faff6"></a>
### `run.js module code (L1–L55)`

`module_region` · [benchmarking/run.js:L1-L55][f1]

Runs all benchmark suites sequentially at module load and prints cumulative timings.

It imports the reactivity and SSR benchmark lists, pushes a fresh reactive context ($.push({}, true)), then for each suite awaits every benchmark, coercing results.time and results.gc_time via Number() into both per-suite and running totals, logging suite totals with toFixed(2). Any thrown or rejected value during the awaits is caught: a failure banner is logged, the error printed to stderr, and the process exits with status 1, so $.pop() and the completion banner never run on failure. On success it pops the reactive context and logs total_time and total_gc_time.

**Notes.**

- side_effect: The entire benchmark run executes at import time; loading this module starts it.
- failure: The catch path calls process.exit(1), skipping the success-only $.pop() cleanup.
- condition: Non-numeric timing fields become NaN totals because values pass through Number() with no validation.

imports: [benchmarking/benchmarks/reactivity/index.js][f2], [benchmarking/benchmarks/ssr/index.js][f3]

**Uncertainties.**

- The $.push/$.pop contract and the benchmark result shape ({time, gc_time}) are defined outside this file.

<a id="u-823bd0dd0cd8"></a>
### `assert`

`export function assert(a)` · [benchmarking/utils.js:L96-L100][f4]

Throws a new Error('Assertion failed') when the argument is falsy; otherwise returns undefined.

Used by benchmark setups to check expected values.

uses: [mol_bench.js](r5-benchmarks.md#u-a12651df59d5)

<a id="u-0bbe8c671495"></a>
### `fastest_test`

`export async function fastest_test(times, fn)` · [benchmarking/utils.js:L82-L91][f4]

Runs fn `times` times sequentially via run_tracked, collecting each run's result and timing, then reduces with a comparison keeping the run whose timing.time is strictly smaller; ties keep the earlier run.

Returns the fastest run object {result, timing: {time, gc_time}}. If times is 0 the reduce over an empty array throws a TypeError. Any run failure propagates.

calls: [run_tracked](r4-benchmarking.md#u-cd205b57d6f7)

<a id="u-3308e4a46f8a"></a>
### `promise_delay`

`function promise_delay(timeout = 0)` · [benchmarking/utils.js:L51-L53][f4]

Returns a Promise resolved by setTimeout after the given timeout (default 0ms), used to yield to timers such as performance-entry delivery.

<a id="u-19c8243b4a22"></a>
### `read_file`

`export function read_file(file)` · [benchmarking/utils.js:L105-L107][f4]

Reads a file synchronously as UTF-8 and normalizes Windows CRLF line endings to LF before returning the string; fs errors propagate.

<a id="u-52eb06b944b0"></a>
### `run_timed`

`function run_timed(fn)` · [benchmarking/utils.js:L58-L63][f4]

Synchronously runs fn, measures elapsed performance.now() around it, and returns {result, time}; it performs no GC tracking or error handling, so exceptions from fn propagate directly.

<a id="u-cd205b57d6f7"></a>
### `run_tracked`

`async function run_tracked(fn)` · [benchmarking/utils.js:L68-L76][f4]

Measures fn's runtime and associated GC time in one tracked run.

It forces a full v8.collectGarbage() first, creates a fresh GarbageTrack observer, wraps run_timed(fn) in gc_track.watch to capture the timing window and track_id, then awaits gcDuration to sum GC pauses inside that window. It destructures the wrapped result, calls destroy() to stop observation, and returns {result, timing: {time, gc_time}}. If fn throws, the exception propagates and destroy() is skipped (no try/finally), leaving that observer connected.

**Notes.**

- failure: An exception from fn bypasses gc_track.destroy() because there is no try/finally, leaking an active PerformanceObserver for that run.

uses: [utils-js-garbagetrack](r4-benchmarking.md#u-d508b6db6446); calls: [run_timed](r4-benchmarking.md#u-52eb06b944b0)

**Uncertainties.**

- v8.collectGarbage behavior depends on the v8-natives binding being available at runtime.

<a id="u-ccb2ac8173a1"></a>
### `write`

`export function write(file, contents)` · [benchmarking/utils.js:L113-L119][f4]

Writes contents to a file, first creating its parent directory recursively via mkdirSync inside a try/catch that swallows any creation error.

If directory creation fails silently but the directory is still absent, the subsequent writeFileSync will throw. Returns nothing.

**Notes.**

- failure: mkdirSync errors are swallowed by an empty catch; only writeFileSync failures surface.

<a id="u-d508b6db6446"></a>
### `utils-js-garbagetrack`

`class GarbageTrack` · [benchmarking/utils.js:L8-L14][f4]

Tracks elapsed wall-clock windows and GC pause durations attributable to a wrapped function.

The constructor starts a PerformanceObserver subscribed to 'gc' entries, whose callback appends entries to this.perf_entries. watch(fn) increments track_id, measures performance.now() around a synchronous call of fn, records the window as {track_id, start, end}, and returns {result, track_id}. gcDuration(track_id) is async: it first awaits promise_delay(10) (giving the observer time to receive GC entries), finds the matching period, and if none exists rejects with the string 'no period found' (a non-Error rejection); otherwise it sums the durations of GC entries whose startTime falls in [start, end). destroy() disconnects the observer, after which no further GC entries are collected. Uncertainty: GC pauses overlapping but starting outside the window are excluded, and whether the 10ms delay suffices for entries to arrive is environment-dependent.

**Notes.**

- failure: gcDuration rejects with a bare string 'no period found', not an Error, when the track_id has no recorded period.
- side_effect: The observer keeps collecting GC entries into perf_entries until destroy() is called.

calls: [promise_delay](r4-benchmarking.md#u-3308e4a46f8a)

**Uncertainties.**

- Whether the fixed 10ms delay guarantees all GC performance entries for the period have been delivered is not provable from the source.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/benchmarking/run.js
[f2]: ../../../../../../eval/svelte-be645b4/benchmarking/benchmarks/reactivity/index.js
[f3]: ../../../../../../eval/svelte-be645b4/benchmarking/benchmarks/ssr/index.js
[f4]: ../../../../../../eval/svelte-be645b4/benchmarking/utils.js
