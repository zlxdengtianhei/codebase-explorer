# Compiler Pipeline

**Capability.** Owns the parse → analyze → transform pipeline that turns Svelte component source into executable JavaScript, plus the automated Svelte 4 → 5 migration tool built on the same analysis.

Use this subtree for anything that reads source and emits code. Entry points live in compiler-entry; phases are split into analysis, client transform, server transform, and migration.

**Children.**

- [Compiler Public Entry](r3-compiler-entry.md) `r3-compiler-entry` · 6 unit(s)
- [Analysis Phase](r3-analyze-phase.md) `r3-analyze-phase` · 0 unit(s)
- [Client Transform Phase](r3-client-transform.md) `r3-client-transform` · 3 unit(s)
- [Server Transform Phase](r3-server-transform.md) `r3-server-transform` · 11 unit(s)
- [Svelte 4 to 5 Migration](r3-migration.md) `r3-migration` · 0 unit(s)

Parent: [Svelte Compiler and Runtime](r3-svelte.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
