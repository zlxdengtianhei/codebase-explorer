# Transform Phase

**Capability.** Converts analyzed ASTs into executable output: a client transform producing DOM-based runtime calls, a server transform producing SSR payload code, and shared assignment handling used by both.

Choose client-transform for browser output, server-transform for SSR output, and shared-assignment-transform for the assignment driver both sides delegate to. Each side keeps its own visitor set and type contracts.

**Children.**

- [Client Transform](r1-client-transform.md) `r1-client-transform` · 21 unit(s)
- [Server Transform](r1-server-transform.md) `r1-server-transform` · 17 unit(s)
- [Shared Assignment Driver](r1-shared-assignment-transform.md) `r1-shared-assignment-transform` · 1 unit(s)

Parent: [Compiler](r1-compiler.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
