# Parsing and Lexical Helpers

**Capability.** Phase-1 text and lexical mechanics: consuming template text with entity decoding, matching brackets/quotes/regex in embedded JS, HTML entity lookup, fragment node creation, and fuzzy name matching for diagnostics.

Use this subtree when reasoning about raw template-to-AST conversion: bracket.js and text.js define what characters terminate constructs, entities.js provides the character-reference table, and fuzzymatch.js powers 'did you mean' suggestions. create.js supplies the Fragment factory used during parsing.

**Depended on by.**

- [Semantic Analysis Visitors](r4-analyze-visitors.md) · graph-confirmed · 1 edge(s)
- [Template Parsing](r5-compiler-parse.md) · graph-only · 15 edge(s)

Parent: [Compiler Pipeline](r4-compiler.md)

## Units (23)

<a id="u-36401d8c3a23"></a>
### `text`

`export default function text(parser)` · [packages/svelte/src/compiler/phases/1-parse/state/text.js:L6-L23][f1]

Consumes characters until the end of the template, a '<', or a '{', appending a Text node whose raw is the consumed slice and whose data is the raw with character references decoded (attribute-context decoding disabled).

Always appends; never returns a next state.

calls: [decode_character_references](r1-html-entity-decoding.md#u-a03f13997ae5)

<a id="u-29a08a302323"></a>
### `count_leading_backslashes`

`function count_leading_backslashes(string, search_start_index)` · [packages/svelte/src/compiler/phases/1-parse/utils/bracket.js:L77-L85][f2]

Walks backwards from search_start_index while characters are backslashes and returns the count of consecutive backslashes.

An odd count means the character after the run is escaped.

<a id="u-3e5597267416"></a>
### `find_matching_bracket`

`export function find_matching_bracket(template, index, open)` · [packages/svelte/src/compiler/phases/1-parse/utils/bracket.js:L94-L135][f2]

Finds the index of the bracket closing the one at `index`, ignoring nested brackets inside comments, strings, and regex literals.

`close` comes from the default_brackets map ({ -> }, ( -> ), [ -> ]). Loop until depth reaches zero or the template ends: quote chars jump i past find_string_end; '/' followed by nothing continues; '//' skips past the next newline, '/*' past the next '*/' (infinity_if_negative turns a missing terminator into Infinity, ending the loop via the length check); any other '/' is treated as a regex and skipped to its end. The default branch tracks depth on open/close chars and returns i when depth hits zero. Returns undefined when no close is found.

calls: [find_string_end](r4-compiler-parse.md#u-218d9a0afb81), [find_regex_end](r4-compiler-parse.md#u-61260c77d46c), [infinity_if_negative](r4-compiler-parse.md#u-edd9bb8ecede)

**Uncertainties.**

- A '/' not followed by '/' or '*' is unconditionally treated as regex start; a division operator before a nested bracket would be misread.

<a id="u-61260c77d46c"></a>
### `find_regex_end`

`function find_regex_end(string, search_start_index)` · [packages/svelte/src/compiler/phases/1-parse/utils/bracket.js:L41-L43][f2]

Thin wrapper over find_unescaped_char that locates the closing unescaped '/' of a regex literal, returning its index or Infinity if absent.

calls: [find_unescaped_char](r4-compiler-parse.md#u-e7db0acb2cbc)

<a id="u-218d9a0afb81"></a>
### `find_string_end`

`function find_string_end(string, search_start_index, string_start_char)` · [packages/svelte/src/compiler/phases/1-parse/utils/bracket.js:L21-L34][f2]

Finds the end index of a quoted string starting at search_start_index with quote character string_start_char.

For backtick strings the whole text is searched; for other quotes the search text is truncated at the first newline (indexOf returns -1 when there is none, and infinity_if_negative turns that into Infinity so the slice keeps the full string), since single/double-quoted strings cannot span lines. Delegates the scan to find_unescaped_char and returns Infinity when no unescaped terminator exists.

calls: [infinity_if_negative](r4-compiler-parse.md#u-edd9bb8ecede), [find_unescaped_char](r4-compiler-parse.md#u-e7db0acb2cbc)

<a id="u-e7db0acb2cbc"></a>
### `find_unescaped_char`

`function find_unescaped_char(string, search_start_index, char)` · [packages/svelte/src/compiler/phases/1-parse/utils/bracket.js:L52-L64][f2]

Scans for the first occurrence of char not preceded by an escaping backslash.

Loop: indexOf locates the next char; if absent, returns Infinity; otherwise count_leading_backslashes counts backslashes immediately before it and the index is returned when the count is even. An odd count means the char is escaped, so the search resumes at the following index.

calls: [count_leading_backslashes](r4-compiler-parse.md#u-29a08a302323)

<a id="u-edd9bb8ecede"></a>
### `infinity_if_negative`

`function infinity_if_negative(num)` · [packages/svelte/src/compiler/phases/1-parse/utils/bracket.js:L8-L13][f2]

Maps negative numbers to Infinity and passes all other values through unchanged.

Bracket scanning uses it to convert a failed indexOf (-1) into a sentinel that never terminates a skip loop.

<a id="u-cf3966ee18ec"></a>
### `match_bracket`

`export function match_bracket(parser, start, brackets = default_brackets)` · [packages/svelte/src/compiler/phases/1-parse/utils/bracket.js:L149-L180][f2]

Scans parser.template from start until the bracket closing the outermost opener, using a stack for proper nesting (brackets defaults to default_brackets).

Quote chars are skipped via match_quote, which also consumes template-literal interpolations. A char that is a key of `brackets` is pushed; a close value pops the stack, and if the popped bracket's expected close differs, e.expected_token is thrown at i-1. When the stack empties after a close, the index after that close is returned. Reaching the end of the template throws e.unexpected_eof; there is no non-throwing failure exit.

calls: [match_quote](r4-compiler-parse.md#u-bc749ce8d7ac); raises: [e.expected_token](../../catalog.json), [e.unexpected_eof](../../catalog.json)

**Uncertainties.**

- A close char with an empty stack pops undefined, so brackets[undefined] is undefined and e.expected_token fires before the length check; relies on well-formed input.

<a id="u-bc749ce8d7ac"></a>
### `match_quote`

`function match_quote(parser, start, quote)` · [packages/svelte/src/compiler/phases/1-parse/utils/bracket.js:L187-L213][f2]

Consumes a quoted string in parser.template starting just after the opening quote and returns the index just past the closing quote.

A backslash sets an escape flag that skips the next character; the matching quote ends the scan. In backtick strings, '$' followed by '{' triggers match_bracket so interpolation braces are consumed within the string. Hitting the end of the template throws e.unterminated_string_constant at the start index.

calls: [match_bracket](r4-compiler-parse.md#u-cf3966ee18ec); raises: [e.unterminated_string_constant](../../catalog.json)

<a id="u-6f16c2773335"></a>
### `create_fragment`

`export function create_fragment(transparent = false)` · [packages/svelte/src/compiler/phases/1-parse/utils/create.js:L7-L17][f3]

Returns a fresh AST.Fragment node with an empty nodes array and metadata {transparent (from the optional boolean parameter, default false), dynamic: false, has_await: false}.

Pure factory; no side effects; callers mutate the returned object independently.

<a id="u-8dda8fecedc4"></a>
### `entities.js-entity-table`

`group` · [packages/svelte/src/compiler/phases/1-parse/utils/entities.js:L2-L1682][f4]

Provides a single default-exported lookup table mapping HTML character-reference names to their Unicode codepoints, sourced from the WHATWG entities.json data.

Every entry is a static name-to-integer pair; keys include forms with a trailing semicolon and a smaller set without one (e.g. 'amp' vs 'amp;'), and values are decimal codepoints such as 38 for ampersand. The table is pure data: it has no methods, no computation, and no side effects, and its only observable behavior is property lookup by exact key, so consumers must supply the entity text precisely as spelled here, including case and any semicolon.

**Uncertainties.**

- The consumer that reads this table (e.g. the parser's entity decoding logic) is not in the supplied source, so how partial or case-insensitive matching is handled at lookup time cannot be confirmed here.

<a id="u-1a1551cf741f"></a>
### `FuzzySet`

`class FuzzySet` · [packages/svelte/src/compiler/phases/1-parse/utils/fuzzymatch.js:L123-L134][f5]

Approximate string-matching set adapted from fuzzyset.js.

It indexes candidate strings by 2- and 3-character grams (GRAM_SIZE_LOWER/UPPER); exact_set maps lowercase values to originals for exact hits, match_dict maps each gram to [index, count] postings, and items[gram_size] stores per-string [vector normal, normalized value]. Construction adds every input string via add. Lookup degrades gracefully from large to small gram sizes; a member has no individual value except through its methods.

<a id="u-53c64f37672a"></a>
### `_distance`

`function _distance(str1, str2)` · [packages/svelte/src/compiler/phases/1-parse/utils/fuzzymatch.js:L27-L37][f5]

Returns a normalized similarity from 0 to 1 between two strings: 1 minus the Levenshtein distance divided by the longer string's length.

Two null inputs throw the string 'Trying to compare two null values'; one null input returns 0. Inputs are coerced with String before comparison.

calls: [levenshtein](r4-compiler-parse.md#u-1ed726d7da45)

<a id="u-4d517976b3f9"></a>
### `fuzzymatch`

`export default function fuzzymatch(name, names)` · [packages/svelte/src/compiler/phases/1-parse/utils/fuzzymatch.js:L6-L13][f5]

Returns the best fuzzy match for `name` from `names`, or null.

Empty name list returns null immediately. Otherwise builds a FuzzySet from the candidates and gets matches for the name; the top candidate is returned (as [score, name]) only if its normalized score exceeds 0.7, otherwise null.

uses: [FuzzySet.constructor](r4-compiler-parse.md#u-f00815f4d95d); calls: [FuzzySet.get](r4-compiler-parse.md#u-c7b2b46a6dea)

<a id="u-500fe48ba9fb"></a>
### `gram_counter`

`function gram_counter(value, gram_size = 2)` · [packages/svelte/src/compiler/phases/1-parse/utils/fuzzymatch.js:L97-L113][f5]

Builds a Record mapping each gram from iterate_grams(value, gram_size) to its number of occurrences.

Pure counting helper used for cosine-style gram similarity.

calls: [iterate_grams](r4-compiler-parse.md#u-883c73062dca)

<a id="u-883c73062dca"></a>
### `iterate_grams`

`function iterate_grams(value, gram_size = 2)` · [packages/svelte/src/compiler/phases/1-parse/utils/fuzzymatch.js:L77-L91][f5]

Produces substring grams of size gram_size (default 2) from the value: the value is lowercased, non-[\w, ] characters stripped, and padded with '-' on both ends.

If the simplified string is shorter than the gram size, trailing '-' padding is appended to the (unused) value variable — note the pad loop appends to `value`, not `simplified`, so it has no effect on the grams produced.

**Notes.**

- side_effect: Pure function; the apparent padding branch mutates a local only and does not change output.

**Uncertainties.**

- The len_diff padding loop modifies `value` instead of `simplified`, so it appears to be dead code affecting the result only through `simplified`, which is unchanged.

<a id="u-1ed726d7da45"></a>
### `levenshtein`

`function levenshtein(str1, str2)` · [packages/svelte/src/compiler/phases/1-parse/utils/fuzzymatch.js:L45-L69][f5]

Computes the Levenshtein edit distance with a single rolling row of the DP matrix.

Outer loop over str2, inner over str1: equal characters carry the diagonal value, otherwise the row minimum plus one; row/column boundaries use i+j. Returns the last computed cell (current.pop()) as the distance.

<a id="u-388181d4f9b2"></a>
### `sort_descending`

`function sort_descending(a, b)` · [packages/svelte/src/compiler/phases/1-parse/utils/fuzzymatch.js:L119-L121][f5]

Comparator for [score, match] tuples sorting by score descending.

<a id="u-6130c9704ec3"></a>
### `FuzzySet.__get`

`__get(value, gram_size)` · [packages/svelte/src/compiler/phases/1-parse/utils/fuzzymatch.js:L212-L277][f5]

Fuzzy-scored lookup at one gram size.

Builds gram counts for the query, accumulates dot products per candidate index from match_dict postings, and computes cosine scores as dot product divided by (query normal × candidate normal). Results are sorted descending, truncated to 50, re-scored with _distance against the normalized query, sorted again, and only tuples whose score equals the top score are kept, mapped back through exact_set to the original strings.

**Notes.**

- contract: Returned matches map back to the original casing via exact_set; scores are the minimal _distance value shared by all top ties.

calls: [gram_counter](r4-compiler-parse.md#u-500fe48ba9fb), [_distance](r4-compiler-parse.md#u-53c64f37672a), [sort_descending](r4-compiler-parse.md#u-388181d4f9b2)

**Uncertainties.**

- If items[gram_size] is undefined for a gram size with no indexed items, the score expression would throw; get guards this only implicitly by gram sizes always populated at construction.

<a id="u-15a18bec466b"></a>
### `FuzzySet._add`

`_add(value, gram_size)` · [packages/svelte/src/compiler/phases/1-parse/utils/fuzzymatch.js:L163-L188][f5]

Indexes one string at one gram size.

Appends a placeholder to items[gram_size] (or a fresh array) at the next index, computes gram counts via gram_counter on the lowercased value, accumulates squared gram counts, and appends [index, count] postings to match_dict per gram. Stores the vector normal sqrt(sum of squares) and normalized value in items, and maps the lowercase value to the original in exact_set.

calls: [gram_counter](r4-compiler-parse.md#u-500fe48ba9fb)

<a id="u-dca5ce597b3b"></a>
### `FuzzySet.add`

`add(value)` · [packages/svelte/src/compiler/phases/1-parse/utils/fuzzymatch.js:L147-L157][f5]

Adds a value at both gram sizes unless a case-insensitive duplicate already exists in exact_set, in which case it returns false without changes; otherwise delegates to _add for gram sizes 2 and 3.

calls: [FuzzySet._add](r4-compiler-parse.md#u-15a18bec466b)

**Uncertainties.**

- No explicit return on the success path, so the function returns undefined for new values and false for duplicates.

<a id="u-f00815f4d95d"></a>
### `FuzzySet.constructor`

`constructor(arr)` · [packages/svelte/src/compiler/phases/1-parse/utils/fuzzymatch.js:L134-L144][f5]

Initializes empty item arrays for gram sizes 2 and 3, then adds every string in `arr` via add, populating exact_set, match_dict, and items.

calls: [FuzzySet.add](r4-compiler-parse.md#u-dca5ce597b3b)

<a id="u-c7b2b46a6dea"></a>
### `FuzzySet.get`

`get(value)` · [packages/svelte/src/compiler/phases/1-parse/utils/fuzzymatch.js:L191-L205][f5]

Returns matches for a value as [score, string] tuples, or null.

An exact case-insensitive hit short-circuits to [[1, original]]. Otherwise tries gram size 3 first, then 2, returning the first non-empty result set from __get; if none, returns null.

calls: [FuzzySet.__get](r4-compiler-parse.md#u-6130c9704ec3)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/1-parse/state/text.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/1-parse/utils/bracket.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/1-parse/utils/create.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/1-parse/utils/entities.js
[f5]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/1-parse/utils/fuzzymatch.js
