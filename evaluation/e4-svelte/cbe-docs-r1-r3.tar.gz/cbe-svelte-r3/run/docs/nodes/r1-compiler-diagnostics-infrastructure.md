# Compiler Warning Infrastructure

**Capability.** The compiler's warning diagnostic class, the shared filter-and-record gate every emitter uses, the generated per-code warning emitter functions with their codes list, and the code-generator template for server-side error throwing functions.

Use when adding or changing a compiler warning or server error code. The generated emitters call through to the plumbing gate (81 call sites); server-errors.js is the template expanded into src/internal/server/errors.js.

**Depended on by.**

- [Accessibility Checks](r1-a11y-checks.md) · model-inferred · 0 edge(s)
- [Shared Analysis Visitors & Helpers](r1-analysis-visitors.md) · model-inferred · 0 edge(s)

Parent: [Compiler](r1-compiler.md)

## Units (3)

<a id="u-31c5078caed8"></a>
### `warnings-js-warning-plumbing`

`class InternalCompileWarning extends CompileDiagnostic` · [packages/svelte/src/compiler/warnings.js:L7-L15][f1]

Defines the compiler's warning diagnostic class and the shared filter-and-record gate every warning emitter uses.

InternalCompileWarning extends CompileDiagnostic, sets its name field to 'CompileWarning', and its constructor only forwards code, message, and position to the superclass. w(node, code, message) starts from the current ignore_stack; when a node is passed it prefers the per-node stack from ignore_map, falling back to ignore_stack when the node is unmapped. If a stack exists and its innermost entry (stack.at(-1)) contains the code, the warning is silently dropped before construction. Otherwise an InternalCompileWarning is created with position [node.start, node.end ?? node.start] when node.start is defined, or undefined position otherwise; if warning_filter rejects the instance nothing is recorded, otherwise it is pushed onto the shared warnings array.

**Notes.**

- side_effect: w appends accepted InternalCompileWarning instances to the warnings array imported from './state.js'.
- contract: Suppression and filtering semantics depend on ignore_stack, ignore_map, and warning_filter from './state.js'; this file only consumes them.

imports: [packages/svelte/src/compiler/state.js][f2]; inherits: [packages/svelte/src/compiler/utils/compile_diagnostic.js][f3]; calls: [packages/svelte/src/compiler/utils/compile_diagnostic.js][f3]

**Uncertainties.**

- CompileDiagnostic's constructor behavior and warning_filter's rejection criteria live outside this file; only their call shapes are observable here.

<a id="u-915204921132"></a>
### `warnings-js-code-warnings`

`export function a11y_accesskey(node)` · [packages/svelte/src/compiler/warnings.js:L129-L131][f1]

Holds the generated exported warning emitter functions (one per warning code) plus the exported codes array that enumerates those code strings.

Each emitter takes a nullable NodeLike node plus code-specific string parameters and delegates to w with a fixed code and a templated message ending in a svelte.dev/e/<code> URL. Three emitters vary the message by a truthiness condition: a11y_unknown_aria_attribute and a11y_unknown_role append a 'Did you mean <suggestion>?' clause when suggestion is truthy, and unknown_code formats with or without a suggestion; all other emitters interpolate their parameters unconditionally. No emitter has local logic beyond message construction; suppression, filtering, and recording are entirely delegated to w, so each emitter is a no-op when its code is ignored or the diagnostic is filtered.

calls: [warnings-js-warning-plumbing](r1-compiler-diagnostics-infrastructure.md#u-31c5078caed8)

**Uncertainties.**

- Whether callers rely on parameter interpolation edge cases (e.g. undefined name or role values) is not observable from this file.

<a id="u-b9126e67f9c3"></a>
### `server-errors.js-code-template`

`export function CODE(PARAMETER)` · [packages/svelte/scripts/process-messages/templates/server-errors.js:L8-L12][f4]

Code-generator template for server-side error throwing functions (expanded into src/internal/server/errors.js by process-messages).

It re-exports everything from ../shared/errors.js and exports a CODE function template that always throws — unlike the shared/client templates it is not DEV-gated: it builds an Error containing the code string, the message, and the https://svelte.dev/e/<code> link, names it 'Svelte error', and throws it. The generator substitutes the code literals, MESSAGE, and PARAMETER to emit one function per code.

contract: [index.js-run](r2-message-codegen.md#u-f2d5f8b6c5f2)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/warnings.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/state.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/utils/compile_diagnostic.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/scripts/process-messages/templates/server-errors.js
