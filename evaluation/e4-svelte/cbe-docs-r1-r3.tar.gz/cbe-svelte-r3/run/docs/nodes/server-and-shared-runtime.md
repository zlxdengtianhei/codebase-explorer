# Server & Shared Runtime

**Capability.** Executes compiled output outside the browser and holds consumer-agnostic runtime contracts: SSR payload buffers, context maps, stale-reaction aborts, plus environment-agnostic store implementations, error throwers, validation helpers, and pure utilities (escaping, HTML content-model tables) used by both runtimes.

Use when changing SSR output plumbing or behavior that must hold on client and server. Nothing here knows about compilation internals; both the compiler and the client runtime consume these pieces (region-0003→region-0004/0005 edges).

**Children.**

- [Svelte Compiler and Runtime](r3-svelte.md) `r3-svelte` · 1 unit(s)

**Depends on.**

- [Client Runtime](client-runtime.md) · graph-confirmed · 113 edge(s)
- [Public API, Types & Reactive Primitives](public-api-types.md) · graph-confirmed · 59 edge(s)

**Depended on by.**

- [Client Runtime](client-runtime.md) · graph-confirmed · 37 edge(s)
- [Public API, Types & Reactive Primitives](public-api-types.md) · graph-confirmed · 22 edge(s)
- [Svelte Repository](svelte-repo.md) · containment · → 0 / ← 0 edge(s) (ancestor direct units and descendant subtree; → follows ` svelte-repo ` → ` server-and-shared-runtime `)

Parent: [Svelte Repository](svelte-repo.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
