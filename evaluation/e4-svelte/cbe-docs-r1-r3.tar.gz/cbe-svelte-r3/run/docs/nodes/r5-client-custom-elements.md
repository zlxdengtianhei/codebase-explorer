# Custom Element Hosting

**Capability.** Exposes Svelte components as native custom elements: the SvelteElement HTMLElement subclass (guarded on HTMLElement existence), create_custom_element registration, attribute↔prop value conversion by declared type, and slot discovery from existing children.

Use when changing the wrapper-component custom element story. SvelteElement reads/writes props through get_custom_element_value; create_custom_element wires the constructor onto Component.element.

**Depends on.**

- [DOM Operations & Elements](r5-client-dom.md) · model-inferred · 0 edge(s)

Parent: [Client Runtime](r5-runtime-client.md)

## Units (4)

<a id="u-700d12a35f8e"></a>
### `custom-element.js-create-custom-element`

`export function create_custom_element( Component, props_definition, slots, exports, u…` · [packages/svelte/src/internal/client/dom/elements/custom-element.js:L283-L291][f1]

Turns a Svelte component constructor into a custom element class and registers it on Component.element.

It creates a class extending SvelteElement whose constructor passes the component, slots, and use_shadow_dom to super and installs the shared props_definition on $$p_d; its static observedAttributes getter returns the lowercase attribute names (attribute || key) of all defined props. For each prop definition, an accessor pair is defined on the prototype: the getter returns the live component value when the prop exists on the instance, otherwise the locally stored $$d value; the setter converts the value via get_custom_element_value, stores it in $$d, and if a component instance exists either assigns directly to the instance (when it has a getter/accessor for the prop) or pushes it via $set. Each entry in exports gets a read-only getter delegating to the component instance ($$c?.[property]). If extend is supplied, the class is replaced by extend(Class) before being assigned to Component.element and returned.

inherits: [custom-element.js-svelteelement-class](r5-client-custom-elements.md#u-7ae3280ce832); calls: [get_custom_element_value](r5-client-custom-elements.md#u-b0718db16728)

**Uncertainties.**

- get_descriptor(component, prop)?.get is used as the setter signal per the source comment ('If the instance has an accessor'); using a getter descriptor to decide assignment versus $set is as written but unusual.
- The class references SvelteElement, which is undefined-like when HTMLElement is unavailable; behavior in that environment is not shown.

<a id="u-7ae3280ce832"></a>
### `custom-element.js-svelteelement-class`

`class extends HTMLElement` · [packages/svelte/src/internal/client/dom/elements/custom-element.js:L17-L44][f1]

Defines SvelteElement, an HTMLElement subclass (only created when typeof HTMLElement === 'function') that hosts a Svelte component as a custom element.

The constructor stores the component constructor, slot names, and optionally attaches an open shadow root. addEventListener forwards to super but also records the listener in $$l and, if the component instance exists, subscribes via $on and caches the unsubscribe in $$l_u; a custom event named like a native event fires both handlers. removeEventListener removes via super and, if a $on unsubscribe exists, calls and deletes it. connectedCallback is async: it sets $$cn, and if no instance exists, awaits one microtask (letting child slot elements mount), aborting if disconnected or already initialized. It builds slot factories (create_slot makes a <slot> element, named unless 'default', appended to the anchor; 'default' goes into $$d.children when no children prop exists), converts attributes to props via $$g_p name mapping and get_custom_element_value, ports over pre-initialization programmatic prop values (deleting shadowing own properties), then mounts the component with createClassComponent targeting shadowRoot or the element itself, passing $$slots and $$host. An effect_root/render_effect reflects props marked reflect back to attributes (setting $$r to suppress attributeChangedCallback during reflection, removing the attribute when the converted value is null), and pending $$l listeners are subscribed via $on and $$l cleared. attributeChangedCallback ignores calls during reflection ($$r), maps the attribute name through $$g_p, converts to a prop value, and calls $set if the instance exists. disconnectedCallback sets $$cn false, then in a microtask, if still disconnected and an instance exists, destroys it, tears down $$me, and clears $$c. $$g_p maps an attribute name to its prop key by finding a definition whose attribute matches or whose lowercase key matches when no attribute is defined, falling back to the name itself.

**Notes.**

- side_effect: connectedCallback mutates $$d, $$c, $$me, $$l_u and DOM attributes; disconnectedCallback destroys state asynchronously so a quick reconnect cancels teardown.

calls: [createClassComponent](r2-legacy-client.md#u-f1a6026980f8), [effect_root](r4-runtime-effects.md#u-188599523a26), [append](r3-client-template.md#u-daaa1d70e416)

**Uncertainties.**

- Behavior of createClassComponent and effect_root teardown semantics come from outside this file and are not verified here.

<a id="u-b0718db16728"></a>
### `get_custom_element_value`

`function get_custom_element_value(prop, value, props_definition, transform)` · [packages/svelte/src/internal/client/dom/elements/custom-element.js:L228-L258][f1]

Converts a value between a custom element attribute and a Svelte prop according to the prop's declared type.

Boolean coercion happens up front: a non-boolean value becomes value != null (truthy unless null/undefined) when the type is 'Boolean'. With no transform or no matching prop definition the (possibly coerced) value is returned unchanged. For 'toAttribute': Object/Array values are JSON.stringify'd (null if null/undefined), Boolean true becomes '' and false null, Number null/undefined stays null, default returns the value. For 'toProp' (the else branch): Object/Array strings are JSON.parse'd (returning undefined for falsy input), Boolean is returned as-is since coercion already happened, Number strings are converted with unary + unless null/undefined, default returns the value unchanged.

<a id="u-2b317b984503"></a>
### `get_custom_elements_slots`

`function get_custom_elements_slots(element)` · [packages/svelte/src/internal/client/dom/elements/custom-element.js:L263-L270][f1]

Builds a record of slot names already present as child nodes of an element.

Each child node contributes result[node.slot || 'default'] = true, so children without a slot attribute register as the default slot. Returns the record; iteration order follows child order but the result is used only as a name-presence map.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/elements/custom-element.js
