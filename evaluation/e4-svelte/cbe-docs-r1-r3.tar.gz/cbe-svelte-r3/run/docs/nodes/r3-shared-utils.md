# Shared Predicates and Hash

**Capability.** Small pure lookup predicates backed by module-level constant lists, plus two string utilities and a djb2-style hash used to validate {@html} content.

These are the utility calls that appear throughout the compiler and both runtimes; grep targets for shared string/keyword checks.

**Depended on by.**

- [Analysis Driver](r3-analyze-driver.md) · graph-confirmed · 3 edge(s)
- [Analysis Visitors](r3-analyze-visitors.md) · graph-confirmed · 1 edge(s)
- [Client Attribute Application](r3-client-attributes.md) · graph-confirmed · 3 edge(s)
- [Client Transform Visitors](r3-client-transform-visitors.md) · graph-confirmed · 4 edge(s)
- [Migration Script Visitors](r3-migrate-script-visitors.md) · model-inferred · 0 edge(s)
- [Migration Template Visitors](r3-migrate-template-visitors.md) · graph-confirmed · 3 edge(s)
- [Server Markup Serialization](r3-server-markup.md) · graph-confirmed · 1 edge(s)
- [Server Render Entry](r3-server-render-entry.md) · graph-confirmed · 2 edge(s)
- [Server Transform Phase](r3-server-transform.md) · graph-confirmed · 7 edge(s)

Parent: [Shared Utilities and Public Contracts](r3-shared.md)

## Units (2)

<a id="u-7eb274f609ad"></a>
### `utils-js-predicates`

`export function is_void(name)` · [packages/svelte/src/utils.js:L39-L41][f1]

A set of small pure lookup helpers plus two string utilities, each backed by a module-level constant list.

Most predicates are exact, case-sensitive membership checks via Array.includes: is_void (void elements, additionally accepting '!doctype' case-insensitively), is_reserved (JavaScript reserved words), is_delegated (events handled via delegation, e.g. click and input), is_boolean_attribute (present/absent attributes like disabled and checked), is_dom_property (names that must be set as DOM properties, including value and volume), cannot_be_set_statically (autofocus, muted, defaultValue, defaultChecked — attributes needing JavaScript handling rather than a template string), is_passive_event (touchstart, touchmove), is_content_editable_binding (textContent, innerHTML, innerText), is_load_error_element (elements emitting load/error events), is_svg and is_mathml (namespace element lists steering compiler transforms), is_rune and is_state_creation_rune (rune-name lists that also serve as RuneName type guards), and is_raw_text_element (textarea, script, style, title — elements that take raw text and must not receive SSR comments). is_capture_event is the one non-list predicate: true when a name ends with 'capture' except 'gotpointercapture' and 'lostpointercapture'. normalize_attribute lowercases the name and maps it through ATTRIBUTE_ALIASES to the DOM property spelling (e.g. 'readonly' to 'readOnly'; 'class' deliberately absent). sanitize_location inserts a zero-width space after every '/' to prevent devtools linkifying source locations, returning undefined unchanged via optional chaining. All are side-effect free and, for string input, cannot throw.

**Uncertainties.**

- Matching is case-sensitive for every list except the '!doctype' check in is_void and the explicit lowercase in normalize_attribute; whether callers normalize casing first is not visible in this file.

<a id="u-a8a8fa6d6333"></a>
### `hash`

`export function hash(str)` · [packages/svelte/src/utils.js:L7-L14][f1]

Computes a deterministic djb2-style hash of a string, used to validate {@html ...} content.

All carriage returns are removed first via the module-level /\r/g regex; the loop then iterates from the end of the string computing `hash = ((hash << 5) - hash) ^ str.charCodeAt(i)`. The result is normalized with >>> 0 to an unsigned 32-bit integer and returned in base 36. Same input always yields the same output; inputs differing only in \r produce identical hashes.

uses: [check_hash](r4-runtime-dom-blocks.md#u-1df4a5c06d12)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/utils.js
