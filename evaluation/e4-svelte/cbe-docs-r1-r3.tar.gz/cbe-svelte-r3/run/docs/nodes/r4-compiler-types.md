# Compiler Type Declarations

**Capability.** Declares the compiler's public type surface: the public compile API types, internal compiler metadata types, and the modern template AST namespace with estree augmentation.

Use these declarations to understand the data contracts flowing between compiler phases. The internal group is not public API; the AST namespace in template.d.ts is what parsed templates conform to.

**Depended on by.**

- [Compiler Pipeline](r4-compiler.md) · containment · → 0 / ← 0 edge(s) (ancestor direct units and descendant subtree; → follows ` r4-compiler ` → ` r4-compiler-types `)

Parent: [Compiler Pipeline](r4-compiler.md)

## Units (3)

<a id="u-9ca884f55142"></a>
### `index.d.ts-compile-api`

`export interface CompileResult` · [packages/svelte/src/compiler/types/index.d.ts:L14-L50][f1]

Declares the public compiler API types.

`CompileResult` returns compiled `js` and `css` payloads (each with `code` and a magic-string `SourceMap`; `css` is `null` when the component has none, and its `hasGlobal` flag reports global rules), a `warnings` array, `metadata.runes` (always `true` for `compileModule`), and an untyped `ast`. `Warning` and `CompileError` are empty extensions of `ICompileDiagnostic`. `CssHashGetter` is the callback contract for producing the scoped-CSS classname from `{ name, filename, css, hash }`. `CompileOptions` extends `ModuleCompileOptions` and documents each option's effect and default as written: `css` is always `'injected'` in custom-element mode; `runes?: boolean | undefined` with `undefined` meaning infer from code; `fragments: 'html'` populates a template via `innerHTML` and fails under a CSP with `require-trusted-types-for 'script'`, while `'tree'` is slower but universal; `accessors` and `immutable` are deprecated no-ops in runes mode; `generate: false` produces no output for warning-only tooling. `ValidatedModuleCompileOptions` requires all module options except `rootDir`, which stays optional-typed but present; `ValidatedCompileOptions` composes it with `Required<CompileOptions>`, then re-widens `name`, `outputFilename`, `cssOutputFilename`, `sourcemap`, and `runes` back to their optional forms and forces `compatibility` fully required, also adding `customElementOptions`. These are type-only declarations; the runtime validation they describe lives elsewhere.

uses: [template.d.ts-types](r4-compiler-types.md#u-d5bf4f9acf4a), [index.d.ts-internal](r4-compiler-types.md#u-d832db9b26d5)

**Uncertainties.**

- The comment calls the validated types 'scary looking' to make fields required-but-undefined-able; which fields the runtime validator actually populates cannot be proven from these aliases alone

<a id="u-d832db9b26d5"></a>
### `index.d.ts-internal`

`export type BindingKind = | 'normal' // A variable that is not in any way special | '…` · [packages/svelte/src/compiler/types/index.d.ts:L267-L280][f1]

Declares internal compiler metadata types.

`BindingKind` enumerates binding categories (`normal`, `prop`, `bindable_prop`, `rest_prop`, `raw_state`, `state`, `derived`, `each`, `snippet`, `store_sub`, `legacy_reactive`, `template`, `static`). `DeclarationKind` enumerates declaration forms from `var` through `synthetic`. `ExpressionMetadata` records per-expression analysis: `dependencies` are bindings referenced eagerly (outside functions) while `references` includes function-contained uses; the boolean flags `has_state`, `has_call`, `has_await`, `has_member_expression`, and `has_assignment` drive codegen decisions such as wrapping in a derived. `StateField` describes a `$state`-style rune field via its creation rune name, the `PropertyDefinition` or `AssignmentExpression` node, a `PrivateIdentifier` key, and the rune `CallExpression`. The file's trailing region also re-exports `./template.js` wholesale and re-exports `Binding`, `Scope`, and `ReactiveStatement` from internal phase modules.

imports: [template.d.ts-types](r4-compiler-types.md#u-d5bf4f9acf4a); uses: [grp:index.d.ts-internal][f1]

<a id="u-d5bf4f9acf4a"></a>
### `template.d.ts-types`

`export type Namespace = 'html' | 'svg' | 'mathml';` · [packages/svelte/src/compiler/types/template.d.ts:L28-L28][f2]

Declares the `AST` namespace: the modern template AST for Svelte components, plus supporting type aliases and an `estree` module augmentation.

`BaseNode` gives nodes `type`/`start`/`end`; `Fragment.nodes` mixes `Text`, `Tag`, `ElementLike`, `Block`, and `Comment` and carries internal metadata (`transparent` scopes delegate to parents for unique-identifier generation, `dynamic` controls mount/hydrate traversal, `has_await`). `Root` holds inline `SvelteOptions` (overriding `compile(...)` options), the parsed CSS style sheet, instance and module scripts, and script/expression `JSComment`s. Tag nodes (`ExpressionTag`, `HtmlTag`, `ConstTag`, `RenderTag`, `AttachTag`) each embed `ExpressionMetadata`; `RenderTag` additionally tracks candidate snippets for CSS pruning. Directives (`Animate`, `Bind`, `Class`, `Let`, `On`, `Style`, `Transition`, `Use`) follow a `name`/`expression`/`modifiers` shape, with `BindDirective.metadata` recording binding groups and parent each blocks. `BaseElement` requires `attributes` and a `Fragment`; concrete elements specialize it — components carry per-attribute `scopes` and snippet sets for pruning, `RegularElement` flags `svg`/`mathml`/`has_spread`/`scoped`, and `SvelteElement`'s `svg`/`mathml` flags are best-effort because the tag is dynamic. Blocks: `EachBlock` (with `is_controlled` optimization when the block is the single child of a non-fragment parent, `transitive_deps` for legacy invalidation, `keyed`, `contains_group_binding`), `IfBlock` (`elseif` flag), `AwaitBlock` (pending/then/catch fragments), `KeyBlock`, `SnippetBlock` (with `can_hoist` and pruning `sites`). `Attribute.value` is `true`, an `ExpressionTag`, or a mixed `Text`/`ExpressionTag` array; its metadata records delegated events and `needs_clsx`. `SvelteOptionsRaw` is a parse-time-only intermediate. The union aliases (`AttributeLike`, `Directive`, `Block`, `ElementLike`, `Tag`, `TemplateNode`, `SvelteNode`) compose these, with `SvelteNode` including estree `Node`, `Fragment`, `_CSS.Node`, and `Script`, and the namespace re-exports `_CSS` as `CSS`. A trailing `declare module 'estree'` adds optional `start`, `end`, and acorn-typescript `typeAnnotation` to `estree.BaseNode`. Pure type declarations with no runtime behavior.

uses: [css.d.ts-css-ast](r2-compiler-foundations.md#u-b61efd19fa24), [index.d.ts-internal](r4-compiler-types.md#u-d832db9b26d5)

**Uncertainties.**

- Consumer behavior of flags like `is_controlled`, `can_hoist`, and `delegated` is described only by doc comments; the codegen implementing them is not in this batch

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/types/index.d.ts
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/types/template.d.ts
