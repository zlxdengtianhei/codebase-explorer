# Client Codegen Visitors

**Capability.** Serializes the analyzed tree into client-side runtime calls: template DOM construction, reactive assignments and expressions, block/component serialization, and a shared utility layer including the memoizer for extracting complex expressions.

Use when changing client output shape. shared/utils.js helpers (build_expression, build_render_statement, validate_mutation, memoizer) are consumed by the per-node visitors; component.js builds full component instantiations; transform-template assembles the literal template and its dev locations.

**Depends on.**

- [Analysis Phase](r5-compiler-analyze.md) · model-inferred · 0 edge(s)
- [Compiler State & AST Utilities](r5-compiler-state-utils.md) · graph-confirmed · 4 edge(s)
- [AST Manipulation Utilities](r4-compiler-ast-utils.md) · graph-only · 11 edge(s)

**Depended on by.**

- [Transform Entry & Result Assembly](r5-transform-entry.md) · model-inferred · 0 edge(s)
- [Client Code Transformation](r4-transform-client.md) · graph-only · 23 edge(s)
- [Client Transform](r1-client-transform.md) · graph-only · 12 edge(s)

Parent: [Transform Phase](r5-compiler-transform.md)

## Units (25)

<a id="u-6874463c92d7"></a>
### `utils-js-memoizer`

`add(expression, has_await)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/utils.js:L28-L34][f1]

Extracts complex expressions (calls, awaits) from templates, replacing them with generated `$0`, `$1`, ...

identifiers so they are evaluated once. add(expression, has_await) returns a placeholder `#` identifier and queues the expression in the sync or async list. apply() renames every placeholder to its positional `$n` name and returns the ids in sync-then-async order. deriveds(runes) emits let declarations wrapping each sync expression in `$.derived` (runes) or `$.derived_safe_equal` (legacy) via a thunk. async_ids returns the async placeholder ids; async_values returns an array of async thunks or undefined when empty; sync_values likewise returns sync thunks or undefined when empty.

uses: [component-js-build-component](r5-transform-client.md#u-af8f6b0917f6), [build_attribute_effect](r4-transform-client.md#u-0abd8487f7a1)

<a id="u-af8f6b0917f6"></a>
### `component-js-build-component`

`export function build_component(node, component_name, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/component.js:L18-L83][f2]

Serializes a Component, SvelteComponent, or SvelteSelf node into client-side instantiation statements.

It collects props, spreads, events, slots, bindings, snippets, and CSS custom properties, then emits mounting code. Per-attribute dispatch: LetDirectives become `lets` statements (visited with states.default unless a slot prop/slot attribute makes slot scope apply to the component itself, in which case they are pushed to init and also prepended to the default slot function); OnDirective handlers are built with build_event_handler, wrapped in `$.once` for the once modifier, and grouped into a `$$events` init prop; SpreadAttribute becomes a thunk when it has state, memoized via `$.get` when it also has await or calls, otherwise a plain expression; `--`-prefixed Attributes become custom_css_props built with build_attribute_value (values with calls/awaits memoized); other Attributes use build_attribute_value and are memoized in a derived when they have await or any non-Identifier/non-MemberExpression expression chunk, then pushed as a getter prop if stateful or an init prop otherwise. BindDirective in dev mode, when not `this`, not ignored for ownership_invalid_binding, and not a SequenceExpression, adds an `$$ownership_validator.binding` initializer and sets needs_mutation_validation when the bound name resolves to a prop or bindable_prop. Sequence-expression bindings become get/set prop pairs from generated bind_get/bind_set vars; `bind:this` is deferred to build_bind_this. Non-sequence bindings are validated in dev runes mode via validate_binding for MemberExpressions, delayed via push_prop(delay=true) so they follow spreads, with store subs additionally emitting `$.mark_store_binding`; AttachTag becomes an `$.attachment` prop whose value, when stateful, is wrapped in an arrow taking `$$node` and defaulting to `$.noop` when the evaluated expression is not a function. After attributes, delayed props are flushed; `$$events` and `$$slots` objects are emitted when non-empty; non-runes components with bind directives get `$$legacy: true`. Snippet blocks are hoisted into snippet_declarations and pushed as props, with `$$slots.default: true` interop. Children grouped by slot name (determine_slot, default 'default') are serialized into slot arrow functions; a default slot with no lets and no SvelteFragment lets becomes a `children` prop (wrapped in `$.wrap_snippet` in dev) plus `$$slots.default: true`, otherwise children errors via `$.invalid_default_snippet`. Props collapse to a single object when only one property group exists, otherwise `$.spread_props`. When bind_this is present or the component is dynamic, the instantiation function `fn` is wrapped accordingly: dynamic components go through `$.component` with a thunk for the component expression and an arrow containing binding_initializers, otherwise those initializers join the statements. Custom CSS props force a wrapper element (`g` in svg, else `svelte-css-wrapper` with display:contents) plus `$.css_props`, mounting on anchor.lastChild and `$.reset`; otherwise a template comment and add_svelte_meta wrap the mount call. Finally memoizer.apply() renames placeholder ids and, if async values exist, statements are wrapped in a `$.async` call; the result is a block for multiple statements or the single statement otherwise.

**Notes.**

- side_effect: Mutates context.state.init, context.state.analysis (needs_props, needs_mutation_validation), and pushes comments/elements to context.state.template.
- condition: A `slot` attribute or any slot property (determine_slot) makes slot scope apply to the component itself, changing where lets are emitted and which state is used for the default slot.
- field: push_prop with delay queues the push so binding props are appended after spreads, preventing spread objects from overwriting them.

uses: [utils-js-memoizer](r5-transform-client.md#u-6874463c92d7); calls: [build_bind_this](r5-transform-client.md#u-62396233e782), [validate_binding](r5-transform-client.md#u-91b59b999e05), [add_svelte_meta](r5-transform-client.md#u-75700db42066), [build_attribute_value](r4-transform-client.md#u-2462157783c9), [build_event_handler](r2-client-transform.md#u-227977f005ec), [determine_slot](r2-compiler-foundations.md#u-ead26eb5b43f)

**Uncertainties.**

- Runtime semantics of `$.css_props`, `$.spread_props`, `$.bind_this`, `$.async`, `$.component` are outside this file; only call shapes are observable.
- The has_children_prop flag is set but the source shown does not display where a children-prop attribute value itself is consumed beyond the flag.

<a id="u-799dccdfecc2"></a>
### `fix_attribute_casing`

`export default function fix_attribute_casing(name)` · [packages/svelte/src/compiler/phases/3-transform/client/transform-template/fix-attribute-casing.js:L15-L18][f3]

Normalizes an attribute name to its SVG-correct casing.

The name is lowercased and looked up in a map built from the module's SVG attribute list; a hit returns the canonical form (e.g. 'viewbox' -> 'viewBox'), a miss returns the lowercased input unchanged. Attributes outside the SVG set are therefore returned lowercased even if originally mixed-case.

**Uncertainties.**

- Whether callers expect non-SVG names to survive with original casing is not decidable here; the function always lowercases before lookup.

<a id="u-e3fa95e759b1"></a>
### `build_locations`

`function build_locations(nodes)` · [packages/svelte/src/compiler/phases/3-transform/client/transform-template/index.js:L12-L31][f4]

Builds a dev-only array of source locations for template elements.

It walks the given template nodes recursively, skipping non-element nodes, and for each element records [line, column] taken from the module-level locator at the element's start offset; child locations are appended as a nested array only when non-empty. Returns a builders array expression.

calls: [transform_template](r5-transform-client.md#u-e8f6b714535e)

**Uncertainties.**

- locator(node.start) is cast to Location without a guard; null handling is not visible.

<a id="u-e8f6b714535e"></a>
### `transform_template`

`export function transform_template(state, namespace, flags = 0)` · [packages/svelte/src/compiler/phases/3-transform/client/transform-template/index.js:L38-L68][f4]

Builds the runtime call that instantiates the accumulated template as DOM.

It renders via as_tree when state.options.fragments === 'tree', otherwise as_html, then calls `$.from_tree` or `$.from_<namespace>` with the expression and a flags literal only when flags are non-zero. In tree mode the svg/mathml namespace bits (TEMPLATE_USE_SVG / TEMPLATE_USE_MATHML) are OR-ed into flags; otherwise the namespace is encoded only in the callee name. When template.contains_script_tag is set the call is wrapped in `$.with_script`; in dev it is further wrapped in `$.add_locations` with the component's FILENAME member and build_locations output.

uses: [Template](r4-transform-template.md#u-f09b36ebd45e); calls: [build_locations](r5-transform-client.md#u-e3fa95e759b1)

**Uncertainties.**

- Valid namespace strings beyond 'svg'/'mathml' are determined by callers via the `$.from_${namespace}` naming convention.

<a id="u-180b0678e181"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/AssignmentExpression.js:AssignmentExpression`

`export function AssignmentExpression(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/AssignmentExpression.js:L21-L27][f5]

Transforms assignment expressions in client output by delegating to the shared assignment visitor and wrapping the result in mutation validation.

It calls visit_assignment_expression with build_assignment as the per-node builder; when that returns null the original node is visited via context.next(), so plain assignments to non-reactive targets pass through untouched. The resulting expression is passed to validate_mutation, which may augment or replace it (dev-mode checks are inside that helper).

calls: [visit_assignment_expression](r1-shared-assignment-transform.md#u-b43a982ab161), [validate_mutation](r5-transform-client.md#u-a58215b09609)

**Uncertainties.**

- The exact behavior validate_mutation applies to the expression is in a shared helper not supplied here.

<a id="u-446b598656ff"></a>
### `build_assignment`

`function build_assignment(operator, left, right, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/AssignmentExpression.js:L54-L224][f5]

Builds the transformed expression for one assignment, returning null to signal the caller should fall back to normal visiting.

In runes mode with a MemberExpression target, two special cases apply: assignment to a class state field's declaration site rewrites to `this.<field> = value`, wrapping the value in `$.tag` in dev mode (with in_constructor set unless the right side is a $derived rune), and only when a rune is detected on the right; assignment to a PrivateIdentifier becomes `$.set(left, value, needsProxy)` where needsProxy is true for `$state` fields, non-coercive operators, and when should_proxy accepts the value. Otherwise the root object of the target must be an Identifier backed by a scope binding, else null. If a transform.assign exists and the whole target is that identifier, transform.assign is invoked; its 'proxify' flag argument is false for element bindings under a BindDirective (path ends BindDirective/RegularElement), and false for prop, bindable_prop, raw_state, derived, and store_sub bindings, or when not in runes mode, should_proxy rejects the value, or the operator coerces. If transform.mutate exists, transform.mutate wraps a visited assignment. In dev, for non-coercive operators outside an ExpressionStatement (should_transform), the code rewrites member mutations like `(a.b ??= []).push(x)` into `$.assign*` runtime calls so proxy warnings fire; this transform is suppressed for event-handler arrow functions attached to elements that are found as attribute expressions, and for any assignment directly or indirectly under BindDirective or Component/SvelteComponent (including the getter/setter sequence form). When suppressed or when left is not a MemberExpression, it returns null. The `$.assign*` callee is selected from the callees table by operator, receiving the object, the property (literal name for non-computed access), the right side, and a dev locator literal.

uses: [get_rune](r4-compiler-scope.md#u-5204b6ce4f7a); calls: [should_proxy](r3-client-transform-utils.md#u-d089d4da67c8), [build_assignment_value](r4-compiler-ast-utils.md#u-634ffef5ceee), [ast-js-attribute-helpers](r4-compiler-ast-utils.md#u-e05972fa52ab)

**Uncertainties.**

- The behavior of transform.assign/transform.mutate implementations is defined elsewhere (per-binding transforms) and not visible here.
- should_proxy's acceptance criteria are in another file.

<a id="u-3f1e690f4129"></a>
### `is_non_coercive_operator`

`function is_non_coercive_operator(operator)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/AssignmentExpression.js:L35-L37][f5]

Returns true only for the operators '=', '||=', '&&=', '??=' — the ones that can assign a value without coercing it.

Callers use this to decide whether a value may need proxying or a dev-time warning, since coercing operators implicitly convert the value.

**Notes.**

- contract: Non-matching operators (+=, -=, etc.) return false because assignment coerces the value.

<a id="u-494b5cffc303"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/DebugTag.js:DebugTag`

`export function DebugTag(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/DebugTag.js:L10-L28][f6]

Compiles {@debug ...} into a dev-style logging effect pushed to state.init.

Each listed identifier is visited and wrapped in `$.snapshot`; in runes mode the snapshot call is used directly as the property value, otherwise it is wrapped in `$.untrack` of a thunk (avoiding reactive dependencies in legacy mode). The object is logged via console.log, and the whole thing runs inside `$.template_effect` of a block that also emits a `debugger` statement, so execution pauses when the tag is reached.

<a id="u-d99c085dd1f2"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/EachBlock.js:EachBlock`

`export function EachBlock(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/EachBlock.js:L22-L358][f7]

Transforms an each block into a `$.each` runtime call, computing flags, transforms, and invalidation.

The collection expression is built in the parent scope; a template comment is pushed unless the block is controlled. Flags: EACH_INDEX_REACTIVE when keyed with an index; EACH_ITEM_REACTIVE when any dependency binding comes from a shallower function scope and (not runes mode, or the key is not the item, or a store subscription is used); EACH_ITEM_IMMUTABLE in runes mode without stores; EACH_IS_ANIMATED when a keyed block's sole element child carries animate:; EACH_IS_CONTROLLED for controlled blocks. If the collection is a store subscription identifier, its name becomes store_to_invalidate for later `$.invalidate_store`. When inner declarations shadow outer names, a unique `$$array` collection_id is created so bindings can re-read the array. The item context gets a transform: for Identifier contexts, reassignment reads `array[index]` instead of the item variable when the binding was reassigned, reactive items unwrap via get_value, assign/mutate produce sequences appending invalidation statements (legacy-mode `$.invalidate_inner_signals` over transitive deps plus parent each-block deps, and store invalidation when present); for destructured contexts, inserts become `$.derived` declarations and paths become let declarations (`$.derived_safe_equal` when a default value must evaluate once), each with read/assign/mutate transforms, a dev-time eager read to surface TDZ errors, and removal from key_state so the key function uses raw values. A key function arrow is built for keyed blocks using whichever of pattern/index the key actually referenced. The render callback receives anchor, item, index (when used or collection_id exists), and collection_id; the fallback block becomes an extra arrow argument. In dev with keyed blocks, `$.validate_each_keys` is emitted first. Output goes to init, wrapped in `$.async` when the expression has an await. Includes collect_parent_each_blocks, which filters the context path for enclosing EachBlock nodes to gather their transitive dependencies for legacy invalidation.

calls: [get_value](r1-client-transform.md#u-928394943600), [build_expression](r5-transform-client.md#u-cd5eb51d389f), [add_svelte_meta](r5-transform-client.md#u-75700db42066), [extract_paths](r4-compiler-ast-utils.md#u-34f2fcb20c62), [Template](r4-transform-template.md#u-f09b36ebd45e)

**Uncertainties.**

- Exact semantics of build_expression and get_value live in shared helpers not supplied.
- The meaning of node.metadata.transitive_deps entries is established during analysis, not here.
- Side effect of reassigning id.name on destructured insert identifiers mutates the AST pattern nodes; downstream impact is not visible here.

<a id="u-cf6eda1c83ef"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/MemberExpression.js:MemberExpression`

`export function MemberExpression(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/MemberExpression.js:L9-L23][f8]

Rewrites private-state-field reads, especially `this.#foo` inside constructors.

For a PrivateIdentifier property, the field is looked up as '#name' in state.state_fields; if found, the access compiles to `node.v` when inside a constructor and the field is $state or $state.raw (direct value access), otherwise to `$.get(node)` (reactive read). Unknown private names and all other member expressions fall through to context.next().

<a id="u-a9aa3f77ec68"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/RenderTag.js:RenderTag`

`export function RenderTag(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/RenderTag.js:L12-L89][f9]

Serializes {@render} tags.

After a template comment, the callee is unwrapped from optional chaining and each argument is built with build_expression; arguments with awaits or calls are memoized via Memoizer and read back with `$.get`, and every argument becomes a thunk. memoizer.apply() emits the memo assignments and memoizer.deriveds produces the leading derived declarations (runes mode). For dynamic snippets the callee expression is guarded with `?? $.noop` when the source was a ChainExpression, and a `$.snippet(node, thunk(callee), ...args)` call wrapped in add_svelte_meta is emitted; static snippets call (or maybe-call, for optional chains) the snippet function directly with node and args. If the memoizer produced async values, the statements are deferred inside `$.async(node, values, (node, ...ids) => ...)` pushed to init; otherwise the single statement or a block of statements is pushed.

calls: [unwrap_optional](r4-compiler-ast-utils.md#u-aa95700b7c80), [build_expression](r5-transform-client.md#u-cd5eb51d389f); uses: [add_svelte_meta](r5-transform-client.md#u-75700db42066)

<a id="u-78cb80fb5d8c"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/SvelteBoundary.js:SvelteBoundary`

`export function SvelteBoundary(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/SvelteBoundary.js:L11-L116][f10]

Transforms a `<svelte:boundary>` into a `$.boundary(node, props, ($$anchor) => block)` statement in init, wrapped in a block with any hoisted snippet declarations.

Attributes become props: dynamic values produce a getter returning the visited expression, static ones an init property; boolean-valued attributes are skipped as impossible. Const tags are handled specially: in non-async mode they are visited into a const_tags list that is prepended both to the boundary block and to every hoisted snippet body (duplicating the tags so hoisted snippets can reference them); in async mode ConstTag children stay inside the fragment instead. Snippet blocks are hoisted out as declarations unless experimental async mode with const tags is active and the snippet is not `failed`/`pending`, in which case they stay in the fragment; `failed`/`pending` snippets are additionally added to props as `init` properties. In dev the snippet function is extracted one node deeper than in production.

**Notes.**

- condition: All snippet/const placement branches depend on context.state.options.experimental.async; the non-async path duplicates const tag declarations into snippet bodies.
- side_effect: Pushes the boundary statement into context.state.init and a template comment.

calls: [Template](r4-transform-template.md#u-f09b36ebd45e)

**Uncertainties.**

- The dev-mode snippet_fn shape (arguments[1] vs init) relies on the snippet declaration shape produced elsewhere; the @ts-expect-error confirms it is unchecked here.

<a id="u-679da0880969"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/SvelteWindow.js:SvelteWindow`

`export function SvelteWindow(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/SvelteWindow.js:L9-L11][f11]

Compiles <svelte:window> by delegating to visit_special_element with the target '$.window'.

calls: [visit_special_element](r5-transform-client.md#u-5f6160c62286)

<a id="u-7d1fd01c56d0"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/UseDirective.js:UseDirective`

`export function UseDirective(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/UseDirective.js:L11-L37][f12]

Serializes use: action directives into a `$.action(node, actionThunk, paramsThunk?)` statement pushed to init.

The action is an arrow over `$$node` (plus `$$action_arg` when the directive has an expression) that maybe-calls the visited directive name — so optional chaining in `use:maybe?.action` is preserved. The parameter expression is visited into a trailing thunk. The action is emitted in init order so it runs after attribute updates alongside bindings and events; traversal then continues via context.next().

calls: [parse_directive_name](r5-transform-client.md#u-47fb5120ded1)

<a id="u-888d94f48ee5"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/function.js:visit_function`

`export const visit_function = (node, context) =>` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/function.js:L9-L30][f13]

Transforms arrow and function expressions.

The child state clears in_constructor and in_derived; for FunctionExpressions whose parent is a constructor MethodDefinition, in_constructor is set true. When node.metadata.hoisted is true, params are replaced via build_hoisted_params and the body is visited with the new state, returning a modified FunctionExpression; otherwise context.next(state) continues normal visiting.

calls: [build_hoisted_params](r3-client-transform-utils.md#u-a89fb605f1f4)

**Uncertainties.**

- Whether in_derived can be true here is not observable; it is only explicitly set to false.

<a id="u-5f6160c62286"></a>
### `visit_special_element`

`export function visit_special_element(node, id, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/special_element.js:L12-L22][f14]

Handles svelte:body, svelte:document, and svelte:window by rebinding the target node to a fixed runtime id.

OnDirectives are visited with the new state and their resulting expression statements are pushed into context.state.init; all other attributes are visited with the same state without redirecting output.

**Notes.**

- side_effect: Event-handler statements accumulate in context.state.init.

<a id="u-75700db42066"></a>
### `add_svelte_meta`

`export function add_svelte_meta(expression, node, type, additional)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/utils.js:L443-L464][f1]

Wraps a mount expression with dev stack tracking.

Outside dev it returns a plain statement of the expression. In dev, if node.start is undefined or locator yields no location, it also returns the plain statement; otherwise it emits a `$.add_svelte_meta` call taking a zero-argument arrow of the expression, the type literal, the global component_name identifier, line/column literals, and — when additional properties are given — an object of their literal entries.

<a id="u-62396233e782"></a>
### `build_bind_this`

`export function build_bind_this(expression, value, { state, visit })` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/utils.js:L211-L233][f1]

Serializes `bind:this` for components and elements.

A SequenceExpression (bind:x={() => ..., ...}) short-circuits to `$.bind_this(value, set, get)` after visiting. Otherwise the expression's Identifiers are walked; each previously unseen reference whose binding's scope belongs to an EachBlock owner is collected as an id/value pair, and any existing transform for that name is overridden with an identity read so each-context values pass through untransformed. Get and set expressions (an assignment to the original expression) are visited with the adjusted transform. All MemberExpression object nodes along the get chain are marked optional so teardown-time access to missing properties does not throw. The result is `$.bind_this(value, setArrow($$value, ...ids), getArrow(...ids))` plus, when each-context values were collected, a thunked array of their current values as a fourth argument.

**Notes.**

- contract: Member-expression values may be stale when composed of multiple changing variables; the source comments state this matches Svelte 4 behavior.

uses: [component-js-build-component](r5-transform-client.md#u-af8f6b0917f6); group: [build_bind_this](r5-transform-client.md#u-62396233e782)

<a id="u-cd5eb51d389f"></a>
### `build_expression`

`export function build_expression(context, expression, metadata, state = context.state)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/utils.js:L393-L433][f1]

Visits an expression and, in legacy mode only, replicates coarse-grained reactivity by pre-reading dependencies.

It returns the visited value directly when the analysis is runes or maybe_runes, or when the metadata lacks calls, member expressions, and assignments. Otherwise it builds a sequence expression: for each reference that is not a normal non-import binding, build_getter produces a read, wrapped in `$.deep_read_state` for bindable_prop/template bindings, imports, `$$props`, or `$$restProps`; the visited value itself is wrapped in `$.untrack` via a thunk and appended last.

calls: [build_getter](r3-client-transform-utils.md#u-66a19e20e1f1)

<a id="u-b84b76b77b0e"></a>
### `build_render_statement`

`export function build_render_statement(state)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/utils.js:L164-L182][f1]

Builds a `$.template_effect` statement from the state's accumulated update statements and memoizer.

memoizer.apply() names the parameter ids; the effect body is the single update expression when state.update holds exactly one ExpressionStatement, otherwise a block of all update statements; sync and async memoized value arrays follow as arguments (undefined when empty).

uses: [utils-js-memoizer](r5-transform-client.md#u-6874463c92d7)

<a id="u-d8d503fc4b7b"></a>
### `build_template_chunk`

`export function build_template_chunk( values, context, state = context.state, memoize…` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/utils.js:L71-L159][f1]

Builds a template-literal value from an array of Text and ExpressionTag chunks, tracking has_state.

Text and non-null literal chunks append to the current quasi's cooked value; the identifier `undefined` is treated as a value only when a binding named 'undefined' exists in scope. Each real expression is memoized via the memoize callback (defaulting to state.memoizer for calls/awaits) and statically evaluated. With a single chunk the expression is returned directly, coercing known-static values to a literal — avoiding template machinery in favor of set_text. For multiple chunks, `?? null` / `?? null-literal` logicals with null right sides become `?? ''`; known-static values fold into the quasi text; other undefined-able values get `?? ''` appended and start a new quasi (tagged tail when it is the last chunk). Quasis' raw values are produced by sanitize_template_string. The result is a template literal when expressions exist, else a string literal of the cooked text.

**Notes.**

- condition: has_state is true only when has_await or (metadata.has_state and the expression is not statically known), so constant interpolation does not force updates.

calls: [sanitize_template_string](r2-compiler-foundations.md#u-01781e43d6ff)

<a id="u-47fb5120ded1"></a>
### `parse_directive_name`

`export function parse_directive_name(name)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/utils.js:L189-L203][f1]

Converts legacy directive names like `use:a.b-c` into member expressions.

The name is split on '.'; the first part becomes an identifier and each subsequent part a member access, using a computed string-literal property when the part fails regex_is_valid_identifier (e.g. `b-c`) and a plain identifier otherwise.

**Uncertainties.**

- Names without '.' yield a bare Identifier; behavior for empty segments is not guarded here.

<a id="u-91b59b999e05"></a>
### `validate_binding`

`export function validate_binding(state, binding, expression)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/utils.js:L292-L325][f1]

Emits a dev-mode `$.validate_binding` init statement for a bind directive on a member expression.

It returns without emitting anything when the binding expression is a SequenceExpression (handled by assignment validation) or when its root object resolves to a store_sub binding (`$store.foo` needs no validation). Otherwise the call receives the source slice of the binding, a thunk of the object expression (prefixed with `$.mark_store_binding` in a sequence when state.store_to_invalidate is set), a thunk of the property (the computed property expression or a literal of the identifier name), and line/column literals from locator (falsy when no location is available).

uses: [component-js-build-component](r5-transform-client.md#u-af8f6b0917f6)

<a id="u-a58215b09609"></a>
### `validate_mutation`

`export function validate_mutation(node, context, expression)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/utils.js:L333-L385][f1]

Wraps prop mutations with `$$ownership_validator.mutation` in dev mode.

It returns the expression unchanged when not dev, when the mutation target is not a MemberExpression, when the ownership_invalid_mutation warning is ignored, when the root object cannot be resolved, or when the root binding is not a prop or bindable_prop. Otherwise it sets needs_mutation_validation and builds a property path: literal properties become literals, computed identifier properties use the binding's read transformer (or the raw identifier when absent), and any other property type aborts wrapping (returning the plain expression). The path is prefixed with the root name literal and suffixed with line/column from locator; the wrapped call receives binding.prop_alias, the path array, and the original expression.

**Notes.**

- failure: A non-Literal, non-Identifier property (e.g. a template literal key) causes the validator to be skipped and the plain expression returned.

uses: [is_ignored](r5-compiler-state-utils.md#u-468324b42cee)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/utils.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/component.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/transform-template/fix-attribute-casing.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/transform-template/index.js
[f5]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/AssignmentExpression.js
[f6]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/DebugTag.js
[f7]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/EachBlock.js
[f8]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/MemberExpression.js
[f9]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/RenderTag.js
[f10]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/SvelteBoundary.js
[f11]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/SvelteWindow.js
[f12]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/UseDirective.js
[f13]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/function.js
[f14]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/special_element.js
