# Server Transform

**Capability.** Lowers the analyzed AST into SSR payload code: per-node visitors (each, fragment, title, svelte:fragment, rune-statement stripping) and the shared template-building utilities that merge strings, expressions, and attribute values into $$payload statements.

Use this subtree for server-render output shape: build_template/process_children buffer text runs into template literals, while the hydration marker constants (BLOCK_OPEN, empty_comment) in the module header anchor blocks. build_getter supplies identifier reads.

**Depends on.**

- [Client Transform](r2-client-transform.md) · graph-confirmed · 2 edge(s) · the server transform reuses shared clean_nodes and infer_namespace helpers from the client transform utilities.
- [Compiler Foundations](r2-compiler-foundations.md) · graph-confirmed · 1 edge(s)

**Depended on by.**

- [Sandbox Playground](r2-playgrounds.md) · model-inferred · 0 edge(s)
- [Server Transform Phase](r3-server-transform.md) · graph-only · 16 edge(s)

Parent: [Svelte Compiler](r2-compiler.md)

## Units (11)

<a id="u-4806d5caedfd"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/EachBlock.js:EachBlock`

`export function EachBlock(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/EachBlock.js:L12-L66][f1]

Compiles an {#each} block into a server-side for-loop over an array-like snapshot.

The collection expression is visited and wrapped in `$.ensure_array_like` into a root-unique `each_array` constant pushed to init. The loop index is the block's metadata index when group bindings are present or no named index exists, otherwise the user's named index identifier; a secondary `let` aliases the metadata index to the user's name when both differ. Each iteration declares the context variable as `array[index]` and then inlines the visited body statements. If a fallback ({:else}) exists, output is guarded by `if (array.length !== 0)`: the loop branch opens with block_open and the fallback branch is prefixed with a BLOCK_OPEN_ELSE marker for hydration; without fallback, block_open/for/block_close are pushed directly. All output goes through state.template with block_close appended in both cases.

<a id="u-04a9cafb9d3b"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/ExpressionStatement.js:ExpressionStatement`

`export function ExpressionStatement(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/ExpressionStatement.js:L10-L23][f2]

Drops expression statements whose expression is an effect or trace rune: `$effect`, `$effect.pre`, `$effect.root`, and `$inspect.trace` become b.empty in server output.

All other statements continue through context.next().

<a id="u-04c02a2801ab"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/Fragment.js:Fragment`

`export function Fragment(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/Fragment.js:L11-L46][f3]

Transforms a template fragment into a block of init statements plus rendered template strings.

It infers the namespace from the parent node and state, then clean_nodes trims and classifies children (hoisted nodes, trimmed renderables, standalone-ness, text-first detection) honoring preserve_whitespace and preserveComments. A fresh ComponentServerTransformState isolates init/template output and sets skip_hydration_boundaries when the fragment is standalone. Hoisted nodes are visited first; a text-first fragment emits an empty_comment to avoid gluing to the previous fragment; then process_children renders the trimmed nodes. Returns a block combining init statements and the built template.

calls: [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/utils.js:build_template](r2-server-transform.md#u-303aa62127d6), [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/utils.js:process_children (2)](r2-server-transform.md#u-21d2acc05779), [clean_nodes](r2-client-transform.md#u-2ed26069223c), [infer_namespace](r2-client-transform.md#u-b0bc5038f26b)

<a id="u-356cef502838"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/SvelteFragment.js:SvelteFragment`

`export function SvelteFragment(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/SvelteFragment.js:L9-L11][f4]

Handles a <svelte:fragment> node by visiting its fragment and pushing the resulting BlockStatement onto state.template; returns undefined.

**Notes.**

- side_effect: Mutates context.state.template in place rather than returning a node.

<a id="u-781a760465d0"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/TitleElement.js:TitleElement`

`export function TitleElement(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/TitleElement.js:L10-L17][f5]

Compiles <title> into an assignment to `$$payload.title`.

Since children are guaranteed text/expression only, it builds a `<title>` literal template via process_children, appends the closing tag, and pushes the built template statements into state.init with `$$payload.title` as the assignment target.

<a id="u-fb9ba46d1961"></a>
### `utils-js-module`

`module_region` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/utils.js:L1-L29][f6]

Module-level constants of utils.js: block_open and block_close are literal hydration markers (BLOCK_OPEN/BLOCK_CLOSE) that open/close if/each blocks so mismatched nodes can be removed and serve as anchors; empty_comment is the EMPTY_COMMENT literal used to separate text nodes and anchor blocks.

<a id="u-303aa62127d6"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/utils.js:build_template`

`export function build_template(template, out = b.id('$$payload.out'), operator = 'push')` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/utils.js:L141-L175][f6]

Merges an interleaved list of string literals and expressions into payload statements.

Literal strings accumulate into the current string slot; TemplateLiterals contribute their cooked quasis and expressions; other expressions start a new slot. A statement node flushes any pending strings/expressions — as an out.push(...) call when the operator is 'push', otherwise as an assignment to the out identifier using the given operator — then is appended verbatim. Returns the accumulated statement list; output target defaults to $$payload.out with operator 'push'.

<a id="u-1794509e2816"></a>
### `is_statement`

`function is_statement(node)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/utils.js:L92-L94][f6]

Type guard returning true when the node's type name ends with 'Statement' or 'Declaration', used by build_template to distinguish statements from expressions.

<a id="u-21d2acc05779"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/utils.js:process_children (2)`

`export function process_children(nodes, { visit, state })` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/utils.js:L66-L86][f6]

Walks template nodes, buffering runs of consecutive Text, Comment, and ExpressionTag nodes into a sequence and flushing each run into one template literal; non-text nodes are visited individually with a copied state.

Flush converts buffered nodes into a b.template: Text contributes escape_html'd data and Comment contributes a <!--...--> wrapper to the current cooked quasi; ExpressionTags whose static evaluation is known contribute escape_html'd stringified values (null becomes ''), while unknown expressions contribute b.call('$.escape', visit(expression)) and start a new quasi (tail-flagged when last). All quasis then get sanitized raw values and the template is pushed to state.template. Trailing buffered nodes are flushed after the loop.

calls: [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/utils.js:process_children (2)](r2-server-transform.md#u-21d2acc05779)

<a id="u-8ce176223a22"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/utils.js:build_attribute_value`

`export function build_attribute_value( value, context, trim_whitespace = false, is_co…` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/utils.js:L185-L233][f6]

Converts an attribute value into a single expression.

The shorthand value true yields b.true. A non-array or single-element value: a Text chunk becomes a literal — whitespace-collapsed (regex_whitespaces_strict to single space, trimmed) when trim_whitespace is set — and escaped via escape_html(data, true) unless is_component, in which case the raw data is used; any other chunk's expression is visited and returned directly. Multiple chunks build a template literal: Text contributes raw data (whitespace-collapsed when trim_whitespace, no escaping), and each expression chunk contributes b.call('$.stringify', visited-expression) with tail-flagged quasis separating expressions.

**Uncertainties.**

- Escaping differs between component and element contexts; the exact runtime effect of $.stringify and escape_html is outside this source

<a id="u-25646e8536b2"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/utils.js:build_getter`

`export function build_getter(node, state)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/utils.js:L240-L259][f6]

Builds the read expression for an identifier reference.

It returns the node unchanged when no binding exists in scope or when the node is the binding's own declaration. For store_sub bindings (names starting with $) it returns $.store_get(($$store_subs ??= {}), name, recursive-getter-for-the-underlying-store), recursing on the name without the '$' prefix. All other bindings return the node as-is.

**Uncertainties.**

- Which binding kinds actually need transformation beyond store_sub is not visible here; only those two cases are handled

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/EachBlock.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/ExpressionStatement.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/Fragment.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/SvelteFragment.js
[f5]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/TitleElement.js
[f6]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/utils.js
