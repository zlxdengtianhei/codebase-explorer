# Each Block Runtime

**Capability.** Client-side {#each} implementation: deriving the collection, keyed reconciliation (create/update/move/link), and effect pausing coordinated with the batch system.

Read EachBlock-related code here when debugging list updates: reconcile drives create_item/update_item/move, and pause_effects/relax teardown through the linked item/effect lists. It consumes Batch and get directly from the reactivity core.

**Depends on.**

- [Component Context](r2-component-context.md) · model-inferred · 0 edge(s)
- [Reactivity Core & Batching](r2-reactivity-core.md) · graph-confirmed · 3 edge(s) · the each block creates batches and reads reactive state through the reactivity core to coordinate keyed teardown.
- [Effect System](r4-runtime-effects.md) · graph-only · 11 edge(s)
- [Client Hydration State](r3-client-hydration.md) · graph-only · 10 edge(s)

Parent: [Client Runtime](r2-client-runtime.md)

## Units (7)

<a id="u-28e626fece6b"></a>
### `each-js-each`

`function commit()` · [packages/svelte/src/internal/client/dom/blocks/each.js:L162-L188][f1]

Implements the {#each} block: derives the collection via derived_safe_equal (coercing non-arrays and null/undefined to arrays) and runs a block effect that reconciles on change.

For controlled blocks the anchor is the first hydrated child or a freshly appended text node; hydrating advances to the next node. commit() runs reconcile and manages the fallback: empty array resumes or branches fallback_fn, non-empty pauses it. In the effect body it records each_effect once, reads the array, and skips work when empty and previously empty. During hydration a mismatch occurs when the else-marker presence disagrees with length zero, or the HYDRATION_END comment appears before all items are consumed; either way server nodes are removed or the anchor is reset, hydrating is suspended, and items are created directly along the hydrated DOM, with excess nodes removed and a hydration-time fallback branched for an empty array. Otherwise, when should_defer_append() holds, it pre-creates or updates items offscreen (updating only when item/index reactive flags are set), marks removed items' effects as skipped in the current batch, and schedules commit via batch.add_callback; otherwise it commits synchronously. A trailing get(each_array) re-reads the collection to settle the reactive graph after reconciliation, and after block creation hydrating sets anchor to hydrate_node.

group: [each-js-each](r2-dom-blocks.md#u-28e626fece6b); calls: [reconcile](r2-dom-blocks.md#u-4538273d00cc), [create_item](r2-dom-blocks.md#u-12c0d32d8f83)

**Uncertainties.**

- The exact conditions under which should_defer_append() returns true are defined in operations.js, not here

<a id="u-12c0d32d8f83"></a>
### `create_item`

`function create_item( anchor, state, prev, next, value, key, index, render_fn, flags,…` · [packages/svelte/src/internal/client/dom/blocks/each.js:L622-L695][f1]

Creates one each item and its rendered effect.

Value and index become sources only when the respective reactive flags are set; value is a mutable_source unless EACH_ITEM_IMMUTABLE. In DEV with reactive values it attaches a trace closure reading the collection at the current index for dev tracing. When anchor is null it builds a fragment with a text anchor. It branches render_fn with the hydration flag, wires item and effect prev/next links (updating state.first only when not deferred), and restores the previous current_each_item in finally; current_each_item is set to the new item during rendering so animate: directives can attach.

calls: [source](r5-client-reactivity.md#u-97497b70f31b), [mutable_source](r5-client-reactivity.md#u-32c84d6fdda4)

<a id="u-bc4a3f237b08"></a>
### `update_item`

`function update_item(item, value, index, type)` · [packages/svelte/src/internal/client/dom/blocks/each.js:L595-L605][f1]

Pushes a new value into an existing item's reactive value source when EACH_ITEM_REACTIVE is set, and updates the index: setting the reactive index source when EACH_INDEX_REACTIVE is set, otherwise writing the plain number field.

<a id="u-4538273d00cc"></a>
### `reconcile`

`function reconcile( each_effect, array, state, offscreen_items, anchor, render_fn, fl…` · [packages/svelte/src/internal/client/dom/blocks/each.js:L352-L586][f1]

Adds, removes, reorders, and updates each items to match the new array.

With EACH_IS_ANIMATED it pre-measures items that animate into to_animate. Iterating keys: a missing key resumes an offscreen item (relinking and moving it) or creates a new item at the current node position; an existing key is updated when reactive flags demand, resumed when inert (removing it from to_animate and unfixing animation), and moved when out of order — when the item was already seen, it either moves the earlier matched run forward or the later item back, whichever requires fewer moves, resetting matched/stashed after a fresh key is inserted. Skipped keys accumulate in seen/stashed as it scans forward; keys not found (current reaches null) are skipped. Remaining current items plus seen are collected for destruction (excluding inert ones), applying animation measure/fix and pause_effects with a controlled anchor only when EACH_IS_CONTROLLED and the array became empty. Animated items are applied in a microtask. Finally each_effect.first/last are updated, and any leftover offscreen items are destroyed and the map cleared.

calls: [pause_effects](r2-dom-blocks.md#u-1c55b7a0d0a9), [create_item](r2-dom-blocks.md#u-12c0d32d8f83), [update_item](r2-dom-blocks.md#u-bc4a3f237b08), [move](r2-dom-blocks.md#u-3dcc1178b952), [link](r2-dom-blocks.md#u-ea8a4b98c012)

**Uncertainties.**

- The list-reordering minimization heuristic is intricate; edge cases involving INERT items in seen are inferred from the flag checks alone

<a id="u-3dcc1178b952"></a>
### `move`

`function move(item, next, anchor)` · [packages/svelte/src/internal/client/dom/blocks/each.js:L702-L713][f1]

Relocates an item's DOM nodes before the destination: it walks from the item's effect nodes_start up to (but excluding) the next item's nodes_start or the anchor, inserting each node before the destination's nodes_start (or the anchor).

<a id="u-ea8a4b98c012"></a>
### `link`

`function link(state, prev, next)` · [packages/svelte/src/internal/client/dom/blocks/each.js:L720-L732][f1]

Relinks the doubly linked item and effect lists: a null prev makes next the state's first item, otherwise prev's item and effect next pointers are updated; a non-null next gets its prev pointers set correspondingly.

<a id="u-1c55b7a0d0a9"></a>
### `pause_effects`

`function pause_effects(state, items, controlled_anchor)` · [packages/svelte/src/internal/client/dom/blocks/each.js:L73-L107][f1]

Pauses a batch of each items' effects and coordinates their teardown.

It collects children transitions via pause_children for every item; if there are no transitions and a controlled anchor exists, it takes the fast path: clearing the parent element's content, re-appending the anchor, clearing the items map, and linking around the removed run. All collected out transitions then run, and in their completion callback each item is unlinked from the items map and list and destroyed — except in the controlled case where the effects are already gone.

calls: [link](r2-dom-blocks.md#u-ea8a4b98c012)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/blocks/each.js
