# Reactivity Benchmarks

**Capability.** Kairo-style reactivity benchmarks (avoidable and repeated-read chains over Svelte's internal signals) and a cross-branch comparison driver that forks a runner child and renders bar charts.

kairo_avoidable and kairo_repeated both use util.js's busy() to add measurable work; benchmarking/compare/index.js orchestrates multi-branch runs.

**Depends on.**

- [Shared Utilities and Public Contracts](r3-shared.md) · model-inferred · 0 edge(s)
- [Benchmarking Harness](r4-benchmarking.md) · graph-only · 9 edge(s)

Parent: [Repository Tooling](r3-tooling.md)

## Units (4)

<a id="u-6988b0d7b4e5"></a>
### `benchmarking-compare-index-module`

`function char(i)` · [benchmarking/compare/index.js:L101-L103][f1]

Compares benchmark results across git branches by checking out each branch, forking a runner child process, and rendering a bar-chart comparison to the console.

It collects branch names from CLI args (skipping '--' prefixed flags and this file's own path); if none were given it uses the current branch, and if only one was given it appends 'main'. It deletes and recreates the .results directory. For each branch it checks out that branch, then forks runner.js and awaits a message carrying the results, which it writes to <outdir>/<branch>.json; child 'error' events reject the awaiting promise. An 'exit' handler re-checkouts the first branch, so the process restores the starting branch even if the loop fails (git failures in execSync throw synchronously and would otherwise terminate the process with that branch checked out). After all branches run it reads the JSON files and, per benchmark and per metric ('time', 'gc_time'), computes min/max and prints a 20-character bar per branch scaled to the max with the time in ms — but only when min is nonzero, silently skipping an all-zero or empty metric. Bar labels use single letters from char().

uses: [runner.js module code (L1–L10)](r5-benchmarks.md#u-0b0dc218fb67); calls: [benchmarking-compare-index-module](r3-benchmarks.md#u-6988b0d7b4e5)

**Uncertainties.**

- execSync('git checkout ...') interpolates branch names into a shell command; behavior with names containing shell metacharacters is not guarded in this source
- child.on('message') is trusted to fire exactly once with parseable results; a child exiting without messaging would leave the promise pending (no fulfil/reject path for 'exit' is registered)
- whether a 'time' or 'gc_time' metric key is ever absent from a result is not visible here; missing keys would produce NaN via +result[i][metric]

<a id="u-67dcce51185e"></a>
### `kairo_avoidable.js`

`function setup()` · [benchmarking/benchmarks/reactivity/kairo/kairo_avoidable.js:L5-L22][f2]

Benchmarks a five-link derived chain in Svelte's internal reactivity system where intermediate computations are considered avoidable.

setup() builds head as a state signal, computed1..computed5 as deriveds (computed2 drops computed1's value, computed3 and the render effect add a busy() cost), all inside an effect_root whose returned destroy tears the graph down. run() flushes head to 1 and asserts computed5 is 6, then flushes head through 0..999 asserting computed5 stays 6, exercising recomputation of the chain 1000 times. kairo_avoidable_unowned warms up with 10 setup/run/destroy cycles, then times 10 iterations of 1000 runs via fastest_test, destroys its own setup, and returns {benchmark, time, gc_time} with values fixed to two decimals. kairo_avoidable_owned differs only in ownership: the warm-up and final setup happen inside one outer effect_root, so after timing it destroys the inner graph and then the outer destroy_owned; destroy is called with a @ts-ignore because its definite assignment is not visible to the type checker. Assertions propagate as thrown errors, aborting the benchmark.

calls: [fastest_test](r4-benchmarking.md#u-0bbe8c671495), [assert](r4-benchmarking.md#u-823bd0dd0cd8); uses: [busy](r3-benchmarks.md#u-0d12a4a1de84)

**Uncertainties.**

- Exact semantics of $.state/$.derived/$.flush/effect_root come from svelte/internal/client and are not in this batch

<a id="u-6bcaae4b4249"></a>
### `kairo_repeated.js`

`function setup()` · [benchmarking/benchmarks/reactivity/kairo/kairo_repeated.js:L6-L27][f3]

Benchmarks repeated reads of one source within a single computation: setup()'s derived sums head size (30) times, and a render effect counts its recomputations.

run() flushes head to 1 asserting the derived equals size, resets the counter, then for i in 0..99 flushes head to i asserting the derived is i*size and finally that the counter is exactly 100 — one recomputation per write despite many reads. Unowned and owned variants use the standard harness: 10 warm-up setup/run/destroy cycles, fastest_test over 10 iterations of 1000 runs, with owned performing its setup inside an outer effect_root and destroying inner then outer. Both return {benchmark, time, gc_time} fixed to two decimals; assertions throw on failure.

calls: [fastest_test](r4-benchmarking.md#u-0bbe8c671495), [assert](r4-benchmarking.md#u-823bd0dd0cd8)

<a id="u-0d12a4a1de84"></a>
### `busy`

`export function busy()` · [benchmarking/benchmarks/reactivity/kairo/util.js:L1-L6][f4]

Simulates a cheap CPU-heavy computation by incrementing a local counter 100 times and returning nothing; it exists to add measurable work inside deriveds and render effects in the avoidable benchmark.

It has no side effects outside its scope and cannot fail.

**Notes.**

- side_effect: None: the loop result is discarded, so the function's only observable effect is consumed CPU time.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/benchmarking/compare/index.js
[f2]: ../../../../../../eval/svelte-be645b4/benchmarking/benchmarks/reactivity/kairo/kairo_avoidable.js
[f3]: ../../../../../../eval/svelte-be645b4/benchmarking/benchmarks/reactivity/kairo/kairo_repeated.js
[f4]: ../../../../../../eval/svelte-be645b4/benchmarking/benchmarks/reactivity/kairo/util.js
