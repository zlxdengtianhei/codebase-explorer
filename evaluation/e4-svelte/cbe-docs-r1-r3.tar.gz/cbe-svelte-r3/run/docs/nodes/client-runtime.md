# Client Runtime

**Capability.** The browser-side execution engine compiled output calls into: the fine-grained signal/effect core with batched scheduling, DOM template blocks and hydration-aware traversal, element bindings and delegated events, boundaries, legacy-mode support, and dev-mode diagnostics (warnings, tracing, HMR).

Use for anything that happens at runtime in the browser. The effect/signal machinery underpins DOM blocks and bindings; dev instrumentation is compiled out in production. Region evidence shows dense two-way traffic with the compiler (region-0004↔region-0005) and with shared/server runtime pieces (region-0004↔region-0003).

**Children.**

- [Svelte Compiler and Runtime](r4-svelte-monorepo.md) `r4-svelte-monorepo` · 0 unit(s)

**Depends on.**

- [Compiler Pipeline](compiler-pipeline.md) · graph-confirmed · 66 edge(s)
- [Public API, Types & Reactive Primitives](public-api-types.md) · graph-confirmed · 57 edge(s)
- [Server & Shared Runtime](server-and-shared-runtime.md) · graph-confirmed · 37 edge(s)

**Depended on by.**

- [Compiler Pipeline](compiler-pipeline.md) · graph-confirmed · 144 edge(s)
- [Public API, Types & Reactive Primitives](public-api-types.md) · graph-confirmed · 112 edge(s)
- [Server & Shared Runtime](server-and-shared-runtime.md) · graph-confirmed · 113 edge(s)
- [Svelte Repository](svelte-repo.md) · containment · → 0 / ← 0 edge(s) (ancestor direct units and descendant subtree; → follows ` svelte-repo ` → ` client-runtime `)

Parent: [Svelte Repository](svelte-repo.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
