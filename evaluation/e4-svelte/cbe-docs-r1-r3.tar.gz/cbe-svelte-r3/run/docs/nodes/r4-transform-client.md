# Client Code Transformation

**Capability.** Phase-3 client lowering: rewrites template constructs into runtime calls ($.bind_*, $.slot, $.transition, $.set_class/style, attribute effects), serializes variable declarations into reactive constructs, and rewrites identifiers and equality for proxy semantics.

Consult by construct: each visitor lowers one AST node kind into client runtime calls. shared/element.js holds the reusable attribute/class/style builders that visitors compose, and the template subtree supplies the static markup container.

**Depends on.**

- [AST Manipulation Utilities](r4-compiler-ast-utils.md) · graph-confirmed · 7 edge(s)
- [Scope and Binding Model](r4-compiler-scope.md) · graph-confirmed · 16 edge(s)
- [Shared Source Utilities](r4-shared-source-utilities.md) · graph-confirmed · 1 edge(s)
- [Client Static Template Emission](r4-transform-template.md) · graph-confirmed · 2 edge(s)
- [Client Codegen Visitors](r5-transform-client.md) · graph-only · 23 edge(s)
- [Client Transform Utilities](r3-client-transform-utils.md) · graph-only · 10 edge(s)

**Depended on by.**

- [Client Transform Visitors](r3-client-transform-visitors.md) · graph-only · 10 edge(s)

Parent: [Compiler Pipeline](r4-compiler.md)

## Units (16)

<a id="u-61fecc929533"></a>
### `BinaryExpression`

`export function BinaryExpression(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/BinaryExpression.js:L10-L34][f1]

In dev replaces equality operators with runtime helpers to handle proxy semantics: `===`/`!==` become `$.strict_equals(left, right, false?)` and `==`/`!=` become `$.equals(left, right, false?)`, with the trailing boolean false argument emitted only for the negated variants.

In production, or for any other operator, it delegates to context.next() for default traversal.

**Notes.**

- condition: All four equality replacements occur only when `dev` is true; otherwise traversal is unchanged.

<a id="u-e55ab0a7d69f"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/BindDirective.js:BindDirective`

`export function BindDirective(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/BindDirective.js:L15-L260][f2]

Lowers a bind: directive into the appropriate `$.bind_*` runtime call and schedules it.

The bound expression is visited first; a SequenceExpression is split into explicit get/set expressions, otherwise a getter thunk is built from the expression and a setter arrow assigning `$$value` (via b.assignment visited in context) is built, dropped when it turns out identical to the getter. In dev runes mode, validate_binding runs when the expression is a MemberExpression, the binding is `this` only outside reactive blocks (IfBlock/EachBlock/AwaitBlock/KeyBlock in the path), and the binding_property_non_reactive warning is not ignored. For bindings with a table entry carrying `event`, `$.bind_property` is emitted; otherwise a name-based switch selects dedicated runtime calls for window (online, scrollX/scrollY, inner/outer width/height), document (activeElement), media bindings, resize/element-size observers, value (select elements get $.bind_select_value), files, this (via build_bind_this), content-editable bindings, checked/focused, and group. For group, indexes from parent each blocks are wrapped in `$.get` when the block is keyed with an index, and when the parent element has a non-text `value` attribute, the getter is wrapped to first evaluate that attribute value so the group signal registers as a dependency. Unknown names throw. Scheduling: `this` bindings go to init (one-way, may affect the render effect); if the parent element has a use: directive the call is wrapped in `$.effect` in init so it runs after attribute updates in order with actions; otherwise it is pushed to after_update.

calls: [validate_binding](r5-transform-client.md#u-91b59b999e05), [build_bind_this](r5-transform-client.md#u-62396233e782), [build_attribute_value](r4-transform-client.md#u-2462157783c9), [is_ignored](r5-compiler-state-utils.md#u-468324b42cee); uses: [ast-js-attribute-helpers](r4-compiler-ast-utils.md#u-e05972fa52ab)

**Uncertainties.**

- The contents of binding_properties (which bindings have event/bidirectional metadata) come from ../../../bindings.js and are not shown.
- The exact effect of validate_binding (throw vs warn) is in the shared helper.

<a id="u-66fd01a83c22"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/ConstTag.js:ConstTag`

`export function ConstTag(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/ConstTag.js:L15-L91][f3]

Serializes `{@const x = expr}` tags into derived constants pushed to state.consts.

For a simple Identifier declaration, the initializer is built with in_derived set, wrapped via create_derived (awaiting per has_await), dev-tags the expression with the variable name, pushes a const declaration, and installs a `get_value` read transformer; in dev an eager `$.get(x)` statement is also pushed to surface 'accessed before initialization' errors. For destructuring patterns, identifiers extracted from the pattern are removed from a cloned transform map (they are not signals while computing), the initializer is built in that child state, and a derived block destructures `$.get` of the visited pattern and returns the identifier object; the result is stored in a generated `computed_const` temp, dev-tagged `[@const]` and eagerly read in dev, and each declared identifier gets a transformer reading `$.get(tmp).<name>`. No traversal continuation: output is entirely state mutation.

calls: [create_derived](r3-client-transform-utils.md#u-d8c62e2be238), [build_expression](r5-transform-client.md#u-cd5eb51d389f), [extract_identifiers](r4-compiler-ast-utils.md#u-90eb95affc00)

<a id="u-33e650400bd4"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/Identifier.js:Identifier`

`export function Identifier(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/Identifier.js:L11-L41][f4]

Rewrites identifier references in generated/visited code.

Only when is_reference says the node is a value reference: `$$props` is renamed to `$$sanitized_props`; a rest_prop binding read as a non-computed member (and not the target of an assignment/update, runes mode only) is replaced by the direct `$$props` object as an optimization. All other references go through build_getter, which produces the reactive read expression or leaves the identifier untouched; non-reference identifiers return undefined so default traversal applies.

calls: [build_getter](r3-client-transform-utils.md#u-66a19e20e1f1)

**Uncertainties.**

- Whether returning undefined for non-references is handled by the traversal framework is not shown here.

<a id="u-c4e00e5384f2"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/IfBlock.js:IfBlock`

`export function IfBlock(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/IfBlock.js:L11-L88][f5]

Serializes {#if}/{:else if} blocks.

After a template comment, the consequent (and alternate, if present) are visited and hoisted into generated `consequent_*`/`alternate_*` arrow variables taking `$$anchor`. The condition is built with build_expression; with awaits the rendered test reads `$$condition`. A `$.if(node, ($$render) => { if (test) $$render(consequent) else $$render(alternate, false) })` call is wrapped by add_svelte_meta and pushed with the statements into init — or, when has_await, everything is deferred inside `$.async(node, [thunk], (node, $$condition) => ...)`. For an `{:else if}` chain (node.elseif), a trailing `true` argument marks locality so transitions play when any condition in the chain changes, unlike a nested `{#if}` whose transitions only fire on the inner condition.

uses: [add_svelte_meta](r5-transform-client.md#u-75700db42066); calls: [build_expression](r5-transform-client.md#u-cd5eb51d389f)

<a id="u-5bfaaebc7139"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/SlotElement.js:SlotElement`

`export function SlotElement(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/SlotElement.js:L12-L92][f6]

Serializes <slot> elements into `$.slot(node, $$props, name, props, fallback)`.

After a template comment it collects attributes: spreads become thunks in a spreads list; regular attributes are built via build_attribute_value, where values with calls or awaits are memoized and read via `$.get` — the `name` attribute overrides the default `'default'` literal, `slot` attributes are skipped, and other attributes become getter properties when stateful or plain init properties otherwise; LetDirectives are visited into a lets list. memoizer.apply() emits memo code; let bindings are pushed to init before the slot call since attributes may read them; memoizer.deriveds supplies leading declarations. The props expression is a plain object when no spreads, otherwise `$.spread_props(object, ...spreads)`; the fallback is null when the fragment is empty, else a `($$anchor) => ...` arrow. The resulting statement (or `$.async`-wrapped block when memoized awaits exist) is pushed to init.

calls: [build_attribute_value](r4-transform-client.md#u-2462157783c9)

<a id="u-3c05d4ae0c14"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/SvelteBody.js:SvelteBody`

`export function SvelteBody(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/SvelteBody.js:L9-L11][f7]

Compiles <svelte:body> by delegating to visit_special_element with the target expression '$.document.body'.

calls: [visit_special_element](r5-transform-client.md#u-5f6160c62286)

<a id="u-dc69513c68f2"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/SvelteFragment.js:SvelteFragment`

`export function SvelteFragment(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/SvelteFragment.js:L9-L17][f8]

Compiles <svelte:fragment> content into the parent init sequence.

LetDirective attributes are visited first and their resulting statements pushed to state.init; then the fragment's visited block statements are spread into state.init so the fragment's children render in place.

**Uncertainties.**

- The visited fragment is cast to BlockStatement; a fragment visit returning a different node shape would break that assumption (cast only).

<a id="u-d35c66d967c0"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/SvelteSelf.js:SvelteSelf`

`export function SvelteSelf(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/SvelteSelf.js:L9-L12][f9]

Compiles <svelte:self> via build_component using the component's own analysis name, pushing the resulting declaration into state.init.

calls: [component-js-build-component](r5-transform-client.md#u-af8f6b0917f6)

<a id="u-960109c44c27"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/TransitionDirective.js:TransitionDirective`

`export function TransitionDirective(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/TransitionDirective.js:L12-L29][f10]

Serializes transition:/in:/out: directives into a `$.transition(flags, node, nameThunk, paramsThunk?)` statement pushed to state.after_update (so it runs after bind:this).

Flags combine TRANSITION_GLOBAL when the `global` modifier is present, TRANSITION_IN when node.intro, and TRANSITION_OUT when node.outro. The directive name is resolved via parse_directive_name and visited as the third argument; the parameter expression, if any, is appended as an additional thunk.

calls: [parse_directive_name](r5-transform-client.md#u-47fb5120ded1)

<a id="u-0abd8487f7a1"></a>
### `build_attribute_effect`

`export function build_attribute_effect( attributes, class_directives, style_directive…` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/element.js:L20-L98][f11]

Emits one `$.attribute_effect` call that reactively updates all attributes of an element.

Each Attribute value is built with build_attribute_value, memoizing values that have calls or awaits in a local Memoizer. When an event-attribute value is an arrow or function expression, it is hoisted into an init-scoped variable (name generated as 'event_handler') so the handler is not removed and re-added on every update. Non-Attribute entries (spreads) are visited and memoized when they have calls or awaits, then pushed as spread properties. Class and style directives become properties keyed by `$.CLASS`/`$.STYLE` arrays via build_class_directives_object/build_style_directives_object sharing this memoizer. memoizer.apply() assigns the final `$n` ids, which parameterize the effect arrow; sync_values and async_values follow. Two trailing call arguments are conditional and falsy when inapplicable: the scoped-CSS hash literal (only when element.metadata.scoped and the analysis css hash is non-empty) and `true` when the `hydration_attribute_changed` warning is ignored.

calls: [build_class_directives_object](r3-client-transform-visitors.md#u-93d4778b5497), [build_style_directives_object](r3-client-transform-visitors.md#u-29f008b00f20), [build_attribute_value](r4-transform-client.md#u-2462157783c9); uses: [is_ignored](r5-compiler-state-utils.md#u-468324b42cee)

<a id="u-2462157783c9"></a>
### `build_attribute_value`

`export function build_attribute_value(value, context, memoize = (value) => value)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/element.js:L106-L127][f11]

Normalizes an attribute value (boolean true, single chunk, or chunk array) into an expression plus a has_state flag.

`true` becomes b.true with has_state false. A single-Text or single-chunk value becomes a string literal for Text, otherwise build_expression output passed through the memoize callback; has_state is true when the chunk metadata has state or await. Multi-chunk values delegate to build_template_chunk. The memoize parameter defaults to identity.

calls: [build_expression](r5-transform-client.md#u-cd5eb51d389f), [build_template_chunk](r5-transform-client.md#u-d8d503fc4b7b)

<a id="u-d08767f6fc10"></a>
### `build_set_class`

`export function build_set_class(element, node_id, attribute, class_directives, contex…` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/element.js:L149-L217][f11]

Emits a `$.set_class` call for the class attribute plus class directives, choosing init vs update placement from has_state.

The attribute value is built with build_attribute_value; when attribute.metadata.needs_clsx the value is wrapped in `$.clsx`, and values with calls or awaits are memoized in context.state.memoizer. When class directives exist, build_class_directives_object produces `next`; has_state is ORed with any directive having state or await. If stateful, a generated `classes` let variable is declared in init and used as `prev`, otherwise prev is an empty object literal. Scoped CSS handling has three cases: an empty/null string literal value becomes the css hash literal; a non-empty string literal becomes escape_html(value, true) + ' ' + hash; otherwise css_hash is a separate hash literal argument (and defaults to null when directives exist without scoped css). The is_html flag becomes literal 1 or 0. When prev is a variable, the call is assigned back into it, and the statement goes to update; otherwise to init.

**Notes.**

- side_effect: Declares the `classes` variable in context.state.init and pushes the set_class statement into init or update depending on has_state.

calls: [build_class_directives_object](r3-client-transform-visitors.md#u-93d4778b5497), [build_attribute_value](r4-transform-client.md#u-2462157783c9), [escape_html](r4-shared-source-utilities.md#u-0f499dd45547)

<a id="u-b481933571c2"></a>
### `build_set_style`

`export function build_set_style(node_id, attribute, style_directives, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/element.js:L225-L262][f11]

Emits a `$.set_style(node_id, value, prev, next)` call for the style attribute plus style directives, placed in update when stateful and init otherwise.

Value construction memoizes only values with calls (metadata.has_call), regardless of has_await. When style directives exist, build_style_directives_object produces `next`; has_state is ORed with directive state/await, and when stateful a generated `styles` let variable is declared in init, used as `prev`, and the call is assigned back into it; otherwise prev is an empty object literal.

calls: [build_style_directives_object](r3-client-transform-visitors.md#u-29f008b00f20), [build_attribute_value](r4-transform-client.md#u-2462157783c9)

<a id="u-794bd7468f40"></a>
### `get_attribute_name`

`export function get_attribute_name(element, attribute)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/element.js:L133-L139][f11]

Returns the attribute name, lowercased/case-normalized via normalize_attribute for HTML elements, but preserved verbatim for svg and mathml elements where names are case-sensitive.

calls: [utils-js-predicates](r3-shared-utils.md#u-7eb274f609ad)

<a id="u-a34235f3ca3c"></a>
### `variabledeclaration.js-serializers`

`export function VariableDeclaration(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/VariableDeclaration.js:L17-L131][f12]

Serializes variable declarations into reactive runtime constructs, with two main paths.

In runes mode each declarator is classified by its rune: non-reactive or excluded runes ($effect.tracking, $effect.root, $inspect*, $state.snapshot, $host) are visited normally, with hoisted function initializers moved to context.state.hoisted; `$props.id` is skipped; `$props` becomes `$.rest_props($$props, [...seen])` for an identifier binding, or per-property declarations for an ObjectPattern where each leaf gets a prop source (wrapped in `$.proxy` and, in dev, `$.tag_proxy` when the bindable prop has a proxied initial), a rest property becomes rest_props over the remaining names; `$state`/`$state.raw` wrap the value in `$.proxy` (when should_proxy says so, only for `$state`), then `$.state`, with dev tagging, and destructured patterns split into a tmp plus `$.derived` inserts and per-path declarators that re-apply state wrapping for state bindings; `$derived`/`$derived.by` produce `$.derived` (thunked for `$derived`) or, when the analysis marks the call as an async derived, an awaited `$.async_derived` wrapped in `$.save` with a dev waterfall location unless ignored, again with destructuring splitting into derived inserts and path declarators. In legacy mode, declarations whose bindings are neither state nor bindable props are visited normally (hoisted functions likewise); bindable props become get_prop_source declarations, using leaf names for destructured patterns via a tmp plus inserts/paths; otherwise create_state_declarators wraps identifiers in `$.mutable_source` (with a true flag under immutable analysis) and splits destructured patterns into a tmp, `$.derived` array inserts, and per-path mutable_source declarators for state bindings. If no declarations remain, b.empty is returned; otherwise a cloned node with the new declarations is returned.

**Notes.**

- field: Destructuring inserts register context.state.transform[id] = { read: get_value } for generated $$array temporaries.
- failure: Rune-mode $props with a non-ObjectPattern, non-Identifier id reaches assert.equal and fails the transform; non-property pattern entries are treated as RestElement.
- condition: Legacy mode chooses between props (has_props), state (create_state_declarators), and plain visiting by binding kinds returned from scope.get_bindings.

calls: [get_prop_source](r3-client-transform-utils.md#u-d03f333899de); uses: [is_prop_source](r3-client-transform-utils.md#u-38b8a75ee741), [should_proxy](r3-client-transform-utils.md#u-d089d4da67c8), [is_hoisted_function](r2-client-transform.md#u-b9dd511b4830), [get_rune](r4-compiler-scope.md#u-5204b6ce4f7a), [Scope](r4-compiler-scope.md#u-01a82e58170d), [is_ignored](r5-compiler-state-utils.md#u-468324b42cee), [locate_node](r5-compiler-state-utils.md#u-b35212eb6968), [extract_paths](r4-compiler-ast-utils.md#u-34f2fcb20c62)

**Uncertainties.**

- The TODO-commented `void 0` fallback for missing rune arguments suggests the author was unsure it is needed; behavior is as written (value defaults to void 0).
- In runes mode a declarator whose init lacks a recognized rune is visited via context.visit(declarator); what that produces for an init-less declarator is decided in the generic visitor, not here.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/BinaryExpression.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/BindDirective.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/ConstTag.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/Identifier.js
[f5]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/IfBlock.js
[f6]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/SlotElement.js
[f7]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/SvelteBody.js
[f8]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/SvelteFragment.js
[f9]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/SvelteSelf.js
[f10]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/TransitionDirective.js
[f11]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/element.js
[f12]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/VariableDeclaration.js
