# CSS Analysis

**Capability.** Static CSS checks: walking the stylesheet to warn about unused selectors, and utilities that classify selectors as global/scoped and enumerate possible attribute values for matching.

css-warn.js implements the unused-selector warning walk (skipping keyframes and global-block bodies). The utils here define is_global/is_outer_global semantics and value enumeration used during selector matching. Read together they explain which selectors survive scoping.

**Depends on.**

- [CSS Parsing](r2-css-parse.md) · model-inferred · 0 edge(s)

**Depended on by.**

- [Template Analysis](r2-analyze-phase.md) · model-inferred · 0 edge(s)
- [CSS Transform](r2-css-transform.md) · model-inferred · 0 edge(s)

Parent: [CSS Pipeline](r2-css-pipeline.md)

## Units (11)

<a id="u-6a7a7b443898"></a>
### `warn_unused`

`export function warn_unused(stylesheet)` · [packages/svelte/src/compiler/phases/2-analyze/css/css-warn.js:L10-L12][f1]

Walks the stylesheet with the unused-selector visitors to emit css_unused_selector warnings for selectors never marked used.

State carries only the stylesheet reference needed to slice source text for the warning.

<a id="u-582548f75fe1"></a>
### `packages/svelte/src/compiler/phases/2-analyze/css/css-warn.js:Atrule`

`const visitors = { Atrule(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/css/css-warn.js:L15-L20][f1]

Skips descending into keyframes at-rules: when the node is a keyframes node, context.next() is not called, so their inner selectors are never checked for unusedness; otherwise traversal continues.

<a id="u-37b96b469bbc"></a>
### `PseudoClassSelector`

`PseudoClassSelector(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/css/css-warn.js:L21-L25][f1]

Continues traversal through `:is` and `:where` pseudo-classes (context.next() only for those names), so selectors inside them are still visited for unusedness; other pseudo-class selectors stop descent at this node.

<a id="u-2711ea3bb857"></a>
### `packages/svelte/src/compiler/phases/2-analyze/css/css-warn.js:ComplexSelector`

`ComplexSelector(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/css/css-warn.js:L26-L39][f1]

Warns about unused complex selectors.

When metadata.used is not set, it avoids double-warning selectors inside `:is(...)` by checking that the grandparent is not a PseudoClassSelector — or, if it is, that the great-grandparent complex selector is itself used. On warning, it slices the original source text between node.start and node.end using the stylesheet content offsets and calls w.css_unused_selector with the node and text. context.next() always runs.

**Notes.**

- side_effect: Emits a compiler warning via w.css_unused_selector.

<a id="u-8e2f7056bd7d"></a>
### `packages/svelte/src/compiler/phases/2-analyze/css/css-warn.js:Rule`

`Rule(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/css/css-warn.js:L40-L46][f1]

For rules marked as global blocks, visits only the prelude (checking its selectors for unusedness) instead of the whole rule; all other rules traverse normally via context.next(), so declarations and nested rules of global blocks are not scanned.

<a id="u-cb59d8ba04c6"></a>
### `get_possible_values`

`export function get_possible_values(chunk, is_class)` · [packages/svelte/src/compiler/phases/2-analyze/css/utils.js:L85-L96][f2]

Public wrapper returning the possible string values of a Text or ExpressionTag chunk: text contributes its data verbatim, expressions go through gather_possible_values.

Returns null when the UNKNOWN sentinel was produced, signaling that no finite value set exists.

calls: [gather_possible_values](r2-css-analyze.md#u-b80afad44d7a)

<a id="u-b80afad44d7a"></a>
### `gather_possible_values`

`function gather_possible_values(node, is_class, set, is_nested = false)` · [packages/svelte/src/compiler/phases/2-analyze/css/utils.js:L11-L78][f2]

Enumerates the string values an expression node can produce for attribute matching, recording the sentinel UNKNOWN when the set cannot be determined.

Once UNKNOWN is in the set, traversal stops. Literals stringify; conditionals and logical expressions union both sides, except '&&', which models falsy left-hand values specially: an UNKNOWN left side contributes the falsy values '', false, NaN, and 0 (suppressed for class attributes being processed by class:list semantics unless nested in an array/object), while a known left side contributes falsy values only outside class/nested contexts. For class attributes, array elements are recursed as nested, and object literal properties with static identifier or literal keys contribute their key names; computed keys or other properties yield UNKNOWN. Every other node type yields UNKNOWN.

calls: [gather_possible_values](r2-css-analyze.md#u-b80afad44d7a)

<a id="u-f841f035438b"></a>
### `get_parent_rules`

`export function get_parent_rules(rule)` · [packages/svelte/src/compiler/phases/2-analyze/css/utils.js:L102-L111][f2]

Collects the rule's ancestor chain by following metadata.parent_rule until null; the root rule is last in the returned array.

<a id="u-022eb67172ae"></a>
### `packages/svelte/src/compiler/phases/2-analyze/css/utils.js:is_global`

`export function is_global(relative_selector)` · [packages/svelte/src/compiler/phases/2-analyze/css/utils.js:L118-L132][f2]

Reports whether a relative selector is fully global: its first selector must be a :global pseudo class, either without arguments or with every following selector being an unscoped pseudo class or a pseudo element — so :global(button).x is scoped because .x scopes it.

Acts as a type predicate narrowing selectors to that shape.

calls: [is_unscoped_pseudo_class](r2-css-analyze.md#u-2d29e82903c1)

<a id="u-a5fd8a871e73"></a>
### `is_outer_global`

`export function is_outer_global(relative_selector)` · [packages/svelte/src/compiler/phases/2-analyze/css/utils.js:L163-L177][f2]

Like is_global but ignores whether trailing pseudo classes are scopeable: the first selector must be :global, either argless or followed only by pseudo class/pseudo element selectors.

Hence :global(x):has(y) is true here but false for is_global. Used by apply_selector to keep outer-global selectors unmarked as scoped.

<a id="u-2d29e82903c1"></a>
### `is_unscoped_pseudo_class`

`export function is_unscoped_pseudo_class(selector)` · [packages/svelte/src/compiler/phases/2-analyze/css/utils.js:L138-L155][f2]

Determines whether a simple pseudo-class selector cannot be or is not scoped.

True for pseudo classes other than has/is/where/not; :not is also unscoped when it has no args or every inner complex selector has a single child. Additionally, has/is/where/not selectors with args remain unscoped-global only when every complex selector in their args is recursively is_global; a bare pseudo class with no args is unscoped. Non-pseudo-class selectors are false.

calls: [packages/svelte/src/compiler/phases/2-analyze/css/utils.js:is_global](r2-css-analyze.md#u-022eb67172ae)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/css/css-warn.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/css/utils.js
