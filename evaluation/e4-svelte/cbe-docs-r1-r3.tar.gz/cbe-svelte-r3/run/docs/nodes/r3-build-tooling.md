# Build and Audit Tooling

**Capability.** Builds the compiler as a UMD bundle via Rollup, audits every package.json export for tree-shakeability by bundling a feature-rich client and checking for leaked markers, and defines the shared Vitest configuration.

check-treeshakeability.js is self-contained: its driver builds the bundle (grp:check-treeshakeability.js-bundle-code), runs checks, and reports failures with exit 1. rollup.config.js and vitest.config.js are pure configuration.

**Depends on.**

- [Client Runtime](r3-client-runtime.md) · model-inferred · 0 edge(s)
- [Svelte Compiler and Runtime](r3-svelte.md) · within containment · 2 edge(s)

Parent: [Repository Tooling](r3-tooling.md)

## Units (5)

<a id="u-2eb418b9a160"></a>
### `rollup.config.js module code (L1–L17)`

`module_region` · [packages/svelte/rollup.config.js:L1-L17][f1]

Configures the Rollup build that compiles the Svelte compiler into a single UMD bundle.

Importing ./scripts/generate-version.js triggers version generation as an import side effect before configuration is returned. The config bundles src/compiler/index.js into compiler/index.js as a UMD module named 'svelte', applying node resolution, CommonJS interop, and Terser minification. Output settings and plugin order are fixed; no conditional branches exist.

imports: [rollup-config-js-imports](../../catalog.json)

**Uncertainties.**

- Behavior of generate-version.js and whether the build fails if it throws is not visible here.

<a id="u-be696749d63c"></a>
### `check_bundle`

`function check_bundle(case_name, ...strings)` · [packages/svelte/scripts/check-treeshakeability.js:L125-L146][f2]

Checks the prebuilt top-level `bundle` string for code that should have been tree-shaken, given a case name and marker substrings.

For each marker in order it takes its first indexOf in the bundle; a hit (index >= 0) prints ❌ for the case, sets the module-level `failed` flag, prints a ±500-character excerpt around the match with the marker's line prefixed '>' and neighbors '|', showing only six lines either side, and returns immediately — later markers are not checked once one fails. If no marker is found it prints ✅ for the case. Side effects: console output and the shared `failed` flag; returns nothing.

uses: [check-treeshakeability.js module code (L146–L163)](r3-build-tooling.md#u-52b747b1c51f)

**Uncertainties.**

- findIndex can return -1 if the marker spans the excerpt's line split, which would mark the wrong line; not guarded in source.

<a id="u-65c13f088150"></a>
### `check-treeshakeability.js module code (L46–L124)`

`module_region` · [packages/svelte/scripts/check-treeshakeability.js:L46-L124][f2]

Script driver that audits every export in package.json for tree-shakeability and then builds one feature-rich client bundle.

It skips the special export keys './compiler', './internal', './internal/disclose-version', './internal/flags/legacy' and './internal/flags/tracing'. For each remaining key it iterates the 'browser' and 'default' condition types, skipping absent entries, bundles a bare import of the resolved file, and reports ✅ when output is empty or prints the residue plus ❌ and sets the module-level `failed` flag otherwise. It then compiles a synthetic App.svelte exercising mount plus hydration-relevant features (bind:value, spread, svelte:component/element/head, if/each/await/key/snippet, render, html) and bundles the generated JS into a top-level `bundle` string consumed by the later checks.

calls: [check-treeshakeability.js-bundle-code](r3-svelte.md#u-df4ca4955d27); uses: [check_bundle](r3-build-tooling.md#u-be696749d63c)

<a id="u-52b747b1c51f"></a>
### `check-treeshakeability.js module code (L146–L163)`

`module_region` · [packages/svelte/scripts/check-treeshakeability.js:L146-L163][f2]

Final reporting tail of the script: it runs three bundle checks — 'Hydration code' against 'hydrate_node' and 'hydrate_next', 'Legacy code' against 'component_context.l', and '$inspect.trace' against 'CreatedAt' — then, if `failed` was set by any check or the export scan, prints the resolved path of scripts/_bundle.js, writes the full bundle there, closes the console group, and exits with status 1.

When nothing failed the process ends normally and no artifact is written.

**Notes.**

- side_effect: On failure the full generated bundle is persisted to scripts/_bundle.js for inspection.

calls: [check_bundle](r3-build-tooling.md#u-be696749d63c)

<a id="u-cfeb87e5efa3"></a>
### `vitest.config.js module code (L1–L46)`

`module_region` · [vitest.config.js:L1-L46][f3]

Defines the shared Vitest configuration for the Svelte repository.

It reads packages/svelte/package.json at load time and registers a resolve alias for any specifier starting with 'svelte/' whose customResolver maps the specifier through the package.json 'exports' map, falling back to packages/svelte on disk. The resolver treats the bare id 'undefined' (noted in the source as arriving unexpectedly instead of 'svelte/') as the root export '.', and rewrites other ids containing 'undefined' to './'. If no exports entry matches, it returns undefined so the default resolution applies. Export selection depends on the importer: when the importer path contains '_output/server' the server export (exported.default) is used, otherwise the browser export is preferred, falling back to the default export. The test section scopes tests to the repository root with a 'dot' reporter, includes only test files under packages/svelte (including tests/*/test.ts and the runtime-browser test-ssr.ts), excludes default excludes plus '**/samples/**', and configures v8 coverage with lcov and html reporters over packages/svelte/src, written to 'coverage' with reportOnFailure enabled.

**Notes.**

- side_effect: Module load synchronously reads and parses packages/svelte/package.json; an invalid or missing file throws before the config is exported.
- condition: The customResolver returns undefined when the exports lookup misses, leaving resolution to Vitest's default behavior.

imports: [vitest/config](../../catalog.json), [node:fs](../../catalog.json), [node:path](../../catalog.json)

**Uncertainties.**

- The comment says the id can literally be 'undefined'; the exact upstream condition producing that string is not visible here, and the id.replace('undefined', './') branch's triggering inputs are likewise not established by this file.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/rollup.config.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/scripts/check-treeshakeability.js
[f3]: ../../../../../../eval/svelte-be645b4/vitest.config.js
