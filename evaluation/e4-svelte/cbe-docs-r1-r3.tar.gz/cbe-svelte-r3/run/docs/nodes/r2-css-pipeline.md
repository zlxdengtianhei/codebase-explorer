# CSS Pipeline

**Capability.** End-to-end handling of <style> content: character-level parsing into a CSS AST, analysis for unused selectors and global/scoping semantics, and final rendering with :global removal, pruning, and source maps.

Start at css-parse to see how selector text becomes AST; css-analyze decides what is used and global; css-transform emits final CSS. The three sub-phases share the CSS AST types declared in compiler-foundations.

**Children.**

- [CSS Parsing](r2-css-parse.md) `r2-css-parse` · 14 unit(s)
- [CSS Analysis](r2-css-analyze.md) `r2-css-analyze` · 11 unit(s)
- [CSS Transform](r2-css-transform.md) `r2-css-transform` · 8 unit(s)

Parent: [Svelte Compiler](r2-compiler.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
