# Client Prop Accessors

**Capability.** Implements component prop semantics at runtime: single prop getters/setters that sync bound props, proxies for spread attribute chains, rest-props exclusion proxies, coarse-grained legacy $$restProps/$$props proxies, and increment helpers.

grp:props.js-prop is the core accessor; spread-props, rest-props, and legacy-rest-props are proxy variants built on it. prop updaters are the ++/-- closures the compiler emits.

**Depends on.**

- [Client Store Integration](r3-client-stores.md) · graph-confirmed · 1 edge(s)

Parent: [Client Reactivity: Props and Stores](r3-client-reactivity.md)

## Units (6)

<a id="u-2e500006b90d"></a>
### `props.js-prop`

`export function prop(props, key, flags, fallback)` · [packages/svelte/src/internal/client/reactivity/props.js:L278-L286][f1]

Implements a single component prop accessor, synchronizing possibly-bound props with local state and returning a getter/setter function.

Setup classifies the prop from flags: runes (legacy_mode_flag off or PROPS_IS_RUNES), bindable (PROPS_IS_BINDABLE), lazy initial (PROPS_IS_LAZY_INITIAL). get_fallback caches the fallback value once, untracking it when lazy. For bindable props the setter is taken from the props descriptor's set, or, for entry props (STATE_SYMBOL/LEGACY_PROPS present), a direct assignment; otherwise there is none. For bindable props the initial value is read under capture_store_binding to detect store bindings; if the initial value is undefined and a fallback exists, the fallback is computed and pushed through the setter (throwing props_invalid_value in runes mode if the setter is not a real set accessor). Getter variants: runes mode falls back only while the prop is currently undefined and re-marks the fallback dirty when a defined value appears; legacy mode permanently discards the fallback once the prop has had a value. Return paths in order: (1) never-written runes props return just the getter; (2) if a parent-side setter exists, the returned function calls setter on writes — skipping notification for pure mutations in runes mode unless the parent is legacy or it is a store subscription — and reads the getter otherwise, passing getter() instead of the raw value when mutation is true; (3) otherwise a derived (safe-equal unless PROPS_IS_IMMUTABLE) wraps the getter, labeled with the key in dev and eagerly read once when bindable, and writes go through set(d, ...) with proxy(value) for runes bindable props, tracking an overridden flag; reads serve the cached d.v when tearing down while overridden or when the parent effect is DESTROYED (the bind:this case), else read the derived normally.

**Notes.**

- condition: arguments.length === 0 means read; any argument (even undefined) means write, which is why writes pass values explicitly.
- failure: Assigning undefined-with-fallback to a runes bindable prop without a real setter throws props_invalid_value.

calls: [derived](r4-runtime-signals.md#u-d386336ed5eb), [proxy.js-proxy](r4-runtime-signals.md#u-100d26a5c84c), [runtime-js-state-and-helpers](r2-reactivity-core.md#u-6cd2387802ec), [store.js-store-binding-flag](r3-client-stores.md#u-cba0e706248c), [packages/svelte/src/internal/client/reactivity/sources.js:set](r5-client-reactivity.md#u-452914169f68)

**Uncertainties.**

- Behavior when props[key] getter itself throws is not handled here.
- The exact semantics of capture_store_binding's boolean live in store.js.

<a id="u-3f2d8c92820c"></a>
### `props.js-prop-updaters`

`export function update_prop(fn, d = 1)` · [packages/svelte/src/internal/client/reactivity/props.js:L31-L35][f1]

Numeric post- and pre-increment/decrement helpers over prop accessor closures.

update_prop reads the current value via fn(), writes value + d (d defaults to 1, may be -1), and returns the pre-write value. update_pre_prop computes value + d first, writes it, and returns the new value. Both rely on fn being the compiler-generated get/set pair for a prop and perform no validation.

<a id="u-ee39c41b1f1a"></a>
### `props.js-rest-props`

`const rest_props_handler = { get(target, key)` · [packages/svelte/src/internal/client/reactivity/props.js:L53-L57][f1]

Implements rest props (`const { x, ...rest } = $props()`) as a proxy over the full props object plus an exclude list.

get and getOwnPropertyDescriptor return undefined/absent for excluded keys and otherwise read target.props directly (retaining reactivity of the underlying sources); has mirrors that with false for excluded keys; ownKeys filters Reflect.ownKeys of props by the exclude list. set always fails: in dev it reports props_rest_readonly with the proxy name and key, and returns false so strict-mode assignment throws. rest_props constructs the proxy; in dev the target also carries name, other and to_proxy fields (unused by this handler's visible code).

**Notes.**

- failure: Writes to rest props always return false from set; in production the readonly error is not reported but the assignment still fails.

uses: [proxy.js-proxy](r4-runtime-signals.md#u-100d26a5c84c)

**Uncertainties.**

- The dev-only other/to_proxy target fields are not referenced by this handler; their consumers are elsewhere.

<a id="u-22f148fdaa7c"></a>
### `props.js-spread-props`

`const spread_props_handler = { get(target, key)` · [packages/svelte/src/internal/client/reactivity/props.js:L189-L197][f1]

Proxy over an ordered list of prop objects (each possibly a lazy () => object) for spread attributes.

get walks the list from last to first, unwrapping functions, and returns the first object containing the key. set walks the same order and uses the first object whose descriptor for the key has a setter, returning true; with no setter found it returns false (assignment fails in strict mode). getOwnPropertyDescriptor returns the first matching descriptor; if it is non-configurable it rewrites configurable to true to avoid a proxy invariant violation, since the proxy target (an array) does not actually own the key. has returns false for STATE_SYMBOL/LEGACY_PROPS to avoid false positives in prop's is_entry_props check, otherwise true if any source object has the key. ownKeys collects enumerable string keys plus own symbols from all source objects in order, deduplicated. spread_props wraps the array in the proxy.

calls: [utils.js-small-helpers](r1-shared-runtime.md#u-aa0ed6112e71)

**Uncertainties.**

- getOwnPropertyDescriptor claiming configurability for a genuinely non-configurable source descriptor may affect later defineProperty attempts; outcome depends on proxy invariants outside this file.

<a id="u-d75531e1473e"></a>
### `props.js-legacy-rest-props`

`const legacy_rest_props_handler = { get(target, key)` · [packages/svelte/src/internal/client/reactivity/props.js:L103-L108][f1]

Proxy handler for legacy $$restProps/$$props, keyed by a version source so the whole object is coarse-grained.

get skips excluded keys, subscribes to target.version, and returns special[key]\() when a special per-key prop accessor exists (keys temporarily out of sync with the parent), else target.props[key]. set: if the key has no special accessor, it installs one by calling prop() with PROPS_IS_UPDATED inside a getter reading target.props[key], with active_effect temporarily switched to the stored parent_effect and restored in finally; then it invokes special[key]\(value) and bumps the version so any $$props.y usage also reruns. deleteProperty (Svelte 4 deletions) pushes the key onto exclude, bumps the version, and returns true; excluded keys short-circuit to true without side effects. getOwnPropertyDescriptor/has/ownKeys behave like the rest-props handler, reading target.props and filtering exclude. legacy_rest_props builds the proxy, creating the version source and capturing the current active_effect as parent_effect (cast non-null).

**Notes.**

- side_effect: set always returns true, so legacy writes never throw even when they only update the special accessor.

calls: [props.js-prop](r3-client-props.md#u-2e500006b90d), [runtime-js-state-and-helpers](r2-reactivity-core.md#u-6cd2387802ec), [sources.js-update-helpers](r5-client-reactivity.md#u-cecd1288571c)

<a id="u-5e98617d4c45"></a>
### `update_prop`

`export function update_prop(fn, d = 1)` · [packages/svelte/src/internal/client/reactivity/props.js:L31-L35][f1]

See grouped unit grp:props.js-prop-updaters.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/reactivity/props.js
