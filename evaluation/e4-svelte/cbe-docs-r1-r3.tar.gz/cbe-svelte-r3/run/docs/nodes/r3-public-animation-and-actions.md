# Public Animation and Action Contracts

**Capability.** Public API surface for animations and actions: the flip FLIP-animation implementation and the TypeScript declarations for AnimationConfig, FlipParams, and Action/ActionReturn.

Users import flip and the types from svelte/animate and svelte/action. The d.ts units define the contract flip itself conforms to.

Parent: [Shared Utilities and Public Contracts](r3-shared.md)

## Units (4)

<a id="u-2953ae0602e1"></a>
### `flip`

`export function flip(node, { from, to }, params = {})` · [packages/svelte/src/animate/index.js:L13-L58][f1]

Computes a FLIP animation for an element moving between two DOMRect positions, returning an `AnimationConfig` whose `css(t, u)` emits a transform string.

It destructures params with defaults: delay 0, duration `d => Math.sqrt(d) * 120`, easing `cubicOut`. It reads the computed style, keeping `transform` only when it is not 'none', normalizes the transform origin to 0–1 fractions of client width/height, and derives per-axis scale factors from the ratio of client size to the `to` rect divided by the effective zoom. Start/end origin points are computed from the rects; `dx`/`dy` are the origin delta scaled by those factors, and `dsx`/`dsy` the relative scales. The returned duration is `duration(distance)` when a function was supplied, else the literal value; distance is the Euclidean length of `(dx, dy)`. The `css` callback interpolates translate by `u * dx/dy` and scale between 1 and the relative scales. No state is mutated; exceptions from `getComputedStyle` propagate.

**Notes.**

- side_effect: getComputedStyle forces style resolution on the node at animation setup time.

calls: [flip](r3-public-animation-and-actions.md#u-2953ae0602e1); imports: [../easing/index.js](../../catalog.json)

**Uncertainties.**

- Behavior when `node.clientWidth` or rect dimensions are 0 (division by zero producing Infinity/NaN) is not guarded in the source

<a id="u-8715abeb9049"></a>
### `AnimationConfig`

`export interface AnimationConfig` · [packages/svelte/src/animate/public.d.ts:L2-L8][f2]

Declares the optional animation configuration shape: delay and duration numbers, an easing mapping t to a curve value, css generating a stylesheet string from (t, u), and a tick callback receiving (t, u).

Pure type declaration with no runtime behavior.

<a id="u-5713e0c9d221"></a>
### `FlipParams`

`export interface FlipParams` · [packages/svelte/src/animate/public.d.ts:L10-L14][f2]

Declares parameters for flip animations: optional delay, an optional duration that is either a fixed number or computed from an element-count length, and an optional easing function over t.

Pure type declaration.

<a id="u-9af2c2d11258"></a>
### `public-d-ts-action`

`export interface ActionReturn< Parameter = undefined, Attributes extends Record<strin…` · [packages/svelte/src/action/public.d.ts:L27-L39][f3]

Declares the TypeScript-only contracts for Svelte element actions.

`ActionReturn<Parameter, Attributes>` is the object an action may return: optional `update(parameter)` invoked after markup updates whenever the parameter changes, optional `destroy()` invoked after unmount, and a `$$_attributes` marker property that exists solely for type-checking and has no runtime effect. `Action<Element, Parameter, Attributes>` types the action function itself; its call signature uses `undefined extends Parameter` (rather than the converse, an intentional strict/non-strict compatibility choice noted in the file) to decide whether the parameter argument is optional. `Action` and `Action<_, undefined>` both signal a parameterless action. Nothing here executes at runtime; extra attributes/events surfaced through `Attributes` are typing only.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/animate/index.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/animate/public.d.ts
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/action/public.d.ts
