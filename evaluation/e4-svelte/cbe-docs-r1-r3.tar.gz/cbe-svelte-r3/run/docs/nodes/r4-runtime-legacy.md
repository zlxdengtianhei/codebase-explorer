# Legacy Public API

**Capability.** The svelte package's deprecated client-facing component APIs: lifecycle callbacks (onMount/onDestroy/beforeUpdate/afterUpdate) built on lazily initialized legacy context, createEventDispatcher with custom event construction, AbortSignal access for reactions, and dev-time rune misread guards.

Use this subtree when working with legacy-mode components or deprecated imports. Callback registration funnels through init_update_callbacks; throw_rune_error protects rune names at runtime.

**Depends on.**

- [Signals, Deriveds, and Proxies](r4-runtime-signals.md) · model-inferred · 0 edge(s)

Parent: [Svelte Compiler and Runtime](r4-svelte-monorepo.md)

## Units (9)

<a id="u-3eabc3a794df"></a>
### `afterUpdate`

`export function afterUpdate(fn)` · [packages/svelte/src/index-client.js:L223-L233][f1]

Registers a post-update callback (legacy only, deprecated in favor of $effect).

Throws `e.lifecycle_outside_component('afterUpdate')` outside a component and `e.lifecycle_legacy_only('afterUpdate')` when `component_context.l` is null (runes mode). Appends `fn` to the legacy callbacks' `a` array via `init_update_callbacks`; first run is after initial onMount.

calls: [init_update_callbacks](r4-runtime-legacy.md#u-f15a32115088)

<a id="u-346a7286b04e"></a>
### `beforeUpdate`

`export function beforeUpdate(fn)` · [packages/svelte/src/index-client.js:L200-L210][f1]

Registers a pre-update callback (legacy only, deprecated in favor of $effect.pre).

Throws `e.lifecycle_outside_component('beforeUpdate')` outside a component and `e.lifecycle_legacy_only('beforeUpdate')` when `component_context.l` is null (i.e. runes mode). Otherwise appends `fn` to the legacy callbacks' `b` array via `init_update_callbacks`; the runtime invokes these callbacks before each update, with the first run before initial onMount.

calls: [init_update_callbacks](r4-runtime-legacy.md#u-f15a32115088)

<a id="u-a13f6abb0775"></a>
### `createEventDispatcher`

`export function createEventDispatcher()` · [packages/svelte/src/index-client.js:L157-L185][f1]

Creates a legacy component-event dispatcher; deprecated in favor of callback props/$host.

Captures `component_context` at creation time and throws `e.lifecycle_outside_component('createEventDispatcher')` if it is null. The returned dispatcher looks up `type` in the captured component's `$$events` table: if no handlers exist it returns true without creating an event. Otherwise it copies the handler (or handler array) to avoid mutation during dispatch, builds a CustomEvent via `create_custom_event` with the given detail and options, invokes each handler with `fn.call(active_component_context.x, event)` (so `this` is the component's x context), and returns whether the event was not default-prevented — the dispatcher's boolean result lets callers detect `event.preventDefault()`.

calls: [create_custom_event](r4-runtime-legacy.md#u-c36028ba992c); imports: [index-client.js module code (L1–L16)][f1]

**Uncertainties.**

- A source comment questions server-environment dispatch; how $$events behaves in SSR is not defined here.

<a id="u-c36028ba992c"></a>
### `create_custom_event`

`function create_custom_event(type, detail, { bubbles = false, cancelable = false } = {})` · [packages/svelte/src/index-client.js:L130-L132][f1]

Creates a CustomEvent with the given type, detail, and options, defaulting bubbles and cancelable to false when the options object is omitted.

<a id="u-9fba83ef7551"></a>
### `getAbortSignal`

`export function getAbortSignal()` · [packages/svelte/src/index-client.js:L69-L75][f1]

Returns an AbortSignal tied to the currently running derived or effect: the signal aborts when that reaction re-runs or is destroyed.

If `active_reaction` is null it throws via `e.get_abort_signal_outside_reaction` (no return). Otherwise it lazily attaches an AbortController to the reaction's `ac` field and returns its signal, so repeated calls within one reaction share one controller.

**Uncertainties.**

- Cleanup/abort of the stored controller is handled elsewhere (runtime.js), not here.

<a id="u-f15a32115088"></a>
### `init_update_callbacks`

`function init_update_callbacks(context)` · [packages/svelte/src/index-client.js:L239-L242][f1]

Legacy-mode helper that lazily initializes the `{ a: [], b: [], m: [] }` callbacks record on a component's legacy context `l`, returning the existing record if already created; used by onMount, beforeUpdate, and afterUpdate.

<a id="u-de75503262fc"></a>
### `onDestroy`

`export function onDestroy(fn)` · [packages/svelte/src/index-client.js:L115-L121][f1]

Schedules a callback to run when the component unmounts, in both client and (per its doc) server contexts.

Throws `e.lifecycle_outside_component('onDestroy')` when `component_context` is null. It delegates to `onMount`, returning a wrapper that itself returns `untrack(fn)`; because that wrapper returns a function, onMount's cleanup mechanism registers `fn` for teardown.

calls: [onMount](r4-runtime-legacy.md#u-3c1ac43e0c43); imports: [index-client.js module code (L1–L16)][f1]

<a id="u-3c1ac43e0c43"></a>
### `onMount`

`export function onMount(fn)` · [packages/svelte/src/index-client.js:L91-L104][f1]

Schedules a function to run once after the component mounts.

Throws `e.lifecycle_outside_component('onMount')` when `component_context` is null. In legacy mode with a legacy context (`legacy_mode_flag && component_context.l !== null`), it pushes the callback onto the legacy callbacks' `m` array via `init_update_callbacks`. Otherwise it wraps the callback in a `user_effect`: the effect runs `untrack(fn)` and, if the callback synchronously returned a function, returns that as the effect cleanup, implementing the onMount teardown convention; non-function (including Promise) return values produce no cleanup.

calls: [init_update_callbacks](r4-runtime-legacy.md#u-f15a32115088); contract: [onDestroy](r4-runtime-legacy.md#u-de75503262fc); imports: [index-client.js module code (L1–L16)][f1]

**Uncertainties.**

- Exact timing of the user_effect vs mount is defined in internal/runtime modules not supplied.

<a id="u-766cb9a97e53"></a>
### `throw_rune_error`

`function throw_rune_error(rune)` · [packages/svelte/src/index-client.js:L16-L36][f1]

DEV-only guard that turns accidental reads of rune names like '$state' outside Svelte compilation into a runtime error.

For a rune not already on `globalThis`, it defines a configurable property whose getter throws `e.rune_outside_svelte(rune)` unless a value has first been set; the setter just stores the value, so code that assigns the rune name to something else works and later reads succeed. Called once per rune at module load ($state, $effect, $derived, $inspect, $props, $bindable) inside the `if (DEV)` block, so it never runs in production.

**Notes.**

- side_effect: Mutates globalThis with getter/setter properties that persist for the page lifetime (though configurable, nothing in this file removes them).

**Uncertainties.**

- Whether the defined property is ever deleted/configured elsewhere is not visible here.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/index-client.js
