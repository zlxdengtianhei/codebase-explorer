# Warning Message Codegen

**Capability.** Regenerates all Svelte message reference docs and generated warning source files from markdown under messages/, driven by the client/compile/shared warning code templates.

Read index.js-run to see how templates are expanded into internal warning modules. The three template units are inputs to that expansion and are structurally near-identical; edit messages/markdown rather than the generated output.

**Depends on.**

- [Compiler Foundations](r2-compiler-foundations.md) · model-inferred · 0 edge(s)
- [Reactive Primitives](r2-reactive-primitives.md) · graph-confirmed · 1 edge(s)

Parent: [Tooling & Benchmarks](r2-tooling.md)

## Units (4)

<a id="u-f2d5f8b6c5f2"></a>
### `index.js-run`

`function run()` · [packages/svelte/scripts/process-messages/index.js:L17-L100][f1]

Regenerates all Svelte message reference docs and generated source files from markdown under messages/.

`run` deletes and recreates the generated docs directory (DIR), then for each non-hidden category directory reads each .md file (CRLF normalized), parses '## CODE' sections with a regex capturing code and body up to the next heading or EOF. A duplicate code anywhere throws 'Duplicate message code'; a section with no blockquote message text throws 'No message text'. Trailing non-blockquote paragraphs are treated as details and collected before the messages; '> ' markers are stripped from message lines. Sections are rewritten back into the source .md sorted by code, and a generated per-category reference file is written with a do-not-edit banner, per-code headings, fenced messages, and appended details, sorted alphabetically. The nested `transform(name, dest)` then processes seven named templates: it parses the template with acorn (comments captured, block-comment tab indentation stripped), walks the AST to replace any identifier 'CODES' with an array literal of the message codes for that template's category, locates the exported `CODE` function declaration (throwing 'missing export function CODE' if absent), removes it from the body, and takes the nearest preceding comment as its JSDoc. For each message code it derives the %var% placeholders across the message's overload sequence, builds an expression per overload — a plain literal when there are no vars, otherwise a TemplateLiteral splitting on %word% tokens; successive overloads with new parameters become nested ConditionalExpressions testing the newly introduced variable, and two consecutive overloads with equal var counts throw 'Message overloads must have new parameters' — then clones the CODE template via a walk: FunctionDeclaration replaces a PARAMETER identifier param with the collected vars and renames the function to the code; TemplateLiteral splices the code string into literal 'CODE' expressions, inlines a Literal message, or merges a TemplateLiteral message's quasis/expressions; Literal 'CODE' and Identifier 'MESSAGE' are substituted directly. The JSDoc clone rewrites a ' * MESSAGE' line to the final message text, expands a PARAMETER line into one @param per var (optional 'string | undefined | null' for vars not present in the first overload), and drops empty lines. Each printed block is appended to the output, all clones pushed back into the body, and the result written to dest with a generated-file banner. When invoked with -w, a recursive fs.watch on 'messages' debounces concurrent events (a `running` flag plus a single deferred timeout) and reruns `run`; otherwise `run` executes once at import time.

uses: [packages/svelte/scripts/process-messages/templates/compile-errors.js][f2], [packages/svelte/scripts/process-messages/templates/compile-warnings.js][f3], [packages/svelte/scripts/process-messages/templates/client-errors.js][f4]

**Uncertainties.**

- The detail-extraction loop assumes the last section always starts with '> '; a message file ending in plain text is moved into details, so a final unquoted paragraph is never treated as a message.
- Whether watch-mode events dropped while `running` always coalesce into exactly one rerun depends on setTimeout timing, not provable from source alone.

<a id="u-7208ae31f34c"></a>
### `client-warnings.js-code-template`

`export function CODE(PARAMETER)` · [packages/svelte/scripts/process-messages/templates/client-warnings.js:L10-L20][f5]

Code-generator template for client-side warning functions (expanded into src/internal/client/warnings.js by process-messages).

It defines two console style strings, bold and normal, and exports a CODE function template: under DEV it console.warns a styled message with the %c format — bold '[svelte] <code>' header, normal message body, and the https://svelte.dev/e/<code> link — while in production it warns only the link URL. The generator replaces the literal code placeholders and MESSAGE/PARAMETER, emitting one named warning function per code; warnings never throw, they only log.

contract: [index.js-run](r2-message-codegen.md#u-f2d5f8b6c5f2)

**Uncertainties.**

- DEV resolution from esm-env is external to this file.

<a id="u-4bd1768bc558"></a>
### `compile-warnings.js-template`

`class InternalCompileWarning extends CompileDiagnostic` · [packages/svelte/scripts/process-messages/templates/compile-warnings.js:L6-L14][f3]

Template for compiler warning emission (expanded into src/compiler/warnings.js by process-messages).

InternalCompileWarning extends CompileDiagnostic directly, adding only an enumerable name 'CompileWarning', and forwards code/message/position to the super constructor. The internal helper w() decides whether a warning is emitted: it starts from the shared ignore_stack, but when a node is given it prefers ignore_map.get(node) falling back to ignore_stack; if that stack exists and its top-most set contains the code, the warning is suppressed. Otherwise it constructs an InternalCompileWarning with position [start, end ?? start] when node.start is defined (undefined otherwise), applies the shared warning_filter, and pushes the warning only if the filter accepts. `codes` is exported as the CODES placeholder, which the generator replaces with the category's code list. The exported CODE function template calls w() with the node, code string, and message text plus the https://svelte.dev/e/<code> link; it never throws, and the generator expands it into one function per warning code.

contract: [index.js-run](r2-message-codegen.md#u-f2d5f8b6c5f2)

**Uncertainties.**

- ignore_stack, ignore_map, warnings and warning_filter come from ./state.js and CompileDiagnostic from ./utils/compile_diagnostic.js; their semantics are outside this batch.

<a id="u-a879bd248b33"></a>
### `shared-warnings.js-code-template`

`export function CODE(PARAMETER)` · [packages/svelte/scripts/process-messages/templates/shared-warnings.js:L10-L20][f6]

Code-generator template for shared warning functions (expanded into src/internal/shared/warnings.js by process-messages), structurally identical to the client-warnings template.

It defines bold/normal console style strings and exports a CODE function template that DEV-gates console.warn: in development a styled message with a bold '[svelte] <code>' header, the normal-styled message body, and the https://svelte.dev/e/<code> link; in production only the link URL. Warnings log but never throw; the generator emits one named function per code.

contract: [index.js-run](r2-message-codegen.md#u-f2d5f8b6c5f2)

**Uncertainties.**

- DEV resolution from esm-env is external to this file.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/scripts/process-messages/index.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/scripts/process-messages/templates/compile-errors.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/scripts/process-messages/templates/compile-warnings.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/scripts/process-messages/templates/client-errors.js
[f5]: ../../../../../../eval/svelte-be645b4/packages/svelte/scripts/process-messages/templates/client-warnings.js
[f6]: ../../../../../../eval/svelte-be645b4/packages/svelte/scripts/process-messages/templates/shared-warnings.js
