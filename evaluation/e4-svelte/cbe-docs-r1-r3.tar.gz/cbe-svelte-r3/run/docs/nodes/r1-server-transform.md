# Server Transform

**Capability.** Serializes component analyses into SSR output: transforming component and module Programs into server-side code, and per-node visitors that emit payload-appending statements for blocks, tags, head, boundaries, and store updates; types.d.ts declares the server transform contracts.

Read a visitor to see how one AST node becomes a `$.xxx($$payload, ...)` statement in SSR output. transform-server/server_module are the entry points; AssignmentExpression and UpdateExpression rewrite state and store writes.

**Depends on.**

- [Server Runtime](r1-server-runtime.md) · model-inferred · 0 edge(s)
- [Shared Assignment Driver](r1-shared-assignment-transform.md) · graph-confirmed · 1 edge(s)

Parent: [Transform Phase](r1-compiler-transform.md)

## Units (17)

<a id="u-3bff6efcb646"></a>
### `transform-server-js-server-component`

`export function server_component(analysis, options)` · [packages/svelte/src/compiler/phases/3-transform/server/transform-server.js:L90-L112][f1]

Transforms a component analysis into the SSR server-side Program.

Initializes ComponentServerTransformState (initializing hoisted with the svelte/internal/server import; init/template filled later by the Fragment visitor) and walks three trees: the module script with global_visitors, the instance script with global_visitors plus two overrides — ImportDeclaration is moved into state.hoisted and replaced with b.empty, and ExportNamedDeclaration is transparently replaced by its declaration (or removed) — and the template with global_visitors plus template_visitors. Legacy ($:) statements recorded in state.legacy_reactive_statements are appended to the instance body; if any targets a legacy_reactive binding via an assignment's extracted identifiers, a leading `let` declaration of those identifiers is unshifted; a missing recorded statement throws 'Could not find reactive statement'. When analysis.uses_component_bindings, the template body is restructured into snippet declarations plus a do/while loop re-rendering until $$settled, copying and assigning payloads. If any instance binding is a store_sub, a $$store_subs var is declared and an unsubscribe call appended to the template. Bindable props (excluding $$-prefixed) and exported values are collected into a props object passed to $.bind_props when non-empty. The instance and template bodies merge into component_block; $.push/$.pop calls bracket it in dev or when analysis.needs_context; analysis.props_id becomes a leading $.props_id const; uses_rest_props/uses_props add $$restProps/$$sanitized_props consts; uses_slots adds $$slots. When CSS is injected (css ast exists, options.css==='injected', not customElement), $$css { hash, code } is emitted via render_stylesheet and $.payload.css.add is called first in the component block. should_inject_props decides the $$props parameter. Output depends on compatibility.componentApi and dev: Svelte-4 mode adds a render shim and default export of the component; dev adds a render() that throws 'Component.render(...) is no longer valid in Svelte 5' and a FILENAME marker assignment; otherwise the function itself is default-exported. Dev also unshifts the FILENAME assignment.

**Notes.**

- failure: Throws if a reactive statement from analysis.reactive_statements has no matching entry in state.legacy_reactive_statements.
- side_effect: All program assembly is via the b.* builders; no mutation of the input analysis AST occurs except reading.

calls: [extract_identifiers](r4-compiler-ast-utils.md#u-90eb95affc00), [render_stylesheet](r2-css-transform.md#u-197b2d45aa0c)

**Uncertainties.**

- Whether the ImportDeclaration/ExportNamedDeclaration overrides apply only within the instance walk is clear from placement, but their interaction with hoisted module-level imports elsewhere is not verified.

<a id="u-7e11f4406861"></a>
### `server_module`

`export function server_module(analysis, options)` · [packages/svelte/src/compiler/phases/3-transform/server/transform-server.js:L392-L415][f1]

Transforms a <script module> analysis into an SSR module Program.

Builds a ServerTransformState (including an empty legacy_reactive_statements map that exists only so shared legacy visitors work), walks the module AST with global_visitors, and returns a Program whose body begins with the svelte/internal/server namespace import followed by the transformed statements.

<a id="u-327ce0ca4830"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/AssignmentExpression.js:AssignmentExpression`

`export function AssignmentExpression(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/AssignmentExpression.js:L14-L16][f2]

Delegates server-side assignment-expression transformation to the shared helper, using build_assignment for store/class-field rewriting.

If the helper yields an expression it is returned; otherwise context.next() continues default traversal, so non-special assignments pass through untouched.

calls: [packages/svelte/src/compiler/phases/3-transform/server/visitors/AssignmentExpression.js:build_assignment](r1-server-transform.md#u-e2028cc30489), [visit_assignment_expression](r1-shared-assignment-transform.md#u-b43a982ab161)

**Uncertainties.**

- Exact behavior of visit_assignment_expression (fallback ordering, when it returns null) is in shared/assignments.js, not this file.

<a id="u-e2028cc30489"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/AssignmentExpression.js:build_assignment`

`function build_assignment(operator, left, right, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/AssignmentExpression.js:L26-L100][f2]

Rewrites assignments to class state fields and $store names during server compilation; returns null to keep the assignment as-is when no rewrite applies.

First, in runes mode, a non-computed member on `this` whose property names a known state field is handled: if the field was declared by an assignment in the class constructor and this is that same left node, and the right side is a rune call, the assignment becomes a `this.<key> = ...` where the key is the private property itself for private fields, `$state`, or `$state.raw`, otherwise the field's backing key. If instead the field is `$derived`/`$derived.by` and the property is private, the assignment value (built via build_assignment_value) is visited and the result becomes a call `this.#name(value)`, invoking the derived getter/setter. Second, store handling: the left side is unwrapped through nested MemberExpressions to the base object; if that base is not an Identifier whose name starts with `$` followed by a letter/underscore (is_store_name), or the de-$-prefixed name is absent from scope, null is returned. If the whole left side was the store identifier itself, it becomes `$.store_set(name, visitedValue)`. For member assignments on a store (e.g. `$obj.x = ...`), it emits `$.store_mutate(($$store_subs ??= {}), '<$name>', name, visitedAssignment)`. Visits to left/right side effects occur in both rewrite paths.

calls: [get_name](r4-compiler-node-model.md#u-99af92983a86), [get_rune](r4-compiler-scope.md#u-5204b6ce4f7a), [build_assignment_value](r4-compiler-ast-utils.md#u-634ffef5ceee), [packages/svelte/src/compiler/phases/3-transform/server/visitors/AssignmentExpression.js:build_assignment](r1-server-transform.md#u-e2028cc30489)

**Uncertainties.**

- Whether context.state.state_fields is always populated depends on ClassBody's child state; null/absent map behavior for non-class contexts is not visible here.

<a id="u-8619e1ace336"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/AwaitBlock.js:AwaitBlock`

`export function AwaitBlock(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/AwaitBlock.js:L11-L29][f3]

Emits server output for an {#await} block as a `$.await($$payload, expression, pendingThunk, thenArrow)` statement appended to the template, followed by block_close.

Missing pending branch becomes an empty block; a missing value/then becomes an empty-arrow body, so absent branches render nothing.

<a id="u-9d632fc04d55"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/AwaitExpression.js:AwaitExpression`

`export function AwaitExpression(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/AwaitExpression.js:L9-L25][f4]

Rewrites a top-level `await` in component body code to a runtime boundary check.

If the await is at function depth 0 or anywhere beneath a function node in the path, it is legal and default traversal continues via context.next(); otherwise the expression is replaced with a call to `$.await_outside_boundary`, deferring the error to server render time.

uses: [packages/svelte/src/compiler/phases/3-transform/server/visitors/AwaitExpression.js:AwaitExpression.js module code (L1–L8)][f4]

<a id="u-2f46ddefb329"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/ClassBody.js:ClassBody`

`export function ClassBody(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/ClassBody.js:L10-L81][f5]

Transforms class bodies in runes mode into accessor-based field representations; in legacy mode (no state_fields entry for this ClassBody) it just continues default traversal.

It first inserts backing property definitions plus get/set method pairs for `$derived`/`$derived.by` fields that were only assigned in the constructor, so external writes route through the derived setter. Then it walks the original body: non-PropertyDefinition members are visited and kept as-is; for PropertyDefinitions, an unknown name is kept unchanged; private (`#`) names and `$state`/`$state.raw` fields are visited and kept; a definition that is itself a `$derived` field's declaration is replaced by a backing property (keyed by field.key, initialized with the visited rune value) plus getter and `$$value`-forwarding setter calling `this.<key>()`. Public non-private state fields not matching these cases are dropped from the output. Returns a shallow-copied node with the rebuilt body.

calls: [get_name](r4-compiler-node-model.md#u-99af92983a86)

**Uncertainties.**

- Fields with other kinds (e.g. a public `$derived` declared with a non-private key but field.node !== definition) are silently dropped; whether that case is reachable is not determinable here.

<a id="u-4790e3338b92"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/ConstTag.js:ConstTag`

`export function ConstTag(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/ConstTag.js:L10-L16][f6]

Hoists {@const} declarations into component init code: the declaration's id and init are visited and pushed as a `const` statement onto context.state.init, so the binding is computed once when the component renders rather than inline in the template.

<a id="u-20d147d776e2"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/HtmlTag.js:HtmlTag`

`export function HtmlTag(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/HtmlTag.js:L10-L13][f7]

Appends a `{@html ...}` tag as a `$.html(visitedExpression)` call to the template, leaving unescaped injection handling to the runtime helper.

<a id="u-98ec092cab2d"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/IfBlock.js:IfBlock`

`export function IfBlock(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/IfBlock.js:L12-L29][f8]

Compiles an {#if} block to a server-side conditional.

The test and both branches are visited; a missing else becomes an empty block. Hydration markers are prepended: the consequent starts with block_open, the alternate with a BLOCK_OPEN_ELSE literal, both pushed via `$$payload.out.push`. The resulting if statement plus block_close are appended to the template.

<a id="u-b3e492375e5d"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/KeyBlock.js:KeyBlock`

`export function KeyBlock(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/KeyBlock.js:L10-L16][f9]

Wraps a {@key} block's visited fragment between two empty comments in the template, serving as hydration boundary markers without any runtime logic.

<a id="u-d7255cb91ee9"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/RenderTag.js:RenderTag`

`export function RenderTag(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/RenderTag.js:L12-L35][f10]

Compiles a {@render} tag into a call to the snippet function with `$$payload` plus visited arguments.

The callee and arguments are unwrapped from optional chaining via unwrap_optional. A plain CallExpression uses b.call; an optional-chain form uses b.maybe_call so the render is skipped when the callee is nullish. An empty_comment is appended unless hydration boundaries are currently skipped.

calls: [unwrap_optional](r4-compiler-ast-utils.md#u-aa95700b7c80)

<a id="u-b3ca2606d7a1"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/SpreadAttribute.js:SpreadAttribute`

`export function SpreadAttribute(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/SpreadAttribute.js:L8-L10][f11]

Returns the transformed spread attribute expression by visiting node.expression; no other handling.

<a id="u-c2a9e301270e"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/SvelteBoundary.js:SvelteBoundary`

`export function SvelteBoundary(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/SvelteBoundary.js:L12-L38][f12]

Renders a <svelte:boundary> on the server by bracketing output with BLOCK_OPEN/BLOCK_CLOSE literals.

The pending content is chosen by priority: a `pending` attribute (whose value is built via build_attribute_value and called with `$$payload`) wins; otherwise a `pending`-named SnippetBlock in the fragment has its body visited inline; otherwise the whole fragment is visited. Error boundary behavior itself is a client/runtime concern not present here.

calls: [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/utils.js:build_attribute_value](r2-server-transform.md#u-8ce176223a22)

<a id="u-9e86d472de3c"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/SvelteHead.js:SvelteHead`

`export function SvelteHead(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/SvelteHead.js:L10-L16][f13]

Renders <svelte:head> content by visiting its fragment and emitting a `$.head($$payload, ($$payload) => block)` statement, so head content renders through the runtime helper with its own payload context.

<a id="u-4fbc61d80839"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/UpdateExpression.js:UpdateExpression`

`export function UpdateExpression(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/UpdateExpression.js:L9-L26][f14]

Rewrites `++`/`--` on store subscriptions: when the argument is an identifier bound as a `store_sub`, it emits `$.update_store_pre` (prefix) or `$.update_store` (postfix) with a `$$store_subs ??= {}` bookkeeping object, the original `$`-prefixed name literal, the de-prefixed store identifier, and `-1` only for `--` (undefined for `++`).

All other update expressions continue via context.next().

<a id="u-078e279d2ab5"></a>
### `server-types-d-ts`

`export interface ServerTransformState extends TransformState` · [packages/svelte/src/compiler/phases/3-transform/server/types.d.ts:L6-L9][f15]

Type declarations for the server transform.

ServerTransformState extends TransformState with a readonly legacy_reactive_statements Map (LabeledStatement to Statement) for $: blocks. ComponentServerTransformState extends it with the component analysis, validated options, init statement list, hoisted statements/imports, the SSR template statement list, namespace, preserve_whitespace, and skip_hydration_boundaries flags. Context/Visitors alias zimmerframe context/visitor types over ServerTransformState; ComponentContext/ComponentVisitors do the same over ComponentServerTransformState.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/transform-server.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/AssignmentExpression.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/AwaitBlock.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/AwaitExpression.js
[f5]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/ClassBody.js
[f6]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/ConstTag.js
[f7]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/HtmlTag.js
[f8]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/IfBlock.js
[f9]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/KeyBlock.js
[f10]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/RenderTag.js
[f11]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/SpreadAttribute.js
[f12]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/SvelteBoundary.js
[f13]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/SvelteHead.js
[f14]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/UpdateExpression.js
[f15]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/types.d.ts
