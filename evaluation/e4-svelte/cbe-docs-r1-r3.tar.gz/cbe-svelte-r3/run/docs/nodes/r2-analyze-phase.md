# Template Analysis

**Capability.** The phase-2 visitor set: per-node-type validation and metadata computation, plus the shared attribute validators (attribute shape, attribute names, slot placement) reused by multiple visitors.

Each visitor validates one template construct — await/key blocks, call-expression rune placement, imports, style directives, special elements, text. The shared attribute validators under visitors/shared are the cross-visitor helpers. Use this subtree for compile-time diagnostics about template correctness.

**Depends on.**

- [Compiler Foundations](r2-compiler-foundations.md) · graph-confirmed · 1 edge(s) · analysis visitors import error/warning factories and use extract_svelte_ignore from the shared compiler foundations.
- [CSS Analysis](r2-css-analyze.md) · model-inferred · 0 edge(s)

**Depended on by.**

- [Client Transform](r2-client-transform.md) · model-inferred · 0 edge(s)

Parent: [Svelte Compiler](r2-compiler.md)

## Units (17)

<a id="u-e78635f9b260"></a>
### `packages/svelte/src/compiler/phases/2-analyze/visitors/AwaitBlock.js:AwaitBlock`

`export function AwaitBlock(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/AwaitBlock.js:L11-L48][f1]

Analyzes {#await} blocks: validates that pending, then, and catch branches are non-empty via validate_block_not_empty.

In runes mode it validates the '#' opening tag, then scans the raw source 10 characters before the value/error start positions for `{:then`/`{:catch` patterns; if the whitespace group is non-empty it raises block_unexpected_character with a computed source range containing ':'. It marks the subtree dynamic, visits the expression with its metadata as the expression state, then visits each present branch unconditionally.

calls: [validate_block_not_empty](r4-analyze-shared-validation.md#u-b877c3a87dc5), [validate_opening_tag](r4-analyze-shared-validation.md#u-8a95b3b7e6dc), [mark_subtree_dynamic](r1-analysis-visitors.md#u-3e6e9a44c2b4)

**Uncertainties.**

- The substring window of 10 characters is a positional heuristic; unusual spacing beyond 10 chars before the value start may not match and silently skip the check.

<a id="u-d254c72e4204"></a>
### `CallExpression`

`export function CallExpression(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/CallExpression.js:L16-L266][f2]

Analyzes call expressions, distinguishing runes from normal calls and enforcing placement/argument rules per rune.

Any non-$inspect rune rejects SpreadElement arguments. For non-rune callees that are not safe identifiers, analysis.needs_context is set. Rune-specific checks: $bindable only at the root of a $props destructure default; $host takes no arguments and only in instance/custom-element mode; $props and $props.id are unique, instance-scope VariableDeclarators (the latter storing the props id in analysis); $state/$state.raw/$derived/$derived.by must appear in variable declarations, non-static non-computed class property definitions, or this.x assignments at a constructor's root (checked via is_class_property_assignment_at_constructor_root), with derived requiring exactly one argument and state zero or one; $effect/$effect.pre must be expression statements with one argument and force needs_context; $effect.tracking/$effect.root/$state.snapshot/$inspect/$inspect().with enforce exact argument counts; $effect.pending flags expression state; $inspect.trace requires first statement of a function body, rejects generators, and in dev mode stores a tracing thunk on the scope (either the given argument or an auto-generated label via get_function_label). Traversal: $derived and $inspect recurse with increased function_depth (derived also collects expressions with await into analysis.async_deriveds); afterwards, if an expression context exists, non-pure callees or any dependencies mark has_call/has_state.

**Notes.**

- side_effect: Mutates analysis state flags: needs_context, has_props_rune, props_id, async_deriveds, tracing, and scope.tracing.

calls: [get_rune](r4-compiler-scope.md#u-5204b6ce4f7a), [is_pure](r4-analyze-shared-validation.md#u-c8c562a3fb44), [create_expression_metadata](r4-compiler-node-model.md#u-32bbb434f744)

<a id="u-3ee893476e43"></a>
### `get_function_label`

`function get_function_label(nodes)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/CallExpression.js:L271-L294][f2]

Produces a human-readable label for a function node for use in $inspect.trace diagnostics: a named function's identifier, otherwise the callee source text plus '(...)' when directly inside a call, a non-computed property key name, or a variable declarator's name; returns undefined for other parents.

<a id="u-827e3436e5f6"></a>
### `is_class_property_assignment_at_constructor_root`

`function is_class_property_assignment_at_constructor_root(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/CallExpression.js:L315-L331][f2]

Returns true when the node is a plain '=' AssignmentExpression whose left side is a this.X / this.#x / this['x'] member on ThisExpression, and exactly five levels up (AssignmentExpression → ExpressionStatement → BlockStatement → FunctionExpression → MethodDefinition) sits a constructor MethodDefinition — the only allowed location for this-assigned class state outside property definitions.

calls: [get_parent](r4-compiler-ast-utils.md#u-427249cf438e)

<a id="u-8c7c8294d17e"></a>
### `is_class_property_definition`

`function is_class_property_definition(parent)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/CallExpression.js:L307-L309][f2]

Returns true when the parent is a PropertyDefinition that is neither static nor computed, another accepted placement for state runes.

<a id="u-83f04c95344f"></a>
### `is_variable_declaration`

`function is_variable_declaration(parent, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/CallExpression.js:L300-L302][f2]

Returns true when the given parent node is a VariableDeclarator that is not the child of a {#const} tag (checked three levels up the path), determining valid $state/$derived placement.

calls: [get_parent](r4-compiler-ast-utils.md#u-427249cf438e)

<a id="u-a9fa7ba9eca6"></a>
### `packages/svelte/src/compiler/phases/2-analyze/visitors/ImportDeclaration.js:ImportDeclaration`

`export function ImportDeclaration(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/ImportDeclaration.js:L9-L31][f3]

Analyzes import declarations in runes mode only.

Any source starting with 'svelte/internal' raises import_svelte_internal_forbidden. From the bare 'svelte' module, importing beforeUpdate or afterUpdate raises runes_mode_invalid_legacy_application (runes_mode_invalid_import) naming the specifier. No child visiting is performed.

**Uncertainties.**

- The 'svelte/internal' prefix check also matches subpath imports like 'svelte/internal/client'; whether all such subpaths are truly forbidden is decided by the error itself.

<a id="u-9898e6a37ff8"></a>
### `packages/svelte/src/compiler/phases/2-analyze/visitors/KeyBlock.js:KeyBlock`

`export function KeyBlock(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/KeyBlock.js:L10-L21][f4]

Analyzes a {#key} block: first raises an error if the block is empty via validate_block_not_empty, then in runes mode validates the opening tag with '#'.

It marks the subtree dynamic, and visits the key expression and the fragment explicitly — the expression with state.expression set to the block's metadata.expression so call/state tracking applies to the key value.

calls: [validate_block_not_empty](r4-analyze-shared-validation.md#u-b877c3a87dc5), [validate_opening_tag](r4-analyze-shared-validation.md#u-8a95b3b7e6dc), [mark_subtree_dynamic](r1-analysis-visitors.md#u-3e6e9a44c2b4)

<a id="u-e9c21a24251a"></a>
### `StyleDirective`

`export function StyleDirective(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/StyleDirective.js:L11-L38][f5]

Analyzes style: directives.

More than one modifier, or any modifier other than a single 'important', throws style_directive_invalid_modifier. It marks the subtree dynamic. For the shorthand form (value === true) it looks up the directive-name binding and flags the directive's expression metadata as stateful when the binding is not 'normal'. Otherwise it visits the value and then merges each contained ExpressionTag's metadata into the directive's: has_state, has_call, and has_await are OR-ed in.

**Uncertainties.**

- For the shorthand form only has_state is set; has_call/has_await are not derived for it, and whether shorthand binds (implying state) matches all use cases is not verifiable here.

<a id="u-51de6fed2f32"></a>
### `packages/svelte/src/compiler/phases/2-analyze/visitors/SvelteDocument.js:SvelteDocument`

`export function SvelteDocument(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/SvelteDocument.js:L11-L24][f6]

Analyzes <svelte:document>.

It first applies disallow_children, then rejects every attribute that is a spread or a non-event Attribute with illegal_element_attribute naming 'svelte:document' — only on: handlers are permitted. Continues with context.next().

calls: [disallow_children](r1-analysis-visitors.md#u-43b79d8932ce)

<a id="u-bff097b6510d"></a>
### `packages/svelte/src/compiler/phases/2-analyze/visitors/SvelteFragment.js:SvelteFragment`

`export function SvelteFragment(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/SvelteFragment.js:L10-L27][f7]

Analyzes <svelte:fragment>.

The grandparent must be a Component or SvelteComponent, else svelte_fragment_invalid_placement. Attributes: a `slot` Attribute is validated via validate_slot_attribute; anything other than an Attribute or a let: directive throws svelte_fragment_invalid_attribute. Continues visiting children with parent_element cleared so inner content checks treat the fragment as a namespace boundary.

calls: [validate_slot_attribute](r2-analyze-phase.md#u-be5b4cd34d6a)

<a id="u-bba0e211168d"></a>
### `Text`

`export function Text(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/Text.js:L13-L52][f8]

Analyzes text nodes.

Non-whitespace text directly inside a Fragment under a known parent element is checked against the HTML content model via is_tag_valid_with_parent('#text', parent_element), throwing node_invalid_placement on failure. Every Unicode bidirectional control character in the text warns bidirectional_control_characters with absolute source positions, unless an earlier svelte-ignore comment within the same Fragment (comments before this node are scanned, offset by 4 for '<!--') suppresses 'bidirectional_control_characters'; the shared regex's lastIndex is reset before matching. No child visiting — text has none.

calls: [is_tag_valid_with_parent](r4-shared-source-utilities.md#u-a93dfa56dc6d), [extract_svelte_ignore](r2-compiler-foundations.md#u-4a9ee4fb9b67); uses: [Text.js module code (L1–L12)][f8]

**Uncertainties.**

- svelte-ignore is only honored from comments earlier in the same Fragment; ignores on parent elements/blocks are handled elsewhere per the comment.
- match.index is assumed non-null by `match.index + node.start`; a null index would coerce, which the code does not guard.

<a id="u-2cf9a3a61dc0"></a>
### `attribute-js-shared-attribute-validators`

`group` · [packages/svelte/src/compiler/phases/2-analyze/visitors/shared/attribute.js:L1-L11][f9]

Module scaffolding of attribute.js: JSDoc type imports for AST and Context plus runtime imports of errors, warnings, ast utilities, nodes helpers, and the whitespace-only regex.

No behavior of its own; the imported symbols are used by the validators documented in their own units.

group: [validate_attribute_name](r2-analyze-phase.md#u-c4e14f91c1c8)

<a id="u-001c69caf1f6"></a>
### `validate_attribute`

`export function validate_attribute(attribute, parent)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/shared/attribute.js:L27-L49][f9]

Validates attribute value shape for a component or element attribute, warning about quoted single expressions and rejecting unquoted multi-part values.

If the value is a single ExpressionTag and the parent is a Component, SvelteComponent, SvelteSelf, or a RegularElement that is a custom element, it warns attribute_quoted. It returns early when the value is a shorthand boolean (true), not an array, or has exactly one part. Otherwise it determines quoting by comparing the last part's end offset with the attribute's end: if they differ, the value was quoted and any sequence is allowed; if they match (unquoted), it raises the attribute_unquoted_sequence error, so quoted attributes permit sequence expressions while unquoted ones do not.

**Notes.**

- failure: attribute_unquoted_sequence is a thrown error, stopping analysis for that attribute; attribute_quoted is only a warning.

calls: [is_custom_element_node](r4-compiler-node-model.md#u-ea1f0b51e1e8)

**Uncertainties.**

- The is_quoted heuristic (last part end vs attribute end) is inferred from offsets; exact parser guarantees about attribute.end are not visible here.

<a id="u-c4e14f91c1c8"></a>
### `validate_attribute_name`

`export function validate_attribute_name(attribute)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/shared/attribute.js:L12-L21][f9]

Warns when an attribute name contains a colon that suggests a namespace but is not a recognized XML namespace prefix.

If the name includes ':' and does not start with 'xmlns:', 'xlink:', or 'xml:', it emits the attribute_illegal_colon warning; otherwise it does nothing. It always returns normally and has no side effects beyond the warning.

<a id="u-be5b4cd34d6a"></a>
### `validate_slot_attribute`

`export function validate_slot_attribute(context, attribute, is_component = false)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/shared/attribute.js:L56-L125][f9]

Validates a slot="..." attribute against its enclosing component or element, enforcing placement, uniqueness, and default-slot content rules.

If the immediate grandparent (path[-2]) is a SnippetBlock, the attribute must be a text attribute or slot_attribute_invalid is thrown, and validation ends. Otherwise it scans the whole context.path backwards for the nearest Component/SvelteComponent/SvelteSelf/SvelteElement/custom RegularElement ancestor as the owner. With a component owner: if the owner is not the direct parent, slot_attribute_invalid_placement is thrown unless is_component is true (component self-slot). If the owner is the direct parent, a non-text value throws slot_attribute_invalid; the slot name is added to context.state.component_slots, throwing slot_attribute_duplicate if already present. When the name is 'default', each child of the owner fragment must be whitespace text; RegularElement/SvelteFragment children that themselves carry a slot attribute are skipped; anything else triggers slot_default_duplicate. Without any owner, slot_attribute_invalid_placement is thrown unless is_component is true. The owner search loop never breaks after finding an owner, so it continues scanning the remaining path (harmless since owner is only set once).

calls: [is_custom_element_node](r4-compiler-node-model.md#u-ea1f0b51e1e8), [ast-js-attribute-helpers](r4-compiler-ast-utils.md#u-e05972fa52ab)

**Uncertainties.**

- Whether is_component=true corresponds to component-slot usage in all callers cannot be verified from this file (graph shows SvelteFragment passes it).

<a id="u-6eb6e10ad8e7"></a>
### `regular-element-visitor`

`export function RegularElement(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/RegularElement.js:L20-L89][f10]

Covers the RegularElement visitor and its nested is_svg_element helper: validation of element placement and content, metadata computation, and namespace/placement diagnostics.

The visitor first runs validate_element and a11y check_element, records the node's path and adds it to analysis.elements. It performs two content rewrites: a textarea with dynamic children (more than one node or a non-Text first node) errors if a value attribute already exists, otherwise moves all children into a synthetic value attribute, stripping a leading newline from the first text node because browsers ignore it via innerHTML but not via the value property; an option whose sole child is an ExpressionTag without a value attribute gains a fake value attribute so value types stay consistent. An unused lowercase import binding warns component_name_lowercase. has_spread is derived from SpreadAttributes. The nested is_svg_element returns true for known svg tag names, and for a/title walks the path to the nearest RegularElement ancestor and uses its metadata.svg; the result and is_mathml are stored in metadata, and custom elements with attributes mark the subtree dynamic (attributes go through properties). When state.parent_element is set, it walks ancestors: crossing IfBlock/EachBlock/AwaitBlock/KeyBlock downgrades errors to warnings (separate SSR template); after the matching parent element it validates tag-vs-parent and tag-vs-ancestor-chain rules, stopping at component/svelte/snippet boundaries. Self-closing syntax on non-void, non-svg, non-mathml tags (namespace stripped from the name first) warns. After recursion it sets parent_element to this node's name, and for an <a> with no parent element it inspects children to fix metadata.svg (an <a> is valid in both namespaces).

calls: [check_element](r1-a11y-checks.md#u-0f7a175a707e), [validate_element](r5-analyze-visitors.md#u-7d4fa5b13c15), [create_attribute](r4-compiler-node-model.md#u-16d11cbbd59b), [is_tag_valid_with_parent](r4-shared-source-utilities.md#u-a93dfa56dc6d), [is_tag_valid_with_ancestor](r4-shared-source-utilities.md#u-c5a7f2f803ff)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/AwaitBlock.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/CallExpression.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/ImportDeclaration.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/KeyBlock.js
[f5]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/StyleDirective.js
[f6]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/SvelteDocument.js
[f7]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/SvelteFragment.js
[f8]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/Text.js
[f9]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/shared/attribute.js
[f10]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/RegularElement.js
