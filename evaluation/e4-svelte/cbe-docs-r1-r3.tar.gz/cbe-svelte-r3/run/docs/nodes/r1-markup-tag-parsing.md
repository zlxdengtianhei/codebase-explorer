# Markup & Attribute Parsing

**Capability.** Parses one tag (comment, closing tag, or opening element) at the parser position and its attributes/directives; classifies colon-prefixed names into directive types, reads interleaved text/expression sequences, and uses stack predicates for svelte:head and declarative shadow-DOM contexts.

Trace how `<div bind:x={y}>` becomes AST by starting at element and following read_attribute/read_attribute_value. read_sequence covers text-interleaved values. This node consumes expression reading and entity decoding siblings.

**Depends on.**

- [HTML Entity Decoding](r1-html-entity-decoding.md) · graph-confirmed · 2 edge(s)
- [Expression & Script Reading](r1-script-expression-parsing.md) · graph-confirmed · 4 edge(s)
- [Node Factories and Metadata Model](r4-compiler-node-model.md) · graph-only · 11 edge(s)

Parent: [Parse Phase](r1-compiler-parse.md)

## Units (8)

<a id="u-bc08cb4e57fa"></a>
### `element`

`export default function element(parser)` · [packages/svelte/src/compiler/phases/1-parse/state/element.js:L52-L411][f1]

Parses one tag (comment, closing tag, or opening element) at the current parser position and appends the resulting node or pushes the element onto the parse stack.

For comments it reads until '-->' and appends a Comment. For closing tags it consumes '>', rejects void elements, then auto-closes enclosing elements whose tags do not match: in loose mode it can backtrack an attribute accidentally named `<name`; a RegularElement parent gets an implicit-close warning (suppressed if it was already auto-closed for the same tag), while a non-element parent errors unless it was auto-closed by this same tag name. After popping the matched parent it clears last_auto_closed_tag once the stack shrinks below its recorded depth. For opening tags it validates `svelte:` meta names, element/component names (allowing a trailing-dot name only in loose mode), and root-only meta placement/duplication; derives the node type from meta_tags, component-name syntax, `title` inside head, `slot` outside a shadowroot template, else RegularElement. It auto-closes an open parent when HTML omits closing tags, records last_auto_closed_tag, then reads attributes via read_static_attribute for top-level script/style or read_attribute otherwise, rejecting duplicates of Attribute/Bind/Style/Class directives by normalized name (except `this`). SvelteComponent and SvelteElement pull out their `this` attribute (missing/invalid cases error, except SvelteElement's invalid static value which warns and converts the first chunk to a literal or expression, preserving known-buggy Svelte 4 behavior). Top-level script/style are handled specially: read_script/read_style run, an immediately preceding HTML comment becomes a leading comment for warning suppression, and module/instance or css slots are filled once (duplicates error). Otherwise the element is appended; `/>` or void names leave it unstacked, a missing `>` in loose mode may backtrack a `<` attribute, `{/`, `{'`/`{`@`/`{:` prefixes, or trailing whitespace; `textarea` reads its children with read_sequence until the closing tag; non-top-level script/style read raw text until `</name>`; all others are pushed with their fragment.

**Notes.**

- side_effect: Mutates parser state: stack, fragments, index, last_auto_closed_tag, meta_tags, and Root slots (instance, module, css).
- failure: Error paths include void_element_invalid_content, svelte_meta_invalid_tag/duplicate/invalid_placement, tag_invalid_name, attribute_duplicate, script/style_duplicate, svelte_component/element missing or invalid this, element_invalid_closing_tag(_autoclosed), and delegated errors from attribute readers.

calls: [read_script](r1-script-expression-parsing.md#u-086699ac3458), [read_style](r2-css-parse.md#u-863125efdf39), [create_fragment](r4-compiler-parse.md#u-6f16c2773335), [is_element_node](r4-compiler-node-model.md#u-0d9a79ad394a), [ast-js-attribute-helpers](r4-compiler-ast-utils.md#u-e05972fa52ab), [closing_tag_omitted](r4-shared-source-utilities.md#u-10b29d40ea2b), [utils-js-predicates](r3-shared-utils.md#u-7eb274f609ad), [element.js-read-sequence](r1-markup-tag-parsing.md#u-4be2de550c18)

**Uncertainties.**

- Exact regex-driven behavior of parser.eat/read_until helpers is defined outside this file and not verifiable here.

<a id="u-2a4064013135"></a>
### `get_directive_type`

`function get_directive_type(name)` · [packages/svelte/src/compiler/phases/1-parse/state/element.js:L696-L706][f1]

Maps a colon prefix (`use`, `animate`, `bind`, `class`, `style`, `on`, `let`, `in`/`out`/`transition`) to its directive type string, returning false for anything else so the name is treated as a plain attribute.

<a id="u-b95f147540fd"></a>
### `parent_is_head`

`function parent_is_head(stack)` · [packages/svelte/src/compiler/phases/1-parse/state/element.js:L414-L422][f1]

Scans the parser stack from top down and returns true only if it reaches a SvelteHead node before any RegularElement or Component; otherwise returns false.

Used to decide whether a `title` becomes a TitleElement.

<a id="u-d1eed460e3e4"></a>
### `parent_is_shadowroot_template`

`function parent_is_shadowroot_template(stack)` · [packages/svelte/src/compiler/phases/1-parse/state/element.js:L425-L439][f1]

Scans the stack from top down and returns true if any enclosing RegularElement carries a plain attribute named `shadowrootmode`, marking a declarative-shadow-DOM template; `<slot>` inside such a template stays a RegularElement rather than a SlotElement.

**Uncertainties.**

- The attribute is matched only by name and type 'Attribute'; a directive or spread providing shadowrootmode would not be detected.

<a id="u-2c3fac35f2d5"></a>
### `read_attribute`

`function read_attribute(parser)` · [packages/svelte/src/compiler/phases/1-parse/state/element.js:L490-L690][f1]

Reads one attribute or directive of a regular element, returning null when no attribute starts here.

A leading `{` begins either an `{@attach expr}` AttachTag, `{...expr}` SpreadAttribute, or a `{name}` shorthand ExpressionTag attribute; in loose mode, `{#`, `{/`, `{@`, `{:` (likely a mis-read block) returns null so the tag can close, and `{}` mid-typing becomes an empty-name shorthand, otherwise empty shorthands error. Otherwise a name is read until a token-ending character. After optional whitespace, a `:` prefix maps via get_directive_type; a `=` value is read with read_attribute_value (a bare `/` before `>` becomes a single Text chunk '/'), and a quote with no '=' errors. Directives reject missing names and non-single-expression values; StyleDirective keeps a raw value; TransitionDirective sets intro/outro from the `in`/`out`/`transition` prefix; Bind/Class directives without an expression synthesize an Identifier from the directive name. Non-directives become create_attribute with value true or the parsed value.

calls: [read_expression](r1-script-expression-parsing.md#u-793d43872467), [create_attribute](r4-compiler-node-model.md#u-16d11cbbd59b), [get_directive_type](r1-markup-tag-parsing.md#u-2a4064013135); uses: [element.js-read-sequence](r1-markup-tag-parsing.md#u-4be2de550c18)

**Uncertainties.**

- Which directive kinds value validation applies to beyond StyleDirective depends on AST types not shown.

<a id="u-a913d60dcf82"></a>
### `packages/svelte/src/compiler/phases/1-parse/state/element.js:read_attribute_value`

`function read_attribute_value(parser)` · [packages/svelte/src/compiler/phases/1-parse/state/element.js:L712-L763][f1]

Reads an attribute value, optionally quote-delimited.

An immediately closed quote yields a single empty Text chunk. Otherwise read_sequence accumulates chunks until the matching quote or, unquoted, until an invalid character from regex_invalid_unquoted_attribute_value (whitespace, quotes, =, <, >, backtick, or `/>`). If an inner js_parse_error points at a `/>` (e.g. an unterminated construct before a self-closing tag), the position is checked and expected_token rethrows with the quote or '}' as the expected token; other errors propagate. An empty unquoted value errors with expected_attribute_value; the closing quote is consumed for quoted values. Returns the chunk array when quoted, multi-chunk, or text-leading, else the single ExpressionTag.

calls: [element.js-read-sequence](r1-markup-tag-parsing.md#u-4be2de550c18)

**Uncertainties.**

- error.position is an untyped property on the thrown error; its shape is assumed from usage.

<a id="u-73af677afe37"></a>
### `read_static_attribute`

`function read_static_attribute(parser)` · [packages/svelte/src/compiler/phases/1-parse/state/element.js:L445-L484][f1]

Reads a name=value attribute with text-only values for top-level script/style tags.

Returns null when no name characters are present. If '=' follows, optional whitespace is skipped and regex_attribute_value matches a double-quoted, single-quoted, or bare value; no match raises expected_attribute_value. Quoted raw values are stripped and a single Text chunk is produced with data run through decode_character_references(raw, true). A quote starting the next token without '=' raises expected_token. Returns create_attribute(name, start, end, value) where value is true when no '=' appeared.

calls: [decode_character_references](r1-html-entity-decoding.md#u-a03f13997ae5), [create_attribute](r4-compiler-node-model.md#u-16d11cbbd59b)

<a id="u-4be2de550c18"></a>
### `element.js-read-sequence`

`function read_sequence(parser, done, location)` · [packages/svelte/src/compiler/phases/1-parse/state/element.js:L771-L785][f1]

read_sequence accumulates interleaved text and `{expression}` chunks until a caller-supplied done() predicate fires, for attribute values and textarea contents.

Text is buffered into a running raw chunk; each `{` first rejects misplaced blocks (`{#name`) and tags (`{@name`) with block_invalid_placement/tag_invalid_placement, then reads an expression, requires `}`, and pushes an ExpressionTag, resetting the text buffer. flush() only emits the pending text chunk when its raw string is non-empty, decoding character references into data. On end-of-template, loose mode returns the chunks collected so far while strict mode raises unexpected_eof. The inner flush helper is an implementation detail of the sequence reader.

calls: [read_expression](r1-script-expression-parsing.md#u-793d43872467), [decode_character_references](r1-html-entity-decoding.md#u-a03f13997ae5)

**Uncertainties.**

- s0 (lines 771-785) and s1 (791-849) are two sections of one function; grouping assumes they are contiguous halves rather than independent symbols.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/1-parse/state/element.js
