# Migration Driver and Helpers

**Capability.** Runs the migrate pipeline (analyze, walk both scripts and template, migrate CSS) and owns the text-edit/error helpers: MigrationError, node ranges over comments, indentation guessing, parenthesis scanning, and :global CSS wrapping.

Start at grp:index-js-migrate to understand the rewrite flow. The helpers here are consumed by both the script and template visitor subtrees.

**Depends on.**

- [Analysis Driver](r3-analyze-driver.md) · graph-confirmed · 1 edge(s)

**Depended on by.**

- [Migration Script Visitors](r3-migrate-script-visitors.md) · model-inferred · 0 edge(s)
- [Migration Template Visitors](r3-migrate-template-visitors.md) · graph-confirmed · 1 edge(s)

Parent: [Svelte 4 to 5 Migration](r3-migration.md)

## Units (6)

<a id="u-50c4a7a5de79"></a>
### `index-js-migrate`

`export function migrate(source, { filename, use_ts } = {})` · [packages/svelte/src/compiler/migrate/index.js:L124-L275][f1]

Performs a best-effort Svelte 4 → Svelte 5 (runes, event attributes, snippets) migration of a source string and returns `{ code }`.

First it blanks `<style>` contents (storing them for restoration, since CSS may need a preprocessor), resets compiler state, parses the blanked source, and builds combined validated options (defaulting filename, forcing experimental async). It strips the `accessors` option from `<svelte:options>`, restores the style contents, and constructs a State carrying a MagicString, unique generated names (props, rest, run, handlers, and event-modifier helpers), insertion points, and a `uses_ts` flag true when the caller says TS and no JSDoc `@type {` exists, or when the instance script has `lang="ts"`. A `context` attribute on the module script is rewritten to `module`. It walks the instance script with `instance_script` and the template with `template`, then performs post-passes: if there is no instance script but legacy imports, derived components/slots, script insertions, props, $$props/$$restProps usage, or svelte:self exist, a new `<script>` (with `lang="ts"` when needed) is created; a self-import is added for svelte:self when a filename is known; `svelte/legacy` and accumulated script insertions are appended. The inner `check_rune_binding(rune)` throws a MigrationError when a variable named props/bindable/derived already exists and a `$<rune>` rune would have to be introduced. Props emission: when props, $$props, or $$restProps are used, it builds a `let { ... } = $props();` declaration — `...props` for $$props, `$bindable(init)` for bindable props, a rest spread for $$restProps — with types as a TS interface (plus `[key: string]: any` for rest/props) or a JSDoc `@typedef`/`@type`, only when types were detected or every prop is a slot; `check_rune_binding('props'/'bindable')` aborts on name conflicts, and `lang="ts"` is added to an existing script when needed. It then detects whether legacy reactive statements must be reordered (a dependency declared textually after the statement — props counting from the props insertion point — forces reordering); if so each reactive statement's range (including comments, via get_node_range) is moved to the end of the instance script. Derived components and conflicting-slot derivations are emitted as `const name = $derived(...)` (each guarded by check_rune_binding('derived')), accessors re-export non-slot, non-type-only props when `accessors` was set, a closing `</script>` is appended if a script was created, and migrate_css rewrites the CSS. On any thrown error: a non-MigrationError is logged with console.error, `has_migration_task` is set, and the original source is returned prefixed with an `<!-- @migration-task ... -->` comment containing the message; the finally block prints a console notice whenever migration-task comments were added.

**Notes.**

- failure: Any error, including MigrationError, converts the output to the untouched original source plus a @migration-task HTML comment; only non-MigrationError errors are additionally logged.
- side_effect: The module-level `has_migration_task` flag is reset at entry and set on failure, driving the finally-block console notice.

calls: [packages/svelte/src/compiler/phases/1-parse/index.js:parse](r5-compiler-parse.md#u-53ab5f2b9b37), [index-js-analyze-component](r3-analyze-driver.md#u-ff1515d9bcd2), [reset](r5-compiler-state-utils.md#u-0d9f0b886c2d), [extract_identifiers](r4-compiler-ast-utils.md#u-90eb95affc00), [get_node_range](r3-migrate-entry.md#u-7acff5a27531), [migrate_css](r3-migrate-entry.md#u-437d8a4fa38f); raises: [MigrationError](r3-migrate-entry.md#u-18abcf9a9523)

<a id="u-18abcf9a9523"></a>
### `MigrationError`

`class MigrationError extends Error` · [packages/svelte/src/compiler/migrate/index.js:L28-L32][f1]

A custom Error subclass that marks failures where automated migration is impossible.

Its constructor only forwards the message to Error, adding no state; its entire purpose is the type check in migrate's catch block, where a MigrationError is re-thrown as a migration-task comment without console noise, while any other error is additionally logged to the console.

uses: [index-js-migrate](r3-migrate-entry.md#u-50c4a7a5de79)

<a id="u-97593ff10930"></a>
### `find_closing_parenthesis`

`function find_closing_parenthesis(start, code)` · [packages/svelte/src/compiler/migrate/index.js:L102-L114][f1]

Scans `code` from index `start`, counting parentheses beginning at balance 1 (the caller has already consumed the open paren), and returns the index just past the character that balances the count.

It stops early at end-of-string, so an unbalanced input yields the string length rather than an error.

<a id="u-7acff5a27531"></a>
### `get_node_range`

`function get_node_range(source, node)` · [packages/svelte/src/compiler/migrate/index.js:L1818-L1841][f1]

Returns the source range of a labeled statement extended over its comments: the start becomes the first leading comment's start (with a documented @ts-expect-error because the Comment type lacks `start`) and the end the last trailing comment's end.

The start is then walked backwards over spaces and tabs until a line break so the range covers the whole line's indentation; if a non-whitespace character is met before a line break the original start is kept.

<a id="u-4cb15da8c8dc"></a>
### `guess_indent`

`function guess_indent(content)` · [packages/svelte/src/compiler/migrate/index.js:L1970-L1994][f1]

Guesses the file's indentation unit.

Lines starting with tabs and lines starting with two-or-more spaces are counted; with neither present it defaults to a tab. Tabs win on ties or when they are at least as common; otherwise the minimum leading-space count across spaced lines determines a `' '.repeat(min)` indent (treating a missing match as Infinity, which would only survive if every spaced line matched, in which case no minimum exists).

<a id="u-437d8a4fa38f"></a>
### `migrate_css`

`function migrate_css(state)` · [packages/svelte/src/compiler/migrate/index.js:L41-L96][f1]

Wraps arguments of :has/:is/:where pseudo-classes in :global(...) within the component's CSS, rewriting the style block in place.

It is a no-op when the analysis CSS AST has no start. Because the source CSS was blanked earlier, it snips the original CSS text and works on a separate MagicString copy, tracking offsets with `starting`; finally it updates the original range with the rewritten CSS. For each position: if the remaining code starts with :has/:is/:where/:not it finds the open paren; when the text up to the next :global is blank the selector is already global and the scanner skips past that :global block; otherwise it locates the existing :global block's closing parenthesis (via find_closing_parenthesis on the original css_contents) and, if that block ends after the current position, jumps past it without modification. For a non-global, non-:not pseudo-class with a found closing paren, it inserts ':global(' before the argument and ')' after the closing paren, then resumes scanning after it. If no closing parenthesis is found the scanner simply advances one character.

calls: [find_closing_parenthesis](r3-migrate-entry.md#u-97593ff10930)

**Uncertainties.**

- The scanning is string-based; interleavings of pseudo-classes and string literals inside CSS are handled only by the paren-counting heuristic and could produce odd edits, but no counterexample is provable from this source alone

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/migrate/index.js
