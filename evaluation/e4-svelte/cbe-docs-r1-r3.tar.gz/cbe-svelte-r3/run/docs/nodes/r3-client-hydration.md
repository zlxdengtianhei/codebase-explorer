# Client Hydration State

**Capability.** Module-level hydration cursor and comment-marker navigation: setting/advancing/resetting the cursor, reading hydration instructions, and removing server-rendered nodes up to end markers.

Every hydrating consumer (render, template, attributes, blocks) drives its work through these cursor helpers. Treat the cursor as ambient state during hydration.

**Depended on by.**

- [Client Attribute Application](r3-client-attributes.md) · graph-confirmed · 4 edge(s)
- [Client Control Blocks and CSS](r3-client-blocks.md) · graph-confirmed · 7 edge(s)
- [Client Render Lifecycle](r3-client-render.md) · graph-confirmed · 7 edge(s) · mount and hydrate drive their DOM work through the module-level hydration cursor helpers.
- [Client Template Factories](r3-client-template.md) · graph-confirmed · 3 edge(s)
- [DOM Template Blocks](r1-dom-blocks.md) · graph-only · 13 edge(s)
- [Each Block Runtime](r2-dom-blocks.md) · graph-only · 10 edge(s)
- [Runtime DOM Blocks](r4-runtime-dom-blocks.md) · graph-only · 9 edge(s)

Parent: [Client Runtime](r3-client-runtime.md)

## Units (6)

<a id="u-c504e0cdf2f3"></a>
### `hydration-js-state`

`export function set_hydrating(value)` · [packages/svelte/src/internal/client/dom/hydration.js:L20-L22][f1]

Small hydration-state helpers sharing module-level state.

set_hydrating toggles the `hydrating` flag that every hydration code path consults and that enables tree-shaking when hydration is unused. hydrate_next advances `hydrate_node` to its next sibling via set_hydrate_node, so a null sibling triggers the mismatch warning and HYDRATION_ERROR throw. hydrate_template, when hydrating, points `hydrate_node` at the template's content fragment (bypassing the TemplateNode type); when not hydrating it does nothing.

calls: [set_hydrate_node](r3-client-hydration.md#u-053b251d50dd)

<a id="u-94ad8aaab7d1"></a>
### `packages/svelte/src/internal/client/dom/hydration.js:next`

`export function next(count = 1)` · [packages/svelte/src/internal/client/dom/hydration.js:L70-L81][f1]

Advances the hydration cursor past `count` siblings, default 1.

No-op when not hydrating. Starting from `hydrate_node`, it repeatedly follows get_next_sibling; each step's result is cast to TemplateNode without a null check, so a short document would leave the cursor null (differing from set_hydrate_node, which errors on null). Assigns the final node back to `hydrate_node`.

**Uncertainties.**

- No mismatch warning or error is raised if siblings run out mid-walk; behavior then depends on later consumers of a null cursor.

<a id="u-97280e054ad7"></a>
### `read_hydration_instruction`

`export function read_hydration_instruction(node)` · [packages/svelte/src/internal/client/dom/hydration.js:L112-L119][f1]

Reads the instruction string from a hydration comment node.

If the node is falsy or not a comment node it warns with hydration_mismatch and throws HYDRATION_ERROR; otherwise it returns the comment's data.

<a id="u-fc45567d72a4"></a>
### `remove_nodes`

`export function remove_nodes()` · [packages/svelte/src/internal/client/dom/hydration.js:L86-L106][f1]

Removes server-rendered DOM from the current `hydrate_node` up to the matching hydration end comment, and returns that end comment.

Tracks nesting depth: a HYDRATION_START or HYDRATION_START_ELSE comment increments depth; a HYDRATION_END comment returns immediately at depth 0, otherwise decrements. Every non-matching node is removed from the DOM and the walk continues to its next sibling via get_next_sibling.

**Uncertainties.**

- If no matching end comment exists the loop would eventually hit a null next sibling; no explicit guard is present in this function.

<a id="u-0157ee2cbd38"></a>
### `packages/svelte/src/internal/client/dom/hydration.js:reset`

`export function reset(node)` · [packages/svelte/src/internal/client/dom/hydration.js:L48-L58][f1]

Resets the hydration cursor to a given anchor when leaving a block.

If not hydrating it returns immediately. Otherwise, if the current `hydrate_node` still has a next sibling, the server HTML does not match the component boundary: it warns via hydration_mismatch and throws HYDRATION_ERROR. On success it reassigns `hydrate_node` to the passed node.

<a id="u-053b251d50dd"></a>
### `set_hydrate_node`

`export function set_hydrate_node(node)` · [packages/svelte/src/internal/client/dom/hydration.js:L34-L41][f1]

Sets the module-level `hydrate_node` cursor to the given node.

If the node is null it signals a hydration mismatch: it emits the hydration_mismatch warning and throws the HYDRATION_ERROR sentinel rather than assigning. Otherwise it assigns the node and returns it.

**Notes.**

- failure: A null argument is treated as a hard error: warning plus throw of HYDRATION_ERROR; `hydrate_node` is left unchanged.

**Uncertainties.**

- HYDRATION_ERROR's value and how callers match on it are defined outside this file.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/hydration.js
