# Shared Runtime Utilities

**Capability.** Runtime utilities shared by client and server: deep state snapshotting ($state.snapshot) with its behavior test suite, small general-purpose helpers including destructuring-safe to_array, and generated console.warn helpers for non-fatal runtime issues.

Treat as leaf infrastructure: snapshot is consumed by dev logging and public API, and the small helpers are called from scheduling, blocks, and legacy lifecycle code.

**Depended on by.**

- [Dev Diagnostics & HMR](r1-client-dev-diagnostics.md) · graph-confirmed · 1 edge(s) · state-aware console logging snapshots values via the shared $state.snapshot helper.
- [DOM Template Blocks](r1-dom-blocks.md) · graph-confirmed · 2 edge(s)
- [Task Scheduling](r1-task-scheduling.md) · graph-confirmed · 2 edge(s)

Parent: [Svelte Repository](r1-svelte-monorepo.md)

## Units (6)

<a id="u-bfcc537be9f1"></a>
### `packages/svelte/src/internal/shared/clone.js:snapshot`

`export function snapshot(value, skip_warning = false, no_tojson = false)` · [packages/svelte/src/internal/shared/clone.js:L21-L45][f1]

Public $state.snapshot implementation producing a deep plain-data copy of reactive state.

In dev with warnings enabled it clones while collecting the paths of uncloneable properties and then warns via w.state_snapshot_uncloneable: a lone '' path means the whole value was uncloneable; otherwise the first 7 paths (when there are more than 10) or the first 10 are listed as '- <value>...' lines with an '...and N more' excess note. In production, or when skip_warning is true, it clones against a shared dummy path array so failures are never recorded. no_tojson suppresses toJSON-based cloning in all cases.

calls: [clone](r1-shared-runtime.md#u-97cc45d9b173); uses: [warnings.js-console-warners](r1-shared-runtime.md#u-977b55ca7478)

<a id="u-97cc45d9b173"></a>
### `clone`

`function clone(value, cloned, path, paths, original = null, no_tojson = false)` · [packages/svelte/src/internal/shared/clone.js:L57-L137][f1]

Internal recursive deep-clone producing plain snapshots while preserving structure.

For objects it first returns any existing clone from the cloned Map, which breaks cycles. Map and Set instances are shallow-copied via new Map(value)/new Set(value). Arrays become same-length arrays with only present indices (`i in value`) recursively cloned; objects whose prototype is Object.prototype become {} with all enumerable keys cloned. When original is supplied (the instance behind a toJSON result), it is registered in the cloned Map so the instance and its JSON form share one snapshot. In dev, recursive calls receive dotted/bracketed paths ('path[i]', 'path.key') that land in paths on failure; production passes a constant path. Dates go through structuredClone directly; objects with a function-valued toJSON (unless no_tojson) are replaced by the clone of their toJSON() output. EventTargets are returned as-is, and any structuredClone rejection is caught: in dev the path is pushed to paths and the original value returned; no exception propagates. Non-objects are cloned via structuredClone.

**Notes.**

- side_effect: The cloned Map accumulates value→copy pairs across the whole recursion, including toJSON source instances

**Uncertainties.**

- Object subclass instances with non-Object prototypes lacking toJSON fall through to structuredClone; rejection depends on runtime structuredClone behavior

<a id="u-19c34b4624f2"></a>
### `clone.test.ts-snapshot-suite`

`function capture_warnings()` · [packages/svelte/src/internal/shared/clone.test.ts:L5-L19][f2]

Vitest suite validating snapshot's cloning and dev-warning behavior.

capture_warnings swaps console.warn for a collector and returns a restore thunk yielding the collected messages. Tests cover primitives, arrays and plain objects (deep-equal but not identical copies), proxied state (copies are decoupled from later mutations), cyclic references (copy.self === copy), class instances with private fields (only own fields like x survive, getter-backed #y is dropped), toJSON classes (snapshot reflects the toJSON output), a Map subclass (copy is a plain Map, not the subclass), and uncloneable values: a function snapshot returns the original and emits the whole-value warning, objects with function properties emit one warning line per uncloneable path (.a, .b, .c[0..7]), and a 100-element array of functions is truncated to seven listed paths plus '...and 93 more'. Members listed below are local fixture classes/functions explained by this suite; the asserted warning texts come from w.state_snapshot_uncloneable's dev format.

<a id="u-aa0ed6112e71"></a>
### `utils.js-small-helpers`

`export function is_function(thing)` · [packages/svelte/src/internal/shared/utils.js:L19-L21][f3]

Small shared utilities.

The header caches references to Array/Object globals (is_array, index_of, array_from, object_keys, define_property, get_descriptor, get_descriptors, object_prototype, array_prototype, get_prototype_of, is_extensible) so monkey-patching the globals cannot de-opt these helpers. is_function checks typeof === 'function'; is_promise is true when value?.then is a function (thenable check, not instanceof Promise); run invokes fn and returns its result; run_all invokes each zero-arg callback in arr in order, with any thrown error propagating and aborting the loop; noop is an empty arrow function; deferred hand-rolls Promise.withResolvers, returning {promise, resolve, reject} from a single executor capture; fallback returns value unless it is exactly undefined, in which case it returns the fallback value or, when lazy is true, calls fallback as a zero-arg function and returns its result.

<a id="u-c7d546e409e1"></a>
### `to_array`

`export function to_array(value, n)` · [packages/svelte/src/internal/shared/utils.js:L94-L118][f3]

Normalizes a destructuring source into an array, guarding against unbounded iterables.

Arrays are returned unchanged (same reference). If n is unspecified — indicating a rest element, where unbounded iterables are acceptable — or the value lacks Symbol.iterator, it converts with Array.from. Otherwise it iterates the value, pushing elements into a fresh array and breaking exactly when the array reaches length n, so only n values are pulled from a possibly infinite iterable.

<a id="u-977b55ca7478"></a>
### `warnings.js-console-warners`

`export function dynamic_void_element_content(tag)` · [packages/svelte/src/internal/shared/warnings.js:L12-L18][f4]

Generated warning helpers that report non-fatal issues via console.warn.

Both follow the same pattern: in dev (DEV from esm-env) they emit a styled message — '%c[svelte] <code>\n%c<description>\n<doc url>' with bold/normal font-weight arguments; in production they emit only the doc URL. dynamic_void_element_content warns that <svelte:element this="tag"> is a void element and cannot have content. state_snapshot_uncloneable takes an optional properties string: when provided it lists the uncloneable property paths after 'The following properties cannot be cloned... — the return value contains the originals:', otherwise it states that the whole value could not be cloned and the original was returned. Both return normally; nothing is thrown.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/shared/clone.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/shared/clone.test.ts
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/shared/utils.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/shared/warnings.js
