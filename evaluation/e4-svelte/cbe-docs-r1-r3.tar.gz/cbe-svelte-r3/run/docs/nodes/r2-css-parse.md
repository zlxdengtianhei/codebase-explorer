# CSS Parsing

**Capability.** Recursive-descent parser for style element bodies: rules, at-rules, blocks, declarations, selector lists, combinators, identifiers, and values, producing the stylesheet AST.

read_style is the entry point; the read_* functions form the recursion read_body → rule/block → selector/declaration. Use this subtree when fixing selector-syntax acceptance or error positions. Throwing behavior on unterminated constructs goes through parser.eat.

**Depended on by.**

- [CSS Analysis](r2-css-analyze.md) · model-inferred · 0 edge(s)

Parent: [CSS Pipeline](r2-css-pipeline.md)

## Units (14)

<a id="u-863125efdf39"></a>
### `read_style`

`export default function read_style(parser, start, attributes)` · [packages/svelte/src/compiler/phases/1-parse/read/style.js:L25-L45][f1]

Entry point for `<style>` content: reads a body of rules until the literal `</style`, then consumes the closing tag (regex allows trailing whitespace) and returns a StyleSheet node whose `content.styles` is the raw template slice between content_start and content_end, with comment initialized to null.

calls: [read_body](r2-css-parse.md#u-755ffe99e59c)

<a id="u-755ffe99e59c"></a>
### `read_body`

`function read_body(parser, close)` · [packages/svelte/src/compiler/phases/1-parse/read/style.js:L52-L71][f1]

Repeatedly skips comments/whitespace, then reads either an at-rule (when '@' matches) or a rule, accumulating children, until the close string (e.g. '</style') matches or the template ends.

Reaching end-of-template without the close throws e.expected_token.

calls: [read_at_rule](r2-css-parse.md#u-f5e645353a7a), [read_rule](r2-css-parse.md#u-7fd5dca44ce4), [allow_comment_or_whitespace](r2-css-parse.md#u-131239fcb755)

<a id="u-7fd5dca44ce4"></a>
### `read_rule`

`function read_rule(parser)` · [packages/svelte/src/compiler/phases/1-parse/read/style.js:L110-L126][f1]

Parses a normal CSS rule: a selector list followed by a block, returned as a Rule node with fresh metadata (parent_rule null, has_local_selectors/has_global_selectors/is_global_block all false).

calls: [read_selector_list](r2-css-parse.md#u-00c76aa683fd), [read_block](r2-css-parse.md#u-f9ccd7c79c86)

<a id="u-00c76aa683fd"></a>
### `read_selector_list`

`function read_selector_list(parser, inside_pseudo_class = false)` · [packages/svelte/src/compiler/phases/1-parse/read/style.js:L133-L162][f1]

Parses a comma-separated list of complex selectors.

After initial comment/whitespace skipping, it repeatedly reads a selector, records the end, skips comments/whitespace, and returns a SelectorList when the terminator matches — ')' when inside a pseudo-class, otherwise '{'. If the terminator has not been reached, a ',' is required (parser.eat throws otherwise) and parsing continues. Running off the end of the template throws e.unexpected_eof.

calls: [read-style-read-selector](r2-css-parse.md#u-7d8849d82c6d), [allow_comment_or_whitespace](r2-css-parse.md#u-131239fcb755)

<a id="u-7d8849d82c6d"></a>
### `read-style-read-selector`

`function read_selector(parser, inside_pseudo_class = false)` · [packages/svelte/src/compiler/phases/1-parse/read/style.js:L169-L180][f1]

Parses one complex selector as an ordered list of RelativeSelectors joined by combinators.

The inner create_selector builds a fresh RelativeSelector with end -1 and neutral metadata. The main loop dispatches on the next token: '&' (NestingSelector), '*|name' (namespace ignored), '#name', '.name', '::name' (pseudo-element; a parenthesized argument list is parsed only to validate syntax and discarded), ':name' with optional parsed selector-list args (PseudoClassSelector), '[name matcher? value? flags?]' attribute selector, Nth (only inside pseudo-classes and matched before the combinator regex so '+2n-1' is not read as combinator), percentage, or a type selector with optional ignored namespace after '|'. After each selector component, comment/whitespace is skipped; if ',' or the terminator (')' inside pseudo-class, otherwise '{') follows, the parser rewinds to before that token, closes the current RelativeSelector, and returns the ComplexSelector. Otherwise a combinator is read; when present, the current RelativeSelector is closed (only if it has selectors) and a new one begins with that combinator — starting a new selector directly on a terminator throws e.css_selector_invalid. End of template throws e.unexpected_eof.

calls: [read_combinator](r2-css-parse.md#u-ffc85cf8c133), [read_selector_list](r2-css-parse.md#u-00c76aa683fd), [read_identifier](r2-css-parse.md#u-2dd7159f8ba1), [read_attribute_value](r2-css-parse.md#u-ae80a6ada159)

<a id="u-f9ccd7c79c86"></a>
### `read_block`

`function read_block(parser)` · [packages/svelte/src/compiler/phases/1-parse/read/style.js:L415-L441][f1]

Parses a '{'-delimited block: requires '{', then repeatedly skips comments/whitespace and reads block items until '}' matches, then requires '}' (parser.eat throws if missing).

Returns a Block node with the collected children; running off the template end makes read_block_item's reads throw e.unexpected_eof.

calls: [read_block_item](r2-css-parse.md#u-7fe79445acb0), [allow_comment_or_whitespace](r2-css-parse.md#u-131239fcb755)

<a id="u-7fe79445acb0"></a>
### `read_block_item`

`function read_block_item(parser)` · [packages/svelte/src/compiler/phases/1-parse/read/style.js:L449-L462][f1]

Dispatches one item inside a block: '@' starts an at-rule.

Otherwise it reads ahead with read_value to inspect the character that terminated the value (parser.index is rewound to the start afterwards), choosing read_rule when that character is '{' and read_declaration otherwise; the comment notes this lookahead avoids try/catch that would mask errors.

calls: [read_at_rule](r2-css-parse.md#u-f5e645353a7a), [read_rule](r2-css-parse.md#u-7fd5dca44ce4), [read_declaration](r2-css-parse.md#u-ed58797e828b), [read_value](r2-css-parse.md#u-f2107227fcd9)

<a id="u-f5e645353a7a"></a>
### `read_at_rule`

`function read_at_rule(parser)` · [packages/svelte/src/compiler/phases/1-parse/read/style.js:L77-L104][f1]

Parses an at-rule: consumes '@', reads the identifier name and prelude value, then either a '{'-delimited block (e.g. @media) or a required ';' (e.g. @import); a missing semicolon throws via parser.eat.

Returns an Atrule node with block null in the statement form.

calls: [read_value](r2-css-parse.md#u-f2107227fcd9), [read_block](r2-css-parse.md#u-f9ccd7c79c86), [read_identifier](r2-css-parse.md#u-2dd7159f8ba1)

<a id="u-ed58797e828b"></a>
### `read_declaration`

`function read_declaration(parser)` · [packages/svelte/src/compiler/phases/1-parse/read/style.js:L468-L496][f1]

Parses a `property: value;` declaration.

The property is everything up to whitespace or ':'; a ':' is then expected (parser.eat; behavior when absent relies on the empty value path). An empty value is an error (e.css_empty_declaration) unless the property starts with '--' (custom properties may be empty). A terminating ';' is required unless the declaration ends at a '}'. Returns a Declaration node whose end is recorded before the semicolon is consumed.

calls: [read_value](r2-css-parse.md#u-f2107227fcd9)

<a id="u-f2107227fcd9"></a>
### `read_value`

`function read_value(parser)` · [packages/svelte/src/compiler/phases/1-parse/read/style.js:L502-L536][f1]

Consumes a raw declaration/at-rule prelude value character by character until a structural terminator.

Backslash escapes are copied verbatim (next char included); quotes toggle quote_mark so quotes and terminators inside strings are inert; '(' after 'url' sets in_url so ';'/'{'/'}' inside a URL are inert; ')' clears in_url. The value ends (trimmed) at ';', '{' or '}' when not inside quotes or a url; otherwise it continues. Reaching end-of-template throws e.unexpected_eof.

**Notes.**

- condition: A quote toggles on/off by exact match; nested or unbalanced quotes cause the terminator check to be suppressed until the matching quote or EOF error.

<a id="u-2dd7159f8ba1"></a>
### `read_identifier`

`function read_identifier(parser)` · [packages/svelte/src/compiler/phases/1-parse/read/style.js:L575-L611][f1]

Reads a CSS identifier per the CSS syntax ident diagram.

A leading digit or lone hyphen-digit throws e.css_expected_identifier immediately. '\'-escapes become either a unicode code point (up to 6 hex digits plus optional whitespace, decoded via String.fromCodePoint) or a literal backslash plus the next character. Regular characters are [a-zA-Z0-9_-] plus any code point >= 160. An empty result throws e.css_expected_identifier.

**Notes.**

- failure: A backslash at the last template character reads template[index+1], which is undefined — the escape appends '\undefined' rather than throwing; behavior at exact EOF is unverified.

<a id="u-ffc85cf8c133"></a>
### `read_combinator`

`function read_combinator(parser)` · [packages/svelte/src/compiler/phases/1-parse/read/style.js:L380-L409][f1]

Reads a CSS combinator after optional whitespace.

If one of + ~ > || matches, returns a Combinator node with that name; otherwise, if whitespace was actually consumed, returns a descendant combinator named ' ' spanning the skipped span; if neither, returns null.

**Notes.**

- condition: The descendant combinator is only produced when at least one whitespace character was consumed between selectors.

<a id="u-ae80a6ada159"></a>
### `read_attribute_value`

`function read_attribute_value(parser)` · [packages/svelte/src/compiler/phases/1-parse/read/style.js:L543-L569][f1]

Reads an attribute-selector value, optionally quoted.

An opening quote is consumed if present; characters accumulate until the matching closing quote (required, parser.eat throws) or, unquoted, until whitespace or ']'. Backslash escapes are copied verbatim. End-of-template throws e.unexpected_eof; the trimmed value is returned.

**Notes.**

- condition: Unquoted values terminate on any whitespace or ']' via REGEX_CLOSING_BRACKET; quoted values may contain both.

<a id="u-131239fcb755"></a>
### `allow_comment_or_whitespace`

`function allow_comment_or_whitespace(parser)` · [packages/svelte/src/compiler/phases/1-parse/read/style.js:L614-L629][f1]

Skips whitespace and, in a loop, C-style comments (/* ...

*/; unterminated comments make read_until consume to EOF) and HTML comments (<!-- ... -->; the closer is required by parser.eat, so an unclosed one throws). Used before selectors, blocks, and declarations.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/1-parse/read/style.js
