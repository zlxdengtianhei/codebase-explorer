# Svelte Repository

**Capability.** Owns the Svelte toolchain end to end: compiling component source through parse/analyze/transform, executing compiled output on client and server runtimes, and publishing reactive APIs, typings, and shared utilities. The root exists only to relate these capabilities; cross-tree needs flow through depends_on edges.

Start here to navigate. Compilation work lives under compiler-pipeline, execution under the two runtime subtrees, and user-facing reactivity and typings under public-api-types. Note: the five merged regions are overlapping descriptions of the same codebase, so region-level edges evidence dependencies between these capability areas, not necessarily between their exact subnodes.

**Children.**

- [Svelte Repository](r1-svelte-monorepo.md) `r1-svelte-monorepo` · 0 unit(s)
- [Compiler Pipeline](compiler-pipeline.md) `compiler-pipeline` · 0 unit(s)
- [Client Runtime](client-runtime.md) `client-runtime` · 0 unit(s)
- [Server & Shared Runtime](server-and-shared-runtime.md) `server-and-shared-runtime` · 0 unit(s)
- [Public API, Types & Reactive Primitives](public-api-types.md) `public-api-types` · 0 unit(s)

**Depends on.**

- [Client Runtime](client-runtime.md) · containment · → 0 / ← 0 edge(s) (ancestor direct units and descendant subtree; → follows ` svelte-repo ` → ` client-runtime `)
- [Compiler Pipeline](compiler-pipeline.md) · containment · → 0 / ← 0 edge(s) (ancestor direct units and descendant subtree; → follows ` svelte-repo ` → ` compiler-pipeline `)
- [Public API, Types & Reactive Primitives](public-api-types.md) · containment · → 0 / ← 0 edge(s) (ancestor direct units and descendant subtree; → follows ` svelte-repo ` → ` public-api-types `)
- [Server & Shared Runtime](server-and-shared-runtime.md) · containment · → 0 / ← 0 edge(s) (ancestor direct units and descendant subtree; → follows ` svelte-repo ` → ` server-and-shared-runtime `)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
