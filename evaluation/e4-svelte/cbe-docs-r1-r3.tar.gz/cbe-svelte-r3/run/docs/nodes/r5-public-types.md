# Public Element Types

**Capability.** The elements.d.ts type surface: shared attribute value unions and event-handler aliases, ARIA/DOM/base attribute interfaces extended per element, SVG attributes, svelte:window attributes, and the SvelteHTMLElements tag→attributes mapping used to type element props.

Use when adding attributes or elements to the public typings. HTMLAttributes/SVGAttributes extend AriaAttributes and DOMAttributes; every per-element interface composes the base interfaces; SvelteHTMLElements aggregates them all.

Parent: [Svelte Monorepo](r5-svelte.md)

## Units (8)

<a id="u-a17618b45fd1"></a>
### `type-aliases`

`type Booleanish = boolean | 'true' | 'false';` · [packages/svelte/elements.d.ts:L38-L38][f1]

Declares the shared attribute value unions and typed event-handler aliases used by every element interface in this file.

Booleanish is boolean | 'true' | 'false', with null accepted at use sites because Svelte treats null like undefined. EventHandler<E,T> takes one argument typed E & { currentTarget: EventTarget & T }, and each exported alias (ClipboardEventHandler through ContentVisibilityAutoStateChangeEventHandler) instantiates it with the matching DOM event and a free EventTarget parameter. FullAutoFill extends AutoFill with extra literals and a template-literal prefix token. AriaRole, HTMLAttributeAnchorTarget, and HTMLInputTypeAttribute are literal unions widened by (string & {}) so arbitrary strings type-check while literals get completion. ClassValue is string or clsx ClassArray/ClassDictionary for the class attribute.

uses: [DOMAttributes](r5-public-types.md#u-b2213dc03cb0), [HTMLAttributes](r5-public-types.md#u-769572c7f4d3)

**Uncertainties.**

- Declarations only; no runtime dispatch behavior is defined here.

<a id="u-a616c2f1aeb7"></a>
### `elements.d.ts-element-attribute-interfaces`

`export interface HTMLAnchorAttributes extends HTMLAttributes<HTMLAnchorElement>` · [packages/svelte/elements.d.ts:L880-L890][f1]

All remaining per-element attribute interfaces, each a thin extension of HTMLAttributes<ConcreteElement> (or HTMLMediaAttributes<T> for media) adding only that element's own attributes with closed literal unions where the spec has them.

Notable choices: HTMLAudioAttributes is an empty extension inheriting all media bindings; HTMLVideoAttributes adds poster, picture-in-picture/remote-playback toggles, and readonly videoWidth/videoHeight bindings; HTMLMediaAttributes adds media playback attributes, readonly readyState/duration/buffered/played/seekable/seeking/ended bindings and writable muted/volume/currentTime/playbackRate/paused bindings, with SvelteMediaTimeRange describing { start, end }; HTMLDetailsAttributes re-declares 'on:toggle' with a concrete HTMLDetailsElement target and adds bind:open; button and form allow both lowercase and uppercase method literals; input, select, and textarea narrow 'on:change' to ChangeEventHandler of their element and add bind:value, with input/textarea declaring both defaultValue and defaultvalue casing because language tools lowercase non-shorthand attribute names; HTMLImgAttributes adds readonly naturalWidth/naturalHeight; HTMLInputAttributes additionally provides bind:checked/group/files/indeterminate and value: any; deprecated attributes (frameborder, scrolling, charset on script, input type list widened by (string & {})) are kept and flagged; HTMLTemplateAttributes adds shadowrootmode; HTMLWebViewAttributes allows arbitrary preload strings for Electron; HTMLAnchorAttributes target uses HTMLAttributeAnchorTarget. SvelteDocumentAttributes extends HTMLAttributes<Document> with readonly activeElement/fullscreenElement/pointerLockElement/visibilityState bindings.

inherits: [HTMLAttributes](r5-public-types.md#u-769572c7f4d3); uses: [type-aliases](r5-public-types.md#u-a17618b45fd1)

**Uncertainties.**

- HTMLKeygenAttributes targets HTMLElement for a removed element; whether compilers still accept <keygen> is outside this file.

<a id="u-00e9dbdc2f41"></a>
### `AriaAttributes`

`export interface AriaAttributes` · [packages/svelte/elements.d.ts:L479-L676][f1]

Type-only interface enumerating the WAI-ARIA 1.1 attributes as optional quoted properties with doc comments.

Values are string, number, Booleanish, or closed literal unions (e.g. aria-live: 'off' | 'assertive' | 'polite'; aria-autocomplete: 'none' | 'inline' | 'list' | 'both'); every property also accepts undefined and null. aria-checked and aria-pressed additionally allow boolean and 'mixed', aria-current adds 'page' | 'step' | 'location' | 'date' | 'time', aria-invalid adds 'grammar' | 'spelling', and aria-relevant allows compound literals like 'additions removals'. aria-dropeffect and aria-grabbed are marked deprecated per ARIA 1.1.

<a id="u-b2213dc03cb0"></a>
### `DOMAttributes`

`export interface DOMAttributes<T extends EventTarget>` · [packages/svelte/elements.d.ts:L85-L476][f1]

Type-only interface describing the event-handler and binding surface common to every element target T extends EventTarget.

It declares an optional children Snippet prop so spread props work without a separate interface, then for each DOM event category up to three optional handler slots: 'on:x' (Svelte directive style), onx, and onxcapture, each accepting the aliased handler, undefined, or null (null allowed because Svelte treats it like undefined). Notable per-event choices: 'on:input' is FormEventHandler because its event type varies by target, 'on:submit' is SubmitEvent, 'on:beforeinput' uses InputEvent, mouseenter/mouseleave and the gamepad handlers have no capture variants. It ends with readonly 'bind:' dimension properties (contentRect, contentBoxSize, clientWidth, clientHeight) and xmlns.

**Notes.**

- contract: Handler arguments are E & { currentTarget: EventTarget & T }, narrowing currentTarget to the interface's target type.

uses: [type-aliases](r5-public-types.md#u-a17618b45fd1)

**Uncertainties.**

- Whether capture-suffixed names map to capture-phase listeners is compiler behavior outside this declarations file.

<a id="u-769572c7f4d3"></a>
### `HTMLAttributes`

`export interface HTMLAttributes<T extends EventTarget> extends AriaAttributes, DOMAtt…` · [packages/svelte/elements.d.ts:L751-L876][f1]

Base attribute interface for HTML elements, extending AriaAttributes and DOMAttributes<T>.

It covers standard attributes (id, class as ClassValue, style as string, contenteditable including 'plaintext-only', hidden with 'until-found', popover, inert), role as AriaRole, RDFa and non-standard attributes, and SvelteKit data-sveltekit-* routing options as closed unions. It declares contenteditable binding props (bind:innerHTML/textContent/innerText) and readonly measurement bindings (bind:focused, bind:offsetWidth/offsetHeight). Two index signatures broaden it: any `data-${string}` key maps to any, and symbol keys map to Attachment<T> | false | undefined | null — false is allowed so falsy values pass, while other booleans are deliberately rejected for attachments.

**Notes.**

- contract: The data-* index signature suppresses excess-property errors for arbitrary data attributes.
- field: Symbol keys accept only Attachment<T>, false, undefined, or null; true and other booleans fail.

inherits: [AriaAttributes](r5-public-types.md#u-00e9dbdc2f41), [DOMAttributes](r5-public-types.md#u-b2213dc03cb0); uses: [type-aliases](r5-public-types.md#u-a17618b45fd1)

**Uncertainties.**

- Resolution of the Attachment import from svelte/attachments depends on that module, not visible here.

<a id="u-adb80c8bde08"></a>
### `SVGAttributes`

`export interface SVGAttributes<T extends EventTarget> extends AriaAttributes, DOMAttr…` · [packages/svelte/elements.d.ts:L1551-L1844][f1]

Attribute interface for SVG elements, extending AriaAttributes and DOMAttributes<T> directly (not HTMLAttributes).

It re-declares shared HTML-ish properties (class/className, id, style, role, tabindex, crossorigin, width/height), then lists SVG-specific attributes, most typed as number | string | undefined | null with closed literal unions where the spec has them (e.g. 'fill-rule': 'nonzero' | 'evenodd' | 'inherit'; 'stroke-linecap': 'butt' | 'round' | 'square' | 'inherit'; alignment-baseline with a long literal list). It also covers xlink:* and xml:* namespaced attributes, plus a `data-${string}` index signature mapping to any so arbitrary data attributes are allowed.

inherits: [AriaAttributes](r5-public-types.md#u-00e9dbdc2f41), [DOMAttributes](r5-public-types.md#u-b2213dc03cb0); uses: [type-aliases](r5-public-types.md#u-a17618b45fd1)

**Uncertainties.**

- Many SVG attributes are typed loosely as number | string rather than per-spec unions; stricter checking is not provided here.

<a id="u-a4bde8899205"></a>
### `SvelteHTMLElements`

`export interface SvelteHTMLElements` · [packages/svelte/elements.d.ts:L1873-L2091][f1]

Mapping of element/tag names to their attribute interfaces, used to type Svelte element props.

Each HTML tag (a through webview) maps to a concrete interface such as HTMLAnchorAttributes or, for content-only elements, HTMLAttributes<HTMLElement> with a narrowed target type; SVG tags map to SVGAttributes with the specific SVG element type. Svelte-specific entries add 'svelte:window', 'svelte:document', 'svelte:body', 'svelte:fragment' ({ slot?: string }), 'svelte:options' with an inline customElement object shape (tag, shadow, typed props, extend callback) plus immutable/accessors/namespace, 'svelte:head' as an any-valued record, and 'svelte:boundary' with onerror callback and failed/pending Snippets. A final string index signature maps any other name to { [name: string]: any }, so unknown tags and custom elements type-check.

**Notes.**

- contract: The trailing [name: string] index signature lets arbitrary custom elements pass type checking with any attributes.

uses: [HTMLAttributes](r5-public-types.md#u-769572c7f4d3), [SVGAttributes](r5-public-types.md#u-adb80c8bde08), [SvelteWindowAttributes](r5-public-types.md#u-9017cd4cac09)

<a id="u-9017cd4cac09"></a>
### `SvelteWindowAttributes`

`export interface SvelteWindowAttributes extends HTMLAttributes<Window>` · [packages/svelte/elements.d.ts:L1489-L1549][f1]

Attribute interface for <svelte:window>, extending HTMLAttributes<Window>.

It adds readonly bindings for innerWidth/innerHeight/outerWidth/outerHeight/devicePixelRatio and online, plus writable bind:scrollX/scrollY. It then declares window-only event handlers in both 'on:x' and onx forms for browser/device/navigation events not present on ordinary elements: devicelight, deviceproximity, paint, userproximity, beforeprint/afterprint, message/messageerror, offline/online, beforeunload/unload, storage, hashchange, pagehide/pageshow, popstate, devicemotion, deviceorientation (and absolute variant), and unhandledrejection/rejectionhandled, each typed via EventHandler with the matching DOM event and Window target.

inherits: [HTMLAttributes](r5-public-types.md#u-769572c7f4d3)

**Uncertainties.**

- ondevicemotion omits the Window type parameter (EventHandler<DeviceMotionEvent>), unlike its 'on:devicemotion' counterpart; intent unclear.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/elements.d.ts
