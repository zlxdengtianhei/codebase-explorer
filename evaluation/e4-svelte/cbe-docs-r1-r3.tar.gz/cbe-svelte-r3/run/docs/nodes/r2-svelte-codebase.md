# Svelte Codebase

**Capability.** Umbrella for the Svelte framework: its compiler pipeline, client-side runtime, reactive primitives, public type/API surface, and developer tooling. Each top-level child owns an independently cohesive responsibility; the root exists only to relate them.

Use this root to navigate between compiler, runtime, reactive primitives, public API, and tooling. Cross-tree needs flow through depends_on edges rather than through the root. Language identity (JS/TS/d.ts) is preserved inside each subtree.

**Children.**

- [Svelte Compiler](r2-compiler.md) `r2-compiler` · 0 unit(s)
- [Client Runtime](r2-client-runtime.md) `r2-client-runtime` · 0 unit(s)
- [Reactive Primitives](r2-reactive-primitives.md) `r2-reactive-primitives` · 8 unit(s)
- [Public API Types](r2-public-api.md) `r2-public-api` · 10 unit(s)
- [Tooling & Benchmarks](r2-tooling.md) `r2-tooling` · 0 unit(s)

**Depended on by.**

- [DOM Elements](r2-dom-elements.md) · within containment · 1 edge(s)

Parent: [Public API, Types & Reactive Primitives](public-api-types.md)

## Units (9)

<a id="u-b6ffad2a2a76"></a>
### `packages/svelte/src/internal/server/blocks/html.js:html`

`export function html(value)` · [packages/svelte/src/internal/server/blocks/html.js:L7-L11][f1]

Wrap a raw HTML string in hydration comment markers for the server render output.

**Notes.**

- condition: Value is coerced via String(value ?? ''); null/undefined become an empty string.
- condition: In DEV the opening marker is <!--hash--> embedding a content hash; otherwise it is the plain <!----> comment from hydration constants.

calls: [hash](r3-shared-utils.md#u-a8a8fa6d6333)

**Uncertainties.**

- hash() comes from utils.js and is not visible here; its collision behavior is unverified.

<a id="u-1831d6d0eeba"></a>
### `packages/svelte/src/internal/server/types.d.ts:Component`

`export interface Component` · [packages/svelte/src/internal/server/types.d.ts:L1-L12][f2]

Type declaration for the server Component stack frame (parent, context, ondestroy, dev-only function); type-only, no runtime behavior.

<a id="u-f395c337d648"></a>
### `RenderOutput`

`export interface RenderOutput` · [packages/svelte/src/internal/server/types.d.ts:L14-L21][f2]

Type declaration for render output (head, deprecated html, body); type-only, no runtime behavior.

<a id="u-83334ed78d84"></a>
### `packages/svelte/src/internal/shared/attributes.js:append_styles`

`function append_styles(styles, important = false)` · [packages/svelte/src/internal/shared/attributes.js:L91-L103][f3]

Renders a style-property record into a CSS declaration string.

Each key whose value is neither null/undefined nor '' contributes ' key: value' followed by ';' or, when important is true, ' !important;'. Qualifying-null keys are skipped. Returns the accumulated string, which is '' when nothing qualifies. Module-private; used only by to_style.

<a id="u-12a88532ea06"></a>
### `attr`

`export function attr(name, value, is_boolean = false)` · [packages/svelte/src/internal/shared/attributes.js:L24-L29][f3]

Serializes a single attribute into an SSR attribute string like ' name="value"'.

If value is null or undefined, or falsy while is_boolean is true, it returns '' so the attribute is omitted entirely. Otherwise it consults the module-level replacements map (currently only translate: true→'yes', false→'no') and uses the mapped value when the name is a key and the value is present. With is_boolean true it returns ' name' with no assignment; otherwise it returns ' name="..."' with the normalized value passed through escape_html with attribute escaping enabled.

calls: [escape_html](r4-shared-source-utilities.md#u-0f499dd45547)

<a id="u-2274c46486ff"></a>
### `clsx`

`export function clsx(value)` · [packages/svelte/src/internal/shared/attributes.js:L36-L42][f3]

Normalizes a class attribute value while preserving Svelte's falsy-value handling.

If value is an object it delegates to the external clsx package, which resolves class lists/objects to a string. Otherwise it returns value with null and undefined coerced to '' via nullish coalescing; other falsy values such as 0 or false pass through unchanged rather than becoming ''.

**Uncertainties.**

- Output for object inputs depends on the external clsx package, whose implementation is not in this source

<a id="u-bb0adfe2b192"></a>
### `to_class`

`export function to_class(value, hash, directives)` · [packages/svelte/src/internal/shared/attributes.js:L52-L84][f3]

Builds the final class attribute string from a user value, a scoped-CSS hash, and a directives map, returning null when the result is empty.

The value is stringified with null/undefined becoming ''. If hash is truthy it is appended space-separated, or becomes the whole string when classname was empty. For each directives key: a truthy key is appended space-separated; a falsy key is removed from classname by scanning for whole-token occurrences of the key — a match is valid only when its left and right boundaries are start/end-of-string or whitespace characters — and each match is deleted together with one adjacent separator, with the scan resuming after the match. An empty final string is returned as null.

**Notes.**

- condition: Removal matches only whitespace-delimited tokens, so a directive name appearing inside a larger class name is preserved

<a id="u-c7b91478cfe6"></a>
### `to_css_name`

`function to_css_name(name)` · [packages/svelte/src/internal/shared/attributes.js:L109-L114][f3]

Normalizes a CSS property name for comparison.

If the name does not begin with '--' (first two characters checked), it is lowercased; names starting with '--' keep their case because custom property names are case-sensitive. Module-private.

<a id="u-50b25ac26373"></a>
### `to_style`

`export function to_style(value, styles)` · [packages/svelte/src/internal/shared/attributes.js:L121-L219][f3]

Produces the final inline style string by merging an existing style string with override records, returning null when the result is empty.

Without styles it returns null for null/undefined value, otherwise String(value). With styles, an array argument means [normalStyles, importantStyles]; an object means normal styles only. Any existing value string has /*...*/ comments stripped and is trimmed, then scanned character by character: a state machine tracks block comments, quoted strings (quote character remembered until the matching close), and parenthesis depth; only outside all three are ':' taken as the property-name separator and ';' or end-of-string as a declaration terminator. Each kept declaration whose to_css_name-normalized name is not among the reserved names built from the override records' keys is copied into the output; overridden declarations are dropped. Normal styles are appended without !important and important styles with ' !important;' via append_styles; the result is trimmed and returned as null when empty.

calls: [to_css_name](r2-svelte-codebase.md#u-c7b91478cfe6), [packages/svelte/src/internal/shared/attributes.js:append_styles](r2-svelte-codebase.md#u-83334ed78d84)

**Uncertainties.**

- Malformed input (unbalanced quotes or parentheses) has unverified behavior: the scanner only decrements depth on ')' and exits string state only on the matching quote

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/server/blocks/html.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/server/types.d.ts
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/shared/attributes.js
