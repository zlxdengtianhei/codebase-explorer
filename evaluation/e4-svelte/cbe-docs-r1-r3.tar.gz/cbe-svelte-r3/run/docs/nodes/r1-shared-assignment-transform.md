# Shared Assignment Driver

**Capability.** The shared driver for transforming assignment expressions in both client and server output, delegating per-target rewriting to a caller-supplied build_assignment.

Consult when assignment semantics (state fields, stores) differ between client and server output. Both AssignmentExpression visitors call this single driver with their own builders.

**Depended on by.**

- [Client Transform](r1-client-transform.md) · model-inferred · 0 edge(s)
- [Server Transform](r1-server-transform.md) · graph-confirmed · 1 edge(s)

Parent: [Transform Phase](r1-compiler-transform.md)

## Units (1)

<a id="u-b43a982ab161"></a>
### `visit_assignment_expression`

`export function visit_assignment_expression(node, context, build_assignment)` · [packages/svelte/src/compiler/phases/3-transform/shared/assignments.js:L15-L93][f1]

Shared driver for transforming assignment expressions in client and server output, delegating per-target work to a caller-supplied build_assignment.

For destructuring targets (ArrayPattern/ObjectPattern/RestElement) it visits the right-hand side, caches it in $$value when it is not a plain Identifier, extracts paths/inserts via extract_paths (renaming inserted ids via scope.generate('$$array')), and builds one assignment per path; a build_assignment returning null falls back to a plain b.assignment, and if none changed the original assignment is kept (returns null). When inserts or caching exist, the work becomes an arrow-function IIFE called with the value — awaited if any part is async (is_expression_async) — with a trailing return of the cached value when used as an expression; otherwise a plain sequence is produced, again ending with the value when non-standalone (detected by the enclosing path ending in 'Statement'). For Identifier/MemberExpression targets it calls build_assignment directly. Any other left-hand type throws 'Unexpected assignment type ...'.

**Notes.**

- failure: Throws on left-hand types other than ArrayPattern, ObjectPattern, RestElement, Identifier, or MemberExpression.

calls: [extract_paths](r4-compiler-ast-utils.md#u-34f2fcb20c62), [is_expression_async](r4-compiler-ast-utils.md#u-88399029ef9f)

**Uncertainties.**

- The is_standalone check via path.at(-1).type.endsWith('Statement') may misclassify non-statement parents whose type names end in 'Statement'; behavior in that case is not provable here.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/shared/assignments.js
