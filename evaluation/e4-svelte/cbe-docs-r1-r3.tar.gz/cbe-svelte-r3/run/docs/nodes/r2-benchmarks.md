# Reactivity Benchmarks

**Capability.** Micro-benchmarks against the internal client: diamond and unstable-dependency derived-graph propagation in the kairo suite, and creation-scale signal/derived construction in sbench.

Use these to measure the reactivity core: kairo_diamond counts sum recomputations over a fan-out graph, kairo_unstable flips dependency sets per run, and sbench measures construction throughput at 100k scale. They import internal runtime APIs directly.

**Depends on.**

- [Reactivity Core & Batching](r2-reactivity-core.md) · model-inferred · 0 edge(s)
- [Benchmarking Harness](r4-benchmarking.md) · graph-only · 19 edge(s)

Parent: [Tooling & Benchmarks](r2-tooling.md)

## Units (3)

<a id="u-515ca1b112ed"></a>
### `kairo_diamond.js`

`function setup()` · [benchmarking/benchmarks/reactivity/kairo/kairo_diamond.js:L6-L30][f1]

Benchmarks a diamond-shaped dependency graph: setup() creates width (5) deriveds each reading head, a sum derived that maps and reduces them, and a render effect counting sum recomputations.

run() flushes head to 1 asserting sum is 2*width, resets the counter, then for i in 0..499 flushes head to i asserting sum equals (i+1)*width, and finally asserts the counter is exactly 500 — verifying each write propagates once through all branches despite the shared head. Unowned and owned variants follow the standard harness: 10 warm-up setup/run/destroy cycles, fastest_test over 10 iterations of 1000 runs, then teardown (owned nests teardown in an outer effect_root, destroying inner before outer). Both return {benchmark, time, gc_time} as two-decimal strings; assertions throw on mismatch.

calls: [fastest_test](r4-benchmarking.md#u-0bbe8c671495), [assert](r4-benchmarking.md#u-823bd0dd0cd8)

<a id="u-1fe456c77864"></a>
### `kairo_unstable.js`

`function setup()` · [benchmarking/benchmarks/reactivity/kairo/kairo_unstable.js:L4-L27][f2]

Benchmarks a computation whose dependency set changes per run: setup() builds double (head*2) and inverse (-head) deriveds, and current which loops 20 times choosing double when head is odd or inverse when head is even, so the branch taken flips with head's parity.

A render effect counts recomputations. run() flushes head to 1 asserting current is 40 (20×2), resets the counter, then flushes head through 0..99 and finally asserts the counter is exactly 100 — one recomputation per write even though different dependencies are read each time. Unowned and owned variants use the standard harness: 10 warm-up setup/run/destroy cycles, fastest_test over 10 iterations of 1000 runs, owned nesting setup in an outer effect_root and destroying inner before outer; both return {benchmark, time, gc_time} with two-decimal timings, and assertions throw on mismatch.

calls: [fastest_test](r4-benchmarking.md#u-0bbe8c671495), [assert](r4-benchmarking.md#u-823bd0dd0cd8)

<a id="u-546e50cbfc2e"></a>
### `sbench.js`

`function create_data_signals(n, sources)` · [benchmarking/benchmarks/reactivity/sbench.js:L10-L15][f3]

Creation-focused micro-benchmarks over Svelte's internal client, measuring signal and derived construction at COUNT = 100,000 scale rather than update propagation.

create_data_signals fills an array with n state signals seeded 0..n-1. create_computation_0/1/2/1000 and _4 each create deriveds reading 0, 1, 2, 1000, or 4 sources respectively; note the deriveds are created but their values are never read, so creation cost is what is timed. The create_computations_* drivers loop over sources with fixed fan-out/fan-in ratios: 0to1 (no sources), 1to1, 2to1 (sources[i*2], [i*2+1]), 1000to1 (one derived summing sources[offset..offset+999] per 1000 signals), 4to1, and 1to2/1to4/1to8/1to1000 which create repeated deriveds from the first n/ratio sources. bench(fn, count, scount) creates scount data signals and calls fn with them. Each exported sbench_create_* function runs 3 warm-up bench calls, then fastest_test over 10 iterations of 10 bench calls; sbench_create_signals needs no effect_root, while all others wrap each timed iteration in a temporary effect_root that is destroyed immediately, disposing the created graph. Each returns {benchmark, time, gc_time} with two-decimal timing strings; a thrown error from fastest_test propagates and aborts the benchmark.

calls: [fastest_test](r4-benchmarking.md#u-0bbe8c671495)

**Uncertainties.**

- Whether unread deriveds are lazily evaluated (affecting what 'creation' costs) depends on svelte/internal/client internals not supplied

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/benchmarking/benchmarks/reactivity/kairo/kairo_diamond.js
[f2]: ../../../../../../eval/svelte-be645b4/benchmarking/benchmarks/reactivity/kairo/kairo_unstable.js
[f3]: ../../../../../../eval/svelte-be645b4/benchmarking/benchmarks/reactivity/sbench.js
