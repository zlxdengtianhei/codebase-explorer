# Server Render Entry

**Capability.** Component-to-HTML rendering entry (render, element emission with hydration sentinels, head payload, CSS custom-property wrappers) plus module imports/re-exports and shared error and hydration-marker support.

Call render to SSR a component. This node owns the module frame (imports, re-exports, on_destroy) of server/index.js and the server-side error/marker support modules.

**Depends on.**

- [Server Dev Validation](r3-server-dev.md) · graph-confirmed · 1 edge(s)
- [Shared Predicates and Hash](r3-shared-utils.md) · graph-confirmed · 2 edge(s)

Parent: [Server Runtime](r3-server-runtime.md)

## Units (11)

<a id="u-ead9aba750b3"></a>
### `render`

`export function render(component, options = {})` · [packages/svelte/src/internal/server/index.js:L69-L120][f1]

Render a component to HTML on the server, returning head, html, and body strings.

**Notes.**

- side_effect: Swaps the module-level on_destroy array for a fresh one, runs the component, then invokes and restores the previous callbacks; finally always calls abort() to discard any AbortSignal created during render.
- condition: In DEV, reset_elements() isolates the dev element stack from a nested/bad render and is restored before finishing.
- condition: When options.context is provided, a component frame is pushed and its context map assigned, then popped after rendering.
- side_effect: Wraps output in BLOCK_OPEN/BLOCK_CLOSE hydration comments; head is assembled from payload.head.out, the title, and one <style id=hash> block per CSS entry.

calls: [packages/svelte/src/internal/server/context.js:push](r1-server-runtime.md#u-38e06b351976), [packages/svelte/src/internal/server/context.js:pop](r1-server-runtime.md#u-b3ad8cba6058), [reset_elements](r3-server-dev.md#u-cc2fd0cc577f), [abort](r1-server-runtime.md#u-9654b4650543)

**Uncertainties.**

- Behavior of exceptions thrown by the component: the finally aborts, but on_destroy restoration is skipped, leaving the swapped array in place (observable only across repeated render calls in-process).

<a id="u-3675c4ee24d1"></a>
### `packages/svelte/src/internal/server/index.js:element`

`export function element(payload, tag, attributes_fn = noop, children_fn = noop)` · [packages/svelte/src/internal/server/index.js:L35-L53][f1]

Emit an element's server HTML with hydration comment sentinels, delegating attribute and children rendering.

**Notes.**

- condition: If tag is falsy, only the surrounding <!----> comments are emitted.
- condition: Void tags skip children_fn and the closing tag; raw-text elements skip the EMPTY_COMMENT marker before the closing tag.

calls: [utils-js-predicates](r3-shared-utils.md#u-7eb274f609ad)

<a id="u-74e3fe2fb372"></a>
### `packages/svelte/src/internal/server/index.js:head`

`export function head(payload, fn)` · [packages/svelte/src/internal/server/index.js:L127-L132][f1]

Run a callback against the payload's head, wrapped in hydration comment sentinels.

<a id="u-fbc5df6dd0a5"></a>
### `packages/svelte/src/internal/server/index.js:css_props`

`export function css_props(payload, is_html, props, component, dynamic = false)` · [packages/svelte/src/internal/server/index.js:L142-L162][f1]

Render a CSS custom-property wrapper element (div-style or SVG g) around children.

**Notes.**

- condition: is_html selects <svelte-css-wrapper style="display: contents; ..."> versus <g style=...>; styles come from style_object_to_string(props).
- condition: When dynamic, an extra <!----> marker is emitted after the opening tag.

calls: [style_object_to_string](r3-server-markup.md#u-5168ebd4b162)

<a id="u-d40a8d66ec5e"></a>
### `index.js module code (L1–L34)`

`module_region` · [packages/svelte/src/internal/server/index.js:L1-L34][f1]

Imports, re-exports (FILENAME/HMR, attr, clsx), and the INVALID_ATTR_NAME_CHAR_REGEX constant.

<a id="u-625b16cdbeea"></a>
### `index.js module code (L53–L68)`

`module_region` · [packages/svelte/src/internal/server/index.js:L53-L68][f1]

Non-behavioral export of the on_destroy array declaration region.

<a id="u-ee57e0e2e995"></a>
### `index.js module code (L120–L126)`

`module_region` · [packages/svelte/src/internal/server/index.js:L120-L126][f1]

Non-behavioral gap between render and head.

<a id="u-f2ba18cae40c"></a>
### `index.js module code (L132–L141)`

`module_region` · [packages/svelte/src/internal/server/index.js:L132-L141][f1]

Non-behavioral gap between head and css_props.

<a id="u-4305968faf98"></a>
### `errors.js module code (L1–L9)`

`module_region` · [packages/svelte/src/internal/server/errors.js:L1-L9][f2]

Generated error module that re-exports shared errors and defines lifecycle_function_unavailable.

<a id="u-af8d810f9167"></a>
### `lifecycle_function_unavailable`

`export function lifecycle_function_unavailable(name)` · [packages/svelte/src/internal/server/errors.js:L10-L16][f2]

Throw a Svelte error stating that a lifecycle function is unavailable on the server.

**Notes.**

- failure: Always throws an Error named 'Svelte error' with the lifecycle_function_unavailable code, message, and docs URL; returns never.

<a id="u-159475e0c7e5"></a>
### `hydration.js module code (L1–L6)`

`module_region` · [packages/svelte/src/internal/server/hydration.js:L1-L6][f3]

Constants for SSR hydration comment markers derived from shared constants.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/server/index.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/server/errors.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/server/hydration.js
