# Shared Analysis Validation

**Capability.** Central, cross-visitor validation rules reused by all phase-2 visitors: assignment and const/import legality, identifier naming, opening-tag keyword checks, module import conflicts, export legality, purity, and safe-identifier analysis.

When a visitor emits an error or warning about assignments, names, or placement, the rule usually lives here. Visitors call these helpers rather than duplicating rule logic; treat this subtree as the single source of validation semantics.

**Depends on.**

- [AST Manipulation Utilities](r4-compiler-ast-utils.md) · graph-confirmed · 2 edge(s)
- [Node Factories and Metadata Model](r4-compiler-node-model.md) · graph-confirmed · 1 edge(s)
- [Scope and Binding Model](r4-compiler-scope.md) · graph-confirmed · 1 edge(s)

**Depended on by.**

- [Semantic Analysis Visitors](r4-analyze-visitors.md) · graph-confirmed · 7 edge(s)
- [Analysis Visitors](r3-analyze-visitors.md) · graph-only · 10 edge(s)

Parent: [Compiler Pipeline](r4-compiler.md)

## Units (10)

<a id="u-ddca3e44b963"></a>
### `ensure_no_module_import_conflict`

`export function ensure_no_module_import_conflict(node, state)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/shared/utils.js:L153-L165][f1]

Rejects instance-scope declarations that clash with <script module> imports.

It extracts all identifiers bound by a VariableDeclarator's id pattern; for each, if the current state is an 'instance' AST whose scope is exactly the instance root scope and the module scope holds an import of the same name, it throws declaration_duplicate_module_import. Any other scope or AST type passes silently.

calls: [extract_identifiers](r4-compiler-ast-utils.md#u-90eb95affc00)

**Uncertainties.**

- The error message is flagged by a TODO as possibly inaccurate for this case.

<a id="u-c8c562a3fb44"></a>
### `is_pure`

`export function is_pure(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/shared/utils.js:L199-L241][f1]

Conservatively decides whether an expression has no side effects, used to justify optimizations.

Literals are pure. CallExpressions are pure only if the callee and all arguments (unwrapping SpreadElement) are pure. Anything other than Identifier or MemberExpression is impure. For identifiers/member chains, if get_rune reports '$effect.tracking' the node is impure. It then walks to the leftmost object: if it is an Identifier with no scope binding, it is treated as a pure global; if the leftmost node itself is pure by recursion, the whole expression is pure. Everything else returns false, with a TODO noting safe Svelte imports and other cases are not yet recognized.

calls: [get_rune](r4-compiler-scope.md#u-5204b6ce4f7a)

**Uncertainties.**

- Member expressions on bound identifiers (even plain state reads) return false unless the leftmost base is unbound or recursively pure, so many genuinely side-effect-free reads are conservatively impure.
- The b.call helper comes from '#compiler/builders'; its exact construction is external to this file.

<a id="u-63a6d609f552"></a>
### `is_safe_identifier`

`export function is_safe_identifier(expression, scope)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/shared/utils.js:L173-L192][f1]

Determines whether the base of a member/call chain is guaranteed not to invoke context-dependent functions (e.g. store subscriptions or props needing component context).

It unwraps MemberExpression objects down to the base; a non-Identifier base returns false. An unbound identifier returns true (assumed global/safe). A store_sub binding recurses on the name without its leading '$' character. Otherwise safety requires declaration_kind not 'import' and kind not in prop, bindable_prop, rest_prop — i.e. local component state, lets, and similar count as safe.

**Uncertainties.**

- Whether recursion through store_sub always terminates depends on the de-'$'ed name binding to a non-store_sub binding; a pathological '$$x' store_sub chain is not guarded here.

<a id="u-83497fe81c11"></a>
### `validate_assignment`

`export function validate_assignment(node, argument, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/shared/utils.js:L18-L73][f1]

Central validation for assignment-like nodes (AssignmentExpression, UpdateExpression, BindDirective) against their target pattern or expression.

First it delegates to validate_no_const_assignment (is_binding true only for BindDirective). For Identifier targets under runes mode: assigning to the $props.id() binding throws constant_assignment, each-item bindings throw each_item_invalid_assignment (both skipped without runes); snippet bindings throw snippet_parameter_assignment regardless of runes mode. For MemberExpression targets on `this`, it resolves the property name (null when computed with a non-Literal property) and looks up the corresponding class state field. If the field's recorded node is an AssignmentExpression different from the current one, it walks the path backwards to the nearest function node; if that function is a constructor MethodDefinition and the current assignment starts before the field's declaration assignment, it throws state_field_invalid_assignment — preventing state fields being written before their declaration in the constructor. The function loop breaks after the first function ancestor is examined.

calls: [validate_no_const_assignment](r4-analyze-shared-validation.md#u-03d1016cde68), [get_name](r4-compiler-node-model.md#u-99af92983a86), [get_parent](r4-compiler-ast-utils.md#u-427249cf438e)

**Uncertainties.**

- state_fields population and the meaning of field.node being an AssignmentExpression are defined elsewhere (class analysis); behavior here trusts that representation.
- Non-Identifier, non-this-MemberExpression targets pass through only the const check.

<a id="u-b877c3a87dc5"></a>
### `validate_block_not_empty`

`export function validate_block_not_empty(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/shared/utils.js:L140-L147][f1]

Warns block_empty when a block contains only whitespace text, tolerating fully empty blocks as work-in-progress.

Returns immediately for a null/undefined fragment. If the fragment has exactly one node that is a Text whose raw content trims to empty, it emits the block_empty warning; zero-element blocks deliberately produce no warning per the inline assumption about in-progress editing.

<a id="u-1535dc101000"></a>
### `validate_export`

`export function validate_export(node, scope, name)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/shared/utils.js:L287-L298][f1]

Prevents exporting derived or reassigned state.

Looks up the name in the scope; an unbound name passes. A derived binding throws derived_invalid_export; a state or raw_state binding that has been reassigned throws state_invalid_export. Non-reassigned state exports are allowed.

<a id="u-e442f835d467"></a>
### `validate_identifier_name`

`export function validate_identifier_name(binding, function_depth)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/shared/utils.js:L251-L279][f1]

Rejects '$' and '$'-prefixed binding names outside legacy scopes.

A null binding passes. Checks apply only when the declaration kind is not synthetic/param/rest_param and the function_depth is 0/undefined or 1 (allowing legacy Svelte-4 style $-prefixed locals below the component top level). At the name '$' it throws dollar_binding_invalid; any other leading '$' throws dollar_prefix_invalid, except type-only imports whose initial is an ImportDeclaration with importKind 'type', which are exempted to keep the migration script working (flagged by a TODO for removal).

**Uncertainties.**

- The exact function_depth values passed by callers determine legacy tolerance; callers are outside this file.

<a id="u-03d1016cde68"></a>
### `validate_no_const_assignment`

`export function validate_no_const_assignment(node, argument, scope, is_binding)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/shared/utils.js:L81-L120][f1]

Throws when an assignment or bind targets an import or a const-declared binding.

It recurses through ArrayPattern elements and ObjectPattern property values so destructuring targets are checked individually. For Identifier targets, the error fires when declaration_kind is 'import', or 'const' with kind not 'each' (each-block variables are reassignable per iteration). Imports are reported as 'import', others as 'constant'; BindDirective targets raise constant_binding, plain assignments raise constant_assignment. A commented-out block shows a planned more precise message that is not currently used.

**Notes.**

- contract: MemberExpression targets (e.g. obj.prop = x on a const object) are not rejected here; only direct identifier targets are checked.

**Uncertainties.**

- The distinction between the commented-out richer message and the current one is historical; the active behavior is the simple import/constant error.

<a id="u-8a95b3b7e6dc"></a>
### `validate_opening_tag`

`export function validate_opening_tag(node, state, expected)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/shared/utils.js:L129-L134][f1]

Checks that a control-flow block opener's second source character is the expected keyword character (e.g. '{' followed by 'i' for if).

It reads state.analysis.source at node.start + 1; on mismatch it throws block_unexpected_character spanning the first five characters (to limit error highlighting). Legacy mode presumably allowed intervening whitespace per the docstring, but no legacy branch exists in this implementation — the check is unconditional.

**Uncertainties.**

- The docstring claims legacy mode allows whitespace between '{' and the keyword, but the code applies the check unconditionally; the legacy gating must happen elsewhere.

<a id="u-2cd9305b9834"></a>
### `utils-js-imports-and-residuals`

`group` · [packages/svelte/src/compiler/phases/2-analyze/visitors/shared/utils.js:L1-L17][f1]

Module scaffolding of utils.js: JSDoc type imports and runtime imports (errors, warnings, ast helpers, builders, scope, nodes) that the exported validators rely on, plus inter-function residual spans.

No standalone behavior.

group: [validate_assignment](r4-analyze-shared-validation.md#u-83497fe81c11)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/shared/utils.js
