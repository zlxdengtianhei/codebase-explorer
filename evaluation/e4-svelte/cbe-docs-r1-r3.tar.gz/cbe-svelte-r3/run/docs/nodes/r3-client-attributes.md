# Client Attribute Application

**Capability.** Applies and diffs element attributes at runtime: single-attribute setting with hydration and caching, spread-attribute effects, per-element setter caches, form-control defaults (value/checked/selected), custom element data, xlink, and src/srcset URL comparison.

attribute_effect is the reactive entry; the set_* helpers implement per-attribute semantics; get_attributes/get_setters provide per-element caches consumed by the set_* group nodes. src_url_equal/srcset_url_equal support dev hydration warnings.

**Depends on.**

- [Client Hydration State](r3-client-hydration.md) · graph-confirmed · 4 edge(s)
- [Shared Predicates and Hash](r3-shared-utils.md) · graph-confirmed · 3 edge(s)

Parent: [Client Runtime](r3-client-runtime.md)

## Units (17)

<a id="u-5ab20d9a7208"></a>
### `attributes.js-remove-input-defaults`

`export function remove_input_defaults(input)` · [packages/svelte/src/internal/client/dom/elements/attributes.js:L39-L48][f1]

Clears an input's value/checked HTML attributes during hydration so a later form reset restores defaults without wiping current values.

If not hydrating it returns immediately. Otherwise it stores the removal closure as input.__on_r (invoked by the shared form-reset listener), queues the closure as an idle task, and registers the global form-reset listener once. The closure runs at most once (already_removed flag). When it runs, for each of 'value' and 'checked' present as an attribute, it saves the live property, removes the attribute via set_attribute(..., null), then restores the property.

calls: [set_attribute](r3-client-attributes.md#u-475e532b1c41), [add_form_reset_listener](r4-runtime-element-bindings.md#u-3524dfa24535)

**Uncertainties.**

- Timing of the idle callback relative to a form reset depends on queue_idle_task, whose scheduling is outside this source

<a id="u-e75ddf9d4835"></a>
### `attributes.js-set-attributes`

`export function set_attributes(element, prev, next, css_hash, skip_warning = false)` · [packages/svelte/src/internal/client/dom/elements/attributes.js:L274-L388][f1]

Spreads a next attributes object onto an element, diffing against the previously spread object, which it mutates and returns.

Keys present in prev but missing from next are set to null so removal happens. next.class is normalized with clsx, or nulled to force a set_class call when a css hash or CLASS symbol exists; next[STYLE] forces a style entry. If hydrating a Svelte custom element, hydration mode is disabled for the duration and restored before returning. Per key: an OPTION element's nullish value assigns element.value/__value to '' (documented accepted limitation: an explicit null option value can never be removed later, because missing prev keys become null); class and style delegate to set_class/set_style and update the CLASS/STYLE symbol caches; unchanged values are skipped unless the value is undefined and the element still has the attribute; '$$'-prefixed keys are skipped as internal. 'on*' keys configure events: capture-suffixed names lose the suffix and set capture; delegated events store the handler under element['__'+event] via delegate(); non-delegated ones keep a stable wrapper via create_event so swapping handlers does not remove/re-add the listener (null value removes it); removal while a value exists is skipped to avoid browser event swallowing. Remaining keys: style goes through set_attribute; autofocus delegates to autofocus(); __value and non-null value on non-custom elements assign element.value/__value; selected on OPTION uses set_selected. The fallback path lowercases names for non-HTML namespaces (preserve_attribute_case), treats defaultValue/defaultChecked as property writes (also clearing the __attributes cache entry to UNINITIALIZED), and for null values removes the attribute while preserving defaultValue/defaultChecked across a value/checked removal when prev is undefined it restores the default, otherwise nulls the live property. Non-function values otherwise go through set_attribute.

calls: [set_attribute](r3-client-attributes.md#u-475e532b1c41), [set_selected](r3-client-attributes.md#u-1e6158ce232f), [get_setters](r3-client-attributes.md#u-0d26f84d109d), [autofocus](r4-runtime-element-bindings.md#u-7f00a79795f4); uses: [function::set_class::5748-placeholder][f1], [function::set_style::810-placeholder][f1]

**Uncertainties.**

- Whether set_class/set_style targets resolve to the imported class.js/style.js symbols cannot be confirmed from identifiers alone in this excerpt
- Interaction of the skip_warning flag with warnings raised inside set_class/set_style is not visible here

<a id="u-dfc6319c1edb"></a>
### `attribute_effect`

`export function attribute_effect( element, fn, sync = [], async = [], css_hash, skip_…` · [packages/svelte/src/internal/client/dom/elements/attributes.js:L472-L528][f1]

Creates a reactive effect that keeps an element's attributes in sync with attribute expressions.

flatten combines the sync and async sources, and inside the resulting values callback it runs a block effect: each run calls fn with the current values, spreads the result via set_attributes against the previous object, and tracks effects per symbol. ATTACHMENT_KEY symbols create branch effects that attach payloads to the element, destroying the previous effect when the value changes; attachment symbols absent from the next object have their effects destroyed. For SELECT elements, after the first run an additional effect re-selects prev.value and calls init_select. On the select-value branch during runs, select_option is invoked with next.value.

calls: [attributes.js-set-attributes](r3-client-attributes.md#u-e75ddf9d4835), [select_option](r5-client-bindings.md#u-fc6c91d49336), [init_select](r5-client-bindings.md#u-f378be747d77), [attach](r4-runtime-dom-blocks.md#u-89b96e9f81b2)

**Uncertainties.**

- Whether the block/effect/branch/destroy_effect primitives behave as names suggest depends on reactivity/effects.js, not supplied

<a id="u-d95a79442ce3"></a>
### `check_src_in_dev_hydration`

`function check_src_in_dev_hydration(element, attribute, value)` · [packages/svelte/src/internal/client/dom/elements/attributes.js:L580-L590][f1]

During hydration in DEV builds, warns when a src/srcset/href attribute's new value differs from the server-rendered one.

srcset is compared with srcset_url_equal first; otherwise the current attribute value and new value are compared with src_url_equal. When they differ it emits w.hydration_attribute_changed with the attribute, the element's outerHTML with inner content elided, and the new value. Non-DEV builds return immediately.

calls: [src_url_equal](r3-client-attributes.md#u-057a89d5095d), [srcset_url_equal](r3-client-attributes.md#u-c92d9284b6f0)

<a id="u-fd27450a93d7"></a>
### `get_attributes`

`function get_attributes(element)` · [packages/svelte/src/internal/client/dom/elements/attributes.js:L534-L542][f1]

Returns the element's __attributes cache record, lazily initializing it with two symbol flags: IS_CUSTOM_ELEMENT (true when nodeName contains '-') and IS_HTML (true when namespaceURI is NAMESPACE_HTML).

The cache is how all attribute setters above skip redundant DOM writes and detect custom-element/HTML status.

<a id="u-0d26f84d109d"></a>
### `get_setters`

`function get_setters(element)` · [packages/svelte/src/internal/client/dom/elements/attributes.js:L548-L573][f1]

Returns the cached list of writable property names for an element, keyed by its 'is' attribute or nodeName in a module-level Map.

On a miss it walks the prototype chain with get_prototype_of, stopping when reaching Element.prototype, collecting each own descriptor key that has a setter. For custom elements this includes setters on the instance's own prototypes; setters above Element are deliberately excluded. The cache is populated eagerly with an empty array before the walk, so concurrent callers get the same array being filled.

<a id="u-475e532b1c41"></a>
### `set_attribute`

`export function set_attribute(element, attribute, value, skip_warning)` · [packages/svelte/src/internal/client/dom/elements/attributes.js:L162-L200][f1]

Sets or removes a single attribute with hydration and caching behavior.

During hydration it first records the server-rendered value into the __attributes cache; for src, srcset, or href on LINK it optionally warns via check_src_in_dev_hydration and returns without writing, since resetting those attributes would trigger a network request. Otherwise, if the cached value equals the new value it returns. Setting 'loading' additionally stashes the value under LOADING_ATTR_SYMBOL. A null/undefined value removes the attribute; a non-string value that appears among the element's property setters is assigned as a property; anything else goes through setAttribute.

**Notes.**

- failure: A truthy skip_warning suppresses only the dev hydration warning; src/srcset/LINK-href still return without writing.

calls: [check_src_in_dev_hydration](r3-client-attributes.md#u-d95a79442ce3), [get_setters](r3-client-attributes.md#u-0d26f84d109d)

<a id="u-ab3720cbd1ab"></a>
### `set_checked`

`export function set_checked(element, checked)` · [packages/svelte/src/internal/client/dom/elements/attributes.js:L99-L113][f1]

Sets an element's checked property only when the tracked checked value changes.

The previous value is cached in the __attributes record with null normalized to undefined; if the incoming boolean matches, it returns without touching the DOM, otherwise it assigns element.checked directly.

<a id="u-0c7dcf045f92"></a>
### `set_custom_element_data`

`export function set_custom_element_data(node, prop, value)` · [packages/svelte/src/internal/client/dom/elements/attributes.js:L216-L263][f1]

Sets a property or attribute on a custom element while detaching the write from the current active reaction/effect, because custom element setters can run lifecycle code of other elements.

It saves active_reaction/active_effect; if hydrating it temporarily disables hydration mode (a Svelte-scaffolded element could otherwise run block logic in hydration mode), nulls both active slots, performs the write, and restores everything in a finally block. For 'style' it always uses set_attribute. Otherwise it assigns as a property when the element's setters are cached, customElements is unavailable, the element is registered and has the setter, or (unregistered element) the value is a non-null object; in every other case it stringifies non-null values and calls set_attribute, deliberately avoiding premature population of the setters cache.

calls: [set_attribute](r3-client-attributes.md#u-475e532b1c41), [get_setters](r3-client-attributes.md#u-0d26f84d109d)

**Uncertainties.**

- Exact effect of the !customElements guard outside browser-extension contexts is asserted by the comment, not provable here

<a id="u-05d7d561d9ac"></a>
### `set_default_checked`

`export function set_default_checked(element, checked)` · [packages/svelte/src/internal/client/dom/elements/attributes.js:L139-L143][f1]

Updates defaultChecked without changing the current checked state: it reads element.checked, writes defaultChecked, then restores the saved value, because assigning defaultChecked can otherwise move the live property.

<a id="u-6d856c0650f4"></a>
### `set_default_value`

`export function set_default_value(element, value)` · [packages/svelte/src/internal/client/dom/elements/attributes.js:L150-L154][f1]

Updates defaultValue without changing the current value: it reads element.value, writes defaultValue, then restores the saved value, since writing defaultValue can also change the live value property.

<a id="u-1e6158ce232f"></a>
### `set_selected`

`export function set_selected(element, selected)` · [packages/svelte/src/internal/client/dom/elements/attributes.js:L122-L132][f1]

Reflects an option's selected state as the 'selected' attribute rather than the property, so form reset honors it.

When selected is true it adds the attribute only if absent, avoiding reverting a later user selection; when false it removes the attribute unconditionally.

<a id="u-2c42d298a226"></a>
### `set_value`

`export function set_value(element, value)` · [packages/svelte/src/internal/client/dom/elements/attributes.js:L76-L93][f1]

Sets an element's value property, skipping work when the value is unchanged.

The last value is tracked in the element's __attributes cache with null normalized to undefined; if unchanged, or if element.value already equals the value and it is not the PROGRESS-at-0 case, it returns. Otherwise it assigns element.value, mapping null/undefined to ''. PROGRESS elements always receive the assignment when value is 0, because a progress bar at 0 still needs its value set.

**Notes.**

- condition: element.nodeName === 'PROGRESS' with value 0 bypasses the equality skip.

<a id="u-ddd420e3d016"></a>
### `set_xlink_attribute`

`export function set_xlink_attribute(dom, attribute, value)` · [packages/svelte/src/internal/client/dom/elements/attributes.js:L207-L209][f1]

Sets an attribute in the SVG xlink namespace on the element via setAttributeNS, unconditionally and with no caching or hydration special-casing.

<a id="u-b4728141ef31"></a>
### `split_srcset`

`function split_srcset(srcset)` · [packages/svelte/src/internal/client/dom/elements/attributes.js:L603-L605][f1]

Splits a srcset string on commas into candidate entries, each trimmed and split on spaces with empty tokens filtered out, yielding [url, descriptor] arrays.

<a id="u-057a89d5095d"></a>
### `src_url_equal`

`function src_url_equal(element_src, url)` · [packages/svelte/src/internal/client/dom/elements/attributes.js:L597-L600][f1]

Compares two URLs for equality: identical strings match immediately; otherwise both are resolved against document.baseURI with new URL and their hrefs compared, so equivalent absolute/relative forms match.

<a id="u-c92d9284b6f0"></a>
### `srcset_url_equal`

`function srcset_url_equal(element, srcset)` · [packages/svelte/src/internal/client/dom/elements/attributes.js:L612-L629][f1]

Compares an element's current srcset with a new one: equal only if both split into the same number of entries and each entry matches on the descriptor part, with URLs compared in both directions via src_url_equal — bidirectional comparison is required because Vite may emit absolute URLs while browsers keep srcset entries relative, so either side may be absolute while the other is not.

calls: [src_url_equal](r3-client-attributes.md#u-057a89d5095d)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/elements/attributes.js
