# Svelte Monorepo

**Capability.** Root coordinating the Svelte compiler pipeline, the client and server runtimes, shared runtime infrastructure, public type definitions, and repository tooling; every other node owns one phase of this overall story.

Start here to navigate the repository. Compiler work flows parse → analyze → transform; runtimes consume compiled output; tooling benchmarks and sandboxes the results.

**Children.**

- [Compiler Pipeline](r5-compiler.md) `r5-compiler` · 0 unit(s)
- [Client Runtime](r5-runtime-client.md) `r5-runtime-client` · 0 unit(s)
- [Server Runtime](r5-runtime-server.md) `r5-runtime-server` · 13 unit(s)
- [Shared Runtime Infrastructure](r5-runtime-shared.md) `r5-runtime-shared` · 10 unit(s)
- [Public Element Types](r5-public-types.md) `r5-public-types` · 8 unit(s)
- [Repository Tooling](r5-tooling.md) `r5-tooling` · 0 unit(s)

Parent: [Compiler Pipeline](compiler-pipeline.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
