# Client Transform

**Capability.** Serializes component analyses into client-side Programs: seeding state transformers, rewriting class state, grouping template children into shared text updates, static-element detection, and per-node visitors for directives, blocks, imports/exports, and document-level elements; types.d.ts declares the transform state contracts.

Read a specific visitor to see how one AST node becomes runtime calls; Program and shared/declarations set up the scope and state machinery the visitors rely on. process_children and is_static_element are the shared template helpers.

**Depends on.**

- [Client Runtime](r1-client-runtime.md) · model-inferred · 0 edge(s)
- [Shared Assignment Driver](r1-shared-assignment-transform.md) · model-inferred · 0 edge(s)
- [Client Codegen Visitors](r5-transform-client.md) · graph-only · 12 edge(s)

**Depended on by.**

- [Dev Diagnostics & HMR](r1-client-dev-diagnostics.md) · graph-confirmed · 1 edge(s)
- [Playground Sandbox](r1-playground-sandbox.md) · graph-confirmed · 2 edge(s)

Parent: [Transform Phase](r1-compiler-transform.md)

## Units (21)

<a id="u-ba1f8c9b6c22"></a>
### `Program`

`export function Program(_, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/Program.js:L11-L49][f1]

Seeds the component's transform table before the body is visited, then continues traversal.

In legacy (non-runes) mode it maps `$$props` reads to `$$sanitized_props` and, for mutated imported bindings, distinguishes instance from module imports by comparing the import declaration's source positions to the instance script's range; instance imports get a `$_import_<name>` identifier transform whose read/mutate call it, backed by a hoisted `$.reactive_import` variable pushed to legacy_reactive_imports. For every store subscription (`store_sub`) binding it installs a lazy transform: the store expression is visited once and cached by get_store so later-added transforms still apply; read wraps in a call, assign becomes `$.store_set`, mutate becomes `$.store_mutate` with the mutated left side's MemberExpression chain collapsed onto an `$.untrack`-ed store read (matching Svelte 4 semantics), and update becomes `$.update_store`/`$.update_pre_store` with -1 for `--` and a getter built by build_getter. For prop and bindable_prop bindings that are prop sources, a transform reads/writes via calls, with bindable_prop mutations passing a `true` flag for legacy parent interop, and update becoming `$.update_prop`/`$.update_pre_prop`; non-source props read directly from `$$props` using the alias key when aliased. Finally add_state_transformers runs and context.next() visits the program body.

calls: [build_getter](r3-client-transform-utils.md#u-66a19e20e1f1), [is_prop_source](r3-client-transform-utils.md#u-38b8a75ee741), [add_state_transformers](r1-client-transform.md#u-32bec314643f)

**Uncertainties.**

- Whether position comparisons can misclassify imports whose ranges overlap the instance script bounds is not verifiable here.
- add_state_transformers' additions are defined in a shared helper.

<a id="u-32bec314643f"></a>
### `add_state_transformers`

`export function add_state_transformers(context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/declarations.js:L18-L53][f2]

Installs read/assign/mutate/update transformers for every stateful declaration in the current scope.

A binding qualifies when is_state_source is true or its kind is 'derived' or 'legacy_reactive'. Reads use `$.safe_get` when declaration_kind is 'var' (legacy reassignable state) and `$.get` otherwise. Assignment builds `$.set(node, value, proxy)` — proxy true passed as literal true when requested — and wraps it in `$.store_unsub` when a `$name` store_sub binding exists in scope. Mutation returns the mutation unchanged in runes mode but wraps it in `$.mutate` in legacy mode. Updates emit `$.update_pre` for prefix operators and `$.update` otherwise, passing -1 only when the operator is `--` (the `node.operator === '--' && b.literal(-1)` expression is falsy otherwise).

calls: [is_state_source](r3-client-transform-utils.md#u-4eba3d9b7ec5)

<a id="u-928394943600"></a>
### `get_value`

`export function get_value(node)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/declarations.js:L10-L12][f2]

Wraps an identifier in a `$.get` call, serving as the default read transformer for reactive state.

uses: [add_state_transformers](r1-client-transform.md#u-32bec314643f)

<a id="u-7091653bb501"></a>
### `process_children`

`export function process_children(nodes, initial, is_element, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/fragment.js:L19-L29][f3]

Walks template children, grouping adjacent Text/ExpressionTag nodes into sequences that share one text node and one update, and generating sibling references for other nodes.

Tracks `skipped` — the number of static nodes traversed past — and `prev`, the expression for the current anchor. get_node returns prev(is_text) when nothing was skipped, else a `$.sibling(prev(false), skipped, is_text?)` call. flush_node materializes the reference: if it is not already an identifier, a uniquely named var is pushed to state.init; prev then returns the id and skipped becomes 1 (the next node is the sibling call). flush_sequence: an all-Text sequence just increments skipped and pushes template text; otherwise a space-separated text node is pushed to the template, build_template_chunk produces the value, and a standalone expression (sequence length 1) flushes a 'text' node; the `$.set_text` update goes to state.update when has_state and not within bound contenteditable, else a direct `id.nodeValue = value` assignment goes to state.init. In the main loop, non-text nodes first flush any pending sequence; then a static element (is_static_element) merely increments skipped, a lone EachBlock inside an element is marked is_controlled (rendered without an extra anchor), and any other node gets a flushed anchor id placed in child_state.node before being visited. Trailing: a final sequence is flushed, and when skipped > 1 a `$.next(skipped-1)` statement is pushed to state.init to traverse to the last static node during hydration.

**Notes.**

- side_effect: Mutates node.metadata.is_controlled for a single EachBlock child of an element.
- condition: within_bound_contenteditable forces direct nodeValue writes even for stateful chunks.

calls: [build_template_chunk](r5-transform-client.md#u-d8d503fc4b7b), [Scope](r4-compiler-scope.md#u-01a82e58170d), [packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/fragment.js:is_static_element](r1-client-transform.md#u-c654162d4a2b)

**Uncertainties.**

- The `$.next`/`$.sibling` runtime contracts (argument meanings) are outside this file.
- State where template.push_text is recorded must be a state carrying the Template; the type is established elsewhere.

<a id="u-c654162d4a2b"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/fragment.js:is_static_element`

`function is_static_element(node, state)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/fragment.js:L129-L173][f3]

Decides whether a RegularElement can be baked entirely into the template string (no runtime attribute work).

False for: dynamic fragments, custom elements (their attributes go through properties), any non-Attribute attribute, event attributes, names that cannot be set statically, 'dir', value/checked on input/textarea, value on option, loading on img (lazy loading requires post-append application), and any attribute whose value is neither true (bare) nor a text attribute. Otherwise true.

calls: [is_custom_element_node](r4-compiler-node-model.md#u-ea1f0b51e1e8), [ast-js-attribute-helpers](r4-compiler-ast-utils.md#u-e05972fa52ab), [function::cannot_be_set_statically::4349](../../catalog.json)

<a id="u-0128ebcf4caf"></a>
### `AnimateDirective`

`export function AnimateDirective(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/AnimateDirective.js:L11-L28][f4]

Compiles an animate: directive into an `$.animation` call queued in state.after_update, so it runs after bind:this.

The directive name (parsed via parse_directive_name) is visited inside a thunk as the animation type; when node.expression is null (no expression) b.null is passed, otherwise the visited expression is wrapped in a thunk so it is lazily evaluated.

calls: [parse_directive_name](r5-transform-client.md#u-47fb5120ded1)

<a id="u-6379edcfd2b5"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/AttachTag.js:AttachTag`

`export function AttachTag(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/AttachTag.js:L10-L14][f5]

Serializes an {@attach ...} tag into an `$.attach` call that runs the attach expression against the current template node.

It builds the expression via build_expression, pushes `$.attach(node, () => expr)` into init, then continues traversal with context.next().

calls: [build_expression](r5-transform-client.md#u-cd5eb51d389f)

**Uncertainties.**

- Runtime behavior of `$.attach` and build_expression awaits lies outside this file.

<a id="u-34b00bddeeac"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/AwaitBlock.js:AwaitBlock`

`export function AwaitBlock(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/AwaitBlock.js:L14-L75][f6]

Serializes an {#await} block.

It pushes a template comment, builds the awaited expression as a thunk (respecting has_await), then constructs then/catch arrow callbacks when node.then/node.catch exist. Each branch context clones state with a fresh transform map so per-branch identifier transformers (from create_derived_block_argument) do not leak across branches; the branch body is visited and its statements prefixed with the argument declarations. The pending block, if present, becomes a `($$anchor) => ...` arrow. Finally it pushes an add_svelte_meta-wrapped `$.await(node, expression, pending|null, then, catch)` call into init. Returns nothing; output is via context.state mutation.

calls: [create_derived_block_argument](r1-client-transform.md#u-741970a13fda), [build_expression](r5-transform-client.md#u-cd5eb51d389f); uses: [add_svelte_meta](r5-transform-client.md#u-75700db42066)

**Uncertainties.**

- Whether the then branch state intentionally shares transform with context (spread of context.state.transform) vs catch which does not — visible difference in source, effect unproven.

<a id="u-741970a13fda"></a>
### `create_derived_block_argument`

`function create_derived_block_argument(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/AwaitBlock.js:L82-L110][f6]

Builds the derived argument value for an await block's then/catch parameter.

For an Identifier pattern it registers a `get_value` read transformer under that name and returns the identifier with no declarations. For destructuring patterns it visits the pattern, extracts its identifiers, and emits a block that reads `$.get($$source)` into the pattern and returns an object of the extracted identifiers; that block becomes a derived bound to `$$value`, and each extracted identifier is itself declared as a derived reading `$.get($$value).<name>`, each with a `get_value` transformer. Returns `{ id, declarations }` where declarations must precede the visited branch body.

calls: [create_derived](r3-client-transform-utils.md#u-d8c62e2be238), [extract_identifiers](r4-compiler-ast-utils.md#u-90eb95affc00)

<a id="u-bd7b8d09104e"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/ClassBody.js:ClassBody`

`export function ClassBody(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/ClassBody.js:L13-L111][f7]

Rewrites class bodies that contain state fields.

If the analysis has no entry for this ClassBody (legacy mode) it just continues traversal. Otherwise it builds a new body: for each public state field whose node is an AssignmentExpression (declared only in the constructor), it emits the backing key property plus getter/setter methods using `$.get`/`$.set`, passing a proxy flag for `$state` fields. It then walks the original definitions: non-PropertyDefinitions are visited as-is into the new body; PropertyDefinitions without a matching state field pass through; private (`#`) fields are rebuilt as plain property definitions from their visited initializer (dev adds a `$.tag` call naming `Class.#field`); public fields declared in the class body become the backing property with a dev `$.tag`'d initializer plus getter/setter pair. Public fields whose field.node is a different node (constructor-assigned) are skipped from the definition loop since the backing accessors were already emitted. Returns the rebuilt ClassBody node.

calls: [get_parent](r4-compiler-ast-utils.md#u-427249cf438e), [get_name](r4-compiler-node-model.md#u-99af92983a86)

**Uncertainties.**

- `should_proxy` is hard-coded `field.type === '$state' && true` with a TODO; the proxying condition is effectively always true for $state and may change.

<a id="u-a79e6f67903d"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/ExportNamedDeclaration.js:ExportNamedDeclaration`

`export function ExportNamedDeclaration(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/ExportNamedDeclaration.js:L9-L19][f8]

Routes export declarations during client transform.

When transforming the instance (context.state.is_instance): a wrapped declaration is visited and its result returned; a bare export (no declaration) becomes b.empty. Outside the instance transform it calls context.next() to continue default traversal.

<a id="u-2b757b558903"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/ImportDeclaration.js:ImportDeclaration`

`export function ImportDeclaration(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/ImportDeclaration.js:L9-L16][f9]

Moves import declarations out of the component body.

When the current state has a 'hoisted' property, the declaration is pushed to state.hoisted and b.empty is returned (removing it from place). Otherwise context.next() applies default handling.

<a id="u-2bcd841aee06"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/KeyBlock.js:KeyBlock`

`export function KeyBlock(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/KeyBlock.js:L11-L38][f10]

Serializes {#key expr} blocks.

After a template comment it builds the key expression; with awaits the key thunk reads `$$key`. The fragment is visited into an arrow and combined into an add_svelte_meta-wrapped `$.key(node, key, ($$anchor) => body)` statement. When has_await, that statement is wrapped in `$.async(node, [thunk], (node, $$key) => ...)` before being pushed to init; otherwise the statement goes to init directly.

uses: [add_svelte_meta](r5-transform-client.md#u-75700db42066); calls: [build_expression](r5-transform-client.md#u-cd5eb51d389f)

<a id="u-0676455245be"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/SvelteComponent.js:SvelteComponent`

`export function SvelteComponent(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/SvelteComponent.js:L9-L12][f11]

Compiles <svelte:component> via build_component using the synthetic name '$$component', pushing the resulting declaration into state.init.

calls: [component-js-build-component](r5-transform-client.md#u-af8f6b0917f6)

<a id="u-41ee72c88b7f"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/SvelteHead.js:SvelteHead`

`export function SvelteHead(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/SvelteHead.js:L10-L20][f12]

Compiles <svelte:head> into an `$.head` call pushed to state.init, passing an arrow function taking $$anchor whose body is the visited fragment.

Attributes are not handled (TODO comment).

<a id="u-d6475f075d4a"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/TitleElement.js:TitleElement`

`export function TitleElement(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/TitleElement.js:L10-L23][f13]

Compiles <title> into a `$.document.title = value` assignment.

build_template_chunk visits the fragment contents, yielding the value expression and has_state; when the chunk has state the assignment is pushed to state.update (re-evaluated on invalidation), otherwise to state.init (run once).

calls: [build_template_chunk](r5-transform-client.md#u-d8d503fc4b7b)

<a id="u-f5935e5dfe7b"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/UpdateExpression.js:UpdateExpression`

`export function UpdateExpression(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/UpdateExpression.js:L11-L55][f14]

Serializes `++`/`--` expressions.

Incrementing or decrementing a private state field (`this.#x` tracked in state_fields) becomes `$.update(this.#x)` or `$.update_pre(...)` for prefix form, with a `-1` literal argument for `--`. For other arguments: anything that is not an Identifier or MemberExpression throws 'An impossible state was reached'. When the mutation target is a bare identifier with an `update` transformer, the transformer rewrites the whole node (ownership checks are skipped since this is reassignment, not mutation). Otherwise traversal proceeds via context.next(); if the target object has a `mutate` transformer it wraps the resulting expression to trigger reactivity, and validate_mutation performs the final ownership check, returning either the update or a validated version.

**Notes.**

- failure: Non-identifier, non-member arguments throw a generic Error rather than a diagnostic.

calls: [validate_mutation](r5-transform-client.md#u-a58215b09609), [object](r4-compiler-ast-utils.md#u-2f2548aeaec6)

<a id="u-123cf8349bd2"></a>
### `ForOfStatement`

`export function ForOfStatement(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/ForOfStatement.js:L10-L25][f15]

Wraps awaited for-of loops to flag reactivity loss in dev.

Only when node.await is set, dev is true, the await_reactivity_loss warning is not ignored (is_ignored), and experimental async is enabled does it transform: left, right, and body are visited, the right side becomes `$.for_await_track_reactivity_loss(argument)`, and a for-of with await=true is returned. All other cases fall through to context.next().

calls: [is_ignored](r5-compiler-state-utils.md#u-468324b42cee)

<a id="u-4517247cbf4b"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/ArrowFunctionExpression.js:ArrowFunctionExpression`

`export function ArrowFunctionExpression(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/ArrowFunctionExpression.js:L9-L11][f16]

Delegates arrow function nodes to the shared visit_function helper, returning its result; it adds no logic of its own.

calls: [packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/function.js:visit_function](r5-transform-client.md#u-888d94f48ee5)

<a id="u-e62b6e822f4a"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/FunctionExpression.js:FunctionExpression`

`export function FunctionExpression(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/FunctionExpression.js:L9-L11][f17]

Delegates function expression nodes to the shared visit_function helper, returning its result; no additional logic.

calls: [packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/function.js:visit_function](r5-transform-client.md#u-888d94f48ee5)

<a id="u-57396322111a"></a>
### `types-d-ts-state-interfaces`

`export interface ClientTransformState extends TransformState` · [packages/svelte/src/compiler/phases/3-transform/client/types.d.ts:L18-L46][f18]

Declares the client transform state contracts.

ClientTransformState extends TransformState with in_constructor (rewrites this.foo to this.#foo.value), in_derived (directly inside $derived, not $derived.by), is_instance (inside <script>), and a transform record whose per-name read/assign/mutate/update callbacks rewrite reads, assignments, member mutations, and updates into internal runtime calls. ComponentClientTransformState adds component-level fields: analysis/options, hoisted statements, event names, store_to_invalidate, init/update/after_update/consts statement buckets, a Memoizer, the Template, namespace/bound_contenteditable metadata, preserve_whitespace, the current anchor node, legacy_reactive_imports and legacy_reactive_statements, and instance/module hoisted snippet lists. Context/Visitors and ComponentContext/ComponentVisitors alias zimmerframe Context/Visitors over the respective states. A syntax-ERROR node was reported near line 1 of this file, but chunk coverage is preserved.

**Uncertainties.**

- The reported ERROR node near line 1 could mean part of the header import block did not parse; the declared interfaces themselves were covered.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/Program.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/declarations.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/fragment.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/AnimateDirective.js
[f5]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/AttachTag.js
[f6]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/AwaitBlock.js
[f7]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/ClassBody.js
[f8]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/ExportNamedDeclaration.js
[f9]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/ImportDeclaration.js
[f10]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/KeyBlock.js
[f11]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/SvelteComponent.js
[f12]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/SvelteHead.js
[f13]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/TitleElement.js
[f14]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/UpdateExpression.js
[f15]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/ForOfStatement.js
[f16]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/ArrowFunctionExpression.js
[f17]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/FunctionExpression.js
[f18]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/types.d.ts
