# Easing Functions

**Capability.** A family of pure easing functions mapping a progress scalar to an eased scalar, adapted from mattdesl/eases under MIT.

Used by animation configurations (e.g., AnimationConfig.easing); each export is a standalone t → value curve.

Parent: [Shared Utilities and Public Contracts](r3-shared.md)

## Units (1)

<a id="u-bcdfc0779439"></a>
### `index.js-easing-functions`

`export function linear(t)` · [packages/svelte/src/easing/index.js:L10-L12][f1]

Exports a family of pure easing functions mapping a progress scalar `t` (typically 0..1) to an eased scalar, adapted from mattdesl/eases under MIT.

Variants per curve family: identity (`linear`); polynomial families back/cubic/quad/quart/quint each with In, Out, and InOut flavors (e.g. cubicIn is t³, cubicOut is (t-1)³+1, backIn/Out overshoot below 0 or above 1 by design); bounceIn/Out/InOut where bounceOut picks one of four quadratic pieces by thresholding t at 4/11, 8/11, and 9/10, and In/InOut derive by symmetry (1 - bounceOut(1-t) etc.); circ family using square roots; elastic and sine families using trigonometric and exponential terms; expo family with special cases returning t itself exactly at 0 and/or 1 (expoIn at t===0, expoOut at t===1, expoInOut at either). The InOut flavors split at t<0.5 (or via `t *= 2` doubling) and scale the half-range result. All are stateless, side-effect free, and defined for any numeric input, though values outside 0..1 are not clamped and results for such inputs follow directly from the formulas.

calls: [index.js-easing-functions](r3-shared-easing.md#u-bcdfc0779439)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/easing/index.js
