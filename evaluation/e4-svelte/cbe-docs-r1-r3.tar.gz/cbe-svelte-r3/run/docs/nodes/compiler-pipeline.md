# Compiler Pipeline

**Capability.** Turns Svelte source text into client and server JavaScript by parsing, analyzing (validation, references, metadata, scopes), and transforming for each target, supported by shared compiler state, AST/sourcemap utilities, and the Svelte 4→5 migration tool built on the same analysis.

Use this subtree when changing how templates and modules are compiled. Phases run sequentially: parse produces the AST, analyze annotates and validates it, transform emits output. Shared compiler utilities are kept apart from the phase visitors that consume them; region evidence shows heavy mutual traffic with both runtimes (region-0005↔region-0004, region-0005↔region-0002), consistent with the compiler emitting code that calls into the runtime and reusing shared/public contracts.

**Children.**

- [Svelte Monorepo](r5-svelte.md) `r5-svelte` · 0 unit(s)

**Depends on.**

- [Client Runtime](client-runtime.md) · graph-confirmed · 144 edge(s)
- [Public API, Types & Reactive Primitives](public-api-types.md) · graph-confirmed · 71 edge(s)

**Depended on by.**

- [Client Runtime](client-runtime.md) · graph-confirmed · 66 edge(s)
- [Public API, Types & Reactive Primitives](public-api-types.md) · graph-confirmed · 46 edge(s)
- [Svelte Repository](svelte-repo.md) · containment · → 0 / ← 0 edge(s) (ancestor direct units and descendant subtree; → follows ` svelte-repo ` → ` compiler-pipeline `)

Parent: [Svelte Repository](svelte-repo.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
