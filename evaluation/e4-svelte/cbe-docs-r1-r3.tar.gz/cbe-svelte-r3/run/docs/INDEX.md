# Codebase Explorer

## How to read this report

Start with the responsibility tree in INDEX. Open a node page for your maintenance question, then choose a unit.
Node pages explain responsibilities. `catalog.json` stores full signatures, source ranges, folded members, relation evidence, and graph edges.
Set `RUN` to the absolute path of this run directory. Find an id, then read its explanation or frozen source.

```sh
cbe find --run-dir "$RUN" --term "SEARCH_TERM"
cbe query --run-dir "$RUN" --id "$ID"
cbe source --run-dir "$RUN" --id "$ID" --context 2
```

`ID` can be a unit id, symbol id, or file path. Commands return the content directly.
`source` reads frozen source and verifies its digest first.
The catalog also stores reverse graph edges, statuses, and raw evidence.

## Responsibility tree

- [Svelte Repository](nodes/svelte-repo.md) (0 units)
  - [Svelte Repository](nodes/r1-svelte-monorepo.md) (0 units)
    - [Compiler](nodes/r1-compiler.md) (0 units)
      - [Parse Phase](nodes/r1-compiler-parse.md) (0 units)
        - [Markup & Attribute Parsing](nodes/r1-markup-tag-parsing.md) (8 units)
          - [element](nodes/r1-markup-tag-parsing.md#u-bc08cb4e57fa) · Parses one tag (comment, closing tag, or opening element) at the current parser position and appends the resulting node or pushes the element onto the parse stack.
        - [Expression & Script Reading](nodes/r1-script-expression-parsing.md) (3 units)
          - [read_expression](nodes/r1-script-expression-parsing.md#u-793d43872467) · Parses a JS expression at the parser's index using parse_expression_at, then repairs the index around Acorn quirks.
        - [HTML Entity Decoding](nodes/r1-html-entity-decoding.md) (4 units)
          - [decode_character_references](nodes/r1-html-entity-decoding.md#u-a03f13997ae5) · Replaces HTML character references in `html` with their literal characters, selecting the content or attribute-value pattern built by get_entity_pattern.
        - [TypeScript Node Stripping](nodes/r1-typescript-stripping.md) (2 units)
          - [remove_typescript_nodes](nodes/r1-typescript-stripping.md#u-1e95bda7f290) · Entry point that walks the given AST with zimmerframe using the module's TypeScript-stripping visitors and no state, returning the transformed tree of the same nominal type.
        - [Legacy AST Conversion](nodes/r1-legacy-ast-conversion.md) (2 units)
          - [legacy-js-convert](nodes/r1-legacy-ast-conversion.md#u-4723dd340fbf) · convert walks the modern Svelte AST with zimmerframe and rebuilds the Svelte 4 legacy AST node by node.
      - [Analyze Phase](nodes/r1-compiler-analyze.md) (0 units)
        - [CSS Selector Pruning](nodes/r1-css-prune.md) (19 units)
          - [prune](nodes/r1-css-prune.md#u-41775043a205) · Walks a stylesheet to decide which complex selectors match one element, marking matching selectors used so pruning keeps them.
        - [Accessibility Checks](nodes/r1-a11y-checks.md) (4 units)
          - [check_element](nodes/r1-a11y-checks.md#u-0f7a175a707e) · Runs the full set of a11y warning checks on one element node during analysis.
        - [Shared Analysis Visitors & Helpers](nodes/r1-analysis-visitors.md) (10 units)
          - [TransitionDirective](nodes/r1-analysis-visitors.md#u-7f3ea7461731) · Marks the enclosing fragment subtree dynamic because a transition directive depends on runtime state, then continues traversal.
      - [Compiler Warning Infrastructure](nodes/r1-compiler-diagnostics-infrastructure.md) (3 units)
        - [warnings-js-warning-plumbing](nodes/r1-compiler-diagnostics-infrastructure.md#u-31c5078caed8) · Defines the compiler's warning diagnostic class and the shared filter-and-record gate every warning emitter uses.
      - [Transform Phase](nodes/r1-compiler-transform.md) (0 units)
        - [Client Transform](nodes/r1-client-transform.md) (21 units)
          - [Program](nodes/r1-client-transform.md#u-ba1f8c9b6c22) · Seeds the component's transform table before the body is visited, then continues traversal.
        - [Server Transform](nodes/r1-server-transform.md) (17 units)
          - [transform-server-js-server-component](nodes/r1-server-transform.md#u-3bff6efcb646) · Transforms a component analysis into the SSR server-side Program.
        - [Shared Assignment Driver](nodes/r1-shared-assignment-transform.md) (1 units)
          - [visit_assignment_expression](nodes/r1-shared-assignment-transform.md#u-b43a982ab161) · Shared driver for transforming assignment expressions in client and server output, delegating per-target work to a caller-supplied build_assignment.
      - [Preprocessing](nodes/r1-preprocess.md) (10 units)
        - [preprocess](nodes/r1-preprocess.md#u-049035fc1450) · Entry point that runs a preprocessor group or list of groups over component source and returns the combined Processed result.
    - [Client Runtime](nodes/r1-client-runtime.md) (0 units)
      - [DOM Template Blocks](nodes/r1-dom-blocks.md) (11 units)
        - [if-js-if-block](nodes/r1-dom-blocks.md#u-e0280b89cb0f) · Implements {#if}/{:else if} blocks.
      - [Element Bindings](nodes/r1-element-bindings.md) (8 units)
        - [bind_value](nodes/r1-element-bindings.md#u-01d2720075cb) · Two-way binds an input's value.
      - [Event System & Delegation](nodes/r1-event-system.md) (7 units)
        - [events.js-create-event](nodes/r1-event-system.md#u-26b31b85b822) · Attaches a DOM event listener that integrates with Svelte's delegation system and returns the handler for later removal.
      - [Task Scheduling](nodes/r1-task-scheduling.md) (2 units)
        - [task-js-queues](nodes/r1-task-scheduling.md#u-08b6b6ebaf85) · Micro-task and idle-task scheduling queues.
      - [Async Reactivity](nodes/r1-async-reactivity.md) (8 units)
        - [flatten](nodes/r1-async-reactivity.md#u-c50793421b66) · Flattens sync and async expression getters into derived-backed values passed to a callback, used by template and attribute effects.
      - [Reactivity Type Contracts](nodes/r1-client-reactivity-types.md) (8 units)
        - [Signal](nodes/r1-client-reactivity-types.md#u-d7be5ea90299) · Type declaration only: Signal defines the flag bitmask f and write version wv shared by all signals.
      - [Dev Diagnostics & HMR](nodes/r1-client-dev-diagnostics.md) (11 units)
        - [warnings.js-warning-emitters](nodes/r1-client-dev-diagnostics.md#u-a21b565811ae) · Generated dev-mode warning emitters; each function prints a formatted console.warn when DEV is true — with %c bold/normal styling, the message text, and a https://svelte.dev/e/<code> link — and otherwise a single-line console.warn of just the URL.
      - [Legacy Client Compatibility](nodes/r1-legacy-compat-client.md) (4 units)
        - [capture_signals](nodes/r1-legacy-compat-client.md#u-901893964aa4) · Captures all signals read during fn by running untrack(fn) with the module-level captured_signals set to a new Set, so source writes record reads into that set instead of normal dependency tracking.
    - [Server Runtime](nodes/r1-server-runtime.md) (12 units)
      - [packages/svelte/src/internal/server/context.js:context.js module code (L1–L13)](nodes/r1-server-runtime.md#u-520828fc5cd8) · Module imports and the exported current_component state variable for the server component stack.
    - [Shared Runtime Utilities](nodes/r1-shared-runtime.md) (6 units)
      - [packages/svelte/src/internal/shared/clone.js:snapshot](nodes/r1-shared-runtime.md#u-bfcc537be9f1) · Public $state.snapshot implementation producing a deep plain-data copy of reactive state.
    - [Public & Authoring APIs](nodes/r1-public-api.md) (0 units)
      - [Motion \(Spring & Tween\)](nodes/r1-motion.md) (5 units)
        - [index.js module code (L1–L32)](nodes/r1-motion.md#u-fe5771212e14) · Re-exports everything from spring.js and tweened.js and eagerly creates prefersReducedMotion, a reactive MediaQuery for '(prefers-reduced-motion: reduce)'.
      - [Transitions](nodes/r1-transitions.md) (8 units)
        - [blur](nodes/r1-transitions.md#u-bc2c7a4069fc) · Builds a TransitionConfig animating opacity and a CSS blur filter.
      - [Reactive Wrapper Classes](nodes/r1-reactive-collections.md) (4 units)
        - [SvelteDate](nodes/r1-reactive-collections.md#u-cb648e924acc) · A Date subclass that tracks its time value in a reactive source (#time, initialized from super.getTime()) so reads in effects/deriveds re-run when the date changes.
      - [Store Contract](nodes/r1-store-compat.md) (2 units)
        - [public-d-ts-store](nodes/r1-store-compat.md#u-e073ffe38ead) · Public store type contracts.
      - [Attachments](nodes/r1-attachments.md) (2 units)
        - [createAttachmentKey](nodes/r1-attachments.md#u-c36056169480) · Returns a new `Symbol(ATTACHMENT_KEY)` that the spread system recognizes as an attachment when the containing object is spread onto an element, offering a programmatic alternative to `{@attach ...}`.
      - [Rune Ambient Typings](nodes/r1-rune-ambient-typings.md) (8 units)
        - [ambient-dts-state](nodes/r1-rune-ambient-typings.md#u-f90a1ae6e00e) · Ambient declarations for the $state rune: the callable overloads return T for `($state(initial))` and `T | undefined` for the no-argument form; these are compiler-recognized shapes, not runtime functions implemented here.
      - [Legacy Class-Component Adapter \(Server\)](nodes/r1-legacy-component-adapter.md) (1 units)
        - [packages/svelte/src/legacy/legacy-server.js:asClassComponent](nodes/r1-legacy-component-adapter.md#u-97e8d38a4382) · Server-side adapter converting a Svelte 5 component into a Svelte 4-style class constructor: delegates construction to `as_class_component` from legacy-client, then attaches a `render(props, { context })` method to the constructor.
    - [Repository Tooling](nodes/r1-tooling.md) (0 units)
      - [Benchmarks](nodes/r1-benchmarks.md) (4 units)
        - [kairo_broad.js](nodes/r1-benchmarks.md#u-813578b5fd39) · Benchmarks a wide fan-out graph: setup() creates 50 derived pairs (each current = head + i, current2 = current + 1) each with a render effect incrementing a shared counter, all inside one effect_root.
      - [Playground Sandbox](nodes/r1-playground-sandbox.md) (6 units)
        - [download.js module code (L1–L52)](nodes/r1-playground-sandbox.md#u-3a2d44014938) · Downloads a Svelte playground app from a URL argument and writes its files into src/, decoding either a hash payload or the API by id.
      - [ESLint Configuration](nodes/r1-eslint-config.md) (2 units)
        - [create](nodes/r1-eslint-config.md#u-34b493301cfd) · Creates a lint rule visitor that scans each program's full source text for references to the Svelte compiler and reports the first occurrence.
  - [Compiler Pipeline](nodes/compiler-pipeline.md) (0 units)
    - [Svelte Monorepo](nodes/r5-svelte.md) (0 units)
      - [Compiler Pipeline](nodes/r5-compiler.md) (0 units)
        - [Template Parsing](nodes/r5-compiler-parse.md) (17 units)
          - [acorn.js-comment-handlers](nodes/r5-compiler-parse.md#u-25b8c96fd2a2) · Factory returning two collaborating closures that give Acorn comment support, which it lacks natively; comments back `svelte-ignore` handling in JS code and preservation for formatters.
        - [Analysis Phase](nodes/r5-compiler-analyze.md) (0 units)
          - [CSS Analysis](nodes/r5-analyze-css.md) (10 units)
            - [analyze_css](nodes/r5-analyze-css.md#u-f762711e5ae7) · Entry point that analyzes a component's stylesheet: builds a CssState sharing the analysis's keyframes array, with rule null and the component analysis, then walks the stylesheet with the css_visitors table so Atrule, ComplexSelector, RelativeSelector, Rule, and NestingSelector validation and metadata propagation run over the whole CSS tree.
          - [AST Analysis Visitors](nodes/r5-analyze-visitors.md) (19 units)
            - [check_graph_for_cycles](nodes/r5-analyze-visitors.md#u-9450956ffc9b) · Detects a cycle in a directed graph given as an edge list and returns one cycle's nodes, or undefined if acyclic.
        - [Transform Phase](nodes/r5-compiler-transform.md) (0 units)
          - [Transform Entry & Result Assembly](nodes/r5-transform-entry.md) (4 units)
            - [transform_component](nodes/r5-transform-entry.md#u-be9df8c13257) · Turns an analyzed component into a CompileResult with printed JavaScript and optional CSS.
          - [Client Codegen Visitors](nodes/r5-transform-client.md) (25 units)
            - [utils-js-memoizer](nodes/r5-transform-client.md#u-6874463c92d7) · Extracts complex expressions (calls, awaits) from templates, replacing them with generated `$0`, `$1`, ...
          - [Server Codegen Visitors](nodes/r5-transform-server.md) (6 units)
            - [packages/svelte/src/compiler/phases/3-transform/server/visitors/CallExpression.js:CallExpression](nodes/r5-transform-server.md#u-095e9ef68802) · Replaces server-side rune calls with static or runtime substitutes.
        - [Compiler State & AST Utilities](nodes/r5-compiler-state-utils.md) (16 units)
          - [builders-js-node-factories](nodes/r5-compiler-state-utils.md#u-f0ea3a9aa39d) · Factory helpers that construct plain ESTree node objects for code generation; each returns a fresh literal object with no side effects.
        - [Source Maps & Preprocessing](nodes/r5-compiler-sourcemaps.md) (19 units)
          - [mapped_code.js-mapped-code](nodes/r5-compiler-sourcemaps.md#u-9ed57a767ba0) · Carries a code string plus a decoded source map through preprocessing and transformation, so mappings stay accurate across string rewrites.
      - [Client Runtime](nodes/r5-runtime-client.md) (0 units)
        - [Signal Reactivity Core](nodes/r5-client-reactivity.md) (16 units)
          - [set-js-svelteset](nodes/r5-client-reactivity.md#u-3d5a1739f21d) · Reactive Set subclass: reading contents (has/iteration/size/read methods) registers dependencies so effects and deriveds re-run on mutation; values are not deeply reactive.
        - [DOM Operations & Elements](nodes/r5-client-dom.md) (9 units)
          - [operations-js-node-factories](nodes/r5-client-dom.md#u-3edbb11427a1) · Element and fragment construction helpers.
        - [Error & Pending Boundaries](nodes/r5-client-boundary.md) (7 units)
          - [boundary-js-boundary-class](nodes/r5-client-boundary.md#u-4e4a6d345016) · Boundary class coordinating a boundary's main, pending, and failed effects inside one preserved, transparent block effect (flags EFFECT_TRANSPARENT | EFFECT_PRESERVED | BOUNDARY_EFFECT); the exported boundary(node, props, children) merely constructs it.
        - [Element Bindings](nodes/r5-client-bindings.md) (11 units)
          - [bind_online](nodes/r5-client-bindings.md#u-40e4240d9329) · Calls update with navigator.onLine whenever the window fires online or offline.
        - [Custom Element Hosting](nodes/r5-client-custom-elements.md) (4 units)
          - [custom-element.js-create-custom-element](nodes/r5-client-custom-elements.md#u-700d12a35f8e) · Turns a Svelte component constructor into a custom element class and registers it on Component.element.
        - [Dev-Mode Diagnostics](nodes/r5-client-dev.md) (5 units)
          - [init_array_prototype_warnings](nodes/r5-client-dev.md#u-3c0065301141) · Patches Array.prototype.indexOf, lastIndexOf, and includes for dev builds to detect equality mismatches caused by reactive proxies: after delegating to the original method, if the result is a miss (-1 or false), it scans the array comparing items through get_proxied_value and warns state_proxy_equality_mismatch with the method name if an unwrapped item matches.
        - [Spring Motion](nodes/r5-client-motion.md) (4 units)
          - [packages/svelte/src/motion/spring.js:Spring](nodes/r5-client-motion.md#u-6e9a0bc3364a) · Reactive spring class whose #target and #current are signals; assigning spring.target animates spring.current toward it.
      - [Server Runtime](nodes/r5-runtime-server.md) (13 units)
        - [Payload](nodes/r5-runtime-server.md#u-88f15d8dfda3) · Server render output buffer holding body HTML, CSS entries, select_value tracking, and an owned HeadPayload.
      - [Shared Runtime Infrastructure](nodes/r5-runtime-shared.md) (10 units)
        - [errors.js-generated-error-throwers](nodes/r5-runtime-shared.md#u-aa3a4430105f) · Generated error-throwing helpers used by compiled output, all following one pattern: in dev (DEV from esm-env) they throw an Error whose name is 'Svelte error' and whose message is '<code>\n<long description>\n<doc url>'; in production they throw a bare Error whose message is only the doc URL.
      - [Public Element Types](nodes/r5-public-types.md) (8 units)
        - [type-aliases](nodes/r5-public-types.md#u-a17618b45fd1) · Declares the shared attribute value unions and typed event-handler aliases used by every element interface in this file.
      - [Repository Tooling](nodes/r5-tooling.md) (0 units)
        - [Reactivity Benchmarks](nodes/r5-benchmarks.md) (4 units)
          - [runner.js module code (L1–L10)](nodes/r5-benchmarks.md#u-0b0dc218fb67) · Forked child-process runner that executes each reactivity benchmark and reports results to the parent process.
        - [Sandbox Playground](nodes/r5-playgrounds.md) (5 units)
          - [create-app-svelte.js module code (L1–L13)](nodes/r5-playgrounds.md#u-dde2e710e027) · Seeds src/main.svelte from a template file when it does not already exist; directory creation errors are ignored, and nothing happens if the destination exists.
  - [Client Runtime](nodes/client-runtime.md) (0 units)
    - [Svelte Compiler and Runtime](nodes/r4-svelte-monorepo.md) (0 units)
      - [Benchmarking Harness](nodes/r4-benchmarking.md) (9 units)
        - [run.js module code (L1–L55)](nodes/r4-benchmarking.md#u-8a0ea15faff6) · Runs all benchmark suites sequentially at module load and prints cumulative timings.
      - [Build Scripts and Generated Sources](nodes/r4-build-codegen.md) (7 units)
        - [generate-types.js module code (L1–L85)](nodes/r4-build-codegen.md#u-a7ff57214266) · Top-level .d.ts generation for the svelte package.
      - [Shared Source Utilities](nodes/r4-shared-source-utilities.md) (4 units)
        - [escape_html](nodes/r4-shared-source-utilities.md#u-0f499dd45547) · Escapes HTML-sensitive characters in a stringified value for safe insertion into markup or attribute strings.
      - [Compiler Pipeline](nodes/r4-compiler.md) (0 units)
        - [Compiler Type Declarations](nodes/r4-compiler-types.md) (3 units)
          - [index.d.ts-compile-api](nodes/r4-compiler-types.md#u-9ca884f55142) · Declares the public compiler API types.
        - [Parsing and Lexical Helpers](nodes/r4-compiler-parse.md) (23 units)
          - [text](nodes/r4-compiler-parse.md#u-36401d8c3a23) · Consumes characters until the end of the template, a '<', or a '{', appending a Text node whose raw is the consumed slice and whose data is the raw with character references decoded (attribute-context decoding disabled).
        - [Shared Analysis Validation](nodes/r4-analyze-shared-validation.md) (10 units)
          - [ensure_no_module_import_conflict](nodes/r4-analyze-shared-validation.md#u-ddca3e44b963) · Rejects instance-scope declarations that clash with <script module> imports.
        - [Semantic Analysis Visitors](nodes/r4-analyze-visitors.md) (19 units)
          - [AttachTag](nodes/r4-analyze-visitors.md#u-cda1a6710afe) · Marks the enclosing fragment subtree dynamic (an attach tag cannot be statically hoisted) and continues traversal with state.expression set to the node's metadata.expression so descendant expressions record call/state flags onto it.
        - [Scope and Binding Model](nodes/r4-compiler-scope.md) (9 units)
          - [Binding](nodes/r4-compiler-scope.md#u-0c91df12a429) · Tracks one declared name: its declaring scope and identifier node, binding kind, declaration kind, initializer, references, and mutation flags.
        - [Node Factories and Metadata Model](nodes/r4-compiler-node-model.md) (9 units)
          - [create_attribute](nodes/r4-compiler-node-model.md#u-16d11cbbd59b) · Factory building a plain AST.Attribute node from a name, start/end positions and a value, with fresh metadata: delegated is null and needs_clsx is false.
        - [AST Manipulation Utilities](nodes/r4-compiler-ast-utils.md) (14 units)
          - [_extract_paths](nodes/r4-compiler-ast-utils.md#u-9013e97c276b) · Recursively walks a destructuring pattern against an initial value expression, appending path records and intermediate inserts.
        - [Client Static Template Emission](nodes/r4-transform-template.md) (3 units)
          - [Template](nodes/r4-transform-template.md#u-f09b36ebd45e) · Accumulates a component's static template as a lightweight node tree and emits it as an HTML string or a JS array literal.
        - [Client Code Transformation](nodes/r4-transform-client.md) (16 units)
          - [BinaryExpression](nodes/r4-transform-client.md#u-61fecc929533) · In dev replaces equality operators with runtime helpers to handle proxy semantics: `===`/`!==` become `$.strict_equals(left, right, false?)` and `==`/`!=` become `$.equals(left, right, false?)`, with the trailing boolean false argument emitted only for the negated variants.
        - [Server \(SSR\) Code Transformation](nodes/r4-transform-server.md) (5 units)
          - [packages/svelte/src/compiler/phases/3-transform/server/visitors/PropertyDefinition.js:PropertyDefinition](nodes/r4-transform-server.md#u-518018776eef) · Strips rune wrappers from class property initializers in runes mode.
      - [Effect System](nodes/r4-runtime-effects.md) (33 units)
        - [effects-js-module-regions](nodes/r4-runtime-effects.md#u-e76707ac36a4) · Non-behavioral regions of effects.js: import headers and inter-symbol gaps containing only type annotations and blank lines.
      - [Signals, Deriveds, and Proxies](nodes/r4-runtime-signals.md) (13 units)
        - [deriveds-async-derived](nodes/r4-runtime-signals.md#u-0dbfaaba8bef) · Creates an async derived: a source signal fed by an async_effect that repeatedly calls fn, tracks its promise, and pushes resolved values or errors into the source via internal_set.
      - [Runtime DOM Blocks](nodes/r4-runtime-dom-blocks.md) (7 units)
        - [css_props](nodes/r4-runtime-dom-blocks.md#u-c71adbe36cde) · Applies dynamic CSS custom properties to an element via a render effect.
      - [Element Bindings and Behaviors](nodes/r4-runtime-element-bindings.md) (16 units)
        - [bind_active_element](nodes/r4-runtime-element-bindings.md#u-63ddea66ca81) · Binds a callback to changes of document.activeElement via focusin/focusout listeners on document.
      - [Legacy Public API](nodes/r4-runtime-legacy.md) (9 units)
        - [afterUpdate](nodes/r4-runtime-legacy.md#u-3eabc3a794df) · Registers a post-update callback (legacy only, deprecated in favor of $effect).
      - [Runtime Dev-Mode Instrumentation](nodes/r4-runtime-dev.md) (13 units)
        - [cleanup_styles](nodes/r4-runtime-dev.md#u-5a39dee4043b) · Removes all style elements registered under a hash and deletes the hash entry from the registry.
  - [Server & Shared Runtime](nodes/server-and-shared-runtime.md) (0 units)
    - [Svelte Compiler and Runtime](nodes/r3-svelte.md) (1 units)
      - [check-treeshakeability.js-bundle-code](nodes/r3-svelte.md#u-df4ca4955d27) · Builds a Rollup bundle from an in-memory entry source string and returns the bundled JavaScript so callers can test whether an import tree shakes to nothing.
      - [Compiler Pipeline](nodes/r3-compiler.md) (0 units)
        - [Compiler Public Entry](nodes/r3-compiler-entry.md) (6 units)
          - [compile](nodes/r3-compiler-entry.md#u-a54e3b374c84) · Compile Svelte component source into a JavaScript module by running the parse–analyze–transform pipeline.
        - [Analysis Phase](nodes/r3-analyze-phase.md) (0 units)
          - [Analysis Driver](nodes/r3-analyze-driver.md) (6 units)
            - [index-js-analyze-component](nodes/r3-analyze-driver.md#u-ff1515d9bcd2) · Main analysis entry for a component, combining pre-walk setup, the visitor walk over module/instance/template ASTs, and post-walk CSS/element fixups.
          - [Analysis Visitors](nodes/r3-analyze-visitors.md) (18 units)
            - [packages/svelte/src/compiler/phases/2-analyze/visitors/ClassBody.js:ClassBody](nodes/r3-analyze-visitors.md#u-2a9d6ef13421) · Analyzes class bodies in runes mode to inventory state fields and deconflict private keys.
        - [Client Transform Phase](nodes/r3-client-transform.md) (3 units)
          - [transform-client-imports-and-visitors](nodes/r3-client-transform.md#u-a04bf2770de7) · Assembles the client-side visitor map used by zimmerframe walks and a special '_' visitor that re-scopes name transforms at scope boundaries.
          - [Client Transform Utilities](nodes/r3-client-transform-utils.md) (8 units)
            - [build_getter](nodes/r3-client-transform-utils.md#u-66a19e20e1f1) · Builds the read expression for an identifier, or returns the node unchanged.
          - [Client Transform Visitors](nodes/r3-client-transform-visitors.md) (14 units)
            - [BlockStatement](nodes/r3-client-transform-visitors.md#u-113cc5a16382) · Serializes a plain block statement.
        - [Server Transform Phase](nodes/r3-server-transform.md) (11 units)
          - [packages/svelte/src/compiler/phases/3-transform/server/visitors/Component.js:Component](nodes/r3-server-transform.md#u-fb63ecc7b839) · Handles a <Component /> node by delegating to build_inline_component with an identifier for the component's name.
        - [Svelte 4 to 5 Migration](nodes/r3-migration.md) (0 units)
          - [Migration Driver and Helpers](nodes/r3-migrate-entry.md) (6 units)
            - [index-js-migrate](nodes/r3-migrate-entry.md#u-50c4a7a5de79) · Performs a best-effort Svelte 4 → Svelte 5 (runes, event attributes, snippets) migration of a source string and returns `{ code }`.
          - [Migration Script Visitors](nodes/r3-migrate-script-visitors.md) (7 units)
            - [index-js-variabledeclaration](nodes/r3-migrate-script-visitors.md#u-7ca9a10d7605) · Rewrites legacy variable declarations in the instance scope into runes (the visitor does nothing outside the instance scope, and when `analysis.runes` is already true it only records an existing `$props` rune's position and sets `has_props_rune`).
          - [Migration Template Visitors](nodes/r3-migrate-template-visitors.md) (9 units)
            - [index-js-trivial-template-visitors](nodes/r3-migrate-template-visitors.md#u-cb87d88ba279) · Small template visitors.
      - [Runtime](nodes/r3-runtime.md) (0 units)
        - [Client Runtime](nodes/r3-client-runtime.md) (0 units)
          - [Client Hydration State](nodes/r3-client-hydration.md) (6 units)
            - [hydration-js-state](nodes/r3-client-hydration.md#u-c504e0cdf2f3) · Small hydration-state helpers sharing module-level state.
          - [Client Template Factories](nodes/r3-client-template.md) (11 units)
            - [template-js-namespace-wrappers](nodes/r3-client-template.md#u-5821b8bff12d) · Public one-line wrappers around from_namespace: from_svg passes the 'svg' namespace and from_mathml passes 'math', both forwarding content and flags unchanged.
          - [Client Control Blocks and CSS](nodes/r3-client-blocks.md) (3 units)
            - [packages/svelte/src/internal/client/dom/blocks/key.js:key](nodes/r3-client-blocks.md#u-25a3a4f1f827) · Implements the {#key} block: re-renders its content whenever the key expression changes under the selected equality check (not_equal in runes mode, safe_not_equal otherwise).
          - [Client Attribute Application](nodes/r3-client-attributes.md) (17 units)
            - [attributes.js-remove-input-defaults](nodes/r3-client-attributes.md#u-5ab20d9a7208) · Clears an input's value/checked HTML attributes during hydration so a later form reset restores defaults without wiping current values.
          - [Client Reactivity: Props and Stores](nodes/r3-client-reactivity.md) (0 units)
            - [Client Prop Accessors](nodes/r3-client-props.md) (6 units)
              - [props.js-prop](nodes/r3-client-props.md#u-2e500006b90d) · Implements a single component prop accessor, synchronizing possibly-bound props with local state and returning a getter/setter function.
            - [Client Store Integration](nodes/r3-client-stores.md) (5 units)
              - [store.js-setup-stores](nodes/r3-client-stores.md#u-59b61f01da09) · Creates the per-component store references container and its destroy hook.
          - [Client Render Lifecycle](nodes/r3-client-render.md) (3 units)
            - [render.js-mount](nodes/r3-client-render.md#u-751f047b7883) · Implements the public mount/hydrate/unmount lifecycle.
          - [Client Dev Diagnostics](nodes/r3-client-dev.md) (14 units)
            - [assign-js-stale-assignment-helpers](nodes/r3-client-dev.md#u-d4a793369eef) · Dev-mode helpers that execute reactive property assignments (=, &&=, ||=, ??=) and warn when the assignment result disagrees with an untracked re-read of the property.
        - [Server Runtime](nodes/r3-server-runtime.md) (0 units)
          - [Server Render Entry](nodes/r3-server-render-entry.md) (11 units)
            - [render](nodes/r3-server-render-entry.md#u-ead9aba750b3) · Render a component to HTML on the server, returning head, html, and body strings.
          - [Server Dev Validation](nodes/r3-server-dev.md) (8 units)
            - [dev.js module code (L1–L32)](nodes/r3-server-dev.md#u-52b52ceaef85) · Imports, the Element typedef, and module-level dev state (parent element stack, seen-message set).
          - [Server Markup Serialization](nodes/r3-server-markup.md) (16 units)
            - [attr_class](nodes/r3-server-markup.md#u-a9cb571edc90) · Render a class attribute string from a value, scoping hash, and class directives; empty result yields ''.
          - [Server Templating Helpers](nodes/r3-server-templating.md) (22 units)
            - [packages/svelte/src/internal/server/index.js:slot](nodes/r3-server-templating.md#u-c8b85b1bb23a) · Render a named slot: call the provided slot function with slot props, or the fallback.
          - [Server Store Helpers](nodes/r3-server-stores.md) (12 units)
            - [packages/svelte/src/internal/server/index.js:store_get](nodes/r3-server-stores.md#u-5975ccb1491b) · Subscribe a store for template reads and return its current value, caching per store name.
      - [Shared Utilities and Public Contracts](nodes/r3-shared.md) (0 units)
        - [Shared Predicates and Hash](nodes/r3-shared-utils.md) (2 units)
          - [utils-js-predicates](nodes/r3-shared-utils.md#u-7eb274f609ad) · A set of small pure lookup helpers plus two string utilities, each backed by a module-level constant list.
        - [Public Animation and Action Contracts](nodes/r3-public-animation-and-actions.md) (4 units)
          - [flip](nodes/r3-public-animation-and-actions.md#u-2953ae0602e1) · Computes a FLIP animation for an element moving between two DOMRect positions, returning an `AnimationConfig` whose `css(t, u)` emits a transform string.
        - [Easing Functions](nodes/r3-shared-easing.md) (1 units)
          - [index.js-easing-functions](nodes/r3-shared-easing.md#u-bcdfc0779439) · Exports a family of pure easing functions mapping a progress scalar `t` (typically 0..1) to an eased scalar, adapted from mattdesl/eases under MIT.
        - [Runtime Mode Flags](nodes/r3-runtime-mode-flags.md) (4 units)
          - [enable_async_mode_flag](nodes/r3-runtime-mode-flags.md#u-8e5eb2967954) · Sets the module-level mutable async_mode_flag to true, switching internal runtime behavior wherever that export is read.
      - [Repository Tooling](nodes/r3-tooling.md) (0 units)
        - [Reactivity Benchmarks](nodes/r3-benchmarks.md) (4 units)
          - [benchmarking-compare-index-module](nodes/r3-benchmarks.md#u-6988b0d7b4e5) · Compares benchmark results across git branches by checking out each branch, forking a runner child process, and rendering a bar-chart comparison to the console.
        - [Build and Audit Tooling](nodes/r3-build-tooling.md) (5 units)
          - [rollup.config.js module code (L1–L17)](nodes/r3-build-tooling.md#u-2eb418b9a160) · Configures the Rollup build that compiles the Svelte compiler into a single UMD bundle.
  - [Public API, Types & Reactive Primitives](nodes/public-api-types.md) (0 units)
    - [Svelte Codebase](nodes/r2-svelte-codebase.md) (9 units)
      - [packages/svelte/src/internal/server/blocks/html.js:html](nodes/r2-svelte-codebase.md#u-b6ffad2a2a76) · Wrap a raw HTML string in hydration comment markers for the server render output.
      - [Svelte Compiler](nodes/r2-compiler.md) (0 units)
        - [Compiler Foundations](nodes/r2-compiler-foundations.md) (24 units)
          - [errors-internal-error-and-throw-helper](nodes/r2-compiler-foundations.md#u-cef04d4352b1) · Defines InternalCompileError, the Error subclass thrown by every compiler error factory, and `e`, the shared helper that converts a node/position into a thrown InternalCompileError.
        - [CSS Pipeline](nodes/r2-css-pipeline.md) (0 units)
          - [CSS Parsing](nodes/r2-css-parse.md) (14 units)
            - [read_style](nodes/r2-css-parse.md#u-863125efdf39) · Entry point for `<style>` content: reads a body of rules until the literal `</style`, then consumes the closing tag (regex allows trailing whitespace) and returns a StyleSheet node whose `content.styles` is the raw template slice between content_start and content_end, with comment initialized to null.
          - [CSS Analysis](nodes/r2-css-analyze.md) (11 units)
            - [warn_unused](nodes/r2-css-analyze.md#u-6a7a7b443898) · Walks the stylesheet with the unused-selector visitors to emit css_unused_selector warnings for selectors never marked used.
          - [CSS Transform](nodes/r2-css-transform.md) (8 units)
            - [css-index-js-visitors](nodes/r2-css-transform.md#u-fdc33a016f25) · The zimmerframe visitor object that scopes, prunes, and minifies the CSS AST.
        - [Template Analysis](nodes/r2-analyze-phase.md) (17 units)
          - [packages/svelte/src/compiler/phases/2-analyze/visitors/AwaitBlock.js:AwaitBlock](nodes/r2-analyze-phase.md#u-e78635f9b260) · Analyzes {#await} blocks: validates that pending, then, and catch branches are non-empty via validate_block_not_empty.
        - [Client Transform](nodes/r2-client-transform.md) (32 units)
          - [packages/svelte/src/compiler/phases/3-transform/types.d.ts:types.d.ts module code (L1–L4)](nodes/r2-client-transform.md#u-163781a2b736) · Declares TransformState, the shared state object threaded through the transform phase: the Analysis, validated compile options, current Scope, a per-node Map of scopes, and a map of reactive state_fields.
        - [Server Transform](nodes/r2-server-transform.md) (11 units)
          - [packages/svelte/src/compiler/phases/3-transform/server/visitors/EachBlock.js:EachBlock](nodes/r2-server-transform.md#u-4806d5caedfd) · Compiles an {#each} block into a server-side for-loop over an array-like snapshot.
      - [Client Runtime](nodes/r2-client-runtime.md) (0 units)
        - [Reactivity Core & Batching](nodes/r2-reactivity-core.md) (28 units)
          - [runtime-js-state-and-helpers](nodes/r2-reactivity-core.md#u-6cd2387802ec) · Module-level mutable state and small helpers of the client reactivity runtime.
        - [Component Context](nodes/r2-component-context.md) (13 units)
          - [push](nodes/r2-component-context.md#u-9761c5d7c2ee) · Enters a new component scope by replacing component_context with a fresh context object linked to the previous one via p.
        - [Each Block Runtime](nodes/r2-dom-blocks.md) (7 units)
          - [each-js-each](nodes/r2-dom-blocks.md#u-28e626fece6b) · Implements the {#each} block: derives the collection via derived_safe_equal (coercing non-arrays and null/undefined to arrays) and runs a block effect that reconciles on change.
        - [DOM Elements](nodes/r2-dom-elements.md) (15 units)
          - [listen](nodes/r2-dom-elements.md#u-8f0d8dd6601b) · Registers a handler on an EventTarget for each named event and removes all listeners during effect teardown.
        - [Legacy Client Compatibility](nodes/r2-legacy-client.md) (10 units)
          - [Svelte4Component](nodes/r2-legacy-client.md#u-f604417484a2) · Adapter class exposing a Svelte 5 component through the Svelte 4 class API (props proxy, $set/$on/$destroy, enumerable export accessors).
      - [Reactive Primitives](nodes/r2-reactive-primitives.md) (8 units)
        - [createSubscriber](nodes/r2-reactive-primitives.md#u-44838dbc4415) · Creates a subscribe function that lazily wires an external event source into Svelte's reactivity.
      - [Public API Types](nodes/r2-public-api.md) (10 units)
        - [index-dts-branding](nodes/r2-public-api.md#u-fe8809d98989) · Branding utilities used to make internal types nominally distinct.
      - [Tooling & Benchmarks](nodes/r2-tooling.md) (0 units)
        - [Warning Message Codegen](nodes/r2-message-codegen.md) (4 units)
          - [index.js-run](nodes/r2-message-codegen.md#u-f2d5f8b6c5f2) · Regenerates all Svelte message reference docs and generated source files from markdown under messages/.
        - [Reactivity Benchmarks](nodes/r2-benchmarks.md) (3 units)
          - [kairo_diamond.js](nodes/r2-benchmarks.md#u-515ca1b112ed) · Benchmarks a diamond-shaped dependency graph: setup() creates width (5) deriveds each reading head, a sum derived that maps and reduces them, and a render effect counting sum recomputations.
        - [Sandbox Playground](nodes/r2-playgrounds.md) (8 units)
          - [run.js module code (L1–L22)](nodes/r2-playgrounds.md#u-2eee5a3b7690) · Parses CLI args, resolves the sandbox cwd, and empties the output directory before generation.

## Reading stats

- units: 1132 · semantic nodes: 154 · dispositioned inventory ids: 4988
- source ranges are program-derived from the inventory, never model-written

## Graph coverage

Source: static analysis graph. Resolved relations are graph-confirmed; this does not guarantee semantic correctness. External targets are outside the repository; ambiguous targets have multiple candidates. Unresolved or unsupported relations, and languages or relation kinds without coverage, rely on model inference and may be inaccurate.
Import and call status ratios use the edge count of each kind. CFG and dataflow are structural edges; only their counts are shown, without status ratios.
javascript import: resolved 1256/2267 (55%), unresolved 674/2267 (30%), external 337/2267 (15%) · javascript call: resolved 3192/15643 (20%), ambiguous 1078/15643 (7%), unresolved 4739/15643 (30%), external 6634/15643 (42%).
javascript structural edges: cfg=245262, dataflow=50000.
typescript import: resolved 33/41 (80%), unresolved 8/41 (20%) · typescript call: no edges.
typescript structural edges: cfg=0, dataflow=0.
Incomplete capabilities: javascript/call partial; javascript/dataflow partial; typescript/call partial; typescript/dataflow partial.
Program checks: dangling edges 0; nodes outside manifest 0; nodes with missing files 0.

## Overview

This repository is the Svelte framework. Compiler work flows parse → analyze → transform, emitting client JS that calls into the browser runtime and SSR code consumed by the server runtime. The tree is responsibility-based: compiler subtrees own phases, runtime subtrees own execution, and public API/typings plus shared utilities sit as cross-cutting siblings. Key capability areas: compiler-pipeline (with r3/r5 phase views including validate-options, CSS pipeline, sourcemaps, migration), client-runtime (effect/signal core, DOM blocks, bindings, hydration), server-and-shared-runtime (SSR rendering, context, stores, escaping), and public-api-types (reactive primitives wrapping the internal signal system, element typings). Tooling covers benchmarks, message codegen, playground sandboxes, and tree-shakeability audits. Multiple root nodes describe overlapping views of the same codebase; pick one tree and follow its relationships. Compiled output relies on generated warning/error code: message templates are expanded by r2-message-codegen, and warnings flow through the plumbing in r1-compiler-diagnostics-infrastructure.

## Maintenance navigation

Compile-time diagnostics: start at r2-compiler-foundations (errors, CompileDiagnostic, validate-options) or r1-compiler-diagnostics-infrastructure for warning emitters; per-node template validation lives in r2-analyze-phase and r3-analyze-visitors; CSS checks in r2-css-analyze; a11y checks in r1-a11y-checks. Parser issues: r1-compiler-parse / r5-compiler-parse, with entity decoding in r1-html-entity-decoding and expression reading in r1-script-expression-parsing. Codegen: client output in r3-client-transform-visitors with r3-client-transform-utils, server output in r3-server-transform / r2-server-transform; assignment semantics shared by both targets in r1-shared-assignment-transform; CSS rendering in r2-css-transform; source maps in r5-compiler-sourcemaps and preprocessing in r1-preprocess. Runtime behavior: signal writes and derived evaluation in r2-reactivity-core; effect lifecycle in r4-runtime-effects; component context in r2-component-context; each blocks in r2-dom-blocks; await reactivity in r1-async-reactivity; bindings in r1-element-bindings, r4-runtime-element-bindings, r5-client-bindings; hydration cursor in r3-client-hydration; mount/unmount in r3-client-render; boundaries in r5-client-boundary; SSR plumbing in r5-runtime-server and r3-server-runtime. Public surface: reactive wrappers in r2-reactive-primitives and r1-reactive-collections, element typings in r5-public-types and r2-public-api, rune signatures in r1-rune-ambient-typings. Migration questions go to r3-migration; warning message regeneration to r2-message-codegen; performance measurements to the benchmark nodes. When behavior differs between dev and prod, check the dev-only nodes (r1-client-dev-diagnostics, r5-client-dev, r4-runtime-dev, r3-client-dev) which are compiled out of production.

## Dependency view

Arrows point from a user to its dependency. Containment is structural, not a dependency. Graph-confirmed pairs appear in both the tree and resolved call/import edges. Model-inferred pairs appear only in the tree. Graph-only pairs appear only in the graph.
Graph-confirmed and model-inferred pairs count edges between two subtrees. Graph-only pairs count edges between direct node owners. Containment rows show resolved edges between ancestor direct units and a descendant subtree in both directions. Within containment rows count direct owner pairs separately. Neither kind of containment row appears in Mermaid or the three dependency totals.

```mermaid
flowchart LR
  n0["Reactivity Core #38; Batching"]
  n1["Signal Reactivity Core"]
  n2["Effect System"]
  n3["Shared Predicates and Hash"]
  n4["AST Manipulation Utilities"]
  n5["DOM Template Blocks"]
  n6["Client Hydration State"]
  n7["Scope and Binding Model"]
  n8["Signals#44; Deriveds#44; and Proxies"]
  n9["Client Code Transformation"]
  n10["Client Runtime"]
  n11["Public API#44; Types #38; Reactive Primitives"]
  n12["Compiler Foundations"]
  n13["Semantic Analysis Visitors"]
  n14["DOM Operations #38; Elements"]
  n10 --> n11
  n11 --> n10
  n13 --> n4
  n13 --> n7
  n7 --> n4
  n8 --> n2
  n9 --> n4
  n9 --> n7
  n14 --> n1
  n1 ==> n0
  n5 ==> n2
  n8 ==> n1
  n2 ==> n0
  n8 ==> n0
  n5 ==> n6
```

Selected 15 nodes by connection count. Legend: `-->` graph-confirmed; `-.->` model-inferred; `==>` graph-only.

## Dependency list

- [Client Runtime](nodes/client-runtime.md) → [Compiler Pipeline](nodes/compiler-pipeline.md) · graph-confirmed · 66 edge(s)
- [Client Runtime](nodes/client-runtime.md) → [Public API, Types & Reactive Primitives](nodes/public-api-types.md) · graph-confirmed · 57 edge(s)
- [Client Runtime](nodes/client-runtime.md) → [Server & Shared Runtime](nodes/server-and-shared-runtime.md) · graph-confirmed · 37 edge(s)
- [Compiler Pipeline](nodes/compiler-pipeline.md) → [Client Runtime](nodes/client-runtime.md) · graph-confirmed · 144 edge(s)
- [Compiler Pipeline](nodes/compiler-pipeline.md) → [Public API, Types & Reactive Primitives](nodes/public-api-types.md) · graph-confirmed · 71 edge(s)
- [Public API, Types & Reactive Primitives](nodes/public-api-types.md) → [Client Runtime](nodes/client-runtime.md) · graph-confirmed · 112 edge(s)
- [Public API, Types & Reactive Primitives](nodes/public-api-types.md) → [Compiler Pipeline](nodes/compiler-pipeline.md) · graph-confirmed · 46 edge(s)
- [Public API, Types & Reactive Primitives](nodes/public-api-types.md) → [Server & Shared Runtime](nodes/server-and-shared-runtime.md) · graph-confirmed · 22 edge(s)
- [Accessibility Checks](nodes/r1-a11y-checks.md) → [Compiler Warning Infrastructure](nodes/r1-compiler-diagnostics-infrastructure.md) · model-inferred · 0 edge(s)
- [Shared Analysis Visitors & Helpers](nodes/r1-analysis-visitors.md) → [Compiler Warning Infrastructure](nodes/r1-compiler-diagnostics-infrastructure.md) · model-inferred · 0 edge(s)
- [Benchmarks](nodes/r1-benchmarks.md) → [Server Runtime](nodes/r1-server-runtime.md) · model-inferred · 0 edge(s)
- [Dev Diagnostics & HMR](nodes/r1-client-dev-diagnostics.md) → [Reactivity Type Contracts](nodes/r1-client-reactivity-types.md) · model-inferred · 0 edge(s)
- [Dev Diagnostics & HMR](nodes/r1-client-dev-diagnostics.md) → [Client Transform](nodes/r1-client-transform.md) · graph-confirmed · 1 edge(s)
- [Dev Diagnostics & HMR](nodes/r1-client-dev-diagnostics.md) → [Shared Runtime Utilities](nodes/r1-shared-runtime.md) · graph-confirmed · 1 edge(s) · state-aware console logging snapshots values via the shared $state.snapshot helper.
- [Client Transform](nodes/r1-client-transform.md) → [Client Runtime](nodes/r1-client-runtime.md) · model-inferred · 0 edge(s)
- [Client Transform](nodes/r1-client-transform.md) → [Shared Assignment Driver](nodes/r1-shared-assignment-transform.md) · model-inferred · 0 edge(s)
- [DOM Template Blocks](nodes/r1-dom-blocks.md) → [Async Reactivity](nodes/r1-async-reactivity.md) · graph-confirmed · 1 edge(s) · async template blocks call flatten to preserve reactive tracking across awaited expressions.
- [DOM Template Blocks](nodes/r1-dom-blocks.md) → [Shared Runtime Utilities](nodes/r1-shared-runtime.md) · graph-confirmed · 2 edge(s)
- [DOM Template Blocks](nodes/r1-dom-blocks.md) → [Task Scheduling](nodes/r1-task-scheduling.md) · graph-confirmed · 1 edge(s)
- [Element Bindings](nodes/r1-element-bindings.md) → [Task Scheduling](nodes/r1-task-scheduling.md) · graph-confirmed · 3 edge(s)
- [Event System & Delegation](nodes/r1-event-system.md) → [DOM Template Blocks](nodes/r1-dom-blocks.md) · model-inferred · 0 edge(s)
- [Event System & Delegation](nodes/r1-event-system.md) → [Task Scheduling](nodes/r1-task-scheduling.md) · graph-confirmed · 1 edge(s)
- [Legacy Client Compatibility](nodes/r1-legacy-compat-client.md) → [Event System & Delegation](nodes/r1-event-system.md) · graph-confirmed · 2 edge(s)
- [Legacy Class-Component Adapter \(Server\)](nodes/r1-legacy-component-adapter.md) → [Client Runtime](nodes/r1-client-runtime.md) · model-inferred · 0 edge(s)
- [Markup & Attribute Parsing](nodes/r1-markup-tag-parsing.md) → [HTML Entity Decoding](nodes/r1-html-entity-decoding.md) · graph-confirmed · 2 edge(s)
- [Markup & Attribute Parsing](nodes/r1-markup-tag-parsing.md) → [Expression & Script Reading](nodes/r1-script-expression-parsing.md) · graph-confirmed · 4 edge(s)
- [Playground Sandbox](nodes/r1-playground-sandbox.md) → [Client Transform](nodes/r1-client-transform.md) · graph-confirmed · 2 edge(s)
- [Preprocessing](nodes/r1-preprocess.md) → [HTML Entity Decoding](nodes/r1-html-entity-decoding.md) · model-inferred · 0 edge(s)
- [Reactive Wrapper Classes](nodes/r1-reactive-collections.md) → [Motion \(Spring & Tween\)](nodes/r1-motion.md) · model-inferred · 0 edge(s)
- [Server Transform](nodes/r1-server-transform.md) → [Server Runtime](nodes/r1-server-runtime.md) · model-inferred · 0 edge(s)
- [Server Transform](nodes/r1-server-transform.md) → [Shared Assignment Driver](nodes/r1-shared-assignment-transform.md) · graph-confirmed · 1 edge(s)
- [Task Scheduling](nodes/r1-task-scheduling.md) → [Shared Runtime Utilities](nodes/r1-shared-runtime.md) · graph-confirmed · 2 edge(s)
- [Template Analysis](nodes/r2-analyze-phase.md) → [Compiler Foundations](nodes/r2-compiler-foundations.md) · graph-confirmed · 1 edge(s) · analysis visitors import error/warning factories and use extract_svelte_ignore from the shared compiler foundations.
- [Template Analysis](nodes/r2-analyze-phase.md) → [CSS Analysis](nodes/r2-css-analyze.md) · model-inferred · 0 edge(s)
- [Reactivity Benchmarks](nodes/r2-benchmarks.md) → [Reactivity Core & Batching](nodes/r2-reactivity-core.md) · model-inferred · 0 edge(s)
- [Client Transform](nodes/r2-client-transform.md) → [Template Analysis](nodes/r2-analyze-phase.md) · model-inferred · 0 edge(s)
- [Client Transform](nodes/r2-client-transform.md) → [Compiler Foundations](nodes/r2-compiler-foundations.md) · model-inferred · 0 edge(s)
- [Component Context](nodes/r2-component-context.md) → [Reactivity Core & Batching](nodes/r2-reactivity-core.md) · model-inferred · 0 edge(s)
- [CSS Analysis](nodes/r2-css-analyze.md) → [CSS Parsing](nodes/r2-css-parse.md) · model-inferred · 0 edge(s)
- [CSS Transform](nodes/r2-css-transform.md) → [Compiler Foundations](nodes/r2-compiler-foundations.md) · model-inferred · 0 edge(s)
- [CSS Transform](nodes/r2-css-transform.md) → [CSS Analysis](nodes/r2-css-analyze.md) · model-inferred · 0 edge(s)
- [Each Block Runtime](nodes/r2-dom-blocks.md) → [Component Context](nodes/r2-component-context.md) · model-inferred · 0 edge(s)
- [Each Block Runtime](nodes/r2-dom-blocks.md) → [Reactivity Core & Batching](nodes/r2-reactivity-core.md) · graph-confirmed · 3 edge(s) · the each block creates batches and reads reactive state through the reactivity core to coordinate keyed teardown.
- [DOM Elements](nodes/r2-dom-elements.md) → [Reactivity Core & Batching](nodes/r2-reactivity-core.md) · graph-confirmed · 6 edge(s)
- [Legacy Client Compatibility](nodes/r2-legacy-client.md) → [Reactivity Core & Batching](nodes/r2-reactivity-core.md) · graph-confirmed · 4 edge(s)
- [Warning Message Codegen](nodes/r2-message-codegen.md) → [Compiler Foundations](nodes/r2-compiler-foundations.md) · model-inferred · 0 edge(s)
- [Warning Message Codegen](nodes/r2-message-codegen.md) → [Reactive Primitives](nodes/r2-reactive-primitives.md) · graph-confirmed · 1 edge(s)
- [Sandbox Playground](nodes/r2-playgrounds.md) → [Client Transform](nodes/r2-client-transform.md) · model-inferred · 0 edge(s)
- [Sandbox Playground](nodes/r2-playgrounds.md) → [Compiler Foundations](nodes/r2-compiler-foundations.md) · model-inferred · 0 edge(s)
- [Sandbox Playground](nodes/r2-playgrounds.md) → [Server Transform](nodes/r2-server-transform.md) · model-inferred · 0 edge(s)
- [Reactive Primitives](nodes/r2-reactive-primitives.md) → [Reactivity Core & Batching](nodes/r2-reactivity-core.md) · graph-confirmed · 6 edge(s) · public primitives like createSubscriber and toStore build on the internal runtime state helpers and get.
- [Reactivity Core & Batching](nodes/r2-reactivity-core.md) → [Component Context](nodes/r2-component-context.md) · graph-confirmed · 7 edge(s)
- [Server Transform](nodes/r2-server-transform.md) → [Client Transform](nodes/r2-client-transform.md) · graph-confirmed · 2 edge(s) · the server transform reuses shared clean_nodes and infer_namespace helpers from the client transform utilities.
- [Server Transform](nodes/r2-server-transform.md) → [Compiler Foundations](nodes/r2-compiler-foundations.md) · graph-confirmed · 1 edge(s)
- [Analysis Driver](nodes/r3-analyze-driver.md) → [Analysis Visitors](nodes/r3-analyze-visitors.md) · model-inferred · 0 edge(s)
- [Analysis Driver](nodes/r3-analyze-driver.md) → [Shared Predicates and Hash](nodes/r3-shared-utils.md) · graph-confirmed · 3 edge(s)
- [Analysis Visitors](nodes/r3-analyze-visitors.md) → [Shared Predicates and Hash](nodes/r3-shared-utils.md) · graph-confirmed · 1 edge(s)
- [Reactivity Benchmarks](nodes/r3-benchmarks.md) → [Shared Utilities and Public Contracts](nodes/r3-shared.md) · model-inferred · 0 edge(s)
- [Build and Audit Tooling](nodes/r3-build-tooling.md) → [Client Runtime](nodes/r3-client-runtime.md) · model-inferred · 0 edge(s)
- [Client Attribute Application](nodes/r3-client-attributes.md) → [Client Hydration State](nodes/r3-client-hydration.md) · graph-confirmed · 4 edge(s)
- [Client Attribute Application](nodes/r3-client-attributes.md) → [Shared Predicates and Hash](nodes/r3-shared-utils.md) · graph-confirmed · 3 edge(s)
- [Client Control Blocks and CSS](nodes/r3-client-blocks.md) → [Client Hydration State](nodes/r3-client-hydration.md) · graph-confirmed · 7 edge(s)
- [Client Control Blocks and CSS](nodes/r3-client-blocks.md) → [Client Render Lifecycle](nodes/r3-client-render.md) · graph-confirmed · 2 edge(s)
- [Client Control Blocks and CSS](nodes/r3-client-blocks.md) → [Client Template Factories](nodes/r3-client-template.md) · graph-confirmed · 1 edge(s)
- [Client Prop Accessors](nodes/r3-client-props.md) → [Client Store Integration](nodes/r3-client-stores.md) · graph-confirmed · 1 edge(s)
- [Client Render Lifecycle](nodes/r3-client-render.md) → [Client Hydration State](nodes/r3-client-hydration.md) · graph-confirmed · 7 edge(s) · mount and hydrate drive their DOM work through the module-level hydration cursor helpers.
- [Client Render Lifecycle](nodes/r3-client-render.md) → [Client Template Factories](nodes/r3-client-template.md) · graph-confirmed · 1 edge(s)
- [Client Template Factories](nodes/r3-client-template.md) → [Client Hydration State](nodes/r3-client-hydration.md) · graph-confirmed · 3 edge(s)
- [Client Transform Phase](nodes/r3-client-transform.md) → [Analysis Driver](nodes/r3-analyze-driver.md) · model-inferred · 0 edge(s)
- [Client Transform Phase](nodes/r3-client-transform.md) → [Client Transform Utilities](nodes/r3-client-transform-utils.md) · containment · → 4 / ← 0 edge(s) (ancestor direct units and descendant subtree; → follows ` r3-client-transform ` → ` r3-client-transform-utils `)
- [Client Transform Visitors](nodes/r3-client-transform-visitors.md) → [Client Transform Utilities](nodes/r3-client-transform-utils.md) · graph-confirmed · 5 edge(s)
- [Client Transform Visitors](nodes/r3-client-transform-visitors.md) → [Shared Predicates and Hash](nodes/r3-shared-utils.md) · graph-confirmed · 4 edge(s)
- [Compiler Public Entry](nodes/r3-compiler-entry.md) → [Analysis Driver](nodes/r3-analyze-driver.md) · graph-confirmed · 2 edge(s) · compile and compileModule invoke the analysis driver to scope and validate the AST before transformation.
- [Migration Driver and Helpers](nodes/r3-migrate-entry.md) → [Analysis Driver](nodes/r3-analyze-driver.md) · graph-confirmed · 1 edge(s)
- [Migration Script Visitors](nodes/r3-migrate-script-visitors.md) → [Migration Driver and Helpers](nodes/r3-migrate-entry.md) · model-inferred · 0 edge(s)
- [Migration Script Visitors](nodes/r3-migrate-script-visitors.md) → [Shared Predicates and Hash](nodes/r3-shared-utils.md) · model-inferred · 0 edge(s)
- [Migration Template Visitors](nodes/r3-migrate-template-visitors.md) → [Migration Driver and Helpers](nodes/r3-migrate-entry.md) · graph-confirmed · 1 edge(s)
- [Migration Template Visitors](nodes/r3-migrate-template-visitors.md) → [Migration Script Visitors](nodes/r3-migrate-script-visitors.md) · graph-confirmed · 1 edge(s) · template visitors call handle_identifier owned by the script visitors during the shared migration walk.
- [Migration Template Visitors](nodes/r3-migrate-template-visitors.md) → [Shared Predicates and Hash](nodes/r3-shared-utils.md) · graph-confirmed · 3 edge(s)
- [Server Markup Serialization](nodes/r3-server-markup.md) → [Shared Predicates and Hash](nodes/r3-shared-utils.md) · graph-confirmed · 1 edge(s)
- [Server Render Entry](nodes/r3-server-render-entry.md) → [Server Dev Validation](nodes/r3-server-dev.md) · graph-confirmed · 1 edge(s)
- [Server Render Entry](nodes/r3-server-render-entry.md) → [Shared Predicates and Hash](nodes/r3-shared-utils.md) · graph-confirmed · 2 edge(s)
- [Server Templating Helpers](nodes/r3-server-templating.md) → [Server Markup Serialization](nodes/r3-server-markup.md) · model-inferred · 0 edge(s)
- [Server Transform Phase](nodes/r3-server-transform.md) → [Server Runtime](nodes/r3-server-runtime.md) · model-inferred · 0 edge(s)
- [Server Transform Phase](nodes/r3-server-transform.md) → [Shared Predicates and Hash](nodes/r3-shared-utils.md) · graph-confirmed · 7 edge(s)
- [Shared Analysis Validation](nodes/r4-analyze-shared-validation.md) → [AST Manipulation Utilities](nodes/r4-compiler-ast-utils.md) · graph-confirmed · 2 edge(s)
- [Shared Analysis Validation](nodes/r4-analyze-shared-validation.md) → [Node Factories and Metadata Model](nodes/r4-compiler-node-model.md) · graph-confirmed · 1 edge(s)
- [Shared Analysis Validation](nodes/r4-analyze-shared-validation.md) → [Scope and Binding Model](nodes/r4-compiler-scope.md) · graph-confirmed · 1 edge(s)
- [Semantic Analysis Visitors](nodes/r4-analyze-visitors.md) → [Shared Analysis Validation](nodes/r4-analyze-shared-validation.md) · graph-confirmed · 7 edge(s)
- [Semantic Analysis Visitors](nodes/r4-analyze-visitors.md) → [AST Manipulation Utilities](nodes/r4-compiler-ast-utils.md) · graph-confirmed · 12 edge(s)
- [Semantic Analysis Visitors](nodes/r4-analyze-visitors.md) → [Node Factories and Metadata Model](nodes/r4-compiler-node-model.md) · graph-confirmed · 2 edge(s)
- [Semantic Analysis Visitors](nodes/r4-analyze-visitors.md) → [Parsing and Lexical Helpers](nodes/r4-compiler-parse.md) · graph-confirmed · 1 edge(s)
- [Semantic Analysis Visitors](nodes/r4-analyze-visitors.md) → [Scope and Binding Model](nodes/r4-compiler-scope.md) · graph-confirmed · 2 edge(s)
- [Semantic Analysis Visitors](nodes/r4-analyze-visitors.md) → [Shared Source Utilities](nodes/r4-shared-source-utilities.md) · graph-confirmed · 1 edge(s)
- [Benchmarking Harness](nodes/r4-benchmarking.md) → [Svelte Compiler and Runtime](nodes/r4-svelte-monorepo.md) · containment · → 0 / ← 0 edge(s) (ancestor direct units and descendant subtree; → follows ` r4-benchmarking ` → ` r4-svelte-monorepo `)
- [Build Scripts and Generated Sources](nodes/r4-build-codegen.md) → [Compiler Pipeline](nodes/r4-compiler.md) · model-inferred · 0 edge(s)
- [Compiler Pipeline](nodes/r4-compiler.md) → [Compiler Type Declarations](nodes/r4-compiler-types.md) · containment · → 0 / ← 0 edge(s) (ancestor direct units and descendant subtree; → follows ` r4-compiler ` → ` r4-compiler-types `)
- [Node Factories and Metadata Model](nodes/r4-compiler-node-model.md) → [Scope and Binding Model](nodes/r4-compiler-scope.md) · model-inferred · 0 edge(s)
- [Scope and Binding Model](nodes/r4-compiler-scope.md) → [AST Manipulation Utilities](nodes/r4-compiler-ast-utils.md) · graph-confirmed · 11 edge(s)
- [Scope and Binding Model](nodes/r4-compiler-scope.md) → [Node Factories and Metadata Model](nodes/r4-compiler-node-model.md) · graph-confirmed · 1 edge(s)
- [Runtime Dev-Mode Instrumentation](nodes/r4-runtime-dev.md) → [Signals, Deriveds, and Proxies](nodes/r4-runtime-signals.md) · model-inferred · 0 edge(s)
- [Runtime DOM Blocks](nodes/r4-runtime-dom-blocks.md) → [Effect System](nodes/r4-runtime-effects.md) · graph-confirmed · 11 edge(s)
- [Effect System](nodes/r4-runtime-effects.md) → [Runtime Dev-Mode Instrumentation](nodes/r4-runtime-dev.md) · model-inferred · 0 edge(s)
- [Element Bindings and Behaviors](nodes/r4-runtime-element-bindings.md) → [Effect System](nodes/r4-runtime-effects.md) · graph-confirmed · 7 edge(s)
- [Element Bindings and Behaviors](nodes/r4-runtime-element-bindings.md) → [Signals, Deriveds, and Proxies](nodes/r4-runtime-signals.md) · model-inferred · 0 edge(s)
- [Legacy Public API](nodes/r4-runtime-legacy.md) → [Signals, Deriveds, and Proxies](nodes/r4-runtime-signals.md) · model-inferred · 0 edge(s)
- [Signals, Deriveds, and Proxies](nodes/r4-runtime-signals.md) → [Effect System](nodes/r4-runtime-effects.md) · graph-confirmed · 2 edge(s)
- [Client Code Transformation](nodes/r4-transform-client.md) → [AST Manipulation Utilities](nodes/r4-compiler-ast-utils.md) · graph-confirmed · 7 edge(s)
- [Client Code Transformation](nodes/r4-transform-client.md) → [Scope and Binding Model](nodes/r4-compiler-scope.md) · graph-confirmed · 16 edge(s)
- [Client Code Transformation](nodes/r4-transform-client.md) → [Shared Source Utilities](nodes/r4-shared-source-utilities.md) · graph-confirmed · 1 edge(s)
- [Client Code Transformation](nodes/r4-transform-client.md) → [Client Static Template Emission](nodes/r4-transform-template.md) · graph-confirmed · 2 edge(s)
- [Server \(SSR\) Code Transformation](nodes/r4-transform-server.md) → [AST Manipulation Utilities](nodes/r4-compiler-ast-utils.md) · graph-confirmed · 4 edge(s)
- [Server \(SSR\) Code Transformation](nodes/r4-transform-server.md) → [Scope and Binding Model](nodes/r4-compiler-scope.md) · graph-confirmed · 9 edge(s)
- [Client Static Template Emission](nodes/r4-transform-template.md) → [Shared Source Utilities](nodes/r4-shared-source-utilities.md) · graph-confirmed · 1 edge(s)
- [AST Analysis Visitors](nodes/r5-analyze-visitors.md) → [CSS Analysis](nodes/r5-analyze-css.md) · model-inferred · 0 edge(s)
- [Reactivity Benchmarks](nodes/r5-benchmarks.md) → [Signal Reactivity Core](nodes/r5-client-reactivity.md) · model-inferred · 0 edge(s)
- [Error & Pending Boundaries](nodes/r5-client-boundary.md) → [DOM Operations & Elements](nodes/r5-client-dom.md) · graph-confirmed · 1 edge(s)
- [Error & Pending Boundaries](nodes/r5-client-boundary.md) → [Signal Reactivity Core](nodes/r5-client-reactivity.md) · graph-confirmed · 2 edge(s)
- [Custom Element Hosting](nodes/r5-client-custom-elements.md) → [DOM Operations & Elements](nodes/r5-client-dom.md) · model-inferred · 0 edge(s)
- [DOM Operations & Elements](nodes/r5-client-dom.md) → [Dev-Mode Diagnostics](nodes/r5-client-dev.md) · graph-confirmed · 1 edge(s)
- [DOM Operations & Elements](nodes/r5-client-dom.md) → [Signal Reactivity Core](nodes/r5-client-reactivity.md) · graph-confirmed · 1 edge(s)
- [Spring Motion](nodes/r5-client-motion.md) → [Signal Reactivity Core](nodes/r5-client-reactivity.md) · graph-confirmed · 7 edge(s)
- [Spring Motion](nodes/r5-client-motion.md) → [Shared Runtime Infrastructure](nodes/r5-runtime-shared.md) · graph-confirmed · 1 edge(s)
- [Signal Reactivity Core](nodes/r5-client-reactivity.md) → [Shared Runtime Infrastructure](nodes/r5-runtime-shared.md) · model-inferred · 0 edge(s)
- [Analysis Phase](nodes/r5-compiler-analyze.md) → [Template Parsing](nodes/r5-compiler-parse.md) · model-inferred · 0 edge(s)
- [Template Parsing](nodes/r5-compiler-parse.md) → [Compiler State & AST Utilities](nodes/r5-compiler-state-utils.md) · graph-confirmed · 1 edge(s)
- [Source Maps & Preprocessing](nodes/r5-compiler-sourcemaps.md) → [Compiler State & AST Utilities](nodes/r5-compiler-state-utils.md) · model-inferred · 0 edge(s)
- [Sandbox Playground](nodes/r5-playgrounds.md) → [Compiler Pipeline](nodes/r5-compiler.md) · model-inferred · 0 edge(s)
- [Server Runtime](nodes/r5-runtime-server.md) → [Signal Reactivity Core](nodes/r5-client-reactivity.md) · model-inferred · 0 edge(s)
- [Server Runtime](nodes/r5-runtime-server.md) → [Shared Runtime Infrastructure](nodes/r5-runtime-shared.md) · graph-confirmed · 5 edge(s)
- [Shared Runtime Infrastructure](nodes/r5-runtime-shared.md) → [Signal Reactivity Core](nodes/r5-client-reactivity.md) · graph-confirmed · 1 edge(s)
- [Client Codegen Visitors](nodes/r5-transform-client.md) → [Analysis Phase](nodes/r5-compiler-analyze.md) · model-inferred · 0 edge(s)
- [Client Codegen Visitors](nodes/r5-transform-client.md) → [Compiler State & AST Utilities](nodes/r5-compiler-state-utils.md) · graph-confirmed · 4 edge(s)
- [Transform Entry & Result Assembly](nodes/r5-transform-entry.md) → [Source Maps & Preprocessing](nodes/r5-compiler-sourcemaps.md) · graph-confirmed · 3 edge(s)
- [Transform Entry & Result Assembly](nodes/r5-transform-entry.md) → [Client Codegen Visitors](nodes/r5-transform-client.md) · model-inferred · 0 edge(s)
- [Transform Entry & Result Assembly](nodes/r5-transform-entry.md) → [Server Codegen Visitors](nodes/r5-transform-server.md) · model-inferred · 0 edge(s)
- [Server Codegen Visitors](nodes/r5-transform-server.md) → [Compiler State & AST Utilities](nodes/r5-compiler-state-utils.md) · graph-confirmed · 1 edge(s)
- [Server Codegen Visitors](nodes/r5-transform-server.md) → [Server Runtime](nodes/r5-runtime-server.md) · model-inferred · 0 edge(s)
- [Server & Shared Runtime](nodes/server-and-shared-runtime.md) → [Client Runtime](nodes/client-runtime.md) · graph-confirmed · 113 edge(s)
- [Server & Shared Runtime](nodes/server-and-shared-runtime.md) → [Public API, Types & Reactive Primitives](nodes/public-api-types.md) · graph-confirmed · 59 edge(s)
- [Svelte Repository](nodes/svelte-repo.md) → [Client Runtime](nodes/client-runtime.md) · containment · → 0 / ← 0 edge(s) (ancestor direct units and descendant subtree; → follows ` svelte-repo ` → ` client-runtime `)
- [Svelte Repository](nodes/svelte-repo.md) → [Compiler Pipeline](nodes/compiler-pipeline.md) · containment · → 0 / ← 0 edge(s) (ancestor direct units and descendant subtree; → follows ` svelte-repo ` → ` compiler-pipeline `)
- [Svelte Repository](nodes/svelte-repo.md) → [Public API, Types & Reactive Primitives](nodes/public-api-types.md) · containment · → 0 / ← 0 edge(s) (ancestor direct units and descendant subtree; → follows ` svelte-repo ` → ` public-api-types `)
- [Svelte Repository](nodes/svelte-repo.md) → [Server & Shared Runtime](nodes/server-and-shared-runtime.md) · containment · → 0 / ← 0 edge(s) (ancestor direct units and descendant subtree; → follows ` svelte-repo ` → ` server-and-shared-runtime `)
- [Reactive Wrapper Classes](nodes/r1-reactive-collections.md) → [Signal Reactivity Core](nodes/r5-client-reactivity.md) · graph-only · 37 edge(s)
- [Reactive Wrapper Classes](nodes/r1-reactive-collections.md) → [Reactivity Core & Batching](nodes/r2-reactivity-core.md) · graph-only · 26 edge(s)
- [Client Code Transformation](nodes/r4-transform-client.md) → [Client Codegen Visitors](nodes/r5-transform-client.md) · graph-only · 23 edge(s)
- [Signal Reactivity Core](nodes/r5-client-reactivity.md) → [Reactivity Core & Batching](nodes/r2-reactivity-core.md) · graph-only · 22 edge(s)
- [DOM Template Blocks](nodes/r1-dom-blocks.md) → [Effect System](nodes/r4-runtime-effects.md) · graph-only · 20 edge(s)
- [Reactive Wrapper Classes](nodes/r1-reactive-collections.md) → [Runtime Dev-Mode Instrumentation](nodes/r4-runtime-dev.md) · graph-only · 19 edge(s)
- [Reactivity Benchmarks](nodes/r2-benchmarks.md) → [Benchmarking Harness](nodes/r4-benchmarking.md) · graph-only · 19 edge(s)
- [Signals, Deriveds, and Proxies](nodes/r4-runtime-signals.md) → [Signal Reactivity Core](nodes/r5-client-reactivity.md) · graph-only · 18 edge(s)
- [Client Template Factories](nodes/r3-client-template.md) → [DOM Operations & Elements](nodes/r5-client-dom.md) · graph-only · 17 edge(s)
- [Effect System](nodes/r4-runtime-effects.md) → [Reactivity Core & Batching](nodes/r2-reactivity-core.md) · graph-only · 17 edge(s)
- [Server Transform Phase](nodes/r3-server-transform.md) → [Server Transform](nodes/r2-server-transform.md) · graph-only · 16 edge(s)
- [Signals, Deriveds, and Proxies](nodes/r4-runtime-signals.md) → [Reactivity Core & Batching](nodes/r2-reactivity-core.md) · graph-only · 16 edge(s)
- [Preprocessing](nodes/r1-preprocess.md) → [Source Maps & Preprocessing](nodes/r5-compiler-sourcemaps.md) · graph-only · 15 edge(s)
- [Template Parsing](nodes/r5-compiler-parse.md) → [Parsing and Lexical Helpers](nodes/r4-compiler-parse.md) · graph-only · 15 edge(s)
- [DOM Template Blocks](nodes/r1-dom-blocks.md) → [Client Hydration State](nodes/r3-client-hydration.md) · graph-only · 13 edge(s)
- [Error & Pending Boundaries](nodes/r5-client-boundary.md) → [Effect System](nodes/r4-runtime-effects.md) · graph-only · 13 edge(s)
- [Client Transform](nodes/r1-client-transform.md) → [Client Codegen Visitors](nodes/r5-transform-client.md) · graph-only · 12 edge(s)
- [Reactive Primitives](nodes/r2-reactive-primitives.md) → [Signal Reactivity Core](nodes/r5-client-reactivity.md) · graph-only · 12 edge(s)
- [Runtime DOM Blocks](nodes/r4-runtime-dom-blocks.md) → [DOM Operations & Elements](nodes/r5-client-dom.md) · graph-only · 12 edge(s)
- [AST Analysis Visitors](nodes/r5-analyze-visitors.md) → [AST Manipulation Utilities](nodes/r4-compiler-ast-utils.md) · graph-only · 12 edge(s)
- [Reactivity Benchmarks](nodes/r5-benchmarks.md) → [Benchmarking Harness](nodes/r4-benchmarking.md) · graph-only · 12 edge(s)
- [Template Parsing](nodes/r5-compiler-parse.md) → [Expression & Script Reading](nodes/r1-script-expression-parsing.md) · graph-only · 12 edge(s)
- [Benchmarks](nodes/r1-benchmarks.md) → [Benchmarking Harness](nodes/r4-benchmarking.md) · graph-only · 11 edge(s)
- [Markup & Attribute Parsing](nodes/r1-markup-tag-parsing.md) → [Node Factories and Metadata Model](nodes/r4-compiler-node-model.md) · graph-only · 11 edge(s)
- [Each Block Runtime](nodes/r2-dom-blocks.md) → [Effect System](nodes/r4-runtime-effects.md) · graph-only · 11 edge(s)
- [Element Bindings and Behaviors](nodes/r4-runtime-element-bindings.md) → [DOM Elements](nodes/r2-dom-elements.md) · graph-only · 11 edge(s)
- [AST Analysis Visitors](nodes/r5-analyze-visitors.md) → [Shared Analysis Visitors & Helpers](nodes/r1-analysis-visitors.md) · graph-only · 11 edge(s)
- [Client Codegen Visitors](nodes/r5-transform-client.md) → [AST Manipulation Utilities](nodes/r4-compiler-ast-utils.md) · graph-only · 11 edge(s)
- [Each Block Runtime](nodes/r2-dom-blocks.md) → [Client Hydration State](nodes/r3-client-hydration.md) · graph-only · 10 edge(s)
- [Analysis Visitors](nodes/r3-analyze-visitors.md) → [Shared Analysis Validation](nodes/r4-analyze-shared-validation.md) · graph-only · 10 edge(s)
- [Client Transform Visitors](nodes/r3-client-transform-visitors.md) → [Client Code Transformation](nodes/r4-transform-client.md) · graph-only · 10 edge(s)
- [Signals, Deriveds, and Proxies](nodes/r4-runtime-signals.md) → [Runtime Dev-Mode Instrumentation](nodes/r4-runtime-dev.md) · graph-only · 10 edge(s)
- [Client Code Transformation](nodes/r4-transform-client.md) → [Client Transform Utilities](nodes/r3-client-transform-utils.md) · graph-only · 10 edge(s)
- [DOM Template Blocks](nodes/r1-dom-blocks.md) → [Component Context](nodes/r2-component-context.md) · graph-only · 9 edge(s)
- [Analysis Visitors](nodes/r3-analyze-visitors.md) → [AST Manipulation Utilities](nodes/r4-compiler-ast-utils.md) · graph-only · 9 edge(s)
- [Reactivity Benchmarks](nodes/r3-benchmarks.md) → [Benchmarking Harness](nodes/r4-benchmarking.md) · graph-only · 9 edge(s)
- [Client Control Blocks and CSS](nodes/r3-client-blocks.md) → [Effect System](nodes/r4-runtime-effects.md) · graph-only · 9 edge(s)
- [Runtime DOM Blocks](nodes/r4-runtime-dom-blocks.md) → [Client Hydration State](nodes/r3-client-hydration.md) · graph-only · 9 edge(s)
- [Element Bindings](nodes/r5-client-bindings.md) → [Effect System](nodes/r4-runtime-effects.md) · graph-only · 9 edge(s)
- [Error & Pending Boundaries](nodes/r5-client-boundary.md) → [Reactivity Core & Batching](nodes/r2-reactivity-core.md) · graph-only · 9 edge(s)

Graph-only pairs are ranked by edge count; 311 omitted.

### Within containment

- [Build and Audit Tooling](nodes/r3-build-tooling.md) → [Svelte Compiler and Runtime](nodes/r3-svelte.md) · within containment · 2 edge(s)
- [DOM Elements](nodes/r2-dom-elements.md) → [Svelte Codebase](nodes/r2-svelte-codebase.md) · within containment · 1 edge(s)

Within containment: 2 pairs, ranked by edge count; 0 omitted. Each graph list keeps at most 40 pairs independently.

## Key flows

- **Compiler option validation** · validate-options dispatches per-key validators; type-specific checks such as boolean report failures via throw_error.
  [validate-options.js module code \(L1–L171\)](nodes/r2-compiler-foundations.md#u-63df7e79622d) → [boolean](nodes/r2-compiler-foundations.md#u-a62cec4e56c4) → [packages/svelte/src/compiler/validate-options.js:throw\_error](nodes/r2-compiler-foundations.md#u-60c04920b636)
- **Option deprecation warnings** · Deprecated options route through warn_once so each deprecation warns at most once.
  [validate-options.js module code \(L1–L171\)](nodes/r2-compiler-foundations.md#u-63df7e79622d) → [deprecate](nodes/r2-compiler-foundations.md#u-994889c21a32) → [warn\_once](nodes/r2-compiler-foundations.md#u-1215fafafc03)
- **Removed option rejection** · Options removed from the API surface are rejected directly from the module entry.
  [validate-options.js module code \(L1–L171\)](nodes/r2-compiler-foundations.md#u-63df7e79622d) → [removed](nodes/r2-compiler-foundations.md#u-57b26ac837bc)
- **Reactive declaration scoping** · VariableDeclaration serializers consult the Scope class, which validates identifier names during scope construction.
  [variabledeclaration.js-serializers](nodes/r4-transform-client.md#u-a34235f3ca3c) → [Scope](nodes/r4-compiler-scope.md#u-01a82e58170d) → [validate\_identifier\_name](nodes/r4-analyze-shared-validation.md#u-e442f835d467)
- **Destructured state lowering** · extract_paths decomposes destructuring patterns, and build_fallback constructs fallback initializer expressions.
  [variabledeclaration.js-serializers](nodes/r4-transform-client.md#u-a34235f3ca3c) → [extract\_paths](nodes/r4-compiler-ast-utils.md#u-34f2fcb20c62) → [\_extract\_paths](nodes/r4-compiler-ast-utils.md#u-9013e97c276b) → [build\_fallback](nodes/r4-compiler-ast-utils.md#u-287d48fe390a)
- **Fallback expression checks** · build_fallback classifies produced expressions, consulting simplicity and async checks before emitting.
  [variabledeclaration.js-serializers](nodes/r4-transform-client.md#u-a34235f3ca3c) → [extract\_paths](nodes/r4-compiler-ast-utils.md#u-34f2fcb20c62) → [\_extract\_paths](nodes/r4-compiler-ast-utils.md#u-9013e97c276b) → [build\_fallback](nodes/r4-compiler-ast-utils.md#u-287d48fe390a) → [is\_simple\_expression](nodes/r4-compiler-ast-utils.md#u-410082960042)

## Generation notes

- Normalized after the final invalid answer (facts kept, shape fixed): module_48, module_50, module_52, module_53, tree_region-0002, tree_region-0003.

## Aggregation principle checks

Program diagnostics only; they do not prove semantic correctness or trigger rewrites.

### P1 · pass

```json
{"empty_or_duplicate_capabilities": [], "ok": true, "principle": "P1"}
```

### P2 · observe

```json
{"modules": {"client-runtime": {"external": 0, "internal": 0, "internal_external_ratio": null}, "compiler-pipeline": {"external": 0, "internal": 0, "internal_external_ratio": null}, "public-api-types": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r1-a11y-checks": {"external": 20, "internal": 69, "internal_external_ratio": 3.45}, "r1-analysis-visitors": {"external": 58, "internal": 3, "internal_external_ratio": 0.05172413793103448}, "r1-async-reactivity": {"external": 29, "internal": 14, "internal_external_ratio": 0.4827586206896552}, "r1-attachments": {"external": 1, "internal": 0, "internal_external_ratio": 0.0}, "r1-benchmarks": {"external": 18, "internal": 2, "internal_external_ratio": 0.1111111111111111}, "r1-client-dev-diagnostics": {"external": 25, "internal": 5, "internal_external_ratio": 0.2}, "r1-client-reactivity-types": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r1-client-runtime": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r1-client-transform": {"external": 87, "internal": 8, "internal_external_ratio": 0.09195402298850575}, "r1-compiler": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r1-compiler-analyze": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r1-compiler-diagnostics-infrastructure": {"external": 1, "internal": 82, "internal_external_ratio": 82.0}, "r1-compiler-parse": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r1-compiler-transform": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r1-css-prune": {"external": 13, "internal": 78, "internal_external_ratio": 6.0}, "r1-dom-blocks": {"external": 85, "internal": 9, "internal_external_ratio": 0.10588235294117647}, "r1-element-bindings": {"external": 30, "internal": 13, "internal_external_ratio": 0.43333333333333335}, "r1-eslint-config": {"external": 0, "internal": 1, "internal_external_ratio": null}, "r1-event-system": {"external": 16, "internal": 5, "internal_external_ratio": 0.3125}, "r1-html-entity-decoding": {"external": 6, "internal": 4, "internal_external_ratio": 0.6666666666666666}, "r1-legacy-ast-conversion": {"external": 4, "internal": 8, "internal_external_ratio": 2.0}, "r1-legacy-compat-client": {"external": 18, "internal": 2, "internal_external_ratio": 0.1111111111111111}, "r1-legacy-component-adapter": {"external": 1, "internal": 0, "internal_external_ratio": 0.0}, "r1-markup-tag-parsing": {"external": 43, "internal": 10, "internal_external_ratio": 0.23255813953488372}, "r1-motion": {"external": 14, "internal": 6, "internal_external_ratio": 0.42857142857142855}, "r1-playground-sandbox": {"external": 2, "internal": 2, "internal_external_ratio": 1.0}, "r1-preprocess": {"external": 23, "internal": 23, "internal_external_ratio": 1.0}, "r1-public-api": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r1-reactive-collections": {"external": 90, "internal": 1, "internal_external_ratio": 0.011111111111111112}, "r1-rune-ambient-typings": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r1-script-expression-parsing": {"external": 31, "internal": 2, "internal_external_ratio": 0.06451612903225806}, "r1-server-runtime": {"external": 7, "internal": 11, "internal_external_ratio": 1.5714285714285714}, "r1-server-transform": {"external": 24, "internal": 1, "internal_external_ratio": 0.041666666666666664}, "r1-shared-assignment-transform": {"external": 9, "internal": 0, "internal_external_ratio": 0.0}, "r1-shared-runtime": {"external": 26, "internal": 4, "internal_external_ratio": 0.15384615384615385}, "r1-store-compat": {"external": 9, "internal": 0, "internal_external_ratio": 0.0}, "r1-svelte-monorepo": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r1-task-scheduling": {"external": 18, "internal": 0, "internal_external_ratio": 0.0}, "r1-tooling": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r1-transitions": {"external": 0, "internal": 7, "internal_external_ratio": null}, "r1-typescript-stripping": {"external": 4, "internal": 1, "internal_external_ratio": 0.25}, "r2-analyze-phase": {"external": 77, "internal": 7, "internal_external_ratio": 0.09090909090909091}, "r2-benchmarks": {"external": 24, "internal": 0, "internal_external_ratio": 0.0}, "r2-client-runtime": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r2-client-transform": {"external": 78, "internal": 23, "internal_external_ratio": 0.2948717948717949}, "r2-compiler": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r2-compiler-foundations": {"external": 46, "internal": 63, "internal_external_ratio": 1.3695652173913044}, "r2-component-context": {"external": 34, "internal": 13, "internal_external_ratio": 0.38235294117647056}, "r2-css-analyze": {"external": 15, "internal": 6, "internal_external_ratio": 0.4}, "r2-css-parse": {"external": 2, "internal": 55, "internal_external_ratio": 27.5}, "r2-css-pipeline": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r2-css-transform": {"external": 12, "internal": 21, "internal_external_ratio": 1.75}, "r2-dom-blocks": {"external": 39, "internal": 28, "internal_external_ratio": 0.717948717948718}, "r2-dom-elements": {"external": 73, "internal": 24, "internal_external_ratio": 0.3287671232876712}, "r2-legacy-client": {"external": 15, "internal": 2, "internal_external_ratio": 0.13333333333333333}, "r2-message-codegen": {"external": 7, "internal": 3, "internal_external_ratio": 0.42857142857142855}, "r2-playgrounds": {"external": 1, "internal": 14, "internal_external_ratio": 14.0}, "r2-public-api": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r2-reactive-primitives": {"external": 45, "internal": 2, "internal_external_ratio": 0.044444444444444446}, "r2-reactivity-core": {"external": 240, "internal": 85, "internal_external_ratio": 0.3541666666666667}, "r2-server-transform": {"external": 39, "internal": 7, "internal_external_ratio": 0.1794871794871795}, "r2-svelte-codebase": {"external": 22, "internal": 5, "internal_external_ratio": 0.22727272727272727}, "r2-tooling": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r3-analyze-driver": {"external": 47, "internal": 11, "internal_external_ratio": 0.23404255319148937}, "r3-analyze-phase": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r3-analyze-visitors": {"external": 67, "internal": 5, "internal_external_ratio": 0.07462686567164178}, "r3-benchmarks": {"external": 14, "internal": 3, "internal_external_ratio": 0.21428571428571427}, "r3-build-tooling": {"external": 5, "internal": 3, "internal_external_ratio": 0.6}, "r3-client-attributes": {"external": 34, "internal": 33, "internal_external_ratio": 0.9705882352941176}, "r3-client-blocks": {"external": 41, "internal": 0, "internal_external_ratio": 0.0}, "r3-client-dev": {"external": 18, "internal": 14, "internal_external_ratio": 0.7777777777777778}, "r3-client-hydration": {"external": 79, "internal": 2, "internal_external_ratio": 0.02531645569620253}, "r3-client-props": {"external": 23, "internal": 7, "internal_external_ratio": 0.30434782608695654}, "r3-client-reactivity": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r3-client-render": {"external": 32, "internal": 0, "internal_external_ratio": 0.0}, "r3-client-runtime": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r3-client-stores": {"external": 14, "internal": 0, "internal_external_ratio": 0.0}, "r3-client-template": {"external": 37, "internal": 20, "internal_external_ratio": 0.5405405405405406}, "r3-client-transform": {"external": 13, "internal": 2, "internal_external_ratio": 0.15384615384615385}, "r3-client-transform-utils": {"external": 54, "internal": 5, "internal_external_ratio": 0.09259259259259259}, "r3-client-transform-visitors": {"external": 78, "internal": 9, "internal_external_ratio": 0.11538461538461539}, "r3-compiler": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r3-compiler-entry": {"external": 10, "internal": 7, "internal_external_ratio": 0.7}, "r3-migrate-entry": {"external": 14, "internal": 10, "internal_external_ratio": 0.7142857142857143}, "r3-migrate-script-visitors": {"external": 21, "internal": 4, "internal_external_ratio": 0.19047619047619047}, "r3-migrate-template-visitors": {"external": 17, "internal": 25, "internal_external_ratio": 1.4705882352941178}, "r3-migration": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r3-public-animation-and-actions": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r3-runtime": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r3-runtime-mode-flags": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r3-server-dev": {"external": 6, "internal": 3, "internal_external_ratio": 0.5}, "r3-server-markup": {"external": 22, "internal": 0, "internal_external_ratio": 0.0}, "r3-server-render-entry": {"external": 16, "internal": 0, "internal_external_ratio": 0.0}, "r3-server-runtime": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r3-server-stores": {"external": 4, "internal": 6, "internal_external_ratio": 1.5}, "r3-server-templating": {"external": 2, "internal": 2, "internal_external_ratio": 1.0}, "r3-server-transform": {"external": 47, "internal": 18, "internal_external_ratio": 0.3829787234042553}, "r3-shared": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r3-shared-easing": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r3-shared-utils": {"external": 84, "internal": 0, "internal_external_ratio": 0.0}, "r3-svelte": {"external": 6, "internal": 0, "internal_external_ratio": 0.0}, "r3-tooling": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r4-analyze-shared-validation": {"external": 65, "internal": 3, "internal_external_ratio": 0.046153846153846156}, "r4-analyze-visitors": {"external": 60, "internal": 0, "internal_external_ratio": 0.0}, "r4-benchmarking": {"external": 74, "internal": 10, "internal_external_ratio": 0.13513513513513514}, "r4-build-codegen": {"external": 3, "internal": 0, "internal_external_ratio": 0.0}, "r4-compiler": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r4-compiler-ast-utils": {"external": 180, "internal": 11, "internal_external_ratio": 0.06111111111111111}, "r4-compiler-node-model": {"external": 80, "internal": 2, "internal_external_ratio": 0.025}, "r4-compiler-parse": {"external": 34, "internal": 36, "internal_external_ratio": 1.0588235294117647}, "r4-compiler-scope": {"external": 104, "internal": 60, "internal_external_ratio": 0.5769230769230769}, "r4-compiler-types": {"external": 4, "internal": 4, "internal_external_ratio": 1.0}, "r4-runtime-dev": {"external": 73, "internal": 16, "internal_external_ratio": 0.2191780821917808}, "r4-runtime-dom-blocks": {"external": 63, "internal": 2, "internal_external_ratio": 0.031746031746031744}, "r4-runtime-effects": {"external": 215, "internal": 43, "internal_external_ratio": 0.2}, "r4-runtime-element-bindings": {"external": 41, "internal": 5, "internal_external_ratio": 0.12195121951219512}, "r4-runtime-legacy": {"external": 2, "internal": 9, "internal_external_ratio": 4.5}, "r4-runtime-signals": {"external": 111, "internal": 19, "internal_external_ratio": 0.17117117117117117}, "r4-shared-source-utilities": {"external": 31, "internal": 0, "internal_external_ratio": 0.0}, "r4-svelte-monorepo": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r4-transform-client": {"external": 128, "internal": 10, "internal_external_ratio": 0.078125}, "r4-transform-server": {"external": 23, "internal": 2, "internal_external_ratio": 0.08695652173913043}, "r4-transform-template": {"external": 26, "internal": 2, "internal_external_ratio": 0.07692307692307693}, "r5-analyze-css": {"external": 9, "internal": 4, "internal_external_ratio": 0.4444444444444444}, "r5-analyze-visitors": {"external": 73, "internal": 9, "internal_external_ratio": 0.1232876712328767}, "r5-benchmarks": {"external": 20, "internal": 0, "internal_external_ratio": 0.0}, "r5-client-bindings": {"external": 36, "internal": 12, "internal_external_ratio": 0.3333333333333333}, "r5-client-boundary": {"external": 46, "internal": 20, "internal_external_ratio": 0.43478260869565216}, "r5-client-custom-elements": {"external": 7, "internal": 7, "internal_external_ratio": 1.0}, "r5-client-dev": {"external": 13, "internal": 4, "internal_external_ratio": 0.3076923076923077}, "r5-client-dom": {"external": 87, "internal": 9, "internal_external_ratio": 0.10344827586206896}, "r5-client-motion": {"external": 31, "internal": 8, "internal_external_ratio": 0.25806451612903225}, "r5-client-reactivity": {"external": 171, "internal": 27, "internal_external_ratio": 0.15789473684210525}, "r5-compiler": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r5-compiler-analyze": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r5-compiler-parse": {"external": 61, "internal": 53, "internal_external_ratio": 0.8688524590163934}, "r5-compiler-sourcemaps": {"external": 36, "internal": 34, "internal_external_ratio": 0.9444444444444444}, "r5-compiler-state-utils": {"external": 42, "internal": 13, "internal_external_ratio": 0.30952380952380953}, "r5-compiler-transform": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r5-playgrounds": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r5-public-types": {"external": 0, "internal": 15, "internal_external_ratio": null}, "r5-runtime-client": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r5-runtime-server": {"external": 5, "internal": 1, "internal_external_ratio": 0.2}, "r5-runtime-shared": {"external": 27, "internal": 9, "internal_external_ratio": 0.3333333333333333}, "r5-svelte": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r5-tooling": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r5-transform-client": {"external": 144, "internal": 51, "internal_external_ratio": 0.3541666666666667}, "r5-transform-entry": {"external": 18, "internal": 0, "internal_external_ratio": 0.0}, "r5-transform-server": {"external": 17, "internal": 4, "internal_external_ratio": 0.23529411764705882}, "server-and-shared-runtime": {"external": 0, "internal": 0, "internal_external_ratio": null}, "svelte-repo": {"external": 0, "internal": 0, "internal_external_ratio": null}}, "ok": false, "principle": "P2", "scope": "direct primary ownership; incident cross-module edges counted at each endpoint"}
```

### P3 · observe

```json
{"bounds": [5, 30], "ok": false, "out_of_bounds": {"r1-a11y-checks": 4, "r1-attachments": 2, "r1-benchmarks": 4, "r1-compiler-diagnostics-infrastructure": 3, "r1-eslint-config": 2, "r1-html-entity-decoding": 4, "r1-legacy-ast-conversion": 2, "r1-legacy-compat-client": 4, "r1-legacy-component-adapter": 1, "r1-reactive-collections": 4, "r1-script-expression-parsing": 3, "r1-shared-assignment-transform": 1, "r1-store-compat": 2, "r1-task-scheduling": 2, "r1-typescript-stripping": 2, "r2-benchmarks": 3, "r2-client-transform": 32, "r2-message-codegen": 4, "r3-benchmarks": 4, "r3-client-blocks": 3, "r3-client-render": 3, "r3-client-transform": 3, "r3-public-animation-and-actions": 4, "r3-runtime-mode-flags": 4, "r3-shared-easing": 1, "r3-shared-utils": 2, "r3-svelte": 1, "r4-compiler-types": 3, "r4-runtime-effects": 33, "r4-shared-source-utilities": 4, "r4-transform-template": 3, "r5-benchmarks": 4, "r5-client-custom-elements": 4, "r5-client-motion": 4, "r5-transform-entry": 4}, "principle": "P3", "scope": "nodes with directly owned units; structural ancestors excluded"}
```

### P4 · pass

```json
{"ok": true, "ownership_violations": {}, "principle": "P4"}
```

### P5 · observe

```json
{"min_dependent_modules": 2, "min_edges_per_dependent_module": 3, "note": "dependency signal only, including utilities already separated; no automatic reassignment", "ok": false, "principle": "P5", "shared_units": {"benchmarking/utils.js::function::assert::2318": {"r1-benchmarks": 6, "r2-benchmarks": 7, "r3-benchmarks": 7, "r5-benchmarks": 9}, "benchmarking/utils.js::function::fastest_test::2018": {"r1-benchmarks": 8, "r2-benchmarks": 17, "r3-benchmarks": 6, "r5-benchmarks": 9}, "grp:ast-js-attribute-helpers": {"r1-a11y-checks": 4, "r1-client-transform": 4, "r1-css-prune": 4, "r1-markup-tag-parsing": 6, "r1-script-expression-parsing": 2, "r2-analyze-phase": 5, "r2-client-transform": 4, "r2-compiler-foundations": 2, "r3-analyze-visitors": 10, "r3-client-transform-visitors": 8, "r3-migrate-template-visitors": 5, "r3-server-transform": 4, "r4-analyze-visitors": 5, "r4-transform-client": 3, "r5-analyze-visitors": 12, "r5-transform-client": 5}, "grp:hydration-js-state": {"r1-dom-blocks": 10, "r2-dom-blocks": 4, "r3-client-attributes": 4, "r3-client-blocks": 6, "r3-client-render": 5, "r3-client-template": 4, "r4-runtime-dom-blocks": 8, "r5-client-boundary": 1}, "grp:operations-js-node-lookups": {"r1-dom-blocks": 3, "r2-dom-blocks": 5, "r3-client-blocks": 4, "r3-client-hydration": 4, "r3-client-render": 4, "r3-client-template": 14, "r4-runtime-dom-blocks": 12, "r4-runtime-effects": 1, "r4-runtime-element-bindings": 4, "r5-client-boundary": 2}, "grp:runtime-js-state-and-helpers": {"r1-async-reactivity": 4, "r1-client-dev-diagnostics": 2, "r1-dom-blocks": 4, "r1-element-bindings": 8, "r1-event-system": 6, "r1-legacy-compat-client": 3, "r1-reactive-collections": 2, "r2-dom-elements": 10, "r2-legacy-client": 2, "r2-reactive-primitives": 5, "r3-client-attributes": 4, "r3-client-dev": 8, "r3-client-props": 5, "r4-runtime-dev": 5, "r4-runtime-effects": 9, "r4-runtime-legacy": 2, "r4-runtime-signals": 14, "r5-client-boundary": 6, "r5-client-dom": 2, "r5-client-reactivity": 13}, "grp:sources.js-update-helpers": {"r1-reactive-collections": 5, "r2-reactive-primitives": 7, "r3-client-props": 3, "r4-runtime-signals": 3}, "grp:utils-js-memoizer": {"r3-client-transform-visitors": 3, "r4-transform-client": 12}, "grp:utils-js-predicates": {"r1-a11y-checks": 2, "r1-client-transform": 1, "r1-markup-tag-parsing": 3, "r2-analyze-phase": 5, "r2-client-transform": 4, "r3-analyze-driver": 4, "r3-analyze-visitors": 2, "r3-client-attributes": 3, "r3-client-blocks": 2, "r3-client-dev": 2, "r3-client-render": 2, "r3-client-transform-visitors": 4, "r3-migrate-template-visitors": 6, "r3-server-markup": 2, "r3-server-render-entry": 4, "r3-server-transform": 8, "r4-analyze-visitors": 2, "r4-compiler-scope": 3, "r4-runtime-dom-blocks": 2, "r4-transform-client": 2, "r4-transform-template": 2, "r5-analyze-visitors": 7, "r5-client-dev": 2, "r5-compiler-parse": 1, "r5-compiler-state-utils": 2, "r5-runtime-shared": 2}, "packages/svelte/src/compiler/phases/1-parse/read/expression.js::function::read_expression::977": {"r1-markup-tag-parsing": 5, "r5-compiler-parse": 15}, "packages/svelte/src/compiler/phases/1-parse/utils/create.js::function::create_fragment::104": {"r1-markup-tag-parsing": 3, "r5-compiler-parse": 15}, "packages/svelte/src/compiler/phases/2-analyze/visitors/shared/fragment.js::function::mark_subtree_dynamic::83": {"r2-analyze-phase": 6, "r3-analyze-driver": 2, "r3-analyze-visitors": 9, "r4-analyze-visitors": 10, "r5-analyze-visitors": 12}, "packages/svelte/src/compiler/phases/2-analyze/visitors/shared/utils.js::function::validate_block_not_empty::4728": {"r2-analyze-phase": 6, "r3-analyze-visitors": 3, "r5-analyze-visitors": 5}, "packages/svelte/src/compiler/phases/2-analyze/visitors/shared/utils.js::function::validate_opening_tag::4367": {"r2-analyze-phase": 4, "r3-analyze-visitors": 3, "r4-analyze-visitors": 5, "r5-analyze-visitors": 3}, "packages/svelte/src/compiler/phases/3-transform/client/transform-template/template.js::class::Template::368::s0": {"r1-client-transform": 4, "r2-client-transform": 3, "r3-client-transform-visitors": 1, "r4-transform-client": 2, "r5-transform-client": 9}, "packages/svelte/src/compiler/phases/3-transform/client/utils.js::function::build_getter::1220": {"r1-client-transform": 2, "r3-client-transform": 4, "r3-client-transform-visitors": 5, "r4-transform-client": 2, "r5-transform-client": 2}, "packages/svelte/src/compiler/phases/3-transform/client/utils.js::function::create_derived::8270": {"r1-client-transform": 3, "r2-client-transform": 2, "r4-transform-client": 3}, "packages/svelte/src/compiler/phases/3-transform/client/utils.js::function::should_proxy::7118": {"r3-client-transform-visitors": 2, "r4-transform-client": 3, "r5-analyze-visitors": 2, "r5-transform-client": 3}, "packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/element.js::function::build_attribute_value::3231": {"r2-client-transform": 2, "r3-client-transform-visitors": 6, "r5-transform-client": 3}, "packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/utils.js::function::build_expression::11292": {"r1-client-transform": 6, "r3-client-transform-visitors": 2, "r4-transform-client": 7}, "packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/utils.js::function::build_attribute_value::4710": {"r1-server-transform": 2, "r3-server-transform": 11, "r5-transform-server": 5}, "packages/svelte/src/compiler/phases/nodes.js::function::create_attribute::1509": {"r1-markup-tag-parsing": 5, "r2-analyze-phase": 3, "r3-analyze-driver": 3, "r3-server-transform": 2}, "packages/svelte/src/compiler/phases/nodes.js::function::create_expression_metadata::1740": {"r1-markup-tag-parsing": 7, "r2-analyze-phase": 2, "r3-server-transform": 2, "r4-analyze-visitors": 2, "r4-compiler-scope": 1, "r5-compiler-parse": 11}, "packages/svelte/src/compiler/phases/nodes.js::function::get_name::2027": {"r1-client-transform": 2, "r1-server-transform": 4, "r3-analyze-visitors": 4, "r4-analyze-shared-validation": 2, "r4-analyze-visitors": 2, "r5-transform-client": 1}, "packages/svelte/src/compiler/phases/scope.js::class::Scope::13363::s0": {"r1-client-transform": 2, "r2-client-transform": 6, "r3-client-transform-visitors": 1, "r3-svelte": 1, "r4-transform-client": 17, "r4-transform-server": 7, "r5-analyze-visitors": 2, "r5-transform-client": 5, "r5-transform-server": 2}, "packages/svelte/src/compiler/phases/scope.js::function::get_rune::34200": {"r1-server-transform": 2, "r2-analyze-phase": 3, "r2-client-transform": 1, "r2-server-transform": 1, "r3-analyze-driver": 4, "r3-analyze-visitors": 2, "r3-client-transform-visitors": 1, "r3-migrate-script-visitors": 2, "r4-analyze-shared-validation": 2, "r4-analyze-visitors": 2, "r4-transform-client": 2, "r4-transform-server": 5, "r5-analyze-visitors": 2, "r5-transform-client": 2, "r5-transform-server": 2}, "packages/svelte/src/compiler/state.js::function::is_ignored::2286": {"r1-client-transform": 2, "r2-client-transform": 2, "r3-client-transform-visitors": 6, "r4-transform-client": 7, "r5-transform-client": 4, "r5-transform-server": 2}, "packages/svelte/src/compiler/utils/ast.js::function::build_assignment_value::17513": {"r1-server-transform": 3, "r5-transform-client": 3}, "packages/svelte/src/compiler/utils/ast.js::function::extract_identifiers::4009": {"r1-client-transform": 2, "r1-server-transform": 2, "r2-client-transform": 2, "r3-analyze-driver": 3, "r3-analyze-visitors": 2, "r3-migrate-entry": 2, "r3-migrate-script-visitors": 2, "r4-analyze-shared-validation": 2, "r4-analyze-visitors": 1, "r4-compiler-scope": 8, "r4-transform-client": 2, "r5-analyze-visitors": 3}, "packages/svelte/src/compiler/utils/ast.js::function::extract_paths::7725": {"r1-shared-assignment-transform": 2, "r2-client-transform": 2, "r4-analyze-visitors": 2, "r4-transform-client": 5, "r4-transform-server": 3, "r5-transform-client": 2}, "packages/svelte/src/compiler/utils/ast.js::function::unwrap_optional::13743": {"r1-server-transform": 3, "r4-analyze-visitors": 3, "r5-transform-client": 2}, "packages/svelte/src/compiler/utils/slot.js::function::determine_slot::181": {"r3-analyze-visitors": 3, "r4-compiler-scope": 2, "r5-transform-client": 3}, "packages/svelte/src/escaping.js::function::escape_html::134": {"r2-server-transform": 3, "r2-svelte-codebase": 2, "r3-server-markup": 6, "r3-server-transform": 1, "r4-transform-client": 2, "r4-transform-template": 2}, "packages/svelte/src/internal/client/dev/tracing.js::function::get_stack::3464": {"r2-reactivity-core": 2, "r4-runtime-signals": 3, "r5-client-reactivity": 3}, "packages/svelte/src/internal/client/dev/tracing.js::function::tag::4284": {"r1-motion": 2, "r1-reactive-collections": 15, "r2-reactive-primitives": 3, "r4-runtime-signals": 9, "r5-client-boundary": 1, "r5-client-motion": 7, "r5-client-reactivity": 3}, "packages/svelte/src/internal/client/dom/elements/bindings/shared.js::function::listen::550": {"r4-runtime-element-bindings": 23, "r5-client-bindings": 7}, "packages/svelte/src/internal/client/dom/hydration.js::function::set_hydrate_node::1099": {"r1-dom-blocks": 2, "r2-dom-blocks": 3, "r3-client-blocks": 2, "r3-client-render": 2, "r3-client-template": 1, "r4-runtime-dom-blocks": 6, "r5-client-boundary": 2, "r5-client-dom": 7}, "packages/svelte/src/internal/client/loop.js::function::loop::722::s0": {"r1-motion": 4, "r2-dom-elements": 1, "r5-client-motion": 4}, "packages/svelte/src/internal/client/reactivity/batch.js::class::Batch::1920::s0": {"r1-dom-blocks": 1, "r2-dom-blocks": 1, "r4-runtime-effects": 2, "r4-runtime-signals": 6, "r5-client-boundary": 2, "r5-client-reactivity": 3}, "packages/svelte/src/internal/client/reactivity/effects.js::function::block::8446": {"r1-client-dev-diagnostics": 2, "r1-dom-blocks": 4, "r2-dom-blocks": 1, "r3-client-attributes": 1, "r3-client-blocks": 4, "r4-runtime-dom-blocks": 6, "r5-client-boundary": 1}, "packages/svelte/src/internal/client/reactivity/effects.js::function::branch::8675": {"r1-client-dev-diagnostics": 2, "r1-dom-blocks": 8, "r2-dom-blocks": 3, "r3-client-attributes": 1, "r3-client-blocks": 4, "r3-client-render": 1, "r4-runtime-dom-blocks": 4, "r5-client-boundary": 6}, "packages/svelte/src/internal/client/reactivity/effects.js::function::effect::6413": {"r1-element-bindings": 1, "r2-dom-elements": 3, "r3-client-attributes": 1, "r3-client-blocks": 1, "r4-runtime-dom-blocks": 2, "r4-runtime-element-bindings": 3, "r5-client-bindings": 2, "r5-client-dom": 2}, "packages/svelte/src/internal/client/reactivity/effects.js::function::pause_effect::12656": {"r1-dom-blocks": 4, "r2-dom-blocks": 1, "r3-client-blocks": 4, "r4-runtime-dom-blocks": 2, "r5-client-boundary": 3}, "packages/svelte/src/internal/client/reactivity/effects.js::function::render_effect::7960": {"r1-client-dev-diagnostics": 5, "r1-element-bindings": 5, "r1-motion": 1, "r2-reactive-primitives": 2, "r4-runtime-dev": 2, "r4-runtime-dom-blocks": 2, "r4-runtime-element-bindings": 3, "r5-client-bindings": 5, "r5-client-custom-elements": 1, "r5-client-dom": 2, "r5-client-motion": 2}, "packages/svelte/src/internal/client/reactivity/effects.js::function::teardown::3959": {"r1-attachments": 1, "r1-dom-blocks": 2, "r1-element-bindings": 1, "r1-event-system": 2, "r2-dom-elements": 4, "r3-client-stores": 2, "r4-runtime-element-bindings": 1, "r5-client-bindings": 8}, "packages/svelte/src/internal/client/reactivity/sources.js::function::internal_set::3725": {"r1-dom-blocks": 3, "r1-legacy-compat-client": 2, "r2-dom-blocks": 2, "r4-runtime-signals": 3, "r5-client-boundary": 1}, "packages/svelte/src/internal/client/reactivity/sources.js::function::source::1477": {"r1-client-dev-diagnostics": 2, "r1-dom-blocks": 2, "r1-reactive-collections": 1, "r2-dom-blocks": 3, "r2-legacy-client": 1, "r2-reactive-primitives": 2, "r3-client-props": 1, "r4-runtime-signals": 11, "r5-client-boundary": 1}, "packages/svelte/src/internal/client/reactivity/sources.js::function::state::1976": {"r1-motion": 2, "r1-reactive-collections": 12, "r2-reactive-primitives": 2, "r5-client-motion": 7}, "packages/svelte/src/internal/client/render.js::function::set_should_intro::1451": {"r1-client-dev-diagnostics": 3, "r3-client-blocks": 3}, "packages/svelte/src/internal/client/runtime.js::function::get::15253": {"r1-client-dev-diagnostics": 2, "r1-dom-blocks": 2, "r1-legacy-compat-client": 2, "r1-reactive-collections": 24, "r2-dom-blocks": 2, "r2-legacy-client": 2, "r2-reactive-primitives": 1, "r3-client-stores": 2, "r5-client-boundary": 1, "r5-client-motion": 5, "r5-client-reactivity": 12}, "packages/svelte/src/store/shared/index.js::function::get::5098": {"r2-reactive-primitives": 5, "r5-runtime-server": 4}}}
```

### P6 · pass

```json
{"modules": {"client-runtime": {}, "compiler-pipeline": {}, "public-api-types": {}, "r1-a11y-checks": {"javascript": 4}, "r1-analysis-visitors": {"javascript": 10}, "r1-async-reactivity": {"javascript": 8}, "r1-attachments": {"javascript": 2}, "r1-benchmarks": {"javascript": 4}, "r1-client-dev-diagnostics": {"javascript": 11}, "r1-client-reactivity-types": {"typescript": 8}, "r1-client-runtime": {}, "r1-client-transform": {"javascript": 20, "typescript": 1}, "r1-compiler": {}, "r1-compiler-analyze": {}, "r1-compiler-diagnostics-infrastructure": {"javascript": 3}, "r1-compiler-parse": {}, "r1-compiler-transform": {}, "r1-css-prune": {"javascript": 19}, "r1-dom-blocks": {"javascript": 11}, "r1-element-bindings": {"javascript": 8}, "r1-eslint-config": {"javascript": 2}, "r1-event-system": {"javascript": 7}, "r1-html-entity-decoding": {"javascript": 4}, "r1-legacy-ast-conversion": {"javascript": 2}, "r1-legacy-compat-client": {"javascript": 4}, "r1-legacy-component-adapter": {"javascript": 1}, "r1-markup-tag-parsing": {"javascript": 8}, "r1-motion": {"javascript": 5}, "r1-playground-sandbox": {"javascript": 6}, "r1-preprocess": {"javascript": 10}, "r1-public-api": {}, "r1-reactive-collections": {"javascript": 3, "typescript": 1}, "r1-rune-ambient-typings": {"typescript": 8}, "r1-script-expression-parsing": {"javascript": 3}, "r1-server-runtime": {"javascript": 12}, "r1-server-transform": {"javascript": 16, "typescript": 1}, "r1-shared-assignment-transform": {"javascript": 1}, "r1-shared-runtime": {"javascript": 5, "typescript": 1}, "r1-store-compat": {"javascript": 1, "typescript": 1}, "r1-svelte-monorepo": {}, "r1-task-scheduling": {"javascript": 2}, "r1-tooling": {}, "r1-transitions": {"javascript": 8}, "r1-typescript-stripping": {"javascript": 2}, "r2-analyze-phase": {"javascript": 17}, "r2-benchmarks": {"javascript": 3}, "r2-client-runtime": {}, "r2-client-transform": {"javascript": 31, "typescript": 1}, "r2-compiler": {}, "r2-compiler-foundations": {"javascript": 21, "typescript": 3}, "r2-component-context": {"javascript": 13}, "r2-css-analyze": {"javascript": 11}, "r2-css-parse": {"javascript": 14}, "r2-css-pipeline": {}, "r2-css-transform": {"javascript": 8}, "r2-dom-blocks": {"javascript": 7}, "r2-dom-elements": {"javascript": 15}, "r2-legacy-client": {"javascript": 10}, "r2-message-codegen": {"javascript": 4}, "r2-playgrounds": {"javascript": 8}, "r2-public-api": {"javascript": 1, "typescript": 9}, "r2-reactive-primitives": {"javascript": 7, "typescript": 1}, "r2-reactivity-core": {"javascript": 28}, "r2-server-transform": {"javascript": 11}, "r2-svelte-codebase": {"javascript": 7, "typescript": 2}, "r2-tooling": {}, "r3-analyze-driver": {"javascript": 6}, "r3-analyze-phase": {}, "r3-analyze-visitors": {"javascript": 18}, "r3-benchmarks": {"javascript": 4}, "r3-build-tooling": {"javascript": 5}, "r3-client-attributes": {"javascript": 17}, "r3-client-blocks": {"javascript": 3}, "r3-client-dev": {"javascript": 13, "typescript": 1}, "r3-client-hydration": {"javascript": 6}, "r3-client-props": {"javascript": 6}, "r3-client-reactivity": {}, "r3-client-render": {"javascript": 3}, "r3-client-runtime": {}, "r3-client-stores": {"javascript": 5}, "r3-client-template": {"javascript": 11}, "r3-client-transform": {"javascript": 3}, "r3-client-transform-utils": {"javascript": 8}, "r3-client-transform-visitors": {"javascript": 14}, "r3-compiler": {}, "r3-compiler-entry": {"javascript": 6}, "r3-migrate-entry": {"javascript": 6}, "r3-migrate-script-visitors": {"javascript": 7}, "r3-migrate-template-visitors": {"javascript": 9}, "r3-migration": {}, "r3-public-animation-and-actions": {"javascript": 1, "typescript": 3}, "r3-runtime": {}, "r3-runtime-mode-flags": {"javascript": 4}, "r3-server-dev": {"javascript": 8}, "r3-server-markup": {"javascript": 16}, "r3-server-render-entry": {"javascript": 11}, "r3-server-runtime": {}, "r3-server-stores": {"javascript": 12}, "r3-server-templating": {"javascript": 22}, "r3-server-transform": {"javascript": 11}, "r3-shared": {}, "r3-shared-easing": {"javascript": 1}, "r3-shared-utils": {"javascript": 2}, "r3-svelte": {"javascript": 1}, "r3-tooling": {}, "r4-analyze-shared-validation": {"javascript": 10}, "r4-analyze-visitors": {"javascript": 19}, "r4-benchmarking": {"javascript": 9}, "r4-build-codegen": {"javascript": 5, "typescript": 2}, "r4-compiler": {}, "r4-compiler-ast-utils": {"javascript": 14}, "r4-compiler-node-model": {"javascript": 9}, "r4-compiler-parse": {"javascript": 23}, "r4-compiler-scope": {"javascript": 9}, "r4-compiler-types": {"typescript": 3}, "r4-runtime-dev": {"javascript": 13}, "r4-runtime-dom-blocks": {"javascript": 7}, "r4-runtime-effects": {"javascript": 33}, "r4-runtime-element-bindings": {"javascript": 16}, "r4-runtime-legacy": {"javascript": 9}, "r4-runtime-signals": {"javascript": 13}, "r4-shared-source-utilities": {"javascript": 4}, "r4-svelte-monorepo": {}, "r4-transform-client": {"javascript": 16}, "r4-transform-server": {"javascript": 5}, "r4-transform-template": {"javascript": 3}, "r5-analyze-css": {"javascript": 10}, "r5-analyze-visitors": {"javascript": 19}, "r5-benchmarks": {"javascript": 4}, "r5-client-bindings": {"javascript": 11}, "r5-client-boundary": {"javascript": 7}, "r5-client-custom-elements": {"javascript": 4}, "r5-client-dev": {"javascript": 5}, "r5-client-dom": {"javascript": 9}, "r5-client-motion": {"javascript": 4}, "r5-client-reactivity": {"javascript": 16}, "r5-compiler": {}, "r5-compiler-analyze": {}, "r5-compiler-parse": {"javascript": 17}, "r5-compiler-sourcemaps": {"javascript": 19}, "r5-compiler-state-utils": {"javascript": 15, "typescript": 1}, "r5-compiler-transform": {}, "r5-playgrounds": {"javascript": 5}, "r5-public-types": {"typescript": 8}, "r5-runtime-client": {}, "r5-runtime-server": {"javascript": 12, "typescript": 1}, "r5-runtime-shared": {"javascript": 10}, "r5-svelte": {}, "r5-tooling": {}, "r5-transform-client": {"javascript": 25}, "r5-transform-entry": {"javascript": 4}, "r5-transform-server": {"javascript": 6}, "server-and-shared-runtime": {}, "svelte-repo": {}}, "ok": true, "principle": "P6", "scope": "unit counts by language; a multi-language unit contributes once per language"}
```

### P7 · re-render identical

```json
{"identical": true, "ok": null, "principle": "P7", "scope": "same run, same detail answers; cross-run stability requires replay scripts", "status": "re-render identical"}
```

Hierarchy and introduction length:

```json
{"hierarchy": {"ok": true, "requires_intermediate_above_units": 30}, "introduction_length": {"ok": true, "overlong": {}, "scope": "capability+summary characters versus descendant explain characters"}}
```
