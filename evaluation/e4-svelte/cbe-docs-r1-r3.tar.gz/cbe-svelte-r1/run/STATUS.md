# CBE run status

Run `2e797c` · status **complete** · updated 2026-10-17T16:16:38Z · review sample · jobs 2 · host api

Semantic review: mode **sample**; 1/1 reviewed by a separate reader of the source. This is independent of the deterministic structure/coverage checks and does not prove whole-map truth.

Counts: done 74

id_corrected 14

- module_54: ` packages/svelte/src/internal/client/reactivity/store.js::function::store_set::104 ` → ` packages/svelte/src/internal/client/reactivity/store.js::function::store_set::3438 ` (units[27].id)
- module_54: ` packages/svelte/src/internal/client/reactivity/store.js::function::invalidate_store::113 ` → ` packages/svelte/src/internal/client/reactivity/store.js::function::invalidate_store::3599 ` (units[28].id)
- module_54: ` packages/svelte/src/internal/client/reactivity/store.js::function::store_mutate::151 ` → ` packages/svelte/src/internal/client/reactivity/store.js::function::store_mutate::4466 ` (units[30].id)
- module_54: ` packages/svelte/src/internal/client/reactivity/store.js::function::update_store::162 ` → ` packages/svelte/src/internal/client/reactivity/store.js::function::update_store::4688 ` (units[31].id)
- module_54: ` packages/svelte/src/internal/client/reactivity/store.js::function::update_pre_store::173 ` → ` packages/svelte/src/internal/client/reactivity/store.js::function::update_pre_store::4914 ` (units[32].id)
- module_54: ` packages/svelte/src/internal/client/reactivity/store.js::function::mark_store_binding::182 ` → ` packages/svelte/src/internal/client/reactivity/store.js::function::mark_store_binding::5131 ` (units[33].id)
- module_54: ` packages/svelte/src/internal/client/reactivity/store.js::function::capture_store_binding::194 ` → ` packages/svelte/src/internal/client/reactivity/store.js::function::capture_store_binding::5510 ` (units[34].id)
- module_54: ` packages/svelte/src/internal/client/reactivity/store.js::function::store_set::104 ` → ` packages/svelte/src/internal/client/reactivity/store.js::function::store_set::3438 ` (dispositions[packages/svelte/src/internal/client/reactivity/store.js::function::store_set::3438].unit)
- module_54: ` packages/svelte/src/internal/client/reactivity/store.js::function::invalidate_store::113 ` → ` packages/svelte/src/internal/client/reactivity/store.js::function::invalidate_store::3599 ` (dispositions[packages/svelte/src/internal/client/reactivity/store.js::function::invalidate_store::3599].unit)
- module_54: ` packages/svelte/src/internal/client/reactivity/store.js::function::store_mutate::151 ` → ` packages/svelte/src/internal/client/reactivity/store.js::function::store_mutate::4466 ` (dispositions[packages/svelte/src/internal/client/reactivity/store.js::function::store_mutate::4466].unit)
- module_54: ` packages/svelte/src/internal/client/reactivity/store.js::function::update_store::162 ` → ` packages/svelte/src/internal/client/reactivity/store.js::function::update_store::4688 ` (dispositions[packages/svelte/src/internal/client/reactivity/store.js::function::update_store::4688].unit)
- module_54: ` packages/svelte/src/internal/client/reactivity/store.js::function::update_pre_store::173 ` → ` packages/svelte/src/internal/client/reactivity/store.js::function::update_pre_store::4914 ` (dispositions[packages/svelte/src/internal/client/reactivity/store.js::function::update_pre_store::4914].unit)
- module_54: ` packages/svelte/src/internal/client/reactivity/store.js::function::mark_store_binding::182 ` → ` packages/svelte/src/internal/client/reactivity/store.js::function::mark_store_binding::5131 ` (dispositions[packages/svelte/src/internal/client/reactivity/store.js::function::mark_store_binding::5131].unit)
- module_54: ` packages/svelte/src/internal/client/reactivity/store.js::function::capture_store_binding::194 ` → ` packages/svelte/src/internal/client/reactivity/store.js::function::capture_store_binding::5510 ` (dispositions[packages/svelte/src/internal/client/reactivity/store.js::function::capture_store_binding::5510].unit)

index_only_filled 0


answer_fallback 1

- module_42: accepted attempt 2 (final attempt 3)

| Task | Module | State | Attempts | Seconds | Output | Note |
|---|---|---|---:|---:|---|---|
| names |  | done | 1 | 19.0 | host/accepted/names.json |  |
| module_1 | Benchmark Runner Entry and Utilities | done | 1 | 49.0 | host/accepted/module_1.json |  |
| module_2 | Reactivity and SSR Benchmark Suites (Kairo, Mol, Svelte) | done | 1 | 147.0 | host/accepted/module_2.json |  |
| module_3 | Benchmark Comparison Runner | done | 1 | 20.0 | host/accepted/module_3.json |  |
| module_4 | ESLint Configuration | done | 1 | 24.0 | host/accepted/module_4.json |  |
| module_5 | Svelte Sandbox Playground with SSR and Scripts | done | 2 | 53.0 | host/accepted/module_5.json |  |
| module_6 | DOM Element and Attribute Type Declarations | done | 2 | 125.0 | host/accepted/module_6.json |  |
| module_7 | Rollup Build Config and HTML Typings | done | 1 | 33.0 | host/accepted/module_7.json |  |
| module_8 | Code Generation and Compiler Message Templates | done | 3 | 110.0 | host/accepted/module_8.json |  |
| module_9 | Core Constants, Escaping, and Shared Utilities | done | 1 | 205.0 | host/accepted/module_9.json |  |
| module_10 | Public Client/Server Entry Points and HTML Validation | done | 1 | 66.0 | host/accepted/module_10.json |  |
| module_11 | Compiler Error Code Definitions | done | 1 | 157.0 | host/accepted/module_11.json |  |
| module_12 | Compiler API Types and Warning Definitions | done | 1 | 123.0 | host/accepted/module_12.json |  |
| module_13 | Compiler Entry, Legacy API, and Option Validation | done | 1 | 168.0 | host/accepted/module_13.json |  |
| module_14 | Svelte 4 to 5 Migration Tooling | done | 2 | 173.0 | host/accepted/module_14.json |  |
| module_15 | AST Nodes and Scope Analysis | done | 1 | 160.0 | host/accepted/module_15.json |  |
| module_16 | Parser Entry with Acorn and TypeScript Node Stripping | done | 3 | 100.0 | host/accepted/module_16.json |  |
| module_17 | Source Readers for Expressions, Scripts, Styles, Options | done | 1 | 141.0 | host/accepted/module_17.json |  |
| module_18 | Parser States for Elements, Fragments, and Text | done | 1 | 90.0 | host/accepted/module_18.json |  |
| module_19 | Parser State for Tag Reading | done | 1 | 61.0 | host/accepted/module_19.json |  |
| module_20 | HTML Entity Lookup Table | done | 1 | 16.0 | host/accepted/module_20.json |  |
| module_21 | Parser Utilities: Bracket Matching, Node Creation, Fuzzy Matching | done | 1 | 132.0 | host/accepted/module_21.json |  |
| module_22 | Analyze Phase Entry and Types | done | 2 | 81.0 | host/accepted/module_22.json |  |
| module_23 | CSS Pruning and Selector Utilities | done | 1 | 152.0 | host/accepted/module_23.json |  |
| module_24 | Analyze Visitors: Attributes, Bindings, Events, Elements, Snippets | done | 1 | 120.0 | host/accepted/module_24.json |  |
| module_25 | Analyze Visitors for Blocks, Expressions, and Statements | done | 2 | 152.0 | host/accepted/module_25.json |  |
| module_26 | Shared Analyze Visitor Helpers | done | 1 | 104.0 | host/accepted/module_26.json |  |
| module_27 | Accessibility Warning Checks | done | 2 | 98.0 | host/accepted/module_27.json |  |
| module_28 | Analyze Visitors for Components, CSS, and Special Elements | done | 2 | 144.0 | host/accepted/module_28.json |  |
| module_29 | Transform Phase Entry, Types, and Utilities | done | 2 | 73.0 | host/accepted/module_29.json |  |
| module_30 | Client-Side Code Generation Core | done | 1 | 86.0 | host/accepted/module_30.json |  |
| module_31 | Client Transform Visitors: Events, Elements, Boundaries | done | 4 | 98.0 | host/accepted/module_31.json |  |
| module_32 | Client Transform Visitors: Blocks, Bindings, Fragments | done | 1 | 107.0 | host/accepted/module_32.json |  |
| module_33 | Client Transform Visitors: Control Flow and Directives | done | 2 | 142.0 | host/accepted/module_33.json |  |
| module_34 | Shared Client Transform Visitor Helpers | done | 1 | 138.0 | host/accepted/module_34.json |  |
| module_35 | Client Template Generation and Remaining Visitors | done | 1 | 166.0 | host/accepted/module_35.json |  |
| module_36 | Server-Side Render Visitors | done | 1 | 145.0 | host/accepted/module_36.json |  |
| module_37 | Shared Server Render Visitor Helpers | done | 3 | 89.0 | host/accepted/module_37.json |  |
| module_38 | Server Transform Core, CSS Output, and Shared Assignments | done | 1 | 119.0 | host/accepted/module_38.json |  |
| module_39 | Preprocessing and Sourcemap Handling | done | 3 | 103.0 | host/accepted/module_39.json |  |
| module_40 | Compiler Type Declarations (AST, CSS, Template, Legacy) | done | 2 | 177.0 | host/accepted/module_40.json |  |
| module_41 | Compiler Utilities: AST, Builders, Diagnostics | done | 1 | 205.0 | host/accepted/module_41.json |  |
| module_42 | Compiler Utilities: Assertions, Strings, Slots | done | 3 | 87.0 | host/accepted/module_42.json | normalized (18); answer_fallback attempt 2 |
| module_43 | Client Runtime Core and Error Definitions | done | 2 | 130.0 | host/accepted/module_43.json |  |
| module_44 | Client Runtime Entry, Proxies, and Rendering | done | 1 | 117.0 | host/accepted/module_44.json |  |
| module_45 | Client Context, Legacy Support, and Validation Helpers | done | 3 | 94.0 | host/accepted/module_45.json |  |
| module_46 | Development-Mode Checks, HMR, and Ownership Validation | done | 1 | 118.0 | host/accepted/module_46.json |  |
| module_47 | Client DOM Operations, Hydration, and Templates | done | 1 | 129.0 | host/accepted/module_47.json |  |
| module_48 | Client Control-Flow Blocks: Await, Boundary, Each, If | done | 3 | 139.0 | host/accepted/module_48.json |  |
| module_49 | Client DOM Blocks: Slots, Snippets, Head, Key, HTML | done | 1 | 111.0 | host/accepted/module_49.json |  |
| module_50 | Client Element Attributes, Styles, and Transitions | done | 3 | 164.0 | host/accepted/module_50.json |  |
| module_51 | Client Element Actions, Attachments, and Events | done | 1 | 117.0 | host/accepted/module_51.json |  |
| module_52 | Client Element Two-Way Bindings | done | 2 | 168.0 | host/accepted/module_52.json |  |
| module_53 | Client Reactivity: Batches, Async, Effects | done | 1 | 187.0 | host/accepted/module_53.json |  |
| module_54 | Client Reactivity: Signals, Props, Stores | done | 3 | 197.0 | host/accepted/module_54.json | normalized (42); id_corrected 14 |
| module_55 | Server-Side Rendering Core | done | 1 | 186.0 | host/accepted/module_55.json |  |
| module_56 | Shared Internal Utilities, Validation, and Warnings | done | 4 | 113.0 | host/accepted/module_56.json |  |
| module_57 | Motion Primitives: Springs and Tweens | done | 1 | 133.0 | host/accepted/module_57.json |  |
| module_58 | Reactive Built-ins: Map, Set, Date, Media, URL | done | 2 | 118.0 | host/accepted/module_58.json |  |
| module_59 | Reactive Wrapper Implementations and Tests | done | 1 | 101.0 | host/accepted/module_59.json |  |
| module_60 | Easing, Transitions, Stores, and Legacy Runtime Support | done | 2 | 219.0 | host/accepted/module_60.json |  |
| module_61 | Public API Entrypoints for Actions, Stores, and Legacy Modules | done | 4 | 175.0 | host/accepted/module_61.json |  |
| module_62 | Public Svelte Type Definitions | done | 1 | 491.0 | host/accepted/module_62.json |  |
| module_63 | Server Entry, Internal Flags, and Event/Store Utilities | done | 1 | 82.0 | host/accepted/module_63.json |  |
| module_64 | Repository Svelte Configuration | done | 1 | 10.0 | host/accepted/module_64.json |  |
| module_65 | Vitest Test Configuration | done | 1 | 16.0 | host/accepted/module_65.json |  |
| tree |  | done | 2 | 54.0 | host/accepted/tree.json |  |
| tree_region-0001 |  | done | 1 | 197.0 | host/accepted/tree_region-0001.json |  |
| tree_region-0002 |  | done | 2 | 166.0 | host/accepted/tree_region-0002.json |  |
| tree_region-0003 |  | done | 2 | 115.0 | host/accepted/tree_region-0003.json |  |
| tree_region-0004 |  | done | 1 | 204.0 | host/accepted/tree_region-0004.json |  |
| tree_region-0005 |  | done | 2 | 162.0 | host/accepted/tree_region-0005.json |  |
| review_62 | Public Svelte Type Definitions | done | 1 | 32.0 | host/accepted/review_62.json |  |
| system |  | done | 3 | 34.0 | host/accepted/system.json |  |
