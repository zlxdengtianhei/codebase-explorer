# Codebase Explorer

## How to read this report

Start with the responsibility tree in INDEX. Open a node page for your maintenance question, then choose a unit.
Node pages explain responsibilities. `catalog.json` stores full signatures, source ranges, folded members, relation evidence, and graph edges.
Set `RUN` to the absolute path of this run directory. Find an id, then read its explanation or frozen source.

```sh
cbe find --run-dir "$RUN" --term "SEARCH_TERM"
cbe query --run-dir "$RUN" --id "$ID"
cbe source --run-dir "$RUN" --id "$ID" --context 2
```

`ID` can be a unit id, symbol id, or file path. Commands return the content directly.
`source` reads frozen source and verifies its digest first.
The catalog also stores reverse graph edges, statuses, and raw evidence.

## Responsibility tree

- [Svelte Monorepo](nodes/svelte-monorepo.md) (0 units)
  - [Svelte Monorepo](nodes/r1-root.md) (0 units)
    - [Reactivity Benchmarking](nodes/r1-benchmarking.md) (3 units)
      - [runner.js module code (L1–L10)](nodes/r1-benchmarking.md#u-0b0dc218fb67) · Benchmark runner child process: imports the reactivity benchmark list, awaits each benchmark in order, logs its benchmark name to stderr, collects results into an array, and sends the whole array to the parent via process.send.
    - [Build & Repo Tooling](nodes/r1-build-tooling.md) (1 units)
      - [rollup.config.js module code (L1–L17)](nodes/r1-build-tooling.md#u-2eb418b9a160) · Builds the Rollup configuration that compiles the Svelte compiler into a single UMD bundle.
      - [ESLint Configuration](nodes/r1-lint-config.md) (3 units)
        - [create](nodes/r1-lint-config.md#u-34b493301cfd) · Implements the custom no_compiler_imports rule: on each Program it searches the whole source text for compiler references and reports the first occurrence.
      - [Treeshakeability Audit](nodes/r1-treeshakeability-audit.md) (4 units)
        - [check-treeshakeability.js-bundle-code](nodes/r1-treeshakeability-audit.md#u-df4ca4955d27) · Bundles an in-memory entry string via rollup and returns its single chunk of JavaScript, rewriting 'svelte' imports to the package's own export files.
      - [Warning/Error Codegen Templates](nodes/r1-message-codegen-templates.md) (2 units)
        - [packages/svelte/scripts/process-messages/templates/server-errors.js:CODE](nodes/r1-message-codegen-templates.md#u-85f7bd54b8a3) · Template for generated server-side error throwers, unconditional on DEV.
    - [Compiler Pipeline](nodes/r1-compiler.md) (0 units)
      - [HTML Entity Decoding](nodes/r1-parse-entities.md) (6 units)
        - [entities.js module code (L2–L1682)](nodes/r1-parse-entities.md#u-582eaddeee2c) · Default-exports a large lookup table mapping HTML named character references (with trailing semicolon, e.g. 'amp;') to their Unicode code points, generated from the WHATWG entities.json spec.
      - [Analysis Phase](nodes/r1-analysis.md) (0 units)
        - [Analysis Infrastructure & Visitor Helpers](nodes/r1-analysis-infra.md) (7 units)
          - [AnalysisState](nodes/r1-analysis-infra.md#u-ee2ed2e166eb) · Type-only declaration of the mutable state threaded through the analysis walkers.
        - [Accessibility Analysis](nodes/r1-a11y-analysis.md) (3 units)
          - [constants.js module code (L1–L319)](nodes/r1-a11y-analysis.md#u-0304f5d2800a) · Builds the static a11y data tables and derived role/AXObject classification sets used by the a11y analyzer.
        - [CSS Selector Pruning](nodes/r1-css-pruning.md) (20 units)
          - [css-prune-js-prune](nodes/r1-css-pruning.md#u-ff716446121a) · Marks CSS selectors as used when they match a given template element.
      - [Svelte 4 Automigrator](nodes/r1-migrator.md) (22 units)
        - [migrate](nodes/r1-migrator.md#u-0c9d6fc8a11a) · Best-effort migration entry point of Svelte 4 components toward runes, event attributes, and render tags; this first half performs setup.
      - [Client Transform Phase](nodes/r1-client-transform.md) (0 units)
        - [Template Serialization](nodes/r1-client-template.md) (3 units)
          - [Template](nodes/r1-client-template.md#u-f09b36ebd45e) · Accumulates a lightweight template node tree (elements, comments, text) that visitors populate while walking markup, then serializes it either as an HTML string template or as a tree literal.
        - [Client Block & Element Visitors](nodes/r1-client-block-visitors.md) (10 units)
          - [Program](nodes/r1-client-block-visitors.md#u-ba1f8c9b6c22) · Installs name transforms for the component's top-level scope before visiting the program body.
        - [Shared Client Transform Builders](nodes/r1-client-shared-transform-utils.md) (12 units)
          - [component-js-build-component](nodes/r1-client-shared-transform-utils.md#u-af8f6b0917f6) · Serializes a component invocation (Component/SvelteComponent/SvelteSelf) into client statements: it collects props, spreads, events, slots, custom CSS properties, and bind:this handling into a props expression, then emits the component call wrapped in optional dynamic-component and async machinery.
      - [Server Transform Phase](nodes/r1-server-transform.md) (9 units)
        - [packages/svelte/src/compiler/phases/3-transform/server/visitors/IfBlock.js:IfBlock](nodes/r1-server-transform.md#u-98ec092cab2d) · Compiles {#if} blocks into a runtime if statement.
    - [Client Runtime](nodes/r1-runtime-client.md) (0 units)
      - [Mount, Hydrate & Unmount](nodes/r1-client-mounting.md) (4 units)
        - [packages/svelte/src/internal/client/render.js:hydrate](nodes/r1-client-mounting.md#u-4a887fa96d35) · Hydrates server-rendered markup by mounting the component in hydration mode, falling back to a full client mount on mismatch.
      - [Hydration Cursor State](nodes/r1-hydration-cursor.md) (3 units)
        - [hydration.js-state-and-guards](nodes/r1-hydration-cursor.md#u-f1b7a30a3c1f) · Tracks the hydration cursor and guards against SSR/client markup mismatch.
      - [DOM Attributes & Properties](nodes/r1-dom-attributes.md) (14 units)
        - [attributes.js-set-attributes](nodes/r1-dom-attributes.md#u-e75ddf9d4835) · Spreads a next attributes object onto an element, mutating next and returning it as the current-state record.
      - [Boundary & Async Blocks](nodes/r1-boundary-blocks.md) (19 units)
        - [boundary.js module code (L1–L46)](nodes/r1-boundary-blocks.md#u-725f5c0efa7a) · Imports plus the BoundaryProps typedef (onerror, failed, pending) and the boundary effect flag combination EFFECT_TRANSPARENT | EFFECT_PRESERVED | BOUNDARY_EFFECT.
      - [Error Handling & Boundaries](nodes/r1-error-propagation.md) (4 units)
        - [handle_error](nodes/r1-error-propagation.md#u-1b3b4fa2c18e) · Central handler for errors raised inside effects.
      - [Reactive Props & Equality](nodes/r1-reactivity-primitives.md) (9 units)
        - [props.js-prop](nodes/r1-reactivity-primitives.md#u-2e500006b90d) · prop synchronizes a possibly bound component prop with local state and returns a getter/setter closure.
      - [Client Dev Diagnostics & HMR](nodes/r1-client-dev-tools.md) (3 units)
        - [assign.js](nodes/r1-client-dev-tools.md#u-2b16b464bcfd) · Dev-mode wrappers around compound property assignment that warn when a synchronously written value reads back stale.
      - [Runtime Mode Flags](nodes/r1-mode-flags.md) (3 units)
        - [index-js-flags](nodes/r1-mode-flags.md#u-10b9373cdfdd) · Module-level mode flags for the Svelte runtime, all exported as mutable let bindings defaulting to false: async_mode_flag, legacy_mode_flag, and tracing_mode_flag.
    - [Server Runtime](nodes/r1-runtime-server.md) (0 units)
      - [SSR Rendering Helpers](nodes/r1-ssr-core.md) (29 units)
        - [render](nodes/r1-ssr-core.md#u-ead9aba750b3) · Server-renders a component into head/body HTML strings.
      - [SSR Dev Validation](nodes/r1-ssr-dev.md) (6 units)
        - [push_element](nodes/r1-ssr-dev.md#u-4eb759f399d2) · Records an element during SSR and validates HTML nesting in DEV.
    - [Shared Utilities](nodes/r1-shared-utilities.md) (0 units)
      - [DOM & Rune Constant Predicates](nodes/r1-dom-dom-utils.md) (36 units)
        - [utils.js module code (L1–L6)](nodes/r1-dom-dom-utils.md#u-7cb3adb5723d) · Shared `regex_return_characters = /\r/g` used by `hash` to strip carriage returns before hashing.
      - [HTML Nesting Validation](nodes/r1-html-tree-validation.md) (3 units)
        - [is_tag_valid_with_parent](nodes/r1-html-tree-validation.md#u-a93dfa56dc6d) · Validates an element against its direct parent, returning an error message or null.
    - [Public Type Declarations](nodes/r1-public-types.md) (18 units)
      - [index.d.ts-svelte-core](nodes/r1-public-types.md#u-e8db83ebe95d) · Declares the public 'svelte' module types and runtime function signatures for components, lifecycle, context, mounting, and flush control.
    - [svelte/events Public API](nodes/r1-events-api.md) (2 units)
      - [index-js-events](nodes/r1-events-api.md#u-f89d44628152) · Pure re-export module: the public svelte/events entry point re-exports on from the internal client DOM events implementation.
  - [Svelte compiler and runtime](nodes/r2-svelte.md) (0 units)
    - [Component compiler pipeline](nodes/r2-compiler.md) (0 units)
      - [Syntax parsing \(template expressions and CSS\)](nodes/r2-compiler-parsing.md) (18 units)
        - [read_expression](nodes/r2-compiler-parsing.md#u-793d43872467) · Parses a JavaScript expression in the template starting at the current index using `parse_expression_at`, then normalizes the parser position.
      - [Analysis validation core](nodes/r2-analyze-shared-validation.md) (14 units)
        - [validate_assignment](nodes/r2-analyze-shared-validation.md#u-83497fe81c11) · Central validity check for assignments, updates, and bind: directives.
      - [Analyze-phase AST visitors](nodes/r2-analyze-visitors.md) (24 units)
        - [arrowfunctionexpression-js](nodes/r2-analyze-visitors.md#u-d117d54d1300) · Thin analyze-phase visitors that delegate shared logic.
      - [Client code generation](nodes/r2-transform-client.md) (22 units)
        - [types.d.ts module code (L1–L2)](nodes/r2-transform-client.md#u-0b4eac9ca055) · Type-only declarations for the lightweight template node tree built by Template: Element (name, attribute record, children, start offset for __svelte_meta), Text (AST.Text nodes), Comment (optional data), and the Node union.
      - [Server \(SSR\) code generation](nodes/r2-transform-server.md) (16 units)
        - [transform-server.js-server-component](nodes/r2-transform-server.md#u-853d938c4671) · Builds the server-side SSR output Program for a component.
      - [Shared transform assignment driver](nodes/r2-transform-shared-assignments.md) (1 units)
        - [visit_assignment_expression](nodes/r2-transform-shared-assignments.md#u-b43a982ab161) · Shared driver for transforming assignment expressions in client or server output.
      - [Compile diagnostics](nodes/r2-compiler-diagnostics.md) (3 units)
        - [errors-js-exported-error-throwers](nodes/r2-compiler-diagnostics.md#u-9c7c186d9bb9) · Roughly 200 exported factory functions, each raising one specific compile-time error by delegating to the internal e() helper.
      - [Compiler option validation](nodes/r2-compiler-options.md) (8 units)
        - [validate-options-js-option-tables](nodes/r2-compiler-options.md#u-057ab7f46350) · Module-level tables defining the valid compiler options and how each is validated/defaulted.
      - [Preprocessing and sourcemap composition](nodes/r2-preprocess-sourcemaps.md) (25 units)
        - [decode_map](nodes/r2-preprocess-sourcemaps.md#u-c6f821c0ed6a) · Normalizes the map field of a Processed result into a decoded sourcemap.
    - [Client runtime](nodes/r2-client-runtime.md) (0 units)
      - [Reactivity core \(signals and deriveds\)](nodes/r2-client-reactivity.md) (15 units)
        - [deriveds.js-async-derived](nodes/r2-client-reactivity.md#u-bf57b47b222b) · Creates a reactive source fed by a promise-returning function, wired into boundary suspension and batching.
      - [DOM primitives: operations and templates](nodes/r2-client-dom-core.md) (14 units)
        - [operations.js-dom-helpers](nodes/r2-client-dom-core.md#u-d9a22fc32463) · Small DOM creation/mutation helpers.
      - [Block rendering: slots, components, head](nodes/r2-client-dom-blocks.md) (5 units)
        - [sanitize_slots](nodes/r2-client-dom-blocks.md#u-16ae26a1cb4b) · Builds a map of available slot names from component props: sets sanitized.default to true when props.children is truthy, and marks every key in props.$$slots as true.
      - [Element integrations: custom elements, actions, bindings](nodes/r2-client-dom-elements.md) (16 units)
        - [custom-element-js-create-custom-element](nodes/r2-client-dom-elements.md#u-cd2e5c090ca7) · Turns a Svelte component into a custom element class by subclassing SvelteElement and wiring prop and export accessors.
      - [Development-mode guards and tracing](nodes/r2-client-dev.md) (4 units)
        - [create_ownership_validator](nodes/r2-client-dev.md#u-cec8691d0119) · Builds a dev validator that flags illegal cross-component mutations and bindings of props.
    - [Server rendering runtime](nodes/r2-server-runtime.md) (11 units)
      - [abort](nodes/r2-server-runtime.md#u-9654b4650543) · Aborts the current server-render abort controller, signalling stale reactions, then clears it.
    - [Shared runtime utilities](nodes/r2-shared-internals.md) (12 units)
      - [clone](nodes/r2-shared-internals.md#u-97cc45d9b173) · Recursive deep-copy used by snapshot.
    - [Public reactive APIs](nodes/r2-public-reactive.md) (0 units)
      - [Store contract implementation](nodes/r2-stores.md) (6 units)
        - [packages/svelte/src/store/shared/index.js:derived](nodes/r2-stores.md#u-d2fec82a964b) · Creates a Readable store whose value is computed from one store or an array of stores via `fn`.
      - [Motion: Tween and legacy tweened](nodes/r2-motion.md) (7 units)
        - [index.js module code (L1–L32)](nodes/r2-motion.md#u-fe5771212e14) · Re-exports the spring and tweened motion APIs and defines prefersReducedMotion, a reactive MediaQuery matching the CSS prefers-reduced-motion: reduce query.
      - [Reactive value wrappers](nodes/r2-reactive-values.md) (5 units)
        - [packages/svelte/src/reactivity/media-query.js:MediaQuery](nodes/r2-reactive-values.md#u-1f6c2b2fc560) · MediaQuery is a ReactiveValue<boolean> reflecting whether a media query matches, updating via a change listener.
      - [Reactive collection test suites](nodes/r2-reactivity-tests.md) (2 units)
        - [map.test.ts-sveltemap-behavior](nodes/r2-reactivity-tests.md#u-f9bdf3b7aa10) · Vitest suite for SvelteMap reactivity.
    - [Type contracts](nodes/r2-type-definitions.md) (0 units)
      - [Element attribute typing system](nodes/r2-element-types.md) (9 units)
        - [elements-d-ts-element-attribute-interfaces](nodes/r2-element-types.md#u-85b3a60ae163) · Family of per-element attribute interfaces, each extending HTMLAttributes (or HTMLMediaAttributes) with the concrete element type and adding only that element's attributes and bindings.
      - [Action and animation type contracts](nodes/r2-action-animate-types.md) (4 units)
        - [action-public-d-ts-action-type-contracts](nodes/r2-action-animate-types.md#u-3016f3d04ee4) · Type declarations for Svelte actions with no runtime behavior.
    - [Reactivity benchmarks](nodes/r2-benchmarking.md) (3 units)
      - [kairo-diamond-js-benchmark-suite](nodes/r2-benchmarking.md#u-b3d162a91824) · Times a diamond dependency graph: width=5 deriveds each read one head signal, a sum derived aggregates them, and one render effect tracks sum.
    - [Repository tooling](nodes/r2-tooling.md) (5 units)
      - [create-app-svelte.js module code (L1–L13)](nodes/r2-tooling.md#u-dde2e710e027) · Seeds src/main.svelte from a template on first run.
    - [Animation runtime \(flip\)](nodes/r2-animate-flip.md) (2 units)
      - [flip](nodes/r2-animate-flip.md#u-2953ae0602e1) · Computes an FLIP animation config translating and scaling an element from its previous bounding box (`from`) to its new one (`to`).
  - [Svelte Repository](nodes/r3-svelte-monorepo.md) (0 units)
    - [Svelte Compiler](nodes/r3-compiler.md) (0 units)
      - [Template Parsing](nodes/r3-compiler-parse.md) (13 units)
        - [index.js-parser](nodes/r3-compiler-parse.md#u-5ceb409db775) · Recursive-descent Svelte template parser exposing cursor movement, token matching, node bookkeeping, and error helpers used by parse state functions.
      - [Semantic Analysis](nodes/r3-compiler-analyze.md) (23 units)
        - [analyze_component](nodes/r3-compiler-analyze.md#u-32c86377621b) · Performs the setup half of component analysis: builds module/instance/template scopes, resolves `$store` subscriptions, decides runes mode, and constructs the ComponentAnalysis object.
      - [Code Transformation](nodes/r3-compiler-transform.md) (0 units)
        - [Shared Transform Utilities](nodes/r3-compiler-transform-utils.md) (7 units)
          - [clean_nodes](nodes/r3-compiler-transform-utils.md#u-2ed26069223c) · Splits template child nodes into hoisted and regular sets and trims whitespace per documented rules, mutating text nodes in place.
        - [Client Transform](nodes/r3-compiler-transform-client.md) (19 units)
          - [AnimateDirective](nodes/r3-compiler-transform-client.md#u-0128ebcf4caf) · Compiles an animate: directive into an $.animation call pushed to after_update, so it runs after bind:this.
        - [Server Transform \(SSR\)](nodes/r3-compiler-transform-server.md) (9 units)
          - [packages/svelte/src/compiler/phases/3-transform/server/visitors/AwaitBlock.js:AwaitBlock](nodes/r3-compiler-transform-server.md#u-8619e1ace336) · Emits a $.await call into the server template for an {#await} block.
      - [Compiler Diagnostics & Warnings](nodes/r3-compiler-diagnostics.md) (11 units)
        - [warnings.js-warning-message-emitters](nodes/r3-compiler-diagnostics.md#u-2a223a23c812) · Generated one-shot emitters for each warning code; each takes a nullable NodeLike node plus per-message string parameters, builds a fixed message ending in a https://svelte.dev/e/<code> documentation link, and forwards to w for suppression, filtering, and recording.
      - [Compiler Shared Utilities & Legacy AST](nodes/r3-compiler-shared-utils.md) (5 units)
        - [push_array](nodes/r3-compiler-shared-utils.md#u-4f8a7deedb7c) · Pushes every item of `items` onto `array` in a plain loop, mutating `array`.
      - [Template AST Types](nodes/r3-compiler-ast-types.md) (5 units)
        - [template.d.ts-root-and-fragment](nodes/r3-compiler-ast-types.md#u-e8223dc323d4) · Top-level `AST` namespace foundations.
    - [Client Runtime Internals](nodes/r3-runtime.md) (2 units)
      - [index-js-internal](nodes/r3-runtime.md#u-84fe56d94225) · Guard module that unconditionally throws an Error at import time.
      - [Signal Sources](nodes/r3-runtime-reactivity-sources.md) (12 units)
        - [source](nodes/r3-runtime-reactivity-sources.md#u-97497b70f31b) · Allocates a plain Value signal object for v with zero flags, reference equality, and null reactions; it does not register the signal anywhere.
      - [Effect Batching & Scheduling](nodes/r3-runtime-reactivity-batching.md) (8 units)
        - [batch.js-batch-class](nodes/r3-runtime-reactivity-batching.md#u-6d22ee98690b) · A Batch collects source writes and their previous values, traverses the effect tree, and flushes effects in coordinated phases so multiple concurrent async updates cannot interleave.
      - [Deep Reactivity Proxies](nodes/r3-runtime-proxy.md) (5 units)
        - [proxy](nodes/r3-runtime-proxy.md#u-6e64c72c9fe9) · Wraps a state object or array in a reactive Proxy.
      - [Dev-Mode Diagnostics](nodes/r3-runtime-dev-tools.md) (10 units)
        - [tracing.js-tagging](nodes/r3-runtime-dev-tools.md#u-76249388f24e) · Helpers for labeling reactive values in traces.
      - [DOM Blocks](nodes/r3-runtime-dom-blocks.md) (9 units)
        - [if_block](nodes/r3-runtime-dom-blocks.md#u-5467723df322) · Implements an {#if}/{:else if} block that swaps consequent/alternate branch effects as the chosen branch changes.
      - [DOM Elements, Bindings & Transitions](nodes/r3-runtime-dom-elements.md) (18 units)
        - [listen](nodes/r3-runtime-dom-elements.md#u-8f0d8dd6601b) · Registers a handler on an EventTarget for each listed event and removes all listeners when the enclosing effect is torn down.
      - [Legacy Reactivity Mode](nodes/r3-runtime-legacy-mode.md) (2 units)
        - [capture_signals](nodes/r3-runtime-legacy-mode.md#u-901893964aa4) · Captures every signal read during `fn` by running it untrack-ed with the module-level captured_signals set temporarily replaced by a fresh Set; signal reads elsewhere presumably register into this set.
    - [Public Runtime Feature APIs](nodes/r3-public-api.md) (0 units)
      - [Spring Motion](nodes/r3-public-motion.md) (8 units)
        - [packages/svelte/src/motion/spring.js:Spring](nodes/r3-public-motion.md#u-6e9a0bc3364a) · Reactive spring class whose target and current values are state signals; setting target (or calling set) animates current toward target using stiffness, damping and precision.
      - [Transition Configs](nodes/r3-public-transitions.md) (8 units)
        - [blur](nodes/r3-public-transitions.md#u-bc2c7a4069fc) · Returns a TransitionConfig animating a blur filter and opacity.
      - [Reactive Window Values](nodes/r3-public-reactive-window.md) (2 units)
        - [index-js-reactive-window-values](nodes/r3-public-reactive-window.md#u-19fa89d5393e) · Module-level reactive views of window/browser state, each a `ReactiveValue` whose `current` is reactive in a browser and `undefined` on the server (`BROWSER` selects the read function).
    - [Ambient & Language-Server Types](nodes/r3-types.md) (30 units)
      - [Comp](nodes/r3-types.md#u-4202fbdda361) · Ambient module declaration for `*.svelte` imports, typing every Svelte file's default export.
    - [Repository Tooling](nodes/r3-tooling.md) (0 units)
      - [Code & Docs Generation](nodes/r3-tooling-codegen.md) (5 units)
        - [generate-types.js module code (L1–L85)](nodes/r3-tooling-codegen.md#u-a7ff57214266) · Generates the package's TypeScript declaration output and enforces two style checks.
      - [Reactivity Benchmarks & Test Config](nodes/r3-tooling-benchmarks.md) (5 units)
        - [busy](nodes/r3-tooling-benchmarks.md#u-0d12a4a1de84) · Deliberately burns a small amount of CPU by incrementing a local counter 100 times, returning nothing; used inside deriveds and render effects to amplify the measured cost of recomputation so reactivity overhead is distinguishable from noise.
  - [Svelte Monorepo](nodes/r4-svelte-monorepo.md) (0 units)
    - [Compiler Pipeline](nodes/r4-compiler-pipeline.md) (0 units)
      - [Parsing](nodes/r4-parse-phase.md) (9 units)
        - [text](nodes/r4-parse-phase.md#u-36401d8c3a23) · Consumes template characters until the next `<` or `{` (or end of template) and appends a single Text node spanning that range, with raw set to the consumed text and data produced by decoding character references in text context (second argument false, versus true in attribute contexts).
      - [Analysis](nodes/r4-analyze-phase.md) (0 units)
        - [CSS Analysis](nodes/r4-css-analysis.md) (12 units)
          - [analyze_css](nodes/r4-css-analysis.md#u-f762711e5ae7) · Entry point that analyzes a component's stylesheet.
        - [JS & Template Analysis](nodes/r4-js-template-analysis.md) (10 units)
          - [CallExpression](nodes/r4-js-template-analysis.md#u-d254c72e4204) · Analyzes a call expression: resolves the callee as a rune and validates each rune's placement and arity.
      - [Transformation](nodes/r4-transform-phase.md) (0 units)
        - [Transform Entry](nodes/r4-transform-entry.md) (2 units)
          - [transform_component](nodes/r4-transform-entry.md#u-be9df8c13257) · Turns a validated component analysis into printed JS and CSS output for a compile result.
        - [Client Transform](nodes/r4-client-transform.md) (23 units)
          - [transform-client.js-visitors-and-entry](nodes/r4-client-transform.md#u-61e7277a11cb) · Registers the client-side visitor map and drives component and module code generation for the client transform phase.
        - [Server Transform](nodes/r4-server-transform.md) (11 units)
          - [packages/svelte/src/compiler/phases/3-transform/server/visitors/ConstTag.js:ConstTag](nodes/r4-server-transform.md#u-4790e3338b92) · Transforms {@const} tags into a const declaration appended to the component init statements: the visited declaration id and init become b.const(id, init) pushed to context.state.init.
      - [Compiler Semantic Model](nodes/r4-compiler-model.md) (18 units)
        - [Binding](nodes/r4-compiler-model.md#u-0c91df12a429) · Represents one declared identifier: the declaring scope, identifier node, binding kind, declaration kind, initializer, and every reference found to it.
      - [Compiler Utilities](nodes/r4-compiler-utils.md) (9 units)
        - [equal](nodes/r4-compiler-utils.md#u-2a153dd9dab6) · Throws an Error when two values are not strictly equal, serving as a compile-time assertion.
      - [Compiler Legacy Types](nodes/r4-compiler-legacy-types.md) (2 units)
        - [legacy-interfaces.d.ts-deprecated-aliases](nodes/r4-compiler-legacy-types.md#u-9be87a51ccd3) · Backward-compatibility re-export aliases.
    - [Diagnostic Message Codegen](nodes/r4-diagnostics-messages.md) (5 units)
      - [compile-warnings.js-internal-compile-warning](nodes/r4-diagnostics-messages.md#u-e2ab458c038c) · Warning class extending CompileDiagnostic so warnings share the diagnostic object shape.
    - [Client Runtime](nodes/r4-client-runtime.md) (0 units)
      - [Component Context](nodes/r4-component-context.md) (13 units)
        - [packages/svelte/src/internal/client/context.js:add_svelte_meta](nodes/r4-component-context.md#u-19355b3b3598) · Runs a callback with a temporary dev-stack entry describing a block or component location.
      - [Client Dev Tooling](nodes/r4-dev-tooling-client.md) (6 units)
        - [css.js](nodes/r4-dev-tooling-client.md#u-0546b8eb9687) · Tracks component style elements by hash so they can be removed later.
      - [DOM Rendering](nodes/r4-dom-rendering.md) (0 units)
        - [DOM Blocks](nodes/r4-dom-blocks.md) (7 units)
          - [packages/svelte/src/internal/client/dom/blocks/await.js:update](nodes/r4-dom-blocks.md#u-05916687a6e9) · Swaps the visible snippet to the given AwaitState and hides the other two, always setting resolved=true.
        - [DOM Elements & Events](nodes/r4-dom-elements.md) (20 units)
          - [events-js-create-event](nodes/r4-dom-elements.md#u-86f4f61fbc7c) · Creates and registers a DOM event listener that integrates with Svelte's event-delegation machinery, returning the handler so it can later be removed.
        - [Task Scheduling](nodes/r4-task-scheduling.md) (1 units)
          - [task.js-queues](nodes/r4-task-scheduling.md#u-2af0814cc5ec) · Batched micro-task and idle-task scheduling.
      - [Client Reactivity](nodes/r4-client-reactivity.md) (18 units)
        - [async_body](nodes/r4-client-reactivity.md#u-7844e4272e2c) · Runs the body of an async block within the suspension protocol: suspends the current batch, awaits `fn`, and always unsuspends in `finally`.
      - [Legacy Client Helpers](nodes/r4-legacy-client-helpers.md) (1 units)
        - [misc-js-legacy-helpers](nodes/r4-legacy-client-helpers.md#u-dd881b459f6c) · Legacy compatibility helpers.
    - [Server Runtime](nodes/r4-server-runtime.md) (7 units)
      - [packages/svelte/src/index-server.js:onDestroy](nodes/r4-server-runtime.md#u-3d10206fb345) · Server-side onDestroy: registers `fn` on the current server component's destroy list.
    - [Shared Runtime Utilities](nodes/r4-shared-runtime.md) (10 units)
      - [packages/svelte/src/internal/shared/attributes.js:append_styles](nodes/r4-shared-runtime.md#u-83334ed78d84) · Renders a style dictionary into CSS declaration text.
    - [Public Component Types \(Modern\)](nodes/r4-public-component-types.md) (16 units)
      - [packages/svelte/src/index.d.ts:Component](nodes/r4-public-component-types.md#u-e62b7cb5d771) · The Svelte 5 component type: a callable `(internals: ComponentInternals, props: Props) => Exports & {...}`.
    - [Public Component Types \(Legacy\)](nodes/r4-legacy-component-types.md) (15 units)
      - [packages/svelte/src/index.d.ts:SvelteComponent](nodes/r4-legacy-component-types.md#u-4400c2aaf924) · Deprecated Svelte 4 base class for components, retained for typing under the `asClassComponent` compatibility helper; Svelte 5 components are functions and `mount` should instantiate instead.
    - [Reactive Primitives & Motion](nodes/r4-reactive-primitives.md) (11 units)
      - [map.js-sveltemap](nodes/r4-reactive-primitives.md#u-1e768777e1a1) · SvelteMap is a reactive Map subclass: reading size, get, has, forEach, values, entries, or iterating in an effect re-runs that effect when the map changes; values are not made deeply reactive.
    - [Repository Tooling](nodes/r4-repo-tooling.md) (0 units)
      - [Benchmark Harness](nodes/r4-benchmark-harness.md) (11 units)
        - [run.js module code (L1–L55)](nodes/r4-benchmark-harness.md#u-8a0ea15faff6) · Top-level benchmark driver that runs all registered suites sequentially and reports total timing.
      - [Playground Sandbox](nodes/r4-playground-sandbox.md) (9 units)
        - [mkdirp](nodes/r4-playground-sandbox.md#u-7792f9b7775b) · Creates a directory tree, silently ignoring any error from recursive mkdir.
  - [Svelte](nodes/r5-svelte.md) (0 units)
    - [Benchmark Suites](nodes/r5-benchmark-suites.md) (5 units)
      - [kairo-broad-js-benchmark-suite](nodes/r5-benchmark-suites.md#u-5d73821703da) · Creates 50 parallel derived pairs off one head signal and a counter-ticking render effect per pair, measuring fan-out update cost.
    - [SSR Playground Sandbox](nodes/r5-playground-sandbox.md) (3 units)
      - [ssr-common.js module code (L1–L17)](nodes/r5-playground-sandbox.md#u-c9a44632b392) · Installs shared helpers used by both SSR servers.
    - [Shared Runtime Libraries](nodes/r5-shared-lib.md) (3 units)
      - [escape_html](nodes/r5-shared-lib.md#u-0f499dd45547) · Escapes HTML-unsafe characters in a value for safe interpolation into markup.
    - [Compiler](nodes/r5-compiler.md) (0 units)
      - [Compiler Entry API](nodes/r5-compiler-entry.md) (6 units)
        - [compile](nodes/r5-compiler-entry.md#u-a54e3b374c84) · Compiles a Svelte component source string into a JavaScript module implementing the compiler's parse→analyze→transform pipeline.
      - [Compiler Type Definitions](nodes/r5-compiler-types.md) (6 units)
        - [compiler-phases-types-d-ts-analysis-interfaces](nodes/r5-compiler-types.md#u-8baf83940c2e) · Type-only declarations describing compiler phase state; no runtime behavior.
      - [Compiler State and Errors](nodes/r5-compiler-state-errors.md) (9 units)
        - [adjust](nodes/r5-compiler-state-errors.md#u-0298dbcfed58) · Refines compiler state after parsing and basic analysis.
      - [Shared AST Utilities](nodes/r5-compiler-ast-utils.md) (17 units)
        - [build_assignment_value](nodes/r5-compiler-ast-utils.md#u-634ffef5ceee) · Converts a compound assignment into its equivalent right-hand value.
      - [Parse Phase](nodes/r5-parse.md) (0 units)
        - [Template Element Parsing](nodes/r5-template-parsing.md) (8 units)
          - [element](nodes/r5-template-parsing.md#u-bc08cb4e57fa) · Parses an opening or closing tag in the Svelte template parser, dispatching comments, meta tags, components, and elements into the parse tree.
        - [Script and Expression Reading](nodes/r5-script-parsing.md) (7 units)
          - [acorn.js-comment-handlers](nodes/r5-script-parsing.md#u-25b8c96fd2a2) · Provides the onComment/add_comments pair that makes Acorn record comments it would otherwise drop, so svelte-ignore comments and prettier round-trips work.
        - [Fuzzy Match Diagnostics](nodes/r5-parse-diagnostics.md) (6 units)
          - [FuzzySet](nodes/r5-parse-diagnostics.md#u-1a1551cf741f) · Approximate-string-match set in the style of fuzzyset.js: indexes candidate strings by 2- and 3-grams so lookups return ranked [score, originalString] tuples.
      - [Analyze Phase](nodes/r5-analyze.md) (0 units)
        - [Analyze Visitors](nodes/r5-analyze-visitors.md) (21 units)
          - [attachtag-classdirective-spreadattribute-js](nodes/r5-analyze-visitors.md#u-53d5dba31656) · Directive/attribute visitors that mark their subtree dynamic and propagate expression metadata.
        - [CSS Analysis Utilities](nodes/r5-css-analyze-utils.md) (6 units)
          - [gather_possible_values](nodes/r5-css-analyze-utils.md#u-b80afad44d7a) · Collects the set of stringifiable values a class/style expression chunk could take, using a sentinel UNKNOWN object that short-circuits further traversal once present.
      - [Transform Phase](nodes/r5-transform.md) (0 units)
        - [Client Transform](nodes/r5-client-transform.md) (0 units)
          - [Client Transform Visitors](nodes/r5-client-transform-visitors.md) (16 units)
            - [assignmentexpression-js](nodes/r5-client-transform-visitors.md#u-b46464f68b1c) · AssignmentExpression.js transforms compiled assignment expressions for the client output.
          - [Template Emission](nodes/r5-client-template-transform.md) (3 units)
            - [fix_attribute_casing](nodes/r5-client-template-transform.md#u-799dccdfecc2) · Maps a lowercase SVG attribute name to its canonical mixed-case form, or returns the name unchanged.
          - [Client Transform State Types](nodes/r5-client-transform-types.md) (2 units)
            - [ClientTransformState](nodes/r5-client-transform-types.md#u-e21a2406661b) · Type-only declaration extending TransformState with client-specific flags: `in_constructor` (rewrite this.foo to private field reads), `in_derived` (directly inside $derived(...)), `is_instance` (transforming instance script content), and a per-name `transform` record whose optional hooks rewrite reads ($.get style), assignments ($.set), member mutations ($.mutate), and update expressions ($.update).
        - [CSS Transform](nodes/r5-css-transform.md) (13 units)
          - [render_stylesheet](nodes/r5-css-transform.md#u-197b2d45aa0c) · Renders analyzed component CSS into final code, a source map, and a hasGlobal flag.
        - [Server Transform](nodes/r5-server-transform.md) (6 units)
          - [packages/svelte/src/compiler/phases/3-transform/server/visitors/SvelteFragment.js:SvelteFragment](nodes/r5-server-transform.md#u-356cef502838) · Handles <svelte:fragment> in SSR output by visiting the node's fragment and pushing the resulting BlockStatement onto state.template, emitting it as a nested block of template statements.
    - [Client Runtime](nodes/r5-client-runtime.md) (0 units)
      - [Signal Core](nodes/r5-signal-core.md) (18 units)
        - [packages/svelte/src/internal/client/runtime.js:get](nodes/r5-signal-core.md#u-98099fbbf12a) · Reads a signal's value while registering it as a dependency of the active reaction, and recomputes dirty deriveds.
      - [Internal Shared Utilities](nodes/r5-internal-shared-utils.md) (7 units)
        - [deferred](nodes/r5-internal-shared-utils.md#u-3c5ab59ed010) · Creates an externally resolvable promise: returns { promise, resolve, reject } where resolve/reject control the returned promise.
      - [Effect Lifecycle](nodes/r5-effects-module.md) (17 units)
        - [create_effect](nodes/r5-effects-module.md#u-b219b5c574b1) · Core effect factory: builds the Effect object linked to the active effect as parent, inheriting component context and boundary `b`.
      - [Each Block](nodes/r5-each-block.md) (19 units)
        - [each](nodes/r5-each-block.md#u-a4e1b3df9530) · Sets up a keyed each block: controlled-block anchoring, the derived collection, and the commit wrapper that delegates to reconcile and manages the fallback.
      - [Input Bindings](nodes/r5-input-bindings.md) (7 units)
        - [bind_checked](nodes/r5-input-bindings.md#u-d6e0e6bda8ca) · Two-way binds an input's checked state.
      - [Reactive Wrappers and Stores](nodes/r5-reactivity-wrappers.md) (8 units)
        - [SvelteDate](nodes/r5-reactivity-wrappers.md#u-cb648e924acc) · A reactive subclass of the built-in Date whose reads from effects/deriveds re-run when the date changes.
      - [Legacy Component Reactivity](nodes/r5-legacy-internal.md) (2 units)
        - [packages/svelte/src/internal/client/dom/legacy/lifecycle.js:init](nodes/r5-legacy-internal.md#u-d1fb3ea6618e) · Legacy-mode initialization: resolves the current `component_context` (cast to the legacy context type) and returns early if its `l.u` callbacks bag is absent; otherwise wires `beforeUpdate`, `onMount`, and `afterUpdate` behavior.
    - [Public Component API](nodes/r5-public-api.md) (0 units)
      - [Lifecycle and Events](nodes/r5-component-lifecycle.md) (9 units)
        - [onMount](nodes/r5-component-lifecycle.md#u-3c1ac43e0c43) · Schedules a function to run once after the component mounts.
      - [Attachments API](nodes/r5-attachments-api.md) (3 units)
        - [createAttachmentKey](nodes/r5-attachments-api.md#u-c36056169480) · Returns a `Symbol(ATTACHMENT_KEY)` that, used as an object key holding an attachment function spread onto an element, is recognized as an attachment — a programmatic alternative to `{@attach ...}` aimed at library authors.
      - [Svelte 4 Compatibility Adapters](nodes/r5-legacy-adapters.md) (6 units)
        - [Svelte4Component](nodes/r5-legacy-adapters.md#u-f604417484a2) · Svelte 4–compatible component wrapper around a Svelte 5 component, supporting class instantiation, `$set`, `$on`, `$destroy`, and instance exports.
    - [Server Rendering](nodes/r5-server-render.md) (2 units)
      - [index-js-server](nodes/r5-server-render.md#u-c0e8025865b5) · Public server entry point that re-exports render from the internal server implementation.
  - [Compiler Pipeline](nodes/compiler-pipeline.md) (0 units)
    - [Diagnostic Message Codegen](nodes/diagnostics-codegen.md) (0 units)
  - [Client Runtime](nodes/client-runtime.md) (0 units)
  - [Server Runtime](nodes/server-runtime.md) (0 units)
  - [Shared Runtime Utilities](nodes/shared-runtime.md) (0 units)
  - [Public Reactive APIs & Features](nodes/public-reactive-apis.md) (0 units)
  - [Public Type Declarations](nodes/public-types.md) (0 units)
  - [Reactivity & SSR Benchmarking](nodes/benchmarking.md) (0 units)
  - [Build & Repo Tooling](nodes/repo-tooling.md) (0 units)

## Reading stats

- units: 1206 · semantic nodes: 169 · dispositioned inventory ids: 4988
- source ranges are program-derived from the inventory, never model-written

## Graph coverage

Source: static analysis graph. Resolved relations are graph-confirmed; this does not guarantee semantic correctness. External targets are outside the repository; ambiguous targets have multiple candidates. Unresolved or unsupported relations, and languages or relation kinds without coverage, rely on model inference and may be inaccurate.
Import and call status ratios use the edge count of each kind. CFG and dataflow are structural edges; only their counts are shown, without status ratios.
javascript import: resolved 1256/2267 (55%), unresolved 674/2267 (30%), external 337/2267 (15%) · javascript call: resolved 3192/15643 (20%), ambiguous 1078/15643 (7%), unresolved 4739/15643 (30%), external 6634/15643 (42%).
javascript structural edges: cfg=245262, dataflow=50000.
typescript import: resolved 33/41 (80%), unresolved 8/41 (20%) · typescript call: no edges.
typescript structural edges: cfg=0, dataflow=0.
Incomplete capabilities: javascript/call partial; javascript/dataflow partial; typescript/call partial; typescript/dataflow partial.
Program checks: dangling edges 0; nodes outside manifest 0; nodes with missing files 0.

## Overview

This repository implements the Svelte framework end to end: a multi-phase compiler (parse → analyze → transform) that turns .svelte sources into client or server JavaScript, the client runtime of signals/effects/DOM primitives that compiled output calls into, the server runtime behind svelte/server, shared platform-neutral utilities, the public reactive APIs and type declarations, and non-shipping tooling (benchmarks, playground, codegen, audits). For any maintenance question, first pick the layer: compiler behavior lives under compiler-pipeline, browser behavior under client-runtime, SSR under server-runtime, exported APIs under public-reactive-apis, and contracts under public-types. Cross-cutting knowledge (element/attribute tables, HTML nesting rules, escaping) is centralized in shared-runtime, so check it before duplicating a constant. Diagnostics are generated: diagnostics-codegen templates feed the compiler's warnings and runtime error throwers. The compiler and runtimes meet at the emitted $.-calls: transform visitors produce them and the runtime subtrees implement them. Benchmarking and repo-tooling consume the shipped internals from outside and never ship.

## Maintenance navigation

Navigation by maintenance question:

- 'Why does this compile error/warning fire?' The error factories live in packages/svelte/src/compiler/errors.js (function::e) and warnings in warnings.js (function::w); both are generated from diagnostics-codegen templates — regenerate there, not by hand.
- 'How does source become output?' Follow parse → analyze → transform: r3-compiler-parse → r3-compiler-analyze → r3-compiler-transform (equivalently r4-parse-phase / r4-analyze-phase / r4-transform-phase, or r5-parse / r5-analyze / r5-transform). For client element codegen, start at RegularElement (packages/svelte/src/compiler/phases/3-transform/client/visitors/RegularElement.js) which routes through shared/element.js build_attribute_value and the expression builders. For SSR output start at r3-compiler-transform-server or r5-server-transform.
- 'What does an emitted $.-call do?' Open client-runtime children: r3-runtime-reactivity-sources for state writes, r3-runtime-reactivity-batching for scheduling, r3-runtime-proxy for deep $state, r1-dom-attributes for attributes, r1-boundary-blocks with r1-error-propagation for error/pending semantics, r5-signal-core and r5-effects-module for the alternative signal/effect decomposition. Hydration: r1-hydration-cursor plus r1-client-mounting.
- 'SSR markup wrong or dev warnings' — r1-ssr-core for emitted helpers, r1-ssr-dev for nesting validation, which consumes r1-html-tree-validation rules from shared-runtime.
- 'Changing element/attribute/event knowledge' — shared-runtime (r1-dom-dom-utils) is the single source; r1-server-transform, r1-ssr-core and the runtimes consume its predicates; do not fork the tables.
- 'Public API or types' — public-types (r2-element-types for SvelteHTMLElements, r2-action-animate-types) and public-reactive-apis (r2-stores, r2-motion, r2-animate-flip, r3-public-transitions, r3-public-reactive-window). Tweened is built on writable; transition factories produce configs consumed by the runtime transition managers.
- 'Compiler options invalid/deprecated/removed' — r2-compiler-options: the option tables are data; validate-options.js validator/removed/warn_once functions are the mechanics.
- 'Reactivity performance regression' — benchmarking (r3-tooling-benchmarks, r2-benchmarking) drives the batching/sources layers from outside; change the runtime, then rerun suites.
- 'Regenerating declarations, version, message modules' — repo-tooling (r3-tooling-codegen). Tree-shaking or lint failures: r1-treeshakeability-audit and r1-lint-config.
- Legacy/migration: r1-migrator rewrites Svelte 4 components; legacy runtime support in r3-runtime-legacy-mode and r5-legacy-adapters; deprecated typings isolated in public-types.
Uncertainty: where summaries flag it (stores' independence from the signal core, sandbox-to-render wiring, r2-client-dev diagnostics linkage), treat relationships as inferred and verify in source.

## Dependency view

Arrows point from a user to its dependency. Containment is structural, not a dependency. Graph-confirmed pairs appear in both the tree and resolved call/import edges. Model-inferred pairs appear only in the tree. Graph-only pairs appear only in the graph.
Graph-confirmed and model-inferred pairs count edges between two subtrees. Graph-only pairs count edges between direct node owners. Containment rows show resolved edges between ancestor direct units and a descendant subtree in both directions. Within containment rows count direct owner pairs separately. Neither kind of containment row appears in Mermaid or the three dependency totals.

```mermaid
flowchart LR
  n0["Signal Sources"]
  n1["Compiler Semantic Model"]
  n2["Effect Lifecycle"]
  n3["Signal Core"]
  n4["DOM #38; Rune Constant Predicates"]
  n5["Shared AST Utilities"]
  n6["Server Runtime"]
  n7["Shared Runtime Utilities"]
  n8["Client Runtime"]
  n9["Compile diagnostics"]
  n10["Compiler Pipeline"]
  n11["Semantic Analysis"]
  n12["Dev-Mode Diagnostics"]
  n13["Effect Batching #38; Scheduling"]
  n14["Client Transform"]
  n8 -.-> n10
  n8 -.-> n6
  n8 -.-> n7
  n10 -.-> n7
  n13 -.-> n0
  n0 --> n12
  n0 --> n13
  n14 --> n1
  n2 --> n3
  n6 -.-> n8
  n6 -.-> n10
  n6 -.-> n7
  n7 -.-> n8
  n7 -.-> n10
  n7 -.-> n6
  n11 ==> n1
  n13 ==> n3
  n0 ==> n3
  n1 ==> n5
  n14 ==> n5
```

Selected 15 nodes by connection count. Legend: `-->` graph-confirmed; `-.->` model-inferred; `==>` graph-only.

## Dependency list

- [Reactivity & SSR Benchmarking](nodes/benchmarking.md) → [Client Runtime](nodes/client-runtime.md) · model-inferred · 0 edge(s) · Benchmark suites drive the client reactivity internals directly to time signal graph shapes.
- [Reactivity & SSR Benchmarking](nodes/benchmarking.md) → [Build & Repo Tooling](nodes/repo-tooling.md) · model-inferred · 0 edge(s)
- [Reactivity & SSR Benchmarking](nodes/benchmarking.md) → [Server Runtime](nodes/server-runtime.md) · model-inferred · 0 edge(s)
- [Client Runtime](nodes/client-runtime.md) → [Compiler Pipeline](nodes/compiler-pipeline.md) · model-inferred · 0 edge(s) · The client runtime executes the runtime calls that the compiler's client transform emits.
- [Client Runtime](nodes/client-runtime.md) → [Server Runtime](nodes/server-runtime.md) · model-inferred · 0 edge(s) · Hydration in the client runtime aligns with the markers and markup produced by server rendering.
- [Client Runtime](nodes/client-runtime.md) → [Shared Runtime Utilities](nodes/shared-runtime.md) · model-inferred · 0 edge(s) · The client runtime's DOM and dev layers consume shared element/attribute predicates instead of duplicating element tables.
- [Compiler Pipeline](nodes/compiler-pipeline.md) → [Diagnostic Message Codegen](nodes/diagnostics-codegen.md) · containment · → 0 / ← 0 edge(s) (ancestor direct units and descendant subtree; → follows ` compiler-pipeline ` → ` diagnostics-codegen `) · Compile warnings and thrown errors are generated from the diagnostics-codegen message templates.
- [Compiler Pipeline](nodes/compiler-pipeline.md) → [Shared Runtime Utilities](nodes/shared-runtime.md) · model-inferred · 0 edge(s) · Parse, analyze and transform phases use shared constants and predicates such as void/boolean element tables from shared-runtime.
- [Diagnostic Message Codegen](nodes/diagnostics-codegen.md) → [Shared Runtime Utilities](nodes/shared-runtime.md) · model-inferred · 0 edge(s)
- [Public Reactive APIs & Features](nodes/public-reactive-apis.md) → [Client Runtime](nodes/client-runtime.md) · model-inferred · 0 edge(s) · Public reactive features like springs and reactive window values are built on the client runtime's source and tracing internals.
- [Public Reactive APIs & Features](nodes/public-reactive-apis.md) → [Server Runtime](nodes/server-runtime.md) · model-inferred · 0 edge(s)
- [Public Reactive APIs & Features](nodes/public-reactive-apis.md) → [Shared Runtime Utilities](nodes/shared-runtime.md) · model-inferred · 0 edge(s)
- [Public Type Declarations](nodes/public-types.md) → [Compiler Pipeline](nodes/compiler-pipeline.md) · model-inferred · 0 edge(s)
- [Public Type Declarations](nodes/public-types.md) → [Public Reactive APIs & Features](nodes/public-reactive-apis.md) · model-inferred · 0 edge(s) · Action and animation type declarations describe contracts whose runtime implementations live in the public reactive APIs.
- [Accessibility Analysis](nodes/r1-a11y-analysis.md) → [DOM & Rune Constant Predicates](nodes/r1-dom-dom-utils.md) · graph-confirmed · 1 edge(s)
- [Boundary & Async Blocks](nodes/r1-boundary-blocks.md) → [Error Handling & Boundaries](nodes/r1-error-propagation.md) · graph-confirmed · 3 edge(s) · Boundaries register with the error-handling machinery so effect errors are routed to the nearest boundary.
- [Boundary & Async Blocks](nodes/r1-boundary-blocks.md) → [Hydration Cursor State](nodes/r1-hydration-cursor.md) · graph-confirmed · 5 edge(s)
- [Client Block & Element Visitors](nodes/r1-client-block-visitors.md) → [Shared Client Transform Builders](nodes/r1-client-shared-transform-utils.md) · graph-confirmed · 6 edge(s)
- [Client Dev Diagnostics & HMR](nodes/r1-client-dev-tools.md) → [Client Block & Element Visitors](nodes/r1-client-block-visitors.md) · graph-confirmed · 1 edge(s)
- [Client Dev Diagnostics & HMR](nodes/r1-client-dev-tools.md) → [DOM & Rune Constant Predicates](nodes/r1-dom-dom-utils.md) · graph-confirmed · 1 edge(s)
- [Mount, Hydrate & Unmount](nodes/r1-client-mounting.md) → [DOM & Rune Constant Predicates](nodes/r1-dom-dom-utils.md) · graph-confirmed · 1 edge(s)
- [Mount, Hydrate & Unmount](nodes/r1-client-mounting.md) → [Hydration Cursor State](nodes/r1-hydration-cursor.md) · graph-confirmed · 7 edge(s) · hydrate() uses the hydration cursor state and guards to walk server markup during mounting.
- [Shared Client Transform Builders](nodes/r1-client-shared-transform-utils.md) → [Template Serialization](nodes/r1-client-template.md) · graph-confirmed · 5 edge(s)
- [Shared Client Transform Builders](nodes/r1-client-shared-transform-utils.md) → [DOM & Rune Constant Predicates](nodes/r1-dom-dom-utils.md) · graph-confirmed · 1 edge(s)
- [Template Serialization](nodes/r1-client-template.md) → [DOM & Rune Constant Predicates](nodes/r1-dom-dom-utils.md) · graph-confirmed · 1 edge(s)
- [DOM Attributes & Properties](nodes/r1-dom-attributes.md) → [DOM & Rune Constant Predicates](nodes/r1-dom-dom-utils.md) · graph-confirmed · 3 edge(s)
- [DOM Attributes & Properties](nodes/r1-dom-attributes.md) → [Hydration Cursor State](nodes/r1-hydration-cursor.md) · graph-confirmed · 4 edge(s) · Attribute setters consult hydration state to avoid clobbering values during hydration.
- [Svelte 4 Automigrator](nodes/r1-migrator.md) → [Client Block & Element Visitors](nodes/r1-client-block-visitors.md) · graph-confirmed · 6 edge(s)
- [Svelte 4 Automigrator](nodes/r1-migrator.md) → [DOM & Rune Constant Predicates](nodes/r1-dom-dom-utils.md) · graph-confirmed · 3 edge(s)
- [Server Transform Phase](nodes/r1-server-transform.md) → [DOM & Rune Constant Predicates](nodes/r1-dom-dom-utils.md) · graph-confirmed · 7 edge(s) · SSR element builders use shared predicates like boolean-attribute and void-element checks when serializing markup.
- [SSR Rendering Helpers](nodes/r1-ssr-core.md) → [DOM & Rune Constant Predicates](nodes/r1-dom-dom-utils.md) · graph-confirmed · 3 edge(s)
- [SSR Rendering Helpers](nodes/r1-ssr-core.md) → [SSR Dev Validation](nodes/r1-ssr-dev.md) · graph-confirmed · 1 edge(s)
- [SSR Dev Validation](nodes/r1-ssr-dev.md) → [HTML Nesting Validation](nodes/r1-html-tree-validation.md) · graph-confirmed · 2 edge(s)
- [Treeshakeability Audit](nodes/r1-treeshakeability-audit.md) → [Client Block & Element Visitors](nodes/r1-client-block-visitors.md) · graph-confirmed · 1 edge(s)
- [Analyze-phase AST visitors](nodes/r2-analyze-visitors.md) → [Analysis validation core](nodes/r2-analyze-shared-validation.md) · graph-confirmed · 6 edge(s) · Analysis visitors delegate semantic rules like assignment legality and tag validation to the shared validation core.
- [Analyze-phase AST visitors](nodes/r2-analyze-visitors.md) → [Compile diagnostics](nodes/r2-compiler-diagnostics.md) · model-inferred · 0 edge(s)
- [Animation runtime \(flip\)](nodes/r2-animate-flip.md) → [Type contracts](nodes/r2-type-definitions.md) · model-inferred · 0 edge(s)
- [Reactivity benchmarks](nodes/r2-benchmarking.md) → [Reactivity core \(signals and deriveds\)](nodes/r2-client-reactivity.md) · model-inferred · 0 edge(s)
- [Development-mode guards and tracing](nodes/r2-client-dev.md) → [Compile diagnostics](nodes/r2-compiler-diagnostics.md) · model-inferred · 0 edge(s)
- [Block rendering: slots, components, head](nodes/r2-client-dom-blocks.md) → [DOM primitives: operations and templates](nodes/r2-client-dom-core.md) · graph-confirmed · 6 edge(s)
- [Element integrations: custom elements, actions, bindings](nodes/r2-client-dom-elements.md) → [DOM primitives: operations and templates](nodes/r2-client-dom-core.md) · graph-confirmed · 1 edge(s)
- [Reactivity core \(signals and deriveds\)](nodes/r2-client-reactivity.md) → [Compile diagnostics](nodes/r2-compiler-diagnostics.md) · model-inferred · 0 edge(s)
- [Compiler option validation](nodes/r2-compiler-options.md) → [Compile diagnostics](nodes/r2-compiler-diagnostics.md) · model-inferred · 0 edge(s)
- [Syntax parsing \(template expressions and CSS\)](nodes/r2-compiler-parsing.md) → [Compile diagnostics](nodes/r2-compiler-diagnostics.md) · model-inferred · 0 edge(s)
- [Motion: Tween and legacy tweened](nodes/r2-motion.md) → [Store contract implementation](nodes/r2-stores.md) · graph-confirmed · 1 edge(s) · The deprecated tweened store factory is built on top of the writable store contract.
- [Preprocessing and sourcemap composition](nodes/r2-preprocess-sourcemaps.md) → [Compiler option validation](nodes/r2-compiler-options.md) · model-inferred · 0 edge(s)
- [Shared runtime utilities](nodes/r2-shared-internals.md) → [Reactivity core \(signals and deriveds\)](nodes/r2-client-reactivity.md) · model-inferred · 0 edge(s)
- [Store contract implementation](nodes/r2-stores.md) → [Reactivity core \(signals and deriveds\)](nodes/r2-client-reactivity.md) · model-inferred · 0 edge(s)
- [Client code generation](nodes/r2-transform-client.md) → [Compile diagnostics](nodes/r2-compiler-diagnostics.md) · model-inferred · 0 edge(s)
- [Server \(SSR\) code generation](nodes/r2-transform-server.md) → [Compile diagnostics](nodes/r2-compiler-diagnostics.md) · model-inferred · 0 edge(s)
- [Server \(SSR\) code generation](nodes/r2-transform-server.md) → [Shared transform assignment driver](nodes/r2-transform-shared-assignments.md) · graph-confirmed · 1 edge(s)
- [Semantic Analysis](nodes/r3-compiler-analyze.md) → [Compiler Diagnostics & Warnings](nodes/r3-compiler-diagnostics.md) · graph-confirmed · 3 edge(s)
- [Semantic Analysis](nodes/r3-compiler-analyze.md) → [Template Parsing](nodes/r3-compiler-parse.md) · model-inferred · 0 edge(s)
- [Semantic Analysis](nodes/r3-compiler-analyze.md) → [Compiler Shared Utilities & Legacy AST](nodes/r3-compiler-shared-utils.md) · model-inferred · 0 edge(s)
- [Compiler Diagnostics & Warnings](nodes/r3-compiler-diagnostics.md) → [Svelte Compiler](nodes/r3-compiler.md) · containment · → 0 / ← 0 edge(s) (ancestor direct units and descendant subtree; → follows ` r3-compiler-diagnostics ` → ` r3-compiler `)
- [Compiler Diagnostics & Warnings](nodes/r3-compiler-diagnostics.md) → [Code & Docs Generation](nodes/r3-tooling-codegen.md) · model-inferred · 0 edge(s)
- [Template Parsing](nodes/r3-compiler-parse.md) → [Svelte Compiler](nodes/r3-compiler.md) · containment · → 0 / ← 0 edge(s) (ancestor direct units and descendant subtree; → follows ` r3-compiler-parse ` → ` r3-compiler `)
- [Compiler Shared Utilities & Legacy AST](nodes/r3-compiler-shared-utils.md) → [Compiler Diagnostics & Warnings](nodes/r3-compiler-diagnostics.md) · graph-confirmed · 1 edge(s)
- [Code Transformation](nodes/r3-compiler-transform.md) → [Semantic Analysis](nodes/r3-compiler-analyze.md) · model-inferred · 0 edge(s)
- [Client Transform](nodes/r3-compiler-transform-client.md) → [Compiler Diagnostics & Warnings](nodes/r3-compiler-diagnostics.md) · model-inferred · 0 edge(s)
- [Client Transform](nodes/r3-compiler-transform-client.md) → [Shared Transform Utilities](nodes/r3-compiler-transform-utils.md) · graph-confirmed · 3 edge(s)
- [Server Transform \(SSR\)](nodes/r3-compiler-transform-server.md) → [Shared Transform Utilities](nodes/r3-compiler-transform-utils.md) · graph-confirmed · 3 edge(s)
- [Shared Transform Utilities](nodes/r3-compiler-transform-utils.md) → [Server Transform \(SSR\)](nodes/r3-compiler-transform-server.md) · model-inferred · 0 edge(s)
- [Spring Motion](nodes/r3-public-motion.md) → [Dev-Mode Diagnostics](nodes/r3-runtime-dev-tools.md) · graph-confirmed · 7 edge(s)
- [Spring Motion](nodes/r3-public-motion.md) → [Signal Sources](nodes/r3-runtime-reactivity-sources.md) · graph-confirmed · 7 edge(s) · The Spring class backs its target/current values with state signals from the sources layer.
- [Reactive Window Values](nodes/r3-public-reactive-window.md) → [Dev-Mode Diagnostics](nodes/r3-runtime-dev-tools.md) · graph-confirmed · 1 edge(s)
- [Reactive Window Values](nodes/r3-public-reactive-window.md) → [Signal Sources](nodes/r3-runtime-reactivity-sources.md) · graph-confirmed · 2 edge(s)
- [Transition Configs](nodes/r3-public-transitions.md) → [DOM Elements, Bindings & Transitions](nodes/r3-runtime-dom-elements.md) · model-inferred · 0 edge(s)
- [DOM Blocks](nodes/r3-runtime-dom-blocks.md) → [Effect Batching & Scheduling](nodes/r3-runtime-reactivity-batching.md) · graph-confirmed · 1 edge(s)
- [DOM Blocks](nodes/r3-runtime-dom-blocks.md) → [Signal Sources](nodes/r3-runtime-reactivity-sources.md) · model-inferred · 0 edge(s)
- [DOM Elements, Bindings & Transitions](nodes/r3-runtime-dom-elements.md) → [Effect Batching & Scheduling](nodes/r3-runtime-reactivity-batching.md) · model-inferred · 0 edge(s)
- [DOM Elements, Bindings & Transitions](nodes/r3-runtime-dom-elements.md) → [Signal Sources](nodes/r3-runtime-reactivity-sources.md) · model-inferred · 0 edge(s)
- [Legacy Reactivity Mode](nodes/r3-runtime-legacy-mode.md) → [Signal Sources](nodes/r3-runtime-reactivity-sources.md) · graph-confirmed · 1 edge(s)
- [Deep Reactivity Proxies](nodes/r3-runtime-proxy.md) → [Dev-Mode Diagnostics](nodes/r3-runtime-dev-tools.md) · graph-confirmed · 9 edge(s)
- [Deep Reactivity Proxies](nodes/r3-runtime-proxy.md) → [Signal Sources](nodes/r3-runtime-reactivity-sources.md) · graph-confirmed · 13 edge(s)
- [Effect Batching & Scheduling](nodes/r3-runtime-reactivity-batching.md) → [Signal Sources](nodes/r3-runtime-reactivity-sources.md) · model-inferred · 0 edge(s)
- [Signal Sources](nodes/r3-runtime-reactivity-sources.md) → [Dev-Mode Diagnostics](nodes/r3-runtime-dev-tools.md) · graph-confirmed · 3 edge(s)
- [Signal Sources](nodes/r3-runtime-reactivity-sources.md) → [Deep Reactivity Proxies](nodes/r3-runtime-proxy.md) · graph-confirmed · 1 edge(s) · Signal writes call the proxy layer to wrap written values in deep-reactive proxies.
- [Signal Sources](nodes/r3-runtime-reactivity-sources.md) → [Effect Batching & Scheduling](nodes/r3-runtime-reactivity-batching.md) · graph-confirmed · 3 edge(s) · Signal writes via internal_set and mark_reactions hand off to batch scheduling so dependent effects flush together.
- [Reactivity Benchmarks & Test Config](nodes/r3-tooling-benchmarks.md) → [Effect Batching & Scheduling](nodes/r3-runtime-reactivity-batching.md) · model-inferred · 0 edge(s)
- [Reactivity Benchmarks & Test Config](nodes/r3-tooling-benchmarks.md) → [Signal Sources](nodes/r3-runtime-reactivity-sources.md) · model-inferred · 0 edge(s)
- [Code & Docs Generation](nodes/r3-tooling-codegen.md) → [Dev-Mode Diagnostics](nodes/r3-runtime-dev-tools.md) · model-inferred · 0 edge(s)
- [Ambient & Language-Server Types](nodes/r3-types.md) → [Client Runtime Internals](nodes/r3-runtime.md) · model-inferred · 0 edge(s)
- [Analysis](nodes/r4-analyze-phase.md) → [Compiler Semantic Model](nodes/r4-compiler-model.md) · graph-confirmed · 12 edge(s)
- [Analysis](nodes/r4-analyze-phase.md) → [Compiler Utilities](nodes/r4-compiler-utils.md) · graph-confirmed · 1 edge(s)
- [Benchmark Harness](nodes/r4-benchmark-harness.md) → [Client Runtime](nodes/r4-client-runtime.md) · model-inferred · 0 edge(s)
- [Client Reactivity](nodes/r4-client-reactivity.md) → [Component Context](nodes/r4-component-context.md) · graph-confirmed · 3 edge(s)
- [Client Runtime](nodes/r4-client-runtime.md) → [Shared Runtime Utilities](nodes/r4-shared-runtime.md) · graph-confirmed · 2 edge(s)
- [Client Transform](nodes/r4-client-transform.md) → [Compiler Semantic Model](nodes/r4-compiler-model.md) · graph-confirmed · 5 edge(s)
- [Client Transform](nodes/r4-client-transform.md) → [Compiler Utilities](nodes/r4-compiler-utils.md) · model-inferred · 0 edge(s)
- [Compiler Semantic Model](nodes/r4-compiler-model.md) → [Compiler Legacy Types](nodes/r4-compiler-legacy-types.md) · model-inferred · 0 edge(s)
- [Compiler Semantic Model](nodes/r4-compiler-model.md) → [Compiler Utilities](nodes/r4-compiler-utils.md) · model-inferred · 0 edge(s)
- [Component Context](nodes/r4-component-context.md) → [Task Scheduling](nodes/r4-task-scheduling.md) · model-inferred · 0 edge(s)
- [CSS Analysis](nodes/r4-css-analysis.md) → [Compiler Semantic Model](nodes/r4-compiler-model.md) · graph-confirmed · 1 edge(s)
- [Client Dev Tooling](nodes/r4-dev-tooling-client.md) → [Client Reactivity](nodes/r4-client-reactivity.md) · graph-confirmed · 1 edge(s)
- [Diagnostic Message Codegen](nodes/r4-diagnostics-messages.md) → [Compiler Pipeline](nodes/r4-compiler-pipeline.md) · model-inferred · 0 edge(s)
- [DOM Blocks](nodes/r4-dom-blocks.md) → [Component Context](nodes/r4-component-context.md) · graph-confirmed · 10 edge(s)
- [DOM Blocks](nodes/r4-dom-blocks.md) → [DOM Elements & Events](nodes/r4-dom-elements.md) · graph-confirmed · 1 edge(s)
- [DOM Blocks](nodes/r4-dom-blocks.md) → [Shared Runtime Utilities](nodes/r4-shared-runtime.md) · graph-confirmed · 1 edge(s)
- [DOM Blocks](nodes/r4-dom-blocks.md) → [Task Scheduling](nodes/r4-task-scheduling.md) · graph-confirmed · 1 edge(s)
- [DOM Elements & Events](nodes/r4-dom-elements.md) → [Component Context](nodes/r4-component-context.md) · model-inferred · 0 edge(s)
- [DOM Elements & Events](nodes/r4-dom-elements.md) → [Shared Runtime Utilities](nodes/r4-shared-runtime.md) · graph-confirmed · 1 edge(s)
- [DOM Elements & Events](nodes/r4-dom-elements.md) → [Task Scheduling](nodes/r4-task-scheduling.md) · graph-confirmed · 2 edge(s)
- [Public Component Types \(Legacy\)](nodes/r4-legacy-component-types.md) → [Public Component Types \(Modern\)](nodes/r4-public-component-types.md) · model-inferred · 0 edge(s)
- [Parsing](nodes/r4-parse-phase.md) → [Compiler Semantic Model](nodes/r4-compiler-model.md) · model-inferred · 0 edge(s)
- [Playground Sandbox](nodes/r4-playground-sandbox.md) → [Compiler Pipeline](nodes/r4-compiler-pipeline.md) · model-inferred · 0 edge(s)
- [Public Component Types \(Modern\)](nodes/r4-public-component-types.md) → [Reactive Primitives & Motion](nodes/r4-reactive-primitives.md) · model-inferred · 0 edge(s)
- [Reactive Primitives & Motion](nodes/r4-reactive-primitives.md) → [Shared Runtime Utilities](nodes/r4-shared-runtime.md) · model-inferred · 0 edge(s)
- [Reactive Primitives & Motion](nodes/r4-reactive-primitives.md) → [Task Scheduling](nodes/r4-task-scheduling.md) · graph-confirmed · 1 edge(s)
- [Repository Tooling](nodes/r4-repo-tooling.md) → [Svelte Monorepo](nodes/r4-svelte-monorepo.md) · containment · → 0 / ← 0 edge(s) (ancestor direct units and descendant subtree; → follows ` r4-repo-tooling ` → ` r4-svelte-monorepo `)
- [Server Runtime](nodes/r4-server-runtime.md) → [Shared Runtime Utilities](nodes/r4-shared-runtime.md) · model-inferred · 0 edge(s)
- [Server Transform](nodes/r4-server-transform.md) → [Compiler Semantic Model](nodes/r4-compiler-model.md) · graph-confirmed · 9 edge(s)
- [Transform Entry](nodes/r4-transform-entry.md) → [Client Transform](nodes/r4-client-transform.md) · graph-confirmed · 2 edge(s)
- [Analyze Visitors](nodes/r5-analyze-visitors.md) → [Shared AST Utilities](nodes/r5-compiler-ast-utils.md) · graph-confirmed · 15 edge(s)
- [Analyze Visitors](nodes/r5-analyze-visitors.md) → [Fuzzy Match Diagnostics](nodes/r5-parse-diagnostics.md) · graph-confirmed · 1 edge(s)
- [Attachments API](nodes/r5-attachments-api.md) → [Effect Lifecycle](nodes/r5-effects-module.md) · graph-confirmed · 1 edge(s)
- [Benchmark Suites](nodes/r5-benchmark-suites.md) → [Client Runtime](nodes/r5-client-runtime.md) · model-inferred · 0 edge(s)
- [Benchmark Suites](nodes/r5-benchmark-suites.md) → [Compiler](nodes/r5-compiler.md) · model-inferred · 0 edge(s)
- [Template Emission](nodes/r5-client-template-transform.md) → [Client Transform Visitors](nodes/r5-client-transform-visitors.md) · model-inferred · 0 edge(s)
- [Client Transform Visitors](nodes/r5-client-transform-visitors.md) → [Shared AST Utilities](nodes/r5-compiler-ast-utils.md) · graph-confirmed · 11 edge(s)
- [Client Transform Visitors](nodes/r5-client-transform-visitors.md) → [Compiler State and Errors](nodes/r5-compiler-state-errors.md) · graph-confirmed · 5 edge(s)
- [Lifecycle and Events](nodes/r5-component-lifecycle.md) → [Signal Core](nodes/r5-signal-core.md) · graph-confirmed · 2 edge(s)
- [CSS Analysis Utilities](nodes/r5-css-analyze-utils.md) → [Shared AST Utilities](nodes/r5-compiler-ast-utils.md) · model-inferred · 0 edge(s)
- [CSS Transform](nodes/r5-css-transform.md) → [CSS Analysis Utilities](nodes/r5-css-analyze-utils.md) · model-inferred · 0 edge(s)
- [Each Block](nodes/r5-each-block.md) → [Effect Lifecycle](nodes/r5-effects-module.md) · graph-confirmed · 11 edge(s)
- [Each Block](nodes/r5-each-block.md) → [Signal Core](nodes/r5-signal-core.md) · graph-confirmed · 2 edge(s)
- [Effect Lifecycle](nodes/r5-effects-module.md) → [Signal Core](nodes/r5-signal-core.md) · graph-confirmed · 13 edge(s)
- [Input Bindings](nodes/r5-input-bindings.md) → [Effect Lifecycle](nodes/r5-effects-module.md) · graph-confirmed · 5 edge(s)
- [Input Bindings](nodes/r5-input-bindings.md) → [Signal Core](nodes/r5-signal-core.md) · graph-confirmed · 3 edge(s)
- [Svelte 4 Compatibility Adapters](nodes/r5-legacy-adapters.md) → [Lifecycle and Events](nodes/r5-component-lifecycle.md) · model-inferred · 0 edge(s)
- [Svelte 4 Compatibility Adapters](nodes/r5-legacy-adapters.md) → [Effect Lifecycle](nodes/r5-effects-module.md) · graph-confirmed · 1 edge(s)
- [Legacy Component Reactivity](nodes/r5-legacy-internal.md) → [Effect Lifecycle](nodes/r5-effects-module.md) · graph-confirmed · 3 edge(s)
- [Legacy Component Reactivity](nodes/r5-legacy-internal.md) → [Signal Core](nodes/r5-signal-core.md) · graph-confirmed · 4 edge(s)
- [SSR Playground Sandbox](nodes/r5-playground-sandbox.md) → [Server Rendering](nodes/r5-server-render.md) · model-inferred · 0 edge(s)
- [Reactive Wrappers and Stores](nodes/r5-reactivity-wrappers.md) → [Effect Lifecycle](nodes/r5-effects-module.md) · graph-confirmed · 3 edge(s)
- [Reactive Wrappers and Stores](nodes/r5-reactivity-wrappers.md) → [Signal Core](nodes/r5-signal-core.md) · graph-confirmed · 16 edge(s)
- [Script and Expression Reading](nodes/r5-script-parsing.md) → [Shared AST Utilities](nodes/r5-compiler-ast-utils.md) · graph-confirmed · 1 edge(s)
- [Script and Expression Reading](nodes/r5-script-parsing.md) → [Compiler Entry API](nodes/r5-compiler-entry.md) · model-inferred · 0 edge(s)
- [Server Transform](nodes/r5-server-transform.md) → [Shared AST Utilities](nodes/r5-compiler-ast-utils.md) · model-inferred · 0 edge(s)
- [Server Transform](nodes/r5-server-transform.md) → [Shared Runtime Libraries](nodes/r5-shared-lib.md) · graph-confirmed · 3 edge(s)
- [Template Element Parsing](nodes/r5-template-parsing.md) → [Script and Expression Reading](nodes/r5-script-parsing.md) · graph-confirmed · 1 edge(s)
- [Build & Repo Tooling](nodes/repo-tooling.md) → [Compiler Pipeline](nodes/compiler-pipeline.md) · model-inferred · 0 edge(s)
- [Build & Repo Tooling](nodes/repo-tooling.md) → [Server Runtime](nodes/server-runtime.md) · model-inferred · 0 edge(s)
- [Server Runtime](nodes/server-runtime.md) → [Client Runtime](nodes/client-runtime.md) · model-inferred · 0 edge(s)
- [Server Runtime](nodes/server-runtime.md) → [Compiler Pipeline](nodes/compiler-pipeline.md) · model-inferred · 0 edge(s)
- [Server Runtime](nodes/server-runtime.md) → [Shared Runtime Utilities](nodes/shared-runtime.md) · model-inferred · 0 edge(s)
- [Shared Runtime Utilities](nodes/shared-runtime.md) → [Client Runtime](nodes/client-runtime.md) · model-inferred · 0 edge(s)
- [Shared Runtime Utilities](nodes/shared-runtime.md) → [Compiler Pipeline](nodes/compiler-pipeline.md) · model-inferred · 0 edge(s)
- [Shared Runtime Utilities](nodes/shared-runtime.md) → [Server Runtime](nodes/server-runtime.md) · model-inferred · 0 edge(s)
- [Reactive value wrappers](nodes/r2-reactive-values.md) → [Signal Sources](nodes/r3-runtime-reactivity-sources.md) · graph-only · 26 edge(s)
- [Client Transform](nodes/r3-compiler-transform-client.md) → [Shared Client Transform Builders](nodes/r1-client-shared-transform-utils.md) · graph-only · 23 edge(s)
- [Reactive value wrappers](nodes/r2-reactive-values.md) → [Signal Core](nodes/r5-signal-core.md) · graph-only · 21 edge(s)
- [Reactivity benchmarks](nodes/r2-benchmarking.md) → [Benchmark Harness](nodes/r4-benchmark-harness.md) · graph-only · 19 edge(s)
- [Reactive Primitives & Motion](nodes/r4-reactive-primitives.md) → [Signal Sources](nodes/r3-runtime-reactivity-sources.md) · graph-only · 19 edge(s)
- [DOM Blocks](nodes/r4-dom-blocks.md) → [Effect Lifecycle](nodes/r5-effects-module.md) · graph-only · 18 edge(s)
- [Client code generation](nodes/r2-transform-client.md) → [Shared Client Transform Builders](nodes/r1-client-shared-transform-utils.md) · graph-only · 16 edge(s)
- [DOM Blocks](nodes/r3-runtime-dom-blocks.md) → [Hydration Cursor State](nodes/r1-hydration-cursor.md) · graph-only · 16 edge(s)
- [Server Transform Phase](nodes/r1-server-transform.md) → [Server Transform](nodes/r5-server-transform.md) · graph-only · 15 edge(s)
- [Element integrations: custom elements, actions, bindings](nodes/r2-client-dom-elements.md) → [Effect Lifecycle](nodes/r5-effects-module.md) · graph-only · 15 edge(s)
- [Semantic Analysis](nodes/r3-compiler-analyze.md) → [Analysis validation core](nodes/r2-analyze-shared-validation.md) · graph-only · 15 edge(s)
- [Semantic Analysis](nodes/r3-compiler-analyze.md) → [Compiler Semantic Model](nodes/r4-compiler-model.md) · graph-only · 15 edge(s)
- [Analyze Visitors](nodes/r5-analyze-visitors.md) → [Analysis validation core](nodes/r2-analyze-shared-validation.md) · graph-only · 15 edge(s)
- [Benchmark Suites](nodes/r5-benchmark-suites.md) → [Benchmark Harness](nodes/r4-benchmark-harness.md) · graph-only · 15 edge(s)
- [Client Transform Visitors](nodes/r5-client-transform-visitors.md) → [Compiler Semantic Model](nodes/r4-compiler-model.md) · graph-only · 15 edge(s)
- [Reactive Wrappers and Stores](nodes/r5-reactivity-wrappers.md) → [Signal Sources](nodes/r3-runtime-reactivity-sources.md) · graph-only · 14 edge(s)
- [Boundary & Async Blocks](nodes/r1-boundary-blocks.md) → [Effect Lifecycle](nodes/r5-effects-module.md) · graph-only · 13 edge(s)
- [Analyze-phase AST visitors](nodes/r2-analyze-visitors.md) → [Analysis Infrastructure & Visitor Helpers](nodes/r1-analysis-infra.md) · graph-only · 13 edge(s)
- [Analyze-phase AST visitors](nodes/r2-analyze-visitors.md) → [Shared AST Utilities](nodes/r5-compiler-ast-utils.md) · graph-only · 13 edge(s)
- [Template Parsing](nodes/r3-compiler-parse.md) → [Template Element Parsing](nodes/r5-template-parsing.md) · graph-only · 13 edge(s)
- [DOM Blocks](nodes/r3-runtime-dom-blocks.md) → [DOM primitives: operations and templates](nodes/r2-client-dom-core.md) · graph-only · 13 edge(s)
- [DOM Blocks](nodes/r3-runtime-dom-blocks.md) → [Effect Lifecycle](nodes/r5-effects-module.md) · graph-only · 13 edge(s)
- [Template Parsing](nodes/r3-compiler-parse.md) → [Syntax parsing \(template expressions and CSS\)](nodes/r2-compiler-parsing.md) · graph-only · 12 edge(s)
- [Effect Batching & Scheduling](nodes/r3-runtime-reactivity-batching.md) → [Signal Core](nodes/r5-signal-core.md) · graph-only · 12 edge(s)
- [Signal Sources](nodes/r3-runtime-reactivity-sources.md) → [Signal Core](nodes/r5-signal-core.md) · graph-only · 12 edge(s)
- [Reactive Primitives & Motion](nodes/r4-reactive-primitives.md) → [Dev-Mode Diagnostics](nodes/r3-runtime-dev-tools.md) · graph-only · 12 edge(s)
- [Client Transform Visitors](nodes/r5-client-transform-visitors.md) → [Client Transform](nodes/r4-client-transform.md) · graph-only · 12 edge(s)
- [Element integrations: custom elements, actions, bindings](nodes/r2-client-dom-elements.md) → [DOM Elements, Bindings & Transitions](nodes/r3-runtime-dom-elements.md) · graph-only · 11 edge(s)
- [Compiler Semantic Model](nodes/r4-compiler-model.md) → [Shared AST Utilities](nodes/r5-compiler-ast-utils.md) · graph-only · 11 edge(s)
- [DOM Elements & Events](nodes/r4-dom-elements.md) → [Effect Lifecycle](nodes/r5-effects-module.md) · graph-only · 11 edge(s)
- [JS & Template Analysis](nodes/r4-js-template-analysis.md) → [Compiler Semantic Model](nodes/r4-compiler-model.md) · graph-only · 11 edge(s)
- [Analyze Visitors](nodes/r5-analyze-visitors.md) → [Analysis Infrastructure & Visitor Helpers](nodes/r1-analysis-infra.md) · graph-only · 11 edge(s)
- [Template Element Parsing](nodes/r5-template-parsing.md) → [Compiler Semantic Model](nodes/r4-compiler-model.md) · graph-only · 11 edge(s)
- [Template Parsing](nodes/r3-compiler-parse.md) → [Script and Expression Reading](nodes/r5-script-parsing.md) · graph-only · 10 edge(s)
- [Client Transform](nodes/r4-client-transform.md) → [Client Transform](nodes/r3-compiler-transform-client.md) · graph-only · 10 edge(s)
- [Each Block](nodes/r5-each-block.md) → [Hydration Cursor State](nodes/r1-hydration-cursor.md) · graph-only · 10 edge(s)
- [Reactivity Benchmarking](nodes/r1-benchmarking.md) → [Benchmark Harness](nodes/r4-benchmark-harness.md) · graph-only · 9 edge(s)
- [Client Transform](nodes/r4-client-transform.md) → [Shared AST Utilities](nodes/r5-compiler-ast-utils.md) · graph-only · 9 edge(s)
- [Boundary & Async Blocks](nodes/r1-boundary-blocks.md) → [Signal Core](nodes/r5-signal-core.md) · graph-only · 8 edge(s)
- [Mount, Hydrate & Unmount](nodes/r1-client-mounting.md) → [DOM primitives: operations and templates](nodes/r2-client-dom-core.md) · graph-only · 8 edge(s)

Graph-only pairs are ranked by edge count; 302 omitted.

### Within containment


Within containment: 0 pairs, ranked by edge count; 0 omitted. Each graph list keeps at most 40 pairs independently.

## Key flows

- **Compile error raising** · Parse and analysis failures funnel through the generated error-thrower group into the central e() helper that builds the positioned compile error.
  [errors-js-exported-error-throwers](nodes/r2-compiler-diagnostics.md#u-9c7c186d9bb9) → [packages/svelte/src/compiler/errors.js:e](nodes/r2-compiler-diagnostics.md#u-35e148f96f15)
- **Warning emission** · Analysis-phase visitors emit warnings through the generated warning-message emitters into the central w() gate, which applies svelte-ignore suppression.
  [warnings.js-warning-message-emitters](nodes/r3-compiler-diagnostics.md#u-2a223a23c812) → [packages/svelte/src/compiler/warnings.js:w](nodes/r3-compiler-diagnostics.md#u-9c260d23c66a)
- **Compiler option validation** · Declarative option tables are checked by reusable type validators, with removed/deprecated options rejected via once-only warning helpers.
  [validate-options-js-option-tables](nodes/r2-compiler-options.md#u-057ab7f46350) → [validate-options-js-type-validators](nodes/r2-compiler-options.md#u-aaad6bb1d2a8) → [validator](nodes/r2-compiler-options.md#u-3dabd9340065)
- **Client attribute codegen** · The RegularElement visitor builds attribute values that lower to reactive getter expressions, memoized template chunks, and sanitized template strings.
  [packages/svelte/src/compiler/phases/3-transform/client/visitors/RegularElement.js:RegularElement](nodes/r4-client-transform.md#u-f2ea5a46376e) → [build\_attribute\_value](nodes/r3-compiler-transform-client.md#u-2462157783c9) → [build\_expression](nodes/r1-client-shared-transform-utils.md#u-cd5eb51d389f) → [build\_getter](nodes/r4-client-transform.md#u-66a19e20e1f1)
- **Static template chunking** · Static attribute text is chunked into templates, memoized placeholders, and sanitized before becoming the compiled template string.
  [packages/svelte/src/compiler/phases/3-transform/client/visitors/RegularElement.js:RegularElement](nodes/r4-client-transform.md#u-f2ea5a46376e) → [build\_attribute\_value](nodes/r3-compiler-transform-client.md#u-2462157783c9) → [build\_template\_chunk](nodes/r1-client-shared-transform-utils.md#u-d8d503fc4b7b) → [Memoizer](nodes/r1-client-shared-transform-utils.md#u-76b08484949a) → (model-inferred) → [sanitize\_template\_string](nodes/r3-compiler-shared-utils.md#u-01781e43d6ff)

## Generation notes

- Normalized after the final invalid answer (facts kept, shape fixed): module_42, module_54.
- answer_fallback: module_42: accepted attempt 2 after final attempt 3 failed validation.

## Aggregation principle checks

Program diagnostics only; they do not prove semantic correctness or trigger rewrites.

### P1 · pass

```json
{"empty_or_duplicate_capabilities": [], "ok": true, "principle": "P1"}
```

### P2 · observe

```json
{"modules": {"benchmarking": {"external": 0, "internal": 0, "internal_external_ratio": null}, "client-runtime": {"external": 0, "internal": 0, "internal_external_ratio": null}, "compiler-pipeline": {"external": 0, "internal": 0, "internal_external_ratio": null}, "diagnostics-codegen": {"external": 0, "internal": 0, "internal_external_ratio": null}, "public-reactive-apis": {"external": 0, "internal": 0, "internal_external_ratio": null}, "public-types": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r1-a11y-analysis": {"external": 20, "internal": 64, "internal_external_ratio": 3.2}, "r1-analysis": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r1-analysis-infra": {"external": 59, "internal": 4, "internal_external_ratio": 0.06779661016949153}, "r1-benchmarking": {"external": 14, "internal": 0, "internal_external_ratio": 0.0}, "r1-boundary-blocks": {"external": 57, "internal": 19, "internal_external_ratio": 0.3333333333333333}, "r1-build-tooling": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r1-client-block-visitors": {"external": 54, "internal": 5, "internal_external_ratio": 0.09259259259259259}, "r1-client-dev-tools": {"external": 18, "internal": 0, "internal_external_ratio": 0.0}, "r1-client-mounting": {"external": 30, "internal": 4, "internal_external_ratio": 0.13333333333333333}, "r1-client-shared-transform-utils": {"external": 132, "internal": 23, "internal_external_ratio": 0.17424242424242425}, "r1-client-template": {"external": 25, "internal": 2, "internal_external_ratio": 0.08}, "r1-client-transform": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r1-compiler": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r1-css-pruning": {"external": 12, "internal": 83, "internal_external_ratio": 6.916666666666667}, "r1-dom-attributes": {"external": 50, "internal": 28, "internal_external_ratio": 0.56}, "r1-dom-dom-utils": {"external": 96, "internal": 11, "internal_external_ratio": 0.11458333333333333}, "r1-error-propagation": {"external": 13, "internal": 7, "internal_external_ratio": 0.5384615384615384}, "r1-events-api": {"external": 1, "internal": 0, "internal_external_ratio": 0.0}, "r1-html-tree-validation": {"external": 16, "internal": 0, "internal_external_ratio": 0.0}, "r1-hydration-cursor": {"external": 88, "internal": 0, "internal_external_ratio": 0.0}, "r1-lint-config": {"external": 0, "internal": 3, "internal_external_ratio": null}, "r1-message-codegen-templates": {"external": 2, "internal": 0, "internal_external_ratio": 0.0}, "r1-migrator": {"external": 35, "internal": 44, "internal_external_ratio": 1.2571428571428571}, "r1-mode-flags": {"external": 1, "internal": 2, "internal_external_ratio": 2.0}, "r1-parse-entities": {"external": 6, "internal": 5, "internal_external_ratio": 0.8333333333333334}, "r1-public-types": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r1-reactivity-primitives": {"external": 20, "internal": 9, "internal_external_ratio": 0.45}, "r1-root": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r1-runtime-client": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r1-runtime-server": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r1-server-transform": {"external": 43, "internal": 21, "internal_external_ratio": 0.4883720930232558}, "r1-shared-utilities": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r1-ssr-core": {"external": 37, "internal": 12, "internal_external_ratio": 0.32432432432432434}, "r1-ssr-dev": {"external": 6, "internal": 4, "internal_external_ratio": 0.6666666666666666}, "r1-treeshakeability-audit": {"external": 2, "internal": 5, "internal_external_ratio": 2.5}, "r2-action-animate-types": {"external": 0, "internal": 1, "internal_external_ratio": null}, "r2-analyze-shared-validation": {"external": 90, "internal": 3, "internal_external_ratio": 0.03333333333333333}, "r2-analyze-visitors": {"external": 71, "internal": 5, "internal_external_ratio": 0.07042253521126761}, "r2-animate-flip": {"external": 0, "internal": 3, "internal_external_ratio": null}, "r2-benchmarking": {"external": 24, "internal": 0, "internal_external_ratio": 0.0}, "r2-client-dev": {"external": 3, "internal": 3, "internal_external_ratio": 1.0}, "r2-client-dom-blocks": {"external": 30, "internal": 1, "internal_external_ratio": 0.03333333333333333}, "r2-client-dom-core": {"external": 81, "internal": 40, "internal_external_ratio": 0.49382716049382713}, "r2-client-dom-elements": {"external": 56, "internal": 10, "internal_external_ratio": 0.17857142857142858}, "r2-client-reactivity": {"external": 54, "internal": 8, "internal_external_ratio": 0.14814814814814814}, "r2-client-runtime": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r2-compiler": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r2-compiler-diagnostics": {"external": 2, "internal": 178, "internal_external_ratio": 89.0}, "r2-compiler-options": {"external": 2, "internal": 61, "internal_external_ratio": 30.5}, "r2-compiler-parsing": {"external": 28, "internal": 57, "internal_external_ratio": 2.0357142857142856}, "r2-element-types": {"external": 0, "internal": 15, "internal_external_ratio": null}, "r2-motion": {"external": 14, "internal": 5, "internal_external_ratio": 0.35714285714285715}, "r2-preprocess-sourcemaps": {"external": 22, "internal": 56, "internal_external_ratio": 2.5454545454545454}, "r2-public-reactive": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r2-reactive-values": {"external": 67, "internal": 0, "internal_external_ratio": 0.0}, "r2-reactivity-tests": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r2-server-runtime": {"external": 8, "internal": 12, "internal_external_ratio": 1.5}, "r2-shared-internals": {"external": 9, "internal": 4, "internal_external_ratio": 0.4444444444444444}, "r2-stores": {"external": 25, "internal": 8, "internal_external_ratio": 0.32}, "r2-svelte": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r2-tooling": {"external": 0, "internal": 2, "internal_external_ratio": null}, "r2-transform-client": {"external": 76, "internal": 13, "internal_external_ratio": 0.17105263157894737}, "r2-transform-server": {"external": 23, "internal": 2, "internal_external_ratio": 0.08695652173913043}, "r2-transform-shared-assignments": {"external": 9, "internal": 0, "internal_external_ratio": 0.0}, "r2-type-definitions": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r3-compiler": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r3-compiler-analyze": {"external": 108, "internal": 11, "internal_external_ratio": 0.10185185185185185}, "r3-compiler-ast-types": {"external": 8, "internal": 0, "internal_external_ratio": 0.0}, "r3-compiler-diagnostics": {"external": 30, "internal": 92, "internal_external_ratio": 3.066666666666667}, "r3-compiler-parse": {"external": 71, "internal": 29, "internal_external_ratio": 0.4084507042253521}, "r3-compiler-shared-utils": {"external": 26, "internal": 8, "internal_external_ratio": 0.3076923076923077}, "r3-compiler-transform": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r3-compiler-transform-client": {"external": 91, "internal": 17, "internal_external_ratio": 0.18681318681318682}, "r3-compiler-transform-server": {"external": 23, "internal": 6, "internal_external_ratio": 0.2608695652173913}, "r3-compiler-transform-utils": {"external": 29, "internal": 4, "internal_external_ratio": 0.13793103448275862}, "r3-public-api": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r3-public-motion": {"external": 33, "internal": 12, "internal_external_ratio": 0.36363636363636365}, "r3-public-reactive-window": {"external": 5, "internal": 0, "internal_external_ratio": 0.0}, "r3-public-transitions": {"external": 0, "internal": 5, "internal_external_ratio": null}, "r3-runtime": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r3-runtime-dev-tools": {"external": 81, "internal": 2, "internal_external_ratio": 0.024691358024691357}, "r3-runtime-dom-blocks": {"external": 73, "internal": 6, "internal_external_ratio": 0.0821917808219178}, "r3-runtime-dom-elements": {"external": 74, "internal": 26, "internal_external_ratio": 0.35135135135135137}, "r3-runtime-legacy-mode": {"external": 4, "internal": 2, "internal_external_ratio": 0.5}, "r3-runtime-proxy": {"external": 51, "internal": 11, "internal_external_ratio": 0.21568627450980393}, "r3-runtime-reactivity-batching": {"external": 65, "internal": 18, "internal_external_ratio": 0.27692307692307694}, "r3-runtime-reactivity-sources": {"external": 174, "internal": 16, "internal_external_ratio": 0.09195402298850575}, "r3-svelte-monorepo": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r3-tooling": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r3-tooling-benchmarks": {"external": 14, "internal": 3, "internal_external_ratio": 0.21428571428571427}, "r3-tooling-codegen": {"external": 5, "internal": 3, "internal_external_ratio": 0.6}, "r3-types": {"external": 1, "internal": 3, "internal_external_ratio": 3.0}, "r4-analyze-phase": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r4-benchmark-harness": {"external": 73, "internal": 12, "internal_external_ratio": 0.1643835616438356}, "r4-client-reactivity": {"external": 50, "internal": 9, "internal_external_ratio": 0.18}, "r4-client-runtime": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r4-client-transform": {"external": 117, "internal": 26, "internal_external_ratio": 0.2222222222222222}, "r4-compiler-legacy-types": {"external": 2, "internal": 0, "internal_external_ratio": 0.0}, "r4-compiler-model": {"external": 198, "internal": 69, "internal_external_ratio": 0.3484848484848485}, "r4-compiler-pipeline": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r4-compiler-utils": {"external": 14, "internal": 14, "internal_external_ratio": 1.0}, "r4-component-context": {"external": 41, "internal": 13, "internal_external_ratio": 0.3170731707317073}, "r4-css-analysis": {"external": 9, "internal": 5, "internal_external_ratio": 0.5555555555555556}, "r4-dev-tooling-client": {"external": 20, "internal": 0, "internal_external_ratio": 0.0}, "r4-diagnostics-messages": {"external": 2, "internal": 5, "internal_external_ratio": 2.5}, "r4-dom-blocks": {"external": 77, "internal": 5, "internal_external_ratio": 0.06493506493506493}, "r4-dom-elements": {"external": 67, "internal": 18, "internal_external_ratio": 0.26865671641791045}, "r4-dom-rendering": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r4-js-template-analysis": {"external": 66, "internal": 10, "internal_external_ratio": 0.15151515151515152}, "r4-legacy-client-helpers": {"external": 6, "internal": 0, "internal_external_ratio": 0.0}, "r4-legacy-component-types": {"external": 1, "internal": 5, "internal_external_ratio": 5.0}, "r4-parse-phase": {"external": 9, "internal": 20, "internal_external_ratio": 2.2222222222222223}, "r4-playground-sandbox": {"external": 0, "internal": 15, "internal_external_ratio": null}, "r4-public-component-types": {"external": 0, "internal": 5, "internal_external_ratio": null}, "r4-reactive-primitives": {"external": 79, "internal": 1, "internal_external_ratio": 0.012658227848101266}, "r4-repo-tooling": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r4-server-runtime": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r4-server-transform": {"external": 25, "internal": 3, "internal_external_ratio": 0.12}, "r4-shared-runtime": {"external": 30, "internal": 5, "internal_external_ratio": 0.16666666666666666}, "r4-svelte-monorepo": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r4-task-scheduling": {"external": 25, "internal": 0, "internal_external_ratio": 0.0}, "r4-transform-entry": {"external": 14, "internal": 1, "internal_external_ratio": 0.07142857142857142}, "r4-transform-phase": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r5-analyze": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r5-analyze-visitors": {"external": 89, "internal": 7, "internal_external_ratio": 0.07865168539325842}, "r5-attachments-api": {"external": 2, "internal": 0, "internal_external_ratio": 0.0}, "r5-benchmark-suites": {"external": 24, "internal": 1, "internal_external_ratio": 0.041666666666666664}, "r5-client-runtime": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r5-client-template-transform": {"external": 6, "internal": 2, "internal_external_ratio": 0.3333333333333333}, "r5-client-transform": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r5-client-transform-types": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r5-client-transform-visitors": {"external": 90, "internal": 4, "internal_external_ratio": 0.044444444444444446}, "r5-compiler": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r5-compiler-ast-utils": {"external": 194, "internal": 12, "internal_external_ratio": 0.061855670103092786}, "r5-compiler-entry": {"external": 12, "internal": 11, "internal_external_ratio": 0.9166666666666666}, "r5-compiler-state-errors": {"external": 38, "internal": 5, "internal_external_ratio": 0.13157894736842105}, "r5-compiler-types": {"external": 8, "internal": 3, "internal_external_ratio": 0.375}, "r5-component-lifecycle": {"external": 4, "internal": 10, "internal_external_ratio": 2.5}, "r5-css-analyze-utils": {"external": 13, "internal": 5, "internal_external_ratio": 0.38461538461538464}, "r5-css-transform": {"external": 11, "internal": 22, "internal_external_ratio": 2.0}, "r5-each-block": {"external": 44, "internal": 29, "internal_external_ratio": 0.6590909090909091}, "r5-effects-module": {"external": 242, "internal": 29, "internal_external_ratio": 0.11983471074380166}, "r5-input-bindings": {"external": 29, "internal": 9, "internal_external_ratio": 0.3103448275862069}, "r5-internal-shared-utils": {"external": 22, "internal": 0, "internal_external_ratio": 0.0}, "r5-legacy-adapters": {"external": 7, "internal": 2, "internal_external_ratio": 0.2857142857142857}, "r5-legacy-internal": {"external": 10, "internal": 4, "internal_external_ratio": 0.4}, "r5-parse": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r5-parse-diagnostics": {"external": 7, "internal": 12, "internal_external_ratio": 1.7142857142857142}, "r5-playground-sandbox": {"external": 3, "internal": 2, "internal_external_ratio": 0.6666666666666666}, "r5-public-api": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r5-reactivity-wrappers": {"external": 67, "internal": 3, "internal_external_ratio": 0.04477611940298507}, "r5-script-parsing": {"external": 30, "internal": 14, "internal_external_ratio": 0.4666666666666667}, "r5-server-render": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r5-server-transform": {"external": 41, "internal": 3, "internal_external_ratio": 0.07317073170731707}, "r5-shared-lib": {"external": 17, "internal": 1, "internal_external_ratio": 0.058823529411764705}, "r5-signal-core": {"external": 241, "internal": 25, "internal_external_ratio": 0.1037344398340249}, "r5-svelte": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r5-template-parsing": {"external": 57, "internal": 13, "internal_external_ratio": 0.22807017543859648}, "r5-transform": {"external": 0, "internal": 0, "internal_external_ratio": null}, "repo-tooling": {"external": 0, "internal": 0, "internal_external_ratio": null}, "server-runtime": {"external": 0, "internal": 0, "internal_external_ratio": null}, "shared-runtime": {"external": 0, "internal": 0, "internal_external_ratio": null}, "svelte-monorepo": {"external": 0, "internal": 0, "internal_external_ratio": null}}, "ok": false, "principle": "P2", "scope": "direct primary ownership; incident cross-module edges counted at each endpoint"}
```

### P3 · observe

```json
{"bounds": [5, 30], "ok": false, "out_of_bounds": {"r1-a11y-analysis": 3, "r1-benchmarking": 3, "r1-build-tooling": 1, "r1-client-dev-tools": 3, "r1-client-mounting": 4, "r1-client-template": 3, "r1-dom-dom-utils": 36, "r1-error-propagation": 4, "r1-events-api": 2, "r1-html-tree-validation": 3, "r1-hydration-cursor": 3, "r1-lint-config": 3, "r1-message-codegen-templates": 2, "r1-mode-flags": 3, "r1-treeshakeability-audit": 4, "r2-action-animate-types": 4, "r2-animate-flip": 2, "r2-benchmarking": 3, "r2-client-dev": 4, "r2-compiler-diagnostics": 3, "r2-reactivity-tests": 2, "r2-transform-shared-assignments": 1, "r3-public-reactive-window": 2, "r3-runtime": 2, "r3-runtime-legacy-mode": 2, "r4-compiler-legacy-types": 2, "r4-legacy-client-helpers": 1, "r4-task-scheduling": 1, "r4-transform-entry": 2, "r5-attachments-api": 3, "r5-client-template-transform": 3, "r5-client-transform-types": 2, "r5-legacy-internal": 2, "r5-playground-sandbox": 3, "r5-server-render": 2, "r5-shared-lib": 3}, "principle": "P3", "scope": "nodes with directly owned units; structural ancestors excluded"}
```

### P4 · pass

```json
{"ok": true, "ownership_violations": {}, "principle": "P4"}
```

### P5 · observe

```json
{"min_dependent_modules": 2, "min_edges_per_dependent_module": 3, "note": "dependency signal only, including utilities already separated; no automatic reassignment", "ok": false, "principle": "P5", "shared_units": {"benchmarking/utils.js::function::assert::2318": {"r1-benchmarking": 7, "r2-benchmarking": 7, "r3-tooling-benchmarks": 6, "r5-benchmark-suites": 9}, "benchmarking/utils.js::function::fastest_test::2018": {"r1-benchmarking": 6, "r2-benchmarking": 17, "r3-tooling-benchmarks": 6, "r5-benchmark-suites": 11}, "grp:batch.js-batch-class": {"r1-boundary-blocks": 3, "r2-client-reactivity": 5, "r3-runtime-dom-blocks": 1, "r3-runtime-reactivity-sources": 3, "r5-each-block": 2, "r5-effects-module": 2, "r5-signal-core": 4}, "grp:effects.js-trivial-effect-factories": {"r1-boundary-blocks": 6, "r1-client-dev-tools": 2, "r1-client-mounting": 2, "r1-dom-attributes": 4, "r2-client-dom-blocks": 2, "r2-client-dom-elements": 21, "r2-client-reactivity": 2, "r2-motion": 1, "r3-public-motion": 2, "r3-runtime-dev-tools": 2, "r3-runtime-dom-blocks": 7, "r3-runtime-dom-elements": 11, "r4-client-reactivity": 4, "r4-dev-tooling-client": 9, "r4-dom-blocks": 10, "r4-dom-elements": 16, "r4-reactive-primitives": 4, "r5-attachments-api": 2, "r5-each-block": 4, "r5-input-bindings": 10, "r5-reactivity-wrappers": 2}, "grp:hydration.js-state-and-guards": {"r1-boundary-blocks": 4, "r1-client-mounting": 7, "r1-dom-attributes": 6, "r2-client-dom-blocks": 10, "r2-client-dom-core": 11, "r3-runtime-dom-blocks": 19, "r4-dom-blocks": 9, "r5-each-block": 7}, "grp:loop.js-raf-task-loop": {"r2-motion": 4, "r3-public-motion": 4, "r3-runtime-dom-elements": 2}, "grp:operations.js-node-navigation": {"r1-boundary-blocks": 1, "r1-client-mounting": 4, "r1-hydration-cursor": 6, "r2-client-dom-blocks": 9, "r3-runtime-dom-blocks": 10, "r3-runtime-dom-elements": 2, "r4-dom-blocks": 3, "r5-each-block": 4, "r5-effects-module": 1}, "grp:runtime.js-module-state-setters": {"r1-boundary-blocks": 6, "r1-dom-attributes": 4, "r1-reactivity-primitives": 2, "r2-client-reactivity": 6, "r3-runtime-dom-elements": 6, "r3-runtime-proxy": 4, "r3-runtime-reactivity-batching": 3, "r3-runtime-reactivity-sources": 3, "r4-client-reactivity": 6, "r4-dom-blocks": 4, "r4-dom-elements": 4, "r5-effects-module": 4, "r5-reactivity-wrappers": 7}, "grp:task.js-queues": {"r1-boundary-blocks": 2, "r1-dom-attributes": 2, "r3-runtime-dom-elements": 4, "r3-runtime-reactivity-batching": 2, "r4-dom-blocks": 2, "r4-dom-elements": 4, "r4-reactive-primitives": 2, "r5-each-block": 1, "r5-input-bindings": 3}, "grp:tracing.js-tagging": {"r1-boundary-blocks": 1, "r2-motion": 2, "r2-reactive-values": 8, "r3-public-motion": 7, "r3-public-reactive-window": 1, "r3-runtime-proxy": 9, "r3-runtime-reactivity-sources": 1, "r4-reactive-primitives": 14, "r5-reactivity-wrappers": 6}, "packages/svelte/src/compiler/phases/1-parse/read/expression.js::function::read_expression::977": {"r3-compiler-parse": 15, "r5-template-parsing": 5}, "packages/svelte/src/compiler/phases/2-analyze/visitors/shared/fragment.js::function::mark_subtree_dynamic::83": {"r2-analyze-visitors": 10, "r3-compiler-analyze": 10, "r4-js-template-analysis": 4, "r5-analyze-visitors": 18}, "packages/svelte/src/compiler/phases/2-analyze/visitors/shared/utils.js::function::validate_block_not_empty::4728": {"r3-compiler-analyze": 6, "r5-analyze-visitors": 7}, "packages/svelte/src/compiler/phases/2-analyze/visitors/shared/utils.js::function::validate_opening_tag::4367": {"r2-analyze-visitors": 3, "r3-compiler-analyze": 10, "r5-analyze-visitors": 3}, "packages/svelte/src/compiler/phases/3-transform/client/transform-template/template.js::class::Template::368::s0": {"r1-client-block-visitors": 5, "r1-client-shared-transform-utils": 5, "r2-transform-client": 2, "r3-compiler-transform-client": 5, "r4-client-transform": 1, "r5-client-template-transform": 1}, "packages/svelte/src/compiler/phases/3-transform/client/utils.js::function::create_derived::8270": {"r1-client-block-visitors": 3, "r5-client-transform-visitors": 3}, "packages/svelte/src/compiler/phases/3-transform/client/visitors/Program.js::function::Program::378::s0": {"r1-client-dev-tools": 1, "r1-migrator": 7, "r1-treeshakeability-audit": 1, "r3-tooling-benchmarks": 1, "r3-tooling-codegen": 2, "r5-compiler-state-errors": 1, "r5-playground-sandbox": 3, "r5-script-parsing": 1}, "packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/element.js::function::build_attribute_value::3231": {"r1-client-shared-transform-utils": 3, "r2-transform-client": 2, "r4-client-transform": 8}, "packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/utils.js::class::Memoizer::932::s0": {"r2-transform-client": 6, "r3-compiler-transform-client": 13, "r4-client-transform": 6}, "packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/utils.js::function::add_svelte_meta::13178": {"r1-client-block-visitors": 4, "r2-transform-client": 5, "r3-compiler-transform-client": 2}, "packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/utils.js::function::build_expression::11292": {"r1-client-block-visitors": 4, "r2-transform-client": 5, "r3-compiler-transform-client": 6, "r4-client-transform": 2, "r5-client-transform-visitors": 3}, "packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/utils.js::function::build_attribute_value::4710": {"r1-server-transform": 13, "r2-transform-server": 4, "r3-compiler-transform-server": 3}, "packages/svelte/src/compiler/phases/nodes.js::function::create_attribute::1509": {"r1-server-transform": 2, "r3-compiler-analyze": 3, "r4-js-template-analysis": 3, "r5-template-parsing": 3}, "packages/svelte/src/compiler/phases/nodes.js::function::create_expression_metadata::1740": {"r1-server-transform": 2, "r2-analyze-visitors": 2, "r3-compiler-parse": 11, "r4-js-template-analysis": 2, "r5-template-parsing": 8}, "packages/svelte/src/compiler/phases/nodes.js::function::get_name::2027": {"r2-analyze-shared-validation": 2, "r2-transform-server": 2, "r3-compiler-analyze": 6, "r3-compiler-transform-server": 2, "r5-client-transform-visitors": 4}, "packages/svelte/src/compiler/phases/scope.js::class::Scope::13363::s0": {"r1-client-block-visitors": 1, "r1-client-shared-transform-utils": 5, "r1-treeshakeability-audit": 1, "r2-transform-client": 4, "r3-compiler-analyze": 2, "r3-compiler-transform-client": 4, "r3-compiler-transform-server": 2, "r4-client-transform": 3, "r4-js-template-analysis": 2, "r4-server-transform": 6, "r5-client-transform-visitors": 15}, "packages/svelte/src/compiler/phases/scope.js::function::get_rune::34200": {"r1-migrator": 2, "r2-analyze-shared-validation": 2, "r2-transform-server": 3, "r3-compiler-analyze": 6, "r3-compiler-transform-client": 2, "r3-compiler-transform-server": 1, "r4-client-transform": 2, "r4-js-template-analysis": 7, "r4-server-transform": 4, "r5-client-transform-visitors": 4}, "packages/svelte/src/compiler/state.js::function::is_ignored::2286": {"r1-client-shared-transform-utils": 4, "r2-transform-client": 4, "r3-compiler-transform-client": 4, "r3-compiler-transform-server": 2, "r4-client-transform": 6, "r5-client-transform-visitors": 3}, "packages/svelte/src/compiler/utils/ast.js::function::build_assignment_value::17513": {"r2-transform-server": 3, "r5-client-transform-visitors": 3}, "packages/svelte/src/compiler/utils/ast.js::function::extract_identifiers::4009": {"r1-client-block-visitors": 2, "r1-migrator": 3, "r2-analyze-shared-validation": 1, "r2-analyze-visitors": 3, "r2-transform-server": 1, "r3-compiler-analyze": 5, "r3-compiler-transform-utils": 2, "r4-compiler-model": 9, "r5-analyze-visitors": 3, "r5-client-transform-visitors": 2}, "packages/svelte/src/compiler/utils/ast.js::function::extract_paths::7725": {"r1-client-block-visitors": 2, "r2-transform-shared-assignments": 2, "r4-js-template-analysis": 2, "r4-server-transform": 4, "r5-client-transform-visitors": 8}, "packages/svelte/src/compiler/utils/ast.js::function::get_attribute_expression::1846": {"r2-analyze-visitors": 2, "r3-compiler-analyze": 3, "r5-analyze-visitors": 3, "r5-client-transform-visitors": 1, "r5-template-parsing": 3}, "packages/svelte/src/compiler/utils/ast.js::function::is_expression_attribute::1289": {"r3-compiler-analyze": 2, "r5-analyze-visitors": 3, "r5-template-parsing": 3}, "packages/svelte/src/compiler/utils/ast.js::function::is_text_attribute::791": {"r1-a11y-analysis": 2, "r1-client-shared-transform-utils": 2, "r1-css-pruning": 1, "r1-migrator": 5, "r1-server-transform": 3, "r2-analyze-shared-validation": 3, "r2-transform-client": 1, "r3-compiler-analyze": 2, "r3-compiler-shared-utils": 2, "r3-compiler-transform-client": 2, "r4-client-transform": 9, "r5-analyze-visitors": 6, "r5-script-parsing": 2}, "packages/svelte/src/compiler/utils/ast.js::function::object::344": {"r1-client-block-visitors": 2, "r1-client-shared-transform-utils": 3, "r2-analyze-visitors": 3, "r2-transform-client": 2, "r4-compiler-model": 2, "r5-analyze-visitors": 4}, "packages/svelte/src/compiler/utils/ast.js::function::unwrap_optional::13743": {"r2-analyze-visitors": 3, "r2-transform-client": 2, "r4-server-transform": 3}, "packages/svelte/src/compiler/utils/slot.js::function::determine_slot::181": {"r1-client-shared-transform-utils": 3, "r4-compiler-model": 3, "r5-analyze-visitors": 3}, "packages/svelte/src/escaping.js::function::escape_html::134": {"r1-client-template": 2, "r1-server-transform": 2, "r1-ssr-core": 4, "r3-compiler-transform-client": 2, "r4-shared-runtime": 2, "r5-server-transform": 5}, "packages/svelte/src/internal/client/context.js::function::is_runes::4946": {"r3-runtime-reactivity-sources": 3, "r4-client-reactivity": 2, "r4-dom-blocks": 3, "r5-signal-core": 2}, "packages/svelte/src/internal/client/context.js::function::set_component_context::568": {"r1-boundary-blocks": 2, "r4-client-reactivity": 4, "r4-dom-blocks": 3, "r5-signal-core": 3}, "packages/svelte/src/internal/client/context.js::function::set_dev_current_component_function::1881": {"r4-dom-blocks": 5, "r5-signal-core": 3}, "packages/svelte/src/internal/client/error-handling.js::function::invoke_error_boundary::1422": {"r1-boundary-blocks": 3, "r3-runtime-reactivity-batching": 2, "r4-client-reactivity": 4}, "packages/svelte/src/internal/client/reactivity/effects.js::function::block::8446": {"r1-boundary-blocks": 1, "r1-client-dev-tools": 2, "r1-dom-attributes": 2, "r2-client-dom-blocks": 4, "r3-runtime-dom-blocks": 3, "r4-dom-blocks": 5, "r4-dom-elements": 2, "r5-each-block": 1}, "packages/svelte/src/internal/client/reactivity/effects.js::function::destroy_effect::10238": {"r1-boundary-blocks": 3, "r1-client-dev-tools": 2, "r1-dom-attributes": 3, "r2-client-reactivity": 2, "r3-runtime-dom-blocks": 4, "r3-runtime-reactivity-batching": 2, "r4-dom-blocks": 2, "r4-dom-elements": 1, "r5-each-block": 2}, "packages/svelte/src/internal/client/reactivity/effects.js::function::pause_effect::12656": {"r1-boundary-blocks": 4, "r2-client-dom-blocks": 2, "r3-runtime-dom-blocks": 4, "r4-dom-blocks": 4, "r5-each-block": 2}, "packages/svelte/src/internal/client/reactivity/effects.js::function::resume_children::14390": {"r3-runtime-dom-blocks": 4, "r4-dom-blocks": 3, "r5-each-block": 2}, "packages/svelte/src/internal/client/reactivity/sources.js::function::increment::6715": {"r3-runtime-proxy": 4, "r4-reactive-primitives": 15, "r5-reactivity-wrappers": 4}, "packages/svelte/src/internal/client/reactivity/sources.js::function::internal_set::3725": {"r1-boundary-blocks": 2, "r2-client-reactivity": 3, "r3-runtime-legacy-mode": 2, "r4-dom-blocks": 3, "r5-each-block": 2}, "packages/svelte/src/internal/client/reactivity/sources.js::function::set::2970": {"r1-reactivity-primitives": 1, "r2-reactive-values": 19, "r3-public-reactive-window": 1, "r3-runtime-proxy": 1, "r4-client-reactivity": 2, "r4-legacy-client-helpers": 2, "r4-reactive-primitives": 1, "r5-reactivity-wrappers": 8}, "packages/svelte/src/internal/client/reactivity/sources.js::function::source::1477": {"r1-boundary-blocks": 2, "r1-client-dev-tools": 2, "r1-reactivity-primitives": 1, "r2-client-reactivity": 1, "r3-public-reactive-window": 2, "r3-runtime-proxy": 9, "r4-dom-blocks": 2, "r4-legacy-client-helpers": 2, "r4-reactive-primitives": 4, "r5-each-block": 2, "r5-reactivity-wrappers": 1}, "packages/svelte/src/internal/client/reactivity/sources.js::function::state::1976": {"r2-motion": 2, "r2-reactive-values": 9, "r3-public-motion": 8, "r4-reactive-primitives": 7, "r5-reactivity-wrappers": 6}, "packages/svelte/src/internal/client/runtime.js::function::get::15253": {"r1-boundary-blocks": 3, "r1-client-dev-tools": 2, "r2-reactive-values": 22, "r3-public-motion": 5, "r3-runtime-reactivity-sources": 3, "r4-client-reactivity": 2, "r4-legacy-client-helpers": 2, "r4-reactive-primitives": 4, "r5-each-block": 2, "r5-legacy-internal": 2, "r5-reactivity-wrappers": 12}, "packages/svelte/src/internal/client/runtime.js::function::set_signal_status::21252": {"r2-client-reactivity": 2, "r3-runtime-reactivity-batching": 4, "r3-runtime-reactivity-sources": 3, "r5-effects-module": 6, "r5-legacy-adapters": 1}, "packages/svelte/src/internal/client/runtime.js::function::untrack::20953": {"r1-client-dev-tools": 5, "r1-reactivity-primitives": 1, "r2-client-dom-elements": 4, "r3-runtime-dev-tools": 5, "r3-runtime-dom-elements": 2, "r3-runtime-legacy-mode": 2, "r3-runtime-reactivity-sources": 1, "r4-dev-tooling-client": 2, "r4-dom-elements": 2, "r4-reactive-primitives": 2, "r5-component-lifecycle": 4, "r5-effects-module": 2, "r5-input-bindings": 4, "r5-legacy-internal": 1}, "packages/svelte/src/internal/client/runtime.js::function::update_effect::12903": {"r3-runtime-reactivity-batching": 7, "r3-runtime-reactivity-sources": 2, "r5-effects-module": 3}, "packages/svelte/src/motion/utils.js::function::is_date::54": {"r2-motion": 3, "r3-public-motion": 3}, "packages/svelte/src/store/shared/index.js::function::get::5098": {"r4-reactive-primitives": 5, "r5-reactivity-wrappers": 6}, "packages/svelte/src/utils.js::function::is_rune::7796": {"r3-compiler-analyze": 4, "r4-compiler-model": 4, "r4-js-template-analysis": 3}}}
```

### P6 · pass

```json
{"modules": {"benchmarking": {}, "client-runtime": {}, "compiler-pipeline": {}, "diagnostics-codegen": {}, "public-reactive-apis": {}, "public-types": {}, "r1-a11y-analysis": {"javascript": 3}, "r1-analysis": {}, "r1-analysis-infra": {"javascript": 6, "typescript": 1}, "r1-benchmarking": {"javascript": 3}, "r1-boundary-blocks": {"javascript": 19}, "r1-build-tooling": {"javascript": 1}, "r1-client-block-visitors": {"javascript": 10}, "r1-client-dev-tools": {"javascript": 3}, "r1-client-mounting": {"javascript": 4}, "r1-client-shared-transform-utils": {"javascript": 12}, "r1-client-template": {"javascript": 3}, "r1-client-transform": {}, "r1-compiler": {}, "r1-css-pruning": {"javascript": 20}, "r1-dom-attributes": {"javascript": 14}, "r1-dom-dom-utils": {"javascript": 36}, "r1-error-propagation": {"javascript": 4}, "r1-events-api": {"javascript": 1, "typescript": 1}, "r1-html-tree-validation": {"javascript": 3}, "r1-hydration-cursor": {"javascript": 3}, "r1-lint-config": {"javascript": 3}, "r1-message-codegen-templates": {"javascript": 2}, "r1-migrator": {"javascript": 22}, "r1-mode-flags": {"javascript": 3}, "r1-parse-entities": {"javascript": 6}, "r1-public-types": {"typescript": 18}, "r1-reactivity-primitives": {"javascript": 9}, "r1-root": {}, "r1-runtime-client": {}, "r1-runtime-server": {}, "r1-server-transform": {"javascript": 9}, "r1-shared-utilities": {}, "r1-ssr-core": {"javascript": 29}, "r1-ssr-dev": {"javascript": 6}, "r1-treeshakeability-audit": {"javascript": 4}, "r2-action-animate-types": {"typescript": 4}, "r2-analyze-shared-validation": {"javascript": 14}, "r2-analyze-visitors": {"javascript": 24}, "r2-animate-flip": {"javascript": 2}, "r2-benchmarking": {"javascript": 3}, "r2-client-dev": {"javascript": 4}, "r2-client-dom-blocks": {"javascript": 5}, "r2-client-dom-core": {"javascript": 14}, "r2-client-dom-elements": {"javascript": 16}, "r2-client-reactivity": {"javascript": 8, "typescript": 7}, "r2-client-runtime": {}, "r2-compiler": {}, "r2-compiler-diagnostics": {"javascript": 3}, "r2-compiler-options": {"javascript": 8}, "r2-compiler-parsing": {"javascript": 18}, "r2-element-types": {"typescript": 9}, "r2-motion": {"javascript": 7}, "r2-preprocess-sourcemaps": {"javascript": 25}, "r2-public-reactive": {}, "r2-reactive-values": {"javascript": 5}, "r2-reactivity-tests": {"typescript": 2}, "r2-server-runtime": {"javascript": 11}, "r2-shared-internals": {"javascript": 11, "typescript": 1}, "r2-stores": {"javascript": 6}, "r2-svelte": {}, "r2-tooling": {"javascript": 5}, "r2-transform-client": {"javascript": 21, "typescript": 1}, "r2-transform-server": {"javascript": 16}, "r2-transform-shared-assignments": {"javascript": 1}, "r2-type-definitions": {}, "r3-compiler": {}, "r3-compiler-analyze": {"javascript": 23}, "r3-compiler-ast-types": {"typescript": 5}, "r3-compiler-diagnostics": {"javascript": 11}, "r3-compiler-parse": {"javascript": 13}, "r3-compiler-shared-utils": {"javascript": 5}, "r3-compiler-transform": {}, "r3-compiler-transform-client": {"javascript": 19}, "r3-compiler-transform-server": {"javascript": 9}, "r3-compiler-transform-utils": {"javascript": 7}, "r3-public-api": {}, "r3-public-motion": {"javascript": 8}, "r3-public-reactive-window": {"javascript": 2}, "r3-public-transitions": {"javascript": 8}, "r3-runtime": {"javascript": 2}, "r3-runtime-dev-tools": {"javascript": 10}, "r3-runtime-dom-blocks": {"javascript": 9}, "r3-runtime-dom-elements": {"javascript": 18}, "r3-runtime-legacy-mode": {"javascript": 2}, "r3-runtime-proxy": {"javascript": 5}, "r3-runtime-reactivity-batching": {"javascript": 8}, "r3-runtime-reactivity-sources": {"javascript": 12}, "r3-svelte-monorepo": {}, "r3-tooling": {}, "r3-tooling-benchmarks": {"javascript": 5}, "r3-tooling-codegen": {"javascript": 5}, "r3-types": {"typescript": 30}, "r4-analyze-phase": {}, "r4-benchmark-harness": {"javascript": 11}, "r4-client-reactivity": {"javascript": 18}, "r4-client-runtime": {}, "r4-client-transform": {"javascript": 23}, "r4-compiler-legacy-types": {"typescript": 2}, "r4-compiler-model": {"javascript": 18}, "r4-compiler-pipeline": {}, "r4-compiler-utils": {"javascript": 9}, "r4-component-context": {"javascript": 13}, "r4-css-analysis": {"javascript": 12}, "r4-dev-tooling-client": {"javascript": 6}, "r4-diagnostics-messages": {"javascript": 5}, "r4-dom-blocks": {"javascript": 7}, "r4-dom-elements": {"javascript": 19, "typescript": 1}, "r4-dom-rendering": {}, "r4-js-template-analysis": {"javascript": 10}, "r4-legacy-client-helpers": {"javascript": 1}, "r4-legacy-component-types": {"typescript": 15}, "r4-parse-phase": {"javascript": 9}, "r4-playground-sandbox": {"javascript": 9}, "r4-public-component-types": {"typescript": 16}, "r4-reactive-primitives": {"javascript": 9, "typescript": 2}, "r4-repo-tooling": {}, "r4-server-runtime": {"javascript": 6, "typescript": 1}, "r4-server-transform": {"javascript": 11}, "r4-shared-runtime": {"javascript": 10}, "r4-svelte-monorepo": {}, "r4-task-scheduling": {"javascript": 1}, "r4-transform-entry": {"javascript": 2}, "r4-transform-phase": {}, "r5-analyze": {}, "r5-analyze-visitors": {"javascript": 21}, "r5-attachments-api": {"javascript": 2, "typescript": 1}, "r5-benchmark-suites": {"javascript": 5}, "r5-client-runtime": {}, "r5-client-template-transform": {"javascript": 3}, "r5-client-transform": {}, "r5-client-transform-types": {"typescript": 2}, "r5-client-transform-visitors": {"javascript": 16}, "r5-compiler": {}, "r5-compiler-ast-utils": {"javascript": 17}, "r5-compiler-entry": {"javascript": 6}, "r5-compiler-state-errors": {"javascript": 9}, "r5-compiler-types": {"typescript": 6}, "r5-component-lifecycle": {"javascript": 9}, "r5-css-analyze-utils": {"javascript": 6}, "r5-css-transform": {"javascript": 13}, "r5-each-block": {"javascript": 19}, "r5-effects-module": {"javascript": 17}, "r5-input-bindings": {"javascript": 7}, "r5-internal-shared-utils": {"javascript": 7}, "r5-legacy-adapters": {"javascript": 6}, "r5-legacy-internal": {"javascript": 2}, "r5-parse": {}, "r5-parse-diagnostics": {"javascript": 6}, "r5-playground-sandbox": {"javascript": 3}, "r5-public-api": {}, "r5-reactivity-wrappers": {"javascript": 7, "typescript": 1}, "r5-script-parsing": {"javascript": 7}, "r5-server-render": {"javascript": 1, "typescript": 1}, "r5-server-transform": {"javascript": 6}, "r5-shared-lib": {"javascript": 3}, "r5-signal-core": {"javascript": 17, "typescript": 1}, "r5-svelte": {}, "r5-template-parsing": {"javascript": 8}, "r5-transform": {}, "repo-tooling": {}, "server-runtime": {}, "shared-runtime": {}, "svelte-monorepo": {}}, "ok": true, "principle": "P6", "scope": "unit counts by language; a multi-language unit contributes once per language"}
```

### P7 · re-render identical

```json
{"identical": true, "ok": null, "principle": "P7", "scope": "same run, same detail answers; cross-run stability requires replay scripts", "status": "re-render identical"}
```

Hierarchy and introduction length:

```json
{"hierarchy": {"ok": true, "requires_intermediate_above_units": 30}, "introduction_length": {"ok": false, "overlong": {"compiler-pipeline": {"introduction_chars": 692, "detail_chars": 0}, "diagnostics-codegen": {"introduction_chars": 386, "detail_chars": 0}, "client-runtime": {"introduction_chars": 764, "detail_chars": 0}, "server-runtime": {"introduction_chars": 708, "detail_chars": 0}, "shared-runtime": {"introduction_chars": 796, "detail_chars": 0}, "public-reactive-apis": {"introduction_chars": 928, "detail_chars": 0}, "public-types": {"introduction_chars": 803, "detail_chars": 0}, "benchmarking": {"introduction_chars": 679, "detail_chars": 0}, "repo-tooling": {"introduction_chars": 623, "detail_chars": 0}}, "scope": "capability+summary characters versus descendant explain characters"}}
```
