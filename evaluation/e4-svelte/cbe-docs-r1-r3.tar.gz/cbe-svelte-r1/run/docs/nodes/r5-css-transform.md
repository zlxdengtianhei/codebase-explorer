# CSS Transform

**Capability.** Renders analyzed component CSS: scopes selectors, removes :global wrappers and unused rules, prunes empty rules, and emits code plus a source map.

render_stylesheet drives a walker over the CSS AST; the methods decide per rule/selector whether and how it survives. Use to trace scoping and pruning decisions.

**Depends on.**

- [CSS Analysis Utilities](r5-css-analyze-utils.md) · model-inferred · 0 edge(s)

Parent: [Transform Phase](r5-transform.md)

## Units (13)

<a id="u-197b2d45aa0c"></a>
### `render_stylesheet`

`export function render_stylesheet(source, analysis, options)` · [packages/svelte/src/compiler/phases/3-transform/css/index.js:L29-L73][f1]

Renders analyzed component CSS into final code, a source map, and a hasGlobal flag.

Builds a MagicString over the source and a State carrying the scoping class (.hash), keyframes names, minify flag (analysis.inject_styles && !options.dev), and a specificity-bump tracker; walks the CSS AST with the module's visitors; then trims everything before the stylesheet start and after its end (plus preceding whitespace when minifying). Produces {code, map, hasGlobal}; generateMap includes content and uses options.filename / cssOutputFilename; the preprocessor map is merged via merge_with_preprocessor_map. In dev with css==='injected' and non-empty code, appends a sourceMappingURL comment pointing at the map URL. No internal error handling; exceptions from MagicString or the map merge propagate.

calls: [merge_with_preprocessor_map](r2-preprocess-sourcemaps.md#u-58c664c9f3e7); uses: [packages/svelte/src/compiler/phases/3-transform/css/index.js:Atrule](r5-css-transform.md#u-e1dbad642d6e)

**Uncertainties.**

- Exact walk order/visitor dispatch semantics come from zimmerframe, whose behavior is not shown here.

<a id="u-e1dbad642d6e"></a>
### `packages/svelte/src/compiler/phases/3-transform/css/index.js:Atrule`

`const visitors = { _: (node, context) => { context.state.code.addSourcemapLocation(no…` · [packages/svelte/src/compiler/phases/3-transform/css/index.js:L76-L99][f1]

Transforms at-rules during the CSS walk.

If the node is a @keyframes-style at-rule (is_keyframes_node), it locates the keyframes name in the original source (skipping spaces, stopping at '{' or space). When the prelude starts with '-global-' it deletes that prefix so the name stays global; otherwise, unless the at-rule is nested inside a :global block, it prepends the component hash as a scoping prefix. It then returns without recursing, so keyframes contents are untouched. Non-keyframes at-rules just continue the walk via next().

calls: [is_keyframes_node](r4-compiler-model.md#u-8dc3955e3495), [packages/svelte/src/compiler/phases/3-transform/css/index.js:is_in_global_block](r5-css-transform.md#u-104caee60cc4)

<a id="u-2ad602047704"></a>
### `packages/svelte/src/compiler/phases/3-transform/css/index.js:ComplexSelector`

`ComplexSelector(node, context)` · [packages/svelte/src/compiler/phases/3-transform/css/index.js:L283-L372][f1]

Applies scoping edits to one complex selector.

Saves specificity.bumped, then iterates relative selectors. Global selectors (:global / :global without args) have their pseudo-class removed via remove_global_pseudo_class (with combinator handling); when the selector sits in a parent rule and has no args, a '&' is prepended for cases like 'div { :global.x {...} }' becoming '&.x', and a trailing comma before the next used selector is deleted (only when the list has multiple children and this selector is second-to-last by index arithmetic). Non-global selectors are checked for mid-compound 'global' pseudo-classes, which are also removed. For scoped relative selectors — skipping standalone :is/:where selectors and any selector containing a NestingSelector — a scoping modifier is inserted: the first occurrence uses the plain class (state.selector); afterwards ':where(class)' so specificity is not raised further; bumped is set true. The modifier is appended after the first non-pseudo (non-root/host) selector's end, replaces a '*' TypeSelector, or is prepended before a leading pseudo-element/class. After context.next(), bumped is restored to its entry value.

calls: [remove_global_pseudo_class](r5-css-transform.md#u-d582bf731db0)

**Uncertainties.**

- The comma-deletion condition 'node.children.length === findIndex(...) - 1' encodes a positional rule whose full intent was inferred from the comment, not proven.
- If no selector in a scoped relative selector qualifies for insertion (loop exits without break), no scoping class is added — whether that can occur is not shown.

<a id="u-72124d453ad4"></a>
### `Declaration`

`Declaration(node, { state })` · [packages/svelte/src/compiler/phases/3-transform/css/index.js:L100-L137][f1]

Transforms CSS declarations.

After normalizing the property via remove_css_prefix and lowercasing: for 'animation' or 'animation-name' it scans the original source from the value start, accumulating identifier characters; whenever a CSS name-boundary character is hit, if the accumulated name is a component keyframe it prepends the hash prefix to that name; scanning stops early on ';' or '}'. Otherwise, only when state.minify is set, it removes whitespace before the declaration, and additionally collapses whitespace after the colon — except for custom properties (--foo), because some Chromium versions treat '--foo: ;' and '--foo:;' differently.

calls: [remove_css_prefix](r4-compiler-model.md#u-e3a939a3b9f2), [remove_preceding_whitespace](r5-css-transform.md#u-de1c1b6a47fb)

<a id="u-f014322fd2ad"></a>
### `packages/svelte/src/compiler/phases/3-transform/css/index.js:PseudoClassSelector`

`PseudoClassSelector(node, context)` · [packages/svelte/src/compiler/phases/3-transform/css/index.js:L373-L377][f1]

Allows the walk to descend only into :is, :where, :has, and :not pseudo-class selectors; all other pseudo-class selectors stop recursion by not calling context.next().

<a id="u-b57c2c0ef514"></a>
### `packages/svelte/src/compiler/phases/3-transform/css/index.js:Rule`

`Rule(node, { state, next, visit, path })` · [packages/svelte/src/compiler/phases/3-transform/css/index.js:L138-L197][f1]

Decides whether a CSS rule survives and how.

When minifying, whitespace before '{' and after '}' is removed. An empty rule (per is_empty, given global-block context) is kept in dev but otherwise removed (minify) or commented out with '(empty)' using escape_comment_close, and not recursed into. An unused rule not inside a :global block is likewise removed or commented out as '(unused)'. For a global block whose prelude is exactly one selector with one complex selector containing one selector ('{ :global {...} }'), the prelude and braces are commented out (or removed when minifying) and only the block body is visited, so the :global wrapper is dropped. All other rules continue via next().

calls: [is_empty](r5-css-transform.md#u-850d391518fa), [is_used](r5-css-transform.md#u-b3b67c9d0361), [escape_comment_close](r5-css-transform.md#u-8e64579cb2b1)

**Uncertainties.**

- Specific MagicString removal/comment offsets were read from the loops and literals but not executed.

<a id="u-d592a4a39c2c"></a>
### `SelectorList`

`SelectorList(node, { state, next, path })` · [packages/svelte/src/compiler/phases/3-transform/css/index.js:L198-L282][f1]

Prunes unused selectors from a selector list and manages specificity-bump state.

Commenting/pruning is skipped entirely when inside a global block — unless this list is the multi-selector prelude of a global-block rule — and when any ancestor ComplexSelector is itself unused. It then walks the child selectors toggling a 'pruning' state whenever selector.metadata.used differs: at prune starts it inserts '/* (unused) ' (minify: record the start position); at prune ends it locates the preceding comma backwards and appends '*/' or removes through the comma (minify), adjusting for whether a used selector preceded. A trailing prune range is closed at the last selector's end. After pruning, it computes the specificity state: inside a Rule a fresh {bumped:false} is used unless an ancestor rule (via metadata.parent_rule chain) has local selectors, in which case bumped:true; outside a Rule the incoming state is kept. Continues with the updated state via next({...state, specificity}).

**Uncertainties.**

- The comma search scans backwards for ',' without a bound; behavior on a malformed prelude is unspecified in this code.

<a id="u-8e64579cb2b1"></a>
### `escape_comment_close`

`function escape_comment_close(node, code)` · [packages/svelte/src/compiler/phases/3-transform/css/index.js:L458-L479][f1]

Escapes '*/' sequences inside a rule's source range so the rule can safely be wrapped in '/* ...

*/' comments. It tracks string escapes (backslash skips the next char) and CSS comment nesting: inside a comment, a '*/' gets a backslash prepended (comment closed); outside, '/*' opens comment tracking.

<a id="u-850d391518fa"></a>
### `is_empty`

`function is_empty(rule, is_in_global_block)` · [packages/svelte/src/compiler/phases/3-transform/css/index.js:L424-L446][f1]

Determines whether a rule produces no output.

A global block is empty only when its block has no children. Otherwise: any Declaration child makes it non-empty; a Rule child is non-empty only if it is used (or the rule lies in a global block) and recursively non-empty — so nested empty/unused rules count as empty; an Atrule child makes it non-empty when its block is null or has children. Returns true when no such child exists.

<a id="u-104caee60cc4"></a>
### `packages/svelte/src/compiler/phases/3-transform/css/index.js:is_in_global_block`

`function is_in_global_block(path)` · [packages/svelte/src/compiler/phases/3-transform/css/index.js:L383-L385][f1]

Returns true when any node on the visitor path is a Rule flagged metadata.is_global_block, i.e. the current position is inside a :global {...} block.

<a id="u-b3b67c9d0361"></a>
### `is_used`

`function is_used(rule)` · [packages/svelte/src/compiler/phases/3-transform/css/index.js:L449-L451][f1]

A rule is used when any selector in its prelude has metadata.used set to a truthy value.

<a id="u-d582bf731db0"></a>
### `remove_global_pseudo_class`

`function remove_global_pseudo_class(selector, combinator, state)` · [packages/svelte/src/compiler/phases/3-transform/css/index.js:L392-L407][f1]

Erases a ':global' pseudo-class from the output.

With no args: the start position is moved back over preceding whitespace when the combinator is a descendant combinator (so 'div :global.x' becomes 'div.x'), then update() blanks the ':global' text — update rather than remove, per the comment, because a closing unused-comment may already occupy that range. With args (:global(...)), it removes the ':global(' prefix and the closing ')'.

**Notes.**

- side_effect: Mutates the shared MagicString in state.code; edits are order-sensitive relative to SelectorList/Rule commenting.

<a id="u-de1c1b6a47fb"></a>
### `remove_preceding_whitespace`

`function remove_preceding_whitespace(end, state)` · [packages/svelte/src/compiler/phases/3-transform/css/index.js:L414-L418][f1]

Scans backwards from 'end' over whitespace in the original source and removes that whitespace range from the MagicString; no-op when the character before 'end' is not whitespace.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/css/index.js
