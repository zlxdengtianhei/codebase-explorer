# Compiler Pipeline

**Capability.** Owns the staged compilation of .svelte sources into client or server JavaScript: parsing support, semantic analysis (runes, scopes, CSS, a11y metadata, warnings), migration of legacy code, the two transform phases, and the shared semantic model (scopes/bindings/AST types), options validation, error machinery and sourcemap-integrity preprocessing they rely on.

Follow parse → analyze → transform to see source become output; the shared model and utility subtrees feed the analysis and transform phases. Use the diagnostics-message codegen child to understand the generated warning/thrower functions rather than hand-written ones. Legacy compiler type declarations here are documentation-only.

**Children.**

- [Diagnostic Message Codegen](diagnostics-codegen.md) `diagnostics-codegen` · 0 unit(s)

**Depends on.**

- [Diagnostic Message Codegen](diagnostics-codegen.md) · containment · → 0 / ← 0 edge(s) (ancestor direct units and descendant subtree; → follows ` compiler-pipeline ` → ` diagnostics-codegen `) · Compile warnings and thrown errors are generated from the diagnostics-codegen message templates.
- [Shared Runtime Utilities](shared-runtime.md) · model-inferred · 0 edge(s) · Parse, analyze and transform phases use shared constants and predicates such as void/boolean element tables from shared-runtime.

**Depended on by.**

- [Client Runtime](client-runtime.md) · model-inferred · 0 edge(s) · The client runtime executes the runtime calls that the compiler's client transform emits.
- [Public Type Declarations](public-types.md) · model-inferred · 0 edge(s)
- [Build & Repo Tooling](repo-tooling.md) · model-inferred · 0 edge(s)
- [Server Runtime](server-runtime.md) · model-inferred · 0 edge(s)
- [Shared Runtime Utilities](shared-runtime.md) · model-inferred · 0 edge(s)

Parent: [Svelte Monorepo](svelte-monorepo.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
