# Deep Reactivity Proxies

**Capability.** Wraps state objects/arrays in reactive Proxies with dev tracing labels, unwraps proxies to underlying values, provides proxy-aware equality, and defers inspect effects around array-mutating methods.

Use this subtree to understand deep `$state` proxying. get_proxied_value/is back the dev equality helpers, and the inspectable-array wrapper coordinates with the sources subtree's inspect-effect registry.

**Depends on.**

- [Dev-Mode Diagnostics](r3-runtime-dev-tools.md) · graph-confirmed · 9 edge(s)
- [Signal Sources](r3-runtime-reactivity-sources.md) · graph-confirmed · 13 edge(s)

**Depended on by.**

- [Signal Sources](r3-runtime-reactivity-sources.md) · graph-confirmed · 1 edge(s) · Signal writes call the proxy layer to wrap written values in deep-reactive proxies.

Parent: [Client Runtime Internals](r3-runtime.md)

## Units (5)

<a id="u-6e64c72c9fe9"></a>
### `proxy`

`export function proxy(value)` · [packages/svelte/src/internal/client/proxy.js:L39-L64][f1]

Wraps a state object or array in a reactive Proxy.

Values that are not objects, already carry STATE_SYMBOL, or have a prototype other than Object/Array are returned unchanged. Per-property Source signals are lazily created in a Map and a version source tracks structural changes; reading via get subscribes, set/delete/defineProperty notify. In dev with tracing, sources are tagged with labels and a creation stack is captured.

**Notes.**

- condition: with_parent runs nested work under the proxy's original update_version with active_reaction nulled, so child sources created later are not bound to whatever reaction is currently active.
- failure: defineProperty throws via e.state_descriptors_fixed for any descriptor lacking 'value' or marked non-configurable/non-enumerable/non-writable, to respect Proxy invariants; setPrototypeOf always throws e.state_prototype_fixed.
- condition: get only auto-creates a source for own writable (or newly added) properties; prototype access falls through to Reflect.get untracked, and UNINITIALIZED reads surface as undefined.
- condition: set: array 'length' assignment unsets sources for indexes >= the new length (creating UNINITIALIZED sources where the target still has items); a new integer index >= current length bumps the length source; the descriptor setter on the target is invoked before signaling; increment(version) fires only when the property was previously absent.
- condition: ownKeys tracks the version source, filters keys whose source is UNINITIALIZED, and appends source keys not present on the target.
- contract: has returns true for STATE_SYMBOL, creates/tracks a source when an active_effect exists, and reports false for UNINITIALIZED values.

calls: [tracing.js-tagging](r3-runtime-dev-tools.md#u-76249388f24e), [get_stack](r3-runtime-dev-tools.md#u-507749353e33), [source](r3-runtime-reactivity-sources.md#u-97497b70f31b), [packages/svelte/src/internal/client/reactivity/sources.js:set](r3-runtime-reactivity-sources.md#u-452914169f68), [increment](r3-runtime-reactivity-sources.md#u-8fa6038c59d8)

**Uncertainties.**

- The exact reactive semantics of source/get/set/increment live in reactivity/sources.js and are not shown here, so propagation behavior is inferred from names and call sites only.
- The target object is never mutated by handlers except that arrays keep their original items; how state forking relies on this is not provable from this file.

<a id="u-0468b533d5f3"></a>
### `get_proxied_value`

`export function get_proxied_value(value)` · [packages/svelte/src/internal/client/proxy.js:L368-L384][f1]

Unwraps a $state proxy to its underlying value.

If the value is a non-null object holding STATE_SYMBOL, its raw target is returned; otherwise the value is returned as is. The 'in' check is wrapped in try/catch because it throws for cross-origin iframe contentWindow values, which are then returned untouched to avoid breaking payment-library style interactions.

uses: [is](r3-runtime-proxy.md#u-dcae92a399e9)

<a id="u-dcae92a399e9"></a>
### `is`

`export function is(a, b)` · [packages/svelte/src/internal/client/proxy.js:L390-L392][f1]

Equality helper applying Object.is after unwrapping both arguments with get_proxied_value, so a proxy and its raw target compare equal.

<a id="u-51040fd3e0a9"></a>
### `get_label`

`function get_label(path, prop)` · [packages/svelte/src/internal/client/proxy.js:L359-L363][f1]

Builds a dev tracing label for a property path.

Symbols render as path[Symbol(desc)], valid identifiers as path.prop, all-digit strings as path[index], and other strings as path['prop'].

<a id="u-11dd40ae58ef"></a>
### `proxy.js-inspectable-array`

`function inspectable_array(array)` · [packages/svelte/src/internal/client/proxy.js:L411-L413][f1]

Dev-only wrapper (used when proxy() wraps an array) that defers inspect effects around array-mutating methods.

Its get trap returns normal property reads unchanged, but for the nine mutating methods (copyWithin, fill, pop, push, reverse, shift, sort, splice, unshift) it returns a function that marks inspect effects deferred, applies the mutation, then flushes inspect effects once — so $inspect fires a single time and never logs an intermediate array state.

calls: [flush_inspect_effects](r3-runtime-reactivity-sources.md#u-8313e354c312), [sources.js-inspect-effect-toggle](r3-runtime-reactivity-sources.md#u-c20696ab63af)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/proxy.js
