# SSR Rendering Helpers

**Capability.** The server-side implementations of compiled constructs: render entry, elements and attributes, await/each/slot handling, store interop, props/spread merging, head output, and hydration uid markers.

Use this to trace any $. helper emitted by the server transform. render() orchestrates a component render; store helpers emulate subscriptions for one render pass; helpers sanitize props/slots and produce attribute strings.

**Depends on.**

- [DOM & Rune Constant Predicates](r1-dom-dom-utils.md) · graph-confirmed · 3 edge(s)
- [SSR Dev Validation](r1-ssr-dev.md) · graph-confirmed · 1 edge(s)

Parent: [Server Runtime](r1-runtime-server.md)

## Units (29)

<a id="u-ead9aba750b3"></a>
### `render`

`export function render(component, options = {})` · [packages/svelte/src/internal/server/index.js:L69-L120][f1]

Server-renders a component into head/body HTML strings.

Creates a `Payload` with an optional id prefix, swaps in a fresh `on_destroy` array, wraps output in BLOCK_OPEN/BLOCK_CLOSE hydration comments, and in DEV isolates element-validation state via `reset_elements()`. If `options.context` is given it pushes a component frame and assigns the context Map to it before invoking `component(payload, props, {}, {})`, popping afterwards. After rendering it runs and discards accumulated `on_destroy` callbacks and restores the previous array. Builds `head` from the joined head output plus title plus a `<style id=hash>` per CSS entry, and returns `{ head, html, body }` where html and body are the same joined output. A `finally` block always calls `abort()`, so the shared AbortController is reset even if rendering throws.

**Notes.**

- failure: Exceptions during component execution propagate after the finally runs abort(); on_destroy callbacks are not run in the failure path.

calls: [packages/svelte/src/internal/server/context.js:push](r2-server-runtime.md#u-38e06b351976), [packages/svelte/src/internal/server/context.js:pop](r2-server-runtime.md#u-b3ad8cba6058), [reset_elements](r1-ssr-dev.md#u-cc2fd0cc577f), [abort](r2-server-runtime.md#u-9654b4650543); uses: [index.js module code (L1–L34)][f1]

**Uncertainties.**

- Whether `component` being a legacy class component (per the graph edge from legacy-server) interacts with the direct-call signature here is not visible in this file.

<a id="u-3675c4ee24d1"></a>
### `packages/svelte/src/internal/server/index.js:element`

`export function element(payload, tag, attributes_fn = noop, children_fn = noop)` · [packages/svelte/src/internal/server/index.js:L35-L53][f1]

Emits an element with hydration-safe comment delimiters.

Always pushes `<!---->` before and after. If `tag` is truthy it pushes the opening tag, runs `attributes_fn` (which appends attributes into the output), closes the tag, and — only for non-void tags — runs `children_fn`, pushes an `EMPTY_COMMENT` unless the tag is a raw-text element (script/style), and pushes the closing tag. Void tags therefore get no children or closing tag.

calls: [is_void](r1-dom-dom-utils.md#u-9c54e843c710), [is_raw_text_element](r1-dom-dom-utils.md#u-8ee9370d0cd9)

<a id="u-74e3fe2fb372"></a>
### `packages/svelte/src/internal/server/index.js:head`

`export function head(payload, fn)` · [packages/svelte/src/internal/server/index.js:L127-L132][f1]

Renders extra `<head>` content by wrapping a callback's output between BLOCK_OPEN/BLOCK_CLOSE comment markers in `payload.head.out`.

The callback receives the head payload and appends via its own calls; no validation of the callback occurs.

<a id="u-fbc5df6dd0a5"></a>
### `packages/svelte/src/internal/server/index.js:css_props`

`export function css_props(payload, is_html, props, component, dynamic = false)` · [packages/svelte/src/internal/server/index.js:L142-L162][f1]

Emits a wrapper element carrying CSS custom-property styles around a component's output.

Converts `props` via `style_object_to_string`; uses `<svelte-css-wrapper style="display: contents; ...">` for HTML or `<g style="...">` for SVG, optionally pushes an `<!---->` marker when `dynamic`, runs `component()`, then pushes the matching closing comment-plus-tag. The wrapper structure must match what the client hydration expects.

calls: [style_object_to_string](r1-ssr-core.md#u-5168ebd4b162)

<a id="u-a9cb571edc90"></a>
### `attr_class`

`export function attr_class(value, hash, directives)` · [packages/svelte/src/internal/server/index.js:L253-L256][f1]

Builds a ` class="..."` attribute fragment.

Delegates merging to `to_class(value, hash, directives)`; returns the empty string when the merged result is falsy, otherwise returns the escaped attribute text (values HTML-escaped).

calls: [to_class](r4-shared-runtime.md#u-bb0adfe2b192)

<a id="u-1a3f35d1ee98"></a>
### `attr_style`

`export function attr_style(value, directives)` · [packages/svelte/src/internal/server/index.js:L262-L265][f1]

Builds a ` style="..."` attribute fragment.

Delegates to `to_style(value, directives)`; returns '' for an empty result, otherwise the HTML-escaped attribute text.

calls: [to_style](r4-shared-runtime.md#u-50b25ac26373)

<a id="u-809bef1eecf5"></a>
### `spread_attributes`

`export function spread_attributes(attrs, css_hash, classes, styles, flags = 0)` · [packages/svelte/src/internal/server/index.js:L172-L207][f1]

Serializes a props object into an attribute string.

First merges `styles` into `attrs.style` via `to_style`, normalizes `attrs.class` with `clsx`, and if a css hash or class directives exist rewrites `class` via `to_class`. Flags control output: without ELEMENT_IS_NAMESPACED names are treated as HTML (boolean attributes rendered accordingly), and without ELEMENT_PRESERVE_ATTRIBUTE_CASE names are lowercased. Per entry it skips function values, `$$`-prefixed internal keys, and names matching INVALID_ATTR_NAME_CHAR_REGEX (whitespace, quotes, `/`, `=`, and Unicode noncharacters), then appends `attr(name, value, ...)`. Note it mutates the caller's `attrs` object for style/class.

**Notes.**

- side_effect: Writes `attrs.style` and `attrs.class` back onto the passed-in object.

calls: [attr](r4-shared-runtime.md#u-12a88532ea06), [to_class](r4-shared-runtime.md#u-bb0adfe2b192), [to_style](r4-shared-runtime.md#u-50b25ac26373), [clsx](r4-shared-runtime.md#u-2274c46486ff)

<a id="u-1d4fa3ac5094"></a>
### `packages/svelte/src/internal/server/index.js:stringify`

`export function stringify(value)` · [packages/svelte/src/internal/server/index.js:L236-L238][f1]

Converts a value for attribute/text output: strings pass through unchanged, null/undefined become the empty string, everything else is stringified with `value + ''` (so numbers, booleans, objects via toString).

<a id="u-5168ebd4b162"></a>
### `style_object_to_string`

`function style_object_to_string(style_object)` · [packages/svelte/src/internal/server/index.js:L241-L246][f1]

Serializes a style object to an inline-style string: drops entries whose value is null or empty string, formats the rest as `key: value;` joined by single spaces, and HTML-escapes each value (`escape_html(v, true)`).

Keys are not escaped.

calls: [escape_html](r5-shared-lib.md#u-0f499dd45547)

<a id="u-1a337df4b94c"></a>
### `packages/svelte/src/internal/server/index.js:await_block`

`function await_block(payload, promise, pending_fn, then_fn)` · [packages/svelte/src/internal/server/index.js:L443-L454][f1]

Server-side await block: promises render only the pending branch since resolution never happens during SSR.

If `is_promise(promise)`: pushes BLOCK_OPEN, attaches `promise.then(null, noop)` to swallow rejections (preventing unhandled rejection), and runs `pending_fn` when non-null. Otherwise (a plain value) it pushes BLOCK_OPEN_ELSE and runs `then_fn(promise)` when non-null. Exactly one branch emits markers; if both callbacks are null only markers appear.

calls: [is_promise](r5-internal-shared-utils.md#u-f3295568a063)

**Uncertainties.**

- Whether swallowing rejections via then(null, noop) can mask legitimate errors is a deliberate server trade-off, not further specified here.

<a id="u-01a3113f1c5f"></a>
### `ensure_array_like`

`export function ensure_array_like(array_like_or_iterator)` · [packages/svelte/src/internal/server/index.js:L459-L466][f1]

Normalizes each-block sources: falsy input yields `[]`; values with a numeric `length` property pass through unchanged (arrays, strings); anything else is materialized with `Array.from` (iterators, Set/Map, generators).

<a id="u-c8b85b1bb23a"></a>
### `packages/svelte/src/internal/server/index.js:slot`

`export function slot(payload, $$props, name, slot_props, fallback_fn)` · [packages/svelte/src/internal/server/index.js:L361-L373][f1]

Renders a slot or snippet with legacy/prop interop.

Looks up `$$props.$$slots?.[name]`; if the slot is `true` (snippets filling slots) it substitutes `$$props.children` for the default slot or `$$props[name]` otherwise. If a slot function exists it is invoked as `slot_fn(payload, slot_props)`; otherwise the optional `fallback_fn` runs. When neither exists nothing is emitted.

<a id="u-4abf93ac9587"></a>
### `sanitize_props`

`export function sanitize_props(props)` · [packages/svelte/src/internal/server/index.js:L396-L399][f1]

Strips `children` and `$$slots` from a props object via destructuring rest and returns the remaining props; the input object is not mutated.

<a id="u-5e5630e14f22"></a>
### `packages/svelte/src/internal/server/index.js:sanitize_slots`

`export function sanitize_slots(props)` · [packages/svelte/src/internal/server/index.js:L405-L413][f1]

Computes which slots are available: returns an object marking `default` true when `props.children` is truthy, plus a true entry for each key in `props.$$slots`.

Assumes `props.$$slots` is iterable via for-in; absent yields only the default entry.

<a id="u-fa79149bdee0"></a>
### `packages/svelte/src/internal/server/index.js:rest_props`

`export function rest_props(props, rest)` · [packages/svelte/src/internal/server/index.js:L380-L390][f1]

Builds a new object containing all own enumerable keys of `props` except those listed in `rest`.

Enumeration is via for-in, so inherited enumerable keys would be included; no descriptor copying is done here (plain value assignment).

**Uncertainties.**

- for-in includes inherited enumerable properties; whether prototype pollution of props matters is not guarded.

<a id="u-82b1ac47166e"></a>
### `packages/svelte/src/internal/server/index.js:spread_props`

`export function spread_props(props)` · [packages/svelte/src/internal/server/index.js:L213-L230][f1]

Merges an array of prop objects left-to-right into a new object, later objects overwriting earlier keys.

For each key it copies the source property descriptor when one exists (preserving getters/setters via Object.defineProperty) and falls back to a plain value assignment otherwise. Returns the merged object; inputs are not mutated.

**Uncertainties.**

- If a descriptor exists but defineProperty fails (e.g. non-configurable conflict), the exception propagates; not guarded.

<a id="u-f2ea71698e42"></a>
### `bind_props`

`export function bind_props(props_parent, props_now)` · [packages/svelte/src/internal/server/index.js:L421-L433][f1]

Legacy binding propagation: for each key in `props_now`, if the parent's initial value is undefined, the current value is defined, and the parent property has a setter (checked via Object.getOwnPropertyDescriptor), it writes the current value back into `props_parent`.

Thus fallback values flow upward only for accessor-backed props that were never set.

**Notes.**

- condition: All three conditions (undefined initial, defined new, parent setter exists) must hold; otherwise no write occurs.

<a id="u-5975ccb1491b"></a>
### `packages/svelte/src/internal/server/index.js:store_get`

`export function store_get(store_values, store_name, store)` · [packages/svelte/src/internal/server/index.js:L274-L293][f1]

Subscribes to a store for the duration of a server render and returns its current value.

In DEV it first validates the store via `validate_store`. The `store_values` record caches `[store, unsubscribe, value]` per compiled store name: if the cached entry is for the same store it returns the cached value immediately (supporting eager updates in the instance script). If the store was switched, it calls the old entry's unsubscribe, then subscribes via `subscribe_to_store`, storing the new unsubscribe and updating the cached value on each emission. Returns the latest known value at call time.

**Notes.**

- side_effect: Mutates `store_values`, replacing the entry for the store name; old subscriptions are torn down when the store changes.

calls: [subscribe_to_store](r2-stores.md#u-863f9153e183), [validate_store](r4-shared-runtime.md#u-f09c2e0aa53c)

<a id="u-809be478aa47"></a>
### `packages/svelte/src/internal/server/index.js:store_set`

`export function store_set(store, value)` · [packages/svelte/src/internal/server/index.js:L302-L305][f1]

Sets a store's value via `store.set(value)` and returns that value, enabling `{$store = x}` style compiled assignments.

<a id="u-7d1dd4a2a3e6"></a>
### `packages/svelte/src/internal/server/index.js:store_mutate`

`export function store_mutate(store_values, store_name, store, expression)` · [packages/svelte/src/internal/server/index.js:L315-L318][f1]

Implements compiled `store = store <op> x` assignments: re-reads the current value through `store_get` (ensuring a live subscription), sets it back via `store_set`, and returns the `expression` result for the compiled statement.

calls: [packages/svelte/src/internal/server/index.js:store_get](r1-ssr-core.md#u-5975ccb1491b), [packages/svelte/src/internal/server/index.js:store_set](r1-ssr-core.md#u-809be478aa47)

<a id="u-4157e614850a"></a>
### `packages/svelte/src/internal/server/index.js:update_store`

`export function update_store(store_values, store_name, store, d = 1)` · [packages/svelte/src/internal/server/index.js:L327-L331][f1]

Post-increment/decrement for stores: reads the current value via `store_get`, sets the store to `value + d` (d defaults to 1), and returns the pre-update value, matching `store++` semantics.

calls: [packages/svelte/src/internal/server/index.js:store_get](r1-ssr-core.md#u-5975ccb1491b)

<a id="u-7a134f57bf18"></a>
### `update_store_pre`

`export function update_store_pre(store_values, store_name, store, d = 1)` · [packages/svelte/src/internal/server/index.js:L340-L344][f1]

Pre-increment/decrement for stores: computes `store_get(...) + d` (d defaults to 1), sets the store to the result, and returns the new value, matching `++store` semantics.

calls: [packages/svelte/src/internal/server/index.js:store_get](r1-ssr-core.md#u-5975ccb1491b)

<a id="u-60498de8c911"></a>
### `unsubscribe_stores`

`export function unsubscribe_stores(store_values)` · [packages/svelte/src/internal/server/index.js:L347-L351][f1]

Tears down all store subscriptions at the end of a render by calling the stored unsubscribe function (`[1]`) for every entry in `store_values`.

Assumes every entry has a callable unsubscribe; entries created by `store_get` satisfy this.

<a id="u-7bb944bfaa2a"></a>
### `packages/svelte/src/internal/server/index.js:derived`

`export function derived(fn)` · [packages/svelte/src/internal/server/index.js:L532-L546][f1]

Server-safe stand-in for derived stores/signals, built on `once`.

Returns a function used both as getter and setter: with no arguments it returns the last explicitly set value if any (`updated_value ?? get_value()`), otherwise the lazily computed and memoized value of `fn`; with an argument it stores and returns `new_value`, which then shadows the computed value. Because of `??`, an explicitly set value of null/undefined is ignored on reads and the computed value is returned instead.

calls: [packages/svelte/src/internal/server/index.js:once](r1-ssr-core.md#u-a5b0cc827a44)

**Uncertainties.**

- Falsy-but-meaningful set values other than null/undefined work; only null/undefined are shadowed by the fallback, per the `??` semantics.

<a id="u-a5b0cc827a44"></a>
### `packages/svelte/src/internal/server/index.js:once`

`export function once(get_value)` · [packages/svelte/src/internal/server/index.js:L481-L489][f1]

Memoizes a getter as a zero-arg function using a sentinel: the first call stores `get_value()` (initially UNINITIALIZED) and all later calls return the cached value without re-invoking.

If the underlying value legitimately equals the UNINITIALIZED sentinel, it would be recomputed each call — an edge inherent to the sentinel check.

**Uncertainties.**

- No guard if get_value throws; the value stays uninitialized and the next call retries.

<a id="u-7e5028a0fda0"></a>
### `packages/svelte/src/internal/server/index.js:inspect`

`export function inspect(args, inspect = console.log)` · [packages/svelte/src/internal/server/index.js:L473-L475][f1]

Compiled `{@inspect ...}` for SSR: calls the inspector (default `console.log`) once with the string 'init' followed by the inspected args at component initialization; no reactive updates occur on the server.

**Notes.**

- side_effect: Default inspector writes to console.log.

<a id="u-2eb01f29fdab"></a>
### `packages/svelte/src/internal/server/index.js:props_id`

`export function props_id(payload)` · [packages/svelte/src/internal/server/index.js:L496-L500][f1]

Generates a unique id from the payload's `uid()` generator, pushes an HTML comment marker `<!--#uid-->` into `payload.out` (used for hydration alignment of props), and returns the uid.

<a id="u-2c8b13b9bc4e"></a>
### `maybe_selected`

`export function maybe_selected(payload, value)` · [packages/svelte/src/internal/server/index.js:L553-L555][f1]

Returns the string ' selected' when `value` strictly equals `payload.select_value`, otherwise the empty string; used to mark the selected `<option>` during SSR.

<a id="u-8a42e56302a7"></a>
### `valueless_option`

`export function valueless_option(payload, children)` · [packages/svelte/src/internal/server/index.js:L562-L576][f1]

Renders a `<option>` without a value attribute but selects it if its rendered content matches the current select value.

Records the current output length, runs `children()`, joins the newly pushed fragments, and strips `<!---->` markers for comparison against `payload.select_value`. On a match it rewrites the previously pushed opening-tag fragment by replacing its trailing `>` with ` selected>` and compacts the child fragments into a single entry (splice), so the option is emitted pre-selected and the closing tag added later remains intact. When the body does not match, output is untouched.

**Notes.**

- side_effect: Mutates payload.out in place (index rewrite plus splice) only when the content matches select_value.

**Uncertainties.**

- Assumes payload.out[i-1] is the option's opening tag ending in '>'; other compiler output shapes would corrupt the fragment.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/server/index.js
