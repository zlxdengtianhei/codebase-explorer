# Reactivity benchmarks

**Capability.** Owns performance measurement harnesses for the client reactivity system: signal/derived creation throughput and derived-graph update costs (diamond and unstable-dependency patterns), driving internals directly from source.

Run these to detect reactivity regressions. Each benchmark isolates one graph shape; all consume the same client internals measured by client-reactivity. Uncertainty: harness execution details beyond the timing loops are not captured in the units.

**Depends on.**

- [Reactivity core \(signals and deriveds\)](r2-client-reactivity.md) · model-inferred · 0 edge(s)
- [Benchmark Harness](r4-benchmark-harness.md) · graph-only · 19 edge(s)

Parent: [Svelte compiler and runtime](r2-svelte.md)

## Units (3)

<a id="u-b3d162a91824"></a>
### `kairo-diamond-js-benchmark-suite`

`function setup()` · [benchmarking/benchmarks/reactivity/kairo/kairo_diamond.js:L6-L30][f1]

Times a diamond dependency graph: width=5 deriveds each read one head signal, a sum derived aggregates them, and one render effect tracks sum.

setup() builds head, five head+1 deriveds, sum = mapped reduce, and a render_effect incrementing counter while reading sum. run() sets head to 1 under flush, asserts sum === 2*width, resets counter, then 500 times sets head to i and asserts sum === (i+1)*width; the effect should run exactly 500 times despite five dependents of head. kairo_diamond_unowned performs 10 warmup setup/run/destroy cycles then times 10 batches of 1000 run() calls with fastest_test, destroying afterwards and returning benchmark name with 2-decimal time and gc_time. kairo_diamond_owned wraps warmup and the timed instance in one effect_root, times identically, then invokes both destroy and destroy_owned. Assertion failures propagate out of run().

calls: [fastest_test](r4-benchmark-harness.md#u-0bbe8c671495), [assert](r4-benchmark-harness.md#u-823bd0dd0cd8)

<a id="u-a74391ccc888"></a>
### `kairo-unstable-js-benchmark-suite`

`function setup()` · [benchmarking/benchmarks/reactivity/kairo/kairo_unstable.js:L4-L27][f2]

Times a derived whose input choice changes at runtime (unstable dependency): 20 loop reads pick double (head*2) when head is odd, otherwise inverse (-head).

setup() creates head, double, inverse, current aggregating 20 picks, and a counter render effect reading current. run() sets head to 1 and asserts current === 40 (odd path, 20*2), resets counter, then 100 times sets head to i without per-iteration value assertions, finally asserting counter === 100, i.e. the effect re-ran each time even when only the chosen-branch signal changed. kairo_unstable_unowned does 10 warmup setup/run/destroy cycles, times 10 batches of 1000 run() calls via fastest_test, destroys, and returns the benchmark name with 2-decimal time and gc_time. kairo_unstable_owned holds warmup and the timed instance in an effect_root (destroy_owned), times identically, then calls both destroy and destroy_owned. Assertion failures propagate uncaught.

calls: [fastest_test](r4-benchmark-harness.md#u-0bbe8c671495), [assert](r4-benchmark-harness.md#u-823bd0dd0cd8)

<a id="u-a6160c9ce935"></a>
### `sbench-js-sbench-creation-benchmarks`

`function create_data_signals(n, sources)` · [benchmarking/benchmarks/reactivity/sbench.js:L10-L15][f3]

Measures signal and derived creation throughput for several source-to-computation ratios at COUNT=1e5 scale, using the svelte client internals directly from source.

create_data_signals fills an array with n $.state(i) signals. create_computation_* helpers each create one $.derived reading their sources (0, 1, 2, 4 sources, or a 1000-signal sum); create_computations_* drivers loop the appropriate number of times, e.g. 1toN creates N computations per source over n/N sources. bench(fn, count, scount) wires fresh signals into a driver. Each exported async benchmark warms the JIT with 3 bench calls, then times via fastest_test 10 iterations, each doing 10 bench calls; the creation-family benchmarks wrap the timed work in a $.effect_root whose returned destroy is called so created nodes are disposed. All return {benchmark: name, time, gc_time} with times fixed to 2 decimals. sbench_create_signals creates plain data signals only and needs no effect_root. No assertions; failures surface as exceptions from the internals.

calls: [fastest_test](r4-benchmark-harness.md#u-0bbe8c671495)

**Uncertainties.**

- create_computation_* helpers discard the value returned by $.derived; whether disposal requires ownership via effect_root to actually free nodes is internal behavior not shown here.
- create_computations_1to2/4/8/1000 only create computations for the first n/ratio sources, leaving the remaining sources unused, which looks intentional per ratio but is not commented.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/benchmarking/benchmarks/reactivity/kairo/kairo_diamond.js
[f2]: ../../../../../../eval/svelte-be645b4/benchmarking/benchmarks/reactivity/kairo/kairo_unstable.js
[f3]: ../../../../../../eval/svelte-be645b4/benchmarking/benchmarks/reactivity/sbench.js
