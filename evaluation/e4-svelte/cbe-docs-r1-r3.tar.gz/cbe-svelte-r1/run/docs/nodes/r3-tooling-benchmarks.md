# Reactivity Benchmarks & Test Config

**Capability.** Measures the reactivity core: derived-chain and mux/demux benchmark suites with deliberate busy work amplifying recomputation cost, a cross-branch comparison CLI printing bar charts, the shared busy() utility, and the Vitest configuration wiring the 'svelte' alias and test/coverage settings.

Use this subtree when measuring or configuring testing of the repo. The kairo suites consume util.js busy() and exercise the sources/batching layers of the runtime internals; vitest.config.js defines how all tests resolve and run.

**Depends on.**

- [Effect Batching & Scheduling](r3-runtime-reactivity-batching.md) · model-inferred · 0 edge(s)
- [Signal Sources](r3-runtime-reactivity-sources.md) · model-inferred · 0 edge(s)

Parent: [Repository Tooling](r3-tooling.md)

## Units (5)

<a id="u-0d12a4a1de84"></a>
### `busy`

`export function busy()` · [benchmarking/benchmarks/reactivity/kairo/util.js:L1-L6][f1]

Deliberately burns a small amount of CPU by incrementing a local counter 100 times, returning nothing; used inside deriveds and render effects to amplify the measured cost of recomputation so reactivity overhead is distinguishable from noise.

<a id="u-ea7c82325ca8"></a>
### `kairo-avoidable-js-benchmark-suite`

`function setup()` · [benchmarking/benchmarks/reactivity/kairo/kairo_avoidable.js:L5-L22][f2]

Builds a five-level derived-signal chain with deliberate busy work to measure Svelte's reactivity push cost.

setup() creates head state, five deriveds (computed2 forces a recompute marker, computed3 calls busy() as heavy computation), and an effect_root containing a render_effect that reads computed5 and calls busy(); run() sets head to 1 then 1000 more times under $.flush, asserting computed5 === 6 each time (head+i contributes 0 through computed2's constant 0). kairo_avoidable_unowned does 10 JIT warmup setup/run/destroy cycles, then times 10 iterations each running run() 1000 times via fastest_test, destroys, and returns the benchmark name with timing.time and timing.gc_time fixed to 2 decimals. kairo_avoidable_owned wraps all setup/destroy (including warmup and the timed instance) in one $.effect_root so owned by the root, then times identically and calls both destroy and destroy_owned. Assertions propagate thrown errors from run(); no fallback exists.

calls: [fastest_test](r4-benchmark-harness.md#u-0bbe8c671495), [assert](r4-benchmark-harness.md#u-823bd0dd0cd8), [busy](r3-tooling-benchmarks.md#u-0d12a4a1de84)

**Uncertainties.**

- Whether owned vs unowned setups measurably differ is not visible; the structural difference is only effect_root ownership of the timed instance.

<a id="u-c5e52c2b16fe"></a>
### `kairo-mux-js-benchmark-suite`

`function setup()` · [benchmarking/benchmarks/reactivity/kairo/kairo_mux.js:L4-L23][f3]

Times a mux/demux pattern: 100 head signals merged into one derived object, then split back into per-index derived chains, testing selective invalidation.

setup() creates 100 states, a mux derived producing an entries object, 100 splited deriveds (mux[index] then +1), and render effects reading each splited value inside one effect_root. run() does two 10-iteration loops: first sets heads[i] = i and asserts splited[i] === i+1, then sets heads[i] = i*2 and asserts splited[i] === i*2+1, exercising incremental updates of the shared mux. kairo_mux_unowned runs 10 warmup cycles then times 10 batches of 1000 run() calls via fastest_test and returns the benchmark name with time and gc_time at 2 decimals after destroying. kairo_mux_owned keeps warmup and the timed instance inside an effect_root (destroy_owned), times identically, and calls both destroy and destroy_owned. Assertions throw on mismatch.

calls: [fastest_test](r4-benchmark-harness.md#u-0bbe8c671495), [assert](r4-benchmark-harness.md#u-823bd0dd0cd8)

<a id="u-8fce20afc2b5"></a>
### `index.js module code (L1–L100)`

`function char(i)` · [benchmarking/compare/index.js:L101-L103][f4]

CLI that benchmarks the current repo across one or more git branches and prints bar-chart comparisons.

It derives its runner path and results directory from its own URL, wipes and recreates the results directory, collects branch names from argv (skipping '--'-prefixed flags and this file's own path), defaulting to the current branch then 'main' when fewer than two remain. It registers an exit handler that checks out the first branch, then for each branch checks out that branch, forks runner.js, and awaits a message event whose payload is written as JSON to <outdir>/<branch>.json (error on the child rejects the promise). Afterwards it reads all result files, and per benchmark entry and per metric ('time', 'gc_time') computes min/max across branches; if min is nonzero it prints a 20-character bar per branch, bar length scaled by time/max, labeled with a letter via char() and the branch name.

**Notes.**

- side_effect: Mutates the working tree via git checkout per branch and restores branches[0] on process exit.
- condition: Branch defaults: argv branch names only; single branch gets 'main' appended; empty argv uses the current branch name or short SHA.
- failure: A child 'error' event rejects the awaiting promise; non-message failures (e.g. child crash without message) leave the await pending.
- condition: Metric section is suppressed entirely when the minimum time is 0.

uses: [runner.js module code (L1–L10)](r1-benchmarking.md#u-0b0dc218fb67); calls: [index.js module code (L1–L100)](r3-tooling-benchmarks.md#u-8fce20afc2b5)

**Uncertainties.**

- The forked runner's message payload shape is only inferred from how it is serialized and read back here.

<a id="u-cfeb87e5efa3"></a>
### `vitest.config.js module code (L1–L46)`

`module_region` · [vitest.config.js:L1-L46][f5]

Defines the Vitest configuration for the Svelte repository, combining a custom resolution alias for 'svelte' package imports with test discovery and coverage settings.

On import it synchronously reads and parses packages/svelte/package.json; a malformed or missing file throws before config creation. The alias regex /^svelte\/?/ maps bare 'svelte' imports to concrete files: for a matched id, it looks up pkg.exports, treating the id 'undefined' as the root '.' entry and otherwise rewriting 'undefined' inside the id to './' (a workaround noted in a comment). If the exports lookup yields nothing, the resolver returns undefined so default resolution proceeds. Otherwise it resolves an absolute path under packages/svelte, choosing exported.default when the importer path contains '_output/server', else exported.browser falling back to exported.default. The test block scans the repo root, uses the dot reporter, includes only packages/svelte test globs (notably including runtime-browser/test-ssr.ts), excludes default exclusions plus '**/samples/**', and configures v8 coverage with lcov and html reporters over packages/svelte/src, reporting on failure.

**Notes.**

- side_effect: Reads packages/svelte/package.json synchronously at module load.
- failure: A failed read/parse of package.json propagates and prevents config creation; an unmatched exports key is not an error but falls through to default resolution.

imports: [fs](../../catalog.json), [path](../../catalog.json), [vitest/config](../../catalog.json)

**Uncertainties.**

- Exact ids reaching customResolver (beyond the 'undefined' case) depend on the bundler's invocation, not visible here.
- Whether exported.default is always defined for matched ids is not guaranteed by this source; if absent, path.resolve would receive undefined and likely throw at resolution time, but that path is unverified.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/benchmarking/benchmarks/reactivity/kairo/util.js
[f2]: ../../../../../../eval/svelte-be645b4/benchmarking/benchmarks/reactivity/kairo/kairo_avoidable.js
[f3]: ../../../../../../eval/svelte-be645b4/benchmarking/benchmarks/reactivity/kairo/kairo_mux.js
[f4]: ../../../../../../eval/svelte-be645b4/benchmarking/compare/index.js
[f5]: ../../../../../../eval/svelte-be645b4/vitest.config.js
