# Block rendering: slots, components, head

**Capability.** Owns client-side block constructs: rendering named slots with sanitized slot maps, reactively swapping dynamic components, and coordinating <svelte:head> render effects with shared hydration anchors.

Read here for how template-level blocks behave at runtime, including hydration-aware anchor handling. These blocks consume the DOM primitives for node navigation and creation.

**Depends on.**

- [DOM primitives: operations and templates](r2-client-dom-core.md) · graph-confirmed · 6 edge(s)

Parent: [Client runtime](r2-client-runtime.md)

## Units (5)

<a id="u-16ae26a1cb4b"></a>
### `sanitize_slots`

`export function sanitize_slots(props)` · [packages/svelte/src/internal/client/dom/blocks/slot.js:L36-L44][f1]

Builds a map of available slot names from component props: sets sanitized.default to true when props.children is truthy, and marks every key in props.$$slots as true.

Returns the resulting record used to indicate which slots were filled.

<a id="u-0553de12b651"></a>
### `slot`

`export function slot(anchor, $$props, name, slot_props, fallback_fn)` · [packages/svelte/src/internal/client/dom/blocks/slot.js:L10-L30][f1]

Renders a named slot, advancing hydration past the anchor first.

Looks up $$props.$$slots[name]; if it is exactly true (snippet interop), the slot function is taken from $$props.children for the default slot or $$props[name] otherwise, and slot_props are passed as a getter function instead of a plain object. If the slot function is undefined, fallback_fn is invoked with the anchor when non-null; otherwise slot_fn is called with the anchor and the props (or props getter for interop).

**Notes.**

- contract: slot_props are wrapped as () => slot_props only in the snippet-interop case

calls: [hydration.js-state-and-guards](r1-hydration-cursor.md#u-f1b7a30a3c1f); uses: [sanitize_slots](r2-client-dom-blocks.md#u-16ae26a1cb4b)

**Uncertainties.**

- Whether calling slot_fn can throw and how the caller handles that is outside this source

<a id="u-cf4f655ef743"></a>
### `component`

`export function component(node, get_component, render_fn)` · [packages/svelte/src/internal/client/dom/blocks/svelte-component.js:L17-L36][f2]

Swaps a dynamic component reactively inside an EFFECT_TRANSPARENT block, advancing hydration past the anchor first and setting anchor to hydrate_node afterwards.

Each block run compares the previous component with get_component(); if unchanged it returns. When the new component is truthy it creates a pending effect via branch(() => render_fn(target, component)); if should_defer_append() is true, rendering targets a text anchor inside a fresh offscreen DocumentFragment, the current effect is added to current_batch.skipped_effects so it is not torn down by the batch, and commit is scheduled as a batch callback; otherwise commit runs immediately. When the new component is falsy, no effect is created, but the deferred commit still runs. commit pauses the old effect, flushes any offscreen fragment by removing its text anchor and inserting it before the real anchor, and promotes pending_effect.

calls: [hydration.js-state-and-guards](r1-hydration-cursor.md#u-f1b7a30a3c1f), [operations.js-node-navigation](r2-client-dom-core.md#u-a31f01c2fa93), [operations.js-dom-helpers](r2-client-dom-core.md#u-d9a22fc32463), [packages/svelte/src/internal/client/reactivity/effects.js:block](r5-effects-module.md#u-75d755e7c63c), [effects.js-trivial-effect-factories](r5-effects-module.md#u-191f01511fb1), [pause_effect](r5-effects-module.md#u-340d218bcd6f), [component](r2-client-dom-blocks.md#u-cf4f655ef743)

**Uncertainties.**

- Effect of adding an effect to current_batch.skipped_effects depends on batch semantics defined elsewhere

<a id="u-917be05a6f13"></a>
### `head`

`export function head(render_fn)` · [packages/svelte/src/internal/client/dom/blocks/svelte-head.js:L21-L68][f3]

Runs a head render function inside a HEAD_EFFECT block, coordinating shared hydration state across multiple head blocks.

Saves whether it was hydrating and the previous hydrate node; while hydrating it finds or continues from the module-level head_anchor, scanning document.head siblings for a HYDRATION_START comment; if none is found hydration is turned off (framework rendered body but no head), otherwise the hydrate node advances past the marker. When not hydrating, a fresh text anchor is appended to document.head. The block renders render_fn with that anchor; in the finally clause, if it was originally hydrating, hydration is re-enabled, head_anchor is set to the (possibly advanced) hydrate_node so the next head block starts correctly, and the caller's previous hydrate node is restored — ensuring errors inside render_fn still restore hydration state.

**Notes.**

- failure: Exceptions from render_fn propagate after the finally restores hydrating state and head_anchor

calls: [packages/svelte/src/internal/client/reactivity/effects.js:block](r5-effects-module.md#u-75d755e7c63c), [hydration.js-state-and-guards](r1-hydration-cursor.md#u-f1b7a30a3c1f), [operations.js-node-navigation](r2-client-dom-core.md#u-a31f01c2fa93)

**Uncertainties.**

- Whether the scan loop mutating shared head_anchor is safe across concurrent head blocks is only guarded by the finally-restore ordering, not proven

<a id="u-484aa5d18aec"></a>
### `reset_head_anchor`

`export function reset_head_anchor()` · [packages/svelte/src/internal/client/dom/blocks/svelte-head.js:L13-L15][f3]

Clears the module-level head_anchor so the next head block re-scans document.head for its hydration marker instead of resuming from a stale node.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/blocks/slot.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/blocks/svelte-component.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/blocks/svelte-head.js
