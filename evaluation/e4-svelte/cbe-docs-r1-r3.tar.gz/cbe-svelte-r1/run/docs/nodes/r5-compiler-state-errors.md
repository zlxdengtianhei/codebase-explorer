# Compiler State and Errors

**Capability.** Module-level per-compilation state: source locators, warning-suppression stacks, and the generated CompileError machinery for raising positioned errors.

Use to understand offset→location mapping and svelte-ignore suppression. Error classes and throw helpers are generated from the process-messages template.

**Depended on by.**

- [Client Transform Visitors](r5-client-transform-visitors.md) · graph-confirmed · 5 edge(s)

Parent: [Compiler](r5-compiler.md)

## Units (9)

<a id="u-0298dbcfed58"></a>
### `adjust`

`export function adjust(state)` · [packages/svelte/src/compiler/state.js:L122-L136][f1]

Refines compiler state after parsing and basic analysis.

It sets dev, runes, and component_name (defaulting to UNKNOWN_FILENAME) from the given state, and normalizes rootDir backslashes to forward slashes. When a string rootDir is set and the current filename starts with it, the filename is made relative to rootDir by replacing it and stripping a leading slash or backslash. It also clears the ignore state: ignore_stack becomes an empty array and ignore_map is emptied.

**Notes.**

- side_effect: Reassigns dev, runes, component_name, filename, ignore_stack, and clears ignore_map.

**Uncertainties.**

- filename.replace(root_dir, '') replaces the first occurrence anywhere, not necessarily the prefix; a rootDir occurring later in the filename would also be replaced.

<a id="u-468324b42cee"></a>
### `is_ignored`

`export function is_ignored(node, code)` · [packages/svelte/src/compiler/state.js:L93-L95][f1]

Reports whether a runtime warning code is suppressed for a node.

It returns true only when dev is true and the node has an entry in ignore_map whose list contains a set holding the given code; otherwise false, including in non-dev compilations.

<a id="u-b35212eb6968"></a>
### `locate_node`

`export function locate_node(node)` · [packages/svelte/src/compiler/state.js:L54-L57][f1]

Builds a human-readable location string for a node's start offset: it queries the current locator for node.start and returns 'filename:line:column', sanitizing the filename via sanitize_location.

If the locator returns undefined for the offset, the line/column render as 'undefined:undefined' via template interpolation.

calls: [sanitize_location](r1-dom-dom-utils.md#u-eb8e19f29107)

**Uncertainties.**

- Behavior when node.start is undefined or outside the current source is unguarded in the visible code.

<a id="u-0d9f0b886c2d"></a>
### `reset`

`export function reset(state)` · [packages/svelte/src/compiler/state.js:L101-L110][f1]

Resets all module-level compiler state before a compilation.

It sets dev and runes to false, component_name to UNKNOWN_FILENAME, source to '', locator to a function returning undefined, warnings to an empty array, warning_filter to the provided filter or a pass-through (() => true), and filename to the provided filename or UNKNOWN_FILENAME with backslashes converted to forward slashes.

**Notes.**

- side_effect: Reassigns every module-level state export.

<a id="u-cdd07af3c7f6"></a>
### `set_source`

`export function set_source(value)` · [packages/svelte/src/compiler/state.js:L46-L49][f1]

Stores the given source string in module state and rebuilds the locate-character locator for it with offsetLine 1, so subsequent locate_node calls map character offsets to positions in this source.

**Notes.**

- side_effect: Reassigns the module-level source and locator exports.

<a id="u-acb70c3ca854"></a>
### `state-js-ignore-stack`

`export function push_ignore(ignores)` · [packages/svelte/src/compiler/state.js:L79-L82][f1]

Maintains the stack of currently active warning-code suppression sets.

push_ignore creates a new Set that unions the current top of the stack (or an empty set when the stack is empty) with the given ignores and pushes it, so nested scopes inherit outer ignora. pop_ignore removes the top set; popping an empty stack leaves it empty.

**Notes.**

- side_effect: Mutates the module-level ignore_stack array.

<a id="u-3993d4129502"></a>
### `compile-errors.js-internal-compile-error`

`class InternalCompileError extends Error` · [packages/svelte/scripts/process-messages/templates/compile-errors.js:L5-L14][f2]

Error subclass representing a Svelte compile error while sharing an object shape with warnings.

The constructor calls super(message), sets a non-enumerable-in-intent empty stack by assignment (with a comment warning against a class property, which would become enumerable), builds a shared CompileDiagnostic(code, message, position), copies its properties onto the instance via Object.assign, and sets name to 'CompileError'. message is declared as an enumerable field so it serializes. toString and toJSON both delegate to the private #diagnostic's corresponding methods, so string/JSON output matches the shared diagnostic rather than the Error base representation.

uses: [e](r5-compiler-state-errors.md#u-1911ece83f7e)

**Uncertainties.**

- CompileDiagnostic's own behavior lives in a file not supplied here; only the delegation is observable.

<a id="u-e8b9aee0a1be"></a>
### `packages/svelte/scripts/process-messages/templates/compile-errors.js:CODE`

`export function CODE(node, PARAMETER)` · [packages/svelte/scripts/process-messages/templates/compile-errors.js:L58-L60][f2]

Template for generated compile-error functions (placeholder 'CODE' is replaced per message by the generator).

After generation each function extracts start/end from its node argument via e() and throws an InternalCompileError carrying the message plus a https://svelte.dev/e/<code> link; its return type is declared `never` because it always throws.

calls: [e](r5-compiler-state-errors.md#u-1911ece83f7e)

<a id="u-1911ece83f7e"></a>
### `e`

`function e(node, code, message)` · [packages/svelte/scripts/process-messages/templates/compile-errors.js:L41-L50][f2]

Internal throw helper for compile errors.

It extracts start/end from its first argument: a plain number is treated as both start and end; null/undefined or a NodeLike object yields node?.start and node?.end. It throws an InternalCompileError whose position is [start, end ?? start] when start is defined, otherwise undefined — so a missing end falls back to start.

calls: [compile-errors.js-internal-compile-error](r5-compiler-state-errors.md#u-3993d4129502)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/state.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/scripts/process-messages/templates/compile-errors.js
