# Template Element Parsing

**Capability.** Parses opening/closing tags, dispatches elements/components/comments, reads attributes, directives, and value sequences, and creates fresh fragment nodes.

Read to learn how markup structure enters the AST, including directive-prefix classification. The parent-check and read-sequence helpers support element() directly.

**Depends on.**

- [Script and Expression Reading](r5-script-parsing.md) · graph-confirmed · 1 edge(s)
- [Compiler Semantic Model](r4-compiler-model.md) · graph-only · 11 edge(s)

**Depended on by.**

- [Template Parsing](r3-compiler-parse.md) · graph-only · 13 edge(s)

Parent: [Parse Phase](r5-parse.md)

## Units (8)

<a id="u-bc08cb4e57fa"></a>
### `element`

`export default function element(parser)` · [packages/svelte/src/compiler/phases/1-parse/state/element.js:L52-L411][f1]

Parses an opening or closing tag in the Svelte template parser, dispatching comments, meta tags, components, and elements into the parse tree.

On `<!--` it appends a Comment after reading to `-->`. For a closing tag (`/` eaten) it validates the name is not a void element, then loops while the current stack parent name differs: in loose mode it can backtrack if a prior opening `<name` was mis-parsed as an attribute; a RegularElement parent is implicitly closed with a warning (unless already auto-closed by the same tag); a non-element parent throws, either 'autoclosed' (if last_auto_closed_tag matches) or a plain invalid-closing-tag error. After the loop it sets the parent's end, pops it, and clears last_auto_closed_tag once the stack shrinks below its recorded depth. For opening tags: unknown `svelte:` names error; invalid names error unless loose mode with a trailing `.` (mid-typing). Root-only meta tags must be unique and sit at Root, recorded in parser.meta_tags. Element type comes from meta_tags, component-name regex, title-inside-head, slot outside a shadow-root template, else RegularElement. If the parent element's closing tag can be omitted, it warns, closes the parent, and records last_auto_closed_tag. Attributes are read via read_static_attribute for top-level script/style, otherwise read_attribute; duplicates of Attribute/BindDirective/StyleDirective/ClassDirective (bind normalized to Attribute) error unless the name is `this`. SvelteComponent/SvelteElement require a `this` attribute: the component's must be an expression (else error); the element's may be a value, with a non-expression value warning and being converted (Text to a Literal, acknowledging a known buggy interpolation case) or an expression used directly. Top-level script/style are consumed specially via read_script/read_style with duplicate checks and a preceding HTML comment attached for warning suppression. Otherwise the element is appended; self-closing (`/` or void) and unclosed (loose) cases set end without pushing the stack, with loose mode backtracking over an eaten `<` attribute, a `{/` or `{'`/`{@`/`{:` block prefix, or trailing whitespace. Non-void `textarea` and nested `script`/`style` read raw content; all others push onto parser.stack and parser.fragments to parse children.

**Notes.**

- side_effect: Mutates parser state: index, stack, fragments, meta_tags, last_auto_closed_tag, and root-level instance/module/css slots.

calls: [read_script](r5-script-parsing.md#u-086699ac3458), [read_style](r2-compiler-parsing.md#u-863125efdf39), [create_fragment](r5-template-parsing.md#u-6f16c2773335), [is_element_node](r4-compiler-model.md#u-0d9a79ad394a), [get_attribute_expression](r5-compiler-ast-utils.md#u-96e6f6d66786), [is_expression_attribute](r5-compiler-ast-utils.md#u-f63f079d6472), [closing_tag_omitted](r1-html-tree-validation.md#u-10b29d40ea2b), [is_void](r1-dom-dom-utils.md#u-9c54e843c710), [list](r4-compiler-utils.md#u-5617f591c677)

**Uncertainties.**

- Exact behavior of parser.append/pop/current/stack/fragments is defined in the parser core, not in this file
- read_script/read_style return shapes (context, content fields) are assumed from usage here

<a id="u-2a4064013135"></a>
### `get_directive_type`

`function get_directive_type(name)` · [packages/svelte/src/compiler/phases/1-parse/state/element.js:L696-L706][f1]

Maps a directive prefix (`use`, `animate`, `bind`, `class`, `style`, `on`, `let`, or `in`/`out`/`transition`) to its AST directive type string; any other prefix returns false, meaning the attribute stays a regular attribute.

<a id="u-2c3fac35f2d5"></a>
### `read_attribute`

`function read_attribute(parser)` · [packages/svelte/src/compiler/phases/1-parse/state/element.js:L490-L690][f1]

Reads one attribute, spread, attach tag, expression shorthand, or directive and returns null when no name is present.

A leading `{` starts bracket syntax: `@attach` reads an expression into an AttachTag; `...` reads an expression into a SpreadAttribute; otherwise an identifier inside the braces becomes a shorthand Attribute whose value is an ExpressionTag Identifier. In loose mode, a null identifier followed by `#`, `/`, `@`, or `:` returns null so a partially typed block is not mis-parsed, and a lone `}` yields an empty-name shorthand; otherwise attribute_empty_shorthand is thrown. Plain names ending in a token-ending character end the scan; a colon prefix mapped by get_directive_type turns the attribute into a directive with modifiers split on `|`, an empty directive name erroring. If `=` follows, a value is read: a bare `/` before `/>` becomes a Text value of `/`, otherwise read_attribute_value parses it; a quote without `=` errors. StyleDirective keeps its Text/ExpressionTag array value; other directives require a single ExpressionTag value (multi-chunk or Text values raise directive_invalid_value) and otherwise carry a null expression. Transition directives set intro/outro from the `in`/`out`/`transition` prefix. Bind and Class directives without an expression synthesize an Identifier named after the directive.

calls: [get_directive_type](r5-template-parsing.md#u-2a4064013135), [packages/svelte/src/compiler/phases/1-parse/state/element.js:read_attribute_value](r5-template-parsing.md#u-a913d60dcf82), [read_expression](r2-compiler-parsing.md#u-793d43872467), [create_expression_metadata](r4-compiler-model.md#u-32bbb434f744)

**Uncertainties.**

- create_attribute's handling of the value array is defined in nodes.js

<a id="u-a913d60dcf82"></a>
### `packages/svelte/src/compiler/phases/1-parse/state/element.js:read_attribute_value`

`function read_attribute_value(parser)` · [packages/svelte/src/compiler/phases/1-parse/state/element.js:L712-L763][f1]

Reads an attribute value, optionally quoted.

An immediately closed empty quote yields a single empty Text chunk. Otherwise read_sequence collects chunks until the closing quote or, unquoted, an invalid unquoted-value character; the terminator predicate is passed as the `done` callback. If the inner expression parser throws a js_parse_error whose position sits right before `/>` (e.g. `<Component test={{a:1} />` confusing acorn), the index is rewound and a clearer expected_token error is raised quoting the quote mark or `}`; all other errors propagate. An empty unquoted value raises expected_attribute_value. The closing quote is consumed; the result is returned as an array when quoted, multi-chunk, or starting with Text, otherwise the single ExpressionTag is returned directly.

calls: [element.js-read-sequence](r5-template-parsing.md#u-4be2de550c18)

**Uncertainties.**

- error.position is assumed to be the acorn error position array; its exact shape comes from outside this file

<a id="u-73af677afe37"></a>
### `read_static_attribute`

`function read_static_attribute(parser)` · [packages/svelte/src/compiler/phases/1-parse/state/element.js:L445-L484][f1]

Reads a plain (non-expression) attribute name up to a token-ending character and returns null if the name is empty.

If `=` follows, optional whitespace is allowed and regex_attribute_value matches a double-quoted, single-quoted, or bare value; no match raises expected_attribute_value. Quoted values are stripped of quotes, and a single Text chunk is built with entity references decoded. A stray quote where `=` was expected raises expected_token. Returns create_attribute with value `true` when no `=` was present.

calls: [decode_character_references](r1-parse-entities.md#u-a03f13997ae5)

**Uncertainties.**

- create_attribute's normalization behavior lives in nodes.js

<a id="u-2c88f8291588"></a>
### `element.js-parent-checks`

`function parent_is_head(stack)` · [packages/svelte/src/compiler/phases/1-parse/state/element.js:L414-L422][f1]

Two stack-scanning helpers used by element() when deciding an element's type.

parent_is_head walks the parser stack backwards and returns true only if it reaches a SvelteHead node first; a RegularElement or Component stops the search with false. parent_is_shadowroot_template walks the stack backwards and returns true if any RegularElement carries a `shadowrootmode` attribute, marking a declarative-shadow-DOM template (in which case `slot` stays a RegularElement rather than a SlotElement). Both return false for empty or unmatched stacks.

uses: [element](r5-template-parsing.md#u-bc08cb4e57fa)

<a id="u-4be2de550c18"></a>
### `element.js-read-sequence`

`function read_sequence(parser, done, location)` · [packages/svelte/src/compiler/phases/1-parse/state/element.js:L771-L785][f1]

Accumulates attribute or textarea content into Text and ExpressionTag chunks until a caller-supplied `done` predicate fires.

Text characters accumulate in current_chunk; flush() pushes it only if non-empty, decoding entity references into its data. On `{`, a `#{name}` or `@{name}` prefix raises block_invalid_placement or tag_invalid_placement for that location; otherwise whitespace is allowed, an expression is read and its closing `}` required, and an ExpressionTag chunk is pushed before a fresh text chunk starts. If the template ends without `done` firing, loose mode returns the chunks collected so far while strict mode raises unexpected_eof at the template end.

calls: [read_expression](r2-compiler-parsing.md#u-793d43872467), [decode_character_references](r1-parse-entities.md#u-a03f13997ae5)

**Uncertainties.**

- Whether flush's empty-chunk skip can drop meaningful whitespace is not constrained by the code beyond `if (current_chunk.raw)`

<a id="u-6f16c2773335"></a>
### `create_fragment`

`export function create_fragment(transparent = false)` · [packages/svelte/src/compiler/phases/1-parse/utils/create.js:L7-L17][f2]

Builds and returns a fresh empty AST Fragment node with nodes: [] and metadata flags: transparent (from the optional boolean argument, default false), dynamic: false, has_await: false.

Each call returns a new object; no state is shared or mutated. Used by the parser and element/tag state code to seed fragment containers.

uses: [Parser.constructor](r3-compiler-parse.md#u-b8662ab25ac9)

**Uncertainties.**

- The 'transparent' flag's downstream meaning is defined by consumers outside this file; only its default of false is visible here.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/1-parse/state/element.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/1-parse/utils/create.js
