# Parse Phase

**Capability.** Reads raw template text into the internal AST: tags, attributes, directives, inline scripts via Acorn, plus diagnostic suggestion tooling.

Use this subtree to see how source text becomes the AST. Template structure, script/expression reading, and fuzzy diagnostics change for different reasons and are separated accordingly.

**Children.**

- [Template Element Parsing](r5-template-parsing.md) `r5-template-parsing` · 8 unit(s)
- [Script and Expression Reading](r5-script-parsing.md) `r5-script-parsing` · 7 unit(s)
- [Fuzzy Match Diagnostics](r5-parse-diagnostics.md) `r5-parse-diagnostics` · 6 unit(s)

Parent: [Compiler](r5-compiler.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
