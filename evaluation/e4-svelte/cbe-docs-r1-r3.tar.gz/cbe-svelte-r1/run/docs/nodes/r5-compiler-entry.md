# Compiler Entry API

**Capability.** Public compile/parse/compileModule functions that normalize input (BOM removal), orchestrate the pipeline, convert internal ASTs to public ASTs, and stub the removed walk export.

Call these to compile or parse a component or module; they are the intended entry into the phases. walk() is a deliberate throwing stub directing users to estree-walker.

**Depended on by.**

- [Script and Expression Reading](r5-script-parsing.md) · model-inferred · 0 edge(s)

Parent: [Compiler](r5-compiler.md)

## Units (6)

<a id="u-a54e3b374c84"></a>
### `compile`

`export function compile(source, options)` · [packages/svelte/src/compiler/index.js:L21-L55][f1]

Compiles a Svelte component source string into a JavaScript module implementing the compiler's parse→analyze→transform pipeline.

It strips a leading BOM, resets module-level compiler state from the options (warning filter, filename), validates options via validate_component_options, and parses with _parse. It merges validated options with parse-discovered options: the parsed svelte:options minus customElement becomes parsed_options, and customElement is kept separately as customElementOptions on combined_options. If the parsed metadata flags TypeScript, it rewrites parsed's fragment/instance/module through remove_typescript_nodes (each only when present) and also cleans customElementOptions.extend when it exists. It then runs analyze_component and transform_component, and finally attaches result.ast built by to_public_ast, whose output form depends on options.modernAst.

calls: [index-js-to-public-ast](r5-compiler-entry.md#u-5ee87158abe4), [remove_bom](r5-compiler-entry.md#u-2ee755d4c746); uses: [parse](r5-compiler-entry.md#u-08797705aefb), [validate-options.js module code (L179–L183)][f2]

**Uncertainties.**

- Whether _parse, analyze_component, or transform_component throw or recover from errors is not visible in this file.

<a id="u-5cd4b4bd0816"></a>
### `compileModule`

`export function compileModule(source, options)` · [packages/svelte/src/compiler/index.js:L64-L71][f1]

Compiles a plain JavaScript module containing runes into a JavaScript module.

It strips a leading BOM, resets compiler state from the options' warningFilter and filename, validates options with validate_module_options, then runs analyze_module on the source and returns transform_module's result. Unlike compile it never parses a Svelte template and produces no ast field.

calls: [remove_bom](r5-compiler-entry.md#u-2ee755d4c746); uses: [validate-options.js module code (L179–L183)][f2]

<a id="u-08797705aefb"></a>
### `parse`

`export function parse(source, { modern, loose } = {})` · [packages/svelte/src/compiler/index.js:L112-L118][f1]

Parses a component and returns only its AST, without analysis or code generation.

It strips a leading BOM, resets compiler state with a warning filter that suppresses all warnings and an undefined filename, parses via _parse(source, loose), and converts to the public AST via to_public_ast. The returned shape depends on the modern flag: true yields the modern public AST, otherwise the legacy Svelte 4-style AST from convert. The loose option is forwarded so the parser can try to return an AST even for non-compilable input.

calls: [index-js-to-public-ast](r5-compiler-entry.md#u-5ee87158abe4), [remove_bom](r5-compiler-entry.md#u-2ee755d4c746)

<a id="u-2ee755d4c746"></a>
### `remove_bom`

`function remove_bom(source)` · [packages/svelte/src/compiler/index.js:L155-L160][f1]

Returns the source without a leading byte order mark: if the first character's char code is 0xfeff it slices off the first character, otherwise returns the string unchanged.

<a id="u-c9e4085285ea"></a>
### `walk`

`export function walk()` · [packages/svelte/src/compiler/index.js:L166-L170][f1]

Deprecated stub that always throws an error directing callers to import walk from 'estree-walker' instead; it never returns.

**Notes.**

- failure: Throws unconditionally with a message naming estree-walker as the replacement.

<a id="u-5ee87158abe4"></a>
### `index-js-to-public-ast`

`function to_public_ast(source, ast, modern)` · [packages/svelte/src/compiler/index.js:L125-L127][f1]

Converts an internal parsed AST into a public AST shape.

When modern is truthy, it returns a cleaned modern AST: a local clean helper deletes each node's metadata property; options attributes are cleaned directly (attribute, its value, and each element when value is an array), then a zimmerframe walk with a generic '_' handler deletes metadata from every visited node and continues traversal via next(). When modern is falsy, it instead converts the internal AST to the legacy Svelte 4-style AST via convert(source, ast).

**Notes.**

- side_effect: Mutates the input AST in place by deleting metadata properties from nodes.

calls: [legacy-js-convert](r3-compiler-shared-utils.md#u-4723dd340fbf)

**Uncertainties.**

- Whether the walk's '_' handler receives all node kinds (e.g. attributes reached via the options cleanup) is determined by zimmerframe semantics not shown here.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/index.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/validate-options.js
