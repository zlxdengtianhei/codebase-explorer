# Diagnostic Message Codegen

**Capability.** Templates from which the process-messages generator produces warning classes and per-code thrower/warner functions for compile-time and client-side diagnostics, all sharing the CompileDiagnostic shape.

Each CODE template is a placeholder replaced per message by the generator; compile-warnings additionally carries the internal w() helper that records (or suppresses) a warning. Read these to understand the shape of generated diagnostic functions, not the messages themselves.

**Depends on.**

- [Compiler Pipeline](r4-compiler-pipeline.md) · model-inferred · 0 edge(s)

Parent: [Svelte Monorepo](r4-svelte-monorepo.md)

## Units (5)

<a id="u-e2ab458c038c"></a>
### `compile-warnings.js-internal-compile-warning`

`class InternalCompileWarning extends CompileDiagnostic` · [packages/svelte/scripts/process-messages/templates/compile-warnings.js:L6-L14][f1]

Warning class extending CompileDiagnostic so warnings share the diagnostic object shape.

It declares name = 'CompileWarning' as an instance field and its constructor merely forwards (code, message, position) to super; all serialization/toString behavior is inherited from CompileDiagnostic, which is not supplied here.

uses: [w](r4-diagnostics-messages.md#u-664df6361e22)

**Uncertainties.**

- CompileDiagnostic is imported from ./utils/compile_diagnostic.js, whose source is not provided; inherited behavior is inferred from the delegation pattern only.

<a id="u-ae2811903bcd"></a>
### `packages/svelte/scripts/process-messages/templates/compile-warnings.js:CODE`

`export function CODE(node, PARAMETER)` · [packages/svelte/scripts/process-messages/templates/compile-warnings.js:L49-L51][f1]

Template for generated compile-warning functions (placeholder 'CODE' replaced per message by the generator).

It also exports `codes = CODES`, which the generator substitutes with an array literal of the category's message codes. Each generated function forwards (node, parameters) to w() with the message text plus a https://svelte.dev/e/<code> link.

calls: [w](r4-diagnostics-messages.md#u-664df6361e22)

<a id="u-664df6361e22"></a>
### `w`

`function w(node, code, message)` · [packages/svelte/scripts/process-messages/templates/compile-warnings.js:L24-L40][f1]

Internal helper that records one compile warning unless it is suppressed.

It selects the active ignore stack: the global ignore_stack, or, when a node is given, ignore_map.get(node) falling back to ignore_stack. If a stack exists and its topmost set contains the code, the warning is dropped. Otherwise it builds an InternalCompileWarning with position [node.start, node.end ?? node.start] when node has a start (undefined otherwise), and pushes it onto warnings only if the imported warning_filter predicate accepts it.

calls: [compile-warnings.js-internal-compile-warning](r4-diagnostics-messages.md#u-e2ab458c038c); uses: [packages/svelte/scripts/process-messages/templates/compile-warnings.js:CODE](r4-diagnostics-messages.md#u-ae2811903bcd)

**Uncertainties.**

- ignore_stack, ignore_map, warning_filter and warnings come from ./state.js, not supplied; their contracts are inferred from usage.

<a id="u-96149b5e3a32"></a>
### `CODE`

`export function CODE(PARAMETER)` · [packages/svelte/scripts/process-messages/templates/client-errors.js:L10-L18][f2]

Template for generated client-side error throwers.

In DEV builds each generated function builds an Error whose message contains the code, the message text and a https://svelte.dev/e/<code> link, sets name to 'Svelte error', and throws it; in production it throws a bare Error containing only the link. Return type is `never` as it always throws.

uses: [packages/svelte/scripts/process-messages/templates/shared-errors.js:CODE](r3-tooling-codegen.md#u-c8f0956cc77a)

**Uncertainties.**

- DEV comes from esm-env; the conditions under which it is true are outside this source.

<a id="u-f81818d1f5e0"></a>
### `packages/svelte/scripts/process-messages/templates/client-warnings.js:CODE`

`export function CODE(PARAMETER)` · [packages/svelte/scripts/process-messages/templates/client-warnings.js:L10-L20][f3]

Template for generated client-side console warners.

In DEV builds each generated function warns with a styled template (bold code header, normal-styled message, doc link) using the module's bold/normal font-weight strings; in production it warns with only the https://svelte.dev/e/<code> link.

uses: [packages/svelte/scripts/process-messages/templates/shared-warnings.js:CODE](r1-message-codegen-templates.md#u-8b569597eb19)

**Uncertainties.**

- DEV's truthiness conditions are defined in esm-env, not here.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/scripts/process-messages/templates/compile-warnings.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/scripts/process-messages/templates/client-errors.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/scripts/process-messages/templates/client-warnings.js
