# Element integrations: custom elements, actions, bindings

**Capability.** Owns element-level runtime behaviors: wrapping legacy components as custom elements (SvelteElement plus the createCustomElement class factory), running actions in effects, and two-way bindings for document state, media properties and element sizes via shared ResizeObserver singletons. Legacy event-modifier substitutes are included as deprecated element-related helpers.

Use this subtree per DOM integration concern. Media bindings each own one property (currentTime, volume, paused, muted, playbackRate) plus event-driven read-only state; size bindings share per-box-mode observer singletons. The custom element bridge converts attribute strings to typed prop values.

**Depends on.**

- [DOM primitives: operations and templates](r2-client-dom-core.md) · graph-confirmed · 1 edge(s)
- [Effect Lifecycle](r5-effects-module.md) · graph-only · 15 edge(s)
- [DOM Elements, Bindings & Transitions](r3-runtime-dom-elements.md) · graph-only · 11 edge(s)

Parent: [Client runtime](r2-client-runtime.md)

## Units (16)

<a id="u-cd2e5c090ca7"></a>
### `custom-element-js-create-custom-element`

`export function create_custom_element( Component, props_definition, slots, exports, u…` · [packages/svelte/src/internal/client/dom/elements/custom-element.js:L283-L291][f1]

Turns a Svelte component into a custom element class by subclassing SvelteElement and wiring prop and export accessors.

The generated class stores the component, slots, and shadow-DOM flag via its constructor, and observedAttributes lowercases each prop's attribute name (or the key itself) so attribute changes are observed. For every prop definition it defines a prototype accessor: the getter reads the live component property when present, else the cached $$d value; the setter converts via get_custom_element_value, caches in $$d, and, if the component exists, either assigns directly to the component when it has a getter/accessor for the prop (per the comment, preferring instance accessors) or calls $set. Exported properties get read-only getters delegating to the component instance. If an extend function is given, the class is passed through it and the result replaces Class. Finally the class is assigned to Component.element and returned.

**Notes.**

- side_effect: Component.element is mutated to point at the returned class.
- contract: The prop setter distinguishes instance accessors via get_descriptor(component, prop)?.get, not a plain setter.

calls: [get_custom_element_value](r2-client-dom-elements.md#u-b0718db16728)

**Uncertainties.**

- Why the descriptor's get (rather than set) selects the direct-assignment path is not documented in the source; the comment only says an instance accessor takes precedence.

<a id="u-a77d1581ddf1"></a>
### `custom-element-js-svelte-element`

`class extends HTMLElement` · [packages/svelte/src/internal/client/dom/elements/custom-element.js:L17-L44][f1]

Defines the SvelteElement base custom element class (only when HTMLElement exists) that wraps a legacy Svelte component instance inside a DOM element, bridging attributes, props, slots, and listeners.

The constructor stores the component constructor and slot names and optionally attaches an open shadow root. addEventListener records the listener and, if the component instance exists, subscribes via $on (storing the unsubscribe), then delegates to super; a custom event sharing a DOM event name will fire twice since this cannot be detected upfront. removeEventListener removes via super and invokes and deletes the stored unsubscribe if present. connectedCallback is async: it sets $$cn, and on first connect awaits one microtask so child slot elements can mount (aborting if disconnected or already initialized in the meantime), builds $$slots from existing child nodes for each declared slot name (a 'default' slot becomes the children snippet), converts attributes to initial props via $$g_p and get_custom_element_value, ports over programmatically-set pre-init props (deleting the shadowing own property), instantiates the component with createClassComponent targeting shadowRoot or the element, starts an effect_root/render_effect that reflects props marked reflect back to attributes (skipping non-reflect keys, removing the attribute when the converted value is null, with $$r set during reflection so attributeChangedCallback ignores self-induced changes), and replays buffered $$l listeners through $on, clearing $$l. attributeChangedCallback returns early while $$r is true, maps the attribute name via $$g_p, stores the converted value, and $sets the component if it exists. disconnectedCallback marks $$cn false and schedules a microtask that destroys the component, stops the reflection effect root, and clears $$c only if still disconnected. $$g_p resolves an attribute name back to its prop key by matching an explicit attribute definition or a lowercase key match, defaulting to the name itself.

**Notes.**

- failure: If the element reconnects before the connectedCallback microtask resumes, initialization aborts via the !this.$$cn || this.$$c guard.
- side_effect: Reflection sets $$r true around attribute writes so attributeChangedCallback does not feed values back into the component.

calls: [createClassComponent](r5-legacy-adapters.md#u-f1a6026980f8), [append](r2-client-dom-core.md#u-daaa1d70e416), [get_custom_element_value](r2-client-dom-elements.md#u-b0718db16728), [get_custom_elements_slots](r2-client-dom-elements.md#u-2b317b984503)

**Uncertainties.**

- Exact behavior of $on/$set/$destroy comes from the legacy component instance and is not visible in this file.
- The iterator .next() call sites in connectedCallback could not be resolved to specific targets by the graph.

<a id="u-b0718db16728"></a>
### `get_custom_element_value`

`function get_custom_element_value(prop, value, props_definition, transform)` · [packages/svelte/src/internal/client/dom/elements/custom-element.js:L228-L258][f1]

Converts a value between DOM-attribute strings and component prop values according to the declared type.

Boolean coercion happens first: a non-boolean for a 'Boolean' prop becomes value != null. With no transform or no prop definition the value is returned as-is. For 'toAttribute': Object/Array become JSON.stringify or null when nullish; Boolean becomes '' for truthy and null otherwise; Number becomes null when nullish, otherwise the number; other types pass through. For 'toProp': Object/Array become JSON.parse(value) when truthy (undefined otherwise); Number applies unary + unless null; Boolean and the default case return the value unchanged.

**Uncertainties.**

- JSON.parse on malformed attribute strings will throw; no error handling is present.

<a id="u-2b317b984503"></a>
### `get_custom_elements_slots`

`function get_custom_elements_slots(element)` · [packages/svelte/src/internal/client/dom/elements/custom-element.js:L263-L270][f1]

Builds a name-to-true record of slots already present among an element's child nodes, mapping each element child's slot property (or 'default' when empty) to true.

Used by connectedCallback to decide which declared slots need synthetic <slot> elements.

<a id="u-e8c39de2a586"></a>
### `action`

`export function action(dom, action, get_value)` · [packages/svelte/src/internal/client/dom/elements/actions.js:L13-L43][f2]

Runs a Svelte action on an element inside an effect, re-invoking the action's update when its reactive value changes and cleaning up via destroy.

The action itself runs untracked so its initial call never records dependencies. If a value getter was supplied and the returned payload exposes update, a render effect reads the value, deep-reads it so $state mutations are detected, and calls payload.update(value) only after the first run and when safe_not_equal says the value changed; prev starts as a fresh object so the first comparison is always unequal-guarded. If the payload exposes destroy, the outer effect's teardown calls it. A falsy action result is normalized to {}.

**Notes.**

- side_effect: The action may run its destroy callback when the surrounding effect is destroyed, per the returned teardown.

calls: [effects.js-trivial-effect-factories](r5-effects-module.md#u-191f01511fb1), [untrack](r5-signal-core.md#u-aa0e067da463), [safe_not_equal](r1-reactivity-primitives.md#u-3775acbc409e)

<a id="u-63ddea66ca81"></a>
### `bind_active_element`

`export function bind_active_element(update)` · [packages/svelte/src/internal/client/dom/elements/bindings/document.js:L7-L17][f3]

Tracks document focus changes by invoking update with the current document.activeElement.

A focusout whose relatedTarget is set is ignored so an in-progress focus move does not transiently report document.body; focusin and a final focusout still update.

calls: [listen](r3-runtime-dom-elements.md#u-8f0d8dd6601b)

<a id="u-7f84460974e1"></a>
### `media.js-bind-current-time`

`export function bind_current_time(media, get, set = get)` · [packages/svelte/src/internal/client/dom/elements/bindings/media.js:L21-L30][f4]

Two-way binds media.currentTime.

A requestAnimationFrame loop plus a timeupdate listener (for scrubbing while paused) cancels the pending frame, re-arms itself only while !media.paused, and pushes media.currentTime through set when it changed. A render_effect writes get() (Number-coerced) back to media.currentTime when changed and not NaN. Teardown cancels the animation frame and removes the timeupdate listener.

calls: [effects.js-trivial-effect-factories](r5-effects-module.md#u-191f01511fb1)

<a id="u-3d9b1140b986"></a>
### `media.js-bind-muted`

`export function bind_muted(media, get, set = get)` · [packages/svelte/src/internal/client/dom/elements/bindings/media.js:L216-L217][f4]

Two-way binds media.muted.

A volumechange callback pushes media.muted; when get() is initially nullish the callback runs once immediately. A render_effect coerces get() with !! and assigns media.muted only when it differs.

calls: [listen](r3-runtime-dom-elements.md#u-8f0d8dd6601b), [effects.js-trivial-effect-factories](r5-effects-module.md#u-191f01511fb1)

<a id="u-a1f672a4f28c"></a>
### `media.js-bind-paused`

`export function bind_paused(media, get, set = get)` · [packages/svelte/src/internal/client/dom/elements/bindings/media.js:L158-L161][f4]

Two-way binds media.paused.

The update closure pushes media.paused whenever it differs from the cached value. play/pause/canplay events drive update; the listen call passes call_handler_immediately = (paused == null), so an undefined bound value is not pushed initially. An effect (required so the element is mounted before play() to avoid 'interrupted by a new load request' errors) applies get(): if it differs from media.paused it calls media.pause() or media.play(), and a rejected play() promise falls back to setting the bound value back to true (paused).

calls: [effects.js-trivial-effect-factories](r5-effects-module.md#u-191f01511fb1), [listen](r3-runtime-dom-elements.md#u-8f0d8dd6601b)

<a id="u-5e7658852fc0"></a>
### `media.js-bind-volume`

`export function bind_volume(media, get, set = get)` · [packages/svelte/src/internal/client/dom/elements/bindings/media.js:L191-L192][f4]

Two-way binds media.volume.

A volumechange callback pushes media.volume; when get() is initially nullish the callback runs once immediately. A render_effect writes Number(get()) to media.volume when changed and non-NaN.

calls: [listen](r3-runtime-dom-elements.md#u-8f0d8dd6601b), [effects.js-trivial-effect-factories](r5-effects-module.md#u-191f01511fb1)

<a id="u-4820026af89c"></a>
### `bind_playback_rate`

`export function bind_playback_rate(media, get, set = get)` · [packages/svelte/src/internal/client/dom/elements/bindings/media.js:L133-L151][f4]

Two-way binds media.playbackRate.

Two effects exist specifically because the element must be mounted first; setting the rate before insertion is reset to 1 by the browser. The first effect writes Number(get()) to media.playbackRate when changed and non-NaN. The second effect registers a ratechange listener (via listen) that pushes media.playbackRate back to the setter.

calls: [effects.js-trivial-effect-factories](r5-effects-module.md#u-191f01511fb1), [listen](r3-runtime-dom-elements.md#u-8f0d8dd6601b)

<a id="u-c7d9ec0b13d1"></a>
### `media.js-time-ranges-and-listeners`

`function time_ranges_to_array(ranges)` · [packages/svelte/src/internal/client/dom/elements/bindings/media.js:L5-L13][f4]

Media element bindings that push read-only media state into a setter from DOM events.

time_ranges_to_array converts a TimeRanges object into an array of {start, end} objects. bind_buffered listens to loadedmetadata/progress/timeupdate/seeking and, because buffered always returns a fresh object, only calls set when the range count or any start/end changed. bind_seekable sets on loadedmetadata, bind_played on timeupdate, bind_seeking on seeking/seeked, bind_ended on timeupdate/ended, and bind_ready_state on seven readiness events; each pushes the corresponding live property.

calls: [listen](r3-runtime-dom-elements.md#u-8f0d8dd6601b)

<a id="u-d29cfe379011"></a>
### `ResizeObserverSingleton`

`class ResizeObserverSingleton` · [packages/svelte/src/internal/client/dom/elements/bindings/size.js:L9-L23][f5]

A per-instance sharing wrapper around one ResizeObserver, so many bindings observe an element with a single native observer per options object.

It keeps a WeakMap of element → listener Set, lazily creates the ResizeObserver in #getObserver, and its callback stores each entry in the static ResizeObserverSingleton.entries WeakMap before invoking that element's listeners. observe adds a listener, starts observing, and returns an unsubscribe function that removes the listener and unobserves (and deletes the map entry) once the last listener for the element is gone. Three module-level singletons exist for content-box, border-box, and device-pixel-content-box box modes.

**Uncertainties.**

- Whether ResizeObserver is available in the target environment is assumed, not checked, by this source

<a id="u-4086fd190663"></a>
### `bind_element_size`

`export function bind_element_size(element, type, set)` · [packages/svelte/src/internal/client/dom/elements/bindings/size.js:L100-L108][f5]

Binds an element's client/offset width or height via the border-box singleton, pushing element[type] on resize and once immediately.

An effect re-pushes the value inside untrack (updates may contain reads that must not be tracked) and returns the unsubscribe as the effect teardown.

calls: [effects.js-trivial-effect-factories](r5-effects-module.md#u-191f01511fb1), [untrack](r5-signal-core.md#u-aa0e067da463)

<a id="u-dd65fd2f8c17"></a>
### `bind_resize_observer`

`export function bind_resize_observer(element, type, set)` · [packages/svelte/src/internal/client/dom/elements/bindings/size.js:L83-L93][f5]

Picks one of the three box-mode singletons from the requested entry type (contentRect/contentBoxSize → content-box, borderBoxSize → border-box, otherwise device-pixel-content-box), observes the element, and pushes entry[type] on each resize; the unsubscribe is registered as teardown.

calls: [effects.js-trivial-effect-factories](r5-effects-module.md#u-191f01511fb1)

<a id="u-560439f624aa"></a>
### `event-modifiers-js-legacy-modifiers`

`export function trusted(fn)` · [packages/svelte/src/internal/client/dom/legacy/event-modifiers.js:L11-L19][f6]

Deprecated runtime substitutes for legacy Svelte event modifiers.

The wrapper-based modifiers take a handler `fn` and return a substitute: `trusted` invokes `fn?.apply` only when `event.isTrusted` is truthy; `self` invokes it only when `event.target === this`; `once` uses a closure `ran` flag to run the handler exactly once and return immediately thereafter; `stopPropagation`, `stopImmediatePropagation`, and `preventDefault` call the corresponding event method before applying `fn` and return its result. In all cases a nullish `fn` is a no-op. The action-based modifiers `passive(node, [event, handler])` and `nonpassive(...)` start a `user_pre_effect` that registers the handler via the internal `on` helper with `passive: true` or `false` respectively, falling back to `noop` when `handler()` returns nullish, and return its unsubscribe function as the effect teardown.

calls: [packages/svelte/src/internal/client/dom/elements/events.js:on](r4-dom-elements.md#u-d8e90951de4c), [user_pre_effect](r5-effects-module.md#u-53bf5464d746)

**Uncertainties.**

- The assumption that `args[0]` is an Event is unchecked (`@ts-ignore` casts).
- Removal timing of the passive/nonpassive listener depends on `user_pre_effect` teardown semantics outside this file.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/elements/custom-element.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/elements/actions.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/elements/bindings/document.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/elements/bindings/media.js
[f5]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/elements/bindings/size.js
[f6]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/legacy/event-modifiers.js
