# Transition Configs

**Capability.** User-facing CSS transition factories (blur, fade, fly, scale, slide, draw, crossfade) producing TransitionConfig objects, with shared CSS-unit parsing helpers.

Use this subtree for the exported transition functions. These produce configs consumed by the runtime transition layer in the runtime internals subtree; crossfade additionally creates matched send/receive factories.

**Depends on.**

- [DOM Elements, Bindings & Transitions](r3-runtime-dom-elements.md) · model-inferred · 0 edge(s)

Parent: [Public Runtime Feature APIs](r3-public-api.md)

## Units (8)

<a id="u-bc2c7a4069fc"></a>
### `blur`

`export function blur( node, { delay = 0, duration = 400, easing = cubic_in_out, amoun…` · [packages/svelte/src/transition/index.js:L38-L53][f1]

Returns a TransitionConfig animating a blur filter and opacity.

Defaults: delay 0, duration 400, easing cubic_in_out, amount 5, opacity 0. It reads the computed style once: the element's current opacity is the target, the existing filter is preserved (empty when 'none'), and `amount` is split into value+unit. The css callback interpolates opacity from target toward `opacity` and the blur radius by `u`, i.e. it works for both in and out directions.

calls: [split_css_unit](r3-public-transitions.md#u-b34038bcc41a)

**Uncertainties.**

- getComputedStyle is a host API; its failure or non-element nodes are not handled in this file.

<a id="u-e08c53790eff"></a>
### `fade`

`export function fade(node, { delay = 0, duration = 400, easing = linear } = {})` · [packages/svelte/src/transition/index.js:L62-L70][f1]

Returns a TransitionConfig animating opacity with defaults delay 0, duration 400, easing linear.

Captures the element's computed opacity once; the css callback multiplies it by t, so in transitions fade from 0 to the current opacity and out transitions from current opacity to 0.

<a id="u-0bc0dd3f8a1e"></a>
### `fly`

`export function fly( node, { delay = 0, duration = 400, easing = cubic_out, x = 0, y …` · [packages/svelte/src/transition/index.js:L79-L97][f1]

Returns a TransitionConfig animating x/y translation and opacity.

Defaults: delay 0, duration 400, easing cubic_out, x 0, y 0, opacity 0. Preserves the element's existing transform (empty when 'none'), targets the computed opacity, and splits x and y into number+unit pairs. The css callback offsets translation by (1-t)*x/y from the element's position and interpolates opacity with u as in blur, so `in` starts at the given offset/opacity and `out` ends there.

calls: [split_css_unit](r3-public-transitions.md#u-b34038bcc41a)

<a id="u-10ebbce29874"></a>
### `scale`

`export function scale( node, { delay = 0, duration = 400, easing = cubic_out, start =…` · [packages/svelte/src/transition/index.js:L159-L177][f1]

Returns a TransitionConfig animating scale and opacity.

Defaults: delay 0, duration 400, easing cubic_out, start 0, opacity 0. Preserves the existing transform (empty when 'none') and targets computed opacity. The css callback scales between `start` (at u=1) and 1 (at u=0) and interpolates opacity, so `in` grows from `start` and `out` shrinks toward it.

<a id="u-56eca0fbad21"></a>
### `slide`

`export function slide(node, { delay = 0, duration = 400, easing = cubic_out, axis = '…` · [packages/svelte/src/transition/index.js:L108-L150][f1]

Returns a TransitionConfig that slides an element by animating its height (axis 'y', default) or width, including padding, margin, and border widths on the perpendicular edges, with `overflow: hidden` and `min-<primary>: 0`.

Defaults: delay 0, duration 400, easing cubic_out. In DEV, the first time the computed display matches contents/inline/table it warns `transition_slide_display` and sets the module-level `slide_warning` flag, clearing it in a microtask so the warning fires at most once per batch of calls. Opacity ramps quickly: `Math.min(t * 20, 1)` reaches full opacity at t=0.05. All dimension values are captured from computed style when the transition is created.

**Notes.**

- side_effect: slide_warning is module-level mutable state gating the DEV-only warning.

<a id="u-72385efb0ac6"></a>
### `draw`

`export function draw(node, { delay = 0, speed, duration, easing = cubic_in_out } = {})` · [packages/svelte/src/transition/index.js:L186-L210][f1]

Returns a TransitionConfig animating an SVG path draw via stroke-dasharray/stroke-dashoffset.

Requires the node to have getTotalLength; the length is measured up front and increased by the parsed strokeWidth when strokeLinecap is not 'butt' (round/butt caps extend past the endpoint). Duration resolution: if duration is undefined, it becomes 800 unless speed is given, in which case duration = length / speed; if duration is a function it is called with the length. Defaults otherwise: delay 0, easing cubic_in_out. The css callback offsets the dash by u * length, hiding the path at u=1.

**Notes.**

- condition: stroke-linecap other than 'butt' lengthens the measured path by one strokeWidth.

<a id="u-604bb627ffc1"></a>
### `packages/svelte/src/transition/index.js:crossfade`

`export function crossfade({ fallback, ...defaults })` · [packages/svelte/src/transition/index.js:L233-L245][f1]

Creates matched `send`/`receive` transition factories for moving elements between two lists, keyed by `params.key`.

Given `{ fallback, ...defaults }`, it keeps two Maps, to_send and to_receive, and returns [transition(to_send, to_receive, false), transition(to_receive, to_send, true)]. Each factory registers the node under its key and returns a deferred function: if the counterpart map has the same key, it deletes the counterpart entry and produces a crossfade config between the two nodes; otherwise the node is unclaimed, its own entry is deleted, and the optional `fallback(node, params, intro)` config is returned (undefined if not provided). The inner crossfade merges defaults with params (mutating a fresh copy via assign), measures both rects to derive dx/dy translation and width/height ratios, and builds a css callback fading opacity to `t * opacity` while translating by u*dx/u*dy and scaling by t + (1-t)*ratio, with transform-origin top left. Default duration is a function `d => Math.sqrt(d) * 30` (called with the distance) unless a number is supplied; default easing is cubic_out; default delay 0.

**Notes.**

- condition: When no counterpart exists for a key, fallback is used; without a fallback the transition config is undefined.
- side_effect: Matching keys are deleted from both maps, so each pair crossfades at most once.

calls: [packages/svelte/src/transition/index.js:crossfade](r3-public-transitions.md#u-604bb627ffc1)

**Uncertainties.**

- Lifecycle of stale map entries if a deferred transition function is never called is not handled in this file.

<a id="u-b34038bcc41a"></a>
### `split_css_unit`

`function split_css_unit(value)` · [packages/svelte/src/transition/index.js:L26-L29][f1]

Module-private helpers shared by the transition functions.

`linear` is the identity easing. `cubic_out` and `cubic_in_out` are the standard cubic easings (in/out branching at t<0.5), used as default easings. `split_css_unit` splits a CSS length into [number, unit]: for a string it matches an optional sign, digits/decimals, and unit suffix (defaulting the unit to 'px' when the match has an empty unit); for a non-string it returns [value, 'px'].

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/transition/index.js
