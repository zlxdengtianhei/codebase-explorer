# Playground Sandbox

**Capability.** Builds the sandbox playground: CLI setup and directory prep, double compilation (client and server) of every source file into output/, snapshot download into src/, and gzip/base64url payload hashing for shareable URLs; config files fix compiler options (HMR off, async enabled) and Vite setup (no minification, inspect plugin, local svelte excluded from pre-bundling).

run.js is the build driver (mkdirp/write helpers, then the compile loop); download.js and hash.js handle snapshot import/export; the two config modules document the intentional dev-environment choices.

**Depends on.**

- [Compiler Pipeline](r4-compiler-pipeline.md) · model-inferred · 0 edge(s)

Parent: [Repository Tooling](r4-repo-tooling.md)

## Units (9)

<a id="u-7792f9b7775b"></a>
### `mkdirp`

`function mkdirp(dir)` · [playgrounds/sandbox/run.js:L23-L27][f1]

Creates a directory tree, silently ignoring any error from recursive mkdir.

Takes a string path and returns nothing; failures such as permission errors are swallowed by the empty catch, so callers cannot detect failure.

**Uncertainties.**

- Which specific fs.mkdirSync errors occur is platform-dependent; all are suppressed by the empty catch.

<a id="u-7e8e16bca8d0"></a>
### `playgrounds/sandbox/run.js:write`

`function write(file, contents)` · [playgrounds/sandbox/run.js:L33-L36][f1]

Writes text contents to a file, first ensuring the parent directory exists via mkdirp.

Returns nothing; a failed mkdir is swallowed by mkdirp, but a failed fs.writeFileSync propagates to the caller.

calls: [mkdirp](r4-playground-sandbox.md#u-7792f9b7775b)

<a id="u-2eee5a3b7690"></a>
### `run.js module code (L1–L22)`

`module_region` · [playgrounds/sandbox/run.js:L1-L22][f1]

Module setup: parses CLI flags and empties the output directory before generation.

parseArgs accepts a single boolean --runes flag from process.argv; the result is later read as argv.values.runes. If the output directory exists, every entry except '.gitkeep' is removed recursively with fs.rmSync; per-entry errors are caught and ignored, so partial cleanup is possible.

**Notes.**

- side_effect: Deletes all non-.gitkeep contents of the output directory at module load, before any compilation runs.

<a id="u-64412a345d1b"></a>
### `run.js module code (L36–L136)`

`module_region` · [playgrounds/sandbox/run.js:L36-L136][f1]

Compiles every .svelte and .js file under src/ twice, once for 'client' and once for 'server' output, writing results into output/.

For each .svelte file it reads the source and, in the client pass only, additionally writes a JSON AST (bigints serialized as ['BigInt', string]) and a migrated version (migration errors are warned and skipped, not fatal). It compiles with svelte's compile() using generate, the --runes flag, and experimental async enabled; each warning's code and frame are printed to stderr. JS, sourcemap, and in the client pass an extra fragments:'tree' variant are written via write(); CSS is written only when compiled.css exists. Finally each .js module is compiled with compileModule() and written per generate mode.

**Notes.**

- condition: The fragments:'tree' recompilation and AST/migration outputs happen only when generate === 'client'.
- failure: compile/compileModule failures other than migrate (which is caught) are not caught and abort the script.

calls: [playgrounds/sandbox/run.js:write](r4-playground-sandbox.md#u-7e8e16bca8d0), [mkdirp](r4-playground-sandbox.md#u-7792f9b7775b)

**Uncertainties.**

- Exact shape of compiled.js.map.toString() and compiled.css is compiler-defined and not visible here.

<a id="u-3a2d44014938"></a>
### `download.js module code (L1–L52)`

`module_region` · [playgrounds/sandbox/scripts/download.js:L1-L52][f2]

Downloads a Svelte playground snapshot into src/.

The first CLI argument must parse as a URL with origin 'https://svelte.dev' and a '/playground/' pathname; otherwise the script logs an error and exits 1. With a non-empty hash it base64-decodes the hash (mapping '-'/'_' back to '+'/'/'), gunzips via DecompressionStream through a byte-wise Uint8Array, and parses JSON to get files. Otherwise it treats the third pathname segment as an id, fetches the playground API, and maps each component to a file entry. Every resulting file is written under src/.

**Notes.**

- failure: Invalid/missing URL argument and a non-svelte.dev playground URL both exit with code 1 after printing to stderr.
- side_effect: Writes each downloaded file directly into src/, overwriting existing files of the same name.

**Uncertainties.**

- Non-OK fetch responses are not checked; response.json() shape errors would propagate uncaught.
- Empty-hash branch is chosen only when url.hash.length > 1.

<a id="u-515b35e99b78"></a>
### `compress`

`async function compress(payload)` · [playgrounds/sandbox/scripts/hash.js:L22-L42][f3]

Gzip-compresses a string and returns a base64url-encoded hash suitable for a playground URL fragment.

Reads the Blob stream through a gzip CompressionStream in a loop; each chunk's bytes are appended to a string via String.fromCharCode because UTF-8 decoding would make btoa reject the value. On done, it releases the reader lock and returns btoa of the buffer with '+'->'-' and '/'->'_' replacements.

<a id="u-e8f1b39d4f70"></a>
### `hash.js module code (L1–L21)`

`module_region` · [playgrounds/sandbox/scripts/hash.js:L1-L21][f3]

Builds a playground payload from every top-level file (non-directory) in src/, reading each as UTF-8 into a files array serialized as JSON under the name 'sandbox'.

It then awaits compress(payload) and prints a svelte.dev playground 'untitled' URL whose fragment is the base64url gzip hash.

calls: [compress](r4-playground-sandbox.md#u-515b35e99b78)

**Uncertainties.**

- Subdirectories in src/ are skipped entirely; only direct file children are included.

<a id="u-a065383f67c4"></a>
### `svelte.config.js module code (L1–L9)`

`module_region` · [playgrounds/sandbox/svelte.config.js:L1-L9][f4]

Static Svelte compiler configuration: disables HMR and enables the experimental async option.

Exports a plain object with no logic; values apply to whatever tooling consumes svelte.config.js.

<a id="u-05c7b53c4e26"></a>
### `vite.config.js module code (L1–L16)`

`module_region` · [playgrounds/sandbox/vite.config.js:L1-L16][f5]

Vite configuration for the sandbox: disables minification, adds vite-plugin-inspect and the Svelte plugin, and excludes the workspace-local 'svelte' package from dependency optimization so local changes do not require dev-server restarts with --force.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/playgrounds/sandbox/run.js
[f2]: ../../../../../../eval/svelte-be645b4/playgrounds/sandbox/scripts/download.js
[f3]: ../../../../../../eval/svelte-be645b4/playgrounds/sandbox/scripts/hash.js
[f4]: ../../../../../../eval/svelte-be645b4/playgrounds/sandbox/svelte.config.js
[f5]: ../../../../../../eval/svelte-be645b4/playgrounds/sandbox/vite.config.js
