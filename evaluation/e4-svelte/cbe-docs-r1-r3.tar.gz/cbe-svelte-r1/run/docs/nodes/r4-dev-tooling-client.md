# Client Dev Tooling

**Capability.** Development-only validation and introspection: $inspect logging, snippet-argument assertions, non-reactive-binding and duplicate-each-key warnings, element source-location tagging, and removal of dev-installed component CSS.

All units here either warn or annotate; none affect production semantics. Start at validate.js for binding/each-key checks and inspect.js for $inspect; grp:css.js and grp:elements.js handle dev-mode CSS tracking and element metadata.

**Depends on.**

- [Client Reactivity](r4-client-reactivity.md) · graph-confirmed · 1 edge(s)

Parent: [Client Runtime](r4-client-runtime.md)

## Units (6)

<a id="u-0546b8eb9687"></a>
### `css.js`

`export function register_style(hash, style)` · [packages/svelte/src/internal/client/dev/css.js:L8-L17][f1]

Tracks component style elements by hash so they can be removed later.

register_style adds a style element to the Set stored under its hash, creating the Set on first use. cleanup_styles removes every tracked style element from the DOM and deletes the hash entry; it returns early if the hash is unknown. State is a module-level Map shared across calls.

uses: [css.js-append-styles](r4-dom-elements.md#u-f8c34d0a4927)

<a id="u-bbbb362af05b"></a>
### `elements.js`

`export function add_locations(fn, filename, locations)` · [packages/svelte/src/internal/client/dev/elements.js:L13-L22][f2]

Attaches source-location metadata to elements created by compiled template functions in dev mode.

add_locations wraps a DOM-building fn so that after it runs, the start node is chosen as dom itself when hydrating, dom.firstChild when dom is a document fragment, or dom otherwise, and locations are assigned to it; the original dom is returned. assign_location writes an __svelte_meta property (parent dev_stack plus file/line/column) onto an element and, if the location has child locations, recurses into element.firstChild. assign_locations walks siblings, skipping hydration boundary comments (incrementing depth for start markers, decrementing for end markers) and assigning locations[i++] only to element nodes while depth is 0, so hydration wrappers are not misattributed.

**Uncertainties.**

- assign_locations can exhaust siblings before consuming all locations; extra locations are silently dropped (loop ends when node is null).
- Writing __svelte_meta assumes the node is extensible; frozen elements would throw, though this is not guarded.

<a id="u-da1d251f1f86"></a>
### `inspect`

`export function inspect(get_value, inspector = console.log)` · [packages/svelte/src/internal/client/dev/inspect.js:L11-L55][f3]

Implements $inspect: logs values whenever they change, tolerating read errors.

After validate_effect('$inject'-style) checking, it creates a synchronous inspect_effect that calls get_value() inside try/catch; on throw it stores the error for later reporting, otherwise snapshots the value and calls the inspector (default console.log) untracked with 'init' or 'update'. A companion render_effect re-calls get_value (errors ignored) and, if a stored error exists, reports it via console.error and resets it; if that effect never runs the inspect was destroyed and the error is discarded. initial flips to false after the first successful log.

**Notes.**

- failure: Read errors are deferred to a render_effect and reported with console.error, not thrown.

calls: [effects.js-trivial-effect-factories](r5-effects-module.md#u-191f01511fb1), [validate_effect](r5-effects-module.md#u-4f3a8befe7fd), [packages/svelte/src/internal/shared/clone.js:snapshot](r2-shared-internals.md#u-bfcc537be9f1), [untrack](r5-signal-core.md#u-aa0e067da463)

<a id="u-a46097177ac6"></a>
### `validate_snippet_args`

`export function validate_snippet_args(anchor, ...args)` · [packages/svelte/src/internal/client/dev/validation.js:L6-L16][f4]

Dev-time assertion for compiled snippet calls.

Raises e.invalid_snippet_arguments when the anchor is not an object or not a Node instance, and for each remaining argument that is not a function. No return value; passes silently on valid input.

<a id="u-c7a0dea89b16"></a>
### `packages/svelte/src/internal/client/validate.js:validate_binding`

`export function validate_binding(binding, get_object, get_property, line, column)` · [packages/svelte/src/internal/client/validate.js:L48-L83][f5]

Development warning for non-reactive binding properties.

Inside a render effect guarded by a `warned` flag (fires at most once per binding), it captures the bound object with capture_store_binding and skips store subscriptions entirely. It then probes reactivity by reading object[property] inside a nested render effect that only runs once; if that effect has no dependencies (deps === null), the property is deemed non-reactive and w.binding_property_non_reactive warns with a filename:line:column location, after which the outer effect stops warning.

calls: [effects.js-trivial-effect-factories](r5-effects-module.md#u-191f01511fb1), [capture_store_binding](r4-client-reactivity.md#u-8388b459c980)

**Uncertainties.**

- The heuristic assumes a getter has a corresponding setter; a property read that caches without dependencies would be misclassified, as the code comment acknowledges

<a id="u-8e0376d25fe3"></a>
### `validate_each_keys`

`export function validate_each_keys(collection, key_fn)` · [packages/svelte/src/internal/client/validate.js:L14-L39][f5]

Development check for duplicate each-block keys, run inside a render effect that re-validates when the collection changes.

The collection result is normalized: arrays used as-is, null/undefined treated as empty, other iterables converted with Array.from. For each item it computes the key; when a key already seen earlier (tracked in a Map from key to index) reappears, it reports the duplicate indices via e.each_key_duplicate, passing the key as a string unless it stringifies to an '[object ...]' form, in which case null is passed instead.

calls: [effects.js-trivial-effect-factories](r5-effects-module.md#u-191f01511fb1)

**Uncertainties.**

- Whether e.each_key_duplicate always throws is inferred from usage, not visible here

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dev/css.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dev/elements.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dev/inspect.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dev/validation.js
[f5]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/validate.js
