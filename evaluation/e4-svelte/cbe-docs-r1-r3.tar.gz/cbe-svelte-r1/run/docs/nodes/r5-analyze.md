# Analyze Phase

**Capability.** Walks the parsed AST validating template syntax, binding mutability, and component contracts, and propagating reactivity metadata for the transforms.

Enter here for validation and metadata rules. Element/directive visitors are grouped together; CSS-specific value analysis is separate because it serves scoping decisions.

**Children.**

- [Analyze Visitors](r5-analyze-visitors.md) `r5-analyze-visitors` · 21 unit(s)
- [CSS Analysis Utilities](r5-css-analyze-utils.md) `r5-css-analyze-utils` · 6 unit(s)

Parent: [Compiler](r5-compiler.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
