# Runtime Mode Flags

**Capability.** Process-wide mutable flags for async, legacy and tracing modes, plus side-effect modules that enable async or legacy mode at import time.

Use this to see how runtime modes are toggled globally. Importing the enable modules flips the shared flags once for the whole process.

Parent: [Client Runtime](r1-runtime-client.md)

## Units (3)

<a id="u-10b9373cdfdd"></a>
### `index-js-flags`

`export function enable_async_mode_flag()` · [packages/svelte/src/internal/flags/index.js:L5-L7][f1]

Module-level mode flags for the Svelte runtime, all exported as mutable let bindings defaulting to false: async_mode_flag, legacy_mode_flag, and tracing_mode_flag.

Each has an enable function that sets its flag to true; disable_async_mode_flag sets async_mode_flag back to false and is commented as test-only. Because the flags are plain exported bindings, once enabled the mode applies process-wide until explicitly reset. Separate side-effect modules (async.js, legacy.js, tracing.js) import and invoke the corresponding enable function at load time to opt a build into that mode.

**Notes.**

- side_effect: Enabling functions mutate shared module state visible to the whole process, not local state.

**Uncertainties.**

- No unset functions exist for legacy or tracing flags; whether any code relies on resetting them is not visible here.

<a id="u-fa76b71e08ad"></a>
### `async-js-flags`

`group` · [packages/svelte/src/internal/flags/async.js:L1-L3][f2]

Side-effect module that opts the runtime into async mode: it imports enable_async_mode_flag and calls it once at module load, setting async_mode_flag to true for the whole process.

Importing this file is itself the activation mechanism; evaluating it twice has no additional effect beyond re-assigning the same flag to true.

imports: [index-js-flags](r1-mode-flags.md#u-10b9373cdfdd)

**Uncertainties.**

- The unresolved require call reported by the graph has no visible counterpart in the supplied three-line source; activation appears to be purely via import side effect.

<a id="u-a4799a6f7940"></a>
### `legacy-js-flags`

`group` · [packages/svelte/src/internal/flags/legacy.js:L1-L3][f3]

Side-effect module that opts the runtime into legacy (Svelte 4 compatibility) mode: it imports enable_legacy_mode_flag and calls it at load time, setting legacy_mode_flag to true process-wide.

Activation is by import alone.

imports: [index-js-flags](r1-mode-flags.md#u-10b9373cdfdd)

**Uncertainties.**

- The graph reports an unresolved require with no visible counterpart in the supplied source.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/flags/index.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/flags/async.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/flags/legacy.js
