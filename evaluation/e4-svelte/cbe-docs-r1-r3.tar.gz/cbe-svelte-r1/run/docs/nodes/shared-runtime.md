# Shared Runtime Utilities

**Capability.** Environment-agnostic helpers used by compiler and both runtimes: framework-wide constants and predicates (HTML/SVG/MathML element classes, attribute aliases, boolean/DOM properties, delegated events, runes, hashing), HTML escaping for safe interpolation, numeric bitmask constants, SSR attribute/class/style serialization, deep state snapshot/clone, standard error throwers and warning emitters, shared runtime validation (store shape, dynamic tags, void-element warning), and HTML nesting validation rules.

Consult before duplicating any element, attribute or serialization knowledge; these modules are deliberately kept separate from all consumers. utils.js and the escape/bitmask helpers are single sources of fixed lists; the validate_* guards and error throwers each encode one usage mistake.

**Depends on.**

- [Client Runtime](client-runtime.md) · model-inferred · 0 edge(s)
- [Compiler Pipeline](compiler-pipeline.md) · model-inferred · 0 edge(s)
- [Server Runtime](server-runtime.md) · model-inferred · 0 edge(s)

**Depended on by.**

- [Client Runtime](client-runtime.md) · model-inferred · 0 edge(s) · The client runtime's DOM and dev layers consume shared element/attribute predicates instead of duplicating element tables.
- [Compiler Pipeline](compiler-pipeline.md) · model-inferred · 0 edge(s) · Parse, analyze and transform phases use shared constants and predicates such as void/boolean element tables from shared-runtime.
- [Diagnostic Message Codegen](diagnostics-codegen.md) · model-inferred · 0 edge(s)
- [Public Reactive APIs & Features](public-reactive-apis.md) · model-inferred · 0 edge(s)
- [Server Runtime](server-runtime.md) · model-inferred · 0 edge(s)

Parent: [Svelte Monorepo](svelte-monorepo.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
