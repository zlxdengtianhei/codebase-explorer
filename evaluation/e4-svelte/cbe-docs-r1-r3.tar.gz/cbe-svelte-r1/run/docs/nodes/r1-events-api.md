# svelte/events Public API

**Capability.** Public event helper: re-exports the internal `on` implementation and declares its five overloads with documented removal-function semantics and ordering relative to delegated attribute handlers.

Use this for the supported way to attach handlers imperatively. The runtime module is a pure re-export; the .d.ts documents overload shapes.

Parent: [Svelte Monorepo](r1-root.md)

## Units (2)

<a id="u-f89d44628152"></a>
### `index-js-events`

`group` · [packages/svelte/src/events/index.js:L1-L1][f1]

Pure re-export module: the public svelte/events entry point re-exports on from the internal client DOM events implementation.

It contains no logic of its own; all behavior lives in the re-exported module.

<a id="u-455ea46cd5b6"></a>
### `events-public-d-ts-on-overloads`

`export function on<Type extends keyof WindowEventMap>( window: Window, type: Type, ha…` · [packages/svelte/src/events/public.d.ts:L8-L13][f2]

Declarations only: five overloads of the public `on` helper, each documented as attaching an event handler and returning a removal function, preserving handler order relative to declarative handlers added via attributes, which use event delegation.

The overloads target window (`WindowEventMap`), document (`DocumentEventMap`), HTMLElement (`HTMLElementEventMap`), MediaQueryList (`MediaQueryListEventMap`), and a general fallback accepting any `EventTarget` with a string type and `EventListener`. All take optional `AddEventListenerOptions` and bind `this` to the target. The header comment says the overloads live here rather than in JSDoc pending a TypeScript issue fix. No implementation exists in this file.

**Uncertainties.**

- Runtime attach/remove behavior lives in an implementation file not supplied here.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/events/index.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/events/public.d.ts
