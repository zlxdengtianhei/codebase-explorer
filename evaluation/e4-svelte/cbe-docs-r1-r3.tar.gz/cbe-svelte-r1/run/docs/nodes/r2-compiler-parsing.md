# Syntax parsing (template expressions and CSS)

**Capability.** Owns reading raw source characters into AST nodes for embedded JavaScript expressions and CSS stylesheets, including error recovery for unparseable expressions.

Start here to see how `<style>` bodies, selectors, at-rules, and inline JS expressions become AST. The style reader is a recursive-descent family (rule → block → item → declaration/value/selector); the expression reader delegates to the JS parser and falls back to placeholder identifiers. Both raise compiler errors for malformed input.

**Depends on.**

- [Compile diagnostics](r2-compiler-diagnostics.md) · model-inferred · 0 edge(s)

**Depended on by.**

- [Template Parsing](r3-compiler-parse.md) · graph-only · 12 edge(s)

Parent: [Component compiler pipeline](r2-compiler.md)

## Units (18)

<a id="u-793d43872467"></a>
### `read_expression`

`export default function read_expression(parser, opening_token, disallow_loose)` · [packages/svelte/src/compiler/phases/1-parse/read/expression.js:L35-L93][f1]

Parses a JavaScript expression in the template starting at the current index using `parse_expression_at`, then normalizes the parser position.

After a successful parse it rewinds past trailing comments that end before the node start (setting `parser.index` to the last such comment's end), counts `(` characters between the parser index and the node start, and then balances those opening parentheses: scanning forward from the node end (extended past a trailing comment if the final recorded comment ends later), each `)` decrements the count and any non-whitespace, non-`)` character raises `e.expected_token(index, ')')`. The parser index ends after the last consumed closing parenthesis. On any parse error, the catch path first tries loose recovery: when `parser.loose` is set and `disallow_loose` is not, `get_loose_identifier` may return a placeholder expression spanning to the next `}` (or given bracket); if that also fails, the original error is rethrown via `parser.acorn_error(err)`. This recovery exists so `each` constructs like `as { y = z }` still throw a structured error upstream.

**Notes.**

- condition: `disallow_loose` disables the placeholder fallback even when the parser is in loose mode.
- failure: Error precedence: loose fallback attempted first; only if it yields no expression does `parser.acorn_error` handle the original error.

calls: [parse_expression_at](r5-script-parsing.md#u-730e2a662101), [get_loose_identifier](r2-compiler-parsing.md#u-f85dafe8159e)

**Uncertainties.**

- `parser.root.comments` is mutated by `parse_expression_at` (new comments are appended); the normalization relies on that side effect, which is defined in acorn.js.

<a id="u-f85dafe8159e"></a>
### `get_loose_identifier`

`export function get_loose_identifier(parser, opening_token)` · [packages/svelte/src/compiler/phases/1-parse/read/expression.js:L13-L27][f1]

Produces a placeholder expression when the real expression cannot be parsed: it locates the matching closing bracket (default `}`, or the supplied `opening_token`) from the current index and, if found, jumps `parser.index` to that position and returns an empty-named `Identifier` spanning the skipped text, signaling 'unknown expression'.

If no matching bracket exists it returns `undefined` so the caller can fall back to reporting the original error.

calls: [find_matching_bracket](r4-parse-phase.md#u-3e5597267416)

**Uncertainties.**

- Whether `find_matching_bracket` handles nesting is defined in bracket.js and not visible here.

<a id="u-863125efdf39"></a>
### `read_style`

`export default function read_style(parser, start, attributes)` · [packages/svelte/src/compiler/phases/1-parse/read/style.js:L25-L45][f2]

Entry point for a `<style>` element: reads the CSS body up to `</style` via `read_body`, consumes the closing tag (allowing whitespace), and returns a `StyleSheet` node whose `content` records the raw style text span and whose `children` are the parsed rules/at-rules; `comment` starts as `null`.

calls: [read_body](r2-compiler-parsing.md#u-755ffe99e59c)

<a id="u-755ffe99e59c"></a>
### `read_body`

`function read_body(parser, close)` · [packages/svelte/src/compiler/phases/1-parse/read/style.js:L52-L71][f2]

Loops until the template ends, skipping comments and whitespace, returning as soon as the `close` marker (e.g. `</style`) matches.

Each iteration reads either an at-rule (when the next character is `@`) or a normal rule, appending to `children`. If the template is exhausted before the close marker appears, `e.expected_token` fires at the end of the template.

calls: [read_at_rule](r2-compiler-parsing.md#u-f5e645353a7a), [read_rule](r2-compiler-parsing.md#u-7fd5dca44ce4), [allow_comment_or_whitespace](r2-compiler-parsing.md#u-131239fcb755)

<a id="u-7fd5dca44ce4"></a>
### `read_rule`

`function read_rule(parser)` · [packages/svelte/src/compiler/phases/1-parse/read/style.js:L110-L126][f2]

Parses a qualified rule: a selector list followed by a block, returning a `Rule` node whose metadata starts at defaults (`parent_rule: null`, both selector flags and `is_global_block` false; scoping is computed later in the pipeline, not here).

calls: [read_selector_list](r2-compiler-parsing.md#u-00c76aa683fd), [read_block](r2-compiler-parsing.md#u-f9ccd7c79c86)

<a id="u-00c76aa683fd"></a>
### `read_selector_list`

`function read_selector_list(parser, inside_pseudo_class = false)` · [packages/svelte/src/compiler/phases/1-parse/read/style.js:L133-L162][f2]

Parses a comma-separated list of complex selectors.

After skipping comments/whitespace it repeatedly calls `read_selector`, then checks the terminator: inside a pseudo-class the list ends at `)`, otherwise at `{`. If neither terminator nor a required `,` follows, `parser.eat(',', true)` raises. EOF before a terminator raises `e.unexpected_eof`. The returned `SelectorList` spans from the first selector's start to the end of the last one.

calls: [read_selector](r2-compiler-parsing.md#u-7a102285dde0)

**Uncertainties.**

- The returned `end` is captured before skipping trailing whitespace/comments, so trailing trivia after the last selector is left unconsumed relative to the node span.

<a id="u-7a102285dde0"></a>
### `read_selector`

`function read_selector(parser, inside_pseudo_class = false)` · [packages/svelte/src/compiler/phases/1-parse/read/style.js:L169-L180][f2]

First segment of `read_selector`: defines the `create_selector` helper and initializes the working `RelativeSelector` before entering the main selection loop documented in the second segment.

<a id="u-dfd38fe7feea"></a>
### `packages/svelte/src/compiler/phases/1-parse/read/style.js:read_selector`

`function read_selector(parser, inside_pseudo_class = false)` · [packages/svelte/src/compiler/phases/1-parse/read/style.js:L193-L374][f2]

Main selector-compound loop.

Each iteration tries, in order: `&` nesting selector; `*` (optionally namespace-qualified, namespace discarded); `#id`; `.class`; `::pseudo-element` (whose parenthesized arguments are parsed for validation but discarded); `:pseudo-class` (arguments kept as a nested selector list); `[attr]` selectors with optional matcher (`~=` etc.), quoted/unquoted value via `read_attribute_value`, and alphabetic flags; an `An+B` Nth token (only inside pseudo-classes, matched before the combinator so `+2n` is not misread); a percentage; or, when no combinator character follows, a type selector (namespace prefix after `|` discarded). After each compound, comments/whitespace are skipped; if `,`, `)` (in pseudo-class context) or `{` follows, the parser rewinds to just after the compound, the current `RelativeSelector` is finalized and pushed, and the `ComplexSelector` is returned. Otherwise a combinator is read: if present, the finished relative selector (when non-empty) is pushed and a new one starts with that combinator; starting a selector directly with a combinator before any compound raises `e.css_selector_invalid`. Exhausting the template raises `e.unexpected_eof`.

**Notes.**

- condition: Inside pseudo-classes the `)` terminates the list; at rule level `{` does, which is why the same checks branch on `inside_pseudo_class`.

calls: [read_selector_list](r2-compiler-parsing.md#u-00c76aa683fd), [read_combinator](r2-compiler-parsing.md#u-ffc85cf8c133), [read_attribute_value](r2-compiler-parsing.md#u-ae80a6ada159), [read_identifier](r2-compiler-parsing.md#u-2dd7159f8ba1), [allow_comment_or_whitespace](r2-compiler-parsing.md#u-131239fcb755)

**Uncertainties.**

- When a compound branch matches but produces no selector push (not apparent from the branches shown), the loop could re-examine the same position; the visible branches each push or consume, but an empty type-selector branch would raise inside read_identifier.

<a id="u-36f915b3acf9"></a>
### `create_selector`

`function create_selector(combinator, start)` · [packages/svelte/src/compiler/phases/1-parse/read/style.js:L180-L193][f2]

Builds a fresh `RelativeSelector` node with the given combinator (possibly `null`) and start, an empty selector list, `end: -1`, and default metadata (`is_global`, `is_global_like`, `scoped` all false).

<a id="u-f9ccd7c79c86"></a>
### `read_block`

`function read_block(parser)` · [packages/svelte/src/compiler/phases/1-parse/read/style.js:L415-L441][f2]

Parses a `{ ...

}` block: requires the opening brace (erroring otherwise), then loops skipping comments/whitespace and collecting block items until `}` is matched, finally requiring and consuming the closing brace. Returns a `Block` node spanning both braces.

calls: [read_block_item](r2-compiler-parsing.md#u-7fe79445acb0)

**Uncertainties.**

- If the template ends before `}`, `parser.eat('}', true)` is the failure point; no separate EOF message is produced here.

<a id="u-7fe79445acb0"></a>
### `read_block_item`

`function read_block_item(parser)` · [packages/svelte/src/compiler/phases/1-parse/read/style.js:L449-L462][f2]

Reads one item inside a block, deciding its kind without try/catch: at-rules start with `@`.

Otherwise it speculatively reads a value via `read_value`, inspects the character at the resulting position, and rewinds; `{` means the item is a nested rule, anything else a declaration. This read-ahead duplicates parsing work but keeps real error positions intact.

calls: [read_at_rule](r2-compiler-parsing.md#u-f5e645353a7a), [read_value](r2-compiler-parsing.md#u-f2107227fcd9), [read_rule](r2-compiler-parsing.md#u-7fd5dca44ce4)

<a id="u-f5e645353a7a"></a>
### `read_at_rule`

`function read_at_rule(parser)` · [packages/svelte/src/compiler/phases/1-parse/read/style.js:L77-L104][f2]

Parses a CSS at-rule: consumes `@`, reads the at-rule name with `read_identifier`, then reads its prelude with `read_value`.

If the next character is `{` it parses a block (e.g. `@media (...) { ... }`); otherwise it requires and consumes a `;` (e.g. `@import '...'`), failing via the `true` argument to `parser.eat` if absent. Returns an `Atrule` with `block` set to `null` in the statement form.

calls: [read_value](r2-compiler-parsing.md#u-f2107227fcd9), [read_block](r2-compiler-parsing.md#u-f9ccd7c79c86), [read_identifier](r2-compiler-parsing.md#u-2dd7159f8ba1)

<a id="u-ed58797e828b"></a>
### `read_declaration`

`function read_declaration(parser)` · [packages/svelte/src/compiler/phases/1-parse/read/style.js:L468-L496][f2]

Parses a `property: value;` declaration.

The property name is read up to whitespace or `:`, then the colon and value are consumed. If the value is empty and the property is not a custom property (does not start with `--`), `e.css_empty_declaration` fires at the span from declaration start through the colon — empty custom properties are permitted. A trailing `;` is required unless the next character is `}`. Returns a `Declaration` whose `end` is captured before the semicolon, so the node excludes the terminator.

calls: [read_value](r2-compiler-parsing.md#u-f2107227fcd9)

<a id="u-f2107227fcd9"></a>
### `read_value`

`function read_value(parser)` · [packages/svelte/src/compiler/phases/1-parse/read/style.js:L502-L536][f2]

Reads a raw declaration or prelude value character by character until a structural terminator, returning the trimmed text.

Escape handling appends the escaped character verbatim after a backslash; quoted sections track a single active quote mark (`"` or `'`) and ignore terminators inside them; `url(` opens an in-url state where `;`, `{`, `}` are not terminators (a `)` closes the url state). Outside quotes and urls, `;`, `{`, or `}` ends the value. Reaching the end of the template without a terminator raises `e.unexpected_eof`.

**Notes.**

- condition: The `url(` detection compares the last three accumulated characters, so any identifier ending in `url` triggers it, matching CSS behavior loosely.

**Uncertainties.**

- Unterminated quotes or an unclosed `url(` swallow subsequent terminators until EOF, producing an unexpected_eof rather than a targeted quote error.

<a id="u-2dd7159f8ba1"></a>
### `read_identifier`

`function read_identifier(parser)` · [packages/svelte/src/compiler/phases/1-parse/read/style.js:L575-L611][f2]

Reads a CSS identifier per the CSS syntax spec: rejects a leading digit or lone `-` (via `REGEX_LEADING_HYPHEN_OR_DIGIT`) with `e.css_expected_identifier`.

Backslash escapes are decoded — a hex unicode escape (`\[0-9a-fA-F]{1,6}` with optional trailing whitespace/newline) becomes its code point, any other escape takes the next character literally; otherwise characters in `[a-zA-Z0-9_-]` or with code points ≥ 160 are accumulated. An empty result raises `e.css_expected_identifier`.

**Notes.**

- failure: Two distinct error sites use the same `css_expected_identifier`: a forbidden leading character and a zero-length identifier.

**Uncertainties.**

- Code points ≥ 160 are accepted without applying the full spec's exclusions (e.g. surrogates or non-character code points are not filtered).

<a id="u-ffc85cf8c133"></a>
### `read_combinator`

`function read_combinator(parser)` · [packages/svelte/src/compiler/phases/1-parse/read/style.js:L380-L409][f2]

Reads an explicit combinator (`+`, `~`, `>`, or `||`) with surrounding whitespace allowed, returning a `Combinator` node spanning the matched characters.

If no explicit combinator character is present but whitespace was consumed, it returns a descendant combinator named `' '`; if neither, it returns `null`.

<a id="u-ae80a6ada159"></a>
### `read_attribute_value`

`function read_attribute_value(parser)` · [packages/svelte/src/compiler/phases/1-parse/read/style.js:L543-L569][f2]

Reads an attribute-selector value that may be quoted (`'foo bar'`), unquoted (`foo`), or empty.

It first tries to consume an opening quote, then accumulates characters, honoring backslash escapes, until the matching closing quote (required, erroring if absent) or — when unquoted — any whitespace or `]`. Reaching EOF first raises `e.unexpected_eof`. The trimmed value is returned.

**Uncertainties.**

- Escaped characters are kept verbatim including the backslash, unlike `read_identifier` which decodes escapes; downstream consumers see raw escape sequences.

<a id="u-131239fcb755"></a>
### `allow_comment_or_whitespace`

`function allow_comment_or_whitespace(parser)` · [packages/svelte/src/compiler/phases/1-parse/read/style.js:L614-L629][f2]

Skips any run of whitespace and CSS/HTML comments: after consuming whitespace it repeatedly consumes `/* ...

*/` and `<!-- ... -->` pairs (requiring both open and close markers), re-consuming whitespace between and after them, until only whitespace remains.

**Uncertainties.**

- A `<!--` without a matching `-->` fails at `parser.eat('-->', true)`; the error surfaces from the read/eat helpers rather than a dedicated message.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/1-parse/read/expression.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/1-parse/read/style.js
