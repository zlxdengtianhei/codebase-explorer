# Spring Motion

**Capability.** Spring-based animation: the reactive Spring class (target/current as state signals, tick loop with stiffness/damping/precision) and the deprecated writable-store spring factory driving the same tick logic.

Use this subtree for `Spring` and legacy `spring()` semantics. Both share tick_spring and clamp, and both tag their signals for dev tracing.

**Depends on.**

- [Dev-Mode Diagnostics](r3-runtime-dev-tools.md) · graph-confirmed · 7 edge(s)
- [Signal Sources](r3-runtime-reactivity-sources.md) · graph-confirmed · 7 edge(s) · The Spring class backs its target/current values with state signals from the sources layer.

Parent: [Public Runtime Feature APIs](r3-public-api.md)

## Units (8)

<a id="u-6e9a0bc3364a"></a>
### `packages/svelte/src/motion/spring.js:Spring`

`class Spring` · [packages/svelte/src/motion/spring.js:L172-L196][f1]

Reactive spring class whose target and current values are state signals; setting target (or calling set) animates current toward target using stiffness, damping and precision.

The constructor takes an initial value plus SpringOpts: numeric stiffness/damping are clamped to [0,1] and precision is taken as-is, all stored in state signals (DEV mode tags each signal for tracing). Folded accessors: current, damping, precision, stiffness and target getters read via get; damping and stiffness setters clamp to [0,1]; precision setter assigns unclamped; the target setter delegates to this.set(v), returning the set promise implicitly discarded. Animation bookkeeping (#last_value, #last_time, #inverse_mass, #momentum, #task, #deferred) is private and driven by #update and set.

uses: [state](r3-runtime-reactivity-sources.md#u-acd426d0030b)

**Uncertainties.**

- This class fragment listing excludes #update and set, which are documented as their own units; constructor is folded here

<a id="u-6943334b08f4"></a>
### `Spring.#update`

`#update(value)` · [packages/svelte/src/motion/spring.js:L241-L285][f1]

Core animation driver: records value as the new target signal, lazily initializes #current/#last_value with ??= so a first set from undefined adopts the value, and if no task exists starts a loop tick that restores #inverse_mass toward 1, clamps elapsed time to 1000/30 ms, builds a TickContext from the current stiffness/damping/precision signals with dt=(elapsed*60)/1000, ticks via tick_spring, publishes the next value to #current, and clears #task when settled (returning !ctx.settled).

Returns the task's promise, which later set uses to resolve. Note the loop closure captures inv_mass_recovery_rate once at scheduling time.

calls: [tick_spring](r3-public-motion.md#u-6d7266b4a494), [loop.js-raf-task-loop](r5-reactivity-wrappers.md#u-0486df452d62)

**Uncertainties.**

- Whether #update is invoked with value === undefined is not guarded; ??= would then leave #current as its prior value

<a id="u-5e5221bc58ae"></a>
### `packages/svelte/src/motion/spring.js:Spring.set`

`set(value, options)` · [packages/svelte/src/motion/spring.js:L298-L323][f1]

Sets the spring's target and returns a Promise resolving when current catches up.

Any prior pending #deferred is rejected with Error('Aborted') (the rejection is unobserved because #update-time promises are caught with noop when created here... specifically d.promise.catch(noop) suppresses unhandled rejection). If options.instant is truthy or current is undefined, it aborts any running task, writes both target and current to value, and resolves immediately. With options.preserveMomentum, #inverse_mass is set to 0 and #momentum to the given ms so the spring keeps its trajectory before mass recovers. Otherwise a fresh deferred replaces #deferred, #update(value).then resolves it — but only if this deferred is still the current one, so superseded calls never resolve.

**Notes.**

- side_effect: Each non-instant set rejects the previous set's promise with Error('Aborted') and installs a noop catch on the new promise.

calls: [Spring.#update](r3-public-motion.md#u-6943334b08f4), [deferred](r5-internal-shared-utils.md#u-3c5ab59ed010)

**Uncertainties.**

- The docstring's 'hard'/'soft' options are declared deprecated for the class; the implementation reads only instant and preserveMomentum

<a id="u-9df30fb6eb05"></a>
### `packages/svelte/src/motion/spring.js:Spring.of`

`static of(fn, options)` · [packages/svelte/src/motion/spring.js:L230-L238][f1]

Creates a Spring from fn()'s current value and, inside a render_effect, calls spring.set(fn()) so the spring's target re-synchronizes reactively whenever fn's dependencies change.

Must run inside an effect root (e.g. component init) as the docstring states; the render_effect is what keeps the binding alive.

calls: [effects.js-trivial-effect-factories](r5-effects-module.md#u-191f01511fb1), [packages/svelte/src/motion/spring.js:Spring.set](r3-public-motion.md#u-5e5221bc58ae)

<a id="u-6d7266b4a494"></a>
### `tick_spring`

`function tick_spring(ctx, last_value, current_value, target_value)` · [packages/svelte/src/motion/spring.js:L23-L57][f1]

Advances a spring simulation one tick, returning the next value and signaling settlement via ctx.settled.

For numbers and Dates it computes delta, velocity (guarded against zero dt with 1/60), acceleration from stiffness/damping/inv_mass, and the step d; if both |d| and |delta| are below ctx.opts.precision it returns target_value (settled), otherwise it sets ctx.settled=false and returns current+d (as a new Date for dates). Arrays are ticked element-wise via recursion; plain objects are ticked per key into a fresh object; any other type throws 'Cannot spring <typeof> values'.

calls: [is_date](r4-reactive-primitives.md#u-c15d4b363055), [tick_spring](r3-public-motion.md#u-6d7266b4a494)

**Uncertainties.**

- last_value for arrays/objects is indexed by the same keys as current_value; mismatched shapes between last/current/target are not guarded in this source

<a id="u-ba5d7afebe6e"></a>
### `clamp`

`function clamp(n, min, max)` · [packages/svelte/src/motion/spring.js:L367-L369][f1]

Returns n constrained to the [min, max] range via Math.max(min, Math.min(max, n)).

<a id="u-65703c942e2e"></a>
### `spring`

`export function spring(value, opts = {})` · [packages/svelte/src/motion/spring.js:L68-L89][f1]

Deprecated factory creating a spring-animated writable store.

It wraps the initial value in a writable and exposes set, update, subscribe plus the configured stiffness (default 0.15), damping (0.8) and precision (0.01) on the returned object. Animation state (last_value, target_value, inv_mass, inv_mass_recovery_rate, cancel_task, current_token, task) lives in the factory closure; inv_mass recovers toward 1 over time after a 'soft' update. The returned store lacks class-only properties (target/current), hence the cast.

calls: [writable](r2-stores.md#u-dc45d71b793b), [packages/svelte/src/motion/spring.js:set](r3-public-motion.md#u-b9731c9f1349)

<a id="u-b9731c9f1349"></a>
### `packages/svelte/src/motion/spring.js:set`

`function set(new_value, opts = {})` · [packages/svelte/src/motion/spring.js:L89-L141][f1]

Updates the legacy spring store's target and drives its animation loop.

If the initial value is null/undefined, opts.hard is set, or stiffness>=1 and damping>=1, it cancels the running task, snaps last and current value to the new target immediately, and resolves. Otherwise a soft option (true meaning 0.5, otherwise coerced number) sets inv_mass_recovery_rate to 1/(rate*60) and inv_mass to 0 (infinite mass). When no task runs, it starts a loop whose tick recomputes inv_mass toward 1, clamps elapsed time to 1000/30 ms, builds a TickContext with dt=(elapsed*60)/1000, calls tick_spring and publishes the next value to the store; it returns false (and clears task) when ctx.settled. The returned Promise resolves via the task's promise only if this call's token is still current_token, so later set calls supersede earlier pending promises.

**Notes.**

- failure: A tick_spring throw inside the loop callback is not caught here; the behavior of the pending promise is not visible in this file.

calls: [tick_spring](r3-public-motion.md#u-6d7266b4a494), [loop.js-raf-task-loop](r5-reactivity-wrappers.md#u-0486df452d62)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/motion/spring.js
