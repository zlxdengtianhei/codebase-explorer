# Reactivity Benchmarking

**Capability.** Executes and reports reactivity benchmark suites (kairo signal graphs) via a child-process runner for performance comparison.

Use this subtree to understand how reactivity performance is measured. The runner forks per benchmark and aggregates results; each kairo suite times a distinct signal topology (deep chain vs. triangle fan-in).

**Depends on.**

- [Benchmark Harness](r4-benchmark-harness.md) · graph-only · 9 edge(s)

Parent: [Svelte Monorepo](r1-root.md)

## Units (3)

<a id="u-0b0dc218fb67"></a>
### `runner.js module code (L1–L10)`

`module_region` · [benchmarking/compare/runner.js:L1-L10][f1]

Benchmark runner child process: imports the reactivity benchmark list, awaits each benchmark in order, logs its benchmark name to stderr, collects results into an array, and sends the whole array to the parent via process.send.

Any thrown benchmark failure propagates and prevents process.send, leaving the parent's awaited promise unresolved.

**Notes.**

- side_effect: process.send(results) is the IPC channel consumed by compare/index.js, which writes it to a per-branch JSON file.
- failure: A rejected/throwing benchmark aborts the loop before results are sent.

**Uncertainties.**

- Whether process.send here is synchronous or requires an explicit exit/disconnect is not visible in this file.

<a id="u-b8265383c2b9"></a>
### `kairo-deep-js-benchmark-suite`

`function setup()` · [benchmarking/benchmarks/reactivity/kairo/kairo_deep.js:L7-L27][f2]

Times a 50-link derived chain (len=50) updating depth-first from a single head signal.

setup() builds head state, then 50 nested deriveds each adding 1 to the previous, and a render_effect reading the final current and incrementing a counter. run() sets head to 1 under flush, resets counter, then 50 iterations (iter=50) set head to i and assert $.get(current) === len+i, ending by asserting the render effect ran exactly iter times. kairo_deep_unowned warms up with 10 setup/run/destroy cycles, times 10 batches of 1000 run() calls via fastest_test, destroys, and returns the benchmark name with time and gc_time to 2 decimals. kairo_deep_owned holds the timed setup inside a $.effect_root (destroy_owned), runs identical timing, then calls both destroy and destroy_owned. Assertion failures propagate; no recovery path.

calls: [fastest_test](r4-benchmark-harness.md#u-0bbe8c671495), [assert](r4-benchmark-harness.md#u-823bd0dd0cd8)

<a id="u-02eabebf9fbf"></a>
### `kairo-triangle-js-benchmark-suite`

`function count(number)` · [benchmarking/benchmarks/reactivity/kairo/kairo_triangle.js:L6-L11][f3]

Times a triangular chain: width=10 chained deriveds (each +1) whose intermediate values are all summed by one derived, measuring growing fan-in.

setup() builds head state, iteratively pushes each prior current into list and creates current = prev+1, then sum = mapped reduce over list; a render effect increments counter while reading sum. run() computes the expected constant via count(width) (1..width summed), sets head to 1 asserting sum === constant, resets counter, then 100 times sets head to i and asserts sum === constant - width + i*width, ending with counter === 100. kairo_triangle_unowned does 10 warmup setup/run/destroy cycles, times 10 batches of 1000 run() calls via fastest_test, destroys, returns the benchmark name with 2-decimal time and gc_time. kairo_triangle_owned wraps warmup and the timed instance in an effect_root (destroy_owned), times identically, then calls both destroy and destroy_owned. Failed assertions throw.

calls: [fastest_test](r4-benchmark-harness.md#u-0bbe8c671495), [assert](r4-benchmark-harness.md#u-823bd0dd0cd8)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/benchmarking/compare/runner.js
[f2]: ../../../../../../eval/svelte-be645b4/benchmarking/benchmarks/reactivity/kairo/kairo_deep.js
[f3]: ../../../../../../eval/svelte-be645b4/benchmarking/benchmarks/reactivity/kairo/kairo_triangle.js
