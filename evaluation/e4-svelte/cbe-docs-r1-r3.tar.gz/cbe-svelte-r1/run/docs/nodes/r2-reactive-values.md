# Reactive value wrappers

**Capability.** Owns subscribable wrappers around external state: the ReactiveValue base with lazy subscriber creation, MediaQuery for match queries (including prefers-reduced-motion), and SvelteURL whose accessors are reactive to mutation.

Read here for how browser/URL state becomes reactive without stores. The wrappers subscribe only when read inside effects, keeping costs lazy. versions and legacy server compatibility also live at this API level.

**Depends on.**

- [Signal Sources](r3-runtime-reactivity-sources.md) · graph-only · 26 edge(s)
- [Signal Core](r5-signal-core.md) · graph-only · 21 edge(s)

Parent: [Public reactive APIs](r2-public-reactive.md)

## Units (5)

<a id="u-1f6c2b2fc560"></a>
### `packages/svelte/src/reactivity/media-query.js:MediaQuery`

`class MediaQuery extends ReactiveValue` · [packages/svelte/src/reactivity/media-query.js:L37-L42][f1]

MediaQuery is a ReactiveValue<boolean> reflecting whether a media query matches, updating via a change listener.

The constructor auto-wraps the query in parentheses unless it already contains a parenthesized group (parenthesis_regex) or every whitespace/comma-separated token is one of the non-parenthesized keywords ('all','print','screen','and','or','not','only'); this keyword check uses some because queries like 'random,screen' can still match. It then calls window.matchMedia and super with a read function returning q.matches and a subscribe function registering on(q, 'change', update). The documented fallback parameter for SSR appears in the signature but is not used in the visible constructor body.

**Notes.**

- contract: The constructor reads window and window.matchMedia, so construction requires a browser-like environment; the class docstring warns SSR values may be wrong.

**Uncertainties.**

- The fallback parameter is declared but never referenced in the supplied constructor; how the server fallback is applied is not visible here.

<a id="u-55ae66fdfd50"></a>
### `ReactiveValue`

`class ReactiveValue` · [packages/svelte/src/reactivity/reactive-value.js:L6-L15][f2]

Holds a getter function and a createSubscriber-based subscription, exposing the value through a current getter.

The constructor stores fn and builds #subscribe from the onsubscribe callback. Reading current first calls #subscribe() — which integrates with Svelte effects only when read inside a tracking effect — then returns fn(), so the value is computed on every read whether or not it is tracked.

calls: [createSubscriber](r4-reactive-primitives.md#u-44838dbc4415)

<a id="u-699019ac3903"></a>
### `url.js-svelteurl`

`class SvelteURL extends URL` · [packages/svelte/src/reactivity/url.js:L42-L57][f3]

SvelteURL is a reactive URL subclass: reading href, protocol, host, hostname, port, pathname, hash, search, username, or password in an effect re-runs it when the URL is mutated through its accessors.

Eight state fields mirror the URL components, initialized from the parsed URL; in DEV each is tagged for tracing. The constructor re-parses via new URL(url, base), and while creating the SvelteURLSearchParams it sets the module-global current_url to this and clears it afterwards — get_current_url exposes that global so SvelteURLSearchParams can find its owning URL during construction. Getters read the relevant states before returning the super value; host and origin read hostname plus port (origin also protocol); href reads all eight. Setters write through to super, then resync the affected states: href sets all eight and calls [REPLACE] on #searchParams so it mirrors the new query; search sets #search to the raw value and also [REPLACE]s #searchParams. searchParams lazily returns the SvelteURLSearchParams instance (created in the constructor, not on first read). toString and toJSON both return this.href.

calls: [url-search-params.js-svelteurlsearchparams](r4-reactive-primitives.md#u-16bd40497c5c), [packages/svelte/src/internal/client/runtime.js:get](r5-signal-core.md#u-98099fbbf12a), [packages/svelte/src/internal/client/reactivity/sources.js:set](r3-runtime-reactivity-sources.md#u-452914169f68); uses: [state](r3-runtime-reactivity-sources.md#u-acd426d0030b)

**Uncertainties.**

- Whether direct mutation of the underlying URL via means other than these accessors stays reactive is not addressed by this source.
- Only the href and search setters propagate to searchParams; other setters do not, so their effect on #searchParams reactivity is not established here.

<a id="u-d32993a2a403"></a>
### `version.js module code (L1–L8)`

`module_region` · [packages/svelte/src/version.js:L1-L8][f4]

Release-generated version constants: `VERSION` = '5.38.6' (full version from package.json) and `PUBLIC_VERSION` = '5' (major only).

Comment warns the file is generated during release and must not be modified.

<a id="u-97e8d38a4382"></a>
### `packages/svelte/src/legacy/legacy-server.js:asClassComponent`

`export function asClassComponent(component)` · [packages/svelte/src/legacy/legacy-server.js:L22-L25][f5]

Server-side wrapper converting a Svelte 5 component into a Svelte 4-compatible component constructor.

It delegates construction to the client-side `as_class_component`, then attaches a `render` method: given optional `props` and `{context}`, it calls the SSR `render(component, {props, context})` and returns `{css: {code: '', map: null}, head: result.head, html: result.body}` — SSR css output is discarded. The returned constructor is cast rather than type-checked (`@ts-expect-error`/`@ts-ignore` on the assignment and return), so typing mismatches surface only at compile-with-checks time.

calls: [render](r1-ssr-core.md#u-ead9aba750b3)

**Uncertainties.**

- Behavior of `render` and `as_class_component` for client-compiled components is commented only ('works if the component is compiled in SSR mode') and not verifiable here.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/reactivity/media-query.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/reactivity/reactive-value.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/reactivity/url.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/version.js
[f5]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/legacy/legacy-server.js
