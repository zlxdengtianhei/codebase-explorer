# Benchmark Harness

**Capability.** Drives benchmark suites and measures per-run wall-clock and forced-GC time: run_tracked wraps a run with GarbageTrack GC attribution, fastest_test repeats and picks the minimum, and utils provide timing, delay, assertion, and file I/O helpers.

Start at run.js for the suite driver; run_tracked/fastest_test/GarbageTrack define the measurement methodology (GC attribution via performance entries, min-of-N). The remaining utils are small shared helpers.

**Depends on.**

- [Client Runtime](r4-client-runtime.md) · model-inferred · 0 edge(s)

**Depended on by.**

- [Reactivity benchmarks](r2-benchmarking.md) · graph-only · 19 edge(s)
- [Benchmark Suites](r5-benchmark-suites.md) · graph-only · 15 edge(s)
- [Reactivity Benchmarking](r1-benchmarking.md) · graph-only · 9 edge(s)

Parent: [Repository Tooling](r4-repo-tooling.md)

## Units (11)

<a id="u-8a0ea15faff6"></a>
### `run.js module code (L1–L55)`

`module_region` · [benchmarking/run.js:L1-L55][f1]

Top-level benchmark driver that runs all registered suites sequentially and reports total timing.

It first pushes an empty reaction root via the Svelte client internal module ($.push({}, true)), then iterates two suites (reactivity, SSR), awaiting each benchmark and accumulating results.time and results.gc_time per suite and overall. Any thrown error aborts: it logs a failure banner, prints the error, and exits with code 1 (skipping $.pop()). On success it calls $.pop() and logs totals formatted with toFixed(2).

**Notes.**

- side_effect: Writes progress and timing output to stdout/stderr and mutates module-level total_time/total_gc_time accumulators.
- failure: Failure inside any awaited benchmark prevents $.pop() from running because process.exit(1) executes first.

uses: [fastest_test](r4-benchmark-harness.md#u-0bbe8c671495)

**Uncertainties.**

- Exact behavior of $.push/$.pop and the shape of the object returned by each benchmark (fields time and gc_time) is defined outside this file.

<a id="u-b7717abe1fed"></a>
### `GarbageTrack`

`class GarbageTrack` · [benchmarking/utils.js:L8-L14][f2]

Tracks elapsed wall-clock periods and correlating GC performance entries so a caller can attribute garbage-collection time to a specific watched function run.

The constructor immediately starts observing 'gc' entry types; a PerformanceObserver appends every received entry to perf_entries. watch, gcDuration, and destroy expose the tracking lifecycle; instances are cheap and expected to be short-lived (created per tracked run in run_tracked).

calls: [promise_delay](r4-benchmark-harness.md#u-3308e4a46f8a)

<a id="u-823bd0dd0cd8"></a>
### `assert`

`export function assert(a)` · [benchmarking/utils.js:L96-L100][f2]

Throws Error('Assertion failed') when the argument is falsy; returns undefined otherwise.

Used throughout the kairo and mol reactivity benchmarks to validate computed values.

<a id="u-0bbe8c671495"></a>
### `fastest_test`

`export async function fastest_test(times, fn)` · [benchmarking/utils.js:L82-L91][f2]

Benchmark harness that runs fn `times` times, each run via run_tracked (forced GC plus timing and GC tracking), and returns the run with the smallest timing.time.

Results are reduced with a strict less-than comparison, so the earliest run wins ties. Errors thrown by fn propagate on the first occurrence, aborting the loop. This is the function each reactivity benchmark invokes to produce its reported {result, timing} object.

calls: [run_tracked](r4-benchmark-harness.md#u-cd205b57d6f7)

**Uncertainties.**

- Behavior when times is 0: reduce over an empty array throws TypeError; no guard exists in the source.

<a id="u-3308e4a46f8a"></a>
### `promise_delay`

`function promise_delay(timeout = 0)` · [benchmarking/utils.js:L51-L53][f2]

Returns a Promise resolved by setTimeout after the given timeout in milliseconds (default 0), used to yield to the event loop or wait for async observer delivery.

<a id="u-19c8243b4a22"></a>
### `read_file`

`export function read_file(file)` · [benchmarking/utils.js:L105-L107][f2]

Reads a file synchronously as UTF-8 and normalizes CRLF line endings to LF before returning the text.

Read or encoding errors propagate to the caller.

<a id="u-52eb06b944b0"></a>
### `run_timed`

`function run_timed(fn)` · [benchmarking/utils.js:L58-L63][f2]

Synchronously executes fn and returns {result, time} where time is the elapsed milliseconds measured with performance.now around the call.

No error handling: exceptions from fn propagate and no result is produced.

<a id="u-cd205b57d6f7"></a>
### `run_tracked`

`async function run_tracked(fn)` · [benchmarking/utils.js:L68-L76][f2]

Runs fn once with forced GC and measures both its execution time and associated GC time.

It forces a full garbage collection via v8.collectGarbage(), creates a fresh GarbageTrack (which starts observing 'gc' entries), watches run_timed(fn) to capture timing and a track id, awaits gcDuration for the GC time, unwraps the inner result and time, disconnects the observer via destroy(), and returns {result, timing: {time, gc_time}}.

**Notes.**

- side_effect: Forces a garbage collection before timing, so prior allocations do not pollute the measured run.
- failure: If gcDuration rejects (which cannot happen here since the track id comes from watch), destroy() would be skipped; exceptions thrown by fn propagate before gcDuration is awaited.

uses: [GarbageTrack](r4-benchmark-harness.md#u-b7717abe1fed); calls: [run_timed](r4-benchmark-harness.md#u-52eb06b944b0)

**Uncertainties.**

- v8-natives collectGarbage semantics (full vs incremental collection) are not defined in this file.

<a id="u-ccb2ac8173a1"></a>
### `write`

`export function write(file, contents)` · [benchmarking/utils.js:L113-L119][f2]

Writes contents to a file, first creating its directory recursively.

mkdirSync runs in a try/catch with an empty catch, so any directory-creation error (including existing-path errors) is swallowed; the subsequent writeFileSync still executes and its errors propagate uncaught.

**Notes.**

- failure: Empty catch means a genuine mkdir failure is ignored; failure only surfaces if writeFileSync itself throws.

<a id="u-8c65a064a6ec"></a>
### `GarbageTrack.gcDuration`

`async gcDuration(track_id)` · [benchmarking/utils.js:L27-L40][f2]

Asynchronously returns the summed duration of GC entries that occurred during a watched period.

After awaiting promise_delay(10) to give the observer time to deliver entries, it looks up the period by track_id; if none matches, it returns a rejected promise with the string 'no period found' (a non-Error rejection). Otherwise it filters perf_entries whose startTime lies in [period.start, period.end) and reduces them to the sum of their durations, which is 0 when no GC entries exist.

**Notes.**

- failure: Unknown track_id yields a rejected promise with a plain string, not an Error; callers must handle string rejection values.
- condition: The fixed 10ms delay assumes GC performance entries arrive within that window; later-arriving entries would be missed.

calls: [promise_delay](r4-benchmark-harness.md#u-3308e4a46f8a)

<a id="u-8e277c6f1d2c"></a>
### `GarbageTrack.watch`

`watch(fn)` · [benchmarking/utils.js:L14-L22][f2]

Runs fn synchronously while recording a timing period tagged with an incrementing track id.

Increments track_id, captures performance.now before and after fn(), pushes {track_id, start, end} onto periods, and returns {result, track_id} so the caller can later request GC duration. The GC entries arriving during fn are matched in gcDuration by startTime falling within [start, end).

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/benchmarking/run.js
[f2]: ../../../../../../eval/svelte-be645b4/benchmarking/utils.js
