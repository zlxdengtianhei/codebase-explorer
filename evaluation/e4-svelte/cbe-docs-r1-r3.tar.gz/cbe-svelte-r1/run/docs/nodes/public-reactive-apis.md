# Public Reactive APIs & Features

**Capability.** The user-facing reactive and feature modules application code imports: classic stores (writable/derived/readable/get), motion (Tween and legacy tweened, springs, easing), reactive value wrappers (ReactiveValue, MediaQuery, SvelteURL) and reactive collections (SvelteMap/Set/URLSearchParams/Date), the createSubscriber lazy-subscription bridge with inert server stubs, CSS transition factories, the svelte/events public API with its documented overload semantics, the runtime FLIP animation helper, and lifecycle hooks/event dispatch/attachments from the public component API with Svelte 4 compatibility adapters.

Enter here for exported behaviors; each child is a distinct API surface. The tweened factory is built on writable and motion exposes prefersReducedMotion via MediaQuery; all feature modules consume the client reactivity core. Uncertainty: reactive collection implementations are evidenced via their test suites only.

**Depends on.**

- [Client Runtime](client-runtime.md) · model-inferred · 0 edge(s) · Public reactive features like springs and reactive window values are built on the client runtime's source and tracing internals.
- [Server Runtime](server-runtime.md) · model-inferred · 0 edge(s)
- [Shared Runtime Utilities](shared-runtime.md) · model-inferred · 0 edge(s)

**Depended on by.**

- [Public Type Declarations](public-types.md) · model-inferred · 0 edge(s) · Action and animation type declarations describe contracts whose runtime implementations live in the public reactive APIs.

Parent: [Svelte Monorepo](svelte-monorepo.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
