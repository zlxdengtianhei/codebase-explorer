# DOM Blocks

**Capability.** Implements reactive control-flow regions: await_block renders pending/then/catch snippets with stale-promise and hydration handling, key re-renders on key change, and snippet/wrap_snippet/createRawSnippet manage snippet functions with dev ownership context.

Use await.js for async template semantics, key.js for keyed re-rendering, and snippet.js to understand how snippet functions are rendered and wrapped; wrap_snippet also cooperates with shared validation to prevent snippet stringification.

**Depends on.**

- [Component Context](r4-component-context.md) · graph-confirmed · 10 edge(s)
- [DOM Elements & Events](r4-dom-elements.md) · graph-confirmed · 1 edge(s)
- [Shared Runtime Utilities](r4-shared-runtime.md) · graph-confirmed · 1 edge(s)
- [Task Scheduling](r4-task-scheduling.md) · graph-confirmed · 1 edge(s)
- [Effect Lifecycle](r5-effects-module.md) · graph-only · 18 edge(s)

Parent: [DOM Rendering](r4-dom-rendering.md)

## Units (7)

<a id="u-05916687a6e9"></a>
### `packages/svelte/src/internal/client/dom/blocks/await.js:update`

`function update(state, restore)` · [packages/svelte/src/internal/client/dom/blocks/await.js:L76-L132][f1]

Swaps the visible snippet to the given AwaitState and hides the other two, always setting resolved=true.

With restore=true (promise callbacks), it first installs the outer effect as active effect/reaction and restores the captured component context and DEV stack so new branches are created in the right context; the finally block clears all of these and calls flushSync so the DOM updates in the same tick as settlement. For each state the matching effect is resumed if it already exists, otherwise created via branch and the snippet fn; effects for all other states are paused and nulled via their cleanup callbacks. A null snippet fn for the requested state means nothing is rendered for it.

calls: [set_component_context](r4-component-context.md#u-4155baf87729), [flushSync](r3-runtime-reactivity-batching.md#u-f4c4d1829672)

<a id="u-b5b91edad075"></a>
### `await_block`

`export function await_block(node, get_input, pending_fn, then_fn, catch_fn)` · [packages/svelte/src/internal/client/dom/blocks/await.js:L42-L76][f1]

Renders pending/then/catch snippets for a reactive promise input, including hydration-mismatch and stale-promise handling.

Each effect run re-reads get_input; an identical value returns early. During hydration, mismatch is detected when the anchor comment is HYDRATION_START_ELSE exactly when the input is a promise: all server nodes are removed, the anchor is reset, hydrating is turned off and restored at the end. A promise input sets resolved=false and attaches handlers that ignore late settlements (promise !== input), write via internal_set to input_source/error_source, and call update(THEN/CATCH, true); a rejection with no catch_fn rethrows error_source.v. While hydrating with a pending snippet the pending branch is created immediately; otherwise a microtask shows pending only if unresolved. A non-promise input writes directly to input_source and calls update(THEN, false). The effect's returned cleanup resets input to UNINITIALIZED, disabling pending promise callbacks. Sources are `source` in runes mode, `mutable_source` otherwise.

**Notes.**

- failure: Rejected promise with no catch_fn rethrows the stored error from error_source.v.
- condition: Promise callbacks compare `promise !== input` to ignore results from a superseded input.

calls: [packages/svelte/src/internal/client/dom/blocks/await.js:update](r4-dom-blocks.md#u-05916687a6e9), [is_promise](r5-internal-shared-utils.md#u-f3295568a063), [remove_nodes](r1-hydration-cursor.md#u-fc45567d72a4), [task.js-queues](r4-task-scheduling.md#u-2af0814cc5ec)

**Uncertainties.**

- Exact semantics of branch/pause_effect/resume_effect and internal_set are defined outside this file.

<a id="u-27ab3563c744"></a>
### `await.js module code (L1–L41)`

`module_region` · [packages/svelte/src/internal/client/dom/blocks/await.js:L1-L41][f1]

Imports for the await block plus the AwaitState constants PENDING (0), THEN (1), CATCH (2) used to select which snippet effect is active.

<a id="u-25a3a4f1f827"></a>
### `packages/svelte/src/internal/client/dom/blocks/key.js:key`

`export function key(node, get_key, render_fn)` · [packages/svelte/src/internal/client/dom/blocks/key.js:L18-L39][f2]

Re-renders its block whenever the key from get_key changes.

During hydration it advances past the hydrate node first; afterwards anchor becomes hydrate_node. It tracks the previous key (initialized to UNINITIALIZED) and picks not_equal or safe_not_equal depending on is_runes(). On change it creates a new effect via branch(() => render_fn(target)); if should_defer_append() is true (batched/deferred append), the new effect renders into an offscreen DocumentFragment containing a text anchor and commit is added as a batch callback, otherwise commit runs immediately. commit pauses the previous effect, and if an offscreen fragment exists it removes the text anchor inside it, inserts the fragment before the real anchor, and promotes pending_effect to the current effect.

calls: [is_runes](r4-component-context.md#u-71aba13a168a), [hydration.js-state-and-guards](r1-hydration-cursor.md#u-f1b7a30a3c1f), [operations.js-dom-helpers](r2-client-dom-core.md#u-d9a22fc32463), [packages/svelte/src/internal/client/reactivity/effects.js:block](r5-effects-module.md#u-75d755e7c63c), [effects.js-trivial-effect-factories](r5-effects-module.md#u-191f01511fb1), [packages/svelte/src/internal/client/dom/blocks/key.js:key](r4-dom-blocks.md#u-25a3a4f1f827)

**Uncertainties.**

- Semantics of safe_not_equal vs not_equal and of batch-callback timing live outside this file

<a id="u-2edc4e7a14f5"></a>
### `createRawSnippet`

`export function createRawSnippet(fn)` · [packages/svelte/src/internal/client/dom/blocks/snippet.js:L89-L119][f3]

Turns a user function returning {render, setup?} into a programmatic snippet.

When invoked with an anchor and getter params, it calls fn with the param values to get the snippet object. While hydrating it adopts the current hydrate_node as the element and advances hydration; otherwise it builds HTML from snippet.render().trim() via create_fragment_from_html, takes the first child as the element, and in DEV warns invalid_raw_snippet_render if the element has siblings or is not an ELEMENT_NODE, then inserts it before the anchor. It then runs snippet.setup?.(element), calls assign_nodes(element, element), and registers any function returned by setup via teardown for cleanup.

**Notes.**

- side_effect: Inserts DOM before the anchor only in the non-hydrating path
- contract: Only a function return from setup is registered as teardown; other values are ignored

calls: [create_fragment_from_html](r4-dom-elements.md#u-f51e86a3ef3c), [hydration.js-state-and-guards](r1-hydration-cursor.md#u-f1b7a30a3c1f), [assign_nodes](r2-client-dom-core.md#u-081194bea535), [effects.js-trivial-effect-factories](r5-effects-module.md#u-191f01511fb1)

**Uncertainties.**

- The returned snippet function's interaction with effect teardown of the surrounding branch is not visible here

<a id="u-398a190f3765"></a>
### `snippet`

`export function snippet(node, get_snippet, ...args)` · [packages/svelte/src/internal/client/dom/blocks/snippet.js:L27-L55][f3]

Renders a snippet function reactively inside an EFFECT_TRANSPARENT block.

The current snippet starts as noop and is compared against get_snippet() each run; when it changes, any existing snippet effect is destroyed and nulled. In DEV, if the new snippet is null or undefined it calls e.invalid_snippet(); the snippet is still invoked via branch (cast), so a null snippet here relies on noop behavior only until the first change — in production branch(() => snippet(...)) would be called on null and throw. After setting up the block, hydrating mode moves the anchor to hydrate_node.

**Notes.**

- failure: Production path has no null check before invoking snippet, unlike the DEV path

calls: [packages/svelte/src/internal/client/reactivity/effects.js:block](r5-effects-module.md#u-75d755e7c63c), [effects.js-trivial-effect-factories](r5-effects-module.md#u-191f01511fb1), [destroy_effect](r5-effects-module.md#u-214ad59ce57a); uses: [hydration.js-state-and-guards](r1-hydration-cursor.md#u-f1b7a30a3c1f)

**Uncertainties.**

- Whether e.invalid_snippet throws or only warns is defined in errors.js, not shown

<a id="u-4a27c635b68b"></a>
### `wrap_snippet`

`export function wrap_snippet(component, fn)` · [packages/svelte/src/internal/client/dom/blocks/snippet.js:L63-L64][f3]

Wraps a snippet function for development use: the wrapper saves dev_current_component_function, sets it to the owning component so ownership validation sees the right context, runs fn with the node and args, and always restores the previous component function in finally.

prevent_snippet_stringification is applied to the wrapper so treating the snippet as a string triggers a validation error.

calls: [set_dev_current_component_function](r4-component-context.md#u-1de56d41fa38), [prevent_snippet_stringification](r4-shared-runtime.md#u-f0c8633de633)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/blocks/await.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/blocks/key.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/blocks/snippet.js
