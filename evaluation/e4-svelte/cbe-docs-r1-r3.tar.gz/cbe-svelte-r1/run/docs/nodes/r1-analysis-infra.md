# Analysis Infrastructure & Visitor Helpers

**Capability.** Shared analysis state, function/snippet metadata initialization, dynamic-subtree marking, and validation of special elements like svelte:window.

Use this for the common plumbing every analysis visitor relies on. Individual warning rules live in the a11y child; element-validation rules for special elements live here.

**Depended on by.**

- [Analyze-phase AST visitors](r2-analyze-visitors.md) · graph-only · 13 edge(s)
- [Analyze Visitors](r5-analyze-visitors.md) · graph-only · 11 edge(s)

Parent: [Analysis Phase](r1-analysis.md)

## Units (7)

<a id="u-ee2ed2e166eb"></a>
### `AnalysisState`

`export interface AnalysisState` · [packages/svelte/src/compiler/phases/2-analyze/types.d.ts:L5-L30][f1]

Type-only declaration of the mutable state threaded through the analysis walkers.

Key fields: scope/scopes for the current node, the shared ComponentAnalysis, validated options, ast_type discriminating instance/template/module walks, fragment (template root only), parent_element tag name, has_props_rune, component_slots, current expression metadata, state_fields for class-state analysis, function_depth, and the legacy reactive_statement link.

**Uncertainties.**

- This is a declaration file; runtime behavior cannot be inferred beyond what consumers of these fields imply.

<a id="u-3e6e9a44c2b4"></a>
### `mark_subtree_dynamic`

`export function mark_subtree_dynamic(path)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/shared/fragment.js:L6-L15][f2]

Marks every enclosing Fragment node on the path as dynamic, walking from the innermost ancestor outwards.

Once a Fragment already has metadata.dynamic set to true, iteration stops early; otherwise each Fragment's flag is set to true. Called whenever template content becomes non-static.

<a id="u-98e829315086"></a>
### `visit_function`

`export function visit_function(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/shared/function.js:L8-L31][f3]

Initializes function-node metadata (hoisted=false, hoisted_params=[], scope) and continues traversal with an incremented function_depth and a cleared `expression` state.

When the current state has an active `expression` (reactive-expression context), every reference in the new scope whose binding belongs to an outer function (binding.scope.function_depth < current scope's function_depth) is added to context.state.expression.references, capturing cross-function dependencies.

imports: [function.js module code (L1–L7)][f3]

**Uncertainties.**

- The exact meaning of `expression` state and how references are consumed is defined by callers not in this file.

<a id="u-5fc246db911c"></a>
### `is_resolved_snippet`

`export function is_resolved_snippet(binding)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/shared/snippets.js:L8-L17][f4]

Decides whether a binding unambiguously identifies the snippet a component may render.

True when the binding is null/unbound, an import, a prop/rest_prop/bindable_prop, or its initial node is a SnippetBlock; false otherwise. Used by visit_component to classify snippet resolution.

<a id="u-43b79d8932ce"></a>
### `disallow_children`

`export function disallow_children(node)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/shared/special-element.js:L7-L16][f5]

Rejects any content inside svelte:body, svelte:document, svelte:options, or svelte:window.

If the fragment has at least one node, it raises svelte_meta_invalid_content with a span from the first node's start to the last node's end; an empty fragment is allowed.

<a id="u-de902d0a63f3"></a>
### `packages/svelte/src/compiler/phases/2-analyze/visitors/SvelteWindow.js:SvelteWindow`

`export function SvelteWindow(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/SvelteWindow.js:L11-L24][f6]

Validates `<svelte:window>` usage.

It forbids child elements via `disallow_children`, then for each attribute raises `e.illegal_element_attribute(attribute, 'svelte:window')` when the attribute is a SpreadAttribute or a non-event Attribute — only event attributes are permitted. Descent continues afterwards.

calls: [disallow_children](r1-analysis-infra.md#u-43b79d8932ce), [is_event_attribute](r5-compiler-ast-utils.md#u-1c2da82112be)

<a id="u-c7e949fd4745"></a>
### `UseDirective`

`export function UseDirective(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/UseDirective.js:L9-L12][f7]

Marks the subtree containing an action directive (`use:`) as dynamic via `mark_subtree_dynamic(context.path)` and continues descent.

calls: [mark_subtree_dynamic](r1-analysis-infra.md#u-3e6e9a44c2b4)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/types.d.ts
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/shared/fragment.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/shared/function.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/shared/snippets.js
[f5]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/shared/special-element.js
[f6]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/SvelteWindow.js
[f7]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/UseDirective.js
