# Client Transform

**Capability.** Generates the client-side component module: visitors rewrite runes/legacy syntax into runtime calls, template state becomes DOM instantiation, and types define the transform state.

Visitors, template emission, and state types are split because they change independently. Read visitors per syntax feature, template code for how DOM is built.

**Children.**

- [Client Transform Visitors](r5-client-transform-visitors.md) `r5-client-transform-visitors` · 16 unit(s)
- [Template Emission](r5-client-template-transform.md) `r5-client-template-transform` · 3 unit(s)
- [Client Transform State Types](r5-client-transform-types.md) `r5-client-transform-types` · 2 unit(s)

Parent: [Transform Phase](r5-transform.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
