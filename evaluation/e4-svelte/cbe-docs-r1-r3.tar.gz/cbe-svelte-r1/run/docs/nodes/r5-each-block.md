# Each Block

**Capability.** Renders and reconciles keyed and unkeyed each blocks: item effects, a doubly linked item chain, LCS-style diffing, DOM moving, and coordinated pause/destroy of removed rows.

Use to understand list diffing and row lifecycle; reconciliation links, moves, creates, updates, and pauses items through the effect machinery. Module-level current_each_item supports animate: directives.

**Depends on.**

- [Effect Lifecycle](r5-effects-module.md) · graph-confirmed · 11 edge(s)
- [Signal Core](r5-signal-core.md) · graph-confirmed · 2 edge(s)
- [Hydration Cursor State](r1-hydration-cursor.md) · graph-only · 10 edge(s)

Parent: [Client Runtime](r5-client-runtime.md)

## Units (19)

<a id="u-a4e1b3df9530"></a>
### `each`

`export function each(node, flags, get_collection, get_key, render_fn, fallback_fn = n…` · [packages/svelte/src/internal/client/dom/blocks/each.js:L119-L162][f1]

Sets up a keyed each block: controlled-block anchoring, the derived collection, and the commit wrapper that delegates to reconcile and manages the fallback.

For a controlled block (EACH_IS_CONTROLLED), during hydration the anchor is the first child comment/text node, otherwise a fresh text node appended to the parent. The collection is wrapped in derived_safe_equal, normalizing arrays, null/undefined (treated as empty), and iterables via array_from; a mutated store yields a new array so the derived still updates. `commit` runs reconcile against the current array, then if a fallback_fn exists: an empty array resumes or creates the fallback effect, a non-empty array pauses and nulls it.

calls: [reconcile](r5-each-block.md#u-4538273d00cc), [derived_safe_equal](r2-client-reactivity.md#u-15f47648fe69)

<a id="u-6ae9823f394c"></a>
### `packages/svelte/src/internal/client/dom/blocks/each.js:each`

`export function each(node, flags, get_collection, get_key, render_fn, fallback_fn = n…` · [packages/svelte/src/internal/client/dom/blocks/each.js:L188-L336][f1]

The each block's reactive effect body.

It reads the derived array and skips work if the array was already empty and stays empty. During hydration it compares the HYDRATION_START_ELSE instruction against emptiness: a mismatch removes the server DOM and switches out of hydration mode. While hydrating it creates items from server nodes, breaking early at a HYDRATION_END comment (recording a mismatch and stopping hydration), then removes excess nodes via remove_nodes; an empty array with a fallback_fn branches the fallback. Otherwise, if should_defer_append(), it pre-creates/resumes items into offscreen_items (updating existing items only when item/index reactive flags are set), marks effects of removed keys as skipped in the current batch, and schedules commit via batch.add_callback; else commit runs synchronously. On mismatch, hydrating is restored. Finally the array is re-read to stabilize the reactive graph, and the anchor becomes the hydration node when hydrating.

calls: [create_item](r5-each-block.md#u-12c0d32d8f83), [update_item](r5-each-block.md#u-bc4a3f237b08), [read_hydration_instruction](r1-hydration-cursor.md#u-97280e054ad7), [batch.js-batch-class](r3-runtime-reactivity-batching.md#u-6d22ee98690b)

**Uncertainties.**

- should_defer_append's exact triggering conditions live in operations.js.

<a id="u-12c0d32d8f83"></a>
### `create_item`

`function create_item( anchor, state, prev, next, value, key, index, render_fn, flags,…` · [packages/svelte/src/internal/client/dom/blocks/each.js:L622-L695][f1]

Creates one each item and its rendering effect.

Depending on flags it makes the value a mutable_source, a plain source, or raw data, and the index a source or plain number; in DEV with reactive values it attaches a trace function reading the collection at the item index. It sets current_each_item while rendering (restoring the previous value in finally), creates an anchor text node in a fragment when no anchor was passed, branches render_fn to produce the effect, and splices the item and its effect into the prev/next chain — updating state.first only when not deferred. The new item is returned.

calls: [effects.js-trivial-effect-factories](r5-effects-module.md#u-191f01511fb1)

**Uncertainties.**

- The second `branch` argument (`hydrating`) has no local definition here; its effect is not verifiable in this file.

<a id="u-4538273d00cc"></a>
### `reconcile`

`function reconcile( each_effect, array, state, offscreen_items, anchor, render_fn, fl…` · [packages/svelte/src/internal/client/dom/blocks/each.js:L352-L586][f1]

Reconciles the rendered items against the new array using a longest-common-subsequence-style list diff over the key-linked item chain.

When EACH_IS_ANIMATED is set, existing items are measured and queued for animation. For each array entry: a missing key either revives a matching offscreen item (relinked into the chain and moved via move) or creates a new item anchored at the current position, resetting the matched/stashed buffers; an existing key is updated via update_item when reactive flags are set, resumed if inert, and moved when out of place — choosing between moving later stashed items forward (when the stashed run is longer than the matched run) or moving the earlier item back. Skipped keys advance `current`, recording non-inert items in `seen`. Afterwards, all remaining current and seen non-inert items are collected and removed via pause_effects (with a controlled anchor when the array became empty), inert items excluded since their outro already handles removal; animated items get fix() calls and a microtask applies animations. Finally the effect's first/last links are updated, and leftover offscreen items are destroyed and the map cleared.

calls: [create_item](r5-each-block.md#u-12c0d32d8f83), [update_item](r5-each-block.md#u-bc4a3f237b08), [pause_effects](r5-each-block.md#u-1c55b7a0d0a9), [move](r5-each-block.md#u-3dcc1178b952)

**Uncertainties.**

- The animation helper methods measure/unfix/fix/apply are defined outside this file.

<a id="u-bc4a3f237b08"></a>
### `update_item`

`function update_item(item, value, index, type)` · [packages/svelte/src/internal/client/dom/blocks/each.js:L595-L605][f1]

Pushes a new value/index into an existing item: with EACH_ITEM_REACTIVE it internal_sets the item value; with EACH_INDEX_REACTIVE it internal_sets the index source, otherwise it assigns the index as a plain number.

<a id="u-ea8a4b98c012"></a>
### `link`

`function link(state, prev, next)` · [packages/svelte/src/internal/client/dom/blocks/each.js:L720-L732][f1]

Relinks the doubly linked each-item chain: a null prev makes `next` the new state.first, otherwise prev.next (and prev.e.next) are set; a non-null next gets its prev (and e.prev) set accordingly, with effect-level links tolerating null neighbors.

<a id="u-3dcc1178b952"></a>
### `move`

`function move(item, next, anchor)` · [packages/svelte/src/internal/client/dom/blocks/each.js:L702-L713][f1]

Moves an item's DOM range before the destination: it walks the item's nodes from its effect's nodes_start until the start of the next item's nodes (or the anchor) and inserts each node before the destination item's first node (or anchor).

<a id="u-1c55b7a0d0a9"></a>
### `pause_effects`

`function pause_effects(state, items, controlled_anchor)` · [packages/svelte/src/internal/client/dom/blocks/each.js:L73-L107][f1]

Pauses many each-item effects at once and coordinates their teardown.

It first collects child transitions via pause_children for every item. If the removed set is non-empty, has no transitions, and a controlled anchor was supplied, it takes the fast path: the parent element's text content is cleared, the anchor is re-appended, the items map is cleared, and the surviving chain is relinked in one step. Otherwise, and always in the run_out_transitions callback, each removed item's key is deleted from the items map, its list links are spliced out via link, and its effect is destroyed (skipping destruction on the controlled fast path since the DOM was already cleared).

calls: [link](r5-each-block.md#u-ea8a4b98c012)

<a id="u-66d4f51e1d58"></a>
### `index`

`export function index(_, i)` · [packages/svelte/src/internal/client/dom/blocks/each.js:L62-L64][f1]

Key helper returning the raw index, used for unkeyed each blocks.

<a id="u-bde2be852937"></a>
### `set_current_each_item`

`export function set_current_each_item(item)` · [packages/svelte/src/internal/client/dom/blocks/each.js:L54-L56][f1]

Trivial setter for the module-level current_each_item.

<a id="u-362daaf39053"></a>
### `each.js module code (L1–L53)`

`module_region` · [packages/svelte/src/internal/client/dom/blocks/each.js:L1-L53][f1]

Imports plus the exported module-level `current_each_item` used so animate: directives can find the row being updated.

<a id="u-90cad81abf43"></a>
### `each.js module code (L586–L594)`

`module_region` · [packages/svelte/src/internal/client/dom/blocks/each.js:L586-L594][f1]

Continuation region before update_item; no separate behavior.

<a id="u-982ea51b7ae7"></a>
### `each.js module code (L605–L621)`

`module_region` · [packages/svelte/src/internal/client/dom/blocks/each.js:L605-L621][f1]

Continuation region before create_item; no separate behavior.

<a id="u-e140ae346112"></a>
### `each.js module code (L56–L61)`

`module_region` · [packages/svelte/src/internal/client/dom/blocks/each.js:L56-L61][f1]

Continuation region between exports; no separate behavior.

<a id="u-b8cc3b4c8cd3"></a>
### `each.js module code (L695–L701)`

`module_region` · [packages/svelte/src/internal/client/dom/blocks/each.js:L695-L701][f1]

Continuation region before move; no separate behavior.

<a id="u-c6b0d2698560"></a>
### `each.js module code (L713–L719)`

`module_region` · [packages/svelte/src/internal/client/dom/blocks/each.js:L713-L719][f1]

Continuation region before link; no separate behavior.

<a id="u-b5cdbaa3be4b"></a>
### `each.js module code (L64–L72)`

`module_region` · [packages/svelte/src/internal/client/dom/blocks/each.js:L64-L72][f1]

Continuation region between exports; no separate behavior.

<a id="u-2504d2641767"></a>
### `each.js module code (L107–L118)`

`module_region` · [packages/svelte/src/internal/client/dom/blocks/each.js:L107-L118][f1]

Continuation region between exports; no separate behavior.

<a id="u-ae9e96383eca"></a>
### `each.js module code (L336–L351)`

`module_region` · [packages/svelte/src/internal/client/dom/blocks/each.js:L336-L351][f1]

Continuation region before reconcile; no separate behavior.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/blocks/each.js
