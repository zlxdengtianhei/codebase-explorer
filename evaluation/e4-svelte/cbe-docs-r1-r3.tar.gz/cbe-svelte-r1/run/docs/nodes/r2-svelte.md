# Svelte compiler and runtime

**Capability.** Owns the end-to-end responsibility of compiling Svelte components and running them: parsing, analysis, code generation, client/server runtime primitives, public reactive APIs, type contracts, and repo tooling.

This is the root of the responsibility tree. Reader enters here to see the split between the compiler pipeline (parse → analyze → transform, plus preprocess/sourcemap support) and the runtime (client reactivity/DOM, server rendering, shared utilities), alongside public reactive APIs, type definitions, benchmarks, and tooling. Each child owns one cohesive capability.

**Children.**

- [Component compiler pipeline](r2-compiler.md) `r2-compiler` · 0 unit(s)
- [Client runtime](r2-client-runtime.md) `r2-client-runtime` · 0 unit(s)
- [Server rendering runtime](r2-server-runtime.md) `r2-server-runtime` · 11 unit(s)
- [Shared runtime utilities](r2-shared-internals.md) `r2-shared-internals` · 12 unit(s)
- [Public reactive APIs](r2-public-reactive.md) `r2-public-reactive` · 0 unit(s)
- [Type contracts](r2-type-definitions.md) `r2-type-definitions` · 0 unit(s)
- [Reactivity benchmarks](r2-benchmarking.md) `r2-benchmarking` · 3 unit(s)
- [Repository tooling](r2-tooling.md) `r2-tooling` · 5 unit(s)
- [Animation runtime \(flip\)](r2-animate-flip.md) `r2-animate-flip` · 2 unit(s)

Parent: [Svelte Monorepo](svelte-monorepo.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
