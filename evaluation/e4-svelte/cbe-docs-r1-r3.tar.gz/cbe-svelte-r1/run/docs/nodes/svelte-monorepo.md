# Svelte Monorepo

**Capability.** End-to-end ownership of the Svelte framework: the multi-phase compiler that turns component source into client/server JavaScript, the client and server runtimes that compiled output calls into, platform-neutral shared utilities, the public reactive API and type surfaces, and the tooling that builds, benchmarks and polices all of it. Children are split by deliverable and responsibility, not by directory; shared infrastructure is kept separate from its consumers.

Start here to orient between compiler phases (parse → analyze → transform), the runtimes behind the emitted $.-calls, the exported APIs and their types, and the non-shipping developer tooling. Tracing any behavior begins by choosing compiler, runtime, public surface, or tooling. The five root candidate regions were merged into this single tree; region-level evidence shows dense mutual coupling among compiler, runtimes and shared utilities.

**Children.**

- [Svelte Monorepo](r1-root.md) `r1-root` · 0 unit(s)
- [Svelte compiler and runtime](r2-svelte.md) `r2-svelte` · 0 unit(s)
- [Svelte Repository](r3-svelte-monorepo.md) `r3-svelte-monorepo` · 0 unit(s)
- [Svelte Monorepo](r4-svelte-monorepo.md) `r4-svelte-monorepo` · 0 unit(s)
- [Svelte](r5-svelte.md) `r5-svelte` · 0 unit(s)
- [Compiler Pipeline](compiler-pipeline.md) `compiler-pipeline` · 0 unit(s)
- [Client Runtime](client-runtime.md) `client-runtime` · 0 unit(s)
- [Server Runtime](server-runtime.md) `server-runtime` · 0 unit(s)
- [Shared Runtime Utilities](shared-runtime.md) `shared-runtime` · 0 unit(s)
- [Public Reactive APIs & Features](public-reactive-apis.md) `public-reactive-apis` · 0 unit(s)
- [Public Type Declarations](public-types.md) `public-types` · 0 unit(s)
- [Reactivity & SSR Benchmarking](benchmarking.md) `benchmarking` · 0 unit(s)
- [Build & Repo Tooling](repo-tooling.md) `repo-tooling` · 0 unit(s)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
