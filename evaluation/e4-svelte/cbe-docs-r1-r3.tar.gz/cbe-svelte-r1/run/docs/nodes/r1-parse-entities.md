# HTML Entity Decoding

**Capability.** Decodes HTML character references during parsing: a spec-generated named-entity table plus regex construction, numeric validation, and context-aware replacement.

Use this when debugging how text and attribute values are decoded. The entities table is generated from the WHATWG spec; html.js builds a per-context regex and validates numeric code points.

Parent: [Compiler Pipeline](r1-compiler.md)

## Units (6)

<a id="u-582eaddeee2c"></a>
### `entities.js module code (L2–L1682)`

`module_region` · [packages/svelte/src/compiler/phases/1-parse/utils/entities.js:L2-L1682][f1]

Default-exports a large lookup table mapping HTML named character references (with trailing semicolon, e.g. 'amp;') to their Unicode code points, generated from the WHATWG entities.json spec.

Consumers of this module perform entity-name lookups during HTML parsing; the file contains no logic, only this data.

**Notes.**

- contract: Most keys include the trailing semicolon, but a subset of legacy HTML entity names (e.g. amp, lt, gt, quot, copy, nbsp) appear both with and without the semicolon, per the HTML spec.

**Uncertainties.**

- Whether the parse code that consumes this table expects semicolon-included keys, semicolon-less keys, or both is not visible in this file.

<a id="u-e2b2f46acbfa"></a>
### `entities.js module code (L1682–L2234)`

`module_region` · [packages/svelte/src/compiler/phases/1-parse/utils/entities.js:L1682-L2234][f1]

Tail region of the same default-exported entity table: additional named-character-reference entries mapping names to code points, down to the shortest legacy names (gt, lt).

Pure data with no behavior; documented here only to mark its scope as part of the table.

<a id="u-a03f13997ae5"></a>
### `decode_character_references`

`export function decode_character_references(html, is_attribute_value)` · [packages/svelte/src/compiler/phases/1-parse/utils/html.js:L40-L66][f2]

Replaces every HTML character reference in html with its decoded character, choosing the attribute-value or content pattern based on is_attribute_value.

For each match the captured entity resolves in three cases: not starting with '#' looks up the named table entities; '#x...' parses hexadecimal from index 2; otherwise decimal from index 1. When the resolved code is falsy (0/NaN/undefined, e.g. an unknown name slipped through or 'x' with no digits) the original match text is returned unchanged; otherwise the code point is validated by validate_code and emitted via String.fromCodePoint.

**Notes.**

- side_effect: Uses a stateful global regex with String.replace, which resets lastIndex per call, so repeated calls are safe despite the 'g' flag.

calls: [validate_code](r1-parse-entities.md#u-93702e15ee48); uses: [get_entity_pattern](r1-parse-entities.md#u-9eba4a60cf55)

**Uncertainties.**

- Named entity lookup relies on the entities.js table; any key whose value is 0 (if one exists) would be treated as invalid and left undecoded due to the falsy check.
- Behavior on lone surrogates depends on String.fromCodePoint rejecting NUL-converted surrogates; validate_code maps surrogates to 0 so this path yields U+0000.

<a id="u-9eba4a60cf55"></a>
### `get_entity_pattern`

`function get_entity_pattern(is_attribute_value)` · [packages/svelte/src/compiler/phases/1-parse/utils/html.js:L22-L31][f2]

Constructs the global RegExp matching HTML character references: numeric forms '#(?:x[a-fA-F\d]+|\d+)(?:;)?' alternated with every named entity key from entities.js, each transformed by reg_exp_entity for the given context.

The module builds two instances at load time — entity_pattern_content (attribute=false) and entity_pattern_attr_value (attribute=true) — so decode_character_references avoids rebuilding the very large pattern per call.

**Notes.**

- side_effect: Module-level constants entity_pattern_content and entity_pattern_attr_value are created once at import time; both flags are global ('g') regexes and are stateful across replace calls.

calls: [reg_exp_entity](r1-parse-entities.md#u-f66ddc0a405e)

**Uncertainties.**

- Regex construction cost and potential ReDoS characteristics of the huge alternation are not analyzed here.
- Requires Object.keys ordering of the entities module for alternation priority; longer/shorter entity overlaps resolve by regex alternation order, which is not verified.

<a id="u-f66ddc0a405e"></a>
### `reg_exp_entity`

`function reg_exp_entity(entity_name, is_attribute_value)` · [packages/svelte/src/compiler/phases/1-parse/utils/html.js:L12-L19][f2]

Builds the regex source fragment for one entity name per the HTML spec's named-character-reference rules.

In attribute values only, an entity not ending with ';' becomes 'name\\b(?!=)' so the reference is not decoded when the next character is '=', alphanumeric, or word character; all other cases return the name unchanged (content context matches literally).

**Notes.**

- condition: is_attribute_value changes the pattern only for entity names lacking a trailing semicolon.

**Uncertainties.**

- The lookahead only excludes '='; exclusion of letters/digits comes from \\b semantics, which also excludes '_' — whether trailing '_' blocks decoding depends on \\b behavior against entity names.

<a id="u-93702e15ee48"></a>
### `validate_code`

`function validate_code(code)` · [packages/svelte/src/compiler/phases/1-parse/utils/html.js:L79-L127][f2]

Maps a decoded numeric code point to a safe code point, following HTML's illegal-character rules, returning 0 (NUL) for forbidden ranges.

Cases in order: 10 (line feed) becomes 32 (space); below 128 returns as-is; 128–159 remaps through the windows_1252 table (e.g. € for 128); below 55296 returns as-is; 55296–57343 (UTF-16 surrogate halves) become NUL; the rest of the BMP, planes 1 (0x10000–0x1ffff) and 2 (0x20000–0x2ffff), and the supplementary special-purpose ranges 0xe0000–0xe07f and 0xe0100–0xe01ef return as-is; every other code point becomes NUL.

**Notes.**

- failure: There is no throwing path; out-of-range or forbidden codes are silently converted to U+0000.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/1-parse/utils/entities.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/1-parse/utils/html.js
