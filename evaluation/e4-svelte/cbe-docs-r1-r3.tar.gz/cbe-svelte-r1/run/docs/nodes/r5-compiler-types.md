# Compiler Type Definitions

**Capability.** Type-only contracts for compile options and results, validated options, phase state, and the CSS AST namespaces; no runtime behavior.

Consult when authoring tools against the compiler or phase state. Declaration-only and readable in isolation.

Parent: [Compiler](r5-compiler.md)

## Units (6)

<a id="u-8baf83940c2e"></a>
### `compiler-phases-types-d-ts-analysis-interfaces`

`export interface Js` · [packages/svelte/src/compiler/phases/types.d.ts:L12-L17][f1]

Type-only declarations describing compiler phase state; no runtime behavior.

`Js` and `Template` each pair an AST with its `Scope` and a node-to-scope map (`Js` adds `has_await`); `ReactiveStatement` holds a `$:` labeled statement's assignments and dependencies. `Analysis` carries module/component-shared state: module `Js`, deprecated `name`/`runes`, `immutable`, `tracing`, comments, per-class `StateField` maps, `accessors`, and the set of deriveds containing `await`. `ComponentAnalysis` extends it with root scope, instance/template state, collected elements for CSS pruning/scoping, rune flags (`runes`, `maybe_runes`), exports, `$$props`/`$$restProps`/`$$slots` usage, event directive/attribute flags, `custom_element` options (content of `<svelte:options customElement>` or the compiler-option boolean), style injection, reactive statements, `bind:group` mappings, slot names, CSS ast/hash/keyframes/`has_global`, deprecated `source`, and snippet tracking (`snippet_renderers` records whether each render tag/component resolved definitively; `snippets` holds locally declared snippet blocks). A module augmentation attaches `metadata` (`hoisted`, `hoisted_params`, `scope`) to estree arrow-function-expression, function-expression, and function-declaration nodes.

<a id="u-b61efd19fa24"></a>
### `css.d.ts-css-ast`

`export namespace _CSS { export interface BaseNode` · [packages/svelte/src/compiler/types/css.d.ts:L3-L7][f2]

Declares the compiler's internal `_CSS` namespace of stylesheet AST node shapes, from `StyleSheet` down to simple selectors, plus a walker-friendly `Node` union.

Every node has `start`/`end` and a literal `type`. `Rule.metadata` records scoping facts computed elsewhere: `has_global_selectors` when all relative selectors are global or global-like, and `is_global_block` when a `:global` selector makes everything inside unscoped. `ComplexSelector.metadata.used` is set in css-analyze for global selectors and in css-prune for others, per its comment. `RelativeSelector.metadata.is_global` is true only for wholly unscoped selectors: `:global(...).x` does not count, and `:global(...):is/where/not/has(...)` counts only when all child selectors are global; `is_global_like` covers `:root`, `:host`, `::view-transition`, and selectors after a `:global`. Simple selectors are data-only (`name`, nullable `matcher`/`value`/`flags` on `AttributeSelector`, nullable `args` on `PseudoClassSelector`, `NestingSelector.name` fixed to `'&'`). The trailing `Node` union exists, per comment, for zimmerframe walking.

imports: [template.d.ts-root-and-fragment](r3-compiler-ast-types.md#u-e8223dc323d4)

**Uncertainties.**

- `StyleSheet.attributes` is typed `any[]` with a TODO, so its real shape is not determined by this file

<a id="u-beaf4cda9e21"></a>
### `index.d.ts-compile-result-and-helpers`

`export interface CompileResult` · [packages/svelte/src/compiler/types/index.d.ts:L14-L50][f3]

Compile output and small helper types.

`CompileResult` carries `js` (code plus magic-string `SourceMap`), a nullable `css` object with `code`, `map`, and `hasGlobal` (whether global rules are included), a `warnings` array whose entries expose `code`, `message`, and optional `start`/`end` locations, `metadata.runes` (always `true` for `compileModule`), and `ast: any`. `Warning` and `CompileError` are empty interfaces extending `ICompileDiagnostic`, so all members come from that import. `CssHashGetter` is the callback behind the `cssHash` option: it receives `name`, `filename`, `css`, and a `hash` function and returns the scoped-class name string. `OptimizeOptions` holds only `hydrate?: boolean`.

imports: [template.d.ts-root-and-fragment](r3-compiler-ast-types.md#u-e8223dc323d4)

**Uncertainties.**

- `ICompileDiagnostic` members are not visible here, so Warning/CompileError field detail is unproven in this file.

<a id="u-be1f92cc5d0b"></a>
### `index.d.ts-validated-options-and-metadata`

`export type ValidatedModuleCompileOptions = Omit<Required<ModuleCompileOptions>, 'roo…` · [packages/svelte/src/compiler/types/index.d.ts:L242-L244][f3]

Validated option shapes and compiler-internal metadata types.

`ValidatedModuleCompileOptions` makes all `ModuleCompileOptions` fields required except `rootDir`, which stays optional-valued but declared. `ValidatedCompileOptions` combines that with a `Required<CompileOptions>` that omits module keys plus `name`, `compatibility`, filenames, `sourcemap`, and `runes`, then re-adds those keys with their original optional types, requires `compatibility` fully, and adds `customElementOptions: AST.SvelteOptions['customElement']` — the comment notes the deliberately scary types make some fields required yet still undefined-able. `BindingKind` enumerates binding classifications ('normal', 'prop', 'bindable_prop', 'rest_prop', 'raw_state', 'state', 'derived', 'each', 'snippet', 'store_sub', 'legacy_reactive', 'template', 'static'). `DeclarationKind` lists var/let/const/function/import/param/rest_param/synthetic. `ExpressionMetadata` summarizes an expression for the compiler: eagerly referenced `dependencies` vs all `references` (sets of `Binding`), plus boolean flags `has_state` (directly or possibly via member/call), `has_call` (often needs deriving), `has_await`, `has_member_expression`, and `has_assignment`. `StateField` describes a state-rune field: rune name, the `PropertyDefinition` or `AssignmentExpression`, its `PrivateIdentifier` key, and the rune `CallExpression`.

uses: [template.d.ts-root-and-fragment](r3-compiler-ast-types.md#u-e8223dc323d4)

**Uncertainties.**

- Whether `rootDir` in `ValidatedModuleCompileOptions` becomes required or merely non-Omit'ed is ambiguous from `Omit<Required<...>, 'rootDir'> & { rootDir: ... }`; the re-added type is the original optional one.

<a id="u-9a76119419fb"></a>
### `CompileOptions`

`export interface CompileOptions extends ModuleCompileOptions` · [packages/svelte/src/compiler/types/index.d.ts:L67-L196][f3]

Component compile option surface extending `ModuleCompileOptions`.

Documented semantics: `css: 'injected'` embeds styles in the head/injects on mount (always injected in customElement mode) while `'external'` only returns CSS in the result; `cssHash` defaults to `svelte-${hash(css)}`; `fragments` chooses faster `html` template cloning (incompatible with CSP `require-trusted-types-for 'script'`) versus slower `tree`; `runes: true` forces runes mode, `false` ignores runes, `undefined` infers from code (`true` for modules; forcing `true` in a shared config would affect `node_modules`). `accessors` and `immutable` are deprecated with no effect in runes mode; `accessors` defaults to true with `customElement: true`. `compatibility.componentApi: 4` reshapes the default export for Svelte 4-style instantiation. Also: `customElement`, `namespace` ('html'|'svg'|'mathml'), `preserveComments`, `preserveWhitespace`, `discloseVersion`, `sourcemap` merged into the output map, `outputFilename`, `cssOutputFilename`, `hmr`, `modernAst` (default in Svelte 6, removed in 7).

**Notes.**

- contract: All fields optional; defaults in docstrings are enforced elsewhere, not in this declaration file.

inherits: [ModuleCompileOptions](r5-compiler-types.md#u-82d2d1acb3ba); uses: [index.d.ts-compile-result-and-helpers](r5-compiler-types.md#u-beaf4cda9e21)

<a id="u-82d2d1acb3ba"></a>
### `ModuleCompileOptions`

`export interface ModuleCompileOptions` · [packages/svelte/src/compiler/types/index.d.ts:L198-L238][f3]

Options shared by component and module compilation.

`dev: true` adds runtime checks and debugging output. `generate` selects client output, server (SSR) output, or `false`, which generates nothing — documented as useful for tooling that only wants warnings. `filename` feeds sourcemaps and debug hints and is normally set by the bundler plugin; `rootDir` prevents filesystem paths leaking and defaults to `process.cwd()` on node-like environments. `warningFilter` receives each `Warning` and keeps it on `true`, discards it on `false`. `experimental.async` (since 5.36) enables `await` in deriveds, template expressions, and component top level.

uses: [index.d.ts-compile-result-and-helpers](r5-compiler-types.md#u-beaf4cda9e21)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/types.d.ts
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/types/css.d.ts
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/types/index.d.ts
