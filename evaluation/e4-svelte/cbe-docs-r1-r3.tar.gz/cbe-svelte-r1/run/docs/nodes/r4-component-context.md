# Component Context

**Capability.** Maintains the module-level component_context stack and dev stack: push/pop of component frames, runes-vs-legacy mode detection, context maps seeded from ancestors for setContext/getContext/hasContext/getAllContexts, and dev metadata attachment.

Nearly every runtime feature consults this module (is_runes, set_component_context, dev stack). Use get_or_init_context_map as the hub for the public context APIs; push/pop define component lifecycle framing.

**Depends on.**

- [Task Scheduling](r4-task-scheduling.md) · model-inferred · 0 edge(s)

**Depended on by.**

- [Client Reactivity](r4-client-reactivity.md) · graph-confirmed · 3 edge(s)
- [DOM Blocks](r4-dom-blocks.md) · graph-confirmed · 10 edge(s)
- [DOM Elements & Events](r4-dom-elements.md) · model-inferred · 0 edge(s)

Parent: [Client Runtime](r4-client-runtime.md)

## Units (13)

<a id="u-19355b3b3598"></a>
### `packages/svelte/src/internal/client/context.js:add_svelte_meta`

`export function add_svelte_meta(callback, type, component, line, column, additional)` · [packages/svelte/src/internal/client/context.js:L36-L53][f1]

Runs a callback with a temporary dev-stack entry describing a block or component location.

It links the new entry to the current dev_stack as parent, takes the file from component[FILENAME], spreads optional additional properties over the entry, and restores the previous dev_stack in a finally block, so the entry never leaks even if the callback throws.

uses: [set_dev_stack](r4-component-context.md#u-946a777d9545)

**Uncertainties.**

- Behavior when component lacks the FILENAME property is not visible here

<a id="u-c05aabfae0d1"></a>
### `getAllContexts`

`export function getAllContexts()` · [packages/svelte/src/internal/client/context.js:L134-L137][f1]

Returns the whole context Map of the closest parent component via get_or_init_context_map; the map is lazily created and seeded from ancestors, so callers can copy context when programmatically creating components.

calls: [get_or_init_context_map](r4-component-context.md#u-99872e9939fa)

<a id="u-abbef1c88791"></a>
### `getContext`

`export function getContext(key)` · [packages/svelte/src/internal/client/context.js:L80-L84][f1]

Returns the value stored under `key` in the current component's context map, obtained via get_or_init_context_map.

A missing key yields undefined rather than an error; calling outside component initialisation triggers the lifecycle_outside_component error through the shared helper.

calls: [get_or_init_context_map](r4-component-context.md#u-99872e9939fa)

<a id="u-99872e9939fa"></a>
### `get_or_init_context_map`

`function get_or_init_context_map(name)` · [packages/svelte/src/internal/client/context.js:L201-L207][f1]

Shared helper for the public context APIs: calls e.lifecycle_outside_component(name) when there is no current component context; otherwise lazily creates the frame's context Map seeded with the nearest ancestor context map (or nothing when none exists) and caches it on the frame via ??.

calls: [get_parent_context](r4-component-context.md#u-3b276f9d9206)

<a id="u-3b276f9d9206"></a>
### `get_parent_context`

`function get_parent_context(component_context)` · [packages/svelte/src/internal/client/context.js:L213-L223][f1]

Walks the parent chain of a ComponentContext and returns the first non-null context map found, or null when no ancestor has one.

<a id="u-3341dee08c97"></a>
### `hasContext`

`export function hasContext(key)` · [packages/svelte/src/internal/client/context.js:L121-L124][f1]

Returns whether `key` exists in the current component's context map, delegating the outside-component check to get_or_init_context_map.

calls: [get_or_init_context_map](r4-component-context.md#u-99872e9939fa)

<a id="u-71aba13a168a"></a>
### `is_runes`

`export function is_runes()` · [packages/svelte/src/internal/client/context.js:L193-L195][f1]

Reports whether the current component runs in runes mode: true when legacy mode is off, or when there is an active component context whose `l` field is null (push sets `l` non-null only for legacy components).

uses: [push](r4-component-context.md#u-9761c5d7c2ee)

<a id="u-fe159451466a"></a>
### `pop`

`export function pop(component)` · [packages/svelte/src/internal/client/context.js:L167-L190][f1]

Pops the current component context frame when a component finishes.

Any deferred effects on the frame are cleared and flushed immediately by creating a user effect per function; if a `component` argument is given it is stored as the frame's exports. component_context then moves to the parent frame, and in DEV dev_current_component_function is restored from the parent frame's function or null. Returns the `component` argument, or a fresh empty object when undefined.

**Notes.**

- side_effect: Deferred effects (context.e) are drained into created user effects before the frame is popped.

calls: [user_effect](r5-effects-module.md#u-2ecd21794ced)

**Uncertainties.**

- The for-of iterator resolution is ambiguous in the supplied graph evidence; it is a plain iteration over the effects array

<a id="u-9761c5d7c2ee"></a>
### `push`

`export function push(props, runes = false, fn)` · [packages/svelte/src/internal/client/context.js:L145-L160][f1]

Pushes a new component context frame onto the module-level component_context stack when a component starts.

The frame links to the previous context as parent, resets context map, deferred effects and exports to null, stores props, and creates a legacy object (signals, update callbacks, `$:` list) only when legacy_mode_flag is on and `runes` is false. In DEV it records the component function on the frame and in dev_current_component_function.

uses: [set_dev_current_component_function](r4-component-context.md#u-1de56d41fa38)

<a id="u-64fe4521bdfe"></a>
### `setContext`

`export function setContext(key, context)` · [packages/svelte/src/internal/client/context.js:L98-L112][f1]

Stores `context` under `key` in the current component's context map and returns it, making it visible to children via getContext.

In async mode the write is valid only when there is no active reaction, the active effect has the BRANCH_EFFECT flag, and EFFECT_RAN is not set; otherwise e.set_context_after_init is called before storing. Outside async mode the value is stored unconditionally.

**Notes.**

- failure: In async mode with invalid timing, e.set_context_after_init is called before the map write; whether it always throws is not shown in this file.

calls: [get_or_init_context_map](r4-component-context.md#u-99872e9939fa)

**Uncertainties.**

- Whether e.set_context_after_init throws is inferred from its name and usage, not visible here

<a id="u-4155baf87729"></a>
### `set_component_context`

`export function set_component_context(context)` · [packages/svelte/src/internal/client/context.js:L14-L16][f1]

Replaces the module-level component_context variable with the supplied ComponentContext or null.

<a id="u-1de56d41fa38"></a>
### `set_dev_current_component_function`

`export function set_dev_current_component_function(fn)` · [packages/svelte/src/internal/client/context.js:L68-L70][f1]

Replaces the module-level dev_current_component_function variable with the supplied component function.

<a id="u-946a777d9545"></a>
### `set_dev_stack`

`export function set_dev_stack(stack)` · [packages/svelte/src/internal/client/context.js:L22-L24][f1]

Replaces the module-level dev_stack variable with the supplied DevStackEntry or null.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/context.js
