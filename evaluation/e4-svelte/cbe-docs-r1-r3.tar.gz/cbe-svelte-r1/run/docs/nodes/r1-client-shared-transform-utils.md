# Shared Client Transform Builders

**Capability.** Reusable builders for component invocations, sibling text processing, static-element detection, expression memoization, template chunks, legacy reactivity, and dev validation statements.

Use this when a change affects multiple visitors' output shape. Memoizer hoists complex expressions into $0/$1 placeholders; component.js serializes full component calls; fragment.js groups sibling text into single update units.

**Depends on.**

- [Template Serialization](r1-client-template.md) · graph-confirmed · 5 edge(s)
- [DOM & Rune Constant Predicates](r1-dom-dom-utils.md) · graph-confirmed · 1 edge(s)

**Depended on by.**

- [Client Block & Element Visitors](r1-client-block-visitors.md) · graph-confirmed · 6 edge(s)
- [Client Transform](r3-compiler-transform-client.md) · graph-only · 23 edge(s)
- [Client code generation](r2-transform-client.md) · graph-only · 16 edge(s)

Parent: [Client Transform Phase](r1-client-transform.md)

## Units (12)

<a id="u-af8f6b0917f6"></a>
### `component-js-build-component`

`export function build_component(node, component_name, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/component.js:L18-L83][f1]

Serializes a component invocation (Component/SvelteComponent/SvelteSelf) into client statements: it collects props, spreads, events, slots, custom CSS properties, and bind:this handling into a props expression, then emits the component call wrapped in optional dynamic-component and async machinery.

Attributes are processed by type: LetDirectives become hoisted `let` statements, named slot lets apply to the component itself when a `slot` attribute or property exists; OnDirectives build event handlers (wrapped in `$.once` for the `once` modifier, and a handler without expression marks `needs_props`) grouped into a `$$events` prop; SpreadAttributes become thunks when stateful, wrapped via the Memoizer when they contain awaits/calls; Attributes push getter props when stateful else init props, with `--`-prefixed names routed to custom CSS props and values memoized via `$.get(memoizer.add(...))` when they contain calls or awaits, and non-identifier/non-member tag chunks forcing derived wrapping; BindDirectives emit dev-mode ownership-validation initializers for prop/bindable_prop bindings (skipped for `this` and SequenceExpressions), convert SequenceExpressions into paired get/set props or bind_this, and delay binding props so spreads cannot overwrite them (store subscriptions additionally marked with `$.mark_store_binding`); AttachTags become `$.attachment` props, wrapped in an arrow with a `$.noop` fallback when the attachment expression is not statically a function. Delayed props are flushed before events are pushed. Children are grouped by slot (`determine_slot` or 'default'); SnippetBlocks become props directly plus `$$slots` entries (with `children` interop mapping to `default`); each non-empty slot becomes an arrow with `$$anchor`/`$$slotProps` and slot-scope lets. A default slot with no lets and no SvelteFragment lets becomes a `children` prop (wrapped in `$.wrap_snippet` in dev) plus `$$slots.default: true`; otherwise it becomes `$$slots.default` plus an erroring `$.invalid_default_snippet` children prop. Legacy-mode BindDirectives add `$$legacy: true`. One or more props use `$.spread_props`; the call target uses a generated `intermediate_name` inside `$.component` for dynamic components (binding initializers move inside the dynamic arrow), otherwise the plain component member. bind_this wraps the call via `build_bind_this`. Custom CSS props wrap the anchor in `g` (svg) or a `display: contents` wrapper element, emit `$.css_props`, the call on `anchor.lastChild`, and `$.reset`; otherwise a template comment is pushed and the call statement is wrapped by `add_svelte_meta`. If async values exist the statements are wrapped in `$.async`; otherwise a block is returned only when multiple statements exist.

**Notes.**

- side_effect: Pushes into context.state.init, context.state.analysis flags (needs_props, needs_mutation_validation), and the output template (push_element/push_comment/pop_element/set_prop).
- condition: Memoization: expressions with awaits or calls are extracted via Memoizer and, in runes mode, declared as `$.derived` lets; non-runes uses safe deriveds.

calls: [build_attribute_value](r3-compiler-transform-client.md#u-2462157783c9), [build_event_handler](r2-transform-client.md#u-227977f005ec), [build_bind_this](r1-client-shared-transform-utils.md#u-62396233e782), [validate_binding](r1-client-shared-transform-utils.md#u-91b59b999e05), [add_svelte_meta](r1-client-shared-transform-utils.md#u-75700db42066), [determine_slot](r3-compiler-shared-utils.md#u-ead26eb5b43f); uses: [Memoizer](r1-client-shared-transform-utils.md#u-76b08484949a)

**Uncertainties.**

- Exact runtime shape of the emitted statements depends on builder helpers (b.*) and internal state fields (template, metadata.namespace, scopes) not supplied here.

<a id="u-c654162d4a2b"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/fragment.js:is_static_element`

`function is_static_element(node, state)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/fragment.js:L129-L173][f2]

Decides whether a RegularElement can be baked fully into the HTML template string, i.e. needs no runtime attribute or event work.

It fails for dynamically-marked fragments and custom elements (whose attributes go through properties). Any non-Attribute node, event attribute, attribute whose name cannot_be_set_statically, 'dir', value/checked on input/textarea, value on option, or loading on img disqualifies it (src/loading must be applied after DOM insertion for lazy loading). Attributes must be static: value === true (boolean-present) or a text attribute. Everything else qualifies as static.

calls: [is_custom_element_node](r4-compiler-model.md#u-ea1f0b51e1e8); uses: [is_event_attribute](r5-compiler-ast-utils.md#u-1c2da82112be), [is_text_attribute](r5-compiler-ast-utils.md#u-ec400088cae5), [cannot_be_set_statically](r1-dom-dom-utils.md#u-2389aaa6b031)

<a id="u-7091653bb501"></a>
### `process_children`

`export function process_children(nodes, initial, is_element, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/fragment.js:L19-L29][f2]

Transforms a list of sibling template nodes, grouping adjacent Text/ExpressionTag nodes into sequences that share one text node and one update, and creating anchor references for everything else.

Tracks `skipped` static siblings to emit $.sibling/$.next traversals for hydration. Each sequence flush: if entirely static Text it is pushed via template.push_text and skipped advances; otherwise a space text node is pushed to the template, build_template_chunk produces the dynamic value, and flush_node names the text node (single-expression sequences get is_text true to handle SSR omitting empty text nodes); the $.set_text update goes to the update phase unless has_state and within_bound_contenteditable dictate an init-time direct nodeValue assignment. Non-text nodes: static elements (per is_static_element) just increment skipped; a lone EachBlock child of an element is marked is_controlled; any other node gets an anchor variable from flush_node and is visited with state.node set to it. After the loop, trailing static nodes trigger a $.next traversal of skipped-1 steps when hydrating.

**Notes.**

- condition: within_bound_contenteditable (state.metadata) forces direct nodeValue assignment instead of the reactive update path.

calls: [build_template_chunk](r1-client-shared-transform-utils.md#u-d8d503fc4b7b), [packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/fragment.js:is_static_element](r1-client-shared-transform-utils.md#u-c654162d4a2b)

**Uncertainties.**

- The mapping from AST Text/ExpressionTag node shapes to the synthetic {type:'Text', data, raw, start, end} pushed in flush_sequence is not shown here.
- get_node's is_text flag's runtime effect depends on the $.sibling signature, not supplied.

<a id="u-76b08484949a"></a>
### `Memoizer`

`class Memoizer` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/utils.js:L17-L28][f3]

Extracts complex expressions (calls, awaits) out of template output, replacing each with a placeholder identifier that later becomes `$0`, `$1`, and so on.

add returns a placeholder `#` identifier and records the expression as sync or async depending on has_await. apply renames all placeholders to `$<index>` in insertion order (sync first, then async) and returns them, so it must run before the ids are referenced. deriveds emits `let` declarations binding each sync id to `$.derived` (runes) or `$.derived_safe_equal` (legacy) over a thunk of the expression. async_ids lists async placeholders; async_values/sync_values return arrays of thunks of the original expressions, or undefined when that category is empty.

<a id="u-d8d503fc4b7b"></a>
### `build_template_chunk`

`export function build_template_chunk( values, context, state = context.state, memoize…` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/utils.js:L71-L159][f3]

Serializes a mixed list of Text and ExpressionTag chunks into a single expression: a template literal when multiple dynamic chunks exist, a literal when only static text remains, or a lone expression when there is exactly one dynamic chunk.

Per chunk: Text appends to the current quasi; null-valued Literals contribute nothing; other expressions are built with build_expression, memoized, and evaluated. has_state is true when any chunk has await, or has state that is not statically known. For a single-chunk input the (possibly literal-folded) expression is returned directly to allow `set_text` work instead of `template_effect` overhead. In multi-chunk mode, `?? null` / `|| null` logical expressions with a null right side have the null replaced with '' (undefined-avoidance); statically known values fold into the quasi; unknown but possibly-undefined values get `?? ''` appended; unknown values start a new quasi (tail quasi flagged as tail). Finally each quasi's raw string is sanitized and the result is a template expression or a plain literal.

**Notes.**

- condition: An `undefined` identifier is only treated as dynamic when a binding named 'undefined' exists in scope.

calls: [sanitize_template_string](r3-compiler-shared-utils.md#u-01781e43d6ff)

**Uncertainties.**

- Scope.evaluate semantics (is_known, is_defined, value) come from scope.js and are not supplied here.

<a id="u-cd5eb51d389f"></a>
### `build_expression`

`export function build_expression(context, expression, metadata, state = context.state)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/utils.js:L393-L433][f3]

Visits an expression and, only in legacy non-runes analysis (neither runes nor maybe_runes), replicates coarse-grained legacy reactivity.

If the expression has no calls, member expressions, or assignments the visited value is returned unchanged. Otherwise a sequence expression is built: for each reference that is not a plain non-import binding, a getter is created with build_getter and wrapped in `$.deep_read_state` when the binding is a bindable_prop, template binding, import, `$$props`, or `$$restProps`; finally the visited value is wrapped in `$.untrack` over a thunk and appended, so reads happen eagerly while evaluation is untracked.

calls: [build_getter](r4-client-transform.md#u-66a19e20e1f1)

<a id="u-b84b76b77b0e"></a>
### `build_render_statement`

`export function build_render_statement(state)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/utils.js:L164-L182][f3]

Wraps accumulated state.update statements into a `$.template_effect` call whose first argument is an arrow over the memoizer's applied ids; a single ExpressionStatement body is inlined directly, otherwise a block is emitted.

Sync and async memoized values follow as thunk arrays.

<a id="u-62396233e782"></a>
### `build_bind_this`

`export function build_bind_this(expression, value, { state, visit })` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/utils.js:L211-L233][f3]

Serializes `bind:this={expr}` for components and elements into a `$.bind_this` call.

A SequenceExpression is handled directly: the visited expressions become the set and get functions. Otherwise the expression is walked for referenced identifiers; each unique, real reference bound in an enclosing EachBlock scope is collected as an extra parameter to the get/set arrows, its visited value passed as a teardown array thunk, and its read transform neutralized to identity so old values can be nulled on teardown (a legacy-only behavior with acknowledged staleness for complex member expressions). The get expression and the assignment `expr = $$value` are visited under the adjusted transform, and all MemberExpression nodes along the get chain are marked optional so teardown avoids runtime exceptions on missing properties.

<a id="u-75700db42066"></a>
### `add_svelte_meta`

`export function add_svelte_meta(expression, node, type, additional)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/utils.js:L443-L464][f3]

Wraps a block/component statement with dev stack tracking.

Outside dev, or when the node has no start or the locator yields no location, the expression is returned as a plain statement. Otherwise the expression is wrapped in a zero-argument arrow and passed to `$.add_svelte_meta` along with the type literal, the component name identifier, line/column literals, and an optional object literal built from `additional` entries.

**Uncertainties.**

- locator's failure modes come from state.js, not supplied here.

<a id="u-47fb5120ded1"></a>
### `parse_directive_name`

`export function parse_directive_name(name)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/utils.js:L189-L203][f3]

Turns a legacy directive name like `a.b-c` into a member expression chain.

Segments split on '.'; each subsequent segment becomes a member access, computed (literal key) when it is not a valid identifier, otherwise a plain identifier property.

<a id="u-91b59b999e05"></a>
### `validate_binding`

`export function validate_binding(state, binding, expression)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/utils.js:L292-L325][f3]

Emits a dev-mode `$.validate_binding` statement for reactive member bindings.

SequenceExpression bindings and `$store.foo` (store_sub) bindings are skipped. The call receives the binding's source text, a thunk of the object expression (prefixed by `$.mark_store_binding` when state.store_to_invalidate is set), a thunk of the property (literal name when non-computed), and the line/column from locator when available. The statement is pushed to state.init.

**Uncertainties.**

- locator's return shape comes from state.js, not supplied here.

<a id="u-a58215b09609"></a>
### `validate_mutation`

`export function validate_mutation(node, context, expression)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/utils.js:L333-L385][f3]

In dev mode, wraps mutations of component props with an ownership-validation call.

It returns the original expression unchanged when not in dev, the target is not a MemberExpression, 'ownership_invalid_mutation' is ignored, the root object cannot be resolved, or its binding is neither `prop` nor `bindable_prop`. Otherwise it flags needs_mutation_validation and builds a property path from the member chain: literal keys and non-computed identifiers become literals, computed identifiers go through the binding's read transform when present, and any other property node type aborts wrapping and returns the original expression. The result is `$$ownership_validator.mutate` called with the binding's prop_alias, the path array, the original expression, and location line/column.

**Notes.**

- side_effect: Sets state.analysis.needs_mutation_validation when wrapping occurs.

calls: [is_ignored](r5-compiler-state-errors.md#u-468324b42cee)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/component.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/fragment.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/utils.js
