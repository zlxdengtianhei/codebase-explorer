# Public Type Declarations

**Capability.** The d.ts surface for every public module (svelte core, action, animate, attachments, compiler, easing, events, legacy, motion, reactivity, server, store, transition), ambient runes, the *.svelte module declaration, and deprecated compatibility paths.

Use this to find the published types for any public entry point. Legacy compiler interfaces/preprocess declarations exist only for backwards compatibility; the ambient section types runes and .svelte imports.

Parent: [Svelte Monorepo](r1-root.md)

## Units (18)

<a id="u-e8db83ebe95d"></a>
### `index.d.ts-svelte-core`

`declare module 'svelte' { /** * @deprecated In Svelte 4, components are classes. In S…` · [packages/svelte/types/index.d.ts:L1-L21][f1]

Declares the public 'svelte' module types and runtime function signatures for components, lifecycle, context, mounting, and flush control.

Key type surface: ComponentConstructorOptions and Properties support the legacy Svelte 4 class API; SvelteComponent is the deprecated base class with $destroy/$on/$set and type-checking-only fields ($$prop_def, $$events_def, $$slot_def, $$bindings) explicitly absent at runtime; Component is the Svelte 5 callable-component type taking (internals, props) and returning exports plus optional deprecated $on/$set; SvelteComponentTyped extends SvelteComponent unchanged; ComponentEvents/ComponentProps/ComponentType extract generics via conditional inference. Brand/Branded define ComponentInternals, an opaque branded marker; Snippet types renderable snippet blocks, rejecting array (rest-style) parameter types via a length conditional; EventDispatcher types createEventDispatcher dispatchers with detail required unless the event type includes undefined or null; MountOptions makes props optional exactly when {} extends Props. Runtime declarations include getAbortSignal (AbortSignal aborting when the enclosing derived/effect re-runs or is destroyed), onMount (runs once after mount, optional synchronous cleanup return, skipped in SSR), onDestroy (only lifecycle hook running inside server-side components), createEventDispatcher (deprecated CustomEvent dispatcher, non-bubbling), beforeUpdate/afterUpdate (deprecated, map to $effect.pre/$effect), flushSync (synchronously applies pending updates, returns callback result), createRawSnippet, the context functions (all requiring initialization-time invocation), mount/hydrate (return component exports), unmount (Promise resolving after outro transitions when options.outro is true), tick, settled (5.36+), and untrack (reads fn's state without registering dependencies).

**Notes.**

- contract: Members documented as 'does not exist at runtime' ($$prop_def, $$events_def, $$slot_def, $$bindings, z_$$bindings) exist only for type checking.
- condition: ComponentProps resolves via conditional types: SvelteComponent branch first, then Component, else never; MountOptions requires props unless Props is fully optional.
- side_effect: unmount returns Promise<void> since 5.13.0 (void before), resolving after transitions when outro is true.

**Uncertainties.**

- All bodies are ambient declarations; the actual implementation behavior of mount, hydrate, unmount, and the lifecycle functions is not present in this file and rests on the JSDoc contracts only.

<a id="u-40d3ad8ec5cd"></a>
### `index.d.ts-svelte-action`

`declare module 'svelte/action' { /** * Actions can return an object containing the tw…` · [packages/svelte/types/index.d.ts:L555-L594][f1]

Declares the 'svelte/action' module types for typing element actions.

ActionReturn describes the optional object an action may return: update is invoked whenever the action's parameter changes after markup updates, destroy runs after the element is unmounted, and $$_attributes is a type-checking-only marker that has no runtime effect (attributes are declared via the Attributes generic). Action is the callable interface for actions themselves: it receives a node and a parameter, where the parameter argument is optional exactly when undefined extends Parameter (so Action<E> and Action<E, undefined> mean a parameterless action), and it returns void or an ActionReturn.

**Uncertainties.**

- Runtime wiring of update/destroy calls happens in the compiler/client internals, not in this declaration file.

<a id="u-d7d8d35a9cf0"></a>
### `index.d.ts-svelte-animate`

`declare module 'svelte/animate' { // todo: same as Transition, should it be shared? e…` · [packages/svelte/types/index.d.ts:L629-L637][f1]

Declares the 'svelte/animate' module: AnimationConfig (delay, duration, easing, css, tick — the shape both animate and transition functions produce) and FlipParams, plus the flip function signature.

flip computes an element's start and end rectangles ({from, to} DOMRects) and returns an AnimationConfig that translates between them using the First-Last-Invert-Play technique; duration may be a fixed number or a function of the transition length.

**Uncertainties.**

- flip's implementation is not in this file; only its signature and JSDoc contract are declared.

<a id="u-63c07e455474"></a>
### `index.d.ts-svelte-attachments`

`declare module 'svelte/attachments' { /** * An [attachment](https://svelte.dev/docs/s…` · [packages/svelte/types/index.d.ts:L657-L667][f1]

Declares the 'svelte/attachments' module.

Attachment is a function run when its element mounts to the DOM, optionally returning a cleanup called on removal; it is attached via {@attach ...} or by spreading an object containing a key from createAttachmentKey (which returns such a symbol; since 5.29). fromAction converts an existing action into an attachment with identical behavior; two overloads exist — one where the second argument is a function returning the action argument (for parameterized actions) and one for parameterless actions. The module also re-declares local, non-exported Action and ActionReturn interfaces mirroring the svelte/action shapes: ActionReturn carries optional update (called when the parameter changes) and destroy (called at unmount) plus the type-checking-only $$_attributes marker; Action's parameter is optional exactly when undefined extends Parameter.

**Uncertainties.**

- fromAction's actual adaptation behavior (e.g. whether action update is re-invoked on reactive argument changes) is described by JSDoc only; no implementation is present.

<a id="u-338d3e0e5164"></a>
### `index.d.ts-svelte-compiler`

`declare module 'svelte/compiler' { import type { SourceMap } from 'magic-string'; imp…` · [packages/svelte/types/index.d.ts:L796-L806][f1]

Declares the 'svelte/compiler' module: the compile pipeline types and the AST shape.

compile(source, CompileOptions) returns CompileResult with js (code + SourceMap from magic-string), css (null or {code, map, hasGlobal}), warnings (Warning[]), metadata.runes, and ast; compileModule compiles JS/TS source containing runes with ModuleCompileOptions and always reports runes: true per its metadata doc. Two parse overloads exist: with {modern: true} it returns AST.Root, otherwise (modern false/omitted, the Svelte 5 default) Record<string, any> legacy AST; the modern default flips in Svelte 6. walk is a deprecated never-returning stub redirecting to estree-walker. Preprocessor types (MarkupPreprocessor, Preprocessor, PreprocessorGroup) describe source transforms returning Processed (code, opaque map, dependencies, attributes) or void/promise; preprocess runs a group or array of groups and yields Promise<Processed>; migrate best-effort converts legacy code toward runes/event attributes/render tags, returning {code} and possibly throwing on complex input. CompileOptions extends ModuleCompileOptions (dev, generate 'client'|'server'|false, filename, rootDir, warningFilter, experimental.async since 5.36) with name, customElement, deprecated accessors/immutable, namespace, css 'injected'|'external', cssHash, preserveComments, preserveWhitespace, fragments 'html'|'tree', runes (undefined infers; true forces project-wide), discloseVersion, compatibility.componentApi, sourcemap, output filenames, hmr, and modernAst. The AST namespace defines BaseNode (type/start/end), Root (options, fragment, css/instance/module scripts, comments), all tag/directive/block/element node interfaces (with fixed name literals for svelte:* elements; SvelteOptionsRaw is an intermediate parse-only node), union aliases (Directive, Block, ElementLike, Tag, TemplateNode, SvelteNode), Script/JSComment, and the _CSS (CSS) namespace covering StyleSheet, Atrule, Rule, selector structures, and declarations. ICompileDiagnostic is the shared diagnostic shape (code, message, optional stack/filename/start/end/position/frame); Warning and CompileError both extend it.

**Uncertainties.**

- Actual compile/parse/migrate implementations are external; the docstring claims (e.g. migrate throwing on complex code) are unverified here.
- This file also declares VERSION via `export const VERSION: string` in the same module region; it is covered by the residual region rather than a symbol unit.

<a id="u-5742a45481a0"></a>
### `index.d.ts-svelte-easing`

`declare module 'svelte/easing' { export function linear(t: number): number;` · [packages/svelte/types/index.d.ts:L1759-L1760][f1]

Declares the 'svelte/easing' module: 31 easing function signatures (linear; back/bounce/circ/cubic/elastic/expo/quad/quart/quint/sine families each in In/Out/InOut variants).

Each takes progress t as a number and returns the eased progress as a number. All are ambient declarations with no bodies; the curve formulas live in the implementation module.

<a id="u-c8276b9865ba"></a>
### `index.d.ts-svelte-events`

`declare module 'svelte/events' { // Once https://github.com/microsoft/TypeScript/issu…` · [packages/svelte/types/index.d.ts:L2720-L2733][f1]

Declares the 'svelte/events' module: five on overloads returning a handler-removal function.

Overloads cover Window (keyed by WindowEventMap), Document (DocumentEventMap), HTMLElement (HTMLElementEventMap with the element as handler `this`), MediaQueryList (MediaQueryListEventMap), and a general EventTarget/string/EventListener fallback; all accept optional AddEventListenerOptions. Using on instead of addEventListener preserves correct ordering relative to declaratively added handlers (attributes like onclick), which Svelte dispatches via event delegation; a source comment notes the overloads sit outside the JSDoc due to an unresolved TypeScript issue.

**Uncertainties.**

- The delegation-ordering guarantee is stated in JSDoc; the mechanism is implemented elsewhere.

<a id="u-03c5e2d39440"></a>
### `index.d.ts-svelte-legacy`

`declare module 'svelte/legacy' { import type { ComponentConstructorOptions, SvelteCom…` · [packages/svelte/types/index.d.ts:L1825-L1835][f1]

Declares the 'svelte/legacy' module, a compatibility layer for migrating Svelte 4 code.

createClassComponent takes Svelte 4-style options plus a component (class type or function Component) and returns a SvelteComponent instance extended with the component's Exports; asClassComponent performs the inverse, converting a component function into a Svelte 4 compatible constructor class type. Both are deprecated stop-gaps. run executes a function once immediately on the server and like $effect.pre on the client, allowing a cleanup return. handlers combines multiple listeners into a single EventListener, and createBubbler returns a function that, given an event type, produces a handler mimicking Svelte 4 delegated on: directives (returning a boolean). LegacyComponentType types values usable both as constructor and function during the transition. The remaining functions substitute individual event modifiers: trusted, self, stopPropagation, once, stopImmediatePropagation, and preventDefault wrap a handler to emulate the named modifier; passive and nonpassive are element actions taking [event, handler] to attach listeners with the respective listener options.

**Uncertainties.**

- Only signatures are declared; modifier semantics (e.g. trusted checking event.isTrusted) come from JSDoc naming, not visible implementation.

<a id="u-099f7e077413"></a>
### `index.d.ts-svelte-motion`

`class and the Spring interface are merged into one with some things only // existing …` · [packages/svelte/types/index.d.ts:L1910-L1917][f1]

Declares the 'svelte/motion' module combining legacy stores and new classes.

The Spring interface (declaration-merged with the Spring class, a documented compatibility device) carries the legacy spring store surface: Readable subscribe, update, and deprecated markers noting which members exist only on the legacy store. The Spring class (since 5.8.0) wraps a value that moves spring-like toward target: constructor(value, SpringOpts{stiffness,damping,precision}), static of(fn, options) creating a spring bound to fn's return value inside an effect root, set(value, options) returning a Promise resolving when current catches up (options.instant snaps immediately; options.preserveMomentum continues the trajectory for the given milliseconds; legacy hard/soft options do nothing on the class), plus damping/precision/stiffness fields, target, and a current getter. The legacy spring function creates the deprecated animated store, and SpringUpdateOpts members are split by applicability between store and class. Tweened (set/update returning Promises, TweenedOptions with delay, duration possibly a (from,to) function, easing, interpolate) types the deprecated tweened store. The Tween class mirrors Spring but tweens per delay/duration/easing: static of, constructor, set(value, options) returning a Promise resolving on catch-up, current getter, and target setter/getter, with #private state. Subscriber/Unsubscriber/Updater and the local Readable interface provide the store plumbing (subscribe(run, invalidate?) returning Unsubscriber). prefersReducedMotion is exported as a MediaQuery (since 5.7.0).

**Uncertainties.**

- Spring/Tween animation internals are not in this file; Promise resolution timing and momentum behavior rest on the JSDoc contracts.
- Spring.of/Tween.of must be called inside an effect root per JSDoc; the failure mode when called outside is not declared here.

<a id="u-2e80ad11ffc8"></a>
### `index.d.ts-svelte-reactivity`

`class SvelteDate extends Date` · [packages/svelte/types/index.d.ts:L2129-L2164][f1]

Declares the 'svelte/reactivity' module: reactive built-in wrappers plus the subscriber machinery.

SvelteDate extends Date, SvelteSet extends Set, SvelteMap extends Map, SvelteURL extends URL (with a searchParams getter returning SvelteURLSearchParams), and SvelteURLSearchParams extends URLSearchParams with an internal [REPLACE] symbol method — reading their contents in effects/derivatives triggers re-evaluation on mutation; note their values are NOT deeply reactive. Each has a private field and a permissive constructor (Iterable or null/undefined for the collections, variadic for Date). MediaQuery (since 5.7.0) extends ReactiveValue<boolean>: constructor(query, fallback?) where fallback serves as the server value; the JSDoc warns that SSR cannot know the match state, so content may change on hydration. createSubscriber(start) returns a subscribe function integrating external event systems: when called inside an effect, start runs once with an update function whose invocation re-runs the reading effects; a cleanup returned from start runs when all reading effects are destroyed, and start is called only once across multiple active effects. ReactiveValue is a non-exported base class with constructor(fn, onsubscribe) and a current getter; MediaQuery and the window module values build on it.

**Uncertainties.**

- The effect-tracking mechanics of createSubscriber and ReactiveValue.current are documented by JSDoc and an in-file MediaQuery example; no implementation is visible.
- [REPLACE]'s exact use (likely internal param replacement) is inferred from its name and signature only.

<a id="u-947227f6f508"></a>
### `index.d.ts-reactivity-window`

`declare module 'svelte/reactivity/window' { /** * scrollX.current is a reactive vie…` · [packages/svelte/types/index.d.ts:L2403-L2456][f1]

Declares 'svelte/reactivity/window' (since 5.11.0): ReactiveValue views of window/navigator state — scrollX, scrollY, innerWidth, innerHeight, outerWidth, outerHeight, screenLeft, screenTop, online, and devicePixelRatio.

Each exposes a current getter returning number | undefined (boolean | undefined for online), undefined on the server. screenLeft/screenTop update inside requestAnimationFrame callbacks; devicePixelRatio responds to zoom on Chrome but not Firefox/Safari per the docs. A private, non-exported ReactiveValue class (constructor(fn, onsubscribe), current getter, #private state) backs these declarations and matches the base class declared in 'svelte/reactivity'. The exported value constants themselves are ambient const declarations without separate symbol units in this batch.

**Uncertainties.**

- The method::current inventory entry spans lines 2403-2456, which in the source correspond to the window-value const declarations region; it is grouped here rather than documented as an independent function.
- Update triggers for each window value (event listeners vs rAF polling) are stated only in JSDoc.

<a id="u-ec9a25d94e38"></a>
### `index.d.ts-svelte-server`

`declare module 'svelte/server' { import type { ComponentProps, Component, SvelteCompo…` · [packages/svelte/types/index.d.ts:L2468-L2495][f1]

Declares the 'svelte/server' module.

render is server-only (requires the `server` compile option) and returns RenderOutput {head, html (deprecated), body} for populating server-rendered HTML. Its two call signatures are conditionally shaped by props: when {} extends Props the options argument is optional with optional props, otherwise both the options argument and its props field are required; props omit $$slots/$$events, and options also accept context and idPrefix. The component argument accepts either a ComponentType class or a Component function depending on the Comp branch. The local Subscriber/Unsubscriber/Updater type aliases restate the standard store callback shapes for internal typing.

**Uncertainties.**

- Runtime behavior (what lands in head vs body, error handling outside the server build) is not declared beyond the docstring.

<a id="u-f5d9e325deea"></a>
### `index.d.ts-svelte-store`

`export type StartStopNotifier<T> = ( set: (value: T) => void, update: (fn: Updater<T>…` · [packages/svelte/types/index.d.ts:L2527-L2530][f1]

Declares the 'svelte/store' module: the store contract and factory signatures.

Core aliases: Subscriber<T> receives values, Unsubscriber tears down a subscription, Updater<T> maps a value to the next, StartStopNotifier<T> gets (set, update) and may return a cleanup invoked when the last subscriber leaves. Readable exposes subscribe(run, invalidate?) returning Unsubscriber; Writable adds set and update. writable creates a Writable from an initial value plus optional start/stop notifier; readable creates a Readable. Two derived overloads exist: one whose fn receives (values, set, update) and may return an Unsubscriber for manual/async aggregation, and a simpler fn(values) form; both accept an optional initial value. toStore has two overloads — (get, set) yields Writable, (get) alone yields Readable; fromStore has two overloads converting a Writable into {current} (mutable) or a Readable into {readonly current}. readonly wraps a store as Readable; get reads the current value by subscribing and immediately unsubscribing. Stores accepts one Readable, a tuple/array of Readables, or an array; StoresValues maps those to their value types.

**Uncertainties.**

- Notifier/start-stop lifecycle and derived auto-unsubscribing are contract-level only; implementations are outside this file.

<a id="u-bb306d302dcf"></a>
### `index.d.ts-svelte-transition`

`declare module 'svelte/transition' { export type EasingFunction = (t: number) => number;` · [packages/svelte/types/index.d.ts:L2612-L2613][f1]

Declares the 'svelte/transition' module.

EasingFunction maps t to eased t; TransitionConfig is the result shape transitions return (delay, duration, easing, css(t,u), tick(t,u)). Parameter interfaces: BlurParams (blur filter plus opacity, amount), FadeParams (delay/duration/easing), FlyParams (x/y offsets and opacity), SlideParams (axis 'x'|'y'), ScaleParams (start scale, opacity), DrawParams (speed and/or duration possibly length-based), CrossfadeParams. Transition functions blur, fade, fly, slide, and scale each take an Element and optional params and return a TransitionConfig; in-transitions animate from the given values to defaults, out-transitions reverse. draw requires an SVGElement with getTotalLength (the type itself carries the method), animating the stroke from invisible to drawn (in) or erasing it (out). crossfade takes CrossfadeParams plus a fallback(node, params, intro) TransitionConfig producer and returns a [send, receive] pair: each takes (node, params & {key}) and returns a function yielding a TransitionConfig that transforms toward/away from the counterpart element's position while fading, falling back when no counterpart matches the key.

**Uncertainties.**

- Actual CSS/tick generation is implementation-side; default parameter values (e.g. fade duration) are not visible in this file.

<a id="u-84154ae71531"></a>
### `index.d.ts-runes-ambient`

`declare function $state<T>(initial: T): T;` · [packages/svelte/types/index.d.ts:L3107-L3107][f1]

Declares the ambient compiler runes used inside Svelte files.

$state has two call overloads ($state(initial): T and $state(): T | undefined) and a namespace holding $state.raw (non-deeply-reactive state that must be reassigned rather than mutated, same two overloads), $state.snapshot (deep static copy typed by the conditional Snapshot<T>: primitives pass through, Cloneable values map through NonReactive so SvelteDate/Map/Set become their plain builtins, toJSON results are used, arrays and string-keyed objects map recursively, everything else is never), plus supporting aliases (Primitive, TypedArray, Cloneable enumerating structuredClone-able types, NonReactive) and never-typed deprecated constants (apply, arguments, bind, call, caller, length, name, prototype, toString) that exist solely to stop unhelpful intellisense on Function members. $derived(expression) and $derived.by(fn) declare derived state, with the same never-typed guard constants. $effect(fn) runs after DOM updates whenever dependencies change, calling a returned cleanup before re-run or unmount, and never during SSR; its namespace declares pre (runs before DOM update), pending (count of pending promises in the current boundary, excluding children), tracking (whether code runs in a tracking context), and root (creates a non-tracked, manually-cleaned scope, returning the cleanup function), again with guard constants. $props() is any; $props.id() (since 5.20) returns an instance-unique id stable across SSR hydration. $bindable(fallback?) marks a prop bindable by parents. $inspect(...values) returns {with(fn)} where fn receives 'init' or 'update' plus the values, defaulting to console logging; $inspect.trace(name?) must be the first statement of a function body and reports which state changes re-ran an effect. $host() (client-side, custom-element components only) returns the containing HTMLElement.

**Notes.**

- contract: Every rune namespace repeats a set of never-typed, deprecated Function-member constants purely to suppress intellisense; they are not runtime API.
- condition: $state.snapshot's Snapshot<T> resolves to never for objects without a string index signature, so such values are not valid snapshot inputs.

**Uncertainties.**

- Runes are compiler-instrumented declarations; their runtime behavior (cleanup ordering, tracking semantics, pending boundary counting) is asserted by docstrings, with no implementation in this file.

<a id="u-5883a54cb163"></a>
### `index.d.ts-svelte-module-declaration`

`declare module '*.svelte' { // use prettier-ignore for a while because of https://git…` · [packages/svelte/types/index.d.ts:L3085-L3091][f1]

Declares the ambient '*.svelte' module: importing a .svelte file yields a default export typed as both a Svelte 4-style class constructor and a callable component via LegacyComponentType (const Comp), with a parallel type alias Comp = SvelteComponent so the import also satisfies the modern Component typing.

Imports come from 'svelte' and 'svelte/legacy'; a prettier-ignore comment defers formatting due to a language-tools constraint.

<a id="u-01d21c20318b"></a>
### `index.d.ts-compiler-interfaces-legacy`

`declare module 'svelte/types/compiler/interfaces' { import type { Location } from 'lo…` · [packages/svelte/types/index.d.ts:L2880-L2883][f1]

Declares 'svelte/types/compiler/interfaces', a deprecated compatibility module.

CompileOptions re-exports CompileOptions_1 and Warning re-exports Warning_1 (both marked 'import from svelte instead'); Warning_1 extends ICompileDiagnostic. CssHashGetter maps {name, filename, css, hash} to a class-name string. CompileOptions_1 is a full duplicate of the public CompileOptions (name, customElement, accessors/immutable deprecated, namespace, css injected/external, cssHash, preserveComments, preserveWhitespace, fragments, runes, discloseVersion, compatibility.componentApi, sourcemap, output filenames, hmr, modernAst) extending a local ModuleCompileOptions duplicate (dev, generate, filename, rootDir, warningFilter typed against Warning_1, experimental.async). Namespace is 'html'|'svg'|'mathml'; ICompileDiagnostic repeats the shared diagnostic shape with Location from locate-character.

<a id="u-dc7d03919889"></a>
### `index.d.ts-preprocess-legacy`

`declare module 'svelte/types/compiler/preprocess' { /** @deprecated import this from …` · [packages/svelte/types/index.d.ts:L2782-L2784][f1]

Declares 'svelte/types/compiler/preprocess', a deprecated compatibility module.

The exported type aliases MarkupPreprocessor, Preprocessor, PreprocessorGroup, Processed, and SveltePreprocessor simply re-export the corresponding _1 declarations from 'svelte/preprocess' (MarkupPreprocessor_1 takes {content, filename?}; Preprocessor_1 adds tag attributes and markup; PreprocessorGroup_1 bundles name/markup/style/script; Processed_1 carries code, opaque map, dependencies, attributes, toString; SveltePreprocessor_1 is a factory type returning Required<Pick<PreprocessorGroup_1, PreprocessorType>> and is itself marked deprecated in favor of hand-writing the utility). All members redirect imports to 'svelte/preprocess'.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/types/index.d.ts
