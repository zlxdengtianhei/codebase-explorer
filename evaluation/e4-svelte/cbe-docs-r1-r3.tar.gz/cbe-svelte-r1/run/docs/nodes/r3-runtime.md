# Client Runtime Internals

**Capability.** Implements Svelte's client-side execution: the fine-grained reactivity engine (sources, batches, proxies), DOM block/element operations, bindings, transitions at the runtime level, legacy-mode invalidation, dev-mode diagnostics, and the internal entry guard/version disclosure.

Use this subtree when debugging runtime behavior such as effect scheduling, `$state` proxies, DOM updates, or dev warnings/errors. Public feature modules (motion, transitions, reactive window) build on the reactivity and DOM layers here.

**Children.**

- [Signal Sources](r3-runtime-reactivity-sources.md) `r3-runtime-reactivity-sources` · 12 unit(s)
- [Effect Batching & Scheduling](r3-runtime-reactivity-batching.md) `r3-runtime-reactivity-batching` · 8 unit(s)
- [Deep Reactivity Proxies](r3-runtime-proxy.md) `r3-runtime-proxy` · 5 unit(s)
- [Dev-Mode Diagnostics](r3-runtime-dev-tools.md) `r3-runtime-dev-tools` · 10 unit(s)
- [DOM Blocks](r3-runtime-dom-blocks.md) `r3-runtime-dom-blocks` · 9 unit(s)
- [DOM Elements, Bindings & Transitions](r3-runtime-dom-elements.md) `r3-runtime-dom-elements` · 18 unit(s)
- [Legacy Reactivity Mode](r3-runtime-legacy-mode.md) `r3-runtime-legacy-mode` · 2 unit(s)

**Depended on by.**

- [Ambient & Language-Server Types](r3-types.md) · model-inferred · 0 edge(s)

Parent: [Svelte Repository](r3-svelte-monorepo.md)

## Units (2)

<a id="u-84fe56d94225"></a>
### `index-js-internal`

`group` · [packages/svelte/src/internal/index.js:L1-L5][f1]

Guard module that unconditionally throws an Error at import time.

Importing 'svelte/internal' — the private module used by Svelte 4 compiled components that no longer exists in Svelte 5 — fails with a message explaining it is not public API and directing library authors to file an issue with their use case. A leading TODO comment notes possible best-effort legacy private API shims in the future; currently none are implemented, so any import always throws.

<a id="u-ea8222e99174"></a>
### `disclose-version.js module code (L1–L6)`

`module_region` · [packages/svelte/src/internal/disclose-version.js:L1-L6][f2]

Module side effect that registers the public Svelte version in the browser for devtools.

Only when `typeof window !== 'undefined'`, it creates `window.__svelte` and its `v` property (a Set, via nullish-assignment) and adds PUBLIC_VERSION imported from ../version.js. On the server (no window) the module does nothing.

imports: [disclose-version.js module code (L1–L6)](r3-runtime.md#u-ea8222e99174)

**Uncertainties.**

- The graph hints at an unresolved `require`; only the window-guarded Set add is visible in source.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/index.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/disclose-version.js
