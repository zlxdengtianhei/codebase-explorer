# Client Runtime

**Capability.** Executes compiled client code: mounting and hydration, DOM attributes, hydration cursor tracking, boundary/async blocks, error propagation, reactive props and equality, dev diagnostics, and runtime mode flags.

Use this subtree to trace what the emitted $.-calls do at runtime. Mounting and hydration coordinate with the hydration cursor; boundaries own error/pending handling; props and equality underpin reactivity; dev modules add diagnostics only in development.

**Children.**

- [Mount, Hydrate & Unmount](r1-client-mounting.md) `r1-client-mounting` · 4 unit(s)
- [Hydration Cursor State](r1-hydration-cursor.md) `r1-hydration-cursor` · 3 unit(s)
- [DOM Attributes & Properties](r1-dom-attributes.md) `r1-dom-attributes` · 14 unit(s)
- [Boundary & Async Blocks](r1-boundary-blocks.md) `r1-boundary-blocks` · 19 unit(s)
- [Error Handling & Boundaries](r1-error-propagation.md) `r1-error-propagation` · 4 unit(s)
- [Reactive Props & Equality](r1-reactivity-primitives.md) `r1-reactivity-primitives` · 9 unit(s)
- [Client Dev Diagnostics & HMR](r1-client-dev-tools.md) `r1-client-dev-tools` · 3 unit(s)
- [Runtime Mode Flags](r1-mode-flags.md) `r1-mode-flags` · 3 unit(s)

Parent: [Svelte Monorepo](r1-root.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
