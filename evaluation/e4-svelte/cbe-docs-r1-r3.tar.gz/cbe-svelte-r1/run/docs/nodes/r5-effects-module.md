# Effect Lifecycle

**Capability.** Creates, validates, and tears down effects of every kind: user effects, pre-effects, render/template effects, block effects, component roots, $effect.root scopes, and transition-aware pause/resume of subtrees.

Use to understand effect creation flags, DEV placement guards, and the destroy/pause/resume machinery including out-transition deferral. Sits directly on top of signal-core status tracking.

**Depends on.**

- [Signal Core](r5-signal-core.md) · graph-confirmed · 13 edge(s)

**Depended on by.**

- [Attachments API](r5-attachments-api.md) · graph-confirmed · 1 edge(s)
- [Each Block](r5-each-block.md) · graph-confirmed · 11 edge(s)
- [Input Bindings](r5-input-bindings.md) · graph-confirmed · 5 edge(s)
- [Svelte 4 Compatibility Adapters](r5-legacy-adapters.md) · graph-confirmed · 1 edge(s)
- [Legacy Component Reactivity](r5-legacy-internal.md) · graph-confirmed · 3 edge(s)
- [Reactive Wrappers and Stores](r5-reactivity-wrappers.md) · graph-confirmed · 3 edge(s)
- [DOM Blocks](r4-dom-blocks.md) · graph-only · 18 edge(s)
- [Element integrations: custom elements, actions, bindings](r2-client-dom-elements.md) · graph-only · 15 edge(s)
- [Boundary & Async Blocks](r1-boundary-blocks.md) · graph-only · 13 edge(s)
- [DOM Blocks](r3-runtime-dom-blocks.md) · graph-only · 13 edge(s)
- [DOM Elements & Events](r4-dom-elements.md) · graph-only · 11 edge(s)

Parent: [Client Runtime](r5-client-runtime.md)

## Units (17)

<a id="u-b219b5c574b1"></a>
### `create_effect`

`function create_effect(type, fn, sync, push = true)` · [packages/svelte/src/internal/client/reactivity/effects.js:L86-L174][f1]

Core effect factory: builds the Effect object linked to the active effect as parent, inheriting component context and boundary `b`.

In DEV the parent chain skips inspect effects and the component function is recorded. If the parent is INERT the new effect becomes INERT too. When `sync`, the effect runs immediately via `update_effect`, marking EFFECT_RAN; a throw destroys the freshly created effect before rethrowing. Otherwise a non-null `fn` is scheduled for later. When pushing, a ran sync effect that needs no re-runs, DOM, or teardown (single or no child, not EFFECT_PRESERVED) is replaced by its child in the tree; the resulting node is linked under the parent via `push_effect`, and if created inside a derived (and not a root) it is also registered on that derived's effects list.

calls: [update_effect](r5-signal-core.md#u-e2ea8c85735e), [schedule_effect](r3-runtime-reactivity-batching.md#u-ce4f8d895426)

**Uncertainties.**

- Exact meaning of individual flag combinations (INSPECT_EFFECT skipping, EFFECT_PRESERVED) depends on constants and consumers outside this file

<a id="u-191f01511fb1"></a>
### `effects.js-trivial-effect-factories`

`function push_effect(effect, parent_effect)` · [packages/svelte/src/internal/client/reactivity/effects.js:L68-L77][f1]

Thin wrappers over `create_effect` and small flag helpers.

`push_effect` appends an effect to a parent's linked child list (setting first/last). `effect_tracking` reports whether dependency tracking is active (a reaction exists and untracking is off). `teardown` creates a clean RENDER_EFFECT whose sole job is running a teardown function. `create_user_effect` builds a deferred `$effect` (EFFECT|USER_EFFECT, not sync). `inspect_effect` builds an INSPECT_EFFECT run synchronously. `effect` builds a plain deferred EFFECT. `async_effect` builds a sync ASYNC|EFFECT_PRESERVED effect. `render_effect(fn, flags)` builds a sync RENDER_EFFECT with optional extra flags. `branch` builds a sync BRANCH_EFFECT|EFFECT_PRESERVED effect with optional push. `aborted` reports whether the given effect (defaulting to the active one) has the DESTROYED flag.

<a id="u-75d755e7c63c"></a>
### `packages/svelte/src/internal/client/reactivity/effects.js:block`

`export function block(fn, flags = 0)` · [packages/svelte/src/internal/client/reactivity/effects.js:L376-L382][f1]

Creates a synchronous BLOCK_EFFECT (with optional extra flags) for template blocks; in DEV it attaches the current `dev_stack` to the effect for error attribution.

<a id="u-42e380f9794b"></a>
### `component_root`

`export function component_root(fn)` · [packages/svelte/src/internal/client/reactivity/effects.js:L268-L285][f1]

Creates a component's root effect (ROOT_EFFECT|EFFECT_PRESERVED, run synchronously, after `Batch.ensure()`), returning a disposer that returns a Promise.

With `outro: true` it pauses the effect (running out transitions) before destroying and resolving; otherwise it destroys immediately and resolves with undefined.

<a id="u-214ad59ce57a"></a>
### `destroy_effect`

`export function destroy_effect(effect, remove_dom = true)` · [packages/svelte/src/internal/client/reactivity/effects.js:L463-L512][f1]

Fully destroys an effect: removes its DOM range when `remove_dom` or it is a HEAD_EFFECT with both anchor nodes set; recursively destroys children (skipping already-removed DOM); removes reactions; marks the effect DESTROYED; stops its transitions; runs its teardown; unlinks it from the parent unless the parent has no other children; and in DEV clears `component_function`.

Finally nulls next/prev/teardown/ctx/deps/fn/DOM anchors/abort controller — but deliberately keeps `parent` so error propagation still works.

**Notes.**

- side_effect: remove_effect_dom walks sibling nodes until the end node, removing each; unlink_effect splices the effect out of parent/sibling links without destroying it.

calls: [remove_reactions](r5-signal-core.md#u-b457a655a682), [set_signal_status](r5-signal-core.md#u-ebc2eda73ca2)

<a id="u-8ac46761ce64"></a>
### `destroy_effect_children`

`export function destroy_effect_children(signal, remove_dom = false)` · [packages/svelte/src/internal/client/reactivity/effects.js:L416-L440][f1]

Destroys all children of an effect: clears the child list, aborts each child's abort controller with STALE_REACTION (inside `without_reactive_context` so the abort cannot trigger reactive updates), and either reparents ROOT_EFFECT children as independent roots or destroys them recursively.

`remove_dom` propagates to recursive destroys only when DOM was not already removed at this level.

calls: [without_reactive_context](r3-runtime-dom-elements.md#u-ff3a57d1f4f9)

<a id="u-188599523a26"></a>
### `effect_root`

`export function effect_root(fn)` · [packages/svelte/src/internal/client/reactivity/effects.js:L254-L261][f1]

Implements `$effect.root(...)`: ensures a batch exists, creates a synchronously-run ROOT_EFFECT|EFFECT_PRESERVED effect decoupled from the surrounding tree, and returns a cleanup function that destroys that effect (tearing down its subtree).

<a id="u-e4bc784214d0"></a>
### `execute_effect_teardown`

`export function execute_effect_teardown(effect)` · [packages/svelte/src/internal/client/reactivity/effects.js:L395-L409][f1]

Runs an effect's teardown function, if any, with `is_destroying_effect` set true and `active_reaction` nulled so teardown code cannot register dependencies; both globals are restored in `finally` even if the teardown throws.

<a id="u-d9a59d025a48"></a>
### `legacy_pre_effect`

`export function legacy_pre_effect(deps, fn)` · [packages/svelte/src/internal/client/reactivity/effects.js:L300-L318][f1]

Implements `$: statement` scheduling.

Registers a token (effect, ran flag, deps) in the legacy component context, then creates a render effect that evaluates `deps`, bails if `token.ran` is already true (emulating the reset ordering), otherwise marks ran and runs `fn` untracked so dependencies come only from `deps`.

calls: [untrack](r5-signal-core.md#u-aa0e067da463)

<a id="u-b86eec9e6793"></a>
### `legacy_pre_effect_reset`

`export function legacy_pre_effect_reset()` · [packages/svelte/src/internal/client/reactivity/effects.js:L320-L343][f1]

Creates a render effect that re-runs dirty legacy `$:` statements: for each token it evaluates deps; if the token's effect is CLEAN it is marked MAYBE_DIRTY so its dependencies get traversed; if dirty it is updated; finally `token.ran` resets to false so the statement can run again on the next cycle.

<a id="u-2f3c3d6372e6"></a>
### `pause_children`

`export function pause_children(effect, transitions, local)` · [packages/svelte/src/internal/client/reactivity/effects.js:L590-L613][f1]

Marks a subtree inert (toggling the INERT flag off the effect) and gathers its transitions for outro.

Transitions are collected when they are global or when `local` is true; locality is passed down unchanged through transparent or branch children but becomes false for normal children, so only global transitions inside nested blocks outro.

<a id="u-340d218bcd6f"></a>
### `pause_effect`

`export function pause_effect(effect, callback)` · [packages/svelte/src/internal/client/reactivity/effects.js:L557-L567][f1]

Delays destruction of a removed block so out transitions can play: collects transitions from the subtree via `pause_children`, then `run_out_transitions` either destroys the effect and invokes the callback immediately when there are none, or destroys after the last transition's `out` callback fires (a shared counter decrements per completion).

<a id="u-f5814c70931b"></a>
### `resume_children`

`function resume_children(effect, local)` · [packages/svelte/src/internal/client/reactivity/effects.js:L628-L660][f1]

Reverses pausing: toggles INERT off each subtree effect, schedules any effect whose status is not CLEAN as DIRTY (via set_signal_status and schedule_effect — deliberately avoiding `is_dirty` so deriveds are not recomputed eagerly), recurses with the same transparent/local rules as pausing, and plays `in()` on transitions that are global or covered by the local flag.

calls: [set_signal_status](r5-signal-core.md#u-ebc2eda73ca2), [schedule_effect](r3-runtime-reactivity-batching.md#u-ce4f8d895426)

<a id="u-5f7f1fcbe917"></a>
### `template_effect`

`export function template_effect(fn, sync = [], async = [])` · [packages/svelte/src/internal/client/reactivity/effects.js:L366-L370][f1]

Creates the render effect backing template expressions.

It delegates to `flatten` to combine sync and async expression getters, then creates a synchronous RENDER_EFFECT whose function spreads the resolved values (read via `get`) into the update function.

calls: [flatten](r4-client-reactivity.md#u-c50793421b66)

<a id="u-2ecd21794ced"></a>
### `user_effect`

`export function user_effect(fn)` · [packages/svelte/src/internal/client/reactivity/effects.js:L198-L220][f1]

Implements `$effect(...)`.

Validates placement, and in DEV renames the function to '$effect'. A top-level effect in a component branch that has not yet run is deferred: the function is pushed onto the component context's `e` list to run at mount, and nothing is returned. All other cases create the effect immediately via `create_user_effect`.

calls: [validate_effect](r5-effects-module.md#u-4f3a8befe7fd)

<a id="u-53bf5464d746"></a>
### `user_pre_effect`

`export function user_pre_effect(fn)` · [packages/svelte/src/internal/client/reactivity/effects.js:L234-L242][f1]

Implements `$effect.pre(...)`: validates placement, renames the function in DEV, and creates a synchronous USER_EFFECT|RENDER_EFFECT so it runs in the pre-flush phase.

<a id="u-4f3a8befe7fd"></a>
### `validate_effect`

`export function validate_effect(rune)` · [packages/svelte/src/internal/client/reactivity/effects.js:L50-L62][f1]

DEV-time guard for effect runes, raising the appropriate development error: `effect_orphan` when neither active effect nor reaction exists, `effect_in_unowned_derived` when the active reaction is UNOWNED with no active effect, and `effect_in_teardown` when called while an effect is being destroyed.

raises: [packages/svelte/src/internal/client/errors.js][f2]

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/reactivity/effects.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/errors.js
