# Signal Core

**Capability.** The dependency-tracking engine: signal reads that register dependencies and recompute dirty deriveds, dirty checking, reaction execution and dependency reconciliation, status-flag management, tick/settled scheduling, untracking, and deep state reading for legacy mode.

This is the heart of reactivity; everything else in the runtime calls get/set_signal_status/update_reaction. Use it to understand propagation, and untrack/tick for scheduling escapes.

**Depended on by.**

- [Lifecycle and Events](r5-component-lifecycle.md) · graph-confirmed · 2 edge(s)
- [Each Block](r5-each-block.md) · graph-confirmed · 2 edge(s)
- [Effect Lifecycle](r5-effects-module.md) · graph-confirmed · 13 edge(s)
- [Input Bindings](r5-input-bindings.md) · graph-confirmed · 3 edge(s)
- [Legacy Component Reactivity](r5-legacy-internal.md) · graph-confirmed · 4 edge(s)
- [Reactive Wrappers and Stores](r5-reactivity-wrappers.md) · graph-confirmed · 16 edge(s)
- [Reactive value wrappers](r2-reactive-values.md) · graph-only · 21 edge(s)
- [Effect Batching & Scheduling](r3-runtime-reactivity-batching.md) · graph-only · 12 edge(s)
- [Signal Sources](r3-runtime-reactivity-sources.md) · graph-only · 12 edge(s)
- [Boundary & Async Blocks](r1-boundary-blocks.md) · graph-only · 8 edge(s)

Parent: [Client Runtime](r5-client-runtime.md)

## Units (18)

<a id="u-98099fbbf12a"></a>
### `packages/svelte/src/internal/client/runtime.js:get`

`export function get(signal)` · [packages/svelte/src/internal/client/runtime.js:L528-L682][f1]

Reads a signal's value while registering it as a dependency of the active reaction, and recomputes dirty deriveds.

When there is an active reaction and not untracking: reads are skipped if the active effect is already destroyed (a possible leak after an async derived); otherwise, during the init/update cycle (`REACTION_IS_UPDATING`), a fresh read version causes dependency registration — if the signal matches the previously-read dependency slot, only `skipped_deps` is incremented (cheap unchanged-deps case), otherwise the signal is appended to `new_deps` (de-duplicated when `skip_reaction` is true, i.e. inside an unowned derived). Outside the cycle (e.g. after an `await`), the signal is pushed onto `active_reaction.deps` and the reaction is pushed onto the signal's `reactions` if absent. When read with no active reaction, an unowned-eligible derived with null deps and null effects gets the `UNOWNED` flag flipped on if its parent is not unowned. In DEV: reads inside a current async effect that were not tracked warn about reactivity loss with a stack trace; the signal is removed from `recent_async_deriveds`; and tracing mode records stack traces per expression entry, skipping duplicates and delegating to `signal.trace()` when present. Value resolution: if an effect is being destroyed, `old_values` supplies the previous value for plain signals, and for deriveds supplies (or computes via `execute_derived` when the derived is non-clean with reactions or `depends_on_old_values` says it depends on changing values, caching it in `old_values`). Otherwise a derived is served from `batch_deriveds` when present, and recomputed via `update_derived` when `is_dirty`. Finally, if the signal carries `ERROR_VALUE`, its stored value is thrown; otherwise `signal.v` is returned.

**Notes.**

- failure: A signal flagged ERROR_VALUE causes `get` to `throw signal.v`, propagating the stored error to the reader
- condition: Reads while `is_destroying_effect` are served from `old_values` to keep destroyed-effect reads consistent

calls: [is_dirty](r5-signal-core.md#u-6236bf4a1a35), [update_derived](r2-client-reactivity.md#u-637b94af51bf), [execute_derived](r2-client-reactivity.md#u-193107029d03), [get_stack](r3-runtime-dev-tools.md#u-507749353e33); uses: [packages/svelte/src/internal/client/runtime.js:get](r5-signal-core.md#u-98099fbbf12a), [function::old_values][f2], [function::batch_deriveds][f3], [function::tracing_expressions][f4], [function::current_async_effect][f5]

**Uncertainties.**

- Exact shape of `signal.label` and `signal.trace` is defined by other modules

<a id="u-6236bf4a1a35"></a>
### `is_dirty`

`export function is_dirty(reaction)` · [packages/svelte/src/internal/client/runtime.js:L153-L224][f1]

Recursively determines whether a derived or effect needs re-execution, possibly reconnecting it to the graph.

Returns true immediately if the reaction is DIRTY. If MAYBE_DIRTY with dependencies: when the reaction is DISCONNECTED, or unowned while an active non-destroyed effect exists, it re-registers the reaction into each dependency's `reactions` (always for disconnected deriveds, de-duplicated for unowned ones), clears DISCONNECTED, and clears UNOWNED once reconnected to a non-unowned parent. It then walks dependencies: a dirty dependency is recomputed via `update_derived`; any dependency with a write version greater than the reaction's makes it dirty. Otherwise, unless the signal is unowned without an active non-skipped effect (unowned signals are never marked clean there), its status is set to CLEAN and false is returned. Reactions that are neither DIRTY nor MAYBE_DIRTY fall through to false with no status change.

calls: [is_dirty](r5-signal-core.md#u-6236bf4a1a35), [update_derived](r2-client-reactivity.md#u-637b94af51bf), [set_signal_status](r5-signal-core.md#u-ebc2eda73ca2)

**Uncertainties.**

- Exact effect of `skip_reaction` on unowned-connection logic beyond the `is_unowned_connected` guard is not derivable from this function alone

<a id="u-ebc2eda73ca2"></a>
### `set_signal_status`

`export function set_signal_status(signal, status)` · [packages/svelte/src/internal/client/runtime.js:L745-L747][f1]

Replaces only the dirty-status bits of a signal's flags with the given status, preserving all other flags: `signal.f = (signal.f & STATUS_MASK) | status`, where `STATUS_MASK` clears DIRTY, MAYBE_DIRTY and CLEAN.

<a id="u-e2ea8c85735e"></a>
### `update_effect`

`export function update_effect(effect)` · [packages/svelte/src/internal/client/runtime.js:L441-L495][f1]

Re-runs an effect: destroys its children, runs its teardown, executes the effect body via `update_reaction`, and records the new teardown.

Returns without any work if the effect is DESTROYED. It marks the effect CLEAN, saves and sets `active_effect` and `is_updating_effect`, and in DEV swaps in the effect's `component_function` and `dev_stack` (falling back to the current `dev_stack` for non-block effects). Block effects destroy children with `destroy_block_effect_children`; other effects use `destroy_effect_children`. After `execute_effect_teardown` and `update_reaction`, the returned function becomes `effect.teardown` (null otherwise) and `effect.wv` is set to the current write version. In DEV with tracing mode, when the effect ran because it was DIRTY, any dependency flagged `set_during_effect` gets its write version incremented (so it is correctly dirty on re-run) and the flag is cleared. The finally block restores `is_updating_effect`, `active_effect`, and the DEV context/stack values.

**Notes.**

- side_effect: In DEV tracing mode, dependencies written during the effect get fresh write versions so they are dirty on the next run

calls: [update_reaction](r5-signal-core.md#u-f6b808e008e3), [destroy_effect_children](r5-effects-module.md#u-8ac46761ce64), [execute_effect_teardown](r5-effects-module.md#u-e4bc784214d0), [set_dev_current_component_function](r4-component-context.md#u-1de56d41fa38), [set_dev_stack](r4-component-context.md#u-946a777d9545)

<a id="u-f6b808e008e3"></a>
### `update_reaction`

`export function update_reaction(reaction)` · [packages/svelte/src/internal/client/runtime.js:L256-L377][f1]

Runs a reaction's function while tracking its new dependencies, then reconciles the dependency list and restores all previous tracking state.

It saves the previous module state (`new_deps`, `skipped_deps`, `untracked_writes`, `active_reaction`, `skip_reaction`, `current_sources`, component context, `untracking`, `update_version`), resets tracking accumulators, computes `skip_reaction` for unowned reactions (true when untracking, no effect update in progress, or no active reaction), sets `active_reaction` to null for branch/root effects, installs the reaction's component context, and bumps `update_version` via `++read_version`. If the reaction holds an AbortController, it aborts it with `STALE_REACTION` inside `without_reactive_context` and nulls it. In the try block it sets the `REACTION_IS_UPDATING` flag, runs `fn()`, then: if new dependencies were recorded, it removes stale reactions, splices `new_deps` onto the tail of `deps` (or replaces it), and registers the reaction into each new dependency's `reactions` unless skipped (except owned deriveds that already have reactions); otherwise it truncates `deps` to `skipped_deps`, removing stale entries. When runes mode is on and there are untracked writes on a clean non-derived reaction with deps, each write is passed to `schedule_possible_effect_self_invalidation`. Returning to a different previous reaction increments `read_version` and merges `untracked_writes` upward. The `ERROR_VALUE` flag, if set, is cleared before returning the result. Errors from `fn()` are passed to `handle_error` and that return value is used as the result (propagating or swallowing depends on `handle_error`). The finally block restores every saved value and toggles `REACTION_IS_UPDATING` off.

**Notes.**

- failure: Errors thrown by the reaction function are routed to `handle_error`; whether they re-throw is decided there, not here
- side_effect: Sets and restores module-level tracking state; nested executions are safe because everything is saved/restored in finally

calls: [set_component_context](r4-component-context.md#u-4155baf87729), [without_reactive_context](r3-runtime-dom-elements.md#u-ff3a57d1f4f9), [handle_error](r1-error-propagation.md#u-1b3b4fa2c18e), [remove_reactions](r5-signal-core.md#u-b457a655a682), [schedule_possible_effect_self_invalidation](r5-signal-core.md#u-6645f71b9626), [is_runes](r4-component-context.md#u-71aba13a168a)

**Uncertainties.**

- Whether `handle_error` rethrows or returns a sentinel cannot be determined from this file

<a id="u-b71ac6185599"></a>
### `remove_reaction`

`function remove_reaction(signal, dependency)` · [packages/svelte/src/internal/client/runtime.js:L385-L421][f1]

Removes one signal from a dependency's reaction list as an O(1) swap-and-pop; if the list becomes empty it is set to null.

When the dependency is a DERIVED with no remaining reactions and it is not about to be re-added (checked against `new_deps`), it is disconnected from the graph: status set to MAYBE_DIRTY, `DISCONNECTED` toggled on unless it is already UNOWNED or DISCONNECTED, its derived effects destroyed via `destroy_derived_effects`, and its own stale reactions removed recursively. The `new_deps` check avoids disconnecting a dependency the currently-updating parent still uses.

calls: [destroy_derived_effects](r2-client-reactivity.md#u-a30c1fdac161), [remove_reactions](r5-signal-core.md#u-b457a655a682)

<a id="u-b457a655a682"></a>
### `remove_reactions`

`export function remove_reactions(signal, start_index)` · [packages/svelte/src/internal/client/runtime.js:L428-L435][f1]

Removes a reaction's registration from each of its dependencies starting at `start_index`, delegating each pair to `remove_reaction`.

Returns immediately if the signal has no dependencies.

calls: [remove_reaction](r5-signal-core.md#u-b71ac6185599)

<a id="u-5fbc2abe243d"></a>
### `safe_get`

`export function safe_get(signal)` · [packages/svelte/src/internal/client/runtime.js:L708-L710][f1]

Tolerant read wrapper: returns `undefined` when the signal is undefined or null (used for `var` declarations accessed before declaration), otherwise delegates to `get`.

calls: [packages/svelte/src/internal/client/runtime.js:get](r5-signal-core.md#u-98099fbbf12a)

<a id="u-6645f71b9626"></a>
### `schedule_possible_effect_self_invalidation`

`function schedule_possible_effect_self_invalidation(signal, effect, root = true)` · [packages/svelte/src/internal/client/runtime.js:L231-L253][f1]

Propagates untracked writes made inside an effect back onto that effect so a later read can re-trigger it.

Walks the signal's reactions recursively through DERIVED reactions (with `root=false` below the top). For each non-derived reaction equal to the target effect: at the root it marks the effect DIRTY; deeper, it marks it MAYBE_DIRTY only if currently CLEAN; in both cases it schedules the effect. Returns early if the signal has no reactions, and, outside async mode, if the signal is among `current_sources` (already-suppressed self-writes).

calls: [schedule_possible_effect_self_invalidation](r5-signal-core.md#u-6645f71b9626), [schedule_effect](r3-runtime-reactivity-batching.md#u-ce4f8d895426)

<a id="u-fc7941515c6d"></a>
### `push_reaction_value`

`export function push_reaction_value(value)` · [packages/svelte/src/internal/client/runtime.js:L91-L99][f1]

Records a value written within the current reaction so the reaction can later avoid self-triggering.

It appends `value` to `current_sources` (creating the array if null), but only when there is an active reaction and either async mode is off or the reaction has the DERIVED flag; otherwise the value is silently dropped.

**Notes.**

- condition: Append happens only when `active_reaction !== null` and (async mode off OR `(active_reaction.f & DERIVED) !== 0`)

**Uncertainties.**

- Consumers of `current_sources` in this file show the value is used to suppress self-invalidation, but the full lifecycle spans other modules

<a id="u-fe83d8ee971b"></a>
### `packages/svelte/src/internal/client/runtime.js:tick`

`export async function tick()` · [packages/svelte/src/internal/client/runtime.js:L501-L511][f1]

Returns a promise that resolves once pending state changes have been applied.

In async mode it resolves on the next `requestAnimationFrame`; otherwise it awaits one microtask and then calls `flushSync()`, guaranteeing pending changes are flushed after one tick.

calls: [flushSync](r3-runtime-reactivity-batching.md#u-f4c4d1829672)

**Uncertainties.**

- Whether `flushSync` can itself throw (e.g. `flush_sync_in_effect`) is decided in batch.js, not visible here

<a id="u-c3960ca76f41"></a>
### `packages/svelte/src/internal/client/runtime.js:settled`

`export function settled()` · [packages/svelte/src/internal/client/runtime.js:L519-L521][f1]

Returns a promise that resolves once state changes, the asynchronous work they trigger, and the resulting DOM updates have completed.

Implemented by delegating to the current batch: `Batch.ensure()` obtains (creating if needed) the active batch and its `settled()` method returns the promise.

calls: [batch.js-batch-class](r3-runtime-reactivity-batching.md#u-6d22ee98690b)

<a id="u-aa0e067da463"></a>
### `untrack`

`export function untrack(fn)` · [packages/svelte/src/internal/client/runtime.js:L728-L736][f1]

Runs `fn` with dependency tracking disabled and returns its result.

Sets the module flag `untracking` to true (saving and restoring the previous value in finally), so any `get` calls inside `fn` do not register dependencies on the active reaction; nested untrack calls restore correctly.

<a id="u-917581529c00"></a>
### `deep_read`

`export function deep_read(value, visited = new Set())` · [packages/svelte/src/internal/client/runtime.js:L797-L839][f1]

Recursively reads every enumerable property of an object so `$state` proxies are all touched and become reactive, guarding against cycles with a `visited` set (added per object).

Skips non-objects, null, EventTarget instances, and already-visited values. Calls `value.getTime()` on Date instances to capture SvelteDate changes. Property reads are wrapped in try/catch that continues on throw. After the plain walk, if the prototype differs from the built-in Object/Array/Map/Set/Date prototypes, all getters from the prototype's property descriptors are invoked (each individually try/caught and ignored on failure).

**Notes.**

- failure: Property access and getter invocation errors are caught and silently ignored, so deep reading never throws
- side_effect: Getter invocation can run arbitrary user code and record reactive reads

**Uncertainties.**

- Only enumerable properties are visited (`for...in`); non-enumerable state is not read

<a id="u-031649ca68f4"></a>
### `deep_read_state`

`export function deep_read_state(value)` · [packages/svelte/src/internal/client/runtime.js:L773-L788][f1]

Shallowly traverses a value so its `$state` proxies become reactive, reading state at the first level (and the second level for plain arrays' elements' containers is not entered; only one nested level for non-arrays).

Returns immediately for non-objects, null, or EventTarget instances. If the value carries the `STATE_SYMBOL`, it is fully read via `deep_read`. Otherwise, for non-arrays, it iterates enumerable properties and fully reads any property value that is an object carrying `STATE_SYMBOL`. Arrays without the symbol are skipped entirely.

**Notes.**

- condition: Arrays without STATE_SYMBOL are not traversed; only the top-level object or its first-level stateful properties are read

calls: [deep_read](r5-signal-core.md#u-917581529c00)

<a id="u-6edc1c6dcf27"></a>
### `exclude_from_object`

`export function exclude_from_object(obj, keys)` · [packages/svelte/src/internal/client/runtime.js:L754-L765][f1]

Builds a shallow copy of an object's own enumerable string-keyed properties, omitting the keys listed in `keys`, and returns the copy.

Uses a `for...in` loop, so inherited enumerable properties would also be copied; values are copied by reference.

**Uncertainties.**

- Because `for...in` is used, inherited enumerable properties are included; whether that is intended is not stated in the source

<a id="u-ac602620d878"></a>
### `runtime.js-module-state-setters`

`export function set_is_updating_effect(value)` · [packages/svelte/src/internal/client/runtime.js:L54-L56][f1]

Trivial setters and version bumpers over runtime.js's module-level mutable state.

Each `set_*` function assigns its argument to the corresponding exported `let` binding (`is_updating_effect`, `is_destroying_effect`, `active_reaction`, `active_effect`, `untracked_writes`, `update_version`); no validation or side effects. `increment_write_version()` pre-increments `write_version` and returns the new value; `write_version` starts at 1 so unowned deriveds can distinguish a created effect from a run one. `skip_reaction` is exported mutable state with no setter here.

<a id="u-e515969c757d"></a>
### `x`

`const original = { count: 0, get x()` · [packages/svelte/src/internal/client/proxy.test.ts:L16-L22][f6]

Test fixture: a getter on the original object that increments two counters and returns 42, used to verify the proxy preserves (does not cache or bypass) original getters.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/runtime.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/reactivity/sources.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/reactivity/batch.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dev/tracing.js
[f5]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/reactivity/deriveds.js
[f6]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/proxy.test.ts
