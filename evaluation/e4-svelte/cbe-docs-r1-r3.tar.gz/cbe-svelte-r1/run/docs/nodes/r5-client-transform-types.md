# Client Transform State Types

**Capability.** Type-only shape of the client transform state: per-name read/assign/mutate/update hooks plus component-level buckets (init, update, after_update, consts), hoisting, events, and template accumulation.

Consult when adding a client visitor to know what state is available and how output is bucketed.

Parent: [Client Transform](r5-client-transform.md)

## Units (2)

<a id="u-e21a2406661b"></a>
### `ClientTransformState`

`export interface ClientTransformState extends TransformState` · [packages/svelte/src/compiler/phases/3-transform/client/types.d.ts:L18-L46][f1]

Type-only declaration extending TransformState with client-specific flags: `in_constructor` (rewrite this.foo to private field reads), `in_derived` (directly inside $derived(...)), `is_instance` (transforming instance script content), and a per-name `transform` record whose optional hooks rewrite reads ($.get style), assignments ($.set), member mutations ($.mutate), and update expressions ($.update).

Only `read` is required; other hooks are optional per binding.

**Uncertainties.**

- This is a .d.ts declaration; tree-sitter reported an ERROR node near line 1 of the file, so chunk boundaries are program-derived rather than verified.

<a id="u-aa70ee4ad0b0"></a>
### `ComponentClientTransformState`

`export interface ComponentClientTransformState extends ClientTransformState` · [packages/svelte/src/compiler/phases/3-transform/client/types.d.ts:L48-L86][f1]

Type-only declaration extending ClientTransformState for component-level transforms: the component analysis and options, `hoisted` statements, an `events` set for delegated events, optional `store_to_invalidate`, statement buckets (`init` before render effects, `update` inside them, `after_update` for bindings/actions, `consts` for {@const}), a Memoizer, the HTML `template`, metadata (namespace, bound_contenteditable), `preserve_whitespace`, the current anchor `node`, legacy-reactive import/statement accumulators, and instance/module snippet lists.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/types.d.ts
