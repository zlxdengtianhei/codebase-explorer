# Compiler Utilities

**Capability.** ESTree node construction (single-node factories, call/member/key/quasi builders, thunk simplification) plus tiny assertion and string-formatting helpers used throughout the compiler.

These are pure building blocks with no phase-specific knowledge. Use the builders group for fixed-shape node factories and the named helpers (call, maybe_call, member_id, key, quasi, unthunk) when composing expressions; assert.equal and string.list serve diagnostics and invariant checks.

**Depended on by.**

- [Analysis](r4-analyze-phase.md) · graph-confirmed · 1 edge(s)
- [Client Transform](r4-client-transform.md) · model-inferred · 0 edge(s)
- [Compiler Semantic Model](r4-compiler-model.md) · model-inferred · 0 edge(s)

Parent: [Compiler Pipeline](r4-compiler-pipeline.md)

## Units (9)

<a id="u-2a153dd9dab6"></a>
### `equal`

`export function equal(actual, expected)` · [packages/svelte/src/compiler/utils/assert.js:L7-L9][f1]

Throws an Error when two values are not strictly equal, serving as a compile-time assertion.

Takes any actual value and an expected value; on `actual !== expected` it throws `new Error('Assertion failed')`, otherwise returns normally and, per the JSDoc `asserts` clause, narrows the actual value's type for callers. Comparison is strict, so objects must match by identity. The error propagates to the caller with no fallback.

<a id="u-b3e77b1d8760"></a>
### `call`

`export function call(callee, ...args)` · [packages/svelte/src/compiler/utils/builders.js:L99-L124][f2]

Builds a CallExpression, converting a string callee into an Identifier.

Arguments are copied, then processed right-to-left: trailing falsy entries are popped off; once a truthy argument is seen, falsy entries are replaced with an `undefined` identifier so positional arity is preserved. The result is always non-optional.

<a id="u-7b974afef5ad"></a>
### `key`

`export function key(name)` · [packages/svelte/src/compiler/utils/builders.js:L682-L684][f2]

Chooses the node kind for a property key: a valid identifier string becomes an Identifier, anything else (invalid identifier characters, empty string) becomes a string Literal.

<a id="u-7766cd33ccfc"></a>
### `maybe_call`

`export function maybe_call(callee, ...args)` · [packages/svelte/src/compiler/utils/builders.js:L131-L139][f2]

Builds an optional-call chain: constructs a call via `call`, flips its `optional` flag to true, and wraps it in a ChainExpression.

calls: [call](r4-compiler-utils.md#u-b3e77b1d8760)

<a id="u-ca805d7f76b1"></a>
### `member_id`

`export function member_id(path)` · [packages/svelte/src/compiler/utils/builders.js:L317-L327][f2]

Turns a dotted path string into a nested non-computed MemberExpression chain rooted at the first segment as an Identifier; a single-segment path yields just that Identifier.

<a id="u-44404e861756"></a>
### `quasi`

`export function quasi(cooked, tail = false)` · [packages/svelte/src/compiler/utils/builders.js:L374-L377][f2]

Builds a TemplateElement whose raw value is the cooked string passed through sanitize_template_string (escaping backticks/`${}` etc.), with `tail` defaulting to false.

calls: [sanitize_template_string](r3-compiler-shared-utils.md#u-01781e43d6ff)

<a id="u-98dc49f1a7a8"></a>
### `unthunk`

`export function unthunk(expression)` · [packages/svelte/src/compiler/utils/builders.js:L443-L449][f2]

Simplifies arrow functions that add no value.

If the arrow is async and its body is an AwaitExpression, it walks the awaited argument and stops at any nested AwaitExpression; when none is found, it returns unthunk of a non-async arrow with the same params and the awaited expression as body. Independently, a non-async arrow whose body is a CallExpression with an Identifier callee, whose parameter count matches the argument count, and whose params and arguments are pairwise Identifiers of equal name, is replaced by the callee itself (the documented `(arg) => func(arg)` → `func` rewrite). Otherwise the arrow is returned unchanged.

**Uncertainties.**

- Only a shallow nested-await check on the awaited argument; awaits in nested function bodies inside the argument would also stop the rewrite, being detected by the same walk.

<a id="u-9f2a4f04137f"></a>
### `builders.js-trivial-node-builders`

`export function array(elements = [])` · [packages/svelte/src/compiler/utils/builders.js:L10-L12][f2]

Factory helpers that construct single ESTree nodes with fixed shapes; each returns a fresh plain-object node and performs no validation or traversal.

Notable shape decisions: arrow/function_declaration/function_builder set `expression` from body type and a null `metadata` field marked as not for codegen; call accepts a string callee (converted via id) and compacts falsy trailing arguments while replacing interior falsy slots with an `undefined` identifier; maybe_call wraps call's result with `optional: true` in a ChainExpression; member/member_id convert string properties to identifiers (member_id chains a dotted path string into nested member accesses); prop always sets method/shorthand false and honors a computed flag; get/set build accessor Properties whose FunctionExpression value has no id (set names its parameter `$$value`); quasi sanitizes the cooked string via sanitize_template_string for the raw value; thunk wraps an expression in a zero-arg arrow (async flag propagates) then runs unthunk; throw_error builds `throw new Error(str)`; the import helpers build namespace and named-specifier declarations; declaration/declarator and the let/const/var builders assemble VariableDeclarations; for_builder, if_builder, do_while, labeled, update, sequence, rest, spread, stmt, template, conditional, logical, binary, unary, assignment, assignment_pattern, array(_pattern), object(_pattern), id, private_id, literal, init, prop_def, export_default, for_of and new_builder are direct literal-shaped constructors with a string-to-node convenience where noted. unthunk additionally performs two rewrites: an async arrow whose body is a bare AwaitExpression containing no further await is collapsed into a non-async arrow of the same body (recursively), and a sync arrow that forwards its identifier params one-to-one as identifier arguments to a single identifier callee is replaced by that callee.

<a id="u-5617f591c677"></a>
### `list`

`export function list(strings, conjunction = 'or')` · [packages/svelte/src/compiler/utils/string.js:L5-L9][f3]

Formats a string list for human-readable messages.

One item returns as-is; two items join as `a <conjunction> b`; three or more join all but the last with commas, then append the conjunction and the last item. `conjunction` defaults to 'or'.

**Uncertainties.**

- An empty input list is not handled; it would fall into the three-plus branch and produce `,  undefined`-style output via undefined last element.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/utils/assert.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/utils/builders.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/utils/string.js
