# Attachments API

**Capability.** Programmatic attachment creation: createAttachmentKey symbols recognized on spread objects, and fromAction bridging Svelte 4 actions to attachments via effects.

Use by library authors to attach behavior without {@attach} syntax; fromAction compiles action semantics onto the effect system.

**Depends on.**

- [Effect Lifecycle](r5-effects-module.md) · graph-confirmed · 1 edge(s)

Parent: [Public Component API](r5-public-api.md)

## Units (3)

<a id="u-c36056169480"></a>
### `createAttachmentKey`

`export function createAttachmentKey()` · [packages/svelte/src/attachments/index.js:L30-L32][f1]

Returns a `Symbol(ATTACHMENT_KEY)` that, used as an object key holding an attachment function spread onto an element, is recognized as an attachment — a programmatic alternative to `{@attach ...}` aimed at library authors.

Pure; no state or failure paths.

<a id="u-0433aefd7114"></a>
### `fromAction`

`export function fromAction(action, fn = /** @type {() => T} */ (noop))` · [packages/svelte/src/attachments/index.js:L96-L113][f1]

Converts an action into an attachment with equivalent behavior.

On attachment, it untracks `action(element, fn())`, treating a nullish return as `{}`, and destructures `{update, destroy}`. If `update` exists, a `render_effect` re-reads `fn()` and calls `update(arg)` only after the first run (`ran` flag set after the effect body's first execution), so later reactive changes to `fn()` re-invoke the action's update while the initial value came from the untracked call. If `destroy` exists it is registered with `teardown` so it runs when the attachment is torn down. `fn` defaults to `noop`, so the one-argument overload passes an effectively undefined value. The second argument must return the action argument, not be the argument itself.

calls: [effects.js-trivial-effect-factories](r5-effects-module.md#u-191f01511fb1)

**Uncertainties.**

- Whether the render_effect re-runs on changes to `fn()` depends on `render_effect` reactivity semantics external to this file.

<a id="u-9dc068e33cb4"></a>
### `public-d-ts-attachments`

`export interface Attachment<T extends EventTarget = Element>` · [packages/svelte/src/attachments/public.d.ts:L8-L10][f2]

Type-only public API declaration for the svelte/attachments entry point.

The Attachment interface types an attachment as a function taking an element (defaulting to Element, generic over EventTarget) that runs when the element is mounted and may return a cleanup function called on removal. Attachments are attached via {@attach ...} tags or by spreading an object containing a createAttachmentKey property, per the doc comment. The file re-exports everything from './index.js'. No runtime behavior is present in this file.

**Uncertainties.**

- The mount/cleanup lifecycle described in the doc comment is implemented elsewhere and is not verifiable from this declaration file.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/attachments/index.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/attachments/public.d.ts
