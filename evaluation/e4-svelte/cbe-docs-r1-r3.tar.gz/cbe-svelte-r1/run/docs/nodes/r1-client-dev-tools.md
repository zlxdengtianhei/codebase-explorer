# Client Dev Diagnostics & HMR

**Capability.** Development-only tooling: stale-assignment warnings, a console dump of the effect graph, and hot-module-replacement component wrapping.

Use this for dev-mode behavior that disappears in production builds. Each module wraps a specific runtime concern (compound assignment, debugging, HMR).

**Depends on.**

- [Client Block & Element Visitors](r1-client-block-visitors.md) · graph-confirmed · 1 edge(s)
- [DOM & Rune Constant Predicates](r1-dom-dom-utils.md) · graph-confirmed · 1 edge(s)

Parent: [Client Runtime](r1-runtime-client.md)

## Units (3)

<a id="u-2b16b464bcfd"></a>
### `assign.js`

`function compare(a, b, property, location)` · [packages/svelte/src/internal/client/dev/assign.js:L12-L18][f1]

Dev-mode wrappers around compound property assignment that warn when a synchronously written value reads back stale.

Each exported assign* performs the mutation (or compound mutation) on object[property], then calls compare, which returns the written value but emits w.assignment_value_stale when the freshly assigned value differs from an untracked re-read of object[property]. The untrack re-read ensures the check is not itself recorded as a reactive dependency; a mismatch indicates a setter that did not immediately reflect the assignment (e.g. proxy or store indirection).

calls: [sanitize_location](r1-dom-dom-utils.md#u-eb8e19f29107), [untrack](r5-signal-core.md#u-aa0e067da463)

**Uncertainties.**

- The exact reactive semantics that make the re-read differ from the written value live in runtime.js/proxy code not supplied here; the warning is only triggered on observed inequality.

<a id="u-7c0984a1cd2f"></a>
### `debug.js`

`export function root(effect)` · [packages/svelte/src/internal/client/dev/debug.js:L20-L26][f2]

Dev-only console tree dump of the effect graph.

root walks effect.parent until null and returns the topmost effect. log_effect_tree recursively prints an effect's type label chosen by the first matching flag in priority order (root, boundary, block, async, branch, render effect, effect; otherwise '(unknown)'), a status of clean/maybe dirty/dirty from CLEAN/MAYBE_DIRTY flags, its callsite (depth 0, from an Error stack line) or its fn (deeper, collapsed), its deps via log_dep, and then each child in the first/next sibling list. log_dep prints derived deps recursively as collapsed groups or plain state values. All output is console.group/log calls with no state mutation.

**Uncertainties.**

- The callsite regex assumes a specific stack-line format; if stack is unavailable or the line is missing, callsite may end up undefined and be logged as such.

<a id="u-71f7fa443aeb"></a>
### `hmr.js`

`export function hmr(original, get_source)` · [packages/svelte/src/internal/client/dev/hmr.js:L15-L20][f3]

Wraps a component for hot module replacement so it can be swapped at runtime without losing DOM.

hmr returns a wrapper component that renders the current component inside a transparent block: on each run it reads the current component from get_source(), destroys the previous branch effect (deleting all keys of the shared instance object first), and creates a new branch that instantiates the component and copies its property descriptors onto the instance, preserving getters/setters. On re-runs set_should_intro(false/true) suppresses transitions during replacement. While hydrating the anchor is advanced to hydrate_node. The wrapper copies original[FILENAME] and exposes wrapper[HMR] with the original component and a source signal created from it; the HMR accept path replaces that source's value to trigger re-render.

calls: [packages/svelte/src/internal/client/reactivity/effects.js:block](r5-effects-module.md#u-75d755e7c63c), [effects.js-trivial-effect-factories](r5-effects-module.md#u-191f01511fb1), [destroy_effect](r5-effects-module.md#u-214ad59ce57a), [set_should_intro][f4], [packages/svelte/src/internal/client/runtime.js:get](r5-signal-core.md#u-98099fbbf12a), [source](r3-runtime-reactivity-sources.md#u-97497b70f31b)

**Uncertainties.**

- How the HMR accept path writes to wrapper[HMR].source lives outside this file; only the comment describes that contract.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dev/assign.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dev/debug.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dev/hmr.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/render.js
