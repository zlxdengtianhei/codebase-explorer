# Signal Sources

**Capability.** Creation and writing of reactive signals: allocation (source, state, mutable_source), public and internal write paths with equality checks, mutation/increment helpers, reaction marking, and the inspect-effect registry with its flush/toggle accessors.

Use this subtree to trace how `$state` values are created, written, and how dependent reactions get marked. internal_set is the core write path; mark_reactions hands off to batch scheduling; inspect effects are deferred around array mutations and batched writes.

**Depends on.**

- [Dev-Mode Diagnostics](r3-runtime-dev-tools.md) · graph-confirmed · 3 edge(s)
- [Deep Reactivity Proxies](r3-runtime-proxy.md) · graph-confirmed · 1 edge(s) · Signal writes call the proxy layer to wrap written values in deep-reactive proxies.
- [Effect Batching & Scheduling](r3-runtime-reactivity-batching.md) · graph-confirmed · 3 edge(s) · Signal writes via internal_set and mark_reactions hand off to batch scheduling so dependent effects flush together.
- [Signal Core](r5-signal-core.md) · graph-only · 12 edge(s)

**Depended on by.**

- [Spring Motion](r3-public-motion.md) · graph-confirmed · 7 edge(s) · The Spring class backs its target/current values with state signals from the sources layer.
- [Reactive Window Values](r3-public-reactive-window.md) · graph-confirmed · 2 edge(s)
- [DOM Blocks](r3-runtime-dom-blocks.md) · model-inferred · 0 edge(s)
- [DOM Elements, Bindings & Transitions](r3-runtime-dom-elements.md) · model-inferred · 0 edge(s)
- [Legacy Reactivity Mode](r3-runtime-legacy-mode.md) · graph-confirmed · 1 edge(s)
- [Deep Reactivity Proxies](r3-runtime-proxy.md) · graph-confirmed · 13 edge(s)
- [Effect Batching & Scheduling](r3-runtime-reactivity-batching.md) · model-inferred · 0 edge(s)
- [Reactivity Benchmarks & Test Config](r3-tooling-benchmarks.md) · model-inferred · 0 edge(s)
- [Reactive value wrappers](r2-reactive-values.md) · graph-only · 26 edge(s)
- [Reactive Primitives & Motion](r4-reactive-primitives.md) · graph-only · 19 edge(s)
- [Reactive Wrappers and Stores](r5-reactivity-wrappers.md) · graph-only · 14 edge(s)

Parent: [Client Runtime Internals](r3-runtime.md)

## Units (12)

<a id="u-97497b70f31b"></a>
### `source`

`export function source(v, stack)` · [packages/svelte/src/internal/client/reactivity/sources.js:L66-L85][f1]

Allocates a plain Value signal object for v with zero flags, reference equality, and null reactions; it does not register the signal anywhere.

In DEV tracing mode it attaches created (the supplied stack or a freshly captured 'CreatedAt' stack), updated, set_during_effect and trace fields.

<a id="u-acd426d0030b"></a>
### `state`

`export function state(v, stack)` · [packages/svelte/src/internal/client/reactivity/sources.js:L93-L99][f1]

Creates a source via source(v, stack) and registers it with push_reaction_value before returning it; otherwise identical to source.

calls: [source](r3-runtime-reactivity-sources.md#u-97497b70f31b)

<a id="u-32c84d6fdda4"></a>
### `mutable_source`

`export function mutable_source(initial_value, immutable = false, trackable = true)` · [packages/svelte/src/internal/client/reactivity/sources.js:L108-L121][f1]

Creates a source for a mutable ($state) binding.

Unless immutable is true, its equals is switched to safe_equals so mutations of equal-valued primitives still propagate. In legacy mode, when trackable is set and there is component context with a lifecycle list, the signal is pushed onto component_context.l.s (creating the array if needed) so updates can trigger beforeUpdate/afterUpdate callbacks.

<a id="u-452914169f68"></a>
### `packages/svelte/src/internal/client/reactivity/sources.js:set`

`export function set(source, value, should_proxy = false)` · [packages/svelte/src/internal/client/reactivity/sources.js:L143-L163][f1]

Public write path for a source.

It first enforces the safe-mutation rule: if there is an active reaction that is not in an untracking context (or is an inspect effect), runes mode is on, the reaction is a derived, block effect, async or inspect effect, and the source is not in current_sources, state_unsafe_mutation is thrown. When should_proxy is true the value is wrapped with proxy; in DEV the proxy is tagged with the source label. The actual update is delegated to internal_set and its return value is passed through.

calls: [internal_set](r3-runtime-reactivity-sources.md#u-0dae6a8d64cd), [proxy](r3-runtime-proxy.md#u-6e64c72c9fe9)

<a id="u-0dae6a8d64cd"></a>
### `internal_set`

`export function internal_set(source, value)` · [packages/svelte/src/internal/client/reactivity/sources.js:L171-L243][f1]

Core assignment for a signal, skipped entirely when source.equals reports the value unchanged (it then returns the new value without side effects).

On a real change it records the previous value in old_values (or the new value when a destroying effect set it), writes source.v, captures the old value in the current batch via Batch.ensure().capture, and in DEV records an 'UpdatedAt' stack entry keyed by stack trace plus set_during_effect when inside an effect. For derived signals, a DIRTY derived is eagerly executed first to track its dependencies, then its status is set to CLEAN, or MAYBE_DIRTY when it is UNOWNED. The write version is incremented, mark_reactions propagates DIRTY, and a clean, non-branch/root active effect gets the source appended to untracked_writes so effects like `$effect(() => x++)` still reschedule. In DEV with pending inspect effects and no deferral, flush_inspect_effects runs before returning.

calls: [batch.js-batch-class](r3-runtime-reactivity-batching.md#u-6d22ee98690b), [execute_derived](r2-client-reactivity.md#u-193107029d03), [mark_reactions](r3-runtime-reactivity-sources.md#u-a19ed62d3d7e), [runtime.js-module-state-setters](r5-signal-core.md#u-ac602620d878)

<a id="u-1be316a4a069"></a>
### `mutate`

`export function mutate(source, value)` · [packages/svelte/src/internal/client/reactivity/sources.js:L128-L134][f1]

Implements `$state` mutation assignments by untracking the read of the current value and setting the source to that same value, forcing reactions to re-run even though the value is identical; it then returns the supplied value for use as the expression result.

calls: [packages/svelte/src/internal/client/reactivity/sources.js:set](r3-runtime-reactivity-sources.md#u-452914169f68)

<a id="u-8fa6038c59d8"></a>
### `increment`

`export function increment(source)` · [packages/svelte/src/internal/client/reactivity/sources.js:L298-L300][f1]

Writes source.v + 1 through set without reading the source reactively via get, so no dependency is registered on the current reaction; used for internal version-like counters.

calls: [packages/svelte/src/internal/client/reactivity/sources.js:set](r3-runtime-reactivity-sources.md#u-452914169f68)

<a id="u-63fbe11acd11"></a>
### `packages/svelte/src/internal/client/reactivity/sources.js:update`

`export function update(source, d = 1)` · [packages/svelte/src/internal/client/reactivity/sources.js:L271-L279][f1]

Post-increment/decrement for numeric or bigint sources: reads the current value with get, computes the returned result as the pre-update value (value++ for d=1, value-- otherwise), then writes the incremented value back via set.

The old value is returned, so `x++`-style semantics hold.

calls: [packages/svelte/src/internal/client/reactivity/sources.js:set](r3-runtime-reactivity-sources.md#u-452914169f68)

<a id="u-58e668ab2289"></a>
### `update_pre`

`export function update_pre(source, d = 1)` · [packages/svelte/src/internal/client/reactivity/sources.js:L287-L292][f1]

Pre-increment/decrement: reads the source, computes value+1 or value-1 depending on d, writes it via set, and returns the new value from set's return.

calls: [packages/svelte/src/internal/client/reactivity/sources.js:set](r3-runtime-reactivity-sources.md#u-452914169f68)

<a id="u-a19ed62d3d7e"></a>
### `mark_reactions`

`function mark_reactions(signal, status)` · [packages/svelte/src/internal/client/reactivity/sources.js:L307-L346][f1]

Recursively marks a signal's reactions after a write.

It returns immediately when there are no reactions. Per reaction: in legacy mode the currently running active effect is skipped to prevent infinite loops; in DEV inspect effects are collected into inspect_effects for immediate/deferred flushing instead of being scheduled. A reaction that is not already DIRTY gets its status set to the given status (never downgrading DIRTY to MAYBE_DIRTY). Derived reactions are recursed into with MAYBE_DIRTY so their own subscribers are marked transitively; non-derived, newly-marked reactions are scheduled (block effects are also appended to eager_block_effects when that list is active).

**Uncertainties.**

- schedule_effect and eager_block_effects semantics are defined in batch.js and only referenced here

<a id="u-8313e354c312"></a>
### `flush_inspect_effects`

`export function flush_inspect_effects()` · [packages/svelte/src/internal/client/reactivity/sources.js:L245-L263][f1]

Runs all registered inspect effects immediately, then clears the registry and the deferral flag.

Each effect is not updated blindly: a CLEAN effect is promoted to MAYBE_DIRTY, and update_effect runs only when is_dirty reports the effect actually dirty, avoiding overfiring when many sources change in one tick.

calls: [update_effect](r5-signal-core.md#u-e2ea8c85735e), [is_dirty](r5-signal-core.md#u-6236bf4a1a35)

<a id="u-c20696ab63af"></a>
### `sources.js-inspect-effect-toggle`

`export function set_inspect_effects(v)` · [packages/svelte/src/internal/client/reactivity/sources.js:L49-L51][f1]

Two module-level accessors around the inspect-effects registry.

set_inspect_effects replaces the exported inspect_effects set outright; set_inspect_effects_deferred sets a boolean that internal_set consults to skip flushing inspect effects immediately (deferred flushing), and flush_inspect_effects resets it.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/reactivity/sources.js
