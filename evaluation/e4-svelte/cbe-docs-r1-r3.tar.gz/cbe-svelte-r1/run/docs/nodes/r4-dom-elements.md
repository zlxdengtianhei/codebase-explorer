# DOM Elements & Events

**Capability.** Element-level runtime: delegated and direct event registration including the composedPath handler walk, class/style updates, attachment hooks, two-way bindings (select, this, navigator, exported props), and HTML→DocumentFragment parsing used when constructing templates.

Compiled attribute and event code targets these units: events.js plus its create_event/handle_event_propagation groups implement delegation; the bindings submodules implement bind: directives; create_fragment_from_html is the primitive for template instantiation; append-styles lazily installs component CSS; dom/types.d.ts describes template structure types.

**Depends on.**

- [Component Context](r4-component-context.md) · model-inferred · 0 edge(s)
- [Shared Runtime Utilities](r4-shared-runtime.md) · graph-confirmed · 1 edge(s)
- [Task Scheduling](r4-task-scheduling.md) · graph-confirmed · 2 edge(s)
- [Effect Lifecycle](r5-effects-module.md) · graph-only · 11 edge(s)

**Depended on by.**

- [DOM Blocks](r4-dom-blocks.md) · graph-confirmed · 1 edge(s)

Parent: [DOM Rendering](r4-dom-rendering.md)

## Units (20)

<a id="u-86f4f61fbc7c"></a>
### `events-js-create-event`

`export function create_event(event_name, dom, handler, options = {})` · [packages/svelte/src/internal/client/dom/elements/events.js:L50-L54][f1]

Creates and registers a DOM event listener that integrates with Svelte's event-delegation machinery, returning the handler so it can later be removed.

The inner target_handler calls handle_event_propagation bound to the element during the bubble phase only (skipped when options.capture is set), then, unless the event's cancelBubble flag is set, invokes the user handler inside without_reactive_context so handlers do not run under an active reaction. Pointer, touch, and wheel listeners are attached in a microtask via queue_micro_task to work around a Chrome bug where such events fail on cloned, disconnected elements; all other events attach synchronously. options defaults to {}.

**Notes.**

- failure: If the event was already marked cancelBubble by delegation, the user handler is skipped entirely.

calls: [events-js-handle-event-propagation](r4-dom-elements.md#u-a8449e88e16d), [without_reactive_context](r3-runtime-dom-elements.md#u-ff3a57d1f4f9), [task.js-queues](r4-task-scheduling.md#u-2af0814cc5ec)

<a id="u-a8449e88e16d"></a>
### `events-js-handle-event-propagation`

`export function handle_event_propagation(event)` · [packages/svelte/src/internal/client/dom/elements/events.js:L156-L217][f1]

Implements Svelte's delegated-event walk: invoked with `this` set to the element holding the root listener, it walks the event's composedPath from the initial target upward, invoking the `__<eventname>` delegated handler stored on each element, and fakes event.currentTarget to the element currently being handled.

It records the event in last_propagated_event (kept alive to preserve the __root expando against premature GC in Firefox) and, if event.__root shows the event was already handled at or above this listener, skips nodes at or below the previous handling point — except that a document/window-level listener seeing an already-handled event resets __root to itself and returns so a manual re-dispatch restarts cleanly; a handler not present in the path (seen in some JSDOM/window scenarios) returns without handling. If the current target equals the listener element it returns early, since that case is either already handled or safe to defer to the root listener. It then proxies a configurable currentTarget getter onto the event, nulls the active reaction and effect around the walk (so sync blur events from DOM mutation cannot run inside another reaction), and loops: on each element it calls the delegated handler (spreading array form [fn, ...data] as extra arguments) unless the element is disabled and is not the event's original target; handler errors are collected — the first is rethrown synchronously after the loop and any others are thrown from queued microtasks, one each; iteration stops on cancelBubble, reaching the listener element, or exhausting the parent chain (following assignedSlot, parentNode, then host for shadow roots). The finally block sets event.__root to the listener element, deletes the currentTarget proxy, and restores the previous active reaction and effect.

**Notes.**

- failure: First handler error propagates synchronously after the walk; additional errors are thrown asynchronously, one per microtask.
- side_effect: Active reaction/effect are cleared for the duration of the walk and restored in finally, even on throw.

**Uncertainties.**

- The exact semantics of event.__root producers (root delegation listeners) live outside this file.
- Whether a per-element array-form delegated handler receives extra data depends on the compiled `__<event>` expando format not shown here.

<a id="u-132e2aed8e9d"></a>
### `apply`

`export function apply( thunk, element, args, component, loc, has_side_effects = false…` · [packages/svelte/src/internal/client/dom/elements/events.js:L310-L343][f1]

Invokes a compiled event-handler thunk and, in dev, warns when the result is not a function — indicating the user likely called the handler or forgot a `() =>` arrow.

thunk() runs inside try/catch so a throwing thunk is captured rather than escaping. The warning fires only when the handler is not a function and at least one of: has_side_effects is true, the handler result is non-null, or the thunk threw. The warning message includes the event name plus a capture-phase suffix (eventPhase below BUBBLING_PHASE) and a `file:line:col` location when available, and suggests removing trailing `()` or adding a leading `() =>` based on remove_parens. If the thunk threw, the error is rethrown after warning. Finally the handler, if any, is applied to the element with the original args.

**Notes.**

- failure: A throwing thunk rethrows after the warning only when the warning condition was met; otherwise the error is swallowed and handler?.apply does nothing.

uses: [events.js module code (L1–L25)][f1]

**Uncertainties.**

- Whether errors are swallowed or rethrown when the warning condition is false is a real boundary: the catch stores the error, and the rethrow sits inside the warning branch.

<a id="u-cf26b665744a"></a>
### `delegate`

`export function delegate(events)` · [packages/svelte/src/internal/client/dom/elements/events.js:L134-L142][f1]

Registers event names for root-level delegation: each name is added to all_registered_events, and every handle registered in root_event_handles is invoked with the events array so roots attach their corresponding document/window listeners.

uses: [events.js module code (L1–L25)][f1]

<a id="u-a97020bcbb33"></a>
### `event`

`export function event(event_name, dom, handler, capture, passive)` · [packages/svelte/src/internal/client/dom/elements/events.js:L111-L128][f1]

Registers a handler for legacy/manual event attachment, building options from capture and passive flags.

When the target is document.body, window, document, or an HTMLMediaElement (the media case covers Firefox firing stray canplay events after removal), a teardown callback removes the listener when the owning effect is destroyed; other targets never get automatic removal.

calls: [events-js-create-event](r4-dom-elements.md#u-86f4f61fbc7c), [effects.js-trivial-effect-factories](r5-effects-module.md#u-191f01511fb1)

<a id="u-d8e90951de4c"></a>
### `packages/svelte/src/internal/client/dom/elements/events.js:on`

`export function on(element, type, handler, options = {})` · [packages/svelte/src/internal/client/dom/elements/events.js:L95-L101][f1]

Attaches a handler via create_event and returns a removal function that calls removeEventListener with the same type and options, keeping handler order correct relative to delegated attribute handlers.

calls: [events-js-create-event](r4-dom-elements.md#u-86f4f61fbc7c)

<a id="u-25eff3cd7825"></a>
### `replay_events`

`export function replay_events(dom)` · [packages/svelte/src/internal/client/dom/elements/events.js:L26-L42][f1]

Replays load/error events captured by SSR onload/onerror attributes during hydration.

It returns immediately when not hydrating, removes both attributes, reads the saved event from the dom.__e expando, clears it, and if an event was saved dispatches it on the element in a microtask, but only if the element is still connected by then.

**Uncertainties.**

- dom.__e is an undocumented expando set elsewhere (likely by SSR/hydration code not in this file).

<a id="u-085f1a439acb"></a>
### `set_class`

`export function set_class(dom, is_html, value, hash, prev_classes, next_classes)` · [packages/svelte/src/internal/client/dom/elements/class.js:L13-L51][f2]

Updates an element's class with caching via dom.__className.

If hydrating, the cached value differs from value, or the cached value is undefined, it computes the full class name with to_class(value, hash, next_classes); while hydrating it only writes when the computed name differs from the server-rendered class attribute. A nullish computed name removes the class attribute (empty strings are kept as className for performance); otherwise it writes className (HTML) or setAttribute (non-HTML). It then stores value in __className. When the main value is unchanged but next_classes differ from prev_classes, it toggles each class in next_classes individually via classList.toggle, only when presence changed or prev_classes is missing. Returns next_classes.

calls: [to_class](r4-shared-runtime.md#u-bb0adfe2b192)

**Uncertainties.**

- Keys present in prev_classes but absent from next_classes are never explicitly untoggled; whether that is intentional depends on how callers build next_classes.

<a id="u-89b96e9f81b2"></a>
### `attach`

`export function attach(node, get_fn)` · [packages/svelte/src/internal/client/dom/elements/attachments.js:L12-L33][f3]

Attaches a dynamically chosen attachment function to a DOM node, replacing it whenever the getter yields a different function.

A block effect compares fn !== (fn = get_fn()); when it changed, the previous branch effect is destroyed and nulled, and if the new fn is truthy a fresh branch wrapping an effect that calls fn(node) is created. When the new value is undefined/false, only destruction happens. The branch wrapper ensures the attachment effect is torn down with its parent branch, per the legacy-mode comment in the file.

calls: [effects.js-trivial-effect-factories](r5-effects-module.md#u-191f01511fb1), [packages/svelte/src/internal/client/reactivity/effects.js:block](r5-effects-module.md#u-75d755e7c63c)

<a id="u-40e4240d9329"></a>
### `bind_online`

`export function bind_online(update)` · [packages/svelte/src/internal/client/dom/elements/bindings/navigator.js:L7-L11][f4]

Pushes navigator.onLine to the update callback whenever the window fires online or offline.

calls: [listen](r3-runtime-dom-elements.md#u-8f0d8dd6601b)

<a id="u-7e3a8e97cbcd"></a>
### `bind_prop`

`export function bind_prop(props, prop, value)` · [packages/svelte/src/internal/client/dom/elements/bindings/props.js:L13-L22][f5]

Exposes a component-exported variable on $$props so consumers can bind to it.

Reads the property descriptor; only when a setter exists does it assign props[prop] = value and register teardown that sets props[prop] = null. Without a setter the binding is silently ignored.

calls: [effects.js-trivial-effect-factories](r5-effects-module.md#u-191f01511fb1)

<a id="u-6cdee6c1aa0d"></a>
### `bind_select_value`

`export function bind_select_value(select, get, set = get)` · [packages/svelte/src/internal/client/dom/elements/bindings/select.js:L85-L128][f6]

Two-way binds a select's value.

The change handler (also fired on form reset, querying '[selected]' instead of ':checked' after a reset) collects values: multiple selects map get_option_value over the matched options; single selects take the first matching option, falling back to the first non-disabled option when none is selected. An effect (needed so each-block updates run first) applies get() through select_option with a mounting flag; when mounting with undefined value it adopts the DOM's ':checked' option value and pushes it via set. It then records select.__value and clears the mounting flag. init_select attaches the DOM-mutation sync.

calls: [select_option](r4-dom-elements.md#u-fc6c91d49336), [init_select](r4-dom-elements.md#u-f378be747d77), [listen_to_event_and_reset_event](r3-runtime-dom-elements.md#u-adb7ad8d3643), [effects.js-trivial-effect-factories](r5-effects-module.md#u-191f01511fb1)

<a id="u-3a26469d61b5"></a>
### `get_option_value`

`function get_option_value(option)` · [packages/svelte/src/internal/client/dom/elements/bindings/select.js:L131-L138][f6]

Returns option.__value when the option carries one (set by a value attribute during rendering), otherwise the DOM option.value string.

<a id="u-f378be747d77"></a>
### `init_select`

`export function init_select(select)` · [packages/svelte/src/internal/client/dom/elements/bindings/select.js:L55-L77][f6]

Keeps a select's DOM selection in sync when its options change outside the binding (e.g. options in an #each).

A MutationObserver on childList+subtree and on 'value' attribute changes re-applies select.__value via select_option, deliberately not writing back to the binding model. Teardown disconnects the observer.

calls: [select_option](r4-dom-elements.md#u-fc6c91d49336), [effects.js-trivial-effect-factories](r5-effects-module.md#u-191f01511fb1)

<a id="u-fc6c91d49336"></a>
### `select_option`

`export function select_option(select, value, mounting = false)` · [packages/svelte/src/internal/client/dom/elements/bindings/select.js:L14-L45][f6]

Selects the option(s) matching value on a select element.

For a multiple select: nullish value keeps the current selection; a non-array value triggers the select_multiple_invalid_value warning and keeps the selection; otherwise each option's selected flag is set by whether its value is included in the array. For single select: the first option whose value matches (via is) is selected and the function returns; if none matches and (not mounting or value !== undefined), selectedIndex is set to -1, so during mounting with undefined the DOM's initial selection survives.

calls: [is](r3-runtime-proxy.md#u-dcae92a399e9)

<a id="u-7b1a63fed5a0"></a>
### `bind_this`

`export function bind_this(element_or_component = {}, update, get_value, get_parts)` · [packages/svelte/src/internal/client/dom/elements/bindings/this.js:L25-L61][f7]

Implements bind:this for elements/components.

An outer effect contains a render_effect that tracks only the each-block context parts (get_parts), not the value itself, to avoid spurious reruns. On each run it untracked-ly compares get_value(...parts) with the element_or_component and, if different, calls update(element_or_component, ...parts); if this is a rerun and the previous position (old_parts) still holds this instance (per is_bound_this), it nulls it there first so the binding does not linger in a stale each-block slot. The outer effect's teardown queues a microtask (effects cannot be created during teardown) that nulls the binding at the current parts position if it still points at this instance. Returns element_or_component.

calls: [is_bound_this](r4-dom-elements.md#u-46b14567d27a), [effects.js-trivial-effect-factories](r5-effects-module.md#u-191f01511fb1), [untrack](r5-signal-core.md#u-aa0e067da463), [task.js-queues](r4-task-scheduling.md#u-2af0814cc5ec)

<a id="u-46b14567d27a"></a>
### `is_bound_this`

`function is_bound_this(bound_value, element_or_component)` · [packages/svelte/src/internal/client/dom/elements/bindings/this.js:L11-L15][f7]

Returns true when the currently stored bound value is the element/component itself, or is a proxy whose STATE_SYMBOL payload equals it — the check deciding whether a this-binding slot still belongs to this instance before nulling it.

<a id="u-f51e86a3ef3c"></a>
### `create_fragment_from_html`

`export function create_fragment_from_html(html)` · [packages/svelte/src/internal/client/dom/reconciler.js:L2-L6][f8]

Parses an HTML string into a detached DocumentFragment by assigning it to a `<template>` element's innerHTML, returning `template.content`.

Before parsing it replaces every literal `<!>` with `<!---->` for XHTML compliance, which also supplies anchor comments when content would otherwise start/end with a text node.

<a id="u-ac534a0f6465"></a>
### `TemplateStructure`

`export type TemplateStructure = | string | undefined | [string, Record<string, string…` · [packages/svelte/src/internal/client/dom/types.d.ts:L1-L4][f9]

Type-only declaration: a TemplateStructure item is a string, undefined (comment marker), or a recursive tuple of tag name, attributes record, and child structures.

No runtime behavior.

<a id="u-f8c34d0a4927"></a>
### `css.js-append-styles`

`export function append_styles(anchor, css)` · [packages/svelte/src/internal/client/dom/css.js:L9-L32][f10]

Lazily installs a component's CSS into the appropriate document or shadow root.

Within an effect (so it re-runs and cleans up with the effect lifecycle), it resolves the anchor's root node: if the root has a `host` it is a ShadowRoot and becomes the target, otherwise the root's `head` (falling back to the root's `ownerDocument.head`). If no element with the CSS hash as id exists in the target, it creates a `<style>` with that id and code, appends it, and in DEV registers the style. The comment notes DOM querying is preferred over a cache map for simplicity.

**Notes.**

- side_effect: Appends a style element to the resolved head or ShadowRoot; the effect wrapper ties the anchor lookup to the effect being active.
- contract: The effect defers execution until `anchor` is in the DOM, since getRootNode() on a detached node yields a wrong root.

calls: [css.js](r4-dev-tooling-client.md#u-0546b8eb9687)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/elements/events.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/elements/class.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/elements/attachments.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/elements/bindings/navigator.js
[f5]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/elements/bindings/props.js
[f6]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/elements/bindings/select.js
[f7]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/elements/bindings/this.js
[f8]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/reconciler.js
[f9]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/types.d.ts
[f10]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/css.js
