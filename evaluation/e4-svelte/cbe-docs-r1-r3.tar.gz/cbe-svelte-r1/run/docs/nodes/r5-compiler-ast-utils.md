# Shared AST Utilities

**Capability.** Generic ESTree helpers — attribute/expression guards, identifier and destructuring-path extraction, assignment-value construction — shared by all phases.

Reach for these before writing new AST inspection code; parse, analyze, and transform all depend on them. Kept separate from every consumer.

**Depended on by.**

- [Analyze Visitors](r5-analyze-visitors.md) · graph-confirmed · 15 edge(s)
- [Client Transform Visitors](r5-client-transform-visitors.md) · graph-confirmed · 11 edge(s)
- [CSS Analysis Utilities](r5-css-analyze-utils.md) · model-inferred · 0 edge(s)
- [Script and Expression Reading](r5-script-parsing.md) · graph-confirmed · 1 edge(s)
- [Server Transform](r5-server-transform.md) · model-inferred · 0 edge(s)
- [Analyze-phase AST visitors](r2-analyze-visitors.md) · graph-only · 13 edge(s)
- [Compiler Semantic Model](r4-compiler-model.md) · graph-only · 11 edge(s)
- [Client Transform](r4-client-transform.md) · graph-only · 9 edge(s)

Parent: [Compiler](r5-compiler.md)

## Units (17)

<a id="u-634ffef5ceee"></a>
### `build_assignment_value`

`export function build_assignment_value(operator, left, right)` · [packages/svelte/src/compiler/utils/ast.js:L604-L611][f1]

Converts a compound assignment into its equivalent right-hand value.

With '=' it returns `right` unchanged. For '||=', '&&=', '??=' it builds a logical expression with the operator minus the trailing '=' applied to left and right; all other compound operators build a binary expression the same way (e.g. x += 1 becomes x + 1).

<a id="u-287d48fe390a"></a>
### `build_fallback`

`export function build_fallback(expression, fallback)` · [packages/svelte/src/compiler/utils/ast.js:L585-L597][f1]

Builds a `$.fallback` call implementing destructuring default values.

If the fallback is a simple expression it is inlined directly. If it is an AwaitExpression whose argument is simple, the fallback call is wrapped in await. Otherwise, an async fallback becomes `await $.fallback(expression, () => fallback, true)` (thunked with the async flag), while a synchronous one becomes `$.fallback(expression, () => fallback, true)` without await; both pass a `true` literal as the third argument.

calls: [is_simple_expression](r5-compiler-ast-utils.md#u-410082960042), [is_expression_async](r5-compiler-ast-utils.md#u-88399029ef9f)

**Uncertainties.**

- The meaning of the trailing `true` argument to $.fallback is defined outside this file.

<a id="u-4fc74297abd5"></a>
### `extract_all_identifiers_from_expression`

`export function extract_all_identifiers_from_expression(expr)` · [packages/svelte/src/compiler/utils/ast.js:L146-L156][f1]

Extracts all free identifiers of an expression plus a stringified dependency keypath, returning `[keypath.join('.'), nodes]`.

Members folded in: on Identifier, the node is collected unless it is a non-computed property of a MemberExpression (dot properties are not standalone identifiers); the keypath gets `[name]` for computed member properties, else the plain name. On Literal, string values are quoted, other values stringified, computed member positions bracketed. ThisExpression contributes 'this' and forces the walk to descend via `next`.

**Uncertainties.**

- Behavior relies on zimmerframe's walk supplying `path` and `next`; only the handlers shown here are observable.

<a id="u-90eb95affc00"></a>
### `extract_identifiers`

`export function extract_identifiers(pattern)` · [packages/svelte/src/compiler/utils/ast.js:L136-L138][f1]

Returns only the Identifier nodes from unwrap_pattern of the given pattern, discarding MemberExpression leaves.

calls: [unwrap_pattern](r5-compiler-ast-utils.md#u-73018823c866)

<a id="u-f5e86bd3328c"></a>
### `extract_identifiers_from_destructuring`

`export function extract_identifiers_from_destructuring(node, nodes = [])` · [packages/svelte/src/compiler/utils/ast.js:L193-L220][f1]

Recursively gathers leaf identifiers from a destructuring shape expressed as Identifier, ObjectExpression or ArrayExpression.

ObjectExpression recurses into Property values or RestElement arguments; ArrayExpression recurses into each non-hole element. The source comment admits this is incomplete — it is only sufficient for the compiler's current uses — and unknown node types contribute nothing.

**Uncertainties.**

- Acknowledged incompleteness (source TODO); complex patterns may be missed.

<a id="u-34f2fcb20c62"></a>
### `extract_paths`

`export function extract_paths(param, initial)` · [packages/svelte/src/compiler/utils/ast.js:L243-L258][f1]

Decomposes a destructuring parameter against an initial value into `paths` (one per destructured leaf) and `inserts` (intermediate declarations the consumer must name).

All logic is in the folded `_extract_paths` helper. Identifier/MemberExpression leaves record `expression`/`update_expression` and the inherited has_default_value flag. ObjectPattern properties become member accesses; a RestElement builds `$.exclude_from_object(value, [literal keys…])` where literal keys are used for non-computed Identifier and Literal keys and `String(key)` otherwise, assigning it to an Identifier rest leaf or recursing into nested patterns. ArrayPattern inserts a declaration of identifier `#` bound to `$.to_array(value, lengthLiteral)` — the length literal is omitted when the last element is a RestElement — then each element becomes `#[i]` (computed member), with rest elements becoming `id.slice(i)`; rest arguments that are not Identifiers recurse. AssignmentPattern builds a fallback via build_fallback: Identifier lefts record it as expression with has_default_value true, others recurse keeping the original update_expression but marking defaults present.

calls: [build_fallback](r5-compiler-ast-utils.md#u-287d48fe390a)

**Uncertainties.**

- The intermediate `#` identifier's final name is set by consumers, per the docstring; that renaming is outside this file.

<a id="u-1096ddb4c2b1"></a>
### `get_attribute_chunks`

`export function get_attribute_chunks(value)` · [packages/svelte/src/compiler/utils/ast.js:L70-L72][f1]

Normalizes an attribute value into an array of chunks.

An array value is returned as-is; a boolean value (shorthand attribute) yields an empty array; any other single node is wrapped in a one-element array.

<a id="u-96e6f6d66786"></a>
### `get_attribute_expression`

`export function get_attribute_expression(attribute)` · [packages/svelte/src/compiler/utils/ast.js:L59-L63][f1]

Returns the ESTree expression of an attribute assumed to be is_expression_attribute.

If the value is an array it takes `value[0].expression`; otherwise it takes `value.expression` directly. No validation is performed; caller must satisfy the type-guard precondition.

contract: [is_expression_attribute](r5-compiler-ast-utils.md#u-f63f079d6472)

<a id="u-427249cf438e"></a>
### `get_parent`

`export function get_parent(path, at)` · [packages/svelte/src/compiler/utils/ast.js:L425-L432][f1]

Returns `path.at(at)` while skipping TSNonNullExpression and TSAsExpression wrappers: if the node at `at` is one of those, it returns the neighbor — `at - 1` for negative indices, `at + 1` otherwise.

Assumes `path.at(at)` is defined; the code dereferences `node.type` unguarded, so out-of-range paths would throw.

**Uncertainties.**

- No null check on `path.at(at)`; empty/short paths are not handled here.

<a id="u-1c2da82112be"></a>
### `is_event_attribute`

`export function is_event_attribute(attribute)` · [packages/svelte/src/compiler/utils/ast.js:L79-L81][f1]

True when the attribute qualifies as an event handler: is_expression_attribute is satisfied and the attribute name starts with the literal prefix 'on' (no casing or further naming checks).

calls: [is_expression_attribute](r5-compiler-ast-utils.md#u-f63f079d6472)

<a id="u-88399029ef9f"></a>
### `is_expression_async`

`export function is_expression_async(expression)` · [packages/svelte/src/compiler/utils/ast.js:L484-L578][f1]

Recursively determines whether an expression or pattern contains an await.

AwaitExpression is directly true. Composite nodes recurse over their relevant children: ArrayPattern/ArrayExpression elements (skipping holes, descending into SpreadElement arguments), Assignment/AssignmentPattern/Binary/Logical left-and-right (skipping PrivateIdentifier lefts), CallExpression/NewExpression callee (skipping Super) and arguments, ChainExpression inner expression, ConditionalExpression all three parts, ImportExpression source, MemberExpression object (skipping Super) and property (skipping PrivateIdentifier), Object pattern/expression properties (SpreadElement arguments, or Property key unless PrivateIdentifier and value), RestElement argument, SequenceExpression/TemplateLiteral expressions, TaggedTemplateExpression tag and quasi, UnaryExpression/UpdateExpression argument. YieldExpression is true only when it has an argument. Any other type — including plain Identifiers and Literals — returns false.

<a id="u-f63f079d6472"></a>
### `is_expression_attribute`

`export function is_expression_attribute(attribute)` · [packages/svelte/src/compiler/utils/ast.js:L43-L50][f1]

Type-guard for attributes holding a single expression.

Returns true in two cases: the value is neither the boolean `true` nor an array (i.e. a bare ExpressionTag), or the value is a one-element array whose first node is an ExpressionTag. Any other shape (static text, multiple chunks, boolean shorthand) yields false.

<a id="u-410082960042"></a>
### `is_simple_expression`

`export function is_simple_expression(node)` · [packages/svelte/src/compiler/utils/ast.js:L442-L469][f1]

Reports whether evaluating an expression cannot have signal-reading side effects.

Literals, Identifiers, and arrow/function expressions are simple. ConditionalExpressions are simple when test, consequent and alternate all are. Binary and Logical expressions are simple when the left side is not a PrivateIdentifier and both operands are simple. Everything else (calls, members, templates, etc.) returns false.

<a id="u-ec400088cae5"></a>
### `is_text_attribute`

`export function is_text_attribute(attribute)` · [packages/svelte/src/compiler/utils/ast.js:L28-L34][f1]

Type-guard: true only when the attribute value is an array of exactly one node whose type is 'Text'; otherwise false, including when value is the boolean shorthand `true` or a non-array node.

<a id="u-2f2548aeaec6"></a>
### `object`

`export function object(expression)` · [packages/svelte/src/compiler/utils/ast.js:L11-L21][f1]

Walks down the object chain of a member expression to find its left-most identifier.

While the current node is a MemberExpression it descends into `object`; if the result is not an Identifier (e.g. a ThisExpression or CallExpression base) it returns null, otherwise the Identifier.

<a id="u-aa95700b7c80"></a>
### `unwrap_optional`

`export function unwrap_optional(node)` · [packages/svelte/src/compiler/utils/ast.js:L476-L478][f1]

Unwraps an optional chain: returns `node.expression` when the node is a ChainExpression, otherwise the node itself.

<a id="u-73018823c866"></a>
### `unwrap_pattern`

`export function unwrap_pattern(pattern, nodes = [])` · [packages/svelte/src/compiler/utils/ast.js:L89-L129][f1]

Collects the assignable leaves of a destructuring pattern into the given array (defaulting to a new one) and returns it.

Identifier and MemberExpression nodes are pushed directly — member expressions are legal in assignment patterns though not binding patterns. ObjectPattern recurses into RestElement arguments or property values; ArrayPattern recurses into each non-hole element; RestElement recurses into its argument; AssignmentPattern recurses into its left side. Holes (null elements) in array patterns are skipped, so sparse destructuring contributes nothing.

**Uncertainties.**

- No default case: unknown pattern types contribute nothing silently.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/utils/ast.js
