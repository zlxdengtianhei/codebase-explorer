# Motion: Tween and legacy tweened

**Capability.** Owns animated interpolation toward a target value: the reactive Tween class, structural interpolator construction for arrays/objects, and the deprecated tweened store built on writable.

Use this for time-based animation. Tween.of keeps the tween target in sync with a reactive source; the legacy tweened store replicates the behavior over the store contract. Both paths share get_interpolator.

**Depends on.**

- [Store contract implementation](r2-stores.md) · graph-confirmed · 1 edge(s) · The deprecated tweened store factory is built on top of the writable store contract.

Parent: [Public reactive APIs](r2-public-reactive.md)

## Units (7)

<a id="u-fe5771212e14"></a>
### `index.js module code (L1–L32)`

`module_region` · [packages/svelte/src/motion/index.js:L1-L32][f1]

Re-exports the spring and tweened motion APIs and defines prefersReducedMotion, a reactive MediaQuery matching the CSS prefers-reduced-motion: reduce query.

The instance is created eagerly as a pure-annotated MediaQuery from svelte/reactivity, so its .current reflects whether the user prefers reduced motion and updates reactively.

**Notes.**

- side_effect: The MediaQuery is instantiated at module load time, registering a media query listener via svelte/reactivity.

imports: [spring.js module code (L57–L67)][f2], [tweened.js module code (L160–L178)][f3]

<a id="u-ade423f2a64a"></a>
### `Tween`

`class Tween` · [packages/svelte/src/motion/tweened.js:L179-L193][f3]

Reactive tween class: assigning target (or calling set) animates current toward it over time using delay, duration and easing.

The constructor stores the initial value in #current and #target state signals plus a #defaults options object, tagging both signals in DEV. Folded accessors: current and target getters read via get; the target setter delegates to this.set(v). #task holds the single in-flight animation loop. Unlike the deprecated tweened store, this class takes per-instance defaults in the constructor and applies no null-initial-value snap in set.

<a id="u-6d9737c2921d"></a>
### `get_interpolator`

`function get_interpolator(a, b)` · [packages/svelte/src/motion/tweened.js:L20-L79][f3]

Builds a (t)=>T interpolator between a and b, recursing into arrays and plain objects and throwing on mismatches.

Identical values (a===b) or NaN a return a constant-a function. If a and b differ in typeof or array-ness it throws 'Cannot interpolate values of different type'. Arrays produce per-element interpolators combined by index; objects throw 'Object cannot be null' if either is null, handle Date pairs by interpolating epoch milliseconds, and otherwise interpolate per key of b into a fresh result object; b's keys missing from a are not guarded. Numbers interpolate linearly (a + t*(b-a)); any other primitive snaps to b immediately.

calls: [is_date](r4-reactive-primitives.md#u-c15d4b363055)

**Uncertainties.**

- Object interpolation iterates keys of b only; a keys absent in b are dropped from the result

<a id="u-666b38d81067"></a>
### `packages/svelte/src/motion/tweened.js:set`

`function set(new_value, opts)` · [packages/svelte/src/motion/tweened.js:L99-L153][f3]

Animates the legacy tweened store toward new_value.

If the current value is null/undefined it snaps and resolves. Options (delay 0, duration 400, easing linear, interpolate get_interpolator by default) come from {...defaults, ...opts}. duration===0 aborts the previous task, snaps to the target and resolves. Otherwise a loop task is scheduled starting at raf.now()+delay: before start it keeps ticking (returns true); on first tick after start it builds the interpolator fn from the current value, resolves function-form duration(prev, next), and aborts the previous task; each tick then stores fn(easing(elapsed/duration)) into the store until elapsed exceeds duration, at which point it snaps to new_value and returns false. Returns the task's promise, which resolves when the animation ends (not documented here how aborts affect it).

**Notes.**

- condition: The previous task is aborted only once the delay elapses, not at set() call time.

uses: [get_interpolator](r2-motion.md#u-6d9737c2921d); calls: [loop.js-raf-task-loop](r5-reactivity-wrappers.md#u-0486df452d62)

**Uncertainties.**

- If interpolate throws (type mismatch), behavior of the loop task and pending promise is not visible in this file

<a id="u-a3154029292c"></a>
### `tweened`

`export function tweened(value, defaults = {})` · [packages/svelte/src/motion/tweened.js:L90-L99][f3]

Deprecated factory creating a tweened writable store with set/update/subscribe, holding target_value and the current task in closure scope.

Defaults come from merging the factory-level defaults with per-call opts. When the initial value is null/undefined, set snaps immediately.

calls: [writable](r2-stores.md#u-dc45d71b793b), [packages/svelte/src/motion/tweened.js:set](r2-motion.md#u-666b38d81067)

<a id="u-43c0b011945c"></a>
### `Tween.of`

`static of(fn, options)` · [packages/svelte/src/motion/tweened.js:L221-L229][f3]

Creates a Tween from fn()'s current value and, in a render_effect, calls tween.set(fn()) so the tween target re-synchronizes reactively whenever fn's dependencies change.

Must be called inside an effect root.

calls: [effects.js-trivial-effect-factories](r5-effects-module.md#u-191f01511fb1), [Tween.set](r2-motion.md#u-2873d687ccc7)

<a id="u-2873d687ccc7"></a>
### `Tween.set`

`set(value, options)` · [packages/svelte/src/motion/tweened.js:L239-L293][f3]

Writes value to #target and animates #current toward it, returning the task's promise.

Options merge {...this.#defaults, ...options} with defaults delay 0, duration 400, easing linear, interpolate get_interpolator. duration===0 aborts the running task, snaps #current to value and resolves immediately. Otherwise a loop starts at raf.now()+delay: before start it returns true; on the first post-start tick it reads the current value, builds fn = interpolate(prev, value), resolves function-form duration(prev, value), and aborts the previous task (the immediately preceding set's task, aborted late relative to writing #target). Each tick sets #current to fn(easing(elapsed/duration)) until elapsed exceeds duration, then snaps to value and returns false. A new set overwrites #task, so the docstring's Promise resolves with the loop that last finished; a superseded loop is aborted only on the next task's first active tick.

uses: [get_interpolator](r2-motion.md#u-6d9737c2921d); calls: [loop.js-raf-task-loop](r5-reactivity-wrappers.md#u-0486df452d62)

**Uncertainties.**

- Aborting the previous task inside the started branch means during the delay of a new tween the old animation keeps running

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/motion/index.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/motion/spring.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/motion/tweened.js
