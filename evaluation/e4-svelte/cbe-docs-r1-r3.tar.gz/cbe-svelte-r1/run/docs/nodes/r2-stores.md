# Store contract implementation

**Capability.** Owns the svelte/store contract: writable with start notifiers, readable and readonly views, derived stores over one or many sources, get for one-shot reads, and the shared subscribe_to_store utility that validates store shape.

Read this for the canonical store implementations shared by legacy and runes code. derived and readable both delegate to writable; get and derived use subscribe_to_store for safe subscription.

**Depends on.**

- [Reactivity core \(signals and deriveds\)](r2-client-reactivity.md) · model-inferred · 0 edge(s)

**Depended on by.**

- [Motion: Tween and legacy tweened](r2-motion.md) · graph-confirmed · 1 edge(s) · The deprecated tweened store factory is built on top of the writable store contract.

Parent: [Public reactive APIs](r2-public-reactive.md)

## Units (6)

<a id="u-d2fec82a964b"></a>
### `packages/svelte/src/store/shared/index.js:derived`

`export function derived(stores, fn, initial_value)` · [packages/svelte/src/store/shared/index.js:L129-L143][f1]

Creates a Readable store whose value is computed from one store or an array of stores via `fn`.

Validates input: if any store in the normalized array is falsy it throws `derived() expects stores as input, got a falsy value`. `single` records whether a bare store was passed (fn then receives the value directly rather than an array); `auto` is true when fn takes fewer than 2 parameters, meaning it returns the value instead of using set/update. It is implemented as a readable whose start subscribes to every input store in order: each callback stores the value at its index, clears that store's pending bit, and — only after startup — runs `sync`. `sync` returns early while any store hasn't emitted its first value (pending bits set via the invalidate callbacks); otherwise it runs the previous cleanup, calls fn, and either sets the returned value (auto) or treats a returned function as the next cleanup. On stop, all input unsubscribers run, cleanup runs, and `started` is reset so late queued callbacks do not resync.

**Notes.**

- failure: A falsy store in the array throws synchronously before any subscription.
- condition: Dependent stores that have not emitted initial values delay the first fn invocation via the pending bitmask.

calls: [packages/svelte/src/store/shared/index.js:derived](r2-stores.md#u-d2fec82a964b); uses: [readonly](r2-stores.md#u-01eea88b3e69), [packages/svelte/src/store/shared/index.js:derived](r2-stores.md#u-d2fec82a964b)

<a id="u-624938d77758"></a>
### `packages/svelte/src/store/shared/index.js:get`

`export function get(store)` · [packages/svelte/src/store/shared/index.js:L204-L209][f1]

Synchronously retrieves a store's current value by subscribing and immediately unsubscribing.

The subscriber callback captures each emitted value; since subscribe_to_store invokes the callback synchronously with the current value, `value` is populated before the returned unsubscriber runs, and that value is returned. Yields undefined for stores that never emit synchronously.

calls: [packages/svelte/src/store/shared/index.js:get](r2-stores.md#u-624938d77758)

<a id="u-e3031b84c99c"></a>
### `readable`

`export function readable(value, start)` · [packages/svelte/src/store/shared/index.js:L20-L24][f1]

Creates a Readable store exposing only `subscribe`, delegated from an internal writable initialized with the given value and optional start notifier.

Because the writable's set/update are not exposed, external code can only read; the start notifier still runs on first subscriber and stops on last unsubscribe.

calls: [writable](r2-stores.md#u-dc45d71b793b)

<a id="u-01eea88b3e69"></a>
### `readonly`

`export function readonly(store)` · [packages/svelte/src/store/shared/index.js:L190-L195][f1]

Returns a store object exposing only the input store's `subscribe` (bound to the store), hiding any set/update so consumers cannot write.

No copying or wrapping of values occurs.

**Uncertainties.**

- The source comments that the bind may be unnecessary; behavior with unbound subscribe is untested here.

<a id="u-dc45d71b793b"></a>
### `writable`

`export function writable(value, start = noop)` · [packages/svelte/src/store/shared/index.js:L34-L45][f1]

Creates a Writable store holding `value` with a start notifier (default noop) invoked with `set` and `update` when the first subscriber arrives.

`set(new_value)` acts only when `safe_not_equal(value, new_value)`; then it updates `value`, and if the store is started (stop truthy) it calls every subscriber's invalidate function, pushes [subscriber, value] pairs into the shared module-level `subscriber_queue`, and — only if the queue was empty when it started, making this call the queue owner — synchronously runs all queued subscriber callbacks in order and clears the queue; if a nested set filled the queue first, this set leaves the flushing to the outer call. `update(fn)` sets `fn(value)`. `subscribe(run, invalidate)` registers the [run, invalidate] tuple, starts the notifier on the first subscriber (`stop = start(set, update) || noop`), immediately calls `run(value)`, and returns an unsubscriber that removes the tuple and, when the last subscriber leaves, calls and clears `stop`. Re-subscribing after all unsubscribe restarts the notifier.

**Notes.**

- side_effect: subscriber_queue is module-level shared state; nested sets during flush reuse the same queue and defer to the outermost set.
- condition: Writes equal under safe_not_equal are dropped entirely: value, invalidations, and subscriber notifications are skipped.

calls: [writable](r2-stores.md#u-dc45d71b793b); uses: [writable](r2-stores.md#u-dc45d71b793b)

<a id="u-863f9153e183"></a>
### `subscribe_to_store`

`export function subscribe_to_store(store, run, invalidate)` · [packages/svelte/src/store/utils.js:L12-L36][f2]

Subscribes a callback pair to a possibly-absent Svelte store and returns an unsubscribe function.

When the store is null or undefined, it immediately invokes run(undefined) and, if provided, invalidate(undefined) (both calls bypass types via ts-expect-error), and returns noop as a no-op unsubscribe. Otherwise it subscribes inside untrack so that any validation errors triggered by a StartStopNotifier mutating state during subscribe are silenced; it passes run and the optional invalidate as the store's two subscription arguments, relying on the private second-argument contract of Svelte stores. The returned unsubscribe value is normalized for RxJS compatibility: if it exposes an unsubscribe method, it returns a wrapper that calls it, otherwise it returns the function as-is. Errors from store.subscribe are not caught and propagate to the caller.

**Notes.**

- failure: No try/catch wraps store.subscribe; subscription-time failures propagate unhandled.
- contract: The null/undefined branch calls run and invalidate with undefined, so callbacks must tolerate non-T values.

imports: [utils.js module code (L1–L11)][f2]

**Uncertainties.**

- Whether the RxJS unsubscribe call receives any arguments or how RxJS error events interact is not established here.
- The exact validation error silenced by untrack depends on runtime code not supplied.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/store/shared/index.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/store/utils.js
