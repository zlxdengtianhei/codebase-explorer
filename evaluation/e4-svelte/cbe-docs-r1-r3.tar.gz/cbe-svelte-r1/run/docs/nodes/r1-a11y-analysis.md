# Accessibility Analysis

**Capability.** Runs the full battery of a11y warnings per element, backed by static role/AXObject classification tables and private predicate helpers.

Use this to understand or extend accessibility warnings. check_element is the entry point; constants.js supplies the derived data tables it consumes.

**Depends on.**

- [DOM & Rune Constant Predicates](r1-dom-dom-utils.md) · graph-confirmed · 1 edge(s)

Parent: [Analysis Phase](r1-analysis.md)

## Units (3)

<a id="u-0304f5d2800a"></a>
### `constants.js module code (L1–L319)`

`module_region` · [packages/svelte/src/compiler/phases/2-analyze/visitors/shared/a11y/constants.js:L1-L319][f1]

Builds the static a11y data tables and derived role/AXObject classification sets used by the a11y analyzer.

Exported constants include the recognized aria-* attribute names, required attributes per tag (a/area/html/iframe/img/object), distracting elements (blink, marquee), headings requiring content, labelable tags, interactive/recommended handler lists, and Maps from tags, input types, and menuitem types to implicit ARIA roles. At module load it derives abstract_roles, non_interactive_roles (roles whose superClass lacks 'widget'/'window', excluding toolbar/tabpanel/generic/cell, plus progressbar), interactive_roles (remaining non-abstract roles except generic), and autofill token lists for autocomplete validation. It then populates four schema arrays by iterating elementRoles and elementAXObjects: a schema is pushed to an interactive or non-interactive bucket only when every role/AXObject it maps to falls in that bucket. All of this runs once at import time; failures would surface at import, not per component.

uses: [check_element](r1-a11y-analysis.md#u-0f7a175a707e)

**Uncertainties.**

- Exact shapes of roles_map, elementRoles, AXObjects, and elementAXObjects come from the aria-query/axobject-query packages and are not visible in this source

<a id="u-0f7a175a707e"></a>
### `check_element`

`export function check_element(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/shared/a11y/index.js:L56-L454][f2]

Runs the full battery of accessibility warnings for one regular or svelte element during analysis.

It first classifies attributes: event-like Attribute names go into a handler set (name minus the 'on' prefix), ordinary attributes into an attribute_map, SpreadAttribute sets has_spread, contenteditable-related BindDirective names set has_contenteditable_binding, OnDirective adds to the handler set. For each 'aria-*' attribute on an invisible element (meta/html/script/style) it warns about misplaced aria attributes; unknown aria attribute names get a fuzzymatch suggestion; aria-hidden on headings warns; a known attribute's static value is validated against its aria schema; aria-activedescendant warns when the element is not interactive, lacks tabindex, and has no spread. The per-name switch warns for: role values that are abstract or unknown (with fuzzy suggestion), redundant roles against the implicit role (except ul/ol/li and href-less 'a'), nested header/footer redundant roles unless a section/article parent, missing required aria props for the role (skipped for dynamic elements or spreads), interactive roles on static elements with interactive handlers but no tabindex, interactive-to-noninteractive role downgrades, and noninteractive-to-interactive upgrades except the listed exceptions. accesskey always warns; autofocus warns unless the element is or is inside a dialog; scope warns off 'th'; static positive tabindex warns. Whole-element rules: click handlers on non-interactive, non-hidden, non-spread elements without key events warn; noninteractive tabindex (>=0 or dynamic) warns; aria attributes not supported by the effective role (explicit role or implicit role) warn with distinct implicit/explicit messages; recommended handlers on noninteractive elements warn; handlers on fully static elements warn; mouseover/mouseout without focus/blur warn. Tag-specific cases: a/button warn when unlabelled and contentless; 'a' without href warns of missing attribute unless it has id, name, or aria-disabled='true', and static href of '', '#', or a javascript: prefix warns as invalid; input type=image requires alt/aria-label/aria-labelledby, and a present type plus an invalid static autocomplete value warns; img alt matching a redundant pattern warns; label without 'for' and without a labelable/slot/svelte/component child (found by the nested has_input_child walk, which stops descending into matched nodes and component-like nodes) warns; video without muted or aria-hidden=true requires a child track with kind='captions' or a spread, else warns; figcaption must sit in a figure; figcaption inside figure must be first or last among significant children. Finally, tags in a11y_required_attributes (excluding 'a') need one of their listed attributes; distracting elements warn; and headings in a11y_required_content without content (and without aria-label/labelledby, contenteditable bindings, or spread) warn. Static values come only from shorthand (true) or text attributes; anything dynamic is treated as unknown and usually suppresses the check via has_spread or null values.

**Notes.**

- side_effect: All outcomes are compiler warnings emitted via the imported w.* functions; no AST mutation occurs.
- condition: A SpreadAttribute almost universally suppresses element-level warnings (has_spread guards) because spread content is unknowable statically.

calls: [fuzzymatch](r5-parse-diagnostics.md#u-4d517976b3f9), [is_event_attribute](r5-compiler-ast-utils.md#u-1c2da82112be), [list](r4-compiler-utils.md#u-5617f591c677), [is_content_editable_binding](r1-dom-dom-utils.md#u-e47baf4ced62), [index.js-predicate-and-value-helpers](r1-a11y-analysis.md#u-53eefcbcabb0)

**Uncertainties.**

- The exact warning texts and conditions inside the w.* warning implementations are in warnings.js and not visible here
- Behavior of get_static_value for Attributes whose value is true (shorthand) is used as boolean true; how each consumer treats it is visible but downstream a11y-rule semantics rely on aria-query data not in this file

<a id="u-53eefcbcabb0"></a>
### `index.js-predicate-and-value-helpers`

`function is_presentation_role(role)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/shared/a11y/index.js:L557-L559][f2]

Private predicates and value readers shared by check_element.

is_presentation_role tests membership in ['presentation','none']. is_hidden_from_screen_reader returns true for input type=hidden, true/false for a static aria-hidden (a dynamic value counts as hidden), and false when aria-hidden is absent. has_disabled_attribute is true when the disabled attribute has any truthy static value or aria-disabled is statically 'true'. element_interactivity classifies a tag/attribute pair in a fixed order: interactive role schemas, then non-interactive role schemas (skipping 'header'), then interactive then non-interactive AXObject schemas, matching via match_schema (tag name must equal, each schema attribute must exist and, when a value is specified, equal the static text value); otherwise Static. is_interactive_element, is_non_interactive_element, and is_static_element are thin comparisons against that result. is_semantic_role_element walks elementAXObjects: when the schema name matches and every schema attribute is present with the exact static value, it checks whether any role mapped from the AXObject equals the given role. is_valid_autocomplete validates an autocomplete value: shorthand true is invalid, missing/dynamic is valid; otherwise whitespace-split lowercase tokens are consumed in order — optional 'section-*', optional address type (shipping/billing), then either an autofill field name, or a contact type plus contact field name; optional trailing 'webauthn'; valid only when no tokens remain. input_implicit_role maps a static input type to a role, returning 'combobox' when a list attribute exists on an email/search/tel/text/url input; menuitem_implicit_role maps its static type via a table; get_implicit_role dispatches menuitem and input to those and otherwise uses a11y_implicit_semantics. is_non_interactive_roles, is_interactive_roles, and is_abstract_role are membership tests against the constant lists. get_static_value returns true for shorthand attributes, the first chunk data of text attributes, and null otherwise; get_static_text_value converts the shorthand true to null. has_content recursively scans fragment nodes: whitespace-only text is skipped, an img with an alt attribute counts as content, child elements recurse, and any other node type is conservatively treated as content (documented false-positive risk for empty blocks). is_parent scans the context path from the nearest ancestor outward: a SvelteElement ancestor returns true (unknown, so suppress warnings), a RegularElement returns whether its name is in the requested list. validate_aria_attribute_value type-checks a static aria value against the schema, converting shorthand true to the empty string first and skipping dynamic (null) values: string/id reject empty, number rejects empty or non-numeric, boolean requires 'true'/'false', idlist rejects empty, integer requires an exact integer, token requires one of the schema values (case-insensitive), tokenlist requires every whitespace-separated token to be listed, tristate allows 'true'/'false'/'mixed'; each failure emits the matching type warning. warn_missing_attribute formats the a11y_missing_attribute message, choosing 'an' before vowel or href and joining multiple candidates with 'or'.

uses: [constants.js module code (L1–L319)](r1-a11y-analysis.md#u-0304f5d2800a); calls: [is_text_attribute](r5-compiler-ast-utils.md#u-ec400088cae5), [list](r4-compiler-utils.md#u-5617f591c677)

**Uncertainties.**

- axobject-query's AXObjectRoles/elementAXObjects key sets and aria-query schema 'values' contents come from external packages and are not visible here

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/shared/a11y/constants.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/shared/a11y/index.js
