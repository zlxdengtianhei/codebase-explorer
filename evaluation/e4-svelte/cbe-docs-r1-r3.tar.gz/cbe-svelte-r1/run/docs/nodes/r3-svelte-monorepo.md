# Svelte Repository

**Capability.** Holds the Svelte compiler, client runtime internals, public runtime feature modules (motion, transitions, reactive window), ambient TypeScript definitions, and repository tooling such as benchmarks and test configuration.

Use this root to navigate between the compile pipeline, the runtime internals, the public reactive APIs, and the tooling that builds and measures them. Dependencies flow mostly from public features and tooling down into runtime internals.

**Children.**

- [Svelte Compiler](r3-compiler.md) `r3-compiler` · 0 unit(s)
- [Client Runtime Internals](r3-runtime.md) `r3-runtime` · 2 unit(s)
- [Public Runtime Feature APIs](r3-public-api.md) `r3-public-api` · 0 unit(s)
- [Ambient & Language-Server Types](r3-types.md) `r3-types` · 30 unit(s)
- [Repository Tooling](r3-tooling.md) `r3-tooling` · 0 unit(s)

Parent: [Svelte Monorepo](svelte-monorepo.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
