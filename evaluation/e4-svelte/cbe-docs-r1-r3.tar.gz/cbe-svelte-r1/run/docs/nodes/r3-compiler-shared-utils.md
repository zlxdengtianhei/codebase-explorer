# Compiler Shared Utilities & Legacy AST

**Capability.** Small general-purpose helpers (push_array, template-string sanitizing, slot detection) and the legacy.js conversion layer that transforms the modern internal AST into the Svelte 4-style AST, including whitespace trimming.

Use this subtree for cross-phase helper functions and for understanding legacy-mode output conversion. legacy.js dispatches per node type and depends on extract_svelte_ignore from the diagnostics subtree; the tiny utils are consumed throughout the compiler.

**Depends on.**

- [Compiler Diagnostics & Warnings](r3-compiler-diagnostics.md) · graph-confirmed · 1 edge(s)

**Depended on by.**

- [Semantic Analysis](r3-compiler-analyze.md) · model-inferred · 0 edge(s)

Parent: [Svelte Compiler](r3-compiler.md)

## Units (5)

<a id="u-4f8a7deedb7c"></a>
### `push_array`

`export function push_array(array, items)` · [packages/svelte/src/compiler/utils/push_array.js:L9-L13][f1]

Pushes every item of `items` onto `array` in a plain loop, mutating `array`.

The per-item loop avoids the `array.push(...items)` spread, which would exceed the maximum call stack size for around 65k items; it exists for memory and performance reasons per its docstring.

<a id="u-01781e43d6ff"></a>
### `sanitize_template_string`

`export function sanitize_template_string(str)` · [packages/svelte/src/compiler/utils/sanitize_template_string.js:L5-L7][f2]

Escapes characters that would terminate or inject into a template literal: backtick, dollar-brace, and backslash are each prefixed with a backslash via the regex `/(`|\$ {|\\)/g`.

Returns the escaped string; the input is not modified.

<a id="u-ead26eb5b43f"></a>
### `determine_slot`

`export function determine_slot(node)` · [packages/svelte/src/compiler/utils/slot.js:L8-L20][f3]

Returns the slot name assigned by an element's `slot` attribute, or null.

It returns null immediately when the node is not an element node (per is_element_node). It then scans attributes, skipping any that are not plain `Attribute` nodes, not named `slot`, or not text-valued (is_text_attribute), and returns the attribute's first text value's data on the first match. Non-text or dynamic slot attributes are ignored rather than erroring.

uses: [is_element_node](r4-compiler-model.md#u-0d9a79ad394a); calls: [is_text_attribute](r5-compiler-ast-utils.md#u-ec400088cae5)

<a id="u-4723dd340fbf"></a>
### `legacy-js-convert`

`export function convert(source, ast)` · [packages/svelte/src/compiler/legacy.js:L42-L47][f4]

Converts the modern internal Svelte AST into the legacy Svelte 4-style AST by walking the root with zimmerframe and dispatching per-node-type handlers.

The '_' handler deletes metadata from every node. The Root handler rebuilds the legacy root: it re-inserts the raw svelte:options node into fragment.nodes at the position where options.end fits (appending when no node starts after it), computes html start/end by skipping whitespace in the source from the first/last child offsets, strips attributes from instance and module, and returns {html, instance, module, css} with children re-visited. AwaitBlock synthesizes pending/then/catch blocks; when a block exists its start/end come from its first/last children, falling back to source offsets computed by indexOf('}', ...) / lastIndexOf('}', ...) after the previous block or the expression, and skip becomes false; missing blocks get null start/end with skip: true. IfBlock builds an ElseBlock from alternate (unwrapping a single elseif IfBlock into its consequent's nodes), computing end by lastIndexOf('{', node.end-1) and start from the first node or that offset; an elseif IfBlock's own start comes from its first consequent child or that same offset, and the elseif flag is emitted as true only when set. Attribute and StyleDirective, when value is neither true nor an array, push the node on the walk path, wrap the visited single value in a one-element array, pop the path, and return the node with that value; otherwise they pass through via next(). Simple directives are renamed via spread ({...node, type}); AnimateDirective→Animation, BindDirective→Binding, ClassDirective→Class, HtmlTag→RawMustacheTag, OnDirective→EventHandler, TransitionDirective→Transition, UseDirective→Action, LetDirective→Let, SpreadAttribute→Spread. ExpressionTag becomes AttributeShorthand when its parent is an Attribute whose source text starts with '{', otherwise MustacheTag. ConstTag passes the node through when expression is already set; otherwise rebuilds it as an AssignmentExpression with start offset computed as declaration.start plus the length of 'const '. ComplexSelector calls next() first then flattens children into combinators plus selectors as a 'Selector'. StyleSheet spreads the node with context.next()'s result and type 'Style'. Text inside a style RegularElement is re-emitted without a raw field. Comment attaches ignores from extract_svelte_ignore. Component-family nodes (RegularElement→Element, Component/SvelteSelf/SvelteComponent→InlineComponent, SvelteBody→Body, SvelteDocument→Document, SvelteFragment→SlotTemplate, SvelteHead→Head, SvelteOptions→Options, SvelteWindow→Window, SlotElement→Slot, TitleElement→Title, SvelteBoundary, SnippetBlock, KeyBlock, EachBlock) map attributes/children through visit, and SvelteElement inlines a string Literal tag as a plain string unless the preceding source character is '{'. Several block handlers call remove_surrounding_whitespace_nodes before visiting children.

**Notes.**

- side_effect: Mutates the input AST: deletes metadata everywhere, rewrites Text node data, deletes instance/module attributes, and mutates child arrays via remove_surrounding_whitespace_nodes.

calls: [remove_surrounding_whitespace_nodes](r3-compiler-shared-utils.md#u-f51ce07da951), [extract_svelte_ignore](r3-compiler-diagnostics.md#u-4a9ee4fb9b67)

**Uncertainties.**

- The exact visit/next/path semantics come from zimmerframe and are not shown here.
- Root's whitespace-skip loops read source[start] / source[end-1] without bounds checks; behavior on empty fragments relies on the length>0 guard only.
- SvelteElement's tag.type access assumes node.tag is an expression node; a non-Literal non-node tag value is not guarded in the visible code.

<a id="u-f51ce07da951"></a>
### `remove_surrounding_whitespace_nodes`

`function remove_surrounding_whitespace_nodes(nodes)` · [packages/svelte/src/compiler/legacy.js:L16-L34][f4]

Trims leading/trailing whitespace-only Text nodes from a children array, mutating it.

If the first node is Text: when it contains no non-whitespace it is shifted off; otherwise leading whitespace characters are removed from its data. The same treatment is applied to the last node with trailing whitespace. Non-Text boundary nodes and interior nodes are untouched.

**Notes.**

- side_effect: Mutates the passed array and the data of boundary Text nodes.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/utils/push_array.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/utils/sanitize_template_string.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/utils/slot.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/legacy.js
