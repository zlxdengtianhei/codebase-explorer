# DOM Rendering

**Capability.** Constructs and updates the live DOM from compiled templates: block rendering (await/key/snippet), element creation and attribute/event wiring with delegation, HTML fragment parsing, lazy CSS installation, and the shared micro-task/idle scheduling queues used across rendering.

Compiled template code calls into these units directly. Blocks own control-flow regions; elements own attributes, bindings, and events; task.js queues underpin event handling, bind:this, and await blocks. dom/types.d.ts is a type-only description of template structure.

**Children.**

- [DOM Blocks](r4-dom-blocks.md) `r4-dom-blocks` · 7 unit(s)
- [DOM Elements & Events](r4-dom-elements.md) `r4-dom-elements` · 20 unit(s)
- [Task Scheduling](r4-task-scheduling.md) `r4-task-scheduling` · 1 unit(s)

Parent: [Client Runtime](r4-client-runtime.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
