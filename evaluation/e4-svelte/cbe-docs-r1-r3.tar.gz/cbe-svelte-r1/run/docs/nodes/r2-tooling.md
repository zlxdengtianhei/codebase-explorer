# Repository tooling

**Capability.** Owns developer-workflow scripts: seeding the sandbox app from a template, the create-test CLI that collects App.svelte and its relative imports into a new test folder, and the project's Svelte configuration file.

Use these when setting up playground experiments or editing repo-wide compiler settings. create-test's import collector recursively gathers dependencies so tests are self-contained.

Parent: [Svelte compiler and runtime](r2-svelte.md)

## Units (5)

<a id="u-dde2e710e027"></a>
### `create-app-svelte.js module code (L1–L13)`

`module_region` · [playgrounds/sandbox/scripts/create-app-svelte.js:L1-L13][f1]

Seeds src/main.svelte from a template on first run.

If src/main.svelte does not exist, it attempts to create the src directory (ignoring an error if it already exists) and copies the contents of scripts/main.template.svelte into src/main.svelte as UTF-8. If main.svelte already exists the script does nothing.

<a id="u-1a06a1a0bb15"></a>
### `collect_imports`

`function collect_imports(file_path)` · [playgrounds/sandbox/scripts/create-test.js:L72-L113][f2]

Recursively gathers a file and its relative imports into shared module-level sets, skipping already-processed or missing files.

For each import specifier matched by regex, non-relative (node_modules) imports are skipped; relative paths are resolved and probed with '', '.svelte', '.js', '.ts' extensions, and the first existing candidate is recursed into.

uses: [create-test.js module code (L1–L71)](r2-tooling.md#u-44dc189350cd)

**Uncertainties.**

- The regex-based import matching may miss multi-line or nonstandard import syntax.

<a id="u-44dc189350cd"></a>
### `create-test.js module code (L1–L71)`

`module_region` · [playgrounds/sandbox/scripts/create-test.js:L1-L71][f2]

CLI entry that validates a target test folder and prepares it, interactively overwriting or creating it.

The argument defaults to 'runtime-runes/<name>' when no slash is present; a missing argument or one not starting with 'runtime-' aborts with an error and exit code 1. The resolved path is <repo>/packages/svelte/tests/<group>/samples/<name>. If it exists, the script prompts Y/n via raw stdin; an 'n' response exits 0, otherwise it deletes every entry except '_config.js' (recursive, forced). If it does not exist, the directory tree is created.

**Notes.**

- side_effect: Reads one keystroke synchronously from stdin when the target exists, disabling raw mode before resolving.

calls: [collect_imports](r2-tooling.md#u-1a06a1a0bb15)

**Uncertainties.**

- Any stdin response other than a lowercase-'n' result proceeds with overwrite.

<a id="u-2f95b981947e"></a>
### `create-test.js module code (L113–L155)`

`module_region` · [playgrounds/sandbox/scripts/create-test.js:L113-L155][f2]

Copies the files collected from src/App.svelte into the target test folder and writes a starter _config.js for new tests.

Each file is copied preserving its path relative to src/, with App.svelte renamed to main.svelte; missing target directories are created recursively, and each copy is logged. When the target did not previously exist, an empty Svelte test template is written to _config.js. Ends with a summary log line.

<a id="u-092720d6382b"></a>
### `svelte.config.js module code (L1–L8)`

`module_region` · [svelte.config.js:L1-L8][f3]

Exports the default Svelte configuration object for this project.

The only setting enables the experimental async compiler option; a comment notes the file exists so the VS Code extension does not flag a missing config.

**Uncertainties.**

- Effect of experimental.async: true on compilation is not defined by this file; only that it is set.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/playgrounds/sandbox/scripts/create-app-svelte.js
[f2]: ../../../../../../eval/svelte-be645b4/playgrounds/sandbox/scripts/create-test.js
[f3]: ../../../../../../eval/svelte-be645b4/svelte.config.js
