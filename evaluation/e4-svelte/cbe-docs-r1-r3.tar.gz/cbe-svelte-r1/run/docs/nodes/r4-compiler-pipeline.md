# Compiler Pipeline

**Capability.** Owns the staged compilation of .svelte sources: parse template text and expressions, analyze semantics (runes, scopes, CSS, a11y), and transform the validated analysis into client or server ESTree output. Its children are the phases plus the shared semantic model and utilities they all rely on.

Readers tracing how source becomes output should follow parse-phase → analyze-phase → transform-phase. The compiler-model node holds the scope/binding/node machinery shared by analyze and transform; compiler-utils holds the ESTree builders and assertions. Legacy type declarations are documentation-only.

**Children.**

- [Parsing](r4-parse-phase.md) `r4-parse-phase` · 9 unit(s)
- [Analysis](r4-analyze-phase.md) `r4-analyze-phase` · 0 unit(s)
- [Transformation](r4-transform-phase.md) `r4-transform-phase` · 0 unit(s)
- [Compiler Semantic Model](r4-compiler-model.md) `r4-compiler-model` · 18 unit(s)
- [Compiler Utilities](r4-compiler-utils.md) `r4-compiler-utils` · 9 unit(s)
- [Compiler Legacy Types](r4-compiler-legacy-types.md) `r4-compiler-legacy-types` · 2 unit(s)

**Depended on by.**

- [Diagnostic Message Codegen](r4-diagnostics-messages.md) · model-inferred · 0 edge(s)
- [Playground Sandbox](r4-playground-sandbox.md) · model-inferred · 0 edge(s)

Parent: [Svelte Monorepo](r4-svelte-monorepo.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
