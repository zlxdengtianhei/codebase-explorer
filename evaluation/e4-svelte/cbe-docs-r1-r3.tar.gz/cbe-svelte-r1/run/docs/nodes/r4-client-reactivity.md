# Client Reactivity

**Capability.** Async-effect support and store integration: capturing/restoring effect, reaction, component-context, and batch state across awaits; reactivity-loss tracking; and the auto-subscription store protocol (get/set/mutate/update/invalidate, store-binding detection) plus the stale-reaction sentinel.

async.js units form the suspension protocol used by await expressions and async blocks; store.js units implement `$store` semantics compiled into runtime calls; constants.js supplies the STALE_REACTION error sentinel. validate_binding also consults capture_store_binding.

**Depends on.**

- [Component Context](r4-component-context.md) · graph-confirmed · 3 edge(s)

**Depended on by.**

- [Client Dev Tooling](r4-dev-tooling-client.md) · graph-confirmed · 1 edge(s)

Parent: [Client Runtime](r4-client-runtime.md)

## Units (18)

<a id="u-7844e4272e2c"></a>
### `async_body`

`export async function async_body(fn)` · [packages/svelte/src/internal/client/reactivity/async.js:L180-L193][f1]

Runs the body of an async block within the suspension protocol: suspends the current batch, awaits `fn`, and always unsuspends in `finally`.

If `fn` throws and the captured effect has not been destroyed (`aborted(active)` false), the error is forwarded to `invoke_error_boundary`; errors after the effect was aborted are discarded.

calls: [suspend](r3-runtime-reactivity-batching.md#u-aed941f29bc8), [effects.js-trivial-effect-factories](r5-effects-module.md#u-191f01511fb1), [invoke_error_boundary](r1-error-propagation.md#u-8ed809bdafb5)

<a id="u-0edcd5d2a7c1"></a>
### `capture`

`function capture()` · [packages/svelte/src/internal/client/reactivity/async.js:L72-L88][f1]

Snapshots the active effect, reaction, component context, and current batch, returning a `restore` closure that reinstates all four and, in DEV, clears the async-derived tracking via `set_from_async_derived(null)`.

Used so code that resumes after an `await` still registers dependencies against the original effect.

calls: [runtime.js-module-state-setters](r5-signal-core.md#u-ac602620d878), [set_component_context](r4-component-context.md#u-4155baf87729), [set_from_async_derived](r2-client-reactivity.md#u-7529e3342efc)

<a id="u-c50793421b66"></a>
### `flatten`

`export function flatten(sync, async, fn)` · [packages/svelte/src/internal/client/reactivity/async.js:L30-L65][f1]

Combines synchronous and asynchronous expressions into one derived-driven callback.

Chooses `derived` or `derived_safe_equal` depending on `is_runes()`. With no async expressions it maps `fn` over the sync values immediately and returns. Otherwise it captures the current effect context, finds the pending `<svelte:boundary>`, and awaits `Promise.all` of `async_derived` for each expression. On resolution it activates the captured batch, restores context, and calls `fn` with sync plus resolved values; if `fn` throws and the parent effect is not DESTROYED, the error goes to `invoke_error_boundary`, otherwise it is swallowed. Rejection of the promise itself is routed to the boundary's `error`. Deactivation and `unset_context()` run after the callback.

uses: [is_runes](r4-component-context.md#u-71aba13a168a); calls: [get_pending_boundary](r1-boundary-blocks.md#u-662729eaf177), [invoke_error_boundary](r1-error-propagation.md#u-8ed809bdafb5)

**Uncertainties.**

- Behavior of boundary.error and async_derived depends on definitions in other files

<a id="u-9b4068c7d68b"></a>
### `for_await_track_reactivity_loss`

`export async function* for_await_track_reactivity_loss(iterable)` · [packages/svelte/src/internal/client/reactivity/async.js:L135-L168][f1]

DEV-only async generator wrapper for `for await` loops that tracks reactivity loss per iteration and on iterator close.

It obtains an iterator via `Symbol.asyncIterator` falling back to `Symbol.iterator`; if neither exists it throws `TypeError('value is not async iterable')`. Each `next()` is wrapped in `track_reactivity_loss`; on `done` it sets normal completion and stops. In a `finally` block, if completion was normal and `iterator.return` exists, it awaits `iterator.return()` (also wrapped) and returns its `.value` as the generator's return value — so `break` skips the `return` call.

**Uncertainties.**

- Whether `Symbol.iterator` results actually produce async-next semantics relies on the iterable being async-compatible; not verifiable here

<a id="u-183453782dc0"></a>
### `save`

`export async function save(promise)` · [packages/svelte/src/internal/client/reactivity/async.js:L98-L106][f1]

Wraps an awaited value so that it can be read later inside the original effect context: captures the context before awaiting, then returns a promise of a zero-argument function that restores the captured context and yields the resolved value.

Compiler transforms `await a + b` into `(await $.save(a))() + b`.

calls: [capture](r4-client-reactivity.md#u-0edcd5d2a7c1)

<a id="u-f77b77ba957d"></a>
### `track_reactivity_loss`

`export async function track_reactivity_loss(promise)` · [packages/svelte/src/internal/client/reactivity/async.js:L115-L123][f1]

Preserves `current_async_effect` across an await so reactivity-loss warnings can be attributed later.

Like `save`, it awaits the promise, but its returned thunk restores the previous async effect via `set_from_async_derived(previous_async_effect)` and returns the value instead of restoring the full effect context.

calls: [set_from_async_derived](r2-client-reactivity.md#u-7529e3342efc)

<a id="u-2e39d8f937d3"></a>
### `unset_context`

`export function unset_context()` · [packages/svelte/src/internal/client/reactivity/async.js:L170-L175][f1]

Clears all ambient reactivity context after asynchronous work: nulls the active effect, active reaction, and component context, and in DEV clears async-derived tracking.

Called after flatten's callback and by unsuspend so post-await code does not leak dependencies into stale effects.

calls: [runtime.js-module-state-setters](r5-signal-core.md#u-ac602620d878), [set_component_context](r4-component-context.md#u-4155baf87729)

<a id="u-8388b459c980"></a>
### `capture_store_binding`

> **ID corrected by CBE.** CBE changed the unit ID from ` packages/svelte/src/internal/client/reactivity/store.js::function::capture_store_binding::194 ` to the inventory ID ` packages/svelte/src/internal/client/reactivity/store.js::function::capture_store_binding::5510 `. The model wrote this body under the wrong ID; it may be inaccurate.

`export function capture_store_binding(fn)` · [packages/svelte/src/internal/client/reactivity/store.js:L194-L203][f2]

Runs fn with is_store_binding reset to false and returns [result, flag]: the boolean is true only if fn's execution set the flag via mark_store_binding.

The previous flag value is restored in a finally block, so nesting and outer reads are preserved. The result lets prop() treat store-bound props as mutable and skip binding validation.

<a id="u-edad6338b44e"></a>
### `invalidate_store`

> **ID corrected by CBE.** CBE changed the unit ID from ` packages/svelte/src/internal/client/reactivity/store.js::function::invalidate_store::113 ` to the inventory ID ` packages/svelte/src/internal/client/reactivity/store.js::function::invalidate_store::3599 `. The model wrote this body under the wrong ID; it may be inaccurate.

`export function invalidate_store(stores, store_name)` · [packages/svelte/src/internal/client/reactivity/store.js:L113-L118][f2]

Re-assigns the entry's last seen source value back to its store via store_set, but only when the entry has a non-null store; otherwise it does nothing.

<a id="u-5762353cb5e2"></a>
### `mark_store_binding`

> **ID corrected by CBE.** CBE changed the unit ID from ` packages/svelte/src/internal/client/reactivity/store.js::function::mark_store_binding::182 ` to the inventory ID ` packages/svelte/src/internal/client/reactivity/store.js::function::mark_store_binding::5131 `. The model wrote this body under the wrong ID; it may be inaccurate.

`export function mark_store_binding()` · [packages/svelte/src/internal/client/reactivity/store.js:L182-L184][f2]

Sets the module-level is_store_binding flag to true; called inside prop getters so capture_store_binding can detect that a prop read is a store binding.

<a id="u-6bf992bdbb59"></a>
### `store_get`

`export function store_get(store, store_name, stores)` · [packages/svelte/src/internal/client/reactivity/store.js:L30-L74][f2]

Returns the current value of an auto-subscribed store, creating the container entry (store, mutable source, noop unsubscribe) on first access and labeling the source in DEV.

When the stored store differs from the requested one and the component is not unmounted, the old subscription is closed and a new one opened: the first synchronous callback writes entry.source.v directly to avoid state_unsafe_mutation inside deriveds, later callbacks use set; a null/undefined store just resets the source value to undefined with a noop unsubscribe. After unmount (IS_UNMOUNTED symbol present), no subscription is re-registered and the value is read straight from the store to stay consistent without leaking subscriptions. Otherwise it returns get(entry.source) so reads are reactive.

calls: [subscribe_to_store](r2-stores.md#u-863f9153e183), [packages/svelte/src/internal/client/runtime.js:get](r5-signal-core.md#u-98099fbbf12a), [packages/svelte/src/internal/client/reactivity/sources.js:set](r3-runtime-reactivity-sources.md#u-452914169f68)

<a id="u-83c162a9a0c9"></a>
### `store_mutate`

> **ID corrected by CBE.** CBE changed the unit ID from ` packages/svelte/src/internal/client/reactivity/store.js::function::store_mutate::151 ` to the inventory ID ` packages/svelte/src/internal/client/reactivity/store.js::function::store_mutate::4466 `. The model wrote this body under the wrong ID; it may be inaccurate.

`export function store_mutate(store, expression, new_value)` · [packages/svelte/src/internal/client/reactivity/store.js:L151-L154][f2]

Calls store.set(new_value) and returns the original expression value, so `$store += x`-style mutations evaluate to the full expression rather than the new store value.

<a id="u-f137b5f9bcce"></a>
### `store_set`

> **ID corrected by CBE.** CBE changed the unit ID from ` packages/svelte/src/internal/client/reactivity/store.js::function::store_set::104 ` to the inventory ID ` packages/svelte/src/internal/client/reactivity/store.js::function::store_set::3438 `. The model wrote this body under the wrong ID; it may be inaccurate.

`export function store_set(store, value)` · [packages/svelte/src/internal/client/reactivity/store.js:L104-L107][f2]

Calls store.set(value) and returns the value, so `$store = v` assignments evaluate to the assigned value.

<a id="u-acc685c0000a"></a>
### `store_unsub`

`export function store_unsub(store, store_name, stores)` · [packages/svelte/src/internal/client/reactivity/store.js:L84-L95][f2]

Unsubscribes from a container entry when its recorded store differs from the one now requested, resetting unsubscribe to noop but leaving entry.store intact so a subsequent store_get can resubscribe; this covers the case where a store is unsubscribed but the replacement is never subscribed.

Returns the store unchanged.

<a id="u-8f1bdc289c63"></a>
### `update_pre_store`

> **ID corrected by CBE.** CBE changed the unit ID from ` packages/svelte/src/internal/client/reactivity/store.js::function::update_pre_store::173 ` to the inventory ID ` packages/svelte/src/internal/client/reactivity/store.js::function::update_pre_store::4914 `. The model wrote this body under the wrong ID; it may be inaccurate.

`export function update_pre_store(store, store_value, d = 1)` · [packages/svelte/src/internal/client/reactivity/store.js:L173-L177][f2]

Pre-increment for numeric stores: computes store_value + d first, sets the store to it, and returns the new value.

<a id="u-afc78260326c"></a>
### `update_store`

> **ID corrected by CBE.** CBE changed the unit ID from ` packages/svelte/src/internal/client/reactivity/store.js::function::update_store::162 ` to the inventory ID ` packages/svelte/src/internal/client/reactivity/store.js::function::update_store::4688 `. The model wrote this body under the wrong ID; it may be inaccurate.

`export function update_store(store, store_value, d = 1)` · [packages/svelte/src/internal/client/reactivity/store.js:L162-L165][f2]

Post-increment for numeric stores: sets the store to store_value + d (d defaults to 1, -1 for decrements) and returns the pre-update store_value.

<a id="u-59b61f01da09"></a>
### `store.js-setup-stores`

`export function setup_stores()` · [packages/svelte/src/internal/client/reactivity/store.js:L124-L128][f2]

setup_stores returns an empty StoreReferencesContainer plus a cleanup function.

The cleanup wraps its work in teardown so it runs on component destruction: it unsubscribes every entry in the container and then defines a non-enumerable IS_UNMOUNTED property on the container, which store_get consults to avoid resubscribing for an unmounted component.

calls: [effects.js-trivial-effect-factories](r5-effects-module.md#u-191f01511fb1)

<a id="u-40a134e2a457"></a>
### `StaleReactionError`

`class StaleReactionError extends Error` · [packages/svelte/src/internal/client/constants.js:L35-L38][f3]

Defines the error class instantiated as the STALE_REACTION sentinel for aborted async reactions.

It extends Error with a fixed name 'StaleReactionError' and a message explaining that the reaction calling getAbortSignal() was re-run or destroyed; users can match reason.name to ignore it.

uses: [constants.js module code (L38–L43)][f3]

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/reactivity/async.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/reactivity/store.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/constants.js
