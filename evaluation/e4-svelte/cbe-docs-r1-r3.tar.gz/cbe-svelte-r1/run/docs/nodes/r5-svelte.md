# Svelte

**Capability.** Owns the Svelte framework end to end: the multi-phase compiler, the client signal/effect runtime, the public component API, server rendering, and the surrounding benchmarks and playground tooling.

Root of the responsibility tree. Navigate into the compiler pipeline, the client runtime, the public API surface, or the tooling. Shared AST/state infrastructure and shared string utilities are kept separate from their consumers.

**Children.**

- [Benchmark Suites](r5-benchmark-suites.md) `r5-benchmark-suites` · 5 unit(s)
- [SSR Playground Sandbox](r5-playground-sandbox.md) `r5-playground-sandbox` · 3 unit(s)
- [Shared Runtime Libraries](r5-shared-lib.md) `r5-shared-lib` · 3 unit(s)
- [Compiler](r5-compiler.md) `r5-compiler` · 0 unit(s)
- [Client Runtime](r5-client-runtime.md) `r5-client-runtime` · 0 unit(s)
- [Public Component API](r5-public-api.md) `r5-public-api` · 0 unit(s)
- [Server Rendering](r5-server-render.md) `r5-server-render` · 2 unit(s)

Parent: [Svelte Monorepo](svelte-monorepo.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
