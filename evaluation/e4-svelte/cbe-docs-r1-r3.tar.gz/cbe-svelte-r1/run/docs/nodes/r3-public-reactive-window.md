# Reactive Window Values

**Capability.** Module-level reactive views of browser state (including devicePixelRatio), each a ReactiveValue whose `current` reads live in a browser and is undefined on the server.

Use this subtree for reactive window/viewport values. Each value is built from the sources subtree's source/set primitives and tagged for dev tracing; BROWSER selects the read function.

**Depends on.**

- [Dev-Mode Diagnostics](r3-runtime-dev-tools.md) · graph-confirmed · 1 edge(s)
- [Signal Sources](r3-runtime-reactivity-sources.md) · graph-confirmed · 2 edge(s)

Parent: [Public Runtime Feature APIs](r3-public-api.md)

## Units (2)

<a id="u-19fa89d5393e"></a>
### `index-js-reactive-window-values`

`group` · [packages/svelte/src/reactivity/window/index.js:L1-L130][f1]

Module-level reactive views of window/browser state, each a `ReactiveValue` whose `current` is reactive in a browser and `undefined` on the server (`BROWSER` selects the read function).

`scrollX`/`scrollY` update on window `scroll`; `innerWidth`/`innerHeight`/`outerWidth`/`outerHeight` update on `resize`. `screenLeft`/`screenTop` poll in a self-rescheduling `requestAnimationFrame` chain, calling `update()` only when the tracked value changed between frames; their start function returns a teardown that cancels the pending frame. `online` subscribes to both window `online` and `offline` events and unsubscribes from both on teardown. The subscription lifetimes are managed by ReactiveValue's first-subscriber start/last-unsubscriber-stop contract defined elsewhere.

uses: [index-js-events](r1-events-api.md#u-f89d44628152)

**Uncertainties.**

- Whether `on`'s returned unsubscribe runs when the last subscriber unsubscribes depends on ReactiveValue, not visible here.
- Server-side `current` reads return `undefined` by construction of the `BROWSER` ternary; no other server guard is present.

<a id="u-c22347eadbab"></a>
### `DevicePixelRatio`

`class DevicePixelRatio` · [packages/svelte/src/reactivity/window/index.js:L131-L134][f1]

Instantiated once as `devicePixelRatio`; provides a reactive `current` getter for `window.devicePixelRatio`.

It holds a private `source` initialized to the browser DPR or `undefined` on the server. The constructor calls `#update()` only when `BROWSER`, and under `DEV` tags the source for tracing. `current` calls `get(this.#dpr)` to register reactivity and returns `window.devicePixelRatio` in a browser, `undefined` otherwise — so on the server reads are non-reactive and undefined. `#update` subscribes to a `matchMedia('(resolution: <current dppx>dppx)')` change event; when the DPR changes it sets the source, unsubscribes, and re-registers for the new resolution, yielding a self-chaining listener per DPR value.

calls: [source](r3-runtime-reactivity-sources.md#u-97497b70f31b), [DevicePixelRatio](r3-public-reactive-window.md#u-c22347eadbab)

**Uncertainties.**

- The docstring's claim that Chrome reacts to zoom but Firefox/Safari do not is environmental and unverifiable from source.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/reactivity/window/index.js
