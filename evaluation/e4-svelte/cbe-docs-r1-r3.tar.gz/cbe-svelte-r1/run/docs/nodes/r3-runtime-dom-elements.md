# DOM Elements, Bindings & Transitions

**Capability.** Element-level runtime behavior: event listener registration with effect teardown and reactive-context clearing, two-way bindings (element properties, contenteditable, focus, window size/scroll), form-reset plumbing, inline style application, element miscellany, and the Web Animations-based transition/animation managers that effects drive.

Use this subtree for runtime element wiring: how bindings listen to events without capturing reactive context, how transitions are attached to effects and dispatched, and how keyframe/animation managers are created. without_reactive_context in bindings/shared.js is reused by transitions and window bindings.

**Depends on.**

- [Effect Batching & Scheduling](r3-runtime-reactivity-batching.md) · model-inferred · 0 edge(s)
- [Signal Sources](r3-runtime-reactivity-sources.md) · model-inferred · 0 edge(s)

**Depended on by.**

- [Transition Configs](r3-public-transitions.md) · model-inferred · 0 edge(s)
- [Element integrations: custom elements, actions, bindings](r2-client-dom-elements.md) · graph-only · 11 edge(s)

Parent: [Client Runtime Internals](r3-runtime.md)

## Units (18)

<a id="u-8f0d8dd6601b"></a>
### `listen`

`export function listen(target, events, handler, call_handler_immediately = true)` · [packages/svelte/src/internal/client/dom/elements/bindings/shared.js:L18-L32][f1]

Registers a handler on an EventTarget for each listed event and removes all listeners when the enclosing effect is torn down.

Unless call_handler_immediately is false, the handler runs once at setup with no event argument.

calls: [effects.js-trivial-effect-factories](r5-effects-module.md#u-191f01511fb1)

<a id="u-adb7ad8d3643"></a>
### `listen_to_event_and_reset_event`

`export function listen_to_event_and_reset_event(element, event, handler, on_reset = h…` · [packages/svelte/src/internal/client/dom/elements/bindings/shared.js:L59-L76][f1]

Adds the binding's event listener wrapped in without_reactive_context, and chains a form-reset handler on the element: the previous reset handler (element.__on_r, if any) is composed with the new one, supporting multiple bindings on one element such as a checkbox with both group and checked binds.

The reset path invokes on_reset (defaulting to the main handler) with true, which handlers use to read default* values. Finally ensures the global form-reset listener exists via add_form_reset_listener.

calls: [without_reactive_context](r3-runtime-dom-elements.md#u-ff3a57d1f4f9), [add_form_reset_listener](r3-runtime-dom-elements.md#u-3524dfa24535)

<a id="u-ff3a57d1f4f9"></a>
### `without_reactive_context`

`export function without_reactive_context(fn)` · [packages/svelte/src/internal/client/dom/elements/bindings/shared.js:L38-L49][f1]

Runs fn with both the active reaction and active effect temporarily cleared (via set_active_reaction/set_active_effect), restoring both in a finally block; used so DOM-event handlers do not create reactive dependencies in whatever effect happens to be active.

calls: [runtime.js-module-state-setters](r5-signal-core.md#u-ac602620d878)

<a id="u-08959d6f86b1"></a>
### `bind_content_editable`

`export function bind_content_editable(property, element, get, set = get)` · [packages/svelte/src/internal/client/dom/elements/bindings/universal.js:L11-L31][f2]

Two-way binds a contenteditable element's innerHTML/textContent/innerText.

An input listener pushes element[property] to the setter. A render_effect reads get(): when the DOM content already differs, a nullish bound value pushes the current DOM content back to the model (keeping the DOM), otherwise it assigns value + '' to the property.

calls: [effects.js-trivial-effect-factories](r5-effects-module.md#u-191f01511fb1)

<a id="u-0d6d1a335820"></a>
### `bind_focused`

`export function bind_focused(element, set)` · [packages/svelte/src/internal/client/dom/elements/bindings/universal.js:L71-L75][f2]

Pushes whether the element is document.activeElement whenever it fires focus or blur, via listen (which also fires once at setup).

calls: [listen](r3-runtime-dom-elements.md#u-8f0d8dd6601b)

<a id="u-d45b9f5ce24a"></a>
### `universal.js-bind-property`

`export function bind_property(property, event_name, element, set, get)` · [packages/svelte/src/internal/client/dom/elements/bindings/universal.js:L41-L42][f2]

Binds an arbitrary element property via a custom event.

The handler pushes element[property] to set and is added as an event listener. If get is provided, a render_effect writes get() into element[property]; otherwise the handler runs once at setup. Teardown removal of the listener happens only for document.body, window, or document targets — other elements are presumably removed wholesale with their document, so no per-element cleanup occurs.

**Uncertainties.**

- Why teardown is limited to global targets relies on assumptions about element lifetime not stated in this file

<a id="u-8c08fbfaa5cf"></a>
### `bind_window_size`

`export function bind_window_size(type, set)` · [packages/svelte/src/internal/client/dom/elements/bindings/window.js:L64-L66][f3]

Pushes the requested window dimension (innerWidth/innerHeight/outerWidth/outerHeight) on window resize, with the handler wrapped in without_reactive_context so it does not capture reactive context.

calls: [listen](r3-runtime-dom-elements.md#u-8f0d8dd6601b)

<a id="u-cf4d20b48182"></a>
### `window.js-bind-window-scroll`

`export function bind_window_scroll(type, get, set = get)` · [packages/svelte/src/internal/client/dom/elements/bindings/window.js:L10-L13][f3]

Two-way binds window scrollX/scrollY.

The scroll handler (registered globally, passive) runs inside without_reactive_context, sets a scrolling flag, restarts a 100ms timeout whose clear callback resets the flag (a stand-in for scrollend), and pushes the current window scroll value. A render_effect applies get(): the first run is skipped so the page is not force-scrolled initially; otherwise, when not currently scrolling and the value is non-null, it scrolls to the value on the bound axis, keeps the other axis, sets the scrolling flag and its timeout. An additional effect invokes target_handler once, because browsers emit no scroll event for the initial non-smooth position. Teardown removes the global scroll listener.

**Uncertainties.**

- Whether a native scrollend event could replace the 100ms timer is left as a TODO in the source

<a id="u-3524dfa24535"></a>
### `add_form_reset_listener`

`export function add_form_reset_listener()` · [packages/svelte/src/internal/client/dom/elements/misc.js:L37-L58][f4]

Registers (once per document, guarded by a module flag) a capture-phase 'reset' listener that, one microtask after the event and only if not defaultPrevented, calls e.__on_r?.() on every form element.

The one-tick delay lets DOM properties update to their reset values first; capture phase prevents stopPropagation from hiding the event. Inputs register their reset hooks (e.g. input.__on_r) elsewhere.

<a id="u-7f00a79795f4"></a>
### `autofocus`

`export function autofocus(dom, value)` · [packages/svelte/src/internal/client/dom/elements/misc.js:L10-L21][f4]

Imperatively applies autofocus when value is true: sets dom.autofocus = true and queues a micro task that calls dom.focus() only if nothing else has been focused yet (document.activeElement is still the body).

Does nothing for falsy values.

calls: [task.js-queues](r4-task-scheduling.md#u-2af0814cc5ec)

<a id="u-d9f3f6cd0345"></a>
### `remove_textarea_child`

`export function remove_textarea_child(dom)` · [packages/svelte/src/internal/client/dom/elements/misc.js:L29-L33][f4]

Clears SSR-rendered textarea children during hydration, since a textarea's child text corresponds to defaultValue and would otherwise reappear on form reset.

Only acts while hydrating and when a first child exists, then clears all text content.

calls: [operations.js-dom-helpers](r2-client-dom-core.md#u-d9a22fc32463), [operations.js-node-navigation](r2-client-dom-core.md#u-a31f01c2fa93)

<a id="u-e45a1c8437a1"></a>
### `style.js-styles`

`function update_styles(dom, prev = {}, next, priority)` · [packages/svelte/src/internal/client/dom/elements/style.js:L10-L22][f5]

Applies inline styles with caching via dom.__style.

set_style: if hydrating or the cached value changed, it computes the full style attribute with to_style(value, next_styles) and writes it — removing the style attribute when the result is nullish, else assigning style.cssText — skipping the write during hydration when it matches the server-rendered attribute; it then caches value. When the main value is unchanged and next_styles exist, it updates properties individually via update_styles: an array form treats the two entries as normal-priority and '!important' styles, each diffed against the matching prev record; nullish values call removeProperty, others setProperty (with 'important' for the second entry). Returns next_styles.

calls: [to_style](r4-shared-runtime.md#u-50b25ac26373)

**Uncertainties.**

- update_styles never removes properties that disappear from next but were applied in a previous spread, unless the caller supplies them as null in next — inferred from the loop iterating next only.

<a id="u-734d10fe845f"></a>
### `transitions.js-transition`

`export function transition(flags, element, get_fn, get_params)` · [packages/svelte/src/internal/client/dom/elements/transitions.js:L184-L211][f6]

Creates a transition manager and pushes it onto the active effect's transitions list; pause_effect/resume_effect elsewhere drive in()/out()/stop.

Flags decode is_intro/is_outro/is_global; direction is 'both'/'in'/'out'; inert and the default overflow style are captured up front. get_options memoizes the user's transition config in current_options inside without_reactive_context, reusing existing options so an in-flight transition reverses smoothly instead of restarting. in(): restores inert; for non-intro transitions it aborts/resets the pending outro and returns; for intro-only it aborts a stale intro first; then dispatches introstart and animates in with the outro as counterpart, and on finish dispatches introend, aborts, clears intro and current_options, and restores overflow. out(fn): for non-outro transitions it calls fn, clears current_options, and returns; otherwise it sets inert, dispatches outrostart, animates out with the intro as counterpart, and on finish dispatches outroend and calls fn. stop aborts both. When the transition is a local intro (should_intro), global transitions always run; local ones run only after walking up past transparent parent effects to the nearest non-transparent block effect and checking it is absent or already ran (EFFECT_RAN), launching transition.in() inside an effect via untrack.

calls: [transitions.js-animate](r3-runtime-dom-elements.md#u-6d86403ab199), [without_reactive_context](r3-runtime-dom-elements.md#u-ff3a57d1f4f9), [effects.js-trivial-effect-factories](r5-effects-module.md#u-191f01511fb1), [untrack](r5-signal-core.md#u-aa0e067da463)

**Uncertainties.**

- Precise semantics of EFFECT_TRANSPARENT/BLOCK_EFFECT/EFFECT_RAN flags and should_intro are defined in modules not supplied here; the parent-walk behavior is inferred from the in-file comments and flag checks.

<a id="u-6d86403ab199"></a>
### `transitions.js-animate`

`function animate(element, options, counterpart, t2, on_finish)` · [packages/svelte/src/internal/client/dom/elements/transitions.js:L314-L372][f6]

Drives a Web Animations-based intro (t2 === 1) or outro (t2 === 0) and returns an Animation facade with abort/deactivate/reset/t.

If options is a function (deferred transition such as crossfade), it queues a micro task that resolves the config and re-enters animate, returning a facade that forwards to the eventual animation unless aborted beforehand. It deactivates the counterpart first; if the resolved options lack duration it calls on_finish immediately and returns a no-op facade with t() = t2. For a fresh intro (no counterpart) it applies tick(0,1) and generates initial keyframes from css(0,1). A dummy zero/delay-length animation with fill:'forwards' is created so keyframes only appear after DOM updates; its onfinish cancels the dummy, reads the counterpart's current t (defaulting to 1 - t2) so bidirectional transitions start from the current position, aborts the counterpart, and computes delta and scaled duration. If duration > 0: it samples css at n = ceil(duration/(1000/60)) eased steps into keyframes, adds inline overflow:hidden if any keyframe uses it (Safari <18 workaround), rebinds get_t to read animation.currentTime through the easing, and runs a loop calling tick(t, 1-t) while the animation plays; then creates the real animation (fill forwards) whose onfinish sets get_t to t2, calls tick(t2, 1-t2), and on_finish. abort cancels and nulls the effect and silences onfinish; deactivate neuters on_finish; reset calls tick(1,0) for outros; t reads get_t.

calls: [task.js-queues](r4-task-scheduling.md#u-2af0814cc5ec), [loop.js-raf-task-loop](r5-reactivity-wrappers.md#u-0486df452d62), [is_function](r5-internal-shared-utils.md#u-497b6c692c87)

**Uncertainties.**

- When css is absent and duration > 0, keyframes stays empty so the animation runs without style changes while timing still drives tick/on_finish — inferred from the code, untested here.
- The tick loop's dependency on animation.playState values other than 'running' terminating the loop relies on loop() semantics defined outside this file.

<a id="u-4d4f1b4690e2"></a>
### `transitions.js-animation`

`export function animation(element, get_fn, get_params)` · [packages/svelte/src/internal/client/dom/elements/transitions.js:L83-L100][f6]

Creates the animation manager for a keyed each-item move and attaches it to the current each item's .a slot (creating it if absent), always re-pointing item.a.element at the current element (handles tag changes on <svelte:element>).

The manager's measure() captures the element's bounding rect as `from`. apply() aborts any running animation, captures the `to` rect, and only when the rect actually moved calls the user's animate function with {from, to} and params, wrapping the result in animate() with a completion callback that aborts and clears it. fix() temporarily pins the element for layout — skipped if any CSS animations are already running, since their styles would override the fix — reading computed position/width/height (destructured to freeze getter values), and when position is not absolute/fixed it stores original inline styles, sets position/width/height absolutely, and applies a translate transform if the rect shifted relative to `from`. unfix() restores the saved original styles if fix() saved any.

calls: [transitions.js-animate](r3-runtime-dom-elements.md#u-6d86403ab199); uses: [packages/svelte/src/internal/client/dom/blocks/each.js][f7]

**Uncertainties.**

- measure/apply/fix/unfix invocation order is controlled by the each-block reconciliation code, not this file.
- `from` is only assigned by measure(); apply/fix assume measure ran first — behavior if it did not is undefined here.

<a id="u-fbaa1dadf713"></a>
### `css_to_keyframe`

`function css_to_keyframe(css)` · [packages/svelte/src/internal/client/dom/elements/transitions.js:L58-L70][f6]

Parses a CSS declaration string into a Keyframe object: splits on ';', then each part on ':'; if a part has no property or no value it stops parsing (break); each remaining property is camelCased via css_property_to_camelcase and paired with the trimmed value.

<a id="u-397113669a45"></a>
### `css_property_to_camelcase`

`function css_property_to_camelcase(style)` · [packages/svelte/src/internal/client/dom/elements/transitions.js:L35-L52][f6]

Converts a CSS property name to camelCase for Element.animate keyframes.

'float' maps to cssFloat and 'offset' to cssOffset; custom properties starting with '--' are returned unchanged; otherwise dash-separated segments after the first get their first letter uppercased and everything is joined.

<a id="u-4fbd2318aa9b"></a>
### `dispatch_event`

`function dispatch_event(element, type)` · [packages/svelte/src/internal/client/dom/elements/transitions.js:L24-L28][f6]

Dispatches a CustomEvent ('introstart'/'introend'/'outrostart'/'outroend') on the element inside without_reactive_context, so event-handler side effects do not register reactive dependencies.

calls: [without_reactive_context](r3-runtime-dom-elements.md#u-ff3a57d1f4f9)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/elements/bindings/shared.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/elements/bindings/universal.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/elements/bindings/window.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/elements/misc.js
[f5]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/elements/style.js
[f6]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/elements/transitions.js
[f7]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/blocks/each.js
