# Client Runtime

**Capability.** The browser-side machinery compiled components call into: component context frames, DOM construction and hydration of blocks/elements/events, client-side reactivity (async effects and stores), dev-mode tooling, and legacy compatibility helpers.

Compiled client output targets these modules exclusively. Context and reactivity are foundational; dom-rendering owns what appears on screen; dev-tooling-client is stripped or inert in production; legacy-client-helpers back old component semantics.

**Children.**

- [Component Context](r4-component-context.md) `r4-component-context` · 13 unit(s)
- [Client Dev Tooling](r4-dev-tooling-client.md) `r4-dev-tooling-client` · 6 unit(s)
- [DOM Rendering](r4-dom-rendering.md) `r4-dom-rendering` · 0 unit(s)
- [Client Reactivity](r4-client-reactivity.md) `r4-client-reactivity` · 18 unit(s)
- [Legacy Client Helpers](r4-legacy-client-helpers.md) `r4-legacy-client-helpers` · 1 unit(s)

**Depends on.**

- [Shared Runtime Utilities](r4-shared-runtime.md) · graph-confirmed · 2 edge(s)

**Depended on by.**

- [Benchmark Harness](r4-benchmark-harness.md) · model-inferred · 0 edge(s)

Parent: [Svelte Monorepo](r4-svelte-monorepo.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
