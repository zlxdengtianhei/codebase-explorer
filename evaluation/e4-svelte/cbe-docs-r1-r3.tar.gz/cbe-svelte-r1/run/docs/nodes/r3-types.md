# Ambient & Language-Server Types

**Capability.** TypeScript-only declarations: the ambient rune typings ($state/$derived/$effect/$props/$bindable/$inspect/$host, namespaces, Snapshot helpers), the ambient module for `*.svelte` imports, and the svelteHTML global namespace for the language server.

Use this subtree for editor/tooling type surface, not runtime behavior. The rune declarations mirror the runtime internals' actual implementations; Snapshot/TypedArray support $state.snapshot typing.

**Depends on.**

- [Client Runtime Internals](r3-runtime.md) · model-inferred · 0 edge(s)

Parent: [Svelte Repository](r3-svelte-monorepo.md)

## Units (30)

<a id="u-4202fbdda361"></a>
### `Comp`

`declare module '*.svelte' { // use prettier-ignore for a while because of https://git…` · [packages/svelte/src/ambient.d.ts:L1-L7][f1]

Ambient module declaration for `*.svelte` imports, typing every Svelte file's default export.

It declares `Comp` as a `LegacyComponentType` while aliasing `Comp` to `SvelteComponent`, so consumers importing a `.svelte` file get a type compatible with both Svelte 5 components and the legacy class-based component shape.

uses: [packages/svelte/src/index.d.ts:SvelteComponent](r4-legacy-component-types.md#u-4400c2aaf924)

**Uncertainties.**

- Exact compatibility semantics depend on `LegacyComponentType` from 'svelte/legacy', which is not supplied.

<a id="u-2c72cf970058"></a>
### `$state`

`declare function $state<T>(initial: T): T;` · [packages/svelte/src/ambient.d.ts:L23-L23][f1]

Declares the `$state` rune: given an initial value it returns that value typed as deeply reactive state.

The overload without an argument types the result as `T | undefined`. This is a type declaration only; the compiler rewrites `$state(...)` calls.

<a id="u-d8022686024e"></a>
### `ambient.d.ts module code (L7–L22)`

`module_region` · [packages/svelte/src/ambient.d.ts:L7-L22][f1]

Doc comments for `$state` — declares reactive state with a `$state(0)` example and a docs link.

Purely documentation preceding the overloads; no type behavior of its own.

<a id="u-e36177c921d2"></a>
### `ambient.d.ts module code (L94–L119)`

`export function raw<T>(initial: T): T;` · [packages/svelte/src/ambient.d.ts:L119-L119][f1]

Type-only declarations inside the `$state` namespace: `$state.raw` for non-deeply-reactive state that must be reassigned instead of mutated (two overloads, with and without an initial value returning `T | undefined`), and `$state.snapshot` returning `Snapshot<T>` for a static copy of a reactive proxy.

The namespace also exports `never`-typed deprecated constants (apply, arguments, bind, call, etc.) purely to suppress unhelpful intellisense for Function members.

uses: [Snapshot](r3-types.md#u-ca331752873a)

<a id="u-57fbe9201dad"></a>
### `ambient.d.ts module code (L120–L140)`

`module_region` · [packages/svelte/src/ambient.d.ts:L120-L140][f1]

Doc comment for `$state.raw` (non-reactive state, reassignment example, docs link) preceding the `raw` overloads.

<a id="u-56d4d055ac22"></a>
### `ambient.d.ts module code (L140–L176)`

`module_region` · [packages/svelte/src/ambient.d.ts:L140-L176][f1]

Deprecated `never`-typed constants (`apply`, `arguments`, `bind`, `call`, `caller`, `length`, `name`, `prototype`, `toString`) at the end of the `$state` namespace, plus surrounding comments — intellisense suppression only.

<a id="u-8b52742bb316"></a>
### `TypedArray`

`type TypedArray = | Int8Array | Uint8Array | Uint8ClampedArray | Int16Array | Uint16A…` · [packages/svelte/src/ambient.d.ts:L29-L40][f1]

Type-level helpers inside the `$state` namespace that support the `Snapshot<T>` computation.

`Primitive` covers scalar values left untouched by snapshots; `TypedArray` enumerates all numeric/bigint typed arrays; `Cloneable` lists everything `structuredClone` accepts (Web API types included); `NonReactive<T>` conditionally maps `SvelteDate`/`SvelteMap`/`SvelteSet` back to their plain counterparts, noting `URL` is uncloneable.

<a id="u-ca331752873a"></a>
### `Snapshot`

`type Snapshot<T> = T extends Primitive ? T : T extends Cloneable ? NonReactive<T> : T…` · [packages/svelte/src/ambient.d.ts:L82-L86][f1]

`Snapshot<T>` computes the static return type of `$state.snapshot`.

It resolves branch by branch: primitives stay as-is; `Cloneable` values become their `NonReactive` form; anything with a `toJSON(): R` becomes `R`; arrays become `Array<Snapshot<U>>`; plain indexable objects map each property recursively; every other case resolves to `never`, so non-snapshotable shapes produce an unusable type.

uses: [ambient.d.ts module code (L94–L119)](r3-types.md#u-e36177c921d2), [TypedArray](r3-types.md#u-8b52742bb316)

<a id="u-ae828316188b"></a>
### `packages/svelte/src/ambient.d.ts:Snapshot`

`type Snapshot<T> = T extends Primitive ? T : T extends Cloneable ? NonReactive<T> : T…` · [packages/svelte/src/ambient.d.ts:L86-L94][f1]

Doc comment describing `$state.snapshot` usage with a counter example and link.

Documentation only.

<a id="u-d43835e2aa6b"></a>
### `Snapshot.toJSON`

`toJSON(): infer R` · [packages/svelte/src/ambient.d.ts:L86-L86][f1]

The `toJSON(): infer R` arm of the `Snapshot<T>` conditional: types whose `toJSON` returns `R` snapshot to `R`.

Covered in the Snapshot unit; no separate logic.

<a id="u-6a9f2f0ad868"></a>
### `ambient.d.ts module code (L40–L43)`

`module_region` · [packages/svelte/src/ambient.d.ts:L40-L43][f1]

Trailing comment region of the `TypedArray` union; no behavioral content beyond closing the namespace member.

<a id="u-2c2caf668fbc"></a>
### `ambient.d.ts module code (L71–L74)`

`module_region` · [packages/svelte/src/ambient.d.ts:L71-L74][f1]

Doc comment for `NonReactive<T>` explaining it converts `SvelteDate`/`SvelteMap`/`SvelteSet` to non-reactive counterparts and that `URL` is uncloneable.

<a id="u-caae05624065"></a>
### `$derived`

`declare function $derived<T>(expression: T): T;` · [packages/svelte/src/ambient.d.ts:L177-L177][f1]

Declares the `$derived` rune: given an expression it returns the same value, typed so assignments through `$derived` produce derived state.

Type-only declaration; the compiler rewrites usage. The accompanying `$derived` namespace (not separately inventoried in detail) declares `by`, the deprecated `never` constants, and no other members.

<a id="u-7d128142cdcd"></a>
### `by`

`declare namespace $derived { /** * Sometimes you need to create complex derivations t…` · [packages/svelte/src/ambient.d.ts:L179-L197][f1]

`$derived.by(fn)` types the complex-derivation form of the `$derived` rune: it accepts a function and yields that function's return type `T`, letting multi-statement derivations reuse reactive dependencies evaluated inside `fn`.

Pure declaration; runtime semantics are implemented by the compiler and internals, not here.

<a id="u-a000fe2a97f5"></a>
### `ambient.d.ts module code (L197–L236)`

`module_region` · [packages/svelte/src/ambient.d.ts:L197-L236][f1]

Doc comment for `$derived` and the deprecated `never` constants in its namespace — documentation and intellisense suppression, no logic.

<a id="u-0f518f88c4b3"></a>
### `$effect`

`declare function $effect(fn: () => void | (() => void)): void;` · [packages/svelte/src/ambient.d.ts:L237-L237][f1]

Declares the `$effect` rune: accepts a function returning `void` or a cleanup function and returns `void`.

Per the doc comments, the effect runs after DOM update when dependencies change, the returned function runs before re-run or unmount, and effects do not run during SSR. Declaration only.

<a id="u-58b2476de4c8"></a>
### `ambient.d.ts module code (L256–L263)`

`declare namespace $effect { /** * Runs code right before a component is mounted to th…` · [packages/svelte/src/ambient.d.ts:L239-L256][f1]

Members of the `$effect` namespace: `pre` runs before DOM update (same cleanup contract as `$effect`, no SSR), `pending` returns the number of pending promises in the current boundary excluding child boundaries, `tracking` returns whether code runs inside a tracking context (false in component setup, true inside effects/templates), and `root` wraps a function in a non-tracked, non-auto-cleaning scope and returns the cleanup function it returned.

The namespace ends with `never`-typed deprecated constants to keep intellisense quiet.

<a id="u-d3df9b6f3cd0"></a>
### `ambient.d.ts module code (L285–L313)`

`module_region` · [packages/svelte/src/ambient.d.ts:L285-L313][f1]

Deprecated `never`-typed constants closing the `$effect` namespace after `root`; intellisense suppression only.

<a id="u-c8f790f3a756"></a>
### `$props`

`declare function $props(): any;` · [packages/svelte/src/ambient.d.ts:L346-L346][f1]

Declares the `$props` rune, returning `any`; components destructure its result to declare accepted props.

Declaration only; prop typing comes from the component's own type annotations.

<a id="u-3f31e0dcef64"></a>
### `ambient.d.ts module code (L313–L345)`

`module_region` · [packages/svelte/src/ambient.d.ts:L313-L345][f1]

Doc comment for `$props` with a destructuring example and docs link.

<a id="u-dc4ff634385e"></a>
### `id`

`declare namespace $props { /** * Generates an ID that is unique to the current compon…` · [packages/svelte/src/ambient.d.ts:L348-L356][f1]

`$props.id()` is typed to return a string ID unique to the current component instance, consistent between server and client during hydration (since 5.20.0).

Intended for linking elements via `for`/`aria-labelledby`. Declaration only.

<a id="u-8c6a22ee1199"></a>
### `ambient.d.ts module code (L356–L388)`

`module_region` · [packages/svelte/src/ambient.d.ts:L356-L388][f1]

Deprecated `never`-typed constants closing the `$props` namespace.

<a id="u-30ae4cccbd60"></a>
### `$bindable`

`declare function $bindable<T>(fallback?: T): T;` · [packages/svelte/src/ambient.d.ts:L389-L389][f1]

Declares the `$bindable` rune with an optional fallback argument, typed to return `T`; used inside `$props` destructuring to mark a prop as bindable by parents via `bind:`.

The `$bindable` namespace additionally declares the usual `never`-typed deprecated constants for intellisense suppression.

<a id="u-2ce44203bf9f"></a>
### `ambient.d.ts module code (L389–L431)`

`module_region` · [packages/svelte/src/ambient.d.ts:L389-L431][f1]

Doc comment for `$bindable` plus the deprecated `never` constants in its namespace.

<a id="u-26cc0b138679"></a>
### `$inspect`

`declare function $inspect<T extends any[]>( ...values: T ): { with: (fn: (type: 'init…` · [packages/svelte/src/ambient.d.ts:L432-L434][f1]

Declares `$inspect(...values)` for variadic values, returning `{ with }` where `with` accepts a callback invoked with the change type (`'init'` or `'update'`) and the values; by default values are console-logged.

Declaration only.

<a id="u-fe75e31e7979"></a>
### `trace`

`declare namespace $inspect { /** * Tracks which reactive state changes caused an effe…` · [packages/svelte/src/ambient.d.ts:L436-L452][f1]

`$inspect.trace(name?)` is typed to return `void` and, per its docs, must be the first statement of a function body to report which reactive state changes caused an effect to re-run.

Declaration only.

<a id="u-d01bb9a446d7"></a>
### `ambient.d.ts module code (L452–L494)`

`module_region` · [packages/svelte/src/ambient.d.ts:L452-L494][f1]

Doc comment for `$inspect` (including `.with` examples) plus the deprecated `never` constants in its namespace.

<a id="u-d08621bc6699"></a>
### `$host`

`declare function $host<El extends HTMLElement = HTMLElement>(): El;` · [packages/svelte/src/ambient.d.ts:L495-L495][f1]

Declares `$host<El extends HTMLElement>()` returning the custom element instance containing the component; per docs it is available only inside custom element components and only client-side.

The `$host` namespace carries only the `never`-typed deprecated constants for intellisense suppression.

<a id="u-624bfbc73776"></a>
### `ambient.d.ts module code (L495–L518)`

`module_region` · [packages/svelte/src/ambient.d.ts:L495-L518][f1]

Doc comment for `$host` with custom element example, plus deprecated `never` constants in its namespace.

<a id="u-f5408c56c57c"></a>
### `svelte-html-d-ts-module-region`

`type HTMLProps<Property extends string, Override> = Omit< import('./elements.js').Sve…` · [packages/svelte/svelte-html.d.ts:L11-L15][f2]

Declares a global svelteHTML namespace of TypeScript typings for the Svelte language server; this file is intentionally not exported via the package exports map and has no runtime counterpart.

HTMLProps<Property, Override> omits from SvelteHTMLElements[Property] the keys of Override and intersects the result with Override, so user augmentations of the HTMLAttributes/SVGAttributes interfaces override the base element props. mapElementTag maps an HTML tag name to its DOM element type, with overloads for ElementTagNameMap and SVGElementTagNameMap and a fallback returning any for <svelte:element> with dynamic tags. createElement comes in two- and three-argument overloads; both accept a Key that may be undefined or null (for <svelte:element>), type attrs as HTMLAttributes when Key is string (dynamic tag), intersect any provided attrsEnhancers type T with the attrs, and resolve the return type to the DOM element type for HTML or SVG tag maps, otherwise any. Empty HTMLAttributes and SVGAttributes interfaces exist purely as augmentation hooks kept for backwards compatibility until Svelte 6. IntrinsicElements extends SvelteHTMLElements from svelte/elements and redeclares every HTML element (with HTMLAttributes) and SVG element (with SVGAttributes) via HTMLProps, plus an index signature [name: string]: { [name: string]: any } allowing arbitrary custom elements.

uses: [svelte-html-d-ts-module-region](r3-types.md#u-f5408c56c57c)

**Uncertainties.**

- Because IntrinsicElements extends SvelteHTMLElements but also redeclares each key via HTMLProps, the effective props for a given tag depend on TypeScript interface merging semantics; exact resulting types cannot be verified here.
- The parser reports an ERROR node near line 1 (triple-slash reference / global augmentation structure), so line-boundary fidelity of this reading is approximate.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/ambient.d.ts
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/svelte-html.d.ts
