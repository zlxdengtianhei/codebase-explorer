# Client Runtime

**Capability.** Implements the signal/effect engine and the DOM behaviors compiled output calls into: signal reads and status tracking, effect lifecycle, each-block reconciliation, input bindings, reactive wrappers, and legacy in-component reactivity.

Enter here for how reactivity executes at runtime. The core graph (signals, reactions, effects) is separate from DOM blocks and bindings that sit on top of it, and from reactive collection/date wrappers.

**Children.**

- [Signal Core](r5-signal-core.md) `r5-signal-core` · 18 unit(s)
- [Internal Shared Utilities](r5-internal-shared-utils.md) `r5-internal-shared-utils` · 7 unit(s)
- [Effect Lifecycle](r5-effects-module.md) `r5-effects-module` · 17 unit(s)
- [Each Block](r5-each-block.md) `r5-each-block` · 19 unit(s)
- [Input Bindings](r5-input-bindings.md) `r5-input-bindings` · 7 unit(s)
- [Reactive Wrappers and Stores](r5-reactivity-wrappers.md) `r5-reactivity-wrappers` · 8 unit(s)
- [Legacy Component Reactivity](r5-legacy-internal.md) `r5-legacy-internal` · 2 unit(s)

**Depended on by.**

- [Benchmark Suites](r5-benchmark-suites.md) · model-inferred · 0 edge(s)

Parent: [Svelte](r5-svelte.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
