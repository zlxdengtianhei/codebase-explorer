# Public Type Declarations

**Capability.** The compile-time-only type vocabulary of every public module: the d.ts surface for svelte core/action/animate/attachments/compiler/easing/events/legacy/motion/reactivity/server/store/transition, the layered element/attribute typing system and SvelteHTMLElements mapping, the modern Component/Snippet/EventDispatcher/MountOptions contracts with branding, ambient rune and *.svelte declarations, the svelteHTML language-server namespace, and deprecated Svelte 4-era typings retained for compatibility.

Enter when authoring typed components, snippets or templates. Element typing is layered from foundations to per-element interfaces to the tag mapping; ambient declarations mirror runtime implementations. Every legacy typing unit is documented as deprecated in favor of the modern Component/mount surface.

**Depends on.**

- [Compiler Pipeline](compiler-pipeline.md) · model-inferred · 0 edge(s)
- [Public Reactive APIs & Features](public-reactive-apis.md) · model-inferred · 0 edge(s) · Action and animation type declarations describe contracts whose runtime implementations live in the public reactive APIs.

Parent: [Svelte Monorepo](svelte-monorepo.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
