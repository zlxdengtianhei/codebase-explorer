# Boundary & Async Blocks

**Capability.** Implements svelte:boundary effects (error, pending, failed snippets, pending counts, offscreen fragment moves) and async blocks that render once promises resolve inside the nearest pending boundary.

Use this for runtime error/pending semantics. Boundary owns context swapping and DOM relocation; async.js defers rendering until promises resolve and defers to the nearest boundary with a pending snippet.

**Depends on.**

- [Error Handling & Boundaries](r1-error-propagation.md) · graph-confirmed · 3 edge(s) · Boundaries register with the error-handling machinery so effect errors are routed to the nearest boundary.
- [Hydration Cursor State](r1-hydration-cursor.md) · graph-confirmed · 5 edge(s)
- [Effect Lifecycle](r5-effects-module.md) · graph-only · 13 edge(s)
- [Signal Core](r5-signal-core.md) · graph-only · 8 edge(s)

Parent: [Client Runtime](r1-runtime-client.md)

## Units (19)

<a id="u-725f5c0efa7a"></a>
### `boundary.js module code (L1–L46)`

`module_region` · [packages/svelte/src/internal/client/dom/blocks/boundary.js:L1-L46][f1]

Imports plus the BoundaryProps typedef (onerror, failed, pending) and the boundary effect flag combination EFFECT_TRANSPARENT | EFFECT_PRESERVED | BOUNDARY_EFFECT.

<a id="u-480575efeafb"></a>
### `Boundary`

`class Boundary` · [packages/svelte/src/internal/client/dom/blocks/boundary.js:L51-L119][f1]

Boundary effect for error, pending, and $effect.pending handling, owning main/pending/failed child effects, an offscreen fragment, and a pending counter.

`#effect_pending` is a lazily created source: `#effect_pending_subscriber` (createSubscriber) creates it on first subscription (DEV-tagged) and nulls it on teardown, while `#effect_pending_update` writes the current count into it, avoiding needless Batch.ensure flushes when $effect.pending() is unused. `has_pending_snippet` reports whether props.pending exists; `get_effect_pending` subscribes via the subscriber then reads the source, returning the live pending count.

**Notes.**

- field: `pending` mirrors whether the pending snippet is currently shown; initialized from !!props.pending and toggled as the count changes.

calls: [createSubscriber](r4-reactive-primitives.md#u-44838dbc4415), [source](r3-runtime-reactivity-sources.md#u-97497b70f31b), [internal_set](r3-runtime-reactivity-sources.md#u-0dae6a8d64cd)

<a id="u-54ea3a7a2c98"></a>
### `packages/svelte/src/internal/client/dom/blocks/boundary.js:Boundary`

`class Boundary` · [packages/svelte/src/internal/client/dom/blocks/boundary.js:L184-L189][f1]

Continuation fragment of the Boundary class body between methods; no separate behavior.

<a id="u-fef50a865b5f"></a>
### `packages/svelte/src/internal/client/dom/blocks/boundary.js:Boundary (2)`

`class Boundary` · [packages/svelte/src/internal/client/dom/blocks/boundary.js:L221-L224][f1]

Continuation fragment of the Boundary class body between methods; no separate behavior.

<a id="u-971663d15230"></a>
### `packages/svelte/src/internal/client/dom/blocks/boundary.js:Boundary (3)`

`class Boundary` · [packages/svelte/src/internal/client/dom/blocks/boundary.js:L241-L244][f1]

Continuation fragment of the Boundary class body between methods; no separate behavior.

<a id="u-476131750ce9"></a>
### `packages/svelte/src/internal/client/dom/blocks/boundary.js:Boundary (4)`

`class Boundary` · [packages/svelte/src/internal/client/dom/blocks/boundary.js:L257-L260][f1]

Continuation fragment of the Boundary class body between methods; no separate behavior.

<a id="u-cfba2bf7e16c"></a>
### `packages/svelte/src/internal/client/dom/blocks/boundary.js:Boundary (5)`

`class Boundary` · [packages/svelte/src/internal/client/dom/blocks/boundary.js:L363-L364][f1]

Closing fragment of the Boundary class body; no separate behavior.

<a id="u-719d2fff701a"></a>
### `boundary`

`export function boundary(node, props, children)` · [packages/svelte/src/internal/client/dom/blocks/boundary.js:L47-L49][f1]

Factory that instantiates a Boundary with the given node, props, and children; all behavior lives in the class.

uses: [Boundary](r1-boundary-blocks.md#u-480575efeafb)

<a id="u-078c9b337ba6"></a>
### `Boundary.constructor`

`constructor(node, props, children)` · [packages/svelte/src/internal/client/dom/blocks/boundary.js:L119-L180][f1]

Builds the boundary's block effect.

It stores anchor/props/children and the current hydration node, links `parent` to the enclosing boundary via active_effect.b, and sets `pending` from props.pending. Inside the block it registers itself as the enclosing effect's boundary and advances hydration. While hydrating with a pending snippet, the pending branch is created immediately and Batch.enqueue defers creating the main effect (via #run with Batch.ensure) until later, then either shows the pending snippet (pending_count > 0) or pauses the pending effect and clears `pending`. Otherwise children are branched directly with any thrown error routed to this.error, and pending is shown or cleared. When hydrating, the anchor afterwards becomes the current hydration node.

calls: [Boundary.#run](r1-boundary-blocks.md#u-f5286d8f1aba), [Boundary.#show_pending_snippet](r1-boundary-blocks.md#u-45c0b37226a1), [batch.js-batch-class](r3-runtime-reactivity-batching.md#u-6d22ee98690b)

<a id="u-f5286d8f1aba"></a>
### `Boundary.#run`

`#run(fn)` · [packages/svelte/src/internal/client/dom/blocks/boundary.js:L189-L208][f1]

Runs fn within the boundary's effect context: it swaps active effect, active reaction, and component context to this boundary's effect (and its ctx), restoring the previous values in finally.

If fn throws, handle_error reports it and the method returns null rather than propagating, so callers can treat null as 'failed to run'.

calls: [handle_error](r1-error-propagation.md#u-1b3b4fa2c18e)

<a id="u-6da36536328d"></a>
### `Boundary.error`

`error(error)` · [packages/svelte/src/internal/client/dom/blocks/boundary.js:L260-L288][f1]

Handles an error inside the boundary.

It first destroys and nulls any main, pending, and failed effects; while hydrating it rewinds to the opening hydration comment and removes the server-rendered nodes. It defines `reset`, which re-renders the children after clearing state: a second reset warns (svelte_boundary_reset_noop) and does nothing, and calling reset from within onerror throws svelte_boundary_reset_onerror; reset zeroes the pending count, pauses the failed effect, re-runs children via #run with #is_creating_fallback cleared, and shows the pending snippet or clears `pending`. If the error happened while building the fallback, or there is neither onerror nor failed, the error is rethrown for an outer boundary. Otherwise onerror is invoked with active_reaction temporarily nulled (errors from onerror go to invoke_error_boundary on the parent effect), and, when a `failed` snippet exists, a microtask creates the failed effect with #is_creating_fallback set, passing the error and reset to it; failures inside the fallback go to invoke_error_boundary on the parent effect.

calls: [Boundary.#run](r1-boundary-blocks.md#u-f5286d8f1aba), [invoke_error_boundary](r1-error-propagation.md#u-8ed809bdafb5), [task.js-queues](r4-task-scheduling.md#u-2af0814cc5ec)

<a id="u-45c0b37226a1"></a>
### `Boundary.#show_pending_snippet`

`#show_pending_snippet()` · [packages/svelte/src/internal/client/dom/blocks/boundary.js:L210-L221][f1]

Shows the pending snippet while keeping the main content alive: if a main effect exists, its DOM nodes are moved into a document fragment stored as #offscreen_fragment; if no pending effect exists yet, one is branched from props.pending at the anchor.

calls: [move_effect](r1-boundary-blocks.md#u-71a170980fd0)

<a id="u-4e6138a98e40"></a>
### `Boundary.#update_pending_count`

`#update_pending_count(d)` · [packages/svelte/src/internal/client/dom/blocks/boundary.js:L224-L241][f1]

Adjusts #pending_count by d.

When the count reaches 0, `pending` is set false, the pending effect is paused and nulled, and any offscreen fragment is reinserted before the anchor, restoring the main content.

calls: [pause_effect](r5-effects-module.md#u-340d218bcd6f)

<a id="u-48954c5681ed"></a>
### `Boundary.update_pending_count`

`update_pending_count(d)` · [packages/svelte/src/internal/client/dom/blocks/boundary.js:L244-L252][f1]

Public pending-count adjustment.

If this boundary has a pending snippet it applies the delta locally via #update_pending_count; otherwise it delegates to the parent boundary's #update_pending_count. In both cases it schedules #effect_pending_update via the module-level effect_pending_updates set so the $effect.pending source refreshes on the next flush.

**Uncertainties.**

- Behavior of the effect_pending_updates collection itself is defined outside this file.

<a id="u-71a170980fd0"></a>
### `move_effect`

`function move_effect(effect, fragment)` · [packages/svelte/src/internal/client/dom/blocks/boundary.js:L371-L382][f1]

Moves an effect's DOM range into the given fragment: it walks from effect.nodes_start through siblings (using get_next_sibling) appending each node until nodes_end, which is appended but not advanced past.

<a id="u-662729eaf177"></a>
### `get_pending_boundary`

`export function get_pending_boundary()` · [packages/svelte/src/internal/client/dom/blocks/boundary.js:L384-L396][f1]

Finds the nearest enclosing boundary (via active_effect.b and parent links) that has a pending snippet, walking up while boundaries lack one.

If none is found, it calls await_outside_boundary, which raises the corresponding error, before returning the boundary.

<a id="u-8bef95411436"></a>
### `packages/svelte/src/internal/client/dom/blocks/boundary.js:pending`

`export function pending()` · [packages/svelte/src/internal/client/dom/blocks/boundary.js:L398-L410][f1]

Implementation of $effect.pending().

It errors via effect_pending_outside_reaction if there is no active effect, returns 0 when the active effect has no boundary, and otherwise returns boundary.get_effect_pending().

**Uncertainties.**

- Comment notes returning 0 without a boundary is a temporary approximation.

<a id="u-c678d4665d37"></a>
### `boundary.js module code (L364–L370)`

`module_region` · [packages/svelte/src/internal/client/dom/blocks/boundary.js:L364-L370][f1]

Trailing exports after the Boundary class: move_effect, get_pending_boundary, pending.

<a id="u-0ce28dacb587"></a>
### `async`

`export function async(node, expressions, fn)` · [packages/svelte/src/internal/client/dom/blocks/async.js:L11-L26][f2]

Renders an async block once all its promise expressions resolve, inside the nearest async boundary.

Increments the pending count on the boundary from get_pending_boundary, then flattens the expressions; when values arrive it eagerly reads each derived with get so a rejection surfaces before any block is created, then calls fn with the anchor and values. The finally clause always decrements the pending count, whether fn succeeded or threw, so propagation is unchanged.

**Notes.**

- failure: Errors thrown by get or fn propagate after the pending count is decremented in finally

calls: [get_pending_boundary](r1-boundary-blocks.md#u-662729eaf177), [flatten](r4-client-reactivity.md#u-c50793421b66), [packages/svelte/src/internal/client/runtime.js:get](r5-signal-core.md#u-98099fbbf12a)

**Uncertainties.**

- Behavior when no pending boundary exists depends on get_pending_boundary, not shown here

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/blocks/boundary.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/blocks/async.js
