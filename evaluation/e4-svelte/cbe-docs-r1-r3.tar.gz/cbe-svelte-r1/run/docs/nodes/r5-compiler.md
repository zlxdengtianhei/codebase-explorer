# Compiler

**Capability.** Turns Svelte source into executable output via parse → analyze → transform, backed by a shared entry API, AST utilities, per-compilation state/error machinery, and type definitions.

Enter here for turning .svelte text into JS. Entry, utilities, state, and types are separate subtrees from the phase subtrees that consume them.

**Children.**

- [Compiler Entry API](r5-compiler-entry.md) `r5-compiler-entry` · 6 unit(s)
- [Compiler Type Definitions](r5-compiler-types.md) `r5-compiler-types` · 6 unit(s)
- [Compiler State and Errors](r5-compiler-state-errors.md) `r5-compiler-state-errors` · 9 unit(s)
- [Shared AST Utilities](r5-compiler-ast-utils.md) `r5-compiler-ast-utils` · 17 unit(s)
- [Parse Phase](r5-parse.md) `r5-parse` · 0 unit(s)
- [Analyze Phase](r5-analyze.md) `r5-analyze` · 0 unit(s)
- [Transform Phase](r5-transform.md) `r5-transform` · 0 unit(s)

**Depended on by.**

- [Benchmark Suites](r5-benchmark-suites.md) · model-inferred · 0 edge(s)

Parent: [Svelte](r5-svelte.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
