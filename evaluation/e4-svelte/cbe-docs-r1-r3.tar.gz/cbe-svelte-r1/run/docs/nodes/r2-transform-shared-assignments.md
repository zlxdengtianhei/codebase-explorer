# Shared transform assignment driver

**Capability.** Owns the platform-neutral driver for transforming assignment expressions reused by both client and server output generation.

A single focused utility: visit_assignment_expression decides how assignment targets are rewritten regardless of target platform. Kept separate from both transform phases per the shared-utility principle.

**Depended on by.**

- [Server \(SSR\) code generation](r2-transform-server.md) · graph-confirmed · 1 edge(s)

Parent: [Component compiler pipeline](r2-compiler.md)

## Units (1)

<a id="u-b43a982ab161"></a>
### `visit_assignment_expression`

`export function visit_assignment_expression(node, context, build_assignment)` · [packages/svelte/src/compiler/phases/3-transform/shared/assignments.js:L15-L93][f1]

Shared driver for transforming assignment expressions in client or server output.

For destructuring targets (ArrayPattern, ObjectPattern, RestElement) it visits the right-hand side, caches it in $$value when it is not a plain Identifier, and uses extract_paths to enumerate per-path assignments; generated $$array insert ids get fresh scope names. Each path is transformed through the supplied build_assignment callback; when the callback returns null a plain '=' assignment is emitted. If the callback reports no change at all, the original assignment is returned unchanged (null result). When inserts or caching are needed the assignments are wrapped in an arrow IIFE invoked with the original value, ending with a return of the cached value if used in expression position (is_standalone is determined by the parent path ending in 'Statement'); when any part is async the IIFE call is awaited. Otherwise a plain sequence expression is returned, again appending the value when in expression position. For non-destructuring targets, anything other than Identifier or MemberExpression throws 'Unexpected assignment type'; Identifier/MemberExpression targets are delegated to build_assignment with the original operator.

calls: [extract_paths](r5-compiler-ast-utils.md#u-34f2fcb20c62), [is_expression_async](r5-compiler-ast-utils.md#u-88399029ef9f)

**Uncertainties.**

- Behavior of the injected build_assignment callback is defined by callers, not here.
- extract_paths' insert/path shape is used as {id, value} / {id, expression, node} per the code, but its implementation is not supplied.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/shared/assignments.js
