# JS & Template Analysis

**Capability.** Analyzes JavaScript expression and element nodes: resolves runes on calls and validates their placement and arity, links identifier references to bindings, classifies variable declarators as rune-created state, and validates elements (a11y, SVG context, custom elements, attributes).

CallExpression::675 is the hub for rune validation, with helper predicates defining legal placements. Identifier::559 handles reference resolution; VariableDeclarator assigns binding kinds; the RegularElement visitor combines validation with attribute construction.

**Depends on.**

- [Compiler Semantic Model](r4-compiler-model.md) · graph-only · 11 edge(s)

Parent: [Analysis](r4-analyze-phase.md)

## Units (10)

<a id="u-d254c72e4204"></a>
### `CallExpression`

`export function CallExpression(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/CallExpression.js:L16-L266][f1]

Analyzes a call expression: resolves the callee as a rune and validates each rune's placement and arity.

For unknown callees, an unsafe identifier sets analysis.needs_context. $bindable requires zero/one args and an AssignmentPattern inside a $props object destructuring; $host takes no args and only exists in instance code of a custom element; $props and $props.id reject duplicates and invalid placements, with $props.id storing the identifier as analysis.props_id; $state/$derived family require variable declarations, non-static non-computed class property definitions, or constructor-root this-assignments, plus arity checks ($derived exactly one arg, others zero or one); $effect/$effect.pre require expression-statement placement, exactly one argument, and set needs_context; $effect.pending sets expression.has_state; $inspect(.with) enforce argument counts; $inspect.trace demands first statement in a function body, rejects generators, and in dev mode stores a tracing thunk on the scope (explicit argument or a synthesized label/location literal) setting analysis.tracing; $state.snapshot requires exactly one argument. Spread arguments are rejected for all non-$inspect runes. Traversal continues via context.next, with an incremented function_depth and fresh expression metadata for $derived (recording await as an async_derived) and $inspect; finally, when in expression context, an impure callee or any dependencies marks has_call/has_state.

**Notes.**

- side_effect: Mutates analysis.needs_context, has_props_rune, props_id, tracing, async_deriveds, and scope.tracing depending on the rune.
- condition: is_pure plus the expression-dependency check marks has_state, an accepted trade-off per the source's own TODO comment.

calls: [is_pure](r2-analyze-shared-validation.md#u-c8c562a3fb44), [is_safe_identifier](r2-analyze-shared-validation.md#u-63a6d609f552), [create_expression_metadata](r4-compiler-model.md#u-32bbb434f744), [get_rune](r4-compiler-model.md#u-5204b6ce4f7a), [locate_node](r5-compiler-state-errors.md#u-b35212eb6968), [get_parent](r5-compiler-ast-utils.md#u-427249cf438e), [is_variable_declaration](r4-js-template-analysis.md#u-83f04c95344f), [is_class_property_definition](r4-js-template-analysis.md#u-8c7c8294d17e), [is_class_property_assignment_at_constructor_root](r4-js-template-analysis.md#u-827e3436e5f6), [get_function_label](r4-js-template-analysis.md#u-3ee893476e43)

**Uncertainties.**

- context.next with incremented function_depth is relied upon to suppress the static-state-reference warning for $inspect/$derived, as stated in a comment; the downstream effect is not visible in this file.

<a id="u-3ee893476e43"></a>
### `get_function_label`

`function get_function_label(nodes)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/CallExpression.js:L271-L294][f1]

Builds a human-readable label for a function node for trace logging: named function declarations/expressions use their id; otherwise the label comes from the parent — a call expression yields 'calleeSource(...)', a non-computed property yields its key name, and an identifier variable declarator yields its name.

Returns undefined when none apply.

<a id="u-827e3436e5f6"></a>
### `is_class_property_assignment_at_constructor_root`

`function is_class_property_assignment_at_constructor_root(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/CallExpression.js:L315-L331][f1]

Returns true when the node is a plain '=' assignment to a this.member (non-computed identifier, private identifier, or literal key) located five path levels up inside a constructor MethodDefinition (AssignmentExpression → ExpressionStatement → BlockStatement → FunctionExpression → MethodDefinition).

Otherwise false.

calls: [get_parent](r5-compiler-ast-utils.md#u-427249cf438e)

<a id="u-8c7c8294d17e"></a>
### `is_class_property_definition`

`function is_class_property_definition(parent)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/CallExpression.js:L307-L309][f1]

Returns true when the parent is a non-static, non-computed PropertyDefinition, the valid placement for class-field state runes.

<a id="u-83f04c95344f"></a>
### `is_variable_declaration`

`function is_variable_declaration(parent, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/CallExpression.js:L300-L302][f1]

Returns true when the parent is a VariableDeclarator that is not inside a ConstTag (checked three levels up the path).

calls: [get_parent](r5-compiler-ast-utils.md#u-427249cf438e)

<a id="u-ac6549f7c9f9"></a>
### `packages/svelte/src/compiler/phases/2-analyze/visitors/Identifier.js:Identifier`

`export function Identifier(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/Identifier.js:L16-L192][f2]

Analyzes identifier nodes that are actual references (non-references return immediately, visiting children).

It marks the subtree dynamic; errors on 'arguments' outside any function; sets analysis.uses_slots for $$slots. In runes mode, unbound rune names are validated: member-access chains extend the rune name (computed members error), unknown or renamed runes error — $effect.active and $state.frozen suggest their renamed equivalents, $state.is is reported removed — and a rune not followed by a call errors for missing parentheses. In non-runes mode $$props/$$restProps set their analysis flags. When a binding exists: expression metadata records the dependency and reference; has_state is set when the binding is a prop/bindable_prop/rest_prop non-function (or non-static) and the evaluated node is not statically known. A closure-read of state/raw_state/derived bindings under matching function depth warns state_referenced_locally (typed 'derived' when read inside a $state/$state.raw call argument, else 'closure'), skipping writes. Reactive statements reading reassigned module-scope bindings warn reactive_declaration_module_state_dependency. Under experimental async, a {@const} bound template declaration referenced from an implicit children/failed/pending snippet at the same level errors via const_tag_invalid_reference.

**Notes.**

- side_effect: Adds bindings to context.state.expression.dependencies/references and sets uses_slots/uses_props/uses_rest_props flags.

calls: [mark_subtree_dynamic](r1-analysis-infra.md#u-3e6e9a44c2b4), [should_proxy](r4-client-transform.md#u-d089d4da67c8), [is_component_node](r4-compiler-model.md#u-1354bdeaaf38), [get_rune](r4-compiler-model.md#u-5204b6ce4f7a), [Scope](r4-compiler-model.md#u-01a82e58170d), [is_rune](r1-dom-dom-utils.md#u-ad49595ea2ed)

**Uncertainties.**

- The exact semantics of binding.updated and binding.is_function() come from scope.js and are not visible here.
- The snippet-scope matching for experimental async children references depends on analysis.scopes metadata not shown in this file.

<a id="u-4e50ac0ba74b"></a>
### `is_svg_element`

`const is_svg_element = () =>` · [packages/svelte/src/compiler/phases/2-analyze/visitors/RegularElement.js:L89-L106][f3]

Inline helper determining whether the element is SVG: true by name via is_svg; for <a> and <title> it walks the context path backwards and returns the nearest RegularElement ancestor's metadata.svg; otherwise false.

calls: [is_svg](r1-dom-dom-utils.md#u-890d02cea75e)

<a id="u-fde02037f904"></a>
### `packages/svelte/src/compiler/phases/2-analyze/visitors/RegularElement.js:RegularElement`

`export function RegularElement(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/RegularElement.js:L20-L89][f3]

First half of regular-element analysis: runs validate_element and a11y check_element, records the path and pushes the node to analysis.elements.

For <textarea> with children: an explicit value attribute errors (textarea_invalid_content); otherwise dynamic/multiple children are moved into a synthesized 'value' attribute, stripping a leading newline from a first Text node because browsers ignore it under innerHTML but not under the value property, and the fragment's children are cleared. A sole ExpressionTag child of <option> without a value attribute gains a fake 'value' attribute so value types stay consistent. An unused lowercase import binding matching the tag name warns component_name_lowercase. has_spread is set from spread attributes; svg/mathml metadata are computed (svg also checks <a>/<title> ancestors, falling back to the nearest RegularElement ancestor's svg metadata). Custom elements with attributes mark the subtree dynamic since attributes go through properties.

calls: [check_element](r1-a11y-analysis.md#u-0f7a175a707e), [validate_element](r3-compiler-analyze.md#u-7d4fa5b13c15), [create_attribute](r4-compiler-model.md#u-16d11cbbd59b), [is_svg](r1-dom-dom-utils.md#u-890d02cea75e); uses: [is_svg_element](r4-js-template-analysis.md#u-4e50ac0ba74b)

**Uncertainties.**

- The split between s0 and s1 segments is positional; unit boundaries within the function are inferred from the inventory, not from semantics.

<a id="u-ed2f4e653c33"></a>
### `packages/svelte/src/compiler/phases/2-analyze/visitors/RegularElement.js:RegularElement (2)`

`export function RegularElement(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/RegularElement.js:L106-L196][f3]

Second half of regular-element analysis.

When state.parent_element is set, it walks the path backwards: crossing IfBlock/EachBlock/AwaitBlock/KeyBlock ancestors downgrades errors to warnings (separate SSR templates make client-side nesting safe). Before reaching the named parent element, is_tag_valid_with_parent errors or warns; after it, each RegularElement ancestor name is accumulated and is_tag_valid_with_ancestor is checked; Component/SvelteComponent/SvelteElement/SvelteSelf/SnippetBlock ancestors stop the walk. It then strips a namespace prefix from the tag name and warns element_invalid_self_closing_tag for self-closing non-void, non-SVG, non-MathML elements. Traversal continues with parent_element set to this element's name. Afterwards, an <a> without a parent element inspects its children: a non-svg RegularElement child with svg metadata (other than <svg> itself) marks this element as svg.

**Notes.**

- side_effect: Mutates node.metadata.svg and sets parent_element for children via context.next.

calls: [mark_subtree_dynamic](r1-analysis-infra.md#u-3e6e9a44c2b4), [is_custom_element_node](r4-compiler-model.md#u-ea1f0b51e1e8), [is_tag_valid_with_ancestor](r1-html-tree-validation.md#u-c5a7f2f803ff), [is_tag_valid_with_parent](r1-html-tree-validation.md#u-a93dfa56dc6d), [is_mathml](r1-dom-dom-utils.md#u-7f1edff0d5fa), [is_void](r1-dom-dom-utils.md#u-9c54e843c710)

**Uncertainties.**

- context.state.parent_element is presumably established by the parent element's context.next in this same function; the initial value at the component root is not visible here.

<a id="u-8e1ff75e5298"></a>
### `VariableDeclarator`

`export function VariableDeclarator(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/VariableDeclarator.js:L16-L135][f4]

Analyzes variable declarators, the main place runes become binding kinds.

First ensure_no_module_import_conflict checks for name clashes. In runes mode: identifier names in the pattern are validated; if init is $state, $state.raw, $derived, $derived.by or $props, every extracted path's binding gets kind 'state', 'raw_state', 'derived', or (for $props) 'rest_prop'/'prop'. For `$props()`: the pattern must be an ObjectPattern or Identifier (else props_invalid_identifier); custom-element components without explicit props options warn custom_element_props_identifier on the identifier or first rest element; analysis.needs_props is set. An Identifier id becomes a rest_prop binding with initial cleared; ObjectPattern properties reject computed keys, `$$`-prefixed names and non-identifier values (props_invalid_pattern / props_illegal_name), set prop_alias from the key, and rewire initial — stripping `$bindable(...)` to its first argument and marking the binding bindable_prop, otherwise using the default value or null. In non-runes mode, calling $state/$derived/$props directly (unless shadowed by a store_sub binding) throws rune_invalid_usage. Always traverses via context.next().

**Notes.**

- failure: the ts-expect-error on binding lookup implies path.node.name may not correspond to an existing binding for exotic patterns; failure mode there is unproven

calls: [get_rune](r4-compiler-model.md#u-5204b6ce4f7a), [extract_paths](r5-compiler-ast-utils.md#u-34f2fcb20c62), [equal](r4-compiler-utils.md#u-2a153dd9dab6)

**Uncertainties.**

- equal(node.id.type, 'ObjectPattern') is an assertion that aborts if a non-Identifier $props pattern is not an ObjectPattern; whether that state is reachable depends on earlier checks not shown

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/CallExpression.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/Identifier.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/RegularElement.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/VariableDeclarator.js
