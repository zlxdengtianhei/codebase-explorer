# Legacy Reactivity Mode

**Capability.** Legacy (`svelte:options runes={false}`) support at runtime: capturing all signals read inside a function and force-invalidating them via internal_set so dependents re-run without value changes.

Use this subtree only when dealing with legacy-mode invalidation semantics. It depends on the sources subtree's internal_set for the forced writes.

**Depends on.**

- [Signal Sources](r3-runtime-reactivity-sources.md) · graph-confirmed · 1 edge(s)

Parent: [Client Runtime Internals](r3-runtime.md)

## Units (2)

<a id="u-901893964aa4"></a>
### `capture_signals`

`function capture_signals(fn)` · [packages/svelte/src/internal/client/legacy.js:L16-L34][f1]

Captures every signal read during `fn` by running it untrack-ed with the module-level captured_signals set temporarily replaced by a fresh Set; signal reads elsewhere presumably register into this set.

Nested captures merge their results into the enclosing set. The previous value is always restored in finally, and the new set is returned.

calls: [untrack](r5-signal-core.md#u-aa0e067da463)

**Uncertainties.**

- How signals end up added to captured_signals during untrack(fn) is not visible in this file

<a id="u-4dc669135a61"></a>
### `invalidate_inner_signals`

`export function invalidate_inner_signals(fn)` · [packages/svelte/src/internal/client/legacy.js:L42-L46][f1]

Deprecated legacy-mode helper: captures all signals read while running `fn` via capture_signals, then forces a write of each signal's own current value with internal_set so dependents are invalidated without changing values.

calls: [capture_signals](r3-runtime-legacy-mode.md#u-901893964aa4), [internal_set](r3-runtime-reactivity-sources.md#u-0dae6a8d64cd)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/legacy.js
