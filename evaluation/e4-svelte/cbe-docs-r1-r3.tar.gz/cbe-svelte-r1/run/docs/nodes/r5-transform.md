# Transform Phase

**Capability.** Converts the analyzed AST into client JS, server render code, and pruned CSS, via three cooperating output generators.

Enter per output target: client transform visitors and template building, CSS rendering, or server-side codegen. Each consumes the shared AST/state utilities.

**Children.**

- [Client Transform](r5-client-transform.md) `r5-client-transform` · 0 unit(s)
- [CSS Transform](r5-css-transform.md) `r5-css-transform` · 13 unit(s)
- [Server Transform](r5-server-transform.md) `r5-server-transform` · 6 unit(s)

Parent: [Compiler](r5-compiler.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
