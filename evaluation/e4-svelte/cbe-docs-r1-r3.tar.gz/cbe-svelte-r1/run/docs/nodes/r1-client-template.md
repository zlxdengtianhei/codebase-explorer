# Template Serialization

**Capability.** Accumulates a lightweight template node tree during markup traversal and serializes it as an HTML string template or a tree literal.

Use this to see how static markup becomes a compiled template. Visitors feed Template; stringify/objectify produce the two output formats.

**Depends on.**

- [DOM & Rune Constant Predicates](r1-dom-dom-utils.md) · graph-confirmed · 1 edge(s)

**Depended on by.**

- [Shared Client Transform Builders](r1-client-shared-transform-utils.md) · graph-confirmed · 5 edge(s)

Parent: [Client Transform Phase](r1-client-transform.md)

## Units (3)

<a id="u-f09b36ebd45e"></a>
### `Template`

`class Template` · [packages/svelte/src/compiler/phases/3-transform/client/transform-template/template.js:L9-L34][f1]

Accumulates a lightweight template node tree (elements, comments, text) that visitors populate while walking markup, then serializes it either as an HTML string template or as a tree literal.

State: nodes is the root list, #fragment tracks the current insertion list, #stack nests them, #element remembers the last opened element, and flags contains_script_tag / needs_import_node select special runtime instantiation. push_element appends a new element and descends into its children; push_comment and push_text append nodes to the current fragment; pop_element pops the stack so subsequent nodes become siblings; set_prop writes an attribute value onto the last opened element (no-op safety if none opened is not handled). as_html joins stringified nodes into one template quasi; as_tree maps nodes through objectify, first unshifting an extra comment when the root node is a comment so effect.start has an anchor.

**Notes.**

- contract: as_tree mutates this.nodes by unshifting a comment, so it is not side-effect free.

uses: [stringify](r1-client-template.md#u-61b15a4cd312), [objectify](r1-client-template.md#u-c628bcd2b8ab)

**Uncertainties.**

- as_tree reads this.nodes[0].type without guarding an empty nodes list.

<a id="u-61b15a4cd312"></a>
### `stringify`

`function stringify(item)` · [packages/svelte/src/compiler/phases/3-transform/client/transform-template/template.js:L89-L116][f1]

Serializes a template node to an HTML string.

Text nodes concatenate raw source; comments render as <!--data--> or, when data is absent, as the placeholder '<!>'. Elements emit '<name' plus each attribute (value omitted entirely when undefined, otherwise escaped with escape_html(value, true)); void elements self-close as '<name/>' for XHTML compliance, all others emit children recursively then a closing tag.

calls: [escape_html](r5-shared-lib.md#u-0f499dd45547), [is_void](r1-dom-dom-utils.md#u-9c54e843c710)

<a id="u-c628bcd2b8ab"></a>
### `objectify`

`function objectify(item)` · [packages/svelte/src/compiler/phases/3-transform/client/transform-template/template.js:L119-L162][f1]

Serializes a template node into an estree array literal for the tree output format.

Text becomes a single string literal of concatenated data; a comment with data becomes ['// <data>'] and without data becomes null. An element becomes [name] plus, when it has attributes or children, either the attributes object or null as a placeholder; children are mapped recursively. Special case: for 'pre' and 'textarea' elements, a leading newline is stripped from the first child when it is a string literal, mirroring HTML parsing rules.

calls: [fix_attribute_casing](r5-client-template-transform.md#u-799dccdfecc2)

**Uncertainties.**

- Only a Literal first child is newline-stripped; a dynamic first child in pre/textarea is left untouched (visible in code, consequence at runtime unverified).

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/transform-template/template.js
