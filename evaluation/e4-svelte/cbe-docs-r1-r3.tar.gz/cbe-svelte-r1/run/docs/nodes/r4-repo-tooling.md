# Repository Tooling

**Capability.** Developer infrastructure at the repo root: the benchmark harness measuring reaction/GC cost of reactivity code, and the sandbox playground that compiles local sources for client and server and packages them into shareable URLs.

Nothing here ships in the library. Benchmark when changing reactivity internals; use the sandbox scripts to build and share playground snapshots. Configuration files pin compiler and Vite behavior for the sandbox.

**Children.**

- [Benchmark Harness](r4-benchmark-harness.md) `r4-benchmark-harness` · 11 unit(s)
- [Playground Sandbox](r4-playground-sandbox.md) `r4-playground-sandbox` · 9 unit(s)

**Depends on.**

- [Svelte Monorepo](r4-svelte-monorepo.md) · containment · → 0 / ← 0 edge(s) (ancestor direct units and descendant subtree; → follows ` r4-repo-tooling ` → ` r4-svelte-monorepo `)

Parent: [Svelte Monorepo](r4-svelte-monorepo.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
