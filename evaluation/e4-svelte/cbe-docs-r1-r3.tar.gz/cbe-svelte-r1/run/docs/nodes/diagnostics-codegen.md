# Diagnostic Message Codegen

**Capability.** Templates from which generated warning classes and per-code thrower/warner functions are produced for compile-time and client-side diagnostics, sharing one diagnostic shape.

Read these templates to understand the shape of generated diagnostic functions, not the message texts. The generator expands each placeholder per message; warnings also carry an internal suppress-or-record helper.

**Depends on.**

- [Shared Runtime Utilities](shared-runtime.md) · model-inferred · 0 edge(s)

**Depended on by.**

- [Compiler Pipeline](compiler-pipeline.md) · containment · → 0 / ← 0 edge(s) (ancestor direct units and descendant subtree; → follows ` compiler-pipeline ` → ` diagnostics-codegen `) · Compile warnings and thrown errors are generated from the diagnostics-codegen message templates.

Parent: [Compiler Pipeline](compiler-pipeline.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
