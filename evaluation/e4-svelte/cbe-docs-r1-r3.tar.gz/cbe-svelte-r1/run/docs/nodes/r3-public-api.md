# Public Runtime Feature APIs

**Capability.** User-facing reactive feature modules built on the client runtime: spring motion (class and deprecated store), CSS transition factories, and reactive window/browser values exposed as ReactiveValue instances.

Use this subtree to understand the exported feature behaviors users import directly. All of them consume the reactivity core (sources, tracing) from the runtime internals subtree.

**Children.**

- [Spring Motion](r3-public-motion.md) `r3-public-motion` · 8 unit(s)
- [Transition Configs](r3-public-transitions.md) `r3-public-transitions` · 8 unit(s)
- [Reactive Window Values](r3-public-reactive-window.md) `r3-public-reactive-window` · 2 unit(s)

Parent: [Svelte Repository](r3-svelte-monorepo.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
