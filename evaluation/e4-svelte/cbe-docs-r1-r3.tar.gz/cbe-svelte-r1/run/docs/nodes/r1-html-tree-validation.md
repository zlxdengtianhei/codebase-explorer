# HTML Nesting Validation

**Capability.** Encodes HTML content-model rules: whether a tag is valid under its direct parent or farther ancestors, and when closing tags are auto-omitted.

Use this to check element placement rules independent of Svelte. The SSR dev module consumes the parent/ancestor validators to emit placement warnings.

**Depended on by.**

- [SSR Dev Validation](r1-ssr-dev.md) · graph-confirmed · 2 edge(s)

Parent: [Shared Utilities](r1-shared-utilities.md)

## Units (3)

<a id="u-a93dfa56dc6d"></a>
### `is_tag_valid_with_parent`

`export function is_tag_valid_with_parent(child_tag, parent_tag, child_loc, parent_loc)` · [packages/svelte/src/html-tree-validation.js:L186-L240][f1]

Validates an element against its direct parent, returning an error message or null.

Always valid when either tag is a custom element (contains '-') or the parent is 'template'. Builds child/parent label strings (with optional locations) before the checks. With a `disallowed_children` entry for the parent: a `direct` match yields 'cannot be a direct child of', a `descendant` match yields 'cannot be a child of', and an `only` entry permits listed children but otherwise reports the full allow-list. Tags not matched above are then checked against the structural whitelist: `body`/`caption`/`col`/`colgroup`/`frameset`/`frame`/`head`/`html` are invalid in any known parent; `thead`/`tbody`/`tfoot` require a `<table>` parent; `td`/`th` require a `<tr>`; `tr` requires `thead`/`tbody`/`tfoot`. Any other child returns null (valid).

uses: [html-tree-validation.js module code (L74–L145)][f1], [packages/svelte/src/compiler/phases/2-analyze/visitors/RegularElement.js:RegularElement (2)](r4-js-template-analysis.md#u-ed2f4e653c33)

<a id="u-c5a7f2f803ff"></a>
### `is_tag_valid_with_ancestor`

`export function is_tag_valid_with_ancestor(child_tag, ancestors, child_loc, ancestor_…` · [packages/svelte/src/html-tree-validation.js:L146-L175][f1]

Validates an element against its grandparent-and-up ancestors, returning an error message or null.

Custom elements (tag containing '-') are always valid. Looks up `disallowed_children` for the nearest ancestor (last entry); if none, valid. If the entry has `reset_by`, walks the remaining ancestors downward and returns null (valid) when any is a custom element or is listed in `reset_by` — a reset means forbidden descendants are allowed again. If the entry's `descendant` list contains `child_tag`, returns a message of the form `` `<child>` cannot be a descendant of `<ancestor>` ``, embedding locations in parentheses when `child_loc`/`ancestor_loc` are provided; otherwise null.

uses: [html-tree-validation.js module code (L74–L145)][f1], [packages/svelte/src/compiler/phases/2-analyze/visitors/RegularElement.js:RegularElement (2)](r4-js-template-analysis.md#u-ed2f4e653c33)

**Uncertainties.**

- Only the `descendant` and `reset_by` entry shapes are consulted here; `direct`/`only` entries in disallowed_children are ignored by this function.

<a id="u-10b29d40ea2b"></a>
### `closing_tag_omitted`

`export function closing_tag_omitted(current, next)` · [packages/svelte/src/html-tree-validation.js:L63-L74][f1]

Reports whether an HTML element's closing tag will be auto-omitted by the parser given the next sibling.

Looks up `autoclosing_children` for `current`; if an entry exists and `next` is missing (tag is last sibling, so implicitly autoclosed) or `next` appears in the entry's `direct` list (or `descendant` list when no `direct` key exists), returns true; otherwise false. Used by the parser when an element tag closes.

uses: [html-tree-validation.js module code (L1–L62)][f1]

**Uncertainties.**

- If `autoclosing_children[current]` has neither 'direct' nor 'descendant' keys the spread branch reads `disallowed.descendant` as undefined and `.includes` would throw; the defined map never has such a shape.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/html-tree-validation.js
