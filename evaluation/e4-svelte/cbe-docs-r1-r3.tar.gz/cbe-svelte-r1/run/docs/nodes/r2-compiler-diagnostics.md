# Compile diagnostics

**Capability.** Owns the error object model (InternalCompileError wrapping a shared CompileDiagnostic) and the exported factory functions that raise each specific compile-time error via the internal e() helper.

Look up any compiler error message here. Every phase raises diagnostics through this single mechanism, giving thrown errors and warnings one object shape. The ~200 factories are pure throwers with no other behavior.

**Depended on by.**

- [Analyze-phase AST visitors](r2-analyze-visitors.md) · model-inferred · 0 edge(s)
- [Development-mode guards and tracing](r2-client-dev.md) · model-inferred · 0 edge(s)
- [Reactivity core \(signals and deriveds\)](r2-client-reactivity.md) · model-inferred · 0 edge(s)
- [Compiler option validation](r2-compiler-options.md) · model-inferred · 0 edge(s)
- [Syntax parsing \(template expressions and CSS\)](r2-compiler-parsing.md) · model-inferred · 0 edge(s)
- [Client code generation](r2-transform-client.md) · model-inferred · 0 edge(s)
- [Server \(SSR\) code generation](r2-transform-server.md) · model-inferred · 0 edge(s)

Parent: [Component compiler pipeline](r2-compiler.md)

## Units (3)

<a id="u-9c7c186d9bb9"></a>
### `errors-js-exported-error-throwers`

`export function options_invalid_value(node, details)` · [packages/svelte/src/compiler/errors.js:L56-L58][f1]

Roughly 200 exported factory functions, each raising one specific compile-time error by delegating to the internal e() helper.

Every function takes a null/number/NodeLike node argument plus zero or more string parameters interpolated into a fixed message that ends with a https://svelte.dev/e/<code> documentation URL, then throws; none return normally (JSDoc says never). Messages are largely static per error code; notable variants: bind_invalid_name includes an optional explanation sentence only when provided, css_* and options_* and rune_* validate compiler options, CSS :global rules, and rune usage respectively, and typescript_invalid_feature embeds a long preprocessor guidance text. Because all functions share the identical throw-through-e pattern, they carry no per-function branching beyond optional interpolation.

calls: [packages/svelte/src/compiler/errors.js:e](r2-compiler-diagnostics.md#u-35e148f96f15); uses: [packages/svelte/src/compiler/errors.js:InternalCompileError](r2-compiler-diagnostics.md#u-38874e25f3b9)

**Uncertainties.**

- Whether any caller depends on the never return type for control-flow narrowing is outside this file.
- The bind_invalid_name template ternary is the only conditional; behavior of callers supplying non-string explanation values is unverified.

<a id="u-38874e25f3b9"></a>
### `packages/svelte/src/compiler/errors.js:InternalCompileError`

`class InternalCompileError extends Error` · [packages/svelte/src/compiler/errors.js:L6-L15][f1]

Error subclass that wraps a shared CompileDiagnostic so thrown errors and warnings share one object shape.

The constructor calls super(message), blanks this.stack to reduce noise, builds a CompileDiagnostic from (code, message, position), copies its properties onto this with Object.assign (making code/message/position enumerable), and sets name to 'CompileError'. The message field is declared as an own enumerable property with a default of ''. toString() and toJSON() simply delegate to the diagnostic's same-named methods, so serialization and formatting match warnings exactly.

**Notes.**

- side_effect: Object.assign copies diagnostic properties onto the error instance, so diagnostics carry the same enumerable shape as warnings.
- contract: this.stack is cleared in the constructor (not as a class property) to keep it non-enumerable.

imports: [class::CompileDiagnostic][f2]; group: [packages/svelte/src/compiler/errors.js:InternalCompileError](r2-compiler-diagnostics.md#u-38874e25f3b9)

**Uncertainties.**

- Whether bundler plugins rely on the 'CompileError' name or Error extension is asserted only by the code comment, not verified here.

<a id="u-35e148f96f15"></a>
### `packages/svelte/src/compiler/errors.js:e`

`function e(node, code, message)` · [packages/svelte/src/compiler/errors.js:L43-L48][f1]

Internal throw helper that converts a node-or-offset argument into a [start, end] position pair and throws an InternalCompileError.

If node is a number it is used as both start and end; otherwise start/end come from node?.start and node?.end. When start is undefined (node null or missing start) the position is undefined; otherwise end falling back to start yields a zero-width range. Always throws, so callers never receive a return value.

calls: [packages/svelte/src/compiler/errors.js:InternalCompileError](r2-compiler-diagnostics.md#u-38874e25f3b9)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/errors.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/utils/compile_diagnostic.js
