# Build & Repo Tooling

**Capability.** Repo-level infrastructure: bundling the compiler, lint policy, tree-shaking audits, and generated message templates.

Use this subtree for anything that builds or polices the package rather than implementing Svelte itself. Each child owns one autonomous tool with its own entry point and failure reporting.

**Children.**

- [ESLint Configuration](r1-lint-config.md) `r1-lint-config` · 3 unit(s)
- [Treeshakeability Audit](r1-treeshakeability-audit.md) `r1-treeshakeability-audit` · 4 unit(s)
- [Warning/Error Codegen Templates](r1-message-codegen-templates.md) `r1-message-codegen-templates` · 2 unit(s)

Parent: [Svelte Monorepo](r1-root.md)

## Units (1)

<a id="u-2eb418b9a160"></a>
### `rollup.config.js module code (L1–L17)`

`module_region` · [packages/svelte/rollup.config.js:L1-L17][f1]

Builds the Rollup configuration that compiles the Svelte compiler into a single UMD bundle.

Importing ./scripts/generate-version.js triggers version generation as a side effect at config load time. Entry is src/compiler/index.js; output goes to compiler/index.js as a UMD module exposing the global name 'svelte'. Plugins run in order resolve, commonjs, terser, so node module resolution, CommonJS interop, and minification are applied to the bundle.

**Notes.**

- side_effect: Importing the config executes scripts/generate-version.js, so loading the configuration writes/generated version artifacts before bundling.

uses: [rollup-config-js](../../catalog.json); imports: [rollup-config-js](../../catalog.json)

**Uncertainties.**

- Behavior of scripts/generate-version.js is not in the supplied source.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/rollup.config.js
