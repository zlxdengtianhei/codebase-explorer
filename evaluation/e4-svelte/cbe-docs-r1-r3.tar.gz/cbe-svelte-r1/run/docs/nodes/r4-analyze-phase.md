# Analysis

**Capability.** Walks the parsed tree to validate semantics: rune usage, identifiers and bindings, element attributes and a11y, and CSS scoping/global rules. Children split CSS-specific analysis from the JavaScript/template-expression visitors.

Use css-analysis for `:global`, keyframes, nesting, and unused-selector logic; use js-template-analysis for rune validation and binding-kind assignment. Both consume the scope model from compiler-model.

**Children.**

- [CSS Analysis](r4-css-analysis.md) `r4-css-analysis` · 12 unit(s)
- [JS & Template Analysis](r4-js-template-analysis.md) `r4-js-template-analysis` · 10 unit(s)

**Depends on.**

- [Compiler Semantic Model](r4-compiler-model.md) · graph-confirmed · 12 edge(s)
- [Compiler Utilities](r4-compiler-utils.md) · graph-confirmed · 1 edge(s)

Parent: [Compiler Pipeline](r4-compiler-pipeline.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
