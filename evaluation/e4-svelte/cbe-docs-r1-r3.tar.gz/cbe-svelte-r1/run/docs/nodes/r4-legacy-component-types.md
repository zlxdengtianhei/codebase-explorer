# Public Component Types (Legacy)

**Capability.** Deprecated Svelte 4-era typings retained for compatibility: the SvelteComponent/SvelteComponentTyped classes, ComponentConstructorOptions, ComponentType/ComponentEvents/Properties helpers, and their deprecation notes pointing to Component and mount().

Consult when supporting `asClassComponent`-style consumers or migrating old code; every unit here is documented as deprecated in favor of the modern component types.

**Depends on.**

- [Public Component Types \(Modern\)](r4-public-component-types.md) · model-inferred · 0 edge(s)

Parent: [Svelte Monorepo](r4-svelte-monorepo.md)

## Units (15)

<a id="u-4400c2aaf924"></a>
### `packages/svelte/src/index.d.ts:SvelteComponent`

`class SvelteComponent< Props extends Record<string, any> = Record<string, any>, Event…` · [packages/svelte/src/index.d.ts:L45-L59][f1]

Deprecated Svelte 4 base class for components, retained for typing under the `asClassComponent` compatibility helper; Svelte 5 components are functions and `mount` should instantiate instead.

Members: an optional static `element` (present only when compiled with `customElement`), an index signature `[prop: string]: any`, the deprecated constructor taking `ComponentConstructorOptions<Properties<Props, Slots>>`, and the `$$prop_def`/`$$events_def`/`$$slot_def`/`$$bindings` fields that exist only for type checking and explicitly not at runtime.

**Notes.**

- contract: All instance methods and the constructor are marked deprecated; new code must use Component/mount.

uses: [ComponentConstructorOptions](r4-legacy-component-types.md#u-4bdee22464d3)

**Uncertainties.**

- Actual runtime behavior of $destroy/$on/$set comes from the legacy compatibility layer, not this declaration file.

<a id="u-0d0fb760d434"></a>
### `SvelteComponentTyped`

`class SvelteComponentTyped< Props extends Record<string, any> = Record<string, any>, …` · [packages/svelte/src/index.d.ts:L177-L181][f1]

Deprecated typed subclass of `SvelteComponent<Props, Events, Slots>` with an empty body — it adds nothing but a named alias for typed legacy components.

Superseded by `Component`; kept for migration compatibility.

inherits: [packages/svelte/src/index.d.ts:SvelteComponent](r4-legacy-component-types.md#u-4400c2aaf924)

<a id="u-4bdee22464d3"></a>
### `ComponentConstructorOptions`

`export interface ComponentConstructorOptions< Props extends Record<string, any> = Rec…` · [packages/svelte/src/index.d.ts:L11-L24][f1]

Deprecated options interface for constructing Svelte 4-style component classes: `target` (Element/Document/ShadowRoot) is required; optional `anchor`, `props`, `context` (Map), `hydrate`, `intro`, `recover`, `sync`, `idPrefix`, `$$inline`.

Exists purely for typing the legacy constructor; `mount` replaces it in Svelte 5.

uses: [SvelteComponent.constructor](r4-legacy-component-types.md#u-65a1115d62ae)

<a id="u-ffcd52d1fafb"></a>
### `ComponentType`

`export type ComponentType<Comp extends SvelteComponent = SvelteComponent> = (new ( op…` · [packages/svelte/src/index.d.ts:L263-L270][f1]

Deprecated type for a component constructor: `new (options: ComponentConstructorOptions<...>) => Comp` (Props inferred from Comp where possible, else `Record<string, any>`), intersected with an optional `element` static for custom element builds.

Obsolete with the new `Component` type; historically used with `<svelte:component>`.

uses: [ComponentConstructorOptions](r4-legacy-component-types.md#u-4bdee22464d3), [packages/svelte/src/index.d.ts:SvelteComponent](r4-legacy-component-types.md#u-4400c2aaf924)

<a id="u-4598930afb2e"></a>
### `ComponentEvents`

`export type ComponentEvents<Comp extends SvelteComponent> = Comp extends SvelteCompon…` · [packages/svelte/src/index.d.ts:L201-L202][f1]

Deprecated convenience type extracting a component's Events: if `Comp` extends `SvelteComponent<any, infer Events>` it resolves to those Events, otherwise `never`.

Marked deprecated because the new `Component` type has no dedicated Events type.

<a id="u-cc0c44eeb3d1"></a>
### `Properties`

`type Properties<Props, Slots> = Props & (Slots extends { default: any } ? // This is …` · [packages/svelte/src/index.d.ts:L29-L37][f1]

Utility type adding `children?: any` to Props when the Slots type has a `default` slot, for legacy class-component compatibility.

When Props is `Record<string, never>` (accepts no props) it degrades to `any` — commented as unavoidable because TypeScript index signatures would otherwise make an unsatisfiable `children` type.

<a id="u-65a1115d62ae"></a>
### `SvelteComponent.constructor`

`constructor(options: ComponentConstructorOptions<Properties<Props, Slots>>)` · [packages/svelte/src/index.d.ts:L59-L59][f1]

Deprecated legacy constructor typed to accept `ComponentConstructorOptions<Properties<Props, Slots>>`; present only under the `asClassComponent` compatibility helper.

<a id="u-6ad6f4d54883"></a>
### `SvelteComponent.$on`

`$on<K extends Extract<keyof Events, string>>( type: K, callback: (e: Events[K]) => vo…` · [packages/svelte/src/index.d.ts:L97-L100][f1]

Deprecated typed event subscription for legacy components: subscribes a callback for event name `K` drawn from `Events` keys and returns an unsubscribe function.

<a id="u-befcb0b30a83"></a>
### `SvelteComponent.$set`

`$set(props: Partial<Props>): void` · [packages/svelte/src/index.d.ts:L107-L107][f1]

Deprecated partial-props update method of legacy class components, accepting `Partial<Props>`.

<a id="u-9af6c98fb226"></a>
### `SvelteComponent.$destroy`

`$destroy(): void` · [packages/svelte/src/index.d.ts:L90-L90][f1]

Deprecated teardown method of legacy class components, returning void.

<a id="u-005009562411"></a>
### `index.d.ts module code (L37–L44)`

`module_region` · [packages/svelte/src/index.d.ts:L37-L44][f1]

Doc comment above `SvelteComponent` marking it the Svelte 4 base class, deprecated in favor of `Component` for typing and `mount` for instantiation.

<a id="u-54de1ee82391"></a>
### `index.d.ts module code (L172–L176)`

`module_region` · [packages/svelte/src/index.d.ts:L172-L176][f1]

Deprecation doc comment above `SvelteComponentTyped` directing users to `Component`.

<a id="u-2a32051196d9"></a>
### `index.d.ts module code (L202–L233)`

`module_region` · [packages/svelte/src/index.d.ts:L202-L233][f1]

Deprecation note and usage example above `ComponentEvents`, showing a `ComponentEvents<Component>['close']` handler typing.

<a id="u-a0a9a4033bbe"></a>
### `index.d.ts module code (L24–L28)`

`module_region` · [packages/svelte/src/index.d.ts:L24-L28][f1]

Deprecation doc comment above `ComponentConstructorOptions` explaining Svelte 4 classes vs Svelte 5 functions and pointing to `mount` and the migration guide.

<a id="u-76d6693735b7"></a>
### `index.d.ts module code (L239–L262)`

`module_region` · [packages/svelte/src/index.d.ts:L239-L262][f1]

Doc comment and examples above `ComponentProps` including a generic `withProps` function illustration.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/index.d.ts
