# Svelte Monorepo

**Capability.** Umbrella for the Svelte ecosystem: the compiler pipeline that turns component sources into client/server JS, the client and server runtimes that execute compiled output, shared runtime utilities, the public type surface, reactive primitive implementations, and repository tooling such as benchmarks and the sandbox playground.

Start here to navigate the repository. Major responsibilities are split between the compiler (parse → analyze → transform), the runtimes that the compiler emits calls into, shared helpers used by both runtimes, public API/type declarations, and developer tooling. Cross-cutting conventions (runes, scopes, reactivity) flow from the compiler-model and reactivity nodes into every other area.

**Children.**

- [Compiler Pipeline](r4-compiler-pipeline.md) `r4-compiler-pipeline` · 0 unit(s)
- [Diagnostic Message Codegen](r4-diagnostics-messages.md) `r4-diagnostics-messages` · 5 unit(s)
- [Client Runtime](r4-client-runtime.md) `r4-client-runtime` · 0 unit(s)
- [Server Runtime](r4-server-runtime.md) `r4-server-runtime` · 7 unit(s)
- [Shared Runtime Utilities](r4-shared-runtime.md) `r4-shared-runtime` · 10 unit(s)
- [Public Component Types \(Modern\)](r4-public-component-types.md) `r4-public-component-types` · 16 unit(s)
- [Public Component Types \(Legacy\)](r4-legacy-component-types.md) `r4-legacy-component-types` · 15 unit(s)
- [Reactive Primitives & Motion](r4-reactive-primitives.md) `r4-reactive-primitives` · 11 unit(s)
- [Repository Tooling](r4-repo-tooling.md) `r4-repo-tooling` · 0 unit(s)

**Depended on by.**

- [Repository Tooling](r4-repo-tooling.md) · containment · → 0 / ← 0 edge(s) (ancestor direct units and descendant subtree; → follows ` r4-repo-tooling ` → ` r4-svelte-monorepo `)

Parent: [Svelte Monorepo](svelte-monorepo.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
