# Component compiler pipeline

**Capability.** Owns turning Svelte source text into executable client and server JavaScript through sequential phases: parse, analyze/validate, and transform, supported by diagnostics, option validation, and preprocessing with sourcemap integrity.

Use this subtree to understand how source becomes output. Children mirror the real phases because their responsibilities genuinely differ: reading syntax, enforcing semantics, generating code, and supporting infrastructure (errors, options, sourcemaps).

**Children.**

- [Syntax parsing \(template expressions and CSS\)](r2-compiler-parsing.md) `r2-compiler-parsing` · 18 unit(s)
- [Analysis validation core](r2-analyze-shared-validation.md) `r2-analyze-shared-validation` · 14 unit(s)
- [Analyze-phase AST visitors](r2-analyze-visitors.md) `r2-analyze-visitors` · 24 unit(s)
- [Client code generation](r2-transform-client.md) `r2-transform-client` · 22 unit(s)
- [Server \(SSR\) code generation](r2-transform-server.md) `r2-transform-server` · 16 unit(s)
- [Shared transform assignment driver](r2-transform-shared-assignments.md) `r2-transform-shared-assignments` · 1 unit(s)
- [Compile diagnostics](r2-compiler-diagnostics.md) `r2-compiler-diagnostics` · 3 unit(s)
- [Compiler option validation](r2-compiler-options.md) `r2-compiler-options` · 8 unit(s)
- [Preprocessing and sourcemap composition](r2-preprocess-sourcemaps.md) `r2-preprocess-sourcemaps` · 25 unit(s)

Parent: [Svelte compiler and runtime](r2-svelte.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
