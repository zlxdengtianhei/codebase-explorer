# Reactive Wrappers and Stores

**Capability.** Reactive stand-ins for platform objects (SvelteDate, SvelteSet) and store interop (toStore/fromStore), plus the requestAnimationFrame task loop; all read through signal-core so effects re-run on change.

Use when a builtin or store needs to participate in the dependency graph. The url.test suite documents SvelteURL behavior; the rAF loop drives per-frame tasks.

**Depends on.**

- [Effect Lifecycle](r5-effects-module.md) · graph-confirmed · 3 edge(s)
- [Signal Core](r5-signal-core.md) · graph-confirmed · 16 edge(s)
- [Signal Sources](r3-runtime-reactivity-sources.md) · graph-only · 14 edge(s)

Parent: [Client Runtime](r5-client-runtime.md)

## Units (8)

<a id="u-cb648e924acc"></a>
### `SvelteDate`

`class SvelteDate extends Date` · [packages/svelte/src/reactivity/date.js:L42-L51][f1]

A reactive subclass of the built-in Date whose reads from effects/deriveds re-run when the date changes.

Each instance stores its epoch time in a #time state initialized from super.getTime(), a Map of per-method derived sources, and captures the active_reaction at construction. On first construction (guarded by the module-level inited flag) it runs #init once for the whole class. Constructor and method patching are covered by their own units.

calls: [state](r3-runtime-reactivity-sources.md#u-acd426d0030b); uses: [function::active_reaction][f2]

<a id="u-ca8d0a0fef45"></a>
### `SvelteDate.#init`

`#init()` · [packages/svelte/src/reactivity/date.js:L62-L117][f1]

Runs once (module-level inited flag) to patch SvelteDate.prototype with reactive overrides of Date methods.

For each own property name of Date.prototype: names starting with 'get' or 'to', plus 'valueOf', become getters-with-behavior — if called with arguments they read #time (registering the dependency) and delegate directly to the Date method without memoization; with no arguments they return a cached derived that reads #time and applies the method. The derived is created lazily under set_active_reaction(this.#reaction), i.e. attributed to the reaction active at instance construction, then restored; results are read via get(d). Names starting with 'set' delegate to the Date method first, then write the new getTime() into #time, propagating change to all readers. Other method names (e.g. Symbol properties) are left untouched.

**Notes.**

- field: inited is module-scope, so #init patches the prototype exactly once for all instances.

calls: [packages/svelte/src/internal/client/reactivity/sources.js:set](r3-runtime-reactivity-sources.md#u-452914169f68), [packages/svelte/src/internal/client/runtime.js:get](r5-signal-core.md#u-98099fbbf12a), [runtime.js-module-state-setters](r5-signal-core.md#u-ac602620d878); imports: [packages/svelte/src/internal/client/index.js][f3]

**Uncertainties.**

- Whether Date.prototype includes accessor or symbol-keyed members that escape the startsWith filters depends on the runtime and is not established here.

<a id="u-41cdfeb6fcb9"></a>
### `SvelteDate.constructor`

`constructor(...params)` · [packages/svelte/src/reactivity/date.js:L51-L60][f1]

Forwards all constructor parameters to the Date superclass, then tags the #time source for tracing under DEV, and triggers the one-time prototype patching via #init when not yet inited.

calls: [tracing.js-tagging](r3-runtime-dev-tools.md#u-76249388f24e), [SvelteDate.#init](r5-reactivity-wrappers.md#u-ca8d0a0fef45)

<a id="u-e48f7e47221d"></a>
### `set.js-svelteset`

`class SvelteSet extends Set` · [packages/svelte/src/reactivity/set.js:L47-L57][f4]

SvelteSet is a reactive Set subclass: reading size, has, forEach/related read methods, or iterating in an effect re-runs it when the set changes; elements are not deeply reactive.

State is a per-element Map of boolean sources plus #version and #size states, with update_version snapshotted at construction. The constructor in DEV normalizes the iterable via new Set(value) so invalid input throws natively, tags the states, copies elements with super.add, writes #size.v directly, and calls #init once for the first instance ever (module-level inited flag) so the patching code can be tree-shaken. #source returns state(value) inside the creating reaction, source(value) otherwise. #init replaces prototype methods: forEach and other read_methods read #version then delegate to the Set prototype; set_like_methods (difference, intersection, symmetricDifference, union) read #version, delegate, and wrap the result in a new SvelteSet. has checks super.has first; for an absent value it reads #version (so a later add re-runs the effect) without creating a source, while a present value gets a lazily created true-valued source, tagged in DEV, which is then read. add only mutates when the element is new, updating #size and incrementing #version. delete always attempts super.delete; if a source exists it removes it and sets it to false, and only when an element was actually deleted updates #size and increments #version. clear is a no-op on an empty set; otherwise it clears the backing set first, sets all sources to false, clears sources, resets #size, and increments #version. values and entries read #version; keys delegates to values; [Symbol.iterator] delegates to keys; size returns get(#size).

uses: [state](r3-runtime-reactivity-sources.md#u-acd426d0030b); calls: [packages/svelte/src/internal/client/runtime.js:get](r5-signal-core.md#u-98099fbbf12a), [packages/svelte/src/internal/client/reactivity/sources.js:set](r3-runtime-reactivity-sources.md#u-452914169f68), [increment](r3-runtime-reactivity-sources.md#u-8fa6038c59d8)

**Uncertainties.**

- The graph suggests #init/has also consult runtime get for the sources created via #source; exact state-vs-source effects on dependency tracking depend on update_version bookkeeping outside this file.

<a id="u-b889e5535429"></a>
### `url.test.ts-svelteurl-tests`

`group` · [packages/svelte/src/reactivity/url.test.ts:L1-L120][f5]

Vitest suite for SvelteURL.

'url.hash' verifies hash reactivity: assigning hash updates hash readers, assigning href updates them, but changing pathname leaves hash effects untouched. 'url.href' verifies href readers re-run on search assignment and on searchParams append/delete/set, confirming searchParams mutations sync back to the URL. 'url.searchParams' verifies that effects reading url.search, searchParams.get('foo'), and searchParams.has('q') re-run appropriately when search is assigned or searchParams is mutated, including the case where deleting 'foo' does not affect the 'q' reader. 'SvelteURL instanceof URL' checks subclassing. All effect tests clean up via effect_root teardown.

<a id="u-0486df452d62"></a>
### `loop.js-raf-task-loop`

`export function loop(callback)` · [packages/svelte/src/internal/client/loop.js:L32-L44][f6]

Implements per-frame tasks driven by requestAnimationFrame.

run_tasks reads the current time via raf.now() (deliberately not the rAF callback argument), runs each task callback, and removes any task whose callback returns falsy, fulfilling its promise via the stored f function; if tasks remain it schedules itself for the next tick. loop(callback) registers a task ({c: callback, f: fulfill}) on first creation, scheduling run_tasks when the task set was empty, and returns a Task exposing a promise fulfilled when the callback first returns falsy, plus an abort() that deletes the task so its promise never fulfills through f.

uses: [timing.js module code (L1–L16)][f7]

**Uncertainties.**

- Whether deleting an aborted task from raf.tasks while run_tasks iterates is safe depends on Set.forEach semantics not stated here

<a id="u-49382b15058b"></a>
### `toStore`

`export function toStore(get, set)` · [packages/svelte/src/store/index-client.js:L47-L93][f8]

Creates a store from a getter (and optional setter) with reactive change propagation.

It captures `active_effect`/`active_reaction` and the initial value, then builds a `writable` whose start function runs on first subscribe: it detects whether the source changed before subscription (`ran = init_value !== get()`) to skip a redundant set, swaps in the captured effect/reaction via `set_active_*` so dependencies are tracked in the caller's context, and inside a `try/finally` (restoring the previous reaction/effect) creates an `effect_root` containing a `render_effect` that reads the getter and, after the first run, pushes new values into the store; the effect root teardown is returned as the store's stop function. If `set` was supplied the result is a `Writable`-shaped object `{set, update: fn => set(fn(get())), subscribe}`; otherwise only `{subscribe}`, i.e. readable.

calls: [writable](r2-stores.md#u-dc45d71b793b)

**Uncertainties.**

- Restoration of `active_reaction`/`active_effect` assumes no interleaving during the synchronous setup.
- Whether the getter is itself reactive depends on the caller's effect context at subscribe time.

<a id="u-706099be4040"></a>
### `fromStore`

`export function fromStore(store)` · [packages/svelte/src/store/index-client.js:L128-L144][f8]

Wraps a store in an object with a reactive `current` property.

It builds `subscribe` via `createSubscriber`: on first need, `store.subscribe` records each emitted value into a closure `value` and calls `update()` to invalidate readers after the first emission; the store unsubscribe is returned as teardown. Reading `current` checks `effect_tracking()`: inside a tracked effect it invokes `subscribe()` (starting the store subscription and registering the dependency) and returns the cached `value`; outside tracking it falls back to `get(store)`. If `'set' in store` the returned object also has a `current` setter delegating to `store.set(v)`; otherwise `current` is read-only.

calls: [createSubscriber](r4-reactive-primitives.md#u-44838dbc4415), [packages/svelte/src/store/shared/index.js:get](r2-stores.md#u-624938d77758)

**Uncertainties.**

- Whether a Writable-typed store lacking a runtime `set` key is handled is not guarded beyond the `'set' in store` check.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/reactivity/date.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/runtime.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/index.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/reactivity/set.js
[f5]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/reactivity/url.test.ts
[f6]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/loop.js
[f7]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/timing.js
[f8]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/store/index-client.js
