# Compiler Semantic Model

**Capability.** Shared semantic machinery for all phases: lexical scopes and bindings with unique-name generation, static partial evaluation of expressions, rune recognition, AST node construction/classification helpers, the bindable-property table, and CSS at-rule helpers. Every analyze and transform visitor depends on this vocabulary.

Readers should learn Scope/Binding/create_scopes first — nearly every visitor calls get_rune or queries scopes. nodes.js supplies predicates (is_component_node, is_custom_element_node) and metadata factories used across phases; bindings.js is the bindable-property lookup; css.js adds keyframes/vendor-prefix helpers.

**Depends on.**

- [Compiler Legacy Types](r4-compiler-legacy-types.md) · model-inferred · 0 edge(s)
- [Compiler Utilities](r4-compiler-utils.md) · model-inferred · 0 edge(s)
- [Shared AST Utilities](r5-compiler-ast-utils.md) · graph-only · 11 edge(s)

**Depended on by.**

- [Analysis](r4-analyze-phase.md) · graph-confirmed · 12 edge(s)
- [Client Transform](r4-client-transform.md) · graph-confirmed · 5 edge(s)
- [CSS Analysis](r4-css-analysis.md) · graph-confirmed · 1 edge(s)
- [Parsing](r4-parse-phase.md) · model-inferred · 0 edge(s)
- [Server Transform](r4-server-transform.md) · graph-confirmed · 9 edge(s)
- [Semantic Analysis](r3-compiler-analyze.md) · graph-only · 15 edge(s)
- [Client Transform Visitors](r5-client-transform-visitors.md) · graph-only · 15 edge(s)
- [JS & Template Analysis](r4-js-template-analysis.md) · graph-only · 11 edge(s)
- [Template Element Parsing](r5-template-parsing.md) · graph-only · 11 edge(s)

Parent: [Compiler Pipeline](r4-compiler-pipeline.md)

## Units (18)

<a id="u-0c91df12a429"></a>
### `Binding`

`class Binding` · [packages/svelte/src/compiler/phases/scope.js:L88-L140][f1]

Represents one declared identifier: the declaring scope, identifier node, binding kind, declaration kind, initializer, and every reference found to it.

Fields track whether the binding was mutated (`mutated`), reassigned (`reassigned`), its legacy reactive dependencies, and a prop alias for legacy export/rename syntax; `initial` records the initializing expression or node, e.g. for `let { foo = 'bar' } = $props()` it stores `'bar'`, not the `$props()` call.

**Notes.**

- field: metadata is a per-kind bag currently holding `inside_rest` and `is_template_declaration` flags set by scope creation.

**Uncertainties.**

- The JSDoc on `updated` labels it a getter-like member; it is defined as `get updated` and returns true when either mutated or reassigned is set.

<a id="u-006193dba8b7"></a>
### `Evaluation`

`class Evaluation` · [packages/svelte/src/compiler/phases/scope.js:L172-L230][f1]

Performs static partial evaluation of an expression into a set of possible values plus derived flags (`is_known`, `has_unknown`, `is_defined`, `is_string`, `is_number`, `is_function`, `value`).

The constructor registers itself in the module-level `current_evaluations` map (removed at the end) so recursive `Scope.evaluate` calls on the same expression node return the in-progress Evaluation instead of looping. Values may be concrete values, the sentinel symbols NUMBER/STRING/FUNCTION/UNKNOWN, or undefined.

**Notes.**

- condition: Identifier: a `$props.id()` binding yields STRING; an each-block index yields NUMBER; otherwise, if un-updated, non-prop, and non-null-initial, the initializer is evaluated recursively; `undefined` yields undefined; anything else yields UNKNOWN.
- condition: BinaryExpression: exact value when both sides are known; otherwise comparison operators add true and false, arithmetic operators add NUMBER, and `+` adds STRING, NUMBER, or both depending on the operands' string/number flags.
- condition: CallExpression: rune calls are special-cased (`$state`/`$derived` evaluate the first argument, `$props.id` is STRING, `$effect.tracking` adds both booleans, `$derived.by` evaluates only a concise arrow body); known global functions with all-known non-spread arguments are applied, otherwise the registered type symbol is added; everything else is UNKNOWN.
- condition: MemberExpression adds the value of Math/Number constants from global_constants when the keypath matches, else UNKNOWN; functions and all unhandled node types add FUNCTION or UNKNOWN respectively.
- field: After evaluation, flags are computed from the value set: any non-string (including the STRING symbol) clears is_string, null/UNKNOWN clears is_defined, UNKNOWN sets has_unknown, and more than one value or a symbol value clears is_known.

uses: [Scope](r4-compiler-model.md#u-01a82e58170d), [scope.js module code (L757–L809)][f1]; calls: [get_rune](r4-compiler-model.md#u-5204b6ce4f7a), [get_global_keypath](r4-compiler-model.md#u-7baae8d843b4), [is_rune](r1-dom-dom-utils.md#u-ad49595ea2ed)

**Uncertainties.**

- Concurrent evaluation of the same expression node from different scopes returns the first Evaluation via current_evaluations; whether values sets then alias each other's Sets is not guarded here.
- The class docstring marks flags readonly but nothing enforces that at runtime.

<a id="u-01a82e58170d"></a>
### `Scope`

`class Scope` · [packages/svelte/src/compiler/phases/scope.js:L564-L618][f1]

A lexical scope holding a name→Binding `declarations` map, declarator→bindings map, and observed references, linked to a parent scope and a shared ScopeRoot whose `conflicts` set feeds unique-name generation.

`#porous` marks scopes that let `var` and `import` declarations escape to the parent; `function_depth` increments only on non-porous children so block statements do not increase it, and `tracing` optionally enables reactive-dependency tracing.

**Notes.**

- condition: declare: `var` in a porous scope and every `import` declaration recurse into the parent; redeclaring a non-var name with a non-var kind throws the compiler error declaration_duplicate; otherwise a Binding is created, validate_identifier_name is run with function_depth, and the name is added to root.conflicts.
- condition: generate: replaces non-identifier characters with `_`, leading digits with `_`, then suffixes `_1`, `_2`, ... while the name collides with references, declarations, root.conflicts, or a reserved word; registers the chosen name as a reference and in root.conflicts; porous scopes delegate to the parent.
- condition: reference: copies the path to shield it from later mutation, records the reference on this scope, forwards to the parent when no local binding exists, and at the top level treats unbound names as globals by adding them to root.conflicts.
- failure: get_bindings throws Error('No binding found for declarator') when the declarator was never registered in this scope's declarators map.
- condition: evaluate returns a cached Evaluation if the expression is currently being evaluated (cycle guard) and otherwise constructs a new Evaluation that populates the passed or fresh values Set.

calls: [Evaluation](r4-compiler-model.md#u-006193dba8b7), [validate_identifier_name](r2-analyze-shared-validation.md#u-e442f835d467), [is_reserved](r1-dom-dom-utils.md#u-990ab32bfe83); uses: [Binding](r4-compiler-model.md#u-0c91df12a429), [get_rune](r4-compiler-model.md#u-5204b6ce4f7a)

**Uncertainties.**

- declare drops the `initial` argument when recursing for porous `var` declarations (it is not forwarded), so such bindings lose their initializer record.

<a id="u-8f49475011d6"></a>
### `ScopeRoot`

`class ScopeRoot` · [packages/svelte/src/compiler/phases/scope.js:L810-L817][f1]

Per-component root holding the global `conflicts` set shared by all scopes; ensures generated identifiers never collide across the whole component.

`unique(preferred_name)` sanitizes the name to identifier characters (but, unlike Scope.generate, allows a leading digit untouched), appends `_1`, `_2`, ... while the name is in `conflicts`, registers the winner, and returns it wrapped as an Identifier node via `b.id`. Each call permanently claims the name.

<a id="u-a24fbf023b97"></a>
### `create_scopes`

`export function create_scopes(ast, root, allow_reactive_declarations, parent)` · [packages/svelte/src/compiler/phases/scope.js:L838-L868][f1]

Single zimmerframe walk that builds the scope tree for a component AST: returns the root `scope`, a node→Scope map, and `has_await`.

It creates child scopes for functions, blocks, each/if-like fragments and components, records declarations (params, imports, variables, let/snippet/each/catch bindings), defers reference registration to a post-pass so references before declarations still resolve, and collects assignments/updates/bind-directive targets to mark bindings `reassigned` (direct identifier) or `mutated` (member of the pattern).

**Notes.**

- condition: Functions (Function/Arrow) create a scope, declare params via add_params (rest params get declaration kind 'rest_param'); FunctionExpression declares its own id inside the new scope while FunctionDeclaration declares the id in the enclosing scope with the node as initial.
- condition: BlockStatement reuses the function scope when its parent is a function node, else creates a porous block scope; For/Switch statements always create porous block scopes.
- condition: LabeledStatement: only a top-level `$:` label with allow_reactive_declarations gets a new scope; assignment targets not starting with `$` are queued as possible_implicit_declarations, which after the walk become `legacy_reactive` bindings if not already declared.
- condition: EachBlock visits the expression first, then declares context identifiers as 'each' bindings (flagging metadata.inside_rest by a nested walk over RestElement), declares the index as 'static' when the key is the index itself else 'template', and finally attaches metadata including a unique `$$index` name from scope.root.
- condition: AwaitBlock declares `then`/`catch` value and error identifiers as 'template' const in the block's scope and 'normal' const in a fresh child scope that scopes the value/error patterns.
- condition: SnippetBlock declares the whole parameter-less expression node as a 'function' binding on the outer scope (the snippet name), then declares parameters as 'snippet' let bindings in a child scope.
- condition: Component/SvelteSelf/SvelteComponent record the component name as a reference and store per-slot child scopes in node.metadata.scopes; LetDirective attributes are visited in the parent state when the node determines a slot, else in the default scope; children landing in a named slot get that slot's scope.
- condition: StyleDirective only creates a reference when value === true (shorthand form like style:height); transition/animate/use directives reference the directive's pre-dot name and visit their expression.
- side_effect: has_await is set once any AwaitExpression appears outside all function bodies, used by callers to opt into runes mode.
- condition: VariableDeclaration declares each extracted identifier with the statement kind, using kind 'template' under a ConstTag and setting metadata.is_template_declaration; declarators are registered in scope.declarators.

calls: [extract_identifiers](r5-compiler-ast-utils.md#u-90eb95affc00), [extract_identifiers_from_destructuring](r5-compiler-ast-utils.md#u-f5e86bd3328c), [unwrap_pattern](r5-compiler-ast-utils.md#u-73018823c866), [object](r5-compiler-ast-utils.md#u-2f2548aeaec6), [determine_slot](r3-compiler-shared-utils.md#u-ead26eb5b43f), [create_expression_metadata](r4-compiler-model.md#u-32bbb434f744); uses: [Scope](r4-compiler-model.md#u-01a82e58170d), [ScopeRoot](r4-compiler-model.md#u-8f49475011d6)

**Uncertainties.**

- The post-pass marks bindings only when object(expression) returns a root whose name resolves via scope.get; whether member expressions without a plain object root mark anything is not determinable from this excerpt.
- Whether `updates` handles destructuring assignment targets exactly as reassignment versus mutation depends on unwrap_pattern/object behavior not shown here.

<a id="u-7baae8d843b4"></a>
### `get_global_keypath`

`function get_global_keypath(node, scope)` · [packages/svelte/src/compiler/phases/scope.js:L1359-L1382][f1]

Builds a dotted keypath string for an unambiguous global reference, or returns null.

It walks nested non-computed MemberExpressions with Identifier properties, joins property names with dots, and appends '()' when the innermost callee of a CallExpression is a plain Identifier (so `Math.min()` becomes 'Math.min()'). Returns null for computed members, non-Identifier properties, or any other terminal node type. Finally, if the base identifier resolves to a scope binding, it returns null so locals and stores never masquerade as globals/runes.

uses: [Scope](r4-compiler-model.md#u-01a82e58170d)

**Uncertainties.**

- A `Super` base (allowed by the signature) is not handled by the MemberExpression loop, so paths through super fall through to the null-returning branches; exact behavior for such nodes rests on estree shapes not shown.

<a id="u-5204b6ce4f7a"></a>
### `get_rune`

`export function get_rune(node, scope)` · [packages/svelte/src/compiler/phases/scope.js:L1344-L1352][f1]

Returns the rune name (e.g. `$state`) for a CallExpression that invokes a rune, else null.

Null for null/non-CallExpression nodes; otherwise computes the callee's global keypath and requires both a keypath and is_rune(keypath) to be true. Because get_global_keypath returns null when the base identifier resolves to a scope binding, shadowed names never count as runes.

calls: [get_global_keypath](r4-compiler-model.md#u-7baae8d843b4), [is_rune](r1-dom-dom-utils.md#u-ad49595ea2ed)

<a id="u-2bb6e1e761ba"></a>
### `set_scope`

`export function set_scope(node, { next, state })` · [packages/svelte/src/compiler/phases/scope.js:L1334-L1337][f1]

Visitor helper that swaps the current scope when entering a node with an associated scope.

It looks the node up in `state.scopes`; if found and different from the current scope it continues the walk with a shallow-copied state whose `scope` is replaced, otherwise continues unchanged. Used to re-apply scopes in later passes over the same AST.

contract: [create_scopes](r4-compiler-model.md#u-a24fbf023b97)

<a id="u-16d11cbbd59b"></a>
### `create_attribute`

`export function create_attribute(name, start, end, value)` · [packages/svelte/src/compiler/phases/nodes.js:L54-L66][f2]

Constructs a plain `AST.Attribute` node from a name, source start/end offsets, and a pre-built value, initializing `metadata.delegated` to null and `metadata.needs_clsx` to false.

Pure factory: no parsing, validation, or side effects; callers supply the already-parsed value. Widely used by the parser and both transform passes.

<a id="u-32bbb434f744"></a>
### `create_expression_metadata`

`export function create_expression_metadata()` · [packages/svelte/src/compiler/phases/nodes.js:L71-L81][f2]

Creates a fresh ExpressionMetadata record with empty `dependencies` and `references` sets and all boolean flags (`has_state`, `has_call`, `has_member_expression`, `has_assignment`, `has_await`) false.

Pure factory so each caller gets independent sets; mutation of one result never affects another.

<a id="u-99af92983a86"></a>
### `get_name`

`export function get_name(node)` · [packages/svelte/src/compiler/phases/nodes.js:L86-L92][f2]

Extracts a printable name from an expression node for use as a property or class-member name.

`Literal` yields `String(node.value)` (so numbers and other literals are stringified); `PrivateIdentifier` yields `'#' + name`; `Identifier` yields the name; any other node type yields null. No validation that the string is a legal identifier.

<a id="u-1354bdeaaf38"></a>
### `is_component_node`

`export function is_component_node(node)` · [packages/svelte/src/compiler/phases/nodes.js:L31-L33][f2]

Reports whether a node is component-like, i.e. one of `Component`, `SvelteComponent`, or `SvelteSelf`, by membership test on `node.type`.

It is narrower than is_element_node: RegularElement and SlotElement are excluded. Acts as a type guard for the three component types.

<a id="u-ea1f0b51e1e8"></a>
### `is_custom_element_node`

`export function is_custom_element_node(node)` · [packages/svelte/src/compiler/phases/nodes.js:L39-L45][f2]

Decides whether a RegularElement or SvelteElement represents a custom element.

It returns false unless the node is a `RegularElement`. For a RegularElement it is true when the tag name contains a hyphen, or when any attribute is an `Attribute` named `is`. Both conditions are independent; either suffices. The list scan makes cost proportional to the attribute count.

**Notes.**

- condition: SvelteElement nodes always yield false even though the signature accepts them.

<a id="u-0d9a79ad394a"></a>
### `is_element_node`

`export function is_element_node(node)` · [packages/svelte/src/compiler/phases/nodes.js:L22-L24][f2]

Reports whether an AST node is an element-like node that can carry attributes and children anywhere in the tree.

It checks the node's `type` against the module-level `element_nodes` list (SvelteElement, RegularElement, SvelteFragment, Component, SvelteComponent, SvelteSelf, SlotElement); any other type returns false. The return doubles as a type guard in the compiler's TypeScript types.

uses: [nodes.js module code (L1–L21)][f2]

<a id="u-c619bf9805d8"></a>
### `bindings.js module code (L1–L227)`

`module_region` · [packages/svelte/src/compiler/phases/bindings.js:L1-L227][f3]

Defines the compile-time `binding_properties` table mapping Svelte bindable property names to BindingProperty metadata.

Each entry may declare `event` (DOM event signaling changes), `bidirectional` (values written back to the DOM property), `omit_in_ssr` (binding skipped during SSR), and `valid_elements`/`invalid_elements` (element allow/deny lists). Media, img, document, and window bindings are all SSR-omitted; dimension bindings (clientWidth, innerHTML, etc.) are invalid on svelte:window/svelte:document; input bindings like checked, group, value, files are bidirectional. `focused` has an empty entry: recognized but unconstrained.

**Uncertainties.**

- How compiler consumers interpret each flag is outside the supplied source.

<a id="u-8dc3955e3495"></a>
### `is_keyframes_node`

`export const is_keyframes_node = (node) =>` · [packages/svelte/src/compiler/phases/css.js:L14-L14][f4]

Tests whether a CSS Atrule node is a keyframes rule.

Returns true when remove_css_prefix applied to the node's name yields exactly 'keyframes', so vendor-prefixed forms like -webkit-keyframes count. Any other name returns false.

calls: [remove_css_prefix](r4-compiler-model.md#u-e3a939a3b9f2)

**Uncertainties.**

- Case sensitivity is not handled here; 'KEYFRAMES' returns false.

<a id="u-e3a939a3b9f2"></a>
### `remove_css_prefix`

`export function remove_css_prefix(name)` · [packages/svelte/src/compiler/phases/css.js:L9-L11][f4]

Strips a leading CSS vendor prefix from a property or at-rule name.

Replaces the first match of the regex /^-((webkit)|(moz)|(o)|(ms))-/ in the input name with the empty string and returns the result; the input string is not mutated. If no vendor prefix is present, the name is returned unchanged (a new string from replace).

uses: [is_keyframes_node](r4-compiler-model.md#u-8dc3955e3495)

**Uncertainties.**

- Only the first prefix occurrence is removed; a name with a nested or repeated prefix keeps later occurrences.

<a id="u-8ec309b68134"></a>
### `css-js`

`group` · [packages/svelte/src/compiler/phases/css.js:L1-L8][f4]

Module-level regex constants in the compiler CSS phase: regex_css_browser_prefix matches leading -webkit-, -moz-, -o-, or -ms- prefixes and backs remove_css_prefix; regex_css_name_boundary is exported and matches a single whitespace, comma, semicolon, or closing brace character, marking a CSS name boundary for other compiler code.

Both functions in this file delegate to these regexes with no branching.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/scope.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/nodes.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/bindings.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/css.js
