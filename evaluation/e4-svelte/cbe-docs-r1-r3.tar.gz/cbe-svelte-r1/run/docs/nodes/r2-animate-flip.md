# Animation runtime (flip)

**Capability.** Owns the runtime FLIP animation helper: computing the translate/scale config between previous and next bounding boxes, accounting for cumulative CSS zoom.

This is the runtime counterpart of the animate type contracts; public.d.ts has no runtime content, so flip and its zoom helper form their own small capability node.

**Depends on.**

- [Type contracts](r2-type-definitions.md) · model-inferred · 0 edge(s)

Parent: [Svelte compiler and runtime](r2-svelte.md)

## Units (2)

<a id="u-2953ae0602e1"></a>
### `flip`

`export function flip(node, { from, to }, params = {})` · [packages/svelte/src/animate/index.js:L13-L58][f1]

Computes an FLIP animation config translating and scaling an element from its previous bounding box (`from`) to its new one (`to`).

Params supply `delay` (default 0), `duration` (a number, or a function defaulting to `sqrt(d)*120`), and `easing` (default `cubicOut`). It reads computed styles at call time, derives the transform origin as a 0–1 fraction of client size, computes effective zoom via `get_zoom`, and scales positional deltas by `clientWidth/to.width/zoom` (height analogously), so parent transforms and CSS zoom affect the translation. Returns `{delay, duration, easing, css}`; a function `duration` receives `sqrt(dx²+dy²)`. The `css` callback prepends the existing computed `transform` string (empty when `style.transform === 'none'`) to an inverse translate/scale. Exceptions from `getComputedStyle` or parsing propagate uncaught.

calls: [get_zoom](r2-animate-flip.md#u-3fb604c120eb)

<a id="u-3fb604c120eb"></a>
### `get_zoom`

`function get_zoom(element)` · [packages/svelte/src/animate/index.js:L63-L78][f1]

Returns the cumulative effective CSS zoom of an element.

If `'currentCSSZoom' in element` it returns that property directly. Otherwise it walks the `parentElement` chain from the element, multiplying an accumulator (starting at 1) by the numeric value of each node's computed `zoom` style, returning the product when the chain ends at null.

uses: [flip](r2-animate-flip.md#u-2953ae0602e1)

**Uncertainties.**

- `zoom *= +getComputedStyle(current).zoom` is unguarded; a non-numeric computed `zoom` would yield NaN, affecting flip's output.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/animate/index.js
