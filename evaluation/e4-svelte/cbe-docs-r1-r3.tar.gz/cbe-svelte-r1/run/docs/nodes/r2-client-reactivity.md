# Reactivity core (signals and deriveds)

**Capability.** Owns the client reactive graph: creating lazily-evaluated derived signals (including safe-equal and async-derived variants), executing and updating them, and declaring the Signal/Value/Reaction/Effect type hierarchy.

Use this for how derived values are constructed, evaluated and destroyed, and how async-derived integrates with boundaries. types.d.ts holds the shape contracts (no runtime behavior). Uncertainty: effect scheduling itself lives outside the units seen here.

**Depends on.**

- [Compile diagnostics](r2-compiler-diagnostics.md) · model-inferred · 0 edge(s)

**Depended on by.**

- [Reactivity benchmarks](r2-benchmarking.md) · model-inferred · 0 edge(s)
- [Shared runtime utilities](r2-shared-internals.md) · model-inferred · 0 edge(s)
- [Store contract implementation](r2-stores.md) · model-inferred · 0 edge(s)

Parent: [Client runtime](r2-client-runtime.md)

## Units (15)

<a id="u-bf57b47b222b"></a>
### `deriveds.js-async-derived`

`export function async_derived(fn, location)` · [packages/svelte/src/internal/client/reactivity/deriveds.js:L100-L132][f1]

Creates a reactive source fed by a promise-returning function, wired into boundary suspension and batching.

It throws async_derived_orphan when there is no active effect. Inside an async_effect, fn() is called; a synchronous throw is converted into a rejected promise, and on re-runs the previous promise is chained with an empty catch to avoid unhandled rejections. should_suspend is true only when created outside any reaction; then each run calls boundary.update_pending_count(1) and, if the boundary was not already pending at run start, batch.increment(). handler resets prev, clears current_async_effect, and activates the current batch when !pending. On error, unless the error is STALE_REACTION, it sets the ERROR_VALUE flag and writes the error into the signal via internal_set; STALE_REACTION is silently dropped. On success it clears ERROR_VALUE, writes the value, and in DEV with a location schedules an await_waterfall warning via setTimeout if the signal is still unread. Suspension is undone with update_pending_count(-1) plus batch.decrement() when !pending, then unset_context() runs. The effect teardown queues a microtask calling batch.neuter(). The returned promise resolves with the signal only when the awaited promise is still the latest; otherwise next() follows the newer promise. In DEV the signal gets the ASYNC flag and current_async_effect is toggled around fn().

calls: [effects.js-trivial-effect-factories](r5-effects-module.md#u-191f01511fb1), [Boundary.update_pending_count](r1-boundary-blocks.md#u-48954c5681ed), [internal_set](r3-runtime-reactivity-sources.md#u-0dae6a8d64cd), [unset_context](r4-client-reactivity.md#u-2e39d8f937d3), [batch.js-batch-class](r3-runtime-reactivity-batching.md#u-6d22ee98690b)

**Uncertainties.**

- Batch.activate/increment/decrement/neuter semantics live in batch.js; their interplay with pending is inferred from call ordering only

<a id="u-d386336ed5eb"></a>
### `derived`

`export function derived(fn)` · [packages/svelte/src/internal/client/reactivity/deriveds.js:L55-L91][f1]

Constructs a lazily-evaluated Derived signal object for fn without running it.

Flags start as DERIVED|DIRTY. If the active reaction is itself a derived, it becomes the parent; otherwise the parent is the active effect. When there is no active effect, or the parent derived is UNOWNED, the new derived is marked UNOWNED; otherwise the active effect gets EFFECT_PRESERVED so it stays in the effect tree despite the derived's lazy evaluation. The signal captures component context, reference equality, and an UNINITIALIZED value; in DEV tracing mode it records a 'CreatedAt' stack.

calls: [get_stack](r3-runtime-dev-tools.md#u-507749353e33)

<a id="u-15f47648fe69"></a>
### `derived_safe_equal`

`export function derived_safe_equal(fn)` · [packages/svelte/src/internal/client/reactivity/deriveds.js:L245-L249][f1]

Creates a derived like derived(fn) but replaces its equals with safe_equals, so value changes are compared with the safer equality before propagating.

calls: [derived](r2-client-reactivity.md#u-d386336ed5eb)

<a id="u-a30c1fdac161"></a>
### `destroy_derived_effects`

`export function destroy_derived_effects(derived)` · [packages/svelte/src/internal/client/reactivity/deriveds.js:L255-L265][f1]

Destroys all effects created during a derived's last evaluation.

If derived.effects is non-null it is nulled first, so a concurrent rerun cannot destroy them twice, then each effect is passed to destroy_effect in order.

calls: [destroy_effect](r5-effects-module.md#u-214ad59ce57a)

<a id="u-193107029d03"></a>
### `execute_derived`

`export function execute_derived(derived)` · [packages/svelte/src/internal/client/reactivity/deriveds.js:L294-L327][f1]

Re-runs a derived's function and returns its new value, managing the surrounding effect context.

The active effect is temporarily set to the nearest non-derived ancestor found by walking derived.parent until a non-DERIVED parent is reached (null if none); it is restored in a finally block. In both DEV and production the derived's child effects are destroyed and update_reaction(derived) computes the value. In DEV only, a module-level stack detects self-reference: if the derived is already on the stack, derived_references_self is thrown; the derived is pushed before evaluation and popped in finally, and inspect_effects is swapped out and restored so inspect effects created here are isolated.

calls: [update_reaction](r5-signal-core.md#u-f6b808e008e3), [runtime.js-module-state-setters](r5-signal-core.md#u-ac602620d878), [destroy_derived_effects](r2-client-reactivity.md#u-a30c1fdac161)

<a id="u-7529e3342efc"></a>
### `set_from_async_derived`

`export function set_from_async_derived(v)` · [packages/svelte/src/internal/client/reactivity/deriveds.js:L43-L45][f1]

Assigns the module-level current_async_effect variable to the given effect or null; a plain assignment with no conditionals.

<a id="u-637b94af51bf"></a>
### `update_derived`

`export function update_derived(derived)` · [packages/svelte/src/internal/client/reactivity/deriveds.js:L333-L355][f1]

Evaluates a derived and updates its cached value and status.

After execute_derived, the value is stored and the write version incremented only when it differs per derived.equals. If is_destroying_effect is true it returns early without marking clean, avoiding caching a stale value read inside a cleanup function. Otherwise, if batch_deriveds is active the value is recorded in that map instead of changing status; otherwise the status becomes MAYBE_DIRTY when skip_reaction is set or the derived is UNOWNED while it has deps, and CLEAN in all other cases.

calls: [runtime.js-module-state-setters](r5-signal-core.md#u-ac602620d878), [set_signal_status](r5-signal-core.md#u-ebc2eda73ca2)

**Uncertainties.**

- Effect of batch_deriveds consumers is defined in batch.js, not visible here

<a id="u-81f409d392c6"></a>
### `user_derived`

`export function user_derived(fn)` · [packages/svelte/src/internal/client/reactivity/deriveds.js:L231-L237][f1]

Creates a derived with derived(fn) and registers it via push_reaction_value before returning it; no other logic.

calls: [derived](r2-client-reactivity.md#u-d386336ed5eb)

<a id="u-9d57285747d5"></a>
### `Derived`

`export interface Derived<V = unknown> extends Value<V>, Reaction` · [packages/svelte/src/internal/client/reactivity/types.d.ts:L54-L61][f2]

Type-only declaration of Derived extending Value and Reaction with fn, effects and parent; no runtime behavior.

<a id="u-2710975de280"></a>
### `Effect`

`export interface Effect extends Reaction` · [packages/svelte/src/internal/client/reactivity/types.d.ts:L63-L94][f2]

Type-only declaration of Effect extending Reaction with DOM nodes, teardown, transitions, effect-tree links, boundary and DEV fields; no runtime behavior.

<a id="u-dbffae4ef8ef"></a>
### `Reaction`

`export interface Reaction extends Signal` · [packages/svelte/src/internal/client/reactivity/types.d.ts:L43-L52][f2]

Type-only declaration of Reaction extending Signal with ctx, fn, deps and ac; no runtime behavior.

<a id="u-d7be5ea90299"></a>
### `Signal`

`export interface Signal` · [packages/svelte/src/internal/client/reactivity/types.d.ts:L10-L15][f2]

Type-only declaration of the Signal interface (flags f and write version wv); no runtime behavior.

<a id="u-4c170930dd4a"></a>
### `Value`

`export interface Value<V = unknown> extends Signal` · [packages/svelte/src/internal/client/reactivity/types.d.ts:L17-L41][f2]

Type-only declaration of Value extending Signal with equals, reactions, rv, v and optional DEV tracing fields; no runtime behavior.

<a id="u-09d9619b4ae2"></a>
### `MaybeSource`

`export type MaybeSource<T = unknown> = T | Source<T>;` · [packages/svelte/src/internal/client/reactivity/types.d.ts:L98-L98][f2]

Type alias MaybeSource<T> = T | Source<T>; type-only, no runtime behavior.

<a id="u-7d1c64b4718d"></a>
### `packages/svelte/src/internal/client/reactivity/types.d.ts:Source`

`export type Source<V = unknown> = Value<V>;` · [packages/svelte/src/internal/client/reactivity/types.d.ts:L96-L96][f2]

Type alias Source<V> = Value<V>; type-only, no runtime behavior.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/reactivity/deriveds.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/reactivity/types.d.ts
