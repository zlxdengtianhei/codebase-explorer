# Public Component Types (Modern)

**Capability.** The Svelte 5 public type surface of the `svelte` entry: the callable Component interface with branded ComponentInternals, ComponentProps/MountOptions, the branded Snippet type, EventDispatcher/DispatchOptions, ambient declaration loading, and the re-export of the client API including mount().

Use this node when typing components, snippets, event dispatchers, or mount() options. Branding residuals explain why snippets and internals are nominally unassignable; the trailing re-export exposes index-client.js symbols.

**Depends on.**

- [Reactive Primitives & Motion](r4-reactive-primitives.md) · model-inferred · 0 edge(s)

**Depended on by.**

- [Public Component Types \(Legacy\)](r4-legacy-component-types.md) · model-inferred · 0 edge(s)

Parent: [Svelte Monorepo](r4-svelte-monorepo.md)

## Units (16)

<a id="u-e62b7cb5d771"></a>
### `packages/svelte/src/index.d.ts:Component`

`export interface Component< Props extends Record<string, any> = {}, Exports extends R…` · [packages/svelte/src/index.d.ts:L141-L160][f1]

The Svelte 5 component type: a callable `(internals: ComponentInternals, props: Props) => Exports & {...}`.

The return object optionally carries deprecated `$on`/`$set` methods (legacy compatibility only) merged with the component's `Exports`. Also allows an optional static `element` for custom element builds and a `z_$$bindings` typing-only field marked DO NOT USE. Generic `Bindings` defaults to `string` constrained to `keyof Props | ''`. This interface is the recommended replacement for the deprecated `SvelteComponent` class.

uses: [ComponentInternals](r4-public-component-types.md#u-d797c50f680f); contract: [ComponentProps](r4-public-component-types.md#u-47d3bb8d0c60)

<a id="u-d797c50f680f"></a>
### `ComponentInternals`

`export type ComponentInternals = Branded<{}, 'ComponentInternals'>;` · [packages/svelte/src/index.d.ts:L117-L117][f1]

`Branded<{}, 'ComponentInternals'>` — an opaque, nominally branded empty object type representing internal Svelte component state that varies between environments; users must not construct or modify it.

uses: [index.d.ts module code (L108–L110)](r4-public-component-types.md#u-9d93d41fcbbe), [packages/svelte/src/index.d.ts:Component](r4-public-component-types.md#u-e62b7cb5d771)

<a id="u-47d3bb8d0c60"></a>
### `ComponentProps`

`export type ComponentProps<Comp extends SvelteComponent | Component<any, any>> = Comp…` · [packages/svelte/src/index.d.ts:L234-L239][f1]

Convenience type extracting a component's Props.

Conditional: if `Comp` extends `SvelteComponent<infer Props>` it yields those Props; else if it extends `Component<infer Props, any>` it yields those Props; otherwise `never`. Accepts both legacy class components and new function components, so assigning mismatched props errors at compile time.

<a id="u-91fbf567d3ba"></a>
### `MountOptions`

`export type MountOptions<Props extends Record<string, any> = Record<string, any>> = {…` · [packages/svelte/src/index.d.ts:L318-L353][f1]

Options for `mount()`: required `target` (Document/Element/ShadowRoot); optional `anchor` (render immediately before it), deprecated `events` map (use callback props instead), `context` Map accessible via `getContext()`, and `intro` (default true — whether transitions play on initial render).

Props optionality is conditional: `props` is optional when `{}` extends Props (component takes no required props) and required otherwise.

<a id="u-9a51a53c2a0b"></a>
### `Snippet`

`export interface Snippet<Parameters extends unknown[] = []>` · [packages/svelte/src/index.d.ts:L286-L296][f1]

Type of a `#snippet` block: callable with the declared tuple `Parameters`, returning a branded object keyed by the error string '{@render ...} must be called with a Snippet' so only actual snippets satisfy the type.

The rest-parameter condition `number extends Parameters['length'] ? never : Parameters` allows tuples but rejects unbounded arrays, deliberately refusing rest-parameter-style snippets. Snippets can only be invoked via `{@render ...}`.

<a id="u-84d3f4a85efd"></a>
### `DispatchOptions`

`interface DispatchOptions` · [packages/svelte/src/index.d.ts:L298-L300][f1]

Options for `createEventDispatcher` dispatch: `cancelable?: boolean` marks the dispatched event as cancelable by listeners.

uses: [EventDispatcher](r4-public-component-types.md#u-d891867e583b)

<a id="u-d891867e583b"></a>
### `EventDispatcher`

`export interface EventDispatcher<EventMap extends Record<string, any>>` · [packages/svelte/src/index.d.ts:L302-L313][f1]

Typed event dispatcher interface.

Its call signature is generic over an event name `Type extends keyof EventMap` and shapes the remaining arguments by the event's payload type: when the payload type includes `null` or `undefined` (checked via `null extends` / `undefined extends` for strict and non-strict modes), the `parameter` argument is optional and widened with `| null | undefined` (both become a null detail in the CustomEvent constructor); otherwise `parameter` is required. An optional trailing `options?: DispatchOptions` is always allowed. Returns `boolean` (whether the event was not canceled).

**Notes.**

- contract: EventMap payload types that include null/undefined make the parameter argument optional; all others require it.

**Uncertainties.**

- The boolean return's exact meaning (not canceled) is from convention; this declaration does not state it.

<a id="u-715c9da07a04"></a>
### `Component.$on`

`$on?(type: string, callback: (e: any) => void): () => void` · [packages/svelte/src/index.d.ts:L160-L160][f1]

Optional deprecated `$on(type: string, callback)` on the Component return type, returning an unsubscribe function; exists only for legacy compatibility helpers.

<a id="u-92acbe9e6461"></a>
### `Component.$set`

`$set?(props: Partial<Props>): void` · [packages/svelte/src/index.d.ts:L166-L166][f1]

Optional deprecated `$set(props: Partial<Props>)` on the Component return type; legacy compatibility only.

<a id="u-d5b0cfc16dc3"></a>
### `index.d.ts module code (L1–L10)`

`module_region` · [packages/svelte/src/index.d.ts:L1-L10][f1]

Side-effect import of `./ambient.js` so the rune and `*.svelte` ambient declarations apply whenever the public `svelte` types are used.

No exported behavior of its own.

<a id="u-9d93d41fcbbe"></a>
### `index.d.ts module code (L108–L110)`

`type Brand<B> = { [brand]: B };` · [packages/svelte/src/index.d.ts:L111-L111][f1]

Branding helpers: a module-unique `brand` symbol, `Brand<B>` producing `{ [brand]: B }`, and `Branded<T, B>` = `T & Brand<B>`.

Used to make `ComponentInternals` nominally typed.

<a id="u-a6a6b4a5e402"></a>
### `index.d.ts module code (L112–L116)`

`module_region` · [packages/svelte/src/index.d.ts:L112-L116][f1]

Comment 'Internal implementation details that vary between environments' above ComponentInternals.

<a id="u-49ee0ef8cab0"></a>
### `index.d.ts module code (L117–L140)`

`module_region` · [packages/svelte/src/index.d.ts:L117-L140][f1]

Internal-details comment above `ComponentInternals` and the long doc comment above the `Component` interface, including the npm component-library typing example.

<a id="u-1fc952fe0514"></a>
### `index.d.ts module code (L313–L317)`

`module_region` · [packages/svelte/src/index.d.ts:L313-L317][f1]

Implementation-notes comment and surrounding whitespace between `DispatchOptions` and `MountOptions`; no type content beyond what those interfaces carry.

<a id="u-8fb01ee680e3"></a>
### `index.d.ts module code (L353–L355)`

`module_region` · [packages/svelte/src/index.d.ts:L353-L355][f1]

Trailing re-export `export * from './index-client.js'`, exposing the client-side public API (e.g. `mount`) through the `svelte` entry point.

<a id="u-bdd370666fed"></a>
### `index.d.ts module code (L270–L285)`

`module_region` · [packages/svelte/src/index.d.ts:L270-L285][f1]

Deprecation note, `svelte:component` examples, and the `SnippetReturn` unique-symbol declaration preceding `Snippet` — the brand value that makes snippet call results nominally unassignable.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/index.d.ts
