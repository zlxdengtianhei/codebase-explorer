# Legacy Client Helpers

**Capability.** Compatibility helpers for legacy-mode components on the client.

Reference only when supporting Svelte 4-style semantics; isolated so modern paths need not depend on it.

Parent: [Client Runtime](r4-client-runtime.md)

## Units (1)

<a id="u-dd881b459f6c"></a>
### `misc-js-legacy-helpers`

`export function reactive_import(fn)` · [packages/svelte/src/internal/client/dom/legacy/misc.js:L10-L22][f1]

Legacy compatibility helpers.

`reactive_import(fn)` wraps an import accessor in a `source(0)`: the returned function, called with one argument, increments the source's value and returns that argument (treated as a module update); called with no arguments it reads the source (registering the dependency) and returns `fn()`. `bubble_event($$props, event)` (bound with `this` as the component) looks up `$$props.$$events[event.type]`, normalizes it to a callback array (a copy when already an array, a single-element array for one function, empty for nullish), and calls each with the preserved `this` and the event — so mutations of `$$events` during dispatch do not affect the current dispatch. `add_legacy_event_listener($$props, event_name, callback)` simulates `$on` under `compatibility.componentApi === 4`, lazily creating `$$events` and its per-event array then pushing the callback (mutating `$$props` in place). `update_legacy_props($$new_props)` simulates `$set`: for each key present on `this` it assigns the new value through the instance property, requiring component accessors; it deliberately does not update props held in `$$props` or `$$restProps`.

calls: [source](r3-runtime-reactivity-sources.md#u-97497b70f31b), [packages/svelte/src/internal/client/reactivity/sources.js:set](r3-runtime-reactivity-sources.md#u-452914169f68)

**Uncertainties.**

- The graph shows ambiguous call targets for `push` and iterator `next`; behavior of `$$events[event_name].push` is read as plain Array push.
- Whether `bubble_event`'s `this` is always a component instance is unstated in this file.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/legacy/misc.js
