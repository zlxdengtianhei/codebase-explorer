# Analysis validation core

**Capability.** Owns the shared semantic validation primitives used by every analyze-phase visitor: assignment legality, identifier naming, export and tag constraints, attribute/slot placement, purity checks, and dependency-cycle detection.

Read this subtree to find the single authoritative check for each semantic rule; visitors thin-wrap these helpers. check_graph_for_cycles provides generic graph cycle detection used during analysis. This separation keeps individual visitors small and rules centralized.

**Depended on by.**

- [Analyze-phase AST visitors](r2-analyze-visitors.md) · graph-confirmed · 6 edge(s) · Analysis visitors delegate semantic rules like assignment legality and tag validation to the shared validation core.
- [Semantic Analysis](r3-compiler-analyze.md) · graph-only · 15 edge(s)
- [Analyze Visitors](r5-analyze-visitors.md) · graph-only · 15 edge(s)

Parent: [Component compiler pipeline](r2-compiler.md)

## Units (14)

<a id="u-83497fe81c11"></a>
### `validate_assignment`

`export function validate_assignment(node, argument, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/shared/utils.js:L18-L73][f1]

Central validity check for assignments, updates, and bind: directives.

It first delegates to validate_no_const_assignment (with is_binding true only for BindDirective). For an Identifier target under runes mode: binding to $props.id() raises constant_assignment; each-item bindings raise each_item_invalid_assignment; snippet bindings raise snippet_parameter_assignment (snippet check applies regardless of runes). For a `this.x` MemberExpression target, it resolves the field name (null when computed with a non-Literal property, otherwise get_name of the property) and, if that name is a known class state field whose node is an AssignmentExpression different from the current one, it searches the path backwards for the innermost function; if that function is a constructor MethodDefinition and the current assignment's start precedes the field's declaring assignment, it raises state_field_invalid_assignment — preventing assignment to a state field before its declaration in the constructor.

calls: [validate_no_const_assignment](r2-analyze-shared-validation.md#u-03d1016cde68), [get_name](r4-compiler-model.md#u-99af92983a86), [get_parent](r5-compiler-ast-utils.md#u-427249cf438e)

**Uncertainties.**

- context.state.state_fields is optional and may be undefined; behavior when it exists but the field node is not an AssignmentExpression is to skip the constructor check.

<a id="u-03d1016cde68"></a>
### `validate_no_const_assignment`

`export function validate_no_const_assignment(node, argument, scope, is_binding)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/shared/utils.js:L81-L120][f1]

Rejects writes to immutable names.

It recurses through ArrayPattern elements and ObjectPattern property values, then for each Identifier target looks up the binding: if the declaration kind is 'import', or 'const' with kind not 'each', it throws — constant_binding when the write came from a bind: directive, constant_assignment otherwise, using 'import' or 'constant' as the described thing. Each-kind const bindings are deliberately allowed.

**Uncertainties.**

- A commented-out more precise error path suggests future behavior changes; current messages are the generic constant/import forms.

<a id="u-e442f835d467"></a>
### `validate_identifier_name`

`export function validate_identifier_name(binding, function_depth)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/shared/utils.js:L251-L279][f1]

Enforces dollar-sign naming rules for bindings.

Returns immediately for a null binding. Only non-synthetic, non-parameter bindings at function_depth 0 or 1 (or when depth is undefined) are checked: a name exactly '$' raises dollar_binding_invalid; a name starting with '$' raises dollar_prefix_invalid, except type-only imports whose initial is an ImportDeclaration with importKind 'type' — an exemption kept while the migration script exists. The depth parameter exists for legacy Svelte 4 compatibility that allowed $-prefixed variables below the top level.

**Uncertainties.**

- Behavior at function_depth > 1 is silently permissive by design (legacy compatibility), not an oversight.

<a id="u-1535dc101000"></a>
### `validate_export`

`export function validate_export(node, scope, name)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/shared/utils.js:L287-L298][f1]

Rejects exporting reactive state invariants.

Looks up the name in scope; an unbound name passes. A derived binding raises derived_invalid_export; a state or raw_state binding that has been reassigned raises state_invalid_export. Unreassigned state exports are allowed.

<a id="u-8a95b3b7e6dc"></a>
### `validate_opening_tag`

`export function validate_opening_tag(node, state, expected)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/shared/utils.js:L129-L134][f1]

Checks that a control-flow block's opening `{` is immediately followed by the expected character.

If source[node.start + 1] differs, it raises block_unexpected_character scoped to the first five characters (to limit error span size). In legacy mode whitespace between was tolerated by the parser, per the docstring.

**Uncertainties.**

- Legacy-mode tolerance is handled elsewhere; this function only checks the strict position.

<a id="u-b877c3a87dc5"></a>
### `validate_block_not_empty`

`export function validate_block_not_empty(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/shared/utils.js:L140-L147][f1]

Warns about a control-flow block containing only whitespace.

Returns immediately for a null/undefined fragment. When the fragment has exactly one node that is a Text whose raw content trims to empty, it emits block_empty. A zero-element fragment is treated as in-progress editing and not warned.

<a id="u-ddca3e44b963"></a>
### `ensure_no_module_import_conflict`

`export function ensure_no_module_import_conflict(node, state)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/shared/utils.js:L153-L165][f1]

Prevents an instance-script declaration from shadowing a `<script module>` import.

It extracts all identifiers from the VariableDeclarator's id pattern and, when analyzing the instance script at the instance's root scope, checks each name against the module scope: if found as an import declaration, it raises declaration_duplicate_module_import. All other cases pass silently.

**Uncertainties.**

- Only the exact instance-root-scope case is checked; redeclarations in nested scopes are not caught here.

<a id="u-c8c562a3fb44"></a>
### `is_pure`

`export function is_pure(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/shared/utils.js:L199-L241][f1]

Conservatively decides whether an expression has no side effects.

Literals are pure. CallExpressions are pure only if the callee and every (spread-unwrapped) argument are pure. Any other node type than Identifier or MemberExpression is impure. Identifiers/MemberExpressions referencing the $effect.tracking rune (via get_rune) are impure. Otherwise the leftmost object is found; a bare global identifier (no binding) is assumed pure, and a pure leftmost subexpression makes the whole pure; everything else returns false. A missing leftmost object returns false.

calls: [get_rune](r4-compiler-model.md#u-5204b6ce4f7a)

**Uncertainties.**

- The TODO notes safe Svelte imports are not yet treated as pure; imported identifiers therefore return false unless their base is a global.

<a id="u-63a6d609f552"></a>
### `is_safe_identifier`

`export function is_safe_identifier(expression, scope)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/shared/utils.js:L173-L192][f1]

Determines whether the base of a member/call chain will not invoke functions requiring component context.

It unwraps MemberExpression objects to the root; a non-Identifier root (e.g. a call or literal) is unsafe. An unbound identifier is safe (global). For `$name` store-subscription bindings it recursively checks the underlying name without the '$'. Otherwise safety requires the binding to be none of import, prop, bindable_prop, or rest_prop.

**Uncertainties.**

- Recursion for store subs constructs an Identifier-like object with only name/type; relies on lookup by name only.

<a id="u-001c69caf1f6"></a>
### `validate_attribute`

`export function validate_attribute(attribute, parent)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/shared/attribute.js:L27-L49][f2]

Validates a single attribute's value shape against its parent element.

When the value is exactly one ExpressionTag and the parent is a Component, SvelteComponent, SvelteSelf, or a custom-element RegularElement (checked via is_custom_element_node), it warns attribute_quoted. It then returns early when the value is `true` (boolean shorthand), not an array, or has length 1. Otherwise it compares the last value chunk's end offset with the attribute's own end: if they differ, the value is quoted, and quoting a multi-chunk value raises attribute_unquoted_sequence; if they match, no error.

uses: [is_custom_element_node](r4-compiler-model.md#u-ea1f0b51e1e8)

**Uncertainties.**

- The is_quoted heuristic (last chunk end vs attribute end) is inferred from the comparison; the parser's exact offsets are not visible here.

<a id="u-c4e14f91c1c8"></a>
### `validate_attribute_name`

`export function validate_attribute_name(attribute)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/shared/attribute.js:L12-L21][f2]

Warns when a plain attribute name contains a colon.

If the name includes ':' but does not start with 'xmlns:', 'xlink:', or 'xml:', it emits the attribute_illegal_colon warning; otherwise nothing happens. No error is raised and no state changes.

<a id="u-be5b4cd34d6a"></a>
### `validate_slot_attribute`

`export function validate_slot_attribute(context, attribute, is_component = false)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/shared/attribute.js:L56-L125][f2]

Validates a `slot` attribute's placement and value.

If the immediate grandparent (path.at(-2)) is a SnippetBlock, a non-text attribute raises slot_attribute_invalid and validation stops. Otherwise it walks the whole context.path backwards to find the nearest owning Component, SvelteComponent, SvelteSelf, SvelteElement, or custom-element RegularElement. For a component owner not equal to the direct parent, slot_attribute_invalid_placement is raised unless `is_component` is true; for the direct component owner, a non-text attribute raises slot_attribute_invalid, and the slot name is checked for duplicates in context.state.component_slots (slot_attribute_duplicate) before being added. For name 'default', every non-whitespace-text child of the owner fragment that is not a RegularElement/SvelteFragment carrying its own `slot` attribute raises slot_default_duplicate. With no owner found, slot_attribute_invalid_placement is raised unless `is_component`. Side effect: mutates context.state.component_slots.

**Notes.**

- side_effect: Records the slot name in context.state.component_slots, so duplicate detection is order-dependent across the component's attributes.

uses: [is_custom_element_node](r4-compiler-model.md#u-ea1f0b51e1e8); calls: [is_text_attribute](r5-compiler-ast-utils.md#u-ec400088cae5)

**Uncertainties.**

- The while loop does not break after finding an owner, so it always scans the full path; only the last matched ancestor (deepest, given backwards iteration) can win, and code relies on `!owner` without short-circuiting.

<a id="u-9450956ffc9b"></a>
### `check_graph_for_cycles`

`export default function check_graph_for_cycles(edges)` · [packages/svelte/src/compiler/phases/2-analyze/utils/check_graph_for_cycles.js:L6-L25][f3]

Finds one dependency cycle in an edge list.

It builds an adjacency Map from `[u, v]` pairs (ensuring nodes with only incoming edges also appear as keys), then depth-first searches every node with `visited` and `on_stack` sets. Reaching a node that is on the stack records a cycle `[...on_stack, w]`; the first recorded cycle is returned, otherwise undefined. Nodes are removed from `on_stack` after their subtree finishes.

**Uncertainties.**

- Only the first cycle found is returned; other cycles are collected but discarded
- The cycle contents depend on traversal order and on_stack contents, not a canonical shortest cycle

<a id="u-073bfd65aeb5"></a>
### `visit`

`function visit(v)` · [packages/svelte/src/compiler/phases/2-analyze/utils/check_graph_for_cycles.js:L25-L38][f3]

Recursive DFS helper of check_graph_for_cycles: marks a node visited and on the stack, visits each unvisited neighbor, records `[...on_stack, w]` as a cycle when a neighbor is already on the stack, and removes the node from the stack before returning.

**Uncertainties.**

- No recursion-depth guard; a long chain could overflow the stack for very deep graphs (not proven against actual inputs)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/shared/utils.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/shared/attribute.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/utils/check_graph_for_cycles.js
