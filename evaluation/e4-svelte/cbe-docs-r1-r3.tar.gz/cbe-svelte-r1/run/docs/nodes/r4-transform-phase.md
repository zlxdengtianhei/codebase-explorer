# Transformation

**Capability.** Converts a validated analysis into printed JS (and CSS) output, dispatching to client or server code generation. The entry node picks the mode; client and server children own their respective visitor sets and helpers.

Use transform-entry to see how a compile result is assembled; descend into client-transform or server-transform for the per-node-type codegen rules of each output target.

**Children.**

- [Transform Entry](r4-transform-entry.md) `r4-transform-entry` · 2 unit(s)
- [Client Transform](r4-client-transform.md) `r4-client-transform` · 23 unit(s)
- [Server Transform](r4-server-transform.md) `r4-server-transform` · 11 unit(s)

Parent: [Compiler Pipeline](r4-compiler-pipeline.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
