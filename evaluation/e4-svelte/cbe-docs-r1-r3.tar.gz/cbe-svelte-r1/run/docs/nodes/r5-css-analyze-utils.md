# CSS Analysis Utilities

**Capability.** Reasons about class/style expression values and :global selector scoping (possible-value collection, parent-rule chains, global/unscoped-pseudo classification).

Use to understand which selectors count as global and what class/style expressions could produce; consumed by CSS scoping analysis.

**Depends on.**

- [Shared AST Utilities](r5-compiler-ast-utils.md) · model-inferred · 0 edge(s)

**Depended on by.**

- [CSS Transform](r5-css-transform.md) · model-inferred · 0 edge(s)

Parent: [Analyze Phase](r5-analyze.md)

## Units (6)

<a id="u-b80afad44d7a"></a>
### `gather_possible_values`

`function gather_possible_values(node, is_class, set, is_nested = false)` · [packages/svelte/src/compiler/phases/2-analyze/css/utils.js:L11-L78][f1]

Collects the set of stringifiable values a class/style expression chunk could take, using a sentinel UNKNOWN object that short-circuits further traversal once present.

Literals add their stringified value; ConditionalExpressions union both branches; LogicalExpressions union both sides except `&&`, which models falsiness of the left side: if the left is unknown it adds falsy values `''`, `false`, `NaN`, `0` (skipped for top-level class attributes due to clsx behavior, per the TODO comment), otherwise it adds left values only when falsy and not undefined and not a nested class value; class arrays (`ArrayExpression`) recurse into non-hole elements with `is_nested` true; class object literals add keys for non-computed Identifier/Literal properties and UNKNOWN otherwise. Any other node type adds UNKNOWN, which makes the overall result unknown.

**Notes.**

- side_effect: Pure: populates the passed-in `set`; no external state is touched.

<a id="u-f841f035438b"></a>
### `get_parent_rules`

`export function get_parent_rules(rule)` · [packages/svelte/src/compiler/phases/2-analyze/css/utils.js:L102-L111][f1]

Collects the rule itself and all ancestors via `metadata.parent_rule`, nearest first, with the root rule last.

<a id="u-cb59d8ba04c6"></a>
### `get_possible_values`

`export function get_possible_values(chunk, is_class)` · [packages/svelte/src/compiler/phases/2-analyze/css/utils.js:L85-L96][f1]

Returns the possible string values of an attribute chunk, or null when unknowable.

Text chunks yield their data directly; expression tags are expanded with `gather_possible_values`; if the UNKNOWN sentinel appeared, it returns null, otherwise the set as an array of strings.

<a id="u-022eb67172ae"></a>
### `packages/svelte/src/compiler/phases/2-analyze/css/utils.js:is_global`

`export function is_global(relative_selector)` · [packages/svelte/src/compiler/phases/2-analyze/css/utils.js:L118-L132][f1]

True when a relative selector starts with `:global` and stays global: either the bare `:global` (args null), or `:global(...)` followed only by unscoped pseudo classes or pseudo-element selectors, since e.g. `:global(button).x` is still scoped.

The strictness of the trailing-selector check distinguishes it from `is_outer_global`.

calls: [is_unscoped_pseudo_class](r5-css-analyze-utils.md#u-2d29e82903c1)

<a id="u-a5fd8a871e73"></a>
### `is_outer_global`

`export function is_outer_global(relative_selector)` · [packages/svelte/src/compiler/phases/2-analyze/css/utils.js:L163-L177][f1]

True when a relative selector starts with `:global`, ignoring trailing scoped pseudo classes: either bare `:global`, or `:global(...)` whose remaining selectors are all pseudo classes or pseudo elements.

Unlike `is_global`, `:global(x):has(y)` counts as true here, so this predicate marks selectors global-like regardless of scoping modifiers.

<a id="u-2d29e82903c1"></a>
### `is_unscoped_pseudo_class`

`export function is_unscoped_pseudo_class(selector)` · [packages/svelte/src/compiler/phases/2-analyze/css/utils.js:L138-L155][f1]

True for a pseudo class that cannot force scoping.

Any pseudo class other than `has`/`is`/`where`/`not` qualifies; `not` qualifies when it has no args or every argument complex selector has a single child (multi-selector `:not` would be scoped). Alternatively, `has`/`is`/`where`/`not` selectors are unscoped when they have no args, or when every complex selector in their args consists solely of global relative selectors (checked recursively with `is_global`). Non-pseudo-class selectors return false.

calls: [packages/svelte/src/compiler/phases/2-analyze/css/utils.js:is_global](r5-css-analyze-utils.md#u-022eb67172ae)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/css/utils.js
