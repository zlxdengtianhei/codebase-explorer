# Code Transformation

**Capability.** Shared and target-specific lowering of the analyzed AST into client render code and server (SSR) template code.

Start here when tracing how analysis output becomes generated JS. Shared utilities handle fragments, namespaces, hoisting, and rune lowering; client and server subtrees contain their own visitor sets and element/component builders.

**Children.**

- [Shared Transform Utilities](r3-compiler-transform-utils.md) `r3-compiler-transform-utils` · 7 unit(s)
- [Client Transform](r3-compiler-transform-client.md) `r3-compiler-transform-client` · 19 unit(s)
- [Server Transform \(SSR\)](r3-compiler-transform-server.md) `r3-compiler-transform-server` · 9 unit(s)

**Depends on.**

- [Semantic Analysis](r3-compiler-analyze.md) · model-inferred · 0 edge(s)

Parent: [Svelte Compiler](r3-compiler.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
