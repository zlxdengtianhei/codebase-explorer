# CSS Selector Pruning

**Capability.** Determines which scoped CSS selectors can match template elements, using relative-selector matching, combinator handling, sibling/ancestor possibility analysis with existence certainty, and :global truncation.

Use this to reason about why a selector is kept or removed. prune() marks used selectors; the possibility machinery (siblings, ancestors, block branches) errs toward keeping selectors when existence is only probable.

Parent: [Analysis Phase](r1-analysis.md)

## Units (20)

<a id="u-ff716446121a"></a>
### `css-prune-js-prune`

`export function prune(stylesheet, element)` · [packages/svelte/src/compiler/phases/2-analyze/css/css-prune.js:L86-L88][f1]

Marks CSS selectors as used when they match a given template element.

`prune` walks the stylesheet; for each Rule, if `metadata.is_global_block` it visits only the prelude (skipping rule-body traversal), otherwise recurses normally. For each ComplexSelector it computes relative selectors via `get_relative_selectors`, clears the module-level `seen` snippet set, and if `apply_selector` matches walking BACKWARD sets `node.metadata.used = true`. It deliberately never calls `context.next()` for ComplexSelectors, so nested selectors inside `:is(...)` etc. are not visited here.

calls: [css-prune-js-get-relative-selectors](r1-css-pruning.md#u-d2abf5ff5022), [apply_selector](r1-css-pruning.md#u-ca0893fe0929)

**Uncertainties.**

- Whether `seen` being module-level shared state causes cross-call interference is not guarded in this code beyond `seen.clear()` per ComplexSelector.

<a id="u-d2abf5ff5022"></a>
### `css-prune-js-get-relative-selectors`

`function get_relative_selectors(node)` · [packages/svelte/src/compiler/phases/2-analyze/css/css-prune.js:L125-L135][f1]

Builds the list of relative selectors used for matching: truncates trailing globals via `truncate`, then, if the selector's rule has a parent rule and any selectors remain, ensures an explicit `&` nesting selector is present.

It searches each relative selector (walking pseudo-class arguments) for a NestingSelector; if none exists, it gives the first selector a descendant combinator (if it had none) and unshifts a synthetic `nesting_selector` (`&`), so matching will continue up into the parent rule. Returns the possibly mutated selector array.

calls: [truncate](r1-css-pruning.md#u-2de4cf200800)

<a id="u-0561282c9af0"></a>
### `css-prune-js-relative-selector-might-apply-to-node`

`function relative_selector_might_apply_to_node(relative_selector, rule, element, dire…` · [packages/svelte/src/compiler/phases/2-analyze/css/css-prune.js:L348-L453][f1]

Checks whether an element could satisfy each simple selector of a relative selector.

`:has(...)` selectors are split out first; if present, it determines `include_self` (true when any parent rule's prelude is global, or the last parent rule references `:root` or `:global(...)`), then treats each `:has` argument like an ancestor match: a truncated-to-empty argument counts as matched (marked used); otherwise it tries the selectors including the element itself and a variant prepending a wildcard `any_selector`, marking complex selectors used on match. Any `:has` that matches nothing causes return false. The remaining selectors are checked case by case: `Percentage`/`Nth` skipped; `:host`/`:root` fail; bare `:global` or `:global` without args succeed (with args and as the sole selector it instead matches the inner selector against the element BACKWARD); `:not(...)` contents are marked used and, for multi-child complex selectors, all involved selectors and the whole ancestor chain of the element are marked scoped (a conservative over-approximation); `:is`/`:where(...)` match each truncated argument, treating empty (global) args or multi-child complex selectors as optimistic matches (marking them used/scoped) and returning false only if none matched; pseudo-elements pass; AttributeSelectors pass if whitelisted for `details open`/`dialog open` or `attribute_matches` succeeds; Class/Id selectors test the `class`/`id` attribute with `~=`/`=`; TypeSelectors pass on case-insensitive name equality, `*`, or SvelteElement; NestingSelector matches if any parent-rule complex selector matches via `apply_selector` or is entirely global, else false. Returns true when nothing disproved a match.

calls: [truncate](r1-css-pruning.md#u-2de4cf200800), [apply_selector](r1-css-pruning.md#u-ca0893fe0929), [is_global](r1-css-pruning.md#u-b61f649ec5db), [attribute_matches](r1-css-pruning.md#u-5f19512cd934), [unquote](r1-css-pruning.md#u-18405df1fb04), [get_element_parent](r1-css-pruning.md#u-16466c9d33bc), [css-prune-js-get-relative-selectors](r1-css-pruning.md#u-d2abf5ff5022), [get_parent_rules](r5-css-analyze-utils.md#u-f841f035438b)

**Uncertainties.**

- The `include_self` second clause indexes `rules[rules.length - 1]`; behavior when `rules` is empty cannot be verified from this file.

<a id="u-728c789653e3"></a>
### `css-prune-js-get-descendant-elements`

`function get_descendant_elements(node, adjacent_only, seen = new Set())` · [packages/svelte/src/compiler/phases/2-analyze/css/css-prune.js:L788-L795][f1]

Collects descendant RegularElement/SvelteElement nodes of a node.

It walks the node's fragment (or the RenderTag node itself) with zimmerframe; each element found is collected, and recursed into only when not `adjacent_only`. RenderTags encountered cause recursion into the bodies of their snippets, tracked in `seen` to prevent loops. Returns the collected element list.

uses: [css-prune-js-get-descendant-elements](r1-css-pruning.md#u-728c789653e3)

<a id="u-ca0893fe0929"></a>
### `apply_selector`

`function apply_selector(relative_selectors, rule, element, direction)` · [packages/svelte/src/compiler/phases/2-analyze/css/css-prune.js:L195-L213][f1]

Matches one relative selector against an element and recurses through the remaining selectors.

Depending on `direction` it takes the first (FORWARD) or last (BACKWARD) selector; the match succeeds only if the selector might apply to the node (`relative_selector_might_apply_to_node`) and the combinator chain matches (`apply_combinator`). On a match it side-effects: the selector is marked `scoped = true` unless it is an outer global, and `element.metadata.scoped = true`. Returns the boolean match result.

calls: [css-prune-js-relative-selector-might-apply-to-node](r1-css-pruning.md#u-0561282c9af0), [apply_combinator](r1-css-pruning.md#u-0baa697559cd), [is_outer_global](r5-css-analyze-utils.md#u-a5fd8a871e73)

**Uncertainties.**

- `is_outer_global` on an empty-selector relative selector would access `selectors[0]`; whether empty selectors reach this path is not visible here.

<a id="u-0baa697559cd"></a>
### `apply_combinator`

`function apply_combinator(relative_selector, rest_selectors, rule, node, direction)` · [packages/svelte/src/compiler/phases/2-analyze/css/css-prune.js:L223-L285][f1]

Checks that the combinator connecting the current selector to the rest of the chain matches for the given element.

Without a combinator it trivially succeeds. For ` ` and `>` it enumerates descendants (FORWARD) or ancestors (BACKWARD, restricted to the immediate parent for `>`) and succeeds if applying the remaining selectors to any of them matches; in BACKWARD mode it also succeeds when the remaining selectors are all global and either the combinator is descendant or no ancestors exist. For `+` and `~` it enumerates possible siblings (immediate for `+`); RenderTag/SlotElement/Component siblings match only when a single remaining global selector remains, other siblings are matched via `apply_selector`; it also succeeds in BACKWARD mode when the node has no element parent and all remaining selectors are global. Any other combinator returns true (unimplemented).

calls: [apply_selector](r1-css-pruning.md#u-ca0893fe0929), [css-prune-js-get-descendant-elements](r1-css-pruning.md#u-728c789653e3), [get_ancestor_elements](r1-css-pruning.md#u-f22cb866ff97), [get_possible_element_siblings](r1-css-pruning.md#u-8bc72661b27e), [get_element_parent](r1-css-pruning.md#u-16466c9d33bc), [is_global](r1-css-pruning.md#u-b61f649ec5db)

<a id="u-b61f649ec5db"></a>
### `is_global`

`function is_global(selector, rule)` · [packages/svelte/src/compiler/phases/2-analyze/css/css-prune.js:L296-L335][f1]

Recursively decides whether a relative selector is effectively global: immediately true if `is_global`/`is_global_like` metadata is set.

Otherwise each simple selector must not block globality: `:is`/`:where` with args contribute a selector list checked recursively (every relative selector inside must be global, evaluated against the owning rule, which for NestingSelector is the parent rule); other pseudo classes can stay global only if `is_unscoped_pseudo_class` says so. If any selector is neither globally- nor can-be-global, the result is false. Otherwise true if some selector carried global contents, or the selector list is empty.

calls: [is_unscoped_pseudo_class](r5-css-analyze-utils.md#u-2d29e82903c1), [is_global](r1-css-pruning.md#u-b61f649ec5db)

**Uncertainties.**

- For NestingSelector the code casts `rule.metadata.parent_rule` to a Rule without a null check; behavior when there is no parent rule is undefined here.

<a id="u-2de4cf200800"></a>
### `truncate`

`function truncate(node)` · [packages/svelte/src/compiler/phases/2-analyze/css/css-prune.js:L163-L186][f1]

Discards trailing relative selectors that are global and therefore irrelevant to scoping.

It finds the last index whose selector is neither `:global` (bare `global` pseudo without args), nor `is_global_like`, nor `is_global`, then slices children up to and including it. Additionally, for a kept selector containing a `:root` pseudo-class that is not global-like (e.g. `:root.y:has(...)`), it replaces the selector with a copy keeping only `:has(...)` pseudo-class selectors, so everything except `:has` in such a selector is treated as unscoped.

uses: [is_global](r1-css-pruning.md#u-b61f649ec5db)

<a id="u-5f19512cd934"></a>
### `attribute_matches`

`function attribute_matches(node, name, expected_value, operator, case_insensitive)` · [packages/svelte/src/compiler/phases/2-analyze/css/css-prune.js:L626-L735][f1]

Decides whether an element's attributes could produce a value matching an attribute/class/id selector, erring toward a match when values are dynamic.

It scans element attributes: a SpreadAttribute or a BindDirective with the same name always matches; a StyleDirective matches any `style` selector; a ClassDirective matches any `class` selector, with `~=` additionally requiring the directive name to equal the expected value. Plain Attributes are checked only when names match case-insensitively: a boolean-valued attribute matches only with a null operator, and a null expected value always matches. Static text attributes are tested via `test_attribute`, except that a failed match on `class`/`style` continues scanning for a later directive. Dynamic values are expanded with `get_possible_values` per chunk: if any chunk's values are unknown it returns true; combinations across chunks are built incrementally, folding whitespace-leading values and capping `prev_values` at 20 entries (returning true beyond that to avoid exponential growth); any produced possible value satisfying `test_attribute` yields a match. If no attribute matches, returns false.

**Notes.**

- contract: Returns true conservatively for spreads, binds, unknown dynamic values, and overly large value combinations.

calls: [test_attribute](r1-css-pruning.md#u-5aa194851017), [get_possible_values](r5-css-analyze-utils.md#u-cb59d8ba04c6)

<a id="u-5aa194851017"></a>
### `test_attribute`

`function test_attribute(operator, expected_value, case_insensitive, value)` · [packages/svelte/src/compiler/phases/2-analyze/css/css-prune.js:L596-L617][f1]

Compares one concrete attribute value against the expected CSS value with the given attribute operator.

If case-insensitive, both strings are lowercased first. Supported operators: `=` equality, `~=` whitespace-word membership, `|=` prefix followed by `-`, `^=` prefix, `$=` suffix, `*=` substring. Any other operator throws `new Error("this shouldn't happen")`.

**Notes.**

- failure: An unrecognized operator raises an Error rather than returning a boolean.

<a id="u-18405df1fb04"></a>
### `unquote`

`function unquote(str)` · [packages/svelte/src/compiler/phases/2-analyze/css/css-prune.js:L738-L743][f1]

Strips a single leading and trailing quote character.

It slices off the first/last character when the string starts and ends with `'`, or when it starts with `"` (the closing check is only `str[0] === "'"` paired equality or the leading double-quote test); otherwise returns the string unchanged.

**Uncertainties.**

- A double-quoted string's closing quote is not verified to match, so `"abc'` would be sliced.

<a id="u-16466c9d33bc"></a>
### `get_element_parent`

`function get_element_parent(node)` · [packages/svelte/src/compiler/phases/2-analyze/css/css-prune.js:L827-L840][f1]

Returns the nearest RegularElement or SvelteElement in the node's metadata path, scanning from the end of the path toward the root, or null when no element ancestor exists.

<a id="u-f22cb866ff97"></a>
### `get_ancestor_elements`

`function get_ancestor_elements(node, adjacent_only, seen = new Set())` · [packages/svelte/src/compiler/phases/2-analyze/css/css-prune.js:L750-L781][f1]

Collects the element ancestors of a node by walking its metadata path from nearest to farthest, returning RegularElement/SvelteElement parents.

With `adjacent_only` it stops at the first element ancestor. If a SnippetBlock parent is met, it recurses into each render site of the snippet (guarded by the `seen` set to avoid infinite recursion) and then stops traversing this path.

calls: [get_ancestor_elements](r1-css-pruning.md#u-f22cb866ff97)

<a id="u-8bc72661b27e"></a>
### `get_possible_element_siblings`

`function get_possible_element_siblings(node, direction, adjacent_only, seen = new Set())` · [packages/svelte/src/compiler/phases/2-analyze/css/css-prune.js:L849-L941][f1]

Computes which elements could be siblings of a node in the given direction, with an existence certainty per node.

It walks up the metadata path: at each enclosing fragment it scans siblings in direction (FORWARD next, BACKWARD previous). RegularElements without a `slot` attribute are definite matches (early return when adjacent_only); SlotElement and Component contribute probably-existing entries plus their nested-sibling possibilities; other blocks likewise via `get_possible_nested_siblings`, with early return only when a non-Component block yields a definite element; SvelteElement and RenderTag entries are probable, with RenderTag snippets also expanded. Moving up the path: Component/SvelteComponent/SvelteSelf ancestors are skipped, SnippetBlock ancestors recurse into their render sites (loop-guarded, early return when a single site has definite elements), traversal stops at non-block ancestors, and an EachBlock whose body is the current fragment additionally merges the block's nested siblings. Entries map node to NODE_DEFINITELY_EXISTS or NODE_PROBABLY_EXISTS.

calls: [get_possible_nested_siblings](r1-css-pruning.md#u-776b8802874e), [has_definite_elements](r1-css-pruning.md#u-41937f37bf51), [add_to_map](r1-css-pruning.md#u-6a4f9f3a80c1), [is_block](r1-css-pruning.md#u-a2e749949279)

<a id="u-776b8802874e"></a>
### `get_possible_nested_siblings`

`function get_possible_nested_siblings(node, direction, adjacent_only, seen = new Set())` · [packages/svelte/src/compiler/phases/2-analyze/css/css-prune.js:L950-L1009][f1]

Gathers possible element siblings from inside a block-like node by inspecting its branch fragments: EachBlock body+fallback, IfBlock consequent+alternate, AwaitBlock pending/then/catch, KeyBlock/SlotElement single fragment, SnippetBlock body (loop-guarded via `seen`, returning an empty map for repeats), and Component fragment plus snippet bodies.

`exhaustive` starts true except for SlotElement/SnippetBlock, and is cleared per missing fragment and ANDed with whether each fragment produced a definite element. Any non-exhaustive result downgrades every entry to NODE_PROBABLY_EXISTS.

calls: [loop_child](r1-css-pruning.md#u-0a565ad64fac), [has_definite_elements](r1-css-pruning.md#u-41937f37bf51), [add_to_map](r1-css-pruning.md#u-6a4f9f3a80c1)

<a id="u-0a565ad64fac"></a>
### `loop_child`

`function loop_child(children, direction, adjacent_only, seen)` · [packages/svelte/src/compiler/phases/2-analyze/css/css-prune.js:L1054-L1086][f1]

Scans a fragment's children in the given direction collecting possible elements.

RegularElements are definite (breaking immediately when adjacent_only); SvelteElements are probable; RenderTags merge the nested siblings of each of their snippets; blocks merge `get_possible_nested_siblings` results, breaking early when adjacent_only and the block yielded a definite element. Returns the resulting node-to-existence map.

calls: [get_possible_nested_siblings](r1-css-pruning.md#u-776b8802874e), [add_to_map](r1-css-pruning.md#u-6a4f9f3a80c1), [is_block](r1-css-pruning.md#u-a2e749949279)

<a id="u-6a4f9f3a80c1"></a>
### `add_to_map`

`function add_to_map(from, to)` · [packages/svelte/src/compiler/phases/2-analyze/css/css-prune.js:L1032-L1036][f1]

Merges entries of one existence map into another, keeping the higher existence value per node via `higher_existence`, so definite entries never get downgraded by probable ones.

calls: [higher_existence](r1-css-pruning.md#u-7ab616fd59eb)

<a id="u-7ab616fd59eb"></a>
### `higher_existence`

`function higher_existence(exist1, exist2)` · [packages/svelte/src/compiler/phases/2-analyze/css/css-prune.js:L1043-L1046][f1]

Returns the first existence value when the second is undefined; otherwise returns the numerically larger of the two, so DEFINITELY (1) wins over PROBABLY (0).

<a id="u-41937f37bf51"></a>
### `has_definite_elements`

`function has_definite_elements(result)` · [packages/svelte/src/compiler/phases/2-analyze/css/css-prune.js:L1015-L1023][f1]

Returns true only when the map is non-empty and contains at least one NODE_DEFINITELY_EXISTS value; an empty map or all-probable entries yield false.

<a id="u-a2e749949279"></a>
### `is_block`

`function is_block(node)` · [packages/svelte/src/compiler/phases/2-analyze/css/css-prune.js:L1092-L1100][f1]

Type predicate: true for IfBlock, EachBlock, AwaitBlock, KeyBlock, or SlotElement nodes.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/css/css-prune.js
