# Server Rendering

**Capability.** Public server entry re-exporting render, with its TypeScript declaration, for rendering components to strings/streams.

The svelte/server surface; the code-generation side lives in the server transform, whose relation to this entry is not resolved in the given graph.

**Depended on by.**

- [SSR Playground Sandbox](r5-playground-sandbox.md) · model-inferred · 0 edge(s)

Parent: [Svelte](r5-svelte.md)

## Units (2)

<a id="u-c0e8025865b5"></a>
### `index-js-server`

`group` · [packages/svelte/src/server/index.js:L1-L1][f1]

Public server entry point that re-exports render from the internal server implementation.

Contains no logic; all SSR behavior lives in the re-exported module.

<a id="u-d452e617d953"></a>
### `packages/svelte/src/server/index.d.ts:render`

`export function render< Comp extends SvelteComponent<any> | Component<any>, Props ext…` · [packages/svelte/src/server/index.d.ts:L8-L29][f2]

TypeScript declaration for server-side rendering.

render takes a component (class constructor when the component extends SvelteComponent, otherwise a Component) and an options object; it returns RenderOutput with body and head strings for populating server-rendered HTML. Options include props (with $$slots and $$events omitted), an optional context Map, and an optional idPrefix. The overloads encode a requirement: when Props is not the empty type {}, the options argument including props is mandatory; when Props is empty, the whole options object is optional. Doc comment states this is only available on the server when compiling with the server option; no runtime behavior is declared here.

**Uncertainties.**

- Runtime semantics (e.g., how idPrefix affects generated ids) live in the implementation module, not supplied.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/server/index.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/server/index.d.ts
