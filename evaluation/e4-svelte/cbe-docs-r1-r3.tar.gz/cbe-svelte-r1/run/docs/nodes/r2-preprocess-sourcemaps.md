# Preprocessing and sourcemap composition

**Capability.** Owns running user preprocessor groups over source text and preserving accurate position mappings: MappedCode concatenation, decoded-map handling, offset shifting, and composition of preprocessor maps with the compiler map.

Enter here to understand how script/style preprocessors rewrite a file while sourcemaps stay correct. preprocess orchestrates tag/markup processors into a Processed result; mapped_code supplies the mapping math. decode_sourcemap normalizes maps coming out of preprocessors.

**Depends on.**

- [Compiler option validation](r2-compiler-options.md) · model-inferred · 0 edge(s)

Parent: [Component compiler pipeline](r2-compiler.md)

## Units (25)

<a id="u-c6f821c0ed6a"></a>
### `decode_map`

`export function decode_map(processed)` · [packages/svelte/src/compiler/preprocess/decode_sourcemap.js:L86-L96][f1]

Normalizes the map field of a Processed result into a decoded sourcemap.

A string map is JSON.parse'd; string mappings are decoded via @jridgewell/sourcemap-codec. If the object exposes _mappings and its constructor.name is 'SourceMapGenerator', decoded_sourcemap_from_generator converts it. The object is mutated in place and returned; other shapes pass through unchanged.

calls: [decoded_sourcemap_from_generator](r2-preprocess-sourcemaps.md#u-032387dae287)

**Uncertainties.**

- JSON.parse errors on malformed map strings propagate; no fallback exists here

<a id="u-032387dae287"></a>
### `decoded_sourcemap_from_generator`

`function decoded_sourcemap_from_generator(generator)` · [packages/svelte/src/compiler/preprocess/decode_sourcemap.js:L11-L81][f1]

Converts a hidden-property SourceMapGenerator instance into a plain decoded sourcemap object.

It builds value-to-index lookups from generator._sources and generator._names, then walks generator._mappings: when a mapping's generatedLine exceeds the previous line, empty lines are pushed until converted_mappings matches (lines are one-based, so index is line-1); otherwise, for i > 0, mappings identical to the previous one across generatedColumn, originalColumn, name, generatedLine, originalLine and source are skipped. Each kept segment starts as [generatedColumn]; if source != null the source index, originalLine - 1 and originalColumn are appended, and if name != null also the name index. The returned map carries _version, sources, names and converted mappings, copying _file only when non-null; sourcesContent and sourceRoot are intentionally dropped.

calls: [decode_map](r2-preprocess-sourcemaps.md#u-c6f821c0ed6a)

**Uncertainties.**

- Relies on undocumented _sources/_names/_mappings internal shapes; deviations break the conversion and are not verifiable here

<a id="u-d0cf287ba25e"></a>
### `PreprocessResult`

`class PreprocessResult` · [packages/svelte/src/compiler/preprocess/index.js:L19-L56][f2]

Accumulates intermediate preprocessing state and produces the final Processed result.

The constructor stores source and filename, runs update_source with the initial string, and sets file_basename to get_basename(filename), or null when no filename is given, so sourcemap sources stay relative to the file itself. update_source applies a SourceUpdate: a non-null string replaces this.source and rebuilds get_location via locate-character's getLocator; a map is unshifted onto sourcemap_list, keeping maps in reverse order (last transformation first) for later remapping; dependencies are appended. to_processed combines the whole list with combine_sourcemaps(file_basename, sourcemap_list) and returns code, dependencies deduplicated through a Set, the combined map, and a toString returning the current source.

uses: [process_tag](r2-preprocess-sourcemaps.md#u-bfe65eceb1e6)

**Uncertainties.**

- combine_sourcemaps behavior with an empty sourcemap_list or null file_basename is not visible here; @ts-expect-error comments hint at possible bugs

<a id="u-fb2fa12e3a03"></a>
### `parse_tag_attributes`

`function parse_tag_attributes(str)` · [packages/svelte/src/compiler/preprocess/index.js:L223-L236][f2]

Parses an attribute string like lang="sass" into a record.

It repeatedly applies a module-level global regex capturing an attribute name plus optionally one of three value forms (double-quoted, single-quoted, or unquoted non-space run); a name without a captured value maps to true, otherwise to the first non-empty captured value. Later occurrences of the same name overwrite earlier values. Because the regex is shared module state with the /g flag, this function is not reentrant across concurrent iteration, though its single-threaded use here is safe.

**Uncertainties.**

- The shared global regex state would break if invocations interleaved, e.g. in async callbacks; not exercised in this file

<a id="u-049035fc1450"></a>
### `preprocess`

`export default async function preprocess(source, preprocessor, options)` · [packages/svelte/src/compiler/preprocess/index.js:L338-L368][f2]

Entry point that runs a preprocessor group or list over source text and returns the combined Processed result.

The filename comes from options.filename, or from a legacy preprocessor.filename property when the second argument is a bare function. A single group is wrapped into a one-element list; no preprocessor yields an empty list. After building a PreprocessResult, each group is applied in order — markup first, then script tags, then style tags — with each step's SourceUpdate folded into the result via update_source, so later transforms see earlier output. Finally to_processed combines all collected sourcemaps and returns code, deduplicated dependencies, the combined map and a toString.

uses: [PreprocessResult](r2-preprocess-sourcemaps.md#u-d0cf287ba25e); calls: [process_markup](r2-preprocess-sourcemaps.md#u-4ab1a1bb5a53), [process_tag](r2-preprocess-sourcemaps.md#u-bfe65eceb1e6)

**Uncertainties.**

- Errors thrown by user preprocessors are not caught here and propagate to the caller

<a id="u-4ab1a1bb5a53"></a>
### `process_markup`

`async function process_markup(process, source)` · [packages/svelte/src/compiler/preprocess/index.js:L308-L327][f2]

Applies a markup preprocessor to the whole file.

It calls the preprocessor with content and filename; a falsy result yields an empty object, meaning no update. A truthy result yields the processed code, the map JSON.parse'd when it is a string and passed through otherwise (undefined when absent), and the dependencies. Parsing errors on a malformed JSON map string propagate to the caller.

**Uncertainties.**

- Unlike decode_map, SourceMapGenerator-shaped maps are not converted here, as the TODO comment acknowledges; the consequences are handled elsewhere

<a id="u-bfe65eceb1e6"></a>
### `process_tag`

`async function process_tag(tag_name, preprocessor, source)` · [packages/svelte/src/compiler/preprocess/index.js:L265-L279][f2]

Runs a script/style Preprocessor over every matching tag in the markup and returns a SourceUpdate.

It selects regex_style_tags or regex_script_tags by tag name and collects dependencies across all tag invocations. The inner process_single_tag: with neither attributes nor content, or a falsy preprocessor result, or a result with no map whose code equals the original content, it returns no_change — the original source slice mapped via slice_source and MappedCode.from_source, so positions are preserved. Otherwise it parses the original attributes for the preprocessor call, appends processed.dependencies, and calls processed_tag_to_code with the processed result, original attributes, and stringify_tag_attributes(processed.attributes) falling back to the original attributes when the preprocessor did not return new ones. replace_in_code applies this over the regex; the final string, map and accumulated dependencies form the returned update.

calls: [replace_in_code](r3-compiler-diagnostics.md#u-8eab9628969e), [packages/svelte/src/compiler/preprocess/index.js:processed_tag_to_code](r2-preprocess-sourcemaps.md#u-92dd345d2916)

**Uncertainties.**

- The tag regexes skip HTML comments via their leading <!--...--> alternative; how replacement of comments interacts with offsets depends on String.replace semantics not shown here

<a id="u-f5d36b72e8e4"></a>
### `processed_content_to_code`

`function processed_content_to_code(processed, location, file_basename)` · [packages/svelte/src/compiler/preprocess/index.js:L107-L126][f2]

Turns preprocessed tag content plus its sourcemap into a MappedCode anchored at the content's location in the original file.

If processed.map exists it is decoded with decode_map; when the decoded map has a sources array, file_basename is searched in it and only when found (index !== -1) does sourcemap_add_offset shift that source's segments by the given line/column location — maps without sources, e.g. { mappings: '' }, are left unoffset. MappedCode.from_processed then builds the replacement from processed.code and the possibly undefined decoded map.

calls: [decode_map](r2-preprocess-sourcemaps.md#u-c6f821c0ed6a), [sourcemap_add_offset](r2-preprocess-sourcemaps.md#u-6ba9b18d03ed), [MappedCode.from_processed](r2-preprocess-sourcemaps.md#u-55e9f4707897)

<a id="u-92dd345d2916"></a>
### `packages/svelte/src/compiler/preprocess/index.js:processed_tag_to_code`

`function processed_tag_to_code( processed, tag_name, original_attributes, generated_a…` · [packages/svelte/src/compiler/preprocess/index.js:L151-L216][f2]

Builds the MappedCode replacing a whole <style>/<script> tag (open tag, content, close tag) with its processed version.

The build_mapped_code helper maps an unchanged code slice starting at an offset through slice_source and MappedCode.from_source. Two open-tag cases: if the original and generated open tags differ in length (attributes were rewritten), a hand-built version-3 decoded map encodes the tag start (segment [0,0,0,0]) and end of tag start, padded with extra rows while mappings.length <= line for multi-line tags, then the end-of-tag segment; the map is offset to the tag's location with sourcemap_add_offset and wrapped via MappedCode.from_processed. If the lengths match, the original slice is reused via build_mapped_code at offset 0. The close tag is always sliced at original_tag_open.length + source.source.length. parse_attached_sourcemap normalizes processed's attached map, processed_content_to_code maps the content at the offset after the original open tag, and the three pieces are concatenated in order.

calls: [processed_content_to_code](r2-preprocess-sourcemaps.md#u-f5d36b72e8e4), [mapped-code-parse-attached-sourcemap](r2-preprocess-sourcemaps.md#u-ee2f9d311ee5), [slice_source](r3-compiler-diagnostics.md#u-b98556db32bb)

**Uncertainties.**

- parse_attached_sourcemap's failure behavior on malformed maps lives in mapped_code.js and is not verifiable here

<a id="u-348e22d5d13f"></a>
### `stringify_tag_attributes`

`function stringify_tag_attributes(attributes)` · [packages/svelte/src/compiler/preprocess/index.js:L241-L251][f2]

Serializes an attributes record back into a tag-attribute string.

Returns undefined for no attributes, so callers can fall back to the original attributes. Entries with value true render as the bare key; all other values render as key="value" without escaping. Joined entries are prefixed with a single space; an empty record yields an empty string (falsy), which is returned unmodified rather than space-prefixed.

<a id="u-ee2f9d311ee5"></a>
### `mapped-code-parse-attached-sourcemap`

`function log_warning(message)` · [packages/svelte/src/compiler/utils/mapped_code.js:L351-L357][f3]

Extracts a base64 data-URI sourcemap attached as a trailing `sourceMappingURL` comment from preprocessed code and moves it into `processed.map`.

The regex differs by tag: for scripts both `//` and `/* */` forms match at end of string; for styles only `/* */`. Inside the replace callback, the data URI is matched with `regex_data_uri`. If map data exists and `processed.map` is already set, it warns about two maps and keeps only the existing one; otherwise it base64-decodes the data into `processed.map`. If the URL is a path rather than a data URI, it warns when no `processed.map` exists, and always removes the comment. All branches remove the matched comment from `processed.code`. The helper `log_warning` prints a console warning prefixed with a code preview truncated at 100 characters to help locate the offending preprocessor.

uses: [mapped_code.js module code (L387–L393)][f3]

**Uncertainties.**

- b64dec and console are environment-dependent; b64dec resolves to atob or a Buffer-based fallback, and the warning path requires console to exist.
- The graph shows a call to Parser.match from this function that is not visible in the supplied source; its effect is unknown here.

<a id="u-3b244745bdc8"></a>
### `MappedCode`

`class MappedCode` · [packages/svelte/src/compiler/utils/mapped_code.js:L75-L90][f3]

Wraps a generated code string together with its decoded sourcemap so pieces of code can be concatenated while keeping mappings consistent.

Instances hold `string` and `map`; a missing map yields an empty version-3 map with no sources, names, or mappings. Static factories build instances from pre-mapped code (`from_processed`) or from raw source (`from_source`), and `concat` merges another instance into this one in place. Used by the preprocessor pipeline to thread mappings through code replacements.

<a id="u-389a85833371"></a>
### `apply_preprocessor_sourcemap`

`function apply_preprocessor_sourcemap(filename, svelte_map, preprocessor_map_input)` · [packages/svelte/src/compiler/utils/mapped_code.js:L308-L332][f3]

Composes the Svelte sourcemap with a preprocessor sourcemap and attaches `toString`/`toUrl` conveniences expected by Svelte's output.

Returns the original `svelte_map` unchanged when either it or the preprocessor map input is falsy. The preprocessor map may be a JSON string (parsed via JSON.parse, whose errors propagate) or an already-parsed map. It delegates composition to combine_sourcemaps, then defines non-enumerable `toString` (JSON.stringify of the map) and `toUrl` (base64 data URI) properties on the result before returning it.

calls: [combine_sourcemaps](r2-preprocess-sourcemaps.md#u-6270a2fbedb9)

<a id="u-6270a2fbedb9"></a>
### `combine_sourcemaps`

`export function combine_sourcemaps(filename, sourcemap_list)` · [packages/svelte/src/compiler/utils/mapped_code.js:L265-L300][f3]

Composes an ordered list of sourcemaps (newest first) into one map using the `@jridgewell/remapping` library, returning null for an empty list.

If every map except the last has exactly one source, it uses remapping's array interface; otherwise it uses the loader interface, supplying the next map in the list as the child map only when the source name equals the given `filename` basename, and null otherwise (leaf node). The loader's filename equality is a known brittle assumption, noted in a TODO comment. It skips `sourcesContent`, deletes an unset optional `file` field, and when the combined result has empty `sources`, substitutes `[filename]`.

**Notes.**

- condition: Choice between remapping interfaces depends solely on whether any non-last map has `sources.length !== 1`.

**Uncertainties.**

- Whether the array vs loader branch produces different source-name behavior for multi-source maps cannot be verified from this file alone.

<a id="u-10b75c582411"></a>
### `get_basename`

`export function get_basename(filename)` · [packages/svelte/src/compiler/utils/mapped_code.js:L443-L445][f3]

Returns the last segment of a filename after splitting on `/` or `\`, like Node's basename but browser-safe.

<a id="u-a263794e6dc6"></a>
### `get_relative_path`

`function get_relative_path(from, to)` · [packages/svelte/src/compiler/utils/mapped_code.js:L423-L437][f3]

Computes a slash-joined relative path from `from` to `to` without Node utilities, so the compiler stays browser-usable.

Both paths are split on `/` or `\`; the `from` dirname is taken by popping its last part. Leading parts equal in both paths are dropped. Remaining `from` parts are each replaced with `..`; the result is those `..` entries (if any) followed by the remaining `to` parts, joined with `/`.

**Uncertainties.**

- When `from_parts` becomes empty after shifting, the loop exits with no `..` prefix, yielding a same-directory or downward-relative path.

<a id="u-61dfd78a863b"></a>
### `get_source_name`

`export function get_source_name(filename, output_filename, fallback)` · [packages/svelte/src/compiler/utils/mapped_code.js:L452-L454][f3]

Chooses the name to record for the input source file in a sourcemap.

If an `output_filename` is given, returns the path of `filename` relative to that output location; otherwise returns the basename of `filename`.

calls: [get_relative_path](r2-preprocess-sourcemaps.md#u-a263794e6dc6), [get_basename](r2-preprocess-sourcemaps.md#u-10b75c582411)

<a id="u-e8017193524a"></a>
### `last_line_length`

`function last_line_length(s)` · [packages/svelte/src/compiler/utils/mapped_code.js:L12-L14][f3]

Returns the length of the text after the last newline in a string, i.e. the length of its final line.

For a string with no newline this equals the whole string length.

<a id="u-a97c97e7b9a7"></a>
### `merge_tables`

`function merge_tables(this_table, other_table)` · [packages/svelte/src/compiler/utils/mapped_code.js:L48-L72][f3]

Merges a second table into a copy of the first, producing the union plus an index remap for the second table.

Starts with `new_table = this_table.slice()`. For each entry of `other_table` (treated as empty if falsy): if the value already exists in `this_table`, its existing index is recorded in the map; otherwise it is appended to `new_table`, its new index recorded, and `val_changed` set true. `idx_changed` starts equal to `val_changed`, but is reset to false when the index map turned out to be the identity sequence [0,1,2,...] despite values having changed. Returns the union table, the index map, and both flags.

**Uncertainties.**

- Uniqueness is resolved with `indexOf`, so duplicate values across tables share one entry; the O(n²) lookup is unguarded.

<a id="u-58c664c9f3e7"></a>
### `merge_with_preprocessor_map`

`export function merge_with_preprocessor_map(result, options, source_name)` · [packages/svelte/src/compiler/utils/mapped_code.js:L394-L417][f3]

Merges a preprocessor's sourcemap from compile options into the component's result map.

It does nothing unless `options.sourcemap` is set. Then it computes the basename of `options.filename`, rewrites `result.map.sources` to that single basename so both maps agree on source naming, and calls apply_preprocessor_sourcemap, Object.assigning the composed map back onto `result.map`. Finally, if the basename differs from `source_name`, it rewrites each source entry to be relative to `source_name` via get_relative_path, in case output lives in a different directory.

calls: [apply_preprocessor_sourcemap](r2-preprocess-sourcemaps.md#u-389a85833371), [get_basename](r2-preprocess-sourcemaps.md#u-10b75c582411), [get_relative_path](r2-preprocess-sourcemaps.md#u-a263794e6dc6)

**Uncertainties.**

- options.sourcemap is cast to any and may be a string or map object; parsing behavior is defined by apply_preprocessor_sourcemap.

<a id="u-6ba9b18d03ed"></a>
### `sourcemap_add_offset`

`export function sourcemap_add_offset(map, offset, source_index)` · [packages/svelte/src/compiler/utils/mapped_code.js:L22-L40][f3]

Shifts a decoded sourcemap's mappings in place so they account for a line/column offset in the original source.

Returns immediately if `map.mappings` is empty. For every segment whose source index (seg[1]) equals `source_index`, it adds `offset.line` to the source line (seg[2]); if that source line is 0, it additionally adds `offset.column` to the source column (seg[3]). Segments belonging to other sources are untouched; segments are shifted, never reordered, and nothing is returned.

**Notes.**

- side_effect: Mutates the passed map's mappings arrays in place.

**Uncertainties.**

- Shifting seg[3] assumes matching segments have at least 4 entries; the code notes this in a comment but does not assert it.

<a id="u-1bc94121324a"></a>
### `MappedCode.concat`

`concat(other)` · [packages/svelte/src/compiler/utils/mapped_code.js:L109-L184][f3]

Appends another MappedCode's string and mappings onto this instance in place and returns `this` for chaining; the other instance's map is mutated too.

Short-circuits: if `other.string` is empty it returns `this` unchanged; if `this.string` is empty it adopts the other's string and map. Otherwise it records the current last-line length as a column offset before appending. If the other map has no mappings, only the string concatenation happens. Next it merges the other's sources and names tables; per segment, source (seg[1]) and name (seg[4]) indices are remapped only when the corresponding index map is non-identity, choosing among three loop variants for speed. Finally, if the joined strings share a line, every segment of the other map's first line gets the column offset added; that first line is then moved onto this map's last line via push_array, and the remaining lines are appended. Returns `this`.

**Notes.**

- failure: If this map has zero mapping lines, `m1.mappings[m1.mappings.length - 1]` is undefined and push_array would throw; the code relies on factories always producing at least one mapping line.

calls: [last_line_length](r2-preprocess-sourcemaps.md#u-e8017193524a), [merge_tables](r2-preprocess-sourcemaps.md#u-a97c97e7b9a7), [push_array](r3-compiler-shared-utils.md#u-4f8a7deedb7c)

<a id="u-5bfe07934570"></a>
### `MappedCode.constructor`

`constructor(string = '', map = null)` · [packages/svelte/src/compiler/utils/mapped_code.js:L90-L102][f3]

Stores the given string (default '') and, when a map is supplied, keeps it as-is; otherwise builds an empty decoded map `{version: 3, mappings: [], sources: [], names: []}`.

Only field assignment; no validation or copying.

inherits: [MappedCode](r2-preprocess-sourcemaps.md#u-3b244745bdc8)

<a id="u-55e9f4707897"></a>
### `MappedCode.from_processed`

`static from_processed(string, map)` · [packages/svelte/src/compiler/utils/mapped_code.js:L192-L209][f3]

Builds a MappedCode from generated code plus an existing decoded map, padding the map so mapping lines match code lines.

With a map, it appends empty segment lists until `map.mappings.length` equals the `\n`-separated line count, then returns a new instance. Without a map and with an empty string it returns a default instance; otherwise it creates an empty version-3 map with one empty mapping line per code line so every generated line has an entry.

uses: [MappedCode](r2-preprocess-sourcemaps.md#u-3b244745bdc8)

**Uncertainties.**

- If the provided map has more mapping lines than the string has lines, `missing_lines` is negative and the loop does nothing; the excess is kept.

<a id="u-60c4a1a9f36f"></a>
### `MappedCode.from_source`

`static from_source({ source, file_basename, get_location })` · [packages/svelte/src/compiler/utils/mapped_code.js:L216-L248][f3]

Builds a high-resolution identity sourcemap for a raw source string attributed to one file.

It takes the Source record's `source`, `file_basename`, and `get_location`; the offset defaults to line 0, column 0 when `get_location(0)` is falsy. An empty source returns an instance whose map names only the basename but has no mappings. Otherwise each line is tokenized with the regex `/([^\w\s]|\s+)/g`, and each non-empty token becomes a segment `[column, 0, offset.line + line, column]`, mapping generated columns onto source positions; columns in the first generated line are additionally shifted by `offset.column`. The map's single source is the basename.

uses: [MappedCode](r2-preprocess-sourcemaps.md#u-3b244745bdc8)

**Uncertainties.**

- All segments use source index 0, so the map is only correct while `sources` has exactly that one basename.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/preprocess/decode_sourcemap.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/preprocess/index.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/utils/mapped_code.js
