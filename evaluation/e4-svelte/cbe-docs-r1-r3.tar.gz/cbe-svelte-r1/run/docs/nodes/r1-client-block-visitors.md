# Client Block & Element Visitors

**Capability.** Per-node visitors lowering each block type (await, each, boundary, self, fragment, transitions, spreads) and the component program scope into runtime calls.

Use this for the visitor-by-visitor behavior of client output. Program.js installs top-level name transforms; the remaining visitors each emit one runtime construct and delegate shared building to the utils sibling.

**Depends on.**

- [Shared Client Transform Builders](r1-client-shared-transform-utils.md) · graph-confirmed · 6 edge(s)

**Depended on by.**

- [Client Dev Diagnostics & HMR](r1-client-dev-tools.md) · graph-confirmed · 1 edge(s)
- [Svelte 4 Automigrator](r1-migrator.md) · graph-confirmed · 6 edge(s)
- [Treeshakeability Audit](r1-treeshakeability-audit.md) · graph-confirmed · 1 edge(s)

Parent: [Client Transform Phase](r1-client-transform.md)

## Units (10)

<a id="u-ba1f8c9b6c22"></a>
### `Program`

`export function Program(_, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/Program.js:L11-L49][f1]

Installs name transforms for the component's top-level scope before visiting the program body.

In legacy (non-runes) mode it maps $$props reads to $$sanitized_props, and for mutated import bindings it determines instance vs module scope by comparing the import declaration's start/end against the instance script AST; instance imports get a $$_import_<name> variable backed by $.reactive_import, with read/mutate transforms routing through a call to that variable. For every store_sub binding it installs a lazily cached store reference (visited on first use so later transforms still apply) with transforms: read unwraps via b.call, assign uses $.store_set, mutate builds $.store_mutate with the store read untracked (recursively replacing the member-expression left so only the base is untracked), and update picks $.update_store or $.update_pre_store with build_getter and a -1 literal for '--'. For prop and bindable_prop bindings, is_prop_source decides between a source transform (read via call, assign calling the setter, mutate calling with a true flag only for bindable_prop for legacy-parent interop, update via $.update_prop/$.update_pre_prop) and a plain $$props member read using the prop alias when present. Finally it installs additional state transformers via add_state_transformers and continues traversal with context.next().

uses: [should_proxy][f2]; calls: [add_state_transformers](r2-transform-client.md#u-32bec314643f)

**Uncertainties.**

- is_prop_source's criteria live in client/utils.js and are not visible in this file.
- The interplay between the mutate transform's replace() recursion and arbitrary left-hand expressions is inferred from the recursive MemberExpression rebuild only.

<a id="u-34b00bddeeac"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/AwaitBlock.js:AwaitBlock`

`export function AwaitBlock(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/AwaitBlock.js:L14-L75][f3]

Serializes an {#await} block into a single $.await call pushed to init.

It pushes a template comment, then builds the awaited expression as a thunk, async-flagged when metadata.expression.has_await is set. If node.then exists it forks the context with a copied transform map, generates a derived block argument when node.value is present, visits the then block in that forked state, and wraps argument declarations plus the block body in an arrow taking $$anchor and the argument id; node.catch is handled the same way with node.error in its own forked state. If node.pending exists it visits it into an arrow over $$anchor, otherwise it passes b.null. Finally it pushes add_svelte_meta around the $.await call (node, expression thunk, pending, then_block, catch_block) into state.init.

**Notes.**

- side_effect: Forked then/catch contexts copy state.transform, so their child transforms do not leak back to the parent state.

calls: [create_derived_block_argument](r1-client-block-visitors.md#u-741970a13fda), [build_expression](r1-client-shared-transform-utils.md#u-cd5eb51d389f), [add_svelte_meta](r1-client-shared-transform-utils.md#u-75700db42066)

<a id="u-741970a13fda"></a>
### `create_derived_block_argument`

`function create_derived_block_argument(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/AwaitBlock.js:L82-L110][f3]

Builds the destructured value argument for an await block's then/catch branches.

For an Identifier pattern it registers context.state.transform[node.name] = { read: get_value } and returns the identifier with null declarations. For any other pattern it visits the pattern, extracts its identifiers, and builds a block that does `var <pattern> = $.get($$source)` and returns an object of the identifiers; that block becomes a create_derived assigned to $$value, and each extracted identifier becomes its own create_derived of `$.get($$value).<id>` with a get_value read registered in transform. Returns the exposed argument id (the original identifier or a new $$source) and the declaration statements to prepend to the branch body.

calls: [create_derived](r4-client-transform.md#u-d8c62e2be238), [extract_identifiers](r5-compiler-ast-utils.md#u-90eb95affc00)

<a id="u-d99c085dd1f2"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/EachBlock.js:EachBlock`

`export function EachBlock(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/EachBlock.js:L22-L358][f4]

Lowers an {#each} block into an $.each runtime call, building flags, transforms, and invalidation logic.

The list expression is built in the parent scope (scope.parent) via build_expression. Flags accumulate: EACH_INDEX_REACTIVE when keyed with an index; EACH_ITEM_REACTIVE when a dependency crosses function boundaries (skipping same-scope ones) and (not runes mode, or the key is not exactly the item identifier, or the expression references a store_sub); EACH_ITEM_IMMUTABLE in runes mode without store usage; EACH_IS_ANIMATED when a sole child element carries an animate: directive; EACH_IS_CONTROLLED for controlled blocks. A non-controlled block first pushes a template comment. If the collection expression's base identifier resolves to a store_sub binding, its name is recorded as store_to_invalidate for later $.invalidate_store. When the inner scope shadows any outer declaration, a unique $$array identifier (collection_id) is created so the array can still be referenced inside. Index handling: with group bindings or no user index, a generated index identifier is used; child_state.transform[index] unwraps via get_value only when EACH_INDEX_REACTIVE is set and marks uses_index; key_state.transform marks key_uses_index without unwrapping. In legacy (non-runes) mode, transitive dependencies — the collection_id or each-block dependencies plus those of all parent each blocks from collect_parent_each_blocks — become an $.invalidate_inner_signals thunk sequence appended to `sequence`. For an Identifier context, the item transform reads array[index] when the binding was reassigned, otherwise the item (unwrapped by get_value when reactive); assign/mutate produce sequences appending `sequence`, which includes store invalidation. For destructured contexts, inserts become $.derived variables and paths become let declarations ($.derived_safe_equal when a default value must be evaluated only once), each with read/assign/mutate transforms; in dev a read is eagerly evaluated to surface 'accessed before initialization' errors. The body is visited in child_state; the key function is an arrow over the visited key when keyed. If the expression has_await, the collection thunk is deferred via an $.async wrapper producing $$collection; otherwise the $.each call (annotated with svelte meta, and preceded by $.validate_each_keys in dev when keyed) is pushed to init. Fallback ({:else}) becomes an extra anchor arrow argument.

**Notes.**

- condition: The item read for a reassigned legacy binding indexes the live collection instead of using the item variable, since the item copy would be stale.

calls: [build_expression](r1-client-shared-transform-utils.md#u-cd5eb51d389f), [get_value](r2-transform-client.md#u-928394943600), [add_svelte_meta](r1-client-shared-transform-utils.md#u-75700db42066), [extract_paths](r5-compiler-ast-utils.md#u-34f2fcb20c62), [object](r5-compiler-ast-utils.md#u-2f2548aeaec6), [Template](r1-client-template.md#u-f09b36ebd45e); group: [eachblock-js-collect-parent-each-blocks](r1-client-block-visitors.md#u-8c4839a8b741)

**Uncertainties.**

- The semantics of the flag constants (beyond their names) come from constants.js and are not shown.
- get_value and build_expression behaviors are defined in shared modules outside this file.

<a id="u-8c4839a8b741"></a>
### `eachblock-js-collect-parent-each-blocks`

`function collect_parent_each_blocks(context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/EachBlock.js:L363-L365][f4]

Returns every EachBlock on the current context.path, cast to AST.EachBlock[], so EachBlock can merge ancestor blocks' transitive dependencies when generating legacy-mode invalidation.

<a id="u-7506ce95c563"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/SpreadAttribute.js:SpreadAttribute`

`export function SpreadAttribute(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/SpreadAttribute.js:L8-L10][f5]

Compiles a spread attribute by simply visiting and returning its expression.

<a id="u-78cb80fb5d8c"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/SvelteBoundary.js:SvelteBoundary`

`export function SvelteBoundary(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/SvelteBoundary.js:L11-L116][f6]

Transforms a `<svelte:boundary>` into a `$.boundary(node, props, ($$anchor) => block)` call.

Attributes become props: stateful attribute expressions become getters returning the visited expression; static ones become init properties; shorthand (`value === true`) attributes are skipped as impossible after validation. Const tags must live inside the boundary but may be referenced by hoisted snippets; outside experimental.async mode they are visited into `const_tags` and both unshifted into the boundary block and duplicated into hoisted snippet bodies (the comment marks this duplication as temporary). In async mode, const tags stay in the fragment and snippets that could reference them (any snippet not named `failed`/`pending` when const tags exist) remain in the fragment rather than being hoisted. Snippets named `failed`/`pending` are additionally added as init props keyed by their expression. Visited snippet declarations are extracted from the emitted statements; in dev the function is read from the declaration's call arguments. Remaining children form the fragment, visited into the arrow-function block (with const_tags prepended outside async mode). The boundary statement is wrapped in a block with hoisted snippets if any, and a template comment is pushed.

calls: [Template](r1-client-template.md#u-f09b36ebd45e)

**Uncertainties.**

- Whether push_comment is called once per boundary or expects matching pop elsewhere is not visible in this file.

<a id="u-dc69513c68f2"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/SvelteFragment.js:SvelteFragment`

`export function SvelteFragment(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/SvelteFragment.js:L9-L17][f7]

Inlines a <svelte:fragment>'s content into init output.

LetDirective attributes are visited and pushed to init first, then the visited fragment block's statements are appended to init.

<a id="u-d35c66d967c0"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/SvelteSelf.js:SvelteSelf`

`export function SvelteSelf(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/SvelteSelf.js:L9-L12][f8]

Compiles <svelte:self> via build_component named after the current analysis's component name, pushing the result into init.

calls: [component-js-build-component](r1-client-shared-transform-utils.md#u-af8f6b0917f6)

<a id="u-960109c44c27"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/TransitionDirective.js:TransitionDirective`

`export function TransitionDirective(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/TransitionDirective.js:L12-L29][f9]

Serializes transition: directives into a $.transition call queued in after_update so it runs after bind:this.

Flags are composed from modifiers and presence: 'global' sets TRANSITION_GLOBAL (otherwise 0), node.intro adds TRANSITION_IN, node.outro adds TRANSITION_OUT. Arguments are the flag literal, the anchor node, and a thunk of the visited directive name (resolved by parse_directive_name); when node.expression exists a thunk of its visited value is appended.

**Notes.**

- side_effect: The statement goes to context.state.after_update, not init, per the source comment on ordering with bind:this.

calls: [parse_directive_name](r1-client-shared-transform-utils.md#u-47fb5120ded1)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/Program.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/utils.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/AwaitBlock.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/EachBlock.js
[f5]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/SpreadAttribute.js
[f6]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/SvelteBoundary.js
[f7]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/SvelteFragment.js
[f8]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/SvelteSelf.js
[f9]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/TransitionDirective.js
