# Client code generation

**Capability.** Owns rewriting the analyzed AST into client-side JavaScript: identifiers become reactive reads, directives and events become runtime calls, and blocks/special elements become DOM-building output, backed by shared visitor helpers.

Enter here to see how each construct is serialized for the browser. Shared helpers (declarations, events, function) are grouped with the visitors that consume them because their capability is client-output shaping only. Types for the lightweight template tree live here as declaration-only material.

**Depends on.**

- [Compile diagnostics](r2-compiler-diagnostics.md) · model-inferred · 0 edge(s)
- [Shared Client Transform Builders](r1-client-shared-transform-utils.md) · graph-only · 16 edge(s)

Parent: [Component compiler pipeline](r2-compiler.md)

## Units (22)

<a id="u-0b4eac9ca055"></a>
### `types.d.ts module code (L1–L2)`

`export interface Element` · [packages/svelte/src/compiler/phases/3-transform/client/transform-template/types.d.ts:L3-L10][f1]

Type-only declarations for the lightweight template node tree built by Template: Element (name, attribute record, children, start offset for __svelte_meta), Text (AST.Text nodes), Comment (optional data), and the Node union.

<a id="u-4517247cbf4b"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/ArrowFunctionExpression.js:ArrowFunctionExpression`

`export function ArrowFunctionExpression(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/ArrowFunctionExpression.js:L9-L11][f2]

Delegates arrow function transformation to the shared visit_function helper.

calls: [packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/function.js:visit_function](r2-transform-client.md#u-888d94f48ee5)

<a id="u-0ec3860847c4"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/Attribute.js:Attribute`

`export function Attribute(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/Attribute.js:L10-L14][f3]

Handles regular attributes during client transformation; when the attribute is an event attribute (on*) it forwards to visit_event_attribute, otherwise it does nothing here.

uses: [is_event_attribute](r5-compiler-ast-utils.md#u-1c2da82112be); calls: [visit_event_attribute](r2-transform-client.md#u-8ff2bf148b08)

<a id="u-61fecc929533"></a>
### `BinaryExpression`

`export function BinaryExpression(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/BinaryExpression.js:L10-L34][f4]

In dev, rewrites equality comparisons to runtime helpers that normalize proxy and NaN semantics.

For === / !== it returns $.strict_equals(left, right) with a trailing b.false only when the operator is !== (the expression `operator === '!==' && b.false` yields b.false or false); for == / != it returns $.equals(left, right) with b.false only for !=. Both operands are visited. For any other operator, or in non-dev builds, no call node is produced and context.next() performs the default traversal.

**Notes.**

- condition: Outside dev the visitor has no effect on output; the dev branch is skipped entirely.

<a id="u-e55ab0a7d69f"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/BindDirective.js:BindDirective`

`export function BindDirective(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/BindDirective.js:L15-L260][f5]

Lowers a bind: directive into a runtime binding call.

It visits the bound expression; if it is a SequenceExpression, its two parts are get/set; otherwise in dev runes mode, when the expression is a MemberExpression and the binding is 'this' nested under IfBlock/EachBlock/AwaitBlock/KeyBlock (or the name is not 'this'), and the binding_property_non_reactive warning is not ignored, validate_binding runs. The default get is a thunk of the expression and set is an unthunked arrow assigning $$value back to the expression; if get and set turn out identical, set is dropped. If binding_properties has an event, it emits $.bind_property(name, event, node, set??get, bidirectional && get). Otherwise a name switch picks special bind_* calls: window bindings (online, scrollX/scrollY with axis literal, innerWidth/innerHeight/outerWidth/outerHeight), document activeElement, media bindings (muted, paused, volume, playbackRate, currentTime, buffered, played, seekable, seeking, ended, readyState — most get the node plus get and set, read-only ones only set??get), resize-observer and element-size bindings, value (special-cased to $.bind_select_value for a <select> parent), files, this (via build_bind_this), textContent/innerHTML/innerText as content_editable, checked, focused, and group. For group, parent each-block indexes are wrapped in $.get when the block is keyed with a reactive index, and when the parent element has a non-text value attribute the getter is replaced by a thunk evaluating the value attribute before returning the expression, so value updates retrigger the group binding. Unknown names throw 'unknown binding'. Finally, bind:this statements go into init; others go into after_update, or are wrapped in an $.effect thunk when the parent element also has a use: directive, so bindings run after attribute updates and in order with actions.

**Notes.**

- failure: A bind name not present in the switch and without a binding_properties entry throws new Error('unknown binding ' + node.name).

calls: [validate_binding](r1-client-shared-transform-utils.md#u-91b59b999e05), [build_bind_this](r1-client-shared-transform-utils.md#u-62396233e782), [build_attribute_value](r3-compiler-transform-client.md#u-2462157783c9), [is_ignored](r5-compiler-state-errors.md#u-468324b42cee); uses: [is_text_attribute][f6]

**Uncertainties.**

- b.unthunk's exact semantics (when it decides get === set) are in the builders module, not this file.
- The shape of binding_properties entries (event, bidirectional flags) comes from bindings.js and is not shown.

<a id="u-9ed746e0d1ee"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/Component.js:Component`

`export function Component(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/Component.js:L10-L13][f7]

Compiles a component usage via build_component using the tag name, and pushes the resulting declaration into init output.

calls: [component-js-build-component](r1-client-shared-transform-utils.md#u-af8f6b0917f6)

<a id="u-494b5cffc303"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/DebugTag.js:DebugTag`

`export function DebugTag(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/DebugTag.js:L10-L28][f8]

Compiles {@debug ...} into a console.log of a snapshot object, wrapped in a template_effect containing a debugger statement.

Each identifier becomes a property whose value is $.snapshot of the visited identifier; in runes mode the snapshot call is used directly, in legacy mode it is wrapped in $.untrack(thunk) to avoid dependency tracking.

<a id="u-123cf8349bd2"></a>
### `ForOfStatement`

`export function ForOfStatement(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/ForOfStatement.js:L10-L25][f9]

Rewrites awaited for-of loops in dev when async mode is enabled, to warn on reactivity loss.

Only when node.await, dev is true, the 'await_reactivity_loss' warning is not ignored, and options.experimental.async is on does it rewrite: left, right, and body are visited and the right side is wrapped in $.for_await_track_reactivity_loss, producing an await for-of. All other cases take context.next().

uses: [is_ignored](r5-compiler-state-errors.md#u-468324b42cee)

<a id="u-e62b6e822f4a"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/FunctionExpression.js:FunctionExpression`

`export function FunctionExpression(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/FunctionExpression.js:L9-L11][f10]

Delegates function expression transformation to the shared visit_function helper.

calls: [packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/function.js:visit_function](r2-transform-client.md#u-888d94f48ee5)

<a id="u-33e650400bd4"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/Identifier.js:Identifier`

`export function Identifier(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/Identifier.js:L11-L41][f11]

Rewrites identifier references to component runtime access.

Only when is_reference(node, parent) is true does it act: `$$props` is renamed to `$$sanitized_props`; for rest props in runes mode (binding.kind === 'rest_prop', node not the binding's declaration node), a non-computed member read whose grandparent is not an AssignmentExpression or UpdateExpression is replaced with direct `$$props` access as an optimization; all other references go through build_getter, which produces the reactive read expression for the binding. Non-reference identifiers (property keys, member property positions) return undefined and are handled elsewhere.

**Notes.**

- condition: The $$props member-access optimization is gated on analysis.runes because legacy-mode proxies behave differently on direct access.

calls: [build_getter](r4-client-transform.md#u-66a19e20e1f1)

<a id="u-c4e00e5384f2"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/IfBlock.js:IfBlock`

`export function IfBlock(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/IfBlock.js:L11-L88][f12]

Serializes an {#if} block into hoisted branch functions plus a $.if call, with an async variant when the condition awaits.

It pushes a template comment, visits the consequent into an arrow over $$anchor stored in a generated 'consequent' variable, and likewise the alternate into an 'alternate' variable when present. It builds the test via build_expression; when has_await is set the rendered condition reads `$.get($$condition)`. The $.if call receives the anchor node and a `$$render` callback that invokes the consequent or alternate arrow. For node.elseif blocks it appends b.true as a final argument so transitions play on changes to any condition in the `{:else if}` chain rather than only the last one, as explained in the source comment. If has_await, init receives a $.async(node, [thunk(expression, true)], callback-binding-$$condition) wrapper around all statements; otherwise a plain block of the statements is pushed to init.

calls: [build_expression](r1-client-shared-transform-utils.md#u-cd5eb51d389f), [add_svelte_meta](r1-client-shared-transform-utils.md#u-75700db42066)

<a id="u-a9aa3f77ec68"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/RenderTag.js:RenderTag`

`export function RenderTag(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/RenderTag.js:L12-L89][f13]

Serializes {@render} tags, memoizing arguments that contain awaits or calls and routing through $.async when needed.

After pushing a template comment it unwraps any optional chain from node.expression. Each argument is built with build_expression and, when its metadata has_await or has_call, replaced by `$.get(memoizer.add(expression, has_await))` inside a thunk; memoizer.apply() then emits any memo statements. memoizer.deriveds provides the leading statements (runes-mode dependent). The snippet callee is built via build_expression. When node.metadata.dynamic the render becomes a $.snippet(node, thunk(callee), ...args) call, with the callee guarded by `?? $.noop` when the original expression was a ChainExpression so a nullish snippet renders nothing; otherwise it is a direct (or optional) call to the snippet function with the node and args. Both forms are wrapped in add_svelte_meta with kind 'render'. If memoizer.async_values() is non-empty, init receives a $.async(node, values, arrow(node, ...async_ids) block) statement; otherwise the single statement or a block of statements is pushed to init.

calls: [add_svelte_meta](r1-client-shared-transform-utils.md#u-75700db42066), [build_expression](r1-client-shared-transform-utils.md#u-cd5eb51d389f), [unwrap_optional](r5-compiler-ast-utils.md#u-aa95700b7c80)

**Uncertainties.**

- The exact contract of Memoizer.deriveds(analysis.runes) (what it emits per mode) lives in shared/utils.js and is not visible here.

<a id="u-af73e301b19f"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/SvelteDocument.js:SvelteDocument`

`export function SvelteDocument(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/SvelteDocument.js:L9-L11][f14]

Compiles <svelte:document> by delegating to visit_special_element with target $.document.

calls: [visit_special_element](r5-client-transform-visitors.md#u-5f6160c62286)

<a id="u-679da0880969"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/SvelteWindow.js:SvelteWindow`

`export function SvelteWindow(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/SvelteWindow.js:L9-L11][f15]

Compiles <svelte:window> by delegating to visit_special_element with target $.window.

calls: [visit_special_element](r5-client-transform-visitors.md#u-5f6160c62286)

<a id="u-f5935e5dfe7b"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/UpdateExpression.js:UpdateExpression`

`export function UpdateExpression(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/UpdateExpression.js:L11-L55][f16]

Transforms ++/-- expressions with state-aware mutation handling.

For `this.#field` increments where state_fields contains the matching private name, it returns a `$.update` (or `$.update_pre` for prefix operators) call on the member, passing b.literal(-1) as the delta for `--`. If the argument is neither an Identifier nor a MemberExpression it throws 'An impossible state was reached'. Otherwise it takes the base identifier via object(argument); when the argument is a bare identifier with a transform offering update, it delegates to transformers.update(node) — the source notes ownership_invalid_mutation does not apply since this is reassignment, not mutation. Otherwise it runs context.next() for the default transformation and, when a base identifier has a mutate transformer, wraps the result with transformers.mutate(left, update); the final expression passes through validate_mutation, which performs the dev-mode mutation ownership checks.

**Notes.**

- failure: The only thrown error is the 'impossible state' guard for unsupported argument shapes.

calls: [validate_mutation](r1-client-shared-transform-utils.md#u-a58215b09609), [object](r5-compiler-ast-utils.md#u-2f2548aeaec6)

<a id="u-32bec314643f"></a>
### `add_state_transformers`

`export function add_state_transformers(context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/declarations.js:L18-L53][f17]

Installs read/assign/mutate/update transformers on context.state.transform for every binding in the current scope that is a state source, derived, or legacy_reactive.

Read uses `$.safe_get` when the declaration kind is `var` (possibly reassigned), otherwise the `$.get` wrapper. Assign emits `$.set` with a proxy flag, and when a matching `$name` store subscription exists in scope wraps the call in `$.store_unsub`. Mutate returns the mutation unchanged in runes mode, else wraps it in `$.mutate`. Update emits `$.update_pre` for prefix operators, `$.update` otherwise, passing -1 only for `--`.

**Notes.**

- side_effect: Mutates context.state.transform in place for qualifying declarations; silently does nothing when no binding qualifies.

calls: [is_state_source](r4-client-transform.md#u-4eba3d9b7ec5)

<a id="u-928394943600"></a>
### `get_value`

`export function get_value(node)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/declarations.js:L10-L12][f17]

Wraps an identifier in a `$.get` call, producing the standard reactive read expression for state bindings.

uses: [add_state_transformers](r2-transform-client.md#u-32bec314643f)

<a id="u-0bee50cc5235"></a>
### `build_event`

`export function build_event(event_name, node, handler, capture, passive)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/events.js:L94-L103][f18]

Builds the $.event runtime call for a non-delegated handler: event name literal, target node, handler, and a true literal only when capture; passive becomes undefined when not passive, otherwise a literal true.

<a id="u-227977f005ec"></a>
### `build_event_handler`

`export function build_event_handler(node, metadata, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/events.js:L112-L177][f18]

Builds the handler expression for an event attribute or directive.

A null expression yields a function calling $.bubble_event.call(this, $$props, $$arg). The expression is visited; inline arrow/function handlers pass through unchanged. Identifier handlers pass through when the binding is a function, or when not in dev and the binding is not an import; imported bindings and dev-mode identifiers fall through to the wrapped path. When metadata.has_call, the handler is memoized as a $.derived var (name from scope.generate('event_handler')) read through $.get. Otherwise the handler is wrapped in a function calling handler.apply(this, $$args); in dev this becomes a $.apply call carrying the component name, the source location (line/column array when locator resolves), a has_side_effects flag, and a remove_parens flag for zero-argument identifier calls.

**Notes.**

- side_effect: Pushes the memoizing $.derived var declaration into context.state.init when metadata.has_call.

calls: [Scope](r4-compiler-model.md#u-01a82e58170d), [has_side_effects](r2-transform-client.md#u-229b6845de57)

**Uncertainties.**

- Exact dev $.apply argument semantics (e.g. effect of remove_parens) depend on runtime code not supplied.

<a id="u-229b6845de57"></a>
### `has_side_effects`

`function has_side_effects(node)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/events.js:L182-L197][f18]

Conservatively reports whether an expression can have side effects: true for call, new, assignment, and update expressions; sequence expressions recurse over each sub-expression; everything else is false.

<a id="u-8ff2bf148b08"></a>
### `visit_event_attribute`

`export function visit_event_attribute(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/events.js:L12-L84][f18]

Compiles on* attributes into either delegated or explicit event wiring.

The event name is the attribute name minus 'on:'; names matching is_capture_event lose their 'capture' suffix and set capture. The attribute value's expression tag yields a handler via build_event_handler. If node.metadata.delegated is set, the event name is registered in state.events and an assignment of the handler (or an array of handler plus hoisted closure params, when metadata.delegated.hoisted and hoisted_params exist; the handler becomes a hoisted var named on_<event> when the delegated function is the tag expression) to node.__<event> is pushed to init. Otherwise a $.event call from build_event — passing capture true only when capturing and passive true only when is_passive_event matches — is pushed to init for SvelteDocument/SvelteWindow/SvelteBody parents (events above the component run parent-first) and to after_update otherwise.

**Notes.**

- side_effect: Registers event names in context.state.events, shared delegation state.

calls: [ScopeRoot](r4-compiler-model.md#u-8f49475011d6), [is_capture_event](r1-dom-dom-utils.md#u-612ef41e7040), [is_passive_event](r1-dom-dom-utils.md#u-d023bfe04bdf), [build_event_handler](r2-transform-client.md#u-227977f005ec), [build_event](r2-transform-client.md#u-0bee50cc5235)

**Uncertainties.**

- Hoisting path assumes node.metadata.delegated.function.metadata.hoisted_params exists when checked; the interplay of the two hoisted_params checks for exact runtime shapes is not fully visible.

<a id="u-888d94f48ee5"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/function.js:visit_function`

`export const visit_function = (node, context) =>` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/function.js:L9-L30][f19]

Visits arrow and function expressions during client transformation.

State is reset so `in_constructor` and `in_derived` are false; for a FunctionExpression whose parent is a constructor MethodDefinition, `in_constructor` is set true. If node metadata marks the function as hoisted, parameters are rebuilt with build_hoisted_params and the body is visited with the new state; otherwise traversal continues via context.next with the adjusted state.

calls: [build_hoisted_params](r4-client-transform.md#u-a89fb605f1f4)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/transform-template/types.d.ts
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/ArrowFunctionExpression.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/Attribute.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/BinaryExpression.js
[f5]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/BindDirective.js
[f6]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/utils/ast.js
[f7]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/Component.js
[f8]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/DebugTag.js
[f9]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/ForOfStatement.js
[f10]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/FunctionExpression.js
[f11]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/Identifier.js
[f12]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/IfBlock.js
[f13]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/RenderTag.js
[f14]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/SvelteDocument.js
[f15]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/SvelteWindow.js
[f16]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/UpdateExpression.js
[f17]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/declarations.js
[f18]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/events.js
[f19]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/function.js
