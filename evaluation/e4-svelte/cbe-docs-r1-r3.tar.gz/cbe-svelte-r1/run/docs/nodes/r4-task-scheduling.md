# Task Scheduling

**Capability.** Batched micro-task and idle-task queues that defer work such as event handling and post-update bindings.

A small infrastructure node: consumers (events, bind:this, createSubscriber, await blocks) schedule callbacks here rather than managing their own timing.

**Depended on by.**

- [Component Context](r4-component-context.md) · model-inferred · 0 edge(s)
- [DOM Blocks](r4-dom-blocks.md) · graph-confirmed · 1 edge(s)
- [DOM Elements & Events](r4-dom-elements.md) · graph-confirmed · 2 edge(s)
- [Reactive Primitives & Motion](r4-reactive-primitives.md) · graph-confirmed · 1 edge(s)

Parent: [DOM Rendering](r4-dom-rendering.md)

## Units (1)

<a id="u-2af0814cc5ec"></a>
### `task.js-queues`

`function run_micro_tasks()` · [packages/svelte/src/internal/client/dom/task.js:L15-L19][f1]

Batched micro-task and idle-task scheduling.

Two module arrays hold queued callbacks. `queue_micro_task` schedules `run_micro_tasks` via queueMicrotask only when the queue transitions from empty, then pushes the callback; `run_micro_tasks` swaps out the array and runs all taken callbacks via run_all. `queue_idle_task` mirrors this with `requestIdleCallback`, falling back to setTimeout(cb, 1) where requestIdleCallback is undefined; `run_idle_tasks` drains and runs them. `flush_tasks` synchronously drains both queues when non-empty, in micro-then-idle order.

**Notes.**

- side_effect: Module-level arrays are shared state; a drained-then-repushed callback in a task would run in a later batch, not the current one.

calls: [run_all](r5-internal-shared-utils.md#u-15a69c36073f)

**Uncertainties.**

- Exceptions thrown by a queued callback propagate through run_all; per-task isolation is not visible in this file.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/task.js
