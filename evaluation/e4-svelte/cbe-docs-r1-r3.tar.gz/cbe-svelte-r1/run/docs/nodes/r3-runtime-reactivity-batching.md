# Effect Batching & Scheduling

**Capability.** Collects source writes into Batches, schedules effects by walking to their root, flushes effect queues in coordinated phases, guards against infinite loops, supports synchronous flushSync and microtask task draining, and async-boundary suspension.

Use this subtree to understand update ordering and concurrency guarantees. mark_reactions in the sources subtree calls schedule_effect here; flushSync/flush_effects drive all queued work; suspend ties into boundary pending counts.

**Depends on.**

- [Signal Sources](r3-runtime-reactivity-sources.md) · model-inferred · 0 edge(s)
- [Signal Core](r5-signal-core.md) · graph-only · 12 edge(s)

**Depended on by.**

- [DOM Blocks](r3-runtime-dom-blocks.md) · graph-confirmed · 1 edge(s)
- [DOM Elements, Bindings & Transitions](r3-runtime-dom-elements.md) · model-inferred · 0 edge(s)
- [Signal Sources](r3-runtime-reactivity-sources.md) · graph-confirmed · 3 edge(s) · Signal writes via internal_set and mark_reactions hand off to batch scheduling so dependent effects flush together.
- [Reactivity Benchmarks & Test Config](r3-tooling-benchmarks.md) · model-inferred · 0 edge(s)

Parent: [Client Runtime Internals](r3-runtime.md)

## Units (8)

<a id="u-6d22ee98690b"></a>
### `batch.js-batch-class`

`class Batch` · [packages/svelte/src/internal/client/reactivity/batch.js:L81-L179][f1]

A Batch collects source writes and their previous values, traverses the effect tree, and flushes effects in coordinated phases so multiple concurrent async updates cannot interleave.

`current`/`#previous` map sources to new/old values (`capture` records both, first write wins in `#previous`). `process(root_effects)` resets the queue; in async mode with multiple live batches it 'time travels' by temporarily applying this batch's values and other batches' previous values, caching derived results in `batch_deriveds`. It traverses each root, then either commits (no async effects and `#pending === 0`): flushing render/block/effects, releasing `current_batch` while flushing, restoring itself or removing itself from `batches`, resolving `#deferred` — or, when async work is outstanding, defers all queued effects into `#dirty_effects`/`#maybe_dirty_effects` marked CLEAN so they reschedule later. After either path it runs collected async effects and boundary async effects via `update_effect`, and restores time-travelled source values unless they got newer writes. `#traverse_effect_tree` clears CLEAN from the root, walks the linked effect tree skipping clean branches, INERT effects, and `skipped_effects`; EFFECTs go to `#effects`, RENDER_EFFECTs (async mode) to `#render_effects`, ASYNC effects to `#boundary_async_effects` when their branch has pending state else `#async_effects`, and dirty BLOCK_EFFECTs are queued then updated inline. `#defer_effects` bins effects by DIRTY/MAYBE_DIRTY status. `activate`/`deactivate` set or clear `current_batch` (deactivate also clears `previous_batch` and drains `effect_pending_updates` one at a time, stopping if a new batch appears). `flush` runs pending `flush_effects` or commits, returns early if a nested `flushSync` replaced the current batch, removes itself from `batches` when `#pending === 0`, and deactivates. `#commit` runs and clears commit callbacks unless `#neutered` (an async effect resolved after its branch was destroyed). `increment`/`decrement` track in-flight async work; when pending hits 0, deferred effects get their statuses restored and are scheduled, queued arrays clear, and `flush` runs; otherwise just deactivate. `add_callback` registers DOM commit callbacks, `settled` lazily creates a deferred and returns its promise, static `ensure` creates and registers the current batch, enqueuing a microtask flush (which no-ops if a `flushSync` intervened), and static `enqueue` adds tasks to the microtask queue.

calls: [update_effect](r5-signal-core.md#u-e2ea8c85735e), [is_dirty](r5-signal-core.md#u-6236bf4a1a35), [set_signal_status](r5-signal-core.md#u-ebc2eda73ca2), [flush_queued_effects](r3-runtime-reactivity-batching.md#u-93f48e016c80), [schedule_effect](r3-runtime-reactivity-batching.md#u-ce4f8d895426), [deferred](r5-internal-shared-utils.md#u-3c5ab59ed010)

**Uncertainties.**

- Exact semantics of boundary `pending` state on ASYNC effect routing depend on boundary.js, not in this batch

<a id="u-f4c4d1829672"></a>
### `flushSync`

`export function flushSync(fn)` · [packages/svelte/src/internal/client/reactivity/batch.js:L485-L523][f1]

Synchronously flushes all pending updates, optionally running `fn` mid-flush and returning its result.

In async mode inside an effect it throws `flush_sync_in_effect`. Within `is_flushing_sync`, it loops: flushes microtasks, and if no root effects remain flushes the current batch and re-checks (a pending update may have re-queued work) before returning; otherwise flushes effects again. `is_flushing_sync` is restored in `finally`.

**Notes.**

- failure: Calling flushSync inside an effect in async mode raises e.flush_sync_in_effect before any flushing.

calls: [task.js-queues](r4-task-scheduling.md#u-2af0814cc5ec), [flush_effects](r3-runtime-reactivity-batching.md#u-bb27f3ab5ca2)

<a id="u-bb27f3ab5ca2"></a>
### `flush_effects`

`function flush_effects()` · [packages/svelte/src/internal/client/reactivity/batch.js:L525-L571][f1]

Drains `queued_root_effects` in a loop, ensuring a batch exists each iteration and processing it, clearing `old_values` after each pass.

Guards against runaway loops: after 1000 iterations it, in DEV, aggregates per-source update errors and logs them via console.error, then always calls `infinite_loop_guard`. Preserves and restores `is_updating_effect`, sets `is_flushing`, and resets `last_scheduled_effect` in `finally`.

calls: [infinite_loop_guard](r3-runtime-reactivity-batching.md#u-a4b355b41c3e), [runtime.js-module-state-setters](r5-signal-core.md#u-ac602620d878)

<a id="u-93f48e016c80"></a>
### `flush_queued_effects`

`function flush_queued_effects(effects)` · [packages/svelte/src/internal/client/reactivity/batch.js:L595-L642][f1]

Runs a snapshot list of effects in order, updating each that is neither destroyed/inert nor clean.

After updating, effects with no deps, children, or DOM nodes are pruned: fully unlink them from the graph if they have no teardown or abort controller, otherwise null their `fn` to free memory. If an update itself triggered a nested flush that populated `eager_block_effects`, those eager effects are updated and the array reset (noting a TODO that this feels incorrect). Finally `eager_block_effects` is nulled.

calls: [update_effect](r5-signal-core.md#u-e2ea8c85735e), [is_dirty](r5-signal-core.md#u-6236bf4a1a35), [destroy_effect](r5-effects-module.md#u-214ad59ce57a)

**Uncertainties.**

- `eager_block_effects` is populated inside update_effect's dependency handling (runtime.js), not visible here; only its consumer contract is evident

<a id="u-ce4f8d895426"></a>
### `schedule_effect`

`export function schedule_effect(signal)` · [packages/svelte/src/internal/client/reactivity/batch.js:L648-L668][f1]

Schedules an effect by walking to its root and queueing the root for flushing.

During traversal: if scheduling was triggered while a parent block effect is currently flushing (each/await internal source updates), it bails to avoid a second flush; at root or branch ancestors it returns early if they are already unclean, otherwise toggles CLEAN off before pushing the root into `queued_root_effects`. Also records the effect as `last_scheduled_effect` for the infinite-loop guard.

uses: [mark_reactions](r3-runtime-reactivity-sources.md#u-a19ed62d3d7e)

**Uncertainties.**

- Relation to mark_reactions is by call-site evidence; the invocation itself is not in this file

<a id="u-a4b355b41c3e"></a>
### `infinite_loop_guard`

`function infinite_loop_guard()` · [packages/svelte/src/internal/client/reactivity/batch.js:L573-L586][f1]

Raises the effect-update-depth-exceeded error and routes it to the nearest plausible boundary.

In DEV it strips the useless stack via `define_property`. The error is thrown and immediately caught so `invoke_error_boundary` can deliver it to `last_scheduled_effect`, a best-effort guess at the loop's location.

calls: [invoke_error_boundary](r1-error-propagation.md#u-8ed809bdafb5)

<a id="u-dbbbce459e92"></a>
### `dequeue`

`function dequeue()` · [packages/svelte/src/internal/client/reactivity/batch.js:L62-L70][f1]

Shifts one task off the module-level `tasks` queue; if more tasks remain it re-queues itself via `queueMicrotask` before running the shifted task, so remaining tasks drain one microtask at a time.

Companion to `Batch.enqueue`, which seeds the first dequeue when the queue is empty.

<a id="u-aed941f29bc8"></a>
### `suspend`

`export function suspend()` · [packages/svelte/src/internal/client/reactivity/batch.js:L670-L690][f1]

Implements async-block suspension: increments the pending boundary's count and, if the boundary was not already pending, increments the current batch's pending counter.

Returns `unsuspend`, which decrements the boundary count and then either reactivates and decrements the batch (triggering the flush when pending hits zero) or, if the boundary was already pending, merely deactivates the batch; it always clears context via `unset_context`.

calls: [get_pending_boundary](r1-boundary-blocks.md#u-662729eaf177), [unset_context](r4-client-reactivity.md#u-2e39d8f937d3)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/reactivity/batch.js
