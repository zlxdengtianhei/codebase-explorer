# Svelte 4 Automigrator

**Capability.** Best-effort rewrite of legacy components to runes, event attributes, snippets and render tags, with source-level text surgery and MigrationError guards for unconvertible patterns.

Use this to understand how `svelte-migrate` transforms scripts, templates, CSS, slots and events. Text edits go through state.str helpers (trim_block, guess_indent, get_node_range); rune-name collisions abort migration with actionable errors.

**Depends on.**

- [Client Block & Element Visitors](r1-client-block-visitors.md) · graph-confirmed · 6 edge(s)
- [DOM & Rune Constant Predicates](r1-dom-dom-utils.md) · graph-confirmed · 3 edge(s)

Parent: [Compiler Pipeline](r1-compiler.md)

## Units (22)

<a id="u-0c9d6fc8a11a"></a>
### `migrate`

`export function migrate(source, { filename, use_ts } = {})` · [packages/svelte/src/compiler/migrate/index.js:L124-L275][f1]

Best-effort migration entry point of Svelte 4 components toward runes, event attributes, and render tags; this first half performs setup.

It blanks every <style> block (recording offsets and content for restoration), resets module state with a warning-swallowing handler, parses the style-blanked source, and merges parsed options with defaults plus a customElementOptions passthrough and experimental async. It removes the accessors attribute from <svelte:options>, restores the style contents, and builds the shared State: instance scope, unique generated names for props/rest and every event-helper import, insertion points, and a uses_ts flag true when the caller passed use_ts with no '@type {' in the source or the instance script has lang="ts". A module script with a context attribute gets it rewritten to 'module'. It then walks the instance script with instance_script visitors, switches to the template scope and walks the fragment, computes need_script from legacy imports, derived components/conflicting slots, script insertions, props, rest/props usage, or svelte:self, and opens a <script> (lang="ts" when uses_ts and no lang attribute exists) at position 0 if there is no instance script but one is needed.

calls: [packages/svelte/src/compiler/phases/1-parse/index.js:parse](r3-compiler-parse.md#u-53ab5f2b9b37), [analyze_component](r3-compiler-analyze.md#u-32c86377621b), [reset](r5-compiler-state-errors.md#u-0d9f0b886c2d), [guess_indent](r1-migrator.md#u-4cb15da8c8dc); uses: [index.js-instance-script](r1-migrator.md#u-95abfcba687f), [index.js-template-visitors](r1-migrator.md#u-c2cc4d87e6a4)

**Uncertainties.**

- Behavior of analysis.root.unique name generation lives outside this file.

<a id="u-14a64e806c9a"></a>
### `packages/svelte/src/compiler/migrate/index.js:migrate`

`export function migrate(source, { filename, use_ts } = {})` · [packages/svelte/src/compiler/migrate/index.js:L282-L459][f1]

Completion of migrate(): emits props, reorders legacy reactive statements, appends derived declarations, closes the generated script, and defines the failure fallback.

When props/rest props/$$props usage is present it builds the props list, skipping type-only props, appending `= $bindable(init)` (after check_rune_binding('bindable')) or `= init`, and `...rest` for rest props; more than three props switch the separator to newlines. If a $props rune already exists the list is spliced into it; otherwise a Props type is generated only when types were detected or every prop is a slot — a TS interface (plus a string index signature when uses_props/uses_rest_props) or a @typedef/@type JSDoc block — and `let {…} = $props();` is appended after check_rune_binding('props'), adding lang="ts" to an existing script tag when needed. It then detects reactive statements depending on bindings declared after them (props compared against the insertion point, others by source offset) and, if any, moves every reactive statement to the instance script end, removing the vacated line including a preceding \r. $derived declarations for derived components and conflicting slots are appended after check_rune_binding('derived'), then an export block of non-slot, non-type-only props when accessors is set, and the closing </script> when one was opened. migrate_css runs before returning the transformed code. Any thrown value that is not a MigrationError is logged to the console; the catch always returns a `@migration-task` comment plus the original source, sets the module flag, and the finally block prints a reminder naming the file when a migration task was recorded.

**Notes.**

- failure: Every exception path, not only MigrationError, yields the migration-task comment and the unmodified original source.

calls: [packages/svelte/src/compiler/migrate/index.js:check_rune_binding (2)](r1-migrator.md#u-b571f219bc63), [migrate_css](r1-migrator.md#u-437d8a4fa38f), [get_node_range](r1-migrator.md#u-7acff5a27531); uses: [extract_identifiers](r5-compiler-ast-utils.md#u-90eb95affc00)

**Uncertainties.**

- Which of the three identically named check_rune_binding functions a given call resolves to depends on scoping; the graph could not disambiguate.
- Whether the reorder heuristic is exact for all dependency kinds is not provable from this file alone.

<a id="u-95abfcba687f"></a>
### `index.js-instance-script`

`const instance_script = { _(node, { state, next })` · [packages/svelte/src/compiler/migrate/index.js:L485-L500][f1]

Visitor map for the instance <script> during migration; each member receives State and a zimmerframe walk context.

The default visitor migrates `// svelte-ignore` line comments in place when migrate_svelte_ignore changes them. Identifier delegates to handle_identifier. ImportDeclaration advances the props insertion point past the import; for imports from 'svelte' it removes beforeUpdate/afterUpdate specifiers that have no references (removing the whole import when every specifier was removed) and throws a MigrationError naming any beforeUpdate/afterUpdate specifier that is still referenced. ExportNamedDeclaration removes export specifiers whose binding is a bindable_prop, removing the whole declaration when all specifiers were removed; declarations with a declaration body are left untouched. BreakStatement rewrites `break $` (inside a top-level $ label) to `return;`.

**Notes.**

- side_effect: Visitors mutate state.str, state.props, state.props_insertion_point, state.derived_labeled_statements, state.has_props_rune, and state.has_type_or_fallback in place.

calls: [migrate_svelte_ignore](r3-compiler-diagnostics.md#u-22cdd6c7c71c), [handle_identifier](r1-migrator.md#u-f31d2d5b26f5), [get_rune](r4-compiler-model.md#u-5204b6ce4f7a), [function::extract_all_identifiers_from_expression::4368][f2], [extract_type_and_comment](r1-migrator.md#u-081e94041a1f)

<a id="u-8c0aa73c8bca"></a>
### `VariableDeclaration`

`VariableDeclaration(node, { state, path, visit, next })` · [packages/svelte/src/compiler/migrate/index.js:L565-L712][f1]

Member of the instance-script visitor group.

Only acts when the current scope is the instance scope; otherwise returns immediately. For already-runes-mode components it only records a `$props` declaration's insertion point and sets has_props_rune, skipping other declarators. In legacy mode it resolves each declarator's bindings, skipping declarators whose bindings fail to resolve or have neither state nor bindable_prop kinds. For bindable props it throws MigrationError for non-Identifier patterns, and MigrationError when $$props is used together with named props that are initialized or updated; otherwise it records the prop (merging into an existing entry typed via $$Props when one matches) and erases the declarator text, handling multi-declarator lists by trimming from the neighboring comma and moving the insertion point past the whole node.

<a id="u-6d4274e4dd3e"></a>
### `packages/svelte/src/compiler/migrate/index.js:VariableDeclaration`

`VariableDeclaration(node, { state, path, visit, next })` · [packages/svelte/src/compiler/migrate/index.js:L719-L915][f1]

Continuation of the VariableDeclaration visitor for state bindings.

With an initializer it wraps the init (expanding SequenceExpression bounds to the enclosing parentheses) in `$state(...)` after the rune guard. Without an initializer it analyzes references: if every binding is only updated inside a single `$`-labeled statement (excluding `$: foo = bar` counting as reassignment of bar), and the labeled body is either a single-statement block or an assignment expression whose right side has no identifiers, the labeled statement's value is inlined as `= $derived(...)` (or `let x = $state(...)` when the assignment body has no identifiers on the right), removing the labeled statement and transferring its leading/trailing comments. Otherwise the declaration becomes `= $state(...)` with the labeled assignment's right side inlined when applicable. When every declaration became a prop, the whole line (including any ExportNamedDeclaration wrapper) is erased.

**Uncertainties.**

- The possible_derived reference-analysis conditions interact subtly; misclassification for exotic reference paths cannot be excluded from this source.

<a id="u-a9507fb93ee6"></a>
### `LabeledStatement`

`LabeledStatement(node, { path, state, next })` · [packages/svelte/src/compiler/migrate/index.js:L925-L936][f1]

First half of the instance-script `$:` label visitor: skips runes-mode analyses, nested labels (path length > 1), labels other than `$`, and statements already recorded as derived.

After visiting children it defines a rune-name guard used later.

<a id="u-ee80309dc8b0"></a>
### `packages/svelte/src/compiler/migrate/index.js:LabeledStatement`

`LabeledStatement(node, { path, state, next })` · [packages/svelte/src/compiler/migrate/index.js:L943-L1038][f1]

Continuation of the `$:` label visitor.

For an assignment expression body whose left-side bindings are all legacy_reactive: when the right side is not a Literal, no binding is a store_sub, and the left is not a MemberExpression, it converts the statement to `let <left> = $derived(<right>)` after the derived guard, expanding SequenceExpression bounds to the enclosing parentheses and reusing an existing trailing parenthesis (as in `$: ({ a } = b())`) instead of adding one. Otherwise, for reassigned bindings it hoists implicit declarations to `let <name> = $state(...)` before the label (inlining the right side when it has no identifiers), and removes the statement entirely when the right side has no identifiers and no store subscription is involved. Anything else falls back to the `run` helper: a block body becomes `run(() => { … });` in place, while an expression body becomes a `run(() => {` wrapper with re-indentation (excluding text outside the body) and a closing `});` — and adds 'run' to legacy_imports, which triggers the svelte/legacy import emission in migrate().

<a id="u-04a90805f3a2"></a>
### `BreakStatement`

`BreakStatement(node, { state, path })` · [packages/svelte/src/compiler/migrate/index.js:L916-L924][f1]

Member of the instance-script visitor group; rewrites `break $` to `return;` only when the statement's parent is a LabeledStatement and the label is `$`; otherwise leaves the node alone.

<a id="u-9d0d90798ea8"></a>
### `check_rune_binding`

`function check_rune_binding(rune)` · [packages/svelte/src/compiler/migrate/index.js:L936-L943][f1]

Nested guard inside the LabeledStatement visitor: throws a MigrationError quoting the labeled body when a variable named `state` or `derived` already exists in scope.

<a id="u-5b30a40a8a34"></a>
### `packages/svelte/src/compiler/migrate/index.js:check_rune_binding`

`function check_rune_binding(rune)` · [packages/svelte/src/compiler/migrate/index.js:L712-L719][f1]

Nested guard inside the instance-script VariableDeclaration visitor: throws a MigrationError quoting the declaration source when a variable named `state` or `derived` already exists in scope, preventing the automatic `$state`/`$derived` rewrite.

<a id="u-b571f219bc63"></a>
### `packages/svelte/src/compiler/migrate/index.js:check_rune_binding (2)`

`function check_rune_binding(rune)` · [packages/svelte/src/compiler/migrate/index.js:L275-L282][f1]

Guard used while emitting props, derived, and bindable declarations: it throws a MigrationError when the current scope already binds a variable named after the rune (derived, props, or bindable), instructing the user to rename and retry or migrate by hand, since the generated `$rune` reference would collide.

raises: [MigrationError](r1-migrator.md#u-18abcf9a9523)

<a id="u-18abcf9a9523"></a>
### `MigrationError`

`class MigrationError extends Error` · [packages/svelte/src/compiler/migrate/index.js:L28-L32][f1]

Custom error type marking failures that abort automigration because the code is too complex to convert.

It only forwards the message to Error; its value is that migrate()'s catch block distinguishes it from unexpected exceptions and suppresses the console error dump in that case.

uses: [packages/svelte/src/compiler/migrate/index.js:migrate](r1-migrator.md#u-14a64e806c9a)

<a id="u-081e94041a1f"></a>
### `extract_type_and_comment`

`function extract_type_and_comment(declarator, state, path)` · [packages/svelte/src/compiler/migrate/index.js:L1587-L1707][f1]

Derives a prop's type text plus leading and trailing comments from a VariableDeclarator, blanking consumed comments in state.str.

A TS type annotation wins immediately (setting has_type_or_fallback), skipping the colon and spaces. Otherwise comments are cleaned line-by-line (stripping `//`, JSDoc delimiters, and leading `*` markers) and truncated before the first `@` line. On an ExportNamedDeclaration parent whose JSDoc contains `@type {…}` it extracts that type (and any hyphen-separated JSDoc description), setting has_type_or_fallback. A Literal initializer of type string/number/boolean yields that primitive type (also setting has_type_or_fallback); everything else falls back to type 'any'. When uses_ts is set the raw comment strings are returned; otherwise the cleaned variants are.

uses: [Program](r1-client-block-visitors.md#u-ba1f8c9b6c22)

**Uncertainties.**

- The type of the comment nodes' start/end is only accessed through @ts-any casts, so the offsets rely on assumptions the type system does not verify.

<a id="u-97593ff10930"></a>
### `find_closing_parenthesis`

`function find_closing_parenthesis(start, code)` · [packages/svelte/src/compiler/migrate/index.js:L102-L114][f1]

Scans code from start with a balance counter beginning at 1, incrementing on '(' and decrementing on ')', and returns the index just past the character that balances the opening parenthesis.

It stops at end of string, returning that end even when no closing parenthesis was found.

**Uncertainties.**

- Unbalanced input silently returns the string end instead of signaling an error.

<a id="u-7acff5a27531"></a>
### `get_node_range`

`function get_node_range(source, node)` · [packages/svelte/src/compiler/migrate/index.js:L1818-L1841][f1]

Returns the start and end offsets of a labeled statement extended to include its leading and trailing comments, and with the start pulled back to the beginning of its line when only whitespace precedes it on that line; if a non-whitespace character is met before the line break, the original node start is kept.

Used to move whole reactive statements including comments.

**Uncertainties.**

- Comment node offsets are accessed through @ts-expect-error casts, relying on undocumented start/end properties.

<a id="u-4cb15da8c8dc"></a>
### `guess_indent`

`function guess_indent(content)` · [packages/svelte/src/compiler/migrate/index.js:L1970-L1994][f1]

Infers the file's indentation unit: '\t' when no indented lines exist, when tab-indented lines equal or outnumber space-indented lines (ties default to tabs), or otherwise a space run whose length is the minimum space-indent observed across lines.

<a id="u-c2cc4d87e6a4"></a>
### `index.js-template-visitors`

`const template = { Identifier(node, { state, path })` · [packages/svelte/src/compiler/migrate/index.js:L1056-L1059][f1]

Visitor map for the template fragment during migration.

Identifier delegates to handle_identifier. RegularElement migrates slot usage and events, then converts self-closing syntax on non-void, non-SVG elements into an explicit closing tag, stripping preceding whitespace before inserting `</name>`. SvelteSelf becomes a migration-task comment when no filename is known; otherwise it rewrites the opening tag (and closing tag when a fragment exists, or for `<svelte:self></svelte:self>` without `/>`) to the component's own name and records has_svelte_self. SvelteElement migrates slots and events and wraps a static, quoted Literal tag in `{…}` so it stays an expression. Component/SvelteFragment migrate slot usage after/before visiting children. SvelteWindow/SvelteBody/SvelteDocument only migrate event directives. HtmlTag and ConstTag trim their braces via trim_block, as do the header and each pending/catch section of IfBlock, AwaitBlock, and KeyBlock. Comment migrates svelte-ignore comments inside HTML comments. SlotElement (skipped for custom elements) converts the slot into a `children`/named-snippet prop and a `{#if …}{@render name(props)}{:else}…{/if}` (or optional `{@render name?.(props)}` when empty), collecting slot attributes and spreads into the props argument, aliasing the snippet through derived_conflicting_slots when the slot name conflicts with a parent's or its own `slot` attribute or with LetDirective-carrying ancestors, throwing MigrationError when a generated name would change a named slot's name, and pushing or refining a Snippet-typed prop. SvelteComponent rewrites `<svelte:component this={expr}>` to `<expr>`; when expr is not a plain valid component name it binds it via a `{@const}` at the nearest block/component ancestor or, failing that, via a `$derived` recorded in derived_components, and removes the `this={…}` attribute.

calls: [handle_identifier](r1-migrator.md#u-f31d2d5b26f5), [migrate_slot_usage](r1-migrator.md#u-4d888e7e32a9), [handle_events](r1-migrator.md#u-11d2b2cd1c0c), [trim_block](r1-migrator.md#u-cad9e2b4a6a0), [guess_indent](r1-migrator.md#u-4cb15da8c8dc), [migrate_svelte_ignore](r3-compiler-diagnostics.md#u-22cdd6c7c71c); uses: [is_text_attribute](r5-compiler-ast-utils.md#u-ec400088cae5), [is_void](r1-dom-dom-utils.md#u-9c54e843c710), [is_svg](r1-dom-dom-utils.md#u-890d02cea75e), [packages/svelte/src/compiler/phases/1-parse/state/element.js][f3]

**Uncertainties.**

- The SvelteComponent position/indent computation walks the path for block ancestors; exact insertion placement for mixed nesting is hard to verify from source alone.
- Whether every parent type checked for slot-name conflicts is exhaustive cannot be proven from this file.

<a id="u-11d2b2cd1c0c"></a>
### `handle_events`

`function handle_events(element, state)` · [packages/svelte/src/compiler/migrate/index.js:L1723-L1810][f1]

Rewrites legacy `on:event` directives into event attributes on regular/svelte elements and window-family nodes.

It groups OnDirectives by `on<name>` plus a `capture` suffix. Per directive, the handler body is the expression source, or a `bubble('name')` call (registering the createBubbler import and its const insertion) when the directive has no expression. Modifiers wrap the body in helper calls in fixed order (preventDefault, stopPropagation, stopImmediatePropagation, self, trusted, once), each added to legacy_imports. passive/nonpassive modifiers instead replace the whole directive with a `use:passive|nonpassive={['name', () => body]}` action, which takes precedence over attribute conversion. For the remaining cases only the first directive is kept as the attribute anchor; later duplicates are removed including surrounding whitespace. A single handler becomes `on:x={body}` (or `{body}` shorthand when body equals the attribute name); multiple handlers become `on:x={handlers(h1, h2, …)}` via the handlers helper.

**Notes.**

- side_effect: Adds to state.legacy_imports and state.script_insertions, driving the svelte/legacy import emission.

**Uncertainties.**

- Modifier helper behaviors (e.g. trusted) come from svelte/legacy and are outside this file.

<a id="u-f31d2d5b26f5"></a>
### `handle_identifier`

`function handle_identifier(node, state, path)` · [packages/svelte/src/compiler/migrate/index.js:L1848-L1967][f1]

Rewrites legacy prop/slot global identifiers found in scripts and templates.

It skips non-computed MemberExpression properties. When $$props is used: `$$props` and `$$restProps` become the generated props name; any other identifier bound as a bindable_prop (and not the declaration itself) is prefixed with `<props>.`. Otherwise `$$restProps` becomes the generated rest name when rest props are used. `$$slots.<name>` (when slots are used and not a custom element) becomes a snippet access: the slot name resolves to an existing prop or is generated (MigrationError if renaming would occur), 'default' maps to 'children', a new Snippet-typed prop is pushed with needs_refine_type so the type can be refined at the render site, and the whole `$$slots.<name>` range is rewritten to the (optionally props-prefixed) snippet name; a bare `$$slots` identifier is left to error later. Inside a TSInterfaceDeclaration or TSTypeAliasDeclaration named `$$Props`, each member's type, optionality, and comments are applied to matching props or pushed as type-only props, and the whole declaration is removed.

**Notes.**

- side_effect: Pushes to state.props and sets state.has_type_or_fallback for $$Props declarations.

**Uncertainties.**

- For non-MemberExpression `$$slots` uses the code deliberately lets compilation error; the resulting user-facing failure is outside this file.

<a id="u-4d888e7e32a9"></a>
### `migrate_slot_usage`

`function migrate_slot_usage(node, path, state)` · [packages/svelte/src/compiler/migrate/index.js:L1418-L1580][f1]

Converts Svelte 4 slot/let usage on components into snippets.

It bails out unless the node itself or its grandparent is a Component/SvelteComponent. A text `slot` attribute determines the snippet name ('default' becomes 'children'); an invalid identifier or reserved word, or a name shadowing a parent attribute/bind directive, aborts with a migration-task comment. Let directives accumulate snippet parameter strings and are queued for removal, flushed once a valid name is found (so queued removals do not happen when migration bails) or at the end; the slot attribute itself is removed. SvelteFragment with content is unwrapped keeping its children. Default-slot content is wrapped in `{#snippet children(props)}` around the non-named-slot inner nodes — interleaved default/named/default content is reordered by moving the trailing default chunk before the named slot's closing tag — with re-indentation excluded outside the wrapped range; named-slot or SvelteFragment cases wrap the node itself in a snippet, appending the closer via appendRight for SlotElement and appendLeft otherwise.

**Notes.**

- side_effect: Sets the module-level has_migration_task flag when emitting a migration-task comment.

uses: [is_text_attribute](r5-compiler-ast-utils.md#u-ec400088cae5), [is_reserved](r1-dom-dom-utils.md#u-990ab32bfe83)

**Uncertainties.**

- Interleaved default/named slot reordering assumes single-chunk moves; correctness for multiple interleavings is not evident from the source.

<a id="u-437d8a4fa38f"></a>
### `migrate_css`

`function migrate_css(state)` · [packages/svelte/src/compiler/migrate/index.js:L41-L96][f1]

Rewraps CSS pseudo-class selectors in :global() so migrated styles keep Svelte 4 scoping behavior.

It returns immediately when the CSS AST has no start offset. Because the CSS text was blanked to a placeholder in migrate(), it snips the CSS into a separate MagicString and scans a moving window: when remaining code starts with :has/:is/:where/:not it finds the argument's opening parenthesis; if a :global already directly follows (whitespace-only between), it marks the selector already global and skips wrapping; otherwise, if a previous :global exists earlier in the original CSS, it jumps past that :global's closing parenthesis and continues. For unscoped pseudo selectors other than :not it prepends ':global(' at the argument start and appends ')' before the argument's closing parenthesis. Non-matching characters advance the window by one. The transformed CSS is finally written back over the CSS AST range in state.str.

**Notes.**

- side_effect: Replaces the whole CSS AST range in state.str with the transformed text.
- condition: The computed end index is tested for truthiness, so an end of 0 aborts wrapping for that selector.

calls: [find_closing_parenthesis](r1-migrator.md#u-97593ff10930), [packages/svelte/src/compiler/migrate/index.js:migrate](r1-migrator.md#u-14a64e806c9a)

**Uncertainties.**

- A ':global' literal inside strings or comments within the CSS could confuse the window scan; the code has no guard for that.

<a id="u-cad9e2b4a6a0"></a>
### `trim_block`

`function trim_block(state, start, end)` · [packages/svelte/src/compiler/migrate/index.js:L1047-L1053][f1]

Normalizes brace-delimited template regions like `{@html …}`, `{$const …}`, and block headers by snipping the region, stripping the outer braces, and, when the inner text has surrounding whitespace, rewriting the interior (between start+1 and end-1) with the trimmed text in state.str.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/migrate/index.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/utils/ast.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/1-parse/state/element.js
