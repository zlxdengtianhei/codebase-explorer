# DOM & Rune Constant Predicates

**Capability.** Membership predicates over fixed tables: void/boolean/raw-text/SVG/MathML/load-error elements, attribute normalization and aliases, DOM properties vs. static-settable attributes, delegated/passive/capture events, reserved words, runes, and djb2 hashing.

Use these predicates instead of hardcoding element or event names. Each predicate is backed by an adjacent constant list; compiler and both runtimes depend on them.

**Depended on by.**

- [Accessibility Analysis](r1-a11y-analysis.md) · graph-confirmed · 1 edge(s)
- [Client Dev Diagnostics & HMR](r1-client-dev-tools.md) · graph-confirmed · 1 edge(s)
- [Mount, Hydrate & Unmount](r1-client-mounting.md) · graph-confirmed · 1 edge(s)
- [Shared Client Transform Builders](r1-client-shared-transform-utils.md) · graph-confirmed · 1 edge(s)
- [Template Serialization](r1-client-template.md) · graph-confirmed · 1 edge(s)
- [DOM Attributes & Properties](r1-dom-attributes.md) · graph-confirmed · 3 edge(s)
- [Svelte 4 Automigrator](r1-migrator.md) · graph-confirmed · 3 edge(s)
- [Server Transform Phase](r1-server-transform.md) · graph-confirmed · 7 edge(s) · SSR element builders use shared predicates like boolean-attribute and void-element checks when serializing markup.
- [SSR Rendering Helpers](r1-ssr-core.md) · graph-confirmed · 3 edge(s)

Parent: [Shared Utilities](r1-shared-utilities.md)

## Units (36)

<a id="u-7cb3adb5723d"></a>
### `utils.js module code (L1–L6)`

`module_region` · [packages/svelte/src/utils.js:L1-L6][f1]

Shared `regex_return_characters = /\r/g` used by `hash` to strip carriage returns before hashing.

uses: [hash](r1-dom-dom-utils.md#u-a8a8fa6d6333)

<a id="u-29199af756b1"></a>
### `utils.js module code (L14–L38)`

`module_region` · [packages/svelte/src/utils.js:L14-L38][f1]

VOID_ELEMENT_NAMES constant list backing `is_void`.

<a id="u-9c54e843c710"></a>
### `is_void`

`export function is_void(name)` · [packages/svelte/src/utils.js:L39-L41][f1]

Returns true if `name` is a void HTML element — membership in the fixed list (area, base, br, col, command, embed, hr, img, input, keygen, link, meta, param, source, track, wbr) — or the lowercase name equals `'!doctype'`.

Used by the parser (to avoid expecting closing tags), the migrator, and template/SSR transforms.

group: [hash](r1-dom-dom-utils.md#u-a8a8fa6d6333), [is_capture_event](r1-dom-dom-utils.md#u-612ef41e7040)

<a id="u-a8a8fa6d6333"></a>
### `hash`

`export function hash(str)` · [packages/svelte/src/utils.js:L7-L14][f1]

Computes a deterministic string hash of a string using the djb2 variant: strips carriage returns, seeds 5381, then iterates characters backwards applying `(hash << 5) - hash) ^ charCode`, returning the unsigned result in base 36.

Used by `{@html ...}` block integrity checks (client `check_hash` and server html block) to detect content mismatch.

group: [is_void](r1-dom-dom-utils.md#u-9c54e843c710), [is_reserved](r1-dom-dom-utils.md#u-990ab32bfe83)

**Uncertainties.**

- Collision behavior is inherent to djb2; the file does not state how consumers handle collisions.

<a id="u-5bf715f0e893"></a>
### `utils.js module code (L41–L97)`

`module_region` · [packages/svelte/src/utils.js:L41-L97][f1]

RESERVED_WORDS constant list backing `is_reserved`.

<a id="u-ab4a13a46714"></a>
### `packages/svelte/src/utils.js:utils.js module code (L100–L104)`

`module_region` · [packages/svelte/src/utils.js:L100-L104][f1]

Doc comment above `is_reserved`.

<a id="u-990ab32bfe83"></a>
### `is_reserved`

`export function is_reserved(word)` · [packages/svelte/src/utils.js:L98-L100][f1]

Returns true if `word` is in the RESERVED_WORDS list of JavaScript keywords (and `eval`, `arguments`); used by the parser when reading identifiers and by scope code when generating unique names so generated identifiers don't collide with reserved words.

**Uncertainties.**

- The list includes 'eval' and 'arguments', which are not reserved words in strict ES grammar terms but are treated as such here.

<a id="u-612ef41e7040"></a>
### `is_capture_event`

`export function is_capture_event(name)` · [packages/svelte/src/utils.js:L105-L107][f1]

Returns true if `name` ends with 'capture' and is not the DOM event names `gotpointercapture` or `lostpointercapture` — i.e. it denotes a Svelte `on:eventcapture` attribute rather than a literal event named `*capture`.

Used in attribute analysis, event transform, and runtime attribute setting to decide event naming.

group: [is_delegated](r1-dom-dom-utils.md#u-621eb4d7a691)

<a id="u-1c530161b1dc"></a>
### `utils.js module code (L107–L139)`

`module_region` · [packages/svelte/src/utils.js:L107-L139][f1]

DELEGATED_EVENTS constant list backing `is_delegated`.

<a id="u-621eb4d7a691"></a>
### `is_delegated`

`export function is_delegated(event_name)` · [packages/svelte/src/utils.js:L140-L142][f1]

Returns true if `event_name` is in DELEGATED_EVENTS, the fixed list of frequently fired Element events (click, input, key/mouse/pointer/touch events, focusin/focusout, beforeinput, change, dblclick, contextmenu) that Svelte handles via root-level delegation instead of per-element listeners.

<a id="u-cee5abc1adb8"></a>
### `utils.js module code (L142–L182)`

`module_region` · [packages/svelte/src/utils.js:L142-L182][f1]

Doc comment above `is_delegated`.

<a id="u-78fd7bc19c5e"></a>
### `utils.js module code (L185–L211)`

`module_region` · [packages/svelte/src/utils.js:L185-L211][f1]

DOM_BOOLEAN_ATTRIBUTES constant list backing `is_boolean_attribute`.

<a id="u-ced4c00b24a8"></a>
### `is_boolean_attribute`

`export function is_boolean_attribute(name)` · [packages/svelte/src/utils.js:L183-L185][f1]

Returns true if `name` is in DOM_BOOLEAN_ATTRIBUTES — attributes that are present-or-absent rather than valued (allowfullscreen, async, checked, disabled, hidden, etc.).

Consumed by client and server element transforms and by `spread_attributes` to render boolean attributes correctly.

uses: [normalize_attribute](r1-dom-dom-utils.md#u-88eb45828b22)

<a id="u-8cc4cba5cfa8"></a>
### `utils.js module code (L215–L237)`

`module_region` · [packages/svelte/src/utils.js:L215-L237][f1]

ATTRIBUTE_ALIASES record and doc comment backing `normalize_attribute`.

<a id="u-88eb45828b22"></a>
### `normalize_attribute`

`export function normalize_attribute(name)` · [packages/svelte/src/utils.js:L212-L215][f1]

Lowercases `name` and maps it through ATTRIBUTE_ALIASES to the correct DOM property spelling (e.g. `readonly` → `readOnly`, `srcobject` → `srcObject`, `novalidate` → `noValidate`); unaliased names pass through lowercased.

Deliberately excludes `class` → `className` because class is handled separately.

**Uncertainties.**

- Because the input is lowercased before alias lookup, mixed-case inputs match aliases only via their lowercase forms; the passthrough result is always lowercase when no alias applies.

<a id="u-ef4bbff99612"></a>
### `utils.js module code (L240–L248)`

`module_region` · [packages/svelte/src/utils.js:L240-L248][f1]

DOM_PROPERTIES list backing `is_dom_property`.

<a id="u-fc941845047d"></a>
### `is_dom_property`

`export function is_dom_property(name)` · [packages/svelte/src/utils.js:L238-L240][f1]

Returns true if `name` is in DOM_PROPERTIES — the boolean attribute list plus property-only names like `value`, `volume`, `defaultValue`, `defaultChecked`, `srcObject`, `readOnly`.

Used by the client element transform to decide whether an attribute must be set as a DOM property rather than an attribute.

<a id="u-e286a9f373db"></a>
### `utils.js module code (L251–L267)`

`module_region` · [packages/svelte/src/utils.js:L251-L267][f1]

NON_STATIC_PROPERTIES list and doc comment backing `cannot_be_set_statically`.

<a id="u-2389aaa6b031"></a>
### `cannot_be_set_statically`

`export function cannot_be_set_statically(name)` · [packages/svelte/src/utils.js:L249-L251][f1]

Returns true if `name` is in NON_STATIC_PROPERTIES (`autofocus`, `muted`, `defaultValue`, `defaultChecked`) — attributes that silently misbehave when set via the template string and therefore require JavaScript handling.

Used in attribute analysis and element transforms to force dynamic setting.

group: [is_dom_property](r1-dom-dom-utils.md#u-fc941845047d)

<a id="u-ce551cce6dcb"></a>
### `utils.js module code (L270–L274)`

`module_region` · [packages/svelte/src/utils.js:L270-L274][f1]

PASSIVE_EVENTS list and rationale comment backing `is_passive_event`.

<a id="u-d023bfe04bdf"></a>
### `is_passive_event`

`export function is_passive_event(name)` · [packages/svelte/src/utils.js:L268-L270][f1]

Returns true for `touchstart` and `touchmove`.

These are already passive by browser defaults on window/document/body, but because Svelte delegates them and they fire often on mobile, it marks them passive by default for all elements. Used by event transform and runtime event handling.

uses: [is_delegated](r1-dom-dom-utils.md#u-621eb4d7a691)

<a id="u-9b410b81a5c1"></a>
### `utils.js module code (L277–L294)`

`module_region` · [packages/svelte/src/utils.js:L277-L294][f1]

CONTENT_EDITABLE_BINDINGS list backing `is_content_editable_binding`.

<a id="u-e47baf4ced62"></a>
### `is_content_editable_binding`

`export function is_content_editable_binding(name)` · [packages/svelte/src/utils.js:L275-L277][f1]

Returns true if `name` is one of `textContent`, `innerHTML`, `innerText` — the bindings allowed on contenteditable elements.

Used in bind-directive analysis, a11y checks, and the server element transform.

<a id="u-119efe4db2b1"></a>
### `utils.js module code (L297–L388)`

`module_region` · [packages/svelte/src/utils.js:L297-L388][f1]

LOAD_ERROR_ELEMENTS and SVG_ELEMENTS constant lists backing `is_load_error_element` and `is_svg`.

<a id="u-4cd6bb51d97b"></a>
### `is_load_error_element`

`export function is_load_error_element(name)` · [packages/svelte/src/utils.js:L295-L297][f1]

Returns true if the element name is one of body, embed, iframe, img, link, object, script, style, track — the elements that fire `load` and `error` events.

Used in client and server element transforms to handle `on:load`/`on:error` attributes appropriately.

<a id="u-890d02cea75e"></a>
### `is_svg`

`export function is_svg(name)` · [packages/svelte/src/utils.js:L389-L391][f1]

Returns true if `name` is in the SVG_ELEMENTS list (all standard SVG element names including legacy `altGlyph` family, filters, fonts, and `color-profile`).

Used during analysis, migration, and transforms to select the SVG namespace and correct casing/creation strategy.

group: [is_mathml](r1-dom-dom-utils.md#u-7f1edff0d5fa)

<a id="u-8444774d23e8"></a>
### `utils.js module code (L391–L426)`

`module_region` · [packages/svelte/src/utils.js:L391-L426][f1]

MATHML_ELEMENTS constant list backing `is_mathml`.

<a id="u-7f1edff0d5fa"></a>
### `is_mathml`

`export function is_mathml(name)` · [packages/svelte/src/utils.js:L427-L429][f1]

Returns true if `name` is in MATHML_ELEMENTS (math, mrow, mi, mo, semantics, etc.), selecting the MathML namespace during element analysis.

Parallel to `is_svg`; an element is expected to belong to at most one namespace list.

<a id="u-70ba395a662c"></a>
### `utils.js module code (L429–L460)`

`module_region` · [packages/svelte/src/utils.js:L429-L460][f1]

STATE_CREATION_RUNES and RUNES constant lists backing `is_rune` and `is_state_creation_rune`, plus the RuneName typedefs.

<a id="u-958c0fd951c4"></a>
### `utils.js module code (L463–L470)`

`module_region` · [packages/svelte/src/utils.js:L463-L470][f1]

StateCreationRuneName typedef and doc comments above `is_state_creation_rune`.

<a id="u-ad49595ea2ed"></a>
### `is_rune`

`export function is_rune(name)` · [packages/svelte/src/utils.js:L461-L463][f1]

Type-guard returning true if `name` is in RUNES — the full rune name list built from STATE_CREATION_RUNES plus `$state.snapshot`, `$props`, `$props.id`, `$bindable`, `$effect` and its sub-runes, `$inspect`/`$inspect().with`/`$inspect.trace`, and `$host`.

Used throughout analysis to detect and validate rune usage.

uses: [is_state_creation_rune](r1-dom-dom-utils.md#u-c23d56cebfa4)

<a id="u-c23d56cebfa4"></a>
### `is_state_creation_rune`

`export function is_state_creation_rune(name)` · [packages/svelte/src/utils.js:L471-L473][f1]

Type-guard returning true if `name` is one of `$state`, `$state.raw`, `$derived`, `$derived.by` — the runes that create reactive state.

Used e.g. by class-body analysis to handle state initialization in fields.

<a id="u-7445abefc4db"></a>
### `utils.js module code (L473–L478)`

`module_region` · [packages/svelte/src/utils.js:L473-L478][f1]

RAW_TEXT_ELEMENTS list and doc comment backing `is_raw_text_element`.

<a id="u-8ee9370d0cd9"></a>
### `is_raw_text_element`

`export function is_raw_text_element(name)` · [packages/svelte/src/utils.js:L479-L481][f1]

Returns true for `textarea`, `script`, `style`, `title` — elements whose content is raw text, so SSR hydration comments must not be placed inside them.

Used by the client `element` block and the server element renderer.

<a id="u-b777f9ca7d07"></a>
### `utils.js module code (L481–L488)`

`module_region` · [packages/svelte/src/utils.js:L481-L488][f1]

Doc comment above `sanitize_location`.

<a id="u-eb8e19f29107"></a>
### `sanitize_location`

`export function sanitize_location(location)` · [packages/svelte/src/utils.js:L489-L491][f1]

Inserts a zero-width space (`\u200b`) after every `/` in a file `location` string so devtools do not render it as a clickable link.

Generic over `T extends string | undefined`: when `location` is undefined, `location?.replace(...)` short-circuits and undefined passes through unchanged.

**Uncertainties.**

- The JSDoc claims the return type is T, but the implementation always returns a string for string input; the cast is unchecked.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/utils.js
