# Error Handling & Boundaries

**Capability.** Central effect-error handling: enriches errors with component stacks in dev, applies cached message/stack adjustments, and invokes the nearest boundary effect upward through the effect tree.

Use this to follow what happens when an effect throws. handle_error is the entry; invoke_error_boundary walks up until a Boundary handles it or the error is rethrown.

**Depended on by.**

- [Boundary & Async Blocks](r1-boundary-blocks.md) · graph-confirmed · 3 edge(s) · Boundaries register with the error-handling machinery so effect errors are routed to the nearest boundary.

Parent: [Client Runtime](r1-runtime-client.md)

## Units (4)

<a id="u-1b3b4fa2c18e"></a>
### `handle_error`

`export function handle_error(error)` · [packages/svelte/src/internal/client/error-handling.js:L15-L44][f1]

Central handler for errors raised inside effects.

With no active effect, it sets ERROR_VALUE on the active reaction's flags (deferring the throw until an unowned derived is read) and returns the error. Otherwise, in DEV it computes message/stack adjustments once per Error. When the effect has not yet run (error during subtree creation): a non-boundary effect rethrows — applying adjustments only when it has no parent — while a boundary effect delegates to its Boundary.error. When the effect already ran, it calls invoke_error_boundary to walk the effect tree instead.

calls: [invoke_error_boundary](r1-error-propagation.md#u-8ed809bdafb5), [get_adjustments](r1-error-propagation.md#u-d2e928a5c137)

**Uncertainties.**

- Whether effect.b.error throwing inside the not-yet-run branch propagates as-is is not shown here

<a id="u-8ed809bdafb5"></a>
### `invoke_error_boundary`

`export function invoke_error_boundary(error, effect)` · [packages/svelte/src/internal/client/error-handling.js:L50-L69][f1]

Walks the effect tree upward looking for a boundary effect; each Boundary.error found is invoked inside a try, and if it throws, the thrown value replaces the current error and the walk continues.

If no boundary handles the error, DEV-computed adjustments are applied to Error instances and the error is thrown to the caller.

calls: [apply_adjustments](r1-error-propagation.md#u-1f031c007120)

<a id="u-d2e928a5c137"></a>
### `get_adjustments`

`function get_adjustments(error, effect)` · [packages/svelte/src/internal/client/error-handling.js:L76-L99][f1]

Builds development-only enrichment for an error: a component stack listing the effect function name and each ancestor context's filename, and a stack string with internal svelte frames filtered out.

Returns undefined when the error's `message` property is non-configurable, since overwriting it would throw a new error and swallow the original.

**Uncertainties.**

- Assumes effect.ctx follows the ComponentContext shape including `function` and parent `p`

<a id="u-1f031c007120"></a>
### `apply_adjustments`

`function apply_adjustments(error)` · [packages/svelte/src/internal/client/error-handling.js:L104-L116][f1]

Looks up previously computed adjustments for an Error in the module-level WeakMap and, if present, overwrites its `message` and `stack` properties via define_property.

No-op when no adjustments were recorded (e.g. non-DEV or non-configurable message).

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/error-handling.js
