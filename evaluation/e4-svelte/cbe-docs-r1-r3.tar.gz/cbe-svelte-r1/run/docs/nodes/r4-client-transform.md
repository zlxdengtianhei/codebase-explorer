# Client Transform

**Capability.** Generates the client-side component program: registers the client visitor map, rewrites state/rune reads through getters and proxies, hoists flagged functions with captured parameters, and serializes elements including attribute updates, class/style directives, custom-element handling, and select synchronization.

The transform-client group is the entry; client_component/client_module produce whole programs. The utils units define how state and props become signals (build_getter, is_state_source, should_proxy, prop sources, hoisted params). The visitors show per-node codegen, with RegularElement units covering the richest attribute/directive serialization.

**Depends on.**

- [Compiler Semantic Model](r4-compiler-model.md) · graph-confirmed · 5 edge(s)
- [Compiler Utilities](r4-compiler-utils.md) · model-inferred · 0 edge(s)
- [Client Transform](r3-compiler-transform-client.md) · graph-only · 10 edge(s)
- [Shared AST Utilities](r5-compiler-ast-utils.md) · graph-only · 9 edge(s)

**Depended on by.**

- [Transform Entry](r4-transform-entry.md) · graph-confirmed · 2 edge(s)
- [Client Transform Visitors](r5-client-transform-visitors.md) · graph-only · 12 edge(s)

Parent: [Transformation](r4-transform-phase.md)

## Units (23)

<a id="u-61e7277a11cb"></a>
### `transform-client.js-visitors-and-entry`

`export function client_component(analysis, options)` · [packages/svelte/src/compiler/phases/3-transform/client/transform-client.js:L148-L698][f1]

Registers the client-side visitor map and drives component and module code generation for the client transform phase.

The visitor table maps node types to visitors plus a synthetic scope handler that, when a node has its own scope distinct from the current one, deletes transform entries for `normal` bindings and for `state` bindings that are not state sources (per `is_state_source`) and continues with a narrowed transform record; otherwise it just descends. `client_component` walks the module, instance, and template ASTs in sequence, then assembles a function declaration whose body interleaves store setup, legacy reactive statements, exports/accessors, async vs sync bodies, props/slots/rest-props sanitization, CSS injection, HMR hooks, custom-element wrapping, and flag imports.

**Notes.**

- side_effect: state.legacy_reactive_statements, state.events, state.hoisted, and snippet arrays are mutated by visitors during the walks and consumed afterward when assembling the output body.
- condition: analysis.instance.has_await routes the instance body through $.async_body with an abort check ($.aborted) before template statements; the sync path instead runs $.init for non-runes components needing context.
- failure: A reactive statement present in analysis.reactive_statements but missing from state.legacy_reactive_statements throws new Error('Could not find reactive statement').
- contract: The returned Program places imports first (imports extracted from module body plus hoisted entries, order preserved), then module-level snippets, then remaining statements, ending with the component as default export.

calls: [render_stylesheet](r5-css-transform.md#u-197b2d45aa0c), [build_getter](r4-client-transform.md#u-66a19e20e1f1)

**Uncertainties.**

- The full behavior of each imported visitor (Fragment, Program, etc.) is outside this file; only their presence in the table and the described state fields they populate are observable here.

<a id="u-15bd8cef14fb"></a>
### `client_component`

`export function client_component(analysis, options)` · [packages/svelte/src/compiler/phases/3-transform/client/transform-client.js:L148-L698][f1]

Compiles a component analysis into an ESTree.Program containing the client component function.

It initializes ComponentClientTransformState with module scope and a hoisted `import * as $ from 'svelte/internal/client'`, walks module/instance/template ASTs (the instance walk shares the accumulated transform map, and the template walk reuses instance scope). It then emits: legacy reactive declarations and store subscription thunks ($.store_get, with $.validate_store in dev), reactive statements followed by $.legacy_pre_effect_reset, binding-group arrays, a returned object of getters/setters built per binding kind (let/var get $$value assignment setters; props get setter calling the setter function; state gets $.set with $.proxy wrapping for `state` kind), accessors when analysis.accessors (with runes-mode default via binding.initial), legacy $set/$on for componentApi 4 or a $.legacy_api spread in dev. Async components wrap body in $.async_body with an $.aborted check; sync components unshift store setup and push template body. Conditional injections include $.push/$.pop framing, ownership validator, rest/sanitized props, $$slots, CSS via render_stylesheet, bind_prop for non-runes exports, HMR accept handler, custom-element creation with $.create_custom_element (defining the tag unless HMR, which guards on customElements.get), dev FILENAME marker, and flag imports (async/legacy/tracing/disclose-version). Returns {type:'Program', sourceType:'module', body}.

**Uncertainties.**

- Iterator `next` calls resolved to multiple candidates in graph evidence; loop mechanics are standard AST iteration, but no single callee can be named from this source.

<a id="u-1e0775efa9e3"></a>
### `client_module`

`export function client_module(analysis, options)` · [packages/svelte/src/compiler/phases/3-transform/client/transform-client.js:L705-L734][f1]

Compiles a `<script module>` analysis into an ESTree.Program.

It builds a minimal ClientTransformState (module scope, empty transform map, no instance flag), walks the module AST with the shared visitors, and returns a program whose body is `import * as $ from 'svelte/internal/client'`, optionally a tracing flag import when analysis.tracing, followed by the transformed module body. No instance/template handling or component wrapper is produced.

<a id="u-66a19e20e1f1"></a>
### `build_getter`

`export function build_getter(node, state)` · [packages/svelte/src/compiler/phases/3-transform/client/utils.js:L36-L47][f2]

Rewrites an identifier reference using the state's transform table.

If the table has an entry for the name and the node is not the binding's own declaration node, the binding's `read` hook produces the replacement expression; otherwise the identifier is returned unchanged. This deliberately leaves the declaration site of a transformed variable untouched.

**Uncertainties.**

- The `read` hook implementations live in the visitors that populate state.transform; their output shape cannot be verified here (graph lists many candidates).

<a id="u-a89fb605f1f4"></a>
### `build_hoisted_params`

`export function build_hoisted_params(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/utils.js:L146-L166][f2]

Builds and records the final parameter list for a hoisted function.

It calls get_hoisted_params, stores the result on node.metadata.hoisted_params, then prepends either the original visited params or, when the function has none but hoisted params exist, a generated `_` identifier for the event object; appends the hoisted params and returns them.

calls: [get_hoisted_params](r4-client-transform.md#u-7185711d9b41)

<a id="u-d8c62e2be238"></a>
### `create_derived`

`export function create_derived(state, expression, async = false)` · [packages/svelte/src/compiler/phases/3-transform/client/utils.js:L295-L303][f2]

Wraps an expression as a derived signal creation call.

It builds a thunk (async-capable when the `async` flag is set). For async, it emits `await $.save($.async_derived(thunk))`; otherwise it emits `$.derived(thunk)` in runes mode or `$.derived_safe_equal(thunk)` in legacy mode, reflecting that legacy mode should use safe equals in most places.

<a id="u-7185711d9b41"></a>
### `get_hoisted_params`

`function get_hoisted_params(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/utils.js:L54-L64][f2]

Computes the extra parameters a hoisted function needs to capture component-scope references.

For each external reference in the current scope (not declared locally, not the function's own initial): store subscriptions add both the store and its underlying variable; a destructured derived whose read yields `$.get(x)` contributes `x`; non-source props/bindable props contribute `$$props`; imports are skipped; anything else contributes the binding name, with `$$props` additionally added for rest_props in runes mode. push_unique dedupes by name. In dev, a walk over assignments/updates pushes `$$ownership_validator` when validate_mutation indicates the mutation needs validation, stopping the walk after the first hit.

**Notes.**

- condition: binding.initial !== node excludes references where the hoisted function is itself the initializer, preventing self-parameterization.

calls: [validate_mutation](r1-client-shared-transform-utils.md#u-a58215b09609)

**Uncertainties.**

- validate_mutation's comparison contract (returning node when no rewrite needed) is assumed from the surrounding check, not proven in this file.

<a id="u-d03f333899de"></a>
### `get_prop_source`

`export function get_prop_source(binding, state, name, initial)` · [packages/svelte/src/compiler/phases/3-transform/client/utils.js:L175-L230][f2]

Builds the `$.prop(...)` call that creates a reactive prop source.

Flags accumulate: BINDABLE for bindable_prop kind, IMMUTABLE when the analysis is immutable, RUNES in runes mode, and UPDATED when accessors are present or, under immutability, the binding was reassigned or (in runes) mutated, otherwise when it was updated. An optional initial value is passed lazily: simple expressions go through unchanged (is_simple_expression), zero-argument call expressions pass their callee, and anything else is wrapped in a thunk with the LAZY_INITIAL flag. Flag/initial arguments are only appended when non-zero/present.

calls: [is_simple_expression](r5-compiler-ast-utils.md#u-410082960042)

**Uncertainties.**

- is_simple_expression's exact definition is outside this file; the lazy vs eager split depends on it.

<a id="u-38b8a75ee741"></a>
### `is_prop_source`

`export function is_prop_source(binding, state)` · [packages/svelte/src/compiler/phases/3-transform/client/utils.js:L238-L249][f2]

Decides whether a prop/bindable_prop binding needs a `$.prop` signal source rather than a plain $$props property read.

True whenever not in runes mode, or when accessors exist, or the binding was reassigned, has an initial value, or was updated (the updated case exists because a legacy parent may need coarse-grained reactivity).

<a id="u-4eba3d9b7ec5"></a>
### `is_state_source`

`export function is_state_source(binding, analysis)` · [packages/svelte/src/compiler/phases/3-transform/client/utils.js:L24-L29][f2]

Reports whether a `state`/`raw_state` binding must be rewritten on read.

True only when the kind is state or raw_state and, for immutable-mode analyses, the binding was reassigned or the analysis has accessors; in mutable mode all state bindings qualify.

<a id="u-d089d4da67c8"></a>
### `should_proxy`

`export function should_proxy(node, scope)` · [packages/svelte/src/compiler/phases/3-transform/client/utils.js:L255-L287][f2]

Recursively decides whether a state initializer value needs a reactivity proxy.

Returns false for falsy nodes, literals, template literals, arrow/function expressions, unary/binary expressions, and the identifier `undefined`. For a plain identifier with a scope, it resolves the binding and, when the binding is never reassigned and has a non-function/class/import/EachBlock/SnippetBlock initializer, recurses on that initializer with scope null; all other expressions return true (proxy).

**Uncertainties.**

- The recursion passes scope=null, so a chained identifier inside an initializer's initializer cannot resolve bindings and defaults to true.

<a id="u-affe00ad1f18"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/BreakStatement.js:BreakStatement`

`export function BreakStatement(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/BreakStatement.js:L9-L20][f3]

Strips `break $` used to end legacy reactive statements.

It returns undefined (leaving the statement intact) when the component uses runes, when there is no label, or when the label is not '$'. Otherwise, if the enclosing statement at path position 1 is the labeled statement '$', it returns an empty return statement, removing the break.

**Uncertainties.**

- Non-'$'-labeled breaks in non-runes mode reach no branch here, so behavior falls to the visitor framework, not visible in this file.

<a id="u-a7da2a1bef1e"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/CallExpression.js:CallExpression`

`export function CallExpression(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/CallExpression.js:L13-L102][f4]

Transforms call expressions, dispatching runes to their runtime implementations before default traversal.

get_rune classifies the call: $host becomes `$$props.$$host`; $effect.tracking becomes $.effect_tracking(); $state / $state.raw visit their first argument (if present) into $.state(value), wrapping the value in $.proxy for non-raw $state when should_proxy says the value needs a proxy; $derived visits its function argument with in_derived set only for the non-`.by` form and emits $.derived(thunk-or-fn); $state.snapshot becomes $.snapshot(value) passing b.true when 'state_snapshot_uncloneable' is not ignored; $effect.root becomes $.effect_root(...visited args); $effect.pending becomes $.pending(); $inspect and $inspect().with delegate to transform_inspect_rune. Unmatched calls: in dev, when the callee is `console.<method>` (method among debug/dir/error/group/groupCollapsed/info/log/trace/warn), `console` is not shadowed by a local binding, and at least one argument is a SpreadElement or evaluates to something with unknown state, the call is rewritten to spread `$.log_if_contains_state(methodName, ...args)` over the original callee. All other calls fall through to context.next().

**Notes.**

- condition: The console rewrite requires context.state.scope.get('console') === null, so a local `console` binding suppresses it.

calls: [get_rune](r4-compiler-model.md#u-5204b6ce4f7a), [transform_inspect_rune](r3-compiler-transform-utils.md#u-f64464c8fc01), [should_proxy](r4-client-transform.md#u-d089d4da67c8), [is_ignored](r5-compiler-state-errors.md#u-468324b42cee)

<a id="u-9d7a76679f62"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/FunctionDeclaration.js:FunctionDeclaration`

`export function FunctionDeclaration(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/FunctionDeclaration.js:L10-L23][f5]

Transforms function declarations, hoisting ones flagged by metadata.

State is copied with in_constructor and in_derived cleared. If node.metadata.hoisted is true, params come from build_hoisted_params, the body is visited with that state, and the whole declaration is pushed to context.state.hoisted while b.empty replaces it inline; otherwise context.next(state) handles it in place.

calls: [build_hoisted_params](r4-client-transform.md#u-a89fb605f1f4)

<a id="u-f48625ba1690"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/HtmlTag.js:HtmlTag`

`export function HtmlTag(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/HtmlTag.js:L11-L47][f6]

Serializes an {@html} tag into a $.html render call, switching to an async path when the expression awaits.

It pushes a template comment, builds the expression, and reads svg/mathml namespace flags from state.metadata. When the expression has no await it pushes a $.html(node, thunk(expression), svgFlag, mathmlFlag, hydrationIgnoreFlag) statement directly to init. When has_await is set the synchronous thunk reads `$.get($$html)` and init instead receives a $.async(node, [thunk(expression, true)], arrow) whose callback rebuilds the $.html statement with `$$html` bound; the code comments that placing this in init keeps bindings running afterwards so a re-run can override hydration. The hydration flag comes from is_ignored(node, 'hydration_html_changed').

calls: [build_expression](r1-client-shared-transform-utils.md#u-cd5eb51d389f), [is_ignored](r5-compiler-state-errors.md#u-468324b42cee)

<a id="u-f91f27df0412"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/LetDirective.js:LetDirective`

`export function LetDirective(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/LetDirective.js:L11-L51][f7]

Serializes let: directives into derived slot-property bindings.

When the directive has an expression that is not an Identifier (object/array destructuring), it generates an alias name, looks up the bindings via scope.get_bindings, and returns a const declaring $.derived over a thunk that destructures `$$slotProps.<name>` with an object or array pattern (chosen by the expression's type) and returns an object of the bound names; each binding's transform reads `$.get(alias).<name>`. Otherwise (Identifier expression or no expression) the binding name is the expression's name or the directive name, the transform reads `$.get(node)`, and the directive returns a const of create_derived over `$$slotProps.<name>`.

**Notes.**

- side_effect: Both paths mutate context.state.transform so later reads of the bound names compile to the derived reads.

calls: [create_derived](r4-client-transform.md#u-d8c62e2be238)

**Uncertainties.**

- The destructuring branch relies on ts-expect-error casts asserting the expression cannot contain spread elements; this is not enforced in this file.

<a id="u-f2ea5a46376e"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/RegularElement.js:RegularElement`

`export function RegularElement(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/RegularElement.js:L32-L404][f8]

Transforms a regular element into template-construction code.

It pushes the element onto the template (popping and returning immediately for `noscript`), flags the template to need importNode for video/custom elements (cloneNode would not instantiate custom element classes; Webkit needs it for video autoplay), and flags contains_script_tag for `script`. Attributes are partitioned into attributes/class/style/other directive lists, a name lookup map, and a bindings map; `let:` directives are visited first into `lets`. Event directives in other_directives are visited; with any `use:` directive the handler becomes `$.effect(thunk(handler))` in init, otherwise a plain statement in after_update. For `input` elements with spread or value/checked/group bindings (and no defaultValue attribute, with non-text value), it emits `$.remove_input_defaults`; similarly `textarea` emits `$.remove_textarea_child`; `select` with bind:value calls setup_select_synchronization. Without spread, each attribute is dispatched: event attributes to visit_event_attribute; `value` skipped when special value handling applies; static settable values (non-custom-element, not class/style-conflicting) go into the template as props, with the CSS hash appended to static `class` on scoped nodes; `autofocus` emits `$.autofocus` in init; `class` and `style` go to build_set_class/build_set_style; custom elements go to build_custom_element_attribute_update_assignment; otherwise build_element_attribute_update is pushed to update (dynamic) or init. With spread, attributes/class/style are handled by build_attribute_effect. Load/error elements with event handling get `$.replay_events`. Children are cleaned via clean_nodes; an all-static-text element sets textContent once (skipping empty strings), otherwise children are processed with `$.child` calls, with hydrate_node reset after non-text content and `template` content handled via `$.hydrate_template`. If the fragment contains snippet blocks the child statements are wrapped in a block to avoid declaration conflicts; otherwise init/update/after_update lists are merged, element_state appended. A `dir` attribute triggers a self-reassignment update for Chromium's `dir=auto` text bug; and without spread, special value handling serializes the first `value` attribute via build_element_special_value_attribute. Finally the element is popped from the template.

calls: [setup_select_synchronization](r4-client-transform.md#u-97c8dc804a3c), [build_attribute_effect](r3-compiler-transform-client.md#u-0abd8487f7a1), [visit_event_attribute](r2-transform-client.md#u-8ff2bf148b08), [build_set_class](r3-compiler-transform-client.md#u-d08767f6fc10), [build_set_style](r3-compiler-transform-client.md#u-b481933571c2), [build_custom_element_attribute_update_assignment](r4-client-transform.md#u-4cdf2f9f4041), [build_element_attribute_update](r4-client-transform.md#u-b303d9b490e9), [build_element_special_value_attribute](r4-client-transform.md#u-d69720843218), [clean_nodes](r3-compiler-transform-utils.md#u-2ed26069223c), [determine_namespace_for_children](r3-compiler-transform-utils.md#u-fca641f4927b), [process_children](r1-client-shared-transform-utils.md#u-7091653bb501), [build_template_chunk](r1-client-shared-transform-utils.md#u-d8d503fc4b7b), [build_render_statement](r1-client-shared-transform-utils.md#u-b84b76b77b0e), [is_custom_element_node](r4-compiler-model.md#u-ea1f0b51e1e8)

**Uncertainties.**

- Exact shape of template push/pop_element and set_prop output is defined in the template class, not shown.
- Interaction ordering between element_state and child_state statements relies on context.visit semantics not visible here.

<a id="u-93d4778b5497"></a>
### `build_class_directives_object`

`export function build_class_directives_object( class_directives, context, memoizer = …` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/RegularElement.js:L468-L487][f8]

Builds an object expression from class: directives, visiting each directive expression into an `{name: value}` property.

Tracks whether any directive expression has a call or state or an await. If so (or awaited), the object is registered with the Memoizer (memoizer defaults to context.state.memoizer) so a stable, possibly async-aware reference is returned; otherwise the plain object expression is returned.

calls: [Memoizer](r1-client-shared-transform-utils.md#u-76b08484949a)

<a id="u-4cdf2f9f4041"></a>
### `build_custom_element_attribute_update_assignment`

`function build_custom_element_attribute_update_assignment(node_id, attribute, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/RegularElement.js:L613-L624][f8]

Serializes an attribute on a custom element as `$.set_custom_element_data(node, name, value)`, preserving the attribute name's case because the runtime may set a case-sensitive property.

The value is built via build_attribute_value; if it is stateful the call is wrapped in `$.template_effect(thunk)`. The statement is always pushed to init and never grouped with other updates because set_custom_element_data may not be idempotent.

calls: [build_attribute_value](r3-compiler-transform-client.md#u-2462157783c9)

<a id="u-b303d9b490e9"></a>
### `build_element_attribute_update`

`function build_element_attribute_update(element, node_id, name, value, attributes)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/RegularElement.js:L552-L605][f8]

Serializes one attribute assignment/update expression for a non-spread element, choosing the runtime call by attribute name: `muted` becomes a direct `node.muted = value` property assignment (Firefox requires property assignment); `value`, `checked`, and `selected` become `$.set_value`/`$.set_checked`/`$.set_selected`.

`defaultValue` becomes `$.set_default_value` only when a static text `value` attribute exists or it is a non-empty textarea (otherwise falling through), to avoid overwriting current value; `defaultChecked` similarly requires a static boolean `checked` attribute and becomes `$.set_default_checked`. DOM properties (is_dom_property) are plain member assignments; everything else becomes `$.set_xlink_attribute` for names starting with `xlink`, otherwise `$.set_attribute`, passing a `true` flag when hydration_attribute_changed errors are ignored. The caller decides whether the resulting statement goes to init or update based on has_state from build_attribute_value.

uses: [is_ignored](r5-compiler-state-errors.md#u-468324b42cee), [is_text_attribute](r5-compiler-ast-utils.md#u-ec400088cae5), [is_dom_property](r1-dom-dom-utils.md#u-fc941845047d)

<a id="u-d69720843218"></a>
### `build_element_special_value_attribute`

`function build_element_special_value_attribute(element, node_id, attribute, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/RegularElement.js:L635-L685][f8]

Serializes the hidden `__value` property for option/select/input value handling.

For a select with a dynamic (non-static-text) value attribute, the update also calls `$.select_option` to force DOM-side application since select values are not reflected as attributes. The value expression is built with memoization for calls/awaits and scope-evaluated; the inner assignment sets `node.value` to `node.__value = value`, falling back to '' via `??` when the value is not statically defined. If the value is stateful, a fresh `node_id_value` variable initialized to `{}` for `option` (guaranteeing the first `!==` comparison succeeds, mapping undefined to '') guards an update-time conditional assignment; otherwise the statement goes straight to init. For select-with-value, `$.init_select` is additionally pushed to init.

calls: [build_attribute_value](r3-compiler-transform-client.md#u-2462157783c9), [Memoizer](r1-client-shared-transform-utils.md#u-76b08484949a); uses: [is_text_attribute](r5-compiler-ast-utils.md#u-ec400088cae5)

**Uncertainties.**

- scope.evaluate(value) semantics (is_defined) are defined in scope.js and not shown.

<a id="u-29f008b00f20"></a>
### `build_style_directives_object`

`export function build_style_directives_object( style_directives, context, memoizer = …` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/RegularElement.js:L495-L522][f8]

Builds style: directive data as a `normal` object plus an `important` object; directives carrying the `important` modifier go into the second object.

A directive whose value is `true` resolves its expression via build_getter on the directive name (reading a state variable), otherwise via build_attribute_value. If any important-style directive exists, the result is `[normal, important]`, else just `normal`. When any expression has a call/state or await, the result is memoized via Memoizer.add (memoizer defaults to context.state.memoizer); otherwise returned directly.

calls: [build_getter](r4-client-transform.md#u-66a19e20e1f1), [Memoizer](r1-client-shared-transform-utils.md#u-76b08484949a)

<a id="u-97c8dc804a3c"></a>
### `setup_select_synchronization`

`function setup_select_synchronization(value_binding, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/RegularElement.js:L412-L460][f8]

Sets up synchronization between a select's bind:value and inner option signals.

It returns immediately in non-runes mode or when the bound expression is a SequenceExpression. The bound expression is reduced to its root object by unwrapping MemberExpressions; scope references (excluding the bound name itself to avoid infinite invalidation) are collected and serialized via build_getter into an `$.invalidate_inner_signals` thunk. A `$.template_effect` statement visiting the bound expression followed by the invalidator is pushed to init, so indirect option changes propagate to the bound value.

calls: [build_getter](r4-client-transform.md#u-66a19e20e1f1)

**Uncertainties.**

- Why references whose name equals the unwrapped bound root are safe to exclude beyond the stated loop-prevention comment is not proven here.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/transform-client.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/utils.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/BreakStatement.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/CallExpression.js
[f5]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/FunctionDeclaration.js
[f6]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/HtmlTag.js
[f7]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/LetDirective.js
[f8]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/RegularElement.js
