# DOM Attributes & Properties

**Capability.** Sets attributes, properties and special cases (value, checked, custom elements, xlink) with hydration awareness, caching and change detection, and runs the reactive attribute-spreading effect.

Use this for how compiled attribute assignments reach the DOM. set_attribute is the core; per-case setters handle defaults without disturbing live state; attribute_effect keeps spread attributes reactive.

**Depends on.**

- [DOM & Rune Constant Predicates](r1-dom-dom-utils.md) · graph-confirmed · 3 edge(s)
- [Hydration Cursor State](r1-hydration-cursor.md) · graph-confirmed · 4 edge(s) · Attribute setters consult hydration state to avoid clobbering values during hydration.

Parent: [Client Runtime](r1-runtime-client.md)

## Units (14)

<a id="u-e75ddf9d4835"></a>
### `attributes.js-set-attributes`

`export function set_attributes(element, prev, next, css_hash, skip_warning = false)` · [packages/svelte/src/internal/client/dom/elements/attributes.js:L274-L388][f1]

Spreads a next attributes object onto an element, mutating next and returning it as the current-state record.

Missing prev keys are set to null in next so removals happen. While hydrating a Svelte custom element, hydrating is temporarily disabled and restored at the end. class is normalized via clsx, or forced to null (triggering set_class) when a css_hash or the CLASS symbol is present; the STYLE symbol forces a set_style path. Per-key behavior: option value null/undefined sets element.value/__value to '' (an accepted edge case: an explicit null value cannot later be removed); class and style delegate to set_class/set_style and record the CLASS/STYLE symbols; unchanged values are skipped unless undefined while the attribute is still present; '$$'-prefixed keys are skipped; 'on'-prefixed keys configure events — capture-suffixed names get capture opts, delegated events store the handler on element['__event'] and call delegate, non-delegated same-event handler changes keep the old listener alive through the handle closure (avoiding swallowed events) and null removes it; style goes through set_attribute to avoid the setter; autofocus uses autofocus(); __value and value (non-custom-element, non-null) set element.value/__value; selected on option uses set_selected. In the default branch the name is normalized (lowercased) unless the element is not HTML; nullish values remove the attribute — for value/checked the removal also clears defaultValue/defaultChecked, so those are preserved and the live property set to the previous default on initial spread (prev undefined) or null/false otherwise; defaultValue/defaultChecked or setter-listed non-string values (any value on custom elements) are assigned as properties and the cached attribute is marked UNINITIALIZED; other non-function values go through set_attribute.

calls: [set_class](r4-dom-elements.md#u-085f1a439acb), [style.js-styles](r3-runtime-dom-elements.md#u-e45a1c8437a1), [events-js-create-event](r4-dom-elements.md#u-86f4f61fbc7c), [delegate](r4-dom-elements.md#u-cf26b665744a), [autofocus](r3-runtime-dom-elements.md#u-7f00a79795f4), [set_selected](r1-dom-attributes.md#u-1e6158ce232f), [set_attribute](r1-dom-attributes.md#u-475e532b1c41), [get_setters](r1-dom-attributes.md#u-0d26f84d109d), [get_attributes](r1-dom-attributes.md#u-fd27450a93d7), [hydration.js-state-and-guards](r1-hydration-cursor.md#u-f1b7a30a3c1f), [clsx](r4-shared-runtime.md#u-2274c46486ff), [is_delegated](r1-dom-dom-utils.md#u-621eb4d7a691), [is_capture_event](r1-dom-dom-utils.md#u-612ef41e7040), [normalize_attribute](r1-dom-dom-utils.md#u-88eb45828b22)

**Uncertainties.**

- For function values in the default branch the code falls through without writing anything, leaving the prior attribute in place — inferred from the typeof value !== 'function' guard.
- The interaction between the null-removal branch and attributes marked UNINITIALIZED for later set_attribute calls is not fully verifiable from this file.

<a id="u-5ab20d9a7208"></a>
### `attributes.js-remove-input-defaults`

`export function remove_input_defaults(input)` · [packages/svelte/src/internal/client/dom/elements/attributes.js:L39-L48][f1]

Defers clearing input value/checked default attributes after hydration so form resets cannot restore stale template values.

It no-ops when not hydrating. The remove_defaults closure is idempotent via already_removed: it snapshots input.value/checked, removes the attributes through set_attribute, then restores the properties. The closure is stored as input.__on_r (invoked by the global form-reset listener) and queued as an idle task; add_form_reset_listener() registers the document-level listener.

calls: [set_attribute](r1-dom-attributes.md#u-475e532b1c41), [add_form_reset_listener](r3-runtime-dom-elements.md#u-3524dfa24535), [task.js-queues](r4-task-scheduling.md#u-2af0814cc5ec)

**Uncertainties.**

- The ordering guarantee between the idle callback and an earlier reset event depends on queue_idle_task semantics defined outside this file.

<a id="u-8d5e16577b56"></a>
### `attributes.js-src-url-equality`

`function check_src_in_dev_hydration(element, attribute, value)` · [packages/svelte/src/internal/client/dom/elements/attributes.js:L580-L590][f1]

Hydration-time source URL comparison helpers used by the dev warning in set_attribute.

check_src_in_dev_hydration returns immediately unless DEV; for srcset it compares via srcset_url_equal, otherwise via src_url_equal, and if neither matches it emits a hydration_attribute_changed warning with a trimmed outerHTML snippet. src_url_equal is true for identical strings or when both resolve to the same absolute URL against document.baseURI. split_srcset parses a srcset into per-entry [url, descriptor] pairs. srcset_url_equal requires equal entry counts, equal width descriptors, and URL equality in either direction (relative or absolute forms must match across SSR and client).

uses: [attributes.js-src-url-equality](r1-dom-attributes.md#u-8d5e16577b56)

**Uncertainties.**

- The hydration_attribute_changed warning behavior depends on the warnings module not supplied here.

<a id="u-dfc6319c1edb"></a>
### `attribute_effect`

`export function attribute_effect( element, fn, sync = [], async = [], css_hash, skip_…` · [packages/svelte/src/internal/client/dom/elements/attributes.js:L472-L528][f1]

Creates a reactive effect that continuously spreads computed attributes onto an element.

flatten(sync, async, cb) provides the resolved value arrays; inside a block effect it calls fn on the (get-resolved) values, passes prev/next through set_attributes, and keeps the returned record as prev for diffing. For SELECT elements with a 'value' key it re-selects the option after each update via select_option. Symbols in the effects map whose value became falsy in next have their effects destroyed; ATTACHMENT_KEY symbols whose value changed have their previous effect destroyed and a new attach effect branched, also recorded into current. After the block, a SELECT element gets an additional effect that re-applies prev.value and initializes the select.

calls: [flatten](r4-client-reactivity.md#u-c50793421b66), [attributes.js-set-attributes](r1-dom-attributes.md#u-e75ddf9d4835), [select_option](r4-dom-elements.md#u-fc6c91d49336), [init_select](r4-dom-elements.md#u-f378be747d77), [attach](r4-dom-elements.md#u-89b96e9f81b2), [destroy_effect](r5-effects-module.md#u-214ad59ce57a), [effects.js-trivial-effect-factories](r5-effects-module.md#u-191f01511fb1), [packages/svelte/src/internal/client/reactivity/effects.js:block](r5-effects-module.md#u-75d755e7c63c)

<a id="u-475e532b1c41"></a>
### `set_attribute`

`export function set_attribute(element, attribute, value, skip_warning)` · [packages/svelte/src/internal/client/dom/elements/attributes.js:L162-L200][f1]

Sets a single attribute or property with hydration awareness and caching.

While hydrating it records the server-rendered value in the __attributes cache; for src, srcset, or href on LINK it optionally warns via check_src_in_dev_hydration and returns without writing, to avoid re-fetching. It then skips unchanged values using the cache. Setting 'loading' additionally stores the value under LOADING_ATTR_SYMBOL. A nullish value removes the attribute; a non-string value listed among the element's setters is assigned as a property; any other value is written with setAttribute.

**Notes.**

- failure: The hydration path assumes client and server src/srcset/href are equivalent without comparing them, so mismatches are silently kept (or dev-warned), never corrected.

calls: [get_attributes](r1-dom-attributes.md#u-fd27450a93d7), [get_setters](r1-dom-attributes.md#u-0d26f84d109d), [attributes.js-src-url-equality](r1-dom-attributes.md#u-8d5e16577b56)

<a id="u-fd27450a93d7"></a>
### `get_attributes`

`function get_attributes(element)` · [packages/svelte/src/internal/client/dom/elements/attributes.js:L534-L542][f1]

Returns (lazily initializing) the element's __attributes record, seeding it with IS_CUSTOM_ELEMENT (name contains '-') and IS_HTML (namespace is NAMESPACE_HTML).

This record is the change-detection cache used by set_value/set_checked/set_attribute/set_attributes.

<a id="u-0d26f84d109d"></a>
### `get_setters`

`function get_setters(element)` · [packages/svelte/src/internal/client/dom/elements/attributes.js:L548-L573][f1]

Returns the cached list of property setter names for an element's tag (or 'is' attribute value), building it once per key in a module-level Map.

It walks the prototype chain from the element instance up to (excluding) Element.prototype, collecting keys of descriptors that have a setter. For custom elements, setters on the instance itself are included, so the cache key is per-tag and the first-seen shape wins.

<a id="u-2c42d298a226"></a>
### `set_value`

`export function set_value(element, value)` · [packages/svelte/src/internal/client/dom/elements/attributes.js:L76-L93][f1]

Writes the DOM value property with change detection.

It caches attributes.value via get_attributes, normalizing null to undefined. It skips the write when the cached value is unchanged, or when element.value === value — except that a value of 0 on a PROGRESS element always triggers the write, since progress elements need their value set at 0. On change it assigns element.value = value ?? ''.

**Notes.**

- condition: The 0/PROGRESS carve-out forces a property write even when the value appears unchanged.

calls: [get_attributes](r1-dom-attributes.md#u-fd27450a93d7)

<a id="u-ab3720cbd1ab"></a>
### `set_checked`

`export function set_checked(element, checked)` · [packages/svelte/src/internal/client/dom/elements/attributes.js:L99-L113][f1]

Writes element.checked with change detection: it caches attributes.checked via get_attributes, normalizing null to undefined, and skips the property write when the cached value is unchanged; otherwise it assigns element.checked = checked.

calls: [get_attributes](r1-dom-attributes.md#u-fd27450a93d7)

<a id="u-6d856c0650f4"></a>
### `set_default_value`

`export function set_default_value(element, value)` · [packages/svelte/src/internal/client/dom/elements/attributes.js:L150-L154][f1]

Sets element.defaultValue without disturbing the live state: it reads element.value, assigns defaultValue, then restores the previously read value.

<a id="u-05d7d561d9ac"></a>
### `set_default_checked`

`export function set_default_checked(element, checked)` · [packages/svelte/src/internal/client/dom/elements/attributes.js:L139-L143][f1]

Sets element.defaultChecked without disturbing the live state: it reads element.checked, assigns defaultChecked, then restores the previously read checked value.

<a id="u-1e6158ce232f"></a>
### `set_selected`

`export function set_selected(element, selected)` · [packages/svelte/src/internal/client/dom/elements/attributes.js:L122-L132][f1]

Sets the selected attribute on an option.

When selected is true it adds the attribute only if not already present, so a user-changed selection is not overwritten; when false it removes the attribute. The attribute (not the property) is used so form resets take it into account.

<a id="u-0c7dcf045f92"></a>
### `set_custom_element_data`

`export function set_custom_element_data(node, prop, value)` · [packages/svelte/src/internal/client/dom/elements/attributes.js:L216-L263][f1]

Sets a property or attribute on a custom element while isolating side effects: it saves active_reaction and active_effect, disables hydrating if active (preventing block logic in already-scaffolded Svelte custom elements), nulls both active reaction and effect, and restores all three in a finally block.

Property assignment is chosen when prop !== 'style' and either the setters cache has the tag, customElements is unavailable, the registered definition lists the prop among setters, or the element is unregistered and the value is a non-null object (fallback heuristic so setters are not computed before upgrade). Otherwise the value (stringified, null kept) goes through set_attribute.

calls: [get_setters](r1-dom-attributes.md#u-0d26f84d109d), [set_attribute](r1-dom-attributes.md#u-475e532b1c41), [hydration.js-state-and-guards](r1-hydration-cursor.md#u-f1b7a30a3c1f)

**Uncertainties.**

- Behavior for elements registered between the customElements.get check and the property write relies on timing that cannot be verified from this file.

<a id="u-ddd420e3d016"></a>
### `set_xlink_attribute`

`export function set_xlink_attribute(dom, attribute, value)` · [packages/svelte/src/internal/client/dom/elements/attributes.js:L207-L209][f1]

Sets a namespaced attribute via dom.setAttributeNS with the XLink namespace URI; no caching, change detection, or null-removal handling.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/elements/attributes.js
