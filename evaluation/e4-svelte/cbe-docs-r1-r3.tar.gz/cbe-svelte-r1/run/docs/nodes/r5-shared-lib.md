# Shared Runtime Libraries

**Capability.** Framework-wide string utilities: HTML escaping for safe interpolation and shared numeric bitmask constants; no dependencies on other subsystems.

Use these before writing any markup-interpolating or flag-based code; the server transform's template builders depend on escape_html. Kept separate from all consumers.

**Depended on by.**

- [Server Transform](r5-server-transform.md) · graph-confirmed · 3 edge(s)

Parent: [Svelte](r5-svelte.md)

## Units (3)

<a id="u-0f499dd45547"></a>
### `escape_html`

`export function escape_html(value, is_attr)` · [packages/svelte/src/escaping.js:L9-L26][f1]

Escapes HTML-unsafe characters in a value for safe interpolation into markup.

It stringifies via `String(value ?? '')`, so `null`/`undefined` become the empty string while other non-strings go through `String`. For attribute context (`is_attr` truthy) it escapes `&`, `

<a id="u-8f510490a55c"></a>
### `escaping.js module code (L1–L8)`

`module_region` · [packages/svelte/src/escaping.js:L1-L8][f1]

Module-level regexes `ATTR_REGEX = /[&"<]/g` and `CONTENT_REGEX = /[&<]/g` used by `escape_html`; the attribute pattern additionally escapes double quotes.

uses: [escape_html](r5-shared-lib.md#u-0f499dd45547)

<a id="u-7ec445c0cb1a"></a>
### `constants.js module code (L1–L63)`

`module_region` · [packages/svelte/src/constants.js:L1-L63][f2]

Module of numeric bitmask flags and shared runtime constants with no logic.

Bit flags group as: each-block flags (EACH_ITEM_REACTIVE, EACH_INDEX_REACTIVE, EACH_IS_CONTROLLED, EACH_IS_ANIMATED, EACH_ITEM_IMMUTABLE), props flags (PROPS_IS_IMMUTABLE/RUNES/UPDATED/BINDABLE/LAZY_INITIAL), transition flags (TRANSITION_IN/OUT/GLOBAL), template flags (TEMPLATE_FRAGMENT, TEMPLATE_USE_IMPORT_NODE/SVG/MATHML), and element flags (ELEMENT_IS_NAMESPACED, ELEMENT_PRESERVE_ATTRIBUTE_CASE). Sentinel values: hydration markers HYDRATION_START `'['`, HYDRATION_START_ELSE `'[!'` (marks rendered `{:else}` blocks), HYDRATION_END `']'`, HYDRATION_ERROR `{}`; UNINITIALIZED as a bare `Symbol()`; dev-only symbols FILENAME and HMR. Namespace URL strings (NAMESPACE_HTML/SVG/MATHML), IGNORABLE_RUNTIME_WARNINGS listing the eight warning codes `svelte-ignore` may suppress (intentionally a subset so validation stays in place for others), ELEMENTS_WITHOUT_TEXT (marked TODO/unused), and ATTACHMENT_KEY `'@attach'`.

**Uncertainties.**

- How each flag is consumed is defined elsewhere; this file only declares values.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/escaping.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/constants.js
