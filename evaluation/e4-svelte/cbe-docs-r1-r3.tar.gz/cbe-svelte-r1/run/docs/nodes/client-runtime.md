# Client Runtime

**Capability.** Executes compiled client code in the browser: the fine-grained signal/derived/effect engine with batching and proxies, DOM template construction and hydration with cursor tracking, block rendering (slots, dynamic components, head, each reconciliation), element behaviors and bindings, boundaries and async blocks with error/pending handling, reactive props and equality, legacy in-component invalidation, and dev-only diagnostics plus tracing-mode flags.

Trace what the emitted $.-calls do here: context and reactivity are foundational, DOM blocks and bindings sit on top, and dev modules are inert in production. Mounting and hydration coordinate through the hydration cursor; boundaries own error and pending handling. Tracing flags are grouped with dev concerns.

**Depends on.**

- [Compiler Pipeline](compiler-pipeline.md) · model-inferred · 0 edge(s) · The client runtime executes the runtime calls that the compiler's client transform emits.
- [Server Runtime](server-runtime.md) · model-inferred · 0 edge(s) · Hydration in the client runtime aligns with the markers and markup produced by server rendering.
- [Shared Runtime Utilities](shared-runtime.md) · model-inferred · 0 edge(s) · The client runtime's DOM and dev layers consume shared element/attribute predicates instead of duplicating element tables.

**Depended on by.**

- [Reactivity & SSR Benchmarking](benchmarking.md) · model-inferred · 0 edge(s) · Benchmark suites drive the client reactivity internals directly to time signal graph shapes.
- [Public Reactive APIs & Features](public-reactive-apis.md) · model-inferred · 0 edge(s) · Public reactive features like springs and reactive window values are built on the client runtime's source and tracing internals.
- [Server Runtime](server-runtime.md) · model-inferred · 0 edge(s)
- [Shared Runtime Utilities](shared-runtime.md) · model-inferred · 0 edge(s)

Parent: [Svelte Monorepo](svelte-monorepo.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
