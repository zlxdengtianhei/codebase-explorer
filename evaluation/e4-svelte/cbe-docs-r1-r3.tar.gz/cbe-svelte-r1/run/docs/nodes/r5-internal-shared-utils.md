# Internal Shared Utilities

**Capability.** Small dependency-free helpers used across the runtime: deferred promises, promise/function guards, run/run_all, array conversion, and undefined fallbacks.

Infrastructure consumed by effects, stores, and legacy code; kept apart from all of them.

Parent: [Client Runtime](r5-client-runtime.md)

## Units (7)

<a id="u-3c5ab59ed010"></a>
### `deferred`

`export function deferred()` · [packages/svelte/src/internal/shared/utils.js:L53-L68][f1]

Creates an externally resolvable promise: returns { promise, resolve, reject } where resolve/reject control the returned promise.

Used where code must await completion triggered elsewhere (e.g. batch settling, spring updates).

<a id="u-f7765ee2ffbb"></a>
### `fallback`

`export function fallback(value, fallback, lazy = false)` · [packages/svelte/src/internal/shared/utils.js:L77-L83][f1]

Returns value unless it is undefined, in which case returns the fallback.

With lazy true, the fallback is expected to be a function and is invoked to produce the value; otherwise it is returned as-is. Only undefined (not null or other falsy values) triggers the fallback.

<a id="u-497b6c692c87"></a>
### `is_function`

`export function is_function(thing)` · [packages/svelte/src/internal/shared/utils.js:L19-L21][f1]

Type-guard returning true when the argument's typeof is 'function'.

<a id="u-f3295568a063"></a>
### `is_promise`

`export function is_promise(value)` · [packages/svelte/src/internal/shared/utils.js:L33-L35][f1]

Type-guard returning true when `value?.then` is a function, i.e. the value looks Promise-like.

Null/undefined safely yield false via optional chaining; any object with a callable then counts, whether or not it is a real Promise.

<a id="u-c1c0f4514218"></a>
### `packages/svelte/src/internal/shared/utils.js:run`

`export function run(fn)` · [packages/svelte/src/internal/shared/utils.js:L38-L40][f1]

Invokes and returns the result of the given function; a thin indirection, presumably to defer evaluation at call sites.

<a id="u-15a69c36073f"></a>
### `run_all`

`export function run_all(arr)` · [packages/svelte/src/internal/shared/utils.js:L43-L47][f1]

Calls each zero-argument function in the array in order.

No error handling: a throwing entry stops iteration and propagates, leaving later entries uncalled.

<a id="u-c7d546e409e1"></a>
### `to_array`

`export function to_array(value, n)` · [packages/svelte/src/internal/shared/utils.js:L94-L118][f1]

Converts a value to an array for destructuring like `let [a, b, c] = $derived(...)` where the value may be an iterable.

Arrays are returned unchanged. If n is undefined (rest element, so unbounded iterables are fine) or the value has no Symbol.iterator, it uses Array.from. Otherwise it iterates and pushes elements, stopping once n values are collected, avoiding draining an unbounded iterable beyond the needed count.

**Uncertainties.**

- Behavior when `n` is specified but the iterable yields fewer than n values: the shorter array is returned, per the loop, but this case is not exercised in supplied tests.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/shared/utils.js
