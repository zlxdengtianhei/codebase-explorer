# SSR Dev Validation

**Capability.** Development-time server checks: HTML nesting validation via an element stack, deduplicated placement warnings, stack reset/restore, and snippet-argument validation; plus the server lifecycle-unavailable error.

Use this to understand dev-only SSR warnings. push_element validates each element against html-tree-validation rules; reset_elements supports render-scoped isolation.

**Depends on.**

- [HTML Nesting Validation](r1-html-tree-validation.md) · graph-confirmed · 2 edge(s)

**Depended on by.**

- [SSR Rendering Helpers](r1-ssr-core.md) · graph-confirmed · 1 edge(s)

Parent: [Server Runtime](r1-runtime-server.md)

## Units (6)

<a id="u-4eb759f399d2"></a>
### `push_element`

`export function push_element(payload, tag, line, column)` · [packages/svelte/src/internal/server/dev.js:L60-L90][f1]

Records an element during SSR and validates HTML nesting in DEV.

Reads the filename from the current component's `function[FILENAME]`, builds an element record linked to the current `parent`. If a parent exists, it validates the tag against the immediate parent with `is_tag_valid_with_parent` and against each further ancestor with `is_tag_valid_with_ancestor`, walking up via `.parent` and accumulating ancestor tags; each returned message is reported through `print_error` with `file:line:column` locations when filenames are available. Finally sets `parent` to the new element, so subsequent pushes validate against it.

calls: [print_error](r1-ssr-dev.md#u-73a0e82a47ce), [is_tag_valid_with_parent](r1-html-tree-validation.md#u-a93dfa56dc6d), [is_tag_valid_with_ancestor](r1-html-tree-validation.md#u-c5a7f2f803ff)

**Uncertainties.**

- Relies on `current_component.function` being set, which only happens when DEV pushed a component frame; behavior when it is undefined is not guarded here.

<a id="u-c9f93e93e9bd"></a>
### `pop_element`

`export function pop_element()` · [packages/svelte/src/internal/server/dev.js:L92-L94][f1]

Restores the element-validation parent to the enclosing element by setting `parent` to `parent.parent`; assumes a matching `push_element` occurred (non-null parent is cast, not checked).

<a id="u-73a0e82a47ce"></a>
### `print_error`

`function print_error(payload, message)` · [packages/svelte/src/internal/server/dev.js:L33-L44][f1]

Reports a node-invalid-placement SSR warning once per message.

Prefixes the message with `node_invalid_placement_ssr:` plus a hydration-shift explanation, deduplicates via a lazily created module-level `seen` Set (so the same message is only logged once per process/module state), then logs to console.error and pushes a `<script>console.error(...)</script>` tag into `payload.head.out` so the client also logs it.

**Notes.**

- side_effect: Writes to console.error and mutates the payload head output; the `seen` set persists across renders.

<a id="u-cc2fd0cc577f"></a>
### `reset_elements`

`export function reset_elements()` · [packages/svelte/src/internal/server/dev.js:L46-L52][f1]

Snapshots and clears the module-level element-validation parent stack, returning a restore function.

Callers use this to isolate nested `render` calls so a bad inner render cannot corrupt outer parent/child element state; the returned closure restores the previous `parent`.

**Notes.**

- side_effect: Sets the module-level `parent` to null until the returned reset function runs.

<a id="u-75d5182b7c0f"></a>
### `packages/svelte/src/internal/server/dev.js:validate_snippet_args`

`export function validate_snippet_args(payload)` · [packages/svelte/src/internal/server/dev.js:L99-L107][f1]

Dev-time argument check for snippet calls: if `payload` is not an object or is not an instance of `Payload` or `HeadPayload`, it throws via `e.invalid_snippet_arguments()`; otherwise it returns normally with no side effects.

uses: [lifecycle_function_unavailable](r1-ssr-dev.md#u-af8d810f9167)

**Uncertainties.**

- Exact error thrown by invalid_snippet_arguments is defined elsewhere (shared/errors), not visible.

<a id="u-af8d810f9167"></a>
### `lifecycle_function_unavailable`

`export function lifecycle_function_unavailable(name)` · [packages/svelte/src/internal/server/errors.js:L10-L16][f2]

Throws a Svelte-branded Error stating that the named lifecycle function (`%name%(...)`) is unavailable on the server, with a `lifecycle_function_unavailable` code and docs URL.

Never returns (annotated `never`).

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/server/dev.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/server/errors.js
