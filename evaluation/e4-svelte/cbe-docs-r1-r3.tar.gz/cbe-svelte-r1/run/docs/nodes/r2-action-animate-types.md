# Action and animation type contracts

**Capability.** Owns the type-only public declarations for Svelte actions (Action/ActionReturn family) and the svelte/animate entry point (AnimationConfig, FlipParams).

Reference these when typing custom actions or consuming flip/fly-style animations. These declarations constrain the runtime APIs implemented elsewhere but contain no behavior.

Parent: [Type contracts](r2-type-definitions.md)

## Units (4)

<a id="u-3016f3d04ee4"></a>
### `action-public-d-ts-action-type-contracts`

`export interface ActionReturn< Parameter = undefined, Attributes extends Record<strin…` · [packages/svelte/src/action/public.d.ts:L27-L39][f1]

Type declarations for Svelte actions with no runtime behavior.

`ActionReturn<Parameter, Attributes>` types the optional `update` method (called whenever the action's parameter changes, immediately after markup updates) and optional `destroy` method (called after the element is unmounted), plus a `$$_attributes` marker that exists solely for type-checking and has no runtime effect. `Action<Element, Parameter, Attributes>` types the action function itself; its call signature makes the parameter argument optional exactly when `undefined extends Parameter`, otherwise required — the file's implementation note records that this form works better in both strict and nonstrict modes.

<a id="u-36a76bb59cff"></a>
### `public-d-ts-animate`

`export interface AnimationConfig` · [packages/svelte/src/animate/public.d.ts:L2-L8][f2]

Type-only public API declarations for the svelte/animate entry point.

AnimationConfig describes generic animation options (delay, duration, easing, css, tick callbacks); FlipParams describes flip-specific options whose duration may be a number or a function of the number of elements. Both are interfaces with no runtime behavior. The file re-exports everything from './index.js' and carries a comment noting AnimationConfig is the same shape as Transition and might be shared. As declaration-only source, no runtime semantics can be stated.

**Uncertainties.**

- Runtime shapes behind these interfaces live in './index.js', which is not supplied.

<a id="u-8715abeb9049"></a>
### `AnimationConfig`

`export interface AnimationConfig` · [packages/svelte/src/animate/public.d.ts:L2-L8][f2]

Public TypeScript declaration of the animation options accepted by Svelte animation utilities: optional delay, duration, easing function, css string generator, and tick callback.

group: [public-d-ts-animate](r2-action-animate-types.md#u-36a76bb59cff)

<a id="u-5713e0c9d221"></a>
### `FlipParams`

`export interface FlipParams` · [packages/svelte/src/animate/public.d.ts:L10-L14][f2]

Public TypeScript declaration of flip animation parameters: optional delay, optional duration as a number or a function of element count, and an optional easing function.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/action/public.d.ts
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/animate/public.d.ts
