# Shared runtime utilities

**Capability.** Owns platform-neutral runtime helpers used by both client and server: deep snapshot/clone of state, the standard Svelte error throwers, and warning emitters.

Use this for cross-platform behaviors independent of DOM or payload context. snapshot's dev warning path connects to state_snapshot_uncloneable; error throwers each encode one usage mistake.

**Depends on.**

- [Reactivity core \(signals and deriveds\)](r2-client-reactivity.md) · model-inferred · 0 edge(s)

Parent: [Svelte compiler and runtime](r2-svelte.md)

## Units (12)

<a id="u-97cc45d9b173"></a>
### `clone`

`function clone(value, cloned, path, paths, original = null, no_tojson = false)` · [packages/svelte/src/internal/shared/clone.js:L57-L137][f1]

Recursive deep-copy used by snapshot.

Already-cloned values are tracked in a Map so cycles and shared references preserve identity (a cycle yields a copy referencing itself). Maps and Sets are shallow-copied as new Map/Set. Arrays become same-length arrays copying only indices present (`i in value`); plain-object-prototype objects are copied key by key. When the clone originated from a toJSON call, the original instance is also registered in the Map so repeated references resolve to the same copy. Dates go through structuredClone. Other objects with a toJSON function (unless no_tojson) are replaced by a recursive clone of their toJSON() output. EventTargets are returned as-is since they cannot be cloned. Everything else goes through structuredClone; on failure the original value is returned and, in dev, the current path is pushed onto paths for warning. Uncloneable leaves therefore alias the originals in the snapshot.

**Uncertainties.**

- Objects whose prototype is neither object_prototype nor a handled built-in fall through to structuredClone; which of these reach the toJSON branch depends on prototype checks not fully verifiable here.
- Sparse-array holes remain holes in the copy because only present indices are assigned; this follows from `i in value` but hole edge behavior is not separately verified.

<a id="u-bfcc537be9f1"></a>
### `packages/svelte/src/internal/shared/clone.js:snapshot`

`export function snapshot(value, skip_warning = false, no_tojson = false)` · [packages/svelte/src/internal/shared/clone.js:L21-L45][f1]

Public deep-snapshot entry point that clones a value and, in dev, reports what could not be cloned.

With DEV and warnings not skipped, it clones while collecting uncloneable paths: a list containing only '' means the whole value failed and triggers a generic state_snapshot_uncloneable warning; a nonempty list means some properties failed, warned as a bullet list of paths (up to 10, truncated to 7 with '...and N more'). In production or with skip_warning it clones with a shared dummy empty array, suppressing path tracking. no_tojson forwards to clone to bypass toJSON handling.

calls: [clone](r2-shared-internals.md#u-97cc45d9b173), [state_snapshot_uncloneable](r2-shared-internals.md#u-093aec392ae5)

<a id="u-ece0f03618bc"></a>
### `clone.test.ts-snapshot-tests`

`function capture_warnings()` · [packages/svelte/src/internal/shared/clone.test.ts:L5-L19][f2]

Test suite for snapshot plus the capture_warnings helper, which swaps console.warn for a recorder and returns a restore function yielding collected messages.

Cases cover primitives, arrays, objects, proxied state (snapshot unaffected by later mutation), cycles (copy.self === copy), class instances with private fields and getters (only own enumerable field x copied), toJSON classes ({x:1, y:2}), reactive Map subclasses (cloned as plain Map, not the subclass), fully uncloneable values (original returned, generic warning), uncloneable properties (originals aliased; per-path warning listing paths), and many uncloneable properties (truncation to 7 entries with '...and 93 more').

**Uncertainties.**

- Test assertions document intended behavior; they do not prove the implementation's behavior on untested inputs.

<a id="u-243a2fd155d3"></a>
### `await_outside_boundary`

`export function await_outside_boundary()` · [packages/svelte/src/internal/shared/errors.js:L9-L19][f3]

Throws a Svelte error for awaiting outside a `<svelte:boundary>` with a `pending` snippet.

In DEV it throws an Error named 'Svelte error' carrying the message and docs URL; in production it throws a bare Error containing only the URL. Never returns.

<a id="u-21a0cef90eee"></a>
### `invalid_default_snippet`

`export function invalid_default_snippet()` · [packages/svelte/src/internal/shared/errors.js:L25-L35][f3]

Throws a Svelte error when `{@render children(...)}` is used while the parent component uses `let:` directives, suggesting a named snippet instead.

DEV throws a named 'Svelte error' with full message and docs URL; production throws a bare Error with only the URL. Never returns.

<a id="u-5b8d73f8df6c"></a>
### `invalid_snippet_arguments`

`export function invalid_snippet_arguments()` · [packages/svelte/src/internal/shared/errors.js:L41-L51][f3]

Throws a Svelte error when a snippet function receives invalid arguments, i.e. was not instantiated via `{@render ...}`.

DEV throws a named 'Svelte error' with full message and docs URL; production throws a bare Error with only the URL. Never returns.

<a id="u-4ad63b15ef02"></a>
### `lifecycle_outside_component`

`export function lifecycle_outside_component(name)` · [packages/svelte/src/internal/shared/errors.js:L58-L68][f3]

Throws a Svelte error stating that the named lifecycle function `name(...)` can only be used during component initialisation.

DEV throws a named 'Svelte error' embedding the function name, full message, and docs URL; production throws a bare Error with only the URL. Never returns.

<a id="u-04c44370ec95"></a>
### `snippet_without_render_tag`

`export function snippet_without_render_tag()` · [packages/svelte/src/internal/shared/errors.js:L74-L84][f3]

Throws a Svelte error for rendering a snippet without a `{@render}` block, which would stringify the snippet code instead of its content; the message advises changing `{snippet}` to `{@render snippet()}`.

DEV throws a named 'Svelte error' with the full message; production throws a bare Error with only the URL. Never returns.

<a id="u-07015d4f432c"></a>
### `store_invalid_shape`

`export function store_invalid_shape(name)` · [packages/svelte/src/internal/shared/errors.js:L91-L101][f3]

Throws a Svelte error reporting that `name` is not a store with a `subscribe` method.

DEV throws a named 'Svelte error' embedding the name, full message, and docs URL; production throws a bare Error with only the URL. Never returns.

<a id="u-7d812598d346"></a>
### `svelte_element_invalid_this_value`

`export function svelte_element_invalid_this_value()` · [packages/svelte/src/internal/shared/errors.js:L107-L117][f3]

Throws a Svelte error stating that the `this` prop on `<svelte:element>` must be a string, if defined.

DEV throws a named 'Svelte error' with the full message and docs URL; production throws a bare Error with only the URL. Never returns.

<a id="u-166c10327168"></a>
### `dynamic_void_element_content`

`export function dynamic_void_element_content(tag)` · [packages/svelte/src/internal/shared/warnings.js:L12-L18][f4]

Warns that `<svelte:element this="tag">` is a void element and cannot have content.

In DEV it warns a styled, full message with the tag interpolated and docs URL; in production it warns only the URL.

<a id="u-093aec392ae5"></a>
### `state_snapshot_uncloneable`

`export function state_snapshot_uncloneable(properties)` · [packages/svelte/src/internal/shared/warnings.js:L26-L40][f4]

Warns that $state.snapshot could not clone a value.

With a truthy properties string, the message lists the specific uncloneable paths and notes the return value contains the originals; without one, it reports the whole value could not be cloned and the original was returned. DEV emits the styled full message with bold/normal formatting; production warns only the URL.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/shared/clone.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/shared/clone.test.ts
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/shared/errors.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/shared/warnings.js
