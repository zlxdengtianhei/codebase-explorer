# Svelte Compiler

**Capability.** Turns Svelte source text into analyzed ASTs and generated client/server output: parsing, semantic analysis, transformation, diagnostics, and the shared AST type definitions describing intermediate representations.

Read this subtree when tracing how a .svelte file becomes executable output. Phases flow parse → analyze → transform, with warnings/ignore handling threaded through analysis and shared AST types documenting the template AST.

**Children.**

- [Template Parsing](r3-compiler-parse.md) `r3-compiler-parse` · 13 unit(s)
- [Semantic Analysis](r3-compiler-analyze.md) `r3-compiler-analyze` · 23 unit(s)
- [Code Transformation](r3-compiler-transform.md) `r3-compiler-transform` · 0 unit(s)
- [Compiler Diagnostics & Warnings](r3-compiler-diagnostics.md) `r3-compiler-diagnostics` · 11 unit(s)
- [Compiler Shared Utilities & Legacy AST](r3-compiler-shared-utils.md) `r3-compiler-shared-utils` · 5 unit(s)
- [Template AST Types](r3-compiler-ast-types.md) `r3-compiler-ast-types` · 5 unit(s)

**Depended on by.**

- [Compiler Diagnostics & Warnings](r3-compiler-diagnostics.md) · containment · → 0 / ← 0 edge(s) (ancestor direct units and descendant subtree; → follows ` r3-compiler-diagnostics ` → ` r3-compiler `)
- [Template Parsing](r3-compiler-parse.md) · containment · → 0 / ← 0 edge(s) (ancestor direct units and descendant subtree; → follows ` r3-compiler-parse ` → ` r3-compiler `)

Parent: [Svelte Repository](r3-svelte-monorepo.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
