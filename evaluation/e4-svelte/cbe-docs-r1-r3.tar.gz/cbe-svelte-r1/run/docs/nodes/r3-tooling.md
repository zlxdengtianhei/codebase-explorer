# Repository Tooling

**Capability.** Code generation, version stamping, message-documentation generation, reactivity benchmarking, cross-branch comparison, and test configuration for the repository.

Use this subtree when working on the build/dev infrastructure rather than shipped code. Codegen here produces files consumed by the compiler and runtime; benchmarks measure the reactivity core.

**Children.**

- [Code & Docs Generation](r3-tooling-codegen.md) `r3-tooling-codegen` · 5 unit(s)
- [Reactivity Benchmarks & Test Config](r3-tooling-benchmarks.md) `r3-tooling-benchmarks` · 5 unit(s)

Parent: [Svelte Repository](r3-svelte-monorepo.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
