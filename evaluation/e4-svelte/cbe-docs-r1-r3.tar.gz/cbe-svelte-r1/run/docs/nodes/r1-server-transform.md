# Server Transform Phase

**Capability.** Lowers components into SSR output: element/attribute serialization shared across element visitors, plus block visitors for if-blocks, reactive labels and regular elements.

Use this for compiled server markup. element.js concentrates attribute/class/style/spread handling; RegularElement composes those builders, and utils.js constants decide boolean/void/case behavior.

**Depends on.**

- [DOM & Rune Constant Predicates](r1-dom-dom-utils.md) · graph-confirmed · 7 edge(s) · SSR element builders use shared predicates like boolean-attribute and void-element checks when serializing markup.
- [Server Transform](r5-server-transform.md) · graph-only · 15 edge(s)

Parent: [Compiler Pipeline](r1-compiler.md)

## Units (9)

<a id="u-98ec092cab2d"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/IfBlock.js:IfBlock`

`export function IfBlock(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/IfBlock.js:L12-L29][f1]

Compiles {#if} blocks into a runtime if statement.

It visits the test, consequent, and alternate (empty block when absent), prepends a block_open comment to the consequent and a BLOCK_OPEN_ELSE literal marker to the alternate, then pushes the if statement and block_close onto the template.

<a id="u-42a7cea77ed0"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/LabeledStatement.js:LabeledStatement`

`export function LabeledStatement(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/LabeledStatement.js:L9-L24][f2]

Handles legacy `$:` reactive labels.

In runes mode, at any non-root path depth, or when the label is not '$', it returns undefined and traversal continues unchanged. Otherwise it records the statement in legacy_reactive_statements wrapped as a labeled('$', body) — preserving the label so a possible 'break $' still works — and returns b.empty so the original statement disappears from the output (ordering happens later topologically).

**Notes.**

- failure: A TODO notes module-context cases are not yet excluded.

<a id="u-7055b95dd599"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/RegularElement.js:RegularElement`

`export function RegularElement(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/RegularElement.js:L17-L188][f3]

Compiles a regular HTML element to static template literals plus child rendering.

It determines the child namespace (with `pre`/`textarea` forcing whitespace preservation), emits `<name`, builds the attributes via build_element_attributes (whose returned body expression may carry a textarea/contenteditable value), then `/>` for void elements or `>` otherwise. A `script`/`style` element with a single text child is emitted verbatim and returns early. After cleaning child nodes (using the fragment's scope) and visiting hoisted nodes, dev mode adds $.push_element with source line/column. Special cases follow: `select` with spreads captures spread value into $$payload.select_value, or with a value Attribute/BindDirective assigns $$payload.select_value (BindDirective sequence expressions visit only the first expression); `option` lacking any value attribute or spread renders children inside $.valueless_option; when an attribute body expression exists it is rendered as a const and an if emits it as the body when truthy, otherwise the inner template; plain elements just process children. A select with value resets $$payload.select_value to void 0 afterwards, non-void elements emit their closing tag, and dev mode appends $.pop_element.

calls: [build_element_attributes](r1-server-transform.md#u-50884bbfafdd), [build_spread_object](r1-server-transform.md#u-3629ffc7b235), [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/utils.js:build_attribute_value](r5-server-transform.md#u-8ce176223a22), [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/utils.js:process_children (2)](r5-server-transform.md#u-21d2acc05779), [function::is_void::570][f4]

**Uncertainties.**

- The exact return contract of build_element_attributes (null vs. expression) is defined in shared/element.js and only inferred here from the `body !== null` test.

<a id="u-50884bbfafdd"></a>
### `build_element_attributes`

`export function build_element_attributes(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/element.js:L33-L310][f5]

Transforms a regular or svelte element's attributes into server template output, returning an optional content expression for elements whose output is child content rather than attributes.

Per attribute type: `value` on textarea becomes `$.escape`-wrapped child content, prepending a newline when the literal text starts with one (HTML forbids a leading newline right after `<textarea>`); `value` on select is dropped. Event attributes are omitted except onload/onerror on load/error elements, which are recorded in events_to_capture. defaultValue/defaultChecked are skipped; `class` is wrapped in `$.clsx` when metadata.needs_clsx holds. BindDirectives: value on select and on `<input type=file>` are skipped, `this` is skipped, bindings flagged omit_in_ssr are skipped; a SequenceExpression result collapses to a call of its first expression. contenteditable bindings set the content expression, value on textarea sets escaped content, `group` without a sequence synthesizes a `checked` attribute (checkbox uses `includes`, otherwise strict equality against the value attribute; skipped when no value attribute exists), and other bindings become synthesized attributes. SpreadAttribute is kept, sets has_spread, and records onload/onerror capture on load/error elements; UseDirective only triggers that capture; Class/StyleDirectives are collected; LetDirective is ignored (handled by build_inline_component); anything else is visited. With a spread, build_element_spread_attributes emits `$.spread_attributes`, and `option` additionally emits `$.maybe_selected` with the spread object's `value`. Without a spread, literal/text attributes emit a string ` name="value"` (bare name for boolean attributes set true, skipped for empty class), appending the CSS hash to class values; `option value` emits `$.maybe_selected`. Otherwise the value is emitted as a pre-escaped literal (hash appended to class), `$.attr_class`, `$.attr_style`, or `$.attr` (true flag for boolean attributes). Recorded events emit ` name="this.__e=event"` literals.

calls: [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/utils.js:build_attribute_value](r5-server-transform.md#u-8ce176223a22), [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/element.js:get_attribute_name](r1-server-transform.md#u-5ee6cbf26623), [build_spread_object](r1-server-transform.md#u-3629ffc7b235), [build_element_spread_attributes](r1-server-transform.md#u-f66dce05e822), [build_attr_class](r1-server-transform.md#u-b758ea3e0e3a), [build_attr_style](r1-server-transform.md#u-9bfb6c1f061d), [escape_html](r5-shared-lib.md#u-0f499dd45547)

**Uncertainties.**

- Runtime behavior of $.attr, $.clsx, $.escape, $.maybe_selected, $.spread_attributes is outside this file

<a id="u-b758ea3e0e3a"></a>
### `build_attr_class`

`function build_attr_class(class_directives, expression, context, hash)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/element.js:L424-L451][f5]

Builds the dynamic class attribute output as a `$.attr_class(expression, css_hash, directives)` call.

When class directives exist they become an object whose keys are directive names and values are the visited directive expressions. When a CSS hash is supplied it is appended (space-separated, trimmed) to an inline string literal value; a non-literal expression instead passes the hash as a separate literal argument so the runtime can append it.

uses: [build_element_attributes](r1-server-transform.md#u-50884bbfafdd)

<a id="u-9bfb6c1f061d"></a>
### `build_attr_style`

`function build_attr_style(style_directives, expression, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/element.js:L459-L494][f5]

Builds the dynamic style attribute output as a `$.attr_style(expression, directives)` call.

Each style directive contributes a property keyed by the original directive name; its value is the directive name identifier when the directive value is `true`, else the built attribute value with whitespace-insensitive handling. Property names other than custom properties (not starting `--`) are lowercased for the lookup but the property key keeps the original name. Directives with the `important` modifier are collected into a second object, and when any exist the directives argument is a two-element array of [normal, important] objects; otherwise it is a single object, or undefined when no directives exist.

calls: [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/utils.js:build_attribute_value](r5-server-transform.md#u-8ce176223a22)

<a id="u-f66dce05e822"></a>
### `build_element_spread_attributes`

`function build_element_spread_attributes( element, attributes, style_directives, clas…` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/element.js:L364-L415][f5]

Emits a single `$.spread_attributes` call for elements that contain a spread, folding collected class and style directives into optional object arguments.

Class directives become an object of name/expression properties, using the identifier shorthand when the expression is exactly the directive's own name identifier; style directives become an object whose values are the directive name identifier when the value is `true`, else build_attribute_value with trimming. Namespace flags: svg and mathml set both ELEMENT_IS_NAMESPACED and ELEMENT_PRESERVE_ATTRIBUTE_CASE; a custom element sets only ELEMENT_PRESERVE_ATTRIBUTE_CASE; otherwise flags stay 0 and undefined is passed instead of the literal. The call always receives the built spread object and the scoped CSS hash literal (or null), followed by classes, styles, and the flags literal.

calls: [build_spread_object](r1-server-transform.md#u-3629ffc7b235), [is_custom_element_node](r4-compiler-model.md#u-ea1f0b51e1e8)

<a id="u-3629ffc7b235"></a>
### `build_spread_object`

`export function build_spread_object(element, attributes, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/element.js:L331-L354][f5]

Builds an object expression representing the element's attributes for spread paths.

Attributes become init properties using the resolved (case-normalized for non-svg/mathml) name and build_attribute_value with whitespace-insensitive treatment for class/style; BindDirectives become properties whose value is a call of the first expression when the binding expression is a SequenceExpression, otherwise the visited expression; any other attribute kind (SpreadAttribute) becomes a spread of its visited expression.

calls: [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/element.js:get_attribute_name](r1-server-transform.md#u-5ee6cbf26623), [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/utils.js:build_attribute_value](r5-server-transform.md#u-8ce176223a22)

<a id="u-5ee6cbf26623"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/element.js:get_attribute_name`

`function get_attribute_name(element, attribute)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/element.js:L316-L324][f5]

Resolves the output name for an element attribute or binding: the name is lowercased unless the element is svg or mathml, where case must be preserved.

Boolean-attribute alias lookup is deliberately not done here because the server runtime only checks lowercase variants.

uses: [build_element_attributes](r1-server-transform.md#u-50884bbfafdd)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/IfBlock.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/LabeledStatement.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/RegularElement.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/utils.js
[f5]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/element.js
