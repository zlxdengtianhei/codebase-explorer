# Server Runtime

**Capability.** Renders components to HTML strings/streams on the server: the compiled $.-helpers the server transform emits, the component context frame chain with set/get/has context APIs, render payload buffers (body, head, css, uid) with legacy copy/assign semantics, server snippet creation, server-side lifecycle like onDestroy, an abort signal for stale SSR renders, hydration markers for raw HTML, and dev-time HTML nesting validation.

Use this for everything behind svelte/server. Compiled SSR output writes into Payload/HeadPayload and registers teardown via onDestroy; dev validation warns only in development. The relation between the server transform and this public entry is documented only at the region level.

**Depends on.**

- [Client Runtime](client-runtime.md) · model-inferred · 0 edge(s)
- [Compiler Pipeline](compiler-pipeline.md) · model-inferred · 0 edge(s)
- [Shared Runtime Utilities](shared-runtime.md) · model-inferred · 0 edge(s)

**Depended on by.**

- [Reactivity & SSR Benchmarking](benchmarking.md) · model-inferred · 0 edge(s)
- [Client Runtime](client-runtime.md) · model-inferred · 0 edge(s) · Hydration in the client runtime aligns with the markers and markup produced by server rendering.
- [Public Reactive APIs & Features](public-reactive-apis.md) · model-inferred · 0 edge(s)
- [Build & Repo Tooling](repo-tooling.md) · model-inferred · 0 edge(s)
- [Shared Runtime Utilities](shared-runtime.md) · model-inferred · 0 edge(s)

Parent: [Svelte Monorepo](svelte-monorepo.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
