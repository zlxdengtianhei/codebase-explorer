# Public Component API

**Capability.** The user-facing client surface: lifecycle hooks and event dispatch, attachment creation for library authors, and Svelte 4 compatibility adapters.

What application code imports from 'svelte'. Built on top of the client runtime; legacy adapters wrap runtime effects behind Svelte 4 semantics.

**Children.**

- [Lifecycle and Events](r5-component-lifecycle.md) `r5-component-lifecycle` · 9 unit(s)
- [Attachments API](r5-attachments-api.md) `r5-attachments-api` · 3 unit(s)
- [Svelte 4 Compatibility Adapters](r5-legacy-adapters.md) `r5-legacy-adapters` · 6 unit(s)

Parent: [Svelte](r5-svelte.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
