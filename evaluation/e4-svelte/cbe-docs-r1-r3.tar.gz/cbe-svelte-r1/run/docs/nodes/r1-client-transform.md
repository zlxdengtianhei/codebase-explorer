# Client Transform Phase

**Capability.** Lowers the analyzed AST into client-side runtime calls: template serialization, block/element/component visitors, and shared statement-building utilities.

Use this subtree when working on compiled client output. Template serialization is separate from the visitors that populate it, and shared utils (memoization, expression/template building) back all visitors.

**Children.**

- [Template Serialization](r1-client-template.md) `r1-client-template` · 3 unit(s)
- [Client Block & Element Visitors](r1-client-block-visitors.md) `r1-client-block-visitors` · 10 unit(s)
- [Shared Client Transform Builders](r1-client-shared-transform-utils.md) `r1-client-shared-transform-utils` · 12 unit(s)

Parent: [Compiler Pipeline](r1-compiler.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
