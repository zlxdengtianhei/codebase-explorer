# Template AST Types

**Capability.** TypeScript declarations of the template AST: the AST namespace's foundations (root/fragment), tags, directives with their shared BaseElement, concrete elements, and blocks/attributes plus closing unions.

Use this subtree as the reference for AST node shapes shared between parse, analyze, and transform. It is type-only; behavior lives in the phase subtrees.

Parent: [Svelte Compiler](r3-compiler.md)

## Units (5)

<a id="u-e8223dc323d4"></a>
### `template.d.ts-root-and-fragment`

`export type Namespace = 'html' | 'svg' | 'mathml';` · [packages/svelte/src/compiler/types/template.d.ts:L28-L28][f1]

Top-level `AST` namespace foundations.

`Namespace` is the `'html' | 'svg' | 'mathml'` union. `DelegatedEvent` distinguishes hoisted handlers (carrying an arrow/function expression) from non-hoisted ones. `BaseNode` supplies `type`/`start`/`end`. `Fragment` holds a mixed `nodes` array plus internal metadata: `transparent` marks fragments whose scope is not represented in the generated JS (e.g. element scopes) and must delegate to parent scopes for unique identifiers, `dynamic` decides whether mount/hydrate must traverse into the fragment, and `has_await` is present. `Root` is the component root: inline `<svelte:options>` overrides, the main `Fragment`, nullable parsed `css` (`AST.CSS.StyleSheet`), `instance` and `module` scripts, collected `JSComment[]`, and internal `metadata.ts` recording whether the component parsed as TypeScript. `SvelteOptions` mirrors inline options (`runes`, `immutable`, `accessors`, `preserveWhitespace`, `namespace`, `css?: 'injected'`) plus a `customElement` object with `tag`, `shadow`, per-prop attribute/reflect/type records, and an `extend` callback taking and returning a custom element class; it also keeps `start`/`end` for warnings and the Prettier plugin and collects `attributes`. The file also augments estree's `BaseNode` with optional `start`, `end` (Svelte parser) and `typeAnnotation` (acorn-typescript).

uses: [css.d.ts-css-ast](r5-compiler-types.md#u-b61efd19fa24)

<a id="u-cfe4d7167bde"></a>
### `template.d.ts-tags`

`export interface Text extends BaseNode` · [packages/svelte/src/compiler/types/template.d.ts:L119-L125][f1]

Mustache-like tag node shapes.

`Text` keeps `data` with decoded HTML entities and `raw` with the original text. `ExpressionTag` is a plain `{...}` expression; `HtmlTag` is `{@html ...}`; both carry internal `ExpressionMetadata`. `Comment` holds `data` (with a TODO noting a rename for disambiguation). `ConstTag` constrains its `declaration` to a single-variable `VariableDeclaration` whose declarator has a `Pattern` id and `Expression` init. `DebugTag` lists the identifiers in `{@debug ...}`. `RenderTag` is `{@render ...}` whose expression is a (possibly chained) simple call; internal metadata includes per-argument `ExpressionMetadata`, `dynamic`, the enclosing `path`, and a `snippets` set of locally defined snippets it could resolve to, used for CSS pruning. `AttachTag` is `{@attach foo(...)}` with expression metadata.

uses: [index.d.ts-validated-options-and-metadata](r5-compiler-types.md#u-be1f92cc5d0b)

<a id="u-bd906a7e21ed"></a>
### `template.d.ts-directives`

`interface BaseElement extends BaseNode` · [packages/svelte/src/compiler/types/template.d.ts:L306-L310][f1]

Directive node shapes plus the shared `BaseElement` they attach to.

`BaseElement` fixes the common element surface: `name`, `attributes` (Attribute, SpreadAttribute, Directive, or AttachTag), and a `Fragment`. `AnimateDirective` is `animate:x` with nullable expression. `BindDirective` (`bind:x`) allows identifier, member, or sequence expressions; its metadata tracks a `binding_group_name` and `parent_each_blocks`. `ClassDirective` fixes `name: 'class'` with the value expression. `LetDirective` is `let:x` with nullable identifier/array/object expression. `OnDirective` is `on:x` whose modifiers enumerate capture/nonpassive/once/passive/preventDefault/self/stopImmediatePropagation/stopPropagation/trusted. `StyleDirective` is `style:x` whose `value` is `true` (boolean shorthand) or expression/text arrays, with `'important'` modifiers. `TransitionDirective` covers `transition:`/`in:`/`out:` with `'local'|'global'` modifiers and `intro`/`outro` booleans distinguishing the three. `UseDirective` is `use:x` with nullable expression. The `Directive` union groups all eight.

<a id="u-1ad44003bd82"></a>
### `template.d.ts-elements`

`export interface Component extends BaseElement` · [packages/svelte/src/compiler/types/template.d.ts:L312-L323][f1]

Concrete element nodes extending the shared `BaseElement`.

`Component`, `SvelteComponent` (with its dynamic `expression`), `SvelteSelf`, and `SvelteElement` (dynamic `tag` expression) share internal metadata of per-attribute-name `scopes`, a `snippets` set of locally defined snippets for CSS pruning, and a `path`; `SvelteElement` additionally infers `svg`/`mathml` booleans from the template even though a dynamic tag can make them inaccurate, and carries expression metadata. `RegularElement` metadata instead records static `svg`/`mathml` flags, `has_spread`, `scoped`, and `path`. The special-tag elements (`SvelteBody`, `SvelteDocument`, `SvelteFragment`, `SvelteBoundary`, `SvelteHead`, `SvelteWindow`, `TitleElement`, `SlotElement`) only fix their `name` literals. `SvelteOptionsRaw` is explicitly an intermediate parse-time representation that does not exist in the final AST. `ElementLike` unions all fifteen.

<a id="u-09f66e3d06d6"></a>
### `template.d.ts-blocks-attributes`

`export interface EachBlock extends BaseNode` · [packages/svelte/src/compiler/types/template.d.ts:L436-L464][f1]

Blocks, attributes, scripts, and the closing union types of the `AST` namespace.

`EachBlock` holds the iterated `expression`, nullable `context` pattern, `body` and optional `fallback` fragments, optional `index` and `key`; metadata includes `keyed`, `contains_group_binding`, a synthesized `index` identifier, a `declarations` map, `is_controlled` (an optimization when the block is a single child of a non-fragment parent, saving a comment node and speeding insertion), and `transitive_deps` whose bindings legacy mode invalidates on item mutation. `IfBlock` has `test`, `consequent`, nullable `alternate`, and an `elseif` flag. `AwaitBlock` has the awaited `expression`, nullable `value`/`error` patterns, and nullable pending/then/catch fragments (with a TODO about moving value/error into the sub-fragments). `KeyBlock` re-renders its `fragment` when `expression` changes. `SnippetBlock` has an identifier `expression`, `parameters`, optional `typeParams`, and a body; metadata records `can_hoist` and a `sites` set of components/render tags that could render it, for CSS pruning. `Attribute.value` is `true` or an `ExpressionTag`/mixed text array (quoted values become arrays even for a single expression); metadata may mark `delegated` (a `DelegatedEvent`) and `needs_clsx` for class attributes. `SpreadAttribute` and the block/tag metadata use `ExpressionMetadata`. `Script` distinguishes `'default'` vs `'module'` context with an estree `Program`. `JSComment` records line/block comments from scripts and expressions with location info. Trailing unions (`AttributeLike`, `Block`, `Tag`, `TemplateNode`, `SvelteNode`) compose the namespace, with `SvelteNode` also including estree `Node`, `Fragment`, `_CSS.Node`, and `Script`; `AST.CSS` re-exports `_CSS`. A second module-scope `BaseNode` declares a legacy shared shape.

uses: [index.d.ts-validated-options-and-metadata](r5-compiler-types.md#u-be1f92cc5d0b), [css.d.ts-css-ast](r5-compiler-types.md#u-b61efd19fa24)

**Uncertainties.**

- There are two `BaseNode` declarations in this file (inside `namespace AST` and at module scope); how the latter is consumed is not shown here.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/types/template.d.ts
