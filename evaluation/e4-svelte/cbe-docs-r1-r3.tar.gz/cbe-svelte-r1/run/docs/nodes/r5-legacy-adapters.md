# Svelte 4 Compatibility Adapters

**Capability.** Deprecated wrappers letting Svelte 5 components behave like Svelte 4 classes ($set/$on/$destroy), plus bubblers, handler merging, and the reactive run() helper.

Use only when migrating; Svelte4Component is the core wrapper and asClassComponent/createClassComponent are its entry points. run() maps onto $effect.pre semantics.

**Depends on.**

- [Lifecycle and Events](r5-component-lifecycle.md) · model-inferred · 0 edge(s)
- [Effect Lifecycle](r5-effects-module.md) · graph-confirmed · 1 edge(s)

Parent: [Public Component API](r5-public-api.md)

## Units (6)

<a id="u-f604417484a2"></a>
### `Svelte4Component`

`class Svelte4Component` · [packages/svelte/src/legacy/legacy-client.js:L67-L79][f1]

Svelte 4–compatible component wrapper around a Svelte 5 component, supporting class instantiation, `$set`, `$on`, `$destroy`, and instance exports.

The constructor builds coarse-grained reactivity via a Proxy over `{...options.props, $$events: {}}`: `get` and `has` lazily create a mutable_source per property and read it through `get` (has returns true early for LEGACY_PROPS to avoid invalid-binding validation, then Reflect.has); `set` writes through `set` on the source plus Reflect.set. The component is mounted with `hydrate` when `options.hydrate` is set, otherwise `mount`, passing target, anchor, props proxy, context, `intro: options.intro ?? false`, and recover. Afterwards, flushSync runs only when NOT in async mode AND (no `$$host` prop OR `options.sync === false`); in async mode or with custom-element wrappers it is skipped because flushSync would fail there. `this.#events` captures the props' `$$events`. Every instance key except $set/$destroy/$on is re-exposed on the wrapper as an enumerable get/set accessor delegating to `#instance`, providing exports. `#instance.$set` assigns props onto the proxy (triggering per-prop source writes via the set trap); `#instance.$destroy` unmounts. `$set(props)` delegates to `#instance.$set`; `$on(event, callback)` registers a wrapped callback (`callback.call(this, ...args)`) on the event array and returns an unsubscribe function filtering it out; `$destroy` delegates to `#instance.$destroy`.

**Notes.**

- side_effect: The proxy traps lazily create mutable sources keyed by prop name on first read, write, or `has` check.
- condition: flushSync is skipped when async_mode_flag is set, or when a $$host prop exists unless sync === false.

calls: [Svelte4Component](r5-legacy-adapters.md#u-f604417484a2); uses: [Svelte4Component](r5-legacy-adapters.md#u-f604417484a2)

**Uncertainties.**

- Exact mount/hydrate and flushSync semantics live in internal client modules not supplied here.

<a id="u-0c8e95825ebe"></a>
### `asClassComponent`

`export function asClassComponent(component)` · [packages/svelte/src/legacy/legacy-client.js:L49-L51][f1]

Deprecated adapter that takes a component function (Svelte 5 `Component` or SvelteComponent) and returns a class extending Svelte4Component so it can be instantiated with Svelte 4 options.

The subclass constructor merges the captured `component` into the options object spread before calling super, so instantiation delegates entirely to Svelte4Component's mounting and legacy-prop machinery.

inherits: [Svelte4Component](r5-legacy-adapters.md#u-f604417484a2)

<a id="u-f1a6026980f8"></a>
### `createClassComponent`

`export function createClassComponent(options)` · [packages/svelte/src/legacy/legacy-client.js:L31-L34][f1]

Deprecated adapter that constructs and returns a new Svelte4Component from options shaped like Svelte 4 ComponentConstructorOptions plus a `component` key, yielding a Svelte 4 compatible component instance.

It forwards options unchanged; all behavior (hydration, prop proxying, flush timing) lives in Svelte4Component's constructor.

uses: [Svelte4Component](r5-legacy-adapters.md#u-f604417484a2)

<a id="u-f145d0cb7490"></a>
### `createBubbler`

`export function createBubbler()` · [packages/svelte/src/legacy/legacy-client.js:L248-L268][f1]

Deprecated factory producing a `bubble` function mimicking Svelte 4's automatic event bubbling.

It snapshots `component_context` at creation time; if that is null it raises the `lifecycle_outside_component` error, so it must be called inside a component. The returned function takes an event type and returns an event handler that looks up `active_component_context.s.$$events[type]`; if present, it copies the handler(s) (array sliced, single wrapped) and calls each with `active_component_context.x` as `this` and the event, returning `!event.defaultPrevented`. If no handlers exist for the type it returns true.

raises: [createBubbler](r5-legacy-adapters.md#u-f145d0cb7490)

<a id="u-59b2e05812ff"></a>
### `handlers`

`export function handlers(...handlers)` · [packages/svelte/src/legacy/legacy-client.js:L211-L242][f1]

Deprecated helper combining multiple EventListeners into one function that invokes each handler with the event (and the returned function's `this`).

It wraps `event.stopImmediatePropagation` so that when a handler calls it, a `stopped` flag is set and the original behavior still runs. Handlers run in order inside try/catch: an exception is collected into `errors` and the loop continues; if propagation was stopped the loop breaks. After the loop, every collected error is re-thrown asynchronously via `queueMicrotask(() => { throw error; })`, so failures surface as uncaught errors without interrupting later handlers.

**Notes.**

- failure: Handler exceptions are deferred: they never abort sibling handlers but are rethrown as microtask uncaught errors.

<a id="u-8f7bc3d6b657"></a>
### `packages/svelte/src/legacy/legacy-client.js:run`

`export function run(fn)` · [packages/svelte/src/legacy/legacy-client.js:L188-L203][f1]

Deprecated compatibility helper that runs `fn` immediately and reactively like `$effect.pre` on the client (a plain call on the server is the caller's concern per the docstring, but only the client effect path is visible).

Inside the user pre effect, after calling fn, if the active effect was already flagged DIRTY (i.e. re-dirtied during fn), it warns `legacy_recursive_reactive_block` — with the component's FILENAME when DEV and available, otherwise the placeholder 'a file (we can't know which one)' — and downgrades the effect status to MAYBE_DIRTY to emulate legacy recursive reactive-block behavior.

**Notes.**

- failure: Recursive dirtying is not an error; it triggers a warning and a MAYBE_DIRTY status change.

calls: [packages/svelte/src/legacy/legacy-client.js:run](r5-legacy-adapters.md#u-8f7bc3d6b657)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/legacy/legacy-client.js
