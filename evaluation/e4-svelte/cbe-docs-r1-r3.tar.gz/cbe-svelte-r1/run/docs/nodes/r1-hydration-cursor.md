# Hydration Cursor State

**Capability.** Tracks the hydration cursor, reads instruction markers, removes SSR nodes up to hydration-end comments, and guards against SSR/client mismatch.

Use this to understand how client rendering aligns with server markup. Attributes, boundaries and mounting all consume these guards.

**Depended on by.**

- [Boundary & Async Blocks](r1-boundary-blocks.md) · graph-confirmed · 5 edge(s)
- [Mount, Hydrate & Unmount](r1-client-mounting.md) · graph-confirmed · 7 edge(s) · hydrate() uses the hydration cursor state and guards to walk server markup during mounting.
- [DOM Attributes & Properties](r1-dom-attributes.md) · graph-confirmed · 4 edge(s) · Attribute setters consult hydration state to avoid clobbering values during hydration.
- [DOM Blocks](r3-runtime-dom-blocks.md) · graph-only · 16 edge(s)
- [Each Block](r5-each-block.md) · graph-only · 10 edge(s)

Parent: [Client Runtime](r1-runtime-client.md)

## Units (3)

<a id="u-f1b7a30a3c1f"></a>
### `hydration.js-state-and-guards`

`export function set_hydrating(value)` · [packages/svelte/src/internal/client/dom/hydration.js:L20-L22][f1]

Tracks the hydration cursor and guards against SSR/client markup mismatch.

`hydrating` and `hydrate_node` are module-level mutable state: the boolean enables treeshaking of hydration paths, and the node cursor advances as components consume SSR output. `set_hydrating` toggles the flag; `set_hydrate_node` advances the cursor but on a null node warns via `w.hydration_mismatch` and throws the HYDRATION_ERROR sentinel; `hydrate_next` advances to the next sibling through `get_next_sibling`. `reset` is a no-op when not hydrating; when hydrating it fails with the same warning/throw if siblings remain at the cursor (leftover markup), otherwise rewinds to the given node. `hydrate_template` only acts while hydrating, pointing the cursor at the template's content fragment. `next(count)` walks `count` siblings forward but only while hydrating.

**Notes.**

- failure: Three paths (null node to set_hydrate_node, reset with remaining siblings, read_hydration_instruction on a non-comment) all call w.hydration_mismatch then throw HYDRATION_ERROR; the sentinel value doubles as the thrown object.
- condition: All cursor functions behave differently depending on the module-level `hydrating` flag set by set_hydrating.

calls: [operations.js-node-navigation](r2-client-dom-core.md#u-a31f01c2fa93); imports: [packages/svelte/src/internal/client/dev/equality.js][f2]

**Uncertainties.**

- The consumer of the thrown HYDRATION_ERROR sentinel and any catch/teardown behavior live outside this file.

<a id="u-97280e054ad7"></a>
### `read_hydration_instruction`

`export function read_hydration_instruction(node)` · [packages/svelte/src/internal/client/dom/hydration.js:L112-L119][f1]

Reads the instruction marker (comment data) of a hydration node.

If the node is falsy or not a comment node, it warns with a hydration mismatch and throws HYDRATION_ERROR; otherwise returns the comment's data string.

raises: [grp:hydration.js-state-and-guards][f1]

<a id="u-fc45567d72a4"></a>
### `remove_nodes`

`export function remove_nodes()` · [packages/svelte/src/internal/client/dom/hydration.js:L86-L106][f1]

Removes server-rendered nodes from the cursor until the matching hydration-end comment, returning that comment.

Starting at `hydrate_node`, it tracks nesting depth: a HYDRATION_END comment at depth 0 terminates the loop and is returned (not removed); a HYDRATION_END otherwise decrements depth; HYDRATION_START or HYDRATION_START_ELSE increments it. Any other node (including nested comments) is removed and the walk continues via get_next_sibling. The terminating end comment is left in the DOM as the block anchor.

calls: [operations.js-node-navigation](r2-client-dom-core.md#u-a31f01c2fa93)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/hydration.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dev/equality.js
