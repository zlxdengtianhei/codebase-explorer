# Lifecycle and Events

**Capability.** onMount/onDestroy/beforeUpdate/afterUpdate hooks, createEventDispatcher with CustomEvent construction, rune misuse guards, and abort-signal access for awaits.

The documented component API; hooks cache callbacks on the component context's legacy record and route through runtime untracking. throw_rune_error is a dev-only diagnostic.

**Depends on.**

- [Signal Core](r5-signal-core.md) · graph-confirmed · 2 edge(s)

**Depended on by.**

- [Svelte 4 Compatibility Adapters](r5-legacy-adapters.md) · model-inferred · 0 edge(s)

Parent: [Public Component API](r5-public-api.md)

## Units (9)

<a id="u-3c1ac43e0c43"></a>
### `onMount`

`export function onMount(fn)` · [packages/svelte/src/index-client.js:L91-L104][f1]

Schedules a function to run once after the component mounts.

Throws `e.lifecycle_outside_component('onMount')` when `component_context` is null. In legacy mode with a legacy context (`legacy_mode_flag && component_context.l !== null`), the callback is pushed onto the legacy context's `.m` list for the legacy update machinery; otherwise it creates a user effect that runs `fn` via `untrack` and, if `fn` returns a function synchronously, returns it as the effect's cleanup. Any returned non-function value (including a Promise) is discarded, so async cleanup callbacks are not supported.

calls: [init_update_callbacks](r5-component-lifecycle.md#u-f15a32115088), [untrack](r5-signal-core.md#u-aa0e067da463)

<a id="u-de75503262fc"></a>
### `onDestroy`

`export function onDestroy(fn)` · [packages/svelte/src/index-client.js:L115-L121][f1]

Schedules a callback to run immediately before the component unmounts.

Throws `e.lifecycle_outside_component('onDestroy')` when `component_context` is null. Implemented on top of onMount: it registers an effect whose body returns a cleanup closure that calls `fn` via `untrack`, so `fn` runs outside any reactive tracking when the component is destroyed.

calls: [onMount](r5-component-lifecycle.md#u-3c1ac43e0c43), [untrack](r5-signal-core.md#u-aa0e067da463)

<a id="u-346a7286b04e"></a>
### `beforeUpdate`

`export function beforeUpdate(fn)` · [packages/svelte/src/index-client.js:L200-L210][f1]

Legacy-only pre-update hook.

Throws `e.lifecycle_outside_component('beforeUpdate')` without a component context and `e.lifecycle_legacy_only('beforeUpdate')` when `component_context.l` is null (runes mode). Otherwise pushes `fn` onto the legacy context's callback list `.b`.

calls: [init_update_callbacks](r5-component-lifecycle.md#u-f15a32115088)

<a id="u-3eabc3a794df"></a>
### `afterUpdate`

`export function afterUpdate(fn)` · [packages/svelte/src/index-client.js:L223-L233][f1]

Legacy-only post-update hook.

Throws `e.lifecycle_outside_component('afterUpdate')` without a component context and `e.lifecycle_legacy_only('afterUpdate')` when `component_context.l` is null (runes mode). Otherwise pushes `fn` onto the legacy context's callback list `.a`.

calls: [init_update_callbacks](r5-component-lifecycle.md#u-f15a32115088)

<a id="u-f15a32115088"></a>
### `init_update_callbacks`

`function init_update_callbacks(context)` · [packages/svelte/src/index-client.js:L239-L242][f1]

Legacy-mode helper returning (and lazily creating) the callbacks object on the context's legacy record `l`: `{ a: [], b: [], m: [] }` for afterUpdate, beforeUpdate, and onMount callbacks respectively, cached in `l.u`.

<a id="u-a13f6abb0775"></a>
### `createEventDispatcher`

`export function createEventDispatcher()` · [packages/svelte/src/index-client.js:L157-L185][f1]

Creates a legacy event dispatcher bound to the component context at creation time.

Throws `e.lifecycle_outside_component('createEventDispatcher')` if there is no active component context. The returned dispatcher looks up handlers for `type` on `active_component_context.s.$$events`; if none exist it returns true (nothing prevented default). Otherwise it copies the handler(s) (slicing arrays so mutation during dispatch is safe), builds a CustomEvent via `create_custom_event` with the given detail and options, invokes each handler with `this` set to `active_component_context.x`, and returns `!event.defaultPrevented`.

calls: [create_custom_event](r5-component-lifecycle.md#u-c36028ba992c); uses: [is_array][f2]

**Uncertainties.**

- A TODO in the source questions dispatch behavior in non-DOM server environments; not resolved by this file.

<a id="u-c36028ba992c"></a>
### `create_custom_event`

`function create_custom_event(type, detail, { bubbles = false, cancelable = false } = {})` · [packages/svelte/src/index-client.js:L130-L132][f1]

Internal helper constructing a CustomEvent with the given type, detail, and options defaulting bubbles/cancelable to false.

<a id="u-9fba83ef7551"></a>
### `getAbortSignal`

`export function getAbortSignal()` · [packages/svelte/src/index-client.js:L69-L75][f1]

Returns an AbortSignal tied to the currently running derived or effect.

Throws `e.get_abort_signal_outside_reaction` when `active_reaction` is null. Lazily creates an AbortController on the reaction (`active_reaction.ac ??=`) and returns its signal, so the signal aborts when that reaction re-runs or is destroyed.

**Uncertainties.**

- The actual abort triggering lives in the runtime's reaction handling, not in this file.

<a id="u-766cb9a97e53"></a>
### `throw_rune_error`

`function throw_rune_error(rune)` · [packages/svelte/src/index-client.js:L16-L36][f1]

Dev-only guard that makes referencing a rune like `$state` outside Svelte throw a friendly error.

For each rune name not already on `globalThis`, it defines a configurable property whose getter throws `e.rune_outside_svelte(rune)` until a value has been assigned, and whose setter stores the value so subsequent reads return it. Called at module load for `$state`, `$effect`, `$derived`, `$inspect`, `$props`, and `$bindable` when `DEV` is true.

**Notes.**

- side_effect: Defines globalThis properties as a module-load side effect under DEV.

**Uncertainties.**

- If code sets the global to undefined after assigning a value, reads throw again because the undefined check resets to the error path.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/index-client.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/shared/utils.js
