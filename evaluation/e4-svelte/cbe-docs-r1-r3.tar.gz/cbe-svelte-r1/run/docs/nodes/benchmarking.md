# Reactivity & SSR Benchmarking

**Capability.** Measures performance of the reactivity system and the compile-to-render path: kairo signal-topology suites (deep chains, triangle fan-in, fan-out, repeated-read costs), signal/derived throughput and derived-graph update costs driven directly from internals, SSR wrapper compile/render throughput, and a child-process runner that forks per benchmark and aggregates results, including cross-branch comparison.

Run these to detect regressions in the signal runtime or SSR path; each suite times one graph shape and asserts its own correctness afterwards. Nothing here ships in the library. Uncertainty: harness execution details beyond the timing loops are not captured in the units.

**Depends on.**

- [Client Runtime](client-runtime.md) · model-inferred · 0 edge(s) · Benchmark suites drive the client reactivity internals directly to time signal graph shapes.
- [Build & Repo Tooling](repo-tooling.md) · model-inferred · 0 edge(s)
- [Server Runtime](server-runtime.md) · model-inferred · 0 edge(s)

Parent: [Svelte Monorepo](svelte-monorepo.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
