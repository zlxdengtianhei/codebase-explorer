# Element attribute typing system

**Capability.** Owns the layered interface family for every HTML/SVG element and Svelte special element: base vocabularies, shared attribute interfaces, per-element interfaces, and the tag-name-to-attributes mapping.

Use the mapping (SvelteHTMLElements) as the entry point; follow its extends chain to HTMLAttributes/SVGAttributes and their ARIA/DOM-event bases to see which attributes and bindings each element admits. Uncertainty: only interface-level units are captured here, not the full per-element interface bodies.

Parent: [Type contracts](r2-type-definitions.md)

## Units (9)

<a id="u-85b3a60ae163"></a>
### `elements-d-ts-element-attribute-interfaces`

`export interface HTMLAnchorAttributes extends HTMLAttributes<HTMLAnchorElement>` · [packages/svelte/elements.d.ts:L880-L890][f1]

Family of per-element attribute interfaces, each extending HTMLAttributes (or HTMLMediaAttributes) with the concrete element type and adding only that element's attributes and bindings.

Common patterns: method/enctype literals accepted in both casings ('get'|'GET') in HTMLButtonAttributes and HTMLFormAttributes; HTMLButtonAttributes adds command (open union with (string & {})) and commandfor plus popovertarget/action; HTMLDetailsAttributes adds bind:open and narrows toggle handlers to HTMLDetailsElement; HTMLImgAttributes adds readonly bind:naturalWidth/naturalHeight; HTMLLinkAttributes enumerates the full as= rel-preload destination union; deprecated iframe attributes (frameborder, marginheight, marginwidth, scrolling) remain typed. HTMLMediaAttributes<T extends HTMLMediaElement> adds media attributes plus readonly bind:readyState (0–4), duration, buffered/played/seekable as SvelteMediaTimeRange[], seeking, ended, and writable bind:muted/volume/currentTime/playbackRate/paused; HTMLAudioAttributes and HTMLVideoAttributes extend it, video adding bind:videoWidth/Height and poster. HTMLInputAttributes carries both defaultValue/defaultvalue and defaultChecked/defaultchecked casings (for language tools lowercasing names), webkitdirectory, autocorrect, group: any, and bind:value/checked/group/files/indeterminate, narrowing its own change handlers to HTMLInputElement; HTMLSelectAttributes and HTMLTextareaAttributes similarly narrow change handlers and add bind:value. All members are compile-time only.

**Notes.**

- contract: Readonly bind: properties (measurements, media state) model one-way bindings; writable bind: properties allow two-way binding.
- condition: aria-relevant-style compound unions and (string & {}) escapes in command/controlslist/HTMLAttributeAnchorTarget allow arbitrary strings while keeping literal autocomplete.

inherits: [HTMLAttributes](r2-element-types.md#u-769572c7f4d3); uses: [SvelteMediaTimeRange][f1], [elements-d-ts-event-and-attribute-foundations](r2-element-types.md#u-546f759b925c)

<a id="u-546f759b925c"></a>
### `elements-d-ts-event-and-attribute-foundations`

`type Booleanish = boolean | 'true' | 'false';` · [packages/svelte/elements.d.ts:L38-L38][f1]

Defines the base type vocabulary for Svelte's element typings: Booleanish admits boolean, 'true', 'false' (and null where property types add it, because Svelte treats null like undefined).

EventHandler<E, T> yields a handler whose single parameter is E intersected with { currentTarget: EventTarget & T }, so handlers receive a correctly narrowed currentTarget; its default parameters are Event and Element. Eighteen exported aliases (Clipboard through ContentVisibilityAutoStateChange) each instantiate EventHandler with a specific DOM event type; Form and Change handlers use plain Event. FullAutoFill is a union of AutoFill plus extra literals and template-literal-prefixed tokens. All members are compile-time only; nothing here executes.

**Notes.**

- contract: Every event property in later interfaces is typed as handler | undefined | null, so null is assignable anywhere a handler is expected.

<a id="u-00e9dbdc2f41"></a>
### `AriaAttributes`

`export interface AriaAttributes` · [packages/svelte/elements.d.ts:L479-L676][f1]

Compile-time interface enumerating the WAI-ARIA 1.1 attributes as optional hyphenated keys, each accepting undefined and null.

Boolean-like states use Booleanish; enumerated states are string-literal unions (aria-autocomplete, aria-live, aria-sort, aria-haspopup adding Booleanish, aria-current adding 'page'/'step'/'location'/'date'/'time', aria-invalid adding 'grammar'/'spelling', aria-checked/aria-pressed adding 'mixed', aria-relevant with compound values like 'additions text'); counters, levels and range values are number; identifier references are string. aria-dropeffect and aria-grabbed are marked @deprecated in ARIA 1.1 but remain accepted. Nothing executes.

uses: [elements-d-ts-event-and-attribute-foundations](r2-element-types.md#u-546f759b925c)

<a id="u-b2213dc03cb0"></a>
### `DOMAttributes`

`export interface DOMAttributes<T extends EventTarget>` · [packages/svelte/elements.d.ts:L85-L476][f1]

Type-only interface holding every event-handler attribute and the readonly bind: dimension pseudo-attributes available on any DOM event target.

Each event family appears in three optional spellings: Svelte 'on:event' string keys, camelCase onX, and onXcapture for capture phase; all accept undefined or null. Properties use the matching exported handler alias (click → MouseEventHandler<T>, keydown → KeyboardEventHandler<T>, etc.); load/error use the unparameterized EventHandler; input uses FormEventHandler per the comment that the event type varies by target; submit/invalid/formdata use concrete event types; Svelte transition events (outrostart, introend, etc.) use CustomEvent<null>. Gamepad handlers and mouseenter/mouseleave have no capture variants. children is a Svelte Snippet so spread-props components need no extra interface. The readonly bind: keys (contentRect, contentBoxSize, borderBoxSize, devicePixelContentBoxSize, clientWidth, clientHeight) model one-way measurement bindings; xmlns is a plain optional string.

uses: [elements-d-ts-event-and-attribute-foundations](r2-element-types.md#u-546f759b925c)

**Uncertainties.**

- How 'on:x' vs onX vs onXcapture are dispatched at runtime is defined elsewhere; this file only fixes the accepted key spellings and types.

<a id="u-769572c7f4d3"></a>
### `HTMLAttributes`

`export interface HTMLAttributes<T extends EventTarget> extends AriaAttributes, DOMAtt…` · [packages/svelte/elements.d.ts:L751-L876][f1]

Base attribute interface for all HTML elements, extending AriaAttributes and DOMAttributes<T>, so every element type carries all ARIA and event properties.

It adds standard HTML attributes (id, class as ClassValue, style as string, contenteditable including 'plaintext-only', hidden allowing 'until-found' and '', popover, inert, writingsuggestions, etc.), the role as AriaRole, RDFa and non-standard attributes, and SvelteKit data-sveltekit-* hints with literal unions such as 'eager'|'viewport'|'hover'|'tap'|'off'. Svelte bind: entries cover contenteditable bindings (innerHTML/textContent/innerText, writable) and readonly measurements (focused, offsetWidth, offsetHeight). Two index signatures complete the shape: any `data-${string}` key maps to any, and a symbol key maps to Attachment<T> | false | undefined | null — including false deliberately excludes bare boolean attachment values. Per-element interfaces extend this with their own attributes.

inherits: [AriaAttributes](r2-element-types.md#u-00e9dbdc2f41), [DOMAttributes](r2-element-types.md#u-b2213dc03cb0); uses: [AriaRole][f1], [ClassValue][f1], [elements-d-ts-event-and-attribute-foundations](r2-element-types.md#u-546f759b925c)

**Uncertainties.**

- Whether arbitrary symbol keys other than attachments are rejected at runtime depends on Svelte's prop handling, not this file.

<a id="u-adb80c8bde08"></a>
### `SVGAttributes`

`export interface SVGAttributes<T extends EventTarget> extends AriaAttributes, DOMAttr…` · [packages/svelte/elements.d.ts:L1551-L1844][f1]

Attribute interface for all SVG elements, extending AriaAttributes and DOMAttributes<T> directly rather than HTMLAttributes, then redeclaring the shared HTML properties SVG elements accept (class, id, style, role, tabindex, width/height, etc.).

The bulk is the SVG attribute catalog: presentation attributes (fill, stroke family with literal unions like 'stroke-linecap': 'butt'|'round'|'square'|'inherit'), geometry (cx/cy/r, points, d, viewBox), filter/gradient/animation attributes, plus namespaced keys 'xlink:*', 'xml:*' and 'xmlns:xlink'. Almost every property is `number | string | undefined | null`, looser than the HTML counterparts, and includes a `data-${string}` index signature like HTMLAttributes; unlike HTMLAttributes it has no symbol/attachment index signature. Class is typed as ClassValue, className as plain string.

inherits: [AriaAttributes](r2-element-types.md#u-00e9dbdc2f41), [DOMAttributes](r2-element-types.md#u-b2213dc03cb0); uses: [ClassValue][f1]

**Uncertainties.**

- Why some properties are number|string while structurally similar ones are only string is inherited from the React-derived source; no Svelte-specific rationale is visible in this file.

<a id="u-434def3741e5"></a>
### `SvelteDocumentAttributes`

`export interface SvelteDocumentAttributes extends HTMLAttributes<Document>` · [packages/svelte/elements.d.ts:L1482-L1487][f1]

Attribute interface for <svelte:document>, extending HTMLAttributes<Document> with only four readonly bind: entries — activeElement, fullscreenElement, pointerLockElement and visibilityState — typed from the corresponding Document properties.

It contributes no additional event properties beyond those inherited from DOMAttributes (which already covers document events like visibilitychange).

inherits: [HTMLAttributes](r2-element-types.md#u-769572c7f4d3)

<a id="u-a4bde8899205"></a>
### `SvelteHTMLElements`

`export interface SvelteHTMLElements` · [packages/svelte/elements.d.ts:L1873-L2091][f1]

Mapping of every element tag name to its attribute interface: HTML tags map to the per-element HTML interfaces (most plain elements share HTMLAttributes<HTMLElement> with concrete element types where useful, e.g. div → HTMLDivElement), SVG tags map to SVGAttributes with the corresponding SVG element type, and Svelte-special tags map to dedicated shapes: 'svelte:window' → SvelteWindowAttributes, 'svelte:document' → SvelteDocumentAttributes, 'svelte:body' → HTMLAttributes<HTMLElement>, 'svelte:fragment' → { slot?

}, 'svelte:head' → an any-valued index signature, 'svelte:boundary' → onerror handler plus failed/pending Snippets, and 'svelte:options' with customElement (string or an object with tag/shadow/props/extend), immutable, accessors, namespace and a catch-all index signature. A final `[name: string]: { [name: string]: any }` index signature makes any unknown tag name type-check, so misspelled tags are not caught by this type.

**Notes.**

- failure: The trailing string index signature means unknown or misspelled element names resolve to { [name: string]: any } rather than a type error.

uses: [SvelteWindowAttributes](r2-element-types.md#u-9017cd4cac09), [SvelteDocumentAttributes](r2-element-types.md#u-434def3741e5), [SVGAttributes](r2-element-types.md#u-adb80c8bde08), [elements-d-ts-element-attribute-interfaces](r2-element-types.md#u-85b3a60ae163)

**Uncertainties.**

- Whether the index signature weakens autocomplete/error detection in a specific consumer's TypeScript version depends on TS behavior, not stated here.

<a id="u-9017cd4cac09"></a>
### `SvelteWindowAttributes`

`export interface SvelteWindowAttributes extends HTMLAttributes<Window>` · [packages/svelte/elements.d.ts:L1489-L1549][f1]

Attribute interface for <svelte:window>, extending HTMLAttributes<Window>.

Readonly bind: entries expose viewport measurements (innerWidth/Height, outerWidth/Height, devicePixelRatio) and online status; bind:scrollX/scrollY are writable two-way bindings. It then declares window-specific events in all three spellings (with capture variants where present), typed with concrete event classes: storage → StorageEvent, hashchange → HashChangeEvent, pagehide/pageshow → PageTransitionEvent, popstate → PopStateEvent, beforeunload → BeforeUnloadEvent, message family → MessageEvent, promise rejection events, device motion/orientation events. Non-standard events like devicelight, deviceproximity, paint and userproximity use plain Event handlers. Note ondevicemotion uses EventHandler<DeviceMotionEvent> without the Window target parameter, unlike its siblings.

**Notes.**

- condition: All bind: measurement properties are readonly (one-way); only scrollX/scrollY are writable.

inherits: [HTMLAttributes](r2-element-types.md#u-769572c7f4d3)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/elements.d.ts
