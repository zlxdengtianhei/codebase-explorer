# Server Transform

**Capability.** Generates SSR code: template chunk builders that append to $$payload.out, attribute value compilation, identifier getters, and visitors for fragments and <svelte:title>.

Use to see how markup becomes string-appending statements; all output escapes through the shared escape_html. build_template and process_children are the shared backbone.

**Depends on.**

- [Shared AST Utilities](r5-compiler-ast-utils.md) · model-inferred · 0 edge(s)
- [Shared Runtime Libraries](r5-shared-lib.md) · graph-confirmed · 3 edge(s)

**Depended on by.**

- [Server Transform Phase](r1-server-transform.md) · graph-only · 15 edge(s)

Parent: [Transform Phase](r5-transform.md)

## Units (6)

<a id="u-356cef502838"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/SvelteFragment.js:SvelteFragment`

`export function SvelteFragment(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/SvelteFragment.js:L9-L11][f1]

Handles <svelte:fragment> in SSR output by visiting the node's fragment and pushing the resulting BlockStatement onto state.template, emitting it as a nested block of template statements.

**Uncertainties.**

- Whether context.visit can return something other than a BlockStatement is guarded only by a type cast.

<a id="u-781a760465d0"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/TitleElement.js:TitleElement`

`export function TitleElement(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/TitleElement.js:L10-L17][f2]

Compiles <svelte:title> by rendering its text/expression children between literal <title> tags into a separate template, then assigning the built template to $$payload.title via init statements (build_template with target $$payload.title and operator '=').

calls: [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/utils.js:process_children (2)](r5-server-transform.md#u-21d2acc05779)

<a id="u-8ce176223a22"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/utils.js:build_attribute_value`

`export function build_attribute_value( value, context, trim_whitespace = false, is_co…` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/utils.js:L185-L233][f3]

Converts an attribute value (boolean `true`, a single chunk, or an array of Text/ExpressionTag chunks) into an estree expression.

`true` yields b.true. A single Text chunk becomes a string literal, whitespace-normalized when trim_whitespace is set, and HTML-escaped via escape_html unless is_component is true (component props are not escaped). A single expression chunk is visited directly. Multiple chunks become a template literal whose static parts keep raw text (whitespace-normalized when trimming, not escaped) and whose dynamic parts are wrapped in `$.stringify` calls on the visited expressions.

calls: [escape_html](r5-shared-lib.md#u-0f499dd45547); uses: [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/component.js:build_inline_component](r3-compiler-transform-server.md#u-cca955f8230f)

**Uncertainties.**

- $.stringify runtime behavior is defined outside this file

<a id="u-25646e8536b2"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/utils.js:build_getter`

`export function build_getter(node, state)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/utils.js:L240-L259][f3]

Produces the read expression for an identifier reference in the server transform.

When scope lookup finds no binding, or the identifier is the binding's own declaration node, the identifier is returned unchanged. For `store_sub` bindings ($-prefixed store access) it returns a `$.store_get` call that lazily initializes `$$store_subs` to an object, keyed by the original name, reading the underlying store name via a recursive build_getter call. All other identifiers are returned unchanged.

calls: [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/utils.js:build_getter](r5-server-transform.md#u-25646e8536b2)

**Uncertainties.**

- Scope/binding metadata construction lives in the analysis phase, not visible here

<a id="u-303aa62127d6"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/utils.js:build_template`

`export function build_template(template, out = b.id('$$payload.out'), operator = 'push')` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/utils.js:L141-L175][f3]

Compiles a mixed list of statements and expressions into a flat statement list that appends template chunks to an output identifier (default `$$payload.out`).

Consecutive expression items are coalesced into one tagged template: Literal strings extend the current string chunk, TemplateLiterals merge their quasis and expressions, and any other expression opens a new chunk. When a statement item is reached (detected via is_statement) or the list ends with pending content, flush emits either an `out.push(...)` call (operator 'push') or an assignment using the given operator, then resets the buffers. Statements pass through unchanged in order.

calls: [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/utils.js:build_template](r5-server-transform.md#u-303aa62127d6)

<a id="u-21d2acc05779"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/utils.js:process_children (2)`

`export function process_children(nodes, { visit, state })` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/utils.js:L66-L86][f3]

Walks an array of template nodes, buffering adjacent Text, Comment, and ExpressionTag siblings and flushing each run into a single template literal pushed to state.template; other node kinds are visited immediately with a copied state after flushing any pending run, and a trailing run is flushed after the loop.

The flush builds a template whose static quasis accumulate escaped text (`<!--...-->` for comments) and known-value expression results (via state.scope.evaluate; null becomes ''), while unknown expressions become `$.escape` calls on the visited expression. Each quasi's raw value is derived with sanitize_template_string, and the final quasi is tagged as tail based on position within the run.

calls: [sanitize_template_string](r3-compiler-shared-utils.md#u-01781e43d6ff), [escape_html](r5-shared-lib.md#u-0f499dd45547)

**Uncertainties.**

- The result of state.scope.evaluate for known values relies on scope analysis not visible in this file

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/SvelteFragment.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/TitleElement.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/utils.js
