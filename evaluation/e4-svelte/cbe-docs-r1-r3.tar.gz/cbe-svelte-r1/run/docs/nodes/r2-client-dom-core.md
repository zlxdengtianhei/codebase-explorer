# DOM primitives: operations and templates

**Capability.** Owns low-level DOM creation, mutation and traversal (operations.js) and the memoized template factories that build/hydrate fragments from HTML, trees or namespaces while recording block extents.

Everything else in the client runtime builds on these primitives. template.js factories create anchors and assign nodes_start/end on the active effect; operations.js captures hot browser globals once and provides cached node navigation. Read here before any block or element code.

**Depended on by.**

- [Block rendering: slots, components, head](r2-client-dom-blocks.md) · graph-confirmed · 6 edge(s)
- [Element integrations: custom elements, actions, bindings](r2-client-dom-elements.md) · graph-confirmed · 1 edge(s)
- [DOM Blocks](r3-runtime-dom-blocks.md) · graph-only · 13 edge(s)
- [Mount, Hydrate & Unmount](r1-client-mounting.md) · graph-only · 8 edge(s)

Parent: [Client runtime](r2-client-runtime.md)

## Units (14)

<a id="u-d9a22fc32463"></a>
### `operations.js-dom-helpers`

`export function clear_text_content(node)` · [packages/svelte/src/internal/client/dom/operations.js:L206-L208][f1]

Small DOM creation/mutation helpers.

`clear_text_content` empties `textContent`. `should_defer_append` reports whether a block branch change should be batched with other updates in the current boundary: false when async mode is off or `eager_block_effects` is non-null; otherwise it reads the active effect's flags and returns whether EFFECT_RAN is set. `create_element(tag, namespace, is)` uses createElementNS when a namespace is given, otherwise createElement, passing `{ is }` only when `is` is supplied. `create_fragment` and `create_comment` wrap document factory calls. `set_attribute` routes keys starting with `xlink:` to setAttributeNS with the xlink namespace, else setAttribute with a default empty value.

**Notes.**

- condition: should_defer_append's three-way result depends on async_mode_flag, the module-level eager_block_effects, and EFFECT_RAN on the active effect.

uses: [operations.js module code (L1–L29)][f1]

<a id="u-a31f01c2fa93"></a>
### `operations.js-node-navigation`

`export function create_text(value = '')` · [packages/svelte/src/internal/client/dom/operations.js:L79-L81][f1]

Cached-getter node traversal plus hydration-aware child access.

`get_first_child` and `get_next_sibling` call prototype getters captured by init_operations; they fail before init. `child(node, is_text)`: when not hydrating it just returns the node's first child. While hydrating it reads the first child of `hydrate_node`; if there is none (e.g. `<p>{text}</p>` with empty text) it appends a fresh empty text node; if a text node is expected but the child is not text, it creates a text node, inserts it before the child, advances the cursor to it via set_hydrate_node, and returns it instead. `first_child(fragment, is_text)`: when not hydrating, `fragment` is a DocumentFragment; it skips an empty-string user comment (skipping to its next sibling) and returns the first real node. While hydrating, if a text node is expected and the cursor isn't text, it inserts a fresh empty text node before the cursor, advances the cursor, and returns it; otherwise returns `hydrate_node`. `sibling(node, count, is_text)`: walks `count` next-siblings starting from `hydrate_node` while hydrating or from `node` otherwise. Non-hydrating returns the reached node directly. Hydrating with a text expectation but a non-text (or null) sibling inserts a new text node after the last sibling (or before the non-text sibling), advances the cursor, and returns it; otherwise it advances the cursor via set_hydrate_node. These functions are deliberately not side-effect-free because hydration must walk all nodes.

**Notes.**

- side_effect: During hydration child/first_child/sibling mutate the DOM by inserting synthetic empty text nodes and advance the global hydrate_node cursor.
- condition: Behavior changes completely with the `hydrating` flag; each function documents a separate branch for hydrating vs not.

calls: [hydration.js-state-and-guards](r1-hydration-cursor.md#u-f1b7a30a3c1f); contract: [init_operations](r2-client-dom-core.md#u-eb7a9f0e7810)

**Uncertainties.**

- If init_operations has not run, first_child_getter/next_sibling_getter are undefined and traversal calls would throw; this file shows no guard.

<a id="u-eb7a9f0e7810"></a>
### `init_operations`

`export function init_operations()` · [packages/svelte/src/internal/client/dom/operations.js:L30-L73][f1]

Lazily captures browser globals and hot-path prototype slots once per runtime.

It returns immediately if `$window` is already set. Otherwise it stores `window`, `document`, a Firefox UA test, and the `firstChild`/`nextSibling` getter descriptors from Node.prototype. If Element.prototype is extensible it pre-declares hidden slots (`__click`, `__className`, `__attributes`, `__style`, `__e`), and similarly `__t` on Text.prototype, so later property writes are fast. In DEV it adds `__svelte_meta` and installs Array.prototype mutation warnings via `init_array_prototype_warnings`.

**Notes.**

- side_effect: Mutates shared DOM prototypes and module-level $window/$document/is_firefox state; only runs once thanks to the $window guard.

calls: [init_array_prototype_warnings](r3-runtime-dev-tools.md#u-3c0065301141)

<a id="u-daaa1d70e416"></a>
### `append`

`export function append(anchor, dom)` · [packages/svelte/src/internal/client/dom/template.js:L342-L355][f2]

Finishes placing a template's DOM: sets the block's end anchor and inserts the content.

While hydrating it sets the active effect's `nodes_end` to the current cursor and advances the cursor via hydrate_next, inserting nothing. When not hydrating with a null anchor (void `<svelte:element>` with content) it returns without inserting. Otherwise it inserts the fragment/element before the anchor.

calls: [hydration.js-state-and-guards](r1-hydration-cursor.md#u-f1b7a30a3c1f)

<a id="u-081194bea535"></a>
### `assign_nodes`

`export function assign_nodes(start, end)` · [packages/svelte/src/internal/client/dom/template.js:L29-L35][f2]

Records the DOM extent of a template on the active effect, but only for the first caller: it sets `nodes_start`/`nodes_end` on `active_effect` only if `nodes_start` is still null, so nested template functions cannot overwrite the outer block's anchors.

<a id="u-2c649b4b25d0"></a>
### `comment`

`export function comment()` · [packages/svelte/src/internal/client/dom/template.js:L319-L334][f2]

Creates the two-node anchor pair for a block: a start comment and an empty text anchor inside a fresh DocumentFragment, assigned as nodes_start/nodes_end.

While hydrating it instead assigns the current cursor as start (end null) and returns it, letting the existing SSR comment serve as the anchor. Inlined rather than reusing the template factories for performance.

<a id="u-2d74ac8bccad"></a>
### `fragment_from_tree`

`function fragment_from_tree(structure, ns)` · [packages/svelte/src/internal/client/dom/template.js:L161-L201][f2]

Recursively materializes a TemplateStructure tree into a DocumentFragment.

Each item is handled by case: a string becomes a text node; `undefined` or an array whose first element starts with `/` becomes a comment (data taken from the string minus the `//` prefix, preserving comments); otherwise the item is `[name, attributes, ...children]` and an element is created with a namespace of SVG for `svg`, MathML for `math`, the inherited namespace otherwise, and an `is` option from attributes. Attributes are applied via set_attribute. Children are recursively converted and appended into the element's `.content` when it's a `<template>`, else into the element itself, with `foreignObject` resetting the namespace to undefined for its subtree. The element is finally appended to the fragment.

**Notes.**

- condition: Namespace selection: 'svg' and 'math' tags force their namespaces; nested elements inherit; 'foreignObject' children revert to the default namespace.

calls: [operations.js-dom-helpers](r2-client-dom-core.md#u-d9a22fc32463)

<a id="u-7aedb33d1cff"></a>
### `from_html`

`export function from_html(content, flags)` · [packages/svelte/src/internal/client/dom/template.js:L43-L82][f2]

Builds a memoized factory for an HTML template.

Flags control whether the template is a multi-node fragment and whether importNode is preferred. If content doesn't start with `<!>`, a leading `<!>` comment is prepended on first parse so the fragment has a start anchor node. On each factory call while hydrating it assigns the current cursor (`assign_nodes(hydrate_node, null)`) and returns it. Otherwise the content is parsed once via create_fragment_from_html (taking the sole child when not a fragment) and cached; each call clones it with importNode (forced when is_firefox, or when the import-node flag is set) or cloneNode(true), then assigns anchors: for fragments the first and last children, for single nodes the clone itself as both start and end.

**Notes.**

- condition: First call parses and caches; subsequent calls only clone, so hydration vs client mode determines whether any DOM is created.

calls: [create_fragment_from_html](r4-dom-elements.md#u-f51e86a3ef3c), [assign_nodes](r2-client-dom-core.md#u-081194bea535)

**Uncertainties.**

- Whether the non-fragment cached node is an element or fragment relies on the input HTML having a single root; the type assertions are unchecked at runtime.

<a id="u-7fbca348f563"></a>
### `from_namespace`

`function from_namespace(content, flags, ns = 'svg')` · [packages/svelte/src/internal/client/dom/template.js:L91-L137][f2]

Namespace-aware variant of the template factory for SVG and MathML.

It wraps content in `<svg>`/`<math>` tags (plus a leading `<!>` when content doesn't start with one) so the browser parses it in the right namespace, then on first call extracts either the single root element or, for fragment templates, moves all children into a fresh DocumentFragment. Factory calls behave like from_html: hydrating mode assigns the cursor and returns it; otherwise the cached node is cloned (always cloneNode(true), no importNode path here) and anchors are assigned as first/last children for fragments or the clone itself otherwise.

calls: [create_fragment_from_html](r4-dom-elements.md#u-f51e86a3ef3c), [assign_nodes](r2-client-dom-core.md#u-081194bea535)

**Uncertainties.**

- Unlike from_html/from_tree, this clone path never uses importNode, which may matter for Firefox namespace edge cases; no rationale is visible here.

<a id="u-4b6a1b3dac13"></a>
### `from_tree`

`export function from_tree(structure, flags)` · [packages/svelte/src/internal/client/dom/template.js:L209-L249][f2]

Factory equivalent of from_html but built from a structured TemplateStructure tree instead of an HTML string.

Flags select fragment mode, importNode use, and the SVG/MathML namespace. On first call (not hydrating) it builds the node with fragment_from_tree, taking the sole child when not a fragment; subsequent calls clone it (importNode when the flag is set or on Firefox). While hydrating it assigns the cursor and returns it. Anchor assignment matches from_html: first/last child for fragments, the clone for single nodes.

calls: [fragment_from_tree](r2-client-dom-core.md#u-2d74ac8bccad), [assign_nodes](r2-client-dom-core.md#u-081194bea535)

<a id="u-fafca980132c"></a>
### `props_id`

`export function props_id()` · [packages/svelte/src/internal/client/dom/template.js:L360-L377][f2]

Produces a unique component-scoped id, honoring SSR'd ids during hydration.

If hydrating and the cursor is a comment whose text starts with `#`, the id is that text minus the `#` and the cursor advances via hydrate_next. Otherwise a global counter on `window.__svelte` is initialized (`uid ??= 1`) and the id is `c` plus the counter's post-increment value, keeping ids unique even across multiple Svelte runtimes on the page.

<a id="u-7f6237181fe0"></a>
### `run_scripts`

`function run_scripts(node)` · [packages/svelte/src/internal/client/dom/template.js:L264-L294][f2]

Makes inert script tags from parsed HTML execute by replacing each with a fresh `<script>` element copying all attributes and text content.

Returns the node unchanged while hydrating (server-rendered scripts already ran). Otherwise it detects whether the node is a fragment; the script list is either the node itself when it is a single `<script>` element or its `querySelectorAll('script')` result. For each script it checks edge membership: if the script is the fragment's first/last child (or the node itself for the single-element case), the active effect's `nodes_start`/`nodes_end` is repointed at the clone so block anchors don't reference dead nodes, then replaces the original.

**Notes.**

- side_effect: Mutates the DOM by replacing script nodes and may reassign active_effect.nodes_start/nodes_end.

<a id="u-e16a3d523a46"></a>
### `packages/svelte/src/internal/client/dom/template.js:text`

`export function text(value = '')` · [packages/svelte/src/internal/client/dom/template.js:L300-L317][f2]

Creates or hydrates a text node and records it as the block's extent.

When not hydrating, it creates a text node from `String(value)`, assigns it as both start and end, and returns it. While hydrating, if the cursor is not a text node (empty SSR expression), it inserts a fresh empty text node before the cursor, advances the cursor via set_hydrate_node, and uses that node; in both cases it assigns the node as both anchors and returns it.

calls: [hydration.js-state-and-guards](r1-hydration-cursor.md#u-f1b7a30a3c1f)

<a id="u-d64f9d08a8de"></a>
### `with_script`

`export function with_script(fn)` · [packages/svelte/src/internal/client/dom/template.js:L254-L256][f2]

Wraps a template factory so its produced element or fragment passes through `run_scripts`, which re-creates `<script>` tags so they execute.

Returns a new zero-argument function invoking run_scripts on fn's result.

calls: [run_scripts](r2-client-dom-core.md#u-7f6237181fe0)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/operations.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/template.js
