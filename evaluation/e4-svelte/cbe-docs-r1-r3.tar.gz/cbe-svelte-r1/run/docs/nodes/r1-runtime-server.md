# Server Runtime

**Capability.** Renders components to HTML strings on the server, with dev-time HTML nesting validation and server-specific error throwing.

Use this for everything behind svelte/server. ssr-core contains the compiled $.-helpers the server transform emits; ssr-dev adds validation warnings and lifecycle guards only in dev.

**Children.**

- [SSR Rendering Helpers](r1-ssr-core.md) `r1-ssr-core` · 29 unit(s)
- [SSR Dev Validation](r1-ssr-dev.md) `r1-ssr-dev` · 6 unit(s)

Parent: [Svelte Monorepo](r1-root.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
