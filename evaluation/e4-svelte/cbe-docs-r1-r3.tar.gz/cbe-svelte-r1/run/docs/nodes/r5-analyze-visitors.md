# Analyze Visitors

**Capability.** Per-node-type visitors that validate directives, blocks, components, and special elements, and mark expression metadata (has_call/has_state) for downstream transforms.

Consult per syntax feature to learn its constraints and error codes. visit_component is the shared path for <svelte:component>/<svelte:self>/components.

**Depends on.**

- [Shared AST Utilities](r5-compiler-ast-utils.md) · graph-confirmed · 15 edge(s)
- [Fuzzy Match Diagnostics](r5-parse-diagnostics.md) · graph-confirmed · 1 edge(s)
- [Analysis validation core](r2-analyze-shared-validation.md) · graph-only · 15 edge(s)
- [Analysis Infrastructure & Visitor Helpers](r1-analysis-infra.md) · graph-only · 11 edge(s)

Parent: [Analyze Phase](r5-analyze.md)

## Units (21)

<a id="u-53d5dba31656"></a>
### `attachtag-classdirective-spreadattribute-js`

`export function AttachTag(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/AttachTag.js:L10-L13][f1]

Directive/attribute visitors that mark their subtree dynamic and propagate expression metadata.

AttachTag, ClassDirective, and SpreadAttribute each call `mark_subtree_dynamic(context.path)` and continue with `context.next({...context.state, expression: node.metadata.expression})`, so code inside them is analyzed with the node's expression as the current dynamic expression.

calls: [mark_subtree_dynamic](r1-analysis-infra.md#u-3e6e9a44c2b4)

<a id="u-e78635f9b260"></a>
### `packages/svelte/src/compiler/phases/2-analyze/visitors/AwaitBlock.js:AwaitBlock`

`export function AwaitBlock(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/AwaitBlock.js:L11-L48][f2]

Analyzes `{#await}` blocks: checks pending/then/catch sub-blocks are non-empty, and in runes mode validates the opening tag and scans source text before the value/error positions for `{ :then`/`{ :catch` whose whitespace group is non-empty, raising block_unexpected_character in that case (an empty group passes).

Marks the subtree dynamic, then visits the expression with its metadata as expression state, and each present sub-block. Sub-block absence is tolerated by validate_block_not_empty's per-argument call; failure behavior of empty blocks is decided there.

**Notes.**

- failure: block_unexpected_character is thrown only in runes mode and only when the 10 characters before the value/error contain `{` + whitespace + `:then`/`:catch` with a non-whitespace-including group match failing the empty capture

calls: [validate_block_not_empty](r2-analyze-shared-validation.md#u-b877c3a87dc5), [validate_opening_tag](r2-analyze-shared-validation.md#u-8a95b3b7e6dc), [mark_subtree_dynamic](r1-analysis-infra.md#u-3e6e9a44c2b4)

<a id="u-1731905f5fa9"></a>
### `AwaitExpression`

`export function AwaitExpression(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/AwaitExpression.js:L9-L39][f3]

Analyzes `await` expressions and decides whether the await suspends.

suspend starts true only for awaits in an instance script at function_depth 1 (top-level component await). If expression metadata exists, has_await is set; if also inside a ConstTag in the path, the fragment's has_await is set; suspend becomes true. When suspend, missing `experimental.async` option throws experimental_async, and non-runes mode additionally throws legacy_await_invalid — both propagate, so no traversal occurs. Otherwise just context.next().

uses: [validate_assignment](r2-analyze-shared-validation.md#u-83497fe81c11)

**Uncertainties.**

- exact semantics of function_depth and ast_type are defined by the caller and not visible here

<a id="u-95b9d2cc9f5c"></a>
### `BindDirective`

`export function BindDirective(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/BindDirective.js:L20-L254][f4]

Validates a bind: directive against its parent element and the bound expression.

For element parents (RegularElement, SvelteElement, SvelteWindow/Document/Body): if the binding name is a known binding_property, it errors on invalid targets (valid_elements/invalid_elements), enforces <input type> rules — non-text type attributes are rejected for non-value bindings, bind:checked requires type=checkbox and bind:files requires type=file — rejects bind:multiple on selects with a dynamic multiple attribute, forbids offsetWidth on SVG elements, and requires a static contenteditable attribute for content-editable bindings. Unknown names trigger fuzzymatch-based suggestions (only when the suggestion is valid for the parent) followed by a generic bind_invalid_name error. For getter/setter SequenceExpression bindings: bind:group errors, parentheses in source trigger bind_invalid_parens unless inside leading comments, an expression of exactly two parts is required, and the function marks the subtree dynamic and returns early. Otherwise validate_assignment runs, a null left object errors, plain identifier reassignment is rejected unless the binding kind is state/raw_state/prop/bindable_prop/each/store_sub or already updated. bind:group additionally requires a binding (throws a plain Error if missing), rejects snippet parameters, walks the path to mark contributing EachBlocks and collect their declarations, reuses or creates a binding group name keyed by identifier keypath and bindings, and records parent_each_blocks metadata. An each-rest binding warns. Finally context.next() continues traversal.

**Notes.**

- side_effect: Registers EachBlock metadata.contains_group_binding, allocates a unique binding_group name via scope.root.unique, and replaces node.metadata with the group name and parent each blocks.
- failure: All validation failures throw compiler errors (e.bind_* / e.attribute_*); bind:group with a missing binding throws a plain Error('Cannot find declaration for bind:group').
- condition: The parens scan walks backwards over raw source until it finds '{', and skips the error when the '(' lies within leading comment bounds.

calls: [fuzzymatch](r5-parse-diagnostics.md#u-4d517976b3f9), [validate_assignment](r2-analyze-shared-validation.md#u-83497fe81c11), [ScopeRoot](r4-compiler-model.md#u-8f49475011d6), [extract_all_identifiers_from_expression](r5-compiler-ast-utils.md#u-4fc74297abd5), [is_text_attribute](r5-compiler-ast-utils.md#u-ec400088cae5), [object](r5-compiler-ast-utils.md#u-2f2548aeaec6), [is_content_editable_binding](r1-dom-dom-utils.md#u-e47baf4ced62), [is_svg](r1-dom-dom-utils.md#u-890d02cea75e), [mark_subtree_dynamic](r1-analysis-infra.md#u-3e6e9a44c2b4)

**Uncertainties.**

- The meaning of the binding.updated check in the reassignment branch carries a 'TODO wut?' comment in source; its exact semantics are not derivable from this file.
- The comparison between keypath and group entries assumes identifier order encodes the key, as the source's own comment notes edge cases like bind:group={a[i]} vs {a[j]}.

<a id="u-9e857900ba69"></a>
### `packages/svelte/src/compiler/phases/2-analyze/visitors/ExportNamedDeclaration.js:ExportNamedDeclaration`

`export function ExportNamedDeclaration(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/ExportNamedDeclaration.js:L10-L70][f5]

Analyzes named exports after visiting children so bindings exist.

Any specifier exporting the name 'default' inside a component/module script throws module_illegal_default_export. For variable declarations: runes-mode instance scripts reject `export let` (legacy_export_invalid); each declared binding is checked — derived bindings throw derived_invalid_export, and reassigned state/raw_state bindings throw state_invalid_export. In runes mode, instance-level exported functions, classes and `const` declarations are recorded in analysis.exports with null alias.

calls: [extract_identifiers](r5-compiler-ast-utils.md#u-90eb95affc00)

**Uncertainties.**

- behavior when node.declaration exists but is neither Function/ClassDeclaration nor a VariableDeclaration with kind (e.g. other kinds) is not handled here

<a id="u-548da3ff718c"></a>
### `ExpressionTag`

`export function ExpressionTag(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/ExpressionTag.js:L11-L26][f6]

Analyzes `{expr}` text tags.

When the tag sits directly in a template Fragment and a parent element is known, HTML content-model validation runs; an invalid text-in-parent combination throws node_invalid_placement. The subtree is then marked dynamic (needed even for constant expressions like `{42}`), and children are traversed with this tag's expression metadata so inner identifiers record state/call/await flags there.

calls: [mark_subtree_dynamic](r1-analysis-infra.md#u-3e6e9a44c2b4), [is_tag_valid_with_parent](r1-html-tree-validation.md#u-a93dfa56dc6d)

<a id="u-9bef204c5de7"></a>
### `packages/svelte/src/compiler/phases/2-analyze/visitors/IfBlock.js:IfBlock`

`export function IfBlock(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/IfBlock.js:L10-L27][f7]

Analyzes `{#if}`/`{:else if}` blocks.

Consequent and alternate must be non-empty (validate_block_not_empty). In runes mode the opening tag is validated, using ':' as the marker for else-if branches and '#' otherwise. The subtree is marked dynamic, the test expression is visited with the block's expression metadata, then the consequent and any alternate are visited. Errors from the validators propagate before any traversal.

calls: [validate_block_not_empty](r2-analyze-shared-validation.md#u-b877c3a87dc5), [mark_subtree_dynamic](r1-analysis-infra.md#u-3e6e9a44c2b4)

<a id="u-f5a889520a52"></a>
### `LetDirective`

`export function LetDirective(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/LetDirective.js:L9-L24][f8]

Validates `let:` directive placement.

The directive is legal only when its immediate parent is a Component, RegularElement, SlotElement, SvelteElement, SvelteComponent, SvelteSelf, or SvelteFragment; a missing parent or any other parent throws let_directive_invalid_placement, which propagates. No traversal or state change occurs in this visitor.

**Uncertainties.**

- whether binding names themselves are validated elsewhere is not visible here

<a id="u-97612de06878"></a>
### `MemberExpression`

`export function MemberExpression(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/MemberExpression.js:L10-L28][f9]

Analyzes member expressions.

If object and property are identifiers and the object's binding is a rest_prop whose property name starts with `$$`, props_illegal_name is thrown. When expression metadata exists, has_member_expression is set and has_state is OR-ed with `!is_pure(node, context)` — impure member access marks the enclosing expression stateful. If the identifier is not a safe identifier, analysis.needs_context is set so the component gets reactive context. Always traverses via context.next().

calls: [is_pure](r2-analyze-shared-validation.md#u-c8c562a3fb44), [is_safe_identifier](r2-analyze-shared-validation.md#u-63a6d609f552)

<a id="u-317efed2ef7a"></a>
### `packages/svelte/src/compiler/phases/2-analyze/visitors/SlotElement.js:SlotElement`

`export function SlotElement(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/SlotElement.js:L12-L42][f10]

Analyzes `<slot>` elements.

In runes mode outside custom elements, slot_element_deprecated is warned. The subtree is marked dynamic. The slot name defaults to 'default': a `name` attribute must be a static text attribute (else slot_element_invalid_name) and must not equal 'default' (slot_element_invalid_name_default); any attribute other than Attribute, SpreadAttribute or LetDirective throws slot_element_invalid_attribute. The resolved name/node pair is recorded in analysis.slot_names, then children are traversed.

calls: [is_text_attribute](r5-compiler-ast-utils.md#u-ec400088cae5), [mark_subtree_dynamic](r1-analysis-infra.md#u-3e6e9a44c2b4)

<a id="u-835ee6b14ea5"></a>
### `SpreadElement`

`export function SpreadElement(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/SpreadElement.js:L8-L16][f11]

Marks spread expressions inside tracked expressions as calls with state: when expression metadata exists, has_call and has_state are both set, treating `[...x]` like `[...x.values()]`.

Otherwise a no-op beyond traversal via context.next().

**Notes.**

- side_effect: any spread forces the enclosing expression metadata to has_state = true, affecting downstream reactivity decisions

<a id="u-e9c21a24251a"></a>
### `StyleDirective`

`export function StyleDirective(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/StyleDirective.js:L11-L38][f12]

Analyzes `style:` directives.

More than one modifier, or any modifier other than the single 'important', throws style_directive_invalid_modifier. The subtree is marked dynamic. For shorthand form (`style:property` with value === true), the property's binding is looked up and, if bound to something other than kind 'normal', the directive's expression metadata is marked has_state; no traversal happens. For the valued form, children are traversed, then each ExpressionTag chunk's state/call/await flags are OR-ed into the directive's metadata.

calls: [get_attribute_chunks](r5-compiler-ast-utils.md#u-1096ddb4c2b1), [mark_subtree_dynamic](r1-analysis-infra.md#u-3e6e9a44c2b4)

<a id="u-f5aa541ce160"></a>
### `SvelteBoundary`

`export function SvelteBoundary(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/SvelteBoundary.js:L11-L27][f13]

Analyzes `<svelte:boundary>` attributes.

Every attribute must be a plain Attribute named onerror, failed or pending — anything else throws svelte_boundary_invalid_attribute. Its value must be a single ExpressionTag: shorthand (`value === true`) or a non-single/malformed value array throws svelte_boundary_invalid_attribute_value. Errors propagate before traversal; otherwise context.next() visits children.

**Uncertainties.**

- the strictness for value arrays other than exactly one ExpressionTag is implemented here; whether non-array non-true values (e.g. Text) reach the Array.isArray branch is implied but not separately validated

<a id="u-92b20617b51f"></a>
### `packages/svelte/src/compiler/phases/2-analyze/visitors/SvelteComponent.js:SvelteComponent`

`export function SvelteComponent(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/SvelteComponent.js:L10-L18][f14]

Handles the deprecated `<svelte:component>` element.

In runes mode it emits `w.svelte_component_deprecated(node)`; it then visits `node.expression` (the component constructor expression) and delegates to `visit_component`.

calls: [visit_component](r5-analyze-visitors.md#u-3bbf2fbef9a0)

<a id="u-bff097b6510d"></a>
### `packages/svelte/src/compiler/phases/2-analyze/visitors/SvelteFragment.js:SvelteFragment`

`export function SvelteFragment(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/SvelteFragment.js:L10-L27][f15]

Analyzes `<svelte:fragment>` elements.

The grandparent must be a Component or SvelteComponent, otherwise svelte_fragment_invalid_placement is thrown. Attributes: a `slot` attribute is checked via validate_slot_attribute; any Attribute other than slot or anything but a LetDirective throws svelte_fragment_invalid_attribute. Children are traversed with parent_element reset to null so inner content is not constrained by the surrounding element context.

calls: [validate_slot_attribute](r2-analyze-shared-validation.md#u-be5b4cd34d6a)

<a id="u-44e387d55632"></a>
### `packages/svelte/src/compiler/phases/2-analyze/visitors/SvelteSelf.js:SvelteSelf`

`export function SvelteSelf(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/SvelteSelf.js:L12-L36][f16]

Analyzes `<svelte:self>` elements.

The tag is legal only inside an IfBlock, EachBlock, Component or SnippetBlock somewhere in the path; otherwise svelte_self_invalid_placement is thrown. In runes mode a deprecation warning names the component — using the analysis name, or 'Self'/'Self.svelte' placeholders when the filename is unknown — derived from the last path segment of the filename. Validation aside, the element is processed exactly like a component via visit_component.

calls: [visit_component](r5-analyze-visitors.md#u-3bbf2fbef9a0)

<a id="u-2b8b56c3f427"></a>
### `TemplateElement`

`export function TemplateElement(node)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/TemplateElement.js:L8-L12][f17]

Warns about bidirectional control characters inside template literal chunks: if `node.value.cooked` (or an empty string when null/undefined) matches the regex, `w.bidirectional_control_characters(node)` is emitted.

<a id="u-573785eeaa9d"></a>
### `TitleElement`

`export function TitleElement(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/TitleElement.js:L9-L21][f18]

Validates `<svelte:title>` content: raises `e.title_illegal_attribute` for every attribute and `e.title_invalid_content` for any fragment child that is neither Text nor an ExpressionTag.

Descent continues after validation.

**Uncertainties.**

- Whether the error helpers throw immediately or collect errors depends on the errors module, not supplied

<a id="u-4c3d6ff897e3"></a>
### `UpdateExpression`

`export function UpdateExpression(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/UpdateExpression.js:L10-L29][f19]

Analyzes `++`/`--` expressions: validate_assignment runs on the argument to enforce mutability, with errors propagating.

Inside a reactive statement, the argument's binding (reduced via `object` for member targets, requiring an Identifier) is added to reactive_statement.assignments; no other identifiers are collected, unlike plain assignment. When expression metadata exists, has_assignment is set. Always traverses via context.next().

calls: [validate_assignment](r2-analyze-shared-validation.md#u-83497fe81c11), [object](r5-compiler-ast-utils.md#u-2f2548aeaec6)

<a id="u-3bbf2fbef9a0"></a>
### `visit_component`

`export function visit_component(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/shared/component.js:L19-L162][f20]

Analyzes a component node end to end: metadata, snippet tracking, attribute validation, and child-fragment dispatch.

It records the node path, initializes an empty metadata.snippets set, and computes `resolved` (whether the set of renderable snippets is known): a SpreadAttribute or BindDirective makes it unresolved; for expression attributes, an Identifier binding resolves only when is_resolved_snippet(binding) is true and adds the binding's SnippetBlock initial to metadata.snippets; a non-Literal expression makes it unresolved. If resolved, direct SnippetBlock children are also added, and the (node, resolved) pair is stored in analysis.snippet_renderers for later CSS pruning. The node is marked dynamic. Attributes are then validated: any type outside Attribute/SpreadAttribute/LetDirective/OnDirective/BindDirective/AttachTag raises component_invalid_directive; OnDirective forbids modifiers other than at most one 'once' (event_handler_invalid_component_modifier); in runes mode Attribute values are shape-validated (validate_attribute) and their expressions checked for unparenthesized sequence expressions, which also applies to AttachTag expressions; validate_attribute_name always runs; `slot` attributes get component-mode slot validation; non-`this` BindDirectives set analysis.uses_component_bindings. Child visiting splits fragment children into per-slot node lists (comments attach to the next non-comment child and are cleared after a named slot), then visits each slot's nodes with a state using that slot's scope, a shared component_slots set, and — when the component itself has a `slot` attribute (determine_slot) — the outer scope for `let:` directives instead of the default scope.

**Notes.**

- field: node.metadata.path, node.metadata.snippets, and analysis.snippet_renderers are populated here and consumed by later CSS pruning and binding resolution.

calls: [validate_attribute](r2-analyze-shared-validation.md#u-001c69caf1f6), [validate_attribute_name](r2-analyze-shared-validation.md#u-c4e14f91c1c8), [validate_slot_attribute](r2-analyze-shared-validation.md#u-be5b4cd34d6a), [mark_subtree_dynamic](r1-analysis-infra.md#u-3e6e9a44c2b4), [is_resolved_snippet](r1-analysis-infra.md#u-5fc246db911c), [is_expression_attribute](r5-compiler-ast-utils.md#u-f63f079d6472), [get_attribute_expression](r5-compiler-ast-utils.md#u-96e6f6d66786), [determine_slot](r3-compiler-shared-utils.md#u-ead26eb5b43f), [component.js-disallow-unparenthesized-sequences](r5-analyze-visitors.md#u-913cfc7440d9)

**Uncertainties.**

- Whether validate_attribute's quoted warning firing in runes mode only is intentional for legacy compatibility is not visible here.
- The exact semantics of node.metadata.scopes.default and per-slot scopes are defined elsewhere.

<a id="u-913cfc7440d9"></a>
### `component.js-disallow-unparenthesized-sequences`

`function disallow_unparenthesized_sequences(expression, source)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/shared/component.js:L168-L177][f20]

Module-private helper rejecting sequence expressions used directly as attribute or AttachTag values without parentheses.

For a SequenceExpression it scans source characters backwards from the expression start: an encountered '(' means the sequence was parenthesized and is allowed; an encountered '{' means the sequence sits in attribute position and attribute_invalid_sequence_expression is thrown. The scan stops at the first of these characters.

**Uncertainties.**

- Characters other than '(' and '{' are skipped, so the scan may run to the start of source if neither appears; behavior in that case (falling out of the loop silently) is accepted as valid.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/AttachTag.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/AwaitBlock.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/AwaitExpression.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/BindDirective.js
[f5]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/ExportNamedDeclaration.js
[f6]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/ExpressionTag.js
[f7]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/IfBlock.js
[f8]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/LetDirective.js
[f9]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/MemberExpression.js
[f10]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/SlotElement.js
[f11]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/SpreadElement.js
[f12]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/StyleDirective.js
[f13]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/SvelteBoundary.js
[f14]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/SvelteComponent.js
[f15]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/SvelteFragment.js
[f16]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/SvelteSelf.js
[f17]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/TemplateElement.js
[f18]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/TitleElement.js
[f19]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/UpdateExpression.js
[f20]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/shared/component.js
