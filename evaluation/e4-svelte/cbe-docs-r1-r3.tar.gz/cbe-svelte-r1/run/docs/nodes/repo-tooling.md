# Build & Repo Tooling

**Capability.** Developer-workflow and repo infrastructure that does not ship: bundling the compiler, lint policy, tree-shaking audits, code generation and version stamping, message-documentation generation, sandbox playground seeding and SSR dev/prod servers, the create-test CLI that collects App.svelte with its relative imports into self-contained test folders, and compiler/Vite configuration.

Use when building or policing the package or setting up playground experiments, not when implementing Svelte itself. Each tool owns one autonomous entry point and its own failure reporting; codegen output is consumed by compiler and runtime.

**Depends on.**

- [Compiler Pipeline](compiler-pipeline.md) · model-inferred · 0 edge(s)
- [Server Runtime](server-runtime.md) · model-inferred · 0 edge(s)

**Depended on by.**

- [Reactivity & SSR Benchmarking](benchmarking.md) · model-inferred · 0 edge(s)

Parent: [Svelte Monorepo](svelte-monorepo.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
