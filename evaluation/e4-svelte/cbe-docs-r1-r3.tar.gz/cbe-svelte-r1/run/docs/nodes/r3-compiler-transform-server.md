# Server Transform (SSR)

**Capability.** Serializes the analyzed component into server template output: fragments into init statements and template, inline-component rendering shared across Component/SvelteComponent/SvelteSelf, class state fields, await/call lowering for server safety.

Use this subtree when tracing SSR output generation. Shared component.js builds the actual child invocation; CallExpression and AwaitExpression visitors replace client-only behavior with server-safe equivalents.

**Depends on.**

- [Shared Transform Utilities](r3-compiler-transform-utils.md) · graph-confirmed · 3 edge(s)

**Depended on by.**

- [Shared Transform Utilities](r3-compiler-transform-utils.md) · model-inferred · 0 edge(s)

Parent: [Code Transformation](r3-compiler-transform.md)

## Units (9)

<a id="u-8619e1ace336"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/AwaitBlock.js:AwaitBlock`

`export function AwaitBlock(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/AwaitBlock.js:L11-L29][f1]

Emits a $.await call into the server template for an {#await} block.

It pushes the visited expression, a pending thunk (empty block when absent), and an arrow taking the visited value with the then body (empty block when absent); a block_close marker follows.

<a id="u-9d632fc04d55"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/AwaitExpression.js:AwaitExpression`

`export function AwaitExpression(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/AwaitExpression.js:L9-L25][f2]

Transforms await expressions, allowing them only at top level or inside functions.

If function_depth is 0, or any ancestor in the path is an arrow/function declaration/function expression, it defers via context.next(); otherwise it replaces the await with a $.await_outside_boundary call, the runtime's error signal.

<a id="u-095e9ef68802"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/CallExpression.js:CallExpression`

`export function CallExpression(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/CallExpression.js:L12-L54][f3]

Replaces client-only rune calls with server-safe equivalents.

$host becomes void 0, $effect.tracking becomes false, $effect.root becomes a no-op arrow mimicking a cleanup function, $effect.pending becomes literal 0. $state/$state.raw return the visited first argument or void 0 when absent. $derived/$derived.by visit the argument; $derived wraps it in a thunk inside $.derived, $derived.by passes the function directly. $state.snapshot becomes $.snapshot with a second true argument only when the state_snapshot_uncloneable warning is ignored. $inspect forms delegate to transform_inspect_rune. Non-rune calls fall through to context.next(); if no inner visitor returns, the result is undefined.

calls: [transform_inspect_rune](r3-compiler-transform-utils.md#u-f64464c8fc01), [is_ignored](r5-compiler-state-errors.md#u-468324b42cee)

**Uncertainties.**

- is_ignored's truthiness semantics are defined in state.js, not shown here.

<a id="u-2f46ddefb329"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/ClassBody.js:ClassBody`

`export function ClassBody(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/ClassBody.js:L10-L81][f4]

Rewrites class bodies for runes mode, backing class state fields with private keys plus accessors.

If analysis.classes has no entry for this ClassBody (legacy mode) it just calls context.next(). It first inserts, for each public name whose field was declared via constructor AssignmentExpression and is $derived/$derived.by, a backing property definition plus get/set accessor methods calling this.key. It then walks the original body: non-PropertyDefinitions are visited and kept unchanged; a PropertyDefinition with no tracked field is kept; private (#) names and $state/$state.raw fields are kept as visited; a $derived/$derived.by field is replaced by a backing prop_def of field.key (initialized with the visited original value) and get/set methods delegating to that key. Returns a copied node with the new body.

calls: [get_name](r4-compiler-model.md#u-99af92983a86)

**Uncertainties.**

- Fields present in state_fields but matching none of the replacement branches are silently dropped from the body only if their definition isn't in node.body; the insertion loop only adds constructor-declared derived backing fields.

<a id="u-fb63ecc7b839"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/Component.js:Component`

`export function Component(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/Component.js:L10-L12][f5]

Handles a <Component /> element in SSR output by delegating to build_inline_component with an identifier naming the component (node.name), letting shared logic render the child component call.

calls: [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/component.js:build_inline_component](r3-compiler-transform-server.md#u-cca955f8230f)

**Uncertainties.**

- build_inline_component's behavior is defined in another file not supplied here.

<a id="u-04c02a2801ab"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/Fragment.js:Fragment`

`export function Fragment(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/Fragment.js:L11-L46][f6]

Transforms a template fragment into the component's init statements and rendered template.

It infers the namespace from the parent node and children, then cleans nodes (hoisting, trimming whitespace-only text, detecting standalone-ness and text-first content). A fresh child state carries empty init/template arrays, the namespace, and skip_hydration_boundaries set from is_standalone. Hoisted nodes are visited first; a text-first fragment prepends an empty comment so the output is not glued to the previous fragment. Children are processed into the template, and the result is a block of init statements followed by the joined template.

calls: [clean_nodes](r3-compiler-transform-utils.md#u-2ed26069223c), [infer_namespace](r3-compiler-transform-utils.md#u-b0bc5038f26b), [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/utils.js:process_children (2)](r5-server-transform.md#u-21d2acc05779)

<a id="u-f0eb98c41b5a"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/SvelteComponent.js:SvelteComponent`

`export function SvelteComponent(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/SvelteComponent.js:L10-L12][f7]

Handles <svelte:component this={...}> in SSR output by delegating to build_inline_component; the component reference is the visited node.expression rather than a static name.

calls: [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/component.js:build_inline_component](r3-compiler-transform-server.md#u-cca955f8230f)

**Uncertainties.**

- build_inline_component's behavior is defined in another file not supplied here.

<a id="u-e627a2f894c8"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/SvelteSelf.js:SvelteSelf`

`export function SvelteSelf(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/SvelteSelf.js:L10-L12][f8]

Handles <svelte:self> in SSR output by delegating to build_inline_component with an identifier of the component's own name taken from context.state.analysis.name, producing a self-recursive component call.

calls: [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/component.js:build_inline_component](r3-compiler-transform-server.md#u-cca955f8230f)

**Uncertainties.**

- build_inline_component's behavior is defined in another file not supplied here.

<a id="u-cca955f8230f"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/component.js:build_inline_component`

`export function build_inline_component(node, expression, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/component.js:L73-L317][f9]

Serializes an inline component (Component, SvelteComponent, or SvelteSelf) into server template statements: it collects props, spreads, bindings, CSS custom properties, and slots, then emits the invocation.

Attribute dispatch: LetDirective joins lets.default unless a `slot` attribute exists (then slot scope applies to the component itself); SpreadAttribute is visited into an expression appended to props_and_spreads; Attribute names starting `--` become custom_css_props via build_attribute_value, a `children` attribute sets has_children_prop, others become init props; BindDirective on `this` is ignored, while non-`this` bindings become get/set prop pairs — a SequenceExpression yields bind_get/bind_set var declarations pushed into init, otherwise get/set props are pushed with delay=true so they land after spreads and cannot be overwritten (the setter assigns the expression and sets `$$settled = false`). Delayed props are flushed via forEach after the attribute loop. Children are grouped by slot: SnippetBlocks are visited with init redirected to snippet_declarations (hoisted into a block to avoid prop-name conflicts) and pushed as a shorthand prop plus a `$$slots` entry, mapping a `children` snippet to `default`; element children with a `slot` attribute take that slot name and own their LetDirectives, SvelteFragment lets go to default. Each non-empty slot serializes to an arrow taking `$$payload` plus an object pattern of its lets (shorthand when the let expression is null; Object/Array expressions are reinterpreted as patterns). Default slot: with no lets and no let-carrying fragments it becomes a `children` prop (wrapped in `$.prevent_snippet_stringification` in dev) plus `$$slots.default: true`; otherwise `$$slots.default` gets the slot fn and `children` becomes `$.invalid_default_snippet`. Serialized slots become a `$$slots` prop. The props expression is a plain object when there is no spread, otherwise a `$.spread_props` call over objects/spread expressions. The statement uses `b.maybe_call` for SvelteComponent and `b.call` otherwise, wrapped in a block if snippet declarations exist. With custom CSS props the statement goes through `$.css_props` (literal false for svg namespace, else true; trailing true only when dynamic); otherwise dynamic components get a leading empty comment, then the statement, then a trailing empty comment unless `skip_hydration_boundaries` is set.

calls: [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/utils.js:build_attribute_value](r5-server-transform.md#u-8ce176223a22), [is_element_node](r4-compiler-model.md#u-0d9a79ad394a); imports: [utils.js module code (L1–L29)][f10]

**Uncertainties.**

- Runtime semantics of $.spread_props, $.css_props, $.prevent_snippet_stringification, and $.invalid_default_snippet are defined outside this file
- node.metadata.dynamic and node.metadata.scopes per slot name come from the analysis phase, not visible here

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/AwaitBlock.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/AwaitExpression.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/CallExpression.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/ClassBody.js
[f5]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/Component.js
[f6]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/Fragment.js
[f7]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/SvelteComponent.js
[f8]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/SvelteSelf.js
[f9]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/component.js
[f10]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/utils.js
