# Compiler Pipeline

**Capability.** Transforms Svelte source into client or server JS through parsing support, analysis, migration, and the two transform phases.

Use this subtree to navigate the compile phases. Parsing helpers feed the parser, the analysis phase computes metadata and warnings, the migrator upgrades legacy code, and the transform phases emit output.

**Children.**

- [HTML Entity Decoding](r1-parse-entities.md) `r1-parse-entities` · 6 unit(s)
- [Analysis Phase](r1-analysis.md) `r1-analysis` · 0 unit(s)
- [Svelte 4 Automigrator](r1-migrator.md) `r1-migrator` · 22 unit(s)
- [Client Transform Phase](r1-client-transform.md) `r1-client-transform` · 0 unit(s)
- [Server Transform Phase](r1-server-transform.md) `r1-server-transform` · 9 unit(s)

Parent: [Svelte Monorepo](r1-root.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
