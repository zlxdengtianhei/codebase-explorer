# Treeshakeability Audit

**Capability.** Bundles every package export in-memory via Rollup, rewrites 'svelte' imports to export files, and fails when dead code survives.

Use this to verify that package exports tree-shake. The audit bundles a feature-heavy client program, probes it for surviving markers, and reports failures through a module-level flag.

**Depends on.**

- [Client Block & Element Visitors](r1-client-block-visitors.md) · graph-confirmed · 1 edge(s)

Parent: [Build & Repo Tooling](r1-build-tooling.md)

## Units (4)

<a id="u-df4ca4955d27"></a>
### `check-treeshakeability.js-bundle-code`

`async function bundle_code(entry)` · [packages/svelte/scripts/check-treeshakeability.js:L12-L13][f1]

Bundles an in-memory entry string via rollup and returns its single chunk of JavaScript, rewriting 'svelte' imports to the package's own export files.

A virtual plugin serves the entry source as '__entry__'; a custom resolveId maps any importee starting with 'svelte' to path.resolve of pkg.exports[importee with 'svelte' replaced by '.'].browser ?? .default; nodeResolve runs with production/import/browser/default conditions. Rollup warnings coded EMPTY_BUNDLE or CIRCULAR_DEPENDENCY are swallowed by not calling handle; all others are handled normally. After generate, more than one output chunk throws Error('errr what'); otherwise the trimmed code of the first chunk is returned. Module-level pkg is read from package.json before any call.

**Uncertainties.**

- The resolved svelte export paths depend on package.json contents not supplied; only the lookup logic is observable.

<a id="u-be696749d63c"></a>
### `check_bundle`

`function check_bundle(case_name, ...strings)` · [packages/svelte/scripts/check-treeshakeability.js:L125-L146][f1]

Reports whether any of the given strings survived in the module-level `bundle` string.

For each string in order it finds its index: if found it logs '❌ <case_name> not treeshakeable', sets failed = true, prints bundle.slice(index - 500, index + 500) split into lines with the first line containing the string marked '>' (others '|'), sliced to five lines either side, then returns — only the first matching string per case is reported. If no string is found it logs '✅ <case_name> treeshakeable'.

uses: [check-treeshakeability.js module code (L46–L124)](r1-treeshakeability-audit.md#u-65c13f088150)

**Uncertainties.**

- If a match lies within 500 characters of the bundle's start or end, findIndex may see a truncated first line and line-slice indices can go negative; edge behavior is unverified.

<a id="u-65c13f088150"></a>
### `check-treeshakeability.js module code (L46–L124)`

`module_region` · [packages/svelte/scripts/check-treeshakeability.js:L46-L124][f1]

Top-level treeshakeability audit: bundles every package export plus one feature-heavy client bundle, marking failures in the module-level `failed` flag.

Iterating pkg.exports it skips './compiler', './internal', './internal/disclose-version', './internal/flags/legacy' and './internal/flags/tracing'. For each remaining key and each of 'browser'/'default' (skipped when absent), it bundles an import of the resolved export path; empty output logs '✅ subpackage (type)' to stderr, non-empty output prints the leftover code, logs '❌', and sets failed = true. It then bundles a compiled Svelte component importing the package's browser main and exercising hydration-bearing features (svelte:head, bind:value, spread, svelte:component/element, snippet/render, @html, if/each/await/key blocks); the resulting bundle is stored in the module-level `bundle` variable for later probes.

calls: [check-treeshakeability.js-bundle-code](r1-treeshakeability-audit.md#u-df4ca4955d27)

**Uncertainties.**

- All bundling runs at module load; a rejection from bundle_code is not caught here and aborts the script.

<a id="u-52b747b1c51f"></a>
### `check-treeshakeability.js module code (L146–L163)`

`module_region` · [packages/svelte/scripts/check-treeshakeability.js:L146-L163][f1]

Runs the three failure probes and finishes the script.

It calls check_bundle for 'Hydration code' ('hydrate_node', 'hydrate_next'), 'Legacy code' ('component_context.l') and '$inspect.trace' ("'CreatedAt'"), each of which may set the shared `failed` flag. If failed, it logs the bundle's resolved path and writes the bundle to scripts/_bundle.js; it then closes the console group and calls process.exit(1) when failed, otherwise the process ends normally.

calls: [check_bundle](r1-treeshakeability-audit.md#u-be696749d63c)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/scripts/check-treeshakeability.js
