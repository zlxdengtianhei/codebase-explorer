# Compiler Legacy Types

**Capability.** Type declarations kept for backward compatibility: aliases of legacy compiler interfaces and full Svelte 4-era AST node shapes so older tooling can consume old ASTs. No runtime code.

Consult only when interoperating with legacy compiler output or typing old ASTs; they impose no behavior on the current pipeline.

**Depended on by.**

- [Compiler Semantic Model](r4-compiler-model.md) · model-inferred · 0 edge(s)

Parent: [Compiler Pipeline](r4-compiler-pipeline.md)

## Units (2)

<a id="u-9be87a51ccd3"></a>
### `legacy-interfaces.d.ts-deprecated-aliases`

`export type CompileOptions = C;` · [packages/svelte/src/compiler/types/legacy-interfaces.d.ts:L4-L4][f1]

Backward-compatibility re-export aliases.

`CompileOptions` and `Warning` here are deprecated type aliases that resolve to the `C` and `W` imports from `#compiler` (`svelte/compiler` types); each carries a doc comment telling users to import from `'svelte'` instead. No behavior beyond aliasing.

imports: [CompileOptions](r5-compiler-types.md#u-9a76119419fb)

<a id="u-12cde4f20754"></a>
### `legacy-nodes.d.ts-legacy-ast`

`interface BaseNode` · [packages/svelte/src/compiler/types/legacy-nodes.d.ts:L13-L17][f2]

Type declarations for the Svelte 4-era (legacy) node shapes, kept so tooling can consume old ASTs.

`BaseNode` gives `type`/`start`/`end`; `BaseElement` adds `name`, `attributes: LegacyAttributeLike[]`, and `children: LegacyElementLike[]`. Element-like interfaces fix `name` to their special tag (`svelte:body`, `svelte:document`, etc.) and reuse `BaseElement`; `LegacyElement` declares only `type: 'Element'` and so contributes no fields beyond it. Directive interfaces follow a uniform pattern of `name` plus nullable `expression` (`LegacyAction`, `LegacyAnimation`, `LegacyBinding`, `LegacyEventHandler` with `modifiers`, `LegacyTransition` with `modifiers` of `'local'|'global'` and `intro`/`outro` booleans where `intro` is true for `transition:`/`in:` and `outro` for `transition:`/`out:`, `LegacyClass`, `LegacyStyleDirective` whose `value` is `true` or an array of `AST.ExpressionTag`/`AST.Text` with `'important'` modifiers). Block-ish shapes (`LegacyCatchBlock`, `LegacyPendingBlock`, `LegacyThenBlock`) hold `children` plus a `skip` flag. `LegacyAttribute.value` is `true` (shorthand-less static) or an array of text/mustache/shorthand nodes; `LegacyComment.ignores` splits `<!-- svelte-ignore a b c -->` into `['a','b','c']`. The trailing unions group these: `LegacyDirective`, `LegacyAttributeLike` (attribute, spread, directives), `LegacyElementLike` (all element/comment/block/tag shapes), `LegacyCssNode`, and `LegacySvelteNode` mixing legacy nodes with `AST.Text`. Note `SnippetBlock` and `RenderTag` exist in this legacy file too, with `expression` identifiers and nullable argument/context respectively.

imports: [template.d.ts-root-and-fragment](r3-compiler-ast-types.md#u-e8223dc323d4)

**Uncertainties.**

- `LegacyRoot.css/instance/module` are `any`, and `LegacyStyle.attributes`/`children` are `any[]`, so those subtrees are unconstrained here.
- `LegacyElement` lacks `extends BaseElement`, so it is structurally just `type: 'Element'` despite appearing in `LegacyElementLike`.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/types/legacy-interfaces.d.ts
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/types/legacy-nodes.d.ts
