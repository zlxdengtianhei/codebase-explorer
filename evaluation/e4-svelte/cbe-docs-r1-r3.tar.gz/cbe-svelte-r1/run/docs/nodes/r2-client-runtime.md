# Client runtime

**Capability.** Owns the in-browser execution machinery: the reactive signal/derived system, DOM template construction and operations, block rendering (slots, dynamic components, head), element-level behaviors, and development-only guards.

This subtree is everything that runs in the browser when a compiled component executes. Children split by concern: reactivity core, DOM primitives, template blocks, element integrations, and dev-mode validation. Tracing-mode flag infrastructure is grouped with dev concerns.

**Children.**

- [Reactivity core \(signals and deriveds\)](r2-client-reactivity.md) `r2-client-reactivity` · 15 unit(s)
- [DOM primitives: operations and templates](r2-client-dom-core.md) `r2-client-dom-core` · 14 unit(s)
- [Block rendering: slots, components, head](r2-client-dom-blocks.md) `r2-client-dom-blocks` · 5 unit(s)
- [Element integrations: custom elements, actions, bindings](r2-client-dom-elements.md) `r2-client-dom-elements` · 16 unit(s)
- [Development-mode guards and tracing](r2-client-dev.md) `r2-client-dev` · 4 unit(s)

Parent: [Svelte compiler and runtime](r2-svelte.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
