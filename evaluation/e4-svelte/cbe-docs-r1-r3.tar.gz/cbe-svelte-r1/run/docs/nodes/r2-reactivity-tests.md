# Reactive collection test suites

**Capability.** Owns the behavioral specifications for the reactive collection APIs (SvelteMap, SvelteURLSearchParams) as executable Vitest suites.

Consult these tests for the expected reactive semantics of the collection classes; the implementation units themselves are not part of this input set, so treat these as the authoritative observable contract here.

Parent: [Public reactive APIs](r2-public-reactive.md)

## Units (2)

<a id="u-f9bdf3b7aa10"></a>
### `map.test.ts-sveltemap-behavior`

`group` · [packages/svelte/src/reactivity/map.test.ts:L1-L240][f1]

Vitest suite for SvelteMap reactivity.

Tests register render_effects reading size, has, get, and values inside an effect_root, mutate via flushSync, and assert exact logs, verifying: deleting a key flips has to false and removes it from values; re-adding then updating a key fires the tracked effects again; get of a deleted key returns undefined and re-fires when re-set; forEach forwards callback args and this_arg unchanged and is not itself reactive in the test; delete returns true/false correctly; a stored undefined value behaves like any value (effect fires on delete and re-set); effects that read absent keys do not re-fire unless the key gains a value; and SvelteMap instanceof Map holds.

<a id="u-049e70a6d8b7"></a>
### `url-search-params.test.ts-svelteurlsearchparams-tests`

`group` · [packages/svelte/src/reactivity/url-search-params.test.ts:L1-L208][f2]

Vitest suite for SvelteURLSearchParams.

Tests 'new URLSearchParams', 'URLSearchParams.set', 'URLSearchParams.append', and 'URLSearchParams.toString' drive toString in a render effect and mutate via flushSync, asserting no redundant re-runs when a set is a no-op (same value) and that append followed by set with the same value does not re-trigger. 'URLSearchParams.delete' asserts a second delete of an absent key causes no re-run. 'URLSearchParams.get' and 'URLSearchParams.getAll' assert that effects reading specific keys re-run on relevant changes, including reading a missing key returning null or [] and reacting only when that key is affected. 'SvelteURLSearchParams instanceof URLSearchParams' checks subclassing. Each effect test cleans up with the effect_root teardown.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/reactivity/map.test.ts
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/reactivity/url-search-params.test.ts
