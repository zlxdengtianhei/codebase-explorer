# Semantic Analysis

**Capability.** Builds ComponentAnalysis from the parsed AST: scopes, runes-mode detection, svelte-ignore collection, per-node-type validation visitors, and legacy `$:` statement ordering.

Use this subtree when investigating compile-time errors, warnings, or scope/binding metadata. analyze_component/analyze_module drive the walk; the visitors hold per-node rules, with shared element validation factored out.

**Depends on.**

- [Compiler Diagnostics & Warnings](r3-compiler-diagnostics.md) · graph-confirmed · 3 edge(s)
- [Template Parsing](r3-compiler-parse.md) · model-inferred · 0 edge(s)
- [Compiler Shared Utilities & Legacy AST](r3-compiler-shared-utils.md) · model-inferred · 0 edge(s)
- [Analysis validation core](r2-analyze-shared-validation.md) · graph-only · 15 edge(s)
- [Compiler Semantic Model](r4-compiler-model.md) · graph-only · 15 edge(s)

**Depended on by.**

- [Code Transformation](r3-compiler-transform.md) · model-inferred · 0 edge(s)

Parent: [Svelte Compiler](r3-compiler.md)

## Units (23)

<a id="u-32c86377621b"></a>
### `analyze_component`

`export function analyze_component(root, source, options)` · [packages/svelte/src/compiler/phases/2-analyze/index.js:L321-L623][f1]

Performs the setup half of component analysis: builds module/instance/template scopes, resolves `$store` subscriptions, decides runes mode, and constructs the ComponentAnalysis object.

For each `$name` module reference (excluding `$$props`/`$$restProps`/`$$slots`), `$` or `$$` names raise global_reference_invalid; when not in explicit legacy mode the subscription is treated as a rune unless tests on the instance declaration (rune initializer, `$props` rune names, the `svelte/store` derived import) allow store treatment. Valid store subscriptions error if the store is declared in a nested scope (store_invalid_scoped_subscription), if a lowercase undeclared store is referenced in runes mode, warn on rune-name/CallExpression conflicts, error on references located inside the module script, and queue a legacy check that upgrades a reassigned `let` declaration to `state`. Runes mode is `options.runes ?? (has_await anywhere or any remaining rune-named module reference)`; only when legacy mode is confirmed are the queued checks applied. A deprecated `<script context>` attribute warns in runes mode. The analysis sets maybe_runes (legacy component with no `$$props`/`$$restProps` references and no `export let`/`$:` labels), accessors (custom element, legacy option, or componentApi 4), and a css hash via options.cssHash.

**Notes.**

- side_effect: Synthetic `store_sub` bindings are declared in the instance scope and the `$name` reference is moved from module scope to instance scope.

calls: [get_rune](r4-compiler-model.md#u-5204b6ce4f7a), [create_scopes](r4-compiler-model.md#u-a24fbf023b97); uses: [extract_identifiers](r5-compiler-ast-utils.md#u-90eb95affc00)

**Uncertainties.**

- The rune-vs-store decision combines several nested conditions; exact precedence for edge inputs (e.g. `$derived` imported from svelte/store alongside `const x = $derived`) is encoded in the boolean but its intended semantics rest on comments, not provable behavior here.

<a id="u-6c456ee893c0"></a>
### `packages/svelte/src/compiler/phases/2-analyze/index.js:analyze_component`

`export function analyze_component(root, source, options)` · [packages/svelte/src/compiler/phases/2-analyze/index.js:L654-L913][f1]

Second half of component analysis: legacy prop/export processing or runes-mode walking, then template/CSS post-passes and validation.

In legacy mode (`!runes`), exported `let`/`var` bindings become bindable_prop (with prop_alias when renamed), exported functions/classes and `const` declarations become exports; reassigned bindings referenced from the template, StyleDirective paths, or `$:` labels become `state`; an EachBlock walk additionally marks identifiers referenced within expressions of blocks whose each-binding is reassigned as `state` and mutated. In runes mode, `$$props`/`$$restProps` module references are errors, all three ASTs (module, instance, template) are walked with the visitors, and any reassigned non-state binding referenced in the template warns non_reactive_update, except inside functions, and except `bind:this` when not inside an IfBlock/EachBlock/AwaitBlock/KeyBlock. Legacy mode synthesizes `$$props`/`$$restProps` rest_prop bindings, warns export_let_unused for unreferenced props with no `$name` shadow, and orders reactive statements. Shared closing passes: unexportable named module exports error as snippet_invalid_export or export_undefined; mixing `on:` attributes with event directives errors; unresolved snippet renderers get the snippet set attached and render sites recorded; render tags combined with slots/`$$slot` error slot_snippet_conflict; CSS is analyzed, each element is pruned, and warn_unused runs unless suppressed by a `css_unused_selector` ignore comment; finally elements that are scoped custom elements are marked dynamic and empty `class`/`style` attributes are synthesized when directives need them and no spread/attribute supplies one.

calls: [analyze_css](r4-css-analysis.md#u-f762711e5ae7), [css-prune-js-prune](r1-css-pruning.md#u-ff716446121a), [warn_unused](r2-analyze-visitors.md#u-6a7a7b443898), [extract_svelte_ignore](r3-compiler-diagnostics.md#u-4a9ee4fb9b67), [create_attribute](r4-compiler-model.md#u-16d11cbbd59b), [is_custom_element_node](r4-compiler-model.md#u-ea1f0b51e1e8), [mark_subtree_dynamic](r1-analysis-infra.md#u-3e6e9a44c2b4), [order_reactive_statements](r3-compiler-analyze.md#u-1d0641187e84); uses: [get_component_name](r3-compiler-analyze.md#u-b77f317897f5)

**Uncertainties.**

- The legacy EachBlock walk relies on set_scope as the default visitor via a ts-expect-error cast; the exact scope-state coupling during that inner walk is not verifiable from this file.

<a id="u-92d8ef78fb8c"></a>
### `analyze_module`

`export function analyze_module(source, options)` · [packages/svelte/src/compiler/phases/2-analyze/index.js:L249-L313][f1]

Analyzes a module-mode (`compileModule`) source.

It parses the source into an AST (collecting comments), builds scopes under a fresh ScopeRoot, and rejects any `$`-prefixed reference: `$` or `$$`-prefixed names raise global_reference_invalid, and a `$name` reference whose store binding exists and whose name is not a rune raises store_invalid_subscription_module. It returns a runes-mode Analysis (immutable: true, accessors: false) and walks the AST with the shared visitors under a state stubbed with unused component-only fields.

calls: [packages/svelte/src/compiler/phases/1-parse/acorn.js:parse](r5-script-parsing.md#u-2464d5720df7), [create_scopes](r4-compiler-model.md#u-a24fbf023b97), [is_rune](r1-dom-dom-utils.md#u-ad49595ea2ed); uses: [packages/svelte/src/compiler/phases/2-analyze/index.js:_](r3-compiler-analyze.md#u-622534e4d55e)

**Uncertainties.**

- The walk state casts analysis to ComponentAnalysis for typing; visitor code paths requiring real component fields are not exercised by module ASTs, but that guarantee is not visible here.

<a id="u-b77f317897f5"></a>
### `get_component_name`

`function get_component_name(filename)` · [packages/svelte/src/compiler/phases/2-analyze/index.js:L231-L240][f1]

Derives a PascalCase component name from a filename.

It splits on slashes, takes the basename, strips `.svelte`, and if the result is `index` and the parent directory exists and is not `src`, uses the directory name instead; the first character is uppercased.

**Uncertainties.**

- Non-`.svelte` filenames pass through unchanged apart from casing; no suffix other than `.svelte` is stripped.

<a id="u-1d167d10f6f2"></a>
### `js`

`function js(script, root, allow_reactive_declarations, parent)` · [packages/svelte/src/compiler/phases/2-analyze/index.js:L208-L226][f1]

Builds the Js analysis bundle for one script section of a component.

It substitutes an empty synthetic Program (start/end -1) when the script is absent, then runs create_scopes over the AST with the given ScopeRoot, reactive-declaration allowance, and parent scope, returning the ast, its scope and scopes map, and whether top-level await occurs.

calls: [create_scopes](r4-compiler-model.md#u-a24fbf023b97)

<a id="u-1d0641187e84"></a>
### `order_reactive_statements`

`function order_reactive_statements(unsorted_reactive_declarations)` · [packages/svelte/src/compiler/phases/2-analyze/index.js:L918-L961][f1]

Topologically orders legacy `$:` reactive statements by their dataflow.

It indexes statements by assigned binding names, then builds edges from each assignment name to each dependency name the statement does not itself assign. If check_graph_for_cycles reports a cycle, reactive_declaration_cycle errors with the cycle path, using the first statement that assigns the cycle's entry name. It then emits a Map whose insertion order places every statement after the statements producing its dependencies: add_declaration skips already-emitted declarations and recursively emits producers of unassigned dependencies first.

calls: [check_graph_for_cycles](r2-analyze-shared-validation.md#u-9450956ffc9b)

**Uncertainties.**

- If lookup has no entry for cycle[0], the indexed access would fail; the source assumes every cycle name has an assigning statement.

<a id="u-622534e4d55e"></a>
### `packages/svelte/src/compiler/phases/2-analyze/index.js:_`

`const visitors = { _(node, { state, next, path })` · [packages/svelte/src/compiler/phases/2-analyze/index.js:L86-L139][f1]

Default zimmerframe visitor applied to every node during analysis; it collects `svelte-ignore` comments applying to the node and maintains the ignore stack while visiting it.

If the parent is a Fragment and the node is not a Comment/Text, it scans backwards over preceding siblings, extracting ignores from Comments (offset by `<!--`), stopping at any non-Text sibling; otherwise it extracts ignores from the node's `leadingComments` (offset by `//`). Non-empty ignore lists are pushed before visiting and popped after; every node's snapshot of the ignore stack is cloned into ignore_map. `next()` receives a state with the node's own scope when state.scopes has one that differs from state.scope.

**Notes.**

- side_effect: ignore_map gains an entry for every visited node with a structuredClone of the current ignore_stack, even when no ignores apply.
- condition: Backward comment scan breaks at the first preceding sibling that is neither Comment nor Text, limiting which comments are treated as applying.

calls: [extract_svelte_ignore](r3-compiler-diagnostics.md#u-4a9ee4fb9b67), [state-js-ignore-stack](r5-compiler-state-errors.md#u-acb70c3ca854)

<a id="u-2a9d6ef13421"></a>
### `packages/svelte/src/compiler/phases/2-analyze/visitors/ClassBody.js:ClassBody`

`export function ClassBody(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/ClassBody.js:L15-L49][f2]

Analyzes class bodies in runes mode, building StateField metadata; in non-runes mode it just traverses.

It collects private identifier names, registers an empty state_fields map on analysis.classes, then processes members via the nested `handle`: for a property or constructor `this.x = <rune call>` assignment, if the value is a state-creation rune it errors on duplicate state fields (state_field_duplicate) or on conflicting existing method/assigned field (duplicate_class_field), and records the field. The main loop fills `fields` distinguishing static keys (prefixed '@'), properties (prop/assigned_prop) and methods, erroring on duplicates except pairing a get with a set (and vice versa). Constructor statements assigning `this.<literal-or-ident>` are fed to handle. Public state field names are deconflicted against private ids by replacing invalid chars and prefixing underscores, then assigned generated private keys. Finally traverses with state_fields in state.

calls: [get_rune](r4-compiler-model.md#u-5204b6ce4f7a), [get_name](r4-compiler-model.md#u-99af92983a86)

**Uncertainties.**

- whether a computed non-static PropertyDefinition is silently skipped (it is not handled) versus validated elsewhere is not shown here

<a id="u-12bb8c39d56d"></a>
### `packages/svelte/src/compiler/phases/2-analyze/visitors/ClassDeclaration.js:ClassDeclaration`

`export function ClassDeclaration(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/ClassDeclaration.js:L10-L25][f3]

Analyzes class declarations: in runes mode with a named class, validates the class identifier's binding name.

Then warns perf_avoid_nested_class when the class is nested too deeply — allowed function_depth is 0 in modules (`ast_type === 'module'`) and 1 in components; exceeding it warns but does not stop analysis. Always traverses children via context.next().

calls: [validate_identifier_name](r2-analyze-shared-validation.md#u-e442f835d467)

<a id="u-3462d134e7cb"></a>
### `packages/svelte/src/compiler/phases/2-analyze/visitors/Component.js:Component`

`export function Component(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/Component.js:L9-L20][f4]

Marks a component reference as dynamic under runes mode.

It resolves the binding for the component name, stripping everything from the first '.' for dotted names. `node.metadata.dynamic` is true only when the analysis is in runes mode, the binding exists, and either the binding kind is not 'normal' or the name is dotted — in legacy (non-runes) mode `svelte:component` was required, so plain components are not dynamic here. It then delegates to `visit_component`.

calls: [visit_component](r5-analyze-visitors.md#u-3bbf2fbef9a0)

<a id="u-c1ba3ccb02a9"></a>
### `packages/svelte/src/compiler/phases/2-analyze/visitors/ConstTag.js:ConstTag`

`export function ConstTag(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/ConstTag.js:L10-L39][f5]

Analyzes `{@const}` tags.

In runes mode the opening tag is validated with the '@' marker. The tag is legal only when its immediate parent is a Fragment whose grandparent is IfBlock, SvelteFragment, Component, SvelteComponent, EachBlock, AwaitBlock, SnippetBlock, SvelteBoundary, KeyBlock, or an element (RegularElement/SvelteElement) carrying a `slot` attribute; any other placement throws const_tag_invalid_placement, which propagates and stops traversal. Otherwise it visits the declaration's id and its init with the tag's expression metadata so dependency tracking attaches to the const.

calls: [validate_opening_tag](r2-analyze-shared-validation.md#u-8a95b3b7e6dc)

<a id="u-dbb0147495c2"></a>
### `EachBlock`

`export function EachBlock(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/EachBlock.js:L13-L72][f6]

Analyzes `{#each}` blocks.

Validates the opening tag and that body and fallback are non-empty; rejects `{#each items as $state/$derived}` with state_invalid_placement. If a key exists, metadata.keyed is true unless the key is an identifier equal to the index (that form stays a plain indexed block). The expression is visited in the parent scope with the block's expression metadata; body, key and fallback are visited. In non-runes (legacy) mode it detects whether the context variable is mutated, collects transitive dependencies of the expression bindings recursively, and if mutated upgrades normal const/let/var transitive bindings to kind 'state' so they become invalidatable sources. Finally marks the subtree dynamic.

calls: [validate_opening_tag](r2-analyze-shared-validation.md#u-8a95b3b7e6dc), [extract_identifiers](r5-compiler-ast-utils.md#u-90eb95affc00)

<a id="u-04014907462f"></a>
### `ExpressionStatement`

`export function ExpressionStatement(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/ExpressionStatement.js:L9-L38][f7]

Analyzes expression statements, warning on legacy component instantiation.

When the statement is `new X({ target: ... })` — single ObjectExpression argument containing a `target` property — and X is a normal imported binding whose ImportDeclaration source ends in `.svelte` and imports X as a default specifier, legacy_component_creation is warned. All other statements are unaffected. Always traverses via context.next().

uses: [extract_svelte_ignore](r3-compiler-diagnostics.md#u-4a9ee4fb9b67)

**Uncertainties.**

- the cast of binding.initial to ImportDeclaration is unchecked; a non-import initial would misbehave, but the declaration_kind check makes that unlikely — not provable here

<a id="u-229553bec4c3"></a>
### `Fragment`

`export function Fragment(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/Fragment.js:L8-L10][f8]

Updates analysis state so descendants know which fragment they belong to, continuing the walk with `context.next({...context.state, fragment: node})`.

<a id="u-a8a29531c5a9"></a>
### `packages/svelte/src/compiler/phases/2-analyze/visitors/HtmlTag.js:HtmlTag`

`export function HtmlTag(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/HtmlTag.js:L10-L19][f9]

Analyzes `{@html ...}` tags: in runes mode it validates the opening tag with the '@' prefix, unconditionally marks the subtree dynamic (commented as necessary to fix invalid HTML), and continues with the node's expression set as the current dynamic expression.

calls: [mark_subtree_dynamic](r1-analysis-infra.md#u-3e6e9a44c2b4), [validate_opening_tag](r2-analyze-shared-validation.md#u-8a95b3b7e6dc)

<a id="u-9898e6a37ff8"></a>
### `packages/svelte/src/compiler/phases/2-analyze/visitors/KeyBlock.js:KeyBlock`

`export function KeyBlock(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/KeyBlock.js:L10-L21][f10]

Analyzes `{#key ...}` blocks.

It first rejects empty fragments via `validate_block_not_empty`; in runes mode it validates the opening tag with the '#' prefix. It marks the subtree dynamic, then explicitly visits `node.expression` with the block's `metadata.expression` state and `node.fragment` with the plain state.

calls: [mark_subtree_dynamic](r1-analysis-infra.md#u-3e6e9a44c2b4), [validate_block_not_empty](r2-analyze-shared-validation.md#u-b877c3a87dc5), [validate_opening_tag](r2-analyze-shared-validation.md#u-8a95b3b7e6dc)

<a id="u-fd5ac76065e4"></a>
### `packages/svelte/src/compiler/phases/2-analyze/visitors/PropertyDefinition.js:PropertyDefinition`

`export function PropertyDefinition(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/PropertyDefinition.js:L10-L21][f11]

Detects illegal assignment to `$state` fields.

It resolves the property key name with `get_name` and looks it up in `state_fields`. If a matching field exists, this node is not the field's own declaration, and the node has a value, then when this node's start offset precedes the field declaration's start offset, `e.state_field_invalid_assignment(node)` is raised — i.e. a later class field assigns to an earlier declared state field. `context.next()` runs otherwise and after.

calls: [get_name](r4-compiler-model.md#u-99af92983a86)

**Uncertainties.**

- The start offsets are cast to number; a missing start would compare `undefined < number` (always false), so no error would be raised — this edge is not exercised by visible code

<a id="u-35398f6374ab"></a>
### `SnippetBlock`

`export function SnippetBlock(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/SnippetBlock.js:L11-L75][f12]

Analyzes a {#snippet} block: registers it in analysis.snippets, errors on an empty body, validates the '#'-prefixed opening tag in runes mode, and rejects rest parameters.

Traversal continues with parent_element cleared to null. Hoisting is decided: snippets at the top level (path of exactly a Fragment) whose scope passes can_hoist_snippet are hoistable; when hoistable, the snippet name's binding is copied into the module scope declarations and node.metadata.can_hoist is set. A snippet whose name shadows an attribute of a parent Component errors (snippet_shadowing_prop). A snippet named 'children' whose parent is a Component/SvelteComponent/SvelteSelf errors with snippet_conflict if the component has any non-snippet, non-whitespace-text, non-comment children.

**Notes.**

- side_effect: Mutates analysis.snippets, module scope declarations, and node.metadata.can_hoist.

calls: [validate_block_not_empty](r2-analyze-shared-validation.md#u-b877c3a87dc5), [validate_opening_tag](r2-analyze-shared-validation.md#u-8a95b3b7e6dc), [Scope](r4-compiler-model.md#u-01a82e58170d), [can_hoist_snippet](r3-compiler-analyze.md#u-4e8662011f13)

<a id="u-4e8662011f13"></a>
### `can_hoist_snippet`

`function can_hoist_snippet(scope, scopes, visited = new Set())` · [packages/svelte/src/compiler/phases/2-analyze/visitors/SnippetBlock.js:L81-L108][f12]

Recursively decides whether a snippet's scope can be hoisted to module level: every reference must resolve to a binding at module/function-depth 0 (skipped), declared inside the snippet itself (function_depth >= current, skipped), or a nested snippet whose own scope also passes (tracked via a visited set to avoid cycles).

Any other reference returns false; otherwise true.

**Notes.**

- condition: The visited set prevents infinite recursion when snippets reference each other cyclically.

<a id="u-e568340fb504"></a>
### `packages/svelte/src/compiler/phases/2-analyze/visitors/SvelteElement.js:SvelteElement`

`export function SvelteElement(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/SvelteElement.js:L13-L78][f13]

Analyzes `<svelte:*>` elements: runs element validation and a11y checks first (their errors propagate), records the template path and pushes the node into analysis.elements.

Namespace resolution: an explicit static `xmlns` attribute sets svg/mathml flags by comparing to the SVG/MathML namespace constants; otherwise the ancestor chain is scanned backwards — reaching the root or a Component/SvelteComponent/SvelteFragment/SnippetBlock boundary resets to the compiler options' namespace, and an enclosing element inherits its svg/mathml flags except inside a RegularElement `foreignObject`, which forces both false. The subtree is marked dynamic, then the tag expression, attributes, and fragment (with parent_element cleared) are visited.

calls: [validate_element](r3-compiler-analyze.md#u-7d4fa5b13c15), [check_element](r1-a11y-analysis.md#u-0f7a175a707e), [is_text_attribute](r5-compiler-ast-utils.md#u-ec400088cae5)

**Uncertainties.**

- if the backward scan finds no boundary element, neither branch's break is hit and svg/mathml flags stay unset — whether that state is valid is not visible here

<a id="u-b2fd544bbb7e"></a>
### `TaggedTemplateExpression`

`export function TaggedTemplateExpression(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/TaggedTemplateExpression.js:L9-L16][f14]

Tracks calls in tagged template expressions for expression metadata.

When the current state `expression` is set and the tag is not pure per `is_pure(node.tag, context)`, it sets `has_call = true` and `has_state = true` on `context.state.expression`. Pure tags leave the flags untouched. Descent continues in all cases.

calls: [is_pure](r2-analyze-shared-validation.md#u-c8c562a3fb44)

<a id="u-7f3ea7461731"></a>
### `TransitionDirective`

`export function TransitionDirective(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/TransitionDirective.js:L10-L14][f15]

Marks the subtree containing a transition directive as dynamic via `mark_subtree_dynamic(context.path)` and continues descent.

calls: [mark_subtree_dynamic](r1-analysis-infra.md#u-3e6e9a44c2b4)

<a id="u-7d4fa5b13c15"></a>
### `validate_element`

`export function validate_element(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/shared/element.js:L29-L155][f16]

Performs attribute-level validation shared by RegularElement and SvelteElement visitors, iterating attributes in order with per-kind rules.

For Attribute nodes: in runes mode it shape-validates the value and rejects unparenthesized sequence expressions inline (same backward scan as component.js: '(' allows, '{' throws attribute_invalid_sequence_expression); names matching regex_illegal_attribute_character raise attribute_invalid_name; `on*` names require an expression value (attribute_invalid_event_handler) and warn attribute_global_event_reference when the value is an Identifier equal to the attribute name with no binding in scope; `slot` attributes are validated via validate_slot_attribute in non-component mode; `is` warns attribute_avoid_is; React-style names (className, htmlFor) warn attribute_invalid_property_name with the suggested name; validate_attribute_name runs last. AnimateDirective must be a direct child of an EachBlock with a key (animation_invalid_placement / animation_missing_key), must leave at most one non-comment/non-const/non-whitespace sibling in the each body, and cannot appear twice (animation_duplicate). TransitionDirective tracks in/out transitions: a same-kind duplicate raises transition_duplicate, a different-kind overlap raises transition_conflict (e.g. transition:in vs in:). OnDirective modifiers must all be in EVENT_MODIFIERS (event_handler_invalid_modifier lists them), and 'passive' combined with 'nonpassive' or 'preventDefault' raises event_handler_invalid_modifier_combination. No successful-return state is mutated except local tracking variables.

calls: [validate_attribute](r2-analyze-shared-validation.md#u-001c69caf1f6), [validate_attribute_name](r2-analyze-shared-validation.md#u-c4e14f91c1c8), [validate_slot_attribute](r2-analyze-shared-validation.md#u-be5b4cd34d6a), [is_expression_attribute](r5-compiler-ast-utils.md#u-f63f079d6472), [get_attribute_expression](r5-compiler-ast-utils.md#u-96e6f6d66786)

**Uncertainties.**

- The comment-attached expression in the slot branch suggests the result of validate_slot_attribute is typed as the owner node, but the function returns void; the annotation appears vestigial.
- Transition conflict detection compares only against the stored in/out transitions, so three or more same-slot transitions report against the most recent one.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/index.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/ClassBody.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/ClassDeclaration.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/Component.js
[f5]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/ConstTag.js
[f6]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/EachBlock.js
[f7]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/ExpressionStatement.js
[f8]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/Fragment.js
[f9]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/HtmlTag.js
[f10]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/KeyBlock.js
[f11]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/PropertyDefinition.js
[f12]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/SnippetBlock.js
[f13]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/SvelteElement.js
[f14]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/TaggedTemplateExpression.js
[f15]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/TransitionDirective.js
[f16]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/shared/element.js
