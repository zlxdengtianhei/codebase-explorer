# Parsing

**Capability.** Consumes raw template characters into Text nodes and locates matching brackets, strings, and regexes inside expression sources, forming the foundation AST for later phases.

Use text.js to understand how template text is chunked at `<` or `{`. Use the bracket utilities when reasoning about how the parser finds the end of embedded expressions without being confused by strings, comments, or regex literals.

**Depends on.**

- [Compiler Semantic Model](r4-compiler-model.md) · model-inferred · 0 edge(s)

Parent: [Compiler Pipeline](r4-compiler-pipeline.md)

## Units (9)

<a id="u-36401d8c3a23"></a>
### `text`

`export default function text(parser)` · [packages/svelte/src/compiler/phases/1-parse/state/text.js:L6-L23][f1]

Consumes template characters until the next `<` or `{` (or end of template) and appends a single Text node spanning that range, with raw set to the consumed text and data produced by decoding character references in text context (second argument false, versus true in attribute contexts).

calls: [decode_character_references](r1-parse-entities.md#u-a03f13997ae5)

**Uncertainties.**

- The behavioral difference of the decode flag between text and attribute contexts is defined in utils/html.js, not here

<a id="u-29a08a302323"></a>
### `count_leading_backslashes`

`function count_leading_backslashes(string, search_start_index)` · [packages/svelte/src/compiler/phases/1-parse/utils/bracket.js:L77-L85][f2]

Counts consecutive backslash characters walking backwards from search_start_index.

The loop decrements the index while string[i] === '\\' and returns the tally; callers use its parity to decide whether a character is escaped.

<a id="u-3e5597267416"></a>
### `find_matching_bracket`

`export function find_matching_bracket(template, index, open)` · [packages/svelte/src/compiler/phases/1-parse/utils/bracket.js:L94-L135][f2]

Returns the index of the closing bracket matching the opener at index, skipping over brackets nested inside strings, line comments, block comments, and regex literals, or undefined if the template ends first.

The close character comes from default_brackets ({ -> }, ( -> ), [ -> ]); depth starts at 1. Loop behavior per character: quotes jump past the literal via find_string_end; a '/' followed by '/' skips to past the next newline (Infinity, hence end of scan, if absent); '/' followed by '*' skips past the next '*/' likewise; any other '/' is treated as a regex start and skipped to its unescaped terminator; otherwise matching openers increment and closers decrement depth, returning the index at depth 0.

**Notes.**

- side_effect: Pure: reads only the template string, mutates no parser state.
- failure: Returns undefined rather than throwing when the closing bracket is never found.

calls: [find_string_end](r4-parse-phase.md#u-218d9a0afb81), [infinity_if_negative](r4-parse-phase.md#u-edd9bb8ecede), [find_regex_end](r4-parse-phase.md#u-61260c77d46c), [find_unescaped_char](r4-parse-phase.md#u-e7db0acb2cbc)

**Uncertainties.**

- A '/' not followed by '/', '*' or end-of-input is always treated as a regex start; division operators followed by a character would be mis-skipped, so this helper assumes the opener context makes regex detection safe.
- Empty next_char falls through the switch default implicitly via continue behavior at end of input.

<a id="u-61260c77d46c"></a>
### `find_regex_end`

`function find_regex_end(string, search_start_index)` · [packages/svelte/src/compiler/phases/1-parse/utils/bracket.js:L41-L43][f2]

Thin wrapper that returns the index of the first unescaped '/' at or after search_start_index, or Infinity if none exists, delegating entirely to find_unescaped_char.

calls: [find_unescaped_char](r4-parse-phase.md#u-e7db0acb2cbc)

<a id="u-218d9a0afb81"></a>
### `find_string_end`

`function find_string_end(string, search_start_index, string_start_char)` · [packages/svelte/src/compiler/phases/1-parse/utils/bracket.js:L21-L34][f2]

Finds the end index of a string literal starting at search_start_index, returning Infinity when the terminator is never found.

For backtick strings the whole input is searched (template literals may span lines); for single/double quotes the search is truncated at the first newline after the start (converted to Infinity if no newline exists), so quoted strings cannot extend past a line break. The actual scan is delegated to find_unescaped_char for the quote character.

**Notes.**

- condition: Backtick strings search the full input; quoted strings are limited to the current line by slicing at the next newline.

calls: [infinity_if_negative](r4-parse-phase.md#u-edd9bb8ecede), [find_unescaped_char](r4-parse-phase.md#u-e7db0acb2cbc)

**Uncertainties.**

- Truncation at the newline means the slice end is the newline index; whether the newline itself can terminate the quote search depends on find_unescaped_char over the sliced text.

<a id="u-e7db0acb2cbc"></a>
### `find_unescaped_char`

`function find_unescaped_char(string, search_start_index, char)` · [packages/svelte/src/compiler/phases/1-parse/utils/bracket.js:L52-L64][f2]

Scans forward from search_start_index for the first occurrence of char that is not escaped, returning its index, or Infinity if every occurrence is escaped or none exists.

Each indexOf hit is accepted only when the count of backslashes immediately before it is even; an odd count means the character is escaped and the search resumes after that hit, so 'a\\b' style pairs are skipped iteratively.

calls: [count_leading_backslashes](r4-parse-phase.md#u-29a08a302323)

<a id="u-edd9bb8ecede"></a>
### `infinity_if_negative`

`function infinity_if_negative(num)` · [packages/svelte/src/compiler/phases/1-parse/utils/bracket.js:L8-L13][f2]

Maps a negative number to Infinity so failed indexOf searches become a sentinel 'not found within the string' index.

Returns Infinity when num < 0, otherwise returns num unchanged.

<a id="u-cf3966ee18ec"></a>
### `match_bracket`

`export function match_bracket(parser, start, brackets = default_brackets)` · [packages/svelte/src/compiler/phases/1-parse/utils/bracket.js:L149-L180][f2]

Consumes parser.template from start, tracking a stack of open brackets, and returns the index just past the bracket that empties the stack; raises compiler errors on mismatch or EOF.

Quotes are skipped via match_quote (which itself may recurse into match_bracket for template-literal ${} expressions). Each opener from the brackets map pushes; any closer character pops the stack and throws e.expected_token at the closer's index when it does not match the expected partner of the popped opener; when the stack empties on a matching closer, that position is returned. If the template ends with brackets still open, e.unexpected_eof is thrown at template length. brackets defaults to default_brackets ({/(/[/]}).

**Notes.**

- failure: Throws e.expected_token on mismatched closer and e.unexpected_eof if input ends before the stack empties; never returns on unbalanced input.

uses: [function::match_quote::4164][f2]; calls: [match_quote](r4-parse-phase.md#u-bc749ce8d7ac), [match_bracket](r4-parse-phase.md#u-cf3966ee18ec)

**Uncertainties.**

- A closer arriving when the stack is empty pops undefined, so brackets[undefined] is undefined; char !== expected is then true and e.expected_token is thrown before the stack-empty return — the exact error for stray closers follows this path.

<a id="u-bc749ce8d7ac"></a>
### `match_quote`

`function match_quote(parser, start, quote)` · [packages/svelte/src/compiler/phases/1-parse/utils/bracket.js:L187-L213][f2]

Scans parser.template from start to find the closing quote of a string literal, returning the index of the quote, and throws e.unterminated_string_constant at start if the template ends first.

Backslash sets an escaped flag so the next character (including the quote) is skipped. In backtick strings only, '${' triggers a recursive match_bracket over the interpolation, so nested braces and strings inside template expressions are consumed correctly.

**Notes.**

- failure: Throws e.unterminated_string_constant(start) when EOF is reached before the closing quote.

calls: [match_bracket](r4-parse-phase.md#u-cf3966ee18ec)

**Uncertainties.**

- If match_bracket returns inside the interpolation, scanning continues normally afterwards; behavior when the interpolation's closing '}' is followed immediately by the backtick is handled by the ordinary quote check.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/1-parse/state/text.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/1-parse/utils/bracket.js
