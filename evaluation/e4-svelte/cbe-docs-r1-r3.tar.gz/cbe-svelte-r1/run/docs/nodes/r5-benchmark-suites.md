# Benchmark Suites

**Capability.** Measures reactivity fan-out and repeated-read costs (kairo variants, Mol bench) and SSR wrapper compile/render throughput against the runtime and compiler.

Use these self-contained suites to gauge performance regressions in the signal runtime or the compile-to-render path; each asserts its own correctness after timing. They consume the runtime and compiler from outside.

**Depends on.**

- [Client Runtime](r5-client-runtime.md) · model-inferred · 0 edge(s)
- [Compiler](r5-compiler.md) · model-inferred · 0 edge(s)
- [Benchmark Harness](r4-benchmark-harness.md) · graph-only · 15 edge(s)

Parent: [Svelte](r5-svelte.md)

## Units (5)

<a id="u-5d73821703da"></a>
### `kairo-broad-js-benchmark-suite`

`function setup()` · [benchmarking/benchmarks/reactivity/kairo/kairo_broad.js:L4-L27][f1]

Creates 50 parallel derived pairs off one head signal and a counter-ticking render effect per pair, measuring fan-out update cost.

setup() makes head state; for i in 0..49 it creates current = head+i, current2 = current+1, and a render_effect that reads current2 and increments a shared counter, tracking the last current2. run() sets head to 1 under flush, resets counter, then 50 more times sets head to i and asserts $.get(last) === i+50, finally asserting counter === 50*50 (all 50 render effects re-run per update). kairo_broad_unowned does 10 warmup setup/run/destroy cycles, then times 10 runs of 1000 run() calls through fastest_test, destroys, returns name plus fixed-to-2-decimal time and gc_time. kairo_broad_owned keeps the timed instance inside an effect_root (destroy_owned) and also calls the inner destroy; otherwise identical timing. Failed assertions throw out of run().

calls: [fastest_test](r4-benchmark-harness.md#u-0bbe8c671495), [assert](r4-benchmark-harness.md#u-823bd0dd0cd8)

<a id="u-ecc4ed518fc3"></a>
### `kairo-repeated-js-benchmark-suite`

`function setup()` · [benchmarking/benchmarks/reactivity/kairo/kairo_repeated.js:L6-L27][f2]

Times repeated reads of one signal inside a single derived (size=30 reads), measuring multi-read dependency handling.

setup() creates head state and a derived that sums $.get(head) 30 times in a loop, plus a render effect counting runs while reading the derived. run() sets head to 1 and asserts current === size, resets counter, then 100 times sets head to i and asserts current === i*size, finally asserting exactly 100 effect runs. kairo_repeated_unowned does 10 warmup setup/run/destroy cycles, times 10 batches of 1000 run() calls with fastest_test, destroys, and returns the benchmark name with 2-decimal time and gc_time. kairo_repeated_owned places warmup and the timed instance inside one $.effect_root (destroy_owned), times identically, then calls both destroy and destroy_owned. Assertion failures propagate; nothing is caught.

calls: [fastest_test](r4-benchmark-harness.md#u-0bbe8c671495), [assert](r4-benchmark-harness.md#u-823bd0dd0cd8)

<a id="u-5c08818196a5"></a>
### `mol-bench-js-benchmark-suite`

`function fib(n)` · [benchmarking/benchmarks/reactivity/mol_bench.js:L7-L10][f3]

Reproduces the Mol bench: two state signals A/B feed deriveds C..G, one of which (D) overrides its equals method for element-wise array equality, and three render effects push computed values into a result array checked with hard assertions.

fib(n) is naive recursion returning 1 at n<2; hard(n) is n + fib(16) = n+1597. setup() defines C = parity sum, D = mapped array with a custom equals comparing length and elements against this.v, E = hard(C+A+D[0]), F = hard(D[0] && B), G = C + (C || E%2) + D[0] + F. run(i) clears res, sets B=1 then A=1+i*2 in one flush and A=2+i*2, B=2 in another, then asserts res equals [3198, 1601, 3195, 1598]. mol_bench_owned/mol_bench_unowned each do 10 warmup setup/run(0)/destroy cycles, time 10 batches of 1e4 run(i) calls via fastest_test, return name plus 2-decimal time/gc_time; owned wraps warmup and the timed instance in a single $.effect_root and calls destroy_owned additionally. Assertion failures propagate.

calls: [fastest_test](r4-benchmark-harness.md#u-0bbe8c671495), [assert](r4-benchmark-harness.md#u-823bd0dd0cd8)

**Uncertainties.**

- The custom D.equals reads this.v, an internal field of the derived signal; its availability depends on svelte/internal/client internals not shown here.
- mol_bench_owned's ordered res values depend on effect scheduling order within a flush, which is internal behavior of the client runtime.

<a id="u-e49d890081fc"></a>
### `compile_svelte`

`async function compile_svelte()` · [benchmarking/benchmarks/ssr/wrapper/wrapper_bench.js:L7-L16][f4]

Compiles App.svelte for server rendering and returns the compiled component.

It reads `${cwd}/benchmarking/benchmarks/ssr/wrapper/App.svelte` via read_file, compiles it with svelte/compiler's compile using generate:'server', writes output.js.code to the wrapper's output/App.js via write, dynamically imports that file, and resolves to the module's default export. The import and file IO make this asynchronous; failures from read/write/compile/import propagate to the caller.

calls: [read_file](r4-benchmark-harness.md#u-19c8243b4a22), [write](r4-benchmark-harness.md#u-ccb2ac8173a1)

**Uncertainties.**

- The dynamic import path is a template string; whether any bundler rewrites it is outside this file.

<a id="u-2f9f0e0c3125"></a>
### `wrapper_bench`

`export async function wrapper_bench()` · [benchmarking/benchmarks/ssr/wrapper/wrapper_bench.js:L18-L36][f4]

Benchmarks server-side rendering of the wrapper app.

It awaits compile_svelte to get the App component, warms the JIT with 3 render(App) calls from svelte/server, then times 10 iterations of 100 renders via fastest_test, returning {benchmark:'wrapper_bench', time, gc_time} with times formatted to 2 decimals. Errors from compilation or rendering propagate.

calls: [fastest_test](r4-benchmark-harness.md#u-0bbe8c671495)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/benchmarking/benchmarks/reactivity/kairo/kairo_broad.js
[f2]: ../../../../../../eval/svelte-be645b4/benchmarking/benchmarks/reactivity/kairo/kairo_repeated.js
[f3]: ../../../../../../eval/svelte-be645b4/benchmarking/benchmarks/reactivity/mol_bench.js
[f4]: ../../../../../../eval/svelte-be645b4/benchmarking/benchmarks/ssr/wrapper/wrapper_bench.js
