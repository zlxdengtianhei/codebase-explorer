# Shared Runtime Utilities

**Capability.** Environment-agnostic helpers used by both client and server output: SSR attribute/class/style serialization (attr, clsx, to_class, to_style, append_styles, to_css_name) and shared runtime validation (store shape, dynamic-element tag, void-element warning, snippet stringification guard).

Compiled code in either target may call these; keep them environment-neutral. to_style's merge pipeline and the validate_* guards are the main entry points.

**Depended on by.**

- [Client Runtime](r4-client-runtime.md) · graph-confirmed · 2 edge(s)
- [DOM Blocks](r4-dom-blocks.md) · graph-confirmed · 1 edge(s)
- [DOM Elements & Events](r4-dom-elements.md) · graph-confirmed · 1 edge(s)
- [Reactive Primitives & Motion](r4-reactive-primitives.md) · model-inferred · 0 edge(s)
- [Server Runtime](r4-server-runtime.md) · model-inferred · 0 edge(s)

Parent: [Svelte Monorepo](r4-svelte-monorepo.md)

## Units (10)

<a id="u-83334ed78d84"></a>
### `packages/svelte/src/internal/shared/attributes.js:append_styles`

`function append_styles(styles, important = false)` · [packages/svelte/src/internal/shared/attributes.js:L91-L103][f1]

Renders a style dictionary into CSS declaration text.

Iterates enumerable keys, emitting a declaration only when the value is neither null/undefined nor ''; each is ' key: value' followed by ';' or ' !important;' when important is true. Returns the accumulated string, possibly ''.

<a id="u-12a88532ea06"></a>
### `attr`

`export function attr(name, value, is_boolean = false)` · [packages/svelte/src/internal/shared/attributes.js:L24-L29][f1]

Serializes one SSR attribute to a string, returning '' when it should be omitted.

If value is null/undefined, or falsy while is_boolean is true, it returns ''. The replacements table (only translate: true→'yes', false→'no') may normalize the value; with is_boolean it emits ' name' with no assignment, otherwise ' name="…"' with the value HTML-escaped in attribute mode by escape_html.

calls: [escape_html](r5-shared-lib.md#u-0f499dd45547)

**Uncertainties.**

- Exact attribute-mode escaping rules of escape_html are defined in escaping.js, not here.

<a id="u-2274c46486ff"></a>
### `clsx`

`export function clsx(value)` · [packages/svelte/src/internal/shared/attributes.js:L36-L42][f1]

Normalizes a class value while preserving Svelte's falsy handling.

Object inputs delegate to the external clsx package (merging class dictionaries/arrays); any other type returns the value itself, with '' substituted for null/undefined. Other falsy values such as 0 or false pass through unchanged, which the source flags as a Svelte 6 TODO.

uses: [clsx](../../catalog.json)

**Uncertainties.**

- Behavior of the external clsx package for object inputs is not visible in this file.

<a id="u-bb0adfe2b192"></a>
### `to_class`

`export function to_class(value, hash, directives)` · [packages/svelte/src/internal/shared/attributes.js:L52-L84][f1]

Builds a class attribute string from a base value, a component hash, and class directives, returning null when the result is empty.

The base value is stringified (null/undefined → ''); a truthy hash is appended with a space or becomes the sole content. Each directive key: when truthy the key is appended; when falsy, whole-token occurrences of that key are removed — a match requires a whitespace or string boundary on both sides, scanning left to right and resuming after the removed span. An empty result returns null so callers can omit the attribute.

**Uncertainties.**

- Falsy directive removal can strip tokens appended earlier in the same call (by value, hash, or a truthy directive); such combined edge cases are not separately verified.

<a id="u-c7b91478cfe6"></a>
### `to_css_name`

`function to_css_name(name)` · [packages/svelte/src/internal/shared/attributes.js:L109-L114][f1]

Normalizes a CSS property name for comparison: names not starting with '--' are lowercased; custom properties beginning with '--' keep their original case, since custom property names are case-sensitive.

<a id="u-50b25ac26373"></a>
### `to_style`

`export function to_style(value, styles)` · [packages/svelte/src/internal/shared/attributes.js:L121-L219][f1]

Merges an existing inline style string with style objects, returning the merged string or null when empty.

With styles given, an array input splits into [normal, important] dictionaries, otherwise the object is normal. The existing value has block comments stripped and is trimmed, then scanned character by character with a state machine tracking string literals ('"' or "'"), comments, and parenthesis depth; a ':' marks the property-name position, and ';' or end-of-input terminates a declaration only outside strings/comments/parens. Declarations whose to_css_name-normalized name appears among the objects' reserved names are dropped so the objects win; kept declarations are re-emitted trimmed with ';'. Normal styles are appended via append_styles, important ones with important=true. Without a styles argument, value is stringified, null/undefined becoming null.

calls: [packages/svelte/src/internal/shared/attributes.js:append_styles](r4-shared-runtime.md#u-83334ed78d84), [to_css_name](r4-shared-runtime.md#u-c7b91478cfe6)

**Uncertainties.**

- The inline parser does not validate CSS; malformed input such as unbalanced quotes or parens yields parser-dependent output not verified here.

<a id="u-f0c8633de633"></a>
### `prevent_snippet_stringification`

`export function prevent_snippet_stringification(fn)` · [packages/svelte/src/internal/shared/validate.js:L41-L47][f2]

Marks a snippet function so accidental stringification fails loudly: it overrides fn.toString to throw snippet_without_render_tag (returning '' only because toString must return a string; the thrown error takes effect in normal evaluation contexts), then returns fn unchanged.

raises: [snippet_without_render_tag](r2-shared-internals.md#u-04c44370ec95)

<a id="u-718446e58f9d"></a>
### `validate_dynamic_element_tag`

`export function validate_dynamic_element_tag(tag_fn)` · [packages/svelte/src/internal/shared/validate.js:L19-L25][f2]

Validates the `this` value of a dynamic element.

It calls tag_fn() once; if the tag is truthy but not a string, it throws svelte_element_invalid_this_value. Falsy tags (null/undefined/'' etc.) pass without error.

raises: [svelte_element_invalid_this_value](r2-shared-internals.md#u-7d812598d346)

<a id="u-f09c2e0aa53c"></a>
### `validate_store`

`export function validate_store(store, name)` · [packages/svelte/src/internal/shared/validate.js:L31-L35][f2]

Checks that a value used as a store is store-shaped: if store is non-null and its subscribe is not a function, throws store_invalid_shape(name).

Null/undefined pass silently; only the presence of a subscribe function is checked, not the rest of the store contract.

raises: [store_invalid_shape](r2-shared-internals.md#u-07015d4f432c)

<a id="u-1787859057c4"></a>
### `validate_void_dynamic_element`

`export function validate_void_dynamic_element(tag_fn)` · [packages/svelte/src/internal/shared/validate.js:L11-L16][f2]

Warns when a dynamic element tag names a void element.

It calls tag_fn() once; if the tag is truthy and is_void(tag) reports a void element, it emits the dynamic_void_element_content warning for that tag. Empty/falsey tags pass silently.

calls: [is_void](r1-dom-dom-utils.md#u-9c54e843c710), [dynamic_void_element_content](r2-shared-internals.md#u-166c10327168)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/shared/attributes.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/shared/validate.js
