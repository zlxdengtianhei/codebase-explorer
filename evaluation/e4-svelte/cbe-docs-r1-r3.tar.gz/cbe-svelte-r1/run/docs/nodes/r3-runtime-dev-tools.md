# Dev-Mode Diagnostics

**Capability.** Development-only instrumentation: `$inspect` tracing with signal labeling and stack cleanup, safe console logging of state, and equality helpers that warn on proxy-equality mismatches; plus generated runtime error throwers and client warning loggers.

Use this subtree for dev-mode observability and diagnostic surfaces. Tracing helpers are consumed by proxy and sources code; the equality helpers wrap proxy value unwrapping; error throwers and warning helpers are generated, single-purpose surfaces.

**Depended on by.**

- [Spring Motion](r3-public-motion.md) · graph-confirmed · 7 edge(s)
- [Reactive Window Values](r3-public-reactive-window.md) · graph-confirmed · 1 edge(s)
- [Deep Reactivity Proxies](r3-runtime-proxy.md) · graph-confirmed · 9 edge(s)
- [Signal Sources](r3-runtime-reactivity-sources.md) · graph-confirmed · 3 edge(s)
- [Code & Docs Generation](r3-tooling-codegen.md) · model-inferred · 0 edge(s)
- [Reactive Primitives & Motion](r4-reactive-primitives.md) · graph-only · 12 edge(s)

Parent: [Client Runtime Internals](r3-runtime.md)

## Units (10)

<a id="u-76249388f24e"></a>
### `tracing.js-tagging`

`export function tag(source, label)` · [packages/svelte/src/internal/client/dev/tracing.js:L180-L185][f1]

Helpers for labeling reactive values in traces.

tag sets source.label and forwards source.v to tag_proxy, which invokes the value's PROXY_PATH_SYMBOL hook with the label when present and returns the value unchanged. label formats a value for display: symbols render as Symbol(description), functions as '<function>', non-null objects as '<object>', everything else via String. Mostly stateless annotation used by proxies and reactive classes across the codebase.

<a id="u-ba4e4c464b32"></a>
### `packages/svelte/src/internal/client/dev/tracing.js:trace`

`export function trace(label, fn)` · [packages/svelte/src/internal/client/dev/tracing.js:L90-L130][f1]

Times and traces reactive reads performed by fn.

It saves and restores the module-level tracing_expressions in a finally block, installing a fresh entries map plus the active reaction. After running fn and measuring elapsed ms, the label is read untracked; then: if effect_tracking() is false it logs that the expression ran outside an effect; else if no dependencies were recorded it logs 'no reactive dependencies'; otherwise it opens a console group and logs each recorded signal entry via log_entry inside untrack before closing. Returns fn's value in all cases.

calls: [effects.js-trivial-effect-factories](r5-effects-module.md#u-191f01511fb1), [log_entry](r3-runtime-dev-tools.md#u-28361dd4c3b4), [untrack](r5-signal-core.md#u-aa0e067da463)

**Uncertainties.**

- How entries get populated during fn is not in this function; some read path must record into tracing_expressions.

<a id="u-28361dd4c3b4"></a>
### `log_entry`

`function log_entry(signal, entry)` · [packages/svelte/src/internal/client/dev/tracing.js:L22-L74][f1]

Prints one traced signal as a collapsed console group during $trace.

Skips signals whose value is UNINITIALIZED. Classifies the signal via get_type, decides dirty (signal.wv > active_reaction.wv or reaction.wv === 0), and prints the label/type with a bold blue style when dirty, snapshotting state objects. For '$derived' signals it recurses into their deps. It then prints signal.created, each updated entry's error when dirty, and any trace stacks from the optional TraceEntry, closing the group. The module-level tracing_expressions and its TraceEntry shape are declared alongside and consumed by trace.

**Uncertainties.**

- Assumes active_reaction is non-null (cast with a type assertion); behavior when called with no active reaction is not guarded.

<a id="u-507749353e33"></a>
### `get_stack`

`export function get_stack(label)` · [packages/svelte/src/internal/client/dev/tracing.js:L136-L174][f1]

Builds a cleaned-up Error stack for trace output.

Returns null when stack is unavailable. It drops the 'Error' header line and any line containing 'svelte/src/internal', and aborts with null if a line mentions 'validate_each_keys'. If nothing survives it returns null; otherwise it rewrites the error's stack to the filtered lines and its name to '<label>Error' (the Error suffix being needed for proper rendering) via define_property, returning the error object.

**Uncertainties.**

- Whether the validate_each_keys early-return is intentional silence for that callsite is not documented in the source.

<a id="u-5bbd41443b98"></a>
### `log_if_contains_state`

`export function log_if_contains_state(method, ...objects)` · [packages/svelte/src/internal/client/dev/console-log.js:L10-L35][f2]

Logs console arguments safely when they contain reactive state, returning the originals unchanged.

Inside untrack it inspects each object; objects carrying STATE_SYMBOL are replaced with a deep snapshot so logging does not leak live proxies. If any object contained state, it emits w.console_log_state for the method name and prints the transformed arguments with a '[snapshot]' label. The whole body is wrapped in try/catch with an empty catch, so any error (e.g. snapshot failure) is silently swallowed. Returns the original objects array regardless.

**Notes.**

- side_effect: Prints to console only when at least one argument contains reactive state; errors are silently ignored.

calls: [packages/svelte/src/internal/shared/clone.js:snapshot](r2-shared-internals.md#u-bfcc537be9f1), [untrack](r5-signal-core.md#u-aa0e067da463)

<a id="u-1016bd3303e1"></a>
### `equals`

`export function equals(a, b, equal = true)` · [packages/svelte/src/internal/client/dev/equality.js:L95-L101][f3]

Loose-equality counterpart of strict_equals.

Compares a == b against get_proxied_value(a) == get_proxied_value(b) and, when the two disagree, emits w.state_proxy_equality_mismatch with '==' or '!=' per the equal flag. Unlike strict_equals there is no try/catch, so a throwing proxy read propagates. Returns (a == b) === equal.

calls: [get_proxied_value](r3-runtime-proxy.md#u-0468b533d5f3)

<a id="u-28877320e4f3"></a>
### `strict_equals`

`export function strict_equals(a, b, equal = true)` · [packages/svelte/src/internal/client/dev/equality.js:L77-L87][f3]

Dev replacement for strict equality that warns when comparing a proxy directly differs from comparing its underlying value.

It computes a === b and get_proxied_value(a) === get_proxied_value(b); on mismatch it emits w.state_proxy_equality_mismatch with '===' or '!==' per the equal flag. Property reads on a or b may throw in restricted contexts, so the comparison is wrapped in try/catch that suppresses errors. Returns (a === b) === equal regardless of any warning.

calls: [get_proxied_value](r3-runtime-proxy.md#u-0468b533d5f3)

<a id="u-3c0065301141"></a>
### `init_array_prototype_warnings`

`export function init_array_prototype_warnings()` · [packages/svelte/src/internal/client/dev/equality.js:L4-L69][f3]

Patches Array.prototype.indexOf/lastIndexOf/includes to warn on suspected proxy-equality mismatches.

Each patch delegates to the original method, and only when the result misses (-1 or false) does it scan the array comparing get_proxied_value(this[i]) with strict equality; if an unproxied element would have matched, it emits w.state_proxy_equality_mismatch and returns the original result unchanged. lastIndexOf defaults from_index to this.length - 1 because the native implementation distinguishes undefined from omission. A cleanup function stored on Array.__svelte_cleanup restores the originals and is invoked at the start of a re-init, preventing duplicate patches in REPL reloads.

**Notes.**

- side_effect: Mutates the global Array.prototype and stores a restore hook on Array.__svelte_cleanup.

calls: [get_proxied_value](r3-runtime-proxy.md#u-0468b533d5f3)

<a id="u-b64379ea087c"></a>
### `errors.js-error-throwers`

`export function async_derived_orphan()` · [packages/svelte/src/internal/client/errors.js:L11-L21][f4]

Generated runtime error throwers for Svelte's internal client: each exported function unconditionally throws and never returns.

In DEV builds it constructs an Error whose message is `CODE\n<human message>\n<docs URL>`, sets `error.name = 'Svelte error'`, and throws it; in production it throws a bare Error containing only the docs URL. Parameterized functions interpolate their arguments into the DEV message. `each_key_duplicate` branches on its optional third parameter: when `value` is truthy the message includes the duplicate key, otherwise it omits it and reports only the indexes. The file also re-exports everything from `../shared/errors.js`.

imports: [errors.js module code (L1–L10)][f4]

**Uncertainties.**

- Whether DEV is resolved at build time or runtime cannot be determined from this file

<a id="u-4587bd56f822"></a>
### `warnings.js-generated-warning-helpers`

`export function assignment_value_stale(property, location)` · [packages/svelte/src/internal/client/warnings.js:L13-L19][f5]

Generated dev-warning helpers; each is a no-throw console.warn logger that differs only in its message.

In DEV builds each prints a styled '%c[svelte] name' header, a full explanatory message interpolated from its arguments (some branch on optional location to include or omit it), and a docs URL; in production each prints only the bare docs URL. They are called from throughout the client runtime to flag conditions such as stale assignment results, reactivity loss after await, non-reactive bindings, hydration mismatches and changed attributes, double unmounts, invalid ownership mutations, proxy equality pitfalls, no-op boundary resets, and slide transitions with non-block display.

**Uncertainties.**

- All warnings warn unconditionally within their DEV branch; whether callers gate these on a dev flag check of their own is not visible in this file.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dev/tracing.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dev/console-log.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dev/equality.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/errors.js
[f5]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/warnings.js
