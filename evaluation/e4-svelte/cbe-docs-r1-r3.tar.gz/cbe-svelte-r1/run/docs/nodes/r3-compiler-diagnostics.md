# Compiler Diagnostics & Warnings

**Capability.** Infrastructure for compile-time feedback: warning message emitters, the central emit gate, warning objects, svelte-ignore extraction/migration, serializable diagnostics with code frames, and preprocess source replacement used around compilation.

Use this subtree when working with warning codes, suppression via svelte-ignore, or error rendering. Generated emitters in warnings.js all route through w, and CompileDiagnostic backs both warnings and errors; replace_in_code supports preprocessors that run before parsing.

**Depends on.**

- [Svelte Compiler](r3-compiler.md) · containment · → 0 / ← 0 edge(s) (ancestor direct units and descendant subtree; → follows ` r3-compiler-diagnostics ` → ` r3-compiler `)
- [Code & Docs Generation](r3-tooling-codegen.md) · model-inferred · 0 edge(s)

**Depended on by.**

- [Semantic Analysis](r3-compiler-analyze.md) · graph-confirmed · 3 edge(s)
- [Compiler Shared Utilities & Legacy AST](r3-compiler-shared-utils.md) · graph-confirmed · 1 edge(s)
- [Client Transform](r3-compiler-transform-client.md) · model-inferred · 0 edge(s)

Parent: [Svelte Compiler](r3-compiler.md)

## Units (11)

<a id="u-2a223a23c812"></a>
### `warnings.js-warning-message-emitters`

`export function a11y_accesskey(node)` · [packages/svelte/src/compiler/warnings.js:L129-L131][f1]

Generated one-shot emitters for each warning code; each takes a nullable NodeLike node plus per-message string parameters, builds a fixed message ending in a https://svelte.dev/e/<code> documentation link, and forwards to w for suppression, filtering, and recording.

No emitter contains logic beyond message interpolation. Notable variations: a11y_aria_attributes, a11y_distracting_elements, a11y_hidden, a11y_misplaced_role, a11y_missing_attribute, and a11y_missing_content interpolate an element name; the a11y_incorrect_aria_attribute_type_* family interpolates attribute names (and allowed values for token/tokenlist variants); a11y_unknown_aria_attribute, a11y_unknown_role, and unknown_code conditionally append a 'Did you mean ...?' suggestion when the suggestion argument is truthy, otherwise emit a plain form; a11y_invalid_attribute interpolates the offending href value and attribute name; a11y_mouse_events_have_key_events names the event and its required companion; a11y_no_static_element_interactions interpolates element and handler names; a11y_role_has_required_aria_props interpolates required props; state_referenced_locally interpolates a name and expected type; node_invalid_placement_ssr prepends a caller-supplied message to a fixed SSR hydration caveat; svelte_self_deprecated and element_implicitly_closed/element_invalid_self_closing_tag interpolate tag or import names. Passing a suggestion of undefined, null, or empty string selects the message branch without the suggestion.

calls: [packages/svelte/src/compiler/warnings.js:w](r3-compiler-diagnostics.md#u-9c260d23c66a)

<a id="u-398217cb8a64"></a>
### `packages/svelte/src/compiler/warnings.js:InternalCompileWarning`

`class InternalCompileWarning extends CompileDiagnostic` · [packages/svelte/src/compiler/warnings.js:L7-L15][f1]

Concrete warning object extending CompileDiagnostic, labeled with the runtime name 'CompileWarning'.

The class body only overrides the name field; the constructor forwards code, message, and a [start, end] position tuple (or undefined) straight to the CompileDiagnostic superclass, adding no validation or transformation. Instances are created exclusively by the w helper and pushed into the shared warnings state, so their shape is whatever CompileDiagnostic establishes.

inherits: [CompileDiagnostic][f2]

**Uncertainties.**

- CompileDiagnostic's constructor behavior and stored fields are not in the supplied source, so instance shape beyond name and forwarded arguments is unproven

<a id="u-9c260d23c66a"></a>
### `packages/svelte/src/compiler/warnings.js:w`

`function w(node, code, message)` · [packages/svelte/src/compiler/warnings.js:L25-L39][f1]

Central emit gate for compiler warnings; every generated warning emitter delegates here.

Given an optional node, code, and message, it resolves the suppression stack: the global ignore_stack, or a node-specific stack from ignore_map when the node exists. Suppression only applies if a stack exists and its topmost set contains the code, in which case the warning is dropped silently. Next it constructs an InternalCompileWarning; the position is [node.start, node.end ?? node.start] when the node exists and start is defined, otherwise undefined. A final pass through warning_filter can still reject the warning; only surviving warnings are pushed onto the shared warnings array. Side effects are confined to that push.

**Notes.**

- condition: When node.start is undefined the warning is still constructed but with an undefined position, so filtering by warning_filter proceeds without location data.

calls: [packages/svelte/src/compiler/warnings.js:InternalCompileWarning](r3-compiler-diagnostics.md#u-398217cb8a64), [warning_filter][f3]; imports: [packages/svelte/src/compiler/state.js][f3]

**Uncertainties.**

- warning_filter's rejection criteria and the semantics of ignore_map/ignore_stack population live in state.js and are not verifiable from this file

<a id="u-4a9ee4fb9b67"></a>
### `extract_svelte_ignore`

`export function extract_svelte_ignore(offset, text, runes)` · [packages/svelte/src/compiler/utils/extract_svelte_ignore.js:L28-L82][f4]

Parses `svelte-ignore ` comments into ignored warning codes, advancing the offset past the matched prefix and returning an empty array when the prefix is absent.

Runes mode (`runes` true): tokens are comma-separated word codes; iteration stops at the first token not followed by a comma, and trailing prose is ignored. Known codes (warning codes plus IGNORABLE_RUNTIME_WARNINGS) are collected; legacy hyphenated codes are mapped through the replacements table or by turning hyphens into underscores — if that replacement is known a `legacy_code` warning fires at the token's computed source range, otherwise an `unknown_code` warning fires with a fuzzymatch suggestion. Non-runes mode is lax: every word token is collected, and for unknown codes whose mapped replacement is known the replacement is also pushed (backward compatibility), without emitting warnings.

calls: [fuzzymatch](r5-parse-diagnostics.md#u-4d517976b3f9)

**Uncertainties.**

- Effect of pushing unmapped unknown codes in non-runes mode (they are ignored downstream?) is decided by consumers.

<a id="u-22cdd6c7c71c"></a>
### `migrate_svelte_ignore`

`export function migrate_svelte_ignore(text)` · [packages/svelte/src/compiler/utils/extract_svelte_ignore.js:L89-L104][f4]

Rewrites legacy ignore codes in an ignore comment to their modern underscore form.

If the text lacks the `svelte-ignore ` prefix it is returned unchanged. Otherwise the prefix is kept and each `word-word…` code after it is replaced via the replacements table or hyphen-to-underscore mapping; a trailing comma is appended when another such code follows, converting legacy comma separation to the new form.

<a id="u-49c3d847da08"></a>
### `CompileDiagnostic`

`class CompileDiagnostic` · [packages/svelte/src/compiler/utils/compile_diagnostic.js:L52-L60][f2]

Serializable compiler error carrying code, message, position, locations and a code frame.

The constructor stores code and message; it sets `filename` only when the module-level `state.filename` is not the UNKNOWN_FILENAME sentinel. Given a position, it resolves start/end Locations via `state.locator` and, only when both resolve, builds `frame` with get_code_frame over `state.source` (0-based line, end column). toString renders `code: message`, then `filename:line:column` when filename and start exist, then the frame. toJSON returns a plain object of code, message, filename, start, end, position, frame — omitting undefined fields under JSON serialization. Reading module state means diagnostics depend on ambient compile state, not constructor arguments, for filename/source.

calls: [compile_diagnostic.js-code-frame-helpers](r3-compiler-diagnostics.md#u-afaee2ddc190)

**Uncertainties.**

- Whether state.locator or state.source can be unset during construction is decided elsewhere; the code assumes locator returns undefined (not throw) on failure.

<a id="u-afaee2ddc190"></a>
### `compile_diagnostic.js-code-frame-helpers`

`function tabs_to_spaces(str)` · [packages/svelte/src/compiler/utils/compile_diagnostic.js:L9-L11][f2]

Helpers for rendering source excerpts.

tabs_to_spaces expands leading tab runs (regex `/^\t+/`) to two spaces per tab, which keeps column math consistent with the caret rendering. get_code_frame slices up to five lines around the error line (start at line-2 clamped to 0, end at line+3 clamped to the line count), prefixes each with a zero-padded 1-based line number, converts tabs, and for the error line appends a second line containing a caret whose indent equals the converted prefix length of the error line up to the given column plus the number-width and separator. Line numbers here are 0-based inputs (callers pass start.line - 1).

**Uncertainties.**

- The caret column is derived from the end location's column, not the start's, in the constructor's call.

<a id="u-8eab9628969e"></a>
### `replace_in_code`

`export async function replace_in_code(regex, get_replacement, location)` · [packages/svelte/src/compiler/preprocess/replace_in_code.js:L69-L72][f5]

Replaces all regex matches in a Source's text with async-generated MappedCode replacements.

It awaits calculate_replacements over location.source, then perform_replacements splices the results into the original text; the awaited return is a single MappedCode for the whole transformed source.

calls: [calculate_replacements](r3-compiler-diagnostics.md#u-8a9b3380f617), [perform_replacements](r3-compiler-diagnostics.md#u-35d5b911e638)

<a id="u-8a9b3380f617"></a>
### `calculate_replacements`

`function calculate_replacements(re, get_replacement, source)` · [packages/svelte/src/compiler/preprocess/replace_in_code.js:L24-L40][f5]

Finds all regex matches in the source and computes async replacements.

String.replace invokes the callback for each match; for each one, get_replacement(...match) runs asynchronously and its promise resolves to a Replacement { offset (second-to-last match argument), length (match[0].length), replacement }. The callback returns '' so replace itself produces no substituted string; only the collected offsets matter. Promise.all waits for every replacement; a rejection in any get_replacement propagates through Promise.all to replace_in_code's caller.

**Uncertainties.**

- Overlapping matches are impossible because String.replace is non-overlapping by specification

<a id="u-35d5b911e638"></a>
### `perform_replacements`

`function perform_replacements(replacements, source)` · [packages/svelte/src/compiler/preprocess/replace_in_code.js:L47-L61][f5]

Reassembles the source with replacements applied, preserving source-map positions.

Iterating replacements in match order, it appends the unchanged slice from last_end to the current offset as a MappedCode built from a sliced Source, then the replacement, then advances last_end past the matched region; after the loop it appends the trailing unchanged slice. The result is one MappedCode containing original text with mapped positions for every untouched segment and preprocessor-generated mappings for replacements.

calls: [slice_source](r3-compiler-diagnostics.md#u-b98556db32bb), [MappedCode.concat](r2-preprocess-sourcemaps.md#u-1bc94121324a)

**Uncertainties.**

- Replacements are assumed sorted by offset and non-overlapping; this holds because calculate_replacements emits them in match order

<a id="u-b98556db32bb"></a>
### `slice_source`

`export function slice_source(code_slice, offset, { file_basename, filename, get_locat…` · [packages/svelte/src/compiler/preprocess/replace_in_code.js:L10-L17][f5]

Creates a sub-Source view of a code slice at a given offset.

It reuses the parent's file_basename and filename, and wraps get_location so that indices within the slice are shifted by the offset before lookup, letting mapped-code construction treat the slice as if it started the file.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/warnings.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/utils/compile_diagnostic.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/state.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/utils/extract_svelte_ignore.js
[f5]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/preprocess/replace_in_code.js
