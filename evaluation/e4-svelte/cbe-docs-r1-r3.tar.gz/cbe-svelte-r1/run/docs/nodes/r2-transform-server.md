# Server (SSR) code generation

**Capability.** Owns building the server-side SSR output Program for a component and its module script, via per-node server visitors that lower tags, slots, boundaries, assignments and identifiers to payload-based output.

Use this subtree for SSR semantics: how <slot>, <svelte:head>, {@html}, {@debug}, store assignments and class state are emitted as $$payload calls. transform-server owns the Program construction; its visitors share the assignment driver in transform-shared-assignments.

**Depends on.**

- [Compile diagnostics](r2-compiler-diagnostics.md) · model-inferred · 0 edge(s)
- [Shared transform assignment driver](r2-transform-shared-assignments.md) · graph-confirmed · 1 edge(s)

Parent: [Component compiler pipeline](r2-compiler.md)

## Units (16)

<a id="u-853d938c4671"></a>
### `transform-server.js-server-component`

`const instance = /** @type {Program} */ ( walk( /** @type {AST.SvelteNode} */ (analys…` · [packages/svelte/src/compiler/phases/3-transform/server/transform-server.js:L112-L121][f1]

Builds the server-side SSR output Program for a component.

It constructs a ComponentServerTransformState (hoisted starting with a star-import of svelte/internal/server, legacy_reactive_statements map, template/init placeholders set later by the Fragment visitor) and walks three ASTs: the module script with global_visitors, the instance script with global_visitors plus two overrides (ImportDeclaration nodes are moved into state.hoisted and replaced with b.empty; ExportNamedDeclaration with a declaration is replaced by its declaration, otherwise b.empty), and the template with global plus template visitors. Legacy reactive ($:) statements are reattached to the instance body; a missing mapping throws 'Could not find reactive statement'; assignments inside them yield let-declarations for legacy_reactive bindings, unshifted when non-empty. With component bindings, the template is restructured into snippets plus a $$render_inner function inside a do/while loop copying payloads until $$settled. Store subscriptions inject a $$store_subs var and a cleanup if. Bindable props (excluding $$-prefixed) and module exports are collected into props passed to $.bind_props at the template's end. Context is pushed/popped when dev or analysis.needs_context; $$restProps/$$sanitized_props/$$slots consts are injected per analysis flags; CSS is inlined as a $$css object (via render_stylesheet) with a payload.css.add call when css==='injected' and not a custom element. should_inject_props (context, props, needs/uses props, slots) decides the '$$props' parameter. Finally the component function is emitted: componentApi===4 wraps it with a svelte/server render method and default export; otherwise dev adds a throwing .render stub plus default export and a FILENAME annotation; non-dev just default-exports the function.

calls: [render_stylesheet](r5-css-transform.md#u-197b2d45aa0c)

**Uncertainties.**

- Behavior of the individual visitors (Fragment, RegularElement, etc.) referenced in template_visitors is not in this file.
- The '___snippet' property on FunctionDeclaration nodes is set elsewhere (Fragment visitor) and only accessed via ts-expect-error here.

<a id="u-7e11f4406861"></a>
### `server_module`

`export function server_module(analysis, options)` · [packages/svelte/src/compiler/phases/3-transform/server/transform-server.js:L392-L415][f1]

Builds the Program for a <script module> block.

It creates a ServerTransformState (legacy_reactive_statements included only so shared legacy visitors work, per the comment) and walks the module AST with global_visitors, then returns a module whose body is a star-import of svelte/internal/server followed by the transformed statements.

<a id="u-327ce0ca4830"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/AssignmentExpression.js:AssignmentExpression`

`export function AssignmentExpression(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/AssignmentExpression.js:L14-L16][f2]

Transforms server-side assignment expressions by delegating store and class-state handling to build_assignment.

If visit_assignment_expression produces a replacement it is returned; otherwise the visitor falls through to context.next() to continue normal traversal.

calls: [visit_assignment_expression](r2-transform-shared-assignments.md#u-b43a982ab161), [packages/svelte/src/compiler/phases/3-transform/server/visitors/AssignmentExpression.js:build_assignment](r2-transform-server.md#u-e2028cc30489)

**Uncertainties.**

- Exact semantics of visit_assignment_expression (when it invokes the callback vs. returns undefined) live outside this file.

<a id="u-e2028cc30489"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/AssignmentExpression.js:build_assignment`

`function build_assignment(operator, left, right, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/AssignmentExpression.js:L26-L100][f2]

Rewrites assignments to $store names and class state fields during server transform, returning null when no rewrite applies.

In runes mode, an assignment to an own non-computed this member resolves the class state field: if it is a constructor-declared state initializer and the left node matches, the assignment target becomes the backing key (private name, $state, $state.raw keep the property; other runes use field.key) with the visited right side; if the field is $derived/$derived.by with a private key, it becomes a setter call this.#name(value). Otherwise the code unwraps MemberExpression chains to the base object; if the base is not a $-prefixed identifier or the stripped name is not in scope, it returns null. A direct store assignment becomes $.store_set(name, value); a member-of-store assignment becomes $.store_mutate with a lazily initialized $$store_subs object, the original store name literal, the store id, and the visited assignment.

**Notes.**

- side_effect: Visits left and right subtrees via context.visit as part of building the replacement expressions.
- condition: Return of null signals visit_assignment_expression to keep the original assignment.

calls: [get_name](r4-compiler-model.md#u-99af92983a86), [get_rune](r4-compiler-model.md#u-5204b6ce4f7a), [build_assignment_value](r5-compiler-ast-utils.md#u-634ffef5ceee)

**Uncertainties.**

- context.state.state_fields and scope.get behavior are defined elsewhere; the mapping of field.node/key is inferred from usage here.

<a id="u-b851baaf8949"></a>
### `is_store_name`

`function is_store_name(name)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/AssignmentExpression.js:L105-L107][f2]

Reports whether a name looks like a Svelte store reference: it must start with '$' followed by a letter or underscore.

<a id="u-9d50dabfc8ae"></a>
### `AssignmentExpression.js module code (L1–L13)`

`module_region` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/AssignmentExpression.js:L1-L13][f2]

Type-only JSDoc imports and module imports for builders, build_assignment_value, get_name, get_rune, and visit_assignment_expression.

<a id="u-078a09b58b89"></a>
### `AssignmentExpression.js module code (L100–L104)`

`module_region` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/AssignmentExpression.js:L100-L104][f2]

Trailing region containing the is_store_name helper definition boundary; non-behavioral framing.

<a id="u-c7f9ace204ca"></a>
### `AssignmentExpression.js module code (L16–L25)`

`module_region` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/AssignmentExpression.js:L16-L25][f2]

JSDoc-typed local function build_assignment between the two exported visitors; non-behavioral framing.

<a id="u-20e9980643b4"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/DebugTag.js:DebugTag`

`export function DebugTag(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/DebugTag.js:L10-L24][f3]

Compiles {@debug} tags to a console.log of an object literal mapping each listed identifier to its visited value, followed by a debugger statement, both pushed onto the template.

<a id="u-20d147d776e2"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/HtmlTag.js:HtmlTag`

`export function HtmlTag(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/HtmlTag.js:L10-L13][f4]

Compiles {@html} tags by visiting the expression and pushing a $.html call onto the template.

<a id="u-3c30c4f1dadd"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/Identifier.js:Identifier`

`export function Identifier(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/Identifier.js:L11-L19][f5]

Rewrites reference identifiers in the server transform.

Non-references are left untouched (returns undefined, continuing traversal). $$props references become $$sanitized_props; all other references go through build_getter, which resolves the appropriate read expression for the binding.

calls: [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/utils.js:build_getter](r5-server-transform.md#u-25646e8536b2)

<a id="u-518018776eef"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/PropertyDefinition.js:PropertyDefinition`

`export function PropertyDefinition(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/PropertyDefinition.js:L10-L37][f6]

Strips runes from class property initializers in runes mode.

For a property whose value is a rune call: $state/$state.raw keep the property but drop the value entirely when there are no arguments, otherwise keep only the visited first argument. $derived/$derived.by become b.call('$.derived', ...) with the visited first argument, wrapped in a thunk for $derived (plain function for $derived.by), or null when there are no arguments. Non-rune properties continue via context.next().

**Uncertainties.**

- The $derived branch visits arguments[0] before checking arguments.length, which would throw on a zero-argument $derived property.

<a id="u-d7c757c85a8a"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/SlotElement.js:SlotElement`

`export function SlotElement(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/SlotElement.js:L11-L54][f7]

Compiles <slot> elements into $.slot($$payload, $$props, name, props, fallback) wrapped in empty-comment hydration markers.

Attributes are collected: spreads are visited into a spreads list; regular attributes become init properties except `slot` (ignored) and `name` (which becomes the slot name literal, defaulting to 'default'). With no spreads the props are an object literal; otherwise $.spread_props combines the object with the spread expressions. The fallback is null when the fragment is empty, else a thunk of the visited fragment.

calls: [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/utils.js:build_attribute_value](r5-server-transform.md#u-8ce176223a22)

<a id="u-c2a9e301270e"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/SvelteBoundary.js:SvelteBoundary`

`export function SvelteBoundary(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/SvelteBoundary.js:L12-L38][f8]

Compiles <svelte:boundary> for SSR.

It emits BLOCK_OPEN, then chooses content: a `pending` attribute (visited via build_attribute_value) is called with $$payload; otherwise a `pending` snippet block inside the fragment is rendered by visiting its body; with neither, the whole fragment is rendered. BLOCK_CLOSE ends the boundary region.

calls: [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/utils.js:build_attribute_value](r5-server-transform.md#u-8ce176223a22)

**Uncertainties.**

- Behavior when both a pending attribute and pending snippet exist: the attribute branch wins by if/else order.

<a id="u-9e86d472de3c"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/SvelteHead.js:SvelteHead`

`export function SvelteHead(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/SvelteHead.js:L10-L16][f9]

Compiles <svelte:head> into a $.head($$payload, arrow) call where the arrow takes $$payload and renders the visited fragment block; the statement is pushed onto the template.

<a id="u-4fbc61d80839"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/UpdateExpression.js:UpdateExpression`

`export function UpdateExpression(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/UpdateExpression.js:L9-L26][f10]

Rewrites ++/-- on store subscriptions.

If the argument is an identifier whose binding kind is 'store_sub', it becomes $.update_store_pre (prefix) or $.update_store (postfix), given a lazily initialized $$store_subs object, the original '$name' literal, the underlying store id `name`, and a -1 literal only for '--'. All other update expressions continue via context.next().

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/transform-server.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/AssignmentExpression.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/DebugTag.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/HtmlTag.js
[f5]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/Identifier.js
[f6]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/PropertyDefinition.js
[f7]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/SlotElement.js
[f8]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/SvelteBoundary.js
[f9]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/SvelteHead.js
[f10]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/UpdateExpression.js
