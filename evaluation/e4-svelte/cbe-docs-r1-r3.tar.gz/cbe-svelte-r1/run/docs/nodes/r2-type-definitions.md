# Type contracts

**Capability.** Owns the compile-time-only public type vocabulary: the full element/attribute typing system in elements.d.ts, action type contracts, and animation option/param declarations. No runtime behavior.

Enter here when authoring typed components or templates. The element typing system is layered: foundations (Booleanish, event handlers, ARIA) feed HTMLAttributes/SVGAttributes, which feed per-element interfaces and the SvelteHTMLElements tag mapping.

**Children.**

- [Element attribute typing system](r2-element-types.md) `r2-element-types` · 9 unit(s)
- [Action and animation type contracts](r2-action-animate-types.md) `r2-action-animate-types` · 4 unit(s)

**Depended on by.**

- [Animation runtime \(flip\)](r2-animate-flip.md) · model-inferred · 0 edge(s)

Parent: [Svelte compiler and runtime](r2-svelte.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
