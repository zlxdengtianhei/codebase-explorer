# DOM Blocks

**Capability.** Client-side implementations of template blocks: {#if} branch swapping with batch-aware commits, {#html} rendering with hydration hash checks, and dynamic-tag `<svelte:element>` rendering with transition awareness, plus scoped CSS custom property application.

Use this subtree to see how compiled block constructs behave at runtime. if_block coordinates with Batches for deferred branch swaps; html validates hydration hashes; css_props applies custom properties reactively.

**Depends on.**

- [Effect Batching & Scheduling](r3-runtime-reactivity-batching.md) · graph-confirmed · 1 edge(s)
- [Signal Sources](r3-runtime-reactivity-sources.md) · model-inferred · 0 edge(s)
- [Hydration Cursor State](r1-hydration-cursor.md) · graph-only · 16 edge(s)
- [DOM primitives: operations and templates](r2-client-dom-core.md) · graph-only · 13 edge(s)
- [Effect Lifecycle](r5-effects-module.md) · graph-only · 13 edge(s)

Parent: [Client Runtime Internals](r3-runtime.md)

## Units (9)

<a id="u-5467723df322"></a>
### `if_block`

`export function if_block(node, fn, elseif = false)` · [packages/svelte/src/internal/client/dom/blocks/if.js:L26-L46][f1]

Implements an {#if}/{:else if} block that swaps consequent/alternate branch effects as the chosen branch changes.

The block effect calls fn(set_branch) each run, tracking whether a branch was chosen; if none was, update_branch(null, null) clears any active branch. set_branch records that a branch was selected and delegates to update_branch with the boolean condition. When hydrating, the anchor afterwards becomes the hydration node. The `elseif` flag makes the effect EFFECT_TRANSPARENT, which per the docstring affects which transitions count as local.

<a id="u-c58d5f81e582"></a>
### `packages/svelte/src/internal/client/dom/blocks/if.js:if_block`

`export function if_block(node, fn, elseif = false)` · [packages/svelte/src/internal/client/dom/blocks/if.js:L49-L54][f1]

Continuation fragment of if_block's closure state (offscreen_fragment declaration region); no separate behavior.

<a id="u-ae7c5c1016f1"></a>
### `update_branch`

`const update_branch = ( /** @type {boolean | null} */ new_condition, /** @type {null …` · [packages/svelte/src/internal/client/dom/blocks/if.js:L81-L136][f1]

Switches the rendered branch when the condition actually changes; an unchanged condition returns immediately.

During hydration, if the HYDRATION_START_ELSE instruction matches the new condition's presence, the server DOM is removed, the anchor reset, hydrating turned off and restored at the end (mismatch path). When appends are deferred (should_defer_append), new content is branched into an offscreen fragment with a text anchor, the incoming effect is removed from the batch's skipped set while the outgoing one is added, and commit is scheduled via batch.add_callback; otherwise commit runs synchronously, creating the consequent or alternate effect lazily via `??=` so branch effects are only created when first needed.

calls: [packages/svelte/src/internal/client/dom/blocks/if.js:commit](r3-runtime-dom-blocks.md#u-7ea0ede4bea2), [effects.js-trivial-effect-factories](r5-effects-module.md#u-191f01511fb1)

**Uncertainties.**

- should_defer_append semantics live in operations.js.

<a id="u-7ea0ede4bea2"></a>
### `packages/svelte/src/internal/client/dom/blocks/if.js:commit`

`function commit()` · [packages/svelte/src/internal/client/dom/blocks/if.js:L54-L79][f1]

Applies the current branch condition to the DOM: if content was rendered offscreen for a deferred batch, the trailing anchor text node is removed and the fragment inserted before the anchor.

Then the effect matching the condition is resumed and the opposite effect is paused, its cleanup nulling the corresponding effect slot so it can be recreated later.

calls: [resume_children](r5-effects-module.md#u-f5814c70931b), [pause_effect](r5-effects-module.md#u-340d218bcd6f)

<a id="u-80bc19e4c534"></a>
### `if.js module code (L1–L25)`

`module_region` · [packages/svelte/src/internal/client/dom/blocks/if.js:L1-L25][f1]

Imports for the if block; also notes a pending TODO to reinstate a prior behavior change.

<a id="u-72a5d8905202"></a>
### `html`

`export function html(node, get_value, svg = false, mathml = false, skip_warning = false)` · [packages/svelte/src/internal/client/dom/blocks/html.js:L44-L119][f2]

Renders reactive HTML into the DOM before an anchor inside a template effect.

Each run compares the new get_value() (nullish coerced to '') with the previous value: if unchanged it only calls hydrate_next while hydrating and returns. When changed, it first removes the effect's existing DOM via remove_effect_dom and clears nodes_start/nodes_end, then returns early if the new value is empty. If hydrating, it reads the server hash comment, walks siblings until an empty-data comment terminator; if none is found it warns hydration_mismatch and throws HYDRATION_ERROR, and in DEV without skip_warning it verifies the hash via check_hash, then assigns nodes and sets the hydrate node past the terminator. Otherwise it parses the value via create_fragment_from_html (script tags deliberately not executed), wrapping in <svg>/<math> when the svg or mathml flags are set, assigns first/last child nodes to the effect, and inserts the fragment before the anchor — unwrapping children one by one for svg/mathml, inserting the fragment whole otherwise.

**Notes.**

- failure: During hydration, a missing empty-comment terminator causes w.hydration_mismatch() then throw HYDRATION_ERROR
- side_effect: Mutates the active effect's nodes_start/nodes_end and the live DOM before the anchor

calls: [check_hash](r3-runtime-dom-blocks.md#u-1df4a5c06d12), [create_fragment_from_html](r4-dom-elements.md#u-f51e86a3ef3c), [assign_nodes](r2-client-dom-core.md#u-081194bea535), [destroy_effect](r5-effects-module.md#u-214ad59ce57a), [template_effect](r5-effects-module.md#u-5f7f1fcbe917), [hydration.js-state-and-guards](r1-hydration-cursor.md#u-f1b7a30a3c1f)

**Uncertainties.**

- Exact behavior of HYDRATION_ERROR as a throw value (it is a sentinel, per constants import)
- Whether anchor.before(fragment) with a fragment works identically across target browsers is not established here

<a id="u-1df4a5c06d12"></a>
### `check_hash`

`function check_hash(element, server_hash, value)` · [packages/svelte/src/internal/client/dom/blocks/html.js:L20-L34][f2]

Compares a server-rendered hydration hash against the client HTML value and warns on mismatch.

Returns immediately if there is no server hash or it matches hash(String(value ?? '')). On mismatch it builds a location string from the element's __svelte_meta.loc ('near file:line:column'), falling back to the current dev component's FILENAME ('in file'), or undefined if neither exists, then emits w.hydration_html_changed with sanitize_location applied.

**Notes.**

- condition: Only active in DEV builds at its single call site; the element __svelte_meta lookup uses a ts-expect-error cast

calls: [hash](r1-dom-dom-utils.md#u-a8a8fa6d6333), [sanitize_location](r1-dom-dom-utils.md#u-eb8e19f29107)

**Uncertainties.**

- The exact warning text and whether sanitize_location handles an undefined argument are defined in w and utils, not shown

<a id="u-165ac079f0d2"></a>
### `packages/svelte/src/internal/client/dom/blocks/svelte-element.js:element`

`export function element(node, get_tag, is_svg, render_fn, get_namespace, location)` · [packages/svelte/src/internal/client/dom/blocks/svelte-element.js:L36-L166][f3]

Renders a dynamic-tag element reactively, switching between tags with transition awareness.

Saves was_hydrating and advances hydration; captures the existing element if the hydrate node is an ELEMENT_NODE (advancing hydration again) and uses hydrate_node as anchor while hydrating. Inside an EFFECT_TRANSPARENT block it computes next_tag (null when get_tag() is falsy) and the namespace (get_namespace(), else SVG namespace when is_svg or tag is 'svg', else null); if the tag is unchanged it returns. It temporarily sets the current each-item block so animate: directives bind correctly, then handles the existing effect: pause (outro) with a callback clearing effect/current_tag when next_tag is null, resume when the tag matches current_tag, or immediate destroy plus set_should_intro(false) when the tag changes. A new element is created via createElementNS/createElement (reusing the hydrated element), tagged with __svelte_meta location info in DEV, its nodes assigned, and render_fn run with a child anchor: during hydration a comment is appended for raw-text elements, the child anchor is the first child or an appended text node, hydration is disabled when no child anchor exists, otherwise the hydrate node moves to it. After render_fn, active_effect.nodes_end is set to the element and it is inserted before the anchor; tag/current_tag are updated, intro is re-enabled, and the each-item context restored. After the block, if it was hydrating, hydration state is restored with set_hydrating(true) and the saved anchor.

**Notes.**

- side_effect: Sets element.__svelte_meta with dev_stack parent and file/line/column in DEV when location is provided
- condition: Outro of the old tag can be aborted by resuming if the same tag returns before teardown completes

calls: [set_current_each_item](r5-each-block.md#u-bde2be852937), [set_should_intro][f4], [pause_effect](r5-effects-module.md#u-340d218bcd6f), [resume_children](r5-effects-module.md#u-f5814c70931b), [destroy_effect](r5-effects-module.md#u-214ad59ce57a), [effects.js-trivial-effect-factories](r5-effects-module.md#u-191f01511fb1), [packages/svelte/src/internal/client/reactivity/effects.js:block](r5-effects-module.md#u-75d755e7c63c), [assign_nodes](r2-client-dom-core.md#u-081194bea535), [is_raw_text_element](r1-dom-dom-utils.md#u-8ee9370d0cd9), [hydration.js-state-and-guards](r1-hydration-cursor.md#u-f1b7a30a3c1f), [operations.js-node-navigation](r2-client-dom-core.md#u-a31f01c2fa93)

**Uncertainties.**

- The assumption that namespaces never change without the tag changing is stated in a comment but unverified
- Behavior when render_fn populates content for a void element is only described by comment (silently discarded DOM), not enforced here

<a id="u-c71adbe36cde"></a>
### `css_props`

`export function css_props(element, get_styles)` · [packages/svelte/src/internal/client/dom/blocks/css-props.js:L11-L29][f5]

Applies reactive CSS custom properties to an element via a render effect.

During hydration it advances the hydrate node to the element's first child so subsequent hydration continues past it. The render effect reads get_styles on each change; for each key it calls element.style.setProperty when the value is truthy and removeProperty when falsy, so empty-string or falsy values remove the property rather than set it.

calls: [hydration.js-state-and-guards](r1-hydration-cursor.md#u-f1b7a30a3c1f), [effects.js-trivial-effect-factories](r5-effects-module.md#u-191f01511fb1)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/blocks/if.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/blocks/html.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/blocks/svelte-element.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/render.js
[f5]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/blocks/css-props.js
