# Shared Utilities

**Capability.** Framework-wide constants and predicates (HTML/SVG/MathML element classes, attribute aliases, boolean/DOM properties, delegated events, runes, hashing) and HTML nesting validation rules, consumed by compiler and both runtimes.

Use this before duplicating any element/attribute knowledge. utils.js is the single source of the fixed element and event lists; html-tree-validation encodes which parent/ancestor combinations are legal.

**Children.**

- [DOM & Rune Constant Predicates](r1-dom-dom-utils.md) `r1-dom-dom-utils` · 36 unit(s)
- [HTML Nesting Validation](r1-html-tree-validation.md) `r1-html-tree-validation` · 3 unit(s)

Parent: [Svelte Monorepo](r1-root.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
