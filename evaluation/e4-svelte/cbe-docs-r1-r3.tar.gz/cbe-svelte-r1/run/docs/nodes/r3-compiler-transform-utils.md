# Shared Transform Utilities

**Capability.** Fragment node cleaning and whitespace rules, `{@const}` topological ordering, namespace inference for children, hoisting checks, and dev-only `$inspect` lowering used by both client and server transforms.

Use this subtree for cross-target transform logic. Client and server Fragment visitors both depend on clean_nodes/infer_namespace, and rune-call lowering funnels `$inspect` through transform_inspect_rune.

**Depends on.**

- [Server Transform \(SSR\)](r3-compiler-transform-server.md) · model-inferred · 0 edge(s)

**Depended on by.**

- [Client Transform](r3-compiler-transform-client.md) · graph-confirmed · 3 edge(s)
- [Server Transform \(SSR\)](r3-compiler-transform-server.md) · graph-confirmed · 3 edge(s)

Parent: [Code Transformation](r3-compiler-transform.md)

## Units (7)

<a id="u-2ed26069223c"></a>
### `clean_nodes`

`export function clean_nodes( parent, nodes, path, namespace = 'html', state, // TODO …` · [packages/svelte/src/compiler/phases/3-transform/utils.js:L145-L324][f1]

Splits template child nodes into hoisted and regular sets and trims whitespace per documented rules, mutating text nodes in place.

When state.analysis.runes is false it first reorders ConstTags via sort_const_tags. Comments are dropped when preserve_comments is false. ConstTag, DebugTag, SvelteBody/Window/Document/Head, TitleElement, and SnippetBlock nodes are hoisted; everything else stays regular. When preserve_whitespace is false: whitespace-only leading/trailing Text nodes are removed, remaining boundary text has its leading/trailing whitespace stripped; whitespace between a text and a non-text node collapses to a single space (removed entirely when the previous text already ends in whitespace), except that whitespace adjacent to ExpressionTags is kept since they count as one text. Whitespace-only interior text is dropped entirely when namespace is svg outside any <text> element, or when the parent is select/tr/table/tbody/thead/tfoot/colgroup/datalist. Inside a <pre>, a lone leading newline (\n or \r\n) is discarded. A lone script child gets an empty Comment appended so run_scripts can node.replaceWith it. Returns hoisted, trimmed, is_standalone (single non-dynamic RenderTag, or non-dynamic Component without HMR and without --prefixed attributes), and is_text_first (fragment-like parent whose first node is Text or ExpressionTag), which forces an anchor comment so text is not fused with surroundings.

**Notes.**

- side_effect: Mutates first/last Text nodes' raw and data in place even when the node is later dropped from trimmed.
- condition: preserve_whitespace and preserve_comments are explicit parameters because component transform state does not yet inherit the module options, per the in-code TODO.

calls: [utils-js-sort-const-tags](r3-compiler-transform-utils.md#u-fe7b8b768228)

**Uncertainties.**

- Whether trimming mutations leak to shared AST text nodes reused elsewhere is not established here.

<a id="u-fca641f4927b"></a>
### `determine_namespace_for_children`

`export function determine_namespace_for_children(node, namespace)` · [packages/svelte/src/compiler/phases/3-transform/utils.js:L442-L452][f1]

Decides the child namespace directly from an element's own name and metadata: foreignObject forces 'html', metadata.svg yields 'svg', metadata.mathml yields 'mathml', and everything else yields 'html'.

Unlike infer_namespace it never inspects children or falls back to the incoming namespace argument except as the default return.

<a id="u-b0bc5038f26b"></a>
### `infer_namespace`

`export function infer_namespace(namespace, parent, nodes)` · [packages/svelte/src/compiler/phases/3-transform/utils.js:L332-L378][f1]

Chooses the namespace for the children of a node when creating a fragment.

A RegularElement named foreignObject always yields 'html'. For RegularElement or SvelteElement parents, metadata.svg yields 'svg', metadata.mathml yields 'mathml', otherwise 'html'. For namespace-resetting parents (Fragment, Root, Component, SvelteComponent, SvelteFragment, SnippetBlock, SlotElement) it calls check_nodes_for_namespace(nodes, 'keep') and adopts the result unless it is 'keep' or 'maybe_html'. Otherwise it scans top-level RegularElement children: a mathml element keeps 'mathml' only if no svg was seen, an svg element keeps 'svg' only if nothing was seen, any plain element short-circuits to 'html', and mixed namespaces or no elements fall back to the incoming namespace.

calls: [utils-js-check-nodes-for-namespace](r3-compiler-transform-utils.md#u-fa4ae41ef14a)

**Uncertainties.**

- The deep scan only inspects direct RegularElement children in the final loop; nested elements are covered only through check_nodes_for_namespace for the reset-parent case.

<a id="u-b9dd511b4830"></a>
### `is_hoisted_function`

`export function is_hoisted_function(node)` · [packages/svelte/src/compiler/phases/3-transform/utils.js:L24-L33][f1]

Reports whether a node is a function node flagged as hoisted.

It returns true only for ArrowFunctionExpression, FunctionExpression, or FunctionDeclaration nodes whose metadata.hoisted === true; any other node type returns false, and function nodes without the metadata flag also return false. The metadata is compiler-attached, so callers rely on earlier phases having set it.

**Uncertainties.**

- Which phase sets metadata.hoisted is not visible in this file.

<a id="u-f64464c8fc01"></a>
### `transform_inspect_rune`

`export function transform_inspect_rune(node, context)` · [packages/svelte/src/compiler/phases/3-transform/utils.js:L459-L481][f1]

Lowers $inspect rune calls into $.inspect calls, only in dev builds: it returns b.empty immediately when dev is false, so production emits nothing.

For `$inspect(...).xxx` member calls it visits the callee object's arguments and the outer call's first argument; for plain `$inspect(...)` it visits all call arguments. In client generation the inspected args are wrapped via b.thunk(b.array(...)) (lazy), while server generation passes b.array(...) directly (eager).

**Notes.**

- condition: as_fn is true only when state.options.generate === 'client'; the thunk-vs-array choice follows from it.

uses: [packages/svelte/src/compiler/phases/3-transform/client/visitors/CallExpression.js:CallExpression](r4-client-transform.md#u-a7da2a1bef1e), [packages/svelte/src/compiler/phases/3-transform/server/visitors/CallExpression.js:CallExpression](r3-compiler-transform-server.md#u-095e9ef68802)

**Uncertainties.**

- A member-expression form with no arguments (node.arguments[0] undefined) is passed to visit without a guard; resulting behavior is not visible here.

<a id="u-fe7b8b768228"></a>
### `utils-js-sort-const-tags`

`function sort_const_tags(nodes, state)` · [packages/svelte/src/compiler/phases/3-transform/utils.js:L40-L67][f1]

sort_const_tags reorders ConstTag nodes in a node list into topological dependency order, matching Svelte 4 behavior, and defers all non-ConstTag nodes to the end in original order.

For each ConstTag it extracts the identifiers bound by its single declaration, resolves them to bindings via state.scope.get, and walks the init expression collecting referenced bindings (only is_reference identifiers count; the walk uses set_scope to track scopes). Bindings with no scope entry are skipped as dependencies. If no ConstTags exist the input is returned unchanged. Edges connect each tag's binding to tag bindings it depends on; check_graph_for_cycles detects cycles, and a non-empty cycle raises e.const_tag_cycle with the offending tag and a 'a → b → …' name chain (throw propagates to the caller). Otherwise a recursive add() emits dependencies before dependents, producing [sorted ConstTags, other nodes].

calls: [extract_identifiers](r5-compiler-ast-utils.md#u-90eb95affc00), [check_graph_for_cycles](r2-analyze-shared-validation.md#u-9450956ffc9b)

**Uncertainties.**

- When a ConstTag declares multiple bindings mapped to the same bindings map, later tags overwrite earlier ones silently.
- Duplicate ConstTag nodes could recurse infinitely in add() if they share one node object; not established from this source.

<a id="u-fa4ae41ef14a"></a>
### `utils-js-check-nodes-for-namespace`

`function check_nodes_for_namespace(nodes, namespace)` · [packages/svelte/src/compiler/phases/3-transform/utils.js:L387-L392][f1]

check_nodes_for_namespace applies a heuristic over a node list to refine a tentative namespace: keep the current one unless a non-svg/non-mathml regular element is found (always 'html'), or only svg/mathml elements plus non-whitespace text appear.

For each top-level node it walks with zimmerframe, entering only EachBlock, IfBlock, AwaitBlock, Fragment, KeyBlock, RegularElement, SvelteElement, and Text. The shared RegularElement/SvelteElement visitor sets namespace to 'html' and stops the walk when the element is neither svg nor mathml; when namespace is still 'keep' it adopts 'svg' or 'mathml' from element metadata. A Text visitor with non-whitespace-trimmed data sets namespace to 'maybe_html'. The walk short-circuits, returning 'html' immediately once decided; otherwise the accumulated namespace is returned.

**Uncertainties.**

- Once namespace is 'maybe_html' or a concrete svg/mathml, later plain elements still force 'html' via the visitor's first branch; exact precedence across nested walks follows visitor order and is not separately tested here.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/utils.js
