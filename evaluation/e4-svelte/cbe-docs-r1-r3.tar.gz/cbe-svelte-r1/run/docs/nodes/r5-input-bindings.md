# Input Bindings

**Capability.** Two-way bindings for input value/checked/group/files, including number coercion and binding-group value collection, built as render effects over signals.

Use to see how compiled bind: directives behave at runtime; all bindings create effects via the effect factories and read/untrack through signal-core.

**Depends on.**

- [Effect Lifecycle](r5-effects-module.md) · graph-confirmed · 5 edge(s)
- [Signal Core](r5-signal-core.md) · graph-confirmed · 3 edge(s)

Parent: [Client Runtime](r5-client-runtime.md)

## Units (7)

<a id="u-d6e0e6bda8ca"></a>
### `bind_checked`

`export function bind_checked(input, get, set = get)` · [packages/svelte/src/internal/client/dom/elements/bindings/input.js:L220-L240][f1]

Two-way binds an input's checked state.

Change and form-reset events push input.checked (defaultChecked on reset) to the setter. At setup, if hydrating with a defaultChecked/checked mismatch or untrack(get) is nullish, input.checked is pushed. A render_effect writes input.checked = Boolean(get()).

calls: [listen_to_event_and_reset_event](r3-runtime-dom-elements.md#u-adb7ad8d3643), [untrack](r5-signal-core.md#u-aa0e067da463), [effects.js-trivial-effect-factories](r5-effects-module.md#u-191f01511fb1)

<a id="u-00ad8cbfeb28"></a>
### `bind_files`

`export function bind_files(input, get, set = get)` · [packages/svelte/src/internal/client/dom/elements/bindings/input.js:L287-L304][f1]

Two-way binds input.files.

The change event pushes input.files to the setter; during hydration a truthy input.files is pushed at setup. A render_effect assigns input.files = get().

calls: [listen_to_event_and_reset_event](r3-runtime-dom-elements.md#u-adb7ad8d3643), [effects.js-trivial-effect-factories](r5-effects-module.md#u-191f01511fb1)

**Uncertainties.**

- input.files assignment is browser-defined; the source cannot guarantee the write takes effect

<a id="u-dbd1fc23c7b5"></a>
### `bind_group`

`export function bind_group(inputs, group_index, input, get, set = get)` · [packages/svelte/src/internal/client/dom/elements/bindings/input.js:L126-L212][f1]

Two-way binds one input of a radio/checkbox group.

Resolves the shared binding_group array by indexing inputs with group_index (creating nested arrays with ??=) and pushes the input. The change handler (and reset handler, which sets [] for checkboxes or null otherwise) reads input.__value; for checkboxes it becomes the array of all checked group values via get_binding_group_value. A render_effect applies get(): checkbox checked = (value || []).includes(__value); radio checked = is(__value, value). If hydrating with defaultChecked !== input.checked, a flag defers: a later microtask derives the value from the group's DOM state (checked checkbox values, or the first checked input's __value) and calls set. Teardown splices the input out of its group. A module-level pending Set plus queue_micro_task sorts each newly created group by compareDocumentPosition (DocumentPosition FOLLOWING = 4 sorts first) to keep stable order across insertion orders.

calls: [listen_to_event_and_reset_event](r3-runtime-dom-elements.md#u-adb7ad8d3643), [get_binding_group_value](r5-input-bindings.md#u-1bfc194f94a2), [is](r3-runtime-proxy.md#u-dcae92a399e9), [task.js-queues](r4-task-scheduling.md#u-2af0814cc5ec), [effects.js-trivial-effect-factories](r5-effects-module.md#u-191f01511fb1)

**Uncertainties.**

- The hydration fixup microtask has no guard against running after the input's effect was destroyed

<a id="u-01d2720075cb"></a>
### `bind_value`

`export function bind_value(input, get, set = get)` · [packages/svelte/src/internal/client/dom/elements/bindings/input.js:L19-L113][f1]

Two-way binds an input's value.

The input handler (also invoked on form reset via listen_to_event_and_reset_event) reads defaultValue on reset or input.value, coerces number/range inputs with to_number, calls set, records current_batch in a local WeakSet, then after await tick() re-reads get(): if the accessor validation changed the value, it rewrites input.value (nullish to '') and restores the selection, clamping the end offset to the new length. At setup, when hydrating with defaultValue !== input.value, or when untrack(get) is nullish while the DOM holds a value, the DOM value is pushed. The render_effect writes get() into input.value but skips: when the input is focused and previous_batch ?? current_batch was recorded (deferred async updates never clobber a focused input); for number/range when to_number(input.value) already equals value (0 vs 00); for date inputs when both state and DOM value are empty (preserves a partially typed date); or when value === input.value (lets minlength work). In DEV, a checkbox triggers e.bind_invalid_checkbox_value on both the input event and in the effect.

**Notes.**

- failure: In DEV a bound checkbox throws the bind_invalid_checkbox_value error; this guard is commented as not yet applied in production.

calls: [listen_to_event_and_reset_event](r3-runtime-dom-elements.md#u-adb7ad8d3643), [packages/svelte/src/internal/client/runtime.js:tick](r5-signal-core.md#u-fe83d8ee971b), [untrack](r5-signal-core.md#u-aa0e067da463), [effects.js-trivial-effect-factories](r5-effects-module.md#u-191f01511fb1)

**Uncertainties.**

- The exact semantics of previous_batch vs current_batch at render-effect time depend on batch internals outside this file

<a id="u-1bfc194f94a2"></a>
### `get_binding_group_value`

`function get_binding_group_value(group, __value, checked)` · [packages/svelte/src/internal/client/dom/elements/bindings/input.js:L249-L265][f1]

Collects the __value of every checked input in a group into a Set-deduplicated array.

When the triggering input was just unchecked (checked false), its own value is explicitly deleted so the removal is reflected even if the DOM still shows it checked.

<a id="u-d9154063e6ad"></a>
### `is_numberlike_input`

`function is_numberlike_input(input)` · [packages/svelte/src/internal/client/dom/elements/bindings/input.js:L270-L273][f1]

Returns true when the input's type is 'number' or 'range'; used by bind_value to decide string-to-number coercion.

<a id="u-efa4928bf146"></a>
### `to_number`

`function to_number(value)` · [packages/svelte/src/internal/client/dom/elements/bindings/input.js:L278-L280][f1]

Maps the empty string to null, otherwise applies unary + coercion; this is how empty number inputs become null in bindings.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/elements/bindings/input.js
