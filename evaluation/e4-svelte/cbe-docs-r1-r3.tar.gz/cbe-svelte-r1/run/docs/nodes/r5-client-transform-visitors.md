# Client Transform Visitors

**Capability.** Per-node rewriters: assignments and mutations into $.set/$.mutate, state declarations, class fields, snippets, events, actions, legacy $: statements, and special elements.

Consult per syntax feature to see the emitted runtime call shapes. build_assignment is the shared assignment engine; visit_special_element rebinds window/document/body targets.

**Depends on.**

- [Shared AST Utilities](r5-compiler-ast-utils.md) · graph-confirmed · 11 edge(s)
- [Compiler State and Errors](r5-compiler-state-errors.md) · graph-confirmed · 5 edge(s)
- [Compiler Semantic Model](r4-compiler-model.md) · graph-only · 15 edge(s)
- [Client Transform](r4-client-transform.md) · graph-only · 12 edge(s)

**Depended on by.**

- [Template Emission](r5-client-template-transform.md) · model-inferred · 0 edge(s)

Parent: [Client Transform](r5-client-transform.md)

## Units (16)

<a id="u-b46464f68b1c"></a>
### `assignmentexpression-js`

`export function AssignmentExpression(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/AssignmentExpression.js:L21-L27][f1]

AssignmentExpression.js transforms compiled assignment expressions for the client output.

The exported AssignmentExpression visitor delegates to visit_assignment_expression with build_assignment as the per-node builder, falls back to context.next() when no rewrite applies, then wraps the result in validate_mutation. is_non_coercive_operator classifies operators (=, ||=, &&=, ??=) that do not read the old value, and the callees map picks the runtime helper per operator.

calls: [visit_assignment_expression](r2-transform-shared-assignments.md#u-b43a982ab161), [validate_mutation](r1-client-shared-transform-utils.md#u-a58215b09609)

**Uncertainties.**

- Exact validation performed by validate_mutation is outside this file's source.

<a id="u-446b598656ff"></a>
### `build_assignment`

`function build_assignment(operator, left, right, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/AssignmentExpression.js:L54-L224][f1]

Rewrites a single assignment into runtime calls, returning null when no rewrite applies.

In runes mode with a MemberExpression target: if the target matches a class state-field declaration whose node is this exact assignment and the right side carries a rune, it visits the value with in_constructor set (false for $derived/$derived.by), wraps it in $.tag under dev with a class-qualified label, and emits an assignment to this.<field.key>; if the property is a private identifier it visits build_assignment_value(operator, left, right) and emits $.set(left, value, needsProxy) where needsProxy is true only for $state fields, non-coercive operators, and should_proxy(value). Otherwise it unwraps the member chain to its base object; if the base is not an Identifier or has no binding, it returns null. For reassignment (base is the whole left side) with a transform.assign, it visits build_assignment_value and calls transform.assign, passing should-proxy true only when not inside a RegularElement BindDirective, the binding kind is none of prop/bindable_prop/raw_state/derived/store_sub, runes mode is on, should_proxy(right) holds, and the operator is non-coercive. If transform.mutate exists it calls transform.mutate with the visited assignment. Otherwise, in dev with a non-coercive operator and not directly an ExpressionStatement, it plans a $.assign* call for member targets so proxification can be warned about; this is suppressed for event-handler arrows on elements whose expression matches an event attribute, and for BindDirective/Component/SvelteComponent positions including the bind:{getter, setter} sequence pattern. When those checks leave should_transform true for a MemberExpression left, it emits a call to the operator's callee with the object, computed property or literal name, right side, and a location literal; any other shape returns null.

**Notes.**

- side_effect: The dev-mode $.tag wrapper and the location literal embed source positions from locate_node(left) into the generated output.

calls: [get_rune](r4-compiler-model.md#u-5204b6ce4f7a), [get_name](r4-compiler-model.md#u-99af92983a86), [build_assignment_value](r5-compiler-ast-utils.md#u-634ffef5ceee), [should_proxy][f3]; uses: [get_attribute_expression][f2], [is_event_attribute][f2]

**Uncertainties.**

- The signatures and behavior of transform.assign/transform.mutate are defined elsewhere in context.state.transform and are not visible here.
- should_proxy's exact criteria live in client/utils.js and are only referenced.

<a id="u-bd7b8d09104e"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/ClassBody.js:ClassBody`

`export function ClassBody(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/ClassBody.js:L13-L111][f4]

Rewrites class bodies that contain state fields, producing getters/setters backed by $.get/$.set.

It looks up state_fields for this ClassBody in the analysis; if absent (legacy mode) it just calls context.next(). Otherwise it copies state_fields into the child state and, for each non-private field whose node is an AssignmentExpression (declared via constructor assignment), inserts a backing property definition plus a getter `return $.get(this.#key)` and a setter `$.set(this.#key, value, proxyFlag)` where proxyFlag is true for $state fields. It then walks the original body: non-PropertyDefinition members are visited and kept as-is; PropertyDefinitions without a matching state field are visited unchanged; private (#-prefixed) fields keep their key but have their initializer visited (tagged with $.tag in dev when the definition is the field's own declaration); public fields declared at class level get their visited initializer (dev-tagged) emitted as the backing property plus getter/setter methods, dropping the original property definition. Returns the node with the new body.

**Notes.**

- field: `should_proxy` is currently hardcoded to `field.type === '$state' && true` with a TODO, so it is always true for $state fields.

calls: [get_parent](r5-compiler-ast-utils.md#u-427249cf438e), [get_name](r4-compiler-model.md#u-99af92983a86)

**Uncertainties.**

- Public fields present in state_fields but whose definitions do not match field.node are silently dropped from the body; whether that case is reachable is not derivable here.
- The parent lookup at index -1 is assumed to be the ClassDeclaration/ClassExpression; used only for dev tag names.

<a id="u-66fd01a83c22"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/ConstTag.js:ConstTag`

`export function ConstTag(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/ConstTag.js:L15-L91][f5]

Serializes {@const} declarations into derived constants pushed to state.consts.

For an Identifier binding it builds the init with in_derived set, wraps it in create_derived (async-flagged by metadata.expression.has_await), tags it with $.tag in dev, pushes a const declaration, and registers a get_value read transform. For destructured bindings it generates a 'computed_const' temp, clones the transform map deleting each extracted identifier (so nested identifiers are treated as plain variables in the child state), builds the init with in_derived, and wraps a block that destructures the init and returns an object of the identifiers into a create_derived; in dev it is tagged '[@const]'. In both cases dev also pushes an eager $.get statement so 'Cannot access x before initialization' errors surface at the right place. Destructured identifiers get read transforms that read `$.get(tmp).<name>`.

**Notes.**

- side_effect: Each {@const} mutates context.state.transform for its identifiers, affecting how later reads in the same scope are compiled.
- failure: Dev-only eager $.get evaluation exists solely to trigger TDZ errors eagerly.

calls: [create_derived](r4-client-transform.md#u-d8c62e2be238), [build_expression](r1-client-shared-transform-utils.md#u-cd5eb51d389f), [extract_identifiers](r5-compiler-ast-utils.md#u-90eb95affc00)

<a id="u-2b757b558903"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/ImportDeclaration.js:ImportDeclaration`

`export function ImportDeclaration(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/ImportDeclaration.js:L9-L16][f6]

Moves import declarations to hoisted output when the current state supports it: if 'hoisted' exists in state, the node is pushed there and b.empty is returned; otherwise context.next() proceeds normally.

<a id="u-5cb26cf0f344"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/LabeledStatement.js:LabeledStatement`

`export function LabeledStatement(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/LabeledStatement.js:L11-L64][f7]

Compiles legacy `$:` reactive statements into $.legacy_pre_effect calls, leaving all other labeled statements untouched.

When the analysis is in runes mode, the path is deeper than 1, or the label is not `$`, it delegates to context.next(). Otherwise it looks up the ReactiveStatement for this node; if none is registered (not the instance context) it returns undefined without output. The body is visited and normalized to a block. For each tracked dependency binding it skips 'normal' bindings that are not imports are actually kept — precisely: bindings with kind 'normal' and a non-import declaration_kind are skipped — while imports and non-normal kinds emit a getter; `$$props`, `$$restProps`, and 'bindable_prop' bindings are additionally wrapped in $.deep_read_state because fine-grained $state inside props requires deep reads to trigger updates. The resulting sequence becomes the first (thunked) argument of $.legacy_pre_effect, with the block body as the second; the statement is stored in state.legacy_reactive_statements for later topological ordering, and the visitor returns b.empty so the original statement is not emitted inline.

**Notes.**

- side_effect: Registers the serialized statement in context.state.legacy_reactive_statements keyed by the original node; returns b.empty to suppress inline emission.

calls: [build_getter](r4-client-transform.md#u-66a19e20e1f1)

<a id="u-cf6eda1c83ef"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/MemberExpression.js:MemberExpression`

`export function MemberExpression(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/MemberExpression.js:L9-L23][f8]

Rewrites private state-field access inside constructors.

For this.#foo-style accesses (PrivateIdentifier property) whose name matches a state field: inside a constructor with a $state or $state.raw field it emits the member directly with a '.v' suffix; otherwise it emits $.get(member). Non-private or unknown-field expressions fall through to context.next().

**Notes.**

- condition: Only $state/$state.raw fields get the direct .v access; other field kinds always use $.get.

**Uncertainties.**

- The rewrite applies regardless of the object being literally `this`; the comment says `this.#foo` but the code checks only the property type.

<a id="u-3abb91ec17dc"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/OnDirective.js:OnDirective`

`export function OnDirective(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/OnDirective.js:L19-L38][f9]

Serializes an `on:` directive into a runtime event registration call.

When the directive has no expression it sets `context.state.analysis.needs_props = true` (handler supplied as a prop). The handler is built via build_event_handler, then wrapped by `$.<modifier>(handler)` for each modifier present from the fixed list (stopPropagation, stopImmediatePropagation, preventDefault, self, trusted, once), applied in list order so wrappers nest. `capture` is true only with the capture modifier; `passive` is true with `passive`, explicitly false with `nonpassive`, otherwise undefined. Returns build_event(node.name, context.state.node, handler, capture, passive).

calls: [build_event](r2-transform-client.md#u-0bee50cc5235), [build_event_handler](r2-transform-client.md#u-227977f005ec)

**Uncertainties.**

- Behavior of build_event_handler/build_event for expressionless directives is outside this file.

<a id="u-ab4813441bd1"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/SnippetBlock.js:SnippetBlock`

`export function SnippetBlock(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/SnippetBlock.js:L13-L100][f10]

Serializes {#snippet} blocks into a const-bound snippet function, preparing parameter transforms and hoisting decisions.

It builds an argument list starting with $$anchor; each Identifier parameter becomes an assignment pattern defaulting to $.noop with a b.call read transform. Non-identifier (destructuring) parameters get a `$$argN` alias, and extract_paths splits it: inserted array-pattern ids are renamed to generated `$$array` names with derived declarations ($.derived over the visited value) and get_value reads; each path gets a let declaration of its visited expression — wrapped in $.derived_safe_equal when it has a default value so the default is evaluated only once — with transform read set to get_value or b.call accordingly; in dev each such name is eagerly read to surface TDZ errors. The body block prepends a dev-only $.validate_snippet_args(...arguments) statement plus the declarations. In dev the snippet is a FunctionExpression wrapped in $.wrap_snippet(analysis.name, fn) so `arguments` is available; otherwise it is an arrow. Top-level snippets (path is just a Fragment) go to module_level_snippets when metadata.can_hoist, else instance_level_snippets; nested snippets are pushed to state.init as the const declaration.

**Notes.**

- field: has_await comes from node.body.metadata.has_await || false and is passed to the created function/arrow.
- failure: Dev-only eager reads of path names exist to trigger 'Cannot access x before initialization' errors at the right time.

calls: [extract_paths](r5-compiler-ast-utils.md#u-34f2fcb20c62); uses: [Scope](r4-compiler-model.md#u-01a82e58170d)

<a id="u-0676455245be"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/SvelteComponent.js:SvelteComponent`

`export function SvelteComponent(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/SvelteComponent.js:L9-L12][f11]

Compiles <svelte:component> via build_component under the reserved name '$$component' and pushes the result into init output.

calls: [component-js-build-component](r1-client-shared-transform-utils.md#u-af8f6b0917f6)

<a id="u-41ee72c88b7f"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/SvelteHead.js:SvelteHead`

`export function SvelteHead(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/SvelteHead.js:L10-L20][f12]

Compiles <svelte:head> by pushing a $.head call into init, passing an arrow function taking $$anchor whose body is the visited fragment.

Attributes are noted as unhandled by a TODO comment.

<a id="u-d6475f075d4a"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/TitleElement.js:TitleElement`

`export function TitleElement(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/TitleElement.js:L10-L23][f13]

Compiles <title> content into a document.title assignment.

build_template_chunk produces the value expression and whether it depends on reactive state: when stateful the assignment is pushed to the update phase, otherwise it runs once in init.

calls: [build_template_chunk](r1-client-shared-transform-utils.md#u-d8d503fc4b7b)

<a id="u-7d1fd01c56d0"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/UseDirective.js:UseDirective`

`export function UseDirective(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/UseDirective.js:L11-L37][f14]

Serializes use: action directives into a $.action call pushed to init so actions run after attribute updates, in order with bindings and events.

It builds an arrow whose parameters are $$node plus $$action_arg when node.expression exists, calling the visited directive name (via parse_directive_name) through b.maybe_call with those params; the action's expression, when present, is appended as an evaluated thunk. It pushes b.stmt(b.call('$.action', node, arrow[, thunk])) to state.init and then continues traversal with context.next().

calls: [parse_directive_name](r1-client-shared-transform-utils.md#u-47fb5120ded1)

<a id="u-39f817804cf0"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/VariableDeclaration.js:VariableDeclaration (2)`

`export function VariableDeclaration(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/VariableDeclaration.js:L155-L397][f15]

Transforms a variable declaration into component code, splitting behavior on runes mode.

In runes mode, each declarator is dispatched by its init's rune: non-state runes (`$effect.tracking`, `$effect.root`, `$inspect`, `$inspect.trace`, `$state.snapshot`, `$host`, or no rune) fall through to a normal visit, except hoisted functions which are moved to context.state.hoisted as consts; `$props.id` is skipped; `$props` is deserialized by destructuring pattern — an identifier becomes `$.rest_props($$props, [seen names])` (adding `$$host` for custom elements and the rest name in dev), an ObjectPattern visits each property: bindable-prop initials are proxied on demand (`$.proxy`, plus `$.tag_proxy` in dev), prop sources become declarators via get_prop_source, and RestElements become `$.rest_props` with the accumulated seen list; `$state`/`$state.raw` wrap values in `$.proxy` (when should_proxy, only for `$state`, tagged in dev when not a state source), `$.state` (for state sources, `$.tag` in dev), with destructured patterns using a `tmp` plus `$$array` derived inserts and per-path declarators that reapply the state wrapper for state bindings; `$derived`/`$derived.by` wrap the value in `$.derived` (thunked for `$derived`, `$.tag`ged in dev), or, when registered as an async derived, `$.async_derived` awaited through `$.save` (with a waterfall location literal in dev when not ignored); destructured deriveds introduce a `$$d` identifier unless the init is a bare identifier, with inserts and paths becoming `$.derived` calls. Legacy mode distinguishes bindings: neither state nor bindable props visit normally (hoisted functions again lifted first); bindable props become get_prop_source declarators (with the leaf-paths extraction for pattern ids, where leaves are the props); state bindings go through create_state_declarators. Returns `b.empty` if no declarations remain, otherwise a copy of the node with new declarations. The in-batch helper create_state_declarator (the $state identifier/pattern path) is covered by this unit.

calls: [get_rune](r4-compiler-model.md#u-5204b6ce4f7a), [is_hoisted_function](r3-compiler-transform-utils.md#u-b9dd511b4830), [get_prop_source](r4-client-transform.md#u-d03f333899de), [is_prop_source](r4-client-transform.md#u-38b8a75ee741), [should_proxy](r4-client-transform.md#u-d089d4da67c8), [Scope](r4-compiler-model.md#u-01a82e58170d), [is_ignored](r5-compiler-state-errors.md#u-468324b42cee), [locate_node](r5-compiler-state-errors.md#u-b35212eb6968), [extract_paths](r5-compiler-ast-utils.md#u-34f2fcb20c62)

**Uncertainties.**

- The `// TODO` after the $props branch and the `void 0` fallback comment suggest unresolved design questions, but their runtime impact is not determinable from this file.
- is_state_source/get_prop_source internals (whether a binding counts as state source) live in client/utils.js and are not shown.

<a id="u-ce9e3badaf1d"></a>
### `create_state_declarators`

`function create_state_declarators(declarator, context, value)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/VariableDeclaration.js:L405-L439][f15]

Creates the output declarators for a legacy-mode state declaration.

For an identifier declarator it wraps the value in `$.mutable_source`, passing `true` when analysis.immutable. For destructuring patterns it introduces a `tmp` declarator, `$$array`-renamed insert declarators as `$.derived` calls (registering get_value as their read transform), and per-path declarators that wrap state-kind bindings in `$.mutable_source` (immutable-flagged) and leave other paths unwrapped.

calls: [Scope](r4-compiler-model.md#u-01a82e58170d), [extract_paths](r5-compiler-ast-utils.md#u-34f2fcb20c62)

<a id="u-5f6160c62286"></a>
### `visit_special_element`

`export function visit_special_element(node, id, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/special_element.js:L12-L22][f16]

Visits svelte:body, svelte:document, and svelte:window by rebinding the current target node to a fixed identifier (the given id, e.g. the document/window reference).

OnDirectives are visited with that state and their resulting statements pushed to init; all other attributes are visited with the same state without extra handling.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/AssignmentExpression.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/utils/ast.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/utils.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/ClassBody.js
[f5]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/ConstTag.js
[f6]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/ImportDeclaration.js
[f7]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/LabeledStatement.js
[f8]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/MemberExpression.js
[f9]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/OnDirective.js
[f10]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/SnippetBlock.js
[f11]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/SvelteComponent.js
[f12]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/SvelteHead.js
[f13]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/TitleElement.js
[f14]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/UseDirective.js
[f15]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/VariableDeclaration.js
[f16]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/special_element.js
