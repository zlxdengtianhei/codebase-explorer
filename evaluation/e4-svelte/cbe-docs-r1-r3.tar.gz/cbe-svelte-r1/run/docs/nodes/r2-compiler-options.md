# Compiler option validation

**Capability.** Owns validating, defaulting, deprecating and rejecting compiler options: declarative option tables composed from reusable validator builders and once-only warning helpers.

Read this to learn which compile options exist and how invalid, deprecated or removed ones are handled. Tables are data; validators and warn-once helpers are the reusable mechanics they compose.

**Depends on.**

- [Compile diagnostics](r2-compiler-diagnostics.md) · model-inferred · 0 edge(s)

**Depended on by.**

- [Preprocessing and sourcemap composition](r2-preprocess-sourcemaps.md) · model-inferred · 0 edge(s)

Parent: [Component compiler pipeline](r2-compiler.md)

## Units (8)

<a id="u-057ab7f46350"></a>
### `validate-options-js-option-tables`

`group` · [packages/svelte/src/compiler/validate-options.js:L1-L171][f1]

Module-level tables defining the valid compiler options and how each is validated/defaulted.

common_options holds options shared by components and modules: filename (string, default '(unknown)'), rootDir (string, defaulting to process.cwd?.(), Deno.cwd(), or undefined depending on runtime), dev (boolean false), generate (via validator mapping legacy 'dom'/'ssr' to 'client'/'server' with a once-only rename warning, accepting 'client', 'server', or false, and throwing otherwise), warningFilter (fun, default () => true), and experimental.async (boolean false). component_options adds component-only options: accessors and immutable are deprecated booleans; css accepts only 'external'/'injected' and throws for booleans and 'none'; cssHash defaults to a function producing 'svelte-' + hash(css); compatibility.componentApi is a list [4,5] defaulting 5; namespace and fragments are lists; plus booleans/strings/functions such as customElement (false), discloseVersion (true), modernAst (false), runes (undefined), hmr (false), sourcemap (pass-through validator), and numerous options that are removed (legacy, format, tag, sveltePath, errorMode, varsReport) or warn-removed (loopGuardTimeout, enableSourcemap, hydratable). validate_module_options combines common_options with no-op stubs for every component option key so module compilation ignores them, and validate_component_options combines common_options with component_options; both are built with object().

**Notes.**

- contract: Unknown keys are rejected because object() is called without allow_unknown.

calls: [packages/svelte/src/compiler/validate-options.js:object](r2-compiler-options.md#u-0dfc41eda888), [removed](r2-compiler-options.md#u-57b26ac837bc)

**Uncertainties.**

- Whether Object.keys(component_options) ordering is stable across engines is assumed for the no-op stub map in validate_module_options.

<a id="u-aaad6bb1d2a8"></a>
### `validate-options-js-type-validators`

`function string(fallback, allow_empty = true)` · [packages/svelte/src/compiler/validate-options.js:L263-L275][f1]

Concrete leaf validators shared by option tables.

string builds a validator requiring a string input when specified (throwing an error naming the keypath otherwise) and, when allow_empty is false, rejecting '' as well; it accepts a fallback. boolean requires a true/false input when specified, otherwise the fallback. list takes an allowed array with fallback defaulting to its first element and rejects any input outside it, formatting the message as 'either "a" or "b"' for two options or a comma list ending in 'or "x"' for more. fun requires a function input when specified, otherwise a fallback function. throw_error raises an options_invalid_value error with the given message. All throw via the errors module and give no fallback value.

calls: [validator](r2-compiler-options.md#u-3dabd9340065)

<a id="u-994889c21a32"></a>
### `deprecate`

`function deprecate(fn, validator)` · [packages/svelte/src/compiler/validate-options.js:L207-L212][f1]

Wraps a validator with a deprecation warning: when the input is defined it emits the given warning once (warn_once), then always delegates to the wrapped validator with the input and keypath, returning its result.

calls: [warn_once](r2-compiler-options.md#u-1215fafafc03)

<a id="u-0dfc41eda888"></a>
### `packages/svelte/src/compiler/validate-options.js:object`

`function object(children, allow_unknown = false)` · [packages/svelte/src/compiler/validate-options.js:L219-L245][f1]

Builds a validator for object-shaped option groups.

It rejects non-object inputs (including arrays) by raising an options error naming the keypath. It then iterates the input's own keys: unknown keys are copied through when allow_unknown is set, otherwise an options_unrecognised error names the full keypath (or bare key at the root). Finally it runs each child validator on the corresponding input value (undefined when input is falsy) with a dotted keypath, collecting results into a fresh output object that it returns.

uses: [validator](r2-compiler-options.md#u-3dabd9340065), [validate-options-js-type-validators](r2-compiler-options.md#u-aaad6bb1d2a8)

**Uncertainties.**

- for...in also walks inherited enumerable keys; prototype pollution of Object could add phantom input keys.

<a id="u-57b26ac837bc"></a>
### `removed`

`function removed(msg)` · [packages/svelte/src/compiler/validate-options.js:L172-L179][f1]

Builds a validator for an option that no longer exists: if the input is not undefined it raises an options_removed error with the given message; it always returns undefined, which becomes the validated value.

uses: [validate-options-js-type-validators](r2-compiler-options.md#u-aaad6bb1d2a8)

<a id="u-3dabd9340065"></a>
### `validator`

`function validator(fallback, fn)` · [packages/svelte/src/compiler/validate-options.js:L252-L256][f1]

Builds a validator from a fallback and a transform: undefined input yields the fallback, any other input is passed through fn with the keypath and the result returned.

<a id="u-1215fafafc03"></a>
### `warn_once`

`function warn_once(fn)` · [packages/svelte/src/compiler/validate-options.js:L184-L189][f1]

Emits a warning function at most once per module run: a module-level warned Set keyed by the function itself suppresses repeat emissions.

**Notes.**

- side_effect: Adds the warning function to the shared warned set.

<a id="u-d8df8fda6d4f"></a>
### `warn_removed`

`function warn_removed(fn)` · [packages/svelte/src/compiler/validate-options.js:L195-L200][f1]

Builds a validator for an option that has been removed but should only warn: when the input is defined it emits the given warning once (via warn_once) and returns undefined regardless.

calls: [warn_once](r2-compiler-options.md#u-1215fafafc03)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/validate-options.js
