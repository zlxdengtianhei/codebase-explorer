# Server Runtime

**Capability.** Server-side rendering support: the render payload buffers (body output, head payload, css set, uid generator) with legacy copy/assign semantics, server snippet creation, the server component frame/RenderOutput types, and server-side lifecycle APIs like onDestroy.

Compiled SSR output writes into Payload/HeadPayload and registers teardown via onDestroy; createRawSnippet wraps render functions into server snippet callables. types.d.ts documents the component frame and render result shape.

**Depends on.**

- [Shared Runtime Utilities](r4-shared-runtime.md) · model-inferred · 0 edge(s)

Parent: [Svelte Monorepo](r4-svelte-monorepo.md)

## Units (7)

<a id="u-3d10206fb345"></a>
### `packages/svelte/src/index-server.js:onDestroy`

`export function onDestroy(fn)` · [packages/svelte/src/index-server.js:L7-L10][f1]

Server-side onDestroy: registers `fn` on the current server component's destroy list.

Reads `current_component` (cast to Component) and lazily creates its `.d` array, pushing the callback. Per the module docs, this is the only legacy lifecycle function that actually runs during SSR.

<a id="u-9b7114ceb220"></a>
### `packages/svelte/src/internal/server/blocks/snippet.js:createRawSnippet`

`export function createRawSnippet(fn)` · [packages/svelte/src/internal/server/blocks/snippet.js:L14-L24][f2]

Wraps a render/setup function into a server snippet callable.

The returned function maps its arguments to zero-arg getters (freezing values for later reads), invokes `fn` with them, calls the result's `render()`, trims the string, and pushes it into `payload.out`. The optional `setup`/cleanup return value is never used in this server path; `fn` is called unguarded, so exceptions from it propagate to the caller.

**Uncertainties.**

- The snippet type's `setup` lifecycle appears unused here; whether it runs elsewhere is not visible.

<a id="u-0180f968bb91"></a>
### `HeadPayload`

`class HeadPayload` · [packages/svelte/src/internal/server/payload.js:L1-L9][f3]

Accumulates `<head>`-bound render output: a `Set` of css `{hash, code}` entries, an `out` string array, a `uid` generator defaulting to a no-op returning '', and a `title` string.

The constructor accepts all four with defaults (empty set, empty array, '', no-op) and assigns them directly, so callers can share collections or inject a real id generator.

<a id="u-88f15d8dfda3"></a>
### `Payload`

`class Payload` · [packages/svelte/src/internal/server/payload.js:L22-L32][f3]

The server render buffer: `out` (body HTML fragments), `css` set, `select_value` for option matching, a nested `HeadPayload`, and a `uid` id generator.

The constructor takes an id prefix, sets `this.uid = props_id_generator(prefix)` (ids like `<prefix>s1`, `s2`, ... incrementing per call) and shares that generator with `head.uid` so ids stay unique across body and head. Field initializers run first, then the constructor overwrites `uid`.

<a id="u-bbeddcad611f"></a>
### `assign_payload`

`export function assign_payload(p1, p2)` · [packages/svelte/src/internal/server/payload.js:L65-L70][f3]

Legacy binding merge: replaces `p1.out` with a copy of `p2.out`, and assigns `p1.css`, `p1.head`, and `p1.uid` by reference, so afterwards p1 and p2 share the same head, css set, and id generator state.

Only `out` is defensively copied.

**Notes.**

- side_effect: p1's previous head/css/uid references are dropped; p1 aliases p2's.

<a id="u-ab7dea894e0f"></a>
### `copy_payload`

`export function copy_payload({ out, css, head, uid })` · [packages/svelte/src/internal/server/payload.js:L43-L57][f3]

Legacy-mode payload clone: creates a new Payload and copies `out` as a fresh array, `css` as a new Set, and `uid` by reference; builds a fresh HeadPayload whose `out` and `css` are copies but whose `title` and `uid` are shared.

Subsequent writes to the copy's arrays/sets do not affect the original, but writes to `title` on the copy do not propagate either (separate objects), while the uid generator state is shared.

**Uncertainties.**

- The comment says this handles legacy bindings; the exact copy semantics required by callers are not shown.

<a id="u-1831d6d0eeba"></a>
### `packages/svelte/src/internal/server/types.d.ts:Component`

`export interface Component` · [packages/svelte/src/internal/server/types.d.ts:L1-L12][f4]

Type-only declaration file: `Component` describes the server component frame (`p` parent link, `c` context Map, `d` ondestroy callbacks, optional dev-only `function`) and `RenderOutput` describes the result of server rendering (`head`, deprecated `html`, `body`).

Contains no runtime code.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/index-server.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/server/blocks/snippet.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/server/payload.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/server/types.d.ts
