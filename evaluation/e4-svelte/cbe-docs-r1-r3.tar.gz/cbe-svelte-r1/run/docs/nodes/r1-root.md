# Svelte Monorepo

**Capability.** Umbrella for the Svelte compiler pipeline, client/server runtimes, shared utilities, public type surface, and the tooling that builds, lints and benchmarks them.

Readers start here to orient between the compiler (parse → analyze → transform), the runtime implementations behind compiled output, and the supporting tooling. Children split by deliverable, not by directory. Cross-cutting shared utilities are kept separate from their consumers.

**Children.**

- [Reactivity Benchmarking](r1-benchmarking.md) `r1-benchmarking` · 3 unit(s)
- [Build & Repo Tooling](r1-build-tooling.md) `r1-build-tooling` · 1 unit(s)
- [Compiler Pipeline](r1-compiler.md) `r1-compiler` · 0 unit(s)
- [Client Runtime](r1-runtime-client.md) `r1-runtime-client` · 0 unit(s)
- [Server Runtime](r1-runtime-server.md) `r1-runtime-server` · 0 unit(s)
- [Shared Utilities](r1-shared-utilities.md) `r1-shared-utilities` · 0 unit(s)
- [Public Type Declarations](r1-public-types.md) `r1-public-types` · 18 unit(s)
- [svelte/events Public API](r1-events-api.md) `r1-events-api` · 2 unit(s)

Parent: [Svelte Monorepo](svelte-monorepo.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
