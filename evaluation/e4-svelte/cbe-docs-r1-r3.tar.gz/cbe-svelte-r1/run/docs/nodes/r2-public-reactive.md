# Public reactive APIs

**Capability.** Owns the user-facing reactive building blocks: classic stores (writable/derived/readable/get), motion (Tween class and legacy tweened store), reactive value wrappers (ReactiveValue, MediaQuery, SvelteURL), their test suites, the version constants, and the legacy server-side component compatibility wrapper.

Enter here for the exported APIs application code consumes directly. Each child is a distinct API surface; the tweened factory is built on writable, and motion's index also exposes prefersReducedMotion via MediaQuery. Reactive collections (SvelteMap/SvelteURLSearchParams) appear here through their test suites, since their implementation units are not in this set.

**Children.**

- [Store contract implementation](r2-stores.md) `r2-stores` · 6 unit(s)
- [Motion: Tween and legacy tweened](r2-motion.md) `r2-motion` · 7 unit(s)
- [Reactive value wrappers](r2-reactive-values.md) `r2-reactive-values` · 5 unit(s)
- [Reactive collection test suites](r2-reactivity-tests.md) `r2-reactivity-tests` · 2 unit(s)

Parent: [Svelte compiler and runtime](r2-svelte.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
