# SSR Playground Sandbox

**Capability.** Runs App.svelte locally under a dev SSR server (Vite middleware) and a prod SSR server (pre-rendered HTML plus static assets), with shared helpers in ssr-common.

Use it to try server rendering end to end. Whether the servers call svelte/server's render is inferred from their descriptions, not resolved in the given graph.

**Depends on.**

- [Server Rendering](r5-server-render.md) · model-inferred · 0 edge(s)

Parent: [Svelte](r5-svelte.md)

## Units (3)

<a id="u-c9a44632b392"></a>
### `ssr-common.js module code (L1–L17)`

`module_region` · [playgrounds/sandbox/ssr-common.js:L1-L17][f1]

Installs shared helpers used by both SSR servers.

It polyfills Promise.withResolvers only if absent, returning { promise, resolve, reject }, and defines a global delayed(value, ms = 1000) that resolves to value after ms via setTimeout. Both assignments happen at import time as side effects on globalThis.

**Notes.**

- side_effect: Assigns globalThis.delayed; the sandbox App presumably uses it to exercise async SSR.

**Uncertainties.**

- Nothing here uses delayed itself; who consumes globalThis.delayed is not visible in this file.

<a id="u-00b4d70b764d"></a>
### `ssr-dev.js module code (L1–L39)`

`module_region` · [playgrounds/sandbox/ssr-dev.js:L1-L39][f2]

Development SSR server: Vite middleware in front of Polka rendering App.svelte on each request.

It sets NODE_ENV to 'development', creates a Vite server in middleware mode with appType 'custom', and mounts vite.middlewares before a handler that reads index.html, applies vite.transformIndexHtml, loads /src/App.svelte via vite.ssrLoadModule, renders it with svelte/server, and splices head/body into the transformed template plus a phone-number replacement for Safari hydration testing. Responds 200 text/html for every request; errors are not caught, so a failed render/load yields no response. Port comes from PORT env or '5173'; importing ssr-common.js registers the delayed helper.

imports: [ssr-common.js module code (L1–L17)](r5-playground-sandbox.md#u-c9a44632b392)

**Uncertainties.**

- Replace uses first-match .replace for head/body, so repeated markers are only partially substituted.

<a id="u-170a1c7ad4ed"></a>
### `ssr-prod.js module code (L1–L42)`

`module_region` · [playgrounds/sandbox/ssr-prod.js:L1-L42][f3]

Production SSR server: renders App.svelte once at startup into a static HTML string served for '/', and streams static assets from dist/client otherwise.

Static import of App plus svelte/server render happens at module load; the dist/client/index.html template gets head/body spliced in. Requests for '/' get 200 text/html with the rendered string. Any other URL resolves under dist/client; if the file exists it is streamed with a content type from the extension map (.js, .css) or 'application/octet-stream'; missing files get 404 'not found'. Listens on port 3000.

imports: [ssr-common.js module code (L1–L17)](r5-playground-sandbox.md#u-c9a44632b392)

**Uncertainties.**

- App is rendered once at startup, not per request; per-request state isolation is not provided by this server.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/playgrounds/sandbox/ssr-common.js
[f2]: ../../../../../../eval/svelte-be645b4/playgrounds/sandbox/ssr-dev.js
[f3]: ../../../../../../eval/svelte-be645b4/playgrounds/sandbox/ssr-prod.js
