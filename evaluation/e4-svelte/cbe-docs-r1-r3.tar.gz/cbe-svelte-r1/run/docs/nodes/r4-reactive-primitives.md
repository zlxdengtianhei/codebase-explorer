# Reactive Primitives & Motion

**Capability.** Public reactive built-ins and supporting utilities: reactive collections (SvelteMap, SvelteSet, SvelteURLSearchParams, SvelteDate), the lazy-subscription bridge createSubscriber, easing functions, a Date type guard for motion, plus inert server stubs (MediaQuery, createSubscriber, fromStore/toStore) for environments without effects. Behavioral tests for the collections live alongside.

Use the collection implementations and their test suites to understand invalidation granularity; create-subscriber connects external sources to the effect system. The *_server stubs mirror client APIs so shared code runs on the server; easing and motion/utils are pure helpers.

**Depends on.**

- [Shared Runtime Utilities](r4-shared-runtime.md) · model-inferred · 0 edge(s)
- [Task Scheduling](r4-task-scheduling.md) · graph-confirmed · 1 edge(s)
- [Signal Sources](r3-runtime-reactivity-sources.md) · graph-only · 19 edge(s)
- [Dev-Mode Diagnostics](r3-runtime-dev-tools.md) · graph-only · 12 edge(s)

**Depended on by.**

- [Public Component Types \(Modern\)](r4-public-component-types.md) · model-inferred · 0 edge(s)

Parent: [Svelte Monorepo](r4-svelte-monorepo.md)

## Units (11)

<a id="u-1e768777e1a1"></a>
### `map.js-sveltemap`

`class SvelteMap extends Map` · [packages/svelte/src/reactivity/map.js:L53-L63][f1]

SvelteMap is a reactive Map subclass: reading size, get, has, forEach, values, entries, or iterating in an effect re-runs that effect when the map changes; values are not made deeply reactive.

It keeps a per-key Map of sources plus #version and #size states, and snapshots update_version at construction. The constructor in DEV normalizes the iterable via new Map(value) so invalid input throws the native exception, and tags the states for tracing; entries are copied with super.set and #size.v is written directly. #source returns state(value) when created inside the same reaction (update_version matches) and source(value) otherwise, so the creating reaction does not depend on it. has/get create a per-key source only when the key holds a defined value; when the value is undefined (or key absent) they instead read #version so the effect re-runs if the key gains a value later, returning false/undefined. A stored-undefined value does get a source at set time, so get tracks it per-key. set always performs super.set: for a new key it creates a source, updates #size, and increments #version; for an existing key whose value changed it increments that key's source, and increments #version only when the source's reactions are not all contained in the version's reactions (copying the reaction set first). delete only touches reactivity if a source existed: it removes the source, updates #size, sets the source to -1, and increments #version. clear is a no-op on an empty map; otherwise it clears the backing map first (so $inspect output looks right), resets #size, sets every source to -1, increments #version, and clears sources. #read_all reads #version, lazily creates missing per-key sources when #size.v differs from sources.size, then reads every source; forEach, values, and entries delegate to it before calling super. keys only reads #version. size reads #size. [Symbol.iterator] returns entries().

uses: [state](r3-runtime-reactivity-sources.md#u-acd426d0030b); calls: [source](r3-runtime-reactivity-sources.md#u-97497b70f31b), [packages/svelte/src/internal/client/reactivity/sources.js:set](r3-runtime-reactivity-sources.md#u-452914169f68), [increment](r3-runtime-reactivity-sources.md#u-8fa6038c59d8), [packages/svelte/src/internal/client/runtime.js:get](r5-signal-core.md#u-98099fbbf12a)

**Uncertainties.**

- Whether increment(version) is required alongside increment(s) depends on runtime reaction bookkeeping (version.reactions, s.reactions) whose maintenance lives outside this file.

<a id="u-c13cb70b6879"></a>
### `set.test.ts-behavior-of-svelteset`

`group` · [packages/svelte/src/reactivity/set.test.ts:L1-L159][f2]

Vitest suite for SvelteSet verifying reactive invalidation against render effects.

The set.values() test runs three render effects reading size, has(3), and Array.from(set), then flushSync's a delete and a clear, asserting the exact log of re-runs including size shrinking before clear. The set.has(...) and 'not invoking reactivity when value is not in the set after changes' tests delete and re-add an element and assert precisely which has() effects re-run, confirming that effects reading an absent key are not re-run when the key is absent before and after a change. set.delete(...) checks return values (true then false) without effects; set.forEach(...) asserts the callback sees the full updated contents after an add. Set.instanceOf asserts SvelteSet is a Set subclass.

<a id="u-56720b5a7c5a"></a>
### `date-test-ts-sveltedate-reactivity-suite`

`const expect_all_changes_to_be_false = () =>` · [packages/svelte/src/reactivity/date.test.ts:L478-L482][f3]

Vitest suite verifying that SvelteDate propagates mutations to effects with per-field granularity.

Each test wraps a SvelteDate(initial_date), registers render_effects inside an effect_root that push getter results into a log, mutates via flushSync, and asserts the log against plain-Date computations. Recurring expectations: setting a value that does not change fires no effect; local-time and UTC getter effects fire separately; setSeconds(60/61) rolls over into minutes and fires minute effects; setMonth(13) rolls over year and fires getSeconds/getMonth/getFullYear. The 'fine grained' test runs every Date getter/formatter in its own render_effect and, via expect_all_changes_to_be_false, asserts exactly the flags corresponding to fields actually changed by setFullYear(y, m), setSeconds(61*60*25+1, 10), and setMonth(+1). Remaining tests cover toLocaleString with options, valueOf after setTime, instanceof Date, and Date methods first read inside deriveds, including a method shared between two deriveds.

uses: [map.js-sveltemap](r4-reactive-primitives.md#u-1e768777e1a1)

**Uncertainties.**

- SvelteDate's implementation is not in the supplied source; the suite's assertions are the only evidence for its per-field source granularity.

<a id="u-16bd40497c5c"></a>
### `url-search-params.js-svelteurlsearchparams`

`class SvelteURLSearchParams extends URLSearchParams` · [packages/svelte/src/reactivity/url-search-params.js:L35-L41][f4]

A reactive URLSearchParams subclass.

Each instance holds a #version state source used to invalidate readers, a #url obtained from get_current_url() (may be absent, e.g. outside a SvelteURL context), and an #updating re-entrancy flag. Read methods (get, getAll, has, keys, values, entries, toString, size, and Symbol.iterator via entries) call get(this.#version) before delegating to the URLSearchParams base, registering dependency on any param mutation. Write methods delegate to the base class, then conditionally propagate: append and sort always call #update_url() and increment(version); delete only does so when super.has(name, value) showed something existed beforehand; set compares the joined getAll(name) before and after, since has(name, value) would wrongly report no change when an older duplicate value remains. #update_url syncs ?<search> into #url.search unless #url is falsy or #updating is true, guarding with the flag to prevent recursion. The internal [REPLACE] method bulk-swaps all params from another URLSearchParams: it returns early if #updating, sets the flag, deletes all existing keys and appends the incoming pairs directly on the base class (no #update_url), then increments the version and clears the flag.

calls: [url.js-svelteurl](r2-reactive-values.md#u-699019ac3903), [state](r3-runtime-reactivity-sources.md#u-acd426d0030b), [increment](r3-runtime-reactivity-sources.md#u-8fa6038c59d8), [packages/svelte/src/internal/client/runtime.js:get](r5-signal-core.md#u-98099fbbf12a), [tracing.js-tagging](r3-runtime-dev-tools.md#u-76249388f24e)

**Uncertainties.**

- Whether [REPLACE] intentionally skips #update_url (so the linked URL is not synced during bulk replacement) cannot be confirmed from this file alone.
- get_current_url may return undefined in some contexts; only the falsy check in #update_url is observable here.

<a id="u-44838dbc4415"></a>
### `createSubscriber`

`export function createSubscriber(start)` · [packages/svelte/src/reactivity/create-subscriber.js:L54-L95][f5]

Creates a subscribe function that lazily connects external event sources to Svelte's reactivity.

The returned function first checks effect_tracking(); if no effect is tracking, it does nothing, so reads outside effects never start subscriptions. When tracking, it reads a version source (recording the dependency) and creates a render_effect whose cleanup schedules a microtask countdown: the local subscribers count rises to 1 per active effect, and start() is invoked untracked only on the first subscriber, with an update callback that increments version to re-run dependent effects. start's returned cleanup is stored in stop. The teardown decrements subscribers inside queue_micro_task, deliberately deferring so a subscriber's own re-run is not mistaken for destruction; when the count reaches 0, stop?.() runs, stop is cleared, and version is incremented so dependent deriveds are marked dirty when the subscription is later re-established. In DEV the version source is tagged for tracing.

**Notes.**

- side_effect: start() runs inside untrack, so its own reactive reads do not register dependencies.
- condition: Each render effect instance holds its own cleanup; multiple effects each increment subscribers, and stop only fires when the count returns to zero.

uses: [effects.js-trivial-effect-factories](r5-effects-module.md#u-191f01511fb1); calls: [effects.js-trivial-effect-factories](r5-effects-module.md#u-191f01511fb1), [packages/svelte/src/internal/client/runtime.js:get](r5-signal-core.md#u-98099fbbf12a), [untrack](r5-signal-core.md#u-aa0e067da463), [source](r3-runtime-reactivity-sources.md#u-97497b70f31b), [increment](r3-runtime-reactivity-sources.md#u-8fa6038c59d8), [task.js-queues](r4-task-scheduling.md#u-2af0814cc5ec), [tracing.js-tagging](r3-runtime-dev-tools.md#u-76249388f24e)

**Uncertainties.**

- Behavior if start throws during subscription is not established from this file; no try/catch is visible.

<a id="u-8fae15838695"></a>
### `MediaQuery`

`class MediaQuery` · [packages/svelte/src/reactivity/index-server.js:L7-L13][f6]

Server-side inert stub of the reactive MediaQuery: it has only a current field, set by the constructor to the optional matches argument, defaulting to false.

The query string itself is ignored, and no subscription or media-query machinery exists on the server.

<a id="u-0c1b5a22246d"></a>
### `packages/svelte/src/reactivity/index-server.js:createSubscriber`

`export function createSubscriber(_)` · [packages/svelte/src/reactivity/index-server.js:L21-L23][f6]

Server-side no-op replacement for createSubscriber: it ignores its argument and returns an empty function, so client code calling the subscribe function does nothing on the server.

<a id="u-2a69132bdb51"></a>
### `packages/svelte/src/store/index-server.js:fromStore`

`export function fromStore(store)` · [packages/svelte/src/store/index-server.js:L84-L87][f7]

Server variant of `fromStore`: returns an object whose `current` getter simply calls `get(store)`, with no subscription or caching since there is no reactive effect system on the server.

If `'set' in store`, the object additionally exposes a `current` setter delegating to `store.set(v)`; otherwise `current` is read-only.

calls: [packages/svelte/src/store/shared/index.js:get](r2-stores.md#u-624938d77758)

<a id="u-7280df9e1bf0"></a>
### `packages/svelte/src/store/index-server.js:toStore`

`export function toStore(get, set)` · [packages/svelte/src/store/index-server.js:L35-L49][f7]

Server variant of `toStore`: no reactive wiring.

It creates a `writable(get())` once at call time and returns `{set, update: fn => set(fn(get())), subscribe}` when a setter was given, otherwise `{subscribe}`. Because nothing subscribes to the underlying store, later state changes are not reflected unless `set`/`update` is used.

calls: [writable](r2-stores.md#u-dc45d71b793b)

<a id="u-608f30af0b16"></a>
### `easing-index-easing-functions`

`export function linear(t)` · [packages/svelte/src/easing/index.js:L10-L12][f8]

Module exporting pure easing functions that map progress `t` (a number, typically 0–1) to a transformed progress value, all adapted from mattdesl/eases under MIT.

Each family has in/out/inOut variants: linear returns t; back* overshoots using s=1.70158 (inOut uses s*1.525); bounce* uses piecewise polynomial bounceOut with thresholds a=4/11, b=8/11, c=9/10, and bounceIn/bounceInOut derive from it by mirroring around t=1 or 0.5; circ* uses square roots, potentially NaN for t outside [0,1] in circIn; cubic/quad/quart/quint use polynomial powers, with the InOut variants branching at t<0.5 (or doubling t); elastic/expo use sine and powers of 2, with expoIn/expoOut/expoInOut special-casing exact 0 and/or 1 inputs to return t itself; sine* use cosine/sine of π·t/2, where sineIn guards against floating-point noise by returning 1 when |cos| < 1e-14. Several functions mutate their parameter (t *= 2, --t, t--), which is safe because t is a local copy.

**Uncertainties.**

- Behavior for t outside [0,1] (overshoot values, NaN in circIn) follows directly from the formulas but is not tested here.

<a id="u-c15d4b363055"></a>
### `is_date`

`export function is_date(obj)` · [packages/svelte/src/motion/utils.js:L5-L7][f9]

Type guard returning true when obj's Object.prototype.toString tag is '[object Date]', so cross-realm Dates are recognized.

uses: [is_date](r4-reactive-primitives.md#u-c15d4b363055)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/reactivity/map.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/reactivity/set.test.ts
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/reactivity/date.test.ts
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/reactivity/url-search-params.js
[f5]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/reactivity/create-subscriber.js
[f6]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/reactivity/index-server.js
[f7]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/store/index-server.js
[f8]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/easing/index.js
[f9]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/motion/utils.js
