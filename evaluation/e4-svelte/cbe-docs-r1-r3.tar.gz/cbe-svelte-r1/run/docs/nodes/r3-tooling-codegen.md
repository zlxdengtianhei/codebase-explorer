# Code & Docs Generation

**Capability.** Generates package outputs from source data: TypeScript declaration files with style checks, src/version.js from package.json, and error/warning message modules plus docs from markdown under messages/, using the shared-errors template.

Use this subtree when regenerating declarations, version constants, or message-derived modules. process-messages' module tail drives run(); shared-errors.js is the template for the generated error throwers in the runtime dev-tools subtree.

**Depends on.**

- [Dev-Mode Diagnostics](r3-runtime-dev-tools.md) · model-inferred · 0 edge(s)

**Depended on by.**

- [Compiler Diagnostics & Warnings](r3-compiler-diagnostics.md) · model-inferred · 0 edge(s)

Parent: [Repository Tooling](r3-tooling.md)

## Units (5)

<a id="u-a7ff57214266"></a>
### `generate-types.js module code (L1–L85)`

`module_region` · [packages/svelte/scripts/generate-types.js:L1-L85][f1]

Generates the package's TypeScript declaration output and enforces two style checks.

It writes thin re-export .d.ts shims for 'action', 'animate', 'easing', 'motion', 'store', 'transition', 'legacy' plus index.d.ts and compiler.d.ts (each "import './types/index.js';") for consumers not using moduleResolution 'bundler', and legacy preprocess/interfaces shims under types/compiler after a recursive mkdir. It then awaits dts-buddy's createBundle with stripInternal (removing @internal declarations) and compilerOptions.paths derived from pkg.imports (preferring value.types, then value.default, then the raw value), registering roughly sixteen module entry points. Afterwards it appends a newline to types/index.d.ts and re-reads it: absolute markdown links ']\(/...)' are listed and the script exits 1; a '\texport { ' occurrence triggers an explanatory error (re-export statements break d.ts generation via @sveltejs/package) and exit 1.

**Uncertainties.**

- createBundle's behavior is an external dts-buddy API; only its configuration is observable here.

<a id="u-5c80dbc18b0c"></a>
### `generate-version.js module code (L1–L16)`

`module_region` · [packages/svelte/scripts/generate-version.js:L1-L16][f2]

Writes src/version.js at module load from package.json: VERSION is the full pkg.version and PUBLIC_VERSION its first dot-separated segment (pkg.version.split('.')[0]); the generated file is marked do-not-modify.

fs errors propagate uncaught.

<a id="u-6fdfa0228630"></a>
### `run`

`function run()` · [packages/svelte/scripts/process-messages/index.js:L17-L100][f3]

Regenerates message documentation and the generated source modules from markdown under messages/.

It removes and recreates DIR ('../../documentation/docs/98-reference/.generated'), then for each non-dot category directory reads each .md file (CRLF normalized). The regex /## ([\w]+)\n\n([^]+?)(?=$|\n\n## )/ extracts '## CODE' sections; a code already seen anywhere throws 'Duplicate message code <category>/<code>'. Each section's text is split on blank lines; while the last block does not start with '> ', it is popped and front-inserted into `details`; if no '> ' blocks remain it throws 'No message text'. Message lines strip a leading '> ' (bare '>' becomes a blank line). Each source .md is rewritten with its sections sorted by code; each generated category .md holds '### <code>' plus fenced message blocks and any details, sorted by rendered entry. It then defines transform() and applies it to seven templates, writing each into its src/ destination. Inside transform, an Identifier visitor replaces the `CODES` identifier with an array literal of the category's message codes.

uses: [index.js module code (L407–L429)](r3-tooling-codegen.md#u-3b801fcf6208)

<a id="u-3b801fcf6208"></a>
### `index.js module code (L407–L429)`

`module_region` · [packages/svelte/scripts/process-messages/index.js:L407-L429][f3]

Module tail that drives run().

When started with the '-w' argument it installs a recursive fs.watch on 'messages': while a run is in progress further events only arm a timeout (via ??=) that clears the running flag when it fires; otherwise it sets running = true, logs 'Regenerating messages...' and calls run() synchronously. Without '-w' it simply calls run() once.

calls: [run](r3-tooling-codegen.md#u-6fdfa0228630)

**Uncertainties.**

- The timeout duration is not visible in this excerpt; debounce timing cannot be stated.

<a id="u-c8f0956cc77a"></a>
### `packages/svelte/scripts/process-messages/templates/shared-errors.js:CODE`

`export function CODE(PARAMETER)` · [packages/svelte/scripts/process-messages/templates/shared-errors.js:L8-L16][f4]

Template for generated shared (client/server) error throwers.

Under DEV each generated function throws an Error named 'Svelte error' containing code, message and the https://svelte.dev/e/<code> link; otherwise it throws an Error containing only the link, keeping production messages minimal.

**Uncertainties.**

- DEV's truthiness conditions are defined in esm-env, not here.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/scripts/generate-types.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/scripts/generate-version.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/scripts/process-messages/index.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/scripts/process-messages/templates/shared-errors.js
