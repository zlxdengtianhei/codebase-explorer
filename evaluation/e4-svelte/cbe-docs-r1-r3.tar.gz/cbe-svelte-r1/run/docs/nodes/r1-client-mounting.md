# Mount, Hydrate & Unmount

**Capability.** Entry points that create the component root effect, wire event delegation, hydrate SSR markup with fallback to client mount, and tear components down; plus cheap text diffing.

Use this for the public mount/hydrate/unmount lifecycle. hydrate mounts in hydration mode and falls back on mismatch; _mount is the shared implementation behind both.

**Depends on.**

- [DOM & Rune Constant Predicates](r1-dom-dom-utils.md) · graph-confirmed · 1 edge(s)
- [Hydration Cursor State](r1-hydration-cursor.md) · graph-confirmed · 7 edge(s) · hydrate() uses the hydration cursor state and guards to walk server markup during mounting.
- [DOM primitives: operations and templates](r2-client-dom-core.md) · graph-only · 8 edge(s)

Parent: [Client Runtime](r1-runtime-client.md)

## Units (4)

<a id="u-4a887fa96d35"></a>
### `packages/svelte/src/internal/client/render.js:hydrate`

`export function hydrate(component, options)` · [packages/svelte/src/internal/client/render.js:L100-L166][f1]

Hydrates server-rendered markup by mounting the component in hydration mode, falling back to a full client mount on mismatch.

It locates the HYDRATION_START comment anchor inside the target (throwing HYDRATION_ERROR if absent), enables hydrating, mounts with that anchor, and verifies a HYDRATION_END comment remains — otherwise it warns hydration_mismatch and rethrows. On any failure it warns 'Failed to hydrate:' (unless the error is a Svelte error whose message contains a https://svelte.dev/e/ link, which is rethrown as-is, or the sentinel HYDRATION_ERROR), throws via e.hydration_failed when options.recover is false, and otherwise clears the target and calls mount for a clean client render. A finally block restores prior hydrating/hydrate_node state and resets the head anchor.

calls: [_mount](r1-client-mounting.md#u-fabacd5ad2b7), [warnings.js-generated-warning-helpers](r3-runtime-dev-tools.md#u-4587bd56f822); raises: [hydration_failed][f2]

**Uncertainties.**

- Detecting Svelte errors by string-matching 'https://svelte.dev/e/' in error message lines is a heuristic; error class identity is not checked.

<a id="u-fabacd5ad2b7"></a>
### `_mount`

`function _mount(Component, { target, anchor, props = {}, events, context, intro = tru…` · [packages/svelte/src/internal/client/render.js:L177-L184][f1]

Shared implementation behind mount/hydrate: creates a component_root effect that branches into the component render, wires up event propagation listeners, and registers a cleanup that removes them.

The component function runs synchronously inside the branch with should_intro set from the intro option (default true, or false during hydration), context pushed/popped if supplied, and events copied onto props.$$events without spreading to preserve a state-proxy props object. During hydration assign_nodes links the anchor; active_effect.nodes_end records hydrate_node afterwards. The instance is stored in mounted_components keyed to the unmount function, so unmount() can trigger teardown; the cleanup removes target listeners, decrements the document_listeners refcount (removing the document listener at zero), unregisters the event handle, and removes an auto-created text anchor.

**Notes.**

- side_effect: Every mount registers a document-level handle_event_propagation listener per event name (refcounted) so events originating from manually portaled elements are still caught.
- field: mounted_components is a module-level WeakMap mapping the component instance to its unmount function, allowing unmount() to find teardown without leaking instances.

calls: [component_root](r5-effects-module.md#u-42e380f9794b), [effects.js-trivial-effect-factories](r5-effects-module.md#u-191f01511fb1), [push](r4-component-context.md#u-9761c5d7c2ee), [pop](r4-component-context.md#u-fe159451466a), [is_passive_event](r1-dom-dom-utils.md#u-d023bfe04bdf), [operations.js-node-navigation](r2-client-dom-core.md#u-a31f01c2fa93), [assign_nodes](r2-client-dom-core.md#u-081194bea535)

**Uncertainties.**

- The document_listeners Map is shared across mounts, so listener lifetime depends on refcounting across all mounts; behavior when counts are corrupted elsewhere cannot be verified here.

<a id="u-4d8f77d0d2a4"></a>
### `packages/svelte/src/internal/client/render.js:unmount`

`export function unmount(component, options)` · [packages/svelte/src/internal/client/render.js:L303-L316][f1]

Tears down a component previously returned by mount/hydrate.

Looks up the unmount fn in mounted_components, deletes the entry, and returns its result (a Promise that resolves after outro transitions when options.outro is true). For an unknown component it returns Promise.resolve(), warning lifecycle_double_unmount in dev.

**Uncertainties.**

- Whether the unmount fn's return is always a Promise depends on component_root teardown, not visible here.

<a id="u-86b704dae3fa"></a>
### `set_text`

`export function set_text(text, value)` · [packages/svelte/src/internal/client/render.js:L52-L61][f1]

Updates a text node's value with cheap diffing.

Null/undefined become '', objects are string-coerced before comparison (making reactive references observable), and nodeValue is only written when the string differs from the cached __t marker.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/render.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/errors.js
