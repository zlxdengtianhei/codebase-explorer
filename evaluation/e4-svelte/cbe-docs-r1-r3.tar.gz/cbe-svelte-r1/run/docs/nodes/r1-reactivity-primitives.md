# Reactive Props & Equality

**Capability.** Implements component prop synchronization (prop, rest/spread/legacy-$props proxies, update helpers) and the deliberately over-eager equality tests that drive signal updates.

Use this for how $props(), spreads, rest destructuring and bindable props behave, and for the equality semantics that decide when updates propagate.

Parent: [Client Runtime](r1-runtime-client.md)

## Units (9)

<a id="u-2e500006b90d"></a>
### `props.js-prop`

`export function prop(props, key, flags, fallback)` · [packages/svelte/src/internal/client/reactivity/props.js:L278-L286][f1]

prop synchronizes a possibly bound component prop with local state and returns a getter/setter closure.

Setup classifies the prop via flags: runes (unless legacy mode with PROPS_IS_RUNES absent), bindable, lazy initial fallback. For bindable props a setter is taken from the existing descriptor, or, for entry props (STATE_SYMBOL/LEGACY_PROPS), a direct assignment to props[key]; the initial value is read under capture_store_binding to record whether it is a store subscription. When the initial value is undefined and a fallback exists, the fallback is evaluated lazily and untracked; in runes mode writing an invalid fallback value throws props_invalid_value, otherwise the setter is invoked with it. Getter behavior differs by mode: runes mode returns the fallback only while the prop is undefined and re-arms fallback_dirty once a real value appears; legacy mode permanently clears the fallback as soon as the prop was ever defined. Three return shapes follow: a plain getter when the prop is never written (runes without PROPS_IS_UPDATED); a direct-forwarding closure when a setter exists, which writes mutation ? getter() : value and skips notifying on pure mutation in runes mode unless the parent is legacy or it is a store subscription; otherwise a local derived (safe_equal unless immutable) is created, labeled with the key in DEV, its initial value read if bindable, and the returned closure writes into it via set(d, ...) (proxied when runes and bindable), tracking an overridden flag. During effect teardown, if the prop was locally overridden or the parent effect is DESTROYED, the closure returns the derived's cached d.v instead of re-evaluating, which also supports bind:this reads after destruction.

calls: [proxy](r3-runtime-proxy.md#u-6e64c72c9fe9), [packages/svelte/src/internal/client/reactivity/sources.js:set](r3-runtime-reactivity-sources.md#u-452914169f68); uses: [derived](r2-client-reactivity.md#u-d386336ed5eb)

**Uncertainties.**

- capture_store_binding's effect on the returned closure is only observable through its boolean result; its internals live in store.js
- The parent_effect teardown branch assumes active_effect at prop() creation is the component effect, which holds only if prop() is called during component setup

<a id="u-22f148fdaa7c"></a>
### `props.js-spread-props`

`const spread_props_handler = { get(target, key)` · [packages/svelte/src/internal/client/reactivity/props.js:L189-L197][f1]

spread_props wraps an ordered list of prop records (each possibly a function returning the record) in a Proxy, with later entries scanned first in get, set and getOwnPropertyDescriptor.

get walks back-to-front, calling function entries, and returns the first object containing the key, or undefined. set finds the first entry whose descriptor for the key has a setter, invokes it, and returns true; if none exists it returns false. getOwnPropertyDescriptor returns the first found descriptor, forcing configurable to true when a source object reports a non-configurable property, because the array target never actually contains the key and the proxy would otherwise throw a validation error. has returns false for STATE_SYMBOL and LEGACY_PROPS to avoid a false is_entry_props detection, then true when any entry contains the key. ownKeys collects unique string keys and symbols across all entries.

<a id="u-ee39c41b1f1a"></a>
### `props.js-rest-props`

`const rest_props_handler = { get(target, key)` · [packages/svelte/src/internal/client/reactivity/props.js:L53-L57][f1]

rest_props returns a Proxy over the full props record that hides every key in the exclude list, implementing rest destructuring like `const { x, ...rest } = $props()`.

get and getOwnPropertyDescriptor return undefined (or no descriptor) for excluded keys and otherwise forward to target.props; has returns false for excluded keys, ownKeys filters Reflect.ownKeys(target.props) by the exclude list. set always fails: it reports a props_rest_readonly error in DEV and returns false, so rest objects are read-only. The DEV target also carries name, other and to_proxy fields not present in production.

**Uncertainties.**

- Purpose of the DEV-only other/to_proxy fields is not visible in this file

<a id="u-d75531e1473e"></a>
### `props.js-legacy-rest-props`

`const legacy_rest_props_handler = { get(target, key)` · [packages/svelte/src/internal/client/reactivity/props.js:L103-L108][f1]

legacy_rest_props returns a Proxy implementing legacy $$restProps/$$props over a target holding props, an exclude array, a special map of per-key writable signals, a version source, and the creating component's parent_effect.

get subscribes to version (so any $$props write reruns all $$props reads, coarse-grained) and returns the special handler for keys promoted to writable, otherwise target.props[key]. set, when the key is not yet special, creates a prop() signal bound to target.props[key] with the active effect temporarily set to parent_effect (restored in finally), then writes the value through special[key] and bumps version. deleteProperty excludes the key (Svelte 4 allowed deletions on $$restProps) and bumps version, always returning true. getOwnPropertyDescriptor/has/ownKeys behave like the rest handler: excluded keys are hidden, ownKeys filters by exclude.

calls: [packages/svelte/src/internal/client/reactivity/sources.js:update](r3-runtime-reactivity-sources.md#u-63fbe11acd11), [props.js-prop](r1-reactivity-primitives.md#u-2e500006b90d)

<a id="u-b25a00737640"></a>
### `props.js-update-prop-helpers`

`export function update_prop(fn, d = 1)` · [packages/svelte/src/internal/client/reactivity/props.js:L31-L35][f1]

Small numeric-update helpers over prop getter/setter closures.

update_prop calls fn() to read the current value, writes value+d back through fn, and returns the pre-update value, so callers get the old value while the signal moves forward. update_pre_prop computes value+d first, writes it, and returns the new value. The direction d defaults to 1 and can be -1 for decrements.

<a id="u-3775acbc409e"></a>
### `safe_not_equal`

`export function safe_not_equal(a, b)` · [packages/svelte/src/internal/client/reactivity/equality.js:L13-L17][f2]

Reactivity inequality test that intentionally reports changes more often than strict difference.

When a is NaN (a != a), it returns whether b is a real number (b == b), so NaN versus anything always yields true except NaN versus NaN-ish comparisons resolve via b's validity. Otherwise it returns true if a !== b, or if a is a non-null object, or if a is a function — meaning any object or function new value always counts as changed even when referentially equal is false only by identity; equality by reference still returns false for the !== leg but the object/function clause forces true, so identical references to objects/functions are still treated as changed. Primitives equal by === return false.

**Uncertainties.**

- The object/function clause is ORed with a !== b, so even the same object reference yields true (safe_not_equal(o, o) is true); downstream consumers relying on this to always re-run for objects is inferred from the expression, not from caller behavior.

<a id="u-371c4a3b72d6"></a>
### `safe_equals`

`export function safe_equals(value)` · [packages/svelte/src/internal/client/reactivity/equality.js:L29-L31][f2]

Complement of safe_not_equal bound to a signal's value: returns !safe_not_equal(value, this.v).

It reports equality when safe_not_equal reports inequality, inheriting the NaN and object/function treatment. Like equals, it depends on this being bound to the source object.

calls: [safe_not_equal](r1-reactivity-primitives.md#u-3775acbc409e)

**Uncertainties.**

- Behavior unbound is undefined, same as equals.

<a id="u-d069e3e7a0b4"></a>
### `packages/svelte/src/internal/client/reactivity/equality.js:equals`

`export function equals(value)` · [packages/svelte/src/internal/client/reactivity/equality.js:L4-L6][f2]

Equality check bound to a reactive signal's current value via this.

Returns true only when the incoming value strictly equals this.v, using ===, so object and function comparisons are by reference. As a method-typed Equals, it relies on the caller binding this to the source object.

**Uncertainties.**

- Behavior when called unbound (this undefined) is a runtime error surface not visible in this file.

<a id="u-80bb0808e8b1"></a>
### `not_equal`

`export function not_equal(a, b)` · [packages/svelte/src/internal/client/reactivity/equality.js:L24-L26][f2]

Strict inequality: returns true exactly when a !== b.

No NaN or object special-casing, so NaN is considered equal to itself (returns false) and objects compare by reference. Used where assignments should propagate only on genuine value change.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/reactivity/props.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/reactivity/equality.js
