# ESLint Configuration

**Capability.** Composes the shared Svelte ESLint config with a custom no_compiler_imports rule that scans source text for compiler references.

Read this to see which lint rules apply repo-wide and how the repo prevents importing compiler internals from runtime code. The exported flat config array is the single source of truth.

Parent: [Build & Repo Tooling](r1-build-tooling.md)

## Units (3)

<a id="u-34b493301cfd"></a>
### `create`

`const no_compiler_imports = { meta: { type: /** @type {const} */ ('problem'), docs: {…` · [eslint.config.js:L4-L33][f1]

Implements the custom no_compiler_imports rule: on each Program it searches the whole source text for compiler references and reports the first occurrence.

It gets the full file text, computes the later of the two match positions via Math.max of indexOf('../compiler/') and indexOf('#compiler'); if both are -1 no report is made. On a hit it converts the index (and index+12) to source locations and reports that references to compiler code are forbidden for both type and value imports. It relies on string search rather than AST/JSDoc inspection, per the in-code comment accepting theoretical false positives.

**Notes.**

- side_effect: Reports at most one violation per file: only the position with the largest match index is reported.
- failure: If neither '../compiler/' nor '#compiler' appears, indexOf returns -1, Math.max yields -1, and nothing is reported.

uses: [eslint.config.js module code (L33–L109)](r1-lint-config.md#u-78c15cf9d85b)

**Uncertainties.**

- Whether Math.max (later match) versus min is intentional is not justified in source; only one report location is ever produced.
- The reported end location uses a fixed 12-character span regardless of which pattern matched.

<a id="u-55beeca2886a"></a>
### `eslint.config.js module code (L1–L3)`

`module_region` · [eslint.config.js:L1-L3][f1]

Imports the Svelte shared ESLint config and the lube plugin, which later config blocks consume.

Pure import region with no behavior of its own.

<a id="u-78c15cf9d85b"></a>
### `eslint.config.js module code (L33–L109)`

`module_region` · [eslint.config.js:L33-L109][f1]

Exports a flat ESLint config array that spreads @sveltejs/eslint-config and appends four config objects.

The first enables TypeScript project service rooted at import.meta.dirname, registers lube and the custom no_compiler_imports plugin, and sets rules: await-thenable, require-await, and no-console as errors, lube/svelte-naming-convention with fixSameNames, while turning off object-shorthand (JSDoc cast pattern false positive), prefer-promise-reject-errors, no-var, quotes, no-unused-vars, and prefer-const pending a future lint:fix run. The second targets **/*.svelte and disables the type-aware rules (await-thenable, prefer-promise-reject-errors, require-await) because type-aware rules reportedly fail when run through Svelte files. The third targets packages/svelte/src/** excluding the compiler directory, enabling custom/no_compiler_imports and disabling svelte/no-svelte-internal. The final block is a global ignores list covering declaration files, tests, generated/bundled scripts, error/warning modules that legitimately reference the compiler, the published compiler entry, benchmarking/coverage/playgrounds, top-level *.config.js, documentation, and tmp.

uses: [create](r1-lint-config.md#u-34b493301cfd); imports: [eslint.config.js module code (L1–L3)](r1-lint-config.md#u-55beeca2886a)

**Uncertainties.**

- exact resolution of import.meta.dirname and projectService behavior depends on the ESLint runtime, not visible here.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/eslint.config.js
