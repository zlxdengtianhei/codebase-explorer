# Analysis Phase

**Capability.** Walks the AST to compute dynamic-fragment metadata, validate special elements, run accessibility checks, and prune unused CSS selectors.

Use this subtree for warning-generation and metadata computation between parse and transform. Infrastructure (state types, shared visitor helpers) is separate from the a11y and CSS subsystems.

**Children.**

- [Analysis Infrastructure & Visitor Helpers](r1-analysis-infra.md) `r1-analysis-infra` · 7 unit(s)
- [Accessibility Analysis](r1-a11y-analysis.md) `r1-a11y-analysis` · 3 unit(s)
- [CSS Selector Pruning](r1-css-pruning.md) `r1-css-pruning` · 20 unit(s)

Parent: [Compiler Pipeline](r1-compiler.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
