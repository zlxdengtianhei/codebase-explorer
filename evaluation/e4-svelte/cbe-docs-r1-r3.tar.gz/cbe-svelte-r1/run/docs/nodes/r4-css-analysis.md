# CSS Analysis

**Capability.** Validates selector and at-rule semantics: classifies `:global` blocks and selectors, tracks keyframe names and global-keyframe usage, validates nesting-selector placement, and marks selector usage to suppress or emit unused-selector warnings.

Start at analyze_css as the entry point and follow the Rule/Atrule/ComplexSelector visitors. The is_* helpers express how global-ness propagates down the visitor path.

**Depends on.**

- [Compiler Semantic Model](r4-compiler-model.md) · graph-confirmed · 1 edge(s)

Parent: [Analysis](r4-analyze-phase.md)

## Units (12)

<a id="u-f762711e5ae7"></a>
### `analyze_css`

`export function analyze_css(stylesheet, analysis)` · [packages/svelte/src/compiler/phases/2-analyze/css/css-analyze.js:L322-L331][f1]

Entry point that analyzes a component's stylesheet.

It builds the initial `CssState` reusing `analysis.css.keyframes` as the keyframes list, with `rule` null and the component analysis attached, then walks the whole stylesheet with the module's `css_visitors`, which mutate selector/rule metadata, push keyframe names, and set `analysis.css.has_global` as a side effect.

uses: [Atrule](r4-css-analysis.md#u-e57d7d11437c)

<a id="u-b122f86baec1"></a>
### `is_global_block_selector`

`function is_global_block_selector(simple_selector)` · [packages/svelte/src/compiler/phases/2-analyze/css/css-analyze.js:L25-L31][f1]

Tests whether a simple selector is the bare `:global` pseudo-class that opens a global block.

Returns true only when the selector is a 'PseudoClassSelector' named 'global' with `args === null`; `:global(...)` with arguments returns false.

<a id="u-369b23b9e8cb"></a>
### `is_in_global_block`

`function is_in_global_block(path)` · [packages/svelte/src/compiler/phases/2-analyze/css/css-analyze.js:L46-L48][f1]

Reports whether any node in the visitor path is a Rule flagged with `metadata.is_global_block`, i.e. whether the current position sits inside a `:global { ...

}` block.

<a id="u-eb466791d0eb"></a>
### `is_unscoped`

`function is_unscoped(path)` · [packages/svelte/src/compiler/phases/2-analyze/css/css-analyze.js:L36-L40][f1]

Determines whether the entire enclosing rule chain is unscoped.

It filters the node path to Rule nodes and returns true only if every such rule has `metadata.has_global_selectors`; a path with no Rule nodes vacuously returns true.

**Uncertainties.**

- Vacuously true when the path contains no Rule nodes; whether that case is reachable depends on callers not shown here

<a id="u-e57d7d11437c"></a>
### `Atrule`

`const css_visitors = { Atrule(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/css/css-analyze.js:L51-L63][f1]

Collects keyframe names and records global-keyframe usage during CSS analysis.

For a keyframes at-rule: if the prelude does not start with '-global-' and the position is not inside a global block, the prelude name is pushed onto `state.keyframes`; else if the prelude starts with '-global-', `analysis.css.has_global` is OR-ed with `is_unscoped(path)` (empty keyframes blocks still count). `context.next()` runs in every case so children are always visited.

calls: [is_keyframes_node](r4-compiler-model.md#u-8dc3955e3495)

<a id="u-7665c45db5b3"></a>
### `ComplexSelector`

`ComplexSelector(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/css/css-analyze.js:L64-L141][f1]

Validates `:global` placement within a complex selector and computes its metadata.

After visiting children, it finds the first `is_global` child: if nested two frames up in a `PseudoClassSelector` and the global has no args, `css_global_block_invalid_placement` is raised; if the global has args but sits neither first nor last, any following non-global child raises `css_global_invalid_placement` (consecutive globals are allowed). A second pass over relative selectors enforces: a `:global(element)` whose inner first selector is a TypeSelector must be at compound position 0 (`css_global_invalid_selector_list`); `:global(...)` followed by a TypeSelector raises `css_type_selector_invalid_placement`; multiple selectors inside `:global(...)` raise `css_global_invalid_selector` when this complex selector has more than one relative selector or the compound has more than one selector. It then sets `metadata.rule`, marks `metadata.is_global` when every relative selector is global or global-like, ORs `metadata.used` with `is_global`, and finally marks a leading NestingSelector as used when the parent rule's prelude contains a single global child and the next selector is absent or an unscoped pseudo-class.

calls: [packages/svelte/src/compiler/phases/2-analyze/css/utils.js:is_global](r5-css-analyze-utils.md#u-022eb67172ae)

**Uncertainties.**

- Whether the `e.*` error functions throw or record depends on the errors module, not supplied

<a id="u-103ef31ee70b"></a>
### `NestingSelector`

`NestingSelector(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/css/css-analyze.js:L287-L315][f1]

Validates placement of the CSS nesting selector `&`.

Without a parent rule, `&` is legal only as the sole selector of a rule wrapped in `:global(...)`: the rule prelude must have one complex selector with one relative selector, whose first pseudo-class is `global` and whose first inner selector is this node; otherwise `css_nesting_selector_invalid_placement` is raised. With a parent rule that is a top-level global block consisting of a lone `:global`, `css_global_block_invalid_modifier_start` is raised (e.g. `:global { &.foo {} }`). `context.next()` always runs.

**Uncertainties.**

- The deeply indexed access into `global` args assumes a specific AST shape; a missing node would throw a TypeError before the error helper runs

<a id="u-db1d1474a19e"></a>
### `RelativeSelector.ComplexSelector`

`ComplexSelector(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/css/css-analyze.js:L187-L190][f1]

Inline visitor defined inside RelativeSelector: marks a complex selector's `metadata.used = true` and continues descent via `context.next()`; suppresses unused-selector warnings for selectors nested under global/root selectors.

<a id="u-7853ab08bc6e"></a>
### `RelativeSelector`

`RelativeSelector(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/css/css-analyze.js:L142-L187][f1]

Classifies a relative selector as global or global-like and marks nested selectors used.

A leading combinator raises `css_selector_invalid` unless the rule is nested (`rule.metadata.parent_rule`) or the context is a `PseudoClassSelector` three frames up. `metadata.is_global` is set when `is_global(node)` holds. `is_global_like` is set when all selectors are pseudo class/element selectors and the first is `:host` or one of the listed `view-transition*` pseudo-elements, or when the selector contains `:root` without containing `:has` (so `:root.y:has(.x)` stays scoped). For global/global-like selectors, each child selector is walked with an inline ComplexSelector visitor that sets `metadata.used = true`, preventing nested selectors like `:root:not(.x)` from being reported unused. `context.next()` always runs.

calls: [packages/svelte/src/compiler/phases/2-analyze/css/utils.js:is_global](r5-css-analyze-utils.md#u-022eb67172ae)

<a id="u-f5f18aef458a"></a>
### `Rule.ComplexSelector`

`ComplexSelector(node)` · [packages/svelte/src/compiler/phases/2-analyze/css/css-analyze.js:L226-L228][f1]

Inline visitor used while walking global-block child selectors: marks the visited complex selector's `metadata.used = true`.

No continuation call, so the walk stops at this node.

<a id="u-7fee2f390291"></a>
### `Rule`

`Rule(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/css/css-analyze.js:L197-L226][f1]

Classifies `:global { ...

}` block syntax for a rule and raises structural errors. It records `metadata.parent_rule` from state. Per complex selector, each relative child is examined: selectors after a detected `:global` opener are marked `is_global_like`; a child whose first selector is bare `:global` becomes a global block, but if that child has extra selectors and is first in a top-level rule, `css_global_block_invalid_modifier_start` is raised instead; a non-space combinator on such a child raises `css_global_block_invalid_combinator`; a lone `:global` combined with other complex selectors in the prelude raises `css_global_block_invalid_list`; a direct Declaration inside a single-selector lone-global rule raises `css_global_block_invalid_declaration`; `:global` at any position other than 0 raises `css_global_block_invalid_modifier`. If an earlier complex selector was a global block but the current one is not, `css_global_block_invalid_list` is raised. Selectors 1..n of a global-block child are walked marking their complex selectors used.

**Uncertainties.**

- Whether `e.*` throws or records depends on the errors module, not supplied

<a id="u-9242418cf87e"></a>
### `packages/svelte/src/compiler/phases/2-analyze/css/css-analyze.js:Rule`

`Rule(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/css/css-analyze.js:L228-L286][f1]

Continues Rule processing after global-block classification.

It builds child state `{...context.state, rule: node}`, visits `node.prelude` first so child selector metadata is populated, then aggregates `metadata.has_global_selectors` and `has_local_selectors` from each complex selector's `metadata.is_global`. `analysis.css.has_global` is set when the rule has global selectors, contains at least one Declaration, and the enclosing path is unscoped per `is_unscoped`. Finally `node.block` is visited with the same child state so nested rules inherit `parent_rule`.

calls: [is_unscoped](r4-css-analysis.md#u-eb466791d0eb)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/css/css-analyze.js
