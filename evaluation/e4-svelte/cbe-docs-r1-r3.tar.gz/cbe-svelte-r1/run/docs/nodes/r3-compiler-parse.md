# Template Parsing

**Capability.** Recursive-descent parsing of Svelte templates: the Parser state machine, dispatch over fragment/tag states, `{#...}` block structure, and `<svelte:options>` attribute validation.

Use this subtree to understand how raw template text becomes a Root AST. The Parser class provides cursor and error primitives; parse() drives the state loop; tag.js handles `{`-delimited syntax and options.js validates compile-time options.

**Depends on.**

- [Svelte Compiler](r3-compiler.md) · containment · → 0 / ← 0 edge(s) (ancestor direct units and descendant subtree; → follows ` r3-compiler-parse ` → ` r3-compiler `)
- [Template Element Parsing](r5-template-parsing.md) · graph-only · 13 edge(s)
- [Syntax parsing \(template expressions and CSS\)](r2-compiler-parsing.md) · graph-only · 12 edge(s)
- [Script and Expression Reading](r5-script-parsing.md) · graph-only · 10 edge(s)

**Depended on by.**

- [Semantic Analysis](r3-compiler-analyze.md) · model-inferred · 0 edge(s)

Parent: [Svelte Compiler](r3-compiler.md)

## Units (13)

<a id="u-5ceb409db775"></a>
### `index.js-parser`

`class Parser` · [packages/svelte/src/compiler/phases/1-parse/index.js:L18-L57][f1]

Recursive-descent Svelte template parser exposing cursor movement, token matching, node bookkeeping, and error helpers used by parse state functions.

**Notes.**

- field: Stack and fragments grow and shrink in tandem: pop() removes the top of both, append() pushes a node onto the innermost fragment, and current() peeks the stack top.
- condition: eat(str, required, required_in_loose) advances the index on match; on failure it raises expected_token only when required and (not loose or required_in_loose), otherwise returns false.
- condition: match() compares a literal at the index, with a single-character fast path; match_regex()/read() require a ^-anchored pattern and return null (or leave the index unchanged for read) when the match does not start at the index.
- condition: read_identifier() reads a Unicode code-point-wise identifier using acorn's isIdentifierStart/isIdentifierChar; it returns null if the first code point cannot start an identifier, and raises unexpected_reserved_word unless allow_reserved is set and the identifier is reserved.
- condition: read_until() raises unexpected_eof at end of input in strict mode but returns '' in loose mode; without a regex match it consumes to the end of the template.
- failure: require_whitespace() raises expected_whitespace when the current character is not whitespace, then skips whitespace.
- failure: acorn_error() rethrows an Acorn error as a js_parse_error, stripping the trailing '(line:col)' position indicator from the message.

**Uncertainties.**

- read_identifier's codePointAt at an out-of-range index would be undefined; behavior at exactly end-of-template relies on the isIdentifierStart check failing, which is acorn's concern.

<a id="u-53ab5f2b9b37"></a>
### `packages/svelte/src/compiler/phases/1-parse/index.js:parse`

`export function parse(template, loose = false)` · [packages/svelte/src/compiler/phases/1-parse/index.js:L296-L301][f1]

Entry point that records the source in shared compiler state, then parses the template with a new Parser and returns its Root node.

**Notes.**

- side_effect: Calls state.set_source(template) before parsing, which configures shared state used elsewhere in the compiler.

calls: [Parser.constructor](r3-compiler-parse.md#u-b8662ab25ac9); uses: [index.js-parser](r3-compiler-parse.md#u-5ceb409db775)

<a id="u-b8662ab25ac9"></a>
### `Parser.constructor`

`constructor(template, loose)` · [packages/svelte/src/compiler/phases/1-parse/index.js:L57-L151][f1]

Constructs the Parser and runs the full template state-machine loop, producing the Root AST or throwing structured parse errors.

**Notes.**

- failure: Throws TypeError immediately if the template is not a string.
- condition: TypeScript mode is detected by scanning the template with a module-shared global regex over HTML comments and tags for a lang attribute whose value is 'ts'; the do/while continues until a match whose second character is 's' (restricting to script tags), and regex lastIndex is reset afterwards because the regex is module-shared.
- failure: After the loop, leftover stack entries mean unclosed content: loose mode closes the node at template length; otherwise RegularElement raises element_unclosed and other node types raise block_unclosed, both with a synthesized end position. If the final state is not the fragment state, unexpected_eof is raised at the current index.
- side_effect: Root start/end are computed by trimming whitespace around the first and last fragment nodes, or set to null when the fragment is empty.
- side_effect: A SvelteOptions node found in the root fragment is removed from the nodes, converted via read_options, validated with disallow_children, and stashed as a non-enumerable __raw__ property pointing at the raw node for the legacy AST format.

uses: [index.js-parser](r3-compiler-parse.md#u-5ceb409db775); calls: [create_fragment](r5-template-parsing.md#u-6f16c2773335), [read_options](r3-compiler-parse.md#u-d4c4a2170fce), [disallow_children](r1-analysis-infra.md#u-43b79d8932ce)

**Uncertainties.**

- Whether the lang-scan loop reliably skips all non-script matches for arbitrary templates depends on regex_lang_attribute's full behavior, not fully verifiable from this excerpt.

<a id="u-d4c4a2170fce"></a>
### `read_options`

`export default function read_options(node)` · [packages/svelte/src/compiler/phases/1-parse/read/options.js:L10-L195][f2]

Converts the raw attributes of a `<svelte:options>` element into a validated `AST.SvelteOptions` object.

Each attribute must be of type `Attribute` or `e.svelte_options_invalid_attribute` fires. Known names map to option values: `runes`, `immutable`, `preserveWhitespace`, and `accessors` use `get_boolean_value`; `tag` always raises the deprecation error; `namespace` accepts the SVG/MathML constant strings, plain `html`/`mathml`/`svg`, otherwise errors; `css` must be exactly `injected`; unknown names raise `svelte_options_unknown_attribute`. The `customElement` branch is the largest: a bare `true` value errors; a text value is validated with `validate_tag` and stored as the tag; an object-literal value is decomposed into properties (`tag`, `props`, `shadow`, `extend`), where `props` must be an object of objects each containing only `type` (one of String/Number/Boolean/Array/Object), `reflect` (boolean), or `attribute` (string), and `shadow` must be `open` or `none`; a literal `null` value is silently ignored for backwards compatibility; anything else errors. Validation helpers throw immediately, so the first failing attribute aborts the whole read.

**Notes.**

- failure: Every malformed case calls an `e.*` error constructor; no partial options object is returned on failure.

calls: [get_static_value](r3-compiler-parse.md#u-6d5fb04e54eb), [get_boolean_value](r3-compiler-parse.md#u-afa9e7c8c98c), [validate_tag](r3-compiler-parse.md#u-5802e1b7bde8)

**Uncertainties.**

- The `if (!node)` guard after dereferencing `node.start` is dead code as written; its practical effect is unobservable for a falsy argument (it would already have thrown).
- Whether the `tag` property inside a `customElement` object expression is also subject to `get_static_value`-style checks is not shown; only `tag[1]?.value` is read here.

<a id="u-afa9e7c8c98c"></a>
### `get_boolean_value`

`function get_boolean_value(attribute)` · [packages/svelte/src/compiler/phases/1-parse/read/options.js:L222-L228][f2]

Reads an attribute value that must be exactly the boolean `true` or `false`; any other static result makes it raise `e.svelte_options_invalid_attribute_value(attribute, 'true or false')`.

Returns the boolean on success.

calls: [get_static_value](r3-compiler-parse.md#u-6d5fb04e54eb)

<a id="u-6d5fb04e54eb"></a>
### `get_static_value`

`function get_static_value(attribute)` · [packages/svelte/src/compiler/phases/1-parse/read/options.js:L200-L217][f2]

Extracts a compile-time constant value from a parsed attribute.

Returns `true` for shorthand (`value === true`) or a missing/empty chunk. A multi-chunk value returns `null` (non-static). A single `Text` chunk returns its `data` string; a single non-Literal expression returns `null`; otherwise the Literal's `value` is returned. Callers treat `null` as 'not statically determinable'.

**Uncertainties.**

- Accessing `chunk.expression.type` assumes the chunk is an expression chunk when it is not `Text`; the visible code does not guard other chunk types.

<a id="u-5802e1b7bde8"></a>
### `validate_tag`

`function validate_tag(attribute, tag)` · [packages/svelte/src/compiler/phases/1-parse/read/options.js:L250-L261][f2]

Asserts (via its `asserts` return type) that a custom-element tag is a valid string, then validates it against the WHATWG custom-element grammar regex: it must start with a lowercase letter, contain a hyphen, and use only the allowed lowercase/digit/unicode characters.

An empty string passes the `if (tag)` guard and thus the regex check; reserved names (`annotation-xml`, `color-profile`, `font-face*`, `missing-glyph`) raise `svelte_options_reserved_tagname`; a non-string raises `svelte_options_invalid_tagname`, as does a string failing the regex.

**Notes.**

- contract: Declared `asserts tag is string`, so callers may treat `tag` as a string after the call.

**Uncertainties.**

- An empty-string tag skips both error branches and would be accepted, despite being an invalid custom element name.

<a id="u-26ec42ae9fe1"></a>
### `fragment`

`export default function fragment(parser)` · [packages/svelte/src/compiler/phases/1-parse/state/fragment.js:L7-L17][f3]

Parser state selector: returns the next state function based on the character at the parser index — element for `<`, tag for `{`, otherwise text.

It returns the function rather than invoking it, so the parser loop applies the chosen state.

uses: [element](r5-template-parsing.md#u-bc08cb4e57fa), [text](r4-parse-phase.md#u-36401d8c3a23)

<a id="u-c3bb69761a6b"></a>
### `tag.js-open`

`function open(parser)` · [packages/svelte/src/compiler/phases/1-parse/state/tag.js:L51-L137][f4]

Parses `{#...}` block openings for if, each, await, key, and snippet blocks, sharing the pattern of backtracking to the real `{` start, reading a header expression, appending the block node, pushing it on parser.stack, and pushing its fragment so subsequent content lands in the new block's body.

calls: [read_expression](r2-compiler-parsing.md#u-793d43872467), [read_pattern](r5-script-parsing.md#u-eaf948574d56), [create_fragment](r5-template-parsing.md#u-6f16c2773335), [get_loose_identifier](r2-compiler-parsing.md#u-f85dafe8159e), [parse_expression_at](r5-script-parsing.md#u-730e2a662101), [match_bracket](r4-parse-phase.md#u-cf3966ee18ec), [create_expression_metadata](r4-compiler-model.md#u-32bbb434f744)

<a id="u-9c915ba5cbbf"></a>
### `tag`

`export default function tag(parser)` · [packages/svelte/src/compiler/phases/1-parse/state/tag.js:L18-L48][f4]

Dispatches a `{` encountered in template text to the appropriate expression or block parser.

After consuming `{`, it tries `#` (open), `:` (next), `@` (special), and `/` (close, only when not a comment `/*` or `//`); none matching means an inline `{expression}` is read via read_expression, whitespace and a mandatory `}` are consumed, and an ExpressionTag node is appended with fresh expression metadata.

calls: [tag.js-open](r3-compiler-parse.md#u-c3bb69761a6b), [next](r3-compiler-parse.md#u-3119a97fbde8), [special](r3-compiler-parse.md#u-4f88ba6dfbca), [close](r3-compiler-parse.md#u-8d9da699a16c), [read_expression](r2-compiler-parsing.md#u-793d43872467), [create_expression_metadata](r4-compiler-model.md#u-32bbb434f744)

**Uncertainties.**

- Whether `parser.match('/')` returning true with comment-like `/*` or `//` falls through to read_expression is only inferable from the code path; no explicit error is raised here.

<a id="u-8d9da699a16c"></a>
### `close`

`function close(parser)` · [packages/svelte/src/compiler/phases/1-parse/state/tag.js:L556-L624][f4]

Parses `{/...}` closing tags by matching the keyword against the current stack block.

IfBlock requires the `if` keyword (in loose mode, or when the keyword does not match, the block is implicitly closed: its end is set, popped, and close recurses on the new top); after `{/if}` a loop pops the stack through consecutive `elseif` blocks so a whole else-if chain ends together. EachBlock, KeyBlock, AwaitBlock, and SnippetBlock match their respective keywords. RegularElement closes only in loose mode (otherwise block_unexpected_close); any other block type errors with block_unexpected_close. When the expected keyword does not match, the current block is implicitly ended (end set, popped) and close recurses on the enclosing block, so `{/if}` can close nested non-if constructs. On a successful keyword match, whitespace and `}` are consumed, the block's end is recorded, and the block is popped.

contract: [tag.js-open](r3-compiler-parse.md#u-c3bb69761a6b)

**Uncertainties.**

- The comment says the unmatched-keyword recursion is 'only relevant/reached for loose parsing mode', but nothing in this function enforces loose mode for the non-RegularElement cases; the recursion path's reachability depends on parser state not visible here.

<a id="u-3119a97fbde8"></a>
### `next`

`function next(parser)` · [packages/svelte/src/compiler/phases/1-parse/state/tag.js:L442-L553][f4]

Parses `{:...}` continuation tags against the block currently on top of parser.stack.

For an IfBlock it requires `else` (rejecting `{:else if}` as an error since deprecated), swaps the active fragment for a new alternate fragment; if `if` follows, it reads the test expression, appends a nested IfBlock marked `elseif: true`, and pushes it with its consequent fragment, otherwise it consumes `}`. For an EachBlock it requires `else` and installs a fallback fragment. For an AwaitBlock it accepts `then` (with optional value pattern) or `catch` (with optional error pattern), erroring on a duplicate clause, each replacing the pending fragment; anything else after `{:await` is an expected-token error. A block of any other type raises block_invalid_continuation_placement. Missing `else`/`then`/`catch` keywords raise expected_token errors.

**Notes.**

- failure: `{:else if}` inside an IfBlock continuation calls e.block_invalid_elseif rather than being accepted, even though a nested else-if node is otherwise supported via `elseif: true` — the error is raised before that path is reachable from `next`.

calls: [read_pattern](r5-script-parsing.md#u-eaf948574d56), [read_expression](r2-compiler-parsing.md#u-793d43872467), [create_fragment](r5-template-parsing.md#u-6f16c2773335)

**Uncertainties.**

- The TODO notes parser.current()'s type is broader than the handled block types; other block types currently on the stack would hit the final error.

<a id="u-4f88ba6dfbca"></a>
### `special`

`function special(parser)` · [packages/svelte/src/compiler/phases/1-parse/state/tag.js:L627-L759][f4]

Parses `{@...}` special tags.

`{@html expr}` appends an HtmlTag. `{@debug}` with nothing before `}` appends a DebugTag with an empty identifier list (debug-all); otherwise the expression is read and must be Identifiers separated by commas — a SequenceExpression's elements or a single expression — and any non-Identifier triggers debug_tag_invalid_arguments. `{@const id = expr}` reads a pattern and initializer, rejecting a top-level SequenceExpression initializer unless a `(` appears in the source before the initializer (allowing `(b, c)` but not `b, c`), then appends a ConstTag wrapping a const VariableDeclaration whose span starts at `const` rather than `@const`. `{@render expr}` requires a CallExpression (possibly wrapped in ChainExpression) or raises render_tag_invalid_expression, then appends a RenderTag with empty metadata arguments/path/snippets. Only the const branch falls through; html, debug, and render return.

calls: [read_pattern](r5-script-parsing.md#u-eaf948574d56), [read_expression](r2-compiler-parsing.md#u-793d43872467), [create_expression_metadata](r4-compiler-model.md#u-32bbb434f744)

**Uncertainties.**

- After `{@const ...}` the function does not `return`; if `parser.eat('render')` somehow matched afterwards (unreachable since `const` was consumed), a second append would occur — the fall-through appears intentional but its reachability is unverified.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/1-parse/index.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/1-parse/read/options.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/1-parse/state/fragment.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/1-parse/state/tag.js
