# Analyze-phase AST visitors

**Capability.** Owns per-node-type semantic analysis: validating template constructs (attributes, directives, special elements, tags), tracking reactivity-relevant bindings, detecting delegated events, and emitting CSS unused-selector warnings.

Enter here per syntax construct to learn what the compiler checks and records about it during analysis. Visitors are thin and delegate shared rules to the validation core; event delegation analysis lives with the Attribute visitor. css-warn performs the stylesheet walk for unused selectors.

**Depends on.**

- [Analysis validation core](r2-analyze-shared-validation.md) · graph-confirmed · 6 edge(s) · Analysis visitors delegate semantic rules like assignment legality and tag validation to the shared validation core.
- [Compile diagnostics](r2-compiler-diagnostics.md) · model-inferred · 0 edge(s)
- [Analysis Infrastructure & Visitor Helpers](r1-analysis-infra.md) · graph-only · 13 edge(s)
- [Shared AST Utilities](r5-compiler-ast-utils.md) · graph-only · 13 edge(s)

Parent: [Component compiler pipeline](r2-compiler.md)

## Units (24)

<a id="u-d117d54d1300"></a>
### `arrowfunctionexpression-js`

`export function ArrowFunctionExpression(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/ArrowFunctionExpression.js:L9-L11][f1]

Thin analyze-phase visitors that delegate shared logic.

ArrowFunctionExpression and FunctionExpression both forward to `visit_function`, which scopes the function body and tracks references; neither adds node-specific logic.

calls: [visit_function](r1-analysis-infra.md#u-98e829315086)

<a id="u-57ff0d312a51"></a>
### `AssignmentExpression`

`export function AssignmentExpression(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/AssignmentExpression.js:L10-L31][f2]

Analyzes assignment expressions, validating the target and recording invalidated bindings for reactivity tracking.

validate_assignment(node, node.left, context) enforces target legality; its errors propagate. Inside a reactive statement, every identifier extracted from the left side has its binding added to reactive_statement.assignments — for a MemberExpression target `object` reduces to the base identifier, and a null base skips the loop. When an expression metadata object is in state, has_assignment is set. Always continues via context.next().

calls: [validate_assignment](r2-analyze-shared-validation.md#u-83497fe81c11)

**Uncertainties.**

- Whether validate_assignment rejects particular target shapes is decided in shared/utils.js, not visible here

<a id="u-a8d2e390ed17"></a>
### `Attribute`

`export function Attribute(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/Attribute.js:L16-L79][f3]

Analyzes a component attribute node, marking the surrounding subtree dynamic when the attribute requires runtime resolution.

After context.next(), it marks dynamic when: the parent RegularElement is an <option value>, the attribute is an event attribute, its name cannot be set statically, or it is a non-literal class expression (in which case it also sets node.metadata.needs_clsx). When the attribute has a value, it iterates chunks; for event attributes on RegularElement/SvelteElement it sets analysis.uses_event_attributes, computes the delegated-event info via get_delegated_event, marks the hoisted function's metadata and stores the result in node.metadata.delegated. A loop over expression chunks skips function expressions, performing no other action in the visible code.

**Notes.**

- side_effect: Sets node.metadata.needs_clsx, node.metadata.delegated, delegated_event.function.metadata.hoisted, and analysis.uses_event_attributes.

calls: [get_delegated_event](r2-analyze-visitors.md#u-462828f3596d), [mark_subtree_dynamic](r1-analysis-infra.md#u-3e6e9a44c2b4), [get_attribute_chunks](r5-compiler-ast-utils.md#u-1096ddb4c2b1), [get_attribute_expression](r5-compiler-ast-utils.md#u-96e6f6d66786), [is_event_attribute](r5-compiler-ast-utils.md#u-1c2da82112be), [cannot_be_set_statically](r1-dom-dom-utils.md#u-2389aaa6b031)

**Uncertainties.**

- The loop over attribute chunks other than skipping non-function expressions has no observable effect in the visible source, which may indicate removed or future logic.

<a id="u-462828f3596d"></a>
### `get_delegated_event`

`function get_delegated_event(event_name, handler, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/Attribute.js:L91-L233][f3]

Determines whether an event handler can be delegated and hoisted, returning null when not applicable, the shared unhoisted DelegatedEvent when delegation is possible but hoisting is not, or {hoisted:true, function} when hoisting is safe.

Returns null when the handler is missing, the event name is not delegated, or the closest element is not a RegularElement. Returns unhoisted when the element has spread attributes (the event becomes part of the dynamic spread array). For inline arrow/function-expression handlers the handler is the target; for identifiers it resolves the binding and inspects each reference path: references that are OnDirectives or event-attribute expression tags must point at non-spread RegularElements with delegated event names, others must be FunctionDeclarations or VariableDeclarators; module-scope references and exported names also force unhoisted; otherwise the bound function becomes the target. Then bails to unhoisted when the target is missing, has more than one parameter, or any reference in its scope uses arguments/$host, a store subscription, an unhoistable snippet, a shadowed local binding, repeated $store references, each-block indices, rest params, each bindings in non-runes mode, or mutated normal bindings.

**Notes.**

- side_effect: Returns the module-level shared object unhoisted (hoisted:false) rather than allocating a new object per call.
- condition: The reference-path walk classifies each usage; any path with no parent, or whose parent is neither OnDirective, event-attribute ExpressionTag, FunctionDeclaration, nor VariableDeclarator, returns unhoisted.

calls: [is_event_attribute](r5-compiler-ast-utils.md#u-1c2da82112be), [is_delegated](r1-dom-dom-utils.md#u-621eb4d7a691), [get_attribute_event_name](r2-analyze-visitors.md#u-95a93395ab75)

**Uncertainties.**

- The null-vs-unhoisted distinction matters to callers: null means not delegated at all; only the shared unhoisted object and the hoisted result are visible contracts here.

<a id="u-95a93395ab75"></a>
### `get_attribute_event_name`

`function get_attribute_event_name(event_name)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/Attribute.js:L238-L244][f3]

Strips the two-character 'on' prefix from an attribute-derived event name and, if the remainder is a capture event, removes the trailing seven-character 'capture' suffix before returning it.

calls: [is_capture_event](r1-dom-dom-utils.md#u-612ef41e7040)

<a id="u-3976d5e73938"></a>
### `DebugTag`

`export function DebugTag(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/DebugTag.js:L9-L15][f4]

Validates `{@debug ...}` tags in runes mode via `validate_opening_tag(node, context.state, '@')`, then continues visiting children.

Outside runes mode no validation runs.

calls: [validate_opening_tag](r2-analyze-shared-validation.md#u-8a95b3b7e6dc)

<a id="u-64d8ee790c77"></a>
### `packages/svelte/src/compiler/phases/2-analyze/visitors/ExportDefaultDeclaration.js:ExportDefaultDeclaration`

`export function ExportDefaultDeclaration(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/ExportDefaultDeclaration.js:L10-L20][f5]

Restricts default exports.

When `context.state.ast_type` is falsy (a `.svelte.js` module), an identifier default export is validated with `validate_export`; any other declaration shape passes unvalidated. When `ast_type` is truthy (an actual Svelte component file), `e.module_illegal_default_export(node)` is raised. `context.next()` runs in both cases.

calls: [validate_export](r2-analyze-shared-validation.md#u-1535dc101000); raises: [packages/svelte/src/compiler/phases/2-analyze/visitors/shared/utils.js][f6]

**Uncertainties.**

- The exact meaning of `ast_type` values is inferred from the comment; the state field is defined elsewhere

<a id="u-e5e44148727d"></a>
### `ExportSpecifier`

`export function ExportSpecifier(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/ExportSpecifier.js:L9-L30][f7]

Analyzes `export { a as b }` specifiers, resolving local and exported names from Identifier names or literal values.

In an instance script under runes mode, the pair {name: local, alias: exported} is pushed to analysis.exports and the local binding is marked reassigned (if it exists). Otherwise (module script or legacy mode) validate_export checks the export against scope; its failures propagate. No traversal is triggered — the node has no children to visit here.

calls: [validate_export](r2-analyze-shared-validation.md#u-1535dc101000)

<a id="u-eab780869b30"></a>
### `FunctionDeclaration`

`export function FunctionDeclaration(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/FunctionDeclaration.js:L10-L16][f8]

Analyzes function declarations.

In runes mode with a non-null id, it validates the function name by looking up the binding via `scope.get(node.id.name)` and passing it to `validate_identifier_name`. It then delegates to `visit_function` for scoping and reference tracking.

calls: [visit_function](r1-analysis-infra.md#u-98e829315086), [validate_identifier_name](r2-analyze-shared-validation.md#u-e442f835d467)

**Uncertainties.**

- Behavior when `scope.get` returns null is decided inside validate_identifier_name, not visible here

<a id="u-a9fa7ba9eca6"></a>
### `packages/svelte/src/compiler/phases/2-analyze/visitors/ImportDeclaration.js:ImportDeclaration`

`export function ImportDeclaration(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/ImportDeclaration.js:L9-L31][f9]

Analyzes import declarations in runes mode only.

Importing from any 'svelte/internal'-prefixed source throws import_svelte_internal_forbidden. Importing 'svelte' itself forbids the legacy lifecycle hooks: an ImportSpecifier named beforeUpdate or afterUpdate throws runes_mode_invalid_import. Non-runes mode performs no checks, and no traversal happens (imports have no analyzable children here).

**Uncertainties.**

- non-runes mode silently permits svelte/internal imports; whether other passes catch them is outside this file

<a id="u-a9f55b312aed"></a>
### `packages/svelte/src/compiler/phases/2-analyze/visitors/LabeledStatement.js:LabeledStatement`

`export function LabeledStatement(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/LabeledStatement.js:L12-L95][f10]

Analyzes labeled statements, specially handling `$:` reactive statements.

A `$:` at instance top level is a reactive statement: runes mode rejects it (legacy_reactive_statement_invalid); otherwise a ReactiveStatement is created, children are traversed with it in state and an incremented function_depth, then every scope reference becomes a dependency unless it is the left side of a plain `=` assignment (member-expression chains are unwrapped to their base). The statement is stored in analysis.reactive_statements, and if the body is a plain assignment, bindings of the assigned identifiers that are already legacy_reactive get their legacy_dependencies set from the collected dependencies. A misplaced `$:` outside instance top level warns reactive_declaration_invalid_placement in legacy mode only. Non-`$:` labels and all cases finish with a plain context.next() — note the reactive case traverses children twice structurally (once via the stateful next, once via the trailing next on already-visited content).

calls: [extract_identifiers](r5-compiler-ast-utils.md#u-90eb95affc00), [object](r5-compiler-ast-utils.md#u-2f2548aeaec6)

**Uncertainties.**

- the trailing context.next() after the earlier stateful context.next() may re-visit children; whether the visitor framework tolerates that is not visible here

<a id="u-6cad4b795a74"></a>
### `Literal`

`export function Literal(node)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/Literal.js:L8-L14][f11]

Warns about trojan-source bidirectional control characters.

For string literals only, if the value matches `regex_bidirectional_control_characters`, `w.bidirectional_control_characters(node)` is emitted; non-string values (numbers, booleans, null, regex) are ignored.

raises: [packages/svelte/src/compiler/phases/2-analyze/visitors/shared/utils.js][f6]

<a id="u-61f80c72baef"></a>
### `NewExpression`

`export function NewExpression(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/NewExpression.js:L9-L17][f12]

Flags performance and reactivity concerns for `new` expressions.

If the callee is a ClassExpression and the current `scope.function_depth` is greater than 0, `w.perf_avoid_inline_class(node)` warns against classes created inside functions. It then unconditionally sets `context.state.analysis.needs_context = true` and continues descent — every `new` expression in the component forces reactive context.

<a id="u-5d5cb13598f7"></a>
### `OnDirective`

`export function OnDirective(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/OnDirective.js:L10-L28][f13]

Handles on:event directives.

In runes mode it warns event_directive_deprecated for element parents (RegularElement/SvelteElement) but not component events, since those warnings would be unactionable. For element parents it records the first event directive node in analysis.event_directive_node (only if unset). It marks the subtree dynamic and continues traversal with node.metadata.expression as the expression state.

**Notes.**

- side_effect: Sets analysis.event_directive_node via ??= so only the first event directive is stored.

calls: [mark_subtree_dynamic](r1-analysis-infra.md#u-3e6e9a44c2b4)

<a id="u-5ba7dfee6f56"></a>
### `RenderTag`

`export function RenderTag(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/RenderTag.js:L14-L68][f14]

Analyzes `{@render ...}` tags.

The opening tag is validated and the template path recorded. The (optionally-unwrapped) callee's binding decides metadata.dynamic: true unless the callee is a plain identifier bound to a normal binding. When the binding resolves unambiguously to a SnippetBlock (is_resolved_snippet), the tag is recorded as resolved and that snippet is added to metadata.snippets; otherwise render tags are linked pessimistically. The tag registers in analysis.snippet_renderers and sets analysis.uses_render_tags. Spread arguments in the call throw render_tag_invalid_spread_argument; `.call`/`.apply`/`.bind` member calls throw render_tag_invalid_call_expression. The subtree is marked dynamic, the callee visited with the tag's expression metadata, and each argument visited with fresh per-argument expression metadata appended to metadata.arguments.

calls: [is_resolved_snippet](r1-analysis-infra.md#u-5fc246db911c), [unwrap_optional](r5-compiler-ast-utils.md#u-aa95700b7c80), [create_expression_metadata](r4-compiler-model.md#u-32bbb434f744)

<a id="u-4e2293e9dea9"></a>
### `packages/svelte/src/compiler/phases/2-analyze/visitors/SvelteBody.js:SvelteBody`

`export function SvelteBody(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/SvelteBody.js:L11-L22][f15]

Validates `<svelte:body>` usage.

It forbids child elements via `disallow_children(node)`, then for each attribute raises `e.svelte_body_illegal_attribute` when the attribute is a SpreadAttribute or a plain Attribute that is not an event attribute — only event bindings are allowed.

calls: [disallow_children](r1-analysis-infra.md#u-43b79d8932ce), [is_event_attribute](r5-compiler-ast-utils.md#u-1c2da82112be)

<a id="u-51de6fed2f32"></a>
### `packages/svelte/src/compiler/phases/2-analyze/visitors/SvelteDocument.js:SvelteDocument`

`export function SvelteDocument(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/SvelteDocument.js:L11-L24][f16]

Analyzes `<svelte:document>` elements.

disallow_children rejects any element children; then each attribute must be an event attribute — a SpreadAttribute or any non-event Attribute throws illegal_element_attribute for 'svelte:document'. Errors propagate; children are traversed via context.next() only if validation passes.

calls: [disallow_children](r1-analysis-infra.md#u-43b79d8932ce), [is_event_attribute](r5-compiler-ast-utils.md#u-1c2da82112be)

<a id="u-7502f1ce8b9a"></a>
### `SvelteHead`

`export function SvelteHead(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/SvelteHead.js:L10-L18][f17]

Validates `<svelte:head>`: raises `e.svelte_head_illegal_attribute` for every attribute on the node, marks the subtree dynamic, and continues descent.

calls: [mark_subtree_dynamic](r1-analysis-infra.md#u-3e6e9a44c2b4)

<a id="u-bba0e211168d"></a>
### `Text`

`export function Text(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/Text.js:L13-L52][f18]

Analyzes text nodes.

Non-whitespace text directly in a Fragment under a known parent element is content-model validated; an invalid combination throws node_invalid_placement. Every bidirectional control character in the data triggers a bidirectional_control_characters warning unless an earlier Comment sibling in the same Fragment carries a svelte-ignore for it — the ignore comment's own start offset (+4) is used when extracting. The warning is positioned at the match's absolute source offsets; the shared regex's lastIndex is reset before matching. No traversal is needed (text has no children).

**Notes.**

- side_effect: resets the module-level regex_bidirectional_control_characters.lastIndex to 0 before scanning, guarding shared regex state

calls: [extract_svelte_ignore](r3-compiler-diagnostics.md#u-4a9ee4fb9b67), [is_tag_valid_with_parent](r1-html-tree-validation.md#u-a93dfa56dc6d)

<a id="u-6a7a7b443898"></a>
### `warn_unused`

`export function warn_unused(stylesheet)` · [packages/svelte/src/compiler/phases/2-analyze/css/css-warn.js:L10-L12][f19]

Walks a stylesheet to emit unused-selector warnings.

The walk state carries only the stylesheet; the module-level `visitors` decide per node type whether descent continues and when `css_unused_selector` is raised.

uses: [packages/svelte/src/compiler/phases/2-analyze/css/css-warn.js:ComplexSelector](r2-analyze-visitors.md#u-2711ea3bb857)

<a id="u-582548f75fe1"></a>
### `packages/svelte/src/compiler/phases/2-analyze/css/css-warn.js:Atrule`

`const visitors = { Atrule(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/css/css-warn.js:L15-L20][f19]

Skips descending into keyframes at-rules during the unused-selector walk: when the node is a keyframes node, `context.next()` is not called, so selector children of keyframes are never checked.

calls: [is_keyframes_node](r4-compiler-model.md#u-8dc3955e3495)

<a id="u-2711ea3bb857"></a>
### `packages/svelte/src/compiler/phases/2-analyze/css/css-warn.js:ComplexSelector`

`ComplexSelector(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/css/css-warn.js:L26-L39][f19]

Warns about unused selectors.

If the complex selector's `metadata.used` is false, and either it is not nested inside an `is`/`where` pseudo-class two frames up, or the complex selector four frames up is used (preventing double warnings for `.unused:is(.unused)`), it slices the original stylesheet text between `node.start` and `node.end` and calls `w.css_unused_selector(node, text)`. `context.next()` always runs.

**Uncertainties.**

- Assumes node.start/node.end are valid offsets relative to `content.styles`/`content.start`; behavior when a single selector pair appears twice nested in `:is`/`:where` deeper than four frames is unproven

<a id="u-37b96b469bbc"></a>
### `PseudoClassSelector`

`PseudoClassSelector(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/css/css-warn.js:L21-L25][f19]

For `:is(...)` and `:where(...)` pseudo-classes, continues descent (`context.next()`); for all other pseudo-class selectors nothing happens, so their contents are not walked.

<a id="u-8e2f7056bd7d"></a>
### `packages/svelte/src/compiler/phases/2-analyze/css/css-warn.js:Rule`

`Rule(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/css/css-warn.js:L40-L46][f19]

For rules flagged `is_global_block`, visits only the prelude (checking global selectors for usage) and skips the block; all other rules continue with `context.next()`, walking both prelude and block.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/ArrowFunctionExpression.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/AssignmentExpression.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/Attribute.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/DebugTag.js
[f5]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/ExportDefaultDeclaration.js
[f6]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/shared/utils.js
[f7]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/ExportSpecifier.js
[f8]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/FunctionDeclaration.js
[f9]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/ImportDeclaration.js
[f10]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/LabeledStatement.js
[f11]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/Literal.js
[f12]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/NewExpression.js
[f13]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/OnDirective.js
[f14]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/RenderTag.js
[f15]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/SvelteBody.js
[f16]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/SvelteDocument.js
[f17]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/SvelteHead.js
[f18]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/Text.js
[f19]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/css/css-warn.js
