# Legacy Component Reactivity

**Capability.** Legacy-mode initialization that wires beforeUpdate/onMount/afterUpdate into the current component context and deeply reads all component state so it registers as reactive dependencies.

Use to understand how Svelte 4-style pre/update hooks are simulated over the signal graph.

**Depends on.**

- [Effect Lifecycle](r5-effects-module.md) · graph-confirmed · 3 edge(s)
- [Signal Core](r5-signal-core.md) · graph-confirmed · 4 edge(s)

Parent: [Client Runtime](r5-client-runtime.md)

## Units (2)

<a id="u-d1fb3ea6618e"></a>
### `packages/svelte/src/internal/client/dom/legacy/lifecycle.js:init`

`export function init(immutable = false)` · [packages/svelte/src/internal/client/dom/legacy/lifecycle.js:L12-L18][f1]

Legacy-mode initialization: resolves the current `component_context` (cast to the legacy context type) and returns early if its `l.u` callbacks bag is absent; otherwise wires `beforeUpdate`, `onMount`, and `afterUpdate` behavior.

With `immutable = true` (default false), a `derived` bumps a version counter only when some prop's object identity changes, and `props()` becomes `get(d)` — so before/afterUpdate fire only on prop identity changes; otherwise `props()` is `deep_read_state(context.s)`. If `callbacks.b` is non-empty, a `user_pre_effect` calls `observe_all(context, props)` then runs all beforeUpdate callbacks. A `user_effect` always runs: it untracks execution of all `onMount` (`callbacks.m`) callbacks via `run`, and its teardown invokes each returned function that is itself a function. If `callbacks.a` is non-empty, another `user_effect` calls `observe_all(context, props)` then runs all afterUpdate callbacks, so afterUpdate effects re-run when observed signals change.

calls: [observe_all](r5-legacy-internal.md#u-0dbaafa34d50), [packages/svelte/src/internal/client/dom/legacy/lifecycle.js:init](r5-legacy-internal.md#u-d1fb3ea6618e)

**Uncertainties.**

- Guaranteed order relative to user effects depends on `user_pre_effect`/`user_effect`/`derived` semantics defined elsewhere.
- Whether `run` may return non-function values is assumed from the `typeof fn === 'function'` teardown check.

<a id="u-0dbaafa34d50"></a>
### `observe_all`

`function observe_all(context, props)` · [packages/svelte/src/internal/client/dom/legacy/lifecycle.js:L76-L82][f1]

Reads every signal associated with a legacy component so they register as dependencies of the currently running effect: if `context.l.s` exists it calls `get(signal)` for each, then invokes `props()` (which itself reads component state, deeply or via the immutable-mode derived version counter).

Called from init's beforeUpdate and afterUpdate effects to make those effects re-run when the component's state changes.

uses: [packages/svelte/src/internal/client/dom/legacy/lifecycle.js:init](r5-legacy-internal.md#u-d1fb3ea6618e)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/legacy/lifecycle.js
