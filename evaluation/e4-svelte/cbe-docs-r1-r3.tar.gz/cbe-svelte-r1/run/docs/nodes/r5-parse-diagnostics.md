# Fuzzy Match Diagnostics

**Capability.** Approximate string matching (n-gram indexing plus Levenshtein) to suggest close alternatives for misspelled names.

A self-contained utility set; the analyze phase uses it for 'did you mean' suggestions on invalid bind targets.

**Depended on by.**

- [Analyze Visitors](r5-analyze-visitors.md) · graph-confirmed · 1 edge(s)

Parent: [Parse Phase](r5-parse.md)

## Units (6)

<a id="u-1a1551cf741f"></a>
### `FuzzySet`

`class FuzzySet` · [packages/svelte/src/compiler/phases/1-parse/utils/fuzzymatch.js:L123-L134][f1]

Approximate-string-match set in the style of fuzzyset.js: indexes candidate strings by 2- and 3-grams so lookups return ranked [score, originalString] tuples.

The constructor initializes items buckets for gram sizes 2 and 3 and adds every input string via add(). add() normalizes to lowercase and refuses duplicates already in exact_set (returning false without inserting); otherwise it indexes the string at both gram sizes via _add(), which stores each string under its gram postings in match_dict, records its vector normal, and registers the original (non-lowercased) string in exact_set. get() short-circuits exact (case-insensitive) hits to score 1, otherwise tries gram size 3 then 2 via __get(), returning null when nothing matches. __get() scores candidates by cosine-like gram overlap (shared gram counts product over vector normals), sorts descending, truncates to the top 50, recomputes true normalized edit-distance scores via _distance, sorts again, and keeps only entries tied with the best score, mapping back to the original strings stored in exact_set.

**Notes.**

- contract: Returned matches are [score, originalString] pairs; score 1 means exact case-insensitive match, and only ties with the best score survive __get.

calls: [gram_counter](r5-parse-diagnostics.md#u-500fe48ba9fb), [_distance](r5-parse-diagnostics.md#u-53c64f37672a); uses: [sort_descending][f1]

**Uncertainties.**

- add() has no explicit return on the successful path, so it returns undefined (not true) when a value is inserted; only the duplicate path returns false.
- __get computes matches[index] += ... accumulation assuming each gram posting appears once per candidate; correctness for duplicate candidates differing only in case relies on exact_set deduplication in add().
- items[match_index][0] in __get assumes match_index keys align with item indices stored in _add; the object-key coercion of numeric indices is not guarded.

<a id="u-53c64f37672a"></a>
### `_distance`

`function _distance(str1, str2)` · [packages/svelte/src/compiler/phases/1-parse/utils/fuzzymatch.js:L27-L37][f1]

Computes a normalized similarity in [0,1] as 1 - levenshtein/max(len).

Throws the string 'Trying to compare two null values' when both inputs are null; when only one is null it returns 0. Both inputs are coerced with String() before the Levenshtein distance is taken, so division is by the coerced maximum length.

**Notes.**

- failure: Throws a plain string (not an Error object) when both arguments are null.

calls: [levenshtein](r5-parse-diagnostics.md#u-1ed726d7da45)

**Uncertainties.**

- Comparison against null is via ===, so undefined inputs are coerced to the string 'undefined' rather than treated as null.

<a id="u-4d517976b3f9"></a>
### `fuzzymatch`

`export default function fuzzymatch(name, names)` · [packages/svelte/src/compiler/phases/1-parse/utils/fuzzymatch.js:L6-L13][f1]

Returns the best fuzzy suggestion for name among names, or null when there is no candidate list or no close match.

With an empty names list it returns null immediately. Otherwise it builds a FuzzySet from the candidates, gets matches for name, and returns matches[0][1] only when the top score exceeds 0.7; anything weaker (including a null match result) yields null. Used for 'did you mean' diagnostics in directive binding, a11y checks, and svelte-ignore extraction.

calls: [FuzzySet](r5-parse-diagnostics.md#u-1a1551cf741f); uses: [FuzzySet](r5-parse-diagnostics.md#u-1a1551cf741f)

**Uncertainties.**

- The 0.7 cutoff is strict greater-than; a score of exactly 0.7 yields null.
- Scores at or below 0 mean no overlap; only the first (highest-scoring) match is ever considered.

<a id="u-500fe48ba9fb"></a>
### `gram_counter`

`function gram_counter(value, gram_size = 2)` · [packages/svelte/src/compiler/phases/1-parse/utils/fuzzymatch.js:L97-L113][f1]

Wraps iterate_grams and returns a Record mapping each gram to its occurrence count in the value.

gram_size defaults to 2 like the underlying generator; iteration order follows gram order, and repeated grams accumulate.

calls: [iterate_grams](r5-parse-diagnostics.md#u-883c73062dca)

<a id="u-883c73062dca"></a>
### `iterate_grams`

`function iterate_grams(value, gram_size = 2)` · [packages/svelte/src/compiler/phases/1-parse/utils/fuzzymatch.js:L77-L91][f1]

Produces the n-gram list used for fuzzy matching: the value is lowercased, stripped of characters outside [\w, ] via non_word_regex, and padded with '-' on both sides; then all contiguous substrings of length gram_size (default 2) are returned.

If the padded simplified string is shorter than gram_size, extra '-' are appended to value before re-padding so at least the padding window can form — but note the grams are still sliced from the originally built simplified string, so a very short input can yield an empty results list.

**Notes.**

- side_effect: Pure with respect to the caller: builds and returns a new array.

**Uncertainties.**

- The len_diff padding mutates value but simplified was already built, so for len_diff > 0 the appended padding never reaches the returned grams; short strings may produce zero grams.

<a id="u-1ed726d7da45"></a>
### `levenshtein`

`function levenshtein(str1, str2)` · [packages/svelte/src/compiler/phases/1-parse/utils/fuzzymatch.js:L45-L69][f1]

Classic Levenshtein edit distance using a single rolling row (current array) with prev holding the deleted upper-left cell; when a row is empty (i or j is 0) the cell value is i + j.

Returns the last cell via current.pop(), which is str2.length when str1 is empty and vice versa. Cost is O(len1*len2) time, O(len1) space.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/1-parse/utils/fuzzymatch.js
