# Warning/Error Codegen Templates

**Capability.** Templates from which the generated server-side error throwers and shared console warners are emitted.

Use these templates to see the shape of generated runtime diagnostics. They are build-time inputs, not runtime code.

Parent: [Build & Repo Tooling](r1-build-tooling.md)

## Units (2)

<a id="u-85f7bd54b8a3"></a>
### `packages/svelte/scripts/process-messages/templates/server-errors.js:CODE`

`export function CODE(PARAMETER)` · [packages/svelte/scripts/process-messages/templates/server-errors.js:L8-L12][f1]

Template for generated server-side error throwers, unconditional on DEV.

Each generated function creates an Error containing code, message text and the https://svelte.dev/e/<code> link, names it 'Svelte error', and throws it; declared return type is `never`.

uses: [packages/svelte/scripts/process-messages/templates/shared-errors.js:CODE](r3-tooling-codegen.md#u-c8f0956cc77a)

<a id="u-8b569597eb19"></a>
### `packages/svelte/scripts/process-messages/templates/shared-warnings.js:CODE`

`export function CODE(PARAMETER)` · [packages/svelte/scripts/process-messages/templates/shared-warnings.js:L10-L20][f2]

Template for generated shared (client/server) console warners.

Under DEV each generated function warns with styled output (bold code header, normal message, doc link) using the module-level bold/normal strings; otherwise it warns with only the https://svelte.dev/e/<code> link.

**Uncertainties.**

- DEV's truthiness conditions are defined in esm-env, not here.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/scripts/process-messages/templates/server-errors.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/scripts/process-messages/templates/shared-warnings.js
