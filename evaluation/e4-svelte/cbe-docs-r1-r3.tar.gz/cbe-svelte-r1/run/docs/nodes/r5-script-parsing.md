# Script and Expression Reading

**Capability.** Feeds template-embedded JS/TS to Acorn: whole <script> blocks and single expressions, preserving comments, reading patterns and type annotations, and stripping TypeScript-only syntax.

Use to understand how inline code and `{expressions}` become ESTree nodes with comments intact. The TS-strip visitors run as a separate cleanup step invoked by the compile entry.

**Depends on.**

- [Shared AST Utilities](r5-compiler-ast-utils.md) · graph-confirmed · 1 edge(s)
- [Compiler Entry API](r5-compiler-entry.md) · model-inferred · 0 edge(s)

**Depended on by.**

- [Template Element Parsing](r5-template-parsing.md) · graph-confirmed · 1 edge(s)
- [Template Parsing](r3-compiler-parse.md) · graph-only · 10 edge(s)

Parent: [Parse Phase](r5-parse.md)

## Units (7)

<a id="u-25b8c96fd2a2"></a>
### `acorn.js-comment-handlers`

`function get_comment_handlers(source, comments, index = 0)` · [packages/svelte/src/compiler/phases/1-parse/acorn.js:L104-L139][f1]

Provides the onComment/add_comments pair that makes Acorn record comments it would otherwise drop, so svelte-ignore comments and prettier round-trips work.

**Notes.**

- side_effect: onComment pushes {type, value, start, end, loc} objects into the caller's comments array; for multiline block comments it strips common indentation by removing the comment's first-line leading whitespace from every line via a global multiline regex.
- condition: add_comments filters comments to those with start >= index (so expression parsing ignores earlier comments), then walks the AST: comments starting before a node become its leadingComments.
- condition: After next(), a comment becomes trailing when the node is the last entry of a BlockStatement/Program body, ArrayExpression elements, or ObjectExpression properties — then all remaining comments before the parent's end, even newline-separated, are attached — or when node.end <= comment start and the intervening text matches /^[,) \t]*$/, which attaches exactly one.
- condition: Leftover comments after the walk become the root's trailingComments when the first comment starts at or after ast.end or the ast is a Program; the code says this supports detecting the end of expression tags.
- failure: start_loc/end_loc are cast to acorn Position objects without a guard; if Acorn omits them the loc fields would be undefined.

**Uncertainties.**

- Trailing-comment placement for parent node types not listed depends on zimmerframe's path.at(-1) semantics, which is outside the supplied source.

<a id="u-2464d5720df7"></a>
### `packages/svelte/src/compiler/phases/1-parse/acorn.js:parse`

`export function parse(source, comments, typescript, is_script)` · [packages/svelte/src/compiler/phases/1-parse/acorn.js:L22-L66][f1]

Parses a JavaScript or TypeScript source string into an ESTree Program with Acorn, collecting comments into the caller-supplied array.

**Notes.**

- side_effect: When is_script is true, it temporarily replaces the shared parser prototype's parseStatement so each statement parse resets this.undefinedExports to {}, tolerating exports of names declared elsewhere in the component; the original is restored in a finally block even on throw.
- condition: Selects the TypeScript-extended parser when typescript is true, otherwise the stock acorn Parser; parsing uses sourceType 'module', ecmaVersion 16, and locations.

calls: [acorn.js-comment-handlers](r5-script-parsing.md#u-25b8c96fd2a2)

**Uncertainties.**

- The TypeScript parser is built once at module load by extending acorn.Parser with tsPlugin; other effects of that extension are outside this file.

<a id="u-730e2a662101"></a>
### `parse_expression_at`

`export function parse_expression_at(source, comments, typescript, index)` · [packages/svelte/src/compiler/phases/1-parse/acorn.js:L75-L94][f1]

Parses a single expression starting at a caller-supplied index, returning the expression AST with leading/trailing comments attached.

**Notes.**

- contract: Unlike full-source parse, it applies no is_script undefinedExports workaround and calls parseExpressionAt at the given index.

calls: [acorn.js-comment-handlers](r5-script-parsing.md#u-25b8c96fd2a2)

<a id="u-eaf948574d56"></a>
### `read_pattern`

`export default function read_pattern(parser)` · [packages/svelte/src/compiler/phases/1-parse/read/context.js:L14-L79][f2]

Parses a destructuring or identifier binding pattern following constructs like `{x}` or `[a, b]` in template contexts.

It first attempts a plain identifier via `parser.read_identifier`; on success it attaches an optional type annotation and returns an `Identifier` node with start/end locations resolved through the shared `locator`. Otherwise the first character must be `{` or `[` — anything else raises `e.expected_pattern`. For a bracketed pattern, `match_bracket` finds the closing index, the parser is advanced there, and the pattern text is re-parsed by tricking Acorn: preceding template text is blanked (newlines preserved, first space removed to keep column alignment), wrapped as `(pattern = 1)`, and parsed at `start - 1`, taking the `.left` side. A type annotation is then read from the real template and, if present, extends the expression's `end`. Any Acorn failure propagates through `parser.acorn_error(error)` with no other fallback, and that catch path does not return a value from the function's perspective.

**Notes.**

- side_effect: Mutates `parser.index` on both the identifier and bracket paths.
- failure: All parse failures funnel into `parser.acorn_error`; no alternative recovery exists in this function.

calls: [read_type_annotation](r5-script-parsing.md#u-e32a5aa85acf), [match_bracket](r4-parse-phase.md#u-cf3966ee18ec), [parse_expression_at](r5-script-parsing.md#u-730e2a662101)

**Uncertainties.**

- Behavior when `match_bracket` returns an unexpected index is not visible here and depends on bracket.js guarantees.
- The catch block calls `parser.acorn_error`, whose control-flow effect (throw vs. continue) is defined in the Parser, not shown.

<a id="u-e32a5aa85acf"></a>
### `read_type_annotation`

`function read_type_annotation(parser)` · [packages/svelte/src/compiler/phases/1-parse/read/context.js:L85-L125][f2]

Reads an optional `: Type` annotation after a pattern or parameter name, returning a `TSTypeAnnotation` node or `undefined`.

After skipping whitespace, if the next character is not `:` it rewinds `parser.index` to the saved start and returns `undefined`. When a colon is present it rewrites the template for Acorn-TS: everything before the insertion point is blanked (newlines kept), the text `_ as ` is injected so the annotation parses as an `as` expression, and every `? :` optional-marker later in the template is replaced with `:` to prevent Acorn-TS from treating subsequent parameters as sequence-expression members. If the result is an `AssignmentExpression` (mangled `foo: bar = baz`), it scans back to the `=` and re-parses the truncated template; if it is a `SequenceExpression` (trailing `, other`), only the first expression is kept. The parser index is set to the final expression's end and the returned node spans from the original start through that index.

**Notes.**

- side_effect: Restores `parser.index` on the no-annotation path and advances it to the annotation's end otherwise.
- failure: Acorn errors from `parse_expression_at` are not caught here; they propagate to the caller.

calls: [parse_expression_at](r5-script-parsing.md#u-730e2a662101)

**Uncertainties.**

- The backward scan `while (template[b] !== '=') b -= 1` assumes an `=` exists before the assignment's right side; malformed input behavior is not guarded here.

<a id="u-086699ac3458"></a>
### `read_script`

`export function read_script(parser, start, attributes)` · [packages/svelte/src/compiler/phases/1-parse/read/script.js:L22-L90][f3]

Reads the text of a `<script>` element and returns an `AST.Script`.

It consumes everything up to a closing `</script>` (with optional whitespace); if the template ends first, `e.element_unclosed` fires. The script source is synthesized by blanking the template prefix before the script start (newlines preserved) so Acorn error positions align, then parsed with `acorn.parse(..., true)`; parse failures go through `parser.acorn_error`. Attributes are then validated: reserved names (`server`, `client`, `worker`, `test`, `default`) raise `script_reserved_attribute`; unknown names warn via `w.script_unknown_attribute` without failing. `module` must be a shorthand boolean attribute or a generic invalid-value error fires and the context becomes `'module'`; `context` must be a text attribute whose value is exactly `"module"`, otherwise `script_invalid_context` fires. The returned node records `context` (`'default'` or `'module'`), the parsed Program, and the original attributes.

**Notes.**

- side_effect: `ast.start` is overwritten with the script's template start offset after parsing.

calls: [is_text_attribute](r5-compiler-ast-utils.md#u-ec400088cae5); uses: [packages/svelte/src/compiler/phases/1-parse/acorn.js][f1]

**Uncertainties.**

- The comment 'TODO is this necessary?' above `ast.start = script_start` flags unresolved intent; the downstream effect of this assignment is not visible here.

<a id="u-a94a43262fe7"></a>
### `remove_typescript_nodes.js-strip-visitors`

`function remove_this_param(node, context)` · [packages/svelte/src/compiler/phases/1-parse/remove_typescript_nodes.js:L11-L16][f4]

Zimmerframe visitors that erase TypeScript-only syntax from an ESTree AST, replacing type constructs with their underlying expressions and rejecting unsupported TS features with compiler errors.

**Notes.**

- side_effect: The default _(node, context) visitor mutates every node in place, deleting typeAnnotation, typeParameters, typeArguments, returnType, and accessibility so they cannot confuse the code generator.
- failure: Hard errors via typescript_invalid_feature: Decorator, TSEnumDeclaration, accessor PropertyDefinition, accessibility modifiers on constructor parameters (TSParameterProperty when readonly/accessibility is set and the grandparent path entry is a constructor), and namespaces (TSModuleDeclaration) whose visited bodies contain any non-empty node.
- condition: Type-only imports/exports are removed: importKind/exportKind === 'type' yields b.empty, and type-only specifiers are filtered out, yielding b.empty when nothing remains.
- condition: Wrapper expressions (TSAsExpression, TSSatisfiesExpression, TSNonNullExpression, TSTypeAssertion, TSInstantiationExpression) are replaced by a visit of their inner expression; TSInterfaceDeclaration, TSTypeAliasDeclaration, TSDeclareFunction, and declare-less TSModuleDeclaration bodies become b.empty.
- condition: ClassBody rebuilds its body dropping declare PropertyDefinitions; ClassDeclaration with declare becomes b.empty and otherwise deletes implements; abstract MethodDefinition and declare VariableDeclaration become b.empty; TSParameterProperty otherwise visits its parameter.
- condition: remove_this_param (shared by FunctionExpression/FunctionDeclaration) shifts off a leading parameter literally named 'this' and continues traversal via context.next().

**Uncertainties.**

- ExportNamedDeclaration's EmptyStatement check on the visited declaration result assumes zimmerframe returns a node with a declaration property; the exact returned shape when the child is erased depends on zimmerframe semantics outside this file.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/1-parse/acorn.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/1-parse/read/context.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/1-parse/read/script.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/1-parse/remove_typescript_nodes.js
