# Server rendering runtime

**Capability.** Owns server-side execution primitives: the component context stack with set/get/has context APIs, a module-level abort signal for stale SSR renders, and hydration markers for raw HTML output.

Read here for what the compiled SSR output calls at runtime. context.js maintains the linked component frame chain that context APIs walk; abort-signal signals stale reactions; blocks/html wraps raw HTML with markers for client hydration.

Parent: [Svelte compiler and runtime](r2-svelte.md)

## Units (11)

<a id="u-9654b4650543"></a>
### `abort`

`export function abort()` · [packages/svelte/src/internal/server/abort-signal.js:L6-L9][f1]

Aborts the current server-render abort controller, signalling stale reactions, then clears it.

Calls `abort(STALE_REACTION)` only if a controller exists, so the first call without a prior `getAbortSignal` is a no-op besides resetting state to null.

uses: [packages/svelte/src/internal/server/abort-signal.js:getAbortSignal](r2-server-runtime.md#u-fbe9939ec5b9)

**Uncertainties.**

- Effect of aborting with STALE_REACTION on reactions is defined in #client/constants consumers, not visible here.

<a id="u-fbe9939ec5b9"></a>
### `packages/svelte/src/internal/server/abort-signal.js:getAbortSignal`

`export function getAbortSignal()` · [packages/svelte/src/internal/server/abort-signal.js:L11-L13][f1]

Lazily creates and returns the signal of a module-level AbortController.

Uses `controller ??= new AbortController()`, so repeated calls within a render share one controller until `abort()` resets it.

uses: [abort](r2-server-runtime.md#u-9654b4650543)

<a id="u-b6ffad2a2a76"></a>
### `packages/svelte/src/internal/server/blocks/html.js:html`

`export function html(value)` · [packages/svelte/src/internal/server/blocks/html.js:L7-L11][f2]

Wraps a raw HTML string in hydration comment markers for server output.

Coerces the value with `String(value ?? '')`, so null becomes an empty string. In DEV the opening marker embeds a hash of the content (`<!--${hash(html)}-->`); otherwise it is a plain `<!---->`. Always appends `<!---->` as the closing marker.

calls: [hash](r1-dom-dom-utils.md#u-a8a8fa6d6333)

**Uncertainties.**

- Purpose of the DEV hash (e.g. hydration matching) is not established by this file.

<a id="u-ebffdeebb3a9"></a>
### `packages/svelte/src/internal/server/context.js:getAllContexts`

`export function getAllContexts()` · [packages/svelte/src/internal/server/context.js:L41-L43][f3]

Returns the current component's context Map itself, initialized on demand.

Mutating the returned Map mutates the component's context; requires an active component.

calls: [packages/svelte/src/internal/server/context.js:get_or_init_context_map](r2-server-runtime.md#u-23128ee48fc4)

<a id="u-590d884e05a5"></a>
### `packages/svelte/src/internal/server/context.js:getContext`

`export function getContext(key)` · [packages/svelte/src/internal/server/context.js:L14-L19][f3]

Reads a context value for the current component.

Requires a current component (else `get_or_init_context_map` throws via `lifecycle_outside_component`); then returns `context_map.get(key)` cast to T, so a missing key yields undefined rather than an error.

calls: [packages/svelte/src/internal/server/context.js:get_or_init_context_map](r2-server-runtime.md#u-23128ee48fc4)

<a id="u-23128ee48fc4"></a>
### `packages/svelte/src/internal/server/context.js:get_or_init_context_map`

`function get_or_init_context_map(name)` · [packages/svelte/src/internal/server/context.js:L49-L55][f3]

Shared guard/initializer for all context APIs.

If `current_component` is null it calls `e.lifecycle_outside_component(name)` (which throws), so all context functions fail outside component init. Otherwise it lazily assigns `current_component.c` a new Map seeded with the nearest ancestor context (`get_parent_context(...) || undefined`), giving child components inherited copies of parent entries at creation time.

**Notes.**

- side_effect: Mutates the current component's `c` field, permanently caching the context map.

calls: [packages/svelte/src/internal/server/context.js:get_parent_context](r2-server-runtime.md#u-6c070cbfaf56)

**Uncertainties.**

- Exact error thrown by lifecycle_outside_component is defined in errors.js/shared errors, not shown here.

<a id="u-6c070cbfaf56"></a>
### `packages/svelte/src/internal/server/context.js:get_parent_context`

`function get_parent_context(component_context)` · [packages/svelte/src/internal/server/context.js:L84-L96][f3]

Walks the parent chain of a component frame, returning the first non-null `c` context Map, or null if none exists.

Because maps are seeded at first access, this returns the closest ancestor's already-initialized map, or null if the whole chain is uninitialized.

<a id="u-d714cd56dee8"></a>
### `packages/svelte/src/internal/server/context.js:hasContext`

`export function hasContext(key)` · [packages/svelte/src/internal/server/context.js:L36-L38][f3]

Returns whether the current component's context map (possibly inherited) contains the key; requires an active component like the other context functions.

calls: [packages/svelte/src/internal/server/context.js:get_or_init_context_map](r2-server-runtime.md#u-23128ee48fc4)

<a id="u-b3ad8cba6058"></a>
### `packages/svelte/src/internal/server/context.js:pop`

`export function pop()` · [packages/svelte/src/internal/server/context.js:L68-L78][f3]

Pops the current component frame.

Collects any ondestroy callbacks accumulated in `component.d` into the shared `on_destroy` array (executed by `render` after the component body), then restores `current_component` to the parent frame. Assumes `current_component` is non-null; the cast would hide a null pop.

uses: [index.js module code (L1–L34)][f4]

**Uncertainties.**

- Behavior when pop is called with no active component (current_component null) is not guarded in this code.

<a id="u-38e06b351976"></a>
### `packages/svelte/src/internal/server/context.js:push`

`export function push(fn)` · [packages/svelte/src/internal/server/context.js:L60-L66][f3]

Pushes a new component frame onto the linked component stack: creates `{ p: current_component, c: null, d: null }` and sets it as `current_component`.

In DEV it also stores the component function on the frame, which dev.js reads for filename validation. Context inheritance happens later when `get_or_init_context_map` initializes `c`.

<a id="u-9d2873c370b6"></a>
### `packages/svelte/src/internal/server/context.js:setContext`

`export function setContext(key, context)` · [packages/svelte/src/internal/server/context.js:L27-L30][f3]

Stores a context value on the current component's map and returns the same value.

Throws `lifecycle_function_unavailable`-style error through `get_or_init_context_map` when no component is active.

calls: [packages/svelte/src/internal/server/context.js:get_or_init_context_map](r2-server-runtime.md#u-23128ee48fc4)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/server/abort-signal.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/server/blocks/html.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/server/context.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/server/index.js
