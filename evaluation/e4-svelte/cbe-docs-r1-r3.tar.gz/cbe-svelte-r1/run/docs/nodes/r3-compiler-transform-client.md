# Client Transform

**Capability.** Lowers the analyzed component into client-side render code: per-node visitors producing `$.` runtime calls, with shared element helpers building reactive attribute/class/style effects.

Use this subtree to see how template nodes become runtime invocations (element, key, slot, animation, await). shared/element.js builds the attribute/class/style update expressions reused by SvelteElement and SlotElement.

**Depends on.**

- [Compiler Diagnostics & Warnings](r3-compiler-diagnostics.md) · model-inferred · 0 edge(s)
- [Shared Transform Utilities](r3-compiler-transform-utils.md) · graph-confirmed · 3 edge(s)
- [Shared Client Transform Builders](r1-client-shared-transform-utils.md) · graph-only · 23 edge(s)

**Depended on by.**

- [Client Transform](r4-client-transform.md) · graph-only · 10 edge(s)

Parent: [Code Transformation](r3-compiler-transform.md)

## Units (19)

<a id="u-0128ebcf4caf"></a>
### `AnimateDirective`

`export function AnimateDirective(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/AnimateDirective.js:L11-L28][f1]

Compiles an animate: directive into an $.animation call pushed to after_update, so it runs after bind:this.

The directive name is parsed and visited as the animation key; the parameter expression becomes a thunk, or b.null when the directive has no expression.

calls: [parse_directive_name](r1-client-shared-transform-utils.md#u-47fb5120ded1)

<a id="u-6379edcfd2b5"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/AttachTag.js:AttachTag`

`export function AttachTag(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/AttachTag.js:L10-L14][f2]

Serializes an {@attach} tag into a $.attach call appended to init.

It builds the attach expression via build_expression, pushes a statement calling $.attach with the current node and a thunk wrapping the expression, then continues traversal with context.next() so children are still visited.

calls: [build_expression](r1-client-shared-transform-utils.md#u-cd5eb51d389f)

**Uncertainties.**

- Whether build_expression mutates node.metadata.expression is not visible in this file.

<a id="u-f3de4a3c5909"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/AwaitExpression.js:AwaitExpression`

`export function AwaitExpression(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/AwaitExpression.js:L10-L29][f3]

Transforms an await expression, wrapping it to preserve or diagnose reactivity context.

It first visits the argument. When the await is top-level in the instance script (is_instance with function_depth 1), or sits inside a reactive expression but is not the last-evaluated subexpression, it returns `await $.save(argument)` so surrounding reactive effects survive the await. Otherwise, when dev is on and 'await_reactivity_loss' is not ignored via is_ignored, it returns `await $.track_reactivity_loss(argument)`. In the remaining case it returns the original node when the visit left the argument identical (argument === node.argument), or a shallow copy with the transformed argument.

calls: [is_ignored](r5-compiler-state-errors.md#u-468324b42cee); uses: [is_reactive_expression](r3-compiler-transform-client.md#u-cce61d3ebba0), [is_last_evaluated_expression](r3-compiler-transform-client.md#u-b83cfea00bba)

<a id="u-b83cfea00bba"></a>
### `is_last_evaluated_expression`

`function is_last_evaluated_expression(context, node)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/AwaitExpression.js:L65-L126][f3]

Determines whether the node is the last value produced by its enclosing expression chain, walking the path outward.

A parent with metadata returns true immediately. Per parent type it returns false when the node is not the finally-evaluated part: a non-last ArrayExpression element; the left side of an Assignment/Binary/Logical expression; a non-last CallExpression or NewExpression argument; the test of a ConditionalExpression; the object of a computed MemberExpression; a non-last ObjectExpression property; a Property key; a non-last SequenceExpression expression; a non-last expression in a TaggedTemplateExpression quasi or TemplateLiteral. Any other parent type returns false. On each pass it ascends (node = parent); if the path is exhausted without disqualification the function ends, returning undefined (falsy).

**Uncertainties.**

- The implicit undefined return at the path root is treated as 'is last' by the caller because the condition negates the call; this is implementation behavior, not a documented contract.

<a id="u-cce61d3ebba0"></a>
### `is_reactive_expression`

`function is_reactive_expression(context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/AwaitExpression.js:L34-L59][f3]

Decides whether an await sits in a reactive position.

Returns true immediately when context.state.in_derived is set. Otherwise walks the context path from innermost outward: reaching an ArrowFunctionExpression, FunctionExpression, or FunctionDeclaration returns false (a function boundary ends reactivity); any parent carrying a metadata property returns true (inside a template/reactive construct); exhausting the path returns false.

<a id="u-113cc5a16382"></a>
### `BlockStatement`

`export function BlockStatement(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/BlockStatement.js:L10-L32][f4]

Serializes a block statement, wrapping it in tracing instrumentation when scope.tracing is set.

It calls add_state_transformers(context) first, then reads scope.tracing: when non-null it takes the nearest path parent (a function node), reads parent.async, visits each statement of node.body into a thunk, and returns a block containing `return $.trace(tracing, thunk)`, awaited when the parent function is async. When tracing is null it delegates to context.next().

calls: [add_state_transformers](r2-transform-client.md#u-32bec314643f)

**Uncertainties.**

- The code assumes the nearest path parent is always a function node when tracing is non-null; the cast is unchecked in this file.

<a id="u-7baf7e9461f9"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/Comment.js:Comment`

`export function Comment(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/Comment.js:L8-L11][f5]

Pushes a comment node into the template when comments are preserved (only reached when preserveComments is true), recording its data via template.push_comment.

uses: [Template](r1-client-template.md#u-f09b36ebd45e)

<a id="u-a79e6f67903d"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/ExportNamedDeclaration.js:ExportNamedDeclaration`

`export function ExportNamedDeclaration(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/ExportNamedDeclaration.js:L9-L19][f6]

Routes export handling during instance transformation.

In the instance state (is_instance) it visits the exported declaration, or returns b.empty for bare exports; otherwise it defers to context.next() for the normal path.

<a id="u-096c3cb09027"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/ExpressionStatement.js:ExpressionStatement`

`export function ExpressionStatement(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/ExpressionStatement.js:L10-L30][f7]

Rewrites effect runes used as statements.

If the statement is a call expression, get_rune identifies it: '$effect' becomes a $.user_effect call and '$effect.pre' a $.user_pre_effect call, visiting the rune's first argument as the callback; the callee's source location is copied onto the generated call for source-map mapping. '$inspect.trace' statements are dropped entirely (b.empty). Any other statement, or a non-call expression, falls through to context.next() for default handling.

calls: [get_rune](r4-compiler-model.md#u-5204b6ce4f7a)

<a id="u-7a4dc7847558"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/Fragment.js:Fragment`

`export function Fragment(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/Fragment.js:L16-L128][f8]

Transforms a fragment into a render block, choosing between a hoisted template and anchor-based rendering.

It infers the namespace from the parent and cleans the child nodes via clean_nodes; if nothing remains it returns an empty block. It sets up a fresh child state (init/consts/update/after_update, a new Memoizer and Template, copied transforms) and visits hoisted nodes. Then it branches on the trimmed content: a single RegularElement gets a generated element id, its template hoisted under the unique root name (with TEMPLATE_USE_IMPORT_NODE flag when needed), an init variable instantiating it, and a $.append close; a lone SvelteFragment/TitleElement is just visited; a single Text node becomes a $.text variable with an append close; multiple nodes either use a shared $.text template when they are only Text/ExpressionTags, use the existing $$anchor directly when standalone, or build a fragment template — substituting $.comment when the template holds exactly one comment node — with a $.first_child-based expression otherwise. After the body (consts, optional $.aborted early return for has_await, optional $.next to skip a leading placeholder comment, init, a render effect via build_render_statement when updates exist, after_update), the $.append close is emitted last because later insertions must be accounted for. With has_await the whole body is wrapped in $.async_body; otherwise a plain block is returned.

calls: [infer_namespace][f9], [clean_nodes](r3-compiler-transform-utils.md#u-2ed26069223c), [transform_template][f10], [process_children](r1-client-shared-transform-utils.md#u-7091653bb501)

**Uncertainties.**

- clean_nodes' filtering rules (whitespace, comments) are implemented in 3-transform/utils.js and only referenced here.

<a id="u-2bcd841aee06"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/KeyBlock.js:KeyBlock`

`export function KeyBlock(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/KeyBlock.js:L11-L38][f11]

Serializes a {#key} block into a $.key call, with an async wrapper when the key expression awaits.

It pushes a template comment, builds the key expression, and when has_await is set the runtime thunk reads `$.get($$key)` instead. It visits the fragment into an arrow over $$anchor, wraps the $.key(node, key, arrow) call in add_svelte_meta, and pushes to init: directly when no await, or inside a $.async(node, [thunk(expression, true)], callback binding $$key) statement when the key is asynchronous.

calls: [build_expression](r1-client-shared-transform-utils.md#u-cd5eb51d389f), [add_svelte_meta](r1-client-shared-transform-utils.md#u-75700db42066)

<a id="u-5bfaaebc7139"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/SlotElement.js:SlotElement`

`export function SlotElement(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/SlotElement.js:L12-L92][f12]

Serializes <slot> elements into a $.slot call with memoized attribute values and an optional fallback.

After pushing a template comment it partitions attributes: SpreadAttributes become thunks collected into spreads; Attributes are built via build_attribute_value, whose callback wraps values with has_call or has_await metadata in `$.get(memoizer.add(value, has_await))`; the `name` attribute replaces the default 'default' literal, `slot` attributes are dropped, and remaining attributes become object properties — getters (b.get) when the value has state, plain init properties otherwise. LetDirectives are visited and pushed to init before attributes so the bindings are available to them. memoizer.apply() runs, and memoizer.deriveds provides leading statements. The props expression is a plain object when no spreads exist, else `$.spread_props(object, ...spreads)`. The fallback is null for an empty fragment, else an arrow over $$anchor visiting the fragment. The $.slot(node, $$props, name, props, fallback) statement is appended, then init receives either a $.async wrapper (when async_values exist, binding memoized ids in the callback) or the single statement / block directly.

calls: [build_attribute_value](r3-compiler-transform-client.md#u-2462157783c9), [Memoizer](r1-client-shared-transform-utils.md#u-76b08484949a)

<a id="u-3c05d4ae0c14"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/SvelteBody.js:SvelteBody`

`export function SvelteBody(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/SvelteBody.js:L9-L11][f13]

Compiles <svelte:body> by delegating to visit_special_element with the target expression $.document.body.

calls: [visit_special_element](r5-client-transform-visitors.md#u-5f6160c62286)

<a id="u-fa257fa55ed4"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/SvelteElement.js:SvelteElement`

`export function SvelteElement(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/SvelteElement.js:L19-L156][f14]

Lowers a dynamic <svelte:element> into an $.element runtime call.

It pushes a template comment, then partitions attributes: xmlns (only if dynamic, i.e. not a text attribute) is kept as dynamic_namespace; Attributes and SpreadAttributes are collected; class/style directives are queued; Let directives are visited in the outer context producing statements; On directive handlers are visited in an inner context and pushed to its after_update; other attributes are visited in the inner context. Attribute application is runtime-dispatched: a single static class attribute uses build_set_class, while any other attribute set uses build_attribute_effect via spread because custom-element semantics cannot be determined statically. The tag expression is visited and wrapped in a thunk (deferred through $.get/$$tag when the element has an await). The inner context's init statements, an optional render effect from build_render_statement, after_update handlers, and the fragment visited under a child namespace from determine_namespace_for_children form the inner block passed to $.element. In dev it validates void dynamic elements (when the fragment is non-empty) and the tag expression via $.validate_* calls and attaches a line/column locator. The $.element call receives the anchor node, tag thunk, an svg/mathml boolean, the inner arrow when inner statements exist, the dynamic namespace thunk when present, and the dev location. When the tag expression has_await, the statements are wrapped in an $.async call; otherwise they are pushed to init as a single statement or block.

calls: [determine_namespace_for_children::12556][f9], [build_attribute_effect](r3-compiler-transform-client.md#u-0abd8487f7a1), [build_set_class](r3-compiler-transform-client.md#u-d08767f6fc10), [build_attribute_value](r3-compiler-transform-client.md#u-2462157783c9); uses: [is_text_attribute][f15]

**Uncertainties.**

- The runtime dispatch inside build_attribute_effect/build_set_class is defined in shared/element.js and only referenced here.
- locator(node.start) semantics come from state.js and are not visible.

<a id="u-0abd8487f7a1"></a>
### `build_attribute_effect`

`export function build_attribute_effect( attributes, class_directives, style_directive…` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/element.js:L20-L98][f16]

Builds a reactive `$.attribute_effect` call that updates attributes, class/style directive objects, and the scoped CSS hash on an element.

Each Attribute is serialized via build_attribute_value with memoization for call/await-bearing values; event attributes whose value is a function literal are hoisted into a named `event_handler` variable so updates reuse the same handler instead of removing/re-adding it. Non-Attribute entries (spreads) are visited and memoized when stateful, then pushed as spread properties. Class/style directives, when present, contribute `$.CLASS`/`$.STYLE` keyed init properties built by the RegularElement helpers against the same Memoizer. The final call receives the element id, an arrow over memoizer ids returning the values object, sync and async value arrays, the CSS hash literal only when the element is scoped and the hash is non-empty, and `true` only when 'hydration_attribute_changed' is not ignored. The memoizer is applied (ids assigned) and resulting statements are pushed to context.state.init.

**Notes.**

- side_effect: Pushes the attribute_effect statement and any hoisted handler declarations into context.state.init.

calls: [build_attribute_value](r3-compiler-transform-client.md#u-2462157783c9), [build_class_directives_object](r4-client-transform.md#u-93d4778b5497), [build_style_directives_object](r4-client-transform.md#u-29f008b00f20), [is_ignored](r5-compiler-state-errors.md#u-468324b42cee)

**Uncertainties.**

- build_class_directives_object/build_style_directives_object signatures and effects live outside the supplied source.

<a id="u-2462157783c9"></a>
### `build_attribute_value`

`export function build_attribute_value(value, context, memoize = (value) => value)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/element.js:L106-L127][f16]

Serializes an attribute value into a single expression plus a has_state flag.

`true` (boolean attribute) yields `true` with has_state false; a single Text chunk yields a string literal with has_state false; a single ExpressionTag is built with build_expression and passed through the caller's memoize callback, with has_state true when the expression has state or await; multi-chunk values are delegated to build_template_chunk.

calls: [build_expression](r1-client-shared-transform-utils.md#u-cd5eb51d389f), [build_template_chunk](r1-client-shared-transform-utils.md#u-d8d503fc4b7b)

<a id="u-d08767f6fc10"></a>
### `build_set_class`

`export function build_set_class(element, node_id, attribute, class_directives, contex…` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/element.js:L149-L217][f16]

Builds a `$.set_class` call updating an element's class attribute together with class directives and the scoped CSS hash.

The attribute value is built with clsx wrapping when attribute.metadata.needs_clsx and memoization for call/await values. When class directives exist, their objects form the `next` argument and has_state is OR-ed with directive state; if any directive is stateful a generated `classes` variable is declared and used as `prev`, otherwise an empty object literal is used. Scoped CSS hash merging has three cases: an empty/null literal class value becomes just the hash; a string literal becomes escaped-html of the value plus a space and the hash; otherwise the hash is passed separately (or null when no directives need it). The call is pushed to context.state.update when stateful, else context.state.init; with a previous-classes variable the whole call becomes an assignment to that variable.

calls: [build_attribute_value](r3-compiler-transform-client.md#u-2462157783c9), [build_class_directives_object](r4-client-transform.md#u-93d4778b5497), [escape_html](r5-shared-lib.md#u-0f499dd45547)

<a id="u-b481933571c2"></a>
### `build_set_style`

`export function build_set_style(node_id, attribute, style_directives, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/element.js:L225-L262][f16]

Builds a `$.set_style` call updating an element's inline style plus style directives.

The value is built with memoization for call-bearing expressions. When style directives exist they form the `next` object and has_state accumulates directive state; stateful directives allocate a generated `styles` variable as `prev` (the final call becomes an assignment to it), otherwise an empty object. The statement is pushed to context.state.update when stateful, else context.state.init.

calls: [build_style_directives_object](r4-client-transform.md#u-29f008b00f20)

<a id="u-794bd7468f40"></a>
### `get_attribute_name`

`export function get_attribute_name(element, attribute)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/element.js:L133-L139][f16]

Returns the normalized attribute name for HTML/MathML-free elements via normalize_attribute; for svg or mathml elements the name is returned unchanged to preserve case.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/AnimateDirective.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/AttachTag.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/AwaitExpression.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/BlockStatement.js
[f5]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/Comment.js
[f6]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/ExportNamedDeclaration.js
[f7]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/ExpressionStatement.js
[f8]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/Fragment.js
[f9]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/utils.js
[f10]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/transform-template/index.js
[f11]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/KeyBlock.js
[f12]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/SlotElement.js
[f13]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/SvelteBody.js
[f14]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/SvelteElement.js
[f15]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/utils/ast.js
[f16]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/element.js
