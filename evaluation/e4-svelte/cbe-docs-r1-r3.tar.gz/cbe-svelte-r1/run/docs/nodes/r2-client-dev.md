# Development-mode guards and tracing

**Capability.** Owns dev-only safety infrastructure: prop-ownership validation against illegal cross-component mutation, guards against removed component-instance APIs, and the process-wide tracing-mode flag enabled at module load.

Consult this for behavior that exists only in development builds or when tracing is explicitly enabled. These modules fail fast or instrument rather than implement features.

**Depends on.**

- [Compile diagnostics](r2-compiler-diagnostics.md) · model-inferred · 0 edge(s)

Parent: [Client runtime](r2-client-runtime.md)

## Units (4)

<a id="u-cec8691d0119"></a>
### `create_ownership_validator`

`export function create_ownership_validator(props)` · [packages/svelte/src/internal/client/dev/ownership.js:L16-L66][f1]

Builds a dev validator that flags illegal cross-component mutations and bindings of props.

It resolves the current component and its parent from component_context. mutation(prop, path, result, line, column) returns result unchanged when the root prop is bound or unset, or when there is no parent; otherwise it walks path elements requiring each intermediate value to carry STATE_SYMBOL (bailing out otherwise), then warns w.ownership_invalid_mutation with a sanitized location built from the component's FILENAME plus line/column. binding(key, child_component, value) warns w.ownership_invalid_binding when the key is not bound/unset, a parent exists, and value() carries STATE_SYMBOL.

calls: [is_bound_or_unset](r2-client-dev.md#u-cde78e1b7b26), [sanitize_location](r1-dom-dom-utils.md#u-eb8e19f29107)

**Uncertainties.**

- Component lookup depends on component_context shape (function, p.function) defined elsewhere; behavior when either is absent relies on optional chaining plus the !parent guard.

<a id="u-cde78e1b7b26"></a>
### `is_bound_or_unset`

`function is_bound_or_unset(props, prop_name)` · [packages/svelte/src/internal/client/dev/ownership.js:L72-L81][f1]

Determines whether a prop may legally be reassigned or was never passed.

Treats props as entry props when STATE_SYMBOL or LEGACY_PROPS is present, and returns true when the prop has a setter descriptor, is an entry prop present in props, or is not present in props at all. Grouped with create_ownership_validator, whose callbacks use it to skip ownership warnings.

**Uncertainties.**

- The comment justifies entry-prop handling for mount/createClassComponent cases; exact callers are outside this file.

<a id="u-7809689f1eee"></a>
### `legacy.js`

`export function check_target(target)` · [packages/svelte/src/internal/client/dev/legacy.js:L6-L10][f2]

Dev guards against removed component-instance APIs.

check_target throws e.component_api_invalid_new when a truthy target (a component function called with new) is passed, using its FILENAME or 'a component'. legacy_api reads the current component function from component_context and returns an object whose $destroy, $on, and $set all call the local error helper, which raises e.component_api_changed with the method name and the component's FILENAME. Both paths exist only to produce errors for legacy API usage.

**Uncertainties.**

- legacy_api assumes component_context?.function exists when the returned methods are called; error() would throw a TypeError if component were undefined.

<a id="u-3b9ed3b84d82"></a>
### `tracing-js-flags`

`group` · [packages/svelte/src/internal/flags/tracing.js:L1-L3][f3]

Side-effect module that enables runtime tracing: it imports enable_tracing_mode_flag and calls it at load, setting tracing_mode_flag to true process-wide.

Activation is by import alone.

imports: [index-js-flags](r1-mode-flags.md#u-10b9373cdfdd)

**Uncertainties.**

- The graph reports an unresolved require with no visible counterpart in the supplied source.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dev/ownership.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dev/legacy.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/flags/tracing.js
