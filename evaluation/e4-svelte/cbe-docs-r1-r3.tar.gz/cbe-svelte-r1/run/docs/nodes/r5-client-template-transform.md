# Template Emission

**Capability.** Turns accumulated template state into the runtime instantiation call, with dev-mode location metadata and canonical SVG attribute casing.

Read to see how the compiled template string and its effect expressions are assembled into the final DOM-building call.

**Depends on.**

- [Client Transform Visitors](r5-client-transform-visitors.md) · model-inferred · 0 edge(s)

Parent: [Client Transform](r5-client-transform.md)

## Units (3)

<a id="u-799dccdfecc2"></a>
### `fix_attribute_casing`

`export default function fix_attribute_casing(name)` · [packages/svelte/src/compiler/phases/3-transform/client/transform-template/fix-attribute-casing.js:L15-L18][f1]

Maps a lowercase SVG attribute name to its canonical mixed-case form, or returns the name unchanged.

It lowercases the input, looks it up in a module-level map built from the svg_attributes list (lowercase key → original spelling, e.g. 'viewbox' → 'viewBox'), and falls back to the lowercased input when no entry exists.

<a id="u-e3fa95e759b1"></a>
### `build_locations`

`function build_locations(nodes)` · [packages/svelte/src/compiler/phases/3-transform/client/transform-template/index.js:L12-L31][f2]

Recursively builds a dev-mode location array for template elements.

It creates an output array, skips every non-element node, and for each element records a [line, column] pair from the locator of its start offset, appending a nested children array only when that recursion produced elements. It assumes every node is inside locator coverage; no error handling is visible.

uses: [index.js module code (L1–L11)][f2]

**Uncertainties.**

- Assumes locator(node.start) always returns a Location; the cast is unchecked in source.

<a id="u-e8f6b714535e"></a>
### `transform_template`

`export function transform_template(state, namespace, flags = 0)` · [packages/svelte/src/compiler/phases/3-transform/client/transform-template/index.js:L38-L68][f2]

Turns the accumulated template state into the runtime instantiation call.

It picks tree vs HTML output from state.options.fragments === 'tree': in tree mode it flags svg/mathml namespaces via TEMPLATE_USE_SVG/TEMPLATE_USE_MATHML and calls $.from_tree, otherwise $.from_html/from_svg/from_mathml per namespace, passing a flags literal only when nonzero. If the template contained a <script> tag the call is wrapped in $.with_script; in dev mode it is further wrapped in $.add_locations with the component's $.FILENAME member and recursively built element locations.

calls: [build_locations](r5-client-template-transform.md#u-e3fa95e759b1); uses: [Template](r1-client-template.md#u-f09b36ebd45e), [packages/svelte/src/compiler/phases/3-transform/client/visitors/Fragment.js:Fragment](r3-compiler-transform-client.md#u-7a4dc7847558)

**Uncertainties.**

- Behavior of $.from_<namespace> for namespaces other than svg/mathml/html is not visible here.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/transform-template/fix-attribute-casing.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/transform-template/index.js
