# CBE run status

Run `e1d8f7` · status **complete** · updated 2026-10-17T16:38:19Z · review sample · jobs 2 · host api

Semantic review: mode **sample**; 1/1 reviewed by a separate reader of the source. This is independent of the deterministic structure/coverage checks and does not prove whole-map truth.

Counts: done 75

id_corrected 2

- module_54: ` packages/svelte/src/internal/client/reactivity/props.js::function::update_pre_prop::866 ` → ` packages/svelte/src/internal/client/reactivity/props.js::function::update_pre_prop::1058 ` (units[9].id)
- module_54: ` packages/svelte/src/internal/client/reactivity/props.js::function::update_pre_prop::866 ` → ` packages/svelte/src/internal/client/reactivity/props.js::function::update_pre_prop::1058 ` (dispositions[packages/svelte/src/internal/client/reactivity/props.js::function::update_pre_prop::1058].unit)

index_only_filled 2

- module_39: ` packages/svelte/src/compiler/preprocess/legacy-public.d.ts::type_alias::SveltePreprocessor::597 ` (missing)
- module_57: ` packages/svelte/src/motion/spring.js::class::Spring::5721::s1 ` (missing)

answer_fallback 1

- module_57: accepted attempt 2 (final attempt 3)

| Task | Module | State | Attempts | Seconds | Output | Note |
|---|---|---|---:|---:|---|---|
| names |  | done | 1 | 18.0 | host/accepted/names.json |  |
| module_1 | Benchmark Runner Utilities | done | 1 | 45.0 | host/accepted/module_1.json |  |
| module_2 | Reactivity and SSR Benchmark Suites | done | 1 | 189.0 | host/accepted/module_2.json |  |
| module_3 | Benchmark Comparison Runner | done | 1 | 23.0 | host/accepted/module_3.json |  |
| module_4 | ESLint Configuration | done | 2 | 20.0 | host/accepted/module_4.json |  |
| module_5 | Svelte Sandbox Playground with SSR Server and Scripts | done | 1 | 61.0 | host/accepted/module_5.json |  |
| module_6 | DOM Element Type Declarations | done | 2 | 120.0 | host/accepted/module_6.json |  |
| module_7 | Build Configuration and HTML Type Definitions | done | 1 | 32.0 | host/accepted/module_7.json |  |
| module_8 | Build and Codegen Maintenance Scripts | done | 3 | 131.0 | host/accepted/module_8.json |  |
| module_9 | Core Constants, Utilities, and Type Entry Points | done | 1 | 171.0 | host/accepted/module_9.json |  |
| module_10 | Public Client and Server Entry Points with HTML Validation | done | 1 | 80.0 | host/accepted/module_10.json |  |
| module_11 | Compiler Error Message Definitions | done | 1 | 163.0 | host/accepted/module_11.json |  |
| module_12 | Compiler Type Definitions and Warning Codes | done | 1 | 139.0 | host/accepted/module_12.json |  |
| module_13 | Compiler API Entry and Legacy Compilation | done | 2 | 141.0 | host/accepted/module_13.json |  |
| module_14 | Svelte 4 to 5 Migration Tool | done | 3 | 346.0 | host/accepted/module_14.json |  |
| module_15 | AST Nodes and Scope Analysis | done | 2 | 134.0 | host/accepted/module_15.json |  |
| module_16 | Svelte Template Parser | done | 1 | 141.0 | host/accepted/module_16.json |  |
| module_17 | Parser Readers for Expressions, Scripts, and Styles | done | 1 | 124.0 | host/accepted/module_17.json |  |
| module_18 | Parser State Machines for Markup and Text | done | 1 | 52.0 | host/accepted/module_18.json |  |
| module_19 | Parser Tag State Machine | done | 1 | 64.0 | host/accepted/module_19.json |  |
| module_20 | HTML Entity Lookup Table | done | 1 | 15.0 | host/accepted/module_20.json |  |
| module_21 | Parsing Helpers: Brackets, Node Creation, Fuzzy Matching, HTML Metadata | done | 2 | 106.0 | host/accepted/module_21.json |  |
| module_22 | Template Analysis Phase | done | 2 | 65.0 | host/accepted/module_22.json |  |
| module_23 | CSS Pruning Analysis | done | 2 | 148.0 | host/accepted/module_23.json |  |
| module_24 | Analysis Visitors: Attributes, Directives, Elements, Snippets | done | 1 | 96.0 | host/accepted/module_24.json |  |
| module_25 | Analysis Visitors for Blocks, Statements, and Expressions | done | 1 | 146.0 | host/accepted/module_25.json |  |
| module_26 | Shared Analysis Visitor Helpers | done | 1 | 116.0 | host/accepted/module_26.json |  |
| module_27 | Accessibility Warnings Analysis | done | 2 | 91.0 | host/accepted/module_27.json |  |
| module_28 | CSS Analysis, Cycle Detection, and Additional Analysis Visitors | done | 2 | 143.0 | host/accepted/module_28.json |  |
| module_29 | Transform Phase Infrastructure | done | 1 | 78.0 | host/accepted/module_29.json |  |
| module_30 | Client-Side Code Generation | done | 1 | 114.0 | host/accepted/module_30.json |  |
| module_31 | Client Transform Visitors: Events, Elements, Boundaries | done | 3 | 103.0 | host/accepted/module_31.json |  |
| module_32 | Client Transform Visitors: Bindings and Blocks | done | 2 | 115.0 | host/accepted/module_32.json |  |
| module_33 | Client Transform Visitors: Expressions, Snippets, Transitions | done | 3 | 132.0 | host/accepted/module_33.json |  |
| module_34 | Shared Client Transform Helpers | done | 2 | 127.0 | host/accepted/module_34.json |  |
| module_35 | Client Template Generation and Remaining Transform Visitors | done | 3 | 164.0 | host/accepted/module_35.json |  |
| module_36 | Server-Side Rendering Transform Visitors | done | 1 | 156.0 | host/accepted/module_36.json |  |
| module_37 | Shared Server Transform Helpers | done | 1 | 118.0 | host/accepted/module_37.json |  |
| module_38 | Server Transform Core, CSS Output, and Shared Assignment Utilities | done | 2 | 112.0 | host/accepted/module_38.json |  |
| module_39 | Preprocessing Pipeline with Sourcemap Handling | done | 3 | 106.0 | host/accepted/module_39.json | normalized (14); index_only_filled 1 |
| module_40 | Compiler Type Declarations | done | 2 | 172.0 | host/accepted/module_40.json |  |
| module_41 | Compiler AST Utilities and Diagnostics | done | 2 | 193.0 | host/accepted/module_41.json |  |
| module_42 | Compiler Utility Helpers | done | 3 | 89.0 | host/accepted/module_42.json |  |
| module_43 | Client Runtime Reactivity Engine | done | 5 | 116.0 | host/accepted/module_43.json |  |
| module_44 | Client Runtime Entry, Rendering, and Proxies | done | 2 | 124.0 | host/accepted/module_44.json |  |
| module_45 | Client Runtime Support: Context, Legacy, Timing, Validation | done | 2 | 132.0 | host/accepted/module_45.json |  |
| module_46 | Development-Mode Diagnostics and HMR | done | 2 | 100.0 | host/accepted/module_46.json |  |
| module_47 | DOM Operations, Hydration, and Templates | done | 2 | 127.0 | host/accepted/module_47.json |  |
| module_48 | Control Flow Block Rendering: Await, Boundary, Each, If | done | 1 | 148.0 | host/accepted/module_48.json |  |
| module_49 | Remaining Block Rendering: Slots, Snippets, Key, Head | done | 1 | 90.0 | host/accepted/module_49.json |  |
| module_50 | Element Attributes, Styles, Classes, and Transitions | done | 2 | 153.0 | host/accepted/module_50.json |  |
| module_51 | Element Actions, Attachments, Events, and Custom Elements | done | 2 | 89.0 | host/accepted/module_51.json |  |
| module_52 | Element Binding Implementations | done | 1 | 164.0 | host/accepted/module_52.json |  |
| module_53 | Reactivity: Batches, Effects, Async | done | 3 | 171.0 | host/accepted/module_53.json |  |
| module_54 | Reactivity: Sources, Deriveds, Props, Stores | done | 3 | 240.0 | host/accepted/module_54.json | normalized (90); id_corrected 2 |
| module_55 | Server-Side Rendering Runtime | done | 1 | 175.0 | host/accepted/module_55.json |  |
| module_56 | Shared Internal Utilities for Client and Server | done | 1 | 143.0 | host/accepted/module_56.json |  |
| module_57 | Motion: Springs and Tweens | done | 3 | 130.0 | host/accepted/module_57.json | normalized (10); answer_fallback attempt 2; index_only_filled 1 |
| module_58 | Reactive Built-ins: Map, Set, Date, Media Queries | done | 1 | 147.0 | host/accepted/module_58.json |  |
| module_59 | Reactive Value Infrastructure and URL Classes with Tests | done | 1 | 92.0 | host/accepted/module_59.json |  |
| module_60 | Easing, Transitions, Stores, and Legacy Support Modules | done | 1 | 227.0 | host/accepted/module_60.json |  |
| module_61 | Public API Modules: Actions, Animations, Events, Store Entry Points | done | 1 | 204.0 | host/accepted/module_61.json |  |
| module_62 | Public Package Type Definitions | done | 1 | 370.0 | host/accepted/module_62.json |  |
| module_63 | Server Entry, Feature Flags, Events, and Shared Compiler CSS | done | 2 | 56.0 | host/accepted/module_63.json |  |
| module_64 | Svelte Configuration | done | 1 | 10.0 | host/accepted/module_64.json |  |
| module_65 | Vitest Test Configuration | done | 1 | 15.0 | host/accepted/module_65.json |  |
| tree |  | done | 2 | 46.0 | host/accepted/tree.json |  |
| tree_region-0001 |  | done | 2 | 115.0 | host/accepted/tree_region-0001.json | normalized (3) |
| tree_region-0002 |  | done | 2 | 229.0 | host/accepted/tree_region-0002.json |  |
| tree_region-0003 |  | done | 2 | 130.0 | host/accepted/tree_region-0003.json | normalized (1) |
| tree_region-0004 |  | done | 2 | 156.0 | host/accepted/tree_region-0004.json |  |
| tree_region-0005 |  | done | 2 | 110.0 | host/accepted/tree_region-0005.json |  |
| tree_region-0006 |  | done | 2 | 126.0 | host/accepted/tree_region-0006.json |  |
| review_62 | Public Package Type Definitions | done | 1 | 32.0 | host/accepted/review_62.json |  |
| system |  | done | 4 | 50.0 | host/accepted/system.json | normalized (1) |
