# Codebase Explorer

## How to read this report

Start with the responsibility tree in INDEX. Open a node page for your maintenance question, then choose a unit.
Node pages explain responsibilities. `catalog.json` stores full signatures, source ranges, folded members, relation evidence, and graph edges.
Set `RUN` to the absolute path of this run directory. Find an id, then read its explanation or frozen source.

```sh
cbe find --run-dir "$RUN" --term "SEARCH_TERM"
cbe query --run-dir "$RUN" --id "$ID"
cbe source --run-dir "$RUN" --id "$ID" --context 2
```

`ID` can be a unit id, symbol id, or file path. Commands return the content directly.
`source` reads frozen source and verifies its digest first.
The catalog also stores reverse graph edges, statuses, and raw evidence.

## Responsibility tree

- [Svelte Monorepo](nodes/svelte-monorepo.md) (0 units)
  - [Svelte Monorepo](nodes/r1-svelte-monorepo.md) (2 units)
    - [set.test.ts-set-reactivity-tests](nodes/r1-svelte-monorepo.md#u-d5d1e7157705) · Vitest suite for SvelteSet covering reactivity and mutation semantics.
    - [Svelte Compiler](nodes/r1-compiler.md) (0 units)
      - [Parse Phase](nodes/r1-compiler-parse.md) (1 units)
        - [remove_typescript_nodes-js-strips-typescript-syntax-from-ast](nodes/r1-compiler-parse.md#u-acabd3d60ba8) · Strips TypeScript-only syntax from an already-parsed AST by walking it with zimmerframe, so the remaining JavaScript can be printed by esrap without confusing type artifacts.
        - [svelte:options Reading](nodes/r1-compiler-parse-options.md) (4 units)
          - [read_options](nodes/r1-compiler-parse-options.md#u-d4c4a2170fce) · Converts the attributes of a <svelte:options> node into a validated AST.SvelteOptions object.
        - [CSS Parsing](nodes/r1-compiler-parse-style.md) (14 units)
          - [read_style](nodes/r1-compiler-parse-style.md#u-863125efdf39) · Entry point that parses a <style> element into an AST.CSS.StyleSheet.
      - [Analyze Phase](nodes/r1-compiler-analyze.md) (1 units)
        - [check_graph_for_cycles](nodes/r1-compiler-analyze.md#u-9450956ffc9b) · Detects a dependency cycle in a directed graph given as [u, v] edge pairs and returns one cycle's node list, or undefined.
        - [Analysis Visitors](nodes/r1-compiler-analyze-visitors.md) (15 units)
          - [ArrowFunctionExpression](nodes/r1-compiler-analyze-visitors.md#u-5a0755c3b44f) · Delegates arrow function analysis entirely to visit_function, which handles scope creation and function-scoped reactivity tracking.
        - [Analysis Shared Validation](nodes/r1-compiler-analyze-shared-utils.md) (9 units)
          - [ensure_no_module_import_conflict](nodes/r1-compiler-analyze-shared-utils.md#u-ddca3e44b963) · Prevents an instance-context declaration from shadowing a module-context import with the same name.
      - [Transform Phase](nodes/r1-compiler-transform.md) (0 units)
        - [Client Transform Visitors](nodes/r1-compiler-transform-client.md) (17 units)
          - [component.js-build-component](nodes/r1-compiler-transform-client.md#u-ea683dd1d72c) · Builds the client-side serialization of a component (Component, SvelteComponent, SvelteSelf) into a statement that instantiates it with props, slots, events, and bindings.
        - [Shared Assignment Rewriting](nodes/r1-compiler-transform-shared.md) (1 units)
          - [visit_assignment_expression](nodes/r1-compiler-transform-shared.md#u-b43a982ab161) · Shared helper that rewrites assignment expressions whose left side is reactive-capable.
        - [Server Transform \(SSR\)](nodes/r1-compiler-transform-server.md) (14 units)
          - [transform-server-js-server-component](nodes/r1-compiler-transform-server.md#u-3bff6efcb646) · Transforms a component analysis into an SSR JavaScript Program.
      - [Preprocessing & Sourcemaps](nodes/r1-compiler-preprocess.md) (10 units)
        - [decode_map](nodes/r1-compiler-preprocess.md#u-c6f821c0ed6a) · Normalizes the map field of a Processed result into a decoded source map.
      - [Compiler Diagnostics](nodes/r1-compiler-diagnostics.md) (6 units)
        - [errors-js-generated-error-factories](nodes/r1-compiler-diagnostics.md#u-adef92463631) · Generated export for each compiler error code (options_invalid_value through void_element_invalid_content).
    - [Client Runtime](nodes/r1-client-runtime.md) (11 units)
      - [append_styles](nodes/r1-client-runtime.md#u-25ab046937f2) · Injects a component's CSS into the DOM once per matching root.
      - [Attribute Synchronization](nodes/r1-client-attributes.md) (17 units)
        - [attribute_effect](nodes/r1-client-attributes.md#u-dfc6319c1edb) · Creates a reactive effect that keeps an element's attributes in sync with attribute expressions.
    - [Boundaries & Async Blocks](nodes/r1-client-boundaries.md) (14 units)
      - [Boundary](nodes/r1-client-boundaries.md#u-480575efeafb) · Error and pending boundary that owns one block effect and swaps between main, pending, and failed child effects, preserving its DOM across destruction via EFFECT_PRESERVED.
    - [Dev-mode Diagnostics](nodes/r1-client-dev-dx.md) (7 units)
      - [assign.js-assignment-helpers](nodes/r1-client-dev-dx.md#u-e1a32c6b07a5) · Dev-mode wrappers for property assignment that warn when the pre-assignment value was stale.
      - [Generated Warning Helpers](nodes/r1-client-dev-warnings.md) (1 units)
        - [warnings-js-generated-messages](nodes/r1-client-dev-warnings.md#u-b66cedc3c469) · Generated dev-warning helpers, each calling `console.warn` exactly once and returning nothing.
    - [Shared Internals](nodes/r1-shared-internals.md) (22 units)
      - [errors-js-error-throwers](nodes/r1-shared-internals.md#u-94a28e8b7f6f) · Generated error-throwing helpers; each function never returns.
    - [Server Runtime \(SSR\)](nodes/r1-server-runtime.md) (7 units)
      - [packages/svelte/src/internal/server/blocks/html.js:html](nodes/r1-server-runtime.md#u-b6ffad2a2a76) · Render a raw `{@html}` value as a string wrapped in hydration comment markers.
    - [Public API Surface](nodes/r1-public-surface.md) (0 units)
      - [Rune Ambient Types](nodes/r1-public-runes-types.md) (8 units)
        - [ambient.d.ts-$bindable](nodes/r1-public-runes-types.md#u-2b06af83867c) · Declares the $bindable rune, which marks a prop as bindable by parents via bind:.
      - [Reactive Collections & Motion](nodes/r1-public-reactivity-motion.md) (13 units)
        - [index-js-local-helpers](nodes/r1-public-reactivity-motion.md#u-0a3d9aa213c7) · Local helpers for the transition module.
      - [Public Type Contracts](nodes/r1-public-type-contracts.md) (3 units)
        - [attachmentspublicdts-attachment](nodes/r1-public-type-contracts.md#u-004d2d4d10be) · Declares the Attachment type: a function called when an element is mounted, generic over an EventTarget subtype defaulting to Element, optionally returning a cleanup function run on removal.
    - [Repo Tooling & Benchmarks](nodes/r1-tooling.md) (0 units)
      - [Lint Configuration](nodes/r1-tooling-lint.md) (2 units)
        - [eslint.config.js-flat-config](nodes/r1-tooling-lint.md#u-4c030f15b9c8) · Defines the module's ESLint flat-config surface: the no_compiler_imports rule object plus the default-exported config array.
      - [Treeshakeability Verification](nodes/r1-tooling-treeshake.md) (4 units)
        - [packages/svelte/scripts/check-treeshakeability.js:bundle_code](nodes/r1-tooling-treeshake.md#u-8afde5f8f2a5) · Bundles a synthetic entry string through rollup and returns the single output chunk's trimmed code.
      - [Reactivity Benchmarks](nodes/r1-tooling-benchmarks.md) (2 units)
        - [kairo_deep-js](nodes/r1-tooling-benchmarks.md#u-08f0cffb8cef) · Builds a linear 50-deep derived chain (module constants len=50, iter=50) and times propagations through it.
      - [Playground Scripts](nodes/r1-tooling-playground.md) (4 units)
        - [create-app-svelte.js module code (L1–L13)](nodes/r1-tooling-playground.md#u-dde2e710e027) · Seeds src/main.svelte from main.template.svelte if it does not already exist.
  - [Compiler Pipeline and Migration](nodes/compiler-and-migration.md) (0 units)
    - [Svelte Monorepo](nodes/r5-svelte-monorepo.md) (0 units)
      - [Compiler Public API and Pipeline](nodes/r5-compiler-pipeline.md) (8 units)
        - [compile](nodes/r5-compiler-pipeline.md#u-a54e3b374c84) · Compile a `.svelte` component source into a JavaScript module by running the full parse/analyze/transform pipeline.
        - [Analyze-Phase Visitors](nodes/r5-analyze-phase.md) (18 units)
          - [RegularElement.js-regular-element](nodes/r5-analyze-phase.md#u-72f0e6cf5bcc) · Analyzes a regular HTML element: validates name/a11y, records element metadata (path, spread, svg/mathml), performs textarea/option rewrites, SSR parent/ancestor validity checks, and self-closing warnings.
        - [Client Transform](nodes/r5-client-transform.md) (27 units)
          - [template.js-template-class](nodes/r5-client-transform.md#u-74901e1385cf) · Accumulates an in-memory template representation (elements, comments, text) that visitors populate, then serializes it either to a single HTML-string quasi (as_html) or to a nested array literal (as_tree).
        - [Server \(SSR\) Transform](nodes/r5-server-transform.md) (9 units)
          - [packages/svelte/src/compiler/phases/3-transform/server/visitors/IfBlock.js:IfBlock](nodes/r5-server-transform.md#u-98ec092cab2d) · Emits an {#if} block as a runtime `if`.
      - [Svelte 4 to 5 Migration](nodes/r5-svelte-migration.md) (27 units)
        - [index-js-migrationerror](nodes/r5-svelte-migration.md#u-9fa554fc7f25) · Sentinel Error subclass whose constructor only forwards the message to Error, marking intentional migration aborts.
      - [Compiler Utilities and AST Helpers](nodes/r5-compiler-utilities.md) (23 units)
        - [equal](nodes/r5-compiler-utilities.md#u-2a153dd9dab6) · Asserts identity between two values, throwing a plain Error('Assertion failed') on !== mismatch.
      - [Client Runtime Reactivity](nodes/r5-runtime-reactivity.md) (67 units)
        - [errors.js-generated-error-throwers](nodes/r5-runtime-reactivity.md#u-aa3a4430105f) · Generated factory functions for named Svelte runtime errors; each never returns.
      - [Client Runtime DOM](nodes/r5-runtime-dom.md) (29 units)
        - [each](nodes/r5-runtime-dom.md#u-a4e1b3df9530) · Implements keyed each blocks: derives the collection (coercing null to [] and iterables via array_from), and on each rerun hydrates, creates, updates, reorders, or removes item effects, with optional fallback rendering for empty collections.
      - [Reactive Built-ins](nodes/r5-reactive-builtins.md) (6 units)
        - [packages/svelte/src/reactivity/map.js:SvelteMap](nodes/r5-reactive-builtins.md#u-8d62cace0a14) · Reactive Map subclass: reads in effects/deriveds re-run when the map mutates, without deep reactivity of values.
      - [Animation Helpers](nodes/r5-animation-helpers.md) (2 units)
        - [flip](nodes/r5-animation-helpers.md#u-2953ae0602e1) · Computes a First-Last-Invert-Play animation config that translates and scales an element between two DOMRect positions.
      - [Warning Codegen Template](nodes/r5-warnings-codegen.md) (3 units)
        - [InternalCompileWarning](nodes/r5-warnings-codegen.md#u-cb8e8c3375b1) · CompileDiagnostic subclass representing a single compile warning.
      - [Reactivity and SSR Benchmarks](nodes/r5-benchmarks.md) (5 units)
        - [kairo_diamond-js](nodes/r5-benchmarks.md#u-78f66379fb6c) · Diamond graph: module constant width=5, five deriveds each reading the same head plus a sum derived reducing them, timed over 500 updates.
      - [Playground Sandbox](nodes/r5-playground-sandbox.md) (5 units)
        - [download.js module code (L1–L52)](nodes/r5-playground-sandbox.md#u-3a2d44014938) · Downloads a Svelte playground app into src/.
  - [Client/Server Runtime and Shared Infrastructure](nodes/runtime-and-shared-infra.md) (0 units)
    - [Svelte Monorepo](nodes/r6-svelte-monorepo.md) (0 units)
      - [Reactivity Benchmarks](nodes/r6-benchmarking.md) (3 units)
        - [kairo_unstable-js](nodes/r6-benchmarking.md#u-72a078bef7a2) · Times a derived whose dependencies change dynamically: 20 loop iterations each pick between a double and an inverse derived based on the parity of head.
      - [Public DOM Element Typings](nodes/r6-public-dom-typings.md) (19 units)
        - [AriaAttributes](nodes/r6-public-dom-typings.md#u-00e9dbdc2f41) · Type-level map of the WAI-ARIA 1.1 attributes as optional element properties, each also permitting undefined and null.
      - [Compiler Pipeline](nodes/r6-compiler.md) (0 units)
        - [Compiler AST Declarations](nodes/r6-compiler-ast-types.md) (2 units)
          - [css.d.ts-css-ast-node-types](nodes/r6-compiler-ast-types.md#u-5d5d8b2013b5) · Type declarations for the compiler's internal CSS AST, exported as the `_CSS` namespace and re-aliased to `CSS` by template.d.ts.
        - [Template Parsing](nodes/r6-compiler-parse.md) (13 units)
          - [fragment](nodes/r6-compiler-parse.md#u-26ec42ae9fe1) · Dispatcher: returns the next parser state function based on the upcoming character — element state for '<', tag (expression/block) state for '{', otherwise text state.
        - [Semantic Analysis](nodes/r6-compiler-analyze.md) (19 units)
          - [AwaitExpression](nodes/r6-compiler-analyze.md#u-1731905f5fa9) · Analyzes await expressions, deciding whether the await may suspend and erroring otherwise.
          - [CSS Scoping Analysis](nodes/r6-compiler-analyze-css.md) (8 units)
            - [warn_unused](nodes/r6-compiler-analyze-css.md#u-6a7a7b443898) · Walks the stylesheet to emit unused-selector warnings, carrying { stylesheet } state into the module's visitors.
        - [Code Generation](nodes/r6-compiler-transform.md) (0 units)
          - [Client Transform](nodes/r6-transform-client.md) (19 units)
            - [client_component](nodes/r6-transform-client.md#u-15bd8cef14fb) · Transforms a full component analysis into a client-side ESTree.Program containing one exported component function.
            - [Client Transform State Types](nodes/r6-transform-client-types.md) (11 units)
              - [ClientTransformState](nodes/r6-transform-client-types.md#u-e21a2406661b) · Interface extending TransformState with `in_constructor`, `in_derived`, `is_instance` flags and a `transform` record whose per-name entry has a required `read` (identifier to signal read, e.g. `$.get(foo)`) and optional `assign`, `mutate`, and `update` rewriters.
          - [Server Transform \(SSR\)](nodes/r6-transform-server.md) (10 units)
            - [packages/svelte/src/compiler/phases/3-transform/server/visitors/AwaitBlock.js:AwaitBlock](nodes/r6-transform-server.md#u-8619e1ace336) · Emits server code for an {#await} block as a `$.await($$payload, expression, pendingThunk, thenArrow)` statement appended to the template.
        - [Compiler Infrastructure](nodes/r6-compiler-infra.md) (18 units)
          - [MappedCode](nodes/r6-compiler-infra.md#u-3b244745bdc8) · Mutable string-plus-decoded-sourcemap pair used to build generated code with accurate mappings, supporting in-place concatenation and construction from raw or preprocessed text.
      - [Client Runtime](nodes/r6-runtime-client.md) (0 units)
        - [Client Reactivity Core](nodes/r6-client-reactivity.md) (17 units)
          - [deriveds-js-async-derived](nodes/r6-client-reactivity.md#u-ad60e0aa2daf) · Creates an async derived: an async_effect calls fn(), tracking signals read while accessing the promise's then, and publishes settled results into a Source via internal_set.
        - [Dev-Mode Diagnostics](nodes/r6-client-dev.md) (3 units)
          - [tracing.js-reactive-tracing](nodes/r6-client-dev.md#u-fb7046392fad) · Dev-time tracing of reactive reads and updates.
        - [DOM Template Blocks](nodes/r6-client-dom-blocks.md) (10 units)
          - [css_props](nodes/r6-client-dom-blocks.md#u-c71adbe36cde) · Keeps a div or g element's inline CSS custom properties in sync with a reactive style record.
        - [Element Effects and Transitions](nodes/r6-client-dom-elements.md) (10 units)
          - [autofocus](nodes/r6-client-dom-elements.md#u-7f00a79795f4) · Applies autofocus imperatively: when value is true it sets dom.autofocus and queues a micro task that calls dom.focus() only if the body is still the active element, i.e. the user has not already focused something else.
        - [Legacy Component Lifecycle](nodes/r6-client-dom-legacy.md) (2 units)
          - [packages/svelte/src/internal/client/dom/legacy/lifecycle.js:init (2)](nodes/r6-client-dom-legacy.md#u-805336ae6185) · Legacy-mode hook installer: reads the current `ComponentContextLegacy` from `component_context`, and if it has legacy callbacks (`context.l.u`), wires `beforeUpdate`, `onMount`, and `afterUpdate`.
        - [Task Scheduling](nodes/r6-client-dom-task.md) (5 units)
          - [flush_tasks](nodes/r6-client-dom-task.md#u-f61b99082e8c) · Synchronously drains both queues: micro tasks first, then idle tasks, each only if non-empty.
      - [Server Runtime](nodes/r6-runtime-server.md) (10 units)
        - [abort](nodes/r6-runtime-server.md#u-9654b4650543) · Abort any active server-side abort controller and reset module state so subsequent renders start clean.
      - [Shared Utilities and Tests](nodes/r6-shared-infra.md) (21 units)
        - [deferred](nodes/r6-shared-infra.md#u-3c5ab59ed010) · Creates an externally-resolvable promise: returns `{ promise, resolve, reject }` where promise is a new Promise whose executor captures the resolve/reject functions into the returned object.
      - [Stores, Motion, and Reactive Values](nodes/r6-stores-motion-reactivity.md) (0 units)
        - [Store Contract](nodes/r6-stores.md) (6 units)
          - [writable](nodes/r6-stores.md#u-dc45d71b793b) · Creates a Writable store holding value, with an optional start notifier (default noop) invoked with set and update when the first subscriber arrives.
        - [Spring Motion](nodes/r6-motion.md) (4 units)
          - [packages/svelte/src/motion/spring.js:Spring](nodes/r6-motion.md#u-6e9a0bc3364a) · Reactive spring class whose current value animates toward its target using spring physics: it holds #current/#target plus #stiffness (0.15), #damping (0.8), and #precision (0.01) as reactive state signals.
        - [Reactive Browser Values](nodes/r6-reactive-values.md) (2 units)
          - [index.js-window-values](nodes/r6-reactive-values.md#u-ed447951421e) · Reactive views of window state, each a `ReactiveValue` whose read function returns the live value in the browser and `undefined` on the server (guarded by the `BROWSER` flag).
  - [Public Typing and Reactive/Motion Libraries](nodes/public-typing-and-reactive-libs.md) (0 units)
    - [Svelte Codebase](nodes/r4-svelte-codebase.md) (0 units)
      - [Benchmark Harness](nodes/r4-benchmark-harness.md) (11 units)
        - [run.js module code (L1–L55)](nodes/r4-benchmark-harness.md#u-8a0ea15faff6) · Top-level driver that runs all benchmark suites sequentially and prints aggregated timings.
      - [Compiler Pipeline](nodes/r4-compiler.md) (0 units)
        - [Error Message Templates](nodes/r4-compiler-error-templates.md) (3 units)
          - [packages/svelte/scripts/process-messages/templates/server-errors.js:CODE](nodes/r4-compiler-error-templates.md#u-85f7bd54b8a3) · Template for generated server error functions that always throw unconditionally (no DEV branch).
        - [Template Parsing \(Phase 1\)](nodes/r4-template-parsing.md) (13 units)
          - [get_comment_handlers](nodes/r4-template-parsing.md#u-4bea7fd815cc) · Returns the `onComment`/`add_comments` pair used to give Acorn comment awareness, needed for `svelte-ignore` support and comment preservation.
        - [Semantic Analysis \(Phase 2\)](nodes/r4-compile-analysis.md) (0 units)
          - [CSS Analysis](nodes/r4-css-analysis.md) (10 units)
            - [analyze_css](nodes/r4-css-analysis.md#u-f762711e5ae7) · Entry point for CSS analysis of a component stylesheet: builds a CssState sharing analysis.css.keyframes, with rule null and the component analysis, then walks the stylesheet with the module's css_visitors.
          - [JS and Template Visitors](nodes/r4-analysis-visitors.md) (17 units)
            - [CallExpression](nodes/r4-analysis-visitors.md#u-d254c72e4204) · Analyzes call expressions, validating rune usage placement and argument counts per rune, tracking analysis flags, and recording call/state purity metadata.
        - [Code Generation \(Phase 3\)](nodes/r4-codegen-transform.md) (0 units)
          - [Client Transform](nodes/r4-client-transform.md) (24 units)
            - [fix_attribute_casing](nodes/r4-client-transform.md#u-799dccdfecc2) · Maps an attribute name to its canonical SVG casing when one exists.
          - [Server Transform](nodes/r4-server-transform.md) (7 units)
            - [packages/svelte/src/compiler/phases/3-transform/server/visitors/SvelteHead.js:SvelteHead](nodes/r4-server-transform.md#u-9e86d472de3c) · Renders `<svelte:head>` by visiting its fragment and pushing `$.head($$payload, ($$payload) => block)` into the template, deferring head content rendering to the runtime.
          - [CSS Transform](nodes/r4-css-transform.md) (13 units)
            - [escape_comment_close](nodes/r4-css-transform.md#u-8e64579cb2b1) · Escapes '*/' sequences inside a rule so wrapping it in a block comment cannot terminate early.
        - [Compiler Shared Infrastructure](nodes/r4-compiler-infra.md) (23 units)
          - [builders-js-trivial-node-builders](nodes/r4-compiler-infra.md#u-b83c295c759f) · This group covers the one-line ESTree node factory helpers in builders.js — array, array_pattern, assignment_pattern, assignment, await (await_builder), binary, block, labeled, unary, conditional, logical, declaration, declarator, export_default, for_of, function_declaration, id, private_id, import_namespace, init, literal, member, member_id, object, object_pattern, prop, prop_def, rest, sequence, stmt, template, update, do_while, let_builder, const_builder, var_builder, for_builder, if_builder, return_builder, and the shared constants void0/empty/true/false/null/this/debugger.
      - [Runtime](nodes/r4-runtime.md) (0 units)
        - [Reactive Batch Scheduling](nodes/r4-reactivity-scheduling.md) (17 units)
          - [Batch](nodes/r4-reactivity-scheduling.md#u-43c969fbb82e) · Groups source updates so effects flush once against consistent values.
        - [Client DOM Blocks](nodes/r4-client-dom-blocks.md) (11 units)
          - [async](nodes/r4-client-dom-blocks.md#u-0ce28dacb587) · Renders an async block's contents once its awaited expressions resolve, tracking pending count on the enclosing boundary.
        - [Element Bindings and Styles](nodes/r4-element-bindings.md) (12 units)
          - [bind_active_element](nodes/r4-element-bindings.md#u-63ddea66ca81) · Binds document.activeElement changes to a callback by listening for focusin/focusout on document.
        - [Client Dev Tooling](nodes/r4-client-dev-tools.md) (4 units)
          - [hmr](nodes/r4-client-dev-tools.md#u-0e08a21e78a3) · Wraps a component for hot module replacement: hmr(original, get_source) returns a wrapper component that renders the current component from a reactive source and re-creates it on update.
        - [Client Entry and Lifecycle](nodes/r4-client-entry.md) (10 units)
          - [index-client-js-entry-points](nodes/r4-client-entry.md#u-6341627de73d) · Client entry module re-exporting the runtime API and defining lifecycle helpers.
        - [Server Runtime](nodes/r4-server-runtime.md) (12 units)
          - [packages/svelte/src/server/index.d.ts:render](nodes/r4-server-runtime.md#u-d452e617d953) · Type declaration of the server-only render entry: takes a component (wrapped in ComponentType when it is a SvelteComponent) and an options object with optional props (omitting $$slots/$$events), context map, and idPrefix.
        - [Runtime Shared Helpers](nodes/r4-runtime-shared.md) (16 units)
          - [packages/svelte/src/internal/shared/attributes.js:append_styles](nodes/r4-runtime-shared.md#u-83334ed78d84) · Joins a style-name/value record into a CSS declaration string.
        - [Legacy Compatibility \(Server\)](nodes/r4-legacy-compat.md) (2 units)
          - [packages/svelte/src/legacy/legacy-server.js:asClassComponent (2)](nodes/r4-legacy-compat.md#u-ad399b19be02) · Server-side counterpart of `asClassComponent`: converts a Svelte 5 component into a Svelte-4-style class constructor by delegating to the client implementation, then attaches a `render` method for SSR.
      - [Reactive Built-in Wrappers](nodes/r4-reactivity-library.md) (7 units)
        - [SvelteDate](nodes/r4-reactivity-library.md#u-cb648e924acc) · A reactive subclass of Date whose time value is a state source; reads through Date getter/toString methods in effects or deriveds re-run when the time changes.
      - [Motion Library](nodes/r4-motion-library.md) (4 units)
        - [index.js module code (L1–L32)](nodes/r4-motion-library.md#u-fe5771212e14) · Re-exports the spring and tweened motion modules and exposes prefersReducedMotion, a reactive MediaQuery signal matching the CSS '(prefers-reduced-motion: reduce)' query, constructed eagerly at module load.
      - [Public API Type Surface](nodes/r4-public-api-types.md) (18 units)
        - [index-d-ts-action-types](nodes/r4-public-api-types.md#u-774be8a3c591) · Types for `svelte/action`: an Action is a function invoked when an element is created, optionally taking a parameter (the parameter argument is optional only when `undefined extends Parameter`), returning void or an ActionReturn whose optional `update` runs on parameter change and `destroy` runs on unmount.
  - [Build and Packaging](nodes/build-and-packaging.md) (0 units)
    - [Svelte framework](nodes/r2-svelte.md) (0 units)
      - [Compiler](nodes/r2-compiler.md) (0 units)
        - [Template parser](nodes/r2-parse.md) (19 units)
          - [Parser](nodes/r2-parse.md#u-e466b0264ad6) · Character-level parser for Svelte templates that drives a state machine over the raw template string and produces an AST.Root.
        - [CSS pruning analysis](nodes/r2-css-prune.md) (18 units)
          - [prune](nodes/r2-css-prune.md#u-41775043a205) · Walks a stylesheet and marks which selectors actually match a given element, so unused CSS can be pruned.
        - [Client code generation](nodes/r2-client-transform.md) (0 units)
          - [Client transform visitors](nodes/r2-client-visitors.md) (9 units)
            - [Program](nodes/r2-client-visitors.md#u-ba1f8c9b6c22) · Installs the top-level read/assign/mutate/update transforms for `$$props`, legacy reactive imports, store subscriptions, and prop/bindable props before continuing traversal.
          - [Client signal builders](nodes/r2-client-signal-builders.md) (20 units)
            - [utils.js module code (L1–L23)](nodes/r2-client-signal-builders.md#u-0360a1447240) · Import block for builders, AST helpers, prop flag constants, dev state, walk, and validate_mutation; no runtime behavior beyond module loading.
          - [Shared transform utilities](nodes/r2-transform-shared.md) (7 units)
            - [clean_nodes](nodes/r2-transform-shared.md#u-2ed26069223c) · Splits a fragment's nodes into hoisted items and whitespace-trimmed regular nodes.
        - [Server element serialization](nodes/r2-server-element-transform.md) (1 units)
          - [packages/svelte/src/compiler/phases/3-transform/server/visitors/RegularElement.js:RegularElement](nodes/r2-server-element-transform.md#u-7055b95dd599) · Renders a regular element's opening tag, attributes, children, and closing tag into the template.
        - [Diagnostics, state and validation infrastructure](nodes/r2-compiler-infrastructure.md) (15 units)
          - [compile-diagnostic-js-module-region](nodes/r2-compiler-infrastructure.md#u-4c4cd0899c53) · This group covers the CompileDiagnostic module's file-level support code: the `regex_tabs` pattern, `tabs_to_spaces` (replaces each leading tab run with two spaces per tab, used to align code frames that mix tabs and spaces), and `get_code_frame(source, line, column)` (formats a snippet of two lines before through three after the given zero-based line; each line is prefixed with its right-aligned 1-based number and colon, tabs expanded to spaces, and the error line additionally gets a following line with a `^` marker positioned under the column after tab expansion).
        - [Compiler type surface](nodes/r2-compiler-types.md) (5 units)
          - [index.d.ts-compiler-result-and-options](nodes/r2-compiler-types.md#u-10040b416e26) · Type declarations for the compiler's public surface.
      - [Client runtime](nodes/r2-client-runtime.md) (2 units)
        - [disclose-version.js module code (L1–L6)](nodes/r2-client-runtime.md#u-ea8222e99174) · Discloses the library version to devtools when the module is first loaded.
        - [Reactivity core](nodes/r2-reactivity-core.md) (16 units)
          - [runtime.js-module-state-setters](nodes/r2-reactivity-core.md#u-ac602620d878) · Module-level reactive-system state and its trivial writers.
        - [Async reactivity](nodes/r2-async-reactivity.md) (8 units)
          - [StaleReactionError](nodes/r2-async-reactivity.md#u-40a134e2a457) · Instantiates an Error subclass whose instance is exported as STALE_REACTION, the rejection reason for aborted async reaction signals.
        - [Component context](nodes/r2-component-context.md) (11 units)
          - [context.js-dev-state-setters](nodes/r2-component-context.md#u-beb31e6973ea) · Three exported setters maintain module-level development/introspection state in context.js: set_component_context replaces the global component_context slot, set_dev_stack replaces the global dev_stack slot, and set_dev_current_component_function replaces the dev_current_component_function slot.
        - [Store integration](nodes/r2-store-integration.md) (20 units)
          - [store-js-setup-stores](nodes/r2-store-integration.md#u-543bcc42ec11) · setup_stores creates an empty StoreReferencesContainer and a cleanup function.
        - [DOM elements, events and bindings](nodes/r2-dom-elements.md) (16 units)
          - [packages/svelte/src/internal/client/dom/blocks/svelte-element.js:element](nodes/r2-dom-elements.md#u-165ac079f0d2) · Renders a dynamic-tag element, switching the created element when the tag changes and managing outro/resume of the previous element's effect.
      - [Server renderer](nodes/r2-server-render.md) (30 units)
        - [escape_html](nodes/r2-server-render.md#u-0f499dd45547) · Escapes HTML-special characters in a value for safe interpolation into markup or attribute strings.
      - [Public authoring API and typings](nodes/r2-public-api.md) (7 units)
        - [index-js-easing-functions](nodes/r2-public-api.md#u-418ed383b520) · Easing functions that map a progress value t (conventionally 0..1) to an eased progress value, used by animations and transitions.
      - [Build and repo tooling](nodes/r2-build-tooling.md) (10 units)
        - [rollup-config-js](nodes/r2-build-tooling.md#u-ba39a0ffd5bc) · Defines the single Rollup build for the Svelte compiler, emitting a minified UMD bundle.
      - [Reactivity benchmarks](nodes/r2-benchmarks.md) (2 units)
        - [kairo_avoidable-js](nodes/r2-benchmarks.md#u-a018922f0d70) · Builds a five-deep derived chain whose recomputation is intentionally avoidable, then times 1000 full re-runs of that chain.
  - [Benchmarks and Developer Environment](nodes/tooling-and-dev-env.md) (0 units)
    - [Svelte Monorepo](nodes/r3-svelte-monorepo.md) (2 units)
      - [misc.js-legacy-helpers](nodes/r3-svelte-monorepo.md#u-3c3f0a7bb39a) · Runtime helpers for legacy (`componentApi === 4`) component behavior.
      - [Compiler](nodes/r3-compiler.md) (0 units)
        - [Parse Utilities](nodes/r3-parse-utilities.md) (9 units)
          - [create_fragment](nodes/r3-parse-utilities.md#u-6f16c2773335) · Builds a fresh, empty AST Fragment node.
        - [Component Analysis](nodes/r3-analysis-core.md) (17 units)
          - [index-js-analyze-component](nodes/r3-analysis-core.md#u-ff1515d9bcd2) · Full analysis of a Svelte component root into a ComponentAnalysis, spanning scope creation, legacy store-subscription handling, runes-mode decision, visitor walks, prop/export classification, and final template/CSS fixups.
        - [Scope and Node Model](nodes/r3-scope-node-model.md) (14 units)
          - [scope.js-create-scopes-visitor](nodes/r3-scope-node-model.md#u-cbb081ea695c) · create_scopes walks the AST with zimmerframe to build the scope tree: it creates a non-porous root Scope, collects identifier references, assignment/update targets, and `$:` implicit declarations during the walk, then post-processes them so declarations are registered before references are attached.
        - [Accessibility Checks](nodes/r3-a11y-checks.md) (5 units)
          - [index.js-check-element](nodes/r3-a11y-checks.md#u-7ec766147486) · Runs every accessibility warning for one RegularElement or SvelteElement during analysis; it is the shared entry point invoked by the RegularElement and SvelteElement visitors.
        - [Code Generation Transforms](nodes/r3-code-generation-transform.md) (0 units)
          - [Client Transform](nodes/r3-client-transform.md) (13 units)
            - [packages/svelte/src/compiler/phases/3-transform/client/visitors/AssignmentExpression.js:AssignmentExpression](nodes/r3-client-transform.md#u-180b0678e181) · Transforms assignment expressions by delegating to the shared assignment walker with this module's build_assignment, falling back to default traversal when no rewrite applies, then wrapping the result in mutation validation.
          - [Server Transform](nodes/r3-server-transform.md) (10 units)
            - [packages/svelte/src/compiler/phases/3-transform/server/visitors/MemberExpression.js:MemberExpression](nodes/r3-server-transform.md#u-21f5ba0822c6) · Rewrites private-field reads of $derived class fields in runes mode.
        - [Svelte 4 AST Converter](nodes/r3-legacy-ast-compat.md) (2 units)
          - [legacy.js-convert-modern-ast-to-svelte-4-shape](nodes/r3-legacy-ast-compat.md#u-b18e2937a7a3) · Group the Svelte-4 compatibility AST converter: `convert` walks the modern AST with zimmerframe, deleting `metadata` everywhere and replacing node types/shapes with their legacy equivalents via per-node-type handlers.
        - [Diagnostic Code Templates](nodes/r3-diagnostics-templates.md) (5 units)
          - [CODE](nodes/r3-diagnostics-templates.md#u-96149b5e3a32) · Template for generated client error functions that never return.
      - [Client Runtime](nodes/r3-runtime.md) (0 units)
        - [Effect Engine](nodes/r3-effects-engine.md) (22 units)
          - [effects.js-effect-creators](nodes/r3-effects-engine.md#u-27c9c7c4069f) · One-line effect constructor wrappers, all delegating to `create_effect` with different flag combinations.
        - [DOM Template Factories](nodes/r3-dom-template-factories.md) (13 units)
          - [from_html](nodes/r3-dom-template-factories.md#u-7aedb33d1cff) · Builds a factory for HTML templates.
        - [Element Bindings, Actions, and Custom Elements](nodes/r3-element-bindings.md) (13 units)
          - [action](nodes/r3-element-bindings.md#u-e8c39de2a586) · Runs a Svelte action on an element inside a root effect, wiring reactive value updates and teardown.
        - [Component Mounting](nodes/r3-component-mounting.md) (6 units)
          - [packages/svelte/src/internal/client/render.js:mount](nodes/r3-component-mounting.md#u-1879cc967524) · Public mount entry point: delegates entirely to `_mount`, so mounting plays intro transitions by default (unless `options.intro` is false) and returns the component's exported API.
        - [Client Error Boundaries](nodes/r3-client-error-handling.md) (4 units)
          - [handle_error](nodes/r3-client-error-handling.md#u-1b3b4fa2c18e) · Central handler for errors raised during effect execution.
        - [Svelte 4 Client Compatibility](nodes/r3-legacy-client-runtime.md) (6 units)
          - [Svelte4Component](nodes/r3-legacy-client-runtime.md#u-f604417484a2) · Svelte 4-compatible component wrapper that runs a Svelte 5 component and exposes legacy instance APIs ($set, $on, $destroy, exported instance properties).
        - [Reactive Primitives and Stores](nodes/r3-reactive-primitives.md) (5 units)
          - [createSubscriber](nodes/r3-reactive-primitives.md#u-44838dbc4415) · Creates a subscribe function that bridges external event systems into Svelte's reactive graph.
        - [Public API Surface and Types](nodes/r3-public-api.md) (9 units)
          - [index-server-js-stubs](nodes/r3-public-api.md#u-529cfef18850) · Server entry module exporting no-op and unavailable client APIs.
      - [Tooling and Developer Environment](nodes/r3-tooling.md) (0 units)
        - [Reactivity Benchmarks](nodes/r3-reactivity-benchmarks.md) (5 units)
          - [kairo_broad-js](nodes/r3-reactivity-benchmarks.md#u-90d8b37ebf5a) · Fans one state signal out to 50 independent two-step derived chains and times updates that every branch must recompute.
        - [Dev Environment Configuration](nodes/r3-dev-environment.md) (4 units)
          - [ssr-dev.js module code (L1–L39)](nodes/r3-dev-environment.md#u-00b4d70b764d) · Runs a Vite-middleware dev server rendering App.svelte on each request.

## Reading stats

- units: 1264 · semantic nodes: 145 · dispositioned inventory ids: 4988
- source ranges are program-derived from the inventory, never model-written

## Graph coverage

Source: static analysis graph. Resolved relations are graph-confirmed; this does not guarantee semantic correctness. External targets are outside the repository; ambiguous targets have multiple candidates. Unresolved or unsupported relations, and languages or relation kinds without coverage, rely on model inference and may be inaccurate.
Import and call status ratios use the edge count of each kind. CFG and dataflow are structural edges; only their counts are shown, without status ratios.
javascript import: resolved 1256/2267 (55%), unresolved 674/2267 (30%), external 337/2267 (15%) · javascript call: resolved 3192/15643 (20%), ambiguous 1078/15643 (7%), unresolved 4739/15643 (30%), external 6634/15643 (42%).
javascript structural edges: cfg=245262, dataflow=50000.
typescript import: resolved 33/41 (80%), unresolved 8/41 (20%) · typescript call: no edges.
typescript structural edges: cfg=0, dataflow=0.
Incomplete capabilities: javascript/call partial; javascript/dataflow partial; typescript/call partial; typescript/dataflow partial.
Program checks: dangling edges 0; nodes outside manifest 0; nodes with missing files 0.

## Overview

This is the Svelte monorepo. Its responsibilities split into a compiler pipeline (parse → analyze → client/server transforms, plus Svelte 4→5 migration codemods), client and server runtimes that execute compiled output, public typing and reactive/motion libraries that authors import, and non-shipping build/tooling (benchmarks, lint, treeshake verification, playground scripts). The root node 'svelte-monorepo' groups these facets; several region groupings (r1-* through r6-*) describe the same codebase at different cuts, so most maintenance questions have multiple valid entry nodes.

Compiler: 'compiler-and-migration' owns the phases. Parsing appears as 'r2-parse', 'r4-template-parsing', and 'r1-compiler-parse' (options validation, CSS grammar, TS stripping). Analysis and validation policy lives in 'r1-compiler-analyze-visitors'/'r1-compiler-analyze-shared-utils', 'r5-analyze-phase', 'r3-analysis-core', and 'r4-css-analysis'. Code generation is 'r1-compiler-transform-client'/'r1-compiler-transform-server' with 'r1-compiler-transform-shared' for assignment rewriting, plus the r2/r3/r4/r5 equivalents. Diagnostics are centralized in 'r1-compiler-diagnostics' and 'r5-warnings-codegen'; scope/binding infrastructure shared by analysis and both transforms is 'r3-scope-node-model'; 'r5-compiler-utilities' is the consumer-agnostic helper library. Migration codemods are 'r5-svelte-migration'.

Runtime: 'runtime-and-shared-infra' covers execution. Signal machinery appears as 'r5-runtime-reactivity', 'r2-reactivity-core', and 'r3-effects-engine'; DOM realization as 'r5-runtime-dom', 'r2-dom-elements', 'r3-dom-template-factories'; batching as 'r4-reactivity-scheduling'; async context as 'r2-async-reactivity'; component context as 'r2-component-context'; store bridging as 'r2-store-integration'; mounting and boundaries as 'r3-component-mounting' and 'r1-client-boundaries'; SSR as 'r1-server-runtime'/'r2-server-render'. Shared helpers are 'r1-shared-internals' and 'r4-runtime-shared'.

Public surface and tooling: 'r4-public-api-types' (declarations), 'r4-reactivity-library'/'r5-reactive-builtins' (reactive wrappers), 'r4-motion-library' (Spring/Tween), 'r6-stores'. Build/packaging is 'build-and-packaging' with 'r2-build-tooling'; measurement and dev environment is 'tooling-and-dev-env' with 'r1-tooling-treeshake', 'r1-tooling-lint', and the benchmark nodes. Cooperation pattern: transform visitors emit calls into runtime helpers, reactive wrappers funnel mutations through runtime source machinery, motion schedules frames through the client loop, and tooling verifies or measures compiler output without shipping.

## Maintenance navigation

Start at 'svelte-monorepo' to pick a facet, then descend to the most specific matching node.

Parsing: template text → AST is 'r2-parse' or 'r4-template-parsing'; CSS grammar 'r1-compiler-parse-style'; <svelte:options> rules 'r1-compiler-parse-options'; fragment/entity/fuzzy helpers 'r3-parse-utilities'. Preprocessing and source maps: 'r1-compiler-preprocess'; sourcemap code building and ignore comments: 'r6-compiler-infra'.

Analysis and diagnostics: validation policy changes land in 'r1-compiler-analyze-shared-utils'; node-specific checks in 'r1-compiler-analyze-visitors' or 'r5-analyze-phase'. Scope, bindings, and rune resolution: 'r3-scope-node-model' (a dependency of analysis, a11y checks, and both transform passes, so changes ripple widely). Accessibility rules: 'r3-a11y-checks'. CSS scoping and pruning: 'r4-css-analysis' then 'r4-css-transform'. Error codes and InternalCompileError: 'r1-compiler-diagnostics'; warning-generation templates: 'r5-warnings-codegen'; compile state and option validation: 'r2-compiler-infrastructure'.

Code generation: client output 'r1-compiler-transform-client' (or 'r5-client-transform' for template/fragment helpers, 'r2-client-visitors' with 'r2-client-signal-builders' for signal expressions); SSR output 'r1-compiler-transform-server' (or 'r5-server-transform' for payload serialization, 'r2-server-element-transform' for element tags). Shared assignment semantics: 'r1-compiler-transform-shared'. Migration codemods: 'r5-svelte-migration'; legacy AST conversion: 'r3-legacy-ast-compat'.

Runtime: signal read/write semantics — 'r5-runtime-reactivity' or 'r2-reactivity-core'; effect lifecycle — 'r3-effects-engine'; derived evaluation — 'r6-client-reactivity'; batching/flushSync — 'r4-reactivity-scheduling'; async context across awaits — 'r2-async-reactivity'; component context — 'r2-component-context'; store bridging — 'r2-store-integration'. DOM: each blocks and bindings 'r5-runtime-dom'; events/media 'r2-dom-elements'; element bindings and custom elements 'r3-element-bindings'; template cloning 'r3-dom-template-factories'. Mount/hydrate/unmount: 'r3-component-mounting'; boundaries: 'r1-client-boundaries'. SSR: 'r2-server-render' or 'r1-server-runtime'; server context/abort: 'r6-runtime-server'. Shared helpers: 'r1-shared-internals' or 'r4-runtime-shared'. Svelte 4 compat: 'r3-legacy-client-runtime' and 'r4-legacy-compat'.

Public surface: declarations 'r4-public-api-types'; rune ambient types 'r1-public-runes-types'; element typings 'r6-public-dom-typings'; reactive wrappers 'r4-reactivity-library' or 'r5-reactive-builtins'; motion 'r4-motion-library' or 'r5-animation-helpers'; stores 'r6-stores'.

Tooling: treeshake gate 'r1-tooling-treeshake'; lint 'r1-tooling-lint'; benchmarks 'r5-benchmarks', 'r3-reactivity-benchmarks', 'r6-benchmarking', or harness 'r4-benchmark-harness'; packaging/message generation 'r2-build-tooling'; playground 'r5-playground-sandbox' or 'r1-tooling-playground'. For cross-boundary changes (e.g. a new $. runtime call emitted by a visitor), open the emitting transform node and the runtime implementation node together; the dependency list records which pairs cooperate.

## Dependency view

Arrows point from a user to its dependency. Containment is structural, not a dependency. Graph-confirmed pairs appear in both the tree and resolved call/import edges. Model-inferred pairs appear only in the tree. Graph-only pairs appear only in the graph.
Graph-confirmed and model-inferred pairs count edges between two subtrees. Graph-only pairs count edges between direct node owners. Containment rows show resolved edges between ancestor direct units and a descendant subtree in both directions. Within containment rows count direct owner pairs separately. Neither kind of containment row appears in Mermaid or the three dependency totals.

```mermaid
flowchart LR
  n0["Effect Engine"]
  n1["Compiler Utilities and AST Helpers"]
  n2["Reactivity core"]
  n3["Client transform visitors"]
  n4["Scope and Node Model"]
  n5["Client Runtime"]
  n6["Client Runtime Reactivity"]
  n7["Shared Utilities and Tests"]
  n8["DOM elements#44; events and bindings"]
  n9["Element Bindings#44; Actions#44; and Custom Elements"]
  n10["Reactive Batch Scheduling"]
  n11["Client Transform"]
  n12["Client Runtime DOM"]
  n13["Dev-Mode Diagnostics"]
  n14["Compiler Pipeline and Migration"]
  n8 --> n2
  n0 --> n9
  n9 --> n0
  n11 --> n1
  n12 --> n6
  n6 ==> n2
  n12 ==> n0
  n12 ==> n5
  n4 ==> n1
  n8 ==> n0
  n0 ==> n2
  n3 ==> n1
  n10 ==> n2
  n6 ==> n13
  n8 ==> n9
  n3 ==> n11
```

Selected 15 nodes by connection count. Legend: `-->` graph-confirmed; `-.->` model-inferred; `==>` graph-only.

## Dependency list

- [Build and Packaging](nodes/build-and-packaging.md) → [Benchmarks and Developer Environment](nodes/tooling-and-dev-env.md) · graph-confirmed · 53 edge(s) · Sandbox/playground packaging scripts share the dev-environment configuration and benchmark workloads.
- [Compiler Pipeline and Migration](nodes/compiler-and-migration.md) → [Build and Packaging](nodes/build-and-packaging.md) · graph-confirmed · 67 edge(s)
- [Compiler Pipeline and Migration](nodes/compiler-and-migration.md) → [Client/Server Runtime and Shared Infrastructure](nodes/runtime-and-shared-infra.md) · graph-confirmed · 54 edge(s) · Compiler transforms emit calls into the client and server runtimes, so generated code's runtime behavior is implemented in the runtime-and-shared-infra subtree.
- [Public Typing and Reactive/Motion Libraries](nodes/public-typing-and-reactive-libs.md) → [Client/Server Runtime and Shared Infrastructure](nodes/runtime-and-shared-infra.md) · graph-confirmed · 29 edge(s) · Reactive wrappers and springs build on the internal signal/source machinery and shared runtime helpers.
- [Boundaries & Async Blocks](nodes/r1-client-boundaries.md) → [Client Runtime](nodes/r1-client-runtime.md) · graph-confirmed · 5 edge(s)
- [Analysis Visitors](nodes/r1-compiler-analyze-visitors.md) → [Analysis Shared Validation](nodes/r1-compiler-analyze-shared-utils.md) · graph-confirmed · 12 edge(s) · Analysis visitors delegate shared validation invariants (assignment legality, identifier naming, block emptiness, purity) to the shared helpers.
- [Analysis Visitors](nodes/r1-compiler-analyze-visitors.md) → [Compiler Diagnostics](nodes/r1-compiler-diagnostics.md) · model-inferred · 0 edge(s)
- [Parse Phase](nodes/r1-compiler-parse.md) → [Compiler Diagnostics](nodes/r1-compiler-diagnostics.md) · model-inferred · 0 edge(s)
- [svelte:options Reading](nodes/r1-compiler-parse-options.md) → [Compiler Diagnostics](nodes/r1-compiler-diagnostics.md) · model-inferred · 0 edge(s)
- [Preprocessing & Sourcemaps](nodes/r1-compiler-preprocess.md) → [Svelte Compiler](nodes/r1-compiler.md) · containment · → 0 / ← 0 edge(s) (ancestor direct units and descendant subtree; → follows ` r1-compiler-preprocess ` → ` r1-compiler `)
- [Client Transform Visitors](nodes/r1-compiler-transform-client.md) → [Client Runtime](nodes/r1-client-runtime.md) · model-inferred · 0 edge(s)
- [Client Transform Visitors](nodes/r1-compiler-transform-client.md) → [Shared Assignment Rewriting](nodes/r1-compiler-transform-shared.md) · model-inferred · 0 edge(s)
- [Server Transform \(SSR\)](nodes/r1-compiler-transform-server.md) → [Shared Assignment Rewriting](nodes/r1-compiler-transform-shared.md) · graph-confirmed · 1 edge(s) · The server transform reuses the shared assignment rewriter so reactive assignment semantics match the client target.
- [Server Transform \(SSR\)](nodes/r1-compiler-transform-server.md) → [Server Runtime \(SSR\)](nodes/r1-server-runtime.md) · model-inferred · 0 edge(s)
- [Reactive Collections & Motion](nodes/r1-public-reactivity-motion.md) → [Client Runtime](nodes/r1-client-runtime.md) · graph-confirmed · 2 edge(s)
- [Server Runtime \(SSR\)](nodes/r1-server-runtime.md) → [Shared Internals](nodes/r1-shared-internals.md) · model-inferred · 0 edge(s)
- [Shared Internals](nodes/r1-shared-internals.md) → [Compiler Diagnostics](nodes/r1-compiler-diagnostics.md) · model-inferred · 0 edge(s)
- [Reactivity Benchmarks](nodes/r1-tooling-benchmarks.md) → [Client Runtime](nodes/r1-client-runtime.md) · model-inferred · 0 edge(s)
- [Treeshakeability Verification](nodes/r1-tooling-treeshake.md) → [Client Transform Visitors](nodes/r1-compiler-transform-client.md) · model-inferred · 0 edge(s) · Treeshakeability verification bundles the compiler's client exports and probes the client transform output for residual code.
- [Async reactivity](nodes/r2-async-reactivity.md) → [Component context](nodes/r2-component-context.md) · graph-confirmed · 3 edge(s) · Async reactivity capture/unset reads and resets component-context state and runes-mode detection across await boundaries.
- [Async reactivity](nodes/r2-async-reactivity.md) → [Reactivity core](nodes/r2-reactivity-core.md) · graph-confirmed · 4 edge(s)
- [Build and repo tooling](nodes/r2-build-tooling.md) → [Client transform visitors](nodes/r2-client-visitors.md) · graph-confirmed · 2 edge(s)
- [Client transform visitors](nodes/r2-client-visitors.md) → [Client signal builders](nodes/r2-client-signal-builders.md) · graph-confirmed · 4 edge(s) · Client visitors construct emitted runtime call expressions (getters, prop sources, deriveds) through the signal builders.
- [Client transform visitors](nodes/r2-client-visitors.md) → [Diagnostics, state and validation infrastructure](nodes/r2-compiler-infrastructure.md) · graph-confirmed · 1 edge(s)
- [Client transform visitors](nodes/r2-client-visitors.md) → [Shared transform utilities](nodes/r2-transform-shared.md) · graph-confirmed · 2 edge(s)
- [Diagnostics, state and validation infrastructure](nodes/r2-compiler-infrastructure.md) → [Template parser](nodes/r2-parse.md) · model-inferred · 0 edge(s)
- [DOM elements, events and bindings](nodes/r2-dom-elements.md) → [Component context](nodes/r2-component-context.md) · model-inferred · 0 edge(s)
- [DOM elements, events and bindings](nodes/r2-dom-elements.md) → [Reactivity core](nodes/r2-reactivity-core.md) · graph-confirmed · 4 edge(s)
- [Public authoring API and typings](nodes/r2-public-api.md) → [DOM elements, events and bindings](nodes/r2-dom-elements.md) · model-inferred · 0 edge(s)
- [Reactivity core](nodes/r2-reactivity-core.md) → [Component context](nodes/r2-component-context.md) · graph-confirmed · 7 edge(s)
- [Server element serialization](nodes/r2-server-element-transform.md) → [Shared transform utilities](nodes/r2-transform-shared.md) · graph-confirmed · 2 edge(s) · The SSR element visitor reuses the shared fragment-cleaning and namespace-inference helpers also used by the client element visitor.
- [Store integration](nodes/r2-store-integration.md) → [Reactivity core](nodes/r2-reactivity-core.md) · graph-confirmed · 1 edge(s) · store_get reads store-backed state through the reactivity core's get.
- [Shared transform utilities](nodes/r2-transform-shared.md) → [Client signal builders](nodes/r2-client-signal-builders.md) · model-inferred · 0 edge(s)
- [Accessibility Checks](nodes/r3-a11y-checks.md) → [Parse Utilities](nodes/r3-parse-utilities.md) · graph-confirmed · 2 edge(s)
- [Accessibility Checks](nodes/r3-a11y-checks.md) → [Scope and Node Model](nodes/r3-scope-node-model.md) · model-inferred · 0 edge(s)
- [Component Analysis](nodes/r3-analysis-core.md) → [Accessibility Checks](nodes/r3-a11y-checks.md) · graph-confirmed · 1 edge(s)
- [Component Analysis](nodes/r3-analysis-core.md) → [Scope and Node Model](nodes/r3-scope-node-model.md) · graph-confirmed · 16 edge(s) · Component analysis dispatches over scopes and bindings created by the scope/node model, which also feeds a11y checks and both transform passes.
- [Client Transform](nodes/r3-client-transform.md) → [Scope and Node Model](nodes/r3-scope-node-model.md) · graph-confirmed · 9 edge(s)
- [Client Transform](nodes/r3-client-transform.md) → [Server Transform](nodes/r3-server-transform.md) · model-inferred · 0 edge(s)
- [Component Mounting](nodes/r3-component-mounting.md) → [DOM Template Factories](nodes/r3-dom-template-factories.md) · graph-confirmed · 1 edge(s)
- [Component Mounting](nodes/r3-component-mounting.md) → [Effect Engine](nodes/r3-effects-engine.md) · graph-confirmed · 2 edge(s) · Mount and hydrate create the component root through the effect engine's effect creators.
- [Effect Engine](nodes/r3-effects-engine.md) → [Element Bindings, Actions, and Custom Elements](nodes/r3-element-bindings.md) · graph-confirmed · 1 edge(s)
- [Element Bindings, Actions, and Custom Elements](nodes/r3-element-bindings.md) → [DOM Template Factories](nodes/r3-dom-template-factories.md) · graph-confirmed · 1 edge(s)
- [Element Bindings, Actions, and Custom Elements](nodes/r3-element-bindings.md) → [Effect Engine](nodes/r3-effects-engine.md) · graph-confirmed · 8 edge(s) · Bindings and the custom-element class run their reactive updates inside effects created by the effect engine.
- [Element Bindings, Actions, and Custom Elements](nodes/r3-element-bindings.md) → [Svelte 4 Client Compatibility](nodes/r3-legacy-client-runtime.md) · graph-confirmed · 1 edge(s)
- [Svelte 4 Client Compatibility](nodes/r3-legacy-client-runtime.md) → [Component Mounting](nodes/r3-component-mounting.md) · graph-confirmed · 1 edge(s)
- [Svelte 4 Client Compatibility](nodes/r3-legacy-client-runtime.md) → [Effect Engine](nodes/r3-effects-engine.md) · graph-confirmed · 1 edge(s)
- [Reactive Primitives and Stores](nodes/r3-reactive-primitives.md) → [Effect Engine](nodes/r3-effects-engine.md) · graph-confirmed · 5 edge(s)
- [Server Transform](nodes/r3-server-transform.md) → [Scope and Node Model](nodes/r3-scope-node-model.md) · graph-confirmed · 7 edge(s)
- [Client DOM Blocks](nodes/r4-client-dom-blocks.md) → [Reactive Batch Scheduling](nodes/r4-reactivity-scheduling.md) · graph-confirmed · 2 edge(s)
- [Client Transform](nodes/r4-client-transform.md) → [Compiler Shared Infrastructure](nodes/r4-compiler-infra.md) · model-inferred · 0 edge(s)
- [Client Transform](nodes/r4-client-transform.md) → [Reactive Batch Scheduling](nodes/r4-reactivity-scheduling.md) · model-inferred · 0 edge(s)
- [CSS Analysis](nodes/r4-css-analysis.md) → [Compiler Shared Infrastructure](nodes/r4-compiler-infra.md) · graph-confirmed · 1 edge(s)
- [CSS Transform](nodes/r4-css-transform.md) → [Compiler Shared Infrastructure](nodes/r4-compiler-infra.md) · graph-confirmed · 2 edge(s)
- [CSS Transform](nodes/r4-css-transform.md) → [CSS Analysis](nodes/r4-css-analysis.md) · model-inferred · 0 edge(s)
- [Element Bindings and Styles](nodes/r4-element-bindings.md) → [Reactive Batch Scheduling](nodes/r4-reactivity-scheduling.md) · model-inferred · 0 edge(s)
- [Element Bindings and Styles](nodes/r4-element-bindings.md) → [Runtime Shared Helpers](nodes/r4-runtime-shared.md) · graph-confirmed · 1 edge(s)
- [Legacy Compatibility \(Server\)](nodes/r4-legacy-compat.md) → [Client Entry and Lifecycle](nodes/r4-client-entry.md) · model-inferred · 0 edge(s)
- [Motion Library](nodes/r4-motion-library.md) → [Reactive Built-in Wrappers](nodes/r4-reactivity-library.md) · model-inferred · 0 edge(s)
- [Public API Type Surface](nodes/r4-public-api-types.md) → [Compiler Pipeline](nodes/r4-compiler.md) · model-inferred · 0 edge(s)
- [Public API Type Surface](nodes/r4-public-api-types.md) → [Motion Library](nodes/r4-motion-library.md) · model-inferred · 0 edge(s)
- [Public API Type Surface](nodes/r4-public-api-types.md) → [Reactive Built-in Wrappers](nodes/r4-reactivity-library.md) · model-inferred · 0 edge(s)
- [Public API Type Surface](nodes/r4-public-api-types.md) → [Runtime](nodes/r4-runtime.md) · model-inferred · 0 edge(s)
- [Reactive Built-in Wrappers](nodes/r4-reactivity-library.md) → [Reactive Batch Scheduling](nodes/r4-reactivity-scheduling.md) · model-inferred · 0 edge(s)
- [Server Runtime](nodes/r4-server-runtime.md) → [Runtime Shared Helpers](nodes/r4-runtime-shared.md) · model-inferred · 0 edge(s)
- [Template Parsing \(Phase 1\)](nodes/r4-template-parsing.md) → [Compiler Shared Infrastructure](nodes/r4-compiler-infra.md) · graph-confirmed · 1 edge(s)
- [Analyze-Phase Visitors](nodes/r5-analyze-phase.md) → [Compiler Utilities and AST Helpers](nodes/r5-compiler-utilities.md) · graph-confirmed · 16 edge(s)
- [Reactivity and SSR Benchmarks](nodes/r5-benchmarks.md) → [Compiler Public API and Pipeline](nodes/r5-compiler-pipeline.md) · model-inferred · 0 edge(s)
- [Client Transform](nodes/r5-client-transform.md) → [Analyze-Phase Visitors](nodes/r5-analyze-phase.md) · model-inferred · 0 edge(s)
- [Client Transform](nodes/r5-client-transform.md) → [Compiler Utilities and AST Helpers](nodes/r5-compiler-utilities.md) · graph-confirmed · 10 edge(s)
- [Compiler Public API and Pipeline](nodes/r5-compiler-pipeline.md) → [Client Transform](nodes/r5-client-transform.md) · containment · → 0 / ← 0 edge(s) (ancestor direct units and descendant subtree; → follows ` r5-compiler-pipeline ` → ` r5-client-transform `)
- [Compiler Public API and Pipeline](nodes/r5-compiler-pipeline.md) → [Server \(SSR\) Transform](nodes/r5-server-transform.md) · containment · → 0 / ← 0 edge(s) (ancestor direct units and descendant subtree; → follows ` r5-compiler-pipeline ` → ` r5-server-transform `)
- [Playground Sandbox](nodes/r5-playground-sandbox.md) → [Compiler Public API and Pipeline](nodes/r5-compiler-pipeline.md) · model-inferred · 0 edge(s)
- [Reactive Built-ins](nodes/r5-reactive-builtins.md) → [Client Runtime Reactivity](nodes/r5-runtime-reactivity.md) · graph-confirmed · 35 edge(s) · SvelteMap and SvelteURL back their mutations with sources, state, and set from the client reactivity core.
- [Client Runtime DOM](nodes/r5-runtime-dom.md) → [Client Runtime Reactivity](nodes/r5-runtime-reactivity.md) · graph-confirmed · 6 edge(s)
- [Svelte 4 to 5 Migration](nodes/r5-svelte-migration.md) → [Analyze-Phase Visitors](nodes/r5-analyze-phase.md) · model-inferred · 0 edge(s)
- [Svelte 4 to 5 Migration](nodes/r5-svelte-migration.md) → [Compiler Utilities and AST Helpers](nodes/r5-compiler-utilities.md) · graph-confirmed · 10 edge(s)
- [Warning Codegen Template](nodes/r5-warnings-codegen.md) → [Compiler Public API and Pipeline](nodes/r5-compiler-pipeline.md) · model-inferred · 0 edge(s)
- [Reactivity Benchmarks](nodes/r6-benchmarking.md) → [Client Reactivity Core](nodes/r6-client-reactivity.md) · model-inferred · 0 edge(s)
- [DOM Template Blocks](nodes/r6-client-dom-blocks.md) → [Task Scheduling](nodes/r6-client-dom-task.md) · model-inferred · 0 edge(s)
- [DOM Template Blocks](nodes/r6-client-dom-blocks.md) → [Client Reactivity Core](nodes/r6-client-reactivity.md) · model-inferred · 0 edge(s)
- [Element Effects and Transitions](nodes/r6-client-dom-elements.md) → [Task Scheduling](nodes/r6-client-dom-task.md) · graph-confirmed · 2 edge(s)
- [Element Effects and Transitions](nodes/r6-client-dom-elements.md) → [Shared Utilities and Tests](nodes/r6-shared-infra.md) · graph-confirmed · 1 edge(s)
- [Legacy Component Lifecycle](nodes/r6-client-dom-legacy.md) → [Client Reactivity Core](nodes/r6-client-reactivity.md) · graph-confirmed · 1 edge(s)
- [Legacy Component Lifecycle](nodes/r6-client-dom-legacy.md) → [Shared Utilities and Tests](nodes/r6-shared-infra.md) · graph-confirmed · 2 edge(s)
- [Task Scheduling](nodes/r6-client-dom-task.md) → [Shared Utilities and Tests](nodes/r6-shared-infra.md) · graph-confirmed · 2 edge(s)
- [Client Reactivity Core](nodes/r6-client-reactivity.md) → [Dev-Mode Diagnostics](nodes/r6-client-dev.md) · graph-confirmed · 1 edge(s)
- [Compiler Pipeline](nodes/r6-compiler.md) → [Compiler Infrastructure](nodes/r6-compiler-infra.md) · containment · → 0 / ← 0 edge(s) (ancestor direct units and descendant subtree; → follows ` r6-compiler ` → ` r6-compiler-infra `)
- [Semantic Analysis](nodes/r6-compiler-analyze.md) → [CSS Scoping Analysis](nodes/r6-compiler-analyze-css.md) · containment · → 0 / ← 0 edge(s) (ancestor direct units and descendant subtree; → follows ` r6-compiler-analyze ` → ` r6-compiler-analyze-css `)
- [Semantic Analysis](nodes/r6-compiler-analyze.md) → [Compiler Infrastructure](nodes/r6-compiler-infra.md) · graph-confirmed · 1 edge(s)
- [Template Parsing](nodes/r6-compiler-parse.md) → [Compiler AST Declarations](nodes/r6-compiler-ast-types.md) · model-inferred · 0 edge(s)
- [Code Generation](nodes/r6-compiler-transform.md) → [Semantic Analysis](nodes/r6-compiler-analyze.md) · model-inferred · 0 edge(s)
- [Spring Motion](nodes/r6-motion.md) → [Dev-Mode Diagnostics](nodes/r6-client-dev.md) · graph-confirmed · 7 edge(s)
- [Spring Motion](nodes/r6-motion.md) → [Shared Utilities and Tests](nodes/r6-shared-infra.md) · graph-confirmed · 1 edge(s)
- [Spring Motion](nodes/r6-motion.md) → [Store Contract](nodes/r6-stores.md) · graph-confirmed · 1 edge(s)
- [Reactive Browser Values](nodes/r6-reactive-values.md) → [Dev-Mode Diagnostics](nodes/r6-client-dev.md) · graph-confirmed · 1 edge(s)
- [Server Runtime](nodes/r6-runtime-server.md) → [Shared Utilities and Tests](nodes/r6-shared-infra.md) · model-inferred · 0 edge(s)
- [Store Contract](nodes/r6-stores.md) → [Shared Utilities and Tests](nodes/r6-shared-infra.md) · graph-confirmed · 1 edge(s)
- [Client Transform](nodes/r6-transform-client.md) → [Client Transform State Types](nodes/r6-transform-client-types.md) · containment · → 0 / ← 0 edge(s) (ancestor direct units and descendant subtree; → follows ` r6-transform-client ` → ` r6-transform-client-types `)
- [Client/Server Runtime and Shared Infrastructure](nodes/runtime-and-shared-infra.md) → [Compiler Pipeline and Migration](nodes/compiler-and-migration.md) · graph-confirmed · 60 edge(s)
- [Client/Server Runtime and Shared Infrastructure](nodes/runtime-and-shared-infra.md) → [Public Typing and Reactive/Motion Libraries](nodes/public-typing-and-reactive-libs.md) · graph-confirmed · 43 edge(s)
- [Svelte Monorepo](nodes/svelte-monorepo.md) → [Compiler Pipeline and Migration](nodes/compiler-and-migration.md) · containment · → 0 / ← 0 edge(s) (ancestor direct units and descendant subtree; → follows ` svelte-monorepo ` → ` compiler-and-migration `)
- [Svelte Monorepo](nodes/svelte-monorepo.md) → [Client/Server Runtime and Shared Infrastructure](nodes/runtime-and-shared-infra.md) · containment · → 0 / ← 0 edge(s) (ancestor direct units and descendant subtree; → follows ` svelte-monorepo ` → ` runtime-and-shared-infra `)
- [Benchmarks and Developer Environment](nodes/tooling-and-dev-env.md) → [Compiler Pipeline and Migration](nodes/compiler-and-migration.md) · graph-confirmed · 107 edge(s)
- [Client Transform Visitors](nodes/r1-compiler-transform-client.md) → [Client Transform](nodes/r5-client-transform.md) · graph-only · 25 edge(s)
- [Client DOM Blocks](nodes/r4-client-dom-blocks.md) → [Effect Engine](nodes/r3-effects-engine.md) · graph-only · 24 edge(s)
- [Reactive Built-ins](nodes/r5-reactive-builtins.md) → [Reactivity core](nodes/r2-reactivity-core.md) · graph-only · 21 edge(s)
- [Client Runtime Reactivity](nodes/r5-runtime-reactivity.md) → [Reactivity core](nodes/r2-reactivity-core.md) · graph-only · 20 edge(s)
- [Reactive Built-ins](nodes/r5-reactive-builtins.md) → [Dev-Mode Diagnostics](nodes/r6-client-dev.md) · graph-only · 18 edge(s)
- [DOM Template Factories](nodes/r3-dom-template-factories.md) → [Client Runtime DOM](nodes/r5-runtime-dom.md) · graph-only · 17 edge(s)
- [Client DOM Blocks](nodes/r4-client-dom-blocks.md) → [Client Runtime](nodes/r1-client-runtime.md) · graph-only · 16 edge(s)
- [Client Runtime DOM](nodes/r5-runtime-dom.md) → [Effect Engine](nodes/r3-effects-engine.md) · graph-only · 16 edge(s)
- [Template Parsing](nodes/r6-compiler-parse.md) → [Template Parsing \(Phase 1\)](nodes/r4-template-parsing.md) · graph-only · 16 edge(s)
- [Client Transform](nodes/r3-client-transform.md) → [Client Transform](nodes/r5-client-transform.md) · graph-only · 15 edge(s)
- [Reactive Primitives and Stores](nodes/r3-reactive-primitives.md) → [Client Runtime Reactivity](nodes/r5-runtime-reactivity.md) · graph-only · 15 edge(s)
- [Client Runtime DOM](nodes/r5-runtime-dom.md) → [Client Runtime](nodes/r1-client-runtime.md) · graph-only · 15 edge(s)
- [Scope and Node Model](nodes/r3-scope-node-model.md) → [Compiler Utilities and AST Helpers](nodes/r5-compiler-utilities.md) · graph-only · 14 edge(s)
- [Reactivity Benchmarks](nodes/r6-benchmarking.md) → [Benchmark Harness](nodes/r4-benchmark-harness.md) · graph-only · 14 edge(s)
- [Client Transform](nodes/r6-transform-client.md) → [Client signal builders](nodes/r2-client-signal-builders.md) · graph-only · 14 edge(s)
- [Boundaries & Async Blocks](nodes/r1-client-boundaries.md) → [Effect Engine](nodes/r3-effects-engine.md) · graph-only · 13 edge(s)
- [DOM elements, events and bindings](nodes/r2-dom-elements.md) → [Effect Engine](nodes/r3-effects-engine.md) · graph-only · 13 edge(s)
- [Effect Engine](nodes/r3-effects-engine.md) → [Reactivity core](nodes/r2-reactivity-core.md) · graph-only · 13 edge(s)
- [Reactive Primitives and Stores](nodes/r3-reactive-primitives.md) → [Reactivity core](nodes/r2-reactivity-core.md) · graph-only · 13 edge(s)
- [JS and Template Visitors](nodes/r4-analysis-visitors.md) → [Compiler Utilities and AST Helpers](nodes/r5-compiler-utilities.md) · graph-only · 13 edge(s)
- [Client transform visitors](nodes/r2-client-visitors.md) → [Compiler Utilities and AST Helpers](nodes/r5-compiler-utilities.md) · graph-only · 12 edge(s)
- [Reactive Batch Scheduling](nodes/r4-reactivity-scheduling.md) → [Reactivity core](nodes/r2-reactivity-core.md) · graph-only · 12 edge(s)
- [Client Runtime Reactivity](nodes/r5-runtime-reactivity.md) → [Dev-Mode Diagnostics](nodes/r6-client-dev.md) · graph-only · 12 edge(s)
- [Template Parsing](nodes/r6-compiler-parse.md) → [Parse Utilities](nodes/r3-parse-utilities.md) · graph-only · 12 edge(s)
- [Preprocessing & Sourcemaps](nodes/r1-compiler-preprocess.md) → [Compiler Infrastructure](nodes/r6-compiler-infra.md) · graph-only · 11 edge(s)
- [DOM elements, events and bindings](nodes/r2-dom-elements.md) → [Element Bindings, Actions, and Custom Elements](nodes/r3-element-bindings.md) · graph-only · 11 edge(s)
- [Component Analysis](nodes/r3-analysis-core.md) → [Compiler Utilities and AST Helpers](nodes/r5-compiler-utilities.md) · graph-only · 11 edge(s)
- [Template Parsing \(Phase 1\)](nodes/r4-template-parsing.md) → [Scope and Node Model](nodes/r3-scope-node-model.md) · graph-only · 11 edge(s)
- [Reactivity and SSR Benchmarks](nodes/r5-benchmarks.md) → [Benchmark Harness](nodes/r4-benchmark-harness.md) · graph-only · 11 edge(s)
- [Semantic Analysis](nodes/r6-compiler-analyze.md) → [Compiler Utilities and AST Helpers](nodes/r5-compiler-utilities.md) · graph-only · 11 edge(s)
- [Client Transform](nodes/r6-transform-client.md) → [Scope and Node Model](nodes/r3-scope-node-model.md) · graph-only · 11 edge(s)
- [Analysis Visitors](nodes/r1-compiler-analyze-visitors.md) → [Compiler Utilities and AST Helpers](nodes/r5-compiler-utilities.md) · graph-only · 10 edge(s)
- [Client transform visitors](nodes/r2-client-visitors.md) → [Client Transform](nodes/r3-client-transform.md) · graph-only · 10 edge(s)
- [Client transform visitors](nodes/r2-client-visitors.md) → [Client Transform](nodes/r5-client-transform.md) · graph-only · 10 edge(s)
- [Server Transform](nodes/r3-server-transform.md) → [Compiler Utilities and AST Helpers](nodes/r5-compiler-utilities.md) · graph-only · 10 edge(s)
- [Element Bindings and Styles](nodes/r4-element-bindings.md) → [Effect Engine](nodes/r3-effects-engine.md) · graph-only · 10 edge(s)
- [DOM Template Blocks](nodes/r6-client-dom-blocks.md) → [Effect Engine](nodes/r3-effects-engine.md) · graph-only · 10 edge(s)
- [DOM Template Blocks](nodes/r6-client-dom-blocks.md) → [Client Runtime DOM](nodes/r5-runtime-dom.md) · graph-only · 10 edge(s)
- [Reactive Collections & Motion](nodes/r1-public-reactivity-motion.md) → [Client Runtime Reactivity](nodes/r5-runtime-reactivity.md) · graph-only · 9 edge(s)
- [Reactivity Benchmarks](nodes/r1-tooling-benchmarks.md) → [Benchmark Harness](nodes/r4-benchmark-harness.md) · graph-only · 9 edge(s)

Graph-only pairs are ranked by edge count; 311 omitted.

### Within containment

- [Attribute Synchronization](nodes/r1-client-attributes.md) → [Client Runtime](nodes/r1-client-runtime.md) · within containment · 4 edge(s)

Within containment: 1 pairs, ranked by edge count; 0 omitted. Each graph list keeps at most 40 pairs independently.

## Key flows

- **Reactive read executes a derived** · A tracked read of a reactive wrapper goes through the runtime get into derived execution and then the reaction update loop, consulting runes-mode context state.
  [SvelteURL](nodes/r5-reactive-builtins.md#u-d8aa9c46c2fa) → [packages/svelte/src/internal/client/runtime.js:get](nodes/r2-reactivity-core.md#u-98099fbbf12a) → [execute\_derived](nodes/r6-client-reactivity.md#u-193107029d03) → [update\_reaction](nodes/r2-reactivity-core.md#u-f6b808e008e3) → [is\_runes](nodes/r2-component-context.md#u-71aba13a168a) → (model-inferred) → [context.js-dev-state-setters](nodes/r2-component-context.md#u-beb31e6973ea)
- **Dirty checking and derived updates** · After a read, flushed inspect effects check staleness via is_dirty and recompute values through update_derived, touching module reactive state.
  [SvelteURL](nodes/r5-reactive-builtins.md#u-d8aa9c46c2fa) → [packages/svelte/src/internal/client/runtime.js:get](nodes/r2-reactivity-core.md#u-98099fbbf12a) → [execute\_derived](nodes/r6-client-reactivity.md#u-193107029d03) → [flush\_inspect\_effects](nodes/r5-runtime-reactivity.md#u-8313e354c312) → [is\_dirty](nodes/r2-reactivity-core.md#u-6236bf4a1a35) → [update\_derived](nodes/r6-client-reactivity.md#u-637b94af51bf)
- **Stale derived effect teardown** · Re-executing a derived destroys its old effects, unwinding teardown, child destruction, reaction removal, and DOM cleanup.
  [SvelteURL](nodes/r5-reactive-builtins.md#u-d8aa9c46c2fa) → [packages/svelte/src/internal/client/runtime.js:get](nodes/r2-reactivity-core.md#u-98099fbbf12a) → [execute\_derived](nodes/r6-client-reactivity.md#u-193107029d03) → [destroy\_derived\_effects](nodes/r6-client-reactivity.md#u-a30c1fdac161) → [destroy\_effect](nodes/r3-effects-engine.md#u-214ad59ce57a) → [execute\_effect\_teardown](nodes/r3-effects-engine.md#u-e4bc784214d0)
- **Effect unlinking and DOM removal** · The same teardown path removes accumulated DOM changes and detaches the effect from the graph, ending with reaction removal bookkeeping.
  [SvelteURL](nodes/r5-reactive-builtins.md#u-d8aa9c46c2fa) → [packages/svelte/src/internal/client/runtime.js:get](nodes/r2-reactivity-core.md#u-98099fbbf12a) → [execute\_derived](nodes/r6-client-reactivity.md#u-193107029d03) → [destroy\_derived\_effects](nodes/r6-client-reactivity.md#u-a30c1fdac161) → [destroy\_effect](nodes/r3-effects-engine.md#u-214ad59ce57a) → [remove\_effect\_dom](nodes/r3-effects-engine.md#u-92a1603726c9) → (model-inferred) → [remove\_reactions](nodes/r2-reactivity-core.md#u-b457a655a682)
- **Effect update and untracked reads** · During effect updates the runtime consults tracing and effect-tracking state; untrack and snapshot provide untracked reads and value snapshots.
  [SvelteURL](nodes/r5-reactive-builtins.md#u-d8aa9c46c2fa) → [packages/svelte/src/internal/client/runtime.js:get](nodes/r2-reactivity-core.md#u-98099fbbf12a) → [tracing.js-reactive-tracing](nodes/r6-client-dev.md#u-fb7046392fad) → [effect\_tracking](nodes/r3-effects-engine.md#u-c4dc07dc96fc) → (model-inferred) → [untrack](nodes/r2-reactivity-core.md#u-aa0e067da463) → (model-inferred) → [packages/svelte/src/internal/shared/clone.js:snapshot](nodes/r1-shared-internals.md#u-bfcc537be9f1)
- **Generated diagnostics factories** · Compiler errors and warnings are emitted through generated factory functions backed by the shared throw helper e and the warning filter w.
  [errors-js-generated-error-factories](nodes/r1-compiler-diagnostics.md#u-adef92463631) → [packages/svelte/src/compiler/errors.js:e](nodes/r1-compiler-diagnostics.md#u-35e148f96f15) → (model-inferred) → [warnings-js-warning-emitters](nodes/r2-compiler-infrastructure.md#u-8878846122a8) → [packages/svelte/src/compiler/warnings.js:w](nodes/r2-compiler-infrastructure.md#u-9c260d23c66a)

## Generation notes

- CBE normalized the overview after a second invalid answer: dependency_descriptions[15] removed: dependency description must name an existing pair and one sentence (<=300 characters)
- Normalized after the final invalid answer (facts kept, shape fixed): module_39, module_54, module_57, system, tree_region-0001, tree_region-0003.
- answer_fallback: module_57: accepted attempt 2 after final attempt 3 failed validation.
- module_39: CBE assigned 1 inventory symbol(s) to index_only because the model answer omitted or supplied invalid dispositions.
- module_57: CBE assigned 1 inventory symbol(s) to index_only because the model answer omitted or supplied invalid dispositions.

## Aggregation principle checks

Program diagnostics only; they do not prove semantic correctness or trigger rewrites.

### P1 · pass

```json
{"empty_or_duplicate_capabilities": [], "ok": true, "principle": "P1"}
```

### P2 · observe

```json
{"modules": {"build-and-packaging": {"external": 0, "internal": 0, "internal_external_ratio": null}, "compiler-and-migration": {"external": 0, "internal": 0, "internal_external_ratio": null}, "public-typing-and-reactive-libs": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r1-client-attributes": {"external": 44, "internal": 33, "internal_external_ratio": 0.75}, "r1-client-boundaries": {"external": 47, "internal": 22, "internal_external_ratio": 0.46808510638297873}, "r1-client-dev-dx": {"external": 26, "internal": 0, "internal_external_ratio": 0.0}, "r1-client-dev-warnings": {"external": 2, "internal": 0, "internal_external_ratio": 0.0}, "r1-client-runtime": {"external": 96, "internal": 4, "internal_external_ratio": 0.041666666666666664}, "r1-compiler": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r1-compiler-analyze": {"external": 4, "internal": 0, "internal_external_ratio": 0.0}, "r1-compiler-analyze-shared-utils": {"external": 63, "internal": 2, "internal_external_ratio": 0.031746031746031744}, "r1-compiler-analyze-visitors": {"external": 62, "internal": 2, "internal_external_ratio": 0.03225806451612903}, "r1-compiler-diagnostics": {"external": 4, "internal": 176, "internal_external_ratio": 44.0}, "r1-compiler-parse": {"external": 4, "internal": 0, "internal_external_ratio": 0.0}, "r1-compiler-parse-options": {"external": 2, "internal": 13, "internal_external_ratio": 6.5}, "r1-compiler-parse-style": {"external": 2, "internal": 48, "internal_external_ratio": 24.0}, "r1-compiler-preprocess": {"external": 18, "internal": 22, "internal_external_ratio": 1.2222222222222223}, "r1-compiler-transform": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r1-compiler-transform-client": {"external": 78, "internal": 6, "internal_external_ratio": 0.07692307692307693}, "r1-compiler-transform-server": {"external": 31, "internal": 4, "internal_external_ratio": 0.12903225806451613}, "r1-compiler-transform-shared": {"external": 9, "internal": 0, "internal_external_ratio": 0.0}, "r1-public-reactivity-motion": {"external": 33, "internal": 11, "internal_external_ratio": 0.3333333333333333}, "r1-public-runes-types": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r1-public-surface": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r1-public-type-contracts": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r1-server-runtime": {"external": 8, "internal": 6, "internal_external_ratio": 0.75}, "r1-shared-internals": {"external": 18, "internal": 6, "internal_external_ratio": 0.3333333333333333}, "r1-svelte-monorepo": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r1-tooling": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r1-tooling-benchmarks": {"external": 13, "internal": 0, "internal_external_ratio": 0.0}, "r1-tooling-lint": {"external": 0, "internal": 1, "internal_external_ratio": null}, "r1-tooling-playground": {"external": 0, "internal": 1, "internal_external_ratio": null}, "r1-tooling-treeshake": {"external": 2, "internal": 6, "internal_external_ratio": 3.0}, "r2-async-reactivity": {"external": 38, "internal": 9, "internal_external_ratio": 0.23684210526315788}, "r2-benchmarks": {"external": 16, "internal": 0, "internal_external_ratio": 0.0}, "r2-build-tooling": {"external": 3, "internal": 22, "internal_external_ratio": 7.333333333333333}, "r2-client-runtime": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r2-client-signal-builders": {"external": 57, "internal": 10, "internal_external_ratio": 0.17543859649122806}, "r2-client-transform": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r2-client-visitors": {"external": 87, "internal": 8, "internal_external_ratio": 0.09195402298850575}, "r2-compiler": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r2-compiler-infrastructure": {"external": 85, "internal": 87, "internal_external_ratio": 1.0235294117647058}, "r2-compiler-types": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r2-component-context": {"external": 39, "internal": 11, "internal_external_ratio": 0.28205128205128205}, "r2-css-prune": {"external": 13, "internal": 77, "internal_external_ratio": 5.923076923076923}, "r2-dom-elements": {"external": 65, "internal": 10, "internal_external_ratio": 0.15384615384615385}, "r2-parse": {"external": 21, "internal": 29, "internal_external_ratio": 1.380952380952381}, "r2-public-api": {"external": 3, "internal": 0, "internal_external_ratio": 0.0}, "r2-reactivity-core": {"external": 237, "internal": 30, "internal_external_ratio": 0.12658227848101267}, "r2-server-element-transform": {"external": 20, "internal": 0, "internal_external_ratio": 0.0}, "r2-server-render": {"external": 49, "internal": 19, "internal_external_ratio": 0.3877551020408163}, "r2-store-integration": {"external": 12, "internal": 2, "internal_external_ratio": 0.16666666666666666}, "r2-svelte": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r2-transform-shared": {"external": 33, "internal": 5, "internal_external_ratio": 0.15151515151515152}, "r3-a11y-checks": {"external": 22, "internal": 68, "internal_external_ratio": 3.090909090909091}, "r3-analysis-core": {"external": 85, "internal": 11, "internal_external_ratio": 0.12941176470588237}, "r3-client-error-handling": {"external": 11, "internal": 9, "internal_external_ratio": 0.8181818181818182}, "r3-client-transform": {"external": 98, "internal": 16, "internal_external_ratio": 0.16326530612244897}, "r3-code-generation-transform": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r3-compiler": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r3-component-mounting": {"external": 39, "internal": 6, "internal_external_ratio": 0.15384615384615385}, "r3-dev-environment": {"external": 3, "internal": 0, "internal_external_ratio": 0.0}, "r3-diagnostics-templates": {"external": 0, "internal": 2, "internal_external_ratio": null}, "r3-dom-template-factories": {"external": 43, "internal": 26, "internal_external_ratio": 0.6046511627906976}, "r3-effects-engine": {"external": 213, "internal": 47, "internal_external_ratio": 0.22065727699530516}, "r3-element-bindings": {"external": 76, "internal": 15, "internal_external_ratio": 0.19736842105263158}, "r3-legacy-ast-compat": {"external": 4, "internal": 8, "internal_external_ratio": 2.0}, "r3-legacy-client-runtime": {"external": 7, "internal": 2, "internal_external_ratio": 0.2857142857142857}, "r3-parse-utilities": {"external": 26, "internal": 11, "internal_external_ratio": 0.4230769230769231}, "r3-public-api": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r3-reactive-primitives": {"external": 62, "internal": 3, "internal_external_ratio": 0.04838709677419355}, "r3-reactivity-benchmarks": {"external": 12, "internal": 5, "internal_external_ratio": 0.4166666666666667}, "r3-runtime": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r3-scope-node-model": {"external": 178, "internal": 64, "internal_external_ratio": 0.3595505617977528}, "r3-server-transform": {"external": 38, "internal": 17, "internal_external_ratio": 0.4473684210526316}, "r3-svelte-monorepo": {"external": 6, "internal": 0, "internal_external_ratio": 0.0}, "r3-tooling": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r4-analysis-visitors": {"external": 53, "internal": 11, "internal_external_ratio": 0.20754716981132076}, "r4-benchmark-harness": {"external": 73, "internal": 12, "internal_external_ratio": 0.1643835616438356}, "r4-client-dev-tools": {"external": 13, "internal": 0, "internal_external_ratio": 0.0}, "r4-client-dom-blocks": {"external": 87, "internal": 11, "internal_external_ratio": 0.12643678160919541}, "r4-client-entry": {"external": 2, "internal": 19, "internal_external_ratio": 9.5}, "r4-client-transform": {"external": 50, "internal": 13, "internal_external_ratio": 0.26}, "r4-codegen-transform": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r4-compile-analysis": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r4-compiler": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r4-compiler-error-templates": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r4-compiler-infra": {"external": 24, "internal": 45, "internal_external_ratio": 1.875}, "r4-css-analysis": {"external": 10, "internal": 4, "internal_external_ratio": 0.4}, "r4-css-transform": {"external": 12, "internal": 23, "internal_external_ratio": 1.9166666666666667}, "r4-element-bindings": {"external": 35, "internal": 7, "internal_external_ratio": 0.2}, "r4-legacy-compat": {"external": 2, "internal": 0, "internal_external_ratio": 0.0}, "r4-motion-library": {"external": 6, "internal": 0, "internal_external_ratio": 0.0}, "r4-public-api-types": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r4-reactivity-library": {"external": 15, "internal": 2, "internal_external_ratio": 0.13333333333333333}, "r4-reactivity-scheduling": {"external": 61, "internal": 15, "internal_external_ratio": 0.2459016393442623}, "r4-runtime": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r4-runtime-shared": {"external": 24, "internal": 5, "internal_external_ratio": 0.20833333333333334}, "r4-server-runtime": {"external": 17, "internal": 4, "internal_external_ratio": 0.23529411764705882}, "r4-server-transform": {"external": 48, "internal": 0, "internal_external_ratio": 0.0}, "r4-svelte-codebase": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r4-template-parsing": {"external": 66, "internal": 25, "internal_external_ratio": 0.3787878787878788}, "r5-analyze-phase": {"external": 68, "internal": 7, "internal_external_ratio": 0.10294117647058823}, "r5-animation-helpers": {"external": 0, "internal": 3, "internal_external_ratio": null}, "r5-benchmarks": {"external": 21, "internal": 2, "internal_external_ratio": 0.09523809523809523}, "r5-client-transform": {"external": 142, "internal": 47, "internal_external_ratio": 0.33098591549295775}, "r5-compiler-pipeline": {"external": 24, "internal": 12, "internal_external_ratio": 0.5}, "r5-compiler-utilities": {"external": 265, "internal": 14, "internal_external_ratio": 0.052830188679245285}, "r5-playground-sandbox": {"external": 1, "internal": 1, "internal_external_ratio": 1.0}, "r5-reactive-builtins": {"external": 87, "internal": 3, "internal_external_ratio": 0.034482758620689655}, "r5-runtime-dom": {"external": 132, "internal": 58, "internal_external_ratio": 0.4393939393939394}, "r5-runtime-reactivity": {"external": 187, "internal": 68, "internal_external_ratio": 0.36363636363636365}, "r5-server-transform": {"external": 14, "internal": 14, "internal_external_ratio": 1.0}, "r5-svelte-migration": {"external": 30, "internal": 49, "internal_external_ratio": 1.6333333333333333}, "r5-svelte-monorepo": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r5-warnings-codegen": {"external": 0, "internal": 2, "internal_external_ratio": null}, "r6-benchmarking": {"external": 17, "internal": 21, "internal_external_ratio": 1.2352941176470589}, "r6-client-dev": {"external": 76, "internal": 0, "internal_external_ratio": 0.0}, "r6-client-dom-blocks": {"external": 53, "internal": 6, "internal_external_ratio": 0.11320754716981132}, "r6-client-dom-elements": {"external": 30, "internal": 12, "internal_external_ratio": 0.4}, "r6-client-dom-legacy": {"external": 13, "internal": 4, "internal_external_ratio": 0.3076923076923077}, "r6-client-dom-task": {"external": 22, "internal": 6, "internal_external_ratio": 0.2727272727272727}, "r6-client-reactivity": {"external": 54, "internal": 8, "internal_external_ratio": 0.14814814814814814}, "r6-compiler": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r6-compiler-analyze": {"external": 74, "internal": 14, "internal_external_ratio": 0.1891891891891892}, "r6-compiler-analyze-css": {"external": 16, "internal": 6, "internal_external_ratio": 0.375}, "r6-compiler-ast-types": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r6-compiler-infra": {"external": 43, "internal": 22, "internal_external_ratio": 0.5116279069767442}, "r6-compiler-parse": {"external": 57, "internal": 23, "internal_external_ratio": 0.40350877192982454}, "r6-compiler-transform": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r6-motion": {"external": 32, "internal": 5, "internal_external_ratio": 0.15625}, "r6-public-dom-typings": {"external": 0, "internal": 26, "internal_external_ratio": null}, "r6-reactive-values": {"external": 3, "internal": 1, "internal_external_ratio": 0.3333333333333333}, "r6-runtime-client": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r6-runtime-server": {"external": 7, "internal": 13, "internal_external_ratio": 1.8571428571428572}, "r6-shared-infra": {"external": 23, "internal": 0, "internal_external_ratio": 0.0}, "r6-stores": {"external": 25, "internal": 8, "internal_external_ratio": 0.32}, "r6-stores-motion-reactivity": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r6-svelte-monorepo": {"external": 0, "internal": 0, "internal_external_ratio": null}, "r6-transform-client": {"external": 86, "internal": 6, "internal_external_ratio": 0.06976744186046512}, "r6-transform-client-types": {"external": 1, "internal": 0, "internal_external_ratio": 0.0}, "r6-transform-server": {"external": 36, "internal": 2, "internal_external_ratio": 0.05555555555555555}, "runtime-and-shared-infra": {"external": 0, "internal": 0, "internal_external_ratio": null}, "svelte-monorepo": {"external": 0, "internal": 0, "internal_external_ratio": null}, "tooling-and-dev-env": {"external": 0, "internal": 0, "internal_external_ratio": null}}, "ok": false, "principle": "P2", "scope": "direct primary ownership; incident cross-module edges counted at each endpoint"}
```

### P3 · observe

```json
{"bounds": [5, 30], "ok": false, "out_of_bounds": {"r1-client-dev-warnings": 1, "r1-compiler-analyze": 1, "r1-compiler-parse": 1, "r1-compiler-parse-options": 4, "r1-compiler-transform-shared": 1, "r1-public-type-contracts": 3, "r1-svelte-monorepo": 2, "r1-tooling-benchmarks": 2, "r1-tooling-lint": 2, "r1-tooling-playground": 4, "r1-tooling-treeshake": 4, "r2-benchmarks": 2, "r2-client-runtime": 2, "r2-server-element-transform": 1, "r3-client-error-handling": 4, "r3-dev-environment": 4, "r3-legacy-ast-compat": 2, "r3-svelte-monorepo": 2, "r4-client-dev-tools": 4, "r4-compiler-error-templates": 3, "r4-legacy-compat": 2, "r4-motion-library": 4, "r5-animation-helpers": 2, "r5-runtime-reactivity": 67, "r5-warnings-codegen": 3, "r6-benchmarking": 3, "r6-client-dev": 3, "r6-client-dom-legacy": 2, "r6-compiler-ast-types": 2, "r6-motion": 4, "r6-reactive-values": 2}, "principle": "P3", "scope": "nodes with directly owned units; structural ancestors excluded"}
```

### P4 · pass

```json
{"ok": true, "ownership_violations": {}, "principle": "P4"}
```

### P5 · observe

```json
{"min_dependent_modules": 2, "min_edges_per_dependent_module": 3, "note": "dependency signal only, including utilities already separated; no automatic reassignment", "ok": false, "principle": "P5", "shared_units": {"benchmarking/utils.js::function::assert::2318": {"r1-tooling-benchmarks": 7, "r2-benchmarks": 7, "r3-reactivity-benchmarks": 6, "r5-benchmarks": 6, "r6-benchmarking": 3}, "benchmarking/utils.js::function::fastest_test::2018": {"r1-tooling-benchmarks": 6, "r2-benchmarks": 6, "r3-reactivity-benchmarks": 6, "r5-benchmarks": 8, "r6-benchmarking": 14}, "grp:context.js-dev-state-setters": {"r1-client-boundaries": 2, "r2-async-reactivity": 4, "r2-reactivity-core": 9, "r4-client-dom-blocks": 6, "r6-client-dom-blocks": 2}, "grp:effects.js-effect-creators": {"r1-client-attributes": 3, "r1-client-boundaries": 6, "r1-client-dev-dx": 5, "r1-client-runtime": 1, "r1-public-reactivity-motion": 1, "r2-component-context": 2, "r2-dom-elements": 11, "r2-public-api": 2, "r2-store-integration": 2, "r3-component-mounting": 2, "r3-element-bindings": 9, "r3-legacy-client-runtime": 1, "r3-reactive-primitives": 3, "r4-client-dev-tools": 1, "r4-client-dom-blocks": 12, "r4-element-bindings": 10, "r5-runtime-dom": 8, "r6-client-dev": 3, "r6-client-dom-blocks": 7, "r6-client-dom-elements": 5, "r6-client-dom-legacy": 2, "r6-client-reactivity": 2, "r6-motion": 2}, "grp:runtime.js-module-state-setters": {"r1-client-attributes": 4, "r1-client-boundaries": 6, "r2-async-reactivity": 6, "r2-dom-elements": 6, "r3-effects-engine": 10, "r3-element-bindings": 4, "r3-legacy-client-runtime": 1, "r3-reactive-primitives": 4, "r4-client-dom-blocks": 4, "r4-reactivity-library": 3, "r4-reactivity-scheduling": 7, "r5-runtime-reactivity": 18, "r6-client-reactivity": 9}, "grp:state.js-module-level-compiler-state": {"r1-compiler-transform-client": 7, "r2-client-visitors": 2, "r3-analysis-core": 4, "r3-client-transform": 4, "r4-analysis-visitors": 1, "r4-client-transform": 4, "r5-client-transform": 2, "r5-svelte-migration": 2, "r6-transform-client": 8, "r6-transform-server": 2}, "grp:template.js-template-class": {"r1-compiler-transform-client": 7, "r2-client-visitors": 1, "r3-client-transform": 2, "r4-client-transform": 4}, "grp:tracing.js-reactive-tracing": {"r1-client-boundaries": 1, "r1-public-reactivity-motion": 3, "r2-reactivity-core": 3, "r3-reactive-primitives": 7, "r4-reactivity-library": 2, "r5-reactive-builtins": 20, "r5-runtime-reactivity": 14, "r6-client-reactivity": 2, "r6-motion": 7, "r6-reactive-values": 1}, "grp:utils.js-element-attribute-predicates": {"r1-client-attributes": 3, "r1-shared-internals": 2, "r2-client-visitors": 5, "r2-parse": 2, "r2-server-element-transform": 2, "r2-server-render": 3, "r3-a11y-checks": 2, "r3-client-transform": 2, "r3-component-mounting": 1, "r3-scope-node-model": 1, "r3-server-transform": 6, "r4-client-transform": 2, "r4-template-parsing": 3, "r5-analyze-phase": 6, "r5-client-transform": 2, "r5-svelte-migration": 3, "r6-compiler-analyze": 1}, "grp:utils.js-namespace-and-rune-predicates": {"r2-dom-elements": 1, "r2-server-render": 2, "r3-analysis-core": 4, "r3-scope-node-model": 3, "r5-analyze-phase": 4, "r5-svelte-migration": 1, "r6-compiler-analyze": 3}, "packages/svelte/src/compiler/phases/1-parse/utils/create.js::function::create_fragment::104": {"r2-parse": 2, "r4-template-parsing": 3, "r6-compiler-parse": 14}, "packages/svelte/src/compiler/phases/2-analyze/visitors/shared/fragment.js::function::mark_subtree_dynamic::83": {"r1-compiler-analyze-visitors": 7, "r3-analysis-core": 8, "r4-analysis-visitors": 5, "r5-analyze-phase": 8}, "packages/svelte/src/compiler/phases/2-analyze/visitors/shared/utils.js::function::validate_block_not_empty::4728": {"r1-compiler-analyze-visitors": 6, "r3-analysis-core": 5, "r5-analyze-phase": 2}, "packages/svelte/src/compiler/phases/2-analyze/visitors/shared/utils.js::function::validate_opening_tag::4367": {"r1-compiler-analyze-visitors": 6, "r3-analysis-core": 3, "r4-analysis-visitors": 3, "r5-analyze-phase": 2, "r6-compiler-analyze": 2}, "packages/svelte/src/compiler/phases/3-transform/client/utils.js::function::build_getter::1220": {"r2-client-visitors": 6, "r3-client-transform": 2, "r5-client-transform": 2, "r6-transform-client": 6}, "packages/svelte/src/compiler/phases/3-transform/client/utils.js::function::create_derived::8270": {"r1-compiler-transform-client": 2, "r5-client-transform": 3, "r6-transform-client": 3}, "packages/svelte/src/compiler/phases/3-transform/client/utils.js::function::should_proxy::7118": {"r3-client-transform": 3, "r4-client-transform": 2, "r6-compiler-analyze": 2, "r6-transform-client": 3}, "packages/svelte/src/compiler/phases/3-transform/client/visitors/Program.js::function::Program::378::s0": {"r1-tooling-treeshake": 1, "r2-build-tooling": 2, "r2-compiler-infrastructure": 1, "r3-dev-environment": 3, "r4-client-dev-tools": 1, "r5-playground-sandbox": 1, "r5-svelte-migration": 6, "r6-compiler-parse": 1}, "packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/element.js::function::build_attribute_value::3231": {"r1-compiler-transform-client": 5, "r2-client-visitors": 8, "r6-transform-client": 2}, "packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/utils.js::class::Memoizer::932::s0": {"r1-compiler-transform-client": 14, "r2-client-visitors": 6, "r3-client-transform": 8}, "packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/utils.js::function::build_expression::11292": {"r1-compiler-transform-client": 2, "r2-client-visitors": 2, "r3-client-transform": 4, "r6-transform-client": 3}, "packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/utils.js::function::build_attribute_value::4710": {"r1-compiler-transform-server": 2, "r2-server-element-transform": 2, "r2-server-render": 1, "r3-server-transform": 10, "r5-server-transform": 5}, "packages/svelte/src/compiler/phases/nodes.js::function::create_attribute::1509": {"r3-analysis-core": 3, "r3-server-transform": 2, "r4-template-parsing": 4, "r5-analyze-phase": 2}, "packages/svelte/src/compiler/phases/nodes.js::function::create_expression_metadata::1740": {"r3-server-transform": 2, "r4-analysis-visitors": 3, "r4-template-parsing": 9, "r6-compiler-parse": 11}, "packages/svelte/src/compiler/phases/nodes.js::function::get_name::2027": {"r1-compiler-analyze-shared-utils": 2, "r1-compiler-transform-client": 1, "r1-compiler-transform-server": 4, "r3-analysis-core": 5, "r3-client-transform": 2}, "packages/svelte/src/compiler/phases/scope.js::class::Scope::13363::s0": {"r1-compiler-transform-client": 7, "r1-tooling-treeshake": 1, "r3-analysis-core": 1, "r3-client-transform": 9, "r3-server-transform": 1, "r4-client-transform": 2, "r5-client-transform": 3, "r5-server-transform": 2, "r6-compiler-analyze": 1, "r6-transform-client": 13, "r6-transform-server": 8}, "packages/svelte/src/compiler/phases/scope.js::function::get_rune::34200": {"r1-compiler-analyze-shared-utils": 2, "r1-compiler-transform-client": 2, "r1-compiler-transform-server": 3, "r3-analysis-core": 6, "r3-client-transform": 2, "r3-server-transform": 1, "r4-analysis-visitors": 3, "r4-client-transform": 2, "r5-svelte-migration": 1, "r6-compiler-analyze": 1, "r6-transform-client": 2, "r6-transform-server": 5}, "packages/svelte/src/compiler/utils/ast.js::function::build_assignment_value::17513": {"r1-compiler-transform-server": 3, "r3-client-transform": 3}, "packages/svelte/src/compiler/utils/ast.js::function::extract_identifiers::4009": {"r1-compiler-analyze-shared-utils": 2, "r1-compiler-analyze-visitors": 3, "r1-compiler-transform-server": 2, "r2-transform-shared": 2, "r3-analysis-core": 5, "r3-scope-node-model": 9, "r4-analysis-visitors": 1, "r5-client-transform": 2, "r5-svelte-migration": 3, "r6-transform-client": 2}, "packages/svelte/src/compiler/utils/ast.js::function::extract_paths::7725": {"r1-compiler-transform-shared": 2, "r3-analysis-core": 2, "r3-client-transform": 2, "r5-client-transform": 2, "r6-transform-client": 6, "r6-transform-server": 4}, "packages/svelte/src/compiler/utils/ast.js::function::get_attribute_expression::1846": {"r1-compiler-analyze-visitors": 3, "r3-client-transform": 2, "r4-analysis-visitors": 3, "r4-template-parsing": 3, "r5-analyze-phase": 1}, "packages/svelte/src/compiler/utils/ast.js::function::is_event_attribute::2555": {"r1-compiler-analyze-visitors": 3, "r2-client-visitors": 1, "r3-a11y-checks": 2, "r3-client-transform": 4, "r3-server-transform": 1, "r5-analyze-phase": 3, "r5-client-transform": 1, "r6-compiler-analyze": 2, "r6-transform-client": 1}, "packages/svelte/src/compiler/utils/ast.js::function::is_expression_attribute::1289": {"r1-compiler-analyze-visitors": 2, "r4-analysis-visitors": 3, "r4-template-parsing": 3}, "packages/svelte/src/compiler/utils/ast.js::function::is_text_attribute::791": {"r1-compiler-analyze-visitors": 2, "r2-client-visitors": 8, "r2-compiler-infrastructure": 2, "r2-css-prune": 2, "r3-a11y-checks": 2, "r3-analysis-core": 1, "r3-client-transform": 3, "r3-server-transform": 3, "r5-analyze-phase": 3, "r5-client-transform": 1, "r5-svelte-migration": 4, "r6-compiler-analyze": 3, "r6-compiler-parse": 2, "r6-transform-client": 2}, "packages/svelte/src/compiler/utils/ast.js::function::unwrap_optional::13743": {"r1-compiler-transform-server": 3, "r4-analysis-visitors": 3, "r5-client-transform": 2}, "packages/svelte/src/compiler/utils/slot.js::function::determine_slot::181": {"r1-compiler-transform-client": 3, "r3-scope-node-model": 3, "r4-analysis-visitors": 3}, "packages/svelte/src/internal/client/dom/elements/bindings/shared.js::function::listen::550": {"r2-dom-elements": 15, "r4-element-bindings": 4, "r5-runtime-dom": 4}, "packages/svelte/src/internal/client/dom/elements/bindings/shared.js::function::without_reactive_context::908": {"r2-dom-elements": 2, "r2-reactivity-core": 2, "r3-effects-engine": 2, "r5-runtime-dom": 3, "r6-client-dom-elements": 3}, "packages/svelte/src/internal/client/dom/hydration.js::function::hydrate_next::1251": {"r1-client-boundaries": 1, "r2-dom-elements": 2, "r3-component-mounting": 2, "r3-dom-template-factories": 4, "r4-client-dom-blocks": 3, "r5-runtime-dom": 1, "r6-client-dom-blocks": 6}, "packages/svelte/src/internal/client/dom/hydration.js::function::set_hydrate_node::1099": {"r1-client-boundaries": 2, "r2-dom-elements": 2, "r3-component-mounting": 3, "r3-dom-template-factories": 2, "r4-client-dom-blocks": 4, "r5-runtime-dom": 11, "r6-client-dom-blocks": 3}, "packages/svelte/src/internal/client/dom/hydration.js::function::set_hydrating::562": {"r1-client-attributes": 5, "r2-dom-elements": 2, "r3-component-mounting": 5, "r4-client-dom-blocks": 6, "r5-runtime-dom": 3}, "packages/svelte/src/internal/client/dom/operations.js::function::create_text::2224": {"r2-dom-elements": 1, "r3-component-mounting": 2, "r3-dom-template-factories": 6, "r4-client-dom-blocks": 3, "r6-client-dom-blocks": 1}, "packages/svelte/src/internal/client/dom/operations.js::function::get_first_child::2409": {"r2-dom-elements": 1, "r3-component-mounting": 1, "r3-dom-template-factories": 10, "r4-client-dom-blocks": 1, "r6-client-dom-blocks": 6, "r6-client-dom-elements": 2}, "packages/svelte/src/internal/client/dom/task.js::function::queue_micro_task::594": {"r1-client-boundaries": 1, "r2-dom-elements": 2, "r3-reactive-primitives": 2, "r4-client-dom-blocks": 1, "r4-element-bindings": 3, "r5-runtime-dom": 1, "r6-client-dom-elements": 4}, "packages/svelte/src/internal/client/loop.js::function::loop::722::s0": {"r1-public-reactivity-motion": 4, "r6-client-dom-elements": 2, "r6-motion": 4}, "packages/svelte/src/internal/client/reactivity/batch.js::class::Batch::1920::s0": {"r1-client-boundaries": 2, "r2-reactivity-core": 4, "r3-effects-engine": 2, "r4-client-dom-blocks": 1, "r5-runtime-dom": 1, "r5-runtime-reactivity": 2, "r6-client-reactivity": 5}, "packages/svelte/src/internal/client/reactivity/effects.js::function::block::8446": {"r1-client-attributes": 2, "r1-client-boundaries": 1, "r2-dom-elements": 1, "r4-client-dev-tools": 1, "r4-client-dom-blocks": 8, "r5-runtime-dom": 1, "r6-client-dom-blocks": 4}, "packages/svelte/src/internal/client/reactivity/effects.js::function::destroy_effect::10238": {"r1-client-attributes": 3, "r1-client-boundaries": 3, "r2-dom-elements": 2, "r4-client-dev-tools": 1, "r4-client-dom-blocks": 2, "r5-runtime-dom": 2, "r6-client-dom-blocks": 1, "r6-client-reactivity": 2}, "packages/svelte/src/internal/client/reactivity/effects.js::function::pause_effect::12656": {"r1-client-boundaries": 3, "r2-dom-elements": 2, "r4-client-dom-blocks": 5, "r5-runtime-dom": 1, "r6-client-dom-blocks": 1}, "packages/svelte/src/internal/client/reactivity/sources.js::function::increment::6715": {"r1-public-reactivity-motion": 6, "r3-reactive-primitives": 7, "r5-reactive-builtins": 6}, "packages/svelte/src/internal/client/reactivity/sources.js::function::internal_set::3725": {"r1-client-boundaries": 1, "r4-client-dom-blocks": 3, "r5-runtime-dom": 2, "r6-client-reactivity": 3}, "packages/svelte/src/internal/client/reactivity/sources.js::function::set::2970": {"r2-store-integration": 1, "r3-reactive-primitives": 5, "r3-svelte-monorepo": 2, "r4-reactivity-library": 2, "r5-reactive-builtins": 19, "r6-reactive-values": 1}, "packages/svelte/src/internal/client/reactivity/sources.js::function::state::1976": {"r1-public-reactivity-motion": 5, "r3-reactive-primitives": 3, "r4-reactivity-library": 2, "r5-reactive-builtins": 13, "r6-motion": 7}, "packages/svelte/src/internal/client/runtime.js::function::get::15253": {"r1-client-boundaries": 1, "r1-public-reactivity-motion": 1, "r2-store-integration": 2, "r3-reactive-primitives": 10, "r3-svelte-monorepo": 2, "r4-client-dev-tools": 1, "r4-client-dom-blocks": 1, "r4-reactivity-library": 4, "r5-reactive-builtins": 22, "r5-runtime-dom": 2, "r5-runtime-reactivity": 3, "r6-client-dom-legacy": 2, "r6-motion": 5}, "packages/svelte/src/internal/client/runtime.js::function::untrack::20953": {"r1-client-dev-dx": 5, "r3-effects-engine": 2, "r3-element-bindings": 3, "r3-reactive-primitives": 2, "r4-client-entry": 2, "r4-element-bindings": 3, "r5-runtime-reactivity": 4, "r6-client-dev": 6, "r6-client-dom-elements": 2, "r6-client-dom-legacy": 1}, "packages/svelte/src/internal/client/runtime.js::function::update_effect::12903": {"r3-effects-engine": 3, "r4-reactivity-scheduling": 7, "r5-runtime-reactivity": 2}, "packages/svelte/src/motion/utils.js::function::is_date::54": {"r1-public-reactivity-motion": 3, "r6-motion": 3}, "packages/svelte/src/store/shared/index.js::function::get::5098": {"r3-reactive-primitives": 5, "r4-server-runtime": 6}}}
```

### P6 · pass

```json
{"modules": {"build-and-packaging": {}, "compiler-and-migration": {}, "public-typing-and-reactive-libs": {}, "r1-client-attributes": {"javascript": 17}, "r1-client-boundaries": {"javascript": 14}, "r1-client-dev-dx": {"javascript": 7}, "r1-client-dev-warnings": {"javascript": 1}, "r1-client-runtime": {"javascript": 11}, "r1-compiler": {}, "r1-compiler-analyze": {"javascript": 1}, "r1-compiler-analyze-shared-utils": {"javascript": 9}, "r1-compiler-analyze-visitors": {"javascript": 15}, "r1-compiler-diagnostics": {"javascript": 6}, "r1-compiler-parse": {"javascript": 1}, "r1-compiler-parse-options": {"javascript": 4}, "r1-compiler-parse-style": {"javascript": 14}, "r1-compiler-preprocess": {"javascript": 10}, "r1-compiler-transform": {}, "r1-compiler-transform-client": {"javascript": 17}, "r1-compiler-transform-server": {"javascript": 14}, "r1-compiler-transform-shared": {"javascript": 1}, "r1-public-reactivity-motion": {"javascript": 13}, "r1-public-runes-types": {"typescript": 8}, "r1-public-surface": {}, "r1-public-type-contracts": {"typescript": 3}, "r1-server-runtime": {"javascript": 7}, "r1-shared-internals": {"javascript": 17, "typescript": 5}, "r1-svelte-monorepo": {"typescript": 2}, "r1-tooling": {}, "r1-tooling-benchmarks": {"javascript": 2}, "r1-tooling-lint": {"javascript": 2}, "r1-tooling-playground": {"javascript": 4}, "r1-tooling-treeshake": {"javascript": 4}, "r2-async-reactivity": {"javascript": 8}, "r2-benchmarks": {"javascript": 2}, "r2-build-tooling": {"javascript": 10}, "r2-client-runtime": {"javascript": 2}, "r2-client-signal-builders": {"javascript": 20}, "r2-client-transform": {}, "r2-client-visitors": {"javascript": 9}, "r2-compiler": {}, "r2-compiler-infrastructure": {"javascript": 15}, "r2-compiler-types": {"typescript": 5}, "r2-component-context": {"javascript": 11}, "r2-css-prune": {"javascript": 18}, "r2-dom-elements": {"javascript": 16}, "r2-parse": {"javascript": 19}, "r2-public-api": {"javascript": 4, "typescript": 3}, "r2-reactivity-core": {"javascript": 16}, "r2-server-element-transform": {"javascript": 1}, "r2-server-render": {"javascript": 30}, "r2-store-integration": {"javascript": 20}, "r2-svelte": {}, "r2-transform-shared": {"javascript": 7}, "r3-a11y-checks": {"javascript": 5}, "r3-analysis-core": {"javascript": 17}, "r3-client-error-handling": {"javascript": 4}, "r3-client-transform": {"javascript": 13}, "r3-code-generation-transform": {}, "r3-compiler": {}, "r3-component-mounting": {"javascript": 6}, "r3-dev-environment": {"javascript": 4}, "r3-diagnostics-templates": {"javascript": 5}, "r3-dom-template-factories": {"javascript": 13}, "r3-effects-engine": {"javascript": 22}, "r3-element-bindings": {"javascript": 13}, "r3-legacy-ast-compat": {"javascript": 2}, "r3-legacy-client-runtime": {"javascript": 6}, "r3-parse-utilities": {"javascript": 9}, "r3-public-api": {"javascript": 2, "typescript": 7}, "r3-reactive-primitives": {"javascript": 5}, "r3-reactivity-benchmarks": {"javascript": 5}, "r3-runtime": {}, "r3-scope-node-model": {"javascript": 14}, "r3-server-transform": {"javascript": 10}, "r3-svelte-monorepo": {"javascript": 1, "typescript": 1}, "r3-tooling": {}, "r4-analysis-visitors": {"javascript": 17}, "r4-benchmark-harness": {"javascript": 11}, "r4-client-dev-tools": {"javascript": 4}, "r4-client-dom-blocks": {"javascript": 11}, "r4-client-entry": {"javascript": 10}, "r4-client-transform": {"javascript": 20, "typescript": 4}, "r4-codegen-transform": {}, "r4-compile-analysis": {}, "r4-compiler": {}, "r4-compiler-error-templates": {"javascript": 3}, "r4-compiler-infra": {"javascript": 22, "typescript": 1}, "r4-css-analysis": {"javascript": 10}, "r4-css-transform": {"javascript": 13}, "r4-element-bindings": {"javascript": 12}, "r4-legacy-compat": {"javascript": 2}, "r4-motion-library": {"javascript": 2, "typescript": 2}, "r4-public-api-types": {"typescript": 18}, "r4-reactivity-library": {"javascript": 4, "typescript": 3}, "r4-reactivity-scheduling": {"javascript": 9, "typescript": 8}, "r4-runtime": {}, "r4-runtime-shared": {"javascript": 16}, "r4-server-runtime": {"javascript": 11, "typescript": 1}, "r4-server-transform": {"javascript": 7}, "r4-svelte-codebase": {}, "r4-template-parsing": {"javascript": 13}, "r5-analyze-phase": {"javascript": 18}, "r5-animation-helpers": {"javascript": 2}, "r5-benchmarks": {"javascript": 5}, "r5-client-transform": {"javascript": 27}, "r5-compiler-pipeline": {"javascript": 8}, "r5-compiler-utilities": {"javascript": 23}, "r5-playground-sandbox": {"javascript": 5}, "r5-reactive-builtins": {"javascript": 4, "typescript": 2}, "r5-runtime-dom": {"javascript": 29}, "r5-runtime-reactivity": {"javascript": 67}, "r5-server-transform": {"javascript": 9}, "r5-svelte-migration": {"javascript": 27}, "r5-svelte-monorepo": {}, "r5-warnings-codegen": {"javascript": 3}, "r6-benchmarking": {"javascript": 3}, "r6-client-dev": {"javascript": 3}, "r6-client-dom-blocks": {"javascript": 10}, "r6-client-dom-elements": {"javascript": 10}, "r6-client-dom-legacy": {"javascript": 2}, "r6-client-dom-task": {"javascript": 5}, "r6-client-reactivity": {"javascript": 17}, "r6-compiler": {}, "r6-compiler-analyze": {"javascript": 19}, "r6-compiler-analyze-css": {"javascript": 8}, "r6-compiler-ast-types": {"typescript": 2}, "r6-compiler-infra": {"javascript": 18}, "r6-compiler-parse": {"javascript": 13}, "r6-compiler-transform": {}, "r6-motion": {"javascript": 4}, "r6-public-dom-typings": {"typescript": 19}, "r6-reactive-values": {"javascript": 2}, "r6-runtime-client": {}, "r6-runtime-server": {"javascript": 10}, "r6-shared-infra": {"javascript": 14, "typescript": 7}, "r6-stores": {"javascript": 6}, "r6-stores-motion-reactivity": {}, "r6-svelte-monorepo": {}, "r6-transform-client": {"javascript": 19}, "r6-transform-client-types": {"typescript": 11}, "r6-transform-server": {"javascript": 10}, "runtime-and-shared-infra": {}, "svelte-monorepo": {}, "tooling-and-dev-env": {}}, "ok": true, "principle": "P6", "scope": "unit counts by language; a multi-language unit contributes once per language"}
```

### P7 · re-render identical

```json
{"identical": true, "ok": null, "principle": "P7", "scope": "same run, same detail answers; cross-run stability requires replay scripts", "status": "re-render identical"}
```

Hierarchy and introduction length:

```json
{"hierarchy": {"ok": true, "requires_intermediate_above_units": 30}, "introduction_length": {"ok": true, "overlong": {}, "scope": "capability+summary characters versus descendant explain characters"}}
```
