# Reactive Primitives and Stores

**Capability.** User-facing reactivity building blocks: subscribe-on-demand bridging of external systems, reactive media queries, a reactive Set, and store interop (toStore/fromStore).

Use this subtree for the higher-level reactive APIs built on effects. createSubscriber and the store adapters create and dispose root effects as consumers come and go; SvelteSet and MediaQuery are ready-made reactive wrappers.

**Depends on.**

- [Effect Engine](r3-effects-engine.md) · graph-confirmed · 5 edge(s)
- [Client Runtime Reactivity](r5-runtime-reactivity.md) · graph-only · 15 edge(s)
- [Reactivity core](r2-reactivity-core.md) · graph-only · 13 edge(s)

Parent: [Client Runtime](r3-runtime.md)

## Units (5)

<a id="u-44838dbc4415"></a>
### `createSubscriber`

`export function createSubscriber(start)` · [packages/svelte/src/reactivity/create-subscriber.js:L54-L95][f1]

Creates a subscribe function that bridges external event systems into Svelte's reactive graph.

The returned function is a no-op unless called while an effect is tracking; otherwise it reads an internal version source and installs a render effect per caller. That render effect increments a subscriber count: the first subscriber invokes `start` (untracked) with an `update` callback that increments the version source, causing dependent effects to re-run; `start`'s return value is stored as `stop`. Each render effect's teardown defers via `queue_micro_task` before decrementing, so the count does not transiently reach zero during its own re-run; when it reaches zero, `stop` is called and the version is incremented so dependent deriveds are marked dirty on re-subscription. In DEV the version source is tagged for tracing. Errors from `start` are not caught here.

**Notes.**

- side_effect: Calling `update` from the external system increments the version source, which invalidates effects that read the subscribe function's version.
- condition: Multiple effects calling subscribe share one `start` invocation; teardown happens only when the last subscriber's deferred decrement hits zero.

calls: [source](r5-runtime-reactivity.md#u-97497b70f31b), [tracing.js-reactive-tracing](r6-client-dev.md#u-fb7046392fad), [packages/svelte/src/internal/client/runtime.js:get](r2-reactivity-core.md#u-98099fbbf12a), [untrack](r2-reactivity-core.md#u-aa0e067da463), [effects.js-effect-creators](r3-effects-engine.md#u-27c9c7c4069f), [effect_tracking](r3-effects-engine.md#u-c4dc07dc96fc), [queue_micro_task](r6-client-dom-task.md#u-996120ba9b8d), [increment](r5-runtime-reactivity.md#u-8fa6038c59d8)

**Uncertainties.**

- Behavior of `start`/`stop` invocation timing depends on runtime internals (render effect teardown scheduling) not supplied in this file.

<a id="u-1f6c2b2fc560"></a>
### `packages/svelte/src/reactivity/media-query.js:MediaQuery`

`class MediaQuery extends ReactiveValue` · [packages/svelte/src/reactivity/media-query.js:L37-L42][f2]

Reactive boolean wrapper around window.matchMedia whose current reflects whether a media query matches, with an optional server fallback.

The constructor normalizes the query: if parenthesis_regex matches (the query already contains a parenthesized part) or every whitespace/comma-separated keyword check finds the query composed only of tokens from non_parenthesized_keywords ('all','print','screen','and','or','not','only'), the query is used as-is; otherwise it is wrapped in parentheses, so 'min-width: 800px' becomes '(min-width: 800px)'. It then calls window.matchMedia(final_query) and passes a read function returning q.matches and an update subscription using on(q, 'change', update) to the ReactiveValue base. Because it touches window and matchMedia directly, construction is browser-only; during SSR the fallback value applies, so hydrated content can differ.

**Notes.**

- failure: Instantiating in an environment without window will throw a ReferenceError; the class provides no guard.
- condition: The keyword check uses split(/[\s,]+/).some(...), so 'random,screen' still matches screen and skips auto-parenthesis per the linked issue.

uses: [media-query.js module code (L1–L36)][f2]; imports: [index.js module code (L1–L1)](r2-public-api.md#u-62e73e8675dc)

**Uncertainties.**

- The base ReactiveValue contract (how read/update produce 'current') is not supplied; behavior is inferred from the constructor arguments.

<a id="u-52a0d572a7ee"></a>
### `SvelteSet`

`class SvelteSet extends Set` · [packages/svelte/src/reactivity/set.js:L47-L57][f3]

Reactive Set subclass whose reads in effects/deriveds re-run on mutation, without deep reactivity of elements.

It holds a per-element boolean Source map plus version and size states. The constructor calls super(); in DEV it wraps value in new Set(value) so invalid iterables throw the native exception before tagging the version and size states, inserts provided elements via super.add, syncs #size.v, and lazily runs #init once per process (module-level inited flag) so the class stays tree-shakable. #init patches the prototype: forEach/isDisjointFrom/isSubsetOf/isSupersetOf track the version then delegate to the Set prototype, while difference/intersection/symmetricDifference/union track the version and return a new SvelteSet of the result. #source returns state(value) when update_version still equals the constructor-time snapshot #update_version (source created within the same reaction), otherwise source(value). has returns super.has immediately for the boolean but only creates a source (initial value true, DEV-tagged) for present elements; absent elements track the version instead, so a later add re-fires. add mutates via super.add only when absent, updating size and incrementing the version, and returns this even for duplicates. delete removes the element's source and sets it to false when one exists, and updates size plus increments the version only if something was actually deleted, returning the boolean. clear no-ops when empty, clears first (for readable $inspect output), sets each source to false, clears sources, resets size, and increments the version. keys/values/entries (and Symbol.iterator via keys) track the version before returning the native iterator; size gets #size.

**Notes.**

- contract: set-like methods (union, difference, etc.) return plain new SvelteSet instances, so chaining stays reactive but identity differs from the original.

calls: [packages/svelte/src/internal/client/runtime.js:get](r2-reactivity-core.md#u-98099fbbf12a), [increment](r5-runtime-reactivity.md#u-8fa6038c59d8), [tracing.js-reactive-tracing](r6-client-dev.md#u-fb7046392fad)

**Uncertainties.**

- #init mutates SvelteSet.prototype globally on first instantiation; behavior for instances created before/after in module-reload scenarios is not visible here.
- Semantics of update_version/increment from the internal modules are inferred from call sites only.

<a id="u-49382b15058b"></a>
### `toStore`

`export function toStore(get, set)` · [packages/svelte/src/store/index-client.js:L47-L93][f4]

Creates a store backed by reactive state on the client.

It snapshots the caller's `active_effect` and `active_reaction`, reads the initial value, and builds a `writable` whose start-stop notifier, on first subscribe, detects whether the value already changed since construction (`ran = init_value !== get()`) and then, inside `effect_root`/`render_effect`, re-reads `get()` and pushes changes via `set` — skipping the first firing when nothing changed since init. The effect/reaction contexts active at `toStore` call time are restored around `effect_root` (with `finally` reinstating the previous reaction/effect), so reactivity is attributed to the creation site rather than the subscriber; `effect_root`'s teardown is returned so the store stops tracking when the last subscriber leaves. With a `set` argument the result is a Writable-shaped object (`set`, `update: fn => set(fn(get()))`, shared `subscribe`); otherwise only `subscribe` is exposed, yielding a Readable.

calls: [writable](r6-stores.md#u-dc45d71b793b), [effect_root](r3-effects-engine.md#u-188599523a26)

**Uncertainties.**

- Exact dependency tracking depends on `render_effect`/`effect_root` internals, not shown.

<a id="u-706099be4040"></a>
### `fromStore`

`export function fromStore(store)` · [packages/svelte/src/store/index-client.js:L128-L144][f4]

Wraps a store in an object whose `current` property is reactive in Svelte 5 effects.

It lazily subscribes via `createSubscriber`: on first read inside a tracking context, the store is subscribed with a callback that records the latest value and, after the initial delivery (`ran` flag), signals `update()` to invalidate; the store unsubscribe is returned as the createSubscriber teardown. The `current()` helper calls `subscribe()` when `effect_tracking()` is true and returns the cached value, otherwise falls back to a non-tracking `get(store)` for reads outside effects. If the store has a `set`, the returned object also has a `set current` that forwards to `store.set(v)`; otherwise `current` is read-only. Distinguishing writable stores by `'set' in store` means any object with a `set` property is treated as writable.

calls: [fromStore](r3-reactive-primitives.md#u-706099be4040), [createSubscriber](r3-reactive-primitives.md#u-44838dbc4415)

**Uncertainties.**

- `createSubscriber`'s start/stop and update semantics are defined outside this file.
- Detection of writability via `'set' in store` may misclassify stores exposing an unrelated `set` key.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/reactivity/create-subscriber.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/reactivity/media-query.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/reactivity/set.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/store/index-client.js
