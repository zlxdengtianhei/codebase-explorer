# Svelte Compiler

**Capability.** Turns Svelte component source into analyzed, transformed JavaScript: parsing, semantic analysis, and client/server code generation, with diagnostics and preprocessing shared across phases.

Use this subtree for all compilation work. Each phase has its own node; diagnostics and preprocessing are shared capabilities consumed by multiple phases.

**Children.**

- [Parse Phase](r1-compiler-parse.md) `r1-compiler-parse` · 1 unit(s)
- [Analyze Phase](r1-compiler-analyze.md) `r1-compiler-analyze` · 1 unit(s)
- [Transform Phase](r1-compiler-transform.md) `r1-compiler-transform` · 0 unit(s)
- [Preprocessing & Sourcemaps](r1-compiler-preprocess.md) `r1-compiler-preprocess` · 10 unit(s)
- [Compiler Diagnostics](r1-compiler-diagnostics.md) `r1-compiler-diagnostics` · 6 unit(s)

**Depended on by.**

- [Preprocessing & Sourcemaps](r1-compiler-preprocess.md) · containment · → 0 / ← 0 edge(s) (ancestor direct units and descendant subtree; → follows ` r1-compiler-preprocess ` → ` r1-compiler `)

Parent: [Svelte Monorepo](r1-svelte-monorepo.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
