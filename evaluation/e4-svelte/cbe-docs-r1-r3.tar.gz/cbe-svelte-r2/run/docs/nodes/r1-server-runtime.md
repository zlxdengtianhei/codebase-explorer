# Server Runtime (SSR)

**Capability.** Server-side runtime for compiled SSR output: raw {@html} rendering wrapped in hydration markers, payload accumulators for body and head output with per-render ID generation, and legacy payload copy/assign helpers.

Compiled server code writes into Payload/HeadPayload instances; html.js emits hydration-delimited raw HTML; server errors surface server-unavailable lifecycle functions.

**Depends on.**

- [Shared Internals](r1-shared-internals.md) · model-inferred · 0 edge(s)

**Depended on by.**

- [Server Transform \(SSR\)](r1-compiler-transform-server.md) · model-inferred · 0 edge(s)

Parent: [Svelte Monorepo](r1-svelte-monorepo.md)

## Units (7)

<a id="u-b6ffad2a2a76"></a>
### `packages/svelte/src/internal/server/blocks/html.js:html`

`export function html(value)` · [packages/svelte/src/internal/server/blocks/html.js:L7-L11][f1]

Render a raw `{@html}` value as a string wrapped in hydration comment markers.

`value` is coerced with String, nullish becoming ''. The opening marker is `<!--hash-->` in DEV (so hydration can verify the content hash) and `<!---->` in production; the closing marker is always `<!---->`. Delegates hashing to the external `hash` util.

calls: [hash](r5-compiler-utilities.md#u-a8a8fa6d6333)

<a id="u-af8d810f9167"></a>
### `lifecycle_function_unavailable`

`export function lifecycle_function_unavailable(name)` · [packages/svelte/src/internal/server/errors.js:L10-L16][f2]

Throw a Svelte-branded Error stating that the named lifecycle function is unavailable on the server.

Builds a message containing the error code 'lifecycle_function_unavailable', the function name, and a docs URL, sets error.name to 'Svelte error', and throws. Return type is never, so callers rely on it not returning.

<a id="u-0180f968bb91"></a>
### `HeadPayload`

`class HeadPayload` · [packages/svelte/src/internal/server/payload.js:L1-L9][f3]

Mutable accumulator for `<head>` output during SSR: an out array of HTML fragments, a Set of {hash, code} CSS entries, a title string, and a uid generator.

Its constructor takes all four with defaults (empty Set, empty array, '', () => '') and assigns them; field initializers run first but are immediately overwritten, so passing undefined explicitly still yields defaults except where the default parameter kicks in only for omitted args — css/out/title/uid are all assignable. Render's head assembly reads out, title, and css.

**Notes.**

- field: head.uid is set to the shared Payload uid generator by the Payload constructor, so props_id markers in head share the same counter.

uses: [Payload](r1-server-runtime.md#u-88f15d8dfda3)

<a id="u-88f15d8dfda3"></a>
### `Payload`

`class Payload` · [packages/svelte/src/internal/server/payload.js:L22-L32][f3]

Top-level server render payload collecting body output and metadata.

Fields: css Set, out array of HTML strings, uid function, select_value (undefined until a select is rendered), and a nested HeadPayload. The constructor takes an id_prefix (default '') and assigns uid = props_id_generator(id_prefix) — a counter producing `${prefix}s1`, `${prefix}s2`, ... — and shares that generator with head.uid so IDs stay unique across head and body.

calls: [props_id_generator](r1-server-runtime.md#u-059a47caefaa); uses: [HeadPayload](r1-server-runtime.md#u-0180f968bb91)

<a id="u-bbeddcad611f"></a>
### `assign_payload`

`export function assign_payload(p1, p2)` · [packages/svelte/src/internal/server/payload.js:L65-L70][f3]

Copy payload state from p2 into p1 for legacy mode: p1.out becomes a shallow copy of p2.out, while css, head, and uid are assigned by reference (head is shared, not copied, unlike copy_payload).

uses: [copy_payload](r1-server-runtime.md#u-ab7dea894e0f)

<a id="u-ab7dea894e0f"></a>
### `copy_payload`

`export function copy_payload({ out, css, head, uid })` · [packages/svelte/src/internal/server/payload.js:L43-L57][f3]

Create an independent Payload copy for legacy binding handling.

Destructures {out, css, head, uid} from the source, builds a fresh Payload, shallow-copies out into a new array and css into a new Set, and constructs a fresh HeadPayload whose out/css are likewise copied while title and uid are shared by reference. Nested objects inside out are shared, not deep-copied.

uses: [Payload](r1-server-runtime.md#u-88f15d8dfda3)

<a id="u-059a47caefaa"></a>
### `props_id_generator`

`function props_id_generator(prefix)` · [packages/svelte/src/internal/server/payload.js:L77-L80][f3]

Create a per-render ID counter: returns a closure producing `${prefix}s${n}` with n starting at 1 and incrementing on every call; not exported.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/server/blocks/html.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/server/errors.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/server/payload.js
