# CSS pruning analysis

**Capability.** Decides which CSS selectors actually match component elements so unused rules can be pruned, via a selector-matching engine over the template AST with definite/probable element-existence tracking.

Start at prune, which drives apply_selector/apply_combinator and relative_selector_might_apply_to_node. The get_* helpers supply ancestor/descendant/sibling possibilities across block structures; attribute_matches/test_attribute evaluate attribute selectors; add_to_map and has_definite_elements maintain existence maps.

Parent: [Compiler](r2-compiler.md)

## Units (18)

<a id="u-41775043a205"></a>
### `prune`

`export function prune(stylesheet, element)` · [packages/svelte/src/compiler/phases/2-analyze/css/css-prune.js:L86-L88][f1]

Walks a stylesheet and marks which selectors actually match a given element, so unused CSS can be pruned.

For each Rule: if it is a global block only its prelude is visited, otherwise normal recursion via context.next(). For each ComplexSelector: relative selectors are computed, the module-level snippet 'seen' set is cleared, and apply_selector runs BACKWARD from the element; a match sets node.metadata.used = true. No context.next() is called for ComplexSelector, so nested selector lists (inside :is(...) etc.) are only entered when explicitly visited elsewhere.

calls: [get_relative_selectors](r2-css-prune.md#u-5f13be96e649), [apply_selector](r2-css-prune.md#u-ca0893fe0929)

**Uncertainties.**

- zimmerframe walk semantics (whether visiting node.prelude recurses into inner rules) are external to this file

<a id="u-ca0893fe0929"></a>
### `apply_selector`

`function apply_selector(relative_selectors, rule, element, direction)` · [packages/svelte/src/compiler/phases/2-analyze/css/css-prune.js:L195-L213][f1]

Core matcher for one link of a selector chain.

The current relative selector is taken from the front for FORWARD or the end for BACKWARD; matching requires it to be defined, relative_selector_might_apply_to_node to hold, and apply_combinator to succeed on the rest. On a match, the selector is marked metadata.scoped = true unless it is an outer global, and element.metadata.scoped is set to true; the boolean propagates upward.

calls: [relative_selector_might_apply_to_node](r2-css-prune.md#u-8cf24a10b3c2), [apply_combinator](r2-css-prune.md#u-0baa697559cd)

**Uncertainties.**

- An empty selector list yields matched=false with no side effects

<a id="u-0baa697559cd"></a>
### `apply_combinator`

`function apply_combinator(relative_selector, rest_selectors, rule, node, direction)` · [packages/svelte/src/compiler/phases/2-analyze/css/css-prune.js:L223-L285][f1]

Continues matching across a combinator: read from rest_selectors[0] (FORWARD) or the current selector (BACKWARD); no combinator means success.

For ' ' or '>': descendants/ancestors (immediate ones for '>') each get apply_selector for the rest; BACKWARD also succeeds when all remaining selectors are global and the combinator is a descendant combinator or there are no parents. For '+' or '~': possible siblings are enumerated; RenderTag/SlotElement/Component siblings match only when exactly one remaining global selector exists, real elements are matched recursively, and BACKWARD additionally succeeds for all-global rest selectors when the node has no element parent. Any other combinator name returns true (source TODO).

calls: [get_descendant_elements](r2-css-prune.md#u-f417ee58086c), [get_ancestor_elements](r2-css-prune.md#u-f22cb866ff97), [get_possible_element_siblings](r2-css-prune.md#u-8bc72661b27e), [is_global](r2-css-prune.md#u-b61f649ec5db)

**Uncertainties.**

- Sibling iteration order per direction depends on get_possible_element_siblings behavior

<a id="u-8cf24a10b3c2"></a>
### `relative_selector_might_apply_to_node`

`function relative_selector_might_apply_to_node(relative_selector, rule, element, dire…` · [packages/svelte/src/compiler/phases/2-analyze/css/css-prune.js:L348-L453][f1]

Checks whether an element satisfies every simple selector of one relative selector.

':has(...)' selectors are handled first: for each, every truncated complex selector inside must match — via apply_selector including the element itself when ancestor rules are global or reference :root/:global(...), and via apply_selector with a '*' prefix excluding the element (treating '.x:has(.y)' like '.x .y'); a fully-truncated :global is marked used and matches; any failed :has returns false. Remaining selectors are then tested individually: Percentage/Nth are skipped; ':host'/':root' return false; a lone ':global(...)' recurses BACKWARD on its contents; bare ':global' returns true (everything beyond is global); ':not(...)' contents are marked used and left unscoped, except multi-selector ':not(a b)' which marks the element chain scoped; ':is'/':where' match per complex selector, assuming a match (marking scoped) when the descendant interpretation applies; pseudo elements always pass; AttributeSelector consults a details/dialog 'open' whitelist then attribute_matches; ClassSelector/IdSelector compare against class ('~=') / id ('='); TypeSelector compares names case-insensitively but passes for '*' and SvelteElement; NestingSelector matches if any parent-rule complex selector applies recursively or is entirely global, else returns false. Otherwise the element possibly matches (true).

calls: [apply_selector](r2-css-prune.md#u-ca0893fe0929), [truncate](r2-css-prune.md#u-2de4cf200800), [get_parent_rules](r6-compiler-analyze-css.md#u-f841f035438b), [is_global](r2-css-prune.md#u-b61f649ec5db), [attribute_matches](r2-css-prune.md#u-5f19512cd934), [get_element_parent](r2-css-prune.md#u-16466c9d33bc), [get_relative_selectors](r2-css-prune.md#u-5f13be96e649)

**Uncertainties.**

- The exact set of node types reaching this function (per its JSDoc union) is enforced upstream; behavior for unexpected types is unproven
- PseudoElementSelector always passing means pseudo elements never prevent a match

<a id="u-5f13be96e649"></a>
### `get_relative_selectors`

`function get_relative_selectors(node)` · [packages/svelte/src/compiler/phases/2-analyze/css/css-prune.js:L125-L135][f1]

Returns the truncated relative selectors of a complex selector, injecting an implicit '&' nesting selector when the owning rule has a parent rule but the selector contains no explicit NestingSelector (searched inside pseudo-class arguments too, stopping at the first find).

When injecting, the first selector receives a descendant combinator if it has none, then the synthetic '&' RelativeSelector constant is unshifted, so matching climbs to the parent rule.

calls: [truncate](r2-css-prune.md#u-2de4cf200800)

**Uncertainties.**

- Depends on node.metadata.rule and metadata.parent_rule being populated by earlier analysis phases

<a id="u-2de4cf200800"></a>
### `truncate`

`function truncate(node)` · [packages/svelte/src/compiler/phases/2-analyze/css/css-prune.js:L163-L186][f1]

Discards trailing global selectors from a complex selector because they are irrelevant for scoping.

findLastIndex locates the last child that is not global-like, not a bare ':global' pseudo-class without args, and not metadata.is_global; the slice keeps everything up to and including it. For a retained child containing a :root selector that is not global-like, all selectors except ':has(...)' are filtered out, so in ':root.y:has(...)' only the :has part remains to be scoped. If no qualifying child exists the result is empty, which callers interpret as fully global.

**Uncertainties.**

- findLastIndex returning -1 yields an empty array; all callers must handle the empty case as global

<a id="u-b61f649ec5db"></a>
### `is_global`

`function is_global(selector, rule)` · [packages/svelte/src/compiler/phases/2-analyze/css/css-prune.js:L296-L335][f1]

Decides whether a relative selector is effectively global.

Immediately true when metadata.is_global or is_global_like is set. Otherwise every simple selector must qualify: ':is'/':where' count via their args containing only all-global complex selectors (checked recursively, with the owner rule being the parent rule for NestingSelectors), other pseudo classes via is_unscoped_pseudo_class, and a NestingSelector via its parent rule's prelude being all global. Any selector failing both checks returns false; overall it returns true if some selector list was explicitly all-global or the selector list is empty.

calls: [is_unscoped_pseudo_class](r6-compiler-analyze-css.md#u-2d29e82903c1)

**Uncertainties.**

- For a NestingSelector the parent_rule is cast to a Rule without a check; a missing parent rule would throw

<a id="u-5f19512cd934"></a>
### `attribute_matches`

`function attribute_matches(node, name, expected_value, operator, case_insensitive)` · [packages/svelte/src/compiler/phases/2-analyze/css/css-prune.js:L626-L735][f1]

Tests whether any attribute of the element can satisfy an attribute selector.

SpreadAttributes and a BindDirective with the same name match immediately, as do StyleDirective for 'style' and ClassDirective for 'class' (the latter only when the directive name equals the expected value for '~='). Plain Attributes must match by name; value===true matches only a null operator, and a null expected value always matches. Static text attributes are tested via test_attribute, except that a non-matching class/style attribute is skipped in case a class/style directive still matches. Dynamic attributes compute possible values chunk by chunk via get_possible_values: an unknown chunk (null) forces a match (return true); chunk combinations are joined, keeping pieces ending/starting in whitespace separate, with prev_values capped at 20 to avoid exponential growth (bail-out returns true). Each candidate value is tested with test_attribute; the function returns false only after exhausting all attributes.

calls: [test_attribute](r2-css-prune.md#u-5aa194851017), [is_text_attribute](r5-compiler-utilities.md#u-ec400088cae5), [get_attribute_chunks](r5-compiler-utilities.md#u-1096ddb4c2b1), [get_possible_values](r6-compiler-analyze-css.md#u-cb59d8ba04c6)

**Uncertainties.**

- The combinatorial join of prev_values across chunks is approximate; whitespace-heavy combinations may cause conservative bail-outs (return true)

<a id="u-5aa194851017"></a>
### `test_attribute`

`function test_attribute(operator, expected_value, case_insensitive, value)` · [packages/svelte/src/compiler/phases/2-analyze/css/css-prune.js:L596-L617][f1]

Applies one CSS attribute-matching operator to a concrete string value.

When case_insensitive, both expected and actual values are lowercased first. Supports '=' (equality), '~=' (whitespace-separated word), '|=' (prefix followed by '-'), '^=' (prefix), '$=' (suffix), '*=' (substring); any other operator throws new Error("this shouldn't happen").

<a id="u-f22cb866ff97"></a>
### `get_ancestor_elements`

`function get_ancestor_elements(node, adjacent_only, seen = new Set())` · [packages/svelte/src/compiler/phases/2-analyze/css/css-prune.js:L750-L781][f1]

Collects the element ancestors of a node by walking node.metadata.path backwards.

RegularElement/SvelteElement parents are pushed, stopping immediately for adjacent_only. A SnippetBlock ancestor is expanded once per unique snippet (tracked in the 'seen' set) by recursing into each render site's own ancestors, then the walk breaks.

**Uncertainties.**

- Non-element, non-snippet path entries (e.g. components) are skipped, so ancestors across component boundaries are invisible to this function

<a id="u-f417ee58086c"></a>
### `get_descendant_elements`

`function get_descendant_elements(node, adjacent_only, seen = new Set())` · [packages/svelte/src/compiler/phases/2-analyze/css/css-prune.js:L788-L795][f1]

Collects RegularElement/SvelteElement descendants of a node (its fragment, or the node itself for RenderTags).

The inner walk visits the tree: elements are collected and recursed into only when not adjacent_only; RenderTags recurse into each not-yet-seen snippet body via the shared 'seen' set; all other nodes are descended normally. With adjacent_only the first element of each subtree is collected without descending further.

<a id="u-16466c9d33bc"></a>
### `get_element_parent`

`function get_element_parent(node)` · [packages/svelte/src/compiler/phases/2-analyze/css/css-prune.js:L827-L840][f1]

Returns the nearest RegularElement or SvelteElement found by scanning node.metadata.path backwards, or null when no such ancestor exists.

<a id="u-8bc72661b27e"></a>
### `get_possible_element_siblings`

`function get_possible_element_siblings(node, direction, adjacent_only, seen = new Set())` · [packages/svelte/src/compiler/phases/2-analyze/css/css-prune.js:L849-L941][f1]

Enumerates the elements that could be siblings of a node in the given direction, mapping each to NODE_DEFINITELY_EXISTS or NODE_PROBABLY_EXISTS.

It walks node.metadata.path backwards: at each enclosing fragment it scans forward/backward from the node's position. RegularElements are definite (unless they carry a slot attribute) and terminate an adjacent-only search; blocks and Components contribute probable SlotElement/Component entries plus nested siblings via get_possible_nested_siblings, stopping an adjacent-only search only on a definite non-Component result; SvelteElements and RenderTags are probable, with RenderTags additionally expanding each snippet. When the fragment boundary is crossed, the walk continues to the next enclosing node, recursing into unseen SnippetBlock sites (adjacent-only stops only when a single-site snippet yields definite elements) and, for an EachBlock whose body fragment was just scanned, adding the block's nested siblings. Component/SvelteComponent/SvelteSelf wrappers are transparent; any other enclosing node stops the walk.

calls: [get_possible_nested_siblings](r2-css-prune.md#u-776b8802874e), [is_block](r2-css-prune.md#u-a2e749949279), [has_definite_elements](r2-css-prune.md#u-41937f37bf51), [add_to_map](r2-css-prune.md#u-6a4f9f3a80c1)

**Uncertainties.**

- The paired i-- in `path[i--]` then `current = path[i]` relies on exact path layout; whether every enclosing node type is handled consistently is not provable from this file alone

<a id="u-776b8802874e"></a>
### `get_possible_nested_siblings`

`function get_possible_nested_siblings(node, direction, adjacent_only, seen = new Set())` · [packages/svelte/src/compiler/phases/2-analyze/css/css-prune.js:L950-L1009][f1]

Collects possible elements at the boundary of a block-like node's child fragments in the given direction.

Each block type contributes its fragments: EachBlock body+fallback, IfBlock consequent+alternate, AwaitBlock pending/then/catch, KeyBlock/SlotElement their fragment, SnippetBlock its body (returning empty for an already-seen snippet), and Component its fragment plus snippet bodies. Each non-null fragment is scanned via loop_child; a null fragment or a fragment without definite elements makes the result non-exhaustive. Non-exhaustive results (SlotElement, SnippetBlock, missing branches) downgrade every entry to NODE_PROBABLY_EXISTS, since the block might render nothing.

calls: [loop_child](r2-css-prune.md#u-0a565ad64fac), [has_definite_elements](r2-css-prune.md#u-41937f37bf51), [add_to_map](r2-css-prune.md#u-6a4f9f3a80c1)

<a id="u-0a565ad64fac"></a>
### `loop_child`

`function loop_child(children, direction, adjacent_only, seen)` · [packages/svelte/src/compiler/phases/2-analyze/css/css-prune.js:L1054-L1086][f1]

Scans a child list from the start (FORWARD) or end (BACKWARD) collecting possible elements.

RegularElements are definite and stop an adjacent-only scan; SvelteElements are probable; RenderTags contribute nested siblings of each snippet; blocks contribute get_possible_nested_siblings results, stopping an adjacent-only scan once a definite result is found. Other child types are skipped.

calls: [get_possible_nested_siblings](r2-css-prune.md#u-776b8802874e), [add_to_map](r2-css-prune.md#u-6a4f9f3a80c1)

<a id="u-6a4f9f3a80c1"></a>
### `add_to_map`

`function add_to_map(from, to)` · [packages/svelte/src/compiler/phases/2-analyze/css/css-prune.js:L1032-L1036][f1]

Merges one existence map into another, keeping the higher existence value per key via higher_existence, so definite entries are never downgraded by probable ones.

<a id="u-41937f37bf51"></a>
### `has_definite_elements`

`function has_definite_elements(result)` · [packages/svelte/src/compiler/phases/2-analyze/css/css-prune.js:L1015-L1023][f1]

Returns true only if the given existence map is non-empty and contains at least one NODE_DEFINITELY_EXISTS value; empty maps and probably-exists-only maps return false.

<a id="u-a2e749949279"></a>
### `is_block`

`function is_block(node)` · [packages/svelte/src/compiler/phases/2-analyze/css/css-prune.js:L1092-L1100][f1]

Type predicate: true for IfBlock, EachBlock, AwaitBlock, KeyBlock, or SlotElement nodes; false otherwise.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/css/css-prune.js
