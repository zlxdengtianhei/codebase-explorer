# Accessibility Checks

**Capability.** Runs all a11y warnings against element nodes during analysis, backed by role/attribute classification helpers and implicit role resolution.

Use this subtree to understand which accessibility rules fire and when. check_element is the single entry invoked by element visitors; classification helpers and role resolution decide rule applicability, and fuzzymatch supplies close-name suggestions.

**Depends on.**

- [Parse Utilities](r3-parse-utilities.md) · graph-confirmed · 2 edge(s)
- [Scope and Node Model](r3-scope-node-model.md) · model-inferred · 0 edge(s)

**Depended on by.**

- [Component Analysis](r3-analysis-core.md) · graph-confirmed · 1 edge(s)

Parent: [Compiler](r3-compiler.md)

## Units (5)

<a id="u-7ec766147486"></a>
### `index.js-check-element`

`export function check_element(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/shared/a11y/index.js:L56-L454][f1]

Runs every accessibility warning for one RegularElement or SvelteElement during analysis; it is the shared entry point invoked by the RegularElement and SvelteElement visitors.

**Notes.**

- contract: A first pass over attributes builds an attribute map, a handler set (OnDirective names plus on* attribute names via is_event_attribute), a has_spread flag, and contenteditable attr/binding flags; node.type 'SvelteElement' sets is_dynamic_element, which suppresses warnings that depend on element shape (required role props, aria-activedescendant tabindex, click-events-have-key-events, no-noninteractive-tabindex).
- condition: aria-* attributes: warn on invisible elements; unknown names get a fuzzymatch suggestion; aria-hidden on heading tags warns; the static value is validated against the aria schema when one exists; aria-activedescendant warns only when the element is not dynamic, not interactive, has no tabindex attribute, and no spread.
- condition: role attribute: each whitespace-separated token is checked independently for abstract or unknown roles (with fuzzymatch), redundancy against the implicit role (ul/ol/li exempt; a without href exempt), header/footer nested redundancy unless an ancestor is section or article, required role props (skipped for dynamic elements or spreads), interactive-supports-focus, and interactive↔noninteractive role misuse with the non-interactive-element exception table.
- condition: Single-attribute cases: accesskey always warns; autofocus warns unless the element is dialog or has a dialog parent; scope warns unless it is a static th; a numeric positive tabindex warns.
- condition: Element-level checks: a click handler on a non-interactive, non-hidden, non-presentation, non-dynamic element without spread and without keydown/keyup/keypress warns; tabindex present with value null or >= 0 on non-interactive elements warns; aria attributes not in the resolved explicit or implicit role warn, with a distinct message when the role is implicit; recommended interactive handlers on non-interactive elements warn; any interactive handlers on fully static elements warn with a handler list; mouseover/mouseout without focus/blur warn.
- condition: Tag-specific switch: a/button warn when unlabelled and contentless unless aria-hidden=true or inert; a validates href ('', '#', or js:-prefixed) and warns about missing href unless id, name, or aria-disabled=true is present; input type=image requires alt/aria-label/aria-labelledby and autocomplete is validated against the autofill token grammar; img warns on redundant alt text unless aria-hidden; label without for and without a labelable or slot child (found via zimmerframe walk that stops at SvelteElement, SlotElement, Component, and RenderTag) warns; video returns early when muted or aria-hidden=true or spread, otherwise warns without a track child whose kind=captions; figcaption outside figure warns; figcaption not first or last among meaningful figure children warns.
- condition: Final checks: required attributes per tag from a11y_required_attributes (a excluded) trigger warn_missing_attribute; blink and marquee warn as distracting; h1–h6 without content warn unless aria-label/aria-labelledby, a spread, or a contenteditable binding is present.
- side_effect: No state is mutated; all reporting goes through the imported w.a11y_* warning functions.

calls: [fuzzymatch](r3-parse-utilities.md#u-4d517976b3f9), [is_event_attribute](r5-compiler-utilities.md#u-1c2da82112be), [list](r2-compiler-infrastructure.md#u-5617f591c677), [utils.js-element-attribute-predicates](r5-compiler-utilities.md#u-57e79fafa2c2), [index.js-classification-helpers](r3-a11y-checks.md#u-2c222358e8c0), [validate_aria_attribute_value](r3-a11y-checks.md#u-1ca90fd6c2b7), [index.js-role-resolution](r3-a11y-checks.md#u-e9d06bf238d5), [warn_missing_attribute](r3-a11y-checks.md#u-0c8184e3783d); uses: [RegularElement.js-regular-element](r5-analyze-phase.md#u-72f0e6cf5bcc), [packages/svelte/src/compiler/phases/2-analyze/visitors/SvelteElement.js:SvelteElement](r3-analysis-core.md#u-e568340fb504)

**Uncertainties.**

- warning message text and severity are determined in warnings.js, which is not supplied

<a id="u-2c222358e8c0"></a>
### `index.js-classification-helpers`

`function is_presentation_role(role)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/shared/a11y/index.js:L557-L559][f1]

Predicate and value-extraction helpers that classify roles, elements, and attribute values so check_element can decide which accessibility rules apply.

**Notes.**

- contract: get_static_value returns true for a bare attribute, the first text chunk for a text attribute, and null for a missing or dynamic attribute; get_static_text_value additionally maps the bare-attribute true to null so text-valued semantics only.
- contract: element_interactivity checks role-based schemas first, then AXObject-based schemas, each interactive before non-interactive, and returns Static when nothing matches; 'header' is excluded from non-interactive role schemas. is_interactive_element/is_non_interactive_element/is_static_element are thin comparisons against that result.
- contract: match_schema requires the tag name to equal schema.name and, when schema.attributes exist, every listed attribute to be present with a matching static text value; a missing attributes list always matches.
- contract: is_hidden_from_screen_reader returns true for input type=hidden, for aria-hidden present with a dynamic value (null), and for aria-hidden true or 'true'; otherwise false.
- contract: has_disabled_attribute is true when disabled is any truthy static value or aria-disabled is exactly 'true'.
- contract: is_presentation_role, is_non_interactive_roles, is_interactive_roles, and is_abstract_role are membership tests against the constants.js lists.
- contract: is_semantic_role_element iterates elementAXObjects: a schema matches when the tag name equals and each schema attribute is present with an equal static value; then any AXObject role equal to the given role makes it true; no match returns false.
- contract: is_valid_autocomplete: bare true is invalid, null/absent (dynamic) is valid; otherwise the trimmed lowercase token list drops an optional section-* prefix, an optional shipping/billing token, then requires a field-name token, or a contact-type plus contact-field pair; an optional trailing webauthn is dropped, and validity requires all tokens consumed.
- failure: get_static_text_value(null) and non-text attributes yield null, so role_static_value comparisons treat dynamic roles as null and several checks use `role_static_value !== null` to keep them in scope.

calls: [is_text_attribute](r5-compiler-utilities.md#u-ec400088cae5), [list](r2-compiler-infrastructure.md#u-5617f591c677)

<a id="u-e9d06bf238d5"></a>
### `index.js-role-resolution`

`function input_implicit_role(attribute_map)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/shared/a11y/index.js:L729-L739][f1]

Implicit role resolution for input and menuitem elements and the parent-element scan used to contextualize role redundancy and placement warnings.

**Notes.**

- contract: get_implicit_role delegates menuitem to menuitem_implicit_role and input to input_implicit_role; everything else looks up a11y_implicit_semantics. input_implicit_role returns undefined without a static type, 'combobox' when a list attribute exists with a combobox_if_list type, otherwise the input_type_to_implicit_role entry; menuitem_implicit_role maps its static type via menuitem_type_to_implicit_role.
- contract: has_content recurses into fragment nodes: whitespace-only text is skipped; an img with any alt attribute counts as content; child elements count only if they themselves have content; everything else (dynamic blocks, components) is assumed to have content, per the in-code comment acknowledging false positives.
- contract: is_parent walks the path backwards, returning true on any SvelteElement (playing safe to suppress warnings), the membership test result on the first RegularElement, and false when the path runs out.

calls: [index.js-classification-helpers](r3-a11y-checks.md#u-2c222358e8c0)

<a id="u-1ca90fd6c2b7"></a>
### `validate_aria_attribute_value`

`function validate_aria_attribute_value(attribute, name, schema, value)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/shared/a11y/index.js:L874-L946][f1]

Validates a static aria attribute value against its ARIA schema type and emits a type-specific warning when the value does not conform.

**Notes.**

- condition: Returns immediately when the value is null (dynamic); a bare attribute (true) is treated as the empty string. id/string, idlist, and number reject ''; number also rejects non-numeric strings; boolean requires 'true'/'false'; integer requires a whole number; token requires the lowercased value in the schema's values; tokenlist requires every whitespace-separated lowercased token to be listed; tristate requires 'true', 'false', or 'mixed'.

calls: [list](r2-compiler-infrastructure.md#u-5617f591c677)

**Uncertainties.**

- schema.types other than the eight cases handled fall through silently because the switch has no default

<a id="u-0c8184e3783d"></a>
### `warn_missing_attribute`

`function warn_missing_attribute(node, attributes, name = node.name)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/shared/a11y/index.js:L953-L962][f1]

Emits the a11y_missing_attribute warning with a grammatically assembled attribute list for the element.

**Notes.**

- contract: The article is 'an' when the first attribute starts with a vowel or is 'href', else 'a'; multi-attribute lists join with commas and ' or ' before the last item; the displayed name defaults to the node's tag name.

uses: [warn_missing_attribute](r3-a11y-checks.md#u-0c8184e3783d)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/shared/a11y/index.js
