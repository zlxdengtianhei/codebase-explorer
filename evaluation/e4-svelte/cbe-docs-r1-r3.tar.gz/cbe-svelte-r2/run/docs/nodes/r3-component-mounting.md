# Component Mounting

**Capability.** Public mount/hydrate/unmount entry points that create component roots, manage intro-transition defaults, and track per-component cleanup.

Use this subtree for the component lifecycle API surface. mount and hydrate share the _mount implementation, which creates the root effect; unmount looks up and awaits the stored cleanup, optionally after transitions.

**Depends on.**

- [DOM Template Factories](r3-dom-template-factories.md) · graph-confirmed · 1 edge(s)
- [Effect Engine](r3-effects-engine.md) · graph-confirmed · 2 edge(s) · Mount and hydrate create the component root through the effect engine's effect creators.

**Depended on by.**

- [Svelte 4 Client Compatibility](r3-legacy-client-runtime.md) · graph-confirmed · 1 edge(s)

Parent: [Client Runtime](r3-runtime.md)

## Units (6)

<a id="u-1879cc967524"></a>
### `packages/svelte/src/internal/client/render.js:mount`

`export function mount(component, options)` · [packages/svelte/src/internal/client/render.js:L73-L75][f1]

Public mount entry point: delegates entirely to `_mount`, so mounting plays intro transitions by default (unless `options.intro` is false) and returns the component's exported API.

calls: [render-js-mount-impl](r3-component-mounting.md#u-a2a28a0a4743)

<a id="u-4a887fa96d35"></a>
### `packages/svelte/src/internal/client/render.js:hydrate`

`export function hydrate(component, options)` · [packages/svelte/src/internal/client/render.js:L100-L166][f1]

Hydrates server-rendered markup for a component, defaulting `intro` to false.

It locates the first child of the target whose comment data equals HYDRATION_START (throwing HYDRATION_ERROR when none exists), enables hydrating mode with that node as anchor, and mounts via `_mount`. After mounting it requires the hydration node to be the HYDRATION_END comment; otherwise it warns via `w.hydration_mismatch()` and throws HYDRATION_ERROR. The catch block re-throws errors whose message contains a line starting with 'https://svelte.dev/e/' (Svelte's own errors); for any other error it warns 'Failed to hydrate:' and, unless `options.recover === false` (which calls `e.hydration_failed()`), falls back to a full client-side `mount` after `clear_text_content(target)` and re-initialising operations. A finally block restores the previous hydrating flag and hydration node and calls `reset_head_anchor()`.

calls: [render-js-mount-impl](r3-component-mounting.md#u-a2a28a0a4743), [set_hydrating](r1-client-runtime.md#u-dd47d7c92d42), [set_hydrate_node](r1-client-runtime.md#u-053b251d50dd), [hydrate_next](r1-client-runtime.md#u-83058186182e), [packages/svelte/src/internal/client/render.js:mount](r3-component-mounting.md#u-1879cc967524), [warnings-js-generated-messages](r1-client-dev-warnings.md#u-b66cedc3c469), [reset_head_anchor](r4-client-dom-blocks.md#u-484aa5d18aec)

**Uncertainties.**

- Re-throw detection matches any error whose message has a line starting with the svelte.dev error URL prefix; non-Error objects fall through to the recover/fallback path

<a id="u-a2a28a0a4743"></a>
### `render-js-mount-impl`

`function _mount(Component, { target, anchor, props = {}, events, context, intro = tru…` · [packages/svelte/src/internal/client/render.js:L177-L184][f1]

Core mounting routine shared by `mount` and `hydrate`.

It initialises DOM operations, registers event handling, and runs the component inside a `component_root` effect. `event_handle` adds `handle_event_propagation` listeners for each registered event name to the target (deduplicated per mount via `registered_events`) and, reference-counted in the module-level `document_listeners` map, to `document` so events from manually portaled elements are still caught; passivity comes from `is_passive_event`. The whole set of `all_registered_events` is registered up front and `event_handle` itself is added to `root_event_handles`. Inside `component_root`, an anchor text node is appended to the target when none was supplied; a `branch` effect pushes the supplied `context` onto the component context stack (attaching it as `ctx.c`), copies `events` into `props.$$events` (preserving state-proxy props rather than spreading), calls `assign_nodes` when hydrating, sets `should_intro` to the `intro` option around the synchronous `Component(anchor_node, props)` invocation, records `hydrate_node` as the active effect's `nodes_end` when hydrating, and pops the context. The returned cleanup removes target listeners, decrements document listener counts (removing the document listener and map entry at zero), deletes `event_handle` from `root_event_handles`, and removes an auto-created anchor node. Finally, the component instance and cleanup are stored in the `mounted_components` WeakMap and the exports object is returned.

calls: [component_root](r3-effects-engine.md#u-42e380f9794b), [effects.js-effect-creators](r3-effects-engine.md#u-27c9c7c4069f), [push](r2-component-context.md#u-9761c5d7c2ee), [pop](r2-component-context.md#u-fe159451466a), [create_text](r5-runtime-dom.md#u-492391ef3e07), [init_operations](r5-runtime-dom.md#u-eb7a9f0e7810), [assign_nodes](r3-dom-template-factories.md#u-081194bea535), [function::is_passive_event::4930](../../catalog.json); uses: [function::handle_event_propagation][f2]

**Uncertainties.**

- The mounted `component` variable is typed as possibly undefined and read after the render effect; the code asserts it is defined because the effect runs synchronously, but this ordering is an assumption not proven here

<a id="u-4d8f77d0d2a4"></a>
### `packages/svelte/src/internal/client/render.js:unmount`

`export function unmount(component, options)` · [packages/svelte/src/internal/client/render.js:L303-L316][f1]

Unmounts a previously mounted or hydrated component by looking up its stored cleanup in `mounted_components`, deleting the entry, and invoking it with the options (its return value, a Promise that resolves after transitions when `outro` is true, is returned).

If no reference exists, in dev it warns via `w.lifecycle_double_unmount()` and otherwise returns an already-resolved Promise.

calls: [warnings-js-generated-messages](r1-client-dev-warnings.md#u-b66cedc3c469)

**Uncertainties.**

- The Promise semantics of the returned cleanup depend on the component_root return value, whose implementation is not in this file

<a id="u-cbadffbbf083"></a>
### `set_should_intro`

`export function set_should_intro(value)` · [packages/svelte/src/internal/client/render.js:L43-L45][f1]

Overwrites the module-level `should_intro` flag with the given boolean; consumers use the flag to decide whether block effects play intro transitions.

<a id="u-86b704dae3fa"></a>
### `set_text`

`export function set_text(text, value)` · [packages/svelte/src/internal/client/render.js:L52-L61][f1]

Updates a text node's content only when it actually changes.

Null/undefined coerce to '', objects are string-coerced before diffing (making template `$state` array references reactive through their valueOf/toString), and other values pass through. The last written string is cached on the node's `__t` property; the DOM `nodeValue` is touched only when the coerced string differs from the cache, avoiding layout churn on repeated sets.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/render.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/elements/events.js
