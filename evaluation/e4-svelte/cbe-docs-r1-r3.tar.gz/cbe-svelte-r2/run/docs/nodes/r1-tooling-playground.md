# Playground Scripts

**Capability.** Seeds and maintains sandbox tests: main.svelte templating, command-line target validation for new tests, recursive import-closure collection from App.svelte, and copying collected files plus a stub config into the target folder.

create-test.js drives the whole flow (validate args, collect_imports, copy); create-app-svelte.js seeds the app entry if missing.

Parent: [Repo Tooling & Benchmarks](r1-tooling.md)

## Units (4)

<a id="u-dde2e710e027"></a>
### `create-app-svelte.js module code (L1–L13)`

`module_region` · [playgrounds/sandbox/scripts/create-app-svelte.js:L1-L13][f1]

Seeds src/main.svelte from main.template.svelte if it does not already exist.

It creates the src directory in a try/catch that tolerates 'already exists', then copies the template contents. Existing main.svelte files are never overwritten.

<a id="u-1a06a1a0bb15"></a>
### `collect_imports`

`function collect_imports(file_path)` · [playgrounds/sandbox/scripts/create-test.js:L72-L113][f2]

Recursively walks relative import statements starting from App.svelte to gather the sandbox's local file closure.

Already-processed or nonexistent paths return immediately; each visited file is added to both tracking sets. Only imports starting with '.' are followed; bare (node_modules) specifiers are skipped. Each resolved import is tried with no extension, then .svelte, .js, .ts in that order, and the first existing path is recursed into. Import matching is a broad regex over the file text, so imports inside comments or strings can yield false positives.

**Notes.**

- contract: The same regex/extension resolution applies uniformly to .svelte and script files; there is no separate svelte-aware resolver.

calls: [collect_imports](r1-tooling-playground.md#u-1a06a1a0bb15)

**Uncertainties.**

- Imports whose specifier lacks an extension but resolves only via directory index files are not handled by the extension list.

<a id="u-44dc189350cd"></a>
### `create-test.js module code (L1–L71)`

`module_region` · [playgrounds/sandbox/scripts/create-test.js:L1-L71][f2]

Validates and normalizes the command-line target folder for a new playground-derived test.

A missing argument, or one not starting with 'runtime-', prints an error and exits 1; a bare name is prefixed with 'runtime-runes/'. The target is resolved to packages/svelte/tests/<group>/samples/<name>. If it exists, the script asks Y/n via raw stdin, exits on 'n', otherwise deletes everything in it except _config.js; if it does not exist the directory is created recursively.

**Uncertainties.**

- The Y/n prompt treats anything other than 'n' as confirmation, including empty or other keys, because only 'n' is checked.

<a id="u-2f95b981947e"></a>
### `create-test.js module code (L113–L155)`

`module_region` · [playgrounds/sandbox/scripts/create-test.js:L113-L155][f2]

Copies the collected files into the target test folder, then seeds a stub config for new tests.

Each file is copied preserving its path relative to src/, except App.svelte which is renamed to main.svelte; missing target directories are created first. If the target folder did not exist, an empty _config.js exporting a no-op test() is written; for pre-existing folders _config.js was preserved untouched, so no config is generated.

uses: [collect_imports](r1-tooling-playground.md#u-1a06a1a0bb15)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/playgrounds/sandbox/scripts/create-app-svelte.js
[f2]: ../../../../../../eval/svelte-be645b4/playgrounds/sandbox/scripts/create-test.js
