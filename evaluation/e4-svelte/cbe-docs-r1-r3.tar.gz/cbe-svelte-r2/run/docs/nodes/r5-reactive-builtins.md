# Reactive Built-ins

**Capability.** Public reactive substitutes for platform classes (SvelteMap, SvelteURL, SvelteDate), built on the internal source machinery, plus their behavioral tests verifying that mutations trigger effect re-runs.

Use this subtree for collection/URL/date reactivity semantics without deep value reactivity. These classes consume runtime-reactivity sources and are validated by date.test.ts.

**Depends on.**

- [Client Runtime Reactivity](r5-runtime-reactivity.md) · graph-confirmed · 35 edge(s) · SvelteMap and SvelteURL back their mutations with sources, state, and set from the client reactivity core.
- [Reactivity core](r2-reactivity-core.md) · graph-only · 21 edge(s)
- [Dev-Mode Diagnostics](r6-client-dev.md) · graph-only · 18 edge(s)

Parent: [Svelte Monorepo](r5-svelte-monorepo.md)

## Units (6)

<a id="u-8d62cace0a14"></a>
### `packages/svelte/src/reactivity/map.js:SvelteMap`

`class SvelteMap extends Map` · [packages/svelte/src/reactivity/map.js:L53-L63][f1]

Reactive Map subclass: reads in effects/deriveds re-run when the map mutates, without deep reactivity of values.

It keeps a per-key Source map plus version and size states. #source creates state(value) when update_version still equals the constructor-time snapshot #update_version (source created inside the same reaction, so it must not become that reaction's dependency), otherwise source(value). has/get: if no key source exists and super.get(key) is undefined, they track the version (so a later insertion re-fires) and return false/undefined without creating a source; otherwise they create the source (DEV: tag it with the label of the key), get(s), and return true/the value. set stores via super.set; when the key source is new it sets #size and increments the version; when only the value changed it increments the key source and additionally increments the version only if the source's reactions are not all covered by the version's reactions (computed from a snapshot Set of version.reactions). delete removes the source, sets it to -1, updates size, and increments the version, only when a source existed; the boolean result of super.delete is returned either way. clear no-ops when already empty, clears first (for readable $inspect output), resets size to 0, sets every source to -1, increments the version, then clears sources. #read_all gets the version, lazily creates missing key sources when #size.v differs from the source-map size, then gets every source; values(), entries(), and Symbol.iterator route through it, while keys() only tracks the version. size gets #size and returns super.size. The constructor calls super(), and in DEV wraps value in new Map(value) so invalid iterables throw the native exception before tagging the version and size states; any provided entries are inserted via super.set and #size.v is set to super.size.

**Notes.**

- side_effect: set/delete/clear mutate the underlying Map immediately, so non-reactive super reads see the new contents at once.
- field: #sources maps keys to per-key number sources; -1 marks a deleted/absent key's source as changed.

calls: [state](r5-runtime-reactivity.md#u-acd426d0030b), [tracing.js-reactive-tracing](r6-client-dev.md#u-fb7046392fad), [increment](r5-runtime-reactivity.md#u-8fa6038c59d8)

**Uncertainties.**

- The exact semantics of increment/set/source from sources.js and update_version from runtime.js are inferred from call sites; their definitions are not supplied.
- Whether s.reactions can change between the snapshot and the check in set is not visible here.

<a id="u-3b59d731599e"></a>
### `map.js module code (L1–L52)`

`module_region` · [packages/svelte/src/reactivity/map.js:L1-L52][f1]

Module imports and class documentation for SvelteMap; no executable behavior beyond the import declarations.

<a id="u-d8aa9c46c2fa"></a>
### `SvelteURL`

`class SvelteURL extends URL` · [packages/svelte/src/reactivity/url.js:L42-L57][f2]

Reactive URL subclass: reading a property in an effect/derived re-runs when that property (or href) is reassigned.

Each instance keeps one state per URL component (protocol, username, password, hostname, port, pathname, hash, search) initialized from the parsed URL via super.<prop>, plus a lazily-owned #searchParams. The constructor re-parses input through new URL(url, base), initializes super, tags all states in DEV, sets the module variable current_url to this, constructs a SvelteURLSearchParams from url.searchParams, and resets current_url to null — the window during which get_current_url returns this instance. Each simple getter (hash, hostname, password, pathname, port, protocol, search, username) tracks its state and returns the super value; each setter writes super first, then set()s the state to the recomputed super value (search's setter stores the raw value directly rather than super.search). host reads hostname and port states and writes both; origin reads protocol, hostname, and port and returns super.origin. href reads all eight states and returns super.href; its setter writes super.href, updates all eight states, and calls #searchParams[REPLACE]\(super.searchParams) so the params object stays in sync; the search setter does the same REPLACE. searchParams returns the SvelteURLSearchParams instance; toString and toJSON both return this.href.

**Notes.**

- failure: Invalid url input throws from new URL(url, base) with the native parse error before super() completes.
- side_effect: The constructor temporarily mutates the shared module variable current_url; constructing two SvelteURLs cannot interleave within a single synchronous execution, but reentrancy during SvelteURLSearchParams construction is not guarded.

calls: [state](r5-runtime-reactivity.md#u-acd426d0030b), [packages/svelte/src/internal/client/runtime.js:get](r2-reactivity-core.md#u-98099fbbf12a), [packages/svelte/src/internal/client/reactivity/sources.js:set](r5-runtime-reactivity.md#u-452914169f68), [SvelteURLSearchParams](r1-public-reactivity-motion.md#u-bc7188c78465), [tracing.js-reactive-tracing](r6-client-dev.md#u-fb7046392fad)

**Uncertainties.**

- Whether SvelteURLSearchParams construction or [REPLACE] can reentrantly observe current_url mid-construction is not visible in this file.
- The [REPLACE] contract on SvelteURLSearchParams is inferred from its call sites only.

<a id="u-35dc648e13ac"></a>
### `get_current_url`

`export function get_current_url()` · [packages/svelte/src/reactivity/url.js:L10-L13][f2]

Returns the module-level current_url pointer (a SvelteURL or null).

The comment states it exists because Vitest does not respect live bindings of a directly exported variable; SvelteURLSearchParams reads it to find the URL whose search params it belongs to. Its value is only non-null while a SvelteURL constructor is executing.

uses: [SvelteURL](r5-reactive-builtins.md#u-d8aa9c46c2fa), [SvelteURLSearchParams](r1-public-reactivity-motion.md#u-bc7188c78465)

<a id="u-b00f24011c35"></a>
### `date-test-ts`

`const expect_all_changes_to_be_false = () =>` · [packages/svelte/src/reactivity/date.test.ts:L478-L482][f3]

Verifies that SvelteDate setters trigger reactive re-evaluation of getters read in render effects.

Each test builds a SvelteDate, registers render effects under an effect_root that log getter values, applies setter mutations inside flushSync, and asserts the exact log sequence. Recurring checks: a setter called with the current value must not fire effects; local and UTC getter pairs update in lockstep; edge values roll over (setSeconds(60)/(61) bumps minutes, and in the propagation test setMonth(13) updates month, year, seconds effects); setYear (legacy API) is skipped if absent; toLocaleString and valueOf are reactive; and Date methods first read inside deriveds (including shared between two deriveds) propagate changes.

calls: [expect_all_changes_to_be_false](r5-reactive-builtins.md#u-3c1f47f53531)

**Uncertainties.**

- The exact implementation of SvelteDate's change-flag granularity (which getters re-fire for a given setter) is inferred from the asserted log/flag expectations, not from its source, which is not supplied.

<a id="u-3c1f47f53531"></a>
### `expect_all_changes_to_be_false`

`const expect_all_changes_to_be_false = () =>` · [packages/svelte/src/reactivity/date.test.ts:L478-L482][f3]

Test helper asserting that every entry in the closure-over changes record is false, prefixing failures with the current test_description.

Used inside flushSync blocks to confirm no unintended effect fired after a SvelteDate mutation.

group: [date-test-ts](r5-reactive-builtins.md#u-b00f24011c35)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/reactivity/map.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/reactivity/url.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/reactivity/date.test.ts
