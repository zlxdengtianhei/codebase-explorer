# Shared Utilities and Tests

**Capability.** Runtime-agnostic helpers (captured globals, run/run_all, deferred promises, promise-like checks, fallback, iterable to_array) plus the Vitest suite validating snapshot/clone behavior.

Use these helpers from both client and server code; they are dependency-free infrastructure. The clone test suite documents snapshot semantics including uncloneable values and reactive collections.

**Depended on by.**

- [Element Effects and Transitions](r6-client-dom-elements.md) · graph-confirmed · 1 edge(s)
- [Legacy Component Lifecycle](r6-client-dom-legacy.md) · graph-confirmed · 2 edge(s)
- [Task Scheduling](r6-client-dom-task.md) · graph-confirmed · 2 edge(s)
- [Spring Motion](r6-motion.md) · graph-confirmed · 1 edge(s)
- [Server Runtime](r6-runtime-server.md) · model-inferred · 0 edge(s)
- [Store Contract](r6-stores.md) · graph-confirmed · 1 edge(s)

Parent: [Svelte Monorepo](r6-svelte-monorepo.md)

## Units (21)

<a id="u-3c5ab59ed010"></a>
### `deferred`

`export function deferred()` · [packages/svelte/src/internal/shared/utils.js:L53-L68][f1]

Creates an externally-resolvable promise: returns `{ promise, resolve, reject }` where promise is a new Promise whose executor captures the resolve/reject functions into the returned object.

Callers settle the promise later from outside; resolve/reject are typed loosely (ts-expect-error) but are the real Promise executor arguments.

<a id="u-f7765ee2ffbb"></a>
### `fallback`

`export function fallback(value, fallback, lazy = false)` · [packages/svelte/src/internal/shared/utils.js:L77-L83][f1]

Default-value helper: returns `fallback` only when `value` is exactly undefined (strict `===`), so null, false, 0, and '' pass through unchanged.

When `lazy` is true the fallback is treated as a thunk and invoked; otherwise it is returned directly.

<a id="u-497b6c692c87"></a>
### `is_function`

`export function is_function(thing)` · [packages/svelte/src/internal/shared/utils.js:L19-L21][f1]

Type guard returning true exactly when `typeof thing === 'function'`; used to discriminate callbacks from values.

<a id="u-f3295568a063"></a>
### `is_promise`

`export function is_promise(value)` · [packages/svelte/src/internal/shared/utils.js:L33-L35][f1]

Promise-like check: true when `value?.then` is a function, false for null/undefined or anything without a callable `then` — this accepts any thenable, not only real Promises.

<a id="u-c1c0f4514218"></a>
### `packages/svelte/src/internal/shared/utils.js:run`

`export function run(fn)` · [packages/svelte/src/internal/shared/utils.js:L38-L40][f1]

Invokes `fn()` and returns its result; a trivial indirect-call helper.

<a id="u-15a69c36073f"></a>
### `run_all`

`export function run_all(arr)` · [packages/svelte/src/internal/shared/utils.js:L43-L47][f1]

Calls each zero-argument function in the array in order with a plain indexed loop.

No exception handling: if a callback throws, iteration stops and the error propagates, leaving later callbacks unrun.

<a id="u-c7d546e409e1"></a>
### `to_array`

`export function to_array(value, n)` · [packages/svelte/src/internal/shared/utils.js:L94-L118][f1]

Converts a destructuring source to an array with iterable-length awareness.

Arrays are returned unchanged (same reference). If `n` is undefined (rest element — unbounded iterables are allowed) or the value lacks Symbol.iterator, it is converted wholesale with Array.from. Otherwise exactly `n` elements are taken: iteration stops as soon as the output array reaches length n, so infinite iterables terminate; a shorter iterable yields a shorter array.

<a id="u-3c69a83476fd"></a>
### `utils.js module code (L1–L18)`

`module_region` · [packages/svelte/src/internal/shared/utils.js:L1-L18][f1]

Captured globals: module-level references to Array.isArray, indexOf, Array.from, Object.keys/defineProperty/getOwnPropertyDescriptor/getOwnPropertyDescriptors, Object/Array prototypes, getPrototypeOf, isExtensible, kept so monkey-patching the globals cannot de-opt these helpers.

<a id="u-f5a36dbaf2b2"></a>
### `utils.js module code (L35–L37)`

`module_region` · [packages/svelte/src/internal/shared/utils.js:L35-L37][f1]

Comment region citing is-promise provenance; no runtime behavior.

<a id="u-aca512dce802"></a>
### `utils.js module code (L40–L42)`

`module_region` · [packages/svelte/src/internal/shared/utils.js:L40-L42][f1]

Non-behavioral gap between run and run_all.

<a id="u-a2b959d09c32"></a>
### `utils.js module code (L47–L52)`

`module_region` · [packages/svelte/src/internal/shared/utils.js:L47-L52][f1]

Non-behavioral gap between run_all and deferred.

<a id="u-421f298bcd9e"></a>
### `utils.js module code (L68–L76)`

`module_region` · [packages/svelte/src/internal/shared/utils.js:L68-L76][f1]

Non-behavioral gap between deferred and fallback.

<a id="u-bf0585bfd055"></a>
### `utils.js module code (L83–L93)`

`module_region` · [packages/svelte/src/internal/shared/utils.js:L83-L93][f1]

Comment region explaining the to_array use case; no runtime behavior.

<a id="u-87f3debe9801"></a>
### `utils.js module code (L23–L32)`

`module_region` · [packages/svelte/src/internal/shared/utils.js:L23-L32][f1]

Non-behavioral gap around the noop constant.

<a id="u-27aa7c779b6a"></a>
### `clone-test-ts-suite`

`function capture_warnings()` · [packages/svelte/src/internal/shared/clone.test.ts:L5-L19][f2]

Vitest suite for `snapshot`.

`capture_warnings` swaps console.warn for a collector and returns a restore function that puts the original back and yields the collected messages. Cases verify: primitives pass through (42); arrays and objects are deep-equal copies with distinct identity; changes to a `proxy` state after snapshotting do not affect the snapshot; cyclic objects keep cycle identity (copy.self is the copy); a class instance snapshots only its own fields, excluding prototype getters and private fields ({x:1}); a `toJSON` method redirects cloning to its output ({x:1,y:2}); a Map subclass snapshots to a plain Map instance, not the subclass; an uncloneable function value is returned identical and triggers the exact single `state_snapshot_uncloneable` warning string; an object with several function-valued properties warns with a per-path list (`.a`, `.b`, `.c[0..7]`) while the container is still copied; and an array of 100 functions truncates the path list to 7 entries plus '...and 93 more'.

calls: [packages/svelte/src/internal/shared/clone.js:snapshot](r1-shared-internals.md#u-bfcc537be9f1); imports: [packages/svelte/src/internal/client/proxy](../../catalog.json)

<a id="u-1badd8c478e8"></a>
### `clone.test.ts module code (L1–L4)`

`module_region` · [packages/svelte/src/internal/shared/clone.test.ts:L1-L4][f2]

Test-file imports of snapshot, vitest assertions, and proxy; no runtime behavior of its own.

<a id="u-728658ac88ed"></a>
### `clone.test.ts module code (L75–L84)`

`module_region` · [packages/svelte/src/internal/shared/clone.test.ts:L75-L84][f2]

Test bodies around the class fixtures; covered in the suite group.

<a id="u-0113b917f6be"></a>
### `clone.test.ts module code (L98–L106)`

`module_region` · [packages/svelte/src/internal/shared/clone.test.ts:L98-L106][f2]

Test bodies around the toJSON fixture; covered in the suite group.

<a id="u-dc0432537498"></a>
### `clone.test.ts module code (L110–L122)`

`module_region` · [packages/svelte/src/internal/shared/clone.test.ts:L110-L122][f2]

Reactive Map test body; covered in the suite group.

<a id="u-3a84ae52975e"></a>
### `clone.test.ts module code (L122–L188)`

`module_region` · [packages/svelte/src/internal/shared/clone.test.ts:L122-L188][f2]

Uncloneable-value and warning-content tests; covered in the suite group.

<a id="u-cb5eea837bf9"></a>
### `clone.test.ts module code (L19–L68)`

`module_region` · [packages/svelte/src/internal/shared/clone.test.ts:L19-L68][f2]

Basic snapshot tests (primitive, array, object, proxied state, cycles) covered in the suite group.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/shared/utils.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/shared/clone.test.ts
