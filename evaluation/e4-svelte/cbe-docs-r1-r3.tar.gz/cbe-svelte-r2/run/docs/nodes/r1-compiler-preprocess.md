# Preprocessing & Sourcemaps

**Capability.** Runs user preprocessor groups over component source (markup and script/style tags), reassembles the source with MappedCode ranges, and decodes/normalizes source maps so downstream compilation keeps accurate mappings.

preprocess is the entry point; process_tag/process_markup apply user hooks; PreprocessResult tracks evolving source and dependencies; decode_sourcemap.js converts generator objects into plain decoded maps. Attribute parsing/serialization helpers support tag reconstruction.

**Depends on.**

- [Svelte Compiler](r1-compiler.md) · containment · → 0 / ← 0 edge(s) (ancestor direct units and descendant subtree; → follows ` r1-compiler-preprocess ` → ` r1-compiler `)
- [Compiler Infrastructure](r6-compiler-infra.md) · graph-only · 11 edge(s)

Parent: [Svelte Compiler](r1-compiler.md)

## Units (10)

<a id="u-c6f821c0ed6a"></a>
### `decode_map`

`export function decode_map(processed)` · [packages/svelte/src/compiler/preprocess/decode_sourcemap.js:L86-L96][f1]

Normalizes the map field of a Processed result into a decoded source map.

Three sequential cases: a string map is JSON.parse'd; a map whose mappings is a VLQ string is decoded via @jridgewell/sourcemap-codec; an object with _mappings whose constructor.name is 'SourceMapGenerator' is converted by decoded_sourcemap_from_generator. Any other object passes through unchanged, and errors from JSON.parse or decoding propagate.

calls: [decoded_sourcemap_from_generator](r1-compiler-preprocess.md#u-032387dae287)

**Uncertainties.**

- Detection relies on constructor.name === 'SourceMapGenerator'; bundling/minification could defeat this check, leaving the object unconverted.

<a id="u-032387dae287"></a>
### `decoded_sourcemap_from_generator`

`function decoded_sourcemap_from_generator(generator)` · [packages/svelte/src/compiler/preprocess/decode_sourcemap.js:L11-L81][f1]

Converts a mozilla/source-map SourceMapGenerator instance, accessed via hidden properties, into a plain decoded source map object.

It builds value-to-index lookups from generator._sources.toArray() and generator._names.toArray(), then iterates generator._mappings.toArray(). When a mapping's generatedLine exceeds the previous line, empty arrays are pushed until converted_mappings aligns (lines are one-based, indexed as line - 1); otherwise, when i > 0, a mapping identical to its predecessor in all six fields (generatedColumn, originalColumn, name, generatedLine, originalLine, source) is skipped. Each kept mapping appends [generatedColumn]; if mapping.source != null the segment gains [source_idx[source], originalLine - 1, originalColumn], plus name_idx[name] when a name exists. The result carries version, sources, names, and the converted mappings; file is set only when generator._file != null, and sourcesContent/sourceRoot are intentionally omitted.

**Uncertainties.**

- Assumes the generator exposes _sources, _names, _mappings, _version, and _file with mappings sorted by generated position; nothing validates this.
- A mapping source or name missing from the generator arrays would push undefined into segments.

<a id="u-d0cf287ba25e"></a>
### `PreprocessResult`

`class PreprocessResult` · [packages/svelte/src/compiler/preprocess/index.js:L19-L56][f2]

Tracks intermediate preprocessing state: the current source string, the filename as passed in, accumulated dependencies, a file basename used as the sourcemap sources entry, and a locator refreshed on every source change.

Sourcemaps are kept newest-first via unshift, matching the remapping convention for chained transformations. The constructor seeds the initial source through update_source so get_location exists immediately, and sets file_basename to null when filename is null, otherwise to get_basename(filename). update_source applies a partial SourceUpdate in place: a non-null string replaces source and rebuilds getLocator(source); a present map is unshifted onto sourcemap_list; a dependencies array is appended. to_processed combines the map list with combine_sourcemaps(file_basename, sourcemap_list) and returns a Processed-shaped object whose code is the current source, dependencies are deduplicated through a Set, map is the combined result, and toString returns the current source.

contract: [Source][f3]; uses: [packages/svelte/src/compiler/utils/mapped_code.js][f4]

**Uncertainties.**

- Two @ts-expect-error comments ('TODO there might be a bug in hiding here') surround combine_sourcemaps usage, flagging unverified type/behavior assumptions.

<a id="u-fb2fa12e3a03"></a>
### `parse_tag_attributes`

`function parse_tag_attributes(str)` · [packages/svelte/src/compiler/preprocess/index.js:L223-L236][f2]

Parses an attribute string into a record using a shared global regex matching names (\w, -, $) with optional values in double quotes, single quotes, or an unquoted run of non-space characters.

A missing or empty value is stored as the falsy value itself (`attrs[name] = !value || value`), so boolean-style attributes become false and empty quoted values become ''. The regex is module-level with the g flag, so repeated calls with overlapping lastIndex from concurrent use could behave unexpectedly.

**Uncertainties.**

- The regex's lastIndex is shared state; interrupted matches (e.g. during exceptions) could skip input on the next call.

<a id="u-049035fc1450"></a>
### `preprocess`

`export default async function preprocess(source, preprocessor, options)` · [packages/svelte/src/compiler/preprocess/index.js:L338-L368][f2]

Entry point that transforms component source through a preprocessor group or array of groups.

The filename comes from options.filename, falling back to a legacy preprocessor.filename property. Preprocessor groups are normalized to an array (empty when preprocessor is falsy), and a PreprocessResult is created for the source. For each group, in order: markup runs process_markup over the whole file, then script and style each run process_tag; each returned SourceUpdate is applied via update_source, so later preprocessors see earlier output and their maps accumulate newest-first. Finally to_processed returns the combined code, deduplicated dependencies, and merged sourcemap.

uses: [PreprocessResult](r1-compiler-preprocess.md#u-d0cf287ba25e); calls: [process_markup](r1-compiler-preprocess.md#u-4ab1a1bb5a53), [process_tag](r1-compiler-preprocess.md#u-bfe65eceb1e6)

**Uncertainties.**

- Errors thrown by user preprocessors propagate and abort the whole run; no per-preprocessor fallback exists.

<a id="u-4ab1a1bb5a53"></a>
### `process_markup`

`async function process_markup(process, source)` · [packages/svelte/src/compiler/preprocess/index.js:L308-L327][f2]

Runs a markup preprocessor over the whole source.

If the preprocessor returns a result, it is converted to a SourceUpdate: string is processed.code, dependencies pass through, and map is JSON-parsed when a string, taken as-is otherwise, or undefined when absent. If the preprocessor returns nothing, an empty object is returned so update_source changes nothing.

**Uncertainties.**

- The map is inserted without decoding validation here despite the TODO questioning whether decode_sourcemap should be used.

<a id="u-bfe65eceb1e6"></a>
### `process_tag`

`async function process_tag(tag_name, preprocessor, source)` · [packages/svelte/src/compiler/preprocess/index.js:L265-L279][f2]

Applies a script/style preprocessor to every matching tag in the source and collects dependencies.

Tags are found with regex_style_tags or regex_script_tags depending on tag_name; both skip HTML comments. For each match, process_single_tag is invoked with the full tag text, the attribute string, the captured content, and the match offset. It returns a no-op MappedCode (the original slice) when the tag has neither attributes nor content, when the preprocessor returns nothing, or when there is no map and processed.code equals the original content. Otherwise it collects processed.dependencies, converts processed.attributes to a string (falling back to the original attributes when stringify returns undefined), and delegates to processed_tag_to_code with a Source sliced to the content at the tag offset. Aggregated dependencies are returned alongside the replacement string and map from replace_in_code.

calls: [replace_in_code](r4-compiler-infra.md#u-8eab9628969e), [processed_tag_to_code](r1-compiler-preprocess.md#u-f147b9bdbeb1), [slice_source](r4-compiler-infra.md#u-b98556db32bb), [parse_tag_attributes](r1-compiler-preprocess.md#u-fb2fa12e3a03), [stringify_tag_attributes](r1-compiler-preprocess.md#u-348e22d5d13f)

**Uncertainties.**

- Regex captures assume tag content ends at the first matching close tag; nested tags of the same name are not handled in the visible pattern.

<a id="u-f5d36b72e8e4"></a>
### `processed_content_to_code`

`function processed_content_to_code(processed, location, file_basename)` · [packages/svelte/src/compiler/preprocess/index.js:L107-L126][f2]

Converts a preprocessor's tag-content output into a MappedCode.

If processed.map exists it is decoded via decode_map; when the decoded map has a sources array, the index of file_basename is looked up and only when found (index !== -1) are that source's segments shifted to the tag-content location via sourcemap_add_offset — maps not referencing the component file are left unshifted, and empty maps without sources skip offsetting entirely. Returns MappedCode.from_processed(processed.code, decoded_map).

calls: [decode_map](r1-compiler-preprocess.md#u-c6f821c0ed6a); uses: [packages/svelte/src/compiler/utils/mapped_code.js][f4]

<a id="u-f147b9bdbeb1"></a>
### `processed_tag_to_code`

`function processed_tag_to_code( processed, tag_name, original_attributes, generated_a…` · [packages/svelte/src/compiler/preprocess/index.js:L137-L150][f2]

Builds the MappedCode that replaces a whole <style>/<script> tag (open tag, processed content, close tag) in the source, using the Source's file_basename and get_location.

It reconstructs the original open tag (<tag + original_attributes + '>') and the output open tag (with generated_attributes). If their lengths differ, it hand-writes a version-3 map whose sole source is file_basename: a segment mapping the tag start to (0,0), a segment mapping the end of `<tag` back to its original column, one extra line mapping per additional newline in the generated attributes, and a final segment mapping the generated tag's end (column from lastIndexOf('\n')) back to the original tag's end; the map is shifted to the tag's start with sourcemap_add_offset. If lengths are equal, the open tag is instead mapped by slicing the original source at offset 0 via build_mapped_code. The close tag is always mapped by slicing at original_tag_open.length + source.source.length (i.e. just after the original tag). parse_attached_sourcemap processes the content's attached map, then processed_content_to_code maps the content at the position after the original open tag; the three pieces are concatenated in order.

calls: [slice_source](r4-compiler-infra.md#u-b98556db32bb), [processed_content_to_code](r1-compiler-preprocess.md#u-f5d36b72e8e4); uses: [packages/svelte/src/compiler/utils/mapped_code.js][f4]

**Uncertainties.**

- The length-equality fast path assumes equal-length tags have identical layout; only length, not content, is compared.
- Column computation for multi-line generated attributes uses tag_open.lastIndexOf('\n') without subtracting the offset of that index in the arithmetic shown; correctness for multi-line attributes is not verified here.

<a id="u-348e22d5d13f"></a>
### `stringify_tag_attributes`

`function stringify_tag_attributes(attributes)` · [packages/svelte/src/compiler/preprocess/index.js:L241-L251][f2]

Serializes an attributes record back into an attribute string: entries with value true render as the bare key, all others as key="value"; entries are space-joined and prefixed with a leading space when non-empty.

Returns undefined when attributes is falsy or when serialization yields an empty string.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/preprocess/decode_sourcemap.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/preprocess/index.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/preprocess/private.d.ts
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/utils/mapped_code.js
