# Client runtime

**Capability.** The browser-side runtime: the signal/effect reactivity core, component context, store integration, async/reactivity-loss handling, and DOM rendering (elements, events, media bindings).

Start at reactivity-core for the signal graph, then component-context and store-integration for the surrounding lifecycle. dom-elements covers event delegation and element bindings. The module also guards accidental imports of the removed Svelte 4 internal entry and discloses the version to devtools.

**Children.**

- [Reactivity core](r2-reactivity-core.md) `r2-reactivity-core` · 16 unit(s)
- [Async reactivity](r2-async-reactivity.md) `r2-async-reactivity` · 8 unit(s)
- [Component context](r2-component-context.md) `r2-component-context` · 11 unit(s)
- [Store integration](r2-store-integration.md) `r2-store-integration` · 20 unit(s)
- [DOM elements, events and bindings](r2-dom-elements.md) `r2-dom-elements` · 16 unit(s)

Parent: [Svelte framework](r2-svelte.md)

## Units (2)

<a id="u-ea8222e99174"></a>
### `disclose-version.js module code (L1–L6)`

`module_region` · [packages/svelte/src/internal/disclose-version.js:L1-L6][f1]

Discloses the library version to devtools when the module is first loaded.

If a global window exists, it creates (or reuses) window.__svelte, creates (or reuses) its v property as a Set, and adds PUBLIC_VERSION from ../version.js. In non-browser environments (no window) the module does nothing; multiple Svelte copies are detectable by devtools inspecting the resulting Set.

imports: [disclose-version.js module code (L1–L6)](r2-client-runtime.md#u-ea8222e99174)

**Uncertainties.**

- Only PUBLIC_VERSION is added; any DEV-specific version disclosure would live elsewhere and is not visible here.

<a id="u-f3cae833edb2"></a>
### `index.js module code (L1–L5)`

`module_region` · [packages/svelte/src/internal/index.js:L1-L5][f2]

Guard module that always throws an Error on import, with a message explaining that 'svelte/internal' was a private Svelte 4 module removed in Svelte 5, and directing library authors to file an issue if they depended on it.

Importing this module can never succeed.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/disclose-version.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/index.js
