# Benchmarks and Developer Environment

**Capability.** Owns measurement and local development: the benchmark harness (timing, GC correlation, file/assert helpers), reactivity and SSR benchmark workloads, and the shared Vitest/Vite sandbox configuration used while working on the package. None of this ships to users.

Use this subtree to run or interpret performance measurements and to configure local dev. The harness internals (fastest_test→run_tracked→run_timed/GarbageTrack) are local; SSR benchmarks compile via the public compiler API.

**Children.**

- [Svelte Monorepo](r3-svelte-monorepo.md) `r3-svelte-monorepo` · 2 unit(s)

**Depends on.**

- [Compiler Pipeline and Migration](compiler-and-migration.md) · graph-confirmed · 107 edge(s)

**Depended on by.**

- [Build and Packaging](build-and-packaging.md) · graph-confirmed · 53 edge(s) · Sandbox/playground packaging scripts share the dev-environment configuration and benchmark workloads.

Parent: [Svelte Monorepo](svelte-monorepo.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
