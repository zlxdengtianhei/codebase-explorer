# Svelte Monorepo

**Capability.** Owns the full Svelte ecosystem: public DOM typings, the compiler pipeline (parse → analyze → transform), client and server runtimes, shared infrastructure, stores/motion/reactive values, and reactivity benchmarks.

Start here to navigate the codebase. Major responsibilities are separated: compiler phases from runtimes, shared utilities from consumers.

**Children.**

- [Reactivity Benchmarks](r6-benchmarking.md) `r6-benchmarking` · 3 unit(s)
- [Public DOM Element Typings](r6-public-dom-typings.md) `r6-public-dom-typings` · 19 unit(s)
- [Compiler Pipeline](r6-compiler.md) `r6-compiler` · 0 unit(s)
- [Client Runtime](r6-runtime-client.md) `r6-runtime-client` · 0 unit(s)
- [Server Runtime](r6-runtime-server.md) `r6-runtime-server` · 10 unit(s)
- [Shared Utilities and Tests](r6-shared-infra.md) `r6-shared-infra` · 21 unit(s)
- [Stores, Motion, and Reactive Values](r6-stores-motion-reactivity.md) `r6-stores-motion-reactivity` · 0 unit(s)

Parent: [Client/Server Runtime and Shared Infrastructure](runtime-and-shared-infra.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
