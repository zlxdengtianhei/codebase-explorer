# Runtime

**Capability.** The compiled-output execution environment: client-side reactivity scheduling and DOM operations, server-side rendering, shared HTML attribute/warning helpers, and the public entry modules that re-export these capabilities.

Use this subtree for behavior after compilation. Client runtime covers batching, blocks, bindings, and dev tooling; server runtime covers SSR helpers; shared modules (attributes, warnings, flags) serve both; entry modules re-export and host lifecycle APIs.

**Children.**

- [Reactive Batch Scheduling](r4-reactivity-scheduling.md) `r4-reactivity-scheduling` · 17 unit(s)
- [Client DOM Blocks](r4-client-dom-blocks.md) `r4-client-dom-blocks` · 11 unit(s)
- [Element Bindings and Styles](r4-element-bindings.md) `r4-element-bindings` · 12 unit(s)
- [Client Dev Tooling](r4-client-dev-tools.md) `r4-client-dev-tools` · 4 unit(s)
- [Client Entry and Lifecycle](r4-client-entry.md) `r4-client-entry` · 10 unit(s)
- [Server Runtime](r4-server-runtime.md) `r4-server-runtime` · 12 unit(s)
- [Runtime Shared Helpers](r4-runtime-shared.md) `r4-runtime-shared` · 16 unit(s)
- [Legacy Compatibility \(Server\)](r4-legacy-compat.md) `r4-legacy-compat` · 2 unit(s)

**Depended on by.**

- [Public API Type Surface](r4-public-api-types.md) · model-inferred · 0 edge(s)

Parent: [Svelte Codebase](r4-svelte-codebase.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
