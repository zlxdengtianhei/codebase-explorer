# Treeshakeability Verification

**Capability.** Bundles synthetic entries per svelte package export through rollup (with a resolveId mapping bare 'svelte*' specifiers to local files) and verifies each shakes to nothing, then probes a feature-heavy client bundle for residual code.

check_bundle reports surviving markers; bundle_code with its resolveId hook produces the chunks. This is the regression gate for client-runtime tree-shaking.

**Depends on.**

- [Client Transform Visitors](r1-compiler-transform-client.md) · model-inferred · 0 edge(s) · Treeshakeability verification bundles the compiler's client exports and probes the client transform output for residual code.

Parent: [Repo Tooling & Benchmarks](r1-tooling.md)

## Units (4)

<a id="u-8afde5f8f2a5"></a>
### `packages/svelte/scripts/check-treeshakeability.js:bundle_code`

`async function bundle_code(entry)` · [packages/svelte/scripts/check-treeshakeability.js:L26-L46][f1]

Bundles a synthetic entry string through rollup and returns the single output chunk's trimmed code.

The entry is injected as the virtual module '__entry__'; a custom plugin maps bare 'svelte*' specifiers to absolute paths resolved from pkg.exports (browser entry preferred over default); nodeResolve then resolves remaining imports with production/import/browser/default conditions. Rollup warnings with code EMPTY_BUNDLE or CIRCULAR_DEPENDENCY are swallowed in onwarn; any other warning is forwarded by calling handle(warning). If bundle.generate produces more than one output file it throws Error('errr what'); otherwise output[0].code trimmed is returned. Rollup failures propagate to the caller.

uses: [bundle_code.resolveId](r1-tooling-treeshake.md#u-351ac66b7b34)

**Uncertainties.**

- The function reads the module-level pkg, parsed from 'package.json' relative to the process working directory, outside this function's scope

<a id="u-be696749d63c"></a>
### `check_bundle`

`function check_bundle(case_name, ...strings)` · [packages/svelte/scripts/check-treeshakeability.js:L125-L146][f1]

Reports whether any of the given marker strings survived into the module-level bundle.

For each candidate string it searches bundle with indexOf; on the first hit it logs ❌, sets the shared failed flag, slices ±500 characters around the match, marks the line containing the string with '>' and up to five surrounding lines with '|', prints that context, and returns immediately — remaining strings for the case are not checked. If no string is found it logs ✅. Side effects are console output and the module-level failed flag; it always returns undefined.

uses: [check-treeshakeability.js module code (L46–L124)](r1-tooling-treeshake.md#u-65c13f088150)

**Uncertainties.**

- If the marker is not found inside the ±500-character slice, findIndex returns -1 and the '>' mark and slice indices operate on a -1 target, producing misleading context output

<a id="u-351ac66b7b34"></a>
### `bundle_code.resolveId`

`const bundle = await rollup({ input: '__entry__', plugins: [ virtual({ __entry__: ent…` · [packages/svelte/scripts/check-treeshakeability.js:L13-L26][f1]

Rollup resolveId hook mapping bare 'svelte*' specifiers to local files.

If the importee does not start with 'svelte' it returns undefined, deferring to nodeResolve. Otherwise it replaces the leading 'svelte' with '.' to index pkg.exports and resolves the browser entry when present, else the default entry, returning its absolute path.

**Uncertainties.**

- A 'svelte'-prefixed specifier missing from pkg.exports yields undefined and the property access on it would throw

<a id="u-65c13f088150"></a>
### `check-treeshakeability.js module code (L46–L124)`

`module_region` · [packages/svelte/scripts/check-treeshakeability.js:L46-L124][f1]

Top-level treeshakeability check: bundles every svelte package export and verifies each shakes away to nothing, then probes a feature-heavy client bundle for residual code.

For each pkg.exports key except './compiler', './internal', './internal/disclose-version', './internal/flags/legacy', and './internal/flags/tracing', and for each present 'browser'/'default' condition, it bundles an import of the resolved entry: empty output logs ✅, otherwise it logs the residual code, marks ❌, and sets failed. It then bundles the compiled JS of a Svelte component exercising hydration, bindings, each/await/key blocks, snippets, and html/component/element tags, and runs check_bundle for hydration, legacy, and $inspect.trace markers. On failure it writes the bundle to scripts/_bundle.js and, after console.groupEnd, exits with status 1.

calls: [packages/svelte/scripts/check-treeshakeability.js:bundle_code](r1-tooling-treeshake.md#u-8afde5f8f2a5), [check_bundle](r1-tooling-treeshake.md#u-be696749d63c)

**Uncertainties.**

- A thrown Error('errr what') from bundle_code aborts the whole script; nothing here catches it

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/scripts/check-treeshakeability.js
