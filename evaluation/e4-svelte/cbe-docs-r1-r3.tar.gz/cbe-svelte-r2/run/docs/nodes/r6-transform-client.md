# Client Transform

**Capability.** Transforms component and module analyses into client-side programs, lowering directives, attributes, special elements, reactive statements, and state declarations into runtime calls and template builders.

Use for how Svelte source becomes DOM-manipulating code. client_component/client_module are entry points; visitors queue bind_*/event/const/head/title output into state buckets; VariableDeclaration branches on runes vs legacy mode.

**Children.**

- [Client Transform State Types](r6-transform-client-types.md) `r6-transform-client-types` · 11 unit(s)

**Depends on.**

- [Client Transform State Types](r6-transform-client-types.md) · containment · → 0 / ← 0 edge(s) (ancestor direct units and descendant subtree; → follows ` r6-transform-client ` → ` r6-transform-client-types `)
- [Client signal builders](r2-client-signal-builders.md) · graph-only · 14 edge(s)
- [Scope and Node Model](r3-scope-node-model.md) · graph-only · 11 edge(s)

Parent: [Code Generation](r6-compiler-transform.md)

## Units (19)

<a id="u-15bd8cef14fb"></a>
### `client_component`

`export function client_component(analysis, options)` · [packages/svelte/src/compiler/phases/3-transform/client/transform-client.js:L148-L698][f1]

Transforms a full component analysis into a client-side ESTree.Program containing one exported component function.

It first walks the module AST with an initial state (seeded with a `svelte/internal/client` namespace import), then reuses accumulated `transform` state to walk the instance AST (with `is_instance: true`), then the template AST using instance scopes. It then assembles the component block: legacy reactive declarations become `$.mutable_source` consts; store subscriptions get `$.setup_stores` init plus `$.store_get` thunks (wrapped with `$.validate_store` in dev) and set a cleanup flag; legacy `$:` statements are appended (throwing 'Could not find reactive statement' if one is missing) followed by `$.legacy_pre_effect_reset`; binding groups become array consts. The returned component object is built from exports: let/var identifiers get getter+setter pairs, non-dev const-ish identifiers become inits, prop/bindable props get `name($$value)` setters, state gets `$.set` (with `$.proxy` for reactive state), otherwise just a getter. When `analysis.accessors` is set, prop/bindable props also get getter/setter pairs (setters flush; runes-mode setters default `$$value` to the binding initial). `componentApi === 4` adds `$set`/`$on`; otherwise dev mode spreads `$.legacy_api`. Body layout differs for `has_await`: instance body, exports assignment, an `$.aborted` early return, and template body go inside an `$.async_body` arrow; otherwise they are inlined and `$.init` runs for non-runes legacy components needing context. Various blocks are unshifted conditionally: ownership validator, legacy `bind_prop` exports (non-runes only), `$$restProps`/`$$sanitized_props`, `$$slots`, `$$props_id` (first line, for hydration), `new.target` checks, and injected CSS via `render_stylesheet` plus `$.append_styles`. When context is injected, `$.push`/`$.pop` wrap the body, with `$$pop`/`$$cleanup` ordering so store cleanup runs last. Imports are hoisted to the top preserving order, module snippets next. HMR mode appends an `import.meta.hot.accept` handler swapping sources (and cleaning styles if a CSS hash exists) plus a default export; otherwise just a default export. Dev mode tags the function with `$.FILENAME`; feature flags (async, legacy, tracing, disclose-version) prepend flag imports; collected events emit a `$.delegate` call. Custom-element options build a `$.create_custom_element` call with prop metadata (defaulting boolean-literal initials to type 'Boolean'), slot and accessor lists, shadow-DOM usage (`true` unless `shadow === 'none'` for object configs), and either `customElements.define` (guarded when HMR) or a bare call. Returns the final module Program.

**Notes.**

- failure: Throws new Error('Could not find reactive statement') when a reactive statement node lacks a matching transformed statement in state.legacy_reactive_statements.
- side_effect: Mutates node.metadata.hoisted-like state indirectly through visitors; locally it mutates component_block.body ordering via repeated unshift, so emission order depends on the sequence of conditional blocks.

calls: [render_stylesheet](r4-css-transform.md#u-197b2d45aa0c), [build_getter](r2-client-signal-builders.md#u-66a19e20e1f1); uses: [transform-client.js module code (L1–L147)](r6-transform-client.md#u-b1b779bca6fc)

**Uncertainties.**

- The exact final statement ordering results from many unshift/push interleavings; the emitted order for every flag combination was not independently verified.
- init/consts/update/template state fields are typed as any and populated by the Fragment visitor; their exact production is outside this file.

<a id="u-1e0775efa9e3"></a>
### `client_module`

`export function client_module(analysis, options)` · [packages/svelte/src/compiler/phases/3-transform/client/transform-client.js:L705-L734][f1]

Transforms a `<script module>` analysis into a client-side module Program.

It builds a minimal ClientTransformState (module scope, empty transform and state_fields, no instance context), walks the module AST with the shared visitors map, and returns a Program whose body starts with `import * as $ from 'svelte/internal/client'`, optionally adds the `svelte/internal/flags/tracing` import when `analysis.tracing` is set, followed by all transformed module statements. Unlike client_component there is no instance/template walk, no push/pop lifecycle, and no export assembly.

<a id="u-b1b779bca6fc"></a>
### `transform-client.js module code (L1–L147)`

`module_region` · [packages/svelte/src/compiler/phases/3-transform/client/transform-client.js:L1-L147][f1]

Defines the visitor map driving client-side Svelte transformation, plus the imports and a `set_scope` handler for the `_` key.

When entering a node whose scope differs from the current state scope, `set_scope` copies `state.transform` and deletes entries for names declared in that scope where the binding is `normal`, or `state` but not a state source per `is_state_source` — so re-declared or never-reassigned `$state` names stop being rewritten; it then calls `next` with the narrowed transform and new scope. If the scope matches or is absent it calls `next` unchanged. All other keys map directly to the imported per-node-type visitor functions.

calls: [is_state_source](r2-client-signal-builders.md#u-4eba3d9b7ec5)

<a id="u-6e308e3d6c2c"></a>
### `transform-client.js module code (L698–L704)`

`module_region` · [packages/svelte/src/compiler/phases/3-transform/client/transform-client.js:L698-L704][f1]

Residual lines between client_component and client_module; the source shows only the JSDoc comment annotating client_module.

<a id="u-0ec3860847c4"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/Attribute.js:Attribute`

`export function Attribute(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/Attribute.js:L10-L14][f2]

Handles regular attributes: when is_event_attribute identifies the attribute as an on<event> handler it forwards to visit_event_attribute; all other attributes produce nothing in this visitor, implying they are handled elsewhere.

calls: [visit_event_attribute](r4-client-transform.md#u-8ff2bf148b08)

<a id="u-e55ab0a7d69f"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/BindDirective.js:BindDirective`

`export function BindDirective(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/BindDirective.js:L15-L260][f3]

Lowers a `bind:` directive into the appropriate `$.bind_*` runtime call and schedules it in the correct statement queue.

The bound expression is visited; a SequenceExpression is split into a get/set pair, otherwise get is a thunk of the expression and set is an arrow assigning `$$value` back through the expression, with set dropped when unthunking makes it identical to get. In dev runes mode `validate_binding` runs when the expression is a MemberExpression that is not `bind:this`, or is `bind:this` nested inside an IfBlock/EachBlock/AwaitBlock/KeyBlock, unless the `binding_property_non_reactive` warning is ignored. When `binding_properties[node.name].event` exists a generic `$.bind_property` call is emitted; otherwise a name switch selects specialized helpers for window bindings (online, scrollX/Y, inner/outer sizes, activeElement), media bindings (muted through readyState), resize/element size (via `$.bind_resize_observer`/`$.bind_element_size`), `value` (as `$.bind_select_value` when the parent element is a `<select>`), files, `this` (via `build_bind_this`), content-editable bindings, checked, focused, and group; unknown names throw `Error('unknown binding ' + name)`. For `group`, index references from parent each blocks are wrapped in `$.get` when the block is keyed, and when the parent element has a non-text `value` attribute the group getter becomes a thunk that first evaluates that value attribute so value changes re-trigger group updates. Scheduling: `bind:this` goes to `init`; other bindings on elements with a `use:` directive are wrapped in `$.effect` in `init`, else pushed to `after_update` so they run after attribute updates in order with events/actions.

**Notes.**

- failure: An unrecognized binding name throws 'unknown binding <name>' at transform time.

calls: [build_bind_this](r5-client-transform.md#u-62396233e782), [validate_binding](r5-client-transform.md#u-91b59b999e05), [state.js-module-level-compiler-state](r2-compiler-infrastructure.md#u-d73d7b033038), [is_text_attribute](r5-compiler-utilities.md#u-ec400088cae5), [build_attribute_value](r3-client-transform.md#u-2462157783c9)

**Uncertainties.**

- get === set after b.unthunk relies on builder identity semantics defined elsewhere
- binding_properties table contents live in bindings.js and are not shown

<a id="u-66fd01a83c22"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/ConstTag.js:ConstTag`

`export function ConstTag(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/ConstTag.js:L15-L91][f4]

Serializes {@const name = expr} into derived constants registered in state.consts with a get_value transform.

For a simple Identifier declarator: the initializer is built via build_expression under in_derived state, wrapped in create_derived (awaited when metadata.expression.has_await), `$.tag`-wrapped in dev, pushed as a const declaration, its transform set to get_value, and in dev an eager `$.get(name)` statement is pushed to surface 'before initialization' errors. For destructuring patterns: identifiers declared by the pattern are removed from a copied transform (they are not signals in that scope), the initializer is built in that child state, and a derived block declares the visited pattern from init and returns an object of the identifiers; the result is stored in a generated `computed_const` temp (tagged '[@const]' in dev, eagerly read in dev), and each identifier's transform reads `$.get(tmp).<id>`.

calls: [create_derived](r2-client-signal-builders.md#u-d8c62e2be238), [build_expression](r5-client-transform.md#u-cd5eb51d389f), [extract_identifiers](r5-compiler-utilities.md#u-90eb95affc00)

<a id="u-e62b6e822f4a"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/FunctionExpression.js:FunctionExpression`

`export function FunctionExpression(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/FunctionExpression.js:L9-L11][f5]

Delegates function expression nodes to the shared visit_function helper; all transformation logic lives there.

calls: [packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/function.js:visit_function](r5-client-transform.md#u-888d94f48ee5)

<a id="u-2b757b558903"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/ImportDeclaration.js:ImportDeclaration`

`export function ImportDeclaration(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/ImportDeclaration.js:L9-L16][f6]

Hoists imports out of the component body: when the current state carries a 'hoisted' array, the declaration is pushed there and replaced with b.empty; otherwise the default visitor chain continues.

**Uncertainties.**

- The non-hoisted path's outcome depends on the visitor driver outside this file.

<a id="u-5cb26cf0f344"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/LabeledStatement.js:LabeledStatement`

`export function LabeledStatement(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/LabeledStatement.js:L11-L64][f7]

Handles Svelte 4 `$:` reactive labels.

Labels in runes mode, nested statements (path length > 1), or labels other than `$` fall through to context.next(). The matching ReactiveStatement is looked up in the analysis; if absent (not the instance context) the node is dropped. The body is visited and coerced to a block. Each visible dependency becomes a getter in a sequence, except plain non-import bindings are skipped; `$$props`, `$$restProps`, and bindable_prop bindings are deep-read via `$.deep_read_state` because fine-grained state from runes components would otherwise miss updates. The whole thing is stored as a `$.legacy_pre_effect(depsThunk, bodyThunk)` statement in state.legacy_reactive_statements (topologically ordered later), and b.empty is returned so the statement is removed in place.

calls: [build_getter](r2-client-signal-builders.md#u-66a19e20e1f1)

<a id="u-cf6eda1c83ef"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/MemberExpression.js:MemberExpression`

`export function MemberExpression(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/MemberExpression.js:L9-L23][f8]

Rewrites private-state field access.

For a PrivateIdentifier property that matches a known state field ('#' + name in state_fields), inside a constructor the field is read directly as member '.v' only for $state and $state.raw fields; all other cases (and always outside constructors) read through $.get(node). Unknown private names fall through to context.next().

**Uncertainties.**

- Behavior for private methods or fields absent from state_fields is left to context.next() and is not shown here.

<a id="u-3abb91ec17dc"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/OnDirective.js:OnDirective`

`export function OnDirective(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/OnDirective.js:L19-L38][f9]

Serializes an `on:` directive into an event-registration expression.

When the directive has no expression it sets `context.state.analysis.needs_props = true`, forcing prop forwarding so the event can be forwarded. The handler is built via `build_event_handler`, then wrapped in `$.<modifier>` calls for each present modifier in the fixed order stopPropagation, stopImmediatePropagation, preventDefault, self, trusted, once. Finally it returns `build_event(node.name, context.state.node, handler, capture, passive)`: capture is true only with the `capture` modifier; passive is true with `passive`, explicitly false with `nonpassive`, otherwise undefined.

calls: [build_event](r4-client-transform.md#u-0bee50cc5235)

**Uncertainties.**

- Runtime semantics of the `$.` modifier wrapper calls are defined elsewhere; only the wrapping order and structure are visible here.

<a id="u-7506ce95c563"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/SpreadAttribute.js:SpreadAttribute`

`export function SpreadAttribute(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/SpreadAttribute.js:L8-L10][f10]

Compiles a spread attribute by simply visiting and returning its expression; no wrapper is added here.

**Uncertainties.**

- How the returned expression is consumed by the enclosing element visitor is not visible in this file.

<a id="u-3c05d4ae0c14"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/SvelteBody.js:SvelteBody`

`export function SvelteBody(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/SvelteBody.js:L9-L11][f11]

Compiles <svelte:body> by delegating to visit_special_element with the target expression '$.document.body'.

calls: [visit_special_element](r1-compiler-transform-client.md#u-5f6160c62286)

<a id="u-41ee72c88b7f"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/SvelteHead.js:SvelteHead`

`export function SvelteHead(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/SvelteHead.js:L10-L20][f12]

Compiles <svelte:head> into an init statement calling $.head with an arrow function taking $$anchor whose body is the visited fragment, so head content renders through that callback.

**Uncertainties.**

- Attributes on <svelte:head> are not processed here, as the TODO comment notes.

<a id="u-d6475f075d4a"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/TitleElement.js:TitleElement`

`export function TitleElement(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/TitleElement.js:L10-L23][f13]

Compiles <title> by building its content chunk with build_template_chunk, yielding a value expression and a has_state flag, then emitting an assignment of that value to $.document.title.

When the content is dynamic (has_state) the statement is pushed into state.update so it re-runs on changes; otherwise it goes into state.init for one-time execution.

calls: [build_template_chunk](r5-client-transform.md#u-d8d503fc4b7b)

<a id="u-f9615b35110b"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/VariableDeclaration.js:VariableDeclaration`

`export function VariableDeclaration(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/VariableDeclaration.js:L17-L131][f14]

Serializes a variable declaration, branching on runes mode.

In runes mode each declarator is dispatched by its rune: non-state runes ($effect.tracking, $effect.root, $inspect*, $state.snapshot, $host) or missing runes pass through normally, except hoisted function initializers which are pushed to context.state.hoisted as consts; `$props.id` is skipped. `$props` serializes to `$.rest_props($$props, [seen names])` for an Identifier declarator (rest name appended in dev for error messages), or, for an ObjectPattern, per-property: bindable-prop initial values are wrapped in `$.proxy` (and `$.tag_proxy` in dev) when should_proxy says so, and properties that are prop sources get `get_prop_source` declarations; RestElements also become `$.rest_props` calls with all previously seen names excluded. `$state`/`$state.raw` declarations wrap values in `$.proxy` (plus `$.tag_proxy` in dev for non-state bindings) when should_proxy applies, then `$.state` (plus `$.tag` in dev) for state sources; destructured patterns get a `tmp` binding, `$.derived` inserts named `$$array*` registered in context.state.transform with get_value readers, and per-path declarations recursing into create_state_declarator for state bindings. `$derived`/`$derived.by` produce `$.derived` calls (thunked for `$derived`); async deriveds (present in analysis.async_deriveds) become `$.async_derived` awaited through `$.save`, with a dev-only location literal unless the `await_waterfall` warning is ignored. Non-identifier `$derived` patterns share a `$$d` derived when the rune is not `$derived` with a plain identifier argument, otherwise each path gets its own derived; all get dev `$.tag` labels like `[$derived object]`.

**Notes.**

- side_effect: Insert declarators mutate id.name via scope.generate and register readers in context.state.transform.

calls: [get_rune](r3-scope-node-model.md#u-5204b6ce4f7a), [get_prop_source](r2-client-signal-builders.md#u-d03f333899de); uses: [is_prop_source](r2-client-signal-builders.md#u-38b8a75ee741), [should_proxy](r2-client-signal-builders.md#u-d089d4da67c8), [is_hoisted_function](r2-transform-shared.md#u-b9dd511b4830), [packages/svelte/src/compiler/phases/3-transform/client/visitors/VariableDeclaration.js:VariableDeclaration (2)](r6-transform-client.md#u-39f817804cf0)

**Uncertainties.**

- The `$props` ObjectPattern branch asserts the id type; a non-ObjectPattern, non-Identifier id would fail via assert.equal, whose throwing behavior lives in assert.js.
- The local `create_state_declarator` closure is folded here; its rune capture ($state vs $state.raw) is fixed per invocation of the enclosing branch.

<a id="u-39f817804cf0"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/VariableDeclaration.js:VariableDeclaration (2)`

`export function VariableDeclaration(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/VariableDeclaration.js:L155-L397][f14]

Legacy (non-runes) half of the same visitor, plus the shared return path.

Each declarator's bindings are inspected: if none are state or bindable_prop, hoisted function initializers go to context.state.hoisted as consts and everything else is visited normally. Bindable-prop declarators become `get_prop_source` declarations keyed by prop_alias or the source name; destructured export-let patterns use a `tmp` binding with `$.derived` inserts and per-path prop sources for bindable_prop leaves. State declarators delegate to create_state_declarators. Finally, if no declarations were produced (e.g. everything was skipped or hoisted) the visitor returns `b.empty`; otherwise it returns the node with the rewritten declarations.

**Notes.**

- condition: A declaration containing both state and bindable_prop bindings takes the has_props branch first; the state bindings of that declarator are not separately handled in the legacy path.

calls: [get_prop_source](r2-client-signal-builders.md#u-d03f333899de), [Scope](r3-scope-node-model.md#u-01a82e58170d), [state.js-module-level-compiler-state](r2-compiler-infrastructure.md#u-d73d7b033038), [extract_paths](r5-compiler-utilities.md#u-34f2fcb20c62), [create_state_declarators](r6-transform-client.md#u-ce9e3badaf1d); uses: [is_hoisted_function](r2-transform-shared.md#u-b9dd511b4830)

**Uncertainties.**

- The inventory splits one function into two segments (s0/s1); their exact split point inside the shared body is not observable from the listing, so rune-mode and legacy-mode coverage was assigned by content.

<a id="u-ce9e3badaf1d"></a>
### `create_state_declarators`

`function create_state_declarators(declarator, context, value)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/VariableDeclaration.js:L405-L439][f14]

Creates the output for a legacy-mode state declaration.

For an Identifier declarator it returns a single declarator wrapping the value in `$.mutable_source`, passing `true` as the second argument when analysis is immutable. For destructured patterns it emits a `tmp` declarator, then `$.derived` inserts named `$$array*` (registered in context.state.transform with get_value readers), then per-path declarations: paths whose binding is `state` get their own `$.mutable_source` (immutable-aware), all others keep the plain visited expression.

calls: [Scope](r3-scope-node-model.md#u-01a82e58170d), [extract_paths](r5-compiler-utilities.md#u-34f2fcb20c62)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/transform-client.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/Attribute.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/BindDirective.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/ConstTag.js
[f5]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/FunctionExpression.js
[f6]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/ImportDeclaration.js
[f7]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/LabeledStatement.js
[f8]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/MemberExpression.js
[f9]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/OnDirective.js
[f10]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/SpreadAttribute.js
[f11]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/SvelteBody.js
[f12]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/SvelteHead.js
[f13]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/TitleElement.js
[f14]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/VariableDeclaration.js
