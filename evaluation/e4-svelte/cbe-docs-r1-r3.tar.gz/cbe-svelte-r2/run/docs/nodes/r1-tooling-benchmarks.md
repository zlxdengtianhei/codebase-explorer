# Reactivity Benchmarks

**Capability.** Times reactivity propagation through synthetic derived graphs: a linear 50-deep chain and a triangular chain with a running sum, each with fixed module constants and iteration counts.

Read these to compare graph-shape performance; they are benchmarks only, not shipped or tested runtime code.

**Depends on.**

- [Client Runtime](r1-client-runtime.md) · model-inferred · 0 edge(s)
- [Benchmark Harness](r4-benchmark-harness.md) · graph-only · 9 edge(s)

Parent: [Repo Tooling & Benchmarks](r1-tooling.md)

## Units (2)

<a id="u-08f0cffb8cef"></a>
### `kairo_deep-js`

`function setup()` · [benchmarking/benchmarks/reactivity/kairo/kairo_deep.js:L7-L27][f1]

Builds a linear 50-deep derived chain (module constants len=50, iter=50) and times propagations through it.

setup() starts from state head and loops len times, each derived adding 1 to the previous via a captured closure variable; a render_effect inside $.effect_root reads the final derived and increments a counter. run() flushes head=1, resets counter, then for i=0..iter-1 flushes head=i and asserts get(current)===len+i, finally asserting counter===iter (the effect ran once per flush). kairo_deep_unowned runs 10 un-timed JIT-warmup setup/run/destroy cycles, then awaits fastest_test(10, 1000 run() calls), destroys and returns {benchmark, time, gc_time} via toFixed(2). kairo_deep_owned performs the warmup and retains one setup inside a single $.effect_root (destroy_owned), assigns run/destroy to outer variables, times identically, then tears down with destroy() and destroy_owned().

uses: [assert](r4-benchmark-harness.md#u-823bd0dd0cd8); calls: [fastest_test](r4-benchmark-harness.md#u-0bbe8c671495)

<a id="u-99bc9e7f53ac"></a>
### `kairo_triangle-js`

`function count(number)` · [benchmarking/benchmarks/reactivity/kairo/kairo_triangle.js:L6-L11][f2]

Triangular dependency chain: module constant width=10, a growing chain of deriveds where each link is also accumulated into a sum.

count(number) builds [1..number] and reduces to the triangular sum (count(10)===55). setup() walks current from head through width deriveds each adding 1, pushing every prior link (including head) into list; sum is a derived reducing get over list; a render_effect reads sum and increments a counter. run() computes constant=count(width), flushes head=1 asserting sum===constant, resets counter, then for i=0..99 flushes head=i and asserts sum===constant-width+i*width, finally asserting counter===100. kairo_triangle_unowned does 10 JIT-warmup setup/run/destroy cycles, awaits fastest_test(10, 1000 run() calls), destroys and returns {benchmark, time, gc_time} with toFixed(2). kairo_triangle_owned keeps warmup plus the retained setup in one $.effect_root (destroy_owned), assigns run/destroy to outer variables, times identically, then calls destroy() and destroy_owned().

uses: [assert](r4-benchmark-harness.md#u-823bd0dd0cd8); calls: [fastest_test](r4-benchmark-harness.md#u-0bbe8c671495)

**Uncertainties.**

- The exact sum for head values other than 0..1 is only implied by the assertion formula; the chain includes head itself in list, which the formula accounts for.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/benchmarking/benchmarks/reactivity/kairo/kairo_deep.js
[f2]: ../../../../../../eval/svelte-be645b4/benchmarking/benchmarks/reactivity/kairo/kairo_triangle.js
