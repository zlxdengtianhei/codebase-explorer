# Warning Codegen Template

**Capability.** Template used by the process-messages script to generate the compile-warning module: the warning class, the central w() filter deciding whether warnings are recorded, and the CODE template emitting the per-warning factory functions.

Use this when regenerating or auditing compiler warning machinery. CODE templates the generated throwers; w() is the filtering gate the generated code calls.

**Depends on.**

- [Compiler Public API and Pipeline](r5-compiler-pipeline.md) · model-inferred · 0 edge(s)

Parent: [Svelte Monorepo](r5-svelte-monorepo.md)

## Units (3)

<a id="u-cb8e8c3375b1"></a>
### `InternalCompileWarning`

`class InternalCompileWarning extends CompileDiagnostic` · [packages/svelte/scripts/process-messages/templates/compile-warnings.js:L6-L14][f1]

CompileDiagnostic subclass representing a single compile warning.

It only adds an enumerable name field 'CompileWarning' and a constructor forwarding code, message, and position to super; no extra state or methods.

<a id="u-664df6361e22"></a>
### `w`

`function w(node, code, message)` · [packages/svelte/scripts/process-messages/templates/compile-warnings.js:L24-L40][f1]

Central filter deciding whether a compile warning is recorded.

It picks the ignore stack: the node's entry in ignore_map when the node has one, otherwise the current ignore_stack. If a stack exists and its top set contains the code, the warning is dropped. It then constructs an InternalCompileWarning with position [node.start, node.end ?? node.start] when node.start is defined, else undefined, and returns without recording if warning_filter rejects the warning; otherwise it pushes the warning onto the shared warnings collection.

**Uncertainties.**

- ignore_stack, ignore_map, warning_filter, and warnings come from ./state.js, outside this file; their exact semantics are not verifiable here

<a id="u-ae2811903bcd"></a>
### `packages/svelte/scripts/process-messages/templates/compile-warnings.js:CODE`

`export function CODE(node, PARAMETER)` · [packages/svelte/scripts/process-messages/templates/compile-warnings.js:L49-L51][f1]

Template for generated compile-warning functions.

After generation it calls w(node, '<CODE>', message plus svelte.dev/e/CODE link) with the message interpolated; it returns normally since warnings are recorded rather than thrown. Also exposes `export const codes = CODES`, which the generator replaces with the literal list of warning codes.

calls: [w](r5-warnings-codegen.md#u-664df6361e22)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/scripts/process-messages/templates/compile-warnings.js
