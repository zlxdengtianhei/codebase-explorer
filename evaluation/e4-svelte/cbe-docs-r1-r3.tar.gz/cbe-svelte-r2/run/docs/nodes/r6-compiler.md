# Compiler Pipeline

**Capability.** Turns Svelte source into executable code through three phases — parsing into a template/JS AST, semantic analysis with validation and warnings, and client/server code generation — supported by compiler infrastructure such as source maps and ignore-comment handling.

Traverse the parse, analyze, and transform subtrees for phase-specific logic; the infra subtree holds cross-phase utilities. AST type declarations document intermediate representations shared across phases.

**Children.**

- [Compiler AST Declarations](r6-compiler-ast-types.md) `r6-compiler-ast-types` · 2 unit(s)
- [Template Parsing](r6-compiler-parse.md) `r6-compiler-parse` · 13 unit(s)
- [Semantic Analysis](r6-compiler-analyze.md) `r6-compiler-analyze` · 19 unit(s)
- [Code Generation](r6-compiler-transform.md) `r6-compiler-transform` · 0 unit(s)
- [Compiler Infrastructure](r6-compiler-infra.md) `r6-compiler-infra` · 18 unit(s)

**Depends on.**

- [Compiler Infrastructure](r6-compiler-infra.md) · containment · → 0 / ← 0 edge(s) (ancestor direct units and descendant subtree; → follows ` r6-compiler ` → ` r6-compiler-infra `)

Parent: [Svelte Monorepo](r6-svelte-monorepo.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
