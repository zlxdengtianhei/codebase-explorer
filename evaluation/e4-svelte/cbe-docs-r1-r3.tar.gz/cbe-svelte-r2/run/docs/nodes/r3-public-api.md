# Public API Surface and Types

**Capability.** Defines what consumers import: the server entry with no-op client APIs and server-side lifecycle hooks, plus the type declarations for both component models, snippets, event dispatching, and mount options.

Use this subtree for API contracts. index-server shows which client APIs are unavailable on the server; index.d.ts is the single source of truth for component, snippet, and mounting types, including deprecated Svelte 4 shapes.

Parent: [Client Runtime](r3-runtime.md)

## Units (9)

<a id="u-529cfef18850"></a>
### `index-server-js-stubs`

`export function createEventDispatcher()` · [packages/svelte/src/index-server.js:L20-L22][f1]

Server entry module exporting no-op and unavailable client APIs.

`createEventDispatcher` returns `noop`, so dispatched events do nothing on the server. `mount`, `hydrate` and `unmount` all throw `e.lifecycle_function_unavailable(name)`. `tick` and `settled` are async no-ops. beforeUpdate, afterUpdate, onMount and flushSync are re-exported as `noop` from shared utils; context getters/setters, getAbortSignal and createRawSnippet are re-exported from server internals.

<a id="u-3d10206fb345"></a>
### `packages/svelte/src/index-server.js:onDestroy`

`export function onDestroy(fn)` · [packages/svelte/src/index-server.js:L7-L10][f1]

Server-side onDestroy: casts `current_component` to a Component and appends `fn` to its `d` array, lazily creating the array with `??=`.

This is the only lifecycle function that runs inside a server component, per its docstring.

**Uncertainties.**

- When `current_component` is null/undefined this would throw on property access; no guard is present.

<a id="u-ea3468a96368"></a>
### `index.d.ts-type-utilities`

`type Brand<B> = { [brand]: B };` · [packages/svelte/src/index.d.ts:L111-L111][f2]

Utility types over the two component models.

Brand/Branded create a nominal brand via a unique symbol; ComponentInternals is the branded empty object type Svelte passes as a component's first argument. ComponentEvents extracts the Events record from a SvelteComponent subclass via conditional inference, resolving to never otherwise. ComponentProps extracts Props from either a SvelteComponent class or a modern Component function type, falling back to never. ComponentType describes a constructable legacy component whose constructor accepts ComponentConstructorOptions over inferred Props, with an optional static element for custom elements. SvelteComponentTyped is a deprecated empty subclass of SvelteComponent preserved as an alias.

<a id="u-383c0c7ebdb5"></a>
### `index.d.ts-legacy-class-component-types`

`export interface ComponentConstructorOptions< Props extends Record<string, any> = Rec…` · [packages/svelte/src/index.d.ts:L11-L24][f2]

Types supporting the deprecated Svelte 4 class-component model.

ComponentConstructorOptions enumerates the options accepted by the legacy constructor: target (required), anchor, props, context, hydrate, intro, recover, sync, idPrefix, and internal flags. Properties augments a Props type with an optional children property when the Slots type has a default slot, collapsing to any when Props accepts no props, a trade-off the source comments attribute to TypeScript index-signature behavior. These feed the SvelteComponent and ComponentType declarations.

<a id="u-b1437bddcaf3"></a>
### `index.d.ts-event-dispatcher`

`interface DispatchOptions` · [packages/svelte/src/index.d.ts:L298-L300][f2]

Declares the createEventDispatcher result.

DispatchOptions carries an optional cancelable flag. The dispatcher is callable with a Type key of the event map plus a parameter and options; the parameter tuple shape depends on the event's type: if the mapped type includes null the parameter is optional (null, undefined, and a missing parameter are treated equivalently, matching CustomEvent's behavior of a null detail), otherwise it is required. Returns a boolean indicating whether the event was not cancelled — per the implementation notes, the undefined-extends formulation works in both strict and non-strict mode.

<a id="u-4400c2aaf924"></a>
### `packages/svelte/src/index.d.ts:SvelteComponent`

`class SvelteComponent< Props extends Record<string, any> = Record<string, any>, Event…` · [packages/svelte/src/index.d.ts:L45-L59][f2]

Type-only declaration of the Svelte 4 component base class, retained for backwards compatibility; Svelte 5 components are functions and new code should use Component and mount.

The class is generic over Props, Events, and Slots, carries an index signature so any property access type-checks, and declares a static element member present only when compiled with the customElement option. The constructor exists only via the asClassComponent compatibility helper and takes ComponentConstructorOptions with props augmented by a children property when a default slot exists (via Properties). $destroy tears the component down, $on subscribes to a declared event and returns an unsubscribe function, and $set applies a partial props update. The $$prop_def, $$events_def, $$slot_def, and $$bindings fields are typing-only and do not exist at runtime.

**Uncertainties.**

- This is a declaration file; no runtime behavior is implemented here.

<a id="u-e62b7cb5d771"></a>
### `packages/svelte/src/index.d.ts:Component`

`export interface Component< Props extends Record<string, any> = {}, Exports extends R…` · [packages/svelte/src/index.d.ts:L141-L160][f2]

Declares the modern Svelte 5 component type: a callable interface invoked as (internals, props) returning the component's Exports intersected with optional legacy $on and $set methods.

The internals parameter is a branded ComponentInternals reserved for Svelte's own use. The interface also carries an optional static element member for custom-element compilation and a typing-only z_$$bindings field that does not exist at runtime. Bindings is constrained to keys of Props or the empty string.

<a id="u-9a51a53c2a0b"></a>
### `Snippet`

`export interface Snippet<Parameters extends unknown[] = []>` · [packages/svelte/src/index.d.ts:L286-L296][f2]

Declares the type of a #snippet block: a callable taking the snippet's declared parameters as a tuple and returning a branded error object.

The rest-parameter condition number extends Parameters['length'] ? never : Parameters deliberately rejects plain array types so rest-parameter-style snippets do not type-check, since only tuples are supported. The return type is an object whose only key is an error message pointing users to import the Snippet type, so snippets can only be invoked through the {@render ...} tag; calling them like functions produces that message.

<a id="u-91fbf567d3ba"></a>
### `MountOptions`

`export type MountOptions<Props extends Record<string, any> = Record<string, any>> = {…` · [packages/svelte/src/index.d.ts:L318-L353][f2]

Defines the options accepted by the mount() function: a required target (Document, Element, or ShadowRoot), optional anchor node to render before, deprecated events record superseded by callback props, optional context Map accessible via getContext, and intro controlling initial-render transitions with a documented default of true.

props is optional only when Props is the empty object type; for any non-empty props type the intersection makes props required, so callers must supply the component's props.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/index-server.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/index.d.ts
