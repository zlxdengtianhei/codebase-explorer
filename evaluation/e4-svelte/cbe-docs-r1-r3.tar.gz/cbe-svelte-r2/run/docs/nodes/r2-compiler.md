# Compiler

**Capability.** Owns the full source-to-output compilation: template parsing, CSS pruning analysis, client and server code generation, diagnostics/warnings and options validation, and the compiler's type surface.

Use this subtree to understand how a Svelte file becomes compiled code. Parsing, CSS analysis, code generation and diagnostics infrastructure are separated so each can be read independently. Consumers outside the compiler (script tooling) depend on narrow units such as the Program visitor.

**Children.**

- [Template parser](r2-parse.md) `r2-parse` · 19 unit(s)
- [CSS pruning analysis](r2-css-prune.md) `r2-css-prune` · 18 unit(s)
- [Client code generation](r2-client-transform.md) `r2-client-transform` · 0 unit(s)
- [Server element serialization](r2-server-element-transform.md) `r2-server-element-transform` · 1 unit(s)
- [Diagnostics, state and validation infrastructure](r2-compiler-infrastructure.md) `r2-compiler-infrastructure` · 15 unit(s)
- [Compiler type surface](r2-compiler-types.md) `r2-compiler-types` · 5 unit(s)

Parent: [Svelte framework](r2-svelte.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
