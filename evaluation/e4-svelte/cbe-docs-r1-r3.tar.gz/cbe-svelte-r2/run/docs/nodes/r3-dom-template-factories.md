# DOM Template Factories

**Capability.** Builds and clones template fragments for html, svg, mathml, and programmatic trees, managing namespaces, comment/text anchors, block boundary recording, and script re-execution in cloned markup.

Use this subtree to understand how generated code obtains DOM nodes cheaply. The from_* factories cache and clone templates; assign_nodes records block boundaries on the active effect, so it depends on the effect engine.

**Depends on.**

- [Client Runtime DOM](r5-runtime-dom.md) · graph-only · 17 edge(s)

**Depended on by.**

- [Component Mounting](r3-component-mounting.md) · graph-confirmed · 1 edge(s)
- [Element Bindings, Actions, and Custom Elements](r3-element-bindings.md) · graph-confirmed · 1 edge(s)

Parent: [Client Runtime](r3-runtime.md)

## Units (13)

<a id="u-7aedb33d1cff"></a>
### `from_html`

`export function from_html(content, flags)` · [packages/svelte/src/internal/client/dom/template.js:L43-L82][f1]

Builds a factory for HTML templates.

The returned function, when hydrating, assigns the current hydrate_node as the block boundary and returns it without creating anything. Otherwise it lazily parses the content once via create_fragment_from_html, prefixing `<!>` when the content does not already start with one so a start anchor comment exists; non-fragment templates reduce the fragment to its first child. Each call clones the cached node — via importNode when the flag is set or on Firefox, else cloneNode(true) — and assigns boundaries: first/last child for fragments, the clone itself for single nodes.

calls: [create_fragment_from_html](r6-client-dom-blocks.md#u-f51e86a3ef3c), [assign_nodes](r3-dom-template-factories.md#u-081194bea535), [get_first_child](r5-runtime-dom.md#u-fa05927498af)

<a id="u-7fbca348f563"></a>
### `from_namespace`

`function from_namespace(content, flags, ns = 'svg')` · [packages/svelte/src/internal/client/dom/template.js:L91-L137][f1]

Builds a factory for svg/math templates by wrapping content in `<svg>` or `<math>` tags (prefixing `<!>` when no start comment marker is present) so the browser parses it in the right namespace.

Hydrating, the returned function just assigns hydrate_node and returns it. Otherwise it lazily parses once: for fragments it moves all children of the namespace root into a fresh DocumentFragment, for single nodes it takes the root's first child. Each call clones the cached node and assigns first/last-child boundaries for fragments or the clone itself otherwise.

calls: [create_fragment_from_html](r6-client-dom-blocks.md#u-f51e86a3ef3c), [assign_nodes](r3-dom-template-factories.md#u-081194bea535)

<a id="u-2810c009cb53"></a>
### `from_svg`

`export function from_svg(content, flags)` · [packages/svelte/src/internal/client/dom/template.js:L144-L146][f1]

Returns a from_namespace factory with namespace 'svg'.

calls: [from_namespace](r3-dom-template-factories.md#u-7fbca348f563)

<a id="u-2b7ace01f784"></a>
### `from_mathml`

`export function from_mathml(content, flags)` · [packages/svelte/src/internal/client/dom/template.js:L153-L155][f1]

Returns a from_namespace factory with namespace 'math'.

calls: [from_namespace](r3-dom-template-factories.md#u-7fbca348f563)

<a id="u-4b6a1b3dac13"></a>
### `from_tree`

`export function from_tree(structure, flags)` · [packages/svelte/src/internal/client/dom/template.js:L209-L249][f1]

Builds a factory for templates constructed programmatically from a TemplateStructure.

Hydrating, the returned function assigns the current hydrate_node and returns it. Otherwise it lazily builds the node once via fragment_from_tree, choosing SVG or MathML namespace from flags (TEMPLATE_USE_SVG / TEMPLATE_USE_MATHML) and reducing to the first child for non-fragment templates. Each call clones the cached node — importNode when the flag is set or on Firefox, else cloneNode(true) — and assigns first/last-child boundaries for fragments, the clone itself otherwise.

calls: [fragment_from_tree](r3-dom-template-factories.md#u-2d74ac8bccad), [assign_nodes](r3-dom-template-factories.md#u-081194bea535)

<a id="u-2d74ac8bccad"></a>
### `fragment_from_tree`

`function fragment_from_tree(structure, ns)` · [packages/svelte/src/internal/client/dom/template.js:L161-L201][f1]

Recursively builds a DocumentFragment from a TemplateStructure tree.

String items become text nodes. Undefined items, or arrays whose first string starts with '/' (comments when preserveComments is on), become comment nodes, slicing the leading '// ' when data exists. Element items are destructured into name, attributes and children; the namespace is SVG for 'svg', MathML for 'math', otherwise the inherited namespace argument. Attributes are applied with set_attribute. Children are appended into the element's .content when it is a TEMPLATE element, otherwise into the element, with 'foreignObject' resetting the namespace to undefined for descendants. The element is appended to the fragment last.

calls: [create_element](r5-runtime-dom.md#u-2338496d57e4), [packages/svelte/src/internal/client/dom/operations.js:set_attribute](r5-runtime-dom.md#u-a8729df1779e), [create_text](r5-runtime-dom.md#u-492391ef3e07), [create_comment](r5-runtime-dom.md#u-08dc08a685e0)

<a id="u-081194bea535"></a>
### `assign_nodes`

`export function assign_nodes(start, end)` · [packages/svelte/src/internal/client/dom/template.js:L29-L35][f1]

Records the boundary nodes of a rendered block on the active effect, but only for the first caller: it sets nodes_start/nodes_end exclusively when effect.nodes_start is still null, so outer template content wins over nested calls.

uses: [template.js module code (L1–L28)][f1]

<a id="u-2c649b4b25d0"></a>
### `comment`

`export function comment()` · [packages/svelte/src/internal/client/dom/template.js:L319-L334][f1]

Creates or hydrates a comment anchor.

Hydrating: assigns hydrate_node as the block start and returns it. Otherwise builds a fragment containing an empty start comment followed by an empty text anchor, assigns those as block boundary nodes, and returns the fragment; not delegated to the template machinery for performance.

calls: [assign_nodes](r3-dom-template-factories.md#u-081194bea535)

<a id="u-e16a3d523a46"></a>
### `packages/svelte/src/internal/client/dom/template.js:text`

`export function text(value = '')` · [packages/svelte/src/internal/client/dom/template.js:L300-L317][f1]

Creates or hydrates a text node and records it as the block boundary.

Not hydrating: creates a text node from String(value), assigns it as both start and end, and returns it. Hydrating: uses the current hydrate_node; if it is not a text node (empty SSR expression) it inserts a fresh empty text node before it, advances the cursor to the new node, then assigns and returns it. Deliberately not side-effect-free due to hydration DOM mutation.

calls: [create_text](r5-runtime-dom.md#u-492391ef3e07), [assign_nodes](r3-dom-template-factories.md#u-081194bea535), [set_hydrate_node](r1-client-runtime.md#u-053b251d50dd)

<a id="u-daaa1d70e416"></a>
### `append`

`export function append(anchor, dom)` · [packages/svelte/src/internal/client/dom/template.js:L342-L355][f1]

Places rendered DOM into the document relative to the anchor.

Hydrating: it records the current hydrate_node as the effect's nodes_end and advances the cursor via hydrate_next, without moving nodes. Not hydrating with a null anchor — the void `<svelte:element>` with content edge case — it does nothing; otherwise it inserts dom immediately before the anchor.

calls: [hydrate_next](r1-client-runtime.md#u-83058186182e)

<a id="u-fafca980132c"></a>
### `props_id`

`export function props_id()` · [packages/svelte/src/internal/client/dom/template.js:L360-L377][f1]

Produces a component-unique id.

While hydrating, if the cursor is a comment whose text starts with '#', the id is the text after '#', the cursor advances via hydrate_next, and that id is returned. Otherwise a counter on window.__svelte (created on first use so ids stay unique across Svelte runtimes) is incremented and returned as `c<N>`.

calls: [hydrate_next](r1-client-runtime.md#u-83058186182e)

<a id="u-7f6237181fe0"></a>
### `run_scripts`

`function run_scripts(node)` · [packages/svelte/src/internal/client/dom/template.js:L264-L294][f1]

Makes script tags inside freshly cloned markup actually execute by replacing each script with a new script element copying all attributes and textContent (parsed fragments do not run scripts).

Returns the node unchanged when hydrating, since SSR'd scripts already ran. Collects scripts either as the node itself (when it is a SCRIPT element) or via querySelectorAll. Because replacement changes node identity, if a replaced script is the node's first/last child (or is the whole node) the active effect's nodes_start/nodes_end is redirected to the clone, keeping block boundaries valid.

**Notes.**

- side_effect: Replaces script elements in the live DOM and may rewrite active_effect.nodes_start/nodes_end.

uses: [template.js module code (L1–L28)][f1]

<a id="u-d64f9d08a8de"></a>
### `with_script`

`export function with_script(fn)` · [packages/svelte/src/internal/client/dom/template.js:L254-L256][f1]

Wraps a template factory so its produced node is passed through run_scripts before being returned.

calls: [run_scripts](r3-dom-template-factories.md#u-7f6237181fe0)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/template.js
