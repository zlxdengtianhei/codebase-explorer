# Client/Server Runtime and Shared Infrastructure

**Capability.** Owns execution of compiled output: the client signal/effect engine and DOM realization, the SSR renderer with payload/abort semantics, and the dependency-free shared helpers, validators, and flag modules both runtimes consume. Runtimes are grouped with shared infra because every runtime call funnels through these shared primitives.

Use this subtree for everything that runs after compilation: client reactivity and DOM, server rendering, and the runtime-agnostic helpers (run/run_all, deferred, to_array, clone tests). Flag modules enable async/legacy/tracing modes by import side effect.

**Children.**

- [Svelte Monorepo](r6-svelte-monorepo.md) `r6-svelte-monorepo` · 0 unit(s)

**Depends on.**

- [Compiler Pipeline and Migration](compiler-and-migration.md) · graph-confirmed · 60 edge(s)
- [Public Typing and Reactive/Motion Libraries](public-typing-and-reactive-libs.md) · graph-confirmed · 43 edge(s)

**Depended on by.**

- [Compiler Pipeline and Migration](compiler-and-migration.md) · graph-confirmed · 54 edge(s) · Compiler transforms emit calls into the client and server runtimes, so generated code's runtime behavior is implemented in the runtime-and-shared-infra subtree.
- [Public Typing and Reactive/Motion Libraries](public-typing-and-reactive-libs.md) · graph-confirmed · 29 edge(s) · Reactive wrappers and springs build on the internal signal/source machinery and shared runtime helpers.
- [Svelte Monorepo](svelte-monorepo.md) · containment · → 0 / ← 0 edge(s) (ancestor direct units and descendant subtree; → follows ` svelte-monorepo ` → ` runtime-and-shared-infra `)

Parent: [Svelte Monorepo](svelte-monorepo.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
