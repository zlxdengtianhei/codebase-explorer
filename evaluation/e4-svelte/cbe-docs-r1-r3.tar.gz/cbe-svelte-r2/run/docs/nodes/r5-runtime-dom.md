# Client Runtime DOM

**Capability.** Client-side DOM realization: low-level node creation/traversal operations (hydration-aware), the keyed each-block lifecycle (create/update/reconcile/move/pause with fallbacks), and two-way bindings for select, window and navigator.

Use this subtree for how reactive state reaches the DOM. Each-blocks drive per-item sources from runtime-reactivity; bindings listen to browser events via the shared listen mechanism; operations.js is the hydration-aware DOM primitive layer.

**Depends on.**

- [Client Runtime Reactivity](r5-runtime-reactivity.md) · graph-confirmed · 6 edge(s)
- [Effect Engine](r3-effects-engine.md) · graph-only · 16 edge(s)
- [Client Runtime](r1-client-runtime.md) · graph-only · 15 edge(s)

**Depended on by.**

- [DOM Template Factories](r3-dom-template-factories.md) · graph-only · 17 edge(s)
- [DOM Template Blocks](r6-client-dom-blocks.md) · graph-only · 10 edge(s)

Parent: [Svelte Monorepo](r5-svelte-monorepo.md)

## Units (29)

<a id="u-a4e1b3df9530"></a>
### `each`

`export function each(node, flags, get_collection, get_key, render_fn, fallback_fn = n…` · [packages/svelte/src/internal/client/dom/blocks/each.js:L119-L162][f1]

Implements keyed each blocks: derives the collection (coercing null to [] and iterables via array_from), and on each rerun hydrates, creates, updates, reorders, or removes item effects, with optional fallback rendering for empty collections.

A controlled block renders into the parent element, creating a text anchor outside hydration. The s0 region prepares state, anchor, the derived collection, and the commit function; commit calls reconcile then manages the fallback: resumes or creates it when the array is empty, pauses it when non-empty. Hydration mismatch handling (else-comment vs emptiness, HYDRATION_END encountered early, excess nodes) removes server DOM and resumes hydrating afterwards. When appends are deferred (should_defer_append), new/returning keys are created or updated into offscreen_items, removed items' effects are marked skipped in the current batch, and commit runs as a batch callback; otherwise commit runs immediately. Each run re-reads the derived collection at the end to re-clean the reactive graph. Setting was_empty skips work for repeated empty arrays. After hydrating, anchor becomes hydrate_node.

calls: [commit](r5-runtime-dom.md#u-41c2b84a34f3), [create_item](r5-runtime-dom.md#u-12c0d32d8f83)

**Uncertainties.**

- should_defer_append's trigger conditions live in operations.js and are only consumed here.

<a id="u-41c2b84a34f3"></a>
### `commit`

`function commit()` · [packages/svelte/src/internal/client/dom/blocks/each.js:L162-L188][f1]

Applies one collection snapshot to the DOM via reconcile, then synchronizes the fallback branch: creates or resumes the fallback when the array is empty, pauses (and nulls) it when items exist.

Only runs when a fallback_fn was supplied.

calls: [reconcile](r5-runtime-dom.md#u-4538273d00cc)

<a id="u-12c0d32d8f83"></a>
### `create_item`

`function create_item( anchor, state, prev, next, value, key, index, render_fn, flags,…` · [packages/svelte/src/internal/client/dom/blocks/each.js:L622-L695][f1]

Creates one each row: builds value/index sources according to reactive and immutable flags (plain values when not reactive), attaches a DEV trace to the value source that reads the collection at the current index, then branches render_fn inside a fragment with a fresh text anchor when no anchor is supplied (deferred creation).

Links the new item and its effect into the prev/next chain and updates state.first when it becomes the head (unless deferred). Restores the previous current_each_item in finally, wrapping the render so nested renders see the right row.

<a id="u-4538273d00cc"></a>
### `reconcile`

`function reconcile( each_effect, array, state, offscreen_items, anchor, render_fn, fl…` · [packages/svelte/src/internal/client/dom/blocks/each.js:L352-L586][f1]

Keyed diff that adds, removes, and reorders each-item effects to match the new array, reusing existing items by key and pulling replacements from offscreen_items when available.

For animated flags it measures matched items up front and collects them into a to_animate set. The main loop walks the array: unknown keys either reinstate an offscreen item (linking it into the list, moving its DOM before the next node) or create a fresh item at the current child anchor, resetting the matched/stashed buffers after each insertion. Known keys are updated when reactive flags demand, resumed if inert, and physically reordered when out of place: if the item was already seen (moved later), it either shifts the earlier matched run to the front or the later item to the back, whichever requires fewer moves, re-indexing the loop (i -= 1) in the front case; otherwise it skips forward stashing unvisited items into `seen`, stopping when the key is found or the list ends. Trailing items (current plus everything in seen not inert) are removed via pause_effects with a controlled anchor only when the block is controlled and the new array is empty; animated removals measure then fix before pausing. After the loop, animations apply in a microtask, the each effect's first/last effect pointers are set, and leftover offscreen items are destroyed and the map cleared.

calls: [update_item](r5-runtime-dom.md#u-bc4a3f237b08), [create_item](r5-runtime-dom.md#u-12c0d32d8f83), [pause_effects](r5-runtime-dom.md#u-1c55b7a0d0a9), [move](r5-runtime-dom.md#u-3dcc1178b952)

**Uncertainties.**

- The INERT flag semantics (outroing items) are inferred from comments and flag checks here, not from effects.js.

<a id="u-bc4a3f237b08"></a>
### `update_item`

`function update_item(item, value, index, type)` · [packages/svelte/src/internal/client/dom/blocks/each.js:L595-L605][f1]

Pushes new value/index into an existing item's reactive slots: the value source is set when EACH_ITEM_REACTIVE, the index source when EACH_INDEX_REACTIVE, otherwise the plain index field is overwritten.

<a id="u-ea8a4b98c012"></a>
### `link`

`function link(state, prev, next)` · [packages/svelte/src/internal/client/dom/blocks/each.js:L720-L732][f1]

Relinks the item list around a boundary: updates state.first when prev is null, otherwise rewires prev's next pointers (item and effect), and symmetrically sets next's prev pointers when next is non-null; null targets are tolerated on the effect side.

<a id="u-3dcc1178b952"></a>
### `move`

`function move(item, next, anchor)` · [packages/svelte/src/internal/client/dom/blocks/each.js:L702-L713][f1]

Physically moves one item's DOM range: walks nodes from the item effect's nodes_start up to (excluding) the next item's nodes_start or the anchor, inserting each before the destination node's start (or before the anchor).

<a id="u-1c55b7a0d0a9"></a>
### `pause_effects`

`function pause_effects(state, items, controlled_anchor)` · [packages/svelte/src/internal/client/dom/blocks/each.js:L73-L107][f1]

Pauses the child effects of multiple removed each items, collecting their transition managers.

With a controlled anchor and no transitions it takes a fast path: clears the parent element's text content, re-appends the anchor, clears the items map, and unlinks the removed range in one step. Otherwise, once all out transitions finish, it deletes each item's key from the map, unlinks it via link, and destroys its effect; in the controlled case destroy_effect is called with the keep-fragment flag false (derived from `!is_controlled`) and the map was already cleared.

calls: [link](r5-runtime-dom.md#u-ea8a4b98c012)

**Uncertainties.**

- Exact meaning of destroy_effect's second argument is defined in effects.js and only inferred here.

<a id="u-66d4f51e1d58"></a>
### `index`

`export function index(_, i)` · [packages/svelte/src/internal/client/dom/blocks/each.js:L62-L64][f1]

Identity helper for each blocks without a key: ignores the item and returns its index, used as get_key.

<a id="u-bde2be852937"></a>
### `set_current_each_item`

`export function set_current_each_item(item)` · [packages/svelte/src/internal/client/dom/blocks/each.js:L54-L56][f1]

Module-level setter assigning the module variable current_each_item, used to bracket rendering of one keyed row so animate: directives can find the item being updated.

<a id="u-eb7a9f0e7810"></a>
### `init_operations`

`export function init_operations()` · [packages/svelte/src/internal/client/dom/operations.js:L30-L73][f2]

Lazily captures window/document globals, a Firefox user-agent flag, and the Node.prototype firstChild/nextSibling getters, so the runtime works in server contexts where these globals are absent.

Early-returns when $window is already set, making it idempotent. When Element.prototype is extensible it pre-seeds internal properties (__click, __className, __attributes, __style, __e) for faster lookups; Text.prototype gets __t. In DEV it adds __svelte_meta to elements and calls init_array_prototype_warnings. Mutating shared prototypes is the observable side effect.

calls: [init_array_prototype_warnings](r1-client-dev-dx.md#u-3c0065301141); uses: [operations.js module code (L1–L29)][f2]

<a id="u-2338496d57e4"></a>
### `create_element`

`export function create_element(tag, namespace, is)` · [packages/svelte/src/internal/client/dom/operations.js:L231-L237][f2]

Creates an element, using createElementNS when a namespace is given and plain createElement otherwise; an `is` value is passed as an options object for customized built-ins.

<a id="u-492391ef3e07"></a>
### `create_text`

`export function create_text(value = '')` · [packages/svelte/src/internal/client/dom/operations.js:L79-L81][f2]

Creates a text node with the given (default empty) value via document.createTextNode.

<a id="u-08dc08a685e0"></a>
### `create_comment`

`export function create_comment(data = '')` · [packages/svelte/src/internal/client/dom/operations.js:L247-L249][f2]

Creates a comment node with the given (default empty) data via document.createComment.

<a id="u-7cb358bae5c9"></a>
### `packages/svelte/src/internal/client/dom/operations.js:create_fragment`

`export function create_fragment()` · [packages/svelte/src/internal/client/dom/operations.js:L239-L241][f2]

Creates an empty DocumentFragment via document.createDocumentFragment.

<a id="u-7752b6debbf3"></a>
### `first_child`

`export function first_child(fragment, is_text)` · [packages/svelte/src/internal/client/dom/operations.js:L137-L159][f2]

Returns the first node of a fragment, adapting to hydration mode.

Not hydrating: it takes the fragment's first child; if that is an empty-string Comment (user comment workaround) it returns that comment's next sibling instead. Hydrating: if is_text is true and the current hydrate_node is not a text node (empty SSR expression), it creates an empty text node, inserts it before hydrate_node, updates the cursor and returns it; otherwise it returns hydrate_node unchanged. Not side-effect-free because hydration mutates the DOM and cursor.

calls: [get_first_child](r5-runtime-dom.md#u-fa05927498af), [set_hydrate_node](r1-client-runtime.md#u-053b251d50dd)

<a id="u-156555a05481"></a>
### `child`

`export function child(node, is_text)` · [packages/svelte/src/internal/client/dom/operations.js:L110-L129][f2]

Descends to the first child of a node, doubling as a hydration cursor advance.

When not hydrating it simply returns get_first_child(node). When hydrating it reads the first child of the current hydrate_node; if that child is null (e.g. `<p>{text}</p>` with empty text) it appends a fresh empty text node and uses it. If is_text is true and the child is not a text node, it creates an empty text node, inserts it before the existing child, updates the cursor to it and returns it, compensating for empty SSR expressions. Otherwise it sets the cursor to the child and returns it. Deliberately not side-effect-free because hydration walks and mutates nodes.

calls: [get_first_child](r5-runtime-dom.md#u-fa05927498af), [set_hydrate_node](r1-client-runtime.md#u-053b251d50dd)

<a id="u-dfa8c3eb25d7"></a>
### `sibling`

`export function sibling(node, count = 1, is_text = false)` · [packages/svelte/src/internal/client/dom/operations.js:L168-L199][f2]

Advances count (default 1) siblings from the starting point, which is hydrate_node when hydrating and the given node otherwise, returning the reached node.

Not hydrating, it just returns the node after skipping. Hydrating with is_text and a non-text (or null) result — possible when an SSR expression was empty — it creates an empty text node, inserts it after the last visited sibling (via after when the result is null, otherwise before the result), updates the cursor to it and returns it. Otherwise the cursor is set to the reached node, which is returned. Not side-effect-free.

calls: [get_next_sibling](r5-runtime-dom.md#u-21941a8e2833), [set_hydrate_node](r1-client-runtime.md#u-053b251d50dd)

<a id="u-fa05927498af"></a>
### `get_first_child`

`export function get_first_child(node)` · [packages/svelte/src/internal/client/dom/operations.js:L89-L91][f2]

Returns the node's first child via the cached Node.prototype.firstChild getter captured by init_operations; marked side-effect-free.

Relies on init_operations having run, otherwise first_child_getter is undefined.

contract: [init_operations](r5-runtime-dom.md#u-eb7a9f0e7810)

<a id="u-21941a8e2833"></a>
### `get_next_sibling`

`export function get_next_sibling(node)` · [packages/svelte/src/internal/client/dom/operations.js:L99-L101][f2]

Returns the node's next sibling via the cached Node.prototype.nextSibling getter captured by init_operations; marked side-effect-free.

contract: [init_operations](r5-runtime-dom.md#u-eb7a9f0e7810)

<a id="u-a8729df1779e"></a>
### `packages/svelte/src/internal/client/dom/operations.js:set_attribute`

`export function set_attribute(element, key, value = '')` · [packages/svelte/src/internal/client/dom/operations.js:L257-L263][f2]

Sets an attribute with a default value of empty string.

Keys starting with 'xlink:' are set through the XLink namespace via setAttributeNS; all others use plain setAttribute.

<a id="u-a9b234e4df06"></a>
### `clear_text_content`

`export function clear_text_content(node)` · [packages/svelte/src/internal/client/dom/operations.js:L206-L208][f2]

Removes all children by assigning an empty string to the node's textContent.

<a id="u-46ab51c8fe62"></a>
### `should_defer_append`

`export function should_defer_append()` · [packages/svelte/src/internal/client/dom/operations.js:L216-L222][f2]

Reports whether block branch insertion/removal should be batched with other updates in the current boundary.

Returns false when async_mode_flag is off or eager_block_effects is non-null; otherwise reads the active effect's flags and returns true only when EFFECT_RAN is set.

uses: [operations.js module code (L1–L29)][f2]

<a id="u-fc6c91d49336"></a>
### `select_option`

`export function select_option(select, value, mounting = false)` · [packages/svelte/src/internal/client/dom/elements/bindings/select.js:L14-L45][f3]

Selects the option(s) in a select element matching a value.

For multiple selects: null/undefined values keep the current selection; a non-array value triggers a warning and keeps the selection; otherwise each option's selected flag is set to whether its value is in the array. For single selects, the first option whose value matches (via is) is selected and the scan stops; if none matches, selectedIndex is set to -1 unless mounting with an undefined value (leaving DOM-derived selection intact).

calls: [select_option](r5-runtime-dom.md#u-fc6c91d49336), [is](r5-runtime-reactivity.md#u-dcae92a399e9)

<a id="u-f378be747d77"></a>
### `init_select`

`export function init_select(select)` · [packages/svelte/src/internal/client/dom/elements/bindings/select.js:L55-L77][f3]

Keeps a select's DOM selection correct when options change outside the binding, e.g. options in an #each block.

A MutationObserver on the select (childList+subtree for options/optgroups, attributes filtered to 'value' for option value changes) re-runs select_option with select.__value; the binding model itself is deliberately not updated. Teardown disconnects the observer.

calls: [select_option](r5-runtime-dom.md#u-fc6c91d49336)

**Uncertainties.**

- select.__value is assigned by callers (e.g. bind_select_value), not here.

<a id="u-6cdee6c1aa0d"></a>
### `bind_select_value`

`export function bind_select_value(select, get, set = get)` · [packages/svelte/src/internal/client/dom/elements/bindings/select.js:L85-L128][f3]

Two-way binds a select's value.

On change (or form reset, querying '[selected]' instead of ':checked') the selected option value(s) are read: multiple selects map all matching options through get_option_value into an array; single selects read the first match, falling back to the first non-disabled option, and set() receives its value or null if none. An effect (not render_effect, so it runs after each-block updates) applies get() via select_option with a mounting flag; while mounting with an undefined value, the DOM's :checked option value is read back and pushed into state. select.__value caches the value for init_select, and mounting is cleared after the first run. init_select is called to keep the DOM synced on option mutations.

calls: [select_option](r5-runtime-dom.md#u-fc6c91d49336), [init_select](r5-runtime-dom.md#u-f378be747d77)

<a id="u-d8dc2a0f3d67"></a>
### `bind_window_scroll`

`export function bind_window_scroll(type, get, set = get)` · [packages/svelte/src/internal/client/dom/elements/bindings/window.js:L10-L13][f4]

Two-way binds window scrollX/scrollY.

A passive scroll listener, wrapped in without_reactive_context, marks scrolling as active, debounces a 100ms clear timer, and pushes the current scroll value into state. A render_effect writes state back but skips the very first run (accessibility: no initial programmatic scroll); when not currently scrolling and the value is non-null it performs scrollTo preserving the other axis and restarts the 100ms scrolling window. An effect runs the handler once at mount because browsers emit no scroll event for the initial position. Teardown removes the scroll listener.

calls: [without_reactive_context](r3-element-bindings.md#u-ff3a57d1f4f9)

<a id="u-8c08fbfaa5cf"></a>
### `bind_window_size`

`export function bind_window_size(type, set)` · [packages/svelte/src/internal/client/dom/elements/bindings/window.js:L64-L66][f4]

Pushes window[innerWidth|innerHeight|outerWidth|outerHeight] into a setter on window resize events, run outside the reactive context via listen (immediate call by default).

calls: [listen](r3-element-bindings.md#u-8f0d8dd6601b)

<a id="u-40e4240d9329"></a>
### `bind_online`

`export function bind_online(update)` · [packages/svelte/src/internal/client/dom/elements/bindings/navigator.js:L7-L11][f5]

Pushes navigator.onLine into a callback on window online/offline events, via listen so listeners are removed at effect teardown.

calls: [listen](r3-element-bindings.md#u-8f0d8dd6601b)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/blocks/each.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/operations.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/elements/bindings/select.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/elements/bindings/window.js
[f5]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/elements/bindings/navigator.js
