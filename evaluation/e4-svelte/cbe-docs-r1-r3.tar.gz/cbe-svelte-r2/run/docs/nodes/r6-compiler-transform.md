# Code Generation

**Capability.** Lowers analyzed ASTs into executable ESTree programs for both client (DOM) and server (SSR) targets, driven by per-node visitor maps over shared transform state.

Use the client subtree for DOM-output lowering and its state types; the server subtree for payload-based SSR visitors.

**Children.**

- [Client Transform](r6-transform-client.md) `r6-transform-client` · 19 unit(s)
- [Server Transform \(SSR\)](r6-transform-server.md) `r6-transform-server` · 10 unit(s)

**Depends on.**

- [Semantic Analysis](r6-compiler-analyze.md) · model-inferred · 0 edge(s)

Parent: [Compiler Pipeline](r6-compiler.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
