# Effect Engine

**Capability.** Creates, links, schedules, pauses, resumes, and destroys effects: the core reactivity lifecycle with flag-based effect kinds, child-list management, transition-aware pausing, and creation-time validation.

This is the heart of the runtime; nearly every other runtime module calls into it. Read create_effect and the flag wrappers first, then the destroy/pause/resume lifecycle for teardown and transition semantics.

**Depends on.**

- [Element Bindings, Actions, and Custom Elements](r3-element-bindings.md) · graph-confirmed · 1 edge(s)
- [Reactivity core](r2-reactivity-core.md) · graph-only · 13 edge(s)

**Depended on by.**

- [Component Mounting](r3-component-mounting.md) · graph-confirmed · 2 edge(s) · Mount and hydrate create the component root through the effect engine's effect creators.
- [Element Bindings, Actions, and Custom Elements](r3-element-bindings.md) · graph-confirmed · 8 edge(s) · Bindings and the custom-element class run their reactive updates inside effects created by the effect engine.
- [Svelte 4 Client Compatibility](r3-legacy-client-runtime.md) · graph-confirmed · 1 edge(s)
- [Reactive Primitives and Stores](r3-reactive-primitives.md) · graph-confirmed · 5 edge(s)
- [Client DOM Blocks](r4-client-dom-blocks.md) · graph-only · 24 edge(s)
- [Client Runtime DOM](r5-runtime-dom.md) · graph-only · 16 edge(s)
- [Boundaries & Async Blocks](r1-client-boundaries.md) · graph-only · 13 edge(s)
- [DOM elements, events and bindings](r2-dom-elements.md) · graph-only · 13 edge(s)
- [Element Bindings and Styles](r4-element-bindings.md) · graph-only · 10 edge(s)
- [DOM Template Blocks](r6-client-dom-blocks.md) · graph-only · 10 edge(s)

Parent: [Client Runtime](r3-runtime.md)

## Units (22)

<a id="u-27c9c7c4069f"></a>
### `effects.js-effect-creators`

`export function teardown(fn)` · [packages/svelte/src/internal/client/reactivity/effects.js:L187-L192][f1]

One-line effect constructor wrappers, all delegating to `create_effect` with different flag combinations.

`teardown` creates an unscheduled RENDER_EFFECT with null fn, marks it CLEAN, and attaches `fn` as its teardown. `create_user_effect` builds `EFFECT | USER_EFFECT` unscheduled. `user_pre_effect` validates then builds a synchronous `RENDER_EFFECT | USER_EFFECT` (in DEV renaming `fn` to '$effect.pre'). `inspect_effect` builds a synchronous INSPECT_EFFECT. `effect` builds an unscheduled plain EFFECT. `async_effect` builds a synchronous `ASYNC | EFFECT_PRESERVED` effect. `render_effect` builds a synchronous RENDER_EFFECT with optional extra flags. `branch` builds a synchronous `BRANCH_EFFECT | EFFECT_PRESERVED` with optional push suppression.

calls: [create_effect](r3-effects-engine.md#u-b219b5c574b1), [validate_effect](r3-effects-engine.md#u-4f3a8befe7fd)

<a id="u-b219b5c574b1"></a>
### `create_effect`

`function create_effect(type, fn, sync, push = true)` · [packages/svelte/src/internal/client/reactivity/effects.js:L86-L174][f1]

Constructs the core Effect object (context, dependency/teardown/node links, flags) and either runs or schedules it.

In DEV it skips inspect-effect ancestors when choosing the parent and records the current component function. An INERT parent marks the new effect INERT. When `sync` is true it runs `update_effect` immediately, sets EFFECT_RAN, and on error destroys the just-created effect before rethrowing; otherwise a non-null `fn` is scheduled. When `push` is set, it attaches the effect (skipping itself for already-ran, teardown-free, childless, non-preserved effects) into the parent's linked list via `push_effect`, and additionally registers it on the active reaction when that reaction is a non-root DERIVED.

calls: [update_effect](r2-reactivity-core.md#u-e2ea8c85735e), [push_effect](r3-effects-engine.md#u-34956c8e3e11), [schedule_effect](r4-reactivity-scheduling.md#u-ce4f8d895426)

<a id="u-34956c8e3e11"></a>
### `push_effect`

`function push_effect(effect, parent_effect)` · [packages/svelte/src/internal/client/reactivity/effects.js:L68-L77][f1]

Appends an effect to the end of a parent effect's doubly linked child list, setting both `first` and `last` when the list was empty.

<a id="u-4f3a8befe7fd"></a>
### `validate_effect`

`export function validate_effect(rune)` · [packages/svelte/src/internal/client/reactivity/effects.js:L50-L62][f1]

Enforces creation-time invariants for `$effect`, `$effect.pre`, and `$inspect`: throws `effect_orphan` when no effect or reaction is active, `effect_in_unowned_derived` when the active reaction is UNOWNED without an active effect, and `effect_in_teardown` when an effect is currently being destroyed.

<a id="u-2ecd21794ced"></a>
### `user_effect`

`export function user_effect(fn)` · [packages/svelte/src/internal/client/reactivity/effects.js:L198-L220][f1]

Internal `$effect(...)`: validates context and, in DEV, renames `fn` to '$effect'.

A top-level effect in an unmounted component (no active reaction, parent is a BRANCH_EFFECT that has not yet run) is deferred by pushing `fn` onto the component context's effect list instead of creating an effect; everything else creates the effect immediately via `create_user_effect`, whose Effect is returned only in the non-deferred path.

calls: [validate_effect](r3-effects-engine.md#u-4f3a8befe7fd), [effects.js-effect-creators](r3-effects-engine.md#u-27c9c7c4069f)

<a id="u-188599523a26"></a>
### `effect_root`

`export function effect_root(fn)` · [packages/svelte/src/internal/client/reactivity/effects.js:L254-L261][f1]

Internal `$effect.root(...)`: ensures a batch exists, creates a ROOT_EFFECT|EFFECT_PRESERVED root that runs immediately, and returns a cleanup closure that destroys it.

calls: [destroy_effect](r3-effects-engine.md#u-214ad59ce57a)

<a id="u-c4dc07dc96fc"></a>
### `effect_tracking`

`export function effect_tracking()` · [packages/svelte/src/internal/client/reactivity/effects.js:L180-L182][f1]

Internal `$effect.tracking()`: true when a reaction is active and untracking is not in progress.

<a id="u-42e380f9794b"></a>
### `component_root`

`export function component_root(fn)` · [packages/svelte/src/internal/client/reactivity/effects.js:L268-L285][f1]

Effect root for component mounting: ensures a batch exists and creates an immediately-run ROOT_EFFECT|EFFECT_PRESERVED root.

Returns an unmount function that yields a Promise: with `{ outro: true }` it first pauses the effect (running out transitions) then destroys it and fulfils; otherwise it destroys immediately and fulfils.

calls: [pause_effect](r3-effects-engine.md#u-340d218bcd6f), [destroy_effect](r3-effects-engine.md#u-214ad59ce57a)

<a id="u-75d755e7c63c"></a>
### `packages/svelte/src/internal/client/reactivity/effects.js:block`

`export function block(fn, flags = 0)` · [packages/svelte/src/internal/client/reactivity/effects.js:L376-L382][f1]

Creates a synchronous BLOCK_EFFECT (plus caller flags) and, in DEV, records the current `dev_stack` on it for better error reporting; returns the effect.

<a id="u-5f7f1fcbe917"></a>
### `template_effect`

`export function template_effect(fn, sync = [], async = [])` · [packages/svelte/src/internal/client/reactivity/effects.js:L366-L370][f1]

Wires a template update function to sync and async expressions by delegating to `flatten`; for each resolved value set it creates a synchronous render effect that spreads the values (re-read via `get`) into `fn`.

calls: [flatten](r2-async-reactivity.md#u-c50793421b66), [create_effect](r3-effects-engine.md#u-b219b5c574b1)

<a id="u-d9a59d025a48"></a>
### `legacy_pre_effect`

`export function legacy_pre_effect(deps, fn)` · [packages/svelte/src/internal/client/reactivity/effects.js:L300-L318][f1]

Internal `$: ...` statement setup: registers a token (deps thunk, ran flag, effect slot) in the legacy component context, then creates a render effect that evaluates `deps`, and unless the token already ran during the reset pass, marks it ran and calls `fn` inside `untrack` so legacy statements do not register dependencies implicitly.

calls: [untrack](r2-reactivity-core.md#u-aa0e067da463), [effects.js-effect-creators](r3-effects-engine.md#u-27c9c7c4069f)

<a id="u-b86eec9e6793"></a>
### `legacy_pre_effect_reset`

`export function legacy_pre_effect_reset()` · [packages/svelte/src/internal/client/reactivity/effects.js:L320-L343][f1]

Creates a render effect that re-runs dirty legacy `$:` statements: for each token it evaluates deps, promotes a CLEAN token effect to MAYBE_DIRTY so its dependencies are traversed, updates it when dirty, and resets `token.ran` so subsequent legacy pre-effects can run again.

calls: [is_dirty](r2-reactivity-core.md#u-6236bf4a1a35), [runtime.js-module-state-setters](r2-reactivity-core.md#u-ac602620d878)

<a id="u-214ad59ce57a"></a>
### `destroy_effect`

`export function destroy_effect(effect, remove_dom = true)` · [packages/svelte/src/internal/client/reactivity/effects.js:L463-L512][f1]

Fully destroys one effect.

It removes the effect's DOM range when `remove_dom` is set or the effect is a HEAD_EFFECT with nodes present, then destroys children (skipping a second DOM removal when it already removed them), removes reactions, and marks the effect DESTROYED. Stops any transitions, runs the teardown, unlinks itself from its parent when the parent still has children, and in DEV clears `component_function`. Finally nulls `next`/`prev`/`teardown`/`ctx`/`deps`/`fn`/node references/abort controller — `parent` is deliberately kept so error propagation can still find it.

calls: [remove_reactions](r2-reactivity-core.md#u-b457a655a682), [execute_effect_teardown](r3-effects-engine.md#u-e4bc784214d0), [unlink_effect](r3-effects-engine.md#u-519e1d7b7b2b)

<a id="u-8ac46761ce64"></a>
### `destroy_effect_children`

`export function destroy_effect_children(signal, remove_dom = false)` · [packages/svelte/src/internal/client/reactivity/effects.js:L416-L440][f1]

Destroys all children of an effect: first nulls the child list head/tail, aborts each child's abort controller with reason STALE_REACTION inside `without_reactive_context`, then either detaches ROOT_EFFECT children (they become independent roots by nulling `parent`) or destroys them recursively.

calls: [without_reactive_context](r3-element-bindings.md#u-ff3a57d1f4f9), [destroy_effect](r3-effects-engine.md#u-214ad59ce57a)

<a id="u-e4bc784214d0"></a>
### `execute_effect_teardown`

`export function execute_effect_teardown(effect)` · [packages/svelte/src/internal/client/reactivity/effects.js:L395-L409][f1]

Runs an effect's teardown function, if any, under `is_destroying_effect = true` and with the active reaction cleared; both ambient values are restored in `finally` even if the teardown throws.

<a id="u-519e1d7b7b2b"></a>
### `unlink_effect`

`export function unlink_effect(effect)` · [packages/svelte/src/internal/client/reactivity/effects.js:L534-L546][f1]

Detaches an effect from its parent's linked list: rewires sibling `next`/`prev` pointers and fixes the parent's `first`/`last` when they pointed at this effect, so later traversals skip it.

<a id="u-92a1603726c9"></a>
### `remove_effect_dom`

`export function remove_effect_dom(node, end)` · [packages/svelte/src/internal/client/reactivity/effects.js:L519-L527][f1]

Removes DOM nodes from `node` up to (and including) `end`, advancing via `get_next_sibling`; when the current node equals `end` the traversal stops after removing it.

calls: [get_next_sibling](r5-runtime-dom.md#u-21941a8e2833)

<a id="u-340d218bcd6f"></a>
### `pause_effect`

`export function pause_effect(effect, callback)` · [packages/svelte/src/internal/client/reactivity/effects.js:L557-L567][f1]

Pauses a removed block effect instead of destroying it, so outro transitions can play and state reversals can resume it: collects transitions from the subtree with `pause_children`, then runs their out transitions and destroys the effect (invoking the optional callback) once all complete.

calls: [pause_children](r3-effects-engine.md#u-2f3c3d6372e6), [run_out_transitions](r3-effects-engine.md#u-a51d37cf57ad)

<a id="u-2f3c3d6372e6"></a>
### `pause_children`

`export function pause_children(effect, transitions, local)` · [packages/svelte/src/internal/client/reactivity/effects.js:L590-L613][f1]

Recursively marks an effect subtree INERT (skipping subtrees already INERT) and gathers transitions into the collector: a transition is included when it is global or within the local scope, where transparency (EFFECT_TRANSPARENT or BRANCH_EFFECT children) propagates the parent's locality and other children reset it to false.

<a id="u-f5814c70931b"></a>
### `resume_children`

`function resume_children(effect, local)` · [packages/svelte/src/internal/client/reactivity/effects.js:L628-L660][f1]

Recursively un-pauses an INERT subtree: clears the INERT flag, and when the effect is not CLEAN marks it DIRTY and schedules it — deliberately avoiding `is_dirty` so paused derived dependencies are not eagerly recomputed.

It recurses with the same transparency-based locality rules as `pause_children`, then plays each visible transition's `in`.

calls: [schedule_effect](r4-reactivity-scheduling.md#u-ce4f8d895426), [runtime.js-module-state-setters](r2-reactivity-core.md#u-ac602620d878)

<a id="u-a51d37cf57ad"></a>
### `run_out_transitions`

`export function run_out_transitions(transitions, fn)` · [packages/svelte/src/internal/client/reactivity/effects.js:L573-L576][f1]

Runs each transition's `out` with a countdown `check` callback; when the transition list is empty it invokes `fn` immediately, otherwise `fn` fires once the last transition finishes.

<a id="u-028f962a5fe6"></a>
### `aborted`

`export function aborted(effect = /** @type {Effect} */ (active_effect))` · [packages/svelte/src/internal/client/reactivity/effects.js:L662-L664][f1]

Reports whether an effect (defaulting to the currently active effect) carries the DESTROYED flag, used to skip error handling for work whose owning block is gone.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/reactivity/effects.js
