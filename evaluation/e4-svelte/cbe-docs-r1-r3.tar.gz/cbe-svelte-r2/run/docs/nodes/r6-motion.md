# Spring Motion

**Capability.** Spring physics animation: the reactive Spring class animating toward targets with stiffness/damping/precision, the deprecated legacy spring() store built on writable, and tick_spring advancing numeric/Date/array/object values per frame.

Use Spring for runes-mode animation; the legacy spring() store remains for Svelte 4 compatibility. Both share tick_spring physics.

**Depends on.**

- [Dev-Mode Diagnostics](r6-client-dev.md) · graph-confirmed · 7 edge(s)
- [Shared Utilities and Tests](r6-shared-infra.md) · graph-confirmed · 1 edge(s)
- [Store Contract](r6-stores.md) · graph-confirmed · 1 edge(s)

Parent: [Stores, Motion, and Reactive Values](r6-stores-motion-reactivity.md)

## Units (4)

<a id="u-6e9a0bc3364a"></a>
### `packages/svelte/src/motion/spring.js:Spring`

`class Spring` · [packages/svelte/src/motion/spring.js:L172-L196][f1]

Reactive spring class whose current value animates toward its target using spring physics: it holds #current/#target plus #stiffness (0.15), #damping (0.8), and #precision (0.01) as reactive state signals.

The constructor applies SpringOpts, clamping stiffness and damping to [0,1] when numbers and storing precision unclamped, and tags all signals for dev tracing. set(value, options) rejects any pending deferred with Error('Aborted'); with options.instant or an undefined current value it aborts any task and snaps current and target to value, resolving immediately; with options.preserveMomentum it zeroes #inverse_mass and sets #momentum so the spring continues on its trajectory while #update's loop restores mass toward 1; otherwise it creates a deferred (with its rejection swallowed via catch(noop)) and resolves it when #update's loop finishes, provided no newer set replaced the deferred. #update writes the target, lazily initializes #current/#last_value, starts the single loop task if none exists (clamping elapsed time to 1/30 s, ticking tick_spring, and clearing #task when settled), and returns the task promise. Getters read signals via get; stiffness/damping setters clamp to [0,1], precision does not; the target setter delegates to set(v). static of(fn, options) seeds a Spring with fn() and registers a render_effect that re-calls set(fn()) whenever fn's reactive dependencies change, requiring an effect root.

**Notes.**

- failure: Concurrent set calls reject the earlier deferred with Error('Aborted'); its rejection is silenced by catch(noop), but awaiting the earlier promise still surfaces that error.
- side_effect: preserveMomentum keeps inv_mass at 0 only until the running loop's recovery-rate addition restores it toward 1.

calls: [tick_spring](r6-motion.md#u-6d7266b4a494), [loop](r1-client-runtime.md#u-4df1fec218a0), [effects.js-effect-creators](r3-effects-engine.md#u-27c9c7c4069f), [deferred](r6-shared-infra.md#u-3c5ab59ed010)

**Uncertainties.**

- #update returns this.#task.promise; whether that promise can reject is defined in loop.js, outside this batch.

<a id="u-b9731c9f1349"></a>
### `packages/svelte/src/motion/spring.js:set`

`function set(new_value, opts = {})` · [packages/svelte/src/motion/spring.js:L89-L141][f1]

Legacy spring store's set: records the new target and either snaps immediately or starts a loop-driven animation.

Immediate snap occurs when the initial value is null, opts.hard is set, or both spring.stiffness and spring.damping are >= 1: it sets cancel_task so any running animation stops on its next tick, resets last_time/last_value, and publishes the target through the store, resolving immediately. With opts.soft (true meaning 0.5, otherwise numeric), inv_mass_recovery_rate becomes 1/(soft*60) and inv_mass is set to 0 (infinite mass), so the spring is briefly unaffected by spring forces. Otherwise, if no task exists it starts a loop: each tick it restores inv_mass toward 1, clamps elapsed time to 1/30 s so blocked threads or inactive tabs don't destabilize the spring, ticks tick_spring with a fresh ctx, publishes the next value, and stops (task=null, return false) when ctx.settled. The returned Promise resolves only when the loop's promise fulfils and this call's token is still current, so superseded sets never resolve.

calls: [loop](r1-client-runtime.md#u-4df1fec218a0), [tick_spring](r6-motion.md#u-6d7266b4a494)

**Uncertainties.**

- Loop promise rejection behavior is defined in loop.js, outside this batch.

<a id="u-65703c942e2e"></a>
### `spring`

`export function spring(value, opts = {})` · [packages/svelte/src/motion/spring.js:L68-L89][f1]

Deprecated legacy spring store: wraps a writable store whose value animates toward the latest set/update target using tick_spring physics.

Defaults are stiffness 0.15, damping 0.8, precision 0.01. The returned object exposes set, update (delegating to set with fn(target_value, value) and the same opts), subscribe, and the option values as plain properties. Per-call set animation semantics live in the nested set closure.

calls: [writable](r6-stores.md#u-dc45d71b793b), [tick_spring](r6-motion.md#u-6d7266b4a494)

<a id="u-6d7266b4a494"></a>
### `tick_spring`

`function tick_spring(ctx, last_value, current_value, target_value)` · [packages/svelte/src/motion/spring.js:L23-L57][f1]

Advances a spring simulation one tick for numeric, Date, array, or plain-object values, mutating ctx to report settling.

For numbers and Dates it computes velocity as (current - last)/(dt || 1/60), spring force as stiffness*delta, damping as damping*velocity, scales by ctx.inv_mass, and returns the stepped value; when both the step and the remaining delta are below ctx.opts.precision it returns the target value with ctx.settled left true, otherwise sets ctx.settled=false so the caller's loop keeps ticking (Dates yield a new Date shifted by the step). Arrays step element-wise via recursion; plain objects key-wise over current_value's keys. Any other value type throws `Cannot spring <type> values`.

**Notes.**

- failure: Non-numeric, non-Date, non-array, non-object values throw instead of animating.

calls: [is_date](r4-motion-library.md#u-c15d4b363055)

**Uncertainties.**

- The numeric branch performs subtraction arithmetic on values only guarded by typeof/is_date checks, so coercions for unusual numeric-like values are unproven.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/motion/spring.js
