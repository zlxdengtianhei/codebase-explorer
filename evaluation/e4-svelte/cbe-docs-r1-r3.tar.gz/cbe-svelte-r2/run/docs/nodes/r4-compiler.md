# Compiler Pipeline

**Capability.** Transforms Svelte component source into optimized client JavaScript, server render code, and scoped CSS through parse, analyze, and transform phases, supported by shared AST builders, preprocessing, and generated diagnostic templates.

Use this subtree to trace how source becomes output: parsing produces the AST, analysis validates and annotates it, transforms emit code. Builders, CSS helpers, preprocessing, and error templates are shared infrastructure consumed across phases.

**Children.**

- [Error Message Templates](r4-compiler-error-templates.md) `r4-compiler-error-templates` · 3 unit(s)
- [Template Parsing \(Phase 1\)](r4-template-parsing.md) `r4-template-parsing` · 13 unit(s)
- [Semantic Analysis \(Phase 2\)](r4-compile-analysis.md) `r4-compile-analysis` · 0 unit(s)
- [Code Generation \(Phase 3\)](r4-codegen-transform.md) `r4-codegen-transform` · 0 unit(s)
- [Compiler Shared Infrastructure](r4-compiler-infra.md) `r4-compiler-infra` · 23 unit(s)

**Depended on by.**

- [Public API Type Surface](r4-public-api-types.md) · model-inferred · 0 edge(s)

Parent: [Svelte Codebase](r4-svelte-codebase.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
