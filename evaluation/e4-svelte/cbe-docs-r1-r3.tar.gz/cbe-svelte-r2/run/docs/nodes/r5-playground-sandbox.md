# Playground Sandbox

**Capability.** Sandbox playground tooling: downloading a sample app, compressing src/ files into a svelte.dev playground URL (gzip+base64url), SSR helper polyfills, and a production SSR server serving a prebuilt page.

Use these scripts to build, share or serve the sandbox app. They are dev tooling, independent of the runtime library.

**Depends on.**

- [Compiler Public API and Pipeline](r5-compiler-pipeline.md) · model-inferred · 0 edge(s)

Parent: [Svelte Monorepo](r5-svelte-monorepo.md)

## Units (5)

<a id="u-3a2d44014938"></a>
### `download.js module code (L1–L52)`

`module_region` · [playgrounds/sandbox/scripts/download.js:L1-L52][f1]

Downloads a Svelte playground app into src/.

The first argv entry must parse as a URL with origin https://svelte.dev and a /playground/ path, otherwise the script errors and exits 1. With a non-empty hash, the fragment is base64url-decoded, gunzipped via DecompressionStream, and parsed, and files come from .files; without a hash, the playground id from the path segment is fetched from the playground API and components are reshaped into file entries named <name>.<type>. Finally every file is written to src/<name>.

**Notes.**

- failure: Decompression, JSON parsing, and fetch failures are not caught, so they propagate and abort the script after validation.

**Uncertainties.**

- Whether the hash decode requires '-'/'_' restoration to '+'/'/' before atob is done here via replaceAll; correctness for malformed hashes is unproven.

<a id="u-515b35e99b78"></a>
### `compress`

`async function compress(payload)` · [playgrounds/sandbox/scripts/hash.js:L22-L42][f2]

Gzip-compresses a string and returns a base64url string suitable for a URL fragment.

The payload is streamed through CompressionStream('gzip') and read chunk by chunk; each byte is appended as a latin-1 character so btoa will accept it (utf-8 decoding would make btoa reject). On the done signal the lock is released and the buffer is base64-encoded with '+'->'-' and '/'->_'.

<a id="u-e8f1b39d4f70"></a>
### `hash.js module code (L1–L21)`

`module_region` · [playgrounds/sandbox/scripts/hash.js:L1-L21][f2]

Builds a playground payload from all top-level files in src/ (directories are skipped) with name 'sandbox', compresses it, and prints a svelte.dev playground URL with the result in the fragment.

Each file entry carries utf-8 read contents and text:true, flagged with a TODO since binary files would be misread.

calls: [compress](r5-playground-sandbox.md#u-515b35e99b78)

<a id="u-c9a44632b392"></a>
### `ssr-common.js module code (L1–L17)`

`module_region` · [playgrounds/sandbox/ssr-common.js:L1-L17][f3]

Installs sandbox-side helpers: a Promise.withResolvers polyfill (only when missing) returning {promise, resolve, reject}, and a globalThis.delayed(v, ms=1000) that resolves with v after a setTimeout.

Importing this module mutates global scope for both dev and prod servers.

**Notes.**

- side_effect: Assigns to Promise and globalThis, affecting every module in the process.

<a id="u-170a1c7ad4ed"></a>
### `ssr-prod.js module code (L1–L42)`

`module_region` · [playgrounds/sandbox/ssr-prod.js:L1-L42][f4]

Serves the prebuilt production app: App.svelte is rendered once at startup into a cached HTML page from dist/client/index.html (replacing the ssr-body and ssr-head placeholders), and a polka server on port 3000 dispatches per request.

'/' returns the cached page as text/html; any other URL resolves under dist/client and, if the file exists, is streamed with the extension-mapped content type (.js, .css) falling back to application/octet-stream; missing files get a 404 'not found'.

**Notes.**

- side_effect: Rendered HTML is computed once at module load, so server start fails if dist/client/index.html or the compiled App is unavailable.

**Uncertainties.**

- Whether the port is configurable is not visible; '3000' is hard-coded.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/playgrounds/sandbox/scripts/download.js
[f2]: ../../../../../../eval/svelte-be645b4/playgrounds/sandbox/scripts/hash.js
[f3]: ../../../../../../eval/svelte-be645b4/playgrounds/sandbox/ssr-common.js
[f4]: ../../../../../../eval/svelte-be645b4/playgrounds/sandbox/ssr-prod.js
