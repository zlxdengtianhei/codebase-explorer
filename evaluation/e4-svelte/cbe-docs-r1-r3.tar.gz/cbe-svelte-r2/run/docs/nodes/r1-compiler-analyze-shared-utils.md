# Analysis Shared Validation

**Capability.** Cross-visitor validation and classification helpers: assignment/bind target legality, const/assignment protection, identifier naming, block emptiness, opening-tag shape, export restrictions, module/instance import conflicts, purity, and safe-identifier classification.

Treat this as the policy core of the analyze phase: visitors call into these helpers, so changes here affect many node kinds at once.

**Depended on by.**

- [Analysis Visitors](r1-compiler-analyze-visitors.md) · graph-confirmed · 12 edge(s) · Analysis visitors delegate shared validation invariants (assignment legality, identifier naming, block emptiness, purity) to the shared helpers.

Parent: [Analyze Phase](r1-compiler-analyze.md)

## Units (9)

<a id="u-ddca3e44b963"></a>
### `ensure_no_module_import_conflict`

`export function ensure_no_module_import_conflict(node, state)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/shared/utils.js:L153-L165][f1]

Prevents an instance-context declaration from shadowing a module-context import with the same name.

It extracts the identifier names of the VariableDeclarator's id pattern and, for each, throws declaration_duplicate_module_import when the current state is 'instance', the current scope is the instance root scope, and the module root scope holds that name as an import. Any other position or non-import module binding passes.

calls: [extract_identifiers](r5-compiler-utilities.md#u-90eb95affc00)

**Uncertainties.**

- The TODO comment says the error message wording is wrong for this case; the thrown condition itself is as coded.

<a id="u-c8c562a3fb44"></a>
### `is_pure`

`export function is_pure(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/shared/utils.js:L199-L241][f1]

Conservatively decides whether an expression is side-effect free for optimization purposes.

Literals are pure. A CallExpression is pure only if its callee and every argument (unwrapping SpreadElements) are pure. Any other node type except Identifier and MemberExpression is impure. For Identifiers/MemberExpressions, if get_rune on the call-shaped node resolves to $effect.tracking it is impure. It then unwraps MemberExpression objects to the leftmost value: an Identifier with no binding is assumed pure (globals are safe); a pure left operand (recursive) is pure; everything else — including bound identifiers like props or reactive state — returns false. A TODO notes safe Svelte imports are not yet handled.

calls: [get_rune](r3-scope-node-model.md#u-5204b6ce4f7a)

**Uncertainties.**

- b.call(node) constructs a synthetic call node solely to query get_rune; whether all identifier/member shapes passed here are valid inputs to get_rune is not shown.
- MemberExpression with a null-ish object chain edge is guarded by `if (!left) return false` but how left could be null given the loop is unclear.

<a id="u-63a6d609f552"></a>
### `is_safe_identifier`

`export function is_safe_identifier(expression, scope)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/shared/utils.js:L173-L192][f1]

Determines whether the base of a member/call chain cannot invoke something needing component context.

It unwraps MemberExpression objects to the leftmost node; anything other than an Identifier returns false. With no binding for that name it returns true. A store_sub binding (name starts with '$') recurses on the name minus the '$' prefix. Otherwise it is safe only when the binding is not an import, prop, bindable_prop, or rest_prop — those may depend on component context that is unavailable at the call site.

**Notes.**

- contract: Recursion on store_sub checks the underlying store identifier's safety with the same rules.

<a id="u-83497fe81c11"></a>
### `validate_assignment`

`export function validate_assignment(node, argument, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/shared/utils.js:L18-L73][f1]

Checks that an assignment, update, or bind: target is legal.

It first delegates to validate_no_const_assignment (with is_binding true only for BindDirective). For an Identifier target: under runes, a binding pointing at the analysis's props_id node throws constant_assignment for $props.id(), and an each-kind binding throws each_item_invalid_assignment; a snippet-kind binding always throws snippet_parameter_assignment. For a this.x member target, it derives the field name from a static or Literal-keyed property (null otherwise, computed non-Literal keys are skipped) and looks it up in state_fields. If the field's declaring node is an AssignmentExpression different from the current node, it walks the path backwards for the nearest function node and throws state_field_invalid_assignment only when that function is a constructor MethodDefinition and the current assignment starts before the field's declaration — i.e. assigning to a state field in the constructor before its initializer.

calls: [validate_no_const_assignment](r1-compiler-analyze-shared-utils.md#u-03d1016cde68), [get_name](r3-scope-node-model.md#u-99af92983a86), [get_parent](r5-compiler-utilities.md#u-427249cf438e)

**Uncertainties.**

- state_fields and props_id are populated elsewhere; their exact structure is inferred from the lookups here.

<a id="u-b877c3a87dc5"></a>
### `validate_block_not_empty`

`export function validate_block_not_empty(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/shared/utils.js:L140-L147][f1]

Warns about a control-flow block containing only whitespace.

It returns for a null/undefined fragment, and also returns when the block has zero nodes (assumed to be mid-typing, so no distracting warning). Exactly one Text node whose raw content trims to empty triggers warning block_empty on that text node.

<a id="u-1535dc101000"></a>
### `validate_export`

`export function validate_export(node, scope, name)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/shared/utils.js:L287-L298][f1]

Rejects exporting derived or reassigned state.

A missing binding passes. A derived-kind binding throws derived_invalid_export; state or raw_state bindings that have been reassigned throw state_invalid_export. Non-reassigned state and all other kinds export freely.

<a id="u-e442f835d467"></a>
### `validate_identifier_name`

`export function validate_identifier_name(binding, function_depth)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/shared/utils.js:L251-L279][f1]

Rejects invalid '$' names for declared bindings.

A null binding returns immediately. Synthetic declarations and parameters (param, rest_param) are always allowed, as are bindings at function_depth 2 or deeper — preserving Svelte 4's allowance for '$'-prefixed locals below the component top level (legacy compatibility; the docstring says this argument can go once legacy mode is gone). Otherwise, a node named exactly '$' throws dollar_binding_invalid; a name merely starting with '$' throws dollar_prefix_invalid, except type-only imports whose initial is an ImportDeclaration with importKind 'type' (exempted so the migration script can complete; TODO to remove).

**Uncertainties.**

- binding.node is assumed to always expose a name here; synthetic bindings are filtered out first, but other nameless shapes are not explicitly guarded.

<a id="u-03d1016cde68"></a>
### `validate_no_const_assignment`

`export function validate_no_const_assignment(node, argument, scope, is_binding)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/shared/utils.js:L81-L120][f1]

Rejects assignments or bindings targeting imports and const-declared values.

It recurses through ArrayPattern elements and ObjectPattern Property values down to Identifiers; other node types are ignored. For an Identifier, a binding whose declaration_kind is 'import', or 'const' with kind not 'each', triggers an error: constant_binding when is_binding is true, otherwise constant_assignment, with the message naming 'import' or 'constant'. A commented-out more precise message indicates the current wording is a deliberate simplification, including for then/catch variables.

**Notes.**

- failure: Each-kind const bindings (each item variables) are exempt and do not error here.

<a id="u-8a95b3b7e6dc"></a>
### `validate_opening_tag`

`export function validate_opening_tag(node, state, expected)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/shared/utils.js:L129-L134][f1]

Ensures a control-flow block opens with '{' immediately followed by the expected character.

If source[node.start + 1] differs from expected, it throws block_unexpected_character over the range start..start+5 (deliberately narrowed to avoid excessive highlighting). Per the docstring, legacy mode allows whitespace between, and this check is intended to move into the parser once legacy mode is removed.

**Uncertainties.**

- How legacy mode bypasses this function (call-site conditioning) is not visible here.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/shared/utils.js
