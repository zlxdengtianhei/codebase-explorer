# Client Transform State Types

**Capability.** Declares ClientTransformState and ComponentClientTransformState — the transform-state fields (statement buckets, hoisted list, template, metadata) plus zimmerframe Context/Visitors aliases — that all client visitors share.

Read these to understand what state client visitors carry. Declaration-only, no runtime behavior.

**Depended on by.**

- [Client Transform](r6-transform-client.md) · containment · → 0 / ← 0 edge(s) (ancestor direct units and descendant subtree; → follows ` r6-transform-client ` → ` r6-transform-client-types `)

Parent: [Client Transform](r6-transform-client.md)

## Units (11)

<a id="u-e21a2406661b"></a>
### `ClientTransformState`

`export interface ClientTransformState extends TransformState` · [packages/svelte/src/compiler/phases/3-transform/client/types.d.ts:L18-L46][f1]

Interface extending TransformState with `in_constructor`, `in_derived`, `is_instance` flags and a `transform` record whose per-name entry has a required `read` (identifier to signal read, e.g. `$.get(foo)`) and optional `assign`, `mutate`, and `update` rewriters.

Declaration-only; no runtime behavior.

<a id="u-aa70ee4ad0b0"></a>
### `ComponentClientTransformState`

`export interface ComponentClientTransformState extends ClientTransformState` · [packages/svelte/src/compiler/phases/3-transform/client/types.d.ts:L48-L86][f1]

Interface extending ClientTransformState for component transforms: analysis/options, `hoisted` statements, event set, optional `store_to_invalidate`, init/update/after_update/consts statement buckets, memoizer, template, metadata (namespace, bound_contenteditable), preserve_whitespace, anchor `node`, legacy reactive imports/statements, and instance/module snippet lists.

Declaration-only.

<a id="u-26d9c2957bc2"></a>
### `types.d.ts module code (L1–L17)`

`module_region` · [packages/svelte/src/compiler/phases/3-transform/client/types.d.ts:L1-L17][f1]

Type-only import block for estree and internal type modules; no runtime behavior.

<a id="u-62adfc8faf02"></a>
### `types.d.ts module code (L88–L88)`

`module_region` · [packages/svelte/src/compiler/phases/3-transform/client/types.d.ts:L88-L88][f1]

Same line as the Context alias; residual artifact, no separate content.

<a id="u-954c7ca91f68"></a>
### `types.d.ts module code (L89–L90)`

`module_region` · [packages/svelte/src/compiler/phases/3-transform/client/types.d.ts:L89-L90][f1]

Residual lines following the Visitors alias; no behavioral content.

<a id="u-fd90ab85708e"></a>
### `types.d.ts module code (L91–L94)`

`module_region` · [packages/svelte/src/compiler/phases/3-transform/client/types.d.ts:L91-L94][f1]

Residual lines following ComponentContext; no behavioral content.

<a id="u-066e8275b1da"></a>
### `types.d.ts module code (L95–L98)`

`module_region` · [packages/svelte/src/compiler/phases/3-transform/client/types.d.ts:L95-L98][f1]

Residual trailing lines; no behavioral content.

<a id="u-7d151e77b44c"></a>
### `ComponentContext`

`export type ComponentContext = import('zimmerframe').Context` · [packages/svelte/src/compiler/phases/3-transform/client/types.d.ts:L91-L91][f1]

Type alias for zimmerframe Context over ComponentClientTransformState; declaration-only.

<a id="u-f07334551d00"></a>
### `ComponentVisitors`

`export type ComponentVisitors = import('zimmerframe').Visitors` · [packages/svelte/src/compiler/phases/3-transform/client/types.d.ts:L95-L95][f1]

Type alias for zimmerframe Visitors over ComponentClientTransformState; declaration-only.

<a id="u-a640c8ac74f1"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/types.d.ts:Context`

`export type Context = import('zimmerframe').Context` · [packages/svelte/src/compiler/phases/3-transform/client/types.d.ts:L88-L88][f1]

Type alias for zimmerframe Context over AST nodes and ClientTransformState; declaration-only.

<a id="u-07e119fad719"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/types.d.ts:Visitors`

`export type Visitors = import('zimmerframe').Visitors` · [packages/svelte/src/compiler/phases/3-transform/client/types.d.ts:L89-L89][f1]

Type alias for zimmerframe Visitors over AST nodes and `any` state; declaration-only.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/types.d.ts
