# Legacy Compatibility (Server)

**Capability.** Server-side implementations of the deprecated Svelte 4 interop APIs: asClassComponent (delegating to the client implementation, then attaching a render method) and legacy run semantics.

Use this subtree for svelte/legacy on the server. asClassComponent converts a Svelte 5 component into a Svelte-4-style constructor with SSR render; run invokes fn once immediately, ignoring cleanup.

**Depends on.**

- [Client Entry and Lifecycle](r4-client-entry.md) · model-inferred · 0 edge(s)

Parent: [Runtime](r4-runtime.md)

## Units (2)

<a id="u-ad399b19be02"></a>
### `packages/svelte/src/legacy/legacy-server.js:asClassComponent (2)`

`export function asClassComponent(component)` · [packages/svelte/src/legacy/legacy-server.js:L33-L39][f1]

Server-side counterpart of `asClassComponent`: converts a Svelte 5 component into a Svelte-4-style class constructor by delegating to the client implementation, then attaches a `render` method for SSR.

The inner `_render(props, { context } = {})` calls the server `render(component, { props, context })` and reshapes the result into `{ css: { code: '', map: null }, head, html: result.body }`; CSS is deliberately empty because server rendering of this legacy wrapper does not emit component CSS here. The constructor is returned with `render` attached despite the type casts.

calls: [packages/svelte/src/legacy/legacy-server.js:asClassComponent (2)](r4-legacy-compat.md#u-ad399b19be02), [render](r2-server-render.md#u-ead9aba750b3)

**Uncertainties.**

- Behavior of the delegated `as_class_component` is defined in legacy-client.js, not shown.
- Why the server `render` result stores HTML in `body` is not evidenced here.

<a id="u-eb5fff7df135"></a>
### `packages/svelte/src/legacy/legacy-server.js:run`

`export function run(fn)` · [packages/svelte/src/legacy/legacy-server.js:L48-L50][f1]

Deprecated legacy `run`: invokes `fn()` once immediately, matching server semantics where `$effect.pre` would also run once synchronously; a returned cleanup function is ignored on the server.

**Uncertainties.**

- Whether the return value of `fn` is intentionally discarded vs. forwarded is not stated; the declared return type is `void`.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/legacy/legacy-server.js
