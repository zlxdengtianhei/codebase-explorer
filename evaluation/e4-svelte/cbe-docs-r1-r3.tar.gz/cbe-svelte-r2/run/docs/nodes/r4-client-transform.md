# Client Transform

**Capability.** Serializes the AST into client-side runtime calls: fragment/template construction with location metadata and SVG attribute casing, rune dispatch, reactive updates, event handler compilation, and boundaries/self/loop constructs.

Use this subtree for how client code is emitted. transform_template/fix_attribute_casing build the static template layer consumed by the Fragment visitor (see Fragment→transform_template calls); events.js compiles on<event> attributes; the remaining visitors handle individual node types.

**Depends on.**

- [Compiler Shared Infrastructure](r4-compiler-infra.md) · model-inferred · 0 edge(s)
- [Reactive Batch Scheduling](r4-reactivity-scheduling.md) · model-inferred · 0 edge(s)

Parent: [Code Generation \(Phase 3\)](r4-codegen-transform.md)

## Units (24)

<a id="u-799dccdfecc2"></a>
### `fix_attribute_casing`

`export default function fix_attribute_casing(name)` · [packages/svelte/src/compiler/phases/3-transform/client/transform-template/fix-attribute-casing.js:L15-L18][f1]

Maps an attribute name to its canonical SVG casing when one exists.

It lowercases the input, looks it up in a module-level Map that pairs each lowercase SVG attribute name with its original mixed-case spelling, and returns the hit or, on a miss, the lowercased input unchanged. Unknown and non-SVG attributes therefore come back lowercased.

uses: [objectify](r5-client-transform.md#u-c628bcd2b8ab)

<a id="u-abe775a427d2"></a>
### `fix-attribute-casing.js-svg-attribute-table`

`group` · [packages/svelte/src/compiler/phases/3-transform/client/transform-template/fix-attribute-casing.js:L1-L14][f1]

Module setup backing fix_attribute_casing: a long space-separated SVG attribute list split into an array, and a Map populated once at load time that maps every lowercase attribute name to its original mixed-case spelling.

It has no exported behavior beyond the default function.

<a id="u-e3fa95e759b1"></a>
### `build_locations`

`function build_locations(nodes)` · [packages/svelte/src/compiler/phases/3-transform/client/transform-template/index.js:L12-L31][f2]

Recursively builds a builders array of [line, column] pairs for every element node in the given template nodes, appending a nested children array only when that recursion yields at least one element; non-element nodes are skipped.

It relies on the module-level locator already being initialized.

calls: [transform_template](r4-client-transform.md#u-e8f6b714535e)

**Uncertainties.**

- locator is imported from state.js; behavior if it is unset cannot be established from this file.

<a id="u-e8f6b714535e"></a>
### `transform_template`

`export function transform_template(state, namespace, flags = 0)` · [packages/svelte/src/compiler/phases/3-transform/client/transform-template/index.js:L38-L68][f2]

Builds the runtime expression that instantiates the accumulated template.

When state.options.fragments is 'tree' it serializes via as_tree and sets TEMPLATE_USE_SVG for namespace 'svg' or TEMPLATE_USE_MATHML for 'mathml' in the flags; otherwise it emits $.from_<namespace> over the HTML form. A flags literal is passed only when nonzero. If the template contains a script tag the call is wrapped in $.with_script; in dev mode it is wrapped again in $.add_locations with the analysis FILENAME member and element locations from build_locations.

**Notes.**

- condition: tree mode with any other namespace produces a from_tree call without namespace flags
- side_effect: reads state.template flags (contains_script_tag) without mutating them

calls: [template.js-template-class](r5-client-transform.md#u-74901e1385cf), [build_locations](r4-client-transform.md#u-e3fa95e759b1)

<a id="u-f8c9a75e03c4"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/transform-template/types.d.ts:Comment`

`export interface Comment` · [packages/svelte/src/compiler/phases/3-transform/client/transform-template/types.d.ts:L17-L20][f3]

Type declaration for a template comment node: type discriminator 'comment' with a string-or-undefined data field.

<a id="u-e73ae7f67c1f"></a>
### `Element`

`export interface Element` · [packages/svelte/src/compiler/phases/3-transform/client/transform-template/types.d.ts:L3-L10][f3]

Type declaration describing a template element node: type discriminator 'element', the tag name, a Record of attribute names to string-or-undefined, child nodes, and a numeric start offset used for populating __svelte_meta.

<a id="u-2200b91a1cdc"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/transform-template/types.d.ts:Text`

`export interface Text` · [packages/svelte/src/compiler/phases/3-transform/client/transform-template/types.d.ts:L12-L15][f3]

Type declaration for a template text node: type discriminator 'text' wrapping an array of AST.Text nodes.

<a id="u-2b132b9513b0"></a>
### `Node`

`export type Node = Element | Text | Comment;` · [packages/svelte/src/compiler/phases/3-transform/client/transform-template/types.d.ts:L22-L22][f3]

Union type alias of the Element, Text, and Comment template node shapes declared above.

<a id="u-61fecc929533"></a>
### `BinaryExpression`

`export function BinaryExpression(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/BinaryExpression.js:L10-L34][f4]

In dev mode replaces equality operators with runtime helpers so proxies compare correctly: `===`/`!==` become `$.strict_equals(left, right, false?)` with the third argument present only for `!==`; `==`/`!=` become `$.equals(left, right, false?)` with it present only for `!=`.

In production, or for any other operator, context.next() runs the default transformation and the node is not replaced.

<a id="u-113cc5a16382"></a>
### `BlockStatement`

`export function BlockStatement(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/BlockStatement.js:L10-L32][f5]

Serializes a block statement, optionally wrapping it in tracing instrumentation.

add_state_transformers runs first. When scope.tracing is non-null, the immediate parent function node's async flag decides whether the traced thunk is awaited: the visited statements become `$.trace(tracing, () => {...})`, returned as `block { return <call or await call> }`. Without tracing, context.next() takes the default path.

calls: [add_state_transformers](r5-client-transform.md#u-32bec314643f)

**Uncertainties.**

- The parent path node is cast to a function type without a guard; its behavior when the parent is not a function is unguarded here.

<a id="u-affe00ad1f18"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/BreakStatement.js:BreakStatement`

`export function BreakStatement(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/BreakStatement.js:L9-L20][f6]

Strips `break $` statements used to exit legacy reactive statements.

In runes mode, or when the label is absent or not named '$', the statement is returned unchanged (falsy/undefined). Inside a legacy reactive statement — detected when the parent (context.path[1]) is the LabeledStatement labeled '$' — it returns an empty return statement to end the compiled reactive block; a labeled break on '$' outside such a statement is left untouched.

**Uncertainties.**

- The non-reactive-statement path returns undefined implicitly; whether that means 'keep the node' depends on the visitor driver, not visible here.

<a id="u-a7da2a1bef1e"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/CallExpression.js:CallExpression`

`export function CallExpression(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/CallExpression.js:L13-L102][f7]

Dispatches rune calls to runtime helpers and adds dev-mode console instrumentation.

get_rune classifies the call: `$host` yields `$$props.$$host`; `$effect.tracking` yields `$.effect_tracking()`; `$state`/`$state.raw` visit the argument, wrapping it in `$.proxy` when the rune is `$state` and should_proxy requires it, returning `$.state(value)` (undefined argument allowed); `$derived` wraps the visited argument in a thunk while `$derived.by` passes the function, both under `$.derived` with in_derived set only for `$derived`; `$state.snapshot` becomes `$.snapshot(arg, true?)` with the flag present when state_snapshot_uncloneable is ignored; `$effect.root` becomes `$.effect_root(...visitedArgs)`; `$effect.pending` becomes `$.pending()`; `$inspect` variants delegate to transform_inspect_rune. Non-rune calls: in dev, a `console.<method>` call (method in a fixed list, console not shadowed in scope) with at least one spread or unknown-evaluating argument is rewritten to spread `$.log_if_contains_state(method, ...args)`. Otherwise context.next() applies the default transform.

calls: [transform_inspect_rune](r2-transform-shared.md#u-f64464c8fc01), [should_proxy](r2-client-signal-builders.md#u-d089d4da67c8), [get_rune](r3-scope-node-model.md#u-5204b6ce4f7a), [state.js-module-level-compiler-state](r2-compiler-infrastructure.md#u-d73d7b033038)

**Uncertainties.**

- Whether should_proxy's exact criteria are satisfied for a given argument depends on that helper, outside this file.

<a id="u-a79e6f67903d"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/ExportNamedDeclaration.js:ExportNamedDeclaration`

`export function ExportNamedDeclaration(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/ExportNamedDeclaration.js:L9-L19][f8]

Handles module-level exports during instance-scope transformation: when state.is_instance, the inner declaration is visited and returned (or b.empty when there is no declaration), so exports are stripped from the instance copy; otherwise the default next visitor continues.

**Uncertainties.**

- How the same node is processed for the module copy (non-instance path via context.next()) depends on the driver outside this file.

<a id="u-123cf8349bd2"></a>
### `ForOfStatement`

`export function ForOfStatement(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/ForOfStatement.js:L10-L25][f9]

Wraps `for await...of` loops to flag reactivity loss, but only when all conditions hold: the loop is awaited, dev mode is on, the await_reactivity_loss warning is not ignored (per is_ignored), and experimental async support is enabled.

In that case the left, right, and body are visited and the right side is wrapped in $.for_await_track_reactivity_loss before emitting a true-await for-of. Every other for-of falls through to context.next().

calls: [state.js-module-level-compiler-state](r2-compiler-infrastructure.md#u-d73d7b033038)

<a id="u-7a4dc7847558"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/Fragment.js:Fragment`

`export function Fragment(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/Fragment.js:L16-L128][f10]

Builds the render block for a fragment: hoisting a template when needed, initializing anchors/elements, and assembling init, render-effect, and after-update statements in order.

It infers the namespace, cleans the child nodes, and returns an empty block when nothing remains. Distinguished cases: a single RegularElement gets a generated id, its template hoisted, instantiation unshifted into init, and a `$.append` close statement; a lone SvelteFragment/TitleElement is visited directly; a single Text node becomes a `$.text` call; multiple nodes either use a space text template (all Text/ExpressionTag with at least one ExpressionTag), reuse `$$anchor` for standalone blocks, or build a fragment template (`$.comment` shortcut for a single comment node), always closing with `$.append`. State consts come first, then an early return when `$.aborted` under await, then a `$.next` skip when text is first, then init, the render statement when updates exist, after_update, and the close statement last because later insertions must be known when building the inner-element list. With await the body is wrapped in `$.async_body`.

calls: [transform_template](r4-client-transform.md#u-e8f6b714535e), [fragment.js-process_children](r5-client-transform.md#u-c8d8a77dfc05), [clean_nodes](r2-transform-shared.md#u-2ed26069223c), [infer_namespace](r2-transform-shared.md#u-b0bc5038f26b), [build_render_statement](r5-client-transform.md#u-b84b76b77b0e)

**Uncertainties.**

- Template/Memoizer internals and clean_nodes trimming rules are defined in other files

<a id="u-06422e17faaf"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/Fragment.js:Fragment (2)`

`export function Fragment(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/Fragment.js:L128-L184][f10]

Continuation of the Fragment visitor body described in its unit: assembles consts, await-abort guard, text-skip, init, render effect, after_update, and the close statement, returning either a `$.async_body` block (with await) or a plain block.

<a id="u-f38feaae905e"></a>
### `expression`

`const expression = (is_text) =>` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/Fragment.js:L128-L128][f10]

One-line local helper inside Fragment producing the anchor-resolving expression for non-standalone fragment children: `$.first_child(id, true)` when the next node is text, else `$.first_child(id)`.

<a id="u-78cb80fb5d8c"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/SvelteBoundary.js:SvelteBoundary`

`export function SvelteBoundary(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/SvelteBoundary.js:L11-L116][f11]

Serializes a `<svelte:boundary>` into a `$.boundary(node, props, ($$anchor) => block)` statement.

Attributes become props: constant values are `init` properties; stateful attribute expressions become getter properties returning the expression; non-Attribute or shorthand-valued attributes are skipped (validation should have rejected them). Fragment children are split: ConstTags are collected into const_tags statements (visited immediately unless experimental.async, in which case they stay inside the fragment) because they must live inside the boundary yet may be referenced by hoisted snippets. SnippetBlocks are hoisted: `failed`/`pending` snippets become init props on the boundary; other snippets become hoisted declarations, and when not in async mode the const_tags variable declarations are unshifted into the snippet function body so references resolve (in async mode snippets referencing const tags are instead kept in the fragment). All remaining children are visited into the block, with const_tags prepended in non-async mode. Hoisted declarations and the boundary call are wrapped in a block when any snippet was hoisted, and pushed to init after a template comment is pushed.

calls: [template.js-template-class](r5-client-transform.md#u-74901e1385cf)

**Uncertainties.**

- In dev mode the snippet function is extracted via `snippet.declarations[0].init.arguments[1]` with a ts-expect-error cast; the exact dev-mode snippet AST shape is defined by the snippet transform, not visible here.
- Whether `context.visit` of the fragment can throw for unexpected child types is not established here.

<a id="u-d35c66d967c0"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/SvelteSelf.js:SvelteSelf`

`export function SvelteSelf(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/SvelteSelf.js:L9-L12][f12]

Compiles <svelte:self> by delegating to build_component with the current analysis name (the component referencing itself), then pushes the result into state.init.

calls: [component.js-build-component](r1-compiler-transform-client.md#u-ea683dd1d72c)

<a id="u-f5935e5dfe7b"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/UpdateExpression.js:UpdateExpression`

`export function UpdateExpression(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/UpdateExpression.js:L11-L55][f13]

Serializes ++/-- expressions against reactive state.

A private-field member update on `this` whose `#name` is a tracked state field becomes `$.update` (or `$.update_pre` for prefix operators) applied to the member, with a literal -1 added for `--`. Any argument that is neither an Identifier nor a MemberExpression throws 'An impossible state was reached'. When the object root is the argument itself and its transformer provides `update`, that transformer rewrites the node directly (no ownership check since this is reassignment, not mutation). Otherwise context.next() produces the default update; if a `mutate` transformer exists for the root it wraps the result, and validate_mutation performs the final ownership/mutation validation pass on the node and updated expression.

calls: [validate_mutation](r5-client-transform.md#u-a58215b09609), [object](r5-compiler-utilities.md#u-2f2548aeaec6)

**Uncertainties.**

- Which transformers install `update`/`mutate` is determined elsewhere; behavior here assumes their presence on state.transform entries.

<a id="u-0bee50cc5235"></a>
### `build_event`

`export function build_event(event_name, node, handler, capture, passive)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/events.js:L94-L103][f14]

Constructs the $.event runtime call for a non-delegated handler: the event name literal, the anchor node, the handler, a true literal only when capturing, and a literal passive flag only when passive is defined (undefined otherwise).

uses: [visit_event_attribute](r4-client-transform.md#u-8ff2bf148b08)

<a id="u-227977f005ec"></a>
### `build_event_handler`

`export function build_event_handler(node, metadata, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/events.js:L112-L177][f14]

Turns an event handler expression into a callable handler.

A null expression yields a function that calls $.bubble_event.call(this, $$props, $$arg). The expression is visited; an already-function handler is returned as is. An Identifier handler is returned as is when its binding is a function, or when not in dev mode and the binding is not an import; dev mode and imports fall through to wrapping. When the expression metadata reports has_call, the handler is memoized into a $.derived variable created in init and read via $.get. Otherwise the handler is wrapped in a function calling handler.apply(this, $$args); in dev mode this becomes a $.apply call that additionally passes the component name, the handler's source line/column from locator, a flag when the node has side effects, and a flag removing parens for zero-argument identifier calls.

calls: [has_side_effects](r4-client-transform.md#u-229b6845de57)

**Uncertainties.**

- The dev-mode remove_parens flag is only set for CallExpression nodes with no arguments whose callee is an Identifier; other call shapes get no flag.
- Whether locator can return undefined here (loc && ...) and how $.apply handles that is defined elsewhere.

<a id="u-229b6845de57"></a>
### `has_side_effects`

`function has_side_effects(node)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/events.js:L182-L197][f14]

Reports whether an expression node can have side effects: true for CallExpression, NewExpression, AssignmentExpression, and UpdateExpression; for SequenceExpression it recurses over each sub-expression with some(); all other node types return false.

<a id="u-8ff2bf148b08"></a>
### `visit_event_attribute`

`export function visit_event_attribute(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/events.js:L12-L84][f14]

Compiles an on<event> attribute on a regular element.

The event name is the attribute name minus 'on'; if is_capture_event matches, the 'capture' suffix is stripped and capture mode is set. The handler is built by build_event_handler from the attribute's expression tag. When node.metadata.delegated is set, the event name is recorded in state.events and an assignment of the handler (or an array of handler plus hoisted params, when metadata.delegated.hoisted and hoisted_params exist) to node.__<event> is pushed into init; a hoisted inline function is additionally declared as a root-unique on_<event> variable in state.hoisted. Otherwise a $.event call is built with the capture flag and a passive flag from is_passive_event (true or omitted); it goes into init for SvelteDocument/SvelteWindow/SvelteBody parents (events above the component must run parent first) and into after_update otherwise.

calls: [build_event_handler](r4-client-transform.md#u-227977f005ec), [build_event](r4-client-transform.md#u-0bee50cc5235)

**Uncertainties.**

- Whether metadata.delegated.hoisted can be true with function !== tag.expression while hoisted_params exist is not determinable from this source; in that case the plain handler is assigned.
- is_passive_event and is_capture_event predicates live in another file.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/transform-template/fix-attribute-casing.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/transform-template/index.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/transform-template/types.d.ts
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/BinaryExpression.js
[f5]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/BlockStatement.js
[f6]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/BreakStatement.js
[f7]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/CallExpression.js
[f8]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/ExportNamedDeclaration.js
[f9]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/ForOfStatement.js
[f10]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/Fragment.js
[f11]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/SvelteBoundary.js
[f12]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/SvelteSelf.js
[f13]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/UpdateExpression.js
[f14]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/events.js
