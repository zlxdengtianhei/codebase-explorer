# Template Parsing (Phase 1)

**Capability.** Turns raw component source into the initial AST: Acorn-backed JS/TS parsing with comment capture, expression reading from template text, and element-state handling that classifies tags, attributes, and directives.

Use this subtree for how `<tag attr={expr}>` and template expressions become AST nodes. acorn.js wraps the parser; read/expression.js extracts expressions; element.js walks element structure. read_sequence is the shared text/expression chunker used by both element and attribute-value reading (see grp:element.js-read_sequence edges into read_expression).

**Depends on.**

- [Compiler Shared Infrastructure](r4-compiler-infra.md) · graph-confirmed · 1 edge(s)
- [Scope and Node Model](r3-scope-node-model.md) · graph-only · 11 edge(s)

**Depended on by.**

- [Template Parsing](r6-compiler-parse.md) · graph-only · 16 edge(s)

Parent: [Compiler Pipeline](r4-compiler.md)

## Units (13)

<a id="u-4bea7fd815cc"></a>
### `get_comment_handlers`

`function get_comment_handlers(source, comments, index = 0)` · [packages/svelte/src/compiler/phases/1-parse/acorn.js:L104-L139][f1]

Returns the `onComment`/`add_comments` pair used to give Acorn comment awareness, needed for `svelte-ignore` support and comment preservation.

`onComment` records each comment (type Block/Line, value, start, end, loc) into the shared `comments` array; for block comments containing a newline it strips the common indentation by slicing from the previous line start, skipping whitespace to measure indentation, and removing that prefix from every line via a global multiline regex. `add_comments(ast)` first filters comments below `index` and copies them, then walks the AST: comments starting before a node become that node's `leadingComments`; trailing-comment assignment depends on the parent: if the node is the last entry of a BlockStatement/Program body, ArrayExpression elements, or ObjectExpression properties, all remaining comments up to the parent's end (possibly newline-separated) become `trailingComments`; otherwise a single comment becomes `trailingComments` only if the source between node end and comment start is just separators/whitespace. Any comments left after the walk are appended to the root AST's `trailingComments` (for expression tags or Program) so the expression-tag end can later be detected.

**Uncertainties.**

- The exact `loc` fields rely on Acorn supplying start_loc/end_loc positions; the code casts them without a null check.

<a id="u-2464d5720df7"></a>
### `packages/svelte/src/compiler/phases/1-parse/acorn.js:parse`

`export function parse(source, comments, typescript, is_script)` · [packages/svelte/src/compiler/phases/1-parse/acorn.js:L22-L66][f1]

Parses a JS or TS source string into an ESTree Program, attaching comments Acorn would otherwise drop.

Chooses the TypeScript-extended parser when `typescript` is set, otherwise plain `acorn.Parser`. For `<script>` content (`is_script`), it wraps the parser prototype's `parseStatement` so that after each statement `this.undefinedExports` is reset to an empty object, preventing Acorn from erroring on exports whose declarations live elsewhere in the component; the prototype is restored in a `finally`, so the original is reinstated even if parsing throws. After parsing, `add_comments` from the comment handlers mutates the AST to attach comments, then the Program is returned.

**Notes.**

- side_effect: Temporarily mutates the shared (extended or built-in) parser prototype's parseStatement when is_script is true, restoring it in a finally block.

calls: [get_comment_handlers](r4-template-parsing.md#u-4bea7fd815cc)

**Uncertainties.**

- Whether the prototype patch is safe under concurrent/async parsing of multiple sources is not addressed in this file.

<a id="u-730e2a662101"></a>
### `parse_expression_at`

`export function parse_expression_at(source, comments, typescript, index)` · [packages/svelte/src/compiler/phases/1-parse/acorn.js:L75-L94][f1]

Parses a single expression starting at a given index of the source, choosing the TypeScript-extended parser when `typescript` is set.

Comments are collected via `get_comment_handlers` seeded with `index`, so only comments at or after that index are considered when `add_comments` attaches `leadingComments`/`trailingComments` to the resulting expression node. The parsed expression AST is returned; parse errors propagate from the underlying Acorn call.

calls: [get_comment_handlers](r4-template-parsing.md#u-4bea7fd815cc)

<a id="u-f85dafe8159e"></a>
### `get_loose_identifier`

`export function get_loose_identifier(parser, opening_token)` · [packages/svelte/src/compiler/phases/1-parse/read/expression.js:L13-L27][f2]

Fallback that captures an unparsable expression up to the matching closing bracket.

It searches for the bracket matching opening_token (default '{') starting at parser.index; if found, it moves parser.index to that bracket and returns an empty-named Identifier spanning the region, signaling 'unknown expression'. If no matching bracket exists it returns undefined, leaving parser.index unchanged.

<a id="u-793d43872467"></a>
### `read_expression`

`export default function read_expression(parser, opening_token, disallow_loose)` · [packages/svelte/src/compiler/phases/1-parse/read/expression.js:L35-L93][f2]

Parses a JS expression from the template at parser.index using Acorn, returning the estree Expression and advancing parser.index past it.

After parsing it rewinds parser.index to the end of any comment that ends before the node start, counts '(' characters between parser.index and node.start, then consumes that many closing parentheses — a non-whitespace, non-')' character in that span triggers e.expected_token; the final index is also extended past the last recorded comment if it extends beyond the node. On any parse error, if parser.loose is set and disallow_loose is falsy, it falls back to get_loose_identifier and returns its opaque identifier if one is found (used for each-loop constructs like 'as { y = z }'); otherwise the error is rethrown via parser.acorn_error.

calls: [parse_expression_at](r4-template-parsing.md#u-730e2a662101), [get_loose_identifier](r4-template-parsing.md#u-f85dafe8159e)

**Uncertainties.**

- parser.loose semantics and where disallow_loose is set are outside this file.

<a id="u-bc08cb4e57fa"></a>
### `element`

`export default function element(parser)` · [packages/svelte/src/compiler/phases/1-parse/state/element.js:L52-L411][f3]

Parses an element, comment, closing tag, or special tag (script/style/textarea) starting at the current '<'.

It appends the parsed node to the parser and manages the parser stack for auto-closing and nesting.

**Notes.**

- side_effect: Mutates parser state: appends nodes, pops/pushes the element stack, records parser.meta_tags and parser.last_auto_closed_tag, and rewinds parser.index in loose mode.

calls: [read_script](r6-compiler-parse.md#u-086699ac3458), [read_style](r1-compiler-parse-style.md#u-863125efdf39), [create_fragment](r3-parse-utilities.md#u-6f16c2773335), [is_element_node](r3-scope-node-model.md#u-0d9a79ad394a), [get_attribute_expression](r5-compiler-utilities.md#u-96e6f6d66786), [is_expression_attribute](r5-compiler-utilities.md#u-f63f079d6472), [closing_tag_omitted](r2-compiler-infrastructure.md#u-10b29d40ea2b), [utils.js-element-attribute-predicates](r5-compiler-utilities.md#u-57e79fafa2c2)

**Uncertainties.**

- Exact error/warning message shapes come from the errors/warnings modules, whose signatures are not in this excerpt.

<a id="u-2a4064013135"></a>
### `get_directive_type`

`function get_directive_type(name)` · [packages/svelte/src/compiler/phases/1-parse/state/element.js:L696-L706][f3]

Maps a colon-prefix ('use', 'animate', 'bind', 'class', 'style', 'on', 'let', 'in'/'out'/'transition') to its directive type string; any other prefix returns false, causing the attribute to be read as a plain Attribute.

<a id="u-b95f147540fd"></a>
### `parent_is_head`

`function parent_is_head(stack)` · [packages/svelte/src/compiler/phases/1-parse/state/element.js:L414-L422][f3]

Scans the stack backwards: returns true if the nearest enclosing node is SvelteHead, false as soon as a RegularElement or Component encloses, false otherwise.

Determines whether <title> parses as TitleElement.

<a id="u-d1eed460e3e4"></a>
### `parent_is_shadowroot_template`

`function parent_is_shadowroot_template(stack)` · [packages/svelte/src/compiler/phases/1-parse/state/element.js:L425-L439][f3]

Returns true if any stack entry (backwards scan) is a RegularElement carrying a shadowrootmode attribute, marking declarative-shadow-DOM templates where <slot> stays a regular element rather than SlotElement.

<a id="u-2c3fac35f2d5"></a>
### `read_attribute`

`function read_attribute(parser)` · [packages/svelte/src/compiler/phases/1-parse/state/element.js:L490-L690][f3]

Reads one attribute-like construct: '{' opens an AttachTag (@attach), SpreadAttribute (...), or shorthand ExpressionTag attribute; otherwise reads a name up to a token-ending character.

A colon prefix maps to a directive via get_directive_type; directives require a single expression value (mixed/text values error), get inferred intro/outro for transitions, and Bind/Class directives without expressions get an identifier expression from their name. Duplicate handling is not done here. Returns null when the name is empty, and in loose mode also when '{' is followed by block-start characters so the parser can recover.

calls: [read_expression](r4-template-parsing.md#u-793d43872467), [get_directive_type](r4-template-parsing.md#u-2a4064013135), [create_attribute](r3-scope-node-model.md#u-16d11cbbd59b), [create_expression_metadata](r3-scope-node-model.md#u-32bbb434f744)

**Uncertainties.**

- Whether value=true (no '=') is valid for every directive kind is enforced elsewhere and not visible here.

<a id="u-a913d60dcf82"></a>
### `packages/svelte/src/compiler/phases/1-parse/state/element.js:read_attribute_value`

`function read_attribute_value(parser)` · [packages/svelte/src/compiler/phases/1-parse/state/element.js:L712-L763][f3]

Reads an attribute value: an immediately-closed quote yields a single empty Text chunk; otherwise read_sequence collects text/expression chunks until the closing quote or an invalid unquoted character.

If read_sequence's expression parse throws a js_parse_error positioned just before '/>' (e.g. `<Component test={{a:1} />`), it rewrites the error to an expected-token error; otherwise the error propagates. Empty unquoted values error; a quoted or multi-chunk or text-containing value returns the array, otherwise the single ExpressionTag.

calls: [element.js-read_sequence](r4-template-parsing.md#u-d49034e0d402)

<a id="u-73af677afe37"></a>
### `read_static_attribute`

`function read_static_attribute(parser)` · [packages/svelte/src/compiler/phases/1-parse/state/element.js:L445-L484][f3]

Reads a plain attribute without expression support (used for top-level <script>/<style>).

Returns null at a token-ending character; otherwise reads the name, optionally reads '=' plus a quoted or unquoted value decoded with character references, errors if a quote follows without '=', and returns the created Attribute node.

calls: [decode_character_references](r2-parse.md#u-a03f13997ae5)

<a id="u-d49034e0d402"></a>
### `element.js-read_sequence`

`function read_sequence(parser, done, location)` · [packages/svelte/src/compiler/phases/1-parse/state/element.js:L771-L785][f3]

read_sequence accumulates template content into Text chunks and ExpressionTags until a caller-supplied done() predicate fires.

Text chunks are flushed only when non-empty, with character references decoded and their end positions set. '{' sequences become expressions, but '{#' blocks and '{@' tags error as invalid placements at the given location. If the template ends before done(), loose mode returns the chunks so far; otherwise unexpected_eof is thrown. Used both for <textarea> content and attribute values, so the done predicate and error location differ per caller.

calls: [read_expression](r4-template-parsing.md#u-793d43872467), [decode_character_references](r2-parse.md#u-a03f13997ae5), [create_expression_metadata](r3-scope-node-model.md#u-32bbb434f744)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/1-parse/acorn.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/1-parse/read/expression.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/1-parse/state/element.js
