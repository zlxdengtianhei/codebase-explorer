# Client code generation

**Capability.** Serializes the analyzed AST into client-side JavaScript: visitors emit template construction and init/update statements, signal builders construct runtime call expressions, and shared utilities handle fragments, namespaces and rune lowering for both client and server transforms.

Read client-visitors for how elements, key blocks and the program root are lowered; client-signal-builders for the emitted $.prop/build_getter machinery; transform-shared for fragment cleaning, namespace inference and $inspect lowering shared across output targets.

**Children.**

- [Client transform visitors](r2-client-visitors.md) `r2-client-visitors` · 9 unit(s)
- [Client signal builders](r2-client-signal-builders.md) `r2-client-signal-builders` · 20 unit(s)
- [Shared transform utilities](r2-transform-shared.md) `r2-transform-shared` · 7 unit(s)

Parent: [Compiler](r2-compiler.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
