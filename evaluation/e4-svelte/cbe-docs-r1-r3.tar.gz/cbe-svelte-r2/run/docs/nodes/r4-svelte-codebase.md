# Svelte Codebase

**Capability.** The Svelte framework repository: a compiler pipeline that parses, analyzes, and transforms component sources, the client/server runtime those transforms target, the reactivity and motion libraries, the public type surface, and benchmarking infrastructure.

Start here to navigate the repository. Main subtrees are the compiler, the runtime, the reactivity/motion libraries, and public API types; benchmarking stands alone. Missing graph edges do not prove independence across subtrees.

**Children.**

- [Benchmark Harness](r4-benchmark-harness.md) `r4-benchmark-harness` · 11 unit(s)
- [Compiler Pipeline](r4-compiler.md) `r4-compiler` · 0 unit(s)
- [Runtime](r4-runtime.md) `r4-runtime` · 0 unit(s)
- [Reactive Built-in Wrappers](r4-reactivity-library.md) `r4-reactivity-library` · 7 unit(s)
- [Motion Library](r4-motion-library.md) `r4-motion-library` · 4 unit(s)
- [Public API Type Surface](r4-public-api-types.md) `r4-public-api-types` · 18 unit(s)

Parent: [Public Typing and Reactive/Motion Libraries](public-typing-and-reactive-libs.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
