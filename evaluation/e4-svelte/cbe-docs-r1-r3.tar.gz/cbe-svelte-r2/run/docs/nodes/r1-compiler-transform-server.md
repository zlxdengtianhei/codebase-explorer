# Server Transform (SSR)

**Capability.** Transforms component and module analyses into SSR JavaScript Programs: payload-driven visitors emit template statements, rewrite assignments and identifiers, drop client-only effects, and render boundaries/titles/render tags.

transform-server.js is the entry (component and module variants); the visitors directory holds per-node emission. Class bodies become getter/setter pairs over private fields; {@debug} becomes console.log plus debugger.

**Depends on.**

- [Shared Assignment Rewriting](r1-compiler-transform-shared.md) · graph-confirmed · 1 edge(s) · The server transform reuses the shared assignment rewriter so reactive assignment semantics match the client target.
- [Server Runtime \(SSR\)](r1-server-runtime.md) · model-inferred · 0 edge(s)

Parent: [Transform Phase](r1-compiler-transform.md)

## Units (14)

<a id="u-3bff6efcb646"></a>
### `transform-server-js-server-component`

`export function server_component(analysis, options)` · [packages/svelte/src/compiler/phases/3-transform/server/transform-server.js:L90-L112][f1]

Transforms a component analysis into an SSR JavaScript Program.

Initialises ComponentServerTransformState (hoisted starting with `import * as $ from 'svelte/internal/server'`, legacy_reactive_statements map, init/template placeholders set later by Fragment), then walks three ASTs: the module AST with global_visitors, the instance AST with two overrides — ImportDeclaration is pushed onto state.hoisted and replaced by an empty statement, and ExportNamedDeclaration either visits its declaration (keeping the export's side value) or becomes empty — and the template AST with global plus template visitors, each with the correct scope map. Legacy `$:` statements are then appended to the instance body in analysis order, throwing 'Could not find reactive statement' if a recorded statement is missing; when an `$:` body is a top-level assignment to a legacy_reactive binding, an uninitialized `let` declarator for that identifier is hoisted into one leading VariableDeclaration. If analysis.uses_component_bindings, template statements are split from snippet declarations and wrapped in a $$render_inner function driven by a do/while loop that repeats until $$settled, copying and assigning payloads back for legacy child bindings. If any instance binding is a store_sub, `$$store_subs` is declared and an unsubscribe call is appended to the template. Bindable props (excluding $$-prefixed) and module exports are collected into props, and when non-empty `$.bind_props($$props, {...})` is appended so bound-prop values propagate. The instance and template bodies form the component block; analysis.props_id (if any) is declared first for hydration, `$.push`/`$.pop` wrap the block in dev or when needs_context, and $$restProps/$$sanitized_props/$$slots constants are unshifted per uses_rest_props/uses_props/uses_slots. When CSS exists, css==='injected' and not a custom element, a $$css object from render_stylesheet is emitted and `$$payload.css.add` is called first in the block. The exported function takes $$payload plus $$props when should_inject_props (context injection, props, needs_props, uses_props/rest_props/slots, or named slots). Output shape varies: componentApi===4 adds a `render` wrapper importing from 'svelte/server' and a default export; dev replaces render with a throwing function and adds a FILENAME assignment; otherwise the component is exported directly.

**Notes.**

- side_effect: state.hoisted accumulates instance import declarations which are prepended to the final program body
- failure: Throws if a reactive statement in analysis.reactive_statements has no matching entry in state.legacy_reactive_statements

calls: [render_stylesheet](r4-css-transform.md#u-197b2d45aa0c), [extract_identifiers](r5-compiler-utilities.md#u-90eb95affc00); uses: [server_module](r1-compiler-transform-server.md#u-7e11f4406861)

**Uncertainties.**

- The exact behavior of the many imported visitors (Fragment, EachBlock, etc.) is outside this file; init/template fields are documented as null until the Fragment visitor sets them, per its comment

<a id="u-7e11f4406861"></a>
### `server_module`

`export function server_module(analysis, options)` · [packages/svelte/src/compiler/phases/3-transform/server/transform-server.js:L392-L415][f1]

Transforms a `<script module>` analysis into an SSR Program.

Builds a ServerTransformState carrying the module scope, an empty legacy_reactive_statements map (present only so shared legacy visitors work; unusable in modules per the comment), and state_fields, walks the module AST with global_visitors, and returns a Program whose body starts with `import * as $ from 'svelte/internal/server'` followed by the transformed module body.

<a id="u-327ce0ca4830"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/AssignmentExpression.js:AssignmentExpression`

`export function AssignmentExpression(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/AssignmentExpression.js:L14-L16][f2]

Transforms assignment expressions on the server by delegating to shared assignment logic or continuing traversal.

It calls visit_assignment_expression with the module-local build_assignment callback; if that returns nothing, it falls back to context.next() so non-assignment-relevant nodes are visited normally.

calls: [visit_assignment_expression](r1-compiler-transform-shared.md#u-b43a982ab161); uses: [packages/svelte/src/compiler/phases/3-transform/server/visitors/AssignmentExpression.js:build_assignment](r1-compiler-transform-server.md#u-e2028cc30489)

**Uncertainties.**

- Whether visit_assignment_expression always invokes build_assignment for every assignment shape is not visible in this file

<a id="u-e2028cc30489"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/AssignmentExpression.js:build_assignment`

`function build_assignment(operator, left, right, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/AssignmentExpression.js:L26-L100][f2]

Builds a replacement expression for an assignment, or returns null to keep it as-is.

In runes mode with a non-computed `this.x` member target, it looks up the class field: if the field is a constructor state declaration currently being assigned (left === field.node.left) and the right side is a rune call, it assigns either to the private property (for private keys or $state/$state.raw runes) or to the field's backing key; if the field is $derived/$derived.by with a private-key target, it becomes a call to the getter/setter member with the combined assignment value. Outside that special case, it strips member expressions to the base object; if the base is not an Identifier that is a `$store`-style name, or the underlying store variable is not in scope, it returns null. For a plain `$store = v` it emits `$.store_set(name, visited value)`; for member assignments like `$store.x += v`, it lazily initializes `$$store_subs ??= {}` and emits `$.store_mutate($$store_subs, '$store', name, visited assignment)`.

calls: [get_name](r3-scope-node-model.md#u-99af92983a86), [get_rune](r3-scope-node-model.md#u-5204b6ce4f7a), [build_assignment_value](r5-compiler-utilities.md#u-634ffef5ceee), [is_store_name](r1-compiler-transform-server.md#u-b851baaf8949)

**Uncertainties.**

- context.state.state_fields and context.state.scope.get(name) behavior (e.g. deconflicted names) depends on state/scope implementations not shown

<a id="u-b851baaf8949"></a>
### `is_store_name`

`function is_store_name(name)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/AssignmentExpression.js:L105-L107][f2]

Returns true when the name starts with '$' followed by a letter or underscore, i.e. looks like a store reference such as `$count` or `$_store`.

A lone `$` or `$1` is rejected because name[1] fails the regex test.

<a id="u-2f46ddefb329"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/ClassBody.js:ClassBody`

`export function ClassBody(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/ClassBody.js:L10-L81][f3]

Rewrites a class body in runes mode to expose state fields as getter/setter pairs backed by private fields.

If analysis.classes has no entry for this ClassBody (legacy mode), it defers via context.next(). Otherwise it builds a new body: first, for each non-private state field whose declaration is a constructor AssignmentExpression with kind $derived/$derived.by, it inserts a backing property plus get/set accessors calling `this.#key` (setter passes `$$value`). Then it walks the original definitions: non-PropertyDefinitions are visited as-is; PropertyDefinitions with no matching field are visited; private-`#`, $state, and $state.raw fields are visited unchanged; a PropertyDefinition that IS the field node ($derived/$derived.by) is replaced by a backing prop initialized with the visited field value plus getter/setter methods. The rebuilt node is returned.

calls: [get_name](r3-scope-node-model.md#u-99af92983a86)

**Uncertainties.**

- What child_state.state_fields is consumed for ( coordination with AssignmentExpression/MemberExpression visitors) is evident only by shared state_fields shape

<a id="u-4790e3338b92"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/ConstTag.js:ConstTag`

`export function ConstTag(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/ConstTag.js:L10-L16][f4]

Turns an {@const} tag into a `const` declaration in the component init statements.

It visits the first declaration's id and init and pushes `b.const(id, init)` onto context.state.init; nothing is emitted into the template.

<a id="u-20e9980643b4"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/DebugTag.js:DebugTag`

`export function DebugTag(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/DebugTag.js:L10-L24][f5]

Emits a {@debug} tag as `console.log({...identifiers})` followed by a debugger statement in the template.

Each identifier becomes an init property whose value is the visited identifier.

<a id="u-04a9cafb9d3b"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/ExpressionStatement.js:ExpressionStatement`

`export function ExpressionStatement(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/ExpressionStatement.js:L10-L23][f6]

Drops effectful rune statements on the server.

If the statement's expression is a `$effect`, `$effect.pre`, `$effect.root`, or `$inspect.trace` rune, it returns an empty statement; otherwise it continues traversal with context.next().

<a id="u-20d147d776e2"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/HtmlTag.js:HtmlTag`

`export function HtmlTag(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/HtmlTag.js:L10-L13][f7]

Emits an {@html} tag by visiting its expression and pushing `$.html(expression)` as a template statement.

<a id="u-3c30c4f1dadd"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/Identifier.js:Identifier`

`export function Identifier(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/Identifier.js:L11-L19][f8]

Rewrites identifier references during expression transforms.

Only when the identifier is a reference relative to its parent path node: `$$props` is renamed to `$$sanitized_props`, and any other reference is passed to build_getter, whose result (or undefined for non-store/non-reactive names) is returned. Non-reference identifiers (property keys, member property positions) fall through with undefined, letting default handling apply.

calls: [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/utils.js:build_getter](r4-server-transform.md#u-25646e8536b2)

**Uncertainties.**

- build_getter's per-name behavior (store subs, props, etc.) is in shared/utils.js

<a id="u-d7255cb91ee9"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/RenderTag.js:RenderTag`

`export function RenderTag(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/RenderTag.js:L12-L35][f9]

Emits a snippet render tag `{@render foo(args)}` as a call statement with `$$payload` prepended.

The callee and each argument are visited (the expression is unwrapped through optional chaining), then b.call is used for a plain CallExpression and b.maybe_call for optional `?.()` forms. An empty hydration comment is appended unless skip_hydration_boundaries is set (e.g. standalone fragments).

calls: [unwrap_optional](r5-compiler-utilities.md#u-aa95700b7c80)

<a id="u-c2a9e301270e"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/SvelteBoundary.js:SvelteBoundary`

`export function SvelteBoundary(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/SvelteBoundary.js:L12-L38][f10]

Renders a `<svelteboundary>` by emitting BLOCK_OPEN, then exactly one of three pending renderings, then BLOCK_CLOSE.

If a `pending` attribute exists, its built value is called as a snippet with `$$payload`; otherwise if the fragment contains a snippet block named `pending`, its visited body is pushed; otherwise the whole fragment is visited. Precedence favors the attribute over the named snippet.

calls: [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/utils.js:build_attribute_value](r4-server-transform.md#u-8ce176223a22)

**Uncertainties.**

- Mismatch cases such as a non-snippet `pending` attribute value are not validated here; build_attribute_value's tolerance is defined elsewhere

<a id="u-781a760465d0"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/TitleElement.js:TitleElement`

`export function TitleElement(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/TitleElement.js:L10-L17][f11]

Renders `<svelte:title>` into an assignment to `$$payload.title`.

It builds the `<title>` open literal, processes the fragment children (text/expression only per comment) into a local template, appends the closing literal, then pushes the built template statements into state.init with `$$payload.title` as the assignment target.

calls: [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/utils.js:process_children](r4-server-transform.md#u-e9ea6b8060a4), [build_template](r4-server-transform.md#u-7d424d7f2d77)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/transform-server.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/AssignmentExpression.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/ClassBody.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/ConstTag.js
[f5]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/DebugTag.js
[f6]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/ExpressionStatement.js
[f7]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/HtmlTag.js
[f8]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/Identifier.js
[f9]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/RenderTag.js
[f10]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/SvelteBoundary.js
[f11]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/TitleElement.js
