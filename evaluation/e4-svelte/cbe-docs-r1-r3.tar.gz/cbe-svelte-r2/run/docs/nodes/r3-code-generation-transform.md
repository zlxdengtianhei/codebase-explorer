# Code Generation Transforms

**Capability.** Lowers the analyzed AST into runnable JavaScript, with parallel client (reactive DOM updates) and server (SSR string output) visitor sets over shared element-serialization helpers.

Use this subtree to see how analysis output becomes code. The client pass builds reactive update statements; the server pass builds render-time attribute and content serialization. Both lean on the scope/node model for binding and rune information.

**Children.**

- [Client Transform](r3-client-transform.md) `r3-client-transform` · 13 unit(s)
- [Server Transform](r3-server-transform.md) `r3-server-transform` · 10 unit(s)

Parent: [Compiler](r3-compiler.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
