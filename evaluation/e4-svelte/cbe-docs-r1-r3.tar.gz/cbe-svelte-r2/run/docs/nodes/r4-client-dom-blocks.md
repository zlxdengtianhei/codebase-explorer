# Client DOM Blocks

**Capability.** Runtime implementations of control-flow and special blocks in the DOM: conditional, await/async, dynamic component, head rendering, and element attachments, each swapping managed effects as their inputs change.

Use this subtree for how compiled blocks execute. if_block and await_block manage branch effect creation/resumption (await_block.update calls flushSync), head renders into document.head with hydration anchors, and attach re-runs attachment functions on change.

**Depends on.**

- [Reactive Batch Scheduling](r4-reactivity-scheduling.md) · graph-confirmed · 2 edge(s)
- [Effect Engine](r3-effects-engine.md) · graph-only · 24 edge(s)
- [Client Runtime](r1-client-runtime.md) · graph-only · 16 edge(s)

Parent: [Runtime](r4-runtime.md)

## Units (11)

<a id="u-0ce28dacb587"></a>
### `async`

`export function async(node, expressions, fn)` · [packages/svelte/src/internal/client/dom/blocks/async.js:L11-L26][f1]

Renders an async block's contents once its awaited expressions resolve, tracking pending count on the enclosing boundary.

It gets the pending boundary and increments its pending count, then flattens the expressions; the callback eagerly reads every derived value with get() before invoking fn, so a rejection prevents fn from creating any block, while the finally clause always decrements the pending count.

**Notes.**

- failure: Rejections during the eager get() loop propagate out of the callback after the finally has already decremented the pending count; fn is never called in that case.

calls: [get_pending_boundary](r1-client-boundaries.md#u-662729eaf177), [flatten](r2-async-reactivity.md#u-c50793421b66)

**Uncertainties.**

- Whether the flatten callback can run more than once is not visible here; if it did, pending count would be incremented once but decremented per callback invocation.

<a id="u-05916687a6e9"></a>
### `packages/svelte/src/internal/client/dom/blocks/await.js:update`

`function update(state, restore)` · [packages/svelte/src/internal/client/dom/blocks/await.js:L76-L132][f2]

Swaps which await snippet is active: resumes the existing effect for the target state or creates it via branch, and pauses effects of the other states, nulling them in pause callbacks.

When `restore` is true it first saves-then-sets active effect/reaction, component context, and DEV component function/stack so snippet code runs with the original component's context, restoring nulls in `finally` and calling flushSync so the DOM updates in the same tick as resolution. `restore=false` (the non-promise input path) skips all context save/restore and the flushSync. Always sets `resolved = true` on entry, canceling any queued pending microtask. Exceptions from effect work propagate after the finally-block restoration.

uses: [await_block](r4-client-dom-blocks.md#u-b5b91edad075)

**Uncertainties.**

- Whether both set_active_effect and set_active_reaction are required is flagged as uncertain by the in-code TODO.

<a id="u-b5b91edad075"></a>
### `await_block`

`export function await_block(node, get_input, pending_fn, then_fn, catch_fn)` · [packages/svelte/src/internal/client/dom/blocks/await.js:L42-L76][f2]

Renders pending/then/catch snippets of an awaited promise, swapping effect branches as the input promise resolves, rejects, or is replaced.

On setup it creates a source (or mutable source when not in runes mode) for the value and one for the error. The returned block effect re-runs when the input changes: if the input is a promise it registers then/catch callbacks that ignore stale promises (identity check `promise !== input`), set the corresponding source, and update branches with context restoration; while hydrating it renders the pending snippet immediately, otherwise it queues a microtask that shows pending only if still unresolved. If the input is not a promise it sets the value source and shows the then branch directly without restoration. Rejection with no catch_fn rethrows `error_source.v`. Hydration mismatch (promise vs `HYDRATION_START_ELSE` comment) removes server nodes and resumes hydration afterwards. The effect's cleanup resets the input to UNINITIALIZED so stale promise callbacks become no-ops. After hydrating, the anchor becomes hydrate_node.

**Notes.**

- failure: A rejected promise without a catch snippet rethrows the stored error after entering the CATCH state, propagating out of the microtask.
- side_effect: The effect teardown sets the captured input to UNINITIALIZED, disabling later resolve/reject callbacks of a replaced promise.

calls: [packages/svelte/src/internal/client/dom/blocks/await.js:update](r4-client-dom-blocks.md#u-05916687a6e9); imports: [await.js module code (L1–L41)][f2]

**Uncertainties.**

- Behavior of branch/pause_effect/resume_effect and internal_set comes from their use here; their internal semantics are outside this file.

<a id="u-7ea0ede4bea2"></a>
### `packages/svelte/src/internal/client/dom/blocks/if.js:commit`

`function commit()` · [packages/svelte/src/internal/client/dom/blocks/if.js:L54-L79][f3]

Finalizes a branch switch: restores the offscreen fragment into the DOM (removing its temporary text anchor), resumes the effect matching the current condition, and pauses the other effect with a callback that nulls the corresponding slot.

Assumes exactly one side is active per the truthiness of condition.

<a id="u-ae7c5c1016f1"></a>
### `update_branch`

`const update_branch = ( /** @type {boolean | null} */ new_condition, /** @type {null …` · [packages/svelte/src/internal/client/dom/blocks/if.js:L81-L136][f3]

Switches the if block to a new condition; identical consecutive conditions short-circuit.

During hydration a mismatch between the branch's boolean and the else-comment instruction removes the server-rendered DOM, disables hydrating, and resumes hydration mode after rendering. When appends are deferred, the new branch renders into a fresh offscreen fragment anchored by a text node, the incoming effect is removed from the batch's skipped set, the outgoing one added, and commit is scheduled as a batch callback; otherwise commit runs synchronously. Branch effects are created lazily with ??= so each side is built once and reused across toggles.

<a id="u-5467723df322"></a>
### `if_block`

`export function if_block(node, fn, elseif = false)` · [packages/svelte/src/internal/client/dom/blocks/if.js:L26-L46][f3]

Renders one of two branches based on a reactive condition, creating or resuming the active branch's effect and pausing the other.

The caller-provided fn receives set_branch; set_branch records that a branch was chosen and delegates to update_branch with the flag as the new condition. The block effect resets has_branch each run and calls update_branch(null, null) when no branch was selected, hiding both sides. Flags are EFFECT_TRANSPARENT for {:else if} chains (affecting transition locality) and 0 otherwise. Hydration advances past the opener at setup, and anchor is rewired to hydrate_node after hydrating. The commit fragment (if_block.commit) inserts any deferred offscreen fragment before the anchor (dropping its placeholder text) and resumes the active effect while pausing the inactive one with nulling callbacks; update_branch handles condition changes, hydration mismatch (boolean condition matching the else-comment removes server DOM and resumes hydrating), deferred rendering into an offscreen fragment with batch skipped-effect bookkeeping and a commit callback, and immediate commit otherwise.

calls: [update_branch](r4-client-dom-blocks.md#u-ae7c5c1016f1), [packages/svelte/src/internal/client/dom/blocks/if.js:commit](r4-client-dom-blocks.md#u-7ea0ede4bea2)

<a id="u-80bc19e4c534"></a>
### `if.js module code (L1–L25)`

`module_region` · [packages/svelte/src/internal/client/dom/blocks/if.js:L1-L25][f3]

Imports and the to-do note only; no executable behavior beyond the exported functions.

<a id="u-cf4f655ef743"></a>
### `component`

`export function component(node, get_component, render_fn)` · [packages/svelte/src/internal/client/dom/blocks/svelte-component.js:L17-L36][f4]

Mounts a dynamic component and swaps its rendered effect when the component identity changes, deferring swaps when the batch defers appending.

During hydration it advances first. A block effect returns early when get_component() yields the same component; when it changes and is truthy it branches a pending effect into an offscreen fragment with a text anchor if deferring (adding the current effect to the batch's skipped_effects so it is not torn down prematurely). commit pauses the old effect, re-inserts the offscreen fragment after removing its text anchor, and promotes the pending effect; commit runs immediately or as a batch callback. When the new component is falsy, only the commit scheduling runs, so the previous effect is paused and nothing renders. After setup, hydration moves the anchor to hydrate_node.

calls: [packages/svelte/src/internal/client/reactivity/effects.js:block](r3-effects-engine.md#u-75d755e7c63c), [effects.js-effect-creators](r3-effects-engine.md#u-27c9c7c4069f)

<a id="u-917be05a6f13"></a>
### `head`

`export function head(render_fn)` · [packages/svelte/src/internal/client/dom/blocks/svelte-head.js:L21-L68][f5]

Renders content into document.head inside a HEAD_EFFECT block, handling multiple head blocks during hydration.

While hydrating it saves the previous hydrate node; if head_anchor is unset it starts at head's first child and scans forward for a HYDRATION_START comment. If none is found, hydration is disabled (framework rendered body but not head); otherwise the hydrate node is set to the node after the marker and head_anchor tracks it. When not hydrating, a fresh text anchor is appended to head. The render effect runs in a try block; the finally restores hydrating to true, leaves head_anchor at the consumed hydrate node so the next head block continues from there, and restores the previous hydrate node when this call was hydrating.

calls: [packages/svelte/src/internal/client/reactivity/effects.js:block](r3-effects-engine.md#u-75d755e7c63c)

**Uncertainties.**

- head_anchor is module state shared across head blocks; concurrent or nested head calls could interleave unpredictably, which this file does not guard against.

<a id="u-484aa5d18aec"></a>
### `reset_head_anchor`

`export function reset_head_anchor()` · [packages/svelte/src/internal/client/dom/blocks/svelte-head.js:L13-L15][f5]

Clears the module-level head_anchor so the next head block re-scans document.head for its hydration marker.

<a id="u-89b96e9f81b2"></a>
### `attach`

`export function attach(node, get_fn)` · [packages/svelte/src/internal/client/dom/elements/attachments.js:L12-L33][f6]

Attaches a dynamically chosen attachment function to a DOM node, recreating it whenever the chosen function changes.

Inside a block effect, it compares the previous fn with get_fn(); on reference inequality it destroys the previous branch effect (if any) and, when the new fn is truthy, creates a branch containing an effect that calls fn(node). When fn becomes falsy only the old effect is destroyed. Because comparison is by reference, returning a new-but-equal function re-runs the attachment.

calls: [effects.js-effect-creators](r3-effects-engine.md#u-27c9c7c4069f), [packages/svelte/src/internal/client/reactivity/effects.js:block](r3-effects-engine.md#u-75d755e7c63c), [destroy_effect](r3-effects-engine.md#u-214ad59ce57a)

**Uncertainties.**

- Semantics of block/branch/destroy_effect (e.g. immediate vs deferred destruction) are defined outside this file.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/blocks/async.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/blocks/await.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/blocks/if.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/blocks/svelte-component.js
[f5]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/blocks/svelte-head.js
[f6]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/elements/attachments.js
