# Stores, Motion, and Reactive Values

**Capability.** User-facing reactive abstractions layered on the runtime: the store contract (writable/readable/derived/get), the spring animation primitive in both runes and legacy store forms, and reactive window values.

Use stores for the Svelte store contract, motion for spring physics animation, and reactive values for reactive window state. Springs build on writable; legacy spring shares tick_spring physics with the Spring class.

**Children.**

- [Store Contract](r6-stores.md) `r6-stores` · 6 unit(s)
- [Spring Motion](r6-motion.md) `r6-motion` · 4 unit(s)
- [Reactive Browser Values](r6-reactive-values.md) `r6-reactive-values` · 2 unit(s)

Parent: [Svelte Monorepo](r6-svelte-monorepo.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
