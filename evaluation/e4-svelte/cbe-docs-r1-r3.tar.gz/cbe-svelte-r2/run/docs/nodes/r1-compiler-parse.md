# Parse Phase

**Capability.** Converts raw component text into AST: validated <svelte:options> reading, a full recursive-descent CSS parser, and stripping of TypeScript-only syntax so later phases see plain JavaScript.

options.js handles <svelte:options> validation; style.js contains the entire CSS grammar as mutually recursive readers; remove_typescript_nodes.js is a post-parse type-stripping walk. Errors raised here flow through compiler diagnostics.

**Children.**

- [svelte:options Reading](r1-compiler-parse-options.md) `r1-compiler-parse-options` · 4 unit(s)
- [CSS Parsing](r1-compiler-parse-style.md) `r1-compiler-parse-style` · 14 unit(s)

**Depends on.**

- [Compiler Diagnostics](r1-compiler-diagnostics.md) · model-inferred · 0 edge(s)

Parent: [Svelte Compiler](r1-compiler.md)

## Units (1)

<a id="u-acabd3d60ba8"></a>
### `remove_typescript_nodes-js-strips-typescript-syntax-from-ast`

`function remove_this_param(node, context)` · [packages/svelte/src/compiler/phases/1-parse/remove_typescript_nodes.js:L11-L16][f1]

Strips TypeScript-only syntax from an already-parsed AST by walking it with zimmerframe, so the remaining JavaScript can be printed by esrap without confusing type artifacts.

The generic fallback `_` visitor deletes `typeAnnotation`, `typeParameters`, `typeArguments`, `returnType`, and `accessibility` from every node and recurses. Type-only syntax is removed: TSAsExpression, TSSatisfiesExpression, TSNonNullExpression, TSTypeAssertion, and TSInstantiationExpression are replaced by a visit of their inner expression; interfaces, type aliases, `declare` functions, `declare` variables, `declare` classes, and abstract methods become `b.empty`; `declare` property definitions are dropped by the ClassBody visitor (which rebuilds the body, visiting each child). Import/export handling: `import type`/`export type` declarations become `b.empty`; for value imports and named exports, type-kind specifiers are filtered out, and if none remain the whole declaration becomes `b.empty`; an ExportNamedDeclaration with a declaration whose visit produces an EmptyStatement declaration (i.e. it was erased) also becomes `b.empty`. Errors for unsupported TS features: decorators, `accessor` fields, enums, accessibility/readonly modifiers on constructor parameters, and namespaces whose bodies contain any non-empty node all raise `e.typescript_invalid_feature`. Functions named `this` as first parameter get that parameter shifted off. `remove_typescript_nodes(ast)` simply walks the given AST with these visitors and returns it.

**Uncertainties.**

- TSModuleDeclaration visits all body entries but always returns b.empty, so its non-type content is checked only for the error condition, not preserved; whether downstream passes see cleaned namespace contents is not visible here.
- Whether the mutate-in-place `delete` fallback plus returned nodes can leave stale type fields on nodes zimmerframe does not re-emit is not proven from this file.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/1-parse/remove_typescript_nodes.js
