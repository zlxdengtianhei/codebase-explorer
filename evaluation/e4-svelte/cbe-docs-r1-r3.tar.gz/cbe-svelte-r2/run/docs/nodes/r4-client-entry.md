# Client Entry and Lifecycle

**Capability.** The public client entry module: re-exports of the runtime API, component lifecycle hooks (onMount/onDestroy, deprecated beforeUpdate/afterUpdate, createEventDispatcher), getAbortSignal, and dev-only rune-global guards.

Use this subtree for the API surface apps import on the client. Lifecycle helpers require an active component context and share init_update_callbacks for legacy hook storage; throw_rune_error traps unassigned rune globals (grp:index-client-js-entry-points groups the re-exports and calls it).

**Depended on by.**

- [Legacy Compatibility \(Server\)](r4-legacy-compat.md) · model-inferred · 0 edge(s)

Parent: [Runtime](r4-runtime.md)

## Units (10)

<a id="u-6341627de73d"></a>
### `index-client-js-entry-points`

`group` · [packages/svelte/src/index-client.js:L1-L16][f1]

Client entry module re-exporting the runtime API and defining lifecycle helpers.

Module-level regions hold JSDoc imports and re-exports of flushSync, context functions, hydrate/mount/unmount, tick/untrack/settled and createRawSnippet from internal client modules. Under DEV the module installs rune-error traps via throw_rune_error; the exported lifecycle functions guard on `component_context` and either register effects or push legacy callbacks as detailed in their own units.

group: [throw_rune_error](r4-client-entry.md#u-766cb9a97e53)

<a id="u-3eabc3a794df"></a>
### `afterUpdate`

`export function afterUpdate(fn)` · [packages/svelte/src/index-client.js:L223-L233][f1]

Deprecated legacy hook scheduling `fn` after each component update; first run happens after the initial onMount.

Same guard sequence as beforeUpdate: throws `e.lifecycle_outside_component('afterUpdate')` outside a component and `e.lifecycle_legacy_only('afterUpdate')` in runes mode (`component_context.l === null`), then pushes `fn` onto the legacy callbacks object's `a` array.

calls: [init_update_callbacks](r4-client-entry.md#u-f15a32115088)

<a id="u-346a7286b04e"></a>
### `beforeUpdate`

`export function beforeUpdate(fn)` · [packages/svelte/src/index-client.js:L200-L210][f1]

Deprecated legacy hook scheduling `fn` before each component update; first run happens before the initial onMount.

Throws `e.lifecycle_outside_component('beforeUpdate')` outside a component, and `e.lifecycle_legacy_only('beforeUpdate')` when `component_context.l` is null (runes mode). Otherwise pushes `fn` onto the legacy callbacks object's `b` array.

calls: [init_update_callbacks](r4-client-entry.md#u-f15a32115088)

<a id="u-a13f6abb0775"></a>
### `createEventDispatcher`

`export function createEventDispatcher()` · [packages/svelte/src/index-client.js:L157-L185][f1]

Deprecated factory for legacy component event dispatchers; requires a component context or throws `e.lifecycle_outside_component('createEventDispatcher')`.

It captures `component_context` at creation time and returns a dispatcher `(type, detail, options)`. The dispatcher looks up handlers registered under `type` on the captured context's `$$events`; if none exist it returns true. Otherwise it copies the handler(s) (slicing arrays so mutation during dispatch is safe), builds a CustomEvent via `create_custom_event`, invokes each handler with `this` set to the context's `x` (the component instance), and returns `!event.defaultPrevented`, i.e. false when any handler called preventDefault.

calls: [create_custom_event](r4-client-entry.md#u-c36028ba992c)

**Uncertainties.**

- The graph offers three candidates for the iteration call; the `for...of` here iterates the local callbacks array, so the resolved targets are irrelevant to behavior visible here.

<a id="u-c36028ba992c"></a>
### `create_custom_event`

`function create_custom_event(type, detail, { bubbles = false, cancelable = false } = {})` · [packages/svelte/src/index-client.js:L130-L132][f1]

Constructs a CustomEvent of the given type with the provided detail; `bubbles` and `cancelable` default to false when the options object is omitted.

Internal helper for createEventDispatcher.

<a id="u-9fba83ef7551"></a>
### `getAbortSignal`

`export function getAbortSignal()` · [packages/svelte/src/index-client.js:L69-L75][f1]

Returns an AbortSignal tied to the currently running derived or effect.

When `active_reaction` is null it throws `e.get_abort_signal_outside_reaction()`. Otherwise it lazily creates an AbortController on the reaction's `ac` field and returns its signal, so the same controller is reused per reaction.

uses: [index-client-js-entry-points](r4-client-entry.md#u-6341627de73d)

**Uncertainties.**

- The signal aborts when the reaction re-runs or is destroyed is documented but the aborting itself lives outside this file.

<a id="u-f15a32115088"></a>
### `init_update_callbacks`

`function init_update_callbacks(context)` · [packages/svelte/src/index-client.js:L239-L242][f1]

Legacy-mode helper returning (and lazily creating) the `u` callbacks record on the context's legacy slot `l`: `{ a: [], b: [], m: [] }` for afterUpdate, beforeUpdate and onMount callbacks.

Casts the context to ComponentContextLegacy, so callers must already have ensured `l` is non-null.

<a id="u-de75503262fc"></a>
### `onDestroy`

`export function onDestroy(fn)` · [packages/svelte/src/index-client.js:L115-L121][f1]

Schedules a callback to run immediately before component unmount; requires an active component context or throws `e.lifecycle_outside_component('onDestroy')`.

Implemented on top of onMount: it registers `() => () => untrack(fn)`, so onMount's cleanup detection turns the inner function into the unmount cleanup, and `untrack` runs the callback outside reactive tracking.

calls: [onMount](r4-client-entry.md#u-3c1ac43e0c43)

<a id="u-3c1ac43e0c43"></a>
### `onMount`

`export function onMount(fn)` · [packages/svelte/src/index-client.js:L91-L104][f1]

Schedules a function to run once when the component mounts; must be called during component initialisation or it throws `e.lifecycle_outside_component('onMount')`.

In legacy mode with a legacy context (`legacy_mode_flag` and `component_context.l` non-null) the callback is pushed onto the legacy callbacks object's `m` list via `init_update_callbacks`. Otherwise it creates a user effect that calls `fn` inside `untrack` and, if `fn` returns a function synchronously, returns it as the cleanup so it runs on unmount; a returned Promise is discarded.

calls: [init_update_callbacks](r4-client-entry.md#u-f15a32115088); uses: [onDestroy](r4-client-entry.md#u-de75503262fc)

**Uncertainties.**

- In legacy mode the timing of `m` callbacks is handled elsewhere (context.l.u consumers not in this file).

<a id="u-766cb9a97e53"></a>
### `throw_rune_error`

`function throw_rune_error(rune)` · [packages/svelte/src/index-client.js:L16-L36][f1]

Dev-only guard that traps reads of unassigned rune globals like `$state`.

If the rune name is not already on `globalThis`, defines a configurable property whose getter either returns a previously set value or throws `e.rune_outside_svelte(rune)` on first read while undefined; the setter stores the value, so a genuine global assignment silences the error. Called at module load for $state, $effect, $derived, $inspect, $props and $bindable, only under DEV.

**Notes.**

- side_effect: Mutates globalThis with intercepted properties at module load time when DEV is true.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/index-client.js
