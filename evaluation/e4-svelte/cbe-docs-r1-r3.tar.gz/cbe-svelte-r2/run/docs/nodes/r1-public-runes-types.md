# Rune Ambient Types

**Capability.** Ambient declarations giving the runes ($state, $derived, $effect, $props, $bindable, $inspect, $host) and '*.svelte' imports their compile-time type surface for TypeScript tooling.

No runtime behavior; edit when rune type signatures change. The module declaration for *.svelte keeps legacy component typing for editors.

Parent: [Public API Surface](r1-public-surface.md)

## Units (8)

<a id="u-2b06af83867c"></a>
### `ambient.d.ts-$bindable`

`declare function $bindable<T>(fallback?: T): T;` · [packages/svelte/src/ambient.d.ts:L389-L389][f1]

Declares the $bindable rune, which marks a prop as bindable by parents via bind:.

It takes an optional fallback of type T and returns T. The namespace carries only deprecated never-typed constants to keep editors from offering function-object members.

<a id="u-282c7a452862"></a>
### `ambient.d.ts-$derived`

`declare function $derived<T>(expression: T): T;` · [packages/svelte/src/ambient.d.ts:L177-L177][f1]

Declares the $derived rune's type surface.

The function overload takes an expression of type T and returns T; the namespace's by variant takes a zero-argument function and returns its return type, for multi-statement derivations. Deprecated never-typed constants on the namespace exist only to keep editors from offering unhelpful function-object members.

<a id="u-6591b8c52961"></a>
### `ambient.d.ts-$effect`

`declare function $effect(fn: () => void | (() => void)): void;` · [packages/svelte/src/ambient.d.ts:L237-L237][f1]

Declares the $effect rune family.

The root function takes a callback returning void or a cleanup function, and runs after DOM updates whenever reactive dependencies change; its returned cleanup runs before re-run or on unmount, and it never runs during SSR. Namespace members: pre runs before DOM updates with the same cleanup semantics; pending returns the number of pending promises in the current boundary, excluding child boundaries; tracking reports whether code runs inside a tracking context such as an effect or template; root creates a manually managed, non-auto-cleaning effect scope and returns a cleanup function, usable outside component initialisation. Deprecated never-typed constants again suppress intellisense noise.

**Uncertainties.**

- Only signatures and doc comments are present; actual scheduling and cleanup behavior is implemented elsewhere.

<a id="u-c4b6e9768bad"></a>
### `ambient.d.ts-$host`

`declare function $host<El extends HTMLElement = HTMLElement>(): El;` · [packages/svelte/src/ambient.d.ts:L495-L495][f1]

Declares the $host rune, returning the this reference of the containing custom element, generic over an HTMLElement subtype (default HTMLElement).

It is usable only inside custom element components and only on the client. The namespace holds deprecated never-typed constants to suppress editor suggestions.

<a id="u-7316e49df4db"></a>
### `ambient.d.ts-$inspect`

`declare function $inspect<T extends any[]>( ...values: T ): { with: (fn: (type: 'init…` · [packages/svelte/src/ambient.d.ts:L432-L434][f1]

Declares the $inspect rune.

It is variadic over the inspected values and returns an object whose with method accepts a callback receiving the event type ('init' or 'update') and the values; by default values are logged to the console. Namespace member trace takes an optional name and must be the first statement of a function body; it records which reactive state changes caused an effect to re-run. Deprecated never-typed constants suppress intellisense noise.

<a id="u-55de8c748fa2"></a>
### `ambient.d.ts-$props`

`declare function $props(): any;` · [packages/svelte/src/ambient.d.ts:L346-L346][f1]

Declares the $props rune, typed as returning any so component prop destructuring type-checks against the component's declared prop types.

Namespace member id returns a string unique to the current component instance that stays consistent between server render and client hydration, intended for linking attributes like for and aria-labelledby; since 5.20.0. Deprecated never-typed constants suppress unhelpful namespace member suggestions.

<a id="u-b6bc286a55e9"></a>
### `ambient.d.ts-$state`

`declare function $state<T>(initial: T): T;` · [packages/svelte/src/ambient.d.ts:L23-L23][f1]

Declares the $state rune's type surface.

Two overloads accept an optional initial value: with an argument the return type is T, without one it is T | undefined. The namespace provides support types: Primitive; TypedArray covering all typed-array constructors; Cloneable enumerating structuredClone-compatible types (Date, Map, Set, Blob, File, etc.); NonReactive unwrapping SvelteDate/SvelteMap/SvelteSet to their plain counterparts via conditional-type inference; and Snapshot<T>, a recursive conditional that keeps primitives as-is, maps Cloneables through NonReactive, uses a toJSON return type when present, recurses into arrays, and maps index-signature objects property-by-property, resolving to never for objects lacking an index signature. raw declares shallow-reactive state whose value must be reassigned rather than mutated; snapshot declares extraction of a static value from a deep reactive proxy. The namespace also declares deprecated never-typed constants (apply, call, length, prototype, etc.) purely to suppress misleading intellisense on the namespace object.

**Uncertainties.**

- This file contains only declarations; the runtime implementation of these runes lives elsewhere and its behavior cannot be verified here.

<a id="u-798bc86c54c1"></a>
### `ambient.d.ts-svelte-module-declaration`

`declare module '*.svelte' { // use prettier-ignore for a while because of https://git…` · [packages/svelte/src/ambient.d.ts:L1-L7][f1]

Types every '*.svelte' import as a legacy Svelte 4 component class for tooling compatibility.

The declared module re-exports a const default typed as LegacyComponentType, with a companion type alias tying it to SvelteComponent, so TypeScript consumers of .svelte files get legacy-class typing.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/ambient.d.ts
