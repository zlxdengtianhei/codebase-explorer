# Element Bindings and Styles

**Capability.** Two-way bindings between DOM elements and reactive state (inputs, groups, files, this, contenteditable, document.activeElement, arbitrary properties) plus inline style directive application.

Use this subtree for runtime binding and styling behavior. Each bind_* function owns one binding kind; get_binding_group_value supports bind_group; set_style/update_styles apply style directives and call the shared to_style from internal/shared/attributes.

**Depends on.**

- [Reactive Batch Scheduling](r4-reactivity-scheduling.md) · model-inferred · 0 edge(s)
- [Runtime Shared Helpers](r4-runtime-shared.md) · graph-confirmed · 1 edge(s)
- [Effect Engine](r3-effects-engine.md) · graph-only · 10 edge(s)

Parent: [Runtime](r4-runtime.md)

## Units (12)

<a id="u-63ddea66ca81"></a>
### `bind_active_element`

`export function bind_active_element(update)` · [packages/svelte/src/internal/client/dom/elements/bindings/document.js:L7-L17][f1]

Binds document.activeElement changes to a callback by listening for focusin/focusout on document.

On focusout with a relatedTarget the handler returns early so the transient focus transfer to document.body is not reported; otherwise update(document.activeElement) runs. Listeners are removed via listen's teardown.

calls: [listen](r3-element-bindings.md#u-8f0d8dd6601b)

<a id="u-d6e0e6bda8ca"></a>
### `bind_checked`

`export function bind_checked(input, get, set = get)` · [packages/svelte/src/internal/client/dom/elements/bindings/input.js:L220-L240][f2]

Two-way binds a checkbox's checked state.

On change (or form reset, using defaultChecked) the value is pushed via set. At setup, hydrating divergence between defaultChecked and checked, or a nullish get(), pushes input.checked into state. A render_effect continuously sets input.checked = Boolean(value).

calls: [listen_to_event_and_reset_event](r3-element-bindings.md#u-adb7ad8d3643)

<a id="u-00ad8cbfeb28"></a>
### `bind_files`

`export function bind_files(input, get, set = get)` · [packages/svelte/src/internal/client/dom/elements/bindings/input.js:L287-L304][f2]

Two-way binds an input's files list.

On change (or reset via handler default) set(input.files) is called; during hydration with non-empty files the DOM state is pushed to state; a render_effect writes get() into input.files.

calls: [listen_to_event_and_reset_event](r3-element-bindings.md#u-adb7ad8d3643)

**Uncertainties.**

- input.files is normally read-only in browsers; assigning from the render_effect relies on platform/typing allowances not verifiable here.

<a id="u-dbd1fc23c7b5"></a>
### `bind_group`

`export function bind_group(inputs, group_index, input, get, set = get)` · [packages/svelte/src/internal/client/dom/elements/bindings/input.js:L126-L212][f2]

Two-way binds a radio or checkbox group.

The input is registered into a shared binding_group array, indexed by group_index when provided. On change, radios set the bound value to input.__value; checkboxes set it to the array of checked __values computed across the group; form reset sets [] or null. A render_effect syncs state to the DOM: checkbox checked = value.includes(__value), radio checked via is(__value, value); during hydration with divergent defaultChecked it defers via hydration_mismatch. teardown removes the input from the group. A microtask sorts the group by document position once (tracked in the module-level pending set) to keep insertion order stable. A second microtask applies hydration mismatch recovery: checkboxes recompute the group value, radios take the __value of the first checked input. teardown also removes the input from the group.

calls: [get_binding_group_value](r4-element-bindings.md#u-1bfc194f94a2), [listen_to_event_and_reset_event](r3-element-bindings.md#u-adb7ad8d3643), [is](r5-runtime-reactivity.md#u-dcae92a399e9)

**Uncertainties.**

- input.__value is set elsewhere (attribute handling), not in this file.

<a id="u-01d2720075cb"></a>
### `bind_value`

`export function bind_value(input, get, set = get)` · [packages/svelte/src/internal/client/dom/elements/bindings/input.js:L19-L113][f2]

Two-way binds an input's value to reactive state.

The input event reads defaultValue on form reset or input.value, coerces via to_number for number/range types, and calls set; the current batch is recorded in a WeakSet. After awaiting tick(), if the accessor's get() returns a different (validated/coerced) value, the input value is reassigned and the selection start/end restored, clamping end to the new length. At setup, when hydrating with a divergent defaultValue, or when get() is nullish and the input has a value, the DOM value is pushed into state. A render_effect pushes state into the DOM, with guards: if the input is focused and the recorded batch matches previous_batch ?? current_batch, the DOM value is never overwritten; numberlike inputs skip writes when to_number(input.value) equals the value (0 vs 00); empty date inputs on both sides are skipped; otherwise input.value is set only when it differs, assigning '' for nullish values. DEV mode throws on checkbox use both in the handler and the effect.

calls: [listen_to_event_and_reset_event](r3-element-bindings.md#u-adb7ad8d3643), [is_numberlike_input][f2], [to_number][f2]

**Uncertainties.**

- The exact semantics of previous_batch vs current_batch during effect runs are not visible in this file and are taken from the comment/usage.

<a id="u-1bfc194f94a2"></a>
### `get_binding_group_value`

`function get_binding_group_value(group, __value, checked)` · [packages/svelte/src/internal/client/dom/elements/bindings/input.js:L249-L265][f2]

Computes the bound value of a checkbox group: collects __value of every checked input into a Set, removes __value when the current input is unchecked, and returns the result as an array.

Order follows group array order, not DOM order.

<a id="u-7b1a63fed5a0"></a>
### `bind_this`

`export function bind_this(element_or_component = {}, update, get_value, get_parts)` · [packages/svelte/src/internal/client/dom/elements/bindings/this.js:L25-L61][f3]

Implements bind:this for elements and components.

An effect contains a render_effect that only tracks the each-block parts (not the value) to avoid needless reruns; untracked, when get_value(...parts) is not already the element_or_component (identity checked directly or via STATE_SYMBOL), update(element_or_component, ...parts) assigns it, and on parts changes (each-block context shift) the previous position is nulled with update(null, ...old_parts) if it still points at this component. Effect teardown nulls the binding at the current position via a microtask, since effects cannot run during teardown. Returns element_or_component unchanged.

calls: [bind_this](r4-element-bindings.md#u-7b1a63fed5a0)

<a id="u-08959d6f86b1"></a>
### `bind_content_editable`

`export function bind_content_editable(property, element, get, set = get)` · [packages/svelte/src/internal/client/dom/elements/bindings/universal.js:L11-L31][f4]

Two-way binds an editable element's innerHTML, textContent, or innerText.

An input listener pushes element[property] into state. A render_effect syncs state to the DOM when it differs; if the incoming value is null/undefined it pushes the element's current value back into state instead of overwriting, otherwise assigns value + '' (string coercion).

<a id="u-0d6d1a335820"></a>
### `bind_focused`

`export function bind_focused(element, set)` · [packages/svelte/src/internal/client/dom/elements/bindings/universal.js:L71-L75][f4]

Pushes whether the element is document.activeElement into a setter on focus and blur events, via listen with teardown removal.

calls: [listen](r3-element-bindings.md#u-8f0d8dd6601b)

<a id="u-b50b57e2cff1"></a>
### `bind_property`

`export function bind_property(property, event_name, element, set, get)` · [packages/svelte/src/internal/client/dom/elements/bindings/universal.js:L41-L42][f4]

Two-way binds an arbitrary element property via a custom event.

A handler pushes element[property] into state and is added as an event listener for event_name. If a get accessor is supplied, a render_effect writes get() into element[property]; otherwise the handler fires once to seed state from the DOM. Listener removal on teardown happens only for document.body, window, or document targets, since other elements' listeners die with the element.

<a id="u-dd07311bde30"></a>
### `set_style`

`export function set_style(dom, value, prev_styles, next_styles)` · [packages/svelte/src/internal/client/dom/elements/style.js:L30-L57][f5]

Sets an element's inline style from a template style string plus optional style directive objects, returning next_styles.

During hydration or when the cached __style differs from the value, it computes the full style attribute via to_style and writes it: removes the style attribute when null, otherwise assigns style.cssText — but only when not hydrating or the attribute actually differs; then caches on __style. Otherwise (cached value unchanged) it applies style directives incrementally: when next_styles is an array, first and second entries are updated with normal and 'important' priority respectively; otherwise a single object is updated normally.

calls: [to_style](r4-runtime-shared.md#u-50b25ac26373), [update_styles](r4-element-bindings.md#u-24fad240d483)

<a id="u-24fad240d483"></a>
### `update_styles`

`function update_styles(dom, prev = {}, next, priority)` · [packages/svelte/src/internal/client/dom/elements/style.js:L10-L22][f5]

Applies individual style properties that changed between prev and next: removes the property when the next value is null, otherwise sets it via style.setProperty, optionally with a priority (used for '!important').

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/elements/bindings/document.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/elements/bindings/input.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/elements/bindings/this.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/elements/bindings/universal.js
[f5]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/elements/style.js
