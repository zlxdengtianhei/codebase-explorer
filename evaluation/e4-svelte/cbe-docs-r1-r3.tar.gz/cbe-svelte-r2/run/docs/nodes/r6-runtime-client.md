# Client Runtime

**Capability.** Browser-side runtime: lazy derived signals and async deriveds, DOM template/block rendering, element effects (transitions, animations, misc element behaviors), legacy-mode compatibility, dev-mode diagnostics, and micro/idle task scheduling.

Use this subtree for everything that executes in the browser. Reactivity primitives are separated from DOM rendering, which is separated from dev-only tooling and legacy support.

**Children.**

- [Client Reactivity Core](r6-client-reactivity.md) `r6-client-reactivity` · 17 unit(s)
- [Dev-Mode Diagnostics](r6-client-dev.md) `r6-client-dev` · 3 unit(s)
- [DOM Template Blocks](r6-client-dom-blocks.md) `r6-client-dom-blocks` · 10 unit(s)
- [Element Effects and Transitions](r6-client-dom-elements.md) `r6-client-dom-elements` · 10 unit(s)
- [Legacy Component Lifecycle](r6-client-dom-legacy.md) `r6-client-dom-legacy` · 2 unit(s)
- [Task Scheduling](r6-client-dom-task.md) `r6-client-dom-task` · 5 unit(s)

Parent: [Svelte Monorepo](r6-svelte-monorepo.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
