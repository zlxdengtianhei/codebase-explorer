# Diagnostic Code Templates

**Capability.** Code-generation templates that turn message catalogs into generated error/warning functions: never-returning client errors, logging client warnings, and InternalCompileError-based compile errors sharing a throw helper.

Use this subtree when changing how compiler diagnostics are emitted. The CODE templates define the shape of every generated diagnostic function; the compile-error templates share one internal throw helper.

Parent: [Compiler](r3-compiler.md)

## Units (5)

<a id="u-96149b5e3a32"></a>
### `CODE`

`export function CODE(PARAMETER)` · [packages/svelte/scripts/process-messages/templates/client-errors.js:L10-L18][f1]

Template for generated client error functions that never return.

When DEV is truthy it builds an Error whose message is the code, the message text, and a svelte.dev/e/CODE link, renames it 'Svelte error', and throws it; otherwise it throws a bare Error containing only the documentation URL. During generation, placeholders CODE are replaced with the real code and MESSAGE with the message expression, and the JSDoc/parameters are expanded.

<a id="u-f81818d1f5e0"></a>
### `packages/svelte/scripts/process-messages/templates/client-warnings.js:CODE`

`export function CODE(PARAMETER)` · [packages/svelte/scripts/process-messages/templates/client-warnings.js:L10-L20][f2]

Template for generated client warning functions that log and return.

Under DEV it calls console.warn with a styled multi-line output (bold code line, normal message, svelte.dev/e/CODE link) using the module's bold/normal font-weight strings; otherwise it logs only the URL. Generation replaces CODE and MESSAGE placeholders and expands parameters.

<a id="u-255da5998640"></a>
### `InternalCompileError`

`class InternalCompileError extends Error` · [packages/svelte/scripts/process-messages/templates/compile-errors.js:L5-L14][f3]

Error subclass representing a Svelte compile error while sharing the CompileDiagnostic object shape.

The constructor calls super(message), clears this.stack (assigned in the constructor so it stays non-enumerable), creates a private #diagnostic CompileDiagnostic, copies all its properties onto this with Object.assign, and sets name to 'CompileError'. message is declared as an enumerable field so it survives serialization; toString and toJSON delegate to the private diagnostic. The comment explains this design: extending Error lets bundler plugins handle it, while copying diagnostic properties keeps error and warning shapes identical.

**Uncertainties.**

- CompileDiagnostic's constructor and methods are external to this file; delegation behavior is not verifiable here

<a id="u-e8b9aee0a1be"></a>
### `packages/svelte/scripts/process-messages/templates/compile-errors.js:CODE`

`export function CODE(node, PARAMETER)` · [packages/svelte/scripts/process-messages/templates/compile-errors.js:L58-L60][f3]

Template for generated compile-error functions.

After generation it calls e(node, '<CODE>', message + documentation URL) with the message text interpolated, so the thrown InternalCompileError carries the source position derived from node. Declared @returns {never} since e always throws.

calls: [e](r3-diagnostics-templates.md#u-1911ece83f7e)

<a id="u-1911ece83f7e"></a>
### `e`

`function e(node, code, message)` · [packages/svelte/scripts/process-messages/templates/compile-errors.js:L41-L50][f3]

Internal throw helper shared by all generated compile-error functions.

It derives start/end from the node argument: a plain number is treated as both start and end; null/undefined yields undefined bounds; otherwise node.start/node.end are read. It throws an InternalCompileError with the code and message plus a [start, end] position, falling back to end = start when only start is defined, and omitting the position entirely when start is undefined. Never returns normally.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/scripts/process-messages/templates/client-errors.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/scripts/process-messages/templates/client-warnings.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/scripts/process-messages/templates/compile-errors.js
