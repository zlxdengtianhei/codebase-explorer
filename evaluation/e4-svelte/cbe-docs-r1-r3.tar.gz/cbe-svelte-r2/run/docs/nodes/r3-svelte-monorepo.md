# Svelte Monorepo

**Capability.** Coordinates the Svelte compiler pipeline, the client runtime and reactive primitives, the legacy compatibility layers, and the developer tooling that benchmarks, tests, and serves the package.

Start here to navigate the repository. The compiler subtree covers parsing, analysis, and code generation; the runtime subtree covers client-side rendering and reactivity; the tooling subtree covers benchmarks and dev configuration.

**Children.**

- [Compiler](r3-compiler.md) `r3-compiler` · 0 unit(s)
- [Client Runtime](r3-runtime.md) `r3-runtime` · 0 unit(s)
- [Tooling and Developer Environment](r3-tooling.md) `r3-tooling` · 0 unit(s)

Parent: [Benchmarks and Developer Environment](tooling-and-dev-env.md)

## Units (2)

<a id="u-3c3f0a7bb39a"></a>
### `misc.js-legacy-helpers`

`export function reactive_import(fn)` · [packages/svelte/src/internal/client/dom/legacy/misc.js:L10-L22][f1]

Runtime helpers for legacy (`componentApi === 4`) component behavior.

`reactive_import(fn)` wraps a possibly-reactive import: the returned function, when called with one argument (a setter), increments an internal source counter, notifies dependents via `set`, and returns the argument; when called with no arguments it reads the source (registering the dependency) and returns `fn()`'s value. `bubble_event($$props, event)` (with `this` as the component) looks up `$$props.$$events[event.type]`, normalizes a single function or an array into a copy of the callback list, and invokes each with the preserved `this` so handlers see the component instance. `add_legacy_event_listener` initializes `$$props.$$events` and the per-event array with `||=` then pushes the callback, simulating `$on`. `update_legacy_props` iterates `$$new_props` and assigns only keys that already exist on `this`, relying on component accessors so real prop setters run; it cannot update keys that live in `$$props` or `$$restProps`.

calls: [packages/svelte/src/internal/client/reactivity/sources.js:set](r5-runtime-reactivity.md#u-452914169f68), [source](r5-runtime-reactivity.md#u-97497b70f31b)

**Uncertainties.**

- `is_array` is imported from shared utils; its exact behavior is standard but its definition is not in this file.
- How compiler-generated call sites pass `this` to bubble_event is not visible here.

<a id="u-062d00c282a7"></a>
### `proxy.test.ts-proxy-suite`

`const original = { count: 0, get x()` · [packages/svelte/src/internal/client/proxy.test.ts:L16-L22][f2]

Vitest suite for the state proxy covering: writes do not mutate the original object; getters are preserved and re-invoked on each read (side-effecting getter runs twice, original count stays 0); defineProperty on state succeeds with a plain data descriptor while the original is untouched and redefinition with accessor descriptors throws a /state_descriptors_fixed/ error; proxies nested inside other proxies are not re-wrapped (inner mutations read through outer); property deletion updates the proxy copy and deleting missing keys succeeds; and array push, index mutation past the end, and length shrink all copy-on-write into the proxy while the original array remains unchanged.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/legacy/misc.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/proxy.test.ts
