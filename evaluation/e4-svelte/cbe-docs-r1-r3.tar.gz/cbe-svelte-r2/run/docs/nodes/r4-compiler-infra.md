# Compiler Shared Infrastructure

**Capability.** Cross-phase utilities used by parsing, analysis, and codegen: ESTree node builders, CSS at-rule helpers, source-preserving regex replacement for preprocessing, and the analysis-phase type declarations.

Use this subtree when looking for shared building blocks rather than phase logic. Builders are consumed by codegen and parsing (e.g. acorn.js parse uses call; read_static_attribute contexts use key); replace_in_code underpins preprocessors; phases/css.js is shared between CSS analysis and CSS transform (both call is_keyframes_node).

**Depended on by.**

- [Client Transform](r4-client-transform.md) · model-inferred · 0 edge(s)
- [CSS Analysis](r4-css-analysis.md) · graph-confirmed · 1 edge(s)
- [CSS Transform](r4-css-transform.md) · graph-confirmed · 2 edge(s)
- [Template Parsing \(Phase 1\)](r4-template-parsing.md) · graph-confirmed · 1 edge(s)

Parent: [Compiler Pipeline](r4-compiler.md)

## Units (23)

<a id="u-b83c295c759f"></a>
### `builders-js-trivial-node-builders`

`export function array(elements = [])` · [packages/svelte/src/compiler/utils/builders.js:L10-L12][f1]

This group covers the one-line ESTree node factory helpers in builders.js — array, array_pattern, assignment_pattern, assignment, await (await_builder), binary, block, labeled, unary, conditional, logical, declaration, declarator, export_default, for_of, function_declaration, id, private_id, import_namespace, init, literal, member, member_id, object, object_pattern, prop, prop_def, rest, sequence, stmt, template, update, do_while, let_builder, const_builder, var_builder, for_builder, if_builder, return_builder, and the shared constants void0/empty/true/false/null/this/debugger.

Each constructs a plain object literal of the corresponding ESTree node type from its arguments, setting the conventional fields (e.g. `arrow` derives `expression: body.type !== 'BlockStatement'` and nulls `metadata`; `member` converts a string property to an Identifier and defaults computed/optional to false; `member_id` splits a dotted path into nested non-computed member accesses; `prop` always sets method/shorthand false and defaults computed false; `labeled` builds its label via `id`). Variable-declaration builders (`let`/`const`/`var`) wrap a single declarator, and `for`/`if`/`return` map directly onto their statement shapes with optional defaults (null init/argument, missing alternate). They have no branching, I/O, or failure paths beyond those field defaults.

<a id="u-b3e77b1d8760"></a>
### `call`

`export function call(callee, ...args)` · [packages/svelte/src/compiler/utils/builders.js:L99-L124][f1]

Builds a CallExpression from a string callee (converted to an Identifier) or an expression, filling positional arguments.

Trailing falsy arguments are removed; falsy arguments followed by truthy ones are replaced with the identifier `undefined`, so call sites preserve positional arity without trailing undefined noise. The resulting node has `optional: false`.

**Uncertainties.**

- Arguments with falsy-but-intended values (e.g. the number 0 or empty string) would be replaced or dropped; callers must avoid passing such values as placeholders

<a id="u-289295de5e95"></a>
### `function_builder`

`function function_builder(id, params, body, async = false)` · [packages/svelte/src/compiler/utils/builders.js:L591-L601][f1]

Builds a FunctionExpression with optional name identifier, params, block body, and async flag (default false); `generator` is always false and `metadata` is nulled since it is not consumed by codegen.

<a id="u-da8832cd2a82"></a>
### `get`

`export function get(name, body)` · [packages/svelte/src/compiler/utils/builders.js:L249-L251][f1]

Builds a getter Property: `prop('get', key(name), function_builder(null, [], block(body)))`, i.e. a zero-parameter function expression as the property value with the key chosen by `key`.

calls: [key](r4-compiler-infra.md#u-7b974afef5ad)

<a id="u-dad6e966f812"></a>
### `import_all`

`export function import_all(as, source)` · [packages/svelte/src/compiler/utils/builders.js:L618-L624][f1]

Builds `import * as <as> from '<source>'` as an ImportDeclaration whose sole specifier is a namespace specifier built by `import_namespace`, with the source as a string Literal.

calls: [builders-js-trivial-node-builders](r4-compiler-infra.md#u-b83c295c759f)

<a id="u-684e3e0272bc"></a>
### `imports`

`export function imports(parts, source)` · [packages/svelte/src/compiler/utils/builders.js:L631-L641][f1]

Builds a named-imports declaration from `[imported, local]` string pairs: each pair becomes an ImportSpecifier with Identifier `imported` and `local` names, under the given string-literal source.

<a id="u-7b974afef5ad"></a>
### `key`

`export function key(name)` · [packages/svelte/src/compiler/utils/builders.js:L682-L684][f1]

Chooses a property key node: a valid identifier string (per `regex_is_valid_identifier`) becomes an Identifier; anything else becomes a string Literal, so keys like `'a-b'` stay quoted in output.

uses: [regex_is_valid_identifier][f2]

<a id="u-7766cd33ccfc"></a>
### `maybe_call`

`export function maybe_call(callee, ...args)` · [packages/svelte/src/compiler/utils/builders.js:L131-L139][f1]

Builds an optional-chaining call: it reuses `call` to construct a CallExpression, forces `optional: true` on it, and wraps the result in a ChainExpression.

calls: [call](r4-compiler-infra.md#u-b3e77b1d8760)

<a id="u-296c11447ae8"></a>
### `method`

`export function method(kind, key, params, body, computed = false, is_static = false)` · [packages/svelte/src/compiler/utils/builders.js:L573-L582][f1]

Builds a MethodDefinition: the value is a FunctionExpression created by `function_builder(null, params, block(body))` with the given kind ('constructor' | 'method' | 'get' | 'set'), key, computed flag (default false), and static flag (default false).

calls: [function_builder](r4-compiler-infra.md#u-289295de5e95)

<a id="u-c4697c8f3403"></a>
### `new_builder`

`function new_builder(expression, ...args)` · [packages/svelte/src/compiler/utils/builders.js:L481-L489][f1]

Builds a NewExpression, converting a string callee to an Identifier.

Exported indirectly only through `throw_error`; the arguments are used as given, with no undefined-filling like `call`.

**Uncertainties.**

- Not exported directly from the module (no `export` on the declaration), so reachable only via other builders

<a id="u-44404e861756"></a>
### `quasi`

`export function quasi(cooked, tail = false)` · [packages/svelte/src/compiler/utils/builders.js:L374-L377][f1]

Builds a TemplateElement from cooked string content.

The raw value is produced by `sanitize_template_string(cooked)` (escaping for template-literal output), and both `raw` and `cooked` are set to that sanitized string; `tail` defaults to false and marks the final element.

calls: [sanitize_template_string](r2-compiler-infrastructure.md#u-01781e43d6ff)

**Uncertainties.**

- The cooked field is assigned the sanitized rather than original string; downstream effect of that choice is outside this file

<a id="u-5d5cf405daf0"></a>
### `set`

`export function set(name, body)` · [packages/svelte/src/compiler/utils/builders.js:L400-L402][f1]

Builds a setter Property: like `get` but the function expression takes one parameter named `$$value` (`prop('set', key(name), function_builder(null, [id('$$value')], block(body)))`).

calls: [key](r4-compiler-infra.md#u-7b974afef5ad)

<a id="u-09b5e18750ea"></a>
### `throw_error`

`export function throw_error(str)` · [packages/svelte/src/compiler/utils/builders.js:L655-L660][f1]

Builds `throw new Error('<str>')`, combining `new_builder('Error', literal(str))` inside a ThrowStatement.

calls: [new_builder](r4-compiler-infra.md#u-c4697c8f3403)

<a id="u-07dc2343b5b7"></a>
### `thunk`

`export function thunk(expression, async = false)` · [packages/svelte/src/compiler/utils/builders.js:L434-L436][f1]

Wraps an expression in a zero-parameter arrow function to defer evaluation; `async = true` produces an async arrow.

The arrow is passed through `unthunk`, so trivially-inlinable thunks may be collapsed back to the bare expression.

calls: [unthunk](r4-compiler-infra.md#u-98dc49f1a7a8)

<a id="u-98dc49f1a7a8"></a>
### `unthunk`

`export function unthunk(expression)` · [packages/svelte/src/compiler/utils/builders.js:L443-L449][f1]

Optimizes arrow functions that merely forward their parameters.

First case: for an async arrow whose body is a bare `await x()` (no nested awaits inside `x`, checked by walking the argument and stopping at any AwaitExpression), it rebuilds a non-async arrow around the awaited argument and recurses. Second case: a non-async arrow whose body is a CallExpression with an Identifier callee, whose parameters exactly match the call arguments one-to-one by identifier name and count, is replaced by the callee expression itself — `(a, b) => fn(a, b)` becomes `fn`. Any other arrow is returned unchanged.

**Uncertainties.**

- The parameter/argument match compares only names and positions; scoping or shadowing differences are not analyzed

<a id="u-8dc3955e3495"></a>
### `is_keyframes_node`

`export const is_keyframes_node = (node) =>` · [packages/svelte/src/compiler/phases/css.js:L14-L14][f3]

Reports whether a CSS AST at-rule is a keyframes rule by prefix-stripping its name and comparing to 'keyframes', so -webkit-keyframes also matches.

calls: [remove_css_prefix](r4-compiler-infra.md#u-e3a939a3b9f2)

<a id="u-e3a939a3b9f2"></a>
### `remove_css_prefix`

`export function remove_css_prefix(name)` · [packages/svelte/src/compiler/phases/css.js:L9-L11][f3]

Strips a leading vendor prefix (-webkit-, -moz-, -o-, -ms-) from an at-rule name via regex replace and returns the result; pure, no AST mutation.

Names with a leading dash not followed by a known vendor are unchanged.

uses: [css.js module code (L1–L8)](r4-compiler-infra.md#u-c3bf87758682)

<a id="u-c3bf87758682"></a>
### `css.js module code (L1–L8)`

`module_region` · [packages/svelte/src/compiler/phases/css.js:L1-L8][f3]

Module constants for CSS compiler phases: a vendor-prefix regex (-webkit-/-moz-/-o-/-ms- at string start) used by remove_css_prefix, and an exported regex matching a CSS name boundary character (whitespace, comma, semicolon, or closing brace).

<a id="u-8a9b3380f617"></a>
### `calculate_replacements`

`function calculate_replacements(re, get_replacement, source)` · [packages/svelte/src/compiler/preprocess/replace_in_code.js:L24-L40][f4]

Collects replacement descriptors for every regex match: String.replace drives the scan (returning '' only to discard the matched text, not to mutate anything), and for each match get_replacement(...match) is called, producing a promise resolving to { offset (match's second-to-last argument, the match index), length (matched string length), replacement }.

Returns Promise.all of these promises, so a rejected preprocessor rejects the whole batch; ordering follows match order, and matching is synchronous with String.replace semantics.

<a id="u-35d5b911e638"></a>
### `perform_replacements`

`function perform_replacements(replacements, source)` · [packages/svelte/src/compiler/preprocess/replace_in_code.js:L47-L61][f4]

Assembles the final output MappedCode from ordered replacement descriptors.

It walks replacements in order, appending the unchanged source text between the previous end and each replacement's offset (mapped via slice_source), then the replacement MappedCode, and finally the unchanged suffix after the last replacement. Note concat is invoked for its return value chain; the intermediate `out.concat(unchanged_prefix).concat(replacement)` results are not reassigned, so correctness depends on concat mutating `out` or the final concat including prior content — the final result returned is out.concat(unchanged_suffix).

calls: [slice_source](r4-compiler-infra.md#u-b98556db32bb); uses: [packages/svelte/src/compiler/utils/mapped_code.js][f5]

**Uncertainties.**

- Whether concat mutates the receiver or returns a new MappedCode is not visible here; if it returns a new instance, the intermediate results would be discarded and only the suffix concatenation would matter.

<a id="u-8eab9628969e"></a>
### `replace_in_code`

`export async function replace_in_code(regex, get_replacement, location)` · [packages/svelte/src/compiler/preprocess/replace_in_code.js:L69-L72][f4]

Asynchronously replaces all regex matches in location.source with MappedCode replacements: calculate_replacements gathers per-match replacements (invoking get_replacement), then perform_replacements stitches unchanged text and replacements into one mapped output.

calls: [calculate_replacements](r4-compiler-infra.md#u-8a9b3380f617), [perform_replacements](r4-compiler-infra.md#u-35d5b911e638)

<a id="u-b98556db32bb"></a>
### `slice_source`

`export function slice_source(code_slice, offset, { file_basename, filename, get_locat…` · [packages/svelte/src/compiler/preprocess/replace_in_code.js:L10-L17][f4]

Derives a sub-Source from a source string slice at a given offset: the returned object carries the slice as source and the original file_basename/filename, and its get_location re-bases indices so a lookup at index i reports the location at i + offset in the full source.

This is what lets tag-content preprocessors report positions relative to the whole file.

<a id="u-689ee810dba7"></a>
### `types.d.ts-interfaces`

`export interface Js` · [packages/svelte/src/compiler/phases/types.d.ts:L12-L17][f6]

Type declarations for the compiler's analysis phases.

`Js` and `Template` hold each phase's ESTree/AST, scope, and per-node scope map; `Js` additionally records whether a top-level `await` exists. `ReactiveStatement` collects the assignments and dependencies of a `$:` block. `Analysis` carries data shared by module and component compilation (deprecated `name`/`runes`, immutability, tracing, comments, class state fields, accessor flag, and the set of deriveds containing `await`). `ComponentAnalysis` extends it with everything component-specific: instance/template phases, elements for CSS scoping, runes detection, exports, legacy `$$props`/`$$restProps`/`$$slots` usage, context needs, event-directive info, custom-element options, style injection, reactive statements, bind:group bindings, slot names, CSS output data, source text, and snippet/render-tag bookkeeping. The `declare module 'estree'` block augments arrow, function-expression, and function-declaration nodes with `metadata` (hoisted flag, hoisted params, scope). No runtime behavior.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/utils/builders.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/patterns.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/css.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/preprocess/replace_in_code.js
[f5]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/utils/mapped_code.js
[f6]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/types.d.ts
