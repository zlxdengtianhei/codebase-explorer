# Reactive Collections & Motion

**Capability.** User-facing reactive values: the reactive SvelteURLSearchParams class tracked via version state (with SvelteSet covered by its test suite), tweened motion via the reactive Tween class and the deprecated writable-wrapping tweened store, and built-in transition factories (blur, fade, fly, scale, slide, draw, crossfade) built on local helpers.

Tween/tweened schedule frames through the client loop; transitions are pure config factories. set.test.ts documents reactive-collection mutation semantics.

**Depends on.**

- [Client Runtime](r1-client-runtime.md) · graph-confirmed · 2 edge(s)
- [Client Runtime Reactivity](r5-runtime-reactivity.md) · graph-only · 9 edge(s)

Parent: [Public API Surface](r1-public-surface.md)

## Units (13)

<a id="u-0a3d9aa213c7"></a>
### `index-js-local-helpers`

`const linear = (x) =>` · [packages/svelte/src/transition/index.js:L7-L7][f1]

Local helpers for the transition module.

linear returns its input. cubic_out eases out with (t-1)^3 + 1; cubic_in_out is piecewise: 4t^3 for t<0.5, else 0.5*(2t-2)^3 + 1. split_css_unit parses a number-or-string into a [value, unit] tuple: a string matching an optional sign, digits/decimal point, and trailing unit yields [parseFloat, unitOr 'px']; any non-matching string, and any non-string value, yields [value, 'px']. assign copies all enumerable own-in keys from src onto tar and returns tar (mutates the first argument).

<a id="u-ade423f2a64a"></a>
### `Tween`

`class Tween` · [packages/svelte/src/motion/tweened.js:L179-L193][f2]

Reactive tween class whose current value animates toward its target using delay, duration, easing, and interpolate options (defaults 0, 400, linear, get_interpolator), merged from the constructor's #defaults with each set call's options.

The constructor seeds #current/#target state signals with the initial value and tags them in DEV. set(value, options) first writes #target; when the merged duration is 0 it aborts any running task, snaps #current to value, and resolves immediately. Otherwise it starts at raf.now() + delay: the loop callback returns true while waiting; on the first active tick it captures the previous current, builds the interpolator, resolves function durations as duration(prev, value), and aborts the task captured before this call; when elapsed exceeds duration it publishes the final value and stops; intermediate ticks publish fn(easing(elapsed/duration)). The returned promise is the loop task's promise. static of(fn, options) seeds a Tween with fn() and registers a render_effect calling tween.set(fn()) so reactive changes retarget the tween; getters expose current and target, and the target setter delegates to set(v).

calls: [loop](r1-client-runtime.md#u-4df1fec218a0); uses: [get_interpolator](r1-public-reactivity-motion.md#u-6d9737c2921d), [effects.js-effect-creators](r3-effects-engine.md#u-27c9c7c4069f)

**Uncertainties.**

- The loop task promise's rejection behavior is defined in loop.js, outside this batch.
- Unlike the legacy tweened.set, the previous task is only aborted on the first active tick, so a superseded tween keeps animating during the new delay period.

<a id="u-6d9737c2921d"></a>
### `get_interpolator`

`function get_interpolator(a, b)` · [packages/svelte/src/motion/tweened.js:L20-L79][f2]

Builds a (t) => T interpolator between values a and b, recursing into composite structures.

If a === b or a is NaN it returns a constant function of a. It throws 'Cannot interpolate values of different type' when a and b differ in typeof or array-ness. Arrays produce per-element interpolators combined positionally; plain objects require both non-null (throwing 'Object cannot be null' otherwise), special-case two Dates into a linear time interpolation, and otherwise interpolate over b's keys per property; numbers interpolate linearly via a + t*delta. Any other type snaps immediately to b.

calls: [is_date](r4-motion-library.md#u-c15d4b363055)

**Uncertainties.**

- Key sets are taken from b only, so keys missing in a are not explicitly handled beyond the recursion.

<a id="u-666b38d81067"></a>
### `packages/svelte/src/motion/tweened.js:set`

`function set(new_value, opts)` · [packages/svelte/src/motion/tweened.js:L99-L153][f2]

Legacy tweened store's set: records the new target and starts or replaces a loop-driven animation.

If the store's value is still null/undefined it publishes the new value immediately and resolves. Options merge over the store's defaults, defaulting to delay 0, duration 400, linear easing, and get_interpolator. When duration === 0 it aborts the previous task, publishes the target, and resolves immediately. Otherwise it schedules a loop starting at raf.now() + delay: before the start time the callback keeps ticking (returning true); on first tick after start it builds the interpolator from the current value, resolves function durations as duration(from, to), and aborts the previous task; once elapsed exceeds duration it publishes the final value and stops; on each intermediate tick it publishes fn(easing(elapsed/duration)). The returned promise is the loop task's promise.

calls: [loop](r1-client-runtime.md#u-4df1fec218a0), [get_interpolator](r1-public-reactivity-motion.md#u-6d9737c2921d)

**Uncertainties.**

- The task promise's rejection semantics live in loop.js, outside this batch.

<a id="u-a3154029292c"></a>
### `tweened`

`export function tweened(value, defaults = {})` · [packages/svelte/src/motion/tweened.js:L90-L99][f2]

Deprecated legacy tweened store: wraps a writable store and animates its value from the current value to each set/update target over time.

The returned object exposes set, update (delegating to set with fn(target_value, value) and the same opts), and subscribe; per-call delay/duration/easing/interpolate semantics live in the nested set closure.

calls: [writable](r6-stores.md#u-dc45d71b793b); uses: [get_interpolator](r1-public-reactivity-motion.md#u-6d9737c2921d)

<a id="u-bc7188c78465"></a>
### `SvelteURLSearchParams`

`class SvelteURLSearchParams extends URLSearchParams` · [packages/svelte/src/reactivity/url-search-params.js:L35-L41][f3]

A reactive URLSearchParams subclass tracking changes via an internal version state.

Read methods (`get`, `getAll`, `has`, `keys`, `values`, `entries`, `toString`, `size`, and iteration) read `#version` so effects/deriveds re-run on mutation; writers (`append`, `delete`, `set`, `sort`) delegate to URLSearchParams, then bump the version, and additionally sync the query string to `#url` (captured at construction via `get_current_url`) through `#update_url`. `#update_url` is skipped when there is no current URL or when `#updating` is set, and it writes `?...` only when the serialized params are non-empty. `delete` and `set` bump the version only when the mutation actually changed contents (`has` check, or comparing joined values before/after), avoiding spurious invalidation. The internal `[REPLACE]` symbol method swaps all params for those of another URLSearchParams under the `#updating` guard, then bumps the version; it and `#update_url` skip re-entrant updates.

calls: [state](r5-runtime-reactivity.md#u-acd426d0030b), [get_current_url](r5-reactive-builtins.md#u-35dc648e13ac), [increment](r5-runtime-reactivity.md#u-8fa6038c59d8), [packages/svelte/src/internal/client/runtime.js:get](r2-reactivity-core.md#u-98099fbbf12a)

**Uncertainties.**

- `#url.search = ...` relies on SvelteURL's search setter to sync back to the URL instance; that setter's behavior is outside this file.
- Graph candidates for super.* calls are ambiguous, but the source shows they delegate to the URLSearchParams base class.

<a id="u-bc2c7a4069fc"></a>
### `blur`

`export function blur( node, { delay = 0, duration = 400, easing = cubic_in_out, amoun…` · [packages/svelte/src/transition/index.js:L38-L53][f1]

Builds a TransitionConfig animating opacity and a CSS blur filter.

Reads the node's computed opacity and filter (an existing filter is preserved; 'none' becomes empty string) once at creation. Defaults: delay 0, duration 400, easing cubic_in_out, amount 5, opacity 0. amount is decomposed into value and unit via split_css_unit, so units like 'rem' are preserved. The css callback interpolates from the target opacity toward opacity*target and from 0 blur to u*value+unit as the transition progresses (u goes 1→0 on 'in'), producing `opacity: ...; filter: <kept filter> blur(<u*value><unit>)`.

calls: [index-js-local-helpers](r1-public-reactivity-motion.md#u-0a3d9aa213c7)

**Uncertainties.**

- getComputedStyle behavior in non-DOM environments is not defined here.

<a id="u-604bb627ffc1"></a>
### `packages/svelte/src/transition/index.js:crossfade`

`export function crossfade({ fallback, ...defaults })` · [packages/svelte/src/transition/index.js:L233-L245][f1]

Creates a matched pair of send/receive transition factories that animate an element between two positions.

Two module-level Maps (to_send, to_receive) pair nodes by key: calling the send factory registers (key, node) in to_send, and when its transition function runs, if the key exists in to_receive the counterpart node is taken and deleted from that map and the inner crossfade(other_node, node, params) computes the config; likewise for receive with roles swapped. The inner crossfade merges defaults (everything in the params object except fallback) with per-call params via nested assign, defaulting delay 0, duration to d => sqrt(d)*30 (d = pixel distance between the two rects), easing cubic_out. It reads both bounding rects for dx, dy, and width/height ratios, plus the moving node's computed transform and opacity, and returns a config whose css callback fades by t*opacity and translates/scales from the counterpart position (translate(u*dx, u*dy), scale interpolating t + (1-t)*dw/dh) with transform-origin top left; duration may itself be a function of the distance. When no counterpart exists (the node vanishes entirely), the pending key is removed from the items map and the user-supplied fallback(node, params, intro) is returned as the transition (possibly undefined).

**Notes.**

- condition: fallback is used only when the counterpart key was never registered or was already consumed.
- side_effect: Both maps persist across transitions for the lifetime of the returned pair; consumed keys are deleted to keep pairings one-to-one.

calls: [packages/svelte/src/transition/index.js:crossfade](r1-public-reactivity-motion.md#u-604bb627ffc1), [index-js-local-helpers](r1-public-reactivity-motion.md#u-0a3d9aa213c7)

<a id="u-72385efb0ac6"></a>
### `draw`

`export function draw(node, { delay = 0, speed, duration, easing = cubic_in_out } = {})` · [packages/svelte/src/transition/index.js:L186-L210][f1]

Builds a TransitionConfig animating an SVG path's stroke drawing via stroke-dasharray/stroke-dashoffset.

Requires node.getTotalLength; length is measured once, and increased by the integer stroke width when strokeLinecap is not 'butt' (so round/square caps stay visible). Duration resolution: if duration is undefined, it becomes 800 unless speed is given, in which case duration = len / speed; if duration is a function it is called with len; otherwise the given number is used. Default easing cubic_in_out. The css callback maps u to dashoffset u*len with dasharray len, producing draw-in/erase-out.

**Notes.**

- condition: Four mutually ordered duration cases: undefined+no speed → 800; undefined+speed → len/speed; function → duration(len); otherwise number.

**Uncertainties.**

- Calling on elements without getTotalLength (non-SVG) throws TypeError from the method lookup; no guard exists.

<a id="u-e08c53790eff"></a>
### `fade`

`export function fade(node, { delay = 0, duration = 400, easing = linear } = {})` · [packages/svelte/src/transition/index.js:L62-L70][f1]

Builds a TransitionConfig animating only opacity.

Captures the element's computed opacity once, then returns delay (default 0), duration (default 400), easing (default linear), and a css callback mapping t to `opacity: t * o`, so 'in' goes 0→current and 'out' reverses over the same values.

<a id="u-0bc0dd3f8a1e"></a>
### `fly`

`export function fly( node, { delay = 0, duration = 400, easing = cubic_out, x = 0, y …` · [packages/svelte/src/transition/index.js:L79-L97][f1]

Builds a TransitionConfig animating x/y translation and opacity.

Defaults: delay 0, duration 400, easing cubic_out, x 0, y 0, opacity 0. Reads computed style once: preserves an existing transform ('none' becomes empty) and the target opacity; od = target_opacity * (1 - opacity) is the opacity delta. x and y pass through split_css_unit so string values keep their units (default 'px'). The css callback (t, u) emits transform: <existing> translate((1-t)*x_value, (1-t)*y_value) and opacity: target_opacity - od*u, so 'in' transitions start offset/faded and converge to the element's natural position and opacity; 'out' reverses.

calls: [index-js-local-helpers](r1-public-reactivity-motion.md#u-0a3d9aa213c7)

<a id="u-10ebbce29874"></a>
### `scale`

`export function scale( node, { delay = 0, duration = 400, easing = cubic_out, start =…` · [packages/svelte/src/transition/index.js:L159-L177][f1]

Builds a TransitionConfig animating opacity and scale.

Defaults: delay 0, duration 400, easing cubic_out, start 0, opacity 0. Captures the element's computed opacity and existing transform ('none' becomes empty) once. With sd = 1 - start and od = target_opacity * (1 - opacity), the css callback (t, u) emits transform: <existing> scale(1 - sd*u) and opacity: target_opacity - od*u, so 'in' grows from scale(start) at reduced opacity to the natural state, and 'out' reverses toward scale(start).

<a id="u-56eca0fbad21"></a>
### `slide`

`export function slide(node, { delay = 0, duration = 400, easing = cubic_out, axis = '…` · [packages/svelte/src/transition/index.js:L108-L150][f1]

Builds a TransitionConfig that slides an element by animating its height or width (axis 'y' or 'x', default 'y') along with padding, margin, and border widths on the perpendicular sides, plus overflow:hidden and opacity.

All metrics are read from computed style at creation: primary dimension value, the two secondary paddings/margins/border-widths (chosen by axis, capitalized to matching style keys). In DEV only, if the element's display matches /contents|inline|table/ and the one-shot slide_warning flag is false, it sets the flag, schedules its reset in a microtask via Promise.resolve().then, and warns with w.transition_slide_display; the module-level flag prevents repeat warnings until the microtask runs. The css callback scales every measured quantity by t, keeps opacity at min(t*20,1) (reaching full opacity by 5% progress), sets the primary property and min-primary to animate and collapse, and emits `min-<primary>: 0` to allow shrinking.

**Notes.**

- side_effect: Dev-only warning is debounced by a module-level flag reset asynchronously in a microtask.

uses: [slide](r1-public-reactivity-motion.md#u-56eca0fbad21)

**Uncertainties.**

- The exact warning text/behavior of w.transition_slide_display is external.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/transition/index.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/motion/tweened.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/reactivity/url-search-params.js
