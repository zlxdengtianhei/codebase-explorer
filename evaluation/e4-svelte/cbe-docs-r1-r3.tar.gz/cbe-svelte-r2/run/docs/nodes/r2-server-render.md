# Server renderer

**Capability.** SSR runtime helpers: component rendering to {head, html, body}, hydration-marked element/slot/await output, attribute and style serialization with HTML escaping, store subscription for the template duration, and legacy prop/binding propagation.

Read render for the top-level payload flow and element/slot/head for structure. Attribute helpers (attr_class, attr_style, spread_attributes, style_object_to_string) all funnel through escape_html for safety; store_get/store_set/update_* give stores one-shot SSR semantics.

Parent: [Svelte framework](r2-svelte.md)

## Units (30)

<a id="u-0f499dd45547"></a>
### `escape_html`

`export function escape_html(value, is_attr)` · [packages/svelte/src/escaping.js:L9-L26][f1]

Escapes HTML-special characters in a value for safe interpolation into markup or attribute strings.

The value is coerced with String(), with null and undefined mapping to an empty string. When is_attr is truthy the pattern also matches double quotes; otherwise only & and < are handled. The function resets the regex's lastIndex, then repeatedly scans: for each match it appends the unescaped substring since the last match plus the entity — &amp; for &, &quot; for " (attribute mode only, since " is not in the content pattern), and &lt; for < — and advances the last index; > is never escaped. It returns the accumulated escaped text followed by the remaining tail. Note the regexes are module-level and shared, hence the manual lastIndex reset before each use.

uses: [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/utils.js:build_attribute_value](r4-server-transform.md#u-8ce176223a22)

<a id="u-a9cb571edc90"></a>
### `attr_class`

`export function attr_class(value, hash, directives)` · [packages/svelte/src/internal/server/index.js:L253-L256][f2]

Render a class attribute for a value/css-hash/directives combination.

Delegates to to_class; returns '' when the result is empty, otherwise ` class="<escaped>"` with escape_html in attribute-safe mode.

calls: [to_class](r4-runtime-shared.md#u-bb0adfe2b192), [escape_html](r2-server-render.md#u-0f499dd45547)

<a id="u-1a3f35d1ee98"></a>
### `attr_style`

`export function attr_style(value, directives)` · [packages/svelte/src/internal/server/index.js:L262-L265][f2]

Render a style attribute.

Delegates to to_style (accepting an object or a [before, after] directive pair); returns '' when empty, otherwise ` style="<escaped>"` with attribute-safe escaping.

calls: [to_style](r4-runtime-shared.md#u-50b25ac26373), [escape_html](r2-server-render.md#u-0f499dd45547)

<a id="u-1a337df4b94c"></a>
### `packages/svelte/src/internal/server/index.js:await_block`

`function await_block(payload, promise, pending_fn, then_fn)` · [packages/svelte/src/internal/server/index.js:L443-L454][f2]

Server-side `{#await}` handling: only one branch ever renders because SSR cannot wait for promises.

If the value is a promise, push BLOCK_OPEN, attach `promise.then(null, noop)` to swallow later rejections, and run pending_fn when non-null. Otherwise (not a promise) push BLOCK_OPEN_ELSE and run then_fn(promise) when non-null; if both handlers are null nothing but the marker is emitted.

calls: [is_promise](r6-shared-infra.md#u-f3295568a063)

<a id="u-f2ea71698e42"></a>
### `bind_props`

`export function bind_props(props_parent, props_now)` · [packages/svelte/src/internal/server/index.js:L421-L433][f2]

Legacy-mode binding propagation on the server: for each key in props_now, if the parent's initial value was undefined, the new value is defined, and the parent property has a setter (checked via Object.getOwnPropertyDescriptor), assign the child value back into props_parent.

All other keys are left untouched; keys without setters are skipped.

<a id="u-fbc5df6dd0a5"></a>
### `packages/svelte/src/internal/server/index.js:css_props`

`export function css_props(payload, is_html, props, component, dynamic = false)` · [packages/svelte/src/internal/server/index.js:L142-L162][f2]

Emit a CSS custom-property scoping wrapper around children.

Converts props via style_object_to_string; HTML context gets `<svelte-css-wrapper style="display: contents; styles">`, SVG context gets `<g style="styles">`. When dynamic, pushes an extra `<!---->` marker before running component() so the client can patch the style; closes with the matching `<!----></svelte-css-wrapper>` or `<!----></g>`.

calls: [style_object_to_string](r2-server-render.md#u-5168ebd4b162)

<a id="u-7bb944bfaa2a"></a>
### `packages/svelte/src/internal/server/index.js:derived`

`export function derived(fn)` · [packages/svelte/src/internal/server/index.js:L532-L546][f2]

Server-side legacy `derived` store stand-in built on once().

Returns a function: called with no arguments it returns updated_value if set, otherwise the lazily computed once() value; called with an argument it stores that value as updated_value and returns it. A set value of undefined still reads as 'unset' on subsequent reads because of the `??` fallback.

calls: [packages/svelte/src/internal/server/index.js:once](r2-server-render.md#u-a5b0cc827a44)

<a id="u-3675c4ee24d1"></a>
### `packages/svelte/src/internal/server/index.js:element`

`export function element(payload, tag, attributes_fn = noop, children_fn = noop)` · [packages/svelte/src/internal/server/index.js:L35-L53][f2]

Emit a server-rendered element into payload.out, wrapped in hydration comment markers.

Always pushes `<!---->` first; if tag is truthy it pushes `<tag`, runs attributes_fn (default noop) to emit attributes, closes the tag, and — only for non-void tags — runs children_fn, pushes EMPTY_COMMENT unless the tag is a raw text element (script/style, which must not get the marker), then pushes the closing tag. A falsy tag emits only the two surrounding `<!---->` markers.

calls: [utils.js-element-attribute-predicates](r5-compiler-utilities.md#u-57e79fafa2c2), [utils.js-namespace-and-rune-predicates](r5-compiler-utilities.md#u-c266f2d1e7a9)

<a id="u-01a3113f1c5f"></a>
### `ensure_array_like`

`export function ensure_array_like(array_like_or_iterator)` · [packages/svelte/src/internal/server/index.js:L459-L466][f2]

Normalize an each-block source into something indexable.

Falsy input yields []. Values with a length property pass through unchanged; other iterables are materialized with Array.from.

<a id="u-74e3fe2fb372"></a>
### `packages/svelte/src/internal/server/index.js:head`

`export function head(payload, fn)` · [packages/svelte/src/internal/server/index.js:L127-L132][f2]

Run fn against the payload's head object, wrapping its output with hydration open/close markers.

Writes BLOCK_OPEN, invokes fn(head_payload) which appends into head_payload.out, then BLOCK_CLOSE.

<a id="u-7e5028a0fda0"></a>
### `packages/svelte/src/internal/server/index.js:inspect`

`export function inspect(args, inspect = console.log)` · [packages/svelte/src/internal/server/index.js:L473-L475][f2]

{@debug} on the server: call the inspector (default console.log) once with 'init' followed by the argument values; returns nothing.

<a id="u-2c8b13b9bc4e"></a>
### `maybe_selected`

`export function maybe_selected(payload, value)` · [packages/svelte/src/internal/server/index.js:L553-L555][f2]

Return ' selected' when value matches payload.select_value, else '' — used when server-rendering <option> selection state.

<a id="u-a5b0cc827a44"></a>
### `packages/svelte/src/internal/server/index.js:once`

`export function once(get_value)` · [packages/svelte/src/internal/server/index.js:L481-L489][f2]

Lazy one-shot evaluation: returns a getter that on first call computes get_value() and caches it; the sentinel UNINITIALIZED distinguishes 'not yet run'.

Subsequent calls return the cached value. If the computed value happens to equal the sentinel, it would be recomputed each call — an inherent sentinel-collision edge.

<a id="u-2eb01f29fdab"></a>
### `packages/svelte/src/internal/server/index.js:props_id`

`export function props_id(payload)` · [packages/svelte/src/internal/server/index.js:L496-L500][f2]

Generate the component's unique ID from payload.uid(), emit it as a `<!--#uid-->` marker into payload.out, and return the uid string.

uses: [props_id_generator](r1-server-runtime.md#u-059a47caefaa)

<a id="u-ead9aba750b3"></a>
### `render`

`export function render(component, options = {})` · [packages/svelte/src/internal/server/index.js:L69-L120][f2]

Server-render a component to {head, html, body}.

Creates a Payload (with optional idPrefix), swaps the module-level on_destroy array for a fresh one, wraps output in hydration BLOCK_OPEN/BLOCK_CLOSE markers, and in DEV protects the element-validation stack with reset_elements(). If options.context is given, pushes a component scope and installs the map as the current component's context, popping afterwards. Calls the component as `component(payload, props ?? {}, {}, {})` (four positional arguments). Afterwards runs and clears collected on_destroy callbacks, restores the previous on_destroy array, assembles head from payload.head.out plus title plus `<style id=hash>` blocks for each CSS entry, joins payload.out for the body, and returns {head, html: body, body}. The finally clause always calls abort() to reset the abort controller, so errors during rendering still clean up but propagate to the caller.

calls: [packages/svelte/src/internal/server/context.js:push](r6-runtime-server.md#u-38e06b351976), [packages/svelte/src/internal/server/context.js:pop](r6-runtime-server.md#u-b3ad8cba6058), [abort](r6-runtime-server.md#u-9654b4650543), [reset_elements](r4-server-runtime.md#u-cc2fd0cc577f); uses: [Payload](r1-server-runtime.md#u-88f15d8dfda3)

**Uncertainties.**

- The component call passes four arguments; only payload and props semantics are evident, the two empty-object argument slots' expected contents are not defined in this file.

<a id="u-fa79149bdee0"></a>
### `packages/svelte/src/internal/server/index.js:rest_props`

`export function rest_props(props, rest)` · [packages/svelte/src/internal/server/index.js:L380-L390][f2]

Build a new object containing every own-enumerable key of props except those listed in rest.

Simple copy; values are not cloned, and the input is not mutated.

<a id="u-4abf93ac9587"></a>
### `sanitize_props`

`export function sanitize_props(props)` · [packages/svelte/src/internal/server/index.js:L396-L399][f2]

Strip `children` and `$$slots` from a props object via destructuring and return the remaining props as a new object.

<a id="u-5e5630e14f22"></a>
### `packages/svelte/src/internal/server/index.js:sanitize_slots`

`export function sanitize_slots(props)` · [packages/svelte/src/internal/server/index.js:L405-L413][f2]

Compute a {slotName: true} map: default is true when props.children is truthy (any value, not only functions), and each key of props.$$slots is set to true.

Returns the new record.

<a id="u-c8b85b1bb23a"></a>
### `packages/svelte/src/internal/server/index.js:slot`

`export function slot(payload, $$props, name, slot_props, fallback_fn)` · [packages/svelte/src/internal/server/index.js:L361-L373][f2]

Render a named slot or snippet with fallback.

Looks up $$props.$$slots[name]; if that value is `true` (snippet-fills-slot interop), it instead uses $$props[name] (or $$props.children for the default slot). If a function is found it is called as slot_fn(payload, slot_props); otherwise the optional fallback_fn runs. Does nothing if no slot and no fallback exist.

<a id="u-809bef1eecf5"></a>
### `spread_attributes`

`export function spread_attributes(attrs, css_hash, classes, styles, flags = 0)` · [packages/svelte/src/internal/server/index.js:L172-L207][f2]

Serialize a spread-attributes object into an HTML attribute string.

First normalizes: merges styles into attrs.style via to_style, clsx-collapses an existing class value, and applies css_hash/classes via to_class. Then iterates keys with three skip rules: function values are omitted, names starting with `$$` are omitted, and names matching INVALID_ATTR_NAME_CHAR_REGEX (whitespace, quotes, slash, equals, noncharacters) are omitted. Flags control behavior: absence of ELEMENT_IS_NAMESPACED enables boolean-attribute compaction via attr(), absence of ELEMENT_PRESERVE_ATTRIBUTE_CASE lowercases each name. Each surviving entry appends attr(name, value, is_html && is_boolean_attribute(name)). Mutates the passed attrs object during normalization.

calls: [attr](r4-runtime-shared.md#u-12a88532ea06), [to_class](r4-runtime-shared.md#u-bb0adfe2b192), [to_style](r4-runtime-shared.md#u-50b25ac26373), [clsx](r4-runtime-shared.md#u-2274c46486ff), [function::is_boolean_attribute::2743][f3]

**Uncertainties.**

- Exact flag-bit semantics are read from the two named constants; other flag bits in `flags` are ignored here.

<a id="u-82b1ac47166e"></a>
### `packages/svelte/src/internal/server/index.js:spread_props`

`export function spread_props(props)` · [packages/svelte/src/internal/server/index.js:L213-L230][f2]

Merge an array of prop objects left-to-right into a new object, later entries winning.

For each key it copies the source property descriptor when one exists (preserving getters/setters) via Object.defineProperty, else a plain assignment. Returns the merged object without mutating inputs.

<a id="u-5975ccb1491b"></a>
### `packages/svelte/src/internal/server/index.js:store_get`

`export function store_get(store_values, store_name, store)` · [packages/svelte/src/internal/server/index.js:L274-L293][f2]

Subscribe to a store for the duration of an SSR template and return its current value.

In DEV, validates the store (name minus the leading `$`). If store_values already holds this exact store under store_name, the cached value is returned without resubscribing — deliberately ignoring eager updates from the instance script. Otherwise it unsubscribes any previously tracked subscription (store switch), records [store, null, undefined], subscribes via subscribe_to_store with a callback that writes each emitted value into slot 2, stores the unsubscribe function in slot 1, and returns the current value.

calls: [subscribe_to_store](r6-stores.md#u-863f9153e183), [validate_store](r1-shared-internals.md#u-f09c2e0aa53c)

<a id="u-7d1dd4a2a3e6"></a>
### `packages/svelte/src/internal/server/index.js:store_mutate`

`export function store_mutate(store_values, store_name, store, expression)` · [packages/svelte/src/internal/server/index.js:L315-L318][f2]

Apply a store mutation expression: reads the current value with store_get, writes it back through store_set after the expression ran — note the expression is evaluated as an argument before store_set, so `store.x += 1` style expressions see the pre-update value — then returns the expression's value.

calls: [packages/svelte/src/internal/server/index.js:store_get](r2-server-render.md#u-5975ccb1491b), [packages/svelte/src/internal/server/index.js:store_set](r2-server-render.md#u-809be478aa47)

<a id="u-809be478aa47"></a>
### `packages/svelte/src/internal/server/index.js:store_set`

`export function store_set(store, value)` · [packages/svelte/src/internal/server/index.js:L302-L305][f2]

Set a store's value and return that value unchanged (store.set(value); return value).

<a id="u-1d4fa3ac5094"></a>
### `packages/svelte/src/internal/server/index.js:stringify`

`export function stringify(value)` · [packages/svelte/src/internal/server/index.js:L236-L238][f2]

Coerce a template expression value to text: strings pass through unchanged, null/undefined become '', anything else uses String concatenation (value + '').

<a id="u-5168ebd4b162"></a>
### `style_object_to_string`

`function style_object_to_string(style_object)` · [packages/svelte/src/internal/server/index.js:L241-L246][f2]

Convert a style object into a CSS declaration string: keys with null/undefined or '' values are filtered out; each remaining entry becomes `key: value;` with the value HTML-escaped (in attribute-safe mode via escape_html), entries joined by single spaces.

calls: [escape_html](r2-server-render.md#u-0f499dd45547)

<a id="u-60498de8c911"></a>
### `unsubscribe_stores`

`export function unsubscribe_stores(store_values)` · [packages/svelte/src/internal/server/index.js:L347-L351][f2]

Tear down all store subscriptions recorded in a store_values record by invoking each entry's stored unsubscribe function (slot 1).

Assumes every entry has a callable unsubscribe.

<a id="u-4157e614850a"></a>
### `packages/svelte/src/internal/server/index.js:update_store`

`export function update_store(store_values, store_name, store, d = 1)` · [packages/svelte/src/internal/server/index.js:L327-L331][f2]

Post-increment/decrement helper for numeric stores.

Reads the current value via store_get (d defaults to 1), sets store to value + d, and returns the pre-update value.

calls: [packages/svelte/src/internal/server/index.js:store_get](r2-server-render.md#u-5975ccb1491b), [packages/svelte/src/internal/server/index.js:store_set](r2-server-render.md#u-809be478aa47)

<a id="u-7a134f57bf18"></a>
### `update_store_pre`

`export function update_store_pre(store_values, store_name, store, d = 1)` · [packages/svelte/src/internal/server/index.js:L340-L344][f2]

Pre-increment/decrement helper for numeric stores.

Computes store_get(...) + d (d defaults to 1), sets the store to that new value, and returns the new value.

calls: [packages/svelte/src/internal/server/index.js:store_get](r2-server-render.md#u-5975ccb1491b)

<a id="u-8a42e56302a7"></a>
### `valueless_option`

`export function valueless_option(payload, children)` · [packages/svelte/src/internal/server/index.js:L562-L576][f2]

Handle `<option>` without a value attribute by inspecting rendered output.

Records the current payload.out length, runs children(), and joins the emitted slices into body. After stripping `<!---->` markers, if that text equals payload.select_value, it retroactively edits the previously pushed fragment: rewrites the last string before the children (removing its final character, turning `>` into ` selected>`) and collapses the children's entries into one body entry at the children's start index. If the text differs, payload.out stays as children() left it.

**Uncertainties.**

- Relies on children() pushing exactly one closing fragment ending in '>' right before the children entries; unusual child output shapes could misplace the attribute.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/escaping.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/server/index.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/utils.js
