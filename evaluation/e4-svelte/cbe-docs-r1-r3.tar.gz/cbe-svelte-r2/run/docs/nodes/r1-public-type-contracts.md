# Public Type Contracts

**Capability.** Type-only public contracts: the store interface (Readable/Writable/Subscriber/Unsubscriber/StartStopNotifier), animation config types (AnimationConfig, FlipParams), and the Attachment type with optional cleanup.

No runtime code; these documents are the API surface other packages and user code compile against.

Parent: [Public API Surface](r1-public-surface.md)

## Units (3)

<a id="u-004d2d4d10be"></a>
### `attachmentspublicdts-attachment`

`export interface Attachment<T extends EventTarget = Element>` · [packages/svelte/src/attachments/public.d.ts:L8-L10][f1]

Declares the Attachment type: a function called when an element is mounted, generic over an EventTarget subtype defaulting to Element, optionally returning a cleanup function run on removal.

Docstring ties it to {@attach} tags and createAttachmentKey. The file ends with a wildcard re-export of './index.js'. Type-only; no runtime behavior.

**Uncertainties.**

- Contents of './index.js' re-export are not in this batch.

<a id="u-3d6785682a34"></a>
### `public.d.ts-store-interfaces`

`export type Subscriber<T> = (value: T) => void;` · [packages/svelte/src/store/public.d.ts:L2-L2][f2]

Public store type contracts.

`Readable<T>` requires `subscribe(run, invalidate?)` callable with `this: void`, returning an `Unsubscriber`. `Writable<T>` extends Readable with `set(value)` and `update(updater)`, both `this: void`, informing subscribers. Supporting aliases: `Subscriber<T>`, `Unsubscriber`, `Updater<T>`, and `StartStopNotifier<T>` whose returned optional cleanup runs when the last subscriber unsubscribes. The module re-exports everything from `./index-client.js`. Type-only; no runtime behavior beyond the re-export.

<a id="u-09b7fb924225"></a>
### `publicdts-animation-types`

`export interface AnimationConfig` · [packages/svelte/src/animate/public.d.ts:L2-L8][f3]

Type declarations for Svelte animations: AnimationConfig (optional delay, duration, easing(t), css(t,u), tick(t,u)) and FlipParams (optional delay, easing(t), and duration as a number or a function of element count), plus a wildcard re-export of './index.js'.

No runtime behavior; the todo comment notes AnimationConfig mirrors Transition and may be shared.

**Uncertainties.**

- Contents of './index.js' re-export are not in this batch.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/attachments/public.d.ts
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/store/public.d.ts
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/animate/public.d.ts
