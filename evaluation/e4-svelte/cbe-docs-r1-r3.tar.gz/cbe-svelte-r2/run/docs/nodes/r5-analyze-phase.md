# Analyze-Phase Visitors

**Capability.** Static analysis of the parsed component tree: per-node-type visitors validate placement and attributes, mark dynamic subtrees, detect delegatable events, and record metadata; shared attribute/slot validation rules are reused by multiple visitors.

Use this subtree when debugging compile-time diagnostics or pre-transform metadata. Each visitor owns one node kind; shared/attribute.js centralizes slot/attribute validation. Output feeds the transform phases.

**Depends on.**

- [Compiler Utilities and AST Helpers](r5-compiler-utilities.md) · graph-confirmed · 16 edge(s)

**Depended on by.**

- [Client Transform](r5-client-transform.md) · model-inferred · 0 edge(s)
- [Svelte 4 to 5 Migration](r5-svelte-migration.md) · model-inferred · 0 edge(s)

Parent: [Compiler Public API and Pipeline](r5-compiler-pipeline.md)

## Units (18)

<a id="u-72f0e6cf5bcc"></a>
### `RegularElement.js-regular-element`

`export function RegularElement(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/RegularElement.js:L20-L89][f1]

Analyzes a regular HTML element: validates name/a11y, records element metadata (path, spread, svg/mathml), performs textarea/option rewrites, SSR parent/ancestor validity checks, and self-closing warnings.

**Notes.**

- side_effect: Pushes the node into analysis.elements and stores a copy of context.path in node.metadata.path.
- condition: textarea children become a value attribute unless a value attribute already exists (error); a leading newline is stripped from the first text because browsers ignore it via innerHTML but not via the value property. A single ExpressionTag child of <option> without a value attribute gains a synthetic value attribute to keep value types consistent. An unused lowercase-import binding warns component_name_lowercase.
- condition: metadata.has_spread is true if any SpreadAttribute exists; all attributes on custom elements mark the subtree dynamic.
- failure: With context.state.parent_element set, walking up the path: blocks (if/each/await/key) switch errors to warnings (separate template per block); crossing the named parent element checks is_tag_valid_with_parent, then further RegularElement ancestors check is_tag_valid_with_ancestor, stopping at component/snippet boundaries; violations raise node_invalid_placement or the warning variant.
- condition: A self-closing '/' on a non-void, non-svg, non-mathml element (namespace prefix stripped) warns element_invalid_self_closing_tag. After traversal, an <a> with no parent element checks its children for svg metadata (excluding 'svg' itself) and may set metadata.svg.

calls: [index.js-check-element](r3-a11y-checks.md#u-7ec766147486), [validate_element](r1-compiler-analyze-visitors.md#u-7d4fa5b13c15)

**Uncertainties.**

- The is_svg_element closure returns the nearest RegularElement ancestor's metadata.svg for <a>/<title>, relying on that metadata being computed earlier in the traversal order.

<a id="u-cda1a6710afe"></a>
### `AttachTag`

`export function AttachTag(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/AttachTag.js:L10-L13][f2]

Marks the enclosing subtree dynamic for an `{@attach ...}` tag, then continues the walk with state.expression set to the tag's analyzed metadata expression so inner expressions attribute call/state info to it.

<a id="u-a8d2e390ed17"></a>
### `Attribute`

`export function Attribute(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/Attribute.js:L16-L79][f3]

Analyzes a component attribute during the analyze phase, marking the subtree dynamic in cases where static optimization is impossible and detecting delegatable event handlers.

**Notes.**

- condition: Dynamic marking occurs for: <option value>, any event attribute, any attribute whose name cannot be set statically, and non-trivial class expressions (not Literal/TemplateLiteral/BinaryExpression), the latter also setting node.metadata.needs_clsx.
- side_effect: For event attributes on RegularElement/SvelteElement parents it sets analysis.uses_event_attributes, and on a non-null delegated event it flags the handler function metadata.hoisted and stores the DelegatedEvent on node.metadata.delegated.

calls: [mark_subtree_dynamic](r6-compiler-analyze.md#u-3e6e9a44c2b4), [get_delegated_event](r5-analyze-phase.md#u-462828f3596d)

**Uncertainties.**

- The for-loop over get_attribute_chunks skips FunctionExpression/ArrowFunctionExpression chunks but performs no other work in the visible body, so its purpose here is unclear from this excerpt alone.

<a id="u-95a93395ab75"></a>
### `get_attribute_event_name`

`function get_attribute_event_name(event_name)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/Attribute.js:L238-L244][f3]

Strips the event-attribute prefix and a trailing capture suffix from an attribute name to yield the underlying event name.

**Notes.**

- condition: Always removes the first two characters (e.g. 'on'); if the remainder is a capture event, an additional 7 characters ('capture') are removed.

calls: [utils.js-element-attribute-predicates](r5-compiler-utilities.md#u-57e79fafa2c2)

<a id="u-462828f3596d"></a>
### `get_delegated_event`

`function get_delegated_event(event_name, handler, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/Attribute.js:L91-L233][f3]

Decides whether an event handler can be delegated/hoisted, returning a DelegatedEvent with hoisted info or null; conservatively returns the shared unhoisted object on many bail-out conditions.

**Notes.**

- condition: Bails out (null) when there is no handler or the event name is not delegated; bails out (unhoisted) when the parent element is not a RegularElement, the element has a spread, the identifier handler is referenced in module scope, the binding is exported, the target function is missing or has more than one parameter, and each reference scan rejects arguments/$host, store subscriptions, non-hoistable snippets, shadowed bindings, repeated store subs, each-block indexes, rest params, each bindings in non-runes mode, or mutated normal bindings.
- contract: Arrow/FunctionExpression handlers are used directly as target_function; an Identifier resolves to the binding's initial function only if the binding is_function().
- failure: Returns { hoisted: true, function: target_function } only when every reference in the target function's scope passes all checks.

calls: [get_attribute_event_name](r5-analyze-phase.md#u-95a93395ab75); uses: [Attribute](r5-analyze-phase.md#u-a8d2e390ed17)

**Uncertainties.**

- Whether parent.type of a reference path being 'FunctionDeclaration'/'VariableDeclarator' covers all benign reference shapes is inferred from the code's else-if; other shapes bail out by design.

<a id="u-3462d134e7cb"></a>
### `packages/svelte/src/compiler/phases/2-analyze/visitors/Component.js:Component`

`export function Component(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/Component.js:L9-L20][f4]

Records whether a component usage is dynamic, then delegates to shared component analysis.

The binding is looked up by the component name, or its base name before the first dot for dotted names. metadata.dynamic is true only when the component is in runes mode, the binding exists, and either the binding kind is not 'normal' or the name is dotted — in non-runes mode `svelte:component` was required to switch components, so a plain component with a normal binding is static.

calls: [visit_component](r4-analysis-visitors.md#u-3bbf2fbef9a0)

**Uncertainties.**

- Behavior when the binding is null in runes mode: metadata.dynamic is false, no error here.

<a id="u-64d8ee790c77"></a>
### `packages/svelte/src/compiler/phases/2-analyze/visitors/ExportDefaultDeclaration.js:ExportDefaultDeclaration`

`export function ExportDefaultDeclaration(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/ExportDefaultDeclaration.js:L10-L20][f5]

Validates default exports in Svelte modules.

Outside a .svelte.js module context (ast_type falsy): if the exported declaration is an Identifier, validate_export checks it; non-identifier declarations pass through. Inside a .svelte.js module context, e.module_illegal_default_export throws. context.next() runs only in the non-error path.

calls: [validate_export](r1-compiler-analyze-shared-utils.md#u-1535dc101000); raises: [ExportDefaultDeclaration.js module code (L1–L9)][f5]

<a id="u-04014907462f"></a>
### `ExpressionStatement`

`export function ExpressionStatement(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/ExpressionStatement.js:L9-L38][f6]

Analyzes expression statements, warning on legacy component instantiation.

When the statement is `new X({ target: ... })` with a single ObjectExpression argument containing a `target` property, it looks up X's binding; if it is a normal import, the import source ends in '.svelte', and the import specifier is a default import matching the binding, it warns legacy_component_creation. Always continues traversal.

**Notes.**

- condition: The comment notes a class imported from a .svelte.js module would not be caught — deliberately out of scope.

<a id="u-229553bec4c3"></a>
### `Fragment`

`export function Fragment(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/Fragment.js:L8-L10][f7]

Continues the walk with state.fragment set to this fragment node, so descendants know their owning fragment.

<a id="u-eab780869b30"></a>
### `FunctionDeclaration`

`export function FunctionDeclaration(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/FunctionDeclaration.js:L10-L16][f8]

In runes mode with a named function, validates the function's identifier binding via validate_identifier_name before delegating to visit_function for scope and reactivity analysis; non-runes mode or anonymous functions skip validation.

calls: [visit_function](r6-compiler-analyze.md#u-98e829315086), [validate_identifier_name](r1-compiler-analyze-shared-utils.md#u-e442f835d467)

<a id="u-9898e6a37ff8"></a>
### `packages/svelte/src/compiler/phases/2-analyze/visitors/KeyBlock.js:KeyBlock`

`export function KeyBlock(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/KeyBlock.js:L10-L21][f9]

Analyzes `{#key ...}` blocks: first rejects an empty fragment via validate_block_not_empty, validates the opening tag in runes mode (with '#' prefix), marks the subtree dynamic, then visits the key expression with state.expression pointing at the block's metadata expression and finally visits the fragment.

calls: [validate_block_not_empty](r1-compiler-analyze-shared-utils.md#u-b877c3a87dc5), [validate_opening_tag](r1-compiler-analyze-shared-utils.md#u-8a95b3b7e6dc)

<a id="u-f5aa541ce160"></a>
### `SvelteBoundary`

`export function SvelteBoundary(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/SvelteBoundary.js:L11-L27][f10]

Validates <svelte:boundary> attributes: every attribute must be a plain Attribute named 'onerror', 'failed', or 'pending' (else svelte_boundary_invalid_attribute), and its value must be a single ExpressionTag — a shorthand (true) value or any other shape raises svelte_boundary_invalid_attribute_value.

Continues traversal afterwards. The module-level `valid` list is a private constant of this unit.

<a id="u-bff097b6510d"></a>
### `packages/svelte/src/compiler/phases/2-analyze/visitors/SvelteFragment.js:SvelteFragment`

`export function SvelteFragment(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/SvelteFragment.js:L10-L27][f11]

Analyzes <svelte:fragment>: it must sit directly inside a Component or SvelteComponent (grandparent in path), else svelte_fragment_invalid_placement.

Attributes may only be plain Attributes or LetDirectives; a `slot` attribute is validated by validate_slot_attribute, anything else raises svelte_fragment_invalid_attribute. Continues traversal with parent_element cleared.

calls: [validate_slot_attribute](r5-analyze-phase.md#u-be5b4cd34d6a)

<a id="u-2b8b56c3f427"></a>
### `TemplateElement`

`export function TemplateElement(node)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/TemplateElement.js:L8-L12][f12]

Warns when a template literal's cooked string value contains bidirectional control characters; a null cooked value is treated as empty and passes.

<a id="u-bba0e211168d"></a>
### `Text`

`export function Text(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/Text.js:L13-L52][f13]

Analyzes template text nodes.

Non-whitespace text directly inside a Fragment under a known parent_element is content-model checked ('#text' vs parent) and errors node_invalid_placement on a message. For each bidirectional control character in the data it warns bidirectional_control_characters at absolute source position, unless an earlier sibling Comment in the same Fragment carries a svelte-ignore for that warning (checked via extract_svelte_ignore per comment, scanning only siblings before this node). The shared bidirectional regex's lastIndex is reset before use.

calls: [is_tag_valid_with_parent](r2-compiler-infrastructure.md#u-a93dfa56dc6d), [extract_svelte_ignore](r6-compiler-infra.md#u-4a9ee4fb9b67)

**Uncertainties.**

- The +4 offset into child.start assumes a '<!--' prefix on comments; its correctness depends on comment node positions.
- No context.next() call: whether Text nodes have children to visit is implicit.

<a id="u-001c69caf1f6"></a>
### `validate_attribute`

`export function validate_attribute(attribute, parent)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/shared/attribute.js:L27-L49][f14]

Validates how a single attribute's value is written on components, svelte components, self references, and custom elements.

When the value is exactly one ExpressionTag and the parent is Component, SvelteComponent, SvelteSelf, or a RegularElement that is a custom element node, it warns attribute_quoted (suggesting the braces be quoted). It returns early if the value is shorthand-true, not an array, or has a single chunk. Otherwise it treats a multi-chunk value as a sequence: if the last chunk's end does not equal the attribute's end, the value was unquoted and it throws attribute_unquoted_sequence.

calls: [is_custom_element_node](r3-scope-node-model.md#u-ea1f0b51e1e8)

**Uncertainties.**

- The is_quoted heuristic (last chunk end vs attribute end) is inferred from the comparison; whether editors can produce other shapes matching it is not visible here.

<a id="u-c4e14f91c1c8"></a>
### `validate_attribute_name`

`export function validate_attribute_name(attribute)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/shared/attribute.js:L12-L21][f14]

Warns when an attribute name contains a colon outside the reserved XML namespaces.

If the name includes ':' and does not start with 'xmlns:', 'xlink:', or 'xml:', it emits warning attribute_illegal_colon; otherwise nothing happens and no error is thrown.

uses: [packages/svelte/src/compiler/utils/ast.js][f15]

<a id="u-be5b4cd34d6a"></a>
### `validate_slot_attribute`

`export function validate_slot_attribute(context, attribute, is_component = false)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/shared/attribute.js:L56-L125][f14]

Enforces placement and uniqueness rules for slot="..." attributes during analysis.

If the immediate grandparent (path.at(-2)) is a SnippetBlock, the attribute must be a text attribute or slot_attribute_invalid is thrown, then it returns. Otherwise it walks the context path from the innermost node outward, remembering the first (nearest) ancestor that is a Component, SvelteComponent, SvelteSelf, SvelteElement, or a RegularElement custom element as the owner. With a component-like owner that is not the direct parent, it throws slot_attribute_invalid_placement unless is_component is true. With a component-like owner equal to the parent, the attribute must be a text attribute; the slot name is added to context.state.component_slots, throwing slot_attribute_duplicate if already present, and for the 'default' name every child of the owner fragment must be whitespace text or carry its own slot attribute, else slot_default_duplicate is thrown. If no owner exists and is_component is false, slot_attribute_invalid_placement is thrown. Note the walk never breaks, so the last matching ancestor in the path wins, not the nearest.

**Notes.**

- side_effect: Mutates context.state.component_slots by adding the validated slot name.
- condition: The while loop has no break, so 'owner' ends up being the outermost matching ancestor in the path, which affects which duplicate/placement checks apply.

calls: [is_custom_element_node](r3-scope-node-model.md#u-ea1f0b51e1e8), [is_text_attribute](r5-compiler-utilities.md#u-ec400088cae5); uses: [packages/svelte/src/compiler/phases/2-analyze/visitors/shared/attribute.js][f14]

**Uncertainties.**

- Because the owner search never breaks, the effective owner for nested component/custom-element chains is the outermost match; whether that is intended placement semantics is not provable from this file alone.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/RegularElement.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/AttachTag.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/Attribute.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/Component.js
[f5]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/ExportDefaultDeclaration.js
[f6]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/ExpressionStatement.js
[f7]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/Fragment.js
[f8]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/FunctionDeclaration.js
[f9]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/KeyBlock.js
[f10]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/SvelteBoundary.js
[f11]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/SvelteFragment.js
[f12]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/TemplateElement.js
[f13]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/Text.js
[f14]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/shared/attribute.js
[f15]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/utils/ast.js
