# Reactivity Benchmarks

**Capability.** Times reactive-signal graph construction and dynamic dependency switching at 1e5-signal scale, kept separate from library code so measurement harnesses never ship with the runtime.

Use this subtree to understand benchmark methodology. Benchmarks share graph-construction helpers and a common timing pattern.

**Depends on.**

- [Client Reactivity Core](r6-client-reactivity.md) · model-inferred · 0 edge(s)
- [Benchmark Harness](r4-benchmark-harness.md) · graph-only · 14 edge(s)

Parent: [Svelte Monorepo](r6-svelte-monorepo.md)

## Units (3)

<a id="u-72a078bef7a2"></a>
### `kairo_unstable-js`

`function setup()` · [benchmarking/benchmarks/reactivity/kairo/kairo_unstable.js:L4-L27][f1]

Times a derived whose dependencies change dynamically: 20 loop iterations each pick between a double and an inverse derived based on the parity of head.

setup() creates state head, derived double=head*2, derived inverse=-head, and current which loops 20 times adding get(head)%2 ? get(double) : get(inverse); a render_effect in $.effect_root reads current and increments a counter. run() flushes head=1 and asserts get(current)===40 (20 even-parity iterations doubling), resets counter, then for i=0..99 flushes head=i with no value assertions, finally asserting counter===100, i.e. the effect re-ran once per update despite the switching branch. kairo_unstable_unowned does 10 JIT-warmup setup/run/destroy cycles, awaits fastest_test(10, 1000 run() calls), destroys and returns {benchmark, time, gc_time} via toFixed(2). kairo_unstable_owned keeps warmup plus the retained setup inside one $.effect_root (destroy_owned), assigns run/destroy to outer variables, times identically, then calls destroy() and destroy_owned().

uses: [assert](r4-benchmark-harness.md#u-823bd0dd0cd8); calls: [fastest_test](r4-benchmark-harness.md#u-0bbe8c671495)

<a id="u-dedf9c09053e"></a>
### `sbench-js-helpers`

`function create_data_signals(n, sources)` · [benchmarking/benchmarks/reactivity/sbench.js:L10-L15][f2]

Signal-graph construction helpers for the sbench suite, built on COUNT=1e5.

create_data_signals(n, sources) fills sources[i] with $.state(i) for i<n and returns the array. The create_computation_* helpers each create deriveds that are never returned or stored: _0 ignores its source; _1 reads one signal; _2 sums two; _4 sums four; _1000 sums ss[offset..offset+999] in a loop. The create_computations_* drivers loop over n (or n/2, n/4, n/8, n/1000 for fan-out variants) wiring sources into the matching creator, e.g. create_computations_2to1 pairs sources[i*2] and sources[i*2+1], and create_computations_1to1000 attaches 1000 single-source deriveds to each of n/1000 sources. bench(fn, count, scount) creates scount fresh data signals and calls fn(count, sources) once; creation itself, not reads, is what each benchmark times.

**Uncertainties.**

- Discarded deriveds may be garbage-collected immediately; whether they participate in a dependency graph depends on svelte internal behavior outside this file.

<a id="u-af6c41678350"></a>
### `sbench-js-tests`

`export async function sbench_create_signals()` · [benchmarking/benchmarks/reactivity/sbench.js:L151-L168][f2]

Ten exported async benchmarks, all sharing one timing pattern around graph construction with COUNT=1e5 signals.

Each does 3 un-timed JIT-warmup bench(...) calls, then awaits fastest_test(10, body) where body repeats the bench call 10 times and returns the resulting timing; finally it returns {benchmark, time, gc_time} with timings formatted via toFixed(2). Except sbench_create_signals — which times bench(create_data_signals, COUNT, COUNT) with 100 repetitions and no effect scoping — every timed body runs inside a $.effect_root whose handle destroy() is called after the loop, so all created deriveds are scoped to that root. Variants differ only in driver and counts: 0to1 (scount=0), 1to1 (COUNT), 2to1 (COUNT/2 over COUNT sources), 4to1 (COUNT/4), 1000to1 (COUNT/1000), 1to2 (COUNT, COUNT/2 sources), 1to4 (COUNT/4 sources), 1to8 (COUNT/8), 1to1000 (COUNT/1000). A failed assert inside fastest_test would propagate out of the awaited call; none of these bodies assert.

calls: [sbench-js-helpers](r6-benchmarking.md#u-dedf9c09053e), [fastest_test](r4-benchmark-harness.md#u-0bbe8c671495)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/benchmarking/benchmarks/reactivity/kairo/kairo_unstable.js
[f2]: ../../../../../../eval/svelte-be645b4/benchmarking/benchmarks/reactivity/sbench.js
