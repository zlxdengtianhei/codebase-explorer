# Error Message Templates

**Capability.** Code templates from which the generated server-only and shared error/warning functions are produced, separating message generation from compiler logic.

Use this subtree when changing how compiler diagnostics are generated rather than how they are emitted. Each template defines the shape of generated throw/warn functions for one category.

Parent: [Compiler Pipeline](r4-compiler.md)

## Units (3)

<a id="u-85f7bd54b8a3"></a>
### `packages/svelte/scripts/process-messages/templates/server-errors.js:CODE`

`export function CODE(PARAMETER)` · [packages/svelte/scripts/process-messages/templates/server-errors.js:L8-L12][f1]

Template for generated server error functions that always throw unconditionally (no DEV branch).

It creates an Error containing the code, message text, and svelte.dev/e/CODE link, sets name to 'Svelte error', and throws it. Generation fills in CODE, MESSAGE, and parameters.

<a id="u-c8f0956cc77a"></a>
### `packages/svelte/scripts/process-messages/templates/shared-errors.js:CODE`

`export function CODE(PARAMETER)` · [packages/svelte/scripts/process-messages/templates/shared-errors.js:L8-L16][f2]

Template for generated shared error functions usable on client and server.

Under DEV it throws an Error with name 'Svelte error' containing the code, message, and svelte.dev/e/CODE link; otherwise it throws a bare Error with only the URL, avoiding message bloat in production bundles.

<a id="u-8b569597eb19"></a>
### `packages/svelte/scripts/process-messages/templates/shared-warnings.js:CODE`

`export function CODE(PARAMETER)` · [packages/svelte/scripts/process-messages/templates/shared-warnings.js:L10-L20][f3]

Template for generated shared warning functions.

Under DEV it console.warns a styled multi-line message (bold code line, normal message, svelte.dev/e/CODE link) using the module-level bold/normal font-weight strings; otherwise it warns with only the URL.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/scripts/process-messages/templates/server-errors.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/scripts/process-messages/templates/shared-errors.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/scripts/process-messages/templates/shared-warnings.js
