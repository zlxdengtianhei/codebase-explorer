# Shared transform utilities

**Capability.** Target-agnostic transform helpers: fragment node cleaning with Svelte-4-compatible const-tag ordering, namespace inference for element subtrees, hoisted-function detection, and $inspect rune lowering.

Consult clean_nodes and the namespace units when a visitor must decide which nodes to render and in which namespace. These utilities are shared by the client and server RegularElement visitors; is_hoisted_function and transform_inspect_rune serve the client transform.

**Depends on.**

- [Client signal builders](r2-client-signal-builders.md) · model-inferred · 0 edge(s)

**Depended on by.**

- [Client transform visitors](r2-client-visitors.md) · graph-confirmed · 2 edge(s)
- [Server element serialization](r2-server-element-transform.md) · graph-confirmed · 2 edge(s) · The SSR element visitor reuses the shared fragment-cleaning and namespace-inference helpers also used by the client element visitor.

Parent: [Client code generation](r2-client-transform.md)

## Units (7)

<a id="u-2ed26069223c"></a>
### `clean_nodes`

`export function clean_nodes( parent, nodes, path, namespace = 'html', state, // TODO …` · [packages/svelte/src/compiler/phases/3-transform/utils.js:L145-L324][f1]

Splits a fragment's nodes into hoisted items and whitespace-trimmed regular nodes.

In legacy (non-runes) mode it first reorders ConstTags via sort_const_tags; that step mutates nothing else but changes the node order it processes. Comments are dropped unless preserve_comments; ConstTag, DebugTag, SvelteBody/SvelteWindow/SvelteDocument/SvelteHead, TitleElement, and SnippetBlock nodes are hoisted, everything else stays regular. When preserve_whitespace is false: whitespace-only leading and trailing text nodes are removed (mutating first/last text nodes' raw and data to strip leading/trailing whitespace); a text node's leading whitespace collapses to a single space unless the previous node is a text node ending in whitespace (then removed), and trailing whitespace collapses to a space unless followed by an ExpressionTag; a surviving text node is dropped when it is exactly ' ' and can_remove_entirely holds — true inside svg (outside any 'text' element on the node or path) or inside select/tr/table/tbody/thead/tfoot/colgroup/datalist regular elements. For a 'pre' parent whose first text is exactly '\n' or '\r\n', that node is discarded since the browser inserts it. A lone script element gets an empty Comment appended so run_scripts can call replaceWith on it. Results include hoisted, trimmed, is_standalone (single non-dynamic RenderTag, or non-dynamic Component without --prefixed attributes when hmr is off), and is_text_first (a text/expression first child under Fragment/SnippetBlock/EachBlock/SvelteComponent/SvelteBoundary/Component/SvelteSelf, needing an anchor comment). Note first is read before the pre handling via var hoisting so the standalone/text-first checks see the post-shift first node.

**Notes.**

- side_effect: Mutates Text nodes' raw/data in place and shifts/pops the shared regular array, affecting the caller's nodes list.
- condition: ConstTag sorting only occurs when state.analysis.runes is false; runes mode keeps source order.

calls: [utils.js-sort-const-tags](r2-transform-shared.md#u-ecb5f24829a9)

<a id="u-fca641f4927b"></a>
### `determine_namespace_for_children`

`export function determine_namespace_for_children(node, namespace)` · [packages/svelte/src/compiler/phases/3-transform/utils.js:L442-L452][f1]

Returns the namespace for a RegularElement/SvelteElement's children based only on that node: foreignObject forces 'html'; metadata.svg yields 'svg'; metadata.mathml yields 'mathml'; otherwise 'html'.

Unlike infer_namespace it never inspects children — it trusts the element's already-computed metadata.

<a id="u-b0bc5038f26b"></a>
### `infer_namespace`

`export function infer_namespace(namespace, parent, nodes)` · [packages/svelte/src/compiler/phases/3-transform/utils.js:L332-L378][f1]

Infers the namespace for a node's children.

A foreignObject parent always yields 'html'. RegularElement/SvelteElement parents yield 'svg' or 'mathml' from their metadata, else 'html'. For namespace-resetting parents (Fragment, Root, Component, SvelteComponent, SvelteFragment, SnippetBlock, SlotElement), check_nodes_for_namespace is consulted with 'keep'; a concrete result other than 'keep' or 'maybe_html' wins. Otherwise the children are scanned directly: any non-svg/non-mathml RegularElement forces 'html'; mathml/svg elements force 'html' when mixed with a different namespace or kept consistent otherwise; with no elements the incoming namespace is returned unchanged. This bounds uncertainty for slots whose default content cannot be statically inspected — in such cases the parent namespace propagates.

calls: [utils.js-check-nodes-for-namespace](r2-transform-shared.md#u-8bded2d505aa)

<a id="u-b9dd511b4830"></a>
### `is_hoisted_function`

`export function is_hoisted_function(node)` · [packages/svelte/src/compiler/phases/3-transform/utils.js:L24-L33][f1]

Reports whether an AST node is a function node flagged as hoisted.

It returns false for non-function nodes; for ArrowFunctionExpression, FunctionExpression, or FunctionDeclaration it returns true only when node.metadata?.hoisted is exactly true. Used by transform visitors to decide hoisting of top-level function declarations.

<a id="u-f64464c8fc01"></a>
### `transform_inspect_rune`

`export function transform_inspect_rune(node, context)` · [packages/svelte/src/compiler/phases/3-transform/utils.js:L459-L481][f1]

Lowers $inspect rune call sites into $.inspect calls.

It returns an empty expression immediately when not in dev mode, so $inspect compiles to nothing in production. For a member-expression callee ($inspect(...).with(...)) it visits the inspected arguments from the callee object and the first call argument (the callback), producing $.inspect(args, callback); for a plain call it produces $.inspect(args). Client generation wraps the argument array in a thunk (b.thunk(b.array(...))) while server generation passes the array directly, matching lazy vs eager evaluation expectations.

**Notes.**

- condition: Only node.arguments[0] is visited for the .with form; additional arguments are ignored by this code.

uses: [packages/svelte/src/compiler/phases/3-transform/client/visitors/CallExpression.js:CallExpression](r4-client-transform.md#u-a7da2a1bef1e)

<a id="u-8bded2d505aa"></a>
### `utils.js-check-nodes-for-namespace`

`function check_nodes_for_namespace(nodes, namespace)` · [packages/svelte/src/compiler/phases/3-transform/utils.js:L387-L392][f1]

Heuristic namespace probe: returns the current namespace unless the subtree proves otherwise.

It walks each top-level node (descending only into EachBlock, IfBlock, AwaitBlock, Fragment, KeyBlock, RegularElement, SvelteElement, and Text) with a shared handler for SvelteElement and RegularElement: an element that is neither svg nor mathml sets the namespace to 'html' and stops the walk; otherwise, if the starting namespace is 'keep', it becomes 'svg' or 'mathml' from that element's metadata. Non-whitespace Text sets 'maybe_html', signaling content the heuristic cannot classify. The loop returns early as soon as 'html' is established; after all nodes the accumulated value ('keep', 'maybe_html', 'svg', or 'mathml') is returned. Callers treat 'keep' and 'maybe_html' as 'no conclusion'.

uses: [infer_namespace](r2-transform-shared.md#u-b0bc5038f26b)

**Uncertainties.**

- The walk descends only through the listed node types, so element namespaces hidden inside other wrapper node types are not detected; whether that can misclassify is not provable here

<a id="u-ecb5f24829a9"></a>
### `utils.js-sort-const-tags`

`function sort_const_tags(nodes, state)` · [packages/svelte/src/compiler/phases/3-transform/utils.js:L40-L67][f1]

Topologically sorts ConstTag nodes within a fragment to match Svelte 4 evaluation order.

For each ConstTag the collected bindings are extracted via extract_identifiers and resolved through state.scope.get; a zimmerframe walk over the initializer's declarations gathers referenced bindings, using set_scope on entry and an Identifier visitor that adds bindings only for true references (checked with is_reference against the parent). Non-ConstTag nodes are accumulated separately. If no ConstTags exist the input is returned unchanged. Dependency edges are built between tags when one tag's deps intersect the tag map; check_graph_for_cycles detects circular dependencies, in which case e.const_tag_cycle throws a compiler error naming the cycle as 'a → b → ...'. Otherwise a depth-first add() recursively emits dependencies before each tag, and the result is the sorted ConstTags followed by all other nodes in original order. A tag whose identifiers map to missing scope entries is cast to Binding unconditionally, which assumes scope lookup always succeeds for const-tag declarators.

calls: [extract_identifiers](r5-compiler-utilities.md#u-90eb95affc00), [check_graph_for_cycles](r1-compiler-analyze.md#u-9450956ffc9b)

**Uncertainties.**

- The return value of check_graph_for_cycles is assumed to be a cycle array; elements are used as Map keys into tags without a shape check

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/utils.js
