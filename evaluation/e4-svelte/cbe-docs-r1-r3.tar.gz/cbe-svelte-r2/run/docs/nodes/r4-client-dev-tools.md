# Client Dev Tooling

**Capability.** Development-mode instrumentation of the runtime: HMR component wrapping, ownership/mutation validation, dev-only CSS style tracking for HMR removal, and effect-tree debug printing.

Use this subtree for dev-only behaviors that are absent in production builds. These modules wrap or observe the runtime rather than implement core semantics; ownership validation flags illegal prop mutations, hmr re-creates components on source change.

Parent: [Runtime](r4-runtime.md)

## Units (4)

<a id="u-0e08a21e78a3"></a>
### `hmr`

`export function hmr(original, get_source)` · [packages/svelte/src/internal/client/dev/hmr.js:L15-L20][f1]

Wraps a component for hot module replacement: hmr(original, get_source) returns a wrapper component that renders the current component from a reactive source and re-creates it on update.

wrapper(anchor, props) returns an instance object populated inside an EFFECT_TRANSPARENT block: each run reads the source component via get, destroys the previous branch effect and clears the instance's own keys, then creates a branch that instantiates the component (with new when used with new.target) and copies its property descriptors onto the instance, preserving getters/setters. On replacements after the first run (ran true), set_should_intro(false/true) suppresses transitions around the swap. After setting ran = true, if hydrating, anchor is replaced with hydrate_node. The wrapper carries FILENAME copied from original and an HMR record containing original and a reactive source(original); per the embedded comment, updates replace that source's value so subsequent block runs pick up the new component.

calls: [hmr](r4-client-dev-tools.md#u-0e08a21e78a3), [source](r5-runtime-reactivity.md#u-97497b70f31b)

**Uncertainties.**

- How external HMR code updates wrapper[HMR].source is not shown in this file; the comment is the only evidence for the update protocol.

<a id="u-cec8691d0119"></a>
### `create_ownership_validator`

`export function create_ownership_validator(props)` · [packages/svelte/src/internal/client/dev/ownership.js:L16-L66][f2]

Creates a dev validator that flags illegal prop mutations and interrupted binding chains.

It captures the current component and its parent from component_context. mutation(prop, path, result, line, column) returns result unchanged — silently allowing the mutation — when the root prop is bound or unset (is_bound_or_unset) or there is no parent; otherwise it walks path[:-1], aborting silently if any intermediate value lacks STATE_SYMBOL, and otherwise emits ownership_invalid_mutation naming the root prop, the sanitized `file:line:column` location, the mutated prop, and the parent's FILENAME. binding(key, child_component, value) emits ownership_invalid_binding when the key is not bound/unset, a parent exists, and value() yields an object with STATE_SYMBOL. is_bound_or_unset(props, name) is true when a setter descriptor exists, when props carries STATE_SYMBOL/LEGACY_PROPS and contains the name (entry props like mount(Component, $state props) or createClassComponent), or when the name is absent from props.

calls: [create_ownership_validator](r4-client-dev-tools.md#u-cec8691d0119), [sanitize_location](r5-compiler-utilities.md#u-eb8e19f29107)

<a id="u-c05b95719e0c"></a>
### `css.js-style-registry`

`export function register_style(hash, style)` · [packages/svelte/src/internal/client/dev/css.js:L8-L17][f3]

Tracks component style elements by hash in a module-level Map so they can be removed later (e.g. on HMR).

register_style(hash, style) gets or creates the Set for the hash and adds the style element. cleanup_styles(hash) removes every style element in that hash's set from the DOM via style.remove() and deletes the map entry; it returns immediately when the hash is unknown.

**Notes.**

- side_effect: register_style mutates module state that persists across components; cleanup_styles mutates the live DOM.

<a id="u-a880c7a17285"></a>
### `debug.js-effect-inspection`

`export function root(effect)` · [packages/svelte/src/internal/client/dev/debug.js:L20-L26][f4]

Debug helpers that print an effect tree and its dependencies.

root(effect) walks effect.parent until null and returns the topmost effect. log_effect_tree(effect, depth) opens a console.group labeled by the first matching flag in order root, boundary, block, async, branch, render effect, effect, else '(unknown)', with status clean/maybe dirty/dirty (CLEAN/MAYBE_DIRTY flags), bold when not clean. At depth 0 it prints a callsite derived from new Error().stack line 3 with query strings stripped; deeper levels collapse a 'fn' group printing effect.fn. Non-null deps are logged via log_dep, which prints deriveds recursively as collapsed groups (value plus their own deps) and other values as 'state'. Children are traversed through effect.first/next with depth + 1 before the group closes.

calls: [debug.js-effect-inspection](r4-client-dev-tools.md#u-a880c7a17285)

**Uncertainties.**

- The depth-0 callsite extraction assumes a specific stack format; if stack line 3 is undefined, the printed value is not determined by this source.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dev/hmr.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dev/ownership.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dev/css.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dev/debug.js
