# Public Typing and Reactive/Motion Libraries

**Capability.** Owns the author-facing contract: published type declarations for every svelte subpath, the DOM element typings, and the reactive wrapper and motion libraries (SvelteDate/ReactiveValue, Spring/Tween, flip) whose behavior those declarations document. Types and their runtime implementations are kept adjacent so declaration merging and actual semantics can be checked together.

Use this subtree to check what users compile against and how reactive built-ins, springs, and FLIP behave. Declarations are types only; runtime implementations of reactivity live under runtime-and-shared-infra.

**Children.**

- [Svelte Codebase](r4-svelte-codebase.md) `r4-svelte-codebase` · 0 unit(s)

**Depends on.**

- [Client/Server Runtime and Shared Infrastructure](runtime-and-shared-infra.md) · graph-confirmed · 29 edge(s) · Reactive wrappers and springs build on the internal signal/source machinery and shared runtime helpers.

**Depended on by.**

- [Client/Server Runtime and Shared Infrastructure](runtime-and-shared-infra.md) · graph-confirmed · 43 edge(s)

Parent: [Svelte Monorepo](svelte-monorepo.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
