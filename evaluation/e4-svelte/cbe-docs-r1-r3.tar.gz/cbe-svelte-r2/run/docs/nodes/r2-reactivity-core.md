# Reactivity core

**Capability.** Implements the signal graph: tracked reads, dirty checking, dependency removal, effect/reaction execution, batch settling and module-level reactive-system state.

Read get and update_reaction/update_effect for the core read and re-run paths, is_dirty for staleness, and remove_reaction/remove_reactions for graph teardown. untrack, tick and settled are the user-facing synchronization entry points.

**Depends on.**

- [Component context](r2-component-context.md) · graph-confirmed · 7 edge(s)

**Depended on by.**

- [Async reactivity](r2-async-reactivity.md) · graph-confirmed · 4 edge(s)
- [DOM elements, events and bindings](r2-dom-elements.md) · graph-confirmed · 4 edge(s)
- [Store integration](r2-store-integration.md) · graph-confirmed · 1 edge(s) · store_get reads store-backed state through the reactivity core's get.
- [Reactive Built-ins](r5-reactive-builtins.md) · graph-only · 21 edge(s)
- [Client Runtime Reactivity](r5-runtime-reactivity.md) · graph-only · 20 edge(s)
- [Effect Engine](r3-effects-engine.md) · graph-only · 13 edge(s)
- [Reactive Primitives and Stores](r3-reactive-primitives.md) · graph-only · 13 edge(s)
- [Reactive Batch Scheduling](r4-reactivity-scheduling.md) · graph-only · 12 edge(s)

Parent: [Client runtime](r2-client-runtime.md)

## Units (16)

<a id="u-ac602620d878"></a>
### `runtime.js-module-state-setters`

`export function set_is_updating_effect(value)` · [packages/svelte/src/internal/client/runtime.js:L54-L56][f1]

Module-level reactive-system state and its trivial writers.

Exported mutable bindings track the currently executing reaction (active_reaction) and effect (active_effect), the updating/destroying flags (is_updating_effect, is_destroying_effect), untracked writes seen during a reaction (untracked_writes), version counters (write_version starts at 1; read_version and update_version), skip_reaction, current_sources, and untracking. Each setter assigns its parameter to the matching binding with no validation or branching; increment_write_version pre-increments and returns write_version. push_reaction_value appends a value to current_sources only when a reaction is active and, in async mode, only when that reaction has the DERIVED flag; otherwise the value is dropped. set_signal_status clears only the DIRTY|MAYBE_DIRTY|CLEAN bits of signal.f via a mask and ORs in the new status, leaving other flags intact.

uses: [update_reaction](r2-reactivity-core.md#u-f6b808e008e3)

<a id="u-917581529c00"></a>
### `deep_read`

`export function deep_read(value, visited = new Set())` · [packages/svelte/src/internal/client/runtime.js:L797-L839][f1]

Recursively reads every property of an object so that $state proxies record the reads, using a visited Set to stop cycles.

It skips null values, EventTarget instances (DOM elements), and already-visited objects; for Date instances it calls getTime() to capture internal state. Each property is read recursively inside try/catch, so throwing getters are silently ignored. After the walk, if the prototype is not one of the standard Object/Array/Map/Set/Date prototypes, all getter descriptors on the prototype are invoked (also try/catch-guarded) so custom getters on subclasses are evaluated too.

calls: [deep_read](r2-reactivity-core.md#u-917581529c00); uses: [packages/svelte/src/internal/client/../shared/utils.js][f2]

<a id="u-031649ca68f4"></a>
### `deep_read_state`

`export function deep_read_state(value)` · [packages/svelte/src/internal/client/runtime.js:L773-L788][f1]

Reads the reactive state at the first level of a value so it becomes tracked, using a shallow heuristic for performance.

Non-objects (including null and EventTarget instances) return immediately. If the value itself carries STATE_SYMBOL it is fully traversed with deep_read; otherwise, for non-arrays, each own enumerable property that is an object carrying STATE_SYMBOL is deep-read individually.

calls: [deep_read](r2-reactivity-core.md#u-917581529c00)

<a id="u-331dbfbca387"></a>
### `depends_on_old_values`

`function depends_on_old_values(derived)` · [packages/svelte/src/internal/client/runtime.js:L685-L700][f1]

Recursively checks whether a derived's current value could be stale relative to values recorded in old_values during effect destruction.

Returns true if the derived's value is UNINITIALIZED (unknown, assume the worst), if any direct dependency is in old_values, or if any dependency is itself a derived that recursively depends on old values; otherwise false. A derived with no dependencies returns false.

calls: [depends_on_old_values](r2-reactivity-core.md#u-331dbfbca387)

<a id="u-6edc1c6dcf27"></a>
### `exclude_from_object`

`export function exclude_from_object(obj, keys)` · [packages/svelte/src/internal/client/runtime.js:L754-L765][f1]

Builds a shallow copy of an object containing only its enumerable own-inherited keys that are not in the given keys array, via for-in over the object; excluded and inherited-from-prototype-but-listed keys are skipped.

Returns the new object without mutating the input.

**Uncertainties.**

- for-in also enumerates inherited enumerable properties; whether that is intended is not stated in the source

<a id="u-98099fbbf12a"></a>
### `packages/svelte/src/internal/client/runtime.js:get`

`export function get(signal)` · [packages/svelte/src/internal/client/runtime.js:L528-L682][f1]

Reads a signal's value while registering it as a dependency of the active reaction, the core read path of the reactivity system.

When a reaction is active and not untracking, and the active effect is not destroyed (destroyed effects occur when a derived is read inside an async derived), it registers the dependency: during a reaction's update cycle it stamps signal.rv with read_version and, if the reaction reads the same dependencies in the same order, merely increments skipped_deps (cheap path); a changed order builds new_deps, pushing duplicates unless skip_reaction; outside the update cycle (e.g. after an await) it appends the signal directly to reaction.deps and links the reaction into signal.reactions. When no reaction is active and the signal is an unowned, dependency-less derived, it is marked UNOWNED unless its parent is unowned. DEV behavior: reading a signal not previously read by the current async effect warns about reactivity loss with a stack trace; recent_async_deriveds entries for the signal are deleted; in tracing mode with a matching active reaction, a stack trace is captured per signal (unless signal.trace handles it) and deduplicated in tracing_expressions entries. Value resolution: during effect destruction, values recorded in old_values are returned; a dirty derived with reactions, or one depending on old values, is re-executed via execute_derived and cached in old_values. Otherwise a derived present in batch_deriveds returns its cached value; if is_dirty says it needs it, update_derived recomputes. If the signal carries ERROR_VALUE, its stored value is thrown; otherwise signal.v is returned.

calls: [is_dirty](r2-reactivity-core.md#u-6236bf4a1a35), [update_derived](r6-client-reactivity.md#u-637b94af51bf), [execute_derived](r6-client-reactivity.md#u-193107029d03), [tracing.js-reactive-tracing](r6-client-dev.md#u-fb7046392fad)

**Uncertainties.**

- execute_derived/update_derived internals live in deriveds.js and are not verified here
- old_values is imported from sources.js; when it is populated is outside this file
- w.await_reactivity_loss semantics live in warnings.js

<a id="u-6236bf4a1a35"></a>
### `is_dirty`

`export function is_dirty(reaction)` · [packages/svelte/src/internal/client/runtime.js:L153-L224][f1]

Determines whether a derived or effect needs recomputation.

Returns true immediately if the reaction is flagged DIRTY. When MAYBE_DIRTY and it has dependencies, it may first reconnect the reaction: if the reaction is DISCONNECTED, or is UNOWNED while an effect is active without skip_reaction, and the active effect is not DESTROYED, it pushes the reaction back into each dependency's reactions list — re-adding duplicates only in the disconnected case — then clears DISCONNECTED, and clears UNOWNED when the reaction now has a non-unowned parent. It then walks all dependencies: each dependency is recursively checked with is_dirty, and if dirty it is recomputed via update_derived; if any dependency's write version exceeds the reaction's, it returns true. If unowned but not actively connected, the status is left alone; otherwise it is set to CLEAN. Any other flag state returns false.

calls: [runtime.js-module-state-setters](r2-reactivity-core.md#u-ac602620d878), [is_dirty](r2-reactivity-core.md#u-6236bf4a1a35), [update_derived](r6-client-reactivity.md#u-637b94af51bf)

**Uncertainties.**

- Behavior of update_derived (recomputation and value updates) lives in deriveds.js and is not verified here

<a id="u-b71ac6185599"></a>
### `remove_reaction`

`function remove_reaction(signal, dependency)` · [packages/svelte/src/internal/client/runtime.js:L385-L421][f1]

Detaches one dependency from a signal's reaction graph.

It removes the signal from the dependency's reactions list (swap-with-last and pop); when the list empties it becomes null. If the dependency is a DERIVED whose reactions are now null and it is not present in new_deps (guarding against an apparent-but-not-real disconnection during parent-effect updates), the derived is disconnected: marked MAYBE_DIRTY, flagged DISCONNECTED unless already UNOWNED or DISCONNECTED, its owned derived effects destroyed via destroy_derived_effects, and its own reactions removed recursively.

calls: [remove_reactions](r2-reactivity-core.md#u-b457a655a682), [destroy_derived_effects](r6-client-reactivity.md#u-a30c1fdac161)

<a id="u-b457a655a682"></a>
### `remove_reactions`

`export function remove_reactions(signal, start_index)` · [packages/svelte/src/internal/client/runtime.js:L428-L435][f1]

Iterates a signal's dependencies from start_index to the end and calls remove_reaction for each, detaching the signal from those dependencies.

Returns immediately if the signal has no dependencies.

calls: [remove_reaction](r2-reactivity-core.md#u-b71ac6185599)

<a id="u-5fbc2abe243d"></a>
### `safe_get`

`export function safe_get(signal)` · [packages/svelte/src/internal/client/runtime.js:L708-L710][f1]

Reads a possibly-undefined signal, returning undefined when the argument is undefined and otherwise delegating to get.

Used for var declarations that can be read before their declaration exists.

calls: [packages/svelte/src/internal/client/runtime.js:get](r2-reactivity-core.md#u-98099fbbf12a)

<a id="u-6645f71b9626"></a>
### `schedule_possible_effect_self_invalidation`

`function schedule_possible_effect_self_invalidation(signal, effect, root = true)` · [packages/svelte/src/internal/client/runtime.js:L231-L253][f1]

Propagates invalidation for sources written inside the currently running effect but not yet tracked by it, so the effect re-runs if it later reads them.

It returns early if the signal has no reactions, and — outside async mode — if the signal is listed in current_sources, since those writes are already tracked. It walks the signal's reactions: DERIVED reactions are visited recursively with root=false; when a reaction is the given effect, it marks the effect DIRTY at the recursion root, otherwise upgrades only a CLEAN reaction to MAYBE_DIRTY, then schedules the effect via schedule_effect.

calls: [schedule_possible_effect_self_invalidation](r2-reactivity-core.md#u-6645f71b9626), [schedule_effect](r4-reactivity-scheduling.md#u-ce4f8d895426)

<a id="u-c3960ca76f41"></a>
### `packages/svelte/src/internal/client/runtime.js:settled`

`export function settled()` · [packages/svelte/src/internal/client/runtime.js:L519-L521][f1]

Returns a promise that resolves once all pending state changes, the asynchronous work they trigger, and the resulting DOM updates have completed, by delegating to the current batch's settled() obtained through Batch.ensure().

calls: [Batch](r4-reactivity-scheduling.md#u-43c969fbb82e)

**Uncertainties.**

- Resolution semantics of Batch.settled are defined in batch.js and not verified here

<a id="u-fe83d8ee971b"></a>
### `packages/svelte/src/internal/client/runtime.js:tick`

`export async function tick()` · [packages/svelte/src/internal/client/runtime.js:L501-L511][f1]

Returns a promise that resolves once pending state changes have been applied.

In async mode it resolves on the next requestAnimationFrame. Otherwise it awaits one microtask (Promise.resolve()) and then calls flushSync, guaranteeing pending synchronous state changes are flushed after one tick.

calls: [flushSync](r4-reactivity-scheduling.md#u-f4c4d1829672)

<a id="u-aa0e067da463"></a>
### `untrack`

`export function untrack(fn)` · [packages/svelte/src/internal/client/runtime.js:L728-L736][f1]

Runs fn with dependency tracking suppressed: it sets the untracking flag true (saving the previous value), calls fn, and restores the flag in a finally block even if fn throws.

State read inside fn is therefore not registered as a dependency of the surrounding reaction.

uses: [runtime.js-module-state-setters](r2-reactivity-core.md#u-ac602620d878)

<a id="u-e2ea8c85735e"></a>
### `update_effect`

`export function update_effect(effect)` · [packages/svelte/src/internal/client/runtime.js:L441-L495][f1]

Re-runs an effect, first tearing down its previous children and teardown function.

It returns without doing anything if the effect is DESTROYED; otherwise it marks it CLEAN, saves and sets active_effect and is_updating_effect. In DEV it swaps in the effect's component function and dev stack (block effects keep their own stack; others keep the current one). It destroys children — destroy_block_effect_children for BLOCK_EFFECT, destroy_effect_children otherwise — runs execute_effect_teardown, then delegates the actual run to update_reaction, storing a returned function as effect.teardown (null otherwise) and stamping effect.wv with write_version. In DEV tracing mode, when the effect ran DIRTY, any dependency flagged set_during_effect gets its write version bumped via increment_write_version so it is correctly dirty on the next run, then the flag is cleared. Finally it restores the saved effect/flag and DEV context state.

calls: [update_reaction](r2-reactivity-core.md#u-f6b808e008e3), [destroy_effect_children](r3-effects-engine.md#u-8ac46761ce64), [execute_effect_teardown](r3-effects-engine.md#u-e4bc784214d0), [context.js-dev-state-setters](r2-component-context.md#u-beb31e6973ea), [runtime.js-module-state-setters](r2-reactivity-core.md#u-ac602620d878)

<a id="u-f6b808e008e3"></a>
### `update_reaction`

`export function update_reaction(reaction)` · [packages/svelte/src/internal/client/runtime.js:L256-L377][f1]

Runs a reaction's function while tracking its dependencies, saving and restoring all module-level tracking state (new_deps, skipped_deps, untracked_writes, active_reaction, skip_reaction, current_sources, component context, untracking, update_version) in a finally block.

Before running it resets new_deps/skipped_deps/untracked_writes, sets skip_reaction for UNOWNED reactions when untracking or outside an update, sets active_reaction to null for branch/root effects, bumps update_version via ++read_version, and aborts any stored AbortController outside a reactive context with reason STALE_REACTION. After fn() returns it reconciles dependencies: if new_deps exist it removes reactions past skipped_deps and splices the new dependencies in (appending the reaction to each dependency's reactions list unless skip_reaction, except for deriveds that already have reactions); if no new deps and deps shrank, it truncates. If running in runes mode with untracked writes and a plain, non-dirty reaction, it propagates self-invalidation for each written source. Returning to a different previous reaction increments read_version and merges untracked writes upward. An ERROR_VALUE flag is cleared after a successful run. Errors from fn() are passed to handle_error and its return value becomes the result; state is still restored.

uses: [runtime.js-module-state-setters](r2-reactivity-core.md#u-ac602620d878); calls: [context.js-dev-state-setters](r2-component-context.md#u-beb31e6973ea), [without_reactive_context](r3-element-bindings.md#u-ff3a57d1f4f9), [is_runes](r2-component-context.md#u-71aba13a168a), [remove_reactions](r2-reactivity-core.md#u-b457a655a682), [schedule_possible_effect_self_invalidation](r2-reactivity-core.md#u-6645f71b9626), [handle_error](r3-client-error-handling.md#u-1b3b4fa2c18e)

**Uncertainties.**

- handle_error's return value semantics (rethrow vs. fallback value) are defined in error-handling.js and not verifiable here

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/runtime.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/shared/utils.js
