# Semantic Analysis

**Capability.** Walks the AST to validate directives and special elements, track reactivity metadata (dynamic subtrees, expression purity, function scoping), emitting errors and warnings before code generation.

Use this subtree for compile-time validation and metadata collection. Template visitors share mark_subtree_dynamic, visit_function, and special-element helpers; SvelteBody/SvelteHead validate their special elements (children/attribute rules) before marking their subtrees dynamic.

**Children.**

- [CSS Scoping Analysis](r6-compiler-analyze-css.md) `r6-compiler-analyze-css` · 8 unit(s)

**Depends on.**

- [CSS Scoping Analysis](r6-compiler-analyze-css.md) · containment · → 0 / ← 0 edge(s) (ancestor direct units and descendant subtree; → follows ` r6-compiler-analyze ` → ` r6-compiler-analyze-css `)
- [Compiler Infrastructure](r6-compiler-infra.md) · graph-confirmed · 1 edge(s)
- [Compiler Utilities and AST Helpers](r5-compiler-utilities.md) · graph-only · 11 edge(s)

**Depended on by.**

- [Code Generation](r6-compiler-transform.md) · model-inferred · 0 edge(s)

Parent: [Compiler Pipeline](r6-compiler.md)

## Units (19)

<a id="u-1731905f5fa9"></a>
### `AwaitExpression`

`export function AwaitExpression(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/AwaitExpression.js:L9-L39][f1]

Analyzes await expressions, deciding whether the await may suspend and erroring otherwise.

suspend starts true only in a component instance at function_depth 1. Any expression context sets has_await, and if the path contains a ConstTag also flags fragment.metadata.has_await, and forces suspend true. When suspend, missing experimental.async raises experimental_async and non-runes mode raises legacy_await_invalid; both are independent checks. Always delegates via context.next().

uses: [mark_subtree_dynamic](r6-compiler-analyze.md#u-3e6e9a44c2b4)

**Uncertainties.**

- Whether fragment.metadata.has_await being set has downstream compile effects is outside this file.

<a id="u-95b9d2cc9f5c"></a>
### `BindDirective`

`export function BindDirective(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/BindDirective.js:L20-L254][f2]

Validates a bind: directive against its parent element and binding rules, then either records getter/setter bindings or resolves the bound expression into binding metadata.

**Notes.**

- failure: Element-targeted errors include invalid/invalidated binding names (with fuzzy suggestions and valid-element lists), input type mismatches (checkbox for checked, file for files), dynamic input type misuse, select multiple conflicts, offsetWidth on svg, and contenteditable bindings without a static contenteditable attribute.
- condition: A SequenceExpression value is treated as a getter/setter binding: 'group' is rejected, parentheses outside leading comments trigger bind_invalid_parens (scanning source backwards to '{'), and exactly two expressions are required; the subtree is marked dynamic and the function returns early.
- side_effect: For bind:group it collects enclosing EachBlocks whose declarations feed the expression, reuses or creates a binding group name via scope.root.unique stored in analysis.binding_groups keyed by [keypath, bindings], and sets node.metadata with the group name and parent each blocks.
- condition: A plain Identifier reassignment is only valid for bind:this or bindings of kind state/raw_state/prop/bindable_prop/each/store_sub or that are updated, otherwise bind_invalid_value errors; bind:group with a missing binding throws a plain Error, and a snippet binding errors; each-rest bindings warn.

calls: [fuzzymatch](r3-parse-utilities.md#u-4d517976b3f9), [validate_assignment](r1-compiler-analyze-shared-utils.md#u-83497fe81c11), [mark_subtree_dynamic](r6-compiler-analyze.md#u-3e6e9a44c2b4)

**Uncertainties.**

- The comment '// TODO wut?' indicates the binding.updated allowance for non-runes reassignment semantics is not fully specified in the source.

<a id="u-3976d5e73938"></a>
### `DebugTag`

`export function DebugTag(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/DebugTag.js:L9-L15][f3]

Validates `{@debug ...}` tag placement in runes mode via validate_opening_tag (with '@' prefix), then continues the walk unconditionally in non-runes mode.

calls: [validate_opening_tag](r1-compiler-analyze-shared-utils.md#u-8a95b3b7e6dc)

<a id="u-e5e44148727d"></a>
### `ExportSpecifier`

`export function ExportSpecifier(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/ExportSpecifier.js:L9-L30][f4]

Analyzes `export { x }` specifiers.

In instance scope under runes mode, records the local/exported name pair in analysis.exports and marks the local binding reassigned. Otherwise (non-instance scope), validate_export checks the local name against the scope. No traversal beyond this; the function does not call context.next or visit children.

calls: [validate_export](r1-compiler-analyze-shared-utils.md#u-1535dc101000)

**Uncertainties.**

- Non-runes instance-scope specifiers get no exports entry and no validation — only validate_export in the else branch is skipped in instance scope regardless of runes.

<a id="u-0527ca5efcfc"></a>
### `FunctionExpression`

`export function FunctionExpression(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/FunctionExpression.js:L9-L11][f5]

Delegates function expression analysis entirely to visit_function, which handles scope creation and function-scoped reactivity tracking.

<a id="u-ac6549f7c9f9"></a>
### `packages/svelte/src/compiler/phases/2-analyze/visitors/Identifier.js:Identifier`

`export function Identifier(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/Identifier.js:L16-L192][f6]

Analyzes identifier references: marks subtrees dynamic, validates rune names, records expression dependencies, and emits state-reference and module-reactivity warnings.

**Notes.**

- failure: Non-references return immediately; 'arguments' outside any function errors; in runes mode, rune-like names without a local binding walk MemberExpression properties rejecting computed access, unknown/renamed/removed runes ($effect.active→$effect.tracking, $state.frozen→$state.raw, $state.is removed), and non-call usage.
- side_effect: $$slots always sets analysis.uses_slots; $$props/$$restProps set their flags only in non-runes mode.
- condition: Bound references are added to the current expression's dependencies/references; has_state is set for non-static, non-function props/bindable/rest_prop or reassigned-state-like bindings whose value is not statically known. A read of state/raw_state/derived within the same function depth warns state_referenced_locally (type 'closure' or 'derived' when read inside a $state/$state.raw call argument), skipping assignments/updates. Reads of reassigned module-scope bindings inside reactive statements warn. Under experimental async, a {@const} of a template declaration referenced through an implicit children/failed/pending snippet at the same scope errors.

calls: [mark_subtree_dynamic](r6-compiler-analyze.md#u-3e6e9a44c2b4), [should_proxy](r2-client-signal-builders.md#u-d089d4da67c8)

**Uncertainties.**

- The exact meaning of binding.updated and scope.evaluate(node).is_known depends on code outside this file.

<a id="u-5d5cb13598f7"></a>
### `OnDirective`

`export function OnDirective(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/OnDirective.js:L10-L28][f7]

Handles on:event directives: deprecation warning in runes mode for element events, records the first event directive, marks subtree dynamic, and continues with the directive's expression metadata.

**Notes.**

- condition: The deprecated-event warning is suppressed for component events since they may not be author-controlled; analysis.event_directive_node is set only once (??=) for element parents.

calls: [mark_subtree_dynamic](r6-compiler-analyze.md#u-3e6e9a44c2b4)

<a id="u-25d6f65abe59"></a>
### `SpreadAttribute`

`export function SpreadAttribute(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/SpreadAttribute.js:L10-L13][f8]

Marks the enclosing subtree dynamic for a spread attribute, then continues the walk with state.expression set to the attribute's metadata expression.

<a id="u-835ee6b14ea5"></a>
### `SpreadElement`

`export function SpreadElement(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/SpreadElement.js:L8-L16][f9]

Treats any expression-context spread (e.g. [...x]) as a potential call with state: sets has_call and has_state on the enclosing expression metadata, then continues traversal.

No validation performed.

<a id="u-4e2293e9dea9"></a>
### `packages/svelte/src/compiler/phases/2-analyze/visitors/SvelteBody.js:SvelteBody`

`export function SvelteBody(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/SvelteBody.js:L11-L22][f10]

Validates `<svelte:body>`: disallow_children rejects any element children, then for each attribute a spread or a non-event attribute raises e.svelte_body_illegal_attribute; only event attributes (per is_event_attribute) are allowed.

context.next() runs after all checks.

calls: [disallow_children](r6-compiler-analyze.md#u-43b79d8932ce), [is_event_attribute](r5-compiler-utilities.md#u-1c2da82112be)

<a id="u-7502f1ce8b9a"></a>
### `SvelteHead`

`export function SvelteHead(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/SvelteHead.js:L10-L18][f11]

Validates `<svelte:head>`: every attribute raises e.svelte_head_illegal_attribute (loop does not break, so each attribute errors), then the subtree is marked dynamic and the walk continues.

<a id="u-b2fd544bbb7e"></a>
### `TaggedTemplateExpression`

`export function TaggedTemplateExpression(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/TaggedTemplateExpression.js:L9-L16][f12]

Marks tagged template expressions as impure calls for the enclosing expression: when state.expression is set and the tag is not pure (per is_pure), that expression's has_call and has_state are both set to true.

context.next() always continues.

calls: [is_pure](r1-compiler-analyze-shared-utils.md#u-c8c562a3fb44)

<a id="u-7f3ea7461731"></a>
### `TransitionDirective`

`export function TransitionDirective(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/TransitionDirective.js:L10-L14][f13]

Marks the enclosing subtree dynamic for a transition directive, then continues the walk.

<a id="u-c7e949fd4745"></a>
### `UseDirective`

`export function UseDirective(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/UseDirective.js:L9-L12][f14]

Marks the enclosing subtree dynamic for an action directive (`use:`), then continues the walk.

<a id="u-0304f5d2800a"></a>
### `constants.js module code (L1–L319)`

`module_region` · [packages/svelte/src/compiler/phases/2-analyze/visitors/shared/a11y/constants.js:L1-L319][f15]

Builds the module-level accessibility lookup tables used by element and role checks, combining hardcoded lists with aria-query and axobject-query package data.

**Notes.**

- side_effect: Module load runs filters and loops that populate non_interactive_element_role_schemas, interactive_element_role_schemas, interactive_element_ax_object_schemas, and non_interactive_element_ax_object_schemas.
- contract: non_interactive_roles excludes toolbar, tabpanel, generic, and cell from the widget/window superclass test (treated as interactive) and appends progressbar; interactive_roles is the remaining non-abstract roles except generic.
- contract: AXObject classification: interactive means type 'widget'; non-interactive means type 'windows' or 'structure'; an element schema is pushed into a bucket only when every mapped AXObject falls in that bucket.

uses: [MappedCode.concat](r6-compiler-infra.md#u-1bc94121324a)

**Uncertainties.**

- exact contents of roles_map, aria, AXObjects, elementRoles, and elementAXObjects come from the aria-query and axobject-query packages, which are not supplied

<a id="u-3e6e9a44c2b4"></a>
### `mark_subtree_dynamic`

`export function mark_subtree_dynamic(path)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/shared/fragment.js:L6-L15][f16]

Flags every Fragment on the given path, from innermost to outermost, as dynamic, stopping early at the first Fragment already marked.

It walks the path backwards; for each Fragment node it returns immediately if metadata.dynamic is truthy, otherwise sets it to true. Non-Fragment nodes are skipped. This is the shared mechanism by which visitors signal that a static fragment needs to become reactive.

<a id="u-98e829315086"></a>
### `visit_function`

`export function visit_function(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/shared/function.js:L8-L31][f17]

Shared visitor for arrow functions, function expressions, and function declarations: it initializes function metadata and tracks cross-function references when inside a reactive expression.

It sets node.metadata with hoisted=false, empty hoisted_params, and the current scope. If context.state.expression is set, it iterates the scope's references and, for each binding whose scope's function_depth is below the current scope's, adds that binding to state.expression.references (capturing references to outer, possibly reactive, values). It then continues traversal with function_depth incremented by one and expression reset to null, so nested functions do not re-run the expression-reference capture.

**Uncertainties.**

- What state.expression contains and how its references set is consumed is defined elsewhere; only the membership condition is visible here.

<a id="u-5fc246db911c"></a>
### `is_resolved_snippet`

`export function is_resolved_snippet(binding)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/shared/snippets.js:L8-L17][f18]

Decides whether a binding unambiguously identifies which snippet a component may render, per its docstring: a null binding (no binding found), an import, a prop, rest_prop, bindable_prop, or a binding whose initial is a SnippetBlock all count as resolved; anything else (e.g. a locally reassigned or opaque local variable) does not.

<a id="u-43b79d8932ce"></a>
### `disallow_children`

`export function disallow_children(node)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/shared/special-element.js:L7-L16][f19]

Rejects any content inside svelte:body, svelte:document, svelte:options, or svelte:window.

If the fragment has at least one node it throws svelte_meta_invalid_content with a range spanning from the first node's start to the last node's end and the element's name; an empty fragment passes silently.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/AwaitExpression.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/BindDirective.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/DebugTag.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/ExportSpecifier.js
[f5]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/FunctionExpression.js
[f6]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/Identifier.js
[f7]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/OnDirective.js
[f8]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/SpreadAttribute.js
[f9]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/SpreadElement.js
[f10]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/SvelteBody.js
[f11]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/SvelteHead.js
[f12]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/TaggedTemplateExpression.js
[f13]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/TransitionDirective.js
[f14]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/UseDirective.js
[f15]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/shared/a11y/constants.js
[f16]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/shared/fragment.js
[f17]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/shared/function.js
[f18]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/shared/snippets.js
[f19]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/shared/special-element.js
