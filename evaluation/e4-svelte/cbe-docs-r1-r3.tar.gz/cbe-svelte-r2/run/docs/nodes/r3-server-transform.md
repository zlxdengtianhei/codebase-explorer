# Server Transform

**Capability.** Generates SSR code: serializes element attributes (including class/style/spread handling), strips rune syntax from class fields, and rewrites $derived private-field reads for server rendering.

Use this subtree for server-rendering behavior of attributes and runes-mode classes. build_element_attributes is the central serializer; name casing and boolean-attribute handling here deliberately differ from the client pass.

**Depends on.**

- [Scope and Node Model](r3-scope-node-model.md) · graph-confirmed · 7 edge(s)
- [Compiler Utilities and AST Helpers](r5-compiler-utilities.md) · graph-only · 10 edge(s)

**Depended on by.**

- [Client Transform](r3-client-transform.md) · model-inferred · 0 edge(s)

Parent: [Code Generation Transforms](r3-code-generation-transform.md)

## Units (10)

<a id="u-21f5ba0822c6"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/MemberExpression.js:MemberExpression`

`export function MemberExpression(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/MemberExpression.js:L9-L23][f1]

Rewrites private-field reads of $derived class fields in runes mode.

When the object is `this` and the property is a PrivateIdentifier and `#name` maps to a field of kind $derived/$derived.by in state_fields, it returns `b.call(node)` — i.e. calls the getter — otherwise it continues with context.next().

**Uncertainties.**

- state_fields is accessed with optional chaining, so absence is tolerated; which visitors populate it is outside this file

<a id="u-518018776eef"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/PropertyDefinition.js:PropertyDefinition`

`export function PropertyDefinition(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/PropertyDefinition.js:L10-L37][f2]

Strips rune syntax from class property initializers in runes mode.

For a PropertyDefinition whose value is a CallExpression: `$state`/`$state.raw` become the plain property with the visited first argument, or null value when no argument was passed; `$derived`/`$derived.by` become the property initialized with `$.derived(fn)` where the function is a thunk for `$derived` and raw for `$derived.by`, again null when arguments are empty. Non-rune properties continue through context.next().

**Notes.**

- failure: In the $derived branch, context.visit(node.value.arguments[0]) executes before checking arguments.length === 0, so a zero-argument $derived property would throw at compile time despite the null-value branch.

**Uncertainties.**

- For $derived with zero arguments, node.value.arguments[0] is visited before the length check, which would throw — the length check appears to occur too late; recorded as observed code order

<a id="u-b3ca2606d7a1"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/SpreadAttribute.js:SpreadAttribute`

`export function SpreadAttribute(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/SpreadAttribute.js:L8-L10][f3]

SSR visitor for a spread attribute: returns the transformed attribute expression itself, letting the enclosing element visitor handle spreading.

<a id="u-efff830ecb5a"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/SvelteElement.js:SvelteElement`

`export function SvelteElement(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/SvelteElement.js:L15-L75][f4]

Renders `<svelte:element>` with a dynamic tag.

The tag expression is visited; in dev it is hoisted into a const when not an identifier (so getters/calls run once), and validation calls `$.validate_void_dynamic_element` (only when the fragment has nodes) and `$.validate_dynamic_element_tag` are pushed to init. Attribute building runs in a fresh state whose init/template are folded into an attributes block; dev also wraps output in `$.push_element`/`$.pop_element` with source location. Finally it emits `$.element($$payload, tag, attributesThunk?, childrenThunk?)`, passing thunks only when the respective blocks are non-empty (falsy otherwise) and the visited fragment as children.

calls: [build_element_attributes](r3-server-transform.md#u-50884bbfafdd), [determine_namespace_for_children](r2-transform-shared.md#u-fca641f4927b), [build_template](r4-server-transform.md#u-7d424d7f2d77)

**Uncertainties.**

- Whether `false` thunks (from `length > 0 && b.thunk(...)`) are handled as absent arguments depends on b.call's arity handling, not shown

<a id="u-50884bbfafdd"></a>
### `build_element_attributes`

`export function build_element_attributes(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/element.js:L33-L310][f5]

Serializes a regular or svelte element's attributes into the server template and returns an optional content expression (used when an attribute/binding must become the element's child content).

Attribute handling: value on textarea becomes escaped content (with an extra leading newline restored when the text starts with one, per the HTML textarea restriction); value on select is omitted; event attributes are dropped except that onload/onerror on load/error elements are recorded for capture; defaultValue/defaultChecked are dropped; class gets a $.clsx wrapper when attribute.metadata.needs_clsx; everything else is kept. BindDirectives: value on select, value on file inputs, 'this', and omit_in_ssr bindings are skipped; the visited expression's first element is used when it is a SequenceExpression; contenteditable bindings become content; value on textarea becomes escaped content; a group binding (non-sequence) synthesizes a checked attribute comparing the bound expression to the value attribute (includes-call for checkbox type, === otherwise) and is skipped when no value attribute exists; other bindings become synthesized attributes. SpreadAttribute always sets has_spread and, on load/error elements, records onload/onerror; UseDirective likewise records capture events on those elements; ClassDirective/StyleDirective are collected; LetDirective is ignored (handled by build_inline_component); anything else is visited. With a spread, build_element_spread_attributes emits one $.spread_attributes call, and option elements additionally emit $.maybe_selected from the spread object's value. Without a spread, each attribute emits either a literal ` name="value"` string (boolean attributes render bare when the value is true; empty strings when true-but-not-boolean; class gets the scoped CSS hash appended and empty class is skipped) plus $.maybe_selected for option/value, or dynamic output via $.attr / build_attr_class / build_attr_style after escape_html pre-escaping of inline string literals. Recorded events are emitted as ` event="this.__e=event"` literals.

**Notes.**

- side_effect: Pushes literals and runtime calls into context.state.template and may mutate attribute.value[0].data for textarea values.
- failure: No error paths are present; unsupported attribute kinds fall through to context.visit.

calls: [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/element.js:get_attribute_name](r3-server-transform.md#u-5ee6cbf26623), [build_element_spread_attributes](r3-server-transform.md#u-f66dce05e822), [build_spread_object](r3-server-transform.md#u-3629ffc7b235), [build_attr_class](r3-server-transform.md#u-b758ea3e0e3a), [build_attr_style](r3-server-transform.md#u-9bfb6c1f061d), [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/utils.js:build_attribute_value](r4-server-transform.md#u-8ce176223a22), [escape_html](r2-server-render.md#u-0f499dd45547)

**Uncertainties.**

- Whether context.visit on unrecognized attribute types can push output is decided by visitors outside this file.
- is_boolean_attribute, is_load_error_element, is_content_editable_binding, and the create_attribute/create_expression_metadata helpers are imported; their exact predicates are not visible here.

<a id="u-b758ea3e0e3a"></a>
### `build_attr_class`

`function build_attr_class(class_directives, expression, context, hash)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/element.js:L424-L451][f5]

Builds the $.attr_class call for a dynamic class attribute.

When class directives exist they become an object mapping each directive name to its visited expression. The scoped CSS hash is merged into the expression when it is a string literal (appended and trimmed, mutating the literal's value); otherwise it is passed as a separate literal argument. Returns $.attr_class(expression, css_hash-or-undefined, directives-or-undefined).

<a id="u-9bfb6c1f061d"></a>
### `build_attr_style`

`function build_attr_style(style_directives, expression, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/element.js:L459-L494][f5]

Builds the $.attr_style call for a dynamic style attribute.

Each style directive yields a property keyed by the original directive name with a value of the name identifier (when value is true) or build_attribute_value with whitespace trimming; property names other than CSS custom properties (not starting with '--') are lowercased. Directives with the 'important' modifier are separated into a second object; the directives argument is an array of [normal, important] objects when important properties exist, otherwise a single object of normal properties, or undefined when there are no directives.

<a id="u-f66dce05e822"></a>
### `build_element_spread_attributes`

`function build_element_spread_attributes( element, attributes, style_directives, clas…` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/element.js:L364-L415][f5]

Emits the single $.spread_attributes call used when an element has spread attributes.

Class directives become an object of name-to-value properties (shorthand identifier when the expression is an identifier matching the name, otherwise the visited expression); style directives become an object whose values are the directive name identifier when value is true, else build_attribute_value with whitespace trimming. Flags: svg or mathml elements set both ELEMENT_IS_NAMESPACED and ELEMENT_PRESERVE_ATTRIBUTE_CASE; a custom element (per is_custom_element_node) sets only ELEMENT_PRESERVE_ATTRIBUTE_CASE. The call arguments are the spread object from build_spread_object, the scoped CSS hash literal or null, the optional classes/styles objects, and a flags literal omitted (undefined) when flags is 0.

calls: [build_spread_object](r3-server-transform.md#u-3629ffc7b235), [is_custom_element_node](r3-scope-node-model.md#u-ea1f0b51e1e8)

**Uncertainties.**

- Runtime semantics of $.spread_attributes are not in this file.

<a id="u-3629ffc7b235"></a>
### `build_spread_object`

`export function build_spread_object(element, attributes, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/element.js:L331-L354][f5]

Builds an object expression representing the element's non-spread attributes for the spread path.

Attributes become init properties keyed by get_attribute_name with values from build_attribute_value (whitespace-insensitive for class/style); BindDirectives become properties whose value is a call of the first expression of a SequenceExpression or the visited binding expression; any SpreadAttribute in the list is emitted as a spread element of its visited expression, preserving spread order inside the object.

calls: [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/element.js:get_attribute_name](r3-server-transform.md#u-5ee6cbf26623), [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/utils.js:build_attribute_value](r4-server-transform.md#u-8ce176223a22)

<a id="u-5ee6cbf26623"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/element.js:get_attribute_name`

`function get_attribute_name(element, attribute)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/element.js:L316-L324][f5]

Resolves the output name for an attribute or binding: on HTML (non-svg, non-mathml) elements the name is lowercased, deliberately skipping boolean-attribute alias lookup because the server runtime only checks lowercase boolean variants; on svg/mathml elements the original casing is preserved.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/MemberExpression.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/PropertyDefinition.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/SpreadAttribute.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/SvelteElement.js
[f5]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/element.js
