# Compiler Utilities and AST Helpers

**Capability.** Shared, consumer-agnostic compiler support: AST inspection and construction (pattern/extraction helpers, attribute type-guards, assignment expansion), assertion helpers, and src/utils.js predicates (element/attribute name lists, namespace/rune checks) plus hashing and location sanitization.

Treat this as the shared library both analyze/transform phases and migration depend on. Nothing here owns a compiler phase; changes must preserve behavior relied on across all consumers.

**Depended on by.**

- [Analyze-Phase Visitors](r5-analyze-phase.md) · graph-confirmed · 16 edge(s)
- [Client Transform](r5-client-transform.md) · graph-confirmed · 10 edge(s)
- [Svelte 4 to 5 Migration](r5-svelte-migration.md) · graph-confirmed · 10 edge(s)
- [Scope and Node Model](r3-scope-node-model.md) · graph-only · 14 edge(s)
- [JS and Template Visitors](r4-analysis-visitors.md) · graph-only · 13 edge(s)
- [Client transform visitors](r2-client-visitors.md) · graph-only · 12 edge(s)
- [Component Analysis](r3-analysis-core.md) · graph-only · 11 edge(s)
- [Semantic Analysis](r6-compiler-analyze.md) · graph-only · 11 edge(s)
- [Analysis Visitors](r1-compiler-analyze-visitors.md) · graph-only · 10 edge(s)
- [Server Transform](r3-server-transform.md) · graph-only · 10 edge(s)

Parent: [Svelte Monorepo](r5-svelte-monorepo.md)

## Units (23)

<a id="u-2a153dd9dab6"></a>
### `equal`

`export function equal(actual, expected)` · [packages/svelte/src/compiler/utils/assert.js:L7-L9][f1]

Asserts identity between two values, throwing a plain Error('Assertion failed') on !== mismatch.

Uses only strict identity, so structural equality never passes; its TS assert-signature makes a passing call refine the argument type at compile time. No return value and no message customization.

<a id="u-9013e97c276b"></a>
### `_extract_paths`

`function _extract_paths(paths, inserts, param, expression, update_expression, has_def…` · [packages/svelte/src/compiler/utils/ast.js:L269-L415][f2]

Recursive core of `extract_paths`, dispatching on the param node type.

Identifier/MemberExpression records a path entry using the current expression and update_expression. For ObjectPattern: a RestElement property builds `$.exclude_from_object(expression, [literal keys...])` — keys become literals for non-computed Identifier keys or Literal keys, otherwise `String(key)` is called at runtime — and the rest argument is recorded directly if an Identifier, else recursed; regular properties become member accesses on the current expression, computed when the property is computed or the key is not an Identifier. For ArrayPattern, an intermediate `# = $.to_array(expression, ...)` insert is created first; the length literal is omitted when the last element is a RestElement. Each element then derives `#[i]` member accesses, or for a trailing RestElement a `#.slice(i)` rest expression, recursing into non-Identifier arguments. For AssignmentPattern, `build_fallback(expression, right)` produces the expression; an Identifier left side is recorded with `has_default_value: true`, otherwise recursion continues with the fallback expression and `has_default_value` set true while keeping the original update_expression. Returns the accumulated `paths`.

**Notes.**

- side_effect: Mutates the caller-supplied `paths` and `inserts` arrays in place.

calls: [build_fallback](r5-compiler-utilities.md#u-287d48fe390a); uses: [builders-js-trivial-node-builders](r4-compiler-infra.md#u-b83c295c759f); imports: [packages/svelte/src/compiler/builders.js](../../catalog.json)

**Uncertainties.**

- Runtime helper semantics of `$.to_array`, `$.exclude_from_object`, and `build_fallback` output are not visible here

<a id="u-634ffef5ceee"></a>
### `build_assignment_value`

`export function build_assignment_value(operator, left, right)` · [packages/svelte/src/compiler/utils/ast.js:L604-L611][f2]

Converts a compound assignment into its expanded right-hand value: for `=` it returns `right` unchanged; for `||=`, `&&=`, `??=` it builds a logical expression with the operator minus its trailing `=` applied to `left` and `right`; all other operators build a binary expression the same way (e.g. `x += 1` becomes `x + 1`).

**Uncertainties.**

- The logical/binary classification relies solely on membership in the hardcoded `['||=', '&&=', '??=']` list

<a id="u-287d48fe390a"></a>
### `build_fallback`

`export function build_fallback(expression, fallback)` · [packages/svelte/src/compiler/utils/ast.js:L585-L597][f2]

Builds a `$.fallback(expression, ...)` call implementing destructuring default values, choosing its shape by the fallback expression's complexity.

A simple fallback is passed directly for eager evaluation. An AwaitExpression whose argument is simple becomes `await $.fallback(expression, argument)`. Any other async fallback becomes `await $.fallback(expression, thunk(fallback, true), true)` — a lazily evaluated async thunk with a true flag — while a non-async fallback becomes `$.fallback(expression, thunk(fallback), true)`.

calls: [is_simple_expression](r5-compiler-utilities.md#u-410082960042), [is_expression_async](r5-compiler-utilities.md#u-88399029ef9f)

**Uncertainties.**

- Semantics of the trailing `true` argument to `$.fallback` are defined only in the runtime helper, not visible here

<a id="u-4fc74297abd5"></a>
### `extract_all_identifiers_from_expression`

`export function extract_all_identifiers_from_expression(expr)` · [packages/svelte/src/compiler/utils/ast.js:L146-L156][f2]

Walks an expression with zimmerframe to produce a dotted dependency keypath plus the list of free identifiers, returned as `[keypath, ids]`.

The Identifier visitor skips property-position identifiers of non-computed member expressions (so `a.b` contributes only to the keypath), but pushes computed keys to `ids` and brackets them as `[name]` in the keypath versus the bare name otherwise. Literals are stringified (strings quoted) with the same computed-key bracketing. ThisExpression contributes 'this' and uses `next()` to keep walking. The result is the keypath segments joined with '.'.

**Uncertainties.**

- Behavior for node types without an explicit visitor relies on default zimmerframe traversal
- Per the TODO, this may duplicate `expression.dependencies` semantics that could diverge

<a id="u-90eb95affc00"></a>
### `extract_identifiers`

`export function extract_identifiers(pattern)` · [packages/svelte/src/compiler/utils/ast.js:L136-L138][f2]

Returns only the Identifier leaves of a pattern by running `unwrap_pattern` on a fresh array and filtering out MemberExpressions.

calls: [unwrap_pattern](r5-compiler-utilities.md#u-73018823c866)

<a id="u-f5e86bd3328c"></a>
### `extract_identifiers_from_destructuring`

`export function extract_identifiers_from_destructuring(node, nodes = [])` · [packages/svelte/src/compiler/utils/ast.js:L193-L220][f2]

Extracts leaf identifiers from a destructuring shape expressed as expressions (ObjectExpression/ArrayExpression, as produced by the parser), accumulating into the passed array.

Identifier pushes itself; ObjectExpression recurses into each Property's value or a RestElement's argument; ArrayExpression recurses into non-hole elements. Unknown node types are ignored — the JSDoc notes this is intentionally incomplete but sufficient for its callers.

**Uncertainties.**

- Property values and rest arguments are cast via `any`, so malformed shapes are unchecked at this boundary

<a id="u-34f2fcb20c62"></a>
### `extract_paths`

`export function extract_paths(param, initial)` · [packages/svelte/src/compiler/utils/ast.js:L243-L258][f2]

Computes every destructured binding of `param` against the initial value `initial`, returning `{ inserts, paths }`.

Each `paths` entry records the leaf node (Identifier or MemberExpression), whether it is a rest, whether a default is involved, its value `expression`, and an `update_expression` without defaults. `inserts` holds intermediate declarations needed for array patterns (converting iterables via `$.to_array`); consumers must rename the placeholder `#` identifier. All recursion happens in `_extract_paths`, starting with `has_default_value = false`.

calls: [_extract_paths](r5-compiler-utilities.md#u-9013e97c276b)

<a id="u-1096ddb4c2b1"></a>
### `get_attribute_chunks`

`export function get_attribute_chunks(value)` · [packages/svelte/src/compiler/utils/ast.js:L70-L72][f2]

Normalizes an attribute value into an array of Text/ExpressionTag chunks.

Arrays pass through unchanged; a boolean shorthand value (`true`) yields an empty array; any other single value is wrapped in a one-element array.

<a id="u-96e6f6d66786"></a>
### `get_attribute_expression`

`export function get_attribute_expression(attribute)` · [packages/svelte/src/compiler/utils/ast.js:L59-L63][f2]

Unwraps the single ESTree expression of an attribute whose value is one ExpressionTag, accepting both the wrapped-array and bare forms.

When the value is an array it reads `value[0].expression`, otherwise `value.expression`. No validation is performed; callers are expected to have applied the matching type-guard.

contract: [is_expression_attribute](r5-compiler-utilities.md#u-f63f079d6472)

<a id="u-427249cf438e"></a>
### `get_parent`

`export function get_parent(path, at)` · [packages/svelte/src/compiler/utils/ast.js:L425-L432][f2]

Returns `path.at(at)` while skipping TypeScript wrapper nodes: if the node at the index is a TSNonNullExpression or TSAsExpression, it returns the neighbor at `at - 1` for negative indices or `at + 1` otherwise.

It also strips `undefined` from the result type for assertion convenience; if the path index is out of range, `path.at` itself yields undefined and this function does not guard against it.

**Uncertainties.**

- No check that the shifted neighbor is itself not a TS wrapper; a double-wrapped node would not be fully unwrapped

<a id="u-1c2da82112be"></a>
### `is_event_attribute`

`export function is_event_attribute(attribute)` · [packages/svelte/src/compiler/utils/ast.js:L79-L81][f2]

Type-guard for event-handler attributes: true when the attribute satisfies `is_expression_attribute` and its name starts with the literal prefix 'on'.

calls: [is_expression_attribute](r5-compiler-utilities.md#u-f63f079d6472)

<a id="u-88399029ef9f"></a>
### `is_expression_async`

`export function is_expression_async(expression)` · [packages/svelte/src/compiler/utils/ast.js:L484-L578][f2]

Recursively determines whether an expression or pattern contains an await.

AwaitExpression is trivially true. Composite nodes check their relevant children: ArrayPattern/ArrayExpression scan elements (holes false, SpreadElement's argument recursed); assignment, binary, and logical nodes check left (skipping PrivateIdentifier) then right; Call/New check the callee (skipping Super) and every argument; ChainExpression delegates to its inner expression; conditional checks all three branches; ImportExpression checks its source; MemberExpression checks object (skipping Super) and property (skipping PrivateIdentifier); object patterns/expressions check spread arguments and each Property's key (skipping PrivateIdentifier) and value; RestElement checks its argument; Sequence/TemplateLiteral scan their expressions; tagged templates check tag then quasi; Unary/Update check their argument; YieldExpression checks its argument only when present. All other node types return false.

**Uncertainties.**

- Nodes without an explicit case (e.g. plain Identifier, Literal) fall to the default false branch, which is intended

<a id="u-f63f079d6472"></a>
### `is_expression_attribute`

`export function is_expression_attribute(attribute)` · [packages/svelte/src/compiler/utils/ast.js:L43-L50][f2]

Type-guard for attributes holding a single expression.

Returns true in either of two cases: the value is a non-array non-`true` value (a bare ExpressionTag, kept for Svelte 5 compat per the TODO), or the value is a one-element array whose element type is 'ExpressionTag'. Shorthand (`value === true`) and multi-chunk attributes are false.

**Uncertainties.**

- The predicate assumes any non-array, non-`true` value is an ExpressionTag; no runtime check confirms this

<a id="u-410082960042"></a>
### `is_simple_expression`

`export function is_simple_expression(node)` · [packages/svelte/src/compiler/utils/ast.js:L442-L469][f2]

Reports whether an expression is side-effect-free to read, used to decide if eager access could prematurely trigger signals.

Literals, identifiers, and arrow/function expressions are simple. ConditionalExpressions are simple only if test, consequent, and alternate are all simple. Binary and logical expressions are simple when the left side is not a PrivateIdentifier and both sides are simple. Everything else returns false.

<a id="u-ec400088cae5"></a>
### `is_text_attribute`

`export function is_text_attribute(attribute)` · [packages/svelte/src/compiler/utils/ast.js:L28-L34][f2]

Type-guard that reports whether an attribute's value is a single static Text node.

True only when the value is an array of exactly one element whose type is 'Text'; shorthand attributes (value `true`) and multi-chunk or expression values return false.

<a id="u-2f2548aeaec6"></a>
### `object`

`export function object(expression)` · [packages/svelte/src/compiler/utils/ast.js:L11-L21][f2]

Returns the left-most identifier of a member-expression chain, or null.

It repeatedly steps from a MemberExpression into its `object` while the node is a MemberExpression, so `a.b.c` yields `a`. If the resulting root is not an Identifier (e.g. a call result), it returns null instead of throwing.

<a id="u-aa95700b7c80"></a>
### `unwrap_optional`

`export function unwrap_optional(node)` · [packages/svelte/src/compiler/utils/ast.js:L476-L478][f2]

Returns the inner expression of a ChainExpression, or the node itself when it is already a plain call or member expression.

<a id="u-73018823c866"></a>
### `unwrap_pattern`

`export function unwrap_pattern(pattern, nodes = [])` · [packages/svelte/src/compiler/utils/ast.js:L89-L129][f2]

Collects the assignable leaf nodes of a destructuring pattern into the given (default empty) array and returns it.

Identifier and MemberExpression nodes are pushed directly — member expressions are valid in assignment but not binding patterns. ObjectPattern recurses into each property's value, or a RestElement's argument; ArrayPattern skips null holes and recurses into remaining elements; RestElement recurses into its argument; AssignmentPattern recurses into its left side. Unknown node types contribute nothing.

<a id="u-57e79fafa2c2"></a>
### `utils.js-element-attribute-predicates`

`export function is_void(name)` · [packages/svelte/src/utils.js:L39-L41][f3]

Collection of name-list membership predicates and one aliasing helper used by the compiler and runtime to decide how elements and attributes are handled.

is_void matches the 16 void element names or a case-insensitive '!doctype'; is_reserved tests JavaScript reserved words (including eval, arguments, let, static, yield); is_capture_event matches names ending in 'capture' except the actual pointercapture/lostpointercapture event names; is_delegated matches the fixed list of 23 delegated DOM events; is_boolean_attribute matches present/absent attributes like disabled and checked; is_dom_property matches DOM properties (the boolean list plus value, volume, readOnly, etc.); cannot_be_set_statically matches autofocus, muted, defaultValue, and defaultChecked, which need JavaScript handling rather than static template output; is_passive_event matches touchstart and touchmove, which delegation marks passive by default; is_content_editable_binding matches textContent, innerHTML, and innerText bindings; is_load_error_element matches the nine elements that emit load and error events. normalize_attribute lowercases the name and maps it through ATTRIBUTE_ALIASES (e.g. formnovalidate to formNoValidate, srcobject to srcObject) so attribute names resolve to their property names; unknown names pass through lowercased.

**Uncertainties.**

- is_void's '!doctype' comparison makes the check case-insensitive only for that special case; callers pass element names whose casing conventions are not visible here.

<a id="u-c266f2d1e7a9"></a>
### `utils.js-namespace-and-rune-predicates`

`export function is_svg(name)` · [packages/svelte/src/utils.js:L389-L391][f3]

Predicates over namespaces and runes.

is_svg and is_mathml test membership in fixed lists of SVG element names (including hyphenated ones like color-profile and font-face) and MathML element names respectively, used to pick the correct namespace when creating elements. is_rune matches the full RUNES list of rune names ('$state', '$state.raw', '$derived', '$props', '$effect.tracking', '$inspect().with', '$host', etc.) and is_state_creation_rune matches the subset that creates reactive state ('$state', '$state.raw', '$derived', '$derived.by'); both act as type guards narrowing to the list-derived literal unions. is_raw_text_element matches textarea, script, style, and title — elements whose content is raw text and must not receive SSR hydration comments.

**Uncertainties.**

- Membership is exact-match and case-sensitive; names differing in casing from the lists will not match.

<a id="u-a8a8fa6d6333"></a>
### `hash`

`export function hash(str)` · [packages/svelte/src/utils.js:L7-L14][f3]

Computes a deterministic short string hash of a string using a djb2-style variant, used e.g. to validate {@html} content against server output.

Carriage returns are stripped first so differing line endings hash identically. It starts from 5381 and iterates characters from the end of the string, updating hash = ((hash << 5) - hash) ^ charCode, then returns the unsigned 32-bit value converted to a base-36 string. Overflow beyond 32 bits is possible before the final >>> 0 normalization; the caller-supplied graph evidence shows it feeding html-block hash checks on both server and client.

uses: [check_hash](r6-client-dom-blocks.md#u-1df4a5c06d12)

<a id="u-eb8e19f29107"></a>
### `sanitize_location`

`export function sanitize_location(location)` · [packages/svelte/src/utils.js:L489-L491][f3]

Returns a location string with every forward slash followed by a zero-width space, preventing devtools from rendering the path as a clickable link; undefined input passes through unchanged, preserving the generic T of the input type.

Replaces globally, so every slash is affected.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/utils/assert.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/utils/ast.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/utils.js
