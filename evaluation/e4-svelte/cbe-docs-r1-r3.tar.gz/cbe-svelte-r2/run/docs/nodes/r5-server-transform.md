# Server (SSR) Transform

**Capability.** Emits server-rendered output for blocks, slots and inline components: visitors serialize each SSR-relevant node type into $$payload-based calls, with shared/component.js providing the inline-component serializer used by Component and SvelteSelf.

Use this subtree for server-side rendering semantics, including hydration boundaries (KeyBlock comments), slot rendering and legacy $: labels. build_inline_component and its push_prop helper are the core component serializer.

**Depended on by.**

- [Compiler Public API and Pipeline](r5-compiler-pipeline.md) · containment · → 0 / ← 0 edge(s) (ancestor direct units and descendant subtree; → follows ` r5-compiler-pipeline ` → ` r5-server-transform `)

Parent: [Compiler Public API and Pipeline](r5-compiler-pipeline.md)

## Units (9)

<a id="u-98ec092cab2d"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/IfBlock.js:IfBlock`

`export function IfBlock(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/IfBlock.js:L12-L29][f1]

Emits an {#if} block as a runtime `if`.

The test and consequent are visited; the alternate is visited or an empty block. An opening hydration comment is unshifted into the consequent body, and a BLOCK_OPEN_ELSE literal push into the alternate body (even when the alternate was empty), then `b.if(test, consequent, alternate)` and block_close are pushed to the template.

<a id="u-b3e492375e5d"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/KeyBlock.js:KeyBlock`

`export function KeyBlock(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/KeyBlock.js:L10-L16][f2]

Emits a {#key} block by pushing an empty comment, the visited fragment block, and another empty comment into the template — the comments serve as hydration boundaries since server rendering has no keyed re-creation.

<a id="u-42a7cea77ed0"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/LabeledStatement.js:LabeledStatement`

`export function LabeledStatement(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/LabeledStatement.js:L9-L24][f3]

Handles legacy `$:` reactive labels.

If in runes mode, the path length is greater than 1 (nested anywhere other than top level), or the label is not `$`, it returns undefined so normal traversal applies. Otherwise it records the statement in state.legacy_reactive_statements as `b.labeled('$', visited body)` — keeping the `$` label because `break $` may occur inside — and returns an empty statement, deferring emission to later topological ordering. A TODO comment notes module context is not yet excluded.

**Uncertainties.**

- The bail-out for module context mentioned in the TODO is not implemented in this code

<a id="u-d7c757c85a8a"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/SlotElement.js:SlotElement`

`export function SlotElement(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/SlotElement.js:L11-L54][f4]

Renders a `<slot>` element as `$.slot($$payload, $$props, name, props, fallback)`.

Attributes are collected in order: spread attributes accumulate into `spreads`; regular attributes become init props via build_attribute_value, except `name` which overrides the default 'default' literal and `slot` which is dropped entirely. The props expression is a plain object when no spreads exist, otherwise `$.spread_props([{...}, ...spreads])`. The fallback is null when the fragment is empty, otherwise a thunk of the visited fragment. Output is wrapped in empty comments for hydration boundaries.

calls: [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/utils.js:build_attribute_value](r4-server-transform.md#u-8ce176223a22)

<a id="u-356cef502838"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/SvelteFragment.js:SvelteFragment`

`export function SvelteFragment(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/SvelteFragment.js:L9-L11][f5]

SSR visitor for `<svelte:fragment>`: visits the fragment content as a BlockStatement and pushes it onto state.template for the enclosing component/slot output.

**Uncertainties.**

- The cast assumes node.fragment transforms to a BlockStatement; behavior if it does not is not established here

<a id="u-e627a2f894c8"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/SvelteSelf.js:SvelteSelf`

`export function SvelteSelf(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/SvelteSelf.js:L10-L12][f6]

SSR visitor for `<svelte:self>`: delegates to build_inline_component with an identifier of the component's own analysis name.

calls: [build_inline_component](r5-server-transform.md#u-b4ac53ff3e29)

<a id="u-b4ac53ff3e29"></a>
### `build_inline_component`

`export function build_inline_component(node, expression, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/component.js:L14-L57][f7]

Prepares the serialization state for compiling a component, SvelteComponent, or SvelteSelf node into server output.

It accumulates props and spreads in props_and_spreads, collects CSS-custom-property (--*) attributes separately in custom_css_props, records let directives per slot in lets (default slot seeded empty), and builds child_state whose scope is the component's default-slot scope so default-slot children resolve in the component scope. slot_scope_applies_to_itself detects a slot attribute, in which case let directives are not pushed to lets.default; has_children_prop later forces the default slot to serialize as a children prop instead of $$slots when both a children attribute and child nodes exist. Delayed prop pushes (used for bind directives) are queued in delayed_props.

group: [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/component.js:push_prop](r5-server-transform.md#u-ea7f47924620), [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/component.js:build_inline_component](r5-server-transform.md#u-cca955f8230f); imports: [build_template](r4-server-transform.md#u-7d424d7f2d77)

**Uncertainties.**

- The exact type of node.metadata.scopes and whether a named-slot scope is always present at runtime is not shown in this file.

<a id="u-cca955f8230f"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/component.js:build_inline_component`

`export function build_inline_component(node, expression, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/component.js:L73-L317][f7]

Main body of the inline-component serializer.

For each attribute: LetDirective goes to lets.default (unless slot scope applies to the component itself); SpreadAttribute is visited and pushed as a spread entry; a leading '--' attribute becomes a custom_css_props entry via build_attribute_value; ordinary attributes become init properties (a 'children' attribute sets has_children_prop); a non-'this' BindDirective with a SequenceExpression emits get/set variables declared in context.state.init plus accessor properties, otherwise it emits delayed get/set properties whose setter assigns the bound expression and clears $$settled. Delayed props are flushed before slot serialization. Children are grouped by slot name (SnippetBlock children become shorthand props plus $$slots entries; element children with a slot attribute name their slot and collect their let directives). Each non-empty slot is serialized by visiting a synthetic fragment with the default child_state or the named-slot scope; slot parameters append an object pattern built from the let directives (plain name, object/array pattern when so written). The default slot becomes a children prop (wrapped in $.prevent_snippet_stringification in dev) plus $$slots.default:true only when there are no let directives and no fragment-carrying SvelteFragments; otherwise it becomes $$slots.default and children is set to $.invalid_default_snippet, which errors at runtime. $$slots is pushed if any slots were serialized. The props expression is a plain object when only one property group exists, otherwise a $.spread_props call. The call statement uses b.maybe_call for SvelteComponent (dynamic) and b.call otherwise; snippet declarations hoist into a surrounding block. If custom CSS props exist the statement is emitted through a $.css_props call whose second argument is false only for svg namespace and whose last argument is true when dynamic; otherwise a dynamic component emits an empty_comment anchor before the statement, and a trailing empty_comment is emitted unless skip_hydration_boundaries is set.

**Notes.**

- side_effect: Mutates context.state.init (bind get/set declarations) and context.state.template (css_props call, statements, anchor comments).
- condition: block.body.length === 0 for a slot skips emitting that slot entirely.

calls: [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/utils.js:build_attribute_value](r4-server-transform.md#u-8ce176223a22), [is_element_node](r3-scope-node-model.md#u-0d9a79ad394a), [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/component.js:push_prop](r5-server-transform.md#u-ea7f47924620)

**Uncertainties.**

- Runtime behavior of $.invalid_default_snippet, $.css_props, $.spread_props, and $.prevent_snippet_stringification is defined outside this file.
- The three _iterator_*.next() call sites (fragment iteration) could not be resolved by the supplied graph; they are for-of iteration over node.attributes/node.fragment.nodes in this source.

<a id="u-ea7f47924620"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/component.js:push_prop`

`function push_prop(prop, delay = false)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/component.js:L57-L58][f7]

Inner helper that appends a serialized property to the props list currently being built.

do_push inspects the last entry of props_and_spreads: if it is an array of properties it pushes onto it; if it is a spread expression it starts a fresh property array after it, preserving spread/binding ordering semantics. When delay is true the closure is queued in delayed_props instead of running immediately, so bind-generated getters/setters are emitted after spreads and cannot be overwritten by them.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/IfBlock.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/KeyBlock.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/LabeledStatement.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/SlotElement.js
[f5]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/SvelteFragment.js
[f6]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/SvelteSelf.js
[f7]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/component.js
