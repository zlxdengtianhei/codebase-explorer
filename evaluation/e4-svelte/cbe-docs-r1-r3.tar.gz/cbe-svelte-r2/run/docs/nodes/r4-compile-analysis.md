# Semantic Analysis (Phase 2)

**Capability.** Validates and annotates the parsed AST before codegen: CSS walking for scoping metadata and JS/template node visiting for rune legality, component structure, and warnings.

Use this subtree to see what constraints the compiler enforces and which metadata (used selectors, global blocks, state purity) codegen relies on. It splits into CSS-specific analysis and per-node-type visitors.

**Children.**

- [CSS Analysis](r4-css-analysis.md) `r4-css-analysis` · 10 unit(s)
- [JS and Template Visitors](r4-analysis-visitors.md) `r4-analysis-visitors` · 17 unit(s)

Parent: [Compiler Pipeline](r4-compiler.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
