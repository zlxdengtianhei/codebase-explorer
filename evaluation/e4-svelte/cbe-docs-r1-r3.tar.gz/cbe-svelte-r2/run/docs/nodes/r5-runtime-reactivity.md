# Client Runtime Reactivity

**Capability.** The signal machinery: source creation and write paths (set/internal_set/mark_reactions, update/increment), equality strategies, $state proxies and dev inspection, component prop synchronization (prop, rest/spread/legacy proxies), legacy invalidation helpers, generated runtime error factories and dev-only API validation.

Use this subtree for anything about how state changes propagate. Props and proxies build on sources; equality decides update propagation; errors.js and dev/* provide diagnostics consumed across the runtime.

**Depends on.**

- [Reactivity core](r2-reactivity-core.md) · graph-only · 20 edge(s)
- [Dev-Mode Diagnostics](r6-client-dev.md) · graph-only · 12 edge(s)

**Depended on by.**

- [Reactive Built-ins](r5-reactive-builtins.md) · graph-confirmed · 35 edge(s) · SvelteMap and SvelteURL back their mutations with sources, state, and set from the client reactivity core.
- [Client Runtime DOM](r5-runtime-dom.md) · graph-confirmed · 6 edge(s)
- [Reactive Primitives and Stores](r3-reactive-primitives.md) · graph-only · 15 edge(s)
- [Reactive Collections & Motion](r1-public-reactivity-motion.md) · graph-only · 9 edge(s)

Parent: [Svelte Monorepo](r5-svelte-monorepo.md)

## Units (67)

<a id="u-aa3a4430105f"></a>
### `errors.js-generated-error-throwers`

`export function async_derived_orphan()` · [packages/svelte/src/internal/client/errors.js:L11-L21][f1]

Generated factory functions for named Svelte runtime errors; each never returns.

Under the DEV flag from esm-env the function builds an Error whose message is 'name\n<full message>\n<docs URL>', sets error.name to 'Svelte error', and throws it, giving developers the full diagnostic; in production it throws a bare Error containing only the docs URL string. No function catches or falls back; every call site must treat the call as a throw. Parameterized messages interpolate their arguments into the DEV text. each_key_duplicate branches on its optional third argument: when value is truthy the message names the duplicate key, otherwise it reports only the two indexes.

imports: [errors.js module code (L1–L10)][f1]

<a id="u-4dc669135a61"></a>
### `invalidate_inner_signals`

`export function invalidate_inner_signals(fn)` · [packages/svelte/src/internal/client/legacy.js:L42-L46][f2]

Deprecated legacy-mode helper: invokes fn while capturing every signal read during the call, then re-writes each captured signal with internal_set(signal, signal.v) to invalidate its dependents.

Capture is nested-aware: capture_signals saves the previous captured_signals set, runs fn untracked with a fresh Set, merges the new set into the previous one when nested, and restores the previous set in a finally block, so an exception still unwinds the global to its prior value.

calls: [untrack](r2-reactivity-core.md#u-aa0e067da463), [internal_set](r5-runtime-reactivity.md#u-0dae6a8d64cd)

<a id="u-0c9fb6efcc44"></a>
### `proxy-js-reactive-proxy`

`export function proxy(value)` · [packages/svelte/src/internal/client/proxy.js:L39-L64][f3]

Creates a reactive Proxy over plain objects and arrays so property reads and writes become tracked sources.

Non-objects, null, values already bearing STATE_SYMBOL, and objects whose prototype is neither Object.prototype nor Array.prototype are returned unchanged. A version source tracks structural changes; each lazily discovered own property gets a `source` created through `with_parent`, which when the current update version differs from the creation-time version temporarily clears the active reaction and restores the parent version around `fn`, so late-created child sources are not attributed to the current reaction; on matching versions `fn` runs directly. Array targets eagerly create a `length` source and, in dev, wrap the raw value with `inspectable_array`. Handler behavior: `defineProperty` calls `e.state_descriptors_fixed()` when the descriptor lacks `value` or is non-configurable, non-enumerable, or non-writable, then creates a source or, if one exists, `set`s its value; `deleteProperty` sets an existing source to UNINITIALIZED (creating an UNINITIALIZED source via `with_parent` for own target props), incrementing the version only when a source existed or the prop was in the target; `get` returns the raw target for STATE_SYMBOL and `update_path` for PROXY_PATH_SYMBOL, otherwise creates a source (only when the prop is absent-but-existing reads are excluded, i.e. when it is an own writable descriptor) wrapping a nested `proxy` or UNINITIALIZED, returns `undefined` for UNINITIALIZED values, and falls back to `Reflect.get`; `getOwnPropertyDescriptor` substitutes the live source value into value descriptors and synthesizes a writable/enumerable/configurable descriptor for source-only properties; `has` returns true for STATE_SYMBOL, treats UNINITIALIZED sources as absent, creates sources when one exists already or when inside an active effect and the prop is absent or writable, subscribing via `get`; `set` handles array `length` shrinking by setting index sources (creating UNINITIALIZED ones for indices still in the target) to UNINITIALIZED, creates sources for new/writable props, wraps assigned values with `proxy`, invokes target setters before signaling, raises `length` when a new integer index is >= current length, and increments the version only when the property was previously absent; `ownKeys` subscribes to the version, filters target keys whose source is UNINITIALIZED, and appends source-only keys; `setPrototypeOf` always calls `e.state_prototype_fixed()`. In dev tracing, `update_path` rewrites `path`, re-tags the version and all child sources via `get_label`, guarded against re-entry by an `updating` flag.

calls: [source](r5-runtime-reactivity.md#u-97497b70f31b), [packages/svelte/src/internal/client/reactivity/sources.js:set](r5-runtime-reactivity.md#u-452914169f68), [increment](r5-runtime-reactivity.md#u-8fa6038c59d8), [runtime.js-module-state-setters](r2-reactivity-core.md#u-ac602620d878), [tracing.js-reactive-tracing](r6-client-dev.md#u-fb7046392fad), [get_label](r5-runtime-reactivity.md#u-51040fd3e0a9), [proxy-js-inspectable-array](r5-runtime-reactivity.md#u-f0a1c062bf17)

**Uncertainties.**

- The `set` handler's array-length branch dereferences `s.v` for 'length' without a null check, relying on the eager length-source creation that only happens for array targets

<a id="u-f0a1c062bf17"></a>
### `proxy-js-inspectable-array`

`function inspectable_array(array)` · [packages/svelte/src/internal/client/proxy.js:L411-L413][f3]

Wraps a raw array in a dev-only proxy so mutating array methods trigger `$inspect` exactly once.

In its `get`, non-mutating properties return the reflected value unchanged; for the nine known mutating methods (copyWithin, fill, pop, push, reverse, shift, sort, splice, unshift) it returns a wrapper function that first defers inspect effects, applies the method to the underlying array, then flushes inspect effects, preventing logs of intermediate states such as an emptied slot.

calls: [flush_inspect_effects](r5-runtime-reactivity.md#u-8313e354c312), [set_inspect_effects_deferred](r5-runtime-reactivity.md#u-96f10aa3e8f5)

<a id="u-51040fd3e0a9"></a>
### `get_label`

`function get_label(path, prop)` · [packages/svelte/src/internal/client/proxy.js:L359-L363][f3]

Formats a dev tracing label for a property within a path.

Symbols render as `path[Symbol(desc)]` (empty brackets when description is missing); identifier-like strings as `path.prop`; purely numeric strings as `path[0]`; any other string as `path['prop']`.

<a id="u-0468b533d5f3"></a>
### `get_proxied_value`

`export function get_proxied_value(value)` · [packages/svelte/src/internal/client/proxy.js:L368-L384][f3]

Unwraps a `$state` proxy to its raw target: for a non-null object holding STATE_SYMBOL it returns the value stored under that symbol; otherwise it returns the input unchanged.

The containment check runs in try/catch whose catch returns the original value, because the check throws for cross-origin iframe `contentWindow` objects and such values are definitely not proxies.

<a id="u-dcae92a399e9"></a>
### `is`

`export function is(a, b)` · [packages/svelte/src/internal/client/proxy.js:L390-L392][f3]

Proxy-aware equality: applies `Object.is` to both arguments after unwrapping each with `get_proxied_value`, so a state proxy and its raw target compare equal.

calls: [get_proxied_value](r5-runtime-reactivity.md#u-0468b533d5f3)

<a id="u-d069e3e7a0b4"></a>
### `packages/svelte/src/internal/client/reactivity/equality.js:equals`

`export function equals(value)` · [packages/svelte/src/internal/client/reactivity/equality.js:L4-L6][f4]

Strict-equality comparator intended as an Equals implementation bound to a reactive signal: returns value === this.v.

Requires 'this' to be a signal-like object with a v property.

**Uncertainties.**

- Detached invocation would throw; binding is established by callers outside this file.

<a id="u-80bb0808e8b1"></a>
### `not_equal`

`export function not_equal(a, b)` · [packages/svelte/src/internal/client/reactivity/equality.js:L24-L26][f4]

Plain strict inequality (a !== b) with no special cases: NaN never counts as changed and identical references count as equal.

<a id="u-371c4a3b72d6"></a>
### `safe_equals`

`export function safe_equals(value)` · [packages/svelte/src/internal/client/reactivity/equality.js:L29-L31][f4]

Complement of safe_not_equal bound to a signal: returns !safe_not_equal(value, this.v).

Like safe_not_equal, treats NaN as equal to itself-ish and always counts objects/functions as unequal, requiring 'this' with a v property.

calls: [safe_not_equal](r5-runtime-reactivity.md#u-3775acbc409e)

**Uncertainties.**

- Detached invocation would throw; binding is established by callers outside this file.

<a id="u-3775acbc409e"></a>
### `safe_not_equal`

`export function safe_not_equal(a, b)` · [packages/svelte/src/internal/client/reactivity/equality.js:L13-L17][f4]

Decides whether b differs from a enough to trigger an update.

If a is NaN (a != a), returns whether b is a number (b == b). Otherwise returns true when a !== b, or when a is a non-null object or a function — so objects and functions always count as changed even when reference-identical, forcing re-notification for mutable values.

<a id="u-a56d2b7daa4d"></a>
### `props-js-prop`

`export function prop(props, key, flags, fallback)` · [packages/svelte/src/internal/client/reactivity/props.js:L278-L286][f5]

prop synchronizes a possibly bound component prop with inner component state and returns a combined getter/setter closure.

Flags decide everything: runes mode is legacy_mode_flag off or PROPS_IS_RUNES; bindable is PROPS_IS_BINDABLE; lazy is PROPS_IS_LAZY_INITIAL. The get_fallback helper caches the fallback value once, evaluating it untracked when lazy. With bindable, a setter is taken from the props descriptor, or for entry props (detected by STATE_SYMBOL/LEGACY_PROPS) a direct assignment; and the initial value is captured via capture_store_binding, which also flags store subscriptions. When the initial value is undefined and a fallback exists, the fallback is evaluated and pushed through the setter (raising props_invalid_value in runes mode if the setter exists). Getters differ by mode: runes reads props[key], falling back to get_fallback on undefined and marking the fallback dirty again when a real value exists; legacy never reverts from defined to undefined — once a value is seen, fallback_value is cleared permanently. If the prop is never written (runes without PROPS_IS_UPDATED) only the getter is returned. If a parent setter exists, the returned function forwards writes (skipping notification when mutation && runes && non-legacy && not a store sub, since the state proxy handles it) and reads via the getter. Otherwise a local derived (derived_safe_equal, or derived for PROPS_IS_IMMUTABLE) is created over the getter, labelled with the key in dev, eagerly read when bindable, and the returned closure writes into it via set (proxying values when runes && bindable), records overridden, updates fallback_value when set, and on read short-circuits to d.v during teardown when overridden or when the parent effect is DESTROYED (supporting bind:this reads after destruction).

**Notes.**

- condition: mutation argument chooses between forwarding get(d) (mutation) and the raw value to the setter path.
- failure: props_invalid_value is thrown only when a runes-mode prop has a fallback, an initial undefined value, and an existing setter.

calls: [derived](r6-client-reactivity.md#u-d386336ed5eb), [packages/svelte/src/internal/client/reactivity/sources.js:set](r5-runtime-reactivity.md#u-452914169f68), [capture_store_binding](r2-store-integration.md#u-8388b459c980), [proxy-js-reactive-proxy](r5-runtime-reactivity.md#u-0c9fb6efcc44)

**Uncertainties.**

- Exact behavior of capture_store_binding's return tuple is defined in store.js.
- The semantics of get(d) and set(d, ...) on a Derived rely on runtime.js and sources.js behavior.

<a id="u-88830f9f33ea"></a>
### `props-js-rest-props`

`export function rest_props(props, exclude, name)` · [packages/svelte/src/internal/client/reactivity/props.js:L92-L97][f5]

rest_props wraps a props object in a Proxy that hides an exclude list, implementing `const { x, ...rest } = $props()`.

get returns undefined for excluded keys, otherwise the underlying props value (forwarding reactivity reads). set always fails: in dev it reports props_rest_readonly naming `name.key`, and returns false, so rest props are read-only. getOwnPropertyDescriptor returns an enumerable/configurable descriptor only for non-excluded keys present in props, otherwise undefined. has returns false for excluded keys, otherwise membership in props. ownKeys filters Reflect.ownKeys of props by the exclude list. The dev target additionally carries unused other and to_proxy fields.

**Notes.**

- failure: Any set attempt returns false, triggering a TypeError in strict mode, after a dev-only props_rest_readonly error is raised.

uses: [props-js-rest-props](r5-runtime-reactivity.md#u-88830f9f33ea)

<a id="u-b3aaaf7083f7"></a>
### `props-js-spread-props`

`export function spread_props(...props)` · [packages/svelte/src/internal/client/reactivity/props.js:L264-L266][f5]

spread_props wraps an array of prop objects (or thunks returning them) in a Proxy that resolves each key against the sources from last to first, so later spreads override earlier ones.

get unwraps thunks and returns the first (last-wins) object containing the key; undefined when none do. set unwraps from the end and invokes the first found setter descriptor, returning true; if no setter exists anywhere it returns false. getOwnPropertyDescriptor unwraps from the end and returns the first descriptor found, forcing configurable to true when the source descriptor is non-configurable — the proxy target (an array) does not actually hold the key, so leaving it false would make the proxy throw a validation error. has returns false for STATE_SYMBOL and LEGACY_PROPS (avoiding a false positive is_entry_props check) and otherwise true when any source contains the key. ownKeys deduplicates enumerable string keys and own symbols across all sources in order.

**Notes.**

- condition: Set only propagates when a source object exposes a real setter; assigning to a plain data property in a spread source does nothing and reports failure.

uses: [props-js-spread-props](r5-runtime-reactivity.md#u-b3aaaf7083f7)

<a id="u-a2db9dc5fc5e"></a>
### `props-js-legacy-rest-props`

`export function legacy_rest_props(props, exclude)` · [packages/svelte/src/internal/client/reactivity/props.js:L167-L181][f5]

legacy_rest_props wraps $$restProps/$$props for legacy mode in a Proxy backed by props, exclude, special (per-key prop accessors), a version source, and the creating active_effect.

get skips excluded keys, subscribes to the version source so any change re-runs readers, and returns special[key]\() if a special accessor exists, otherwise the raw props value. set first creates, when absent, a special accessor via prop() on a synthetic object reading target.props[key] (with the parent effect temporarily active so prop captures the right parent), then calls the accessor with the value and updates version — $$props is coarse-grained, so writing x re-runs readers of y too; it returns true. deleteProperty adds non-excluded keys to the exclude list and bumps version (Svelte 4 allowed deletions), always returning true. getOwnPropertyDescriptor mirrors rest props: undefined when excluded or missing. has returns false for excluded keys. ownKeys filters props keys by exclude.

**Notes.**

- side_effect: set mutates target.special and target.exclude, so handler state persists across calls.

calls: [props-js-prop](r5-runtime-reactivity.md#u-a56d2b7daa4d); uses: [packages/svelte/src/internal/client/reactivity/sources.js:set](r5-runtime-reactivity.md#u-452914169f68)

**Uncertainties.**

- The runtime `update` used on version is imported from sources.js/runtime; only its effect on the version source is visible here.

<a id="u-5e98617d4c45"></a>
### `update_prop`

`export function update_prop(fn, d = 1)` · [packages/svelte/src/internal/client/reactivity/props.js:L31-L35][f5]

Reads the current value with fn(), writes value + d back through fn, and returns the pre-update value; d defaults to 1.

<a id="u-b9f21e5041ee"></a>
### `update_pre_prop`

> **ID corrected by CBE.** CBE changed the unit ID from ` packages/svelte/src/internal/client/reactivity/props.js::function::update_pre_prop::866 ` to the inventory ID ` packages/svelte/src/internal/client/reactivity/props.js::function::update_pre_prop::1058 `. The model wrote this body under the wrong ID; it may be inaccurate.

`export function update_pre_prop(fn, d = 1)` · [packages/svelte/src/internal/client/reactivity/props.js:L42-L46][f5]

Computes fn() + d, writes that value back through fn, and returns the new (post-update) value; d defaults to 1.

Unlike update_prop the returned value reflects the write.

<a id="u-2943596ede3a"></a>
### `props.js module code (L1–L30)`

`module_region` · [packages/svelte/src/internal/client/reactivity/props.js:L1-L30][f5]

Module imports and type imports; non-behavioral.

<a id="u-b566645a6b55"></a>
### `props.js module code (L35–L41)`

`module_region` · [packages/svelte/src/internal/client/reactivity/props.js:L35-L41][f5]

Trailing region after update_prop; non-behavioral.

<a id="u-592c03ed7ac3"></a>
### `props.js module code (L46–L52)`

`module_region` · [packages/svelte/src/internal/client/reactivity/props.js:L46-L52][f5]

Trailing region after update_pre_prop; non-behavioral.

<a id="u-0517c21957ec"></a>
### `props.js module code (L57–L58)`

`module_region` · [packages/svelte/src/internal/client/reactivity/props.js:L57-L58][f5]

Separator between rest_props_handler methods; non-behavioral.

<a id="u-2cdd9ef31c12"></a>
### `props.js module code (L65–L66)`

`module_region` · [packages/svelte/src/internal/client/reactivity/props.js:L65-L66][f5]

Separator between rest_props_handler methods; non-behavioral.

<a id="u-248f50d4dd11"></a>
### `props.js module code (L75–L76)`

`module_region` · [packages/svelte/src/internal/client/reactivity/props.js:L75-L76][f5]

Separator between rest_props_handler methods; non-behavioral.

<a id="u-8a65900544f6"></a>
### `props.js module code (L79–L80)`

`module_region` · [packages/svelte/src/internal/client/reactivity/props.js:L79-L80][f5]

Separator between rest_props_handler methods; non-behavioral.

<a id="u-b08f3f3e9c86"></a>
### `props.js module code (L82–L91)`

`module_region` · [packages/svelte/src/internal/client/reactivity/props.js:L82-L91][f5]

Trailing region of the rest_props_handler object; non-behavioral.

<a id="u-0883ed3221a0"></a>
### `props.js module code (L97–L102)`

`module_region` · [packages/svelte/src/internal/client/reactivity/props.js:L97-L102][f5]

Trailing region after rest_props; non-behavioral.

<a id="u-fc31e06b4869"></a>
### `props.js module code (L108–L109)`

`module_region` · [packages/svelte/src/internal/client/reactivity/props.js:L108-L109][f5]

Separator between legacy_rest_props_handler methods; non-behavioral.

<a id="u-7dc9a6c07703"></a>
### `props.js module code (L135–L136)`

`module_region` · [packages/svelte/src/internal/client/reactivity/props.js:L135-L136][f5]

Separator between legacy_rest_props_handler methods; non-behavioral.

<a id="u-ea62e7fe42e9"></a>
### `props.js module code (L145–L146)`

`module_region` · [packages/svelte/src/internal/client/reactivity/props.js:L145-L146][f5]

Separator between legacy_rest_props_handler methods; non-behavioral.

<a id="u-cb6894fba728"></a>
### `props.js module code (L152–L153)`

`module_region` · [packages/svelte/src/internal/client/reactivity/props.js:L152-L153][f5]

Separator between legacy_rest_props_handler methods; non-behavioral.

<a id="u-4bbbd9ec83da"></a>
### `props.js module code (L156–L157)`

`module_region` · [packages/svelte/src/internal/client/reactivity/props.js:L156-L157][f5]

Separator between legacy_rest_props_handler methods; non-behavioral.

<a id="u-395d890145cf"></a>
### `props.js module code (L159–L166)`

`module_region` · [packages/svelte/src/internal/client/reactivity/props.js:L159-L166][f5]

Trailing region of the legacy_rest_props_handler object; non-behavioral.

<a id="u-4ceb97961b8d"></a>
### `props.js module code (L181–L188)`

`module_region` · [packages/svelte/src/internal/client/reactivity/props.js:L181-L188][f5]

Trailing region after legacy_rest_props; non-behavioral.

<a id="u-8e08de167667"></a>
### `props.js module code (L197–L198)`

`module_region` · [packages/svelte/src/internal/client/reactivity/props.js:L197-L198][f5]

Separator between spread_props_handler methods; non-behavioral.

<a id="u-835f0c9995b0"></a>
### `props.js module code (L210–L211)`

`module_region` · [packages/svelte/src/internal/client/reactivity/props.js:L210-L211][f5]

Separator between spread_props_handler methods; non-behavioral.

<a id="u-e7f67ab43e17"></a>
### `props.js module code (L227–L228)`

`module_region` · [packages/svelte/src/internal/client/reactivity/props.js:L227-L228][f5]

Separator between spread_props_handler methods; non-behavioral.

<a id="u-fd7bf3a7a048"></a>
### `props.js module code (L238–L239)`

`module_region` · [packages/svelte/src/internal/client/reactivity/props.js:L238-L239][f5]

Separator between spread_props_handler methods; non-behavioral.

<a id="u-41215cb3ff4e"></a>
### `props.js module code (L257–L263)`

`module_region` · [packages/svelte/src/internal/client/reactivity/props.js:L257-L263][f5]

Trailing region of the spread_props_handler object; non-behavioral.

<a id="u-dedd5aa1c2c8"></a>
### `props.js module code (L266–L277)`

`module_region` · [packages/svelte/src/internal/client/reactivity/props.js:L266-L277][f5]

Trailing region after spread_props; non-behavioral.

<a id="u-97497b70f31b"></a>
### `source`

`export function source(v, stack)` · [packages/svelte/src/internal/client/reactivity/sources.js:L66-L85][f6]

Creates a plain reactive Value object with flags 0, the initial value, default equals, and zeroed rv/wv; no dependencies or reactions yet.

In dev tracing mode it records created (from the stack argument or get_stack('CreatedAt')) plus null-initialized updated, set_during_effect, and trace fields. The value v is stored as-is; fn is never evaluated.

<a id="u-acd426d0030b"></a>
### `state`

`export function state(v, stack)` · [packages/svelte/src/internal/client/reactivity/sources.js:L93-L99][f6]

Creates a source via source(v, stack) and additionally registers it with push_reaction_value before returning; otherwise identical to source.

calls: [source](r5-runtime-reactivity.md#u-97497b70f31b)

<a id="u-32c84d6fdda4"></a>
### `mutable_source`

`export function mutable_source(initial_value, immutable = false, trackable = true)` · [packages/svelte/src/internal/client/reactivity/sources.js:L108-L121][f6]

Creates a source intended for mutation, switching equals to safe_equals unless immutable is true (safe_equals means identity-based values still compare as changed, so mutation updates propagate).

In legacy mode, when trackable and a component context with lifecycle state exists, the signal is appended to component_context.l.s (creating the array if needed) so updates can trigger beforeUpdate/afterUpdate.

<a id="u-1be316a4a069"></a>
### `mutate`

`export function mutate(source, value)` · [packages/svelte/src/internal/client/reactivity/sources.js:L128-L134][f6]

Writes the source's current value back through set, untracked, so in-place mutations of objects/arrays are detected by the equality check without tracking reads.

Always returns the passed value regardless of the set result.

calls: [packages/svelte/src/internal/client/reactivity/sources.js:set](r5-runtime-reactivity.md#u-452914169f68)

<a id="u-452914169f68"></a>
### `packages/svelte/src/internal/client/reactivity/sources.js:set`

`export function set(source, value, should_proxy = false)` · [packages/svelte/src/internal/client/reactivity/sources.js:L143-L163][f6]

Public write path for a source.

First it guards against unsafe mutation: if there is an active reaction, we are not untracking (or the reaction is an inspect effect), runes mode is on, and the reaction is a derived, block effect, async, or inspect effect, and the source is not in current_sources, it throws state_unsafe_mutation. The value is proxied first when should_proxy is set; in dev it is tagged with the source's label via tag_proxy. It then delegates the actual update to internal_set and returns its result.

calls: [internal_set](r5-runtime-reactivity.md#u-0dae6a8d64cd), [proxy-js-reactive-proxy](r5-runtime-reactivity.md#u-0c9fb6efcc44)

**Uncertainties.**

- The exact role of current_sources in permitting writes is set elsewhere.

<a id="u-0dae6a8d64cd"></a>
### `internal_set`

`export function internal_set(source, value)` · [packages/svelte/src/internal/client/reactivity/sources.js:L171-L243][f6]

Core unconditional write to a source; it is a no-op returning the value unchanged when source.equals(value) holds.

On a real change it records the old value in old_values (recording the new value instead when a destroying effect is running), assigns source.v, and captures the previous value on the current Batch via Batch.ensure().capture. In dev it records an 'UpdatedAt' stack, deduplicated per stack trace with a hit count, and sets set_during_effect when an effect is active. If the target is a derived: when it is DIRTY it is eagerly executed via execute_derived to track dependencies, then its status is set to CLEAN when not UNOWNED, otherwise MAYBE_DIRTY. It bumps the write version, marks reactions DIRTY via mark_reactions, and — in runes mode, when the active effect is CLEAN and not a branch/root effect — registers the source in untracked_writes so a currently running effect (e.g. `$effect(() => x++)`) still gets scheduled. Finally, in dev with non-empty inspect_effects and no deferral, it flushes them immediately. Always returns the new value.

**Notes.**

- failure: No safety guard here: this function writes even inside effects; the guard lives in set().

calls: [execute_derived](r6-client-reactivity.md#u-193107029d03), [runtime.js-module-state-setters](r2-reactivity-core.md#u-ac602620d878), [flush_inspect_effects](r5-runtime-reactivity.md#u-8313e354c312)

**Uncertainties.**

- Batch.capture/ensure semantics live in batch.js.
- Behavior when old_values entries are later read is outside this file.

<a id="u-a19ed62d3d7e"></a>
### `mark_reactions`

`function mark_reactions(signal, status)` · [packages/svelte/src/internal/client/reactivity/sources.js:L307-L346][f6]

Recursively propagates a dirtiness status to a signal's reactions.

It returns immediately when there are none. Per reaction, in order: in legacy mode the active effect is skipped to prevent infinite loops; in dev, inspect effects are collected into inspect_effects instead of being scheduled (so they can run immediately with a meaningful stack); reactions not already DIRTY get the given status via set_signal_status (a DIRTY reaction is never downgraded to MAYBE_DIRTY); derived reactions are recursed into with MAYBE_DIRTY; and other non-dirty reactions are scheduled — block effects are additionally pushed onto eager_block_effects when that list is non-null.

**Notes.**

- condition: Scheduling happens only for reactions that were not already DIRTY; already-dirty reactions are left untouched.

calls: [schedule_effect](r4-reactivity-scheduling.md#u-ce4f8d895426), [runtime.js-module-state-setters](r2-reactivity-core.md#u-ac602620d878)

<a id="u-8313e354c312"></a>
### `flush_inspect_effects`

`export function flush_inspect_effects()` · [packages/svelte/src/internal/client/reactivity/sources.js:L245-L263][f6]

Runs pending inspect effects synchronously.

It clears the deferral flag, snapshots inspect_effects into an array, and for each effect: marks CLEAN effects MAYBE_DIRTY first, then updates it via update_effect only if is_dirty reports true — this avoids over-firing clean effects. Finally it clears the set so effects are not re-run.

calls: [update_effect](r2-reactivity-core.md#u-e2ea8c85735e), [is_dirty](r2-reactivity-core.md#u-6236bf4a1a35), [runtime.js-module-state-setters](r2-reactivity-core.md#u-ac602620d878)

<a id="u-118b0ec57332"></a>
### `set_inspect_effects`

`export function set_inspect_effects(v)` · [packages/svelte/src/internal/client/reactivity/sources.js:L49-L51][f6]

Replaces the module-level inspect_effects set with the given set.

Callers (e.g. execute_derived in dev) use it to isolate inspect effects collected during a derived evaluation.

<a id="u-96f10aa3e8f5"></a>
### `set_inspect_effects_deferred`

`export function set_inspect_effects_deferred()` · [packages/svelte/src/internal/client/reactivity/sources.js:L55-L57][f6]

Sets the module-level inspect_effects_deferred flag to true, which makes internal_set skip the immediate flush_inspect_effects call; something later must clear it (flush_inspect_effects resets the flag when it runs).

**Uncertainties.**

- What schedules the deferred flush after this flag is set is not visible in this file.

<a id="u-63fbe11acd11"></a>
### `packages/svelte/src/internal/client/reactivity/sources.js:update`

`export function update(source, d = 1)` · [packages/svelte/src/internal/client/reactivity/sources.js:L271-L279][f6]

Post-increment/decrement on a numeric or bigint source: reads the value via get, computes the pre-update result for d = 1 (post-increment) or -1 (post-decrement), writes the updated value with set, and returns the pre-update result.

calls: [packages/svelte/src/internal/client/reactivity/sources.js:set](r5-runtime-reactivity.md#u-452914169f68)

<a id="u-58e668ab2289"></a>
### `update_pre`

`export function update_pre(source, d = 1)` · [packages/svelte/src/internal/client/reactivity/sources.js:L287-L292][f6]

Pre-increment/decrement on a numeric or bigint source: reads via get, increments or decrements depending on d (1 or -1), writes with set, and returns the set call's result — the new value.

calls: [packages/svelte/src/internal/client/reactivity/sources.js:set](r5-runtime-reactivity.md#u-452914169f68)

<a id="u-8fa6038c59d8"></a>
### `increment`

`export function increment(source)` · [packages/svelte/src/internal/client/reactivity/sources.js:L298-L300][f6]

Writes source.v + 1 through set without reading the source through get first — deliberately bypassing dependency tracking, so callers (like proxy handlers) do not register the source as a dependency.

calls: [packages/svelte/src/internal/client/reactivity/sources.js:set](r5-runtime-reactivity.md#u-452914169f68)

<a id="u-71bbe3139d81"></a>
### `sources.js module code (L1–L48)`

`module_region` · [packages/svelte/src/internal/client/reactivity/sources.js:L1-L48][f6]

Module imports plus the inspect_effects and old_values declarations; non-behavioral.

<a id="u-6d055fef0d19"></a>
### `sources.js module code (L51–L54)`

`module_region` · [packages/svelte/src/internal/client/reactivity/sources.js:L51-L54][f6]

Separator after set_inspect_effects; non-behavioral.

<a id="u-9c4940e2ef5e"></a>
### `sources.js module code (L57–L65)`

`module_region` · [packages/svelte/src/internal/client/reactivity/sources.js:L57-L65][f6]

Trailing region after set_inspect_effects_deferred; non-behavioral.

<a id="u-c15a60a93058"></a>
### `sources.js module code (L85–L92)`

`module_region` · [packages/svelte/src/internal/client/reactivity/sources.js:L85-L92][f6]

Trailing region after source; non-behavioral.

<a id="u-7b033f14967e"></a>
### `sources.js module code (L99–L107)`

`module_region` · [packages/svelte/src/internal/client/reactivity/sources.js:L99-L107][f6]

Trailing region after state; non-behavioral.

<a id="u-ab0905a8f4db"></a>
### `sources.js module code (L121–L127)`

`module_region` · [packages/svelte/src/internal/client/reactivity/sources.js:L121-L127][f6]

Trailing region after mutable_source; non-behavioral.

<a id="u-b3f835387b77"></a>
### `sources.js module code (L134–L142)`

`module_region` · [packages/svelte/src/internal/client/reactivity/sources.js:L134-L142][f6]

Trailing region after mutate; non-behavioral.

<a id="u-3c962c8bc656"></a>
### `sources.js module code (L163–L170)`

`module_region` · [packages/svelte/src/internal/client/reactivity/sources.js:L163-L170][f6]

Trailing region after set; non-behavioral.

<a id="u-50bee4916726"></a>
### `sources.js module code (L263–L270)`

`module_region` · [packages/svelte/src/internal/client/reactivity/sources.js:L263-L270][f6]

Trailing region after internal_set; non-behavioral.

<a id="u-449f34265f17"></a>
### `sources.js module code (L279–L286)`

`module_region` · [packages/svelte/src/internal/client/reactivity/sources.js:L279-L286][f6]

Trailing region after flush_inspect_effects; non-behavioral.

<a id="u-c7fef567b91a"></a>
### `sources.js module code (L292–L297)`

`module_region` · [packages/svelte/src/internal/client/reactivity/sources.js:L292-L297][f6]

Trailing region after update; non-behavioral.

<a id="u-cd24b4fd82a7"></a>
### `sources.js module code (L300–L306)`

`module_region` · [packages/svelte/src/internal/client/reactivity/sources.js:L300-L306][f6]

Trailing region after increment; non-behavioral.

<a id="u-e8e23a5f2201"></a>
### `legacy_api`

`export function legacy_api()` · [packages/svelte/src/internal/client/dev/legacy.js:L12-L16][f7]

Builds the legacy component API surface that always fails in runes mode.

It resolves component from component_context?.function and returns an object whose $destroy, $on, and $set methods each throw component_api_changed via a shared error(method) closure that reports the component's FILENAME.

uses: [check_target](r5-runtime-reactivity.md#u-bcccf8325ff4)

**Uncertainties.**

- check_target and legacy_api are not visibly called from each other in this file; their shared caller is outside the supplied source.

<a id="u-bcccf8325ff4"></a>
### `check_target`

`export function check_target(target)` · [packages/svelte/src/internal/client/dev/legacy.js:L6-L10][f7]

Throws a component_api_invalid_new error when a truthy target is passed, using target[FILENAME] (or 'a component' when unset) and target.name in the message; a falsy target is silently accepted.

<a id="u-a46097177ac6"></a>
### `validate_snippet_args`

`export function validate_snippet_args(anchor, ...args)` · [packages/svelte/src/internal/client/dev/validation.js:L6-L16][f8]

Validates snippet call arguments in dev mode.

It raises invalid_snippet_arguments when the anchor is not an object or not a Node instance, and for each remaining argument when it is not a function; valid input returns normally with no value.

uses: [validation.js module code (L1–L5)][f8]

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/errors.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/legacy.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/proxy.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/reactivity/equality.js
[f5]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/reactivity/props.js
[f6]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/reactivity/sources.js
[f7]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dev/legacy.js
[f8]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dev/validation.js
