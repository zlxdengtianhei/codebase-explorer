# Client Error Boundaries

**Capability.** Central error handling for effect execution: bubbles errors to boundary effects, applies dev-only message/stack adjustments derived from component ancestry, and skips handling for destroyed work.

Use this subtree to trace what happens when an effect throws. handle_error is the entry; adjustments are computed once and re-applied via property redefinition. Its exact interaction with the effect engine beyond the documented calls is not resolved here.

Parent: [Client Runtime](r3-runtime.md)

## Units (4)

<a id="u-1b3b4fa2c18e"></a>
### `handle_error`

`export function handle_error(error)` · [packages/svelte/src/internal/client/error-handling.js:L15-L44][f1]

Central handler for errors raised during effect execution.

With no active effect, it sets ERROR_VALUE on the active reaction's flags so an unowned derived throws only when read, and returns the error. Otherwise, in DEV for not-yet-recorded Error instances, it computes and caches component-stack adjustments. If the effect has not run (error during subtree creation): a non-boundary effect rethrows (applying cached adjustments only at the root, i.e. when effect.parent is null), letting the error bubble to a creating boundary; a boundary effect delegates to effect.b.error(error). If the effect already ran, it bubbles the error itself via invoke_error_boundary.

calls: [get_adjustments](r3-client-error-handling.md#u-d2e928a5c137), [apply_adjustments](r3-client-error-handling.md#u-1f031c007120), [invoke_error_boundary](r3-client-error-handling.md#u-8ed809bdafb5)

**Uncertainties.**

- When effect === null, active_reaction is cast to Derived without a check; behavior if it is another reaction type is not established here.

<a id="u-8ed809bdafb5"></a>
### `invoke_error_boundary`

`export function invoke_error_boundary(error, effect)` · [packages/svelte/src/internal/client/error-handling.js:L50-L69][f1]

Bubbles an error up the effect tree looking for a boundary effect.

For each effect with BOUNDARY_EFFECT set, it calls that boundary's error handler and returns on success; if the handler itself throws, the thrown value replaces the error and the walk continues upward. If the chain ends without a boundary handling the error, cached adjustments are applied for Error instances and the error is rethrown to the caller.

calls: [apply_adjustments](r3-client-error-handling.md#u-1f031c007120)

<a id="u-1f031c007120"></a>
### `apply_adjustments`

`function apply_adjustments(error)` · [packages/svelte/src/internal/client/error-handling.js:L104-L116][f1]

Applies previously cached adjustments to an Error by redefining its 'message' and 'stack' properties with define_property; when no adjustment was cached the error is left untouched.

No-ops outside DEV flows since nothing is cached there.

contract: [get_adjustments](r3-client-error-handling.md#u-d2e928a5c137)

<a id="u-d2e928a5c137"></a>
### `get_adjustments`

`function get_adjustments(error, effect)` · [packages/svelte/src/internal/client/error-handling.js:L76-L99][f1]

Builds development-only message and stack adjustments for an error from the effect's component ancestry.

If the error's 'message' property is not configurable it returns undefined, since overwriting would throw and swallow the original error. It composes a component stack line per ancestor context (filename via FILENAME, or '<unknown>' when the effect function has no name, indented with two spaces on Firefox else a tab). The returned stack filters out lines containing 'svelte/src/internal'.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/error-handling.js
