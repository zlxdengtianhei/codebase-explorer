# Template parser

**Capability.** Turns raw Svelte template text into an AST.Root via a character-level state machine, backed by self-contained bracket/string scanning and HTML character-reference decoding utilities.

Read Parser and parse for the entry flow; eat, read_identifier and read_until are the primitive consumption operations. bracket.js helpers locate brackets, quotes and regex ends while respecting escapes; html.js decodes and validates character references used by text (and attribute) parsing.

**Depended on by.**

- [Diagnostics, state and validation infrastructure](r2-compiler-infrastructure.md) · model-inferred · 0 edge(s)

Parent: [Compiler](r2-compiler.md)

## Units (19)

<a id="u-e466b0264ad6"></a>
### `Parser`

`class Parser` · [packages/svelte/src/compiler/phases/1-parse/index.js:L18-L57][f1]

Character-level parser for Svelte templates that drives a state machine over the raw template string and produces an AST.Root.

It tracks the current index, TypeScript mode, a stack of open nodes, a parallel fragment stack, meta tags, and any auto-closed tag. Trivial helpers folded here: `current` returns the top of the stack; `acorn_error` rethrows an Acorn error via `e.js_parse_error`, stripping the trailing `(line:col)` position indicator from the message; `match` compares the string at the current index (single-character fast path); `match_regex` matches a regex on the remaining input and returns null unless the match starts at index 0; `allow_whitespace`/`require_whitespace` skip whitespace, the latter raising `e.expected_whitespace` first; `read` matches a `^`-anchored regex and advances on success; `pop` pops both the fragment and node stacks and returns the closed node; `append` pushes a node onto the innermost fragment's nodes and returns it.

<a id="u-53ab5f2b9b37"></a>
### `packages/svelte/src/compiler/phases/1-parse/index.js:parse`

`export function parse(template, loose = false)` · [packages/svelte/src/compiler/phases/1-parse/index.js:L296-L301][f1]

Entry point that parses a Svelte template into an AST.Root.

It records the source in shared compiler state via `state.set_source(template)` (used for error context), constructs a `Parser` in loose mode only if `loose` is true — the constructor performs the full parse — and returns `parser.root`.

uses: [Parser](r2-parse.md#u-e466b0264ad6)

<a id="u-b8662ab25ac9"></a>
### `Parser.constructor`

`constructor(template, loose)` · [packages/svelte/src/compiler/phases/1-parse/index.js:L57-L151][f1]

Runs the whole template parse: validates the template is a string (TypeError otherwise), trims trailing whitespace, detects TypeScript mode from the first `lang=` attribute of a `<s...` tag (a global regex loop requires the match to start with '<s'; `lastIndex` is reset afterwards because the regex is module-level), and seeds a Root node with an empty fragment, js list, and `metadata.ts`.

It then loops the fragment state function — each state returns the next state or falls back to `fragment` — until the index reaches the template end. Unclosed nodes are then handled: in loose mode the current node just ends at template length; a RegularElement raises `e.element_unclosed`, other node types raise `e.block_unclosed`, both after pinning `end` to start+1. If the final state is not `fragment`, `e.unexpected_eof` is thrown. Root start/end are computed from the first/last fragment node with surrounding whitespace skipped, or null when the fragment is empty. Finally, a top-level `<svelte:options>` node is removed from the fragment, converted via `read_options`, validated with `disallow_children`, attached to root.options, and its original raw node stored as a non-enumerable `__raw__` property for the old AST format.

**Notes.**

- side_effect: Uses a module-level global regex (regex_lang_attribute) whose lastIndex is manually reset; running detection depends on that reset.
- failure: Non-string templates throw TypeError; unclosed elements/blocks and premature EOF raise compiler errors via the e.* helpers, which do not return.

calls: [create_fragment](r3-parse-utilities.md#u-6f16c2773335), [read_options](r1-compiler-parse-options.md#u-d4c4a2170fce), [disallow_children](r6-compiler-analyze.md#u-43b79d8932ce)

**Uncertainties.**

- The lang-detection do/while loop condition (match_lang[0][1] !== 's') combined with the regex means only the first tag starting '<s' with lang= is considered; interaction with comments in the regex alternation is not fully proven.

<a id="u-8cb832201f3c"></a>
### `Parser.eat`

`eat(str, required = false, required_in_loose = true)` · [packages/svelte/src/compiler/phases/1-parse/index.js:L170-L181][f1]

Consumes a literal string if it matches at the current index, advancing the index by its length and returning true.

Otherwise returns false unless the token is required: when `required` is true and (not in loose mode, or `required_in_loose` is also true), `e.expected_token` raises a parse error. In loose mode with `required_in_loose=false`, a missing required token is tolerated.

<a id="u-fc2e325a2bd5"></a>
### `Parser.read_identifier`

`read_identifier(allow_reserved = false)` · [packages/svelte/src/compiler/phases/1-parse/index.js:L222-L246][f1]

Reads a Unicode identifier at the current index, advancing it.

Returns null immediately if the first code point fails `isIdentifierStart`; otherwise consumes code points while `isIdentifierChar` holds, advancing by 1 or 2 depending on whether the code point fits in a UTF-16 unit. When `allow_reserved` is false and the identifier is a reserved word (per `is_reserved`), `e.unexpected_reserved_word` raises with the start position and the identifier text.

calls: [utils.js-element-attribute-predicates](r5-compiler-utilities.md#u-57e79fafa2c2)

<a id="u-0bfb5a68006c"></a>
### `Parser.read_until`

`read_until(pattern)` · [packages/svelte/src/compiler/phases/1-parse/index.js:L249-L265][f1]

Consumes and returns all text up to the first match of a regex, moving the index to the match position.

At or past the end of the template it returns '' in loose mode but raises `e.unexpected_eof` otherwise. If the regex never matches, the index moves to the end and the entire remainder is returned.

<a id="u-36401d8c3a23"></a>
### `text`

`export default function text(parser)` · [packages/svelte/src/compiler/phases/1-parse/state/text.js:L6-L23][f2]

Consumes template characters until the next '<' or '{' or end of template, then appends a Text node whose data has character references decoded (entity decoding differs from attribute values via the second decode argument).

calls: [decode_character_references](r2-parse.md#u-a03f13997ae5)

<a id="u-29a08a302323"></a>
### `count_leading_backslashes`

`function count_leading_backslashes(string, search_start_index)` · [packages/svelte/src/compiler/phases/1-parse/utils/bracket.js:L77-L85][f3]

Counts consecutive backslashes ending at search_start_index by walking backwards while string[i] === '\\'.

Returns 0 when the character at the start index is not a backslash; reading before index 0 yields undefined and stops the loop, so no explicit bounds check is needed.

<a id="u-3e5597267416"></a>
### `find_matching_bracket`

`export function find_matching_bracket(template, index, open)` · [packages/svelte/src/compiler/phases/1-parse/utils/bracket.js:L94-L135][f3]

Scans template from index for the bracket closing `open`, ignoring brackets inside comments, string literals, and regex, returning the closer's index or undefined if the scan ends with depth > 0.

Depth starts at 1; close comes from default_brackets ({ }, ( ), [ ]). Per character: quotes jump past the string with find_string_end (an Infinity result makes i exceed template.length and ends the loop); a '/' with no next char continues without advancing i; '//' skips to just after the next newline, '/*' to just after the next '*/', both via infinity_if_negative so a missing terminator exits the loop; any other char after '/' is treated as regex start and find_regex_end skips it; default adjusts depth on open/close, returning i the moment depth reaches 0.

calls: [find_string_end](r2-parse.md#u-218d9a0afb81), [infinity_if_negative](r2-parse.md#u-edd9bb8ecede), [find_regex_end](r2-parse.md#u-61260c77d46c)

**Uncertainties.**

- The `if (!next_char) continue;` path for a trailing '/' does not advance i, so loop progress on that path depends on the loop condition, not on visible advancement.

<a id="u-61260c77d46c"></a>
### `find_regex_end`

`function find_regex_end(string, search_start_index)` · [packages/svelte/src/compiler/phases/1-parse/utils/bracket.js:L41-L43][f3]

Returns the index of the first unescaped '/' at or after search_start_index, or Infinity if none exists.

Thin delegation to find_unescaped_char.

calls: [find_unescaped_char](r2-parse.md#u-e7db0acb2cbc)

<a id="u-218d9a0afb81"></a>
### `find_string_end`

`function find_string_end(string, search_start_index, string_start_char)` · [packages/svelte/src/compiler/phases/1-parse/utils/bracket.js:L21-L34][f3]

Finds the closing quote of a string starting at search_start_index, returning Infinity if unterminated.

For backticks the whole input is searched (template literals may span newlines); for ' and " the searched text is cut at the first newline from search_start_index — if no newline exists, infinity_if_negative makes the slice run to the end, keeping indexes valid in the original string. The actual scan is delegated to find_unescaped_char with the quote char.

calls: [infinity_if_negative](r2-parse.md#u-edd9bb8ecede), [find_unescaped_char](r2-parse.md#u-e7db0acb2cbc)

**Uncertainties.**

- ${...} interpolations in backtick strings are not special-cased here; a quote inside one would terminate the scan.

<a id="u-e7db0acb2cbc"></a>
### `find_unescaped_char`

`function find_unescaped_char(string, search_start_index, char)` · [packages/svelte/src/compiler/phases/1-parse/utils/bracket.js:L52-L64][f3]

Scans for the first occurrence of char not escaped by a backslash.

Loop: indexOf from i; -1 returns Infinity; an occurrence is unescaped only when count_leading_backslashes immediately before it is even; odd counts mean escaped, so the search resumes at found_index + 1. Returns the index of the accepted occurrence; terminates only via return.

calls: [count_leading_backslashes](r2-parse.md#u-29a08a302323)

<a id="u-edd9bb8ecede"></a>
### `infinity_if_negative`

`function infinity_if_negative(num)` · [packages/svelte/src/compiler/phases/1-parse/utils/bracket.js:L8-L13][f3]

Maps a negative number to Infinity, otherwise returns the input unchanged.

Single branch: num < 0 yields Infinity, else num. Used to turn a failed indexOf (-1) into a 'not found' sentinel when computing slice/advance positions.

<a id="u-cf3966ee18ec"></a>
### `match_bracket`

`export function match_bracket(parser, start, brackets = default_brackets)` · [packages/svelte/src/compiler/phases/1-parse/utils/bracket.js:L149-L180][f3]

Balanced-bracket matcher over parser.template from start, returning the index just past the closer that empties the stack.

Quotes are skipped via match_quote, which recurses back here for `${` in backtick strings. Keys of the brackets map (default default_brackets) push onto a stack; a char among the map's values pops the stack and compares against the expected closer — mismatch throws e.expected_token(i - 1, expected); an empty stack after the pop returns i. Reaching end of template with brackets still open throws e.unexpected_eof(parser.template.length).

**Notes.**

- failure: Mismatched closer raises expected_token at the closer's index; EOF with unclosed brackets raises unexpected_eof at template length.

calls: [match_quote](r2-parse.md#u-bc749ce8d7ac); uses: [find_matching_bracket](r2-parse.md#u-3e5597267416)

**Uncertainties.**

- A closer encountered while the stack is empty pops undefined; brackets[undefined] is undefined, so the comparison path would throw expected_token — implied by the cast, not exercised in visible source.

<a id="u-bc749ce8d7ac"></a>
### `match_quote`

`function match_quote(parser, start, quote)` · [packages/svelte/src/compiler/phases/1-parse/utils/bracket.js:L187-L213][f3]

Consumes a quoted literal in parser.template starting at start and returns the index of the closing quote.

A backslash sets is_escaped so the next character can never close the string. In backtick strings, `${` recurses into match_bracket to skip the interpolation body, so quotes inside interpolations do not end the literal. If template ends first, e.unterminated_string_constant(start) throws.

**Notes.**

- failure: Unterminated string raises unterminated_string_constant positioned at start, not at EOF.

calls: [match_bracket](r2-parse.md#u-cf3966ee18ec)

<a id="u-a03f13997ae5"></a>
### `decode_character_references`

`export function decode_character_references(html, is_attribute_value)` · [packages/svelte/src/compiler/phases/1-parse/utils/html.js:L40-L66][f4]

Replaces HTML character references in `html` with their Unicode characters, selecting the attribute-value or content pattern by is_attribute_value.

The replacement callback resolves the captured entity: names not starting with '#' look up the entities map; '#x…' parses hex; '#…' parses decimal. If the resolved code point is falsy (0/NaN), the original match is returned unchanged; otherwise the character is produced via String.fromCodePoint(validate_code(code)), so illegal code points become NUL or whitespace per validate_code. Pattern objects are shared and stateful ('g' flag), but replace resets lastIndex per call.

calls: [validate_code](r2-parse.md#u-93702e15ee48)

**Uncertainties.**

- Undefined entity keys would yield undefined code and fall into the falsy no-op branch; named entities are assumed present in entities.js.

<a id="u-9eba4a60cf55"></a>
### `get_entity_pattern`

`function get_entity_pattern(is_attribute_value)` · [packages/svelte/src/compiler/phases/1-parse/utils/html.js:L22-L31][f4]

Builds the global regex used for entity decoding: alternation of numeric references `#(?:x[a-fA-F\d]+|\d+)(?:;)?` and all keys of the entities map, each shaped by reg_exp_entity according to is_attribute_value.

The two variants are precomputed once at module load as entity_pattern_content and entity_pattern_attr_value.

calls: [reg_exp_entity](r2-parse.md#u-f66ddc0a405e)

**Uncertainties.**

- Longest-match behavior among the thousands of joined entity alternatives depends on key ordering in entities.js, not visible here.

<a id="u-f66ddc0a405e"></a>
### `reg_exp_entity`

`function reg_exp_entity(entity_name, is_attribute_value)` · [packages/svelte/src/compiler/phases/1-parse/utils/html.js:L12-L19][f4]

Adapts a named-entity key into a regex-source fragment per the HTML spec's named-character-reference rules: in attribute values, an entity name not ending in ';' is emitted as `name\b(?!

=)` — expressed as `${entity_name}\b(?!=)` — so it matches only when not followed by '='. Otherwise the name is used verbatim (it always matches, optionally consuming its ';').

<a id="u-93702e15ee48"></a>
### `validate_code`

`function validate_code(code)` · [packages/svelte/src/compiler/phases/1-parse/utils/html.js:L79-L127][f4]

Maps a numeric character-reference code point to a safe replacement, following HTML's illegal-code-point rules.

Distinct ranges: 10 (line feed) becomes 32 (space); 0–127 passes through; 128–159 remaps through the windows_1252 table (so e.g. &#128; yields €); 55296–57343 (UTF-16 surrogate halves) and any code point outside the listed acceptable planes become NUL (0); all other basic-multilingual, supplementary, and special-purpose-plane ranges listed pass through unchanged.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/1-parse/index.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/1-parse/state/text.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/1-parse/utils/bracket.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/1-parse/utils/html.js
