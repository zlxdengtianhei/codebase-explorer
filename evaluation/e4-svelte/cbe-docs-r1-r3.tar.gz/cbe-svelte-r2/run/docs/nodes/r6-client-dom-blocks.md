# DOM Template Blocks

**Capability.** Renders template-level constructs at anchors: raw {@html} (with dev hydration hash check), keyed blocks, named slots, snippets (including raw and dev-wrapped), CSS custom properties, plus the HTML-to-fragment reconciler entry.

Use to understand how blocks and snippets materialize in the DOM. html and createRawSnippet both go through create_fragment_from_html in the reconciler.

**Depends on.**

- [Task Scheduling](r6-client-dom-task.md) · model-inferred · 0 edge(s)
- [Client Reactivity Core](r6-client-reactivity.md) · model-inferred · 0 edge(s)
- [Effect Engine](r3-effects-engine.md) · graph-only · 10 edge(s)
- [Client Runtime DOM](r5-runtime-dom.md) · graph-only · 10 edge(s)

Parent: [Client Runtime](r6-runtime-client.md)

## Units (10)

<a id="u-c71adbe36cde"></a>
### `css_props`

`export function css_props(element, get_styles)` · [packages/svelte/src/internal/client/dom/blocks/css-props.js:L11-L29][f1]

Keeps a div or g element's inline CSS custom properties in sync with a reactive style record.

During hydration it advances the hydrate node past the element's first child; a render effect then reads the styles and, per key, sets the property when the value is truthy and removes it otherwise.

calls: [set_hydrate_node](r1-client-runtime.md#u-053b251d50dd), [effects.js-effect-creators](r3-effects-engine.md#u-27c9c7c4069f)

<a id="u-72a5d8905202"></a>
### `html`

`export function html(node, get_value, svg = false, mathml = false, skip_warning = false)` · [packages/svelte/src/internal/client/dom/blocks/html.js:L44-L119][f2]

Renders a reactive string as raw HTML anchored at a node, replacing previously rendered nodes on change.

A template effect skips work when the value is unchanged (coalescing null to ''); when it changes it first removes the effect's existing DOM (nodes_start to nodes_end) and resets both to null, returning early if the new value is empty. During hydration it consumes server comments up to the empty-comment terminator, warning and throwing HYDRATION_ERROR if none exists, and in DEV without skip_warning checks the server hash via check_hash; it then assigns nodes and repositions the anchor. Otherwise it wraps the value in <svg> or <math> when those flags are set, parses it with create_fragment_from_html (so scripts are not executed), unwraps the wrapper element for svg/mathml, assigns first/last children, and inserts before the anchor.

**Notes.**

- condition: During hydration no attempt is made to repair server/client mismatches; content is taken from the DOM between the comment markers.
- side_effect: effect.nodes_start/nodes_end on the active effect are cleared and reassigned via assign_nodes as the block's DOM boundaries.

calls: [check_hash](r6-client-dom-blocks.md#u-1df4a5c06d12), [create_fragment_from_html](r6-client-dom-blocks.md#u-f51e86a3ef3c), [assign_nodes](r3-dom-template-factories.md#u-081194bea535)

**Uncertainties.**

- The exact failure mode when parsed HTML has no children is not guarded here; assign_nodes is called with whatever get_first_child/lastChild return.

<a id="u-1df4a5c06d12"></a>
### `check_hash`

`function check_hash(element, server_hash, value)` · [packages/svelte/src/internal/client/dom/blocks/html.js:L20-L34][f2]

In development, warns when hydrated {@html} content's server hash does not match the client value.

It returns early if there is no server hash or it matches hash(String(value ?? '')). Otherwise it builds a location string from the element's __svelte_meta loc, or from the current dev component's FILENAME, and emits a hydration_html_changed warning with the sanitized location.

calls: [hash](r5-compiler-utilities.md#u-a8a8fa6d6333)

**Uncertainties.**

- __svelte_meta is read via a ts-expect-error cast; its presence depends on DEV instrumentation elsewhere.

<a id="u-25a3a4f1f827"></a>
### `packages/svelte/src/internal/client/dom/blocks/key.js:key`

`export function key(node, get_key, render_fn)` · [packages/svelte/src/internal/client/dom/blocks/key.js:L18-L39][f3]

Re-renders a keyed block whenever its key changes, pausing the previous render and deferring commit when appending is deferred.

After optional hydrate_next, a block effect compares the previous key to the new one using not_equal in runes mode or safe_not_equal otherwise; on change it either renders into an offscreen document fragment with a text anchor (when should_defer_append) or directly at the anchor, committing immediately or via a current_batch callback. commit pauses the old effect, re-inserts any offscreen fragment after removing its text anchor, and promotes the pending effect. After setup, hydration moves the anchor to hydrate_node.

calls: [packages/svelte/src/internal/client/reactivity/effects.js:block](r3-effects-engine.md#u-75d755e7c63c), [is_runes](r2-component-context.md#u-71aba13a168a)

**Uncertainties.**

- Which equality semantics apply depends on is_runes(), defined outside this file.

<a id="u-16ae26a1cb4b"></a>
### `sanitize_slots`

`export function sanitize_slots(props)` · [packages/svelte/src/internal/client/dom/blocks/slot.js:L36-L44][f4]

Builds a record marking which slots are present: default is set when props.children is truthy, and every key in props.$$slots is set to true.

<a id="u-0553de12b651"></a>
### `slot`

`export function slot(anchor, $$props, name, slot_props, fallback_fn)` · [packages/svelte/src/internal/client/dom/blocks/slot.js:L10-L30][f4]

Renders a named slot's content or its fallback at a comment anchor.

During hydration it advances first. The slot function is looked up in $$props.$$slots[name]; if it is true (snippet interop) it is taken from props.children for the default slot or props[name], and the props are passed as a getter instead of directly. If no slot function exists, fallback_fn is invoked when non-null; otherwise slot_fn is called with the anchor and slot_props.

calls: [hydrate_next](r1-client-runtime.md#u-83058186182e)

<a id="u-2edc4e7a14f5"></a>
### `createRawSnippet`

`export function createRawSnippet(fn)` · [packages/svelte/src/internal/client/dom/blocks/snippet.js:L89-L119][f5]

Turns a render/setup factory into a programmatic snippet function.

When invoked, it calls fn with getter params to get {render, setup?}. While hydrating, the element is the current hydrate_node and hydration advances; otherwise the trimmed render() HTML is parsed with create_fragment_from_html, its first child is taken as the element (warning in DEV if there are extra siblings or it is not an element node) and inserted before the anchor. setup is then called with the element, assign_nodes marks the element as both start and end, and a function return value from setup is registered as teardown of the active effect.

**Notes.**

- failure: No validation of render() output occurs outside DEV; a fragment with no element would make element null/undefined downstream.

calls: [create_fragment_from_html](r6-client-dom-blocks.md#u-f51e86a3ef3c), [assign_nodes](r3-dom-template-factories.md#u-081194bea535), [effects.js-effect-creators](r3-effects-engine.md#u-27c9c7c4069f)

<a id="u-398a190f3765"></a>
### `snippet`

`export function snippet(node, get_snippet, ...args)` · [packages/svelte/src/internal/client/dom/blocks/snippet.js:L27-L55][f5]

Renders a snippet at an anchor and swaps the rendered branch when the snippet function identity changes.

Inside an EFFECT_TRANSPARENT block, if get_snippet() returns the same function as before nothing happens; otherwise the previous snippet effect is destroyed, an invalid_snippet error is raised in DEV when the new snippet is null/undefined, and a new branch runs the snippet with the anchor and args. After setup, hydration moves the anchor to hydrate_node. The initial snippet is noop so the first pass always renders.

calls: [packages/svelte/src/internal/client/reactivity/effects.js:block](r3-effects-engine.md#u-75d755e7c63c), [effects.js-effect-creators](r3-effects-engine.md#u-27c9c7c4069f)

**Uncertainties.**

- e.invalid_snippet() in DEV is assumed to throw; its control-flow effect on the subsequent branch call is not visible here.

<a id="u-4a27c635b68b"></a>
### `wrap_snippet`

`export function wrap_snippet(component, fn)` · [packages/svelte/src/internal/client/dom/blocks/snippet.js:L63-L64][f5]

Wraps a snippet function for development so it runs with the owning component's dev context and rejects stringification.

The wrapper saves dev_current_component_function, sets it to component, calls fn, and restores the previous value in finally; prevent_snippet_stringification is applied to the wrapper before returning it.

calls: [prevent_snippet_stringification](r1-shared-internals.md#u-f0c8633de633)

<a id="u-f51e86a3ef3c"></a>
### `create_fragment_from_html`

`export function create_fragment_from_html(html)` · [packages/svelte/src/internal/client/dom/reconciler.js:L2-L6][f6]

Parses an HTML string into a DocumentFragment by assigning it to a detached template element's innerHTML, replacing every `<!>` with `<!---->` for XHTML compliance, then returning the template's content.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/blocks/css-props.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/blocks/html.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/blocks/key.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/blocks/slot.js
[f5]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/blocks/snippet.js
[f6]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/reconciler.js
