# Shared Assignment Rewriting

**Capability.** Shared helper that rewrites assignment expressions whose left side is reactive-capable, used by both client and server transforms so assignment semantics stay consistent.

Change this node when reactive assignment semantics change; both transform backends depend on it.

**Depended on by.**

- [Client Transform Visitors](r1-compiler-transform-client.md) · model-inferred · 0 edge(s)
- [Server Transform \(SSR\)](r1-compiler-transform-server.md) · graph-confirmed · 1 edge(s) · The server transform reuses the shared assignment rewriter so reactive assignment semantics match the client target.

Parent: [Transform Phase](r1-compiler-transform.md)

## Units (1)

<a id="u-b43a982ab161"></a>
### `visit_assignment_expression`

`export function visit_assignment_expression(node, context, build_assignment)` · [packages/svelte/src/compiler/phases/3-transform/shared/assignments.js:L15-L93][f1]

Shared helper that rewrites assignment expressions whose left side is reactive-capable.

For destructuring targets (ArrayPattern, ObjectPattern, RestElement) it visits the right side, caches it in `$$value` when it is not a plain Identifier, extracts insert declarations and assignment paths via extract_paths (generating `$$array` names for inserts), and builds an assignment per path through the caller's build_assignment; if build_assignment returns null for every path (no reactive change), the original assignment is kept by returning null. Otherwise, if inserts or caching are needed it wraps everything in an arrow IIFE called with the value, ending with `return $$value` when the assignment is part of an expression (parent path type ends with 'Statement' determines standalone-ness), and awaits the call when the value or any built assignment is async; otherwise it returns a comma sequence, again ending with the cached value in expression position. For Identifier or MemberExpression targets it delegates directly to build_assignment with the original operator; any other left type throws `Unexpected assignment type`.

**Notes.**

- condition: Returning null is a contract signal to the caller that no transformation is needed
- failure: Non-destructuring, non-Identifier, non-MemberExpression left sides throw

calls: [extract_paths](r5-compiler-utilities.md#u-34f2fcb20c62), [is_expression_async](r5-compiler-utilities.md#u-88399029ef9f)

**Uncertainties.**

- get_value is imported but not referenced in this excerpt's visible body

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/shared/assignments.js
