# Benchmark Harness

**Capability.** Measures and compares execution timing of candidate implementations, forcing GC and correlating wall-clock time with GC activity, plus small file/assert helpers used by the driver.

Use this subtree to understand how benchmarks are run and timed. run.js drives suites; utils.js supplies timing, GC tracking, and file utilities. Internal edges (fastest_test→run_tracked→run_timed/GarbageTrack) are all local to this node.

**Depended on by.**

- [Reactivity Benchmarks](r6-benchmarking.md) · graph-only · 14 edge(s)
- [Reactivity and SSR Benchmarks](r5-benchmarks.md) · graph-only · 11 edge(s)
- [Reactivity Benchmarks](r1-tooling-benchmarks.md) · graph-only · 9 edge(s)

Parent: [Svelte Codebase](r4-svelte-codebase.md)

## Units (11)

<a id="u-8a0ea15faff6"></a>
### `run.js module code (L1–L55)`

`module_region` · [benchmarking/run.js:L1-L55][f1]

Top-level driver that runs all benchmark suites sequentially and prints aggregated timings.

It pushes an empty reaction root onto the Svelte client runtime ($ .push({}, true)) before iterating the two suites (reactivity, SSR); for each benchmark it awaits the benchmark callable and accumulates results.time and results.gc_time (coerced with Number) into suite and total counters. Any thrown error inside the loop is caught, logged as 'Benchmarking Failed' with console.error, and terminates the process with exit code 1. On success it pops the reaction root and logs suite and total times formatted with toFixed(2).

**Notes.**

- side_effect: Top-level await: module execution blocks on each benchmark and writes to stdout/stderr; process.exit(1) on failure.
- contract: Each benchmark is expected to be an async function returning an object with numeric-coercible time and gc_time properties.

uses: [fastest_test](r4-benchmark-harness.md#u-0bbe8c671495), [assert](r4-benchmark-harness.md#u-823bd0dd0cd8)

**Uncertainties.**

- The exact return shape of each benchmark callable is inferred from field access (results.time, results.gc_time), not from a visible definition.

<a id="u-b7717abe1fed"></a>
### `GarbageTrack`

`class GarbageTrack` · [benchmarking/utils.js:L8-L14][f2]

Tracks wall-clock measurement periods and correlates them with garbage-collection entries reported by the Node performance observer.

On construction it starts observing 'gc' entry types, appending every GC entry to an internal list; watch records a timed period with a monotonically increasing track id; gcDuration asynchronously sums the durations of GC entries falling inside that period; destroy disconnects the observer. Field initialization order matters: the observer callback pushes into this.perf_entries, which is declared after the observer field, so entries arriving before field initialization would fail — in practice entries only arrive after observe() is called in the constructor.

**Uncertainties.**

- The parser emitted multiple class fragments (s0, s1, s4); this unit covers the whole class lines 8–49 including all listed methods.

<a id="u-823bd0dd0cd8"></a>
### `assert`

`export function assert(a)` · [benchmarking/utils.js:L96-L100][f2]

Throws new Error('Assertion failed') when the argument is falsy; otherwise returns undefined.

Exported and used by kairo benchmark setup.run code per graph evidence.

<a id="u-0bbe8c671495"></a>
### `fastest_test`

`export async function fastest_test(times, fn)` · [benchmarking/utils.js:L82-L91][f2]

Runs fn `times` times via run_tracked, collecting each { result, timing } and returning the run with the smallest timing.time using a reduce comparison.

Each run includes forced GC and GC-time measurement from run_tracked. If any run or the gcDuration await rejects, the rejection propagates to the caller. Exported; used by kairo benchmark functions per graph evidence.

calls: [run_tracked](r4-benchmark-harness.md#u-cd205b57d6f7)

<a id="u-3308e4a46f8a"></a>
### `promise_delay`

`function promise_delay(timeout = 0)` · [benchmarking/utils.js:L51-L53][f2]

Returns a promise resolved after the given timeout in milliseconds via setTimeout; defaults to 0.

<a id="u-19c8243b4a22"></a>
### `read_file`

`export function read_file(file)` · [benchmarking/utils.js:L105-L107][f2]

Synchronously reads a file as UTF-8 and normalizes CRLF line endings to LF before returning the string.

<a id="u-52eb06b944b0"></a>
### `run_timed`

`function run_timed(fn)` · [benchmarking/utils.js:L58-L63][f2]

Runs fn synchronously and returns { result, time } where time is the elapsed performance.now delta around the call.

Exceptions from fn propagate before any timing is returned.

<a id="u-cd205b57d6f7"></a>
### `run_tracked`

`async function run_tracked(fn)` · [benchmarking/utils.js:L68-L76][f2]

Measures one run of fn, forcing a full GC beforehand and reporting the GC time during the run.

It calls v8.collectGarbage(), creates a fresh GarbageTrack (whose constructor starts gc observation), and uses watch to time run_timed(fn), obtaining a track_id. It awaits gcDuration(track_id); if no period was recorded (e.g. watch threw) that rejection propagates. It then unwraps the inner { result, time }, calls destroy() to disconnect the observer, and returns { result, timing: { time, gc_time } }. The temporary GarbageTrack leaks if gcDuration rejects before destroy.

uses: [GarbageTrack](r4-benchmark-harness.md#u-b7717abe1fed); calls: [run_timed](r4-benchmark-harness.md#u-52eb06b944b0)

**Uncertainties.**

- v8.collectGarbage availability/behavior depends on the v8-natives package; not visible here.

<a id="u-ccb2ac8173a1"></a>
### `write`

`export function write(file, contents)` · [benchmarking/utils.js:L113-L119][f2]

Writes contents to a file, first creating its directory recursively; mkdir errors are swallowed by an empty catch, and a subsequent writeFileSync failure propagates.

**Notes.**

- failure: Any fs.mkdirSync error is intentionally ignored; only fs.writeFileSync errors surface.

<a id="u-8c65a064a6ec"></a>
### `GarbageTrack.gcDuration`

`async gcDuration(track_id)` · [benchmarking/utils.js:L27-L40][f2]

Asynchronously computes total GC time attributable to a recorded period.

It awaits promise_delay(10) first, giving the performance observer time to deliver GC entries, then finds the period matching the given track_id. If none exists, it returns a rejected promise with the string 'no period found' (non-Error rejection). Otherwise it filters perf_entries whose startTime lies in [period.start, period.end) and reduces their durations to a sum, which resolves the returned promise.

**Notes.**

- failure: Rejection value is a string, not an Error, per the eslint-disable comment.

calls: [promise_delay](r4-benchmark-harness.md#u-3308e4a46f8a)

<a id="u-8e277c6f1d2c"></a>
### `GarbageTrack.watch`

`watch(fn)` · [benchmarking/utils.js:L14-L22][f2]

Runs fn synchronously inside a measured period and assigns it the next track id.

It increments track_id, captures performance.now before and after the synchronous call, and pushes { track_id, start, end } into periods. Returns { result, track_id } so the caller can later request the GC time for that id. If fn throws, no period is pushed and the exception propagates.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/benchmarking/run.js
[f2]: ../../../../../../eval/svelte-be645b4/benchmarking/utils.js
