# Scope and Node Model

**Capability.** Shared compiler infrastructure: the lexical scope tree (Scope, ScopeRoot, Binding, Evaluation, rune detection) and AST node helpers/metadata factories consumed by every later phase.

Read this subtree before any visitor or transform code: bindings, rune resolution (get_rune), and expression metadata all originate here. It is a dependency of analysis, a11y checks, and both transform passes, so changes here ripple widely.

**Depends on.**

- [Compiler Utilities and AST Helpers](r5-compiler-utilities.md) · graph-only · 14 edge(s)

**Depended on by.**

- [Accessibility Checks](r3-a11y-checks.md) · model-inferred · 0 edge(s)
- [Component Analysis](r3-analysis-core.md) · graph-confirmed · 16 edge(s) · Component analysis dispatches over scopes and bindings created by the scope/node model, which also feeds a11y checks and both transform passes.
- [Client Transform](r3-client-transform.md) · graph-confirmed · 9 edge(s)
- [Server Transform](r3-server-transform.md) · graph-confirmed · 7 edge(s)
- [Template Parsing \(Phase 1\)](r4-template-parsing.md) · graph-only · 11 edge(s)
- [Client Transform](r6-transform-client.md) · graph-only · 11 edge(s)

Parent: [Compiler](r3-compiler.md)

## Units (14)

<a id="u-cbb081ea695c"></a>
### `scope.js-create-scopes-visitor`

`export function create_scopes(ast, root, allow_reactive_declarations, parent)` · [packages/svelte/src/compiler/phases/scope.js:L838-L868][f1]

create_scopes walks the AST with zimmerframe to build the scope tree: it creates a non-porous root Scope, collects identifier references, assignment/update targets, and `$:` implicit declarations during the walk, then post-processes them so declarations are registered before references are attached.

Returned object: `{ has_await, scope, scopes }`, where has_await becomes true if an AwaitExpression appears outside any function (an ArrowFunctionExpression/FunctionExpression/FunctionDeclaration anywhere in the path prevents it) — a side channel used to opt into runes mode. Helper visitors: add_params declares each extracted parameter identifier as 'param' (or 'rest_param' for RestElement); create_block_scope pushes a porous child scope (used for For/ForIn/ForOf/Switch and BlockStatement unless the block is a function body, which already has its own scope); SvelteFragment (shared by SlotElement/SvelteElement/RegularElement) pushes a non-porous child. Component-like nodes reference the component name, store a default child scope in metadata.scopes, and give each slotted child (determine_slot hit) its own named scope; LetDirective attributes are visited in the default state. SvelteDirective visitors (Transition/Animate/Use) reference the directive name's first dot-segment and visit any expression. Identifier records only genuine references (is_reference) that are not TS-parent nodes. LabeledStatement creates a scope for top-level `$:` labels when allow_reactive_declarations, collecting non-`$`-prefixed assignment targets as possible implicit declarations, later declared as 'legacy_reactive' if no binding exists. LetDirective declares destructured or plain names as 'template'/'const' bindings with references. AssignmentExpression/UpdateExpression/BindDirective collect left-hand sides as updates. ImportDeclaration declares specifiers as 'import'. Function declarations/expressions/arrows create scopes; FunctionExpression declares its own id inside, FunctionDeclaration declares it outside with itself as initial; parameters via add_params. ClassDeclaration declares as 'let'. VariableDeclaration declares each identifier as 'normal' (or 'template' under a ConstTag) with the declarator's kind and init, registering bindings in scope.declarators. CatchClause makes a porous scope for its param when present. EachBlock visits the expression, then declares context identifiers as 'each'/'const' (computing per-binding inside_rest metadata by walking the context), the index as 'static' unless the key expression is not the index identifier (then 'template'), visits children in the new scope, and fills metadata including a unique `$$index` name from root. AwaitBlock declares value/error identifiers as 'template' in the then/catch scopes and 'normal' in dedicated value/error scopes. SnippetBlock declares the snippet expression name as 'function' and parameters as 'snippet'/'let' in a child scope. Fragment uses a porous child when metadata.transparent. StyleDirective references the name only for the shorthand form (`value === true`), e.g. `<button style:height />`, since explicit values are already handled by Identifier. Post-passes: implicit declarations become legacy_reactive bindings; collected references are applied via scope.reference; collected updates unwrap patterns and, when a binding is found whose node differs from the target expression, mark `reassigned` for direct targets or `mutated` for member accesses.

uses: [Scope](r3-scope-node-model.md#u-01a82e58170d), [ScopeRoot](r3-scope-node-model.md#u-8f49475011d6); calls: [create_expression_metadata](r3-scope-node-model.md#u-32bbb434f744), [extract_identifiers](r5-compiler-utilities.md#u-90eb95affc00), [determine_slot](r2-compiler-infrastructure.md#u-ead26eb5b43f), [unwrap_pattern](r5-compiler-utilities.md#u-73018823c866)

**Uncertainties.**

- Visitor dispatch order and which nodes reach Identifier depend on zimmerframe internals not shown here.
- extract_identifiers/extract_identifiers_from_destructuring/object/unwrap_pattern semantics are established in ast.js, not this file.
- The has_await runes-mode opt-in is only described by a comment; downstream consumption is not visible here.

<a id="u-01a82e58170d"></a>
### `Scope`

`class Scope` · [packages/svelte/src/compiler/phases/scope.js:L564-L618][f1]

Tracks declared names and their references for one lexical region, linked to a parent Scope and a shared ScopeRoot.

The constructor sets function_depth to parent+1 for non-porous scopes and the parent's depth for porous ones, so block scopes do not increase depth. `declare` hoists `var` declarations out of porous scopes and `import` declarations always to the root's parent chain; once it lands, a duplicate non-`var`/non-`var` pair raises e.declaration_duplicate, the identifier is validated via validate_identifier_name, the Binding is stored by name, and the name is added to root.conflicts. `child(porous)` creates a nested scope. `generate` sanitizes the preferred name (invalid characters become `_`, leading digits become `_`) and appends `_1`, `_2`, … until the name is unused in this scope's references/declarations, root.conflicts, and not a reserved word, then registers it. `get`/`owner` walk up the parent chain. `get_bindings` throws 'No binding found for declarator' when a declarator was never registered. `reference` copies the path (later path mutations cannot affect stored references), appends to this scope's references map, and either records the reference on the local binding, delegates to the parent, or — at the top level with no binding — adds the name to root.conflicts as a global. `evaluate` returns a cached Evaluation for a re-entrant expression or builds a new one; its docstring warns results are wrong if scopes are not fully generated first.

uses: [Binding](r3-scope-node-model.md#u-0c91df12a429), [Evaluation](r3-scope-node-model.md#u-006193dba8b7), [scope.js module code (L757–L809)][f1]

**Uncertainties.**

- declare calls e.declaration_duplicate and validate_identifier_name, whose full behaviors live in other files.
- Whether var-hoisting terminates depends on the root scope being non-porous; the root's construction is outside this file.

<a id="u-8f49475011d6"></a>
### `ScopeRoot`

`class ScopeRoot` · [packages/svelte/src/compiler/phases/scope.js:L810-L817][f1]

Per-compilation root holding a global `conflicts` set of names that must stay unique.

`unique(preferred_name)` sanitizes the name (invalid characters become `_`), then appends `_1`, `_2`, … while the name is in conflicts, adds the chosen name to conflicts, and returns a built identifier node (b.id). Unlike Scope.generate it does not check declarations or reserved words, only the conflicts set.

uses: [scope.js module code (L830–L837)][f1]

<a id="u-0c91df12a429"></a>
### `Binding`

`class Binding` · [packages/svelte/src/compiler/phases/scope.js:L88-L140][f1]

Represents a single declared name: its scope, declaring identifier, binding/declaration kind, initializer, and all references found to it.

The constructor only stores the five arguments; `initial` defaults to null and reference/mutation lists start empty. The `updated` getter returns true when either `mutated` or `reassigned` was set (scope.js marks these when processing assignments, updates, and bind directives). `is_function()` returns true only when the binding was never updated and its initial value is an ArrowFunctionExpression, FunctionExpression, or FunctionDeclaration; any mutation or reassignment forces false, since a reassigned name cannot be used directly as e.g. an event handler. Fields like prop_alias, legacy_dependencies, and metadata are populated by later analysis phases, not by this class itself.

**Uncertainties.**

- Whether `mutated`/`reassigned` are set correctly for every syntax form depends on create_scopes' update collection, not on this class.

<a id="u-006193dba8b7"></a>
### `Evaluation`

`class Evaluation` · [packages/svelte/src/compiler/phases/scope.js:L172-L230][f1]

Partially evaluates an expression against a Scope into a set of possible values plus derived flags (is_known, has_unknown, is_defined, is_string, is_number, is_function, value).

All behavior lives in the constructor, which registers the evaluation in a module-level `current_evaluations` map so cyclic evaluations return the existing Evaluation instead of recursing infinitely, then switches on expression type. Literal adds its value. Identifier: a binding whose initial is a `$props.id()` rune call yields STRING; an EachBlock index binding yields NUMBER; an un-updated, non-prop binding with an initial value recursively evaluates that initial; the bare global `undefined` adds undefined; anything else (props, rest props, bindable props, imports, mutated bindings) adds UNKNOWN. BinaryExpression evaluates both sides: if both known the operator is applied exactly; otherwise comparison/equality operators yield {true,false}, arithmetic operators yield NUMBER, `+` yields STRING or NUMBER (both when either side is untyped), default UNKNOWN. ConditionalExpression yields the taken branch's values when the test is known, else the union of both branches. LogicalExpression applies the operator exactly when both sides are known; with a known left it short-circuits (`&&` with falsy left, `||` with truthy left, `??` with non-nullish left keep the left value, else take the right's values); with unknown left it unions both sides. UnaryExpression applies the operator when its argument is known, else `!`/`delete` yield {false,true}, `+`/`-`/`~` yield NUMBER, `typeof` yields STRING, `void` yields undefined, default UNKNOWN. CallExpression resolves a global keypath: rune calls get special values ($state/$state.raw/$derived evaluate their argument or undefined when absent; $props.id is STRING; $effect.tracking is {false,true}; $derived.by evaluates a concise arrow body else UNKNOWN; other runes UNKNOWN); a known entry in `globals` with no spread arguments is applied exactly when all evaluated args are known, else typed by its declared symbol; unresolved callees are UNKNOWN. TemplateLiteral concatenates cooked quasis with evaluated expressions, degrading to STRING when any expression is unknown. MemberExpression yields the value of a global constant (Math.PI etc.) or UNKNOWN; function nodes yield the FUNCTION symbol; default is UNKNOWN. Afterwards each value drives the flags: non-string values clear is_string, non-numbers clear is_number, non-FUNCTION values clear is_function, null/UNKNOWN clear is_defined, UNKNOWN sets has_unknown; more than one value or a symbol value sets is_known false. The entry is finally removed from current_evaluations.

uses: [Scope](r3-scope-node-model.md#u-01a82e58170d), [scope.js module code (L757–L809)][f1]; calls: [get_global_keypath](r3-scope-node-model.md#u-7baae8d843b4), [get_rune](r3-scope-node-model.md#u-5204b6ce4f7a)

**Uncertainties.**

- STRING/NUMBER/FUNCTION are Symbols, so the type flags are conservative approximations, not proofs about actual values.
- No error handling: applying binary/unary operators to known values (e.g. `in` on a non-object) could throw at compile time; none is specified in this file.

<a id="u-7baae8d843b4"></a>
### `get_global_keypath`

`function get_global_keypath(node, scope)` · [packages/svelte/src/compiler/phases/scope.js:L1359-L1382][f1]

Builds a dotted keypath string for a global reference, or returns null.

It walks MemberExpressions accumulating `.prop` segments (returning null on computed access or non-Identifier properties), optionally consumes one CallExpression layer (appending '()' for e.g. `Math.min(...)` with an Identifier callee), and requires the chain to bottom out at an Identifier. If that identifier resolves to a local binding in the scope, it returns null — a shadowed name is not a global. Otherwise it returns the identifier name plus the accumulated suffix, e.g. 'Math.min()' or 'console.log'.

calls: [Scope](r3-scope-node-model.md#u-01a82e58170d)

<a id="u-5204b6ce4f7a"></a>
### `get_rune`

`export function get_rune(node, scope)` · [packages/svelte/src/compiler/phases/scope.js:L1344-L1352][f1]

Returns the rune name (e.g. '$derived') if the node is a CallExpression whose callee resolves to a rune keypath, else null.

Null/non-CallExpression inputs return null; the callee keypath must also pass is_rune, and a keypath that names a locally-bound variable is rejected inside get_global_keypath.

calls: [get_global_keypath](r3-scope-node-model.md#u-7baae8d843b4), [utils.js-namespace-and-rune-predicates](r5-compiler-utilities.md#u-c266f2d1e7a9)

<a id="u-2bb6e1e761ba"></a>
### `set_scope`

`export function set_scope(node, { next, state })` · [packages/svelte/src/compiler/phases/scope.js:L1334-L1337][f1]

Visitor helper that re-targets the traversal scope for the current node: it looks the node up in state.scopes and, when a different scope exists there, continues (next) with a copied state using that scope; otherwise it continues with the unchanged state.

Nodes without a mapped scope keep the enclosing scope.

<a id="u-16d11cbbd59b"></a>
### `create_attribute`

`export function create_attribute(name, start, end, value)` · [packages/svelte/src/compiler/phases/nodes.js:L54-L66][f2]

Constructs a fresh AST Attribute node with the given name, source span, and value, initializing analysis metadata.

**Notes.**

- field: metadata.delegated starts null and metadata.needs_clsx starts false; each call yields a new metadata object so callers can mutate independently.

<a id="u-32bbb434f744"></a>
### `create_expression_metadata`

`export function create_expression_metadata()` · [packages/svelte/src/compiler/phases/nodes.js:L71-L81][f2]

Creates a default ExpressionMetadata record used to accumulate reference/state tracking during analysis: empty dependencies and references sets, and all boolean flags (has_state, has_call, has_member_expression, has_assignment, has_await) starting false.

<a id="u-99af92983a86"></a>
### `get_name`

`export function get_name(node)` · [packages/svelte/src/compiler/phases/nodes.js:L86-L92][f2]

Extracts a printable name from a simple expression.

Literals yield String(node.value); PrivateIdentifier yields '#'+name; Identifier yields name; any other node type returns null, so callers must handle the null case for computed or complex expressions.

<a id="u-1354bdeaaf38"></a>
### `is_component_node`

`export function is_component_node(node)` · [packages/svelte/src/compiler/phases/nodes.js:L31-L33][f2]

Reports whether an AST node is component-like: Component, SvelteComponent, or SvelteSelf.

Pure predicate over node.type with no other conditions or side effects.

<a id="u-ea1f0b51e1e8"></a>
### `is_custom_element_node`

`export function is_custom_element_node(node)` · [packages/svelte/src/compiler/phases/nodes.js:L39-L45][f2]

Detects custom elements among element nodes.

Returns true only for a RegularElement whose tag name contains a hyphen, or which has an Attribute named `is`. SvelteElement and all component nodes return false, so e.g. `<svelte:element this="my-el">` is not reported as custom here.

<a id="u-0d9a79ad394a"></a>
### `is_element_node`

`export function is_element_node(node)` · [packages/svelte/src/compiler/phases/nodes.js:L22-L24][f2]

Reports whether an AST node is one of the element-like node types that can carry attributes and children.

**Notes.**

- contract: True exactly when node.type is one of SvelteElement, RegularElement, SvelteFragment, Component, SvelteComponent, SvelteSelf, SlotElement; the type predicate is only as sound as that hardcoded list.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/scope.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/nodes.js
