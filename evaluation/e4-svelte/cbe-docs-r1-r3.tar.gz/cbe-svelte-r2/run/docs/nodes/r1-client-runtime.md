# Client Runtime

**Capability.** Browser-side runtime shared by compiled output: hydration cursor walking, DOM attribute synchronization, the rAF task loop, style injection, and boundary/async state that template code calls into.

Compiled client code calls these helpers directly. Hydration and attributes are consumed together (set_attributes consults hydration state); the loop is consumed by motion and any per-frame scheduling.

**Children.**

- [Attribute Synchronization](r1-client-attributes.md) `r1-client-attributes` · 17 unit(s)

**Depended on by.**

- [Boundaries & Async Blocks](r1-client-boundaries.md) · graph-confirmed · 5 edge(s)
- [Client Transform Visitors](r1-compiler-transform-client.md) · model-inferred · 0 edge(s)
- [Reactive Collections & Motion](r1-public-reactivity-motion.md) · graph-confirmed · 2 edge(s)
- [Reactivity Benchmarks](r1-tooling-benchmarks.md) · model-inferred · 0 edge(s)
- [Client DOM Blocks](r4-client-dom-blocks.md) · graph-only · 16 edge(s)
- [Client Runtime DOM](r5-runtime-dom.md) · graph-only · 15 edge(s)
- [Attribute Synchronization](r1-client-attributes.md) · within containment · 4 edge(s)

Parent: [Svelte Monorepo](r1-svelte-monorepo.md)

## Units (11)

<a id="u-25ab046937f2"></a>
### `append_styles`

`export function append_styles(anchor, css)` · [packages/svelte/src/internal/client/dom/css.js:L9-L32][f1]

Injects a component's CSS into the DOM once per matching root.

Inside an effect, it resolves the mount target: if the anchor's root has a host it is treated as a ShadowRoot, otherwise the head of the root (or its ownerDocument) is used. If no element with id css.hash exists in the target, a style element with that id and css.code is created and appended; in DEV it is also registered. If the style already exists, nothing is appended. The comment notes the effect wrapper ensures anchor is attached before getRootNode, and that always querying the DOM is preferred over a map cache.

calls: [css.js-style-registry](r4-client-dev-tools.md#u-c05b95719e0c)

**Uncertainties.**

- The effect's tracked dependencies are not visible here, so re-run conditions are inferred from the effect mechanism, not proven in this file.

<a id="u-83058186182e"></a>
### `hydrate_next`

`export function hydrate_next()` · [packages/svelte/src/internal/client/dom/hydration.js:L43-L45][f2]

Moves the hydrate_node cursor to its next sibling and returns the new cursor.

The sibling lookup goes through get_next_sibling, and any null result flows into set_hydrate_node's warning-and-throw path.

calls: [set_hydrate_node](r1-client-runtime.md#u-053b251d50dd), [get_next_sibling](r5-runtime-dom.md#u-21941a8e2833)

<a id="u-97c53e59acba"></a>
### `hydrate_template`

`export function hydrate_template(template)` · [packages/svelte/src/internal/client/dom/hydration.js:L63-L68][f2]

When hydrating, points the hydrate_node cursor at the template's content DocumentFragment so subsequent hydration walks inside the template's SSR output; non-hydrating calls do nothing.

uses: [hydration.js module code (L1–L19)][f2]

<a id="u-94ad8aaab7d1"></a>
### `packages/svelte/src/internal/client/dom/hydration.js:next`

`export function next(count = 1)` · [packages/svelte/src/internal/client/dom/hydration.js:L70-L81][f2]

Skips the hydrate_node cursor forward count (default 1) siblings, only while hydrating.

Each step uses get_next_sibling; unlike set_hydrate_node there is no null check in the loop, so a null result leaves the cursor null without throwing here.

calls: [get_next_sibling](r5-runtime-dom.md#u-21941a8e2833)

**Uncertainties.**

- No null guard on loop results; whether callers tolerate a null cursor is not established by this source.

<a id="u-97280e054ad7"></a>
### `read_hydration_instruction`

`export function read_hydration_instruction(node)` · [packages/svelte/src/internal/client/dom/hydration.js:L112-L119][f2]

Returns the comment data of a hydration instruction node.

If the node is missing or not a comment node, it warns via w.hydration_mismatch and throws HYDRATION_ERROR instead of returning a value.

**Notes.**

- failure: Non-comment or falsy node: warning then throw HYDRATION_ERROR.

raises: [hydration.js module code (L1–L19)][f2]

<a id="u-fc45567d72a4"></a>
### `remove_nodes`

`export function remove_nodes()` · [packages/svelte/src/internal/client/dom/hydration.js:L86-L106][f2]

Deletes server-rendered nodes from the current hydrate_node up to the matching hydration end comment, tracking nesting depth.

A comment with data HYDRATION_END at depth 0 is the boundary and is returned without removal; otherwise depth decrements. HYDRATION_START or HYDRATION_START_ELSE comments increment depth so nested blocks survive until their own end marker. All other nodes are removed from the DOM and the walk continues to the next sibling.

**Notes.**

- failure: No guard against a null sibling: a missing HYDRATION_END comment would drive the loop past the end of the document; casts hide the null.

calls: [get_next_sibling](r5-runtime-dom.md#u-21941a8e2833)

<a id="u-0157ee2cbd38"></a>
### `packages/svelte/src/internal/client/dom/hydration.js:reset`

`export function reset(node)` · [packages/svelte/src/internal/client/dom/hydration.js:L48-L58][f2]

Resets the hydrate_node cursor to a block's start node when leaving a block.

No-ops when not hydrating. If the current cursor still has a next sibling, the server markup has more content than expected, so it warns via w.hydration_mismatch and throws HYDRATION_ERROR; otherwise hydrate_node is reassigned.

**Notes.**

- failure: leftover siblings at block exit are treated as a mismatch: warning plus throw HYDRATION_ERROR.

calls: [get_next_sibling](r5-runtime-dom.md#u-21941a8e2833); uses: [hydration.js module code (L1–L19)][f2]

<a id="u-053b251d50dd"></a>
### `set_hydrate_node`

`export function set_hydrate_node(node)` · [packages/svelte/src/internal/client/dom/hydration.js:L34-L41][f2]

Advances the module-level hydrate_node cursor to the given node and returns it.

If the node is null it warns via w.hydration_mismatch and throws the HYDRATION_ERROR sentinel, so a missing expected node always aborts hydration rather than leaving a stale cursor.

**Notes.**

- failure: null input triggers w.hydration_mismatch() then throws HYDRATION_ERROR; no fallback.

uses: [hydration.js module code (L1–L19)][f2]; raises: [hydration.js module code (L1–L19)][f2]

<a id="u-dd47d7c92d42"></a>
### `set_hydrating`

`export function set_hydrating(value)` · [packages/svelte/src/internal/client/dom/hydration.js:L20-L22][f2]

Toggles the module-level hydrating flag that switches the client runtime from creating DOM to walking server-rendered markup.

uses: [hydration.js module code (L1–L19)][f2]

<a id="u-4df1fec218a0"></a>
### `loop`

`export function loop(callback)` · [packages/svelte/src/internal/client/loop.js:L32-L44][f3]

Creates a per-frame task on the shared raf schedule.

If the task set is empty it starts the frame loop with raf.tick(run_tasks). It registers a task entry { c: callback, f: fulfill } in raf.tasks and returns a Task whose promise fulfills (via f) when the callback first returns falsy, and whose abort() removes the task from the set so it never runs again. Calling abort on an already-completed task is a no-op delete since run_tasks already removed it.

uses: [run_tasks](r1-client-runtime.md#u-7667b2d6678b)

<a id="u-7667b2d6678b"></a>
### `run_tasks`

`function run_tasks()` · [packages/svelte/src/internal/client/loop.js:L9-L24][f3]

Runs one frame of raf-scheduled tasks.

It takes the timestamp from raf.now() (not the rAF callback argument, avoiding timing wonkiness), then iterates the task set: a task whose callback returns falsy is removed and its fulfillment function called, ending its promise; truthy-returning tasks persist. If any tasks remain, it schedules the next frame via raf.tick(run_tasks). Mutation of raf.tasks during iteration (adding/removing tasks from callbacks) is not guarded here.

contract: [loop](r1-client-runtime.md#u-4df1fec218a0)

**Uncertainties.**

- Whether Set iteration tolerates concurrent add/delete from task callbacks is not established by this source.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/css.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/hydration.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/loop.js
