# Async reactivity

**Capability.** Preserves and restores the ambient reactive context across awaits: context capture/unset, awaited-expression thunks, async block bodies, and dev-only reactivity-loss tracking for async deriveds and for-await loops.

Read capture, save and unset_context to see how effect/reaction/context survive await boundaries; flatten and async_body drive template and block evaluation. StaleReactionError/STALE_REACTION aborts superseded async reactions.

**Depends on.**

- [Component context](r2-component-context.md) · graph-confirmed · 3 edge(s) · Async reactivity capture/unset reads and resets component-context state and runes-mode detection across await boundaries.
- [Reactivity core](r2-reactivity-core.md) · graph-confirmed · 4 edge(s)

Parent: [Client runtime](r2-client-runtime.md)

## Units (8)

<a id="u-40a134e2a457"></a>
### `StaleReactionError`

`class StaleReactionError extends Error` · [packages/svelte/src/internal/client/constants.js:L35-L38][f1]

Instantiates an Error subclass whose instance is exported as STALE_REACTION, the rejection reason for aborted async reaction signals.

The instance carries a fixed name 'StaleReactionError' and message, so user code can match on `reason.name` to ignore aborts caused by re-run or destroyed reactions.

<a id="u-7844e4272e2c"></a>
### `async_body`

`export async function async_body(fn)` · [packages/svelte/src/internal/client/reactivity/async.js:L180-L193][f2]

Runs an async block body while marking the work as pending: calls `suspend()` to register in-flight async work, awaits `fn`, and always unsuspends in `finally`.

If `fn` rejects and the owning effect is not DESTROYED (checked with `aborted`), the error goes to `invoke_error_boundary`; errors in already-destroyed blocks are swallowed.

calls: [suspend](r4-reactivity-scheduling.md#u-aed941f29bc8), [aborted](r3-effects-engine.md#u-028f962a5fe6), [invoke_error_boundary](r3-client-error-handling.md#u-8ed809bdafb5)

<a id="u-0edcd5d2a7c1"></a>
### `capture`

`function capture()` · [packages/svelte/src/internal/client/reactivity/async.js:L72-L88][f2]

Snapshots the active effect, active reaction, component context, and current batch, returning a `restore` closure that reinstates them via the corresponding setters and re-activates the snapshot batch; in DEV it also clears async-derived tracking.

This lets code resumed after `await` register dependencies against the original effect context.

calls: [runtime.js-module-state-setters](r2-reactivity-core.md#u-ac602620d878), [context.js-dev-state-setters](r2-component-context.md#u-beb31e6973ea), [set_from_async_derived](r6-client-reactivity.md#u-7529e3342efc)

<a id="u-c50793421b66"></a>
### `flatten`

`export function flatten(sync, async, fn)` · [packages/svelte/src/internal/client/reactivity/async.js:L30-L65][f2]

Evaluates a template's sync and async expressions and invokes `fn` with all values once async ones resolve.

With no async expressions it maps each sync expression through `derived` (or `derived_safe_equal` when `is_runes()` is false) and calls `fn` synchronously. Otherwise it snapshots the effect context with `capture`, gets the pending boundary, and maps each async expression through `async_derived`; on `Promise.all` resolution it re-activates the captured batch, restores the context, and calls `fn` with the combined values. An error thrown by `fn` reaches `invoke_error_boundary` only if the parent effect lacks the DESTROYED flag; a rejection anywhere in the chain is reported via the boundary's `error`. Afterwards the batch is deactivated and the context unset.

calls: [is_runes](r2-component-context.md#u-71aba13a168a), [capture](r2-async-reactivity.md#u-0edcd5d2a7c1), [get_pending_boundary](r1-client-boundaries.md#u-662729eaf177), [invoke_error_boundary](r3-client-error-handling.md#u-8ed809bdafb5)

**Uncertainties.**

- Whether `batch?.activate()` fully determines the values read inside `fn` cannot be proven from this file alone.

<a id="u-9b4068c7d68b"></a>
### `for_await_track_reactivity_loss`

`export async function* for_await_track_reactivity_loss(iterable)` · [packages/svelte/src/internal/client/reactivity/async.js:L135-L168][f2]

Async generator backing DEV `for await` loops so reactivity-loss tracking wraps each iterator step.

It obtains an iterator via `Symbol.asyncIterator`, falling back to `Symbol.iterator`, and throws TypeError when neither exists. Each `next()` call is wrapped by `track_reactivity_loss`; a `done` result sets normal completion and ends the loop, otherwise the value is yielded. In `finally`, only on normal completion (not `break`/throw) and when `iterator.return` exists does it call `return()` through `track_reactivity_loss` and return its `.value` as the generator's return value.

**Notes.**

- failure: Non-iterable input throws TypeError before any iteration occurs.

<a id="u-183453782dc0"></a>
### `save`

`export async function save(promise)` · [packages/svelte/src/internal/client/reactivity/async.js:L98-L106][f2]

Wraps an awaited promise so the surrounding effect context survives the await: it captures context first, awaits the promise, and resolves to a thunk that restores the captured context and returns the value — the transform target for `await a + b`.

calls: [capture](r2-async-reactivity.md#u-0edcd5d2a7c1)

<a id="u-f77b77ba957d"></a>
### `track_reactivity_loss`

`export async function track_reactivity_loss(promise)` · [packages/svelte/src/internal/client/reactivity/async.js:L115-L123][f2]

Like `save`, but its returned thunk restores the previously captured `current_async_effect` via `set_from_async_derived` before returning the value, enabling DEV `await_reactivity_loss` warnings after the promise resolves.

calls: [set_from_async_derived](r6-client-reactivity.md#u-7529e3342efc)

<a id="u-2e39d8f937d3"></a>
### `unset_context`

`export function unset_context()` · [packages/svelte/src/internal/client/reactivity/async.js:L170-L175][f2]

Clears the ambient reactive context after async work completes: nulls the active effect, active reaction, and component context, and in DEV clears async-derived tracking, so later work is not attributed to a stale effect.

calls: [runtime.js-module-state-setters](r2-reactivity-core.md#u-ac602620d878), [context.js-dev-state-setters](r2-component-context.md#u-beb31e6973ea)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/constants.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/reactivity/async.js
