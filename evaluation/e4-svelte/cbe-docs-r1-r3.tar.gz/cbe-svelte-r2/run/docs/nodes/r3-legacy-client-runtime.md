# Svelte 4 Client Compatibility

**Capability.** Deprecated runtime adapters exposing Svelte 4 class components, event bubbling, handlers, and $effect.pre-like run() on top of the Svelte 5 engine.

Use this subtree when maintaining backwards compatibility. Svelte4Component wraps a modern component with $set/$on/$destroy; asClassComponent and createClassComponent adapt between the two component models.

**Depends on.**

- [Component Mounting](r3-component-mounting.md) · graph-confirmed · 1 edge(s)
- [Effect Engine](r3-effects-engine.md) · graph-confirmed · 1 edge(s)

**Depended on by.**

- [Element Bindings, Actions, and Custom Elements](r3-element-bindings.md) · graph-confirmed · 1 edge(s)

Parent: [Client Runtime](r3-runtime.md)

## Units (6)

<a id="u-f604417484a2"></a>
### `Svelte4Component`

`class Svelte4Component` · [packages/svelte/src/legacy/legacy-client.js:L67-L79][f1]

Svelte 4-compatible component wrapper that runs a Svelte 5 component and exposes legacy instance APIs ($set, $on, $destroy, exported instance properties).

The constructor builds a props Proxy over a copy of options.props plus a $$events object; each accessed property gets a lazily created mutable_source, the getter returns get(source), the setter calls set(source, value) plus Reflect.set (coarse-grained versioned reactivity, deliberately not $state), and the has trap returns true for the LEGACY_PROPS sentinel to avoid 'invalid binding' validation while still registering a source and delegating to Reflect.has. It then invokes hydrate or mount depending on options.hydrate, passing target, anchor, props, context, intro (default false) and recover. Unless async_mode_flag is set and except when options.props.$$host exists or options.sync === false (i.e. flushSync is skipped for custom-element wrappers, opt-outs, and async mode), it calls flushSync(). this.#events is read from props.$$events afterward. For each own key of the instance other than $set/$destroy/$on it defines an enumerable accessor on this delegating to #instance. It overwrites #instance.$set with Object.assign(props, next) and #instance.$destroy with unmount(this.#instance). $set delegates to the instance $set; $on registers a wrapped callback (bound to this) in #events[event], creating the array lazily, and returns an unsubscriber filtering it out; $destroy delegates to the instance $destroy. add_source is an inner helper creating a mutable_source(value, false, false) and storing it in the sources map.

**Notes.**

- condition: flushSync is called only when NOT in async mode AND (no $$host prop OR options.sync !== false); otherwise the initial render flush is left to the surrounding scheduler.
- failure: Errors from mount/hydrate propagate out of the constructor, leaving the wrapper partially initialized.
- field: #events holds the $$events object created inside the props proxy, so $on subscriptions are seen by the component through the proxy.

calls: [Svelte4Component](r3-legacy-client-runtime.md#u-f604417484a2)

**Uncertainties.**

- Behavior of hydrate/mount/unmount and flushSync is defined in other modules not supplied here; only their call conditions are observable in this file.
- Whether Reflect.set on the proxy target alone suffices for component-visible updates depends on internal reactivity semantics not shown.

<a id="u-0c8e95825ebe"></a>
### `asClassComponent`

`export function asClassComponent(component)` · [packages/svelte/src/legacy/legacy-client.js:L49-L51][f1]

Deprecated adapter returning a Svelte 4-compatible constructor for a given component function or SvelteComponent class.

The returned anonymous class extends Svelte4Component and, in its constructor, merges the captured component into the caller's options ({component, ...options}) before invoking super, so options.component in the caller's options is overridden by the bound component. Members of the parent class (props proxy, $set, $on, $destroy) apply unchanged. Typing is suppressed with @ts-expect-error because $$prop_def internals are not modeled.

inherits: [Svelte4Component](r3-legacy-client-runtime.md#u-f604417484a2)

<a id="u-f1a6026980f8"></a>
### `createClassComponent`

`export function createClassComponent(options)` · [packages/svelte/src/legacy/legacy-client.js:L31-L34][f1]

Deprecated adapter that instantiates a Svelte 4-compatible component class from a Svelte 5 component function.

Takes the same options object as a Svelte 4 constructor (including a component field) and simply returns new Svelte4Component(options); all mounting, prop-proxy, and lifecycle behavior is delegated to that class. Throws nothing itself beyond what the Svelte4Component constructor propagates.

uses: [Svelte4Component](r3-legacy-client-runtime.md#u-f604417484a2)

<a id="u-f145d0cb7490"></a>
### `createBubbler`

`export function createBubbler()` · [packages/svelte/src/legacy/legacy-client.js:L248-L268][f1]

Deprecated factory producing a bubble(type) helper that re-dispatches an event to the capturing component's $$events, mimicking Svelte 4's automatic event bubbling.

Captures component_context at creation time; if it is null it calls lifecycle_outside_component('createBubbler'), which presumably throws. The returned function takes an event type and returns an event handler that looks up active_component_context.s.$$events[type]; if present, it copies the value (array via slice, single via one-element array) and invokes each callback with active_component_context.x as this and the event, returning !event.defaultPrevented. If no matching events exist it returns true (event not handled).

**Notes.**

- failure: Called outside a component context, it raises the lifecycle_outside_component error instead of returning a bubbler.

raises: [createBubbler](r3-legacy-client-runtime.md#u-f145d0cb7490)

**Uncertainties.**

- Whether lifecycle_outside_component throws or only reports depends on the errors module not supplied.

<a id="u-59b2e05812ff"></a>
### `handlers`

`export function handlers(...handlers)` · [packages/svelte/src/legacy/legacy-client.js:L211-L242][f1]

Deprecated helper combining multiple EventListeners into one.

Returns a function that calls each handler with the event and the original this, in order. It temporarily replaces event.stopImmediatePropagation with a wrapper that sets a stopped flag and calls the original, so propagation stopping halts the remaining handlers. Each handler call is wrapped in try/catch: errors are collected rather than interrupting the chain, and after the loop each collected error is rethrown asynchronously in its own queueMicrotask(() => { throw error; }), so they surface as uncaught errors without breaking other handlers. Handlers that are null/undefined are skipped via optional call.

**Notes.**

- failure: Handler exceptions are deferred: they never prevent later handlers from running, and each is thrown in a separate microtask.

<a id="u-8f7bc3d6b657"></a>
### `packages/svelte/src/legacy/legacy-client.js:run`

`export function run(fn)` · [packages/svelte/src/legacy/legacy-client.js:L188-L203][f1]

Deprecated legacy replacement for $effect.pre: wraps fn in a user_pre_effect that runs fn immediately during effect setup.

After fn runs, if the active effect was re-dirtied synchronously (DIRTY flag set), it emulates legacy recursive-reactive-block behavior: in DEV it resolves the filename from dev_current_component_function[FILENAME] (falling back to a placeholder string) and warns via legacy_recursive_reactive_block; unconditionally it downgrades the effect status to MAYBE_DIRTY so a same-tick re-run is not treated as an error. fn's return value is ignored; a returned cleanup function is passed through only insofar as user_pre_effect handles it.

calls: [packages/svelte/src/legacy/legacy-client.js:run](r3-legacy-client-runtime.md#u-8f7bc3d6b657)

**Uncertainties.**

- Whether a cleanup function returned by fn is honored depends on user_pre_effect internals not supplied.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/legacy/legacy-client.js
