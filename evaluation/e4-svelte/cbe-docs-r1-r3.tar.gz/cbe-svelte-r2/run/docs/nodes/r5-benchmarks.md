# Reactivity and SSR Benchmarks

**Capability.** Synthetic performance workloads: kairo diamond and Molière-style derived-chain graphs, a shared CPU-burning util, and an SSR benchmark that compiles App.svelte and times server rendering.

Use these for measuring signal and SSR throughput, not for production behavior. wrapper_bench compiles and renders via the public compiler API.

**Depends on.**

- [Compiler Public API and Pipeline](r5-compiler-pipeline.md) · model-inferred · 0 edge(s)
- [Benchmark Harness](r4-benchmark-harness.md) · graph-only · 11 edge(s)

Parent: [Svelte Monorepo](r5-svelte-monorepo.md)

## Units (5)

<a id="u-78f66379fb6c"></a>
### `kairo_diamond-js`

`function setup()` · [benchmarking/benchmarks/reactivity/kairo/kairo_diamond.js:L6-L30][f1]

Diamond graph: module constant width=5, five deriveds each reading the same head plus a sum derived reducing them, timed over 500 updates.

setup() pushes width deriveds of head+1 into an array, then sum = derived(() => current.map(get).reduce(add, 0)); a render_effect reads sum and increments a counter. run() flushes head=1 and asserts sum===2*width, resets counter, then for i=0..499 flushes head=i and asserts sum===(i+1)*width, finally asserting counter===500 (one effect run per flush). kairo_diamond_unowned does 10 JIT-warmup setup/run/destroy cycles, awaits fastest_test(10, 1000 run() calls), destroys and returns {benchmark, time, gc_time} with toFixed(2). kairo_diamond_owned keeps the warmup and the retained setup inside one $.effect_root (destroy_owned), assigns run/destroy to outer variables, times identically, then calls destroy() and destroy_owned().

uses: [assert](r4-benchmark-harness.md#u-823bd0dd0cd8); calls: [fastest_test](r4-benchmark-harness.md#u-0bbe8c671495)

<a id="u-0d12a4a1de84"></a>
### `busy`

`export function busy()` · [benchmarking/benchmarks/reactivity/kairo/util.js:L1-L6][f2]

Burns a small fixed number of CPU iterations as synthetic workload; returns undefined.

<a id="u-85101c0587c1"></a>
### `mol-bench-js`

`function fib(n)` · [benchmarking/benchmarks/reactivity/mol_bench.js:L7-L10][f3]

Molière-style benchmark with heavy derived computations anchored on recursive fib.

fib(n) recurses with base case n<2 returning 1 (fib(16)===1597); hard(n) returns n+fib(16). setup() creates states A and B, and deriveds: C=(A%2)+(B%2); D=numbers.map(i => i+(A%2)-(B%2)) over numbers=[0..4], with D.equals overridden to an element-wise comparison against this.v (null-safe, length-checked); E=hard(C+A+D[0]); F=hard(D[0] && B); G=C+(C || E%2)+D[0]+F. Three render_effects push hard(G), G, and hard(F) into a shared res array. run(i) clears res, flushes B=1 then A=1+i*2, then flushes A=2+i*2 and B=2, and asserts res equals [3198, 1601, 3195, 1598]. mol_bench_unowned runs 10 JIT-warmup setup/run(0)/destroy cycles, then awaits fastest_test(10, 1e4 run(i) calls), destroys and returns {benchmark, time, gc_time} via toFixed(2). mol_bench_owned performs the warmup and retains one setup inside a single $.effect_root (destroy_owned), assigns run/destroy to outer variables, times identically, then calls destroy() and destroy_owned().

uses: [assert](r4-benchmark-harness.md#u-823bd0dd0cd8); calls: [fastest_test](r4-benchmark-harness.md#u-0bbe8c671495)

**Uncertainties.**

- D.equals reads this.v, a field assumed to hold the derived's cached value; the internal representation is not in this batch.
- The asserted numeric outcomes (3198/1601/3195/1598) encode the framework's exact recomputation order and are not re-derived here.

<a id="u-e49d890081fc"></a>
### `compile_svelte`

`async function compile_svelte()` · [benchmarking/benchmarks/ssr/wrapper/wrapper_bench.js:L7-L16][f4]

Compiles App.svelte for server rendering and dynamically imports the emitted module.

It reads the source from the fixed dir under process.cwd(), compiles with generate:'server', writes output.js.code to output/App.js, then awaits a dynamic import of that file path and returns the module's default export. A compile failure or unreadable file propagates before any write of a new module; note that a stale output/App.js is overwritten before import, so import caching across repeated calls depends on the module loader, which is outside this file.

**Notes.**

- side_effect: Writes the compiled server bundle to output/App.js inside the benchmarks directory.

calls: [read_file](r4-benchmark-harness.md#u-19c8243b4a22), [write](r4-benchmark-harness.md#u-ccb2ac8173a1)

**Uncertainties.**

- Whether the dynamic import bypasses the ESM cache on recompilation is not determined by this source.

<a id="u-2f9f0e0c3125"></a>
### `wrapper_bench`

`export async function wrapper_bench()` · [benchmarking/benchmarks/ssr/wrapper/wrapper_bench.js:L18-L36][f4]

Times server-side rendering of the compiled App component.

It first awaits compile_svelte to obtain the default component, performs 3 un-timed render(App) calls as JIT warm-up, then awaits fastest_test(10, () => { for 100 iterations render(App) }) and returns {benchmark:'wrapper_bench', time, gc_time} with timings formatted toFixed(2). Errors from rendering propagate out of the awaited fastest_test call.

calls: [compile_svelte](r5-benchmarks.md#u-e49d890081fc), [fastest_test](r4-benchmark-harness.md#u-0bbe8c671495)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/benchmarking/benchmarks/reactivity/kairo/kairo_diamond.js
[f2]: ../../../../../../eval/svelte-be645b4/benchmarking/benchmarks/reactivity/kairo/util.js
[f3]: ../../../../../../eval/svelte-be645b4/benchmarking/benchmarks/reactivity/mol_bench.js
[f4]: ../../../../../../eval/svelte-be645b4/benchmarking/benchmarks/ssr/wrapper/wrapper_bench.js
