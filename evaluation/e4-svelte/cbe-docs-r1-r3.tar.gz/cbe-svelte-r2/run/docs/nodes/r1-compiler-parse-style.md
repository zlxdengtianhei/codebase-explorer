# CSS Parsing

**Capability.** Recursive-descent parser producing AST.CSS.StyleSheet from <style> content: stylesheet body, rules, at-rules, blocks, selector lists, declarations, and low-level ident/value/comment lexing.

read_style is the entry point; read_body/read_block_item dispatch between rules, declarations and at-rules; read_selector_list/read_selector handle complex selectors. The ident/value/comment helpers are shared leaf lexers; the mutual recursion among block readers is inherent to the nested CSS grammar.

Parent: [Parse Phase](r1-compiler-parse.md)

## Units (14)

<a id="u-863125efdf39"></a>
### `read_style`

`export default function read_style(parser, start, attributes)` · [packages/svelte/src/compiler/phases/1-parse/read/style.js:L25-L45][f1]

Entry point that parses a <style> element into an AST.CSS.StyleSheet.

It delegates to read_body with the '</style' terminator, then consumes the actual closing tag via parser.read(/^<\/style\s*>/). The returned node records the element start/end, the original attributes, the parsed children, and a raw content object carrying the exact source slice of the CSS text with comment set to null.

calls: [read_body](r1-compiler-parse-style.md#u-755ffe99e59c)

<a id="u-755ffe99e59c"></a>
### `read_body`

`function read_body(parser, close)` · [packages/svelte/src/compiler/phases/1-parse/read/style.js:L52-L71][f1]

Parses the stylesheet body until the close marker.

Each iteration skips comments/whitespace, returns accumulated children when parser.match(close) succeeds, and otherwise parses an at-rule (on '@') or a rule. If the template is exhausted before the close marker appears, e.expected_token fires at end of template.

calls: [read_at_rule](r1-compiler-parse-style.md#u-f5e645353a7a), [read_rule](r1-compiler-parse-style.md#u-7fd5dca44ce4)

<a id="u-f9ccd7c79c86"></a>
### `read_block`

`function read_block(parser)` · [packages/svelte/src/compiler/phases/1-parse/read/style.js:L415-L441][f1]

Parses a '{'...'}' block whose items are declarations, nested rules or at-rules.

It requires the '{', then loops: skipping comments/whitespace, breaking on '}', and otherwise appending read_block_item output; the closing '}' is required. Returns a Block node spanning from '{' to after '}'.

calls: [read_block_item](r1-compiler-parse-style.md#u-7fe79445acb0)

<a id="u-7fe79445acb0"></a>
### `read_block_item`

`function read_block_item(parser)` · [packages/svelte/src/compiler/phases/1-parse/read/style.js:L449-L462][f1]

Parses one block child, deciding its kind by lookahead: '@' means at-rule; otherwise it speculatively reads a value, inspects whether the following character is '{', rewinds, and parses a rule if so or a declaration if not.

This read-ahead duplicates parsing work but avoids try/catch that would mask real errors.

calls: [read_at_rule](r1-compiler-parse-style.md#u-f5e645353a7a), [read_rule](r1-compiler-parse-style.md#u-7fd5dca44ce4), [read_declaration](r1-compiler-parse-style.md#u-ed58797e828b)

<a id="u-7fd5dca44ce4"></a>
### `read_rule`

`function read_rule(parser)` · [packages/svelte/src/compiler/phases/1-parse/read/style.js:L110-L126][f1]

Parses a normal CSS rule: a selector list followed by a block, returned as a Rule node whose metadata is initialized with parent_rule null and has_local_selectors/has_global_selectors/is_global_block all false; end is the current parser.index after the block.

calls: [read_selector_list](r1-compiler-parse-style.md#u-00c76aa683fd), [read_block](r1-compiler-parse-style.md#u-f9ccd7c79c86)

<a id="u-f5e645353a7a"></a>
### `read_at_rule`

`function read_at_rule(parser)` · [packages/svelte/src/compiler/phases/1-parse/read/style.js:L77-L104][f1]

Parses an at-rule starting at '@'.

After consuming the '@' (required) it reads the at-rule name via read_identifier, the prelude via read_value, then either parses a block when '{' follows (e.g. @media) or requires a ';' (e.g. @import) via parser.eat(';', true), which errors if missing. Returns an Atrule node with name, prelude, and a block that is null for statement-style at-rules.

calls: [read_value](r1-compiler-parse-style.md#u-f2107227fcd9), [read_block](r1-compiler-parse-style.md#u-f9ccd7c79c86)

<a id="u-00c76aa683fd"></a>
### `read_selector_list`

`function read_selector_list(parser, inside_pseudo_class = false)` · [packages/svelte/src/compiler/phases/1-parse/read/style.js:L133-L162][f1]

Parses a comma-separated list of complex selectors, terminating at ')' when inside a pseudo-class or at '{' otherwise.

After each selector it skips comments/whitespace; if the terminator matches it returns a SelectorList whose end is the pre-whitespace index, otherwise it requires a ',' via parser.eat(',', true) (missing comma errors) and continues. Exhausting the template raises e.unexpected_eof.

calls: [read_selector](r1-compiler-parse-style.md#u-7a102285dde0)

<a id="u-7a102285dde0"></a>
### `read_selector`

`function read_selector(parser, inside_pseudo_class = false)` · [packages/svelte/src/compiler/phases/1-parse/read/style.js:L169-L180][f1]

Parses one complex selector as a list of RelativeSelectors joined by combinators.

Its local create_selector builds a RelativeSelector with the given combinator, empty selectors list, end -1, and zeroed metadata. The main loop dispatches on the next token: '&' → NestingSelector; '*' (optionally followed by '|namespace') → TypeSelector; '#' → IdSelector; '.' → ClassSelector; '::' → PseudoElementSelector (an argument list is parsed for validity but discarded); ':' → PseudoClassSelector with a nested selector list as args when '(' follows; '[' → AttributeSelector with optional matcher (from /^[~^$*|]?=/), quoted-or-bare value, and alphabetic flags, ']' required; inside pseudo-classes, an nth-of pattern (matched before combinators so '+2n-1' is not read as '+') → Nth; a percentage → Percentage; otherwise an identifier, with an ignored '|' namespace, → TypeSelector. After each item, comments/whitespace are skipped; if ',' or the terminator (')' or '{' per context) follows, it rewinds to before that whitespace and returns the accumulated ComplexSelector. Otherwise it reads a combinator; when present, the current relative selector is finalized (only if non-empty) and a new one starts at the combinator — a terminator immediately after a combinator raises e.css_selector_invalid. Template exhaustion raises e.unexpected_eof.

calls: [read_combinator](r1-compiler-parse-style.md#u-ffc85cf8c133), [read_selector_list](r1-compiler-parse-style.md#u-00c76aa683fd), [read_identifier](r1-compiler-parse-style.md#u-2dd7159f8ba1)

**Uncertainties.**

- The Combinator node's start field is used as the new selector's start, implying read_combinator exposes it; the exact start offset when whitespace precedes the combinator character depends on read_combinator's internal handling.

<a id="u-ffc85cf8c133"></a>
### `read_combinator`

`function read_combinator(parser)` · [packages/svelte/src/compiler/phases/1-parse/read/style.js:L380-L409][f1]

Returns the combinator between relative selectors or null.

After skipping whitespace it reads /^\+|~|>|\|\|/; a match yields a Combinator node spanning the operator. If no operator matched but whitespace was skipped, it returns a descendant Combinator named ' '. If neither operator nor whitespace is present it returns null, meaning the selector items continue unbroken.

**Uncertainties.**

- The returned start when whitespace precedes the operator is the operator's own index, not the whitespace start; downstream uses rely on this but are outside this file.

<a id="u-ae80a6ada159"></a>
### `read_attribute_value`

`function read_attribute_value(parser)` · [packages/svelte/src/compiler/phases/1-parse/read/style.js:L543-L569][f1]

Reads an attribute-selector value, optionally quoted.

It first attempts to consume " or ' as the quote mark; with a quote the value ends at the matching quote (required via parser.eat, else error), without a quote it ends at the first whitespace or ']' per REGEX_CLOSING_BRACKET. Backslash escapes are carried through literally. Reaching end of template raises e.unexpected_eof; the trimmed value is returned.

<a id="u-ed58797e828b"></a>
### `read_declaration`

`function read_declaration(parser)` · [packages/svelte/src/compiler/phases/1-parse/read/style.js:L468-L496][f1]

Parses 'property: value;'.

The property is read up to whitespace or ':'; after ':' and whitespace the value comes from read_value. An empty value is an error (e.css_empty_declaration) unless the property starts with '--' (custom properties may be empty). A trailing ';' is required unless the next character is '}'. The returned Declaration node's end is taken before the semicolon is consumed.

**Notes.**

- condition: parser.eat(':') is optional in the code; a missing colon yields an empty property and then the empty-declaration error unless the property is custom-property-like.

<a id="u-f2107227fcd9"></a>
### `read_value`

`function read_value(parser)` · [packages/svelte/src/compiler/phases/1-parse/read/style.js:L502-L536][f1]

Reads a raw declaration or at-rule prelude value as a trimmed string, terminated by unquoted ';', '{' or '}'.

It tracks a single active quote mark (' or "), backslash escapes (the escaped character is appended literally after the backslash), and url(...) context: '(' after a trailing 'url' enables in_url, ')' disables it, and inside a url or quotes the terminators do not apply. Escaping is consumed even inside quotes. End of template before a terminator raises e.unexpected_eof.

**Notes.**

- condition: Only one quote mark is tracked at a time; a quote toggles off only on the same character, so mixed quotes nest textually.

<a id="u-2dd7159f8ba1"></a>
### `read_identifier`

`function read_identifier(parser)` · [packages/svelte/src/compiler/phases/1-parse/read/style.js:L575-L611][f1]

Reads a CSS identifier per the CSS syntax spec's ident diagram.

A leading hyphen followed by a digit (or a leading digit) raises e.css_expected_identifier. '\' starts an escape: a hex unicode sequence (1-6 digits, optional trailing whitespace/newline) is decoded via String.fromCodePoint, otherwise the next character is kept literally after the backslash. Regular characters are those matching [a-zA-Z0-9_-] or with code point ≥160. An empty result raises e.css_expected_identifier.

**Notes.**

- failure: read_identifier never returns empty — it errors instead, so callers can rely on a non-empty name.

<a id="u-131239fcb755"></a>
### `allow_comment_or_whitespace`

`function allow_comment_or_whitespace(parser)` · [packages/svelte/src/compiler/phases/1-parse/read/style.js:L614-L629][f1]

Skips whitespace plus CSS ('/*...*/') and HTML ('<!--...-->') comments in any interleaving.

It loops while '/*' or '<!--' match: comment content is read up to the closer and the closer itself is required via parser.eat, so an unterminated comment errors; whitespace is skipped after each comment.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/1-parse/read/style.js
