# Tooling and Developer Environment

**Capability.** Benchmarks the reactivity system across branches and provides the shared dev configuration (Vitest, Vite sandbox) used while working on the package.

Use this subtree for measurement and local development setup. Benchmarks isolate signal-fan-out performance; the sandbox and Vitest configs govern how the package builds, serves, and tests during development.

**Children.**

- [Reactivity Benchmarks](r3-reactivity-benchmarks.md) `r3-reactivity-benchmarks` · 5 unit(s)
- [Dev Environment Configuration](r3-dev-environment.md) `r3-dev-environment` · 4 unit(s)

Parent: [Svelte Monorepo](r3-svelte-monorepo.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
