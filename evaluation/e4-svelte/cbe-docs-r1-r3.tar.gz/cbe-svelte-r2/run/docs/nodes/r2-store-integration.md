# Store integration

**Capability.** Bridges Svelte stores into the reactive system: reactive subscription on first read, resubscribe/unsubscribe bookkeeping, set/increment/mutation helpers, and store-binding flags for prop getters.

Read store_get for the subscribe/read path and store_set/store_mutate/update_store/update_pre_store for the write paths; setup_stores and the container entries manage per-component subscription lifecycle. capture_store_binding and mark_store_binding mark prop reads as store bindings.

**Depends on.**

- [Reactivity core](r2-reactivity-core.md) · graph-confirmed · 1 edge(s) · store_get reads store-backed state through the reactivity core's get.

Parent: [Client runtime](r2-client-runtime.md)

## Units (20)

<a id="u-543bcc42ec11"></a>
### `store-js-setup-stores`

`export function setup_stores()` · [packages/svelte/src/internal/client/reactivity/store.js:L124-L128][f1]

setup_stores creates an empty StoreReferencesContainer and a cleanup function.

The cleanup, registered through teardown (so it runs on effect teardown), unsubscribes every entry in the container and then defines the IS_UNMOUNTED symbol property on the container. That marker changes store_get behavior afterwards: no new subscriptions are created, and reads fall back to reading the store directly. Returns the container and cleanup as a tuple.

calls: [effects.js-effect-creators](r3-effects-engine.md#u-27c9c7c4069f)

**Uncertainties.**

- When cleanup is invoked relative to component destruction depends on the caller.

<a id="u-8388b459c980"></a>
### `capture_store_binding`

`export function capture_store_binding(fn)` · [packages/svelte/src/internal/client/reactivity/store.js:L194-L203][f1]

Runs fn with is_store_binding reset to false and returns [fn() result, whether the flag was set during the run].

The previous flag value is restored in a finally block, so nested calls compose correctly. The boolean tells callers whether fn read a store-bound prop, used to relax binding_property_non_reactive validation and keep such props mutable in runes mode.

<a id="u-edad6338b44e"></a>
### `invalidate_store`

`export function invalidate_store(stores, store_name)` · [packages/svelte/src/internal/client/reactivity/store.js:L113-L118][f1]

Re-writes a store with the last value seen in its container entry: when the entry's store is non-null it calls store_set with entry.source.v, propagating the current source value back into the store.

calls: [store_set](r2-store-integration.md#u-f137b5f9bcce)

<a id="u-5762353cb5e2"></a>
### `mark_store_binding`

`export function mark_store_binding()` · [packages/svelte/src/internal/client/reactivity/store.js:L182-L184][f1]

Sets the module-level is_store_binding flag to true; intended to be called inside prop getters to mark the currently read prop as a store binding.

<a id="u-6bf992bdbb59"></a>
### `store_get`

`export function store_get(store, store_name, stores)` · [packages/svelte/src/internal/client/reactivity/store.js:L30-L74][f1]

Reads a store's value reactively, subscribing on first use.

It lazily creates a per-store-name entry in the container holding a mutable source and a noop unsubscribe. In dev the source is labelled with the store name. When the store differs from the subscribed one and the container is not marked IS_UNMOUNTED, the old subscription is torn down and a new one created via subscribe_to_store; a null/undefined store just resets the source value and unsubscribe. The subscription callback writes the source synchronously (bypassing set, avoiding state_unsafe_mutation inside synchronous derived evaluation) for callbacks fired during subscribe, and via set afterwards. When the owning component is unmounted (IS_UNMOUNTED present) the raw store value is read directly with get_store instead of the possibly stale source, avoiding leaks while keeping values consistent. Otherwise it returns get(entry.source).

calls: [subscribe_to_store](r6-stores.md#u-863f9153e183), [packages/svelte/src/internal/client/runtime.js:get](r2-reactivity-core.md#u-98099fbbf12a)

**Uncertainties.**

- The store contract that subscribe_to_store invokes the callback synchronously once is defined in store/utils.js.

<a id="u-83c162a9a0c9"></a>
### `store_mutate`

`export function store_mutate(store, expression, new_value)` · [packages/svelte/src/internal/client/reactivity/store.js:L151-L154][f1]

Calls store.set(new_value) and returns the original expression value, so `$store += x` evaluates to the computed expression while the store receives the new value.

<a id="u-f137b5f9bcce"></a>
### `store_set`

`export function store_set(store, value)` · [packages/svelte/src/internal/client/reactivity/store.js:L104-L107][f1]

Calls store.set(value) and returns the value, so `$store = x` compiles to an expression that also yields x.

<a id="u-acc685c0000a"></a>
### `store_unsub`

`export function store_unsub(store, store_name, stores)` · [packages/svelte/src/internal/client/reactivity/store.js:L84-L95][f1]

Unsubscribes a store-name entry only if its currently subscribed store differs from the given store, then sets unsubscribe to noop; it deliberately keeps entry.store so a following store_get can resubscribe.

Returns the store argument unchanged.

<a id="u-8f1bdc289c63"></a>
### `update_pre_store`

`export function update_pre_store(store, store_value, d = 1)` · [packages/svelte/src/internal/client/reactivity/store.js:L173-L177][f1]

Pre-increment/decrement on a numeric store: computes store_value + d, writes it via store.set, and returns the new value.

<a id="u-afc78260326c"></a>
### `update_store`

`export function update_store(store, store_value, d = 1)` · [packages/svelte/src/internal/client/reactivity/store.js:L162-L165][f1]

Post-increment/decrement on a numeric store: writes store_value + d via store.set and returns the pre-update store_value.

<a id="u-037f7c03bbfc"></a>
### `store.js module code (L1–L29)`

`module_region` · [packages/svelte/src/internal/client/reactivity/store.js:L1-L29][f1]

Module imports plus the is_store_binding and IS_UNMOUNTED declarations; non-behavioral.

<a id="u-1e92d8e5fe2b"></a>
### `store.js module code (L74–L83)`

`module_region` · [packages/svelte/src/internal/client/reactivity/store.js:L74-L83][f1]

Trailing region after store_get; non-behavioral.

<a id="u-43f09462ecb9"></a>
### `store.js module code (L95–L103)`

`module_region` · [packages/svelte/src/internal/client/reactivity/store.js:L95-L103][f1]

Trailing region after store_unsub; non-behavioral.

<a id="u-73fcfa414c38"></a>
### `store.js module code (L107–L112)`

`module_region` · [packages/svelte/src/internal/client/reactivity/store.js:L107-L112][f1]

Trailing region after store_set; non-behavioral.

<a id="u-3e7318f2b73e"></a>
### `store.js module code (L118–L123)`

`module_region` · [packages/svelte/src/internal/client/reactivity/store.js:L118-L123][f1]

Trailing region after invalidate_store; non-behavioral.

<a id="u-4f53576ddd5d"></a>
### `store.js module code (L142–L150)`

`module_region` · [packages/svelte/src/internal/client/reactivity/store.js:L142-L150][f1]

Trailing region after setup_stores; non-behavioral.

<a id="u-ec34732a3c49"></a>
### `store.js module code (L154–L161)`

`module_region` · [packages/svelte/src/internal/client/reactivity/store.js:L154-L161][f1]

Trailing region after store_mutate; non-behavioral.

<a id="u-c9dffc5be004"></a>
### `store.js module code (L165–L172)`

`module_region` · [packages/svelte/src/internal/client/reactivity/store.js:L165-L172][f1]

Trailing region after update_store; non-behavioral.

<a id="u-c926e60a9e71"></a>
### `store.js module code (L177–L181)`

`module_region` · [packages/svelte/src/internal/client/reactivity/store.js:L177-L181][f1]

Trailing region after update_pre_store; non-behavioral.

<a id="u-5a15260dd192"></a>
### `store.js module code (L184–L193)`

`module_region` · [packages/svelte/src/internal/client/reactivity/store.js:L184-L193][f1]

Trailing region after mark_store_binding; non-behavioral.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/reactivity/store.js
