# Client Transform Visitors

**Capability.** Compiles component ASTs into client-side reactive code: component instantiation and slot serialization, transitions/animations scheduled after bind:this, class field accessors, await reactivity preservation, and special global elements.

Read these visitors to see how each template construct maps to runtime calls. Shared helpers (build_component, visit_special_element) carry the reusable serialization; most visitor files are thin delegates.

**Depends on.**

- [Client Runtime](r1-client-runtime.md) · model-inferred · 0 edge(s)
- [Shared Assignment Rewriting](r1-compiler-transform-shared.md) · model-inferred · 0 edge(s)
- [Client Transform](r5-client-transform.md) · graph-only · 25 edge(s)

**Depended on by.**

- [Treeshakeability Verification](r1-tooling-treeshake.md) · model-inferred · 0 edge(s) · Treeshakeability verification bundles the compiler's client exports and probes the client transform output for residual code.

Parent: [Transform Phase](r1-compiler-transform.md)

## Units (17)

<a id="u-ea683dd1d72c"></a>
### `component.js-build-component`

`export function build_component(node, component_name, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/component.js:L18-L83][f1]

Builds the client-side serialization of a component (Component, SvelteComponent, SvelteSelf) into a statement that instantiates it with props, slots, events, and bindings.

Iterates attributes: LetDirectives are collected as `lets` (visited with the default-slot state when slot scope does not already apply, otherwise visited first with default state); OnDirectives become handlers via build_event_handler wrapped in `$.once` when the `once` modifier is present, grouped per event name and pushed as `$$events` after all attributes; a handler-less OnDirective marks `needs_props`. SpreadAttributes become thunks when their expression has state (wrapped in `$.get`/memoizer when awaiting or calling), otherwise raw expressions. Attributes named `--x` become custom CSS props initialized with build_attribute_value, memoized on call/await. Normal Attributes are pushed as getters or inits depending on `has_state`, wrapped in `$.get`+memoizer when non-identifier expression tags suggest over-firing. BindDirectives: in dev, non-`this` non-sequence bindings to prop/bindable_prop kinds add `$$ownership_validator.binding` initializers and set `needs_mutation_validation`; SequenceExpressions become `bind:this` (if name is `this`) or synthesized get/set props with generated ids; otherwise dev+runes MemberExpressions call validate_binding, store-sub bindings get a getter that calls `$.mark_store_binding`, and binding get/set props are delayed so spreads do not overwrite them (delayed_props flushed after the loop). AttachTags become `$.attachment` props, wrapped in an arrow over `$$node` when stateful. Children are grouped by determine_slot or SnippetBlock name: snippet declarations are hoisted into a block, snippets become props plus `$$slots` entries; default slots become a `children` prop (possibly `$.wrap_snippet` in dev, or `$.invalid_default_snippet` when lets/SvelteFragment LetDirectives exist) plus a `$$slots.default: true` marker. Legacy (non-runes) bind directives add `$$legacy: true`. Props combine into an object or `$.spread_props`. The final call expression `fn` is layered: `build_bind_this` wraps when bind:this exists; dynamic components (SvelteComponent or dynamic metadata) are routed through `$.component` with a scope-generated intermediate name and a body containing binding initializers. Custom CSS props force a wrapper element (`g` for svg, `svelte-css-wrapper` with `display: contents` otherwise) in the template, then `$.css_props`, the component call on `anchor.lastChild`, and `$.reset`; otherwise a template comment plus add_svelte_meta wrap the call. Memoizer.apply fills placeholder ids; if async values exist the whole body returns through `$.async` with the async ids as arrow params, else a block or single statement is returned.

uses: [Memoizer](r5-client-transform.md#u-76b08484949a), [state.js-module-level-compiler-state](r2-compiler-infrastructure.md#u-d73d7b033038), [object](r5-compiler-utilities.md#u-2f2548aeaec6); calls: [build_bind_this](r5-client-transform.md#u-62396233e782), [validate_binding](r5-client-transform.md#u-91b59b999e05), [add_svelte_meta](r5-client-transform.md#u-75700db42066), [build_attribute_value](r3-client-transform.md#u-2462157783c9), [build_event_handler](r4-client-transform.md#u-227977f005ec), [determine_slot](r2-compiler-infrastructure.md#u-ead26eb5b43f)

**Uncertainties.**

- node.metadata.dynamic, scopes map, and fragment node shapes are external; exact slot-scope state selection for named slots relies on node.metadata.scopes[slot_name] existing
- runtime shape of b.* builder helpers is assumed from usage

<a id="u-0128ebcf4caf"></a>
### `AnimateDirective`

`export function AnimateDirective(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/AnimateDirective.js:L11-L28][f2]

Compiles an animate: directive into an $.animation call appended to state.after_update, so it runs after bind:this.

The directive name expression is visited after parse_directive_name parsing; when the directive has no expression, b.null is passed instead of a thunk of the value expression.

calls: [parse_directive_name](r5-client-transform.md#u-47fb5120ded1)

**Uncertainties.**

- Exactly what parse_directive_name returns is defined in another file.

<a id="u-4517247cbf4b"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/ArrowFunctionExpression.js:ArrowFunctionExpression`

`export function ArrowFunctionExpression(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/ArrowFunctionExpression.js:L9-L11][f3]

Delegates arrow function nodes to the shared visit_function helper; all transformation logic lives there.

calls: [packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/function.js:visit_function](r5-client-transform.md#u-888d94f48ee5)

<a id="u-f3de4a3c5909"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/AwaitExpression.js:AwaitExpression`

`export function AwaitExpression(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/AwaitExpression.js:L10-L29][f4]

Rewrites await expressions whose reactivity would be lost.

After visiting the argument, instance top-level await (is_instance and function_depth 1), or an await inside a reactive expression that is not the last-evaluated subexpression, produce `await $.save(argument)` to preserve the reactive proxy. Otherwise, in dev and when await_reactivity_loss is not ignored via is_ignored, it returns `await $.track_reactivity_loss(argument)`. If the visited argument is unchanged the original node is returned; otherwise a copy with the new argument.

calls: [state.js-module-level-compiler-state](r2-compiler-infrastructure.md#u-d73d7b033038)

<a id="u-b83cfea00bba"></a>
### `is_last_evaluated_expression`

`function is_last_evaluated_expression(context, node)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/AwaitExpression.js:L65-L126][f4]

Reports whether the awaited argument is the last value produced along its expression chain, deciding whether `$.save` is needed.

Walking parents backwards, a node with `metadata` returns true immediately. Each parent type imposes a position condition: array/object elements, call/new arguments, sequence/template/tagged-template expressions must be the last entry; the left operand of assignment/binary/logical expressions, a conditional's test, a computed member's object, and a property's key return false. Any other parent type returns false. The loop ends by returning undefined (falsy).

**Uncertainties.**

- Loop completion returns undefined rather than an explicit false; only falsiness is observable.

<a id="u-cce61d3ebba0"></a>
### `is_reactive_expression`

`function is_reactive_expression(context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/AwaitExpression.js:L34-L59][f4]

Determines whether the current await sits in a reactive context.

Returns true immediately when state.in_derived. Otherwise it walks the parent path backwards: any function node (arrow, function expression, declaration) ends the scan with false, any node carrying a `metadata` property ends it with true; exhausting the path returns false.

**Uncertainties.**

- The `parent.metadata` check is an in-source acknowledged heuristic, not a robust mechanism.

<a id="u-bd7b8d09104e"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/ClassBody.js:ClassBody`

`export function ClassBody(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/ClassBody.js:L13-L111][f5]

Rewrites class bodies so `$state` fields become backed by `$.get`/`$.set` accessors.

If the analysis has no state_fields for this class body (legacy mode) it calls context.next() and returns unchanged. It first inserts backing field definitions plus getter/setter method pairs for fields whose node is an AssignmentExpression (fields declared only in the constructor); private (`#`) names are skipped there. Each body member is then revisited: non-PropertyDefinitions pass through visited; PropertyDefinitions without a matching state field pass through; private-named fields keep their key but get their initializer visited and, in dev, wrapped in `$.tag(value, 'Class.name')`; a public field declared here becomes a prop_def of field.key plus a getter returning `$.get(this.key)` and a setter calling `$.set(this.key, value, proxyFlag)`, where the proxy flag is true whenever the field type is `$state` (a TODO notes this is unconditional). In dev, initializers of public fields are also `$.tag`-wrapped with `ClassName.name` or `[class].#name` when the class has no id. Returns a copy of the node with the new body.

**Uncertainties.**

- `should_proxy` is hardcoded to `field.type === '$state' && true` with an in-source TODO; whether future conditions were intended is not decidable.
- get_parent is called with -1; which parent that resolves to depends on that helper.

<a id="u-7baf7e9461f9"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/Comment.js:Comment`

`export function Comment(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/Comment.js:L8-L11][f6]

Appends the comment node to the template via state.template.push_comment with the comment's data; the docstring notes this visitor only runs when comments are preserved (preserveComments).

calls: [template.js-template-class](r5-client-transform.md#u-74901e1385cf)

<a id="u-9ed746e0d1ee"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/Component.js:Component`

`export function Component(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/Component.js:L10-L13][f7]

Compiles a component tag by delegating to build_component with the component's name, then pushes the resulting declaration into state.init.

calls: [component.js-build-component](r1-compiler-transform-client.md#u-ea683dd1d72c)

<a id="u-096c3cb09027"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/ExpressionStatement.js:ExpressionStatement`

`export function ExpressionStatement(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/ExpressionStatement.js:L10-L30][f8]

Rewrites rune effect calls.

When the statement's expression is a CallExpression whose rune (per get_rune) is '$effect' or '$effect.pre', the first argument is visited and wrapped in a call to $.user_effect or $.user_pre_effect respectively; the callee's source location is copied onto the new call for sourcemap mapping, and the statement is returned. A '$inspect.trace' rune call is dropped entirely (b.empty). Any other statement falls through to context.next().

calls: [get_rune](r3-scope-node-model.md#u-5204b6ce4f7a)

<a id="u-9d7a76679f62"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/FunctionDeclaration.js:FunctionDeclaration`

`export function FunctionDeclaration(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/FunctionDeclaration.js:L10-L23][f9]

Handles function declarations, splitting on hoisting metadata.

When node.metadata.hoisted is true, params are rebuilt with build_hoisted_params (capturing referenced component state explicitly), the body is visited with in_constructor and in_derived reset to false, and the rewritten declaration is pushed into state.hoisted while b.empty is returned in place. Non-hoisted functions continue through context.next with the same reset state.

calls: [build_hoisted_params](r2-client-signal-builders.md#u-a89fb605f1f4)

<a id="u-f48625ba1690"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/HtmlTag.js:HtmlTag`

`export function HtmlTag(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/HtmlTag.js:L11-L47][f10]

Serializes {@html ...} into a `$.html` runtime call.

After a template comment, build_expression produces the expression; when it has await, the rendered html operand becomes `$.get($$html)` instead. Namespace metadata selects `is_svg`/`is_mathml` truthy flags, and is_ignored(node, 'hydration_html_changed') supplies a final flag. Without await, the `$.html(node, thunk, flags...)` statement goes directly to state.init. With await, init instead receives `$.async(node, [thunk(expression, true)], (node, $$html) => { statement })`, deferring rendering until the async value resolves — placed in init so later bindings can override hydration.

calls: [build_expression](r5-client-transform.md#u-cd5eb51d389f), [state.js-module-level-compiler-state](r2-compiler-infrastructure.md#u-d73d7b033038)

<a id="u-f91f27df0412"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/LetDirective.js:LetDirective`

`export function LetDirective(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/LetDirective.js:L11-L51][f11]

Serializes `let:` slot bindings into derived declarations over `$$slotProps`.

With a non-identifier expression (destructuring), a scope-generated alias is declared as `$.derived(() => { const {pattern} = $$slotProps.name; return {binding: name...} })` — object vs array pattern chosen by the expression type — and each binding from get_bindings gets a transform reading `$.get(alias).<name>`. With an identifier or no expression, the bound name (expression name or directive name) gets a `$.get` transform and is declared as `create_derived(state, $$slotProps.<name>)`. Both branches return the const declaration node.

calls: [create_derived](r2-client-signal-builders.md#u-d8c62e2be238); uses: [Scope](r3-scope-node-model.md#u-01a82e58170d)

**Uncertainties.**

- The ts-expect-error casts assume the destructuring expression contains no spread elements; this is asserted, not verified here.

<a id="u-5bfaaebc7139"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/SlotElement.js:SlotElement`

`export function SlotElement(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/SlotElement.js:L12-L92][f12]

Serializes <slot> elements into a `$.slot($$slots..., name, props, fallback)` call.

Attributes are classified: spreads become thunks in a spreads list; normal attributes are built via build_attribute_value whose callback memoizes values with call/await metadata behind `$.get`; the `name` attribute overrides the default 'default' literal, `slot` is skipped, and others become object properties — a getter when the value has state, an init otherwise. LetDirectives are visited and pushed to init before the slot call so bindings are available to attributes. memoizer.apply() runs; memoizer.deriveds yields preliminary statements. With spreads the props expression becomes `$.spread_props(object, ...spreads)`; an empty fragment yields a null fallback, otherwise an `$$anchor` arrow of the visited fragment. The `$.slot` statement is appended, and init receives either `$.async(node, values, (node, ...ids) => statements)` when async values exist, or the single statement/block otherwise.

calls: [build_attribute_value](r3-client-transform.md#u-2462157783c9), [Memoizer](r5-client-transform.md#u-76b08484949a)

<a id="u-af73e301b19f"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/SvelteDocument.js:SvelteDocument`

`export function SvelteDocument(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/SvelteDocument.js:L9-L11][f13]

Compiles <svelte:document> by delegating to visit_special_element with the target expression '$.document'.

calls: [visit_special_element](r1-compiler-transform-client.md#u-5f6160c62286)

<a id="u-960109c44c27"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/TransitionDirective.js:TransitionDirective`

`export function TransitionDirective(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/TransitionDirective.js:L12-L29][f14]

Serializes transition:/in:/out: directives into a `$.transition(flags, node, nameThunk, paramsThunk?)` statement pushed to state.after_update, so it runs after bind:this.

Flags combine TRANSITION_GLOBAL (when the `global` modifier is present), TRANSITION_IN (node.intro), and TRANSITION_OUT (node.outro). The directive name expression and, when present, the parameter expression are each visited inside thunks.

calls: [parse_directive_name](r5-client-transform.md#u-47fb5120ded1)

<a id="u-5f6160c62286"></a>
### `visit_special_element`

`export function visit_special_element(node, id, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/special_element.js:L12-L22][f15]

Serializes svelte:body, svelte:document, and svelte:window by rebinding state.node to a fixed global identifier (the passed id).

Each OnDirective is visited under that state and its resulting expression statement is pushed to init; all other attribute types are visited under the same state with no explicit output handling here, relying on their own visitors.

**Uncertainties.**

- How non-OnDirective attributes contribute output depends on their visitors, which are outside this file

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/component.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/AnimateDirective.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/ArrowFunctionExpression.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/AwaitExpression.js
[f5]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/ClassBody.js
[f6]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/Comment.js
[f7]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/Component.js
[f8]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/ExpressionStatement.js
[f9]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/FunctionDeclaration.js
[f10]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/HtmlTag.js
[f11]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/LetDirective.js
[f12]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/SlotElement.js
[f13]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/SvelteDocument.js
[f14]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/TransitionDirective.js
[f15]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/special_element.js
