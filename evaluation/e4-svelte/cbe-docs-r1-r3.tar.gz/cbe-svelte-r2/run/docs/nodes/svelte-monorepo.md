# Svelte Monorepo

**Capability.** Navigation root for a repository whose responsibilities split into compiler pipeline, client/server runtimes, public typing, reactive/motion libraries, and dev tooling. Children are responsibility facets merged from the candidate region overviews; they intentionally do not mirror directory layout.

Start here to navigate. Compilation and codemod work lives under compiler-and-migration; execution behavior under runtime-and-shared-infra; author-facing contracts under public-typing-and-reactive-libs; measurement and build workflow under the tooling children. Cross-facet dependencies are recorded in depends_on and include real cycles.

**Children.**

- [Svelte Monorepo](r1-svelte-monorepo.md) `r1-svelte-monorepo` · 2 unit(s)
- [Compiler Pipeline and Migration](compiler-and-migration.md) `compiler-and-migration` · 0 unit(s)
- [Client/Server Runtime and Shared Infrastructure](runtime-and-shared-infra.md) `runtime-and-shared-infra` · 0 unit(s)
- [Public Typing and Reactive/Motion Libraries](public-typing-and-reactive-libs.md) `public-typing-and-reactive-libs` · 0 unit(s)
- [Build and Packaging](build-and-packaging.md) `build-and-packaging` · 0 unit(s)
- [Benchmarks and Developer Environment](tooling-and-dev-env.md) `tooling-and-dev-env` · 0 unit(s)

**Depends on.**

- [Compiler Pipeline and Migration](compiler-and-migration.md) · containment · → 0 / ← 0 edge(s) (ancestor direct units and descendant subtree; → follows ` svelte-monorepo ` → ` compiler-and-migration `)
- [Client/Server Runtime and Shared Infrastructure](runtime-and-shared-infra.md) · containment · → 0 / ← 0 edge(s) (ancestor direct units and descendant subtree; → follows ` svelte-monorepo ` → ` runtime-and-shared-infra `)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
