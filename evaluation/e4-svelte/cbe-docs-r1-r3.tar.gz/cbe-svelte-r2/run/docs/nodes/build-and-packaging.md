# Build and Packaging

**Capability.** Owns artifact production: the Rollup UMD compiler build, generated type-declaration/version files, markdown-to-module generation of error/warning code, and the playground sandbox that compiles sample sources for client and server.

Run generate-types/generate-version and process-messages as part of packaging; the sandbox script rebuilds output/ via its write helpers and svelte.config.js enables experimental async compilation. process-messages depends on the compiler's client Program transform.

**Children.**

- [Svelte framework](r2-svelte.md) `r2-svelte` · 0 unit(s)

**Depends on.**

- [Benchmarks and Developer Environment](tooling-and-dev-env.md) · graph-confirmed · 53 edge(s) · Sandbox/playground packaging scripts share the dev-environment configuration and benchmark workloads.

**Depended on by.**

- [Compiler Pipeline and Migration](compiler-and-migration.md) · graph-confirmed · 67 edge(s)

Parent: [Svelte Monorepo](svelte-monorepo.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
