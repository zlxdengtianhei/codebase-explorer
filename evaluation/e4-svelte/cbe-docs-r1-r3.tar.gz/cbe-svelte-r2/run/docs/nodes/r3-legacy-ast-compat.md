# Svelte 4 AST Converter

**Capability.** Converts the modern compiler AST into the Svelte 4 shape for legacy compilation, deleting metadata and remapping node types via per-node handlers.

Use this subtree when working on legacy.js. The convert walker is the whole capability; whitespace trimming supports it. Note that behavior depends on per-node-type handlers not detailed here.

Parent: [Compiler](r3-compiler.md)

## Units (2)

<a id="u-b18e2937a7a3"></a>
### `legacy.js-convert-modern-ast-to-svelte-4-shape`

`export function convert(source, ast)` · [packages/svelte/src/compiler/legacy.js:L42-L47][f1]

Group the Svelte-4 compatibility AST converter: `convert` walks the modern AST with zimmerframe, deleting `metadata` everywhere and replacing node types/shapes with their legacy equivalents via per-node-type handlers.

`remove_surrounding_whitespace_nodes` trims leading/trailing whitespace Text children in place (shift/pop fully-whitespace Text nodes, or strip leading/trailing whitespace from their `data`) and is used by block handlers before visiting children. The `_` handler is the default that deletes metadata and continues. Notable handlers: Root splices `options.__raw__` back into the fragment before the first node ending at/after `options.end`, computes the html Fragment start/end by skipping whitespace in the source string, deletes `attributes` from instance/module, and returns the legacy `{html, instance, module, css}` root. AwaitBlock builds Pending/Then/Catch blocks with null start/end and `skip: true` defaults, filling start/end from first/last child or by scanning the source for `}` after `expression.end` (then/catch fall back to previous block's end), setting `skip: false` when the corresponding block exists. ConstTag returns the node unchanged if it already has a legacy `expression`; otherwise it synthesizes an AssignmentExpression from the first declaration, adjusting start by the length of `'const '` and deleting `typeAnnotation`. ExpressionTag becomes AttributeShorthand when the direct parent is an Attribute whose source starts with `{`, otherwise MustacheTag. IfBlock: an alternate consisting of a single `elseif` IfBlock is unwrapped to that block's consequent nodes; the else block's end is the last `{` before node.end; an elseif IfBlock's start comes from its first consequent child or that last-brace scan; `elseif` is preserved as true/undefined. EachBlock builds an ElseBlock from `fallback` (end at last `{` before node.end, start from first child or that position). Attribute and StyleDirective, when the value is neither `true` nor an array, push the node onto the walk path, visit the single value wrapping it in a one-element array, pop the path, and return a copy with that value; otherwise they call `next()`. StyleSheet spreads the node with `context.next()`'s result and adds `type: 'Style'`. ComplexSelector calls `next()` first, then flattens children into combinators followed by selectors as `Selector.children`. Comment attaches `ignores` extracted from its data via `extract_svelte_ignore`. Text inside a `<style>` RegularElement parent returns a fresh Text node lacking `raw`. SvelteElement downgrades a string Literal `tag` to a plain string unless the preceding source character is `{`. Remaining handlers are straightforward renames: AnimateDirective→Animation, BindDirective→Binding, ClassDirective→Class, HtmlTag→RawMustacheTag, OnDirective→EventHandler, SpreadAttribute→Spread, and Component/SlotElement/SvelteBody/SvelteComponent/SvelteDocument/SvelteFragment/SvelteHead/SvelteSelf/SvelteWindow/TitleElement map to InlineComponent/Slot/Body/InlineComponent/Document/SlotTemplate/Head/InlineComponent/Window/Title with visited attributes and children; KeyBlock, SnippetBlock, SvelteBoundary and RegularElement also visit and trim whitespace. The walk result is returned as the legacy root.

calls: [remove_surrounding_whitespace_nodes](r3-legacy-ast-compat.md#u-f51ce07da951), [extract_svelte_ignore](r6-compiler-infra.md#u-4a9ee4fb9b67)

**Uncertainties.**

- Text's handler returns undefined for non-style-element parents; what zimmerframe does with an undefined return (default traversal) is outside this file.
- The `__raw__` options shape and its producer are not visible in this file.

<a id="u-f51ce07da951"></a>
### `remove_surrounding_whitespace_nodes`

`function remove_surrounding_whitespace_nodes(nodes)` · [packages/svelte/src/compiler/legacy.js:L16-L34][f1]

Trim surrounding whitespace Text nodes from an array in place.

If the first node is a Text containing only whitespace it is shifted off; otherwise its leading whitespace is stripped from `data`. The same is done symmetrically for the last node with trailing whitespace. Mutates the passed array and node data; no return value.

**Uncertainties.**

- Does not run after shifting the first node, so an array that becomes whitespace-led/lagged by the first mutation is not re-examined.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/legacy.js
