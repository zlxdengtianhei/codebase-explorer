# Component context

**Capability.** Maintains the component lifecycle stack and the context API: push/pop of component_context, setContext/getContext/hasContext/getAllContexts over parent-chained context maps, runes-mode detection and dev-only metadata stacking.

Use setContext/getContext/hasContext/getAllContexts as the public surface; get_or_init_context_map and get_parent_context implement lookup including ancestor fallback. is_runes decides legacy vs runes behaviour and is consulted by the reactivity core.

**Depended on by.**

- [Async reactivity](r2-async-reactivity.md) · graph-confirmed · 3 edge(s) · Async reactivity capture/unset reads and resets component-context state and runes-mode detection across await boundaries.
- [DOM elements, events and bindings](r2-dom-elements.md) · model-inferred · 0 edge(s)
- [Reactivity core](r2-reactivity-core.md) · graph-confirmed · 7 edge(s)

Parent: [Client runtime](r2-client-runtime.md)

## Units (11)

<a id="u-beb31e6973ea"></a>
### `context.js-dev-state-setters`

`export function set_component_context(context)` · [packages/svelte/src/internal/client/context.js:L14-L16][f1]

Three exported setters maintain module-level development/introspection state in context.js: set_component_context replaces the global component_context slot, set_dev_stack replaces the global dev_stack slot, and set_dev_current_component_function replaces the dev_current_component_function slot.

Each is a bare assignment with no validation, so passing null clears the corresponding global.

<a id="u-19355b3b3598"></a>
### `packages/svelte/src/internal/client/context.js:add_svelte_meta`

`export function add_svelte_meta(callback, type, component, line, column, additional)` · [packages/svelte/src/internal/client/context.js:L36-L53][f1]

Wraps a callback with a development-only stack entry describing the block or component being created.

It snapshots the current dev_stack as parent, pushes a new entry built from the component's FILENAME property plus line, column, type, and any additional properties, runs the callback, and restores the previous stack in a finally block so the stack is unwound even if the callback throws; the callback's return value is propagated.

**Notes.**

- side_effect: Mutates the module-level dev_stack variable for the duration of the callback.

uses: [context.js-dev-state-setters](r2-component-context.md#u-beb31e6973ea)

<a id="u-c05aabfae0d1"></a>
### `getAllContexts`

`export function getAllContexts()` · [packages/svelte/src/internal/client/context.js:L134-L137][f1]

Returns the whole context Map of the current component, requiring component initialisation.

The returned map is the live, lazily created map on component_context.c seeded with ancestor entries, so a caller can mutate the shared context through it.

**Notes.**

- side_effect: First access lazily creates the map on component_context.c.

calls: [get_or_init_context_map](r2-component-context.md#u-99872e9939fa)

<a id="u-abbef1c88791"></a>
### `getContext`

`export function getContext(key)` · [packages/svelte/src/internal/client/context.js:L80-L84][f1]

Returns the context value registered under key by the closest ancestor component, using the current component's context map obtained via get_or_init_context_map; that helper throws a lifecycle error if called outside component initialisation.

Missing keys yield undefined, since the map lookup is not validated.

**Uncertainties.**

- Unknown keys are not rejected; the result is an unchecked Map.get cast to T.

<a id="u-99872e9939fa"></a>
### `get_or_init_context_map`

`function get_or_init_context_map(name)` · [packages/svelte/src/internal/client/context.js:L201-L207][f1]

Internal helper returning the current component's context map; throws e.lifecycle_outside_component(name) when component_context is null.

On first access it creates the map on component_context.c, seeded by copying get_parent_context(component_context) so the component inherits all ancestor context entries.

calls: [get_parent_context](r2-component-context.md#u-3b276f9d9206)

<a id="u-3b276f9d9206"></a>
### `get_parent_context`

`function get_parent_context(component_context)` · [packages/svelte/src/internal/client/context.js:L213-L223][f1]

Walks the parent chain of a ComponentContext and returns the first non-null context map found on an ancestor, or null when no ancestor has initialised a context map.

The loop terminates at a p of null.

<a id="u-3341dee08c97"></a>
### `hasContext`

`export function hasContext(key)` · [packages/svelte/src/internal/client/context.js:L121-L124][f1]

Reports whether key exists in the current component's context map, returning the Map.has result as a boolean.

Like getContext, it throws via get_or_init_context_map when called outside component initialisation.

calls: [get_or_init_context_map](r2-component-context.md#u-99872e9939fa)

<a id="u-71aba13a168a"></a>
### `is_runes`

`export function is_runes()` · [packages/svelte/src/internal/client/context.js:L193-L195][f1]

Reports whether the current code runs in runes mode: true when legacy_mode_flag is off, or when there is a current component context whose l legacy slot is null.

When component_context is null and legacy mode is on, it returns false.

<a id="u-fe159451466a"></a>
### `pop`

`export function pop(component)` · [packages/svelte/src/internal/client/context.js:L167-L190][f1]

Pops the current component context, completing component initialisation.

If context.e holds deferred callbacks, it clears context.e first and converts each callback into a user effect via create_user_effect, so errors there propagate out of pop. If a component argument was supplied it is stored as context.x (exports). It then restores component_context to the parent link, and under DEV restores dev_current_component_function from the parent context's function (null if none). Returns the component argument, or a fresh empty object when undefined.

**Notes.**

- condition: component === undefined changes the return value to {} rather than undefined.
- side_effect: Clears context.e before creating effects so the deferred list is not flushed twice.

calls: [effects.js-effect-creators](r3-effects-engine.md#u-27c9c7c4069f); contract: [push](r2-component-context.md#u-9761c5d7c2ee)

<a id="u-9761c5d7c2ee"></a>
### `push`

`export function push(props, runes = false, fn)` · [packages/svelte/src/internal/client/context.js:L145-L160][f1]

Pushes a new component context onto the module-level component_context stack when a component initialises.

The new context links p to the previous context; c (context map), e (deferred effects), and x (exports) start null; s holds the props. The l legacy slot is a fresh object only when legacy_mode_flag is on and the runes argument is false, otherwise null. Under DEV it records the component function on the context and into dev_current_component_function.

**Notes.**

- side_effect: Mutates global component_context and, under DEV, dev_current_component_function; must be paired with pop.

<a id="u-64fe4521bdfe"></a>
### `setContext`

`export function setContext(key, context)` · [packages/svelte/src/internal/client/context.js:L98-L112][f1]

Stores a context value under key on the current component's context map and returns the value so children (including slotted content) can read it with getContext.

When async_mode_flag is set, it validates that there is no active reaction, the active effect is a branch effect, and that branch has not yet run; if any check fails it calls e.set_context_after_init() instead of writing. In legacy/other modes it writes unconditionally.

calls: [get_or_init_context_map](r2-component-context.md#u-99872e9939fa)

**Uncertainties.**

- Whether e.set_context_after_init throws or warns is defined in errors.js, not shown here.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/context.js
