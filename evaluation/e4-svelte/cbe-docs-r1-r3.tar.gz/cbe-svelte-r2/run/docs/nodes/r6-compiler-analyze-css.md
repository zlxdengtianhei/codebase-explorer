# CSS Scoping Analysis

**Capability.** Computes CSS scoping facts: which attribute values selectors can match, whether selectors are global or outer-global, and which selectors are unused so warnings can be emitted.

Use for scoping decisions and unused-selector warnings. is_global/is_outer_global lean on is_unscoped_pseudo_class; get_possible_values feeds attribute matching; css-warn.js walks the stylesheet to report unused selectors.

**Depended on by.**

- [Semantic Analysis](r6-compiler-analyze.md) · containment · → 0 / ← 0 edge(s) (ancestor direct units and descendant subtree; → follows ` r6-compiler-analyze ` → ` r6-compiler-analyze-css `)

Parent: [Semantic Analysis](r6-compiler-analyze.md)

## Units (8)

<a id="u-6a7a7b443898"></a>
### `warn_unused`

`export function warn_unused(stylesheet)` · [packages/svelte/src/compiler/phases/2-analyze/css/css-warn.js:L10-L12][f1]

Walks the stylesheet to emit unused-selector warnings, carrying { stylesheet } state into the module's visitors.

<a id="u-2711ea3bb857"></a>
### `packages/svelte/src/compiler/phases/2-analyze/css/css-warn.js:ComplexSelector`

`ComplexSelector(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/css/css-warn.js:L26-L39][f1]

Warns for selectors not marked used.

A warning is emitted when metadata.used is false and not inside an `is`/`where` pseudo-class whose enclosing complex selector is already used (preventing double warnings for `.unused:is(.unused)`); the selector's source text is sliced from the stylesheet content and passed to w.css_unused_selector. The Atrule visitor (folded) skips descending into non-keyframes at-rules so their contents are not traversed for this check; the PseudoClassSelector visitor descends only into `is`/`where`; the Rule visitor visits only the prelude of global-block rules instead of the whole rule.

**Uncertainties.**

- The Atrule/PseudoClassSelector/Rule guards' exact intent (limiting traversal scope) is inferred from the branch conditions.

<a id="u-b80afad44d7a"></a>
### `gather_possible_values`

`function gather_possible_values(node, is_class, set, is_nested = false)` · [packages/svelte/src/compiler/phases/2-analyze/css/utils.js:L11-L78][f2]

Computes the set of string values an expression node may produce for attribute matching, adding the UNKNOWN sentinel when the value cannot be determined (early-returning once UNKNOWN is present).

Literals stringify to their value; conditional expressions union both arms. For '&&', the left side is evaluated separately: if it is unknown, the falsy values ''/false/NaN/0 are added unless this is a nested class attribute (where clsx drops falsy values); if known, known falsy values are added under the same class/nesting restriction; the right side is then always evaluated. Other logical expressions union both sides. For class attributes, array literals union their non-hole elements (marked nested) and object literals add non-computed Identifier/Literal keys, adding UNKNOWN for anything else. Any other node type adds UNKNOWN.

**Uncertainties.**

- Values are stringified at the caller, so distinguishing false/NaN/0 from their string forms inside this set is only meaningful for the falsy checks performed here

<a id="u-f841f035438b"></a>
### `get_parent_rules`

`export function get_parent_rules(rule)` · [packages/svelte/src/compiler/phases/2-analyze/css/utils.js:L102-L111][f2]

Collects the rule itself followed by all ancestor rules via metadata.parent_rule, ending with the outermost rule last; a null input yields an empty list.

<a id="u-cb59d8ba04c6"></a>
### `get_possible_values`

`export function get_possible_values(chunk, is_class)` · [packages/svelte/src/compiler/phases/2-analyze/css/utils.js:L85-L96][f2]

Returns the possible string values of a Text or ExpressionTag attribute chunk, or null when any value is undeterminable.

Text chunks yield their data directly; expression chunks delegate to gather_possible_values; a set containing UNKNOWN maps to a null return, which callers treat as 'may match anything'.

calls: [gather_possible_values](r6-compiler-analyze-css.md#u-b80afad44d7a)

<a id="u-022eb67172ae"></a>
### `packages/svelte/src/compiler/phases/2-analyze/css/utils.js:is_global`

`export function is_global(relative_selector)` · [packages/svelte/src/compiler/phases/2-analyze/css/utils.js:L118-L132][f2]

True when a relative selector starts with ':global' and stays global: a bare ':global' (args === null) qualifies, otherwise every following selector must be an unscoped pseudo class (via is_unscoped_pseudo_class) or a pseudo element — so e.g. ':global(button).x' is not global because the class scopes it.

calls: [is_unscoped_pseudo_class](r6-compiler-analyze-css.md#u-2d29e82903c1)

**Uncertainties.**

- Assumes selectors is non-empty (selectors[0] accessed without a guard)

<a id="u-a5fd8a871e73"></a>
### `is_outer_global`

`export function is_outer_global(relative_selector)` · [packages/svelte/src/compiler/phases/2-analyze/css/utils.js:L163-L177][f2]

True when a relative selector starts with ':global' regardless of scoped pseudo classes after it, unlike is_global: a bare ':global' qualifies, or with args when every other selector is a pseudo class or pseudo element (so ':global(x):has(y)' is an outer global here but not is_global, while a TypeSelector like in ':global(button).x' still disqualifies).

**Uncertainties.**

- Assumes selectors is non-empty (selectors[0] accessed without a guard)

<a id="u-2d29e82903c1"></a>
### `is_unscoped_pseudo_class`

`export function is_unscoped_pseudo_class(selector)` · [packages/svelte/src/compiler/phases/2-analyze/css/utils.js:L138-L155][f2]

True when a simple selector is a pseudo class that cannot or does not need scoping.

Non-'has'/'is'/'where' pseudo classes qualify, except ':not' which qualifies only when it has no args or every inner complex selector is single-selector (multi-selector ':not' must be scoped). 'has'/'is'/'where' qualify only when they have no args or all their inner relative selectors are recursively global via is_global. Non-pseudo-class selectors return false.

calls: [packages/svelte/src/compiler/phases/2-analyze/css/utils.js:is_global](r6-compiler-analyze-css.md#u-022eb67172ae)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/css/css-warn.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/css/utils.js
