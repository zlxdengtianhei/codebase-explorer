# Reactive Browser Values

**Capability.** ReactiveValue views of browser state (window values), each reading the live value in the browser and undefined on the server behind the BROWSER flag, including the devicePixelRatio view.

Use for isomorphic reactive access to window-derived state. Server consumers receive undefined by design.

**Depends on.**

- [Dev-Mode Diagnostics](r6-client-dev.md) · graph-confirmed · 1 edge(s)

Parent: [Stores, Motion, and Reactive Values](r6-stores-motion-reactivity.md)

## Units (2)

<a id="u-ed447951421e"></a>
### `index.js-window-values`

`group` · [packages/svelte/src/reactivity/window/index.js:L161-L161][f1]

Reactive views of window state, each a `ReactiveValue` whose read function returns the live value in the browser and `undefined` on the server (guarded by the `BROWSER` flag).

`scrollX`/`scrollY` subscribe to window `scroll`; `innerWidth`/`innerHeight`/`outerWidth`/`outerHeight` to window `resize`; both update on every event. `screenLeft`/`screenTop` cannot be observed by events, so their start functions poll inside a self-rescheduling `requestAnimationFrame` loop, calling `update()` only when the sampled value changed since the previous frame, and cancel the pending frame on unsubscribe. `online` subscribes to both window `online` and `offline` events and removes both on teardown. All depend on the `on` helper's unsubscriber contract for cleanup.

group: [DevicePixelRatio](r6-reactive-values.md#u-c22347eadbab); uses: [packages/svelte/src/events/index.js][f2]

**Uncertainties.**

- Polling frequency/teardown timing depends on `on` and `requestAnimationFrame`, not visible here.
- `ReactiveValue` subscription semantics are defined in reactive-value.js, outside this file.

<a id="u-c22347eadbab"></a>
### `DevicePixelRatio`

`class DevicePixelRatio` · [packages/svelte/src/reactivity/window/index.js:L131-L134][f1]

IIFE-installed class giving `devicePixelRatio.current` a reactive view of `window.devicePixelRatio` (undefined on the server).

It holds a private `source` initialized to the current value (or undefined off-browser). `#update` subscribes, via `on`, to a `matchMedia('(resolution: <dppx>dppx)')` change event for the current DPR; when the DPR changes it sets the source, unsubscribes the now-stale query, and re-runs `#update` to listen on the new DPR's media query — a self-refreshing chain. The constructor only starts the chain when `BROWSER`, and in `DEV` tags the source for tracing. `current` registers dependency with `get(this.#dpr)` and returns `window.devicePixelRatio` in the browser, `undefined` otherwise.

group: [DevicePixelRatio](r6-reactive-values.md#u-c22347eadbab)

**Uncertainties.**

- Browser-specific behavior noted in the docstring (Chrome reacts to zoom, Firefox/Safari may not) stems from `devicePixelRatio`/matchMedia semantics, not this code.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/reactivity/window/index.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/events/index.js
