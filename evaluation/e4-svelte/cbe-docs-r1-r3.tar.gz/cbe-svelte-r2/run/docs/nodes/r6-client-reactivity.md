# Client Reactivity Core

**Capability.** Implements lazy Derived signals (creation, safe-equality, execution, effect teardown) and async deriveds that track signal reads across promise boundaries and publish settled values into Sources.

Use for the signal graph engine. derived/derived_safe_equal/user_derived build signals; execute/update_derived evaluate and cache; the async-derived group handles await-dependent reactivity. Dev tracing is invoked from derived evaluation.

**Depends on.**

- [Dev-Mode Diagnostics](r6-client-dev.md) · graph-confirmed · 1 edge(s)

**Depended on by.**

- [Reactivity Benchmarks](r6-benchmarking.md) · model-inferred · 0 edge(s)
- [DOM Template Blocks](r6-client-dom-blocks.md) · model-inferred · 0 edge(s)
- [Legacy Component Lifecycle](r6-client-dom-legacy.md) · graph-confirmed · 1 edge(s)

Parent: [Client Runtime](r6-runtime-client.md)

## Units (17)

<a id="u-ad60e0aa2daf"></a>
### `deriveds-js-async-derived`

`export function async_derived(fn, location)` · [packages/svelte/src/internal/client/reactivity/deriveds.js:L100-L132][f1]

Creates an async derived: an async_effect calls fn(), tracking signals read while accessing the promise's then, and publishes settled results into a Source via internal_set.

It returns a promise fulfilling with the Source once the latest promise settles. With no active effect it throws async_derived_orphan. Per effect run: a synchronous throw from fn() is converted into a rejected promise; if prev exists the new promise gets a swallowing catch to avoid unhandled rejections. With should_suspend (created outside any reaction, i.e. during initialisation) the boundary's pending count is incremented and the batch incremented when the boundary was not already pending. The handler resets prev and current_async_effect, activates the batch when the boundary was not already pending, and on error sets ERROR_VALUE and internal_sets the error unless it is STALE_REACTION (ignored entirely); on success it clears ERROR_VALUE, internal_sets the value, and in dev with a location argument schedules an await_waterfall warning via setTimeout keyed on the recent_async_deriveds set. It then decrements the pending count/batch when suspending and calls unset_context. The rejection path coerces falsy errors to the string 'unknown'. The effect teardown queues batch.neuter() on a microtask when a batch exists. The outer promise resolves through next/go only when the settled promise is still the current one; otherwise it re-awaits the newer promise. In dev the signal is flagged ASYNC.

**Notes.**

- condition: should_suspend is true only when active_reaction is null at creation time, so re-runs from inside reactions never suspend.

calls: [effects.js-effect-creators](r3-effects-engine.md#u-27c9c7c4069f), [internal_set](r5-runtime-reactivity.md#u-0dae6a8d64cd), [Boundary.update_pending_count](r1-client-boundaries.md#u-48954c5681ed), [Batch](r4-reactivity-scheduling.md#u-43c969fbb82e), [unset_context](r2-async-reactivity.md#u-2e39d8f937d3)

**Uncertainties.**

- Semantics of batch.activate/neuter/increment/decrement and boundary pending counting live in batch.js and boundary.js; only the call sites are visible.
- What unset_context resets is defined in async.js.

<a id="u-d386336ed5eb"></a>
### `derived`

`export function derived(fn)` · [packages/svelte/src/internal/client/reactivity/deriveds.js:L55-L91][f1]

Creates a lazily-evaluated Derived signal object around fn without evaluating it.

Flags start as DERIVED|DIRTY; when there is no active effect, or the active reaction is a derived flagged UNOWNED, UNOWNED is added; otherwise the active effect is marked EFFECT_PRESERVED so effects created lazily inside the derived remain attached to the parent tree. The signal captures component context, default equals, parent (parent derived or active effect), null deps/reactions, and v = UNINITIALIZED. In dev tracing mode it records a 'CreatedAt' stack via get_stack. fn is never called here.

**Notes.**

- field: ac starts as null; it is the AbortController slot on the signal object.

calls: [tracing.js-reactive-tracing](r6-client-dev.md#u-fb7046392fad)

**Uncertainties.**

- The downstream consequences of EFFECT_PRESERVED and UNOWNED are defined outside this file.

<a id="u-15f47648fe69"></a>
### `derived_safe_equal`

`export function derived_safe_equal(fn)` · [packages/svelte/src/internal/client/reactivity/deriveds.js:L245-L249][f1]

Creates a derived via derived(fn) and replaces its equals with safe_equals, so re-evaluations that produce a non-identical value (e.g. fresh objects) still count as changes; returns the modified signal.

calls: [derived](r6-client-reactivity.md#u-d386336ed5eb)

<a id="u-a30c1fdac161"></a>
### `destroy_derived_effects`

`export function destroy_derived_effects(derived)` · [packages/svelte/src/internal/client/reactivity/deriveds.js:L255-L265][f1]

Destroys the effects created inside a derived: when derived.effects is non-null it nulls the array first (preventing re-entrant double destruction) and then destroys each effect in order via destroy_effect.

calls: [destroy_effect](r3-effects-engine.md#u-214ad59ce57a)

<a id="u-193107029d03"></a>
### `execute_derived`

`export function execute_derived(derived)` · [packages/svelte/src/internal/client/reactivity/deriveds.js:L294-L327][f1]

Re-runs a derived's function and returns its value.

The module-scope helper get_derived_parent_effect walks the parent chain past DERIVED parents to the nearest non-derived effect (or null), and that effect is temporarily made active via set_active_effect. It then destroys the derived's child effects and computes the value with update_reaction; the previous active effect is restored in finally, so errors thrown by fn propagate after restoration. In dev it also swaps in a fresh inspect-effects set, detects self-referencing evaluation using a module-level stack (throwing derived_references_self when the derived is already on it), and pushes/pops the derived on that stack; in production the stack is untouched.

calls: [update_reaction](r2-reactivity-core.md#u-f6b808e008e3), [runtime.js-module-state-setters](r2-reactivity-core.md#u-ac602620d878), [destroy_derived_effects](r6-client-reactivity.md#u-a30c1fdac161)

**Uncertainties.**

- How update_reaction handles errors thrown by fn is decided in runtime.js, not here.

<a id="u-7529e3342efc"></a>
### `set_from_async_derived`

`export function set_from_async_derived(v)` · [packages/svelte/src/internal/client/reactivity/deriveds.js:L43-L45][f1]

Sets the module-level current_async_effect reference to the given effect or null.

Plain assignment with no conditions or error handling; readers observe whatever was last stored.

<a id="u-637b94af51bf"></a>
### `update_derived`

`export function update_derived(derived)` · [packages/svelte/src/internal/client/reactivity/deriveds.js:L333-L355][f1]

Executes a derived and caches its result.

The value from execute_derived is written only when derived.equals(value) fails, in which case v is replaced and the write version bumped via increment_write_version. It skips marking the derived clean while a destroying effect is running, avoiding caching a stale value in cleanup functions. Otherwise, if batch_deriveds is non-null the value is recorded into that map instead of changing status; otherwise status becomes MAYBE_DIRTY when (skip_reaction or the derived is UNOWNED) and it has deps, or CLEAN in all other cases, applied via set_signal_status.

calls: [runtime.js-module-state-setters](r2-reactivity-core.md#u-ac602620d878)

**Uncertainties.**

- The effect of writing into batch_deriveds is realized in batch.js.

<a id="u-81f409d392c6"></a>
### `user_derived`

`export function user_derived(fn)` · [packages/svelte/src/internal/client/reactivity/deriveds.js:L231-L237][f1]

Creates a derived via derived(fn) and registers it with push_reaction_value before returning it; no other transformation is applied.

calls: [derived](r6-client-reactivity.md#u-d386336ed5eb)

<a id="u-c99b4d48e9d9"></a>
### `deriveds.js module code (L1–L42)`

`module_region` · [packages/svelte/src/internal/client/reactivity/deriveds.js:L1-L42][f1]

Module imports and the current_async_effect declaration; non-behavioral.

<a id="u-8ab7ea564004"></a>
### `deriveds.js module code (L45–L54)`

`module_region` · [packages/svelte/src/internal/client/reactivity/deriveds.js:L45-L54][f1]

Declares recent_async_deriveds, an exported Set used by the dev await_waterfall check in async_derived; non-behavioral here.

<a id="u-c7c50a3a4c9b"></a>
### `deriveds.js module code (L91–L99)`

`module_region` · [packages/svelte/src/internal/client/reactivity/deriveds.js:L91-L99][f1]

Trailing declarations after derived; non-behavioral material already located by the inventory.

<a id="u-31cc6b170bbc"></a>
### `deriveds.js module code (L223–L230)`

`module_region` · [packages/svelte/src/internal/client/reactivity/deriveds.js:L223-L230][f1]

Trailing region after async_derived; non-behavioral.

<a id="u-78711135f23a"></a>
### `deriveds.js module code (L237–L244)`

`module_region` · [packages/svelte/src/internal/client/reactivity/deriveds.js:L237-L244][f1]

Trailing region after user_derived; non-behavioral.

<a id="u-df2f993cb801"></a>
### `deriveds.js module code (L249–L254)`

`module_region` · [packages/svelte/src/internal/client/reactivity/deriveds.js:L249-L254][f1]

Trailing region after derived_safe_equal; non-behavioral.

<a id="u-5a8b300d4516"></a>
### `deriveds.js module code (L265–L277)`

`module_region` · [packages/svelte/src/internal/client/reactivity/deriveds.js:L265-L277][f1]

Module-level stack array declaration used for dev recursion detection; non-behavioral.

<a id="u-02712bc1503f"></a>
### `deriveds.js module code (L287–L293)`

`module_region` · [packages/svelte/src/internal/client/reactivity/deriveds.js:L287-L293][f1]

Trailing region after get_derived_parent_effect; non-behavioral.

<a id="u-beec63e50ae6"></a>
### `deriveds.js module code (L327–L332)`

`module_region` · [packages/svelte/src/internal/client/reactivity/deriveds.js:L327-L332][f1]

Trailing region after execute_derived; non-behavioral.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/reactivity/deriveds.js
