# Lint Configuration

**Capability.** ESLint flat config owning the custom no_compiler_imports rule (whole-file scan per program) and the default-exported config array wiring it.

Edit when adding lint rules or adjusting compiler-import boundaries; the rule creation and the config export form one module-level capability.

Parent: [Repo Tooling & Benchmarks](r1-tooling.md)

## Units (2)

<a id="u-4c030f15b9c8"></a>
### `eslint.config.js-flat-config`

`group` · [eslint.config.js:L33-L109][f1]

Defines the module's ESLint flat-config surface: the no_compiler_imports rule object plus the default-exported config array.

The rule object (meta plus create) is covered by the create unit. The exported array composes @sveltejs/eslint-config and adds, in order: a base block enabling type-aware parsing via projectService rooted at import.meta.dirname, registering the lube and custom plugins, forcing several rules on (await-thenable, require-await, no-console, lube/svelte-naming-convention) and deliberately turning others off (object-shorthand and prefer-promise-reject-errors because ESLint misreads JSDoc cast patterns, no-var, plus quotes/no-unused-vars/prefer-const deferred to a future lint:fix run); a '**/*.svelte' block disabling the three type-aware rules, which the comment says fail when run through Svelte files; a block scoped to packages/svelte/src excluding the compiler directory that enables custom/no_compiler_imports and disables svelte/no-svelte-internal; and a final ignores-only block excluding declaration files, tests, generated error/warning files, benchmarking, coverage, playgrounds, top-level *.config.js, documentation, and tmp. Config blocks apply in array order, so later blocks override earlier rule settings for matching files.

group: [create](r1-tooling-lint.md#u-34b493301cfd); imports: [@sveltejs/eslint-config](../../catalog.json), [eslint-plugin-lube](../../catalog.json)

**Uncertainties.**

- Exact precedence semantics of the spread of svelte_config versus the following blocks is inferred from flat-config ordering, not proven here.

<a id="u-34b493301cfd"></a>
### `create`

`const no_compiler_imports = { meta: { type: /** @type {const} */ ('problem'), docs: {…` · [eslint.config.js:L4-L33][f1]

Implements the custom no_compiler_imports ESLint rule by scanning the whole file text once per program.

On the Program node it gets the full source text and takes the later of the first occurrences of '../compiler/' and '#compiler' (Math.max of the two indexOf results). If that index is -1, meaning neither string is present, nothing is reported. Otherwise it reports at the 12-character span starting at that index, with a message stating that references to compiler code are forbidden in runtime code for both type and value imports. Because this is a raw substring search over comments and JSDoc too, it can in principle flag text occurrences that are not actual imports; the source itself acknowledges this as unlikely. The rule performs no fixes and reports at most one violation per file.

**Notes.**

- side_effect: Reports at most one violation per file: only the location of the later of the two first-match indices is reported.
- condition: The search covers the entire raw text including comments and JSDoc, per the inline comment explaining ESLint lacks a JSDoc-checking API.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/eslint.config.js
