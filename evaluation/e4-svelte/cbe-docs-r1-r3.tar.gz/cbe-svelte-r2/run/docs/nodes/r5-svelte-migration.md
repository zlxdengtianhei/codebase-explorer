# Svelte 4 to 5 Migration

**Capability.** Rewrites legacy component code to runes mode: the migrate() entry point plus walker visitors converting $: labels, bindable props, slot usage, on: events, svelte:self/component and declarations, with a sentinel MigrationError for intentional aborts and @migration-task fallbacks.

Use this subtree to understand or extend codemods. migrate() builds shared State consumed by visitors; helpers like handle_events, migrate_slot_usage and trim_block are shared across visitors; failure paths emit migration tasks.

**Depends on.**

- [Analyze-Phase Visitors](r5-analyze-phase.md) · model-inferred · 0 edge(s)
- [Compiler Utilities and AST Helpers](r5-compiler-utilities.md) · graph-confirmed · 10 edge(s)

Parent: [Svelte Monorepo](r5-svelte-monorepo.md)

## Units (27)

<a id="u-9fa554fc7f25"></a>
### `index-js-migrationerror`

`class MigrationError extends Error` · [packages/svelte/src/compiler/migrate/index.js:L28-L32][f1]

Sentinel Error subclass whose constructor only forwards the message to Error, marking intentional migration aborts.

**Notes.**

- contract: migrate's catch suppresses console.error output only for this error type, so it distinguishes planned aborts from bugs.

<a id="u-e7b335023277"></a>
### `index-js-thin-visitors`

`Identifier(node, { state, path })` · [packages/svelte/src/compiler/migrate/index.js:L501-L503][f1]

One-line delegating visitors in both walker tables.

**Notes.**

- contract: Both Identifier visitors forward to handle_identifier; Component calls migrate_slot_usage after next() while SvelteFragment calls it before next(); SvelteWindow, SvelteBody and SvelteDocument call handle_events then next().

calls: [handle_identifier](r5-svelte-migration.md#u-f31d2d5b26f5), [handle_events](r5-svelte-migration.md#u-11d2b2cd1c0c), [migrate_slot_usage](r5-svelte-migration.md#u-4d888e7e32a9)

<a id="u-6ad88d7a7f44"></a>
### `index-js-trim-visitors`

`HtmlTag(node, { state, next })` · [packages/svelte/src/compiler/migrate/index.js:L1371-L1374][f1]

Template visitors that normalize whitespace inside brace-delimited tag headers by calling trim_block.

**Notes.**

- side_effect: HtmlTag and ConstTag trim the whole tag range; IfBlock and KeyBlock trim from the block start through the closing brace of the expression; AwaitBlock trims the header (ending after the expression, or after the value binding when there is no pending branch) and, when present, the {:then} and {:catch} clause braces, before descending.

calls: [trim_block](r5-svelte-migration.md#u-cad9e2b4a6a0)

<a id="u-081e94041a1f"></a>
### `extract_type_and_comment`

`function extract_type_and_comment(declarator, state, path)` · [packages/svelte/src/compiler/migrate/index.js:L1587-L1707][f1]

Derives a prop's type, leading comment and trailing comment from a declarator and blanks the consumed comments from the output.

**Notes.**

- condition: Precedence: a TS type annotation wins outright; else a cleaned `@type {...}` JSDoc on an exported declaration (description after ` - ` is preserved); else a string/number/boolean Literal initializer supplies its typeof; else 'any'. All comment text from the first `@` line onward is dropped during cleaning.
- side_effect: Sets state.has_type_or_fallback when a type annotation, exported @type, or inferable Literal is found; with uses_ts the raw comments are returned instead of the cleaned ones.

**Uncertainties.**

- The export path runs a regex against comment_node.value, whose shape is asserted only by cast here.

<a id="u-97593ff10930"></a>
### `find_closing_parenthesis`

`function find_closing_parenthesis(start, code)` · [packages/svelte/src/compiler/migrate/index.js:L102-L114][f1]

Scans forward from start counting parentheses and returns the index just past the parenthesis that balances the opening one.

**Notes.**

- failure: If the input ends unbalanced, the loop stops on the undefined character and the string end is returned.

<a id="u-7acff5a27531"></a>
### `get_node_range`

`function get_node_range(source, node)` · [packages/svelte/src/compiler/migrate/index.js:L1818-L1841][f1]

Extends a labeled statement's range over its leading and trailing comments and pulls the start back to the beginning of its line when only whitespace precedes it.

**Notes.**

- condition: The backward scan resets to the node start if any non-space/non-tab character is met before a line break.

<a id="u-4cb15da8c8dc"></a>
### `guess_indent`

`function guess_indent(content)` · [packages/svelte/src/compiler/migrate/index.js:L1970-L1994][f1]

Infers indentation from the source: tabs win on ties or absence, otherwise the smallest leading-space width found is used.

**Notes.**

- condition: Returns '\t' when no indented lines exist or tabbed lines are at least as many as spaced lines; otherwise ' '.repeat(min) with min the minimum space-indent count.

<a id="u-11d2b2cd1c0c"></a>
### `handle_events`

`function handle_events(element, state)` · [packages/svelte/src/compiler/migrate/index.js:L1723-L1810][f1]

Converts on: directives into event attributes, wrapping modifiers and merging multiple handlers per event name.

**Notes.**

- condition: Directive expressions become the handler body; expression-less directives become a bubble('event') call with createBubbler imported and instantiated. Modifiers are applied in the fixed order preventDefault, stopPropagation, stopImmediatePropagation, self, trusted, once, each added to legacy imports; passive/nonpassive become use: actions and skip the attribute path.
- side_effect: For each event only the first directive survives: duplicates are removed (including preceding whitespace); multiple handlers are combined via a handlers(...) helper and the first directive's text is overwritten with the resulting onX attribute (capture appends 'capture' to the name).

<a id="u-f31d2d5b26f5"></a>
### `handle_identifier`

`function handle_identifier(node, state, path)` · [packages/svelte/src/compiler/migrate/index.js:L1848-L1967][f1]

Rewrites legacy $$props, $$restProps and $$slots identifiers in both walks, skipping non-object MemberExpression properties.

**Notes.**

- condition: Under uses_props, $$props/$$restProps become the generated props name and bindable-prop references get a `props.` prefix; otherwise $$restProps under uses_rest_props becomes the rest name. `$$slots.x` under uses_slots becomes a snippet reference: `default` maps to `children`, existing slot props are reused, non-default renames raise MigrationError, and first sightings register a type_only Snippet<[any]> prop flagged needs_refine_type; a bare $$slots identifier is left to error.
- side_effect: `$$Props` interface or type alias members update or create type_only props from each member's annotation and comments, then the whole declaration is removed.

raises: [index-js-migrationerror](r5-svelte-migration.md#u-9fa554fc7f25)

**Uncertainties.**

- Member key access (member.key.name, member.typeAnnotation.typeAnnotation) assumes TS node shapes guaranteed elsewhere.

<a id="u-0c9d6fc8a11a"></a>
### `migrate`

`export function migrate(source, { filename, use_ts } = {})` · [packages/svelte/src/compiler/migrate/index.js:L124-L275][f1]

First half of the exported migrate() entry point: prepares the source and analysis and builds the shared State consumed by the walker visitors.

**Notes.**

- side_effect: Resets global compiler state via reset() and blanks <style> bodies with recorded offsets restored into the MagicString afterwards.

calls: [packages/svelte/src/compiler/phases/1-parse/index.js:parse](r2-parse.md#u-53ab5f2b9b37), [index-js-analyze-component](r3-analysis-core.md#u-ff1515d9bcd2), [state.js-module-level-compiler-state](r2-compiler-infrastructure.md#u-d73d7b033038), [guess_indent](r5-svelte-migration.md#u-4cb15da8c8dc)

**Uncertainties.**

- The uses_ts detection reads attr.value[0].data on lang attributes with a cast, assuming text attributes; non-text values would misbehave in a way this file does not show.

<a id="u-14a64e806c9a"></a>
### `packages/svelte/src/compiler/migrate/index.js:migrate`

`export function migrate(source, { filename, use_ts } = {})` · [packages/svelte/src/compiler/migrate/index.js:L282-L459][f1]

Second half of migrate(): emits the $props() declaration, reorders legacy reactive statements, appends derived declarations, and turns failures into @migration-task fallbacks.

**Notes.**

- failure: Any exception is caught: non-MigrationError errors are additionally logged via console.error; both cases return the original source prefixed with a @migration-task comment.
- side_effect: The finally block logs a console reminder whenever has_migration_task was set.

calls: [migrate_css](r5-svelte-migration.md#u-437d8a4fa38f), [get_node_range](r5-svelte-migration.md#u-7acff5a27531); raises: [index-js-migrationerror](r5-svelte-migration.md#u-9fa554fc7f25)

**Uncertainties.**

- The reorder condition casts dep.node.start to number for non-prop dependencies; the analyzer guaranteeing non-null starts is not visible here.

<a id="u-437d8a4fa38f"></a>
### `migrate_css`

`function migrate_css(state)` · [packages/svelte/src/compiler/migrate/index.js:L41-L96][f1]

Wraps selector pseudo-class arguments in :global(...) when migrating a component's CSS, editing a separate MagicString because the source CSS text was already blanked.

**Notes.**

- side_effect: The rewritten CSS replaces the CSS AST range in state.str via update.

calls: [find_closing_parenthesis](r5-svelte-migration.md#u-97593ff10930)

**Uncertainties.**

- Offset arithmetic mixes indices from the copied string and the full CSS contents across several continue paths; the source does not prove insertions land correctly under unusual nesting.

<a id="u-4d888e7e32a9"></a>
### `migrate_slot_usage`

`function migrate_slot_usage(node, path, state)` · [packages/svelte/src/compiler/migrate/index.js:L1418-L1580][f1]

Rewrites Svelte 4 slot usage (slot attributes and let: directives on components, svelte:fragment, slot children) into snippets, bailing unless the node or its parent is a component.

**Notes.**

- failure: An invalid or reserved snippet name, or one shadowing a parent prop, prepends a @migration-task comment and aborts that node, skipping queued let-directive removals; valid names flush the removal queue after validation.
- side_effect: The `slot` attribute is removed (`default` becomes `children`); let: directives are removed and collected as snippet parameters. For the children snippet on non-fragment nodes, default content is kept inside a {#snippet} block, with interleaved default content moved back before named-slot content and the closing {/snippet} placed depending on whether named slots follow; named-slot or fragment nodes wrap the element itself, appending the closing tag via appendRight for SlotElement and appendLeft otherwise.

uses: [is_text_attribute](r5-compiler-utilities.md#u-ec400088cae5), [utils.js-element-attribute-predicates](r5-compiler-utilities.md#u-57e79fafa2c2)

**Uncertainties.**

- Content reordering for interleaved default/named slots manipulates single-character offsets (inner_end - 1); the source does not prove correctness when named and default content alternate more than once with adjacent text nodes.

<a id="u-cad9e2b4a6a0"></a>
### `trim_block`

`function trim_block(state, start, end)` · [packages/svelte/src/compiler/migrate/index.js:L1047-L1053][f1]

Trims whitespace inside a brace-delimited range, rewriting the interior between the braces only when trimming actually changes the content.

<a id="u-04a90805f3a2"></a>
### `BreakStatement`

`BreakStatement(node, { state, path })` · [packages/svelte/src/compiler/migrate/index.js:L916-L924][f1]

Converts a `break $` whose direct parent is the `$:` LabeledStatement into `return;`; all other break statements are left untouched.

<a id="u-c45889eebc7f"></a>
### `Comment`

`Comment(node, { state })` · [packages/svelte/src/compiler/migrate/index.js:L1365-L1370][f1]

Migrates svelte-ignore directives inside HTML comments, overwriting the comment body only when migrate_svelte_ignore changed the text.

<a id="u-d450a84d8bbe"></a>
### `ExportNamedDeclaration`

`ExportNamedDeclaration(node, { state, next })` · [packages/svelte/src/compiler/migrate/index.js:L542-L564][f1]

For bare export lists it removes specifiers whose local binding is a bindable_prop, deleting the whole declaration only when every specifier was removed.

**Notes.**

- condition: Declarations with a declaration property just descend; non-Identifier specifiers are skipped and prevent whole-node removal.

<a id="u-9982c4ec79f5"></a>
### `ImportDeclaration`

`ImportDeclaration(node, { state })` · [packages/svelte/src/compiler/migrate/index.js:L504-L541][f1]

Advances the props insertion point past each import and prunes unused beforeUpdate/afterUpdate specifiers from 'svelte' imports.

**Notes.**

- failure: If any such specifier still has references a MigrationError naming the imports aborts migration; if all specifiers were removed the whole statement is removed.

raises: [index-js-migrationerror](r5-svelte-migration.md#u-9fa554fc7f25)

**Uncertainties.**

- The removal end scans for the next ',' before the next '}' and then skips whitespace via original[end]; a specifier at end of file would read past the source.

<a id="u-ee80309dc8b0"></a>
### `packages/svelte/src/compiler/migrate/index.js:LabeledStatement`

`LabeledStatement(node, { path, state, next })` · [packages/svelte/src/compiler/migrate/index.js:L943-L1038][f1]

Migrates top-level `$:` statements into runes or run-wrapped code, after the s0 guards skip runes mode, nested or non-$ labels, and already-derived statements and visit children.

**Notes.**

- condition: Assignments whose bindings are all legacy_reactive become `let x = $derived(expr)` when the right side is a non-literal, no store subscription is involved and the left side is not a MemberExpression; a trailing paren is only added when the body is not already parenthesized.
- failure: check_rune_binding throws MigrationError when variables named derived or state shadow the runes.
- side_effect: Anything not converted becomes a run(() => { ... }) callback: block bodies are rewritten in place, single statements are wrapped, re-indented and closed with });, and the 'run' legacy import is registered.

raises: [index-js-migrationerror](r5-svelte-migration.md#u-9fa554fc7f25); calls: [extract_all_identifiers_from_expression](r5-compiler-utilities.md#u-4fc74297abd5), [extract_identifiers](r5-compiler-utilities.md#u-90eb95affc00)

<a id="u-447477721877"></a>
### `RegularElement`

`RegularElement(node, { state, path, next })` · [packages/svelte/src/compiler/migrate/index.js:L1060-L1073][f1]

Migrates slot usage and events on regular elements and rewrites self-closing tags into explicit open/close pairs.

**Notes.**

- condition: When the source ends the tag with `/>` and the name is neither void nor SVG, the slash is removed (backtracking over preceding spaces) and `</name>` appended; void and SVG elements keep their self-closing form.

calls: [migrate_slot_usage](r5-svelte-migration.md#u-4d888e7e32a9), [handle_events](r5-svelte-migration.md#u-11d2b2cd1c0c)

<a id="u-6be75180ef05"></a>
### `SlotElement`

`SlotElement(node, { state, path, next, visit })` · [packages/svelte/src/compiler/migrate/index.js:L1226-L1364][f1]

Converts <slot> elements into snippet renders, registering the corresponding snippet props on State (skipped for custom elements, which only get slot-usage migration).

**Notes.**

- condition: Slot props come from spread and normal attributes; a `slot` attribute is ignored and a `name` attribute sets the slot name, creating an aliased `{name}_render` in derived_conflicting_slots when an ancestor or the element itself also declares a same-named slot, or when a default-slot ancestor uses LetDirectives, to avoid shadowing.
- failure: If a non-default slot name would have to be renamed by scope.generate, a MigrationError aborts because the component would become unusable.
- side_effect: The element is replaced with `{#if name}{@render name(props)}{:else}...{/if}` when it has content, else `{@render name?.(props)}`, prefixed with the props namespace under uses_props; existing props typed Snippet<[any]> get refined when flagged needs_refine_type.

calls: [migrate_slot_usage](r5-svelte-migration.md#u-4d888e7e32a9); raises: [index-js-migrationerror](r5-svelte-migration.md#u-9fa554fc7f25)

**Uncertainties.**

- Attribute value slicing assumes first/last value nodes are Text or carry expression positions; other node shapes are not handled visibly here.

<a id="u-e57c073bc997"></a>
### `SvelteComponent`

`SvelteComponent(node, { state, next, path })` · [packages/svelte/src/compiler/migrate/index.js:L1140-L1209][f1]

Rewrites <svelte:component this={expr}> into a direct component reference, hoisting non-trivial expressions into a temporary binding.

**Notes.**

- condition: When the expression is not an Identifier or MemberExpression matching a valid component name, a generated name is bound via {@const} at the nearest enclosing EachBlock/AwaitBlock/IfBlock/SnippetBlock/Component/SvelteComponent; otherwise it is queued in derived_components for a $derived declaration, reusing an existing entry for the same expression.
- side_effect: The element name is overwritten in the open tag and in a matching close tag, and the this={...} attribute text is removed.

calls: [migrate_slot_usage](r5-svelte-migration.md#u-4d888e7e32a9)

**Uncertainties.**

- The close-tag overwrite relies on the raw source ending with the element name and the `this` scan walks backwards over whitespace; positions are assumed, not validated.

<a id="u-382ccc84af17"></a>
### `SvelteElement`

`SvelteElement(node, { state, path, next })` · [packages/svelte/src/compiler/migrate/index.js:L1111-L1135][f1]

Migrates slots and events on <svelte:element> and turns a static string tag into a braced expression tag.

**Notes.**

- condition: For a Literal tag, scanning backwards to '=' detects an intervening '{' (dynamic tag); if none is found and the closing quote follows, '{' and '}' are wrapped around the literal so it becomes an expression.

calls: [migrate_slot_usage](r5-svelte-migration.md#u-4d888e7e32a9), [handle_events](r5-svelte-migration.md#u-11d2b2cd1c0c)

<a id="u-5adc2dc68abc"></a>
### `SvelteSelf`

`SvelteSelf(node, { state, next })` · [packages/svelte/src/compiler/migrate/index.js:L1074-L1110][f1]

Replaces <svelte:self> with a self-import of the component, or defers with a migration task when the filename is unknown.

**Notes.**

- condition: Without a filename a @migration-task comment is prepended and has_migration_task set; otherwise the opening tag, the closing tag when a fragment exists, or the separate end tag of `<svelte:self></svelte:self>` is overwritten with the component name and has_svelte_self is set so migrate inserts the import.

**Uncertainties.**

- Closing-tag detection depends on raw source suffix checks (fragment presence and a trailing '/>'); malformed markup could overwrite the wrong range.

<a id="u-8c0aa73c8bca"></a>
### `VariableDeclaration`

`VariableDeclaration(node, { state, path, visit, next })` · [packages/svelte/src/compiler/migrate/index.js:L565-L712][f1]

Instance-scope variable declarations in non-runes mode: bindable-prop declarations are converted into State prop entries and their source text blanked.

**Notes.**

- failure: Non-Identifier bindable patterns and $$props combined with initialized or updated named props raise MigrationError.
- side_effect: When all declarations were props, the whole line (including an enclosing ExportNamedDeclaration) is removed and the props insertion point moves past it.

calls: [extract_type_and_comment](r5-svelte-migration.md#u-081e94041a1f); raises: [index-js-migrationerror](r5-svelte-migration.md#u-9fa554fc7f25)

**Uncertainties.**

- Multi-declaration removal ranges are computed from comma positions in the original source; correctness depends on those commas existing exactly where assumed.

<a id="u-6d4274e4dd3e"></a>
### `packages/svelte/src/compiler/migrate/index.js:VariableDeclaration`

`VariableDeclaration(node, { state, path, visit, next })` · [packages/svelte/src/compiler/migrate/index.js:L719-L915][f1]

Handles the state half of non-runes declarations: initialized declarators are wrapped in $state(...), uninitialized ones become $derived or $state depending on their labeled-statement updates.

**Notes.**

- failure: check_rune_binding throws MigrationError when a scope variable named state or derived would shadow the rune.
- condition: SequenceExpression initializers extend the wrap range outward to the enclosing parentheses before inserting $state.

raises: [index-js-migrationerror](r5-svelte-migration.md#u-9fa554fc7f25); calls: [extract_all_identifiers_from_expression](r5-compiler-utilities.md#u-4fc74297abd5)

**Uncertainties.**

- The possible_derived analysis relies on reference paths containing the labeled assignment; whether every reference carries such paths is decided in the analyzer, not here.

<a id="u-d0f59bc5501b"></a>
### `_`

`const instance_script = { _(node, { state, next })` · [packages/svelte/src/compiler/migrate/index.js:L485-L500][f1]

Fallback instance-script visitor that rewrites // style svelte-ignore comments in place via migrate_svelte_ignore, overwriting only when the text changed, then continues traversal.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/migrate/index.js
