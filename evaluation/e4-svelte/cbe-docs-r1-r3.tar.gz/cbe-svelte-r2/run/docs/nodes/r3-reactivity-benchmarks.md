# Reactivity Benchmarks

**Capability.** Times two reactivity workloads (broad fan-out to many derived chains, and a multiplexed aggregate) and compares results across git branches via a parent/child-process runner.

Use this subtree to measure scheduler performance. The benchmark files are standalone timing scripts; compare/index orchestrates branches and prints a chart, while runner.js executes benchmarks in a child process.

Parent: [Tooling and Developer Environment](r3-tooling.md)

## Units (5)

<a id="u-90d8b37ebf5a"></a>
### `kairo_broad-js`

`function setup()` · [benchmarking/benchmarks/reactivity/kairo/kairo_broad.js:L4-L27][f1]

Fans one state signal out to 50 independent two-step derived chains and times updates that every branch must recompute.

setup() creates state head and, inside $.effect_root, loops i=0..49 creating derived current=head+i, derived current2=current+1, and a render_effect that reads current2 and increments a shared counter; last ends up bound to the i=49 chain. run() flushes head=1, resets counter to 0, then for i=0..49 flushes head=i and asserts get(last)===i+50; after the loop it asserts counter===50*50, i.e. all 50 render effects re-ran on all 50 updates. kairo_broad_unowned performs 10 JIT-warmup setup/run/destroy cycles, then awaits fastest_test(10, 1000 run() calls), destroys, and returns {benchmark, time, gc_time} with toFixed(2) timings. kairo_broad_owned runs the warmup and the retained setup inside one $.effect_root (handle destroy_owned), assigns the final run/destroy to outer variables, times identically, then calls destroy() and destroy_owned().

uses: [assert](r4-benchmark-harness.md#u-823bd0dd0cd8); calls: [fastest_test](r4-benchmark-harness.md#u-0bbe8c671495)

**Uncertainties.**

- Behavior of svelte/internal/client primitives is not observable in this file.

<a id="u-b047c854e5f5"></a>
### `kairo_mux-js`

`function setup()` · [benchmarking/benchmarks/reactivity/kairo/kairo_mux.js:L4-L23][f2]

Multiplexes 100 state signals through one aggregated derived object and 100 per-index split deriveds, then times updating a slice of them.

setup() fills an array of 100 $.state(0) signals; mux is a derived returning Object.fromEntries of all head values; splited maps each index to derived(get(mux)[index]) then to derived(that+1), and a render_effect per split reads it inside $.effect_root. run() only touches the first 10 heads: first loop sets heads[i]=i and asserts splited[i]===i+1; second loop sets heads[i]=i*2 and asserts splited[i]===i*2+1. kairo_mux_unowned runs 10 JIT-warmup setup/run/destroy cycles, awaits fastest_test(10, 1000 run() calls), destroys and returns {benchmark, time, gc_time} via toFixed(2). kairo_mux_owned performs warmup and retains one setup inside a single $.effect_root (destroy_owned), assigns run/destroy to outer variables, times identically, then calls destroy() and destroy_owned().

uses: [assert](r4-benchmark-harness.md#u-823bd0dd0cd8); calls: [fastest_test](r4-benchmark-harness.md#u-0bbe8c671495)

**Uncertainties.**

- Whether untouched heads' splited deriveds re-run depends on mux/split equality semantics in svelte/internal/client, not observable here.

<a id="u-8fce20afc2b5"></a>
### `index.js module code (L1–L100)`

`module_region` · [benchmarking/compare/index.js:L1-L100][f3]

Runs benchmarks on one or more git branches and prints a comparison chart.

It resolves sibling paths (runner.js, .results), clears and recreates the results directory, collects branch names from CLI args (skipping anything starting with '--' and the script's own path), falls back to the current branch via git when none given, and appends 'main' when only one branch is supplied. It registers an exit handler that checks out branches[0] before terminating, then for each branch checks out that branch, forks runner.js, and waits for a child message, writing the message as formatted JSON to .results/<branch>.json; child errors reject the awaited promise. After all branches run, it re-reads each JSON file and, for each benchmark index and each of the 'time' and 'gc_time' metrics, finds the min/max times; if the minimum is nonzero it prints a 20-character bar chart where bar length is round(20 * time / max) and each row is labeled by a letter via char(), with the fastest branch announced. Side effects: git checkout commands, filesystem writes/deletes, child process fork, console output. Note that a zero minimum metric suppresses that metric's chart entirely, and bar length scales against the maximum, so slower branches get longer bars.

**Notes.**

- side_effect: The 'exit' handler restores branches[0] via git checkout, so the working tree ends on the first branch listed or defaulted.
- condition: Metrics whose minimum time is 0 skip chart printing for that metric because relative ratios would be undefined.
- failure: If the forked runner errors, the awaited promise rejects; subsequent behavior (propagation to top level) is not visible in this file.

calls: [char](r3-reactivity-benchmarks.md#u-f47de227b133); uses: [runner.js module code (L1–L10)](r3-reactivity-benchmarks.md#u-0b0dc218fb67)

**Uncertainties.**

- The shape of result objects received from the child (benchmark name and metric fields) is inferred from usage in JSON output and chart indexing, not from the runner's internals beyond its reactivity_benchmarks loop.

<a id="u-f47de227b133"></a>
### `char`

`function char(i)` · [benchmarking/compare/index.js:L101-L103][f3]

Maps a zero-based index to a lowercase letter label for chart rows.

<a id="u-0b0dc218fb67"></a>
### `runner.js module code (L1–L10)`

`module_region` · [benchmarking/compare/runner.js:L1-L10][f4]

Child-process runner that awaits each reactivity benchmark in order, logs the benchmark name to stderr, accumulates results, and sends the full array to the parent via process.send once all complete.

Iteration is sequential because each benchmark is awaited before the next; a rejection in any benchmark aborts the loop and process.send never runs.

uses: [index.js module code (L1–L100)](r3-reactivity-benchmarks.md#u-8fce20afc2b5)

**Uncertainties.**

- The contract of each benchmark callable and the shape of its result object are defined in benchmarking/benchmarks/reactivity, which is not supplied here.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/benchmarking/benchmarks/reactivity/kairo/kairo_broad.js
[f2]: ../../../../../../eval/svelte-be645b4/benchmarking/benchmarks/reactivity/kairo/kairo_mux.js
[f3]: ../../../../../../eval/svelte-be645b4/benchmarking/compare/index.js
[f4]: ../../../../../../eval/svelte-be645b4/benchmarking/compare/runner.js
