# Server Transform

**Capability.** Serializes the AST into server payload-rendering code: head content, store-subscription updates, and shared utilities that coalesce template output and build attribute values and getters.

Use this subtree for SSR code emission. shared/utils.js supplies build_template, process_children, build_attribute_value, and build_getter used across server visitors; individual visitors handle svelte:head and store updates.

Parent: [Code Generation \(Phase 3\)](r4-codegen-transform.md)

## Units (7)

<a id="u-9e86d472de3c"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/SvelteHead.js:SvelteHead`

`export function SvelteHead(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/SvelteHead.js:L10-L16][f1]

Renders `<svelte:head>` by visiting its fragment and pushing `$.head($$payload, ($$payload) => block)` into the template, deferring head content rendering to the runtime.

<a id="u-4fbc61d80839"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/UpdateExpression.js:UpdateExpression`

`export function UpdateExpression(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/UpdateExpression.js:L9-L26][f2]

Rewrites `++`/`--` on store subscriptions.

If the argument is an Identifier whose binding kind is 'store_sub', it emits `$.update_store_pre` (prefix) or `$.update_store` (postfix) with a lazy `$$store_subs ??= {}` init, the original `$name` literal, the store id `name.slice(1)`, and a literal -1 only for the `--` operator (undefined otherwise, meaning +1). Any other update expression continues via context.next().

**Uncertainties.**

- Whether the runtime treats an undefined final argument as +1 is not shown here

<a id="u-8ce176223a22"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/utils.js:build_attribute_value`

`export function build_attribute_value( value, context, trim_whitespace = false, is_co…` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/utils.js:L185-L233][f3]

Serializes an attribute value into an expression.

A shorthand attribute (value === true) yields b.true. A single chunk (non-array or one-element array) yields the raw/trimmed Text literal — HTML-escaped via escape_html(data, true) unless is_component is set, in which case the plain text is used — or the visited expression for ExpressionTags. Multi-chunk values build a template literal: Text chunks append their (optionally whitespace-collapsed) data to the raw quasi, expression chunks contribute a visited expression wrapped in $.stringify and start a new quasi whose tail flag marks the last chunk.

calls: [escape_html](r2-server-render.md#u-0f499dd45547)

**Uncertainties.**

- The is_component=true variant returning unescaped text is relied on by build_inline_component; whether consumers escape later is outside this file.

<a id="u-25646e8536b2"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/utils.js:build_getter`

`export function build_getter(node, state)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/utils.js:L240-L259][f3]

Builds the read expression for an identifier reference during server transforms.

If the scope has no binding for the name, or the reference is the binding's own declaration node, the identifier is returned unchanged. Store subscriptions ($-prefixed, binding.kind === 'store_sub') become $.store_get($$store_subs ??= {}, '<name>', <getter for the store name without $>), recursing so the underlying store identifier is itself resolved; all other bindings are returned unchanged on the server.

calls: [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/utils.js:build_getter](r4-server-transform.md#u-25646e8536b2)

**Uncertainties.**

- Whether the recursion can loop depends on binding metadata built elsewhere; only the store_sub case recurses in this source.

<a id="u-7d424d7f2d77"></a>
### `build_template`

`export function build_template(template, out = b.id('$$payload.out'), operator = 'push')` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/utils.js:L102-L112][f3]

Converts a mixed list of statements and expressions into output statements appending to (or assigning) an output identifier, defaulting to $$payload.out with operator 'push'.

Consecutive expressions are merged into one template literal: Literals append their string value to the current quasi; TemplateLiterals contribute their first quasi's cooked text to the current string, extend the string list with their remaining quasis, and merge their expressions; other expressions append an expression and start a new quasi. A leading empty quasi is seeded so the first expression has a preceding string. When a statement node (per is_statement) appears, any pending strings are flushed first and the statement is emitted verbatim; the remaining strings flush at the end. flush emits either an out.push(template) call or an assignment using the given operator, then resets the buffers.

<a id="u-1794509e2816"></a>
### `is_statement`

`function is_statement(node)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/utils.js:L92-L94][f3]

Type predicate: true when the node's type ends with 'Statement' or 'Declaration', used by build_template to distinguish statements from expressions in the template array.

<a id="u-e9ea6b8060a4"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/utils.js:process_children`

`export function process_children(nodes, { visit, state })` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/utils.js:L30-L34][f3]

Walks a template's child nodes, coalescing runs of adjacent Text, Comment, and ExpressionTag nodes into single template literals and delegating other nodes to visit with a copied state.

flush builds a template literal from the pending run: Text contributes escape_html(data) to the cooked quasi; Comment contributes an HTML comment literal; ExpressionTags whose expression the scope evaluator marks as known contribute their stringified value to the cooked quasi, while unknown expressions contribute a visited $.escape(...) call and start a new quasi whose tail flag marks the final quasi. All cooked quasis are copied into raw via sanitize_template_string and the b.template is pushed to state.template. A flush occurs whenever a non-textual node interrupts a run and once at the end.

calls: [sanitize_template_string](r2-compiler-infrastructure.md#u-01781e43d6ff), [escape_html](r2-server-render.md#u-0f499dd45547)

**Uncertainties.**

- state.scope.evaluate's classification of 'known' values is defined in scope.js and not shown here.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/SvelteHead.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/UpdateExpression.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/utils.js
