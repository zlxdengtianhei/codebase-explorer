# Parse Utilities

**Capability.** Provides standalone helpers used during parsing: fragment construction, the HTML named-entity table, and fuzzy-name matching for suggestions.

Consult this subtree when tracing how the parser builds fragments, resolves HTML entities, or produces 'did you mean' suggestions. Fuzzy matching is self-contained, from the n-gram FuzzySet down to the Levenshtein implementation.

**Depended on by.**

- [Accessibility Checks](r3-a11y-checks.md) · graph-confirmed · 2 edge(s)
- [Template Parsing](r6-compiler-parse.md) · graph-only · 12 edge(s)

Parent: [Compiler](r3-compiler.md)

## Units (9)

<a id="u-6f16c2773335"></a>
### `create_fragment`

`export function create_fragment(transparent = false)` · [packages/svelte/src/compiler/phases/1-parse/utils/create.js:L7-L17][f1]

Builds a fresh, empty AST Fragment node.

The optional boolean `transparent` (default false) is stored in metadata.transparent; metadata.dynamic and metadata.has_await are always false and nodes is always empty. Each call returns a new object, so mutating one fragment never affects another.

<a id="u-67f1922eebb8"></a>
### `entities-js-default-export-table`

`module_region` · [packages/svelte/src/compiler/phases/1-parse/utils/entities.js:L2-L1682][f2]

Holds a single default-exported object mapping HTML named character references to their numeric code points.

Keys are entity names from the WHATWG entities.json table, mostly including the trailing semicolon (e.g. 'CounterClockwiseContourIntegral;'), with a subset of legacy, semicolon-less names (e.g. Aacute, amp, gt, lt, nbsp, quot) also present, sometimes coexisting with their semicolon-bearing variants. Values are integer code points. The table is pure static data: no functions, no control flow, no side effects; consumers (the parser's entity decoder, not shown here) look names up in this object, and any name absent from it has no mapping. The file is organized alphabetically in descending blocks, but ordering has no behavioral effect. Uncertainty: whether lookups are case-sensitive and how longest-prefix matching is handled lives in the consumer code, not here.

**Uncertainties.**

- Lookup semantics (exact match vs. prefix matching, case sensitivity) are determined by consumers of this table, which are outside the supplied source.
- The source comment cites the WHATWG entities.json but code points were not verified against the spec.

<a id="u-4d517976b3f9"></a>
### `fuzzymatch`

`export default function fuzzymatch(name, names)` · [packages/svelte/src/compiler/phases/1-parse/utils/fuzzymatch.js:L6-L13][f3]

Suggests the closest entry of `names` to `name`, or null.

An empty names list returns null immediately. Otherwise a FuzzySet is built from names and queried; the top match is returned only when its score exceeds 0.7, otherwise null. Comparison is case-insensitive because the set normalizes to lowercase.

calls: [FuzzySet](r3-parse-utilities.md#u-1a1551cf741f)

**Uncertainties.**

- When get returns a non-empty list, matches[0][0] is assumed numeric; the > 0.7 threshold is the only acceptance criterion.

<a id="u-1a1551cf741f"></a>
### `FuzzySet`

`class FuzzySet` · [packages/svelte/src/compiler/phases/1-parse/utils/fuzzymatch.js:L123-L134][f3]

Case-insensitive fuzzy-match set adapted from Glench/fuzzyset.js.

The constructor initializes empty per-gram-size item lists (sizes 2 and 3) and adds every input string via add, so duplicates are silently dropped (add returns false without indexing a normalized value already in exact_set). add/_add index each string twice (bigram and trigram), storing vector norms and original strings; get first checks for an exact (case-insensitive) hit and otherwise queries trigram, then bigram, returning the first size that yields results, or null. __get scores candidates by shared-gram cosine similarity, sorts, truncates to 50, recomputes scores as _distance-based edit similarity, re-sorts, and keeps only entries tied with the top score, mapping back to original-cased strings via exact_set. match_dict maps gram → list of [item index, count] across all indexed strings.

**Uncertainties.**

- If this.items[gram_size] is missing in _add, `items` starts as a fresh array, but the resulting match_dict entries then reference indexes of an array later assigned back to the same key; behavior for unexpected gram sizes is not exercised.
- __get divides by items[match_index][0] (the stored vector norm); a missing index would read from undefined and throw, but that path is not reachable via the public add/get flow shown.

<a id="u-53c64f37672a"></a>
### `_distance`

`function _distance(str1, str2)` · [packages/svelte/src/compiler/phases/1-parse/utils/fuzzymatch.js:L27-L37][f3]

Returns a normalized edit distance in 0–1 between two strings: 1 minus levenshtein divided by the longer length.

Two nulls throw a string-typed error; a single null returns 0 (perfect match, per upstream fuzzyset behavior). Inputs are coerced with String before comparison.

calls: [levenshtein](r3-parse-utilities.md#u-1ed726d7da45)

<a id="u-1ed726d7da45"></a>
### `levenshtein`

`function levenshtein(str1, str2)` · [packages/svelte/src/compiler/phases/1-parse/utils/fuzzymatch.js:L45-L69][f3]

Computes the Levenshtein edit distance with a single rolling row (`current`), iterating rows over str2 and columns over str1.

Matching characters carry `prev` forward; mismatches take 1 + the minimum of the left, upper-left, and upper cells. Boundary cells (i or j zero) hold i + j. Returns the last cell via current.pop().

uses: [_distance](r3-parse-utilities.md#u-53c64f37672a)

<a id="u-500fe48ba9fb"></a>
### `gram_counter`

`function gram_counter(value, gram_size = 2)` · [packages/svelte/src/compiler/phases/1-parse/utils/fuzzymatch.js:L97-L113][f3]

Counts occurrences of each gram produced by iterate_grams, returning a Record keyed by gram with positive integer counts.

Delegates all normalization to iterate_grams.

calls: [iterate_grams](r3-parse-utilities.md#u-883c73062dca)

<a id="u-883c73062dca"></a>
### `iterate_grams`

`function iterate_grams(value, gram_size = 2)` · [packages/svelte/src/compiler/phases/1-parse/utils/fuzzymatch.js:L77-L91][f3]

Produces character n-grams (default bigrams) of the lowercased value after stripping characters matching /[^
, ]+/ (i.e. keeping word chars, commas, spaces) and padding with '-' on both ends.

If the gram size exceeds the simplified length, extra '-' are appended to `value` (note: the loop appends to the variable `value`, but the grams are still sliced from the padded `simplified`, so the padding loop has no effect on the output). Returns all sliding windows of length gram_size.

**Uncertainties.**

- The len_diff padding loop mutates `value`, not `simplified`; its observable effect on the returned grams is not apparent from the source.

<a id="u-388181d4f9b2"></a>
### `sort_descending`

`function sort_descending(a, b)` · [packages/svelte/src/compiler/phases/1-parse/utils/fuzzymatch.js:L119-L121][f3]

Comparator for [score, string] tuples sorting by score descending (b[0] - a[0]).

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/1-parse/utils/create.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/1-parse/utils/entities.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/1-parse/utils/fuzzymatch.js
