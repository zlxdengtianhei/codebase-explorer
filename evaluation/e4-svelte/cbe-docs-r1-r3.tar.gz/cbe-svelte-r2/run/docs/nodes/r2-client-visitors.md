# Client transform visitors

**Capability.** Visitors that serialize AST nodes into client output: Program installs top-level $$props/store/prop read-write transforms, RegularElement emits template construction plus attribute/class/style init and update statements, KeyBlock lowers {#key}.

Read Program for the top-level binding transforms, then RegularElement and its build_* helpers for attribute emission details. These visitors consume the signal builders and shared fragment/namespace utilities and consult module-level compiler state.

**Depends on.**

- [Client signal builders](r2-client-signal-builders.md) · graph-confirmed · 4 edge(s) · Client visitors construct emitted runtime call expressions (getters, prop sources, deriveds) through the signal builders.
- [Diagnostics, state and validation infrastructure](r2-compiler-infrastructure.md) · graph-confirmed · 1 edge(s)
- [Shared transform utilities](r2-transform-shared.md) · graph-confirmed · 2 edge(s)
- [Compiler Utilities and AST Helpers](r5-compiler-utilities.md) · graph-only · 12 edge(s)
- [Client Transform](r3-client-transform.md) · graph-only · 10 edge(s)
- [Client Transform](r5-client-transform.md) · graph-only · 10 edge(s)

**Depended on by.**

- [Build and repo tooling](r2-build-tooling.md) · graph-confirmed · 2 edge(s)

Parent: [Client code generation](r2-client-transform.md)

## Units (9)

<a id="u-ba1f8c9b6c22"></a>
### `Program`

`export function Program(_, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/Program.js:L11-L49][f1]

Installs the top-level read/assign/mutate/update transforms for `$$props`, legacy reactive imports, store subscriptions, and prop/bindable props before continuing traversal.

In legacy mode it maps `$$props` reads to `$$sanitized_props`, and for mutated instance-scope imports (detected by source-position comparison against the instance script AST, since declarations are hoisted) it creates a `$$_import_<name>` variable backed by `$.reactive_import` with read/mutate transforms. For each `store_sub` binding it installs a lazily cached store reference: reads become calls, assignment uses `$.store_set`, mutation builds `$.store_mutate` with the store read untracked (recursively replacing member-expression targets with the untracked read) for Svelte 4 consistency, and updates use `$.update_store`/`$.update_pre_store` with a -1 literal for `--`. For prop and bindable_prop bindings: when the prop is a source, reads/writes go through prop calls, with bindable mutations passing a `true` flag for legacy-parent interop, and updates via `$.update_prop`/`$.update_pre_prop`; otherwise reads access `$$props` directly, using the prop alias as a member key when aliased.

calls: [build_getter](r2-client-signal-builders.md#u-66a19e20e1f1), [is_prop_source](r2-client-signal-builders.md#u-38b8a75ee741), [add_state_transformers](r5-client-transform.md#u-32bec314643f)

**Uncertainties.**

- context.visit for the store identifier uses transform state defined elsewhere; the cached value's exact shape depends on that visit
- position-based instance-import detection assumes node.start/end are populated, which the casts acknowledge

<a id="u-2bcd841aee06"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/KeyBlock.js:KeyBlock`

`export function KeyBlock(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/KeyBlock.js:L11-L38][f2]

Serializes {#key} blocks into a `$.key` runtime call.

The key expression is built with build_expression; with await it reads `$.get($$key)`, otherwise it is used directly as the thunk. The visited fragment becomes the `$$anchor` arrow body. The add_svelte_meta-wrapped `$.key(node, key, anchor)` statement is pushed to init directly, or — when the expression has await — wrapped in `$.async(node, [thunk(expression, true)], (node, $$key) => [statement])` first.

calls: [build_expression](r5-client-transform.md#u-cd5eb51d389f), [add_svelte_meta](r5-client-transform.md#u-75700db42066)

<a id="u-f2ea5a46376e"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/RegularElement.js:RegularElement`

`export function RegularElement(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/RegularElement.js:L32-L404][f3]

Serializes a regular element into template construction plus init/update statements.

It pushes the element onto the template, returning early for `noscript`, and sets template flags: `needs_import_node` for video or custom elements (cloneNode would not instantiate custom-element classes; Webkit needs importNode for video autoplay) and `contains_script_tag` for script tags. Attributes are partitioned by type; `let:` directives are visited first to set state; OnDirectives are visited eagerly and become a `$.effect` thunk when any `use:` exists, otherwise they are appended to after_update. For `input`, `$.remove_input_defaults` is emitted when there is a spread, a value/checked/group binding, or a dynamic value/checked attribute without a defaultValue/defaultChecked; for `textarea`, `$.remove_textarea_child` when spread, a value binding, or a dynamic value/checked attribute exists. A select with `bind:value` triggers setup_select_synchronization. Without spreads, static text/boolean attributes are baked into the template (`set_prop`; boolean attributes rendered valueless), with the scoped-CSS hash appended to static class; `autofocus` becomes `$.autofocus` in init, class and style go through build_set_class/build_set_style, custom elements get build_custom_element_attribute_update_assignment, and everything else gets build_element_attribute_update pushed to update when stateful, init otherwise. Attributes named `value` when needs_special_value_handling (option/select, group or checked bindings) are deferred to build_element_special_value_attribute. With spreads, build_attribute_effect handles all attributes. Load/error elements with spread, use:, or onload/onerror get `$.replay_events` in after_update. Children: clean_nodes splits hoisted and trimmed nodes; all-text, non-reactive trimmed children containing an ExpressionTag become a single textContent assignment (skipped when it evaluates to the empty string), otherwise process_children visits them, entering `.content` and calling `$.hydrate_template` for `<template>`, and emitting `$.reset` when non-text children may leave hydrate_node set. Emission: with SnippetBlock children the child and element statements are wrapped in a block to avoid declaration conflicts (including a render statement when child updates exist); if the fragment is dynamic the arrays are merged into context state; otherwise only element statements are kept. A `dir` attribute triggers a self-assignment in update to fix a Chromium direction bug.

calls: [setup_select_synchronization](r2-client-visitors.md#u-97c8dc804a3c), [build_attribute_effect](r3-client-transform.md#u-0abd8487f7a1), [build_set_class](r3-client-transform.md#u-d08767f6fc10), [build_set_style](r3-client-transform.md#u-b481933571c2), [visit_event_attribute](r4-client-transform.md#u-8ff2bf148b08), [fragment.js-process_children](r5-client-transform.md#u-c8d8a77dfc05), [clean_nodes](r2-transform-shared.md#u-2ed26069223c), [determine_namespace_for_children](r2-transform-shared.md#u-fca641f4927b), [build_element_attribute_update](r2-client-visitors.md#u-b303d9b490e9), [build_custom_element_attribute_update_assignment](r2-client-visitors.md#u-4cdf2f9f4041), [build_element_special_value_attribute](r2-client-visitors.md#u-d69720843218)

**Uncertainties.**

- The `is` attribute becomes a template prop only when its serialized value is a string literal in an html namespace; other cases fall into the general attributes list, whose handling is spread-dependent.
- Behavior of context.visit for bind/animate/transition/use/attach directives is delegated and not visible in this file.
- How the memoizer callback passed to build_attribute_value caches values is defined in shared/utils.js, not here.

<a id="u-93d4778b5497"></a>
### `build_class_directives_object`

`export function build_class_directives_object( class_directives, context, memoizer = …` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/RegularElement.js:L468-L487][f3]

Builds the object expression passed to class-setting runtime helpers from `class:` directives.

Each directive's expression is visited and added as a property keyed by the directive name. If any directive expression has a call, state, or await, the resulting object is registered with the memoizer (await-aware) so it is shared across init and update; otherwise the plain object expression is returned. The memoizer defaults to the context state's memoizer.

calls: [Memoizer](r5-client-transform.md#u-76b08484949a)

<a id="u-4cdf2f9f4041"></a>
### `build_custom_element_attribute_update_assignment`

`function build_custom_element_attribute_update_assignment(node_id, attribute, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/RegularElement.js:L613-L624][f3]

Serializes an attribute assignment on a custom element as a `$.set_custom_element_data` call, preserving attribute-name case because the runtime may set a case-sensitive property.

The value is built via build_attribute_value; if it has state, the call is wrapped in `$.template_effect` with a thunk. Unlike other attribute updates the statement is always pushed to init and never grouped into an update array, because set_custom_element_data may not be idempotent.

calls: [build_attribute_value](r3-client-transform.md#u-2462157783c9)

<a id="u-b303d9b490e9"></a>
### `build_element_attribute_update`

`function build_element_attribute_update(element, node_id, name, value, attributes)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/RegularElement.js:L552-L605][f3]

Produces the expression that applies one attribute update, choosing the runtime call by attribute name.

`muted` becomes a direct property assignment (Firefox requirement), `value`/`checked`/`selected` become `$.set_value`/`$.set_checked`/`$.set_selected`. `defaultValue` becomes `$.set_default_value` when a static text `value` attribute also exists or the element is a non-empty textarea, and `defaultChecked` becomes `$.set_default_checked` when a static `checked` attribute exists — both to avoid updating the current value of a pristine input. Known DOM properties become plain property assignments; everything else becomes `$.set_xlink_attribute` for names starting with `xlink`, otherwise `$.set_attribute`, with a final boolean argument passing `true` when the `hydration_attribute_changed` warning is ignored.

calls: [state.js-module-level-compiler-state](r2-compiler-infrastructure.md#u-d73d7b033038); uses: [utils.js-element-attribute-predicates](r5-compiler-utilities.md#u-57e79fafa2c2)

**Uncertainties.**

- Docstring says the function returns a reactive boolean, but the implementation returns only the update expression; reactivity is decided by the caller via has_state.

<a id="u-d69720843218"></a>
### `build_element_special_value_attribute`

`function build_element_special_value_attribute(element, node_id, attribute, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/RegularElement.js:L635-L685][f3]

Serializes the `value` attribute of `<select>`, `<option>` or group/checked inputs that need the hidden `__value` property.

The value expression is built via build_attribute_value with memoization for calls/awaits, then scope-evaluated. For a select with a dynamic, non-text value it emits a sequence: assign `__value`, then `element.value` from the evaluated value (falling back to '' via `??` unless the value is defined), then `$.select_option` — enforcing a one-way DOM update even for non-bound selects. Reactive values get a generated `${node_id}_value` variable: initialized to `{}` for `<option>` (so undefined still triggers a change to the empty string), with update guarded by a `!==` check; non-reactive values go straight to init. A select with value additionally gets `$.init_select` in init.

calls: [build_attribute_value](r3-client-transform.md#u-2462157783c9), [Memoizer](r5-client-transform.md#u-76b08484949a); uses: [is_text_attribute](r5-compiler-utilities.md#u-ec400088cae5)

**Uncertainties.**

- `evaluated.is_defined` comes from scope evaluation elsewhere; its exact predicate is not visible here.

<a id="u-29f008b00f20"></a>
### `build_style_directives_object`

`export function build_style_directives_object( style_directives, context, memoizer = …` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/RegularElement.js:L495-L522][f3]

Builds the argument(s) for style-setting runtime helpers from `style:` directives.

Directives split into a `normal` and an `important` object by the `important` modifier. A directive with value `true` serializes as a getter for a variable named after the directive; otherwise its value is built via build_attribute_value. If any expression has a call, state, or await, the result is memoized; otherwise returned directly. The result is the normal object alone when no `important` directives exist, otherwise an array of [normal, important].

calls: [build_getter](r2-client-signal-builders.md#u-66a19e20e1f1), [Memoizer](r5-client-transform.md#u-76b08484949a)

<a id="u-97c8dc804a3c"></a>
### `setup_select_synchronization`

`function setup_select_synchronization(value_binding, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/RegularElement.js:L412-L460][f3]

Emits a template_effect for `bind:value` on `<select>` so indirect updates to inner signals re-synchronize the binding.

It returns immediately in runes mode or when the bound expression is a SequenceExpression. It unwraps the bound expression through member-expression objects to a base name, then collects every other scope reference name with references (skipping the bound name itself to prevent an infinite loop) and serializes each via build_getter into a `$.invalidate_inner_signals` thunk. The emitted template_effect body first evaluates the bound expression, then calls the invalidator, so changes to any referenced signal force the select binding to refresh.

calls: [build_getter](r2-client-signal-builders.md#u-66a19e20e1f1)

**Uncertainties.**

- Whether the bound base name resolves to an Identifier in all non-sequence cases is assumed (the invalidator loop compares name !== bound.name, implying an object with a name).

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/Program.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/KeyBlock.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/RegularElement.js
