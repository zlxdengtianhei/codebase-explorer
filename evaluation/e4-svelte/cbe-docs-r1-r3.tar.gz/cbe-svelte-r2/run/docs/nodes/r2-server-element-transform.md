# Server element serialization

**Capability.** Renders a regular element's opening tag, attributes, children and closing tag directly into the server template.

This single visitor mirrors the client RegularElement work for SSR output. It relies on the same shared fragment-cleaning and namespace-inference utilities as the client transform.

**Depends on.**

- [Shared transform utilities](r2-transform-shared.md) · graph-confirmed · 2 edge(s) · The SSR element visitor reuses the shared fragment-cleaning and namespace-inference helpers also used by the client element visitor.

Parent: [Compiler](r2-compiler.md)

## Units (1)

<a id="u-7055b95dd599"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/RegularElement.js:RegularElement`

`export function RegularElement(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/RegularElement.js:L17-L188][f1]

Renders a regular element's opening tag, attributes, children, and closing tag into the template.

It determines the child namespace (widening `preserve_whitespace` for pre/textarea), pushes the literal `<name`, collects attributes via build_element_attributes (whose returned body expression is used for textarea/contenteditable value bindings), then pushes `/>` for void elements or `>` (XHTML compliance). A lone-child script/style element is emitted verbatim as text plus closing tag. Otherwise children are cleaned with the fragment's own scope and visited. In dev, `$.push_element($$payload, name, line, column)` is pushed before children and `$.pop_element()` after. Special handling: a `<select>` with a value attribute/binding, or any spread attribute, records `$$payload.select_value`; a valueless `<option>` renders its children inside a `$.valueless_option` thunk; when a body expression exists it is bound (to a temporary if not already an identifier) and used as an if — truthy body replaces children, else the inner template renders. After children, a select with value resets `$$payload.select_value` to void 0, the closing tag is pushed for non-void elements, and `$.pop_element()` again in dev.

calls: [build_element_attributes](r3-server-transform.md#u-50884bbfafdd), [clean_nodes](r2-transform-shared.md#u-2ed26069223c), [determine_namespace_for_children](r2-transform-shared.md#u-fca641f4927b), [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/utils.js:build_attribute_value](r4-server-transform.md#u-8ce176223a22), [build_spread_object](r3-server-transform.md#u-3629ffc7b235), [utils.js-element-attribute-predicates](r5-compiler-utilities.md#u-57e79fafa2c2), [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/utils.js:process_children](r4-server-transform.md#u-e9ea6b8060a4), [build_template](r4-server-transform.md#u-7d424d7f2d77)

**Uncertainties.**

- The exact return value contract of build_element_attributes (body expression vs null) is defined in shared/element.js
- Behavior of `$.valueless_option`, `$.push_element`/`$.pop_element` at runtime is outside this file

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/RegularElement.js
