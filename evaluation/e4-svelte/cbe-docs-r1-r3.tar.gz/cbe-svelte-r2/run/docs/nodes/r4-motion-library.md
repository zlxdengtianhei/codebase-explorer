# Motion Library

**Capability.** Spring and tweened animation primitives with their public/private type surfaces, eager prefersReducedMotion signal, and shared value-type detection (is_date) used for interpolation.

Use this subtree for svelte/motion. index.js re-exports and constructs prefersReducedMotion at load; public.d.ts/private.d.ts declare the Spring and options types; utils.js is_date is the shared type guard consumed (model-inferred) by spring and tweened.

**Depends on.**

- [Reactive Built-in Wrappers](r4-reactivity-library.md) · model-inferred · 0 edge(s)

**Depended on by.**

- [Public API Type Surface](r4-public-api-types.md) · model-inferred · 0 edge(s)

Parent: [Svelte Codebase](r4-svelte-codebase.md)

## Units (4)

<a id="u-fe5771212e14"></a>
### `index.js module code (L1–L32)`

`module_region` · [packages/svelte/src/motion/index.js:L1-L32][f1]

Re-exports the spring and tweened motion modules and exposes prefersReducedMotion, a reactive MediaQuery signal matching the CSS '(prefers-reduced-motion: reduce)' query, constructed eagerly at module load.

Consumers branch animations on the user's OS-level reduced-motion preference via its current value.

imports: [spring.js module code (L1–L22)][f2], [tweened.js module code (L1–L19)][f3]

**Uncertainties.**

- MediaQuery behavior lives outside this batch.

<a id="u-d68a2069d749"></a>
### `TickContext`

`export interface TickContext` · [packages/svelte/src/motion/private.d.ts:L1-L10][f4]

Type-only declarations for the motion module: TickContext carries per-frame spring state (inv_mass, dt, stiffness/damping/precision opts, settled flag); SpringOpts holds constructor stiffness/damping/precision; SpringUpdateOpts declares deprecated store-only hard/soft alongside class-only instant/preserveMomentum; Updater is the (target, current) => next function type; TweenedOptions holds delay/duration/easing/interpolate.

No runtime code.

<a id="u-0d50896708c9"></a>
### `Spring`

`class Spring<T>` · [packages/svelte/src/motion/public.d.ts:L39-L40][f5]

Public type surface for svelte/motion.

The Spring interface and Spring class are deliberately merged via declaration merging to avoid a breaking rename; store-only members (update, subscribe) and class-only members (target, current) are marked deprecated/class-only in JSDoc. Also declares the Tweened interface (set/update over a Readable) and re-exports prefersReducedMotion, spring, tweened, and Tween from index.js. No runtime code.

**Uncertainties.**

- Whether the merged interface/class type resolves for consumers cannot be verified from declarations alone.

<a id="u-c15d4b363055"></a>
### `is_date`

`export function is_date(obj)` · [packages/svelte/src/motion/utils.js:L5-L7][f6]

Type guard returning true when Object.prototype.toString.call(obj) is '[object Date]', used by spring and tweened to detect Date values for special-cased interpolation and stepping.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/motion/index.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/motion/spring.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/motion/tweened.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/motion/private.d.ts
[f5]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/motion/public.d.ts
[f6]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/motion/utils.js
