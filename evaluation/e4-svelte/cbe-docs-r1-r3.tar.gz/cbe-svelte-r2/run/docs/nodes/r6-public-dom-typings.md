# Public DOM Element Typings

**Capability.** Declares the type-level attribute surface for HTML, SVG, media, and Svelte special elements, layered from ARIA/event base interfaces up to the SvelteHTMLElements tag map.

Use this subtree when typing element attributes or event handlers. Base interfaces (AriaAttributes, DOMAttributes, HTMLAttributes) feed per-element and special-element interfaces, all aggregated by SvelteHTMLElements.

Parent: [Svelte Monorepo](r6-svelte-monorepo.md)

## Units (19)

<a id="u-00e9dbdc2f41"></a>
### `AriaAttributes`

`export interface AriaAttributes` · [packages/svelte/elements.d.ts:L479-L676][f1]

Type-level map of the WAI-ARIA 1.1 attributes as optional element properties, each also permitting undefined and null.

Boolean states use the Booleanish alias; enumerated states use string-literal unions (aria-autocomplete, aria-live, aria-sort, aria-relevant with multi-word combinations); counts, positions, and range values are number; references are string. aria-checked, aria-pressed, and aria-selected use boolean | 'false' | 'mixed' | 'true'. aria-dropeffect and aria-grabbed are marked deprecated. Purely type-level with no logic.

uses: [Booleanish](r6-public-dom-typings.md#u-ec31d6e609b3)

<a id="u-b2213dc03cb0"></a>
### `DOMAttributes`

`export interface DOMAttributes<T extends EventTarget>` · [packages/svelte/elements.d.ts:L85-L476][f1]

Attribute map for event handlers and Svelte dimension bindings available on every event target.

Declares a children prop typed as a Svelte Snippet, then three spellings per event — quoted 'on:name', camelCase property, and camelCase+capture — grouped by family from clipboard through fullscreen, including Svelte transition events typed CustomEvent<null>. Every handler value also accepts undefined or null; a comment states Svelte treats null like undefined. Some events use directly instantiated EventHandler (on:submit as SubmitEvent, on:beforeinput as InputEvent); on:input is deliberately FormEventHandler because its event type depends on the target element. Ends with readonly bind: entries for ResizeObserver-style dimensions (contentRect, box sizes, clientWidth/Height) and xmlns.

**Notes.**

- contract: All bind: dimension entries are readonly: they are output-only binding targets.

uses: [packages-svelte-elements-d-ts-event-handler-aliases](r6-public-dom-typings.md#u-89afffa785a3), [EventHandler](r6-public-dom-typings.md#u-b8d44575b8e9)

**Uncertainties.**

- Capture-phase semantics are implied by the 'capture' key suffix naming only; no runtime wiring exists in this file.

<a id="u-769572c7f4d3"></a>
### `HTMLAttributes`

`export interface HTMLAttributes<T extends EventTarget> extends AriaAttributes, DOMAtt…` · [packages/svelte/elements.d.ts:L751-L876][f1]

Base attribute type for all standard HTML elements, extending AriaAttributes and DOMAttributes<T>.

Adds standard attributes (accesskey through writingsuggestions, with literal unions for autocapitalize, dir, enterkeyhint, hidden, popover, translate), role typed AriaRole, RDFa attributes, non-standard legacy attributes, inputmode and is, and SvelteKit data-sveltekit-* routing hints with literal unions. Svelte bindings appear as quoted keys: bind:innerHTML/textContent/innerText for contenteditable elements and readonly bind:focused/offsetWidth/offsetHeight. Two index signatures close it: [key: `data-${string}`]: any for arbitrary data- attributes, and [key: symbol]: Attachment<T> | false | undefined | null for attachments while excluding other booleans.

**Notes.**

- contract: class?: ClassValue, so clsx-style objects and arrays are accepted, not just strings.

inherits: [AriaAttributes](r6-public-dom-typings.md#u-00e9dbdc2f41), [DOMAttributes](r6-public-dom-typings.md#u-b2213dc03cb0); uses: [AriaRole](r6-public-dom-typings.md#u-18d847350041), [ClassValue](r6-public-dom-typings.md#u-200e0d31db80)

<a id="u-3f50c0ba1916"></a>
### `HTMLInputAttributes`

`export interface HTMLInputAttributes extends HTMLAttributes<HTMLInputElement>` · [packages/svelte/elements.d.ts:L1093-L1150][f1]

Attribute type for <input>, extending HTMLAttributes<HTMLInputElement>.

Covers input-specific attributes including autocomplete typed FullAutoFill, Safari-only autocorrect, capture, checked, files, form* attributes, indeterminate, min/max/step, pattern, and type typed HTMLInputTypeAttribute; value is any. Provides defaultValue/defaultvalue and defaultChecked/defaultchecked in both casings because language tools lowercase non-shorthand attribute names. Overrides change handling with ChangeEventHandler<HTMLInputElement> and adds binds: bind:checked, bind:value (any), bind:group (any), readonly bind:files, and bind:indeterminate.

inherits: [HTMLAttributes](r6-public-dom-typings.md#u-769572c7f4d3); uses: [FullAutoFill](r6-public-dom-typings.md#u-2f8cb9c6a27e), [HTMLInputTypeAttribute](r6-public-dom-typings.md#u-75549bf9ff5e)

<a id="u-65008f7d54ec"></a>
### `HTMLMediaAttributes`

`export interface HTMLMediaAttributes<T extends HTMLMediaElement> extends HTMLAttribut…` · [packages/svelte/elements.d.ts:L1221-L1265][f1]

Attribute type shared by media elements, generic over T extending HTMLMediaElement and extending HTMLAttributes<T>.

Declares playback/loading attributes (autoplay, controls, controlslist with extra-string escape, crossorigin, preload, src, muted, playsinline, loop, lowercase Svelte convenience keys currenttime/defaultmuted/defaultplaybackrate); volume is documented as a value between 0 and 1. Readonly binds expose media state: readyState limited to literals 0–4, duration, buffered/played/seekable as SvelteMediaTimeRange arrays, seeking, ended; writable binds cover muted, volume, currentTime (seconds), playbackRate (1 = normal), and paused.

**Notes.**

- contract: Ready-state bind accepts only 0|1|2|3|4; volume and playbackRate constraints are doc-comment contracts, not enforced types.

inherits: [HTMLAttributes](r6-public-dom-typings.md#u-769572c7f4d3); uses: [SvelteMediaTimeRange](r6-public-dom-typings.md#u-143cfdef3b39)

<a id="u-adb80c8bde08"></a>
### `SVGAttributes`

`export interface SVGAttributes<T extends EventTarget> extends AriaAttributes, DOMAttr…` · [packages/svelte/elements.d.ts:L1551-L1844][f1]

Attribute type for all SVG elements, extending AriaAttributes and DOMAttributes<T>.

Lists shared HTML-like properties (className, class as ClassValue, color, height/width, id, lang, part, max/min, media, method, name, style, target, type, role, tabindex, crossorigin), then an extensive alphabetical catalog of SVG-specific presentation, animation, filter, and xlink/xml namespaced attributes, most typed number | string | undefined | null; enumerated members include alignment-baseline, color-interpolation-filters, fill-rule, stroke-linecap, and stroke-linejoin. Closes with a [key: `data-${string}`]: any index signature for arbitrary data- attributes; unlike HTMLAttributes it has no symbol/attachment index signature.

inherits: [AriaAttributes](r6-public-dom-typings.md#u-00e9dbdc2f41), [DOMAttributes](r6-public-dom-typings.md#u-b2213dc03cb0); uses: [ClassValue](r6-public-dom-typings.md#u-200e0d31db80)

<a id="u-434def3741e5"></a>
### `SvelteDocumentAttributes`

`export interface SvelteDocumentAttributes extends HTMLAttributes<Document>` · [packages/svelte/elements.d.ts:L1482-L1487][f1]

Attribute type for <svelte:document>, extending HTMLAttributes<Document>.

Adds only readonly binds exposing document state: activeElement, fullscreenElement, pointerLockElement, and visibilityState, each typed via the corresponding Document property and accepting undefined | null. Output-only binding targets, no writable members of its own.

inherits: [HTMLAttributes](r6-public-dom-typings.md#u-769572c7f4d3)

<a id="u-a4bde8899205"></a>
### `SvelteHTMLElements`

`export interface SvelteHTMLElements` · [packages/svelte/elements.d.ts:L1873-L2091][f1]

Master mapping from HTML/SVG tag names and Svelte special elements to their attribute types, used to type element attributes in Svelte components.

HTML tags map to their per-element attribute interface (a→HTMLAnchorAttributes, input→HTMLInputAttributes, etc.) or to HTMLAttributes with the concrete DOM element type parameter; SVG tags map to SVGAttributes parameterized by the corresponding SVG element class. Svelte-specific entries include 'svelte:window'/'svelte:document', 'svelte:fragment' ({ slot? }), 'svelte:options' (customElement with tag/shadow/props/extend, immutable, accessors, namespace, plus a string index signature), 'svelte:head' (any-named keys), and 'svelte:boundary' with onerror (error, reset callback), failed and pending Snippets. A final [name: string]: { [name: string]: any } index signature allows unknown tags.

**Notes.**

- field: 'svelte:boundary' failed/pending are typed as Svelte Snippets; onerror receives the error and a reset function.

uses: [HTMLAttributes](r6-public-dom-typings.md#u-769572c7f4d3), [SVGAttributes](r6-public-dom-typings.md#u-adb80c8bde08), [SvelteWindowAttributes](r6-public-dom-typings.md#u-9017cd4cac09), [SvelteDocumentAttributes](r6-public-dom-typings.md#u-434def3741e5)

<a id="u-143cfdef3b39"></a>
### `SvelteMediaTimeRange`

`export interface SvelteMediaTimeRange` · [packages/svelte/elements.d.ts:L1477-L1480][f1]

Structural type describing one buffered/played/seekable media time range with required numeric start and end fields.

Used as the element type of the buffered/played/seekable arrays in HTMLMediaAttributes binds. Type-level only.

<a id="u-9017cd4cac09"></a>
### `SvelteWindowAttributes`

`export interface SvelteWindowAttributes extends HTMLAttributes<Window>` · [packages/svelte/elements.d.ts:L1489-L1549][f1]

Attribute type for <svelte:window>, extending HTMLAttributes<Window>.

Readonly binds expose viewport and environment state: innerWidth/innerHeight, outerWidth/outerHeight, devicePixelRatio, and navigator.onLine; scrollX/scrollY binds are writable. Adds window-specific event handlers covering lifecycle (beforeprint/afterprint, beforeunload/unload, pagehide/pageshow), networking (online/offline), navigation (hashchange, popstate), messaging (message/messageerror with MessageEvent), storage (StorageEvent), device APIs (devicemotion, deviceorientation and its absolute variant, devicelight, deviceproximity, userproximity), promise rejection events, and others like beforeinstallprompt, paint, languagechange, orientationchange.

**Notes.**

- contract: bind:online is readonly (output-only) while bind:scrollX/scrollY are writable binding targets.

inherits: [HTMLAttributes](r6-public-dom-typings.md#u-769572c7f4d3)

<a id="u-18d847350041"></a>
### `AriaRole`

`export type AriaRole = | 'alert' | 'alertdialog' | 'application' | 'article' | 'banne…` · [packages/svelte/elements.d.ts:L679-L749][f1]

Union of all WAI-ARIA 1.1 role string literals (alert through treeitem) plus (string & {}), which keeps autocomplete for arbitrary strings while preserving literal-type checking for known roles.

Type-level only.

<a id="u-ec31d6e609b3"></a>
### `Booleanish`

`type Booleanish = boolean | 'true' | 'false';` · [packages/svelte/elements.d.ts:L38-L38][f1]

Alias boolean | 'true' | 'false', allowing ARIA-style string booleans and real booleans interchangeably; a preceding comment notes null is also permitted downstream since Svelte treats null like undefined.

<a id="u-200e0d31db80"></a>
### `ClassValue`

`export type ClassValue = string | import('clsx').ClassArray | import('clsx').ClassDic…` · [packages/svelte/elements.d.ts:L2093-L2093][f1]

Alias string | clsx ClassArray | clsx ClassDictionary (via import('clsx') types), so the class attribute accepts clsx-compatible inputs.

Type-level only.

<a id="u-b8d44575b8e9"></a>
### `EventHandler`

`type EventHandler<E extends Event = Event, T extends EventTarget = Element> = ( event…` · [packages/svelte/elements.d.ts:L44-L46][f1]

Defines the generic event-handler type all typed Svelte event attributes share.

The handler takes one argument typed as E intersected with { currentTarget: EventTarget & T }, narrowing the event's currentTarget to the element type parameter; the return type is any, E defaults to Event and T to Element. Purely type-level.

uses: [packages-svelte-elements-d-ts-event-handler-aliases](r6-public-dom-typings.md#u-89afffa785a3)

<a id="u-2f8cb9c6a27e"></a>
### `FullAutoFill`

`export type FullAutoFill = | AutoFill | 'bday' | ${OptionalPrefixToken<AutoFillAddre…` · [packages/svelte/elements.d.ts:L70-L79][f1]

Union of autocomplete tokens accepted by inputs, selects, and textareas: the AutoFill union plus extra literals ('bday', 'nickname', 'language', 'organization-title', 'photo', 'sex', 'url') and a template-literal member combining an OptionalPrefixToken of AutoFillAddressKind with 'cc-additional-name'.

Type-level only.

<a id="u-9a4e0edc803e"></a>
### `HTMLAttributeAnchorTarget`

`export type HTMLAttributeAnchorTarget = '_self' | '_blank' | '_parent' | '_top' | (st…` · [packages/svelte/elements.d.ts:L878-L878][f1]

Union of anchor target values ('_self', '_blank', '_parent', '_top') plus (string & {}) so arbitrary targets remain assignable without losing literal checking.

Type-level only.

<a id="u-75549bf9ff5e"></a>
### `HTMLInputTypeAttribute`

`export type HTMLInputTypeAttribute = | 'button' | 'checkbox' | 'color' | 'date' | 'da…` · [packages/svelte/elements.d.ts:L1068-L1091][f1]

Union of standard input type literals (button through week) plus (string & {}) so non-standard types remain assignable while known types keep checking.

Type-level only.

<a id="u-aca2cb770a6b"></a>
### `packages-svelte-elements-d-ts-element-attribute-interfaces`

`export interface HTMLAnchorAttributes extends HTMLAttributes<HTMLAnchorElement>` · [packages/svelte/elements.d.ts:L880-L890][f1]

The remaining per-element attribute interfaces, each extending HTMLAttributes (or HTMLMediaAttributes for media) parameterized by the element's DOM class and adding only that element's own attributes, usually optional string/number/boolean unions accepting undefined | null.

Notable specifics: HTMLAudioAttributes and HTMLVideoAttributes extend HTMLMediaAttributes (video adding poster, dimension binds videoWidth/videoHeight); HTMLDetailsAttributes adds bind:open and re-declares toggle handlers for HTMLDetailsElement; HTMLButtonAttributes adds command/commandfor and popover targets; HTMLSelectAttributes and HTMLTextareaAttributes override change with ChangeEventHandler for their element and add bind:value (textarea keeps dual-cased defaultValue); HTMLImgAttributes adds readonly naturalWidth/naturalHeight binds; HTMLLinkAttributes enumerates the full as= literal list; input-like value fields use string | string[] | number unions where constrained.

inherits: [HTMLAttributes](r6-public-dom-typings.md#u-769572c7f4d3), [HTMLMediaAttributes](r6-public-dom-typings.md#u-65008f7d54ec); uses: [FullAutoFill](r6-public-dom-typings.md#u-2f8cb9c6a27e)

<a id="u-89afffa785a3"></a>
### `packages-svelte-elements-d-ts-event-handler-aliases`

`export type ClipboardEventHandler<T extends EventTarget> = EventHandler<ClipboardEven…` · [packages/svelte/elements.d.ts:L48-L48][f1]

Exported type aliases specializing EventHandler for each DOM event category: clipboard, composition, drag, focus, form and change (both plain Event), keyboard, mouse, touch, pointer, gamepad, UI, wheel, animation, transition, message, toggle, and contentvisibilityautostatechange.

Each takes an EventTarget parameter and yields handlers whose event has the corresponding DOM event type with narrowed currentTarget. Type-level only.

uses: [EventHandler](r6-public-dom-typings.md#u-b8d44575b8e9)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/elements.d.ts
