# Client Transform

**Capability.** Lowers analyzed components into client runtime calls: concrete block/tag/attribute visitors plus shared helpers for template construction, expression building, memoization and dev-time validation. The Template class and fragment sibling-walking are the shared substrate.

Use this subtree to see how template syntax becomes $.template/$.each/$.await-style output. shared/utils.js and shared/declarations.js supply expression reading, placeholders and state transformers; template.js owns HTML/tree serialization.

**Depends on.**

- [Analyze-Phase Visitors](r5-analyze-phase.md) · model-inferred · 0 edge(s)
- [Compiler Utilities and AST Helpers](r5-compiler-utilities.md) · graph-confirmed · 10 edge(s)

**Depended on by.**

- [Compiler Public API and Pipeline](r5-compiler-pipeline.md) · containment · → 0 / ← 0 edge(s) (ancestor direct units and descendant subtree; → follows ` r5-compiler-pipeline ` → ` r5-client-transform `)
- [Client Transform Visitors](r1-compiler-transform-client.md) · graph-only · 25 edge(s)
- [Client Transform](r3-client-transform.md) · graph-only · 15 edge(s)
- [Client transform visitors](r2-client-visitors.md) · graph-only · 10 edge(s)

Parent: [Compiler Public API and Pipeline](r5-compiler-pipeline.md)

## Units (27)

<a id="u-74901e1385cf"></a>
### `template.js-template-class`

`class Template` · [packages/svelte/src/compiler/phases/3-transform/client/transform-template/template.js:L9-L34][f1]

Accumulates an in-memory template representation (elements, comments, text) that visitors populate, then serializes it either to a single HTML-string quasi (as_html) or to a nested array literal (as_tree).

State: nodes is the root list, #fragment points at the currently open child list, #stack tracks open element child lists, #element is the innermost element, and the contains_script_tag/needs_import_node flags steer downstream instantiation. push_element appends an element and opens its children as the new fragment; pop_element pops the stack back to the parent list; push_comment and push_text append nodes; set_prop writes onto the innermost element's attributes and would throw on an undefined attribute when no element is open. as_html joins stringify output of all root nodes into one quasi. as_tree unshifts a dataless comment whenever the first node is a comment (so effect.start has an anchor), mutating the shared node list as a side effect, then maps nodes through objectify.

**Uncertainties.**

- as_tree reads this.nodes[0].type unguarded; an empty node list in tree mode appears to throw, but whether that state is reachable depends on callers outside this file.

<a id="u-c628bcd2b8ab"></a>
### `objectify`

`function objectify(item)` · [packages/svelte/src/compiler/phases/3-transform/client/transform-template/template.js:L119-L162][f1]

Serializes one template node into a builders AST for tree-mode instantiation.

Text nodes become a literal of the joined node data; comments become a one-element array ['// data'] or null when data is absent. Elements become an array headed by the element name, followed by an attributes object (keys passed through fix_attribute_casing; undefined values become void 0) only when attributes or children exist, then child elements. For 'pre' and 'textarea' elements a leading newline is stripped from a literal first child, compensating for HTML parsing rules.

calls: [fix_attribute_casing](r4-client-transform.md#u-799dccdfecc2)

<a id="u-61b15a4cd312"></a>
### `stringify`

`function stringify(item)` · [packages/svelte/src/compiler/phases/3-transform/client/transform-template/template.js:L89-L116][f1]

Serializes one template node to HTML text.

Text nodes join their raw source; comments render as <!--data--> or the <!> placeholder when data is absent. For elements it opens a tag emitting each attribute key bare when its value is undefined, otherwise key="value" with escape_html(value, true); void element names get a self-closing '/>' for XHTML compliance, other elements emit children (by recursion) then the closing tag.

calls: [escape_html](r2-server-render.md#u-0f499dd45547)

<a id="u-6379edcfd2b5"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/AttachTag.js:AttachTag`

`export function AttachTag(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/AttachTag.js:L10-L14][f2]

Serializes an {@attach} tag into an init-time `$.attach` call.

The tag expression is rebuilt via build_expression, a `$.attach(node, () => expression)` statement is pushed to context.state.init, and context.next() continues visiting the subtree.

calls: [build_expression](r5-client-transform.md#u-cd5eb51d389f)

<a id="u-34b00bddeeac"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/AwaitBlock.js:AwaitBlock`

`export function AwaitBlock(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/AwaitBlock.js:L14-L75][f3]

Serializes an {#await} block into a `$.await` runtime call.

After pushing a template comment, the awaited expression becomes a thunk built by build_expression. If node.then exists, a copied context (with a copied transform map) visits the then block; node.value, when present, is processed by create_derived_block_argument, whose declarations precede the visited block body inside an arrow taking `$$anchor` plus the argument id; node.catch/node.error are handled identically for the catch arm. The final `$.await(node, expression, pendingArrow|null, thenBlock, catchBlock)` call is wrapped by add_svelte_meta and pushed to state.init; a missing pending block serializes as null.

calls: [build_expression](r5-client-transform.md#u-cd5eb51d389f), [add_svelte_meta](r5-client-transform.md#u-75700db42066)

**Uncertainties.**

- Whether the shallowly copied transform maps intentionally leak changes made by visited sub-blocks is not provable from this file.

<a id="u-741970a13fda"></a>
### `create_derived_block_argument`

`function create_derived_block_argument(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/AwaitBlock.js:L82-L110][f3]

Prepares the destructured argument of {:then value}/{:catch error}.

For an Identifier pattern it sets `transform[name] = { read: get_value }` and returns the identifier with null declarations. For any other pattern it visits the pattern, extracts its identifiers, and builds a block binding `$$source` via `$.get` and returning an object of those identifiers; that block becomes a create_derived `$$value`, and each identifier gets its own derived reading `$.get($$value).<id>` plus a get_value transform. Returns the argument id (`$$source`) and the declaration statements to prepend to the block body.

calls: [create_derived](r2-client-signal-builders.md#u-d8c62e2be238), [extract_identifiers](r5-compiler-utilities.md#u-90eb95affc00)

<a id="u-494b5cffc303"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/DebugTag.js:DebugTag`

`export function DebugTag(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/DebugTag.js:L10-L28][f4]

Compiles {@debug ...} into a console.log of an object mapping each listed identifier to its snapshot, scheduled inside a $.template_effect thunk in init followed by a debugger statement so execution pauses.

Each value comes from $.snapshot of the visited identifier; in runes mode the snapshot is used directly, otherwise it is wrapped in $.untrack(thunk) to avoid dependency tracking.

**Notes.**

- side_effect: pushes both the template_effect statement and an embedded debugger statement into state.init

<a id="u-d99c085dd1f2"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/EachBlock.js:EachBlock`

`export function EachBlock(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/EachBlock.js:L22-L358][f5]

Lowers an each block into a `$.each` call, computing flags, transforms, and invalidation glue.

The list expression is built in the parent scope; a comment is pushed to the template unless the block is controlled. Flags are accumulated: EACH_INDEX_REACTIVE for keyed blocks with an index; EACH_ITEM_REACTIVE when a dependency binding has function_depth >= the current scope and (`!runes || !key_is_item || uses_store`), where uses_store is set if any expression dependency is a store_sub; EACH_ITEM_IMMUTABLE when in runes mode without store use; EACH_IS_ANIMATED when the keyed block contains an element with an `animate:` directive; EACH_IS_CONTROLLED for controlled blocks. If the list expression's base identifier is a store_sub binding, its name becomes store_to_invalidate. A unique `$$array` collection id is created when the inner scope shadows an outer declaration. For an Identifier context, read/assign/mutate transforms are installed: reassigned items read via `collection[index]`, reactive items via `get_value`, and assignments/mutations append the invalidation sequence. For destructured contexts, inserts become `$.derived` variables and paths become `let` declarations (via `$.derived_safe_equal` when a default value must be called once), each with read/assign/mutate transforms and, in dev, an eager read to surface 'cannot access before initialization' errors. In legacy mode a `$.invalidate_inner_signals` thunk over transitive deps of this and all parent each blocks is prepended to the sequence; store invalidation is appended. The key function is an arrow over the visited key (including the index when the key uses it). When the expression has await, everything is wrapped in `$.async` with the collection thunk resolved to `$$collection`; otherwise statements go to `init`, preceded by `$.validate_each_keys` in dev for keyed blocks.

calls: [get_value](r5-client-transform.md#u-928394943600), [build_expression](r5-client-transform.md#u-cd5eb51d389f), [add_svelte_meta](r5-client-transform.md#u-75700db42066), [Scope](r3-scope-node-model.md#u-01a82e58170d), [ScopeRoot](r3-scope-node-model.md#u-8f49475011d6), [extract_paths](r5-compiler-utilities.md#u-34f2fcb20c62), [object](r5-compiler-utilities.md#u-2f2548aeaec6), [packages/svelte/src/compiler/phases/3-transform/client/visitors/EachBlock.js:EachBlock](r5-client-transform.md#u-d99c085dd1f2)

**Uncertainties.**

- exact semantics of the flags constants are defined in constants.js, not shown
- the TODO in the source acknowledges EACH_ITEM_REACTIVE heuristics cover fewer cases than intended

<a id="u-a9aa3f77ec68"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/RenderTag.js:RenderTag`

`export function RenderTag(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/RenderTag.js:L12-L89][f6]

Serializes {@render} tags into snippet invocation calls.

After a template comment, unwrap_optional strips any optional chain. Each argument is built with build_expression; when its metadata has await or a call, the expression is memoized and read back via `$.get(memoizer.add(...))`, then passed as a thunk. memoizer.apply() emits setup, and memoizer.deriveds yields preliminary statements (per runes mode). The callee is built with build_expression. Dynamic snippets (node.metadata.dynamic) render via `$.snippet(node, thunk(callee), ...args)`, with a ChainExpression callee guarded by `?? $.noop` so a nullish snippet renders nothing; static snippets call (or maybe-call) the callee directly with the node and args, both wrapped by add_svelte_meta. If memoizer.async_values() is non-empty, init receives `$.async(node, values, (node, ...ids) => statements)`; otherwise the single statement or a block of them is pushed.

calls: [build_expression](r5-client-transform.md#u-cd5eb51d389f), [add_svelte_meta](r5-client-transform.md#u-75700db42066), [unwrap_optional](r5-compiler-utilities.md#u-aa95700b7c80)

**Uncertainties.**

- Memoizer's internal id/derived allocation scheme lives outside this file.

<a id="u-dc69513c68f2"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/SvelteFragment.js:SvelteFragment`

`export function SvelteFragment(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/SvelteFragment.js:L9-L17][f7]

Compiles <svelte:fragment> content into the parent's init.

First each LetDirective attribute is visited and pushed into state.init (let: directives establish slot bindings); then the fragment is visited as a block statement and all of its body statements are spread into state.init.

**Uncertainties.**

- The cast of the visited fragment to BlockStatement assumes the fragment visitor yields a block; that guarantee is established elsewhere.

<a id="u-679da0880969"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/SvelteWindow.js:SvelteWindow`

`export function SvelteWindow(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/SvelteWindow.js:L9-L11][f8]

Compiles <svelte:window> by delegating to visit_special_element with the target expression '$.window'.

calls: [visit_special_element](r1-compiler-transform-client.md#u-5f6160c62286)

<a id="u-7d1fd01c56d0"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/UseDirective.js:UseDirective`

`export function UseDirective(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/UseDirective.js:L11-L37][f9]

Serializes use: actions into a `$.action(node, actionFactory, paramsThunk?)` statement pushed to state.init, so actions run after attribute updates in order with bindings and events.

The factory is an arrow over `$$node` (plus `$$action_arg` when a parameter expression exists) that maybe-calls the visited directive name; the parameter expression, when present, is visited inside a trailing thunk. context.next() then continues with the default transform.

calls: [parse_directive_name](r5-client-transform.md#u-47fb5120ded1)

<a id="u-32bec314643f"></a>
### `add_state_transformers`

`export function add_state_transformers(context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/declarations.js:L18-L53][f10]

Installs read/assign/mutate/update transformers on context.state for each binding in the current scope that is a state source, derived, or legacy_reactive.

Read uses `$.safe_get` for `var`-declared bindings (legacy mutable without reassignment) and `$.get` otherwise. Assign produces `$.set` (with a `true` proxy flag when requested); if `$name` resolves to a store_sub binding, the set call is wrapped in `$.store_unsub` with the store name and `$$stores`. Mutate returns the mutation unchanged in runes mode, else wraps it in `$.mutate`. Update emits `$.update_pre` for prefix and `$.update` otherwise, passing `-1` only for `--`.

calls: [is_state_source](r2-client-signal-builders.md#u-4eba3d9b7ec5)

**Uncertainties.**

- is_state_source semantics live in another file; the exact set of bindings treated as state sources is not established here

<a id="u-928394943600"></a>
### `get_value`

`export function get_value(node)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/declarations.js:L10-L12][f10]

Wraps an identifier in a `$.get` call expression so reads of reactive state go through the reactivity runtime.

uses: [add_state_transformers](r5-client-transform.md#u-32bec314643f)

<a id="u-c8d8a77dfc05"></a>
### `fragment.js-process_children`

`export function process_children(nodes, initial, is_element, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/fragment.js:L19-L29][f11]

Walks an array of template sibling nodes and emits the template references and text updates the runtime needs, joining adjacent Text/ExpressionTag nodes into one sequence.

Internals: get_node returns prev(is_text) when no node has been skipped, otherwise a $.sibling call carrying the skip count (and a text flag). flush_node materializes the current position into an identifier — reusing prev's expression when it is already an identifier, otherwise declaring a variable via scope.generate — then sets skipped to 1 so the next lookup is a sibling step. flush_sequence emits static text via template.push_text (incrementing skipped) when every node is Text; otherwise it pushes a single-space text node into the template, builds the dynamic chunk with build_template_chunk, flushes a node reference, and emits a $.set_text update into state.update when has_state and the content is not bound contenteditable, otherwise an immediate nodeValue assignment in init. The main loop flushes any open sequence before non-text nodes; a static element (per is_static_element) just increments skipped, a lone EachBlock inside an element is marked is_controlled, and anything else gets a flushed node identifier that replaces context.state.node for the child visit. After the loop, trailing sequences are flushed, and when more than one node was skipped a trailing $.next call (in init) walks hydration to the last static node.

<a id="u-c654162d4a2b"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/fragment.js:is_static_element`

`function is_static_element(node, state)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/fragment.js:L129-L173][f11]

Decides whether a RegularElement can be baked entirely into the template string instead of receiving runtime node references.

It returns false for non-RegularElement nodes, elements with dynamic fragment metadata, custom elements (attributes go through properties), any non-Attribute node (directives/spreads), event attributes, names for which cannot_be_set_statically is true, 'dir', value/checked on input or textarea, value on option, loading on img, and any attribute whose value is dynamic (not true and not a text attribute). Only when every attribute passes these checks does it return true.

**Uncertainties.**

- is_custom_element_node and cannot_be_set_statically are defined elsewhere; their exact predicates are not visible here.

<a id="u-888d94f48ee5"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/function.js:visit_function`

`export const visit_function = (node, context) =>` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/function.js:L9-L30][f12]

Serializes arrow and function expressions.

State is copied with in_constructor and in_derived reset to false; for FunctionExpressions whose parent is a constructor MethodDefinition, in_constructor is set true. If node.metadata.hoisted is true, params are rebuilt with build_hoisted_params and a new FunctionExpression is returned with the visited body under that state. Otherwise context.next continues the normal visitor chain with the adjusted state.

calls: [build_hoisted_params](r2-client-signal-builders.md#u-a89fb605f1f4)

**Uncertainties.**

- The effect of in_constructor/in_derived flags on descendant visitors is defined elsewhere

<a id="u-76b08484949a"></a>
### `Memoizer`

`class Memoizer` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/utils.js:L17-L28][f13]

Extracts complex expressions (calls, awaits) from templates and replaces them with sequential placeholder identifiers `$0`, `$1`, ...

`add(expression, has_await)` returns a placeholder id named `#` and queues the expression in the sync or async list. `apply()` renames all queued ids to `$i` in insertion order (sync first, then async) and returns them, to be used as arrow parameters. `deriveds(runes)` emits `let $i = $.derived(thunk)` (or `$.derived_safe_equal` when runes is false) for sync entries only. `async_ids()` lists the async placeholder ids; `async_values()`/`sync_values()` return arrays of thunks over the expressions, or undefined when the respective list is empty.

<a id="u-75700db42066"></a>
### `add_svelte_meta`

`export function add_svelte_meta(expression, node, type, additional)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/utils.js:L443-L464][f13]

In dev mode, wraps a block/component creation expression so runtime stack traces report source location.

Returns the plain statement when not in dev or when the node has no start or locator yields no position. Otherwise emits `$.add_svelte_meta` with a zero-arg arrow producing the original expression, the block type literal, the current component_name identifier, line and column literals, and — when `additional` is supplied — an object of literal-valued entries.

uses: [function::component_name::0][f14]

**Uncertainties.**

- component_name is imported from state.js; its runtime shape is defined there

<a id="u-62396233e782"></a>
### `build_bind_this`

`export function build_bind_this(expression, value, { state, visit })` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/utils.js:L211-L233][f13]

Serializes `bind:this` for components and elements.

A SequenceExpression short-circuits to `$.bind_this(value, set, get)` over the visited sequence's expressions. Otherwise the visitor walks the expression collecting each context (EachBlock-scoped) variable reference once: its visited value is pushed into ids/values arrays, and any existing transform for that name gets a pass-through read so the get arrow sees the raw loop variable. The get and set expressions (the latter being an assignment of `$$value` to the expression) are visited under a child state with the adjusted transform; every MemberExpression on the get chain is marked optional so missing intermediate properties do not throw at teardown. Result: `$.bind_this(value, setArrow($$value, ...ids), getArrow(...ids))`, plus a thunked array of the each-context values when any were collected.

group: [build_bind_this.Identifier](r5-client-transform.md#u-d458a3c6e946)

**Uncertainties.**

- walk's path/is_reference interplay for non-simple expressions is external

<a id="u-d458a3c6e946"></a>
### `build_bind_this.Identifier`

`Identifier(node, { path })` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/utils.js:L233-L258][f13]

Walk visitor for identifiers in build_bind_this: skips already-seen names and non-references; looks up the binding and, when its scope is owned by an EachBlock on the state.scopes stack, records the identifier and its visited value and neutralizes that name's transform read.

Names without bindings are ignored.

<a id="u-cd5eb51d389f"></a>
### `build_expression`

`export function build_expression(context, expression, metadata, state = context.state)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/utils.js:L393-L433][f13]

Transforms an expression, replicating legacy coarse-grained reactivity by eagerly reading dependencies around an untracked evaluation.

The expression is visited under the given state. In runes or maybe_runes mode the visited value returns as-is. If metadata shows no call, member expression, or assignment, it also returns unchanged. Otherwise a sequence is built: for each metadata reference that is not a plain non-import binding, build_getter produces a read; bindable_prop, template, import, `$$props`, and `$$restProps` references get their getter wrapped in `$.deep_read_state`. The visited value itself is wrapped in `$.untrack(thunk)` and appended last, so legacy reads happen eagerly while the expression evaluates untracked.

calls: [build_getter](r2-client-signal-builders.md#u-66a19e20e1f1)

**Uncertainties.**

- The exact distinction between runes/maybe_runes gating and legacy metadata flags depends on analysis fields defined elsewhere

<a id="u-b84b76b77b0e"></a>
### `build_render_statement`

`export function build_render_statement(state)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/utils.js:L164-L182][f13]

Builds the `$.template_effect` statement for an element's reactive updates: memoizer.apply() fixes the placeholder ids, which become the parameters of an arrow whose body is the single update expression when state.update holds exactly one ExpressionStatement, otherwise a block of all update statements.

Sync and async memoized values are passed as thunk arrays after the arrow.

uses: [Memoizer](r5-client-transform.md#u-76b08484949a)

<a id="u-d8d503fc4b7b"></a>
### `build_template_chunk`

`export function build_template_chunk( values, context, state = context.state, memoize…` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/utils.js:L71-L159][f13]

Turns a list of Text and ExpressionTag nodes into either a template literal expression or a single expression.

Text and non-null Literal tags accumulate into the current quasi's cooked string; the literal `undefined` identifier is only inlined when `undefined` is not shadowed in scope. Dynamic tags are built via build_expression and memoized through the memoize callback (defaulting to state.memoizer for call/await expressions), then evaluated by the scope. For a single-value input, the expression is returned directly (constant-folded to a literal when evaluated.is_known), optimizing for set_text instead of template_effect. In multi-value mode, `?? ??` and `||` logical expressions with a null right-hand literal get the null replaced by `''`; non-known values that are not defined get `?? ''` appended; known values fold into the quasi. Each dynamic chunk closes a quasi (the last marked as tail), raw strings are sanitized via sanitize_template_string, and the result is a b.template over quasis and expressions, or a plain string literal when no expressions remain. has_state reflects any await, or state that the scope cannot prove known.

calls: [sanitize_template_string](r2-compiler-infrastructure.md#u-01781e43d6ff), [build_expression](r5-client-transform.md#u-cd5eb51d389f)

**Uncertainties.**

- scope.evaluate's is_known/is_defined semantics are defined in scope.js and only inferred here

<a id="u-47fb5120ded1"></a>
### `parse_directive_name`

`export function parse_directive_name(name)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/utils.js:L189-L203][f13]

Converts a legacy directive name like `a.b-c` into a member expression chain.

Splits on dots, starting from an identifier of the first part; each subsequent part becomes a member access, computed with a literal when the part is not a valid identifier, plain property otherwise.

**Notes.**

- contract: Only dots are split; dashes and other invalid characters force computed member access rather than an error.

<a id="u-91b59b999e05"></a>
### `validate_binding`

`export function validate_binding(state, binding, expression)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/utils.js:L292-L325][f13]

Emits a dev-time `$.validate_binding` init statement for `bind:x={obj.prop}` in runes mode.

SequenceExpression bindings return early (handled elsewhere), as do store_sub bindings ($store.foo). The pushed call passes the binding's source text, a thunk over the object expression — prefixed with `$.mark_store_binding` inside a sequence when state.store_to_invalidate is set — a thunk yielding the computed property expression or literal property name, and the located line/column when locator returns a position.

**Uncertainties.**

- state.store_to_invalidate's origin is outside this file

<a id="u-a58215b09609"></a>
### `validate_mutation`

`export function validate_mutation(node, context, expression)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/utils.js:L333-L385][f13]

In dev mode, wraps mutations of component props with an ownership-validation call.

Returns the original expression unchanged when not dev, the target is not a MemberExpression, or the mutation is ignored via ownership_invalid_mutation. Also unchanged when the root object cannot be determined or its binding is neither `prop` nor `bindable_prop`. Otherwise marks analysis.needs_mutation_validation and builds a property path: literal keys stay literals, identifier keys become literals for non-computed access or the transform's read output for computed access, and any other property type aborts the wrapping. The path is prefixed with the root name literal and the result becomes `$$ownership_validator.mutation(prop_alias, path, expression, line, column)`; the location is included only when locator finds one for the root object's start.

calls: [state.js-module-level-compiler-state](r2-compiler-infrastructure.md#u-d73d7b033038); uses: [object](r5-compiler-utilities.md#u-2f2548aeaec6)

**Uncertainties.**

- The wrapping is skipped silently (original expression returned) for private (non-Identifier/Literal) property accesses; whether that is intended laxness is not stated in source

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/transform-template/template.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/AttachTag.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/AwaitBlock.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/DebugTag.js
[f5]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/EachBlock.js
[f6]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/RenderTag.js
[f7]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/SvelteFragment.js
[f8]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/SvelteWindow.js
[f9]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/UseDirective.js
[f10]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/declarations.js
[f11]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/fragment.js
[f12]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/function.js
[f13]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/utils.js
[f14]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/state.js
