# Legacy Component Lifecycle

**Capability.** Wires Svelte 4 component lifecycle (beforeUpdate/onMount/afterUpdate) and registers legacy component signals with the running effect so prop changes trigger before/afterUpdate.

Use only for Svelte 4 compatibility semantics. init installs hooks from ComponentContextLegacy; observe_all subscribes the legacy signals.

**Depends on.**

- [Client Reactivity Core](r6-client-reactivity.md) · graph-confirmed · 1 edge(s)
- [Shared Utilities and Tests](r6-shared-infra.md) · graph-confirmed · 2 edge(s)

Parent: [Client Runtime](r6-runtime-client.md)

## Units (2)

<a id="u-805336ae6185"></a>
### `packages/svelte/src/internal/client/dom/legacy/lifecycle.js:init (2)`

`export function init(immutable = false)` · [packages/svelte/src/internal/client/dom/legacy/lifecycle.js:L18-L68][f1]

Legacy-mode hook installer: reads the current `ComponentContextLegacy` from `component_context`, and if it has legacy callbacks (`context.l.u`), wires `beforeUpdate`, `onMount`, and `afterUpdate`.

Props reading: by default `props` deep-reads the component's state so all signals register with whichever effect runs; in immutable mode (`immutable === true`) it instead builds a `derived` that compares each prop's identity against the previous snapshot and increments a version counter, so `props()` (and thus the callbacks) only fire when some prop object identity changed. If `callbacks.b` is non-empty, a `user_pre_effect` calls `observe_all(context, props)` then runs all `beforeUpdate` callbacks. `onMount` always runs via a `user_effect` that untracks and runs each mount callback, returning a cleanup that invokes any returned function. If `callbacks.a` is non-empty, a second `user_effect` observes props and runs all `afterUpdate` callbacks. Throws if there is no legacy component context (the cast assumes one).

calls: [observe_all](r6-client-dom-legacy.md#u-0dbaafa34d50), [derived](r6-client-reactivity.md#u-d386336ed5eb), [user_effect](r3-effects-engine.md#u-2ecd21794ced), [effects.js-effect-creators](r3-effects-engine.md#u-27c9c7c4069f)

**Uncertainties.**

- Effect scheduling order relative to component mounting is governed by the effects runtime, not visible here.

<a id="u-0dbaafa34d50"></a>
### `observe_all`

`function observe_all(context, props)` · [packages/svelte/src/internal/client/dom/legacy/lifecycle.js:L76-L82][f1]

Registers all signals associated with a legacy component with the currently running effect so prop changes trigger before/afterUpdate.

If the context has a signal list (`context.l.s`) it reads each signal via `get` inside the caller's effect; then it calls `props()`, which deep-reads component state or, in immutable mode, evaluates the version derived.

calls: [packages/svelte/src/internal/client/dom/legacy/lifecycle.js:init (2)](r6-client-dom-legacy.md#u-805336ae6185)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/legacy/lifecycle.js
