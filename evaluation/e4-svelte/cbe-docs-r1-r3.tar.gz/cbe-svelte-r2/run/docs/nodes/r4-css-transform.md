# CSS Transform

**Capability.** Rewrites component stylesheets in place with MagicString: scopes keyframes and selectors, removes or comments out unused rules, strips :global pseudo-classes, and minifies whitespace, returning code, map, and hasGlobal.

Use this subtree for scoping/pruning output CSS. render_stylesheet is the entry; visitor methods apply per-node edits and rely on is_used/is_empty/is_in_global_block for pruning decisions. is_keyframes_node from phases/css.js is shared with the analysis phase.

**Depends on.**

- [Compiler Shared Infrastructure](r4-compiler-infra.md) · graph-confirmed · 2 edge(s)
- [CSS Analysis](r4-css-analysis.md) · model-inferred · 0 edge(s)

Parent: [Code Generation \(Phase 3\)](r4-codegen-transform.md)

## Units (13)

<a id="u-8e64579cb2b1"></a>
### `escape_comment_close`

`function escape_comment_close(node, code)` · [packages/svelte/src/compiler/phases/3-transform/css/index.js:L458-L479][f1]

Escapes '*/' sequences inside a rule so wrapping it in a block comment cannot terminate early.

Iterates the rule's source range tracking escape state and comment state: inside a comment, '*/' gets a backslash prepended; outside, a backslash skips the next character and '/*' enters comment state.

<a id="u-850d391518fa"></a>
### `is_empty`

`function is_empty(rule, is_in_global_block)` · [packages/svelte/src/compiler/phases/3-transform/css/index.js:L424-L446][f1]

Recursively decides whether a Rule produces no CSS.

A global block is empty when its block has no children. Otherwise any Declaration child makes it non-empty; a Rule child is non-empty only when it is used or the enclosing context is a global block and the child itself is not recursively empty; an Atrule child makes it non-empty when its block is null or has children. Returns true when no such child exists.

calls: [is_used](r4-css-transform.md#u-b3b67c9d0361)

<a id="u-104caee60cc4"></a>
### `packages/svelte/src/compiler/phases/3-transform/css/index.js:is_in_global_block`

`function is_in_global_block(path)` · [packages/svelte/src/compiler/phases/3-transform/css/index.js:L383-L385][f1]

Returns true when any node on the visitor path is a Rule whose metadata.is_global_block is set (a `:global { ...

}` block).

<a id="u-b3b67c9d0361"></a>
### `is_used`

`function is_used(rule)` · [packages/svelte/src/compiler/phases/3-transform/css/index.js:L449-L451][f1]

Returns true when any complex selector in the rule's prelude has metadata.used set.

<a id="u-d582bf731db0"></a>
### `remove_global_pseudo_class`

`function remove_global_pseudo_class(selector, combinator, state)` · [packages/svelte/src/compiler/phases/3-transform/css/index.js:L392-L407][f1]

Deletes a :global pseudo-class from the output.

With no args and a descendant combinator it first walks back over preceding whitespace so 'div :global.x' becomes 'div.x', then blanks the ':global' text via update rather than remove, because a closing unused-selector comment may already occupy the range. With args it removes ':global(' plus the trailing ')', leaving the argument selectors in place.

<a id="u-de1c1b6a47fb"></a>
### `remove_preceding_whitespace`

`function remove_preceding_whitespace(end, state)` · [packages/svelte/src/compiler/phases/3-transform/css/index.js:L414-L418][f1]

Minification helper: scans backwards from `end` over whitespace in the original source and removes the whitespace run immediately before `end` when non-empty.

<a id="u-197b2d45aa0c"></a>
### `render_stylesheet`

`export function render_stylesheet(source, analysis, options)` · [packages/svelte/src/compiler/phases/3-transform/css/index.js:L29-L73][f1]

Rewrites a component's stylesheet in place with MagicString and returns {code, map, hasGlobal}.

Builds State (hash, minify only when analysis.inject_styles and not dev, scoped selector class, keyframes list, specificity flag), walks the CSS AST with the visitors, then trims output to ast.content.start..end. When minifying it strips whitespace preceding the stylesheet end. It generates a source map with included content, merges the preprocessor map into it, and in dev with css==='injected' and non-empty code appends a sourceMappingURL comment using map.toUrl(). Returns css.code from code.toString() and hasGlobal from analysis.css.has_global.

**Notes.**

- side_effect: The walk's generic visitor records every node's start/end via code.addSourcemapLocation
- condition: minify state flag is analysis.inject_styles && !options.dev, not options.minify

calls: [merge_with_preprocessor_map](r6-compiler-infra.md#u-58c664c9f3e7); uses: [packages/svelte/src/compiler/phases/3-transform/css/index.js:Atrule](r4-css-transform.md#u-e1dbad642d6e)

**Uncertainties.**

- Trimming depends on ast.content offsets not visible here

<a id="u-e1dbad642d6e"></a>
### `packages/svelte/src/compiler/phases/3-transform/css/index.js:Atrule`

`const visitors = { _: (node, context) => { context.state.code.addSourcemapLocation(no…` · [packages/svelte/src/compiler/phases/3-transform/css/index.js:L76-L99][f1]

Handles keyframes at-rules: for a keyframes node it scans past the name to the identifier, and if the prelude starts with '-global-' removes those 8 characters; otherwise, when not inside a :global block, prepends the scoped hash to the name.

It returns without calling next() so keyframes contents are not transformed. All non-keyframes at-rules continue via next().

calls: [is_keyframes_node](r4-compiler-infra.md#u-8dc3955e3495), [packages/svelte/src/compiler/phases/3-transform/css/index.js:is_in_global_block](r4-css-transform.md#u-104caee60cc4)

<a id="u-2ad602047704"></a>
### `packages/svelte/src/compiler/phases/3-transform/css/index.js:ComplexSelector`

`ComplexSelector(node, context)` · [packages/svelte/src/compiler/phases/3-transform/css/index.js:L283-L372][f1]

Applies scoping edits to one complex selector.

For each :global relative selector it calls remove_global_pseudo_class; when a parent rule exists and global.args is null it prepends '&' for uncombinated selectors (div { :global.x } becomes div { &.x }), and when this selector is the last of multiple children in the parent prelude it updates away the comma up to the next selector, but only if that next selector is used (otherwise its own removal handles the comma). For non-global relative selectors it strips any mid-compound :global pseudo-class. For scoped selectors it skips standalone :is/:where and anything containing a NestingSelector; otherwise it inserts the scoped class once as a bare class (first occurrence, giving a +0-1-0 bump) and thereafter as :where(class), by scanning selectors backward: pseudo-elements/classes are skipped except a modifier prefix at index 0 when not root/host, '*' is replaced entirely by the modifier, and everything else gets the modifier appended after its end; it stops at the first selector edited. Sets specificity.bumped=true on first scoping, calls next(), then restores the entry bumped value.

calls: [remove_global_pseudo_class](r4-css-transform.md#u-d582bf731db0)

**Uncertainties.**

- The comma-deletion condition `children.length === findIndex(...) - 1` encodes an ordering assumption about multiple :global selectors that is not fully verifiable here

<a id="u-72124d453ad4"></a>
### `Declaration`

`Declaration(node, { state })` · [packages/svelte/src/compiler/phases/3-transform/css/index.js:L100-L137][f1]

Rewrites animation names and minifies declaration whitespace.

If the lowercased, prefix-stripped property is 'animation' or 'animation-name', it scans source characters building each candidate name; at a CSS name boundary it prepends the hash when the name is in state.keyframes, and stops the scan at ';' or '}'. Otherwise, only when state.minify, it removes whitespace before the declaration and collapses whitespace after the colon, skipping custom properties starting with '--' because older Chromium treats '--foo: ;' differently from '--foo:;'.

calls: [remove_css_prefix](r4-compiler-infra.md#u-e3a939a3b9f2)

<a id="u-f014322fd2ad"></a>
### `packages/svelte/src/compiler/phases/3-transform/css/index.js:PseudoClassSelector`

`PseudoClassSelector(node, context)` · [packages/svelte/src/compiler/phases/3-transform/css/index.js:L373-L377][f1]

Descends only into the logical pseudo-classes :is, :where, :has and :not via next(); every other pseudo-class selector is left unvisited.

<a id="u-b57c2c0ef514"></a>
### `packages/svelte/src/compiler/phases/3-transform/css/index.js:Rule`

`Rule(node, { state, next, visit, path })` · [packages/svelte/src/compiler/phases/3-transform/css/index.js:L138-L197][f1]

Decides whether a rule survives, is removed, or is commented out.

When minifying it first strips whitespace before the rule and before its closing brace. If not dev and is_empty says the rule is empty (passing the global-block context), it removes the rule when minifying, otherwise wraps it in '/* (empty) ... */' with escape_comment_close preventing comment-terminator breakouts; then returns. If is_used is false and the rule is not in a global block, the same removal/'(unused)' comment treatment applies. If the rule is a :global block whose prelude is exactly one complex selector with one compound selector, it comments out the 'selector {' and '}' parts (or deletes them when minifying) and visits only the block body, returning without next(). Otherwise next() recurses.

**Notes.**

- condition: Empty rules are kept in dev for devtools visibility

calls: [is_empty](r4-css-transform.md#u-850d391518fa), [is_used](r4-css-transform.md#u-b3b67c9d0361), [escape_comment_close](r4-css-transform.md#u-8e64579cb2b1)

<a id="u-d592a4a39c2c"></a>
### `SelectorList`

`SelectorList(node, { state, next, path })` · [packages/svelte/src/compiler/phases/3-transform/css/index.js:L198-L282][f1]

Prunes unused selectors from a selector list and resets specificity-bump state.

Comment/prune editing runs only when not inside a global block (except a multi-selector list in a global-block Rule) and no ancestor ComplexSelector is itself unused. It walks children toggling a 'pruning' flag at used/unused transitions: in minify mode it removes pruned ranges scanning back to the comma (dropping the comma only when no used selector preceded), otherwise it inserts '/* (unused) ' markers and appends '*/' at boundaries; a trailing pruned run is removed or closed at the last child's end. For specificity, if the parent is a Rule it starts with bumped:false but sets bumped:true when any ancestor rule via metadata.parent_rule has local selectors; outside a Rule it reuses the incoming state object. Passes the updated state into next().

calls: [packages/svelte/src/compiler/phases/3-transform/css/index.js:is_in_global_block](r4-css-transform.md#u-104caee60cc4)

**Uncertainties.**

- Exact comma placement in mixed used/unused runs relies on character scans whose edge behavior cannot be fully confirmed from the offsets alone

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/css/index.js
