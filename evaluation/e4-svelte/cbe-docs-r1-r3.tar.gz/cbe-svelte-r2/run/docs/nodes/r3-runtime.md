# Client Runtime

**Capability.** Implements client-side execution: the effect engine, DOM template factories, element bindings and custom elements, component mounting, error boundaries, reactive primitives, legacy component adapters, and the public API surface.

Use this subtree for everything that runs in the browser. The effect engine is the core; rendering, bindings, and reactive primitives all create or manage effects. Legacy adapters bridge Svelte 4 semantics onto this engine.

**Children.**

- [Effect Engine](r3-effects-engine.md) `r3-effects-engine` · 22 unit(s)
- [DOM Template Factories](r3-dom-template-factories.md) `r3-dom-template-factories` · 13 unit(s)
- [Element Bindings, Actions, and Custom Elements](r3-element-bindings.md) `r3-element-bindings` · 13 unit(s)
- [Component Mounting](r3-component-mounting.md) `r3-component-mounting` · 6 unit(s)
- [Client Error Boundaries](r3-client-error-handling.md) `r3-client-error-handling` · 4 unit(s)
- [Svelte 4 Client Compatibility](r3-legacy-client-runtime.md) `r3-legacy-client-runtime` · 6 unit(s)
- [Reactive Primitives and Stores](r3-reactive-primitives.md) `r3-reactive-primitives` · 5 unit(s)
- [Public API Surface and Types](r3-public-api.md) `r3-public-api` · 9 unit(s)

Parent: [Svelte Monorepo](r3-svelte-monorepo.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
