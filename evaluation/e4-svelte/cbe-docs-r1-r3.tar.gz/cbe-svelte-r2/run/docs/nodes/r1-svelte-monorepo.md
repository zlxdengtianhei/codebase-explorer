# Svelte Monorepo

**Capability.** Umbrella responsibility coordinating the Svelte compiler pipeline, the client/server runtimes, shared internals, the public type surface, and repository tooling; children each own one end-to-end responsibility.

Start here to navigate. Compilation lives under the compiler subtree, runtime behavior under runtime subtrees, user-facing type declarations under public surface, and scripts/benchmarks under tooling.

**Children.**

- [Svelte Compiler](r1-compiler.md) `r1-compiler` · 0 unit(s)
- [Client Runtime](r1-client-runtime.md) `r1-client-runtime` · 11 unit(s)
- [Boundaries & Async Blocks](r1-client-boundaries.md) `r1-client-boundaries` · 14 unit(s)
- [Dev-mode Diagnostics](r1-client-dev-dx.md) `r1-client-dev-dx` · 7 unit(s)
- [Shared Internals](r1-shared-internals.md) `r1-shared-internals` · 22 unit(s)
- [Server Runtime \(SSR\)](r1-server-runtime.md) `r1-server-runtime` · 7 unit(s)
- [Public API Surface](r1-public-surface.md) `r1-public-surface` · 0 unit(s)
- [Repo Tooling & Benchmarks](r1-tooling.md) `r1-tooling` · 0 unit(s)

Parent: [Svelte Monorepo](svelte-monorepo.md)

## Units (2)

<a id="u-d5d1e7157705"></a>
### `set.test.ts-set-reactivity-tests`

`group` · [packages/svelte/src/reactivity/set.test.ts:L1-L159][f1]

Vitest suite for SvelteSet covering reactivity and mutation semantics.

Cases build sets, read them inside render effects within an effect_root, mutate under flushSync, and assert exact effect re-run logs: `values()` iteration, `size`, `has`, `Array.from`, and `forEach` all re-run on relevant changes; deleting then re-adding a value only re-runs effects that observed the intermediate state (a `has` effect that never saw the value does not re-run on re-add). `delete` returns true/false per presence like Set, and `new SvelteSet() instanceof Set` holds.

**Uncertainties.**

- SvelteSet implementation itself is not in this batch; assertions encode expected behavior but the implementation cannot be verified here.

<a id="u-c87771427bc5"></a>
### `types.d.ts-internal-types`

`type EventCallback = (event: Event) => boolean;` · [packages/svelte/src/internal/client/types.d.ts:L5-L5][f2]

Type-only declarations for the Svelte client runtime internals.

ComponentContext is the single-character-keyed per-component node (p parent, c context map, e deferred effects, s props, x exports, l legacy signals/update-callbacks/$: state, optional DEV-only function); ComponentContextLegacy narrows l to non-null. Other aliases describe event callback maps, the Equals comparator, template/DOM node unions, each-block state and linked-list items, transition/animation managers and configs, store reference containers, action payloads, the Raf test seam, Task/TaskEntry/TaskCallback scheduling types, ProxyStateObject (tagged with STATE_SYMBOL), SourceLocation, and the DevStackEntry debug stack node. The file re-exports './reactivity/types' at the end; no runtime behavior exists here.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/reactivity/set.test.ts
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/types.d.ts
