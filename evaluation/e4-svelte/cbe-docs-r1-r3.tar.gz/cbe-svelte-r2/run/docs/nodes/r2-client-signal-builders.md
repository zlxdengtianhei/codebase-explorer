# Client signal builders

**Capability.** Builds the client runtime's signal expressions: read getters, prop/state sources, proxy decisions, derived creation and hoisted-function parameter computation for event handlers.

Use build_getter, get_prop_source/is_prop_source, is_state_source and should_proxy to understand how bindings become signals, and get_hoisted_params for which parameters hoisted event-handler functions receive. create_derived wraps expressions into derived-signal calls.

**Depended on by.**

- [Client transform visitors](r2-client-visitors.md) · graph-confirmed · 4 edge(s) · Client visitors construct emitted runtime call expressions (getters, prop sources, deriveds) through the signal builders.
- [Shared transform utilities](r2-transform-shared.md) · model-inferred · 0 edge(s)
- [Client Transform](r6-transform-client.md) · graph-only · 14 edge(s)

Parent: [Client code generation](r2-client-transform.md)

## Units (20)

<a id="u-0360a1447240"></a>
### `utils.js module code (L1–L23)`

`module_region` · [packages/svelte/src/compiler/phases/3-transform/client/utils.js:L1-L23][f1]

Import block for builders, AST helpers, prop flag constants, dev state, walk, and validate_mutation; no runtime behavior beyond module loading.

<a id="u-66a19e20e1f1"></a>
### `build_getter`

`export function build_getter(node, state)` · [packages/svelte/src/compiler/phases/3-transform/client/utils.js:L36-L47][f1]

Builds the read expression for an identifier during client transformation.

If the state's transform map has an entry for the identifier's name and the node is not the binding's own declaration node, it returns `state.transform[name].read(node)`, delegating the actual rewrite (e.g. wrapping in `$.get(...)`) to the registered read function. Otherwise — untransformed names or the declaration site itself — it returns the identifier unchanged.

contract: [ClientTransformState](r6-transform-client-types.md#u-e21a2406661b)

**Uncertainties.**

- The behavior of each registered read function is defined by the visitors that install them, not by this file.

<a id="u-a89fb605f1f4"></a>
### `build_hoisted_params`

`export function build_hoisted_params(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/utils.js:L146-L166][f1]

Computes and records the full parameter list for a hoisted function.

It calls get_hoisted_params, stores the result on `node.metadata.hoisted_params`, then builds the emitted params: if the function has no own params but needs hoisted ones, a fresh `_`-prefixed identifier (via scope.generate) is added first for the event object; otherwise each declared param is transformed through `context.visit`. Hoisted params are appended after the function's own params.

calls: [get_hoisted_params](r2-client-signal-builders.md#u-7185711d9b41)

<a id="u-d8c62e2be238"></a>
### `create_derived`

`export function create_derived(state, expression, async = false)` · [packages/svelte/src/compiler/phases/3-transform/client/utils.js:L295-L303][f1]

Builds the call expression that creates a derived signal from an expression.

The expression is wrapped in a thunk (async when the `async` flag is set). For async derivations it emits `await $.save($.async_derived(thunk))`; otherwise it emits `$.derived(thunk)` in runes mode or `$.derived_safe_equal(thunk)` in legacy mode, matching legacy safe-equals semantics.

<a id="u-4af56d0c6065"></a>
### `push_unique`

`function push_unique(id)` · [packages/svelte/src/compiler/phases/3-transform/client/utils.js:L64-L68][f1]

Local helper; see get_hoisted_params.

<a id="u-61f872381d70"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/utils.js:visit`

`function visit(node, { next, stop })` · [packages/svelte/src/compiler/phases/3-transform/client/utils.js:L123-L130][f1]

Dev-mode walker handler: for each AssignmentExpression/UpdateExpression in the hoisted function, if `validate_mutation` returns something other than the node itself, the mutation needs ownership validation, so `$$ownership_validator` is pushed as a parameter and the walk stops; otherwise traversal continues.

calls: [validate_mutation](r5-client-transform.md#u-a58215b09609)

<a id="u-7185711d9b41"></a>
### `get_hoisted_params`

`function get_hoisted_params(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/utils.js:L54-L64][f1]

First segment of get_hoisted_params: sets up the params accumulator and the `push_unique` helper that appends an identifier only when no param with the same name exists, preventing clashes.

<a id="u-e75f8500d3ca"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/utils.js:get_hoisted_params`

`function get_hoisted_params(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/utils.js:L68-L123][f1]

Core of get_hoisted_params: iterates the current scope's references and collects parameters a hoisted (event-handler) function must receive.

For each reference bound outside the scope and not the function's own initial value: store subscriptions add both the store binding (`binding.node.name`) and the underlying store name; destructured `$.get(x)` member expressions are collapsed to just the derived signal identifier; prop/bindable_prop references that are not prop sources become `$$props`; imports are skipped; everything else is added as a copied identifier (to strip source-map positions), with rest_prop bindings in runes mode additionally adding `$$props` since delegated handlers may access them.

**Uncertainties.**

- The member-expression match requires exactly the shape `$.get(<Identifier>)`; deeper nesting or renamed internals would fall through to the generic path.

<a id="u-b509d17c0c83"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/utils.js:get_hoisted_params (2)`

`function get_hoisted_params(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/utils.js:L130-L139][f1]

Final segment: in dev mode it walks the function body with the visit handler to append `$$ownership_validator`, then returns the accumulated params.

<a id="u-d03f333899de"></a>
### `get_prop_source`

`export function get_prop_source(binding, state, name, initial)` · [packages/svelte/src/compiler/phases/3-transform/client/utils.js:L175-L230][f1]

Builds the `$.prop($$props, name, flags, initial?)` call that creates a prop source for a prop or bindable binding.

Flags accumulate bitwise: PROPS_IS_BINDABLE for bindable_prop, PROPS_IS_IMMUTABLE for immutable analyses, PROPS_IS_RUNES for runes mode, and PROPS_IS_UPDATED when accessors are on or (in immutable mode) the binding is reassigned or (runes) mutated, or (non-immutable) updated. The initial value is made lazy to avoid eager evaluation: simple expressions (per is_simple_expression) pass through unchanged and set no lazy flag; a zero-argument call expression passes its callee as the thunk factory; anything else is wrapped in `b.thunk`, and either lazy form sets PROPS_IS_LAZY_INITIAL. Flag and initial arguments are appended only when non-empty, so constant simple props emit a two-argument call.

calls: [is_simple_expression](r5-compiler-utilities.md#u-410082960042); uses: [is_prop_source](r2-client-signal-builders.md#u-38b8a75ee741)

<a id="u-38b8a75ee741"></a>
### `is_prop_source`

`export function is_prop_source(binding, state)` · [packages/svelte/src/compiler/phases/3-transform/client/utils.js:L238-L249][f1]

Decides whether a prop/bindable_prop binding needs an actual signal source rather than a plain `$$props` property read: true unless runes mode is off-conditions are all false — i.e. true when not in runes mode, when accessors exist, when the binding is reassigned, when it has an initial value, or when it was updated.

The `updated` case is commented as required while legacy mode exists, since legacy parents need coarse-grained reactivity.

<a id="u-4eba3d9b7ec5"></a>
### `is_state_source`

`export function is_state_source(binding, analysis)` · [packages/svelte/src/compiler/phases/3-transform/client/utils.js:L24-L29][f1]

Reports whether a `state`/`raw_state` binding must be rewritten on reads: true for those kinds when the analysis is not immutable, or when the binding is reassigned or the analysis has accessors.

Immutable, never-reassigned state without accessors therefore reads the raw value.

uses: [is_prop_source](r2-client-signal-builders.md#u-38b8a75ee741)

<a id="u-d089d4da67c8"></a>
### `should_proxy`

`export function should_proxy(node, scope)` · [packages/svelte/src/compiler/phases/3-transform/client/utils.js:L255-L287][f1]

Decides whether a state initializer expression needs `$.proxy` wrapping.

Returns false for falsy nodes, literals, template literals, arrow/function expressions, unary and binary expressions, and the identifier `undefined` — values that cannot hold proxied state. For a named identifier with a scope, it resolves the binding and, when bound to a non-reassigned initial that is not a function/class declaration, import, EachBlock, or SnippetBlock, recurses on that initial with a null scope; such bindings inherit the proxy decision of their initializer. Everything else returns true, meaning the value should be proxied.

calls: [should_proxy](r2-client-signal-builders.md#u-d089d4da67c8)

**Uncertainties.**

- The recursion passes scope=null, so an identifier initial that itself references another identifier cannot be resolved further and returns true.

<a id="u-ab39375a9f94"></a>
### `utils.js module code (L29–L35)`

`module_region` · [packages/svelte/src/compiler/phases/3-transform/client/utils.js:L29-L35][f1]

Residual lines between functions; no behavioral content.

<a id="u-79302e882f44"></a>
### `utils.js module code (L47–L53)`

`module_region` · [packages/svelte/src/compiler/phases/3-transform/client/utils.js:L47-L53][f1]

Residual lines between functions; no behavioral content.

<a id="u-d2e53b911400"></a>
### `utils.js module code (L139–L145)`

`module_region` · [packages/svelte/src/compiler/phases/3-transform/client/utils.js:L139-L145][f1]

Residual lines between functions; no behavioral content.

<a id="u-5f8d932aed7c"></a>
### `utils.js module code (L166–L174)`

`module_region` · [packages/svelte/src/compiler/phases/3-transform/client/utils.js:L166-L174][f1]

Residual lines between functions; no behavioral content.

<a id="u-17746ca4b126"></a>
### `utils.js module code (L230–L237)`

`module_region` · [packages/svelte/src/compiler/phases/3-transform/client/utils.js:L230-L237][f1]

Residual lines between functions; no behavioral content.

<a id="u-402ac3dc2835"></a>
### `utils.js module code (L249–L254)`

`module_region` · [packages/svelte/src/compiler/phases/3-transform/client/utils.js:L249-L254][f1]

Residual lines between functions; no behavioral content.

<a id="u-3983f2ef2e61"></a>
### `utils.js module code (L287–L294)`

`module_region` · [packages/svelte/src/compiler/phases/3-transform/client/utils.js:L287-L294][f1]

Residual lines between functions; no behavioral content.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/utils.js
