# Animation Helpers

**Capability.** Public flip animation helper computing First-Last-Invert-Play transforms between DOMRects, accounting for effective CSS zoom along the ancestor chain.

Use this for FLIP transition configuration. flip is the public entry; get_zoom is its zoom-awareness helper.

Parent: [Svelte Monorepo](r5-svelte-monorepo.md)

## Units (2)

<a id="u-2953ae0602e1"></a>
### `flip`

`export function flip(node, { from, to }, params = {})` · [packages/svelte/src/animate/index.js:L13-L58][f1]

Computes a First-Last-Invert-Play animation config that translates and scales an element between two DOMRect positions.

Parameters default to delay 0, duration `sqrt(d) * 120`, easing `cubicOut`; a function duration is applied to the Euclidean distance between start and end. It reads computed styles, normalizes the transform-origin to 0..1 fractions of client size, divides client/to dimensions by an effective zoom so parent CSS zoom and `currentCSSZoom` do not skew scale factors, derives translation (`(from - to) * scale correction`) and relative scales, and returns `{ delay, duration, easing, css }` where `css(t, u)` composes the preserved transform with translate and scale interpolated by `u`. The returned `css` string is generated per animation frame by the transition machinery, which is not in this file.

calls: [get_zoom](r5-animation-helpers.md#u-3fb604c120eb); uses: [get_zoom](r5-animation-helpers.md#u-3fb604c120eb)

**Uncertainties.**

- Behavior depends on `getComputedStyle` and the transition engine consuming the returned `css` function; neither is visible here.

<a id="u-3fb604c120eb"></a>
### `get_zoom`

`function get_zoom(element)` · [packages/svelte/src/animate/index.js:L63-L78][f1]

Returns the effective CSS zoom multiplying the element and all its ancestors.

If `currentCSSZoom` exists on the element it returns it directly (modern browsers), skipping the walk. Otherwise it multiplies `getComputedStyle(current).zoom` (coerced with unary `+`) down the `parentElement` chain starting at 1, so a non-numeric or missing zoom coerces to 0 or NaN and propagates through the product.

**Uncertainties.**

- What `+getComputedStyle(...).zoom` yields when `zoom` is unset (e.g. 'normal' coercing to NaN) is not handled in this code.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/animate/index.js
