# Analysis Visitors

**Capability.** Node-specific semantic checks: block emptiness and opening-tag validation, {@const} and let: placement, deprecated-pattern warnings, dynamic-subtree marking, and legacy reactive dependency collection for each blocks.

Each visitor file handles one node kind; common invariants are delegated to the shared-utils node. collect_transitive_dependencies is EachBlock's local helper for legacy reactive bindings.

**Depends on.**

- [Analysis Shared Validation](r1-compiler-analyze-shared-utils.md) · graph-confirmed · 12 edge(s) · Analysis visitors delegate shared validation invariants (assignment legality, identifier naming, block emptiness, purity) to the shared helpers.
- [Compiler Diagnostics](r1-compiler-diagnostics.md) · model-inferred · 0 edge(s)
- [Compiler Utilities and AST Helpers](r5-compiler-utilities.md) · graph-only · 10 edge(s)

Parent: [Analyze Phase](r1-compiler-analyze.md)

## Units (15)

<a id="u-5a0755c3b44f"></a>
### `ArrowFunctionExpression`

`export function ArrowFunctionExpression(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/ArrowFunctionExpression.js:L9-L11][f1]

Delegates arrow function analysis entirely to visit_function, which handles scope creation and function-scoped reactivity tracking.

calls: [visit_function](r6-compiler-analyze.md#u-98e829315086)

<a id="u-57ff0d312a51"></a>
### `AssignmentExpression`

`export function AssignmentExpression(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/AssignmentExpression.js:L10-L31][f2]

Analyzes assignment expressions, validating the target and recording bindings for reactive statements.

**Notes.**

- side_effect: Records assigned bindings into state.reactive_statement.assignments and sets state.expression.has_assignment when an expression context exists.
- condition: For MemberExpression targets, object(node.left) is computed first but every identifier of node.left is added; the non-null id check only gates the loop's outer access.

calls: [validate_assignment](r1-compiler-analyze-shared-utils.md#u-83497fe81c11), [extract_identifiers](r5-compiler-utilities.md#u-90eb95affc00), [object](r5-compiler-utilities.md#u-2f2548aeaec6)

**Uncertainties.**

- The shadowed loop variable `id` reuses the outer name; the outer `id !== null` check does not guard the loop, but extract_identifiers only yields identifiers so this appears safe.

<a id="u-e78635f9b260"></a>
### `packages/svelte/src/compiler/phases/2-analyze/visitors/AwaitBlock.js:AwaitBlock`

`export function AwaitBlock(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/AwaitBlock.js:L11-L48][f3]

Analyzes {#await} blocks: rejects empty pending/then/catch, and in runes mode validates the opening tag and the 10 characters before the value/error for a stray ':' after '{:then' or '{:catch', raising block_unexpected_character with a position range.

Marks the subtree dynamic, then visits the promise expression with its own expression metadata, and each present child block. Only the value/error character checks are runes-gated; the empty-block validation always runs.

calls: [validate_block_not_empty](r1-compiler-analyze-shared-utils.md#u-b877c3a87dc5), [validate_opening_tag](r1-compiler-analyze-shared-utils.md#u-8a95b3b7e6dc), [mark_subtree_dynamic](r6-compiler-analyze.md#u-3e6e9a44c2b4)

**Uncertainties.**

- Whether block_unexpected_character throws or only records an error depends on the errors module, not supplied here.

<a id="u-12bb8c39d56d"></a>
### `packages/svelte/src/compiler/phases/2-analyze/visitors/ClassDeclaration.js:ClassDeclaration`

`export function ClassDeclaration(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/ClassDeclaration.js:L10-L25][f4]

Analyzes class declarations: in runes mode with a non-null id it validates the class binding's name, then warns perf_avoid_nested_class when the class is nested deeper than allowed — depth 0 in modules, 1 in components (so component-scope top-level is fine, but `new class` anywhere deeper is warned too).

Always continues traversal.

calls: [validate_identifier_name](r1-compiler-analyze-shared-utils.md#u-e442f835d467)

<a id="u-8d41d0decaea"></a>
### `ClassDirective`

`export function ClassDirective(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/ClassDirective.js:L10-L13][f5]

Marks the enclosing subtree dynamic for a `class:` directive, then continues the walk with state.expression set to the directive's metadata expression.

<a id="u-c1ba3ccb02a9"></a>
### `packages/svelte/src/compiler/phases/2-analyze/visitors/ConstTag.js:ConstTag`

`export function ConstTag(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/ConstTag.js:L10-L39][f6]

Analyzes {@const} tags: in runes mode validates the opening tag, then enforces placement — the tag's immediate parent must be a Fragment, and its grandparent must be one of the allowed block/component/snippet types, or an element carrying a `slot` attribute; otherwise const_tag_invalid_placement is raised.

Visits the declaration's id and its initializer, the latter with expression metadata from the tag.

calls: [validate_opening_tag](r1-compiler-analyze-shared-utils.md#u-8a95b3b7e6dc)

**Uncertainties.**

- Whether validate_opening_tag or const_tag_invalid_placement abort analysis depends on unsupplied error machinery.

<a id="u-dbb0147495c2"></a>
### `EachBlock`

`export function EachBlock(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/EachBlock.js:L13-L72][f7]

Analyzes {#each} blocks: validates the opening tag and that body and fallback are non-empty; errors state_invalid_placement if the loop context identifier is literally named $state or $derived.

When a key exists, metadata.keyed is true unless the key is an identifier equal to the index (indexed, not keyed). The expression is visited in the parent scope so its dependencies reflect outer bindings; body, key, and fallback follow. In non-runes mode it detects whether the context binding is mutated, collects transitive legacy dependencies, and upgrades affected normal const/let/var bindings to 'state' so they become mutable sources. Finally marks the subtree dynamic.

calls: [collect_transitive_dependencies](r1-compiler-analyze-visitors.md#u-8ffd455023da), [validate_opening_tag](r1-compiler-analyze-shared-utils.md#u-8a95b3b7e6dc), [mark_subtree_dynamic](r6-compiler-analyze.md#u-3e6e9a44c2b4)

**Uncertainties.**

- Whether the transitive-deps upgrade to 'state' also applies to bindings not in transitive_deps is moot; only those in the set are upgraded.

<a id="u-8ffd455023da"></a>
### `collect_transitive_dependencies`

`function collect_transitive_dependencies(binding, bindings)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/EachBlock.js:L79-L90][f7]

Recursively adds a binding and, while the binding is legacy_reactive, all of its legacy_dependencies to the target set, guarding cycles by skipping already-present bindings.

Private helper of EachBlock, not exported.

<a id="u-f5a889520a52"></a>
### `LetDirective`

`export function LetDirective(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/LetDirective.js:L9-L24][f8]

Validates let: directive placement: errors let_directive_invalid_placement unless the directive's immediate parent is a Component, RegularElement, SlotElement, SvelteElement, SvelteComponent, SvelteSelf, or SvelteFragment.

A missing parent also errors. No traversal occurs.

<a id="u-97612de06878"></a>
### `MemberExpression`

`export function MemberExpression(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/MemberExpression.js:L10-L28][f9]

Analyzes member expressions.

If both object and property are identifiers and the object's binding is a rest_prop whose property name starts with '$$', errors props_illegal_name (guarding reserved $$props names on rest spreads). Inside an expression context it sets has_member_expression and ORs has_state with whether the expression is non-pure. When the identifier is not a safe identifier (could change between reads), analysis.needs_context is set to force runtime context. Continues traversal.

calls: [is_pure](r1-compiler-analyze-shared-utils.md#u-c8c562a3fb44), [is_safe_identifier](r1-compiler-analyze-shared-utils.md#u-63a6d609f552)

<a id="u-317efed2ef7a"></a>
### `packages/svelte/src/compiler/phases/2-analyze/visitors/SlotElement.js:SlotElement`

`export function SlotElement(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/SlotElement.js:L12-L42][f10]

Analyzes <slot> elements: warns slot_element_deprecated in runes mode outside custom elements and marks the subtree dynamic.

The effective slot name starts as 'default'; a `name` attribute must be a static text attribute (else slot_element_invalid_name) and must not be 'default' itself (slot_element_invalid_name_default). Any attribute other than a normal Attribute, SpreadAttribute, or LetDirective raises slot_element_invalid_attribute. Registers the resolved name in analysis.slot_names and continues traversal.

calls: [is_text_attribute](r5-compiler-utilities.md#u-ec400088cae5)

<a id="u-e9c21a24251a"></a>
### `StyleDirective`

`export function StyleDirective(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/StyleDirective.js:L11-L38][f11]

Analyzes style: directives.

More than one modifier, or any modifier other than a single 'important', raises style_directive_invalid_modifier. Marks the subtree dynamic. For shorthand style:name (value === true), it looks up the name's binding and flags has_state when the binding kind is not 'normal'. Otherwise it visits the value and then propagates has_state, has_call, and has_await from each contained ExpressionTag chunk into the directive's own expression metadata.

calls: [get_attribute_chunks](r5-compiler-utilities.md#u-1096ddb4c2b1)

**Uncertainties.**

- In the shorthand case, no context.next() is called — child traversal is skipped for shorthand directives.

<a id="u-51de6fed2f32"></a>
### `packages/svelte/src/compiler/phases/2-analyze/visitors/SvelteDocument.js:SvelteDocument`

`export function SvelteDocument(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/SvelteDocument.js:L11-L24][f12]

Analyzes <svelte:document>: disallows child elements via disallow_children, and rejects any SpreadAttribute or non-event Attribute with illegal_element_attribute attributed to 'svelte:document'.

Continues traversal.

calls: [disallow_children](r6-compiler-analyze.md#u-43b79d8932ce)

<a id="u-de902d0a63f3"></a>
### `packages/svelte/src/compiler/phases/2-analyze/visitors/SvelteWindow.js:SvelteWindow`

`export function SvelteWindow(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/SvelteWindow.js:L11-L24][f13]

Validates `<svelte:window>`: disallow_children rejects element children, and any spread or non-event attribute raises e.illegal_element_attribute with 'svelte:window'; only event attributes are permitted.

context.next() runs after the checks.

calls: [disallow_children](r6-compiler-analyze.md#u-43b79d8932ce), [is_event_attribute](r5-compiler-utilities.md#u-1c2da82112be)

<a id="u-7d4fa5b13c15"></a>
### `validate_element`

`export function validate_element(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/shared/element.js:L29-L155][f14]

Validates the attribute list of a regular or svelte element, dispatching per attribute type and throwing or warning on invalid usage.

For plain Attribute nodes: in runes mode it runs validate_attribute and rejects unparenthesized SequenceExpression values by scanning the source backwards from the expression start ('(' accepts, '{' throws attribute_invalid_sequence_expression). It throws attribute_invalid_name when the name matches regex_illegal_attribute_character; an on* name (longer than 'on') must have an expression value, else attribute_invalid_event_handler is thrown, and an Identifier equal to the attribute name with no binding warns attribute_global_event_reference. A slot attribute is delegated to validate_slot_attribute with is_component defaulting to false; the 'is' attribute warns attribute_avoid_is; React-style names className/htmlFor warn with the suggested Svelte name; validate_attribute_name always runs. AnimateDirective must sit directly in a keyed EachBlock whose body contains at most one non-comment, non-const, non-whitespace node (animation_invalid_placement / animation_missing_key / animation_duplicate otherwise). TransitionDirective: an existing in- or out-transition matching the new one's direction throws transition_duplicate (same kind) or transition_conflict (in vs out); the new directive then registers as in_transition/out_transition. OnDirective modifiers must all be in EVENT_MODIFIERS (else event_handler_invalid_modifier with the full list), and 'passive' combined with 'nonpassive' or 'preventDefault' throws event_handler_invalid_modifier_combination as soon as both are seen.

calls: [validate_attribute](r5-analyze-phase.md#u-001c69caf1f6), [validate_attribute_name](r5-analyze-phase.md#u-c4e14f91c1c8), [validate_slot_attribute](r5-analyze-phase.md#u-be5b4cd34d6a), [is_expression_attribute](r5-compiler-utilities.md#u-f63f079d6472), [get_attribute_expression](r5-compiler-utilities.md#u-96e6f6d66786)

**Uncertainties.**

- validate_slot_attribute is called without the is_component argument, so it defaults to false inside element validation; callers of validate_element determine whether that is correct for each element kind.
- The react_attributes map only contains className and htmlFor, so no other React names are flagged.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/ArrowFunctionExpression.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/AssignmentExpression.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/AwaitBlock.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/ClassDeclaration.js
[f5]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/ClassDirective.js
[f6]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/ConstTag.js
[f7]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/EachBlock.js
[f8]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/LetDirective.js
[f9]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/MemberExpression.js
[f10]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/SlotElement.js
[f11]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/StyleDirective.js
[f12]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/SvelteDocument.js
[f13]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/SvelteWindow.js
[f14]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/shared/element.js
