# Store Contract

**Capability.** Implements writable/readable/derived/readonly/get per the Svelte store contract, with subscribe_to_store handling subscription and invalidation callbacks.

Use these for store creation and one-shot reads. readable wraps writable; derived composes sources via readable; get reads synchronously through subscribe_to_store.

**Depends on.**

- [Shared Utilities and Tests](r6-shared-infra.md) · graph-confirmed · 1 edge(s)

**Depended on by.**

- [Spring Motion](r6-motion.md) · graph-confirmed · 1 edge(s)

Parent: [Stores, Motion, and Reactive Values](r6-stores-motion-reactivity.md)

## Units (6)

<a id="u-dc45d71b793b"></a>
### `writable`

`export function writable(value, start = noop)` · [packages/svelte/src/store/shared/index.js:L34-L45][f1]

Creates a Writable store holding value, with an optional start notifier (default noop) invoked with set and update when the first subscriber arrives.

set(new_value) only acts when safe_not_equal(value, new_value) holds: it stores the value, and if the store is started (stop is truthy) it first calls every subscriber's invalidate callback, pushing (subscriber, value) pairs onto the shared module-level subscriber_queue, then — only if this call started with an empty queue (run_queue) — drains it by invoking each subscriber's run function with its recorded value and clears the queue; nested sets triggered by those run callbacks therefore append to the queue and are drained by the outermost caller. When not yet started, the value is stored and subscribers receive it via their initial run in subscribe. update(fn) applies fn to the current value and delegates to set. subscribe(run, invalidate=noop) registers the [run, invalidate] tuple; on becoming the first subscriber it runs start(set, update) and coerces a falsy return to noop, then immediately calls run with the current value; the returned unsubscriber removes the tuple and, when the last subscriber leaves and stop exists, calls stop and resets it to null.

**Notes.**

- side_effect: Uses a module-level subscriber_queue shared across all writable stores; only the outermost set call drains it, batching nested set calls.
- contract: A subscriber's run callback executes synchronously on subscribe with the current value; invalidate runs before run during a set cycle.

calls: [writable](r6-stores.md#u-dc45d71b793b)

**Uncertainties.**

- safe_not_equal's exact semantics live in the equality module not supplied.

<a id="u-e3031b84c99c"></a>
### `readable`

`export function readable(value, start)` · [packages/svelte/src/store/shared/index.js:L20-L24][f1]

Creates a Readable store view over an underlying writable store initialized with value and optional start notifier.

Returns an object exposing only the subscribe method of a fresh writable(value, start), hiding set/update; the start notifier fires on first subscriber and its stop logic runs on last unsubscribe exactly as in writable.

calls: [writable](r6-stores.md#u-dc45d71b793b)

<a id="u-d2fec82a964b"></a>
### `packages/svelte/src/store/shared/index.js:derived`

`export function derived(stores, fn, initial_value)` · [packages/svelte/src/store/shared/index.js:L129-L143][f1]

Creates a Readable store whose value is computed from one or more source stores via fn, rebuilt lazily per subscriber through readable(initial_value, ...).

Accepts either a single store or an array (single = !Array.isArray); throws Error('derived() expects stores as input, got a falsy value') if any store is falsy. auto is true when fn takes fewer than 2 declared parameters, switching between the set-style and auto-return API. Inside the start notifier, each source is subscribed via subscribe_to_store: the invalidate callback marks slot i pending via a bitfield (pending |= 1 << i), and the value callback records values[i], clears that bit, and — once started — triggers sync. sync() is a no-op while any source is pending; otherwise it runs the previous cleanup, calls fn(values or single value, set, update), and in auto mode pushes the result via set, whereas in non-auto mode it stores a returned function as the next cleanup. stop (returned when the last subscriber unsubscribes) runs all source unsubscribers via run_all, invokes the pending cleanup, and resets started to false so queued-but-late callbacks will not re-sync; started is set true and sync runs once at start so the initial value is computed with all sources present.

**Notes.**

- failure: Falsy store inputs throw synchronously before any subscription is made.
- condition: fn.length < 2 selects the auto mode: the returned value is set automatically; otherwise fn must call set/update and may return a cleanup function.

calls: [packages/svelte/src/store/shared/index.js:derived](r6-stores.md#u-d2fec82a964b), [readable](r6-stores.md#u-e3031b84c99c)

**Uncertainties.**

- subscribe_to_store's invalidate/notify ordering is defined in store/utils.js, not supplied.

<a id="u-624938d77758"></a>
### `packages/svelte/src/store/shared/index.js:get`

`export function get(store)` · [packages/svelte/src/store/shared/index.js:L204-L209][f1]

Synchronously reads a store's current value by subscribing via subscribe_to_store with a callback that captures each emitted value, then immediately invoking the returned unsubscriber.

Returns the captured value; if the store never emits, the return value is undefined (typing suppressed). No value is retained after the call.

calls: [packages/svelte/src/store/shared/index.js:get](r6-stores.md#u-624938d77758)

**Uncertainties.**

- Whether start notifiers run and are cleaned up depends on subscribe_to_store's implementation.

<a id="u-01eea88b3e69"></a>
### `readonly`

`export function readonly(store)` · [packages/svelte/src/store/shared/index.js:L190-L195][f1]

Wraps a store to expose only its subscribe method, bound to the original store, producing a Readable view that cannot be updated through this object.

Contains no copying or guarding: writes to the underlying store remain possible via the original reference.

<a id="u-863f9153e183"></a>
### `subscribe_to_store`

`export function subscribe_to_store(store, run, invalidate)` · [packages/svelte/src/store/utils.js:L12-L36][f2]

Subscribes a run callback (and optional invalidate callback) to a store and returns an unsubscribe function.

If the store is null or undefined, it calls run(undefined) and invalidate(undefined) immediately and returns a no-op unsubscribe. Otherwise it subscribes inside untrack — silencing validation errors that a mutating start/stop notifier could otherwise trigger — passing invalidate as the store's private second argument. The returned value is normalized for RxJS-style subscriptions: if it has an unsubscribe method, it wraps it in a new function; otherwise it is returned as-is.

uses: [utils.js module code (L1–L11)][f2]

**Uncertainties.**

- Relies on the store contract accepting a second invalidate argument; non-conforming stores' behavior with that argument is unverifiable here.
- run/invalidate are invoked synchronously inside the store's subscribe per the store contract, not directly in this function.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/store/shared/index.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/store/utils.js
