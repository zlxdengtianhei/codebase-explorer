# Server Transform (SSR)

**Capability.** Lowers blocks, components, snippets, runes, and declarations into payload-printing server code ($.await, $.ensure_array_like, build_inline_component, snippet function declarations).

Use to see how SSR output is emitted synchronously into $$payload. Component/SvelteComponent share build_inline_component; VariableDeclaration rebuilds declarations per binding kind.

Parent: [Code Generation](r6-compiler-transform.md)

## Units (10)

<a id="u-8619e1ace336"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/AwaitBlock.js:AwaitBlock`

`export function AwaitBlock(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/AwaitBlock.js:L11-L29][f1]

Emits server code for an {#await} block as a `$.await($$payload, expression, pendingThunk, thenArrow)` statement appended to the template.

The pending thunk is the visited pending block or an empty block; the arrow takes the visited value pattern (or no parameter) and its body is the visited then block or an empty block. A block_close marker is pushed afterwards for hydration alignment.

imports: [utils.js module code (L1–L29)][f2]

<a id="u-9d632fc04d55"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/AwaitExpression.js:AwaitExpression`

`export function AwaitExpression(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/AwaitExpression.js:L9-L25][f3]

Decides whether a top-level `await` is legal on the server.

If function_depth is 0 (still in component body) the await is allowed and traversal continues via context.next(); the same applies when any ancestor in context.path is an arrow/function declaration/expression. Otherwise, meaning the await sits inside a function and outside the boundary per the source comment, it returns `$.await_outside_boundary(...)`, presumably a runtime error trigger.

**Uncertainties.**

- The exact runtime effect of `$.await_outside_boundary` is not shown; whether context.path is never empty (making the depth-0 check necessary) is inferred only from `context.path.some`

<a id="u-095e9ef68802"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/CallExpression.js:CallExpression`

`export function CallExpression(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/CallExpression.js:L12-L54][f4]

Rewrites Svelte rune calls to their server runtime equivalents.

`$host` becomes void 0, `$effect.tracking` false, `$effect.root` an empty arrow mimicking a cleanup function, `$effect.pending` literal 0. `$state`/`$state.raw` return the visited first argument or void 0 when absent. `$derived` wraps the visited function in a thunk inside `$.derived`; `$derived.by` passes the function directly. `$state.snapshot` becomes `$.snapshot(value, true?)` where the second argument is `true` only when `state_snapshot_uncloneable` is ignored. `$inspect` forms delegate to transform_inspect_rune. Any other call falls through to context.next().

calls: [get_rune](r3-scope-node-model.md#u-5204b6ce4f7a), [transform_inspect_rune](r2-transform-shared.md#u-f64464c8fc01), [state.js-module-level-compiler-state](r2-compiler-infrastructure.md#u-d73d7b033038)

**Uncertainties.**

- Returns undefined (not context.next()) after the final context.next(), relying on the visitor to mutate in place

<a id="u-fb63ecc7b839"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/Component.js:Component`

`export function Component(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/Component.js:L10-L12][f5]

SSR visitor for a `<Component />` element: delegates to build_inline_component with an identifier referencing the component's name.

calls: [build_inline_component](r5-server-transform.md#u-b4ac53ff3e29)

<a id="u-4806d5caedfd"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/EachBlock.js:EachBlock`

`export function EachBlock(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/EachBlock.js:L12-L66][f6]

Emits a {#each} block as a for-loop over `$.ensure_array_like(collection)`.

The loop index is the block's metadata index when group bindings are present or no user index exists, otherwise a fresh `each_array`-scoped id; a shadowing `let node.index = index` is emitted when names differ but a user index exists. The item variable is bound via `let context = each_array[index]` when present, then the visited body statements are inlined into the loop. With a fallback (else clause), the template gets an if on `each_array.length !== 0` choosing between an opening comment plus the loop and the fallback block preceded by a BLOCK_OPEN_ELSE push; without a fallback it pushes block_open, the loop, and block_close.

imports: [utils.js module code (L1–L29)][f2]

**Uncertainties.**

- Whether metadata.index and metadata.contains_group_binding are always defined on each-block nodes is assumed from usage

<a id="u-04c02a2801ab"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/Fragment.js:Fragment`

`export function Fragment(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/Fragment.js:L11-L46][f7]

Transforms a fragment into a block combining hoisted statements and rendered template.

It infers the namespace from the parent node and children, then clean_nodes partitions and trims the child list (honoring preserve_whitespace and preserveComments), reporting whether content is standalone and text-first. A child state is created with fresh init/template arrays and skip_hydration_boundaries set to is_standalone; hoisted nodes are visited first, an empty comment is pushed when is_text_first so the output does not glue to the previous fragment, then process_children renders the trimmed nodes. Returns `b.block([...init, ...build_template(template)])`.

calls: [clean_nodes](r2-transform-shared.md#u-2ed26069223c), [infer_namespace](r2-transform-shared.md#u-b0bc5038f26b), [build_template](r4-server-transform.md#u-7d424d7f2d77), [packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/utils.js:process_children](r4-server-transform.md#u-e9ea6b8060a4)

**Uncertainties.**

- Exact semantics of clean_nodes outputs (hoisted/trimmed/is_standalone/is_text_first) live in utils.js, not shown here

<a id="u-80641b90f11d"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/SnippetBlock.js:SnippetBlock`

`export function SnippetBlock(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/SnippetBlock.js:L11-L29][f8]

Turns a {#snippet} into a function declaration taking `$$payload` plus the snippet parameters, with the visited body.

The function gets a `___snippet = true` marker used by legacy $$render_inner handling, and is pushed into state.hoisted when metadata.can_hoist, otherwise state.init. In dev, `$.validate_snippet_args($$payload)` is prepended to the body and a `$.prevent_snippet_stringification(fn.id)` statement is pushed alongside the declaration.

**Uncertainties.**

- Consumers of the `___snippet` marker are outside this file

<a id="u-f0eb98c41b5a"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/SvelteComponent.js:SvelteComponent`

`export function SvelteComponent(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/SvelteComponent.js:L10-L12][f9]

SSR visitor for `<svelte:component this={...}>`: delegates to build_inline_component with the transformed `this` expression as the component reference.

calls: [build_inline_component](r5-server-transform.md#u-b4ac53ff3e29)

<a id="u-4d51e6360b98"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/VariableDeclaration.js:VariableDeclaration`

`export function VariableDeclaration(node, context)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/VariableDeclaration.js:L15-L36][f10]

Rebuilds variable declarations per binding kind.

In runes mode, each declarator's init rune is inspected: missing, $effect.tracking, $inspect, or $effect.root runes are visited normally; `$props.id` is dropped entirely; `$props` declarations are rewritten against `$$props` — `$bindable()` defaults in the pattern are replaced by their argument or void 0, a top-level rest element is flagged, and `$$slots`/`$$events` are hidden from consumers either by inserting rest-pattern properties (aliased to `$$slots_` when analysis.uses_slots) or, for an identifier id, by wrapping in an object pattern with a rest of that name; other runes take the first call argument (or void 0) as the value, with `$derived.by` wrapping it in a call, Identifier ids getting the value directly, `$derived` visiting the pattern, and everything else delegating to create_state_declarators for destructuring. In legacy mode, declarators without state or bindable_prop bindings are visited as-is; bindable props become `$$props['name-or-alias']` with the visited init as fallback via build_fallback, where non-identifier patterns extract leaf paths (inserts get `$$array` temporaries); otherwise state bindings go through create_state_declarators. Returns b.empty when nothing remains, else the node with new declarations.

calls: [get_rune](r3-scope-node-model.md#u-5204b6ce4f7a), [function::create_state_declarators::6126](../../catalog.json), [build_fallback](r5-compiler-utilities.md#u-287d48fe390a), [extract_paths](r5-compiler-utilities.md#u-34f2fcb20c62), [Scope](r3-scope-node-model.md#u-01a82e58170d)

**Uncertainties.**

- The walk visitor's RestElement handler only sets has_rest and returns undefined (no replacement), relying on walk semantics for pattern traversal
- inserts/paths shapes from extract_paths (id/name/expression fields) are used per their documented contract in ast.js, not verified here

<a id="u-26d37038317b"></a>
### `packages/svelte/src/compiler/phases/3-transform/server/visitors/VariableDeclaration.js:create_state_declarators`

`function create_state_declarators(declarator, scope, value)` · [packages/svelte/src/compiler/phases/3-transform/server/visitors/VariableDeclaration.js:L194-L212][f10]

Expands a destructured state declarator into multiple declarations.

Identifier ids yield a single declarator of the value. Otherwise a `tmp` id (scope-generated) receives the value; extract_paths produces `inserts` (each turned into a declarator with a scope-generated `$$array` name) and `paths` (each leaf becomes a declarator initialized with its path expression against tmp). Returns the declarator list in that order.

calls: [extract_paths](r5-compiler-utilities.md#u-34f2fcb20c62)

**Uncertainties.**

- Relies on extract_paths computing path expressions against the tmp id; that implementation is in ast.js

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/AwaitBlock.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/utils.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/AwaitExpression.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/CallExpression.js
[f5]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/Component.js
[f6]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/EachBlock.js
[f7]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/Fragment.js
[f8]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/SnippetBlock.js
[f9]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/SvelteComponent.js
[f10]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/server/visitors/VariableDeclaration.js
