# Compiler Diagnostics

**Capability.** Owns the compiler's error surface: the InternalCompileError class that unifies error/warning diagnostic shape (toJSON, toString), the internal throw helper, and the generated per-code error factories covering every compiler error code.

Errors thrown anywhere in the compiler originate here. The generated factory group depends on the throw helper `e`; InternalCompileError shapes what tooling sees.

**Depended on by.**

- [Analysis Visitors](r1-compiler-analyze-visitors.md) · model-inferred · 0 edge(s)
- [Parse Phase](r1-compiler-parse.md) · model-inferred · 0 edge(s)
- [svelte:options Reading](r1-compiler-parse-options.md) · model-inferred · 0 edge(s)
- [Shared Internals](r1-shared-internals.md) · model-inferred · 0 edge(s)

Parent: [Svelte Compiler](r1-compiler.md)

## Units (6)

<a id="u-adef92463631"></a>
### `errors-js-generated-error-factories`

`export function options_invalid_value(node, details)` · [packages/svelte/src/compiler/errors.js:L56-L58][f1]

Generated export for each compiler error code (options_invalid_value through void_element_invalid_content).

Each exported factory takes a node (or position number) plus message-specific interpolation arguments, builds a fixed message template ending with a https://svelte.dev/e/<code> link, and calls the internal throw helper e, which throws a CompileError positioned at the node. All factories are declared to return never; only bind_invalid_name varies its message conditionally, appending the optional explanation after 'not a valid binding' when one is supplied. These functions contain no other logic and perform no state changes.

calls: [packages/svelte/src/compiler/errors.js:e](r1-compiler-diagnostics.md#u-35e148f96f15)

**Uncertainties.**

- Exact parameter sets vary per factory per the JSDoc; the group covers them uniformly without listing each signature.

<a id="u-38874e25f3b9"></a>
### `packages/svelte/src/compiler/errors.js:InternalCompileError`

`class InternalCompileError extends Error` · [packages/svelte/src/compiler/errors.js:L6-L15][f1]

Wraps compiler errors so thrown objects are real Errors yet share the warning diagnostic shape.

The constructor calls super(message), blanks the stack, builds a private CompileDiagnostic from (code, message, position), copies its enumerable properties onto the error via Object.assign, sets name to 'CompileError', and keeps message as an own enumerable field. toString and toJSON delegate to the private diagnostic.

inherits: [class::CompileDiagnostic][f2]

**Uncertainties.**

- The inventory lists a second InternalCompileError class entry (lines 34-35); its content is not visible here, so it is folded into this unit only as a range artifact, not as behavior.

<a id="u-35e148f96f15"></a>
### `packages/svelte/src/compiler/errors.js:e`

`function e(node, code, message)` · [packages/svelte/src/compiler/errors.js:L43-L48][f1]

Internal throw helper for every generated error factory.

It derives start/end from the first argument: if the argument is a number it is used as both start and end; otherwise start and end are read from the object's optional .start/.end fields (null yields undefined). It throws an InternalCompileError with (code, message) and a [start, end] position when a start is present, falling back to end===start when no end exists; with no start the position is undefined.

**Notes.**

- condition: If node is null, both start and end are undefined and the error is created without a position.
- failure: This function never returns (declared never); the InternalCompileError propagates to the caller of the wrapping factory.

<a id="u-b3eaa9f85b08"></a>
### `packages/svelte/src/compiler/errors.js:InternalCompileError.constructor`

`constructor(code, message, position)` · [packages/svelte/src/compiler/errors.js:L15-L26][f1]

Initializes the error: stores the message via super, sets this.stack to an empty string (deliberately not a class property so it stays non-enumerable), creates the shared CompileDiagnostic, copies its properties onto this with Object.assign, and names the error 'CompileError'.

**Notes.**

- side_effect: Copies all own enumerable properties of the CompileDiagnostic onto the error instance, so consumers see the same shape as warnings.

<a id="u-b87ccdf77f1a"></a>
### `packages/svelte/src/compiler/errors.js:InternalCompileError.toJSON`

`toJSON()` · [packages/svelte/src/compiler/errors.js:L32-L34][f1]

Serialization hook that returns the private CompileDiagnostic's toJSON output, giving errors and warnings an identical JSON shape.

calls: [CompileDiagnostic](r2-compiler-infrastructure.md#u-49c3d847da08)

<a id="u-e2ea9900220c"></a>
### `packages/svelte/src/compiler/errors.js:InternalCompileError.toString`

`toString()` · [packages/svelte/src/compiler/errors.js:L28-L30][f1]

Returns the string produced by the private CompileDiagnostic's toString, rather than the default Error formatting.

calls: [CompileDiagnostic](r2-compiler-infrastructure.md#u-49c3d847da08)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/errors.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/utils/compile_diagnostic.js
