# Dev-mode Diagnostics

**Capability.** Development-only correctness aids: stale-assignment wrappers, source-location tagging on created elements, proxy-aware equality warnings (including patched Array.prototype methods), and runtime validation of bindings and each-block keys.

All of these are no-ops or silent in production builds; use them to explain dev-only warnings. Each file guards one class of likely user mistake.

**Children.**

- [Generated Warning Helpers](r1-client-dev-warnings.md) `r1-client-dev-warnings` · 1 unit(s)

Parent: [Svelte Monorepo](r1-svelte-monorepo.md)

## Units (7)

<a id="u-e1a32c6b07a5"></a>
### `assign.js-assignment-helpers`

`function compare(a, b, property, location)` · [packages/svelte/src/internal/client/dev/assign.js:L12-L18][f1]

Dev-mode wrappers for property assignment that warn when the pre-assignment value was stale.

Each exported helper performs the compound assignment ('=', '&&=', '||=', '??=') on object[property], then compares the produced value with an untrack(() => object[property]) re-read, so the check creates no reactive dependencies. compare returns the assignment result unchanged; when the two values differ (a !== b) it emits assignment_value_stale with the property name and sanitize_location(location). The four helpers differ only in when the operator applies: always, when the current value is truthy, falsy, or null/undefined respectively.

calls: [untrack](r2-reactivity-core.md#u-aa0e067da463), [sanitize_location](r5-compiler-utilities.md#u-eb8e19f29107)

**Uncertainties.**

- How the post-assignment untracked read can differ from the assigned value depends on proxy/reactive-source semantics not supplied here.

<a id="u-a0f5d3698876"></a>
### `elements.js-source-locations`

`export function add_locations(fn, filename, locations)` · [packages/svelte/src/internal/client/dev/elements.js:L13-L22][f2]

Attaches source locations to elements created by compiled templates during development.

add_locations(fn, filename, locations) returns a wrapper that calls fn(...args) to build the DOM, picks the start node — the fragment itself while hydrating, otherwise firstChild when fn produced a document fragment, else the node — delegates to assign_locations, and returns the DOM. assign_location writes a __svelte_meta property holding the current dev_stack as parent and {file, line, column}, and if location[2] exists recurses into element.firstChild with nested locations. assign_locations walks siblings, tracking hydration depth: while hydrating, HYDRATION_START or HYDRATION_START_ELSE comments raise depth and HYDRATION_END comments lower it; only at depth 0 on ELEMENT_NODE nodes does it consume the next location, stopping when nodes or locations run out.

**Notes.**

- side_effect: __svelte_meta is written directly onto DOM elements, exposing source metadata to devtools.

calls: [elements.js-source-locations](r1-client-dev-dx.md#u-a0f5d3698876)

<a id="u-1016bd3303e1"></a>
### `equals`

`export function equals(a, b, equal = true)` · [packages/svelte/src/internal/client/dev/equality.js:L95-L101][f3]

Dev-mode ==/!= comparison that warns when proxy unwrapping would change the result.

Unlike strict_equals there is no try/catch: if (a == b) differs from (get_proxied_value(a) == get_proxied_value(b)) it emits state_proxy_equality_mismatch with '==' or '!=' per the equal flag. Returns (a == b) === equal.

calls: [get_proxied_value](r5-runtime-reactivity.md#u-0468b533d5f3)

<a id="u-3c0065301141"></a>
### `init_array_prototype_warnings`

`export function init_array_prototype_warnings()` · [packages/svelte/src/internal/client/dev/equality.js:L4-L69][f3]

Patches Array.prototype.indexOf, lastIndexOf, and includes to detect likely-failed comparisons against state proxies.

Each patch calls the original method first; only on a miss (-1 or false) does it scan the array comparing get_proxied_value(this[i]) === item, and if a proxied element would have matched, it emits a state_proxy_equality_mismatch warning naming the method, then returns the original result unchanged. lastIndexOf defaults from_index to this.length - 1 when undefined because the native implementation treats a passed undefined differently. To prevent the REPL from stacking duplicate patches, any prior Array.__svelte_cleanup is invoked first, and a new cleanup closure restoring the three originals is installed.

**Notes.**

- side_effect: Mutates Array.prototype globally and stores a restore hook on the Array constructor.

calls: [get_proxied_value](r5-runtime-reactivity.md#u-0468b533d5f3)

<a id="u-28877320e4f3"></a>
### `strict_equals`

`export function strict_equals(a, b, equal = true)` · [packages/svelte/src/internal/client/dev/equality.js:L77-L87][f3]

Dev-mode ===/!== comparison that warns when proxy unwrapping would change the result.

If (a === b) differs from (get_proxied_value(a) === get_proxied_value(b)), it emits state_proxy_equality_mismatch with '===' or '!==' per the equal flag. The property reads are wrapped in try/catch with an empty catch because reading properties of a and b may be disallowed (e.g. secure context); the warning is then skipped. Returns (a === b) === equal.

calls: [get_proxied_value](r5-runtime-reactivity.md#u-0468b533d5f3)

<a id="u-c7a0dea89b16"></a>
### `packages/svelte/src/internal/client/validate.js:validate_binding`

`export function validate_binding(binding, get_object, get_property, line, column)` · [packages/svelte/src/internal/client/validate.js:L48-L83][f4]

Development warning for non-reactive bind targets, evaluated inside a render effect that runs once per change.

A module-scoped warned flag short-circuits repeat warnings. capture_store_binding(get_object) reveals whether the object is a store subscription; store subscriptions are skipped. A nested render effect reads object[property] once; if that effect ends with deps === null the property read created no dependency, so the property is deemed non-reactive and w.binding_property_non_reactive is emitted with a filename:line:column location derived from dev_current_component_function, then warned is set to suppress future output.

calls: [effects.js-effect-creators](r3-effects-engine.md#u-27c9c7c4069f), [capture_store_binding](r2-store-integration.md#u-8388b459c980)

**Uncertainties.**

- The reactivity probe assumes a getter has a corresponding setter effect-dependency behavior; edge cases where a dependency exists despite non-reactivity are acknowledged as extreme in the comment, not proven here.

<a id="u-8e0376d25fe3"></a>
### `validate_each_keys`

`export function validate_each_keys(collection, key_fn)` · [packages/svelte/src/internal/client/validate.js:L14-L39][f4]

Development check for duplicate each-block keys, run inside a render effect so it re-validates when the collection changes.

It evaluates the collection getter, normalising non-array iterables with Array.from and treating null/undefined as empty; for each item it computes the key with key_fn(item, i), and on a duplicate calls e.each_key_duplicate with the earlier index and current index as strings, passing null for the key text when the key stringifies to an '[object ...]' form.

calls: [effects.js-effect-creators](r3-effects-engine.md#u-27c9c7c4069f)

**Uncertainties.**

- Whether e.each_key_duplicate throws or warns is defined in errors.js, not shown.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dev/assign.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dev/elements.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dev/equality.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/validate.js
