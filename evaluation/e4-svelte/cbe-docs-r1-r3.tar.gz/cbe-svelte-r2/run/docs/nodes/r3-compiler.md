# Compiler

**Capability.** Transforms Svelte source into executable code through parsing utilities, a scope-aware analysis phase, accessibility diagnostics, and client/server code generation.

Use this subtree to understand how a component moves from source text to generated JavaScript. Each phase is isolated: parse utilities, the analyzer, scope/node infrastructure, a11y checks, and the client/server transform passes.

**Children.**

- [Parse Utilities](r3-parse-utilities.md) `r3-parse-utilities` · 9 unit(s)
- [Component Analysis](r3-analysis-core.md) `r3-analysis-core` · 17 unit(s)
- [Scope and Node Model](r3-scope-node-model.md) `r3-scope-node-model` · 14 unit(s)
- [Accessibility Checks](r3-a11y-checks.md) `r3-a11y-checks` · 5 unit(s)
- [Code Generation Transforms](r3-code-generation-transform.md) `r3-code-generation-transform` · 0 unit(s)
- [Svelte 4 AST Converter](r3-legacy-ast-compat.md) `r3-legacy-ast-compat` · 2 unit(s)
- [Diagnostic Code Templates](r3-diagnostics-templates.md) `r3-diagnostics-templates` · 5 unit(s)

Parent: [Svelte Monorepo](r3-svelte-monorepo.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
