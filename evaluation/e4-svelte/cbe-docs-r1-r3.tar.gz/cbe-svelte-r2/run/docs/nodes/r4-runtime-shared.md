# Runtime Shared Helpers

**Capability.** Platform-independent runtime utilities used by client and server: HTML attribute serialization (attr, clsx, to_class, to_style), shared runtime warnings, and the module-global mode flags (async/legacy/tracing).

Use this subtree when both render targets need the same helper. to_style is called by client set_style; warnings emit dev messages for shared diagnostics; flags are set one-way by internal modules to switch runtime modes.

**Depended on by.**

- [Element Bindings and Styles](r4-element-bindings.md) · graph-confirmed · 1 edge(s)
- [Server Runtime](r4-server-runtime.md) · model-inferred · 0 edge(s)

Parent: [Runtime](r4-runtime.md)

## Units (16)

<a id="u-83334ed78d84"></a>
### `packages/svelte/src/internal/shared/attributes.js:append_styles`

`function append_styles(styles, important = false)` · [packages/svelte/src/internal/shared/attributes.js:L91-L103][f1]

Joins a style-name/value record into a CSS declaration string.

The separator is ' !important;' when `important` is true, else ';'. Each entry whose value is not null/undefined and not the empty string contributes ` key: value<separator>`; null, undefined, and empty-string values are skipped, so they remove nothing but contribute no declaration.

<a id="u-12a88532ea06"></a>
### `attr`

`export function attr(name, value, is_boolean = false)` · [packages/svelte/src/internal/shared/attributes.js:L24-L29][f1]

Serializes a single attribute into a leading-space HTML string for server-side rendering.

Returns an empty string when the value is null/undefined, or when the value is falsy and `is_boolean` is set (boolean attributes are omitted entirely). Otherwise, if the attribute name appears in the `replacements` table (currently `translate`), the value is mapped through that table (true→'yes', false→'no'); otherwise the value is used as-is. For boolean attributes the output is just ` name`; for others it is ` name="escaped-value"` with the value HTML-escaped via `escape_html` with attribute escaping enabled.

calls: [escape_html](r2-server-render.md#u-0f499dd45547)

<a id="u-2274c46486ff"></a>
### `clsx`

`export function clsx(value)` · [packages/svelte/src/internal/shared/attributes.js:L36-L42][f1]

Normalizes a class attribute value, preserving Svelte's handling of falsy values.

If the value is an object (including arrays, which clsx handles), it delegates to the third-party `clsx` package; otherwise it returns the value, substituting the empty string for null/undefined via `??`. Numbers and strings pass through unchanged, so non-empty falsy values like 0 or '' are returned as-is rather than being collapsed.

uses: [clsx](../../catalog.json)

<a id="u-bb0adfe2b192"></a>
### `to_class`

`export function to_class(value, hash, directives)` · [packages/svelte/src/internal/shared/attributes.js:L52-L84][f1]

Computes the final class attribute content from a base value, a scoped-CSS hash, and CSS class directives, returning null when the result is empty.

The base value is stringified (empty for null/undefined); a truthy hash is appended with a single space if the base is non-empty, else used alone. Directives are then processed in key order: truthy directive values append the class name; falsy directive values remove that name from the accumulated string, matching only whole tokens bounded by whitespace characters (from a list covering space, tabs, newlines, CR, FF, NBSP, VT, and BOM) or string ends, looping over repeated occurrences. Empty final output is reported as null so callers can omit the attribute.

**Notes.**

- side_effect: Pure string manipulation only; no DOM access, so the same result is produced during SSR and client updates.

**Uncertainties.**

- Whether a falsy directive key present only in the removal scan, not in the added classes, could remove a class the user supplied independently — removal is purely string-token based and matches any whole-token occurrence in the accumulated string.

<a id="u-c7b91478cfe6"></a>
### `to_css_name`

`function to_css_name(name)` · [packages/svelte/src/internal/shared/attributes.js:L109-L114][f1]

Lowercases a CSS custom-property name unless it starts with '--' (CSS variables), whose case is preserved; all other names are returned lowercased.

<a id="u-50b25ac26373"></a>
### `to_style`

`export function to_style(value, styles)` · [packages/svelte/src/internal/shared/attributes.js:L121-L219][f1]

Merges an existing inline-style string with style overrides, returning the normalized style text or null when empty.

When `styles` is absent, the value is simply stringified (null becomes null). When `styles` is an array, the first element holds normal overrides and the second holds `!important` overrides; a plain object holds only normal overrides. The existing value is stringified, stripped of /*...*/ comments, and trimmed, then scanned character by character: comments, quoted strings, and parenthesized values are tracked so colons and semicolons inside them are ignored. Each declaration whose property name (lowercased via `to_css_name`) is not among the override keys is re-emitted as ` property;` — so any property present in the overrides is dropped from the incoming value and replaced by the override record. At the end, normal overrides are appended via `append_styles` (non-important), then important overrides with ' !important;' separators; the whole result is trimmed, and empty output is returned as null.

calls: [packages/svelte/src/internal/shared/attributes.js:append_styles](r4-runtime-shared.md#u-83334ed78d84), [to_css_name](r4-runtime-shared.md#u-c7b91478cfe6)

**Uncertainties.**

- The scanner tracks parentheses with a counter (in_apo) but never rejects unterminated quotes or comments; behavior on malformed style text depends on this lenient scan and is not verifiable here.
- Unclosed comment/quote at end of value leaves the scan in that state, so trailing text may be skipped.

<a id="u-e763a0b97a98"></a>
### `attributes.js module code (L1–L23)`

`module_region` · [packages/svelte/src/internal/shared/attributes.js:L1-L23][f1]

Imports escape_html and clsx, and defines the `replacements` table mapping the `translate` attribute's true/false to 'yes'/'no' for boolean-attr serialization quirks.

<a id="u-166c10327168"></a>
### `dynamic_void_element_content`

`export function dynamic_void_element_content(tag)` · [packages/svelte/src/internal/shared/warnings.js:L12-L18][f2]

Warns that a `<svelte:element this="tag">` is void and cannot have content.

In dev, console.warn is called with a styled two-part message (bold/normal font-weight format specifiers) including the tag and docs URL; in production it warns with only the URL string. Never throws; the return value is ignored by callers.

<a id="u-093aec392ae5"></a>
### `state_snapshot_uncloneable`

`export function state_snapshot_uncloneable(properties)` · [packages/svelte/src/internal/shared/warnings.js:L26-L40][f2]

Warns that `$state.snapshot` could not fully clone a value.

In dev it console.warns a styled message whose middle section depends on the argument: a truthy `properties` string yields 'The following properties cannot be cloned...' plus the supplied path list verbatim, while null/undefined yields 'Value cannot be cloned... the original value was returned'. The docs URL is appended in both cases. In production it warns only the URL string, so all path detail is lost in prod builds.

<a id="u-37fb907c4490"></a>
### `warnings.js module code (L1–L11)`

`module_region` · [packages/svelte/src/internal/shared/warnings.js:L1-L11][f2]

Generated-file header, DEV import, and bold/normal style constants; no runtime behavior beyond styling strings.

<a id="u-cec9a7e39cac"></a>
### `warnings.js module code (L18–L25)`

`module_region` · [packages/svelte/src/internal/shared/warnings.js:L18-L25][f2]

Non-behavioral gap between warning functions.

<a id="u-2c7340b211d4"></a>
### `disable_async_mode_flag`

`export function disable_async_mode_flag()` · [packages/svelte/src/internal/flags/index.js:L10-L12][f3]

Resets async_mode_flag to false.

Its comment restricts use to testing; the code enforces no restriction.

<a id="u-8e5eb2967954"></a>
### `enable_async_mode_flag`

`export function enable_async_mode_flag()` · [packages/svelte/src/internal/flags/index.js:L5-L7][f3]

Sets the module-global async_mode_flag to true; no arguments, no return value.

Comment on disable_async_mode_flag marks testing-only usage; no guard prevents double enabling.

<a id="u-0c177e01fbd2"></a>
### `enable_legacy_mode_flag`

`export function enable_legacy_mode_flag()` · [packages/svelte/src/internal/flags/index.js:L14-L16][f3]

Sets the module-global legacy_mode_flag to true, one-way; no corresponding disable function exists in this module.

<a id="u-76b26958c1d1"></a>
### `enable_tracing_mode_flag`

`export function enable_tracing_mode_flag()` · [packages/svelte/src/internal/flags/index.js:L18-L20][f3]

Sets the module-global tracing_mode_flag to true, one-way; no corresponding disable function exists in this module.

<a id="u-0ef56c30b6b2"></a>
### `index.js module code (L1–L4)`

`module_region` · [packages/svelte/src/internal/flags/index.js:L1-L4][f3]

Declares three mutable exported flag variables (async_mode_flag, legacy_mode_flag, tracing_mode_flag), all starting false, mutated by the enable/disable functions in the same module.

State is module-global, so flips affect the whole process.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/shared/attributes.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/shared/warnings.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/flags/index.js
