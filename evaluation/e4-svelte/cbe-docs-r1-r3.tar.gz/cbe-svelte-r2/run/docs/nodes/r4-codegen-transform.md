# Code Generation (Phase 3)

**Capability.** Emits executable output from the annotated AST: client DOM-manipulating JavaScript with templates and events, server payload-rendering code, and rewritten scoped CSS, plus template-node typing shared by the client transform.

Use this subtree for how output code is produced. It splits by output target: client visitors and template building, server visitors and shared serialization utilities, and CSS rewriting.

**Children.**

- [Client Transform](r4-client-transform.md) `r4-client-transform` · 24 unit(s)
- [Server Transform](r4-server-transform.md) `r4-server-transform` · 7 unit(s)
- [CSS Transform](r4-css-transform.md) `r4-css-transform` · 13 unit(s)

Parent: [Compiler Pipeline](r4-compiler.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
