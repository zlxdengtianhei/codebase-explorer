# Reactivity benchmarks

**Capability.** Kairo-style performance benchmarks that exercise the client runtime's derived chains: an intentionally avoidable five-deep chain and a derived that redundantly reads the same signal many times, each timed over repeated runs.

Use these to measure propagation cost of derived graphs against the reactivity core. No static dependency edges to runtime units were resolved in the supplied graph; the exercised runtime behaviour is inferred from the benchmark summaries.

Parent: [Svelte framework](r2-svelte.md)

## Units (2)

<a id="u-a018922f0d70"></a>
### `kairo_avoidable-js`

`function setup()` · [benchmarking/benchmarks/reactivity/kairo/kairo_avoidable.js:L5-L22][f1]

Builds a five-deep derived chain whose recomputation is intentionally avoidable, then times 1000 full re-runs of that chain.

setup() creates state head=0 and deriveds: computed1 reads head; computed2 uses a sequence expression (get(computed1), 0) so its value is constant 0; computed3 calls busy() and yields get(computed2)+1, hence always 1; computed4 and computed5 add 2 and 3, so computed5 is always 6 regardless of head. An effect_root registers a render_effect reading computed5 and calling busy(). run() flushes head=1, asserts computed5===6, then loops 1000 times flushing head=i and re-asserting computed5===6; any assertion failure propagates out of run. kairo_avoidable_unowned does 10 un-timed setup/run/destroy JIT-warmup loops, then awaits fastest_test(10, running run() 1000 times), destroys its own setup, and returns {benchmark, time, gc_time} with timing values formatted via toFixed(2). kairo_avoidable_owned wraps the same warmup plus the retained setup inside one $.effect_root whose handle is destroy_owned; the outer run/destroy pair is assigned into function-scope variables, timed identically, then torn down by destroy() followed by destroy_owned().

calls: [busy](r5-benchmarks.md#u-0d12a4a1de84), [fastest_test](r4-benchmark-harness.md#u-0bbe8c671495); uses: [assert](r4-benchmark-harness.md#u-823bd0dd0cd8)

**Uncertainties.**

- The runtime semantics of $.flush, $.effect_root and $.derived come from svelte/internal/client, which is not in this batch; only call structure is observed.

<a id="u-5b30d5ae9c70"></a>
### `kairo_repeated-js`

`function setup()` · [benchmarking/benchmarks/reactivity/kairo/kairo_repeated.js:L6-L27][f2]

Times a derived that redundantly reads the same state signal size times (module constant size=30).

setup() creates state head and a derived that loops i=0..size-1 accumulating get(head); a render_effect in $.effect_root reads it and increments a counter. run() flushes head=1 and asserts get(current)===size, resets counter, then for i=0..99 flushes head=i and asserts get(current)===i*size, finally asserting counter===100. kairo_repeated_unowned performs 10 un-timed JIT-warmup setup/run/destroy cycles, then awaits fastest_test(10, 1000 run() calls), destroys and returns {benchmark, time, gc_time} with toFixed(2). kairo_repeated_owned runs the warmup and retains one setup inside a single $.effect_root (destroy_owned), assigns the final run/destroy to outer variables, times identically, then tears down with destroy() and destroy_owned().

uses: [assert](r4-benchmark-harness.md#u-823bd0dd0cd8); calls: [fastest_test](r4-benchmark-harness.md#u-0bbe8c671495)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/benchmarking/benchmarks/reactivity/kairo/kairo_avoidable.js
[f2]: ../../../../../../eval/svelte-be645b4/benchmarking/benchmarks/reactivity/kairo/kairo_repeated.js
