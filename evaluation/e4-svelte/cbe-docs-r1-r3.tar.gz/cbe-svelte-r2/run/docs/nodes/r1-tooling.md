# Repo Tooling & Benchmarks

**Capability.** Developer tooling around the library rather than shipped code: lint policy enforcement, bundle treeshakeability verification, reactify benchmarks, SSR sandbox seeding scripts, and package docs.

Use these when changing build/dev workflow; none of it ships to users. Treeshakeability verification depends on the compiler's client output.

**Children.**

- [Lint Configuration](r1-tooling-lint.md) `r1-tooling-lint` · 2 unit(s)
- [Treeshakeability Verification](r1-tooling-treeshake.md) `r1-tooling-treeshake` · 4 unit(s)
- [Reactivity Benchmarks](r1-tooling-benchmarks.md) `r1-tooling-benchmarks` · 2 unit(s)
- [Playground Scripts](r1-tooling-playground.md) `r1-tooling-playground` · 4 unit(s)

Parent: [Svelte Monorepo](r1-svelte-monorepo.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
