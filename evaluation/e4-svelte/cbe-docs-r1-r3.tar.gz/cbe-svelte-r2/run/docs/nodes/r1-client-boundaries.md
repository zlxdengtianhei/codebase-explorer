# Boundaries & Async Blocks

**Capability.** Client-side error and pending boundary: the Boundary class owns one block effect and swaps main/pending/failed child effects, preserves DOM across destruction, rewinds hydration on error, and exposes pending-count tracking plus the `$effect.pending()` accessor.

boundary.js is self-contained: constructor builds the effect, error()/reset() handle failure and recovery, #show_pending_snippet/#update_pending_count handle async waiting, get_pending_boundary walks the chain. It depends on hydration cursor helpers during rewind.

**Depends on.**

- [Client Runtime](r1-client-runtime.md) · graph-confirmed · 5 edge(s)
- [Effect Engine](r3-effects-engine.md) · graph-only · 13 edge(s)

Parent: [Svelte Monorepo](r1-svelte-monorepo.md)

## Units (14)

<a id="u-480575efeafb"></a>
### `Boundary`

`class Boundary` · [packages/svelte/src/internal/client/dom/blocks/boundary.js:L51-L119][f1]

Error and pending boundary that owns one block effect and swaps between main, pending, and failed child effects, preserving its DOM across destruction via EFFECT_PRESERVED.

Instance state includes the doubly linked pending/failed/main effects, an offscreen DocumentFragment holding main content while pending is shown, a pending counter, and an `#is_creating_fallback` guard used by error handling. `#effect_pending` is a lazily created source of the pending count, built by `#effect_pending_subscriber` (createSubscriber) so no Batch churn occurs unless `$effect.pending()` is actually read; in DEV the source is tagged for tracing. `#effect_pending_update` pushes the current count into that source and is registered globally via effect_pending_updates in update_pending_count. has_pending_snippet reports whether a pending snippet prop exists. Field fragments s2, s4, s5, s7, s8 belong to this declaration.

group: [Boundary.constructor](r1-client-boundaries.md#u-078c9b337ba6), [Boundary](r1-client-boundaries.md#u-480575efeafb)

**Uncertainties.**

- Interaction of createSubscriber start/stop timing with read lifetime is defined in create-subscriber.js, not here.

<a id="u-5b0962e99d37"></a>
### `packages/svelte/src/internal/client/dom/blocks/boundary.js:reset`

`const reset = () =>` · [packages/svelte/src/internal/client/dom/blocks/boundary.js:L288-L320][f1]

reset restores the boundary to fresh rendering after an error.

A second call is a no-op warning (svelte_boundary_reset_noop); calling reset from inside its own onerror callback throws svelte_boundary_reset_onerror. It zeroes the pending count, pauses the failed effect, sets pending=true, re-renders children via #run (clearing #is_creating_fallback first), then shows the pending snippet if the count became nonzero again or marks pending=false.

<a id="u-719d2fff701a"></a>
### `boundary`

`export function boundary(node, props, children)` · [packages/svelte/src/internal/client/dom/blocks/boundary.js:L47-L49][f1]

Creates a Boundary instance for the given node, props, and children render function; the constructor performs all work, so this wrapper only exists to expose boundary as a plain function.

calls: [Boundary](r1-client-boundaries.md#u-480575efeafb)

<a id="u-662729eaf177"></a>
### `get_pending_boundary`

`export function get_pending_boundary()` · [packages/svelte/src/internal/client/dom/blocks/boundary.js:L384-L396][f1]

Walks the boundary chain from the active effect's `b` through parent links, returning the nearest boundary whose has_pending_snippet is true; if none exists it throws the await_outside_boundary error and, per the throw, never falls through.

uses: [Boundary](r1-client-boundaries.md#u-480575efeafb)

<a id="u-71a170980fd0"></a>
### `move_effect`

`function move_effect(effect, fragment)` · [packages/svelte/src/internal/client/dom/blocks/boundary.js:L371-L382][f1]

Relocates an effect's rendered DOM range into a fragment by walking siblings from nodes_start until nodes_end (exclusive), appending each node; iteration stops at null, so a missing end sentinel moves to the end of the document scope via get_next_sibling returning null.

<a id="u-8bef95411436"></a>
### `packages/svelte/src/internal/client/dom/blocks/boundary.js:pending`

`export function pending()` · [packages/svelte/src/internal/client/dom/blocks/boundary.js:L398-L410][f1]

Implements `$effect.pending()`: errors via effect_pending_outside_reaction if there is no active effect, returns 0 when the active effect has no boundary (marked TODO as eventually global), otherwise delegates to the boundary's get_effect_pending.

<a id="u-f5286d8f1aba"></a>
### `Boundary.#run`

`#run(fn)` · [packages/svelte/src/internal/client/dom/blocks/boundary.js:L189-L208][f1]

Runs a callback with the boundary's effect as active effect/reaction and the effect's component context, restoring all three afterwards.

On a thrown error it reports via handle_error and returns null instead of propagating, so callers treat null as 'children failed'.

uses: [Boundary](r1-client-boundaries.md#u-480575efeafb)

<a id="u-45c0b37226a1"></a>
### `Boundary.#show_pending_snippet`

`#show_pending_snippet()` · [packages/svelte/src/internal/client/dom/blocks/boundary.js:L210-L221][f1]

Activates the pending snippet: moves the existing main effect's DOM nodes into an offscreen DocumentFragment (if a main effect exists) and creates the pending effect via branch if none exists yet.

Assumes props.pending is present.

calls: [move_effect](r1-client-boundaries.md#u-71a170980fd0)

<a id="u-4e6138a98e40"></a>
### `Boundary.#update_pending_count`

`#update_pending_count(d)` · [packages/svelte/src/internal/client/dom/blocks/boundary.js:L224-L241][f1]

Adjusts the private pending counter by 1 or -1.

When the count reaches zero it clears `pending`, pauses the pending effect (nulling it in the callback), and reinserts the offscreen fragment before the anchor, clearing the reference. Nonzero counts leave current DOM untouched.

uses: [Boundary](r1-client-boundaries.md#u-480575efeafb)

<a id="u-078c9b337ba6"></a>
### `Boundary.constructor`

`constructor(node, props, children)` · [packages/svelte/src/internal/client/dom/blocks/boundary.js:L119-L180][f1]

Builds the boundary's block effect.

During hydration with a pending snippet it branches the pending snippet immediately, then enqueues a batch callback that runs the main children via #run (with Batch.ensure) and either shows the pending snippet (pending_count > 0) or pauses the pending effect and clears `pending`. Without hydration or without a pending snippet it branches children directly inside a try whose catch forwards the error to this.error, then shows pending or sets pending=false based on the count. Sets the active effect's `b` to this boundary, advances hydration past the boundary opener, and after hydration rewires #anchor to hydrate_node. The parent boundary is read from the active effect's `b`.

calls: [Boundary.error](r1-client-boundaries.md#u-6da36536328d)

<a id="u-6da36536328d"></a>
### `Boundary.error`

`error(error)` · [packages/svelte/src/internal/client/dom/blocks/boundary.js:L260-L288][f1]

Entry half of error handling: destroys any existing main, pending, and failed effects (nulling each), and during hydration rewinds to the boundary's opening comment, skips its content with next(), and removes the server-rendered nodes.

Then defines the reset closure (explained in its own unit), and decides whether the error can be handled here: if a fallback is currently being created, or neither onerror nor failed exists, the error is rethrown for an outer boundary.

group: [packages/svelte/src/internal/client/dom/blocks/boundary.js:reset](r1-client-boundaries.md#u-5b0962e99d37)

<a id="u-c564ebef3bcc"></a>
### `packages/svelte/src/internal/client/dom/blocks/boundary.js:Boundary.error`

`error(error)` · [packages/svelte/src/internal/client/dom/blocks/boundary.js:L320-L363][f1]

Continuation of error(): with active_reaction temporarily nulled, invokes props.onerror(error, reset), tracking `calling_on_error` so reset can detect reentrancy; an exception from onerror is passed to invoke_error_boundary with the boundary effect's parent.

Afterwards, if a `failed` snippet exists, it is rendered in a queued microtask through #run with #is_creating_fallback set true during rendering; errors thrown while creating the fallback go to invoke_error_boundary against the parent effect, and the guard is cleared in finally. The closure is split by the compiler into two regions but forms one method.

group: [Boundary.error](r1-client-boundaries.md#u-6da36536328d)

**Uncertainties.**

- The microtask ordering of failed-snippet creation relative to onerror completion is not constrained in this file beyond queue_micro_task.

<a id="u-a0161944a00d"></a>
### `Boundary.get_effect_pending`

`get_effect_pending()` · [packages/svelte/src/internal/client/dom/blocks/boundary.js:L254-L257][f1]

Lazily starts the pending-count subscription and returns the current value of the lazily created pending source via get; must only be called after the subscriber has ensured #effect_pending exists, hence the non-null cast.

<a id="u-48954c5681ed"></a>
### `Boundary.update_pending_count`

`update_pending_count(d)` · [packages/svelte/src/internal/client/dom/blocks/boundary.js:L244-L252][f1]

Public pending-count increment/decrement used by async work inside the boundary.

Boundaries with a pending snippet handle the count themselves; otherwise the parent boundary's private counter is adjusted, so nested boundaries propagate pending state upward. In both cases the effect_pending_update is added to the shared effect_pending_updates set so any `$effect.pending()` source stays in sync.

calls: [Boundary.#update_pending_count](r1-client-boundaries.md#u-4e6138a98e40)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/blocks/boundary.js
