# Element Bindings, Actions, and Custom Elements

**Capability.** Wires elements to the reactive graph: DOM event bindings with untracked handlers, size bindings via a shared ResizeObserver, prop bindings, actions, class application, and Svelte component-as-custom-element support.

Use this subtree for how elements react at runtime. Binding helpers run handlers outside reactive contexts and tear down with their effect; the custom-element machinery wraps components in a SvelteElement class and depends on effects, templates, and legacy adapters.

**Depends on.**

- [DOM Template Factories](r3-dom-template-factories.md) · graph-confirmed · 1 edge(s)
- [Effect Engine](r3-effects-engine.md) · graph-confirmed · 8 edge(s) · Bindings and the custom-element class run their reactive updates inside effects created by the effect engine.
- [Svelte 4 Client Compatibility](r3-legacy-client-runtime.md) · graph-confirmed · 1 edge(s)

**Depended on by.**

- [Effect Engine](r3-effects-engine.md) · graph-confirmed · 1 edge(s)
- [DOM elements, events and bindings](r2-dom-elements.md) · graph-only · 11 edge(s)

Parent: [Client Runtime](r3-runtime.md)

## Units (13)

<a id="u-e8c39de2a586"></a>
### `action`

`export function action(dom, action, get_value)` · [packages/svelte/src/internal/client/dom/elements/actions.js:L13-L43][f1]

Runs a Svelte action on an element inside a root effect, wiring reactive value updates and teardown.

The action call is wrapped in untrack and a falsy return is coerced to {}, so initialization never tracks dependencies. If get_value is supplied and the payload exposes update, a nested render_effect reads the value, deep-reads it (so $state mutations are noticed), and calls payload.update only after the first pass and when safe_not_equal(prev, value) holds; prev starts as {} to guarantee initial inequality. If the payload exposes destroy, the effect's teardown calls it.

**Notes.**

- side_effect: payload.destroy runs when the wrapping effect is destroyed; payload.update runs only on detected value changes after the first render_effect pass.

calls: [effects.js-effect-creators](r3-effects-engine.md#u-27c9c7c4069f), [safe_not_equal](r5-runtime-reactivity.md#u-3775acbc409e), [deep_read_state](r2-reactivity-core.md#u-031649ca68f4), [untrack](r2-reactivity-core.md#u-aa0e067da463)

<a id="u-7e3a8e97cbcd"></a>
### `bind_prop`

`export function bind_prop(props, prop, value)` · [packages/svelte/src/internal/client/dom/elements/bindings/props.js:L13-L22][f2]

Exposes a non-prop exported variable on $$props so consumers can bind to it.

It only acts when the prop has a property descriptor with a setter: it assigns the value to props[prop] and registers a teardown that sets props[prop] to null on destroy. Without a setter, nothing happens.

<a id="u-8f0d8dd6601b"></a>
### `listen`

`export function listen(target, events, handler, call_handler_immediately = true)` · [packages/svelte/src/internal/client/dom/elements/bindings/shared.js:L18-L32][f3]

Registers a handler on an EventTarget for a list of event names, optionally firing it once immediately (default true), and returns removal of all listeners via teardown when the enclosing effect is destroyed.

<a id="u-adb7ad8d3643"></a>
### `listen_to_event_and_reset_event`

`export function listen_to_event_and_reset_event(element, event, handler, on_reset = h…` · [packages/svelte/src/internal/client/dom/elements/bindings/shared.js:L59-L76][f3]

Listens for a binding's DOM event, running the handler outside any reactive context, and arranges for handlers to re-run when the owning form is reset.

It stores a reset callback on the element's __on_r property: if one already exists (checkbox with both group and checked binds), the new callback chains the previous one before invoking on_reset(true); otherwise it becomes on_reset(true). Finally add_form_reset_listener() ensures a global reset dispatcher exists. on_reset defaults to handler, so a form reset re-derives the bound value from default* properties.

calls: [without_reactive_context](r3-element-bindings.md#u-ff3a57d1f4f9), [add_form_reset_listener](r6-client-dom-elements.md#u-3524dfa24535)

**Uncertainties.**

- How __on_r is invoked on form reset is implemented in add_form_reset_listener, outside this file.

<a id="u-ff3a57d1f4f9"></a>
### `without_reactive_context`

`export function without_reactive_context(fn)` · [packages/svelte/src/internal/client/dom/elements/bindings/shared.js:L38-L49][f3]

Runs a function with the active reaction and effect temporarily cleared, so reads inside it are not tracked, then restores both in a finally block and returns fn()'s result.

<a id="u-d29cfe379011"></a>
### `ResizeObserverSingleton`

`class ResizeObserverSingleton` · [packages/svelte/src/internal/client/dom/elements/bindings/size.js:L9-L23][f4]

Shares one native ResizeObserver per box option so each element is observed only once.

observe(element, listener) stores listeners in a per-element Set, starts observation, and returns an unsubscribe function that removes the listener and, when the last listener for an element is gone, deletes the entry and unobserves. #getObserver lazily creates the ResizeObserver whose callback stores each entry in the static entries WeakMap and dispatches it to all listeners registered for the target. Module-level singletons exist for content-box, border-box, and device-pixel-content-box.

group: [ResizeObserverSingleton](r3-element-bindings.md#u-d29cfe379011)

<a id="u-4086fd190663"></a>
### `bind_element_size`

`export function bind_element_size(element, type, set)` · [packages/svelte/src/internal/client/dom/elements/bindings/size.js:L100-L108][f4]

Binds an element's client/offset width or height using the border-box singleton.

Size changes call set(element[type]); an additional effect performs an untracked initial set (so reads inside the update are ignored) and returns the unsubscribe function as its teardown.

uses: [ResizeObserverSingleton](r3-element-bindings.md#u-d29cfe379011)

<a id="u-dd65fd2f8c17"></a>
### `bind_resize_observer`

`export function bind_resize_observer(element, type, set)` · [packages/svelte/src/internal/client/dom/elements/bindings/size.js:L83-L93][f4]

Binds a resize entry property to a setter using the shared ResizeObserverSingleton matching the requested box: contentRect/contentBoxSize use content-box, borderBoxSize uses border-box, anything else uses device-pixel-content-box.

Each observed entry calls set(entry[type]); teardown unsubscribes.

uses: [ResizeObserverSingleton](r3-element-bindings.md#u-d29cfe379011)

<a id="u-085f1a439acb"></a>
### `set_class`

`export function set_class(dom, is_html, value, hash, prev_classes, next_classes)` · [packages/svelte/src/internal/client/dom/elements/class.js:L13-L51][f5]

Sets an element's class from a template value, scoping hash, and class directives, returning next_classes.

During hydration or when the cached __className differs from the value (including the undefined edge case), it computes the final class name via to_class and writes it: removes the class attribute when nullish (empty strings are kept to avoid performance issues), uses className for HTML elements, setAttribute otherwise — but only when not hydrating or the attribute actually differs; then caches the value on __className. Otherwise, when only class directive objects changed between renders, it toggles individual classes whose presence differs from prev_classes (or that are present with no prev_classes).

calls: [to_class](r4-runtime-shared.md#u-bb0adfe2b192)

<a id="u-6858bbbea2fe"></a>
### `custom-element.js-svelte-element-class`

`class extends HTMLElement` · [packages/svelte/src/internal/client/dom/elements/custom-element.js:L17-L44][f6]

Defines the SvelteElement base class (only when HTMLElement is a function) that wraps a Svelte component as a custom element.

It stores the component constructor, slots, and shadow-DOM flag (constructor attaches an open shadow root when requested). addEventListener buffers the listener and, if mounted, subscribes via $on while also delegating to super, so same-named custom events can fire twice; removeEventListener delegates to super and calls the stored unsubscribe when mounted. connectedCallback (async) marks connected, and on first connect waits one microtask so child slot elements can appear, aborting if disconnected or already mounted; it builds slot factory functions creating <slot> elements (named for non-default), converts attributes to props via get_custom_element_value using $$g_p name resolution, ports pre-init programmatic props (removing shadowing properties), mounts the component with createClassComponent targeting shadowRoot or the element with $$host, starts an effect_root whose render_effect reflects props marked reflect back to attributes under the $$r guard (removing attributes for null values), and subscribes buffered listeners. attributeChangedCallback returns while $$r is set, else converts the attribute and $sets the component (guarded if unmounted). disconnectedCallback clears the connected flag and destroys the component, its effect root, and the instance in a microtask, tolerating DOM moves. $$g_p maps an attribute name back to its prop key via the props definitions.

calls: [createClassComponent](r3-legacy-client-runtime.md#u-f1a6026980f8), [get_custom_element_value](r3-element-bindings.md#u-b0718db16728), [get_custom_elements_slots](r3-element-bindings.md#u-2b317b984503), [effect_root](r3-effects-engine.md#u-188599523a26), [append](r3-dom-template-factories.md#u-daaa1d70e416)

**Uncertainties.**

- Iterator .next() calls in connectedCallback could not be resolved by the graph; assumed to be plain for-of iteration over $$s, this.attributes, and object keys.
- Behavior of createClassComponent and effect_root teardown is defined outside this file.

<a id="u-ed4b9fd66ffc"></a>
### `create_custom_element`

`export function create_custom_element( Component, props_definition, slots, exports, u…` · [packages/svelte/src/internal/client/dom/elements/custom-element.js:L283-L291][f6]

Turns a Svelte component into a custom element class extending SvelteElement, wiring constructor (Component, slots, shadow-DOM flag, props definitions) and observedAttributes (lowercased attribute-or-key names).

For each prop definition it defines a prototype accessor: get prefers the component instance value when present, else the stored $$d value; set converts via get_custom_element_value, stores in $$d, and if mounted uses the component's own accessor descriptor when available, else calls $set. Exported properties get read-only getters onto the instance. An optional extend callback can replace the class, and the result is assigned to Component.element before being returned.

calls: [get_custom_element_value](r3-element-bindings.md#u-b0718db16728); inherits: [custom-element.js-svelte-element-class](r3-element-bindings.md#u-6858bbbea2fe)

**Uncertainties.**

- get_descriptor(component, prop)?.get is used as 'setter'; whether components expose getters for all settable props is defined in legacy-client, outside this file.

<a id="u-b0718db16728"></a>
### `get_custom_element_value`

`function get_custom_element_value(prop, value, props_definition, transform)` · [packages/svelte/src/internal/client/dom/elements/custom-element.js:L228-L258][f6]

Converts a value between attribute strings and typed props according to the prop's declared type.

A non-boolean value for a Boolean-typed prop is first coerced to value != null. With no transform or no prop definition the value is returned unchanged. For 'toAttribute': Object/Array become JSON.stringify (null when null), Boolean becomes '' or null, Number passes through (null when null), default returns as-is. For 'toProp': Object/Array become JSON.parse (falsy value returned as-is), Boolean is left already converted, Number applies unary + when non-null, default returns unchanged. JSON.parse of malformed attribute text throws and propagates.

<a id="u-2b317b984503"></a>
### `get_custom_elements_slots`

`function get_custom_elements_slots(element)` · [packages/svelte/src/internal/client/dom/elements/custom-element.js:L263-L270][f6]

Scans an element's child nodes and returns a record marking which slot names already exist; each child contributes node.slot or 'default'.

Used by connectedCallback to detect existing slots.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/elements/actions.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/elements/bindings/props.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/elements/bindings/shared.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/elements/bindings/size.js
[f5]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/elements/class.js
[f6]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/elements/custom-element.js
