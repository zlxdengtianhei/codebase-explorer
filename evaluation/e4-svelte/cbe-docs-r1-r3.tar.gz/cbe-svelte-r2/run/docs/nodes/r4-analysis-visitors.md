# JS and Template Visitors

**Capability.** Per-node-type analysis: rune call placement and purity, legacy `$:` reactive statements, component/snippet structure, svelte:component/self/title/html constraints, and targeted warnings (bidirectional characters, inline class expressions).

Use this subtree when a diagnostic or analysis flag originates from a specific syntax node. visit_component is the shared entry for component, svelte:component, and svelte:self (both delegate to it); CallExpression carries rune validation with its placement predicates.

**Depends on.**

- [Compiler Utilities and AST Helpers](r5-compiler-utilities.md) · graph-only · 13 edge(s)

Parent: [Semantic Analysis \(Phase 2\)](r4-compile-analysis.md)

## Units (17)

<a id="u-d254c72e4204"></a>
### `CallExpression`

`export function CallExpression(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/CallExpression.js:L16-L266][f1]

Analyzes call expressions, validating rune usage placement and argument counts per rune, tracking analysis flags, and recording call/state purity metadata.

**Notes.**

- failure: All non-$inspect runes reject SpreadElement arguments; each case enforces its own placement and arity: $bindable only in $props destructuring defaults, $host with no args and only in instance custom elements, $props once and only at instance declarator root, $props.id once at instance VariableDeclaration, $state/$derived families only in variable declarations, class property definitions, or constructor-root this-assignments, $effect families only as expression statements, $inspect().with/$inspect.trace arity and placement (trace only as first statement of a non-generator function body), $state.snapshot exactly one arg.
- side_effect: Unknown callees, $bindable, and $effect set analysis.needs_context; $props sets has_props_rune; $props.id stores analysis.props_id; $effect.pending marks the current expression as stateful; in dev, $inspect.trace stores a tracing thunk on the scope (argument or a label from get_function_label plus location) and sets analysis.tracing.
- condition: Recursion differs: $derived traverses with a fresh expression metadata and incremented function depth (recording async_deriveds if the expression has await), $inspect also increments depth, everything else uses context.next(); afterwards a non-pure callee or non-empty dependency set marks the enclosing expression's has_call/has_state.

calls: [get_rune](r3-scope-node-model.md#u-5204b6ce4f7a), [is_pure](r1-compiler-analyze-shared-utils.md#u-c8c562a3fb44)

**Uncertainties.**

- The is_pure check includes dependencies outside the call itself, acknowledged in a source comment as producing false positives.

<a id="u-3ee893476e43"></a>
### `get_function_label`

`function get_function_label(nodes)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/CallExpression.js:L271-L294][f1]

Derives a human-readable label for a function from its name, its call-site callee source, its property key, or its variable declarator id, for dev tracing output.

**Notes.**

- condition: Returns fn.id.name for named declarations/expressions, 'callee(...)' for call-expression parents, property key names for non-computed properties, and declarator ids; returns undefined if none apply.

<a id="u-827e3436e5f6"></a>
### `is_class_property_assignment_at_constructor_root`

`function is_class_property_assignment_at_constructor_root(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/CallExpression.js:L315-L331][f1]

Returns true when the node is a this.x = ...

assignment at the top level of a constructor body, another accepted placement for state runes.

**Notes.**

- condition: Accepts only '=' assignments to this.<identifier>, this.<private>, or this.<literal>, where the MethodDefinition five levels up is a constructor.

calls: [get_parent](r5-compiler-utilities.md#u-427249cf438e)

<a id="u-8c7c8294d17e"></a>
### `is_class_property_definition`

`function is_class_property_definition(parent)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/CallExpression.js:L307-L309][f1]

Returns true when the parent is a non-static, non-computed PropertyDefinition, accepting state runes as class field initializers.

<a id="u-83f04c95344f"></a>
### `is_variable_declaration`

`function is_variable_declaration(parent, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/CallExpression.js:L300-L302][f1]

Returns true only when the parent is a VariableDeclarator whose enclosing declaration is not a {@const} tag, used to validate state rune placement.

calls: [get_parent](r5-compiler-utilities.md#u-427249cf438e)

<a id="u-a8a29531c5a9"></a>
### `packages/svelte/src/compiler/phases/2-analyze/visitors/HtmlTag.js:HtmlTag`

`export function HtmlTag(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/HtmlTag.js:L10-L19][f2]

Handles `{@html ...}` tags: in runes mode the opening tag is validated (with '@' prefix); the subtree is always marked dynamic because raw HTML may fix invalid markup; then the walk continues with state.expression set to the tag's metadata expression.

calls: [validate_opening_tag](r1-compiler-analyze-shared-utils.md#u-8a95b3b7e6dc)

<a id="u-a9fa7ba9eca6"></a>
### `packages/svelte/src/compiler/phases/2-analyze/visitors/ImportDeclaration.js:ImportDeclaration`

`export function ImportDeclaration(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/ImportDeclaration.js:L9-L31][f3]

Analyzes import declarations under runes mode only.

Any source starting with 'svelte/internal' raises import_svelte_internal_forbidden; importing 'beforeUpdate' or 'afterUpdate' from 'svelte' raises runes_mode_invalid_import for that specifier. Non-runes imports are untouched; no traversal occurs.

**Notes.**

- condition: The svelte/internal check uses startsWith, so deep paths like svelte/internal/client are also rejected.

<a id="u-a9f55b312aed"></a>
### `packages/svelte/src/compiler/phases/2-analyze/visitors/LabeledStatement.js:LabeledStatement`

`export function LabeledStatement(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/LabeledStatement.js:L12-L95][f4]

Analyzes labeled statements, implementing `$:` legacy reactive statements.

A `$` label is a reactive statement only in instance scope directly inside Program; in runes mode that placement raises legacy_reactive_statement_invalid. For real reactive statements it traverses with a fresh ReactiveStatement (raising function_depth by 1), then derives dependencies: every referenced binding is added unless its reference is the left side of a plain `=` assignment (walking down MemberExpression chains to find that). The statement is registered in analysis.reactive_statements. If the body is a sole assignment, the assigned bindings of kind legacy_reactive get their legacy_dependencies set to the dependency list; for MemberExpression targets only the root object identifier is considered. A `$` label in an invalid non-runes placement warns reactive_declaration_invalid_placement. The unconditional trailing context.next() means a visited reactive body is traversed twice — once with reactive_statement state, once normally.

**Uncertainties.**

- The double traversal (context.next inside the branch plus the final one) is visible in the code; its correctness relies on idempotence of visitors, which is not proven here.
- Whether `$: double = x * 2` populates legacy_dependencies on `double` depends on binding kind being legacy_reactive at that point, as the TODO notes.

<a id="u-6cad4b795a74"></a>
### `Literal`

`export function Literal(node)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/Literal.js:L8-L14][f5]

Warns when a string literal contains bidirectional control characters: only string values are tested against regex_bidirectional_control_characters, and a match emits w.bidirectional_control_characters.

<a id="u-61f80c72baef"></a>
### `NewExpression`

`export function NewExpression(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/NewExpression.js:L9-L17][f6]

Warns against instantiating a class expression inline: when the callee is a ClassExpression inside any function (function_depth > 0), w.perf_avoid_inline_class is emitted.

Unconditionally sets analysis.needs_context to true before continuing the walk.

**Notes.**

- side_effect: Always sets context.state.analysis.needs_context = true.

<a id="u-5ba7dfee6f56"></a>
### `RenderTag`

`export function RenderTag(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/RenderTag.js:L14-L68][f7]

Analyzes {@render} tags.

Validates the opening tag, snapshots the template path into metadata, and unwraps optional chaining to find the callee. metadata.dynamic is true whenever the callee identifier's binding is absent or not kind 'normal'; the render tag is linked to every snippet unless it resolves unambiguously (is_resolved_snippet), in which case only the directly bound SnippetBlock is recorded. Registers the tag in analysis.snippet_renderers and sets analysis.uses_render_tags. Spread arguments in the raw call raise render_tag_invalid_spread_argument; calling .bind/.apply/.call on the snippet raises render_tag_invalid_call_expression. Marks the subtree dynamic, then visits the callee and each argument with fresh per-argument expression metadata pushed into metadata.arguments.

calls: [is_resolved_snippet](r6-compiler-analyze.md#u-5fc246db911c), [mark_subtree_dynamic](r6-compiler-analyze.md#u-3e6e9a44c2b4), [create_expression_metadata](r3-scope-node-model.md#u-32bbb434f744), [unwrap_optional](r5-compiler-utilities.md#u-aa95700b7c80)

<a id="u-92b20617b51f"></a>
### `packages/svelte/src/compiler/phases/2-analyze/visitors/SvelteComponent.js:SvelteComponent`

`export function SvelteComponent(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/SvelteComponent.js:L10-L18][f8]

Analyzes `<svelte:component>`: in runes mode emits w.svelte_component_deprecated, visits the `this` expression, then delegates to shared component analysis.

Non-runes mode only walks.

calls: [visit_component](r4-analysis-visitors.md#u-3bbf2fbef9a0)

<a id="u-44e387d55632"></a>
### `packages/svelte/src/compiler/phases/2-analyze/visitors/SvelteSelf.js:SvelteSelf`

`export function SvelteSelf(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/SvelteSelf.js:L12-L36][f9]

Analyzes <svelte:self>: valid only when the path contains an IfBlock, EachBlock, Component, or SnippetBlock ancestor, else svelte_self_invalid_placement.

In runes mode warns svelte_self_deprecated, deriving display name and basename from the module filename, falling back to 'Self'/'Self.svelte' when the filename is unknown. Then delegates entirely to visit_component for the rest of analysis.

calls: [visit_component](r4-analysis-visitors.md#u-3bbf2fbef9a0)

**Uncertainties.**

- filename/UNKNOWN_FILENAME come from imported module state; their exact values at analysis time are not visible here.

<a id="u-573785eeaa9d"></a>
### `TitleElement`

`export function TitleElement(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/TitleElement.js:L9-L21][f10]

Validates `<svelte:title>`: every attribute raises e.title_illegal_attribute, and any fragment child that is neither Text nor an ExpressionTag raises e.title_invalid_content; then the walk continues.

<a id="u-4c3d6ff897e3"></a>
### `UpdateExpression`

`export function UpdateExpression(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/UpdateExpression.js:L10-L29][f11]

Analyzes ++/-- expressions: validates the mutated argument via validate_assignment.

Within a reactive statement, if the argument is a plain identifier (for MemberExpression, only when object() yields an identifier — unlike AssignmentExpression, no identifiers are extracted from patterns), its binding is added to reactive_statement.assignments. Sets expression.has_assignment when in an expression context, then continues traversal.

calls: [validate_assignment](r1-compiler-analyze-shared-utils.md#u-83497fe81c11)

<a id="u-67ff43322877"></a>
### `disallow_unparenthesized_sequences`

`function disallow_unparenthesized_sequences(expression, source)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/shared/component.js:L168-L177][f12]

Throws if a SequenceExpression appears as an attribute or attach-tag value without enclosing parentheses.

It scans the source backwards from the expression's start: finding '(' first means the sequence was parenthesized and is accepted; finding '{' first means the sequence starts the attribute value, so attribute_invalid_sequence_expression is thrown. Characters other than '(' or '{' are skipped. Non-SequenceExpression inputs are ignored.

**Uncertainties.**

- Correctness depends on expression.start being the position just inside any parenthesis; off-by-one behavior of estree start positions is assumed.

<a id="u-3bbf2fbef9a0"></a>
### `visit_component`

`export function visit_component(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/shared/component.js:L19-L162][f12]

Analyzes a component, svelte:component, or svelte:self element: it records metadata, resolves which local snippets the component may render (for CSS pruning), validates attributes, and visits children split by slot name.

It snapshots the path, creates an empty metadata.snippets set, and starts with resolved=true. Attribute scan: a SpreadAttribute or BindDirective marks the component unresolved; expression attributes whose value is an Identifier consult the binding via is_resolved_snippet (adding a SnippetBlock initial to metadata.snippets); a non-Literal, non-Identifier expression marks it unresolved. If resolved, direct SnippetBlock children are also added. The result is stored in analysis.snippet_renderers and the enclosing path is marked dynamic. A second attribute pass throws component_invalid_directive for types outside the allowed set (Attribute, Spread, Let, On, Bind, AttachTag), rejects On modifiers other than a single 'once', and in runes mode validates the attribute and rejects unparenthesized sequence expressions (for Attribute values and AttachTag expressions); validate_attribute_name always runs, and a slot attribute goes through validate_slot_attribute with is_component=true. Non-'this' BindDirectives set analysis.uses_component_bindings. Children are partitioned: comments accumulate and are prepended to the next named slot's node list (cleared after a named slot), with determine_slot deciding each child's slot (defaulting to 'default'). Each slot's nodes are then visited with a per-slot state using that slot's scope, null parent_element, and a shared component_slots set; if the component has a slot attribute, let: directives use the original state instead of the default-slot scope.

calls: [is_resolved_snippet](r6-compiler-analyze.md#u-5fc246db911c), [is_expression_attribute](r5-compiler-utilities.md#u-f63f079d6472), [get_attribute_expression](r5-compiler-utilities.md#u-96e6f6d66786), [determine_slot](r2-compiler-infrastructure.md#u-ead26eb5b43f), [mark_subtree_dynamic](r6-compiler-analyze.md#u-3e6e9a44c2b4), [validate_attribute](r5-analyze-phase.md#u-001c69caf1f6), [validate_attribute_name](r5-analyze-phase.md#u-c4e14f91c1c8), [validate_slot_attribute](r5-analyze-phase.md#u-be5b4cd34d6a), [disallow_unparenthesized_sequences](r4-analysis-visitors.md#u-67ff43322877)

**Uncertainties.**

- The exact semantics of metadata.scopes (populated elsewhere) and how determine_slot classifies children rely on code outside this file.
- Behavior of context.visit and the analysis state's later mutation of snippet_renderers (e.g. fallback to all snippets when unresolved) is only described by comments here.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/CallExpression.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/HtmlTag.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/ImportDeclaration.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/LabeledStatement.js
[f5]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/Literal.js
[f6]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/NewExpression.js
[f7]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/RenderTag.js
[f8]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/SvelteComponent.js
[f9]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/SvelteSelf.js
[f10]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/TitleElement.js
[f11]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/UpdateExpression.js
[f12]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/shared/component.js
