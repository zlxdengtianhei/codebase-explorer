# Component Analysis

**Capability.** Walks a parsed component to produce ComponentAnalysis: scope-driven visitor dispatch over template and script nodes, svelte-ignore collection, runes-mode decisions, prop/export classification, reactive-statement ordering, and per-node validation.

Use this subtree to see what the analyzer guarantees before transformation. The analyze_component group is the entry point; individual visitors handle specific node types, and module-level analysis shares the same scope machinery.

**Depends on.**

- [Accessibility Checks](r3-a11y-checks.md) · graph-confirmed · 1 edge(s)
- [Scope and Node Model](r3-scope-node-model.md) · graph-confirmed · 16 edge(s) · Component analysis dispatches over scopes and bindings created by the scope/node model, which also feeds a11y checks and both transform passes.
- [Compiler Utilities and AST Helpers](r5-compiler-utilities.md) · graph-only · 11 edge(s)

Parent: [Compiler](r3-compiler.md)

## Units (17)

<a id="u-ff1515d9bcd2"></a>
### `index-js-analyze-component`

`export function analyze_component(root, source, options)` · [packages/svelte/src/compiler/phases/2-analyze/index.js:L321-L623][f1]

Full analysis of a Svelte component root into a ComponentAnalysis, spanning scope creation, legacy store-subscription handling, runes-mode decision, visitor walks, prop/export classification, and final template/CSS fixups.

**Notes.**

- condition: Store-subscription path activates when options.runes is false, the name is not a rune, or the declaration qualifies as a store (null rune init, or a non-'props' $props rune name, excepting a svelte/store-derived import named alongside '$derived').
- failure: Within the store path: nested-scope ownership errors store_invalid_scoped_subscription; in runes mode an undeclared all-lowercase store errors global_reference_invalid; a declared rune-named binding called directly warns store_rune_conflict; references lexically inside the module script error store_invalid_subscription.
- side_effect: state.adjust mutates global compiler state; deferred callbacks promote reassigned 'let' bindings to 'state' but only run when not in runes mode.
- condition: runes defaults to options.runes ?? (has_await || instance.has_await || any rune reference in module scope); maybe_runes enables runic behavior for legacy components without $$props/$$restProps references or export let, unless runes explicitly disabled.
- failure: Runes mode errors legacy_props_invalid/legacy_rest_props_invalid for $$props/$$restProps in module scope; warns non_reactive_update for reassigned normal bindings referenced in the template, except bind:this under non-IfBlock/EachBlock/AwaitBlock/KeyBlock paths which is skipped.
- failure: Legacy mode declares synthetic $$props/$$restProps as rest_props, warns export_let_unused for unreferenced props, and orders reactive statements; unexported locals in module script error snippet_invalid_export or export_undefined.
- condition: Mixing on: directives with event attributes errors mixed_event_handler_syntaxes; render tags alongside slots/$$slot error slot_snippet_conflict.
- side_effect: For each element, an empty class attribute is appended when not spread-present but scoped or class-directive exists, and an empty style attribute when a style directive exists without a style attribute or spread.

calls: [js](r3-analysis-core.md#u-1d167d10f6f2), [scope.js-create-scopes-visitor](r3-scope-node-model.md#u-cbb081ea695c), [get_component_name](r3-analysis-core.md#u-b77f317897f5), [index-js-order-reactive-statements](r3-analysis-core.md#u-ab70ae446bea), [analyze_css](r4-css-analysis.md#u-f762711e5ae7), [prune](r2-css-prune.md#u-41775043a205), [warn_unused](r6-compiler-analyze-css.md#u-6a7a7b443898), [create_attribute](r3-scope-node-model.md#u-16d11cbbd59b), [is_custom_element_node](r3-scope-node-model.md#u-ea1f0b51e1e8), [mark_subtree_dynamic](r6-compiler-analyze.md#u-3e6e9a44c2b4), [extract_svelte_ignore](r6-compiler-infra.md#u-4a9ee4fb9b67)

**Uncertainties.**

- accessors derivation (custom element, options.accessors only in legacy, or componentApi === 4) and css hash generation via options.cssHash are observed but their callees' behavior is external.
- The exact topological guarantees of order_reactive_statements are covered in its own unit, not re-derived here.

<a id="u-ab70ae446bea"></a>
### `index-js-order-reactive-statements`

`function order_reactive_statements(unsorted_reactive_declarations)` · [packages/svelte/src/compiler/phases/2-analyze/index.js:L918-L961][f1]

Topologically orders legacy reactive statements by dependency, erroring on dependency cycles.

Builds a lookup from assigned binding names to statements, collects edges from each statement's assignments to its non-assigned dependencies, and passes them to check_graph_for_cycles; a non-empty cycle raises reactive_declaration_cycle with the joined cycle names. It then emits an insertion-ordered Map by recursively adding dependencies' statements first via add_declaration, which skips already-added declarations and ignores dependencies the statement itself assigns.

**Notes.**

- failure: A cycle is reported referencing lookup[cycle[0]][0]; if cycle[0] had no lookup entry this would throw, though cycle names originate from assignments so an entry should exist.
- condition: Self-dependencies assigned within the same statement are excluded from edges and from recursion via assignments.has(binding).

calls: [check_graph_for_cycles](r1-compiler-analyze.md#u-9450956ffc9b)

**Uncertainties.**

- Recursion in add_declaration relies on the inclusion check to terminate; whether it also guards mutual recursion beyond that is not verified from this source alone.

<a id="u-92d8ef78fb8c"></a>
### `analyze_module`

`export function analyze_module(source, options)` · [packages/svelte/src/compiler/phases/2-analyze/index.js:L249-L313][f1]

Analyzes standalone module source into a module Analysis.

Parses the source collecting comments, creates scopes under a fresh ScopeRoot, then validates each '$'-prefixed module-scope reference: bare '$' or '$$'-prefixed names outside RESERVED raise global_reference_invalid; a '$name' whose store binding exists and is not a rune raises store_invalid_subscription_module. The returned Analysis hard-codes runes/immutable true, accessors false. After state.adjust (dev, rootDir, runes), it walks the AST with the shared visitor table, supplying placeholder component-only state fields to satisfy types.

calls: [packages/svelte/src/compiler/phases/1-parse/acorn.js:parse](r4-template-parsing.md#u-2464d5720df7), [scope.js-create-scopes-visitor](r3-scope-node-model.md#u-cbb081ea695c); uses: [function::is_rune::7796](../../catalog.json)

**Uncertainties.**

- Per-node analysis effects during walk come from the imported visitor modules, not visible here.

<a id="u-b77f317897f5"></a>
### `get_component_name`

`function get_component_name(filename)` · [packages/svelte/src/compiler/phases/2-analyze/index.js:L231-L240][f1]

Derives a component class name from a filename: splits on / or \, strips '.svelte' from the basename, substitutes the parent directory name when the base is 'index' (unless the directory is 'src'), and upper-cases the first character.

**Uncertainties.**

- Non-null casts on basename/last_dir assume a well-formed path; degenerate inputs are unguarded here.

<a id="u-1d167d10f6f2"></a>
### `js`

`function js(script, root, allow_reactive_declarations, parent)` · [packages/svelte/src/compiler/phases/2-analyze/index.js:L208-L226][f1]

Builds the Js record for a component's module or instance script.

Uses the script's parsed Program, or synthesizes an empty module Program with start/end -1 when the script is absent, then runs create_scopes with the given allow_reactive_declarations flag and parent scope, returning ast, scope, scopes and has_await.

calls: [scope.js-create-scopes-visitor](r3-scope-node-model.md#u-cbb081ea695c)

<a id="u-622534e4d55e"></a>
### `packages/svelte/src/compiler/phases/2-analyze/index.js:_`

`const visitors = { _(node, { state, next, path })` · [packages/svelte/src/compiler/phases/2-analyze/index.js:L86-L139][f1]

Collects svelte-ignore directives that apply to each visited node before descending, snapshotting them per node.

If the parent is a template Fragment and the node is not Comment/Text, it scans backwards through preceding siblings, extracting ignores from Comments (offset past '<!--') and stopping at the first non-Text sibling; otherwise it reads the node's estree leadingComments (offset past '//'). Collected ignores are pushed via push_ignore, the current ignore_stack is structuredClone-captured into ignore_map for the node, next() runs with the node's own scope swapped in when it differs from the ambient scope, and pop_ignore restores the stack.

calls: [extract_svelte_ignore](r6-compiler-infra.md#u-4a9ee4fb9b67), [state.js-module-level-compiler-state](r2-compiler-infrastructure.md#u-d73d7b033038)

**Uncertainties.**

- push_ignore/pop_ignore and ignore_stack/ignore_map semantics are defined in state.js and only observed here as calls.

<a id="u-7f848a6e0a10"></a>
### `handle`

`function handle(node, key, value)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/ClassBody.js:L49-L76][f2]

Registers a state-creating class field from a property definition or constructor assignment.

get_name(key) returning null aborts. If the value's rune is a state-creation rune: a duplicate name raises state_field_duplicate; the deconflicted key ('@' prefix for static PropertyDefinitions, plain name otherwise) is looked up in fields, and an existing entry that is not exactly a lone 'prop' raises duplicate_class_field. The field is then stored in state_fields with its rune as type, the private key when the key is a PrivateIdentifier, and the value cast to a CallExpression.

**Uncertainties.**

- Behavior when value is not a call expression but get_rune still matches is not validated here (the cast is unchecked).

<a id="u-2a9d6ef13421"></a>
### `packages/svelte/src/compiler/phases/2-analyze/visitors/ClassBody.js:ClassBody`

`export function ClassBody(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/ClassBody.js:L15-L49][f2]

Rune-mode-only wrapper: in non-runes mode it just continues traversal; otherwise it collects private member names, registers a per-class StateField map on analysis.classes, validates fields/methods/constructor assignments via the nested handle and body loops, deconflicts generated private ids, and finally continues with state_fields in state.

Member loops are explained in the sibling unit; this unit owns the early return, private_ids collection, state_fields/fields map setup, and the post-loop deconfliction that replaces invalid identifier characters with '_' and prefixes '_' while colliding with existing private ids, assigning each public state field a generated private key.

**Uncertainties.**

- The exact downstream consumers of analysis.classes and state_fields are outside this file.

<a id="u-92c9182bb2c0"></a>
### `packages/svelte/src/compiler/phases/2-analyze/visitors/ClassBody.js:ClassBody (2)`

`export function ClassBody(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/ClassBody.js:L76-L156][f2]

The class-body scan loops of ClassBody: the member loop records duplicate-class-field conflicts per (static-qualified) name — non-computed instance PropertyDefinitions register 'prop'/'assigned_prop' and error on any repeat; MethodDefinitions register their kind, allowing exactly one getter plus one setter combination but erroring on repeats, props, or assigned props colliding with methods.

The constructor loop then revisits ExpressionStatement assignments of form this.x = ... (or this['x'], non-computed literal only) calling handle so $state runes in constructor assignments register state fields. Computed keys on methods are skipped entirely.

**Uncertainties.**

- handle may still raise state_field_duplicate if the same name is assigned $state twice in the constructor.

<a id="u-9e857900ba69"></a>
### `packages/svelte/src/compiler/phases/2-analyze/visitors/ExportNamedDeclaration.js:ExportNamedDeclaration`

`export function ExportNamedDeclaration(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/ExportNamedDeclaration.js:L10-L70][f3]

Analyzes named exports.

Visits children first so bindings exist, then errors module_illegal_default_export if any specifier exports the name 'default' (comparing identifier name or literal value) whenever ast_type is set. For variable declarations: runes-mode instance `export let` raises legacy_export_invalid; each declared binding that is 'derived' raises derived_invalid_export, and a reassigned state/raw_state binding raises state_invalid_export. In runes mode, instance-level exported functions/classes and const declarators are appended to analysis.exports with alias null.

calls: [extract_identifiers](r5-compiler-utilities.md#u-90eb95affc00)

**Uncertainties.**

- Order of error precedence: default-export and let-export checks run before per-binding kind checks.

<a id="u-548da3ff718c"></a>
### `ExpressionTag`

`export function ExpressionTag(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/ExpressionTag.js:L11-L26][f4]

Analyzes template expression tags.

When directly inside a Fragment (i.e., in a template) with a parent_element in state, checks html content-model validity of '#text' against that parent and raises node_invalid_placement on a message. Always marks the subtree dynamic (needed even for literal-only tags like {42}), then continues with the tag's own expression metadata in state.

calls: [mark_subtree_dynamic](r6-compiler-analyze.md#u-3e6e9a44c2b4), [is_tag_valid_with_parent](r2-compiler-infrastructure.md#u-a93dfa56dc6d)

<a id="u-9bef204c5de7"></a>
### `packages/svelte/src/compiler/phases/2-analyze/visitors/IfBlock.js:IfBlock`

`export function IfBlock(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/IfBlock.js:L10-L27][f5]

Analyzes {#if}/{:else if} blocks: requires non-empty consequent and alternate, validates the opening tag in runes mode using '#' for if and ':' for else-if, marks the subtree dynamic, then visits the test with the block's expression metadata followed by consequent and any alternate.

calls: [validate_block_not_empty](r1-compiler-analyze-shared-utils.md#u-b877c3a87dc5), [mark_subtree_dynamic](r6-compiler-analyze.md#u-3e6e9a44c2b4)

<a id="u-fd5ac76065e4"></a>
### `packages/svelte/src/compiler/phases/2-analyze/visitors/PropertyDefinition.js:PropertyDefinition`

`export function PropertyDefinition(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/PropertyDefinition.js:L10-L21][f6]

Rejects illegal reassignment of `$state`/`$derived` fields in class bodies.

The property key's name is resolved via get_name and looked up in state_fields; when a matching state field exists, this node is a different node than the field's declaration, and the node has an initializer, an error is thrown if this node starts before the field's declaration (e.state_field_invalid_assignment), i.e. assigning to a state field earlier in the class. Later-positioned definitions and non-matching names pass through; context.next() continues.

calls: [get_name](r3-scope-node-model.md#u-99af92983a86)

<a id="u-35398f6374ab"></a>
### `SnippetBlock`

`export function SnippetBlock(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/SnippetBlock.js:L11-L75][f7]

Registers a snippet block, validates its body/tags/parameters, decides hoistability, and detects prop shadowing and children-snippet conflicts.

**Notes.**

- failure: Rest parameters in snippet parameters error; a snippet whose name matches an Attribute/BindDirective on its parent Component errors as shadowing a prop; a 'children' snippet on a Component/SvelteComponent/SvelteSelf whose content includes anything besides snippet blocks, whitespace text, or comments errors as a conflict.
- side_effect: Hoistable top-level snippets have their binding copied into the module scope declarations and node.metadata.can_hoist set; traversal continues with parent_element cleared.

calls: [can_hoist_snippet](r3-analysis-core.md#u-4e8662011f13), [validate_opening_tag](r1-compiler-analyze-shared-utils.md#u-8a95b3b7e6dc), [validate_block_not_empty](r1-compiler-analyze-shared-utils.md#u-b877c3a87dc5)

<a id="u-4e8662011f13"></a>
### `can_hoist_snippet`

`function can_hoist_snippet(scope, scopes, visited = new Set())` · [packages/svelte/src/compiler/phases/2-analyze/visitors/SnippetBlock.js:L81-L108][f7]

Recursively checks whether a snippet's scope can be hoisted: all referenced bindings must be module-level or declared within the snippet itself, including transitively referenced snippets.

**Notes.**

- condition: Bindings at function_depth 0 and bindings declared at or below the snippet's own depth are ignored; a referenced SnippetBlock binding is checked recursively via its scope with a visited set to avoid cycles; any other outer binding returns false.

<a id="u-e568340fb504"></a>
### `packages/svelte/src/compiler/phases/2-analyze/visitors/SvelteElement.js:SvelteElement`

`export function SvelteElement(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/SvelteElement.js:L13-L78][f8]

Analyzes <svelte:element>: runs shared element validation and a11y checks, records the template path in metadata, and registers the element in analysis.elements.

Namespace resolution: an explicit static xmlns attribute sets metadata.svg/mathml by comparing to the SVG/MathML namespace constants; otherwise it scans ancestors — crossing a component/snippet/svelte-fragment boundary or reaching the root resets to the compile options namespace, while a nearest RegularElement/SvelteElement ancestor inherits its namespaces, with foreignObject forcing both to false. Then marks the subtree dynamic, visits the dynamic tag expression, all attributes, and the fragment with parent_element cleared so children validate against no element parent.

calls: [index.js-check-element](r3-a11y-checks.md#u-7ec766147486), [validate_element](r1-compiler-analyze-visitors.md#u-7d4fa5b13c15), [mark_subtree_dynamic](r6-compiler-analyze.md#u-3e6e9a44c2b4)

**Uncertainties.**

- If no matching ancestor is found in the while loop (no break), metadata.svg/mathml stay undefined — this depends on whether path always contains a terminating node type.

<a id="u-8e1ff75e5298"></a>
### `VariableDeclarator`

`export function VariableDeclarator(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/visitors/VariableDeclarator.js:L16-L135][f9]

Analyzes variable declarators, doing most rune binding classification.

First rejects module-scope import conflicts. In runes mode, extracts declaration paths and validates every declared identifier's name; if the initializer is $state/$state.raw/$derived/$derived.by/$props, every path's binding kind is set to 'state', 'raw_state', 'derived', or (for $props) 'rest_prop' for rest paths else 'prop'. For $props: the id must be an ObjectPattern or Identifier (props_invalid_identifier); in custom elements without explicit props options, warns custom_element_props_identifier on a whole identifier or the first RestElement; sets analysis.needs_props. An Identifier id becomes a rest_prop with initial cleared; ObjectPattern properties must be non-computed, non-$$-prefixed, with identifier values (after unwrapping defaults), each getting prop_alias from the key; a $bindable() default is stripped, its argument becomes the binding's initial, and the kind becomes bindable_prop, otherwise the default/right value becomes initial. In non-runes mode, calling $state/$derived/$props (unless shadowed by a store_sub binding) raises rune_invalid_usage. Always continues traversal.

**Notes.**

- failure: equal(node.id.type, 'ObjectPattern') is an assertion guard for the non-Identifier branch.

calls: [get_rune](r3-scope-node-model.md#u-5204b6ce4f7a), [extract_paths](r5-compiler-utilities.md#u-34f2fcb20c62), [equal](r5-compiler-utilities.md#u-2a153dd9dab6)

**Uncertainties.**

- Whether validate_identifier_name on destructured paths and the later binding.kind writes assume bindings already exist in scope (created earlier) — a missing binding would fail the non-null casts.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/index.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/ClassBody.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/ExportNamedDeclaration.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/ExpressionTag.js
[f5]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/IfBlock.js
[f6]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/PropertyDefinition.js
[f7]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/SnippetBlock.js
[f8]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/SvelteElement.js
[f9]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/visitors/VariableDeclarator.js
