# Svelte framework

**Capability.** Root capability spanning the Svelte compiler pipeline, the client reactivity runtime, the server renderer, the public authoring API and its typings, and the build/tooling that produces and exercises all of it.

Start here to navigate the repository. Children own one major responsibility area each; units are grouped by responsibility rather than directory. Cross-cutting dependencies (e.g. generated docs consuming the client transform) are recorded in depends_on.

**Children.**

- [Compiler](r2-compiler.md) `r2-compiler` · 0 unit(s)
- [Client runtime](r2-client-runtime.md) `r2-client-runtime` · 2 unit(s)
- [Server renderer](r2-server-render.md) `r2-server-render` · 30 unit(s)
- [Public authoring API and typings](r2-public-api.md) `r2-public-api` · 7 unit(s)
- [Build and repo tooling](r2-build-tooling.md) `r2-build-tooling` · 10 unit(s)
- [Reactivity benchmarks](r2-benchmarks.md) `r2-benchmarks` · 2 unit(s)

Parent: [Build and Packaging](build-and-packaging.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
