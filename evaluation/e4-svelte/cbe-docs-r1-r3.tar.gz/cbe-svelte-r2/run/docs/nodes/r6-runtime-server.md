# Server Runtime

**Capability.** SSR-side component context (scoped push/pop with parent-chain lookup) and abort-signal management for cancelling in-flight server renders.

Use for server-side context/get/set/has APIs and render abort semantics. get_or_init_context_map lazily builds context maps with ancestor inheritance.

**Depends on.**

- [Shared Utilities and Tests](r6-shared-infra.md) · model-inferred · 0 edge(s)

Parent: [Svelte Monorepo](r6-svelte-monorepo.md)

## Units (10)

<a id="u-9654b4650543"></a>
### `abort`

`export function abort()` · [packages/svelte/src/internal/server/abort-signal.js:L6-L9][f1]

Abort any active server-side abort controller and reset module state so subsequent renders start clean.

uses: [packages/svelte/src/internal/server/abort-signal.js:getAbortSignal](r6-runtime-server.md#u-fbe9939ec5b9)

<a id="u-fbe9939ec5b9"></a>
### `packages/svelte/src/internal/server/abort-signal.js:getAbortSignal`

`export function getAbortSignal()` · [packages/svelte/src/internal/server/abort-signal.js:L11-L13][f1]

Lazily create the module's AbortController and return its signal.

The controller persists between calls (`controller ??= new AbortController()`), so callers sharing a render get the same signal until abort() clears it. Acts as a side-effectful accessor over module state.

uses: [abort](r6-runtime-server.md#u-9654b4650543)

**Uncertainties.**

- Whether abort() is invoked exactly once per render is enforced only in render's finally (visible in index.js); direct callers could leak a stale controller between renders.

<a id="u-ebffdeebb3a9"></a>
### `packages/svelte/src/internal/server/context.js:getAllContexts`

`export function getAllContexts()` · [packages/svelte/src/internal/server/context.js:L41-L43][f2]

Return the current component's whole context Map, initializing it (including inheritance from ancestors) if needed.

Throws outside a component. Mutating the returned Map mutates the component's context.

calls: [packages/svelte/src/internal/server/context.js:get_or_init_context_map](r6-runtime-server.md#u-23128ee48fc4)

<a id="u-590d884e05a5"></a>
### `packages/svelte/src/internal/server/context.js:getContext`

`export function getContext(key)` · [packages/svelte/src/internal/server/context.js:L14-L19][f2]

Read a context value for the current component by key.

Builds (or reuses) the component's context map and returns `map.get(key)` cast to T; a missing key yields undefined rather than an error. Throws via the lifecycle guard when called outside any component.

calls: [packages/svelte/src/internal/server/context.js:get_or_init_context_map](r6-runtime-server.md#u-23128ee48fc4)

<a id="u-23128ee48fc4"></a>
### `packages/svelte/src/internal/server/context.js:get_or_init_context_map`

`function get_or_init_context_map(name)` · [packages/svelte/src/internal/server/context.js:L49-L55][f2]

Shared guard and lazy initializer for all context APIs.

If current_component is null it calls e.lifecycle_outside_component(name), which throws (never returns per its signature). Otherwise it assigns `current_component.c ??= new Map(get_parent_context(current_component) || undefined)` — so a first access clones the nearest ancestor's context map, giving copy-on-write inheritance: child context starts as a snapshot of the parent's and further writes stay local.

calls: [packages/svelte/src/internal/server/context.js:get_parent_context](r6-runtime-server.md#u-6c070cbfaf56); raises: [lifecycle_function_unavailable](r1-server-runtime.md#u-af8d810f9167)

<a id="u-6c070cbfaf56"></a>
### `packages/svelte/src/internal/server/context.js:get_parent_context`

`function get_parent_context(component_context)` · [packages/svelte/src/internal/server/context.js:L84-L96][f2]

Walk the parent chain (component.p) and return the first non-null context map found, or null if no ancestor has one.

Loops until parent is null; does not modify any state.

<a id="u-d714cd56dee8"></a>
### `packages/svelte/src/internal/server/context.js:hasContext`

`export function hasContext(key)` · [packages/svelte/src/internal/server/context.js:L36-L38][f2]

Return whether a key exists in the current component's context map, without reading the value.

Throws outside a component.

calls: [packages/svelte/src/internal/server/context.js:get_or_init_context_map](r6-runtime-server.md#u-23128ee48fc4)

<a id="u-b3ad8cba6058"></a>
### `packages/svelte/src/internal/server/context.js:pop`

`export function pop()` · [packages/svelte/src/internal/server/context.js:L68-L78][f2]

Leave the current component scope.

Reads `current_component.d` (array of ondestroy callbacks, if any) and appends them to the exported on_destroy list for later execution at end of render, then restores current_component to the parent. Assumes a component is currently active; cast is unchecked.

uses: [index.js module code (L53–L68)][f3]

<a id="u-38e06b351976"></a>
### `packages/svelte/src/internal/server/context.js:push`

`export function push(fn)` · [packages/svelte/src/internal/server/context.js:L60-L66][f2]

Enter a component scope: push a new {p, c, d} record onto the linked stack by making it current_component with the previous one as parent.

In DEV it also records the component function under `function`. Context map and ondestroy list start null/empty; the previous component is never mutated.

uses: [packages/svelte/src/internal/server/context.js:pop](r6-runtime-server.md#u-b3ad8cba6058)

<a id="u-9d2873c370b6"></a>
### `packages/svelte/src/internal/server/context.js:setContext`

`export function setContext(key, context)` · [packages/svelte/src/internal/server/context.js:L27-L30][f2]

Store a context value under a key on the current component and return the same value.

Uses the lazily initialized context map; throws outside a component. Later entries overwrite earlier ones for the same key.

calls: [packages/svelte/src/internal/server/context.js:get_or_init_context_map](r6-runtime-server.md#u-23128ee48fc4)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/server/abort-signal.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/server/context.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/server/index.js
