# Public API Surface

**Capability.** User-facing reactivity, motion, transition, and store features with their type declarations: ambient rune typings for tooling, reactive collections, tweened motion (legacy store and Tween class), built-in transition factories, and the public store/animate/attachment contracts.

Applications import from here; the compiler emits calls into internal runtime on their behalf. Type-declaration groups document contracts without runtime behavior.

**Children.**

- [Rune Ambient Types](r1-public-runes-types.md) `r1-public-runes-types` · 8 unit(s)
- [Reactive Collections & Motion](r1-public-reactivity-motion.md) `r1-public-reactivity-motion` · 13 unit(s)
- [Public Type Contracts](r1-public-type-contracts.md) `r1-public-type-contracts` · 3 unit(s)

Parent: [Svelte Monorepo](r1-svelte-monorepo.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
