# Task Scheduling

**Capability.** Shared microtask and idle-task queues with synchronous flush, used across the client runtime to defer DOM work.

Use queue_micro_task/queue_idle_task to defer callbacks; flush_tasks drains both queues (used by tests and teardown paths).

**Depends on.**

- [Shared Utilities and Tests](r6-shared-infra.md) · graph-confirmed · 2 edge(s)

**Depended on by.**

- [DOM Template Blocks](r6-client-dom-blocks.md) · model-inferred · 0 edge(s)
- [Element Effects and Transitions](r6-client-dom-elements.md) · graph-confirmed · 2 edge(s)

Parent: [Client Runtime](r6-runtime-client.md)

## Units (5)

<a id="u-f61b99082e8c"></a>
### `flush_tasks`

`export function flush_tasks()` · [packages/svelte/src/internal/client/dom/task.js:L52-L60][f1]

Synchronously drains both queues: micro tasks first, then idle tasks, each only if non-empty.

Queued callbacks run immediately instead of on their usual microtask/idle schedule.

calls: [run_micro_tasks](r6-client-dom-task.md#u-796c025f6846), [run_idle_tasks](r6-client-dom-task.md#u-c70f2ab94d65)

<a id="u-74329185432d"></a>
### `queue_idle_task`

`export function queue_idle_task(fn)` · [packages/svelte/src/internal/client/dom/task.js:L41-L47][f1]

Adds a callback to the idle queue.

Only when the queue was empty does it schedule run_idle_tasks through request_idle_callback, which falls back to setTimeout(cb, 1) when requestIdleCallback is unavailable.

calls: [run_idle_tasks](r6-client-dom-task.md#u-c70f2ab94d65)

<a id="u-996120ba9b8d"></a>
### `queue_micro_task`

`export function queue_micro_task(fn)` · [packages/svelte/src/internal/client/dom/task.js:L30-L36][f1]

Adds a callback to the shared microtask queue.

Only when the queue was empty does it schedule run_micro_tasks with queueMicrotask, so one flush drains everything queued in the current turn.

calls: [run_micro_tasks](r6-client-dom-task.md#u-796c025f6846)

<a id="u-c70f2ab94d65"></a>
### `run_idle_tasks`

`function run_idle_tasks()` · [packages/svelte/src/internal/client/dom/task.js:L21-L25][f1]

Swaps out the idle_tasks queue and runs all collected callbacks synchronously via run_all.

calls: [run_all](r6-shared-infra.md#u-15a69c36073f)

<a id="u-796c025f6846"></a>
### `run_micro_tasks`

`function run_micro_tasks()` · [packages/svelte/src/internal/client/dom/task.js:L15-L19][f1]

Swaps out the micro_tasks queue and runs all collected callbacks synchronously via run_all, so callbacks queued during the flush run only on the next microtask turn.

calls: [run_all](r6-shared-infra.md#u-15a69c36073f)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/task.js
