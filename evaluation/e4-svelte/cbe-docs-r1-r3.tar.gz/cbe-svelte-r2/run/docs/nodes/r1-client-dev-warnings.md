# Generated Warning Helpers

**Capability.** Generated dev-warning functions, each calling console.warn exactly once with a specific diagnostic message and returning nothing.

This is the message catalog consumed by the other dev-mode diagnostics; edit generated sources upstream rather than by hand.

Parent: [Dev-mode Diagnostics](r1-client-dev-dx.md)

## Units (1)

<a id="u-b66cedc3c469"></a>
### `warnings-js-generated-messages`

`export function assignment_value_stale(property, location)` · [packages/svelte/src/internal/client/warnings.js:L13-L19][f1]

Generated dev-warning helpers, each calling `console.warn` exactly once and returning nothing.

When DEV is true, every function emits a formatted message with a bold `[svelte]` code line, the human-readable explanation, and a docs URL; when DEV is false it emits only the bare URL string. Two functions have conditional text: `binding_property_non_reactive` includes the location in parentheses only when a truthy location is supplied, and `hydration_html_changed`/`hydration_mismatch` similarly append or omit the location phrase. The rest interpolate their parameters directly into fixed message templates. Side effect is console output only; no state is read or mutated.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/warnings.js
