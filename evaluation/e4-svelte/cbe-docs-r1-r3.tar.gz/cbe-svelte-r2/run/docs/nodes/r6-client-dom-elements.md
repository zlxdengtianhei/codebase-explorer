# Element Effects and Transitions

**Capability.** Per-element runtime effects: intro/outro animations and transitions (managers, keyframe parsing, event dispatch), imperative element behaviors (autofocus, form reset listeners, textarea hydration), and deprecated Svelte 4 event-modifier substitutes.

Use for transition/animation lifecycle and element attribute side effects. transition/animation both funnel into animate(); modifiers are higher-order handler wrappers kept for legacy compatibility.

**Depends on.**

- [Task Scheduling](r6-client-dom-task.md) · graph-confirmed · 2 edge(s)
- [Shared Utilities and Tests](r6-shared-infra.md) · graph-confirmed · 1 edge(s)

Parent: [Client Runtime](r6-runtime-client.md)

## Units (10)

<a id="u-7f00a79795f4"></a>
### `autofocus`

`export function autofocus(dom, value)` · [packages/svelte/src/internal/client/dom/elements/misc.js:L10-L21][f1]

Applies autofocus imperatively: when value is true it sets dom.autofocus and queues a micro task that calls dom.focus() only if the body is still the active element, i.e. the user has not already focused something else.

Does nothing when value is false.

calls: [queue_micro_task](r6-client-dom-task.md#u-996120ba9b8d)

<a id="u-3524dfa24535"></a>
### `add_form_reset_listener`

`export function add_form_reset_listener()` · [packages/svelte/src/internal/client/dom/elements/misc.js:L37-L58][f1]

Registers, at most once per document (module-level flag), a capture-phase 'reset' listener that, one microtask later (after form element DOM properties have reset), calls each form element's __on_r hook unless the reset's default was prevented.

Capture phase guarantees the listener runs despite stopPropagation.

**Notes.**

- contract: Element hooks named __on_r (installed by remove_input_defaults) are invoked one tick after the reset event.

<a id="u-d9f3f6cd0345"></a>
### `remove_textarea_child`

`export function remove_textarea_child(dom)` · [packages/svelte/src/internal/client/dom/elements/misc.js:L29-L33][f1]

During hydration, clears a textarea's children, since the child content actually represents defaultValue; does nothing outside hydration or when the textarea has no first child.

calls: [clear_text_content](r5-runtime-dom.md#u-a9b234e4df06), [get_first_child](r5-runtime-dom.md#u-fa05927498af)

<a id="u-ebc7650933de"></a>
### `animate`

`function animate(element, options, counterpart, t2, on_finish)` · [packages/svelte/src/internal/client/dom/elements/transitions.js:L314-L372][f2]

Runs an intro (t2=1) or outro (t2=0) animation and returns a facade with abort/deactivate/reset/t.

When options is a function (deferred transitions such as crossfade), it queues a micro task to call it with the direction and recursively animate the resulting config, returning a facade that forwards to the inner animation and records abort even before the inner one exists. It first deactivates the counterpart (opposite intro/outro). When options is missing or has no duration, it calls on_finish immediately and returns a no-op facade with t() = t2. Otherwise, for an intro with no counterpart it applies tick(0,1) and seeds keyframes from css(0,1); it then plays a dummy delay-length animation with fill forwards (delay defaults to 0), whose onfinish cancels the dummy, reads the counterpart's current t as the start t1 (enabling bidirectional reversal), aborts the counterpart, computes duration = options.duration * |t2 - t1|, and when duration > 0 samples css at n+1 eased points (n = frames for 60fps, integer ceiling so t2 is not missed), forces overflow hidden inline when any keyframe uses overflow:hidden (Safari <18 workaround), tracks t via animation.currentTime through the easing, drives tick in a loop while the animation is running, and on the main animation's finish pins t, runs tick(t2, 1-t2), and calls on_finish. abort cancels the current animation, nulls its effect (Chromium leak) and neutralizes onfinish; deactivate replaces on_finish with noop; reset on an outro runs tick(1,0); t() returns the tracked t.

calls: [queue_micro_task](r6-client-dom-task.md#u-996120ba9b8d), [loop](r1-client-runtime.md#u-4df1fec218a0)

**Uncertainties.**

- Whether the dummy delay animation's onfinish always fires on all browsers (e.g. when tab is backgrounded) is a Web Animations API behavior not provable from this source.
- The loop callback's return-false exit condition depends on loop's contract, defined outside this file.

<a id="u-d0d565c5637e"></a>
### `animation`

`export function animation(element, get_fn, get_params)` · [packages/svelte/src/internal/client/dom/elements/transitions.js:L83-L100][f2]

Creates (or reuses) the animation manager for a keyed each item, enabling animated moves after reconciliation.

The manager is stored on item.a and exposes four phases: measure records the element's bounding rect as the 'from'; apply aborts any running animation, records the 'to' rect, and only when the rects actually differ creates the user's AnimateFn options and runs animate() with a completion callback that aborts and clears the animation; fix temporarily pins the element to position absolute with computed width/height and a translate offset when the from/to positions differ — skipped entirely when an animation is already running, since animation styles would take precedence — saving original styles for unfix; unfix restores the saved styles. For svelte:element tag changes where a manager already exists, the manager's element reference is swapped to the new element instead of creating a new manager.

calls: [animate](r6-client-dom-elements.md#u-ebc7650933de)

**Uncertainties.**

- The caller contract that measure/fix/apply/unfix are invoked in the expected order by each-block reconciliation is not visible in this file.

<a id="u-397113669a45"></a>
### `css_property_to_camelcase`

`function css_property_to_camelcase(style)` · [packages/svelte/src/internal/client/dom/elements/transitions.js:L35-L52][f2]

Converts a CSS property name to the camelCase form used by Element.animate: maps 'float' to cssFloat and 'offset' to cssOffset, leaves custom properties starting with '--' untouched, and otherwise capitalizes each segment after the first hyphen.

<a id="u-fbaa1dadf713"></a>
### `css_to_keyframe`

`function css_to_keyframe(css)` · [packages/svelte/src/internal/client/dom/elements/transitions.js:L58-L70][f2]

Parses a CSS declaration string into a Keyframe object by splitting on ';' and each declaration on ':'; stops parsing at the first malformed declaration (empty property or missing value); each property is converted with css_property_to_camelcase and values are trimmed.

<a id="u-4fbd2318aa9b"></a>
### `dispatch_event`

`function dispatch_event(element, type)` · [packages/svelte/src/internal/client/dom/elements/transitions.js:L24-L28][f2]

Dispatches a CustomEvent with the given intro/outro start/end type on an element, wrapped in without_reactive_context so the dispatch does not create reactive dependencies.

<a id="u-61fe578d008d"></a>
### `transition`

`export function transition(flags, element, get_fn, get_params)` · [packages/svelte/src/internal/client/dom/elements/transitions.js:L184-L211][f2]

Creates a transition manager from flags (in/out/global) and attaches it to the current active effect's transitions list, so pause/resume of the effect later triggers intros and outros.

get_options lazily computes the user's AnimationConfig inside without_reactive_context, caching it in current_options so an ongoing transition reverses smoothly instead of regenerating. in(): restores the element's original inert state; for intro-only transitions aborts a prior intro; for non-bidirectional cases aborts a pending outro; dispatches 'introstart' and runs animate(..., t2=1) whose completion dispatches 'introend', aborts and clears the intro and options, and restores the stashed overflow style (Safari <18 workaround). out(fn): for non-outro transitions just calls fn and clears options; otherwise sets inert, dispatches 'outrostart', and runs animate(..., t2=0) whose completion dispatches 'outroend' then calls fn. stop() aborts both. When this is an intro and should_intro holds, the transition runs immediately via effect(() => untrack(() => transition.in())), unless it is local: then it runs only when the nearest enclosing non-transparent block effect is absent or has already run, where transparent ancestors (snippets, else-if) are skipped.

calls: [animate](r6-client-dom-elements.md#u-ebc7650933de), [without_reactive_context](r3-element-bindings.md#u-ff3a57d1f4f9), [effects.js-effect-creators](r3-effects-engine.md#u-27c9c7c4069f), [untrack](r2-reactivity-core.md#u-aa0e067da463)

**Uncertainties.**

- Exact semantics of should_intro and effect flags (EFFECT_TRANSPARENT, BLOCK_EFFECT, EFFECT_RAN) are defined outside this file.

<a id="u-756ffb8754e5"></a>
### `event-modifiers.js-modifiers`

`export function trusted(fn)` · [packages/svelte/src/internal/client/dom/legacy/event-modifiers.js:L11-L19][f3]

Deprecated runtime substitutes for Svelte 4 event modifiers, each a higher-order function returning a wrapped handler, except the action-style `passive`/`nonpassive`.

`trusted` invokes `fn` only when `event.isTrusted` is true. `self` invokes `fn` only when `event.target === this` (the bound element). `stopPropagation`, `stopImmediatePropagation`, and `preventDefault` call the corresponding event method first and forward the arguments and return value of `fn?.apply(this, args)`. `once` closes over a `ran` flag so the handler executes exactly one time and is a no-op afterwards. All wrappers tolerate a nullish `fn` via optional-call. `passive(node, [event, handler])` and `nonpassive` register the listener inside a `user_pre_effect` through the `on` helper with `{ passive: true }` / `{ passive: false }`, defaulting a nullish handler result to `noop`; the value returned by `on` is the effect teardown.

calls: [packages/svelte/src/internal/client/dom/elements/events.js:on](r2-dom-elements.md#u-d8e90951de4c), [effects.js-effect-creators](r3-effects-engine.md#u-27c9c7c4069f)

**Uncertainties.**

- Whether `passive`/`nonpassive` are consumed as Svelte actions (their signatures suggest it) is not evidenced in this file.
- The `on` helper's listener semantics (registration, teardown) are defined elsewhere.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/elements/misc.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/elements/transitions.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/legacy/event-modifiers.js
