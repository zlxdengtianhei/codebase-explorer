# Compiler Pipeline and Migration

**Capability.** Owns source-to-output compilation: parse, analyze, and client/server transforms, plus the Svelte 4→5 codemod pipeline and the shared compiler utilities both phases and migration consume. These belong together because migration rewrites the same AST the transform phases emit, and all depend on the shared AST/element-predicate helpers.

Use this subtree to trace a .svelte file to a CompileResult, or to understand and extend migration codemods. Phase internals (analyze, client/server transform) sit beside migrate() visitors; shared utilities are consumer-agnostic and behavior must be preserved for all callers.

**Children.**

- [Svelte Monorepo](r5-svelte-monorepo.md) `r5-svelte-monorepo` · 0 unit(s)

**Depends on.**

- [Build and Packaging](build-and-packaging.md) · graph-confirmed · 67 edge(s)
- [Client/Server Runtime and Shared Infrastructure](runtime-and-shared-infra.md) · graph-confirmed · 54 edge(s) · Compiler transforms emit calls into the client and server runtimes, so generated code's runtime behavior is implemented in the runtime-and-shared-infra subtree.

**Depended on by.**

- [Client/Server Runtime and Shared Infrastructure](runtime-and-shared-infra.md) · graph-confirmed · 60 edge(s)
- [Svelte Monorepo](svelte-monorepo.md) · containment · → 0 / ← 0 edge(s) (ancestor direct units and descendant subtree; → follows ` svelte-monorepo ` → ` compiler-and-migration `)
- [Benchmarks and Developer Environment](tooling-and-dev-env.md) · graph-confirmed · 107 edge(s)

Parent: [Svelte Monorepo](svelte-monorepo.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
