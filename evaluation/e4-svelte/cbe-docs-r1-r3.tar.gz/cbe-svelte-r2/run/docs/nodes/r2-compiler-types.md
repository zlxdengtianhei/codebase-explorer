# Compiler type surface

**Capability.** Type declarations for the compiler: public compile result/options types, the legacy Svelte 4 AST node types, deprecated aliases, and the private/public re-export entry points.

Use index.d.ts for the current public compiler types and legacy-nodes.d.ts when reading Svelte 4 compatibility paths. private.d.ts re-exports the full internal surface; public.d.ts is the curated external entry.

Parent: [Compiler](r2-compiler.md)

## Units (5)

<a id="u-10040b416e26"></a>
### `index.d.ts-compiler-result-and-options`

`export interface CompileResult` · [packages/svelte/src/compiler/types/index.d.ts:L14-L50][f1]

Type declarations for the compiler's public surface.

`CompileResult` describes what `compile` returns: `js` code plus a magic-string SourceMap, a nullable `css` result with `hasGlobal` marking global rules, `warnings`, `metadata.runes` (always true for `compileModule`), and an `any`-typed `ast`. `Warning` and `CompileError` are empty extensions of `ICompileDiagnostic`, so all diagnostic shape comes from that import. `CssHashGetter` is the `cssHash` callback contract: it receives name, filename, css text, and a hash function and returns the scoped classname (documented default `svelte-${hash(css)}`). `ModuleCompileOptions` holds shared knobs: `dev`; `generate` as `'client'`, `'server'`, or `false` (nothing generated, useful for warning-only tooling); `filename`; `rootDir` (documented as `process.cwd()` on node-like environments); `warningFilter` returning true to keep a warning; experimental `async` (await in deriveds/template expressions/component top level, since 5.36). `CompileOptions` adds component knobs: `name` inferred from filename if unspecified; `customElement` (documented to force `css: 'injected'` and default `accessors` to true); deprecated `accessors`/`immutable` with no effect in runes mode; `namespace`; `css` injected vs external; `cssHash`; `preserveComments`/`preserveWhitespace`; `fragments` html-vs-tree (tree works under CSP `require-trusted-types-for`); `runes` where undefined infers from code and a config-level `true` forces project-wide runes; `discloseVersion`; `compatibility.componentApi` 4|5; `sourcemap` merged into the output; output filenames; `hmr`; `modernAst`. The `Validated*` aliases exist, per their comment, to make options required-but-undefined-able: `ValidatedModuleCompileOptions` re-adds `rootDir` keeping it optional-shaped, and `ValidatedCompileOptions` intersects `Required` variants while restoring the original (possibly undefined) types for `name`, filenames, `sourcemap`, `runes`, requires `compatibility`, and adds `customElementOptions: AST.SvelteOptions['customElement']`. `BindingKind` (13 string variants: normal, prop, bindable_prop, rest_prop, raw_state, state, derived, each, snippet, store_sub, legacy_reactive, template, static) and `DeclarationKind` are string-literal unions; `ExpressionMetadata` records eagerly vs lazily referenced `Binding` sets plus `has_state`/`has_call`/`has_await`/`has_member_expression`/`has_assignment`; `StateField` ties a state-creation rune (`StateCreationRuneName` type) to its `PropertyDefinition`/`AssignmentExpression` node, `PrivateIdentifier` key, and rune `CallExpression`. Tail re-exports surface `template.js` types, `Binding`/`Scope`, and `ReactiveStatement` (TODO noting the chain is odd). No runtime behavior exists in this file.

**Uncertainties.**

- Where the documented defaults (e.g. `@default 'client'`) are enforced is not visible in this file.
- `OptimizeOptions` has only its `hydrate?` flag here; its consumer is unknown.
- `CompileResult.ast` is `any`, so the returned AST shape is not typed here.
- `ValidatedCompileOptions.customElementOptions` is added despite not existing on `CompileOptions`; its population site is unknown here.

<a id="u-9be87a51ccd3"></a>
### `legacy-interfaces.d.ts-deprecated-aliases`

`export type CompileOptions = C;` · [packages/svelte/src/compiler/types/legacy-interfaces.d.ts:L4-L4][f2]

Deprecated re-export aliases for backward compatibility.

`CompileOptions` aliases the `#compiler` module's `CompileOptions` (`C`) and `Warning` aliases its `Warning` (`W`); both carry `@deprecated import this from 'svelte' instead` JSDoc. No declarations or behavior of their own — any consumer of these aliases sees exactly the `#compiler` types.

<a id="u-2b7a597755cc"></a>
### `legacy-nodes.d.ts-legacy-ast-node-types`

`interface BaseNode` · [packages/svelte/src/compiler/types/legacy-nodes.d.ts:L13-L17][f3]

Type declarations for the legacy (Svelte 4-style) template AST, importing `AST` from `#compiler` and estree node types.

Local `BaseNode` requires `type: string` plus `start`/`end`, and `BaseElement` adds `name`, `attributes: LegacyAttributeLike[]`, and `children: LegacyElementLike[]`. Directive-like nodes follow a common pattern of `name` plus a nullable or required `expression`: `LegacyAction` (`use:x`), `LegacyAnimation` (`animate:x`), `LegacyBinding` (`bind:x`, accepting Identifier, MemberExpression, or SequenceExpression), `LegacyClass` (`class:x`, `name` literally `'class'`), `LegacyEventHandler` (`on:x`, with a `modifiers: string[]` list), `LegacyStyleDirective` (`style:x`, `value` either `true` (shorthand) or an array of `AST.ExpressionTag | AST.Text`, `modifiers` of `'important'`), and `LegacyTransition` (`transition:`/`in:`/`out:` with `'local' | 'global'` modifiers and `intro`/`outro` booleans — per the docstrings, `intro` is true for `transition:`/`in:` and `outro` for `transition:`/`out:`). Attribute-side nodes: `LegacyAttribute` with `value` of `true` or an array of `AST.Text | LegacyMustacheTag | LegacyAttributeShorthand`, `LegacyAttributeShorthand`, `LegacyLet` (`let:x`, expression null/Identifier/Array/ObjectExpression), `LegacySpread`. Block-shaped nodes (`LegacyCatchBlock`, `LegacyPendingBlock`, `LegacyThenBlock`) hold `children: LegacySvelteNode[]` and a `skip` flag. `BaseElement` subtypes fix `type` and usually `name`: `LegacyBody` ('svelte:body'), `LegacyDocument`, `LegacyHead`, `LegacyInlineComponent` (optional `expression` set for `<svelte:component>`), `LegacySlot`, `LegacySlotTemplate`, `LegacyTitle` (name `'title'`), `LegacyWindow`. `LegacyElement` is a lone `{ type: 'Element' }` interface with no other fields. Others: `LegacyMustacheTag`, `LegacyRawMustacheTag`, `LegacyOptions` (attributes `any[]`), `SnippetBlock` (Identifier expression, nullable `Pattern` context, children), `RenderTag` (Identifier expression, nullable argument), `LegacyConstTag` (AssignmentExpression), `LegacyComment` with `data` and `ignores` (documented as `['a','b','c']` for `<!-- svelte-ignore a b c -->`), and `LegacyStyle`/`LegacySelector` for CSS (`LegacySelector` children are `AST.CSS.Combinator | AST.CSS.SimpleSelector`; `LegacyStyle` uses `any[]` for attributes and children). The closing unions tie it together: `LegacyDirective` (the eight directive types), `LegacyAttributeLike`, `LegacyElementLike` (16 member types including `LegacyElement` and `LegacyComment`), `LegacyCssNode`, and `LegacySvelteNode` (which also admits `AST.Text`). Declaration-only types: no runtime behavior here.

**Uncertainties.**

- `LegacyRoot.css/instance/module` are `any`, so the shapes of the parsed CSS and script roots in a legacy tree are not typed here.
- `LegacyElement` has only `type: 'Element'` and no start/end/name fields despite being a `LegacyElementLike` member; how consumers handle it is unknown from this file.
- `LegacyEventHandler.modifiers` is plain `string[]` with no literal restriction, unlike the transition modifiers.

<a id="u-23a4c3a13e41"></a>
### `private.d.ts module code (L1–L2)`

`module_region` · [packages/svelte/src/compiler/private.d.ts:L1-L2][f4]

Re-exports the full public surface of the Svelte compiler by re-exporting everything from ./types/index and ./index.

This file adds no declarations of its own, so its export set is exactly the union of those two modules' exports.

imports: [packages/svelte/src/compiler/index.js][f5], [packages/svelte/src/compiler/types/index.js](../../catalog.json)

**Uncertainties.**

- Name collisions between the two re-exported modules, if any, are not resolvable from this file alone.

<a id="u-2fb29ef9b5c5"></a>
### `public.d.ts module code (L1–L15)`

`module_region` · [packages/svelte/src/compiler/public.d.ts:L1-L15][f6]

Type-only public entry point for the compiler: re-exports ./index.js wholesale, then explicitly re-exports preprocessor types (MarkupPreprocessor, Preprocessor, PreprocessorGroup, Processed), compile types (CompileError, CompileOptions, ModuleCompileOptions, CompileResult, Warning) from ./types/index, and the AST type from ./types/template.

No runtime code; only type declarations are published here.

imports: [packages/svelte/src/compiler/index.js][f5], [packages/svelte/src/compiler/preprocess/public.js](../../catalog.json), [packages/svelte/src/compiler/types/index.js](../../catalog.json), [packages/svelte/src/compiler/types/template.js](../../catalog.json)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/types/index.d.ts
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/types/legacy-interfaces.d.ts
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/types/legacy-nodes.d.ts
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/private.d.ts
[f5]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/index.js
[f6]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/public.d.ts
