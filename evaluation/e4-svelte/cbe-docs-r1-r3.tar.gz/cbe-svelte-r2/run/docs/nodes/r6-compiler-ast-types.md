# Compiler AST Declarations

**Capability.** Declaration-only descriptions of the compiler's internal CSS AST (the _CSS/CSS namespace) and template AST (the AST namespace) consumed by every phase.

Read these for the shape of parsed CSS or template nodes. They contain no runtime behavior.

**Depended on by.**

- [Template Parsing](r6-compiler-parse.md) · model-inferred · 0 edge(s)

Parent: [Compiler Pipeline](r6-compiler.md)

## Units (2)

<a id="u-5d5d8b2013b5"></a>
### `css.d.ts-css-ast-node-types`

`export namespace _CSS { export interface BaseNode` · [packages/svelte/src/compiler/types/css.d.ts:L3-L7][f1]

Type declarations for the compiler's internal CSS AST, exported as the `_CSS` namespace and re-aliased to `CSS` by template.d.ts.

`BaseNode` fixes only `start`/`end` positions. `StyleSheet` holds Atrule/Rule children plus a `content` block with raw styles text and an optional leading `AST.Comment`; its `attributes` is an `any[]` TODO. `Rule` wraps a `SelectorList` prelude and a `Block`, carrying internal scoping metadata: `parent_rule`, `has_local_selectors`, `has_global_selectors` (a ComplexSelector whose RelativeSelectors are all global/global-like), and `is_global_block` (a `:global` selector makes everything inside unscoped). `ComplexSelector` (`a b c`) holds `RelativeSelector` children with internal `rule`, `is_global`, and `used` flags — `used` is documented as set in css-analyze for global selectors and in css-prune while scoping for others. `RelativeSelector` (`a`, `> b`) has a nullable `combinator` (null for the first selector) and a `SimpleSelector` list; its internal `is_global` treats `:global(...)`, `:global`, `:global.x` as unscoped but not `:global(...).x`, and `:global(...):is/where/not/has(...)` only when all children are global; `is_global_like` covers `:root`, `:host`, `::view-transition`, or selectors after a `:global`. Remaining shapes are flat: `TypeSelector`/`IdSelector`/`ClassSelector`/`PseudoElementSelector` with a `name`, `AttributeSelector` with nullable matcher/value/flags, `PseudoClassSelector` with nullable `SelectorList` args, `Percentage`, `Nth`, `NestingSelector` whose `name` is literally `'&'`, `Combinator`, `Block` of Declaration/Rule/Atrule, `Declaration` property/value strings, the `SimpleSelector` union, and a `Node` union labeled 'for zimmerframe' traversal. Declaration-only types: no runtime behavior here.

**Notes.**

- contract: The `Node` union omits `StyleSheet`, so a zimmerframe walk rooted at a stylesheet must handle the root outside that union.

**Uncertainties.**

- Where `metadata.used` and the global/scoping flags are computed is asserted only by doc comments, not shown here.
- `StyleSheet.attributes` is `any[]` with a TODO, so its element type is unknown.

<a id="u-f4796b15510a"></a>
### `template.d.ts-ast-namespace`

`export type Namespace = 'html' | 'svg' | 'mathml';` · [packages/svelte/src/compiler/types/template.d.ts:L28-L28][f2]

The modern template AST declarations, exported as the `AST` namespace, plus module-level helpers and an estree augmentation.

`Namespace` is the `'html' | 'svg' | 'mathml'` union; `DelegatedEvent` is either `{ hoisted: true; function: ArrowFunctionExpression | FunctionExpression | FunctionDeclaration }` or `{ hoisted: false }`. `AST.BaseNode` requires `type`, `start`, `end`. `Fragment` holds `nodes` of Text/Tag/ElementLike/Block/Comment with internal metadata: `transparent` (documented: the fragment's scope has no scope in the output JS, e.g. an element scope, so unique-identifier generation delegates to parent scopes), `dynamic` (whether mount/hydrate must traverse in), and `has_await`. `Root` is the top node with `options: SvelteOptions | null` (inline `<svelte:options>` overriding compile options), `fragment`, nullable `css: AST.CSS.StyleSheet` (the `_CSS` namespace re-exported as `CSS` at the end), nullable `instance` and `module` `Script`s, `comments: JSComment[]`, and internal `ts` flag. `SvelteOptions` carries position info plus optional `runes`, `immutable`, `accessors`, `preserveWhitespace`, `namespace`, `css?: 'injected'`, and a `customElement` object (tag, shadow `'open' | 'none'`, typed `props` with attribute/reflect/type, and an `extend` callback taking and returning a component class). Text node: `data` with decoded entities and `raw` with undecoded. Tag nodes: `ExpressionTag`, `HtmlTag`, `ConstTag` (a constrained single-declarator VariableDeclaration), `DebugTag` (`identifiers: Identifier[]`), `RenderTag` (a SimpleCallExpression or ChainExpression wrapping one; internal metadata includes per-argument ExpressionMetadata, `snippets` set and `path` for CSS pruning), `AttachTag`. Directives: `AnimateDirective`, `BindDirective` (metadata with `binding_group_name` and `parent_each_blocks`), `ClassDirective` (`name` literally `'class'`), `LetDirective`, `OnDirective` with a closed modifier union (capture, nonpassive, once, passive, preventDefault, self, stopImmediatePropagation, stopPropagation, trusted), `StyleDirective` (`value` of `true`, ExpressionTag, or mixed array; `'important'` modifiers), `TransitionDirective` (with `intro`/`outro` booleans), `UseDirective`. `BaseElement` adds `name`, `attributes` (Attribute | SpreadAttribute | Directive | AttachTag), and a `fragment`. Element subtypes: `Component` (metadata `scopes: Record<string, Scope>`, `dynamic`, `snippets`, `path`), `TitleElement`, `SlotElement`, `RegularElement` (svg/mathml/has_spread/scoped/path metadata), `SvelteBody`, `SvelteComponent` (dynamic tag `expression`), `SvelteDocument`, `SvelteElement` (dynamic `tag` expression; svg/mathml metadata docstrings concede the booleans may be inaccurate for dynamic tags), `SvelteFragment`, `SvelteBoundary`, `SvelteHead`, `SvelteSelf`, `SvelteWindow`, and `SvelteOptionsRaw`, docstring-noted as an intermediate parse-time representation that does not exist in the final AST. Blocks: `EachBlock` (expression, nullable context Pattern, body, optional fallback/index/key; metadata includes `keyed`, `contains_group_binding`, an `index` Identifier, a declarations Map, `is_controlled` — documented as an optimization when the parent isn't a fragment and there's a single child — and `transitive_deps`), `IfBlock` (with `elseif` flag, test, consequent, nullable alternate), `AwaitBlock` (expression, nullable value/error patterns and pending/then/catch fragments), `KeyBlock`, and `SnippetBlock` (identifier, parameters, optional typeParams, body; metadata `can_hoist` and a `sites` set for CSS pruning). `Attribute` value is `true`, an ExpressionTag, or an array of Text|ExpressionTag (docstring: quoted/string values are arrays even for a single expression); metadata covers `delegated` (DelegatedEvent or null) and `needs_clsx`. `SpreadAttribute`, `Script` (context `'default' | 'module'`, estree `Program` content, attributes), and `JSComment` (Line/Block with value, positions, and loc) complete the set. Closing unions: `AttributeLike`, `Directive` (eight), `Block` (five), `ElementLike` (15, with `SvelteBoundary` appearing twice in the union), `Tag`, `TemplateNode`, and `SvelteNode = Node | TemplateNode | AST.Fragment | _CSS.Node | Script`. A `declare module 'estree'` augmentation adds optional `start`/`end` (Svelte parser) and `typeAnnotation` (acorn-typescript) to estree's `BaseNode`. Declaration-only types: no runtime behavior in this file.

**Notes.**

- contract: The estree module augmentation makes `start`/`end` optional on all estree nodes, so code reading `node.start` on plain estree nodes must tolerate `undefined` unless the augmentation is relied upon.

**Uncertainties.**

- `Root.options` is typed `SvelteOptions` (the options-shaped interface) rather than `SvelteOptionsRaw`; the exact relationship between the two interfaces is not shown here.
- `ElementLike` includes `SvelteBoundary` twice, which is legal but may indicate an editing artifact.
- How `DelegatedEvent.hoisted` is decided for an event attribute is not visible in this file.
- `Fragment.metadata.has_await` has no docstring, so its exact semantics are inferred from its name only.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/types/css.d.ts
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/types/template.d.ts
