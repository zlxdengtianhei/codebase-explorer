# Build and repo tooling

**Capability.** Produces package artifacts and development environments: the Rollup UMD build of the compiler, generated type declarations and version files, markdown message-to-module generation for errors/warnings, and the playground sandbox that compiles sample sources for client and server.

Run generate-types/generate-version as part of packaging; process-messages regenerates the error/warning modules from markdown and depends on the client Program transform. The sandbox script cleans and rebuilds output/ via its write/mkdirp helpers. svelte.config.js enables experimental async compilation for this repo.

**Depends on.**

- [Client transform visitors](r2-client-visitors.md) · graph-confirmed · 2 edge(s)

Parent: [Svelte framework](r2-svelte.md)

## Units (10)

<a id="u-ba39a0ffd5bc"></a>
### `rollup-config-js`

`module_region` · [packages/svelte/rollup.config.js:L1-L17][f1]

Defines the single Rollup build for the Svelte compiler, emitting a minified UMD bundle.

The import of './scripts/generate-version.js' runs version generation purely for its side effect at config load time. Entry input is src/compiler/index.js; output goes to compiler/index.js as a UMD module named 'svelte'. The plugin chain resolves node modules, converts CommonJS dependencies, and minifies with terser; no conditions or failure paths are encoded in the file itself.

imports: [./scripts/generate-version.js](../../catalog.json), [rollup](../../catalog.json)

**Uncertainties.**

- Behavior of the version generation side effect lives in scripts/generate-version.js, not supplied here.

<a id="u-a7ff57214266"></a>
### `generate-types.js module code (L1–L85)`

`module_region` · [packages/svelte/scripts/generate-types.js:L1-L85][f2]

Generates the package's TypeScript declarations with dts-buddy and validates the output.

It writes shim .d.ts files (action, animate, easing, motion, store, transition, legacy, index, compiler) that re-export types/index.js for non-'bundler' module resolution, plus legacy types/compiler/preprocess.d.ts and interfaces.d.ts re-exporting ../index.js. It awaits createBundle with stripInternal enabled, paths derived from pkg.imports (value.types, else value.default, else the value itself), and a module map from public package names to source declaration files. After appending a newline it scans the generated text: any JSDoc link target starting with '/' is listed and the script exits 1; a '\texport { ' occurrence triggers an explanatory message about d.ts generation failures and exits 1. All effects are fs writes and process exits.

**Uncertainties.**

- createBundle success depends on dts-buddy and the referenced source files, external to this script
- pkg.imports entry shapes other than {types, default} pass through unvalidated

<a id="u-5c80dbc18b0c"></a>
### `generate-version.js module code (L1–L16)`

`module_region` · [packages/svelte/scripts/generate-version.js:L1-L16][f3]

Writes src/version.js from package.json.

The generated module exports VERSION as the full version string and PUBLIC_VERSION as only the first dot-separated segment (pkg.version.split('.')[0]); no format validation is performed. Reading package.json and writing the file are the only effects.

<a id="u-363f78c18f32"></a>
### `packages/svelte/scripts/process-messages/index.js:transform`

`function transform(name, dest)` · [packages/svelte/scripts/process-messages/index.js:L139-L261][f4]

Transforms one message template file into a generated source module.

It reads the template, parses it with acorn (locations on, comments collected), dedents block comments, and walks the AST replacing any Identifier named CODES with an array literal of the category's message codes. It locates the exported 'function CODE' declaration, throwing 'missing export function CODE in <name>.js' if absent, splices it out, and takes the closest preceding comment as the JSDoc, printing the remaining AST without it. For each message code it extracts %var% names in order of first appearance across that code's message sections, then builds a message expression: a plain literal when no vars are present; otherwise a TemplateLiteral split on %var% with backticks and ${ escaped; and when overloading (prev_vars exists) a ConditionalExpression testing the first newly added variable — if the var count did not grow it throws 'Message overloads must have new parameters'. A second walk clones the CODE function per code: the PARAMETER parameter becomes one Identifier per var (renaming the function to the code), Literal 'CODE' becomes the code, Identifier MESSAGE becomes the message expression, and TemplateLiteral placeholders ${'CODE'} are merged into the raw quasi while ${MESSAGE} splices the message's quasis/expressions; other expressions are visited. The cloned JSDoc replaces the MESSAGE line with the last message and expands PARAMETER into @param entries, optional (string | undefined | null) once past the first overload's var count. Each printed block is appended to the printed output and the clone is pushed back into the AST body; finally the file is written to dest with a do-not-edit header.

**Uncertainties.**

- The jsdoc lookup assumes a block comment precedes the CODE declaration; if none does, jsdoc is undefined and constructing jsdoc_clone would throw

<a id="u-6fdfa0228630"></a>
### `run`

`function run()` · [packages/svelte/scripts/process-messages/index.js:L17-L100][f4]

Reads markdown message definitions, normalizes and sorts them in place, emits generated reference docs, and drives template transformation into the error/warning modules.

It removes and recreates the generated docs directory, then per non-hidden category and .md file parses '## CODE' sections: a duplicate code throws Error('Duplicate message code category/CODE'); trailing non-blockquote paragraphs are popped into details until the last section starts with '> '; if no blockquote sections remain it throws 'No message text'. Blockquote markers are stripped, sections are sorted by code and the source markdown rewritten sorted, and per-category docs are written with a do-not-edit header, fenced message blocks, details, sorted alphabetically. It then calls transform for the seven error/warning targets. At module level run() executes immediately; with '-w' in argv, fs.watch on messages/ reruns it, using a running flag plus a lazily created timeout to coalesce change events occurring during a run. Thrown errors propagate and abort the run.

calls: [packages/svelte/scripts/process-messages/index.js:transform](r2-build-tooling.md#u-363f78c18f32)

<a id="u-7792f9b7775b"></a>
### `mkdirp`

`function mkdirp(dir)` · [playgrounds/sandbox/run.js:L23-L27][f5]

Creates a directory and any missing parents; mkdirSync errors are caught and ignored, so a failed creation never throws.

<a id="u-7e8e16bca8d0"></a>
### `playgrounds/sandbox/run.js:write`

`function write(file, contents)` · [playgrounds/sandbox/run.js:L33-L36][f5]

Writes text contents to a file after first ensuring its parent directory exists via mkdirp, so nested output paths are created on demand.

calls: [mkdirp](r2-build-tooling.md#u-7792f9b7775b)

<a id="u-2eee5a3b7690"></a>
### `run.js module code (L1–L22)`

`module_region` · [playgrounds/sandbox/run.js:L1-L22][f5]

Cleans the sandbox output directory before regeneration.

It parses the --runes boolean flag and computes the script's own directory as cwd, then deletes every entry in output/ except .gitkeep; individual removal failures are swallowed by an empty catch so clearing never aborts the script.

**Uncertainties.**

- Whether removal failures should be silent is not stated; the empty catch only shows errors are intentionally ignored.

<a id="u-64412a345d1b"></a>
### `run.js module code (L36–L136)`

`module_region` · [playgrounds/sandbox/run.js:L36-L136][f5]

Compiles every .svelte and .js file under src/ twice, once for 'client' and once for 'server' generation, writing results into output/.

For each .svelte file it reads the source; for the client pass it also serializes the parse AST to output/ast (bigint values become ['BigInt', string]), runs migrate() into output/migrated (migration errors are warned and skipped), compiles once normally, then again with fragments:'tree' into .tree.js outputs. Each compile's warnings (code and frame) go to stderr; JS, source map, and CSS (when compiled.css exists) are written next to each other with a sourceMappingURL comment. For .js files it uses compileModule and writes only the JS output. Compiles enable experimental async and pass the --runes flag through; a compile error is not caught here and would abort the whole run.

**Notes.**

- failure: Neither compile nor compileModule is wrapped in try/catch in this region, so a compiler throw terminates the script after the earlier passes.

calls: [playgrounds/sandbox/run.js:write](r2-build-tooling.md#u-7e8e16bca8d0), [mkdirp](r2-build-tooling.md#u-7792f9b7775b)

**Uncertainties.**

- Whether the tree-fragment compile failing should stop later files is not shown; there is no local error handling around it.

<a id="u-092720d6382b"></a>
### `svelte.config.js module code (L1–L8)`

`module_region` · [svelte.config.js:L1-L8][f6]

Exports a default Svelte configuration object enabling experimental async compiler support.

The file contains only this literal: an object with compilerOptions.experimental.async set to true, which per the file's comment suppresses editor warnings in VS Code.

**Uncertainties.**

- The runtime effect of experimental.async on the Svelte compiler is not defined in this file; only its presence as a configuration flag is observable.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/rollup.config.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/scripts/generate-types.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/scripts/generate-version.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/scripts/process-messages/index.js
[f5]: ../../../../../../eval/svelte-be645b4/playgrounds/sandbox/run.js
[f6]: ../../../../../../eval/svelte-be645b4/svelte.config.js
