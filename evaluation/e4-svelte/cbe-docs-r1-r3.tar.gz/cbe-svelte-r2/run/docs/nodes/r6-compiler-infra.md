# Compiler Infrastructure

**Capability.** Cross-phase compiler utilities: sourcemap-aware code building via MappedCode (concatenation, map merging, preprocessor map combination, browser-safe path helpers) and svelte-ignore comment parsing/legacy-code migration.

Use MappedCode when combining generated code with accurate mappings, and extract_svelte_ignore for warning-code suppression semantics. Kept apart from the phases that consume it.

**Depended on by.**

- [Compiler Pipeline](r6-compiler.md) · containment · → 0 / ← 0 edge(s) (ancestor direct units and descendant subtree; → follows ` r6-compiler ` → ` r6-compiler-infra `)
- [Semantic Analysis](r6-compiler-analyze.md) · graph-confirmed · 1 edge(s)
- [Preprocessing & Sourcemaps](r1-compiler-preprocess.md) · graph-only · 11 edge(s)

Parent: [Compiler Pipeline](r6-compiler.md)

## Units (18)

<a id="u-3b244745bdc8"></a>
### `MappedCode`

`class MappedCode` · [packages/svelte/src/compiler/utils/mapped_code.js:L75-L90][f1]

Mutable string-plus-decoded-sourcemap pair used to build generated code with accurate mappings, supporting in-place concatenation and construction from raw or preprocessed text.

The constructor stores the string and, absent a map, creates an empty version-3 map with empty mappings/sources/names, so instances are always usable without null-map checks. Preprocessor output accumulates via the static factories and concat while keeping the source map consistent.

group: [MappedCode.concat](r6-compiler-infra.md#u-1bc94121324a), [MappedCode.from_processed](r6-compiler-infra.md#u-55e9f4707897), [MappedCode.from_source](r6-compiler-infra.md#u-60c4a1a9f36f)

<a id="u-389a85833371"></a>
### `apply_preprocessor_sourcemap`

`function apply_preprocessor_sourcemap(filename, svelte_map, preprocessor_map_input)` · [packages/svelte/src/compiler/utils/mapped_code.js:L308-L332][f1]

Combines Svelte's own map with a preprocessor's map for a file, returning the enriched SourceMap.

Returns svelte_map unchanged when either the map or the preprocessor map input is missing. A string input is JSON.parse'd into a map. It delegates to combine_sourcemaps([svelte_map, preprocessor_map]) and then tacks non-enumerable toString (JSON.stringify) and toUrl (base64 data URL via b64enc) properties onto the result, since Svelte expects those SourceMap conveniences without a wrapper class. Parse errors from invalid JSON propagate to the caller.

calls: [combine_sourcemaps](r6-compiler-infra.md#u-6270a2fbedb9)

**Uncertainties.**

- b64enc is module-private and environment-selected (btoa vs Buffer); which branch runs depends on the host.

<a id="u-6270a2fbedb9"></a>
### `combine_sourcemaps`

`export function combine_sourcemaps(filename, sourcemap_list)` · [packages/svelte/src/compiler/utils/mapped_code.js:L265-L300][f1]

Chains a list of source maps into one via @jridgewell/remapping, returning null for an empty list.

Strategy choice: if every map except the last has exactly one source, remapping is called with the array interface (only the oldest map may have multiple sources); otherwise the loader interface is used, where a source named exactly equal to the filename returns the next map in the list (map_idx advancing 1, 2, ...) and anything else returns null, treating it as a leaf source — a brittleness the code itself flags in a TODO, since it depends on filename being a basename. sourcesContent is skipped in both paths. Afterward a falsy map.file is deleted, and when combined sources come out empty (possible when the leading map is empty) sources is set to [filename].

**Uncertainties.**

- The loader-interface equality check assumes preprocessor maps list the input file basename in sources; a full relative path would fail to chain, as the source TODO notes.

<a id="u-10b75c582411"></a>
### `get_basename`

`export function get_basename(filename)` · [packages/svelte/src/compiler/utils/mapped_code.js:L443-L445][f1]

Returns the last / or \ separated segment of a filename, mirroring node's basename without using it, for browser compatibility.

<a id="u-a263794e6dc6"></a>
### `get_relative_path`

`function get_relative_path(from, to)` · [packages/svelte/src/compiler/utils/mapped_code.js:L423-L437][f1]

Computes a '/'-joined relative path from `from` to `to` without node's path utilities, keeping the compiler browser-usable.

Both paths split on / or \; from's last segment is popped to get its dirname. Leading shared segments are shifted off both lists. Remaining from-parts (outside the target directory) are each replaced with '..'. Returns from_parts joined with to_parts; if the paths share the whole dirname, the result is just the to-parts joined.

<a id="u-61dfd78a863b"></a>
### `get_source_name`

`export function get_source_name(filename, output_filename, fallback)` · [packages/svelte/src/compiler/utils/mapped_code.js:L452-L454][f1]

Chooses the name to record for the input source in output maps: when output_filename is set it returns the input filename made relative to the output location via get_relative_path; otherwise it returns the basename of the input filename.

calls: [get_relative_path](r6-compiler-infra.md#u-a263794e6dc6), [get_basename](r6-compiler-infra.md#u-10b75c582411)

<a id="u-e8017193524a"></a>
### `last_line_length`

`function last_line_length(s)` · [packages/svelte/src/compiler/utils/mapped_code.js:L12-L14][f1]

Returns the character count of a string's last line: length minus lastIndexOf('\n') minus 1.

With no newline this yields the full length. Used to compute the column offset when concatenating mapped strings.

<a id="u-a97c97e7b9a7"></a>
### `merge_tables`

`function merge_tables(this_table, other_table)` · [packages/svelte/src/compiler/utils/mapped_code.js:L48-L72][f1]

Merges a second table (sources or names) into a copy of the first, returning the combined table plus an index remap and two change flags.

Each other_table value is looked up with indexOf: existing values map to their old index; missing values are appended and map to the new index, setting val_changed. idx_changed starts as val_changed but is reset to false when idx_map is the identity [0,1,2,...], letting callers skip segment rewriting. A null/undefined other_table is treated as empty.

**Uncertainties.**

- indexOf lookup assumes unique table entries; duplicates would alias to the first occurrence.

<a id="u-58c664c9f3e7"></a>
### `merge_with_preprocessor_map`

`export function merge_with_preprocessor_map(result, options, source_name)` · [packages/svelte/src/compiler/utils/mapped_code.js:L394-L417][f1]

Merges the compiler's result map with the preprocessor map supplied via compile options, doing nothing when options.sourcemap is falsy.

When enabled, it first rewrites result.map.sources to the basename of options.filename so both maps agree on the source name, then applies the preprocessor map through apply_preprocessor_sourcemap and Object.assigns the combined map back onto result.map. If the basename differs from source_name, sources are converted back to paths relative to the input file with get_relative_path, in case the output lives in a different directory.

calls: [apply_preprocessor_sourcemap](r6-compiler-infra.md#u-389a85833371), [get_basename](r6-compiler-infra.md#u-10b75c582411), [get_relative_path](r6-compiler-infra.md#u-a263794e6dc6)

<a id="u-601c351d12f3"></a>
### `parse_attached_sourcemap`

`export function parse_attached_sourcemap(processed, tag_name)` · [packages/svelte/src/compiler/utils/mapped_code.js:L341-L351][f1]

Strips an inline sourceMappingURL comment from preprocessed code and uses it as the processed map.

The comment syntax depends on tag_name: 'script' accepts both //... and /*...*/ forms at the end of the code; 'style' accepts only the /*...*/ form. Inside the replacement, the URL is decoded as a base64 data URI via regex_data_uri. If a data URI is found: when processed.map already exists, a warning is logged (via log_warning, showing the first 100 chars of processed.code to help locate the offending preprocessor) and the attached map is ignored; otherwise processed.map is set to the base64-decoded string. If the URL is a path or non-data URL and processed.map is absent, a warning advises returning map data directly; in all cases the matched comment is removed from processed.code by returning ''. Non-matching code is untouched.

calls: [parse_attached_sourcemap](r6-compiler-infra.md#u-601c351d12f3)

**Uncertainties.**

- b64dec is environment-selected (atob vs Buffer); its failure mode on malformed data is not visible here.
- The graph links the regex construction to Parser.match, which is inconsistent with this file's contents; that edge is not supported by the visible source.

<a id="u-6ba9b18d03ed"></a>
### `sourcemap_add_offset`

`export function sourcemap_add_offset(map, offset, source_index)` · [packages/svelte/src/compiler/utils/mapped_code.js:L22-L40][f1]

Mutates a decoded source map in place, shifting segment source positions by a line/column offset.

Returns immediately when mappings is empty. For each segment it acts only when seg[1] equals source_index, restricting the change to one source file; when the segment's source line is 0 its source column is also shifted by offset.column, otherwise only the source line moves by offset.line. Segments shorter than 4 entries are untouched because the source_index check comes first.

<a id="u-1bc94121324a"></a>
### `MappedCode.concat`

`concat(other)` · [packages/svelte/src/compiler/utils/mapped_code.js:L109-L184][f1]

Concatenates another MappedCode into this one in place and returns this, mutating both operands.

If other.string is empty it is a no-op; if this.string is empty, this adopts other's string and map wholesale. Otherwise the last-line length of this.string is captured before appending, becoming the column offset for other's first mapped line. When other's map has no mappings, only string concatenation occurs. Otherwise sources and names are merged via merge_tables; m1's tables are replaced only when values changed, and other's segments get source/name indices rewritten only when the corresponding index maps are non-identity (three specialized loop variants chosen by the two flags). Finally, when column_offset > 0 all columns of other's first mapping line shift; other's first mapping line is appended to this map's last line, joining at the newline, and the remaining lines are appended. No deep copying: other is left with shifted mappings.

calls: [merge_tables](r6-compiler-infra.md#u-a97c97e7b9a7), [last_line_length](r6-compiler-infra.md#u-e8017193524a), [push_array](r2-compiler-infrastructure.md#u-4f8a7deedb7c)

**Uncertainties.**

- If this.string is non-empty but this.map.mappings is empty, m1.mappings[m1.mappings.length-1] is undefined and push_array would throw; no guard is visible.

<a id="u-5bfe07934570"></a>
### `MappedCode.constructor`

`constructor(string = '', map = null)` · [packages/svelte/src/compiler/utils/mapped_code.js:L90-L102][f1]

Initializes the instance: string defaults to '' and map defaults to a fresh empty decoded map ({version:3, mappings:[], sources:[], names:[]}) whenever the map argument is falsy.

<a id="u-55e9f4707897"></a>
### `MappedCode.from_processed`

`static from_processed(string, map)` · [packages/svelte/src/compiler/utils/mapped_code.js:L192-L209][f1]

Wraps already-processed output into a MappedCode, padding the map so mapping-line count equals generated-line count, since some tools emit fewer lines.

With a supplied map it pushes empty mapping lines for the deficit. Without a map, an empty string yields an empty MappedCode; otherwise a fresh map of one empty mapping line per '\n'-split line is built so unmapped positions stay aligned.

uses: [MappedCode](r6-compiler-infra.md#u-3b244745bdc8)

<a id="u-60c4a1a9f36f"></a>
### `MappedCode.from_source`

`static from_source({ source, file_basename, get_location })` · [packages/svelte/src/compiler/utils/mapped_code.js:L216-L248][f1]

Builds a high-resolution identity map for raw source text, later merged with Svelte's coarser map.

The offset defaults to {line:0, column:0} when get_location(0) returns falsy. The map's sources is [file_basename]; empty source returns immediately with that map. Each newline-split line is tokenized by regex_line_token (non-word punctuation runs or whitespace runs); each non-empty token yields a segment [column, 0, offset.line + line, column] and column advances by the token length, giving per-token resolution. First-line segments have their original column (index 3) shifted by offset.column to honor partial-line offsets.

uses: [MappedCode](r6-compiler-infra.md#u-3b244745bdc8)

<a id="u-725d816e5093"></a>
### `extract-svelte-ignore-js-support`

`group` · [packages/svelte/src/compiler/utils/extract_svelte_ignore.js:L1-L27][f2]

This group covers file-level support in extract_svelte_ignore.js: the `regex_svelte_ignore` pattern matching a leading `svelte-ignore ` (case-sensitive, allowing leading whitespace); the `replacements` table mapping nine legacy kebab-case codes to their new snake_case equivalents; and the `codes` list combining `w.codes` with IGNORABLE_RUNTIME_WARNINGS as the set of recognized ignorable codes.

<a id="u-4a9ee4fb9b67"></a>
### `extract_svelte_ignore`

`export function extract_svelte_ignore(offset, text, runes)` · [packages/svelte/src/compiler/utils/extract_svelte_ignore.js:L28-L82][f2]

Parses `svelte-ignore ` comment contents at the given offset into a list of warning codes, with mode-dependent strictness.

If the text does not start with the `svelte-ignore ` pattern, returns an empty list. In runes mode, codes are comma-separated: each `[

$-]+` match is accepted when it is a known code (warning codes plus IGNORABLE_RUNTIME_WARNINGS); unknown codes are first mapped through the legacy-code replacement table (or hyphens-to-underscores) and reported via `w.legacy_code` when that replacement is known, otherwise reported via `w.unknown_code` with a fuzzymatch suggestion — but the code is not added to the ignores in either error case. Parsing stops at the first match without a trailing comma. In non-runes mode, parsing is lax: every `[

$-]+` token is pushed unconditionally, and additionally its mapped replacement is pushed when the token itself is unknown but its replacement is known, preserving backwards compatibility with legacy codes. Offsets are advanced past the `svelte-ignore ` prefix so reported positions point at each code.

calls: [fuzzymatch](r3-parse-utilities.md#u-4d517976b3f9)

**Uncertainties.**

- Exact sets of `w.codes` and IGNORABLE_RUNTIME_WARNINGS are defined outside this file
- Behavior when a runes-mode match lacks a comma but more text follows (prose handling) is per the break-on-no-comma logic; prose content is never validated

<a id="u-22cdd6c7c71c"></a>
### `migrate_svelte_ignore`

`export function migrate_svelte_ignore(text)` · [packages/svelte/src/compiler/utils/extract_svelte_ignore.js:L89-L104][f2]

Rewrites legacy ignore codes to their modern underscore forms inside `svelte-ignore ` comment text, returning the text unchanged when it does not match the ignore prefix.

After the prefix, each hyphenated code is replaced with its table replacement or hyphens-to-underscores; a trailing comma is appended when hyphenated text continues after the match, preserving separation for subsequent codes.

**Uncertainties.**

- The lookahead via `regex test` on following text can append a comma whenever any hyphenated sequence appears later in the comment, not only immediately after the current code

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/utils/mapped_code.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/utils/extract_svelte_ignore.js
