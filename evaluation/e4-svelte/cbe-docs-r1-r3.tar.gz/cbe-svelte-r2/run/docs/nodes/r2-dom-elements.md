# DOM elements, events and bindings

**Capability.** Client-side DOM work: dynamic-element rendering, delegated and direct event handling with bubbling emulation, hydration event replay, and media element bindings including two-way currentTime/volume state and buffered-range publishing.

Read events.js for delegation semantics (delegate, handle_event_propagation, event, on) and replay_events for SSR hydration. media.js bindings split into two-way binds and event-forwarding range binds built on time_ranges_to_array; element() renders dynamic <svelte:element> tags.

**Depends on.**

- [Component context](r2-component-context.md) · model-inferred · 0 edge(s)
- [Reactivity core](r2-reactivity-core.md) · graph-confirmed · 4 edge(s)
- [Effect Engine](r3-effects-engine.md) · graph-only · 13 edge(s)
- [Element Bindings, Actions, and Custom Elements](r3-element-bindings.md) · graph-only · 11 edge(s)

**Depended on by.**

- [Public authoring API and typings](r2-public-api.md) · model-inferred · 0 edge(s)

Parent: [Client runtime](r2-client-runtime.md)

## Units (16)

<a id="u-165ac079f0d2"></a>
### `packages/svelte/src/internal/client/dom/blocks/svelte-element.js:element`

`export function element(node, get_tag, is_svg, render_fn, get_namespace, location)` · [packages/svelte/src/internal/client/dom/blocks/svelte-element.js:L36-L166][f1]

Renders a dynamic-tag element, switching the created element when the tag changes and managing outro/resume of the previous element's effect.

It captures hydration state and advances past the anchor; if the hydrate node is already an element it adopts it and advances again. Inside an EFFECT_TRANSPARENT block: the namespace comes from get_namespace(), is_svg, or the 'svg' tag defaulting to NAMESPACE_SVG; identical tags return early. The enclosing each item block is temporarily restored (for animate: directives). If an effect exists: a null next tag pauses the effect (clearing effect and current_tag on completion); the same tag as current resumes the effect (aborting the outro); a changed tag destroys it immediately and disables intros. When a new tag differs from current_tag, a branch creates the element (createElementNS/createElement, or the adopted hydrate element), attaches DEV __svelte_meta location info when a location is given, assigns nodes, and for render_fn appends a protective comment before raw-text elements during hydration, picks a child anchor (first child while hydrating, else an appended text node), disables hydrating if there is no child anchor or repositions the hydrate node, and calls render_fn (child_anchor may be undefined for void elements); finally the active effect's nodes_end is set to the element and it is inserted before the anchor. tag/current_tag are updated, intro is re-enabled, and the each item is restored. After setup, hydration state and node are restored so subsequent blocks hydrate correctly.

**Notes.**

- side_effect: set_hydrating(false) inside render_fn setup is undone after the block via set_hydrating(true) and set_hydrate_node(anchor).
- condition: Namespace changes without a tag change are assumed not to occur; only the tag is compared.

calls: [set_current_each_item](r5-runtime-dom.md#u-bde2be852937), [effects.js-effect-creators](r3-effects-engine.md#u-27c9c7c4069f), [pause_effect](r3-effects-engine.md#u-340d218bcd6f), [resume_children](r3-effects-engine.md#u-f5814c70931b), [destroy_effect](r3-effects-engine.md#u-214ad59ce57a)

**Uncertainties.**

- Whether the outro completion callback can fire after a new effect was started (race between pause callback and re-render) is not determinable from this file.

<a id="u-5f07941d0504"></a>
### `bind_buffered`

`export function bind_buffered(media, set)` · [packages/svelte/src/internal/client/dom/elements/bindings/media.js:L64-L82][f2]

Publishes media.buffered as an array of {start, end} ranges on loadedmetadata, progress, timeupdate, and seeking events.

Because TimeRanges is a fresh object per access, the previous snapshot is compared by length and per-range start/end values; set() is called only when the ranges actually changed.

calls: [time_ranges_to_array](r2-dom-elements.md#u-813d089e78b3), [listen](r3-element-bindings.md#u-8f0d8dd6601b)

<a id="u-ff4af77f53b3"></a>
### `bind_current_time`

`export function bind_current_time(media, get, set = get)` · [packages/svelte/src/internal/client/dom/elements/bindings/media.js:L21-L30][f2]

Two-way binds media.currentTime.

A requestAnimationFrame loop (self-rescheduling while not paused) plus a timeupdate listener (covering scrubbing via native controls while paused) push media.currentTime into state whenever it changes, cancelling any pending frame first. A render_effect writes state back: Number(get()) is assigned to media.currentTime only when it differs from the cached value and is not NaN. Teardown cancels the raf frame and removes the timeupdate listener.

calls: [bind_current_time](r2-dom-elements.md#u-ff4af77f53b3)

<a id="u-7fefb5f7789c"></a>
### `bind_muted`

`export function bind_muted(media, get, set = get)` · [packages/svelte/src/internal/client/dom/elements/bindings/media.js:L216-L217][f2]

Two-way binds media.muted.

A callback pushes media.muted into state, running immediately when get() is null and on every volumechange event via listen. A render_effect sets media.muted to Boolean(get()) only when it differs from the element's current muted state.

calls: [listen](r3-element-bindings.md#u-8f0d8dd6601b)

<a id="u-ff3b55389a53"></a>
### `bind_paused`

`export function bind_paused(media, get, set = get)` · [packages/svelte/src/internal/client/dom/elements/bindings/media.js:L158-L161][f2]

Two-way binds media.paused.

An update helper pushes media.paused into state when it differs from the cached value; it is bound to play, pause, and canplay events (canplay catches src swaps that pause playback), with the immediate-call suppressed when the bound value is null. An effect reconciles state to the media: it calls media.pause() when the bound value is true, otherwise media.play(), whose rejection resets the bound value to true; effect wrapping guarantees the element is mounted, avoiding play() interruptions during load.

calls: [bind_paused](r2-dom-elements.md#u-ff3b55389a53)

<a id="u-4820026af89c"></a>
### `bind_playback_rate`

`export function bind_playback_rate(media, get, set = get)` · [packages/svelte/src/internal/client/dom/elements/bindings/media.js:L133-L151][f2]

Two-way binds media.playbackRate, deliberately using effect (not render_effect) so both directions run after the element is mounted, otherwise the browser resets the rate to 1.

The first effect assigns Number(get()) to media.playbackRate when different and not NaN; the second registers a ratechange listener via listen that pushes media.playbackRate back into state.

calls: [listen](r3-element-bindings.md#u-8f0d8dd6601b)

<a id="u-9a0b45d9b402"></a>
### `bind_volume`

`export function bind_volume(media, get, set = get)` · [packages/svelte/src/internal/client/dom/elements/bindings/media.js:L191-L192][f2]

Two-way binds media.volume.

A callback pushes media.volume into state; it runs immediately when get() is null (so an unbound initial value is read from the DOM) and on every volumechange event via listen (immediate-call disabled). A render_effect assigns Number(get()) to media.volume when it differs and is not NaN.

calls: [listen](r3-element-bindings.md#u-8f0d8dd6601b)

<a id="u-813d089e78b3"></a>
### `time_ranges_to_array`

`function time_ranges_to_array(ranges)` · [packages/svelte/src/internal/client/dom/elements/bindings/media.js:L5-L13][f2]

Converts a TimeRanges object into a plain array of {start, end} objects by iterating indices 0..ranges.length-1 and calling ranges.start(i)/ranges.end(i).

<a id="u-27a01e33e57d"></a>
### `media.js-range-binds`

`export function bind_seekable(media, set)` · [packages/svelte/src/internal/client/dom/elements/bindings/media.js:L88-L90][f2]

Groups the media bindings that only forward media element state to a setter on selected events, without a get-side.

bind_seekable pushes time_ranges_to_array(media.seekable) on loadedmetadata; bind_played pushes media.played ranges on timeupdate; bind_seeking pushes media.seeking on seeking/seeked; bind_ended pushes media.ended on timeupdate/ended; bind_ready_state pushes media.readyState on loadedmetadata, loadeddata, canplay, canplaythrough, playing, waiting, and emptied. All use listen, so each fires its handler once immediately (except where defaults apply) and removes listeners at effect teardown.

calls: [time_ranges_to_array](r2-dom-elements.md#u-813d089e78b3), [listen](r3-element-bindings.md#u-8f0d8dd6601b)

<a id="u-132e2aed8e9d"></a>
### `apply`

`export function apply( thunk, element, args, component, loc, has_side_effects = false…` · [packages/svelte/src/internal/client/dom/elements/events.js:L310-L343][f3]

Invokes an event-handler thunk and, in dev, warns when the result is not a function.

The thunk call is wrapped in try/catch, capturing both the handler and any thrown error. When the handler is not a function and (the handler has side effects, or the handler is non-null, or an error was caught), it builds a description with the event name plus capture-phase suffix and a filename:line:column location (or just the filename when no location), warns via w.event_handler_invalid with a suggestion depending on remove_parens ('remove the trailing ()' vs 'add a leading () =>'), and re-throws any caught error. Finally it applies the handler (if callable) to the element with the supplied args.

uses: [events.js module code (L128–L133)][f3]

**Uncertainties.**

- Whether w.event_handler_invalid throws or only logs in different modes is defined in warnings.js, outside this file.

<a id="u-523dfbad5fa3"></a>
### `create_event`

`export function create_event(event_name, dom, handler, options = {})` · [packages/svelte/src/internal/client/dom/elements/events.js:L50-L54][f3]

Registers an event handler on a target with Svelte's propagation semantics.

The inner target_handler invokes handle_event_propagation (bound to the target) unless the listener is a capture listener, and then calls the user handler via without_reactive_context only if the event's cancelBubble is not set. For pointer*, touch, and wheel event names, attachment is deferred via queue_micro_task to work around a Chrome bug with cloned, disconnected elements; other events attach synchronously. Returns target_handler so callers can remove it later.

calls: [handle_event_propagation](r2-dom-elements.md#u-516aca8f7de8), [without_reactive_context](r3-element-bindings.md#u-ff3a57d1f4f9), [queue_micro_task](r6-client-dom-task.md#u-996120ba9b8d)

<a id="u-cf26b665744a"></a>
### `delegate`

`export function delegate(events)` · [packages/svelte/src/internal/client/dom/elements/events.js:L134-L142][f3]

Registers event names as globally delegated by adding each to all_registered_events, and notifies every handle in root_event_handles with the event list so root listeners can be (re)established.

<a id="u-a97020bcbb33"></a>
### `event`

`export function event(event_name, dom, handler, capture, passive)` · [packages/svelte/src/internal/client/dom/elements/events.js:L111-L128][f3]

Registers an event listener with capture/passive options via create_event, and registers a teardown that removes the listener — but only when the target is document.body, window, document, or an HTMLMediaElement (the latter guarded because Firefox can emit stray canplay events after removal).

For other targets no teardown is created in this function.

calls: [effects.js-effect-creators](r3-effects-engine.md#u-27c9c7c4069f), [create_event](r2-dom-elements.md#u-523dfbad5fa3)

<a id="u-516aca8f7de8"></a>
### `handle_event_propagation`

`export function handle_event_propagation(event)` · [packages/svelte/src/internal/client/dom/elements/events.js:L156-L217][f3]

Walks an event's propagation path and invokes delegated handlers stored as '__' + event_name expandas on each element, emulating bubbling for delegated listeners.

It records the event in last_propagated_event (a Firefox GC workaround keeping the __root expando alive). If the event was already handled at a __root that appears in the composedPath and this listener is document/window, it resets __root to this element and returns, preventing nested apps from double-firing; if the handler element is not in the path it returns; otherwise it resumes from the previously handled index. It returns early when the current target is the handler element itself. It proxies event.currentTarget to the walked node via a configurable getter, clears active reaction/effect so handlers run outside reactive contexts, then loops from current_target up through assignedSlot/parentNode/host, calling array-shaped handlers as fn(event, ...data) and plain ones as fn(event), skipping delegated handlers on disabled elements unless the event target is that element. Handler errors are collected: the first is re-thrown synchronously after the loop, the rest are re-thrown one per microtask. Finally, __root is set to the handler element, the currentTarget proxy is deleted, and the previous reaction/effect are restored.

calls: [runtime.js-module-state-setters](r2-reactivity-core.md#u-ac602620d878)

**Uncertainties.**

- Exact interplay of event.__root with the root delegation listeners set up elsewhere is only partially visible in this file.

<a id="u-d8e90951de4c"></a>
### `packages/svelte/src/internal/client/dom/elements/events.js:on`

`export function on(element, type, handler, options = {})` · [packages/svelte/src/internal/client/dom/elements/events.js:L95-L101][f3]

Attaches an event handler via create_event and returns a closure that removes it with removeEventListener using the same type, handler, and options.

This keeps ordering consistent with delegated declarative handlers.

calls: [create_event](r2-dom-elements.md#u-523dfbad5fa3)

<a id="u-25eff3cd7825"></a>
### `replay_events`

`export function replay_events(dom)` · [packages/svelte/src/internal/client/dom/elements/events.js:L26-L42][f3]

Replays load/error events captured by SSR onload/onerror attributes during hydration.

It returns immediately when not hydrating, removes the onload/onerror attributes, reads the stashed event from dom.__e, and if present clears the expando and dispatches the event in a microtask, but only when the element is still connected at that time.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/blocks/svelte-element.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/elements/bindings/media.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/elements/events.js
