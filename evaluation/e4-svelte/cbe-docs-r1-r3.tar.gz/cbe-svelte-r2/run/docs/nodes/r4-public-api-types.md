# Public API Type Surface

**Capability.** The published TypeScript declarations for every svelte subpath entry point: component types, runes ambient declarations, lifecycle/mounting signatures, stores, transitions, animations, attachments, actions, events, easing, reactivity wrappers, server render, legacy interop, and the compiler API.

Use this subtree to check the contract users compile against. Declaration merging is significant (Spring interface vs class, SvelteComponent legacy base vs modern Component). These are types only; the runtime implementations live under runtime/reactivity/motion nodes.

**Depends on.**

- [Compiler Pipeline](r4-compiler.md) · model-inferred · 0 edge(s)
- [Motion Library](r4-motion-library.md) · model-inferred · 0 edge(s)
- [Reactive Built-in Wrappers](r4-reactivity-library.md) · model-inferred · 0 edge(s)
- [Runtime](r4-runtime.md) · model-inferred · 0 edge(s)

Parent: [Svelte Codebase](r4-svelte-codebase.md)

## Units (18)

<a id="u-774be8a3c591"></a>
### `index-d-ts-action-types`

`declare module 'svelte/action' { /** * Actions can return an object containing the tw…` · [packages/svelte/types/index.d.ts:L555-L594][f1]

Types for `svelte/action`: an Action is a function invoked when an element is created, optionally taking a parameter (the parameter argument is optional only when `undefined extends Parameter`), returning void or an ActionReturn whose optional `update` runs on parameter change and `destroy` runs on unmount.

The `$$_attributes` property exists solely for type-checking of extra attributes/events and has no runtime effect. Both the exported and module-local copies in `svelte/attachments` are textually identical declarations.

<a id="u-628e648ed2bb"></a>
### `index-d-ts-animate`

`export function flip(node: Element, { from, to }: { from: DOMRect; to: DOMRect; }, pa…` · [packages/svelte/types/index.d.ts:L649-L652][f1]

`svelte/animate` declares the `flip` function (First-Last-Invert-Play animation between a `from` and `to` DOMRect) returning an AnimationConfig, plus the AnimationConfig and FlipParams option interfaces.

Only signatures are present; the translation computation happens in implementation files not supplied.

<a id="u-8f9ff170256f"></a>
### `index-d-ts-attachments`

`export function createAttachmentKey(): symbol;` · [packages/svelte/types/index.d.ts:L690-L690][f1]

`svelte/attachments` declares the Attachment interface (runs on element mount, optionally returning a teardown function), createAttachmentKey (returns a symbol recognized when the object is spread onto an element), and two overloads of fromAction that convert an action into an attachment.

The overloads differ in arity: one takes a zero-argument action, the other takes an action plus a function returning the action's argument — the JSDoc stresses the second argument must be a getter function, not the value itself. The module also re-declares local ActionReturn/Action types identical to `svelte/action`'s.

**Notes.**

- contract: createAttachmentKey is annotated @since 5.29; fromAction is typed to accept either an Action or a plain function of the same shape.

<a id="u-5b2fe6070c76"></a>
### `index-d-ts-compiler`

`declare module 'svelte/compiler' { import type { SourceMap } from 'magic-string'; imp…` · [packages/svelte/types/index.d.ts:L796-L806][f1]

Signatures for `svelte/compiler`: compile (source + CompileOptions returning CompileResult with js/css/warnings/metadata/ast), compileModule (JavaScript source containing runes), two parse overloads (the `modern: true` overload returns AST.Root; the default `modern?: false` overload returns Record<string, any>, with the doc noting `modern` flips to default-true in Svelte 6), a deprecated walk that types as never and is documented as replaced by `estree-walker`, preprocess (returns a Promise of Processed), and migrate (best-effort runes migration returning { code }, documented as possibly throwing on complex code).

Supporting interfaces (CompileOptions with options like css, runes, fragments, hmr, modernAst; ModuleCompileOptions with generate/dev/warningFilter; CompileResult; AST namespace node interfaces; CSS namespace) are type-only. No implementation is supplied.

**Notes.**

- contract: CompileOptions.extends ModuleCompileOptions; `css` becomes always 'injected' for custom elements, and `fragments` selects between the faster `html` template cloning and the universally safe `tree` strategy.
- failure: The AST namespace types a compile error surface via CompileError extends ICompileDiagnostic, but whether compile throws or returns diagnostics is not determined in this file.

**Uncertainties.**

- Actual compilation/parsing behavior is in source files not provided; only contracts are visible.

<a id="u-5d9d1b986570"></a>
### `index-d-ts-component-interface`

`export interface Component< Props extends Record<string, any> = {}, Exports extends R…` · [packages/svelte/types/index.d.ts:L138-L157][f1]

The modern Svelte 5 `Component` type: a callable interface describing a component function that receives internal Svelte state and props, and returns the component's exports plus optional deprecated $on/$set methods.

It also carries an optional `element` static (custom-element builds) and a type-only `z_$$bindings` marker that explicitly does not exist at runtime. Pure typing contract; no runtime behavior is declared here.

uses: [packages/svelte/types/index.d.ts:Brand][f1]

<a id="u-9023d4c3113a"></a>
### `index-d-ts-easing`

`declare module 'svelte/easing' { export function linear(t: number): number;` · [packages/svelte/types/index.d.ts:L1759-L1760][f1]

Thirty easing function declarations for `svelte/easing` (linear, back/bounce/circ/cubic/elastic/expo/quad/quart/quint/sine in In/Out/InOut variants), each typed as (t: number) => number.

The file declares no bodies, so curve values and out-of-range-t behavior cannot be stated from this source.

**Uncertainties.**

- Numeric output of each easing curve is not visible in this declaration file.

<a id="u-d5039a49c509"></a>
### `index-d-ts-events`

`declare module 'svelte/events' { // Once https://github.com/microsoft/TypeScript/issu…` · [packages/svelte/types/index.d.ts:L2720-L2733][f1]

Five overloads of `svelte/events`' `on`, attaching a handler to window, document, HTMLElement, MediaQueryList, or any EventTarget and returning a remover function.

The JSDoc states the point of using `on` over addEventListener is preserving handler order relative to declarative (delegated) handlers; the window/document/typed overloads bind `this` and narrow the event type via the respective event maps. A comment notes the overloads live outside the JSDoc only because of a pending TypeScript issue.

<a id="u-52372e95c2a1"></a>
### `index-d-ts-legacy`

`declare module 'svelte/legacy' { import type { ComponentConstructorOptions, SvelteCom…` · [packages/svelte/types/index.d.ts:L1825-L1835][f1]

Deprecated `svelte/legacy` compatibility API declarations: createClassComponent (options + component function yielding a Svelte 4-style component merged with Exports) and asClassComponent (inverse conversion to a ComponentType); run (server: immediate single run; client: like $effect.pre); handlers (combines multiple listeners into one EventListener); createBubbler (recreates Svelte 4 automatic event bubbling); and per-modifier substitutes trusted, self, stopPropagation, once, stopImmediatePropagation, preventDefault, plus the action-shaped passive/nonpassive.

LegacyComponentType supports using a component as both class and function during migration. All members are marked @deprecated stop-gaps except LegacyComponentType.

<a id="u-d12e0e97d984"></a>
### `index-d-ts-lifecycle`

`export function getAbortSignal(): AbortSignal;` · [packages/svelte/types/index.d.ts:L374-L374][f1]

Declaration-only signatures for the `svelte` entry point's lifecycle, context, mounting, and scheduling APIs: getAbortSignal, onMount, onDestroy, createEventDispatcher, beforeUpdate, afterUpdate, flushSync, createRawSnippet, getContext/setContext/hasContext/getAllContexts, mount, hydrate, unmount, tick, settled, and untrack.

Each declares a contract documented in JSDoc (e.g. onMount callbacks run once after mount and not during SSR; unmount returns a Promise that resolves after outro transitions when options.outro is true; mount/hydrate options require `props` unless Props is the empty object). No implementations are present in this file, so runtime ordering, error behavior, and SSR differences cannot be verified from this source.

**Notes.**

- contract: MountOptions/hydrate options make `props` optional only when `{} extends Props`; otherwise it is required, expressed through conditional types.
- contract: createEventDispatcher, beforeUpdate, and afterUpdate are declared @deprecated in favor of callback props/$host and $effect/$effect.pre respectively.

**Uncertainties.**

- Runtime semantics (callback timing, promise resolution, SSR behavior) come from JSDoc prose only; the implementations are not in this file.

<a id="u-996a4a357b56"></a>
### `index-d-ts-motion`

`class and the Spring interface are merged into one with some things only // existing …` · [packages/svelte/types/index.d.ts:L1910-L1917][f1]

`svelte/motion` declarations, deliberately split via declaration merging between a legacy Spring interface and the new Spring class: the interface carries the store-style set/update/subscribe and precision/damping/stiffness (update and subscribe are annotated as existing only on the legacy spring store), while the class adds constructor, static Spring.of (must run inside an effect root), set(value, options) returning a Promise that resolves when `current` catches up to `target`, with SpringUpdateOpts.instant short-circuiting and preserveMomentum continuing the trajectory for given milliseconds, plus target/current accessors.

Tween mirrors this shape with TweenedOptions (delay, duration or duration function, easing, custom interpolate) and is the recommended replacement for the deprecated tweened store. The module also re-declares local Readable/Subscriber/Unsubscriber/Updater types and exports the deprecated spring/tweened store factories and a prefersReducedMotion MediaQuery constant. All behavior is contract-level only in this file; a comment notes the merging exists to avoid a breaking rename in Svelte 6.

**Notes.**

- contract: SpringUpdateOpts fields hard/soft apply only to the legacy spring store and do nothing on the Spring class; instant/preserveMomentum apply only to the class and do nothing on the store.

**Uncertainties.**

- Spring physics and tween scheduling are implemented elsewhere; this file only fixes signatures.

<a id="u-fbf369fb74e1"></a>
### `index-d-ts-reactivity`

`class SvelteDate extends Date` · [packages/svelte/types/index.d.ts:L2129-L2164][f1]

`svelte/reactivity` declarations: reactive wrappers SvelteDate, SvelteSet, SvelteMap, SvelteURL, and SvelteURLSearchParams extend their built-ins (SvelteURL's searchParams getter returns SvelteURLSearchParams; SvelteURLSearchParams exposes an internal [REPLACE] method keyed by a module-private unique symbol).

Reading their contents inside effects/derivations re-runs those contexts on mutation, but their values are not deeply reactive per the JSDoc. MediaQuery extends the non-exported ReactiveValue<boolean> base, constructed from a query string with an optional server fallback; the JSDoc warns SSR cannot know the match value, risking hydration-time content change. createSubscriber builds a subscribe function bridging external event systems: start receives an update callback that re-runs dependent effects, its optional teardown runs when all reading effects are destroyed, and start is shared across concurrent effects. ReactiveValue itself is declared with a getter-returning constructor and `current` accessor plus private state.

**Notes.**

- side_effect: Mutation methods like SvelteSet.add and SvelteMap.set are re-declared to trigger reactivity; plain built-in values they contain are not made reactive.

**Uncertainties.**

- The #private fields and actual subscription wiring are not in this declaration file.

<a id="u-811b44947861"></a>
### `index-d-ts-reactivity-window`

`declare module 'svelte/reactivity/window' { /** * scrollX.current is a reactive vie…` · [packages/svelte/types/index.d.ts:L2403-L2456][f1]

`svelte/reactivity/window` exports ReactiveValue-backed constants for window geometry and state (scrollX/scrollY, innerWidth/innerHeight, outerWidth/outerHeight, screenLeft/screenTop, online, devicePixelRatio), all typed `current: number | boolean | undefined` with `undefined` on the server.

screenLeft/screenTop are documented as updated inside requestAnimationFrame callbacks; devicePixelRatio is a plain object getter (not ReactiveValue) whose zoom responsiveness differs by browser. The module privately re-declares the ReactiveValue base class (constructor taking a getter and an onsubscribe update hook, plus a `current` getter) without exporting it.

**Notes.**

- condition: The private ReactiveValue declaration here is structurally separate from the one in 'svelte/reactivity'; both are non-exported classes.

<a id="u-be40d68471e7"></a>
### `index-d-ts-runes`

`declare function $state<T>(initial: T): T;` · [packages/svelte/types/index.d.ts:L3107-L3107][f1]

Ambient declarations of the Svelte 5 runes and their namespaces: $state (value or undefined when called without an argument, with $state.raw for non-deeply-reactive state requiring reassignment and $state.snapshot producing a plain-clone via the recursive Snapshot type), $derived and $derived.by for derived expressions expected to be side-effect free, $effect plus $effect.pre (pre-DOM-update), $effect.pending (count of pending promises in the current boundary, excluding children), $effect.tracking, and $effect.root (manual, non-auto-cleaning scope returning a cleanup function), $props and $props.id (hydration-stable unique id, since 5.20), $bindable, $inspect (returning a `with` callback receiving 'init'/'update' plus values) and $inspect.trace (must be the first statement of a function body), and $host for the enclosing custom element (client-side only).

Each namespace also declares deprecated never-typed constants (apply, arguments, bind, call, caller, length, name, prototype, toString) purely to keep intellisense from suggesting Function.prototype members. These are compile-time rune declarations with no JavaScript bodies here.

**Notes.**

- contract: Snapshot<T> resolves primitives to themselves, Cloneable values to NonReactive counterparts (Date/Map/Set map to their built-in forms; URL is uncloneable), toJSON results, arrays recursively, and indexable objects property-wise; non-indexable objects resolve to never.

<a id="u-575a3a9e7fb8"></a>
### `index-d-ts-server`

`declare module 'svelte/server' { import type { ComponentProps, Component, SvelteCompo…` · [packages/svelte/types/index.d.ts:L2468-L2495][f1]

`svelte/server` declares render, server-only when compiling with the server option, taking a component plus optional options (props with $$slots/$$events omitted, context map, idPrefix) and returning RenderOutput with head, deprecated html, and body HTML strings.

A conditional type makes the options object required with mandatory `props` when Props is non-empty, and optional otherwise; the component argument accepts either a ComponentType (for SvelteComponent subclasses) or the component function itself.

<a id="u-721ac0eff083"></a>
### `index-d-ts-store`

`export function toStore<V>(get: () => V, set: (v: V) => void): Writable<V>;` · [packages/svelte/types/index.d.ts:L2556-L2556][f1]

`svelte/store` declarations: writable/readable factories taking an initial value and optional StartStopNotifier (invoked on first subscribe, may return a cleanup run on last unsubscribe); two derived overloads — one where fn pushes values via set/update and may return an Unsubscriber, one where fn returns the value directly; readonly wrapping a store read-only; get subscribing and immediately unsubscribing to read the current value; toStore overloads (getter+setter yields Writable, getter alone yields Readable); and fromStore overloads converting stores to `{ current }` objects, writable only for Writable input and readonly for Readable input.

Supporting Writable/Readable interfaces and Subscriber/Unsubscriber/Updater/Stores/StoresValues types complete the module. Implementations live elsewhere.

**Notes.**

- contract: StoresValues maps a tuple/array of stores to a tuple of their value types; a single Readable maps to its value type.

<a id="u-7630d8d369fe"></a>
### `index-d-ts-transition`

`export function blur(node: Element, { delay, duration, easing, amount, opacity }?: Bl…` · [packages/svelte/types/index.d.ts:L2677-L2677][f1]

`svelte/transition` declarations: blur, fade, fly, slide, scale, draw, and the crossfade factory, each taking an element plus optional params and returning a TransitionConfig (delay/duration/easing/css/tick).

draw requires an SVGElement with getTotalLength and animates stroke drawing, with duration expressible as a number or a function of path length. crossfade takes CrossfadeParams plus a fallback transition and returns a [send, receive] pair; when a keyed counterpart exists the element is transformed to its partner's position while fading, otherwise the fallback is used. Only signatures are declared here; animation math is elsewhere.

**Notes.**

- condition: The in/out direction semantics (animate from param values to defaults, or reverse) are documented per function in JSDoc.

<a id="u-0a76f8851a0e"></a>
### `public.d.ts-transition-types`

`export type EasingFunction = (t: number) => number;` · [packages/svelte/src/transition/public.d.ts:L1-L1][f2]

Type-only declarations for transitions: `EasingFunction` maps progress `t` to an eased value; `TransitionConfig` describes what a transition function may return (`delay`, `duration`, `easing`, a `css(t, u)` string generator, and an optional `tick` callback); and the parameter interfaces `BlurParams`, `FadeParams`, `FlyParams`, `SlideParams`, `ScaleParams`, `DrawParams`, and `CrossfadeParams` declare the optional options accepted by the built-in transitions (most share delay/duration/easing, with type-specific fields such as axis, start scale, or function-valued durations).

The file re-exports the transition implementations from `./index.js`.

<a id="u-ddcc4fee2b1b"></a>
### `packages/svelte/types/index.d.ts:SvelteComponent`

`class SvelteComponent< Props extends Record<string, any> = Record<string, any>, Event…` · [packages/svelte/types/index.d.ts:L42-L56][f1]

Legacy Svelte 4 component base class kept for typing backwards compatibility only; its constructor and $destroy/$on/$set members exist only through legacy compatibility helpers, not in Svelte 5 components.

Members marked 'type checking only, does not exist at runtime' ($$prop_def, $$events_def, $$slot_def, $$bindings) plus an index signature and an optional static `element` (custom-element build) exist purely in the type layer. $on is typed against the Events map's string keys and returns an unsubscribe function; $set accepts Partial<Props>. All members are @deprecated with a pointer to `mount` and the v5 migration guide.

**Notes.**

- contract: The constructor's props parameter is widened through the `Properties` helper, which adds `children?: any` when the Slots type has a default slot.

uses: [packages/svelte/types/index.d.ts:ComponentConstructorOptions][f1]

**Uncertainties.**

- This is a declaration file; the actual runtime behavior of these members lives in source files not supplied here.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/types/index.d.ts
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/transition/public.d.ts
