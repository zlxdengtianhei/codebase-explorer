# Reactive Built-in Wrappers

**Capability.** User-facing reactive classes that wrap built-ins (SvelteDate, and ReactiveValue backing external signals like MediaQuery), plus their server-side inert counterparts and the test suites that pin their reactivity behavior.

Use this subtree for how reactive wrapper classes work and are verified. SvelteDate patches its prototype once on first construction so Date reads become tracked; ReactiveValue turns a subscribe function into a tracked `current` read; the map/url/url-search-params test groups assert effect re-run semantics. index-server.js supplies the inert server variants.

**Depends on.**

- [Reactive Batch Scheduling](r4-reactivity-scheduling.md) · model-inferred · 0 edge(s)

**Depended on by.**

- [Motion Library](r4-motion-library.md) · model-inferred · 0 edge(s)
- [Public API Type Surface](r4-public-api-types.md) · model-inferred · 0 edge(s)

Parent: [Svelte Codebase](r4-svelte-codebase.md)

## Units (7)

<a id="u-cb648e924acc"></a>
### `SvelteDate`

`class SvelteDate extends Date` · [packages/svelte/src/reactivity/date.js:L42-L51][f1]

A reactive subclass of Date whose time value is a state source; reads through Date getter/toString methods in effects or deriveds re-run when the time changes.

On first construction the class patches SvelteDate.prototype once (module-level `inited` guard): methods named `get*`, `to*`, or `valueOf` become reactive readers, and `set*` methods become writers that update `#time` after delegating to Date. The constructor stores the active reaction at instantiation so lazily created deriveds are computed as if created with the instance. Errors from Date methods propagate unchanged. The class-level `#reaction` field and the `#deriveds` map back this per-instance memoization.

calls: [state](r5-runtime-reactivity.md#u-acd426d0030b), [tracing.js-reactive-tracing](r6-client-dev.md#u-fb7046392fad)

**Uncertainties.**

- `#time` is initialized with `super.getTime()` before `super(...params)` sets a value in the source order shown; the effective initial value relies on class-field initialization running after super() as per language semantics not visible here.

<a id="u-ca8d0a0fef45"></a>
### `SvelteDate.#init`

`#init()` · [packages/svelte/src/reactivity/date.js:L62-L117][f1]

One-time prototype patcher (guarded by the module-level `inited` flag) that replaces Date.prototype method names on SvelteDate.prototype.

For reader methods (names starting with `get` or `to`, or `valueOf`): with any arguments, it reads `#time` for tracking and calls the Date method directly, without memoization. With no arguments, it returns a lazily created per-instance derived (stored in `#deriveds`) that reads `#time` and applies the Date method; the derived is created under the instance's stored `#reaction` via `set_active_reaction`, then the caller's reaction is restored. For writer methods (`set*`), it applies the Date method and then `set`s `#time` to the resulting `getTime()`. Non-get/set/to methods are left untouched.

calls: [runtime.js-module-state-setters](r2-reactivity-core.md#u-ac602620d878), [packages/svelte/src/internal/client/reactivity/sources.js:set](r5-runtime-reactivity.md#u-452914169f68), [packages/svelte/src/internal/client/runtime.js:get](r2-reactivity-core.md#u-98099fbbf12a)

**Uncertainties.**

- The iterator's `next()` targets are ambiguous in the graph (three candidates), but source shows it iterates `Object.getOwnPropertyNames(Date.prototype)`; some Date methods are non-enumerable own properties, so coverage of every method name is unverified.

<a id="u-41cdfeb6fcb9"></a>
### `SvelteDate.constructor`

`constructor(...params)` · [packages/svelte/src/reactivity/date.js:L51-L60][f1]

Delegates all parameters to the Date constructor, tags the `#time` source in DEV, and triggers one-time prototype patching on the first construction.

It performs no parameter validation; invalid Date constructor arguments yield an invalid Date instance as with built-in Date.

calls: [SvelteDate.#init](r4-reactivity-library.md#u-ca8d0a0fef45)

<a id="u-55ae66fdfd50"></a>
### `ReactiveValue`

`class ReactiveValue` · [packages/svelte/src/reactivity/reactive-value.js:L6-L15][f2]

Holds a value-producing function `fn` and a subscribe function built from `createSubscriber(onsubscribe)`; reading `current` first calls the subscribe function (making the read reactive when inside an effect) and then returns `fn()`'s result.

`fn` is re-invoked on each `current` access; no caching or error handling is applied.

calls: [createSubscriber](r3-reactive-primitives.md#u-44838dbc4415)

<a id="u-983ffa06fa59"></a>
### `map-test-ts`

`group` · [packages/svelte/src/reactivity/map.test.ts:L1-L240][f3]

Tests SvelteMap reactivity: effects reading size, has, values, and get re-run on delete/set/clear mutations in the expected order; a set that changes an existing value fires only the value effect, not size; deleting an absent key returns false and does not re-fire; has(2) re-fires when the key is deleted and re-added; forEach passes (value, key, map) and honors thisArg; setting an undefined value then deleting and re-setting works; reading get for an absent key does not create unbounded tracking; and SvelteMap instances pass instanceof Map.

<a id="u-51301b03d805"></a>
### `url.test.ts-svelteurl-reactivity-tests`

`group` · [packages/svelte/src/reactivity/url.test.ts:L1-L120][f4]

Vitest suite for SvelteURL: render effects reading `hash`, `href`, `search`, or `searchParams` accessors re-run under flushSync when the URL changes.

Mutating `searchParams` (append/delete/set) is reflected in `href`/`search` reads, and setting `search` updates `searchParams`; mutating `pathname` does not invalidate hash effects, and hash changes are isolated from path changes. Also asserts `instanceof URL`.

**Uncertainties.**

- SvelteURL's implementation is not included in this batch, so the sync mechanism between URL and searchParams cannot be verified from source here.

<a id="u-a6beb6373335"></a>
### `url-search-params.test.ts-urlsearchparams-reactivity-tests`

`group` · [packages/svelte/src/reactivity/url-search-params.test.ts:L1-L208][f5]

Vitest suite for SvelteURLSearchParams: render effects reading `toString`, `get`, or `getAll` inside an effect_root re-run under flushSync only when contents actually change.

A redundant `set` to the same value produces no re-run; `set` after `append` on the same name is a real change; redundant `delete` of an absent key is a no-op; `get` effects re-run on version changes even for keys they do not read. Also asserts `instanceof URLSearchParams`.

**Uncertainties.**

- Same as the class unit: implementation under test is not in this batch's source for verification.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/reactivity/date.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/reactivity/reactive-value.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/reactivity/map.test.ts
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/reactivity/url.test.ts
[f5]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/reactivity/url-search-params.test.ts
