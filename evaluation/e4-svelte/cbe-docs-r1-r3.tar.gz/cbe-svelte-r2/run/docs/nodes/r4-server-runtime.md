# Server Runtime

**Capability.** Server-side execution support: the public render entry, raw-snippet wrapping, dev-mode element-placement and snippet-argument validation, and the store bridging (toStore/fromStore) and reactivity stubs appropriate for non-reactive rendering.

Use this subtree for SSR behavior. dev.js validates HTML nesting during SSR (push_element/pop_element with print_error); index-server stubs (MediaQuery, createSubscriber) and store/index-server give inert server counterparts to client reactivity.

**Depends on.**

- [Runtime Shared Helpers](r4-runtime-shared.md) · model-inferred · 0 edge(s)

Parent: [Runtime](r4-runtime.md)

## Units (12)

<a id="u-d452e617d953"></a>
### `packages/svelte/src/server/index.d.ts:render`

`export function render< Comp extends SvelteComponent<any> | Component<any>, Props ext…` · [packages/svelte/src/server/index.d.ts:L8-L29][f1]

Type declaration of the server-only render entry: takes a component (wrapped in ComponentType when it is a SvelteComponent) and an options object with optional props (omitting $$slots/$$events), context map, and idPrefix.

When Props is the empty-extent {} the options argument is optional and props may be omitted; otherwise options becomes required with mandatory props. Returns RenderOutput with body and head per its docstring.

**Uncertainties.**

- Declaration only; runtime behavior lives in the implementation module not supplied here.

<a id="u-1ab2344551b5"></a>
### `packages/svelte/src/server/index.js:index.js module code (L1–L1)`

`module_region` · [packages/svelte/src/server/index.js:L1-L1][f2]

Pure re-export forwarding render from the internal server module as the public server entry point.

<a id="u-9b7114ceb220"></a>
### `packages/svelte/src/internal/server/blocks/snippet.js:createRawSnippet`

`export function createRawSnippet(fn)` · [packages/svelte/src/internal/server/blocks/snippet.js:L14-L24][f3]

Wrap a programmatic render function so it behaves like a compiled server snippet.

Returns a closure invoked with (payload, ...args): it converts each argument into a zero-arg getter (freezing the value), calls fn with those getters, trims the `render()` string, and pushes the result onto payload.out. The optional `setup`/cleanup parts of fn's return value are never used here — only `render()` is called; no cleanup or setup side effects occur on the server path. fn's exceptions propagate to the caller of the snippet.

**Notes.**

- contract: Only fn().render() output is emitted; setup() and its returned cleanup are ignored by this server implementation.

<a id="u-c9f93e93e9bd"></a>
### `pop_element`

`export function pop_element()` · [packages/svelte/src/internal/server/dev.js:L92-L94][f4]

Close the current dev element by moving the parent pointer to its parent record; assumes push_element was called first (unchecked cast).

<a id="u-73a0e82a47ce"></a>
### `print_error`

`function print_error(payload, message)` · [packages/svelte/src/internal/server/dev.js:L33-L44][f4]

Report one SSR element-placement violation exactly once per message.

Wraps the message with a fixed 'node_invalid_placement_ssr' prefix explaining hydration risk, deduplicates via a lazily created module-level `seen` Set, logs with console.error, and appends a `<script>console.error(...)</script>` to payload.head.out so the client console shows the same error. Subsequent identical messages are silently skipped.

uses: [dev.js module code (L52–L59)][f4]

<a id="u-4eb759f399d2"></a>
### `push_element`

`export function push_element(payload, tag, line, column)` · [packages/svelte/src/internal/server/dev.js:L60-L90][f4]

Track each element opened during SSR in DEV and validate HTML nesting.

Reads the component filename from current_component.function[FILENAME], builds a record {tag, parent, filename, line, column}, and — when a parent element exists — checks the tag against the parent via is_tag_valid_with_parent and then against each successive ancestor via is_tag_valid_with_ancestor, building the ancestor tag list incrementally. Each failure message (with `file:line:col` locations when filenames exist) goes through print_error, which dedupes. Finally the new record becomes the current parent. With no parent, no validation occurs.

calls: [is_tag_valid_with_parent](r2-compiler-infrastructure.md#u-a93dfa56dc6d), [is_tag_valid_with_ancestor](r2-compiler-infrastructure.md#u-c5a7f2f803ff), [print_error](r4-server-runtime.md#u-73a0e82a47ce)

<a id="u-cc2fd0cc577f"></a>
### `reset_elements`

`export function reset_elements()` · [packages/svelte/src/internal/server/dev.js:L46-L52][f4]

Save and clear the dev element-placement stack, returning a restore closure.

Calling reset_elements sets `parent` to null so a nested render cannot inherit outer elements; the returned function reinstates the saved stack. Used by render's DEV guard.

uses: [push_element](r4-server-runtime.md#u-4eb759f399d2)

<a id="u-75d5182b7c0f"></a>
### `packages/svelte/src/internal/server/dev.js:validate_snippet_args`

`export function validate_snippet_args(payload)` · [packages/svelte/src/internal/server/dev.js:L99-L107][f4]

Assert that a snippet's first argument is a valid payload object.

If payload is not an object or is neither a Payload nor a HeadPayload instance, calls e.invalid_snippet_arguments(), which throws; otherwise returns silently.

uses: [Payload](r1-server-runtime.md#u-88f15d8dfda3), [HeadPayload](r1-server-runtime.md#u-0180f968bb91); raises: [lifecycle_function_unavailable](r1-server-runtime.md#u-af8d810f9167)

<a id="u-2a69132bdb51"></a>
### `packages/svelte/src/store/index-server.js:fromStore`

`export function fromStore(store)` · [packages/svelte/src/store/index-server.js:L84-L87][f5]

Server variant of `fromStore`: returns an object with a `current` getter that simply calls `get(store)` on each access (no caching or subscription, appropriate for non-reactive server rendering).

If the store has a `set`, the object also exposes a `set current` forwarding to `store.set(v)`; writability is again detected by `'set' in store`.

calls: [packages/svelte/src/store/shared/index.js:get](r6-stores.md#u-624938d77758)

**Uncertainties.**

- `'set' in store` may misclassify objects with an unrelated `set` property as writable.

<a id="u-7280df9e1bf0"></a>
### `packages/svelte/src/store/index-server.js:toStore`

`export function toStore(get, set)` · [packages/svelte/src/store/index-server.js:L35-L49][f5]

Server variant of `toStore`: since there is no reactivity on the server, it creates a `writable` seeded once with `get()` and never subscribes to updates.

With a `set` argument it returns a Writable-shaped object (`set`, `update: fn => set(fn(get()))`, `subscribe` from the underlying store); without one, only `subscribe` is returned. Reads of `get()` happen eagerly at call time.

calls: [writable](r6-stores.md#u-dc45d71b793b), [packages/svelte/src/store/shared/index.js:get](r6-stores.md#u-624938d77758)

<a id="u-8fae15838695"></a>
### `MediaQuery`

`class MediaQuery` · [packages/svelte/src/reactivity/index-server.js:L7-L13][f6]

Server-side inert replacement for the client MediaQuery: a `current` field set from the optional `matches` constructor argument, defaulting to false.

It performs no media querying and no reactivity.

<a id="u-0c1b5a22246d"></a>
### `packages/svelte/src/reactivity/index-server.js:createSubscriber`

`export function createSubscriber(_)` · [packages/svelte/src/reactivity/index-server.js:L21-L23][f6]

Server-side no-op stub for createSubscriber: ignores its argument and returns a function that does nothing, so client reactive-subscription logic is absent on the server.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/server/index.d.ts
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/server/index.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/server/blocks/snippet.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/server/dev.js
[f5]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/store/index-server.js
[f6]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/reactivity/index-server.js
