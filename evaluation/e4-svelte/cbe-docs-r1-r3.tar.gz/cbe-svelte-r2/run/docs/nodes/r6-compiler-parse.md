# Template Parsing

**Capability.** Character-driven parser states dispatching fragments, {#block} openings, continuations, closings and @-tags, plus reading script content and binding patterns with optional type annotations into estree nodes.

Trace how raw template text becomes an AST: fragment() dispatches by next character, tag.js handles all brace-delimited syntax, and read/context and read/script produce estree patterns and programs.

**Depends on.**

- [Compiler AST Declarations](r6-compiler-ast-types.md) · model-inferred · 0 edge(s)
- [Template Parsing \(Phase 1\)](r4-template-parsing.md) · graph-only · 16 edge(s)
- [Parse Utilities](r3-parse-utilities.md) · graph-only · 12 edge(s)

Parent: [Compiler Pipeline](r6-compiler.md)

## Units (13)

<a id="u-26ec42ae9fe1"></a>
### `fragment`

`export default function fragment(parser)` · [packages/svelte/src/compiler/phases/1-parse/state/fragment.js:L7-L17][f1]

Dispatcher: returns the next parser state function based on the upcoming character — element state for '<', tag (expression/block) state for '{', otherwise text state.

Performs no parsing itself.

<a id="u-9c915ba5cbbf"></a>
### `tag`

`export default function tag(parser)` · [packages/svelte/src/compiler/phases/1-parse/state/tag.js:L18-L48][f2]

Dispatches the character after an opening `{` in template text to the block/tag parser.

It consumes the `{`, skips whitespace, and routes: `#` to open (blocks), `:` to next (block continuations), `@` to special ({@html}/{@debug}/{@const}/{@render}). If the next characters are `/` but not `/*` or `//` (i.e. not a comment), it consumes the `/` and routes to close. Anything else is parsed as an expression and appended as an ExpressionTag, requiring a closing `}` (parser.eat('}', true) throws if absent).

calls: [open](r6-compiler-parse.md#u-fcd837245062), [next](r6-compiler-parse.md#u-3119a97fbde8), [special](r6-compiler-parse.md#u-4f88ba6dfbca), [close](r6-compiler-parse.md#u-8d9da699a16c), [read_expression](r4-template-parsing.md#u-793d43872467)

**Uncertainties.**

- Whether comment-like `/` sequences fall through to read_expression and how that behaves is not visible here.

<a id="u-8d9da699a16c"></a>
### `close`

`function close(parser)` · [packages/svelte/src/compiler/phases/1-parse/state/tag.js:L556-L624][f2]

Parses `{/...}` closing tags by matching the keyword against the current block type.

IfBlock: if `if` doesn't match, the block is ended (end = start - 1), popped, and close() recurses on the new current block (loose-mode tolerance); otherwise after `}` it walks up popping the stack while block.elseif is true so the whole else-if chain gets the final end index, then pops. EachBlock/KeyBlock/AwaitBlock/SnippetBlock match their keyword; RegularElement matches only in loose parsing mode (otherwise e.block_unexpected_close), and any other block type always raises e.block_unexpected_close. When the keyword doesn't match, the block is closed and popped and close() recurses; when it matches, `}` is required and the block is ended at parser.index and popped.

calls: [close](r6-compiler-parse.md#u-8d9da699a16c)

**Uncertainties.**

- The comment says the non-matching recursion is 'only relevant/reached for loose parsing mode' for RegularElement, but the recursion also runs for block types whose keyword simply doesn't match; whether other modes can reach it is not enforced by visible code.

<a id="u-3119a97fbde8"></a>
### `next`

`function next(parser)` · [packages/svelte/src/compiler/phases/1-parse/state/tag.js:L442-L553][f2]

Parses `{:...}` continuation tags against the block currently on top of parser.stack.

For an IfBlock: `else` is required (e.expected_token otherwise), `else if` is rejected with e.block_invalid_elseif; the previous fragment is popped and the alternate becomes the target. With a following `if`, a test expression is read and a nested IfBlock with elseif: true is appended and pushed, becoming the new fragment; plain `else` just consumes `}`. For an EachBlock: requires `else`, consumes `}`, and creates the fallback fragment. For an AwaitBlock: `then` or `catch` (erroring with e.block_duplicate_clause if the clause already exists); when `}` doesn't immediately follow, whitespace is required and a value/error pattern is read. Any other clause on an AwaitBlock raises e.expected_token, and any other block type raises e.block_invalid_continuation_placement.

calls: [read_pattern](r6-compiler-parse.md#u-eaf948574d56), [read_expression](r4-template-parsing.md#u-793d43872467), [create_fragment](r3-parse-utilities.md#u-6f16c2773335), [create_expression_metadata](r3-scope-node-model.md#u-32bbb434f744)

<a id="u-fcd837245062"></a>
### `open`

`function open(parser)` · [packages/svelte/src/compiler/phases/1-parse/state/tag.js:L51-L137][f2]

Parses `{#if expr}`: reads the test expression, requires a closing `}`, appends an IfBlock (elseif: false, end: -1), pushes it on parser.stack and makes its consequent fragment the current parse target.

No alternate is set here; `{:else}` handling lives in next().

<a id="u-8c0586749f6c"></a>
### `packages/svelte/src/compiler/phases/1-parse/state/tag.js:open`

`function open(parser)` · [packages/svelte/src/compiler/phases/1-parse/state/tag.js:L145-L439][f2]

Handles `each`, `await`, `key`, and `snippet` openings.

Each-branch: reads the iterated expression with retry/backtracking — if read_expression throws, it rewinds to just before the trailing `as` (searching backwards), truncates parser.template to that point and retries, or in loose mode falls back to get_loose_identifier, rethrowing the original error if none of this succeeds. If no `as` follows, a SequenceExpression's first element is used and a trailing TSAsExpression is stripped via the walk visitor (see TSAsExpression unit), rewinding parser.index before the `as`. Then optional `as <pattern>`, `, index` (e.expected_identifier if missing), and `( key )` are read; if the closing `}` doesn't match and the preceding four characters are ' as ', the parser re-reads the context pattern and substitutes an empty-name Identifier as the expression; otherwise it re-runs eat('}', true) to raise the parser error. Appends an EachBlock (metadata null, filled later), pushes stack/fragments. Await-branch: reads the awaited expression, then splits on `then`/`catch` — if immediately followed by `}`, the clause has no pattern; otherwise it requires whitespace and reads a value/error pattern; the unmatched clause becomes the pending fragment. If `}` fails to match and the tail is ' then ' or ' catch ', the pattern is re-read and the expression replaced by an empty Identifier, shifting pending to then/catch; any other tail re-runs eat('}', true) to error. Key-branch: expression then `}` then KeyBlock with its own fragment. Snippet-branch: reads the name (empty string in loose mode, else e.expected_identifier), optionally slices generic type parameters between `<` and its match via match_bracket when parser.ts, balances parentheses for the parameter list, reconstructs parameters by parsing `prelude + params + ' => {}'` with parse_expression_at (or `{ params: [] }` when no parenthesis matched), then appends a SnippetBlock with can_hoist false and an empty sites set.

calls: [read_expression](r4-template-parsing.md#u-793d43872467), [read_pattern](r6-compiler-parse.md#u-eaf948574d56), [get_loose_identifier](r4-template-parsing.md#u-f85dafe8159e), [parse_expression_at](r4-template-parsing.md#u-730e2a662101), [match_bracket](r2-parse.md#u-cf3966ee18ec), [create_fragment](r3-parse-utilities.md#u-6f16c2773335), [create_expression_metadata](r3-scope-node-model.md#u-32bbb434f744)

**Uncertainties.**

- The empty-identifier substitution ('' name) produced in the ' as '/' then '/' catch ' recovery paths is consumed downstream in ways not visible here.
- Behavior when the `(`/`)` parenthesis-balance loop for snippet params hits template end without closing is not explicitly handled in the shown code.

<a id="u-4f88ba6dfbca"></a>
### `special`

`function special(parser)` · [packages/svelte/src/compiler/phases/1-parse/state/tag.js:L627-L759][f2]

Parses `@`-tags following `{`.

`{@html}` reads one expression and appends an HtmlTag. `{@debug}` reads an empty identifier list when the tag is immediately `{@debug}` (matched against a whitespace-then-`}` regex), otherwise reads an expression whose sequence members (or single expression) must all be Identifiers (e.debug_tag_invalid_arguments otherwise) and appends a DebugTag. `{@const}` reads a pattern, requires `=`, reads the initializer, and rejects a SequenceExpression initializer unless a `(` appears in the source between the expression start and the initializer start (allowing `(b, c)` arrow arguments while rejecting `a = b, c = d`) via e.const_tag_invalid_expression; it appends a ConstTag whose declaration spans from `const` to before the closing `}`. `{@render}` reads an expression that must be a CallExpression or a ChainExpression wrapping one (e.render_tag_invalid_expression otherwise) and appends a RenderTag with dynamic false and empty arguments/path/snippets metadata. Note: the const and render branches lack `return`, so after `{@const}` the parser also attempts parser.eat('render') — it fails silently in practice, but the code does not guard against it.

calls: [read_expression](r4-template-parsing.md#u-793d43872467), [read_pattern](r6-compiler-parse.md#u-eaf948574d56), [create_expression_metadata](r3-scope-node-model.md#u-32bbb434f744)

**Uncertainties.**

- Missing return after the ConstTag append means `{@const ...}` falls through to parser.eat('render'); since 'render' cannot match there it is presumed inert, but this fall-through is an observed code shape, not a verified no-op in all inputs.

<a id="u-1671bc4b1103"></a>
### `open.TSAsExpression`

`TSAsExpression(node, context)` · [packages/svelte/src/compiler/phases/1-parse/state/tag.js:L137-L145][f2]

Walk visitor used while stripping a TypeScript assertion erroneously consumed as part of an each expression.

When the visited TSAsExpression ends at the expression's end, it is captured as the assertion, the expression is replaced by its inner expression, and the effective end shrinks to the inner expression's end; otherwise context.next() continues the walk. The caller then rewinds parser.index to just before the matching `as` token so subsequent parsing (e.g. `as item`) starts correctly.

<a id="u-d7f4bd0257df"></a>
### `tag.js module code (L1–L17)`

`module_region` · [packages/svelte/src/compiler/phases/1-parse/state/tag.js:L1-L17][f2]

Module imports and two regex/lookup constants supporting the tag dispatch functions.

<a id="u-f35052d84375"></a>
### `tagjs-open-and-tsassertion-recovery`

`function open(parser)` · [packages/svelte/src/compiler/phases/1-parse/state/tag.js:L51-L137][f2]

Parses `{#...}` block openings.

After backtracking to the real `{`, it branches on the keyword after `#`:

**Notes.**

- side_effect: The each-branch temporarily replaces the readonly parser.template with a truncated copy during expression recovery, then restores it.
- failure: open ends with e.expected_block_type(parser.index) when no known keyword matches.

**Uncertainties.**

- The exact text of the TSAsExpression visitor lines (137–145) is the walk handler shown inside the each branch; the separate inventory entry is treated as that handler.

<a id="u-eaf948574d56"></a>
### `read_pattern`

`export default function read_pattern(parser)` · [packages/svelte/src/compiler/phases/1-parse/read/context.js:L14-L79][f3]

Reads a destructuring-ish binding pattern in an each-loop context, producing an estree Pattern.

It first tries a plain identifier; if parser.read_identifier yields a name it attaches a type annotation and location data and returns an Identifier. Otherwise the next character must be '{' or '[' or e.expected_pattern throws. It consumes the matched bracket via match_bracket, then tricks Acorn by parsing '<spaces>(pattern = 1)' (rewritten so columns stay correct, removing the first space to offset the inserted '(') and takes .left as the pattern. The annotation is re-read afterwards; if present the pattern's end is extended to it. Parse failures propagate to parser.acorn_error, which itself throws, so the trailing implicit return is unreachable in practice.

**Notes.**

- side_effect: Mutates parser.index both to the matched bracket end and to the type-annotation end.
- failure: Any Acorn error is funneled through parser.acorn_error rather than returned.

calls: [read_type_annotation](r6-compiler-parse.md#u-e32a5aa85acf), [parse_expression_at](r4-template-parsing.md#u-730e2a662101)

**Uncertainties.**

- Behavior of parser.acorn_error (throw vs recover) is not visible in this file; the fallthrough return is untyped/unreachable in the shown source.

<a id="u-e32a5aa85acf"></a>
### `read_type_annotation`

`function read_type_annotation(parser)` · [packages/svelte/src/compiler/phases/1-parse/read/context.js:L85-L125][f3]

Parses an optional TypeScript-style ': Type' annotation at the current position, restoring parser.index and returning undefined if the ':' is absent.

To parse the type it rewrites the template: everything before the annotation is blanked to spaces and '_ as ' is spliced in, and '?:' sequences later in the file are rewritten to ':' so Acorn-TS does not misread subsequent function parameters as sequence expressions. If Acorn returns an AssignmentExpression (e.g. 'foo: bar = baz'), it rewinds to the '=' and reparses the truncated source; if it returns a SequenceExpression (trailing parameters mistaken as a sequence), it keeps only the first expression. Returns a synthetic TSTypeAnnotation node spanning from before the whitespace to expression.end, and moves parser.index to that end.

calls: [parse_expression_at](r4-template-parsing.md#u-730e2a662101)

**Uncertainties.**

- Whether parse_expression_at can throw here and how that error surfaces is not handled in this function's source.

<a id="u-086699ac3458"></a>
### `read_script`

`export function read_script(parser, start, attributes)` · [packages/svelte/src/compiler/phases/1-parse/read/script.js:L22-L90][f4]

Reads the body of a <script> element into an estree Program wrapped in an AST.Script node.

It captures everything up to a closing </script> tag; if end-of-file is reached first, e.element_unclosed fires. To preserve line/column positions the pre-script template prefix is blanked to spaces (newlines kept) and prepended to the script source before acorn.parse; parse errors are rethrown via parser.acorn_error. Each attribute is then validated: reserved names (server, client, worker, test, default) error, unknown names warn; 'module' must be a shorthand attribute and sets context to 'module'; 'context' must be a text attribute with value 'module' or errors. context defaults to 'default'. Returns the node with the element start, current end, context, parsed content, and the original attributes array.

**Notes.**

- side_effect: parser.index is advanced past the closing script tag by parser.read before attribute validation.
- failure: acorn.parse failures become parser.acorn_error, which propagates; attribute errors are raised after parsing succeeds.

uses: [is_text_attribute](r5-compiler-utilities.md#u-ec400088cae5)

**Uncertainties.**

- The closing-tag regex allows trailing whitespace (</script\s*>); whether the parser tolerates anything else about the closing tag is not shown.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/1-parse/state/fragment.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/1-parse/state/tag.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/1-parse/read/context.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/1-parse/read/script.js
