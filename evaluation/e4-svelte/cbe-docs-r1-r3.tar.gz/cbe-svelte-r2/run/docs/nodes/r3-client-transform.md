# Client Transform

**Capability.** Generates client-side code: assignment and identifier rewriting into reactive writes, block serialization ($.if, snippets), dynamic elements, and shared builders for attribute effects, class, and style updates.

Consult this subtree when generated client output looks wrong for assignments, identifiers, if-blocks, snippets, or svelte:element. The shared/element builders are the common vocabulary for emitting reactive attribute updates.

**Depends on.**

- [Scope and Node Model](r3-scope-node-model.md) · graph-confirmed · 9 edge(s)
- [Server Transform](r3-server-transform.md) · model-inferred · 0 edge(s)
- [Client Transform](r5-client-transform.md) · graph-only · 15 edge(s)

**Depended on by.**

- [Client transform visitors](r2-client-visitors.md) · graph-only · 10 edge(s)

Parent: [Code Generation Transforms](r3-code-generation-transform.md)

## Units (13)

<a id="u-180b0678e181"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/AssignmentExpression.js:AssignmentExpression`

`export function AssignmentExpression(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/AssignmentExpression.js:L21-L27][f1]

Transforms assignment expressions by delegating to the shared assignment walker with this module's build_assignment, falling back to default traversal when no rewrite applies, then wrapping the result in mutation validation.

`visit_assignment_expression(node, context, build_assignment)` returns the rewritten expression or null; on null the original node's children are visited via `context.next()`. The resulting expression is passed to `validate_mutation`, which (implemented elsewhere) may reject or adjust invalid mutations.

calls: [visit_assignment_expression](r1-compiler-transform-shared.md#u-b43a982ab161), [validate_mutation](r5-client-transform.md#u-a58215b09609), [build_assignment](r3-client-transform.md#u-446b598656ff)

**Uncertainties.**

- validate_mutation's acceptance/rejection conditions are implemented outside this file

<a id="u-446b598656ff"></a>
### `build_assignment`

`function build_assignment(operator, left, right, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/AssignmentExpression.js:L54-L224][f1]

Rewrites one assignment into runtime helper calls or binding transforms, returning null when default traversal should apply.

In runes mode with a MemberExpression target it first matches class state fields: for the constructor declaration itself (`this.#x = $state(...)` shape, when left === field.node.left), it inspects the rune on the right; if present it visits the value with `in_constructor` false for `$derived`/`$derived.by`, wraps it in `$.tag` under dev with `<Class>.<name>`, and returns `this.<field.key> = value`. For any other assignment to a PrivateIdentifier property it visits `build_assignment_value(operator, left, right)` and returns `$.set(left, value, needsProxy)`, where needsProxy is true only for `$state` fields, non-coercive operators, and when `should_proxy(value, scope)` accepts. Otherwise it reduces the target to its base object; a non-identifier base, missing binding, or missing transform yields null. When the whole left side is the identifier and `transform.assign` exists, it visits the assignment value and calls `transform.assign`, passing a proxy flag false when the path is a `bind:` on a RegularElement, or for `prop`/`bindable_prop`/`raw_state`/`derived`/`store_sub` bindings, or when not in runes mode, or when `should_proxy(right)` fails, or for coercive operators. If only `transform.mutate` exists it wraps a fully visited assignment via `transform.mutate`. For dev-mode member mutations outside ExpressionStatements with non-coercive operators it plans a `$.assign`/`$.assign_and`/`$.assign_or`/`$.assign_nullish` call (object, key or name literal, right, source location) so late proxification can be warned about; this is suppressed when the assignment appears in an event-handler arrow matched to an element's event attribute, in `BindDirective`/`Component`/`SvelteComponent` paths, or in the getter/setter sequence form of `bind:prop`. If still planned, the helper call is visited and returned; otherwise null.

calls: [get_name](r3-scope-node-model.md#u-99af92983a86), [get_rune](r3-scope-node-model.md#u-5204b6ce4f7a), [build_assignment_value](r5-compiler-utilities.md#u-634ffef5ceee), [should_proxy](r2-client-signal-builders.md#u-d089d4da67c8), [state.js-module-level-compiler-state](r2-compiler-infrastructure.md#u-d73d7b033038), [get_attribute_expression](r5-compiler-utilities.md#u-96e6f6d66786), [is_event_attribute](r5-compiler-utilities.md#u-1c2da82112be)

**Uncertainties.**

- The contracts of transform.assign/transform.mutate callbacks (return shape, proxy-flag semantics) are defined where transforms are created, not here
- context.visit dispatch behavior is external to this file

<a id="u-3f1e690f4129"></a>
### `is_non_coercive_operator`

`function is_non_coercive_operator(operator)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/AssignmentExpression.js:L35-L37][f1]

Reports whether an assignment operator writes without coercing the previous value: `=`, `||=`, `&&=`, `??=` count as non-coercive; compound operators like `+=` do not.

Callers use this to decide whether the assigned value may need proxying.

<a id="u-33e650400bd4"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/Identifier.js:Identifier`

`export function Identifier(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/Identifier.js:L11-L41][f2]

Rewrites identifier references to props.

For non-references it returns undefined (no replacement). `$$props` references become `$$sanitized_props`. In runes mode, when the binding is a rest_prop that is not the declaration site itself and the identifier is a non-computed member-read object not targeted by an enclosing assignment or update expression, it returns `$$props` directly to avoid proxy overhead. All other references fall through to build_getter, which produces the appropriate reactive read expression.

calls: [build_getter](r2-client-signal-builders.md#u-66a19e20e1f1)

**Uncertainties.**

- The exact expression build_getter returns is defined outside this file.

<a id="u-c4e00e5384f2"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/IfBlock.js:IfBlock`

`export function IfBlock(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/IfBlock.js:L11-L88][f3]

Serializes {#if} blocks into a `$.if` runtime call.

Consequent and (when present) alternate fragments are visited and hoisted into generated `consequent`/`alternate` arrow constants taking `$$anchor`. build_expression builds the test; when it has await the in-render test becomes `$.get($$condition)`. The render callback calls `$$render(consequent_id)` on truth and `$$render(alternate_id, false)` otherwise. For `{:else if}` chains (node.elseif), a `true` argument is appended so transitions inside count as local to both conditions, unlike a nested {#if} where they are local only to the inner condition. Without await, the statements are pushed to init as a block; with await, init receives `$.async(node, [thunk(expression, true)], (node, $$condition) => statements)`.

calls: [build_expression](r5-client-transform.md#u-cd5eb51d389f), [add_svelte_meta](r5-client-transform.md#u-75700db42066)

<a id="u-ab4813441bd1"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/SnippetBlock.js:SnippetBlock`

`export function SnippetBlock(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/SnippetBlock.js:L13-L100][f4]

Serializes {#snippet} blocks into a const-bound function.

Parameters after `$$anchor` become assignment patterns defaulting to `$.noop` for plain identifiers (transform read: b.call), or `$$arg<i>` aliases for destructuring patterns; extract_paths yields inserts (each renamed to a generated `$$array` id, declared as `$.derived` of the visited default and read via get_value) and paths (declared as thunks, or `$.derived_safe_equal` when they have default values so the default evaluates once, with read accordingly get_value or b.call; in dev each is eagerly read to surface before-initialization errors). The visited body is preceded by declarations and, in dev, a `$.validate_snippet_args(...arguments)` check. In dev the snippet is `$.wrap_snippet(componentName, function(...args){...})` — a FunctionExpression so `arguments` works — otherwise a plain arrow. Top-level snippets are hoisted into module_level_snippets when can_hoist, else instance_level_snippets; nested snippets are pushed to state.init.

calls: [extract_paths](r5-compiler-utilities.md#u-34f2fcb20c62); uses: [Scope](r3-scope-node-model.md#u-01a82e58170d)

**Uncertainties.**

- Whether `has_await` on the body affects the emitted function beyond the async flag passed to b.function/b.arrow depends on those builders.

<a id="u-0676455245be"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/SvelteComponent.js:SvelteComponent`

`export function SvelteComponent(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/SvelteComponent.js:L9-L12][f5]

Compiles <svelte:component> by delegating to build_component with the synthetic name '$$component', then pushes the resulting declaration into state.init.

calls: [component.js-build-component](r1-compiler-transform-client.md#u-ea683dd1d72c)

<a id="u-fa257fa55ed4"></a>
### `packages/svelte/src/compiler/phases/3-transform/client/visitors/SvelteElement.js:SvelteElement`

`export function SvelteElement(node, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/SvelteElement.js:L19-L156][f6]

Lowers a `<svelte:x>` dynamic element into a `$.element` call, pushing a template comment and building the element body in a temporary context so init/update statements become the render function parameter.

Attributes are classified: `xmlns` (non-text) is kept as a dynamic namespace; plain and spread attributes go to the attribute list; class/style directives are collected; `let:` directives are visited in the outer context producing statements; `on:` handlers are visited in the inner context and pushed to after_update; anything else is visited in the inner context. When there is exactly one static class attribute, `build_set_class` handles it; otherwise any attributes go through `build_attribute_effect` as a spread so the runtime decides how to set them (custom-element safe). The tag expression is visited and thunked (or wrapped in `$.get($$tag)` under await); inner statements get the render effect when updates exist, then after_update, then the fragment visited with a child-specific namespace. In dev, `$.validate_void_dynamic_element` (when the fragment is non-empty) and `$.validate_dynamic_element_tag` are emitted, plus a line/column location array from `locator(node.start)`. Finally `$.element` receives the anchor, tag thunk, svg/mathml flag, optional render arrow, optional namespace thunk, and optional location; under await the statements are wrapped in `$.async`, else pushed to init as a single statement or block.

calls: [build_attribute_effect](r3-client-transform.md#u-0abd8487f7a1), [build_attribute_value](r3-client-transform.md#u-2462157783c9), [build_set_class](r3-client-transform.md#u-d08767f6fc10), [build_render_statement](r5-client-transform.md#u-b84b76b77b0e), [determine_namespace_for_children](r2-transform-shared.md#u-fca641f4927b), [Scope](r3-scope-node-model.md#u-01a82e58170d), [is_text_attribute](r5-compiler-utilities.md#u-ec400088cae5)

**Uncertainties.**

- locator's return shape (line/column) comes from state.js and is not shown
- the runtime contract of $.element's optional arguments is defined in the internal client, not here

<a id="u-0abd8487f7a1"></a>
### `build_attribute_effect`

`export function build_attribute_effect( attributes, class_directives, style_directive…` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/element.js:L20-L98][f7]

Emits a `$.attribute_effect` call that reactively updates an element's attributes.

Each Attribute contributes an init property whose value comes from build_attribute_value with memoization for call/await expressions; event-handler attributes whose value is a function literal get a scope-generated stable id hoisted into `init` so updates do not remove and re-add the listener. Non-Attribute entries (spreads) become spread properties, memoized when they call or await. Class and style directives contribute `$.CLASS`/`$.STYLE` keyed properties built via build_class_directives_object/build_style_directives_object. After memoizer.apply() fills ids, the pushed statement passes the arrow over the values object plus sync and async value arrays; the scoped-css hash literal and the `hydration_attribute_changed` true flag are each appended only when their guard (element.metadata.scoped with non-empty hash; is_ignored) holds, otherwise `false`-equivalent operands are passed.

calls: [build_attribute_value](r3-client-transform.md#u-2462157783c9), [build_class_directives_object](r2-client-visitors.md#u-93d4778b5497), [build_style_directives_object](r2-client-visitors.md#u-29f008b00f20), [state.js-module-level-compiler-state](r2-compiler-infrastructure.md#u-d73d7b033038); uses: [Memoizer](r5-client-transform.md#u-76b08484949a), [is_event_attribute](r5-compiler-utilities.md#u-1c2da82112be)

**Uncertainties.**

- build_class_directives_object and build_style_directives_object bodies are outside this file; their exact returned shape is inferred from usage

<a id="u-2462157783c9"></a>
### `build_attribute_value`

`export function build_attribute_value(value, context, memoize = (value) => value)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/element.js:L106-L127][f7]

Normalizes an attribute's AST value into a runtime expression plus a has_state flag.

A `true` value (boolean attribute) returns `true` with no state. A single Text chunk becomes a string literal, static. A single ExpressionTag is transformed via build_expression, passed through the caller's memoize callback, and is stateful when the expression has state or await. Multi-chunk values delegate to build_template_chunk with the same memoize callback, so the caller's memoization policy applies to templated values too.

calls: [build_expression](r5-client-transform.md#u-cd5eb51d389f), [build_template_chunk](r5-client-transform.md#u-d8d503fc4b7b)

<a id="u-d08767f6fc10"></a>
### `build_set_class`

`export function build_set_class(element, node_id, attribute, class_directives, contex…` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/element.js:L149-L217][f7]

Emits a `$.set_class` statement (or assignment to a tracked variable) that applies the class attribute plus class directives to an element.

The attribute value is built via build_attribute_value; the memoize callback wraps values in `$.clsx` when attribute.metadata.needs_clsx and memoizes via context.state.memoizer on call/await. When class directives exist, their object is built with build_class_directives_object; has_state is widened to include directive state/await, and if stateful a generated `let classes` variable is declared in init, threaded as `prev`, and the final statement becomes an assignment back into it. Scoped css hash handling: an empty/null literal value becomes just the hash; a string literal is escaped with escape_html and suffixed with the hash; any other value keeps the hash as a separate `css_hash` argument. The is_html flag selects literal 1 vs 0 in the call. The statement is pushed to update when stateful, otherwise to init.

calls: [build_attribute_value](r3-client-transform.md#u-2462157783c9), [build_class_directives_object](r2-client-visitors.md#u-93d4778b5497), [escape_html](r2-server-render.md#u-0f499dd45547)

**Uncertainties.**

- The runtime contract of $.set_class's numeric is_html flag and prev/next objects is not visible here

<a id="u-b481933571c2"></a>
### `build_set_style`

`export function build_set_style(node_id, attribute, style_directives, context)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/element.js:L225-L262][f7]

Emits a `$.set_style` statement applying the style attribute plus style directives.

The value is built via build_attribute_value, memoized through context.state.memoizer when metadata.has_call; note the callback passes has_await as the Memoizer's has_await argument, so await-only values are also routed to memoization here. When style directives exist, build_style_directives_object supplies `next`; has_state widens to include directive state/await, and stateful cases declare a generated `let styles` variable, pass it as `prev`, and wrap the call in an assignment storing the result back. The statement lands in update when stateful, init otherwise.

**Notes.**

- condition: The memoize callback tests metadata.has_call but forwards metadata.has_await to memoizer.add, so await-only values are memoized despite the guard naming only has_call.

calls: [build_attribute_value](r3-client-transform.md#u-2462157783c9), [build_style_directives_object](r2-client-visitors.md#u-29f008b00f20)

<a id="u-794bd7468f40"></a>
### `get_attribute_name`

`export function get_attribute_name(element, attribute)` · [packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/element.js:L133-L139][f7]

Returns the attribute name normalized for HTML (normalize_attribute), but keeps the original name unchanged for svg and mathml elements where casing matters.

calls: [utils.js-element-attribute-predicates](r5-compiler-utilities.md#u-57e79fafa2c2)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/AssignmentExpression.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/Identifier.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/IfBlock.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/SnippetBlock.js
[f5]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/SvelteComponent.js
[f6]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/SvelteElement.js
[f7]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/element.js
