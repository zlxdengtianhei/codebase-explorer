# Svelte Monorepo

**Capability.** Umbrella for the Svelte compiler, client runtime, reactive built-ins, codegen tooling, benchmarks and playground scripts, grouped by responsibility rather than directory layout.

Root navigation node. Compiler work lives under compiler-pipeline, svelte-migration and compiler-utilities; runtime behavior under runtime-reactivity and runtime-dom; reactive built-ins, animation, warning tooling, benchmarks and playground scripts are sibling leaves.

**Children.**

- [Compiler Public API and Pipeline](r5-compiler-pipeline.md) `r5-compiler-pipeline` · 8 unit(s)
- [Svelte 4 to 5 Migration](r5-svelte-migration.md) `r5-svelte-migration` · 27 unit(s)
- [Compiler Utilities and AST Helpers](r5-compiler-utilities.md) `r5-compiler-utilities` · 23 unit(s)
- [Client Runtime Reactivity](r5-runtime-reactivity.md) `r5-runtime-reactivity` · 67 unit(s)
- [Client Runtime DOM](r5-runtime-dom.md) `r5-runtime-dom` · 29 unit(s)
- [Reactive Built-ins](r5-reactive-builtins.md) `r5-reactive-builtins` · 6 unit(s)
- [Animation Helpers](r5-animation-helpers.md) `r5-animation-helpers` · 2 unit(s)
- [Warning Codegen Template](r5-warnings-codegen.md) `r5-warnings-codegen` · 3 unit(s)
- [Reactivity and SSR Benchmarks](r5-benchmarks.md) `r5-benchmarks` · 5 unit(s)
- [Playground Sandbox](r5-playground-sandbox.md) `r5-playground-sandbox` · 5 unit(s)

Parent: [Compiler Pipeline and Migration](compiler-and-migration.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
