# Diagnostics, state and validation infrastructure

**Capability.** Cross-cutting compiler services: module-level compilation state, compiler-option validation, generated warning emitters over a deduplicating sink, diagnostic/code-frame formatting, small shared utils, and HTML tree validation tables backing template warnings.

Consult state.js and validate-options.js for how compilation state and options are managed, warnings.js for how warning codes are emitted, and CompileDiagnostic plus its code-frame helpers for how errors are presented. html-tree-validation powers invalid-nesting warnings.

**Depends on.**

- [Template parser](r2-parse.md) · model-inferred · 0 edge(s)

**Depended on by.**

- [Client transform visitors](r2-client-visitors.md) · graph-confirmed · 1 edge(s)

Parent: [Compiler](r2-compiler.md)

## Units (15)

<a id="u-4c4cd0899c53"></a>
### `compile-diagnostic-js-module-region`

`function tabs_to_spaces(str)` · [packages/svelte/src/compiler/utils/compile_diagnostic.js:L9-L11][f1]

This group covers the CompileDiagnostic module's file-level support code: the `regex_tabs` pattern, `tabs_to_spaces` (replaces each leading tab run with two spaces per tab, used to align code frames that mix tabs and spaces), and `get_code_frame(source, line, column)` (formats a snippet of two lines before through three after the given zero-based line; each line is prefixed with its right-aligned 1-based number and colon, tabs expanded to spaces, and the error line additionally gets a following line with a `^` marker positioned under the column after tab expansion).

<a id="u-d73d7b033038"></a>
### `state.js-module-level-compiler-state`

`export function set_source(value)` · [packages/svelte/src/compiler/state.js:L46-L49][f2]

Group the compiler's mutable module-level state and its lifecycle helpers.

Exported mutable bindings include `warnings`, `filename`, `component_name` (default `'<unknown>'`), `source`, `dev`, `runes`, a `locator` from locate-character, `warning_filter`, `ignore_stack` (array of Sets of ignorable warning codes), and `ignore_map` (Map from node to arrays of Sets of codes, for warnings emitted outside the stack-building window). `set_source` stores the source and rebuilds the locator with `offsetLine: 1`. `locate_node` resolves a node's `start` offset through the current locator and returns `<filename>:<line>:<column>` with the filename sanitized; if the locator returns undefined, the template renders 'undefined' line/column values. `push_ignore` pushes a new Set merging the current top-of-stack ignores with the given ones; `pop_ignore` pops the stack. `is_ignored(node, code)` returns true only when `dev` is true AND `ignore_map` has an entry for the node whose set arrays contain a set holding that code. `reset` is called before each compilation: it sets dev/runes false, component_name to UNKNOWN_FILENAME, source to '', replaces the locator with a no-op returning undefined, normalizes backslashes in the filename (defaulting to UNKNOWN_FILENAME), sets warning_filter to the given filter or always-true, and clears warnings. `adjust` runs after parse/basic analysis: it stores dev, runes, and component_name, and if a rootDir is given (backslashes normalized) and the filename starts with it, rewrites filename relative to that root stripping a leading slash; it then clears the ignore stack and map.

**Notes.**

- side_effect: All state is module-scoped mutable state shared across compilations; concurrent or reentrant compilations would overwrite each other's settings.

calls: [sanitize_location](r5-compiler-utilities.md#u-eb8e19f29107)

**Uncertainties.**

- Whether reset's temporary no-op locator returning undefined is relied upon by callers between reset and set_source is not visible here.
- UNKNOWN_FILENAME is used as component_name default in reset, though the constant's declared purpose is fallback filenames; the mismatch is observable in the source.

<a id="u-e5a40c95c787"></a>
### `validate-options.js-compiler-option-validators`

`function removed(msg)` · [packages/svelte/src/compiler/validate-options.js:L172-L179][f3]

Group the compiler-options validation module: two public validators, `validate_component_options` and `validate_module_options`, are built by the `object` combinator over shared and per-kind option specs, and return functions that walk an input options object and produce a fully populated validated object.

`object(children, allow_unknown)` rejects non-object or array inputs via throw_error; unknown keys raise `e.options_unrecognised` unless `allow_unknown`, then runs each child validator with dot-joined keypaths, always writing every child key into the output (so validated output includes defaults). `validator(fallback, fn)` applies `fn` unless input is undefined, in which case the fallback is returned. `string` requires a string when specified (optionally rejecting empty); `boolean` requires true/false; `list(options)` requires membership, formatting a one-of/either message; `fun` requires a function. `removed(msg)` throws whenever the option is set; `warn_removed(fn)` warns once when set and yields undefined; `deprecate(fn, validator)` warns once then delegates; `warn_once` deduplicates via a module-level Set keyed by the warning function. Notable option behaviors: `generate` maps deprecated 'dom'/'ssr' to 'client'/'server' with a rename warning, accepts 'client', 'server', or false, and throws otherwise; `css` throws for booleans, 'none', and anything but 'external'/'injected'; `rootDir` defaults to `process.cwd?.()` or Deno's cwd depending on runtime; `sourcemap` passes any value through unchecked; several removed options (legacy, format, tag, sveltePath, errorMode, varsReport) throw with migration messages. `validate_module_options` uses the common options but replaces every component option with a no-op validator, so module compilation silently accepts-and-ignores component keys rather than rejecting them. `throw_error` delegates to `e.options_invalid_value`. Errors thrown during validation propagate to callers of compile/compileModule.

**Notes.**

- side_effect: warn_once mutates a module-level `warned` Set, so deprecation warnings are emitted at most once per process for each warning function.

**Uncertainties.**

- Exact messages/behavior of e.options_unrecognised, e.options_removed, e.options_invalid_value and the warning functions live in errors.js/warnings.js, not supplied.
- validate_module_options ignores component-only keys via no-op validators, meaning misspellings of component options are accepted there without error; intent beyond what the code shows is unstated.

<a id="u-8878846122a8"></a>
### `warnings-js-warning-emitters`

`export function a11y_accesskey(node)` · [packages/svelte/src/compiler/warnings.js:L129-L131][f4]

One exported function per compiler warning code, all generated by a script and never edited by hand.

Each function takes a nullable NodeLike node plus code-specific interpolation values, and delegates immediately to the shared sink w with a fixed code and a templated message ending in a svelte.dev documentation URL; all suppression, dedup, and filtering behavior therefore happens inside w and none of these functions has local state or failure paths of its own. Template arity varies per code (e.g. a11y_aria_attributes takes an element name, a11y_autocomplete_valid a value and input type, state_referenced_locally a name and type). Three functions are conditional on their last argument: a11y_unknown_aria_attribute and a11y_unknown_role append a 'Did you mean ...?' clause only when the suggestion argument is truthy, and unknown_code does the same for unrecognized codes. Passing null for node yields a warning with no position, per w's derivation rules.

calls: [packages/svelte/src/compiler/warnings.js:w](r2-compiler-infrastructure.md#u-9c260d23c66a)

**Uncertainties.**

- Whether any caller relies on argument order beyond the documented parameters cannot be verified from this file.

<a id="u-e612644d1f15"></a>
### `html-tree-validation-js-children-maps`

`group` · [packages/svelte/src/html-tree-validation.js:L1-L62][f5]

Two module-level constant tables drive HTML tree validation.

`autoclosing_children` maps parent tags to children that auto-close them, either only as direct children (`direct`) or at any depth (`descendant`, optionally with `reset_by` tags that lift the restriction). `disallowed_children` starts as a spread of `autoclosing_children` and then overrides several entries (optgroup, option) and adds entries using an additional `only` whitelist shape for parents like select, table, head, html, frameset and '#document'; each entry cites the WHATWG/MDN rule it encodes. Both maps are consumed only by the three exported validators in this file.

**Uncertainties.**

- The map key '#document' uses the only-tagged shape, implying it is only consulted with the root as 'parent'; which validator reaches it is not visible in this file.

<a id="u-10b29d40ea2b"></a>
### `closing_tag_omitted`

`export function closing_tag_omitted(current, next)` · [packages/svelte/src/html-tree-validation.js:L63-L74][f5]

Reports whether a tag will be implicitly auto-closed, so the emitted closing tag would be omitted.

Looks up `current` in `autoclosing_children`; if no entry exists it returns false. If an entry exists and either `next` is undefined (end of siblings) or `next` is listed in the entry's `direct` or `descendant` array, it returns true; otherwise false. Used by the parser to decide whether to synthesize a closing tag.

uses: [html-tree-validation-js-children-maps](r2-compiler-infrastructure.md#u-e612644d1f15)

<a id="u-c5a7f2f803ff"></a>
### `is_tag_valid_with_ancestor`

`export function is_tag_valid_with_ancestor(child_tag, ancestors, child_loc, ancestor_…` · [packages/svelte/src/html-tree-validation.js:L146-L175][f5]

Returns an error string when a tag is forbidden as a descendant of its nearest listed ancestor (grandparent and above), i.e. when the browser would repair the HTML.

Returns null immediately for custom elements (child_tag contains '-'). Takes `ancestors[ancestors.length-1]` as the ancestor tag and looks it up in `disallowed_children`; no entry means valid. If the entry has `reset_by`, it walks the remaining ancestors outward, returning null when any intermediate ancestor is a custom element or appears in `reset_by` (forbidden descendants become allowed again past the reset). If the entry's `descendant` array contains child_tag, it formats child and ancestor tags, appending the optional location strings in parentheses, into a '<child> cannot be a descendant of <ancestor>' message. Any other case returns null.

uses: [html-tree-validation-js-children-maps](r2-compiler-infrastructure.md#u-e612644d1f15)

**Uncertainties.**

- Behavior assumes ancestors contains at least two entries per the JSDoc; with fewer, ancestors[ancestors.length-2] would be undefined and the reset_by loop would call includes on undefined values.

<a id="u-a93dfa56dc6d"></a>
### `is_tag_valid_with_parent`

`export function is_tag_valid_with_parent(child_tag, parent_tag, child_loc, parent_loc)` · [packages/svelte/src/html-tree-validation.js:L186-L240][f5]

Returns an error string when a tag is not allowed as a direct child of its parent, otherwise null.

Custom elements on either side short-circuit to null, as does a `template` parent (no warnings inside template immediate children). If the parent has a `disallowed_children` entry: a `direct` hit yields '<child> cannot be a direct child of <parent>'; a `descendant` hit yields 'cannot be a child of'; an `only` list permits listed children (null) and rejects all others with a message enumerating the allowed tags. If no rule matched, structurally constrained children are rejected: body/caption/col/colgroup/frameset/frame/head/html are invalid anywhere else; thead/tbody/tfoot must be children of a table; td/th must be children of a tr; tr must be a child of thead/tbody/tfoot. Tags with no entry and no special rule return null. Optional location strings are embedded in the message text.

uses: [html-tree-validation-js-children-maps](r2-compiler-infrastructure.md#u-e612644d1f15)

**Uncertainties.**

- `parent_tag` is documented optional and guarded with ?. but is otherwise assumed truthy when building the parent label; a genuinely undefined parent would produce '<undefined>' style text.

<a id="u-49c3d847da08"></a>
### `CompileDiagnostic`

`class CompileDiagnostic` · [packages/svelte/src/compiler/utils/compile_diagnostic.js:L52-L60][f1]

Represents a single compiler diagnostic with code, message, optional filename/positions, and a formatted code frame, implementing the ICompileDiagnostic shape.

The constructor stores code and message; it attaches `filename` from module state only when it is not the UNKNOWN_FILENAME sentinel. When a `[start, end]` position is given, it stores `position`, resolves `start`/`end` Locations via `state.locator`, and — only when both resolve — builds `frame` with `get_code_frame(state.source, start.line - 1, end.column)`. If the locator returns undefined for either end, no frame is produced. `toString` composes `code: message`, appends the filename (with `:line:column` when a start exists), then the frame; `toJSON` returns a plain object of the diagnostic fields for serialization.

**Uncertainties.**

- Behavior depends on module state (`state.filename`, `state.locator`, `state.source`) set elsewhere; their nullability is only partially inferable here

<a id="u-4f8a7deedb7c"></a>
### `push_array`

`export function push_array(array, items)` · [packages/svelte/src/compiler/utils/push_array.js:L9-L13][f6]

Appends every item of `items` to `array` with individual push calls, mutating `array`.

Exists for memory/performance and to avoid the 'max call stack size exceeded' error that spread-based push hits with ~65k+ items.

<a id="u-01781e43d6ff"></a>
### `sanitize_template_string`

`export function sanitize_template_string(str)` · [packages/svelte/src/compiler/utils/sanitize_template_string.js:L5-L7][f7]

Escapes backticks, dollar-brace sequences, and backslashes in a string so it can be embedded safely inside a JS template literal, prefixing each of (` | ${ | \) with a backslash.

<a id="u-ead26eb5b43f"></a>
### `determine_slot`

`export function determine_slot(node)` · [packages/svelte/src/compiler/utils/slot.js:L8-L20][f8]

Returns the slot name assigned by a component-content node, or null.

Non-element nodes yield null immediately. Among the element's attributes it scans for one of type 'Attribute' named 'slot' that is a static text attribute (is_text_attribute); the first such match's text data is returned. Attributes of other types, other names, or non-text (dynamic) slot attributes are skipped, and the scan continues; with no qualifying attribute the result is null.

calls: [is_element_node](r3-scope-node-model.md#u-0d9a79ad394a); uses: [is_text_attribute](r5-compiler-utilities.md#u-ec400088cae5)

<a id="u-5617f591c677"></a>
### `list`

`export function list(strings, conjunction = 'or')` · [packages/svelte/src/compiler/utils/string.js:L5-L9][f9]

Formats a list of strings for prose messages: one item returns itself; two items return 'a <conjunction> b'; three or more return comma-joined items with the conjunction before the last (e.g. 'a, b or c').

conjunction defaults to 'or'.

<a id="u-398217cb8a64"></a>
### `packages/svelte/src/compiler/warnings.js:InternalCompileWarning`

`class InternalCompileWarning extends CompileDiagnostic` · [packages/svelte/src/compiler/warnings.js:L7-L15][f4]

Warning payload type for internal compiler diagnostics; it extends CompileDiagnostic and only overrides the name to 'CompileWarning'.

The constructor accepts a code, a message, and an optional [start, end] position pair, and forwards all three to the CompileDiagnostic constructor unchanged. No validation, transformation, or side effects occur beyond the base-class initialization, so behavior (including how position is stored) is inherited from the unproven CompileDiagnostic boundary.

inherits: [packages/svelte/src/compiler/utils/compile_diagnostic.js][f1]

**Uncertainties.**

- Behavior of the inherited fields and methods comes from CompileDiagnostic, which is outside the supplied source.

<a id="u-9c260d23c66a"></a>
### `packages/svelte/src/compiler/warnings.js:w`

`function w(node, code, message)` · [packages/svelte/src/compiler/warnings.js:L25-L39][f4]

Core deduplicating sink that every warning emitter in this file calls.

It takes a nullable node, a code string, and a message. First it picks an ignore set: the node's own set from ignore_map if the node exists, otherwise the module-level ignore_stack. If that stack exists and its last entry contains the code, the warning is dropped. Position is derived only when node exists and node.start is defined: [node.start, node.end ?? node.start], else undefined. It then builds an InternalCompileWarning and pushes it onto the shared warnings array only if warning_filter accepts it; otherwise the warning is silently discarded. Neither early-exit path throws, so suppression is invisible to the caller.

calls: [packages/svelte/src/compiler/warnings.js:InternalCompileWarning](r2-compiler-infrastructure.md#u-398217cb8a64); uses: [packages/svelte/src/compiler/state.js][f2]

**Uncertainties.**

- Semantics of ignore_map/ignore_stack population and warning_filter's acceptance criteria live in ./state.js and are not visible here.
- Uses of the `stack` import besides ignore_stack/ignore_map are not evident from this source.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/utils/compile_diagnostic.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/state.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/validate-options.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/warnings.js
[f5]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/html-tree-validation.js
[f6]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/utils/push_array.js
[f7]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/utils/sanitize_template_string.js
[f8]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/utils/slot.js
[f9]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/utils/string.js
