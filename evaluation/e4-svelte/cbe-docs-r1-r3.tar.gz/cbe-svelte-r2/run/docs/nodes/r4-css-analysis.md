# CSS Analysis

**Capability.** Walks the component stylesheet to validate :global usage, nesting selectors, and at-rules, recording keyframes names, global-block metadata, and selector scoping decisions on the CSS AST.

Use this subtree for CSS validation and the metadata downstream CSS pruning/scoping consumes. analyze_css is the entry point; is_in_global_block/is_unscoped compute global-context decisions used by its visitors.

**Depends on.**

- [Compiler Shared Infrastructure](r4-compiler-infra.md) · graph-confirmed · 1 edge(s)

**Depended on by.**

- [CSS Transform](r4-css-transform.md) · model-inferred · 0 edge(s)

Parent: [Semantic Analysis \(Phase 2\)](r4-compile-analysis.md)

## Units (10)

<a id="u-f762711e5ae7"></a>
### `analyze_css`

`export function analyze_css(stylesheet, analysis)` · [packages/svelte/src/compiler/phases/2-analyze/css/css-analyze.js:L322-L331][f1]

Entry point for CSS analysis of a component stylesheet: builds a CssState sharing analysis.css.keyframes, with rule null and the component analysis, then walks the stylesheet with the module's css_visitors.

Returns nothing; all results accumulate in the passed analysis and in selector metadata.

uses: [Atrule](r4-css-analysis.md#u-e57d7d11437c)

<a id="u-b122f86baec1"></a>
### `is_global_block_selector`

`function is_global_block_selector(simple_selector)` · [packages/svelte/src/compiler/phases/2-analyze/css/css-analyze.js:L25-L31][f1]

Reports whether a simple selector is a bare `:global` pseudo-class with no arguments, i.e. the header of a `:global { ...

}` block. True only when type is 'PseudoClassSelector', name is 'global', and args is null; `:global(...)` returns false.

<a id="u-369b23b9e8cb"></a>
### `is_in_global_block`

`function is_in_global_block(path)` · [packages/svelte/src/compiler/phases/2-analyze/css/css-analyze.js:L46-L48][f1]

Returns true when any node on the path is a Rule whose metadata.is_global_block is set, i.e. the current position sits inside a `:global { ...

}` block.

<a id="u-eb466791d0eb"></a>
### `is_unscoped`

`function is_unscoped(path)` · [packages/svelte/src/compiler/phases/2-analyze/css/css-analyze.js:L36-L40][f1]

Decides whether an enclosing CSS path is entirely unscoped: filters the path to `Rule` nodes and returns true only when every such rule has metadata.has_global_selectors; a path with no Rule nodes yields true (vacuous every).

**Uncertainties.**

- The vacuously-true case for a path without Rule nodes is inferred from every(), not a documented contract.

<a id="u-e57d7d11437c"></a>
### `Atrule`

`const css_visitors = { Atrule(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/css/css-analyze.js:L51-L63][f1]

Collects component keyframes names and flags global keyframes during the CSS walk.

For a keyframes at-rule: if the name does not start with '-global-' and the node is not inside a global block, the name is pushed onto state.keyframes; if the name starts with '-global-' (even for an empty block), analysis.css.has_global is set true only when is_unscoped(context.path) holds. context.next() always continues the walk.

**Notes.**

- side_effect: Mutates context.state.keyframes and context.state.analysis.css.has_global.

calls: [is_keyframes_node](r4-compiler-infra.md#u-8dc3955e3495)

<a id="u-7665c45db5b3"></a>
### `ComplexSelector`

`ComplexSelector(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/css/css-analyze.js:L64-L141][f1]

Validates `:global(...)` placement within a complex selector and derives its metadata after children are analyzed.

After context.next(), if any child is global: a nested position (path element two back is a PseudoClassSelector) with argument-less `:global` raises css_global_block_invalid_placement; an argumented `:global(...)` neither first nor last raises css_global_invalid_placement unless every following child is also global. A second pass over relative selectors raises css_global_invalid_selector_list when a type selector inside `:global(...)` is not at index 0 of the compound, css_type_selector_invalid_placement when a type selector directly follows `:global(...)`, and css_global_invalid_selector when `:global()` holds multiple selectors while the complex selector has more than one child or the relative selector more than one simple selector. Metadata: rule from state, is_global when every child is global/global-like, used ||= is_global; additionally a leading NestingSelector in a rule whose parent rule is global marks the selector used when the selector after `&` is absent or an unscoped pseudo-class. Errors are thrown compiler errors and abort the walk.

calls: [packages/svelte/src/compiler/phases/2-analyze/css/utils.js:is_global](r6-compiler-analyze-css.md#u-022eb67172ae); uses: [is_unscoped_pseudo_class](r6-compiler-analyze-css.md#u-2d29e82903c1)

**Uncertainties.**

- Whether `:global()` in the middle with following globals but preceding non-globals is accepted (only following children are checked) is as written but not confirmed against tests.

<a id="u-103ef31ee70b"></a>
### `NestingSelector`

`NestingSelector(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/css/css-analyze.js:L287-L315][f1]

Validates placement of the CSS nesting selector `&`.

With no parent rule, it must be the sole selector, in the sole complex selector of the current rule, inside a `:global(...)` whose first inner selector is this node; any deviation raises css_nesting_selector_invalid_placement. With a parent rule that is a top-level global block containing exactly one bare `:global` selector, css_global_block_invalid_modifier_start is raised (rejecting `:global { &.foo {...} }`). context.next() always continues.

<a id="u-7853ab08bc6e"></a>
### `RelativeSelector`

`RelativeSelector(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/css/css-analyze.js:L142-L187][f1]

Classifies a relative selector as global or global-like and rejects illegal leading combinators.

If the selector has a combinator, state.rule has no parent_rule, it is the parent complex selector's first child, and the path element three back is not a PseudoClassSelector, css_selector_invalid is thrown. metadata.is_global is set when is_global(node) holds with at least one selector. is_global_like is set when all selectors are pseudo-class/pseudo-element selectors and the first is `:host` or one of the view-transition* pseudo-elements, or when a `:root` selector is present without any `:has(...)` (so `:root.y:has(.x)` stays scoped). For global/global-like selectors every child selector is walked with a sub-visitor that marks each ComplexSelector used and continues, keeping nested selectors like `:root:not(.x)` out of unused-selector warnings. context.next() then continues.

calls: [packages/svelte/src/compiler/phases/2-analyze/css/utils.js:is_global](r6-compiler-analyze-css.md#u-022eb67172ae)

<a id="u-7fee2f390291"></a>
### `Rule`

`Rule(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/css/css-analyze.js:L197-L226][f1]

Analyzes a CSS rule: records nesting, validates `:global { ...

}` block headers, and derives selector metadata. metadata.parent_rule is set from state.rule. For each complex selector in the prelude, per relative selector: once a bare `:global` header was seen, later children are marked is_global_like. When a bare `:global` is at position 0: at the top level with additional simple selectors it raises css_global_block_invalid_modifier_start; otherwise the rule is marked is_global_block, remaining simple selectors get their ComplexSelectors marked used via sub-walks, a non-space combinator raises css_global_block_invalid_combinator, a lone `:global` combined with several complex selectors raises css_global_block_invalid_list, and a lone `:global` rule with a direct declaration raises css_global_block_invalid_declaration. A bare `:global` at any other position raises css_global_block_invalid_modifier. After the loop, a rule marked is_global_block whose current complex selector had no `:global` header also raises css_global_block_invalid_list.

**Uncertainties.**

- is_global_block is reset per complex selector, so the post-loop check compares the rule-level flag against only the last complex selector's outcome; intent is not decidable from this file.

<a id="u-9242418cf87e"></a>
### `packages/svelte/src/compiler/phases/2-analyze/css/css-analyze.js:Rule`

`Rule(node, context)` · [packages/svelte/src/compiler/phases/2-analyze/css/css-analyze.js:L228-L286][f1]

Continuation of Rule analysis after selector validation.

State is extended with rule: node, node.prelude is visited first so child selector metadata is populated, then has_global_selectors and has_local_selectors accumulate from each complex selector's is_global. analysis.css.has_global is set true when the rule has global selectors, its block contains at least one Declaration, and is_unscoped(context.path) — every enclosing rule also unscoped. Finally node.block is visited with the new state.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/css/css-analyze.js
