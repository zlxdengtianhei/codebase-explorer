# Transform Phase

**Capability.** Generates executable JavaScript from the analysis: a client output driving reactive DOM updates and a server output producing SSR payloads, plus shared assignment-rewriting logic used by both.

Client visitors emit runtime calls ($.slot, $.html, transitions, animations) and class/state rewriting; server visitors emit payload-centric statements. Shared assignment logic is kept separate from both consumers.

**Children.**

- [Client Transform Visitors](r1-compiler-transform-client.md) `r1-compiler-transform-client` · 17 unit(s)
- [Shared Assignment Rewriting](r1-compiler-transform-shared.md) `r1-compiler-transform-shared` · 1 unit(s)
- [Server Transform \(SSR\)](r1-compiler-transform-server.md) `r1-compiler-transform-server` · 14 unit(s)

Parent: [Svelte Compiler](r1-compiler.md)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.
