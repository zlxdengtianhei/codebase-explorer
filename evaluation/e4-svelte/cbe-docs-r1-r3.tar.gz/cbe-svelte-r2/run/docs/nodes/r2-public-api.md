# Public authoring API and typings

**Capability.** Author-facing surface: easing functions for transitions, action and event-helper typings, attachment keys and action-to-attachment wrapping, the svelteHTML JSX typing namespace, and the public re-export of the `on` event helper.

Library authors use createAttachmentKey/fromAction to integrate with `{@attach}`, and the action/events typings for type-safe helpers. easing/index.js supplies the transition easing curves; events/index.js is a pure re-export of the internal `on`.

**Depends on.**

- [DOM elements, events and bindings](r2-dom-elements.md) · model-inferred · 0 edge(s)

Parent: [Svelte framework](r2-svelte.md)

## Units (7)

<a id="u-418ed383b520"></a>
### `index-js-easing-functions`

`export function linear(t)` · [packages/svelte/src/easing/index.js:L10-L12][f1]

Easing functions that map a progress value t (conventionally 0..1) to an eased progress value, used by animations and transitions.

Each is a pure single-argument function with no side effects. Families: linear returns t; the polynomial families (quad, cubic, quart, quint) raise t to increasing powers, with *InOut variants applying the 'in' curve to the first half (t<0.5 or doubled-t<1) and the 'out' curve shifted to the second half; quadInOut, circInOut, quintInOut, and backInOut mutate t in place (t*=2, t--, t-=2) before computing. The back family overshoots below 0/above 1 near the ends via the s=1.70158 (InOut: 1.70158*1.525) overshoot constant. bounceOut selects among four nested ranges (t<4/11, <8/11, <9/10, else) of quadratic formulas; bounceIn and bounceInOut are reflections/compositions of bounceOut. circ family uses sqrt(1-t^2) shapes; sine family uses trig, with sineIn explicitly returning 1 when the cosine magnitude is below 1e-14 to avoid floating-point noise. elastic family combines sine oscillation with 2^(10*(t-1)) attenuation; elasticIn/Out hit 0/1 only approximately (no endpoint special-case). expoIn returns t when t===0.0, expoOut returns t when t===1.0, and expoInOut returns t for both exact endpoints, avoiding 2^(-10) asymmetry at boundaries. Values outside [0,1] are not clamped by any function.

**Notes.**

- side_effect: None: all functions are pure and stateless; parameter reassignment (t*=2 etc.) is local.
- contract: No input validation; non-numeric or out-of-range t produces unvalidated numeric output per the formulas.

<a id="u-e3e000b88519"></a>
### `public.d.ts-action`

`export interface ActionReturn< Parameter = undefined, Attributes extends Record<strin…` · [packages/svelte/src/action/public.d.ts:L27-L39][f2]

Type-only declarations describing Svelte actions: `ActionReturn` exposes optional `update` (called when the action parameter changes) and `destroy` (called on unmount) plus a `$$_attributes` marker used solely for type-checking; `Action` types the action function itself, using `undefined extends Parameter` so that `Action<Element>` and `Action<Element, undefined>` both make the parameter optional.

None of this has runtime behavior.

<a id="u-88dc1957fa2e"></a>
### `public.d.ts-events-on`

`export function on<Type extends keyof WindowEventMap>( window: Window, type: Type, ha…` · [packages/svelte/src/events/public.d.ts:L8-L13][f3]

Type-only overload declarations for the `on` helper.

Each overload attaches an event handler to a window, document, HTMLElement (typed via `HTMLElementEventMap`), MediaQueryList, or a generic `EventTarget`, and returns an unsubscriber `() => void`. Per the accompanying doc comment, using `on` instead of raw `addEventListener` preserves handler ordering relative to Svelte's declaratively added (delegated) handlers. The implementations live elsewhere; this file contains no runtime code.

<a id="u-cc2899ac16bb"></a>
### `svelte-html-d-ts`

`type HTMLProps<Property extends string, Override> = Omit< import('./elements.js').Sve…` · [packages/svelte/svelte-html.d.ts:L11-L15][f4]

Declares a global typing-only namespace svelteHTML (loaded directly by the Svelte language server, deliberately absent from the package exports map) so JSX-style element typing works.

mapElementTag has three overloads: keys of ElementTagNameMap and SVGElementTagNameMap map to their concrete element types; a catch-all any overload exists because <svelte:element> needs dynamic tags. createElement has two overloads: a two-argument form and a three-argument form whose middle parameter is an attrs enhancer intersected into the attributes; the element parameter accepts undefined | null because of <svelte:element>; the return type falls back to any when the key is neither an HTML nor SVG tag name. HTMLProps<Property, Override> omits the matching SvelteHTMLElements entry's keys that are overridden and intersects Override, so user augmentations of HTMLAttributes/SVGAttributes take precedence. The empty HTMLAttributes and SVGAttributes interfaces (both internal, marked for removal in Svelte 6) exist only so consumers who augmented import('svelte/elements') typings still merge correctly. IntrinsicElements extends SvelteHTMLElements and enumerates every HTML element as HTMLProps<'name', HTMLAttributes> and every SVG element (svg onward) as HTMLProps<'name', SVGAttributes>, plus an index signature [name: string]: { [name: string]: any } allowing arbitrary custom elements.

imports: [./elements.js](../../catalog.json); uses: [ElementTagNameMap](../../catalog.json), [SVGElementTagNameMap](../../catalog.json)

**Uncertainties.**

- The source has a reported syntax ERROR node near line 1 in the parser tree; chunk coverage is preserved but exact parse behavior of the triple-slash reference is uncertain.
- This is a declaration file: all functions are typings only with no runtime implementation visible.

<a id="u-c36056169480"></a>
### `createAttachmentKey`

`export function createAttachmentKey()` · [packages/svelte/src/attachments/index.js:L30-L32][f5]

Returns a `Symbol(ATTACHMENT_KEY)` that the compiler/renderer recognizes as an attachment when the containing object is spread onto an element, giving library authors a programmatic alternative to `{@attach ...}`.

It has no other behavior and does not validate or cache keys.

<a id="u-0433aefd7114"></a>
### `fromAction`

`export function fromAction(action, fn = /** @type {() => T} */ (noop))` · [packages/svelte/src/attachments/index.js:L96-L113][f5]

Wraps an action (or plain `(element, arg)` function) as an attachment function.

When the attachment runs for an element it calls, untracked, `action(element, fn())`, destructuring the possibly-null result into `update`/`destroy`. If `update` exists it creates a render effect that reads `fn()` and, after the first run (`ran` flag prevents firing with the initial value the action already consumed), calls `update(arg)` whenever the argument changes reactively. If `destroy` exists it is registered via `teardown` so it runs when the attachment is torn down. `fn` defaults to `noop`, so a second argument must be supplied for parameterized actions; it must be a function returning the argument, not the argument itself.

uses: [fromAction](r2-public-api.md#u-0433aefd7114); calls: [effects.js-effect-creators](r3-effects-engine.md#u-27c9c7c4069f)

**Uncertainties.**

- Exact re-run semantics depend on `render_effect` and `untrack`, defined outside this file.

<a id="u-62e73e8675dc"></a>
### `index.js module code (L1–L1)`

`module_region` · [packages/svelte/src/events/index.js:L1-L1][f6]

Pure re-export forwarding 'on' from the internal DOM events module as this module's public surface.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/easing/index.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/action/public.d.ts
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/events/public.d.ts
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/svelte-html.d.ts
[f5]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/attachments/index.js
[f6]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/events/index.js
