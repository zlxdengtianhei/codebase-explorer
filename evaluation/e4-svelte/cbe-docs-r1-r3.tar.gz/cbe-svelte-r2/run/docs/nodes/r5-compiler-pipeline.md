# Compiler Public API and Pipeline

**Capability.** Owns the public compile entry points (compile, compileModule, parse) and the transform-phase entry points they invoke: input normalization (remove_bom), parse/analyze orchestration, transform dispatch, and public AST/result shaping.

Use this subtree to see how a .svelte file or JS module becomes a CompileResult. compile/compileModule delegate to transform_component/transform_module; phase internals are under analyze-phase, client-transform and server-transform.

**Children.**

- [Analyze-Phase Visitors](r5-analyze-phase.md) `r5-analyze-phase` · 18 unit(s)
- [Client Transform](r5-client-transform.md) `r5-client-transform` · 27 unit(s)
- [Server \(SSR\) Transform](r5-server-transform.md) `r5-server-transform` · 9 unit(s)

**Depends on.**

- [Client Transform](r5-client-transform.md) · containment · → 0 / ← 0 edge(s) (ancestor direct units and descendant subtree; → follows ` r5-compiler-pipeline ` → ` r5-client-transform `)
- [Server \(SSR\) Transform](r5-server-transform.md) · containment · → 0 / ← 0 edge(s) (ancestor direct units and descendant subtree; → follows ` r5-compiler-pipeline ` → ` r5-server-transform `)

**Depended on by.**

- [Reactivity and SSR Benchmarks](r5-benchmarks.md) · model-inferred · 0 edge(s)
- [Playground Sandbox](r5-playground-sandbox.md) · model-inferred · 0 edge(s)
- [Warning Codegen Template](r5-warnings-codegen.md) · model-inferred · 0 edge(s)

Parent: [Svelte Monorepo](r5-svelte-monorepo.md)

## Units (8)

<a id="u-a54e3b374c84"></a>
### `compile`

`export function compile(source, options)` · [packages/svelte/src/compiler/index.js:L21-L55][f1]

Compile a `.svelte` component source into a JavaScript module by running the full parse/analyze/transform pipeline.

It strips a leading BOM, resets module compiler state (warning filter and filename from options), and validates options. It parses the source, then merges options: validated options are overlaid with options parsed from `<svelte:options>` (`parsed.options`), with `customElement` split out and kept as `customElementOptions`. When `parsed.metadata.ts` is set, `remove_typescript_nodes` is applied to fragment, instance, and module, and, if present, to `customElementOptions.extend`. It then runs `analyze_component` and `transform_component`, and attaches the public AST via `to_public_ast`, choosing modern or legacy shape based on `options.modernAst`. Errors from validation, parsing, analysis, or transform propagate; no fallback is visible.

calls: [to_public_ast](r5-compiler-pipeline.md#u-bbe3d8bf2fb6), [remove_bom](r5-compiler-pipeline.md#u-2ee755d4c746); imports: [index.js module code (L55–L63)][f1]

**Uncertainties.**

- Behavior of remove_typescript_nodes, analyze_component, and transform_component is defined in other files not supplied here.

<a id="u-5cd4b4bd0816"></a>
### `compileModule`

`export function compileModule(source, options)` · [packages/svelte/src/compiler/index.js:L64-L71][f1]

Compile a plain JavaScript module containing runes.

Removes a BOM, resets compiler state with the caller's warning filter and filename, validates options with `validate_module_options`, then runs `analyze_module` on the source and `transform_module` on the resulting analysis, returning the transform result. No component AST is produced; validation and pipeline errors propagate.

calls: [remove_bom](r5-compiler-pipeline.md#u-2ee755d4c746)

**Uncertainties.**

- Behavior of analyze_module/transform_module lives outside this file.

<a id="u-08797705aefb"></a>
### `parse`

`export function parse(source, { modern, loose } = {})` · [packages/svelte/src/compiler/index.js:L112-L118][f1]

Parse a component and return only its AST.

Removes the BOM, resets state with a warning filter that always returns false (all warnings suppressed) and undefined filename, parses with the `loose` flag forwarded, then converts to the public AST shape. With `modern` truthy the result is the modern AST with internal metadata stripped; otherwise the legacy Svelte-4-shaped AST is returned. The `filename` option is destructured away and unused, per the inline TODO. Parse errors propagate.

calls: [to_public_ast](r5-compiler-pipeline.md#u-bbe3d8bf2fb6), [remove_bom](r5-compiler-pipeline.md#u-2ee755d4c746)

**Uncertainties.**

- Exact effect of `loose` depends on the parser in phases/1-parse, outside this file.

<a id="u-2ee755d4c746"></a>
### `remove_bom`

`function remove_bom(source)` · [packages/svelte/src/compiler/index.js:L155-L160][f1]

Strip a leading UTF-8 byte order mark.

If the first character's char code is 0xfeff, return the string minus its first character; otherwise return the input unchanged. Empty strings are safe because charCodeAt on an empty string returns NaN, which fails the comparison.

<a id="u-bbe3d8bf2fb6"></a>
### `to_public_ast`

`function to_public_ast(source, ast, modern)` · [packages/svelte/src/compiler/index.js:L125-L127][f1]

Convert an internal AST into its public form, choosing shape by the `modern` flag.

In modern mode it mutates the AST in place: a `clean` helper deletes `node.metadata`; for each `<svelte:options>` attribute it cleans the attribute, its `value`, and each element of an array-valued `value`; then a zimmerframe walk with a catch-all `_` handler deletes `metadata` on every node and continues via `next()`, returning the walked root. In legacy mode it delegates to `convert(source, ast)` producing the Svelte-4-style tree. The caller's AST object is modified in the modern path.

calls: [legacy.js-convert-modern-ast-to-svelte-4-shape](r3-legacy-ast-compat.md#u-b18e2937a7a3)

<a id="u-c9e4085285ea"></a>
### `walk`

`export function walk()` · [packages/svelte/src/compiler/index.js:L166-L170][f1]

Deprecated shim that always throws.

Any invocation raises an Error telling callers to import `walk` from 'estree-walker' instead; it never returns.

<a id="u-be9df8c13257"></a>
### `transform_component`

`export function transform_component(analysis, source, options)` · [packages/svelte/src/compiler/phases/3-transform/index.js:L19-L62][f2]

Transforms an analyzed Svelte component into a printed CompileResult.

When options.generate is false it returns a stub result with null js/css/ast, the warnings array from compiler state, and the analysis' runes flag. Otherwise it builds the program with server_component or client_component depending on generate === 'server', prints it with esrap using the ts printer seeded with analysis.comments, embedding the raw source as sourceMapContent and a computed source name via get_source_name; merge_with_preprocessor_map then folds any preprocessor source map into the result. CSS is rendered through render_stylesheet only when the analysis has CSS and styles are not injected; otherwise css is null. js, css, warnings, runes metadata, and a null ast placeholder are returned; the comments note warnings and ast are filled in later.

calls: [client_component](r6-transform-client.md#u-15bd8cef14fb), [transform-server-js-server-component](r1-compiler-transform-server.md#u-3bff6efcb646), [render_stylesheet](r4-css-transform.md#u-197b2d45aa0c), [get_source_name](r6-compiler-infra.md#u-61dfd78a863b), [merge_with_preprocessor_map](r6-compiler-infra.md#u-58c664c9f3e7)

**Uncertainties.**

- state.warnings is annotated 'set afterwards'; how it is populated before callers see it is outside this file

<a id="u-bccc1428d18a"></a>
### `transform_module`

`export function transform_module(analysis, source, options)` · [packages/svelte/src/compiler/phases/3-transform/index.js:L70-L118][f2]

Transforms an analyzed non-component module (e.g. compiled via compileModule) into a CompileResult.

With options.generate === false it returns a stub with null js/css/ast and runes: true. Otherwise it picks server_module or client_module by generate === 'server', then prints with esrap/ts using analysis.comments and embedded sourceMapContent. It derives the filename basename by splitting on slashes/backslashes, prepends a 'generated by Svelte vVERSION' block comment to the first top-level statement when the program body is non-empty, and additionally prepends the same comment to the printed code string while prefixing the source map mappings with ';' to keep alignment. Returns js, css: null, runes: true, warnings from state, and a null ast placeholder.

calls: [client_module](r6-transform-client.md#u-1e0775efa9e3), [server_module](r1-compiler-transform-server.md#u-7e11f4406861), [get_source_name](r6-compiler-infra.md#u-61dfd78a863b)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/index.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/3-transform/index.js
