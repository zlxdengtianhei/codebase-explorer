# Reactive Batch Scheduling

**Capability.** Groups source updates into batches so effects flush once against consistent values: scheduling, effect queues, synchronous and microtask flushing, infinite-loop guarding, suspension for async work, and the signal/reaction type contracts.

Use this subtree to understand when effects run. Batch plus flushSync/flush_effects/schedule_effect form the scheduler; await and if blocks call flushSync and Batch directly. types.d.ts declares only shapes (Signal/Value/Reaction/Effect/Derived) with no runtime behavior.

**Depends on.**

- [Reactivity core](r2-reactivity-core.md) · graph-only · 12 edge(s)

**Depended on by.**

- [Client DOM Blocks](r4-client-dom-blocks.md) · graph-confirmed · 2 edge(s)
- [Client Transform](r4-client-transform.md) · model-inferred · 0 edge(s)
- [Element Bindings and Styles](r4-element-bindings.md) · model-inferred · 0 edge(s)
- [Reactive Built-in Wrappers](r4-reactivity-library.md) · model-inferred · 0 edge(s)

Parent: [Runtime](r4-runtime.md)

## Units (17)

<a id="u-43c969fbb82e"></a>
### `Batch`

`class Batch` · [packages/svelte/src/internal/client/reactivity/batch.js:L81-L179][f1]

Groups source updates so effects flush once against consistent values.

Instance state: `current`/`#previous` maps of source values (identical keys), `#callbacks` (DOM commit callbacks from if/each/key blocks), `#pending` (in-flight async count), `#deferred` (resolves on commit, backs `settled()`), `#neutered` (an async effect resolved after its branch was deleted; suppresses commit callbacks), effect queues (`#async_effects` run after the rest of the flush for latest values, `#boundary_async_effects` inside a new boundary which do not block commit, `#render_effects`, `#effects`, `#block_effects`, plus `#dirty_effects`/`#maybe_dirty_effects` deferred while async work is pending), and `skipped_effects` excluded from traversal. `process` resets the module queue; in async mode with multiple batches it 'time travels' by temporarily writing this batch's (and undoing other batches') source values, restoring them afterwards unless a newer write landed. It then traverses the effect tree and, if no new async work arose and none is outstanding, commits: flushes render/effect queues with `current_batch` temporarily null, reinstates itself (or deletes itself from `batches` if a new batch appeared), and resolves `#deferred`; otherwise it defers all queues by clearing their statuses to CLEAN. Finally it runs the collected async effects via `update_effect`. `#traverse_effect_tree` clears CLEAN on the root and walks the linked effect list, skipping clean branches, INERT effects, and `skipped_effects`; EFFECT flags go to `#effects`, RENDER_EFFECT (async mode only) to `#render_effects`, ASYNC to the boundary or plain async queue, and other dirty block effects are updated immediately. `#defer_effects` routes DIRTY versus MAYBE_DIRTY effects into the deferred queues and marks them CLEAN so they can be rescheduled when async state resolves. `decrement` reschedules the deferred effects with their original statuses when `#pending` reaches zero, resets the render/effect queues, and flushes; otherwise it deactivates. `deactivate` clears `current_batch`/`previous_batch` and drains at most one `effect_pending_updates` entry at a time, stopping if a new batch became current. `flush` runs `flush_effects` when root effects are queued, else commits; if a nested `flushSync` replaced the current batch it returns early (legacy mode only), deleting itself from `batches` when no async work remains, then deactivates. `neuter` sets `#neutered`, `#commit` runs and clears `#callbacks` unless neutered, `add_callback` registers a commit callback, `settled` lazily creates and returns the deferred promise, static `ensure` creates and registers a batch when none is current (scheduling its flush via `enqueue` unless flushing synchronously, bailing if a `flushSync` intervened), and static `enqueue` unshifts tasks onto the microtask-pumped queue.

calls: [is_dirty](r2-reactivity-core.md#u-6236bf4a1a35), [runtime.js-module-state-setters](r2-reactivity-core.md#u-ac602620d878), [deferred](r6-shared-infra.md#u-3c5ab59ed010), [schedule_effect](r4-reactivity-scheduling.md#u-ce4f8d895426)

**Uncertainties.**

- `Batch.capture` is described from its body (records prior value once, always stores current `source.v`); its interplay with `old_values` in sources.js is outside this file.

<a id="u-6561acc7b015"></a>
### `packages/svelte/src/internal/client/reactivity/batch.js:clear`

`export function clear()` · [packages/svelte/src/internal/client/reactivity/batch.js:L695-L697][f1]

Test-only helper that forcibly empties the module-level `batches` set to prevent cross-talk between tests.

<a id="u-dbbbce459e92"></a>
### `dequeue`

`function dequeue()` · [packages/svelte/src/internal/client/reactivity/batch.js:L62-L70][f1]

Microtask pump for the module-level `tasks` queue: shifts one task and, if more remain, schedules another `dequeue` microtask before running the shifted task, so queued batch-flush tasks execute one per microtask in order.

<a id="u-f4c4d1829672"></a>
### `flushSync`

`export function flushSync(fn)` · [packages/svelte/src/internal/client/reactivity/batch.js:L485-L523][f1]

Synchronously drains all pending updates, optionally running `fn` after an initial flush and returning its result.

In async mode with an active effect it throws `flush_sync_in_effect`. It sets `is_flushing_sync`, then loops: flushes queued microtasks (`flush_tasks`); if no root effects remain it flushes the current batch and, if still none, resets `last_scheduled_effect` and returns the result — otherwise runs `flush_effects` again. The `is_flushing_sync` flag is restored in `finally`.

calls: [flush_tasks](r6-client-dom-task.md#u-f61b99082e8c)

<a id="u-bb27f3ab5ca2"></a>
### `flush_effects`

`function flush_effects()` · [packages/svelte/src/internal/client/reactivity/batch.js:L525-L571][f1]

Repeatedly processes queued root effects until the queue drains: each iteration ensures a batch exists, invokes `infinite_loop_guard` after more than 1000 flushes (in DEV first aggregating and logging each source's update errors by stack), runs `batch.process(queued_root_effects)`, and clears `old_values`.

Preserves and restores `is_updating_effect` and clears `last_scheduled_effect` in `finally`.

calls: [runtime.js-module-state-setters](r2-reactivity-core.md#u-ac602620d878); uses: [update_effect](r2-reactivity-core.md#u-e2ea8c85735e)

<a id="u-93f48e016c80"></a>
### `flush_queued_effects`

`function flush_queued_effects(effects)` · [packages/svelte/src/internal/client/reactivity/batch.js:L595-L642][f1]

Runs queued render/effect entries in order while not DESTROYED or INERT and still dirty.

Before each `update_effect` it resets `eager_block_effects` to a fresh array; afterwards, effects with no deps, no children, and no DOM nodes are pruned — unlinked entirely when they have no teardown or abort controller, otherwise kept in the tree with `fn` nulled to free memory. If the update filled `eager_block_effects` (a nested flush may have nulled it), it clears `old_values` and updates those eagerly collected block effects, then empties the list. Finally sets `eager_block_effects` to null.

calls: [is_dirty](r2-reactivity-core.md#u-6236bf4a1a35), [unlink_effect](r3-effects-engine.md#u-519e1d7b7b2b)

<a id="u-a4b355b41c3e"></a>
### `infinite_loop_guard`

`function infinite_loop_guard()` · [packages/svelte/src/internal/client/reactivity/batch.js:L573-L586][f1]

Handles runaway flush loops by invoking `effect_update_depth_exceeded` inside try/catch; in DEV it blanks the error's stack (it contains no useful information) and then routes the error to `invoke_error_boundary` targeting `last_scheduled_effect` — a best-effort guess at the nearest relevant boundary.

calls: [invoke_error_boundary](r3-client-error-handling.md#u-8ed809bdafb5)

<a id="u-ce4f8d895426"></a>
### `schedule_effect`

`export function schedule_effect(signal)` · [packages/svelte/src/internal/client/reactivity/batch.js:L648-L668][f1]

Schedules an effect by walking up to its root ancestor and pushing that root onto `queued_root_effects`; records the effect in `last_scheduled_effect`.

During an active flush it bails out when the traversed effect is the active BLOCK_EFFECT (an internal block-source update), preventing a second flush; for ROOT/BRANCH ancestors it stops early if already non-CLEAN, otherwise toggles CLEAN off as it ascends.

uses: [update_effect](r2-reactivity-core.md#u-e2ea8c85735e)

<a id="u-aed941f29bc8"></a>
### `suspend`

`export function suspend()` · [packages/svelte/src/internal/client/reactivity/batch.js:L670-L690][f1]

Registers in-flight async work against the current batch and pending boundary: increments the boundary's pending count, and only when the boundary was not already pending increments the batch, so boundary-held async work does not block batch commit.

The returned `unsuspend` decrements the boundary count; when the boundary was not pending it re-activates and decrements the batch (triggering deferred-effect scheduling at zero), otherwise only deactivates, and always clears the reactive context via `unset_context`.

calls: [get_pending_boundary](r1-client-boundaries.md#u-662729eaf177), [unset_context](r2-async-reactivity.md#u-2e39d8f937d3)

<a id="u-9d57285747d5"></a>
### `Derived`

`export interface Derived<V = unknown> extends Value<V>, Reaction` · [packages/svelte/src/internal/client/reactivity/types.d.ts:L54-L61][f2]

Type declaration only: Derived extends Value and Reaction, narrowing fn and adding effects and parent; no runtime behavior.

<a id="u-2710975de280"></a>
### `Effect`

`export interface Effect extends Reaction` · [packages/svelte/src/internal/client/reactivity/types.d.ts:L63-L94][f2]

Type declaration only: Effect extends Reaction with DOM nodes, fn, teardown, transitions, effect linked-list fields (prev/next/first/last/parent), and boundary b plus dev-only fields; no runtime behavior.

<a id="u-dbffae4ef8ef"></a>
### `Reaction`

`export interface Reaction extends Signal` · [packages/svelte/src/internal/client/reactivity/types.d.ts:L43-L52][f2]

Type declaration only: Reaction extends Signal with ctx, fn, deps, and ac fields; no runtime behavior.

<a id="u-d7be5ea90299"></a>
### `Signal`

`export interface Signal` · [packages/svelte/src/internal/client/reactivity/types.d.ts:L10-L15][f2]

Type declaration only: base shape { f: flags bitmask, wv: write version }; no runtime behavior.

<a id="u-4c170930dd4a"></a>
### `Value`

`export interface Value<V = unknown> extends Signal` · [packages/svelte/src/internal/client/reactivity/types.d.ts:L17-L41][f2]

Type declaration only: Value extends Signal with equals, reactions, rv, v plus optional dev-only fields (label, created, updated, set_during_effect, trace); no runtime behavior.

<a id="u-44fb259a3b22"></a>
### `types.d.ts module code (L1–L9)`

`module_region` · [packages/svelte/src/internal/client/reactivity/types.d.ts:L1-L9][f2]

Type-only import statements; no runtime behavior.

<a id="u-09d9619b4ae2"></a>
### `MaybeSource`

`export type MaybeSource<T = unknown> = T | Source<T>;` · [packages/svelte/src/internal/client/reactivity/types.d.ts:L98-L98][f2]

Type alias: MaybeSource<T> = T | Source<T>; no runtime behavior.

<a id="u-7d1c64b4718d"></a>
### `packages/svelte/src/internal/client/reactivity/types.d.ts:Source`

`export type Source<V = unknown> = Value<V>;` · [packages/svelte/src/internal/client/reactivity/types.d.ts:L96-L96][f2]

Type alias: Source<V> = Value<V>; no runtime behavior.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/reactivity/batch.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/reactivity/types.d.ts
