# svelte:options Reading

**Capability.** Validates <svelte:options> attributes into a static options object: extracts compile-time constant values, enforces boolean attribute rules, and checks custom-element tag names.

read_options is the entry point; get_static_value and get_boolean_value supply static evaluation; validate_tag asserts valid tag names. All units exist solely to serve option validation.

**Depends on.**

- [Compiler Diagnostics](r1-compiler-diagnostics.md) · model-inferred · 0 edge(s)

Parent: [Parse Phase](r1-compiler-parse.md)

## Units (4)

<a id="u-d4c4a2170fce"></a>
### `read_options`

`export default function read_options(node)` · [packages/svelte/src/compiler/phases/1-parse/read/options.js:L10-L195][f1]

Converts the attributes of a <svelte:options> node into a validated AST.SvelteOptions object.

Non-'Attribute' nodes immediately raise e.svelte_options_invalid_attribute. Recognized names: runes/immutable/preserveWhitespace/accessors read a boolean (get_boolean_value errors on non-boolean); 'tag' always errors as deprecated; namespace accepts the SVG/MathML constants, or the literal strings 'html'/'mathml'/'svg', else errors; css accepts only 'injected'; unknown names error. For customElement: a bare true or Text value goes through get_static_value plus validate_tag; an expression that is a null Literal is silently ignored for Svelte 4 backwards compat; anything else non-Object errors. Object form requires non-computed Identifier-keyed properties; 'tag' is validated via validate_tag, 'props' must be an ObjectExpression whose entries are non-computed Identifier keys mapping to ObjectExpressions containing only Literal-valued 'type' (String/Number/Boolean/Array/Object), 'reflect' (boolean) or 'attribute' (string) — any deviation errors; 'shadow' must be 'open' or 'none'; 'extend' is stored as-is. The start/end mirror the options node and attributes are shared by reference.

**Notes.**

- failure: All validation failures go through error constructors from errors.js; the switch has no recovery path.
- condition: Empty/absent attributes yield options with only start, end, and the raw attributes array.

calls: [get_static_value](r1-compiler-parse-options.md#u-6d5fb04e54eb), [get_boolean_value](r1-compiler-parse-options.md#u-afa9e7c8c98c), [validate_tag](r1-compiler-parse-options.md#u-5802e1b7bde8)

**Uncertainties.**

- get_static_value can return null; for namespace that null falls into the final error branch, but for the Text customElement path validate_tag handles it — behavior of validate_tag with null is its own unit.

<a id="u-6d5fb04e54eb"></a>
### `get_static_value`

`function get_static_value(attribute)` · [packages/svelte/src/compiler/phases/1-parse/read/options.js:L200-L217][f1]

Extracts a compile-time constant value from an attribute.

Returns true when the value is a bare true (shorthand) or falsy chunk; returns null when the value has more than one chunk or the single chunk is a non-Literal expression; returns the text data for a Text chunk and the literal value otherwise.

<a id="u-afa9e7c8c98c"></a>
### `get_boolean_value`

`function get_boolean_value(attribute)` · [packages/svelte/src/compiler/phases/1-parse/read/options.js:L222-L228][f1]

Reads an attribute via get_static_value and requires the result to be a boolean, raising e.svelte_options_invalid_attribute_value(attribute, 'true or false') otherwise; returns the boolean.

<a id="u-5802e1b7bde8"></a>
### `validate_tag`

`function validate_tag(attribute, tag)` · [packages/svelte/src/compiler/phases/1-parse/read/options.js:L250-L261][f1]

Asserts a custom-element tag name is valid.

A non-string (including null from get_static_value) raises e.svelte_options_invalid_tagname; an empty string passes silently. Otherwise the name must match the WHATWG custom-element regex (lowercase start, must contain a hyphen, unicode-aware) or e.svelte_options_invalid_tagname is raised, and must not be one of eight reserved names (annotation-xml, color-profile*, font-face*, missing-glyph) or e.svelte_options_reserved_tagname is raised.

**Notes.**

- condition: Empty-string tags bypass both the regex and reserved-name checks.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/1-parse/read/options.js
