# Shared Internals

**Capability.** Runtime infrastructure shared between client and server: deep-cloning/snapshotting of reactive state, shared type contracts (Store, Snapshot, Getters), shared runtime validators for dynamic tags/stores/snippets, generated error throwers, and the mode-enabling flag modules selected by import.

Consumed by both client and server runtimes; validate.js throws via the generated shared errors. Flag modules (async/legacy/tracing) turn modes on as a side effect of being imported.

**Depends on.**

- [Compiler Diagnostics](r1-compiler-diagnostics.md) · model-inferred · 0 edge(s)

**Depended on by.**

- [Server Runtime \(SSR\)](r1-server-runtime.md) · model-inferred · 0 edge(s)

Parent: [Svelte Monorepo](r1-svelte-monorepo.md)

## Units (22)

<a id="u-94a28e8b7f6f"></a>
### `errors-js-error-throwers`

`export function await_outside_boundary()` · [packages/svelte/src/internal/shared/errors.js:L9-L19][f1]

Generated error-throwing helpers; each function never returns.

In dev, every function throws an Error whose name is 'Svelte error', whose message is the error code, the full explanatory text, and a docs URL. In production each throws a plain Error whose message is only the docs URL, to keep the bundle lean. `lifecycle_outside_component(name)` and `store_invalid_shape(name)` interpolate the offending name into the message; the rest are parameterless: await_outside_boundary, invalid_default_snippet, invalid_snippet_arguments, snippet_without_render_tag, and svelte_element_invalid_this_value. These are invoked from runtime code when a lifecycle or snippet/store invariant is violated.

<a id="u-97cc45d9b173"></a>
### `clone`

`function clone(value, cloned, path, paths, original = null, no_tojson = false)` · [packages/svelte/src/internal/shared/clone.js:L57-L137][f2]

Deep-copies a value into a plain, non-reactive snapshot, tracking uncloneable paths.

Non-null objects are looked up in the `cloned` Map first, so shared references and cycles map to the same copy. Maps and Sets are shallow-copied (their entries are not recursed). Arrays are copied index-wise, skipping holes (`i in value` check); plain `Object.prototype` objects are copied key-wise; in dev each element/property path is extended (`[i]`, `.key`). Dates are `structuredClone`d. Objects with a `toJSON` method (unless `no_tojson`) are cloned from their toJSON() output, with the original instance also mapped to the resulting copy so repeated references resolve. EventTargets are returned as-is because they cannot be cloned. Everything else goes through `structuredClone`; on failure the original value is returned, and in dev the current path is pushed onto `paths` so the caller can warn. Prototype-dependent branches rely on `get_prototype_of` and `is_array` from utils.

**Notes.**

- failure: structuredClone failures never propagate: the original (uncloned) value is returned, so snapshots silently contain originals for uncloneable leaves.
- condition: Map and Set copies are shallow — nested reactive objects inside them are not snapshotted, unlike arrays and plain objects.

uses: [is_promise](r6-shared-infra.md#u-f3295568a063); imports: [packages/svelte/src/internal/shared/utils.js][f3]

**Uncertainties.**

- Reactor class instances with non-Object prototypes and no toJSON fall through to structuredClone or EventTarget check; their exact classification for subclasses of Map/Set beyond the instanceof checks is not shown.

<a id="u-bfcc537be9f1"></a>
### `packages/svelte/src/internal/shared/clone.js:snapshot`

`export function snapshot(value, skip_warning = false, no_tojson = false)` · [packages/svelte/src/internal/shared/clone.js:L21-L45][f2]

Returns a reactive-state snapshot of a value via the internal `clone` routine.

In dev, unless `skip_warning` is set, clone collects the paths of uncloneable properties: if the root itself could not be cloned (single empty path), `state_snapshot_uncloneable` is warned with no detail; if any paths were collected, a bulleted list `- <value>...` is warned, truncated to the first 7 entries when more than 10 paths exist with an '...and N more' line. In production, or with `skip_warning`, cloning runs with a shared dummy array and no warning path. `no_tojson` disables `toJSON`-based cloning and passes through to clone.

calls: [clone](r1-shared-internals.md#u-97cc45d9b173), [state_snapshot_uncloneable](r4-runtime-shared.md#u-093aec392ae5)

<a id="u-df550d1db066"></a>
### `clone.js module code (L1–L20)`

`module_region` · [packages/svelte/src/internal/shared/clone.js:L1-L20][f2]

Imports DEV, the warnings module, and shared object/array helpers; defines the `empty` dummy path array used in production snapshots.

<a id="u-e55dbaa0ec3e"></a>
### `clone.js module code (L45–L56)`

`module_region` · [packages/svelte/src/internal/shared/clone.js:L45-L56][f2]

Non-behavioral gap between the snapshot and clone declarations.

<a id="u-d56a943feb43"></a>
### `errors.js module code (L1–L8)`

`module_region` · [packages/svelte/src/internal/shared/errors.js:L1-L8][f1]

Generated-file header and DEV import only; no runtime behavior.

<a id="u-b4fecd2dd9fd"></a>
### `Store.set`

`set(value: V): void` · [packages/svelte/src/internal/shared/types.d.ts:L3-L3][f4]

Type-only member of the Store interface; no implementation.

<a id="u-9fb4fb9882dc"></a>
### `Getters`

`export type Getters<T> = { [K in keyof T]: () => T[K]; };` · [packages/svelte/src/internal/shared/types.d.ts:L6-L8][f4]

Mapped type turning each property into a getter function; type-only.

<a id="u-078f073161ff"></a>
### `packages/svelte/src/internal/shared/types.d.ts:Snapshot`

`export type Snapshot<T> = ReturnType<typeof $state.snapshot<T>>;` · [packages/svelte/src/internal/shared/types.d.ts:L10-L10][f4]

Snapshot<T> derived from $state.snapshot's return type; type-only.

<a id="u-ce5a15ad82e6"></a>
### `Store`

`export type Store<V> = { subscribe: (run: (value: V) => void) => () => void; set(valu…` · [packages/svelte/src/internal/shared/types.d.ts:L1-L3][f4]

Type declarations only: Store<V> requires subscribe and set; no runtime behavior.

<a id="u-ca44493cbca6"></a>
### `packages/svelte/src/internal/shared/types.d.ts:Store`

`export type Store<V> = { subscribe: (run: (value: V) => void) => () => void; set(valu…` · [packages/svelte/src/internal/shared/types.d.ts:L3-L4][f4]

Type declaration fragment; no runtime behavior.

<a id="u-f0c8633de633"></a>
### `prevent_snippet_stringification`

`export function prevent_snippet_stringification(fn)` · [packages/svelte/src/internal/shared/validate.js:L41-L47][f5]

Guards a snippet function against accidental stringification by overwriting its `toString` with a function that throws `snippet_without_render_tag` (returning '' only in the impossible non-throwing path) and returns the same fn.

Any attempt to coerce the snippet to a string (e.g. rendering `{snippet}` instead of `{@render snippet()}`) therefore raises the error.

raises: [errors-js-error-throwers](r1-shared-internals.md#u-94a28e8b7f6f)

<a id="u-718446e58f9d"></a>
### `validate_dynamic_element_tag`

`export function validate_dynamic_element_tag(tag_fn)` · [packages/svelte/src/internal/shared/validate.js:L19-L25][f5]

Throws when a dynamic element tag is neither absent nor a string.

The tag thunk is called once; if the result is truthy and not a string, `svelte_element_invalid_this_value` throws (Svelte error in dev, URL-only Error in prod). Falsy tags (e.g. undefined) pass silently.

raises: [errors-js-error-throwers](r1-shared-internals.md#u-94a28e8b7f6f)

<a id="u-f09c2e0aa53c"></a>
### `validate_store`

`export function validate_store(store, name)` · [packages/svelte/src/internal/shared/validate.js:L31-L35][f5]

Rejects non-store bindings by name: when the store is not null/undefined and has no `subscribe` function, `store_invalid_shape(name)` throws.

Null/undefined stores are permitted, as are any objects with a callable subscribe.

raises: [errors-js-error-throwers](r1-shared-internals.md#u-94a28e8b7f6f)

<a id="u-1787859057c4"></a>
### `validate_void_dynamic_element`

`export function validate_void_dynamic_element(tag_fn)` · [packages/svelte/src/internal/shared/validate.js:L11-L16][f5]

Warns when a `<svelte:element>` resolves to a void tag.

It calls the supplied tag thunk once and, if the resulting tag is truthy and classified void by `is_void`, emits the `dynamic_void_element_content` warning; non-void or falsy tags are silent. The thunk is invoked eagerly, so validation occurs when called.

calls: [utils.js-element-attribute-predicates](r5-compiler-utilities.md#u-57e79fafa2c2), [dynamic_void_element_content](r4-runtime-shared.md#u-166c10327168)

<a id="u-235bb6f1002d"></a>
### `validate.js module code (L1–L10)`

`module_region` · [packages/svelte/src/internal/shared/validate.js:L1-L10][f5]

Re-exports `invalid_default_snippet` from errors.js alongside the local imports of is_void, warnings (w), and errors (e).

<a id="u-0f82513768a8"></a>
### `validate.js module code (L16–L18)`

`module_region` · [packages/svelte/src/internal/shared/validate.js:L16-L18][f5]

Non-behavioral gap between validate functions.

<a id="u-6d4a96dbec9e"></a>
### `validate.js module code (L25–L30)`

`module_region` · [packages/svelte/src/internal/shared/validate.js:L25-L30][f5]

Non-behavioral gap between validate functions.

<a id="u-8dbb0545f515"></a>
### `validate.js module code (L35–L40)`

`module_region` · [packages/svelte/src/internal/shared/validate.js:L35-L40][f5]

Non-behavioral gap between validate functions.

<a id="u-414671c193d0"></a>
### `async.js module code (L1–L3)`

`module_region` · [packages/svelte/src/internal/flags/async.js:L1-L3][f6]

Side-effectful module: importing it calls enable_async_mode_flag(), turning the async mode flag on at import time.

Used to opt a build into async mode via module selection rather than an API call.

calls: [enable_async_mode_flag](r4-runtime-shared.md#u-8e5eb2967954)

<a id="u-109b602dff80"></a>
### `legacy.js module code (L1–L3)`

`module_region` · [packages/svelte/src/internal/flags/legacy.js:L1-L3][f7]

Side-effectful module: importing it calls enable_legacy_mode_flag(), enabling legacy mode at import time via module selection rather than an API call.

calls: [enable_legacy_mode_flag](r4-runtime-shared.md#u-0c177e01fbd2)

<a id="u-69417271d161"></a>
### `tracing.js module code (L1–L3)`

`module_region` · [packages/svelte/src/internal/flags/tracing.js:L1-L3][f8]

Side-effectful module: importing it calls enable_tracing_mode_flag(), enabling tracing mode at import time via module selection rather than an API call.

calls: [enable_tracing_mode_flag](r4-runtime-shared.md#u-76b26958c1d1)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/shared/errors.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/shared/clone.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/shared/utils.js
[f4]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/shared/types.d.ts
[f5]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/shared/validate.js
[f6]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/flags/async.js
[f7]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/flags/legacy.js
[f8]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/flags/tracing.js
