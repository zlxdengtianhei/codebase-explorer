# Dev-Mode Diagnostics

**Capability.** Development-only introspection: tracing of reactive reads/updates, $inspect effect implementation, and console logging with reactive state replaced by snapshots.

Use when debugging reactivity behavior in dev. These modules are dev-guarded and not part of production rendering.

**Depended on by.**

- [Client Reactivity Core](r6-client-reactivity.md) · graph-confirmed · 1 edge(s)
- [Spring Motion](r6-motion.md) · graph-confirmed · 7 edge(s)
- [Reactive Browser Values](r6-reactive-values.md) · graph-confirmed · 1 edge(s)
- [Reactive Built-ins](r5-reactive-builtins.md) · graph-only · 18 edge(s)
- [Client Runtime Reactivity](r5-runtime-reactivity.md) · graph-only · 12 edge(s)

Parent: [Client Runtime](r6-runtime-client.md)

## Units (3)

<a id="u-fb7046392fad"></a>
### `tracing.js-reactive-tracing`

`function log_entry(signal, entry)` · [packages/svelte/src/internal/client/dev/tracing.js:L22-L74][f1]

Dev-time tracing of reactive reads and updates.

trace(label, fn) records a fresh tracing_expressions entry map, runs fn timed with performance.now, restores the previous tracing_expressions in finally, then reports: outside an effect it logs 'ran outside of an effect'; inside an effect with no recorded entries it logs 'no reactive dependencies'; otherwise it opens a console group and logs each recorded signal via log_entry untracked. log_entry prints a collapsed group labeled with the signal type (get_type: '$derived' when DERIVED or ASYNC flags set, 'store' when the label starts with '$', else '$state'), a dirty style when signal.wv exceeds the active reaction's wv or the reaction wv is 0, and a snapshotted value for state objects; for deriveds it recursively logs deps, and it appends the created stack and dirty-update errors plus any supplied trace stacks. get_stack(label) builds an Error, filters its stack (dropping 'Error' lines, internal svelte/src/internal frames, and returning null entirely if validate_each_keys appears), and returns null when nothing remains; otherwise it redefines the error's stack to the filtered lines and its name to `${label}Error`. tag(source, label) sets source.label and forwards source.v to tag_proxy, which invokes value?.[PROXY_PATH_SYMBOL]?.(label) to propagate the label into proxies. label(value) renders symbols with their description, functions and objects as placeholders, everything else via String.

**Notes.**

- contract: tracing_expressions is a module-level mutable export; other modules record entries into it while trace's fn runs.

calls: [tracing.js-reactive-tracing](r6-client-dev.md#u-fb7046392fad)

**Uncertainties.**

- Which code paths populate tracing_expressions.entries is not visible in this file.
- get_stack's filtering heuristics (validate_each_keys, internal frames) depend on stack formats of the host engine.

<a id="u-5bbd41443b98"></a>
### `log_if_contains_state`

`export function log_if_contains_state(method, ...objects)` · [packages/svelte/src/internal/client/dev/console-log.js:L10-L35][f2]

Logs console arguments with reactive state replaced by plain snapshots, returning the original arguments untouched.

Inside untrack, each argument that is a non-null object with STATE_SYMBOL is replaced by snapshot(obj, true); others pass through. If at least one object contained state, it emits the console_log_state warning and prints a grey '[snapshot]' prefix plus the transformed values. The entire body is inside try/catch with an empty catch, so any error is silently swallowed and the original arguments are still returned.

**Notes.**

- failure: All detection/printing errors are suppressed by an empty catch; only the returned objects are guaranteed.

calls: [untrack](r2-reactivity-core.md#u-aa0e067da463), [packages/svelte/src/internal/shared/clone.js:snapshot](r1-shared-internals.md#u-bfcc537be9f1)

<a id="u-da1d251f1f86"></a>
### `inspect`

`export function inspect(get_value, inspector = console.log)` · [packages/svelte/src/internal/client/dev/inspect.js:L11-L55][f3]

Implements $inspect: an inspect_effect reads get_value(), snapshots the result, and calls the inspector (default console.log) untracked with 'init' on the first run and 'update' afterwards.

If reading get_value() throws, the error is stored and the inspector is not called. A companion render_effect re-calls get_value() (ignoring errors) and, when a stored error exists, logs it via console.error and resets it, so errors surface with stack traces only if the effect is still alive; per the comments, if the render effect never runs the inspect was destroyed. validate_effect('$inspect') enforces the calling context.

**Notes.**

- failure: get_value() throwing inside the inspect_effect does not propagate; it is deferred to the render_effect's console.error.

calls: [effects.js-effect-creators](r3-effects-engine.md#u-27c9c7c4069f), [packages/svelte/src/internal/shared/clone.js:snapshot](r1-shared-internals.md#u-bfcc537be9f1), [untrack](r2-reactivity-core.md#u-aa0e067da463)

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dev/tracing.js
[f2]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dev/console-log.js
[f3]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dev/inspect.js
