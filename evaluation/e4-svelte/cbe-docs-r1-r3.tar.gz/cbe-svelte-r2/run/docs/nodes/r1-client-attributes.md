# Attribute Synchronization

**Capability.** Sets and diffs element attributes/properties reactively: per-attribute writes with hydration awareness, spread handling, custom element data, form-element special cases (value/checked/selected/defaults), and URL/srcset equality helpers used for dev hydration checks.

attribute_effect creates the reactive effect; set_attributes/set_attribute do the writes; get_attributes/get_setters provide caching and prototype-chain setter discovery. Use src_url_equal/srcset_url_equal via check_src_in_dev_hydration for dev-only mismatch warnings.

**Depends on.**

- [Client Runtime](r1-client-runtime.md) · within containment · 4 edge(s)

Parent: [Client Runtime](r1-client-runtime.md)

## Units (17)

<a id="u-dfc6319c1edb"></a>
### `attribute_effect`

`export function attribute_effect( element, fn, sync = [], async = [], css_hash, skip_…` · [packages/svelte/src/internal/client/dom/elements/attributes.js:L472-L528][f1]

Creates a reactive effect that keeps an element's attributes in sync with attribute expressions.

flatten(sync, async, cb) invokes the callback with resolved values; inside, a block effect calls fn(...values.map(get)) to compute the next attribute object and applies it with set_attributes, using the previous result as prev. For SELECT elements, when initialized and next has a 'value' key it re-selects via select_option. Symbol-keyed next entries with ATTACHMENT_KEY description create or destroy attachment effects via attach/branch/destroy_effect when their value changes; stale attachment effects whose next value is falsy are destroyed. If the element is a SELECT, a separate effect re-applies prev.value and initializes the select after the block runs.

calls: [set_attributes](r1-client-attributes.md#u-a86deb1351f3), [flatten](r2-async-reactivity.md#u-c50793421b66), [select_option](r5-runtime-dom.md#u-fc6c91d49336), [init_select](r5-runtime-dom.md#u-f378be747d77), [attach](r4-client-dom-blocks.md#u-89b96e9f81b2), [destroy_effect](r3-effects-engine.md#u-214ad59ce57a), [packages/svelte/src/internal/client/reactivity/effects.js:block](r3-effects-engine.md#u-75d755e7c63c), [effects.js-effect-creators](r3-effects-engine.md#u-27c9c7c4069f)

<a id="u-d95a79442ce3"></a>
### `check_src_in_dev_hydration`

`function check_src_in_dev_hydration(element, attribute, value)` · [packages/svelte/src/internal/client/dom/elements/attributes.js:L580-L590][f1]

In DEV only, warns during hydration when a src/srcset/href attribute set on the client may differ from the server-rendered one.

For srcset it compares with srcset_url_equal; otherwise with src_url_equal against the element's current attribute; if either comparison reports equality it stays silent, otherwise it calls the hydration_attribute_changed warning with a truncated outerHTML and the new value.

<a id="u-fd27450a93d7"></a>
### `get_attributes`

`function get_attributes(element)` · [packages/svelte/src/internal/client/dom/elements/attributes.js:L534-L542][f1]

Returns (lazily creating) the element's __attributes cache object; on creation it records whether the element is a custom element (node name contains '-') and whether its namespace is HTML.

This cache backs change detection throughout this module.

<a id="u-0d26f84d109d"></a>
### `get_setters`

`function get_setters(element)` · [packages/svelte/src/internal/client/dom/elements/attributes.js:L548-L573][f1]

Returns the cached list of property names with setters for an element's tag (or 'is' extension name), computed by walking the prototype chain from the instance to but not including Element.prototype and collecting descriptor keys that have a setter.

Results are memoized per cache key in a module-level Map, so an element queried before its custom element is registered keeps the earlier (possibly smaller) setter list.

**Uncertainties.**

- Cache entries are never invalidated, so setters added after first computation are not seen; whether any caller clears the cache is not visible here.

<a id="u-35e5f0c9db54"></a>
### `remove_input_defaults`

`export function remove_input_defaults(input)` · [packages/svelte/src/internal/client/dom/elements/attributes.js:L39-L48][f1]

Removes an input's value/checked default attributes during hydration while preserving live property values.

It returns immediately unless hydrating. Its remove_defaults closure is stored on input.__on_r for the global form-reset listener and also queued as an idle task, so removal happens on idle or just before a form reset, whichever comes first; an already_removed flag makes it idempotent. For each attribute present it snapshots the DOM property, removes the attribute, then restores the property value. It also triggers one-time global form-reset listener registration.

calls: [set_attribute](r1-client-attributes.md#u-475e532b1c41), [add_form_reset_listener](r6-client-dom-elements.md#u-3524dfa24535), [queue_idle_task](r6-client-dom-task.md#u-74329185432d)

<a id="u-475e532b1c41"></a>
### `set_attribute`

`export function set_attribute(element, attribute, value, skip_warning)` · [packages/svelte/src/internal/client/dom/elements/attributes.js:L162-L200][f1]

Sets, updates, or removes a single attribute with hydration-aware skipping.

During hydration it records the server-rendered attribute value into the __attributes cache; for src, srcset, and href on LINK elements it warns in dev (unless skip_warning) but returns without writing, since rewriting these could trigger a network request — this skip applies regardless of whether values actually match. Otherwise it returns early when the cached value is unchanged; records the loading value under LOADING_ATTR_SYMBOL; removes the attribute when value is null; assigns as a property when value is non-string and the element prototype chain has a setter; otherwise calls setAttribute.

uses: [get_attributes](r1-client-attributes.md#u-fd27450a93d7), [get_setters](r1-client-attributes.md#u-0d26f84d109d); calls: [check_src_in_dev_hydration](r1-client-attributes.md#u-d95a79442ce3)

<a id="u-a86deb1351f3"></a>
### `set_attributes`

`export function set_attributes(element, prev, next, css_hash, skip_warning = false)` · [packages/svelte/src/internal/client/dom/elements/attributes.js:L274-L388][f1]

Spreads a next attribute object onto an element, mutating next (missing prev keys become null) and returning the merged current object used as the next call's prev.

Class and style keys are diverted to set_class/set_style after normalizing class via clsx, forcing a set_class/set_style call when css_hash or the CLASS/STYLE symbol is present. For an OPTION element a null/undefined value sets value to '' (a known unfixable edge case: an explicitly set null value can never later be removed). During hydration of a Svelte custom element, hydration mode is temporarily disabled and restored at the end. For each key: 'on'-prefixed keys configure events — delegated events are stored as element.__<event> with delegate(); non-delegated events reuse the existing listener when only the handler changed (value non-null), remove the prior listener when value becomes null, and otherwise create a listener via create_event whose handle closure calls the latest current[key] handler, so handler identity changes do not require re-subscription. capture events strip the 'capture' suffix and set capture option. 'style' goes through set_attribute to avoid the setter; 'autofocus' calls autofocus; '__value' and value (non-null) set element.value = element.__value = value except on custom elements; 'selected' on options calls set_selected. Remaining keys are case-normalized when not HTML: null values remove the attribute (with special preservation of defaultValue/defaultChecked when removing value/checked, restoring live value only when prev is undefined for initial render, otherwise null/false); defaultValue/defaultChecked or non-string values on setter-backed properties are assigned directly as properties (cached as UNINITIALIZED in __attributes); other non-function values go through set_attribute. Keys prefixed '$$' are skipped.

uses: [get_attributes](r1-client-attributes.md#u-fd27450a93d7); calls: [set_class](r3-element-bindings.md#u-085f1a439acb), [set_style](r4-element-bindings.md#u-dd07311bde30), [set_attribute](r1-client-attributes.md#u-475e532b1c41), [set_selected](r1-client-attributes.md#u-1e6158ce232f), [autofocus](r6-client-dom-elements.md#u-7f00a79795f4), [create_event](r2-dom-elements.md#u-523dfbad5fa3), [delegate](r2-dom-elements.md#u-cf26b665744a)

**Uncertainties.**

- The interaction of IS_CUSTOM_ELEMENT/IS_HTML flags with elements whose __attributes cache was initialized elsewhere is not visible in this file.

<a id="u-ab3720cbd1ab"></a>
### `set_checked`

`export function set_checked(element, checked)` · [packages/svelte/src/internal/client/dom/elements/attributes.js:L99-L113][f1]

Sets an element's checked property guarded by the __attributes cache: returns early when the cached checked equals the incoming value after normalizing null to undefined; otherwise assigns element.checked = checked.

uses: [get_attributes](r1-client-attributes.md#u-fd27450a93d7)

<a id="u-0c7dcf045f92"></a>
### `set_custom_element_data`

`export function set_custom_element_data(node, prop, value)` · [packages/svelte/src/internal/client/dom/elements/attributes.js:L216-L263][f1]

Sets a property or attribute on a custom element while detaching the write from the current active reaction and effect, and temporarily disabling hydration mode so an already-scaffolded Svelte custom element cannot run block logic mid-hydration.

A finally block restores reaction, effect, and hydrating state even if the write throws from custom element lifecycle code. Property assignment is used when prop is not 'style' and either the element's tag/is name is in the setters cache, customElements is unavailable, or the element is registered and has a setter for prop; for unregistered elements it assigns only when value is a non-null object. All other cases call set_attribute with the value stringified first (null passes through) to avoid re-running setter detection and populating the setters cache early.

calls: [set_attribute](r1-client-attributes.md#u-475e532b1c41), [set_hydrating](r1-client-runtime.md#u-dd47d7c92d42); uses: [get_setters](r1-client-attributes.md#u-0d26f84d109d)

<a id="u-05d7d561d9ac"></a>
### `set_default_checked`

`export function set_default_checked(element, checked)` · [packages/svelte/src/internal/client/dom/elements/attributes.js:L139-L143][f1]

Updates defaultChecked without disturbing the live state: snapshots element.checked, assigns defaultChecked, then restores the snapshot.

<a id="u-6d856c0650f4"></a>
### `set_default_value`

`export function set_default_value(element, value)` · [packages/svelte/src/internal/client/dom/elements/attributes.js:L150-L154][f1]

Updates defaultValue without disturbing the live state: snapshots element.value, assigns defaultValue, then restores the snapshot.

<a id="u-1e6158ce232f"></a>
### `set_selected`

`export function set_selected(element, selected)` · [packages/svelte/src/internal/client/dom/elements/attributes.js:L122-L132][f1]

Reflects an option's selected state as the selected attribute rather than the property, because the property does not reflect to the DOM and would be lost on form reset.

When selected is true it sets the attribute only if absent, avoiding clobbering a later user selection; when false it removes the attribute unconditionally.

<a id="u-2c42d298a226"></a>
### `set_value`

`export function set_value(element, value)` · [packages/svelte/src/internal/client/dom/elements/attributes.js:L76-L93][f1]

Sets an element's value property, skipping redundant writes via the __attributes cache: it returns when the cached value equals the new value (null normalized to undefined), or when element.value already equals the value unless the element is a PROGRESS whose value is 0, since progress always needs an explicit set at 0.

Otherwise assigns element.value = value ?? '', so null/undefined become an empty string.

uses: [get_attributes](r1-client-attributes.md#u-fd27450a93d7)

<a id="u-ddd420e3d016"></a>
### `set_xlink_attribute`

`export function set_xlink_attribute(dom, attribute, value)` · [packages/svelte/src/internal/client/dom/elements/attributes.js:L207-L209][f1]

Sets an XLink-namespaced attribute via setAttributeNS with no change detection.

<a id="u-b4728141ef31"></a>
### `split_srcset`

`function split_srcset(srcset)` · [packages/svelte/src/internal/client/dom/elements/attributes.js:L603-L605][f1]

Splits a srcset string on commas into candidate descriptors, each trimmed and split on spaces with empty tokens filtered out.

<a id="u-057a89d5095d"></a>
### `src_url_equal`

`function src_url_equal(element_src, url)` · [packages/svelte/src/internal/client/dom/elements/attributes.js:L597-L600][f1]

Compares two URLs for equality: true when the strings match, otherwise true when both resolve to the same absolute href against document.baseURI.

<a id="u-c92d9284b6f0"></a>
### `srcset_url_equal`

`function srcset_url_equal(element, srcset)` · [packages/svelte/src/internal/client/dom/elements/attributes.js:L612-L629][f1]

Compares an element's srcset with a candidate srcset: equal only if both have the same number of candidates, each with matching width descriptor and URLs that match in either direction when resolved against baseURI.

Bidirectional comparison is required because bundlers and browsers may leave relative URLs in srcset unresolved.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/internal/client/dom/elements/attributes.js
