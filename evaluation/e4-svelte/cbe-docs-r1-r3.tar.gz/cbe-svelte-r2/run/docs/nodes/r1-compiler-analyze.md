# Analyze Phase

**Capability.** Semantic validation and scope/reactivity tracking over the parsed AST: per-node visitors enforce placement, naming, and assignment rules, shared utils centralize common invariants, and a cycle detector guards dependency graphs.

Visitors delegate shared invariants to the shared-utils node, so validation-policy changes usually land there while visitor files encode node-specific checks. check_graph_for_cycles is a standalone graph utility.

**Children.**

- [Analysis Visitors](r1-compiler-analyze-visitors.md) `r1-compiler-analyze-visitors` · 15 unit(s)
- [Analysis Shared Validation](r1-compiler-analyze-shared-utils.md) `r1-compiler-analyze-shared-utils` · 9 unit(s)

Parent: [Svelte Compiler](r1-compiler.md)

## Units (1)

<a id="u-9450956ffc9b"></a>
### `check_graph_for_cycles`

`export default function check_graph_for_cycles(edges)` · [packages/svelte/src/compiler/phases/2-analyze/utils/check_graph_for_cycles.js:L6-L25][f1]

Detects a dependency cycle in a directed graph given as [u, v] edge pairs and returns one cycle's node list, or undefined.

Builds an adjacency map (creating entries for both endpoints), then depth-first searches from every node using visited and on_stack sets. The folded visit function marks a node visited and on-stack, recurses into unvisited neighbors, records [...on_stack, w] as a cycle when it meets an on-stack neighbor, and removes the node from the stack on exit. The first recorded cycle is returned; recursion depth equals graph depth, so very deep graphs could overflow the stack.

**Uncertainties.**

- The returned cycle list is in stack order and may contain repeated traversal artifacts; whether it is a minimal cycle is not guaranteed by the code.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/packages/svelte/src/compiler/phases/2-analyze/utils/check_graph_for_cycles.js
