# Dev Environment Configuration

**Capability.** Repository-level development configuration: shared Vitest settings and a Vite/Svelte sandbox dev server exercising SSR with compiler options tuned for iteration.

Use this subtree when adjusting the developer workflow. The sandbox config keeps the local svelte package unoptimized to avoid forced restarts and enables experimental compiler options; vitest.config.js defines test settings for the whole repo.

Parent: [Tooling and Developer Environment](r3-tooling.md)

## Units (4)

<a id="u-00b4d70b764d"></a>
### `ssr-dev.js module code (L1–L39)`

`module_region` · [playgrounds/sandbox/ssr-dev.js:L1-L39][f1]

Runs a Vite-middleware dev server rendering App.svelte on each request.

NODE_ENV is forced to 'development'; PORT (default 5173) selects the listen port. For every request it re-reads index.html, applies Vite's HTML transform, ssr-loads /src/App.svelte fresh (so edits are picked up without restart), renders head/body, and substitutes them into the <!--ssr-head--> and <!--ssr-body--> placeholders. It also wraps a hard-coded phone number in a tel: link to check Safari does not break hydration. Responses are always 200 text/html.

**Uncertainties.**

- Any error while reading, transforming, loading, or rendering propagates to polka/Vite middleware handling; local fallback behavior is not defined here.

<a id="u-a065383f67c4"></a>
### `svelte.config.js module code (L1–L9)`

`module_region` · [playgrounds/sandbox/svelte.config.js:L1-L9][f2]

Svelte compiler configuration for the sandbox: disables HMR and enables the experimental async option.

<a id="u-05c7b53c4e26"></a>
### `vite.config.js module code (L1–L16)`

`module_region` · [playgrounds/sandbox/vite.config.js:L1-L16][f3]

Vite configuration for the sandbox: disables build minification, enables the vite-plugin-inspect and Svelte plugins, and excludes the local workspace 'svelte' package from dependency pre-optimization, since optimizing it would force dev-server restarts with --force on every change.

<a id="u-cfeb87e5efa3"></a>
### `vitest.config.js module code (L1–L46)`

`module_region` · [vitest.config.js:L1-L46][f4]

Defines the shared Vitest configuration for the Svelte repository.

It reads packages/svelte/package.json at load time to build a resolve alias that maps any 'svelte/...' import to the matching package export path, then returns a config object with test discovery globs, reporters, exclusions, and v8 coverage settings.

**Notes.**

- side_effect: The module synchronously reads and JSON-parses packages/svelte/package.json via fs.readFileSync at load time; a missing or malformed file makes importing this config throw.
- condition: In customResolver, if id equals the literal string 'undefined' it is treated as the root '.' export (a commented workaround), otherwise 'undefined' inside the id is replaced with './' before the pkg.exports lookup.
- failure: If the id is not found in pkg.exports, customResolver returns undefined, leaving resolution to the default resolver behavior rather than throwing.
- contract: The customResolver picks exported.default when the importing file path contains '_output/server' (server build), and otherwise prefers exported.browser with a fallback to exported.default, resolving against 'packages/svelte'.

**Uncertainties.**

- The replacement of 'undefined' with './' in non-root ids relies on the comment-documented quirk that ids arrive containing 'undefined'; whether the first occurrence or all occurrences are replaced (String.replace replaces only the first) is unverified against actual id shapes.
- Whether Vitest/Rollup honors a returned undefined from customResolver as a pass-through is assumed, not proven from this source.

## Look up code

`RUN` is the run directory. Find `ID` by a unit title on this page (exact names first):
`cbe find --run-dir "$RUN" --term "UNIT_TITLE"`. Then use an `ID` from the results:
`cbe query --run-dir "$RUN" --id "$ID"`; `cbe source --run-dir "$RUN" --id "$ID" --context 2`.

[f1]: ../../../../../../eval/svelte-be645b4/playgrounds/sandbox/ssr-dev.js
[f2]: ../../../../../../eval/svelte-be645b4/playgrounds/sandbox/svelte.config.js
[f3]: ../../../../../../eval/svelte-be645b4/playgrounds/sandbox/vite.config.js
[f4]: ../../../../../../eval/svelte-be645b4/vitest.config.js
