# client_runtime_core_sources

## 1. Introduction

`client_runtime_core_sources` is the **writable-signal layer** of Svelte's client-side reactive runtime. It lives in `packages/svelte/src/internal/client/reactivity/sources.js` and defines where *data enters* the signal graph: every `$state(...)` variable, every deep proxy property, and every compiled `x++` / `++x` mutation ultimately becomes a write to a **source signal** managed by this module.

The module has three jobs:

1. **Factory functions** (`source`, `state`, `mutable_source`) that create the plain-object signal records consumed by the rest of the engine.
2. **The single write path** (`set` → `internal_set`) that validates, versions, batches and propagates every mutation — plus the numeric convenience operators `update`, `update_pre` and `increment` (the module's named core components).
3. **Dirty propagation** (`mark_reactions`) that flips downstream reactions (deriveds, block effects, DOM effects) to `DIRTY`/`MAYBE_DIRTY` and schedules their re-execution.

It is one slice of the broader reactive engine; the full picture is described in [client_runtime_core](client_runtime_core.md) and its siblings ([client_runtime_core_runtime](client_runtime_core_runtime.md), [client_runtime_core_batching](client_runtime_core_batching.md), [client_runtime_core_deriveds](client_runtime_core_deriveds.md), [client_runtime_core_proxies](client_runtime_core_proxies.md)).

---

## 2. Module Responsibilities

| Responsibility | Implementation | Notes |
|---|---|---|
| Signal creation | `source`, `state`, `mutable_source` | Plain objects `{ f, v, reactions, equals, rv, wv }` + dev tracing fields |
| Guarded writes | `set`, `internal_set` | Unsafe-mutation detection, proxying, equality short-circuit, batching |
| Numeric operators | `update`, `update_pre`, `increment` | Compiled forms of `x++`, `++x`, internal bookkeeping |
| Deep mutation | `mutate` | Re-sets a proxied object to itself to trigger propagation |
| Dirty propagation | `mark_reactions` | Recursively marks deriveds `MAYBE_DIRTY`, schedules effects |
| `$inspect` support | `inspect_effects`, `set_inspect_effects`, `set_inspect_effects_deferred`, `flush_inspect_effects` | Dev-only immediate flush semantics |
| Teardown consistency | `old_values` | Value map consulted by `runtime.get` while an effect is being destroyed |

Out of scope for this module (documented elsewhere): effect scheduling/flushing ([client_runtime_core_batching](client_runtime_core_batching.md), [client_runtime_core_effects](client_runtime_core_effects.md)), lazy derived evaluation ([client_runtime_core_deriveds](client_runtime_core_deriveds.md)), deep reactivity proxies ([client_runtime_core_proxies](client_runtime_core_proxies.md)), and prop/store bridging ([client_runtime_core_props](client_runtime_core_props.md), [client_runtime_core_stores](client_runtime_core_stores.md)).

---

## 3. Architecture

### 3.1 Position in the Reactive Engine

`sources.js` sits at the **entry point of the write half** of the signal graph. Reads flow through `runtime.get`; writes flow through `set`/`internal_set` here. Everything below is downstream of this module.

```mermaid
flowchart TB
    subgraph producers["Value Producers (who writes)"]
        GEN["Compiler-emitted client code<br/>x++, ++x, x-- , deep mutations"]
        PROPS["props.js<br/>update_prop / update_pre_prop"]
        STORES["store.js<br/>update_store / update_pre_store"]
        PX["proxy.js<br/>deep $state proxies"]
        MOTION["motion / bindings / DOM blocks"]
    end

    subgraph SOURCES["sources.js (this module)"]
        FACT["Factories<br/>source / state / mutable_source"]
        NUM["Numeric updates<br/>update / update_pre / increment"]
        WRITE["Write path<br/>set / internal_set / mutate"]
        MARK["Propagation<br/>mark_reactions"]
        DEVST["Dev state<br/>inspect_effects / old_values"]
    end

    subgraph infra["Reactive infrastructure"]
        RT["runtime.js<br/>get, set_signal_status,<br/>increment_write_version,<br/>untracked_writes, is_dirty"]
        BATCH["batch.js<br/>Batch.ensure / capture,<br/>schedule_effect, eager_block_effects"]
        DER["deriveds.js<br/>execute_derived"]
        EFF["effects.js / async.js<br/>effect re-execution"]
    end

    subgraph support["Platform services"]
        EQ["equality.js<br/>equals / safe_equals"]
        ERR["errors.js<br/>state_unsafe_mutation"]
        TRC["dev/tracing.js<br/>get_stack / tag_proxy"]
        FLAGS["flags<br/>legacy_mode_flag / tracing_mode_flag"]
    end

    producers --> NUM
    producers --> WRITE
    NUM --> WRITE
    PX --> FACT
    FACT --> EQ
    FACT --> FLAGS
    FACT --> TRC
    WRITE --> EQ
    WRITE --> RT
    WRITE --> BATCH
    WRITE --> DER
    WRITE --> ERR
    WRITE --> TRC
    MARK --> RT
    MARK --> BATCH
    BATCH --> EFF
    RT --> EFF
```

### 3.2 Anatomy of a Source Signal

A source is deliberately minimal — a plain object so the engine can swap fields cheaply and stay tree-shakeable:

```js
{
  f: 0,            // status flags bitmask (CLEAN / DIRTY / DERIVED / UNOWNED / ...)
  v,               // current value
  reactions: null, // list of reactions (deriveds + effects) that read this signal
  equals,          // equality function (equals | safe_equals) — see signal_model
  rv: 0,           // read version — bumped when read by the current reaction cycle
  wv: 0            // write version — monotonic counter for batch/consistency checks
}
```

In dev/tracing mode ([client_dev_mode](client_dev_mode.md)) the factory additionally attaches `created` / `updated` / `set_during_effect` / `trace` metadata captured via `get_stack` / `tag_proxy`.

- The **type contract** (`Signal`, `Source`, `Value`) is defined in [client_runtime_core_signal_model](client_runtime_core_signal_model.md).
- Equality strategy matters here: `source()` defaults to strict `equals` (`===`); `mutable_source()` upgrades to `safe_equals` so object mutations and `NaN` changes still propagate.

---

## 4. Public Surface

### 4.1 Signal factories

| Function | Purpose |
|---|---|
| `source(v, stack)` | Base factory. Returns a clean, strict-equality source. |
| `state(v, stack)` | `source` + `push_reaction_value` — used for `$state` rune bindings created inside component initialisation. |
| `mutable_source(initial, immutable, trackable)` | Sources for mutable/legacy state. `immutable=false` switches to `safe_equals`; in `legacy_mode_flag` it registers the signal on `component_context.l.s` so `beforeUpdate`/`afterUpdate` can observe writes. |

### 4.2 Write path — `set` / `internal_set` / `mutate`

`set(source, value, should_proxy)` is the **only** sanctioned entry point for writes:

1. **Unsafe-mutation guard** — in runes mode, writing while the active reaction is a `DERIVED`, `BLOCK_EFFECT`, `ASYNC` or `INSPECT_EFFECT` (and the source is not one of the currently-being-read `current_sources`) throws `state_unsafe_mutation` (see [client_runtime_core_diagnostics](client_runtime_core_diagnostics.md)).
2. **Proxying** — `should_proxy=true` wraps the value with `proxy()` from [client_runtime_core_proxies](client_runtime_core_proxies.md); dev mode then tags the proxy with the signal label.
3. Delegates to `internal_set`.

`internal_set(source, value)` performs the real state transition:

- **Equality short-circuit**: if `source.equals(value)` is true, nothing happens (no re-render storm from identical writes).
- **Teardown bookkeeping**: stores values in `old_values` — the *new* value if the current effect is being destroyed (so cleanup code observes the latest value), otherwise the *old* value (so `get` during teardown can rewind).
- **Batch capture**: `Batch.ensure().capture(source, old_value)` records the before/after pair on the active [batch](client_runtime_core_batching.md), enabling multi-batch "time travel" in async mode.
- **Dev tracing**: records a `source.updated` stack-trace map and a `set_during_effect` flag when `active_effect !== null`.
- **Dirty derived special case**: assigning to a `DIRTY` derived eagerly calls `execute_derived` (from [client_runtime_core_deriveds](client_runtime_core_deriveds.md)) to track its dependencies, then settles its status to `CLEAN` or `MAYBE_DIRTY` (`UNOWNED` → `MAYBE_DIRTY`).
- **Versioning**: `source.wv = increment_write_version()` — the global write counter used by consistency checks.
- **Propagation**: `mark_reactions(source, DIRTY)`.
- **Self-write in clean effect**: if the write happened inside a `CLEAN` non-branch effect (e.g. `$effect(() => x++)`), the source is appended to `untracked_writes` so the effect itself still gets scheduled.
- **Inspect flushing**: dev-only — pending `$inspect` effects run immediately unless deferred.

`mutate(source, value)` is the deep-mutation primitive (compiled form of `state.field++` on proxied objects): it re-reads the current value **untracked** and writes it back, so object identity is preserved while all reactions re-fire.

### 4.3 Numeric update operators (core components)

These are the module's named core components — the runtime counterparts of JavaScript increment/decrement expressions emitted by the compiler back-end (see [Compiler_Back-End_(Client___Server_Code_Generation)](Compiler_Back-End_(Client___Server_Code_Generation).md), client visitors such as `UpdateExpression` handling):

```js
// post-increment / post-decrement:  x++ , x--
export function update(source, d = 1) {
    var value = get(source);          // tracked read → registers dependency
    var result = d === 1 ? value++ : value--;
    set(source, value);               // write new value → full propagation pipeline
    return result;                    // returns the OLD value
}

// pre-increment / pre-decrement:  ++x , --x
export function update_pre(source, d = 1) {
    var value = get(source);
    return set(source, d === 1 ? ++value : --value); // returns the NEW value
}

// untracked internal increment (never registers a dependency)
export function increment(source) {
    set(source, source.v + 1);
}
```

| Call | Read | Write | Returns | JS equivalent |
|---|---|---|---|---|
| `update(s)` / `update(s, d)` | `get(s)` (tracked) | `s + d` / `s - d` | previous value | `x++` / `x--` |
| `update_pre(s)` / `update_pre(s, d)` | `get(s)` (tracked) | `s + d` / `s - d` | new value | `++x` / `--x` |
| `increment(s)` | none (uses `s.v` directly) | `s.v + 1` | — | internal counters (e.g. proxy version bumps) |

Both `update` and `update_pre` are typed to `number | bigint` sources. The **tracked** `get` call is what makes `x++` inside an effect establish a dependency on `x` — combined with the `untracked_writes` handling inside `internal_set`, this is what lets `$effect(() => x++)` re-run without infinite synchronous recursion.

Sibling modules mirror the *same get/set contract* for their own value holders rather than wrapping raw sources:

| Module | Post form | Pre form | Backing storage |
|---|---|---|---|
| **sources** (this module) | `update(source)` | `update_pre(source)` | raw source signal |
| [props](client_runtime_core_props.md) | `update_prop(fn)` | `update_pre_prop(fn)` | getter/setter accessor pair |
| [stores](client_runtime_core_stores.md) | `update_store(store, v)` | `update_pre_store(store, v)` | store `.set()` contract |

### 4.4 Propagation — `mark_reactions`

After a value changes, `mark_reactions(signal, DIRTY)` walks `signal.reactions`:

- **Legacy-mode guard**: skips the currently-running effect (`reaction === active_effect`) to prevent synchronous infinite loops when `legacy_mode_flag` is on.
- **Inspect effects** (dev): collected into the `inspect_effects` set instead of being scheduled, so their stack traces stay meaningful; flushed via `flush_inspect_effects`.
- **Status update**: reactions not already `DIRTY` are flipped to the given status (`DIRTY` or `MAYBE_DIRTY`).
- **Deriveds** are recursed into with `MAYBE_DIRTY` — lazily re-evaluated only when *read* ([client_runtime_core_deriveds](client_runtime_core_deriveds.md)).
- **Block effects** are additionally pushed onto `eager_block_effects` (the batch's priority queue for template consistency), and every non-derived reaction goes through `schedule_effect` on the current [batch](client_runtime_core_batching.md).

### 4.5 Dev-mode exports

| Export | Role |
|---|---|
| `inspect_effects` / `set_inspect_effects` | Set of pending `$inspect` effects; swapped out during derived execution so deriveds don't over-trigger inspects. |
| `set_inspect_effects_deferred` | Defers immediate flushing (used while batch processing wants writes observed atomically). |
| `flush_inspect_effects` | Marks clean inspect effects `MAYBE_DIRTY` and re-runs only those that are actually dirty — avoids over-firing. |
| `old_values` | `Map<Source, any>` consulted by `runtime.get` while an effect is being destroyed, keeping reads consistent during teardown. |

---

## 5. Data Flow

### 5.1 The write pipeline (`set` → `internal_set`)

```mermaid
flowchart TD
    A["set(source, value, should_proxy)"] --> B{"Active reaction is DERIVED,<br/>BLOCK_EFFECT, ASYNC or INSPECT_EFFECT?"}
    B -- "yes and source not in current_sources" --> C["throw state_unsafe_mutation"]
    B -- no --> D{"should_proxy?"}
    D -- yes --> E["value = proxy(value)"]
    D -- no --> F
    E --> G["DEV: tag_proxy value with signal label"] --> F["internal_set"]
    F --> H{"source.equals(value)?"}
    H -- yes --> Z["return value — no propagation"]
    H -- no --> I["record value in old_values<br/>old value normally, new value if effect is destroying"]
    I --> J["source.v = value"]
    J --> K["Batch.ensure().capture(source, old_value)"]
    K --> L{"DEV tracing active?"}
    L -- yes --> L2["append to source.updated map,<br/>flag set_during_effect"] --> M
    L -- no --> M{"source is a DIRTY derived?"}
    M -- yes --> M2["execute_derived eagerly,<br/>status CLEAN or MAYBE_DIRTY"]
    M -- no --> N
    M2 --> N["source.wv = increment_write_version()"]
    N --> O["mark_reactions(source, DIRTY)"]
    O --> P{"write happened inside a CLEAN,<br/>non-branch effect?"}
    P -- yes --> Q["append source to untracked_writes<br/>so the effect itself is scheduled"]
    P -- no --> R
    Q --> R{"DEV: pending inspect_effects<br/>and not deferred?"}
    R -- yes --> S["flush_inspect_effects()"]
    R -- no --> T["return value"]
    S --> T
```

### 5.2 Reaction propagation (`mark_reactions`)

```mermaid
flowchart TD
    A["mark_reactions(signal, DIRTY)"] --> B{"signal.reactions"}
    B -- null --> Z["done"]
    B -- list --> C["iterate reaction"]
    C --> D{"legacy mode and reaction is<br/>the active effect?"}
    D -- yes --> C
    D -- no --> E{"DEV and INSPECT_EFFECT flag?"}
    E -- yes --> F["add to inspect_effects set"] --> C
    E -- no --> G{"reaction already DIRTY?"}
    G -- "not dirty" --> H["set_signal_status(reaction, DIRTY)"]
    G -- already dirty --> I
    H --> I{"reaction is DERIVED?"}
    I -- yes --> J["recurse with MAYBE_DIRTY<br/>deriveds re-evaluate lazily on read"]
    I -- no --> K{"BLOCK_EFFECT?"}
    K -- yes --> L["push onto eager_block_effects"]
    K -- no --> M
    L --> M["schedule_effect on current batch"] --> C
    J --> C
```

### 5.3 End-to-end: `count++` in a component

```mermaid
sequenceDiagram
    autonumber
    participant T as Component / template code
    participant U as update / update_pre
    participant G as runtime.get
    participant S as set → internal_set
    participant B as Batch
    participant M as mark_reactions
    participant E as Effect graph (DOM)

    T->>U: $.update(count_source)   // compiled from count++
    U->>G: get(count_source)
    G-->>U: current value (dependency registered on active reaction)
    U->>S: set(source, value + 1)
    S->>S: equality check (source.equals)
    S->>B: Batch.ensure() → capture(source, old)
    S->>M: mark_reactions(source, DIRTY)
    M->>E: schedule_effect(...) for dirty deriveds / effects
    S-->>U: new value
    U-->>T: post-increment result (old value)
    Note over B,E: Microtask flush → Batch.process → dirty effects re-run →<br/>get() returns fresh values → DOM patches → batch commits
```

---

## 6. Dependency Graph

```mermaid
flowchart LR
    subgraph SM["sources.js (this module)"]
        UP["update"]
        UPRE["update_pre"]
        SET["set / internal_set / mutate"]
        FAC["source / state / mutable_source"]
        MR["mark_reactions"]
        FIE["flush_inspect_effects"]
    end

    subgraph SIB["Sibling reactivity modules"]
        RT["client_runtime_core_runtime<br/>runtime.js"]
        EQM["client_runtime_core_signal_model<br/>equality.js"]
        BAT["client_runtime_core_batching<br/>batch.js"]
        DER["client_runtime_core_deriveds<br/>deriveds.js"]
        PX["client_runtime_core_proxies<br/>proxy.js"]
        EFF["client_runtime_core_effects<br/>effects.js"]
    end

    subgraph SUP["Platform services"]
        FLG["shared_runtime<br/>flags"]
        DIA["client_runtime_core_diagnostics<br/>errors.js"]
        DEVM["client_dev_mode<br/>dev/tracing.js"]
    end

    FAC --> EQM
    SET --> EQM
    SET --> RT
    SET --> BAT
    SET --> DER
    SET --> PX
    SET --> DIA
    SET --> DEVM
    FAC --> FLG
    FAC --> DEVM
    UP --> RT
    UP --> SET
    UPRE --> RT
    UPRE --> SET
    MR --> RT
    MR --> BAT
    FIE --> EFF
    PX --> FAC
    PX --> SET
```

Notable dependency details:

- **runtime.js is both a dependency and a consumer** — `get` lives there, while write-side primitives live here; the two halves form one logical unit split for tree-shaking ([client_runtime_core_runtime](client_runtime_core_runtime.md)).
- **proxy.js consumes this module heavily**: every proxied property lazily creates a source via `source()` and routes writes through `set(..., true)` ([client_runtime_core_proxies](client_runtime_core_proxies.md)).
- **batch.js** is consulted on every actual value change (`Batch.ensure().capture`) and receives every scheduled effect (`schedule_effect`, `eager_block_effects`) ([client_runtime_core_batching](client_runtime_core_batching.md)).
- Status flags (`CLEAN`, `DIRTY`, `MAYBE_DIRTY`, `UNOWNED`, `DERIVED`, `BLOCK_EFFECT`, `INSPECT_EFFECT`, `BRANCH_EFFECT`, `ROOT_EFFECT`, `ASYNC`) come from `#client/constants`, part of the signal model vocabulary ([client_runtime_core_signal_model](client_runtime_core_signal_model.md)).

---

## 7. Integration With the Wider System

- **Compiler back-end**: the client transform emits `$.update`, `$.update_pre`, `$.mutate`, `$.set` and `$.state` calls into generated component code. Any template expression like `{count++}` becomes a call into this module. See [Compiler_Back-End_(Client___Server_Code_Generation)](Compiler_Back-End_(Client___Server_Code_Generation).md).
- **Rendering back-ends**: DOM effects created by the [client_dom_renderer](client_dom_renderer.md) read sources through `get` and are re-scheduled by `mark_reactions` via the batch; the async pipeline ([client_runtime_core_async](client_runtime_core_async.md)) relies on batch capture to keep multi-batch writes consistent.
- **Legacy layer**: `mutable_source` + `legacy_mode_flag` wiring into `component_context.l.s` powers `beforeUpdate`/`afterUpdate` semantics; `invalidate_inner_signals` in [client_runtime_core_diagnostics / legacy](client_runtime_core_diagnostics.md) iterates exactly the signals this factory registers.
- **Dev mode**: tracing metadata (`created`, `updated`, `trace`) and `$inspect` flushing are only active when compiled with dev flags ([client_dev_mode](client_dev_mode.md), [shared_runtime](shared_runtime.md)).

---

## 8. Design Invariants & Concurrency Semantics

1. **Single write choke-point.** All mutations traverse `set`/`internal_set`, which is what makes global guarantees (unsafe-mutation detection, write versioning, batching, inspect flushing) enforceable.
2. **Equality short-circuit.** `source.equals` prevents cascades from identical writes; choosing `equals` vs `safe_equals` at factory time encodes the immutability contract of the signal.
3. **Write/read version pairing.** Each write bumps the global write version (`wv`); reads stamp `rv`. Batches use these to detect stale values across async flush boundaries ("time travelling" between multiple batches).
4. **No synchronous cycles.** In runes mode, writes from inside deriveds/block effects throw; in legacy mode, `mark_reactions` skips the active effect; in both modes, self-writes in clean effects are deferred via `untracked_writes` so `$effect(() => x++)` re-runs on the *next* flush instead of recursing.
5. **Laziness where possible, eagerness where required.** Deriveds are only marked `MAYBE_DIRTY` and re-evaluated on read — except when a dirty derived is *written to*, where it is eagerly executed to preserve dependency tracking.
6. **Teardown consistency.** During effect destruction, `get` serves values from `old_values` (including freshly written values), so cleanup callbacks observe a coherent snapshot.
7. **Plain-object signals.** Signals are bare objects with bitmask flags — cheap to create, cheap to status-flip, and trivially tree-shaken when dev-mode branches are compiled out.

---

## 9. Related Modules

- [client_runtime_core](client_runtime_core.md) — parent module: full client runtime overview
- [client_runtime_core_signal_model](client_runtime_core_signal_model.md) — `Signal`/`Source` type contracts and equality
- [client_runtime_core_runtime](client_runtime_core_runtime.md) — `get`, reaction tracking, version counters, flush loop
- [client_runtime_core_batching](client_runtime_core_batching.md) — `Batch`, effect scheduling and microtask flushing
- [client_runtime_core_deriveds](client_runtime_core_deriveds.md) — lazy derived evaluation
- [client_runtime_core_effects](client_runtime_core_effects.md) — effect lifecycle (`block`, `legacy_pre_effect`)
- [client_runtime_core_proxies](client_runtime_core_proxies.md) — deep `$state` proxies built on this module
- [client_runtime_core_props](client_runtime_core_props.md) — prop get/set accessors mirroring update semantics
- [client_runtime_core_stores](client_runtime_core_stores.md) — store bridge mirroring update semantics
- [client_runtime_core_async](client_runtime_core_async.md) — async effects & batch interplay
- [client_runtime_core_diagnostics](client_runtime_core_diagnostics.md) — errors/warnings including `state_unsafe_mutation`
- [client_dev_mode](client_dev_mode.md) — tracing, HMR, ownership validation instrumentation
