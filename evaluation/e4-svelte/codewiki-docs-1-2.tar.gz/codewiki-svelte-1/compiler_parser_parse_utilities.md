# compiler_parser_parse_utilities

**Package:** `svelte` · **Location:** `packages/svelte/src/compiler/phases/1-parse/` · **Parent module:** [compiler_parser](<compiler_parser.md>)

## 1. Introduction

`compiler_parser_parse_utilities` is the *support toolkit* of the Svelte template parser (phase `1-parse`). While the state machine (see [compiler_parser_template_state_machine](<compiler_parser_template_state_machine.md>)) walks the source text and the JS/TS reader (see [compiler_parser_js_ts_processing](<compiler_parser_js_ts_processing.md>)) handles `<script>` content, this module provides the small, self-contained helpers the parser leans on to turn raw text into well-formed AST data:

| Utility | File | Responsibility |
| --- | --- | --- |
| `read_options` | `read/options.js` | Parses and validates the `<svelte:options>` element into a typed `AST.Root['options']` object |
| `fuzzymatch` / `sort_descending` | `utils/fuzzymatch.js` | "Did you mean …?" suggestion engine (q-gram fuzzy set + Levenshtein distance) used to enrich diagnostics |
| `get_entity_pattern` / `decode_character_references` | `utils/html.js` | HTML character-reference (entity) decoding for text content and attribute values, per the WHATWG parsing spec |

The module has **no mutable state shared with the parser** except the singleton, precompiled entity regexes — every function is a pure transformation from raw text/AST fragments to validated output or a thrown diagnostic.

## 2. Position in the System

The parser entry point `parse(template, loose)` (in `1-parse/index.js`) drives a `Parser` instance through the template state machine. Two integration points connect this module to that loop:

1. **During the parse loop** — the `text` and `element` states call `decode_character_references(...)` from `utils/html.js` every time they materialise an `AST.Text` node or a static attribute value.
2. **After the parse loop** — the `Parser` constructor scans the root fragment for a `SvelteOptions` node, splices it out, and hands it to `read_options` to populate `root.options`.

```mermaid
flowchart TB
    subgraph FE["Compiler Front-End (Parsing, Analysis &amp; CSS Scoping)"]
        subgraph CP["compiler_parser"]
            direction TB
            INDEX["1-parse/index.js<br/>Parser / parse()"]
            subgraph SM["compiler_parser_template_state_machine"]
                FRAG["state/fragment.js"]
                ELEM["state/element.js"]
                TEXT["state/text.js"]
            end
            subgraph UTILS["compiler_parser_parse_utilities (this module)"]
                OPTS["read/options.js<br/>read_options()"]
                HTML["utils/html.js<br/>get_entity_pattern()<br/>decode_character_references()"]
                FUZZY["utils/fuzzymatch.js<br/>fuzzymatch() / sort_descending()"]
                ENT["utils/entities.js<br/>(WHATWG entity table)"]
            end
            JSTS["compiler_parser_js_ts_processing<br/>(acorn.js, remove_typescript_nodes.js)"]
        end
        DIAG["compiler_diagnostics<br/>(errors.js, warnings.js)"]
        TYPES["compiler_types<br/>(AST.Root, AST.SvelteOptionsRaw)"]
        ANALYZE["compiler_analyzer<br/>(phase 2-analyze)"]
    end

    INDEX -->|"state = state(parser) loop"| SM
    INDEX -->|"after loop: root.options = read_options(SvelteOptionsRaw)"| OPTS
    ELEM -->|"decode_character_references(raw, true)"| HTML
    TEXT -->|"decode_character_references(data, false)"| HTML
    HTML -->|"entity name → code point lookup"| ENT
    OPTS -->|"svelte_options_* errors"| DIAG
    ELEM -.->|"error helpers"| DIAG
    FUZZY -.->|"closest-match strings for diagnostics"| DIAG
    OPTS -->|"AST.Root['options']"| TYPES
    INDEX -->|"Root (options, fragment, js, css)"| ANALYZE
```

Solid arrows are direct function calls; dashed arrows indicate indirect/auxiliary use (diagnostic messages, type contracts).

## 3. Component Reference

### 3.1 `read_options` — `<svelte:options>` parsing (`read/options.js`)

```js
function read_options(node: AST.SvelteOptionsRaw): AST.Root['options']
```

**Input contract.** `node` is the raw `SvelteOptions` element produced by the state machine (`<svelte:options runes={true} … />`). Its `attributes` array contains the generic `AST.Attribute` nodes built by `read_attribute` / `read_static_attribute`.

**Behaviour.** Iterates each attribute and dispatches on its name:

| Attribute | Accepted shape | Result field |
| --- | --- | --- |
| `runes` | boolean | `options.runes` |
| `tag` | — | **throws** `svelte_options_deprecated_tag` (removed in favour of `customElement`) |
| `customElement` | string tag **or** object `{ tag?, props?, shadow?, extend? }` | `options.customElement` |
| `namespace` | `html`, `svg`, `mathml`, or a full namespace URI (`NAMESPACE_SVG` / `NAMESPACE_MATHML` from `constants.js`) | `options.namespace: 'html' \| 'svg' \| 'mathml'` |
| `css` | literal `"injected"` | `options.css` |
| `immutable`, `preserveWhitespace`, `accessors` | boolean | corresponding boolean fields |
| anything else | — | **throws** `svelte_options_unknown_attribute` |

**Validation performed:**

- Only plain `Attribute` nodes are allowed; directives/spreads inside `<svelte:options>` raise `svelte_options_invalid_attribute`.
- `customElement.tag` must satisfy the [HTML custom-element name grammar](https://html.spec.whatwg.org/multipage/custom-elements.html#valid-custom-element-name) (`regex_valid_tag_name`, must contain a hyphen, start lowercase) and must not be one of the reserved names (`annotation-xml`, `font-face`, `missing-glyph`, …).
- `customElement.props` entries require `type` ∈ {`String`, `Number`, `Boolean`, `Array`, `Object`}, boolean `reflect`, and string `attribute` — anything else raises `svelte_options_invalid_customelement_props`.
- `customElement.shadow` must be `'open'` or `'none'`.
- `customElement={null}` is silently accepted for Svelte 4 backwards compatibility.
- The legacy `customElement={{ tag: … }}` key form is reconstructed by scanning the `ObjectExpression` properties of the parsed attribute expression.

**Internal helpers (file-private):**

- `get_static_value(attribute)` — resolves an attribute value to `true` (valueless), a string (`Text` chunk), a literal value, or `null` (non-literal / multi-chunk expressions).
- `get_boolean_value(attribute)` — `get_static_value` + strict boolean check, otherwise `svelte_options_invalid_attribute_value`.
- `validate_tag(attribute, tag)` — name grammar + reserved-name assertion (asserts `tag is string`).

**Call site.** In `Parser`'s constructor (`1-parse/index.js`), *after* the state loop terminates:

```js
const options_index = this.root.fragment.nodes.findIndex((n) => n.type === 'SvelteOptions');
if (options_index !== -1) {
    const options = this.root.fragment.nodes[options_index];
    this.root.fragment.nodes.splice(options_index, 1);   // remove from visible fragment
    this.root.options = read_options(options);            // validate & hoist
    disallow_children(options);                           // no children allowed (2-analyze/shared/special-element.js)
    Object.defineProperty(this.root.options, '__raw__', { value: options, enumerable: false }); // for legacy AST
}
```

```mermaid
sequenceDiagram
    participant P as Parser (1-parse/index.js)
    participant SM as State machine (element state)
    participant RO as read_options (read/options.js)
    participant E as compiler_diagnostics (errors.js)

    SM->>P: yields SvelteOptions node into root.fragment
    P->>P: splice node out of root.fragment.nodes
    P->>RO: read_options(rawNode)
    loop each attribute
        RO->>RO: switch on attribute name
        alt invalid attribute / value / tag name
            RO->>E: throw svelte_options_* CompileError
        end
    end
    RO-->>P: AST.Root['options'] (typed component options)
    P->>P: attach non-enumerable __raw__ for legacy AST
    P->>P: disallow_children(rawNode) → svelte_meta_invalid_content if non-empty
```

### 3.2 `get_entity_pattern` / `decode_character_references` — HTML entity decoding (`utils/html.js`)

**Pattern construction.**

```js
function get_entity_pattern(is_attribute_value: boolean): RegExp
```

Builds a single global regex `&(#(?:x[a-fA-F\d]+|\d+)(?:;)?|<named entity alternation>)` from the keys of `utils/entities.js` (a snapshot of the WHATWG `entities.json` table — thousands of named references). It is invoked exactly **twice**, at module load, producing two cached singletons:

- `entity_pattern_content` — for text content; every named entity, with or without a trailing `;`, is matched.
- `entity_pattern_attr_value` — for attribute values; per the [named character reference state](https://html.spec.whatwg.org/multipage/parsing.html#named-character-reference-state) of the HTML parsing spec, references *not* ending in `;` are additionally guarded with `\b(?!=)` so that e.g. `&notit;=` is not partially decoded inside an attribute.

**Decoding.**

```js
function decode_character_references(html: string, is_attribute_value: boolean): string
```

Replaces each matched reference with its character:

1. **Named** (`&amp;`) → looked up in the entity table.
2. **Decimal** (`&#8212;`) or **hex** (`&#x2014;`) → `parseInt`.
3. Result is passed through `validate_code(code)` and converted with `String.fromCodePoint`. Unresolvable matches are returned unchanged.

`validate_code` implements the browser-style leniency rules for illegal code points:

| Code point range | Mapping |
| --- | --- |
| `10` (line feed) | `32` (space) |
| `< 128` (ASCII) | unchanged |
| `128–159` (C1 controls) | remapped via the **windows-1252** table (so `€`, `“`, etc. survive) |
| `0xD800–0xDFFF` (UTF-16 surrogate halves) and other verboten planes | `NUL` |
| all other assigned planes (BMP, SMP 0x10000–0x2FFFF, special-purpose 0xE0000–0xE01EF) | unchanged |

**Consumers:**

| Consumer | Mode | Why |
| --- | --- | --- |
| `state/text.js::text` | `is_attribute_value = false` | `AST.Text.data` for character data between tags |
| `state/element.js::read_attribute_value` (quoted/unquoted values) | `true` | `Text` chunks inside regular attribute values |
| `state/element.js::read_static_attribute` | `true` | attribute values of top-level `<script>`/`<style>` tags |

Note that raw text inside `<script>`/`<style>` bodies and `<textarea>` content is **not** entity-decoded (the parser treats it as raw), matching browser behaviour.

```mermaid
flowchart LR
    A["Raw template text"] --> B{"Context?"}
    B -->|"text node"| C["entity_pattern_content"]
    B -->|"attribute value"| D["entity_pattern_attr_value<br/>(unnamed refs guarded with \b(?!=))"]
    C --> E["regex replace over &refs"]
    D --> E
    E --> F{"Reference kind"}
    F -->|"named"| G["entities.js lookup"]
    F -->|"&#x…;"| H["parseInt(…, 16)"]
    F -->|"&#…;"| I["parseInt(…, 10)"]
    G & H & I --> J["validate_code(code)"]
    J --> K["String.fromCodePoint"]
    K --> L["decoded string → AST.Text.data / attribute Text chunk"]
    J -.->|"illegal code point"| M["NUL or windows-1252 remap"]
```

### 3.3 `fuzzymatch` / `sort_descending` — suggestion engine (`utils/fuzzymatch.js`)

```js
function fuzzymatch(name: string, names: string[]): string | null
function sort_descending(a: [number, string], b: [number, string]): number // comparator: b[0] - a[0]
```

A vendored, trimmed port of [fuzzyset.js](https://github.com/Glench/fuzzyset.js) (BSD-licensed, adapted 2016) that answers "which of these valid names did the user most likely mean?" for developer-facing diagnostics.

**Algorithm pipeline** (`FuzzySet`):

1. **Indexing (`add` / `_add`)** — every candidate string is lower-cased, normalised (non-word characters stripped, `-` padding added) and decomposed into overlapping **q-grams** for `GRAM_SIZE = 2` and `3`. Per string, the gram counts are stored in `match_dict` alongside the vector norm `√Σ(count²)`; exact strings are kept in `exact_set`.
2. **Lookup (`get`)** — an exact (case-insensitive) hit short-circuits to score `1`. Otherwise q-gram matching runs from gram size `3` down to `2`, accumulating cosine-similarity scores `overlap / (‖input‖·‖candidate‖)` per candidate.
3. **Ranking** — results are sorted with `sort_descending` (descending by score), truncated to the top **50** candidates, re-scored with a **Levenshtein**-based normalised edit distance `1 − distance/max(len)`, and sorted again; ties with the best score are kept.
4. **Threshold** — `fuzzymatch` returns `matches[0][1]` only if the top score is **> 0.7**, otherwise `null` (so diagnostics never suggest a poor match).

`levenshtein` uses a single rolling row (space-optimised dynamic programming); `iterate_grams` / `gram_counter` implement the tokenisation/counting described above.

Because the engine is only invoked on the error path, its cost is amortised: zero work during a successful compile.

## 4. Data Flow Through the Parse Phase

```mermaid
flowchart TD
    SRC["`.svelte` source string"] --> PARSE["parse(template, loose)"]
    PARSE --> LOOP["Parser state loop<br/>(fragment → element/text/tag states)"]
    LOOP -->|"Text nodes"| DEC["decode_character_references"]
    LOOP -->|"Attribute values"| DEC
    DEC --> ASTF["AST.Fragment (Text / attributes)"]
    ASTF -->|"raw SvelteOptions element"| RO["read_options"]
    RO --> OPT["root.options:<br/>runes, namespace, customElement, css, …"]
    LOOP --> ROOT["AST.Root"]
    OPT --> ROOT
    ROOT --> A2["phase 2-analyze (compiler_analyzer)"]
    A2 --> T3["phase 3-transform (client / server)"]
    LOOP -.->|"invalid options / tag names"| ERR["CompileError (svelte_options_*)"]
    LOOP -.->|"misspelled names"| FUZZ["fuzzymatch suggestion string"]
```

## 5. Dependencies

### Upstream (consumed by this module)

| Dependency | Source module | Used by | Purpose |
| --- | --- | --- | --- |
| `NAMESPACE_SVG`, `NAMESPACE_MATHML` | `src/constants.js` | `read_options` | Recognise full namespace URIs for `namespace="…"` |
| `svelte_options_*` error factories | [compiler_diagnostics](<compiler_diagnostics.md>) (`errors.js`) | `read_options` | Throwing positioned `CompileError`s (deprecated `tag`, invalid `customElement` shape, unknown attribute, invalid tag name, …) |
| `entities` table | `utils/entities.js` (same folder) | `get_entity_pattern` / `decode_character_references` | WHATWG named-character-reference → code point mapping |
| `AST.SvelteOptionsRaw`, `AST.Root` types | [compiler_types](<compiler_types.md>) (`types/template.d.ts`) | `read_options` | Input/output type contracts |

### Downstream (consumers of this module)

| Consumer | Module | Integration |
| --- | --- | --- |
| `Parser` constructor | [compiler_parser](<compiler_parser.md>) | Calls `read_options` once per component after the state loop |
| `state/text.js`, `state/element.js` | [compiler_parser_template_state_machine](<compiler_parser_template_state_machine.md>) | Call `decode_character_references` for every text node and static attribute value |
| Analyzer / transform phases | [compiler_analyzer](<compiler_analyzer.md>), [Compiler Back-End](<Compiler_Back-End_(Client___Server_Code_Generation).md>) | Read the validated `root.options` / decoded `Text.data` produced here |

## 6. Design Notes & Maintenance Guidance

- **Module-load cost vs. runtime cost.** The two entity regexes are compiled once at import time (alternation over the full entity table). Never rebuild `get_entity_pattern` per call — reuse the cached `entity_pattern_content` / `entity_pattern_attr_value` singletons the way `decode_character_references` does.
- **Spec fidelity.** Attribute-value decoding intentionally diverges from content decoding (`\b(?!=)` guard, per WHATWG). When touching `html.js`, test both `is_attribute_value` modes; the difference only shows up for legacy (semicolon-less) references such as `&notin` followed by `=`.
- **Fail fast, positionally.** `read_options` throws immediately via `errors.js` helpers so diagnostics carry exact `[start, end]` bounds from the parsed attribute node — keep new validations inside this pattern rather than deferring to the analyzer.
- **Backwards compatibility islands.** `customElement={null}` and the deprecated `tag` attribute exist purely for Svelte 4 migration paths; don't remove them without a major-version decision.
- **`sort_descending` in isolation.** The comparator is only meaningful for `[score, match]` tuples; the threshold (`0.7`) and truncation size (`50`) are the tunable knobs if suggestion quality or perf ever need adjustment.
- **Related tooling.** Source-level reprocessing of files before parsing (which may also affect entities/options) is handled by [compiler_preprocess](<compiler_preprocess.md>); migration of legacy options/tags is covered by [compiler_migrate](<compiler_migrate.md>).

## 7. Quick API Summary

```js
// read/options.js
export default function read_options(node: AST.SvelteOptionsRaw): AST.Root['options'];
// utils/html.js
function get_entity_pattern(is_attribute_value: boolean): RegExp; // module-private, used to build cached patterns
export function decode_character_references(html: string, is_attribute_value: boolean): string;
// utils/fuzzymatch.js
export default function fuzzymatch(name: string, names: string[]): string | null; // best match > 0.7 or null
function sort_descending(a: MatchTuple, b: MatchTuple): number; // descending-score comparator
```
