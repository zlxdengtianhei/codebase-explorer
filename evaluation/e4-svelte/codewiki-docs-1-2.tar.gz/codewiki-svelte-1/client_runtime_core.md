# Client Runtime Core (Reactivity Engine)

## 1. Purpose & Scope

`client_runtime_core` is the **heart of Svelte's client-side runtime** — a fine-grained, push/pull reactive system that powers every `$state`, `$derived`, `$effect`, `$props()` and store binding compiled into a Svelte 5 application. The compiler (`Compiler_Back-End_(Client___Server_Code_Generation)`) lowers runes into calls into this module; the DOM renderer (`client_dom_renderer`) consumes the effects it schedules to update the DOM.

Its responsibilities:

| Responsibility | Where |
|---|---|
| Signal data model (`Signal`, `Value`, `Reaction`, `Derived`, `Effect`) | `reactivity/types.d.ts` |
| Global scheduling/dirty-checking state machine (`get`, `update_reaction`, `update_effect`, `tick`, `settled`) | `runtime.js` |
| Writable state (sources) — creation, mutation, dirty-marking | `reactivity/sources.js` |
| Computed values (deriveds), incl. async deriveds | `reactivity/deriveds.js` |
| Effect lifecycle (create/schedule/destroy/pause/resume) | `reactivity/effects.js` |
| Batching, transactions & synchronous flushing (`Batch`, `flushSync`) | `reactivity/batch.js` |
| Deep reactivity via Proxies (`$state` objects/arrays) | `proxy.js` |
| Component props & bindings (`$props()`, rest props, spread props) | `reactivity/props.js` |
| Store auto-subscription interop (`$store`) | `reactivity/store.js` |
| Async reactivity support (`await` in components, `$await` deriveds) | `reactivity/async.js` |
| RAF task loop (transitions, tweens, spring animations) | `loop.js` |
| Equality semantics for update coalescing | `reactivity/equality.js` |
| Dev-time validation, generated errors/warnings, legacy mode shims | `validate.js`, `errors.js`, `warnings.js`, `legacy.js` |

Everything here is *internal*: application code never imports these modules directly — it interacts through runes compiled to `$.state`, `$.get`, `$.set`, etc. calls into this module.

## 2. Mental Model: Signals, Reactions & the Push/Pull Split

The engine separates **writing** (push: mark dependents dirty) from **reading** (pull: recompute only when read).

- **Signals** (sources & deriveds) hold values plus a monotonically increasing **write version** (`wv`).
- **Reactions** (effects & deriveds, which are both) track **dependencies** (`deps`) and their own **read version** (`rv`). A reaction is *dirty* if any dependency's `wv` exceeds its own `wv`.
- Writing a source bumps `write_version` and **pushes** `DIRTY`/`MAYBE_DIRTY` flags onto its `reactions` and schedules them into the current [Batch](#client_runtime_core_batching).
- When a reaction runs (or a derived is read), `update_reaction`/`get` **pull** values, re-registering exactly the dependencies actually read during that run — enabling automatic, precise dependency tracking without annotations.

```mermaid
flowchart TD
    subgraph Writes["Write path (push)"]
        A["$.set(source, v)<br/>sources.js"] --> B["source.v = v<br/>wv = ++write_version"]
        B --> C["mark_reactions<br/>DIRTY / MAYBE_DIRTY"]
        C --> D["schedule_effect<br/>→ queued_root_effects"]
        D --> E["Batch.ensure()<br/>capture old value"]
    end
    subgraph Flush["Flush (batching)"]
        E --> F["microtask → batch.flush()<br/>or flushSync"]
        F --> G["process(): traverse<br/>effect tree"]
        G --> H["update_effect → update_reaction"]
    end
    subgraph Reads["Read path (pull)"]
        H --> I["reaction.fn() runs"]
        I --> J["$.get(dep)<br/>runtime.js"]
        J --> K["dep dirty? (dep.wv > rv)<br/>→ update_derived"]
        K --> L["new_deps recorded,<br/>stale deps removed"]
        L --> I
    end
    J --> M["DOM updated via<br/>client_dom_renderer"]
```

## 3. Architecture Overview

```mermaid
flowchart TB
    subgraph Core["Core scheduling & dirty checking"]
        RUNTIME["runtime.js<br/>get / update_reaction / update_effect<br/>is_dirty / tick / settled"]
        TYPES["reactivity/types.d.ts<br/>Signal · Value · Reaction · Derived · Effect"]
        EQ["reactivity/equality.js<br/>equals / not_equal / safe_equals"]
        LOOP["loop.js<br/>raf task loop"]
    end

    subgraph Signals["Signal implementations"]
        SOURCES["reactivity/sources.js<br/>source · state · set · internal_set<br/>update · mark_reactions"]
        DERIVEDS["reactivity/deriveds.js<br/>derived · async_derived<br/>execute_derived · update_derived"]
        EFFECTS["reactivity/effects.js<br/>create_effect · render_effect<br/>block · branch · destroy/pause/resume"]
        BATCH["reactivity/batch.js<br/>Batch · flushSync · schedule_effect · suspend"]
    end

    subgraph Facades["Value facades"]
        PROXY["proxy.js<br/>$state deep proxies"]
        PROPS["reactivity/props.js<br/>prop / rest_props / spread_props"]
        STORES["reactivity/store.js<br/>store_get / setup_stores"]
        ASYNC["reactivity/async.js<br/>save · flatten · async_body"]
    end

    subgraph Guardrails["Diagnostics & compatibility"]
        VALIDATE["validate.js"]
        ERRORS["errors.js / warnings.js<br/>(generated)"]
        LEGACY["legacy.js<br/>invalidate_inner_signals"]
    end

    TYPES --> RUNTIME
    EQ --> SOURCES & DERIVEDS
    RUNTIME --> SOURCES & DERIVEDS & EFFECTS & BATCH
    BATCH --> RUNTIME
    SOURCES --> PROXY & PROPS & STORES
    DERIVEDS --> PROPS & ASYNC
    EFFECTS --> ASYNC & STORES
    PROXY & PROPS --> RUNTIME
    VALIDATE --> ERRORS
    LEGACY --> SOURCES & RUNTIME
```

**Flag-based state machine.** Every signal carries a bitmask `f` (see `constants.js`): `CLEAN`, `DIRTY`, `MAYBE_DIRTY`, `DESTROYED`, plus type flags `DERIVED`, `EFFECT`, `RENDER_EFFECT`, `BLOCK_EFFECT`, `BRANCH_EFFECT`, `ROOT_EFFECT`, `INSPECT_EFFECT`, `ASYNC` and modifiers `UNOWNED`, `DISCONNECTED`, `INERT`, `EFFECT_PRESERVED`. `set_signal_status` swaps the status bits; `is_dirty` inspects them to decide lazily whether recomputation is needed.

```mermaid
stateDiagram-v2
    [*] --> DIRTY: effect created
    state "CLEAN" as clean
    state "MAYBE_DIRTY" as maybe
    state "DIRTY" as dirty
    state "DESTROYED" as dead
    dirty --> clean: update_reaction ran
    clean --> dirty: dep.wv > this.wv
    clean --> maybe: upstream maybe-dirty
    maybe --> dirty: dep actually changed (is_dirty pull)
    maybe --> clean: is_dirty walk found no real change
    clean --> dead: destroy_effect / branch removed
    dirty --> dead
```

## 4. Key Invariants & Design Notes

1. **Versioning, not recomputation.** `write_version` is global and monotonic; each write stamps `wv`. `get()` compares `dep.wv > reaction.wv` to decide dirtiness — O(1) checks instead of eager recomputation.
2. **Lazy deriveds.** Deriveds recompute only when read (`update_derived` in `get()`), and results are cached until a dependency's `wv` advances.
3. **Dynamic dependency tracking.** `update_reaction` snapshots `new_deps`/`skipped_deps` while `reaction.fn()` runs, then rewires `deps` and `reactions` bidirectionally — removing stale edges (`remove_reactions`) and possibly *disconnecting* unused deriveds so the VM can GC them.
4. **Batched commits.** All writes go through `Batch.ensure()`. Batches capture old values (enabling "time travelling" when multiple async batches coexist), defer branch DOM commits, count pending async work (`suspend`/`unsuspend`) and only commit when settled. `flushSync` opts out synchronously.
5. **Ownership & unowned deriveds.** A `derived` created outside an effect gets `UNOWNED` and only connects to the graph when read under an active effect — preventing memory leaks for deriveds that nobody subscribes to.
6. **Safe mutation rules.** `set()` throws `state_unsafe_mutation` when state is written inside a derived/template expression; `flushSync` inside effects is rejected in async mode; infinite loops trip `effect_update_depth_exceeded` (guarded at 1000 flushes) and route to the nearest `<svelte:boundary>`.
7. **Prod/dev dual output.** `errors.js`/`warnings.js` are code-generated (`scripts/process-messages`) — full messages + docs links in `DEV`, minimal URL-only throws/warns in prod. Tree-shaking plus `esm-env`'s `DEV` constant removes diagnostics from production bundles.
8. **Equality-driven updates.** `equals` (referential) is the default; `safe_equals` (Svelte's classic `safe_not_equal`) is used for mutable sources, stores and safe deriveds so mutations of the same object identity still propagate.

## 5. Sub-module Reference

The module is split into 11 detailed sub-module pages, all saved alongside this file (links resolve to the exact generated filenames):

📄 Generated files: `client_runtime_core_signal_model.md` · `client_runtime_core_runtime.md` · `client_runtime_core_sources.md` · `client_runtime_core_deriveds.md` · `client_runtime_core_effects.md` · `client_runtime_core_batching.md` · `client_runtime_core_proxies.md` · `client_runtime_core_props.md` · `client_runtime_core_stores.md` · `client_runtime_core_async.md` · `client_runtime_core_diagnostics.md`

| Sub-module | File(s) | Summary |
|---|---|---|
| [Signal Model & Equality](client_runtime_core_signal_model.md) | `reactivity/types.d.ts`, `reactivity/equality.js` | The `Signal`/`Value`/`Reaction`/`Derived`/`Effect` interface hierarchy and equality semantics that gate updates. |
| [Core Runtime & Scheduling](client_runtime_core_runtime.md) | `runtime.js`, `loop.js` | Global reactive-context slots, `get`/`untrack`, `update_reaction`/`update_effect`, lazy dirty checking, `tick`/`settled`, RAF task loop. |
| [Sources (Writable State)](client_runtime_core_sources.md) | `reactivity/sources.js` | `source`/`state`/`mutable_source` creation, `set`/`internal_set`/`mutate`, `update`/`update_pre`, dirty propagation via `mark_reactions`. |
| [Deriveds (Computed Values)](client_runtime_core_deriveds.md) | `reactivity/deriveds.js` | `derived`, `user_derived`, async `derived`, `execute_derived`/`update_derived` and derived-effect ownership/GC. |
| [Effects (Lifecycle)](client_runtime_core_effects.md) | `reactivity/effects.js` | Effect kinds (`$effect`, `$effect.pre`, render/block/branch/root/inspect/async), creation, teardown, pause/resume for transitions. |
| [Batching & Flush Cycle](client_runtime_core_batching.md) | `reactivity/batch.js` | The `Batch` transaction class, `flushSync`, `schedule_effect`, async suspension, infinite-loop guards, `Batch.clear` and microtask `dequeue`. |
| [State Proxies](client_runtime_core_proxies.md) | `proxy.js` | The `Proxy` handler implementing deep `$state` reactivity for objects/arrays, `get_proxied_value`, dev path tagging (`update_path`). |
| [Component Props](client_runtime_core_props.md) | `reactivity/props.js` | `prop()` binding synchronization, `$bindable` fallbacks, rest/spread props proxies, `update_prop` helpers. |
| [Store Interop](client_runtime_core_stores.md) | `reactivity/store.js` | Auto-subscription (`store_get`), component-scoped containers (`setup_stores`), store mutations/updates and `mark_store_binding`. |
| [Async Reactivity](client_runtime_core_async.md) | `reactivity/async.js` | Effect-context capture/restore across `await` (`save`, `flatten`), `async_body` for `{#await}`-style async blocks, reactivity-loss tracking. |
| [Diagnostics & Legacy Mode](client_runtime_core_diagnostics.md) | `validate.js`, `errors.js`, `warnings.js`, `legacy.js` | Dev-only binding/each-key validation, generated error/warning catalogs, and the deprecated `invalidate_inner_signals`. |

## 6. Data Flow: From `count++` to DOM Update

```mermaid
sequenceDiagram
    participant App as Compiled component
    participant Src as sources.js
    participant Rt as runtime.js
    participant Ba as batch.js
    participant Ef as effects.js
    participant Dom as client_dom_renderer

    App->>Src: $.update(source) / $.set(source, v)
    Src->>Src: source.v = v, wv = increment_write_version()
    Src->>Ba: Batch.ensure().capture(source, old)
    Src->>Src: mark_reactions(source, DIRTY)
    Src->>Ba: schedule_effect(effect)
    Ba->>Ba: queue root effects (microtask) or flushSync
    Ba->>Ef: process → update_effect(dirty effects)
    Ef->>Rt: update_reaction(effect) → fn()
    App->>Rt: $.get(dep) reads
    Rt->>Rt: is_dirty(dep)? → update_derived; rewire deps
    Rt-->>Dom: template_effect callbacks run
    Dom->>Dom: patch text/attributes/bindings
    Ba->>Ba: commit() → DOM branches appended/removed
    Note over Ba: settled() resolves once async work + commit done
```

## 7. Relationship to Other Modules

- **Upstream — compiler:** `Compiler_Back-End_(Client___Server_Code_Generation)` emits `import * as $ from 'svelte/internal/client'` and rewrites runes/directives to the functions documented here (e.g. `$state` → `$.state`, `$derived` → `$.user_derived`, `$effect` → `$.user_effect`, `{#if}` → `$.if_block`, `bind:` → `$.bind_*` + `$.prop`). `TransformState`-driven visitors decide exactly which primitives are called.
- **Downstream — rendering:** `client_dom_renderer` builds blocks on top of these primitives: `if_block`, `each`, `key`, `boundary`, `snippet` all create effects via `effects.js` (`block`/`branch`/`render_effect`); `attribute_effect`/`template_effect` wire DOM updates as render effects; `render.js` (`mount`/`hydrate`/`unmount`) uses `component_root` and `Batch`.
- **Sibling — `client_dev_mode`:** dev instrumentation (HMR wrappers, ownership validation, `$inspect`, location tagging) hooks into the same signals; this module exposes the dev-only hooks it needs (labels, `get_stack`, `tracing_expressions`).
- **Peers:** `Reactive_State_Primitives___Store_Interop` (`$.store/shared`) supplies the subscribe/get implementation that `reactivity/store.js` bridges into signals; `Cross-Runtime_Platform_Services` provides `flags` (`legacy_mode_flag`, `async_mode_flag`, `tracing_mode_flag`) and shared utils consumed throughout.
- **Server counterpart:** `server_runtime` mirrors this API surface (`$.get`-free, immediate evaluation) so compiled output is isomorphic; see that module's docs for SSR semantics.

```mermaid
graph LR
    C[Compiler Back-End] -->|emits $. calls| CORE(client_runtime_core)
    CORE -->|effects & signals| DOM[client_dom_renderer]
    CORE -.->|dev hooks| DEV[client_dev_mode]
    STORES[Store primitives] -->|subscribe/get| CORE
    FLAGS[flags / shared utils] --> CORE
    CORE -->|$.prop / $.store_get| SSR[server_runtime equivalent API]
```

## 8. Glossary

- **Source** — a writable signal (`Value`), the only node whose value is set directly.
- **Derived** — a signal + reaction hybrid; recomputes from its function and caches.
- **Effect** — a reaction that runs for its side effects; the unit the scheduler executes.
- **Reaction** — anything that reads signals: effects and deriveds.
- **Batch** — a transaction capturing writes, scheduling effects and committing DOM changes.
- **Unowned derived** — created with no active effect; connects lazily, disconnects when unread.
- **Write/read version (`wv`/`rv`)** — monotonic counters implementing the dirty check.
