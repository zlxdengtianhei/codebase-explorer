# Transitions Module (`transitions_and_animations_transitions`)

> **Module scope:** `packages/svelte/src/transition/index.js` · `packages/svelte/src/transition/public.d.ts`
> **Parent module:** [transitions_and_animations](transitions_and_animations.md) (Motion & Visual Effects System)

## 1. Introduction

The **transitions module** implements Svelte's family of **built-in transition functions** — the pure, tree-shakeable functions that users import from `svelte/transition` and attach to DOM elements via the `transition:`, `in:`, and `out:` directives. Every function shares one contract:

```js
(node: Element, params?: <Transition>Params) => TransitionConfig
```

It answers the question *"what should this element look like at any point of its enter/leave animation?"* by returning a declarative [`TransitionConfig`](#42-transitionconfig). The module itself performs **no animation scheduling** — it is a *description layer*. Driving the animation (timing, cancellation, reversal, `inert` handling, lifecycle events) is the responsibility of the client rendering backend, documented in [client_dom_renderer_elements_and_events](client_dom_renderer_elements_and_events.md).

**Responsibilities:**

| Concern | Where |
|---|---|
| Seven built-in transitions: `blur`, `fade`, `fly`, `slide`, `scale`, `draw`, `crossfade` | `src/transition/index.js` |
| Public type contracts (`TransitionConfig`, per-transition `*Params`) | `src/transition/public.d.ts` |
| Internal default easings (`linear`, `cubic_out`, `cubic_in_out`) | `src/transition/index.js` (private copies) |
| CSS-unit parsing for string/number params (`split_css_unit`) | `src/transition/index.js` (private helper) |
| Dev-mode misuse warning for `slide` (`transition_slide_display`) | delegates to internal client warnings |

## 2. Position in the System

The transitions module sits at the boundary between the **public API surface** and the **reactive client runtime**:

1. **Compile time:** the compiler's `TransitionDirective` visitor (see [compiler_client_transform_elements_and_directives](compiler_client_transform_elements_and_directives.md)) lowers `transition:name={params}` into a runtime call `$.transition(flags, node, thunk(fn), thunk(params))`. The transition function itself (`fn`) is imported into the component's output code from `svelte/transition` and called **lazily**.
2. **Runtime:** `$.transition` (in `src/internal/client/dom/elements/transitions.js`, documented in [client_dom_renderer_elements_and_events](client_dom_renderer_elements_and_events.md)) invokes `fn(element, params, { direction })`, receives the `TransitionConfig`, and drives it with the **Web Animations API** (generating CSS `@keyframes` from `config.css(t, u)`), or calls `config.tick` per frame for JS-driven effects.
3. **Authoring:** users may also write *custom* transitions — any function honouring the same signature and `TransitionConfig` return type (declared in `packages/svelte/types/index.d.ts`, see [svelte-types](svelte-types.md)).

```mermaid
flowchart TB
    subgraph Author["Developer code"]
        SFC["Component source<br/>transition:fly={{ y: 20 }}"]
        CUSTOM["Custom transition fn"]
    end

    subgraph Compiler["Compiler — see compiler_client_transform_elements_and_directives"]
        TDV["TransitionDirective visitor"]
    end

    subgraph ThisModule["This module — svelte/transition"]
        IDX["src/transition/index.js<br/>blur · fade · fly · slide · scale · draw · crossfade"]
        PUB["src/transition/public.d.ts<br/>TransitionConfig · *Params · EasingFunction"]
    end

    subgraph Runtime["Client runtime — see client_dom_renderer_elements_and_events"]
        RT["$.transition(flags, node, thunk, thunk)<br/>src/internal/client/dom/elements/transitions.js"]
        ANIM["animate() → Web Animations API<br/>keyframes from css(t, u) / tick(t, u)"]
        WARN["internal/client/warnings.js<br/>transition_slide_display (DEV)"]
    end

    SFC --> TDV
    TDV -->|$.transition(...)| RT
    RT -->|"get_fn()(element, params)"| IDX
    IDX -->|TransitionConfig| RT
    RT --> ANIM
    IDX -.->|DEV warning| WARN
    CUSTOM -.->|same contract| RT
    IDX --- PUB
```

## 3. Architecture & Component Relationships

### 3.1 Files and exports

| File | Exports | Role |
|---|---|---|
| `src/transition/index.js` | `blur`, `fade`, `fly`, `slide`, `scale`, `draw`, `crossfade` | Transition implementations (pure functions of node + params) |
| `src/transition/index.js` (private) | `linear`, `cubic_out`, `cubic_in_out`, `split_css_unit`, `assign` | Default easings and param normalization used as internal defaults |
| `src/transition/public.d.ts` | `TransitionConfig`, `EasingFunction`, `BlurParams`, `FadeParams`, `FlyParams`, `SlideParams`, `ScaleParams`, `DrawParams`, `CrossfadeParams` | Public TypeScript contracts; also re-exports `./index.js` |

> **Note on default easings:** the module keeps **private copies** of `linear`, `cubic_out` and `cubic_in_out` rather than importing them from the easing catalogue ([transitions_and_animations_easing](transitions_and_animations_easing.md)). This is a deliberate tree-shaking decision: bundlers can drop the entire 30-function easing module when a component only relies on transition defaults, and only pay for the few easing frames actually referenced. Users who want richer easing pass it explicitly via the `easing` param, importing from `svelte/easing`.

### 3.2 Dependency map

```mermaid
flowchart LR
    subgraph This["transitions_and_animations_transitions"]
        T["transition/index.js"]
        P["transition/public.d.ts"]
    end

    subgraph Siblings["Sibling modules"]
        E["transitions_and_animations_easing<br/>(svelte/easing)"]
        F["transitions_and_animations_flip<br/>(svelte/animate)"]
    end

    subgraph Runtime["Runtime (consumers)"]
        R1["client_dom_renderer_elements_and_events<br/>$.transition / $.animation"]
        R2["client_runtime_core_diagnostics<br/>warnings.js"]
    end

    subgraph Compile["Compiler (producer of calls)"]
        C["compiler_client_transform_elements_and_directives<br/>TransitionDirective"]
    end

    subgraph API["Public surface"]
        A["svelte-types / public_api"]
    end

    T -->|"returns TransitionConfig (P)"| R1
    R1 -->|DEV warning for slide| R2
    P -->|types re-exported| A
    T -->|"defaults are local copies, NOT imports"| E
    T -->|"structurally same contract as"| F
    C -->|emits $.transition + import| T
```

## 4. Type Contracts (`public.d.ts`)

All built-in transitions are described by a single return type and a set of per-transition parameter interfaces. These types are re-exported through the package type surface ([svelte-types](svelte-types.md)).

```mermaid
classDiagram
    class TransitionConfig {
        +delay? : number
        +duration? : number
        +easing? : EasingFunction
        +css?(t : number, u : number) string
        +tick?(t : number, u : number) void
    }
    class EasingFunction {
        <<type>>
        (t: number) => number
    }
    class FadeParams {
        +delay? : number
        +duration? : number
        +easing? : EasingFunction
    }
    class BlurParams {
        +amount? : number|string
        +opacity? : number
    }
    class FlyParams {
        +x? : number|string
        +y? : number|string
        +opacity? : number
    }
    class SlideParams {
        +axis? : 'x'|'y'
    }
    class ScaleParams {
        +start? : number
        +opacity? : number
    }
    class DrawParams {
        +speed? : number
        +duration? : number | ((len)=>number)
    }
    class CrossfadeParams {
        +duration? : number | ((len)=>number)
    }
    EasingFunction ..> TransitionConfig : easing?
    FadeParams <|-- BlurParams : extends (structurally)
    FadeParams <|-- FlyParams
    FadeParams <|-- SlideParams
    FadeParams <|-- ScaleParams
    FadeParams <|-- DrawParams
    FadeParams <|-- CrossfadeParams
    BlurParams ..> TransitionConfig : consumed by blur()
    FlyParams ..> TransitionConfig : consumed by fly()
    SlideParams ..> TransitionConfig : consumed by slide()
    ScaleParams ..> TransitionConfig : consumed by scale()
    DrawParams ..> TransitionConfig : consumed by draw()
    CrossfadeParams ..> TransitionConfig : consumed by crossfade()
```

Key semantics of `TransitionConfig`:

- **`css(t, u)`** — returns a string of CSS declarations evaluated per frame. `t` is the eased progress (`0 → 1`, where `1` is "fully in") and `u = 1 − t`. Writing effects in terms of `u` makes the same config valid for both intro and outro directions without branching.
- **`tick(t, u)`** — imperative alternative to `css` for effects CSS cannot express. Mutually compatible with `css`, but `css`-only transitions can be driven entirely by Web Animations and never run JS per frame.
- **`delay`, `duration`, `easing`** — scheduling inputs consumed by the runtime's animation driver. `duration` may be a number **or a function of a measured distance** (`DrawParams`, `CrossfadeParams`) — this is resolved *inside* the transition functions before the config is returned.

## 5. Transition Catalogue

### 5.1 Overview

| Function | Animates | Default duration / easing | Params of note |
|---|---|---|---|
| `blur` | `opacity` + CSS `filter: blur()` | 400 ms / `cubic_in_out` | `amount` (number \| string, e.g. `"10px"`), `opacity` |
| `fade` | `opacity` | 400 ms / `linear` | — |
| `fly` | `opacity` + `transform: translate(x, y)` | 400 ms / `cubic_out` | `x`, `y` (number \| string), `opacity` |
| `slide` | `height`/`width` + margins, paddings, borders, opacity ramp | 400 ms / `cubic_out` | `axis: 'x' \| 'y'` |
| `scale` | `transform: scale()` + `opacity` | 400 ms / `cubic_out` | `start` (initial scale), `opacity` |
| `draw` | SVG `stroke-dasharray`/`stroke-dashoffset` | 800 ms or `len / speed` / `duration(len)` / `cubic_in_out` | `speed`, callable `duration` |
| `crossfade` | position + scale + opacity between two elements | `Math.sqrt(d) * 30` / `cubic_out` | `key` matching, `fallback` |

Common implementation pattern (all functions except `crossfade`):

1. **Read current computed styles** (`getComputedStyle`) to establish the *target* state (target opacity, existing transform chain, filter, dimensions) — transitions always animate **toward the element's natural styles**, never hard-code them.
2. **Normalize parameters** — e.g. `split_css_unit("1.5em")` → `[1.5, "em"]` so lengths can be composed per-frame with the correct unit; numbers default to `px`.
3. **Return a `TransitionConfig`** whose `css(t, u)` interpolates between the parameter-provided start state and the measured natural state.

### 5.2 `crossfade` — a transition *factory*

Unlike the others, `crossfade({ fallback })` is a higher-order function. It returns a **`[send, receive]` pair** of transition factories used to move elements between two lists (e.g. two `<ul>`s). Key mechanics:

- Each side keeps a **`Map<key, Element>`** of pending elements (`to_send`, `to_receive`).
- When a transition function is invoked, the node registers itself under `params.key` and returns a *deferred thunk*; the thunk is only executed when the runtime actually starts the animation.
- At thunk time, if a **counterpart with the same key exists**, the two elements' bounding rects (`getBoundingClientRect`) are compared and a config is produced that translates/scales/fades from one to the other (`transform-origin: top left`, duration defaults to `Math.sqrt(distance) * 30`).
- If **no counterpart** exists, the registered entry is removed and the user-supplied `fallback(node, params, intro)` runs instead (commonly `fade`).

```mermaid
sequenceDiagram
    participant A as List A element (send)
    participant B as List B element (receive)
    participant SendMap as to_send Map
    participant RecvMap as to_receive Map
    participant RT as runtime (Web Animations)

    Note over A,RecvMap: user creates one send/receive pair via crossfade({ fallback })
    A->>SendMap: register key k → node A
    A-->>RT: thunk (deferred)
    B->>RecvMap: register key k → node B
    B-->>RT: thunk (deferred)
    RT->>RecvMap: run A's thunk (outro)
    RecvMap-->>A: counterpart B found → crossfade(B→A): translate/scale/fade config
    RT->>SendMap: run B's thunk (intro)
    SendMap-->>B: counterpart A found → crossfade(A→B) config
    alt no counterpart found
        RT-->>A: fallback(node, params, intro)
    end
```

Both returned factories keep their maps in sync across invocations, which is why `crossfade` must be called **once at module or component scope** and the resulting `send`/`receive` reused.

## 6. Runtime Integration & Execution Flow

The runtime side is documented in detail in [client_dom_renderer_elements_and_events](client_dom_renderer_elements_and_events.md); this section covers only the handshake with this module.

```mermaid
sequenceDiagram
    participant Comp as Compiled component
    participant RT as $.transition (client runtime)
    participant Fn as transition fn (this module)
    participant WAAPI as animate() → Web Animations

    Note over Comp: compiled: $.transition(flags, node, thunk(fn), thunk(params)) in after_update
    Comp->>RT: transition(TRANSITION_IN|OUT|GLOBAL, element, thunk(fn), thunk(params))
    RT->>RT: decide intro/outro from flags; attach TransitionManager to active effect
    RT->>Fn: fn(element, params, { direction }) — inside without_reactive_context, cached (current_options ??=)
    Fn-->>RT: TransitionConfig { delay, duration, easing, css(t, u) }
    RT->>WAAPI: generate keyframes from css(t,u), schedule with delay/duration/easing
    Note over RT: intro → element.inert restored; outro → element.inert = true until done
    RT->>RT: dispatch introstart/introend/outrostart/outroend; abort & reverse smoothly reusing cached options
```

Design points relevant to this module's contract:

- **Lazy + memoized invocation.** `get_options()` wraps `fn(element, params)` in `without_reactive_context` and caches the result while a transition is running, so a reversible transition replays the *same* config instead of recomputing with changed params. Transition functions must therefore be cheap and side-effect free aside from reading layout.
- **Global vs local.** `flags` carry `TRANSITION_GLOBAL` and direction bits; *local* transitions only play when the state change happened in the same block (see runtime module docs).
- **Element restrictions.** `slide` emits a **dev-only warning** (`transition_slide_display`, via [client_runtime_core_diagnostics](client_runtime_core_diagnostics.md)) when the element's computed `display` is `contents`, `inline`, or a `table` type — layouts where animating height cannot work. The warning is emitted once, asynchronously, and self-resets via a microtask.
- **`flip` shares the contract.** The `animate:` directive's `flip` function ([transitions_and_animations_flip](transitions_and_animations_flip.md)) returns an `AnimationConfig` structurally identical to `TransitionConfig`, and is consumed by the *same* `$.animation` driver — the two systems are intentionally shape-compatible.

## 7. Data Flow Summary

```mermaid
flowchart LR
    P["params object<br/>(literal or reactive expression)"] --> N["normalize:<br/>defaults + split_css_unit"]
    S["computed styles<br/>(getComputedStyle)"] --> N
    M["layout measurement<br/>(getTotalLength, getBoundingClientRect)"] --> N
    N --> CFG["TransitionConfig<br/>css(t, u) closure capturing targets"]
    CFG --> KF["per-frame CSS strings<br/>@keyframes via WAAPI"]
    CFG --> TK["tick(t, u) per frame<br/>(JS effects)"]
```

Inputs to a config are computed **once**, when the runtime first requests options; the `css` closure then only does arithmetic per frame.

## 8. Usage Examples

```svelte
<script>
  import { blur, fly, slide, draw, crossfade, fade } from 'svelte/transition';
  import { cubicOut } from 'svelte/easing'; // optional richer easing

  const [send, receive] = crossfade({ fallback: fade });
</script>

<!-- both directions -->
<div transition:fade={{ duration: 200 }} />

<!-- directional -->
{#if visible}
  <p in:fly={{ y: 20, delay: 100 }} out:blur={{ amount: 10 }}>hi</p>
{/if}

<!-- axis-aware slide (warns in DEV if display is inline/contents/table) -->
<div transition:slide={{ axis: 'x' }} />

<!-- SVG stroke drawing; duration derived from path length / speed -->
<path transition:draw={{ speed: 2 }} d="..." />

<!-- string units are honoured, numbers are px -->
<div in:fly={{ x: '10vw' }} />
```

## 9. Related Documentation

- [transitions_and_animations](transitions_and_animations.md) — parent module: full motion system overview (`motion/`, `transition/`, `animate/`, `easing/`).
- [transitions_and_animations_easing](transitions_and_animations_easing.md) — easing catalogue accepted as the `easing` param; this module intentionally duplicates its three default easings for tree-shaking.
- [transitions_and_animations_flip](transitions_and_animations_flip.md) — `flip` animate function; same `AnimationConfig`/`TransitionConfig` shape, driven by the same engine.
- [client_dom_renderer_elements_and_events](client_dom_renderer_elements_and_events.md) — runtime consumers `$.transition` / `$.animation` (flags, lifecycle, Web Animations driving, event replay).
- [client_runtime_core_diagnostics](client_runtime_core_diagnostics.md) — internal warnings, including `transition_slide_display`.
- [compiler_client_transform_elements_and_directives](compiler_client_transform_elements_and_directives.md) — `TransitionDirective` visitor that compiles directives to `$.transition(...)` calls.
- [svelte-types](svelte-types.md) and [public_api_type_contracts](public_api_type_contracts.md) — public re-export surface for `TransitionConfig` and `*Params`.
- [motion_tweened](motion_tweened.md) / [motion_spring](motion_spring.md) — reactive value animation alternatives (not DOM enter/leave transitions).
