# Server Runtime Rendering Core (`server_runtime_rendering_core`)

> **Module location:** `packages/svelte/src/internal/server/index.js`
> **Parent group:** Component Rendering Backends → `server_runtime`
> **Public surface:** re-exported as `render` by `svelte/server` (`packages/svelte/src/server/index.js`)

## 1. Introduction

`server_runtime_rendering_core` is the heart of Svelte's **server-side rendering (SSR) engine**. It contains the single entry point `render()` — which executes a compiled component and assembles its HTML — together with all the low-level primitives that the compiler's server transform generates calls to: element emission, attribute serialization, slot resolution, store interop, and asynchronous block handling.

The module is deliberately *stateless between calls*. All mutable render state lives on a **`Payload`** object (see [server_runtime_payload_model](server_runtime_payload_model.md)) that is threaded by reference through every component and helper, allowing deeply nested component trees to contribute chunks to one output buffer without any global coordination.

**Key characteristics:**

- **Chunked output buffer** — HTML is emitted as an array of string chunks (`payload.out`), joined once at the end. This avoids quadratic string concatenation and enables post-hoc chunk rewriting (e.g. `valueless_option` injecting `selected`).
- **Hydration-annotated HTML** — every block is delimited with comment markers (`<!--[-->`, `<!--]-->`, `<!--[!-->`) so the client renderer can graft interactivity onto server output (see [client_dom_renderer](client_dom_renderer.md)).
- **Single import surface** — the module re-exports nearly every server helper, so compiler-generated code can do `import * as $ from 'svelte/internal/server'` and call `$.element`, `$.slot`, `$.store_get`, etc.
- **Shared-utility delegation** — escaping, attribute and style normalization are delegated to cross-runtime helpers, guaranteeing byte-identical behavior between SSR and hydration.

## 2. Position in the System

The module sits at the center of the server rendering path:

1. The **compiler** (`compiler_server_transform`) turns a `.svelte` file into a component function `(payload, props) => void` whose body calls into this module.
2. **`svelte/server`** ([public_api](public_api.md)) exposes `render(component, options)` to applications and meta-frameworks; the **legacy compatibility layer** ([legacy_compat](legacy_compat.md)) wraps the same function for class components.
3. The **payload model** ([server_runtime_payload_model](server_runtime_payload_model.md)) supplies the mutable `Payload`, unique-ID generation and abort signalling.
4. The **server context API** ([context_api](context_api.md)) maintains the `current_component` stack that `push()`/`pop()` manipulate, enabling `getContext`/`setContext` and `onDestroy` during SSR.
5. The produced HTML markers are consumed by the **client renderer** ([client_dom_renderer](client_dom_renderer.md)) during hydration.

## 3. Architecture

```mermaid
flowchart TB
    subgraph Consumers["Consumers"]
        PUB["Public API<br/>svelte/server"]
        LEGACY["Legacy compat layer<br/>legacy-server._render"]
        GEN["Compiler-generated SSR code<br/>(compiler_server_transform)"]
    end

    subgraph Core["server_runtime_rendering_core"]
        ENTRY["render()"]
        STRUCT["Structural emitters<br/>element / head / css_props / props_id"]
        ATTR["Attribute serialization<br/>spread_attributes / attr_class / attr_style / stringify"]
        PROPS["Props & slot plumbing<br/>slot / sanitize_props / sanitize_slots<br/>rest_props / spread_props / bind_props"]
        STORES["Store interop<br/>store_get / store_set / store_mutate<br/>update_store / update_store_pre / unsubscribe_stores"]
        ASYNC["Async & iteration<br/>await_block (exported as await) / ensure_array_like"]
        MISC["Misc helpers<br/>derived / once / maybe_selected / valueless_option"]
        REEXP["Re-export facade<br/>(html, push/pop, dev hooks,<br/>payload ops, validators, escape)"]
    end

    subgraph Support["Supporting modules"]
        PAYLOAD["server_runtime_payload_model<br/>Payload / abort"]
        CTX["context_api (server)<br/>push / pop / current_component"]
        BLOCKS["server_runtime_blocks<br/>html"]
        DEVV["server_runtime_dev_validation<br/>push_element / pop_element / reset_elements"]
        SHARED["shared_runtime + attribute utils<br/>attr / clsx / to_class / to_style<br/>escape_html / validate_store"]
    end

    PUB --> ENTRY
    LEGACY --> ENTRY
    GEN --> STRUCT
    GEN --> ATTR
    GEN --> PROPS
    GEN --> STORES
    GEN --> ASYNC
    GEN --> MISC
    GEN --> REEXP

    ENTRY --> PAYLOAD
    ENTRY --> CTX
    ENTRY --> DEVV
    STRUCT --> PAYLOAD
    ATTR --> SHARED
    STORES --> SHARED
    REEXP --> BLOCKS
```

### 3.1 Functional areas

| Area | Functions | Responsibility |
|---|---|---|
| **Entry point** | `render` | Executes a component, assembles `RenderOutput` (`{ head, html, body }`) |
| **Structural emitters** | `element`, `head`, `css_props`, `props_id` | Emit tags, `<head>` content, CSS custom-property wrappers, and `$props.id()` anchors |
| **Attribute serialization** | `spread_attributes`, `attr_class`, `attr_style`, `stringify` | Turn JS values into safe HTML attribute/text output |
| **Props & slots** | `slot`, `sanitize_props`, `sanitize_slots`, `rest_props`, `spread_props`, `bind_props` | Component-boundary contract between parents and children |
| **Store interop** | `store_get`, `store_set`, `store_mutate`, `update_store`, `update_store_pre`, `unsubscribe_stores` | Subscribe/mutate/unsubscribe stores during one-shot SSR |
| **Async & iteration** | `await_block` (`await`), `ensure_array_like` | `{#await}` pending/then rendering, `{#each}` normalization |
| **Misc** | `derived`, `once`, `maybe_selected`, `valueless_option`, `inspect` | SSR-compatible `$derived`, `<select>` support, `$inspect` |

## 4. Render Lifecycle

`render()` is the only function with lifecycle responsibility. Everything else is a passive emitter.

```mermaid
sequenceDiagram
    autonumber
    participant App as Application
    participant R as render()
    participant P as Payload
    participant C as Compiled component
    participant X as onDestroy queue

    App->>R: render(Component, { props, context, idPrefix })
    R->>P: new Payload(idPrefix)
    Note over P: uid = "prefix-s1, s2, ..." shared with head
    R->>R: save module-level on_destroy, reset it
    R->>P: push BLOCK_OPEN (<!--[-->)
    opt DEV
        R->>R: reset_elements() guards element stack
    end
    opt options.context
        R->>R: push() — new current_component frame
    end
    R->>C: component(payload, props, {}, {})
    Note over C,P: body emits chunks via element(), slot(),<br/>spread_attributes(), store_get(), ...
    C-->>R: returns
    opt options.context
        R->>R: pop() — flushes component.d into on_destroy
    end
    R->>P: push BLOCK_CLOSE (<!--]-->)
    R->>X: run every queued onDestroy callback
    R->>R: restore previous on_destroy (nesting-safe)
    R->>P: head = head.out.join + head.title + <style id=hash> per css entry
    R->>P: html = body = out.join("")
    R-->>App: { head, html, body }
    R->>R: finally: abort() — signal pending async work
```

**Step notes:**

1. **`on_destroy` save/restore** — the module keeps a module-level `on_destroy` array. `pop()` (from the server [context_api](context_api.md)) moves the current component's `d` list into it; `render()` then executes and *restores* the previous array, making nested renders safe (e.g. legacy `_render` inside a framework).
2. **`try/finally` + `abort()`** — even if a component throws, the payload's `AbortController` is aborted (see `getAbortSignal` in [server_runtime_payload_model](server_runtime_payload_model.md)) so any pending `{#await}` work can be cancelled by the host framework.
3. **Head assembly** — `head` output is `payload.head.out.join('')` plus `payload.head.title`, then one `<style id="{hash}">{code}</style>` per entry in `payload.css`. CSS hashes originate from the compiler CSS pipeline.
4. **Return shape** — `{ head, html, body }` where `body` is a legacy alias of `html`; consumers should prefer `html`. The type is `RenderOutput` from [server_runtime_payload_model](server_runtime_payload_model.md).

## 5. Payload-Centric Data Flow

All emitters write into the shared `Payload`; `render()` performs the single join. This is the core data flow of the module:

```mermaid
flowchart LR
    subgraph P["Payload (server_runtime_payload_model)"]
        OUT["out: string[]<br/>body chunk buffer"]
        HEAD["head: HeadPayload<br/>out[] + title + css set"]
        CSS["css: Set&#123; hash, code &#125;"]
        UID["uid(): prefix + s + n"]
        SEL["select_value"]
    end

    EMIT["Emitters<br/>element / head / css_props / slot / await_block / props_id"] -->|"push chunks"| OUT
    EMIT -->|"title & head content"| HEAD
    CSSSRC["Component CSS<br/>(compiler css pipeline)"] -->|"hash + code"| CSS
    PID["props_id()"] --> UID
    SELQ["maybe_selected / valueless_option"] --> SEL

    JOIN["render() final assembly"] --> OUT
    JOIN --> HEAD
    JOIN --> CSS
    JOIN --> RESULT["RenderOutput<br/>{ head, html, body }"]
```

### 5.1 Hydration marker contract

Because the client must reconstruct component structure from markup, the core inserts comment markers with exact byte sequences (defined in `internal/server/hydration.js`):

| Marker | Constant | Emitted by | Meaning |
|---|---|---|---|
| `<!--[-->` | `BLOCK_OPEN` | `render()`, `head()`, `await_block` (pending) | Opens a hydration block |
| `<!--]-->` | `BLOCK_CLOSE` | `render()`, `head()` | Closes a hydration block |
| `<!--[!-->` | `BLOCK_OPEN_ELSE` | `await_block` (resolved promise) | The `{:else}`/then branch was rendered |
| `<!---->` | `EMPTY_COMMENT` | `element()` (before/after tag and inside non-raw-text children), `css_props`, `props_id` surroundings | Separator preventing adjacent text gluing; hydration alignment anchor |
| `<!--#s1-->` | generated uid | `props_id()` | Anchor for `$props.id()` value sharing with the client |

The client renderer consumes these markers during hydration — see [client_dom_renderer](client_dom_renderer.md) (`hydration.js`, `template.js`).

## 6. API Reference

### 6.1 `render(component, options)` → `RenderOutput`

The public SSR entry point. Options: `props` (component props), `context` (`Map` seeded via `setContext`), `idPrefix` (prefix for `props_id` UIDs). Accepts both modern `Component` functions and legacy `SvelteComponent` classes (invoked as `component(payload, props, {}, {})`). Full behavior described in §4.

### 6.2 Structural emitters

- **`element(payload, tag, attributes_fn, children_fn)`** — wraps output in `<!---->` boundaries, emits `<tag …>`, invokes `attributes_fn` (which appends attribute strings into `payload.out`), then `children_fn`. Closing behavior is HTML-spec aware via `is_void` / `is_raw_text_element` (from `src/utils.js`): void elements skip children and the closing tag; raw-text elements (`script`, `style`, `textarea`) skip the inner `<!---->` separator.
- **`head(payload, fn)`** — brackets `fn`'s output with hydration markers inside `payload.head`, isolating `<svelte:head>` content from the body buffer.
- **`css_props(payload, is_html, props, component, dynamic)`** — implements `<svelte:options custom-element>`-style inherited CSS custom properties: HTML gets a `<svelte-css-wrapper style="display: contents; …">` wrapper, SVG gets `<g style="…">`. `dynamic` inserts an extra anchor comment.
- **`props_id(payload)`** — asks `payload.uid()` for the next ID, emits an `<!--#…-->` anchor and returns the UID. Backs the `$props.id()` rune.

### 6.3 Attribute serialization

| Function | Behavior |
|---|---|
| `spread_attributes(attrs, css_hash, classes, styles, flags)` | Merges `styles` (via `to_style`) and `class` (via `clsx` + `to_class`), appends the CSS scoping hash and `class:` directives, then serializes each entry with `attr()`. Filters: functions, `$$`-prefixed internal props, and names matching a WHATWG-invalid attribute character regex are dropped. `flags` bit `ELEMENT_IS_NAMESPACED` disables boolean-attribute handling; `ELEMENT_PRESERVE_ATTRIBUTE_CASE` disables lowercasing. |
| `attr_class(value, hash, directives)` / `attr_style(value, directives)` | Pre-serialized ` class="…"` / ` style="…"` fragments using `to_class` / `to_style`, HTML-escaped. |
| `stringify(value)` | Template text coercion: strings pass through, `null`/`undefined` become `''`, everything else `String(value)`. (Actual HTML escaping is applied by generated code through the re-exported `escape`/`escape_html` — see [shared_runtime](shared_runtime.md).) |

### 6.4 Props & slot plumbing

- **`slot(payload, $$props, name, slot_props, fallback_fn)`** — resolves `$$props.$$slots[name]`. Interop: if the value is `true` (snippets filling legacy slots), it falls back to `$$props.children` (default slot) or `$$props[name]`. Calls the resolved function with `(payload, slot_props)` or renders `fallback_fn`.
- **`sanitize_props(props)`** — strips `children` and `$$slots` before user code sees props.
- **`sanitize_slots(props)`** — builds the legacy `$$slots` presence map: `default: true` when `children` exists, plus every key of `$$slots`.
- **`rest_props(props, rest)`** — shallow copy excluding the listed keys (legacy `let:`/`$$restProps` support).
- **`spread_props(props[])`** — merges an attribute-spread list, **preserving property descriptors** so getters survive merging.
- **`bind_props(props_parent, props_now)`** — legacy two-way binding: when a bindable prop had no initial value (`undefined`) but the child produced one, and the parent object exposes a setter, the value is propagated upward.

### 6.5 Store interop

SSR runs each component exactly once, so store logic reduces to *subscribe → read → (maybe mutate) → unsubscribe*:

```mermaid
flowchart LR
    GEN["Generated code"] -->|"$.store_get($$store_subs, '$name', store)"| SG["store_get"]
    SG -->|"validate_store (DEV)"| V["shared validate"]
    SG --> CACHE["store_values[name] = [store, unsub, value]"]
    CACHE -->|"reuse if same store instance"| SG
    SG -->|"subscribe_to_store"| SUB["store/utils"]
    GEN -->|"$.store_mutate / $.update_store / $.update_store_pre"| MUT["mutate helpers<br/>(read + store.set)"]
    GEN -->|"$.unsubscribe_stores at teardown"| UNS["unsubscribe_stores"]
    UNS -->|"call every cached unsub"| CACHE
```

- `store_get` caches a `[store, unsubscribe, value]` triple per store name in the generated `$$store_subs` object; if the store *instance* changed (e.g. reassigned in the instance script), the old subscription is torn down and a new one created.
- `store_set(store, value)` sets and returns the value; `store_mutate` re-reads then re-sets (`$store += x` semantics) and returns the expression result.
- `update_store` / `update_store_pre` implement postfix (`$store++` → old value) and prefix (`++$store` → new value) semantics.
- `unsubscribe_stores` is called by generated teardown so no subscription outlives the render.

### 6.6 Async & iteration

- **`await_block` (exported as `await`)** — if the value is a promise: push `BLOCK_OPEN`, attach `promise.then(null, noop)` (prevents unhandled-rejection noise for work that resolves after the response), render `pending_fn`. Otherwise: push `BLOCK_OPEN_ELSE` and render `then_fn(promise)` synchronously. Deeper await orchestration (streams/boundaries) lives in [server_runtime_blocks](server_runtime_blocks.md).
- **`ensure_array_like(value)`** — `{#each}` normalization: array-likes pass through, iterables become `Array.from`, `null`/`undefined` become `[]`.

### 6.7 Misc helpers

- **`derived(fn)`** — SSR-compatible `$derived`: returns a callable that lazily computes the value once (via `once`, using the `UNINITIALIZED` sentinel); calling with an argument records an updated value (supports `bind:` to a derived). No reactivity graph is built — see the client equivalent in [client_runtime_core](client_runtime_core.md).
- **`maybe_selected(payload, value)`** — returns `' selected'` when `value === payload.select_value`.
- **`valueless_option(payload, children)`** — renders `<option>` children into the buffer, then if the flattened text (ignoring `<!---->` anchors) equals `payload.select_value`, **rewrites the previously emitted `<option>` chunk** to inject ` selected` and collapses the child chunks. This is only possible because the output buffer is an array of chunks.
- **`inspect(args, inspect)`** — SSR `$inspect`: logs `'init'` with the arguments once at component init.

## 7. Interaction with Compiler-Generated Code

The [compiler_server_transform](compiler_server_transform.md) backend lowers template AST nodes into calls against this module (aliased `svelte/internal/server` → `$`):

```mermaid
flowchart LR
    subgraph Visitors["compiler_server_transform visitors"]
        V_EL["RegularElement / SvelteElement"]
        V_SP["SpreadAttribute / Attribute"]
        V_FR["Fragment / process_children"]
        V_SL["SlotElement"]
        V_AW["AwaitBlock"]
        V_CO["Component"]
        V_EA["EachBlock"]
    end
    subgraph Calls["rendering core entry points"]
        C_EL["$.element / $.head / $.css_props"]
        C_SP["$.spread_attributes / $.attr_class / $.attr_style"]
        C_ST["$.stringify / $.escape"]
        C_SL["$.slot / $.sanitize_props / $.sanitize_slots"]
        C_AW["$.await / $.ensure_array_like"]
        C_CO["$.push / $.pop / $.bind_props / $.rest_props"]
        C_SR["$.store_get / $.unsubscribe_stores"]
    end
    V_EL --> C_EL
    V_SP --> C_SP
    V_FR --> C_ST
    V_SL --> C_SL
    V_AW --> C_AW
    V_EA --> C_AW
    V_CO --> C_CO
    V_CO --> C_SR
```

A simplified example of generated output:

```js
import * as $ from 'svelte/internal/server';

export function App($$payload, $$props) {
	$.push(true); // context frame (context_api)
	const { name = 'world', ...rest } = $.sanitize_props($$props);

	$$payload.out.push(`<h1${$.attr_class('title')}>Hello ${$.stringify(name)}</h1>`);

	$.slot($$payload, $$props, 'footer', {}, null); // <slot name="footer">

	$.pop(); // flushes onDestroy callbacks into render()'s queue
}
```

The module's **re-export facade** (bottom of `index.js`) exists precisely so generated code needs one import: `html`, `push`/`pop`, `push_element`/`pop_element`/`validate_snippet_args` ([server_runtime_dev_validation](server_runtime_dev_validation.md)), `assign_payload`/`copy_payload` ([server_runtime_payload_model](server_runtime_payload_model.md)), `snapshot`, `fallback`/`to_array`, shared validators (`invalid_default_snippet`, `validate_dynamic_element_tag`, `validate_void_dynamic_element`), `escape` (→ `escape_html`), `await_outside_boundary`, `attr`/`clsx`, and the `FILENAME`/`HMR` symbols.

## 8. Security & Correctness Notes

- **Escaping** — attribute values and text are escaped via `escape_html(value, true|false)` (`src/escaping.js`); class/style assembly re-escapes the *combined* result.
- **Attribute name validation** — `spread_attributes` rejects names containing whitespace, quotes, `/`, `=`, `>` and WHATWG noncharacters, and omits `$$`-internal keys, so user-provided spread objects cannot smuggle arbitrary markup.
- **Boolean attributes** — rendered valueless when the name is in the HTML boolean set and the namespace is HTML.
- **Raw text & void elements** — `element()` consults `is_void` / `is_raw_text_element` to emit spec-compliant markup.
- **DEV instrumentation** — in development, `render()` resets the element stack (`reset_elements`) so a throwing render cannot corrupt a subsequent render's parent/child validation state maintained by [server_runtime_dev_validation](server_runtime_dev_validation.md).

## 9. Dependencies

### 9.1 Internal module dependencies

| Dependency | Used for |
|---|---|
| [server_runtime_payload_model](server_runtime_payload_model.md) | `Payload`, `assign_payload`, `copy_payload`, `props_id_generator`, `getAbortSignal`/`abort`, `RenderOutput` type |
| [server_runtime_blocks](server_runtime_blocks.md) | `html` block (raw `{@html}` output), `createRawSnippet` |
| [server_runtime_dev_validation](server_runtime_dev_validation.md) | `push_element`, `pop_element`, `validate_snippet_args`; `reset_elements` inside `render()` |
| [context_api](context_api.md) (server flavor) | `push`, `pop`, `current_component` — context frames and `onDestroy` flushing |
| [shared_runtime](shared_runtime.md) | `noop`, `is_promise`, `fallback`, `to_array`, `snapshot`, `validate_store`, `invalid_default_snippet`, `validate_dynamic_element_tag`, `validate_void_dynamic_element`, `prevent_snippet_stringification`, `await_outside_boundary`; shared attribute helpers `attr`, `clsx`, `to_class`, `to_style`; `subscribe_to_store` from store utils |
| `src/escaping.js` | `escape_html` (re-exported as `escape`) |
| `src/utils.js` | `is_void`, `is_raw_text_element`, `is_boolean_attribute` |
| `src/constants.js` | hydration markers, element flags, `UNINITIALIZED`, `FILENAME`, `HMR` |

### 9.2 Reverse dependencies (who uses this module)

| Consumer | Usage |
|---|---|
| [public_api](public_api.md) | `svelte/server` re-exports `render`; `index-server.js` `onDestroy` cooperates with `pop()`'s `on_destroy` queue |
| [compiler_server_transform](compiler_server_transform.md) | Generates `$.`-prefixed calls into every API group (§7) |
| [legacy_compat](legacy_compat.md) | `legacy-server.js::_render` wraps `render()` for class components |
| [client_dom_renderer](client_dom_renderer.md) | Consumes the hydration markers and `$props.id()` anchors produced here (runtime counterpart, not an import) |

## 10. Related Modules

- [server_runtime](server_runtime.md) — parent grouping containing this module, the payload model, blocks and dev validation.
- [server_runtime_payload_model](server_runtime_payload_model.md) — `Payload`/`HeadPayload` internals, UID generation, abort signalling, `RenderOutput`.
- [server_runtime_blocks](server_runtime_blocks.md) — `{@html …}` and raw snippet blocks.
- [server_runtime_dev_validation](server_runtime_dev_validation.md) — element-stack HTML validation and snippet argument checks.
- [context_api](context_api.md) — `setContext`/`getContext` implemented on top of the `current_component` frames this module pushes.
- [client_dom_renderer](client_dom_renderer.md) — the hydration client that parses the markers defined in §5.1.
- [client_runtime_core](client_runtime_core.md) — signals/effects engine powering the client-side counterparts of `derived` and store helpers.
- [Compiler_Back-End_(Client___Server_Code_Generation)](Compiler_Back-End_(Client___Server_Code_Generation).md) — the transform phase that produces the generated code shown in §7.
