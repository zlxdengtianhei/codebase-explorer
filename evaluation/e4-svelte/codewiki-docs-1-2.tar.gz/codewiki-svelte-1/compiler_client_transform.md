# Compiler Client Transform (`compiler_client_transform`)

> **Location:** `packages/svelte/src/compiler/phases/3-transform/client/`
> **Parent module:** Compiler Back-End (Client & Server Code Generation)
> **Sibling module:** `compiler_server_transform` (the SSR counterpart, sharing the same AST input and analysis)

## 1. Purpose

The **client transform** is the code-generation back-end that turns an *analyzed* Svelte component AST into an executable **client-side JavaScript program** (an ESTree AST that is later printed by esrap). For a component like:

```svelte
<script>
        let count = $state(0);
</script>

<button onclick={() => count++}>
        {count}
</button>
```

it emits (schematically):

```js
import * as $ from 'svelte/internal/client';

const button = $.template(`<button> <!></button>`);

export default function App($$anchor, $$props) {
        $.push($$props, true);
        let count = $.state(0);

        $.init();
        var b = button();
        var t = $.child(b, true);

        $.template_effect(() => $.set_text(t, $.get(count)));
        $.event('click', b, () => count++, false);
        $.append($$anchor, b);
        $.pop();
}
```

Three concerns dominate everything this module does:

1. **Static template hoisting** — markup that never changes is baked into a single HTML string, cloned once per component instantiation (`$.template` → runtime `from_html`), and referenced by *anchor comments* and cheap `$.child`/`$.sibling` traversal instead of `createElement` calls.
2. **Fine-grained reactivity wiring** — every reactive read is rewritten to `$.get(signal)`, every write to `$.set/assign`, and every DOM update that depends on state is wrapped in a `$.template_effect` render effect.
3. **Ordering discipline** — generated statements are sorted into well-defined buckets (`init` → render effect → `after_update`) because DOM setup, bindings, actions and transitions have ordering requirements relative to each other.

## 2. Position in the compiler pipeline

```mermaid
flowchart LR
    subgraph FrontEnd["Compiler Front-End"]
        P["1-parse<br/>(compiler_parser)"] --> A["2-analyze<br/>(compiler_analyzer)"]
        A --> CSSA["CSS analysis<br/>(compiler_css_pipeline)"]
    end
    subgraph BackEnd["Compiler Back-End"]
        T["3-transform<br/>(this module: client)<br/>+ compiler_server_transform"]
    end
    subgraph Runtime["Runtime (generated code's target)"]
        CR["client_dom_renderer<br/>(svelte/internal/client)"]
        SR["server_runtime"]
    end
    A -->|"AST + Analysis<br/>(scopes, bindings, metadata)"| T
    CSSA -->|"css hash / scoping info"| T
    T -->|"imports `svelte/internal/client`<br/>`$.*` helper calls"| CR
```

The client transform receives:

- **`analysis`** — the `ComponentAnalysis` produced by the analyzer: root AST, `Scope`/`Binding` information per script segment, `state_fields` (for class `$state`), `reactive_statements` (legacy `$:`), `css.hash` for scoping, expression metadata (`has_state`, `has_await`, …).
- **`options`** — validated `CompileOptions` (`generate: 'client'`, `dev`, `runes`, `experimental.async`, `fragments`, HMR, custom element config, …).

and produces an `ESTree.Program`. The same analysis is independently processed by [`compiler_server_transform`](compiler_server_transform.md) for SSR output.

## 3. Architecture overview

The single entry point is **`transform-client.js::client_component(analysis, options)`**. It runs the AST through three sequential `zimmerframe` walks that share one visitor map:

```mermaid
flowchart TB
    subgraph client_component["client_component(analysis, options)"]
        direction TB
        W1["walk #1<br/>module script AST<br/>(state.is_instance = false)"] --> W2["walk #2<br/>instance script AST<br/>(is_instance = true)"]
        W2 --> W3["walk #3<br/>template AST<br/>(inherits instance transform map)"]
    end
    W3 --> OUT["ESTree.Program:<br/>imports + hoisted templates +<br/>export default function App()"]
    subgraph Buckets["ComponentClientTransformState buckets"]
        INIT["init[]<br/>one-time setup"]
        UPD["update[]<br/>→ $.template_effect"]
        AU["after_update[]<br/>bindings, actions, transitions"]
        CST["consts[]<br/>{@const} deriveds"]
        HO["hoisted[]<br/>templates & module code"]
        TMPL["template: Template<br/>static HTML string"]
    end
    W1 & W2 & W3 -.->|visitors push statements| Buckets
```

### 3.1 The state machine

Every visitor receives a `ComponentContext` (a `zimmerframe` context) whose `state` is a `ComponentClientTransformState` (declared in `client/types.d.ts`, extending `TransformState`):

| Field | Role |
| --- | --- |
| `analysis`, `options`, `scope`, `scopes` | Immutable compile context, current scope lookup |
| `transform` | **The heart of reactivity rewriting**: `name → { read, assign?, mutate? }` functions that rewrite each reference of a reactive binding |
| `init` / `update` / `after_update` / `consts` | Statement buckets (see below) |
| `template` | The `Template` object accumulating the static HTML of the current fragment |
| `memoizer` | `Memoizer` instance deduplicating call/await expressions inside effect closures |
| `node` | Identifier of the current DOM anchor (the node new content is inserted before) |
| `hoisted`, `instance_level_snippets`, `module_level_snippets` | Code lifted out of the template body (templates, top-level snippets, imports) |
| `legacy_reactive_statements` | `$:` statements serialized for topological ordering (legacy mode) |
| `state_fields` | Class `$state`/`$derived` fields for class-based components |

### 3.2 Statement buckets and their runtime contract

```mermaid
flowchart LR
    subgraph ComponentFn["function App($$anchor, $$props)"]
        PUSH["$.push($$props, runes)"] --> SETUP["consts + init statements<br/>(blocks, elements, snippets)"]
        SETUP --> RE["render effect:<br/>$.template_effect(() => update...)"]
        RE --> AFTERU["after_update:<br/>bindings, actions, transitions"]
        AFTERU --> POP["$.pop($$exports)"]
    end
```

| Bucket | Generated into | Runtime semantics |
| --- | --- | --- |
| `init` | component/fragment body | Runs once: template cloning, block creation (`$.if`, `$.each`, …), events, actions |
| `update` | `$.template_effect(…)` closure (via `build_render_statement`) | Re-runs whenever read signals change; guarded by `value !== (value = …)` dirty checks |
| `after_update` | after the render effect | `bind:` directives, `use:` actions, `transition:` — must run after attribute updates |
| `consts` | before `init` | `{@const}` declarations become `$.derived` consts |

### 3.3 Static templates and anchors

The `Template` class (detailed in [compiler_client_transform_templates](compiler_client_transform_templates.md)) accumulates static markup while visitors walk the tree. `Fragment`/`RegularElement` push elements/attributes/text; `transform_template(state, namespace, flags)` finally emits either:

- `$.from_html('<div class="svelte-x">…</div>')` (HTML namespace),
- `$.from_svg` / `$.from_mathml`, or
- `$.from_tree([...])` (the `fragments: 'tree'` option), plus `$.with_script` wrappers for `<script>` tags and `$.add_locations` in dev mode.

Dynamic content is anchored with comments (`<!>`) and reached via `$.child`/`$.sibling`; `process_children` batches consecutive text/expression tags into single text nodes and decides between `init` assignment and reactive `$.set_text`.

### 3.4 Expression rewriting & memoization

- `build_getter` applies each binding's `transform[name].read`, which usually becomes `$.get(name)`.
- The `Memoizer` hoists expressions containing calls or `await`s out of effect closures into `$0`, `$1, …` locals — sync ones become deriveds (`Memoizer.deriveds`), async ones feed the `$.async(node, values, fn)` machinery.

## 4. Sub-modules

The module splits into five functional areas. Detailed documentation for each:

| Sub-module | Documentation | Contents |
| --- | --- | --- |
| **Templates & fragments** | [compiler_client_transform_templates](compiler_client_transform_templates.md) | `Template` class (`stringify`, `objectify`), `transform_template`, `Fragment` visitor, `clean_nodes`, whitespace trimming, namespace inference (`3-transform/utils.js`) |
| **State & reactivity** | [compiler_client_transform_state_and_reactivity](compiler_client_transform_state_and_reactivity.md) | `build_getter`, `get_prop_source`, `is_state_source`, `should_proxy`, `create_derived`, hoisted function params, `Identifier`/`MemberExpression`/`AssignmentExpression`/`CallExpression` rewriting, class `$state` fields (`ClassBody`), `visit_function` |
| **Control-flow blocks** | [compiler_client_transform_control_flow_blocks](compiler_client_transform_control_flow_blocks.md) | `{#if}` `{#each}` `{#await}` `{#key}` `<svelte:boundary>`, `{@html}` `{@render}` `{@const}` `{@debug}`, snippets (`{#snippet}`/`<slot>`/`<svelte:fragment>`) |
| **Elements & directives** | [compiler_client_transform_elements_and_directives](compiler_client_transform_elements_and_directives.md) | `RegularElement`/`SvelteElement` serialization, `bind:`/`on:`/`use:`/`transition:`/`let:`/`@attach` directives, spread attributes, `<svelte:body|window|document|head>`, `<title>` |
| **Components & scripts** | [compiler_client_transform_components_and_scripts](compiler_client_transform_components_and_scripts.md) | `<Component>`/`<svelte:component>`/`<svelte:self>` instantiation, imports/exports, `await` expressions, dev equality checks, `$effect`/`$inspect` runes, legacy `$:` reactive statements |

## 5. Visitor interaction model

```mermaid
sequenceDiagram
    participant FC as Fragment visitor
    participant RE as RegularElement visitor
    participant BD as BindDirective visitor
    participant T as Template
    participant S as State buckets

    FC->>T: push_element("div") / push_comment()
    FC->>S: init += var div = root()
    FC->>RE: visit(<div bind:value on:click>)
    RE->>T: set_prop("class", hash)
    RE->>S: init/update += attribute setters
    RE->>BD: visit(bind:value)
    BD->>S: after_update += $.bind_value(div, get, set)
    RE->>S: after_update += event handler
    FC->>S: update += build_render_statement()
    FC->>S: init += $.append($$anchor, div)
```

Visitors never generate DOM code directly — they *contribute statements* to the buckets of the ambient state, and the enclosing `Fragment` (or `RegularElement` for scoped children) assembles the final block: `consts` → optional `$.aborted` check → `$.next` (hydration skip) → `init` → render effect → `after_update` → closing `$.append`.

## 6. Key cross-cutting behaviors

- **Runes vs. legacy mode** — `analysis.runes` switches helper selection (`$.derived` vs `$.derived_safe_equal`), enables prop-source optimizations, and disables legacy `$:` machinery (see `LabeledStatement`, `EachBlock` invalidation sequences).
- **Async / experimental async support** — expression metadata `has_await` causes surrounding blocks to be wrapped in `$.async(node, values, fn)` / `$.async_body`, with values passed as parameters (`$$collection`, `$$condition`, `$$key`, `$$tag`, `$$html`).
- **Dev-mode instrumentation** — `dev` toggles: `$.equals`/`$.strict_equals` wrappers, `$.tag` state labels, ownership validation (`validate_mutation`, `$$ownership_validator`), reactivity-loss tracking for `await`/`for await`, `console.log` state inspection, `$.validate_each_keys`, snippet-arg validation, HMR wiring.
- **CSS scoping** — static `class` attributes receive the analysis CSS hash (from `compiler_css_pipeline`); scoped updates flow through `build_set_class`/`build_set_style`.
- **Namespaces** — `infer_namespace` / `determine_namespace_for_children` propagate `html`/`svg`/`mathml` context so correct template functions and attribute casing are used.

## 7. Relationship to other modules

- [`compiler_analyzer`](compiler_analyzer.md) — computes every piece of metadata this module consumes (`Binding.kind`, expression `has_state`/`has_await`/`has_call`, `metadata.scoped`, each-block flags).
- [`compiler_server_transform`](compiler_server_transform.md) — parallel SSR back-end; both share `3-transform/utils.js` (`clean_nodes`, namespace logic) and the `shared/assignments.js` logic.
- [`compiler_css_pipeline`](compiler_css_pipeline.md) — produces the `css.hash` used to scope class attributes here.
- [`client_dom_renderer`](client_dom_renderer.md) — the runtime implementation of all `$.`* helpers the generated code calls (`$.template`, `$.get`, `$.if`, `$.bind_value`, …).
- [`compiler_core`](compiler_core.md) — `compile()` orchestration calls the transform phase and prints the resulting ESTree AST; `utils/builders.js` (`b.*`) is the AST-construction DSL used pervasively.
- [`client_dev_mode`](client_dev_mode.md) — implements many dev helpers injected here (`assign*`, `equals`, `tag`, `hmr`, ownership).

## 8. Further reading

- Per-node visitor reference: see the five sub-module documents linked in §4.
- Types: `client/types.d.ts` defines `TransformState` → `ClientTransformState` → `ComponentClientTransformState`; `transform-template/types.d.ts` types the `Template` node model.
