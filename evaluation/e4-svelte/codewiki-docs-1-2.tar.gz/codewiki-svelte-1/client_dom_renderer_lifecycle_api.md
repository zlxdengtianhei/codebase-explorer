# Client DOM Renderer — Lifecycle API (`client_dom_renderer_lifecycle_api`)

## 1. Introduction

The **`client_dom_renderer_lifecycle_api`** module is the *entry and exit gate* of Svelte's client-side runtime. It lives in a single file — `packages/svelte/src/internal/client/render.js` — and owns the three operations that bracket the entire lifetime of every client-rendered component:

| Export | Role |
| --- | --- |
| `mount` / `hydrate` | **Birth** — instantiate a compiled component inside a DOM target (fresh render, or adoption of server-rendered HTML) |
| `set_text` | **Update** — the primitive used by generated code for reactive text-node updates |
| `unmount` | **Death** — tear down a previously mounted/hydrated component, optionally playing outro transitions |

Everything a `.svelte` file becomes in the browser is ultimately driven through this module: the compiler's client transform (see [compiler_client_transform](compiler_client_transform.md)) emits code whose component function is *invoked* by `_mount`, and every reactive effect it creates is rooted in the effect tree that `_mount` establishes.

Although only `hydrate`, `set_text` and `unmount` are listed as the module's core components, the file also contains the shared internal `_mount` engine, the public `mount` wrapper, and the `should_intro` transition flag — all of which are covered here because they are inseparable from the lifecycle semantics.

---

## 2. Position in the System

```
 svelte (public entry: index-server.js / index-client.js)
   └── mount / hydrate / unmount            ← Public API surface
         └── client_dom_renderer_lifecycle_api (render.js)   ← THIS MODULE
               ├── dom foundation (hydration / operations / template)
               ├── reactivity engine (component_root / branch effects)
               ├── event delegation system
               └── compiled component function  (from the compiler)
```

The module is a sibling of the other `client_dom_renderer` submodules and sits **on top** of them:

* **[client_dom_renderer_dom_foundation](client_dom_renderer_dom_foundation.md)** — supplies DOM primitives (`init_operations`, `get_first_child`, `get_next_sibling`, `create_text`, `clear_text_content`), the hydration cursor (`hydrating`, `hydrate_node`, `set_hydrating`, `set_hydrate_node`, `hydrate_next`) and template cloning (`assign_nodes`).
* **[client_runtime_core](client_runtime_core.md)** — supplies the effect model (`component_root`, `branch`, `active_effect`) and the scheduler that `_mount` plants the component into.
* **[client_dom_renderer_elements_and_events](client_dom_renderer_elements_and_events.md)** — supplies the global event-delegation registry (`all_registered_events`, `root_event_handles`, `handle_event_propagation`) whose root listeners this module attaches and detaches.
* **[client_dom_renderer_control_flow_blocks](client_dom_renderer_control_flow_blocks.md)** — `reset_head_anchor` (from the `svelte-head` block) is reset in `hydrate`'s `finally` clause.
* **[client_runtime_core_diagnostics](client_runtime_core_diagnostics.md)** — hydration-mismatch warnings and the `hydration_failed` error.
* **[Public_API_Surface___Compatibility_Layer](Public_API_Surface___Compatibility_Layer.md)** — re-exports `mount`/`hydrate`/`unmount` as the public `svelte` package API.

---

## 3. Architecture

```mermaid
flowchart TB
    subgraph Public["Public API Surface"]
        IDX["svelte (index entries)<br/>mount · hydrate · unmount"]
    end

    subgraph Module["render.js — Lifecycle API"]
        M["mount(component, options)"]
        H["hydrate(component, options)"]
        IM["_mount(Component, options)"]
        ST["set_text(text, value)"]
        UM["unmount(component, options)"]
        SI["should_intro / set_should_intro"]
        MC["mounted_components<br/>(WeakMap instance → teardown fn)"]
        DL["document_listeners<br/>(Map event → refcount)"]
    end

    subgraph Foundation["client_dom_renderer_dom_foundation"]
        OPS["operations.js<br/>init_operations · get_first_child<br/>get_next_sibling · create_text · clear_text_content"]
        HYD["hydration.js<br/>hydrating · hydrate_node<br/>set_hydrating · set_hydrate_node · hydrate_next"]
        TPL["template.js<br/>assign_nodes"]
    end

    subgraph Engine["client_runtime_core"]
        EFF["reactivity/effects.js<br/>component_root · branch"]
        RT["runtime.js<br/>active_effect"]
    end

    subgraph Events["client_dom_renderer_elements_and_events"]
        EV["events.js<br/>all_registered_events · root_event_handles<br/>handle_event_propagation"]
    end

    subgraph Compiled["Compiler Output"]
        CFN["Component(anchor, props)<br/>(client transform)"]
    end

    IDX --> M & H & UM
    H -->|"validate anchors, enable hydration mode"| IM
    H -->|"recovery fallback"| M
    M --> IM
    IM --> OPS
    IM --> EFF
    IM --> EV
    IM -->|"invokes synchronously"| CFN
    IM -->|"records teardown"| MC
    UM -->|"lookup + delete"| MC
    CFN --> SI
    CFN --> ST
    H --> HYD
    IM --> TPL
    EFF --> RT
```

### 3.1 Module state

The module holds four pieces of module-level state:

| State | Type | Purpose |
| --- | --- | --- |
| `should_intro` | `boolean` (mutable, exported) | Whether the *next* component instantiation plays intro transitions. Defaults to `true`; forced to `false` during hydration (unless `options.intro === true`) and while re-creating children of a `<svelte:element>` whose tag changed. Restored to `true` immediately after `Component(...)` returns inside `_mount`. |
| `document_listeners` | `Map<string, number>` | Ref-counts document-level delegated listeners so multiple mounted roots share one listener per event name. |
| `mounted_components` | `WeakMap<instance, teardown>` | Links each component instance object returned by `mount`/`hydrate` to its teardown function; enables `unmount(instance)`. `WeakMap` prevents leaks when users discard instances. |
| `event_handle` (per mount) | closure | Added to `root_event_handles` so that HMR/dev tooling can re-wire `mount(..., { events })` handlers after hot reload. |

---

## 4. Component Reference

### 4.1 `mount(component, options)` → `Exports`

Public entry for pure client-side rendering.

1. Delegates to `_mount`.
2. Transitions play during the initial render unless `options.intro === false` (`should_intro` is initialized from `intro`, default `true`).
3. Options: `target` (required), `anchor`, `props`, `events`, `context`, `intro`.
4. Returns the component's exported object (`Exports`), populated synchronously because the component's render effect runs synchronously inside `component_root`.

### 4.2 `hydrate(component, options)` → `Exports`

Public entry for adopting server-rendered markup (SSR output from the [server_runtime](server_runtime.md) module).

Semantics:

1. `init_operations()` — lazily caches native getters and installs the `__click`/`__attributes`/`__t`… fast-path slots on prototypes.
2. `options.intro` defaults to `false` — hydration must not replay intros on content that already exists.
3. Scans the target's children for the **hydration start anchor**: the first `Comment` node whose `data === HYDRATION_START` (`<!--→`, emitted by the server renderer). If none is found, `HYDRATION_ERROR` is thrown (and handled by the recovery path below).
4. Switches the runtime into hydration mode (`set_hydrating(true)`, `set_hydrate_node(anchor)`, `hydrate_next()`), so every `template.js`/`operations.js` primitive stops cloning and starts *claiming* existing nodes instead.
5. Calls `_mount` with the anchor; the compiled component's template claims nodes as it builds its effect tree, and `assign_nodes` records the claimed span on the root effect.
6. After mounting, validates the **hydration end anchor**: `hydrate_node` must sit exactly on the `HYDRATION_END` comment. Otherwise a `hydration_mismatch` warning is issued and `HYDRATION_ERROR` is thrown.
7. **Error recovery:** any thrown error is inspected —
   * Svelte compile/runtime errors (message lines starting with `https://svelte.dev/e/`) are re-thrown untouched;
   * a genuine `HYDRATION_ERROR` is silent;
   * other failures are logged via `console.warn('Failed to hydrate: ', …)`.
   Unless `options.recover === false` (which raises the `hydration_failed` error), the target's content is cleared (`clear_text_content`) and the component is **fall back to a full client-side `mount`** — hydration failure degrades to CSR instead of a broken page.
8. `finally` always restores the previous hydration cursor/mode and calls `reset_head_anchor()` so nested `svelte:head` state does not leak between mounts.

### 4.3 `_mount(Component, options)` → `Exports` *(internal)*

The shared engine behind both `mount` and `hydrate`:

1. `init_operations()` (idempotent).
2. Registers **event delegation roots**: iterates the global `all_registered_events` set and attaches `handle_event_propagation` to the *target* (with `passive` hints from `is_passive_event`) and, ref-counted via `document_listeners`, to the *document* (catching nodes portaled out of the container). A single `event_handle` closure is stored in `root_event_handles` for later re-registration (e.g. by the HMR wrapper in [client_dev_mode](client_dev_mode.md)).
3. Creates the component's **root effect** via `component_root(() => { … })`:
   * materializes an anchor text node if none was supplied (`target.appendChild(create_text())`);
   * wraps the instantiation in a `branch(...)` effect;
   * optionally pushes a component context carrying the caller-supplied `context` Map (see [context_api](context_api.md));
   * attaches `$$events` onto `props` when declarative events were passed;
   * during hydration, primes `assign_nodes(anchor_node, null)` so claimed-node bookkeeping starts at the anchor;
   * sets `should_intro = intro`, **synchronously invokes the compiled `Component(anchor_node, props)`**, restores `should_intro = true`, and records `active_effect.nodes_end` from the hydration cursor.
   * pops the pushed context.
4. Returns a **teardown closure** that (a) removes all target listeners, (b) decrements/removes document listeners, (c) deletes the handle from `root_event_handles`, and (d) removes the synthetic anchor text node if it created one. `component_root` wraps this so calling it yields a `Promise` that resolves after outro transitions (see `unmount`).
5. `mounted_components.set(instance, teardown)` binds instance → teardown.

> The returned instance object is `Component(...) || {}`; it is assigned *before* `_mount` returns because the root effect's render function runs synchronously.

### 4.4 `set_text(text, value)`

The cheapest hot path in the runtime; generated code calls it from text effects.

```js
var str = value == null ? '' : typeof value === 'object' ? value + '' : value;
if (str !== (text.__t ??= text.nodeValue)) {
    text.__t = str;
    text.nodeValue = str + '';
}
```

* **Coercion first:** `null`/`undefined` become `''`; objects are string-coerced (`value + ''`) *before* diffing — this keeps `$state` proxies (whose `toString` may be reactive) observable.
* **Cache (`__t`):** the last rendered string is memoized on the text node itself (slot initialized on the `Text.prototype` by `init_operations`). DOM writes happen only when the string actually changed — the `nodeValue` read/write round-trip is paid at most once per node.
* `__t` is a private slot by convention; `init_operations` pre-defines it only when prototypes are extensible (never when the app freezes built-ins).

### 4.5 `unmount(component, options)` → `Promise<void>`

1. Looks up the teardown in `mounted_components` and **deletes the entry** (a second `unmount` for the same instance is a no-op; in `DEV` it raises `lifecycle_double_unmount`).
2. Invokes the teardown (the `component_root` cleanup) with `{ outro }`:
   * `outro: true` — outro transitions play; the returned `Promise` resolves only after they finish (behaviour added in 5.13.0; earlier versions returned `void`).
   * otherwise the root effect is destroyed immediately and the promise resolves right away.
3. If the instance is unknown, resolves immediately.

```js
import { mount, unmount } from 'svelte';
import App from './App.svelte';
const app = mount(App, { target: document.body });
// later…
unmount(app, { outro: true });
```

---

## 5. Process Flows

### 5.1 Mount (client-only render)

```mermaid
sequenceDiagram
    participant U as Application
    participant M as mount
    participant IM as _mount
    participant EV as events.js (delegation)
    participant RE as effects.js (component_root/branch)
    participant C as Compiled Component

    U->>M: mount(App, { target, props })
    M->>IM: _mount(App, options)
    IM->>IM: init_operations()
    IM->>EV: addEventListener(all_registered_events) on target + document (ref-counted)
    IM->>RE: component_root(() => …)
    RE->>RE: Batch.ensure() · create ROOT_EFFECT
    IM->>RE: branch(() => …)  (BRANCH_EFFECT)
    IM->>IM: push context (if given) · props.$$events (if given)
    IM->>IM: should_intro = options.intro ?? true
    IM->>C: Component(anchor_node, props)
    C-->>IM: exports object (synchronous render effect)
    IM->>IM: should_intro = true · pop context
    IM->>IM: mounted_components.set(instance, teardown)
    IM-->>M: exports
    M-->>U: exports
```

### 5.2 Hydrate (SSR adoption) with recovery fallback

```mermaid
flowchart TD
    A["hydrate(App, { target, recover? })"] --> B["init_operations() · intro defaults to false"]
    B --> C{"Find <!--HYDRATION_START--> anchor<br/>in target.children"}
    C -->|"not found"| ERR["throw HYDRATION_ERROR"]
    C -->|"found"| D["set_hydrating(true) · set_hydrate_node(anchor) · hydrate_next()"]
    D --> E["_mount(App, { …, anchor })<br/>template claims existing nodes via hydration cursor"]
    E --> F{"hydrate_node is on<br/><!--HYDRATION_END--> ?"}
    F -->|"no"| G["warn hydration_mismatch<br/>throw HYDRATION_ERROR"]
    F -->|"yes"| H["set_hydrating(false) · return exports"]
    ERR --> REC
    G --> REC
    E -->|"arbitrary runtime error"| X{"Svelte error?<br/>(svelte.dev/e/ URL line)"}
    X -->|"yes"| RT["re-throw as-is"]
    X -->|"no"| W["console.warn('Failed to hydrate: ')"]
    W --> REC{"options.recover === false ?"}
    REC -->|"true"| HF["throw hydration_failed"]
    REC -->|"false"| FB["init_operations() · clear_text_content(target)<br/>set_hydrating(false) · mount(App, options)"]
    FB --> H2["fresh client-side render · return exports"]
    A -.finally.-> Z["restore hydration mode/cursor · reset_head_anchor()"]
```

Key points:

* During `_mount` under hydration mode, the whole DOM-foundation layer switches behaviour: `from_html`/`first_child`/`sibling` stop cloning and advance `hydrate_node` through the existing markup instead (details in [client_dom_renderer_dom_foundation](client_dom_renderer_dom_foundation.md)).
* `recover: false` is the escape hatch for apps that must never silently re-render (e.g. strict SSR contract testing).

### 5.3 Unmount

```mermaid
sequenceDiagram
    participant U as Application
    participant UM as unmount
    participant MC as mounted_components (WeakMap)
    participant CR as component_root teardown
    participant TX as Transitions

    U->>UM: unmount(instance, { outro? })
    UM->>MC: get(instance) · delete(instance)
    alt instance known
        UM->>CR: teardown({ outro })
        alt outro === true
            CR->>TX: pause_effect → play outros
            TX-->>CR: transitions finished
        else outro falsy
            CR->>CR: destroy_effect immediately
        end
        CR-->>UM: resolve Promise
        UM-->>U: Promise<void>
    else unknown instance
        UM->>UM: DEV → warn lifecycle_double_unmount
        UM-->>U: Promise.resolve()
    end
```

The teardown closure created in `_mount` additionally removes every delegated listener from the target, ref-count-decrements the shared document listeners, unregisters the `root_event_handles` entry, and removes the synthetic anchor text node.

### 5.4 Reactive text update (`set_text`)

```mermaid
flowchart LR
    S["signal / state change"] --> E["generated text effect re-runs"]
    E --> V{"value null/undefined?"}
    V -->|"yes"| N["str = ''"]
    V -->|"no"| O{"object?"}
    O -->|"yes"| C["str = value + ''<br/>(coercion may read $state → tracked)"]
    O -->|"no"| P["str = value"]
    N --> D{"str !== text.__t<br/>(__t ??= nodeValue)"}
    C --> D
    P --> D
    D -->|"changed"| W["text.__t = str<br/>text.nodeValue = str"]
    D -->|"unchanged"| SKIP["no DOM write"]
```

---

## 6. Dependencies

### 6.1 Upstream (what this module consumes)

| Import | From submodule | Used for |
| --- | --- | --- |
| `init_operations`, `get_first_child`, `get_next_sibling`, `create_text`, `clear_text_content` | [client_dom_renderer_dom_foundation](client_dom_renderer_dom_foundation.md) (operations.js) | DOM fast paths, anchor scanning, recovery wipe |
| `hydrating`, `hydrate_node`, `set_hydrating`, `set_hydrate_node`, `hydrate_next` | [client_dom_renderer_dom_foundation](client_dom_renderer_dom_foundation.md) (hydration.js) | hydration cursor control |
| `assign_nodes` | [client_dom_renderer_dom_foundation](client_dom_renderer_dom_foundation.md) (template.js) | record claimed-node span on the root effect |
| `component_root`, `branch` | [client_runtime_core](client_runtime_core.md) (effects.js) | root effect creation, teardown/pause-outro semantics |
| `active_effect` | [client_runtime_core](client_runtime_core.md) (runtime.js) | write `nodes_end` after hydration |
| `push`, `pop`, `component_context` | [context_api](context_api.md) | caller-supplied context Map injection |
| `all_registered_events`, `handle_event_propagation`, `root_event_handles` | [client_dom_renderer_elements_and_events](client_dom_renderer_elements_and_events.md) | delegated event wiring |
| `reset_head_anchor` | [client_dom_renderer_control_flow_blocks](client_dom_renderer_control_flow_blocks.md) | `svelte:head` anchor cleanup per mount |
| `w.*`, `e.*` | [client_runtime_core_diagnostics](client_runtime_core_diagnostics.md) | `hydration_mismatch`, `lifecycle_double_unmount`, `hydration_failed` |
| `HYDRATION_START`, `HYDRATION_END`, `HYDRATION_ERROR`, `COMMENT_NODE` | shared constants | anchor markers (`<!--→` … `<!--←`) |
| `is_passive_event` | shared utils | `{ passive }` listener hints |
| `array_from` | [shared_runtime](shared_runtime.md) | copy event-name set |
| `DEV` | `esm-env` | dev-only double-unmount warning |

### 6.2 Downstream (what consumes this module)

* **Public entries** ([Public_API_Surface___Compatibility_Layer](Public_API_Surface___Compatibility_Layer.md)): `index-server.js` and `index-client.js` re-export `mount`, `hydrate`, `unmount` — this is what application code imports from `'svelte'`.
* **Compiler client transform** ([compiler_client_transform](compiler_client_transform.md)): the generated `Component(anchor, props)` function invoked by `_mount` is the product of this transform; its template/fragment builders call `set_text` from text effects and read `should_intro` when deciding whether to play intro transitions.
* **Dev/HMR tooling** ([client_dev_mode](client_dev_mode.md)): the `hmr` wrapper re-mounts components through this module and re-registers event handles via `root_event_handles`.
* **Custom elements** ([client_dom_renderer_elements_and_events](client_dom_renderer_elements_and_events.md)): `create_custom_element` mounts component instances and drives the same `mounted_components` teardown path.
* **Server counterpart**: hydration consumes markup produced by [server_runtime](server_runtime.md), whose SSR payload emits the `HYDRATION_START`/`HYDRATION_END` comment anchors this module scans for.

---

## 7. Design Notes & Invariants

1. **Synchronous first render.** `component_root`'s render function runs synchronously, so `mount`/`hydrate` return fully usable exports and the DOM is committed before the call returns. Async work (effects, transitions) is scheduled by the runtime engine afterwards.
2. **Hydration is a mode, not a separate renderer.** `hydrate` merely flips the shared hydration cursor and reuses `_mount` verbatim; all node-claiming behaviour lives in the DOM foundation primitives that consult `hydrating`. This keeps CSR and SSR-adoption on one code path.
3. **Graceful degradation.** Any hydration mismatch or unexpected error collapses into a clean client-side re-render (`clear_text_content(target)` + `mount`), unless the app opts out with `recover: false`. Svelte's own errors (`svelte.dev/e/…`) are always surfaced, never swallowed.
4. **Listener ref-counting.** Document-level delegated listeners are shared across all mounted roots via `document_listeners`; teardown only removes a document listener when its refcount hits zero, so nested/multiple apps do not fight over them.
5. **No leaks.** `mounted_components` is a `WeakMap`, and `unmount` deletes its entry before running teardown — double unmount is a safe no-op (with a dev-time warning).
6. **Cheap updates.** `set_text` is intentionally branch-light and allocation-free: one string coercion, one cached comparison, one DOM write only when needed.
7. **`should_intro` is a one-shot flag.** It is only `false` during (a) hydration without `intro: true` and (b) `<svelte:element>` tag swaps; `_mount` restores `true` immediately after the component function returns, so it never leaks into later renders.

---

## 8. Related Documentation

* [client_dom_renderer](client_dom_renderer.md) — parent module: overall client DOM renderer architecture.
* [client_dom_renderer_dom_foundation](client_dom_renderer_dom_foundation.md) — DOM operations, template cloning, hydration cursor.
* [client_dom_renderer_control_flow_blocks](client_dom_renderer_control_flow_blocks.md) — if/each/key/await/snippet/slot blocks created inside the branch effect.
* [client_dom_renderer_elements_and_events](client_dom_renderer_elements_and_events.md) — attributes, event delegation, transitions, custom elements.
* [client_runtime_core](client_runtime_core.md) — signals, effects, batching powering the lifecycle.
* [client_runtime_core_diagnostics](client_runtime_core_diagnostics.md) — client errors/warnings referenced above.
* [server_runtime](server_runtime.md) — SSR renderer that produces the markup `hydrate` adopts.
* [compiler_client_transform](compiler_client_transform.md) — transform that generates the component functions `_mount` invokes.
* [Public_API_Surface___Compatibility_Layer](Public_API_Surface___Compatibility_Layer.md) — public entry points re-exporting this module.
* [client_dev_mode](client_dev_mode.md) — HMR wrapper and dev-only instrumentation around the lifecycle.
