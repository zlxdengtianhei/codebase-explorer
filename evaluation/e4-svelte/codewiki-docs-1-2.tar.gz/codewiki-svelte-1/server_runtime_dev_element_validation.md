# Server Runtime Dev Element Validation

## Introduction

The `server_runtime_dev_element_validation` module (`packages/svelte/src/internal/server/dev.js`) implements **development-mode-only correctness checks for server-side rendered (SSR) HTML output**. It guards against structurally invalid HTML — element placements that a browser will silently "repair" during parsing (e.g. `<div>` inside `<p>`, `<tr>` outside a table context) — which would otherwise cause content to shift between SSR output and client hydration, producing confusing `hydration_mismatch` behavior.

It provides three exported functions, all of which are **only emitted into generated code when the compiler runs in `dev` mode**:

| Export | Responsibility |
| --- | --- |
| `push_element(payload, tag, line, column)` | Pushes a rendered element onto a module-scoped element stack and validates it against its parent **and all ancestors** using the HTML tree rules from `html-tree-validation.js`. Violations are reported as `node_invalid_placement_ssr` errors. |
| `pop_element()` | Pops the element stack when an element's children have finished rendering. |
| `validate_snippet_args(payload)` | Validates, at the top of every compiled snippet function, that the snippet was invoked with a proper `Payload`/`HeadPayload` as its first argument; throws `invalid_snippet_arguments` otherwise. |

Two internal helpers complete the module: `reset_elements()` (stack save/restore used by `render()`) and `print_error()` (message formatting, de-duplication, and dual console/head-script reporting).

This module sits inside the [server_runtime](server_runtime.md) layer, alongside the [server_runtime_rendering_core](server_runtime_rendering_core.md) primitives and the [server_runtime_payload_model](server_runtime_payload_model.md). The client-side mirror of this machinery (location tracking via `add_locations`, ownership validation, snippet argument validation) is documented in [client_dev_mode_validation](client_dev_mode_validation.md) and [client_dev_mode_locations](client_dev_mode_locations.md).

---

## Architecture

### Position in the system

The module is inert library code that becomes active through **compiler-generated calls**. The server transform ([compiler_server_transform](compiler_server_transform.md)) injects `$.push_element` / `$.pop_element` around every element's children and `$.validate_snippet_args` at the head of every snippet function — but only when the `dev` compile flag is set. At render time, the stack maintained here feeds back into developer-facing diagnostics through both the **server console** and a **script injected into the SSR `<head>`**.

```mermaid
flowchart TB
    subgraph Compiler["Compiler Back-End — compiler_server_transform (dev builds only)"]
        RE["RegularElement visitor<br/>(static elements)"]
        SE["SvelteElement visitor<br/>svelte:element (dynamic tag)"]
        SB["SnippetBlock visitor"]
    end

    subgraph Module["server_runtime_dev_element_validation — internal/server/dev.js"]
        PUSH["push_element"]
        POP["pop_element"]
        VSA["validate_snippet_args"]
        RESET["reset_elements"]
        PERR["print_error (internal)"]
        STATE[("module state:<br/>parent stack + seen set")]
    end

    subgraph Core["server_runtime_rendering_core"]
        RENDER["render()"]
        ELEM["element()"]
    end

    subgraph PayloadModel["server_runtime_payload_model"]
        P["Payload"]
        HP["HeadPayload"]
    end

    HTV["html-tree-validation.js<br/>is_tag_valid_with_parent / _with_ancestor"]
    CTX["server context.js — current_component"]
    CONST["constants.js — FILENAME symbol"]
    ERRS["server errors.js — invalid_snippet_arguments"]

    RE -- "dev: $.push_element / $.pop_element" --> PUSH
    SE -- "dev: $.push_element(dynamic tag) / $.pop_element" --> PUSH
    SB -- "dev: $.validate_snippet_args($$payload)" --> VSA
    RENDER -- "dev: guards nested renders" --> RESET
    ELEM -. "produces the HTML that the<br/>stack mirrors" .-> Module

    PUSH --> STATE
    POP --> STATE
    PUSH --> PERR
    PUSH -- "rule checks" --> HTV
    PUSH -- "filename lookup" --> CTX
    CTX -- "component.function[FILENAME]" --> CONST
    PERR -- "inject console.error script" --> HP
    VSA -- "instanceof checks" --> P
    VSA -- "instanceof checks" --> HP
    VSA -- "throws on bad $$payload" --> ERRS
```

### Runtime state model

All validation state is **module-scoped** (a singleton per server process), kept deliberately simple because SSR rendering is synchronous:

```mermaid
flowchart LR
    subgraph Record["Element record (typedef)"]
        F["tag: string<br/>parent: null | Element<br/>filename: null | string<br/>line: number<br/>column: number"]
    end

    N["null (stack root)"] --> T["&lt;table&gt; @ App.svelte:4:1"]
    T --> B["&lt;tbody&gt; @ App.svelte:5:2"]
    B --> D["&lt;div&gt; @ App.svelte:6:3"]

    D -- "push_element(payload, 'td', 7, 4)" --> V["validate against parent + ancestors"]
    V -- "tbody only allows tr" --> M(("node_invalid_placement_ssr"))
```

* `parent` — the top of a **linked-list stack** of `Element` records. Each record points at its parent, so `push_element`/`pop_element` form the only mutation interface, and ancestor traversal (`parent.parent → …`) needs no auxiliary collection.
* `seen` — a lazily initialized `Set<string>` (`seen ??= new Set()`) of already-reported messages, preventing duplicate diagnostics for repeated violations (e.g. inside an `{#each}` loop) from flooding the console or the emitted `<head>`.

> **Invariant:** `push_element` and `pop_element` calls are always emitted in balanced pairs by the compiler (for every non-fragment element, including void elements, so the closing-literal emission stays orthogonal). `pop_element` dereferences `parent.parent` without a null check, relying on this invariant. Unbalanced usage is a compiler bug, not a user-facing failure mode.

---

## Core Components

### `push_element(payload, tag, line, column)`

Called (via `$.push_element`) immediately **before an element's children are rendered**. It records the element and validates its placement in a single pass:

```mermaid
flowchart TD
    A["push_element(payload, tag, line, column)"] --> B["filename = current_component.function[FILENAME]"]
    B --> C["child = { tag, parent, filename, line, column }"]
    C --> D{"parent !== null ?"}
    D -- "no (root element)" --> H["parent = child"]
    D -- "yes" --> E["build location strings:<br/>file.svelte:line:column when known"]
    E --> F["is_tag_valid_with_parent(tag, parent.tag, ...)"]
    F --> G{"message returned?"}
    G -- "yes" --> PE["print_error(payload, message)"]
    G -- "no" --> I
    PE --> I["walk ancestor chain via parent.parent"]
    I --> J{"more ancestors?"}
    J -- "yes" --> K["is_tag_valid_with_ancestor(tag, ancestors, ...)"]
    K --> L{"message returned?"}
    L -- "yes" --> PE
    L -- "no" --> J
    J -- "no" --> H
    H --> Z(["stack top = child; children render next"])
```

Key behaviors:

* **Source attribution.** The `filename` is read from `current_component.function[FILENAME]` — a `Symbol('filename')` property that the server `push()` context helper attaches to the component record in dev mode (see [compiler_core_state](compiler_core_state.md) for how `FILENAME` flows from compile options). Each violation message embeds `file:line:column` strings for both the offending child and the invalid ancestor/parent when available, so the error points at real source locations even though validation runs at render time.
* **Two tiers of checks.**
  * *Direct-parent check* — `is_tag_valid_with_parent` covers rules keyed to the immediate parent (`direct` bans like `<li>` in `<li>`, `descendant` bans that also apply at depth one, and `only` whitelists like `<select>` allowing only `option`/`optgroup`/`#text`/`hr`/`script`/`template`). It also enforces, via a fallback `switch`, that structurally special tags (`body`, `caption`, `col`, `head`, `html`, `tr`, `td`, …) only appear under their legal parents.
  * *Ancestor check* — `is_tag_valid_with_ancestor` walks grandparent-and-above with an accumulating `ancestors` array, enforcing `descendant` bans such as `<a>` in `<a>`, `<form>` in `<form>`, headings in headings, and flow content inside `<p>`. The `reset_by` mechanism lifts a ban when an intervening ancestor re-establishes a legal context (e.g. a nested `<dl>` resets the `dt`/`dd` constraint).
* **Exemptions.** Custom elements (tag names containing `-`) are exempt from all checks — their content model is unknown. Children of `<template>` are exempt from parent checks because template content is inert.

### `pop_element()`

Called (via `$.pop_element`) **after an element's children and closing tag have been emitted**. It simply restores the enclosing element: `parent = parent.parent`. For static elements (`RegularElement`), the compiler emits the pop after the `</tag>` literal is pushed; for void elements the pair is still balanced even though no closing literal exists. For `svelte:element`, the pop is emitted around the `$.element(...)` invocation, so dynamic tags are validated with the same mechanism (the tag expression is passed to `push_element` in place of a literal).

### `validate_snippet_args(payload)`

Snippets compile to plain functions whose **first parameter is `$$payload`**. The `SnippetBlock` server visitor unshifts a `$.validate_snippet_args($$payload)` statement at the top of every snippet body in dev builds. The check throws the generated `invalid_snippet_arguments` *Svelte error* (see [compiler_diagnostics_errors](compiler_diagnostics_errors.md) for the error model and [Repository_Engineering_Infrastructure](repository_engineering_infrastructure.md) for the message-generation tooling) when the first argument is not an object or is not an instance of `Payload`/`HeadPayload` (both from [server_runtime_payload_model](server_runtime_payload_model.md)).

This converts a class of silent misuses — calling `{@render …}` with a missing or wrong argument, or invoking a snippet from non-Svelte code with an invalid context — into an immediate, clearly-attributed failure instead of an opaque crash later in the output-buffer machinery. Note the implementation detail: after the first `instanceof` check TypeScript narrows `payload` to `never`, hence the explicit `/** @type {any} */` cast on the second check.

### `reset_elements()` (internal, exported for `render()`)

Because `parent` is module-global state, a nested `render()` call (e.g. rendering a component while another render is in flight, or a broken component that throws mid-render) could otherwise corrupt or leak the element stack across renders. `reset_elements()` snapshots the current `parent`, resets it to `null`, and returns a closure that restores the snapshot. The `render()` entry point in [server_runtime_rendering_core](server_runtime_rendering_core.md) invokes it in dev mode with the explicit comment: *"prevent parent/child element state being corrupted by a bad render"*, and calls the restore closure after the component finishes.

### `print_error(payload, message)` (internal)

```mermaid
flowchart TD
    A["print_error(payload, raw message)"] --> B["compose final message:<br/>node_invalid_placement_ssr: raw message<br/>+ note about browser HTML repair<br/>+ likely hydration_mismatch warning"]
    B --> C{"seen.has(message) ?"}
    C -- "yes (duplicate)" --> Z["return — suppress"]
    C -- "no" --> D["seen.add(message)"]
    D --> E["console.error(message)<br/>on the server"]
    D --> F["payload.head.out.push<br/>script: console.error(JSON.stringify(message))"]
    F --> G["script ships in the head of the SSR response —<br/>error also surfaces in the browser console"]
```

The dual-channel reporting is the module's signature behavior: the developer sees the violation **both where the HTML was produced (server log)** and **where its consequences manifest (browser console)**. Because the browser will repair invalid HTML before hydration runs, pointing at the hydration-time symptom alone would be nearly undebuggable — the injected `<script>` bridges that gap. The `seen` set de-duplicates identical messages across the process lifetime, so an `{#each}` producing 500 identical violations logs once per channel.

---

## End-to-End Process Flow

The sequence below traces a dev-mode SSR render of a component containing `<table><tbody><div>…</div></tbody></table>` and a snippet:

```mermaid
sequenceDiagram
    autonumber
    participant App as Application
    participant Render as render() — server_runtime_rendering_core
    participant Comp as compiled component (dev build)
    participant Stack as dev.js — element stack
    participant Rules as html-tree-validation
    participant Pay as Payload / HeadPayload

    App->>Render: render(Component, options)
    Render->>Stack: reset_elements() — snapshot + clear (DEV)
    Render->>Comp: component(payload, props, ...)

    Note over Comp,Pay: snippet definition first validates its context
    Comp->>Stack: $.validate_snippet_args($$payload)
    Stack->>Pay: instanceof Payload / HeadPayload?
    Note over Stack: on mismatch → throw invalid_snippet_arguments

    Comp->>Stack: $.push_element(payload, 'table', 4, 1)
    Stack->>Stack: record Element (filename from FILENAME)
    Note over Stack: parent === null → no checks
    Comp->>Stack: $.push_element(payload, 'tbody', 5, 2)
    Stack->>Rules: is_tag_valid_with_parent('tbody', 'table', ...)
    Rules-->>Stack: null (allowed)
    Comp->>Stack: $.push_element(payload, 'div', 6, 3)
    Stack->>Rules: is_tag_valid_with_parent('div', 'tbody', ...)
    Rules-->>Stack: message (only tr allowed)
    Stack->>Pay: print_error → head.out.push(script console.error)
    Stack->>Rules: is_tag_valid_with_ancestor('div', [..., 'table'], ...)
    Rules-->>Stack: null
    Note over Stack: children of div render (recursive push/pop)
    Comp->>Stack: $.pop_element() ×3 (unwinding div, tbody, table)

    Comp-->>Render: done
    Render->>Stack: restore snapshot from reset_elements()
    Render-->>App: { html, head, body } — head carries the console.error script
```

---

## Validation Rules Reference (condensed)

The rule tables live in `packages/svelte/src/html-tree-validation.js`, shared with the compiler's template analysis. `push_element` consumes them at runtime; the categories relevant to this module are:

| Category | Meaning | Examples |
| --- | --- | --- |
| `direct` | Child is banned as an *immediate* child | `<li>` in `<li>`; `tbody`/`tfoot` in `thead`; `td`/`th`/`tr` in `td` |
| `descendant` | Child is banned *anywhere below* the ancestor | block content in `<p>`; `<a>` in `<a>`; `<form>` in `<form>`; `h1–h6` in headings |
| `only` | Whitelist of permitted children | `<select>`, `<tr>`, `<tbody>`, `<table>`, `<head>`, `<html>`, `<colgroup>` |
| `reset_by` | A `descendant` ban is lifted when an intermediate ancestor matches | `dt`/`dd` bans reset by a nested `<dl>` |

Exemptions applied inside the rule functions: tags containing `-` (custom elements) pass all checks; `<template>` parents suppress parent-child checks.

---

## Edge Cases and Design Notes

* **Balanced stack, unchecked pop.** The compiler guarantees `push_element`/`pop_element` pairing per element node; `pop_element` trusts it (non-null assertion). This keeps the runtime hot path allocation-free apart from the record object.
* **Per-process deduplication.** `seen` is *not* reset by `reset_elements()` — repeated identical violations across multiple `render()` calls in one process report only once per channel. Distinct messages (different tags/locations) each report once.
* **Global state vs. concurrency.** The stack assumes synchronous, single-threaded rendering per module instance. Nesting is the only supported form of reentrancy and is neutralized by `reset_elements()` inside `render()`.
* **Void elements.** `push_element`/`pop_element` are emitted for void elements too, keeping the stack balanced; the closing-tag literal emission (`if (!node_is_void)`) is independent.
* **Dynamic tags.** `svelte:element` passes its (possibly dynamic) tag expression to `push_element`; dev builds also pre-hoist the tag into a temporary so it is evaluated once, and run the shared validators `validate_dynamic_element_tag` / `validate_void_dynamic_element` from the [shared_runtime](shared_runtime.md) layer.
* **Sibling auto-closing** (`closing_tag_omitted`, e.g. a second `<li>` auto-closing the first) is handled by the shared rules file for other consumers and is *not* a runtime error path in this module — only placements the browser must *repair* are reported.

---

## Related Documentation

* [server_runtime](server_runtime.md) — parent module; SSR runtime overview.
* [server_runtime_rendering_core](server_runtime_rendering_core.md) — `render()`, `element()` primitives; where `reset_elements()` is wired and where `payload.head.out` becomes the response `<head>`.
* [server_runtime_payload_model](server_runtime_payload_model.md) — `Payload`/`HeadPayload` output buffers checked by `validate_snippet_args` and written by `print_error`.
* [server_runtime_dev_validation](server_runtime_dev_validation.md) — sibling grouping of SSR dev-time validation.
* [compiler_server_transform](compiler_server_transform.md) — the visitors (`RegularElement`, `SvelteElement`, `SnippetBlock`) that emit the dev-mode calls.
* [client_dev_mode_validation](client_dev_mode_validation.md) — client-side counterpart (`validate_snippet_args`, ownership validator, dev equality checks).
* [client_dev_mode_locations](client_dev_mode_locations.md) — client-side element location tracking (`add_locations`), the hydration-side mirror of the location data captured here.
* [shared_runtime](shared_runtime.md) — shared validators used alongside this module for `svelte:element` checks.
* [compiler_diagnostics_errors](compiler_diagnostics_errors.md) — the diagnostic/error model that `invalid_snippet_arguments` follows.
