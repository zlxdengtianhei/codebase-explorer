# Attachment Runtime (`svelte/attachments`)

> **Module:** `actions_and_attachments_attachment_runtime`
> **Source:** `packages/svelte/src/attachments/index.js`
> **Public entry:** `svelte/attachments`

---

## 1. Introduction

This module implements the **public runtime for Svelte attachments** — the imperative counterpart to the `{@attach ...}` template syntax. It exposes exactly two functions:

| Export | Since | Purpose |
| --- | --- | --- |
| `createAttachmentKey()` | 5.29 | Creates a symbol key that is recognised as an attachment when an object is spread onto an element (`{...props}`). Programmatic alternative to `{@attach ...}`, aimed at library authors. |
| `fromAction(action, fn)` | 5.32 | Converts a legacy [action](actions_and_attachments_action_contract.md) (`use:` directive) into an attachment, preserving its `update`/`destroy` semantics. Migration bridge for libraries that ship actions. |

Attachments are a generalisation of actions: a function that receives an element, optionally returns a cleanup function, and — unlike actions — can be re-invoked when its expression changes and can be attached programmatically through object spread. While the **compiler** side of `{@attach}` is handled by the client transform (see [compiler_client_transform_elements_and_directives](compiler_client_transform_elements_and_directives.md)), this module provides the *runtime* building blocks that developers and library authors use directly.

The module is intentionally tiny and tree-shakeable: it depends only on a handful of client-runtime primitives (`render_effect`, `teardown`, `branch` consumers, `untrack`, `noop`) and one shared constant.

---

## 2. Core Concepts

### 2.1 The `Attachment` contract

Defined in `packages/svelte/src/attachments/public.d.ts`:

```ts
interface Attachment<T extends EventTarget = Element> {
	(element: T): void | (() => void);
}
```

An attachment is a function that:

1. Receives the **element** it is attached to.
2. Optionally returns a **cleanup function**, which is invoked when the attachment is destroyed (element unmounted, or the attachment replaced).

Compare this with the [`Action` contract](actions_and_attachments_action_contract.md), which receives `(node, parameter)` and returns `void | ActionReturn<Parameter>` where `ActionReturn` may contain `update(param)` and `destroy()` callbacks.

### 2.2 The attachment-key protocol

The bridge between user code and the client runtime is a **symbol protocol**:

- `packages/svelte/src/constants.js` declares `ATTACHMENT_KEY = '@attach'`.
- `createAttachmentKey()` returns `Symbol(ATTACHMENT_KEY)` — i.e. a symbol whose `.description === '@attach'`.
- When props are applied to an element (attribute effects and spreads), the runtime scans `Object.getOwnPropertySymbols(props)` and treats **any symbol whose description matches `ATTACHMENT_KEY`** as an attachment whose value is an `Attachment` function.

This is why a plain object literal can carry attachments:

```svelte
<script>
	import { createAttachmentKey } from 'svelte/attachments';

	const props = {
		class: 'cool',
		onclick: () => alert('clicked'),
		[createAttachmentKey()]: (node) => {
			node.textContent = 'attached!';
		}
	};
</script>

<button {...props}>click me</button>
```

---

## 3. API Reference

### 3.1 `createAttachmentKey()`

```js
function createAttachmentKey(): symbol;
```

Returns a fresh `Symbol(ATTACHMENT_KEY)`. Each call yields a *distinct* symbol, but because the runtime matches on the symbol **description** (`'@attach'`), any key produced by this function is recognised wherever props are spread onto an element.

**Typical usage** — library authors forwarding attachments through a component:

```svelte
<script>
	import { createAttachmentKey } from 'svelte/attachments';
	let { children, attachment } = $props();
</script>

<div {[createAttachmentKey()]: attachment}>
	{@render children?.()}
</div>
```

### 3.2 `fromAction(action, fn?)`

```ts
// Overload 1 — with parameter
function fromAction<E extends EventTarget, T>(
	action: Action<E, T> | ((element: E, arg: T) => void | ActionReturn<T>),
	fn: () => T
): Attachment<E>;

// Overload 2 — without parameter
function fromAction<E extends EventTarget>(
	action: Action<E, void> | ((element: E) => void | ActionReturn<void>)
): Attachment<E>;
```

Wraps an [action](actions_and_attachments_action_contract.md) so it can be used where attachments are expected:

```svelte
<!-- with an action -->
<div use:foo={bar}>...</div>

<!-- equivalent attachment -->
<div {@attach fromAction(foo, () => bar)}>...</div>
```

**Critical nuance:** the second argument `fn` must be a **getter function that returns** the action's argument — *not* the argument itself. Indirection through the thunk is what makes the parameter **reactive**: the wrapper reads it inside a `render_effect`, so changes to `bar` trigger `update(newBar)` on the action.

| Argument | Type | Semantics |
| --- | --- | --- |
| `action` | `Action \| fn` | The action to adapt. Called once with `(element, fn())`. Its optional `update` / `destroy` return members are honoured. |
| `fn` | `() => T` | Getter producing the action's parameter. Defaults to `noop` (parameter-less actions). **Must be a function returning the argument.** |

---

## 4. Architecture & Dependencies

`fromAction` is a thin adapter over the effects system, and `createAttachmentKey` is a one-liner over a shared constant. The heavy lifting happens in the client runtime, which this module orchestrates:

```mermaid
flowchart TB
    subgraph MOD["This module — src/attachments/index.js"]
        CAK["createAttachmentKey()"]
        FA["fromAction(action, fn)"]
    end

    subgraph TYPES["Type contracts"]
        ATT["Attachment&lt;T&gt;<br/>attachments/public.d.ts"]
        ACT["Action / ActionReturn<br/>action/public.d.ts"]
    end

    subgraph RUNTIME["Client runtime"]
        RE["render_effect / teardown<br/>reactivity/effects.js"]
        UT["untrack()<br/>internal/client/runtime.js"]
        AF["attach(node, get_fn)<br/>dom/elements/attachments.js"]
        AE["attribute_effect()<br/>dom/elements/attributes.js"]
    end

    CONST["ATTACHMENT_KEY = '@attach'<br/>src/constants.js"]
    NOOP["noop()<br/>internal/shared/utils.js"]
    USER["User action / attachment functions"]

    CAK --> CONST
    FA --> NOOP
    FA --> UT
    FA --> RE
    FA --> ACT
    ATT -. return type .-> FA
    ACT -. input type .-> FA
    ATT -. implemented by .-> USER
    FA -. produces .-> USER
    AE --> CONST
    AE --> AF
    AF --> RE
    AE -. consumes symbol keys from spread .-> CAK
    AF -. runs {@attach} expressions .-> USER
```

**Dependency summary**

| This module uses… | From | Why |
| --- | --- | --- |
| `render_effect` | `svelte/internal/client` → `reactivity/effects.js` | Reactive re-invocation of the action's `update` when the parameter getter changes. |
| `teardown` | `internal/client/reactivity/effects.js` | Registers the action's `destroy` callback on a dedicated clean effect so it fires on attachment teardown. |
| `untrack` | `index-client.js` (re-exported from `internal/client/runtime.js`) | Runs the initial action call *outside* dependency tracking, so the action body itself never creates reactive dependencies. |
| `noop` | `internal/shared/utils.js` | Default parameter getter for parameter-less actions. |
| `ATTACHMENT_KEY` | `src/constants.js` | Symbol description used by the attachment-key protocol. |

The reverse direction matters too: the runtime is a **consumer** of this module's protocol:

- The compiler's `AttachTag` visitor compiles `{@attach fn}` into `$.attach(node, () => fn)` → `attach()` in `dom/elements/attachments.js`.
- `attribute_effect()` in `dom/elements/attributes.js` interprets `createAttachmentKey()` symbols during attribute/spread application (see §6).

---

## 5. `fromAction` — Behaviour Deep Dive

### 5.1 Execution flow

```mermaid
flowchart TD
    S["Attachment invoked: wrapper(element)"] --> U["untrack:<br/>const { update, destroy } =<br/>action(element, fn()) ?? {}"]
    U --> Q{"Action returned…"}
    Q -->|update| UP["render_effect:<br/>arg = fn()<br/>if ran → update(arg)<br/>(first run skipped)"]
    Q -->|destroy| DE["teardown(destroy)<br/>clean effect, teardown = destroy"]
    Q -->|nothing| IDLE["No further wiring"]
    UP --> L["Element / effect-branch lifecycle"]
    DE --> L
    IDLE --> L
    L -->|"fn()'s deps change"| X["update(newArg)"]
    L -->|"branch destroyed"| Y["destroy() via effect teardown"]
```

### 5.2 Step-by-step semantics

```js
export function fromAction(action, fn = noop) {
	return (element) => {
		const { update, destroy } = untrack(() => action(element, fn()) ?? {});

		if (update) {
			var ran = false;
			render_effect(() => {
				const arg = fn();
				if (ran) update(arg);
			});
			ran = true;
		}

		if (destroy) {
			teardown(destroy);
		}
	};
}
```

1. **Initial call (`untrack`).** The action is invoked immediately with the element and the initial parameter. `untrack` guarantees that neither the action body nor the parameter read introduces reactive dependencies — an action's setup should run once, not re-run. The `?? {}` fallback makes destructuring safe for actions that return `undefined`.

2. **Parameter reactivity (`render_effect` + `ran` flag).** Render effects execute their body **synchronously on creation**. If `update` were called unconditionally, the parameter would be delivered twice for the initial value (once via `action(element, fn())`, once via the effect). The `ran` flag suppresses that first synchronous pass; only *subsequent* re-runs — caused by changes to `fn()`'s reactive dependencies — invoke `update(newArg)`. This exactly reproduces `use:action={param}` semantics, where `update` fires only on parameter *changes*.

3. **Cleanup (`teardown(destroy)`).** `teardown()` creates an effect in the `CLEAN` state whose only job is to run `destroy` when the effect graph tears down the attachment's branch — i.e. when the element is unmounted, the attachment is replaced by a different function, or an enclosing control-flow block (e.g. an `{#if}` branch) is destroyed.

### 5.3 Lifecycle guarantee matrix

| Event | Action callback invoked | Mechanism |
| --- | --- | --- |
| Attachment applied to element | `action(element, fn())` | Direct call, untracked |
| Reactive parameter change | `update(newArg)` | `render_effect` re-run (initial run suppressed by `ran`) |
| Element unmounted / branch destroyed | `destroy()` | `teardown` on the effect branch |
| Attachment function identity replaced | `destroy()` of old, fresh `action(...)` for new | `attach()` destroys the old branch before running the new one |
| Action returns nothing (`void`) | — | Destructuring guarded by `?? {}`; no effects created |

---

## 6. How the Runtime Consumes Attachments

This module only *creates* attachments; two client-runtime sites *execute* them. Understanding them clarifies the guarantees above.

### 6.1 `{@attach fn}` — the compiler path

The client transform's `AttachTag` visitor emits:

```js
$.attach(node, () => fn);
```

`attach(node, get_fn)` (in `dom/elements/attachments.js`) runs inside a `block` effect: whenever `get_fn()` yields a **different function identity**, the previous branch effect is destroyed (running its cleanups) and a new branch runs `fn(node)` inside an effect. Consequences:

- Attachments re-run when the `{@attach}` expression produces a new function (e.g. inside an `{#each}`, or recreated inline).
- Re-running a *stable* function reference does nothing — identity is compared, not results.
- Cleanups returned by previous invocations always run before the next invocation.

### 6.2 `{...props}` — the attachment-key path

`attribute_effect()` (in `dom/elements/attributes.js`) applies attribute objects, including spreads. For each **own symbol** of the next props whose `description === ATTACHMENT_KEY`, it:

1. Destroys the previously installed effect for that symbol (if the value changed or the key disappeared), and
2. Installs `branch(() => attach(element, () => value))` — a dedicated branch so each attachment has its own reactive scope and lifecycle.

```mermaid
sequenceDiagram
    autonumber
    participant U as User code
    participant CAK as createAttachmentKey
    participant AE as attribute_effect
    participant AT as attach()
    participant A as Attachment fn

    U->>CAK: Symbol('@attach')
    CAK-->>U: key
    U->>AE: {...props} applied to element
    AE->>AE: own symbols where description === '@attach'
    AE->>AT: branch(() => attach(el, () => fn))
    AT->>A: effect(() => fn(node))
    A-->>AT: cleanup? (kept as effect teardown)
    Note over AT,A: fn identity changes → old branch destroyed<br/>(cleanup runs) → new branch runs
```

This is the mechanism that makes `createAttachmentKey()` work — and what `fromAction` adapters plug into when forwarded via spreads.

### 6.3 Server-side rendering

Attachments are a **client-only** concept. The module imports exclusively from `svelte/internal/client`, and the compiler defines an `AttachTag` visitor only for the *client* transform — the [server transform](compiler_server_transform_elements.md) has no attachment visitor, so `{@attach}` produces no SSR output and attachment functions never execute during server rendering.

---

## 7. Module Interaction Map

```mermaid
flowchart LR
    subgraph COMPILER["Compiler Back-End"]
        AT["AttachTag visitor<br/>(client transform)"]
    end
    subgraph PUB["Public API surface"]
        M["svelte/attachments<br/>(this module)"]
        AC["svelte/action<br/>(Action contract)"]
    end
    subgraph CLIENT["Client runtime"]
        EFF["Effects: render_effect,<br/>branch, teardown"]
        RT["untrack / signal runtime"]
        ATTACH["attach()"]
        AEFF["attribute_effect()"]
    end
    USER["Application / library code"]

    USER -->|"import"| M
    USER -->|"type-only"| AC
    M --> EFF
    M --> RT
    AT --> ATTACH
    AEFF --> ATTACH
    ATTACH --> EFF
    EFF --> RT
    M -. "attachment-key protocol" .-> AEFF
```

- Upstream: [compiler_client_transform_elements_and_directives](compiler_client_transform_elements_and_directives.md) (emits `$.attach` calls), [actions_and_attachments_action_contract](actions_and_attachments_action_contract.md) (the `Action`/`ActionReturn` types being adapted).
- Downstream: [client_dom_renderer_elements_and_events](client_dom_renderer_elements_and_events.md) (`attribute_effect`, spread application), [client_runtime_core_effects](client_runtime_core_effects.md) (`render_effect`, `teardown`, `branch`), [client_runtime_core_runtime](client_runtime_core_runtime.md) (`untrack`), [shared_runtime_utilities](shared_runtime_utilities.md) (`noop`).
- Types are re-exported through the aggregate type surface in [svelte_types](svelte_types.md).

---

## 8. Design Notes & Edge Cases

- **Identity-based re-running.** Both execution paths (`attach` and the per-symbol branches in `attribute_effect`) compare the attachment **function identity**, not any return value. Memoise attachments (e.g. store them in `$derived`) if the expression would otherwise recreate the function each update.
- **Getter, not value.** `fromAction(foo, bar)` is a footgun: `bar` would be read *once*, untracked. Always pass `fromAction(foo, () => bar)`. The JSDoc overloads encode this in TypeScript.
- **One key per attachment.** Use a distinct `createAttachmentKey()` per attachment you intend to install on the same object; multiple entries under the same symbol would overwrite each other.
- **Cleanup ordering.** Attachments returned cleanups run when their branch is destroyed — before the element is removed from the DOM effects graph, and before any enclosing block teardown completes, matching effect teardown ordering.
- **Tree-shakeability.** `fromAction` pulls in the effects machinery, while `createAttachmentKey` is effectively free (a `Symbol` construction); unused exports are eliminated by the [treeshakeability checks](svelte_build_tooling.md).
- **Version gating.** `createAttachmentKey` requires Svelte ≥ 5.29 and `fromAction` ≥ 5.32; both are additive, non-breaking exports of the `svelte/attachments` entry within the [public API surface](public_api.md).

---

## 9. Source Reference

| Component | Location | Role |
| --- | --- | --- |
| `createAttachmentKey` | `packages/svelte/src/attachments/index.js` | Returns `Symbol(ATTACHMENT_KEY)` for programmatic attachments |
| `fromAction` | `packages/svelte/src/attachments/index.js` | Adapts an `Action` into an `Attachment` with reactive `update` and teardown-bound `destroy` |
| `Attachment` (type) | `packages/svelte/src/attachments/public.d.ts` | `(element: T) => void \| (() => void)` |
| `ATTACHMENT_KEY` | `packages/svelte/src/constants.js` | `'@attach'` — symbol description matched by `attribute_effect` |
| `attach` | `packages/svelte/src/internal/client/dom/elements/attachments.js` | Runtime executor for `{@attach}` expressions |
| `attribute_effect` | `packages/svelte/src/internal/client/dom/elements/attributes.js` | Detects attachment symbols during attribute/spread application |
| `AttachTag` visitor | `packages/svelte/src/compiler/phases/3-transform/client/visitors/AttachTag.js` | Compiles `{@attach fn}` → `$.attach(node, () => fn)` |
