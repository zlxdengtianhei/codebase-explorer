# Compiler Core Builders (`compiler/utils/builders.js`)

> **Module ID:** `compiler_core_builders` (child of [`compiler_core`](compiler_core.md))
> **Location:** `packages/svelte/src/compiler/utils/builders.js`
> **Type:** Pure factory library (ESTree AST node construction)

## 1. Introduction

`builders.js` is the **AST construction toolkit of the Svelte compiler**. It exposes a large family of small, pure factory functions — each returning a plain [ESTree](https://github.com/estree/estree) node literal — that the compiler's transform phases use to assemble generated JavaScript programmatically.

Instead of string-concatenating output code, every visitor in the client transform, server transform, and CSS transform builds output as an ESTree AST using this module (conventionally imported as `b`). The AST is later rendered to source by the printer. This guarantees:

- **Well-formed output** — every node has the exact shape required by the ESTree spec (correct `type`, `operator`, `kind`, etc.), so downstream printers/sourcemap generators never see malformed syntax.
- **Composability** — builders return ordinary nodes, so generated trees can be nested, mutated, and traversed with the same tooling (`zimmerframe`'s `walk`) used for input ASTs.
- **Determinism & treeshakeability** — pure functions with no side effects; shared singletons (`b.true`, `b.false`, `b.null`, `b.this`) are reused across the entire compilation.

> **Note:** `throw_error` in this module builds a *runtime* `ThrowStatement` (`throw new Error(...)`) emitted into compiled output. It is unrelated to compile-time diagnostics, which live in [`compiler_diagnostics`](compiler_diagnostics.md).

---

## 2. Position in the Compiler Pipeline

The builders sit at the **start of the back-end (Phase 3)**: they are the only sanctioned way to create output nodes during transformation.

```mermaid
flowchart LR
    SRC["Svelte source<br/>(.svelte / .js)"] --> PARSE["Phase 1: Parse<br/>(compiler_parser)"]
    PARSE --> AST_T["Template + JS AST"]
    AST_T --> ANALYZE["Phase 2: Analyze<br/>(compiler_analyzer)"]
    ANALYZE --> CSSA["CSS scoping analysis<br/>(compiler_css_pipeline)"]
    ANALYZE --> IR["Annotated AST + Analysis"]
    IR --> TCLIENT["Client transform<br/>(compiler_client_transform)"]
    IR --> TSERVER["Server transform<br/>(compiler_server_transform)"]
    TCLIENT -- "creates output nodes via" --> B["builders.js<br/>(this module)"]
    TSERVER -- "creates output nodes via" --> B
    B --> OUT["Generated ESTree AST"]
    OUT --> PRINT["Printer (esrap) + sourcemaps"]
    PRINT --> JS["Compiled JS<br/>(client bundle / SSR module)"]
```

Because builders are consumed *after* analysis, they never need compiler intelligence (scopes, references, validation) — they only need to produce syntactically correct nodes. All semantic metadata (scope hints, expression metadata) is attached by the transform phases themselves.

---

## 3. Architecture & Dependencies

The module is intentionally **dependency-light**: three imports, one of which is type-only.

```mermaid
graph TB
    subgraph CONSUMERS["Consumers (Phase 3 visitors)"]
        CT["client transform visitors<br/>e.g. Fragment, RegularElement,<br/>IfBlock, Attribute ..."]
        ST["server transform visitors<br/>e.g. RegularElement, EachBlock,<br/>build_assignment ..."]
        TT["template serialization<br/>transform-template/template.js"]
    end

    subgraph BUILDERS["builders.js"]
        CORE["Keyword builders<br/>await · let · const · var · for · if ·<br/>return · function · true · false · null · this · debugger"]
        EXPR["Expression factories<br/>call · arrow · member · template ..."]
        STMT["Statement factories<br/>block · stmt · for_of ..."]
        OBJ["Object/class factories<br/>object · prop · init · get · set ..."]
        UTIL["Utilities<br/>thunk · unthunk · key · quasi"]
    end

    WALK["zimmerframe<br/>walk()"]
    PAT["phases/patterns.js<br/>regex_is_valid_identifier"]
    SAN["utils/sanitize_template_string.js<br/>sanitize_template_string"]
    EST["estree types<br/>(type-only)"]

    CT -->|b.*| BUILDERS
    ST -->|b.*| BUILDERS
    TT -->|b.*| BUILDERS

    UTIL --> WALK
    CORE --> PAT
    UTIL --> SAN
    BUILDERS -.-> EST

    style BUILDERS fill:#eef6ff,stroke:#4a90d9
    style CORE fill:#dceeff,stroke:#4a90d9
```

| Import | Used by | Purpose |
|---|---|---|
| `walk` (zimmerframe) | `unthunk` | Detect nested `AwaitExpression`s when peephole-optimizing async thunks |
| `regex_is_valid_identifier` (`../phases/patterns.js`) | `key` | Choose `Identifier` vs `Literal` for object keys |
| `sanitize_template_string` (`./sanitize_template_string.js`) | `quasi` | Escape `` ` ``, `${`, `\` in raw template quasis |
| `ESTree` types | all | Compile-time node typing only (stripped at build) |

For how the consuming visitors orchestrate these builders, see [`compiler_client_transform`](compiler_client_transform.md) and [`compiler_server_transform`](compiler_server_transform.md).

---

## 4. Design Principles

1. **Pure & stateless** — every function returns a fresh object literal; no builder mutates its inputs or any global state. Exceptions are the deliberately shared immutable singletons (`b.true`, `b.false`, `b.null`, `b.this`, `b.void0`, `b.empty`, `b.debugger`).
2. **String ergonomics** — string arguments are auto-coerced to AST nodes where unambiguous:
   - `id('foo')` → `Identifier`
   - `call('$.state', id('count'))` → callee becomes an `Identifier`
   - `member(expr, 'length')` → non-computed `Identifier` property
   - `member_id('a.b.c')` → nested `MemberExpression` chain from a dotted path
   - `declarator('count')` / `let('x', init)` → string patterns become identifiers
3. **Reserved-word-safe naming** — builders named after JS keywords are declared with `_builder` suffixed internal names and re-exported via a single alias block (see §6.7). This is why the canonical API reads `b.if(...)`, `b.return(...)`, `b.var(...)` even though `if`/`return` cannot be used as function declaration names.
4. **Conventionally imported as `b`** — all transforms do `import * as b from '../../../utils/builders.js'`.
5. **No codegen metadata** — function nodes created here carry `metadata: null` with the explicit comment *"should not be used by codegen"*, distinguishing generated nodes from parsed ones (which carry analyzer metadata).

---

## 5. API Reference

The tables below cover the full exported surface, grouped by family. The eleven components tracked for this module (§5.1) are the keyword-oriented builders plus the object/property helpers most characteristic of the module.

### 5.1 Core Components

| Exported as | Internal name | Signature | Produces | Description |
|---|---|---|---|---|
| `await` | `await_builder` | `await(argument)` | `AwaitExpression` | Wraps an expression in `await ...` |
| `conditional` | — | `conditional(test, consequent, alternate)` | `ConditionalExpression` | Ternary `test ? consequent : alternate` |
| `const` | `const_builder` | `const(pattern, init)` | `VariableDeclaration` (`const`) | Single-declarator `const`; init **required** (as in JS) |
| `for` | `for_builder` | `for(init, test, update, body)` | `ForStatement` | Classic `for (init; test; update) body` |
| `if` | `if_builder` | `if(test, consequent, alternate?)` | `IfStatement` | Statement-level branch (for the expression form use `conditional`) |
| `init` | — | `init(name, value)` | `Property` (`kind: 'init'`) | Object-literal property `{ name: value }`; shorthand for `prop('init', key(name), value)` |
| `let` | `let_builder` | `let(pattern, init?)` | `VariableDeclaration` (`let`) | Single-declarator `let` |
| `object` | — | `object(properties)` | `ObjectExpression` | Object literal from `Property`/`SpreadElement` list |
| `return` | `return_builder` | `return(argument?)` | `ReturnStatement` | Defaults to a bare `return;` (argument `null`) |
| `throw_error` | — | `throw_error(str)` | `ThrowStatement` | `throw new Error(str)` for runtime errors in output code |
| `var` | `var_builder` | `var(pattern, init?)` | `VariableDeclaration` (`var`) | Single-declarator `var` (used for hoisted/template declarations) |

### 5.2 Primitive Node Factories

| Function | Produces | Notes |
|---|---|---|
| `id(name)` | `Identifier` | The workhorse; used by nearly every other builder |
| `private_id(name)` | `PrivateIdentifier` | `#name` class members |
| `literal(value)` | `Literal` | Accepts `string \| boolean \| null \| number \| RegExp` |
| `key(name)` | `Identifier` \| `Literal` | Valid identifier name → `Identifier`, otherwise `Literal` (string key) |
| `member(object, property, computed?, optional?)` | `MemberExpression` | String property → non-computed identifier |
| `member_id(path)` | `Identifier` \| `MemberExpression` | `'$.state.count'` → full member chain |

### 5.3 Expression Builders

| Function | Produces | Notes |
|---|---|---|
| `array(elements?)` | `ArrayExpression` | `null` holes allowed |
| `array_pattern(elements)` | `ArrayPattern` | Destructuring target |
| `assignment(operator, left, right)` | `AssignmentExpression` | e.g. `'='`, `'+='` |
| `assignment_pattern(left, right)` | `AssignmentPattern` | Default values in destructuring/params |
| `binary(operator, left, right)` | `BinaryExpression` | |
| `logical(operator, left, right)` | `LogicalExpression` | `&&`, `\|\|`, `??` |
| `unary(operator, argument)` | `UnaryExpression` | Always prefix |
| `update(operator, argument, prefix?)` | `UpdateExpression` | `++` / `--` |
| `sequence(expressions)` | `SequenceExpression` | `(a, b, c)` |
| `spread(argument)` | `SpreadElement` | |
| `rest(argument)` | `RestElement` | |
| `call(callee, ...args)` | `CallExpression` | See §5.8 for argument normalization |
| `maybe_call(callee, ...args)` | `ChainExpression` | `callee?.(...)` — optional call |
| `new_builder(expression, ...args)` *(not exported)* | `NewExpression` | Used by `throw_error` |
| `template(elements, expressions)` | `TemplateLiteral` | Quasis from `quasi` |
| `quasi(cooked, tail?)` | `TemplateElement` | Raw value sanitized for `` ` ``/`${`/`\` |
| `void0` | `UnaryExpression` | Shared `void 0` singleton (safe `undefined`) |

### 5.4 Statement Builders

| Function | Produces | Notes |
|---|---|---|
| `block(body)` | `BlockStatement` | |
| `stmt(expression)` | `ExpressionStatement` | Turn any expression into a statement |
| `labeled(name, body)` | `LabeledStatement` | For control-flow escape hatches in loops |
| `empty` | `EmptyStatement` | Shared singleton |
| `declaration(kind, declarations)` | `VariableDeclaration` | Generic form for multiple declarators |
| `declarator(pattern, init?)` | `VariableDeclarator` | String pattern → identifier |
| `for_of(left, right, body, _await?)` | `ForOfStatement` | `_await` enables `for await (... of ...)` |
| `do_while(test, body)` | `DoWhileStatement` | |
| `debugger` (`debugger_builder`) | `DebuggerStatement` | Shared singleton |

### 5.5 Function & Class Builders

| Function | Produces | Notes |
|---|---|---|
| `arrow(params, body, async?)` | `ArrowFunctionExpression` | `expression` inferred from body type; `metadata: null` |
| `function` (`function_builder`) *(not exported by name — aliased)* | `FunctionExpression` | Backing node for `method`/`get`/`set` |
| `function_declaration(id, params, body, async?)` | `FunctionDeclaration` | Named top-level functions |
| `method(kind, key, params, body, computed?, is_static?)` | `MethodDefinition` | `'constructor' \| 'method' \| 'get' \| 'set'` |
| `get(name, body)` | `Property` (getter) | Object-literal getter |
| `set(name, body)` | `Property` (setter) | Parameter is implicitly `$$value` |
| `prop_def(key, value, computed?, is_static?)` | `PropertyDefinition` | Class fields |

### 5.6 Object & Property Builders

| Function | Produces | Notes |
|---|---|---|
| `object(properties)` | `ObjectExpression` | |
| `object_pattern(properties)` | `ObjectPattern` | Destructuring target |
| `prop(kind, key, value, computed?)` | `Property` | `kind: 'init' \| 'get' \| 'set'`; never shorthand/method |
| `init(name, value)` | `Property` | Convenience for plain object entries (see §5.1) |

### 5.7 Module (Import/Export) Builders

| Function | Produces | Notes |
|---|---|---|
| `imports(parts, source)` | `ImportDeclaration` | `parts: [imported, local][]` → named specifiers |
| `import_all(as, source)` | `ImportDeclaration` | `import * as as from 'source'` |
| `import_namespace(local)` *(internal)* | `ImportNamespaceSpecifier` | Used by `import_all` |
| `export_default(declaration)` | `ExportDefaultDeclaration` | e.g. `export default component` |

### 5.8 Call & Thunk Utilities

**`call` argument normalization.** Generated runtime helpers take many optional arguments. To keep visitor code readable, `call` accepts `false`/`null`/`undefined` placeholders and normalizes them:

```mermaid
flowchart TD
    A["call(callee, ...args)"] --> B{"callee is a<br/>string?"}
    B -->|yes| C["callee = id(callee)"]
    B -->|no| D["keep callee node"]
    C --> E["Scan args right-to-left"]
    D --> E
    E --> F{"arg is falsy?"}
    F -->|"yes & nothing<br/>truthy seen yet"| G["Pop trailing hole"]
    G --> H{"more args?"}
    F -->|"yes & a truthy arg<br/>was already seen"| I["Replace with<br/>id('undefined')"]
    I --> H
    F -->|no| J["Mark 'truthy seen', continue"]
    J --> H
    H -->|yes| F
    H -->|no| K["Return CallExpression"]
```

Concretely: `call('$.template', nodes, flags, false)` → trailing `false` is dropped; `call('$.if', cond, false, effect)` → interior `false` becomes `undefined` so positional arguments line up.

**`thunk` / `unthunk`.** Template effects must often be passed as *deferred* functions (lazily evaluated inside `$.if`, `$.each`, render effects). `thunk(expr)` wraps an expression in `() => expr`, then `unthunk` applies two peephole optimizations:

1. **Redundant-await removal** — `async () => await x()` collapses to `async () => x`, *unless* the awaited expression itself contains a nested `await` (detected with `zimmerframe`'s `walk`), in which case keeping the outer await is semantically required.
2. **Eta reduction** — `(a, b) => fn(a, b)` (sync, identifier params matching identifier args one-to-one) collapses to `fn`.

These keep emitted code minimal while preserving async semantics — important for the boundary between the client transform's lazy effects and the runtime's render scheduling (see the Reactive Runtime Engine documentation).

---

## 6. Shared Singletons & Export Aliases

### 6.1 Singleton constants

Reused AST leaves are created once and shared (treat as immutable):

| Exported as | Value |
|---|---|
| `true` | `Literal(true)` |
| `false` | `Literal(false)` |
| `null` | `Literal(null)` |
| `this` | `ThisExpression` |
| `void0` | `void 0` |
| `empty` | `EmptyStatement` |
| `debugger` | `DebuggerStatement` |

### 6.2 Keyword alias block

Because keywords cannot serve as function declaration names, seven builders are declared under `_builder` names and re-exported together at the end of the file:

```js
export {
	await_builder as await,
	let_builder as let,
	const_builder as const,
	var_builder as var,
	true_instance as true,
	false_instance as false,
	for_builder as for,
	function_builder as function,
	return_builder as return,
	if_builder as if,
	this_instance as this,
	null_instance as null,
	debugger_builder as debugger
};
```

This makes usage sites read naturally: `b.if(...)`, `b.var(...)`, `b.return(...)`, `b.true`, `b.function(...)`.

---

## 7. Component Interaction & Data Flow

The interaction pattern between a transform visitor and this module follows a strict, repeatable rhythm. The real example below is the client `Fragment` visitor (see [`compiler_client_transform`](compiler_client_transform.md)):

```mermaid
sequenceDiagram
    participant V as Client visitor (Fragment)
    participant SC as Scope (analysis state)
    participant B as builders.js (b)
    participant AST as Output AST (hoisted + body)

    V->>SC: scope.generate("text")
    SC-->>V: unique name "text_1"
    V->>B: b.id("text_1")
    B-->>AST: Identifier
    V->>B: b.call("$.text", b.literal(data))
    B-->>AST: CallExpression ($.text('Hello'))
    V->>B: b.var(id, call)
    B-->>AST: VariableDeclaration
    V->>B: b.stmt(b.call("$.append", b.id("$$anchor"), id))
    B-->>AST: ExpressionStatement (close)
    V->>B: b.block([...consts, ...init, ...update, ...close])
    B-->>AST: BlockStatement → returned to parent visitor
```

A second characteristic use is **template serialization** (`transform-template/template.js::objectify`), where a compiled HTML template is encoded as data for the runtime's `$.template(...)` call — built with `b.array`, `b.object`, `b.prop`, `b.key`, `b.literal`, and `b.void0`. This pairs with the client DOM renderer's `from_html`/`from_tree` machinery (see the Component Rendering Backends documentation).

Typical end-to-end emission (illustrative):

```js
// Template:
//   {#if visible}<p>hi</p>{/if}
//
// Visitor code (conceptual):
b.if(
	b.call('$.if', b.id('visible'), b.thunk(/* branch effect */), b.true),
	b.block([/* branch body: b.stmt(b.call('$.append', ...)) */])
);
```

---

## 8. Usage Guidelines for Maintainers

1. **Always build via `b.*`; never hand-roll node literals** in visitors — the builders enforce invariants (e.g. `Property` nodes are never `method`/`shorthand`, functions carry `metadata: null`, arrow `expression` flag derives from body type).
2. **Prefer `conditional` for expressions, `b.if` for statements** — they are distinct node types in ESTree and are not interchangeable.
3. **Use `call`'s placeholder arguments** (`false`/`null`) rather than constructing `b.id('undefined')` manually; the normalization keeps visitor code aligned with runtime helper signatures.
4. **Use `thunk` for any expression evaluated by the runtime at a later time** (render effects, branch bodies, each-item callbacks); let `unthunk` simplify it automatically.
5. **Reuse singletons** (`b.true`, `b.false`, `b.null`, `b.void0`, `b.this`) instead of `b.literal(true)` etc., and never mutate them.
6. **New runtime helper?** Update both the runtime module (e.g. client DOM renderer / server runtime) and its call sites; the string-form callee (`'$.foo'`) in `b.call` must match an exported internal `$` symbol exactly — there is no cross-check at build time.
7. **Names from user code** must flow through scope-generated identifiers (`context.state.scope.generate`) before reaching `b.id`/`b.var`, to avoid collisions in emitted code.

---

## 9. Related Modules

| Module | Relationship |
|---|---|
| [`compiler_core`](compiler_core.md) | Parent infrastructure module (entry point, options validation, state) |
| [`compiler_client_transform`](compiler_client_transform.md) | Largest consumer — all client visitors construct output with these builders |
| [`compiler_server_transform`](compiler_server_transform.md) | Consumer — SSR visitors build the server render function with these builders |
| [`compiler_css_pipeline`](compiler_css_pipeline.md) | CSS transform emits pruned/scoped stylesheets through the same codegen conventions |
| [`compiler_types`](compiler_types.md) | Template/CSS node definitions these builders *mirror* on the output side (ESTree types) |
| [`compiler_diagnostics`](compiler_diagnostics.md) | Distinct concern: compile-time errors/warnings (vs. `throw_error`'s runtime errors) |
| Component Rendering Backends | The `$.`-prefixed callees built here dispatch to the client DOM renderer / server runtime at run time |
| Reactive Runtime Engine | Effects, bindings and signals manipulated by the code generated with `thunk`/`call` |

---

*File: `packages/svelte/src/compiler/utils/builders.js` — 11 tracked core components: `await_builder`, `conditional`, `const_builder`, `for_builder`, `if_builder`, `init`, `let_builder`, `object`, `return_builder`, `throw_error`, `var_builder`.*
