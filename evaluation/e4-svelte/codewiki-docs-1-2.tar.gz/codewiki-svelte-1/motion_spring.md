# Motion Spring Module (`motion_spring`)

## 1. Introduction

The `motion_spring` module (located at `packages/svelte/src/motion/spring.js`) implements Svelte's **spring physics animation primitives**. It provides value interpolation driven by a damped harmonic oscillator model — when a value changes, instead of moving at a fixed rate, it "bounces" naturally toward its target, based on configurable `stiffness`, `damping`, and `precision` parameters.

The module exposes **two public APIs**:

| API | Kind | Status | Since |
|---|---|---|---|
| `spring(value, opts)` | Store factory (writable store contract) | **Deprecated** — use `Spring` class | Svelte 3 |
| `Spring` | Signals-based class with `.current` / `.target` | **Recommended** | Svelte 5.8.0 |

Both share the same physics engine (`tick_spring`) but differ in the reactive substrate they write to: the legacy `spring()` writes into a classic **store**, while the `Spring` class writes into fine-grained **signal sources** from the reactive runtime.

> **Context:** This module is a leaf of the [Motion & Visual Effects System](motion.md), alongside the [tweened module](motion_tweened.md) (fixed-duration interpolation) and the [transitions & animations system](transitions_and_animations.md) (one-shot enter/leave effects). Springs differ from both: they are *timeless* — the animation duration emerges from physics, not from a configured duration.

---

## 2. Public API

### 2.1 `spring(value, opts?)` — legacy store factory

```js
import { spring } from 'svelte/motion';

const size = spring(0, { stiffness: 0.15, damping: 0.8, precision: 0.01 });
await size.set(100);              // animates, resolves when settled
size.update((n) => n + 10);       // update derives new target from current value
size.subscribe((v) => {...});     // standard store subscription
```

**Options (`SpringOpts`):**

| Option | Default | Meaning |
|---|---|---|
| `stiffness` | `0.15` | Spring force multiplier (0–1). Higher → snappier. |
| `damping` | `0.8` | Velocity bleed-off (0–1). Lower → more bounce. |
| `precision` | `0.01` | Settling threshold for value and velocity. |

**Update options (`SpringUpdateOpts` — store-only, deprecated):**

| Option | Effect |
|---|---|
| `hard` | Jump instantly to the new target, cancelling any running animation. |
| `soft` | Soften the spring: `true` → effective mass ramps in at rate `0.5`; a number `n` → rate `1 / (n * 60)`. The spring temporarily has near-infinite mass (`inv_mass = 0`) and regains mass over time. |

Returns a `SpringStore<T>` object: `{ set, update, subscribe, stiffness, damping, precision }`.

### 2.2 `Spring<T>` class — modern primitive (5.8.0+)

```svelte
<script>
  import { Spring } from 'svelte/motion';

  const spring = new Spring(0);

  // Reactive variant: value follows an expression, must run inside an effect root
  const bound = Spring.of(() => someProp);
</script>

<input type="range" bind:value={spring.target} />
<input type="range" bind:value={spring.current} disabled />
```

- **`new Spring(value, options?)`** — creates a spring. `stiffness` and `damping` are clamped to `[0, 1]` at construction and on every write.
- **`Spring.of(fn, options?)`** — static factory that re-targets the spring whenever `fn()`'s reactive dependencies change (via a `render_effect`). Must be called inside an effect root (e.g. component initialisation).
- **`set(value, options?)`** — sets `target` and returns a `Promise` that resolves when `current` catches up (or rejects the previously pending promise with `Aborted` if superseded).
  - `{ instant: true }` — jumps immediately, aborting any in-flight task.
  - `{ preserveMomentum: ms }` — continues on the current trajectory for `ms` milliseconds (zero mass + momentum ramp). Intended for fling gestures.
- **Reactive properties** — `current`, `target`, `stiffness`, `damping`, `precision` are all backed by signals: reading them tracks dependencies; writing them notifies subscribers. `target`'s setter delegates to `set()`.

---

## 3. Architecture

### 3.1 Component overview

The module is a single file with four internal components. `tick_spring` is the pure physics core; the two public façades own scheduling and state management.

```mermaid
flowchart TB
    subgraph motion_spring["motion_spring (spring.js)"]
        direction TB

        subgraph public["Public API"]
            SPRING["spring(value, opts)<br/><i>deprecated store factory</i>"]
            SPRINGCLASS["class Spring&lt;T&gt;<br/><i>signals-based (5.8.0+)</i>"]
        end

        TICK["tick_spring(ctx, last, current, target)<br/><i>pure physics integrator</i><br/>- numeric / Date: Hooke + damping step<br/>- Array / Object: recursive descent<br/>- else: throw"]

        CLAMP["clamp(n, min, max)"]

        SPRING -- "invokes per rAF frame" --> TICK
        SPRINGCLASS -- "#update() invokes per rAF frame" --> TICK
        SPRINGCLASS -- "guards stiffness/damping" --> CLAMP
        TICK -- "reads is_date()" --> UTILS["is_date()<br/>(motion/utils.js)"]
    end

    style TICK fill:#e8f4fd,stroke:#2196f3
    style SPRING fill:#fff3e0,stroke:#ff9800
    style SPRINGCLASS fill:#e8f5e9,stroke:#4caf50
```

### 3.2 Physics model

`tick_spring` implements a **semi-implicit Euler integration of a damped harmonic oscillator**, evaluated once per animation frame:

```
delta         = target − current                 // displacement
velocity      = (current − last) / dt            // dt is normalized to 60fps frames
springForce   = stiffness × delta                // Hooke's law
damper        = damping × velocity               // viscous damping
acceleration  = (springForce − damper) × inv_mass
step          = (velocity + acceleration) × dt

settled  ⇔  |step| < precision  AND  |delta| < precision   → snap to target, stop the loop
otherwise → current += step, keep looping
```

`inv_mass` is the key to `soft` / `preserveMomentum`: setting it to `0` makes the spring momentarily immovable, then a recovery rate ramps it back to `1`, producing the characteristic "yield then follow" behaviour.

### 3.3 Value-type recursion

Spring supports nested structures — the integrator recurses through the shape of the value:

```mermaid
flowchart TD
    START["current value v"] --> ISNUM{"number<br/>or Date?"}
    ISNUM -- yes --> PHYS["apply physics step<br/>(Dates: step the epoch ms,<br/>return new Date)"]
    ISNUM -- no --> ISARR{"Array?"}
    ISARR -- yes --> MAP["map over elements,<br/>recurse per index"]
    ISARR -- no --> ISOBJ{"plain object?"}
    ISOBJ -- yes --> ITER["iterate own keys,<br/>recurse per key into a new object"]
    ISOBJ -- no --> ERR["throw: Cannot spring &lt;typeof&gt; values"]
    PHYS --> SETTLE{"|step| & |delta|<br/>&lt; precision?"}
    SETTLE -- yes --> DONE["return target<br/>(ctx.settled stays true)"]
    SETTLE -- no --> KEEP["return stepped value<br/>(ctx.settled = false)"]
    MAP --> DONE
    ITER --> DONE
```

Note that `ctx.settled` starts as `true` each frame and is flipped to `false` by *any* numeric leaf that has not settled — so an array/object spring only stops when **every** leaf settles.

---

## 4. Runtime integration & dependencies

The module delegates all scheduling and reactivity to the Svelte client runtime; it contains **no DOM code and no timers of its own**. Every dependency maps to a documented subsystem:

```mermaid
flowchart LR
    subgraph motion_spring
        SPRING["spring()"]
        CLASS["Spring class"]
        TICK["tick_spring"]
    end

    subgraph runtime["Reactive Runtime Engine"]
        LOOP["loop()<br/>rAF task scheduler<br/>(client_runtime_core_runtime)"]
        RAF["raf.now()<br/>frame clock (timing.js)"]
        SRC["state() / set()<br/>signal sources<br/>(client_runtime_core_sources)"]
        EFF["render_effect<br/>(client_runtime_core_effects)"]
        GET["get(signal)<br/>dependency-tracked read<br/>(client_runtime_core_runtime)"]
    end

    subgraph stores["Store Interop"]
        WR["writable()<br/>(stores_core)"]
    end

    subgraph shared["Shared utilities"]
        DEF["deferred() / noop()<br/>(shared_runtime_utilities)"]
    end

    subgraph dev["Dev-mode instrumentation"]
        TAG["tag(signal, label)<br/>(client_dev_mode_debugging)"]
    end

    SPRING --> WR
    SPRING --> LOOP & RAF
    SPRING --> DEF
    CLASS --> SRC & EFF & GET
    CLASS --> LOOP & RAF
    CLASS --> DEF
    CLASS -. "DEV only" .-> TAG
    TICK --> RAF
```

| Dependency | Module | Role in this module |
|---|---|---|
| `writable` | [stores_core](stores_core.md) | Substrate for the legacy `spring()` store (`subscribe` passthrough) |
| `loop` | [client_runtime_core_runtime](client_runtime_core_runtime.md) | Registers a per-frame callback task; returns a promise + `abort()` |
| `raf` | client runtime timing | `raf.now()` high-resolution frame clock |
| `state` / `set` | [client_runtime_core_sources](client_runtime_core_sources.md) | Private signals backing `Spring`'s `#current`, `#target`, `#stiffness`, `#damping`, `#precision` |
| `get` | [client_runtime_core_runtime](client_runtime_core_runtime.md) | Tracked reads for `Spring`'s getters (dependency registration) |
| `render_effect` | [client_runtime_core_effects](client_runtime_core_effects.md) | Powers `Spring.of(fn)` reactive retargeting |
| `deferred`, `noop` | [shared_runtime_utilities](shared_runtime_utilities.md) | Promise plumbing for `set()` resolution / abort semantics |
| `tag` | [client_dev_mode_debugging](client_dev_mode_debugging.md) | DEV-only: labels signals (`Spring.current`, `Spring.stiffness`, …) for tracing/DevTools |
| `is_date` | motion utils | Detects `Date` leaves for specialised stepping |
| `DEV` | esm-env | Compile-time flag gating dev instrumentation |

**See also:** the sibling [motion_tweened](motion_tweened.md) module shares the same `loop` scheduling pattern but uses easing functions from [transitions_and_animations](transitions_and_animations.md) instead of the spring integrator.

---

## 5. Data & control flow

### 5.1 Legacy `spring()` — animation frame loop

```mermaid
sequenceDiagram
    participant C as Consumer
    participant S as spring store
    participant L as loop() task
    participant T as tick_spring
    participant W as writable store

    C->>S: set(new_value, opts)
    alt value == null / opts.hard / stiffness≥1 & damping≥1
        S->>S: cancel_task = true, snap last=value=new
        S->>W: store.set(target)
        S-->>C: resolved Promise
    else opts.soft
        S->>S: inv_mass=0, set recovery rate
    end
    S->>L: register frame callback (if idle)
    loop every animation frame
        L->>T: tick(ctx, last, current, target)
        T-->>L: next_value, ctx.settled?
        L->>S: last_value=current; store.set(value=next)
        alt ctx.settled
            L->>L: task = null (loop ends)
        end
    end
    L-->>C: task promise fulfils (only if token is latest)
    Note over S: Elapsed time clamped to 1/30 s<br/>so blocked tabs don't "snap"
```

Key implementation details:

- **Token cancellation** — every `set()` creates a fresh `current_token`; only the promise belonging to the *latest* token resolves. Interrupted animations never resolve stale promises.
- **Hard-jump shortcut** — springs configured with `stiffness ≥ 1 && damping ≥ 1` are effectively critically-damped-without-motion, so `set` snaps immediately and cancels any running task via the `cancel_task` flag checked at the top of the next frame.
- **Frame-rate normalization** — `dt = (elapsed × 60) / 1000` converts wall-clock milliseconds into "60 fps frames", making the simulation resolution-independent.

### 5.2 `Spring` class — set / update lifecycle

```mermaid
stateDiagram-v2
    [*] --> Idle

    Idle --> Settled: constructor / instant set<br/>(current = target = value)
    Settled --> Settled: set(v, {instant:true})<br/>abort task, snap
    Settled --> Animating: set(v)<br/>start loop task
    Settled --> Yielding: set(v, {preserveMomentum:ms})<br/>inv_mass=0, momentum ramp

    Animating --> Animating: tick_spring step<br/>set(#current, next)
    Yielding --> Animating: inv_mass recovers to 1

    Animating --> Settled: |step| & |delta| < precision<br/>task=null, deferred resolves
    Animating --> Animating: new set(v) supersedes<br/>previous deferred rejects "Aborted"

    Settled --> [*]: unmount / GC
```

The class variant improves on the store in several ways:

1. **Reactive parameters** — `stiffness`, `damping`, `precision` can be *bound* in templates (`bind:value={spring.stiffness}`); each is a real signal, and changes take effect on the very next tick.
2. **Promise ownership** — `set()` stores a `#deferred`; a newer `set()` rejects the older deferred with `new Error('Aborted')` (the rejection is silently swallowed via `catch(noop)` unless the caller awaits it), and only the current deferred resolves on settle.
3. **`Spring.of(fn)`** — creates the spring and installs a `render_effect` that calls `spring.set(fn())` whenever `fn`'s dependencies change — the idiomatic way to follow reactive state (props, stores via `fromStore`, derived values).
4. **Dev-mode tracing** — all five internal signals are `tag()`ged (`Spring.current`, `Spring.target`, `Spring.stiffness`, `Spring.damping`, `Spring.precision`) so ownership/tracing tools can attribute updates.

### 5.3 End-to-end data flow

```mermaid
flowchart LR
    A["Trigger<br/>user event / prop change /<br/>bind:value={spring.target}"] --> B["set(value, options)"]
    B --> C{"instant?"}
    C -- yes --> D["snap: set(#current)<br/>+ set(#target)"]
    C -- no --> E["set(#target, value)<br/>(signals subscribers)"]
    E --> F["loop() task on raf"]
    F --> G["tick_spring(ctx, last, current, target)"]
    G --> H["set(#current, next)"]
    H --> I["UI re-renders via<br/>signal graph (effects)"]
    I -->|next frame| F
    G -->|settled| J["task ends<br/>deferred resolves"]
```

Because animation writes flow through the standard **signal sources**, any effect, template binding, or derived value reading `spring.current` updates automatically — there is no separate animation-to-render bridge.

---

## 6. Design notes & edge cases

| Concern | Handling |
|---|---|
| **Background tab / jank** | Elapsed frame time is clamped to `1000/30` ms. A long pause resumes from a physically plausible state instead of applying a huge integration step that would overshoot wildly. |
| **Division by zero** | Velocity guard: `ctx.dt \|\| 1/60` in `tick_spring` prevents NaN on the first tick. |
| **Unsupported types** | `tick_spring` throws `` `Cannot spring ${typeof} values` `` for strings, booleans, functions, etc. Only numbers, `Date`, arrays, and plain objects are animatable. |
| **Nested Dates in arrays/objects** | Recursion handles them uniformly — each `Date` leaf returns a `new Date(current.getTime() + d)`. |
| **First update on undefined** | `Spring.#update` uses `#current.v ??= value` so a spring constructed without an initial value adopts its first target instantly. |
| **Settled-spring reuse** | When `ctx.settled` is `true` the callback returns `false`, `loop` removes the task, and the next `set()` starts a fresh task — no leaked rAF loops. |
| **Treeshaking** | The legacy `spring()` factory and its `writable` dependency are independently exportable; consumers using only `Spring` need not pull in the store subsystem. |

---

## 7. Migration: `spring()` store → `Spring` class

| Legacy store | Modern class |
|---|---|
| `const s = spring(0)` | `const s = new Spring(0)` |
| `s.set(100)` | `s.target = 100` or `await s.set(100)` |
| `s.update(n => n + 10)` | `s.target += 10` |
| `$s` / `s.subscribe(...)` | read `s.current` in the template (reactive) |
| `s.set(100, { hard: true })` | `s.set(100, { instant: true })` |
| `s.set(100, { soft: 0.5 })` | `s.set(100, { preserveMomentum: … })` (closest analogue) |
| reading `s.stiffness` | `s.stiffness` (now a live signal, bindable) |

The two option sets are intentionally disjoint (`hard`/`soft` are store-only; `instant`/`preserveMomentum` are class-only) — passing the wrong kind is a silent no-op, so migrate call sites together with the constructor.

---

## 8. Related modules

- **[motion](motion.md)** — parent Motion & Visual Effects System; also hosts `prefersReducedMotion`, useful for disabling spring animations.
- **[motion_tweened](motion_tweened.md)** — fixed-duration eased interpolation; use when the motion must complete in a known time rather than settle naturally.
- **[transitions_and_animations](transitions_and_animations.md)** — one-shot CSS/JS enter/leave transitions (`fly`, `fade`, `flip`, …) and easing functions; springs complement these for *continuous* value animation.
- **[client_runtime_core_sources](client_runtime_core_sources.md)** / **[client_runtime_core_runtime](client_runtime_core_runtime.md)** — signal sources and the `get`/`loop` machinery this module builds on.
- **[stores_core](stores_core.md)** / **[stores_interop](stores_interop.md)** — the writable store contract used by the legacy `spring()` API.
- **[client_dev_mode_debugging](client_dev_mode_debugging.md)** — `tag()` labelling used for DEV-mode signal tracing.
