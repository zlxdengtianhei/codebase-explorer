# Public API HTML Typing (`public_api_html_typing`)

> **Module:** `public_api_html_typing`
> **Implementation file:** `packages/svelte/svelte-html.d.ts`
> **Parent module:** [public_api](public_api.md)
> **Core component:** `IntrinsicElements` (global `svelteHTML` namespace)

---

## 1. Introduction

`public_api_html_typing` is the **editor-integration typing layer** of the Svelte package. It is a
**declaration-only ambient module** — no runtime JavaScript exists for it — whose single job is to
teach TypeScript-based tooling (the Svelte language server, svelte2tsx, IDEs) how to type-check
every HTML and SVG element that can appear inside a `.svelte` component's markup.

Three facts define the module's character:

1. **It is deliberately hidden from the exports map.** The file header states this explicitly:
   *"This file is deliberately not exposed through the exports map. It's meant to be loaded
   directly by the Svelte language server."* No application code ever does
   `import 'svelte/svelte-html'` — instead, the language tooling injects the file into the
   compilation so that its declarations become visible **as globals**.
2. **It is a namespace in types only.** The `svelteHTML` namespace is declared inside
   `declare global { … }` with the note: *"This namespace does not exist in the runtime, it is
   only used for typings."* It is the hook through which the language tools express compiled
   template elements.
3. **It is a typed re-projection of the element catalog.** Its `IntrinsicElements` interface
   `extends` the `SvelteHTMLElements` catalog from [`svelte/elements`](svelte_element_types.md)
   (the [svelte_element_types](svelte_element_types.md) module) and re-lists every element
   through an `HTMLProps<'tag', Override>` wrapper that opens a *second* augmentation point for
   user customization.

---

## 2. Position in the System

The module sits at the intersection of three worlds: the **public element catalog**
(`svelte/elements`), the **DOM type libraries** (`lib.dom.d.ts`), and the **Svelte language
tooling** that transforms markup into typed calls.

```mermaid
flowchart TB
    subgraph TOOLING["Language tooling (external to this repo)"]
        LSP["Svelte language server"]
        S2TSX["svelte2tsx<br/>(.svelte → TS transform)"]
        LSP --- S2TSX
    end

    subgraph FILES["Declaration files in the svelte package"]
        direction TB
        SHTML["<b>svelte-html.d.ts</b><br/>public_api_html_typing — this module<br/>global svelteHTML namespace"]
        ELEM["elements.d.ts<br/>svelte_element_types<br/>SvelteHTMLElements, HTMLAttributes,<br/>SVGAttributes, per-element attr types"]
        IDT["src/index.d.ts<br/>public_api_type_contracts<br/>Component / Snippet / EventDispatcher"]
    end

    DOMLIB["TypeScript lib.dom.d.ts<br/>ElementTagNameMap, SVGElementTagNameMap,<br/>HTMLDivElement, SVGCircleElement, …"]
    USER["User source code<br/>.svelte markup + module augmentations"]

    USER -- "writes elements<br/><div> <svg> <circle> <my-widget>" --> S2TSX
    S2TSX ==>"loads directly, not via exports map"==> SHTML
    S2TSX ==>"emits svelteHTML.createElement(…) calls"==> SHTML
    SHTML -- "extends svelteElements.SvelteHTMLElements" --> ELEM
    SHTML -- "/// <reference lib='dom' />" --> DOMLIB
    S2TSX -.->|"reads component contracts<br/>for props/snippets typing"| IDT
    ELEM --> DOMLIB
```

### This module vs. its sibling modules

The `public_api` layer contains several type surfaces with distinct audiences:

| Module | File | Audience | Runtime? |
|---|---|---|---|
| **public_api_html_typing** (this) | `svelte-html.d.ts` | Svelte language server / svelte2tsx only | No — ambient globals |
| [svelte_element_types](svelte_element_types.md) | `elements.d.ts` | Application code (`import type { HTMLAttributes } from 'svelte/elements'`) | No — importable `.d.ts` |
| [public_api_type_contracts](public_api_type_contracts.md) | `src/index.d.ts` | Application code, generated component typings | No — importable `.d.ts` |
| [public_api_client_entry](public_api_client_entry.md) | `src/index-client.js` | Application code | Yes |
| [public_api_server_entry](public_api_server_entry.md) | `src/index-server.js` | Application code (SSR) | Yes |

`elements.d.ts` and `svelte-html.d.ts` are complementary layers of the same concern — element
typing. The element *catalog* (attributes per tag) lives in
[svelte_element_types](svelte_element_types.md); the *template-checking hook* and the
language-server-facing global namespace live here. The module also deliberately keeps
backwards-compat shims for users who historically augmented `svelteHTML.HTMLAttributes` /
`svelteHTML.SVGAttributes` directly (scheduled for removal in Svelte 6, see
[§7](#7-versioning--deprecation-notes)).

---

## 3. Architecture of the Declaration File

```mermaid
flowchart LR
    subgraph GLOBAL["declare global → namespace svelteHTML"]
        direction TB

        HP["<b>HTMLProps&lt;Property, Override&gt;</b><br/>@internal helper type<br/>Omit&lt;SvelteHTMLElements[Property], keyof Override&gt;<br/>&amp; Override"]

        subgraph FN["Type-level function shims (called by svelte2tsx output)"]
            MAP["<b>mapElementTag</b><br/>3 overloads<br/>tag → ElementTagNameMap[K]<br/>/ SVGElementTagNameMap[K] / any"]
            CREATE["<b>createElement</b><br/>2 overloads<br/>(element, attrs) and<br/>(element, attrsEnhancers, attrs)"]
        end

        subgraph AUG["Augmentation points"]
            HA["<b>HTMLAttributes&lt;T&gt;</b><br/>empty interface — deprecated,<br/>remove in Svelte 6"]
            SA["<b>SVGAttributes&lt;T&gt;</b><br/>empty interface — deprecated,<br/>remove in Svelte 6"]
        end

        IE["<b>IntrinsicElements</b><br/>extends svelteElements.SvelteHTMLElements<br/>≈100 HTML entries: HTMLProps&lt;'tag', HTMLAttributes&gt;<br/>≈55 SVG entries: HTMLProps&lt;'tag', SVGAttributes&gt;<br/>+ string index signature for custom elements"]
    end

    IE -- "each entry wrapped by" --> HP
    HP -- "base catalog" --> CATALOG["SvelteHTMLElements<br/>(svelte_element_types)"]
    HP -- "override/merge source" --> AUG
    FN -- "typed against" --> IE
```

### 3.1 Member catalog

| Member | Kind | Visibility | Purpose |
|---|---|---|---|
| `HTMLProps<Property, Override>` | type alias | `@internal` | Re-projects one catalog entry: `Omit<SvelteHTMLElements[Property], keyof Override> & Override`. `keyof Override` keys are stripped from the base and re-added from the override, so user-augmented attributes win cleanly over the built-in ones. |
| `mapElementTag` | function ×3 overloads | `@internal` | Maps a tag string to its DOM class: `ElementTagNameMap[K]` for HTML, `SVGElementTagNameMap[K]` for SVG, and a final `(tag: any) => any` overload — explicitly required *"because used in context of `<svelte:element>`"*. |
| `createElement` | function ×2 overloads | `@internal` | The type-level shim that svelte2tsx emits for every template element. Returns the concrete DOM element class for the tag, falling back to `any`. |
| `HTMLAttributes<T>` | empty interface | deprecated | Legacy augmentation point; historically users merged extra attributes here. Comment: *"TODO remove … in Svelte 6"*. |
| `SVGAttributes<T>` | empty interface | deprecated | SVG counterpart of the above. |
| `IntrinsicElements` | interface | tooling-facing | The full element catalog. Extends `svelteElements.SvelteHTMLElements` (thus also inheriting the `svelte:*` special-element keys and the catch-all index signature), and re-declares each HTML entry as `HTMLProps<'tag', HTMLAttributes>` and each SVG entry as `HTMLProps<'tag', SVGAttributes>`. Ends with `[name: string]: { [name: string]: any }` so unknown/custom element tags never produce hard type errors. |

### 3.2 The two `createElement` overloads

```typescript
// Overload 1 — plain attributes
createElement<Elements extends IntrinsicElements, Key extends keyof Elements>(
    element: Key | undefined | null,   // "undefined | null" because of <svelte:element>
    attrs: string extends Key ? svelteElements.HTMLAttributes<any> : Elements[Key]
): Key extends keyof ElementTagNameMap ? ElementTagNameMap[Key]
 : Key extends keyof SVGElementTagNameMap ? SVGElementTagNameMap[Key]
 : any;

// Overload 2 — with attribute enhancers (used by the language tools to carry
// transformed declarations, e.g. event/binding constructs, alongside the attrs)
createElement<Elements extends IntrinsicElements, Key extends keyof Elements, T>(
    element: Key | undefined | null,
    attrsEnhancers: T,
    attrs: (string extends Key ? svelteElements.HTMLAttributes<any> : Elements[Key]) & T
): /* same conditional DOM-class mapping as overload 1 */;
```

Two deliberate design points:

- **`Key | undefined | null`** — `<svelte:element this={maybeUndefined}>` can compile to a call
  whose tag is `null`/`undefined` or a plain `string`; both overloads accept this and the
  conditional attribute type degrades to `HTMLAttributes<any>` when the key is an unresolved
  `string`.
- **Conditional return type** — the instance type is resolved through the DOM libraries'
  tag-name maps, giving `bind:this` the correct `HTMLInputElement`, `SVGSVGElement`, etc. For
  unknown tags the result is `any`, keeping the transform resilient.

---

## 4. Data Flow: How a Template Element Gets Typed

The following flow traces `<input bind:value={v} on:click={h} />` and
`<svelte:element this={tag} />` from authoring to a resolved TypeScript type.

```mermaid
sequenceDiagram
    participant Dev as Developer (.svelte markup)
    participant LS as Svelte language server
    participant TSX as svelte2tsx transform
    participant TS as TypeScript checker
    participant NS as global svelteHTML (this module)
    participant ELEM as svelte/elements (SvelteHTMLElements)
    participant DOM as lib.dom.d.ts (tag-name maps)

    Dev->>LS: authors <input bind:value={v} on:click={h}/>
    LS->>TSX: request TS view of component
    Note over TSX: markup is rewritten into<br/>TypeScript calls
    TSX->>NS: svelteHTML.createElement("input", {…})
    TS->>NS: resolve global namespace (file loaded directly by LS)
    NS->>ELEM: IntrinsicElements["input"] = HTMLProps<'input', HTMLAttributes>
    ELEM-->>NS: HTMLInputAttributes base
    NS-->>TS: attrs type = base ∪ user augmentations
    TS->>DOM: return type: 'input' extends keyof ElementTagNameMap?
    DOM-->>TS: → HTMLInputElement (instance type for bind:this)
    TS-->>Dev: attribute diagnostics, completions, hover types
```

Key resolution rules along the way:

1. **Namespace injection** — the language server adds `svelte-html.d.ts` to the program (it is
   not resolvable through the package's exports map), making `svelteHTML` a global.
2. **Attribute typing** — `Elements[Key]` resolves through the `HTMLProps` wrapper to the
   per-tag attribute interface from [svelte_element_types](svelte_element_types.md) (e.g.
   `HTMLInputAttributes`), minus any keys re-declared by the (possibly user-augmented)
   `svelteHTML.HTMLAttributes` / `SVGAttributes` merge, plus those overrides.
3. **Instance typing** — the conditional return walks
   `ElementTagNameMap` → `SVGElementTagNameMap` → `any`, so variables bound via `bind:this`
   carry the concrete DOM class.
4. **Dynamic elements** — for `<svelte:element this={tag}>` the key may be `undefined`, `null`
   or an arbitrary `string`; the `string extends Key` branch selects the permissive
   `HTMLAttributes<any>` attribute bag and the final `any` overload/branch provides the instance
   type, mirroring the runtime behavior where the tag is only known at mount time.
5. **Unknown tags** — the trailing index signature `[name: string]: { [name: string]: any }`
   (inherited from and re-declared in `IntrinsicElements`) means custom elements used without
   augmentation type as loose attribute bags instead of failing compilation.

---

## 5. Component Interaction & External Relationships

```mermaid
flowchart TB
    subgraph PUB["public_api (parent module)"]
        direction LR
        SELF["<b>public_api_html_typing</b><br/>svelte-html.d.ts"]
        TC["public_api_type_contracts<br/>Component / Snippet /<br/>EventDispatcher"]
        CE["public_api_client_entry"]
        SE["public_api_server_entry"]
    end

    ELEM["svelte_element_types<br/>elements.d.ts<br/>SvelteHTMLElements /<br/>HTMLAttributes / SVGAttributes"]
    ST["svelte-types<br/>types/index.d.ts<br/>aggregated published .d.ts"]
    TAST["compiler_types_template_ast<br/>RegularElement / BaseElement /<br/>Attribute (compiler's own element model)"]
    CLI["client_dom_renderer_elements_and_events<br/>attribute_effect / set_attribute /<br/>set_custom_element_data (runtime)"]
    SSR["server_runtime_rendering_core<br/>element / spread_attributes (runtime)"]
    APP["Application & extension authors"]

    ELEM ==>"extends SvelteHTMLElements ==> re-lists every tag"==> SELF
    SELF -.->|"complementary: element-level<br/>vs component-level contracts"| TC
    SELF -.->|"not re-exported through the<br/>exports map; loaded by LS directly"| ST
    TAST -.->|"parallel universe: the compiler<br/>has its own template AST,<br/>independent of tooling typings"| SELF
    SELF -.->|"attributes accepted by these types are<br/>applied at runtime by"| CLI
    SELF -.-> SSR
    APP -- "declaration merging<br/>(see §6)" --> SELF
    APP -- "declaration merging" --> ELEM
```

Notable relationships:

- **[svelte_element_types](svelte_element_types.md)** is the *single source of truth* for
  attribute shapes. This module contains **no attribute definitions of its own** — every
  `HTMLProps<'div', …>` call dereferences `SvelteHTMLElements['div']`. A change to an element's
  attributes in `elements.d.ts` automatically flows into template checking here.
- **[public_api_type_contracts](public_api_type_contracts.md)** types the *component* surface
  (`Component`, `Snippet`, `EventDispatcher`); this module types the *element* surface. The
  language tools need both: svelte2tsx emits component instantiations typed by `Component` and
  template elements typed by `svelteHTML.createElement`.
- **[svelte-types](svelte-types.md)** aggregates the *importable* public types; because this
  file is intentionally outside the exports map, it is absent from that aggregation — tooling
  must load it by path.
- **Compiler AST types** ([compiler_types_template_ast](compiler_types_template_ast.md)) are a
  parallel, compiler-internal model of elements (`RegularElement`, `Attribute`,
  `SpreadAttribute`, …) consumed by the analyzer and code generators. The two models never meet:
  this module exists only for TypeScript checking of user markup.
- **Runtime backends** — the attribute contracts validated here are eventually executed by
  [client_dom_renderer_elements_and_events](client_dom_renderer_elements_and_events.md)
  (`attribute_effect`, `set_attribute`, `set_custom_element_data`) on the client and by
  [server_runtime_rendering_core](server_runtime_rendering_core.md) (`element`,
  `spread_attributes`) during SSR. Unknown attributes that slip through the catch-all index
  signature surface at runtime as attribute sets, not type errors.

---

## 6. Extensibility: Augmentation Paths

The module is designed to be extended by declaration merging, and it supports three distinct
paths with different lifetimes:

```mermaid
flowchart TB
    USER["User project — *.d.ts"]

    subgraph RECOMMENDED["① Recommended — augment the public catalog"]
        AUG1["declare module 'svelte/elements' {<br/>  interface SvelteHTMLElements { 'my-widget': … }<br/>  interface HTMLAttributes { … }<br/>}<br/><br/>or: interface HTMLAttributes<…><br/>via import + global merge"]
    end

    subgraph LEGACY["② Legacy — augment the ambient shims (removed in Svelte 6)"]
        AUG2["declare global {<br/>  namespace svelteHTML {<br/>    interface HTMLAttributes { … }<br/>    interface SVGAttributes { … }<br/>  }<br/>}"]
    end

    subgraph BUILTIN["③ Built-in escape hatch"]
        IDX["IntrinsicElements[string] →<br/>{ [name: string]: any }<br/>unknown/custom elements type loosely,<br/>never error"]
    end

    CATALOG["SvelteHTMLElements<br/>(svelte_element_types)"]
    HTMLP["HTMLProps<'tag', Override><br/>(this module)"]
    IE["IntrinsicElements<br/>(this module)"]
    TOOLS["Language tooling checks"]

    USER --> AUG1
    USER --> AUG2
    AUG1 ==>"merges into"==> CATALOG
    AUG2 ==>"merges into empty<br/>HTMLAttributes / SVGAttributes"==> HTMLP
    CATALOG ==>|"extends"| IE
    HTMLP ==>|"wraps each entry"| IE
    IDX --> IE
    IE ==> TOOLS
```

| Path | Mechanics | When to use |
|---|---|---|
| **① `svelte/elements` augmentation** | Declaration-merge into `SvelteHTMLElements` / `HTMLAttributes` / `SVGAttributes` of `elements.d.ts`. Because `IntrinsicElements` *extends* `SvelteHTMLElements`, additions propagate automatically. | Registering custom elements, adding framework-specific attributes, tightening types. This is the documented, future-proof path. |
| **② `svelteHTML` ambient augmentation** | Declaration-merge into the *empty* `svelteHTML.HTMLAttributes` / `svelteHTML.SVGAttributes`. The `HTMLProps` wrapper (`Omit<base, keyof Override> & Override`) then layers these members over the base catalog for every element entry that references the respective override interface. | Only for compatibility with pre-Svelte-5 typing setups that enhanced the `svelteHTML` namespace directly. Explicitly marked for removal in Svelte 6. |
| **③ Index signature** | `IntrinsicElements` closes with `[name: string]: { [name: string]: any }`. | Zero-config tolerance for web-component libraries without shipped types. Trade-off: no checking for tags not covered by ①. |

---

## 7. Versioning & Deprecation Notes

- The in-file comment marks a clear deprecation plan:
  > *TODO remove `HTMLAttributes`/`SVGAttributes`/`IntrinsicElements` in Svelte 6*
  
  The duplicated local interfaces exist purely *"for backwards-compatibility and ease-of-use, in
  case someone enhanced the typings from `import('svelte/elements').HTMLAttributes/SVGAttributes`"*.
  Maintainers should treat the ambient `svelteHTML` interfaces as frozen shims — new attribute
  or element support belongs in [svelte_element_types](svelte_element_types.md).
- Several members carry `@internal do not use` annotations (`HTMLProps`, `mapElementTag`,
  `createElement`). They exist for the language tools' codegen contract, not for application
  code, and may change without a semver-major release.
- The file starts with `/// <reference lib="dom" />`, guaranteeing the DOM tag-name maps it
  depends on are part of any program the language server builds with it.

---

## 8. Maintainer Quick Reference

| Task | Where to act |
|---|---|
| Add/change an element's attributes | `packages/svelte/elements.d.ts` — [svelte_element_types](svelte_element_types.md). This file follows automatically. |
| Add a brand-new standard element | Both files: catalog entry in `elements.d.ts` **and** the `HTMLProps<'tag', …>` line here (the local list is an explicit enumeration). |
| Register a custom element for users | Document path ① (augment `SvelteHTMLElements`) — no core change needed. |
| Change how svelte2tsx emits elements | Coordinate with the `createElement` / `mapElementTag` overload shapes here — they are the contract with the language tools. |
| Understand what happens to attributes at runtime | [client_dom_renderer_elements_and_events](client_dom_renderer_elements_and_events.md) (client) and [server_runtime_rendering_core](server_runtime_rendering_core.md) (SSR). |
| Type a *component* rather than an element | [public_api_type_contracts](public_api_type_contracts.md). |
