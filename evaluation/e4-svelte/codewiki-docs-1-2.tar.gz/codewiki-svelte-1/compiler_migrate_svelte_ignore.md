# compiler_migrate_svelte_ignore

> **Module path:** `packages/svelte/src/compiler/utils/extract_svelte_ignore.js`
> **Parent module:** [compiler_migrate](compiler_migrate.md) (Source Migration & Preprocessing Tooling)

## 1. Introduction

The `compiler_migrate_svelte_ignore` module implements the rewriting of `<!-- svelte-ignore ... -->` comment directives as part of the Svelte 4 → Svelte 5 code migration. Its single exported transformation, **`migrate_svelte_ignore`**, converts legacy kebab-case warning codes (Svelte 4) into the snake_case codes used by the Svelte 5 compiler, and inserts the commas that the runes-mode parser now requires between codes.

Svelte 5 renamed every compiler warning/error code (e.g. `unused-export-let` → `export_let_unused`) and tightened the syntax of `svelte-ignore` comments: codes must be comma-separated, and any text after the codes is treated as prose. Components upgraded from Svelte 4 therefore contain ignore comments that would either be silently ineffective or produce `unknown_code` warnings. The migration tooling calls this module's function for every comment node in the template AST so that suppression behaviour is preserved after upgrade.

The file also hosts the sibling function **`extract_svelte_ignore`**, which is the parse-time counterpart: it *validates and collects* ignore codes while the parser reads a comment. Understanding both functions together is useful because they share the same replacement table, the same code vocabulary, and the same two syntax regimes (strict/runes vs. lax/legacy).

## 2. Core Responsibilities

| Responsibility | Function | Notes |
|---|---|---|
| Rewrite legacy ignore codes in comment text | `migrate_svelte_ignore(text)` | Pure string → string transformation; no compiler state required |
| Validate & collect ignore codes at parse time | `extract_svelte_ignore(offset, text, runes)` | Emits `legacy_code` / `unknown_code` diagnostics for unrecognized codes |
| Maintain the legacy → modern code mapping | `replacements` (module-private) | 9 named legacy codes; all other kebab-case codes fall back to mechanical `-` → `_` conversion |

The module is intentionally tiny and side-effect free (with respect to the compiler): `migrate_svelte_ignore` performs no I/O, holds no state, and can be reasoned about as a pure function — which is what makes it safely callable from the AST walking machinery of the migrator.

## 3. Position in the Architecture

The Svelte compiler's migration entry point ([compiler_migrate](compiler_migrate.md)) parses a `.svelte` source into an AST, then walks it with a `MagicString` so that every transformation is tracked as an edit over the original source. During the template walk, the `Comment` visitor hands each comment's `data` to `migrate_svelte_ignore`. This module therefore sits in the **"source-migration tooling"** layer, downstream of parsing and upstream of the final code output — it never touches the compile pipeline itself (`compile()`/`compileModule()` in [compiler_core](compiler_core.md)).

```mermaid
flowchart TB
    subgraph Source_Migration_Tooling["Source Migration & Preprocessing Tooling"]
        direction TB
        MIG_API["compiler_migrate_api<br/>migrate()"]
        MIG_TF["compiler_migrate_transformations<br/>handle_identifier, handle_events,<br/>migrate_slot_usage, trim_block"]
        IGNORE["<b>compiler_migrate_svelte_ignore</b><br/>migrate_svelte_ignore()"]
    end

    subgraph Parser["Compiler Front-End (see compiler_parser)"]
        PARSE["1-parse: parse()"]
        FUZZY["1-parse/utils/fuzzymatch.js<br/>(suggestion engine)"]
        EXTRACT["extract_svelte_ignore()<br/>(parse-time validation)"]
    end

    subgraph Diagnostics["Compiler Infrastructure (see compiler_diagnostics)"]
        WARNS["compiler/warnings.js<br/>codes, legacy_code, unknown_code"]
        CONST["src/constants.js<br/>IGNORABLE_RUNTIME_WARNINGS"]
    end

    MIG_API -->|"parse(source)"| PARSE
    MIG_API -->|"walk(template)"| MIG_TF
    MIG_API -->|"Comment visitor"| IGNORE
    IGNORE -->|"returns rewritten text<br/>→ MagicString.overwrite"| MIG_API

    PARSE -.->|"comment content"| EXTRACT
    EXTRACT -->|"validates codes"| WARNS
    EXTRACT -->|"suggests fixes"| FUZZY
    EXTRACT -->|"valid codes"| CONST
    IGNORE -.->|"shares replacements table<br/>& code vocabulary (static import)"| WARNS
```

*Solid arrows: runtime call flow during `migrate()`. Dashed arrows: shared definitions / auxiliary relationships.*

### Module tree placement

```
Source_Migration___Preprocessing_Tooling
└── compiler_migrate
    ├── compiler_migrate_api            (migrate, extract_type_and_comment)
    ├── compiler_migrate_transformations (handle_identifier, handle_events,
    │                                     migrate_slot_usage, trim_block)
    └── compiler_migrate_svelte_ignore  ← this module
                                          (packages/svelte/src/compiler/utils/extract_svelte_ignore.js)
```

## 4. API Reference

### 4.1 `migrate_svelte_ignore(text)` — core component

```javascript
/**
 * Replaces legacy svelte-ignore codes with new codes.
 * @param {string} text
 * @returns {string}
 */
export function migrate_svelte_ignore(text)
```

**Parameters**

- `text` — the raw content of a `Comment` AST node (everything between `<!--` and `-->`).

**Returns** — the (possibly rewritten) text. Returns the input unchanged when it is not a `svelte-ignore` comment.

**Algorithm**

1. Test the text against `regex_svelte_ignore = /^\s*svelte-ignore\s/`. If it does not match, return the text untouched — this is a cheap early-exit for the vast majority of comments (HTML comments, migration-task comments, etc.).
2. Compute `length`, the length of the `svelte-ignore ` prefix; everything after it is the code list.
3. Replace every code token, matched with `/\w+-\w+(-\w+)*/g` (i.e. a kebab-case token of at least two segments):
   - If the token is a key of the `replacements` table, use the mapped modern code.
   - Otherwise, mechanically convert kebab-case to snake_case: `code.replace(/-/g, '_')`. This covers the many warnings whose names survived the Svelte 5 rename unchanged apart from the separator convention (e.g. `a11y-missing-attribute` → `a11y_missing_attribute`).
   - **Comma insertion:** if another code token follows in the remaining text (checked by testing the substring after the current token against `/\w+-\w+/`), append a `,`. This is what upgrades Svelte 4's whitespace-separated list into the comma-separated list runes mode demands. Trailing text after the last code (prose) is preserved as-is and never gets a comma.
4. Reassemble: `prefix (unchanged) + rewritten code list (+ prose)`.

**Design notes**

- The token regex only matches multi-segment kebab-case tokens; a single-word token such as `foo` is left alone (there is nothing to convert).
- Unlike `extract_svelte_ignore`, this function performs **no validation** — it never warns about unknown codes. Its contract is "best-effort textual rewrite"; code correctness is enforced later, the next time the migrated component is compiled, at which point `extract_svelte_ignore` (runes mode) will flag anything unrecognizable with `unknown_code` and a fuzzy-match suggestion.
- The comma detection is positional (`substring(length + idx + code.length)`), so commas are only inserted *between* codes, never after the final code or before prose.

### 4.2 `extract_svelte_ignore(offset, text, runes)` — sibling (context)

```javascript
export function extract_svelte_ignore(offset, text, runes): string[]
```

Used by the parser (front-end, see [compiler_parser](compiler_parser.md)) when it reads a comment whose content begins with `svelte-ignore`. It returns the list of warning codes that should be pushed onto the compiler's ignore stack (see `push_ignore`/`pop_ignore` in [compiler_core_state](compiler_core_state.md)). Behaviour differs by mode:

- **Runes mode (`runes: true`)** — strict syntax. Codes must be comma-separated; parsing stops at the first non-comma-terminated token, treating the remainder as prose. Each code is validated against the union of `w.codes` (all compile warnings) and `IGNORABLE_RUNTIME_WARNINGS` (runtime warnings that may be ignored). Unknown codes produce a `legacy_code` warning when a replacement exists, otherwise `unknown_code` with a `fuzzymatch` suggestion (similarity > 0.7).
- **Non-runes mode** — lax backwards compatibility. All `[\w$-]+` tokens are accepted, and for unknown codes the module additionally pushes the *modern replacement* alongside the legacy code, so that Svelte-5-named warnings raised by the analyzer are suppressed too.

### 4.3 The `replacements` table (module-private)

Maps the nine legacy codes whose *meaning* changed or whose names did not follow the mechanical rename rule:

| Legacy code (Svelte 4, kebab) | Modern code (Svelte 5, snake) |
|---|---|
| `non-top-level-reactive-declaration` | `reactive_declaration_invalid_placement` |
| `module-script-reactive-declaration` | `reactive_declaration_module_script` |
| `empty-block` | `block_empty` |
| `avoid-is` | `attribute_avoid_is` |
| `invalid-html-attribute` | `attribute_invalid_property_name` |
| `a11y-structure` | `a11y_figcaption_parent` |
| `illegal-attribute-character` | `attribute_illegal_colon` |
| `invalid-rest-eachblock-binding` | `bind_invalid_each_rest` |
| `unused-export-let` | `export_let_unused` |

Codes not present in the table are assumed to follow the uniform `-` → `_` rename. This table is shared at module scope by both exported functions; the code vocabulary it maps into is defined by the generated `compiler/warnings.js` (see [compiler_diagnostics_warnings](compiler_diagnostics_warnings.md)) plus `IGNORABLE_RUNTIME_WARNINGS`.

## 5. Data & Control Flow

### 5.1 Migration-time flow (primary path)

```mermaid
sequenceDiagram
    autonumber
    participant M as migrate()<br/>(compiler_migrate_api)
    participant P as parse()<br/>(compiler_parser)
    participant W as template walk<br/>(zimmerframe walk)
    participant C as Comment visitor<br/>(compiler_migrate)
    participant S as migrate_svelte_ignore()<br/>(this module)
    participant MS as MagicString

    M->>P: source
    P-->>M: AST (Comment nodes carry raw data)
    M->>W: walk(parsed.fragment, state, template)
    W->>C: visit Comment node
    C->>S: node.data (e.g. "svelte-ignore unused-export-let foo-bar")
    S-->>C: "svelte-ignore export_let_unused, foo_bar"
    alt rewritten text differs
        C->>MS: overwrite(start + 4, end - 3, migrated)
        Note over MS: offsets exclude the <!-- and --> delimiters
    end
    C-->>W: continue walk
    W-->>M: done
    M-->>M: return { code: str.toString() }
```

Key detail: the `Comment` visitor only issues a `MagicString.overwrite` when `migrate_svelte_ignore` actually changed the text (`migrated !== node.data`), so comment-only edits stay minimal in the produced diff and source maps remain tight.

### 5.2 Per-comment decision flow inside `migrate_svelte_ignore`

```mermaid
flowchart TD
    A["text = comment data"] --> B{"matches<br/>/^\s*svelte-ignore\s/ ?"}
    B -- no --> R1["return text unchanged"]
    B -- yes --> C["scan kebab-case tokens<br/>/\w+-\w+(-\w+)*/g"]
    C --> D{"token in<br/>replacements map?"}
    D -- yes --> E["use mapped modern code"]
    D -- no --> F["kebab→snake:<br/>code.replace(/-/g, '_')"]
    E --> G{"another code token<br/>follows?"}
    F --> G
    G -- yes --> H["append ','"]
    G -- no --> I["preserve trailing prose"]
    H --> J["more tokens?"]
    I --> J
    J -- yes --> C
    J -- no --> R2["prefix + rewritten codes<br/>(+ prose)"]
```

### 5.3 Transformation example

```
Input  (Svelte 4 comment):
  <!-- svelte-ignore unused-export-let invalid-html-attribute -->
          │ prefix kept           │ tokens rewritten       │ commas inserted between

Output (Svelte 5 comment):
  <!-- svelte-ignore export_let_unused, attribute_invalid_property_name -->
```

Prose after the codes is preserved without a trailing comma: `svelte-ignore a11y-hidden because of the icon font` becomes `svelte-ignore a11y_hidden because of the icon font`.

## 6. Dependencies

`migrate_svelte_ignore` itself has **no runtime imports** — it relies only on module-local regexes and the `replacements` table. The *file*, however, also defines `extract_svelte_ignore`, which depends on:

| Import | Source | Used by | Purpose |
|---|---|---|---|
| `IGNORABLE_RUNTIME_WARNINGS` | `src/constants.js` | `extract_svelte_ignore` | The whitelist of runtime warnings that `svelte-ignore` may suppress (`await_waterfall`, `await_reactivity_loss`, `state_snapshot_uncloneable`, `binding_property_non_reactive`, `hydration_attribute_changed`, `hydration_html_changed`, `ownership_invalid_binding`, `ownership_invalid_mutation`). The constants file explicitly notes this list exists so validation of `svelte-ignore` stays strict. |
| `fuzzymatch` | `compiler/phases/1-parse/utils/fuzzymatch.js` | `extract_svelte_ignore` (runes mode) | FuzzySet-based "did you mean" suggestion (similarity threshold 0.7) for unrecognized codes. Part of the [compiler_parser_parse_utilities](compiler_parser_parse_utilities.md) module. |
| `w` (warnings) | `compiler/warnings.js` | `extract_svelte_ignore` | `codes` (generated list of all warning codes), `legacy_code`, and `unknown_code` diagnostics. Generated by `scripts/process-messages` — see the [svelte_build_tooling](svelte_build_tooling.md) module. |

**Consumers of this module:**

| Consumer | Usage |
|---|---|
| `compiler/migrate/index.js` → `Comment` visitor ([compiler_migrate](compiler_migrate.md)) | imports `migrate_svelte_ignore`; overwrites comment content when rewritten |
| `compiler/phases/1-parse` (comment reading) | uses `extract_svelte_ignore` to populate the ignore stack during compilation |

## 7. Interaction with the Broader System

- **Parser ↔ migrator symmetry.** Because Svelte 5's parser (runes mode) enforces the comma-separated, snake_case syntax via `extract_svelte_ignore`, the migrator must transform comments to that dialect. The two functions are two faces of the same contract: the parser defines "valid", the migrator rewrites "legacy → valid".
- **Ignore stack semantics.** Whatever codes survive extraction are pushed/popped through `push_ignore` / `pop_ignore` in [compiler_core_state](compiler_core_state.md), and checked by `warning_filter` inside [compiler_diagnostics_warnings](compiler_diagnostics_warnings.md). This module only deals with the *source-text* representation of ignores, never the runtime stack.
- **Non-goal: preprocessing.** Comments containing `svelte-ignore` that pass through [compiler_preprocess](compiler_preprocess.md) first (e.g. inside preprocessor-generated output) are handled the same way — the migrator operates on the final template source it receives.
- **Tooling entry point.** The migrator (and hence this module) is exposed through the compiler's public tooling API rather than `compile()`; users typically invoke it via `npx sv migrate svelte-5` or the `migrate` export documented in [compiler_migrate_api](compiler_migrate_api.md).

## 8. Testing & Extension Guidance

- **Extending the code set:** when a new warning is added to `compiler/warnings.js`, no change is needed here — unknown kebab-case names convert mechanically. Only add an entry to `replacements` when a legacy code maps to a *different* name than the mechanical conversion (or the legacy code is ambiguous).
- **Behavioural invariants worth asserting in tests:**
  1. Non-`svelte-ignore` comments are returned byte-identical.
  2. Multiple codes get exactly one comma between codes, none after the last.
  3. Mapped codes take precedence over mechanical conversion.
  4. Prose following the final code is preserved verbatim.
  5. Single-segment tokens (no hyphen) are left untouched.
- **Failure mode:** because the function never validates, a typo'd legacy code in a comment becomes a typo'd snake_case code after migration; it will surface as an `unknown_code` warning (with a fuzzymatch suggestion) on the first subsequent compile — not as a migration error.

## 9. Related Documentation

- [compiler_migrate](compiler_migrate.md) — parent module: overall migration pipeline and `State`
- [compiler_migrate_api](compiler_migrate_api.md) — `migrate()` entry point and error/migration-task handling
- [compiler_migrate_transformations](compiler_migrate_transformations.md) — sibling AST transformations applied during the same walk
- [compiler_parser](compiler_parser.md) / [compiler_parser_parse_utilities](compiler_parser_parse_utilities.md) — parser that consumes `extract_svelte_ignore` and provides `fuzzymatch`
- [compiler_diagnostics_warnings](compiler_diagnostics_warnings.md) — generated warning catalog defining the valid code vocabulary
- [compiler_core_state](compiler_core_state.md) — `push_ignore` / `pop_ignore` runtime ignore stack
