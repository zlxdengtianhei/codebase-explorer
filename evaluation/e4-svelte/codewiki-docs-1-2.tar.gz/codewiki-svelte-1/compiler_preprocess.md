# Compiler Preprocess Module

> **Module:** `compiler_preprocess` (part of *Source Migration & Preprocessing Tooling*)
> **Source files:** `packages/svelte/src/compiler/preprocess/index.js`, `packages/svelte/src/compiler/preprocess/public.d.ts`

## 1. Introduction & Purpose

The `compiler_preprocess` module implements **`svelte.preprocess`**, the official hook system for
arbitrarily transforming Svelte component source code **before the compiler parses it**.

Its canonical use case is language extension: converting `<style lang="sass">` blocks into plain CSS
or `<script lang="ts">` TypeScript into JavaScript, while keeping **accurate source maps** so that
errors, warnings and debugger output still point at the original file written by the developer.

Key responsibilities:

| Responsibility | Mechanism |
|---|---|
| Whole-file transformation | `markup` preprocessors run over the entire component source |
| Per-tag transformation | `script` / `style` preprocessors run over each `<script>` / `<style>` tag |
| Source map fidelity | Every replacement is spliced as a `MappedCode`; per-preprocessor maps are chained and composed with `@jridgewell/remapping` |
| Dependency tracking | Preprocessors may declare watched files (e.g. `@import`ed Sass partials), surfaced via `Processed.dependencies` |
| Attribute round-tripping | Tag attributes are parsed before the hook runs and re-serialized afterwards (preprocessors may rewrite them, e.g. removing `lang="ts"`) |

The module is intentionally **decoupled from the compiler internals**: it operates purely on strings
and source maps, and hands its output back to tooling (bundler plugins such as `vite-plugin-svelte`
/ `vitePreprocess`, or `svelte-preprocess`) which then invokes `compile()`.

## 2. Position in the System

`preprocess` is exported as a named export of `svelte/compiler` from
`packages/svelte/src/compiler/index.js` (`export { default as preprocess } from './preprocess/index.js'`).
It runs **before** the parse phase and is therefore the first stage of any real-world Svelte build:

```mermaid
flowchart LR
    subgraph Tooling["External build tooling"]
        BP["Bundler plugin<br/>(vite-plugin-svelte, rollup-plugin-svelte)"]
        PP["Preprocessor packages<br/>(vitePreprocess, svelte-preprocess)"]
    end

    subgraph Compiler["svelte/compiler public entry (see compiler_core)"]
        PRE["preprocess()<br/>(this module)"]
        C["compile() / parse()"]
    end

    subgraph Pipeline["Compiler phases (see compiler_parser, compiler_analyzer, ...)"]
        P1["1-parse"]
        P2["2-analyze"]
        P3["3-transform"]
    end

    BP -->|"source + preprocessor groups"| PRE
    PP -->|"implement the PreprocessorGroup contract"| BP
    PRE -->|"Processed: code + combined map + dependencies"| BP
    BP -->|"processed source"| C
    C --> P1 --> P2 --> P3
```

Because preprocessing happens entirely upstream, the parse phase
([compiler_parser](compiler_parser.md)) always receives vanilla HTML/CSS/JS — it never needs to know
about Sass, TypeScript, Pug, etc.

## 3. Architecture Overview

The module is small but precision-engineered around one hard constraint: **every code change must be
traceable back to the original source**. Two implementation files realize this:

- **`index.js` — the preprocessing engine.** Orchestrates preprocessor groups, locates tags,
  splices replacements, and maintains the running source-map chain. Detailed in
  [compiler_preprocess_engine.md](compiler_preprocess_engine.md).
- **`public.d.ts` — the public type contract.** Defines `Processed`, `MarkupPreprocessor`,
  `Preprocessor`, `PreprocessorGroup` and the deprecated `SveltePreprocessor` helper. Detailed in
  [compiler_preprocess_contracts.md](compiler_preprocess_contracts.md).

### 3.1 Component map

```mermaid
flowchart TB
    subgraph PublicAPI["public.d.ts — type contract"]
        PG["PreprocessorGroup<br/>{ name?, markup?, script?, style? }"]
        PROC["Processed<br/>{ code, map?, dependencies?, attributes? }"]
        MP["MarkupPreprocessor"]
        PR["Preprocessor"]
    end

    subgraph Engine["index.js — preprocessing engine"]
        ENTRY["preprocess()<br/>main entry"]
        STATE["PreprocessResult<br/>source · sourcemap_list · dependencies<br/>update_source() · to_processed()"]
        MARKUP["process_markup()<br/>whole-file pass"]
        TAGS["process_tag()<br/>regex scan of &lt;script&gt;/&lt;style&gt;"]
        SINGLETAG["process_single_tag()<br/>per-tag hook invocation"]
        TAG2CODE["processed_tag_to_code()<br/>open tag + content + close tag mapping"]
        CONTENT2CODE["processed_content_to_code()<br/>offset + decode preprocessor map"]
        ATTRS["parse_tag_attributes()<br/>stringify_tag_attributes()"]
    end

    subgraph Support["Supporting utilities (imported)"]
        RIC["replace_in_code / slice_source<br/>(replace_in_code.js)"]
        DECODE["decode_map<br/>(decode_sourcemap.js)"]
        MAPPED["MappedCode · parse_attached_sourcemap ·<br/>sourcemap_add_offset · combine_sourcemaps · get_basename<br/>(../utils/mapped_code.js)"]
        LOC["getLocator<br/>(locate-character)"]
    end

    USER["Consumer (bundler plugin)"] -->|"source + groups"| ENTRY
    PG --> ENTRY
    ENTRY --> STATE
    ENTRY --> MARKUP
    ENTRY --> TAGS
    TAGS --> SINGLETAG
    SINGLETAG -->|"content, attributes, markup, filename"| PR
    PR --> PROC
    MARKUP --> MP
    MP --> PROC
    SINGLETAG --> ATTRS --> TAG2CODE
    SINGLETAG --> CONTENT2CODE
    TAG2CODE --> MAPPED
    CONTENT2CODE --> DECODE --> MAPPED
    ENTRY --> RIC
    RIC --> MAPPED
    STATE --> LOC
    STATE -->|"combine_sourcemaps()"| MAPPED
    STATE -->|"to_processed() → Processed"| USER
```

### 3.2 Internal state: `PreprocessResult`

`PreprocessResult` is the single mutable accumulator threaded through all passes. It implements the
internal `Source` interface (`source`, `filename`, `file_basename`, `get_location`):

- **`source`** — the current (possibly already transformed) markup string.
- **`get_location`** — a `locate-character` locator rebuilt on every `update_source()`, converting
  string indices into `{ line, column }`.
- **`sourcemap_list`** — an **unshifted** (reverse-chronological) list of maps, matching the
  composition order expected by `@jridgewell/remapping`.
- **`dependencies`** — accumulated files to watch, de-duplicated in `to_processed()`.
- **`to_processed()`** — collapses the state into the public `Processed` shape: final code, the
  combined source map, unique dependencies, and a `toString()` alias.

## 4. Preprocessing Pipeline & Data Flow

For every `PreprocessorGroup`, three passes run in fixed order — `markup`, then `script`, then
`style` — each pass operating on the *output* of the previous one:

```mermaid
sequenceDiagram
    participant U as Consumer
    participant E as preprocess()
    participant R as PreprocessResult
    participant M as markup hook
    participant T as script/style hook

    U->>E: preprocess(source, groups, { filename })
    E->>R: new PreprocessResult(source, filename)

    rect rgb(235, 244, 255)
        Note over E,R: Pass 1 — markup (whole file)
        E->>M: { content, filename }
        M-->>E: Processed | void
        E->>R: update_source(string, map?, dependencies?)
    end

    rect rgb(235, 255, 240)
        Note over E,T: Pass 2 — every <script> tag
        E->>T: { content, attributes, markup, filename }
        T-->>E: Processed | void
        E->>E: processed_tag_to_code → MappedCode splice
        E->>R: update_source(string, map?, dependencies?)
    end

    rect rgb(255, 246, 235)
        Note over E,T: Pass 3 — every <style> tag
        E->>T: { content, attributes, markup, filename }
        T-->>E: Processed | void
        E->>E: processed_tag_to_code → MappedCode splice
        E->>R: update_source(string, map?, dependencies?)
    end

    R->>R: to_processed() — combine_sourcemaps(file_basename, sourcemap_list)
    E-->>U: Processed { code, map, dependencies, toString() }
```

Notable behaviors:

- **No-op fast path.** If a hook returns nothing, or returns code identical to the input without a
  map, the original tag is kept verbatim (`process_single_tag`'s `no_change()`).
- **Comment safety.** The tag-scanning regexes (`regex_script_tags` / `regex_style_tags`) skip HTML
  comments, so `<script>` examples inside documentation comments are untouched.
- **Attached `sourceMappingURL`.** If a preprocessor embeds a base64 `//# sourceMappingURL=` data
  URI in its output instead of returning `map`, `parse_attached_sourcemap` extracts it and strips it
  from the code (with a warning if both are present).
- **Attribute rewriting.** `Processed.attributes` returned by a hook replaces the tag's attributes
  (e.g. dropping `lang="ts"` after transpilation). When attributes change length, a synthetic
  high-fidelity source map for the open tag is generated by hand in `processed_tag_to_code`.
- **Offset-aware mapping.** Content maps produced by preprocessors refer to the *tag content* only;
  `processed_content_to_code` locates the segment(s) pointing at the component file (matched via
  `file_basename`) and offsets them to the tag's absolute `{ line, column }` position.

### Source map chain

```mermaid
flowchart LR
    A["original .svelte<br/>file_basename"] -->|"preprocessor map #n"| B["after preprocessor #n"]
    B -->|"preprocessor map #n-1"| C["..."]
    C -->|"offset/splice maps<br/>(MappedCode concat)"| D["final preprocessed code"]
    D -->|"compile()"| E["generated JS/CSS"]
    E -.->|"combined map<br/>(remapping)"| A
```

`combine_sourcemaps` uses `remapping` either with the array interface (when only the oldest map has
multiple sources) or the loader interface, chaining each preprocessor's map back to the original
file so the final `Processed.map` resolves to true original positions.

## 5. Sub-module Documentation

Generated sub-module documentation (files in this directory):

- **[compiler_preprocess_engine.md](compiler_preprocess_engine.md)** — *Preprocessing engine* (`packages/svelte/src/compiler/preprocess/index.js`): the `preprocess` entry point, `process_single_tag` and its surrounding machinery — `PreprocessResult` state tracking, markup/script/style pass orchestration, tag scanning via `regex_script_tags`/`regex_style_tags`, and the source-map splicing helpers (`processed_tag_to_code`, `processed_content_to_code`, attribute parse/serialize).
- **[compiler_preprocess_contracts.md](compiler_preprocess_contracts.md)** — *Public type contracts* (`packages/svelte/src/compiler/preprocess/public.d.ts`): `Processed`, `MarkupPreprocessor`, `Preprocessor`, `PreprocessorGroup`, and the deprecated `SveltePreprocessor` utility type — the stable interface every external preprocessor package implements.

## 6. Usage Example

```js
import { preprocess, compile } from 'svelte/compiler';

const processed = await preprocess(source, [
  {
    name: 'typescript',
    async script({ content, attributes }) {
      if (attributes.lang !== 'ts') return; // no-op fast path
      const { code, map, dependencies } = await tsTranspile(content);
      return { code, map, dependencies, attributes: { ...attributes, lang: null } };
    }
  },
  {
    name: 'sass',
    async style({ content, attributes }) {
      if (attributes.lang !== 'sass') return;
      const { css, map } = await sassRender(content);
      return { code: css, map, attributes: { ...attributes, lang: null } };
    }
  }
], { filename: 'src/App.svelte' });

const result = compile(processed.code, {
  filename: 'src/App.svelte',
  // feed the composed map so diagnostics resolve to the original file
  sourcemap: processed.map
});
```

## 7. Related Modules

- [compiler_core](compiler_core.md) — `svelte/compiler` entry point that re-exports `preprocess`; `compile()` consumes preprocessed sources.
- [compiler_parser](compiler_parser.md) — the parse phase that receives the (already vanilla) preprocessed markup.
- [compiler_migrate](compiler_migrate.md) — sibling source-transformation tooling under *Source Migration & Preprocessing Tooling*.
- [compiler_types](compiler_types.md) — the AST type model produced by the pipeline that follows preprocessing.
