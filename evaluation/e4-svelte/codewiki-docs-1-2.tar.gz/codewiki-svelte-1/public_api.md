# `public_api` — Public API Surface & Compatibility Layer

> The front door of the Svelte package: the modules an application imports directly (`svelte`, `svelte/server`), the type contracts that describe what a compiled component *is*, and the typing hooks consumed by the Svelte language tooling.

---

## 1. Purpose & Scope

Everything else in this repository — the compiler pipeline, the reactive runtime engine, the DOM/SSR renderers — is **internal**. Application developers only ever reach it through the facade documented here. This module has three responsibilities:

1. **Entry-point duality** — expose a single import specifier whose implementation is swapped between a *browser build* (`src/index-client.js`) and an *SSR/default build* (`src/index-server.js`) via export conditions. Both builds expose the same function names, but with environment-appropriate semantics (real implementations vs. no-ops/guards).
2. **Type contracts** — define the stable, public TypeScript interfaces (`src/index.d.ts`) for components, snippets, event dispatchers and mount options — including deliberately shaped *legacy aliases* (`SvelteComponent`, `SvelteComponentTyped`, `ComponentConstructorOptions`, …) that keep Svelte 4 code compiling against Svelte 5.
3. **Editor integration** — provide `svelte-html.d.ts`, a file that is never imported at runtime but is loaded *directly* by the Svelte language server to type-check every HTML/SVG element in component markup.

### What lives here vs. elsewhere

| Concern | File (this module) | Notes |
|---|---|---|
| Browser runtime entry | `packages/svelte/src/index-client.js` | Resolved for the `browser` condition of the root specifier `svelte` |
| SSR/default runtime entry | `packages/svelte/src/index-server.js` | Resolved for the `default` condition of `svelte` (Node/SSR) |
| SSR `render()` entry | `packages/svelte/src/server/index.js` | The dedicated `svelte/server` specifier → `render()` from the internal server runtime |
| Public type contracts | `packages/svelte/src/index.d.ts` | `Component`, `Snippet`, `EventDispatcher`, `MountOptions`, legacy types |
| Editor typing hooks | `packages/svelte/svelte-html.d.ts` | Global `svelteHTML` namespace, `IntrinsicElements` |

---

## 2. Position in the System

```mermaid
flowchart TB
    subgraph APP["Application & ecosystem code"]
        SRC["*.svelte components and<br/>application entry files"]
        TOOLING["Svelte language server /<br/>TypeScript"]
        FRAMEWORKS["Meta-frameworks<br/>(SSR adapters)"]
    end

    subgraph PUB["public_api (this module)"]
        IC["src/index-client.js<br/>browser entry"]
        IS["src/index-server.js<br/>SSR / default entry"]
        SV["src/server/index.js<br/>'svelte/server'"]
        IDT["src/index.d.ts<br/>Component / Snippet / EventDispatcher"]
        HTM["svelte-html.d.ts<br/>svelteHTML.IntrinsicElements"]
    end

    subgraph INTERNAL["Internal engine modules (other wiki pages)"]
        RENDER["client_dom_renderer<br/>mount / hydrate / unmount / createRawSnippet"]
        RUNTIME["client_runtime_core<br/>signals, effects, tick, flushSync, untrack"]
        CTX["context_api<br/>setContext / getContext / hasContext / getAllContexts"]
        SSR["server_runtime<br/>render engine, payload, snippets"]
    end

    SRC -- "browser condition" --> IC
    SRC -- "default condition (SSR)" --> IS
    FRAMEWORKS -- "svelte/server" --> SV
    TOOLING -- "loads directly,<br/>not in the exports map" --> HTM
    TOOLING -- "types via" --> IDT

    IC --> RENDER
    IC --> RUNTIME
    IC --> CTX
    IS --> CTX
    SV --> SSR
    IS -- "throws 'unavailable'" --> RENDER
```

### Export resolution

The package's export map wires the same public *names* to different *implementations* depending on the consuming environment:

```mermaid
flowchart LR
    A["import { mount } from 'svelte'"] --> R["Bundler / runtime resolves<br/>'svelte' export conditions"]
    R -- "browser condition" --> C["src/index-client.js<br/>real client implementations"]
    R -- "default condition" --> S["src/index-server.js<br/>no-ops, stubs and guards"]
    B["import { render } from 'svelte/server'"] --> S2["src/server/index.js<br/>re-exports render from internal/server"]
```

Because `index.d.ts` ends with `export * from './index-client.js'`, the *types* for the runtime functions are shared by both environments — TypeScript users see one consistent surface regardless of target.

---

## 3. Entry-Point Duality (client vs. server)

The two entry files define the **same exported names** with different behavior. This is the mechanism that lets a single component codebase run both in the browser and on the server:

| Exported name | `svelte` (browser → `index-client.js`) | `svelte` (SSR/default → `index-server.js`) |
|---|---|---|
| `onMount` | Runs `fn` once after mount via `user_effect` (untracked); a synchronously returned function becomes teardown | No-op |
| `onDestroy` | Registers teardown through `onMount` | Pushes `fn` onto `current_component.d`, executed when the server render completes |
| `beforeUpdate` / `afterUpdate` | Deprecated; queue into the legacy callback store (`lifecycle_legacy_only` error in runes mode) | No-op |
| `createEventDispatcher` | Deprecated; dispatches `CustomEvent`s to `$$events` handlers, returns `!event.defaultPrevented` | Returns `noop` |
| `getAbortSignal` | Returns an `AbortSignal` bound to the active reaction (`active_reaction.ac`) | Server implementation bound to the render payload |
| `mount` / `hydrate` / `unmount` | Real implementations from `internal/client/render.js` | Throw `lifecycle_function_unavailable` |
| `tick` / `settled` | Scheduler-based implementations from the client runtime | Immediately-resolved `async` functions |
| `untrack` | Real implementation | `run` (executes the callback immediately) |
| `flushSync` | Synchronous batch flush from `internal/client/reactivity/batch.js` | No-op |
| `getContext` / `setContext` / `hasContext` / `getAllContexts` | Client context (map on component context) | Server context (stack in `internal/server/context.js`) |
| `createRawSnippet` | Client snippet wrapper | Server snippet wrapper |

Additional behavior worth knowing:

- **`throw_rune_error` (client entry, DEV only)** — at import time it installs trap properties on `globalThis` for `$state`, `$effect`, `$derived`, `$inspect`, `$props` and `$bindable`. If user code references a rune outside compiled Svelte code (e.g. in a plain `.js` file), reading the global raises the dedicated `rune_outside_svelte` diagnostic instead of an opaque `ReferenceError`.
- **`getAbortSignal` (client)** — must be called while a derived or effect is running; it lazily attaches an `AbortController` to the active reaction so that in-flight `fetch`-style work is aborted when the reaction re-runs or is destroyed. Calling it outside a reaction raises `get_abort_signal_outside_reaction`.

---

## 4. Type Contracts (`src/index.d.ts`)

The root type file defines the *shape* of compiled Svelte artifacts as TypeScript sees them:

- **`Component<Props, Exports, Bindings>`** — the Svelte 5 component model: a component is a **plain function** `(internals: ComponentInternals, props: Props) => exports`. `ComponentInternals` is a *branded* type so user code cannot forge it. An optional `element` static exposes the custom-element class when compiled with `customElement`.
- **`SvelteComponent`** — the legacy Svelte 4 base class, kept for typing only. Its constructor, `$on`, `$set` and `$destroy` are marked as existing *only* through the compatibility helpers of the [legacy_compat](legacy_compat.md) module (`asClassComponent` / `createClassComponent`). Type-only markers `$$prop_def`, `$$events_def`, `$$slot_def` are what generated component typings reference.
- **`SvelteComponentTyped`** — deprecated alias subclass of `SvelteComponent`.
- **`Snippet<Parameters>`** — the type of a `{#snippet}` block. Its return type is deliberately an object whose keys are compiler-error sentences (`'{@render ...} must be called with a Snippet'`), so misuse produces actionable diagnostics; parameters must be a tuple (rest parameters are rejected by a conditional type).
- **`EventDispatcher<EventMap>`** with `DispatchOptions` — the `detail` argument becomes optional exactly when `null`/`undefined` is part of the event's declared type.
- **Utility types** — `ComponentProps`, `ComponentEvents` (deprecated), `ComponentType` (deprecated), `MountOptions`, `Properties` (adds `children?` when a component has a default slot), `ComponentConstructorOptions` (deprecated).
- **Rune globals** — `index.d.ts` imports `./ambient.js`, which declares `*.svelte` module typings and the global rune functions (`$state`, `$derived`, `$effect`, …) that the DEV-time `throw_rune_error` guards protect.

---

## 5. Editor/Tooling Typings (`svelte-html.d.ts`)

This file is *deliberately not exposed through the exports map* — it is loaded directly by the Svelte language server. It declares the global `svelteHTML` namespace containing:

- `mapElementTag` and `createElement` hooks that map a tag name (or `undefined | null` for `<svelte:element>`) to its DOM interface,
- back-compat augmentation interfaces `HTMLAttributes` / `SVGAttributes` (slated for removal in Svelte 6),
- **`IntrinsicElements`**, which extends `SvelteHTMLElements` from the [svelte_element_types](svelte_element_types.md) module and maps every standard HTML and SVG element to its fully typed attribute set, plus an index signature for custom elements.

---

## 6. Runtime Interaction Flows

### Client: `mount` / `unmount` lifecycle

```mermaid
sequenceDiagram
    autonumber
    participant App as Application
    participant API as index-client.js (re-export)
    participant Render as internal/client/render.js
    participant RT as Reactive runtime (client_runtime_core)
    App->>API: mount(Component, { target, props })
    API->>Render: mount()
    Render->>RT: create component context, root effects, bind props
    RT->>RT: render effects build DOM from template and wire signals
    Render-->>App: component exports object
    App->>API: unmount(instance)
    API->>Render: unmount() destroys effects and removes DOM
```

### Server: `render` pipeline

```mermaid
sequenceDiagram
    autonumber
    participant App as Server / meta-framework
    participant SV as svelte/server (src/server/index.js)
    participant SSR as internal/server/index.js (server_runtime)
    App->>SV: render(Component, { props, context })
    SV->>SSR: render()
    SSR->>SSR: render component to strings, collect head content,<br/>queue onDestroy callbacks, build payload
    SSR-->>App: RenderOutput { body, head }
```

In the SSR entry, `onDestroy` callbacks pushed to `current_component.d` run as part of this pipeline — which is why `onDestroy` is the only classic lifecycle hook that executes during server-side rendering.

---

## 7. Sub-module Documentation

Details for each file of this module are documented separately:

### Documentation map

| Sub-module | File | Contents |
|---|---|---|
| Client entry | [public_api_client_entry](public_api_client_entry.md) | `src/index-client.js` — `onMount`, `onDestroy`, `getAbortSignal`, deprecated `createEventDispatcher` / `beforeUpdate` / `afterUpdate`, and the DEV-only `throw_rune_error` rune traps; plus the re-exports of `mount`, `hydrate`, `unmount`, `tick`, `untrack`, `settled`, `flushSync`, the context API and `createRawSnippet`. |
| Server entry | [public_api_server_entry](public_api_server_entry.md) | `src/index-server.js` — the SSR/default stub surface: collecting `onDestroy` callbacks, no-op `onMount` / `flushSync` / `createEventDispatcher`, `untrack` → `run`, immediately-resolved `tick` / `settled`, and `mount` / `hydrate` / `unmount` throwing `lifecycle_function_unavailable`. |
| Type contracts | [public_api_type_contracts](public_api_type_contracts.md) | `src/index.d.ts` — `Component`, `Snippet`, `EventDispatcher`, legacy `SvelteComponent` / `SvelteComponentTyped`, and the `ComponentProps` / `MountOptions` utility types. |
| Editor typing hooks | [public_api_html_typing](public_api_html_typing.md) | `svelte-html.d.ts` — the global `svelteHTML` namespace (`createElement`, `mapElementTag`) and `IntrinsicElements`, consumed directly by the Svelte language server. |

---

## 8. Related Modules

**Sibling sub-modules of the same parent** (public surface extensions — do not re-describe them here):

- [svelte-types](svelte-types.md) — `packages/svelte/types/index.d.ts`, the generated `declare module 'svelte'` type barrel published to TypeScript consumers; aggregates the contracts defined in `src/index.d.ts` plus compile-time types (`CompileResult`, `CompileOptions`, AST nodes).
- [svelte_element_types](svelte_element_types.md) — `packages/svelte/elements.d.ts`, the `SvelteHTMLElements` / `HTMLAttributes` / `AriaAttributes` vocabulary that `svelte-html.d.ts` builds `IntrinsicElements` from.
- [actions_and_attachments](actions_and_attachments.md) — the `svelte/action` contract (`Action<Element, Parameter, Attributes>`) and the `svelte/attachments` runtime (`createAttachmentKey`, `fromAction`), which bridges old-style actions into runes-mode effects.
- [legacy_compat](legacy_compat.md) — `svelte/legacy` (`asClassComponent`, `createClassComponent`, `createBubbler`, …); the reason the deprecated members on `SvelteComponent` exist.

**Internal engine modules that this module depends on:**

- [client_dom_renderer](client_dom_renderer.md) — implements `mount` / `hydrate` / `unmount` and the client `createRawSnippet` re-exported by the client entry.
- [client_runtime_core](client_runtime_core.md) — `tick`, `untrack`, `settled`, the batch `flushSync`, and the signal/effect machinery that `getAbortSignal` and the legacy hooks hook into.
- [context_api](context_api.md) — client and server implementations of `setContext` / `getContext` / `hasContext` / `getAllContexts` re-exported by both entries.
- [server_runtime](server_runtime.md) — the SSR engine behind `svelte/server`'s `render`, the server `createRawSnippet`, the server `getAbortSignal` and the payload model.
- [shared_runtime](shared_runtime.md) — `noop` and `run`, the tiny utilities the server entry uses to stub `onMount`, `flushSync` and `untrack`.

---

## 9. Design Notes

- **One surface, two engines.** The duality table in §3 is the compatibility contract: adding a new public function means adding it to *both* entries (real implementation on the client, correct no-op/guard on the server) and to `index.d.ts`.
- **Errors instead of silence.** The server entry throws (`lifecycle_function_unavailable`) for browser-only operations, and the client entry installs DEV rune traps — both convert *wrong-environment misuse* into clear diagnostics rather than undefined behavior.
- **Types are runtime-shaped.** `Snippet`'s error-message return type and `ComponentInternals` branding show the guiding principle: make incorrect usage a *compile-time* error with a human-readable message.
