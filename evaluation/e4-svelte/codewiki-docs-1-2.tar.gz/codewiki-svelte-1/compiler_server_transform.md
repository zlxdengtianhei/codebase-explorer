# Server Transform (SSR Code Generation) — `compiler_server_transform`

> **Module scope:** `packages/svelte/src/compiler/phases/3-transform/server/**`
>
> This module is the *server-side half* of Svelte's code-generation phase. It rewrites a parsed and analyzed component AST into plain JavaScript that renders the component to an HTML string at request time (Server-Side Rendering). The compiled function streams markup into a `$$payload` accumulator and leaves hydration anchors so the client runtime can later adopt the server-rendered DOM.

---

## 1. Purpose & Position in the Compiler

Svelte compiles in three phases. This module implements the `server` variant of **phase 3**:

```mermaid
flowchart LR
    subgraph FE ["Compiler Front-End"]
        P["1-parse<br/>(compiler_parser)"] --> A["2-analyze<br/>(compiler_analyzer)<br/>scopes · bindings · metadata"]
        A --> CSS["CSS scoping<br/>(compiler_css_pipeline)"]
    end
    subgraph CG ["Phase 3 — Transform"]
        direction TB
        CLI["client transform<br/>(compiler_client_transform)"]
        SRV["<b>server transform</b><br/>(this module)"]
        CSST["CSS transform<br/>(compiler_css_pipeline)"]
    end
    A --> SRV
    A --> CLI
    CSS -->|"scoped css hash"| SRV
    SRV -->|"emits `$.` calls"| RT["svelte/internal/server<br/>(server_runtime module)"]
    CLI -->|"emits internal/client calls"| CRT["svelte/internal/client<br/>(client_dom_renderer)"]
```

Key responsibilities:

- **Template serialization** — walk the template AST and build an ordered list of string chunks and expressions that become `$$payload.out.push(...)` calls.
- **Rune elimination** — server-rendering has no reactivity, so `$state`, `$derived`, `$effect.*`, `$inspect` etc. are rewritten to their static "one-shot" equivalents (plain values, `$.derived(...)`, no-ops, …).
- **Legacy-mode compatibility** — `export let` props, `$:` reactive statements and `$store` auto-subscriptions get their SSR equivalents.
- **Hydration protocol** — control-flow blocks emit marker comments (`<!>`, `<!---->`) defined by `internal/server/hydration.js`, so the client transform's output can reclaim the markup on hydration.
- **Dev-mode instrumentation** — element tracking (`$.push_element`/`$.pop_element`) and snippet-argument validation under `dev` flag.

For the interactive half (DOM creation, effects, event handling), see [compiler_client_transform](compiler_client_transform.md).

---

## 2. Architecture Overview

The server transform is a **visitor-based tree transformation** built on the [`zimmerframe`](https://github.com/Rich-Harris/zimmerframe) walker — the same traversal machinery the client transform uses. Each AST node type has a dedicated visitor file in `visitors/`, exporting a function named after the node type (e.g. `IfBlock`, `RegularElement`).

```mermaid
flowchart TB
    subgraph Entry ["Entry points — server/index.js"]
        SC["server_component(node)"]
        SR["server_root(node)"]
    end
    subgraph Walk ["zimmerframe traversal"]
        CTX["Context<br/>· context.visit(node, state)<br/>· context.next()<br/>· context.path"]
        VM["visitor map — one handler per AST node type"]
    end
    subgraph Groups ["Visitor groups (sub-modules)"]
        PIPE["Pipeline &amp; shared utils"]
        CF["Control-flow blocks"]
        EL["Elements &amp; attributes"]
        CO["Components &amp; snippets"]
        JS["JavaScript semantics"]
    end
    subgraph StateModel ["ComponentServerTransformState (accumulators)"]
        INIT["init[ ]<br/>one-off statements:<br/>consts, snippet fns, hoisted nodes"]
        TPL["template[ ]<br/>ordered output chunks:<br/>literals / expressions / stmts"]
        META["scope · analysis · namespace<br/>preserve_whitespace"]
    end
    subgraph Out ["Generated component body"]
        FLUSH["build_template() coalesces<br/>template[ ] into push statements"]
        CODE["function App($$payload, $$props) {<br/>  ...init...<br/>  $$payload.out.push(`...${expr}...`);<br/>}"]
        RUNTIME["$. runtime functions<br/>(server_runtime module)"]
    end
    SC --> SR --> CTX --> VM
    VM --> PIPE & CF & EL & CO & JS
    PIPE & CF & EL & CO & JS --> INIT
    PIPE & CF & EL & CO & JS --> TPL
    META -.->|"scope.evaluate() folds<br/>static expressions into strings"| TPL
    INIT --> CODE
    TPL --> FLUSH --> CODE
    CODE --> RUNTIME
```

### 2.1 The state model

Visitors rarely generate output directly; instead they **append to two accumulators** carried through `context.state`:

| Accumulator | Purpose | Flushed by |
|---|---|---|
| `state.template` | Ordered render output: string `Literal`s (`<div`), `TemplateLiteral`s, expressions, and full statements (e.g. `if`, calls). | `build_template()` → `$$payload.out.push(...)` statements |
| `state.init` | One-time setup per render: declarations, snippet function declarations, hoisted `{@const}`/`{#snippet}`/`<svelte:head>` content. | Emitted before the template statements in the component body |

Supporting state fields: `scope` (bindings + `evaluate()` for compile-time-known expressions), `analysis` (`ComponentAnalysis`: `runes`, `classes`, `state_fields`, `css.hash`, `uses_slots`, `name`), `namespace` (`html`/`svg`/`mathml`), `preserve_whitespace`, `preserve_comments` and `skip_hydration_boundaries`. `Fragment` and `RegularElement` clone the state with fresh `template`/`init` arrays to scope nested output.

### 2.2 Runtime contract (`$$payload` + `$.` helpers)

Generated code never touches the DOM. It calls helpers from `svelte/internal/server` (documented in [server_runtime](server_runtime.md)):

| Construct in source | Generated server code | Visitor |
|---|---|---|
| `{#if}` | `if (…) { $$payload.out.push('<!>'); … } $$payload.out.push('<!---->')` | [IfBlock](#3-sub-modules) |
| `{#each}` | `$.ensure_array_like` + `for` loop + `<!>`/`<!---->` markers | [EachBlock](#3-sub-modules) |
| `{#await}` | `$.await($$payload, expr, pending_thunk, then_arrow)` | [AwaitBlock](#3-sub-modules) |
| `{#key}` | `<!---->` anchored fragment | [KeyBlock](#3-sub-modules) |
| `<svelte:boundary>` | `<!>` + pending-snippet render + `<!---->` | [SvelteBoundary](#3-sub-modules) |
| `<div …>` | literal open tag + `$.attr`/`$.clsx`/`$.spread_props` + children + `</div>` | [RegularElement](#3-sub-modules) |
| `<svelte:element>` | `$.element($$payload, tag, attrs_thunk, children_thunk)` | [SvelteElement](#3-sub-modules) |
| `{@html}` | `$.html(expr)` | [HtmlTag](#3-sub-modules) |
| `<svelte:head>` | `$.head($$payload, ($$payload) => {…})` | [SvelteHead](#3-sub-modules) |
| `<title>` | `$$payload.title = '<title>…</title>'` | [TitleElement](#3-sub-modules) |
| `<slot>` | `$.slot($$payload, $$props, name, props, fallback_thunk)` | [SlotElement](#3-sub-modules) |
| `<Foo …/>` | `Foo($$payload, { props, $$slots })` (+ `$.css_props` wrapper for `--custom` props) | [Component](#3-sub-modules) |
| `{@render foo(x)}` | `foo($$payload, x)` | [RenderTag](#3-sub-modules) |
| `{#snippet foo(x)}` | hoisted `function foo($$payload, x) {…}` | [SnippetBlock](#3-sub-modules) |
| `let x = $state()`, `$derived` | plain declarator / `$.derived(thunk)` | [VariableDeclaration](#3-sub-modules) |
| `let { a = 1 } = $props()` / `export let a = 1` | destructuring from `$$props` with fallbacks | [VariableDeclaration](#3-sub-modules) |
| `$store` reads / writes / `++` | `$.store_get` / `$.store_set` / `$.store_mutate` / `$.update_store(_pre)` | [Identifier](#3-sub-modules), [AssignmentExpression](#3-sub-modules), [UpdateExpression](#3-sub-modules) |
| `$state()` in expressions, `$effect.*`, `$inspect` | value passthrough / no-ops / `$.derived` / `$.snapshot` / `transform_inspect_rune` | [CallExpression](#3-sub-modules) |
| class fields with runes (`#`-private `$derived`) | backing field + getter/setter pair, `this.#x()` calls | [ClassBody](#3-sub-modules), [PropertyDefinition](#3-sub-modules), [MemberExpression](#3-sub-modules) |
| `$:` (legacy) | collected as labeled `$` statements for topological ordering | [LabeledStatement](#3-sub-modules) |

**Hydration markers** (`block_open` = `<!>`, `block_close` = `<!---->`, `empty_comment` = `<!---->`, from `internal/server/hydration.js`) are pure string literals in the output — the runtime (via `hydrate_template` in [client_dom_renderer](client_dom_renderer.md)) later uses them to align client rendering with server markup.

### 2.3 Worked example (simplified)

```svelte
<!-- App.svelte -->
<script>
        let { name = 'world' } = $props();
</script>

{#if name}
        <h1>Hello {name}!</h1>
{:else}
        <h1>Hello!</h1>
{/if}
```

is compiled (conceptually, eliding details) by `VariableDeclaration` + `IfBlock` + `process_children` into:

```js
export function App($$payload, $$props) {
        $$payload.out += `<!>`;
        {
                const { name: name = 'world' } = $$props;      // $props → $$props (VariableDeclaration)
                if (name) {
                        $$payload.out.push(`<!> <h1>Hello `);       // block_open (IfBlock)
                        $$payload.out.push(`${$.escape(name)}!`);   // process_children → escape
                        $$payload.out.push(`</h1>`);                // closing tag literal
                } else {
                        $$payload.out.push(`<!><h1>Hello!</h1>`);
                }
                $$payload.out.push(`<!---->`);                  // block_close
        }
}
```

> The exact emitted statements are coalesced into as few `push` calls as possible — see [compiler_server_transform_pipeline](compiler_server_transform_pipeline.md).

---

## 3. Sub-modules

The module is organized into five cohesive sub-modules (each documented in its own file):

| Sub-module | Contents | Responsibility |
|---|---|---|
| [**compiler_server_transform_pipeline**](compiler_server_transform_pipeline.md) | `Fragment`, `shared/utils.js` (`process_children`, `build_template`, `build_attribute_value`, `build_getter`), `clean_nodes` | The rendering pipeline core: fragment processing, node cleaning/hoisting, whitespace policy, text/expression batching into template literals, attribute value serialization |
| [**compiler_server_transform_control_flow**](compiler_server_transform_control_flow.md) | `IfBlock`, `EachBlock`, `AwaitBlock`, `KeyBlock`, `SvelteBoundary`, `ConstTag`, `DebugTag` | Branching, iteration, async rendering (`{#await}` / `<svelte:boundary>` pending UI), error isolation, inline declarations & debugging aids |
| [**compiler_server_transform_elements**](compiler_server_transform_elements.md) | `RegularElement`, `SvelteElement`, `HtmlTag`, `TitleElement`, `SvelteHead`, `SlotElement`, `SvelteFragment`, `SpreadAttribute` + `shared/element.js` (`build_element_attributes`, `build_spread_object`) | Everything that emits HTML tags/attributes: static & dynamic elements, select/option & textarea special cases, raw HTML, head content, slot outlets |
| [**compiler_server_transform_components**](compiler_server_transform_components.md) | `Component`, `SvelteComponent`, `SvelteSelf`, `RenderTag`, `SnippetBlock` + `shared/component.js` (`build_inline_component`) | Inline components, dynamic components/self-references, snippet definition & invocation, slot/children serialization (`$$slots`, `children` prop interop) |
| [**compiler_server_transform_javascript**](compiler_server_transform_javascript.md) | `VariableDeclaration`, `Identifier`, `AssignmentExpression`, `UpdateExpression`, `CallExpression`, `ExpressionStatement`, `LabeledStatement`, `AwaitExpression`, `ClassBody`, `PropertyDefinition`, `MemberExpression` | JS-level semantics: runes → static values, props/state/store rewrites, class field desugaring, legacy `$:` handling, `await` placement validation |

Dependency relationships among the sub-modules:

```mermaid
flowchart TD
    JS["compiler_server_transform_javascript<br/>(runes, stores, classes)"] --> PIPE["compiler_server_transform_pipeline<br/>(Fragment, process_children,<br/>build_template, build_getter)"]
    EL["compiler_server_transform_elements"] --> PIPE
    EL -->|"build_inline_component<br/>for shared attribute helpers"| CO
    CO["compiler_server_transform_components"] --> PIPE
    CF["compiler_server_transform_control_flow"] --> PIPE
    CO --> EL
    CF --> CO
    CF --> EL
```

*Note:* direction of arrows is "depends on / delegates to". Practically, all groups lean on the pipeline utilities; element, component and control-flow visitors frequently recurse into each other through `context.visit` as fragments nest.

---

## 4. How This Module Fits Into the System

**Inputs** (from [compiler_analyzer](compiler_analyzer.md) and [compiler_css_pipeline](compiler_css_pipeline.md)):
- the annotated AST — `node.metadata` carries per-node analysis results (`expression` dependencies, `scoped` CSS flags, `scopes`, `dynamic`, `can_hoist`, …);
- `ComponentAnalysis` — rune mode flag, `classes`/`state_fields` (for class transforms), CSS `hash` (appended to `class` attributes for scoping), `uses_slots`;
- `Scope` tree — binding kinds (`state`, `derived`, `store_sub`, `bindable_prop`, …) that drive `Identifier`/`VariableDeclaration`/`AssignmentExpression` rewriting, plus `scope.evaluate()` used by `process_children` to fold static expressions directly into output strings.

**Support libraries** (from [compiler_core](compiler_core.md)):
- `#compiler/builders` (`b.*`) — ESTree node factories used to synthesize every emitted statement/expression;
- shared `visit_assignment_expression` logic (`3-transform/shared/assignments.js`) and `clean_nodes`/`infer_namespace`/`determine_namespace_for_children` (`3-transform/utils.js`).

**Outputs**: a module whose default export is a server component function `( $$payload, $$props ) => void`. It is consumed by `svelte/server`'s `render`/`mount` pipeline ([public_api](public_api.md)), which feeds a `Payload` object whose `.out` array the generated code pushes into. The runtime helpers it calls live in [server_runtime](server_runtime.md).

**Contract with the client transform** ([compiler_client_transform](compiler_client_transform.md)): hydration marker literals (`<!>`, `<!---->`, `<!---->`) must be emitted at exactly matching positions so `hydrate_template` can reclaim blocks. `skip_hydration_boundaries` (set by `Fragment` for standalone single-child fragments, e.g. `{#if x}<Foo/>{/if}`) suppresses redundant anchors.

```mermaid
sequenceDiagram
    participant SSR as Server (Node/edge)
    participant Gen as Generated component fn
    participant RT as svelte/internal/server
    participant CL as Client runtime (hydrate)
    SSR->>Gen: App($$payload, $$props)
    Gen->>RT: $.escape / $.attr / $.derived / $.store_get ...
    Gen->>SSR: $$payload.out.push('<!> <h1>Hello …')
    SSR-->>SSR: join payload.out → HTML string
    SSR-->>CL: HTML + data
    CL->>CL: hydrate_template walks markers<br/>(<!>, <!---->) to claim DOM nodes
```

---

## 5. Cross-cutting Behaviors

- **Whitespace & comment policy** — `clean_nodes` trims insignificant whitespace (with exceptions for `<pre>`, `<textarea>`, `<select>`-family parents and SVG `<text>`), drops comments unless `preserveComments`, hoists non-rendering nodes (`{@const}`, `{@debug}`, snippets, `<svelte:head>`, `<title>`, …) ahead of the template, and decides `is_standalone` / `is_text_first` to minimize hydration anchors.
- **Escaping** — all interpolated text goes through `$.escape`; static text is pre-escaped at compile time (`escape_html` in the pipeline utils); attribute literals are pre-escaped inline; component props use `$.stringify` instead.
- **Dev-mode only code** — `$.push_element`/`$.pop_element` (element stack for nicer errors), `$.validate_snippet_args`, `$.prevent_snippet_stringification`, `$.validate_dynamic_element_tag` / `$.validate_void_dynamic_element`. Guarded by the `dev` compiler state flag from [compiler_core](compiler_core.md).
- **`await` discipline** — top-level `await` is only meaningful inside `<svelte:boundary>`-gated async rendering; `AwaitExpression` compiles illegal placements to `$.await_outside_boundary()` (a runtime error stub).

---

## 6. Related Modules

- [compiler_parser](compiler_parser.md) — produces the initial AST this module consumes (after analysis).
- [compiler_analyzer](compiler_analyzer.md) — scopes, binding kinds and metadata that drive every rewrite decision here.
- [compiler_client_transform](compiler_client_transform.md) — the sibling client-side code generator; shares the visitor structure, zimmerframe traversal, and hydration-marker protocol.
- [compiler_css_pipeline](compiler_css_pipeline.md) — CSS scoping hash consumed when emitting `class` attributes.
- [server_runtime](server_runtime.md) — the `$.` helper implementations and hydration constants invoked by generated code.
- [public_api](public_api.md) — `svelte/server` entry points that execute compiled server components.
