# Motion & Visual Effects System

## Purpose

The `Motion___Visual_Effects_System` module provides Svelte's client-side animation primitives, split into two complementary layers:

1. **Motion value interpolation** (`packages/svelte/src/motion`) — store-based animated values (`spring` and `tweened`) that smoothly interpolate toward a target value over time. These are writable stores driven by a `requestAnimationFrame` loop, so any consumer that can read a store (bindings, styles, SVG attributes) can be animated.
2. **Transitions & animations** (`packages/svelte/src/transition`) — declarative effect functions used with the `transition:`, `in:`, `out:` and `animate:` directives. It ships the built-in CSS/JS transitions (`fade`, `fly`, `slide`, `scale`, `draw`, `blur`, `crossfade`), the `flip` function for animating layout position changes (First-Last-Invert-Play), and the shared **easing** function library used by both layers.

Together they turn discrete state changes into continuous, time-based visual effects, while delegating scheduling and reactivity to the surrounding runtime systems.

## Architecture

```mermaid
flowchart LR
    subgraph Motion["motion (packages/svelte/src/motion)"]
        SPRING[spring]
        TWEENED[tweened]
    end

    subgraph Transition["transitions_and_animations (packages/svelte/src/transition)"]
        EASING[easing]
        BUILTIN[built-in transitions<br/>fade, fly, slide, scale, draw, blur, crossfade]
        FLIP[flip]
    end

    subgraph Platform["Supporting platform systems"]
        RT["Reactive Runtime Engine<br/>(signals, effects, rAF scheduling)"]
        DOMR["Client DOM Renderer<br/>(element lifecycle & blocks)"]
        STORES["Reactive State Primitives<br/>(writable store contract)"]
    end

    EASING --> SPRING
    EASING --> TWEENED
    EASING --> BUILTIN
    FLIP --> BUILTIN

    SPRING --> STORES
    TWEENED --> STORES
    STORES --> RT
    RT --> DOMR
    BUILTIN --> DOMR
    FLIP --> DOMR
```

### Data flow — motion values

`spring()` and `tweened()` behave like stores: writes set a target, and an internal animation loop emits interpolated values frame by frame until settled.

```mermaid
sequenceDiagram
    participant U as User code
    participant S as spring()/tweened() store
    participant L as rAF animation loop
    U->>S: set(target, options)
    S->>L: start ticking
    loop each animation frame
        L->>S: advance time
        S->>S: compute interpolated value<br/>(spring physics / easing + duration)
        S-->>U: store notification with new value
    end
    L->>S: stop when settled
```

### Data flow — transitions & FLIP

Transition functions are invoked by the client DOM renderer at element lifecycle boundaries. They return either a CSS `@keyframes`/inline-style payload (executed via the Web Animations API) or a `tick` callback driven by the easing curve. `flip()` instead measures the element's position delta between renders and inverts it with a transform, then plays it back to zero.

```mermaid
sequenceDiagram
    participant R as Client DOM Renderer
    participant T as transition/animate fn
    participant W as Web Animations API / tick
    R->>T: call fn(node, params) on intro/outro/keyed change
    T->>T: apply easing curve, compute keyframes or flip delta
    T->>W: play animation (css or js mode)
    W-->>R: completion → commit intro/resolve outro
```

## Core Components

| Component | Description | Documentation |
|---|---|---|
| `motion` | Interpolating `spring` and `tweened` store primitives with configurable stiffness/damping or duration/easing, plus shared easing utilities | [Motion (spring & tweened)](<motion.md>) |
| `transitions_and_animations` | Built-in transition functions, the `flip` layout animation, and the easing library powering all time-based effects | [Transitions & Animations](<transitions_and_animations.md>) |

## Relationship to Other Modules

- **Client DOM Renderer** — triggers intro/outro transitions and `flip` animations from its element/blocks lifecycle; transitions must cooperate with outro deferral and block teardown.
- **Reactive Runtime Engine** — motion stores piggyback on the effect/`requestAnimationFrame` scheduling so values update within the normal reactivity model.
- **Reactive State Primitives & Store Interop** — `spring`/`tweened` implement the standard store contract, making them usable with `$value` auto-subscriptions and bindings.
- **Easing** (in `transitions_and_animations`) is deliberately shared: the same curve library drives both motion interpolation and CSS/JS transitions.