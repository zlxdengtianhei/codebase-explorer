# svelte_build_tooling

## Overview

`svelte_build_tooling` is the repository-engineering tooling layer that lives in `packages/svelte/scripts`. It does not ship to end users, but it guards two of the most important quality properties of the published Svelte package:

1. **Tree-shaking guarantee** — every entry point listed in `package.json > exports` must compile down to an *empty* bundle when nothing is imported from it, and the bundle produced by a feature-complete component must not contain hydration, legacy-mode, or `$inspect.trace` code. This is enforced by `scripts/check-treeshakeability.js`.
2. **Single-source-of-truth diagnostics** — every compile error, compile warning, and runtime error/warning message is authored once as Markdown under `packages/svelte/messages/<category>/` and stamped into templated function factories under `scripts/process-messages/templates/`. The `scripts/process-messages/index.js` driver combines both into the generated diagnostic modules (`src/compiler/errors.js`, `src/compiler/warnings.js`, `src/internal/*/errors.js`, `src/internal/*/warnings.js`) and the generated API-reference documentation pages.

Because both tools are wired into the build/CI pipeline (`rollup.config.js` even side-effect-imports sibling script `generate-version.js`), a regression in tree-shaking or a malformed diagnostic message fails the build instead of silently shipping dead code or broken error text.

> **Scope note:** the message *driver* (`process-messages/index.js`) is documented here for context; the code components owned by this module are the **treeshakeability checker** and the seven **message templates** that act as codegen blueprints.

## Architecture

The module contains two independent toolchains that share nothing at runtime but both feed the build:

```mermaid
flowchart LR
    subgraph Sources
        MSG[packages/svelte/messages/&lt;category&gt;/*.md]
        TPL[scripts/process-messages/templates/*.js<br/>CODE / MESSAGE / PARAMETER placeholders]
    end

    subgraph Codegen [Diagnostic Codegen]
        PM[scripts/process-messages/index.js<br/>acorn parse → zimmerframe walk → esrap print]
    end

    subgraph Generated [Generated Modules — do not edit]
        CE[src/compiler/errors.js]
        CW[src/compiler/warnings.js]
        CRTE[src/internal/client/errors.js]
        CRTW[src/internal/client/warnings.js]
        SE[src/internal/server/errors.js]
        SHE[src/internal/shared/errors.js]
        SHW[src/internal/shared/warnings.js]
        DOC[documentation/docs/98-reference/.generated/*.md]
    end

    MSG --> PM
    TPL --> PM
    PM --> CE & CW & CRTE & CRTW & SE & SHE & SHW
    PM --> DOC
```

```mermaid
flowchart LR
    subgraph Checker [Tree-shakeability Checker]
        PKG[package.json exports]
        BC[bundle_code<br/>rollup + virtual + node-resolve]
        CB[check_bundle<br/>forbidden-symbol grep]
        C[compile<br/>feature-complete .svelte fixture]
        OUT[scripts/_bundle.js on failure]
    end

    PKG --> BC
    C --> BC
    BC --> CB
    CB -->|failure| OUT
    CB -->|failure| EXIT[process.exit&#40;1&#41;]
```

### Component map

| Tool | File | Core components | Purpose |
| --- | --- | --- | --- |
| Tree-shakeability checker | `packages/svelte/scripts/check-treeshakeability.js` | `bundle_code`, `check_bundle` | Verifies every public export tree-shakes to nothing and that hydration/legacy/inspect code is prune-able |
| Diagnostic templates | `packages/svelte/scripts/process-messages/templates/*.js` (7 files) | `CODE` (placeholder function) | AST blueprints from which the concrete `error(...)` / `warning(...)` functions are generated |

### Data flow through the module

```mermaid
sequenceDiagram
    participant Dev as Developer
    participant PM as process-messages/index.js
    participant MD as messages/**/*.md
    participant T as templates/*.js
    participant Gen as generated src/** modules
    participant CI as check-treeshakeability.js

    Dev->>MD: edits/creates message docs
    Dev->>T: adjusts placeholder template (rare)
    PM->>MD: parse ## code sections, %var% placeholders
    PM->>T: acorn parse → transform CODE/MESSAGE/CODES nodes
    PM->>Gen: print + write errors.js / warnings.js + docs pages
    CI->>Gen: bundles public exports via rollup
    CI->>CI: greps bundle for forbidden symbols
    CI-->>Dev: ✅ per export / ❌ + scripts/_bundle.js + exit 1
```

## Sub-modules

### [svelte_build_tooling_treeshakeability_checker](svelte_build_tooling_treeshakeability_checker.md)

The Rollup-based bundle audit tool (`check-treeshakeability.js`). It:

- Bundles **every** entry point declared in `package.json > exports` (skipping `./compiler` and internal flag entries) for both `browser` and `default` conditions, and requires the result to be an **empty bundle** (`bundle_code`).
- Resolves bare `svelte/*` imports through a custom Rollup plugin that maps them onto the package's own `exports` table, so the check always audits the *local* sources.
- Compiles a synthetic `App.svelte` fixture that exercises every hydration-relevant template feature (`bind:`, spread attributes, `{#if}/{#each}/{#await}/{#key}`, snippets, `{@render}`, `{@html}`, `<svelte:component|element|head>`, components) with `mount()` from the browser entry.
- Greps the resulting bundle for symbols that must be tree-shaken away — `hydrate_node` / `hydrate_next` (hydration), `component_context.l` (legacy mode), `'CreatedAt'` (`$inspect.trace`) — via `check_bundle`, printing a ±500-character context window around the first offending line and dumping the full bundle to `scripts/_bundle.js` for debugging.
- Fails the process (`exit 1`) when any check trips, making it CI-safe.

See [svelte_build_tooling_treeshakeability_checker.md](svelte_build_tooling_treeshakeability_checker.md) for the detailed walkthrough.

### [svelte_build_tooling_message_templates](svelte_build_tooling_message_templates.md)

The seven template files under `scripts/process-messages/templates/` that define the *shape* of generated diagnostics. Each template exports a single placeholder function `CODE(PARAMETER)` (or `CODE(node, PARAMETER)` for compiler categories) whose body contains the `MESSAGE` placeholder and, in the compile categories, the diagnostic plumbing (`InternalCompileError` extending `Error` via `CompileDiagnostic`, `InternalCompileWarning` honoring `svelte-ignore` via `ignore_stack`/`ignore_map`/`warning_filter`, and the `codes` export fed by the `CODES` placeholder). Template families:

- **compile-errors / compile-warnings** → `src/compiler/errors.js` / `src/compiler/warnings.js` (node-aware, position-carrying diagnostics)
- **client-errors / client-warnings** → `src/internal/client/*` (`DEV`-gated via `esm-env`, re-export shared messages)
- **server-errors** → `src/internal/server/errors.js` (always full-message throws; SSR has no dev/prod split)
- **shared-errors / shared-warnings** → `src/internal/shared/*` (single definition reused by client and server)

See [svelte_build_tooling_message_templates.md](svelte_build_tooling_message_templates.md) for the detailed walkthrough.

## Relationship to other modules

This tooling sits *around* the compiler and runtime rather than inside them:

- **`compiler_diagnostics`** — the generated `src/compiler/errors.js` and `src/compiler/warnings.js` (produced from the compile templates) are the primary consumers of `utils/compile_diagnostic.js` (`CompileDiagnostic`, `get_code_frame`). Any new compile diagnostic starts as a Markdown message + template regeneration, not a hand edit.
- **`client_runtime_core` / `server_runtime` / `shared_runtime`** — the generated `src/internal/{client,server,shared}/{errors,warnings}.js` modules provide the throwing/warning functions those runtimes call (e.g. `bind_not_bindable`, `invalid_default_snippet`).
- **`public_api`** — the checker iterates exactly the export map that `packages/svelte/src/index-client.js` / `index-server.js` back, so API-surface changes must keep both the exports table *and* tree-shakeability green.
- **Compiler front-end** — the checker drives the compiler itself (`compile(...)` on the synthetic fixture), so compiler regressions that leak runtime code into production bundles are caught here.

```mermaid
flowchart TB
    subgraph svelte_build_tooling
        CHK[treeshakeability checker]
        TPL[message templates]
    end

    subgraph consumed_modules
        DIAG[compiler_diagnostics<br/>CompileDiagnostic / state]
        FE[Compiler front-end<br/>compile&#40;&#41;]
        PUB[public_api entries<br/>index-client / index-server]
        RT[client / server / shared runtimes]
    end

    TPL -->|generates errors.js + warnings.js| DIAG
    TPL -->|generates runtime diagnostics| RT
    FE -->|compiled fixture bundle| CHK
    PUB -->|exports map| CHK
```

## Usage

```bash
# Regenerate all diagnostic modules + reference docs (watch mode available)
pnpm --filter svelte process-messages           # node scripts/process-messages/index.js [-w]

# Audit tree-shaking (run after build; exits non-zero on failure)
node packages/svelte/scripts/check-treeshakeability.js
```

**Conventions enforced by this tooling**

- Generated files start with `/* This file is generated by scripts/process-messages/index.js. Do not edit! */` — edit the Markdown messages or the templates instead.
- Every message code maps to a documentation URL `https://svelte.dev/e/<code>`, so codes are part of the public contract and must never be renamed casually (the codegen rejects duplicates across categories).
- Runtime error functions return `never`; compiler diagnostics carry `[start, end]` positions derived from the AST node passed in.
