# compiler_analyzer_block_visitors

## Overview

`compiler_analyzer_block_visitors` is the set of **semantic-analysis visitors for Svelte's control-flow blocks** — `{#if}`, `{:else if}`, `{#each}`, `{#await}`, `{:then}`, `{:catch}`, `{#key}` — plus the JavaScript `await` expression. It lives in `packages/svelte/src/compiler/phases/2-analyze/visitors/` and is dispatched by the analyzer's AST walk (Phase 2 of the compiler pipeline).

Each visitor answers three questions about the block it sees:

1. **Is it valid?** — structural validation (non-empty branches, well-formed `{#`/`{:` opening delimiters) that produces compile errors and warnings.
2. **Is it dynamic?** — marking every enclosing `Fragment` as `dynamic`, which tells the renderers that this subtree needs reactive effects instead of a static template.
3. **What does it depend on?** — populating per-node `metadata` (expression dependencies, `has_await`, keyed-ness, legacy transitive dependencies) that Phase 3 transforms consume to generate client/server code.

| File | Component | Handles |
|---|---|---|
| `visitors/IfBlock.js` | `IfBlock` | `{#if}`, `{:else if}`, `{:else}` |
| `visitors/EachBlock.js` | `EachBlock`, `collect_transitive_dependencies` | `{#each}` iteration blocks |
| `visitors/AwaitBlock.js` | `AwaitBlock` | `{#await}` / `{:then}` / `{:catch}` |
| `visitors/KeyBlock.js` | `KeyBlock` | `{#key}` |
| `visitors/AwaitExpression.js` | `AwaitExpression` | `await` in scripts and template expressions |

The module is a child of [compiler_analyzer](compiler_analyzer.md); it cooperates closely with [compiler_analyzer_scope](compiler_analyzer_scope.md) (scopes/bindings), and feeds [compiler_client_transform](compiler_client_transform.md) and [compiler_server_transform](compiler_server_transform.md).

---

## Position in the Compiler Pipeline

The module runs **after parsing** and **before code generation**. The parser ([compiler_parser](compiler_parser.md)) produces the AST; the analyzer walks it with the `zimmerframe` walker, dispatching to a visitor per node type and switching scopes between nodes via `set_scope` (see [compiler_analyzer_scope](compiler_analyzer_scope.md)). Block visitors read no global configuration directly — everything arrives through the shared `context`/`state` object — and they never mutate the AST shape; they only annotate `metadata` and emit diagnostics.

```mermaid
sequenceDiagram
    participant Parser as Phase 1 — Parse (compiler_parser)
    participant Walk as Phase 2 — Analyzer walk
    participant BV as Block visitors (this module)
    participant Scope as compiler_analyzer_scope
    participant Diag as compiler_diagnostics
    participant Xform as Phase 3 — Transforms

    Parser->>Walk: AST + raw source
    Walk->>Scope: set_scope per node (scope switching)
    Walk->>BV: dispatch visitor for block node type
    BV->>Scope: scope.get(name) binding lookups
    BV->>Diag: errors (block_unexpected_character, ...) / warnings (block_empty)
    BV->>Walk: context.visit(child nodes) — recursion
    BV-->>Walk: node.metadata annotations
    Walk->>Xform: analysis result (metadata, bindings, dynamics)
```

---

## Architecture

```mermaid
flowchart TB
    subgraph P2["Phase 2 — Analyze"]
        W["Analyzer walk<br/>(zimmerframe Context: visit / next / path / state / scope)"]

        subgraph BV["compiler_analyzer_block_visitors"]
            IF["IfBlock"]
            EA["EachBlock<br/>+ collect_transitive_dependencies"]
            AW["AwaitBlock"]
            KY["KeyBlock"]
            AX["AwaitExpression"]
        end

        SHU["visitors/shared/utils.js<br/>validate_opening_tag<br/>validate_block_not_empty"]
        SHF["visitors/shared/fragment.js<br/>mark_subtree_dynamic"]
        TPL["compiler_analyzer_template_visitors<br/>(fragment / element / directive visitors)"]
        JSV["compiler_analyzer_js_visitors<br/>(Identifier / CallExpression / ...)"]
        SCOPE["compiler_analyzer_scope<br/>Scope · Binding · set_scope"]
    end

    subgraph DIAG["compiler_diagnostics"]
        E["errors.js<br/>block_unexpected_character<br/>state_invalid_placement<br/>experimental_async<br/>legacy_await_invalid"]
        Wn["warnings.js<br/>block_empty"]
    end

    subgraph P3["Phase 3 — Transform"]
        CT["compiler_client_transform"]
        ST["compiler_server_transform"]
    end

    W --> BV
    W --> TPL
    W --> JSV
    W --> SCOPE
    IF --> SHU
    EA --> SHU
    AW --> SHU
    KY --> SHU
    IF --> SHF
    EA --> SHF
    AW --> SHF
    KY --> SHF
    SHU --> E
    SHU --> Wn
    AW --> E
    EA --> E
    AX --> E
    BV -- "reads Scope / Binding" --> SCOPE
    JSV -- "accumulate deps into metadata.expression" --> BV
    BV -- "node metadata + Fragment.metadata.dynamic" --> CT
    BV -- "node metadata + Fragment.metadata.dynamic" --> ST
```

### The visitor contract

All components share the same shape: `function Visitor(node, context)`, where `context` is a `zimmerframe` Context providing:

- `context.visit(node, state?)` — recurse into a child node with an optionally overridden state;
- `context.next()` — continue default traversal of children;
- `context.path` — array of ancestor nodes (used by `mark_subtree_dynamic` and the `ConstTag` check);
- `context.state` — the shared analysis state (`analysis.runes`, `analysis.source`, `options`, `ast_type`, `function_depth`, `scope`, `expression`, `fragment`, ...).

Two state-passing conventions are central to this module:

- **Expression tracking**: when a visitor visits a block's *test/expression* node it spreads `{ ...context.state, expression: node.metadata.expression }`. Nested visitors (mostly in [compiler_analyzer_js_visitors](compiler_analyzer_js_visitors.md)) then accumulate `dependencies` and `has_await` onto that `ExpressionMetadata` object.
- **Scope switching**: scope changes between nodes are handled generically by `set_scope` in [compiler_analyzer_scope](compiler_analyzer_scope.md). The one exception is `EachBlock`, which deliberately evaluates its list expression in the **parent** scope (see below).

---

## Component Reference

### `IfBlock` — `{#if}` / `{:else if}` / `{:else}`

1. Validates that `consequent` and `alternate` branches are not whitespace-only (`validate_block_not_empty`, warning `block_empty`; null branches are skipped).
2. In **runes mode** only, validates the opening delimiter: `#` for `{#if`, `:` for `{:else if` (`node.elseif` distinguishes them).
3. Calls `mark_subtree_dynamic(context.path)` *before* visiting children — the mere presence of an `if` makes the subtree dynamic, even if the condition is currently constant.
4. Visits `node.test` with `expression: node.metadata.expression`, then the `consequent` and optional `alternate`.

### `EachBlock` — `{#each}`

The most involved block visitor:

1. Validates the `#` opening tag (unconditional — unlike the other blocks this is not gated on runes mode) and that `body` / `fallback` are non-empty.
2. Rejects rune keywords used as the item binding: `{#each items as $state}` / `as $derived` raises `state_invalid_placement`.
3. Computes **`metadata.keyed`**: `{#each items as item, i (i)}` — a key that is exactly the block's own index — is treated as a *plain indexed* block (`keyed = false`); every other key expression is keyed (`keyed = true`).
4. Visits the list expression with an explicit **parent scope** override (`scope: context.state.scope.parent`), because the item/index/key bindings of the block do not exist where the expression is evaluated. Body, key and fallback are then visited normally (scope switching is done by `set_scope`).
5. **Legacy mode only** (`!analysis.runes`):
   - Determines whether the item binding is *mutated* inside the block (`extract_identifiers(node.context)` + `binding.mutated`).
   - Collects **transitive dependencies** into `metadata.transitive_deps` via `collect_transitive_dependencies`, which recursively expands `legacy_reactive` bindings' `legacy_dependencies` (cycle-safe through a `Set`).
   - If the item is mutated, promotes each collected `normal` binding with declaration kind `const`/`let`/`var` to `kind = 'state'`, so the transforms can turn it into a mutable source and invalidate it when the each-block mutates items.
6. Marks the subtree dynamic.

```mermaid
flowchart TD
    A["EachBlock visitor"] --> B["validate_opening_tag '#' + non-empty body/fallback"]
    B --> C{"context is '$state' / '$derived'?"}
    C -- yes --> C1["error state_invalid_placement"]
    C -- no --> D{"node.key present?"}
    D -- yes --> E["metadata.keyed = key is not Identifier OR no index OR key !== index"]
    D -- no --> F["visits: expression (parent scope) → body → key → fallback"]
    E --> F
    F --> G{"runes mode?"}
    G -- yes --> J["mark_subtree_dynamic"]
    G -- no --> H{"item binding mutated?"}
    H -- yes --> H1["promote transitive_deps 'normal' const/let/var → Binding.kind = 'state'"]
    H -- no --> I["collect_transitive_deps (no promotion)"]
    H1 --> J
    I --> J
```

### `AwaitBlock` — `{#await}` / `{:then}` / `{:catch}`

1. Validates `pending`, `then` and `catch` fragments are non-empty (each is optional in the source, hence the null guards).
2. In runes mode, validates the `#` opening tag.
3. **Delimiter linting on `{:then value}` / `{:catch error}`**: for the destructuring patterns `node.value` and `node.error`, it looks at the 10 source characters before the pattern start and matches `/{(\s*):then\s+$/` (respectively `:catch`). If there is *any whitespace between `{` and `:then`/`:catch`* (e.g. `{ :then x }`), it raises `block_unexpected_character` for the `:` character, keeping the error span narrow.
4. Visits `expression` (with `metadata.expression` tracking), then `pending`, `then`, `catch`; marks the subtree dynamic.

### `KeyBlock` — `{#key}`

1. Validates the fragment is non-empty.
2. In runes mode, validates the `#` opening tag.
3. Visits `expression` (tracked via `metadata.expression`) and `fragment`; marks the subtree dynamic. Keyed blocks force re-creation of their content whenever the key changes, which is why they must always be treated as dynamic.

### `AwaitExpression` — `await` gating and async metadata

```mermaid
flowchart TD
    A["AwaitExpression node"] --> B["suspend = ast_type === 'instance' && function_depth === 1<br/>(top-level await in the component instance script)"]
    B --> C{"inside a tracked template expression?<br/>(state.expression set)"}
    C -- yes --> C1["state.expression.has_await = true"]
    C1 --> C2{"path contains ConstTag?"}
    C2 -- yes --> C3["state.fragment.metadata.has_await = true"]
    C3 --> C4["suspend = true<br/>(template awaits are always suspend points)"]
    C2 -- no --> C4
    C -- no --> D{"suspend?"}
    C4 --> D
    B --> D
    D -- no --> H["context.next() — continue traversal"]
    D -- yes --> E{"options.experimental.async?"}
    E -- no --> E1["error experimental_async"]
    E -- yes --> F{"analysis.runes?"}
    F -- no --> F1["error legacy_await_invalid"]
    F -- yes --> H
```

Behavior in detail:

- **Suspend-point detection**: `suspend` starts as *top-level await in the instance script* (`ast_type === 'instance'` at `function_depth === 1`). Any await inside a tracked template *expression* (i.e. `state.expression` is set) always counts as a suspend point, because it must produce a pending/then/resume boundary at runtime.
- **Async metadata**: `has_await` is recorded on the enclosing `ExpressionMetadata` (later used by `AwaitBlock`/`IfBlock`/`KeyBlock`/`EachBlock` metadata and the transforms). When the await sits inside a `{#const}` (detected by scanning `context.path` for a `ConstTag`), the enclosing `Fragment.metadata.has_await` is also flagged.
- **Gating**: suspend points require the `experimental.async` compile option *and* runes mode; otherwise `experimental_async` / `legacy_await_invalid` errors are thrown.
- If no error is thrown, `context.next()` performs the default child traversal — this visitor adds no child-specific logic.

### Shared helpers (from `visitors/shared/`)

| Helper | Module | Behavior |
|---|---|---|
| `validate_opening_tag(node, state, expected)` | [shared utils](compiler_analyzer.md) | Checks `state.analysis.source[node.start + 1] === expected`; on mismatch raises `block_unexpected_character` over a 5-character span (“avoid a sea of red”). |
| `validate_block_not_empty(node, context)` | shared utils | Warns `block_empty` when a block contains only a single whitespace `Text` node. Zero-element blocks are deliberately silent — the user is probably mid-typing. |
| `mark_subtree_dynamic(path)` | shared fragment | Walks `context.path` **backwards**, setting `Fragment.metadata.dynamic = true` on ancestors; stops at the first fragment already marked dynamic (idempotent). |

---

## Data Flow: What This Module Produces and Who Consumes It

The visitors do not generate code; their output is **analysis metadata** attached to AST nodes and bindings, plus diagnostics. Phase 3 transforms ([compiler_client_transform](compiler_client_transform.md), [compiler_server_transform](compiler_server_transform.md)) and the runtime renderers rely on it.

```mermaid
flowchart LR
    subgraph SRC["Inputs (AST from compiler_parser)"]
        IFN["IfBlock.test"]
        EAN["EachBlock.expression / context / key"]
        AWN["AwaitBlock.expression / value / error"]
        KYN["KeyBlock.expression"]
        AXN["estree AwaitExpression"]
    end

    subgraph META["Metadata written by this module"]
        EX["node.metadata.expression<br/>(ExpressionMetadata: dependencies, has_await)"]
        KE["EachBlock.metadata.keyed"]
        TD["EachBlock.metadata.transitive_deps"]
        DY["Fragment.metadata.dynamic<br/>(via mark_subtree_dynamic)"]
        FA["Fragment / expression has_await"]
        BK["Binding.kind = 'state'<br/>(legacy promotion)"]
    end

    subgraph OUT["Consumers"]
        CT["client transform visitors<br/>IfBlock / EachBlock / AwaitBlock / KeyBlock"]
        ST["server transform visitors<br/>(SSR branch selection, await handling)"]
        RT["runtime renderers<br/>(if_block / each / key / await_block blocks)"]
    end

    IFN --> EX --> CT
    EAN --> EX
    EAN --> KE --> CT
    EAN --> TD --> BK --> CT
    AWN --> EX
    AXN --> EX
    AXN --> FA
    KYN --> EX
    DY --> CT
    DY --> ST
    EX --> ST
```

Key downstream contracts:

- `Fragment.metadata.dynamic` decides whether the client transform creates a **static template** (cloneable DOM) or wires up **reactive effects** for a subtree.
- `metadata.expression.dependencies` (filled jointly with [compiler_analyzer_js_visitors](compiler_analyzer_js_visitors.md)) and `has_await` drive dependency tracking, memoization and async boundaries in both transforms.
- `EachBlock.metadata.keyed` chooses between keyed and plain-indexed rendering strategies; `is_controlled` / `declarations` / `index` metadata on the same node is computed elsewhere in the analyzer.
- Legacy `Binding.kind = 'state'` promotion makes transitive dependencies invalidatable, preserving Svelte 4 reactivity semantics for mutated each-items.

---

## Diagnostics Emitted

| Diagnostic | Raised by | Condition |
|---|---|---|
| `block_empty` (warning) | `validate_block_not_empty` (all blocks) | Branch/fragment contains only whitespace text |
| `block_unexpected_character` | `validate_opening_tag` | Character after `{` is not the expected `#`/`:` |
| `block_unexpected_character` (`:`) | `AwaitBlock` | Whitespace between `{` and `:then`/`:catch` in a `{:then x}`/`{:catch x}` delimiter |
| `state_invalid_placement` | `EachBlock` | `$state`/`$derived` used as the each-item binding |
| `experimental_async` | `AwaitExpression` | Suspend-point `await` without `experimental.async` option |
| `legacy_await_invalid` | `AwaitExpression` | Suspend-point `await` in non-runes mode |

The error/warning catalogs themselves are maintained in [compiler_diagnostics](compiler_diagnostics.md).

---

## Interaction with Sibling Analyzers

```mermaid
flowchart LR
    subgraph Analyze["Phase 2 — analyze"]
        direction TB
        SCOPE["compiler_analyzer_scope<br/>Scope · Binding · set_scope"]
        BLOCK["block visitors (this module)<br/>If/Each/Await/Key + AwaitExpression"]
        TPL["compiler_analyzer_template_visitors<br/>ConstTag · DebugTag · HtmlTag · directives · svelte:*"]
        JS["compiler_analyzer_js_visitors<br/>exports · NewExpression · tagged templates"]
    end
    SCOPE -- "scope.get / binding.mutated / kind promotion" --> BLOCK
    BLOCK -- "expression metadata container" --> JS
    BLOCK -- "path scan for ConstTag" --> TPL
    TPL -- "const fragments get has_await" --> BLOCK
```

- **Scope**: blocks create nested scopes (handled by `set_scope`); `EachBlock` reads `binding.mutated` from the item binding and writes `Binding.kind`.
- **JS visitors**: `AwaitExpression` relies on the `state.expression` handle installed by block visitors; dependency-accumulating visitors run "under" block expressions.
- **Template visitors**: `AwaitExpression` scans `context.path` for `ConstTag` nodes processed by [compiler_analyzer_template_visitors](compiler_analyzer_template_visitors.md); CSS interactions (e.g. global blocks) belong to [compiler_css_pipeline](compiler_css_pipeline.md) and are not handled here.

---

## Related Documentation

- [compiler_analyzer](compiler_analyzer.md) — parent module: walk orchestration, analysis state, visitor dispatch
- [compiler_parser](compiler_parser.md) — Phase 1 parse: produces the AST and source positions used by the source-based validations
- [compiler_analyzer_scope](compiler_analyzer_scope.md) — scopes, bindings, `set_scope`
- [compiler_analyzer_template_visitors](compiler_analyzer_template_visitors.md) — template element/directive/tag visitors (incl. `ConstTag`)
- [compiler_analyzer_js_visitors](compiler_analyzer_js_visitors.md) — JS-level visitors that populate expression dependency metadata
- [compiler_diagnostics](compiler_diagnostics.md) — error/warning message catalogs
- [compiler_client_transform](compiler_client_transform.md) / [compiler_server_transform](compiler_server_transform.md) — consumers of the metadata produced here
- [client_dom_renderer](client_dom_renderer.md) / [server_runtime](server_runtime.md) — runtime block implementations (`if_block`, `each`, `key`, `await_block`) the transforms target
