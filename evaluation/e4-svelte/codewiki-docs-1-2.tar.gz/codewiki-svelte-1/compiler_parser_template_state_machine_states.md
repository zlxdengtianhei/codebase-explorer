# compiler_parser_template_state_machine_states

## Overview

This module implements the **individual state functions** of the Svelte template parser's single-pass state machine (phase 1-parse). Each state function is a pure consumer of the shared `Parser` instance: it inspects the template at `parser.index`, consumes characters, appends AST nodes to the current fragment, mutates the structural stack, and returns the *next* state function to execute.

The module owns three of the parser's four top-level states:

| State / function | File | Responsibility |
|---|---|---|
| `fragment` | `state/fragment.js` | Default dispatcher state — routes to `element`, `tag`, or `text` based on the next character |
| `element` | `state/element.js` | Parses comments, opening/closing tags, meta tags (`svelte:*`), element/component type inference, and drives attribute reading |
| `read_attribute` / `read_static_attribute` | `state/element.js` | Sub-routines (not states) used by `element` to parse attributes, spread attributes, attachments, and directives |
| `text` | `state/text.js` | Consumes plain text until the next `<` or `{`, decoding character references |

The fourth top-level state, `tag` (mustache syntax `{#if}…{/if}`, `{@html}`, `{expr}`), lives in the sibling `state/tag.js` file and is documented in [compiler_parser_template_state_machine](compiler_parser_template_state_machine.md).

## Position in the System

```
Compiler_Front-End
└── compiler_parser
    └── compiler_parser_template_state_machine
        ├── compiler_parser_template_state_machine_engine   ← Parser class & run loop
        └── compiler_parser_template_state_machine_states   ← THIS MODULE (fragment / element / text states)
```

The output of this module is the template portion of `AST.Root` (`fragment`, `js`, `css`, `options` fields), which is consumed by the analysis phase — see [compiler_analyzer](compiler_analyzer.md). Node shapes produced here are defined in [compiler_types_template_ast](compiler_types_template_ast.md).

## Architecture

The state machine engine ([compiler_parser_template_state_machine_engine](compiler_parser_template_state_machine_engine.md)) drives everything. Its `Parser` constructor runs a single loop over the template string:

```javascript
/** @type {ParserState} */
let state = fragment;

while (this.index < this.template.length) {
    state = state(this) || fragment;   // falsy return → reset to fragment
}
```

Contract every state function follows:

1. **Input:** the `Parser` instance (template source, `index`, `stack`, `fragments`, `loose` flag, utility methods such as `match`, `eat`, `read_until`, `append`, `pop`).
2. **Behavior:** consume characters, append AST nodes via `parser.append(node)` into the topmost fragment (`parser.fragments.at(-1)`), and push/pop structural nodes (`parser.stack` / `parser.pop()`) for containers with children.
3. **Output:** the next `ParserState` function, or `undefined` — the engine then resets to `fragment`.

```mermaid
flowchart TB
    subgraph engine["compiler_parser_template_state_machine_engine"]
        P["Parser (index.js)<br/>loop: state = state(parser) || fragment"]
    end

    subgraph states["compiler_parser_template_state_machine_states (this module)"]
        F["fragment.js<br/>fragment (dispatcher)"]
        E["element.js<br/>element"]
        T["text.js<br/>text"]
        RA["element.js helpers<br/>read_attribute<br/>read_static_attribute"]
    end

    subgraph sibling["compiler_parser_template_state_machine (sibling states)"]
        TG["tag.js<br/>tag / open / next / close / special"]
    end

    P -->|"invokes current state"| F
    F -->|"next char is '<'"| E
    F -->|"next char is '{'"| TG
    F -->|"otherwise"| T
    E --> RA
    E -->|"append / stack push-pop"| P
    T -->|"append Text node"| P
    TG -->|"append tag nodes / stack"| P
```

### External dependencies

| Dependency | Provider module | Used for |
|---|---|---|
| `decode_character_references` | [compiler_parser_parse_utilities](compiler_parser_parse_utilities.md) (`utils/html.js`) | HTML entity decoding in text, attribute values, and raw-text chunks |
| `read_expression` | `read/expression.js` | Acorn-based JS expression parsing inside `{…}` tags and attribute values |
| `read_script` / `read_style` | [compiler_parser_js_ts_processing](compiler_parser_js_ts_processing.md) | Full parse of top-level `<script>` / `<style>` contents |
| `is_void`, `closing_tag_omitted`, `list` | shared compiler utils | HTML void-element set, omitted-closing-tag table, error message lists |
| `create_fragment`, `create_attribute`, `create_expression_metadata`, `is_element_node` | `phases/nodes.js` / `utils/create.js` | AST node factories |
| `e.*` errors, `w.*` warnings | [compiler_diagnostics_errors](compiler_diagnostics_errors.md), [compiler_diagnostics_warnings](compiler_diagnostics_warnings.md) | Compile errors and warnings raised during parsing |

## State Machine

`fragment` is the hub state. Because every state function returns `undefined` after producing exactly one node (or handling one tag), the engine returns to `fragment` after *every* step — the machine is effectively "fragment or one-step excursion".

```mermaid
stateDiagram-v2
    direction TB
    [*] --> fragment

    fragment --> element : next char is '<'
    fragment --> tag : next char is '{' (state in sibling module)
    fragment --> text : any other char

    element --> fragment : returns undefined
    tag --> fragment : returns undefined
    text --> fragment : returns undefined

    note right of fragment
        Engine resets to fragment whenever a
        state returns falsy: state = state(parser) || fragment
    end note

    note left of element
        element may push itself / blocks onto
        parser.stack so nested content is
        appended to child fragments
    end note
```

At end-of-input the engine enforces two invariants (see the engine module for the full error contract):

- If the final executed state is **not** `fragment` → `unexpected_eof`.
- If `parser.stack.length > 1` → `element_unclosed` / `block_unclosed` (in `loose` mode the dangling node is simply closed at template end instead).

## Components

### `fragment` — dispatcher (`state/fragment.js`)

A three-way branch on the next character:

```mermaid
flowchart LR
    F["fragment(parser)"] --> M1{"match '<' ?"}
    M1 -->|yes| E["return element"]
    M1 -->|no| M2{"match '{' ?"}
    M2 -->|yes| T["return tag<br/>(state/tag.js)"]
    M2 -->|no| X["return text"]
```

It contains no parsing logic itself — it only selects the next state. Notably it does **not** consume the matched character; the chosen state owns it.

### `text` — plain text consumption (`state/text.js`)

Accumulates characters into `data` while `parser.index` is in bounds and the next character is neither `<` nor `{`, then appends a single `AST.Text` node:

- `raw` — the exact source slice
- `data` — result of `decode_character_references(raw, false)` (text-mode entity decoding; attribute mode passes `true`)

The state terminates at the first `<` or `{`, returning `undefined`, so the following construct is re-examined by `fragment`.

### `element` — tag parsing (`state/element.js`)

The largest state. High-level decision flow:

```mermaid
flowchart TD
    S["element(parser): index++ past '<'"] --> CMT{"eat '!--' ?"}
    CMT -->|yes| APPC["append Comment node, return"]
    CMT -->|no| CLO{"eat '/' (closing tag) ?"}
    CLO -->|yes| CLOSE["auto-close any elements whose closing tags were omitted,<br/>walk stack until name matches, pop stack, set parent.end"]
    CLO -->|no| NAME["read tag name"]
    CLOSE --> RET["return (back to fragment)"]
    NAME --> META{"name starts with 'svelte:'?"}
    META -->|unknown| ERR1["e.svelte_meta_invalid_tag"]
    META -->|known| VAL
    META -->|no| VAL["validate element / component name regexes<br/>(loose mode allows trailing '.')"]
    VAL --> ROOT{"root-only meta tag?"}
    ROOT -->|yes| CHK["error if duplicate or not at Root,<br/>record in parser.meta_tags"]
    ROOT -->|no| INFER
    ROOT -->|"ok"| INFER["infer node type"]
    INFER --> ATTRS["read attributes in a loop:<br/>read_static_attribute for top-level script/style,<br/>else read_attribute; reject duplicates"]
    ATTRS --> SC{"name = script/style at Root?"}
    SC -->|yes| RAW["eat '>', capture preceding HTML comment<br/>for warning silencing,<br/>read_script / read_style into root.js / root.css"]
    SC -->|no| APP["parser.append(element)"]
    RAW --> RET
    APP --> SELFCLOSE{"eat '/' or void element?"}
    SELFCLOSE -->|yes| DONE["element.end = index,<br/>do NOT push stack"]
    SELFCLOSE -->|no| TXT{"special raw-text element?"}
    TXT -->|"textarea"| TA["read_sequence until closing textarea regex"]
    TXT -->|"script / style (nested)"| NESTED["read raw Text until closing tag"]
    TXT -->|"everything else"| PUSH["push element on parser.stack,<br/>push element.fragment on parser.fragments"]
    TA --> RET
    NESTED --> RET
    PUSH --> RET
    DONE --> RET
```

Key behaviors:

- **Type inference** — the resolved `AST.ElementLike['type']` follows this precedence:
  1. **Meta tags** (exact name lookup): `svelte:head` → `SvelteHead`, `svelte:options` → `SvelteOptions`, `svelte:window` → `SvelteWindow`, `svelte:document` → `SvelteDocument`, `svelte:body` → `SvelteBody`, plus non-root `svelte:element`, `svelte:component`, `svelte:self`, `svelte:fragment`, `svelte:boundary`.
  2. **`Component`** — name matches `regex_valid_component_name` (must start uppercase, or be a dotted path) — also tolerant of a trailing `.` in loose mode for editor completions.
  3. **`TitleElement`** — a `title` element whose ancestors reach `SvelteHead` before hitting an element/component.
  4. **`SlotElement`** — a `slot` element *not* inside a declarative-shadow-DOM template (detected via an ancestor element carrying a `shadowrootmode` attribute).
  5. **`RegularElement`** — otherwise (its metadata is pre-populated: `svg`, `mathml`, `scoped`, `has_spread`, `path`); other types get an empty metadata placeholder filled by later phases.
- **Implicit closing** — HTML `closing_tag_omitted` rules (e.g. `<li>` before `<li>`) close the parent and record `parser.last_auto_closed_tag` (with stack depth) so a later matching `</tag>` is handled without spurious errors. Warnings (`element_implicitly_closed`) are emitted.
- **Closing-tag reconciliation** — `</name>` pops the stack; parents that don't match are implicitly closed (with warning, or with `element_invalid_closing_tag` for non-elements). Loose mode can also *backtrack*: if the previous element mis-interpreted `<name` as an attribute, `parser.index` is rewound to that attribute and it is removed.
- **`svelte:component` / `svelte:element`** — the required `this` attribute is extracted from `attributes` into `element.expression` / `element.tag` (`svelte_element_invalid_this` warns for static values to preserve legacy behavior).
- **Loose-mode backtracking after the tag** — if the closing `>` was never found, the parser rewinds characters that plausibly belong to the *next* construct: an attribute named `<`, a `{/`, or a `{#` / `{@` / `{:` prefix; otherwise it absorbs trailing whitespace so language tooling gets more context.

### `read_static_attribute` — attributes of top-level `<script>`/`<style>`

A deliberately restricted reader used only when parsing `<script>` or `<style>` whose parent is `Root`:

- Reads only `name`, `name="value"` / `name='value'` forms as a single `Text` chunk (attribute-mode entity decoding).
- Rejects stray quote characters (`expected_token`).
- Prevents expression tags / directives inside these tags, which would be meaningless before the reader consumes the raw body.

### `read_attribute` — attributes, directives, spreads, attachments

Sub-routine invoked in a loop by `element`. Decision flow:

```mermaid
flowchart TD
    A["read_attribute(parser)"] --> BR{"eat '{' ?"}
    BR -->|"yes"| ATT{"eat '@attach' ?"}
    ATT -->|yes| A1["read_expression → AttachTag"]
    ATT -->|no| SPR{"eat '...' ?"}
    SPR -->|yes| A2["read_expression → SpreadAttribute"]
    SPR -->|no| A3["read_identifier → shorthand Attribute<br/>{name} ⇒ ExpressionTag(Identifier)<br/>(loose mode tolerates '{' / '{#' / '{/' / '{@' / '{:' mid-tag)"]
    BR -->|"no"| NM["read name until token-ending char"]
    A1 --> RT
    A2 --> RT
    A3 --> RT
    NM -->|empty| NUL["return null (loop ends)"]
    NM --> VAL["allow_whitespace; find ':' prefix"]
    VAL --> EQ{"eat '=' ?"}
    EQ -->|yes| AV["read_attribute_value:<br/>'/' before '>', or quoted / unquoted<br/>Text + ExpressionTag sequence"]
    EQ -->|no| DIR["missing '=' before quote → error"]
    AV --> ISDIR{"name has known<br/>directive prefix?"}
    DIR --> ISDIR
    ISDIR -->|yes| D1["build Directive:<br/>name, modifiers, expression<br/>(text parts → directive_invalid_value)<br/>transition: set intro/outro<br/>bind/class shorthand: implicit Identifier expression"]
    ISDIR -->|no| D2["create_attribute(name, value)"]
    D1 --> RT["return node"]
    D2 --> RT
```

Directive prefix table (`get_directive_type`):

| Prefix | Node type | Notes |
|---|---|---|
| `use` | `UseDirective` | |
| `animate` | `AnimateDirective` | |
| `bind` | `BindDirective` | `bind:x` shorthand gets an implicit `Identifier` expression |
| `class` | `ClassDirective` | same shorthand behavior |
| `style` | `StyleDirective` | carries `important` modifiers |
| `on` | `OnDirective` | |
| `let` | `LetDirective` | |
| `in` / `out` / `transition` | `TransitionDirective` | sets `intro` / `outro` flags from the prefix |

Duplicate detection happens in `element`: `Attribute` and `BindDirective` names are normalized to the same key (so `bind:value` + `value` collide), while `class:`/`style:` keep their own namespace (`class:x` + `x` are allowed).

### `read_sequence` — mixed text/expression chunk reader

Shared by attribute values and `<textarea>` bodies. Accumulates raw text into a working chunk and, on `{`, flushes it as `Text` and parses an expression via `read_expression` into an `ExpressionTag`. It also guards placement:

- `{#block}` inside an attribute/textarea → `block_invalid_placement`
- `{@tag}` inside an attribute/textarea → `tag_invalid_placement`

On `js_parse_error` from acorn it probes for an unclosed self-closing tag (`…} />`) to raise a precise `expected_token` instead. Character references in flushed chunks are decoded in attribute mode. In loose mode, unexpected EOF returns the chunks collected so far; otherwise it throws `unexpected_eof`.

## Process Example: Parsing `<p>Hello {name}!</p>`

```mermaid
sequenceDiagram
    participant Eng as Parser loop
    participant Fr as fragment
    participant El as element
    participant Tx as text
    participant Frag as parser.fragments top

    Eng->>Fr: state(parser)
    Note over Fr: index at '<p>' - returns element
    Fr-->>Eng: element state
    Eng->>El: state(parser)
    El->>Frag: append RegularElement p (attributes: [])
    El->>Eng: push p + p.fragment on stacks
    Note over Eng: state returned undefined - reset to fragment
    Eng->>Fr: state(parser)
    Note over Fr: 'H' is text - returns text
    Fr-->>Eng: text state
    Eng->>Tx: state(parser)
    Tx->>Frag: append Text "Hello " (entities decoded)
    Eng->>Fr: state(parser)
    Note over Fr: index at '{' - returns tag (sibling module)
    Fr-->>Eng: tag state
    Eng->>Eng: tag state appends ExpressionTag(name)
    Eng->>Fr: state(parser)
    Fr-->>Eng: text state
    Eng->>Tx: state(parser)
    Tx->>Frag: append Text "!"
    Eng->>El: element state: closing tag /p
    El->>Eng: verify name, set p.end, pop stack
    Note over Eng: index at EOF - root.start/end trimmed from fragment nodes
```

## Output Contract (AST nodes produced)

All nodes carry `start`/`end` offsets into the original template and, where relevant, an empty `metadata.expression` placeholder to be populated during analysis. Node type definitions live in [compiler_types_template_ast](compiler_types_template_ast.md).

| Producer | Nodes |
|---|---|
| `text` | `Text` |
| `element` (comments) | `Comment` |
| `element` (tags) | `RegularElement`, `Component`, `TitleElement`, `SlotElement`, `SvelteHead`, `SvelteWindow`, `SvelteDocument`, `SvelteBody`, `SvelteOptions`, `SvelteElement`, `SvelteComponent`, `SvelteSelf`, `SvelteFragment`, `SvelteBoundary` |
| `read_attribute` | `Attribute`, `SpreadAttribute`, `AttachTag`, `BindDirective`, `OnDirective`, `ClassDirective`, `StyleDirective`, `UseDirective`, `AnimateDirective`, `LetDirective`, `TransitionDirective`, `ExpressionTag` (in values) |
| `read_sequence` | `Text` + `ExpressionTag` sequences |

Top-level `<script>`/`<style>` content is not appended as template nodes — `read_script`/`read_style` store it in `root.js` (`instance` / `module` contexts) and `root.css` respectively, including a captured preceding HTML comment used later for warning suppression (see [compiler_parser_js_ts_processing](compiler_parser_js_ts_processing.md)).

## Error Handling and Loose Mode

This module is the primary consumer of parse diagnostics (full catalog: [compiler_diagnostics_errors](compiler_diagnostics_errors.md), [compiler_diagnostics_warnings](compiler_diagnostics_warnings.md)). Representative errors: `tag_invalid_name`, `svelte_meta_invalid_tag`, `svelte_meta_duplicate`, `svelte_meta_invalid_placement`, `attribute_duplicate`, `attribute_empty_shorthand`, `directive_missing_name`, `directive_invalid_value`, `expected_attribute_value`, `void_element_invalid_content`, `element_invalid_closing_tag`, `block_invalid_placement`, `unexpected_eof`.

**Loose mode** (`parser.loose`) exists so language servers can parse incomplete documents. Behaviors triggered only in loose mode:

- Element names ending in `.` (mid-typing) are accepted and typed as `Component`.
- A closing tag that mismatches the stack can rewind a previously mis-parsed `<name` attribute and continue.
- `read_attribute` returns `null` on `{#`, `{/`, `{@`, `{:` inside an unclosed opening tag instead of erroring, letting `element` close the tag.
- A bare `{}` shorthand becomes an attribute with an empty identifier.
- `read_sequence` and `read_until` return partial results instead of raising `unexpected_eof`; the engine closes dangling stack entries at template length.
- Missing `>` on the final tag absorbs trailing whitespace rather than failing.

## Integration with Other Modules

- **Upstream:** [compiler_core_entry](compiler_core_entry.md)-driven compilation invokes the parse phase; the preprocessed source arrives via [compiler_preprocess_engine](compiler_preprocess_engine.md).
- **Engine:** the `Parser` class, its utility methods (`match`, `eat`, `read_until`, `append`, `pop`), and the `tag`/block states are documented in [compiler_parser_template_state_machine](compiler_parser_template_state_machine.md) and [compiler_parser_template_state_machine_engine](compiler_parser_template_state_machine_engine.md).
- **Utilities:** entity decoding and fuzzy name matching live in [compiler_parser_parse_utilities](compiler_parser_parse_utilities.md); JS/TS/script/style readers in [compiler_parser_js_ts_processing](compiler_parser_js_ts_processing.md).
- **Downstream:** the produced `AST.Root.fragment` is walked by [compiler_analyzer](compiler_analyzer.md) (scope creation, visitor dispatch per node type), then transformed by the back-end modules (client/server transforms) — see the front-end overview in [Compiler_Front-End_Parsing_Analysis_CSS_Scoping_Pipeline](Compiler_Front-End_Parsing_Analysis_CSS_Scoping_Pipeline.md).
