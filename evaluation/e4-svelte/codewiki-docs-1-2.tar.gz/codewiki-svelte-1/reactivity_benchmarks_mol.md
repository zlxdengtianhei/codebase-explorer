# reactivity_benchmarks_mol

## 1. Introduction

`reactivity_benchmarks_mol` implements the **"mol" (molecule) reactivity benchmark** for Svelte 5's client-side signal runtime. Adapted from the [`js-reactivity-benchmark`](https://github.com/milomg/js-reactivity-benchmark) project, it builds a small but *dense and deliberately expensive* reactive dependency graph — two state sources fanning out into four derived signals that converge into a single downstream value — and measures how long the runtime takes to propagate batched updates through it 10,000 times.

The module lives at `benchmarking/benchmarks/reactivity/mol_bench.js` and exports two entry points:

| Export | Description |
| --- | --- |
| `mol_bench_owned()` | Runs the benchmark with the signal graph created **inside an `effect_root`**, exercising the *owned reaction* code path of the runtime. |
| `mol_bench_unowned()` | Runs the identical graph created **at top level**, exercising the *unowned (dynamically re-parented) reaction* code path. |

It is a leaf module of the [reactivity_benchmarks](reactivity_benchmarks.md) suite, alongside the shape-focused [reactivity_benchmarks_sbench](reactivity_benchmarks_sbench.md) (signal creation / fan-out / fan-in ratios) and [reactivity_benchmarks_kairo](reactivity_benchmarks_kairo.md) (named graph topologies: diamond, triangle, broad, deep, mux, …). Where those suites stress *topology*, **mol stresses propagation cost under load**: each derived embeds a deterministic non-reactive workload (`fib(16)` recursion), so the benchmark punishes any runtime that invalidates or recomputes more than strictly necessary.

Beyond timing, the benchmark doubles as a **correctness canary**: every measured iteration asserts exact expected output values (`3198, 1601, 3195, 1598`), so a regression in batching, lazy evaluation, or equality-based pruning fails loudly instead of producing misleading numbers.

---

## 2. Architecture & Module Relationships

The module is pure orchestration logic — it contains no runtime behavior of its own. It composes:

1. **The benchmark harness** (`benchmarking/utils.js`) for timing, GC accounting and assertions.
2. **The Svelte client runtime** (`svelte/internal/client`) for signals, effects and batching.
3. **The suite runner** (`benchmarking/run.js` → `benchmarks/reactivity/index.js`) which invokes the exports and aggregates results.

```mermaid
flowchart TB
    subgraph harness["Benchmark Harness — benchmarking/"]
        RUN["run.js<br/>(suite runner, totals &amp; exit codes)"]
        IDX["benchmarks/reactivity/index.js<br/>(suite registry)"]
        UTILS["utils.js<br/>fastest_test · assert · GarbageTrack"]
    end

    subgraph module["reactivity_benchmarks_mol — mol_bench.js"]
        MB["mol_bench.js"]
        OWNED["mol_bench_owned()"]
        UNOWNED["mol_bench_unowned()"]
        SETUP["setup()<br/>builds signal graph, returns { run, destroy }"]
        RUNFN["run(i)<br/>2 batched flushes + exact-output assertions"]
        MB --> OWNED
        MB --> UNOWNED
        OWNED --> SETUP
        UNOWNED --> SETUP
        SETUP --> RUNFN
    end

    subgraph runtime["Svelte 5 client runtime — svelte/internal/client"]
        SOURCES["reactivity/sources.js<br/>state · set"]
        DERIVEDS["reactivity/deriveds.js<br/>user_derived (derived)"]
        EFFECTS["reactivity/effects.js<br/>effect_root · render_effect"]
        BATCH["reactivity/batch.js<br/>flushSync (exported as flush)"]
        CORE["runtime.js<br/>get"]
    end

    RUN --> IDX --> MB
    OWNED --> UTILS
    UNOWNED --> UTILS
    SETUP --> SOURCES & DERIVEDS & EFFECTS & CORE
    RUNFN --> SOURCES & BATCH & CORE
```

### 2.1 Runtime API surface used

The benchmark consumes only the low-level signal primitives that compiled Svelte components themselves use — this makes it a faithful proxy for real component update costs:

| Benchmark call | Internal export | Implemented in | Referenced documentation |
| --- | --- | --- | --- |
| `$.state(v)` | `state` | `reactivity/sources.js` | [client_runtime_core_sources](client_runtime_core_sources.md) |
| `$.set(s, v)` | `set` | `reactivity/sources.js` | [client_runtime_core_sources](client_runtime_core_sources.md) |
| `$.get(s)` | `get` | `runtime.js` | [client_runtime_core_runtime](client_runtime_core_runtime.md) |
| `$.derived(fn)` | `user_derived` | `reactivity/deriveds.js` | [client_runtime_core_deriveds](client_runtime_core_deriveds.md) |
| `$.effect_root(fn)` | `effect_root` | `reactivity/effects.js` | [client_runtime_core_effects](client_runtime_core_effects.md) |
| `$.render_effect(fn)` | `render_effect` | `reactivity/effects.js` | [client_runtime_core_effects](client_runtime_core_effects.md) |
| `$.flush(fn)` | `flushSync` | `reactivity/batch.js` | [client_runtime_core_batching](client_runtime_core_batching.md) |

The underlying signal/effect data model is documented in [client_runtime_core_signal_model](client_runtime_core_signal_model.md); how measured numbers are compared across runs is covered in [benchmark_comparison_tooling](benchmark_comparison_tooling.md).

### 2.2 The measured reactive graph ("the molecule")

```mermaid
flowchart LR
    A(("state A"))
    B(("state B"))
    C(("C<br/>derived<br/>A%2 + B%2"))
    D(("D<br/>derived<br/>numbers.map(i ⇒ i + A%2 − B%2)<br/>⚠ custom element-wise equals"))
    E(("E<br/>derived (lazy)<br/>hard(C + A + D[0])"))
    F(("F<br/>derived<br/>hard(D[0] &amp;&amp; B)"))
    G(("G<br/>derived<br/>C + (C ∥ E%2) + D[0] + F"))
    FX1["render_effect #1<br/>res.push(hard(G))"]
    FX2["render_effect #2<br/>res.push(G)"]
    FX3["render_effect #3<br/>res.push(hard(F))"]

    A --> C
    B --> C
    A --> D
    B --> D
    A --> E
    C --> E
    D --> E
    D --> F
    B --> F
    C --> G
    E --> G
    D --> G
    F --> G
    G --> FX1
    G --> FX2
    F --> FX3
```

**Deliberate cost features of the graph:**

- **`hard(n) = n + fib(16)`** — every evaluation of `E`, `F` and each effect body pays for a recursive `fib(16)` computation (`fib(16) = 1597`). This constant non-reactive overhead amplifies the penalty for *over-invalidation*: an engine that recomputes `E` or an effect unnecessarily pays ~1597 extra recursive calls.
- **`D` has a custom `equals`** that compares arrays element-wise instead of by reference. Array-producing deriveds are recreated on every change of `A`/`B`; without custom equality, every update would needlessly invalidate `E`, `F` and `G`. The benchmark therefore also verifies that `derived_safe_equal`-style pruning works for user-supplied comparators (set directly on `D.equals`).
- **`E` is read lazily and short-circuited** — `G`'s expression `C + (C || E % 2) + …` only reads `E` when `C` is falsy. During the first flush (`C = 2`), `E` is marked dirty but *never recomputed*; during the second flush (`C = 0`), it is. This exercises the pull-based, lazy evaluation of deriveds.
- **`F` never actually changes value** (`D[0]` is always `0`, so `F` stays `hard(0) = 1597`): the third render effect must *not* re-run in either flush — a check that the runtime skips effects whose dependencies did not change.

### 2.3 Owned vs. unowned variants

The two exports differ only in *where* the final `setup()` is executed, which changes how `$.derived` assigns ownership (see `user_derived` in [client_runtime_core_deriveds](client_runtime_core_deriveds.md)):

| Variant | Graph creation context | Runtime behavior exercised |
| --- | --- | --- |
| `mol_bench_owned` | Inside `$.effect_root(() => { … })` | An active root effect exists, so deriveds are **owned** by it (the root effect receives `EFFECT_PRESERVED`); effects are destroyed via both the inner `destroy` and the outer `destroy_owned`. |
| `mol_bench_unowned` | Top-level scope (no active effect) | Deriveds are flagged **`UNOWNED`** and their dependency links are (re)established dynamically at read time — a costlier bookkeeping path in some scenarios. |

Measuring both ensures that performance work on ownership bookkeeping (owner linking, `push_reaction_value`, preserved-effect handling) cannot silently regress one path while improving the other.

---

## 3. Data Flow & Process

### 3.1 Benchmark lifecycle (`mol_bench_owned`)

```mermaid
sequenceDiagram
    autonumber
    participant R as run.js (suite runner)
    participant M as mol_bench_owned()
    participant RT as client runtime ($)
    participant U as fastest_test() + GarbageTrack

    R->>M: await mol_bench_owned()
    M->>RT: effect_root(() => { 10× warmup: setup(); run(0); destroy() })
    Note over M,RT: JIT warm-up — stabilizes optimization before measurement
    M->>RT: effect_root(() => { ({run, destroy} = setup()) })
    M->>U: fastest_test(10, run 10_000 iterations)
    loop 10 repetitions (each)
        U->>U: v8.collectGarbage() (forced, pre-timing)
        U->>U: watch(run_timed(fn)) — wall-clock window recorded
        U->>U: gcDuration(track_id) via PerformanceObserver('gc')
    end
    U-->>M: fastest repetition: { timing: { time, gc_time } }
    M->>RT: destroy() (graph effects) + destroy_owned() (outer root)
    M-->>R: { benchmark, time, gc_time } (ms, 2-decimal strings)
```

Each timed repetition executes `run(i)` for `i = 0 … 9999`. `fastest_test` discards all but the *fastest* repetition (to filter scheduler/GC noise) while `gc_time` is reported from that same winning window — the GC accounting logic is shared with the whole harness and documented in [reactivity_benchmarks](reactivity_benchmarks.md). For `mol_bench_unowned` the flow is identical except the final `setup()` (and the extra `destroy_owned`) are omitted.

### 3.2 A single `run(i)` — propagation & verification

```mermaid
flowchart TD
    S["res.length = 0"] --> F1["flush #1 — one Batch:<br/>set(B, 1); set(A, 1 + 2i)"]
    F1 --> P1["Synchronous batched propagation<br/>(flushSync drives effect scheduling)"]
    P1 --> K1["C = 2 · D = [0..4] (equals: unchanged)<br/>E dirty but never read (short-circuit)<br/>F = 1597 → unchanged"]
    K1 --> G1["G: 1598 → 1601<br/>effects #1 &amp; #2 re-run → res: [3198, 1601]<br/>effect #3 correctly skipped"]
    G1 --> F2["flush #2 — one Batch:<br/>set(A, 2 + 2i); set(B, 2)"]
    F2 --> P2["Synchronous batched propagation"]
    P2 --> K2["C = 0 → G reads E → E recomputes lazily<br/>D element-wise unchanged → no propagation<br/>F still 1597 → unchanged"]
    K2 --> G2["G: 1601 → 1598<br/>effects #1 &amp; #2 re-run<br/>res: [3198, 1601, 3195, 1598]"]
    G2 --> AS["assert exact output:<br/>res[0]=3198 · res[1]=1601 · res[2]=3195 · res[3]=1598"]
    AS -->|"pass"| OK["iteration complete"]
    AS -->|"fail"| ERR["AssertionError → suite aborts (run.js exits 1)"]
```

The expected values are fully deterministic (`hard(n) = n + 1597`):

| `res` index | Value | Producer | Why |
| --- | --- | --- | --- |
| `res[0]` | `3198` | effect #1, flush #1 | `hard(1601)` = `1601 + 1597` |
| `res[1]` | `1601` | effect #2, flush #1 | `G = 2 + 2 + 0 + 1597` |
| `res[2]` | `3195` | effect #1, flush #2 | `hard(1598)` = `1598 + 1597` |
| `res[3]` | `1598` | effect #2, flush #2 | `G = 0 + (E%2 = 1) + 0 + 1597` |

Any deviation indicates a semantic regression — incorrect dependency tracking, missing batch coalescing, eager evaluation of `E`, or equality checks failing to prune `D`/`F`.

### 3.3 Result contract

Both exports resolve to the common suite result shape consumed by `run.js` and the comparison tooling:

```js
{
  benchmark: 'mol_bench_owned' | 'mol_bench_unowned',
  time: '<ms>',      // wall-clock of fastest repetition / 10_000 updates, 2 decimals
  gc_time: '<ms>'    // GC pause time accumulated in that window, 2 decimals
}
```

---

## 4. Component Interaction Summary

| Component | Responsibility | Interacts with |
| --- | --- | --- |
| `mol_bench_owned` / `mol_bench_unowned` | JIT warm-up, graph lifetime management (owned variant), measurement loop, result formatting | `setup()`, `fastest_test`, `$.effect_root` |
| `setup()` | Constructs the 2-source / 5-derived / 3-effect graph; installs custom `D.equals`; returns `{ run, destroy }` | `$.state`, `$.derived`, `$.effect_root`, `$.render_effect`, `fib`/`hard` |
| `run(i)` | Two `$.flush` batches of state writes; collects effect output; asserts exact values | `$.set`, `$.flush`, `assert` |
| `fib` / `hard` | Deterministic CPU payload (`+fib(16)`) baked into every derived/effect evaluation | — |
| `fastest_test` / `GarbageTrack` | Repeats measurement, forces GC, isolates the fastest run, attributes GC pause time | `v8-natives`, `PerformanceObserver('gc')` |
| `reactivity/index.js` | Registers both exports in the suite order | `run.js` |

## 5. Operational Notes for Maintainers

- **Environment**: requires Node with `v8-natives` (forced `collectGarbage`) and GC `PerformanceObserver` entries — same requirements as the rest of the harness (see [reactivity_benchmarks](reactivity_benchmarks.md)).
- **Interpreting regressions**: because 5 deriveds and 3 effects embed `fib(16)`, this benchmark is *sensitive to over-invalidation*. A time regression with correct output usually means extra derived recomputations (broken `equals` pruning), unnecessary effect scheduling (changed-value filtering), or heavier dependency re-linking (typically visible as an `owned` vs `unowned` divergence).
- **Correctness failures abort the suite**: an assertion failure propagates to `run.js`, which logs `-- Benchmarking Failed --` and exits with code `1` — treat it as a runtime semantics bug, not a benchmarking fluke.
- **The graph is intentionally tiny**; for topology-focused coverage (diamond, triangle, deep chains, mux fan-in, avoidable/unstable subscriptions) refer to [reactivity_benchmarks_kairo](reactivity_benchmarks_kairo.md), and for creation-rate microbenchmarks to [reactivity_benchmarks_sbench](reactivity_benchmarks_sbench.md).