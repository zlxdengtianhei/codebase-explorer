# Client DOM Renderer: Elements & Events (`client_dom_renderer_elements_and_events`)

> **Module path:** `packages/svelte/src/internal/client/dom/elements/*`
> **Parent:** [client_dom_renderer](client_dom_renderer.md) (Component Rendering Backends — Client DOM)

## 1. Introduction

`client_dom_renderer_elements_and_events` is the sub-module of the client DOM renderer that implements everything the compiled output of a Svelte component needs in order to **mutate and interact with individual DOM elements** at runtime. While the [DOM foundation](client_dom_renderer_dom_foundation.md) provides template cloning/hydration primitives and the [control-flow blocks](client_dom_renderer_control_flow_blocks.md) manage conditional/list rendering, this module owns the per-element concerns:

| Concern | File | Responsibility |
|---|---|---|
| **Attributes & properties** | `attributes.js` | Reactive attribute/property application (`attribute_effect`), the spread-attribute diff engine (`set_attributes`), hydration-safe defaults, custom-element data handling |
| **Events** | `events.js` | Listener creation, **event delegation** at the app root, propagation handling, SSR event replay, dev-mode handler validation |
| **Transitions & animations** | `transitions.js` | Intro/outro transition managers, `flip`-style animation managers, and the Web Animations API–based `animate()` engine |
| **Custom elements** | `custom-element.js` | Wrapping Svelte components as native custom elements (`<svelte:options customElement>`), slot creation, attribute↔prop reflection |
| **Element miscellany** | `misc.js` | `autofocus`, textarea hydration fixups, the global form-reset listener |

The compiler's client transform ([compiler_client_transform_elements_and_events](compiler_client_transform_elements_and_directives.md)) emits calls directly into these functions (`$.attribute_effect`, `$.event`, `$.transition`, `$.animation`, `$.set_custom_element_data`, …), making this module one of the most heavily exercised parts of the client runtime.

## 2. Architecture

### 2.1 Position within the client renderer

```mermaid
flowchart TB
    subgraph Compiler["Compiler (build time)"]
        CT["compiler_client_transform_elements_and_directives<br/>(RegularElement, Attribute, OnDirective,<br/>TransitionDirective, UseDirective visitors)"]
    end

    subgraph Parent["client_dom_renderer (see client_dom_renderer.md)"]
        LIFE["client_dom_renderer_lifecycle_api<br/>(hydrate / mount / unmount)"]
        FB["client_dom_renderer_dom_foundation<br/>(template, operations, hydration, css)"]
        BLOCKS["client_dom_renderer_control_flow_blocks<br/>(each, if, key, snippet, ...)"]
        CURRENT["<b>client_dom_renderer_elements_and_events</b><br/>attributes · events · transitions<br/>custom-element · misc"]
        BIND["client_dom_renderer_bindings<br/>(input, select, media, size, ...)"]
    end

    subgraph RuntimeCore["client_runtime_core (see client_runtime_core.md)"]
        RT["runtime.js<br/>active_effect / active_reaction / get"]
        FX["reactivity/effects.js<br/>effect / block / branch / teardown"]
        LOOP["loop.js (run_tasks)"]
    end

    LEGACY["legacy_compat<br/>(createClassComponent)"]
    TRANS["transitions_and_animations<br/>(public fade/fly/flip/slide CSS functions)"]
    DEV["client_dev_mode<br/>(HMR, ownership, warnings)"]

    CT -- "emits $.calls" --> CURRENT
    BLOCKS --> CURRENT
    BIND -- "init_select / select_option /<br/>without_reactive_context" --> CURRENT
    CURRENT --> FB
    CURRENT --> RT
    CURRENT --> FX
    CURRENT --> LOOP
    CURRENT --> LEGACY
    CURRENT -. "transition/animation config fns" .-> TRANS
    CURRENT -. "warnings / dev hooks" .-> DEV
    LIFE -- "attaches root delegation listeners,<br/>should_intro flag" --> CURRENT
```

### 2.2 Internal composition

```mermaid
flowchart LR
    subgraph ELEMENTS["dom/elements/"]
        ATTR["attributes.js<br/>attribute_effect · set_attributes · set_attribute<br/>set_value/set_checked · set_custom_element_data"]
        EVTS["events.js<br/>event · create_event · delegate<br/>handle_event_propagation · replay_events · apply"]
        TRAN["transitions.js<br/>transition · animation · animate · linear"]
        CE["custom-element.js<br/>create_custom_element · SvelteElement<br/>create_slot · get_custom_elements_slots"]
        MISC["misc.js<br/>autofocus · remove_textarea_child<br/>add_form_reset_listener"]
    end

    ATTR -- "on* keys → create_event / delegate" --> EVTS
    ATTR -- "attach (ATTACHMENT_KEY)" --> CE
    ATTR -- "class / style keys" --> CLSSTYLE["class.js · style.js<br/>(set_class / set_style)"]
    MISC -- "autofocus / form-reset" --> ATTR
    EVTS -- "without_reactive_context" --> BIND
```

---

## 3. Attribute System (`attributes.js`)

### 3.1 Core concepts

* **`element.__attributes` cache** — `get_attributes(element)` lazily creates a per-element record used as a *memo of last-applied values* plus two internal markers: `IS_CUSTOM_ELEMENT` (name contains `-`) and `IS_HTML` (namespace check). Every setter compares against this cache to skip no-op DOM writes.
* **`CLASS` / `STYLE` symbols** — `class:foo` and `style:bar` directives are passed to `set_attributes` under these symbols so directive state can be diffed independently of the string `class`/`style` attribute values.
* **Property vs. attribute** — values are applied as DOM *properties* when the element prototype exposes a setter for the name (see `get_setters`), otherwise as attributes via `element.setAttribute`. Attributes with `null`/`undefined` are removed.

### 3.2 `attribute_effect` — the reactive entry point

`attribute_effect(element, fn, sync, async, css_hash, skip_warning)` is emitted for **every dynamic attribute** on a regular element (single attributes, spreads, and combinations thereof):

```mermaid
sequenceDiagram
    participant C as Compiled element code
    participant AE as attribute_effect
    participant B as block() (reactivity)
    participant SA as set_attributes
    participant DOM as DOM Element
    participant SEL as bindings/select.js
    participant ATT as attachments.js

    C->>AE: attribute_effect(el, fn, sync_deps, async_deps, hash)
    AE->>AE: flatten(sync, async) — await async deps
    AE->>B: block(() => diff)
    loop On every dependency change
        B->>B: fn(...values.map(get)) → next object
        B->>SA: set_attributes(el, prev, next, css_hash)
        SA->>DOM: property/attribute/class/style/event mutations
        alt element is SELECT with value
            B->>SEL: select_option(el, next.value)
        end
        loop symbol keys in next
            alt symbol is ATTACHMENT_KEY
                B->>ATT: attach(el, () => value) in branch()
            else stale attachment symbol
                B->>B: destroy_effect(effects[symbol])
            end
        end
        B->>B: prev = current (returned diff state)
    end
    AE->>SEL: effect → select_option(prev.value, true) + init_select
```

Key behaviours:

* `flatten` (from `client_runtime_core_async`) allows `attribute_effect` to work with async dependencies (await-expressions in templates).
* A dedicated `effect` re-applies the select value *after* options have mounted and calls `init_select` (provided by [client_dom_renderer_bindings](client_dom_renderer_bindings.md)).
* Attachments (`{@attach ...}`) arrive as symbol-keyed entries flagged with `ATTACHMENT_KEY`; each is mounted in its own `branch()` so it can be destroyed independently when replaced.

### 3.3 `set_attributes` — the spread diff engine

`set_attributes(element, prev, next, css_hash, skip_warning)` mutates `next` in place and returns it as the new `prev`. The per-key resolution order is:

```mermaid
flowchart TD
    K([key in next]) --> OPT{option element<br/>value == null?}
    OPT -- yes --> OVAL["element.value = __value = ''"]
    OPT -- no --> CLS{key === 'class'?}
    CLS -- yes --> SC["set_class(el, is_html, value, css_hash,<br/>prev[CLASS], next[CLASS])<br/>(class.js)"]
    CLS -- no --> STY{key === 'style'?}
    STY -- yes --> SS["set_style(el, value, prev[STYLE], next[STYLE])<br/>(style.js)"]
    STY -- no --> UNCH{value === prev_value<br/>and not (undefined + attr present)?}
    UNCH -- yes --> SKIP([skip — no-op])
    UNCH -- no --> PP{prefix 'on'?}
    PP -- yes --> EVT["event handling<br/>(see §4.3)"]
    PP -- no --> AF{key === 'autofocus'?}
    AF -- yes --> AFH["misc.autofocus()"]
    AF -- no --> VAL{!custom &&<br/>('__value' or 'value')?}
    VAL -- yes --> VSET["element.value = element.__value = value"]
    VAL -- no --> SELD{selected on option?}
    SELD -- yes --> SS2["set_selected()"]
    SELD -- no --> NULLV{value == null and<br/>not custom / default*?}
    NULLV -- yes --> RM["removeAttribute — preserving<br/>defaultValue/defaultChecked for<br/>value/checked removals"]
    NULLV -- no --> DEF{defaultValue/<br/>defaultChecked?}
    DEF -- yes --> PROP["assign as property<br/>(is_default branch)"]
    DEF -- no --> SETTER{setter exists and<br/>(custom or non-string value)?}
    SETTER -- yes --> PROP
    SETTER -- no --> ATTR["set_attribute(el, name, value)"]
```

Notable edge cases encoded here:

* **`<option value={null}>`** — setting/removing is special-cased because the `value` attribute falls back to text content; the code intentionally documents a known, accepted edge case.
* **Removing `value`/`checked`** — `removeAttribute('value')` also clears `defaultValue`, so the previous default is captured and restored (`use_default` distinguishes initial mount from update).
* **Custom elements** — `IS_CUSTOM_ELEMENT` disables Svelte's `__value` shortcut and null-removal heuristics so that author-defined accessors win; `IS_HTML` toggles attribute-name normalization (case preservation for non-HTML namespaces).

### 3.4 Property resolution & the setters cache

`get_setters(element)` walks the prototype chain from the instance up to (excluding) `Element.prototype`, collecting property keys that have setters, and caches the list per tag name (`setters_cache`). Two callers rely on it:

* `set_attribute` — applies non-string values as properties when a native setter exists (e.g. `input.value = 5` instead of `setAttribute('value', '5')`).
* `set_custom_element_data` — deliberately **refuses to compute setters for unregistered custom elements** (checking `customElements.get(...)`), because upgrade could add new accessors; it falls back to "object → property, otherwise `set_attribute(String(value))`". It also detaches the active reaction/effect (`set_active_reaction(null)` etc.) and pauses hydration so that a foreign element's lifecycle code cannot leak into Svelte's reactive bookkeeping.

### 3.5 Specialized setters

| Function | Purpose |
|---|---|
| `set_value` / `set_checked` | Property writes for `value`/`checked` with cache-based no-op detection; `null`/`undefined` are normalized for initial values; `progress` elements always receive `0`. |
| `set_selected` | Sets/removes the `selected` **attribute** (not property) on `<option>` so form resets reflect it. |
| `set_default_value` / `set_default_checked` | Write `defaultValue`/`defaultChecked` without disturbing the live `value`/`checked` (SSR `value`/`checked` attributes map to these). |
| `remove_input_defaults` | During **hydration**: strips server-rendered `value`/`checked` attributes (queued as an idle task for performance) while preserving live values, registers `input.__on_r` and the form-reset listener so a user-initiated form reset doesn't resurrect stale defaults. |
| `set_xlink_attribute` | SVG namespaced attributes via `setAttributeNS(.../1999/xlink ...)`. |
| `set_attribute` | Generic setter; while **hydrating** it first records the server value into `__attributes`, and deliberately *skips* `src`, `srcset`, and `href` on `<link>` (re-setting them would re-trigger network requests). Dev mode compares resolved URLs (`src_url_equal`, `srcset_url_equal`) and emits `hydration_attribute_changed` warnings on real mismatches. The `loading` attribute is mirrored to `LOADING_ATTR_SYMBOL` for lazy-loading coordination. |

### 3.6 Hydration touchpoints

```mermaid
flowchart LR
    HYD["hydration.js — hydrating flag"] --> RM["remove_input_defaults<br/>(idle task + __on_r)"]
    HYD --> TA["misc.remove_textarea_child<br/>(textarea children = defaultValue)"]
    HYD --> SA["set_attributes / set_attribute<br/>(record server values, skip src/srcset/href)"]
    HYD --> CE["set_custom_element_data / set_attributes<br/>(pause hydration around CE lifecycle)"]
    RM --> FR["add_form_reset_listener<br/>(capture-phase 'reset' → __on_r)"]
```

---

## 4. Event System (`events.js`)

### 4.1 Two registration models

1. **Delegated events** (`on:click` for a curated set of common events — `is_delegated` from the compiler's shared `utils.js`): no per-element listener is attached. The handler is stored on the element as `element.__<eventname>`, and `delegate([event_name])` registers the name in `all_registered_events`. The lifecycle API ([client_dom_renderer_lifecycle_api](client_dom_renderer_lifecycle_api.md)) attaches **one root-level listener per registered event** via `root_event_handles` callbacks when an app mounts.
2. **Direct events** (`capture`/`passive` modifiers, non-delegated names, `window`/`document`/`<body>`/media targets, programmatic `on()`): a real `addEventListener` is created through `create_event`; for global targets (and media elements, which can keep firing after removal in Firefox) a `teardown` effect removes the listener on effect destruction.

### 4.2 `create_event` / `event` / `on`

`create_event(event_name, dom, handler, options)` wraps the user handler in `target_handler`, which:

* runs `handle_event_propagation` (bubble phase only) so delegated handlers fire *before* non-delegated ones preserve ordering;
* invokes the user handler wrapped in `without_reactive_context` ([client_dom_renderer_bindings](client_dom_renderer_bindings.md) — handlers must never run inside an unrelated reaction/effect);
* **defers listener attachment** via `queue_micro_task` for `pointer*`, `touch*`, and `wheel` events — a workaround for a Chrome bug with `cloneNode`-ed, disconnected elements.

`event(...)` is what the compiled `on:click={handler}` emits (built by the compiler's `OnDirective` visitor, including `capture`/`passive` modifiers). `on(...)` returns an unsubscribe function and is used by programmatic/attachment code so that programmatic listeners keep correct ordering relative to delegated ones.

### 4.3 Event delegation flow

```mermaid
sequenceDiagram
    participant U as User interaction
    participant R as Root listener<br/>(document/window)
    participant H as handle_event_propagation
    participant P as composedPath()
    participant E as Element.__event
    participant HND as User handler

    U->>R: event bubbles to root
    R->>H: handle_event_propagation.call(root, event)
    H->>H: last_propagated_event = event (Firefox GC guard)
    H->>P: path = event.composedPath()
    alt event.__root exists (nested apps / replays)
        H->>H: resume propagation at index of __root<br/>or bail if already handled
    end
    H->>H: define_property(event, 'currentTarget', getter → current node)
    H->>H: set_active_reaction(null); set_active_effect(null)
    loop walk path until cancelBubble / root / null
        H->>E: delegated = node['__' + event_name]
        alt delegated && (not disabled || target)
            E->>HND: fn.call(node, event [, ...data])
        end
        H->>P: parent = assignedSlot ?? parentNode ?? host
    end
    Note over H: errors: first rethrown sync,<br/>rest queued per-microtask
    H->>H: event.__root = root; delete event.currentTarget
    H->>H: restore previous reaction/effect
```

Important details:

* `event.__root` prevents **double dispatch** across nested mounted apps and programmatic re-dispatch of the same event object.
* `currentTarget` is a transient getter proxy — it is deleted after handling.
* Arrays stored under `__event` (`[fn, ...data]`) support handlers with bound extra data.
* The entire walk runs with the reactive context cleared, so a synchronous `blur` triggered by DOM removal (Chromium) cannot execute user code inside a foreign reaction.

### 4.4 Spread-attribute event wiring (`set_attributes` `on*` branch)

For keys starting with `on` inside `set_attributes`:

* If **delegated**: set `element['__' + name] = value` and call `delegate([name])` (or clear it when `value == null`).
* If **direct**: swap semantics matter — when replacing a handler with another handler, the old listener is **kept** (only the closure target `current[key]` changes) because browsers can "swallow" events during remove/add (issue #11903); when the handler becomes `null`, the listener is removed via the stored `$$event` handle key (`'$$' + key`).

### 4.5 SSR event replay

During SSR, Svelte plants `onload`/`onerror` attributes plus a captured `dom.__e` event so that errors occurring *before hydration* are not lost. `replay_events(dom)` — called by hydration scaffolding — removes the attributes and re-dispatches the captured event in a microtask if the element is still connected (see [server_runtime](server_runtime.md) for the server-side counterpart).

### 4.6 Dev-mode handler validation (`apply`)

`apply(thunk, element, args, component, loc, has_side_effects, remove_parens)` is emitted around handler expressions in dev builds. It:

* catches throws while evaluating the handler expression,
* warns (`event_handler_invalid`) when the result is not a function — suggesting either *"remove the trailing `()`"* (user called the handler) or *"add a leading `() =>`"* — including file/line/phase info via `FILENAME`,
* re-throws evaluation errors, and finally invokes the handler with `element` as `this`.

---

## 5. Transitions & Animations (`transitions.js`)

The public CSS transition/animation functions (`fade`, `fly`, `flip`, …) live in [transitions_and_animations](transitions_and_animations.md); this module provides the **runtime managers** that the compiled output drives.

### 5.1 `transition(flags, element, get_fn, get_params)`

Creates a `TransitionManager` (`{ is_global, in(), out(fn), stop() }`) and pushes it onto `active_effect.transitions`. The effect machinery ([client_runtime_core_effects](client_runtime_core_effects.md)) later calls `in()`/`out(fn)` from `resume_effect`/`pause_effect`.

```mermaid
stateDiagram-v2
    [*] --> Registered: transition() pushes manager<br/>onto active_effect.transitions
    Registered --> Intro: resume_effect → in()
    Registered --> Outro: pause_effect → out(fn)
    Intro --> IntroRunning: animate(el, opts, outro, t=1)
    Outro --> OutroRunning: element.inert = true<br/>animate(el, opts, intro, t=0, fn)
    IntroRunning --> IntroRunning: outro.abort() + reset if re-intro
    IntroRunning --> Idle: introend → abort, restore overflow
    OutroRunning --> Destroyed: outroend → fn() (destroy branch)
    Idle --> Intro
    Idle --> Outro
    Destroyed --> [*]
```

Key mechanics:

* **Flags** decode `|in|out|global` (`TRANSITION_IN/OUT/GLOBAL`); local intros only auto-play if the owning *block* effect has already run — the code walks the effect tree skipping `EFFECT_TRANSPARENT` blocks (snippets, else-if) to find the nearest block effect.
* **`element.inert`** is set during outros so invisible elements can't be interacted with; `introstart`/`introend`/`outrostart`/`outroend` CustomEvents are dispatched outside the reactive context.
* **Option memoization** (`current_options`) ensures reversible transitions (e.g. `crossfade`) resume smoothly from the counterpart's current progress instead of restarting.
* The **Safari <18 overflow workaround** (`overflow: hidden` inline style during animations whose CSS uses it) is scheduled for removal in 6.0.

### 5.2 `animate()` — the Web Animations engine

`animate(element, options, counterpart, t2, on_finish)` returns a facade `{ abort, deactivate, reset, t }`:

* **Deferred transitions** (option *function*, e.g. `crossfade`) are resolved in a microtask after the DOM updates; the facade forwards lifecycle calls to the eventual real animation (everything stays synchronous for callers).
* A **dummy zero/delay animation** with `fill: 'forwards'` keeps CSS keyframes from being created before the DOM commit.
* Real keyframes are generated from `css(t, u)` sampling (`css_to_keyframe`, ~60fps granularity, easing applied) and played with `element.animate()`.
* **Bidirectional reversal** starts from `counterpart.t()` so in↔out switches are continuous.
* `tick(t, u)` callbacks are driven by `loop()` from [client_runtime_core_runtime](client_runtime_core_runtime.md).
* `abort()` cancels, nulls `effect` (Chromium leak), and neutersonfinish; `deactivate()` neuters `on_finish` for superseded counterparts.

### 5.3 `animation(element, get_fn, get_params)` — flip for keyed each blocks

Attaches an animation manager to `current_each_item` (`item.a` from [client_dom_renderer_control_flow_blocks](client_dom_renderer_control_flow_blocks.md)) with four hooks used by the each-block reconciliation:

| Hook | Role |
|---|---|
| `measure` | Capture the element's `DOMRect` *before* DOM mutation. |
| `fix` | Pin the element with `position: absolute` + translated transform (skipped if a Web Animation is already running, whose styles would take precedence) so layout shifts don't flicker. |
| `apply` | Capture the new rect, build an `AnimateFn` config via `get_fn()(element, {from, to}, params)` (e.g. `flip`), and run it through `animate(...)`. |
| `unfix` | Restore the stashed inline styles. |

For `<svelte:element>` tag swaps, an existing manager's `element` is re-pointed rather than recreated.

`linear` is the identity easing used when a transition config omits `easing`.

---

## 6. Custom Elements (`custom-element.js`)

### 6.1 Class model

```mermaid
classDiagram
    class HTMLElement
    class SvelteElement {
        +$$ctor Component constructor
        +$$s string[] slot names
        +$$c component instance
        +$$cn boolean connected
        +$$d Record~string,any~ props data
        +$$r boolean reflecting
        +$$p_d Record~string,PropDef~ prop definitions
        +$$l Record~string,Listener[]~ pre-mount listeners
        +$$l_u Map unsubscribe fns
        +$$me effect_root reflection handle
        +connectedCallback()
        +disconnectedCallback()
        +attributeChangedCallback(attr, old, new)
        +addEventListener(type, listener, opts)
        +removeEventListener(type, listener, opts)
        -$$g_p(attr) string
    }
    class CustomElementClass {
        +observedAttributes$ string[]
        +prop accessors (get/set)
        +export accessors (get)
    }
    HTMLElement <|-- SvelteElement
    SvelteElement <|-- CustomElementClass
    CustomElementClass ..> SvelteComponent : createClassComponent
```

### 6.2 Lifecycle

```mermaid
flowchart TD
    DEF["create_custom_element(Component, props_definition,<br/>slots, exports, use_shadow_dom, extend)"] --> CLASS["defines class extending SvelteElement:<br/>observedAttributes, prop accessors (proxy to $$c<br/>respecting instance accessors, else $set),<br/>export getters, optional extend(Class)"]
    CLASS --> ATT["Component.element = Class"]
    ATT --> UP["customElements.define(...) (user)"]
    UP --> CONN["connectedCallback"]
    CONN --> TICK["await one microtask — let child<br/>slot elements mount first"]
    TICK --> SLOTS["get_custom_elements_slots(this)<br/>→ create <slot> renderers (template.append)"]
    SLOTS --> ATTRS["read attributes + pre-set programmatic props<br/>→ $$d via get_custom_element_value(toProp)"]
    ATTRS --> MOUNT["createClassComponent({component, target:<br/>shadowRoot ?? this, props: $$d + $$slots + $$host})<br/>(legacy_compat)"]
    MOUNT --> REFL["effect_root + render_effect:<br/>reflect $$c props → attributes<br/>(toAttribute conversions) guarded by $$r"]
    REFL --> LSTN["replay $$l listeners via $on"]
    CONN --> DISC["disconnectedCallback"]
    DISC --> MIC["microtask guard: DOM moves don't destroy"]
    MIC --> DEST["$destroy() + $$me() (teardown reflection)"]
```

Highlights:

* **Type conversion** (`get_custom_element_value`) maps between attribute strings and prop types: `Boolean` (presence ↔ boolean), `Object`/`Array` (JSON), `Number` (`+value`).
* **Attribute/prop aliasing** — `$$g_p` resolves an attribute name (possibly lowercased or remapped via `props_definition[key].attribute`) back to the canonical prop name; `attributeChangedCallback` ignores events fired by the reflection effect itself (`$$r` guard).
* **Dual event subscription** — because it's impossible to know upfront whether a DOM event name is also a component event, `addEventListener` forwards to both the native element *and* `instance.$on`, accepting a possible double-fire for name collisions.
* **Shadow DOM opt-in** — `attachShadow({ mode: 'open' })` in the constructor when configured via `<svelte:options customElement=... />`.
* **SSR/hydration safety** — `set_attributes`/`set_custom_element_data` pause hydration while touching custom elements so a Svelte-built inner custom element doesn't run block logic in hydration mode.

---

## 7. Miscellaneous Element Helpers (`misc.js`)

| Function | Behaviour |
|---|---|
| `autofocus(dom, value)` | Sets `dom.autofocus = true` and focuses it in a microtask **only if** `document.activeElement` is still `<body>` (avoids stealing focus from SSR-restored focus). |
| `remove_textarea_child(dom)` | Hydration-only: a textarea's text child maps to `defaultValue`, so it is cleared to keep form-reset behaviour correct. |
| `add_form_reset_listener()` | Idempotent capture-phase `document` `reset` listener; one tick later (after the browser applied reset values) it calls every registered `element.__on_r` (installed by `remove_input_defaults`) so live values don't revert to server-rendered defaults. |

---

## 8. Dependencies

### 8.1 Upstream (what this module consumes)

| Dependency | Used for | Provided by |
|---|---|---|
| `active_effect`, `active_reaction`, `set_active_effect/reaction`, `get` | Context isolation (custom elements, delegation, handlers) and reading signal values | [client_runtime_core](client_runtime_core.md) |
| `effect`, `block`, `branch`, `destroy_effect`, `teardown`, `effect_root`, `render_effect` | Reactive wrappers for attribute effects, attachments, reflection, listener cleanup | [client_runtime_core_effects](client_runtime_core_effects.md) |
| `flatten` | Async attribute dependencies | [client_runtime_core_async](client_runtime_core_async.md) |
| `loop` | `tick` callbacks for transitions | [client_runtime_core_runtime](client_runtime_core_runtime.md) |
| `hydrating`, `set_hydrating` | Hydration-aware attribute/CE handling | [client_dom_renderer_dom_foundation](client_dom_renderer_dom_foundation.md) |
| `init_select`, `select_option`, `without_reactive_context` | SELECT value sync; handler context isolation | [client_dom_renderer_bindings](client_dom_renderer_bindings.md) |
| `set_class`, `set_style` | `class`/`style` directive diffing | `dom/elements/class.js`, `dom/elements/style.js` |
| `attach` | `{@attach}` execution inside `attribute_effect` | `dom/elements/attachments.js` |
| `current_each_item` | Flip animation manager binding | [client_dom_renderer_control_flow_blocks](client_dom_renderer_control_flow_blocks.md) |
| `should_intro` | Whether local intros auto-play (mount/hydrate option) | [client_dom_renderer_lifecycle_api](client_dom_renderer_lifecycle_api.md) |
| `createClassComponent` | Instantiating components inside custom elements | [legacy_compat](legacy_compat.md) |
| `queue_micro_task`, `queue_idle_task` | Deferred listener attach, default-attribute stripping | `dom/task.js` |
| `is_delegated`, `is_capture_event`, `normalize_attribute`, `clsx` | Delegation tables and attribute normalization | shared compiler/utils modules |
| `w.*` warnings, `DEV` | Dev-mode diagnostics (`event_handler_invalid`, `hydration_attribute_changed`) | [client_dev_mode](client_dev_mode.md) |

### 8.2 Downstream (who consumes this module)

| Consumer | Usage |
|---|---|
| Compiled component output | `$.attribute_effect`, `$.event`, `$.transition`, `$.animation`, `$.set_custom_element_data`, `$.remove_textarea_child`, `$.replay_events`, `$.apply` — emitted by the client transform visitors (see [compiler_client_transform_elements_and_directives](compiler_client_transform_elements_and_directives.md)) |
| [client_dom_renderer_lifecycle_api](client_dom_renderer_lifecycle_api.md) | `mount`/`hydrate`/`unmount` attach root delegation listeners from `all_registered_events` / `root_event_handles`; `unmount`/branch teardown invokes transition `out()`s via the effect machinery |
| [client_dom_renderer_control_flow_blocks](client_dom_renderer_control_flow_blocks.md) | each-block reconciliation calls the flip hooks; branches trigger intro/outro managers |
| [client_dom_renderer_bindings](client_dom_renderer_bindings.md) | bindings build on `set_value`/`set_checked`/`set_attribute` semantics and `without_reactive_context` |
| [server_runtime](server_runtime.md) | Mirror implementation: SSR renders static attributes and plants the `onload`/`onerror` + `__e` payload that `replay_events` consumes |

---

## 9. Function Reference

### `attributes.js`

| Export | Signature (abridged) | Notes |
|---|---|---|
| `attribute_effect` | `(element, fn, sync?, async?, css_hash?, skip_warning?)` | Reactive `block()` around `set_attributes`; attachments + select handling. |
| `set_attributes` | `(element, prev, next, css_hash?, skip_warning?) → current` | Spread diff engine; handles events, class/style symbols, defaults, custom elements. |
| `set_attribute` | `(element, attribute, value, skip_warning?)` | Hydration recording; src/srcset/href skip; property fallback. |
| `set_value` / `set_checked` | `(element, value)` | Cache-guarded property writes. |
| `set_selected` | `(option, selected)` | `selected` **attribute** maintenance. |
| `set_default_value` / `set_default_checked` | `(input, value)` | SSR-mirrored defaults without touching live values. |
| `remove_input_defaults` | `(input)` | Hydration default stripping + `__on_r` reset hook. |
| `set_xlink_attribute` | `(dom, attribute, value)` | XLink namespace. |
| `set_custom_element_data` | `(node, prop, value)` | Context-isolated custom element property/attribute set. |
| `CLASS`, `STYLE` | `Symbol` | Directive diff keys for `set_attributes`. |

### `events.js`

| Export | Signature (abridged) | Notes |
|---|---|---|
| `event` | `(event_name, dom, handler?, capture?, passive?)` | Emitted for `on:` directives. |
| `create_event` | `(event_name, dom, handler?, options?) → target_handler` | Delegation call + context isolation + pointer/touch/wheel deferral. |
| `on` | `(element, type, handler?, options?) → () => void` | Programmatic listener with cleanup. |
| `delegate` | `(events: string[])` | Registers names + notifies `root_event_handles`. |
| `handle_event_propagation` | `(this: EventTarget, event)` | Delegation engine (§4.3). |
| `replay_events` | `(dom)` | SSR `onload`/`onerror` replay during hydration. |
| `apply` | `(thunk, element, args, component, loc?, ...)` | Dev-mode handler validation + invocation. |
| `all_registered_events`, `root_event_handles` | `Set<string>`, `Set<(events) => void>` | Consumed by root mounting. |

### `transitions.js`

| Export | Signature (abridged) | Notes |
|---|---|---|
| `transition` | `(flags, element, get_fn, get_params?)` | Intro/outro manager attached to the active effect. |
| `animation` | `(element, get_fn, get_params?)` | Flip manager bound to `current_each_item` (`measure/fix/apply/unfix`). |
| `linear` | `(t) => t` | Default easing identity. |

### `custom-element.js`

| Export | Signature (abridged) | Notes |
|---|---|---|
| `create_custom_element` | `(Component, props_definition, slots, exports, use_shadow_dom, extend?) → Class` | Custom-element factory; sets `Component.element`. |
| `create_slot` / `get_custom_elements_slots` | internal | `<slot>` renderers and child slot discovery. |

### `misc.js`

| Export | Signature (abridged) | Notes |
|---|---|---|
| `autofocus` | `(dom, value)` | Conditional focus on mount. |
| `remove_textarea_child` | `(dom)` | Hydration defaultValue fix. |
| `add_form_reset_listener` | `()` | Global capture-phase reset handler → `__on_r`. |

---

## 10. Design Notes & Invariants

1. **No reactive context in user event code.** Handlers, delegated walks, custom-element lifecycle, and transition option resolution all run with `active_reaction`/`active_effect` cleared — user code can never accidentally subscribe the surrounding effect.
2. **Minimal DOM writes.** Every setter path is guarded by memoized previous values (`__attributes`, `__className`, `__style`), so no-op updates cost one property comparison.
3. **Hydration must not re-fetch or clobber.** `src`/`srcset`/`href` are never rewritten while hydrating; server-rendered defaults are removed asynchronously and restored on form reset; textarea children are cleared.
4. **Delegation is the default.** Common events cost one root listener; direct listeners exist only for modifiers, global targets, and programmatic use — and handler replacement avoids remove/add ordering bugs (#11903).
5. **Transitions ride the effect tree.** Managers are stored on effects; lifecycle (intro/outro/destroy) falls out of the effect scheduler, with local-vs-global scoping derived from block-effect initialization state.
6. **Custom elements are firewalled.** Foreign element lifecycle code cannot corrupt Svelte's reaction/effect stack or prematurely populate the setters cache before `customElements` upgrade.
