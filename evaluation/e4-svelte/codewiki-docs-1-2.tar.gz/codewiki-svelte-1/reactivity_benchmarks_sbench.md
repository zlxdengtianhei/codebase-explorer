# reactivity_benchmarks_sbench

**Module:** `benchmarking/benchmarks/reactivity/sbench.js`
**Layer:** Repository_Engineering_Infrastructure → `reactivity_benchmarks` → `reactivity_benchmarks_sbench`
**Measured system:** Svelte 5 internal client runtime (`packages/svelte/src/internal/client/index.js`)

---

## 1. Purpose and Scope

`reactivity_benchmarks_sbench` is the **signal-graph creation benchmark suite** of the Svelte repository. It measures how fast the Svelte 5 reactive runtime can *allocate and register* the two fundamental building blocks of a signal graph:

- **Sources** — `$.state(v)` (a writable reactive value), and
- **Deriveds** — `$.derived(fn)` (a lazy computation node),

at scale (`COUNT = 1e5` per iteration) and across a controlled matrix of **fan-in / fan-out graph shapes** (1→1, 2→1, 4→1, 1000→1, 1→2, 1→4, 1→8, 1→1000), plus a raw signals-only baseline.

The suite is adapted from the [`js-reactivity-benchmark`](https://github.com/milomg/js-reactivity-benchmark) project (see the note in `benchmarking/benchmarks/reactivity/index.js`); the topology names and the `time` / `gc_time` reporting convention originate there. It reports two numbers per benchmark — wall-clock time and GC time attributable to the measured window — so that runtime changes affecting allocation pressure (not just raw speed) are visible.

**What it deliberately does *not* measure:** update propagation, recomputation and dependency-graph traversal after writes. Because Svelte 5 `Derived` nodes are lazy (see [§4.3](#43-what-is-and-is-not-measured)), the derived functions passed to `$.derived` are never executed in this suite — no `$.get` and no `$.set` calls occur at measurement time. Propagation-style workloads are covered by the sibling suites [reactivity_benchmarks_kairo](reactivity_benchmarks_kairo.md) and [reactivity_benchmarks_mol](reactivity_benchmarks_mol.md).

## 2. Module Facts

| Property | Value |
| --- | --- |
| Single source file | `benchmarking/benchmarks/reactivity/sbench.js` |
| Public surface | 10 exported `async` benchmark functions (`sbench_create_*`) |
| Result contract | `Promise<{ benchmark: string, time: string, gc_time: string }>` (milliseconds, `toFixed(2)`) |
| Core constant | `COUNT = 1e5` — deriveds (and ≈ edges) created per timed iteration |
| Harness dependency | `fastest_test` from `benchmarking/utils.js` |
| Measured dependency | `$.state`, `$.derived`, `$.get`, `$.effect_root` from `packages/svelte/src/internal/client/index.js` |
| Registered by | `reactivity_benchmarks` array in `benchmarking/benchmarks/reactivity/index.js` |
| Consumed by | `benchmarking/run.js` (suite totals) and the cross-branch comparison tool (see [benchmark_comparison_tooling](benchmark_comparison_tooling.md)) |

## 3. Architecture

### 3.1 Layered design

The file is organized as four internal layers wrapped around the runtime being measured:

1. **Entry-point layer** (`sbench_create_*`) — one exported async function per benchmark; owns the measurement protocol (JIT warm-up → sampled timing → result object).
2. **Topology-builder layer** (`create_computations_<A>to<B>`) — wires `n` deriveds to a pool of sources in a fixed ratio; also decides `count`/`scount` sizing.
3. **Primitive layer** (`create_data_signals`, `create_computation_0/1/2/4/1000`) — the only place that touches the runtime namespace `$`.
4. **Sizing helper** (`bench(fn, count, scount)`) — allocates `scount` sources and invokes a topology builder with `count`.

All runtime interaction is funneled through four `$` APIs, which keeps the module a clean *consumer* of the [client_runtime_core](client_runtime_core.md) internals:

| `$` API | Defined in | Role in this suite |
| --- | --- | --- |
| `$.state(v)` | `reactivity/sources.js::state` → `source` | Allocates a `Source` signal (plain object: `v`, `reactions`, `equals`, `rv`, `wv`). |
| `$.derived(fn)` | `reactivity/deriveds.js::user_derived` → `derived` | Allocates a lazy `Derived` node (`deps: null`, value `UNINITIALIZED`, `fn` stored). |
| `$.get(signal)` | `runtime.js::get` | Referenced only *inside* derived closures; registers dependencies lazily on first read (never fired here). |
| `$.effect_root(fn)` | `reactivity/effects.js::effect_root` | Creates an owned `ROOT_EFFECT \| EFFECT_PRESERVED` scope around each measured run and returns its `destroy()` handle. |

### 3.2 Architecture diagram

```mermaid
flowchart TB
    subgraph infra["Repository benchmarking infrastructure"]
        RUN["benchmarking/run.js<br/>suite runner, prints totals"]
        REG["benchmarks/reactivity/index.js<br/>reactivity_benchmarks registry"]
        CMP["benchmarking/compare/*<br/>cross-branch comparison"]
    end

    subgraph sbench["reactivity_benchmarks_sbench (this module)"]
        direction TB
        ENTRY["Entry points<br/>sbench_create_signals<br/>sbench_create_AtoB (9 topologies)"]
        BENCHFN["bench(fn, count, scount)<br/>sizing helper"]
        TOPO["Topology builders<br/>create_computations_AtoB(n, sources)"]
        PRIM["Signal primitives<br/>create_data_signals<br/>create_computation_0 / 1 / 2 / 4 / 1000"]
        ENTRY --> BENCHFN
        BENCHFN --> TOPO
        TOPO --> PRIM
    end

    subgraph harness["Timing harness — benchmarking/utils.js"]
        FT["fastest_test(times, fn)<br/>min-of-N sampling"]
        GT["run_tracked + GarbageTrack<br/>forced GC, gc-entry observation"]
        FT --> GT
    end

    subgraph runtime["Measured system: Svelte 5 internal client runtime"]
        STATE["$.state — sources.js"]
        DERIVED["$.derived — deriveds.js"]
        GET["$.get — runtime.js (lazy, unreached)"]
        EROOT["$.effect_root — effects.js"]
    end

    RUN --> REG
    CMP --> REG
    REG --> ENTRY
    ENTRY --> FT
    PRIM --> STATE
    PRIM --> DERIVED
    PRIM -.-> GET
    ENTRY --> EROOT
```

## 4. Benchmark Matrix

### 4.1 Topology naming convention

`create_computations_<A>to<B>` — **A** = sources captured per derived (fan-in), **B** = deriveds fed per source (fan-out). All graphs hold the number of *edges* (source references) at ≈ `COUNT` (1e5) while varying how those edges are distributed between derived allocation, source allocation and closure arity:

- **Fan-in variants** (`2to1`, `4to1`, `1000to1`): allocate all `COUNT` sources but fewer deriveds, each closing over more sources.
- **Fan-out variants** (`1to2`, `1to4`, `1to8`, `1to1000`): allocate `COUNT` deriveds but fewer sources, each shared by many deriveds.
- **Degenerate cases**: `0to1` (constant deriveds, zero sources — isolates derived-node allocation alone) and `sbench_create_signals` (baseline: sources only, no deriveds).

### 4.2 Benchmark table

| Exported benchmark | Topology builder | Fan-in (src/derived) | Fan-out (derived/src) | Deriveds / iteration | Sources / iteration | Isolates |
| --- | --- | --- | --- | --- | --- | --- |
| `sbench_create_signals` | `create_data_signals` | – | – | 0 | 1e5 × 100 loops | Raw `$.state` allocation throughput |
| `sbench_create_0to1` | `create_computations_0to1` | 0 | – | 1e5 | 0 | `Derived` node allocation without any source capture |
| `sbench_create_1to1` | `create_computations_1to1` | 1 | 1 | 1e5 | 1e5 | Baseline single-edge graph |
| `sbench_create_2to1` | `create_computations_2to1` | 2 | 1 | 5e4 | 1e5 | Wider closure arity per derived |
| `sbench_create_4to1` | `create_computations_4to1` | 4 | 1 | 2.5e4 | 1e5 | Wider fan-in still |
| `sbench_create_1000to1` | `create_computations_1000to1` | 1000 | 1 | 100 | 1e5 | Extreme single-closure fan-in (loop sum over 1000 sources) |
| `sbench_create_1to2` | `create_computations_1to2` | 1 | 2 | 1e5 | 5e4 | Shared sources, 2 deriveds each |
| `sbench_create_1to4` | `create_computations_1to4` | 1 | 4 | 1e5 | 2.5e4 | Shared sources, 4 deriveds each |
| `sbench_create_1to8` | `create_computations_1to8` | 1 | 8 | 1e5 | 1.25e4 | Shared sources, 8 deriveds each |
| `sbench_create_1to1000` | `create_computations_1to1000` | 1 | 1000 | 1e5 | 100 | Extreme shared source (1000 deriveds reading one source) |

### 4.3 Topology shapes (examples)

```mermaid
flowchart LR
    subgraph fanin["Fan-in example: sbench_create_4to1"]
        direction LR
        a0["state 0"] --> c0["derived 0"]
        a1["state 1"] --> c0
        a2["state 2"] --> c0
        a3["state 3"] --> c0
    end
    subgraph fanout["Fan-out example: sbench_create_1to4"]
        direction LR
        b0["state 0"] --> d0["derived 0"]
        b0 --> d1["derived 1"]
        b0 --> d2["derived 2"]
        b0 --> d3["derived 3"]
    end
```

### 4.4 What is (and is not) measured

Per the runtime implementation (`deriveds.js::derived`), a created `Derived` is a lazily-evaluated node: `deps: null`, value `UNINITIALIZED`, the user function merely *stored*. Since nothing in this suite ever reads the deriveds, the arrow functions (`() => $.get(s1)`) **never execute**, and `runtime.js::get`'s dependency-registration logic is never exercised. Consequently:

- ✅ Measured: `Source` / `Derived` node allocation, closure allocation and capture, `push_reaction_value` bookkeeping, effect-root ownership setup, and the GC cost of reclaiming 10 whole graphs per run.
- ❌ Not measured: derived computation, dirty-checking, dependency (`deps`) array construction via `$.get`, reaction-list wiring, batched propagation, effect teardown cost distribution.

Keep this in mind when interpreting regressions: a slowdown here points at allocation-heavy paths in [client_runtime_core_sources](client_runtime_core_sources.md) and [client_runtime_core_deriveds](client_runtime_core_deriveds.md), not at propagation logic ([client_runtime_core_batching](client_runtime_core_batching.md), [client_runtime_core_runtime](client_runtime_core_runtime.md)) — use the kairo suite for the latter.

## 5. Measurement Methodology

### 5.1 Execution sequence

Every exported benchmark follows the identical protocol:

```mermaid
sequenceDiagram
    autonumber
    participant S as sbench_create_AtoB
    participant F as fastest_test (utils.js)
    participant T as run_tracked + GarbageTrack
    participant R as runtime state/derived

    Note over S: 3 untimed JIT warm-up loops
    S->>F: await fastest_test(10, measured)
    loop 10 samples
        F->>T: run_tracked(measured)
        T->>T: v8.collectGarbage()
        T->>T: t0 = performance.now()
        T->>S: invoke measured()
        S->>R: allocate sources and deriveds
        Note over S,R: computation benchmarks run 10<br/>topology copies inside ONE<br/>$.effect_root, then destroy()
        S-->>T: done
        T->>T: t1 = performance.now()
        T-->>F: { time: t1-t0, gc_time: observed GC }
    end
    F-->>S: fastest sample (min time)
    S-->>S: return { benchmark, time, gc_time }
```

### 5.2 Timing pipeline details

The harness lives in `benchmarking/utils.js` (logic credited to `js-reactivity-benchmark`):

1. **`fastest_test(times, fn)`** — runs the measured function `times` (10) times, keeps the sample with the lowest wall-clock time (min-of-N reduces noise).
2. **`run_tracked(fn)`** — per sample: calls `v8.collectGarbage()` first so heap state is comparable; times `fn()` with `performance.now()`.
3. **`GarbageTrack`** — a `PerformanceObserver` on the `'gc'` entry type records GC pauses; the GC time *overlapping the measured window* `[start, end)` is summed after a 10 ms settle delay and reported as `gc_time`.
4. **Ownership & reclamation** — computation benchmarks wrap all 10 inner topology copies in a single `$.effect_root(() => {...})` and invoke the returned `destroy()` immediately after, inside the timed window. This makes the whole graph garbage-collectable *within* the measured window, which is why `gc_time` is a meaningful first-class metric here. (`sbench_create_signals` skips the effect root — plain state allocation in 100 loops.)

### 5.3 Tuning constants

| Constant | Value | Purpose |
| --- | --- | --- |
| `COUNT` | `1e5` | Deriveds (≈ edges) created per `bench` invocation |
| Warm-up loops | 3 | Untimed; triggers JIT optimization before sampling |
| `fastest_test` samples | 10 | Tracked runs; the minimum is reported |
| Inner iterations (deriveds) | 10 | Topology copies per timed run, one shared `effect_root` |
| Inner loops (signals) | 100 | `create_data_signals(COUNT)` calls per timed run |

## 6. Result Contract and Downstream Consumers

Each benchmark resolves to:

```js
{ benchmark: 'sbench_create_1to1', time: '12.34', gc_time: '5.67' }
```

where `time` and `gc_time` are millisecond strings (`toFixed(2)`).

```mermaid
flowchart LR
    SB["sbench_create_* results<br/>{benchmark, time, gc_time}"] --> REG["reactivity_benchmarks array<br/>(reactivity/index.js)"]
    REG --> RUNJS["benchmarking/run.js<br/>per-suite and total time/gc_time"]
    REG --> CRUN["compare/runner.js<br/>results sent over IPC"]
    CRUN --> J[".results/&lt;branch&gt;.json"]
    J --> CIDX["compare/index.js<br/>ASCII bar charts,<br/>fastest branch per metric"]
```

- **`benchmarking/run.js`** iterates the `reactivity_benchmarks` registry, awaits each benchmark, logs its result and accumulates suite/total `time` / `gc_time`. Note it wraps the entire run in `$.push({}, true)` … `$.pop()` (client [context_api](context_api.md)), i.e. all benchmarks execute inside a synthetic component context — matching production component initialization.
- **Cross-branch comparison** ([benchmark_comparison_tooling](benchmark_comparison_tooling.md)): `compare/runner.js` re-runs only the reactivity suite in a child process per git branch, `compare/index.js` then prints, per benchmark and per metric, which branch was fastest with proportional bar charts.

## 7. Component Reference

### 7.1 Exported entry points (10)

All share the protocol of [§5](#5-measurement-methodology) and differ only in the topology builder, `count`, and `scount` passed to `bench`:

| Function | `bench(fn, count, scount)` invocation |
| --- | --- |
| `sbench_create_signals` | `bench(create_data_signals, COUNT, COUNT)` × 100 per timed run, no effect root |
| `sbench_create_0to1` | `bench(create_computations_0to1, COUNT, 0)` |
| `sbench_create_1to1` | `bench(create_computations_1to1, COUNT, COUNT)` |
| `sbench_create_2to1` | `bench(create_computations_2to1, COUNT / 2, COUNT)` |
| `sbench_create_4to1` | `bench(create_computations_4to1, COUNT / 4, COUNT)` |
| `sbench_create_1000to1` | `bench(create_computations_1000to1, COUNT / 1000, COUNT)` |
| `sbench_create_1to2` | `bench(create_computations_1to2, COUNT, COUNT / 2)` |
| `sbench_create_1to4` | `bench(create_computations_1to4, COUNT, COUNT / 4)` |
| `sbench_create_1to8` | `bench(create_computations_1to8, COUNT, COUNT / 8)` |
| `sbench_create_1to1000` | `bench(create_computations_1to1000, COUNT, COUNT / 1000)` |

### 7.2 Internal helpers

| Helper | Signature | Behavior |
| --- | --- | --- |
| `create_data_signals` | `(n, sources)` | Fills `sources[i] = $.state(i)` for `i < n`. |
| `create_computation_0` | `(i)` | `$.derived(() => i)` — constant derived, no source. |
| `create_computation_1` | `(s1)` | `$.derived(() => $.get(s1))` — single-source closure. |
| `create_computation_2` | `(s1, s2)` | `$.derived(() => $.get(s1) + $.get(s2))`. |
| `create_computation_4` | `(s1..s4)` | Sum of four sources. |
| `create_computation_1000` | `(ss, offset)` | Loop-sums `$.get(ss[offset + i])` for 1000 sources. |
| `create_computations_<A>to<B>` | `(n, sources)` | Topology builders; loop over sources/deriveds per [§4](#4-benchmark-matrix). |
| `bench` | `(fn, count, scount)` | `create_data_signals(scount, [])` then `fn(count, sources)`. |

## 8. Relationship to Other Modules

| Module | Relationship |
| --- | --- |
| [reactivity_benchmarks](reactivity_benchmarks.md) | Parent suite; this module is one of its three children, registered in `reactivity/index.js`. |
| [reactivity_benchmarks_kairo](reactivity_benchmarks_kairo.md) | Sibling suite focused on **propagation/update** graphs (owned/unowned variants). Complements sbench's creation focus. |
| [reactivity_benchmarks_mol](reactivity_benchmarks_mol.md) | Sibling suite (`mol_bench_owned` / `mol_bench_unowned`), also propagation-oriented. |
| [ssr_benchmarks](ssr_benchmarks.md) | The other top-level benchmark suite in `run.js`; SSR cost, not client reactivity. |
| [client_runtime_core](client_runtime_core.md) | The measured system. Specifically [client_runtime_core_sources](client_runtime_core_sources.md) (`$.state`), [client_runtime_core_deriveds](client_runtime_core_deriveds.md) (`$.derived`), [client_runtime_core_runtime](client_runtime_core_runtime.md) (`$.get`), [client_runtime_core_effects](client_runtime_core_effects.md) (`$.effect_root`), [client_runtime_core_signal_model](client_runtime_core_signal_model.md) (signal/equality semantics). |
| [context_api](context_api.md) | `run.js` pushes a synthetic component context around the whole suite (`$.push({}, true)` / `$.pop()`). |
| [benchmark_comparison_tooling](benchmark_comparison_tooling.md) | Consumes this suite's results for branch-vs-branch regression charts. |

## 9. Conventions for Extension

To add a new sbench benchmark:

1. **Implement the topology** as a `create_computations_<shape>(n, sources)` helper next to the existing ones, using only `$.state` / `$.derived` / `$.get`.
2. **Add the entry point** following the canonical template:
   ```js
   export async function sbench_create_<shape>() {
       for (let i = 0; i < 3; i++) bench(build_fn, COUNT_FACTOR, SCOUNT); // JIT warm-up
       const { timing } = await fastest_test(10, () => {
           const destroy = $.effect_root(() => {
               for (let i = 0; i < 10; i++) bench(build_fn, COUNT_FACTOR, SCOUNT);
           });
           destroy();
       });
       return {
           benchmark: 'sbench_create_<shape>',
           time: timing.time.toFixed(2),
           gc_time: timing.gc_time.toFixed(2)
       };
   }
   ```
3. **Register it** in the `reactivity_benchmarks` array in `benchmarking/benchmarks/reactivity/index.js` (sbench entries are grouped first, before kairo and mol).

Keep results shape-compatible — `run.js` and the comparison tool both do `Number(results.time)` / `Number(results.gc_time)` and rely on registry order for cross-branch result alignment (`results[0][i]` ↔ `results[1][i]`), so inserting a benchmark in the middle changes the index mapping between compared branches.

## 10. Interpretation Notes and Limitations

- **Creation-only signal.** Because `Derived` nodes are lazy (see [§4.4](#44-what-is-and-is-not-measured)), deltas in these numbers reflect allocation and bookkeeping cost in the signal model — value-clone cost of `push_reaction_value`, object shape of `Source`/`Derived`, ownership flags — not graph traversal or scheduling.
- **GC time is environment-sensitive.** `gc_time` depends on the V8 version, `v8-natives` availability (forced `collectGarbage`) and the `'gc'` PerformanceObserver hook; compare numbers only on identical environments.
- **Min-of-10 sampling.** The reported `time` is the *best* of 10 samples, which is friendly to noisy CI but optimistic relative to mean latency.
- **No dev-mode paths.** The suite imports the runtime directly (`src/internal/client`), not the built dist; `DEV`-gated instrumentation (tracing, ownership validation, `add_locations`) in [client_dev_mode](client_dev_mode.md) is not compiled in here unless flags are enabled externally.
