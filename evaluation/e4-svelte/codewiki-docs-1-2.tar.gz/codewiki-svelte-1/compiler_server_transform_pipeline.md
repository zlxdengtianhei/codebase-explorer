# Compiler Server Transform Pipeline (`compiler_server_transform_pipeline`)

> **Module scope**
> - `packages/svelte/src/compiler/phases/3-transform/server/visitors/Fragment.js` — the `Fragment` visitor
> - `packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/utils.js` — `process_children`, `build_attribute_value` (plus supporting exports `build_template`, `build_getter`, and the hydration anchor literals `block_open` / `block_close` / `empty_comment`)

---

## 1. Introduction

`compiler_server_transform_pipeline` is the **template-emission core of Svelte's server-side rendering (SSR) backend**. While the surrounding `compiler_server_transform` module provides one visitor per AST node type, this pipeline module owns the *output strategy*: it decides how a region of the component template becomes a stream of JavaScript statements that append HTML to the server render payload (`$$payload`).

The central idea of Svelte's SSR transform is:

> **Walk the analyzed AST and emit statements of the form `$$payload.out.push(<markup>)`, where static text is escaped and concatenated at compile time, and only genuinely dynamic values are evaluated at runtime (wrapped in `$.escape(...)`).**

This module implements that strategy through two cooperating pieces:

| Piece | Responsibility |
|---|---|
| `Fragment` visitor | Entry point for every fragment scope (root, block bodies, snippet bodies, component children). Normalizes the node list, hoists non-positional nodes, and assembles the final `BlockStatement` of emitted statements. |
| `shared/utils.js` utilities | The workhorse functions every server visitor uses to batch inline content (`process_children`), serialize attribute values (`build_attribute_value`), drain the template stream into payload statements (`build_template`), and resolve store subscriptions (`build_getter`). |

It is the server-side counterpart of the template machinery in [`compiler_client_transform`](compiler_client_transform.md): the client transform builds DOM template elements for hydration, whereas this pipeline produces direct serialization code.

---

## 2. Position in the Compiler Architecture

The module sits in **phase 3-transform** of the Svelte compiler, consuming the AST and analysis results produced by the front-end (see [`compiler_parser`](compiler_parser.md) and [`compiler_analyzer`](compiler_analyzer.md)) and emitting code that calls into the server runtime (see [`server_runtime`](server_runtime.md) under [Component Rendering Backends](Component_Rendering_Backends_\(Client_DOM___Server_SSR\).md)).

```mermaid
flowchart TB
    subgraph CORE["compiler_core — Compiler Infrastructure"]
        COMPILE["compile(source, options)"]
        BUILDERS["utils/builders.js (b.*)<br/>estree AST factories"]
    end

    subgraph FRONTEND["Compiler Front-End"]
        PARSE["1-parse (compiler_parser)<br/>source → AST"]
        ANALYZE["2-analyze (compiler_analyzer)<br/>scopes, bindings, expression metadata"]
    end

    COMPILE --> PARSE --> ANALYZE

    subgraph TRANSFORM["3-transform"]
        direction LR
        CLIENT["compiler_client_transform<br/>(DOM templates + reactivity)"]
        SERVER["compiler_server_transform<br/>(SSR output code)"]
    end

    COMPILE --> TRANSFORM

    subgraph PIPE["compiler_server_transform_pipeline (this module)"]
        FRAG["Fragment"]
        UTILS["process_children · build_attribute_value<br/>build_template · build_getter"]
    end

    SERVER -.-> PIPE
    ANALYZE -- "AST + scopes + metadata<br/>(evaluate → constant folding)" --> PIPE
    BUILDERS --> PIPE

    subgraph RUNTIME["server_runtime (Component Rendering Backends)"]
        HOOKS["$$payload.out / $.escape / $.stringify<br/>$.html / $.store_get / hydration anchors"]
    end

    PIPE -- "generated render code calls" --> RUNTIME
```

The pipeline is invoked by the compiler's orchestration in [`compiler_core`](compiler_core.md): `compile()` runs `parse → analyze_component → transform_component`, and the server transform walk dispatches each AST node to its visitor. Whenever a node's visitor needs to render *content* (children, branch bodies, snippet bodies), the dispatch funnels through this module.

---

## 3. Module Composition

```mermaid
flowchart LR
    subgraph THIS["compiler_server_transform_pipeline"]
        direction TB
        F["Fragment<br/>(visitors/Fragment.js)"]
        PC["process_children"]
        BAV["build_attribute_value"]
        BT["build_template"]
        BG["build_getter"]
        ANCH["block_open / block_close /<br/>empty_comment (anchor literals)"]
    end

    subgraph PARENT["3-transform/utils.js — parent module"]
        CN["clean_nodes"]
        IN["infer_namespace"]
    end

    subgraph INFRA["Compiler Infrastructure"]
        B["builders (b.block, b.template,<br/>b.quasi, b.call, …)"]
        TYPES["TransformState /<br/>ServerTransformState"]
    end

    subgraph SHARED["Shared runtime sources"]
        ESC["escape_html (escaping.js)"]
        HYD["internal/server/hydration.js<br/>BLOCK_OPEN / BLOCK_CLOSE / EMPTY_COMMENT"]
        SAN["sanitize_template_string"]
    end

    F --> CN
    F --> IN
    F --> PC
    F --> BT
    F --> ANCH
    F --> B
    PC --> ESC
    PC --> SAN
    BAV --> ESC
    ANCH -- "wraps constants from" --> HYD
    F --> TYPES
```

### Component reference

| Component | File | Kind | Summary |
|---|---|---|---|
| `Fragment` | `server/visitors/Fragment.js` | Visitor | Transforms an `AST.Fragment` into a `BlockStatement` of `init` statements followed by `$$payload.out` writes. |
| `process_children` | `server/visitors/shared/utils.js` | Utility | Walks child nodes, batching runs of `Text` / `Comment` / `ExpressionTag` into single `TemplateLiteral` pieces; recurses into structural nodes. |
| `build_attribute_value` | `server/visitors/shared/utils.js` | Utility | Converts an `AST.Attribute` value (boolean, static text, single expression, or mixed chunks) into an estree expression or template literal. |
| `build_template` | `server/visitors/shared/utils.js` | Utility | Drains the `state.template` stream into statements — `out.push(...)` (default) or `out <op>= ...` — merging adjacent string pieces. |
| `build_getter` | `server/visitors/shared/utils.js` | Utility | Rewrites store-subscription identifiers (`$store`) into `$.store_get(...)` calls; leaves other identifiers untouched. |
| `block_open` / `block_close` / `empty_comment` | `server/visitors/shared/utils.js` | Constants | Literal expressions wrapping the SSR hydration anchors from `internal/server/hydration.js` (e.g. `<!--$s-->`, `<!--/$s-->`, `<!---->`). |

### Transform state and context

Visitors operate on a state object threaded through the walk (based on `TransformState` from `3-transform/types.d.ts`, extended by the server transform; see [`compiler_server_transform`](compiler_server_transform.md) for the full visitor map). The fields most relevant to this pipeline:

| Field | Type | Role during SSR generation |
|---|---|---|
| `state.init` | `Statement[]` | Statements that must run *before* markup is emitted (const tags, snippet declarations, assignments). |
| `state.template` | `(Literal \| TemplateLiteral \| Statement)[]` | Ordered stream of markup pieces; consumed by `build_template`. |
| `state.namespace` | `'html' \| 'svg' \| 'mathml'` | Current serialization namespace, re-inferred per fragment via `infer_namespace`. |
| `state.preserve_whitespace` | `boolean` | Set inside `<pre>`/`<textarea>`; relaxes the whitespace normalization done by `clean_nodes`. |
| `state.skip_hydration_boundaries` | `boolean` | Set when the fragment's content is a single standalone component/render tag; block visitors then suppress anchor comments. |
| `state.scope` / `state.scopes` | `Scope` / `Map` | Used by `scope.evaluate` (constant folding in `process_children`) and `build_getter` (store subscriptions). |
| `state.analysis`, `state.options` | Analysis / options | Runes mode (const-tag ordering in `clean_nodes`), `preserveComments`, `hmr`, dev-mode flags. |
| `context.visit(node, state)` | function | Dispatches `node` to its visitor (walker entry point). |
| `context.path` | `SvelteNode[]` | Ancestor chain; `Fragment` uses `path.at(-1)` as the parent for namespace/whitespace decisions. |

---

## 4. The `Fragment` Visitor

`Fragment` is the hub of the pipeline. It is invoked for every fragment scope in the template and returns the block of code that renders that scope.

### Processing steps

```mermaid
flowchart TD
    A["Fragment(node, context)"] --> B["parent = context.path.at(-1)"]
    B --> C["infer_namespace(state.namespace, parent, node.nodes)"]
    C --> D["clean_nodes(...) →<br/>hoisted, trimmed, is_standalone, is_text_first"]
    D --> E["create fresh state:<br/>init: [], template: [],<br/>namespace, skip_hydration_boundaries = is_standalone"]
    E --> F["visit each hoisted node<br/>(ConstTag, DebugTag, SvelteBody/Window/Document/Head,<br/>TitleElement, SnippetBlock) → fills state.init"]
    F --> G{"is_text_first?"}
    G -- yes --> H["push empty_comment ('<!---->')<br/>to prevent text gluing across boundaries"]
    G -- no --> I
    H --> I["process_children(trimmed, context)"]
    I --> J["return b.block([...state.init,<br/>...build_template(state.template)])"]
```

1. **Parent & namespace resolution** — the parent node (`context.path.at(-1)`) and the node list are passed to `infer_namespace`, which decides between `html`, `svg`, and `mathml` based on parent element metadata and the namespaces of contained elements.
2. **Node normalization (`clean_nodes`)** — shared with the client transform (see [`compiler_client_transform`](compiler_client_transform.md)), this function:
   - removes comments unless `preserveComments` is set;
   - extracts *hoistable* nodes (`ConstTag`, `DebugTag`, `SvelteBody`, `SvelteWindow`, `SvelteDocument`, `SvelteHead`, `TitleElement`, `SnippetBlock`) whose output is position-independent;
   - normalizes whitespace (collapses runs to single spaces, trims fragment edges, applies `<pre>`/`<textarea>`/`select`/`tr`/`table`… and SVG-`text` exceptions);
   - computes two flags: `is_standalone` (the fragment is a single static `RenderTag`/`Component`, so hydration anchors are unnecessary) and `is_text_first` (the fragment begins with text, which needs a separating anchor comment).
3. **Hoisting** — hoisted nodes are visited *first*, with the fresh state. Their visitors push into `state.init` (declarations, assignments, function declarations), guaranteeing execution order: e.g. `{@const}` values and snippet functions exist before any markup referencing them is emitted.
4. **Content emission** — `process_children` turns the trimmed children into template pieces.
5. **Assembly** — `build_template` drains `state.template` into `$$payload.out.push(...)` statements, and the visitor returns `b.block([...state.init, ...build_template(state.template)])`. Parent constructs (e.g. `IfBlock` branches, `SnippetBlock` function bodies, `RenderTag`) embed this returned block.

### Sequence of a fragment render

```mermaid
sequenceDiagram
    participant V as Visitor dispatcher (server transform walk)
    participant F as Fragment
    participant U as clean_nodes / infer_namespace
    participant H as Hoisted-node visitors
    participant PC as process_children
    participant S as scope.evaluate
    participant E as child node visitors
    participant BT as build_template

    V->>F: Fragment(node, context)
    F->>U: resolve namespace, clean node list
    U-->>F: hoisted, trimmed, is_standalone, is_text_first
    F->>H: visit(hoisted) — writes to state.init
    F->>PC: process_children(trimmed, context)
    loop over consecutive Text / Comment / ExpressionTag
        PC->>S: evaluate(expression)
        alt statically known value
            S-->>PC: fold value into quasi (escaped at compile time)
        else dynamic
            PC->>E: visit(expression)
            PC->>PC: push $.escape(expr) into template literal
        end
    end
    PC-->>F: state.template filled (templates / literals / calls)
    F->>BT: build_template(state.template)
    BT-->>F: $$payload.out.push(...) statements
    F-->>V: b.block([...state.init, ...output statements])
```

---

## 5. Shared Utilities

All utilities live in `server/visitors/shared/utils.js` and are consumed by every visitor group of the server transform — elements ([`compiler_server_transform_elements`](compiler_server_transform_elements.md)), control flow ([`compiler_server_transform_control_flow`](compiler_server_transform_control_flow.md)), components ([`compiler_server_transform_components`](compiler_server_transform_components.md)), and JavaScript emission ([`compiler_server_transform_javascript`](compiler_server_transform_javascript.md)).

### 5.1 `process_children(nodes, context)`

Batches sibling inline nodes so that a run like `Hello {name}!` becomes **one** template literal instead of three output calls.

```mermaid
flowchart TD
    A["iterate nodes"] --> B{"Text / Comment /<br/>ExpressionTag?"}
    B -- yes --> C["append to pending sequence"]
    B -- no --> D{"sequence non-empty?"}
    D -- yes --> E["flush sequence →<br/>one b.template(quasis, expressions)"]
    D -- no --> G
    E --> G["visit(node, state)<br/>(visitor pushes its own pieces)"]
    G --> A
    C --> A
    A -- "done" --> H{"sequence non-empty?"}
    H -- yes --> E
    H -- no --> I["end"]
```

Flush behavior per sequence member:

| Node type | Emission |
|---|---|
| `Text` | `quasi.cooked += escape_html(node.data)` — **escaped at compile time**. |
| `Comment` | `quasi.cooked += '<!--' + data + '-->'` — preserved verbatim (only reached when `preserveComments` is on). |
| `ExpressionTag` (statically evaluable) | `scope.evaluate(...).value` folded into the quasi and escaped — zero runtime cost. |
| `ExpressionTag` (dynamic) | `$.escape(visit(expression))` pushed as a template expression — **escaped at runtime**. |

After building the quasis, each `cooked` value is passed through `sanitize_template_string` so the text can be safely embedded in the generated template literal (backticks, `${`, and newlines are neutralized). The resulting template piece is pushed onto `state.template`. Structural nodes flush the pending sequence first, then dispatch to their own visitor, which continues appending to `state.template` — this is what makes output from nested visitors merge seamlessly with surrounding text.

### 5.2 `build_attribute_value(value, context, trim_whitespace, is_component)`

Normalizes the four shapes an `AST.Attribute` value can take into a single expression:

```mermaid
flowchart TD
    A["AST.Attribute value"] --> B{"value === true?"}
    B -- yes --> R1["boolean literal true<br/>(valueless attribute)"]
    B -- no --> C{"single chunk?"}
    C -- "yes: Text" --> D{"trim_whitespace?"}
    D -- yes --> E["collapse whitespace runs,<br/>trim"]
    D -- no --> F
    E --> F{"is_component?"}
    F -- no --> G["literal escape_html(data, true)<br/>(attribute-context escaping)"]
    F -- yes --> H["raw literal<br/>(component props are values,<br/>not serialized HTML)"]
    C -- "yes: ExpressionTag" --> I["context.visit(chunk.expression)"]
    C -- "no: mixed array" --> J["b.template(...)<br/>static Text → quasis (optionally trimmed)<br/>dynamic chunks → $.stringify(visit(expr))"]
```

Two escaping regimes are worth noting:

- **Element attributes rendered as HTML** use `escape_html(data, true)` on static text (attribute mode also escapes quotes).
- **Multi-chunk values** produce a *JavaScript string* (the attribute's value), not directly serialized HTML: static text is inserted raw and dynamic parts become `$.stringify(...)` calls. HTML escaping happens later, when the attribute is serialized by the server runtime (`attr` / `spread_attributes`) — see [`server_runtime`](server_runtime.md).

### 5.3 `build_template(template, out = $$payload.out, operator = 'push')`

Converts the `state.template` stream into statements. It greedily merges adjacent string material (literals and template-literal chunks) and emits:

- `out.push(\`...\`)` — default mode (`operator = 'push'`), used by `Fragment` and most visitors;
- `out <op>= \`...\`` — e.g. `TitleElement` accumulates into `$$payload.title` via `build_template(template, b.id('$$payload.title'), '=')`.

Plain `Statement` entries interleaved in the stream first flush the pending string/expression buffer, then are emitted verbatim — this is how side-effect statements (e.g. dev-mode `$.push_element` tracking) keep their position relative to markup output.

### 5.4 `build_getter(node, state)`

Resolves identifiers with store bindings: a `$store` reference becomes

```js
$.store_get(($$store_subs ??= {}), '$store', store)
```

so stores are subscribed/unsubscribed correctly during server render. All other identifiers (no binding, or the declaration itself) are returned unchanged. It is consumed by the `Identifier` visitor in [`compiler_server_transform_javascript`](compiler_server_transform_javascript.md).

### 5.5 Hydration anchor literals

`block_open`, `block_close`, and `empty_comment` wrap the constants exported by `internal/server/hydration.js`:

| Constant | Approximate output | Used for |
|---|---|---|
| `block_open` | `<!--$s-->` | Opens an `if`/`each`/`await` block region so hydration can remove nodes on mismatch. |
| `block_close` | `<!--/$s-->` | Closes a block region; doubles as the block's anchor node. |
| `empty_comment` | `<!---->` | Separates adjacent text regions / anchors blocks without semantics. |

Control-flow visitors in [`compiler_server_transform_control_flow`](compiler_server_transform_control_flow.md) emit `block_open`/`block_close`; `Fragment` emits `empty_comment` when `is_text_first`. The `skip_hydration_boundaries` state flag (set from `is_standalone`) lets block visitors suppress these anchors when a single self-contained component/render tag makes them redundant.

---

## 6. Generated-Code Runtime Contract

The statements produced by this pipeline execute inside a server render function that receives the `$$payload` render output. The emitted code relies on the following runtime facilities, all provided by [`server_runtime`](server_runtime.md):

| Generated call / token | Runtime source | Purpose |
|---|---|---|
| `$$payload.out.push(str)` | render payload (`RenderOutput`) | Append serialized markup. |
| `$.escape(expr)` | server runtime | Runtime HTML-escaping of dynamic inline content. |
| `$.stringify(expr)` | `internal/server/index.js` (`stringify`) | Safe value stringification for (multi-chunk) attribute values. |
| `$.html(expr)` | `internal/server/blocks/html.js` | Render trusted `{@html ...}` content. |
| `$.store_get(...)` | `internal/server/index.js` | Store subscription during SSR. |
| `$.push_element` / `$.pop_element` | `internal/server/dev.js` | Dev-mode element location tracking. |
| `$.validate_snippet_args` | `internal/server/dev.js` | Dev-mode snippet argument validation (see `SnippetBlock` visitor). |
| `<!--$s-->` / `<!--/$s-->` / `<!---->` | `internal/server/hydration.js` | Hydration anchors for block matching. |

Escaping strategy summary:

- **Static text** → escaped once, at compile time (`escape_html`), then baked into the generated template literal.
- **Dynamic inline values** → wrapped in `$.escape(...)` at runtime.
- **Constant-foldable expressions** → evaluated by the analyzer's expression metadata (`scope.evaluate().is_known`) and treated as static text.
- **Attribute values** → single static chunks escaped at compile time; multi-chunk values are runtime strings escaped when serialized to HTML.

---

## 7. Worked Example

Input (component body):

```svelte
<p>Hi {name}, you have {count} {count === 1 ? 'message' : 'messages'}.</p>
```

Processing through the pipeline:

1. `RegularElement` (see [`compiler_server_transform_elements`](compiler_server_transform_elements.md)) pushes `<p>` and its (here static) attributes via `build_attribute_value`, then calls `process_children` on the cleaned children, and finally pushes `</p>`.
2. `process_children` batches `Hi `, `{name}`, `, you have `, `{count}`, ` `, `{count === 1 ? …}`, `.` into a single template piece — the two conditional expressions are dynamic, so each becomes `$.escape(...)`.
3. `build_template` merges the adjacent pieces (`<p>`, the batched template, `</p>`) into one `push` call.

Generated server code (simplified):

```js
function App($$payload, props) {
  $$payload.out.push(
    `<p>Hi ${$.escape(name)}, you have ${$.escape(count)} ${$.escape(count === 1 ? 'message' : 'messages')}.</p>`
  );
}
```

A fragment-scoped example (snippet body — the `Fragment` visitor's return value becomes the function body that `SnippetBlock` declares):

```svelte
{#snippet greeting(name)}
  Hello {name}, 2 + 2 = {2 + 2}!
{/snippet}
```

```js
function greeting($$payload, name) {
  $$payload.out.push(`Hello ${$.escape(name)}, 2 + 2 = 4!`);
}
```

Note the constant-folded `{2 + 2}`: `scope.evaluate` marks it known, so it is baked into the static text rather than emitted as a runtime expression. Hoisted statements are ordered before output — e.g. an `{@const doubled = count * 2}` in the fragment contributes `const doubled = count * 2;` to `state.init`, which is emitted before the `$$payload.out.push(...)` statements of the returned block.

---

## 8. Design Decisions & Invariants

1. **Compile-time vs runtime escaping.** Everything statically known is escaped and concatenated at build time; only truly dynamic expressions pay runtime cost via `$.escape`. Constant folding through analyzer expression metadata keeps the output minimal.
2. **Single batching pass.** Adjacent inline content is fused into one template literal per run, and `build_template` merges adjacent string material — minimizing the number of `$$payload.out.push` calls in generated code.
3. **`init` before template.** A fragment's returned block always emits `state.init` statements first. Hoisting `ConstTag`/`DebugTag`/snippets/title/head out of positional order is safe (they only declare/assign), and guarantees referenced values exist before markup is streamed.
4. **Whitespace fidelity shared with the client.** `clean_nodes` implements identical normalization for both transforms, so server-rendered HTML and client-built templates match structurally — a prerequisite for hydration. Exceptions (`<pre>`, `<textarea>`, `select` family, SVG `text`) are encoded there and honored via `state.preserve_whitespace`.
5. **Namespace threading.** `infer_namespace` propagates `html`/`svg`/`mathml` through fragment scopes (components, snippets, slots reset and re-evaluate it), keeping serialization and client-side template creation (`from_svg`, `from_mathml`) consistent.
6. **Minimal but sufficient anchors.** `is_text_first` inserts `<!---->` only where text could fuse across a boundary; `skip_hydration_boundaries` drops block anchors when a lone component/render tag makes them redundant. Hydration correctness is preserved with less noise in the HTML output.
7. **Attribute values are not markup.** Multi-chunk attribute values are emitted as runtime strings with `$.stringify` guards; HTML escaping is deferred to the attribute-serialization helpers of the server runtime, avoiding double-escaping.
8. **Location transparency.** Visitors never write to `$$payload` directly; they only append to `state.template` / `state.init` and let `build_template` choose the final output statement shape (including non-`out` targets such as `$$payload.title`).

---

## 9. Interaction with Other Modules

```mermaid
flowchart TB
    PIPE["compiler_server_transform_pipeline<br/>(Fragment + shared utils)"]

    subgraph SIB["compiler_server_transform — sibling visitor groups (consumers)"]
        ELEM["compiler_server_transform_elements<br/>RegularElement · SvelteElement · HtmlTag ·<br/>TitleElement · SvelteHead · SlotElement · SpreadAttribute"]
        CF["compiler_server_transform_control_flow<br/>IfBlock · EachBlock · AwaitBlock · KeyBlock<br/>(block_open/close anchors, branch = Fragment block)"]
        COMP["compiler_server_transform_components<br/>Component · SvelteComponent · SvelteSelf ·<br/>RenderTag · SnippetBlock (bodies = Fragment blocks)"]
        JS["compiler_server_transform_javascript<br/>Identifier (build_getter) · AssignmentExpression ·<br/>CallExpression · …"]
    end

    PARSE["compiler_parser — AST source"]
    ANALYZE["compiler_analyzer — scopes, bindings,<br/>expression metadata (evaluate)"]
    CORE["compiler_core — compile() orchestration,<br/>builders, options validation"]
    CT["compiler_client_transform —<br/>parallel pipeline, shared clean_nodes"]
    RT["server_runtime — $$payload, escape/stringify,<br/>hydration anchors"]

    PIPE --> ELEM
    PIPE --> CF
    PIPE --> COMP
    PIPE --> JS
    PARSE --> PIPE
    ANALYZE --> PIPE
    CORE --> PIPE
    CT -.->|"shared node normalization"| PIPE
    PIPE --> RT
```

| Relationship | Module | Notes |
|---|---|---|
| Parent | [`compiler_server_transform`](compiler_server_transform.md) | Visitor map, server state typedefs, per-node dispatch. |
| Consumers | [`compiler_server_transform_elements`](compiler_server_transform_elements.md), [`compiler_server_transform_control_flow`](compiler_server_transform_control_flow.md), [`compiler_server_transform_components`](compiler_server_transform_components.md), [`compiler_server_transform_javascript`](compiler_server_transform_javascript.md) | All template-emitting visitors funnel through `process_children` / `build_attribute_value` / `build_template` / `build_getter`. |
| Upstream | [`compiler_parser`](compiler_parser.md), [`compiler_analyzer`](compiler_analyzer.md) | Provide the AST, scopes and expression metadata consumed by `clean_nodes` and `scope.evaluate`. |
| Front-end overview | [Compiler Front-End](Compiler_Front-End_\(Parsing,_Analysis___CSS_Scoping_Pipeline\).md) | Full description of phases 1–2 and the CSS scoping pipeline. |
| Sibling backend | [`compiler_client_transform`](compiler_client_transform.md) | DOM-oriented counterpart; shares `clean_nodes`/`infer_namespace` from `3-transform/utils.js`. |
| Infrastructure | [`compiler_core`](compiler_core.md), [`compiler_types`](compiler_types.md), [`compiler_diagnostics`](compiler_diagnostics.md) | Orchestration (`compile`), `b.*` builders, AST type model, and diagnostics raised during earlier phases. |
| Runtime | [`server_runtime`](server_runtime.md) (in [Component Rendering Backends](Component_Rendering_Backends_\(Client_DOM___Server_SSR\).md)) | Implements every `$.xxx` hook and the `$$payload` output the generated code calls into. |
| Backend overview | [Compiler Back-End](Compiler_Back-End_\(Client___Server_Code_Generation\).md) | How client and server code generation relate. |

### Adding a new markup-emitting visitor

To stay compatible with the pipeline, a server visitor should:

1. push literal markup pieces into `context.state.template` (literals via `b.literal`, dynamic parts as expressions — inline expressions must be wrapped in `b.call('$.escape', ...)`);
2. push position-independent side effects into `context.state.init`;
3. render children through `process_children(cleaned_nodes, { ...context, state })`, obtaining `cleaned_nodes` from `clean_nodes` (shared with the client transform);
4. never touch `$$payload` directly — let `build_template` (usually invoked by `Fragment` or the element visitors) produce the final statements.