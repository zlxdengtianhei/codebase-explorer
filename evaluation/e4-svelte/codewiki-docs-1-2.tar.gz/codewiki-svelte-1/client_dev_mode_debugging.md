# client_dev_mode_debugging

> **Module scope:** `packages/svelte/src/internal/client/dev/{inspect,tracing,debug,console-log}.js`
> **Parent module:** `client_dev_mode` (dev-mode instrumentation of the [Reactive Runtime Engine](client_runtime_core.md))
> **Status:** Dev-only. All code in this module is gated behind the `DEV` compile-time flag and stripped from production bundles.

---

## 1. Introduction

`client_dev_mode_debugging` is the observability layer of Svelte 5's client runtime. While the rest of the runtime is optimized for size and speed, this module deliberately trades bundle size and performance for **developer insight**: it makes the otherwise-invisible signal graph, effect tree, and component state observable through the browser console.

It implements the runtime side of four developer-facing facilities:

| Facility | Public surface | Runtime entry point | File |
|---|---|---|---|
| Reactive value inspection | `$inspect(...)` / `$inspect(...).with(fn)` | `inspect()` | `inspect.js` |
| Signal labelling & dependency tracing | `$inspect.trace()` / automatic `$state` labels | `tag()`, `trace()`, `get_stack()` | `tracing.js` |
| Effect-tree introspection | internal tooling (`$.inspect` debug helpers) | `root()`, `log_effect_tree()` | `debug.js` |
| Live-proxy detection in console output | automatic rewrite of `console.*` calls | `log_if_contains_state()` | `console-log.js` |

None of these functions are meant to be called by application code directly; the [compiler client transform](compiler_client_transform.md) injects calls to them during dev builds.

---

## 2. Architecture Overview

The module sits **between** two worlds:

1. **Compile time** — the [Compiler Back-End (client transform)](compiler_client_transform.md) recognizes runes (`$inspect`, `$inspect.trace`) and specific call shapes (`console.*`) and rewrites them into `$.inspect`, `$.trace`, `$.tag`, `$.tag_proxy`, and `$.log_if_contains_state` calls.
2. **Runtime** — the functions hook into the reactive primitives exported by [client_runtime_core](client_runtime_core.md): signal sources/deriveds, the effect hierarchy, batching, and the proxy system.

```mermaid
flowchart TB
    subgraph CT["Compile Time — compiler_client_transform"]
        VD["VariableDeclaration visitor<br/>rewrites $state / $derived / $props"]
        CE["CallExpression visitor<br/>rewrites $inspect and console.*"]
    end

    subgraph MOD["client_dev_mode_debugging (internal/client/dev/)"]
        INSPECT["inspect.js<br/>inspect()"]
        TRACING["tracing.js<br/>tag() · tag_proxy() · trace() · get_stack()"]
        DEBUG["debug.js<br/>root() · log_effect_tree()"]
        CLOG["console-log.js<br/>log_if_contains_state()"]
    end

    subgraph CORE["client_runtime_core (runtime core)"]
        SRC["sources.js<br/>source() · set()"]
        EFF["effects.js<br/>inspect_effect · render_effect · effect_tracking"]
        RT["runtime.js<br/>active_reaction · untrack · flags"]
        PROXY["proxy.js / PROXY_PATH_SYMBOL"]
        FLAGS["internal/flags<br/>enable_tracing_mode_flag"]
    end

    SHARED["internal/shared/clone.js<br/>snapshot()"]
    WARN["internal/client/warnings.js<br/>console_log_state"]

    VD -->|"emits $.tag / $.tag_proxy"| TRACING
    CE -->|"emits $.inspect"| INSPECT
    CE -->|"wraps arguments"| CLOG

    INSPECT -->|"creates"| EFF
    INSPECT -->|"deep-copies values"| SHARED
    TRACING -->|"labels signals"| SRC
    TRACING -->|"stacks via Error()"| RT
    CLOG -->|"deep-copies state"| SHARED
    CLOG -->|"warns"| WARN
    SRC -->|"DEV: tag_proxy on writes"| PROXY
    SRC -->|"tracing mode: created stack"| FLAGS
    EFF --> RT
```

### Design principles

- **Zero production cost.** Every helper is `if (DEV)`-gated at *call sites*; tree-shaking removes the module entirely in prod builds (verified by `scripts/check-treeshakeability.js`).
- **Non-invasive.** Debug helpers wrap, but never replace, core reactive semantics. `log_if_contains_state` returns the original arguments; `inspect` reads state through the same `get()` used by user effects.
- **Console-native ergonomics.** Output uses `console.groupCollapsed`, colour styling, and preserved object identity (snapshots) so DevTools filtering and expand/collapse work as expected.

---

## 3. Component Reference

### 3.1 `inspect.js` — the `$inspect` rune

```js
function inspect(get_value: () => any[], inspector?: Function = console.log)
```

`inspect()` is the runtime implementation of `$inspect(a, b)` and its `.with(fn)` variant. The compiler's `CallExpression` visitor ([compiler_client_transform](compiler_client_transform.md)) lowers both to a single `$.inspect(() => [a, b], fn)` call.

**Behaviour:**

1. **Context validation** — `validate_effect('$inspect')` rejects usage outside component/effect initialization (orphan), inside unowned deriveds, or in teardown (see [client_runtime_core diagnostics](client_runtime_core.md)).
2. **Inspect effect** — creates an `INSPECT_EFFECT` via `inspect_effect()`. It is a synchronous effect: every reactive value read inside `get_value()` becomes a dependency, so the effect re-runs whenever that state changes and before the DOM updates. Synchronous execution is chosen so captured stack traces stay useful.
3. **Snapshotting** — values are deep-copied with `snapshot(value, true, true)` before logging. This *breaks reactivity* of the logged objects: the console shows the values at log time instead of live proxies that mutate after the fact. `no_tojson` is set to avoid surprising `toJSON` invocations.
4. **Untracked invocation** — the user inspector runs inside `untrack()` so a custom `inspector` that reads state does not accidentally add itself as a dependency.
5. **Error deferred-reporting** — because inspect effects run synchronously, `get_value()` may throw transiently (classic case: `$inspect(obj.prop)` lexically before the `{#if obj}` block that owns `obj`). The error is stored in `error` and forwarded to `console.error` by an adjacent **render effect** once reading succeeds again. If the inspect effect is destroyed first, the pending error is discarded (it is no longer relevant).

The paired `render_effect` deliberately calls `get_value()` too (ignoring the result) so that it is re-scheduled on exactly the same dependencies and runs *after* the inspect effect has had a chance to record the error.

### 3.2 `tracing.js` — signal labels and `$inspect.trace()`

This file is the bridge between the compiler-injected labels and the signal graph maintained by [client_runtime_core](client_runtime_core.md).

| Export | Purpose |
|---|---|
| `tag(source, label)` | Attaches a human-readable label to a signal (e.g. `let count = $state(0)` → label `"count"`). Delegates proxy labelling to `tag_proxy`. Emitted by the `VariableDeclaration` visitor for every `$state`/`$derived`/`async` declaration in dev builds. |
| `tag_proxy(value, label)` | Propagates labels into state proxies through `PROXY_PATH_SYMBOL`, enabling nested paths like `obj.nested.counter` in console output. Also invoked on every `set()` to a proxy in dev mode (see [client_runtime_core](client_runtime_core.md)). |
| `trace(label, fn)` | Runtime implementation of `$inspect.trace(() => ...)`. Wraps expression evaluation, records every signal read while active, and prints a grouped report. |
| `get_stack(label)` | Builds a sanitized `Error` whose stack has all `svelte/src/internal` frames removed (and names it `<label>Error` so DevTools renders it as a trace). Returns `null` when no user-relevant frames exist. |
| `tracing_expressions` | Module-level cursor. While non-null, `source()`/`derived` reads in the runtime core register `{ signal → TraceEntry }` records with `created`/`updated` stacks. |
| `label(value)` | Formats a value for console display (`Symbol(...)`, `<function>`, `<object>`, `String(value)`). |

**`trace()` execution model:**

```mermaid
flowchart TD
    A["$inspect.trace(() => expr)"] --> B["tracing_expressions = { entries, reaction }"]
    B --> C["fn() evaluated, timed with performance.now()"]
    C --> D{"signal read while cursor active?"}
    D -->|yes| E["runtime core records<br/>signal → { traces[] } entry"]
    E --> C
    D -->|done| F{"effect_tracking()?"}
    F -->|no| G["log: 'ran outside of an effect (Xms)'"]
    F -->|yes| H{"entries.size === 0?"}
    H -->|yes| I["log: 'no reactive dependencies (Xms)'"]
    H -->|no| J["console.group(label, Xms)<br/>log_entry() per dependency"]
    J --> K["restore previous tracing_expressions<br/>(supports nesting)"]
    G --> K
    I --> K
```

`log_entry(signal, entry)` renders each dependency as a collapsed console group, colour-coded by **dirtiness** (`signal.wv` version counter vs. the current reaction's version — bold `CornflowerBlue` when the dependency was dirty at read time), recursively expanding `$derived` dependencies, printing the `created` stack (captured by `source()` when tracing mode is enabled via `enable_tracing_mode_flag`) and any `updated` stacks recorded at write time.

Dependency *type* is derived from signal flags/label: `DERIVED | ASYNC` flags → `$derived`, a `$`-prefixed label → `store`, otherwise `$state`.

**Label propagation flow** (why every logged `$state` object shows as `count` instead of `Proxy`):

```mermaid
flowchart LR
    A["let count = $state(0)"] -->|"compiler: VariableDeclaration"| B["$.tag($.state(0), 'count')"]
    B --> C["source.label = 'count'"]
    A -->|"compiler"| D["$.tag_proxy($.proxy(obj), 'obj')"]
    D --> E["proxy registers PROXY_PATH_SYMBOL"]
    E -->|"any nested set()"| F["set() calls tag_proxy(new, source.label)"]
    F --> G["child proxies carry 'obj.nested…' labels"]
    C --> H["console output &amp; trace groups<br/>show readable names"]
    G --> H
```

### 3.3 `debug.js` — effect-tree introspection

| Export | Purpose |
|---|---|
| `root(effect)` | Walks `effect.parent` up to the `ROOT_EFFECT`. Anchors tree dumps and teardown scans. |
| `log_effect_tree(effect, depth)` | Recursively prints the live effect hierarchy: node kind resolved from flags (`root`, `boundary`, `block`, `async`, `branch`, `render effect`, `effect`), freshness status from `CLEAN`/`MAYBE_DIRTY` flags, the JS function, and each dependency via `log_dep` (which recursively expands `$derived` chains). The root call prints the originating callsite from `new Error().stack`. |

This is *developer tooling for Svelte maintainers* rather than a user feature: when debugging scheduler bugs, `log_effect_tree($.root(someEffect))` renders the whole dirty-checking landscape of a component at that instant. The flag constants it reads are the same ones defined in `#client/constants` and used by the [client runtime core](client_runtime_core.md) scheduler.

### 3.4 `console-log.js` — live-proxy detection in `console.*`

```js
function log_if_contains_state(method: string, ...objects: any[]): any[]
```

**Compile-time hook** (see [compiler_client_transform](compiler_client_transform.md)): in dev builds, the `CallExpression` visitor rewrites *any* `console.debug|dir|error|group|groupCollapsed|info|log|trace|warn(...)` call whose arguments may reference component state into:

```js
console.log(...$.log_if_contains_state('log', arg1, arg2));
```

**Runtime behaviour:**

1. Runs inside `untrack()` and a `try/catch` — debugging must never itself throw or alter reactivity.
2. Scans arguments for objects carrying `STATE_SYMBOL` (i.e. `$state` proxies).
3. If found: emits the `console_log_state` warning ("Your `console.log` contained `$state` proxies. Consider using `$inspect(...)` or `$state.snapshot(...)` instead"), then logs a `'%c[snapshot]'` line with deep snapshots so the values are frozen at log time.
4. **Returns the original arguments untouched**, so the surrounding `console.*` call behaves exactly as the developer wrote it.

```mermaid
sequenceDiagram
    autonumber
    participant Src as "console.log(count, extra)"
    participant Tr as "CallExpression visitor (dev build)"
    participant Rt as "log_if_contains_state"
    participant W as "warnings console_log_state"
    participant C as "DevTools console"

    Src->>Tr: source expression
    Tr->>Rt: $.log_if_contains_state('log', args…)
    Rt->>Rt: untrack( check STATE_SYMBOL per arg )
    alt state proxy present
        Rt->>W: warn (link to svelte.dev/e/console_log_state)
        Rt->>C: log('%c[snapshot]', deep snapshot of args)
    end
    Rt-->>Tr: original args (unchanged)
    Tr->>C: console.log(original args)
```

---

## 4. `$inspect` Lifecycle (end-to-end)

```mermaid
sequenceDiagram
    autonumber
    participant U as "User source"
    participant C as "Compiler (dev mode)"
    participant R as "Runtime — inspect.js"
    participant G as "Signal graph (runtime core)"
    participant I as "Inspector (console.log / custom)"

    U->>C: $inspect(count);
    C->>C: validate rune usage (2-analyze)
    C->>R: $.inspect(() => [count])
    R->>R: validate_effect('$inspect')
    R->>G: inspect_effect(get_value) — sync effect
    R->>G: render_effect(get_value) — error forwarder
    G-->>R: first run: value = get_value()
    R->>R: snapshot(value) — deep copy, break reactivity
    R->>I: inspector('init', …snap)
    Note over G: later: count changes → write schedules inspect effect
    G-->>R: re-run (synchronously, before DOM update)
    R->>R: snapshot(new values)
    R->>I: inspector('update', …snap)
    Note over R: transient read error? → stored,<br/>render_effect forwards to console.error,<br/>discarded if effect destroyed first
```

Key invariants:

- The inspect effect re-runs **synchronously before** the corresponding DOM updates, so each `update` report reflects the exact state that will be rendered.
- Setting state *inside* an inspect effect throws `state_unsafe_mutation` — `set()` in [sources.js](client_runtime_core.md) special-cases `INSPECT_EFFECT` even while untracking, because `.with()` inspectors are untracked.
- The `init` / `update` first argument lets custom inspectors (e.g. log formatters, test harnesses) distinguish mount from change.

---

## 5. Relationships to Other Modules

| Direction | Module | Relationship |
|---|---|---|
| Consumed by | [Compiler Back-End → client transform](compiler_client_transform.md) | Injects `$.inspect`, `$.tag`, `$.tag_proxy`, `$.trace`, `$.log_if_contains_state` call sites in dev builds; `$inspect` validity is enforced during [2-analyze](compiler_analyzer.md). |
| Built on | [client_runtime_core](client_runtime_core.md) | Uses signals (`Value`/`Derived`), `INSPECT_EFFECT`/`RENDER_EFFECT` creation, `active_reaction`, `untrack`, `effect_tracking`, proxy `PROXY_PATH_SYMBOL`, and the version counters (`wv`/`rv`) that drive dirtiness colouring and trace collection. |
| Shares utilities with | shared runtime (`internal/shared/`) | `snapshot()` deep-clone (also exposed to users as `$state.snapshot`) and `define_property`. |
| Raises diagnostics via | client warnings | `console_log_state` warning (formatted for `DEV`; link-only otherwise). |
| Sibling | [client_dev_mode_hmr](client_dev_mode_hmr.md) | HMR wrapping happens one level up; a re-mounted HMR instance creates fresh inspect effects, so `$inspect` output restarts with `init` after a hot swap. |
| Sibling | [client_dev_mode_validation](client_dev_mode_validation.md) | Validation helpers (`assign`, ownership validator, `validate_snippet_args`) are the "hard failure" half of dev-mode instrumentation; this module is the "observability" half. |
| Sibling | [client_dev_mode_locations](client_dev_mode_locations.md) | `add_locations` attaches source positions to elements — complementary to `get_stack()`'s call-site capture. |
| Gated by | [Cross-Runtime Platform Services / flags](shared_runtime.md) | `enable_tracing_mode_flag` turns on `created`/`updated` stack capture in `source()`; `DEV` gate removes everything in production. |

---

## 6. Usage Cheatsheet (what the developer sees)

```svelte
<script>
  let count = $state(0);            // dev: emitted as $.tag($.state(0), 'count')
  let doubled = $derived(count * 2); // dev: emitted as $.tag($.derived(…), 'doubled')

  $inspect(count, doubled);          // logs ('init', 0, 0) then ('update', …) on change
  $inspect(count).with((type, n) => {
    if (n > 10) { /* custom watcher */ }
  });

  $inspect.trace(() => count * 2);   // grouped report: deps, dirtiness, timing, stacks

  console.log(count);                // rewritten: warns + '[snapshot]' line in dev
</script>
```

Typical debugging scenarios supported:

- **"Why did this update?"** → `$inspect.trace()` around the expression; dirty/bold entries show which dependency changed; `created`/`updated` stacks show where the signal was born and written.
- **"Why is my logged object a Proxy / why did it change after logging?"** → the `console_log_state` warning nudges toward `snapshot`s, which `log_if_contains_state` supplies automatically.
- **"Which effects exist and what are they watching?"** → `log_effect_tree(root(effect))` dumps flags + status + deps for maintainers.

---

## 7. Maintenance Notes

- **Keep it tree-shakeable.** Never let production code paths reference these modules; the `check-treeshakeability` script guards this.
- **Never track inside debug output.** All console interaction in this module happens under `untrack()`; violating this would turn debug reads into reactive dependencies.
- **Stack sanitization contract.** `get_stack()` strips `svelte/src/internal` frames and bails out entirely inside `validate_each_keys` (its stack is not meaningful to users). Name errors `<label>Error` so DevTools render the stack.
- **Snapshot, don't log raw state.** Logging raw proxies in this module's own output would reintroduce the exact problem `console-log.js` warns about; hence every logged value goes through `snapshot(..., true)` or `(..., true, true)`.
