# Compiler Server Transform: Components Module

## 1. Introduction

The `compiler_server_transform_components` module is the part of Svelte's server-side (SSR) transform phase that compiles **component composition constructs** into plain JavaScript statements that write to the SSR payload. It covers five AST node types:

| AST Node | Svelte Syntax | Visitor |
|---|---|---|
| `Component` | `<Foo bar={x} />` | `Component` |
| `SvelteComponent` | `<svelte:component this={dyn} />` | `SvelteComponent` |
| `SvelteSelf` | `<svelte:self />` | `SvelteSelf` |
| `RenderTag` | `{@render name(args)}` | `RenderTag` |
| `SnippetBlock` | `{#snippet name(params)}...{/snippet}` | `SnippetBlock` |

Four of the five visitors (`Component`, `SvelteComponent`, `SvelteSelf`, and indirectly `RenderTag`/`SnippetBlock` interplay) funnel into a single shared builder — `build_inline_component` from `visitors/shared/component.js` — which serializes attributes, spreads, bindings, `let:` directives, slots, and CSS custom properties into a `Component($$payload, props)` call. `SnippetBlock` produces the snippet *functions* that `RenderTag` and component props later *call*.

All output is appended to `context.state.template` (the body of the generated server render function), `context.state.init` (top-of-function declarations), or `context.state.hoisted` (declarations hoisted out of the current block).

**Parent module:** [compiler_server_transform](compiler_server_transform.md) — the phase‑3 server transform, which owns the entry point, visitor dispatch and the `ComponentContext`/state contract this module consumes.

---

## 2. Position in the Compiler Pipeline

The server transform is the third phase of the Svelte compiler. By the time this module runs, the front end ([compiler_parser](compiler_parser.md) + [compiler_analyzer](compiler_analyzer.md)) has produced an analyzed AST enriched with metadata (scopes, `dynamic` flags, `can_hoist` markers) that this module relies on. Its output is consumed downstream by the [server_runtime](server_runtime.md) module at render time.

```mermaid
flowchart LR
    subgraph FrontEnd["Compiler Front-End"]
        P["compiler_parser<br/>(1-parse)"] --> A["compiler_analyzer<br/>(2-analyze)<br/>scopes · metadata · diagnostics"]
    end
    A --> AST["Analyzed AST<br/>(compiler_types)"]
    subgraph Transform["Phase 3 — Server Transform"]
        ST["compiler_server_transform<br/>(entry + dispatch)"] --> COMPS["<b>compiler_server_transform_components</b><br/>(this module)"]
        ST --> PIPE["compiler_server_transform_pipeline<br/>(Fragment, children)"]
        ST --> EL["compiler_server_transform_elements"]
        ST --> CF["compiler_server_transform_control_flow"]
        ST --> JS["compiler_server_transform_javascript"]
    end
    AST --> ST
    COMPS --> CODE["Generated render function<br/>(statements + template chunks)"]
    CODE --> RT["server_runtime<br/>($.css_props, $.spread_props,<br/>$.validate_snippet_args, …)"]
    RT --> HTML["HTML / payload output"]
```

Related back-end sibling: [compiler_client_transform](compiler_client_transform.md) performs the equivalent client-side work and mirrors this module's visitor structure.

---

## 3. Architecture

```mermaid
flowchart TD
    subgraph Visitors["This module (server/visitors)"]
        C["Component<br/><i>Component.js</i>"]
        SC["SvelteComponent<br/><i>SvelteComponent.js</i>"]
        SS["SvelteSelf<br/><i>SvelteSelf.js</i>"]
        RTV["RenderTag<br/><i>RenderTag.js</i>"]
        SB["SnippetBlock<br/><i>SnippetBlock.js</i>"]
    end

    subgraph Shared["Shared server builders"]
        BIC["build_inline_component<br/><i>shared/component.js</i>"]
        BAV["build_attribute_value<br/><i>shared/utils.js</i>"]
        EC["empty_comment<br/>(hydration anchor)"]
    end

    subgraph Infra["Infrastructure"]
        B["builders (b.*)<br/>estree factory"]
        ZF["zimmerframe Context<br/>(ComponentContext: visit / state)"]
        DEV["dev flag<br/><i>compiler/state.js</i>"]
        UO["unwrap_optional<br/><i>utils/ast.js</i>"]
    end

    C -->|"b.id(node.name)"| BIC
    SC -->|"context.visit(node.expression)"| BIC
    SS -->|"b.id(analysis.name)"| BIC
    BIC --> BAV
    BIC -->|"hydration anchors"| EC
    BIC -->|"emit statements"| TPL["state.template / state.init /<br/>state.hoisted"]
    SB -->|"function_declaration"| TPL
    RTV -->|"snippet call stmt"| TPL
    RTV --> UO
    RTV -->|"hydration anchor"| EC
    SB --> DEV
    C & SC & SS & RTV & SB --> ZF
    TPL --> OUT["$$payload render body"]
```

### Component inventory

| Visitor | Input node | Resolution strategy | Emission target |
|---|---|---|---|
| `Component` | `AST.Component` | Static identifier `node.name` | `template` via `build_inline_component` |
| `SvelteComponent` | `AST.SvelteComponent` | Dynamic — visits `this` expression; uses **optional call** | `template` via `build_inline_component` |
| `SvelteSelf` | `AST.SvelteSelf` | Component's own name from `context.state.analysis.name` | `template` via `build_inline_component` |
| `RenderTag` | `AST.RenderTag` | Visits callee + arguments of the render expression | `template` (+ hydration comment) |
| `SnippetBlock` | `AST.SnippetBlock` | Function declaration named by `node.expression` | `hoisted` (if `can_hoist`) or `init`; dev guards |

---

## 4. Component Reference

### 4.1 `Component` — static component tags

```js
// <Greeting name={user} />  compiles to:
Greeting($$payload, { name: user });
```

Thin wrapper: builds `b.id(node.name)` and delegates everything to [`build_inline_component`](#5-shared-builder-build_inline_component). If the component tag carries CSS custom properties (e.g. `<Greeting --theme="dark" />`) or is marked `dynamic` by the analyzer, the call is wrapped accordingly (see §5.4).

### 4.2 `SvelteComponent` — dynamic component tags

```js
// <svelte:component this={dyn} p={1} />  compiles to:
dyn?.($$payload, { p: 1 });
```

Visits `node.expression` (the `this=` value, recursing through [compiler_server_transform_javascript](compiler_server_transform_javascript.md) visitors) and passes the resulting expression to `build_inline_component`. Because the target is only known at runtime, `build_inline_component` emits a `maybe_call` (`?.()`), and the statement is always preceded by an `empty_comment` hydration anchor since the render is inherently dynamic.

### 4.3 `SvelteSelf` — self-references

```js
// inside <Tree>, <svelte:self />  compiles to:
Tree($$payload, {});
```

Resolves to `b.id(context.state.analysis.name)` — the name of the component currently being compiled — then delegates to `build_inline_component`. This avoids any runtime self-lookup machinery; recursion is a direct call to the generated render function.

### 4.4 `RenderTag` — snippet invocation

```js
// {@render item(x)}     →  item($$payload, x);
// {@render maybe?.(y)}  →  maybe?.($$payload, y);
```

Algorithm:
1. `unwrap_optional` strips an outer `ChainExpression`, exposing the underlying `CallExpression`.
2. The callee and each argument are visited (JS visitors from [compiler_server_transform_javascript](compiler_server_transform_javascript.md) handle reactivity/renaming within those expressions).
3. A statement is pushed calling the snippet function with `$$payload` prepended: `b.call` for plain calls, `b.maybe_call` when the source used optional chaining (`node.expression.type === 'CallExpression'` distinguishes the two).
4. Unless `state.skip_hydration_boundaries` is set, an `empty_comment` anchor closes the dynamic region.

### 4.5 `SnippetBlock` — snippet definitions

```js
// {#snippet row(data)}<td>{data}</td>{/snippet}  compiles to:
function row($$payload, data) {
    // body — template pushes from child visitors
}
```

Algorithm:
1. Creates `b.function_declaration(node.expression, [b.id('$$payload'), ...node.parameters], visited body)` — every snippet receives `$$payload` as its first parameter.
2. **Hoisting:** if `node.metadata.can_hoist` (computed during analysis), the declaration goes to `state.hoisted` (usable by sibling render targets, e.g. `<svelte:head>`); otherwise to `state.init`.
3. Tags the function with `fn.___snippet = true` — a temporary hack still needed for legacy `$$render_inner` bindings.
4. **Dev mode only:**
   - Prepends `$.validate_snippet_args($$payload)` to the body (pairs with `validate_snippet_args` in the [server_runtime](server_runtime.md) and [Component_Rendering_Backends](Component_Rendering_Backends_(Client___Server_Code_Generation).md) dev modules).
   - Appends `$.prevent_snippet_stringification(row)` at the declaration site so snippets passed as props fail loudly if coerced to strings.

`SnippetBlock` and `RenderTag` form a producer/consumer pair: snippets are declared once and may be rendered multiple times, passed to components as props, or handed to sibling component transforms.

---

## 5. Shared Builder: `build_inline_component`

The core of this module. Given a component-ish node (`Component`, `SvelteComponent`, `SvelteSelf`), a resolved component expression, and the walking context, it serializes the entire tag into one call statement.

```mermaid
flowchart TD
    S([Attributes + fragment of the tag]) --> A{"Attribute pass<br/>(per attribute)"}
    A -->|"Attribute (plain)"| P["push_prop(init name value)<br/>value via build_attribute_value"]
    A -->|"Attribute --custom"| CP["collect into custom_css_props"]
    A -->|"Attribute children"| HCP["mark has_children_prop"]
    A -->|"SpreadAttribute"| SP["props_and_spreads.push(visited spread)"]
    A -->|"BindDirective ≠ this"| BD["get/set accessor pair<br/>delayed until after spreads"]
    A -->|"LetDirective"| LET["lets.default (unless slot<br/>scope applies to component itself)"]

    P & SP & CP & BD & LET --> DLY["flush delayed props<br/>(bindings last → not overwritten by spreads)"]
    DLY --> CH{"Children pass<br/>(group by slot)"}
    CH -->|"SnippetBlock child"| SBV["visit with redirected init<br/>→ snippet_declarations;<br/>push prop {snippetFn};<br/>$$slots.name = true interop"]
    CH -->|"slot=attr / SvelteFragment"| NM["assign slot_name + let:s"]
    CH -->|"default content"| DEF["children.default"]
    NM & DEF --> SER["serialize each slot →<br/>arrow ($$payload[, let-pattern]) => body<br/>with scope from metadata.scopes"]
    SER --> CHINT{"default slot,<br/>no children prop,<br/>no let:s?"}
    CHINT -->|yes| KIDS["children: slot_fn +<br/>$$slots.default: true"]
    CHINT -->|"no (legacy interop)"| SLOTS["$$slots.default: slot_fn +<br/>children: $.invalid_default_snippet"]
    KIDS & SLOTS --> SS["$$slots object → push_prop"]
    SS --> PE{"props_and_spreads shape?"}
    PE -->|"single plain object"| OBJ["props = { … }"]
    PE -->|"spreads/mixed"| SPX["$.spread_props([…])"]
    OBJ & SPX --> EMIT["stmt: Component($$payload, props)<br/>or Component?.() for dynamic"]
    EMIT --> CSS{"custom_css_props?"}
    CSS -->|yes| WRAP["$.css_props($$payload, isHtml, {…--props},<br/>() => { call }, dynamic && true)"]
    CSS -->|no| DYN{"dynamic?"}
    DYN -->|yes| ANC["empty_comment anchor before"]
    ANC & DYN -->|no-boundaries-skip| OUT([statements → state.template])
```

### 5.1 Props

- **Static/dynamic attributes** become `init` properties; values pass through `build_attribute_value` (literals for text, `$.stringify`-wrapped template expressions for mixed content — see [compiler_server_transform_pipeline](compiler_server_transform_pipeline.md) for its sibling `process_children`).
- **Spreads** are collected as raw expressions; when spreads or a mix of spreads and props exist, the whole props argument becomes `$.spread_props([...])` (implemented in [server_runtime](server_runtime.md) / client props module).

### 5.2 Bindings (`bind:`)

Each `bind:` (except `bind:this`) becomes a getter/setter property pair:

```js
// <Foo bind:value />
Foo($$payload, {
    get value() { return value; },
    set value($$value) { value = $$value; $$settled = false; }
});
```

- Sequence expressions (function bindings) are split into hoisted `bind_get`/`bind_set` temporaries in `state.init`.
- Simple bindings are **delayed** (`push_prop(..., true)`) so that a preceding `{...spread}` cannot overwrite them — accessors always come last within their props group.

### 5.3 Slots, `let:` directives and snippet-as-prop

- Child nodes are grouped by slot name (a `slot="name"` attribute on an element or `SvelteFragment` chooses the slot; everything else is `default`).
- Each slot's content is visited under the scope recorded in `node.metadata.scopes[slot_name]` (default slot content runs in the **component** scope; named slots in the **parent** scope), then wrapped as `($$payload, ...letPattern) => { … }`.
- `let:` directives become object-pattern parameters appended after `$$payload`.
- **Snippets declared directly inside a component tag** are visited with a redirected `init` and pushed as `{ name: nameFn }` props; `$$slots.name = true` is emitted as legacy `<slot>` interop.
- **`children` prop interop:** if the default slot has no `let:` directives, it is passed both as `children` and as `$$slots.default: true`. If a component receives an explicit `children` prop *and* has child nodes, the children go to `$$slots.default` and the `children` prop becomes `$.invalid_default_snippet` (a runtime error helper from [Cross-Runtime_Platform_Services](Cross-Runtime_Platform_Services_(Shared_Utilities,_Flags___Context_Injection).md) shared errors).

### 5.4 CSS custom properties & dynamic wrapping

- Attributes named `--*` are extracted into `custom_css_props` and the entire component call is wrapped:

```js
// <Foo --theme="dark" />  compiles to:
$.css_props($$payload, true, { '--theme': 'dark' }, () => { Foo($$payload, {}); });
// second arg false when state.namespace === 'svg'; trailing `true` if dynamic
```

- For `dynamic` components (or `<svelte:component>`), an `empty_comment` is pushed *before* the call; after any dynamic content, a closing anchor follows unless `state.skip_hydration_boundaries` is set.

---

## 6. Hydration Boundary Mechanism

The server emits `<!---->` comment chunks (`empty_comment`) around dynamic regions — dynamic components, snippets, most block content. The client-side hydrator ([Component_Rendering_Backends](Component_Rendering_Backends_(Client___Server_Code_Generation).md)) uses these comments as anchors to claim corresponding DOM nodes. The `skip_hydration_boundaries` state flag (set for regions that don't need anchors, e.g. inside `<head>`) suppresses the *trailing* comment only, keeping region starts deterministic.

```mermaid
sequenceDiagram
    participant V as Visitor (this module)
    participant T as state.template
    participant R as server_runtime (render time)
    V->>T: empty_comment (<!---->)  [only for dynamic]
    V->>T: stmt: Comp?.($$payload, props) / snippet($$payload, …)
    V->>T: empty_comment  (unless skip_hydration_boundaries)
    Note over R: During SSR, payload.out accumulates<br/>text + <!----> markers; client hydrate()<br/>uses markers to position dynamic blocks
```

---

## 7. Data Flow Through the Context

Every visitor receives a `ComponentContext` (a `zimmerframe.Context`), which supplies:

| Member | Role |
|---|---|
| `context.visit(node, state?)` | Recursive dispatch into other server visitors (elements, control flow, JS) |
| `context.state.template` | Ordered array of statements / template chunks forming the render body |
| `context.state.init` | Declarations emitted at the top of the current block (snippet functions, bind temporaries) |
| `context.state.hoisted` | Declarations hoisted above the current block (`can_hoist` snippets) |
| `context.state.scope` | Current scope for identifier generation |
| `context.state.analysis` | Per-component analysis results (`analysis.name` used by `SvelteSelf`) |
| `context.state.namespace` | `'svg'` or html — controls `$.css_props` SVG flag |
| `context.state.options` / `dev` | Dev-mode toggles gating validation calls |

```mermaid
flowchart LR
    AST["AST node<br/>(compiler_types/template.d.ts)"] --> VIS["visitor(node, context)"]
    VIS -->|"visit expressions/children"| SIB["sibling visitors<br/>(pipeline / elements /<br/>control flow / javascript)"]
    VIS --> BL["builders b.*<br/>(compiler_core/utils/builders.js)"]
    BL --> STMT["estree statements"]
    STMT --> T["state.template / init / hoisted"]
    T --> SER["server transform entry<br/>serializes render function"]
    SER --> OUT["Compiled SSR module<br/>(CompileResult)"]
```

---

## 8. End-to-End Example

Source:

```svelte
<Tree data={root}>
    {#snippet label(node)}<b>{node.name}</b>{/snippet}
    {#each root.children as child (child.id)}
        {@render label(child)}
    {/each}
</Tree>
```

Generated (simplified) server code:

```js
function label($$payload, node) {           // SnippetBlock → state.init / hoisted
    $$payload.out += `<b>`;
    $$payload.out += $.escape(node.name);   // child element/text visitors
    $$payload.out += `</b>`;
}
...
Tree($$payload, {                            // Component → build_inline_component
    data: root,
    label,                                   // snippet-as-prop (block-scoped declaration)
    children: ($$payload) => {               // default slot content
        ...                                  // EachBlock visitor (control-flow module)
        label($$payload, child);             // RenderTag visitor
    },
    $$slots: { default: true }
});
```

---

## 9. Design Notes & Invariants

1. **`$$payload`-passing style.** Unlike the client (DOM construction + signals), server snippets and components are plain functions that thread `$$payload` explicitly — no closures over a global output buffer, enabling streaming and payload copying (`payload.js` in [server_runtime](server_runtime.md)).
2. **Static resolution where possible.** `Component` and `SvelteSelf` are direct identifier calls; only `<svelte:component>` pays for `?.()` dispatch plus a mandatory leading hydration anchor.
3. **Ordering matters.** Delayed binding props are flushed after spreads; snippet declarations inside component tags are wrapped in a block to scope them to the tag; `can_hoist` snippets escape their block entirely.
4. **Legacy interop is centralized.** `let:` handling, `$$slots`, the `children`-prop fallback, and the `___snippet` hack all live in `build_inline_component`/`SnippetBlock`, keeping the per-node visitors minimal.
5. **Dev-mode correctness is additive.** `$.validate_snippet_args` and `$.prevent_snippet_stringification` are only emitted when `dev` is true, so production bundles stay lean (tree-shakeability is verified by `check-treeshakeability` in [Repository_Engineering_Infrastructure](Repository_Engineering_Infrastructure_(Benchmarks,_Build_Scripts___Playground).md)).

---

## 10. Related Modules

- [compiler_server_transform](compiler_server_transform.md) — parent phase: entry point, visitor registry, transform state.
- [compiler_server_transform_pipeline](compiler_server_transform_pipeline.md) — `Fragment` traversal and `build_attribute_value`/`process_children` helpers this module consumes.
- [compiler_server_transform_elements](compiler_server_transform_elements.md) / [compiler_server_transform_control_flow](compiler_server_transform_control_flow.md) — visitors invoked for tag children and block contents.
- [compiler_server_transform_javascript](compiler_server_transform_javascript.md) — expression visitors reached via `context.visit` inside component expressions, snippet arguments and bindings.
- [compiler_analyzer](compiler_analyzer.md) — produces `metadata.scopes`, `metadata.dynamic`, `metadata.can_hoist` and the `analysis` state consumed here.
- [compiler_types](compiler_types.md) — AST definitions for `Component`, `SvelteComponent`, `SvelteSelf`, `RenderTag`, `SnippetBlock`.
- [server_runtime](server_runtime.md) — runtime helpers referenced by generated code: `$.css_props`, `$.spread_props`, `$.escape`, `$.stringify`, `$.validate_snippet_args`, `$.prevent_snippet_stringification`, `$.invalid_default_snippet`.
- [compiler_client_transform](compiler_client_transform.md) — the client-side counterpart, including its `Component`, `RenderTag`, and `SnippetBlock` visitors.