# Module: compiler_client_transform_elements_and_directives

> **Location:** `packages/svelte/src/compiler/phases/3-transform/client/visitors/` (Svelte compiler, phase 3 — client-side code generation)
> **Parent module:** [compiler_client_transform](compiler_client_transform.md)

## 1. Introduction

`compiler_client_transform_elements_and_directives` is the part of the Svelte compiler's client back-end that **turns template elements, attributes and directives into imperative DOM-manipulation JavaScript**. When Svelte compiles a component for the browser, this module supplies the visitors that are dispatched for every `AST.RegularElement`, `AST.SvelteElement`, `AST.Attribute`, `AST.SpreadAttribute`, and every element-level directive (`bind:`, `on:`, `use:`, `transition:`, `let:`, `{@attach ...}`) plus the special element types (`<svelte:head>`, `<svelte:body>`, `<svelte:window>`, `<svelte:document>`, `<title>`).

The visitors in this module do not emit DOM code themselves. Instead they **push statements into the compile-time statement buckets of the current `ComponentClientTransformState`** (`init`, `update`, `after_update`) and register properties on the shared template tree. These buckets are later assembled — by [compiler_client_transform_templates](compiler_client_transform_templates.md) and [compiler_client_transform](compiler_client_transform.md) — into a hydration-friendly `$.template(...)` call plus `init`/`template_effect`/`after_update` wiring. Every emitted statement is a call into the **client runtime** (see [client_dom_renderer](client_dom_renderer.md)), e.g. `$.set_attribute`, `$.event`, `$.bind_value`, `$.transition`.

**Design goals of the module:**

| Goal | Mechanism |
|---|---|
| Static-first output | Static attributes/text are baked into the template string; only dynamic parts get effects |
| Fine-grained reactivity | Dynamic values become `$.template_effect` / `$.attribute_effect` updates, memoized via `Memoizer` |
| Hydration support | Template tree metadata (`push_element`, `set_prop`, `pop_element`) keeps the emitted HTML and the DOM walk in sync; `$.child`/`$.sibling`/`$.reset` navigate hydrated nodes |
| Correct ordering semantics | `let:` before attributes, attributes before events, events/bindings/actions before transitions, `bind:this` first |
| Legacy + runes mode | e.g. legacy `<select bind:value>` gets `$.invalidate_inner_signals` synchronization |

## 2. Position in the Compilation Pipeline

This module sits in **phase 3 (client transform)** of the compiler. It is one of five visitor groups of the client transform:

```mermaid
flowchart TD
    P["Phase 1 - Parse<br/>compiler_parser"] --> A["Phase 2 - Analyze<br/>compiler_analyzer<br/>scopes, references, metadata"]
    A --> T["Phase 3 - Transform"]
    T --> TPL["compiler_client_transform_templates<br/>template tree, template.js"]
    TPL --> SR["compiler_client_transform_state_and_reactivity<br/>visit, visit_function, Identifier,<br/>MemberExpression, AssignmentExpression"]
    SR --> ED["compiler_client_transform_elements_and_directives<br/>(THIS MODULE)"]
    ED --> CF["compiler_client_transform_control_flow_blocks<br/>IfBlock, EachBlock, AwaitBlock, ..."]
    ED --> CS["compiler_client_transform_components_and_scripts<br/>Component, SvelteComponent, snippets"]
    ED --> RT["Client runtime dispatch<br/>client_dom_renderer + client_runtime_core"]
    ED -.-> CSS["compiler_css_pipeline<br/>scoped class hash"]
    ED -.-> TYPES["compiler_types<br/>AST node contracts"]
```

**Inputs** it consumes from earlier phases:
- The analyzed AST from [compiler_parser](compiler_parser.md) / [compiler_analyzer](compiler_analyzer.md) (nodes carry `metadata`: `has_spread`, `scoped`, `expression.has_state/has_call/has_await`, binding groups, `parent_each_blocks`, etc.).
- Scope objects and `scope.references` (from [compiler_analyzer_scope](compiler_analyzer_scope.md)) used e.g. by `setup_select_synchronization` and `LetDirective` binding registration.
- The CSS scoping hash from [compiler_css_pipeline](compiler_css_pipeline.md), appended to `class` attributes for scoped styles.

**Outputs** it feeds forward: statements in the `init` / `update` / `after_update` buckets, template-tree entries, and dev-mode flags (`needs_props`, `contains_script_tag`, `needs_import_node`) that other transform parts and the runtime layer consume.

## 3. Architecture

### 3.1 Component map

```mermaid
flowchart TB
    subgraph ELEM["Element visitors"]
        RE["RegularElement<br/>regular HTML/SVG/MathML elements"]
        SE["SvelteElement<br/>&lt;svelte:element this=...&gt;"]
        TE["TitleElement<br/>&lt;title&gt;"]
        SH["SvelteHead<br/>&lt;svelte:head&gt;"]
        SPS["SvelteBody / SvelteWindow / SvelteDocument<br/>visit_special_element"]
    end

    subgraph ATTR["Attribute visitors"]
        AT["Attribute<br/>(event attributes only)"]
        SA["SpreadAttribute<br/>{...props}"]
    end

    subgraph DIR["Directive visitors"]
        OD["OnDirective<br/>on:event"]
        BD["BindDirective<br/>bind:prop"]
        UD["UseDirective<br/>use:action"]
        TD["TransitionDirective<br/>transition:/in:/out:"]
        LD["LetDirective<br/>let:x (legacy slots)"]
        ATG["AttachTag<br/>{@attach fn}"]
    end

    subgraph SHARED["shared/ helper layer (not in this module's file list)"]
        ELS["element.js:<br/>build_attribute_value,<br/>build_attribute_effect,<br/>build_set_class, build_set_style"]
        EVT["events.js:<br/>build_event,<br/>build_event_handler,<br/>visit_event_attribute"]
        UTS["utils.js:<br/>Memoizer, build_template_chunk,<br/>build_render_statement, parse_directive_name"]
        FRG["fragment.js:<br/>process_children"]
        SPE["special_element.js:<br/>visit_special_element"]
    end

    ELEM --> SHARED
    ATTR --> SHARED
    DIR --> SHARED
    UTS --> RE
    ELS --> RE
    EVT --> OD
```

### 3.2 State and context model

All visitors share the same two contracts defined in `../types` (see [compiler_client_transform](compiler_client_transform.md)):

- **`ComponentContext`** — `{ node, path, state, visit, next }`. `visit` recursively dispatches child nodes; `path` is the ancestor chain (used by `BindDirective` for parent checks and dev binding validation); `next()` lets a visitor defer to sibling processing (`UseDirective`, `AttachTag`).
- **`ComponentClientTransformState`** — the emit target:
  - `init` — one-time setup statements (template manipulation, attribute sets, `bind:this`, actions).
  - `update` — statements re-run inside a `$.template_effect` render effect when reactive inputs change.
  - `after_update` — statements that must run *after* the render effect, in document order (events, bindings, transitions).
  - `node` — the `Identifier` of the current anchor/DOM node in generated code.
  - `template` — the template tree builder (`push_element`, `pop_element`, `set_prop`, `push_text`, `push_comment`).
  - `memoizer` — a `Memoizer` instance that hoists call/await-dependent expressions into `$0, $1, ...` parameters of the surrounding `$.template_effect` / `$.attribute_effect` arrow.
  - `metadata.namespace` — `html` / `svg` / `mathml`, refined per subtree via `determine_namespace_for_children`.
  - `scope` + `transform` — scope lookups and reactive read transforms (e.g. `LetDirective` installs `$.get(...)` readers).

### 3.3 Emission model

```mermaid
flowchart LR
    AST["AST node"] --> V["Visitor<br/>(this module)"]
    V -->|"static parts"| TT["template tree<br/>template.set_prop / push_text"]
    V -->|"dynamic expressions"| INIT["state.init"]
    V -->|"reactive updates"| UPD["state.update"]
    V -->|"events, bindings,<br/>transitions"| AU["state.after_update"]
    TT --> ASM["Template assembly<br/>(compiler_client_transform_templates)"]
    INIT --> ASM
    UPD --> ASM
    AU --> ASM
    ASM --> OUT["$.template(...),<br/>$.template_effect(...),<br/>$.effect(...),<br/>component body"]
```

## 4. Component Reference

### 4.1 `RegularElement` — the workhorse

`visitors/RegularElement.js::RegularElement` compiles `<div>`, `<input>`, `<svg>` etc. This is the most complex visitor in the module and runs a fixed internal pipeline:

```mermaid
flowchart TD
    S["push_element(name) on template tree"] --> NS["noscript? pop_element + stop"]
    NS --> CE["custom element / video / script flags:<br/>needs_import_node, contains_script_tag"]
    CE --> BUCKET["Bucket attributes:<br/>attributes, class_directives,<br/>style_directives, other_directives,<br/>lets, lookup, bindings"]
    BUCKET --> VISIT_OTHER["Visit other_directives<br/>(on: handlers into element_state,<br/>rest via element context)"]
    VISIT_OTHER --> INPUT_FIX["input/textarea fixes:<br/>$.remove_input_defaults /<br/>$.remove_textarea_child"]
    INPUT_FIX --> SELECT["select bind:value? <br/>setup_select_synchronization<br/>(legacy: $.invalidate_inner_signals)"]
    SELECT --> LETS["Emit let: statements first"]
    LETS --> ATTRS{"has_spread?"}
    ATTRS -->|yes| SPREAD["build_attribute_effect<br/>-> $.attribute_effect"]
    ATTRS -->|no| PER_ATTR["Per-attribute emission:<br/>- static -> template.set_prop<br/>- on:x -> visit_event_attribute<br/>- autofocus -> $.autofocus<br/>- class/style -> build_set_class/style<br/>- custom element -> $.set_custom_element_data<br/>- else build_element_attribute_update"]
    PER_ATTR --> REPLAY["img/audio/video with load/error<br/>handlers -> $.replay_events"]
    REPLAY --> CHILDREN["Children:<br/>clean_nodes, namespace,<br/>textContent fast-path or<br/>process_children ($.child/$.sibling)"]
    CHILDREN --> MERGE["Merge child_state + element_state<br/>into init/update/after_update<br/>(block-wrapped if snippets present)"]
    MERGE --> SPECIALS["dir re-assignment fix,<br/>select/option/input __value handling:<br/>$.select_option, $.init_select"]
    SPECIALS --> POP["pop_element()"]
```

Key behaviors worth knowing when maintaining this file:

- **Attribute bucketing** (`attributes`, `class_directives`, `style_directives`, `other_directives`, `lets`, plus the `lookup`/`bindings` maps) drives every later decision. `LetDirective`s are always visited *before* attributes so slot props are available to them.
- **Static inlining**: an attribute can be baked into the template (`template.set_prop`) when it is `value === true` or a plain text attribute, is not settable only via DOM property (`cannot_be_set_statically`), and doesn't collide with class/style directives. Scoped CSS automatically appends the component hash to `class` values here.
- **`build_element_attribute_update`** chooses the correct setter: `$.set_value`, `$.set_checked`, `$.set_selected`, `$.set_default_value`, `$.set_default_checked`, `$.set_xlink_attribute`, `$.set_attribute`, a plain DOM-property assignment (`is_dom_property`, special-cased `muted` for Firefox), or `$.autofocus`.
- **Dynamic values** with calls or awaits are memoized (`context.state.memoizer.add`) so they are evaluated once per update cycle, and reactive ones land in `state.update` wrapped as `if (value !== (value = 'new value')) { ... }`-style diffed assignments.
- **Custom elements** take `build_custom_element_attribute_update_assignment` → `$.set_custom_element_data` (not idempotent, so never grouped into a render effect unless stateful).
- **Special value attributes**: `<select value=...>`, `<option value=...>` and group/checked bindings need the hidden `__value` property (`build_element_special_value_attribute`), including `$.select_option` / `$.init_select` synchronization so one-way `<select value>` always wins over DOM mutation.
- **Children**: `clean_nodes` trims whitespace/comments; an all-static-text child set becomes a single `element.textContent = ...` assignment; `<template>` children descend into `.content` with `$.hydrate_template`; reactive children are wired through `process_children` (from `shared/fragment.js`) which emits `$.child` / `$.sibling` navigation and `$.set_text` updates.
- **Event replay**: media/image elements with `onload`/`onerror` (or spread/`use:`) get `$.replay_events` so handlers attached after the event fired still run (hydration edge case).

### 4.2 `SvelteElement` — dynamic tags

`visitors/SvelteElement.js::SvelteElement` compiles `<svelte:element this={tag}>`. Because the tag is unknown at compile time, no template element is created — the runtime call `$.element(node, get_tag, is_svg_or_mathml, [anchor =>] inner_fn, dynamic_namespace, [line, col])` constructs the node at runtime:

- A fresh **inner context** is created around a generated `$$element` identifier; all attribute/event statements for the dynamic element accumulate inside a callback passed to `$.element`.
- Attributes **always** go through `build_attribute_effect` (spread path), because "is this a custom element?" can only be decided at runtime. A single static `class` text attribute is the only exception (via `build_set_class`).
- A dynamic `xmlns` attribute is passed as a thunk to `$.element`.
- In dev, `$.validate_dynamic_element_tag` / `$.validate_void_dynamic_element` plus source location are emitted.
- **Async support**: if the tag expression contains an `{@await ...}` (`node.metadata.expression.has_await`), the whole `$.element(...)` statement is wrapped in `$.async(node, [tag thunk], ($$node, $$tag) => {...})` and the tag read becomes `$.get($$tag)`.

### 4.3 `Attribute`, `SpreadAttribute`, event attributes

- **`Attribute`** (`visitors/Attribute.js`): standalone attributes are handled by their parent element visitor; this visitor only exists so an attribute visited *outside* an element context still routes `onclick="..."`-style **event attributes** through `visit_event_attribute` (identical semantics to `on:`).
- **`SpreadAttribute`** (`visitors/SpreadAttribute.js`): simply returns `context.visit(node.expression)`. It is meaningful only as part of the snapshot object built by `build_attribute_effect`, which converts spreads into `...expr` properties of the object passed to `$.attribute_effect`.

### 4.4 `BindDirective` — two-way bindings

`visitors/BindDirective.js::BindDirective` compiles `bind:value`, `bind:this`, `bind:clientWidth`, media bindings, etc.:

1. Builds a **getter thunk** for the bound expression and a **setter arrow** `($$value) => (expr = $$value)`; a `SequenceExpression` from the analyzer already carries the `(get, set)` pair.
2. In **dev + runes mode**, member expressions inside blocks (`If`/`Each`/`Await`/`Key`) are validated via `validate_binding` (error `binding_property_non_reactive` can be silenced with `<!-- svelte-ignore -->`).
3. Looks the binding up in `binding_properties` (from `phases/bindings.js`): if a declarative rule exists, emits the generic `$.bind_property(name, event, node, set, bidirectional)`.
4. Otherwise dispatches on the binding name to a dedicated runtime helper — window (`$.bind_online`, `$.bind_window_scroll`, `$.bind_window_size`), document (`$.bind_active_element`), media (`$.bind_muted` … `$.bind_ready_state`), sizes (`$.bind_element_size`, `$.bind_resize_observer`), form controls (`$.bind_value`, `$.bind_select_value`, `$.bind_checked`, `$.bind_files`, `$.bind_group`), misc (`$.bind_focused`, `$.bind_content_editable`, `build_bind_this` for `bind:this`).
5. **Ordering**: `bind:this` goes into `init`; all other bindings go into `after_update` — or into a `$.effect` thunk when the element also has a `use:` directive (so actions see fully-updated attributes). `bind:group` additionally registers the sibling `value` attribute as a dependency and collects enclosing `each` block indexes (signal-wrapped for keyed each) into `$.bind_group`.

### 4.5 `OnDirective` — event handlers

`visitors/OnDirective.js::OnDirective` compiles `on:click={...}`:

- Wraps the handler with `build_event_handler` (shared/events.js): inline arrow/function handlers pass through unchanged; stable identifiers pass through; other expressions are wrapped in a function so they re-evaluate per event, memoized as `$.derived` when they contain calls; in dev they route through `$.apply` for warning attribution. A missing expression produces a props-bubbling handler (`$.bubble_event`).
- Applies modifiers by wrapping: `$.stopPropagation`, `$.stopImmediatePropagation`, `$.preventDefault`, `$.self`, `$.trusted`, `$.once`; `capture` and `passive`/`nonpassive` become `$.event(name, node, handler, capture, passive)` flags via `build_event`.
- A handler-less `on:event` (used for component event bubbling) sets `context.state.analysis.needs_props = true`.

### 4.6 `UseDirective` — actions

`visitors/UseDirective.js::UseDirective` compiles `use:action={param}` into `$.action(node, ($$node, $$action_arg) => action(...), () => param)`. It emits into `init` (actions must run after attribute updates, in order with bindings/events) and calls `context.next()` to let the next directive continue in sequence.

### 4.7 `TransitionDirective` — transitions

`visitors/TransitionDirective.js::TransitionDirective` builds a flag mask (`TRANSITION_GLOBAL` / `TRANSITION_IN` / `TRANSITION_OUT` from `intro`/`outro` metadata) and emits `$.transition(flags, node, () => fn, () => params)` into `after_update` — deliberately after `bind:this` so `node.__` references are correct.

### 4.8 `LetDirective` — legacy slot props

`visitors/LetDirective.js::LetDirective` compiles `let:x` / `let:x={{y, z}}` (legacy slot API):

- `let:x` → `const x = $.derived(() => $$slotProps.x)` and installs a `transform` entry so reads of `x` compile to `$.get(x)`.
- Destructuring forms generate a derived that destructures `$$slotProps.x` and re-exports each bound name, again registering `$.get`-based reads for every binding.

### 4.9 `AttachTag` — attachments

`visitors/AttachTag.js::AttachTag` compiles `{@attach fn}` into `$.attach(node, () => expression)`. The expression is built with `build_expression`, so call/await metadata is respected; `context.next()` continues sibling processing.

### 4.10 Special elements

| Visitor | Compiles to | Notes |
|---|---|---|
| `TitleElement` | `$.document.title = ...` (init or `$.template_effect` update) | uses `build_template_chunk` over the fragment |
| `SvelteHead` | `$.head(($$anchor) => { ...fragment... })` | content rendered into `document.head` |
| `SvelteBody` | `visit_special_element(node, '$.document.body')` | attributes/directives visited with `node` bound to `document.body` |
| `SvelteWindow` | `visit_special_element(node, '$.window')` | enables `bind:innerWidth`, `on:resize`, ... on `window` |
| `SvelteDocument` | `visit_special_element(node, '$.document')` | bindings/events on `document` |

`visit_special_element` only redirects the target identifier: `on:` directives are pushed straight into `init`, everything else is visited with the swapped state.

## 5. Interaction with the Shared Helper Layer

The visitors delegate almost all "how do I serialize X?" questions to `visitors/shared/`:

```mermaid
sequenceDiagram
    participant V as Visitor (RegularElement / SvelteElement)
    participant AV as build_attribute_value
    participant M as Memoizer
    participant AE as build_attribute_effect
    participant ST as state.init / state.update

    V->>AV: attribute.value (true | Text | ExpressionTag | chunks)
    AV-->>V: { value, has_state } (Literal / expression / template chunk)
    Note over V: has_spread? collect attributes,<br/>class + style directives
    V->>AE: attributes, class_directives, style_directives, element_id
    AE->>M: add(expr) for every has_call / has_await value
    AE->>ST: $.attribute_effect(element_id, ($0,$1..) => ({...snapshot, [$.CLASS]:..., [$.STYLE]:...}), sync, async, cssHash, ignoreHydration)
    M-->>AE: parameter ids $0, $1, ...
```

- **`build_attribute_value`** normalizes any attribute value (`true`, single text node, single expression tag, or multi-chunk template) into an estree expression plus a `has_state` flag that decides `init` vs `update` placement.
- **`build_attribute_effect`** builds the single `$.attribute_effect` call used for all spread/custom-element/dynamic cases; class/style directives are passed under the reserved `$.CLASS` / `$.STYLE` keys so the runtime applies them with the correct merge semantics.
- **`Memoizer`** (shared/utils.js) guarantees each call/await expression is evaluated exactly once per update: it renames placeholders to `$0…$n` and exposes them as arrow parameters of `$.template_effect` / `$.attribute_effect`, with sync and async value arrays.
- **`build_render_statement`** turns a filled `state.update` bucket into a `$.template_effect(($0…) => { … }, sync, async)` call.
- **`build_event_handler` / `build_event`** (shared/events.js) implement handler normalization and `$.event` emission (see 4.5).
- **`process_children`** (shared/fragment.js) performs child-node navigation/static-skip logic and produces `$.child`/`$.sibling`/`$.next`/`$.set_text` wiring — used by `RegularElement` and consumed throughout [compiler_client_transform_templates](compiler_client_transform_templates.md).

## 6. Runtime Integration

Every statement emitted by this module is a call into the client runtime. The mapping below is the contract between this module and [client_dom_renderer](client_dom_renderer.md) / [client_runtime_core](client_runtime_core.md):

| Concept | Emitted call(s) | Runtime home |
|---|---|---|
| Attribute updates | `$.set_attribute`, `$.set_xlink_attribute`, `$.set_value`, `$.set_checked`, `$.set_selected`, `$.set_default_value`, `$.set_default_checked`, `$.set_custom_element_data`, `$.autofocus` | `dom/elements/attributes.js` |
| Spread/dynamic attributes | `$.attribute_effect` (+ `$.CLASS`, `$.STYLE` keys) | `dom/elements/attributes.js` |
| Class / style | `build_set_class` / `build_set_style` outputs | `dom/elements/attributes.js`, `dev/css.js` |
| Events | `$.event`, `$.once`, `$.stopPropagation`, `$.preventDefault`, `$.self`, `$.trusted`, `$.apply`, `$.replay_events` | `dom/elements/events.js` |
| Actions | `$.action` | `dom/elements/` action wiring |
| Transitions | `$.transition` | `dom/elements/transitions.js` |
| Attachments | `$.attach` | runtime attachment support |
| Bindings | `$.bind_*` family, `$.bind_property`, `$.init_select`, `$.select_option` | `dom/elements/bindings/*` |
| Dynamic element | `$.element`, `$.validate_dynamic_element_tag`, `$.validate_void_dynamic_element` | `dom/blocks/svelte-element.js` |
| Head / body / window / document | `$.head`, `$.document`, `$.document.body`, `$.window` | `dom/blocks/svelte-head.js`, `dom/elements/bindings/*` |
| Reactivity plumbing | `$.template_effect`, `$.effect`, `$.derived`, `$.get`, `$.async`, `$.invalidate_inner_signals` | [client_runtime_core](client_runtime_core.md) |
| Hydration navigation | `$.child`, `$.sibling`, `$.next`, `$.reset`, `$.hydrate_template` | `dom/operations.js`, `dom/hydration.js` |
| Input/textarea hygiene | `$.remove_input_defaults`, `$.remove_textarea_child` | `dom/elements/attributes.js`, `dom/elements/misc.js` |

```mermaid
flowchart LR
    subgraph GEN["Generated output (illustrative)"]
        TPL["&lt;template&gt; tree with<br/>static props baked in"]
        INITBLOCKS["init: $.set_attribute(...),<br/>$.action(...), bind:this, ..."]
        EFF["$.template_effect(() =&gt; {<br/>if (v !== (v = next)) ...<br/>}, sync, async)"]
        AFT["after_update: $.event(...),<br/>$.bind_value(...), $.transition(...)"]
    end
    subgraph RUN["Client runtime (client_dom_renderer)"]
        DOM["DOM nodes &amp; hydration anchors"]
        SIG["Signals / effects<br/>(client_runtime_core)"]
    end
    TPL --> DOM
    INITBLOCKS --> DOM
    EFF --> SIG
    AFT --> DOM
    SIG --> DOM
```

Example — `<button on:click|preventDefault={handler} disabled={busy}>go</button>` compiles to (schematically):

```js
// template: <button>go</button>, 'disabled' is reactive -> not baked in
button_1.disabled = busy;                       // init (if static at mount) ...
$.template_effect(() => {                       // ... or updated here
    if (button_1.disabled !== (button_1.disabled = busy)) button_1.disabled = busy;
});
var handler_2 = /* memoized if it contains calls */;
$.event('click', button_1, $.preventDefault(handler_2)); // after_update
```

## 7. Dependencies

**Upstream (consumed by this module):**

- [compiler_parser](compiler_parser.md) / [compiler_analyzer](compiler_analyzer.md) — analyzed AST with per-node metadata (`has_spread`, `scoped`, `expression.*`, binding groups, `parent_each_blocks`).
- [compiler_analyzer_scope](compiler_analyzer_scope.md) — `scope.references`, `scope.get_bindings`, `scope.evaluate`, identifier generation.
- [compiler_css_pipeline](compiler_css_pipeline.md) — `analysis.css.hash` used for scoped class emission.
- [compiler_types](compiler_types.md) — AST node contracts (`RegularElement`, `SvelteElement`, `BindDirective`, `OnDirective`, `UseDirective`, `TransitionDirective`, `LetDirective`, `AttachTag`, `TitleElement`, `SvelteBody`, `SvelteWindow`, `SvelteDocument`, `SvelteHead` in `types/template.d.ts`).
- [compiler_core](compiler_core.md) — `utils/builders` (`b.*` estree factories) used to construct every emitted statement; `compiler/state.js` for `dev`, `locator`, `is_ignored` (svelte-ignore handling).

**Shared within phase 3:**

- [compiler_client_transform](compiler_client_transform.md) — `ComponentContext` / `ComponentClientTransformState`, `clean_nodes`, `determine_namespace_for_children`, `create_derived`.
- Sibling visitor groups: [compiler_client_transform_templates](compiler_client_transform_templates.md) (template tree + `Fragment` assembly), [compiler_client_transform_state_and_reactivity](compiler_client_transform_state_and_reactivity.md) (expression compilation, `visit_function`), [compiler_client_transform_control_flow_blocks](compiler_client_transform_control_flow_blocks.md) (blocks that receive anchors created by `process_children`), [compiler_client_transform_components_and_scripts](compiler_client_transform_components_and_scripts.md) (components consuming `let:` props).

**Downstream (runtime contracts):**

- [client_dom_renderer](client_dom_renderer.md) — implements every `$.` helper emitted here (attributes, events, bindings, transitions, dynamic elements, hydration).
- [client_runtime_core](client_runtime_core.md) — signals/effects that `$.template_effect`, `$.derived`, `$.get` and `$.effect` compile down to.
- The server-side counterpart of this module lives in [compiler_server_transform](compiler_server_transform.md); it mirrors the element/directive logic but emits SSR string-building calls instead of DOM effects.

## 8. Maintenance Notes

- **Ordering is semantic**: `let:` → attributes → events/bindings → actions → transitions. If you change where a visitor pushes statements, verify against the runtime's expectations (e.g. actions assume updated attributes; transitions assume `bind:this` ran).
- **`Memoizer` placeholders** (`$0…$n`) are positional — any new `has_call`/`has_await` value must go through `memoizer.add`, never be inlined into `state.update` directly, or duplicated evaluation/lost sync between the snapshot object and parameters will occur.
- **Template/tree sync**: every `push_element` must be matched by `pop_element`, including the early `noscript` return; the template builder is what makes hydration positioning correct.
- **Dev-mode validation** (`validate_binding`, `validate_dynamic_element_tag`, `$.apply`, ownership checks) must stay behind the `dev` flag to keep production output tree-shakeable (see `scripts/check-treeshakeability.js` in the repository tooling).
- **Legacy vs runes**: features like `setup_select_synchronization` and `LetDirective` exist only for legacy components; runes-mode code paths should avoid adding new dependencies on `invalidate_inner_signals` / `$$slotProps` semantics.
