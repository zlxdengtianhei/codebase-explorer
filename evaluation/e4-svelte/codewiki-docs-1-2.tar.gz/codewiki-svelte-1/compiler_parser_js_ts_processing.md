# compiler_parser_js_ts_processing

## 1. Overview

`compiler_parser_js_ts_processing` is the **JavaScript/TypeScript acquisition and normalization layer** inside Phase 1 (parsing) of the Svelte compiler. It is a child module of [compiler_parser](compiler_parser.md) and sits alongside two sibling modules:

- [compiler_parser_template_state_machine](compiler_parser_template_state_machine.md) — the template state machine that *invokes* this module whenever it encounters `<script>` contents or inline `{...}` expressions.
- [compiler_parser_parse_utilities](compiler_parser_parse_utilities.md) — auxiliary helpers (options reading, fuzzy matching, HTML entity handling).

The module provides two cooperating capabilities:

1. **JS/TS parsing** (`phases/1-parse/acorn.js`) — a thin wrapper around [Acorn](https://github.com/acornjs/acorn) (optionally extended with the `@sveltejs/acorn-typescript` plugin) that turns script blocks and template expressions into standard **ESTree** ASTs, while capturing **comments with exact source positions** — something Acorn does not do on its own.
2. **TypeScript stripping** (`phases/1-parse/remove_typescript_nodes.js`) — a zimmerframe-based AST walker that removes TypeScript-only syntax from parsed ASTs so that every downstream phase (analysis, transformation, and the `esrap` code printer) only ever sees **clean, pure ESTree**.

> **Scope note:** This module performs *syntactic* TS handling only. It is **not** a TypeScript transpiler — language features with runtime semantics (enums, decorators, parameter properties, `accessor` fields, namespaces with values) raise the `typescript_invalid_feature` compile error, directing users to the [compiler_preprocess](compiler_preprocess.md) tooling (e.g. `vitePreprocess({ script: true })`).

---

## 2. Component Inventory

| File | Component | Kind | Responsibility |
|---|---|---|---|
| `phases/1-parse/acorn.js` | `parse(source, comments, typescript, is_script)` | exported | Parse a full JS/TS program (script contents, `compileModule` source) into an ESTree `Program`, collecting comments. |
| `phases/1-parse/acorn.js` | `parse_expression_at(source, comments, typescript, index)` | exported | Parse a single expression starting at `index` — used for all inline template expressions. |
| `phases/1-parse/acorn.js` | `get_comment_handlers(source, comments, index)` | internal | Factory returning the `onComment` callback and the `add_comments(ast)` post-processor. |
| `phases/1-parse/remove_typescript_nodes.js` | `remove_typescript_nodes(ast)` | exported | Walk a TS-augmented AST and strip/unwrap/reject TypeScript constructs. |
| `phases/1-parse/remove_typescript_nodes.js` | `remove_this_param(node, context)` | internal (listed core component) | Removes a leading `this` parameter from `FunctionExpression` / `FunctionDeclaration` nodes. |

---

## 3. Architecture

```mermaid
flowchart TB
    subgraph FE["Compiler Front-End (Parsing / Analysis Pipeline)"]
        direction TB
        subgraph P["compiler_parser (parent module)"]
            TM["compiler_parser_template_state_machine<br/>(fragment / element / text states)"]
            U["compiler_parser_parse_utilities"]
            subgraph JS["compiler_parser_js_ts_processing — this module"]
                A["acorn.js<br/>parse · parse_expression_at<br/>get_comment_handlers"]
                R["remove_typescript_nodes.js<br/>remove_typescript_nodes<br/>remove_this_param"]
            end
        end
        AN["compiler_analyzer (Phase 2)"]
        TR["Compiler Back-End (Phase 3 transform)"]
    end

    AC["acorn (npm)"]
    TSP["@sveltejs/acorn-typescript (npm)"]
    ZF["zimmerframe (npm walker)"]
    B["compiler_core<br/>builders: b.empty"]
    ERR["compiler_diagnostics<br/>typescript_invalid_feature · js_parse_error"]

    TM -- "read_script → parse(…, is_script = true)" --> A
    TM -- "read_expression / read_pattern → parse_expression_at" --> A
    A --> AC
    A --> TSP
    R --> ZF
    R -- "type-only node → EmptyStatement" --> B
    R -- "unsupported TS feature" --> ERR
    A -- "Acorn errors funnel via Parser.acorn_error" --> ERR

    P -- "AST.Root { fragment, instance, module, comments }" --> R
    R -- "pure-ESTree ASTs" --> AN
    AN --> TR
```

### 3.1 Positioning within the compile pipeline

```mermaid
flowchart LR
    SRC["`.svelte` source"] --> PP["compiler_preprocess<br/>(optional, full TS → JS)"]
    PP --> TPL["Template parsing<br/>(compiler_parser / state machine)"]
    SRC --> TPL
    TPL --> JSP["**JS/TS processing**<br/>(this module)"]
    JSP --> AST["AST.Root with<br/>clean ESTree scripts + comments"]
    AST --> AZ["Analysis (Phase 2)"]
    AZ --> XF["Transform (Phase 3)"]
    XF --> OUT["JS module (client / server)"]

    style JSP fill:#ffe9b3,stroke:#b8860b,stroke-width:2px
```

---

## 4. `acorn.js` — JS/TS Parsing

### 4.1 Parser selection

```javascript
const ParserWithTS = acorn.Parser.extend(tsPlugin());
// typescript ? ParserWithTS : acorn.Parser
```

The template `Parser` (see [compiler_parser](compiler_parser.md)) pre-scans the source for `<script lang="ts">` and stores the result on `parser.ts`. Every call into this module receives that flag and selects the plain Acorn parser or the TypeScript-extended parser accordingly.

All parsing uses a fixed configuration:

| Option | Value | Reason |
|---|---|---|
| `sourceType` | `'module'` | Svelte scripts are ES modules; `export`/`import` must always be accepted. |
| `ecmaVersion` | `16` | Latest syntax support (the compiler is not a down-level parser). |
| `locations` | `true` | Line/column info for diagnostics and sourcemaps. |
| `onComment` | custom handler | Comment capture (see below). |

### 4.2 `parse()` — full programs

```javascript
parse(source, comments, typescript, is_script) → Program
```

Callers:

- `read/script.js::read_script` — parses `<script>` contents with `is_script = true`, producing the `content: Program` of `AST.Script` nodes (instance / module scripts).
- `phases/2-analyze/index.js::analyze_module` — parses the source for the public `compileModule` API (`typescript = false`, `is_script = false`).

**`is_script` behavior — the `undefinedExports` patch.** A component-level binding can be exported from an instance script even though its declaration is not *lexically inside* that script's source fragment. To keep Acorn from rejecting such exports, when `is_script` is truthy the wrapper temporarily monkey-patches `parser.prototype.parseStatement` so that `this.undefinedExports` is reset to `{}` after every parsed statement; the original method is restored in a `finally` block. This makes `export { x }` legal even when `x` lives outside the parsed snippet.

Errors thrown by Acorn are not surfaced directly — callers wrap the call in `try/catch` and route the error through `Parser.acorn_error(err)`, which converts it into a normalized `js_parse_error` diagnostic (stripping Acorn's `(line:col)` position suffix). See [compiler_diagnostics](compiler_diagnostics.md).

### 4.3 `parse_expression_at()` — inline expressions

```javascript
parse_expression_at(source, comments, typescript, index) → Expression
```

Parses a single expression beginning at `index`. Consumers in the template state machine:

- `read/expression.js::read_expression` — `{...}` expression tags, directive values, event handlers, etc. It also uses the comments captured during this call to detect the *true end* of an expression tag (a trailing comment after the expression extends the consumed range) and to balance enclosing parentheses.
- `read/context.js::read_pattern` — destructuring patterns in `each`/`let`/snippet parameter contexts (where TypeScript type annotations are separately read and tolerated).

Because expression parsing starts mid-document, `get_comment_handlers` filters collected comments to those starting at/after `index`, so comments preceding the expression are not wrongly attached to it.

### 4.4 Comment capture — `get_comment_handlers()`

Acorn does not place comments in the AST. This factory returns two coordinated pieces:

**`onComment` callback** (passed to Acorn): appends each comment to the caller-owned array as a `CommentWithLocation`:

```javascript
{ type: 'Block' | 'Line', value, start, end, loc: { start, end } }
```

For **multi-line block comments**, the common indentation of the comment (computed from the first line of the comment in the source) is stripped from every line, so `svelte-ignore` matching and formatter output are whitespace-insensitive.

**`add_comments(ast)` post-processor**: after parsing, walks the AST (zimmerframe) and attaches comments to nodes, preserving them for downstream tooling:

| Rule | Result |
|---|---|
| Comments starting before `node.start` | pushed onto `node.leadingComments` |
| Comment after `node.end` separated only by `,` `)` whitespace | single `node.trailingComments` entry |
| Node is **last in a body** (`BlockStatement`, `Program`, `ArrayExpression`, `ObjectExpression`) | *all* following comments up to the parent's end become `trailingComments` (may be separated by newlines) |
| Comments after the **root node** (expression tag or `Program`) | appended to the root's `trailingComments` |

**Why comments matter downstream:**

1. **`svelte-ignore` in JS** — the analyzer's generic `_` visitor reads `leadingComments` of JS nodes and feeds them to `extract_svelte_ignore` to suppress warnings (see [compiler_analyzer](compiler_analyzer.md)).
2. **Formatter preservation** — `prettier-plugin-svelte` relies on attached comments so formatting does not drop them.
3. **Expression end detection** — `read_expression` uses the last captured comment's `end` to decide where an expression tag truly ends.
4. **Migration** — the [compiler_migrate](compiler_migrate.md) tooling reads comments with positions when rewriting sources.

### 4.5 Script parsing sequence

```mermaid
sequenceDiagram
    autonumber
    participant C as compile() (compiler_core)
    participant TP as Template Parser (compiler_parser)
    participant SM as State machine (template_state_machine)
    participant RS as read_script
    participant AP as acorn.js::parse
    participant RN as remove_typescript_nodes
    participant AZ as compiler_analyzer

    C->>TP: _parse(source)
    TP->>TP: scan lang="ts" → parser.ts
    loop while index < template.length
        TP->>SM: state(parser)
        SM->>RS: on <script …>
        RS->>RS: read until </script>; blank prefix preserves offsets
        RS->>AP: parse(src, root.comments, parser.ts, true)
        AP->>AP: select parser (TS plugin if ts)
        AP->>AP: onComment collects positioned comments
        AP->>AP: patch parseStatement (undefinedExports) if is_script
        AP-->>RS: ESTree Program
        AP->>AP: add_comments(Program)
    end
    TP-->>C: AST.Root { fragment, instance, module, comments, metadata.ts }
    alt metadata.ts === true
        C->>RN: remove_typescript_nodes(fragment / instance / module / extend)
        RN-->>C: pure-ESTree ASTs
    end
    C->>AZ: analyze_component(parsed, …)
```

---

## 5. `remove_typescript_nodes.js` — TypeScript Stripping

### 5.1 Entry points

- **`remove_typescript_nodes(ast)`** — called by `compiler/index.js::compile` **once, after template parsing**, when `parsed.metadata.ts` is `true`. It walks the `fragment` (template AST, whose expressions may contain TS types), the `instance` and `module` script `Program`s, and a potential custom-element `extend` AST.
- **`remove_this_param(node, context)`** — the listed core component; bound as the visitor for `FunctionExpression` and `FunctionDeclaration`. If the first parameter is an identifier literally named `this` (TypeScript's `this`-parameter feature), it is shifted off the parameter list before continuing traversal.

### 5.2 Handling matrix

The visitor set partitions every TypeScript construct into four actions:

```mermaid
flowchart TD
    N["TS-augmented ESTree node"] --> G{"construct category"}
    G -- "type-only declarations<br/>(interface, type alias, declare class/method/var,<br/>abstract methods, type-only import/export specifiers,<br/>TSDeclareFunction)" --> RM["replace with EmptyStatement<br/>(b.empty from compiler_core)"]
    G -- "type wrappers<br/>(TSAsExpression, TSSatisfiesExpression,<br/>TSNonNullExpression, TSTypeAssertion,<br/>TSInstantiationExpression)" --> UW["unwrap → visit inner expression"]
    G -- "annotation properties<br/>(typeAnnotation, typeParameters, typeArguments,<br/>returnType, accessibility)" --> DEL["deleted from every node<br/>(generic _ visitor)"]
    G -- "this parameter" --> SHIFT["remove_this_param:<br/>params.shift()"]
    G -- "unsupported runtime features<br/>(decorators, enums, namespaces with values,<br/>constructor parameter properties,<br/>accessor fields)" --> ERR["throw typescript_invalid_feature"]
    RM --> OUT["clean ESTree AST"]
    UW --> OUT
    DEL --> OUT
    SHIFT --> OUT
```

| TS construct | Action | Detail |
|---|---|---|
| Type annotations, generics, return types, `accessibility` | **Delete** | The generic `_` visitor deletes these properties from *every* visited node so `esrap` (the printer used in Phase 3) is never confused. |
| `TSAsExpression` / `TSSatisfiesExpression` / `TSNonNullExpression` / `TSTypeAssertion` / `TSInstantiationExpression` | **Unwrap** | Replaced by their inner expression (`x as T` → `x`). |
| `import type …`, `export type …`, type-only specifiers | **Remove** | Replaced with `b.empty` (`EmptyStatement`), or specifiers are filtered out. |
| `TSInterfaceDeclaration`, `TSTypeAliasDeclaration`, `TSDeclareFunction` | **Remove** | Replaced with `b.empty`. |
| `declare` classes / methods / variables, `abstract` methods, `declare` property definitions | **Remove** | Dropped from the AST (ClassBody filtering removes `declare` PropertyDefinitions). |
| `implements` clause | **Delete** | Removed from `ClassDeclaration`; the class body is preserved. |
| `this` parameter | **Remove** | `remove_this_param` strips a leading `this` identifier from function parameters. |
| Namespaces (`TSModuleDeclaration`) | **Conditional** | Visited; allowed only if the body contains nothing but type-level nodes (which are removed), otherwise → error. |
| **Decorators**, **enums**, **constructor parameter properties** (`readonly`/accessibility), **`accessor` fields** | **Error** | `typescript_invalid_feature` compile error with guidance to use a preprocessor. |

### 5.3 Rationale — why strip instead of transpile?

Svelte's compiler consumes TS **syntax** (via `acorn-typescript`) but deliberately does **not** implement TS **semantics**. Stripping achieves:

- A single AST dialect (pure ESTree) across analysis and both transform back-ends — no TS branches in [compiler_analyzer](compiler_analyzer.md) or the transform visitors.
- Printer safety: `esrap` would choke on `typeAnnotation`/`typeArguments` properties, hence the blanket deletion in `_`.
- A clear contract: features that need code *transformation* (enums, decorators, …) fail fast at parse time with actionable errors pointing to [compiler_preprocess](compiler_preprocess.md).

---

## 6. End-to-End Data Flow

```mermaid
flowchart TD
    subgraph S["Source input"]
        T[".svelte template"]
        M["JS module source<br/>(compileModule)"]
    end

    subgraph P1["Phase 1 — Parse"]
        TP["Template state machine<br/>(compiler_parser_template_state_machine)"]
        AP["acorn.js<br/>parse / parse_expression_at"]
        CM["comments[]<br/>(positioned, attached to AST)"]
        RN["remove_typescript_nodes<br/>(only if metadata.ts)"]
    end

    subgraph P2["Phase 2 — Analyze"]
        AZ["compiler_analyzer<br/>(scopes, bindings, runes, ignores)"]
    end

    subgraph P3["Phase 3 — Transform"]
        XF["compiler_client_transform / compiler_server_transform"]
    end

    T --> TP
    TP -- "<script> source" --> AP
    TP -- "{…} expressions / patterns" --> AP
    AP --> CM
    AP -- "Program / Expression nodes" --> RN
    CM -- "leading/trailingComments" --> AZ
    RN -- "pure ESTree" --> AZ
    M -- "parse(…, false, false)" --> AP
    AZ -- "analysis" --> XF

    style AP fill:#ffe9b3,stroke:#b8860b,stroke-width:2px
    style RN fill:#ffe9b3,stroke:#b8860b,stroke-width:2px
```

Key contracts of the module's outputs:

- **Programs** (`AST.Script.content`) and **expressions** are position-accurate ESTree nodes; the script wrapper blanks out everything before the script body with spaces, so offsets remain valid against the *original* template string.
- **Comments** are collected into `parser.root.comments` (shared array) *and* attached to AST nodes; both views are consumed (state machine for expression end detection, analyzer for ignores, migration for rewriting).
- **`metadata.ts`** on the parsed root tells `compile()` whether the stripping pass is required.

---

## 7. Dependencies

### External (npm)

| Package | Used for |
|---|---|
| `acorn` | Base ECMAScript parser (`Parser`, `Parser.parse`, `Parser.parseExpressionAt`). |
| `@sveltejs/acorn-typescript` | `tsPlugin()` — extends Acorn with TypeScript syntax (no transform, parse-only). |
| `zimmerframe` | AST walking in `add_comments` and `remove_typescript_nodes` (visitor + context model). |

### Internal (see module docs)

| Module | Dependency |
|---|---|
| [compiler_core](compiler_core.md) | `builders.js` — `b.empty` (`EmptyStatement`) used as the replacement node for removed type-only declarations. |
| [compiler_diagnostics](compiler_diagnostics.md) | `errors.js` — `typescript_invalid_feature` (unsupported TS constructs) and `js_parse_error` (Acorn failures via `Parser.acorn_error`). |
| [compiler_parser](compiler_parser.md) | Parent module: the `Parser` class owns `parser.ts`, `parser.root.comments` and the error funnel this module plugs into. |
| [compiler_parser_template_state_machine](compiler_parser_template_state_machine.md) | Primary caller — `read_script`, `read_expression`, `read_pattern`. |
| [compiler_analyzer](compiler_analyzer.md) | Downstream consumer; `analyze_module` calls `parse` directly, and the analyzer reads attached comments for `svelte-ignore`. |

---

## 8. Diagnostics & Failure Modes

| Situation | Result |
|---|---|
| Syntax error in script or expression | Acorn throws; caller funnels through `Parser.acorn_error` → `js_parse_error` with the Acorn `(line:col)` suffix stripped. |
| Unclosed `<script>` | `element_unclosed` (thrown by `read_script`, not this module). |
| Decorators, enums, namespaces containing values, constructor parameter properties, `accessor` fields inside `lang="ts"` code | `typescript_invalid_feature` error with preprocessor guidance. |
| Loose parsing mode (`parse(source, { loose: true })`) | Expression failures may fall back to a placeholder empty `Identifier` so tooling still receives an AST. |

For the diagnostics architecture (error codes, code frames, warning filters), see [compiler_diagnostics](compiler_diagnostics.md).

---

## 9. Related Modules

- [compiler_parser](compiler_parser.md) — parent module: overall parse phase structure and the `Parser` class.
- [compiler_parser_template_state_machine](compiler_parser_template_state_machine.md) — the callers of `parse` / `parse_expression_at`; how `<script>` and `{…}` are detected.
- [compiler_parser_parse_utilities](compiler_parser_parse_utilities.md) — `read_options`, fuzzy matching, and HTML entity utilities used in the same phase.
- [compiler_analyzer](compiler_analyzer.md) — consumes the clean ASTs; consumes attached comments for `svelte-ignore`.
- [compiler_core](compiler_core.md) — builder helpers (`b.empty`) and the `compile` / `compileModule` entry points that orchestrate stripping.
- [compiler_diagnostics](compiler_diagnostics.md) — error/warning infrastructure used by this module.
- [compiler_preprocess](compiler_preprocess.md) — the recommended path for full TypeScript support (transpilation before compilation).
- [compiler_migrate](compiler_migrate.md) — downstream consumer of positioned comments.
