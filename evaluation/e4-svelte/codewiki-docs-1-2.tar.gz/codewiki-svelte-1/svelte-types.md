# svelte-types

> **Module:** `svelte-types` (child of [Public API Surface & Compatibility Layer](public_api.md))
> **Artifact:** `packages/svelte/types/index.d.ts`
> **Nature:** *Generated* — bundled by `dts-buddy` from the public declaration sources of every Svelte entry point.

---

## 1. Introduction

The `svelte-types` module is the **single, canonical TypeScript type contract** for the entire public surface of the `svelte` package. It is one physical file — `packages/svelte/types/index.d.ts` — that declares, as a series of ambient `declare module` blocks plus a set of global declarations, every type that consumers of Svelte may import or rely on:

- **Component model types** — `Component`, `SvelteComponent`, `Snippet`, `EventDispatcher`, `ComponentProps`, `MountOptions`, …
- **Runes** — global ambient declarations for `$state`, `$derived`, `$effect`, `$props`, `$bindable`, `$inspect`, `$host`
- **Compiler API** — `compile`, `parse`, `preprocess`, `migrate`, `CompileOptions`, `CompileResult`, and the public `AST` / `CSS` namespaces
- **Stores, reactivity, motion, transitions, actions, attachments, events, server rendering and legacy compatibility** types

Because the file is **generated**, it functions as a *facade*: implementations live in the runtime and compiler modules of this repository (see [Related modules](#8-related-module-documentation)), while this module freezes their observable shape for TypeScript consumers, IDEs (svelte-check / language-tools), and library authors. Editing type behavior therefore means editing the **source declaration files**, never the generated artifact.

### Key characteristics

| Property | Value |
|---|---|
| Location | `packages/svelte/types/index.d.ts` |
| Generator | `packages/svelte/scripts/generate-types.js` (uses `dts-buddy`'s `createBundle`) |
| Declaration strategy | Ambient `declare module '<entry>'` blocks + global ambient scope |
| Internal API stripping | `stripInternal: true` — anything tagged `@internal` (and its dependencies) is removed |
| Companion shims | Root-level `*.d.ts` shims that re-import `./types/index.js` for non-`bundler` module resolution; legacy shims under `types/compiler/` |
| Format constraints | No relative JSDoc links (must be `https://svelte.dev/...`); no `export { … }` statements (build fails if violated) |

---

## 2. Generation Pipeline

The file is rebuilt as part of the package build. `scripts/generate-types.js` maps each **package import name** to the **source declaration file** that owns it, then `dts-buddy` inlines everything into one bundle:

```mermaid
flowchart TB
    subgraph sources["Public declaration sources (packages/svelte/src/)"]
        IDX["src/index.d.ts<br/>(module 'svelte')"]
        AMB["src/ambient.d.ts<br/>imported by index.d.ts<br/>(*.svelte ambient + runes)"]
        ACT["src/action/public.d.ts"]
        ANI["src/animate/public.d.ts"]
        ATT["src/attachments/public.d.ts"]
        CMP["src/compiler/public.d.ts"]
        EAS["src/easing/index.js"]
        LEG["src/legacy/legacy-client.js"]
        MOT["src/motion/public.d.ts"]
        REA["src/reactivity/index-client.js"]
        REW["src/reactivity/window/index.js"]
        SRV["src/server/index.d.ts"]
        STO["src/store/public.d.ts"]
        TRA["src/transition/public.d.ts"]
        EVE["src/events/public.d.ts"]
        LP1["src/compiler/preprocess/legacy-public.d.ts"]
        LP2["src/compiler/types/legacy-interfaces.d.ts"]
    end

    GEN["scripts/generate-types.js<br/>dts-buddy createBundle<br/>stripInternal: true"]

    subgraph out["Generated artifacts"]
        TIDT["types/index.d.ts<br/>(this module — 16 ambient modules + globals)"]
        SHIMS["root shims: index.d.ts, compiler.d.ts,<br/>action.d.ts, animate.d.ts, easing.d.ts,<br/>motion.d.ts, store.d.ts, transition.d.ts, legacy.d.ts<br/>each: import './types/index.js'"]
        LSHIMS["legacy shims (remove in Svelte 6):<br/>types/compiler/preprocess.d.ts<br/>types/compiler/interfaces.d.ts"]
    end

    CONS["Consumers: app code, svelte-check,<br/>svelte-language-tools, bundler plugins"]

    IDX --> GEN
    AMB -. "pulled in via import './ambient.js'" .-> IDX
    ACT --> GEN
    ANI --> GEN
    ATT --> GEN
    CMP --> GEN
    EAS --> GEN
    LEG --> GEN
    MOT --> GEN
    REA --> GEN
    REW --> GEN
    SRV --> GEN
    STO --> GEN
    TRA --> GEN
    EVE --> GEN
    LP1 --> GEN
    LP2 --> GEN

    GEN --> TIDT
    GEN --> SHIMS
    GEN --> LSHIMS
    TIDT --> CONS
    SHIMS --> CONS
```

### Entry-point → source mapping

| Ambient module in `types/index.d.ts` | Declaration source | Contracted implementation modules |
|---|---|---|
| `'svelte'` | `src/index.d.ts` (+ `src/ambient.d.ts` for globals) | [public_api](public_api.md), [context_api_client](context_api_client.md) / [context_api_server](context_api_server.md), reactive runtime |
| `'svelte/action'` | `src/action/public.d.ts` | [actions_and_attachments](actions_and_attachments.md) |
| `'svelte/animate'` | `src/animate/public.d.ts` | [transitions_and_animations](transitions_and_animations.md) (`flip`) |
| `'svelte/attachments'` | `src/attachments/public.d.ts` | [actions_and_attachments](actions_and_attachments.md) |
| `'svelte/compiler'` | `src/compiler/public.d.ts` | [compiler_core_entry](compiler_core_entry.md), [compiler_types_template_ast](compiler_types_template_ast.md), [compiler_types_css_ast](compiler_types_css_ast.md) |
| `'svelte/easing'` | `src/easing/index.js` | [transitions_and_animations](transitions_and_animations.md) |
| `'svelte/events'` | `src/events/public.d.ts` | client DOM event system |
| `'svelte/legacy'` | `src/legacy/legacy-client.js` | [legacy_compat](legacy_compat.md) |
| `'svelte/motion'` | `src/motion/public.d.ts` | [motion](motion.md) |
| `'svelte/reactivity'` | `src/reactivity/index-client.js` | [reactive_builtin_classes](reactive_builtin_classes.md) |
| `'svelte/reactivity/window'` | `src/reactivity/window/index.js` | [reactive_builtin_classes](reactive_builtin_classes.md) |
| `'svelte/server'` | `src/server/index.d.ts` | [server_runtime_payload_model](server_runtime_payload_model.md) |
| `'svelte/store'` | `src/store/public.d.ts` | [stores](stores.md) |
| `'svelte/transition'` | `src/transition/public.d.ts` | [transitions_and_animations](transitions_and_animations.md) |
| `'svelte/types/compiler/preprocess'` ⚠ deprecated | `src/compiler/preprocess/legacy-public.d.ts` | [compiler_preprocess_contracts](compiler_preprocess_contracts.md) |
| `'svelte/types/compiler/interfaces'` ⚠ deprecated | `src/compiler/types/legacy-interfaces.d.ts` | [compiler_types_compiler_api](compiler_types_compiler_api.md) |

> **Note:** The root-level `elements.d.ts` / `svelte-html.d.ts` DOM typings are **static files, not generated** — they belong to the sibling module [svelte_element_types](svelte_element_types.md).

### Build-time validation rules

The generator fails the build when:

1. **Relative JSDoc links** exist (all doc links must be absolute, prefixed with `https://svelte.dev`) — keeps rendered hover docs functional in editors.
2. **`export { … }` statements** appear — downstream `d.ts` generation via `@sveltejs/package` mishandles them; declaration sources must `export interface Foo {}` directly.
3. Anything marked **`@internal`** is silently stripped (not an error, but a guarantee).

---

## 3. Architecture — Ambient Module Map

The file is organized into two layers:

```mermaid
flowchart LR
    ROOT["types/index.d.ts"]

    subgraph mods["Ambient module declarations (16)"]
        M1["'svelte'<br/>component model, lifecycle,<br/>context, snippets, mount/hydrate"]
        M2["'svelte/action'"]
        M3["'svelte/animate'"]
        M4["'svelte/attachments'"]
        M5["'svelte/compiler'<br/>compile API + AST/CSS namespaces"]
        M6["'svelte/easing'"]
        M7["'svelte/events'"]
        M8["'svelte/legacy'"]
        M9["'svelte/motion'"]
        M10["'svelte/reactivity'"]
        M11["'svelte/reactivity/window'"]
        M12["'svelte/server'"]
        M13["'svelte/store'"]
        M14["'svelte/transition'"]
        M15["'svelte/types/compiler/preprocess'<br/>(deprecated alias)"]
        M16["'svelte/types/compiler/interfaces'<br/>(deprecated alias)"]
    end

    subgraph glob["Global ambient scope"]
        G1["declare module '*.svelte'<br/>default export: LegacyComponentType / SvelteComponent"]
        G2["Runes: $state · $derived · $effect ·<br/>$props · $bindable · $inspect · $host"]
    end

    ROOT --> mods
    ROOT --> glob
```

- **Ambient module declarations** make `import type { X } from 'svelte/...'` resolve to the bundled contract regardless of the consumer's `moduleResolution` mode.
- **Global declarations** (from `src/ambient.d.ts`) make `.svelte` imports and compiler-injected runes usable in plain `.ts`/`.svelte` files without any import statement — the runes do not exist in user code; the Svelte compiler rewrites them (see [Compiler Back-End](compiler-back-end.md) for how runes are transformed).

---

## 4. Type Catalog by Domain

### 4.1 Component model (module `'svelte'`)

The dual component story (Svelte 4 classes vs Svelte 5 functions) is expressed as two parallel families, bridged by inference helpers and the legacy compat layer:

```mermaid
classDiagram
    class Component~Props, Exports, Bindings~ {
        <<interface - Svelte 5 function component>>
        +element: typeof HTMLElement
        +z_bindings: Bindings
        +invoke(internals, props) Exports
    }
    class SvelteComponent~Props, Events, Slots~ {
        <<class - Svelte 4 shape>>
        +element: typeof HTMLElement
        +prop_def: Props
        +events_def: Events
        +slot_def: Slots
        +on(type, callback) function
        +set(props) void
        +destroy() void
    }
    class SvelteComponentTyped {
        <<deprecated alias of SvelteComponent>>
    }
    class ComponentInternals {
        <<branded opaque type>>
    }
    class ComponentConstructorOptions~Props~ {
        +target
        +anchor
        +props
        +context
        +hydrate
        +intro
    }
    class ComponentProps {
        <<inference helper>>
    }
    class ComponentEvents {
        <<deprecated inference helper>>
    }
    class ComponentType~Comp~ {
        <<constructor type helper>>
    }
    class Snippet~Parameters~ {
        <<callable interface>>
        +invoke(args) branded-error
    }
    class MountOptions~Props~ {
        +target
        +anchor
        +props
        +context
        +intro
    }
    class EventDispatcher~EventMap~ {
        <<deprecated - createEventDispatcher>>
        +invoke(type, parameter, options) boolean
    }

    SvelteComponentTyped --|> SvelteComponent
    Component ..> ComponentInternals : first param
    ComponentType ..> SvelteComponent : wraps constructor
    ComponentType ..> ComponentConstructorOptions : ctor arg
    ComponentProps ..> SvelteComponent : infer Props
    ComponentProps ..> Component : infer Props
    ComponentEvents ..> SvelteComponent : infer Events
    SvelteComponent ..> ComponentConstructorOptions : constructor
    MountOptions ..> Component : mount() accepts
```

Key members of the `'svelte'` module:

| Category | Types / Functions |
|---|---|
| Components | `Component`, `SvelteComponent`, `SvelteComponentTyped` (deprecated), `ComponentInternals`, `ComponentConstructorOptions` (deprecated), `ComponentProps`, `ComponentEvents` (deprecated), `ComponentType` (deprecated), `MountOptions` |
| Snippets | `Snippet<Parameters>` (typed callable, guarded against direct invocation), `createRawSnippet`, internal `Getters<T>` |
| Instantiation | `mount`, `hydrate`, `unmount` (returns `Promise<void>` with `outro`), `flushSync`, `tick`, `settled`, `untrack` |
| Lifecycle (legacy) | `onMount`, `onDestroy`, `beforeUpdate` / `afterUpdate` (deprecated → `$effect.pre` / `$effect`), `getAbortSignal` |
| Context | `getContext`, `setContext`, `hasContext`, `getAllContexts` |
| Legacy events | `createEventDispatcher`, `EventDispatcher`, `DispatchOptions` |

**Design patterns worth knowing:**

- **Branding:** `ComponentInternals = Branded<{}, 'ComponentInternals'>` uses a `unique symbol` so consumers cannot fabricate the internals object passed as the first argument of a `Component`.
- **Snippet call-guard:** `Snippet` returns a branded object whose property name *is the error message* (`'{@render ...} must be called with a Snippet'`), so calling a snippet outside `{@render}` is a type error.
- **Conditional props:** `MountOptions`, `hydrate` and `render` use `{} extends Props ? { props?: Props } : { props: Props }` — `props` is only optional when the component accepts no required props.
- **Typing-only fields:** `$$prop_def`, `$$events_def`, `$$slot_def`, `$$bindings` and `z_$$bindings` exist purely for the type checker / language tools; they are documented as "does not exist at runtime".
- **`Properties<Props, Slots>` back-compat:** components with a default slot implicitly accept `children?: any` (the trade-off of this compat shim is documented in-source).

### 4.2 Runes (global ambient declarations)

Runes are compiler keywords, not real runtime functions. The global declarations describe their *observable* behavior so that TS code inside `.svelte` files type-checks before compilation:

| Rune | Signature surface | Namespace members |
|---|---|---|
| `$state` | `<T>(initial: T): T` / `<T>(): T \| undefined` | `raw`, `snapshot` (+ `Snapshot<T>`, `Cloneable`, `NonReactive<T>`, `Primitive` helper types) |
| `$derived` | `<T>(expression: T): T` | `by` |
| `$effect` | `(fn): void` | `pre`, `pending`, `tracking`, `root` |
| `$props` | `(): any` | `id` |
| `$bindable` | `<T>(fallback?: T): T` | — |
| `$inspect` | `<T extends any[]>(...values): { with }` | `trace` |
| `$host` | `<El extends HTMLElement>(): El` | — |

Each rune namespace deliberately redeclares `Function` members (`apply`, `call`, `bind`, `prototype`, …) as `never` + `@deprecated` so intellisense does not suggest applying a rune like a regular function.

The `*.svelte` ambient module types the default export as an intersection usable both ways during migration:

```ts
const Comp: LegacyComponentType;   // new (options) => SvelteComponent  |  (...args) => Exports
type Comp = SvelteComponent;
export default Comp;
```

`LegacyComponentType` is defined in the `'svelte/legacy'` block — see [legacy_compat](legacy_compat.md) for the runtime bridge.

### 4.3 Compiler API (module `'svelte/compiler'')

Contracts the compiler pipeline documented in [Compiler Front-End](compiler-front-end.md) / [Compiler Infrastructure](compiler-infrastructure.md):

- **Functions:** `compile`, `compileModule`, `parse` (two overloads: legacy AST vs `modern: true` → `AST.Root`), `preprocess`, `migrate`, `VERSION`, and a deprecated `walk` (→ use `estree-walker`).
- **Options:** `CompileOptions extends ModuleCompileOptions` — covers `generate`, `dev`, `runes`, `customElement`, `css: 'injected' | 'external'`, `cssHash`, `fragments: 'html' | 'tree'`, `hmr`, `modernAst`, `sourcemap`, `compatibility.componentApi`, experimental `experimental.async`, …
- **Results & diagnostics:** `CompileResult` (`js`, `css`, `warnings`, `metadata.runes`, `ast`), `Warning` and `CompileError` both extending the structural `ICompileDiagnostic` type (`code`, `message`, `start`/`end` `Location`, `position`, `frame`) — the concrete catalogs live in [compiler_diagnostics](compiler_diagnostics.md).
- **Preprocessing contracts:** `Processed`, `MarkupPreprocessor`, `Preprocessor`, `PreprocessorGroup` (also re-exported through the deprecated `svelte/types/compiler/preprocess` alias; engine in [compiler_preprocess_engine](compiler_preprocess_engine.md)).

**Public AST namespaces** — `AST` (template) and `AST.CSS` (internal name `_CSS`) mirror the internal type model of [compiler_types_template_ast](compiler_types_template_ast.md) and [compiler_types_css_ast](compiler_types_css_ast.md):

```mermaid
classDiagram
    class AST_BaseNode {
        +type string
        +start number
        +end number
    }
    class Root {
        +options SvelteOptions
        +fragment Fragment
        +css StyleSheet
        +instance Script
        +module Script
        +comments JSComment
    }
    class Fragment {
        +nodes Node array
    }
    class BaseElement {
        +name string
        +attributes attributes-directives
        +fragment Fragment
    }
    class RegularElement
    class Component
    class SvelteBoundary
    class SvelteWindow
    class IfBlock {
        +test Expression
        +consequent Fragment
        +alternate Fragment
        +elseif boolean
    }
    class EachBlock
    class AwaitBlock
    class KeyBlock
    class SnippetBlock
    class Directive {
        <<union of 8 directive nodes>>
    }
    class CSS_StyleSheet {
        +children rules and atrules
    }
    class CSS_Rule {
        +prelude SelectorList
        +block Block
    }
    class CSS_SimpleSelector {
        <<union: Type / Id / Class / Attribute /<br/>PseudoElement / PseudoClass /<br/>Percentage / Nth / Nesting>>
    }

    AST_BaseNode <|-- Root
    AST_BaseNode <|-- Fragment
    AST_BaseNode <|-- IfBlock
    AST_BaseNode <|-- EachBlock
    AST_BaseNode <|-- AwaitBlock
    AST_BaseNode <|-- KeyBlock
    AST_BaseNode <|-- SnippetBlock
    AST_BaseNode <|-- BaseElement
    BaseElement <|-- RegularElement
    BaseElement <|-- Component
    BaseElement <|-- SvelteBoundary
    BaseElement <|-- SvelteWindow
    Fragment ..> Directive : contains attributes
    CSS_StyleSheet --> CSS_Rule
    CSS_Rule --> CSS_SimpleSelector
```

The `AST.TemplateNode` / `Tag` / `Block` / `ElementLike` unions (`ConstTag`, `DebugTag`, `HtmlTag`, `RenderTag`, `AttachTag`, `ExpressionTag`, `Text`, `Comment`, …) and the full `_CSS` node union (`StyleSheet`, `Rule`, `Atrule`, `SelectorList`, `ComplexSelector`, `RelativeSelector`, `Combinator`, `SimpleSelector`, `Declaration`, `Block`) are what the analyzer visitors ([compiler_analyzer](compiler_analyzer.md)) and the code-generation visitors ([compiler_client_transform](compiler_client_transform.md), [compiler_server_transform](compiler_server_transform.md)) traverse. The legacy (Svelte 4) AST is *not* part of this public file; it remains internal to [compiler_types_legacy_ast](compiler_types_legacy_ast.md) and is exposed only as an opaque `Record<string, any>` from legacy `parse`.

### 4.4 Stores (module `'svelte/store'`)

Contracts [stores](stores.md). Core interfaces:

```mermaid
classDiagram
    class Readable~T~ {
        +subscribe(run, invalidate) Unsubscriber
    }
    class Writable~T~ {
        +set(value) void
        +update(updater) void
    }
    class Subscriber~T~
    class Unsubscriber
    class Updater~T~
    class StartStopNotifier~T~
    class Stores
    class StoresValues

    Writable --|> Readable
    Readable ..> Subscriber : runs
    Readable ..> Unsubscriber : returns
    Writable ..> Updater : update arg
    Stores ..> StoresValues : resolves via infer
```

- Interfaces: `Readable<T>`, `Writable<T>`, helper types `Subscriber`, `Unsubscriber`, `Updater`, `StartStopNotifier`, `Stores`, `StoresValues`
- Functions: `readable`, `writable`, `derived` (two overloads: sync fn vs `set`/`update` callback), `readonly`, `get`
- **Runes interop:** `toStore(get, set?)` (function-state → store) and `fromStore(store)` (`{ current }` object, writable view for `Writable`) — the bridge between the store contract and the signal runtime in [client_runtime_core_signal_model](client_runtime_core_signal_model.md).

### 4.5 Reactivity primitives (modules `'svelte/reactivity'` and `'svelte/reactivity/window'`)

Contracts [reactive_builtin_classes](reactive_builtin_classes.md):

- `SvelteDate`, `SvelteSet<T>`, `SvelteMap<K, V>`, `SvelteURL` (with `SvelteURLSearchParams` `searchParams`), `SvelteURLSearchParams` (`[REPLACE]` internal symbol member)
- `MediaQuery extends ReactiveValue<boolean>` and the shared (non-exported in name, structural in shape) `ReactiveValue<T>` base with a `current` getter
- `createSubscriber(start)` — the documented integration point for event-driven external systems (the doc-block example re-implements `MediaQuery` with it)
- Window set: `scrollX`, `scrollY`, `innerWidth`, `innerHeight`, `outerWidth`, `outerHeight`, `screenLeft`, `screenTop`, `online`, `devicePixelRatio` — all `ReactiveValue<T | undefined>`, `undefined` on the server

### 4.6 Motion (module `'svelte/motion'`)

Contracts [motion](motion.md). Notable: the `Spring` and `Tween` classes use **declaration merging** — a deprecated `Spring<T> extends Readable<T>` interface (store-era members: `subscribe`, `update`, `set`) merged with the modern `Spring` class (`target`, `current`, `set(value, { instant, preserveMomentum })`, `Spring.of`). The same pattern applies to `Tween` / deprecated `tweened(): Tweened<T>`, plus `prefersReducedMotion: MediaQuery`, `SpringOpts`, `SpringUpdateOpts`, `TweenedOptions<T>`.

### 4.7 Transitions, animations, easing

Contracts [transitions_and_animations](transitions_and_animations.md):

- `'svelte/transition'`: `TransitionConfig`, `EasingFunction`, parameter interfaces `BlurParams`, `FadeParams`, `FlyParams`, `SlideParams`, `ScaleParams`, `DrawParams`, `CrossfadeParams`, and functions `blur`, `fade`, `fly`, `slide`, `scale`, `draw` (requires `getTotalLength`), `crossfade` (returns a `[send, receive]` pair).
- `'svelte/animate'`: `AnimationConfig` (`delay/duration/easing/css/tick`), `FlipParams`, `flip`.
- `'svelte/easing'`: the full easing function catalog (`linear`, `backIn/Out/InOut`, `bounce*`, `circ*`, `cubic*`, `elastic*`, `expo*`, `quad*`, `quart*`, `quint*`, `sine*`).

### 4.8 Actions & attachments

Contracts [actions_and_attachments](actions_and_attachments.md):

- `'svelte/action'`: `Action<Element, Parameter, Attributes>` (callable interface with conditional-argument arity based on `undefined extends Parameter`) and `ActionReturn` (`update?`, `destroy?`, typing-only `$$_attributes`).
- `'svelte/attachments'`: `Attachment<T extends EventTarget>` (element → optional cleanup), `createAttachmentKey(): symbol`, and two `fromAction` overloads converting an `Action` into an `Attachment` (arg supplied lazily via a function).

### 4.9 Server rendering (module `'svelte/server'`)

- `render(...)` with conditional-arity overloads driven by `{} extends Props` (required-props variant vs optional-props variant), accepting both legacy `ComponentType` and `Component` inputs.
- `RenderOutput { head, body, html (deprecated) }` — the payload contract implemented by [server_runtime_payload_model](server_runtime_payload_model.md).

### 4.10 Events (module `'svelte/events'`)

`on(target, type, handler, options?) => () => void` with **five overloads** mapping target kinds (`Window`, `Document`, `HTMLElement`, `MediaQueryList`, generic `EventTarget`) to their corresponding event maps — guaranteeing handler parameter typing while preserving ordering with Svelte's delegated `onclick` attributes.

### 4.11 Legacy compatibility (module `'svelte/legacy'`)

Contracts [legacy_compat](legacy_compat.md):

- `createClassComponent`, `asClassComponent`, `run`, `handlers`, `createBubbler`
- `LegacyComponentType` — the dual class/function callable used by the `*.svelte` ambient declaration
- Event-modifier substitutes: `trusted`, `self`, `stopPropagation`, `once`, `stopImmediatePropagation`, `preventDefault`, `passive`, `nonpassive` (all deprecated)

### 4.12 Deprecated alias modules

`svelte/types/compiler/preprocess` (`Processed_1`, `MarkupPreprocessor_1`, `Preprocessor_1`, `PreprocessorGroup_1`, `SveltePreprocessor_1`) and `svelte/types/compiler/interfaces` (`CompileOptions_1`, `Warning_1`) keep historical import paths (`import … from 'svelte/types/compiler/interfaces'`) working so tooling can support Svelte 4–6 simultaneously. Both are scheduled for removal in Svelte 6.

---

## 5. Component Interaction & Data Flow

### 5.1 Type checking a `.svelte` import

```mermaid
sequenceDiagram
    participant App as App code (.ts / .svelte)
    participant TS as TypeScript checker
    participant G as Global: declare module '*.svelte'
    participant C as 'svelte' module types
    participant L as LegacyComponentType

    App->>TS: import App from './App.svelte'
    TS->>G: resolve ambient module '*.svelte'
    G->>L: default export typed as LegacyComponentType
    L->>C: bridged to SvelteComponent / Component surface
    C-->>TS: Props / Events / Slots (via $ def fields)
    TS-->>App: type-checked instantiation, props, snippets
```

### 5.2 Compile-time contract flow

```mermaid
flowchart LR
    SRC["Component source<br/>.svelte / .js with runes"] -->|"typed against"| RUNES["Global rune declarations<br/>$state, $effect, ..."]
    SRC -->|"input to"| COMPILE["compile() / compileModule()<br/>(contract: CompileOptions)"]
    COMPILE -->|"returns"| RESULT["CompileResult<br/>js + css + warnings + ast"]
    RESULT -->|"ast typed as"| ASTNS["AST / AST.CSS namespaces<br/>(mirror of compiler_types)"]
    RESULT -->|"consumed by"| TOOLS["Bundler plugins & tooling<br/>(vite-plugin-svelte, svelte-check)"]
    COMPILE -->|"emits runtime calls typed by"| RT["Runtime modules<br/>mount/hydrate/unmount, signals, DOM/SSR"]
```

The `compile` input contract (`CompileOptions`) and the emitted runtime calls (e.g. `mount`, `$.spread`, `template` cloning controlled by `fragments`) are bound together by this module: tooling reads the contract, the compiler and runtime implement it.

### 5.3 Position within the repository

```mermaid
flowchart TB
    subgraph api["Public API Surface & Compatibility Layer"]
        direction LR
        PA["public_api<br/>(runtime entries)"]
        TYPES["svelte-types<br/>(THIS MODULE)"]
        SET["svelte_element_types"]
        AA["actions_and_attachments"]
        LC["legacy_compat"]
    end

    subgraph impls["Implementing modules (types describe their contracts)"]
        direction LR
        CT["compiler_types<br/>+ AST/CSS/legacy AST"]
        ST["stores"]
        RBC["reactive_builtin_classes"]
        MO["motion"]
        TAA["transitions_and_animations"]
        SRP["server_runtime_payload_model"]
        CRC["client_runtime_core"]
        CCP["compiler_preprocess_contracts"]
    end

    USERS["TypeScript consumers:<br/>apps · svelte-check · language-tools · component libraries"]

    impls -->|"declaration sources (public.d.ts)<br/>bundled at build time"| TYPES
    PA --- TYPES
    SET --- TYPES
    AA --- TYPES
    LC --- TYPES
    TYPES -->|"ambient declarations"| USERS
    USERS -.->|"call into"| PA
```

---

## 6. Conventions & Invariants

1. **Generated artifact — do not hand-edit.** All changes go to the source declaration files listed in the mapping table; `types/index.d.ts` is regenerated.
2. **Public vs internal:** `@internal` JSDoc tags are stripped from the bundle — the file only ever reflects the public contract. Internal counterparts (e.g. `TransformState` in `3-transform/types.d.ts`, the `Signal` model) are intentionally absent; see [compiler_client_transform_state_and_reactivity](compiler_client_transform_state_and_reactivity.md) and [client_runtime_core_signal_model](client_runtime_core_signal_model.md).
3. **Back-compat discipline:** deprecated types are kept *typed and documented* (JSDoc `@deprecated` + migration-guide links) rather than removed — `SvelteComponent`, `SvelteComponentTyped`, `ComponentEvents`, `ComponentType`, `createEventDispatcher`, `spring`/`tweened` stores, `svelte/types/compiler/*` aliases.
4. **Single-file ambient bundling** exists so that all TS `moduleResolution` modes work: root shims (`action.d.ts`, `compiler.d.ts`, …) simply `import './types/index.js'`.
5. **Doc links must be absolute** (`https://svelte.dev/...`) — enforced by the generator.
6. **No `export { … }` re-export statements** — enforced by the generator for downstream `d.ts` emit compatibility.

---

## 7. Maintenance Guide

| Task | Where to change |
|---|---|
| Add/modify a type for `svelte` core (components, mount, context, snippets) | `packages/svelte/src/index.d.ts` (and `src/index-client.js` / `src/index-server.js` for JS) |
| Change a rune's declared shape | `packages/svelte/src/ambient.d.ts` |
| Compiler API / AST surface | `packages/svelte/src/compiler/public.d.ts`; the mirrored internal model lives in `src/compiler/types/template.d.ts` / `css.d.ts` ([compiler_types](compiler_types.md)) |
| Store contract | `packages/svelte/src/store/public.d.ts` |
| Reactivity classes | `packages/svelte/src/reactivity/*` (client bundle entry `index-client.js`) |
| Motion contract | `packages/svelte/src/motion/public.d.ts` |
| Transition contract | `packages/svelte/src/transition/public.d.ts` |
| Action / attachment contract | `packages/svelte/src/action/public.d.ts`, `packages/svelte/src/attachments/public.d.ts` |
| Server render contract | `packages/svelte/src/server/index.d.ts` (+ `src/server/types.d.ts`) |
| Legacy contract | `packages/svelte/src/legacy/legacy-client.js` |
| Regenerate | run the package build (`scripts/generate-types.js`) |

After regeneration, the two validation gates (link check, no-`export {}` check) run automatically; a failure means the *source* declaration files need fixing, not the output.

---

## 8. Related Module Documentation

**Parent / siblings (Public API Surface & Compatibility Layer):**
- [public_api](public_api.md) — runtime entry implementations typed by this module
- [svelte_element_types](svelte_element_types.md) — static DOM typings (`elements.d.ts`, `svelte-html.d.ts`), complementary to this generated module
- [actions_and_attachments](actions_and_attachments.md) · [legacy_compat](legacy_compat.md) — implementations of the `svelte/action`, `svelte/attachments`, `svelte/legacy` contracts

**Compiler (AST & API contracts):**
- [compiler_types](compiler_types.md) · [compiler_types_template_ast](compiler_types_template_ast.md) · [compiler_types_css_ast](compiler_types_css_ast.md) · [compiler_types_legacy_ast](compiler_types_legacy_ast.md) · [compiler_types_compiler_api](compiler_types_compiler_api.md)
- [compiler_core_entry](compiler_core_entry.md) — implements `compile` / `compileModule`
- [compiler_analyzer](compiler_analyzer.md) · [compiler_client_transform](compiler_client_transform.md) · [compiler_server_transform](compiler_server_transform.md) — consumers of the `AST` unions
- [compiler_preprocess_contracts](compiler_preprocess_contracts.md) · [compiler_preprocess_engine](compiler_preprocess_engine.md) — preprocessor contract and engine

**Runtime (implementation of typed behavior):**
- [stores](stores.md) · [reactive_builtin_classes](reactive_builtin_classes.md) · [motion](motion.md) · [transitions_and_animations](transitions_and_animations.md)
- [client_runtime_core_signal_model](client_runtime_core_signal_model.md) — internal signal model backing `fromStore`/`toStore` and runes
- [server_runtime_payload_model](server_runtime_payload_model.md) — implements `RenderOutput`
- [context_api_client](context_api_client.md) · [context_api_server](context_api_server.md) — implement the `getContext`/`setContext` contract
