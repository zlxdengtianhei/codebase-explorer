# compiler_preprocess_engine

## 1. Introduction

`compiler_preprocess_engine` is the execution engine of Svelte's source preprocessing system, implemented entirely in [`packages/svelte/src/compiler/preprocess/index.js`](https://github.com/sveltejs/svelte/blob/main/packages/svelte/src/compiler/preprocess/index.js). It exposes a single public async function — **`preprocess(source, preprocessor, options)`** — that applies user-supplied transformation hooks to a `.svelte` component *before* the compiler's parser ever sees the code. Typical use cases are converting `<style lang="sass">` blocks into vanilla CSS or transpiling `<script lang="ts">` TypeScript into JavaScript.

The engine's responsibilities are:

1. **Hook orchestration** — run `markup`, `script`, and `style` preprocessor hooks in a deterministic order for a single preprocessor group or an ordered list of groups.
2. **Tag-level code surgery** — locate every `<script>` / `<style>` tag (while safely skipping HTML comments) and splice preprocessor output back into the markup.
3. **Source-map integrity** — accumulate, offset, chain and finally combine source maps from every transformation step so that positions in the final output still resolve back to the original component source.
4. **Dependency tracking** — collect the files each preprocessor reports (e.g., imported `.scss` partials) so downstream watchers can monitor them.

It is a *pre-compiler* utility: it does **not** parse Svelte syntax, build an AST, or emit runtime code. It transforms raw text and hands the result — plus one chained source map — to the rest of the toolchain.

## 2. Position in the Overall System

```
Bundler plugin (vite-plugin-svelte, svelte-preprocess, …)
        │
        ▼
┌───────────────────────────────┐
│  compiler_preprocess_engine   │  ← this module (preprocess())
└───────────────┬───────────────┘
                │ Processed { code, map, dependencies }
                ▼
Compiler_Front-End (Parsing, Analysis & CSS Scoping Pipeline)   →  Compiler_Back-End (Client & Server Code Generation)
```

Key integration facts:

- `preprocess` is re-exported from the compiler's public entry (`packages/svelte/src/compiler/index.js`, `export { default as preprocess } from './preprocess/index.js'`) and is therefore part of the [Public_API_Surface___Compatibility_Layer_(Entries,_Type_Contracts,_Extensions___Legacy_Support)](Public_API_Surface___Compatibility_Layer_(Entries,_Type_Contracts,_Extensions___Legacy_Support).md) module as `svelte/compiler`'s `preprocess`.
- It runs strictly **before** the parse phase of the [Compiler_Front-End_(Parsing,_Analysis___CSS_Scoping_Pipeline)](Compiler_Front-End_(Parsing,_Analysis___CSS_Scoping_Pipeline).md) module; `compile()` itself does *not* invoke preprocessing — external tooling is expected to call `preprocess()` first and then pass `Processed.code` (and chain `Processed.map`) into `compile()`.
- The hook signatures it consumes (`Processed`, `MarkupPreprocessor`, `Preprocessor`, `PreprocessorGroup`) are specified by the sibling contracts module [compiler_preprocess_contracts](compiler_preprocess_contracts.md), which also back the public `SveltePreprocessor` type re-exported via [Public API types](Public_API_Surface___Compatibility_Layer_(Entries,_Type_Contracts,_Extensions___Legacy_Support).md).
- Preprocessing is orthogonal to the [Compiler_Infrastructure_(Core_Orchestration,_Diagnostics___AST_Type_Model)](Compiler_Infrastructure_(Core_Orchestration,_Diagnostics___AST_Type_Model).md) orchestration layer: the engine keeps its own mutable state (`PreprocessResult`) instead of using `compiler/state.js`, and emits warnings directly (`console.warn` for malformed inline source maps) rather than through the compiler's warning pipeline.

## 3. Architecture

### 3.1 Core Components

| Component | Kind | Visibility | Role |
|---|---|---|---|
| `preprocess(source, preprocessor, options)` | async function | **public** (default export) | Entry point. Normalizes the preprocessor input, drives the markup → script → style passes per group, and produces the final `Processed` result. |
| `PreprocessResult` (class) | class | internal | Mutable accumulation state for one `preprocess()` run. Implements the private `Source` interface; owns the source string, the newest-first sourcemap stack, the dependency list, the character→position locator, and the file basename. |
| `process_markup(process, source)` | async function | internal | Runs one `MarkupPreprocessor` against the whole file content; converts its output into a `SourceUpdate`. |
| `process_tag(tag_name, preprocessor, source)` | async function | internal | Scans the markup for all `<script>` or `<style>` tags with a dedicated regex, schedules per-tag replacement work, and returns a `SourceUpdate` containing the rewritten string, the merged map, and collected dependencies. |
| `process_single_tag(tag_with_content, attributes, content, tag_offset)` | async closure | internal | Handles **one** tag instance: short-circuits no-ops, invokes the script/style preprocessor with parsed attributes, and delegates mapping to `processed_tag_to_code`. (Listed as a core component of this module.) |
| `processed_tag_to_code(...)` | function | internal | Builds the `MappedCode` for a replaced tag: open tag + preprocessed content + close tag, each carrying correct source mappings. |
| `processed_content_to_code(processed, location, file_basename)` | function | internal | Converts preprocessor content output (code + optional map) into `MappedCode`, offsetting segments that point at the original component source. |
| `parse_tag_attributes(str)` / `stringify_tag_attributes(attrs)` | functions | internal | Regex-based round-trip between a raw attribute string and a `Record<string, string \| boolean>`; the stringifier renders the *generated* attributes the preprocessor returns. |

### 3.2 Internal & External Dependencies

The engine delegates all source-map mathematics and string splicing to neighbouring infrastructure utilities:

| Dependency | Origin | Used for |
|---|---|---|
| `getLocator` | `locate-character` (npm) | Building the `get_location(index) → {line, column}` locator for the current source text. |
| `MappedCode` | `../utils/mapped_code.js` | The `string + decoded-map` pair that makes incremental concatenation with map merging possible (`concat`, `from_processed`, `from_source`). |
| `combine_sourcemaps`, `sourcemap_add_offset`, `parse_attached_sourcemap`, `get_basename` | `../utils/mapped_code.js` | Final map chaining (via `@jridgewell/remapping`), shifting tag-content segments into absolute positions, extracting `sourceMappingURL=data:` annotations from preprocessor output, and deriving the `sources[0]` basename. |
| `decode_map` | `./decode_sourcemap.js` | Normalizing preprocessor maps (JSON string, object, or `SourceMapGenerator`) into *decoded* mappings. |
| `replace_in_code`, `slice_source` | `./replace_in_code.js` | Regex-driven asynchronous replacement with identity-mapped unchanged regions; creating offset-relative `Source` views. |

### 3.3 Architecture Diagram

```mermaid
flowchart TB
    subgraph engine["compiler_preprocess_engine — index.js"]
        PRE["preprocess(source, groups, options)<br/>public entry point"]

        subgraph state["PreprocessResult (implements Source)"]
            SRC["source / filename"]
            LOC["get_location (locate-character)"]
            BASE["file_basename"]
            MAPS["sourcemap_list (newest-first stack)"]
            DEPS["dependencies[]"]
        end

        MK["process_markup()"]
        PT["process_tag('script' │ 'style')"]
        PST["process_single_tag()"]
        ATTR["parse_tag_attributes()<br/>stringify_tag_attributes()"]
        PTTC["processed_tag_to_code()"]
        PCTC["processed_content_to_code()"]
    end

    subgraph utils["compiler / utils infrastructure"]
        RP["replace_in_code()<br/>slice_source()<br/>(replace_in_code.js)"]
        DM["decode_map()<br/>(decode_sourcemap.js)"]
        MC["MappedCode<br/>(mapped_code.js)"]
        CS["combine_sourcemaps()<br/>sourcemap_add_offset()<br/>parse_attached_sourcemap()<br/>(mapped_code.js)"]
    end

    subgraph hooks["User preprocessor groups"]
        HMK["markup?: MarkupPreprocessor"]
        HSC["script?: Preprocessor"]
        HST["style?: Preprocessor"]
    end

    PRE -->|"create / update_source()"| state
    PRE -->|"await, per group"| MK & PT
    MK --> HMK
    PT --> PST
    PST --> ATTR
    PST --> HSC
    PT --> HST
    PST --> PTTC
    PTTC --> PCTC
    PT --> RP
    PCTC --> DM & MC & CS
    PTTC --> CS
    MK --> RP
    state -->|"to_processed()"| OUT["Processed { code, map, dependencies, toString }"]
```

## 4. State Model

The engine is a *mutable accumulator* driven by `SourceUpdate` events. Private contracts come from `preprocess/private.d.ts`:

- **`Source`** — `{ source, get_location(index), file_basename, filename? }`; the coordinate system every mapping math is expressed in.
- **`SourceUpdate`** — `{ string?, map?, dependencies? }`; the delta produced by each hook pass.
- **`Replacement`** — `{ offset, length, replacement: MappedCode }`; one spliced tag region (managed by `replace_in_code.js`).

```mermaid
classDiagram
    class PreprocessResult {
        +string source
        +string? filename
        +List~SourceMap~ sourcemap_list
        +List~string~ dependencies
        +string? file_basename
        +Locator get_location
        +update_source(SourceUpdate) void
        +to_processed() Processed
    }
    class Source {
        <<interface>>
        +string source
        +get_location(index) Location
        +string file_basename
        +string? filename
    }
    class SourceUpdate {
        <<interface>>
        +string? string
        +DecodedSourceMap? map
        +List~string~? dependencies
    }
    class Processed {
        +string code
        +object|string? map
        +List~string~ dependencies
        +Record~string,string|bool~? attributes
        +toString() string
    }
    class MappedCode {
        +string string
        +DecodedSourceMap map
        +concat(other) MappedCode
        +from_processed(string, map)$ MappedCode
        +from_source(Source)$ MappedCode
    }
    PreprocessResult ..|> Source : implements
    PreprocessResult ..> SourceUpdate : consumes via update_source()
    PreprocessResult ..> Processed : produces via to_processed()
    MappedCode ..> Source : from_source()
```

Important state behaviours:

- **`update_source()`** replaces the source string *and rebuilds the locator* (positions are always valid for the *current* text), **unshifts** a new map onto `sourcemap_list` (so the list is ordered newest → oldest, exactly what `@jridgewell/remapping`'s multi-transformation mode expects), and appends dependencies.
- **`to_processed()`** collapses the whole run: `combine_sourcemaps(file_basename, sourcemap_list)` chains all maps back to the original file; dependencies are de-duplicated via `Set`; the result carries a `toString()` so a `Processed` behaves like a plain string.
- **`file_basename`** is the last path segment of `filename` (or `null` if unnamed). Preprocessor maps are expected to reference the input file by that basename — the equality check inside `combine_sourcemaps` relies on this convention (flagged as brittle in upstream comments).

## 5. Execution Flow

### 5.1 Top-level Sequence

```mermaid
sequenceDiagram
    autonumber
    participant T as Tooling (bundler plugin)
    participant P as preprocess()
    participant R as PreprocessResult
    participant H as User hooks (markup/script/style)
    participant E as Mapping pipeline (MappedCode, maps)

    T->>P: await preprocess(source, group(s), { filename })
    P->>R: new PreprocessResult(source, filename)
    loop each PreprocessorGroup, in array order (sequential await)
        opt group.markup defined
            P->>H: markup({ content: whole file, filename })
            H-->>P: Processed? (code, map, dependencies)
            P->>E: parse map if string (JSON.parse)
            P->>R: update_source({ string, map, dependencies })
        end
        opt group.script defined
            P->>H: process_tag('script') → per <script> tag: script({ content, attributes, markup, filename })
            H-->>E: Processed? per tag
            E-->>R: update_source({ string, map, dependencies })
        end
        opt group.style defined
            P->>H: process_tag('style') → per <style> tag
            E-->>R: update_source({ string, map, dependencies })
        end
    end
    P->>R: to_processed()
    R->>R: combine_sourcemaps(file_basename, sourcemap_list)
    R-->>T: Processed { code, map, dependencies, toString }
```

Fixed ordering guarantees:

1. Groups run **sequentially** — group *N+1* sees the output of group *N*.
2. Within a group the hook order is **markup → script → style**, regardless of object key order.
3. Inside one `process_tag` pass, all matching tags are discovered first; their preprocessors may run **concurrently** (`Promise.all` inside `calculate_replacements`), but the splice back into the source is deterministic by offset.

### 5.2 Markup Pass vs. Tag Pass

```mermaid
flowchart LR
    subgraph markuppass["Markup pass — process_markup()"]
        A["entire file content"] --> B["markup preprocessor"]
        B -->|"Processed"| C["SourceUpdate<br/>{ string: code,<br/>map: decoded,<br/>dependencies }"]
        B -->|"void"| D["{} — no change"]
    end
    subgraph tagpass["Tag pass — process_tag()"]
        E["current source string"] --> F{"regex_script_tags /<br/>regex_style_tags scan"}
        F -->|"<!-- comment -->"| G["identity-mapped<br/>unchanged slice"]
        F -->|"&lt;script&gt;/&lt;style&gt; tag"| H["process_single_tag()"]
        H -->|"no attrs & no content"| G
        H -->|"preprocessor returns<br/>void or identical code w/o map"| G
        H -->|"real change"| I["processed_tag_to_code()"]
        G --> J["replace_in_code():<br/>splice replacements between<br/>identity-mapped prefixes/suffixes"]
        I --> J
        J --> K["SourceUpdate { string, map, dependencies }"]
    end
```

Regex details worth knowing:

- `regex_script_tags` / `regex_style_tags` share the shape `/<!--[^]*?-->|<tag(attrs)?(\/>|>content<\/tag>)/g`. The leading comment alternative ensures HTML comments containing the literal text `<script>`/`<style>` are matched (and then preserved verbatim) rather than corrupting the scan.
- Attribute capture tolerates double-quoted, single-quoted, and bare values; self-closing forms (`<script ... />`) are supported.
- `parse_tag_attributes` converts the captured string into a plain record (booleans for valueless attributes) that is handed to the preprocessor; if the preprocessor returns `attributes`, `stringify_tag_attributes` re-renders them into the generated open tag — this is how preprocessors drop attributes like `lang="ts"` after transpiling.

## 6. Tag Replacement & Source-Map Construction (deep dive)

`process_single_tag` → `processed_tag_to_code` composes the replacement for one tag as **three concatenated `MappedCode` fragments**:

```mermaid
flowchart TB
    subgraph frag["MappedCode fragments for one replaced tag"]
        direction LR
        OPEN["tag_open_code<br/>&lt;tag generated_attrs&gt;"] --> CONTENT["content_code<br/>preprocessed code"] --> CLOSE["tag_close_code<br/>&lt;/tag&gt;"]
    end
    subgraph mapsrc["How each fragment is mapped"]
        O1["|generated - original| length differs →<br/>synthesized map: map &lt;tag-name&gt; prefix<br/>and end-of-tag columns onto the<br/>ORIGINAL open tag (multi-line aware),<br/>offset by get_location(0)"]
        O2["equal length →<br/>identity map from slice_source()"]
        C1["decode_map(processed) →<br/>sourcemap_add_offset(map,<br/>location of content start,<br/>source_index of file_basename)<br/>→ only segments pointing at the<br/>component file are shifted"]
        C2["parse_attached_sourcemap():<br/>strip & adopt<br/>'//# sourceMappingURL=data:…'<br/>(scripts: // or /* */, styles: /* */)"]
        CL["identity map anchored at<br/>offset original_tag_open.length + content.length"]
    end
    OPEN -.-> O1
    OPEN -.-> O2
    CONTENT -.-> C2
    CONTENT -.-> C1
    CLOSE -.-> CL
    CONCAT["MappedCode.concat() chain:<br/>merge sources/names tables,<br/>re-index segments,<br/>shift columns at junction lines"]
    frag --> CONCAT
    CONCAT --> UPD["SourceUpdate.string + .map<br/>(+ per-tag dependencies)"]
```

Mechanics worth highlighting:

1. **No-op short-circuits** in `process_single_tag` keep output byte-identical and avoid map noise when: the tag has no attributes *and* no content; the preprocessor returns nothing; or it returns the same content with no map.
2. **Open-tag remapping when attributes change length.** If the preprocessor rewrites attributes (e.g., removing `lang="sass"`), the generated open tag no longer matches the original text. A small hand-built decoded map is synthesized: the `<tagname` prefix and the closing `>` of the generated tag are mapped onto the corresponding columns of the *original* open tag, extended line-by-line for multi-line open tags, then shifted by the tag's absolute start location.
3. **Content-map offsetting.** The preprocessor's own map (produced e.g. by Sass) covers the tag content in content-local coordinates. `processed_content_to_code` decodes it and calls `sourcemap_add_offset` with the absolute location of the content start — but **only for segments whose `source` is `file_basename`**, so imports from other files (e.g. an `@import`ed `.scss` file) keep their own coordinates.
4. **Inline source maps.** `parse_attached_sourcemap` extracts base64 `sourceMappingURL=data:` annotations appended by the preprocessor to `processed.code` and promotes them to `processed.map` (removing the comment). Conflicts (inline *and* explicit map) or path-only annotations produce `console.warn` diagnostics with a code excerpt.
5. **Concatenation.** `MappedCode.concat` merges the fragment strings and their maps: source/name tables are unioned and segment indices re-written, columns on junction lines shifted by the previous fragment's last-line length, and the boundary lines merged.
6. **Unchanged regions.** `perform_replacements` (in `replace_in_code.js`) interleaves the tag replacements with **identity-mapped** unchanged prefixes/suffixes built by `MappedCode.from_source`, producing one continuous map for the whole updated string.

## 7. Sourcemap Chaining Strategy

```mermaid
flowchart TD
    ORIG["original component.svelte<br/>sources entry: file_basename"]
    M1["markup hook map<br/>(if any)"]
    M2["script pass merged map"]
    M3["style pass merged map"]
    STK["PreprocessResult.sourcemap_list<br/>unshift ⇒ newest-first:<br/>[M3, M2, M1]"]
    M1 -->|unshift| STK
    M2 -->|unshift| STK
    M3 -->|unshift| STK
    CB["combine_sourcemaps(file_basename, list)<br/>@jridgewell/remapping"]
    STK --> CB
    CB -->|"array interface — when every map<br/>has exactly one source"| FINAL
    CB -->|"loader interface — when an<br/>intermediate map has multiple<br/>sources; chain on sourcefile === filename"| FINAL
    FINAL["Processed.map — one map<br/>from final code back to the<br/>original component source"]
    ORIG -.->|referenced by sources[0]| M1
```

- Each pass contributes **one** map; intermediate text positions always come from the current `get_location` locator, so maps remain composable even though the string changes between passes.
- The final `Processed.map` is what a bundler plugin feeds into its own map chain (alongside `Processed.code`) before/after invoking `compile()`.
- The engine deliberately produces *high-resolution identity maps* for untouched regions (`MappedCode.from_source` maps every token) because they will be merged and their resolution reduced later — precision is preserved where it is cheap.

## 8. API Reference

### `preprocess(source, preprocessor, options)` → `Promise<Processed>` *(public default export)*

| Parameter | Type | Description |
|---|---|---|
| `source` | `string` | Raw `.svelte` component source. |
| `preprocessor` | `PreprocessorGroup \| PreprocessorGroup[]` | One group or an ordered list of groups; each may define `name?`, `markup?`, `script?`, `style?` hooks (see [compiler_preprocess_contracts](compiler_preprocess_contracts.md)). |
| `options.filename` | `string?` | Component filename. Falls back to a legacy `(preprocessor as any).filename` property for backwards compatibility. |

Returns a `Processed` object: `{ code, map?, dependencies: string[], toString() }` — see the contract documentation for full semantics. If every hook is a no-op, `map` is `null` and `dependencies` is empty.

### Hook invocation payloads (what user code receives)

- **Markup preprocessor:** `{ content: <whole file>, filename? }`
- **Script/style preprocessor:** `{ content: <tag inner text, '' if absent>, attributes: Record<string, string | boolean>, markup: <whole file>, filename? }`

A hook may return `void` (unchanged), or a `Processed`-like `{ code, map?, dependencies?, attributes? }`. `attributes` is only honoured on script/style tags and rewrites the tag's attribute list.

### `process_single_tag(tag_with_content, attributes?, content?, tag_offset)` → `Promise<MappedCode>` *(internal)*

Core per-tag worker closed over the current `Source` and preprocessor: decides between identity (no-change) output and a fully mapped replacement; aggregates `processed.dependencies` into the enclosing `process_tag` scope. It is the seam through which all user script/style code enters the engine.

## 9. Design Decisions & Invariants

1. **Regex, not parser.** Tag location is done with regular expressions, intentionally *before* parsing, since the input may not yet be valid Svelte (e.g. untranspiled TypeScript). The comment alternative in the regex keeps commented-out tags inert.
2. **Everything is mapped.** Every produced string fragment — changed or unchanged — carries a decoded source map; correctness of downstream stack traces depends on this invariant.
3. **Newest-first map stack.** `sourcemap_list.unshift` yields the ordering `@jridgewell/remapping` expects for chained transformations of one file.
4. **Basename `sources` convention.** Preprocessor maps must reference the input component by its file basename; the offsetting and combining logic key off `sources.indexOf(file_basename)`.
5. **Minimal-churn no-ops.** Multiple early exits (missing content/attributes, void results, identical code without a map) ensure preprocessors that don't apply leave the source untouched.
6. **Sequential groups, parallel tags.** Cross-group ordering is strictly sequential; within one tag pass, independent tags may resolve concurrently but are spliced by offset, keeping the result deterministic.
7. **Legacy compatibility.** The `(preprocessor as any).filename` fallback preserves a historical calling convention; the sibling legacy type declarations (`legacy-public.d.ts`) cover the deprecated `SveltePreprocessor` helper.

## 10. Related Documentation

- [compiler_preprocess](compiler_preprocess.md) — parent module: the preprocessing subsystem as a whole.
- [compiler_preprocess_contracts](compiler_preprocess_contracts.md) — `Processed`, `MarkupPreprocessor`, `Preprocessor`, `PreprocessorGroup`, `SveltePreprocessor` type contracts.
- [Compiler_Front-End_(Parsing,_Analysis___CSS_Scoping_Pipeline)](Compiler_Front-End_(Parsing,_Analysis___CSS_Scoping_Pipeline).md) — the parser/analysis phases that consume preprocessed output.
- [Compiler_Back-End_(Client___Server_Code_Generation)](Compiler_Back-End_(Client___Server_Code_Generation).md) — downstream code generation whose output maps may be chained with `Processed.map`.
- [Compiler_Infrastructure_(Core_Orchestration,_Diagnostics___AST_Type_Model)](Compiler_Infrastructure_(Core_Orchestration,_Diagnostics___AST_Type_Model).md) — compiler entry points, diagnostics model and shared AST types (`mapped_code.js` lives in this layer's utilities).
- [Public_API_Surface___Compatibility_Layer_(Entries,_Type_Contracts,_Extensions___Legacy_Support)](Public_API_Surface___Compatibility_Layer_(Entries,_Type_Contracts,_Extensions___Legacy_Support).md) — where `preprocess` and the preprocessor types are re-exported publicly (`svelte/compiler`).
