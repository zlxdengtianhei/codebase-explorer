# Repository Engineering Infrastructure (Benchmarks, Build Scripts & Playground)

## Purpose

This module houses the **engineering and quality-infrastructure tooling** that supports the Svelte compiler and runtime codebases — everything that lives *outside* the shipped packages but is essential for developing, validating, and maintaining them. It is not part of the compiled output; instead, it provides:

- **Performance benchmarks** that measure the reactive runtime and server-side rendering pipeline against standardized signal-library suites.
- **Comparison tooling** that aggregates and formats benchmark results across implementations and runs.
- **Build & maintenance scripts** that enforce code-quality invariants (e.g., treeshakeability of generated output) and keep compiler diagnostic assets in sync.

## Architecture

The module is organized around two axes: a **benchmarking axis** (three suites feeding a shared comparison pipeline) and a **build/maintenance axis** (scripts embedded in the `packages/svelte` source tree).

```mermaid
flowchart TD
    subgraph Module["Repository Engineering Infrastructure"]
        subgraph Benchmarks["Benchmarking (benchmarking/)"]
            RB["Reactivity Benchmarks<br/>(benchmarking/benchmarks/reactivity)"]
            SB["SSR Benchmarks<br/>(benchmarking/benchmarks/ssr/wrapper)"]
            CT["Benchmark Comparison Tooling<br/>(benchmarking/compare)"]
        end

        subgraph Build["Build & Maintenance Scripts (packages/svelte/scripts)"]
            TS["Treeshakeability Checker"]
            MT["Message Templates"]
        end
    end

    Runtime["Reactive Runtime Engine<br/>(internal/client)"] --> RB
    SSR["Server Runtime (SSR)"] --> SB

    RB --> CT
    SB --> CT

    Compiler["Compiler Output"] -.-> TS
    Diagnostics["Compiler Diagnostics"] -.-> MT

    Playground["Sandbox Playground<br/>(playgrounds/sandbox)"] -.-> Compiler
    Playground -.-> Runtime
```

### Benchmarking axis

```mermaid
flowchart LR
    subgraph Reactivity["Reactivity Benchmark Suites"]
        K["Kairo"]
        SE["SBench"]
        M["MOL"]
    end
    RC["Reactivity Benchmarks"] --> K & SE & M
    RC --> CMP["Comparison Tooling"]
    SSR["SSR Benchmark Wrapper"] --> CMP
    CMP --> OUT["Formatted / compared results"]
```

The reactivity benchmarks evaluate Svelte's signals implementation using three independent, community-standard suites (**Kairo**, **SBench**, **MOL**), which cover core signal operations (read/write, deriveds, effects) and enable apples-to-apples comparison with other reactive libraries. The SSR benchmark wrapper exercises the server-side rendering path for throughput and allocation characteristics. Both feed the comparison tooling, which normalizes and contrasts results across libraries and benchmark runs.

### Build & maintenance axis

The `packages/svelte/scripts` directory contains development-time utilities that run against the package source: the **treeshakeability checker**, which verifies that the compiled, generated client code can be fully tree-shaken by bundlers (a core Svelte performance guarantee), and **message templates**, which manage the canonical compiler error/warning message strings so diagnostics stay consistent and localized.

Alongside these, the `playgrounds/sandbox` directory provides an isolated environment for manually experimenting with compiler and runtime behavior during development.

## Core Components

| Component | Description | Documentation |
|---|---|---|
| `reactivity_benchmarks` | Performance suites (Kairo, SBench, MOL) measuring the reactive runtime's signals, deriveds, and effects against other libraries. | [Reactivity Benchmarks](reactivity_benchmarks.md) |
| `ssr_benchmarks` | SSR benchmark wrapper measuring server-side rendering performance of the server runtime. | [SSR Benchmarks](ssr_benchmarks.md) |
| `benchmark_comparison_tooling` | Tooling to aggregate, normalize, and compare benchmark outputs across implementations and runs. | [Benchmark Comparison Tooling](benchmark_comparison_tooling.md) |
| `svelte_build_tooling` | Build-time maintenance scripts: treeshakeability verification of generated output and compiler message template management. | [Svelte Build Tooling](svelte_build_tooling.md) |