# Legacy Compatibility Layer (`legacy_compat`)

> **Module location:** `packages/svelte/src/legacy/` (exposed as the `svelte/legacy` entry point)

## 1. Purpose & Scope

Svelte 5 replaced the Svelte 4 class-based component model (`new Component({ target, props })`, `$set`/`$on`/`$destroy`, `createEventDispatcher` bubbling, `on:event` modifiers, `$:` reactive blocks) with a function-based, rune-powered component model. The `legacy_compat` module is the **temporary migration bridge** that keeps those Svelte 4 idioms working on top of the Svelte 5 runtime so that codebases can be migrated incrementally.

Every public export in this module is explicitly `@deprecated` — it exists *only* to ease migration to Svelte 5 and will not receive new features.

The module answers four concrete compatibility questions:

| Legacy need | Provided by |
|---|---|
| "I need `new MyComponent(options)` / `$set` / `$on` / `$destroy` / instance exports" | `createClassComponent`, `asClassComponent` (client) + `.render()` (server) |
| "I need `$:` reactive statement semantics" | `run` (client effect wrapper / server immediate call) |
| "I need `on:click|preventDefault\|stopPropagation\|...` modifiers and multi-handler syntax" | `handlers` + re-exported event modifiers |
| "I need `on:click` forwarding without a handler (event bubbling)" | `createBubbler` |

## 2. Architecture Overview

The module is intentionally tiny — **two files, one shared adapter class**:

```
packages/svelte/src/legacy/
├── legacy-client.js   → client-side adapter, run(), event helpers
└── legacy-server.js   → SSR adapter (reuses client code, adds .render(), stubs events)
```

```mermaid
flowchart TB
    subgraph user["Application code (Svelte 4 style)"]
        IMP["import { ... } from 'svelte/legacy'"]
    end

    subgraph legacy["legacy_compat (this module)"]
        LC["legacy-client.js<br/>createClassComponent · asClassComponent · run<br/>handlers · createBubbler · event modifiers"]
        LS["legacy-server.js<br/>asClassComponent (+.render) · run<br/>noop event stubs"]
    end

    subgraph internal["Svelte 5 internal runtime"]
        ADAPT["Svelte4Component adapter class<br/>(internal, in legacy-client.js)"]
        RENDER["internal/client/render.js<br/>mount · hydrate · unmount"]
        BATCH["internal/client/reactivity/batch.js<br/>flushSync"]
        EFF["internal/client/reactivity/effects.js<br/>user_pre_effect ($effect.pre)"]
        SRC["internal/client/reactivity/sources.js<br/>mutable_source · set"]
        RT["internal/client/runtime.js<br/>get · active_effect · set_signal_status"]
        SSR["internal/server/index.js<br/>render"]
        FLAGS["internal/flags/index.js<br/>async_mode_flag"]
        CTX["internal/client/context.js<br/>component_context"]
    end

    IMP --> LC
    IMP --> LS
    LC --> ADAPT
    ADAPT --> RENDER
    ADAPT --> BATCH
    ADAPT --> SRC
    ADAPT --> RT
    ADAPT --> FLAGS
    LC --> EFF
    LC --> CTX
    LS --> LC
    LS --> SSR
```

Key architectural decisions:

1. **Single adapter class (`Svelte4Component`).** Both entry points funnel through one class that impersonates the Svelte 4 component interface. It is not exported directly; users reach it via `createClassComponent()` (factory) or `asClassComponent()` (subclassing).
2. **Server variant *imports* the client variant.** `legacy-server.js` reuses `asClassComponent`/`createClassComponent` from `legacy-client.js` and only adds an SSR `.render()` method plus `noop` stubs. This keeps client bundles free of the server runtime (and vice-versa the server bundle free of DOM code paths).
3. **Coarse-grained reactivity shimming.** Svelte 4 props were *component-granular*: mutating any prop invalidated the whole component. The adapter builds a `Proxy` over per-prop `mutable_source` signals to emulate this behavior using Svelte 5 signals (fine-grained `$state` proxies are deliberately avoided).
4. **Event compatibility is mostly *plumbing*, not *behavior*.** `handlers` and the re-exported modifiers are small wrapper functions; `createBubbler` reads `$$events` out of the component context that the compiler wires up for legacy event forwarding.

## 3. Sub-modules

| Sub-module | File(s) | Responsibility | Documentation |
|---|---|---|---|
| Client-side legacy adapter | `legacy-client.js` | Svelte 4 class-component emulation via the internal `Svelte4Component` adapter (coarse-grained props proxy, `$set`/`$on`/`$destroy`, instance-export forwarding), the `$effect.pre`-based `run()` shim, event multi-handler emulation (`handlers`) and `on:event` modifier re-exports | [legacy_compat_client.md](legacy_compat_client.md) |
| Server-side legacy adapter | `legacy-server.js` | SSR variant that imports the client adapter and attaches the Svelte 4 `.render(props, opts)` contract (translating `{ body, head }` → `{ html, head, css }`), a synchronous server `run()`, and `noop` stubs for every event-related export so shared code does not crash during SSR | [legacy_compat_server.md](legacy_compat_server.md) |

Both sub-modules are two halves of one contract: **`legacy_compat_client.md`** documents everything that requires a DOM / client runtime, while **`legacy_compat_server.md`** documents the thin SSR façade that delegates to it and only diverges where the server runtime differs (`render()` instead of `mount()`, no effects, no events).

## 4. Core Workflows

### 4.1 Wrapping a Svelte 5 component into a Svelte 4 class (client)

```mermaid
sequenceDiagram
    participant App as Application code
    participant API as createClassComponent / asClassComponent
    participant Ad as Svelte4Component (adapter)
    participant R as render.js (mount/hydrate)
    participant RT as signals runtime

    App->>API: new CreateClassComponent({component, target, props, ...})
    API->>Ad: instantiate Svelte4Component
    Ad->>RT: create per-prop mutable_source signals
    Ad->>Ad: build coarse-grained props Proxy (get/has/set → signals)
    Ad->>R: mount(component, {target, props, context, ...})
    Note over Ad,R: hydrate() instead when options.hydrate is set
    Ad->>Ad: expose instance exports as getters/setters (except $set/$on/$destroy)
    Ad->>Ad: install $set (Object.assign → proxy) and $destroy (unmount)
    Ad-->>App: Svelte 4-compatible component instance
    loop later updates
        App->>Ad: $set(props) / prop = value
        Ad->>RT: set(signal, value) → fine-grained effect scheduling
    end
```

Details of the flush-synchronization rule, the `LEGACY_PROPS` proxy trap and event wiring are covered in [legacy_compat_client.md](legacy_compat_client.md).

### 4.2 Server-side rendering of a legacy-wrapped component

```mermaid
sequenceDiagram
    participant App as SSR code
    participant SA as legacy-server.js asClassComponent
    participant CA as legacy-client.js asClassComponent
    participant SR as internal/server render()

    App->>SA: asClassComponent(Component)
    SA->>CA: as_class_component(Component)
    CA-->>SA: Svelte4Component subclass (constructor)
    SA->>SA: attach .render(props, {context}) to constructor
    App->>SA: Component.render(props)
    SA->>SR: render(component, {props, context})
    SR-->>SA: { body, head }
    SA-->>App: { html: body, head, css: {code:'', map:null} }
```

Note the shape translation: the Svelte 5 SSR payload (`{ body, head }`) is remapped to the Svelte 4 contract (`{ html, head, css }`), with `css` always empty because Svelte 5 emits CSS at build time.

### 4.3 Legacy reactive statements (`run`)

```mermaid
flowchart LR
    A["legacy code:<br/>run(() => { ... })<br/>(compiled from $: ... )"] --> B{environment?}
    B -- client --> C["user_pre_effect<br/>($effect.pre)"]
    C --> D{re-marked dirty<br/>within same run?}
    D -- yes --> E["warn legacy_recursive_reactive_block<br/>downgrade DIRTY → MAYBE_DIRTY<br/>(emulates Svelte 4 recursion)"]
    D -- no --> F[done]
    B -- server --> G["fn() executed once, immediately"]
```

## 5. Module Dependencies

```mermaid
flowchart TD
    subgraph this_mod["legacy_compat"]
        LC[legacy-client.js]
        LS[legacy-server.js]
    end

    subgraph reactive["Reactive Runtime Engine (see reactive_runtime_engine.md)"]
        EFFECTS[reactivity/effects.js]
        SOURCES[reactivity/sources.js]
        BATCH[reactivity/batch.js]
        RUNTIME[runtime.js]
        PROPS[reactivity/props.js LEGACY_PROPS]
    end

    subgraph backends["Component Rendering Backends (see component_rendering_backends.md)"]
        CRENDER[client/render.js]
        SRENDER[server/index.js]
        MODS[dom/legacy/event-modifiers.js]
    end

    subgraph platform["Cross-Runtime Platform Services (see cross_runtime_platform_services.md)"]
        FLAGS[flags/index.js]
        CCTX[client/context.js]
        SHARED[shared/utils.js]
        CERR[client/errors.js]
        CWARN[client/warnings.js]
    end

    subgraph types["Public API type contracts (see public_api.md)"]
        TY["SvelteComponent, Component,<br/>ComponentConstructorOptions, ComponentType"]
    end

    LC --> EFFECTS & SOURCES & BATCH & RUNTIME & CRENDER & MODS
    LC --> FLAGS & CCTX & SHARED & CERR & CWARN & PROPS
    LC -. typing only .-> TY
    LS --> LC
    LS --> SRENDER
```

Related modules (not documented here):

- **Reactive Runtime Engine** — provides the signal sources, effects, batching and `get()` machinery the adapter leans on.
- **Component Rendering Backends** — supplies `mount`/`hydrate`/`unmount` (client) and `render` (server).
- **Cross-Runtime Platform Services** — `async_mode_flag` gates `flushSync`, `component_context` enables `createBubbler`.
- **Public API Surface** — `svelte/legacy` is one of the public entry points; the `SvelteComponentTyped`/`Component` type contracts live there.

## 6. Public API Summary

| Export | File | Client/Server | Purpose |
|---|---|---|---|
| `createClassComponent(options)` | legacy-client.js | both (re-exported) | Factory returning a Svelte 4-compatible instance |
| `asClassComponent(component)` | legacy-client.js + legacy-server.js | both (server adds `.render()`) | Convert a component into a Svelte 4 constructor |
| `run(fn)` | both files | both | `$:` statement shim → `$effect.pre` (client) / immediate call (server) |
| `handlers(...fns)` | legacy-client.js | client | Multi-listener emulation (server: `noop`) |
| `createBubbler()` | legacy-client.js | client | `on:event`-without-handler forwarding shim (server: `noop`) |
| `once`, `preventDefault`, `self`, `stopImmediatePropagation`, `stopPropagation`, `trusted`, `passive`, `nonpassive` | legacy-client.js (re-export) | client | `on:directive` modifier functions (server: `noop`) |

## 7. Migration Notes

- All exports are deprecated; the recommended end-state is runes (`$state`, `$derived`, `$effect`), snippets instead of slots, callbacks/attachment props instead of `createEventDispatcher`, and `mount()` instead of `new Component()`.
- `createClassComponent`/`asClassComponent` trade correctness for compatibility: prop reactivity is deliberately *coarse-grained*, `$on` listeners are only cleaned up by `$destroy`, and rendering is force-flushed synchronously unless async mode is active.
- The async-mode flag changes behavior: `flushSync()` is skipped in async mode, so legacy consumers must not assume the DOM is updated synchronously after construction.
- `run()` deviates from Svelte 4 when a reactive block re-triggers itself: instead of recursing forever, it warns (`legacy_recursive_reactive_block`) and marks the effect `MAYBE_DIRTY`.
