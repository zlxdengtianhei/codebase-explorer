# compiler_analyzer_js_visitors

`compiler_analyzer_js_visitors` is the sub-module of the Svelte compiler front-end that implements the **JavaScript-side analysis visitors** of Phase 2 (Analyze). While its sibling groups handle Svelte block syntax (`#if`, `#each`, `#await`, …) and template nodes (elements, directives, tags), this module contains the visitors that fire on **plain ECMAScript AST nodes** — exports, `new` expressions, and template literals — during the depth-first AST walk performed by the analyzer.

These visitors are small, single-purpose functions with a uniform contract:

```js
/**
 * @param {<EstreeNodeType>} node  - the ESTree node currently visited
 * @param {Context} context        - zimmerframe context: { state: AnalysisState, next(), path, ... }
 */
export function <NodeType>(node, context) { /* ... */ context.next(); }
```

Their responsibilities:

1. **Export validation & recording** — enforce Svelte's export rules (no default exports, no `export let` in runes mode, no exporting derived/reassigned state) and populate `analysis.exports`, the component's public export surface consumed by Phase 3.
2. **Reactivity metadata tracking** — mark template expressions as stateful/callful when tagged templates with impure tags are used.
3. **Runtime requirements & performance linting** — flag component instantiation needs (`needs_context`) and discourage inline classes.
4. **Security linting** — detect bidirectional control characters ("Trojan Source") in template literals.

> **Module tree position:** `Compiler_Front-End` → `compiler_analyzer` → `compiler_analyzer_js_visitors` *(current module)*.
> See [compiler_analyzer](compiler_analyzer.md) for the phase orchestration (`analyze_component`) and [compiler_analyzer_scope](compiler_analyzer_scope.md) for the `Scope`/`Binding` machinery these visitors read and mutate.

---

## 1. Component inventory

| Visitor | ESTree node | Category | Diagnostics emitted |
|---|---|---|---|
| `ExportDefaultDeclaration` | `ExportDefaultDeclaration` | Export validation | `module_illegal_default_export` (error) |
| `ExportNamedDeclaration` | `ExportNamedDeclaration` | Export validation + recording | `module_illegal_default_export`, `legacy_export_invalid`, `derived_invalid_export`, `state_invalid_export` (errors) |
| `ExportSpecifier` | `ExportSpecifier` | Export validation + recording | `derived_invalid_export`, `state_invalid_export` (errors, via `validate_export`) |
| `NewExpression` | `NewExpression` | Runtime requirements + perf lint | `perf_avoid_inline_class` (warning) |
| `TaggedTemplateExpression` | `TaggedTemplateExpression` | Reactivity metadata | — |
| `TemplateElement` | `TemplateElement` | Security lint | `bidirectional_control_characters` (warning) |

---

## 2. Architecture & position in the compile pipeline

The Svelte compiler runs in three phases. This module lives in Phase 2, registered in the analyzer's visitor table that `walk()` (from `zimmerframe`) consults for each node. The same visitor table is reused for all three ASTs of a component — the `<script module>` AST, the instance `<script>` AST, and the template fragment (including JS embedded in `{expressions}`) — which is why `ast_type` (`'instance' | 'template' | 'module'`, or `undefined` for `.svelte.js` modules) is the key discriminator used throughout this module.

```mermaid
flowchart TB
    SRC["Svelte source<br/>(.svelte component or .svelte.js module)"]

    subgraph P1["Phase 1 — Parse"]
        PARSE["compiler_parser<br/>parse → Root { module, instance, fragment }"]
    end

    subgraph P2["Phase 2 — Analyze (compiler_analyzer)"]
        AC["analyze_component<br/>creates scopes · builds AnalysisState · walks ASTs"]
        SCOPE["compiler_analyzer_scope<br/>Scope · Binding · set_scope"]
        BV["compiler_analyzer_block_visitors"]
        TV["compiler_analyzer_template_visitors"]
        JV["compiler_analyzer_js_visitors (this module)"]
        AN[("ComponentAnalysis<br/>exports[] · needs_context · bindings · css")]
    end

    subgraph P3["Phase 3 — Transform"]
        CT["compiler_client_transform"]
        SV["compiler_server_transform"]
    end

    SRC --> PARSE --> AC
    SCOPE --> AC
    AC --> BV
    AC --> TV
    AC --> JV
    BV --> AN
    TV --> AN
    JV --> AN
    AN --> CT
    AN --> SV
```

**Inputs** (produced upstream):

- ESTree + Svelte AST from [compiler_parser](compiler_parser.md) (`Root.module`, `Root.instance`, `Root.fragment`).
- Per-node `Context` from the `zimmerframe` walker, carrying an `AnalysisState` (scope, analysis, `ast_type`, `expression` metadata, `function_depth`, …). See `AnalysisState` in the type model ([compiler_types](compiler_types.md)).

**Outputs** (consumed downstream):

- Mutations to `ComponentAnalysis` — primarily `exports: { name, alias }[]` and `needs_context: boolean`.
- Mutations to `Binding`s in the scope tree (`reassigned = true`).
- Compile errors and warnings from [compiler_diagnostics](compiler_diagnostics.md) (thrown/emitted mid-walk).

---

## 3. Execution model

Every visitor is invoked synchronously by the walker. The canonical pattern is *check → record/validate → `context.next()`*; errors abort traversal by throwing. Two visitors deviate from the pattern deliberately (see §4.6 and §5):

```mermaid
sequenceDiagram
    autonumber
    participant W as walk() (zimmerframe)
    participant V as JS visitor (this module)
    participant U as shared/utils.js
    participant B as Scope / Binding
    participant A as ComponentAnalysis

    W->>V: visitor(node, context)
    Note right of V: context.state = AnalysisState<br/>(ast_type · scope · analysis · expression)
    opt export nodes
        V->>B: scope.get(name)
        V->>U: validate_export() / is_pure()
        U--x A: throw CompileError on invalid export
    end
    V->>A: record export / set needs_context / mark has_state
    V->>B: binding.reassigned = true (ExportSpecifier)
    V->>W: context.next() → traverse children
```

The two shared helpers live in the analyzer's `visitors/shared/utils.js` (documented with [compiler_analyzer](compiler_analyzer.md)):

- **`validate_export(node, scope, name)`** — looks up the binding and throws `derived_invalid_export` if it is `$derived` state, or `state_invalid_export` if it is `$state`/`$state.raw` **and** `binding.reassigned`. No-ops when the name is unbound (undefined exports are reported separately by `analyze_component`).
- **`is_pure(node, context)`** — conservatively decides whether an expression is side-effect free: literals are pure; calls are pure only if callee *and* arguments are pure; identifier/member chains are pure only if they resolve to an unbound global (unbound identifiers are assumed safe); `$effect.tracking` is always impure. Local bindings make the expression impure.

---

## 4. Component reference

### 4.1 `ExportDefaultDeclaration`

**File:** `packages/svelte/src/compiler/phases/2-analyze/visitors/ExportDefaultDeclaration.js`

Handles `export default …`. Behaviour branches on `context.state.ast_type`:

- **`ast_type` is falsy → `.svelte.js` / `.svelte.ts` module** (compiled via `compileModule`, see [compiler_core](compiler_core.md); these files have no instance/template split, hence no `ast_type`). A default export is **allowed**, but if the declaration is a bare `Identifier` it is passed to `validate_export` to reject exporting derived or reassigned reactive state. Non-identifier declarations such as `export default $state(0)` or `export default $derived(0)` bypass the check — this is the idiomatic way to export reactive state from a module.
- **`ast_type` is set → `.svelte` component** — a component can never have a default export, so `module_illegal_default_export` is thrown immediately ("A component cannot have a default export").

`context.next()` runs at the end, so children of the exported declaration are still analysed (unless an error aborted the walk first).

```mermaid
flowchart TD
    A["ExportDefaultDeclaration node"] --> B{"context.state.ast_type set?"}
    B -- "no → .svelte.js module" --> C{"declaration is an Identifier?"}
    C -- "yes (export default counter)" --> D["validate_export(counter)"]
    D --> E{"binding kind?"}
    E -- "derived" --> F["⛔ derived_invalid_export"]
    E -- "state / raw_state, reassigned" --> G["⛔ state_invalid_export"]
    E -- "other / unbound" --> H["✓ valid"]
    C -- "no (export default $state(0))" --> H
    B -- "yes → .svelte component" --> I["⛔ module_illegal_default_export"]
    H --> J["context.next()"]
```

### 4.2 `ExportNamedDeclaration`

**File:** `packages/svelte/src/compiler/phases/2-analyze/visitors/ExportNamedDeclaration.js`

The most involved visitor in the module. Processing order matters and is intentional:

1. **`context.next()` is called *first***, before any checks. This guarantees that children — including `ExportSpecifier`s — are visited and all bindings are correctly initialised *before* this visitor inspects `scope.get(...)`.
2. **Default-export ban for modules:** if `ast_type` is truthy-check fails, i.e. the file is a `.svelte.js` module (`!context.state.ast_type`), any specifier exporting the name `default` (identifier *or* string-literal form, e.g. `export { x as "default" }`) raises `module_illegal_default_export`.
3. **Variable declaration exports** (`export const/let/var …`):
   - **Runes mode + instance script + `let`** → `legacy_export_invalid`: "`export let` is forbidden in runes mode — use `$props()` instead".
   - Every declared identifier (flattened through destructuring patterns via `extract_identifiers` from `utils/ast.js`) is resolved to its binding and checked: `derived` → `derived_invalid_export`; `state`/`raw_state` that is `reassigned` → `state_invalid_export`.
4. **Export recording (runes mode + instance script only):** exports that become part of the component's public instance API are pushed to `analysis.exports` as `{ name, alias: null }`:
   - `export function` / `export class` → the declared function/class name.
   - `export const` → every identifier of every declarator.

Exports in the *module* script, and all export handling in **legacy mode** (where exported `let`/`var` become *props*, not exports), are processed directly by `analyze_component` before the walk — see [compiler_analyzer](compiler_analyzer.md) — which is why the recording logic here is gated on `ast_type === 'instance'` and `analysis.runes`.

```mermaid
flowchart TD
    A["ExportNamedDeclaration node"] --> B["context.next()<br/>(children first → ExportSpecifier runs)"]
    B --> C{"in .svelte.js module and a specifier exports 'default'?"}
    C -- yes --> D["⛔ module_illegal_default_export"]
    C -- no --> E{"declaration is a VariableDeclaration?"}
    E -- yes --> F{"runes ∧ instance ∧ kind === 'let'?"}
    F -- yes --> G["⛔ legacy_export_invalid"]
    F -- no --> H["for each declared identifier:<br/>check binding"]
    H --> I{"binding kind?"}
    I -- "derived" --> J["⛔ derived_invalid_export"]
    I -- "state/raw_state, reassigned" --> K["⛔ state_invalid_export"]
    I -- ok --> L{"runes ∧ instance?"}
    E -- no --> L
    L -- yes --> M{"declaration kind?"}
    M -- "function / class" --> N["analysis.exports += { name, alias: null }"]
    M -- "const" --> O["analysis.exports += each identifier"]
    L -- no --> P["done"]
    N --> P
    O --> P
```

### 4.3 `ExportSpecifier`

**File:** `packages/svelte/src/compiler/phases/2-analyze/visitors/ExportSpecifier.js`

Handles the specifier form `export { local as exported }` (visited as a child of `ExportNamedDeclaration`, or of an export-with-source declaration). It resolves both names, tolerating **string-literal** export names (`export { x as "weird name" }`).

- **Instance script + runes mode:**
  - Records the mapping in `analysis.exports` as `{ name: local_name, alias: exported_name }` — the alias is what external consumers see.
  - Marks the local binding as `reassigned = true`. Exported values can be written from the outside (e.g. through component accessors), so the binding must be treated as mutated for all reactivity decisions — a deliberate conservative choice.
- **Otherwise** (module script, `.svelte.js` module, or legacy mode): runs `validate_export` on the local name, rejecting derived or reassigned state exports.

Like `TemplateElement`, this is a leaf node — `context.next()` is never called.

### 4.4 `NewExpression`

**File:** `packages/svelte/src/compiler/phases/2-analyze/visitors/NewExpression.js`

Two effects for **every** instantiation expression (`new X(…)`):

1. **Perf lint:** if the callee is a `ClassExpression` (i.e. `new class { … }`) **and** it occurs inside a function (`scope.function_depth > 0`), emits the `perf_avoid_inline_class` warning ("Avoid 'new class' — declare the class at top level instead"). Inline classes are re-created per invocation and defeat hoisting/optimisation.
2. **Runtime requirement:** unconditionally sets `analysis.needs_context = true`. Instantiations must run with the component's context machinery available (class fields may hold reactive state, constructors may read context, etc.), so the transform must generate context-aware code.

Traversal continues via `context.next()`.

### 4.5 `TaggedTemplateExpression`

**File:** `packages/svelte/src/compiler/phases/2-analyze/visitors/TaggedTemplateExpression.js`

Contributes to the analyzer's **expression metadata** tracking (`context.state.expression`, an `ExpressionMetadata`). When the current node sits inside a tracked template expression (attribute value, text interpolation, …) and the template's **tag** is not `is_pure`, the enclosing expression is marked:

- `has_call = true` — the expression performs function calls (can't be treated as a static value);
- `has_state = true` — the expression may read reactive state and must be re-evaluated on updates.

This metadata drives update granularity / memoization decisions in the template visitors and Phase 3 transforms (see [compiler_analyzer_template_visitors](compiler_analyzer_template_visitors.md), [compiler_client_transform](compiler_client_transform.md), [compiler_server_transform](compiler_server_transform.md)). Traversal continues.

### 4.6 `TemplateElement`

**File:** `packages/svelte/src/compiler/phases/2-analyze/visitors/TemplateElement.js`

A **security linter** for template literal text chunks. It tests the *cooked* string value against `regex_bidirectional_control_characters` (from `phases/patterns.js`), which matches Unicode bidirectional override/isolate characters (U+202A–U+202E, U+2066–U+2069). If found, it emits the `bidirectional_control_characters` warning — these characters can visually reorder source code ("Trojan Source" attacks) and may hide malicious logic from reviewers.

This is the module's only visitor that **does not call `context.next()`**: `TemplateElement` is a leaf node, so recursing into it would be pure overhead.

---

## 5. State & data contracts

### `AnalysisState` fields read

| Field | Type | Used by | Purpose |
|---|---|---|---|
| `ast_type` | `'instance' \| 'template' \| 'module' \| undefined` | all export visitors | Distinguishes instance script / module script / template / `.svelte.js` module |
| `analysis` | `ComponentAnalysis` | all | Read `runes`; write `exports`, `needs_context` |
| `scope` | `Scope` | export visitors, `NewExpression` | `scope.get(name)` binding lookup; `scope.function_depth` |
| `expression` | `ExpressionMetadata \| null` | `TaggedTemplateExpression` | Current tracked expression; written `has_call`, `has_state` |

### `ComponentAnalysis` fields written

| Field | Written by | Shape / effect |
|---|---|---|
| `exports` | `ExportNamedDeclaration`, `ExportSpecifier` | `{ name: string, alias: string \| null }[]` — the runes-mode instance export surface |
| `needs_context` | `NewExpression` | `true` — transform must emit context-aware instantiation |

### `Binding` mutations

| Mutation | Written by | Rationale |
|---|---|---|
| `binding.reassigned = true` | `ExportSpecifier` (instance + runes) | Exports are externally mutable; conservative reactivity treatment |

---

## 6. Data flow into later phases

```mermaid
flowchart LR
    subgraph JSV["compiler_analyzer_js_visitors"]
        EXPV["ExportDefaultDeclaration<br/>ExportNamedDeclaration<br/>ExportSpecifier"]
        NEV["NewExpression"]
        TTEV["TaggedTemplateExpression"]
    end

    EXPV -->|"exports.push({name, alias})"| A1["analysis.exports"]
    EXPV -->|"throw on invalid export"| ERR["CompileError<br/>(compiler_diagnostics)"]
    EXPV -->|"reassigned = true"| A2["Binding<br/>(compiler_analyzer_scope)"]
    NEV -->|"needs_context = true"| A3["analysis.needs_context"]
    TTEV -->|"has_state / has_call = true"| A4["ExpressionMetadata<br/>(state.expression)"]

    A1 -->|"instance accessors /<br/>module export codegen"| T3["Phase 3 transforms<br/>(client · server)"]
    A3 -->|"context-aware<br/>instantiation"| T3
    A2 -->|"conservative<br/>reactivity guards"| T3
    A4 -->|"update granularity /<br/>memoization"| TPL["template visitors +<br/>transform expression handling"]
```

- `analysis.exports` is consumed by the client and server transform visitors (e.g. their `ExportNamedDeclaration` visitors) to generate export/accessor plumbing for compiled components and `compileModule` output.
- `analysis.needs_context` controls whether the generated component instance requires a context argument.
- `binding.reassigned` influences binding-kind classification and reactivity checks performed throughout the analyzer and transforms.
- `ExpressionMetadata.has_state`/`has_call` determine which template expressions need reactive updates versus being rendered once.

---

## 7. Diagnostics reference

| Code | Kind | Emitted by | Condition | Message (excerpt) |
|---|---|---|---|---|
| `module_illegal_default_export` | error | `ExportDefaultDeclaration`, `ExportNamedDeclaration` | Default export in a component; `as default` specifier in a `.svelte.js` module | "A component cannot have a default export" |
| `legacy_export_invalid` | error | `ExportNamedDeclaration` | `export let` in the instance script under runes mode | "Cannot use `export let` in runes mode — use `$props()` instead" |
| `derived_invalid_export` | error | `ExportNamedDeclaration`, `ExportSpecifier` (via `validate_export`) | Exporting a `$derived` binding | "Cannot export derived state from a module…" |
| `state_invalid_export` | error | `ExportNamedDeclaration`, `ExportSpecifier` (via `validate_export`) | Exporting reassigned `$state` / `$state.raw` | "Cannot export state from a module if it is reassigned…" |
| `perf_avoid_inline_class` | warning | `NewExpression` | `new class { … }` at `function_depth > 0` | "Avoid 'new class' — declare the class at top level scope" |
| `bidirectional_control_characters` | warning | `TemplateElement` | Bidi control characters in a template literal's cooked value | "A bidirectional control character was detected in your code…" |

All diagnostics originate from [compiler_diagnostics](compiler_diagnostics.md) (`errors.js` / `warnings.js`); error codes link to svelte.dev documentation pages.

---

## 8. Dependencies

**Internal (same repo):**

| Dependency | Provided by | Used for |
|---|---|---|
| `Context`, `AnalysisState` | analyzer type model (`phases/2-analyze/types.d.ts`) | Visitor signature and traversal state |
| `validate_export`, `is_pure` | `visitors/shared/utils.js` ([compiler_analyzer](compiler_analyzer.md)) | Shared export validation & purity analysis |
| `extract_identifiers` | `compiler/utils/ast.js` | Flattening destructured export declarations |
| `errors.js`, `warnings.js` | [compiler_diagnostics](compiler_diagnostics.md) | `e.*` errors, `w.*` warnings |
| `regex_bidirectional_control_characters` | `compiler/phases/patterns.js` | Trojan-Source detection |
| `Scope`, `Binding` | [compiler_analyzer_scope](compiler_analyzer_scope.md) | Binding lookup and mutation |
| `walk` (`zimmerframe`) | external (pinned dependency) | AST traversal with `context.next()` |

**Module relationships:**

- Parent orchestrator: [compiler_analyzer](compiler_analyzer.md) — owns the visitor table and the legacy-mode export handling.
- Sibling visitor groups: [compiler_analyzer_block_visitors](compiler_analyzer_block_visitors.md), [compiler_analyzer_template_visitors](compiler_analyzer_template_visitors.md).
- Upstream: [compiler_parser](compiler_parser.md) (ASTs), [compiler_core](compiler_core.md) (`compileModule` entry for `.svelte.js` files).
- Downstream: [compiler_client_transform](compiler_client_transform.md), [compiler_server_transform](compiler_server_transform.md) (consume `exports`, `needs_context`, expression metadata), [compiler_css_pipeline](compiler_css_pipeline.md) (shares the same `ComponentAnalysis`).

---

## 9. Design notes & edge cases

- **`ast_type === undefined` means `.svelte.js` module.** Component walks always set `ast_type`; only `compileModule` analysis leaves it unset. All three export visitors rely on this discriminator.
- **Traversal-order subtlety in `ExportNamedDeclaration`:** `context.next()` deliberately precedes the validation/recording logic so that specifier children (and thus recorded exports / `reassigned` flags) are already in place when the declaration itself inspects bindings. Do not reorder this.
- **Leaf visitors skip traversal:** `ExportSpecifier` and `TemplateElement` never call `context.next()` — they have no children worth visiting; errors thrown in non-leaf visitors also halt traversal before `context.next()`.
- **String-literal export names are supported** (`export { x as "default" }`), which is why both visitors normalise `Identifier` vs `Literal` exported names.
- **Runes vs legacy split:** export *recording* only happens in runes-mode instance scripts; in legacy mode, `analyze_component` converts exported `let`/`var` to bindable props before the walk (see [compiler_analyzer](compiler_analyzer.md)). The validation helpers, however, run in all modes.
- **Conservative purity:** `is_pure` treats any locally bound identifier as impure and special-cases `$effect.tracking`, so `TaggedTemplateExpression` errs on the side of marking expressions stateful/callful — correctness over granularity.
- **Extending the module:** to support a new ECMAScript node, add `packages/svelte/src/compiler/phases/2-analyze/visitors/<NodeType>.js` exporting a function named after the node type and register it in the analyzer's visitor table ([compiler_analyzer](compiler_analyzer.md)). Call `context.next()` unless the node is a leaf.
