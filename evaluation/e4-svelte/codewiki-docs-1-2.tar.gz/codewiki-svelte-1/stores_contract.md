# stores_contract

## 1. Introduction

`stores_contract` is the **type-level foundation of the Svelte store system**. It lives in a single file, `packages/svelte/src/store/public.d.ts`, and defines the *public type contract* — the set of TypeScript types and interfaces (`Readable<T>`, `Writable<T>`, and their supporting callback types) that every Svelte store must satisfy, and that every store consumer may rely on.

The module contains **no runtime logic**. Its sole purpose is to establish a stable, structural interface boundary that decouples:

- **Store implementations** (`writable`, `readable`, `derived`, `readonly`, `tweened`, …) from
- **Store consumers** (the compiled runtime's `$store` auto-subscriptions, the `fromStore`/`toStore` interop bridge, and end-user application code).

Because the contract is defined via plain interfaces (not classes), any object that structurally matches the shape — including third-party stores and RxJS observables — can participate in the Svelte store ecosystem.

> **Module position:** `Reactive_State_Primitives___Store_Interop → stores → stores_contract` (see [Reactive_State_Primitives___Store_Interop](Reactive_State_Primitives___Store_Interop.md)). Its siblings are the implementation module [stores_core](stores_core.md) and the bridges module [stores_interop](stores_interop.md).

---

## 2. Scope and Exports

The module exports exactly six type declarations plus a re-export:

| Export | Kind | Signature | Role |
| --- | --- | --- | --- |
| `Subscriber<T>` | type alias | `(value: T) => void` | Value-update callback handed to `subscribe` |
| `Unsubscriber` | type alias | `() => void` | Teardown handle returned by `subscribe` |
| `Updater<T>` | type alias | `(value: T) => T` | Transform callback handed to `Writable.update` |
| `StartStopNotifier<T>` | type alias | `(set, update) => void \| (() => void)` | Optional start/stop lifecycle hook for a store |
| `Readable<T>` | interface | `subscribe(this: void, run, invalidate?): Unsubscriber` | Read-only subscription surface |
| `Writable<T>` | interface | extends `Readable<T>` with `set(this: void, value)` and `update(this: void, updater)` | Read/write surface |
| `./index-client.js` | re-export | `export * from './index-client.js'` | Pulls the runtime store API ([stores_interop](stores_interop.md)) into the same public module surface |

The core component of this module is **`Writable<T>`** — the most complete expression of the contract, since it inherits `Readable<T>` and adds mutation.

---

## 3. Type Hierarchy

```mermaid
classDiagram
    direction LR

    class Subscriber~T~ {
        <<type alias>>
        (value : T) =% void
    }
    class Unsubscriber {
        <<type alias>>
        () =% void
    }
    class Updater~T~ {
        <<type alias>>
        (value : T) =% T
    }
    class StartStopNotifier~T~ {
        <<type alias>>
        (set, update) =% void or () =% void
    }

    class Readable~T~ {
        <<interface>>
        +subscribe(this_void, run_Subscriber~T~, invalidate_opt) Unsubscriber
    }
    class Writable~T~ {
        <<interface>>
        +set(this_void, value_T) void
        +update(this_void, updater_Updater~T~) void
    }

    Writable --|> Readable : extends
    Readable ..> Subscriber : consumes
    Readable ..> Unsubscriber : returns
    Writable ..> Updater : consumes
    StartStopNotifier ..> Updater : receives update()
```

Key observations:

- **`Readable<T>` is the minimal contract.** Anything with a `subscribe` method is a store. This is what `derived` accepts as input and what [stores_interop](stores_interop.md) `fromStore` treats as read-only.
- **`Writable<T> extends Readable<T>.** Presence of `set`/`update` is the *only* structural difference — this is exactly the duck-typing check (`'set' in store`) used by `fromStore` to decide whether to expose a writable `current` property.
- **`StartStopNotifier<T>` is a factory-side contract**, not a consumer-side one. It is the second argument of `writable(value, start)` / `readable(value, start)` in [stores_core](stores_core.md). It receives the store's own `set`/`update` and may return a cleanup function that runs when the *last* subscriber unsubscribes.

---

## 4. Architecture and Component Relationships

The contract sits at the center of the store subsystem: implementations are produced *below* it, consumers *above* it.

```mermaid
graph TB
    subgraph CONTRACT["stores_contract — packages/svelte/src/store/public.d.ts"]
        T1["Readable&lt;T&gt;"]
        T2["Writable&lt;T&gt;"]
        T3["Subscriber / Unsubscriber /<br/>Updater / StartStopNotifier"]
    end

    subgraph CORE["stores_core — shared/index.js, utils.js"]
        W["writable(value, start)"]
        R["readable(value, start)"]
        D["derived(stores, fn)"]
        STS["subscribe_to_store(store, run, invalidate)"]
    end

    subgraph INTEROP["stores_interop — index-client.js / index-server.js"]
        FS["fromStore(store)"]
        TS["toStore(get, set)"]
    end

    subgraph RUNTIME["client_runtime_core_stores — internal/client/reactivity/store.js"]
        SG["store_get / store_mutate<br/>(compiled $store syntax)"]
        SS["setup_stores<br/>(per-instance subscription registry)"]
    end

    subgraph MOTION["motion — tweened"]
        TW["tweened(value, defaults)"]
    end

    W -- "implements Writable&lt;T&gt;" --> T2
    R -- "implements Readable&lt;T&gt;" --> T1
    D -- "returns Readable&lt;T&gt;<br/>built on contract inputs" --> T1
    TW -- "implements Writable&lt;T&gt;" --> T2
    TS -- "produces contract-shaped object" --> T2

    STS -- "consumes Readable&lt;T&gt;<br/>(+ private invalidate arg)" --> T1
    SG -- "consumes via subscribe_to_store" --> STS
    SS -- "owns Unsubscriber handles" --> T3
    FS -- "duck-types via 'set' in store" --> T2

    style CONTRACT fill:#e8f0fe,stroke:#4285f4,stroke-width:2px
    style CORE fill:#e6f4ea,stroke:#34a853
    style INTEROP fill:#fef7e0,stroke:#f9ab00
    style RUNTIME fill:#fce8e6,stroke:#ea4335
    style MOTION fill:#f3e8fd,stroke:#a142f4
```

### Dependency summary

| Consumer | File | How the contract is used |
| --- | --- | --- |
| `writable` | `store/shared/index.js` | Returns `{ set, update, subscribe }` — a `Writable<T>` |
| `readable` / `derived` / `readonly` | `store/shared/index.js` | Return `{ subscribe }` — a `Readable<T>` |
| `subscribe_to_store` | `store/utils.js` | Generic `Readable<T>` consumer; normalizes stores *and* RxJS observables |
| `fromStore` / `toStore` | `store/index-client.js`, `store/index-server.js` | Bridge between the store contract and the signals runtime (see [stores_interop](stores_interop.md)) |
| `store_get`, `store_mutate`, `setup_stores` | `internal/client/reactivity/store.js` | Runtime implementation of `$store` auto-subscriptions (see [client_runtime_core_stores](client_runtime_core_stores.md)) |
| `tweened` | `motion/tweened.js` | Store-conformant animated value (see [motion](motion.md)) |

---

## 5. Contract Semantics

The type declarations encode behavioral guarantees that all implementations must honor:

1. **Synchronous initial emission.** `subscribe(run, ...)` must invoke `run(currentValue)` synchronously, before returning the `Unsubscriber`. This is why consumers (e.g. `store_get`) can read a valid value immediately after subscribing.
2. **Synchronous update propagation.** `set()` / `update()` must notify all current subscribers synchronously with the new value.
3. **One `Unsubscriber` per subscription.** The function returned by `subscribe` removes exactly one subscription and may safely trigger the `StartStopNotifier` cleanup when it removes the *last* one.
4. **`this: void` methods.** All contract methods declare `this: void`. This guarantees the methods do not depend on `this`, so they remain valid when destructured (`const { subscribe } = store`) and that a plain object literal can satisfy the interface — the foundation of the ecosystem's structural typing.
5. **Optional `invalidate` callback.** `Readable.subscribe` accepts an optional second argument. It is effectively a *private extension* of the public contract: `subscribe_to_store` forwards it with `@ts-expect-error`, and `derived` uses it to track "pending" upstream invalidations while a derived value is being recomputed. User-facing stores are not required to use it.
6. **Start/stop lifecycle.** If a store was created with a `StartStopNotifier`, it runs exactly when the first subscriber arrives (receiving `set`/`update` as push channels), and its optional cleanup return value runs when the last subscriber leaves. Between those events the store is "hot"; outside them it is dormant.

---

## 6. Data Flow

### 6.1 Subscription lifecycle

```mermaid
sequenceDiagram
    autonumber
    participant C as Consumer
    participant Store as Store (Writable~T~)
    participant N as StartStopNotifier
    participant S as Subscriber~T~

    C->>Store: subscribe(run, invalidate?)
    Store->>Store: register [run, invalidate] tuple
    alt first subscriber (store cold)
        Store->>N: start(set, update)
        N-->>Store: void | cleanup fn
    end
    Store->>S: run(currentValue) — synchronous initial emission
    Store-->>C: Unsubscriber

    Note over Store,S: store is now "hot"

    Store->>S: run(newValue) on every accepted set()
    Store->>S: invalidate() before re-run (derived tracking)

    C->>Store: call Unsubscriber
    Store->>Store: remove tuple
    alt last subscriber
        Store->>N: cleanup()
        Note over Store: store becomes cold
    end
end
```

### 6.2 Write path (`set` semantics as implemented by [stores_core](stores_core.md))

```mermaid
flowchart LR
    A["set(new_value)"] --> B{"safe_not_equal?<br/>(primitives: !==,<br/>objects: reference)"}
    B -- "no" --> Z["no-op — no notification"]
    B -- "yes" --> C["value = new_value"]
    C --> D{"store hot?<br/>(stop != null)"}
    D -- "no (no subscribers)" --> Z
    D -- "yes" --> E["invalidate all subscribers<br/>push [subscriber, value] to<br/>shared subscriber_queue"]
    E --> F{"queue was empty?<br/>(start of drain)"}
    F -- "yes" --> G["drain queue: run each<br/>subscriber with new value"]
    F -- "no (nested set)" --> H["defer to outer drain"]
    G --> Z
```

The single shared `subscriber_queue` is an implementation detail of `writable` that guarantees **batched, loop-free notification**: a `set` performed *while* the queue is draining only enqueues work and never restarts the drain, which keeps update ordering deterministic even for chains of derived stores. Consumers of the contract only observe its externally visible effect: synchronous notification.

---

## 7. Structural Interop

Because the contract is purely structural, `subscribe_to_store` (the canonical consumer-side entry point, used by `derived`, `store_get`, and the compiler-generated binding code) deliberately accepts looser shapes:

```mermaid
flowchart TD
    A["subscribe_to_store(store, run, invalidate)"] --> B{"store == null?"}
    B -- "yes" --> C["run(undefined); invalidate?<br/>return noop"]
    B -- "no" --> D["untrack(() => store.subscribe(run, invalidate?))"]
    D --> E{"result has .unsubscribe?"}
    E -- "yes (RxJS Observable)" --> F["wrap: () => unsub.unsubscribe()"]
    E -- "no (Svelte store)" --> G["return Unsubscriber as-is"]
```

This is what allows third-party observable libraries to be used wherever a `Readable<T>` is expected. Note again the `@ts-expect-error` on the `invalidate` argument — the private second parameter is intentionally *not* part of the advertised public API, even though the internal pipeline uses it.

On the write side, [stores_interop](stores_interop.md)'s `fromStore` performs the mirror-image check: `'set' in store` distinguishes `Writable<T>` from `Readable<T>` at runtime, choosing a get/set reactive property versus a get-only one.

---

## 8. Where This Module Fits in the System

```mermaid
flowchart TB
    USER["User code / libraries"] -->|"import { writable, fromStore, ... }"| PUB["Public API surface<br/>(public_api)"]
    COMP["Svelte compiler output<br/>($store auto-subscription code)"] -->|"store_get / store_mutate"| RTSUB["subscribe_to_store"]
    PUB --> STI["stores_interop<br/>(fromStore / toStore)"]
    PUB --> STC["stores_core<br/>(writable / readable / derived / get / update)"]
    STC --> CONTRACT["stores_contract (this module)"]
    STI --> CONTRACT
    RTSUB --> CONTRACT
    STC -->|"derived subscribes to<br/>Readable inputs"| RTSUB
    MOTION["motion (tweened)"] --> CONTRACT
    SIGNALS["client_runtime_core<br/>(signals engine)"] <-->|"subscribe()"| STI

    style CONTRACT fill:#e8f0fe,stroke:#4285f4,stroke-width:2px
```

In prose:

- **Upstream (producers):** [stores_core](stores_core.md) factories, [motion](motion.md)'s `tweened`, and [stores_interop](stores_interop.md)'s `toStore` all *produce* contract-conformant objects. They are the reason this file exists — without the shared interface they could not be substituted for one another.
- **Downstream (consumers):** the store-subscription machinery of the reactive runtime ([client_runtime_core_stores](client_runtime_core_stores.md)) consumes the contract on behalf of compiled `$store` expressions, and [stores_interop](stores_interop.md) consumes it to bridge stores into the signals engine used by runes components.
- **Peer systems:** the reactive built-in classes ([reactive_builtin_classes](reactive_builtin_classes.md)) and the runes `$state`/`$derived` primitives are *alternatives* to stores, connected to them by the `fromStore`/`toStore` adapters — the contract makes those adapters possible with zero coupling.

---

## 9. Usage Examples

### 9.1 Implementing the contract (consumer side)

```ts
import type { Readable, Writable, StartStopNotifier } from 'svelte/store';

// Read-only store backed by an external event source
function ticker(): Readable<number> {
	const start: StartStopNotifier<number> = (set) => {
		const id = setInterval(() => set(Date.now()), 1000);
		return () => clearInterval(id); // runs when last subscriber leaves
	};
	return { subscribe: /* from writable */ undefined as any, /* ... */ } as Readable<number>;
}

// Minimal hand-rolled Writable
function myWritable<T>(value: T): Writable<T> {
	const subs = new Set<(v: T) => void>();
	return {
		subscribe(run) {
			subs.add(run);
			run(value); // contract: synchronous initial emission
			return () => subs.delete(run);
		},
		set(v) {
			value = v;
			subs.forEach((run) => run(v)); // contract: synchronous propagation
		},
		update(fn) {
			this.set(fn(value));
		}
	};
}
```

In practice you should use the ready-made factories from [stores_core](stores_core.md) (`writable`, `readable`, `derived`, `readonly`) rather than hand-rolling.

### 9.2 Consuming the contract

```ts
import { get, fromStore } from 'svelte/store';

function countSubscribers(store: Readable<number>) {
	let unsub = store.subscribe(() => {}); // Readable is enough
	unsub();
	return get(store); // one-shot read, also contract-typed
}

// In a runes component, fromStore detects Writable vs Readable
// structurally ('set' in store) — see stores_interop.
const counter = fromStore(myWritable(0));
counter.current = 42; // allowed because myWritable satisfies Writable<number>
```

---

## 10. Design Notes and Rationale

- **Why interfaces and not a base class?** Stores must be creatable from plain object literals (Svelte's original 3.x design goal) and must remain tree-shakeable: the contract costs nothing at runtime. The build tooling (`check-treeshakeability`) depends on type-only modules like this one emitting no code.
- **Why `this: void`?** It is the TypeScript idiom for "this method may be detached from its object". It makes `{ subscribe } = store` legal and prevents implementations from sneaking in `this`-dependent behavior that would break structural substitutability.
- **Why a separate `Readable` at all?** Read-only store propagation (`derived`, `readonly`, server-rendered data) is the common case; splitting the contract lets the compiler and runtime optimize read-only paths and lets `fromStore` reject writes at the type level *and* at runtime.
- **Why is `StartStopNotifier` part of the public contract?** It documents the lazy-subscription protocol that custom stores (including user-defined ones) must implement for resources to be acquired/released correctly — e.g. `tweened`'s animation loop in [motion](motion.md) and `derived`'s upstream subscriptions in [stores_core](stores_core.md).
- **The private `invalidate` parameter** is a deliberate asymmetry: it is in the public signature for backwards compatibility (legacy components' reactive statements relied on it) but is treated as internal by all modern consumers, which call `subscribe` with `@ts-expect-error` through `subscribe_to_store`.

---

## 11. Related Documentation

| Module | Relationship |
| --- | --- |
| [stores_core](stores_core.md) | Reference implementations (`writable`, `readable`, `derived`, `readonly`, `get`, `update`) of this contract |
| [stores_interop](stores_interop.md) | `fromStore`/`toStore` adapters between this contract and the signals runtime |
| [client_runtime_core_stores](client_runtime_core_stores.md) | Runtime consumption of the contract for compiled `$store` syntax |
| [motion](motion.md) | `tweened` — an animated `Writable<T>` implementation |
| [Reactive_State_Primitives___Store_Interop](Reactive_State_Primitives___Store_Interop.md) | Parent module: the broader store + reactive-primitive landscape |
