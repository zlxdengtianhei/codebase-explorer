# client_runtime_core_props

> **Module**: `packages/svelte/src/internal/client/reactivity/props.js`
> **Subsystem**: Reactive Runtime Engine (Signals, Effects & Batching) → [client_runtime_core](client_runtime_core.md)
> **Category**: Client-side (browser) runtime — not used for SSR

---

## 1. Introduction

`client_runtime_core_props` implements the **reactive prop plumbing** of Svelte's client runtime. When the compiler generates code for a component, it does not deal with "props" as a first-class language concept — it calls the functions in this module to:

- **Read props** with fallback and binding semantics (`prop`),
- **Destructure rest props** (`const { a, ...rest } = $props()`) via a read-mostly proxy (`rest_props`),
- **Merge spread attributes** (`<Child {...a} {...b} />`) into a single virtual `$$props` object (`spread_props`),
- **Replicate legacy Svelte 4 behaviour** for `$$props` / `$$restProps` (`legacy_rest_props`),
- **Apply increment/decrement operators to props** (`foo++`, `--bar`) (`update_prop`, `update_pre_prop`).

Every "prop" in a compiled Svelte 5 component is ultimately an **overloaded accessor function** produced here: calling it with no arguments *reads* the prop (registering a reactive dependency), calling it with a value *writes* it (propagating back to the parent binding when the prop is bindable), and calling it with `(value, true)` signals a *mutation* (e.g. `obj.x = 1` on a bindable object prop).

This module sits on top of the signal primitives provided by its sibling submodules — [client_runtime_core_sources](client_runtime_core_sources.md) (`source`/`set`/`update`), [client_runtime_core_deriveds](client_runtime_core_deriveds.md) (`derived`/`derived_safe_equal`), [client_runtime_core_proxies](client_runtime_core_proxies.md) (`proxy`), [client_runtime_core_stores](client_runtime_core_stores.md) (`capture_store_binding`) and [client_runtime_core_runtime](client_runtime_core_runtime.md) (`get`, `untrack`, `active_effect`).

---

## 2. Position in the System Architecture

The compiler's client transform ([compiler_client_transform](compiler_client_transform.md)) emits calls into this module from the `Component` and `BindDirective` visitors, and from `RegularElement`/`Component` visitors for spread attributes. The DOM renderer ([client_dom_renderer](client_dom_renderer.md)) consumes the accessors produced here for element bindings (`bind_prop`). The server has an independent, stateless mirror of this API in [server_runtime](server_runtime.md) (`rest_props`, `spread_props`, `bind_props` in `src/internal/server/index.js`); the two never mix — props.js is purely the client/reactivity half.

```mermaid
flowchart TB
    subgraph Compiler["Compiler — Client Transform (compiler_client_transform)"]
        CV["Component.js visitor"]
        BD["BindDirective.js visitor"]
        RE["RegularElement.js visitor<br/>(spread attributes)"]
    end

    subgraph Core["client_runtime_core — Reactive Runtime"]
        PROPS["props.js<br/>(this module)"]
        SRC["sources.js"]
        DRV["deriveds.js"]
        RT["runtime.js"]
        PXY["proxy.js"]
        STO["store.js"]
        ERR["errors.js / validate.js"]
    end

    subgraph Render["Rendering Backends"]
        DOM["client_dom_renderer<br/>(element bindings, bind_prop)"]
        SSR["server_runtime<br/>(stateless SSR mirror of props API)"]
    end

    CV -- "prop(), rest_props(), spread_props()" --> PROPS
    BD -- "prop()" --> PROPS
    RE -- "spread_props()" --> PROPS
    DOM -- "reads prop accessors" --> PROPS

    PROPS --> SRC
    PROPS --> DRV
    PROPS --> RT
    PROPS --> PXY
    PROPS --> STO
    PROPS --> ERR
```

### Dependency graph of `props.js`

```mermaid
flowchart LR
    subgraph props["props.js"]
        PROP["prop"]
        REST["rest_props"]
        SPREAD["spread_props"]
        LREST["legacy_rest_props"]
        UPD["update_prop / update_pre_prop"]
    end

    SRC["sources.js:<br/>source, set, update"]
    DRV["deriveds.js:<br/>derived, derived_safe_equal"]
    RT["runtime.js:<br/>get, untrack, active_effect,<br/>is_destroying_effect, set_active_effect"]
    PXY["proxy.js:<br/>proxy"]
    STO["store.js:<br/>capture_store_binding"]
    CONST["constants.js:<br/>PROPS_IS_* flags"]
    FLAGS["flags/index.js:<br/>legacy_mode_flag"]
    UTIL["shared/utils.js:<br/>get_descriptor, is_function"]
    E["errors.js:<br/>props_rest_readonly, props_invalid_value"]
    C["#client/constants:<br/>DESTROYED, LEGACY_PROPS, STATE_SYMBOL"]

    PROP --> SRC
    PROP --> DRV
    PROP --> RT
    PROP --> PXY
    PROP --> STO
    PROP --> CONST
    PROP --> FLAGS
    PROP --> UTIL
    PROP --> E
    PROP --> C

    LREST --> SRC
    LREST --> RT
    LREST --> PROP
    LREST --> E

    REST --> E
    REST --> CONST
    SPREAD --> UTIL
    UPD --> RT
```

---

## 3. Public API Reference

### 3.1 `prop(props, key, flags, fallback)` — the prop accessor factory

The most important function in the module. Returns an **overloaded accessor**:

| Call form | Meaning |
|---|---|
| `accessor()` | Read current prop value (registers a reactive dependency). |
| `accessor(value)` | Write `value` through to the parent binding or to a local derived. |
| `accessor(value, true)` | *Mutation-style* write (the value already in the child changed internally, e.g. `prop.x = 1`); the parent is only notified when it cannot detect the change itself. |

`flags` is a bitmask emitted by the compiler:

| Flag | Value | Meaning |
|---|---|---|
| `PROPS_IS_IMMUTABLE` | `1` | Values are treated as immutable → use `derived` instead of `derived_safe_equal` (skip equality checks). |
| `PROPS_IS_RUNES` | `2` | The component compiles under runes mode even if the runtime global is in legacy mode. |
| `PROPS_IS_UPDATED` | `4` | The component **writes** to the prop → a writable accessor is required. |
| `PROPS_IS_BINDABLE` | `8` | The prop participates in `bind:` → writes must propagate to the parent. |
| `PROPS_IS_LAZY_INITIAL` | `16` | The fallback is a thunk; evaluate it lazily and untracked on first read. |

Internally, `prop` follows a decision ladder (see §4.1):

1. **Decode flags** — `runes`, `bindable`, `lazy`.
2. **Resolve a setter** (bindable only): prefer the parent's own accessor descriptor (`get_descriptor(props, key).set`). For *entry props* (created by `mount(Component, props)` with `$state` or `createClassComponent`), detected via the `STATE_SYMBOL` / `LEGACY_PROPS` markers, it falls back to direct assignment `(v) => (props[key] = v)`.
3. **Capture the initial value**; for bindable props this runs through `capture_store_binding` so that a prop whose initial read resolves through a store subscription (`is_store_sub`) is later notified on mutation too.
4. **Fallback handling** — `get_fallback()` caches the fallback; with `PROPS_IS_LAZY_INITIAL` it is evaluated `untrack`ed. If the initial value is `undefined` and a fallback exists:
   - runes mode with a setter → throws `props_invalid_value` (you cannot `bind:x={undefined}` when `x` has a fallback);
   - legacy mode → writes the fallback back to the parent via the setter.
5. **Build the getter**:
   - *runes*: `props[key]`, falling back to `get_fallback()`; a later defined value resets the fallback cache.
   - *legacy*: once the prop has ever been defined, the fallback is permanently discarded — replicating Svelte 4 semantics where a prop going defined → undefined does **not** revert to the default.
6. **Choose the access strategy**:
   - read-only runes prop (`PROPS_IS_UPDATED` unset) → return the bare getter (no write machinery is even allocated);
   - bindable with a parent setter → return a pass-through accessor that calls the setter, with mutation-notification heuristics (notify unless runes-mode parent will detect the mutation itself; always notify for store-backed or legacy parents);
   - otherwise → create a local **derived** (`derived_safe_equal`, or `derived` when `PROPS_IS_IMMUTABLE`) over the getter, labelled with the key in DEV, and return an accessor that `set`s the derived. During teardown (`is_destroying_effect && overridden`, or the parent effect is `DESTROYED`) reads return the cached `d.v` without recomputation — this keeps `bind:this` working after the component is destroyed.

```mermaid
flowchart TD
    A["prop(props, key, flags, fallback)"] --> B["decode flags:<br/>runes, bindable, lazy"]
    B --> C{"bindable?"}
    C -- "yes" --> D["resolve setter:<br/>parent descriptor .set,<br/>or entry-props direct assign"]
    C -- "no" --> E["setter = undefined"]
    D --> F["capture initial value<br/>(capture_store_binding if bindable)"]
    E --> F
    F --> G{"initial undefined<br/>and fallback present?"}
    G -- "yes" --> H["initialise from fallback"]
    H --> I{"runes + setter?"}
    I -- "yes" --> J["throw props_invalid_value<br/>(bind:x=undefined)"]
    I -- "no" --> K["continue"]
    G -- "no" --> K
    K --> L{"runes and<br/>PROPS_IS_UPDATED unset?"}
    L -- "yes" --> M["return getter only<br/>(read-only prop)"]
    L -- "no" --> N{"setter available?"}
    N -- "yes" --> O["return pass-through accessor<br/>writing via setter<br/>(mutation-aware notify)"]
    N -- "no" --> P["create local derived<br/>derived / derived_safe_equal<br/>labelled key in DEV"]
    P --> Q["if bindable: get(d) once<br/>to propagate initial value"]
    Q --> R["return accessor<br/>set(d, ...) / get(d)<br/>with teardown fast-path"]
```

### 3.2 `rest_props(props, exclude, name)` — rest destructuring proxy

Backs `const { a, ...rest } = $props()`. Returns a `Proxy` over `{ props, exclude }` (plus DEV-only bookkeeping fields `name`, `other`, `to_proxy`), handled by `rest_props_handler`:

| Trap | Behaviour |
|---|---|
| `get` | Excluded keys read as `undefined`; otherwise forwards to `props[key]` (so reactivity of the underlying `$props()` proxy is preserved). |
| `set` | **Throws `props_rest_readonly`** in DEV — rest objects are read-only. (Production silently rejects.) |
| `getOwnPropertyDescriptor` | Hides excluded keys; synthesises an enumerable/configurable descriptor for real keys. |
| `has` / `ownKeys` | Filtered by the exclude list, keeping `for…in`, `in` and spread semantics consistent. |

The factory is annotated `/*#__NO_SIDE_EFFECTS__*/` so bundlers can drop unused calls at build time.

### 3.3 `spread_props(...props)` — spread-attribute merge proxy

Backs `<Child {...a} {...b} />`. Takes a heterogeneous list of plain objects and **getter thunks** (`() => props`) and exposes them as one virtual `$$props` object:

```mermaid
flowchart TD
    A["Child with spreads:<br/>spread_props(objA, () => stateB, objC)"] --> B["Proxy over props array"]
    B -- "get k" --> C["scan array last-to-first,<br/>unwrapping getter thunks"]
    C --> D["first owner of k wins<br/>(later spreads shadow earlier)"]
    B -- "set k" --> E["scan last-to-first for the first<br/>property descriptor with .set"]
    E --> F["delegate the write to that owner"]
    B -- "has / ownKeys" --> G["union across all sources,<br/>nullish sources skipped,<br/>string keys + symbols, order preserved"]
    B -- "has STATE_SYMBOL / LEGACY_PROPS" --> H["always false<br/>(prevents false is_entry_props<br/>detection inside prop())"]
```

Notable implementation details:

- **Getter thunks are re-evaluated per access** so that inline spread expressions (`{...object_with_getters}`) stay live.
- `getOwnPropertyDescriptor` **forces `configurable: true`** on returned descriptors. Because the proxy target (an array) never actually contained the key, exposing a non-configurable descriptor would trigger the "proxy invariant" TypeError ('Non-configurability Report Error'). Forcing configurability is safe here since Svelte controls all access.
- `set` walks backwards and only writes to the **first source with a setter** — typically a `$state` proxy or a bindable prop accessor — so updates land in exactly one authoritative location.

### 3.4 `legacy_rest_props(props, exclude)` — `$$props` / `$$restProps` proxy

Replicates Svelte 4's coarse-grained prop objects, which were writable and could even have keys deleted:

```mermaid
flowchart TD
    A["legacy_rest_props(props, exclude)"] --> B["Proxy target:<br/>props, exclude, special map,<br/>version = source(0), parent_effect"]
    B -- "get k" --> C["get(version)<br/>(track coarse dependency)"]
    C --> D{"k in special?"}
    D -- "yes" --> E["special[k]()<br/>(locally-created writable prop)"]
    D -- "no" --> F["props[k]"]
    B -- "set k, v" --> G{"k in special?"}
    G -- "no" --> H["create prop(..., PROPS_IS_UPDATED)<br/>under parent_effect<br/>(handles temporary parent/child desync)"]
    H --> I["special[k] = prop"]
    G -- "yes" --> I
    I --> J["special[k](v)<br/>then update(version)"]
    J --> K["all reads of ANY key re-run<br/>($$props is coarse-grained)"]
    B -- "deleteProperty k" --> L["push k into exclude<br/>+ update(version)<br/>(Svelte 4 allowed deletions)"]
```

Key points:

- A single `version` **source signal** models the whole object: any write (or delete) bumps it, so `$$props.foo` and `$$props.bar` reads all invalidate together — exactly the Svelte 4 behaviour.
- Writes to unseen keys lazily create a real writable `prop(..., PROPS_IS_UPDATED)` **under the component's `parent_effect`** (saved at creation time and temporarily restored via `set_active_effect`). This is necessary because `bind:this` can cause writes after the writing effect has moved on, and because props can be temporarily out of sync with the parent.
- The `parent_effect` reference is also what lets `prop` detect a destroyed component when reading props in teardown code.

### 3.5 `update_prop(fn, d)` / `update_pre_prop(fn, d)` — operator support

Thin helpers the compiler emits for `++` / `--` on props, where `fn` is the accessor returned by `prop`:

```javascript
update_prop(fn, d)      // postfix:  const value = fn(); fn(value + d); return value;
update_pre_prop(fn, d)  // prefix:   const value = fn() + d; fn(value); return value;
```

| Compiler pattern | Generated call | Returned value |
|---|---|---|
| `foo++` (prop) | `update_prop(() => foo, (v) => (foo = v))` style | old value |
| `++foo` (prop) | `update_pre_prop(...)` | new value |
| `foo--` / `--foo` | same helpers with `d = -1` | old / new value |

Both delegate to the prop accessor, so all binding/fallback/legacy semantics of `prop` apply automatically.

---

## 4. Behavioural Flows

### 4.1 Bound-prop write-back (bindable prop with parent setter)

```mermaid
sequenceDiagram
    participant Ch as Child component code
    participant PA as prop() accessor
    participant ST as Parent setter (descriptor)
    participant PP as Parent $state proxy
    participant FX as Parent effects (batching)

    Ch->>PA: accessor(newValue)
    alt direct setter available
        PA->>ST: setter(newValue)
        ST->>PP: props[key] = newValue
        PP->>FX: schedule signals / batch flush
        Note over FX: parent re-renders bound binding
    else no setter (unbound, writable prop)
        PA->>PA: set(local derived, newValue)
        Note over PA: override is child-local;<br/>fallback_value updated if set
    end
    PA-->>Ch: value (echoed back)
```

### 4.2 Mutation-style updates (`obj.prop = x` through a bindable object)

When the compiled code mutates a **bindable object prop** in place, it calls the accessor with `(value, /* mutation */ true)`:

- **runes-mode parent**: the notification is *skipped* — the parent's `$state` proxy ([client_runtime_core_proxies](client_runtime_core_proxies.md)) already detected the deep mutation and will invalidate dependents.
- **legacy parent / store-backed prop** (`$$legacy` marker, or `is_store_sub` from `capture_store_binding`): the notification **is sent** (`setter(getter())`), because those parents cannot detect the change themselves.

This heuristic avoids double-invalidation while preserving correctness across compilation modes.

### 4.3 Rest/spread read path

```mermaid
flowchart LR
    subgraph Parent
        P1["props object<br/>(often a proxy)"]
    end
    subgraph Child
        R["rest_props(props, ['a','b'])"]
        S["spread_props(a, () => b)"]
    end
    P1 --> R -->|"get 'c'"| P1
    R -->|"get 'a' (excluded)"| U["undefined"]
    S -->|"get 'k': scan last-to-first"| P1
    S -->|"set 'k': first .set owner"| P1
```

---

## 5. Interaction with the Reactive Core

`props.js` composes the primitive signal layers; it never schedules effects or flushes batches itself:

| Core layer (module) | What props.js uses it for |
|---|---|
| [client_runtime_core_sources](client_runtime_core_sources.md) | `source(0)` for the legacy version counter; `set` to write the local derived; `update` to bump version / implement operators. |
| [client_runtime_core_deriveds](client_runtime_core_deriveds.md) | `derived` / `derived_safe_equal` create the *local override* signal for writable, unbound props; `PROPS_IS_IMMUTABLE` selects the non-equality-checking variant. |
| [client_runtime_core_runtime](client_runtime_core_runtime.md) | `get` to read signals and register dependencies; `untrack` for lazy fallbacks; `active_effect` / `set_active_effect` to anchor lazily-created legacy props to the owning component effect; `is_destroying_effect` for the teardown fast-path. |
| [client_runtime_core_proxies](client_runtime_core_proxies.md) | `proxy(value)` wraps incoming object values of bindable props so child mutations remain tracked in the parent. |
| [client_runtime_core_stores](client_runtime_core_stores.md) | `capture_store_binding` detects props whose initial value flows through a store subscription, changing mutation-notify behaviour. |
| [client_runtime_core_batching](client_runtime_core_batching.md) | Indirectly: all `set` calls participate in the standard batch/flush cycle — no special handling here. |
| [client_runtime_core_diagnostics](client_runtime_core_diagnostics.md) | Throws `props_rest_readonly` (DEV write to rest props) and `props_invalid_value` (`bind:x={undefined}` with a fallback). |

DEV-mode extras: the derived created for a writable prop is labelled with the prop key (`d.label = key`), which surfaces in `$inspect`, ownership-mismatch and tracing messages produced by [client_dev_mode](client_dev_mode.md).

---

## 6. Design Notes & Invariants

1. **Accessors, not signals.** Props are deliberately *not* exposed as signal objects. The accessor indirection lets one call site serve read, write and mutation forms, and lets the implementation switch strategies (getter-only / pass-through / local derived) without changing generated call sites.
2. **Fallback liveness (runes vs legacy).** In runes mode the fallback "re-arms" whenever the prop returns to `undefined` (so `mount`-style dynamic props can fall back repeatedly). In legacy mode the fallback is discarded the first time the prop is defined — faithful to Svelte 4, where a defined→undefined transition did not restore defaults.
3. **Entry-prop detection.** The `STATE_SYMBOL` / `LEGACY_PROPS` sentinels distinguish *entry* props objects (owned by `mount` / `createClassComponent`) from ordinary objects, which decides whether direct assignment is a valid setter. `spread_props` returns `false` for these sentinels in `has` so merged spreads are never misidentified as entry props.
4. **Proxy-invariant care.** Both rest and spread handlers synthesise descriptors instead of storing values on the target; `spread_props` must force `configurable: true` to satisfy the `getOwnPropertyDescriptor` invariant of `Proxy` (the array target genuinely lacks the key).
5. **Coarse vs fine invalidation.** `legacy_rest_props` intentionally uses one version source for the entire object (Svelte 4 semantics), whereas runes-mode code paths never read `$$props` as a whole and enjoy per-key granularity through the underlying props proxy.
6. **Teardown safety.** `bind:this` can read props from a destroy callback *after* effects are torn down. The `DESTROYED` / `is_destroying_effect` fast-paths return the last computed derived value without re-executing, avoiding updates during unmount.
7. **Tree-shaking.** `rest_props` is marked `/*#__NO_SIDE_EFFECTS__*/`; the read-only-prop fast path (bare getter) keeps generated code minimal for the common "parent passes value, child only reads" case.

---

## 7. Related Modules

- [client_runtime_core](client_runtime_core.md) — parent module; overall runtime architecture and signal lifecycle.
- [client_runtime_core_runtime](client_runtime_core_runtime.md) — `get`, `untrack`, effect-tree traversal, `tick`/`settled`.
- [client_runtime_core_sources](client_runtime_core_sources.md) / [client_runtime_core_deriveds](client_runtime_core_deriveds.md) / [client_runtime_core_signal_model](client_runtime_core_signal_model.md) — signal primitives consumed here.
- [client_runtime_core_proxies](client_runtime_core_proxies.md) — `$state` proxies used for bindable object props and referenced by the spread `set` path.
- [client_runtime_core_stores](client_runtime_core_stores.md) — store-binding capture and `mark_store_binding` interplay.
- [client_runtime_core_batching](client_runtime_core_batching.md) — batch scheduling that flushes prop-driven updates.
- [client_runtime_core_diagnostics](client_runtime_core_diagnostics.md) — `props_rest_readonly`, `props_invalid_value`, `validate_binding`.
- [client_dev_mode](client_dev_mode.md) — DEV labels, ownership validation, HMR wrappers around compiled components.
- [compiler_client_transform](compiler_client_transform.md) — the compiler phase that emits calls to `prop` / `rest_props` / `spread_props` / `update_prop` / `update_pre_prop` (see `Component`, `BindDirective`, `RegularElement` visitors).
- [client_dom_renderer](client_dom_renderer.md) — DOM bindings (`bind_prop`, `attribute_effect`) that consume prop accessors at the element level.
- [server_runtime](server_runtime.md) — the stateless SSR mirror (`rest_props`, `spread_props`, `bind_props`) used by [compiler_server_transform](compiler_server_transform.md).
