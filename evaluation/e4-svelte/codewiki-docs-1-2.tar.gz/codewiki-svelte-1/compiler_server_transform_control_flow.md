# compiler_server_transform_control_flow

## 1. Overview

`compiler_server_transform_control_flow` is the subset of the Svelte compiler's server (SSR) code
generator responsible for translating **template control-flow constructs** into plain JavaScript
that emits HTML strings at request time. It contains one visitor per construct:

| Visitor | Svelte syntax | Generated strategy |
| --- | --- | --- |
| `IfBlock` | `{#if}…{:else}…{/if}` | Native JS `if/else` statement, lazily evaluated per branch |
| `EachBlock` | `{#each expr as item, i}…{:else}…{/each}` | Hoisted array + native `for` loop, optional `{:else}` fallback |
| `AwaitBlock` | `{#await expr}…{:then v}…{:catch e}…{/await}` | Call to runtime helper `$.await(...)` with thunks/arrows |
| `KeyBlock` | `{#key expr}…{/key}` | Pass-through fragment wrapped in empty-comment anchors |
| `SvelteBoundary` | `<svelte:boundary>` | Hydration boundary markers + optional `pending` snippet render |
| `ConstTag` | `{@const x = expr}` | `const` declaration hoisted into the current block's `init` |
| `DebugTag` | `{@debug a, b}` | `console.log({...})` statement + `debugger` |

All visitors share the same output contract: they append **statements and string fragments** to
`context.state.template`, which the enclosing `Fragment` visitor later coalesces into
`$$payload.out.push(...)` calls (see
[compiler_server_transform_pipeline](compiler_server_transform_pipeline.md)).

The generated code is what actually runs on the server: a compiled Svelte 5 SSR component is
nothing more than a function `( $$payload, $$props ) => { ... }` that pushes strings into
`$$payload.out`, interleaved with **hydration marker comments** so the client can re-attach
behavior after page load.

> **Parent context:** This module is a child of
> [compiler_server_transform](compiler_server_transform.md), which in turn belongs to
> [Compiler_Back-End_(Client___Server_Code_Generation)](Compiler_Back-End_(Client___Server_Code_Generation).md).
> The client-side mirror of this module is
> [compiler_client_transform_control_flow_blocks](compiler_client_transform_control_flow_blocks.md) —
> same constructs, but generating DOM-creation/hydration code instead of strings.

---

## 2. Position in the compiler pipeline

The Svelte compiler runs three phases: **parse → analyze → transform** (see
[Compiler_Front-End_(Parsing,_Analysis___CSS_Scoping_Pipeline)](Compiler_Front-End_(Parsing,_Analysis___CSS_Scoping_Pipeline).md)).
By the time this module executes, the template AST has already been validated and annotated with
scope/binding metadata. This module is purely a *translation* step — it performs no further
validation, but it **consumes analysis metadata** (e.g. `EachBlock`'s `metadata.contains_group_binding`
and the analyzer's synthetic `metadata.index`) produced in phase 2.

```mermaid
flowchart LR
    A["Source<br/>.svelte file"] --> B["Phase 1: Parse<br/>(compiler_parser)"]
    B --> C["Phase 2: Analyze<br/>(compiler_analyzer_block_visitors)"]
    C --> D["Phase 3: Transform"]
    D --> D1["Client transform<br/>(compiler_client_transform_control_flow_blocks)"]
    D --> D2["Server transform<br/>(compiler_server_transform)"]
    D2 --> E["compiler_server_transform_<br/>control_flow (this module)"]
    E --> F["ESTree Program"]
    F --> G["esrap print → JS"]
    G --> H["Imported as<br/>svelte/internal/server component"]
    H --> I["Request time:<br/>component($$payload, $$props)<br/>pushes HTML strings"]
```

Entry point into this module is the visitor registry in
`packages/svelte/src/compiler/phases/3-transform/server/transform-server.js`, where
`IfBlock`, `EachBlock`, `AwaitBlock`, `KeyBlock`, `SvelteBoundary`, `ConstTag` and `DebugTag` are
registered in the `template_visitors` map and dispatched by `zimmerframe`'s `walk()` while it
traverses the template AST.

---

## 3. Architecture

### 3.1 Component relationships

```mermaid
flowchart TB
    subgraph Registry["transform-server.js (compiler_server_transform)"]
        W["walk(analysis.template.ast,<br/>state, visitors)"]
        TV["template_visitors map"]
    end

    subgraph Module["compiler_server_transform_control_flow"]
        IF["IfBlock"]
        EACH["EachBlock"]
        AWAIT["AwaitBlock"]
        KEY["KeyBlock"]
        BOUNDARY["SvelteBoundary"]
        CONST["ConstTag"]
        DEBUG["DebugTag"]
    end

    subgraph Pipeline["compiler_server_transform_pipeline"]
        FRAG["Fragment<br/>(assembles blocks)"]
        PC["process_children"]
        BT["build_template<br/>coalesces → payload.out.push"]
        BAV["build_attribute_value"]
    end

    subgraph Infra["compiler_core infrastructure"]
        B["builders.js (b.*)<br/>ESTree node factories"]
        SCOPE["scope.js / set_scope"]
    end

    subgraph Runtime["server_runtime (svelte/internal/server)"]
        HYD["hydration.js<br/>BLOCK_OPEN / BLOCK_OPEN_ELSE /<br/>BLOCK_CLOSE / EMPTY_COMMENT"]
        RT["$.await, $.ensure_array_like,<br/>$.escape, $.stringify"]
        PAY["Payload / abort-signal"]
    end

    W --> TV
    TV --> IF & EACH & AWAIT & KEY & BOUNDARY & CONST & DEBUG
    IF & EACH & AWAIT & KEY & BOUNDARY & CONST & DEBUG --> B
    IF & EACH & BOUNDARY --> HYD
    AWAIT & EACH --> RT
    IF & EACH & KEY & BOUNDARY & DEBUG --> FRAG
    BOUNDARY --> BAV
    FRAG --> PC --> BT
    CONST --> SCOPE
    RT --> PAY
```

### 3.2 The visitor contract

Each visitor has the signature:

```js
/**
 * @param {AST.IfBlock} node        // the typed AST node (see compiler_types/template.d.ts)
 * @param {ComponentContext} context // zimmerframe walking context
 */
export function IfBlock(node, context) { ... }
```

`ComponentContext` (defined in `3-transform/server/types.d.ts`) exposes:

- **`context.visit(child)`** — recursively transforms a child node and returns the resulting
  ESTree node. Visiting a `Fragment` child invokes the `Fragment` visitor, which returns a
  `BlockStatement` whose body is `[...init, ...build_template(template)]`.
- **`context.state`** — the shared `ComponentServerTransformState`. The fields this module uses:
  - `template: Array<Statement | Expression>` — ordered SSR output fragments for the current
    fragment scope. Control-flow visitors *append* here; statements (e.g. `b.if`, `b.for`) are
    emitted verbatim, expressions/literals are coalesced later by `build_template`.
  - `init: Statement[]` — declarations that must precede the template output in the emitted
    block (`ConstTag`, `EachBlock`'s array hoist).
  - `skip_hydration_boundaries`, `namespace`, `options`, `analysis` — read-only context.
- **`context.path`** — ancestor node chain (used by `Fragment` for namespace inference).

The state object is *copied per fragment* (`{ ...state }` in `Fragment`/`process_children`), but
the `init`/`template` **arrays are shared by reference**, so pushes from nested block visitors
land in the correct enclosing scope.

### 3.3 AST builders

All ESTree nodes are created with the `#compiler/builders` module
(`packages/svelte/src/compiler/utils/builders.js`, part of
[compiler_core](compiler_core.md)): `b.if` → `IfStatement`, `b.for` → `ForStatement`,
`b.block`, `b.const`, `b.let`, `b.stmt`, `b.call`, `b.literal`, `b.thunk` (a `() => ...` arrow),
`b.arrow`, `b.member`, `b.binary`, etc. Visitors never hand-roll node objects, which keeps output
shape consistent and AST locations clean.

### 3.4 Hydration marker contract

Markers come from `packages/svelte/src/internal/server/hydration.js` (shared with
[server_runtime](server_runtime.md)) and are consumed by the client hydrator in
[client_dom_renderer](client_dom_renderer.md):

| Constant | Literal | Purpose |
| --- | --- | --- |
| `BLOCK_OPEN` | `<!--[-->` | Opens an if/each/boundary branch region |
| `BLOCK_OPEN_ELSE` | `<!--[!-->` | Marks the *fallback* branch (`{:else}`, `{:catch}`, empty-each fallback) |
| `BLOCK_CLOSE` | `<!--]-->` | Closes a block region; anchor for hydration & anchor-element recovery |
| `EMPTY_COMMENT` | `<!---->` | Neutral anchor: separates adjacent text nodes / marks KeyBlock span |

**Invariant:** every `BLOCK_OPEN` emitted by a branch must be matched by exactly one
`BLOCK_CLOSE`; the else-variant only ever appears *inside* a branch body, never around it. The
client hydrator walks these markers to decide which branch's DOM nodes to claim.

---

## 4. Visitor reference

### 4.1 `IfBlock`

**Strategy — lazy native branch.** The test, consequent and alternate are visited *eagerly at
compile time* into `IfStatement` parts, but at *runtime* only the taken branch executes —
essential for correctness when expressions have side effects or access bindings not valid in the
other branch.

```js
{#if x > 1}
  <p>big</p>
{:else}
  <p>small</p>
{/if}
```

compiles to (conceptually):

```js
if (x > 1) {
  $$payload.out.push('<!--[-->');   // unshifted into consequent body
  $$payload.out.push('<p>big</p>');
  $$payload.out.push('<!--]-->');
} else {
  $$payload.out.push('<!--[!-->');  // unshifted into alternate body
  $$payload.out.push('<p>small</p>');
  $$payload.out.push('<!--]-->');
}
```

Key details:

- `block_open` is **unshifted** into the consequent's body and `BLOCK_OPEN_ELSE` into the
  alternate's body — markers are therefore *inside* the branch blocks, so whitespace resolution
  performed by `Fragment`/`clean_nodes` has already happened.
- A missing `{:else}` becomes `b.block([])` — still emits `<!--[!-->` + `<!--]-->` so the hydrator
  can detect "nothing rendered" and remove stale nodes on mismatch.
- The entire `b.if(test, consequent, alternate), block_close` pair is pushed to `state.template`.

### 4.2 `EachBlock`

**Strategy — hoisted array + plain `for` loop.** The most involved visitor in this module.

```mermaid
flowchart TD
    A["EachBlock node"] --> B["collection = visit(node.expression)"]
    B --> C{"contains_group_binding?<br/>or no explicit index?"}
    C -- yes --> D["use synthetic<br/>each_node_meta.index"]
    C -- no --> E["use user index id"]
    D & E --> F["state.init += const each_array =<br/>$.ensure_array_like(collection)"]
    F --> G["Build loop body:<br/>let item = each_array[i]<br/>(+ index alias if needed)<br/>+ visited body statements"]
    G --> H{"node.fallback<br/>({:else}) present?"}
    H -- yes --> I["template += if (each_array.length !== 0)<br/>  { push(open); for-loop } <br/>else { push(BLOCK_OPEN_ELSE); fallback }<br/>+ block_close"]
    H -- no --> J["template += block_open,<br/>for_loop, block_close"]
```

Input:

```svelte
{#each items as item, i}
  <li>{i}: {item}</li>
{:else}
  <p>empty</p>
{/each}
```

Output (conceptually):

```js
const each_array = $.ensure_array_like(items);
if (each_array.length !== 0) {
  $$payload.out.push('<!--[-->');
  for (let i = 0, $$length = each_array.length; i < $$length; i++) {
    let item = each_array[i];
    $$payload.out.push(`<li>${$.escape(i)}: ${$.escape(item)}</li>`);
  }
  $$payload.out.push('<!--]-->');
} else {
  $$payload.out.push('<!--[!-->');
  $$payload.out.push('<p>empty</p>');
  $$payload.out.push('<!--]-->');
}
```

Key details:

- **`$.ensure_array_like`** (server_runtime) normalizes iterables/iterators into indexable arrays
  and `null`/`undefined` into `[]`; the loop reads `$$length` once instead of touching `.length`
  every iteration.
- **Index aliasing:** if the analyzer flagged `contains_group_binding` (any `<group>` binding
  inside), the visitor uses the analyzer's synthetic `each_node_meta.index` and re-aliases it with
  `let <user index> = <synthetic index>` so user code sees the expected name. Without a user
  index, the synthetic one is used directly.
- **Fallback wrapping:** the fallback branch is gated by `each_array.length !== 0`; note the
  `block_open` statement is emitted *inside* the `if` (via `open`), while `block_close` trails the
  whole conditional — matching the hydration-marker invariant in §3.4.
- The `each_array` const goes to `state.init`, so it is declared once per enclosing fragment,
  before any output is pushed.

### 4.3 `AwaitBlock`

**Strategy — full delegation to the runtime.** Unlike `IfBlock`/`EachBlock`, no JS control-flow
statement is emitted; instead a single call:

```js
$.await(
  $$payload,
  promise_expression,
  () => { /* pending branch, or empty block */ },
  (value) => { /* then branch, or empty block */ }
);
$$payload.out.push('<!--]-->');
```

- The pending branch is wrapped with `b.thunk` (`() => {...}`) and the then branch with
  `b.arrow([value], ...)` — both are *lazily invoked by the runtime*, preserving SSR's ability to
  render the pending snippet first and stream/replace it when the promise resolves (the runtime
  helper coordinates with `Payload` and the abort-signal machinery of
  [server_runtime](server_runtime.md)).
- Missing `pending`/`then` children compile to empty blocks, so the visitor never has to
  special-case partial `{#await}…{:then}` forms.
- Only `block_close` is pushed by the visitor itself; the runtime helper is responsible for the
  matching `BLOCK_OPEN` and else-branch markers, keeping marker emission adjacent to the code that
  actually decides branch order.

### 4.4 `KeyBlock`

**Strategy — semantically a no-op on the server.** Keying only matters where re-creation of DOM
subtrees can occur (client). The visitor wraps the visited fragment between two `empty_comment`
anchors:

```js
$$payload.out.push('<!---->');
{ /* fragment statements */ }
$$payload.out.push('<!---->');
```

The anchors guarantee the fragment occupies stable marker positions in the HTML stream so
hydration can locate it and (on the client, in
[compiler_client_transform_control_flow_blocks](compiler_client_transform_control_flow_blocks.md))
re-create it when the key expression changes.

### 4.5 `SvelteBoundary`

**Strategy — boundary markers + pending-content selection.** For `<svelte:boundary>`, the visitor
emits `BLOCK_OPEN` … `BLOCK_CLOSE` and chooses one of three pending-content variants:

```mermaid
flowchart TD
    A["svelte:boundary node"] --> B{"pending attribute?<br/>(pending={snippet})"}
    B -- yes --> C["template += value($$payload)<br/>(snippet reference called with payload)"]
    B -- no --> D{"child {#snippet pending()}<br/>present?"}
    D -- yes --> E["template += visit(snippet.body)"]
    D -- no --> F["template += visit(node.fragment)<br/>(render children normally)"]
    C & E & F --> G["template += BLOCK_CLOSE literal"]
```

- `pending={snippet}` attributes are resolved with
  `build_attribute_value(..., is_component = true)` — attribute snippets are called directly with
  `$$payload` rather than escaped into HTML (note the `false, true` flags: no whitespace trimming
  of concern, component-context so the literal text is *not* HTML-escaped).
- The boundary markers tell the client hydrator where the error boundary's DOM region starts/ends;
  runtime pairing happens with the `boundary` block in
  [client_dom_renderer](client_dom_renderer.md) and the abort machinery in
  [server_runtime](server_runtime.md).

### 4.6 `ConstTag`

**Strategy — hoist to block scope.** `{@const y = expr}` produces no output; it declares a value
usable by later siblings *within the same block*. The visitor pushes
`const <id> = <init>` into `state.init`:

```svelte
{#if x}
  {@const y = x * 2}
  <span>{y}</span>
{/if}
```

```js
if (x) {
  const y = x * 2;                      // from state.init
  $$payload.out.push(`<span>${$.escape(y)}</span>`);  // from state.template
  $$payload.out.push('<!--]-->');
}
```

Because `Fragment` emits `[...state.init, ...build_template(state.template)]`, the declaration
precedes all output statements of the *enclosing* fragment — and since each branch body is its
own `Fragment` (visited recursively into a `BlockStatement`), `{@const}` inside an `{#if}`/`{#each}`
is correctly scoped to that branch. Eager evaluation (at block entry, not first use) matches the
runes-mode semantics established by the analyzer's
[compiler_analyzer_block_visitors](compiler_analyzer_block_visitors.md).

### 4.7 `DebugTag`

**Strategy — debug affordance, valid in SSR too.** `{@debug a, b}` emits into the template:

```js
console.log({ a, b });   // current values at render time
debugger;
```

The identifiers object uses shorthand props; values are visited through `context.visit` so store
subscriptions/prop getters apply. `b.debugger` halts attached devtools when the tag executes
during server rendering (typically in dev only).

---

## 5. End-to-end data flow

### 5.1 Compile-time flow

```mermaid
sequenceDiagram
    participant TS as transform-server.js
    participant ZW as zimmerframe walk()
    participant V as Control-flow visitor
    participant FR as Fragment visitor
    participant BT as build_template
    participant OUT as ESTree Program

    TS->>ZW: walk(template.ast, state, visitors)
    ZW->>V: dispatch node (e.g. EachBlock)
    V->>V: push consts to state.init<br/>(each_array, @const)
    V->>ZW: context.visit(children)
    ZW->>FR: child Fragment
    FR->>BT: block([...init, ...build_template(template)])
    FR-->>V: BlockStatement
    V->>V: state.template.push(b.if / b.for / $.await call,<br/>block_open / block_close literals)
    V-->>ZW: undefined (nodes accumulated in state)
    ZW->>TS: done walking
    TS->>OUT: component function body =<br/>[...hoisted, ...module, ...instance, ...template]
```

### 5.2 Runtime flow (generated code executing)

```mermaid
flowchart LR
    REQ["HTTP request"] --> CMP["component($$payload, $$props)"]
    CMP --> INIT["state.init statements<br/>(each_array, @const, ...)"]
    INIT --> BR{"control-flow<br/>statement"}
    BR -- if/for --> PUSH["$$payload.out.push(...)<br/>HTML + markers"]
    BR -- $.await --> AW["render pending, await promise,<br/>render then-branch"]
    AW --> PUSH
    PUSH --> JOIN["payload.out.join('')"]
    JOIN --> HTML["HTML response<br/>with <!--[--> / <!--[!--> / <!--]--> markers"]
    HTML --> HYD["Client hydrator<br/>(client_dom_renderer)<br/>claims branch nodes by marker"]
```

---

## 6. Dependencies

### Upstream (consumed by this module)

| Dependency | What is used | Link |
| --- | --- | --- |
| `compiler_server_transform_pipeline` | `Fragment` (child visiting), `process_children`, `build_template`, `build_attribute_value`, `block_open`/`block_close`/`empty_comment` literals | [compiler_server_transform_pipeline](compiler_server_transform_pipeline.md) |
| `compiler_core` | `builders.js` (`b.*` ESTree factories), `scope.js`/`set_scope` | [compiler_core](compiler_core.md) |
| `compiler_types` | `AST.IfBlock`, `AST.EachBlock`, `AST.AwaitBlock`, `AST.KeyBlock`, `AST.SvelteBoundary`, `AST.ConstTag`, `AST.DebugTag` node types | [compiler_types](compiler_types.md) |
| `compiler_analyzer_block_visitors` | Analysis metadata: `each_node_meta.contains_group_binding`, synthetic `each_node_meta.index` | [compiler_analyzer_block_visitors](compiler_analyzer_block_visitors.md) |
| `compiler_diagnostics` | Errors/warnings already raised in phase 2 — this module performs no validation | [compiler_diagnostics](compiler_diagnostics.md) |
| `server_runtime` (hydration.js) | `BLOCK_OPEN`, `BLOCK_OPEN_ELSE`, `BLOCK_CLOSE` marker literals | [server_runtime](server_runtime.md) |

### Downstream (consumes this module's output)

| Consumer | Relationship | Link |
| --- | --- | --- |
| `transform-server.js` | Registers all seven visitors in `template_visitors`; assembles final `Program` | [compiler_server_transform](compiler_server_transform.md) |
| `server_runtime` | Generated code calls `$.await`, `$.ensure_array_like`, `$.escape`, `$.stringify`, `$$payload.out.push` | [server_runtime](server_runtime.md) |
| `client_dom_renderer` | Hydrator parses the emitted `<!--[-->`/`<!--[!-->`/`<!--]-->`/`<!---->` markers to reclaim branch DOM | [client_dom_renderer](client_dom_renderer.md) |
| `compiler_client_transform_control_flow_blocks` | Client-side counterpart generating the symmetric DOM logic | [compiler_client_transform_control_flow_blocks](compiler_client_transform_control_flow_blocks.md) |

---

## 7. Design invariants and gotchas

1. **Branches must be lazy.** `IfBlock` compiles to native `if/else` and `AwaitBlock` to thunks so
   that a branch's expressions execute only when taken — never visit a branch body outside the
   branch statement.
2. **`init` runs before output.** All declarations (`ConstTag`, `each_array`) are pushed to
   `state.init` and emitted before the fragment's output statements. Do not push declarations into
   `template` — order would depend on `build_template` statement coalescing.
3. **Marker pairing is a hard contract.** `block_open`/`block_close` must wrap every branch
   region exactly once; `BLOCK_OPEN_ELSE` lives *inside* a branch body. Breaking this silently
   breaks hydration, not compilation.
4. **Fragment state is copied, arrays are shared.** `process_children` spreads state
   (`{ ...state }`) per child visit, so array pushes from nested visitors still reach the
   correct fragment's `init`/`template`. Never *reassign* `state.template`/`state.init` —
   create a new state via `Fragment` instead.
5. **`EachBlock` length caching.** The loop condition compares against a `$$length` const, so
   mutating the collection mid-render does not extend the loop; `$.ensure_array_like` also
   guarantees an indexable array for Set/Map/generator inputs.
6. **Group bindings force a synthetic index.** If the analyzer detected
   `contains_group_binding`, `node.index` is an alias (`let userIndex = synthetic`) — the
   synthetic index must be the loop variable so per-iteration identity is stable.
7. **`AwaitBlock` marker ownership is split.** The visitor emits only the trailing
   `block_close`; the `$.await` runtime helper owns the opening marker and else-branch handling.
   Keep this split when modifying either side.
8. **`KeyBlock` is not free.** It adds two `<!---->` anchors to the payload; avoid wrapping
   static content in `{#key}` for output-size-sensitive SSR.
9. **Escaping happens deeper in the pipeline.** These visitors never HTML-escape text;
   `process_children`/`build_attribute_value` wrap dynamic values in `$.escape`/`$.stringify`.
   Raw output (`{@html}`) is handled by `HtmlTag` in
   [compiler_server_transform_elements](compiler_server_transform_elements.md), not here.
10. **No validation here.** Illegal constructs (e.g. `{@const}` outside a block, `{:else}` on a
    `{#key}`) are compile errors raised in phase 2 by the analyzer visitors; this module can
    assume well-formed, typed nodes.

---

## 8. Debugging tips

- To see the emitted output for a component, compile with `generate: 'server'` and inspect the
  `js.code`; markers `<!--[-->`, `<!--[!-->`, `<!--]-->` make branch regions easy to spot.
- `svelte output` in the Playground (see
  [sandbox-playground](sandbox-playground.md)) renders this module's transformations live.
- SSR rendering tests live under `packages/svelte/tests/server-side-rendering/`; hydration-marker
  mismatches typically indicate a visitor emitting unbalanced `block_open`/`block_close`.
- The client-side counterpart tests in
  `packages/svelte/tests/hydration/` verify that the markers emitted here match what
  [client_dom_renderer](client_dom_renderer.md) expects.
