# context_api_server

> **Module path:** `packages/svelte/src/internal/server/context.js`
> **Parent module:** [Context API](context_api.md) · **Sibling module:** [Context API — Client](context_api_client.md)

## 1. Introduction

The **`context_api_server`** module is the server-side implementation of Svelte's [Context API](context_api.md) (`setContext`, `getContext`, `hasContext`, `getAllContexts`). Because server-side rendering (SSR) is fully **synchronous and single-pass**, this module implements context using a radically simpler strategy than its client counterpart: a module-level **component stack** (`current_component`) modelled as a parent-linked list, with a lazily-created, copy-inheriting `Map` per component.

Besides the four public context functions, the module owns two internal lifecycle primitives — `push()` and `pop()` — which bracket every component's execution during SSR. These primitives make the module the *de-facto component-scoping backbone of the server runtime*: the [server rendering core](server_runtime_rendering_core.md) drives them from `render()`, and the public `onDestroy` API uses the stack to defer cleanup callbacks until the render completes.

---

## 2. Architecture Overview

The module is a single file exporting six functions and one piece of module state. It intentionally has **no dependencies on reactivity, effects, or the DOM** — only on `esm-env` (the `DEV` flag), the server runtime's `on_destroy` queue, and the shared diagnostics module.

```mermaid
flowchart TB
    subgraph PUBLIC["Public API Surface"]
        PUB["public_api<br/>index-server.js<br/>(re-exports context fns, defines onDestroy)"]
    end

    subgraph SERVER["Server Internal (this ecosystem)"]
        CTX["context_api_server<br/>server/context.js<br/>★ this module"]
        RENDER["server_runtime_rendering_core<br/>server/index.js — render()"]
        OD["on_destroy queue<br/>(server/index.js)"]
        SHARED["shared_runtime<br/>shared/errors.js<br/>lifecycle_outside_component"]
    end

    subgraph CLIENT["Client Internal (parity contract)"]
        CCTX["context_api_client<br/>client/context.js"]
    end

    PUB -- "re-exports setContext / getContext /<br/>hasContext / getAllContexts" --> CTX
    PUB -- "onDestroy writes to current_component.d" --> CTX
    RENDER -- "push() / pop() around root component" --> CTX
    CTX -- "deferred destroy callbacks" --> OD
    CTX -- "throws on invalid usage" --> SHARED
    CTX <-. "API parity, same call sites<br/>emitted by the compiler" .-> CCTX
```

### 2.1 Exported Components

| Symbol | Kind | Visibility | Purpose |
|---|---|---|---|
| `current_component` | `Component \| null` (module `var`) | internal (consumed by `index-server.js`, `server/index.js`) | Top of the component stack; `null` when no component is initializing. |
| `push(fn)` | function | internal | Enter a component's initialization scope. |
| `pop()` | function | internal | Exit the scope; forward collected destroy callbacks. |
| `setContext(key, context)` | function | public (via [public_api](public_api.md)) | Store a context value; returns the value. |
| `getContext(key)` | function | public (via [public_api](public_api.md)) | Read a context value, searching ancestors. |
| `hasContext(key)` | function | public (via [public_api](public_api.md)) | Check whether a key resolves in the current chain. |
| `getAllContexts()` | function | public (via [public_api](public_api.md)) | Return the component's entire context `Map`. |

### 2.2 Internal Helpers

| Symbol | Purpose |
|---|---|
| `get_or_init_context_map(name)` | Guards that a component is initializing (throws `lifecycle_outside_component` otherwise) and lazily creates the component's context `Map`, seeded from the nearest ancestor's map. |
| `get_parent_context(component)` | Walks the `p` (parent) chain and returns the first ancestor's non-null context map, or `null`. |

---

## 3. Core Data Model

The entire module revolves around one record shape and two pieces of module state.

### 3.1 The component context record

```mermaid
classDiagram
    class Component {
        +Component? p
        +Map? c
        +Function[]? d
        +Function? function
    }
    note for Component "p — parent link (linked-list stack, null = root)
c — context Map, LAZY: null until a context fn is called
    (or until render() installs options.context on the root)
d — array of onDestroy callbacks, LAZY: null until onDestroy is called
function — DEV-only: the component function, attached in push()
    for richer diagnostics"
```

### 3.2 Module state & cross-module handles

* **`current_component`** — the stack top. SSR never yields, so a single mutable variable is a correct stack representation; every `push`/`pop` pair restores the previous value.
* **`on_destroy`** (owned by [server_runtime_rendering_core](server_runtime_rendering_core.md)) — a module-level `Function[]`. `pop()` appends the finished component's `d` array to it; `render()` drains it once at the end of the render pass. This is the only channel through which this module mutates foreign state.

---

## 4. Component Reference

### 4.1 `push(fn)`

```js
export function push(fn) {
	current_component = { p: current_component, c: null, d: null };
	if (DEV) {
		// component function
		current_component.function = fn;
	}
}
```

* Creates a fresh record whose parent is the previous stack top, then installs it.
* Both `c` (context map) and `d` (destroy callbacks) start as `null` and are created **lazily** — components that never touch context or `onDestroy` never allocate them.
* In `DEV` builds, stores the component function for error-message attribution by dev tooling.
* Called once per component by the compiler-generated server code, and once by `render()` when the user passes `options.context` (see [§5](#5-process-flows)). Note that `render()` calls `push()` with no argument; `fn` is optional by design.

### 4.2 `pop()`

```js
export function pop() {
	var component = current_component;
	var ondestroy = component.d;
	if (ondestroy) {
		on_destroy.push(...ondestroy);
	}
	current_component = component.p;
}
```

* Restores the parent as the stack top.
* **Destroy deferral:** any `onDestroy` callbacks registered during initialization (via `current_component.d`, populated by [`index-server.js`](public_api.md)) are handed to the render-wide `on_destroy` queue instead of being invoked. `render()` invokes them after the component tree finishes emitting markup, then restores its own saved queue (making nested/reentrant renders safe). There is no equivalent on the client, where cleanup is bound to unmount effects.
* Unlike the client's `pop` (which returns the component instance and flushes queued effects), the server `pop()` returns nothing — SSR has no instance object to hand back.

### 4.3 `setContext(key, context)` / `getContext(key)` / `hasContext(key)` / `getAllContexts()`

All four share the same preamble: obtain the component's context map through `get_or_init_context_map(name)`, then perform a plain `Map` operation:

| Function | Operation | Returns |
|---|---|---|
| `setContext` | `map.set(key, context)` | the `context` value (enables pass-through usage) |
| `getContext` | `map.get(key)` | value or `undefined`; **no** "not found" error |
| `hasContext` | `map.has(key)` | `boolean` |
| `getAllContexts` | the map itself | live `Map` for the current component |

Because the map is per-component (not global), a `setContext` during component *X*'s initialization is visible to `getContext` in *X* **and in descendants initialized later** — the standard Svelte scoping rule, satisfied here purely by stack position rather than by any reactive mechanism.

### 4.4 `get_or_init_context_map(name)` — the lazy-inheritance core

```mermaid
flowchart TD
    A["Context fn called<br/>(getContext / setContext /<br/>hasContext / getAllContexts)"] --> B{"current_component<br/>=== null ?"}
    B -- "yes" --> E["throw lifecycle_outside_component<br/>(shared_runtime errors module)"]
    B -- "no" --> F{"component.c<br/>already initialized?"}
    F -- "yes" --> G["return existing Map"]
    F -- "no" --> H["get_parent_context:<br/>walk p-chain for nearest<br/>ancestor with a Map"]
    H -- "found" --> I["new Map(ancestorMap)<br/>→ snapshot copy"]
    H -- "none" --> J["new Map(undefined)<br/>→ empty Map"]
    I --> K["component.c ??= map<br/>(memoized on the record)"]
    J --> K
    K --> G
```

Key semantics encoded here:

1. **Initialization-scope guard.** Every context function is legal *only during component initialization* (i.e., while `current_component !== null`). Calling one from an event handler, module scope, or after `pop()` throws [`lifecycle_outside_component`](shared_runtime.md), with the offending function `name` embedded in the dev-mode message. The server `push`/`pop` window *is* "component initialization" — there is no post-init lifecycle in SSR.
2. **Lazy creation.** `c` is `null` until the first context access, so context-free components cost nothing beyond the record itself.
3. **Snapshot inheritance.** `new Map(parentMap)` **copies** the nearest ancestor's entries at first access. Lookups in the child therefore hit its own map — `get_parent_context` is only consulted once, ever. Consequences worth remembering:
   * Mutating a parent's context *after* a descendant has read it does **not** propagate to that descendant's map (context is intentionally not reactive — see the [Context API overview](context_api.md)).
   * A child that only *reads* still materializes its own map copy; `getAllContexts()` returns the child's map, which can be larger than what the child set.
   * Overrides are trivially supported: `setContext` on the child map shadows same-key ancestors (including the root map installed by `render()`).

### 4.5 `get_parent_context(component_context)`

A plain iterative walk of the `p` links, returning the first non-null `c` found or `null`. Iterative (not recursive) so deep component trees cannot overflow the stack.

---

## 5. Process Flows

### 5.1 Server render lifecycle (component interaction)

The sequence below shows how the [server rendering core](server_runtime_rendering_core.md) and this module cooperate for a full `render()` call, including the `options.context` root-injection path.

```mermaid
sequenceDiagram
    autonumber
    participant App as Application
    participant R as render() — server/index.js
    participant C as context.js (this module)
    participant Root as Root component fn
    participant Child as Child component fn

    App->>R: render(Component, { props, context? })
    R->>R: save + reset on_destroy queue
    opt options.context provided
        R->>C: push()
        Note over C: stack: { p:null, c:null, d:null }
        R->>C: current_component.c = options.context
        Note over C: user Map becomes the ROOT context
    end
    R->>Root: component(payload, props, ...)
    Root->>C: push(fn) / setContext("user", u)
    Note over C: Root.c = new Map → { "user": u }
    Root->>Child: render child
    Child->>C: push(fn)
    Child->>C: getContext("user")
    C-->>Child: u  (via snapshot copy of Root.c)
    Root-->>C: onDestroy(cleanup)
    Note over C: Root.d = [cleanup]
    Child->>C: pop()
    Note over C: restore Root; Child.d (empty) skipped
    Root-->>R: markup written to payload
    R->>C: pop()   (if options.context was used)
    Note over C: Root.d → on_destroy; stack restored
    R->>R: run every queued cleanup fn
    R-->>App: { html, head, body }
```

### 5.2 Push/pop stack discipline

```mermaid
stateDiagram-v2
    [*] --> NoComponent: module load (current_component = null)
    NoComponent --> CompA: push(fn)
    CompA --> CompB: push(fn)
    note right of CompB: getContext sees B's map,<br/>falling back to A's snapshot
    CompB --> CompA: pop()  (B.d → on_destroy)
    CompA --> NoComponent: pop()  (A.d → on_destroy)
    NoComponent --> [*]: render() drains on_destroy
```

Any context call attempted in the `NoComponent` state throws `lifecycle_outside_component`.

### 5.3 Compiler contract

The Svelte compiler emits `push(...)` / `pop()` around each component's server-side function body (see the code-generation visitors in [Compiler Back-End — server transform](Compiler_Back-End_(Client___Server_Code_Generation).md)), and compiles user-facing `setContext`/`getContext`/`hasContext`/`getAllContexts` imports to this module's exports. The module therefore must keep its exact export names and `push`/`pop` arity stable — they are part of the compiler↔runtime contract.

---

## 6. Module Relationships

| Relationship | Direction | Details | Documented in |
|---|---|---|---|
| Public re-export | → this module | `index-server.js` line 42 re-exports the four context functions; it also implements `onDestroy` by writing to `current_component.d`. | [public_api](public_api.md) |
| Lifecycle driver | → this module | `render()` calls `push()`/`pop()` around the root component when `options.context` is given, and drains `on_destroy` afterwards. | [server_runtime_rendering_core](server_runtime_rendering_core.md) |
| Destroy-callback sink | ← this module | `pop()` appends collected callbacks to the `on_destroy` queue owned by the rendering core. | [server_runtime_rendering_core](server_runtime_rendering_core.md) |
| Render output | (context) | Context values must be serializable/plain when used to produce markup; they are consumed synchronously during payload assembly. | [server_runtime_payload_model](server_runtime_payload_model.md) |
| Diagnostics | → shared | `lifecycle_outside_component` (and the server errors façade) come from the shared error module. | [shared_runtime](shared_runtime.md) |
| Client twin | ↔ parity | Same four public functions, same compiler call sites; diverges in record shape, effect handling, and `pop` return value. | [context_api_client](context_api_client.md) |
| Parent scope | container | This module is the `context_api_server` leaf of the context API family. | [context_api](context_api.md) · [Cross-Runtime Platform Services](Cross-Runtime_Platform_Services_(Shared_Utilities,_Flags___Context_Injection).md) |

---

## 7. Server vs. Client Implementation Notes

For maintainers touching both halves of the context API, the essential differences:

| Aspect | Server (this module) | Client ([context_api_client](context_api_client.md)) |
|---|---|---|
| Stack variable | `current_component` | `component_context` |
| Record fields | `p`, `c`, `d`, DEV `function` | `p`, `c`, `e` (effects), `s` (props), `x` (component), `l` (legacy), DEV `function` |
| `push` signature | `push(fn)` — fn only in DEV | `push(props, runes, fn)` — carries props & legacy-mode metadata |
| `pop` behavior | Defers `d` callbacks to `on_destroy`; returns nothing | Flushes queued effects immediately, binds component instance, returns it |
| Reactivity | None — context is a plain `Map` snapshot | Same Map snapshot, but embedded in the effect/signal graph |
| Primary consumer | `render()` (SSR pass) | `mount`/`hydrate` + ongoing component lifecycle |
| Dev instrumentation | `function` for diagnostics | `dev_current_component_function` + ownership validators, tracing tags |

Both implementations share the *lazy map + nearest-ancestor snapshot* inheritance rule, so behavior of user code (`setContext`/`getContext` semantics) is identical across environments.

---

## 8. Error Handling & Edge Cases

* **`lifecycle_outside_component`** — thrown by `get_or_init_context_map` when any context function runs outside a `push`/`pop` window. Dev builds produce a full message with the function name and a docs URL; production builds throw a minimal URL-only `Error` to keep the bundle small.
* **`getContext` of a missing key** returns `undefined` silently (by design — matches client behavior). Use `hasContext` to disambiguate.
* **Reentrancy** — `render()` saves and restores both the `on_destroy` queue and (via `pop`) the component stack, so a `render` invoked during another render (e.g., rendering a component to string from within a context consumer) cannot corrupt outer state.
* **Keys** — stored in a native `Map`, so keys use SameValueZero equality (objects, functions, and `Symbol` are all valid keys; this is the idiomatic way to create private context keys, e.g. via [`createAttachmentKey`](actions_and_attachments.md)-style symbol factories).
* **Tree-shaking** — the module is dependency-light (`esm-env`, server index, shared errors); the `DEV`-guarded block is dead-code-eliminated in production builds, consistent with the repo's treeshakeability checks ([Repository Engineering Infrastructure](Repository_Engineering_Infrastructure_(Benchmarks,_Build_Scripts___Playground).md)).

---

## 9. Quick Reference (maintainer cheat-sheet)

* Adding a new context-related public API? Add it here, guard it with `get_or_init_context_map('<name>')`, re-export from [`index-server.js`](public_api.md), and mirror it in [context_api_client](context_api_client.md).
* Changing the `Component` record shape? Update `push`/`pop` here, the compiler's server-transform visitors, `onDestroy` in `index-server.js`, and the client twin.
* Debugging "context is undefined" during SSR? Check that (1) the call happens during initialization, (2) the providing ancestor calls `setContext` before the consumer's first context access (snapshot semantics), and (3) `render()`'s `options.context` is only installed on the root record.
