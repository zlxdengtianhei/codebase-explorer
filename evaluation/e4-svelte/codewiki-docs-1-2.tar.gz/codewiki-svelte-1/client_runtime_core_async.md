# Client Runtime Core — Async (`client_runtime_core_async`)

> **Source:** `packages/svelte/src/internal/client/reactivity/async.js`
> **Parent module:** [client_runtime_core](client_runtime_core.md) (Reactive Runtime Engine)
> **Feature flag:** experimental `async` mode (`enable_async_mode_flag`), controlled by the `experimental.async` compile option.

## 1. Introduction

`client_runtime_core_async` is the runtime heart of Svelte's **experimental asynchronous components**. A standard Svelte 5 component is a purely synchronous effect tree: template expressions, `$derived`, and component bodies all evaluate synchronously against an *active effect* so that signal reads can be tracked as dependencies. Async mode relaxes this constraint — components and template expressions may contain `await` — which creates three fundamental problems that this module solves:

1. **Reactivity tracking across await points.** Signal reads that happen *after* an `await` must still register as dependencies of the correct effect, otherwise the UI silently stops updating.
2. **Context preservation.** The active effect, active reaction, component context (`component_context`) and the current batch are ambient, synchronous state. Any asynchronous continuation must restore them before touching reactive state.
3. **Coordination with boundaries and batching.** While a component is awaiting, the nearest [`{#snippet pending=…}` boundary](client_dom_renderer.md) must show its pending snippet and the batch scheduler must be held open; errors after resolution must be routed into error boundaries, or swallowed if the block was already destroyed.

The module exposes three compiler-facing primitives — `save`, `track_reactivity_loss`, `for_await_track_reactivity_loss` — plus the component-body wrapper `async_body`, and internal helpers (`flatten`, `capture`, `unset_context`) shared with the async DOM block.

| Export | Visibility | Purpose |
| --- | --- | --- |
| `save(promise)` | compiler-generated code (`$.save`) | Snapshot & restore effect context around a top-level/continuation `await` |
| `track_reactivity_loss(promise)` | compiler-generated code (`$.track_reactivity_loss`, DEV only) | Detect reactive reads that lose tracking across `await` and warn (`await_reactivity_loss`) |
| `for_await_track_reactivity_loss(iterable)` | compiler-generated code (`$.for_await_track_reactivity_loss`, DEV only) | DEV wrapper for `for await` loops implementing ECMA-262 iterator semantics with reactivity-loss tracking |
| `async_body(fn)` | runtime (async component bodies) | Suspend the boundary while an async component body runs; route errors; unsuspend |
| `flatten(sync, async, fn)` | internal (`dom/blocks/async.js`) | Evaluate mixed sync/async template expressions, then apply the result |
| `capture()` / `unset_context()` | internal | Context snapshot/restore factory and context clearing |

---

## 2. Architecture

The module sits *between* the compiler back-end (which rewrites `await` expressions into calls to this module) and the reactive core (effects, batching, deriveds, boundaries). It is intentionally a thin coordination layer: it owns no scheduling logic of its own but composes the primitives of `batch.js`, `deriveds.js`, `boundary.js` and `error-handling.js`.

```mermaid
flowchart TB
    subgraph Compiler["Compiler back-end — client transform"]
        direction LR
        AE["AwaitExpression visitor<br/>(compiler_client_transform_components_and_scripts)"]
        FO["ForOfStatement visitor<br/>(compiler_client_transform_components_and_scripts)"]
    end

    subgraph Module["client_runtime_core_async (async.js)"]
        SAVE["save(promise)"]
        TR["track_reactivity_loss(promise)"]
        FA["for_await_track_reactivity_loss(iter)"]
        AB["async_body(fn)"]
        FL["flatten(sync, async, fn)"]
        CAP["capture() / unset_context()"]
    end

    subgraph Core["client_runtime_core — reactive core"]
        direction LR
        RT["runtime.js<br/>active_effect · active_reaction"]
        CTX["context.js<br/>component_context · is_runes"]
        BAT["batch.js<br/>current_batch · suspend"]
        DER["deriveds.js<br/>async_derived · derived · set_from_async_derived"]
        EFF["effects.js<br/>aborted · block"]
    end

    subgraph Renderer["client_dom_renderer"]
        direction LR
        ASYNC["dom/blocks/async.js → async()"]
        BND["dom/blocks/boundary.js<br/>Boundary · get_pending_boundary"]
        AW["dom/blocks/await.js → await_block"]
    end

    EH["error-handling.js → invoke_error_boundary"]

    AE -- "$.save(a)" --> SAVE
    AE -- "$.track_reactivity_loss(a)" --> TR
    FO -- "$.for_await_track_reactivity_loss(it)" --> FA
    ASYNC -- "flatten()" --> FL
    AB --> BAT
    FL --> DER
    SAVE --> CAP
    TR --> CAP
    FL --> CAP
    BAT --> BND
    FL --> BND
    AB --> EH
    FL --> EH
    EFF --> AB
    SAVE --> RT
    CAP --> RT
    CAP --> CTX
```

**Relationship to `{#await}` blocks.** The classic `{#await promise}…{/await}` block (`dom/blocks/await.js → await_block`) is a *branch-switching* construct: it shows pending/then/catch branches as promise state changes; it does not make component code itself asynchronous and does not use this module. Async mode is the orthogonal feature where `await` appears *inline* in component bodies and template expressions, which is what this module enables.

---

## 3. Component Reference

### 3.1 `save(promise)` — context-preserving await

```js
export async function save(promise) {
  var restore = capture();
  var value = await promise;
  return () => { restore(); return value; };
}
```

The compiler rewrites reactive `await` expressions so that the *context restoration happens on the resolved value's accessor*, not on the promise:

```svelte
{@expression (await a) + b}
<!-- compiles to -->
{@expression (await $.save(a))() + b}
```

`save` snapshots the ambient context via `capture()` **before** awaiting — active effect, active reaction, component context, current batch — and returns a thunk that (a) restores that context and (b) yields the resolved value. Consequently the subsequent read of `b` executes with the original effect active and is correctly registered as its dependency.

Per the `AwaitExpression` client-transform visitor, `$.save` is injected when:
- the `await` is a **top-level await** in a component instance, or
- the `await` occurs inside a **reactive expression** (template expression / `$derived`) and is **not the last evaluated expression** (i.e. reactive reads may still follow it).

In all other cases, the compiler either emits `$.track_reactivity_loss` (dev, warnings not silenced) or leaves the expression untouched.

### 3.2 `track_reactivity_loss(promise)` — DEV reactivity-loss instrumentation

```js
export async function track_reactivity_loss(promise) {
  var previous_async_effect = current_async_effect;
  var value = await promise;
  return () => { set_from_async_derived(previous_async_effect); return value; };
}
```

A DEV-mode counterpart of `save` for `await`s where full context restoration is unnecessary. After the promise settles, it restores the previous `current_async_effect` (via `deriveds.js → set_from_async_derived`), which allows the runtime's async-derived bookkeeping to detect that a reactive value was read across an await point without effective tracking and emit the **`await_reactivity_loss`** warning (see [client_dev_mode](client_dev_mode.md) and the warnings in [client_runtime_core_diagnostics](client_runtime_core_diagnostics.md)). The warning is silenced with `<!-- svelte-ignore await_reactivity_loss -->`.

### 3.3 `for_await_track_reactivity_loss(iterable)` — DEV `for await` wrapper

```js
export async function* for_await_track_reactivity_loss(iterable) { /* … */ }
```

A DEV-only async generator that the compiler injects for `for await (… of …)` loops (when `experimental.async` is on and `await_reactivity_loss` is not ignored). It re-implements the observable semantics of the ECMA-262 algorithms **ForIn/OfBodyEvaluation** and **AsyncIteratorClose**:

- obtains the iterator via `Symbol.asyncIterator` falling back to `Symbol.iterator` (sync iterables are supported), throwing `TypeError('value is not async iterable')` otherwise;
- wraps **every** `iterator.next()` result — and the `iterator.return()` result on normal completion (`break`, `return`, etc.) — in `track_reactivity_loss`, so `await_reactivity_loss` warnings can be emitted after each step resolves;
- propagates `done`/`value` through `yield` and honors `iterator.return` in a `finally` block, mirroring AsyncIteratorClose.

```mermaid
flowchart TD
    A["for await (x of it) {…}"] --> B["$.for_await_track_reactivity_loss(it)"]
    B --> C{"asyncIterator or<br/>Symbol.iterator?"}
    C -- "none" --> D["throw TypeError"]
    C --> E["loop: await track_reactivity_loss(iterator.next())"]
    E --> F{"done?"}
    F -- "no" --> G["restore async-effect tracking → yield value"]
    G --> E
    F -- "yes" --> H{"iterator.return defined?<br/>(normal completion only)"}
    H -- "yes" --> I["track iterator.return → return its value"]
    H -- "no" --> J["generator finishes"]
```

### 3.4 `async_body(fn)` — async component body wrapper

```js
export async function async_body(fn) {
  var unsuspend = suspend();               // batch.js → suspend()
  var active = active_effect;
  try {
    await fn();
  } catch (error) {
    if (!aborted(active)) invoke_error_boundary(error, active);
  } finally {
    unsuspend();
  }
}
```

Wraps the body of a component whose instance script contains top-level `await` (the compiler marks such components as async). Lifecycle:

1. **Suspend** — `batch.js → suspend()` finds the nearest pending boundary (`get_pending_boundary`, throws `await_outside_boundary` if none), increments its pending count, and increments the current batch, keeping pending UI visible and holding the batch open.
2. **Run** — awaits `fn()`, the component's top-level initialization.
3. **Error routing** — errors are pushed to `invoke_error_boundary`, which walks the effect ancestry to the nearest `BOUNDARY_EFFECT` and calls `Boundary.error(error)`; if none exists, the error is re-thrown. Errors in already-`DESTROYED` effects are deliberately swallowed (the block has been torn down, e.g. mid navigation).
4. **Unsuspend** — `unsuspend()` decrements the boundary pending count (hiding the pending snippet and reattaching the offscreen main content when it hits zero), decrements/activates the batch, and calls `unset_context()` so stale ambient context cannot leak into unrelated reactions.

```mermaid
flowchart TD
    A["async_body(fn)"] --> B["suspend():<br/>boundary.update_pending_count(+1)<br/>batch.increment()"]
    B --> C["await fn()"]
    C -- "resolves" --> G["finally: unsuspend()"]
    C -- "throws" --> D{"aborted(active_effect)<br/>i.e. DESTROYED flag?"}
    D -- "no" --> E["invoke_error_boundary(error, effect)<br/>→ Boundary.error or re-throw"]
    D -- "yes" --> F["swallow (block already destroyed)"]
    E --> G
    F --> G
    G --> H["boundary.update_pending_count(-1)<br/>batch activate/decrement · unset_context()"]
```

### 3.5 `flatten(sync, async, fn)` — mixed sync/async expression evaluation (internal)

The workhorse behind the async DOM block (`client_dom_renderer → dom/blocks/async.js::async`), which renders templates whose expressions may await:

1. **Sync expressions** are immediately converted to deriveds — `derived` in runes mode, `derived_safe_equal` in legacy mode (`is_runes()` from [context API](context_api.md)).
2. **Async expressions** are each wrapped in `async_derived` (see [client_runtime_core_deriveds](client_runtime_core_deriveds.md)), producing reactive signals backed by promise resolution; all are combined with `Promise.all`.
3. The current context is captured (`capture()`), along with the parent effect and the nearest pending boundary.
4. On resolution: the batch is re-activated, context restored, and `fn(values)` is invoked with all values (sync deriveds first, then async results). Errors thrown by `fn` go to `invoke_error_boundary` unless the parent effect was destroyed. Batch is deactivated and context cleared afterwards (`unset_context`).
5. A rejected promise (e.g. from `async_derived`) is routed to the boundary directly: `boundary.error(error)` — surfacing the `{#snippet failed=…}` fallback.

```mermaid
sequenceDiagram
    autonumber
    participant B as dom/blocks/async.js (async)
    participant F as flatten()
    participant D as deriveds.js (async_derived)
    participant P as Promise.all
    participant Bd as Boundary
    participant E as Error boundary / batch

    B->>F: flatten([], expressions, fn)
    F->>F: capture() context · get_pending_boundary()
    F->>D: expression → async_derived(expr) (per async expr)
    F->>P: Promise.all([async_derived…])
    P-->>F: resolved values
    F->>E: batch.activate() · restore() context
    F->>B: fn([...syncDeriveds, ...values])
    alt fn throws & parent not destroyed
        F->>E: invoke_error_boundary(error, parent)
    end
    F->>E: batch.deactivate() · unset_context()
    Note over P,Bd: rejection path →<br/>Bd.error(error) → failed snippet
```

### 3.6 `capture()` and `unset_context()` — context plumbing (internal)

- **`capture()`** snapshots `active_effect`, `active_reaction`, `component_context` and `current_batch`, returning a `restore()` closure that re-applies all four (and, in DEV, resets the async-derived tracking set by `track_reactivity_loss`). This one primitive powers both `save` and `flatten` and is the module's core idiom: *snapshot before await, restore before touching signals*.
- **`unset_context()`** nulls the active effect, reaction, component context (and the DEV async-derived marker). It is invoked after async continuations finish so that late-resolving work cannot accidentally attribute signal writes/reads to a stale effect — the guard that keeps unrelated reactions isolated.

---

## 4. End-to-End Data Flow

The complete journey of an inline `await` in a reactive template expression, from source to reactive update:

```mermaid
flowchart LR
    subgraph FE["Compiler front-end"]
        P["1-parse · 2-analyze<br/>AwaitExpression / AwaitBlock visitors"]
    end
    subgraph BE["Compiler back-end (client)"]
        T["3-transform · AwaitExpression<br/>rewrites to $.save / $.track_reactivity_loss"]
    end
    subgraph RT["Runtime (this module + core)"]
        S["save(): capture → await → restore"]
        TRACK["read of b registers<br/>dependency on active effect"]
        E["batched flush re-renders"]
    end

    P --> T --> S --> TRACK --> E
```

1. **Front-end** parses and analyzes the `await` (see [Compiler Front-End](Compiler_Front-End_(Parsing,_Analysis___CSS_Scoping_Pipeline).md)); analysis diagnostics such as `await_reactivity_loss` suppressibility are recorded.
2. **Back-end** (`compiler_client_transform_components_and_scripts`) decides between `$.save` (context must survive), `$.track_reactivity_loss` (dev warning only), or no rewrite — see the decision table in §3.1.
3. **Runtime** — `save` guarantees the post-await read of `b` happens with the original effect active; the resulting dependency graph is what makes later updates to `b` re-render the template.
4. **Scheduling** — while promises are pending, the enclosing boundary's pending count is > 0 (via `suspend`/`flatten`), so the `pending` snippet shows; on resolution the batch flushes the re-render (see [client_runtime_core_batching](client_runtime_core_batching.md)). `runtime.js → tick()` also respects `async_mode_flag` by deferring to the next animation frame (see [client_runtime_core_runtime](client_runtime_core_runtime.md)).

---

## 5. Dependencies

### 5.1 Inbound (what this module consumes)

| Import | Consumed symbols | Role |
| --- | --- | --- |
| `#client/constants` | `DESTROYED` | Detect destroyed effects (swallow late errors) |
| `esm-env` | `DEV` | Gate all dev-only instrumentation (tree-shaken in prod) |
| `../context.js` | `component_context`, `is_runes`, `set_component_context` | Component context snapshot/restore; runes-mode detection ([context_api](context_api.md)) |
| `../dom/blocks/boundary.js` | `get_pending_boundary` | Resolve nearest boundary with a `pending` snippet; `await_outside_boundary` otherwise |
| `../error-handling.js` | `invoke_error_boundary` | Route async errors to `Boundary.error` or re-throw |
| `../runtime.js` | `active_effect`, `active_reaction`, `set_active_effect`, `set_active_reaction` | Ambient effect state ([client_runtime_core_runtime](client_runtime_core_runtime.md)) |
| `./batch.js` | `current_batch`, `suspend` | Batch suspension while async work is pending ([client_runtime_core_batching](client_runtime_core_batching.md)) |
| `./deriveds.js` | `async_derived`, `current_async_effect`, `derived`, `derived_safe_equal`, `set_from_async_derived` | Promise-backed reactive signals; dev async tracking ([client_runtime_core_deriveds](client_runtime_core_deriveds.md)) |
| `./effects.js` | `aborted` | DESTROYED-flag check ([client_runtime_core_effects](client_runtime_core_effects.md)) |

### 5.2 Outbound (who consumes this module)

| Consumer | Usage |
| --- | --- |
| Compiler — `AwaitExpression` visitor | Emits `$.save(...)` / `$.track_reactivity_loss(...)` |
| Compiler — `ForOfStatement` visitor | Emits `$.for_await_track_reactivity_loss(...)` for `for await` in dev |
| `dom/blocks/async.js → async()` | Uses `flatten` + `get_pending_boundary` for async template blocks |
| Async component bodies (generated `class`/instance init) | Call `async_body` around top-level awaits |

---

## 6. Error-Handling Semantics

Async code introduces a fundamental hazard: by the time a promise settles, its originating effect may be destroyed (component unmounted, branch torn down, HMR replaced). The module enforces a consistent policy:

```mermaid
flowchart TD
    ERR["Async error originates<br/>(flatten callback, async_body, async_derived)"] --> Q{"Originating effect<br/>DESTROYED / aborted?"}
    Q -- "yes" --> SW["Swallow silently"]
    Q -- "no" --> IB["invoke_error_boundary(error, effect)"]
    IB --> W{"Ancestor with<br/>BOUNDARY_EFFECT flag?"}
    W -- "yes" --> BE["Boundary.error(error)<br/>→ onerror / failed snippet,<br/>re-throw if in fallback creation"]
    W -- "no" --> RT["Apply adjustments (if Error) → re-throw to host"]
```

Additionally, promise-level rejections inside `flatten` bypass the effect-tree walk and are delivered straight to the resolved pending boundary (`boundary.error`), matching where the values were being rendered. Using `await` (or `async_derived`) *outside* any boundary that can go pending raises the `await_outside_boundary` compile-time-aware runtime error via `get_pending_boundary`.

---

## 7. Design Notes

- **Snapshot/restore idiom.** All asynchrony funnels through `capture()`; this keeps a single, auditable definition of "what ambient state matters across await" (effect, reaction, component context, batch). New ambient state must be added there once.
- **Dev/prod parity.** `save`, `flatten` and `async_body` run identically in production; `track_reactivity_loss` / `for_await_track_reactivity_loss` are emitted only in dev builds (`esm-env` `DEV`), keeping production output lean and tree-shakeable (see the repo's `check-treeshakeability` tooling in [Repository Engineering Infrastructure](Repository_Engineering_Infrastructure_(Benchmarks,_Build_Scripts___Playground).md)).
- **Boundary-first suspension.** Suspension always targets the *nearest boundary that can actually display pending UI* (`has_pending_snippet`), walking up the boundary chain; nested async work therefore aggregates into the outermost visible pending state.
- **Separation from `{#await}`.** `await_block` (branch switching on promise state) and async-mode awaits (inline, context-preserving) are deliberately distinct subsystems; both ultimately render through the same batch/flush machinery.
- **Flat batching integration.** `async_derived` and `suspend` use `batch.increment/decrement` + `activate/deactivate` so multiple in-flight promises within one flush coalesce into a single commit — see [client_runtime_core_batching](client_runtime_core_batching.md) for the batch lifecycle.

## 8. Related Modules

- [client_runtime_core](client_runtime_core.md) — parent: signal model, effects, runtime entry points
- [client_runtime_core_signal_model](client_runtime_core_signal_model.md) · [client_runtime_core_sources](client_runtime_core_sources.md) · [client_runtime_core_deriveds](client_runtime_core_deriveds.md) — signals and deriveds consumed by `flatten`
- [client_runtime_core_batching](client_runtime_core_batching.md) — `suspend`, `current_batch`, activation protocol
- [client_runtime_core_effects](client_runtime_core_effects.md) — `block`, `aborted`, effect lifecycle
- [client_runtime_core_diagnostics](client_runtime_core_diagnostics.md) — `await_reactivity_loss`, `await_outside_boundary` and related warnings/errors
- [client_dom_renderer](client_dom_renderer.md) — `async` block, `Boundary`, `await_block`
- [client_dev_mode](client_dev_mode.md) — dev-mode warning and tracing integration
- [compiler_client_transform_components_and_scripts](compiler_client_transform_components_and_scripts.md) — the visitors that generate calls into this module
- [shared_runtime](shared_runtime.md) — `enable_async_mode_flag` and cross-runtime flags
