# Compiler Types (`compiler_types`)

## 1. Introduction & Purpose

The `compiler_types` module is the **type contract layer** of the Svelte compiler. It contains the package's core TypeScript declaration files (`.d.ts`) that define:

- **The AST node shapes** that the [compiler parser](compiler_parser.md) produces, the [analyzer](compiler_analyzer.md) enriches, and the [client/server code generators](compiler_client_transform.md) consume.
- **The CSS AST shapes** used by the [CSS scoping & pruning pipeline](compiler_css_pipeline.md).
- **The legacy (Svelte 4) AST shapes** consumed by the [migration tooling](compiler_migrate.md) and preserved for backward compatibility.
- **The public compiler API contracts** — `compile()`/`compileModule()` options, results, warnings, and errors — that the [core orchestration module](compiler_core.md) implements and that external tooling (bundler plugins, language tools) depends on.

Unlike the other compiler modules, this module contains **no executable code**. Its value is that it fixes the vocabulary of the entire pipeline: every phase communicates by passing these typed structures. Consequently, it sits at the *bottom* of the compiler's dependency graph — everything else depends on it, while it depends only on `estree` (the standard JS AST types) and a handful of internal analysis types (`Binding`, `Scope`, `ICompileDiagnostic`).

> **In one sentence:** this module is the shared language between the Svelte front-end (parsing/analysis) and back-end (code generation), and the public interface Svelte exposes to its consumers.

### Files in this module

| File | Exports | Role |
|---|---|---|
| `packages/svelte/src/compiler/types/template.d.ts` | `namespace AST`, `Namespace`, `DelegatedEvent` | The modern (Svelte 5) template AST + `estree` augmentation |
| `packages/svelte/src/compiler/types/css.d.ts` | `namespace _CSS` | The CSS AST (style sheet → rule → selector → simple selector) |
| `packages/svelte/src/compiler/types/legacy-nodes.d.ts` | `Legacy*` interfaces, `SnippetBlock`, `RenderTag` | The Svelte 4 AST, used by `svelte.migrate` and legacy tooling |
| `packages/svelte/src/compiler/types/index.d.ts` | `CompileResult`, `CompileOptions`, `ModuleCompileOptions`, `Warning`, `CompileError`, `BindingKind`, `DeclarationKind`, `ExpressionMetadata`, `StateField` | Public compiler API contracts + re-exports of `AST`, `Binding`, `Scope` |

---

## 2. Architecture Overview

### 2.1 Module composition

The four declaration files are organized around **namespaces**, which the compiler treats as distinct vocabularies. `index.d.ts` acts as the barrel file that stitches them together.

```mermaid
flowchart TB
    subgraph types["compiler/types"]
        index["index.d.ts<br/>CompileResult · CompileOptions<br/>Warning · CompileError<br/>BindingKind · ExpressionMetadata"]
        template["template.d.ts<br/>namespace AST<br/>(modern template AST)"]
        css["css.d.ts<br/>namespace _CSS<br/>(CSS AST)"]
        legacy["legacy-nodes.d.ts<br/>Legacy* interfaces<br/>(Svelte 4 AST)"]
    end

    index -- "re-exports AST.*, Binding, Scope" --> template
    template -- "type { _CSS as CSS }" --> css
    legacy -- "AST.Text · AST.CSS · AST.ExpressionTag" --> template
    template -- "Binding, ExpressionMetadata, Scope<br/>(phases/scope.js)" --> scope["phases/scope.js<br/>Binding · Scope"]
    index -- "ICompileDiagnostic" --> diag["utils/compile_diagnostic.js<br/>CompileDiagnostic"]
    index -- "StateCreationRuneName" --> utils["src/utils.js"]

    style types fill:#eef6ff,stroke:#4a90d9
```

### 2.2 Position in the compiler pipeline

The types defined here are the *currency* traded between compiler phases. The parser produces them, the analyzer decorates them, and the transformers consume them:

```mermaid
flowchart LR
    SRC["`.svelte` source"] --> P["**1-parse**<br/>compiler_parser"]
    P -- "AST.Root / AST.Fragment<br/>(template.d.ts)<br/>_CSS.StyleSheet (css.d.ts)" --> A["**2-analyze**<br/>compiler_analyzer"]
    A -- "populates @internal metadata,<br/>Binding/Scope graph" --> T["**3-transform**<br/>client / server / css"]
    T -- "CompileResult<br/>(index.d.ts)" --> OUT["js + css + warnings"]
    A -- "diagnostics" --> D["errors / warnings<br/>compiler_diagnostics"]
    SRC -.-> M["svelte.migrate<br/>compiler_migrate"]
    M -- "Legacy* nodes<br/>(legacy-nodes.d.ts)" --> OUT

    style P fill:#f3f9ff,stroke:#4a90d9
    style A fill:#f3f9ff,stroke:#4a90d9
    style T fill:#f3f9ff,stroke:#4a90d9
```

Phase responsibilities w.r.t. these types:

1. **Parse** (`1-parse`) instantiates `AST.Root`, `AST.Fragment` and node interfaces from `template.d.ts`, plus a `_CSS.StyleSheet` from `css.d.ts`. `AST.SvelteOptionsRaw` is an *intermediate-only* node ("doesn't exist in the final AST") that parsing normalizes into `Root.options: SvelteOptions`.
2. **Analyze** (`2-analyze`) fills every `/** @internal */ metadata` block: `ExpressionMetadata` on expressions, `Binding` maps on `EachBlock`, snippet sets on `RenderTag`/`SnippetBlock` (used for CSS pruning), scoping flags on elements, and global-selector flags on `_CSS.Rule`/`RelativeSelector`.
3. **Transform** (`3-transform`, see [compiler_client_transform](compiler_client_transform.md) and [compiler_server_transform](compiler_server_transform.md)) reads the metadata and emits JS. The final result is packaged as `CompileResult` from `index.d.ts` by [compiler_core](compiler_core.md)'s `compile`/`compileModule` entry points.
4. **Migrate** (`svelte.migrate`, see [compiler_migrate](compiler_migrate.md)) is the only consumer of `legacy-nodes.d.ts`: Svelte 4 components parse into `LegacyRoot`, get rewritten, and are re-serialized.

### 2.3 Cross-cutting design conventions

Every AST interface in this module follows the same conventions — knowing them makes all four files readable:

- **Discriminated by `type`**: every node has a literal `type` string (`'RegularElement'`, `'Rule'`, `'ClassSelector'`…), which drives the visitor dispatch in the analyzer and transformers.
- **Source positions**: `start`/`end` character offsets on every node (and `loc` on `JSComment`), enabling warnings/errors to print code frames.
- **`/** @internal */ metadata`**: author-facing properties are plain; compiler-computed data is quarantined under a `metadata` sub-object. This cleanly separates *what the user wrote* from *what the compiler knows*.
- **Interfaces, not classes**: AST nodes are plain data, safe to serialize (`CompileResult.ast`), clone, and hand to `estree`-compatible tooling (prettier-plugin-svelte, svelte2tsx).
- **Union taxonomies**: the AST namespace exports curated unions — `Tag`, `Block`, `ElementLike`, `Directive`, `AttributeLike`, `TemplateNode`, and the umbrella `SvelteNode` — which the shared tree-walker traverses.

---

## 3. Sub-module Documentation

The module splits naturally along its four declaration files. Detailed documentation lives in these companion files (all saved alongside this document):

| Sub-module documentation | Source file | Contents |
|---|---|---|
| [compiler_types_template_ast.md](compiler_types_template_ast.md) | `types/template.d.ts` | `namespace AST` — modern template AST |
| [compiler_types_css_ast.md](compiler_types_css_ast.md) | `types/css.d.ts` | `namespace _CSS` — CSS AST |
| [compiler_types_legacy_ast.md](compiler_types_legacy_ast.md) | `types/legacy-nodes.d.ts` | Svelte 4 `Legacy*` AST |
| [compiler_types_compiler_api.md](compiler_types_compiler_api.md) | `types/index.d.ts` | `CompileResult`, options, diagnostics contracts |

### 3.1 Template AST — [compiler_types_template_ast.md](compiler_types_template_ast.md)
The `namespace AST` in `template.d.ts`: the single most important data structure in the compiler. Covers `Root`/`Fragment`, `Text`/`ExpressionTag`, all `ElementLike` components (`RegularElement`, `Component`, `SvelteWindow`, …), all `Directive`s (`bind:`, `on:`, `class:`, `transition:`, …), all `Block`s (`{#if}`, `{#each}`, `{#await}`, `{#key}`, `{#snippet}`), all `Tag`s (`{@const}`, `{@html}`, `{@render}`, `{@attach}`, …), attributes, `Script`, and the `estree` module augmentation that attaches `start`/`end` to JS nodes. Also explains the union taxonomies and the `metadata` fields each phase relies on.

### 3.2 CSS AST — `compiler_types_css_ast.md`
The `namespace _CSS` in `css.d.ts`: the parse tree of `<style>` content. Covers `StyleSheet` → `Rule`/`Atrule` → `SelectorList` → `ComplexSelector` → `RelativeSelector` → `SimpleSelector`, declarations/blocks, and the `@internal metadata` flags (`is_global`, `is_global_block`, `scoped`, `used`) that drive scoping and pruning in the [CSS pipeline](compiler_css_pipeline.md). Exposed to consumers as `AST.CSS` (via `type { _CSS as CSS }`).

### 3.3 Legacy Svelte 4 AST — `compiler_types_legacy_ast.md`
`legacy-nodes.d.ts`: the pre-Svelte-5 node vocabulary (`LegacyElement`, `LegacyInlineComponent`, `LegacyMustacheTag`, `LegacyEventHandler`, …). Documents the `LegacyAttributeLike`/`LegacyElementLike`/`LegacyDirective` unions, the modern nodes deliberately kept here (`SnippetBlock`, `RenderTag`), and how this vocabulary interops with `AST.*` during migration.

### 3.4 Compiler API Contracts — `compiler_types_compiler_api.md`
`index.d.ts`: the compiler's *external* face. Covers `CompileResult` (js/css/warnings/metadata/ast), the option surfaces `CompileOptions` & `ModuleCompileOptions` (plus their post-validation `Validated*` counterparts consumed internally), `Warning`/`CompileError` extending `ICompileDiagnostic` from [compiler_diagnostics](compiler_diagnostics.md), the binding taxonomy (`BindingKind`, `DeclarationKind`), `ExpressionMetadata` (the reactivity ledger attached to expressions), and `StateField` (rune-created class fields).

---

## 4. Type Hierarchies at a Glance

### 4.1 Template AST taxonomy (`AST` namespace)

```mermaid
flowchart TD
    SvelteNode["AST.SvelteNode<br/>(everything the walker may visit)"] --> Node["estree Node<br/>(JS expressions/stmts)"]
    SvelteNode --> TemplateNode["AST.TemplateNode"]
    SvelteNode --> Frag["AST.Fragment"]
    SvelteNode --> CSSN["_CSS.Node (as AST.CSS.Node)"]
    SvelteNode --> ScriptN["AST.Script"]

    TemplateNode --> Root["AST.Root"]
    TemplateNode --> Text["AST.Text"]
    TemplateNode --> Comment["AST.Comment"]
    TemplateNode --> Attr["AST.Attribute /<br/>AST.SpreadAttribute"]
    TemplateNode --> TagU["Tag"]
    TemplateNode --> ElemU["ElementLike"]
    TemplateNode --> DirU["Directive"]
    TemplateNode --> BlockU["Block"]

    TagU --> ExpressionTag["ExpressionTag"]
    TagU --> HtmlTag["HtmlTag"]
    TagU --> ConstTag["ConstTag"]
    TagU --> DebugTag["DebugTag"]
    TagU --> RenderTag["RenderTag"]
    TagU --> AttachTag["AttachTag"]

    BlockU --> EachBlock["EachBlock"]
    BlockU --> IfBlock["IfBlock"]
    BlockU --> AwaitBlock["AwaitBlock"]
    BlockU --> KeyBlock["KeyBlock"]
    BlockU --> SnippetBlock["SnippetBlock"]

    ElemU --> RegularElement["RegularElement"]
    ElemU --> Component["Component / SvelteComponent /<br/>SvelteSelf"]
    ElemU --> Special["SvelteElement · SvelteFragment ·<br/>SvelteBoundary · SvelteHead ·<br/>SvelteBody · SvelteWindow ·<br/>SvelteDocument · SlotElement ·<br/>TitleElement · SvelteOptionsRaw"]

    DirU --> Bind["BindDirective"]
    DirU --> On["OnDirective"]
    DirU --> Class["ClassDirective"]
    DirU --> Style["StyleDirective"]
    DirU --> Trans["TransitionDirective"]
    DirU --> Other["UseDirective · AnimateDirective ·<br/>LetDirective"]
```

### 4.2 CSS AST taxonomy (`_CSS` namespace)

```mermaid
flowchart TD
    SS["_CSS.StyleSheet"] --> Rule["_CSS.Rule"]
    SS --> Atrule["_CSS.Atrule"]
    Rule --> SL["_CSS.SelectorList"]
    Rule --> Block["_CSS.Block"]
    Atrule --> Block2["_CSS.Block | null"]
    SL --> CS["_CSS.ComplexSelector"]
    CS --> RS["_CSS.RelativeSelector"]
    RS --> Comb["_CSS.Combinator (optional)"]
    RS --> Sim["_CSS.SimpleSelector"]
    Sim --> TS["TypeSelector"]
    Sim --> IDS["IdSelector"]
    Sim --> CLS["ClassSelector"]
    Sim --> ATTR["AttributeSelector"]
    Sim --> PSE["PseudoElementSelector"]
    Sim --> PSC["PseudoClassSelector<br/>(args: SelectorList|null)"]
    Sim --> PCT["Percentage"]
    Sim --> NTH["Nth"]
    Sim --> NES["NestingSelector (&)"]
    Block --> Dec["_CSS.Declaration"]
    Block --> Nested["Rule | Atrule (CSS nesting)"]
```

### 4.3 Diagnostic & result contracts

```mermaid
classDiagram
    class ICompileDiagnostic {
        <<from utils/compile_diagnostic.js>>
        +code: string
        +message: string
        +start? +end? +position?
        +filename? +frame?
    }
    class Warning {
        <<extends ICompileDiagnostic>>
    }
    class CompileError {
        <<extends ICompileDiagnostic>>
    }
    class CompileResult {
        +js: {code, map}
        +css: null | {code, map, hasGlobal}
        +warnings: Warning[]
        +metadata: {runes: boolean}
        +ast: any
    }
    class CompileOptions {
        +name? +customElement? +css? +runes?
        +fragments? +hmr? +modernAst? ...
    }
    class ModuleCompileOptions {
        +dev? +generate? +filename?
        +warningFilter? +experimental?
    }
    class BindingKind {
        <<union>>
        normal | prop | bindable_prop | rest_prop
        raw_state | state | derived | each
        snippet | store_sub | legacy_reactive
        template | static
    }
    class ExpressionMetadata {
        +dependencies: Set~Binding~
        +references: Set~Binding~
        +has_state +has_call +has_await
        +has_member_expression +has_assignment
    }
    ModuleCompileOptions <|-- CompileOptions : extends
    ICompileDiagnostic <|-- Warning
    ICompileDiagnostic <|-- CompileError
    CompileResult --> Warning : warnings[]
    CompileOptions --> Warning : warningFilter()
    ExpressionMetadata --> Binding : Set<Binding>
```

---

## 5. Key Interaction Patterns

### 5.1 The `@internal metadata` protocol

The most important architectural pattern in this module: analysis results never overwrite the author's AST — they are *attached* under `metadata`. For example:

| Node | Metadata | Producer → Consumer |
|---|---|---|
| `ExpressionTag`, `HtmlTag`, directives, blocks | `expression: ExpressionMetadata` | [analyzer](compiler_analyzer.md) → [client/server transforms](compiler_client_transform.md) |
| `Root` | `ts: boolean` | parser (acorn-typescript) → transformers |
| `Fragment` | `transparent`, `dynamic`, `has_await` | analyzer → [template builder](compiler_client_transform_templates.md) |
| `EachBlock` | `is_controlled`, `declarations`, `transitive_deps`, `keyed` | analyzer → [each-block client codegen](compiler_client_transform_control_flow_blocks.md) |
| `RegularElement` / `SvelteElement` | `svg`, `mathml`, `scoped`, `path` | analyzer → element codegen |
| `SnippetBlock` / `RenderTag` | `sites` / `snippets` (mutual sets) | analyzer → **CSS pruning** (drop unused snippets) |
| `_CSS.Rule` / `RelativeSelector` | `is_global`, `is_global_block`, `scoped`, `used` | [css-analyze](compiler_css_pipeline_analysis.md) → [css-prune/transform](compiler_css_pipeline_transform.md) |

### 5.2 Two-way snippet bookkeeping

`SnippetBlock.metadata.sites` and `Component/RenderTag.metadata.snippets` reference *each other*. This inverted index lets the CSS pipeline answer "can this `<style>` rule ever match a snippet's contents?" without re-walking the tree — a snapshot of how tightly the type layer couples analysis phases that otherwise never meet.

### 5.3 `estree` module augmentation

`template.d.ts` declares `declare module 'estree' { interface BaseNode { start?, end?, typeAnnotation? } }`, so *every* JS node parsed by acorn/acorn-typescript carries source positions (and TS annotations) throughout the pipeline. This is why the transformers can point sourcemaps and diagnostics at JS locations too.

### 5.4 Barrel re-exports in `index.d.ts`

```ts
export * from './template.js';                    // AST namespace
export { Binding, Scope } from '../phases/scope.js';
export { ReactiveStatement } from '../phases/types.js';
```

Internal phases import everything from `#compiler` (which maps to `index.d.ts`), making `index.d.ts` the single import surface and the compatibility seam: consumers compiled against `packages/svelte/types/index.d.ts` (the public types package — see [public_api](public_api.md) / [svelte-types](svelte-types.md)) get stable aliases (`Root`, `IfBlock`, `AttributeSelector`, `CompileResult`, …) while internal shapes may evolve.

---

## 6. Dependencies & Related Modules

**Depends on (types only):**

- `estree` — standard JavaScript AST types (also *augmented* by this module)
- `magic-string` — `SourceMap` type used in `CompileResult`
- [`phases/scope.js`](compiler_analyzer_scope.md) — `Binding`, `Scope` (re-exported; referenced in `ExpressionMetadata`)
- [`utils/compile_diagnostic.js`](compiler_diagnostics_diagnostic_model.md) — `ICompileDiagnostic`, base of `Warning`/`CompileError`
- `phases/types.js` — `ReactiveStatement` (re-exported)

**Depended on by (conceptually, via `#compiler`):**

| Consumer module | Types consumed |
|---|---|
| [compiler_parser](compiler_parser.md) | constructs `AST.*` nodes, `_CSS.StyleSheet` |
| [compiler_analyzer](compiler_analyzer.md) | reads/creates `metadata`, `ExpressionMetadata`; produces `Binding`/`Scope` |
| [compiler_client_transform](compiler_client_transform.md) / [compiler_server_transform](compiler_server_transform.md) | consumes full AST + metadata; emits `CompileResult` |
| [compiler_css_pipeline](compiler_css_pipeline.md) | `_CSS.*` nodes and their metadata flags |
| [compiler_diagnostics](compiler_diagnostics.md) | `Warning`/`CompileError` shape, positions for code frames |
| [compiler_migrate](compiler_migrate.md) | `Legacy*` AST |
| [compiler_core](compiler_core.md) | validates `CompileOptions` → `ValidatedCompileOptions`; returns `CompileResult` |
| [public_api](public_api.md) / [svelte-types](svelte-types.md) | public re-exports of the AST & result types |

---

## 7. Maintenance Notes

- **Adding a template node type?** Update `template.d.ts` *and* the relevant union (`ElementLike`, `Tag`, `Block`, `Directive`, `TemplateNode`, `SvelteNode`); parser, analyzer visitors, and both transformer visitor maps must handle the new `type`.
- **Adding a compile option?** Declare it in `CompileOptions`/`ModuleCompileOptions` (with `@default`/`@since` JSDoc), mirror it in the `Validated*` types if required-after-validation, and implement validation in [compiler_core_options](compiler_core_options.md) (`validate-options.js`).
- **Breaking-change hygiene:** anything reachable from `packages/svelte/types/index.d.ts` is public API — treat changes there as semver-relevant. `@internal metadata` fields are exempt.
- **`modernAst` option:** by default `CompileResult.ast` is still serialized in the legacy node vocabulary (`legacy-nodes.d.ts`) for Svelte-4-era tooling; `compile(source, { modernAst: true })` returns the true `AST.Root` from `template.d.ts`. Svelte 6 flips the default — keep both vocabularies compiling until then.

---

*Next reading: start with [compiler_types_template_ast.md](compiler_types_template_ast.md) (the core AST), then [compiler_types_css_ast.md](compiler_types_css_ast.md), [compiler_types_legacy_ast.md](compiler_types_legacy_ast.md), and [compiler_types_compiler_api.md](compiler_types_compiler_api.md).*
