# compiler_parser_template_state_machine

> **Module path:** `packages/svelte/src/compiler/phases/1-parse/` (state sub-system)
> **Parent module:** [compiler_parser](compiler_parser.md)
> **Sibling modules:** [compiler_parser_js_ts_processing](compiler_parser_js_ts_processing.md), [compiler_parser_parse_utilities](compiler_parser_parse_utilities.md)

## 1. Introduction

`compiler_parser_template_state_machine` implements the **core tokenizing/parsing loop of the Svelte template parser**. Rather than using a separate lexer, the parser is built as an explicit **recursive state machine**: a single `Parser` instance repeatedly invokes *state functions* that consume characters from the template source and return the next state to transition into.

The module turns a raw `.svelte` template string into the root of the compiler's AST (`AST.Root`), producing:

- A **template fragment tree** (`Fragment` nodes: elements, components, meta tags, text, comments, expression tags)
- Extracted **top-level `<script>`** contents (module/instance) via the JS/TS sub-parser
- Extracted **top-level `<style>`** contents (CSS source)
- Root-level **`<svelte:options>`** configuration

This module is the first phase of the compiler pipeline (`1-parse`); its output is consumed directly by the analyzer phase — see [compiler_analyzer](compiler_analyzer.md).

### Core Components

| Component | Location | Role |
|---|---|---|
| `Parser` (class) | `phases/1-parse/index.js` | Parser engine: cursor, stack, fragments, reading primitives |
| `parse()` | `phases/1-parse/index.js` | Public entry point: `string → AST.Root` |
| `fragment` | `phases/1-parse/state/fragment.js` | Dispatcher state: routes to element/tag/text |
| `element` | `phases/1-parse/state/element.js` | Parses tags, comments, attributes, special content |
| `read_attribute` | `phases/1-parse/state/element.js` | Parses dynamic attributes, directives, spreads, attachments |
| `read_static_attribute` | `phases/1-parse/state/element.js` | Parses static-only attributes (top-level `<script>`/`<style>`) |
| `text` | `phases/1-parse/state/text.js` | Consumes raw text and decodes HTML entities |

---

## 2. Position in the Compiler Pipeline

```mermaid
flowchart LR
    A[.svelte source string] --> B[parse<br/>set_source + new Parser]
    B --> C{{Template State Machine<br/>THIS MODULE}}
    C --> D[AST.Root]
    D --> E[2-analyze<br/>compiler_analyzer]
    D --> F[3-transform<br/>client / server back-ends]

    subgraph parser_module [compiler_parser]
        direction TB
        C
        G[JS/TS processing<br/>acorn.js parse]
        H[Parse utilities<br/>options / entities / fuzzymatch]
    end

    C -.->|"read_script / read_style"| G
    C -.->|"decode_character_references<br/>read_options"| H
    C -.->|"e.\* compile errors<br/>w.\* warnings"| I[compiler_diagnostics]
    C -.->|"AST node types"| J[compiler_types]

    style C fill:#2d6a4f,color:#fff
```

The parser never consumes raw source itself for JavaScript — expressions and `<script>` bodies are delegated to **acorn** through the sibling module [compiler_parser_js_ts_processing](compiler_parser_js_ts_processing.md). Generic helpers (HTML entity decoding via `get_entity_pattern`, `<svelte:options>` validation, fuzzy name suggestions via `sort_descending`) come from [compiler_parser_parse_utilities](compiler_parser_parse_utilities.md).

---

## 3. Architecture

The module has two cooperating halves:

1. **The `Parser` engine** — holds the reading cursor (`index`), the open-node `stack`, the active `fragments` stack, the `root` AST node, and a toolbox of cursor primitives (`eat`, `match`, `read`, `read_until`, `read_identifier`, `allow_whitespace`, `append`, `pop`).
2. **State functions** — pure-ish functions typed as `ParserState = (parser: Parser) => ParserState | void`. Each consumes one syntactic unit and returns the next state; returning `undefined` falls back to `fragment`.

```mermaid
flowchart TB
    subgraph ParserEngine["Parser engine (index.js)"]
        TPL["template : string<br/>(trimmed end)"]
        IDX["index : number"]
        TS["ts : boolean<br/>(detected from lang attr)"]
        LOOSE["loose : boolean<br/>(error-tolerant mode)"]
        STACK["stack : TemplateNode[]<br/>(open elements)"]
        FRAGS["fragments : Fragment[]<br/>(active insertion points)"]
        ROOT["root : AST.Root"]
        PRIM["Cursor primitives<br/>eat · match · match_regex<br/>read · read_until · read_identifier<br/>allow_whitespace · require_whitespace<br/>append · pop · current"]
    end

    subgraph States["State functions (ParserState)"]
        FRAG["fragment()<br/>dispatcher"]
        ELEM["element()<br/>tags & attributes"]
        TAG["tag()<br/>{expressions} &amp; {#blocks}<br/>(state/tag.js)"]
        TEXT["text()<br/>raw text + entities"]
    end

    FRAG -- "'<'" --> ELEM
    FRAG -- "'{'" --> TAG
    FRAG -- "default" --> TEXT
    ELEM --> FRAG
    TAG --> FRAG
    TEXT --> FRAG

    LOOP["while (index &lt; template.length)<br/>state = state(parser) || fragment"]

    States -.-> PRIM
    LOOP --> States
    States -->|"append(node)"| FRAGS
    STACK <-->|"push / pop"| ELEM
```

> **Note:** `tag` lives in `state/tag.js` and is owned by the parent [compiler_parser](compiler_parser.md) module, but it is an integral state of this machine and is documented here for transition completeness.

---

## 4. The State Machine

### 4.1 State diagram

```mermaid
stateDiagram-v2
    direction TB
    [*] --> fragment : Parser constructor seeds root

    fragment --> element : next char is a tag-open angle bracket
    fragment --> tag : next char is an open brace
    fragment --> text : otherwise

    text --> fragment : consumed text up to tag or brace

    state element_state as "element()" {
        [*] --> peek
        peek --> comment : HTML comment marker
        peek --> closing : closing tag
        peek --> opening : opening tag name

        opening --> metaTag : svelte meta tag
        opening --> component : uppercase or dotted name
        opening --> regularElement : otherwise

        opening --> readAttrs : read_attribute loop
        readAttrs --> specialContent : root-level script or style
        readAttrs --> finished : void, self-closing or loose EOF
        specialContent --> finished
        regularElement --> finished : pushed onto stack,
        finished --> appendNode
        metaTag --> appendNode
        component --> appendNode
        appendNode --> [*] : children parse as fragment

        closing --> [*] : implicit closes, then pop
        comment --> [*]
    }

    state tag_state as "tag()" {
        [*] --> braceBody
        braceBody --> blockOpen : block open rune
        braceBody --> blockClose : block continue rune
        braceBody --> blockSpecial : special tag rune
        braceBody --> expressionTag : plain expression
    }

    element_state --> fragment
    tag_state --> fragment

    note right of fragment
        driver loop
        state = state(parser) fallback fragment
    end note
```

### 4.2 The driver loop

```js
/** @typedef {(parser: Parser) => ParserState | void} ParserState */

let state = fragment;

while (this.index < this.template.length) {
    state = state(this) || fragment;
}
```

Key properties of this design:

- **Flat cursor, no token stream.** States read directly from `parser.template` using anchored regexes and single-character lookahead — extremely cheap for the common HTML case.
- **Two parallel stacks.** `parser.stack` tracks *open nodes* (for closing-tag matching and implicit close logic), while `parser.fragments` tracks the *current insertion point* (each element owns its own child `Fragment`). They are pushed/popped in lockstep for elements.
- **Self-dispatching.** A state function consumes input and returns the next state; the loop only enforces fallback to `fragment` and termination at EOF.

---

## 5. Component Reference

### 5.1 `parse(template, loose)` — entry point

```js
export function parse(template, loose = false) {
    state.set_source(template);      // registers source + getLocator for error positions
    const parser = new Parser(template, loose);
    return parser.root;
}
```

1. `set_source` (from `compiler_core`'s `state.js`) stores the raw source so diagnostics can compute `(line, column)` from offsets via `getLocator`.
2. Constructs the `Parser`; **all parsing happens in the constructor**.
3. Returns the finished `AST.Root`.

### 5.2 `Parser` constructor — setup & invariants

| Step | Behavior |
|---|---|
| Input validation | Throws `TypeError` for non-string input |
| `loose` mode | Stored on the instance; controls error-tolerance & backtracking (§8) |
| TS detection | `regex_lang_attribute` scans for `<script lang="ts">` → sets `parser.ts`, mirrored in `root.metadata.ts` |
| Root creation | `AST.Root` with empty `fragment`, `js: []`, `css: null`, `options: null`, `comments: []` |
| Stack seeding | `stack = [root]`, `fragments = [root.fragment]`, initial state = `fragment` |
| EOF checks | If `stack.length > 1` → `element_unclosed` / `block_unclosed` (or truncation in loose mode). If final `state !== fragment` → `unexpected_eof` |
| Root bounds | `root.start`/`root.end` trimmed to first/last non-whitespace character of the fragment |
| `svelte:options` hoisting | The `SvelteOptions` node is spliced out of the fragment, validated by `read_options` (sibling module), attached to `root.options`, and its raw node kept as non-enumerable `__raw__` |

### 5.3 `fragment` — the dispatcher

```js
export default function fragment(parser) {
    if (parser.match('<')) return element;
    if (parser.match('{')) return tag;
    return text;
}
```

One-character lookahead decides the branch. This is the *resting state* of the machine: every other state eventually returns here (directly or via the loop's `|| fragment` fallback).

### 5.4 `element` — tags, comments, attributes, special content

The largest state; its decision flow:

```mermaid
flowchart TD
    START["index consumed '<'"] --> IS_COMMENT{"eat('!--')?"}
    IS_COMMENT -- yes --> COMMENT["read_until('-->') → Comment node"]
    COMMENT --> RETURN

    IS_COMMENT -- no --> IS_CLOSE{"eat('/')? (closing tag)"}
    IS_CLOSE -- yes --> CLOSE["Walk up stack:<br/>implicitly close mismatched ancestors<br/>(warn element_implicitly_closed)<br/>match name → set parent.end, pop()"]
    CLOSE --> RETURN

    IS_CLOSE -- no --> NAME["read element/component name"]
    NAME --> CHECK{"name valid?<br/>(regex_valid_element_name /<br/>regex_valid_component_name)"}
    CHECK -- no --> ERR["tag_invalid_name<br/>(skipped for trailing '.' in loose mode)"]
    CHECK -- yes --> META{"svelte: meta tag?"}
    META -- root-only/dup/misplaced --> ERR2["svelte_meta_invalid_tag<br/>svelte_meta_duplicate<br/>svelte_meta_invalid_placement"]
    META -- ok --> TYPE

    TYPE{"Resolve node type"}
    TYPE --> T_META["SvelteHead · SvelteOptions · SvelteWindow<br/>SvelteDocument · SvelteBody · SvelteElement<br/>SvelteComponent · SvelteSelf · SvelteFragment<br/>SvelteBoundary"]
    TYPE --> T_COMP["Component (uppercase or dotted name)"]
    TYPE --> T_TITLE["TitleElement (title in svelte:head)"]
    TYPE --> T_SLOT["SlotElement (slot, not in shadow-root template)"]
    TYPE --> T_REG["RegularElement"]

    T_META & T_COMP & T_TITLE & T_SLOT & T_REG --> ATTRS["Loop: read_attribute(parser)<br/>→ duplicate checks (unique_names)"]
    ATTRS --> THISCHECK{"SvelteComponent /<br/>SvelteElement?"}
    THISCHECK -- yes --> EXTRACT["extract this=… expression<br/>→ element.expression / element.tag"]
    THISCHECK -- no --> TOPLEVEL
    EXTRACT --> TOPLEVEL

    TOPLEVEL{"top-level<br/><script>/<style>?"}
    TOPLEVEL -- yes --> STATIC["eat('>') · read_static_attribute loop<br/>read_script → root.js / read_style → root.css<br/>(attach preceding HTML comment for svelte-ignore)"]
    STATIC --> RETURN["return (next state = fragment)"]

    TOPLEVEL -- no --> APPEND["parser.append(element)"]
    APPEND --> SELFCLOSE{"eat('/') or void element?"}
    SELFCLOSE -- yes --> ENDNODE["element.end = index<br/>(NOT pushed on stack)"]
    SELFCLOSE -- no --> CLOSED{"eat('>')?"}
    CLOSED -- yes --> SPECIAL{"textarea /<br/>script / style?"}
    SPECIAL -- textarea --> TA["read_sequence until </textarea>"]
    SPECIAL -- script/style --> SS["raw read_until </name> as Text"]
    SPECIAL -- other --> PUSH["stack.push(element)<br/>fragments.push(element.fragment)"]
    CLOSED -- no --> LOOSE["loose-mode backtracking:<br/>rewind eaten '<{' / '{#…' fragments<br/>or absorb whitespace"]
    LOOSE --> ENDNODE
    TA & SS --> ENDNODE
    PUSH & ENDNODE --> RETURN
```

**Attribute parsing** (`read_attribute` vs `read_static_attribute`):

- **`read_static_attribute`** — used *only* for top-level `<script>`/`<style>` tags so their attributes (`lang`, `context`, `generics`, …) are kept as plain text values; expressions are intentionally **not** evaluated there. Entity decoding uses the pattern utilities from [compiler_parser_parse_utilities](compiler_parser_parse_utilities.md).
- **`read_attribute`** — the general grammar:
  - `{@attach …}` → `AttachTag`
  - `{...expr}` → `SpreadAttribute`
  - `{name}` → shorthand `Attribute` with an `ExpressionTag` value
  - `name="value"` / `name={expr}` / `name` → `Attribute` (value is `true` or a `Text`/`ExpressionTag` chunk array, built by the shared `read_sequence` helper)
  - `prefix:name|modifier` → directive nodes, dispatched by `get_directive_type`:
    `bind:` → `BindDirective`, `on:` → `OnDirective`, `class:` → `ClassDirective`, `style:` → `StyleDirective`, `use:` → `UseDirective`, `animate:` → `AnimateDirective`, `let:` → `LetDirective`, `in:`/`out:`/`transition:` → `TransitionDirective` (with `intro`/`outro` flags).

`read_sequence` interleaves raw `Text` chunks (entity-decoded) and `{ExpressionTag}` chunks, and rejects misplaced `{#block}` / `{@special}` syntax inside attributes with `block_invalid_placement` / `tag_invalid_placement`. It is reused for textarea content and attribute values.

### 5.5 `text` — raw text consumption

```js
while (parser.index < parser.template.length && !parser.match('<') && !parser.match('{')) {
    data += parser.template[parser.index++];
}
```

Accumulates characters until the next `<` or `{`, appends an `AST.Text` node with both `raw` and entity-decoded `data` (decoding via `get_entity_pattern`/`decode_character_references` from [compiler_parser_parse_utilities](compiler_parser_parse_utilities.md)). Returning `undefined` hands control back to `fragment`.

---

## 6. Data Flow

```mermaid
flowchart LR
    SRC["template string"] --> SM["State machine<br/>fragment ⇄ element / tag / text"]
    SM -->|"append()"| FRAG["Fragment.nodes<br/>(RegularElement · Component · meta tags<br/>Text · Comment · ExpressionTag)"]
    SM -->|"read_script<br/>(root-level)"| JS["root.js / root.module<br/>(estree AST via acorn)"]
    SM -->|"read_style<br/>(root-level)"| CSS["root.css<br/>(CSS AST source)"]
    SM -->|"splice"| OPT["root.options<br/>(validated SvelteOptionsRaw)"]
    SM -->|"leading comment"| LC["svelte-ignore comments<br/>attached to script/style content"]

    FRAG & JS & CSS & OPT & LC --> ROOT["AST.Root<br/>start/end trimmed to content"]

    ROOT --> AN["2-analyze visitors<br/>(compiler_analyzer)"]
    ROOT --> TR["3-transform<br/>(compiler_client_transform /<br/>compiler_server_transform)"]

    style ROOT fill:#1d3557,color:#fff
```

The shape of the output AST is defined by [compiler_types](compiler_types.md) (`types/template.d.ts`: `Root`, `RegularElement`, `Component`, `Text`, `ExpressionTag`, directives, …). Node `metadata` objects (e.g. `RegularElement.metadata.svg/scoped/has_spread/path`, fragment `transparent/dynamic`) are initialized here but *populated* by later phases.

---

## 7. Interaction Flow (sequence)

```mermaid
sequenceDiagram
    participant API as compile pipeline
    participant P as parse()
    participant E as Parser engine
    participant F as fragment state
    participant El as element state
    participant Tx as text state
    participant JS as read_script (acorn)

    API->>P: parse("<p>{count}</p><script>…</script>")
    P->>P: set_source(template)
    P->>E: new Parser(template, loose)
    E->>F: state = fragment(parser)
    F-->>E: '<' → element
    E->>El: element(parser)
    El->>El: read name "p", type=RegularElement
    El->>El: append(p), push stack+fragment
    El-->>E: (children next)
    E->>Tx: text(parser)
    Tx-->>E: Text node appended → fragment
    E->>F: fragment(parser)
    F-->>E: '{' → tag → ExpressionTag(count)
    E->>El: element(parser)  // '</p>'
    El->>El: closing tag: pop, p.end=index
    El-->>E: fragment
    E->>El: element(parser)  // '<script>'
    El->>JS: read_script(parser, start, attrs)
    JS-->>El: script content (estree Program)
    El->>E: root.instance = content
    E->>E: EOF checks, root bounds, svelte:options hoist
    E-->>P: this.root
    P-->>API: AST.Root
```

---

## 8. Error Handling & Loose Parsing Mode

**Strict (default) mode** fails fast with precise compile errors produced through [compiler_diagnostics](compiler_diagnostics.md): `element_unclosed`, `block_unclosed`, `unexpected_eof`, `expected_token`, `expected_attribute_value`, `attribute_duplicate`, `directive_missing_name`, `svelte_meta_*`, `tag_invalid_name`, `void_element_invalid_content`, `element_invalid_closing_tag(_autoclosed)`, etc.

**`loose = true`** (used by language tooling such as the Svelte VS Code extension while a document is mid-typing) maximizes AST recovery:

- Unclosed trailing elements get `end = template.length` instead of raising `element_unclosed`; blocks likewise tolerate EOF.
- **Backtracking heuristics** in `element`:
  - An opening `<` mis-tokenized as an attribute name (`<div <p>`) is rewound when a later closing tag reveals the mistake.
  - A partially typed block (`{#i`) or closing (`{`) swallowed at the end of an attribute/tag is rewound (`index -= 1/2`).
  - `read_attribute` returns `null` instead of throwing when it detects `#`, `/`, `@`, `:` after `{` (i.e. a block in an unclosed tag) or an empty `{}` shorthand.
  - Incomplete names ending in `.` (e.g. `<div.`) are accepted as placeholder `Component` nodes.

**Implicit closing (both modes):** HTML's optional end tags are modeled with `closing_tag_omitted` (`html-tree-validation.js`): `<ul><li>a<li>b</ul>` auto-closes the first `<li>` and records `last_auto_closed_tag` so that later `</li>` closing tags are matched against the *right* ancestor (and only warn once via `element_implicitly_closed`).

**Special content rules:** `<textarea>` children are read verbatim until `</textarea>`; non-root `<script>`/`<style>` contents become a single raw `Text` node; only *root-level* `<script>`/`<style>` feed `read_script`/`read_style` (duplicates raise `script_duplicate`/`style_duplicate`). Preceding HTML comments are attached to root scripts/styles so `svelte-ignore` warnings can be honored later.

---

## 9. Module Dependencies

```mermaid
flowchart TB
    subgraph this [compiler_parser_template_state_machine]
        IDX[1-parse/index.js<br/>Parser · parse]
        FRAGST[1-parse/state/fragment.js]
        ELEMST[1-parse/state/element.js<br/>element · read_attribute ·<br/>read_static_attribute]
        TEXTST[1-parse/state/text.js]
    end

    IDX --> FRAGST & ELEMST & TEXTST
    ELEMST --> IDX

    IDX -->|"state.set_source<br/>getLocator"| CORE[compiler_core<br/>state.js · utils]
    ELEMST & TEXTST -->|"e.\* / w.\* diagnostics"| DIAG[compiler_diagnostics<br/>errors.js · warnings.js]
    IDX & ELEMST -->|"AST.Root · node shapes"| TYPES[compiler_types<br/>template.d.ts · index.d.ts]
    ELEMST & TEXTST -->|"decode_character_references<br/>get_entity_pattern"| UTILS[compiler_parser_parse_utilities]
    IDX -->|"read_options<br/>(svelte:options)"| UTILS
    ELEMST & IDX -->|"read_script · read_style<br/>acorn parse · remove_this_param"| JSPROC[compiler_parser_js_ts_processing]
    ELEMST -->|"closing_tag_omitted"| HTMLOPT["html-tree-validation.js<br/>(repo util)"]
    ELEMST & TEXTST & FRAGST -->|"create_fragment<br/>create_attribute"| NODES[compiler_parser<br/>utils/create.js · phases/nodes.js]
    ELEMST & TEXTST -->|"read_expression"| JSPROC

    TYPES -.->|consumed by| ANALYZER[compiler_analyzer]
    ANALYZER -.-> TRANSFORM["compiler_client_transform ·<br/>compiler_server_transform"]
```

### Upstream (inputs)

| Dependency | Provided by | Used for |
|---|---|---|
| `set_source` | [compiler_core](compiler_core.md) (`state.js`) | Global source registration for line/column error mapping |
| `errors` (`e.*`) / `warnings` (`w.*`) | [compiler_diagnostics](compiler_diagnostics.md) | All parse-time diagnostics (`block_unclosed`, `element_unclosed`, …) |
| AST type shapes | [compiler_types](compiler_types.md) | `AST.Root`, `Fragment`, `RegularElement`, directives, … |
| `read_expression`, `read_script`, `read_style` | [compiler_parser_js_ts_processing](compiler_parser_js_ts_processing.md) | `{…}` tags, root `<script>` (→ acorn estree AST), root `<style>` |
| `decode_character_references`, `get_entity_pattern`, `read_options`, `sort_descending` | [compiler_parser_parse_utilities](compiler_parser_parse_utilities.md) | Entity decoding, `<svelte:options>` parsing, error suggestions |

### Downstream (outputs)

| Consumer | Relationship |
|---|---|
| [compiler_analyzer](compiler_analyzer.md) | Walks the `Root` fragment; e.g. `AwaitBlock`, `ConstTag`, `SvelteFragment` visitors assume parser-produced node invariants; scope helpers (`set_scope`) attach analysis metadata |
| [compiler_client_transform](compiler_client_transform.md) / [compiler_server_transform](compiler_server_transform.md) | Transform visitors (e.g. `RegularElement`, `Fragment`) consume the same AST |
| [compiler_migrate](compiler_migrate.md) | Rewrites ASTs produced by this parser (Svelte 4 → 5 migration) |

---

## 10. Design Notes for Maintainers

1. **Everything happens in the constructor.** The `Parser` class is effectively a builder; `parse()` is a thin wrapper. Keep the loop's invariant (`state !== fragment` at EOF ⇒ `unexpected_eof`) intact when adding states.
2. **Adding a state** = create `state/*.js` exporting `(parser) => nextParserState | void`, import and dispatch it from `fragment` (or from a parent state). Prefer returning `undefined` to fall back to `fragment`.
3. **Loose mode is a first-class concern.** Any new early-return/error path should consider mid-typing scenarios; mirror the existing backtracking patterns rather than throwing when `parser.loose` is set.
4. **Offsets are byte-exact.** Nodes must record `start`/`end` relative to the *original* template (note the `trimEnd()` and whitespace trimming of `root.start/end`); diagnostics rely on `set_source` being called before parsing.
5. **Attribute grammar is load-bearing.** `read_sequence` is shared by attribute values and textarea content; changes affect both. Directive prefix recognition (`get_directive_type`) must stay in sync with the analyzer/transform visitors listed under [compiler_analyzer](compiler_analyzer.md).
6. **Script/style detection is regex-based** (`regex_lang_attribute`) and intentionally tolerant; TS flag propagation to `root.metadata.ts` drives downstream TypeScript stripping (`remove_this_param`, see [compiler_parser_js_ts_processing](compiler_parser_js_ts_processing.md)).
