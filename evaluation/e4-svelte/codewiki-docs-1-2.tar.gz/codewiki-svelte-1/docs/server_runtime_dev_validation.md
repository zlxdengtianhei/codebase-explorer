# Server Runtime Dev Validation

> **Module**: `server_runtime_dev_validation` — part of the `Component Rendering Backends (Client DOM & Server SSR)` → `server_runtime` subsystem
> **Source file**: `packages/svelte/src/internal/server/dev.js`

## 1. Introduction

The **server runtime dev validation** module is a development-mode-only instrumented safety net for Svelte's server-side rendering (SSR) pipeline. During a production build, SSR codegen emits nothing from this module — it is entirely tree-shaken away. In development, however, the server-side compiler backend injects calls into this module at two critical points:

1. **HTML content model validation** — as each element is opened during rendering, `push_element` verifies that the emitted tag is legal in its parent/ancestor context (e.g. a `<div>` inside a `<p>`, or a `<td>` outside a table row). Invalid placements are reported with source-mapped locations and also forwarded into the HTML payload so the error surfaces in the *browser console* as well, correlating server diagnostics with hydration warnings.
2. **Snippet invocation validation** — `validate_snippet_args` guards every compiled snippet function against being invoked outside the normal `{@render ...}` path (e.g. stringified or manually called with a bogus payload).

Because server rendering is a straight-line, side-effectful string-building process, the module relies on a small amount of **module-level mutable state** (an element stack and a message-deduplication set) plus a **save/restore protocol** (`reset_elements`) that the render entry point uses to isolate each render call.

## 2. Architecture Overview

The module sits between compiler-generated component code and the payload/output model. It *observes* the render walk without altering the HTML output (except for injecting the browser-side `console.error` shim).

```mermaid
flowchart TB
    subgraph Compiler["compiler_server_transform (dev mode only)"]
        RE["RegularElement visitor"]
        SB["SnippetBlock visitor"]
    end

    subgraph Module["server_runtime_dev_validation (dev.js)"]
        PE["push_element()"]
        POPE["pop_element()"]
        VSA["validate_snippet_args()"]
        RES["reset_elements()"]
        PRERR["print_error() (internal)"]

        subgraph State["Module-level state"]
            PARENT["parent : Element \| null<br/>(linked-list element stack)"]
            SEEN["seen : Set&lt;string&gt;<br/>(error dedup)"]
        end
    end

    subgraph TreeVal["HTML content model rules<br/>(html-tree-validation.js)"]
        PARENTCHK["is_tag_valid_with_parent()"]
        ANCCHK["is_tag_valid_with_ancestor()"]
    end

    subgraph Svc["Cross-runtime services"]
        CTX["server context.js<br/>current_component"]
        CONST["constants.js<br/>FILENAME symbol"]
        ERRS["errors.js<br/>invalid_snippet_arguments"]
        PAYLOAD["payload.js<br/>Payload / HeadPayload"]
    end

    RE -->|"$.push_element($$payload, tag, line, col)"| PE
    RE -->|"$.pop_element()"| POPE
    SB -->|"$.validate_snippet_args($$payload)"| VSA

    PE --> PARENTCHK
    PE --> ANCCHK
    PE --> PARENT
    PE --> PRERR
    POPE --> PARENT
    RES --> PARENT
    PRERR --> SEEN

    PE -->|"reads FILENAME"| CTX
    CTX --> CONST
    PE -->|"writes error script"| PAYLOAD
    PRERR --> PAYLOAD
    VSA --> ERRS
    VSA -->|"instanceof check"| PAYLOAD
```

### 2.1 Component responsibility matrix

| Export | Visibility | Responsibility | Emitted by |
|---|---|---|---|
| `push_element(payload, tag, line, column)` | dev-only call site | Push an opened element onto the validation stack; validate against parent and all ancestors; report violations | `RegularElement` server visitor |
| `pop_element()` | dev-only call site | Pop the stack when the element's closing tag is emitted | `RegularElement` server visitor |
| `validate_snippet_args(payload)` | dev-only call site | Assert the first argument of a snippet function is a real `Payload`/`HeadPayload`; throw `invalid_snippet_arguments` otherwise | `SnippetBlock` server visitor |
| `reset_elements()` | runtime-internal | Save/clear the stack; return a restore closure (used by `render()` for render isolation) | `server_runtime_rendering_core` |
| `print_error(payload, message)` | private | Dedupe + log violation, and mirror it into the head payload as an inline script | internal only |

## 3. Internal State Model

The module owns two pieces of module-scoped mutable state:

```mermaid
flowchart LR
    subgraph Stack["Element stack (linked list via .parent)"]
        direction TB
        A["Element<br/>tag: 'div'<br/>parent: null<br/>filename, line, column"]
        B["Element<br/>tag: 'p'<br/>parent: A"]
        C["Element<br/>tag: 'span'<br/>parent: B"]
        B --> A
        C --> B
        PARENTVAR["parent ➞ C<br/>(innermost open element)"]
    end

    SEENSET["seen : Set&lt;string&gt;<br/>one entry per unique violation message<br/>(prevents console spam across repeated renders)"]
```

**Element record shape** (typedef `Element`):

| Field | Type | Meaning |
|---|---|---|
| `tag` | `string` | HTML tag name as rendered |
| `parent` | `Element \| null` | Enclosing open element — forms the stack |
| `filename` | `string \| null` | Source `.svelte` file of the *component that rendered this element* |
| `line` / `column` | `number` | Location of the element in that file (computed at compile time) |

Filename attribution works because the server context pushes the component function onto `current_component` (`push(fn)` stores it as `current_component.function` in dev), and the compiler tags that function with the `FILENAME` symbol (`Symbol('filename')`) from the shared constants module.

## 4. Core Component Reference

### 4.1 `push_element(payload, tag, line, column)`

**When it runs**: Immediately after the opening tag markup has been pushed to `payload.out`, but *before* children are rendered (compiler emits it there in dev mode).

**Validation algorithm**:

1. Resolve the current component's source file via `current_component.function[FILENAME]`.
2. Build the child `Element` record; if a `parent` is open, validate:
   - **Direct-parent check**: `is_tag_valid_with_parent(tag, parent.tag, child_loc, parent_loc)` — catches illegal *direct* children, illegal *descendants* of known containers, and "only-children" rules (e.g. `<table>`).
   - **Ancestor walk**: climb `parent.parent`, `parent.parent.parent`, … calling `is_tag_valid_with_ancestor(tag, ancestors, …)` — catches forbidden-descendant rules such as interactive elements nested inside `<a>` or `<button>` (with `reset_by` semantics so custom elements or intermediate containers can reset the restriction).
3. On any violation, `print_error(payload, message)` reports it.
4. Push the child record as the new `parent`.

All validation messages are location-annotated (`file.svelte:line:column`) when filename information is available, which makes the diagnostics actionable directly from component source.

### 4.2 `pop_element()`

Pops the innermost element (`parent = parent.parent`), mirroring the closing tag emitted by codegen. The compiler only emits it for non-void elements, keeping the stack consistent with the actual markup stream.

### 4.3 `validate_snippet_args(payload)`

Inserted as the **first statement of every compiled snippet function** in dev mode. It checks that the `payload` argument is an instance of `Payload` or `HeadPayload` (the instanceof union works around `HeadPayload` being used for `{@render}` inside `<svelte:head>`). If not — e.g. a snippet was passed through an untyped channel, stringified, or invoked by hand — it throws the `invalid_snippet_arguments` error with a canonical docs URL.

> This is the server-side twin of `client_dev_mode_validation`'s `validate_snippet_args`; the same compiler visitor family emits both, per platform. See the client-side module docs for the hydration-side counterpart.

### 4.4 `reset_elements()` (internal but exported)

Returns a *dispose closure* that restores the previous stack. `render()` in the server rendering core wraps each component invocation:

```js
if (DEV) {
    reset_reset_element = reset_elements();
}
// ... component(payload, props, ...)
if (reset_reset_element) {
    reset_reset_element();
}
```

This guarantees that a component which throws mid-render (leaving an unbalanced `push_element`/`pop_element` sequence) cannot corrupt the stack for the *next* `render()` call on the same module instance — the server runtime is a long-lived process, so this isolation matters.

### 4.5 `print_error(payload, message)` (private)

Implements three important behaviors:

1. **Prefixing** — rewrites the message to begin with `node_invalid_placement_ssr` (the machine-readable error code) and appends a hint that browser HTML repair will shift content and likely trigger a `hydration_mismatch` warning.
2. **Deduplication** — lazily initializes a `seen` set; identical messages are only reported once per process. Since SSR frameworks render the same broken markup on every request, this prevents log flooding.
3. **Dual-channel reporting** — besides `console.error` on the server, it appends `<script>console.error("…")</script>` to `payload.head.out`, so the violation is visible in the *browser's* developer console, right next to hydration diagnostics.

## 5. Data Flow

### 5.1 Compile-time → runtime flow

```mermaid
sequenceDiagram
    autonumber
    participant C as Server compiler<br/>(compiler_server_transform)
    participant G as Generated SSR code
    participant DV as dev.js<br/>(push/pop_element)
    participant TV as html-tree-validation.js
    participant PAY as Payload
    participant R as render() loop

    C->>G: dev mode: emit $.push_element($$payload, tag, line, col)<br/>before children, $.pop_element() after close tag
    R->>G: render(component)
    R->>DV: reset_elements() → save & clear stack
    G->>DV: push_element(payload, "div", 3, 1)
    DV->>DV: read current_component.function[FILENAME]
    DV->>TV: is_tag_valid_with_parent(tag, parent.tag, …)
    TV-->>DV: null (ok) | message
    DV->>TV: is_tag_valid_with_ancestor(tag, ancestors, …)
    TV-->>DV: null (ok) | message
    alt violation found
        DV->>PAY: head.out.push("<script>console.error(…)</script>")
        DV->>DV: console.error(message) — once per unique message
    end
    DV->>DV: parent = { tag, parent, filename, line, column }
    G->>G: render children markup …
    G->>DV: pop_element()
    DV->>DV: parent = parent.parent
    R->>DV: restore closure() — stack back to saved state
```

### 5.2 Error surfacing paths

```mermaid
flowchart TD
    V["Invalid element placement<br/>detected during SSR"] --> MSG["build annotated message<br/>child/parent/ancestor + file:line:col"]
    MSG --> SEEN{"seen already?"}
    SEEN -->|yes| DROP["drop (dedup)"]
    SEEN -->|no| ADD["add to seen set"]
    ADD --> CE["console.error on server"]
    ADD --> INJ["inject &lt;script&gt;console.error(…) into<br/>payload.head.out"]
    INJ --> BROWSER["Message appears in the<br/>browser dev console after load"]

    SNIPT["Snippet called with<br/>invalid/foreign payload"] --> VSA["validate_snippet_args"]
    VSA --> THROW["throw invalid_snippet_arguments<br/>(docs URL attached)"]
```

## 6. Integration Points

### 6.1 With the compiler backend

The server transform phase (see [compiler_server_transform.md](compiler_server_transform.md)) is the *producer* of all calls into this module. In the `RegularElement` visitor, codegen is gated on the `dev` flag:

```js
if (dev) {
    const location = locator(node.start);
    state.template.push(
        b.stmt(b.call('$.push_element',
            b.id('$$payload'), b.literal(node.name),
            b.literal(location.line), b.literal(location.column)))
    );
}
// …children…
if (dev) {
    state.template.push(b.stmt(b.call('$.pop_element')));
}
```

Similarly, `SnippetBlock` prepends `$.validate_snippet_args($$payload)` to each snippet function body in dev mode. Consequences for maintainers:

- Any change to these call shapes must be synchronized between `dev.js` and the corresponding server visitors.
- Production builds contain zero references to this module, so it must never acquire production-relevant side effects at import time (its state is lazily initialized for this reason: `seen ??= new Set()`).

### 6.2 With the render pipeline

The render entry ([server_runtime_rendering_core.md](server_runtime_rendering_core.md)) calls `reset_elements()` per render to guard stack integrity across requests, as shown above. This is one of several dev-mode affordances `render()` enables (context push/pop, on-destroy wiring, etc.).

### 6.3 With the payload model

All reporting flows through `Payload`/`HeadPayload` from [server_runtime_payload_model.md](server_runtime_payload_model.md):

- `payload.head.out` receives the browser-side `console.error` script.
- `validate_snippet_args` type-checks against both payload classes because snippets may render into the head payload (`<svelte:head>`).

### 6.4 With validation rules

The actual HTML knowledge (which children are legal where) lives in `src/html-tree-validation.js` — a shared, runtime-agnostic rules table (`disallowed_children`) with `direct`, `descendant`, `only`, and `reset_by` semantics. This module is purely the *orchestrator*: it walks the live render stack and applies those rules. This separation keeps the rules testable and lets the same rules be reused by other tooling.

## 7. Process Flows

### 7.1 Element validation walk (`push_element`)

```mermaid
flowchart TD
    START(["push_element(payload, tag, line, col)"]) --> F{"current_component?"}
    F -->|"yes (normal render)"| FN["filename = current_component.function[FILENAME]"]
    F -->|"no"| FN2["(throws — components always wrap rendering)"]
    FN --> HASP{"parent ≠ null?"}
    HASP -->|"no"| PUSH
    HASP -->|"yes"| VP["validate vs parent:<br/>is_tag_valid_with_parent"]
    VP --> VIO1{"message?"}
    VIO1 -->|"yes"| REPORT
    VIO1 -->|"no"| ANC["walk ancestors:<br/>is_tag_valid_with_ancestor<br/>(with reset_by short-circuit)"]
    ANC --> VIO2{"message?"}
    VIO2 -->|"yes"| REPORT
    VIO2 -->|"no"| PUSH
    REPORT["print_error(payload, message)<br/>(dedup + console + head script)"] --> PUSH
    PUSH["parent = child Element record"] --> DONE(["return"])
```

### 7.2 Snippet argument validation

```mermaid
flowchart LR
    A(["{@render snip(...)}<br/>or misuse"]) --> B["snippet fn body starts with<br/>validate_snippet_args($$payload)"]
    B --> C{"payload instanceof<br/>Payload | HeadPayload?"}
    C -->|"yes"| OK["continue rendering snippet"]
    C -->|"no"| ERR["throw invalid_snippet_arguments"]
```

## 8. Invariants & Gotchas for Maintainers

1. **Stack discipline is caller-owned.** The compiler guarantees a `push_element`/`pop_element` pair per non-void element, but user-level errors (e.g. a snippet that renders half a tree and throws) can unbalance the stack. That is why `render()` must always bracket component invocation with `reset_elements()` in dev mode.
2. **Module-global state ⇒ not concurrent-render safe *within a process* without the reset protocol.** The state is intentionally cheap; do not add heavier structures here.
3. **`seen` is process-lifetime.** Dedup means a given violation message is logged once per server process, not per request. Unique messages (different location strings) still each report once.
4. **Custom elements are exempt** (`tag.includes('-')`) — both validators bail early for them, since the HTML parser allows anything inside custom elements.
5. **`<template>` children are exempt** from direct-parent checks by design.
6. **Head payloads are first-class.** `validate_snippet_args` accepts `HeadPayload` explicitly; a type-only union (`Payload | HeadPayload`) is used because TypeScript narrows `payload` to `never` after the first `instanceof` in the original expression.
7. **Diagnostics must stay dual-channel.** The inline `<script>console.error</script>` injection is essential UX — it links the server-side `node_invalid_placement_ssr` message to the client-side `hydration_mismatch` the user actually sees. Don't drop it when refactoring reporting.

## 9. Related Modules

| Module | Relationship |
|---|---|
| [server_runtime_rendering_core.md](server_runtime_rendering_core.md) | `render()` orchestrates dev validation via `reset_elements()`; produces the `Payload` consumed here |
| [server_runtime_payload_model.md](server_runtime_payload_model.md) | `Payload`/`HeadPayload` definitions; target of error injection and snippet arg type checks |
| [compiler_server_transform.md](compiler_server_transform.md) | Emits all `$.push_element` / `$.pop_element` / `$.validate_snippet_args` calls in dev mode |
| [server_runtime_blocks.md](server_runtime_blocks.md) | Other server blocks (html/snippet) whose rendering is bracketed by the same element stack |
| [client_dev_mode_validation.md](client_dev_mode_validation.md) | Client-side dev validation counterpart (`validate_snippet_args`, ownership/equality checks) |
| [server_runtime_dev_validation_diagnostics](server_runtime_dev_validation.md) | This module's error codes: `node_invalid_placement_ssr`, `invalid_snippet_arguments` |

## 10. Quick API Summary

```js
// Dev-only entry points (tree-shaken in production)
push_element(payload, tag, line, column) // validate + push element onto stack
pop_element()                            // pop element (paired with push_element)
validate_snippet_args(payload)           // throw if payload is not Payload/HeadPayload

// Internal (used by render core)
reset_elements() // → () => void  save/clear stack, returns restore closure
```
