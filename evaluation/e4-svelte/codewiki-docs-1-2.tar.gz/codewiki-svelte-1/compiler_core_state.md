# compiler_core_state

## 1. Introduction

`compiler_core_state` (implemented in a single file, `packages/svelte/src/compiler/state.js`) provides the **global, in-progress compilation state** shared by every phase of the Svelte compiler — parsing, analysis, CSS scoping, and client/server code generation. Instead of threading cross-cutting context (the raw source text, filename, line/column locator, dev/runes mode, warning filter, and the `svelte-ignore` bookkeeping) through every function signature of the compiler pipeline, all phases read and mutate this module-level singleton.

The module's two *core components* — **`push_ignore`** and **`pop_ignore`** — implement a scoped stack that lets the analyzer register which warnings are suppressed for a given subtree (via `<!-- svelte-ignore code, ... -->` / `// svelte-ignore` comments). Around them sit the lifecycle primitives `reset()` and `adjust()`, the source/position helpers `set_source()` and `locate_node()`, and the lookup predicate `is_ignored()`.

> **Position in the system:** `compiler_core_state` is one of four sub-modules of [compiler_core](compiler_core_entry.md), alongside [compiler_core_entry](compiler_core_entry.md), [compiler_core_options](compiler_core_options.md), and [compiler_core_builders](compiler_core_builders.md), within the *Compiler Infrastructure (Core Orchestration, Diagnostics & AST Type Model)* layer.

---

## 2. Design Rationale: Why a Module Singleton?

The compiler is a multi-pass pipeline (`1-parse → 2-analyze → 3-transform`). Certain data is needed *everywhere* but belongs to *no single phase*:

- The **original source text** — required at any moment to render code frames for errors (`[compiler_diagnostics](compiler_diagnostics.md)`).
- The **character-offset → line/column locator** — needed to turn AST `start`/`end` offsets into human-readable positions.
- The **compilation mode flags** (`dev`, `runes`) — decided during analysis but honored during transformation.
- The **warning accumulator and filter** — warnings are emitted from hundreds of places, collected once, and filtered at the end.
- The **`svelte-ignore` scopes** — defined in the template, consumed by both analysis warnings and transform-time decisions.

Representing these as a module-scoped singleton keeps every phase function signature small and makes the compiler's behavior deterministic: **the state is always reset before a compilation and re-adjusted once parse-level facts are known**. This is an explicit trade-off: compilations are serialized per process, and every entry point must call `reset()` first (the entry orchestrators do, see [compiler_core_entry](compiler_core_entry.md)).

---

## 3. State Inventory

| Field | Type | Set by | Purpose |
|---|---|---|---|
| `warnings` | `Warning[]` | `reset()` (cleared) | Accumulator for all warnings of the current compilation; the entry point filters it with `warning_filter` before returning `CompileResult`. |
| `filename` | `string` | `reset()` / `adjust()` | Source filename (backslashes normalized to `/`), made relative to `rootDir`. Dev-mode/diagnostic use only — never compiler output. |
| `UNKNOWN_FILENAME` | `'(unknown)'` (const) | — | Fallback when no filename is supplied. |
| `component_name` | `string` | `adjust()` | Name of the component in the generated `export default function ...`; defaults to `'<unknown>'`. |
| `source` | `string` | `set_source()` | The original source text; consumed by code-frame rendering. |
| `dev` | `boolean` | `reset()` (false) → `adjust()` | Whether compilation runs with `dev: true`; gates dev-only instrumentation and `is_ignored`. |
| `runes` | `boolean` | `reset()` (false) → `adjust()` | Whether runes mode is active for this component. |
| `locator` | `locate-character` locator | `set_source()` | Maps character offsets to `{ line, column }` (`offsetLine: 1`). Before parse it is a no-op returning `undefined`. |
| `warning_filter` | `(warning) => boolean` | `reset()` | User-supplied `CompileOptions.warningFilter` (validated by [compiler_core_options](compiler_core_options.md)); defaults to `() => true`. |
| `ignore_stack` | `Set<string>[]` | `push_ignore()` / `pop_ignore()` / `adjust()` (cleared) | Lexical stack of ignored warning-code sets; inner frames inherit outer frames' codes. |
| `ignore_map` | `Map<SvelteNode \| {start?, end?}, Set<string>[]>` | analysis visitors / `adjust()` (cleared) | Per-node record of ignored codes — exists *in addition to* `ignore_stack` because not all warnings are emitted while the stack window is active. Queried via `is_ignored()`. |

---

## 4. API Reference

### 4.1 Core Components

#### `push_ignore(ignores: string[])`

Pushes a new ignore scope onto `ignore_stack`. The new frame is the **union of the current top-of-stack codes and the incoming codes**, so ignore scopes nest and inherit:

```js
export function push_ignore(ignores) {
	const next = new Set([...(ignore_stack.at(-1) || []), ...ignores]);
	ignore_stack.push(next);
}
```

Worked example:

| Call | `ignore_stack` afterwards |
|---|---|
| `push_ignore(['a11y_missing_attribute'])` | `[{ a11y_missing_attribute }]` |
| `push_ignore(['a11y_label_has_associated_control'])` | `[{ a11y_missing_attribute }, { a11y_missing_attribute, a11y_label_has_associated_control }]` |
| `pop_ignore()` | `[{ a11y_missing_attribute }]` |
| `pop_ignore()` | `[]` |

The merging semantics guarantee that a `svelte-ignore` comment on an outer element keeps suppressing warnings for all its children, even when the children introduce additional ignores.

#### `pop_ignore()`

Pops the most recent frame, exactly restoring the enclosing scope. It is always called in tight pairing with `push_ignore` — the analysis visitors bracket the visitation of an annotated subtree with the two calls (`push` on the `svelte-ignore` comment, `pop` when the subtree walk leaves it), keeping the stack balanced even when nested ignores occur.

### 4.2 Supporting Functions

| Function | Role |
|---|---|
| `set_source(value)` | Stores the source text and rebuilds `locator` with `getLocator(source, { offsetLine: 1 })`. Called by `parse()` in `1-parse/index.js`. |
| `locate_node(node)` | Renders a display string `` `${sanitize_location(filename)}:${line}:${column}` `` for a node's `start` offset (uses the `sanitize_location` helper from `compiler/utils.js`). Used for dev-mode locations on emitted nodes. |
| `is_ignored(node, code)` | `true` only when `dev` is enabled **and** any per-node code set in `ignore_map` contains `code`. Gates *ignorable runtime warnings* (`IGNORABLE_RUNTIME_WARNINGS` from `compiler/constants.js`). |
| `reset(state)` | Called **before every compilation** by `compile()` / `compileModule()` in [compiler_core_entry](compiler_core_entry.md). Clears warnings, resets mode flags to `false`, normalizes/relativizes is deferred to `adjust`, installs `warning_filter`, and replaces `locator` with a no-op. |
| `adjust(state)` | Called **once per component**, from `analyze_component()` in [compiler_analyzer](compiler_analyzer.md), after parsing and basic scope analysis. Sets `dev`, `runes`, `component_name`, makes `filename` relative to `rootDir`, and **clears `ignore_stack` and `ignore_map`** so ignore bookkeeping starts fresh for the visitor walks that follow. |

---

## 5. The `svelte-ignore` Suppression Mechanism

`push_ignore` / `pop_ignore` are the write side of a two-part suppression system:

1. **During analysis**, when a visitor encounters an ignore comment, the comment's payload is parsed by `extract_svelte_ignore()` (see [compiler_migrate](compiler_migrate.md)'s sibling utility `utils/extract_svelte_ignore.js`). It validates codes (with fuzzy-match suggestions and legacy-code rewrites in runes mode), returning the list of valid warning codes.
2. The visitor calls **`push_ignore(codes)`**, walks the annotated subtree (warnings may fire while the window is open), then calls **`pop_ignore()`**. The per-node code sets are additionally recorded in **`ignore_map`** so suppression decisions remain possible *after* the lexical window has closed.
3. **During transformation** (dev mode), client-transform visitors query **`is_ignored(node, code)`** to decide whether to embed runtime validation/warning code — e.g. `each_key_duplicate` or `binding_property_non_reactive` checks — into the generated output. If the node was covered by a `svelte-ignore` comment, the runtime check is omitted.
4. A compile-time example of the same data: `analyze_component` reads the root CSS comment via `extract_svelte_ignore(...)` and skips `css_unused_selector` reporting when the code is listed there (see [compiler_css_pipeline_analysis](compiler_css_pipeline_analysis.md)).

```mermaid
flowchart TD
    C["svelte-ignore comment<br/>code1, code2"] --> X["extract_svelte_ignore(offset, text, runes)<br/>validates codes, maps legacy names"]
    X -->|"codes[]"| P["push_ignore(codes)"]
    P --> M["new Set previous codes union new codes<br/>pushed onto ignore_stack"]
    M --> V["analysis descends into annotated subtree<br/>warnings may fire while window is open"]
    V --> O["pop_ignore()<br/>previous scope restored"]
    O --> R["per-node code sets recorded in ignore_map"]
    R --> Q{"is_ignored(node, code)"}
    Q -->|"dev true and code present"| S["dev-mode runtime warning<br/>instrumentation suppressed"]
    Q -->|"otherwise"| T["runtime warning code embedded<br/>e.g. each_key_duplicate"]
```

---

## 6. Architecture & Component Relationships

The state singleton sits at the center of the compiler: the entry orchestrators **reset** it, the parser **seeds** it with the source, the analyzer **adjusts** it once mode/component facts are known and **drives** the ignore stack, the transformers **query** it, and the diagnostics subsystem **reads** it to render warnings and errors.

```mermaid
flowchart TB
    OPT["compiler_core_options<br/>validated CompileOptions<br/>filename, warningFilter, dev, runes, rootDir"]

    subgraph CORE["compiler_core_state — packages/svelte/src/compiler/state.js"]
        FIELDS["Module-level mutable fields<br/>warnings / filename / source / dev / runes<br/>component_name / locator / warning_filter<br/>ignore_stack / ignore_map"]
        RESET["reset()"]
        ADJUST["adjust()"]
        SETSRC["set_source()"]
        LOCNODE["locate_node()"]
        PUSHPOP["push_ignore() / pop_ignore()"]
        ISIGN["is_ignored()"]
    end

    ENTRY["compiler_core_entry<br/>compile() / compileModule()"]

    subgraph PHASES["Compiler phases"]
        PARSE["1-parse<br/>compiler_parser"]
        ANALYZE["2-analyze<br/>compiler_analyzer"]
        CLIENT["3-transform client<br/>compiler_client_transform"]
        SERVER["3-transform server<br/>compiler_server_transform"]
    end

    subgraph DIAG["compiler_diagnostics"]
        ERRORS["errors.js — CompileError"]
        WARNS["warnings.js — warning emitters"]
        CDIAG["CompileDiagnostic + get_code_frame"]
    end

    ENTRY -->|"reset with filename, warningFilter"| RESET
    OPT --> RESET
    PARSE -->|"set_source"| SETSRC
    ANALYZE -->|"adjust with dev, runes, name, rootDir"| ADJUST
    ANALYZE --> PUSHPOP
    CLIENT --> ISIGN
    SERVER --> ISIGN
    CLIENT --> LOCNODE
    RESET --> FIELDS
    ADJUST --> FIELDS
    SETSRC --> FIELDS
    PUSHPOP --> FIELDS
    WARNS -->|"push Warning objects"| FIELDS
    ERRORS -->|"read filename, locator, source"| FIELDS
    CDIAG -->|"read filename, locator, source"| FIELDS
    FIELDS -->|"warnings filtered by warning_filter"| ENTRY
```

**Distinction from per-phase states:** the global state is *not* the same as the visitor context objects threaded through the passes — `AnalysisState` (2-analyze) and `TransformState` (`phases/3-transform/types.d.ts`, see [compiler_client_transform_state_and_reactivity](compiler_client_transform_state_and_reactivity.md)) carry per-walk, per-node context and are passed explicitly. `state.js` holds only the cross-cutting, phase-independent facts.

---

## 7. Compilation Lifecycle (State Perspective)

```mermaid
sequenceDiagram
    autonumber
    participant Entry as compile/compileModule
    participant State as state singleton
    participant Parse as 1-parse
    participant Analyze as 2-analyze
    participant Transform as 3-transform
    participant Diag as compiler_diagnostics

    Entry->>State: reset(filename, warningFilter)
    Note over State: dev=false, runes=false<br/>warnings=[], locator=no-op
    Entry->>Parse: parse(source)
    Parse->>State: set_source(source)
    Note over State: source stored, locator rebuilt
    Entry->>Analyze: analyze_component(parsed, source, options)
    Analyze->>State: adjust(dev, runes, component_name, rootDir)
    Note over State: ignore_stack=[], ignore_map cleared<br/>filename relativized to rootDir
    loop per svelte-ignore comment scope
        Analyze->>State: push_ignore(codes)
        Analyze->>Diag: warnings may fire (accumulated in state.warnings)
        Analyze->>State: pop_ignore()
    end
    Entry->>Transform: transform_component(analysis, source, options)
    Transform->>State: is_ignored(node, code) — dev-mode gating
    Transform->>State: locate_node(node) — dev-mode locations
    Note over Diag,State: errors/warnings read filename, locator, source<br/>to render messages and code frames
    Entry->>Entry: filter state.warnings via state.warning_filter
    Entry-->>Entry: CompileResult (warnings, js, css, ast, ...)
```

Two lifecycles exist: `compile()` (components, full parse → analyze → transform → AST conversion) and `compileModule()` (plain JS modules; no template parse, so `set_source` may not be driven by `parse()` in that path). Both begin with the same `state.reset(...)` contract (see [compiler_core_entry](compiler_core_entry.md)).

---

## 8. Data Flow

```mermaid
flowchart LR
    subgraph IN["Inputs"]
        OPTS["CompileOptions<br/>filename, warningFilter"]
        SRC["component source text"]
        RES["analysis facts<br/>dev, runes, component name, rootDir"]
        COMMENTS["svelte-ignore comments"]
    end

    subgraph ST["compiler_core_state"]
        FN["filename"]
        WF["warning_filter"]
        SO["source + locator"]
        MODE["dev / runes / component_name"]
        IG["ignore_stack / ignore_map"]
        W["warnings accumulator"]
    end

    subgraph OUT["Outputs / Consumers"]
        RESULT["CompileResult.warnings<br/>filtered at the end"]
        ERRL["CompileError messages<br/>with code frames"]
        DEVLOC["dev-mode node locations"]
        RUNTIME["runtime-warning gating<br/>in generated code"]
    end

    OPTS --> FN
    OPTS --> WF
    SRC --> SO
    RES --> MODE
    COMMENTS --> IG
    IG --> RUNTIME
    MODE --> DEVLOC
    SO --> ERRL
    FN --> ERRL
    W --> RESULT
    WF --> RESULT
```

---

## 9. Consumers & Related Modules

| Consumer | Relationship to `compiler_core_state` |
|---|---|
| [compiler_core_entry](compiler_core_entry.md) | `compile()` / `compileModule()` invoke `reset({ filename, warningFilter })` as their first act and collect the final filtered `state.warnings`. |
| [compiler_core_options](compiler_core_options.md) | Validates the options from which `filename` and `warningFilter` originate. |
| [compiler_core_builders](compiler_core_builders.md) | Sibling utility module; AST builders are stateless counterparts to the stateful singleton. |
| [compiler_parser](compiler_parser.md) (specifically `compiler_parser_template_state_machine`) | `parse()` calls `set_source(source)` to seed the text and locator. |
| [compiler_analyzer](compiler_analyzer.md) | `analyze_component()` calls `adjust()` once `runes` / `component_name` are resolved; template/JS/block visitors (`[compiler_analyzer_template_visitors](compiler_analyzer_template_visitors.md)`, `[compiler_analyzer_block_visitors](compiler_analyzer_block_visitors.md)`) drive `push_ignore`/`pop_ignore` around `svelte-ignore` scopes. Scope handling is documented in [compiler_analyzer_scope](compiler_analyzer_scope.md). |
| [compiler_css_pipeline_analysis](compiler_css_pipeline_analysis.md) / [compiler_css_pipeline_transform](compiler_css_pipeline_transform.md) | CSS analysis honors root-level `svelte-ignore` comments (e.g. `css_unused_selector`); global-block rules live in the css-pipeline docs. |
| [compiler_client_transform](compiler_client_transform.md) / [compiler_server_transform](compiler_server_transform.md) | Transform visitors consult `is_ignored()` for dev-mode runtime warnings and `locate_node()` for dev locations. |
| [compiler_diagnostics](compiler_diagnostics.md) | `warnings.js` emitters push `Warning` objects into `state.warnings`; `errors.js` throws `CompileError`; `CompileDiagnostic` reads `state.filename`, `state.locator`, `state.source` and `state.UNKNOWN_FILENAME`, rendering code frames via `get_code_frame()`. |
| [compiler_types](compiler_types.md) | Declares the contracts flowing through the state: `Warning`, `CompileError`, `CompileResult`, `CompileOptions.warningFilter`. |

---

## 10. Design Notes & Gotchas

- **`reset()` vs `adjust()` ordering.** `reset()` runs *before* parsing with only user options; it cannot know `dev`/`runes` yet (they may be implied by `<svelte:options runes>` or rune usage), so it sets them to `false`. `adjust()` runs *after* parse + scope analysis and installs the true values, relativizes `filename` against `rootDir`, and clears the ignore bookkeeping. Never assume mode flags are final before `adjust()` has run.
- **`ignore_stack` survives `reset()` but not `adjust()`.** The ignore bookkeeping is intentionally cleared in `adjust()`, right before the visitor walks that populate it — if you add a new pass between reset and adjust, do not rely on ignore state.
- **Dev-only semantics of `is_ignored()`.** `is_ignored()` hard-returns `false` unless `dev === true`; production builds embed no ignore-sensitive runtime checks at all.
- **Filename hygiene.** Backslashes are normalized to `/` in `reset()`, and `filename` is made relative to `rootDir` in `adjust()`. The field is for diagnostics and dev-mode output only — per its own doc comment it "should not be used in the compiler output except in dev mode".
- **Re-entrancy.** Because state is module-global, concurrent compilations in one process would clobber each other; the contract is one compilation at a time, always initiated through [compiler_core_entry](compiler_core_entry.md) so `reset()` runs first.
- **`locator` availability.** Before `set_source()` the locator is a no-op returning `undefined`; `locate_node()` therefore yields `null` line/column for nodes queried before parsing — relevant for error paths triggered during option validation ([compiler_core_options](compiler_core_options.md)).

---

## 11. Related Documentation

- [compiler_core_entry](compiler_core_entry.md) — pipeline orchestration and `reset()` call sites
- [compiler_core_options](compiler_core_options.md) — option validation incl. `warningFilter`
- [compiler_core_builders](compiler_core_builders.md) — AST builder utilities
- [compiler_diagnostics](compiler_diagnostics.md) — errors, warnings, and `CompileDiagnostic` consumers of the state
- [compiler_types](compiler_types.md) — `Warning`, `CompileError`, `CompileResult` type contracts
- [compiler_parser](compiler_parser.md) — parse phase that seeds `source`/`locator`
- [compiler_analyzer](compiler_analyzer.md) — `adjust()` call site and ignore-scope driving
- [compiler_client_transform](compiler_client_transform.md) · [compiler_server_transform](compiler_server_transform.md) — transform-time `is_ignored()`/`locate_node()` consumers