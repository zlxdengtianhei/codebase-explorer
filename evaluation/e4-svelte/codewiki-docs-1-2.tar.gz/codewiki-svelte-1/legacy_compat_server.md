# legacy_compat_server

## Introduction

`legacy_compat_server` is the **server-side half of Svelte's legacy compatibility layer**. It lives in a single file — `packages/svelte/src/legacy/legacy-server.js` — and exists so that **Svelte 4-style class components and reactive statements continue to work when component code is rendered on the server (SSR) by Svelte 5**.

Svelte 5 replaced the class-based `SvelteComponent` API and `$:` reactive statements with function components and runes. For imperative code that still constructs components like `new MyComponent({ target, props })` or relies on the Svelte 4 `render()` SSR contract, Svelte ships the `legacy` compatibility entries. This module implements the **server variant** of that shim. The file's own header states its core design constraint:

> *"By having this as a separate entry point for server environments, we save the client bundle from having to include the server runtime."*

In other words, bundlers resolve `svelte/legacy` to either [legacy_compat_client](legacy_compat_client.md) (browsers) or this module (Node/SSR), and only the selected half is ever shipped. The server variant contains just enough surface — a `.render()` method adapter, an immediate-run `run()`, and no-op event helpers — to keep Svelte 4-shaped code from crashing during SSR.

All exported APIs are **deprecated** and intended only as a temporary migration bridge.

---

## Module Overview

| Component | Kind | Purpose |
|---|---|---|
| `asClassComponent(component)` | exported function | Wraps a Svelte 5 component so it can be used as a Svelte 4 class constructor **with a working `render()` method for SSR**. |
| `_render(props, options)` | internal closure | Created inside `asClassComponent`; adapts the Svelte 5 server `render()` output to the Svelte 4 `{ html, css, head }` shape. |
| `run(fn)` | exported function | Svelte 4 `$:`-block shim — executes `fn()` once immediately on the server (no reactivity). |
| `noop` (re-exported) | exported value | Stubs `handlers`, `createBubbler`, `once`, `preventDefault`, `self`, `stopImmediatePropagation`, `stopPropagation`, `trusted`, `passive`, `nonpassive` — event helpers that are meaningless on the server but must exist to prevent crashes. |
| `createClassComponent` | re-export | Re-exported verbatim from [legacy_compat_client](legacy_compat_client.md) so both entries expose the same imperative-construction API. |

---

## Architecture & Position in the System

`legacy_compat_server` is a **leaf adapter** at the intersection of two runtime subsystems:

- It **borrows** the client-side class machinery (`Svelte4Component` base class) from [legacy_compat_client](legacy_compat_client.md), because the returned constructor must behave like a Svelte 4 class on both sides.
- It **uses** the Svelte 5 SSR engine (`render()`) from the [server_runtime](server_runtime.md) module to actually produce markup.

```mermaid
graph TB
    subgraph Public["Public API Surface & Compatibility Layer"]
        LIC["legacy_compat_client<br/>(svelte/legacy — client)"]
        LIV["legacy_compat_server<br/>(svelte/legacy — server)"]
    end

    subgraph Rendering["Component Rendering Backends"]
        SR["server_runtime<br/>(internal/server — render engine)"]
        CR["client_dom_renderer<br/>(internal/client — mount/hydrate)"]
    end

    subgraph SharedInfra["Cross-Runtime Platform Services"]
        CTX["context_api<br/>(server context push/pop)"]
        FLAGS["shared_runtime_flags"]
    end

    LIC -->|"createClassComponent,<br/>asClassComponent, run"| CR
    LIC --> FLAGS
    LIV -->|"as_class_component<br/>(Svelte4Component base)"| LIC
    LIV -->|"re-exports createClassComponent"| LIC
    LIV -->|"render(component, {props, context})"| SR
    SR --> CTX
```

**Key relationships:**

1. **Import**: `asClassComponent as as_class_component` and `createClassComponent` are imported from `legacy-client.js`. The server module *does not* re-implement class semantics; it extends them.
2. **Import**: `render` from `internal/server/index.js` — the real SSR entry point documented in [server_runtime](server_runtime.md).
3. **Re-export**: `createClassComponent` is re-exported unchanged. Its construction path (`hydrate`/`mount`) is inherently client-side, so calling it during pure SSR is not meaningful, but keeping the export keeps the two `svelte/legacy` entries API-identical.

---

## Component Details

### `asClassComponent(component)`

Transforms a Svelte 5 component (a compiled SSR render function) into a **Svelte 4-compatible class constructor**.

```mermaid
flowchart TD
    A["asClassComponent(component)"] --> B["as_class_component(component)<br/>from legacy_compat_client:<br/>class extends Svelte4Component"]
    B --> C["component_constructor<br/>(Svelte 4 class: $set / $on / $destroy)"]
    C --> D["Define _render(props, opts) closure"]
    D --> E["Attach: component_constructor.render = _render"]
    E --> F["Return constructor typed as<br/>typeof SvelteComponent & Exports"]
```

Step by step:

1. **Class creation** — delegates to the client's `asClassComponent`, producing a subclass of the internal `Svelte4Component`. That base class (see [legacy_compat_client](legacy_compat_client.md)) emulates Svelte 4's coarse-grained props proxy, `$set`, `$on`, and `$destroy` on top of Svelte 5's `mount`/`hydrate`.
2. **Render-method injection** — the crucial server-specific step: it attaches a `render` method onto the constructor. Legacy SSR tooling (e.g. SvelteKit adapters pre-runes, `server.render(...)` call sites) invokes `component.render(props, { context })` and expects a specific payload.
3. **Return** — the same constructor is returned, so one object serves both `new Ctor({...})` (client-style) and `Ctor.render({...})` (SSR-style) usage.

### `_render(props, options)` — the shape adapter

`_render` is not exported; it is the closure bound into the constructor's `render` property. Its job is purely **output-shape translation**:

```mermaid
sequenceDiagram
    participant Legacy as Legacy SSR code
    participant AC as Ctor.render = _render
    participant R5 as svelte 5 render()<br/>(server_runtime)
    participant P as Payload

    Legacy->>AC: _render(props, { context })
    AC->>R5: render(component, { props, context })
    R5->>P: new Payload + component(payload, props, ...)
    Note over R5: context pushed via context_api<br/>css collected as <style> into head<br/>onDestroy cleanups run
    R5-->>AC: { head, html: body, body }
    AC-->>Legacy: { css: { code: '', map: null },<br/>head: result.head,<br/>html: result.body }
```

The translation rules reflect how the Svelte 4 and Svelte 5 SSR contracts differ:

| Svelte 4 `render()` field | Svelte 5 `render()` source | Adapter behavior |
|---|---|---|
| `html` | `result.body` | Copied (Svelte 5 also exposes it as `html`, but the adapter reads `body`). |
| `head` | `result.head` | Copied verbatim. **Note:** Svelte 5 emits component CSS as `<style id="…">` tags *inside* `head`, so legacy consumers that re-inject `css.code` must not do so again. |
| `css: { code, map }` | *does not exist* | Stubbed to `{ code: '', map: null }` to satisfy the legacy contract without duplicating styles. |

Options are limited to `{ context }` — the only legacy render option that still has meaning server-side; it is forwarded to Svelte 5's `render()`, which pushes it onto the [context_api](context_api.md) stack for the duration of the render.

> ⚠️ The implementation carries `@ts-expect-error` markers: the payload matches at runtime only **if the component was compiled in SSR mode**. A client-compiled component cannot be rendered this way.

### `run(fn)`

The server twin of the client `run()` in [legacy_compat_client](legacy_compat_client.md), which wraps `fn` in a `user_pre_effect` to emulate `$:` statement semantics. On the server there is no reactive system driving re-execution, so the implementation collapses to:

```js
export function run(fn) {
    fn();
}
```

The function executes **exactly once, immediately**. This mirrors Svelte 4's SSR behavior, where reactive statements run once during component initialization. Any cleanup-return value is ignored, and no effect lifecycle is registered with the server runtime.

### Event-helper stubs (`noop` family)

Shared component code frequently references Svelte 4's event utilities — `handlers(...)` compositor, `createBubbler()`, and the modifiers `once`, `preventDefault`, `self`, `stopImmediatePropagation`, `stopPropagation`, `trusted`, `passive`, `nonpassive`. None of these can do anything during SSR (there are no DOM events), but because the *same component source* compiles for both targets, the server entry must still export the names or the module graph breaks. The module therefore exports a single shared `noop` under all ten names:

```js
export {
    noop as handlers,
    noop as createBubbler,
    noop as once,
    /* …modifiers… */
};
```

This is the server-side analogue of the *real* implementations in [legacy_compat_client](legacy_compat_client.md) (`handlers`, `createBubbler` and the event-modifier helpers), deliberately reduced to stubs to keep the SSR entry free of client runtime code.

---

## Data Flow: Legacy Component Render on the Server

End-to-end flow when legacy code server-renders a migrated component:

```mermaid
flowchart TD
    A["Legacy caller:<br/>Comp.render(props, { context })"] --> B["legacy_compat_server<br/>_render closure"]
    B --> C["server_runtime render(component, {props, context})"]
    C --> D{"options.context?"}
    D -->|yes| E["context_api push()"]
    D -->|no| F["skip"]
    E --> G["component(payload, props, {}, {})<br/>compiled SSR function"]
    F --> G
    G --> H["Serialize template → payload.out<br/>Collect head/title/css into payload.head"]
    H --> I{"context pushed?"}
    I -->|yes| J["context_api pop()"]
    I -->|no| K["skip"]
    J --> L["Run onDestroy cleanups<br/>return { head, html/body }"]
    K --> L
    L --> M["_render remaps:<br/>{ html: body, head, css: empty }"]
    M --> N["Legacy consumer receives<br/>Svelte 4 render result"]
```

Note that the `try/finally` inside Svelte 5's `render()` guarantees the abort-signal/cleanup path (`server_runtime`) runs even if the component throws — the adapter adds no error handling of its own.

---

## Dependencies

**Direct imports:**

| Dependency | Source module | Used for |
|---|---|---|
| `asClassComponent as as_class_component` | [legacy_compat_client](legacy_compat_client.md) | Building the `Svelte4Component`-based constructor. |
| `createClassComponent` | [legacy_compat_client](legacy_compat_client.md) | Re-exported for API parity between client/server legacy entries. |
| `render` | [server_runtime](server_runtime.md) | Actual SSR execution. |
| `SvelteComponent` (type only) | Public API type contracts (`index.js` JSDoc import) | Typing the returned constructor. |

**Reverse / consumer-facing links:**

- Bundler-resolved as the **server condition** of the `svelte/legacy` export; the client condition resolves to [legacy_compat_client](legacy_compat_client.md).
- The type-side contract for legacy component types (`SvelteComponentTyped` and friends) is documented in [public_api_type_contracts](public_api_type_contracts.md).
- Server context semantics consumed via the `context` option come from [context_api](context_api.md).
- The rendering engine being adapted is documented in [server_runtime](server_runtime.md) (`render`, payload model).

---

## Design Rationale

1. **Bundle isolation.** Importing `internal/server` from the shared `legacy-client.js` would drag the entire SSR engine into browser bundles. Splitting the entry and re-exporting only the trivially shareable pieces (`createClassComponent`) keeps each target minimal.
2. **Contract preservation over feature parity.** The adapter's goal is that *existing* Svelte 4 SSR integration code (which reads `html`, `head`, `css.code`) keeps working, not that new features surface through it. Hence `css` is a permanent empty stub and only `{ context }` is forwarded.
3. **Crash-proof stubs.** The ten no-op event exports are cheap insurance: shared component modules that import them at top level remain loadable on the server.
4. **Single-implementation class semantics.** By delegating to the client module for the class shape, behavior of `$set`/`$on`/`$destroy` stays defined in exactly one place ([legacy_compat_client](legacy_compat_client.md)).

---

## Usage Notes, Limitations & Deprecation

- **Deprecated by design.** Every exported helper is marked `@deprecated` — use it only as a temporary bridge while migrating imperative component code to Svelte 5's `mount`/`hydrate` APIs (see [public_api_client_entry](public_api_client_entry.md)).
- **Requires SSR-compiled components.** `Ctor.render()` works "if the component is compiled in SSR mode" (per the in-code comment); rendering a client-compiled component via this path is unsupported.
- **CSS output difference.** Unlike Svelte 4, component CSS arrives inside `head` as `<style id="…">` elements produced by the Svelte 5 payload; `css.code` will always be empty string. Consumers that concatenate `css.code` must skip injection when it is empty.
- **No reactive semantics for `run()`.** Unlike the client `run()` (a `$effect.pre` wrapper with recursive-update warnings), the server `run()` executes once and discards the return value — cleanup functions returned by `fn` are never called.
- **`render()` is the only functional new behavior.** Everything else on the returned class inherits client-oriented behavior from `Svelte4Component`; calling its constructor during SSR will not mount anything meaningful.

---

## Source Reference

- File: `packages/svelte/src/legacy/legacy-server.js`
- Components: `asClassComponent`, `_render` (internal), `run`, `noop` (re-exported ×10), `createClassComponent` (re-export)
