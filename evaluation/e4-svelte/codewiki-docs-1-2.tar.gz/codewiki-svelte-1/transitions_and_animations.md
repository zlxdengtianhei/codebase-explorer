# Transitions and Animations System

## 1. Overview

The **transitions_and_animations** module is the public, user-facing motion layer of the Svelte framework. It supplies everything an application developer needs to create declarative visual effects in `.svelte` components:

- **Built-in transition functions** (`blur`, `fade`, `fly`, `slide`, `scale`, `draw`, `crossfade`) used with the `transition:`, `in:` and `out:` directives.
- **The `flip` animation function** used with the `animate:` directive on keyed `each` block children.
- **A library of 30+ easing functions** (`linear`, `cubicOut`, `elasticOut`, `bounceInOut`, …) that shape the timing curve of every transition and animation.

The module is intentionally *pure and side-effect free*: every function is a factory that receives a DOM node plus parameters, samples the node's current computed styles once, and returns a declarative **`TransitionConfig` / `AnimationConfig`** object (delay, duration, easing, and a `css(t, u)` or `tick(t, u)` callback). It contains **no state, no reactivity, and no DOM mutation logic** — the actual scheduling, playback and DOM style application is owned by the client DOM renderer (see [Component_Rendering_Backends_(Client_DOM___Server_SSR)](component_rendering_backends_client_dom___server_ssr.md)), which drives the Web Animations API using these configs.

This separation gives the module three valuable properties:

1. **Tree-shakeability** — an app that uses only `fade` never ships the code for `crossfade`, `draw`, or the easing library beyond what it imports.
2. **User extensibility** — because the contract is a plain config object, users can write custom transitions in their own code and they plug into the exact same runtime pipeline.
3. **SSR safety** — since configs are only computed in the browser, the module never needs a server counterpart; during SSR, transitions are simply ignored.

## 2. Module Structure

The module consists of three packages under `packages/svelte/src/`:

| Package | Purpose | Public surface |
|---|---|---|
| `transition/` | Built-in transitions for `transition:`/`in:`/`out:` directives + the `TransitionConfig` contract | 7 transition functions, 7 param interfaces |
| `animate/` | The `flip` animation for `animate:` directives + the `AnimationConfig` contract | `flip`, `FlipParams`, `AnimationConfig` |
| `easing/` | Pure mathematical timing functions shared by motion, transitions and animations | 30 easing functions |

Detailed documentation per sub-module:

- ➡️ **[Built-in Transition Functions](transitions_and_animations_transitions.md)** — `blur`, `fade`, `fly`, `slide`, `scale`, `draw`, `crossfade` and their parameter contracts.
- ➡️ **[Flip Animation](transitions_and_animations_flip.md)** — the First-Last-Invert-Play animation engine for keyed `each` blocks.
- ➡️ **[Easing Library](transitions_and_animations_easing.md)** — the complete catalogue of timing functions.

## 3. Architecture

### 3.1 Position in the overall system

```mermaid
flowchart LR
    subgraph User["User Land"]
        SRC[".svelte component<br/>transition:fly={{ y: 200 }}<br/>animate:flip"]
    end

    subgraph Compiler["Compiler Front-End / Back-End"]
        TV["TransitionDirective visitor<br/>(compiler_client_transform)"]
        AV["AnimateDirective handling<br/>(each block codegen)"]
    end

    subgraph Runtime["Client Runtime — DOM Renderer"]
        TM["$.transition()<br/>TransitionManager"]
        AM["$.animation()<br/>EachItem animation manager"]
        WAAPI["Web Animations API driver<br/>(animate loop, css function eval)"]
    end

    subgraph Module["transitions_and_animations (this module)"]
        T["transition/index.js<br/>blur · fade · fly · slide ·<br/>scale · draw · crossfade"]
        F["animate/index.js<br/>flip"]
        E["easing/index.js<br/>30 easing functions"]
    end

    SRC -->|compiled by| TV
    SRC -->|compiled by| AV
    TV -->|"$.transition(flags, el, thunk, params)"| TM
    AV -->|"$.animation(el, thunk, params)"| AM
    TM -->|"fn(node, params) → TransitionConfig"| T
    TM -.->|easing param| E
    AM -->|"fn(node, {from, to}) → AnimationConfig"| F
    F -->|"import cubicOut"| E
    T -.->|default easings| E
    TM --> WAAPI
    AM --> WAAPI
```

### 3.2 Execution lifecycle of a transition

```mermaid
sequenceDiagram
    participant C as Compiler
    participant R as Client Runtime ($.transition)
    participant M as Module (e.g. fly)
    participant D as DOM / Web Animations API

    Note over C: Build time
    C->>C: TransitionDirective visitor emits<br/>$.transition(flags, node, thunk, paramsThunk)

    Note over R,D: Client, element enters/leaves
    R->>R: Determine direction (in/out/both)<br/>& globality (local/global modifier)
    R->>M: thunk()(element, params)
    M->>M: getComputedStyle(node) — sample<br/>opacity, transform, height, etc. once
    M->>M: split_css_unit() for '100px'-style params
    M-->>R: TransitionConfig {delay, duration,<br/>easing, css(t,u)}
    R->>R: animate(config, counterpart, t_target, callback)
    loop Every animation frame
        R->>M: config.css(t, u) — evaluate inline styles
        M-->>R: CSS string (interpolated)
        R->>D: Apply styles / Animation keyframes
    end
    R->>D: introend / outroend events dispatched<br/>element.inert restored
```

### 3.3 Contract: the config object

Every function in this module converges on a single small interface — the entire integration surface with the runtime:

```ts
interface TransitionConfig {
    delay?: number;                      // ms before the animation starts
    duration?: number;                   // ms of playback
    easing?: (t: number) => number;      // from easing/index.js
    css?: (t: number, u: number) => string;   // t: eased progress (1→0 for out), u: 1 - t
    tick?: (t: number, u: number) => void;    // imperative alternative to css
}
```

- `t` is the *eased* progress of the transition: 0→1 for `in`, 1→0 for `out`.
- `u = 1 - t` lets authors write distance-proportional effects (`u * 100px`) without mirroring their math for in/out directions.
- `css` returns a string of inline styles applied as keyframes; `tick` is the JS-driven fallback when `css` cannot express an effect (e.g., imperative canvas work).

The runtime guarantees `css`/`tick` are invoked with values already passed through `delay`/`duration`/`easing`, so transition authors only implement the interpolation itself.

## 4. Sub-module Reference

### 4.1 Built-in Transition Functions — [`transitions_and_animations_transitions.md`](transitions_and_animations_transitions.md)

`packages/svelte/src/transition/`

Seven factory functions, each sampling computed styles at creation time so the transition always animates *from the element's actual current state*:

| Function | Effect | Distinctive mechanics |
|---|---|---|
| `blur` | Opacity + CSS `blur()` filter | `split_css_unit` accepts `'5px'` or `5` |
| `fade` | Opacity only | simplest possible `css(t)` |
| `fly` | translate(x, y) + opacity | preserves pre-existing `transform` |
| `slide` | Collapse/expand height *including* padding, margin and border widths | DEV-mode warning when `display: contents/inline/table` |
| `scale` | scale() + opacity | preserves pre-existing `transform` |
| `draw` | SVG `stroke-dashoffset` line drawing | supports `speed` and `duration(len)` callback, uses `getTotalLength()` |
| `crossfade` | Paired `send`/`receive` position+morph transitions | stateful — returns a `[send, receive]` tuple backed by two matching `Map`s, with `fallback` for unpaired nodes |

### 4.2 Flip Animation — [`transitions_and_animations_flip.md`](transitions_and_animations_flip.md)

`packages/svelte/src/animate/`

`flip(node, { from, to }, params)` implements the **First-Last-Invert-Play** technique for elements reordered inside keyed `each` blocks. The runtime measures the element's rect *before* the reorder (`from`) and *after* (`to`); `flip` computes the delta — respecting `transform-origin`, existing transforms and even the CSS `zoom` property via a parent-walk — and returns an `AnimationConfig` that translates and scales the element from its old visual position back to the new one. Default duration is distance-adaptive: `sqrt(distance) * 120ms`.

### 4.3 Easing Library — [`transitions_and_animations_easing.md`](transitions_and_animations_easing.md)

`packages/svelte/src/easing/`

Thirty pure `f(t) → number` functions across ten families (`back`, `bounce`, `circ`, `cubic`, `elastic`, `expo`, `linear`, `quad`, `quart`, `quint`, `sine`), each with `In`/`Out`/`InOut` variants (adapted from mattdesl/eases, MIT). They are the default easing of nearly every transition (`cubic_out` for `fly`/`slide`/`scale`/`crossfade`/`flip`, `cubic_in_out` for `blur`/`draw`, `linear` for `fade`) and are re-exported for user-authored transitions. `transition/index.js` privately duplicates `linear`, `cubic_out`, `cubic_in_out` as an internal optimisation.

## 5. Integration with Other Modules

| Direction | Module | Interaction |
|---|---|---|
| Consumed by | [Component_Rendering_Backends_(Client_DOM___Server_SSR)](component_rendering_backends_client_dom___server_ssr.md) → `client_dom_renderer_elements_and_events` | `dom/elements/transitions.js` calls the module's factories from `$.transition()` / `$.animation()` and drives playback; `dom/css.js` handles style clean-up |
| Fed by | [Compiler_Front-End_(Parsing,_Analysis___CSS_Scoping_Pipeline)](compiler_front-end_parsing__analysis___css_scoping_pipeline.md) → `compiler_client_transform_elements_and_directives` | The `TransitionDirective` codegen visitor lowers `transition:fly={{y:200}}` into `$.transition(TRANSITION_IN \| TRANSITION_OUT, node, thunk(fly), thunk({y: 200}))` |
| Sibling | [Motion___Visual_Effects_System](Motion___Visual_Effects_System.md) → `motion_spring`, `motion_tweened` | `tweened`/`spring` are *reactive* interpolators (drive values over time via effects); this module is *temporal* (drives styles per frame for mount/unmount/move). Both share the easing library's conventions |
| Types surfaced | [Public_API_Surface___Compatibility_Layer](public_api_surface___compatibility_layer.md) | `TransitionConfig`, `BlurParams`, `FlipParams`, `CrossfadeParams`, etc. are re-exported through `packages/svelte/types/index.d.ts` |
| Diagnostics | Reactive_Runtime dev warnings | `slide` triggers `transition_slide_display` via `internal/client/warnings.js` in DEV builds only |

### 5.1 Crossfade vs. flip: two sides of "move"

Both `crossfade` and `flip` animate an element between two positions, but at different layers:

```mermaid
flowchart TD
    subgraph crossfade["crossfade (this module)"]
        C1["Developer pairs items manually<br/>send(node,{key}) / receive(node,{key})"] --> C2["Module keeps send/receive Maps<br/>computes rect delta itself"]
    end
    subgraph flipRun["flip (runtime-orchestrated)"]
        F1["each block move"] --> F2["Runtime measures before/after rects<br/>(EachItem measure/apply/fix/unfix)"]
        F2 --> F3["Module only computes<br/>the invert transform"]
    end
```

`crossfade` *owns the pairing state* (two `Map`s keyed by an arbitrary `key` param) and coordinates between two lists; `flip` is stateless and receives its `{from, to}` rects from the `each` block manager, which also performs the temporary `position: absolute` "fix/unfix" dance so transforms compute correctly.

## 6. Design Notes & Conventions

- **Style sampling once, interpolation many times.** `getComputedStyle` is called in the factory body, not inside `css(t, u)` — cheap per-frame evaluation.
- **`split_css_unit`** (`'12px'` → `[12, 'px']`) lets numeric *and* unit-string parameters coexist for `blur.amount`, `fly.x/y`.
- **Existing transforms are preserved**: `fly`, `scale`, `crossfade`, `flip` all read `style.transform === 'none' ? '' : style.transform` and prepend it, so transitions compose with the element's static styling.
- **Functional durations**: `draw` and `crossfade` accept `duration: (len) => ms`, allowing distance/length-adaptive timing; `flip` defaults to it.
- **Graceful abort semantics**: the runtime may abort an intro with a running outro (and vice versa); configs are treated as immutable snapshots — a re-trigger re-invokes the factory via `get_options()` caching in the `TransitionManager`.
- **DEV-only instrumentation** is compiled away: `import { DEV } from 'esm-env'` guards the `slide` display warning, keeping production bundles lean.
- **Tree-shakeability**: every export is an isolated, top-level, side-effect-free function (verified by the repo's `check-treeshakeability` script in [Repository_Engineering_Infrastructure](repository_engineering_infrastructure_benchmarks__build_scripts___playground.md)).
