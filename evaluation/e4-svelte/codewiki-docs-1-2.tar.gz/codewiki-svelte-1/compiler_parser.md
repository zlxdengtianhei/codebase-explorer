# compiler_parser — Svelte Compiler Front-End (Phase 1: Parsing)

## 1. Purpose & Scope

`compiler_parser` is the **first phase of the Svelte compiler** (`packages/svelte/src/compiler/phases/1-parse/`). It converts raw Svelte source code — a single-file component mixing markup, `{...}` expressions/blocks, `<script>` logic and `<style>` sheets — into a structured **Abstract Syntax Tree (AST)** rooted in `AST.Root`.

It is a *hand-written, single-pass, state-machine* template parser combined with an *acorn-based* JavaScript/TypeScript parser. Its contract is narrow but critical:

- **Input**: `string` template source (+ `loose` flag for editor/language-tooling scenarios).
- **Output**: `AST.Root` — the template fragment tree, the parsed `instance`/`module` script `Program`s, the raw CSS `StyleSheet` node, and the validated `<svelte:options>` — with **precise character offsets (`start`/`end`)** on every node for diagnostics and source maps.
- **Errors**: Raises `CompileError`s (via the shared diagnostics module) for malformed markup; in `loose` mode it recovers where possible so editors get partial results.

Key design goals visible in the code:

| Goal | How it is achieved |
|---|---|
| Exact source positions | Every node records `start`/`end`; script sources are offset-padded so acorn reports positions relative to the whole file |
| Comment preservation | acorn `onComment` captures all JS comments and a post-parse walk re-attaches them as `leadingComments`/`trailingComments` (needed for `svelte-ignore` and Prettier compatibility) |
| Editor friendliness (`loose` mode) | The state machine backtracks (e.g. a mis-parsed `<` attribute), tolerates unclosed tags and partially typed expressions |
| TS support without emitting TS | TypeScript is parsed with `@sveltejs/acorn-typescript`, then TS-only nodes are *stripped* by `remove_typescript_nodes` before later phases |
| Helpful errors | A fuzzy matcher (n-gram `FuzzySet`) suggests "did you mean …?" alternatives for invalid names |

## 2. Position in the Compiler Pipeline

The parser is the entry point of the compiler **front-end**. Its `AST.Root` feeds the analysis phase, which feeds the CSS pipeline and the code-generation back-end:

```mermaid
flowchart LR
    SRC["Svelte source\n(.svelte file)"] --> P["**compiler_parser**\n(1-parse)\nstate machine + acorn"]
    P --> ROOT["AST.Root\nfragment · instance/module\nCSS · options · comments"]
    ROOT --> A["compiler_analyzer\n(2-analyze)\nscoping, warnings, validation"]
    A --> CSS["compiler_css_pipeline\nCSS scoping & pruning"]
    ROOT --> CSS
    A --> T["compiler_client_transform /\ncompiler_server_transform\n(3-transform)"]
    CSS --> T
    T --> OUT["Compiled JS\nclient & server"]
```

Cross-references to sibling modules (do not re-document here):

- Diagnostics raised while parsing (`element_unclosed`, `block_unclosed`, `js_parse_error`, `svelte_options_*`, …) come from **[compiler_diagnostics](compiler_diagnostics.md)**; `state.set_source()` registers the source there so `CompileError`s can render code frames.
- Node factories used while building the AST (`create_fragment`, `create_attribute`, `create_expression_metadata`) come from the shared `phases/nodes.js` helpers, part of the **[compiler_core](compiler_core.md)** infrastructure.
- The exact shape of every produced node (`Root`, `RegularElement`, `Component`, `ExpressionTag`, `Text`, directives, `Script`, `StyleSheet`, …) is defined by **[compiler_types](compiler_types.md)** (`types/template.d.ts`, `types/css.d.ts`).
- Downstream consumers: **[compiler_analyzer](compiler_analyzer.md)**, **[compiler_css_pipeline](compiler_css_pipeline.md)**, **[compiler_client_transform](compiler_client_transform.md)** / **[compiler_server_transform](compiler_server_transform.md)**.

## 3. Architecture Overview

The module has three cooperating layers. The hand-written state machine owns the markup; whenever it hits embedded code it delegates to the acorn layer; shared leaf utilities handle options, entities and error suggestions.

```mermaid
flowchart TB
    subgraph SM["Template State Machine (hand-written)"]
        ENTRY["parse(template, loose)\n1-parse/index.js"] --> FSM["Parser.loop\nstate = state(parser)"]
        FSM --> FRAG["fragment.js\nrouter"]
        FRAG -->|"&lt;"| ELEM["element.js\nelements, attributes,\ndirectives, script/style"]
        FRAG -->|"{"| TAG["tag.js\n{expr} {#block} {:…} {/block} {@…}"]
        FRAG -->|"else"| TEXT["text.js\nraw text + entities"]
        ELEM --> FSM
        TAG --> FSM
        TEXT --> FSM
    end

    subgraph JS["JS / TS Processing (acorn-based)"]
        EXPR["read/expression.js"] --> ACORN["acorn.js\nparse / parse_expression_at\ncomment re-attachment"]
        SCRIPT["read/script.js"] --> ACORN
        ACORN --> TSSTRIP["remove_typescript_nodes.js\nstrip TS-only syntax"]
    end

    ELEM -->|"&lt;script&gt; content"| SCRIPT
    ELEM -->|"attribute values,\nmustache tags"| EXPR
    TAG --> EXPR

    subgraph UTIL["Parse Utilities"]
        OPT["read/options.js\n&lt;svelte:options&gt; validation"]
        ENT["utils/html.js\nentity decoding"]
        FUZZ["utils/fuzzymatch.js\nsuggestions"]
    end

    ENTRY --> OPT
    ELEM --> ENT
    TEXT --> ENT
    SM -.->|"errors + suggestions"| FUZZ
    ENTRY -.->|"set_source → code frames"| DIAG["compiler_diagnostics"]
```

### 3.1 The parser loop and state functions

`parse()` (in `1-parse/index.js`) sets up shared source state for diagnostics, then constructs the `Parser` class whose constructor **is** the parsing loop:

```mermaid
sequenceDiagram
    participant C as compile() caller
    participant parse as parse(template, loose)
    participant S as compiler/state.js (set_source)
    participant P as Parser
    participant St as state fns (fragment/element/tag/text)

    C->>parse: template string
    parse->>S: set_source(template) → locator for code frames
    parse->>P: new Parser(template, loose)
    Note over P: detect lang="ts" → ts flag<br/>create AST.Root skeleton + empty Fragment<br/>push Root onto stack & fragments
    loop while index < template.length
        P->>St: state = state(parser)
        St-->>P: next state (or void → fragment)
        Note over St: append AST nodes to current Fragment<br/>push/pop element & fragment stacks
    end
    Note over P: unclosed element/block → error or loose recovery<br/>trim Root.start/end to first/last node<br/>extract <svelte:options> via read_options()
    P-->>C: parser.root (AST.Root)
```

State functions are pure-ish functions of type `(parser: Parser) => ParserState | void`; returning nothing falls back to `fragment`, the router state:

- **`fragment`** (`state/fragment.js`) — the dispatcher: `<` → `element`, `{` → `tag`, anything else → `text`.
- **`element`** (`state/element.js`) — the largest state: comments, closing tags (with implicit-close auto-pop logic, e.g. `<div><p></div>`), opening tags, node-type resolution (`RegularElement`, `Component`, `svelte:*` meta tags, `SlotElement`, `TitleElement`), attribute/directive reading, special raw-text bodies (`<textarea>`, nested `<script>`/`<style>`) and top-level `<script>`/`<style>` hoisting into `Root`.
- **`tag`** (`state/tag.js`) — `{expression}`, block openers `{#if}/{#each}/{#await}…`, continuation `{:else}…`, closers `{/if}…` and special tags `{@const} {@debug} {@render} {@attach}`.
- **`text`** (`state/text.js`) — accumulates raw characters until `<` or `{`, then emits an `AST.Text` node with entity-decoded `data` and preserved `raw`.

The `Parser` class also exposes the low-level scanning vocabulary used by all states: `eat`, `match`, `match_regex`, `read`, `read_until`, `read_identifier`, `allow_whitespace`, `require_whitespace`, plus the stack helpers `current()`, `push` (via states), `pop()`, and `append()` which appends a node to the innermost open `Fragment`.

### 3.2 Embedded code: delegation to acorn

- Attribute values and mustache tags call `read_expression()` (`read/expression.js`), which delegates to `parse_expression_at()` in `acorn.js`, handles leading comments and balances closing parentheses before resuming template scanning.
- A top-level `<script>` is read as raw text (`read/script.js`), its source is **offset-padded** (everything before the script body is replaced with spaces so acorn's positions match the original file), then parsed via `acorn.parse(...)` with `is_script = true`.
- `acorn.js` additionally patches `parser.prototype.parseStatement` in script mode so stray `export`s (allowed in Svelte components) do not throw.
- For `lang="ts"`, the TypeScript acorn plugin is used; afterwards `remove_typescript_nodes()` walks the `Program` with `zimmerframe` and rewrites it to plain JS: deleting annotations, unwrapping `TSAsExpression`/`TSSatisfiesExpression`/`TSNonNullExpression`, dropping type-only imports/exports/interfaces/aliases/declare members, removing `this` parameters, and erroring on unsupported features (enums, decorators, namespaces with runtime nodes, `accessor` fields, constructor parameter properties).

### 3.3 The output `AST.Root`

```mermaid
flowchart LR
    R["AST.Root"] --> F["fragment: Fragment\n(Text · ExpressionTag · elements · blocks · comments)"]
    R --> I["instance: Script\n(default <script> → estree Program)"]
    R --> M["module: Script\n(<script context="module" | module>)"]
    R --> CSS["css: StyleSheet\nraw styles + CSS node tree"]
    R --> O["options: SvelteOptions\nvalidated <svelte:options>"]
    R --> CM["comments: JSComment[]\n(start/end located)"]
    R --> MD["metadata.ts\nTypeScript flag"]
```

## 4. Sub-modules

The module splits cleanly into three sub-modules. Detailed documentation:

| Sub-module | Files | Responsibility |
|---|---|---|
| **[compiler_parser_template_state_machine](compiler_parser_compiler_parser_template_state_machine.md)** | `1-parse/index.js`, `state/fragment.js`, `state/element.js`, `state/text.js` | The `Parser` class, the state-function loop, node-type resolution, attribute/directive parsing and recovery behaviour |
| **[compiler_parser_js_ts_processing](compiler_parser_js_ts_processing.md)** | `acorn.js`, `remove_typescript_nodes.js` (with `read/expression.js`, `read/script.js`) | JavaScript/TypeScript expression and script parsing, comment attachment, TS syntax stripping |
| **[compiler_parser_parse_utilities](compiler_parser_parse_utilities.md)** | `read/options.js`, `utils/fuzzymatch.js`, `utils/html.js` | `<svelte:options>` validation, fuzzy "did you mean" suggestions, HTML character-reference decoding |

## 5. End-to-End Data Flow

```mermaid
flowchart TD
    A["raw template"] --> B["set_source() → diagnostics locator"]
    A --> C{"Parser loop\n(fragment router)"}
    C -->|"&lt;!-- comment --&gt;"| D["AST.Comment"]
    C -->|"text run"| E["AST.Text\ndata = decode_character_references(raw)"]
    C -->|"{expr}"| F["AST.ExpressionTag\nexpression parsed by acorn"]
    C -->|"{#if}/{#each}/…"| G["AST block nodes\nbuilt by tag.js helpers"]
    C -->|"&lt;tag attr=… bind:… on:… {…spread} {@attach}"| H["AST.RegularElement / Component /\nsvelte:* meta · directives · SpreadAttribute · AttachTag"]
    H -->|"top-level &lt;script&gt;"| I["read_script → acorn.parse\n(+ remove_typescript_nodes if ts)\n→ Root.instance / Root.module"]
    H -->|"top-level &lt;style&gt;"| J["read_style → AST.StyleSheet\n→ Root.css"]
    D --> K["AST.Root"]
    E --> K
    F --> K
    G --> K
    H --> K
    I --> K
    J --> K
    C -->|"&lt;svelte:options …&gt;"| L["read_options() → validated\nRoot.options"]
    L --> K
    K --> N["hand-off to compiler_analyzer\n(2-analyze)"]
```

## 6. Error Handling & Recovery Strategy

- **Strict mode (default)**: any structural problem raises a `CompileError` through `compiler_diagnostics` — e.g. `element_unclosed`, `block_unclosed` (referenced from `errors.js`), `element_invalid_closing_tag`, `attribute_duplicate`, `unexpected_eof`. Because `set_source()` ran first, these errors render code frames with line/column.
- **Loose mode (`parse(template, true)`)**: used by language tooling while the user is mid-typing. Behaviours include: tolerating unclosed tags/blocks (fragment ends at EOF), backtracking when a `<` of the *next* element was consumed as an attribute name, allowing incomplete identifiers (`<div.`), and letting expression reads fall back to a synthetic identifier via `get_loose_identifier`.
- **Implicit-close rules**: when a closing tag matches an ancestor instead of the current element, currently open elements are auto-closed (`w.element_implicitly_closed` warning + `last_auto_closed_tag` bookkeeping), mirroring HTML's optional-end-tag semantics (`html-tree-validation.js`).
- **Suggestions**: unknown directive/meta names feed `fuzzymatch()`, which returns the closest known name above a 0.7 similarity threshold for "did you mean" diagnostics.

## 7. Related Modules

- **[compiler_diagnostics](compiler_diagnostics.md)** — all errors/warnings raised here, code-frame rendering, source registration.
- **[compiler_core](compiler_core.md)** — node factories, AST builder helpers, compile orchestration entry (`compileModule`).
- **[compiler_types](compiler_types.md)** — the `AST.*` node contracts produced by this parser.
- **[compiler_analyzer](compiler_analyzer.md)** — phase 2 consumer; fills in per-expression metadata (`dependencies`, `has_state`, …) initialised by `create_expression_metadata()` during parsing.
- **[compiler_css_pipeline](compiler_css_pipeline.md)** — consumes the `StyleSheet` node emitted by `read_style`.
- **[compiler_client_transform](compiler_client_transform.md)** / **[compiler_server_transform](compiler_server_transform.md)** — phase 3 consumers of the final analyzed AST.
- **[compiler_preprocess](compiler_preprocess.md)** — typically runs *before* this parser (e.g. for TypeScript via external preprocessor, legacy `lang` handling).
