# Client DOM Renderer — DOM Foundation

> **Module:** `client_dom_renderer_dom_foundation`
> **Location:** `packages/svelte/src/internal/client/dom/` (`hydration.js`, `operations.js`, `template.js`, `css.js`)
> **Parent layer:** [Component Rendering Backends (Client DOM / Server SSR)](client_dom_renderer.md)

---

## 1. Introduction

The **DOM foundation** module is the lowest-level layer of Svelte 5's client-side renderer. It provides the primitive building blocks that every other part of the client runtime — control-flow blocks, element/directive handling, bindings, and the lifecycle API — uses to create, navigate, and hydrate DOM nodes.

Its four files have sharply separated responsibilities:

| File | Responsibility |
|---|---|
| `operations.js` | Low-level node creation & navigation primitives, plus lazy browser-environment initialization |
| `hydration.js` | Global hydration state machine: the `hydrating` flag and the `hydrate_node` cursor used to walk server-rendered HTML |
| `template.js` | Lazy template factories that turn compiler-emitted template strings / tree structures into live DOM clones |
| `css.js` | Scoped component CSS injection into the document head or shadow roots |

The module is built around a single defining idea: **dual-mode execution**. Every navigation or creation function branches on the module-level `hydrating` flag — either *walking* the DOM that was already rendered on the server (hydration) or *cloning* pre-parsed template fragments (pure client-side rendering). This allows the exact same compiled component code to run in both modes without branching at the component level.

---

## 2. Module Architecture

```mermaid
flowchart TB
    subgraph foundation["client_dom_renderer_dom_foundation"]
        direction TB
        HYD["hydration.js<br/>─────<br/>hydrating / hydrate_node<br/>hydrate_template · next · reset<br/>hydrate_next · set_hydrate_node<br/>remove_nodes · read_hydration_instruction"]
        OPS["operations.js<br/>─────<br/>init_operations · $window / $document<br/>child · first_child · sibling<br/>create_element · create_fragment<br/>create_comment · create_text<br/>set_attribute · clear_text_content<br/>should_defer_append"]
        TPL["template.js<br/>─────<br/>from_html · from_svg · from_mathml · from_tree<br/>text · comment · append · assign_nodes<br/>props_id · with_script / run_scripts"]
        CSS["css.js<br/>─────<br/>append_styles"]
        REC["reconciler.js<br/>(internal helper)<br/>create_fragment_from_html"]
    end

    HYD <-->|"cursor state read/written<br/>by every traversal"| OPS
    OPS -->|"parse HTML strings"| REC
    TPL -->|"create/navigate nodes"| OPS
    TPL -->|"read & advance cursor"| HYD
    CSS -->|"creates effect to inject<br/><style> near anchor"| OPS

    style foundation fill:#1a1a2e,stroke:#e94560,color:#fff
    style HYD fill:#16213e,stroke:#0f3460,color:#fff
    style OPS fill:#16213e,stroke:#0f3460,color:#fff
    style TPL fill:#16213e,stroke:#0f3460,color:#fff
    style CSS fill:#16213e,stroke:#0f3460,color:#fff
    style REC fill:#0f3460,stroke:#e94560,color:#fff
```

### 2.1 Component responsibilities in detail

#### `hydration.js` — the hydration cursor

- **`hydrating`** — module-level boolean gate. Importantly, it is exported via `let` with a `set_hydrating` setter so that *all* hydration machinery can be **tree-shaken away** when the application never calls `hydrate()` (see the comment in the source: *"guard everything related to hydration code so it can be treeshaken out"*).
- **`hydrate_node`** — the "read cursor" into the server-rendered DOM. It starts as the node inside the opening `<!--[-->` hydration marker and is advanced by `child()`, `sibling()`, `hydrate_next()` and `next()` as the component tree claims its nodes.
- **`set_hydrate_node`** — single guarded write path; a `null` node triggers `hydration_mismatch` warning and throws the `HYDRATION_ERROR` sentinel (a `Symbol`, not an `Error`, so the recovery logic in `hydrate()` can distinguish it from real exceptions).
- **`reset(node)`** — verifies the subtree was fully consumed (no remaining siblings) and rewinds the cursor to `node`. Used when entering/leaving fragments so a mismatch (e.g. SSR HTML that does not match the component) fails loudly.
- **`hydrate_template(template)`** — entry point for `TemplateEffect`s during hydration: adopts `template.content` as the hydration target.
- **`next(count)`** — advances the cursor `count` siblings ahead without claiming; used to skip over SSR content the client renderer does not materialize.
- **`remove_nodes()`** — removes all DOM from the cursor up to the matching `<!--]-->` end marker (nesting-aware via depth counting), returning the end anchor. Used when a hydrated branch must be discarded/recreated.
- **`read_hydration_instruction(node)`** — validates that a node is the expected comment marker and returns its `data` (`HYDRATION_START`, `HYDRATION_START_ELSE`, `HYDRATION_END`).

Markers emitted by the SSR renderer: `<!--[-->` (`HYDRATION_START`), `<!--[-->` variants for else branches (`HYDRATION_START_ELSE`), `<!--]-->` (`HYDRATION_END`).

#### `operations.js` — node primitives & environment bootstrap

- **`init_operations()`** — idempotent, lazy initialization (avoids crashing in non-browser environments / eliminates a separate server entry point):
  - caches `$window`, `$document`, and a Firefox detection flag;
  - extracts **prototype getter functions** for `firstChild` / `nextSibling` from `Node.prototype` descriptors — calling the raw getter is measurably faster than property access and bypasses userland wrappers;
  - reserves hidden cache slots on prototypes used by the renderer for O(1) lookups: `Element.prototype.__click` (delegated event handlers), `__className`, `__attributes`, `__style`, `__e` (event map), `Text.prototype.__t` (cached text content);
  - in `DEV`, installs `__svelte_meta` and array-mutation warnings (see [client_dev_mode_validation](client_dev_mode_validation.md)).
- **Navigation:** `child(node, is_text)`, `first_child(fragment, is_text)`, `sibling(node, count, is_text)` — the dual-mode core. When *not* hydrating they are plain getters (and are annotated `/*@__NO_SIDE_EFFECTS__*/` so bundlers may drop them); when *hydrating* they instead advance/validate `hydrate_node`. A critical hydration subtlety: **empty expressions** (`{expr}` that rendered as nothing during SSR) have no text node in the HTML — these functions synthesize and insert an empty `Text` node so the client renderer still holds a live anchor to update later.
- **Creation:** `create_element` (with optional namespace + `is`), `create_fragment`, `create_comment`, `create_text`, `clear_text_content`.
- **`set_attribute`** — sets an attribute, transparently routing `xlink:*` keys through `setAttributeNS` (SVG compatibility).
- **`should_defer_append()`** — consults `async_mode_flag` and batch state (`eager_block_effects`, `active_effect`'s `EFFECT_RAN` flag) to decide whether branch switches inside an `<svelte:boundary>` should be batched together — connecting this low-level module to the [batching system](client_runtime_core_batching.md).

#### `template.js` — compiled-template instantiation

Compiled components embed their markup as strings or tree structures (see [compiler_client_transform_templates](compiler_client_transform_templates.md)). This file lazily materializes them:

- **`from_html(content, flags)`** — returns a factory closure. On first call it parses `content` via `create_fragment_from_html` (which replaces `<!>` with `<!---->` for XHTML compliance inside `<template>` elements) and caches the result; every subsequent call returns a **deep clone** (`cloneNode(true)`, or `document.importNode` when `TEMPLATE_USE_IMPORT_NODE` is set or on Firefox). Fragment templates (`TEMPLATE_FRAGMENT`) yield `Node[]` with distinct start/end nodes; otherwise a single node.
- **`from_svg` / `from_mathml`** — namespace-aware variants wrapping content in `<svg>`/`<math>` so the HTML parser assigns correct element namespaces, then unwrapping.
- **`from_tree(structure, flags)`** — builds DOM programmatically from a JSON `TemplateStructure` (nested `[tag, attributes, ...children]` arrays) instead of parsing HTML — used when `preserveComments` or similar options make string templates unsuitable. Handles `<template>` content targets, `foreignObject` namespace resets, and comment items (`'// <data>'`).
- **`text(value)` / `comment()`** — claim-or-create primitives for expression anchors. `comment()` creates a start-comment + text anchor fragment; during hydration both simply *claim* the existing cursor node.
- **`assign_nodes(start, end)`** — writes the claimed/created node span onto the **active effect** (`effect.nodes_start` / `effect.nodes_end`) only if not already set. This is the mechanism by which unmount/removal later knows which DOM a block owns (consumed by `unmount` in [client_dom_renderer_lifecycle_api](client_dom_renderer_lifecycle_api.md)).
- **`append(anchor, dom)`** — inserts a built fragment before `anchor` in client mode; in hydration mode it finalizes `nodes_end` and advances the cursor via `hydrate_next()`.
- **`props_id()`** — returns the component instance's scoping UID: during hydration it is recovered from the `#<id>` comment the SSR renderer emitted (keeping class scoping stable across SSR/client); otherwise generated from a runtime-global counter (`window.__svelte.uid`).
- **`with_script(fn)` / `run_scripts(node)`** — wraps template factories whose HTML contains `<script>` tags; since scripts inserted via fragments never execute, each script is cloned/replaced so the browser runs it, patching `nodes_start`/`nodes_end` if edge scripts were replaced. No-op while hydrating (SSR'd scripts already ran).

#### `css.js` — scoped style injection

- **`append_styles(anchor, css)`** — schedules an `effect` that, once `anchor` is connected, locates the correct style root via `anchor.getRootNode()`: a `ShadowRoot` (custom elements / shadow-DOM usage) or the document `head`. It inserts `<style id={css.hash}>` with the compiled CSS if not already present (querying the DOM each time by design — roughly equal performance to map-caching with less code). In `DEV` the style element is registered for HMR cleanup (see [client_dev_mode_hmr](client_dev_mode_hmr.md)).

---

## 3. Position in the System

```mermaid
flowchart LR
    subgraph compiler["Compiler (build time)"]
        CT["3-transform/client<br/>emits calls to $ template API<br/>+ template strings"]
    end

    subgraph lifecycle["Lifecycle API"]
        MOUNT["mount()"]
        HYDRATE["hydrate()"]
        UNMOUNT["unmount()"]
    end

    subgraph foundation["DOM Foundation (this module)"]
        OPS["operations.js"]
        HYD["hydration.js"]
        TPL["template.js"]
        CSS["css.js"]
    end

    subgraph consumers["Renderer layers built on top"]
        BLOCKS["Control-flow blocks<br/>(if · each · key · await · snippet · slot …)"]
        ELEMS["Elements & Events"]
        BIND["Bindings"]
    end

    subgraph runtime["Reactive Runtime"]
        EFF["effects.js — active_effect"]
        BATCH["batch.js — eager_block_effects"]
        FLAGS["flags — async_mode_flag"]
    end

    CT -->|"$.from_html, $.text,<br/>$.comment, $.append,<br/>$.append_styles, $.child, $.sibling"| foundation
    HYDRATE -->|"set_hydrating(true),<br/>walk markers, cursor advance"| HYD
    MOUNT & UNMOUNT --> OPS
    foundation --> BLOCKS & ELEMS & BIND
    EFF & BATCH & FLAGS --> foundation

    style foundation fill:#1a1a2e,stroke:#e94560,color:#fff
```

**Upstream producers:**
- The **compiler's client transform** generates component code that calls exactly these primitives (`$.from_html("<div>…</div>", flags)`, `$.text(expr)`, `$.comment()`, `$.append(anchor, frag)`, `$.append_styles(anchor, css)`). See [compiler_client_transform_templates](compiler_client_transform_templates.md).
- The **server renderer** is the symmetric counterpart: its `element`, `attr_class`, `spread_attributes`, etc. produce the HTML *and* the `<!--[-->`/`<!--]-->` markers that this module consumes during hydration. See [server_runtime](server_runtime.md).

**Downstream consumers:**
- [client_dom_renderer_lifecycle_api](client_dom_renderer_lifecycle_api.md) — `hydrate()`/`mount()` drive the cursor; `unmount()` consumes `nodes_start`/`nodes_end` spans.
- [client_dom_renderer_control_flow_blocks](client_dom_renderer_control_flow_blocks.md) — `if_block`, `each`, `key`, `await_block`, `snippet`, `slot` all claim anchors via `child`/`sibling`/`comment` and register node spans through `assign_nodes`.
- [client_dom_renderer_elements_and_events](client_dom_renderer_elements_and_events.md) — attribute/effects layer relies on `set_attribute`, the `__click`/`__attributes` cache slots, and `event` delegation initialized by `init_operations`.
- [client_dom_renderer_bindings](client_dom_renderer_bindings.md) — bindings read/write through the same `__attributes`/`__style` slots.

**Lateral dependencies:**
- [client_runtime_core](client_runtime_core.md) — `active_effect` (node-span ownership), `effect()` (CSS injection), `eager_block_effects` (deferred appends), `run_tasks`-adjacent scheduling.
- [client_runtime_core_batching](client_runtime_core_batching.md) — `should_defer_append()` coordinates branch swaps with `<svelte:boundary>` batching.
- [shared_runtime](shared_runtime.md) — `flags` (`async_mode_flag`), shared utils (`get_descriptor`, `is_extensible`), `DEV` from `esm-env`.
- [client_dev_mode](client_dev_mode.md) — dev-only style registration, array prototype warnings, element location tagging.

---

## 4. Dual-Mode Data Flow

The heart of the module is that compiled code is *mode-agnostic*: the branch happens inside these primitives.

```mermaid
flowchart TD
    START(["Compiled template call<br/>e.g. $.from_html('<p>')()"]) --> Q{"hydrating?"}

    Q -->|"no — client mode"| CLONE["Clone cached template node<br/>(cloneNode / importNode)"]
    CLONE --> ASSIGN["assign_nodes(clone, clone | start, end)<br/>→ effect.nodes_start / nodes_end"]

    Q -->|"yes — hydration mode"| CLAIM["Claim hydrate_node<br/>(already rendered by SSR)"]
    CLAIM --> ASSIGN

    ASSIGN --> NAV{"Navigation:<br/>child / sibling / first_child"}
    NAV -->|"client"| GET["Prototype getters<br/>firstChild / nextSibling"]
    NAV -->|"hydration"| CURSOR["Advance hydrate_node cursor<br/>(set_hydrate_node, mismatch → warn + HYDRATION_ERROR)"]

    GET --> DONE(["Nodes owned by active effect"])
    CURSOR --> GAP{"Empty SSR expression?<br/>(missing Text node)"}
    GAP -->|"yes"| SYNTH["Insert empty Text node<br/>as live anchor"]
    GAP -->|"no"| DONE
    SYNTH --> DONE

    style Q fill:#e94560,color:#fff
```

---

## 5. Process Flows

### 5.1 Hydration sequence (end to end)

```mermaid
sequenceDiagram
    autonumber
    participant App as Application
    participant H as hydrate() (lifecycle API)
    participant HS as hydration.js
    participant OPS as operations.js
    participant C as Component code
    participant T as template.js

    App->>H: hydrate(Component, { target })
    H->>OPS: init_operations()
    H->>OPS: scan target for <!--[--> HYDRATION_START
    H->>HS: set_hydrating(true)
    H->>HS: set_hydrate_node(startMarker) → hydrate_next()
    H->>C: mount(component, { anchor })

    loop over compiled template effects
        C->>T: template factory / $.text / $.comment
        T->>HS: read hydrate_node (claim)
        T->>T: assign_nodes → effect.nodes_start/end
        C->>OPS: child(node, is_text) / sibling(node, count)
        OPS->>HS: set_hydrate_node(next sibling)
        Note over OPS: missing Text node for empty<br/>expression → synthesize one
    end

    C-->>H: done
    H->>HS: check cursor === <!--]--> HYDRATION_END
    alt mismatch
        H->>HS: hydration_mismatch warning<br/>+ throw HYDRATION_ERROR
    end
    H->>HS: set_hydrating(false)
    H-->>App: component instance exports

    Note over H: on any hydration failure:<br/>recover=true → clear target & mount() from scratch<br/>recover=false → hydration_failed error
```

### 5.2 Template materialization (client mode)

```mermaid
flowchart TD
    A["Compiler emitted:<br/>const root = $.from_html('&lt;div class=…&gt;…&lt;/div&gt;', flags)"] --> B{"Factory called<br/>first time?"}
    B -->|"yes"| C["create_fragment_from_html(content)<br/>-&lt;template&gt;.innerHTML, &lt;!&gt; → &lt;!----&gt;"]
    C --> D{"flags"}
    D -->|"TEMPLATE_FRAGMENT"| E["keep DocumentFragment<br/>start = firstChild, end = lastChild"]
    D -->|"single root"| F["unwrap firstChild as root node"]
    D -->|"TEMPLATE_USE_IMPORT_NODE<br/>or Firefox"| G["document.importNode(node, true)"]
    B -->|"no (cached)"| H
    E & F --> H["cloneNode(true)"]
    G --> H
    H --> I["assign_nodes(start, end)<br/>→ active_effect.nodes_start/nodes_end"]
    I --> J(["Return clone for insertion<br/>($.append places it before anchor)"])

    style A fill:#16213e,stroke:#0f3460,color:#fff
    style I fill:#e94560,color:#fff
```

### 5.3 Scoped CSS injection

```mermaid
flowchart LR
    A["Compiled component:<br/>$.append_styles(anchor, {hash, code})"] --> B["create effect(...)"]
    B --> C["anchor.getRootNode()"]
    C --> D{"root.host?"}
    D -->|"ShadowRoot"| E["target = shadow root"]
    D -->|"Document / detached"| F["target = document.head<br/>(ownerDocument.head fallback)"]
    E & F --> G{"'style#' + hash present?"}
    G -->|"no"| H["append <style id=hash><br/>textContent = code"]
    G -->|"yes"| I["skip (dedup across instances)"]
    H --> J["DEV: register_style for HMR cleanup"]
    style B fill:#e94560,color:#fff
```

---

## 6. Key Design Concepts

### 6.1 Hydration markers as block anchors
SSR output interleaves `<!--[-->` / `<!--]-->` comments marking block boundaries. During hydration these comments become the **anchors** that control-flow blocks attach branches to — the same anchors that, in client-only mode, are created by `$.comment()`. When hydration succeeds, the cursor naturally rests on the closing marker, which `reset()` and `hydrate()` validate (see [client_dom_renderer_control_flow_blocks](client_dom_renderer_control_flow_blocks.md)).

### 6.2 Effect-owned node spans
Every DOM-producing call routes through `assign_nodes`, which stamps `nodes_start`/`nodes_end` on the currently active effect **once**. This span-based ownership is what makes unmounting an entire component or block a simple range removal — the reactive runtime itself never touches the DOM directly.

### 6.3 Empty-expression synthesis
SSR omits text nodes for expressions that rendered empty (e.g. `<p>{text}</p>` with `text === ''`). The navigation functions in `operations.js` and `text()` in `template.js` detect this during hydration and insert an empty `Text` node so reactive updates always have a node to write into. This is why none of the navigation functions are marked side-effect-free.

### 6.4 Performance engineering
- **Prototype getter caching** (`first_child_getter`, `next_sibling_getter`) — raw descriptor getters are faster and wrapper-proof.
- **Hidden instance slots** (`__click`, `__attributes`, `__style`, `__e`, `__t`) — O(1) per-element state without `WeakMap` lookups; guarded by `is_extensible` for frozen prototypes.
- **Lazy template caching + cloning** — parse once, clone cheaply; `importNode` only where semantics/perf demand it (Firefox).
- **Tree-shakeability** — hydration state is a mutable module export paired with `/*@__NO_SIDE_EFFECTS__*/` annotations so unused paths (and `hydrate()` itself) drop out of bundles (verified by the repo's `check-treeshakeability` script).

### 6.5 Error signaling
Hydration problems throw the `HYDRATION_ERROR` *sentinel value* rather than an `Error`. The lifecycle layer catches it and, depending on `recover`, silently falls back to a full client-side mount or raises `hydration_failed`. Genuine Svelte `Error`s (message contains a `https://svelte.dev/e/` link) are re-thrown untouched, so user code errors are never masked as hydration failures.

---

## 7. API Reference (exports by file)

| File | Export | Kind | Purpose |
|---|---|---|---|
| `hydration.js` | `hydrating` / `set_hydrating` | state / setter | Global mode gate (tree-shaken when unused) |
| | `hydrate_node` / `set_hydrate_node` | state / setter | Read cursor; `null` → `hydration_mismatch` + throw |
| | `hydrate_next` | fn | Advance cursor to next sibling |
| | `hydrate_template` | fn | Adopt `<template>` content as hydration target |
| | `next(count)` | fn | Skip `count` siblings during hydration |
| | `reset(node)` | fn | Verify subtree fully consumed, rewind cursor |
| | `remove_nodes` | fn | Delete DOM up to matching `<!--]-->` |
| | `read_hydration_instruction` | fn | Read/validate marker comment data |
| `operations.js` | `init_operations` | fn | Idempotent env bootstrap & prototype patching |
| | `$window`, `$document`, `is_firefox` | vars | Cached globals |
| | `child`, `first_child`, `sibling` | fn | Dual-mode navigation (hydration-aware) |
| | `create_element`, `create_fragment`, `create_comment`, `create_text` | fn | Node factories |
| | `set_attribute` | fn | Attribute set with `xlink:` namespace handling |
| | `clear_text_content` | fn | Empty a node (used in hydration recovery) |
| | `should_defer_append` | fn | Async-mode batch coordination for block swaps |
| | `get_first_child`, `get_next_sibling` | fn | Raw (non-hydrating) getters |
| `template.js` | `from_html`, `from_svg`, `from_mathml`, `from_tree` | factories | Lazy template → clone closures |
| | `text`, `comment` | fn | Claim/create expression anchors |
| | `assign_nodes` | fn | Stamp node span on active effect |
| | `append` | fn | Insert fragment / finalize hydration span |
| | `props_id` | fn | Recover/generate component scoping UID |
| | `with_script` | fn | Script-execution wrapper for factories |
| `css.js` | `append_styles` | fn | Deduplicated scoped-CSS injection |

---

## 8. Interaction with Sibling Renderer Layers

```mermaid
flowchart TB
    F["DOM Foundation"]

    F -->|"cursor + markers"| IF["if_block / each / key / await<br/>(control-flow blocks)"]
    F -->|"assign_nodes spans"| SNIP["snippet / slot / svelte:element<br/>(blocks)"]
    F -->|"set_attribute, __attributes,<br/>__click delegation slots"| EL["attribute_effect, event()<br/>(elements & events)"]
    F -->|"__style / __attributes slots"| BD["bind_value, bind_group, …<br/>(bindings)"]
    F -->|"hydration cursor mgmt"| LC["mount / hydrate / unmount<br/>(lifecycle API)"]

    IF & SNIP -->|"branch anchors = $.comment()"| ANCHOR["Comment anchors<br/>(shared currency)"]
    ANCHOR --> F

    style F fill:#1a1a2e,stroke:#e94560,color:#fff
```

- **Control-flow blocks** never manipulate `hydrate_node` directly; they rely on `child`/`sibling`/`comment` and `reset()` to keep the cursor consistent across branch entry/exit.
- **Elements & events** build on `init_operations`' cache slots: delegated listeners are stored in `element.__click`, current attribute snapshots in `element.__attributes` — enabling cheap dirty-checking in `attribute_effect` (see [client_dom_renderer_elements_and_events](client_dom_renderer_elements_and_events.md)).
- **Bindings** write through the same slots, so hydration state and post-hydration updates share one representation.

---

## 9. Failure Modes & Diagnostics

| Situation | Mechanism | Outcome |
|---|---|---|
| Cursor hits `null` (DOM ended early) | `set_hydrate_node(null)` → `w.hydration_mismatch()` | Warning + `HYDRATION_ERROR` thrown |
| `reset()` finds unconsumed siblings | `w.hydration_mismatch()` | Warning + throw |
| Marker node is not a comment | `read_hydration_instruction` | Warning + throw |
| `hydrate()` ends off the `<!--]-->` marker | `render.js` check | Warning + throw → recovery path |
| Recovery (`recover !== false`) | `clear_text_content(target)` + fresh `mount()` | Client renders from scratch; console warning otherwise |
| `recover === false` | `e.hydration_failed()` | Hard compile-error-family failure |

Client-side warnings/errors used here live in the runtime diagnostics layer (`../warnings.js`, client errors module) — see [client_runtime_core_diagnostics](client_runtime_core_diagnostics.md).

---

## 10. Related Documentation

- [client_dom_renderer](client_dom_renderer.md) — parent renderer overview
- [client_dom_renderer_lifecycle_api](client_dom_renderer_lifecycle_api.md) — `mount` / `hydrate` / `unmount` driving this module
- [client_dom_renderer_control_flow_blocks](client_dom_renderer_control_flow_blocks.md) — block implementations consuming anchors & spans
- [client_dom_renderer_elements_and_events](client_dom_renderer_elements_and_events.md) — attributes, events, transitions, custom elements
- [client_dom_renderer_bindings](client_dom_renderer_bindings.md) — two-way bindings
- [client_runtime_core](client_runtime_core.md) / [client_runtime_core_effects](client_runtime_core_effects.md) / [client_runtime_core_batching](client_runtime_core_batching.md) — reactive runtime providing `active_effect` and scheduling
- [client_dev_mode](client_dev_mode.md) / [client_dev_mode_hmr](client_dev_mode_hmr.md) / [client_dev_mode_validation](client_dev_mode_validation.md) — dev-mode instrumentation hooks
- [shared_runtime](shared_runtime.md) — shared utils & feature flags
- [compiler_client_transform_templates](compiler_client_transform_templates.md) — how the compiler emits calls into this module
- [server_runtime](server_runtime.md) — the SSR counterpart producing the HTML & markers consumed here
