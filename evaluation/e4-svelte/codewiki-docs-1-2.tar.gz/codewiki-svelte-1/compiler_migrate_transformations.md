# compiler_migrate_transformations

> **Module scope:** `packages/svelte/src/compiler/migrate/index.js` — transformation helpers `handle_identifier`, `handle_events`, `migrate_slot_usage`, `trim_block`.
>
> This module is the *muscle* of the Svelte migration codemod. While [compiler_migrate_api](compiler_migrate_api.md) owns the `migrate()` orchestration, the props/state rune synthesis and the visitor bookkeeping, the functions documented here perform the actual **positional source rewrites** that turn Svelte 4 syntax into Svelte 5 syntax (runes, event attributes, snippets).

---

## 1. Overview

The Svelte 5 migration tool (`migrate()`, documented in [compiler_migrate_api](compiler_migrate_api.md)) does **not** rebuild an output AST. Instead it:

1. Parses the source once ([compiler_parser](compiler_parser.md)),
2. Analyzes it once ([compiler_analyzer](compiler_analyzer.md)) to obtain scopes, bindings and flags such as `uses_props`, `uses_rest_props`, `uses_slots`,
3. Walks the AST with a `MagicString` overlay open on the *original* source text,
4. Delegates the syntactic rewrites to the four transformation helpers in this module.

Because every edit is expressed as a `(start, end)` range against the original string, all transformations compose safely regardless of the order in which the visitors discover nodes.

| Helper | Responsibility | Edits performed via `MagicString` |
|---|---|---|
| `handle_identifier(node, state, path)` | Rewrite legacy "magic globals" (`$$props`, `$$restProps`, `$$slots.*`) and absorb `$$Props` TypeScript interfaces into the generated props model | `str.update`, `str.prependLeft`, `str.remove` |
| `handle_events(element, state)` | Convert `on:event` directives into event attributes (`onclick={...}`), replaying Svelte 4 modifier semantics through `svelte/legacy` imports | `str.overwrite`, `str.remove` |
| `migrate_slot_usage(node, path, state)` | Convert `<slot>`, `slot="..."` attributes and `let:` directives into `{#snippet}` declarations / `{@render}` expressions and the `children` prop | `str.prependLeft`, `str.appendLeft`, `str.appendRight`, `str.update`, `str.remove`, `str.move`, `str.indent` |
| `trim_block(state, start, end)` | Normalize insignificant whitespace inside block/tag delimiters (`{#if (...) }`, `{@html …}`, `{:then …}`) | `str.update` |

These helpers are **not** part of the public API surface. They are internal to `migrate/index.js` and only invoked from the visitor maps defined in the same file (see [§6 Visitor integration](#6-visitor-integration)).

---

## 2. Position in the system

The module lives under the *Source Migration & Preprocessing Tooling* subsystem, as a child of [compiler_migrate](compiler_migrate.md). Its sibling sub-modules are:

- [compiler_migrate_api](compiler_migrate_api.md) — the `migrate()` entry point, the visitor maps that call into this module, and `extract_type_and_comment`.
- [compiler_migrate_svelte_ignore](compiler_migrate_svelte_ignore.md) — `migrate_svelte_ignore`, used to rewrite `svelte-ignore a11y-x` comment codes (invoked from the visitor maps, not from this module's helpers).

It consumes output of the compiler front-end and never touches the back-end (client/server transforms), the runtime, or the public API.

```mermaid
flowchart LR
    SRC["Svelte 4 source text"] --> M["migrate() — compiler_migrate_api"]
    M --> P["parse() — compiler_parser"]
    P --> AN["analyze_component() — compiler_analyzer"]
    AN --> W1["walk: instance_script visitors"]
    AN --> W2["walk: template visitors"]
    W1 --> ID["handle_identifier"]
    W2 --> ID
    W2 --> EV["handle_events"]
    W2 --> SU["migrate_slot_usage"]
    W2 --> TB["trim_block"]
    ID --> MS["MagicString overlay edits"]
    EV --> MS
    SU --> MS
    TB --> MS
    MS --> OUT["Svelte 5 code — or '@migration-task' fallback"]
```

---

## 3. Architecture & dependencies

```mermaid
flowchart TD
    subgraph MOD["compiler_migrate_transformations"]
        FNS["handle_identifier, handle_events, migrate_slot_usage, trim_block"]
    end

    FNS --> MS["magic-string — positional source edits"]
    FNS --> ZW["zimmerframe — walk / Visitors"]
    FNS --> PARSE["compiler_parser — parse, regex_valid_component_name"]
    FNS --> ANZ["compiler_analyzer — analyze_component"]
    FNS --> SCOPE["compiler_analyzer_scope — Scope.get / Scope.generate, Binding kinds, get_rune"]
    FNS --> CORE["compiler_core — reset, validate_component_options"]
    FNS --> IG["compiler_migrate_svelte_ignore — migrate_svelte_ignore"]
    FNS --> UTILS["utils/ast.js, utils.js — extract_identifiers, is_text_attribute, is_reserved, is_void, is_svg"]
    FNS --> PAT["compiler patterns — regex_is_valid_identifier"]
    FNS --> TYPES["compiler_types — AST.SvelteNode, Binding, ComponentAnalysis, ValidatedCompileOptions"]
```

Key design points:

- **Single-pass, offset-based editing.** The original source is immutable during the walk. All helpers read ground truth from `state.str.original` (character-level probing for quotes, parens, line breaks) and only ever emit *edits* into the overlay.
- **Scope-driven naming.** Every generated identifier (e.g. `props`, `rest`, `preventDefault`, `bubble`) is produced by `Scope.generate()` / `ScopeRoot.unique()` ([compiler_analyzer_scope](compiler_analyzer_scope.md)), guaranteeing collision-free names.
- **Binding-kind awareness.** Decisions rely on binding `kind` values produced by the analyzer (`prop`, `bindable_prop`, `state`, `legacy_reactive`, `store_sub`, …). See [compiler_analyzer_scope](compiler_analyzer_scope.md) and [compiler_types](compiler_types.md).
- **Graceful degradation.** Anything that cannot be migrated mechanically must not corrupt the file: it either throws a `MigrationError` (whole file falls back, see [§7](#7-error-handling--migration-tasks)) or injects a local `@migration-task` comment and leaves that region untouched.

---

## 4. The transformation contract — `State`

All helpers receive the shared migration `State` object (typed and initialized in `migrate()`, see [compiler_migrate_api](compiler_migrate_api.md)). The table below shows which fields each helper reads or mutates.

| `State` field | `handle_identifier` | `handle_events` | `migrate_slot_usage` | `trim_block` |
|---|:-:|:-:|:-:|:-:|
| `str` (MagicString) | read + **write** | read + **write** | read + **write** | read + **write** |
| `scope` (bindings / name generation) | read | – | read (only indirectly via name checks) | – |
| `analysis` (`uses_props`, `uses_rest_props`, `uses_slots`, `custom_element`, `name`, `source`) | read | – | read | – |
| `props` (accumulated props model) | **write** (slot props, `$$Props` members) | – | – | – |
| `names` (generated unique names) | read | read | – | – |
| `legacy_imports` (set of `svelte/legacy` specifiers) | – | **write** | – | – |
| `script_insertions` (extra statements in instance script) | – | **write** | – | – |
| `indent` | – | – | read | – |
| `end` (source length, indent exclusion bounds) | – | – | read | – |

Module-level shared state: the boolean flag `has_migration_task` lives at module scope and is set when a helper (or the API layer) decides a region must be finished by hand. It drives the post-migration console notice emitted by `migrate()`.

---

## 5. Core transformations

### 5.1 `handle_identifier` — legacy globals → props / slots

Called for **every** `Identifier` node of both walks (instance script and template). It early-returns for member-expression *properties* and then resolves the identifier through the following decision cascade:

```mermaid
flowchart TD
    A["Identifier node"] --> B{"parent is MemberExpression property?"}
    B -- yes --> Z1["skip — handled at the member level"]
    B -- no --> C{"analysis.uses_props?"}
    C -- yes --> D{"name is $$props or $$restProps?"}
    D -- yes --> D1["rewrite identifier to generated 'props' name"]
    D -- no --> D2{"binding kind is bindable_prop and not the declaration itself?"}
    D2 -- yes --> D3["prefix with 'props.' so prop access goes through the $props object"]
    D2 -- no --> E{"name is $$restProps and uses_rest_props?"}
    E -- yes --> E1["rewrite to generated 'rest' name"]
    E -- no --> F{"name is $$slots and uses_slots?"}
    F -- yes --> G{"parent is MemberExpression?"}
    G -- no --> G1["leave as-is — migrate() will surface a manual error"]
    G -- yes --> G2["resolve slot name; 'default' becomes 'children'"]
    G2 --> G3{"name already registered or scope.generate keeps it stable?"}
    G3 -- no --> G4["throw MigrationError — slot would be renamed, component would break"]
    G3 -- yes --> G5["register prop with slot_name metadata, type Snippet, needs_refine_type = true"]
    G5 --> G6["rewrite member expression to the slot prop identifier (prefixed with props. if uses_props)"]
    C -- no --> F
    F -- no --> H{"parent is TSInterfaceDeclaration or TSTypeAliasDeclaration named $$Props?"}
    H -- yes --> H1["merge each member's type, optionality, comments into state.props"]
    H1 --> H2["remove the interface/type alias from the source"]
    H -- no --> Z2["nothing to do"]
```

Behaviour highlights:

- **`$$props` / `$$restProps`.** When the component uses `$$props`, *all* bindable prop references become `props.<name>` (they are now properties of the `$props()` object rather than bare locals). Without `$$props`, only `$$restProps` is rewritten (to the generated `rest` name — "not 100% correct but it'll do", per the source comment).
- **`$$slots.<name>`.** The first reference registers a synthetic prop:
  - `local`/`exported` = slot name (`default` → `children`),
  - `type` = `import('svelte').Snippet<[any]>` (a safe initial guess),
  - `needs_refine_type = true` — later refined to a parameterless `Snippet` (or kept `[any]`) by the `SlotElement` visitor when the actual render site is found (see [compiler_migrate_api](compiler_migrate_api.md)).
- **`$$Props`.** A TypeScript `interface $$Props { ... }` (or equivalent type alias) is dissolved: each member's type annotation, optionality, leading JSDoc and trailing comment are merged into the corresponding entry of `state.props` (or appended as a `type_only` prop), then the declaration is deleted from the output. This feeds the type synthesis performed by `migrate()` (see `has_type_or_fallback` in [compiler_migrate_api](compiler_migrate_api.md)).

Example effects:

```svelte
<!-- before (uses $$props) -->            <!-- after -->
<h1>{title}</h1>                          <h1>{props.title}</h1>
{#if $$slots.footer}                      {#if footer}
  <slot name="footer" />                    {@render footer?.()}
{/if}                                     {/if}
```

### 5.2 `handle_events` — `on:` directives → event attributes

Handles elements that support event directives: `RegularElement`, `SvelteElement`, `SvelteWindow`, `SvelteBody`, `SvelteDocument`. Because Svelte 4 allowed *multiple* handlers and *modifiers* per event, migration must preserve Svelte 4 execution semantics — which is exactly why the `svelte/legacy` helpers exist ([legacy_compat](legacy_compat.md)).

```mermaid
flowchart TD
    A["collect element's on: directives, grouped by 'on' + name (+ 'capture')"] --> B{"directive has inline expression?"}
    B -- no --> C["body = bubble('event') — requires createBubbler legacy import plus a 'const bubble = createBubbler()' script insertion"]
    B -- yes --> D["body = verbatim source text of the handler expression"]
    C --> E["wrap body with modifiers, in Svelte 4 order"]
    D --> E
    E --> F{"passive or nonpassive modifier?"}
    F -- yes --> G["overwrite directive with use:passive / use:nonpassive action — 'use:passive=['click', () => body]'"]
    F -- no --> H{"more than one handler for the same event?"}
    H -- "first of group" --> H1["keep directive slot; remember replacement"]
    H1 --> I
    H -- "subsequent" --> H2["remove the directive text (incl. surrounding whitespace)"]
    H2 --> I["build replacement"]
    I --> J{"multiple handlers?"}
    J -- yes --> K["replacement = 'onname={handlers(fn1, fn2, ...)}' — requires 'handlers' legacy import"]
    J -- no --> L["replacement = 'onname={body}' — collapsed to 'onname={body}' when body is exactly the attribute name"]
    K --> M["str.overwrite(first.start, first.end, replacement)"]
    L --> M
```

**Modifier order matters.** Modifiers are applied in the exact order Svelte 4 evaluated them, regardless of the order written in the markup:

| Priority | Modifier | Legacy import used |
|:-:|---|---|
| 1 | `preventDefault` | `preventDefault` |
| 2 | `stopPropagation` | `stopPropagation` |
| 3 | `stopImmediatePropagation` | `stopImmediatePropagation` |
| 4 | `self` | `self` |
| 5 | `trusted` | `trusted` |
| 6 | `once` | `once` |

Each applied modifier wraps the handler body one more time, e.g. `on:click|preventDefault|stopPropagation={fn}` becomes `onclick={stopPropagation(preventDefault(fn))}`.

Example effects:

```svelte
<!-- before -->                                      <!-- after -->
<button on:click={save} on:click={log}>Go</button>   <button onclick={handlers(save, log)}>Go</button>
<form on:submit|preventDefault={go}>…</form>         <form onsubmit={preventDefault(go)}>…</form>
<canvas on:mousemove|passive={track} />              <canvas use:passive={['mousemove', () => track()]} />
<svelte:window on:keydown={k} />                     <svelte:window onkeydown={k} />
```

### 5.3 `migrate_slot_usage` — `<slot>` / `slot=` / `let:` → snippets

Invoked from the `RegularElement`, `SvelteElement`, `Component`, `SvelteComponent`, `SvelteFragment` and `SlotElement` template visitors. It converts Svelte 4 slot passing into Svelte 5 snippet syntax ([compiler_types_template_ast](compiler_types_template_ast.md) node model):

- a `slot="name"` attribute on content passed **to** a component → a `{#snippet name(...)}` block around that content,
- `let:` directives → snippet parameters (`let:y={z}` → parameter `y: z`),
- the default slot of the *consuming* component (`<slot />` inside the component that declares it) → `{@render children?.(...)}` — this part lives in the `SlotElement` visitor of [compiler_migrate_api](compiler_migrate_api.md); this helper covers the *call-site* side.

```mermaid
flowchart TD
    A["node with slot attributes (relative to a Component / SvelteComponent parent)"] --> B["scan attributes: read slot=..., queue let: removals"]
    B --> C{"slot name is a valid, non-reserved identifier?"}
    C -- no --> BAIL1["insert '@migration-task: migrate this slot by hand' comment — stop, keep let: directives"]
    C -- yes --> D{"name would shadow a prop of the parent component?"}
    D -- yes --> BAIL2["insert '@migration-task ... would shadow a prop' comment — stop"]
    D -- no --> E["flush removal queue — strip slot= and let: attributes"]
    E --> F{"node type?"}
    F -- "SvelteFragment" --> F1["remove the tags themselves, keep the content"]
    F1 --> G
    F -- "content of default slot ('children')" --> G["interleave scan: default content wrapped in one '#snippet children(...)' block; named-slot children moved / delimited so their closing tags stay inside their own snippets"]
    F -- "named slot" --> H["wrap the element itself: prepend '{#snippet name(props)}', indent its content, append '{/snippet}'"]
    G --> I["str.indent to keep the snippet bodies aligned with the original markup"]
    H --> I
    I --> OUT["snippet-based call site"]
```

Robustness features worth noting:

- **Removal queue for atomicity.** `let:` directives are only removed *after* a valid slot name is confirmed. If migration bails, no partial edit has been made — the directive text stays fully intact for the human.
- **Interleaved slot content.** Markup like

  ```svelte
  <Card>default text<div slot="header">H</div>more default text</Card>
  ```

  requires the default content to be split around the named snippet. The helper detects the boundaries, back-shifts one character and `str.move`s later default content so that every generated `{#snippet}` / `{/snippet}` pair nests correctly.
- **Name-preservation invariant.** A migration that would rename a slot (because `scope.generate` cannot keep the requested name) is rejected with a `MigrationError` — renaming would silently break consumers that pass content by slot name.
- **`children` mapping.** `slot="default"` content becomes the `children` snippet, matching the runtime slot implementation of the client renderer ([client_dom_renderer](client_dom_renderer.md)).

Example effect:

```svelte
<!-- before -->
<FancyBox>
  <div slot="header" let:open>{open}</div>
  <p>Body</p>
</FancyBox>

<!-- after -->
<FancyBox>
  {#snippet header({ open })}
    <div>{open}</div>
  {/snippet}
  {#snippet children()}
    <p>Body</p>
  {/snippet}
</FancyBox>
```

### 5.4 `trim_block` — whitespace normalization

The smallest helper, but the one users *see* most: it removes insignificant whitespace just inside block/tag delimiters, so migrated files don't accumulate `{#if ( condition ) }` artifacts. It slices the source range, drops the first and last characters (the braces), trims, and writes the range back **only if trimming actually changed something**.

Call sites (all in the template visitor map of [compiler_migrate_api](compiler_migrate_api.md)):

| Visitor | Trimmed range |
|---|---|
| `HtmlTag` | whole `{@html …}` |
| `ConstTag` | whole `{@const …}` |
| `IfBlock` | `{#if … }` header |
| `AwaitBlock` | `{#await … }` header plus each `{:then … }` / `{:catch … }` branch header |
| `KeyBlock` | `{#key … }` header |

```svelte
<!-- before -->        <!-- after -->
{#if ( a && b ) }      {#if ( a && b )}
{#await promise then}  {#await promise then}   (branch headers trimmed too)
```

Note that `trim_block` deliberately preserves *significant* inner characters — it only touches the whitespace immediately inside the delimiters, so expressions like `{#if (a && b)}` with meaningful parentheses pass through unchanged.

---

## 6. Visitor integration

The helpers are pure functions of `(node, state, path)` and are wired into the two visitor maps defined alongside them:

| Visitor (map) | Helper invoked |
|---|---|
| `instance_script.Identifier` | `handle_identifier` |
| `template.Identifier` | `handle_identifier` |
| `template.RegularElement` | `migrate_slot_usage` → `handle_events` (then self-closing tag fix-up) |
| `template.SvelteElement` | `migrate_slot_usage` (then dynamic-tag literal fix-up) → `handle_events` |
| `template.Component` | `migrate_slot_usage` (after visiting children) |
| `template.SvelteComponent` | `migrate_slot_usage` (then `this={expr}` → component expression rewrite) |
| `template.SvelteFragment` | `migrate_slot_usage` |
| `template.SlotElement` | `migrate_slot_usage`, then the `<slot>` → `{@render children?.()}` rewrite in the API visitor |
| `template.SvelteWindow` / `SvelteBody` / `SvelteDocument` | `handle_events` |
| `template.HtmlTag` / `ConstTag` / `IfBlock` / `AwaitBlock` / `KeyBlock` | `trim_block` |

```mermaid
sequenceDiagram
    autonumber
    participant M as migrate() — compiler_migrate_api
    participant W as zimmerframe walk
    participant T as compiler_migrate_transformations
    participant S as MagicString overlay

    M->>M: parse + analyze_component (front-end)
    Note over M: state.scope = analysis.instance.scope
    M->>W: walk(instance.content, instance_script)
    W->>T: handle_identifier (every Identifier)
    T->>S: rewrite $$props / $$restProps / $$slots / $$Props
    Note over M: state.scope = analysis.template.scope
    M->>W: walk(fragment, template)
    W->>T: handle_identifier / migrate_slot_usage / handle_events / trim_block
    T->>S: positional edits, legacy_imports & script_insertions bookkeeping
    W-->>M: walk complete
    M->>S: synthesize $props(), $derived, legacy imports, reorder reactive statements
    S-->>M: toString() → migrated code (or @migration-task fallback)
```

Two properties of this integration are essential:

1. **Cross-phase data flow.** Slot identifiers discovered by `handle_identifier` (via `$$slots.x`) are recorded in `state.props` and later *refined* by the `SlotElement` visitor, which knows the actual render parameters. The prop model is therefore assembled cooperatively across both walks.
2. **The walkers never write text themselves.** All string mutation is channelled through these helpers (plus the post-walk synthesis in `migrate()`), keeping the edit log attributable and debuggable.

---

## 7. Error handling & migration tasks

The module participates in a two-tier failure model:

```mermaid
flowchart TD
    A["Transformation encounters something it cannot rewrite"] --> B{"Is it locally containable?"}
    B -- yes --> C["Inject a local '@migration-task: …' HTML comment<br/>leave the region untouched<br/>set module flag has_migration_task"]
    B -- no --> D["throw MigrationError with an actionable message"]
    C --> E["migrate() returns: task comment + original source"]
    D --> F["migrate() catch: log + return 'Error while migrating …' task comment + original source"]
    E --> G["finally: console notice about migration-task comments"]
    F --> G
```

- **Local bail-outs** (`@migration-task` comments) are used when only *one construct* is at fault: invalid/reserved slot names, slots that would shadow a parent prop, `<svelte:self>` without a filename, CSS that resists automatic `:global()` insertion (handled in `migrate()`, see [compiler_migrate_api](compiler_migrate_api.md)).
- **`MigrationError`** aborts the *whole file*. Examples raised by or related to this module's helpers: a slot whose name `scope.generate` cannot preserve ("…making the component unusable"), and — from the API layer — `$state`/`$derived`/`$props` name collisions and unsupported destructured `export let` patterns.
- The fallback output is always **valid, unchanged Svelte 4** prefixed with an HTML comment, so a partially-migrated codebase never breaks; humans finish flagged spots by hand.

---

## 8. Invariants & maintenance notes

1. **Never re-parse.** Helpers must only mutate through `MagicString`. Character-level probing (`str.original[...]`) is allowed; reading `str.toString()` mid-walk is not (except in `migrate_css`, which works on an isolated snapshot).
2. **Positional integrity.** Offsets always refer to the *original* source. Edits accumulate as ranges; the final `toString()` resolves overlaps by insertion order.
3. **Name stability.** Any newly introduced identifier must come from `Scope.generate()` / `ScopeRoot.unique()`; hard-coded names would risk shadowing user code.
4. **Svelte 4 semantics preservation.** Event modifier order, reactive-statement ordering, and slot dispatch behavior must be bit-for-bit equivalent after migration — that is the entire reason `svelte/legacy` re-exports exist ([legacy_compat](legacy_compat.md)).
5. **Module-scope flag.** `has_migration_task` is shared module state; it assumes one migration run per process/scope. If the codemod is ever parallelized in-process, this must be moved into per-run state.
6. **Formatter awareness.** `guess_indent()` (tab-vs-space detection) and `str.indent(...)` exclusion ranges keep generated `{#snippet}` bodies aligned with the file's existing style; changes to output shapes should preserve this.
7. **Testing.** Behavior is exercised through snapshot tests of `migrate()` output (see the repository's `packages/svelte/tests/migrate` suite) rather than unit-tested in isolation — keep that in mind when changing message wording, since error texts appear in snapshots.

---

## 9. Related documentation

- [compiler_migrate_api](compiler_migrate_api.md) — `migrate()` entry point, visitor maps, props/derived synthesis, `extract_type_and_comment`.
- [compiler_migrate](compiler_migrate.md) — parent module overview.
- [compiler_migrate_svelte_ignore](compiler_migrate_svelte_ignore.md) — `svelte-ignore` code renaming (`a11y-x` → `a11y_x`).
- [compiler_preprocess](compiler_preprocess.md) — sibling preprocessing pipeline (why `<style>` contents are blanked during migration).
- [compiler_parser](compiler_parser.md) / [compiler_analyzer](compiler_analyzer.md) / [compiler_analyzer_scope](compiler_analyzer_scope.md) — front-end phases consumed by the migration.
- [compiler_types](compiler_types.md) (notably [compiler_types_template_ast](compiler_types_template_ast.md)) — the AST node types these helpers match on.
- [compiler_core](compiler_core.md) — `reset()`, option validation and other infrastructure.
- [legacy_compat](legacy_compat.md) — the runtime `svelte/legacy` helpers that the migrated output imports.
- [client_dom_renderer](client_dom_renderer.md) — how migrated snippets/slots are ultimately rendered at runtime.