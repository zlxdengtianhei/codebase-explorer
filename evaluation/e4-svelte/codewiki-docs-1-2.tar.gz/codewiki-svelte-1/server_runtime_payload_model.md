# Server Runtime Payload Model (`server_runtime_payload_model`)

## Introduction

The **`server_runtime_payload_model`** module defines the data contracts that carry server-side rendered (SSR) output through Svelte's server rendering engine. Every server-compiled Svelte component receives a **`Payload`** object (`$$payload` in generated code) and *pushes* HTML fragments into it; when rendering finishes, the accumulated state is joined into a **`RenderOutput`** object — the public result handed back to frameworks and legacy adapters. A small companion service provides **abort signals** so in-flight async work can be invalidated once a render completes.

This module is a leaf dependency of the server runtime ([server_runtime_rendering_core](server_runtime_rendering_core.md)) and sits at the boundary between:

- the **compiler back-end** ([compiler_server_transform](compiler_server_transform.md)), which generates code that *reads and writes* payloads,
- the **rendering core**, which *creates, consumes, and finalizes* payloads,
- and the **public/legacy API surface** ([public_api](public_api.md), [legacy_compat](legacy_compat.md)), which *exposes and adapts* the resulting `RenderOutput`.

---

## Module composition

| File | Contents | Role |
| --- | --- | --- |
| `packages/svelte/src/internal/server/payload.js` | `HeadPayload`, `Payload` classes; `copy_payload`, `assign_payload`, `props_id_generator` | Output accumulator model + legacy-mode copy/assign helpers + hydration ID factory |
| `packages/svelte/src/internal/server/types.d.ts` | `RenderOutput`, `Component` interfaces | Type contracts for the render result and per-component server context |
| `packages/svelte/src/internal/server/abort-signal.js` | `abort`, `getAbortSignal` | Module-scoped `AbortController` service for stale-reaction invalidation |

---

## Architecture

```mermaid
graph TB
    subgraph payload["payload.js — output accumulators"]
        Payload["Payload<br/>out: string[]<br/>css: Set&lt;{hash, code}&gt;<br/>uid: () =&gt; string<br/>select_value<br/>head: HeadPayload"]
        HeadPayload["HeadPayload<br/>out: string[]<br/>css: Set&lt;{hash, code}&gt;<br/>title: string<br/>uid: () =&gt; string"]
        copy["copy_payload()"]
        assign["assign_payload()"]
        gen["props_id_generator(prefix)<br/>() =&gt; `${prefix}s${n++}`"]
        Payload --> HeadPayload
    end

    subgraph types["types.d.ts — type contracts"]
        RenderOutput["RenderOutput<br/>head / html (deprecated) / body"]
        Component["Component<br/>p (parent) / c (context)<br/>d (onDestroy) / function (dev)"]
    end

    subgraph abort["abort-signal.js — cancellation service"]
        ctl["AbortController (module singleton)"]
        abortFn["abort()"]
        getSig["getAbortSignal()"]
        abortFn --> ctl
        getSig --> ctl
    end

    subgraph consumers["Consumers (other modules)"]
        render["render()<br/>(server_runtime_rendering_core)"]
        helpers["template helpers:<br/>element, head, await_block,<br/>css_props, valueless_option,<br/>props_id, maybe_selected"]
        devv["dev.js: push_element<br/>(server_runtime_dev_validation)"]
        blocks["blocks: html, createRawSnippet<br/>(server_runtime_blocks)"]
        generated["generated SSR code<br/>(compiler_server_transform)"]
        publicAPI["svelte/server<br/>(public_api)"]
        legacy["_render() legacy adapter<br/>(legacy_compat)"]
    end

    render -- "new Payload(idPrefix)" --> Payload
    render -- "joins into" --> RenderOutput
    render -- "finally → abort()" --> abortFn
    generated -- "$$payload param" --> Payload
    helpers -- "out.push(...)" --> Payload
    helpers -- "reads select_value / uid" --> Payload
    devv -- "dev warnings into out" --> Payload
    blocks -- "out.push(...)" --> Payload
    generated -- "legacy bindings loop" --> copy
    generated -- "legacy bindings loop" --> assign
    publicAPI -- "re-exports" --> getSig
    legacy -- "adapts" --> RenderOutput
    STALE["STALE_REACTION<br/>(StaleReactionError)<br/>client_runtime_core_signal_model"] -.-> abortFn
    Component -. "used by context.js push/pop" .-> context["server context stack<br/>(context_api)"]
```

---

## Core component reference

### `Payload` and `HeadPayload` (`payload.js`)

`Payload` is the mutable output sink threaded through all server-compiled component functions. It deliberately uses **append-only arrays of strings** instead of a DOM or a tree, because SSR output must be produced in a single synchronous pass.

```js
export class Payload {
    css = new Set();        // deduplicated <style> fragments ({ hash, code })
    out = [];               // body HTML fragments, in emission order
    uid = () => '';         // hydration id generator
    select_value = undefined; // current <select value={...}> during SSR
    head = new HeadPayload();

    constructor(id_prefix = '') {
        this.uid = props_id_generator(id_prefix);
        this.head.uid = this.uid;
    }
}
```

| Field | Written by | Read by |
| --- | --- | --- |
| `out` | `render()` (hydration boundary markers), `element()`, `await_block()`, `css_props()`, `valueless_option()`, `props_id()`, dev `push_element()`, `createRawSnippet()`, `html()` block, and every generated template statement (`$$payload.out.push(...)`) | `render()` → `body`; `valueless_option()` inspects its own slice to detect `selected` options |
| `css` | component `<style>` blocks | `render()` → emits `<style id="{hash}">` tags into `head` |
| `head` | `$.head(payload, fn)` — invokes the callback with `payload.head` (so generated code inside `<svelte:head>` *shadows* `$$payload` with the head payload) | `render()` → `head` string |
| `head.title` | `<svelte:title>` (compiled to `$$payload.title += ...` inside the head callback) | `render()` appends it after `head.out` |
| `select_value` | generated code for `<select>` with a `value` attribute **and** spread attributes | `maybe_selected(payload, value)` → marks matching `<option>` as `selected`; `valueless_option()` compares rendered option text against it |
| `uid` | set once by the constructor (shared between `Payload` and its `head`) | `props_id()` → `<!--#{uid}-->` hydration markers; `$props.id()` rune |

`HeadPayload` is structurally identical minus `select_value`, and additionally carries `title`. The nested object keeps head output isolated from body output while remaining reachable from a single render argument.

### `props_id_generator` (`payload.js`, private)

```js
function props_id_generator(prefix) {
    let uid = 1;
    return () => `${prefix}s${uid++}`;
}
```

A closure factory producing deterministic, per-render unique IDs (`{prefix}s1`, `{prefix}s2`, …). `render()` seeds the prefix from the `idPrefix` render option (`idPrefix + '-'`), which frameworks (e.g. SvelteKit) use to avoid collisions across concurrent renders.

**Server/client pairing:** the server `props_id()` emits `<!--#uid-->` into `payload.out` and returns the uid; the client counterpart in `internal/client/dom/template.js` (`client_dom_renderer_dom_foundation`) reads that marker while hydrating to reproduce the *same* ID, falling back to a `c{n}` counter for non-hydrated instances. The `$props.id()` rune makes the compiler hoist `const uid = $.props_id($$payload)` to the first line of the component so IDs are allocation-ordered and stable.

### `copy_payload` / `assign_payload` (`payload.js`)

```js
export function copy_payload({ out, css, head, uid }) { /* fresh Payload with copied out/css + copied nested head */ }
export function assign_payload(p1, p2) { /* p1.out = [...p2.out]; p1.css = p2.css; p1.head = p2.head; p1.uid = p2.uid */ }
```

These two functions exist **exclusively for legacy-mode component bindings** (see [Legacy binding reconciliation](#legacy-binding-reconciliation)). `copy_payload` produces an isolated workspace — new arrays, new `Set`s, and a fresh nested `HeadPayload` — so speculative re-renders never mutate the original payload. `assign_payload` then commits the winning iteration's state back onto the original payload by reference swap (with `out` copied once more).

### `RenderOutput` and `Component` (`types.d.ts`)

```ts
export interface RenderOutput {
    /** HTML that goes into the `<head>` */
    head: string;
    /** @deprecated use `body` instead */
    html: string;
    /** HTML that goes somewhere into the `<body>` */
    body: string;
}
```

`RenderOutput` is the final, immutable projection of a `Payload` and the shape returned by `render()` in `server/index.js` (`html` is kept as a deprecated alias for backward compatibility). It is re-exported through the public type surface (`packages/svelte/types/index.d.ts`, module [svelte-types](svelte-types.md)) and adapted by the legacy layer.

The `Component` interface in the same file — `{ p, c, d, function? }` (parent, context map, `onDestroy` callbacks, dev component function) — is the server-side unit of the context stack maintained by `internal/server/context.js` (module [context_api](context_api.md)). It is orthogonal to payload accumulation but shares this type file as the server runtime's contract layer.

### `abort` / `getAbortSignal` (`abort-signal.js`)

```js
let controller = null;

export function abort() {
    controller?.abort(STALE_REACTION);
    controller = null;
}

export function getAbortSignal() {
    return (controller ??= new AbortController()).signal;
}
```

A lazily instantiated, **module-scoped** `AbortController`:

- `getAbortSignal()` hands the signal to server code that starts cancellable async work during a render (e.g. `fetch`-style operations). It is re-exported publicly from `svelte/server` (`packages/svelte/src/index-server.js`, module [public_api](public_api.md)).
- `abort()` is called in `render()`'s `finally` block, terminating any pending listeners with reason **`STALE_REACTION`** — a `StaleReactionError` instance imported from the client constants (`internal/client/constants.js`, module [client_runtime_core_signal_model](client_runtime_core_signal_model.md)) — so user code can distinguish "render ended, result is stale" from genuine errors, and so the next `render()` starts from a clean singleton.

---

## Data flow: from `render()` to `RenderOutput`

```mermaid
flowchart TD
    A["caller: render(component, { props, context, idPrefix })"] --> B["new Payload(idPrefix + '-')<br/>uid = props_id_generator"]
    B --> C["payload.out.push(BLOCK_OPEN)<!--[-->"]
    C --> D["optional: push() context root"]
    D --> E["component($$payload, props, bindings, slots)"]
    E --> F["generated template helpers write fragments"]
    F --> G["payload.out<br/><!--[-->...body HTML...<!--]-->"]
    F --> H["payload.head.out<br/><svelte:head> fragments"]
    F --> I["payload.head.title<br/><svelte:title> += ..."]
    F --> J["payload.css<br/>Set of { hash, code }"]
    F --> K["payload.select_value<br/><select> value"]
    G & H & I & J --> L["render() finalizes:<br/>head = head.out + title + style tags<br/>body = out.join('')"]
    L --> M["RenderOutput { head, html: body, body }"]
    L --> N["finally: abort()<br/>(STALE_REACTION)"]
    M --> O["framework / adapter<br/>injects head + body into HTML shell"]
    M --> P["legacy_compat: _render()<br/>→ { css, head, html }"]
```

Key properties of this flow:

1. **Single-threaded synchronous pass** — the whole component tree writes into one payload; ordering of `out` entries is exactly document order.
2. **Hydration boundaries** — `render()` wraps output with `<!--[-->` / `<!--]-->` markers (from `internal/server/hydration.js`), and block helpers emit additional boundary comments so the client renderer can claim nodes during hydration.
3. **Head isolation** — `<svelte:head>` content lands in `payload.head.out`; `<svelte:title>` accumulates into `payload.head.title`; component `<style>` blocks are deduplicated through the `css` `Set` and emitted as `<style id="{hash}">` in the final `head` string.

---

## Legacy binding reconciliation

When a legacy-mode component has component bindings (compiler flag `analysis.uses_component_bindings`), the generated SSR code (see [compiler_server_transform](compiler_server_transform.md)) wraps the template in a **do/while fixpoint loop**: it re-renders into a copied payload until bound props stop changing, then commits the result. The payload model's copy/assign pair is what makes this transactional.

```mermaid
sequenceDiagram
    participant G as Generated component body
    participant P as $$payload (Payload)
    participant C as $.copy_payload
    participant R as $$render_inner (template)
    participant A as $.assign_payload

    G->>P: render attempt 1
    G->>C: copy_payload($$payload)
    C-->>G: $$inner_payload (isolated copy)
    loop while (!$$settled)
        G->>R: $$render_inner($$inner_payload)
        R-->>P: child bind_props() writes propagate
        Note over G: $$settled = false if any binding changed
    end
    G->>A: assign_payload($$payload, $$inner_payload)
    A-->>P: out / css / head / uid replaced by winning iteration
    P-->>G: continue (render() joins output)
```

Design rationale:

- **Isolation:** each iteration renders into a fresh copy, so partial output from a non-final iteration never leaks into the final HTML.
- **Commit semantics:** `assign_payload` performs a single-reference commit — the original payload's arrays/sets/head are swapped for the final iteration's, keeping the surrounding `render()` call oblivious to retries.
- The legacy adapter `_render` in [legacy_compat](legacy_compat.md) then maps `RenderOutput` onto the Svelte 3/4 shape `{ css: { code: '', map: null }, head, html: result.body }`.

---

## Abort signal lifecycle

```mermaid
stateDiagram-v2
    [*] --> Idle: module load (controller = null)
    Idle --> Active: getAbortSignal()<br/>(lazily creates AbortController, returns .signal)
    Active --> Active: server code wires signal to fetch / timers
    Active --> Aborted: render() finally → abort()<br/>reason = STALE_REACTION (StaleReactionError)
    Aborted --> Idle: controller = null (fresh singleton for next render)
    Idle --> Aborted: abort() with no controller<br/>(no-op: `controller?.abort()`)
```

Behavior notes:

- The reason object is shared with the client-side reactivity engine, allowing consumers to check `error.name === 'StaleReactionError'` and silently ignore cancellation.
- Because the controller is module-scoped (not per-payload), only one render's async work is signal-tracked at a time per server module instance; `render()`'s `finally` guarantees the reset even when the component throws.

---

## Integration with the rest of the system

| Integration point | Direction | Detail |
| --- | --- | --- |
| [compiler_server_transform](compiler_server_transform.md) | consumes model | Generates every SSR component as `function ($$payload, $$props, $$bindings, $$slots) { ... }`; template statements are compiled to `$$payload.out.push(...)` via `build_template()`. Injects `copy_payload`/`assign_payload` wrappers for legacy bindings and `$.props_id` for `$props.id()`. |
| [server_runtime_rendering_core](server_runtime_rendering_core.md) | owns lifecycle | `render()` instantiates `Payload`, seeds it with the `idPrefix`, calls the component, joins output into `RenderOutput`, and triggers `abort()` in `finally`. Helpers (`element`, `head`, `await_block`, `css_props`, `valueless_option`, `maybe_selected`, `spread_attributes`, `props_id`) read/write payload fields. |
| [server_runtime_blocks](server_runtime_blocks.md) | writes output | `html()` block and `createRawSnippet()` append raw HTML fragments to `payload.out` (snippets receive the payload as their first argument). |
| [server_runtime_dev_validation](server_runtime_dev_validation.md) | writes diagnostics | Dev-mode `push_element(payload, ...)` streams HTML-tree-validation errors directly into `payload.out`, so warnings appear inline in the rendered output. |
| [public_api](public_api.md) | exposes API | `svelte/server` re-exports `getAbortSignal` for user-driven cancellation during SSR. |
| [legacy_compat](legacy_compat.md) | adapts contract | `_render` projects `RenderOutput` onto the legacy `{ css, head, html }` render result. |
| [client_dom_renderer_dom_foundation](client_dom_renderer_dom_foundation.md) | mirrors ID scheme | Client `props_id()` consumes the `<!--#uid-->` markers emitted via `payload.uid` so `$props.id()` values match after hydration. |
| [client_runtime_core_signal_model](client_runtime_core_signal_model.md) | shares constant | `STALE_REACTION` (`StaleReactionError`) originates in client constants and is reused as the abort reason. |
| [context_api](context_api.md) | adjacent contract | The `Component` interface (same `types.d.ts`) backs `push`/`pop` and `setContext`/`getContext` on the server. |

---

## Design notes and invariants

- **Append-only output:** payload arrays are written sequentially and never re-ordered (except the deliberate splice in `valueless_option`, which collapses rendered `<option>` children to detect `selected`); this keeps `render()`'s `join('')` a faithful serialization.
- **Copy-on-write for speculation:** mutation-heavy SSR stays cheap because copying only happens in the legacy-binding fixpoint loop; runes-mode rendering (the default) never pays for `copy_payload`.
- **One render, one payload, one uid namespace:** `Payload` and its `HeadPayload` share the same `uid` closure, so `$props.id()` values inside `<svelte:head>` and the body come from a single monotonic sequence.
- **Graceful teardown:** the `finally`-based `abort()` call guarantees cancellation and singleton reset regardless of component errors, preventing signal leaks across requests.
- **Backward compatibility is encoded in the type:** the deprecated `html` field on `RenderOutput` (alias of `body`) documents the Svelte 4 → 5 rename without breaking existing consumers.
