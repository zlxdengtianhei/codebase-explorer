# compiler_core — Core Orchestration of the Svelte Compiler

## 1. Overview

`compiler_core` is the **entry point and orchestration layer** of the Svelte compiler. It wires together the three compiler phases (parse → analyze → transform), validates and normalizes compile options, maintains the shared per-compilation state that every phase reads from and writes to, and provides the ESTree AST builder toolkit used to synthesize the output JavaScript.

It lives at the top of the compiler package (`packages/svelte/src/compiler/`) and exposes the public `svelte/compiler` API surface:

| Export | Source file | Purpose |
|---|---|---|
| `compile(source, options)` | `index.js` | Full component pipeline: `.svelte` source → JavaScript module (+ CSS, warnings, AST) |
| `compileModule(source, options)` | `index.js` | Rune-enabled plain JavaScript module → JavaScript module |
| `parse(source, { modern, loose })` | `index.js` | Parse-only entry point returning the public AST (modern or legacy shape) |
| `preprocess` | re-export of `compiler_preprocess` | Svelte preprocessor runner (see [compiler_preprocess](compiler_preprocess.md)) |
| `migrate` | re-export of `compiler_migrate` | Svelte 4 → 5 codemod driver (see [compiler_migrate](compiler_migrate.md)) |
| `VERSION` | re-export | Compiler version string |
| `walk` | `index.js` | **Deprecated** — always throws; `estree-walker` must be imported directly |

### The four source files

| File | Role |
|---|---|
| `packages/svelte/src/compiler/index.js` | Pipeline driver & public entry points (`compile`, `compileModule`, `parse`, `to_public_ast`, `remove_bom`) |
| `packages/svelte/src/compiler/validate-options.js` | Composable options-validation DSL and the concrete `compile`/`compileModule` option schemas |
| `packages/svelte/src/compiler/state.js` | Module-global per-compilation state (source, locator, flags, warnings, `svelte-ignore` stack) |
| `packages/svelte/src/compiler/utils/builders.js` | Factory helpers for constructing ESTree nodes during code generation |

Detailed documentation for each responsibility lives in these sub-module pages:

- **[compiler_core_entry](compiler_core_entry.md)** — entry points and pipeline orchestration
- **[compiler_core_options](compiler_core_options.md)** — options validation DSL
- **[compiler_core_state](compiler_core_state.md)** — global compiler state
- **[compiler_core_builders](compiler_core_builders.md)** — ESTree AST builders

---

## 2. Architecture

### 2.1 Position in the overall system

`compiler_core` sits above the phase modules. It *coordinates* the front-end and back-end, *consumes* diagnostics infrastructure, and *is consumed by* everything that needs to produce or inspect compiler output.

```mermaid
graph TB
    subgraph COMPILER_CORE ["compiler_core (this module)"]
        IDX["index.js<br/>compile / compileModule / parse"]
        OPT["validate-options.js<br/>validation DSL"]
        ST["state.js<br/>global compiler state"]
        BLD["utils/builders.js<br/>ESTree builders"]
    end

    subgraph FRONT ["Front-End phases"]
        P["compiler_parser<br/>1-parse"]
        A["compiler_analyzer<br/>2-analyze"]
        CSS["compiler_css_pipeline"]
    end

    subgraph BACK ["Back-End phases"]
        CT["compiler_client_transform<br/>3-transform/client"]
        SVT["compiler_server_transform<br/>3-transform/server"]
    end

    subgraph INFRA ["Sibling infrastructure"]
        DIAG["compiler_diagnostics<br/>errors / warnings / code frames"]
        TYPES["compiler_types<br/>AST + CompileResult contracts"]
    end

    IDX -->|"validate_component_options"| OPT
    IDX -->|"state.reset / state.adjust"| ST
    IDX -->|"_parse"| P
    IDX -->|"analyze_component"| A
    IDX -->|"transform_component"| CT
    IDX -->|"transform_component"| SVT
    IDX -->|"public AST types"| TYPES
    OPT -->|"error/warning factories"| DIAG
    ST -->|"warnings array"| DIAG
    A --> CSS
    CT --> BLD
    SVT --> BLD
    A --> BLD
    ST -.->|"read by all phases"| P
    ST -.-> A
    ST -.-> CT
    ST -.-> SVT
```

### 2.2 The `compile()` pipeline

`compile()` is a straight-line composition of the phases. Each step is documented in the linked module pages.

```mermaid
flowchart TD
    SRC["source string"] --> BOM["remove_bom() — strip U+FEFF"]
    BOM --> RESET["state.reset() — fresh warnings,<br/>locator, warning filter, filename"]
    RESET --> VAL["validate_component_options()<br/>(compiler_core_options)"]
    VAL --> PARSE["_parse(source)<br/>(compiler_parser)"]
    PARSE --> TS{"parsed.metadata.ts?"}
    TS -- "yes" --> RM["remove_typescript_nodes()<br/>on fragment / instance / module /<br/>customElement.extend"]
    TS -- "no" --> MERGE
    RM --> MERGE["merge parsed &lt;svelte:options&gt;<br/>with validated options"]
    MERGE --> AN["analyze_component()<br/>(compiler_analyzer +<br/>compiler_css_pipeline)"]
    AN --> TR["transform_component()<br/>(compiler_client_transform or<br/>compiler_server_transform via<br/>options.generate)"]
    TR --> PRINT["print() program + render CSS"]
    PRINT --> AST["to_public_ast()<br/>modern: strip metadata<br/>legacy: convert()"]
    AST --> OUT["CompileResult { js, css, warnings,<br/>ast, metadata }"]
```

Key behaviors of the driver:

1. **BOM removal** — a leading `\uFEFF` would corrupt template-generation offsets, so it is stripped before anything else.
2. **State reset** — `state.reset()` clears warnings, rebuilds the line/column `locator` for the new source, and installs the user's `warningFilter` (see [compiler_core_state](compiler_core_state.md)).
3. **Option validation** — unknown options throw `options_unrecognised`; removed/deprecated options emit the correct diagnostics via [compiler_diagnostics](compiler_diagnostics.md) (see [compiler_core_options](compiler_core_options.md)).
4. **`<svelte:options>` merging** — options parsed from the component override (but are merged with) the programmatic options; `customElement` attributes are kept separately as `customElementOptions`.
5. **TypeScript stripping** — if the parser detected TypeScript, type-only nodes are erased from all three roots plus the custom-element `extend` config before analysis.
6. **AST publication** — the returned `CompileResult.ast` is a cleaned modern AST (`modernAst: true`) or the Svelte-4-style legacy shape produced by `convert()` in `legacy.js`.

### 2.3 End-to-end sequence

```mermaid
sequenceDiagram
    autonumber
    participant U as Bundler / Tooling
    participant E as index.js (entry)
    participant V as validate-options.js
    participant S as state.js
    participant P as 1-parse (compiler_parser)
    participant AN as 2-analyze (compiler_analyzer)
    participant T as 3-transform (compiler_client_transform /<br/>compiler_server_transform)
    U->>E: compile(source, options)
    E->>S: state.reset({ warningFilter, filename })
    E->>V: validate_component_options(options)
    V->>U: (throws/warns via compiler_diagnostics if invalid)
    V-->>E: ValidatedCompileOptions (defaults filled)
    E->>P: _parse(source)
    P-->>E: AST.Root (+ metadata.ts, parsed options, css)
    E->>AN: analyze_component(parsed, source, options)
    Note over AN: scopes, bindings, runes mode detection,<br/>CSS scoping, diagnostics
    AN-->>E: ComponentAnalysis
    E->>T: transform_component(analysis, source, options)
    alt generate === "server"
        T-->>T: server_component(analysis)
    else generate === "client"/"dom"
        T-->>T: client_component(analysis)
    end
    T-->>E: { js (printed + sourcemap), css, warnings }
    E->>E: result.ast = to_public_ast(...)
    E-->>U: CompileResult
```

---

## 3. Sub-module responsibilities (high level)

### 3.1 Entry point & pipeline orchestration — [compiler_core_entry](compiler_core_entry.md)

`index.js` owns the three public compile functions and the glue logic between them: BOM handling, state reset, option validation calls, TypeScript-node stripping, `<svelte:options>` merging, and finally publishing a sanitized public AST on the result. It also guards the deprecated `walk` export and re-exports `preprocess`, `migrate` and `VERSION`. The phase functions it delegates to are documented in [compiler_parser](compiler_parser.md), [compiler_analyzer](compiler_analyzer.md), [compiler_client_transform](compiler_client_transform.md) and [compiler_server_transform](compiler_server_transform.md).

### 3.2 Options validation DSL — [compiler_core_options](compiler_core_options.md)

`validate-options.js` implements a small combinator library (`object`, `string`, `boolean`, `list`, `fun`, `validator`) and builds two concrete schemas on top of it: `validate_component_options` and `validate_module_options`. It encodes defaults (`dev: false`, `generate: 'client'`, `css: 'external'`, …), cross-runtime `rootDir` resolution, renames (`dom`/`ssr` → `server`/`client` with a one-time warning), deprecations (`accessors`, `immutable`), hard removals (`format`, `tag`, `sveltePath`, …) and legacy compatibility (`compatibility.componentApi: 4 | 5`). All failures are surfaced through the error/warning factories of [compiler_diagnostics](compiler_diagnostics.md), and the validated result is typed as `ValidatedCompileOptions` from [compiler_types](compiler_types.md).

### 3.3 Global compiler state — [compiler_core_state](compiler_core_state.md)

`state.js` holds module-scoped state that phases share without threading it through every call: the raw `source`, a `locate-character` locator, `filename`, `dev`/`runes` flags, the current `component_name`, the accumulating `warnings` array, the user `warning_filter`, and the `svelte-ignore` machinery (`push_ignore` / `pop_ignore` / `is_ignored` backed by `ignore_stack` + `ignore_map`). `reset()` is called once per compilation by the entry point; `adjust()` is called by analysis once `dev`, `runes` and the component name are known.

### 3.4 ESTree AST builders — [compiler_core_builders](compiler_core_builders.md)

`utils/builders.js` is a dense factory library covering virtually the whole ESTree grammar (expressions, statements, declarations, patterns, modules, class members). Beyond plain node shapes it adds compiler-specific conveniences: `call()` pads missing middle arguments with `undefined`, `thunk`/`unthunk` simplify trivial arrow wrappers, `quasi()` sanitizes raw template text, `key()` picks identifier vs. literal keys, and keyword-like exports (`b.if`, `b.let`, `b.const`, `b.return`, …) make generated code read like JavaScript. Both the client and server transform visitors (see [compiler_client_transform](compiler_client_transform.md), [compiler_server_transform](compiler_server_transform.md)) and parts of analysis construct output exclusively through these helpers.

---

## 4. How the pieces interact

```mermaid
flowchart LR
    subgraph ENTRY ["compiler_core_entry"]
        compileFn["compile / compileModule / parse"]
    end
    subgraph OPTS ["compiler_core_options"]
        validators["object · string · boolean · list · fun<br/>removed · warn_removed · deprecate"]
    end
    subgraph STATE ["compiler_core_state"]
        st["source · locator · filename · dev · runes<br/>warnings · warning_filter · ignore stack"]
    end
    subgraph BUILDERS ["compiler_core_builders"]
        b["ESTree node factories"]
    end
    subgraph SIB ["Sibling modules"]
        diag["compiler_diagnostics"]
        types["compiler_types"]
        fe["Front-End phases"]
        be["Back-End phases"]
    end

    compileFn -->|"options"| validators
    validators -->|"e.* / w.*"| diag
    compileFn -->|"reset / adjust / warnings"| st
    compileFn -->|"phases"| fe
    compileFn -->|"phases"| be
    fe -->|"read flags, push warnings, ignores"| st
    be -->|"read flags, push warnings"| st
    be -->|"synthesize output JS"| b
    st -->|"warnings array"| diag
    compileFn -->|"typed by"| types
```

Notable invariants:

- **One reset per compilation.** `state.js` is global mutable state; `compile`, `compileModule` and `parse` each call `state.reset()` first, which is why the compiler is safe for sequential (non-concurrent) use.
- **Warnings funnel through state.** Diagnostics emitted anywhere in the phases are appended to `state.warnings`; the entry point simply copies that array into the `CompileResult`, already filtered by the user's `warningFilter`.
- **Builders are output-only.** Builder-produced nodes carry `metadata: null`; they are never fed back into analysis. Conversely, parsed AST nodes always carry compiler `metadata`, which `to_public_ast`/`convert` strip before publication.
- **Two AST dialects.** Internal code works with the modern AST (`types/template.d.ts`, `types/css.d.ts` in [compiler_types](compiler_types.md)); `parse()` without `modern: true` returns the legacy shape via `convert()` for Svelte-4-era tooling compatibility (legacy node types such as `LegacySlot`, `LegacyStyleDirective` also live in [compiler_types](compiler_types.md)).

---

## 5. Cross-references to other modules

| Topic | Module documentation |
|---|---|
| Template/JS/CSS parsing, state machine, TS stripping | [compiler_parser](compiler_parser.md) |
| Scope construction, binding kinds, runes detection, visitors | [compiler_analyzer](compiler_analyzer.md) |
| CSS analysis (`:global` blocks, unused selectors) and CSS transforms | [compiler_css_pipeline](compiler_css_pipeline.md) |
| Client-side output generation (template clones, effects, reactivity) | [compiler_client_transform](compiler_client_transform.md) |
| Server-side output generation (SSR payload calls) | [compiler_server_transform](compiler_server_transform.md) |
| Error/warning message catalogs, code frames | [compiler_diagnostics](compiler_diagnostics.md) |
| AST node, `CompileOptions`/`CompileResult`, CSS selector types | [compiler_types](compiler_types.md) |
| Source preprocessing (TypeScript, etc.) | [compiler_preprocess](compiler_preprocess.md) |
| Svelte 4 → 5 migration codemod | [compiler_migrate](compiler_migrate.md) |

> **Where to go next:** for the exact behavior of each public function, read [compiler_core_entry](compiler_core_entry.md); for option-by-option semantics, [compiler_core_options](compiler_core_options.md); for `svelte-ignore` and warning lifecycle, [compiler_core_state](compiler_core_state.md); for codegen node recipes, [compiler_core_builders](compiler_core_builders.md).

---

## 6. Documentation map (generated files)

All documentation lives in this flat directory. This module's pages:

- `compiler_core.md` *(this file — overview, architecture, pipeline)*
- [compiler_core_entry.md](compiler_core_entry.md) — `index.js`: `compile`, `compileModule`, `parse`, `to_public_ast`
- [compiler_core_options.md](compiler_core_options.md) — `validate-options.js`: validator combinators and option schemas
- [compiler_core_state.md](compiler_core_state.md) — `state.js`: global state, `reset`/`adjust`, `svelte-ignore` stack
- [compiler_core_builders.md](compiler_core_builders.md) — `utils/builders.js`: ESTree node factory library

Adjacent modules referenced above: [compiler_parser](compiler_parser.md), [compiler_analyzer](compiler_analyzer.md), [compiler_css_pipeline](compiler_css_pipeline.md), [compiler_client_transform](compiler_client_transform.md), [compiler_server_transform](compiler_server_transform.md), [compiler_diagnostics](compiler_diagnostics.md), [compiler_types](compiler_types.md), [compiler_preprocess](compiler_preprocess.md), [compiler_migrate](compiler_migrate.md).
