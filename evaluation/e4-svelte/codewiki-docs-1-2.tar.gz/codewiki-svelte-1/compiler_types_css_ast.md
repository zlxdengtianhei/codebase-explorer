# compiler_types_css_ast

## 1. Introduction

`compiler_types_css_ast` defines the **CSS Abstract Syntax Tree (AST) type model** for the Svelte compiler. It lives in a single declaration file:

```
packages/svelte/src/compiler/types/css.d.ts
```

The module declares the `_CSS` namespace, which contains every node interface the compiler uses to represent the contents of a component's `<style>` block: stylesheets, at-rules, rules, selector lists, individual simple selectors, combinator relationships, declaration blocks, and declarations.

Its responsibilities are:

1. **Contract definition** — providing the structural, discriminated-union shape that the CSS parser produces during `1-parse` and that all downstream CSS phases (analysis, scoping/pruning, transformation) consume.
2. **Position tracking** — guaranteeing every node carries `start`/`end` character offsets so downstream phases can perform surgical source edits (via `MagicString`), emit source maps, and render precise error/warning code frames.
3. **Analysis metadata contract** — reserving typed `metadata` (`@internal`) slots on `Rule`, `ComplexSelector`, and `RelativeSelector` where the CSS analysis and scoping passes record their conclusions (globality, usage, scoped status).
4. **Walker compatibility** — exporting the `Node` union so generic tree-walking utilities (`zimmerframe`) can traverse the CSS tree type-safely.

This module is a **leaf type module**: it contains no runtime logic and no runtime dependencies. It only imports `AST.Comment` from the template AST (`#compiler`) for the `StyleSheet.content.comment` field.

---

## 2. Architectural Context

The module is one of four type modules under `compiler_types` in the compiler infrastructure. It sits between the parser (producer) and the CSS pipeline (consumers).

```mermaid
flowchart TD
    subgraph types["compiler_types (AST Type Model)"]
        TPL["template.d.ts<br/>(template AST)"]
        CSS["css.d.ts<br/>(_CSS namespace)<br/>★ this module"]
        LEG["legacy-nodes.d.ts<br/>(legacy AST)"]
        IDX["index.d.ts<br/>(CompileResult, CompileError)"]
    end

    P["compiler_parser<br/>1-parse: CSS reader inside<br/>&lt;style&gt; processing"] -- "produces<br/>StyleSheet tree" --> CSS
    TPL -. "AST.Comment reference<br/>for StyleSheet.content.comment" .-> CSS

    CSS -- "consumed by" --> AN["compiler_css_pipeline_analysis<br/>(2-analyze/css/css-analyze.js)<br/>is_global_block_selector · is_in_global_block · is_unscoped<br/>phases/css.js: is_keyframes_node"]
    CSS -- "consumed by" --> PR["CSS scoping / pruning<br/>(css-prune: sets used & scoped flags)"]
    CSS -- "consumed by" --> TX["compiler_css_pipeline_transform<br/>(3-transform/css/index.js)<br/>remove_global_pseudo_class · escape_comment_close"]

    AN --> PR --> TX
    TX -- "final CSS text + ast" --> IDX["CompileResult.css<br/>(compiler_types_compiler_api)"]
    IDX -. "re-exported in public<br/>svelte/types/index.d.ts" .-> PUB["public type surface<br/>(svelte-types)"]
```

Key relationships:

| Relationship | Counterpart module | Nature |
|---|---|---|
| Produced by | [compiler_parser](compiler_parser.md) | The parse phase (`phases/1-parse`) parses `<style>` contents into a `StyleSheet` conforming to these interfaces |
| Consumed by | [compiler_css_pipeline_analysis](compiler_css_pipeline_analysis.md) | `css-analyze.js` reads/writes the `metadata` fields and inspects `PseudoClassSelector` nodes |
| Consumed by | [compiler_css_pipeline_transform](compiler_css_pipeline_transform.md) | `3-transform/css/index.js` edits the output CSS using node `start`/`end` offsets |
| Referenced types | [compiler_types_template_ast](compiler_types_template_ast.md) | `AST.Comment` is embedded in `StyleSheet.content.comment` |
| Sibling type model | [compiler_types_legacy_ast](compiler_types_legacy_ast.md) | Shares the same `BaseNode`-with-positions convention for the legacy (Svelte 4) AST |
| Exposed through | [compiler_types_compiler_api](compiler_types_compiler_api.md) | `CompileResult` carries the CSS `ast`; several selector types (`ClassSelector`, `PseudoClassSelector`, …) are re-exported on the public `svelte/types` surface |

---

## 3. Node Model

### 3.1 Node Hierarchy

All nodes extend `BaseNode` (`{ start: number; end: number }`) and are discriminated by a string-literal `type` field. The tree decomposes along two axes: **structure** (stylesheet → rules/blocks → declarations) and **selectors** (selector list → complex → relative → simple selectors).

```mermaid
classDiagram
    class BaseNode {
        +number start
        +number end
    }

    class StyleSheet {
        +type = 'StyleSheet'
        +attributes : any[]
        +children : (Atrule | Rule)[]
        +content : {start, end, styles, comment}
    }
    class Atrule {
        +type = 'Atrule'
        +name : string
        +prelude : string
        +block : Block | null
    }
    class Rule {
        +type = 'Rule'
        +prelude : SelectorList
        +block : Block
        +metadata : RuleMetadata
    }
    class Block {
        +type = 'Block'
        +children : (Declaration | Rule | Atrule)[]
    }
    class Declaration {
        +type = 'Declaration'
        +property : string
        +value : string
    }

    class SelectorList {
        +type = 'SelectorList'
        +children : ComplexSelector[]
    }
    class ComplexSelector {
        +type = 'ComplexSelector'
        +children : RelativeSelector[]
        +metadata : ComplexSelectorMetadata
    }
    class RelativeSelector {
        +type = 'RelativeSelector'
        +combinator : Combinator | null
        +selectors : SimpleSelector[]
        +metadata : RelativeSelectorMetadata
    }
    class Combinator {
        +type = 'Combinator'
        +name : string
    }

    BaseNode <|-- StyleSheet
    BaseNode <|-- Atrule
    BaseNode <|-- Rule
    BaseNode <|-- Block
    BaseNode <|-- Declaration
    BaseNode <|-- SelectorList
    BaseNode <|-- ComplexSelector
    BaseNode <|-- RelativeSelector
    BaseNode <|-- Combinator
    BaseNode <|-- SimpleSelector

    StyleSheet o-- "children" Atrule
    StyleSheet o-- "children" Rule
    Rule o-- "prelude" SelectorList
    Rule o-- "block" Block
    Block o-- "children" Declaration
    Block o-- "children" Rule
    Block o-- "children" Atrule
    SelectorList o-- "children" ComplexSelector
    ComplexSelector o-- "children" RelativeSelector
    RelativeSelector o-- "combinator" Combinator
    RelativeSelector o-- "selectors" SimpleSelector
```

The `SimpleSelector` type is a union of nine leaf selector kinds, plus `Percentage`/`Nth` for `@keyframes`/`nth-*` contexts:

```mermaid
classDiagram
    class SimpleSelector {
        <<union type>>
    }
    class TypeSelector { +type='TypeSelector' +name (e.g. div) }
    class IdSelector { +type='IdSelector' +name (e.g. #app) }
    class ClassSelector { +type='ClassSelector' +name (e.g. .card) }
    class AttributeSelector {
        +type='AttributeSelector'
        +name +matcher +value +flags (e.g. [href="x" i])
    }
    class PseudoElementSelector { +type='PseudoElementSelector' +name (e.g. ::before) }
    class PseudoClassSelector {
        +type='PseudoClassSelector'
        +name +args : SelectorList | null (e.g. :hover, :global(...))
    }
    class Percentage { +type='Percentage' +value (e.g. 50% in keyframes) }
    class Nth { +type='Nth' +value (e.g. 2n+1) }
    class NestingSelector { +type='NestingSelector' +name = '&' }
    SimpleSelector ..|> TypeSelector
    SimpleSelector ..|> IdSelector
    SimpleSelector ..|> ClassSelector
    SimpleSelector ..|> AttributeSelector
    SimpleSelector ..|> PseudoElementSelector
    SimpleSelector ..|> PseudoClassSelector
    SimpleSelector ..|> Percentage
    SimpleSelector ..|> Nth
    SimpleSelector ..|> NestingSelector
```

### 3.2 Structural Nodes

| Interface | `type` literal | Role | Notable fields |
|---|---|---|---|
| `BaseNode` | — | Base interface for all CSS nodes | `start`, `end` (character offsets, **required** — unlike the template AST where they are optional) |
| `StyleSheet` | `'StyleSheet'` | Root node for one component's `<style>` contents | `attributes` (style-tag attributes, untyped TODO), `children: (Atrule \| Rule)[]`, `content: { start, end, styles, comment: AST.Comment \| null }` |
| `Atrule` | `'Atrule'` | At-rule (`@media`, `@keyframes`, `@supports`, …) | `name`, `prelude` (raw string), `block: Block \| null` (block-less at-rules such as `@import` have `null`) |
| `Rule` | `'Rule'` | A CSS rule: selector prelude + block | `prelude: SelectorList`, `block: Block`, `metadata` (see §4) |
| `Block` | `'Block'` | A `{ … }` block | `children: (Declaration \| Rule \| Atrule)[]` — nested rules model CSS nesting |
| `Declaration` | `'Declaration'` | A property declaration (`color: red`) | `property`, `value` (raw strings) |

### 3.3 Selector Nodes

The selector model mirrors the CSS Selectors grammar with one level per specificity concept:

| Interface | `type` literal | Matches | Example |
|---|---|---|---|
| `SelectorList` | `'SelectorList'` | Comma-separated selectors | `a, b, c {}` → 3 `ComplexSelector` children |
| `ComplexSelector` | `'ComplexSelector'` | One full selector | `a b c` → 3 `RelativeSelector` children |
| `RelativeSelector` | `'RelativeSelector'` | One compound step, optionally with a leading combinator | In `a > b`: `a` (combinator `null`) and `> b` (combinator `'>'`) |
| `Combinator` | `'Combinator'` | Descendant (`' '`), `>`, `+`, `~` | `name` holds the raw combinator text |
| `TypeSelector` | `'TypeSelector'` | Element type | `div` |
| `IdSelector` | `'IdSelector'` | ID | `#app` |
| `ClassSelector` | `'ClassSelector'` | Class | `.card` |
| `AttributeSelector` | `'AttributeSelector'` | Attribute test | `[href="x" i]` → `matcher='='`, `value='"x"'`, `flags='i'` |
| `PseudoElementSelector` | `'PseudoElementSelector'` | Pseudo-element | `::before` |
| `PseudoClassSelector` | `'PseudoClassSelector'` | Pseudo-class | `:hover`; `:is(…)` carries `args: SelectorList`; **`args === null` for bare `:global`** |
| `Percentage` | `'Percentage'` | Keyframe offset | `50%` |
| `Nth` | `'Nth'` | An+B expression | `2n+1` inside `:nth-child(…)` |
| `NestingSelector` | `'NestingSelector'` | CSS nesting parent ref | `&` (literal `name`) |

### 3.4 Example: Source Text → AST

```css
/* inside <style> */
@media (min-width: 100px) {
  .card :global(p) { color: red; }
}
@keyframes fade { 0% { opacity: 0 } }
```

```
StyleSheet
├── Atrule  (name: 'media', prelude: '(min-width: 100px)')
│   └── Block
│       └── Rule
│           ├── prelude: SelectorList
│           │   └── ComplexSelector
│           │       ├── RelativeSelector            (combinator: null)
│           │       │   └── [ClassSelector '.card']
│           │       └── RelativeSelector            (combinator: ' ')
│           │           └── [PseudoClassSelector 'global', args: SelectorList([TypeSelector 'p'])]
│           └── Block → [Declaration 'color: red']
└── Atrule  (name: 'keyframes', prelude: 'fade')
    └── Block
        └── Rule → Percentage '0%' → Block → [Declaration 'opacity: 0']
```

---

## 4. Analysis Metadata Contract (`@internal`)

The AST nodes are **pure parse output**, but the CSS pipeline needs to record analysis conclusions. This is done via typed `metadata` objects marked `/** @internal */`. They are never part of the public API contract and are populated progressively by the CSS pipeline (see [compiler_css_pipeline_analysis](compiler_css_pipeline_analysis.md)).

### 4.1 `Rule.metadata`

| Field | Type | Meaning | Populated by |
|---|---|---|---|
| `parent_rule` | `null \| Rule` | Enclosing `Rule` for CSS nesting chains | css-analyze |
| `has_local_selectors` | `boolean` | At least one selector of this rule is component-local | css-analyze / prune |
| `has_global_selectors` | `boolean` | Every `RelativeSelector` of every `ComplexSelector` is global or global-like → the entire rule body is emitted unscoped | css-analyze |
| `is_global_block` | `boolean` | The rule contains a `:global` selector; everything inside is treated as unscoped | css-analyze |

### 4.2 `ComplexSelector.metadata`

| Field | Type | Meaning |
|---|---|---|
| `rule` | `null \| Rule` | Back-reference to the owning rule (avoids parent-pointer plumbing) |
| `is_global` | `boolean` | The whole complex selector is global |
| `used` | `boolean` | Selector applies to at least one element in the template — set in **css-analyze** for global selectors and in **css-prune** (while scoping) for the rest. Drives the `css_unused_selector` warning |

### 4.3 `RelativeSelector.metadata`

| Field | Type | Meaning |
|---|---|---|
| `is_global` | `boolean` | The whole relative selector is unscoped: bare `:global`, `:global.x` style forms. `:global(...).x` is *not* global (still needs scoping); `:global(...):is/where/not/has(...)` only if all children are global |
| `is_global_like` | `boolean` | `:root`, `:host`, `::view-transition`, or any selector appearing *after* a `:global` |
| `scoped` | `boolean` | Final scoping decision emitted by css-prune |

### 4.4 How Consumers Read the Flags

The predicates exported by the CSS pipeline are thin readers of this metadata — which is why the metadata contract matters:

```js
// css-analyze.js — a bare ':global' (no args) starts a global *block*
function is_global_block_selector(simple_selector) {
    return simple_selector.type === 'PseudoClassSelector' &&
           simple_selector.name === 'global' &&
           simple_selector.args === null;
}

// css-analyze.js and 3-transform/css/index.js — "am I inside a :global block?"
function is_in_global_block(path) {
    return path.some((node) => node.type === 'Rule' && node.metadata.is_global_block);
}

// css-analyze.js — unscoped when every enclosing rule is fully global
function is_unscoped(path) {
    return path.filter((node) => node.type === 'Rule')
               .every((node) => node.metadata.has_global_selectors);
}
```

Note the `PseudoClassSelector.args === null` check: the AST deliberately encodes the distinction between `:global` (bare — block-global) and `:global(…)` (wrapping — inline-global) purely in the presence/absence of `args`.

---

## 5. Data Flow Through the Compiler

```mermaid
sequenceDiagram
    autonumber
    participant Parse as 1-parse (compiler_parser)
    participant Analyze as 2-analyze css-analyze<br/>(compiler_css_pipeline_analysis)
    participant Prune as css-prune / scoping
    participant Transform as 3-transform css<br/>(compiler_css_pipeline_transform)
    participant Result as CompileResult<br/>(compiler_types_compiler_api)

    Note over Parse: CSS reader parses <style> text<br/>into StyleSheet (positions + structure only)
    Parse->>Analyze: StyleSheet AST

    Note over Analyze: classify globality
    Analyze->>Analyze: is_global_block_selector() flags<br/>RelativeSelector.metadata.is_global
    Analyze->>Analyze: propagate to Rule.metadata<br/>(is_global_block, has_global_selectors)
    Analyze->>Analyze: match selectors against template,<br/>set ComplexSelector.metadata.used (global ones)

    Analyze->>Prune: annotated AST
    Note over Prune: scope local selectors (inject class),<br/>set ComplexSelector.metadata.used,<br/>RelativeSelector.metadata.scoped
    Prune->>Transform: pruned + scoped AST

    Note over Transform: text-level edits keyed by BaseNode offsets
    Transform->>Transform: remove_global_pseudo_class()<br/>(strips ':global' / ':global(...)' wrappers)
    Transform->>Transform: escape_comment_close()<br/>(walks node.start..node.end in source)
    Transform->>Result: final CSS text + ast + map
```

Two properties of the type model make this pipeline possible:

- **Offsets enable text surgery.** `remove_global_pseudo_class` and `escape_comment_close` operate on the *original source text* using `node.start` / `node.end` — they never rebuild CSS from the AST. Accurate, required offsets on `BaseNode` are therefore load-bearing.
- **Metadata decouples analysis from transformation.** The transform re-derives context cheaply via `is_in_global_block(path)` instead of re-analyzing selectors, because the analyze pass already persisted its verdicts in `Rule.metadata.is_global_block`.

Special-cased at-rules: `phases/css.js` exposes `is_keyframes_node = (node) => remove_css_prefix(node.name) === 'keyframes'` — keyframe names inside components get scoped/renamed, so `Atrule.name` is inspected across vendor prefixes.

---

## 6. Walker Integration

The `Node` union is exported explicitly *"for zimmerframe"* (the tree-walking utility used throughout the compiler):

```ts
export type Node =
    | StyleSheet
    | Rule
    | Atrule
    | SelectorList
    | Block
    | ComplexSelector
    | RelativeSelector
    | Combinator
    | SimpleSelector
    | Declaration;
```

All structural and selector nodes participate in generic traversal, which is how `css-analyze.js` and the CSS transform receive a `path` array of ancestors (see `is_in_global_block(path)` above). The discriminated `type` literal enables exhaustive `switch` handling in visitors — the same pattern used by the template AST walkers (see [compiler_types_template_ast](compiler_types_template_ast.md)) and legacy AST (see [compiler_types_legacy_ast](compiler_types_legacy_ast.md)).

---

## 7. Design Notes & Invariants

1. **Discriminated unions everywhere.** Every interface fixes a unique string `type`. Downstream code never type-narrows by shape, only by `type`.
2. **Positions are mandatory.** Unlike the template `BaseNode` (where `start`/`end` are optional), the CSS `BaseNode` requires them — CSS is always fully parsed from source and always re-emitted via offset-based edits.
3. **Raw strings over sub-ASTs at the leaf level.** `Atrule.prelude`, `Declaration.property/value`, and `Nth.value` are raw text; only *selectors* get full structural parsing, because scoping decisions need selector granularity but not declaration granularity.
4. **`PseudoClassSelector.args` is the global-mode discriminator.** `args === null` ⇒ bare `:global` (block-global); `args: SelectorList` ⇒ `:global(…)` (wrapping). Several error/warning codes in [compiler_diagnostics](compiler_diagnostics_errors.md) (`css_global_block_invalid_*`, `css_global_invalid_*`) exist to police malformed combinations of these forms.
5. **Analysis results live on the nodes, not in a side table.** `metadata` fields travel with the tree, letting any phase query context with just a `path` — no separate symbol table required.
6. **Single cross-AST dependency.** The only import is `AST.Comment` from the template type model, used for the doc-comment heuristics atop `<style>` (`StyleSheet.content.comment`).
7. **Namespace-encapsulated and publicly surfaced.** Types are declared inside the `_CSS` namespace and are re-exported through the public type surface (`svelte/types/index.d.ts` re-exports `TypeSelector`, `IdSelector`, `ClassSelector`, `AttributeSelector`, `PseudoElementSelector`, `PseudoClassSelector`, `Percentage`, `NestingSelector`, `Nth`), so downstream tooling (language servers, plugins) can type against the same AST the compiler produces.

---

## 8. Related Modules

- [compiler_types_template_ast](compiler_types_template_ast.md) — the template AST type model; provides `AST.Comment` and shares the positions + metadata conventions.
- [compiler_types_legacy_ast](compiler_types_legacy_ast.md) — Svelte 4 node model, including `LegacySelector`/`LegacyStyle` which this module supersedes.
- [compiler_types_compiler_api](compiler_types_compiler_api.md) — `CompileResult` / `CompileOptions`; the CSS AST is embedded in `CompileResult.css.ast`.
- [compiler_parser](compiler_parser.md) — parse phase; its style-tag handling produces `StyleSheet` trees per this contract.
- [compiler_css_pipeline_analysis](compiler_css_pipeline_analysis.md) — populates the `metadata` flags; globality classification and unused-selector detection.
- [compiler_css_pipeline_transform](compiler_css_pipeline_transform.md) — offset-based CSS output edits (`remove_global_pseudo_class`, `escape_comment_close`).
- [compiler_analyzer_scope](compiler_analyzer_scope.md) — component-level scoping state consulted when deciding selector scope.
- [public_api](public_api.md) / [svelte-types](svelte-types.md) — where the CSS AST types reach end users and ecosystem tooling.