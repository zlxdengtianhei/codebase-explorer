# Client DOM Renderer (`client_dom_renderer`)

## 1. Purpose & Scope

The **Client DOM Renderer** is Svelte 5's client-side rendering backend: the set of runtime primitives that *compiled* component code calls in order to **create, update, hydrate, and destroy** live DOM. It lives under `packages/svelte/src/internal/client/dom/` (plus the `render.js` lifecycle entry point).

It is the bridge between two other subsystems:

- **Upstream — the compiler**: The client transform (`Compiler Back-End → compiler_client_transform`) emits JavaScript that does *not* manipulate the DOM directly. Instead it calls helpers exported by this module, conventionally namespaced as `$.` in compiled output (`$.from_html(...)`, `$.if_block(...)`, `$.attribute_effect(...)`, `$.bind_value(...)`, `$.append_styles(...)`, …).
- **Downstream — the reactive runtime engine** (`Reactive_Runtime_Engine_(Signals,_Effects___Batching_with_Dev-Mode_Instrumentation)`): signals, effects, and batches decide *when* renderer code runs. The renderer registers effects (via `block`, `branch`, `render_effect`, `effect`) and the engine re-runs them when state changes.

A sibling module, `server_runtime`, implements the server-side (SSR) counterpart: the same semantic operations, but emitting strings instead of DOM nodes.

```
 .svelte source ──► Compiler (parse → analyze → client transform)
                        │  emits calls to runtime helpers
                        ▼
   ┌─────────────────────────────────────────────────────────┐
   │              Client DOM Renderer (this module)          │
   │  render.js   blocks/   elements/   bindings/   dom/*    │
   └─────────────────────────────────────────────────────────┘
                        │  registers effects, reads signals,
                        │  mutates DOM nodes
                        ▼
        Reactive Runtime Engine (signals · effects · batching)
                        │
                        ▼
                      The DOM
```

## 2. Architecture Overview

The module is organized into five cooperating layers. Each layer only depends on the layers below it, keeping the codebase navigable despite its size.

```mermaid
flowchart TD
    subgraph L1["Layer 1 · Lifecycle API"]
        MOUNT["mount / hydrate / unmount<br/>(render.js)"]
    end

    subgraph L2["Layer 2 · Control-Flow Blocks"]
        IF["if_block"] EACH["each + reconcile"] KEY["key"]
        AWAIT["await_block"] ASYNC["async"] BND["Boundary"]
        SNIP["snippet / slot"] HTML["html"] SEL["svelte:element"] HEAD["svelte:head"]
    end

    subgraph L3["Layer 3 · Elements & Events"]
        ATTR["attribute_effect<br/>set_attributes"]
        EVT["event delegation<br/>handle_event_propagation"]
        TR["transition / animation"]
        CE["custom elements"]
    end

    subgraph L4["Layer 4 · Bindings"]
        BIN["bind_value · bind_group · media<br/>select · size · this · window …"]
    end

    subgraph L5["Layer 5 · DOM Foundation"]
        TPL["template.js<br/>from_html/from_svg/from_mathml/from_tree"]
        OPS["operations.js<br/>child/sibling/first_child"]
        HYD["hydration.js<br/>walk SSR markers"]
        CSS["css.js<br/>append_styles"]
    end

    MOUNT --> L2
    MOUNT --> L3
    L2 --> L3
    L2 --> L5
    L3 --> L5
    L4 --> L3
    L4 --> L5
```

### Layer responsibilities

| Layer | Files | Responsibility |
|---|---|---|
| **Lifecycle API** | `render.js` | Public entry points `mount`, `hydrate`, `unmount`; text diffing (`set_text`); event-delegation wiring at the root. |
| **Control-flow blocks** | `dom/blocks/*` | Implement `{#if}`, `{#each}`, `{#key}`, `{#await}`, `{#snippet}`, `<slot>`, `{@html}`, `<svelte:element>`, `<svelte:head>`, `<svelte:boundary>`, CSS props, and async expressions. Each block owns a *branch effect* whose DOM is created/paused/resumed/destroyed. |
| **Elements & Events** | `dom/elements/*` | Declarative attribute spreading (`attribute_effect`), delegated event handling, transitions/animations (`transition`, `animation`), custom element wrappers, misc DOM edge cases. |
| **Bindings** | `dom/elements/bindings/*` | Two-way bindings (`bind:value`, `bind:group`, `bind:this`, media/window/size/… bindings) — each combines an event listener (DOM → state) with a render effect (state → DOM). |
| **DOM Foundation** | `dom/operations.js`, `dom/template.js`, `dom/hydration.js`, `dom/css.js` | Low-level node traversal/creation, template cloning/caching, hydration-walk state machine, scoped style injection. |

### Detailed sub-module documentation

| Sub-module | Documentation File | Covers |
|---|---|---|
| **Lifecycle API** | [client_dom_renderer_lifecycle_api.md](client_dom_renderer_lifecycle_api.md) | `mount` / `hydrate` / `unmount` (`render.js`), `set_text` diffing, root event-delegation wiring, hydration fallback strategy. |
| **DOM Foundation** | [client_dom_renderer_dom_foundation.md](client_dom_renderer_dom_foundation.md) | Template cloning/caching (`from_html`/`from_svg`/`from_mathml`/`from_tree`, `text`, `comment`, `props_id`), node traversal (`operations.js`), the hydration state machine (`hydration.js`), scoped style injection (`css.js::append_styles`). |
| **Control-Flow Blocks** | [client_dom_renderer_control_flow_blocks.md](client_dom_renderer_control_flow_blocks.md) | `{#if}` / `{#each}` (+ keyed reconciliation) / `{#key}` / `{#await}` / async expressions / `<svelte:boundary>` / snippets & slots / `{@html}` / `<svelte:element>` / `<svelte:head>` / `style:` props. |
| **Elements, Attributes, Events & Transitions** | [client_dom_renderer_elements_and_events.md](client_dom_renderer_elements_and_events.md) | `attribute_effect` & attribute spreading, delegated event system (`handle_event_propagation`), transition/animation managers, custom element wrapper, misc DOM helpers. |
| **Two-Way Bindings** | [client_dom_renderer_bindings.md](client_dom_renderer_bindings.md) | `bind:value` / `bind:group` / `bind:checked`, `bind:select`-family, `bind:this`, `bind:prop`, contenteditable/universal, media, size (`ResizeObserverSingleton`), window/document/navigator bindings. |

> Supporting files consumed but not individually documented: `dom/reconciler.js` (`create_fragment_from_html`) and `dom/task.js` (micro/idle task queues) — they are covered within the **DOM Foundation** page; `dom/elements/bindings/shared.js` (`listen`) is covered within the **Bindings** page.

## 3. Core Concepts

### 3.1 Anchors and effect-owned node ranges

Almost every renderer function receives an **anchor** — a `Comment`/`Text`/`Element` node marking where content belongs. Block effects track the exact node range they own through `effect.nodes_start` / `effect.nodes_end` (assigned via `assign_nodes` in `template.js`). This is what makes pause/resume/destroy of arbitrary content possible without re-rendering siblings.

### 3.2 Effects and branches

The renderer builds on the reactive engine's effect tree (see the [Reactive Runtime Engine] documentation for effect mechanics):

- `block(fn, flags)` — a re-runnable effect implementing a control-flow condition (e.g. re-evaluate the `if` condition).
- `branch(fn)` — creates child content inside a dedicated effect; branches can be **paused** (`pause_effect` → run out-transitions, then destroy) and **resumed** (`resume_effect`) instead of being recreated.
- `render_effect` / `effect` — fine-grained property updates (attribute values, text, bindings).

### 3.3 Hydration markers

Server-rendered HTML embeds comment markers (`<!--[-->`, `--]>`, `<!--[!-->`) produced by `server_runtime`. During `hydrate()`, the renderer walks these markers via the state machine in `hydration.js` (`hydrating`, `hydrate_node`, `hydrate_next`, `remove_nodes`), and every block/element/binding has a hydration-aware path. On **mismatch**, blocks remove the server DOM (`remove_nodes()`) and rebuild client-side — this "repair" strategy keeps hydration resilient.

### 3.4 Batch-aware DOM commits

In async mode, block effects do **not** mutate the DOM immediately on re-run. `should_defer_append()` (in `operations.js`) detects that a batch is committing, so blocks render into an **offscreen `DocumentFragment`** and register a `Batch.add_callback(commit)` — the fragment is inserted when the batch commits (see `if_block`, `each`, `key`). This guarantees atomic, order-consistent DOM updates across concurrent async work.

### 3.5 Template cloning & caching

Static template fragments are compiled into string constants; `from_html` / `from_svg` / `from_mathml` / `from_tree` parse the string **once**, cache the resulting node, and cheaply `cloneNode(true)` per instantiation. `use_import_node`/Firefox handling and `<!>`-prefixed starts (forcing a leading comment anchor) are handled internally.

### 3.6 Event delegation

For performance, common events (`click`, `input`, …) are attached **once at the root** (`handle_event_propagation` walks the composed path) while individual handlers are stored on elements as `element.__click`-style properties. `events.js` also handles capture-phase handlers, passive-event optimization, event replay after SSR (`replay_events`), and dev-mode handler validation (`apply`).

## 4. Key Flows

### 4.1 Mounting and hydration

```mermaid
sequenceDiagram
    participant App as Application code
    participant R as render.js
    participant E as Engine (effects/batches)
    participant B as Blocks/Elements
    participant D as DOM

    App->>R: mount(Component, { target, props })
    R->>R: init_operations() — patch prototypes,<br/>cache getters
    R->>E: component_root(branch(...))
    E->>B: run compiled component fn(anchor, props)
    B->>D: clone templates, insert elements,<br/>set attributes, attach listeners
    B->>E: register block/render effects
    R-->>App: component exports
    Note over R,D: unmount(component, { outro }) later<br/>tears down root effect + listeners

    App->>R: hydrate(Component, { target })
    R->>D: find <!--[--> marker, set_hydrating(true)
    R->>B: same component fn, but hydration-aware
    B->>D: walk SSR markers instead of creating nodes
    alt mismatch detected
        B->>D: remove_nodes() + rebuild client-side
    end
    R-->>App: exports (or falls back to mount)
```

### 4.2 Reactive update of a block

```mermaid
sequenceDiagram
    participant S as State (signal)
    participant E as Engine
    participant IB as if_block effect
    participant DOM

    S-->>E: source.set(newValue)
    E->>IB: re-run block effect
    IB->>IB: condition changed?
    IB->>IB: branch() new branch —<br/>offscreen fragment if batch committing
    IB->>IB: pause_effect(old branch)<br/>(runs out-transitions)
    IB->>DOM: commit: insert fragment,<br/>pause/destroy inactive branch
    Note over IB,DOM: In sync mode the commit is immediate;<br/>in async mode it waits for Batch.#commit()
```

### 4.3 Two-way binding round trip (e.g. `bind:value`)

```mermaid
flowchart LR
    A["user input event"] -->|"input listener"| C["set(value) → source"]
    C --> E["engine flush / batch"]
    E -->|"render_effect"| I["input.value = value<br/>(guarded: focus, selection,<br/>number/date coercion)"]
    I --> A
```

## 5. Relationship to Other Modules

| Module | Relationship |
|---|---|
| **Compiler Back-End (Client Code Generation)** | Emits calls into this module's exports; the helper names must stay in lockstep with the codegen visitors (e.g. `client/visitors/IfBlock.js` emits `$.if_block`). |
| **Reactive Runtime Engine** | Supplies `block/branch/pause_effect/resume_effect/render_effect/effect`, `source/internal_set`, `Batch`/`flushSync`, `get`, `tick`, and dev-mode instrumentation. The renderer is essentially a large consumer of these APIs. |
| **server_runtime** | Semantic counterpart for SSR. The hydration markers this module consumes are produced there (`props_id`, `attr_class`, `await_block`, …). |
| **Cross-Runtime Platform Services** | Shared utilities (`noop`, `is_array`, descriptors), runtime flags (`async_mode_flag`, legacy/dev flags), and the context API used by `Boundary` and custom elements. |
| **Public API Surface** | Exposes `mount`, `hydrate`, `unmount`, `createRawSnippet` and transitions/attachments to user land; this module implements their runtime behavior. |

## 6. Usage in Compiled Output (illustrative)

```js
// Simplified output of the client compiler for:
//   {#if visible}<p class="greet">Hi {name}</p>{/if}
import * as $ from 'svelte/internal/client';

export default function App($$anchor, $$props) {
        $$.bindings = {}; // ...

        var fragment = $.from_html('<!><p class="greet">…</p>', 1)(); // template clone
        var p = $.sibling($.child(fragment));

        // attribute + text updates as render effects
        $.attribute_effect(p, () => ({ class: 'greet' }));
        var text = $.child(p, true);
        $.set_text(text, /* get name */);

        // control flow as a block effect
        $.if_block($$anchor, (branch) => {
                branch(() => $$props.visible && fragment_anchor, ...);
        });
}
```

The renderer's contract with the compiler is deliberately narrow: plain functions over anchors and render closures, plus flag bitmasks — which keeps compiled output small and tree-shakeable (see `scripts/check-treeshakeability.js` in the repository engineering module).

## 7. Design Notes & Invariants

1. **Anchors are the universal addressing scheme.** Text nodes double as anchors (`create_text()`); comment markers double as block boundaries during hydration.
2. **Pause ≠ destroy.** Blocks pause branches to let out-transitions play; destruction happens in the transition callback. This powers `{#each}` reconciliation and `<svelte:element>` tag switches.
3. **Keyed reconciliation in `each.js`.** Items live in a doubly linked list (`EachItem.prev/next`) mirroring the DOM; `reconcile` performs a LIS-like match/move algorithm and supports animations (`EACH_IS_ANIMATED` → `measure/fix/apply/unfix`).
4. **Hydration is optimistic.** Every hydration path validates expected markers and *repairs* by rebuilding when they don't match, rather than failing hard (`hydrate(..., recover)` even falls back to a full client `mount`).
5. **Dev-mode code paths are isolated.** Ownership validation, `__svelte_meta` location tagging, style cleanup (`dev/css.js`) and handler warnings are all gated on `DEV` and tree-shaken in production.
6. **Custom elements bridge legacy class components.** `create_custom_element` wraps a component with an `HTMLElement` subclass handling attribute reflection, slots (`get_custom_elements_slots`), and lifecycle (`connectedCallback`/`disconnectedCallback`).

## 8. File Map

```
src/internal/client/
├── render.js                     ← mount / hydrate / unmount / set_text
└── dom/
    ├── operations.js             ← node traversal, creation, $window/$document, should_defer_append
    ├── template.js               ← from_html/from_svg/from_mathml/from_tree, text, comment, assign_nodes
    ├── hydration.js              ← hydrating state, marker walking, remove_nodes
    ├── css.js                    ← append_styles (scoped CSS injection)
    ├── reconciler.js             ← create_fragment_from_html (support)
    ├── task.js                   ← micro/idle task queues (support)
    ├── blocks/
    │   ├── if.js · each.js · key.js · await.js · async.js · boundary.js
    │   ├── snippet.js · slot.js · html.js
    │   └── svelte-element.js · svelte-head.js · css-props.js
    └── elements/
        ├── attributes.js         ← set_attributes / attribute_effect / setters cache
        ├── events.js             ← delegation, create_event, replay_events, apply
        ├── transitions.js        ← transition manager, animation manager, animate()
        ├── custom-element.js     ← create_custom_element, slot bridges
        ├── misc.js               ← autofocus, remove_textarea_child, form reset listener
        └── bindings/
            ├── shared.js         ← listen helpers
            ├── input.js · select.js · props.js · this.js · universal.js
            ├── media.js · size.js · window.js · document.js · navigator.js
```
