# compiler_analyzer_scope

> **Source file:** `packages/svelte/src/compiler/phases/scope.js`
> **Parent module:** [compiler_analyzer](compiler_analyzer.md)
> **Core exports:** `Scope`, `ScopeRoot`, `Binding`, `create_scopes`, `set_scope`, `get_rune`

---

## 1. Introduction

`compiler_analyzer_scope` implements the **lexical scope and binding model** of the Svelte compiler. Once the parser has produced a template + JavaScript AST (see [compiler_parser](compiler_parser.md)), the compiler needs to know, for every identifier in a component:

- **where it was declared** (which scope owns it),
- **what kind of declaration it is** (variable, prop, each-context, snippet param, import, store subscription, …),
- **how it is used** (referenced, reassigned, mutated, used as a function),
- and, where possible, **what its value/type is** (static partial evaluation).

This module answers all four questions. It is the *foundation* on which every analysis visitor ([compiler_analyzer_block_visitors](compiler_analyzer_block_visitors.md), [compiler_analyzer_template_visitors](compiler_analyzer_template_visitors.md), [compiler_analyzer_js_visitors](compiler_analyzer_js_visitors.md)) and ultimately both transform back-ends ([compiler_client_transform](compiler_client_transform.md), [compiler_server_transform](compiler_server_transform.md)) operate.

The module lives at `packages/svelte/src/compiler/phases/scope.js` and exposes:

| Export | Kind | Purpose |
|---|---|---|
| `create_scopes(ast, root, allow_reactive_declarations, parent)` | function | One-pass walk that builds the whole scope tree for a script/template AST |
| `Scope` | class | A single lexical scope: declarations, references, name generation, expression evaluation |
| `ScopeRoot` | class | Per-component root that tracks name conflicts and mints unique identifiers |
| `Binding` | class | Rich record for one declared identifier (kind, mutations, references, metadata) |
| `set_scope(node, context)` | function | Shared zimmerframe `_` visitor that keeps `state.scope` correct during analysis walks |
| `get_rune(node, scope)` | function | Resolves whether a `CallExpression` is a rune call (e.g. `$state(0)`) |

---

## 2. Position in the Compiler

The module sits inside **Phase 2 – Analysis** of the compiler front-end ([compiler_analyzer](compiler_analyzer.md)), immediately downstream of parsing ([compiler_parser](compiler_parser.md)) and upstream of every visitor and the back-end transforms.

```mermaid
flowchart LR
    subgraph pipeline["Svelte compiler pipeline"]
        direction LR
        P["1-parse<br/>compiler_parser"] --> AN["2-analyze<br/>compiler_analyzer"]
        AN --> TR["3-transform<br/>compiler_client_transform / compiler_server_transform"]
    end

    subgraph analyzer["Inside compiler_analyzer"]
        direction TB
        SCOPE["compiler_analyzer_scope<br/>(this module: scope.js)"]
        BV["compiler_analyzer_block_visitors"]
        TV["compiler_analyzer_template_visitors"]
        JV["compiler_analyzer_js_visitors"]
        SCOPE --> BV
        SCOPE --> TV
        SCOPE --> JV
    end

    AN -.->|"scopes + bindings as walking state"| analyzer
```

The CSS-specific scoping logic (selector scoping, `:global` handling) is **not** part of this module — it is covered by [compiler_css_pipeline](compiler_css_pipeline.md). This module deals exclusively with **identifier/binding scoping** of scripts and templates.

---

## 3. Architecture

### 3.1 Component overview

```mermaid
classDiagram
    direction LR

    class ScopeRoot {
        +conflicts Set
        +unique(preferredName) Identifier
    }

    class Scope {
        +root ScopeRoot
        +parent Scope
        -porous boolean
        +declarations Map
        +declarators Map
        +references Map
        +function_depth number
        +tracing Expression
        +declare(node, kind, declKind, initial) Binding
        +child(porous) Scope
        +generate(preferredName) string
        +get(name) Binding
        +get_bindings(node) Binding[]
        +owner(name) Scope
        +reference(node, path)
        +evaluate(expression, values) Evaluation
    }

    class Binding {
        +scope Scope
        +node Identifier
        +kind BindingKind
        +declaration_kind DeclarationKind
        +initial Expression
        +references List
        +legacy_dependencies List
        +prop_alias string
        +metadata object
        +mutated boolean
        +reassigned boolean
        +updated boolean
        +is_function() boolean
    }

    class Evaluation {
        +values Set
        +is_known boolean
        +has_unknown boolean
        +is_defined boolean
        +is_string boolean
        +is_number boolean
        +is_function boolean
        +value any
    }

    class create_scopes {
        «walk driver»
        +returns has_await, scope, scopes
    }

    class set_scope {
        «shared visitor»
    }

    Scope "1" --> "1" ScopeRoot : root
    Scope "0..1" --> "1" Scope : parent / child()
    Scope "1" *-- "0..*" Binding : declarations
    Binding "1" --> "1" Scope : scope
    Scope ..> Evaluation : evaluate()
    create_scopes ..> Scope : builds tree
    create_scopes ..> Binding : creates
    set_scope ..> Scope : restores from scopes map
```

### 3.2 Responsibilities

| Component | Responsibility |
|---|---|
| `ScopeRoot` | One per component. Global registry of `conflicts` (every declared *or* referenced name, including globals) so that generated names never collide. `unique()` mints collision-free `Identifier` nodes (used e.g. for the internal `$$index` of each blocks). |
| `Scope` | One per lexical region. Owns `declarations` (name → `Binding`), `declarators` (declarator/`let:` node → bindings), `references` (name → reference sites with their AST path), and `function_depth`. Resolves names up the `parent` chain. |
| `Binding` | One per declared identifier. Tracks `kind`, `declaration_kind`, `initial` value, all `references`, `mutated`/`reassigned` flags, legacy metadata (`prop_alias`, `legacy_dependencies`, `inside_rest`) and derived predicates (`updated`, `is_function()`). |
| `Evaluation` | Private static partial evaluator computing the set of possible values (or coarse type tags `NUMBER` / `STRING` / `FUNCTION` / `UNKNOWN`) for an expression, with a cycle guard. |
| `create_scopes` | The walk driver that instantiates the entire scope tree and returns `{ has_await, scope, scopes }`. |
| `set_scope` | The glue that re-associates the correct `Scope` with analysis visitors as they descend the AST. |

---

## 4. Core Components in Detail

### 4.1 `Scope` — the lexical region

A `Scope` is created via `new Scope(root, parent, porous)` or, more commonly, `parent.child(porous)`.

**Key fields**

| Field | Meaning |
|---|---|
| `#porous` | If `true`, `var` declarations and `import` declarations *escape* to the parent scope when declared here (JS hoisting semantics). Block scopes (`{}`, `for`, `switch`, `catch`, `$:` labels) and fragments are porous; function scopes and the root scope are not. |
| `declarations` | `Map<string, Binding>` — every identifier declared *directly* in this scope. |
| `declarators` | `Map<VariableDeclarator \| AST.LetDirective, Binding[]>` — reverse lookup from a declarator node to the bindings it produced (used by bindable-prop and each-key logic). |
| `references` | `Map<string, { node, path }[]>` — every reference made *through* this scope, with the full AST path captured at reference time. |
| `function_depth` | Increments only when crossing a **non-porous** boundary (i.e. a function), enabling "declared at top level vs. inside a function" checks (e.g. `$`-prefix validation). |
| `tracing` | Optional expression enabling reactive-dependency tracing for this scope (`$inspect.trace` support). |

**Key methods**

| Method | Behaviour |
|---|---|
| `declare(node, kind, declaration_kind, initial)` | Creates a `Binding`. `var`/`import` declarations are forwarded to the nearest non-porous/module scope. Duplicate non-`var` declarations raise `e.declaration_duplicate` (see [compiler_diagnostics](compiler_diagnostics.md)). Names are validated by `validate_identifier_name` (rejects `$` and `$`-prefixed names at top level). |
| `get(name)` | Resolves a binding by walking up the parent chain; returns `null` for unknown names. |
| `owner(name)` | Returns the `Scope` that declares `name`. |
| `reference(node, path)` | Records a reference in this scope and **all ancestor scopes**; attaches it to the owning `Binding` if one exists, otherwise adds the name to `root.conflicts` (it is a global). The AST `path` is copied so later mutations cannot corrupt stored references. |
| `generate(preferred_name)` | Sanitizes a name and appends `_1`, `_2`, … until it avoids all local declarations/references, `root.conflicts` and reserved words. Registers the chosen name. Used to name synthetic variables during transform. |
| `get_bindings(node)` | Returns the bindings recorded for a declarator / `let:` directive node. |
| `evaluate(expression, values?)` | Runs the static partial evaluator (see §4.4). **Must only be called after scope generation is complete**, otherwise it evaluates against incomplete data. |

### 4.2 `Binding` — one declared identifier

A `Binding` is the compiler's long-lived record of a variable. Analysis visitors **mutate** bindings (e.g. promoting `kind` to `'state'`); transform phases **read** them to decide code shape.

**Lifecycle**

1. **Created** by `Scope.declare()` during `create_scopes` with a `kind` + `declaration_kind`.
2. **Enriched** during analysis: references are attached by `Scope.reference()`; `reassigned`/`mutated` are set from the update pass; visitors may re-classify `kind` (e.g. `normal` → `state`, `normal` → `bindable_prop` in [compiler_analyzer](compiler_analyzer.md)).
3. **Consumed** by the transforms: `binding.updated`, `binding.is_function()`, `binding.kind`, `binding.references` and `binding.initial` drive client/server code generation.

**Binding kinds** (declared in `#compiler` types — see [compiler_types](compiler_types.md)):

| `kind` | Meaning | Assigned by |
|---|---|---|
| `normal` | Plain variable declaration | `create_scopes` |
| `state`, `derived` | Rune-based reactive state (`$state`, `$derived`) | visitors / `analyze_component` |
| `prop`, `rest_prop`, `bindable_prop` | Component inputs (`$props()`, `export let`, `$$props`, `$$restProps`) | `create_scopes` / `analyze_component` |
| `each` | Each-block context variable | `create_scopes` |
| `static`, `template` | Template-scoped bindings (each index, `{@const}`, `let:` directives, await `value`/`error`) | `create_scopes` |
| `snippet` | Snippet block parameter | `create_scopes` |
| `legacy_reactive` | Implicit `$:` reactive declaration | `create_scopes` post-walk |
| `store_sub` | Synthetic `$store` subscription binding | [compiler_analyzer](compiler_analyzer.md) (`analyze_component`) |

**Declaration kinds:** `var`, `let`, `const`, `function`, `import`, `param`, `rest_param`, `synthetic`.

**Important predicates**

- `updated` → `mutated || reassigned` — *"can this value ever change after initialization?"* This is the single most consulted flag in the compiler (it decides whether a variable must become a signal).
- `is_function()` → `true` when the binding was never updated and was initialized directly with an arrow/function expression — allows transforms to pass it around directly (e.g. as an event handler).

### 4.3 `ScopeRoot` — conflict registry & name factory

- `conflicts: Set<string>` — union of every declared name plus every *unresolvable* (global) reference. Globals must be treated as reserved because they might collide with compiler-generated identifiers at runtime.
- `unique(preferred_name)` — sanitizes and dedupes a name against `conflicts`, registers it, and returns a ready-made `b.id(...)` identifier node. Example: `scope.root.unique('$$index')` inside each-block metadata.

### 4.4 `Evaluation` — static partial evaluator (private)

`Scope.evaluate(expression)` returns an `Evaluation` that is either an **exact value set** or a **coarse type tag**:

| Tag | Represents |
|---|---|
| `NUMBER` | "some number" (includes `BigInt`) |
| `STRING` | "some string" |
| `FUNCTION` | "some function" |
| `UNKNOWN` | "cannot determine anything" |

**Derived flags:** `is_known` (exactly one concrete, non-symbol value), `has_unknown`, `is_defined` (not null/undefined), `is_string`, `is_number`, `is_function`, and `value` (the single value, when `is_known`).

**Supported inputs**

| Expression | Evaluation strategy |
|---|---|
| `Literal` | Exact value. |
| `Identifier` | Via its `Binding`: `$props.id()` results → `STRING`; each-block index → `NUMBER`; non-updated, non-prop bindings → evaluate their `initial` recursively; otherwise `UNKNOWN`; bare `undefined` → `undefined`. |
| `BinaryExpression` / `UnaryExpression` / `LogicalExpression` | Fold with the module-level `binary` / `unary` / `logical` operator tables when both operands are known; otherwise infer coarse types (e.g. `+` yields `STRING`/`NUMBER`, comparisons yield `true`/`false`). |
| `ConditionalExpression` | Union of branch values, or only the chosen branch when the test is known. |
| `CallExpression` | **Runes:** `$state`/`$state.raw`/`$derived` → argument values; `$props.id` → `STRING`; `$effect.tracking` → `true`/`false`; `$derived.by` → arrow body values. **Globals:** `Math.*`, `Number.*`, `String.*`, `BigInt` (from the `globals` table) are folded when all arguments are known, else mapped to their type tag. Everything else → `UNKNOWN`. |
| `TemplateLiteral` | Concatenates known parts; escapes to `STRING` on any unknown expression. |
| `MemberExpression` | Matches `global_constants` (`Math.PI`, `Math.E`, …); else `UNKNOWN`. |
| Functions | Tagged `FUNCTION`. |

**Cycle guard:** a module-level `current_evaluations` map records in-flight expressions so self-referential initializers (`let a = b; let b = a;`) cannot recurse infinitely.

### 4.5 `create_scopes(ast, root, allow_reactive_declarations, parent)` — the builder

This is the workhorse of the module. It performs **one zimmerframe walk** (see [compiler_analyzer](compiler_analyzer.md) for walker conventions) plus three **post-walk passes**, and returns:

```js
{ has_await, scope, scopes }   // scope: root Scope; scopes: Map<node, Scope>
```

`has_await` is set when a top-level `await` is found outside any function — one of the signals used by [compiler_analyzer](compiler_analyzer.md) to auto-enable **runes mode**.

```mermaid
flowchart TD
    START["create_scopes(ast, root, allow_reactive_declarations, parent)"] --> ROOT["Create non-porous root Scope (bound to ScopeRoot)"]
    ROOT --> WALK

    subgraph WALK["Single zimmerframe walk over the AST"]
        direction TB
        NODE{"Node encountered"}
        NODE -->|"FunctionExpression / FunctionDeclaration / ArrowFunctionExpression"| F["New non-porous child scope<br/>declare function id + params (param / rest_param)"]
        NODE -->|"BlockStatement / For* / Switch / CatchClause"| B["New porous child scope<br/>(var leaks out, no function_depth increment)"]
        NODE -->|"ImportDeclaration / VariableDeclaration / ClassDeclaration"| D["Declare bindings on current scope<br/>VariableDeclarators registered in declarators"]
        NODE -->|"EachBlock"| E["Child scope: declare each context + index<br/>seed node.metadata (expression, $$index, declarations, transitive_deps)"]
        NODE -->|"AwaitBlock"| AB["Child scopes for then-value / catch-error"]
        NODE -->|"SnippetBlock"| SB["Declare snippet as function in enclosing scope<br/>child scope declares snippet params"]
        NODE -->|"Fragment"| FR["Child scope (porous if metadata.transparent)"]
        NODE -->|"Component / SvelteSelf / SvelteComponent"| CO["Per-slot scopes stored on node.metadata.scopes"]
        NODE -->|"LetDirective (let:xxx)"| LET["Declare template/const bindings + self-reference"]
        NODE -->|"Identifier (is_reference, non-TS)"| REF["Queue reference for post-walk"]
        NODE -->|"AssignmentExpression / UpdateExpression / bind:xxx"| UPD["Queue update target"]
        NODE -->|"$: LabeledStatement (legacy)"| LAB["Child scope; collect implicit reactive targets"]
        NODE -->|"AwaitExpression (outside functions)"| AW["Set has_await"]
        NODE -->|"transition: / animate: / use: — SvelteDirective"| DIR["Reference directive name, visit expression"]
        NODE -->|"style: shorthand (style:height)"| STY["Reference the property name as variable"]
    end

    WALK --> POST["Post-walk passes"]
    POST --> P1["1. Declare implicit legacy_reactive bindings<br/>from $: assignment targets"]
    P1 --> P2["2. Apply queued references via scope.reference()<br/>(bindings attached, unknown globals -> root.conflicts)"]
    P2 --> P3["3. Apply queued updates:<br/>unwrap patterns; mark binding.reassigned / binding.mutated"]
    P3 --> RET["Return { has_await, scope, scopes }"]
```

**Why references and updates are applied *after* the walk:** a single forward walk would otherwise encounter uses before declarations. Deferring keeps `create_scopes` order-insensitive — identical logic is then reused for all three ASTs (module, instance, template).

**Slot scopes (`Component` visitor):** dynamic components and snippets with named slots each get their own `Scope`, recorded on `node.metadata.scopes` keyed by slot name. `determine_slot` (from `utils/slot.js`) decides which children belong to which slot scope. This is what makes `let:` directives correctly scoped per slot.

**`SvelteFragment` visitor (in-walk helper):** shared implementation for `SvelteFragment`, `SlotElement`, `SvelteElement` and `RegularElement` — creates a (porous) child scope per element-like node and records it in `scopes`. Named `<fragment slot=...>` contents therefore resolve bindings inside their slot scope.

**`SvelteDirective` visitor (in-walk helper):** for `transition:`, `animate:` and `use:` directives it registers a reference to the directive *name* (before any `.` modifier) — so `<transition:fade>` resolves the `fade` import — and visits the parameter expression. `StyleDirective` is handled separately: only the **shorthand** form (`<div style:height>`) creates a reference, because normal values are ordinary expressions already covered by the `Identifier` visitor.

### 4.6 `set_scope(node, context)` — scope restoration during analysis

```js
export function set_scope(node, { next, state }) {
    const scope = state.scopes.get(node);
    next(scope !== undefined && scope !== state.scope ? { ...state, scope } : state);
}
```

Analysis visitors are plain objects of per-node handlers registered with zimmerframe. They never manage scope themselves; instead the shared `_` (fallback) visitor is `set_scope`. As the walker enters any node that `create_scopes` mapped to a `Scope`, the state is shallow-cloned with the new `scope`; otherwise the walk continues unchanged (no allocation). Result: `context.state.scope` is *always* the lexically correct scope inside every visitor handler — a core convention of [compiler_analyzer](compiler_analyzer.md).

### 4.7 `get_rune(node, scope)` — rune resolution

Returns the rune name (`'$state'`, `'$derived'`, `'$props'`, …) when `node` is a `CallExpression` invoking a rune, otherwise `null`. The private `get_global_keypath` builds dotted keypaths (`Math.min`, `$state`, `$derived.by`) from member chains — also handling `foo()(...)` shapes — and **returns `null` when a local binding shadows the root identifier**, so a variable named `$state` or an imported `derived` is never mistaken for a rune. Used pervasively by visitors and by `analyze_component` (see [compiler_analyzer](compiler_analyzer.md)); rune detection itself (`is_rune`) lives in the shared compiler utilities (see [compiler_core](compiler_core.md)).

---

## 5. Process Flows

### 5.1 Scope construction inside `analyze_component`

[compiler_analyzer](compiler_analyzer.md)'s `analyze_component` orchestrates three `create_scopes` runs over the module script, instance script and template, all sharing one `ScopeRoot`:

```mermaid
sequenceDiagram
    autonumber
    participant AN as analyze_component (compiler_analyzer)
    participant SR as ScopeRoot
    participant CS as create_scopes (this module)
    participant SC as Scope / Binding
    participant VS as Analysis visitors

    AN->>SR: new ScopeRoot()
    AN->>CS: create_scopes(module ast)
    CS->>SC: declare / queue references / queue updates
    CS-->>AN: { has_await, scope, scopes }
    AN->>CS: create_scopes(instance ast, parent = module.scope)
    AN->>CS: create_scopes(template ast, parent = instance.scope)
    AN->>SC: synthesize store_sub bindings for $store references
    AN->>AN: infer runes mode (has_await, $-prefixed references, is_rune)
    AN->>VS: walk(ast, { scope, scopes, ... }, visitors with _ : set_scope)
    VS->>SC: scope.get(name) / binding.updated / scope.evaluate(expr) / get_rune(call)
    VS-->>AN: mutated bindings (kind -> state, bindable_prop, ...), node metadata
```

Downstream of this sequence, `analyze_component` uses the resulting bindings for legacy-mode prop conversion (`bindable_prop`, `prop_alias`), store/rune conflict detection, non-reactive-update warnings (see [compiler_diagnostics](compiler_diagnostics.md)) and CSS analysis ([compiler_css_pipeline](compiler_css_pipeline.md)) — details in [compiler_analyzer](compiler_analyzer.md).

### 5.2 Name resolution at analysis time

1. Visitor handler receives `context.state.scope` (kept correct by `set_scope`).
2. `scope.get(name)` walks the `parent` chain to find the owning `Binding`.
3. Visitor inspects/annotates the binding (`updated`, `kind`, `initial`, `references`).
4. For value reasoning, `scope.evaluate(expr)` yields exact values or type tags.

---

## 6. Data Flow

```mermaid
flowchart LR
    A["Parsed AST<br/>(compiler_parser)"] --> B["create_scopes walk"]
    B --> C["Scope tree + Bindings<br/>scopes: Map node to Scope"]
    C --> D["Analysis visitors<br/>(block / template / js)"]
    D --> E["Re-classified bindings<br/>state, derived, bindable_prop, ..."]
    E --> F["client transform<br/>(compiler_client_transform)"]
    E --> G["server transform<br/>(compiler_server_transform)"]
    C -.->|"evaluate()"| H["Partial values / type tags<br/>used for optimisation decisions"]
    H --> D
```

The `scopes` map is stored on the analysis result (`ComponentAnalysis.module/instance/template`) and threaded through every subsequent walk as `state.scopes` — it is the canonical node → scope lookup for the rest of the compile.

---

## 7. Dependencies & Integration

### 7.1 Dependency map

```mermaid
flowchart LR
    subgraph inbound["Consumed by this module"]
        P["compiler_parser — parsed AST"]
        CT["compiler_types — AST / BindingKind / DeclarationKind"]
        CC["compiler_core — builders (b.id), AST utils, is_rune / is_reserved"]
        ZF["zimmerframe + is-reference — walking & reference detection"]
    end

    subgraph module["compiler_analyzer_scope"]
        CS["create_scopes"]
        SCOPE["Scope / Binding / ScopeRoot"]
        EVAL["Evaluation"]
        SET["set_scope"]
        GR["get_rune"]
    end

    subgraph outbound["Outputs consumed by"]
        AN["compiler_analyzer — analyze_component"]
        BV["compiler_analyzer_block_visitors"]
        TV["compiler_analyzer_template_visitors"]
        JV["compiler_analyzer_js_visitors"]
        TR["compiler_client_transform / compiler_server_transform"]
    end

    P --> CS
    CT --> SCOPE
    CC --> CS
    ZF --> CS
    CS --> SCOPE
    SCOPE --> EVAL
    CS --> AN
    SCOPE --> AN
    SET --> AN
    GR --> AN
    SCOPE --> BV
    SCOPE --> TV
    SCOPE --> JV
    SCOPE --> TR
```

### 7.2 External imports of `scope.js`

| Import | Source | Use |
|---|---|---|
| `is_reference` | npm `is-reference` | Distinguish value references from property keys / shorthand members. |
| `walk`, `Context`, `Visitor` | `zimmerframe` | AST traversal framework (see [compiler_analyzer](compiler_analyzer.md)). |
| `create_expression_metadata` | `phases/nodes.js` | Seeds `EachBlock` metadata (`dependencies`, `has_state`, …). |
| `b.id` | `#compiler/builders` | Mint identifier nodes ([compiler_core](compiler_core.md)). |
| `e.declaration_duplicate` | `../errors.js` | Duplicate-declaration errors ([compiler_diagnostics](compiler_diagnostics.md)). |
| `extract_identifiers`, `extract_identifiers_from_destructuring`, `object`, `unwrap_pattern` | `utils/ast.js` | Flatten patterns into identifiers; find the root object of member expressions ([compiler_core](compiler_core.md)). |
| `is_reserved`, `is_rune` | `utils.js` | Name-generation guards and rune detection. |
| `determine_slot` | `utils/slot.js` | Slot attribution for per-slot component scopes. |
| `validate_identifier_name` | `2-analyze/visitors/shared/utils.js` | Rejects `$`-prefixed top-level declarations (raises `dollar_binding_invalid` / `dollar_prefix_invalid`). |

### 7.3 How sibling visitors rely on this module

- **Block visitors** ([compiler_analyzer_block_visitors](compiler_analyzer_block_visitors.md)): e.g. `EachBlock` reads `node.metadata.expression.dependencies` (seeded here), inspects `binding.mutated`/`binding.kind` in the parent scope, and promotes transitive dependencies to `'state'`.
- **Template visitors** ([compiler_analyzer_template_visitors](compiler_analyzer_template_visitors.md)): directives and elements resolve names through `context.state.scope`; `{@const}` and `let:` bindings created here are re-visited as `'template'` bindings.
- **JS visitors** ([compiler_analyzer_js_visitors](compiler_analyzer_js_visitors.md)): export/prop classification mutates binding kinds (`bindable_prop`, `prop_alias`) and consults `get_rune`.
- **Transforms** ([compiler_client_transform](compiler_client_transform.md), [compiler_server_transform](compiler_server_transform.md)): never re-resolve scope; they consume the final `Binding` records (kinds, `updated`, `references`) embedded in the analysis output.

---

## 8. Diagnostics Emitted

| Diagnostic | Trigger | Mechanism |
|---|---|---|
| `declaration_duplicate` | Same non-`var` name declared twice in a scope | `Scope.declare()` |
| `dollar_binding_invalid` / `dollar_prefix_invalid` | `$` / `$foo` declared at (or near) top level | `Scope.declare()` → `validate_identifier_name` (skipped for params/synthetic and inside functions) |
| Global-reference reservations | Unresolved references recorded into `ScopeRoot.conflicts` | `Scope.reference()` at the root scope |

All message formatting and code frames are centralised in [compiler_diagnostics](compiler_diagnostics.md).

---

## 9. Design Notes & Caveats

- **Order-insensitivity by construction:** references/updates are queued during the walk and resolved afterwards, so forward references, function hoisting and `$:` blocks are handled uniformly.
- **`evaluate()` is a second-phase tool:** it assumes the scope tree is complete. Calling it mid-`create_scopes` can yield wrong results — the JSDoc explicitly warns about this.
- **Porous scopes model JS hoisting:** only non-porous boundaries (functions) increment `function_depth`; blocks are transparent for `var` and `import`.
- **Globals are pessimistically reserved:** any unresolvable reference enters `ScopeRoot.conflicts`, so `Scope.generate` will never emit a name that could shadow a global — safe even if the runtime global doesn't exist.
- **Bindings are mutable analysis records:** visitors are expected to refine `kind`/`metadata`; the transforms must treat them as read-only conclusions.
- **Rune vs. binding precedence:** `get_global_keypath` bails out whenever a binding exists for the root identifier, so user variables named like runes (or stores imported as `derived`) are never confused with runes.
- **Migration-era leniency:** the `Identifier` visitor skips references whose parent is a `TS*` node solely to keep the migration codemods ([compiler_migrate](compiler_migrate.md)) working; this check is slated for removal.

---

## 10. Related Modules

| Module | Relationship |
|---|---|
| [compiler_parser](compiler_parser.md) | Produces the AST this module walks. |
| [compiler_analyzer](compiler_analyzer.md) | Parent: orchestrates `create_scopes`, store synthesis, runes inference and visitor walks. |
| [compiler_analyzer_block_visitors](compiler_analyzer_block_visitors.md) / [compiler_analyzer_template_visitors](compiler_analyzer_template_visitors.md) / [compiler_analyzer_js_visitors](compiler_analyzer_js_visitors.md) | Primary consumers of `Scope`/`Binding` during analysis. |
| [compiler_types](compiler_types.md) | `BindingKind`, `DeclarationKind`, template AST node types. |
| [compiler_core](compiler_core.md) | Builders and AST utilities used here. |
| [compiler_diagnostics](compiler_diagnostics.md) | Error/warning catalogue referenced by `declare()` and `validate_identifier_name`. |
| [compiler_css_pipeline](compiler_css_pipeline.md) | Sibling front-end pipeline; handles CSS selector scoping (separate concern). |
| [compiler_client_transform](compiler_client_transform.md) / [compiler_server_transform](compiler_server_transform.md) | Read final binding kinds/references for code generation. |
