# client_dev_mode_locations

> **Module scope:** `packages/svelte/src/internal/client/dev/elements.js` — source-location instrumentation for rendered DOM elements (dev mode only).

## 1. Introduction

`client_dev_mode_locations` is the smallest, but externally most *visible*, member of the [client_dev_mode](client_dev_mode.md) family. Its single exported function, **`add_locations`**, decorates every element produced from a compiled Svelte template with a `__svelte_meta` expando property containing:

- the **source file**, **line**, and **column** of the element's opening tag in the original `.svelte` file, and
- a `parent` pointer into the runtime **dev stack** — the chain of enclosing components and control-flow blocks.

This metadata is the contract consumed by **Svelte DevTools** browser extensions: hovering or selecting a DOM element reveals exactly where in the source it was authored, and the `parent` chain reconstructs the full ownership hierarchy (which component → which `{#if}`/`{#each}`/`{#await}`/`{#key}` block → which element).

The module is **dev-only by construction**:

1. The compiler emits the `$.add_locations(...)` wrapper only when compiling with `dev: true`.
2. The module lives under `src/internal/client/dev/`, so it is tree-shaken out of production bundles entirely (see the `check-treeshakeability` infrastructure in [svelte_build_tooling](svelte_build_tooling.md)).

### Component inventory

| Component | Visibility | Role |
|---|---|---|
| `add_locations(fn, filename, locations)` | exported | Wraps a template-creation function; returns a function that stamps locations onto the produced DOM |
| `assign_location(element, filename, location)` | private | Stamps `__svelte_meta` on one element and recurses into its children |
| `assign_locations(node, filename, locations)` | private | Walks a sibling chain, matching elements to location entries while skipping hydration boundary comments |

## 2. Architecture & Component Relationships

`add_locations` sits at the seam between the **compiler front-end/back-end** (which *knows* source positions) and the **client runtime** (which *materialises* DOM). The compiler bakes knowledge in; the runtime module applies it at DOM-creation time.

```mermaid
flowchart TB
    subgraph Compiler["Compiler Back-End — see compiler_client_transform_templates"]
        TT["transform-template/index.js<br/>transform_template()"]
        BL["build_locations()<br/>(line, column[, children]) tuples"]
        LOC["locator + dev flag<br/>(compiler/state.js)"]
    end

    subgraph Module["client_dev_mode_locations (this module)"]
        AL["add_locations()<br/>(exported wrapper)"]
        AL2["assign_locations()<br/>sibling walker + hydration depth tracking"]
        AL3["assign_location()<br/>__svelte_meta stamp + child recursion"]
        AL --> AL2 --> AL3
    end

    subgraph Runtime["Client runtime dependencies"]
        HYD["dom/hydration.js<br/>hydrating (module state)"]
        CTX["context.js<br/>dev_stack + add_svelte_meta()"]
        CONST["constants.js<br/>HYDRATION_START/_ELSE/END"]
        NODEC["#client/constants<br/>ELEMENT_NODE, COMMENT_NODE,<br/>DOCUMENT_FRAGMENT_NODE"]
        TMPL["dom/template.js<br/>from_html / from_tree / ..."]
    end

    subgraph Consumers
        DT["Svelte DevTools extensions<br/>(read element.__svelte_meta)"]
    end

    LOC --> TT
    TT -->|"wraps template call<br/>if (dev)"| AL
    BL -->|"locations arg"| AL
    AL -->|"calls fn()"| TMPL
    AL2 -->|"hydrating?"| HYD
    AL2 -->|"depth markers"| CONST
    AL -->|"node-type checks"| NODEC
    AL3 -->|"parent: dev_stack"| CTX
    AL3 -.->|"__svelte_meta"| DT
    CTX -.->|"ownership chain"| DT
```

### Compiler-side counterpart

The wrapping decision happens in the compiler's client transform. Every hoisted template (`$.from_html`, `$.from_svg`, `$.from_mathml`, or `$.from_tree` — see [compiler_client_transform_templates](compiler_client_transform_templates.md)) is wrapped **only in dev mode**:

```js
// packages/svelte/src/compiler/phases/3-transform/client/transform-template/index.js
if (dev) {
    call = b.call(
        '$.add_locations',
        call,                                          // the template factory call
        b.member(b.id(state.analysis.name), '$.FILENAME', true),  // component filename
        build_locations(state.template.nodes)          // [[line, col, [children]], ...]
    );
}
```

`build_locations` walks the compiler's static template tree and produces one `[line, column, children?]` entry per element, in document order, resolving positions through the compile-time `locator`. The emitted nested-array shape mirrors the runtime type:

```ts
// packages/svelte/src/internal/client/types.d.ts
type SourceLocation =
    | [line: number, column: number]
    | [line: number, column: number, SourceLocation[]];
```

### Generated code example

For a component `App.svelte` containing `<div><span>hi</span></div>`, dev-mode output is roughly:

```js
// hoisted template — wrapped by add_locations
const root = $.add_locations(
    $.from_html(`<div><span>hi</span></div>`),
    App[$.FILENAME],        // "App.svelte"
    [[1, 8, [[1, 13]]]]     // div @ 1:8, nested span @ 1:13
);

// in the component body
const div = root();          // ← here the wrapper stamps __svelte_meta
```

## 3. Data Flow & Execution Sequence

The stamped metadata flows from compile time to the DevTools inspector in three stages:

```mermaid
sequenceDiagram
    participant C as Compiler (dev mode)
    participant B as Bundle (hoisted scope)
    participant W as add_locations wrapper
    participant F as from_html/from_tree factory
    participant M as assign_location(s)
    participant D as DevTools

    Note over C: transform_template() resolves<br/>locator(start) per element
    C->>B: $.add_locations(factoryFn, FILENAME, locations)

    Note over B: Component initialisation
    B->>W: root() — invoked once per fragment/element
    W->>F: fn(...args) → create/clone DOM
    F-->>W: dom (DocumentFragment | Element)

    alt hydrating === true
        W->>M: start at current hydrate_node position
    else client-side mount
        W->>M: start at dom.firstChild (fragment) or dom
    end

    M->>M: walk siblings, match elements ↔ locations
    M->>M: element.__svelte_meta = { parent: dev_stack, loc: {file,line,column} }
    W-->>B: return dom (stamped, unchanged shape)

    Note over D: later, on element inspection
    D->>D: read __svelte_meta → jump to file:line:column,<br/>walk .parent → ownership hierarchy
```

Key behavioral properties:

- **Wrap once, stamp on every instantiation.** The wrapper is created once per template, but each call to it (e.g., inside `{#each}` branches) re-stamps the fresh clone.
- **DOM shape is untouched.** No attributes or extra nodes are added — metadata lives in a JS expando, invisible to CSS selectors and serialization.
- **`dev_stack` is captured at *creation* time**, so each clone records the component/block context that was active when it was built — correct even for elements created inside nested snippets or components.

## 4. Algorithm Deep Dive

### 4.1 `add_locations` — the wrapper

```mermaid
flowchart TD
    A["add_locations(fn, filename, locations) called"] --> B["Return wrapper function<br/>(closures over filename + locations)"]
    B --> C["wrapper invoked with template args"]
    C --> D["dom = fn(...args)"]
    D --> E{"hydrating?"}
    E -- "yes" --> F["start = dom<br/>(already positioned at hydrate_node)"]
    E -- "no" --> G{"dom is DocumentFragment?"}
    G -- "yes" --> H["start = dom.firstChild"]
    G -- "no" --> I["start = dom"]
    F & H & I --> J["assign_locations(start, filename, locations)"]
    J --> K["return dom"]
```

The `hydrating ? dom : …` branch matters because during hydration the factory functions (e.g. `from_html`, `from_tree`) return the *existing server-rendered node* rather than a clone, already positioned at the current hydration cursor. Starting the walk from `dom` itself preserves alignment with server output.

### 4.2 `assign_locations` — sibling walk with hydration depth tracking

Two independent walks are interleaved, and they must stay in lock-step:

1. **DOM walk:** `node = node.nextSibling` repeatedly.
2. **Location walk:** index `i` advances only when an **element node** is matched with `locations[i++]`.

Non-element nodes (text, comments) consume no location entries — hence the compiler emits locations for elements only, in document order.

The complication is hydration: server-rendered HTML contains `<!--[-->` / `<!--]-->` comment pairs delimiting blocks (`{#if}`, `{#each}`, …, via `HYDRATION_START`, `HYDRATION_START_ELSE`, `HYDRATION_END`). These comments are **not** present in the compiler's location array, so the walker must skip the DOM subtrees they open:

```mermaid
flowchart TD
    A["node && i < locations.length"] --> B{"hydrating && node is Comment?"}
    B -- "opening marker<br/><!--[--> or <!--+else-->" --> C["depth += 1"]
    B -- "closing marker<br/><!--]-->" --> D["depth -= 1"]
    B -- "not a marker" --> E["depth unchanged"]
    C & D & E --> F{"depth === 0 &&<br/>node is Element?"}
    F -- "yes" --> G["assign_location(node, filename, locations[i])<br/>i += 1"]
    F -- "no" --> H["skip — inside hydration block<br/>or non-element node"]
    G & H --> I["node = node.nextSibling"]
    I --> A
```

- Elements encountered while `depth > 0` belong to a *different* template (they are children of a nested block, stamped by that block's own `add_locations` wrapper), so they are skipped here.
- On a pure client-side mount there are no hydration comments, `hydrating` is `false`, and the walk reduces to a plain linear match.

### 4.3 `assign_location` — stamping and recursion

For each matched element:

```js
element.__svelte_meta = {
    parent: dev_stack,                       // live DevStackEntry chain from context.js
    loc: { file: filename, line: location[0], column: location[1] }
};
```

If the location entry carries a third element (`location[2]`, the nested `SourceLocation[]`), the walker recurses into `element.firstChild`, applying the same element-matching walk one level deep in the DOM tree. This recursion handles the parent/child element relationship inside a single template; the sibling loop handles the flat top level.

### 4.4 The `parent` link: `dev_stack`

The stamped `parent` is the module-level `dev_stack` variable maintained in `../context.js`:

- `set_dev_stack(stack)` installs the stack when a component mounts.
- `add_svelte_meta(callback, type, component, line, column)` pushes an entry (`type` ∈ `component | if | each | await | key | render`, per `DevStackEntry` in `internal/client/types.d.ts`) around block/component initialisation and pops it in a `finally`.

The resulting linked list is what lets DevTools render a breadcrumb such as `App.svelte:12 → {#each} (App.svelte:15) → Item.svelte:3` for any inspected element. See [client_dev_mode_debugging](client_dev_mode_debugging.md) and [client_dev_mode_hmr](client_dev_mode_hmr.md) for the sibling dev instrumentation that consumes related context.

## 5. Module Dependency Map

```mermaid
flowchart LR
    subgraph this["client_dev_mode_locations"]
        elements["dev/elements.js"]
    end

    subgraph client_internal["internal/client (see client_runtime_core)"]
        hydration["dom/hydration.js<br/>hydrating"]
        context["context.js<br/>dev_stack / set_dev_stack /<br/>add_svelte_meta"]
        template["dom/template.js<br/>from_html, from_tree, from_svg,<br/>from_mathml (wrapped targets)"]
        clientConsts["constants.js<br/>COMMENT_NODE / ELEMENT_NODE /<br/>DOCUMENT_FRAGMENT_NODE"]
        sharedConsts["../../constants.js<br/>HYDRATION_START / HYDRATION_START_ELSE /<br/>HYDRATION_END"]
    end

    subgraph siblings["client_dev_mode siblings"]
        hmr["client_dev_mode_hmr"]
        debugging["client_dev_mode_debugging"]
        validation["client_dev_mode_validation"]
    end

    subgraph compiler["compiler (see compiler_client_transform_templates)"]
        tt["transform-template/index.js<br/>transform_template + build_locations"]
        fragvis["visitors/Fragment.js<br/>hoisted template emission"]
    end

    subgraph consumers["External consumers"]
        devtools["Svelte DevTools"]
        svelte_meta["element.__svelte_meta readers"]
    end

    elements --> hydration
    elements --> context
    elements --> clientConsts
    elements --> sharedConsts
    elements -.->|"wraps at runtime"| template
    tt -->|"emits $.add_locations(...)"| elements
    fragvis --> tt
    context --> debugging
    elements -.-> devtools
    elements -.-> svelte_meta
```

Dependency rationale:

| Dependency | Why it is needed |
|---|---|
| `dom/hydration.js → hydrating` | Decide walk origin (existing DOM vs. fresh clone) and enable comment-marker skipping |
| `../../constants.js → HYDRATION_*` | Recognise `<!--[-->`/`<!--]-->` markers while walking server-rendered markup |
| `#client/constants → node types` | Cheap node-type discrimination (`ELEMENT_NODE`, `COMMENT_NODE`, `DOCUMENT_FRAGMENT_NODE`) |
| `../context.js → dev_stack` | Link each element into the live ownership/dev stack chain |
| Wrapped `fn` (`from_*` factories) | The actual DOM producers, called through the closure — this module never touches the template machinery itself |

## 6. Position Within the Overall System

- **Compile-time contract:** `transform_template` (compiler back-end) guarantees the *shape* of the `locations` argument and the arity of `add_locations`; the runtime module guarantees the *interpretation*. A change to one without the other silently breaks DevTools metadata.
- **Dev-mode umbrella:** This module is one leaf of `client_dev_mode`, alongside [client_dev_mode_hmr](client_dev_mode_hmr.md) (hot reloading + CSS cleanup), [client_dev_mode_debugging](client_dev_mode_debugging.md) (`$inspect`, tracing, `$console.log` state snapshots), and [client_dev_mode_validation](client_dev_mode_validation.md) (ownership validators, snippet-arg checks, dev equality checks). All share the same lifecycle: emitted only under `dev`, referenced through `internal/client` exports, tree-shaken otherwise.
- **Server mirror:** the SSR side has an analogous dev surface — `internal/server/dev.js` (`push_element` / `pop_element`) — which maintains a server-side element stack used for the same class of diagnostics. Together the two sides cover "where did this markup come from" during both SSR and client rendering.
- **Non-goals:** the module performs no validation, warning, or error reporting (unlike `internal/client/validate.js`), and does not participate in reactivity (unlike [client_runtime_core](client_runtime_core.md)). Its only side effects are expando properties on freshly created elements.

## 7. Design Notes & Edge Cases

- **Fragments vs. single elements.** `dom.nodeType === DOCUMENT_FRAGMENT_NODE` distinguishes multi-node templates (`TEMPLATE_FRAGMENT` flag) from single-root templates; the walk starts at the first child only for fragments.
- **Text/comment skeletons.** Comment nodes that are *not* hydration markers (e.g., preserved `{/* comments */}`) pass through without consuming location entries; they are simply skipped as non-elements.
- **`<!>` anchor comments.** Templates whose content starts with an expression tag get a synthetic `<!>` comment for the effect anchor (see `from_html`'s `has_start`); being a comment, it is transparent to the walker.
- **Void / self-closing elements.** Correct by construction — the location array is generated from the same element list (`state.template.nodes`) that the HTML/string form was generated from, so counts always align.
- **`<pre>` / `<textarea>` whitespace handling** in the compiler's tree form does not affect locations, since locations are keyed to elements, not text offsets.
- **HMR interplay.** When [client_dev_mode_hmr](client_dev_mode_hmr.md) re-mounts a component after an edit, the new component function runs with fresh templates and re-invokes `add_locations`, so stamped metadata always reflects the current source — no stale line numbers after hot updates.

## 8. Quick Reference

```js
// Runtime signature (internal/client/dev/elements.js)
add_locations(
    fn: (...args) => Dom,      // template factory: $.from_html / $.from_tree / ...
    filename: string,          // component's $.FILENAME static
    locations: SourceLocation[]// [line, column, children?] per element, doc order
): (...args) => Dom            // same-arity wrapper that stamps __svelte_meta

// Metadata written onto each element
element.__svelte_meta = {
    parent: DevStackEntry | null,   // context.js dev_stack at creation time
    loc: { file: string, line: number, column: number }
};
```

*Generated documentation — see also: [client_dev_mode](client_dev_mode.md) · [compiler_client_transform_templates](compiler_client_transform_templates.md) · [client_runtime_core](client_runtime_core.md) · [client_dev_mode_hmr](client_dev_mode_hmr.md) · [client_dev_mode_debugging](client_dev_mode_debugging.md)*
