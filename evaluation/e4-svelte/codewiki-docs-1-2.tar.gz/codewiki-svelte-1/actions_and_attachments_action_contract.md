# Actions & Attachments — Action Contract (`actions_and_attachments_action_contract`)

> **Module path:** `packages/svelte/src/action/public.d.ts`
> **Parent module:** [actions_and_attachments](actions_and_attachments.md)
> **Layer:** Public API Surface & Compatibility Layer → `actions_and_attachments`

---

## 1. Overview

This module is the **pure type-level contract for Svelte actions**. A Svelte *action* is a function that the runtime invokes with a DOM node (and an optional parameter) at the moment the element is created — the mechanism behind the `use:` directive.

The module lives in `packages/svelte/src/action/public.d.ts` and is a **declaration-only file (`.d.ts`)**. It exports two interfaces and ships **zero runtime code**:

| Export | Role |
| --- | --- |
| `Action<Element, Parameter, Attributes>` | The **callable contract** implemented by user code. |
| `ActionReturn<Parameter, Attributes>` | The **lifecycle-object contract** an action may return (`update`, `destroy`, plus a type-checking-only attribute marker). |

Because it is type-only, the module is fully tree-shakeable and has no effect on bundle output. The *behaviour* of actions is owned by other modules:

- **Compile time:** `use:` directives are parsed into `UseDirective` AST nodes and lowered by the client transform (see [compiler_client_transform_elements_and_directives](compiler_client_transform_elements_and_directives.md)).
- **Runtime:** the generated `$.action(...)` calls are executed by the client DOM renderer (see [client_dom_renderer_elements_and_events](client_dom_renderer_elements_and_events.md)).
- **Interop:** the sibling attachment runtime adapts this contract to the newer `Attachment` protocol via `fromAction` (see [actions_and_attachments_attachment_runtime](actions_and_attachments_attachment_runtime.md)).

---

## 2. Core Components

### 2.1 `Action` — the callable contract

```ts
export interface Action<
	Element = HTMLElement,
	Parameter = undefined,
	Attributes extends Record<string, any> = Record<never, any>
> {
	<Node extends Element>(
		...args: undefined extends Parameter
			? [node: Node, parameter?: Parameter]
			: [node: Node, parameter: Parameter]
	): void | ActionReturn<Parameter, Attributes>;
}
```

**Semantics**

- An action is called **once, when the element is created** (mounted into the DOM).
- Returning `void` is legal — the action then has no lifecycle hooks and simply performs one-off setup (e.g. a third-party widget constructor).
- Returning an `ActionReturn` object opt-in to the update/destroy lifecycle (§2.2).

**Generic parameters**

| Generic | Default | Meaning |
| --- | --- | --- |
| `Element` | `HTMLElement` | Constrains which elements the action may be applied to (`use:` on a non-matching element becomes a type error). |
| `Parameter` | `undefined` | Type of the `use:action={param}` value. |
| `Attributes` | `Record<never, any>` | Extra attributes / events the action *enables* on the host element — **TypeScript-only**, no runtime effect (§2.3). |

**Design details worth knowing**

- **Inner `<Node extends Element>` signature** — the call signature is itself generic so concrete node types flow through inference at the usage site (e.g. an `Action` used on a `<div>` receives `HTMLDivElement`, an `Element` subtype).
- **Conditional arity trick** — `undefined extends Parameter ? [node, parameter?] : [node, parameter]` makes the second argument *required* only when the parameter type cannot be `undefined`. Consequently `Action<HTMLDivElement>` and `Action<HTMLDivElement, undefined>` both declare a **parameterless** action, while `Action<HTMLElement, string>` demands the argument.
- **`undefined extends X` vs `X extends undefined`** — per the implementation notes in the source, the inverted conditional is deliberate: it behaves correctly under both `strict` and non-strict TypeScript configurations.

```ts
// Parameterless action bound to <div> elements only:
export const myAction: Action<HTMLDivElement, { someProperty: boolean } | undefined> =
	(node, param = { someProperty: true }) => {
		// ...
	};
```

### 2.2 `ActionReturn` — the lifecycle contract

```ts
export interface ActionReturn<
	Parameter = undefined,
	Attributes extends Record<string, any> = Record<never, any>
> {
	update?: (parameter: Parameter) => void;
	destroy?: () => void;
	$$_attributes?: Attributes;
}
```

| Member | Required | Invoked when |
| --- | --- | --- |
| `update` | optional | The `use:action={param}` parameter changes — **after** Svelte has applied updates to the markup, so the DOM is already current. |
| `destroy` | optional | The element has been **unmounted**. Cleanup/teardown (event listeners, observers, timers, third-party widget destruction). |
| `$$_attributes` | never (phantom) | **Never.** Exists solely so the compiler/type-checker can surface `Attributes` at the usage site. Marked `### DO NOT USE THIS` in source. |

Key semantics encoded in the doc comments:

- `ActionReturn` and `ActionReturn<undefined>` both mean the action **accepts no parameters** (and therefore never receives `update` calls with meaningful data).
- The lifecycle mirrors the runtime exactly: the runtime helper tears down the action's effect on unmount, which is what triggers `destroy` (see the sequence diagram in §4).

### 2.3 Typing attributes & events (`Attributes`)

The `Attributes` generic lets an action declare that it *adds* props or event listeners to the host element. This is pure typing metadata — carried through the phantom `$$_attributes` member so `svelte-check`/`tsc` can merge it into the element's type where `use:myAction` appears:

```ts
interface Attributes {
	newprop?: string;
	'on:event': (e: CustomEvent<boolean>) => void;
}

export function myAction(
	node: HTMLElement,
	parameter: Parameter
): ActionReturn<Parameter, Attributes> {
	// ...
	return {
		update: (updatedParameter) => { /* ... */ },
		destroy: () => { /* ... */ }
	};
}
```

---

## 3. Architecture & Component Relationships

The contract sits at the intersection of four consumers: userland actions, the public type re-export surface, the compiler front-end/back-end, and the attachment bridge.

```mermaid
flowchart TB
    subgraph userland["User code (Svelte components)"]
        UA["myAction: Action&lt;Element, Param, Attr&gt;"]
        TPL["&lt;div use:myAction={param} /&gt;"]
    end

    subgraph thisModule["actions_and_attachments_action_contract (this module, type-only)"]
        A["Action interface"]
        AR["ActionReturn interface"]
    end

    subgraph parent["actions_and_attachments (parent)"]
        ART["actions_and_attachments_attachment_runtime<br/>fromAction / createAttachmentKey"]
    end

    subgraph publicAPI["Public API surface"]
        RT["packages/svelte/types/index.d.ts<br/>(re-exports Action)"]
    end

    subgraph compiler["Compiler"]
        AST["UseDirective AST node<br/>(compiler_types_template_ast)"]
        VIS["client transform UseDirective visitor<br/>emits $.action(...)"]
    end

    subgraph runtime["Client DOM renderer"]
        ACT["$.action runtime helper<br/>(action / update / destroy lifecycle)"]
    end

    UA -- "implements" --> A
    A -- "returns (optionally)" --> AR
    RT -. "type re-export" .-> A
    ART -- "fromAction(action) consumes the contract" --> A
    TPL -- "parsed into" --> AST
    AST -- "lowered by" --> VIS
    VIS -- "generates" --> ACT
    ACT -- "invokes per lifecycle" --> UA
```

Reading the diagram:

1. **This module is a leaf**: nothing imports *from* it at runtime; it is consumed only by the type system and re-exported by the public surface (see [public_api_type_contracts](public_api_type_contracts.md) and [svelte-types](svelte-types.md)).
2. **The sibling runtime module builds on it**: `fromAction` destructures exactly `{ update, destroy }` from an action's return value, i.e. it depends on the `ActionReturn` shape documented here (see [actions_and_attachments_attachment_runtime](actions_and_attachments_attachment_runtime.md)).
3. **The compiler contract is the `UseDirective` AST node** — parsed by the template state machine ([compiler_parser_template_state_machine](compiler_parser_template_state_machine.md)), analyzed by the template visitors ([compiler_analyzer_template_visitors](compiler_analyzer_template_visitors.md)), and lowered as shown above.

---

## 4. Lifecycle & Data Flow

### 4.1 Compile → runtime data flow

The client-transform `UseDirective` visitor emits (simplified):

```js
// use:myAction={param}  →
$.action(node, () => myAction?.($$node, $$action_arg), () => param);
```

The node reference plus two thunks (the action call and a reactive getter for the parameter) are all the runtime needs to honour the contract's documented timing guarantees.

### 4.2 Runtime sequence

```mermaid
sequenceDiagram
    autonumber
    participant C as Compiler (client transform)
    participant R as Client runtime ($.action)
    participant U as User action (Action impl)
    participant D as DOM element

    C->>R: $.action(node, actionThunk, paramThunk)
    Note over D: element created / mounted
    R->>U: action(node, parameter)
    U-->>R: ActionReturn { update?, destroy? } | undefined
    Note over U: one-off setup already done

    loop every parameter change (if update defined)
        Note over D: Svelte applies markup updates first
        R->>U: update(newParameter)
    end

    Note over D: element unmounted
    R->>U: destroy()
    R->>R: teardown of action effect
```

### 4.3 Action state machine

```mermaid
stateDiagram-v2
    [*] --> Invoked : element mounted → action(node, param)
    Invoked --> Tracking : returned ActionReturn (reactive param tracked)
    Invoked --> Done : returned void (no lifecycle)
    Tracking --> Tracking : param change → update(newParam)
    Tracking --> Destroyed : element unmounts → destroy()
    Done --> [*]
    Destroyed --> [*]
```

### 4.4 Bridge into the attachment world

The sibling runtime module's `fromAction` re-creates this exact lifecycle inside the attachment protocol — this is the strongest **runtime** consumer of the contract:

```js
function fromAction(action, fn = noop) {
	return (element) => {
		const { update, destroy } = untrack(() => action(element, fn()) ?? {});
		if (update) { /* render_effect: skip first run, then update(arg) per change */ }
		if (destroy) { teardown(destroy); }
	};
}
```

```mermaid
flowchart LR
    A["Action (this contract)"] -- "fromAction()" --> AT["Attachment&lt;T&gt;<br/>(element) =&gt; void | cleanup"]
    AT -- "applied via" --> AK["createAttachmentKey() spread-prop key<br/>{@attach ...} / spread props"]
```

This is why keeping `ActionReturn`'s shape stable is a compatibility requirement: changing it would silently break `fromAction` destructuring. Details of the attachment side belong to [actions_and_attachments_attachment_runtime](actions_and_attachments_attachment_runtime.md).

---

## 5. How This Module Fits the Overall System

| Concern | Owner | Relationship to this module |
| --- | --- | --- |
| Typing `use:` in userland | **this module** | Defines `Action` / `ActionReturn`. |
| Public re-export (`svelte/action`, `svelte` types) | [public_api_type_contracts](public_api_type_contracts.md), [svelte-types](svelte-types.md) | Re-exports `Action`; no duplication of the contract. |
| Parsing `use:foo={bar}` | [compiler_parser_template_state_machine](compiler_parser_template_state_machine.md) | Produces the `UseDirective` node ([compiler_types_template_ast](compiler_types_template_ast.md)). |
| Analyzing directives | [compiler_analyzer_template_visitors](compiler_analyzer_template_visitors.md) | Validates directive usage before transform. |
| Lowering `use:` to runtime calls | [compiler_client_transform_elements_and_directives](compiler_client_transform_elements_and_directives.md) | Emits `$.action(...)` honouring attribute-update ordering ("actions need to run after attribute updates in order with bindings/events"). |
| Executing the lifecycle | [client_dom_renderer_elements_and_events](client_dom_renderer_elements_and_events.md) / [client_dom_renderer_lifecycle_api](client_dom_renderer_lifecycle_api.md) | Implements the update/destroy timing the contract documents. |
| Modern replacement / interop | [actions_and_attachments_attachment_runtime](actions_and_attachments_attachment_runtime.md) | `fromAction` adapts `Action` → `Attachment`; `createAttachmentKey` enables attachments on spread props. |

**Why the contract lives alone in a `.d.ts`:** the `svelte/action` entry point must remain tree-shakeable and dependency-free; users import the types (`import type { Action } from 'svelte/action'`) with no runtime cost, while the actual `use:` machinery is entirely compiler/runtime-owned.

---

## 6. Maintenance Notes & Gotchas

1. **Do not set or read `$$_attributes`.** It is a phantom property that exists purely so the type-checker can extract `Attributes`; the docs in source mark it `### DO NOT USE THIS`. The supported way to declare enabled attributes/events is the `Attributes` generic.
2. **Preserve the `undefined extends Parameter` form** if editing — swapping to `Parameter extends undefined` regresses inference under non-strict `tsconfig`s (explicit implementation note in source).
3. **Defaults are part of the public API**: `Element = HTMLElement`, `Parameter = undefined`, `Attributes = Record<never, any>`. Changing them is a breaking change.
4. **`update` runs after DOM updates** — this ordering guarantee is relied upon by both the runtime helper and `fromAction`'s skip-first-run `render_effect`; any change must keep both in sync.
5. **`ActionReturn<undefined>` ≡ parameterless.** Documentation, error messages, and tooling elsewhere treat `Parameter = undefined` as "no parameter accepted" — keep this equivalence intact.

---

## 7. References

- [actions_and_attachments](actions_and_attachments.md) — parent module grouping actions & attachments.
- [actions_and_attachments_attachment_runtime](actions_and_attachments_attachment_runtime.md) — `fromAction`, `createAttachmentKey`, the `Attachment` runtime protocol.
- [public_api_type_contracts](public_api_type_contracts.md) & [svelte-types](svelte-types.md) — where `Action` is re-exported to consumers.
- [compiler_types_template_ast](compiler_types_template_ast.md) — the `UseDirective` template AST node type.
- [compiler_client_transform_elements_and_directives](compiler_client_transform_elements_and_directives.md) — lowering of `use:` directives to `$.action(...)`.
- [client_dom_renderer_elements_and_events](client_dom_renderer_elements_and_events.md) — runtime execution of element effects (actions, events, attributes).
