# Compiler Client Transform — Control Flow Blocks

> Module: `compiler_client_transform_control_flow_blocks`
> Location: `packages/svelte/src/compiler/phases/3-transform/client/visitors/`
> Part of: [compiler_client_transform](compiler_client_transform.md) → Compiler Back-End (Client & Server Code Generation)

---

## 1. Overview

This module is a **logical grouping of client-transform visitors** that translate Svelte's *control flow* and *content injection* template constructs into imperative JavaScript for the browser. It does not live in a single folder of its own; rather, it covers the visitor files that handle block-shaped AST nodes during Phase 3 of the compiler:

| Construct | Syntax | Visitor file | Emitted runtime call |
|---|---|---|---|
| Conditional | `{#if}…{:else if}…{:else}…{/if}` | `IfBlock.js` | `$.if(node, fn, elseif?)` |
| Iteration | `{#each expr as item, i (key)}…{:else}…{/each}` | `EachBlock.js` | `$.each(node, flags, get_collection, get_key, render_fn, fallback_fn?)` |
| Async resolution | `{#await p}…{:then v}…{:catch e}…{/await}` | `AwaitBlock.js` | `$.await(node, get_input, pending, then, catch)` |
| Memoization / remount | `{#key expr}…{/key}` | `KeyBlock.js` | `$.key(node, get_key, render_fn)` |
| Error boundary | `<svelte:boundary>` | `SvelteBoundary.js` | `$.boundary(node, props, children)` |
| Raw HTML | `{@html expr}` | `HtmlTag.js` | `$.html(node, get_html, svg?, mathml?, ignored?)` |
| Snippet render | `{@render name(args)}` | `RenderTag.js` | `name(node, …)` or `$.snippet(node, get_fn, …)` |
| Snippet definition | `{#snippet name(params)}…{/snippet}` | `SnippetBlock.js` | `const name = ($$anchor, …) => {…}` |
| Slot outlet | `<slot {a}>fallback</slot>` | `SlotElement.js` | `$.slot(node, $$props, name, props, fallback)` |
| Slot fill | `<svelte:fragment slot="…">` | `SvelteFragment.js` | inlined statements |
| Scoped const | `{@const x = expr}` | `ConstTag.js` | `const x = $.derived(…)` (in `consts` buffer) |
| Debug | `{@debug a, b}` | `DebugTag.js` | `$.template_effect(() => { console.log(…); debugger; })` |

All visitors share the same three-step contract:

1. **Reserve an anchor** in the static HTML template (`context.state.template.push_comment()`) so the runtime knows where to mount dynamic content.
2. **Visit child fragments** to build render thunks (`($$anchor) => {…}` blocks), registering *read/assign/mutate* transforms for block-scoped bindings in `context.state.transform`.
3. **Emit statements** into the appropriate output buffer (`state.init`, `state.consts`, snippet hoist lists), typically wrapped by `add_svelte_meta` in dev mode and by `$.async(…)` when the block expression contains top-level `await`.

The runtime half of every emitted call is implemented by the [client_dom_renderer](client_dom_renderer.md) module (`src/internal/client/dom/blocks/*`), which owns effect creation, branch pausing/resuming, hydration anchoring and reconciliation.

---

## 2. Position in the Compiler Pipeline

The visitors run in **Phase 3 (client transform)**, immediately after analysis. They consume the *annotated* AST produced by [compiler_analyzer](compiler_analyzer.md) — metadata such as `has_await`, `keyed`, `is_controlled`, `contains_group_binding`, `transitive_deps`, `can_hoist` and `dynamic` is assumed to be present and trusted.

```mermaid
graph TB
    subgraph FE["Compiler Front-End (Parsing, Analysis &amp; CSS Scoping)"]
        P["1-parse<br/>(compiler_parser)"] --> A["2-analyze<br/>(compiler_analyzer)<br/>+ compiler_css_pipeline"]
    end

    subgraph BE["Compiler Back-End (Client &amp; Server Code Generation)"]
        T["3-transform/index.js<br/>phase orchestrator"] --> CT["transform-client.js<br/>(visitor dispatch via zimmerframe)"]
        T --> ST["transform-server.js<br/>(compiler_server_transform)"]
    end

    subgraph THIS["compiler_client_transform_control_flow_blocks (this module)"]
        V["IfBlock / EachBlock / AwaitBlock / KeyBlock<br/>SvelteBoundary / HtmlTag / RenderTag / SnippetBlock<br/>SlotElement / SvelteFragment / ConstTag / DebugTag"]
    end

    subgraph RT["Reactive Runtime Engine + Rendering Backends"]
        RB["internal/client/dom/blocks/*<br/>if_block, each, await_block, key,<br/>boundary, html, slot, snippet"]
        RR["internal/client/runtime.js<br/>$.derived, $.get, $.async, effects"]
    end

    A -->|"annotated AST + Scope"| CT
    CT -->|"node type dispatch"| V
    V -->|"ESTree statements calling<br/>$.if, $.each, $.await …"| RB
    V -->|"$.derived / $.get reads"| RR
```

Key upstream/downstream relationships:

- **Upstream (compile-time):** node shapes come from `types/template.d.ts` ([compiler_types](compiler_types.md)); expression metadata from [compiler_analyzer](compiler_analyzer.md); helper AST factories (`b.*`) and the `Scope` type from [compiler_core](compiler_core.md).
- **Downstream (runtime):** the emitted identifiers (`$.if`, `$.each`, …) resolve to internal client exports from the [Reactive Runtime Engine](reactive_runtime_engine.md) and [client_dom_renderer](client_dom_renderer.md) at bundle time.
- **Sibling transforms:** element/directive rendering (anchors, attributes) is handled by [compiler_client_transform_elements_and_directives](compiler_client_transform_elements_and_directives.md); the template/`Fragment` machinery that materialises `template_node` anchors belongs to [compiler_client_transform_templates](compiler_client_transform_templates.md); identifier/assignment rewriting to [compiler_client_transform_state_and_reactivity](compiler_client_transform_state_and_reactivity.md). The SSR counterpart of these visitors lives in [compiler_server_transform](compiler_server_transform.md).

---

## 3. Module Architecture

```mermaid
graph TB
    subgraph DISPATCH["transform-client.js visitor table"]
        Z["zimmerframe walk()
           set_scope hook"]
    end

    subgraph BLOCKS["Control-flow block visitors"]
        IF["IfBlock"]
        EACH["EachBlock"]
        AWAIT["AwaitBlock"]
        KEY["KeyBlock"]
        BOUNDARY["SvelteBoundary"]
    end

    subgraph CONTENT["Content-injection visitors"]
        HTML["HtmlTag"]
        RENDER["RenderTag"]
        SNIPPET["SnippetBlock"]
        SLOT["SlotElement"]
        FRAG["SvelteFragment"]
    end

    subgraph SCOPE["Scoped-value visitors"]
        CONST["ConstTag"]
        DEBUG["DebugTag"]
    end

    subgraph SHARED["Shared utilities (visitors/shared/, ../utils.js)"]
        BE["build_expression"]
        MEM["Memoizer"]
        META["add_svelte_meta"]
        GV["get_value"]
        CD["create_derived"]
        BAV["build_attribute_value"]
    end

    subgraph STATE["ComponentClientTransformState (client/types.d.ts)"]
        BUF["init / consts / update / after_update"]
        HOIST["instance_level_snippets
              module_level_snippets"]
        XFORM["transform[name]:
              read / assign / mutate / update"]
        TMPL["template.push_comment()"]
        NODE["node (anchor id)"]
    end

    DISPATCH --> BLOCKS
    DISPATCH --> CONTENT
    DISPATCH --> SCOPE

    BLOCKS --> SHARED
    CONTENT --> SHARED
    SCOPE --> SHARED

    SHARED --> XFORM
    BLOCKS --> BUF
    BLOCKS --> TMPL
    CONTENT --> TMPL
    SNIPPET --> HOIST
    CONST --> BUF
```

### 3.1 Dispatch model

`transform-client.js` builds a flat `visitors` map (one entry per AST node type) and hands it to `zimmerframe`'s `walk()`. Every AST node entering a control-flow visitor already has:

- a matching `Scope` installed by the `set_scope` `_` hook (bindings declared inside `{#if}`, `{#each}` etc. get fresh scopes from [compiler_analyzer_scope](compiler_analyzer_scope.md)),
- the current `ComponentContext` = `{ visit, state, path }`, where `state` is a `ComponentClientTransformState`.

Visitors recurse with `context.visit(node, childState)` and may **copy + extend `state.transform`** to introduce block-local bindings (e.g. the each `item`, awaited `$$condition`).

### 3.2 Output buffers

| Buffer | Written by | Consumed as |
|---|---|---|
| `state.template` (via `push_comment`) | all block visitors that render DOM | anchor comments (`<!>`) inside the static `template.innerHTML` string |
| `state.init` | `IfBlock`, `EachBlock`, `AwaitBlock`, `KeyBlock`, `HtmlTag`, `RenderTag`, `SlotElement`, `SvelteFragment`, `SnippetBlock` (non-top-level), `SvelteBoundary`, `DebugTag` | statements executed once in the component instance, before the render effect |
| `state.consts` | `ConstTag` (and `SvelteBoundary` in non-async mode) | `{@const}` declarations, prepended to the enclosing block body |
| `state.instance_level_snippets` / `module_level_snippets` | `SnippetBlock` | hoisted snippet declarations, referenced from `<script>` |

---

## 4. Shared Infrastructure

These helpers (from `visitors/shared/utils.js`, `visitors/shared/declarations.js`, `visitors/shared/element.js` and `../utils.js`) encode the module's cross-cutting concerns.

### 4.1 `build_expression(context, expression, metadata, state?)`

Visits an expression and applies **legacy-mode coarse reactivity compensation**:

- In runes mode (or "maybe-runes" components) the visited expression is returned untouched.
- In legacy mode, if the expression `has_call`, `has_member_expression` or `has_assignment`, Svelte 4 semantics require dependencies to be *eagerly read* so they register. The helper builds a `SequenceExpression` of getters for every reference (wrapping prop/import/template bindings in `$.deep_read_state(…)`), and finally evaluates the original value inside `$.untrack(() => value)`.

Control-flow visitors call this for every block *test/expression* (`{#if}`, `{#each}`, `{#key}`, `{@html}`, `{@render}` arguments, `{@const}` init) so that the reactive dependency set is identical to Svelte 4 when not in runes mode.

### 4.2 `Memoizer`

Deduplicates and hoists expressions used in more than one render pass:

- `add(expression, has_await)` returns a placeholder `Identifier` (`$0`, `$1`, … after `apply()`).
- Sync entries become `let $n = $.derived(…)` / `$.derived_safe_equal(…)` declarations (`deriveds(runes)`).
- Async entries become the value list + parameter list of an `$.async` wrapper (`async_values()` / `async_ids()`).

`RenderTag` and `SlotElement` use it so that call-containing or awaited arguments are evaluated **once** per update and read through `$.get($n)`.

### 4.3 `add_svelte_meta(expression, node, type, additional?)`

Dev-mode-only wrapper: replaces a plain statement `stmt` with

```js
$.add_svelte_meta(() => stmt, 'if'|'each'|'await'|'key'|'render', component_name, line, column, additional);
```

giving DevTools component-stack attribution for every block mount. In production (`!dev`) it returns the statement unchanged.

### 4.4 `get_value` and `create_derived`

- `get_value(node)` → `$.get(node)` — the universal read transform registered into `state.transform` for anything that lives in a signal (each items, destructured context parts, `{:then}`/`{:catch}` values, `{@const}`).
- `create_derived(state, expression, async = false)` → `$.derived(thunk)` in runes mode, `$.derived_safe_equal(thunk)` in legacy mode, or — for awaited expressions — `await $.save($.async_derived(thunk))`.

---

## 5. Visitor Reference

### 5.1 `IfBlock` — conditionals

**Input**

```svelte
{#if user.premium}
  <Badge />
{:else if trial}
  <Trial />
{:else}
  <Upsell />
{/if}
```

**Transform sketch (output)**

```js
// init
const consequent_1 = ($$anchor) => { /* <Badge /> build */ };
const alternate_1  = ($$anchor) => { /* {#if trial} chain  */ };

$.if(node, ($$render) => {
  if ($.get(user).premium) $$render(consequent_1);
  else                     $$render(alternate_1, false);
});
```

Behaviour:

- Always anchors a template comment; the runtime `if_block` reads hydration instructions from that anchor and creates/pauses the two branch effects.
- `{:else if}` chains are **flattened at the AST level** (`node.elseif === true`): instead of nesting, the alternative *is* the next if-block. The third argument `true` to `$.if` marks the effect `EFFECT_TRANSPARENT` so that transitions mounted inside the branch replay whenever the *outer* condition changes too — a deliberate semantic difference from a nested `{#if}` inside `{:else}`.
- When `node.metadata.expression.has_await` (top-level `await user.premium`), the whole dispatch moves into `$.async`: the test is pre-evaluated into `$$condition` and read back with `$.get($$condition)` inside the render callback.

```mermaid
flowchart TD
    S["visit IfBlock"] --> C["template.push_comment()"]
    C --> V1["visit consequent -> consequent thunk"]
    V1 --> V2{"node.alternate ?"}
    V2 -->|yes| V3["visit alternate -> alternate thunk
        (elseif chains flatten here)"]
    V2 -->|no| T
    V3 --> T["test = build_expression(...)"]
    T --> Q{"metadata.expression.has_await ?"}
    Q -->|yes| AS["emit $.async(node, [test], (node, $$condition) =>
        if ($.get($$condition)) ... )"]
    Q -->|no| D["emit $.if(node, ($$render) =>
        if (test) $$render(consequent)
        else $$render(alternate, elseif=false))"]
    AS --> M
    D --> M["wrap with add_svelte_meta (dev)"]
    M --> O["push into state.init"]
```

### 5.2 `EachBlock` — iteration (the most complex visitor)

**Input**

```svelte
{#each items as item, i (item.id)}
  <Row bind:value={item.value} index={i} />
{:else}
  <Empty />
{/each}
```

**Key responsibilities**

1. **Parent-scope evaluation.** The collection expression is visited with `state.scope.parent`, because `{#each}` creates a scope that must not shadow the collection's own bindings.
2. **Flag computation** (bit-mask over `constants.js`):

```mermaid
flowchart TD
    F["flags = 0"] --> A1{"keyed &amp;&amp; node.index ?"}
    A1 -->|yes| F1["|= EACH_INDEX_REACTIVE"]
    F1 --> A2
    A1 -->|no| A2{"external deps &amp;&amp;
        (!runes || !key_is_item || uses_store) ?"}
    A2 -->|yes| F2["|= EACH_ITEM_REACTIVE"]
    F2 --> A3
    A2 -->|no| A3{"runes &amp;&amp; !uses_store ?"}
    A3 -->|yes| F3["|= EACH_ITEM_IMMUTABLE"]
    F3 --> A4
    A3 -->|no| A4{"sole child element has animate: ?"}
    A4 -->|yes| F4["|= EACH_IS_ANIMATED"]
    F4 --> A5
    A4 -->|no| A5{"is_controlled ?"}
    A5 -->|yes| F5["|= EACH_IS_CONTROLLED"]
    A5 -->|no| DONE["flags ready for $.each"]
```

3. **Store interop.** If the collection derives from a store subscription, `store_to_invalidate` is captured and `$.invalidate_store($$stores, name)` is appended to every item mutation sequence. In legacy mode, `metadata.transitive_deps` of the block *and of all ancestor each blocks* (`collect_parent_each_blocks`) are wrapped in `$.invalidate_inner_signals(() => deps…)` to replicate Svelte 4's broad invalidation.
4. **Item/index binding transforms.** For an identifier context `item`, a `transform[item.name]` entry is installed:
   - `read`: if the binding was reassigned, read back through `collection[$$index]` (legacy only); otherwise `$.get(item)` when `EACH_ITEM_REACTIVE`, else identity.
   - `assign(value)`: `collection[$$index] = value` followed by the invalidation sequence (marks `uses_index = true`).
   - `mutate(mutation)`: `mutation` + invalidation sequence.
   Destructured contexts (`{#each items as { a, b }}`) produce `$.derived` declarations for inserted defaults and `let` bindings (via `extract_paths`) — `$.derived_safe_equal` when a default value must only evaluate once. Index bindings get their own transform entries in both `child_state` and the separate `key_state` (so key functions see the raw index).
5. **Index uniquing for `bind:group`.** If the block contains group bindings, the index is replaced by a generated id (`$$array`/index pair) and re-aliased with `let i = $$index` so the template keeps using the user's name.
6. **Key function.** Defaults to `$.index`; for keyed blocks an arrow `(item[, index]) => keyExpression` is built using `key_state` transforms.
7. **Render function.** `($$anchor, item[, $$index][, $$array]) => { declarations.concat(body) }` — arguments grow only when actually used.
8. **Fallback & validation.** The `{:else}` fragment becomes a fifth argument; in dev, keyed blocks are pre-checked with `$.validate_each_keys(thunk, key_function)` (runtime implementation in `internal/client/validate.js`, see [client_runtime_core](client_runtime_core.md)).
9. **Emission.** `$.each(node, flags, get_collection, key_function, render_fn[, fallback_fn])` wrapped in `add_svelte_meta`, and into `$.async(node, [get_collection], (node, $$collection) => …)` when the collection expression is awaited (the thunk then reads `$.get($$collection)`).

### 5.3 `AwaitBlock` — async resolution

Emits `$.await(node, get_input, pending_fn | null, then_fn | null, catch_fn | null)`. The input thunk is built with `build_expression` and pre-wrapped as a thunk flagged with `has_await` so nested awaits compose.

The helper `create_derived_block_argument` wires `{:then v}` / `{:catch e}` values:

```mermaid
flowchart TD
    N["value pattern ({:then v} / {:catch e})"] --> I{"Identifier ?"}
    I -->|yes| R["transform[v.name] = { read: get_value }
        id = v (no declarations)"]
    I -->|no| P["id = $$source, value = $$value
        $$value = create_derived(($$source) => {
            const [pattern] = $.get($$source);
            return { a, b, ... };
        })
        per identifier: id_i = create_derived(() => $.get($$value).i)
        declarations prepended to branch body"]
```

The runtime (`await_block`) creates `input_source` / `error_source` signals, branches the pending/then/catch effects, and rethrows when the promise rejects with no `{:catch}` branch.

### 5.4 `KeyBlock` — keyed remount

Trivial wrapper: `$.key(node, () => keyExpr, ($$anchor) => body)`. The runtime compares the key with (`not_equal` in runes mode, `safe_not_equal` in legacy) and tears down/recreates the branch effect when it changes. Supports the `$.async` path via `$$key`.

### 5.5 `SvelteBoundary` — error/async boundary

Emits `$.boundary(node, props, ($$anchor) => block)` (runtime: `new Boundary(...)` from `dom/blocks/boundary.js`). Notable compile-time work:

- **Props object**: plain attributes become `init` properties; attributes whose expression `has_state` become getters (`get name() { return expr }`) so the boundary sees live values.
- **`{@const}` handling**: const tags must live *inside* the boundary but may also be referenced from *hoisted* snippets. In non-async mode the compiler "cheats" by visiting the consts into a `const_tags` buffer, unshifting them into the boundary body **and duplicating them into every hoisted snippet body** (explicitly documented in source as a compatibility concession). In experimental-async mode the const tags stay as fragment children so they execute inside the boundary's async context.
- **Snippet routing**: `pending` and `failed` snippets become boundary `props`; other snippets are hoisted to instance statements — except in async mode when the fragment contains consts (they may reference them, so they stay in the fragment).

### 5.6 `HtmlTag` — raw HTML injection

Emits `$.html(node, () => html, is_svg, is_mathml, hydration_ignored)` where the SVG/MathML flags come from `state.metadata.namespace` and the last flag from `is_ignored(node, 'hydration_html_changed')`. The statement is pushed to `init` (not `update`) deliberately, so that any subsequent binding effects can override hydration output. Awaited HTML is materialised via `$$html` inside `$.async`.

### 5.7 `RenderTag` — snippet invocation

Two shapes:

- **Static** (`{@render snip(x)}`): direct call `snip(node, () => x, …)`; optional-call chains become `snip?.(node, …)`.
- **Dynamic** (`node.metadata.dynamic`, e.g. `{@render (which)()}`): `$.snippet(node, () => snippetFn, …)`; `ChainExpression` callees fall back to `$.noop` so a nullish snippet renders nothing.

All arguments pass through the `Memoizer`: any argument that `has_await` or `has_call` is evaluated once into `$n` and read with `$.get($n)`. If any async values exist, the statement list is wrapped in `$.async(node, [values], (node, $ids…) => …)`.

### 5.8 `SnippetBlock` — snippet definitions

Compiles `{#snippet name(a, { b }, …)}` to a `const name = ($$anchor, a = $.noop, $$arg1) => {…}`:

- Identifier parameters get a default of `$.noop` (they are *thunk getters*, so a missing argument renders nothing) and `read: b.call` transform (i.e. calling the parameter invokes the thunk).
- Destructured parameters are aliased to `$$argN`; `extract_paths` produces `$.derived` / `$.derived_safe_equal` declarations identical to the each-block destructuring path, and in dev an eager read surfaces TDZ errors.
- **Dev instrumentation**: compiled as a `function` expression wrapped in `$.wrap_snippet(component_name, fn)` so `$.validate_snippet_args(...arguments)` can reject wrong-arity callers (see `client_dev_mode`).
- **Hoisting**: top-level snippets (direct child of `Root` fragment) go to `module_level_snippets` when `metadata.can_hoist`, otherwise `instance_level_snippets`; nested snippets are pushed to `init`.
- The body's `has_await` is propagated so async snippets become async functions.

### 5.9 `SlotElement` — slot outlets

`<slot {a}>fallback</slot>` → `$.slot(node, $$props, 'name'|nameExpr, propsObject, fallbackOrNull)`:

- `let:` directives are emitted to `init` **first** (they may feed attributes).
- Attribute values with state/calls/awaits become getters via `build_attribute_value` + `Memoizer`.
- Spreads compose as `$.spread_props(propsObject, …thunks)`.
- The fallback fragment is compiled as a thunk; `null` when empty. The runtime resolves `$$props.$$slots[name]`, supporting both classic slot functions and snippet interop (`true` → the `children`/`name` prop).

### 5.10 `SvelteFragment` — slot fills

Minimal: emits `let:` directives to `init`, then **inlines the fragment body's statements** into `init` (the parent component's `$.slot` call ultimately mounts them through `$$slots`).

### 5.11 `ConstTag` — scoped constants

`{@const x = expr}` compiles to `$.derived`/`$.derived_safe_equal` (through `create_derived`, awaited variants included) pushed into `state.consts`, with `transform[x] = { read: get_value }`:

- **Identifier declaration**: `const x = create_derived(init)`; dev mode wraps in `$.tag(derived, 'x')` and adds an eager `$.get(x)` statement to surface "accessed before initialization" errors immediately.
- **Destructuring declaration**: a generated `computed_const` derived block evaluates the pattern once and returns an object of extracted identifiers; each identifier's `read` becomes `$.get(computed_const).id`. Child state removes these names from `transform` during init evaluation so the identifiers behave as plain variables inside the initializer (with `in_derived: true`).

### 5.12 `DebugTag` — debug checkpoints

`{@debug a, b}` →

```js
$.template_effect(() => {
  console.log({ a: $.untrack(() => $.snapshot(a)), b: … }); // runes mode: without $.untrack
  debugger;
});
```

`$.snapshot` deep-clones reactive proxies so the log shows point-in-time values; `$.untrack` only in legacy mode.

---

## 6. End-to-End Data Flow

```mermaid
sequenceDiagram
    autonumber
    participant Z as zimmerframe walk()
    participant V as Control-flow visitor
    participant ST as state (buffers, transform)
    participant TPL as template (anchors)
    participant GEN as code generation

    Z->>V: visit Block node + ComponentContext
    V->>TPL: push_comment() — reserve anchor
    V->>V: build_expression(test/expr, metadata)
    V->>ST: clone state, install transform entries
    V->>Z: visit(child fragments) [recursive]
    Z-->>V: BlockStatement bodies (template + effect statements)
    V->>V: assemble runtime call ($.if / $.each / …)
    alt dev mode
        V->>ST: wrap in $.add_svelte_meta(...)
    end
    alt has_await
        V->>ST: wrap in $.async(node, [thunks], cb)
    end
    V->>ST: push statements (init / consts / snippets)
    ST->>GEN: buffers merged into component instance body
    GEN-->>GEN: template string + instance fn -> client JS
```

### 6.1 The `$.async` restructuring pattern

Every visitor that can host a top-level `await` follows one canonical shape — a consistent, repeatable code shape:

```mermaid
flowchart TD
    A["expression metadata.has_await ?"] -->|no| B["emit call directly into state.init"]
    A -->|yes| C["emit $.async(node, [thunk(expr)], (node, $$x) => body)"]
    C --> D["inside body, read value with $.get($$x)"]
    B --> E["add_svelte_meta wrapper (dev)"]
    D --> E
```

At runtime `$.async` (via `async_body` in `internal/client/reactivity/async.js`) suspends the effect graph, awaits the thunks, restores reactivity context (`$.save` for deriveds), and runs the body — enabling "await anywhere in templates" under the experimental async flag.

---

## 7. Compiler → Runtime Contract

| Emitted call | Runtime implementation | Notes |
|---|---|---|
| `$.if(node, fn, elseif?)` | `dom/blocks/if.js: if_block` | two branch effects; `elseif` ⇒ `EFFECT_TRANSPARENT` |
| `$.each(node, flags, get_collection, get_key, render_fn, fallback?)` | `dom/blocks/each.js: each` | keyed reconciliation, deferred appends in batches |
| `$.await(node, get_input, pending, then, catch)` | `dom/blocks/await.js: await_block` | pending microtask grace; rethrow without catch |
| `$.key(node, get_key, render_fn)` | `dom/blocks/key.js: key` | full branch remount on key change |
| `$.boundary(node, props, children)` | `dom/blocks/boundary.js: boundary` | `Boundary` class handles errors + async suspension |
| `$.html(node, get_html, svg?, mathml?, ignored?)` | `dom/blocks/html.js: html` | namespace-aware raw insertion |
| `$.slot(node, $$props, name, props, fallback)` | `dom/blocks/slot.js: slot` | classic slots + snippet interop |
| `$.snippet(node, get_fn, …args)` / direct call | `dom/blocks/snippet.js: snippet` | dev wrapper preserves component context |
| `$.derived`, `$.derived_safe_equal`, `$.get`, `$.async`, `$.async_derived`, `$.save` | `internal/client/runtime.js`, `reactivity/deriveds.js`, `reactivity/async.js` | see [client_runtime_core](client_runtime_core.md) |
| `$.invalidate_store`, `$.invalidate_inner_signals`, `$.deep_read_state`, `$.untrack` | `internal/client/runtime.js`, `legacy.js` | legacy-mode invalidation fabric |
| `$.validate_each_keys`, `$.validate_snippet_args` | `internal/client/validate.js`, `dev/validation.js` | dev-only assertions |
| `$.tag`, `$.add_svelte_meta`, `$.wrap_snippet`, `$.snapshot` | `internal/client/dev/*` | dev-mode instrumentation (see [client_dev_mode](client_dev_mode.md)) |

Because every one of these is a `$.`-namespaced reference resolved through `internal/client/index.js`, the emitted component code is tree-shakeable: unused block types drop their runtime counterparts (verified by `scripts/check-treeshakeability.js`, see [svelte_build_tooling](svelte_build_tooling.md)).

---

## 8. State & Context Model

The visitors operate on `ComponentClientTransformState` (extends `TransformState` from `3-transform/types.d.ts`), the fields most relevant here being:

- **`scope` / `scopes`** — lexical scopes from analysis; used for unique name generation (`scope.generate('consequent')`), shadowing detection (`$$array` uniquing) and function-depth comparisons in `EachBlock`.
- **`transform`** — the pluggable *binding semantics table*: `read`/`assign`/`mutate`/`update` hooks per declared name. Block visitors install entries for `item`, index, destructured parts, `{:then}`/`{:catch}` values and `{@const}` names, and **clone the map** (`{ ...state.transform }`) so sibling branches never leak bindings into each other. The generic rewriting of identifier reads/assignments is documented in [compiler_client_transform_state_and_reactivity](compiler_client_transform_state_and_reactivity.md).
- **`node`** — the current anchor identifier threaded into every runtime call.
- **`init` / `consts` / `update` / `after_update`** — the output buffers described in §3.2.
- **`analysis.runes` / `maybe_runes`** — selects strict vs. legacy codegen paths (`derived_safe_equal`, legacy invalidation, `$.untrack` in `DebugTag`).
- **`options.experimental.async`** — toggles the `SvelteBoundary` const/snippet placement strategy.

---

## 9. Design Notes & Gotchas

1. **`{:else if}` ≠ nested if.** Logically identical, but compiled differently on purpose: flattened chains carry `elseif = true`, making their branch effect transparent so `transition:` directives replay when any condition in the chain flips.
2. **Anchor-first discipline.** Every DOM-rendering visitor calls `template.push_comment()` *before* any other work, matching hydration anchor order; skipping it breaks `hydrate_next()` in the runtime blocks.
3. **Each-block scope subtleties.** The collection expression is deliberately visited in the **parent** scope; `key_state` keeps a separate transform map so key expressions see the raw item (no `$.get`) unless the key legitimately uses the index; `uses_index` is flipped lazily when transforms observe index reads.
4. **Legacy invalidation is additive.** `{@const}`-driven mutation sequences (`assign`/`mutate` hooks) append `$.invalidate_inner_signals` over the union of *all ancestor each blocks'* transitive deps — a direct emulation of Svelte 4 dependency invalidation.
5. **Const tags in boundaries are duplicated** (non-async mode) into each hoisted snippet; the source comment flags this as a compatibility concession slated for reversion.
6. **Dev/prod divergence is structural, not just flag-gated**: snippets become `function` expressions + `$.wrap_snippet` in dev (to access `arguments`), and every block mount is wrapped in `$.add_svelte_meta` for DevTools.
7. **Mirrored implementation.** Each visitor has an SSR counterpart in [compiler_server_transform](compiler_server_transform.md) with the same node-type coverage; behavioral parity is enforced by shared snapshot tests rather than shared code.

---

## 10. Related Module Documentation

- [compiler_client_transform](compiler_client_transform.md) — parent phase: client transform orchestration
- [compiler_client_transform_templates](compiler_client_transform_templates.md) — `Fragment`, template strings, `objectify`/`stringify`
- [compiler_client_transform_state_and_reactivity](compiler_client_transform_state_and_reactivity.md) — identifier/member/assignment reactivity rewriting
- [compiler_client_transform_elements_and_directives](compiler_client_transform_elements_and_directives.md) — element + directive compilation
- [compiler_client_transform_components_and_scripts](compiler_client_transform_components_and_scripts.md) — components, imports/exports, JS-level visitors
- [compiler_server_transform](compiler_server_transform.md) — SSR twin of this module
- [compiler_analyzer](compiler_analyzer.md) / [compiler_analyzer_scope](compiler_analyzer_scope.md) / [compiler_analyzer_block_visitors](compiler_analyzer_block_visitors.md) — metadata & scopes consumed here
- [compiler_parser](compiler_parser.md) — AST construction
- [compiler_core](compiler_core.md) — `b.*` AST builders, options validation
- [compiler_types](compiler_types.md) — `IfBlock`, `EachBlock`, `AwaitBlock`, … node type definitions
- [compiler_diagnostics](compiler_diagnostics.md) — errors such as `block_unclosed` raised earlier in the pipeline
- [reactive_runtime_engine](reactive_runtime_engine.md) / [client_runtime_core](client_runtime_core.md) / [client_dev_mode](client_dev_mode.md) — runtime engine the emitted code drives
- [client_dom_renderer](client_dom_renderer.md) — DOM block implementations (`if_block`, `each`, `await_block`, `key`, `boundary`, `html`, `slot`, `snippet`)
