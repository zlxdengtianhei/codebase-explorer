# Reactivity Benchmarks

> **Module:** `reactivity_benchmarks` (part of *Repository Engineering Infrastructure*)
> **Location:** `benchmarking/benchmarks/reactivity/**`
> **Code under test:** Svelte 5 Reactive Runtime Engine (`packages/svelte/src/internal/client`) — see [Reactive Runtime Engine](reactive_runtime_engine.md)

## 1. Purpose and Scope

The `reactivity_benchmarks` module is a **pure signal-graph performance suite** for Svelte 5's reactive runtime. It contains no DOM, no components, and no compilation — every benchmark constructs a graph of *signals*, *derived values*, and *effects* directly against the internal client runtime (`svelte/internal/client`), then measures how fast that runtime can:

1. **Create** reactive primitives at scale (up to 100,000 signals/deriveds),
2. **Propagate** updates through dependency graphs of different shapes (chains, diamonds, fans, multiplexers), and
3. **Avoid work** — correctly pruning recomputation when source changes cannot affect downstream values.

Every benchmark also reports **GC pressure** (`gc_time`) alongside wall-clock time, making the suite sensitive to allocation behaviour in the signal graph (per-update objects, dependency arrays, effect re-creation, etc.).

The suite is adapted from the community [js-reactivity-benchmark](https://github.com/milomg/js-reactivity-benchmark) project (see the attribution comment in `benchmarks/reactivity/index.js`); the `kairo/*` benchmarks mirror the graph topologies of the Kairo reactive-core benchmark suite, and `mol_bench` is the classic "molecule" propagation benchmark popularised by Reactively.

### What it is *not*

- It does **not** benchmark the compiler (see the [Compiler Front-End](compiler_front_end_parsing__analysis___css_scoping_pipeline.md) / [Compiler Back-End](compiler_back_end_client___server_code_generation.md) modules).
- It does **not** benchmark DOM rendering/SSR — that is the sibling `ssr_benchmarks` suite ([SSR Benchmarks](ssr_benchmarks.md)).
- It is **not** a correctness test suite, although every benchmark contains `assert()` gates that make it *fail loudly* if propagation semantics break — timings are only reported for runs that produced provably correct results.

## 2. How It Fits Into the Repository

```mermaid
flowchart TD
    subgraph Infra["Repository Engineering Infrastructure"]
        RUN["benchmarking/run.js<br/>(suite orchestrator)"]
        CMP["benchmarking/compare/<br/>(cross-version comparison —<br/>separate module)"]
    end

    subgraph Suites["Benchmark suites"]
        RB["benchmarks/reactivity/index.js<br/><b>reactivity_benchmarks</b> (28 entries)<br/>— this module"]
        SSR["benchmarks/ssr/index.js<br/>ssr_benchmarks"]
    end

    subgraph ThisModule["reactivity_benchmarks"]
        SB["sbench.js<br/>creation micro-benchmarks"]
        K["kairo/*.js<br/>graph-topology suite (8 files)"]
        MOL["mol_bench.js<br/>heavy-propagation benchmark"]
    end

    subgraph Harness["Shared measurement harness"]
        FT["benchmarking/utils.js<br/>fastest_test · assert"]
        GT["GarbageTrack<br/>PerformanceObserver('gc') + v8-natives"]
    end

    subgraph CUT["Code under test"]
        RT["svelte/internal/client<br/>Reactive Runtime Engine<br/>(signals · deriveds · effects · batching)"]
    end

    RUN --> RB
    RUN --> SSR
    RB --> SB
    RB --> K
    RB --> MOL
    SB & K & MOL --> FT
    FT --> GT
    SB & K & MOL --> RT
```

- **Entry point:** `benchmarking/run.js` wraps the run in `$.push({}, true)` / `$.pop()` (a runtime effect context) and iterates the `reactivity_benchmarks` array exported by `benchmarks/reactivity/index.js`, awaiting each exported async benchmark function, printing its result object, and accumulating `time` / `gc_time` per suite and in total. Any failed `assert` aborts the whole run with a non-zero exit code.
- **Registration:** `benchmarks/reactivity/index.js` imports all 28 benchmark functions and exports them in a fixed order (all `sbench` creation tests first, then all `kairo_*` pairs, then `mol_bench`), keeping runs comparable over time.
- **Cross-version workflow:** results are plain `{ benchmark, time, gc_time }` objects, designed to be consumed by the comparison tooling in `benchmarking/compare` (see [Benchmark Comparison Tooling](benchmark_comparison_tooling.md)).

## 3. Runtime API Surface Under Test

All benchmarks drive the runtime through a tiny, stable internal API (detailed semantics live in the [Reactive Runtime Engine](reactive_runtime_engine.md) docs):

| Internal API | Role in benchmarks |
| --- | --- |
| `$.state(v)` | Creates a writable **source signal** (`head`, `A`, `B`, the 100 `heads[]` in `kairo_mux`) |
| `$.derived(fn)` | Creates a lazy, memoised **computed signal**; `fn` runs inside a tracking context so `$.get` calls become dependency edges |
| `$.get(signal)` | Reads a value; inside a `derived`/`render_effect` it *subscribes* (records the dependency). Repeated reads of the same dependency within one re-evaluation are deduplicated by the runtime |
| `$.set(signal, v)` | Writes a source and marks downstream dependents dirty, scheduling propagation |
| `$.flush(fn)` | Runs `fn` (the mutations) and then synchronously drains the scheduler queue — the unit of "one propagation" in every benchmark |
| `$.effect_root(fn)` | Opens an **ownership root**; returns a `destroy` function that tears down every signal/effect created inside — the backbone of the owned/unowned pattern and of memory-leak-free repetition |
| `$.render_effect(fn)` | Creates a sink effect (the "leaf" of every measured graph); incrementing a `counter` inside it is the standard way benchmarks verify *how many times* propagation ran |

`sbench.js` imports this surface via the deep path `packages/svelte/src/internal/client/index.js`, while the kairo/mol benchmarks use the package specifier `svelte/internal/client` — both resolve to the same runtime through the workspace link.

## 4. Benchmark Execution Model

Every exported benchmark follows the same disciplined lifecycle:

```mermaid
flowchart LR
    A["setup()<br/>build signal graph<br/>+ effect_root sinks"] --> B["JIT warm-up<br/>kairo/mol: 10× · sbench: 3×"]
    B --> C["fresh setup()<br/>for measurement"]
    C --> D["fastest_test(10, workload)<br/>GC-forced, GC-tracked timing"]
    D --> E["report<br/>{ benchmark, time, gc_time }"]
    E --> F["destroy()<br/>tear down effects"]
```

```mermaid
sequenceDiagram
    autonumber
    participant R as run.js
    participant B as benchmark fn (e.g. kairo_deep_owned)
    participant S as setup()
    participant RT as svelte/internal/client
    participant F as fastest_test (benchmarking/utils.js)
    participant G as V8 + PerformanceObserver('gc')

    R->>B: await benchmark()
    B->>S: warm-up loops (setup → run → destroy)
    S->>RT: state / derived / render_effect / effect_root
    Note over B,RT: warm-up stabilises JIT before timing
    B->>S: setup() — the measured graph
    B->>F: fastest_test(10, () => run() × N)
    loop 10 attempts (best-of wins)
        F->>G: v8.collectGarbage()
        F->>G: time fn with performance.now()
        G-->>F: wall time + GC durations overlapping the window
    end
    F-->>B: fastest { time, gc_time }
    B->>RT: destroy() (+ destroy_owned())
    B-->>R: { benchmark, time, gc_time }
```

### 4.1 The measurement harness (`benchmarking/utils.js`)

`fastest_test(times, fn)` is the heart of the harness (shared with the SSR suite):

1. Forces a full `v8.collectGarbage()` before each attempt so allocations from previous attempts do not pollute the measured window.
2. Starts a `PerformanceObserver` on the `'gc'` entry type (`GarbageTrack`) and records the timed window's start/end.
3. Times `fn()` with `performance.now()`, then sums the durations of all GC events that started *inside* that window → `gc_time`.
4. Repeats `times` (always `10`) times and returns the **fastest** attempt — a latency metric rather than an average, which suppresses noise from OS scheduling and background GC.

`assert(condition)` throws on falsy values; every benchmark calls it inside its `run()` after each propagation to pin down exact expected values (and exact sink-execution counters), so the reported numbers always describe *correct* propagation.

### 4.2 The owned / unowned duality

Each graph benchmark ships two variants that isolate one specific runtime cost — **ownership bookkeeping**:

```js
// *_unowned: the graph lives outside any effect root; teardown is trivial
export async function kairo_deep_unowned() { /* warm-up, setup, fastest_test, destroy() */ }

// *_owned: the whole benchmark — including the measured graph — is created
// inside an $.effect_root, so the runtime must maintain owner links
export async function kairo_deep_owned() {
    const destroy_owned = $.effect_root(() => {
        /* 10 warm-up loops + final setup(), all owned by this root */
    });
    await fastest_test(10, () => { for (let i = 0; i < 1000; i++) run(); });
    destroy();          // graph teardown
    destroy_owned();    // root teardown
}
```

Comparing `*_owned` vs `*_unowned` timings quantifies the price of ownership tracking (linking children, enabling deep teardown). The `owned` variants are always registered *before* their `unowned` twins in the suite array.

### 4.3 Result contract

| Field | Type | Meaning |
| --- | --- | --- |
| `benchmark` | `string` | Exact function name (e.g. `kairo_diamond_unowned`) — the join key for comparison tooling |
| `time` | `string` (2dp) | Wall-clock milliseconds of the fastest of 10 GC-forced attempts |
| `gc_time` | `string` (2dp) | Milliseconds of GC activity overlapping that attempt |

`run.js` coerces these with `Number(...)` and sums them per suite and globally.

## 5. Benchmark Catalogue

### 5.1 `sbench.js` — creation throughput (fan-in / fan-out ratios)

Times **graph construction** at `COUNT = 100,000` nodes. Each `sbench_create_*` test builds a source pool and then deriveds with a fixed source→computation ratio; the timed phase wraps the construction in a fresh `$.effect_root` and destroys it, so allocation *and* teardown costs are captured. See [Reactivity Benchmarks — sbench Creation Suite](reactivity_benchmarks_sbench.md).

| Benchmark | Shape | Nodes created per timed `bench()` call |
| --- | --- | --- |
| `sbench_create_signals` | sources only | 100k `$.state` signals (100× per attempt) |
| `sbench_create_0to1` | 0 sources → 1 derived | 100k constant deriveds |
| `sbench_create_1to1` | 1 → 1 | 100k deriveds, 100k sources |
| `sbench_create_2to1` | 2 → 1 | 50k deriveds, 100k sources |
| `sbench_create_4to1` | 4 → 1 | 25k deriveds, 100k sources |
| `sbench_create_1000to1` | 1000 → 1 | 100 deriveds each summing 1000 sources |
| `sbench_create_1to2` / `_1to4` / `_1to8` / `_1to1000` | 1 → N fan-out | 100k deriveds sharing 50k/25k/12.5k/100 sources |

### 5.2 `kairo/*.js` — graph-topology propagation suite

Eight benchmarks, each a different dependency-graph shape with `run()` performing hundreds of `$.flush`-separated updates and asserting exact results and exact sink counts. Every file exports an `_owned`/`_unowned` pair. See [Reactivity Benchmarks — Kairo Topology Suite](reactivity_benchmarks_kairo.md).

| Benchmark | Topology | What it isolates |
| --- | --- | --- |
| `kairo_avoidable` | linear chain with a *constant* intermediate + `busy()` work | **Pruning**: `computed5` provably never changes; a good runtime skips the heavy downstream entirely |
| `kairo_broad` | 1 source → 50 × (derived → derived → render_effect) | **Wide fan-out**: 50 sinks must each run once per update (counter = 50 × 50) |
| `kairo_deep` | 1 source → 50-deep chain → 1 sink | **Propagation latency** along long chains (counter must be exactly `iter`) |
| `kairo_diamond` | 1 source → 5 parallel branches → `sum` → 1 sink | **Diamond merge**: each branch re-evaluates once, the sum once, the sink once |
| `kairo_mux` | 100 sources → 1 mux object → 2×100 downstream → 100 sinks | **Multiplexing**: one aggregated derived fanning out to per-key subscribers |
| `kairo_repeated` | 1 source read 30× inside one derived → 1 sink | **Dependency dedup** for repeated reads |
| `kairo_triangle` | 10-deep chain + `sum` over every chain node → 1 sink | Hybrid deep-chain + broad merge (per-level telescoping sum) |
| `kairo_unstable` | derived conditionally reads `double` or `inverse` 20× per run | **Unstable/conditional dependencies**: sink must still run exactly once per source change |

### 5.3 `mol_bench.js` — heavy-propagation end-to-end

The "molecule" benchmark: two sources (`A`, `B`) feed `C`, `D` (with a custom element-wise `equals` override — a demonstration of the runtime's equality customisation hook), which feed `E`, `F`, `G`; three render effects push results through `hard()` — a recursive `fib(16)` payload that makes *unnecessary* recomputation catastrophic. Each `run(i)` performs two batched flushes (two sources written per flush) and asserts four exact output values. 10,000 iterations per timed attempt. See [Reactivity Benchmarks — mol_bench](reactivity_benchmarks_mol.md).

## 6. Sub-Module Documentation

All sub-module docs live flat in the same documentation folder as this file and were generated from the module's 10 core benchmark files.

| Sub-module | Core files covered | Documentation |
| --- | --- | --- |
| **Kairo topology suite** | `kairo_avoidable.js`, `kairo_broad.js`, `kairo_deep.js`, `kairo_diamond.js`, `kairo_mux.js`, `kairo_repeated.js`, `kairo_triangle.js`, `kairo_unstable.js` (16 exported benchmarks + the `kairo/util.js` `busy()` helper) | [reactivity_benchmarks_kairo.md](reactivity_benchmarks_kairo.md) |
| **sbench creation suite** | `sbench.js` — 10 registered creation benchmarks (`sbench_create_*`) built from 9 ratio templates (`create_computations_*` / `create_data_signals`) | [reactivity_benchmarks_sbench.md](reactivity_benchmarks_sbench.md) |
| **mol_bench** | `mol_bench.js` — deep multi-source graph with expensive `fib(16)` payloads and a custom `equals` hook | [reactivity_benchmarks_mol.md](reactivity_benchmarks_mol.md) |

Wiring reminder: these files are aggregated by the registry `benchmarks/reactivity/index.js` (the `reactivity_benchmarks` array consumed by `benchmarking/run.js`); no sub-module registers itself — adding a benchmark means adding its file **and** appending it to that array.

## 7. Related Documentation

- [Reactive Runtime Engine](reactive_runtime_engine.md) — the signals/deriveds/effects/batching engine being measured; explains what `$.state`, `$.derived`, `$.flush`, `$.effect_root` actually do internally.
- [SSR Benchmarks](ssr_benchmarks.md) — the sibling `benchmarking/benchmarks/ssr` suite sharing `benchmarking/utils.js`.
- [Benchmark Comparison Tooling](benchmark_comparison_tooling.md) — consumes the result objects this module produces for cross-version/runtime comparisons.
