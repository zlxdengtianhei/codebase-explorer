# `public_api_client_entry` — Client-Side Public API Entry Point

**Module path:** `packages/svelte/src/index-client.js`
**Parent module:** [public_api](public_api.md) (Public API Surface & Compatibility Layer)

---

## 1. Introduction

`public_api_client_entry` is the **browser-facing entry point of the `svelte` package** — the module that resolves when application code executes:

```js
import { onMount, tick, mount, flushSync } from 'svelte';
```

It has two responsibilities:

1. **Define the client component lifecycle API** — `onMount`, `onDestroy`, `createEventDispatcher` (deprecated), `getAbortSignal`, plus the legacy-mode-only `beforeUpdate` / `afterUpdate`.
2. **Re-export curated internals as public API** — `mount` / `hydrate` / `unmount`, `tick` / `untrack` / `settled`, `flushSync`, the context API (`setContext` / `getContext` / `hasContext` / `getAllContexts`) and `createRawSnippet`.

The module is deliberately a thin **facade**: every behavior it exposes delegates to the reactive runtime core, the DOM renderer, or the batching scheduler (see [client_runtime_core](client_runtime_core.md), [client_dom_renderer_lifecycle_api](client_dom_renderer_lifecycle_api.md), [client_runtime_core_batching](client_runtime_core_batching.md)). Its only substantive logic is lifecycle registration, legacy-mode bridging, and dev-time rune interception.

Its server-side counterpart is documented in [public_api_server_entry](public_api_server_entry.md); both share a nearly identical export shape so isomorphic components can be written without conditional imports.

---

## 2. Public API Surface

### 2.1 Functions defined in this module

| Export | Mode | Purpose |
|---|---|---|
| `onMount(fn)` | runes + legacy | Run `fn` once after the component mounts to the DOM; a *synchronously returned* function acts as cleanup on unmount. |
| `onDestroy(fn)` | runes + legacy | Run `fn` when the component is destroyed. Implemented on top of `onMount`. The only lifecycle function that also runs during SSR (see [public_api_server_entry](public_api_server_entry.md)). |
| `getAbortSignal()` | runes | Return an `AbortSignal` that aborts when the enclosing `$derived`/`$effect` re-runs or is destroyed. |
| `createEventDispatcher()` | legacy (deprecated) | Create a `CustomEvent` dispatcher for component events. Superseded by callback props and `$host()`. |
| `beforeUpdate(fn)` | legacy only (deprecated) | Pre-update hook. Use `$effect.pre` in runes mode. |
| `afterUpdate(fn)` | legacy only (deprecated) | Post-update hook. Use `$effect` in runes mode. |
| `throw_rune_error(rune)` | *private*, DEV only | Module-initialization side effect: intercepts bare `$state`, `$effect`, `$derived`, `$inspect`, `$props`, `$bindable` globals to emit a helpful error outside Svelte-compiled code. |

### 2.2 Re-exported from internal subsystems

| Export | Source module | Documented by |
|---|---|---|
| `mount`, `hydrate`, `unmount` | `internal/client/render.js` | [client_dom_renderer_lifecycle_api](client_dom_renderer_lifecycle_api.md) |
| `tick`, `untrack`, `settled` | `internal/client/runtime.js` | [client_runtime_core_runtime](client_runtime_core_runtime.md) |
| `flushSync` | `internal/client/reactivity/batch.js` | [client_runtime_core_batching](client_runtime_core_batching.md) |
| `setContext`, `getContext`, `hasContext`, `getAllContexts` | `internal/client/context.js` | [context_api_client](context_api_client.md) |
| `createRawSnippet` | `internal/client/dom/blocks/snippet.js` | [client_dom_renderer_control_flow_blocks](client_dom_renderer_control_flow_blocks.md) |

---

## 3. Architecture

The entry module sits at the boundary between user code and the internal client runtime. Solid arrows are direct imports used to *implement* the lifecycle functions; dashed arrows are pass-through re-exports.

```mermaid
flowchart TB
    APP["Application / compiled component code<br/>(import from 'svelte')"]

    subgraph ENTRY["public_api_client_entry — index-client.js"]
        subgraph DEFINED["Defined here"]
            OM["onMount"]
            OD["onDestroy"]
            GAS["getAbortSignal"]
            CED["createEventDispatcher ⚠deprecated"]
            BU["beforeUpdate ⚠deprecated"]
            AU["afterUpdate ⚠deprecated"]
            TRE["throw_rune_error (DEV, private)"]
        end
        subgraph RE["Re-exports"]
            FS["flushSync"]
            CTXR["setContext / getContext /<br/>hasContext / getAllContexts"]
            MHR["mount / hydrate / unmount"]
            TUS["tick / untrack / settled"]
            CRS["createRawSnippet"]
        end
    end

    subgraph INTERNAL["Internal client runtime"]
        RC["client_runtime_core_runtime<br/>runtime.js: active_reaction, untrack"]
        EFF["reactivity/effects.js<br/>user_effect"]
        ERR["client errors.js<br/>lifecycle_outside_component,<br/>rune_outside_svelte, ..."]
        CTXM["context_api_client<br/>context.js: component_context"]
        FLAGS["shared_runtime_flags<br/>legacy_mode_flag"]
        REN["client_dom_renderer_lifecycle_api<br/>render.js"]
        BAT["client_runtime_core_batching<br/>batch.js"]
        SNIP["client_dom_renderer_control_flow_blocks<br/>snippet.js"]
    end

    UTIL["shared_runtime_utilities<br/>shared/utils.js: is_array"]
    ENV["esm-env<br/>DEV flag"]

    APP -->|"lifecycle calls"| ENTRY
    ENTRY -->|"active_reaction"| RC
    ENTRY -->|"untrack"| RC
    ENTRY -->|"user_effect"| EFF
    ENTRY -->|"error helpers"| ERR
    ENTRY -->|"component_context"| CTXM
    ENTRY -->|"legacy_mode_flag"| FLAGS
    ENTRY -->|"is_array"| UTIL
    ENTRY -->|"DEV"| ENV

    ENTRY -.-> MHR
    MHR -.-> REN
    ENTRY -.-> FS
    FS -.-> BAT
    ENTRY -.-> CTXR
    CTXR -.-> CTXM
    ENTRY -.-> TUS
    TUS -.-> RC
    ENTRY -.-> CRS
    CRS -.-> SNIP
```

### 3.1 Module dependency list (source imports)

| Import | Used by |
|---|---|
| `active_reaction`, `untrack` ← `internal/client/runtime.js` | `getAbortSignal`, `onMount`, `onDestroy` |
| `user_effect` ← `internal/client/index.js` | `onMount` (runes path) |
| `component_context` ← `internal/client/context.js` | guard checks in every lifecycle function; `createEventDispatcher` context capture |
| `legacy_mode_flag` ← `internal/flags/index.js` | `onMount` legacy branch |
| `is_array` ← `internal/shared/utils.js` | `createEventDispatcher` callback normalization |
| `* as e` ← `internal/client/errors.js` | all diagnostics (`lifecycle_outside_component`, `lifecycle_legacy_only`, `get_abort_signal_outside_reaction`, `rune_outside_svelte`) |
| `DEV` ← `esm-env` | gates the `throw_rune_error` block for dead-code elimination in production |

---

## 4. Component Reference

### 4.1 `getAbortSignal()`

Returns an [`AbortSignal`](https://developer.mozilla.org/en-US/docs/Web/API/AbortSignal) bound to the **currently active reaction** (a `$derived` or `$effect`). Typical use: aborting `fetch` calls inside async deriveds when inputs change.

```js
export function getAbortSignal() {
	if (active_reaction === null) {
		e.get_abort_signal_outside_reaction();
	}
	return (active_reaction.ac ??= new AbortController()).signal;
}
```

Key behaviors:

- **Guarded:** throws `get_abort_signal_outside_reaction` when called outside a reaction.
- **Lazy singleton per reaction:** the `AbortController` is memoized on the reaction object (`ac ??= new AbortController()`), so repeated calls in the same derivation share one signal.
- **Automatic teardown:** the runtime aborts the controller when the reaction re-runs or is destroyed — callers never clean up manually.

```mermaid
flowchart TD
    A["getAbortSignal() inside $derived / $effect"] --> B{"active_reaction !== null?"}
    B -- "no" --> C["throw get_abort_signal_outside_reaction"]
    B -- "yes" --> D{"reaction.ac already set?"}
    D -- "no" --> E["ac = new AbortController()"]
    D -- "yes" --> F["reuse existing controller"]
    E --> G["return ac.signal"]
    F --> G
    G --> H["signal aborts automatically when<br/>reaction re-runs or is destroyed"]
```

### 4.2 `onMount(fn)`

Schedules `fn` to run **once** after the component is mounted. Unlike `$effect`, it never re-runs on dependency changes. Must be called during component initialization (may live in an external module as long as it is invoked during init). Never runs during SSR.

**Runes mode** (`legacy_mode_flag === false`, or the component has no legacy context `component_context.l`):

```js
user_effect(() => {
	const cleanup = untrack(fn);
	if (typeof cleanup === 'function') return cleanup;
});
```

- `untrack(fn)` executes `fn` *without dependency tracking* — reads inside `fn` cannot cause the effect to re-run, guaranteeing "run once" semantics.
- If `fn` returns a function synchronously, it is registered as the effect teardown and invoked on unmount.

**Legacy mode** (compiler set `legacy_mode_flag` and the component context carries a legacy record `context.l`):

`fn` is queued on `init_update_callbacks(context).m` instead of creating a reactive effect. The legacy runtime drives the queue around its update cycle, interleaving it with `beforeUpdate` (`u.b`) and `afterUpdate` (`u.a`).

### 4.3 `onDestroy(fn)`

Runs `fn` immediately before unmount. Implemented purely in terms of `onMount`:

```js
export function onDestroy(fn) {
	if (component_context === null) e.lifecycle_outside_component('onDestroy');
	onMount(() => () => untrack(fn));
}
```

The inner arrow function is the *synchronously returned cleanup* of the mount effect — Svelte's cleanup mechanism is the single primitive behind both APIs. `onDestroy` is the only member of the `onMount`/`beforeUpdate`/`afterUpdate`/`onDestroy` group that also executes in server-side components (the server entry implements it independently on `current_component.d`, see [public_api_server_entry](public_api_server_entry.md)).

### 4.4 `createEventDispatcher()` — deprecated

Creates a dispatcher for legacy component events (`on:message` in markup). Subtle but important design points:

- **Context is captured at creation time** (`active_component_context = component_context`), not at dispatch time. The dispatcher keeps working even if called from a timer after initialization.
- **Dispatch path:** looks up `$$events[type]` on the captured context's props object (`context.s.$$events`) — this map is populated by the compiler for `on:*` attributes on component tags. Then, for each handler (normalized via `is_array`), it invokes `fn.call(context.x, event)` where `context.x` is the component instance (assigned in `pop()`).
- **Event semantics:** builds a non-bubbling `CustomEvent` (internal `create_custom_event` helper) and returns `!event.defaultPrevented`; returns `true` when no listeners exist.
- **Replacement:** callback props and the `$host()` rune.

### 4.5 `beforeUpdate(fn)` / `afterUpdate(fn)` — deprecated, legacy only

Both follow the same skeleton:

1. Throw `lifecycle_outside_component` if `component_context === null`.
2. Throw `lifecycle_legacy_only` if `component_context.l === null` — i.e., called from a **runes-mode** component. Runes replacements are `$effect.pre` and `$effect` respectively.
3. Queue `fn` on `init_update_callbacks(context).b` (before) or `.a` (after).

The legacy runtime calls these queues before/after each update pass; the first `beforeUpdate` runs before the initial `onMount`, and the first `afterUpdate` runs after it.

### 4.6 `init_update_callbacks(context)` — private helper

```js
function init_update_callbacks(context) {
	var l = context.l;
	return (l.u ??= { a: [], b: [], m: [] });
}
```

Lazily creates the legacy callback store on the component context: `a` = afterUpdate, `b` = beforeUpdate, `m` = onMount queue. This object is also what [legacy_compat](legacy_compat.md) (`createClassComponent`/`asClassComponent`) consumes to emulate class-component lifecycle hooks.

### 4.7 `throw_rune_error(rune)` — private, DEV only

At module initialization, when `DEV` is true (from `esm-env`), the module installs interceptors on `globalThis` for each rune name (`$state`, `$effect`, `$derived`, `$inspect`, `$props`, `$bindable`):

```mermaid
flowchart TD
    A["DEV build: module top-level side effect"] --> B["for each rune: $state, $effect,<br/>$derived, $inspect, $props, $bindable"]
    B --> C{"rune in globalThis?"}
    C -- "yes" --> D["skip (don't clobber)"]
    C -- "no" --> E["Object.defineProperty(globalThis, rune,<br/>{ configurable: true, get, set })"]
    E --> F["plain .js file references $state etc."]
    F --> G{"has a value been assigned?"}
    G -- "no" --> H["throw rune_outside_svelte(rune)<br/>— helpful error instead of ReferenceError"]
    G -- "yes" --> I["return stored value (no false positive)"]
```

Because runes are compile-time constructs, referencing them outside `.svelte`/compiled files would otherwise produce a confusing `ReferenceError: $state is not defined`. The getter/setter pair lets assignment-based shims keep working while bare reads produce a directed error. In production builds the whole block is statically eliminable because `DEV` is a compile-time constant.

---

## 5. Execution Flows

### 5.1 Component mount and lifecycle registration

`mount` is re-exported from the DOM renderer, but lifecycle functions *defined here* are called **back** during component initialization — the entry module participates on both sides of a mount:

```mermaid
sequenceDiagram
    autonumber
    participant App as Application code
    participant Entry as index-client.js
    participant REN as render.js (mount)
    participant Ctx as context.js (component_context)
    participant Eff as effects.js (user_effect)
    participant RT as runtime.js (untrack)

    App->>Entry: mount(Component, { target })
    Entry->>REN: forwarded re-export
    REN->>Ctx: push(props) — component_context established
    Note over Ctx: component body executes;<br/>it calls lifecycle functions on Entry
    App->>Entry: onMount(fn)
    Entry->>Ctx: guard: component_context must not be null
    alt legacy_mode_flag && context.l !== null
        Entry->>Ctx: init_update_callbacks(ctx).m.push(fn)
    else runes mode
        Entry->>Eff: user_effect(() => untrack(fn))
    end
    REN->>Ctx: pop(component) — context.e effects flushed
    Ctx->>Eff: create_user_effect(fn) for queued init effects
    Note over Eff,RT: on flush: untrack(fn) runs fn once,<br/>synchronous return value becomes teardown
    App->>Entry: unmount(instance)
    Note over Eff: teardown executes — onDestroy/onMount cleanups fire
```

### 5.2 Lifecycle dispatch decision logic

```mermaid
flowchart TD
    A["Lifecycle call, e.g. onMount(fn)"] --> B{"component_context !== null?"}
    B -- "no" --> X1["throw lifecycle_outside_component"]
    B -- "yes" --> C{"which lifecycle?"}
    C -- "onMount" --> D{"legacy_mode_flag AND<br/>context.l !== null?"}
    D -- "yes (legacy)" --> F["queue on context.l.u.m<br/>(init_update_callbacks)"]
    D -- "no (runes)" --> G["user_effect(() => untrack(fn))<br/>+ sync-return cleanup support"]
    C -- "onDestroy" --> H["onMount(() => () => untrack(fn))"]
    C -- "beforeUpdate / afterUpdate" --> I{"context.l === null?"}
    I -- "yes (runes)" --> X2["throw lifecycle_legacy_only"]
    I -- "no (legacy)" --> J["queue on context.l.u.b / u.a"]
    C -- "createEventDispatcher" --> K["capture component_context,<br/>return dispatcher over s.$$events"]
```

### 5.3 Event dispatch (legacy component events)

```mermaid
sequenceDiagram
    participant Comp as Component (init time)
    participant Entry as createEventDispatcher
    participant Ctx as captured component_context
    participant H as Parent handlers ($$events)

    Comp->>Entry: const dispatch = createEventDispatcher()
    Entry->>Ctx: capture active_component_context
    Note over Entry: later, at arbitrary time:
    Comp->>Entry: dispatch('change', detail, options)
    Entry->>Ctx: events = context.s.$$events['change']
    alt listeners exist
        Entry->>Entry: create_custom_event (non-bubbling CustomEvent)
        loop each callback (is_array → slice)
            Entry->>H: fn.call(context.x, event)
        end
        Entry-->>Comp: !event.defaultPrevented
    else no listeners
        Entry-->>Comp: true
    end
```

---

## 6. Client vs. Server Entry Parity

Both entries intentionally expose the same symbol names so shared components compile for either target. Behavior diverges where a browser is required:

| Symbol | This module (client) | `index-server.js` ([public_api_server_entry](public_api_server_entry.md)) |
|---|---|---|
| `onMount` | real effect-based registration | `noop` |
| `beforeUpdate` / `afterUpdate` | legacy queue registration | `noop` |
| `onDestroy` | cleanup of a mount effect | pushes `fn` onto `current_component.d` — **runs** on the server |
| `createEventDispatcher` | walks `$$events`, builds `CustomEvent` | returns `noop` |
| `getAbortSignal` | `active_reaction.ac` signal | server abort-signal implementation |
| `mount` / `hydrate` / `unmount` | real DOM renderer operations | throw `lifecycle_function_unavailable` |
| `tick` / `settled` / `flushSync` | batch-aware flush primitives | async noops |
| Context API | `internal/client/context.js` | `internal/server/context.js` (same semantics) |
| `createRawSnippet` | DOM snippet block | server snippet block |

This table reflects why `onDestroy` is safe in SSR paths while the others are client-only.

---

## 7. Position in the Overall System

```mermaid
flowchart LR
    subgraph PUBLIC["Public API Surface (public_api)"]
        direction TB
        SRV["public_api_server_entry<br/>index-server.js"]
        TYPES["public_api_type_contracts<br/>index.d.ts"]
        HTML["public_api_html_typing<br/>svelte-html.d.ts"]
        CLIENT["**public_api_client_entry**<br/>index-client.js"]
    end

    subgraph CORE["Runtime internals"]
        RCC["client_runtime_core<br/>(signals, deriveds, effects)"]
        CRB["client_runtime_core_batching"]
        CAC["context_api_client"]
        CDRL["client_dom_renderer_lifecycle_api"]
        CDRB["client_dom_renderer_control_flow_blocks"]
    end

    subgraph SUPPORT["Cross-cutting"]
        FLAGS["shared_runtime_flags"]
        DEV["client_dev_mode_validation<br/>(DEV guards / ownership)"]
        LEG["legacy_compat<br/>createClassComponent, bubbler"]
    end

    CLIENT --> RCC
    CLIENT --> CRB
    CLIENT --> CAC
    CLIENT --> CDRL
    CLIENT --> CDRB
    CLIENT --> FLAGS
    LEG -.->|"consumes l.u callback queues"| CLIENT
    DEV -.->|"complements DEV guards"| CLIENT
```

Relationship highlights:

- **Downstream of the compiler, upstream of nothing.** Compiled component code imports *this* module's symbols by name. The tree-shakeability of the internal modules it re-exports is enforced by repository tooling (`scripts/check-treeshakeability.js`, see [svelte_build_tooling](svelte_build_tooling.md)); the module's only top-level side effect (rune interception) is `DEV`-gated and therefore eliminable.
- **Legacy bridge.** The `l.u` callback queues (`m`, `b`, `a`) created by `init_update_callbacks` are the contract between this module and [legacy_compat](legacy_compat.md) class-component shims and the legacy runtime's update cycle.
- **Type contracts.** The runtime return types (`EventDispatcher`) are declared in [public_api_type_contracts](public_api_type_contracts.md); this module imports the type for `createEventDispatcher` from `./index.js`.

---

## 8. Design Notes & Invariants

1. **Initialization-time constraint.** Every defined export (except `getAbortSignal`, which requires an *active reaction*) validates `component_context !== null` and throws `lifecycle_outside_component` otherwise. Lifecycles must be called synchronously during component init.
2. **`untrack` everywhere user code runs.** `onMount`/`onDestroy` wrap user callbacks in `untrack` so that arbitrary reads inside them never create reactive edges — this is what makes "run once" a structural guarantee rather than a convention.
3. **Cleanup is the unifying primitive.** `onDestroy`, `onMount` teardown, and raw-snippet teardown all reduce to effect cleanup functions.
4. **Context capture vs. lookup.** `createEventDispatcher` captures the component context once (dispatch remains valid from async code); context functions (`getContext`, etc.) look up dynamically at call time.
5. **Diagnostics funnel.** All errors originate from `internal/client/errors.js`, keeping message codes centralized (generated via `scripts/process-messages`, see [svelte_build_tooling](svelte_build_tooling.md)).

## 9. See Also

- [public_api](public_api.md) — the full public surface overview
- [public_api_server_entry](public_api_server_entry.md) — server entry and SSR lifecycle differences
- [public_api_type_contracts](public_api_type_contracts.md) — `Component`, `EventDispatcher`, `Snippet`, `SvelteComponentTyped` types
- [client_runtime_core](client_runtime_core.md) — signal model powering `$effect`/`$derived` and `getAbortSignal`
- [client_runtime_core_batching](client_runtime_core_batching.md) — `flushSync`/`tick`/`settled` flushing semantics
- [context_api_client](context_api_client.md) — context API implementation details
- [client_dom_renderer_lifecycle_api](client_dom_renderer_lifecycle_api.md) — `mount`/`hydrate`/`unmount`
- [legacy_compat](legacy_compat.md) — class-component compatibility consuming the legacy callback queues
- [shared_runtime_flags](shared_runtime_flags.md) — `legacy_mode_flag` and friends
