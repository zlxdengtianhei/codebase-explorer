# Compiler CSS Pipeline — Analysis (`compiler_css_pipeline_analysis`)

## 1. Overview

`compiler_css_pipeline_analysis` implements the **CSS analysis step** of the Svelte compiler. It lives inside Phase 2 (`2-analyze`) and operates on the stylesheet AST produced by the parser, populating it with metadata and computing component-level CSS facts that every later stage of the CSS pipeline depends on:

- **Validation** — enforces Svelte's scoping rules around `:global`, `:global(...)`, global blocks (`:global { ... }`) and the CSS nesting selector (`&`), raising compile-time errors for invalid placements.
- **Metadata population** — annotates CSS AST nodes (`Rule`, `ComplexSelector`, `RelativeSelector`) with internal `metadata` flags (`is_global`, `is_global_like`, `used`, `is_global_block`, `has_global_selectors`, `parent_rule`, …).
- **Global-CSS detection** — computes `analysis.css.has_global`, which tells the transform whether the component contributes *unscoped* CSS.
- **Keyframes collection** — records locally-defined `@keyframes` names (to be hash-scoped later) while passing `-global-`-prefixed names through verbatim.

The module is the **analysis half** of the CSS pipeline; its sibling, [compiler_css_pipeline_transform](compiler_css_pipeline_transform.md), consumes the metadata produced here while emitting the final stylesheet.

**Core files**

| File | Exported / key components |
|---|---|
| `packages/svelte/src/compiler/phases/2-analyze/css/css-analyze.js` | `analyze_css` (entry point), `css_visitors`, internal helpers `is_global_block_selector`, `is_in_global_block`, `is_unscoped` |
| `packages/svelte/src/compiler/phases/css.js` | `is_keyframes_node`, `remove_css_prefix` (shared CSS utilities) |

---

## 2. Position in the Compiler Pipeline

`analyze_css` is invoked once per component from `analyze_component` (Phase 2 orchestrator, see [compiler_analyzer](compiler_analyzer.md)), *after* the template/JS visitor walk has populated `analysis.elements`. Immediately afterwards, the CSS-prune step (`prune` + `warn_unused` from `2-analyze/css/css-prune.js`) matches selectors against collected elements and warns about unused selectors. During Phase 3, the transform reads the metadata to scope, prune, and emit the stylesheet (see [compiler_css_pipeline_transform](compiler_css_pipeline_transform.md)).

```mermaid
flowchart LR
    subgraph Pipeline["Svelte compile pipeline"]
        direction LR
        P["Phase 1: Parse<br/>(compiler_parser)"]
        A["Phase 2: Analyze<br/>(compiler_analyzer)"]
        T["Phase 3: Transform<br/>(compiler_client_transform /<br/>compiler_server_transform)"]
    end

    subgraph Phase2["Phase 2 internals"]
        direction TB
        TV["Template and JS visitors<br/>(collect analysis.elements)"]
        ACA["analyze_css<br/>(THIS MODULE)"]
        PR["css-prune<br/>prune / warn_unused"]
    end

    P -->|"AST.CSS.StyleSheet"| ACA
    TV -->|"ComponentAnalysis"| ACA
    ACA -->|"selector metadata +<br/>css.has_global + keyframes"| PR
    PR -->|"used / scoped flags"| T
```

---

## 3. Architecture

The module is a single-pass, depth-first **visitor walk** driven by the `zimmerframe` `walk()` utility. A shared mutable state object (`CssState`) threads the current rule context and the component analysis through every visitor.

```mermaid
flowchart TB
    subgraph Module["compiler_css_pipeline_analysis"]
        ENTRY["analyze_css(stylesheet, analysis)<br/>public entry point"]
        STATE["CssState<br/>keyframes: string[]<br/>rule: Rule or null<br/>analysis: ComponentAnalysis"]

        subgraph Visitors["css_visitors (zimmerframe visitor map)"]
            V1["Atrule"]
            V2["Rule"]
            V3["ComplexSelector"]
            V4["RelativeSelector"]
            V5["NestingSelector"]
        end

        H1["is_global_block_selector<br/>(bare :global pseudo-class)"]
        H2["is_in_global_block<br/>(any ancestor Rule is_global_block)"]
        H3["is_unscoped<br/>(all ancestor Rules have_global_selectors)"]
    end

    subgraph SharedCss["phases/css.js (shared CSS utilities)"]
        KF["is_keyframes_node"]
        RP["remove_css_prefix<br/>(strips -webkit-/-moz-/-o-/-ms-)"]
    end

    subgraph Utils["2-analyze/css/utils.js"]
        G["is_global"]
        UP["is_unscoped_pseudo_class"]
    end

    subgraph Diag["compiler_diagnostics"]
        ERR["errors.js — e.* compile errors"]
        WARN["warnings.js — css_unused_selector<br/>(emitted by css-prune)"]
    end

    ENTRY --> STATE
    ENTRY --> Visitors
    V1 --> KF
    KF --> RP
    V2 --> H1
    V2 --> H2
    V2 --> H3
    V3 --> G
    V4 --> G
    G --> UP
    V2 --> ERR
    V3 --> ERR
    V4 --> ERR
    V5 --> ERR
```

### 3.1 Public API

```js
analyze_css(stylesheet: AST.CSS.StyleSheet, analysis: ComponentAnalysis): void
```

- Creates a `CssState` seeded with `analysis.css.keyframes` (the **same array instance**, so visitor pushes flow directly into the analysis) and walks the stylesheet with `css_visitors`.
- Mutates the stylesheet nodes in place (via `node.metadata.*`) and the `analysis` object (`css.has_global`, `css.keyframes`).
- Throws `CompileError`s (via the `e.*` diagnostics) for invalid selector/global usage.

### 3.2 Internal helpers

| Helper | Signature | Purpose |
|---|---|---|
| `is_global_block_selector` | `(SimpleSelector) => boolean` | `true` for a **bare** `:global` — a `PseudoClassSelector` named `global` with `args === null` (i.e. `:global { … }`, not `:global(…)`) |
| `is_in_global_block` | `(path: Node[]) => boolean` | `true` if any `Rule` on the visitor path has `metadata.is_global_block` — everything inside is emitted unscoped |
| `is_unscoped` | `(path: SvelteNode[]) => boolean` | `true` if **every** `Rule` ancestor has `metadata.has_global_selectors` — the position is not subject to component scoping |

### 3.3 Shared utilities (`phases/css.js`)

| Helper | Purpose |
|---|---|
| `is_keyframes_node` | `remove_css_prefix(node.name) === 'keyframes'` — vendor-prefix-tolerant `@keyframes` detection (matches `@-webkit-keyframes` etc.) |
| `remove_css_prefix` | Strips a leading `-webkit-` / `-moz-` / `-o-` / `-ms-` prefix |

---

## 4. Visitor Walkthrough

### 4.1 `Rule` — global-block detection and rule bookkeeping

The most complex visitor. Per rule it:

1. Links the rule to its parent via `metadata.parent_rule` (nesting context).
2. Iterates each `ComplexSelector` of the prelude looking for a **leading bare `:global`** (found via `is_global_block_selector`), implementing the *global block* feature (`:global { … }`):

```mermaid
flowchart TB
    A["visit Rule"] --> B["Scan each ComplexSelector child:<br/>find bare :global via is_global_block_selector"]
    B --> C{"bare :global at position 0?"}
    C -->|"no, but present"| E5["error:<br/>css_global_block_invalid_modifier"]
    C -->|"yes"| D{"compound has extra selectors<br/>at top level?"}
    D -->|"yes"| E1["error:<br/>css_global_block_invalid_modifier_start"]
    D -->|"no"| F["mark rule.metadata.is_global_block<br/>mark trailing selectors global-like + used"]
    F --> G{"non-descendant combinator<br/>after :global?"}
    G -->|"yes"| E2["error:<br/>css_global_block_invalid_combinator"]
    G -->|"no"| H{"lone :global mixed into<br/>larger selector list?"}
    H -->|"yes"| E3["error:<br/>css_global_block_invalid_list"]
    H -->|"no"| I{"lone :global with<br/>direct declarations?"}
    I -->|"yes"| E4["error:<br/>css_global_block_invalid_declaration"]
    I -->|"no"| J["visit prelude then block<br/>(prelude first, to populate selector metadata)"]
```

3. After visiting the prelude, aggregates selector flags:
   - `metadata.has_global_selectors` / `metadata.has_local_selectors` — set from each complex selector's `metadata.is_global`.
4. Contributes to the component-level flag:
   - `analysis.css.has_global ||= rule has global selectors AND the block contains declarations AND is_unscoped(path)` — i.e. the component ships CSS that is *not* scoped.
5. Visits the block with a new state (`rule: node`) so nested rules chain `parent_rule`.

### 4.2 `ComplexSelector` — `:global` placement validation and global marking

Runs **children first** (`context.next()`), then:

- **Placement validation** for any `:global` in the selector chain:
  - bare `:global` nested inside another pseudo-class (e.g. `:not(:global)`) → `css_global_block_invalid_placement`;
  - `:global(...)` in the *middle* of a chain (only leading/trailing runs of `:global(...)` are allowed) → `css_global_invalid_placement`;
  - `:global(element)` not at the first position of its compound selector → `css_global_invalid_selector_list`;
  - a type selector directly after `:global(.class)` → `css_type_selector_invalid_placement`;
  - `:global(...)` containing multiple selectors inside a compound/complex context → `css_global_invalid_selector`.
- Sets `metadata.rule` (back-reference to the owning `Rule`) and computes `metadata.is_global` (all relative selectors global or global-like); global complex selectors are automatically `metadata.used = true`.
- **Nesting special case:** a `&`-prefixed selector (e.g. `&:hover`) inside a rule whose parent rule selector is global (as in `:global(.foo) { &:hover { … } }`) is marked `used` so it is not flagged as unused.

### 4.3 `RelativeSelector` — global classification

- Rejects a **leading combinator** (`> .foo { … }`) unless the rule itself is nested (`css_selector_invalid`).
- Computes `metadata.is_global` via the shared `is_global` helper (leading `:global`, tolerating trailing unscoped pseudo-classes/elements).
- Computes `metadata.is_global_like` for inherently unscoped selectors: `:host`, `::view-transition*`, and `:root` (unless combined with `:has(...)`, since `:has` arguments must stay scoped).
- When a relative selector is global/global-like, recursively marks **all nested complex selectors** (e.g. inside `:root:not(.x)`) as `used` so they are never reported unused.

### 4.4 `Atrule` — keyframes collection

- If `is_keyframes_node(node)`:
  - names **not** prefixed with `-global-` (and not inside a global block) are pushed onto `analysis.css.keyframes`; the transform later renames them with the component CSS hash to avoid global collisions;
  - names prefixed with `-global-` are emitted verbatim and set `analysis.css.has_global ||= is_unscoped(path)` (empty keyframe blocks are still registered).

### 4.5 `NestingSelector` — `&` placement

- `&` **without** an enclosing rule: only legal as the *sole* selector of a lone `:global(...)` (per the spec, `&` at top level would otherwise be invalid) → otherwise `css_nesting_selector_invalid_placement`.
- `&` directly inside a top-level `:global` block (e.g. `:global { &.foo { … } }`) → `css_global_block_invalid_modifier_start`.

---

## 5. Data Flow and Output Contract

The module consumes the parsed stylesheet plus a freshly built `ComponentAnalysis` and produces three kinds of output consumed downstream:

```mermaid
flowchart LR
    IN1["AST.CSS.StyleSheet<br/>(from compiler_parser)"]
    IN2["ComponentAnalysis<br/>css: { ast, hash, keyframes, has_global }"]

    subgraph Walk["analyze_css walk"]
        M1["Rule.metadata<br/>parent_rule / is_global_block /<br/>has_global_selectors / has_local_selectors"]
        M2["ComplexSelector.metadata<br/>rule / is_global / used"]
        M3["RelativeSelector.metadata<br/>is_global / is_global_like"]
        OUT1["analysis.css.keyframes<br/>(local keyframes names)"]
        OUT2["analysis.css.has_global"]
    end

    OUT3["selector metadata<br/>(used / global flags)"]

    IN1 --> Walk
    IN2 --> Walk
    Walk --> M1
    Walk --> M2
    Walk --> M3
    M1 --> OUT3
    M2 --> OUT3
    M3 --> OUT3
    Walk --> OUT1
    Walk --> OUT2

    OUT3 --> PRUNE["css-prune:<br/>prune per element + warn_unused<br/>(css_unused_selector warning)"]
    OUT1 --> XFORM["Phase 3 CSS transform<br/>(compiler_css_pipeline_transform):<br/>keyframes renaming + scoping"]
    OUT2 --> XFORM
    PRUNE --> XFORM
```

| Output | Producer (visitor) | Consumers |
|---|---|---|
| `Rule.metadata.parent_rule` | `Rule` | `NestingSelector` validation, transform context |
| `Rule.metadata.is_global_block` | `Rule` | css-prune (skips selector matching inside global blocks), transform's own `is_in_global_block` check |
| `Rule.metadata.has_global_selectors` / `has_local_selectors` | `Rule` | `is_unscoped`, scoping decisions |
| `ComplexSelector.metadata.rule` | `ComplexSelector` | prune/apply selector against element tree |
| `ComplexSelector.metadata.is_global` | `ComplexSelector` | rule-level global aggregation |
| `ComplexSelector.metadata.used` | `ComplexSelector` (globals), css-prune (matching) | `warn_unused` → `css_unused_selector` warning; transform drops unused selectors |
| `RelativeSelector.metadata.is_global` / `is_global_like` | `RelativeSelector` | `is_global` aggregation, `used` marking |
| `analysis.css.keyframes` | `Atrule` | transform: hash-scope keyframe names |
| `analysis.css.has_global` | `Atrule`, `Rule` | transform: whether the component contributes unscoped CSS |

> The metadata fields are declared as `/** @internal */` on the CSS AST types in `packages/svelte/src/compiler/types/css.d.ts` — see [compiler_types](compiler_types.md).

---

## 6. Diagnostics Contract

All errors raised by this module are compile errors defined in `errors.js` (see [compiler_diagnostics](compiler_diagnostics.md)). They follow the `css_*` naming scheme and link to documentation at `https://svelte.dev/e/<code>`.

| Code | Raised by | Trigger |
|---|---|---|
| `css_selector_invalid` | `RelativeSelector` | Leading combinator in a non-nested rule position |
| `css_global_invalid_placement` | `ComplexSelector` | `:global(...)` in the middle of a selector chain |
| `css_global_block_invalid_placement` | `ComplexSelector` | Bare `:global` nested inside another pseudo-class |
| `css_global_invalid_selector` | `ComplexSelector` | Multi-selector `:global(...)` used in a compound context |
| `css_global_invalid_selector_list` | `ComplexSelector` | `:global(element)` not first in its compound selector |
| `css_type_selector_invalid_placement` | `ComplexSelector` | Type selector following `:global(.class)` |
| `css_global_block_invalid_modifier` | `Rule` | `:global` not at the start of its selector |
| `css_global_block_invalid_modifier_start` | `Rule`, `NestingSelector` | `:global x` compound at top level; `&` directly inside a `:global` block |
| `css_global_block_invalid_combinator` | `Rule` | Non-descendant combinator after `:global` in a global block |
| `css_global_block_invalid_list` | `Rule` | `:global, :global x { … }`; or mixing global-block with non-global-block selectors in one rule |
| `css_global_block_invalid_declaration` | `Rule` | Declarations directly inside a lone `:global { … }` |
| `css_nesting_selector_invalid_placement` | `NestingSelector` | `&` outside a nested rule (except sole selector of lone `:global`) |
| `css_unused_selector` *(warning)* | css-prune (`warn_unused`) | Selector never marked `used`; suppressible via `<!-- svelte-ignore css_unused_selector -->` |

---

## 7. End-to-End Process Flow

```mermaid
sequenceDiagram
    participant AN as analyze_component<br/>(compiler_analyzer)
    participant ACA as analyze_css<br/>(this module)
    participant W as zimmerframe walk
    participant PR as css-prune
    participant TX as CSS transform<br/>(compiler_css_pipeline_transform)

    Note over AN: template/JS visitors ran first,<br/>analysis.elements populated
    AN->>ACA: analyze_css(analysis.css.ast, analysis)
    ACA->>W: walk(stylesheet, css_state, css_visitors)

    loop each CSS node (depth-first)
        W->>ACA: visitor(node, context)
        ACA->>ACA: validate :global usage (throw on error)
        ACA->>ACA: populate node.metadata flags
        ACA->>ACA: collect keyframes / has_global
    end

    ACA-->>AN: metadata populated

    loop each element in analysis.elements
        AN->>PR: prune(stylesheet, element)
        PR->>PR: match selectors, set ComplexSelector.metadata.used
    end
    AN->>PR: warn_unused(stylesheet) unless svelte-ignore css_unused_selector
    PR-->>AN: unused-selector warnings

    AN-->>TX: ComponentAnalysis with CSS metadata
    TX->>TX: read metadata: is_global_block, used,<br/>keyframes, has_global<br/>scope + prune + rename, emit CSS
```

---

## 8. Key Invariants and Edge Cases

- **Two-phase `used` marking.** `analyze_css` pre-marks `used = true` only for *global* selectors; local selectors get their `used` flag during `prune`, when selectors are matched against actual template elements. `warn_unused` then reports whatever remains unmarked.
- **Ordering matters.** Within `Rule`, the prelude is visited *before* the block so `ComplexSelector.metadata` is populated before child rules rely on it; `ComplexSelector` visitors run children-first so `RelativeSelector` flags exist before aggregation.
- **Shared keyframes array.** `CssState.keyframes` aliases `analysis.css.keyframes`, so `Atrule` pushes are visible to the rest of the compiler without copying.
- **Vendor-prefixed keyframes** (`@-webkit-keyframes`) are handled transparently via `remove_css_prefix`.
- **Selectors after a bare `:global`** in a global-block compound are marked `is_global_like` and `used` (CSS preprocessors may expand `:global { x, y { … } }` into `:global x, :global y { … }`), so the lone-`:global` list check (`css_global_block_invalid_list`) distinguishes *intended* outputs from accidental constraints.
- **`:has` boundaries.** `:root:has(.x)` is deliberately *not* global-like — arguments of `:has(...)` (and `:is/:where/:not`, per `is_unscoped_pseudo_class`) must still be scoped.
- **Nested global reference case.** `&:hover` nested under `:global(.foo)` is marked used even though it never matches a plain element path — it inherits the parent rule's global scope.

---

## 9. Dependencies and Related Modules

| Dependency | Kind | Notes |
|---|---|---|
| `zimmerframe` (`walk`) | external | AST traversal engine with path/State/`context.next()` semantics |
| [compiler_diagnostics](compiler_diagnostics.md) | errors | All `e.css_*` compile errors raised during validation |
| [compiler_types](compiler_types.md) | types | `AST.CSS.*` node shapes and their `/** @internal */ metadata` contract |
| [compiler_parser](compiler_parser.md) | upstream | Produces the `AST.CSS.StyleSheet` consumed here |
| [compiler_analyzer](compiler_analyzer.md) | host | `analyze_component` owns the `ComponentAnalysis`, invokes `analyze_css`, then runs css-prune |
| [compiler_css_pipeline_transform](compiler_css_pipeline_transform.md) | downstream | Consumes metadata; mirrors `is_in_global_block`; strips `:global` via `remove_global_pseudo_class` |
| `2-analyze/css/utils.js` | sibling | `is_global`, `is_unscoped_pseudo_class` — the `:global` classification primitives reused here |

---

## 10. Extension Notes

- **Adding a new placement rule** for `:global`/`&`: implement it in the relevant visitor (`Rule`, `ComplexSelector`, `RelativeSelector`, or `NestingSelector`) and add the message to `errors.js`/`warnings.js` in `compiler_diagnostics`, then regenerate the diagnostics templates (see the `process-messages` scripts in [svelte_build_tooling](svelte_build_tooling.md)).
- **New "unscoped by nature" selectors** (like `::view-transition*` or `:host`): extend the `is_global_like` detection in `RelativeSelector`; no transform changes should be needed since downstream code reads only metadata.
- **New at-rules** that carry component-scoped names: follow the `@keyframes` pattern — collect names in `Atrule` via `analysis.css.keyframes` (or a new state array) and let the transform perform renaming.
