# Context API (`context_api`)

## 1. Introduction & Purpose

The **context API module** implements Svelte's `setContext` / `getContext` / `hasContext` / `getAllContexts` primitives — the mechanism by which a component shares values with arbitrary descendants without threading props through every layer of the tree.

The module is intentionally duplicated across the two runtimes so that each platform gets the smallest possible surface area and the behavior each platform actually needs:

| File | Runtime | Responsibility |
|---|---|---|
| `packages/svelte/src/internal/client/context.js` | Client (browser / hydrate / mount) | Context maps **plus** the component-context stack that drives effects, legacy lifecycle bookkeeping and dev-mode metadata |
| `packages/svelte/src/internal/server/context.js` | Server (SSR) | A lean, synchronous context stack that also drains `onDestroy` callbacks |

Both files expose an **identical public contract** (the four context functions), which is why the rest of the system can consume them interchangeably depending on the entry point (`svelte` → client build, `svelte/server` → server build). The public entries (`packages/svelte/src/index-client.js`, `packages/svelte/src/index-server.js`) simply re-export these functions — see the [Public API Surface & Compatibility Layer](public_api.md) module.

> This module is a sub-module of *Cross-Runtime Platform Services (Shared Utilities, Flags & Context Injection)*, alongside `shared_runtime` (shared utilities and compiler/runtime flags).

## 2. Architecture Overview

```mermaid
flowchart TB
    subgraph Public["Public API Surface"]
        IC["index-client.js<br/>(re-exports)"]
        IS["index-server.js<br/>(re-exports)"]
    end

    subgraph Module["context_api (this module)"]
        CC["client/context.js<br/>setContext · getContext · hasContext · getAllContexts<br/>push · pop · add_svelte_meta · is_runes"]
        SC["server/context.js<br/>setContext · getContext · hasContext · getAllContexts<br/>push · pop"]
    end

    subgraph ClientRuntime["Reactive Runtime Engine (client)"]
        RT["runtime.js<br/>active_effect · active_reaction"]
        EF["reactivity/effects.js<br/>create_user_effect"]
        FLAGS["flags/index.js<br/>async_mode_flag · legacy_mode_flag"]
    end

    subgraph ServerRuntime["Component Rendering Backend (server)"]
        SIDX["server/index.js<br/>on_destroy queue"]
    end

    IC --> CC
    IS --> SC
    CC --> RT
    CC --> EF
    CC --> FLAGS
    SC --> SIDX

    CTX["Compiler Back-End<br/>(generated component code)"] -- "emits push()/pop() around<br/>every component body" --> Module
```

### 2.1 The component-context stack

The heart of the module is a **linked-list stack of frames**. The compiler-generated code for every component wraps its body in `push(...)` / `pop(...)` calls, so at any moment `component_context` (client) or `current_component` (server) points at the frame of the component that is *currently initializing*.

Each frame is a `ComponentContext` node:

```ts
type ComponentContext = {
  p: null | ComponentContext;        // parent frame
  c: null | Map<unknown, unknown>;   // lazily created context map
  e: null | Array<() => ...>;        // deferred effects (client only)
  s: Record<string, unknown>;        // props (legacy / dispatcher support)
  x: Record<string, any> | null;     // component exports
  l: null | {...};                   // legacy-mode bookkeeping (null ⇒ runes mode)
  function?: any;                    // DEV: the component function
};
```

The `p` (parent) chain is what gives the context API its "nearest ancestor" semantics: a context map is *seeded from* (copied from) the closest ancestor frame that has one, so child lookups naturally fall back to parent values.

```mermaid
flowchart TD
    A["Frame: App<br/>c = Map{ theme: 'dark' }"] --> B["Frame: Layout<br/>c = null"]
    B --> C["Frame: Sidebar<br/>c = Map{ theme: 'dark' }<br/><i>seeded from App</i>"]
    C --> D["Frame: MenuItem<br/>c = null"]

    style C fill:#e8f5e9,stroke:#2e7d32
    D -. "getContext('theme') walks up,<br/>finds Sidebar's seeded map" .-> C
```

### 2.2 Context-map inheritance model

A frame's context map is **not created eagerly**. It is built on first use (`getContext`, `setContext`, `hasContext` or `getAllContexts`) via `get_or_init_context_map`:

1. If no component is initializing → throw `lifecycle_outside_component` (context functions must run during component initialisation).
2. Otherwise, `frame.c ??= new Map(parent_context)` — lazily allocate the map, pre-populated with the nearest ancestor's map so inherited keys are visible and overridable locally (copy-on-write inheritance).

```mermaid
sequenceDiagram
    participant C as Component init
    participant F as setContext/getContext
    participant M as get_or_init_context_map
    participant P as get_parent_context

    C->>F: setContext(key, value)
    F->>M: get_or_init_context_map(name)
    alt frame.c already exists
        M-->>F: reuse map (??= memoized)
    else first access
        M->>P: walk p-chain for nearest map
        P-->>M: parent Map (or null)
        M-->>F: new Map(parent entries)
    end
    F->>F: map.set(key, value)
```

### 2.3 Client vs. server divergence

While the four public functions behave identically, the **frame machinery around them differs** because the runtimes differ:

| Concern | Client (`client/context.js`) | Server (`server/context.js`) |
|---|---|---|
| Frame type | Full `ComponentContext` (effects, props, exports, legacy state) | Minimal `{ p, c, d, function }` |
| `push()` extra work | Records props, legacy lifecycle slots, DEV component fn | DEV component fn only |
| `pop()` extra work | Flushes **deferred effects** via `create_user_effect`, stores exports, restores DEV component fn | Moves `onDestroy` callbacks into the shared `on_destroy` queue of `server/index.js` |
| `setContext` validation | In **async mode**, rejects calls after initialisation (outside init, inside a reaction, or on an already-run branch effect) → `set_context_after_init` error | None (SSR is synchronous) |
| Dev tooling | `dev_stack` linked list + `add_svelte_meta`, `dev_current_component_function` | DEV component fn only |
| Mode detection | `is_runes()` — decides runes vs. legacy for the current frame | n/a |

## 3. Sub-module Documentation

Detailed component-level documentation lives in the sub-module files:

- **[Context API — Client Runtime](context_api_client.md)** — `packages/svelte/src/internal/client/context.js`: the four context functions, the full `ComponentContext` push/pop lifecycle, async-mode validation of `setContext`, deferred-effect flushing in `pop`, dev-mode metadata (`add_svelte_meta`, `dev_stack`) and `is_runes()`.
- **[Context API — Server Runtime](context_api_server.md)** — `packages/svelte/src/internal/server/context.js`: the SSR implementation of the same four functions plus the minimal push/pop frames that integrate with the `on_destroy` queue.

## 4. Data Flow Through the System

```mermaid
sequenceDiagram
    autonumber
    participant Comp as Generated component code
    participant Ctx as context_api (push/pop)
    participant User as User component <script>
    participant Map as Context map

    Note over Comp: client: App(Foo) renders <Bar/> in <Foo/> slot
    Comp->>Ctx: push(props, runes, component_fn)
    Note over Ctx: new frame linked to parent
    User->>Ctx: setContext('user', user)
    Ctx->>Map: frame.c.set('user', user)
    User-->>Comp: render children
    Comp->>Ctx: pop(component)
    Note over Ctx: flush deferred effects (client)<br/>queue onDestroy (server)
    Note over Comp: child <Bar/> initialises
    Comp->>Ctx: push(props, runes, component_fn)
    User->>Ctx: getContext('user')
    Ctx->>Map: seeded map lookup → user
    Comp->>Ctx: pop(component)
```

### 4.1 Where each piece fits in the wider system

| Integration point | Module | How it connects |
|---|---|---|
| Compiler emits `push`/`pop` around component bodies | [Compiler Back-End (Client & Server Code Generation)](compiler_server_transform.md) | Generated client and server component code call this module's `push`/`pop` to establish the frame before running the component body |
| Public `setContext/getContext/...` re-exports | [Public API Surface & Compatibility Layer](public_api.md) | `index-client.js` / `index-server.js` re-export the four functions from this module |
| `active_effect`, `active_reaction`, effect flags | [Reactive Runtime Engine](client_runtime_core.md) | Client `setContext` inspects these to enforce async-mode timing rules; `pop` schedules deferred effects through `create_user_effect` |
| `on_destroy` queue | [Component Rendering Backends (Server SSR)](server_runtime_rendering_core.md) | Server `pop` forwards `onDestroy` callbacks collected during rendering |
| `async_mode_flag`, `legacy_mode_flag` | [Shared Runtime & Flags](shared_runtime_flags.md) | Gate async-mode validation and legacy-frame creation (`l`) in `push`, and the runes check in `is_runes()` |

## 5. Key Design Decisions

1. **Copy-on-write inheritance** — child context maps are seeded with the parent's entries. Reads of inherited keys work without any traversal at read time; writes never mutate the parent's map, so sibling subtrees stay isolated.
2. **Laziness** — frames carry `c: null` until a context function is actually called; components that don't use context never allocate a `Map`.
3. **Identical public contract, divergent internals** — the four functions have the same signature and semantics on both runtimes, allowing the compiler and the public API to be runtime-agnostic while each runtime implements what its execution model requires (reactive-effect timing rules on the client, plain synchronous maps on the server).
4. **Init-time-only enforcement** — both runtimes throw `lifecycle_outside_component` when a context function is called outside component initialisation; the client additionally enforces the stricter async-mode rule (`set_context_after_init`) because reactive updates can re-enter component code after initialisation, where context writes would produce non-deterministic inheritance.
5. **Dual purpose of the client stack** — on the client, the context stack is also the backbone for deferred effects, legacy `beforeUpdate/afterUpdate/onMount` bookkeeping (`l`), event-dispatcher support (`s`, `x`), and dev-mode stack traces (`dev_stack` via `add_svelte_meta`), keeping per-component state in one linked structure.
