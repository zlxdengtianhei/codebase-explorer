# Shared Runtime (`shared_runtime`)

## 1. Overview

`shared_runtime` is the **cross-runtime foundation layer** of Svelte's `internal` package. It contains the code that both the client runtime (`internal/client/**`) and the server runtime (`internal/server/**`) import *verbatim*, deliberately kept free of DOM- or SSR-specific assumptions:

| Unit | Files | Purpose |
|------|-------|---------|
| **Micro-utilities** | `internal/shared/utils.js` | Tiny general-purpose helpers plus cached references to global built-ins |
| **State snapshot cloning** | `internal/shared/clone.js` (+ `clone.test.ts`) | Deep-clone logic behind `$state.snapshot`, with dev-mode warning instrumentation |
| **Shared diagnostics** | `internal/shared/errors.js`, `internal/shared/warnings.js`, `internal/shared/validate.js` | Code-generated error/warning throwers and runtime validation gates shared by both rendering backends |
| **Mode flags** | `internal/flags/index.js` | Module-level singletons (`async_mode_flag`, `legacy_mode_flag`, `tracing_mode_flag`) that select runtime behavior at bootstrap |

### Design constraints

1. **Isomorphism** — every file must load and behave identically under Node (SSR) and the browser (hydration/CSR). Nothing here touches `document` or `window`.
2. **Tree-shakeability** — helpers are small, named ESM exports so bundlers can drop unused pieces of the runtime.
3. **Prod/dev duality** — diagnostics are gated on `DEV` from `esm-env`: development builds emit rich messages with names, explanations and `https://svelte.dev/e/<code>` links; production builds throw only the URL.
4. **Monkey-patch resilience** — `utils.js` captures references to `Array`/`Object` built-ins once at module scope so the runtime cannot be de-optimized by user code reassigning globals.
5. **Generated code** — `errors.js` and `warnings.js` are *generated* by `scripts/process-messages/index.js` (see [Repository Engineering Infrastructure](repository_engineering_infrastructure.md)); their headers read `/* This file is generated ... Do not edit! */`.

---

## 2. Architecture

```mermaid
flowchart TB
    subgraph shared_runtime ["shared_runtime (this module)"]
        UTILS["utils.js<br/>noop · run · run_all · to_array<br/>deferred · fallback · is_promise<br/>cached globals (is_array, get_descriptor…)"]
        CLONE["clone.js<br/>snapshot · clone"]
        CLONE_T["clone.test.ts<br/>capture_warnings (test helper)"]
        ERRORS["errors.js (generated)<br/>invalid_default_snippet<br/>await_outside_boundary · lifecycle_outside_component…"]
        WARN["warnings.js (generated)<br/>dynamic_void_element_content<br/>state_snapshot_uncloneable…"]
        VALIDATE["validate.js<br/>validate_dynamic_element_tag<br/>validate_void_dynamic_element<br/>validate_store · prevent_snippet_stringification"]
        FLAGS["flags/index.js<br/>async_mode_flag · legacy_mode_flag<br/>tracing_mode_flag · enable/disable functions"]
    end

    ESMENV["esm-env<br/>(DEV constant)"]
    TOPUTILS["src/utils.js<br/>is_void"]
    PROXY["client/proxy.js<br/>proxy()"]

    VALIDATE --> ERRORS
    VALIDATE --> WARN
    VALIDATE --> TOPUTILS
    CLONE --> WARN
    CLONE_T --> CLONE
    CLONE_T -. tests .-> PROXY
    ERRORS --> ESMENV
    WARN --> ESMENV
```

### Internal dependency graph

```mermaid
graph LR
    V[validate.js] --> E[errors.js]
    V --> W[warnings.js]
    V --> U0["../../utils.js (is_void)"]
    C[clone.js] --> W
    CT[clone.test.ts] --> C
    E --> DEV[esm-env]
    W --> DEV
    FL[flags/index.js] --> READERS["read by proxy.js,<br/>context.js, effects,<br/>runtime.js …"]
```

Notes on the edges:

- `validate.js` re-exports `invalid_default_snippet` from `errors.js` and pulls `is_void` from the top-level `src/utils.js` (void-element lookup: `VOID_ELEMENT_NAMES` plus `!doctype`).
- `clone.test.ts` is the executable specification of `clone.js`; its `capture_warnings()` helper swaps `console.warn` to assert the exact dev-mode warnings emitted by `snapshot()` (including the `state_snapshot_uncloneable` path-list truncation rules).
- `flags/index.js` depends on nothing — it is the *most depended-upon* file in the runtime.

### Consumers across the system

```mermaid
flowchart TB
    subgraph shared
        UTILS["shared/utils.js"]
        DIAG["shared/errors.js · validate.js"]
        FLAGS["flags/index.js"]
        CLONE["shared/clone.js"]
    end

    CRC["Reactive Runtime Engine<br/>client_runtime_core<br/>(runtime.js, proxy.js, deriveds, props, stores)"]
    CDV["client_dev_mode<br/>(hmr, inspect, tracing, assign)"]
    CDR["Component Rendering Backends<br/>client_dom_renderer (blocks, elements,<br/>bindings, hydration)"]
    SSR["server_runtime<br/>(render core, blocks, payload)"]
    CTX["context_api<br/>(client/server context.js)"]
    PUB["Public API / compiled output<br/>$state.snapshot · store_get · snippet render"]

    UTILS --> CRC
    UTILS --> CDR
    UTILS --> SSR
    DIAG --> CDR
    DIAG --> SSR
    DIAG --> PUB
    FLAGS --> CRC
    FLAGS --> CDV
    FLAGS --> CTX
    CLONE --> PUB
```

Typical importers:

- **Reactivity core** (`runtime.js`, `proxy.js`, `props.js`, `store.js`) uses the cached globals, `noop`, `run`, `run_all`, `deferred`, `fallback`, `to_array` and reads `legacy_mode_flag`/`tracing_mode_flag`/`async_mode_flag` to switch between reactive strategies.
- **DOM renderer & SSR** call the shared validators when rendering `<svelte:element>`, snippets, stores and slots, and throw the shared errors on contract violations.
- **Context API** (`context_api` module) checks `async_mode_flag` inside `setContext` to forbid context creation after initialization.
- **Public API**: `$state.snapshot` is the user-facing surface of `clone.js`; `validate_store` backs the `store_get`/`$store` auto-subscription path.

---

## 3. Sub-modules

> **Documentation map for this module**
> - [shared_runtime.md](shared_runtime.md) — this overview (architecture, consumers, lifecycle)
> - [shared_runtime_utilities.md](shared_runtime_utilities.md) — micro-utilities (`utils.js`) and `$state.snapshot` cloning (`clone.js`, `clone.test.ts`)
> - [shared_runtime_diagnostics.md](shared_runtime_diagnostics.md) — generated errors/warnings (`errors.js`, `warnings.js`) and runtime validation gates (`validate.js`)
> - [shared_runtime_flags.md](shared_runtime_flags.md) — bootstrap mode flags (`flags/index.js`)

The module splits cleanly into three sub-modules, each documented separately:

### 3.1 [shared_runtime_utilities](shared_runtime_utilities.md) — micro-utilities & state snapshotting

`internal/shared/utils.js` and `internal/shared/clone.js` + its test suite `clone.test.ts`.

- **`utils.js`** — general-purpose helpers used pervasively:
  - *Cached built-ins* (`is_array`, `get_descriptor`, `get_prototype_of`, `object_prototype`, …) captured at load time for performance and monkey-patch safety.
  - `noop`, `run`, `run_all` — trivial but hot-path helpers used by the effect/batch machinery.
  - `deferred()` — a `Promise.withResolvers` polyfill (pending/resolver triplet) used by async primitives and batching.
  - `fallback(value, fallback, lazy)` — `undefined` coalescing, optionally lazy.
  - `to_array(value, n)` — safe array-destructuring support: returns arrays unchanged, uses `Array.from` for non-iterables/rest elements, and *stops after `n` items* for unbounded iterables (e.g. `let [a, b] = $derived(iterable)`).
- **`clone.js` / `clone.test.ts`** — `snapshot()` deep-clones reactive state: unwraps `$state` proxies, preserves cycles via memo `Map`, honors `toJSON`, returns plain objects/arrays; in `DEV` it collects the paths of uncloneable members and warns `state_snapshot_uncloneable` with a truncated path list (7 shown + “...and N more” when >10). `capture_warnings()` in the test spies on `console.warn` to pin down that output exactly.

### 3.2 [shared_runtime_diagnostics](shared_runtime_diagnostics.md) — shared errors, warnings & validation

`internal/shared/errors.js`, `internal/shared/warnings.js` (both generated) and the hand-written `internal/shared/validate.js`.

- **`errors.js`** — fatal-contract throwers shared by both runtimes: `invalid_default_snippet` (`{@render children(...)}` vs `let:` directives), `await_outside_boundary`, `invalid_snippet_arguments`, `lifecycle_outside_component(name)`, `snippet_without_render_tag`, `store_invalid_shape(name)`, `svelte_element_invalid_this_value`. All are `@returns {never}` and switch message richness on `DEV`.
- **`warnings.js`** — non-fatal `console.warn` diagnostics (`dynamic_void_element_content`, `state_snapshot_uncloneable`, …), same generated DEV/prod shape.
- **`validate.js`** — eager validation gates invoked by compiler-emitted code:
  - `validate_dynamic_element_tag(tag_fn)` — throws when `<svelte:element this={...}>` resolves to a non-string truthy value.
  - `validate_void_dynamic_element(tag_fn)` — warns when a resolved dynamic tag is a void element yet has children.
  - `validate_store(store, name)` — duck-types stores (must expose `subscribe`).
  - `prevent_snippet_stringification(fn)` — patches `fn.toString` so accidentally interpolating a snippet throws `snippet_without_render_tag` instead of stringifying its source.

### 3.3 [shared_runtime_flags](shared_runtime_flags.md) — runtime mode flags

`internal/flags/index.js` — three module-scoped booleans flipped **once at bootstrap** and read synchronously everywhere afterwards:

| Flag | Enabled by | Governs |
|------|------------|---------|
| `async_mode_flag` | `enable_async_mode_flag()` (compiler-emitted entry code) | async `<svelte:boundary>`/`await` semantics, `setContext` init rules |
| `legacy_mode_flag` | `enable_legacy_mode_flag()` | legacy (Svelte 4 style) reactivity paths, e.g. `invalidate_inner_signals` |
| `tracing_mode_flag` | `enable_tracing_mode_flag()` | dev-only stack capture in signals/proxies (`$inspect.trace`, ownership debug) |

`disable_async_mode_flag()` exists **for tests only**. Flags intentionally have no disable paths for the other two modes — a Svelte app runs in exactly one mode per bundle.

---

## 4. Lifecycle: how shared_runtime participates in a render

```mermaid
sequenceDiagram
    participant App as Compiled app entry
    participant Flags as flags/index.js
    participant Gen as Compiler-emitted component code
    participant Val as shared/validate.js
    participant RT as Runtime (client/server)
    participant U as shared/utils.js

    App->>Flags: enable_legacy_mode_flag() / enable_async_mode_flag()
    Note over Flags: one-time mode selection
    App->>RT: mount(component, opts) / SSR render
    Gen->>Val: validate_dynamic_element_tag(() => tag)
    Val->>RT: throws shared error (DEV: rich message / prod: URL)
    Gen->>Val: validate_store(store, name)
    RT->>U: run_all(cleanups) · deferred() · to_array(...)
    RT->>Flags: read async/legacy/tracing flags (sync reads, hot path)
```

Failure semantics are uniform: every shared validator either returns silently (valid) or raises through `errors.js`/`warnings.js`, so both rendering backends report identical codes and docs URLs.

---

## 5. Relationship to other modules

- [context_api](context_api.md) — the sibling sub-module of *Cross-Runtime Platform Services*; both `client/context.js` and `server/context.js` consume `flags/index.js` and mirror the same `setContext/getContext/hasContext/getAllContexts` surface.
- [client_runtime_core](client_runtime_core.md) — signal/effect/batch machinery; largest consumer of `utils.js` helpers and all three flags. Dev-mode instrumentation (ownership, tracing, HMR) lives under [client_dev_mode](client_dev_mode.md).
- [client_dom_renderer](client_dom_renderer.md) and [server_runtime_rendering_core](server_runtime_rendering_core.md) — invoke the shared validators/throwers while rendering elements, snippets and stores.
- [client_runtime_core_proxies](client_runtime_core_proxies.md) — `$state` proxies created by `proxy()` are the *input* that `clone.js`'s `snapshot()` must unwrap; `proxy.js` also reads `tracing_mode_flag`.
- [reactive_builtin_classes](reactive_builtin_classes.md) / stores (`fromStore`, `toStore`) — validated at runtime via `validate_store`.
- [svelte_build_tooling](svelte_build_tooling.md) — the `process-messages` templates that *generate* `errors.js`/`warnings.js` in this module.

## 6. Invariants & maintenance notes

- **Never edit `errors.js`/`warnings.js` by hand** — regenerate via `scripts/process-messages`; message *codes* are stable API (`https://svelte.dev/e/<code>` links appear in prod stacks).
- **Keep `shared/` DOM-free** — anything needing `document` belongs in `internal/client`, anything needing Node streams in `internal/server`.
- **Flags are write-once at bootstrap**; runtime code must treat them as constants after module init. Only `disable_async_mode_flag` may lower a flag, and only in tests.
- **`to_array` is intentionally bounded** when a rest element is *not* involved (`n` provided) — this prevents infinite loops on unbounded iterables during destructuring.
- **Snapshot warnings are path-addressed** (`<value>.a`, `<value>.c[3]`) and capped (7 + overflow count) to keep dev consoles usable; `clone.test.ts` locks this formatting in.
