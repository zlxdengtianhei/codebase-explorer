# compiler_server_transform_elements

## Overview

`compiler_server_transform_elements` is the element-rendering sub-module of the Svelte server-side (SSR) transform. It contains the AST visitors that convert **element-like template nodes** — static HTML elements, dynamic elements (`<svelte:element>`), raw-HTML tags (`{@html}`), document-level constructs (`<svelte:head>`, `<title>`), slot plumbing (`<slot>`, `<svelte:fragment>`) and spread attributes (`{...props}`) — into JavaScript code that emits HTML strings into the `$$payload` output buffer at runtime.

The module lives in `packages/svelte/src/compiler/phases/3-transform/server/visitors/` and runs as **phase 3 of 3** in the compiler, after parsing (see [Compiler_Front-End_(Parsing,_Analysis___CSS_Scoping_Pipeline).md](Compiler_Front-End_(Parsing,_Analysis___CSS_Scoping_Pipeline).md)) has produced an analyzed, scope-annotated AST. Its output is a component function body that pushes string fragments and calls into `svelte/internal/server` helpers, consumed by the [server_runtime](server_runtime.md).

**Source files:**

| File | Exported visitor | Template node handled |
|---|---|---|
| `RegularElement.js` | `RegularElement` | `AST.RegularElement` (e.g. `<div>`, `<svg>`) |
| `SvelteElement.js` | `SvelteElement` | `AST.SvelteElement` (`<svelte:element this={tag}>`) |
| `HtmlTag.js` | `HtmlTag` | `AST.HtmlTag` (`{@html expr}`) |
| `SvelteHead.js` | `SvelteHead` | `AST.SvelteHead` (`<svelte:head>`) |
| `TitleElement.js` | `TitleElement` | `AST.TitleElement` (`<title>`) |
| `SlotElement.js` | `SlotElement` | `AST.SlotElement` (`<slot>`) |
| `SvelteFragment.js` | `SvelteFragment` | `AST.SvelteFragment` (`<svelte:fragment>`) |
| `SpreadAttribute.js` | `SpreadAttribute` | `AST.SpreadAttribute` (`{...expr}`) |

## Module Position in the Compiler Pipeline

All visitors in this module are registered in the `template_visitors` map of `transform-server.js`, which drives a `zimmerframe` walk over the analyzed component AST. Dispatch is purely type-driven: when the walker encounters a node whose `type` matches a visitor key, that visitor is invoked with a `ComponentContext` (walker context exposing `context.visit`, `context.state`, `context.path`).

```mermaid
flowchart TB
    subgraph Compiler["Svelte Compiler Pipeline"]
        direction TB
        P["Phase 1: Parse<br/>(template state machine + Acorn JS parse)"]
        A["Phase 2: Analyze<br/>(scopes, CSS scoping, validation)"]
        T["Phase 3: Transform"]
    end

    subgraph ServerTransform["Server Transform (transform-server.js)"]
        direction TB
        GV["global_visitors<br/>(JS-level: Identifier,<br/>AssignmentExpression, ...)"]
        TV["template_visitors<br/>(template-level)"]
        subgraph THIS["compiler_server_transform_elements (this module)"]
            RE["RegularElement"]
            SE["SvelteElement"]
            HT["HtmlTag"]
            SH["SvelteHead"]
            TE["TitleElement"]
            SLE["SlotElement"]
            SF["SvelteFragment"]
            SA["SpreadAttribute"]
        end
        OTHERS["siblings:<br/>pipeline / control_flow /<br/>components / javascript"]
    end

    RUNTIME["svelte/internal/server<br/>(server_runtime module)<br/>$.element, $.slot, $.head, $.html, ..."]

    P --> A --> T
    T --> GV & TV
    TV --> THIS
    TV -.-> OTHERS
    THIS -->|"emits calls"| RUNTIME
    OTHERS -.-> RUNTIME
```

For the full orchestration, visitor dispatch, and the shared helpers (`process_children`, `build_template`, `build_attribute_value`, `clean_nodes`, `build_element_attributes`) that all server visitors share, see [compiler_server_transform_pipeline.md](compiler_server_transform_pipeline.md). This document focuses on the element-specific logic only.

## Architecture and Component Relationships

### Visitor composition

Every element visitor follows the same contract: it receives an AST node plus a `ComponentContext` and appends output fragments to `context.state.template` (an array of ESTree literals, expressions and statements), initialization statements to `context.state.init`, and may visit child nodes recursively. The shared helpers do the heavy lifting:

```mermaid
graph TD
    subgraph Visitors["This module's visitors"]
        RE[RegularElement]
        SE[SvelteElement]
        TE[TitleElement]
        SLE[SlotElement]
        SH[SvelteHead]
        HT[HtmlTag]
        SF[SvelteFragment]
        SA[SpreadAttribute]
    end

    subgraph Shared["Shared helpers (compiler_server_transform_pipeline)"]
        BEA["build_element_attributes<br/>build_spread_object<br/>(shared/element.js)"]
        PC["process_children<br/>build_template<br/>build_attribute_value<br/>empty_comment<br/>(shared/utils.js)"]
    end

    subgraph TransformUtils["Phase utils (3-transform/utils.js)"]
        CN[clean_nodes]
        NS[determine_namespace_for_children]
    end

    subgraph DevInfra["Compiler infrastructure"]
        B["builders (#compiler/builders)<br/>b.literal / b.call / b.stmt ..."]
        LOC["locator + dev flag<br/>(compiler/state.js)"]
        ISVOID["is_void<br/>(compiler/utils.js)"]
    end

    subgraph Runtime["svelte/internal/server (server_runtime)"]
        EL[$.element]
        HEAD[$.head]
        SLOT[$.slot]
        HTML[$.html]
        ATTR[$.attr / $.clsx / $.escape]
        VO[$.valueless_option / $.maybe_selected]
        PE[$.push_element / $.pop_element]
        VAL[$.validate_dynamic_element_tag<br/>$.validate_void_dynamic_element]
        SP[$.spread_props / $.stringify]
    end

    RE --> BEA & PC & CN & NS & B & LOC & ISVOID
    SE --> BEA & B & LOC & NS
    TE --> PC & B
    SLE --> PC & B
    SH --> B
    HT --> B
    SF -->|"visits fragment"| PC
    SA -->|"returns spread expr"| BEA

    BEA --> ATTR & VO & SP
    RE & SE --> EL
    SH --> HEAD
    SLE --> SLOT
    HT --> HTML
    RE & SE --> PE
    SE --> VAL
```

### State & context model

Visitors do not hold global state — all state flows through the walker:

- **`ComponentContext`** — the `zimmerframe` context; provides `context.visit(node, state?)`, `context.state` and `context.path` (ancestor chain).
- **`ComponentServerTransformState`** — carries the `template` array (ordered output fragments), `init` array (hoisted statements), the current `namespace` (`html` | `svg` | `mathml`), `preserve_whitespace`, the analysis object (including the CSS `hash` for scoping) and `options` (`preserveComments`, `dev`, ...). Visitors routinely derive **new state objects** (`{ ...context.state, template: [] }`) for isolated sub-outputs, merging them back afterwards.
- **Scope evaluation** — `process_children` uses `state.scope.evaluate(expr)` to constant-fold known-static expressions directly into output strings.

## Data Flow: From AST Node to HTML Payload

The core data flow of every element visitor is a three-stage pipeline: **AST → template array → payload statements**.

```mermaid
flowchart LR
    subgraph Stage1["1. AST traversal"]
        NODE["AST element node<br/>(RegularElement, SvelteElement,<br/>SlotElement, ...)"]
    end

    subgraph Stage2["2. Template accumulation"]
        TPL["state.template array<br/>- b.literal('&lt;div class=...')<br/>- b.call('$.attr', ...)<br/>- b.template([...], [...])<br/>- statements ($.slot, $.head ...)"]
        INIT["state.init<br/>(hoisted consts, dev checks)"]
    end

    subgraph Stage3["3. Template fusion"]
        BT["build_template(template)<br/>merges literals + expressions<br/>into '$$payload.out.push(...)'"]
        BLK["b.block([...init, ...template])<br/>returned by Fragment visitor"]
    end

    subgraph RuntimeOut["4. Runtime execution"]
        PAY["$$payload.out<br/>(string buffer assembled into<br/>the final HTML response)"]
    end

    NODE --> TPL
    TPL --> BT --> BLK --> PAY
    NODE --> INIT --> BLK
```

Key details of each stage:

1. **AST traversal** — `RegularElement` and `SvelteElement` first call `determine_namespace_for_children` to inherit/switch the namespace (`foreignObject` returns to `html`; `metadata.svg` / `metadata.mathml` set during analysis drive the choice).
2. **Template accumulation** — static text is HTML-escaped and inlined into string literals; dynamic expressions are wrapped in `$.escape(...)` or `$.stringify(...)` calls; attributes become `$.attr` calls or inline literals (optimization). Statements (e.g. `$.slot`, `$.head`) interleave with fragments.
3. **Template fusion** — `build_template` coalesces adjacent literals/expressions into a single tagged template passed to `$$payload.out.push(...)`, and assigns into a custom output target when told to (e.g. `TitleElement` writes to `$$payload.title` with the `=` operator).
4. **Runtime execution** — the generated `ServerComponent` function is invoked by the SSR renderer (see [server_runtime.md](server_runtime.md) and [Component_Rendering_Backends_(Client_DOM___Server_SSR).md](Component_Rendering_Backends_(Client_DOM___Server_SSR).md)); `$$payload.out` is joined into the HTTP response, and `$$payload.head` collects `<svelte:head>` content separately.

## Visitor Reference

### `RegularElement` — static HTML elements

The most complex visitor in the module. Given an `AST.RegularElement` it produces the literal tag markup and delegates children/attribute edge cases:

1. **Namespace & whitespace state** — derives the child namespace and sets `preserve_whitespace` for `<pre>` / `<textarea>`.
2. **Opening tag** — pushes `<name`, then `build_element_attributes` emits attributes, then closes with `/>` for void elements (XHTML compliance) or `>`.
3. **Raw-text fast path** — `<script>`/`<style>` with a single text child push the raw text and closing tag directly (no escaping, no child processing).
4. **Node cleanup** — `clean_nodes` splits children into `hoisted` (const tags, debug tags, `<svelte:head>`, `<title>`, snippets, body/window/document — which must render *before* the element body) and `trimmed` (whitespace-normalized content, honoring HTML quirks for `select`/`table` elements and the leading-newline rule of `<pre>`). Hoisted nodes are visited immediately.
5. **Dev instrumentation** — in dev mode, `$.push_element($$payload, name, line, column)` / `$.pop_element()` bracket the element for the ownership-validation stack (see `server/dev.js` in [server_runtime.md](server_runtime.md)).
6. **`<select>` value plumbing** — if the select has spreads or a `value` attribute/binding, `$$payload.select_value` is assigned so nested `<option>`s can compute their `selected` state via `$.maybe_selected`; the value is reset (`= undefined`) after the element closes.
7. **Body resolution** — three mutually exclusive strategies:
   - `<option>` **without** a value attribute → wrap children in `$.valueless_option($$payload, () => { ...children })` so the option's value is derived from its text content;
   - **attribute-driven body** (textarea `value` / contenteditable bindings, returned as `content` by `build_element_attributes`) → emit `if (body) { out.push(body) } else { ...children }` so bindings override markup content only when truthy;
   - **default** → `process_children(trimmed, ...)`.
8. **Closing tag** — `</name>` unless void.

```mermaid
flowchart TD
    START([RegularElement node]) --> NS["determine_namespace_for_children<br/>+ preserve_whitespace (pre/textarea)"]
    NS --> OPEN["push literal '&lt;name'"]
    OPEN --> ATTRS["build_element_attributes<br/>(returns body expr or null)"]
    ATTRS --> CLOSEOPEN{"void element?"}
    CLOSEOPEN -->|yes| VOID["push '/&gt;'"]
    CLOSEOPEN -->|no| GT["push '&gt;'"]
    VOID & GT --> RAW{"script/style with<br/>single text child?"}
    RAW -->|yes| FASTPATH["push raw text + closing tag, return"]
    RAW -->|no| CLEAN["clean_nodes → hoisted + trimmed"]
    CLEAN --> HOIST["visit hoisted nodes"]
    HOIST --> DEV1{"dev mode?"}
    DEV1 -->|yes| PUSH["$.push_element(name, line, col)"]
    DEV1 -->|no| SEL
    PUSH --> SEL{"&lt;select&gt; with<br/>value / spreads?"}
    SEL -->|yes| SV["$$payload.select_value = ..."]
    SEL -->|no| BODY
    SV --> BODY{"body resolution"}
    BODY -->|"option without value"| VO["$.valueless_option(children)"]
    BODY -->|"textarea/contenteditable body"| COND["if (body) out.push(body)<br/>else children"]
    BODY -->|default| PROC["process_children(trimmed)"]
    VO & COND & PROC --> RESET["reset select_value if used"]
    RESET --> ENDTAG{"void?"}
    ENDTAG -->|no| CLOSE["push '&lt;/name&gt;'"]
    ENDTAG -->|yes| DEV2
    CLOSE --> DEV2{"dev?"}
    DEV2 -->|yes| POP["$.pop_element()"]
    DEV2 -->|no| DONE([done])
    POP --> DONE
```

### `SvelteElement` — dynamic elements (`<svelte:element>`)

Because the tag name is only known at runtime, no literal markup can be emitted. Instead the visitor generates a single runtime call:

```js
// generated shape
$.element($$payload, tag, () => { /* attributes */ }, () => { /* children */ });
```

1. Visits `node.tag`; in dev mode **memoizes** the tag expression into a `$$tag` const when it is not a plain identifier (ensuring getters/function calls are evaluated once).
2. Dev-only validations are hoisted into `init`: `$.validate_void_dynamic_element` (rejected when a void element has children) and `$.validate_dynamic_element_tag` (rejects non-string tags) — both from `internal/shared/validate.js`.
3. Attributes and children are rendered into **local** `template`/`init` arrays (isolated state), then each non-empty block is wrapped in a thunk.
4. The runtime `element` helper wraps the output in `<!---->` hydration boundaries and closes/omits void tags automatically.

```mermaid
sequenceDiagram
    participant V as SvelteElement visitor
    participant W as zimmerframe walk
    participant R as svelte/internal/server

    V->>W: context.visit(node.tag)
    W-->>V: tag expression
    Note over V: dev: memoize into $$tag const<br/>hoist validate_void_dynamic_element /<br/>validate_dynamic_element_tag
    V->>V: build_element_attributes into local state
    V->>W: context.visit(node.fragment)
    W-->>V: children block
    V->>V: emit $.element(payload, tag,<br/>attributes_thunk?, children_thunk?)
    Note over R: at SSR time: pushes <!---->,<br/><tag ...>, children, </tag>, <!---->
```

### `HtmlTag` — raw HTML injection (`{@html expr}`)

The simplest visitor: visits the expression and pushes `$.html(expression)` into the template. At runtime the `html` block helper flushes the evaluated string verbatim into the payload (the analysis phase guarantees it appears in a valid position; see [compiler_server_transform_control_flow.md](compiler_server_transform_control_flow.md) for how surrounding blocks anchor it).

### `SvelteHead` — `<svelte:head>`

Visits the fragment into a block and emits:

```js
$.head($$payload, ($$payload) => { /* fragment */ });
```

The runtime `head` helper redirects writes into `payload.head`, so head content is collected out-of-band and can be injected into the document shell later. Note that `clean_nodes` also hoists `SvelteHead` nodes out of regular element bodies so they are visited during the *hoisted* pass — head content is emitted before the element's inline content.

### `TitleElement` — `<title>`

Builds a private template `['<title>', ...children, '</title>']` (children are guaranteed to be text/expression tags only, enforced during analysis). Instead of pushing to `$$payload.out`, the fused template is **assigned**:

```js
$$payload.title = `<title>${...}</title>`;
```

via `build_template(template, b.id('$$payload.title'), '=')`. Like `SvelteHead`, `TitleElement` nodes are hoisted by `clean_nodes`.

### `SlotElement` — `<slot>`

Converts slot metadata into a runtime dispatch:

```mermaid
flowchart LR
    subgraph Attributes["slot attributes"]
        NAME["name=... → slot name<br/>(default: 'default')"]
        SLOTATTR["slot=... → ignored<br/>(parent positioning only)"]
        OTHER["other Attribute → props"]
        SPREAD["{...expr} → spreads"]
    end

    PROPS["props expression:<br/>{ ... } or<br/>$.spread_props([{...}, ...spreads])"]
    FALLBACK["fallback:<br/>null | () => { ...fragment }"]
    CALL["$.slot($$payload, $$props,<br/>name, props, fallback)"]

    NAME & OTHER & SPREAD --> PROPS
    PROPS & FALLBACK --> CALL
    CALL --> OUT["template.push(empty_comment,<br/>stmt, empty_comment)"]
```

Design points:

- The `slot` attribute is skipped because slot *placement* is a property of the parent component's markup, not of the slot definition.
- The fallback (default content) becomes a **thunk** so it is only evaluated when the consumer provides no matching snippet.
- At runtime, `$.slot` resolves `$$props.$$slots[name]` with **snippet interop** (`slot_fn === true` falls back to the `children`/named snippet prop), then calls it with the payload and props, or runs the fallback.
- The output is bracketed by `empty_comment` (`<!-- -->`) fragments to prevent adjacent text from fusing across the slot boundary (important for hydration).

### `SvelteFragment` — `<svelte:fragment>`

Renders its fragment inline: `context.state.template.push(context.visit(node.fragment))`. The fragment visitor's returned block is appended directly into the surrounding template. Slot prop scoping (`let:` directives) is handled by the analysis phase's scope machinery ([compiler_analyzer_scope](compiler_analyzer_scope.md)), so no extra code is needed here.

### `SpreadAttribute` — `{...expr}`

A pure pass-through: returns `context.visit(node.expression)`. It never pushes to the template itself; its result is consumed by attribute-building logic — `build_spread_object` embeds it as a `SpreadElement` inside the object literal that feeds `$.spread_props` (or, for `<select>`, into the spread object whose `.value` initializes `$$payload.select_value` in `RegularElement`). This indirection keeps the visitor trivial while the *combination* semantics live in the shared pipeline helpers.

## Emitted Runtime Contract

Generated code assumes the `$` namespace (aliased `svelte/internal/server`) is imported. This module's visitors can emit the following calls:

| Emitted call | Runtime source | Purpose |
|---|---|---|
| `$.element(payload, tag, attrFn?, childFn?)` | `internal/server/index.js` | Dynamic element with hydration comment boundaries |
| `$.head(payload, fn)` | `internal/server/index.js` | Redirect output into `payload.head` |
| `$.slot(payload, $$props, name, props, fallbackFn)` | `internal/server/index.js` | Slot/snippet resolution with fallback |
| `$.html(expr)` | `internal/server/blocks/html.js` | Verbatim HTML injection |
| `$.attr(name, value, isBoolean?)`, `$.attr_class`, `$.attr_style` | `internal/server/index.js` | Escaped attribute rendering |
| `$.clsx(expr)` | `internal/server/index.js` | Conditional class merging (`class:` directives) |
| `$.escape(str)` / `$.stringify(value)` | `internal/server/index.js` | HTML-escape text / stringify dynamic attribute values |
| `$.spread_props(array)` | `internal/server/index.js` | Merge `{...spread}` attribute objects |
| `$.valueless_option(payload, fn)` / `$.maybe_selected(payload, value)` | `internal/server/index.js` | `<option>` value derivation & `selected` computation inside `<select value>` |
| `$.push_element(...) / $.pop_element()` | `internal/server/dev.js` | Dev-mode element stack for ownership validation |
| `$.validate_dynamic_element_tag(thunk)` / `$.validate_void_dynamic_element(thunk)` | `internal/shared/validate.js` | Dev-mode `<svelte:element>` checks (shared services — see [Cross-Runtime_Platform_Services_(Shared_Utilities,_Flags___Context_Injection).md](Cross-Runtime_Platform_Services_(Shared_Utilities,_Flags___Context_Injection).md)) |

## Cross-Module Dependencies

```mermaid
graph LR
    subgraph Frontend["Compiler Front-End"]
        PARSE["compiler_parser"]
        ANALYZE["compiler_analyzer<br/>(scopes, metadata.svg/mathml,<br/>expression metadata)"]
        CSS["compiler_css_pipeline<br/>(css hash → scoped class attr)"]
    end

    subgraph Backend["Compiler Back-End"]
        PIPE["compiler_server_transform_pipeline<br/>(walk, Fragment, shared helpers)"]
        ELEMENTS["compiler_server_transform_elements<br/>(this module)"]
        CF["compiler_server_transform_control_flow"]
        CC["compiler_server_transform_components"]
        CJ["compiler_server_transform_javascript"]
    end

    subgraph Runtime["Runtime"]
        SSR["server_runtime"]
        FLAGS["shared_runtime (flags/validation)"]
    end

    PARSE --> ANALYZE --> PIPE
    ANALYZE --> CSS --> PIPE
    PIPE --> ELEMENTS
    ELEMENTS --> CF & CC & CJ
    CF & CC --> ELEMENTS
    ELEMENTS --> SSR
    ELEMENTS --> FLAGS
```

- **Upstream (analysis)**: element nodes arrive with pre-computed metadata — `metadata.svg`/`mathml` for namespace decisions, `metadata.scoped` + the CSS hash for scoped-class injection (see [compiler_css_pipeline.md](compiler_css_pipeline.md)), and `metadata.expression` for fine-grained reactivity flags (irrelevant on the server but part of the shared AST, defined in [compiler_types](compiler_types)).
- **Peer visitors**: `clean_nodes` hoists `ConstTag`/`DebugTag`/snippet nodes, which are then re-dispatched to [compiler_server_transform_control_flow.md](compiler_server_transform_control_flow.md) and [compiler_server_transform_components.md](compiler_server_transform_components.md) visitors. `process_children` recursively dispatches arbitrary child nodes (blocks, components, elements) through the same walker.
- **Downstream (runtime)**: all emitted `$.*` calls are implemented by [server_runtime](server_runtime.md); dev-mode validations by [Cross-Runtime_Platform_Services_(Shared_Utilities,_Flags___Context_Injection).md](Cross-Runtime_Platform_Services_(Shared_Utilities,_Flags___Context_Injection).md).
- **Mirrored logic**: the client counterpart for elements lives in [compiler_client_transform_elements_and_directives](compiler_client_transform_elements_and_directives) (see also [compiler_client_transform.md](compiler_client_transform.md)); behavioral parity (hydration-compatible output, void-element handling, select/option semantics) between the two is enforced by the shared test suites.

## Design Notes & Invariants

- **No literal markup for dynamic tags**: `SvelteElement` must never inline the tag name, since it can change between renders (and even during one render in dev); memoization in dev prevents double evaluation of tag getters.
- **XHTML-friendly output**: void elements are self-closed (`/>`) so server output is parseable by stricter tooling.
- **Whitespace fidelity**: `clean_nodes` preserves inter-text whitespace as single spaces and keeps whitespace around expression tags verbatim, matching client-side hydration expectations (`white-space: pre-line` behaves consistently).
- **Hydration boundaries**: `<!---->` comment pairs (via runtime `element`/`html` helpers and `empty_comment` in `SlotElement`) delimit ownership of output regions so the client hydrator can claim nodes; the lone-`<script>` special case in `clean_nodes` adds a comment so the client's `run_scripts` can always `replaceWith` the script node.
- **Dev-only code is additive**: all `$.push_element` / validation emissions are guarded by the `dev` compile flag and never appear in production output (see [svelte_build_tooling](svelte_build_tooling) for treeshakeability checks that keep these helpers out of prod bundles).
- **State immutability style**: visitors derive new state objects rather than mutating shared ones; isolated `template`/`init` arrays (e.g. in `SvelteElement`, `TitleElement`, `valueless_option`) are folded back with `build_template` at explicit merge points.

## See Also

- [compiler_server_transform_pipeline.md](compiler_server_transform_pipeline.md) — walk orchestration, `Fragment`, shared attribute/child/template helpers
- [compiler_server_transform_control_flow.md](compiler_server_transform_control_flow.md) — `if`/`each`/`await`/`key` blocks and boundary handling
- [compiler_server_transform_components.md](compiler_server_transform_components.md) — component, snippet and render-tag emission (counterpart of `<slot>` output)
- [compiler_server_transform_javascript.md](compiler_server_transform_javascript.md) — JS-node rewriting in server output
- [Compiler_Back-End_(Client___Server_Code_Generation).md](Compiler_Back-End_(Client___Server_Code_Generation).md) — full back-end overview (client vs server targets)
- [server_runtime.md](server_runtime.md) — implementation of the `$.*` helpers emitted by this module
- [Compiler_Front-End_(Parsing,_Analysis___CSS_Scoping_Pipeline).md](Compiler_Front-End_(Parsing,_Analysis___CSS_Scoping_Pipeline).md) — how element nodes and their metadata are produced
