# Compiler Types — Compiler API Type Contracts (`compiler_types_compiler_api`)

## 1. Introduction

The `compiler_types_compiler_api` module is the **public type contract layer** of the Svelte compiler. Implemented in `packages/svelte/src/compiler/types/index.d.ts`, it defines the *shapes exchanged across the compiler's public boundary* — the value returned by `compile()` / `compileModule()` (`CompileResult`), the diagnostic types surfaced to tooling (`CompileError`, `Warning`), and the full configuration surface (`CompileOptions`, `ModuleCompileOptions` and their validated counterparts).

Where the sibling AST modules ([compiler_types_template_ast](compiler_types_template_ast.md), [compiler_types_css_ast](compiler_types_css_ast.md), [compiler_types_legacy_ast](compiler_types_legacy_ast.md)) model *what a Svelte program looks like*, this module models *what the compiler itself looks like to its consumers*: its inputs (options), its outputs (JS + CSS code, sourcemaps, warnings, metadata, AST), and its failure modes (errors). It is the single file that bundler plugins (e.g. `vite-plugin-svelte`), IDE tooling, and the compiler entry points all agree upon.

### Module Identity

| Attribute | Value |
|---|---|
| File | `packages/svelte/src/compiler/types/index.d.ts` |
| Parent group | `compiler_types` → `Compiler_Infrastructure_(Core_Orchestration,_Diagnostics___AST_Type_Model)` |
| Core exports | `CompileResult`, `CompileError`, `OptimizeOptions` |
| Supporting exports | `Warning`, `CssHashGetter`, `CompileOptions`, `ModuleCompileOptions`, `ValidatedCompileOptions`, `ValidatedModuleCompileOptions`, `BindingKind`, `DeclarationKind`, `ExpressionMetadata`, `StateField` |
| Re-exports | `*` from `./template.js`, `Binding`/`Scope` from `../phases/scope.js`, `ReactiveStatement` from `../phases/types.js` |

---

## 2. Core Type Contracts

### 2.1 `CompileResult`

The return value of `compile()` from `svelte/compiler` (and the analogue produced by `compileModule()`). Everything a downstream tool consumes from a compilation is packaged here:

```ts
interface CompileResult {
    js: {
        code: string;      // The generated code
        map: SourceMap;    // magic-string SourceMap
    };
    css: null | {
        code: string;
        map: SourceMap;
        hasGlobal: boolean; // whether the CSS includes global rules
    };
    warnings: Warning[];
    metadata: {
        runes: boolean;    // whether compiled in runes mode (always true for compileModule)
    };
    ast: any;              // public AST (legacy-shaped unless modernAst: true)
}
```

Key semantics:

- **`js` is always present** — generated client or server code (see [compiler_client_transform](compiler_client_transform.md) and [compiler_server_transform](compiler_server_transform.md)). With `generate: false`, the code is empty; the result is still useful to tooling that only wants warnings.
- **`css` is `null`** when the component has no styles or CSS is emitted externally by the bundler pipeline ([compiler_css_pipeline](compiler_css_pipeline.md)).
- **`metadata.runes`** reports the *effective* mode, whether forced by `runes: true`, or inferred from rune usage.
- **`ast`** is attached by the compiler entry (`compile()`), converted through `to_public_ast(source, parsed, options.modernAst)` — with `modernAst: true` it matches the node interfaces in [compiler_types_template_ast](compiler_types_template_ast.md); otherwise the legacy-shaped tree of [compiler_types_legacy_ast](compiler_types_legacy_ast.md) is returned for Svelte 4 tooling compatibility.

### 2.2 `Warning` and `CompileError` — the diagnostic contract

Both are *structural aliases* of `ICompileDiagnostic` (the interface published by the `CompileDiagnostic` class in [compiler_diagnostics_diagnostic_model](compiler_diagnostics_diagnostic_model.md)):

```ts
export interface Warning extends ICompileDiagnostic {}
export interface CompileError extends ICompileDiagnostic {}
```

`ICompileDiagnostic` guarantees the serialized shape (per `CompileDiagnostic.toJSON()`):

| Field | Meaning |
|---|---|
| `code` | Stable message identifier (e.g. `css_unused_selector`, `block_unclosed`) drawn from the message catalogs in [compiler_diagnostics_errors](compiler_diagnostics_errors.md) / [compiler_diagnostics_warnings](compiler_diagnostics_warnings.md) |
| `message` | Human-readable description |
| `filename` | Source file (omitted when unknown) |
| `start` / `end` | `{ line, column, character }` location objects |
| `position` | `[startChar, endChar]` character offsets |
| `frame` | Code frame excerpt produced by `get_code_frame()` |

The difference is **delivery, not structure**:

- A **`Warning`** is *collected*: appended to `CompileResult.warnings`, filtered through `ModuleCompileOptions.warningFilter`, and subject to suppression via `svelte-ignore` comments (maintained by the `push_ignore` / `pop_ignore` stack in [compiler_core_state](compiler_core_state.md)).
- A **`CompileError`** is *thrown*: instances of the runtime `CompileDiagnostic` class (or legacy error objects) abort compilation. Tooling typically catches it and reads `e.code`, `e.start`, `e.frame` for reporting.

### 2.3 `OptimizeOptions`

A forward-looking hook for output optimization flags:

```ts
export interface OptimizeOptions {
    hydrate?: boolean;
}
```

It exists so consumers can express intent about the *optimized runtime path* independently of `generate`. It is part of this module's core trio (`CompileError`, `CompileResult`, `OptimizeOptions`) even though most real configuration flows through `CompileOptions`.

### 2.4 `CompileOptions` and `ModuleCompileOptions`

`ModuleCompileOptions` is the base shared by both entry points (`compile` and `compileModule`):

```ts
interface ModuleCompileOptions {
    dev?: boolean;                     // dev-mode runtime checks/debug info
    generate?: 'client' | 'server' | false;
    filename?: string;                 // sourcemaps/debug hints (set by bundler plugins)
    rootDir?: string;                  // prevents leaking filesystem paths
    warningFilter?: (warning: Warning) => boolean;
    experimental?: { async?: boolean }; // since 5.36: await in deriveds/templates/top-level
}

interface CompileOptions extends ModuleCompileOptions {
    name?: string;                     // output class name (inferred from filename)
    customElement?: boolean;           // emit custom element constructor
    accessors?: boolean;               // @deprecated — no effect in runes mode
    namespace?: Namespace;             // 'html' | 'svg' | 'mathml' (from template.js)
    immutable?: boolean;               // @deprecated — no effect in runes mode
    css?: 'injected' | 'external';
    cssHash?: CssHashGetter;           // scoped-class naming strategy
    preserveComments?: boolean;
    preserveWhitespace?: boolean;
    fragments?: 'html' | 'tree';       // DOM cloning strategy (CSP/trusted-types aware), since 5.33
    runes?: boolean | undefined;       // force/infer runes mode
    discloseVersion?: boolean;
    compatibility?: { componentApi?: 4 | 5 }; // temporary migration shim
    sourcemap?: object | string;       // preprocessor sourcemap to merge
    outputFilename?: string;
    cssOutputFilename?: string;
    hmr?: boolean;
    modernAst?: boolean;               // return template.d.ts-shaped AST
}
```

`Namespace` is imported from [compiler_types_template_ast](compiler_types_template_ast.md), tying the options surface to the AST namespace model.

**Validation** is performed by [compiler_core_options](compiler_core_options.md) (`validate-options.js`), whose combinator builders (`object`, `string`, `boolean`, `fun`, `list`, `deprecate`, `removed`, `warn_removed`) turn raw user input into `ValidatedCompileOptions` / `ValidatedModuleCompileOptions`, emitting `CompileError`s (e.g. `options_removed_enable_sourcemap`, `options_renamed_ssr_dom` — see [compiler_diagnostics_warnings](compiler_diagnostics_warnings.md)) for outdated keys:

```ts
// "required but possibly undefined" shapes produced by validation
type ValidatedModuleCompileOptions = Omit<Required<ModuleCompileOptions>, 'rootDir'> & { rootDir: ModuleCompileOptions['rootDir'] };
type ValidatedCompileOptions = ValidatedModuleCompileOptions &
    Omit<Required<CompileOptions>, /* keys that may stay undefined */...> & {
        name: CompileOptions['name'];
        /* ...explicitly optional keys preserved... */
        compatibility: Required<Required<CompileOptions>['compatibility']>;
        runes: CompileOptions['runes'];
        customElementOptions: AST.SvelteOptions['customElement']; // merged from <svelte:options>
        hmr: CompileOptions['hmr'];
    };
```

Note that `ValidatedCompileOptions.customElementOptions` is where inline `<svelte:options customElement={...}>` (parsed into `AST.Root.options`, see [compiler_types_template_ast](compiler_types_template_ast.md)) is merged over external options by the entry point in [compiler_core_entry](compiler_core_entry.md).

### 2.5 `CssHashGetter`

Strategy hook for scoping class names produced by the CSS pipeline ([compiler_css_pipeline](compiler_css_pipeline.md)):

```ts
type CssHashGetter = (args: {
    name: string;
    filename: string;
    css: string;
    hash: (input: string) => string;
}) => string;   // default: `svelte-${hash(css)}`
```

### 2.6 Analyzer vocabulary: `BindingKind`, `DeclarationKind`, `ExpressionMetadata`, `StateField`

These types are the compiler-internal vocabulary consumed by the scope system ([compiler_analyzer_scope](compiler_analyzer_scope.md)) and re-exported here so transforms ([compiler_client_transform](compiler_client_transform.md), [compiler_server_transform](compiler_server_transform.md)) and external tooling share one source of truth:

- **`BindingKind`** classifies every binding the analyzer discovers: `normal`, `prop`, `bindable_prop`, `rest_prop`, `raw_state`, `state`, `derived`, `each`, `snippet`, `store_sub`, `legacy_reactive`, `template`, `static`.
- **`DeclarationKind`** records how a binding was declared: `var | let | const | function | import | param | rest_param | synthetic`.
- **`ExpressionMetadata`** captures per-expression reactivity analysis used to decide what must be wrapped in effects/deriveds:

```ts
interface ExpressionMetadata {
    dependencies: Set<Binding>;  // bindings referenced eagerly
    references: Set<Binding>;    // all bindings, incl. inside functions
    has_state: boolean;
    has_call: boolean;           // often ⇒ wrap in derived
    has_await: boolean;          // experimental async support
    has_member_expression: boolean;
    has_assignment: boolean;
}
```

- **`StateField`** describes a class field created by `$state`/`$derived` runes (`type: StateCreationRuneName`, plus its `PropertyDefinition | AssignmentExpression` node, `key` and `value` call), consumed during class-body transforms ([compiler_client_transform_state_and_reactivity](compiler_client_transform_state_and_reactivity.md)).

### 2.7 Re-exported symbols

```ts
export * from './template.js';                      // full template AST namespace (AST.Root, AST.RegularElement, ...)
export { Binding, Scope } from '../phases/scope.js';
export { ReactiveStatement } from '../phases/types.js'; // { assignments: Set<Binding>; dependencies: Binding[] }
```

`Binding` (class) and `Scope` come from the analyzer's scope engine; `ReactiveStatement` backs legacy `$:` handling. These re-exports make `types/index.d.ts` a one-stop import surface — `ExpressionMetadata.dependencies` is literally `Set<Binding>`, and `Binding.kind` is `BindingKind` *from this module*, closing the type loop.

---

## 3. Architecture

### 3.1 Type dependency graph

```mermaid
flowchart TD
    subgraph External
        MS[magic-string: SourceMap]
        EST[estree: AssignmentExpression<br/>CallExpression / PrivateIdentifier<br/>PropertyDefinition]
    end

    subgraph Compiler internal types
        DIAG[ICompileDiagnostic<br/><i>compiler_diagnostics_diagnostic_model</i>]
        TPL[template.d.ts: AST · Namespace<br/><i>compiler_types_template_ast</i>]
        SCOPE[scope.js: Binding · Scope<br/><i>compiler_analyzer_scope</i>]
        PHTYPES[phases/types.d.ts: ReactiveStatement]
        RUNE[utils.js: StateCreationRuneName]
    end

    subgraph THIS MODULE — types/index.d.ts
        WARNING[Warning]
        CERR[CompileError]
        RESULT[CompileResult]
        OPT[OptimizeOptions]
        CSSHASH[CssHashGetter]
        MCO[ModuleCompileOptions]
        CO[CompileOptions]
        VCO[ValidatedCompileOptions]
        VMCO[ValidatedModuleCompileOptions]
        BK[BindingKind]
        DK[DeclarationKind]
        EM[ExpressionMetadata]
        SF[StateField]
    end

    DIAG --> WARNING
    DIAG --> CERR
    WARNING --> RESULT
    MS --> RESULT
    TPL --> RESULT
    TPL --> CO
    TPL --> VCO
    SCOPE --> EM
    BK --> SCOPE
    DK --> SCOPE
    SCOPE --> PHTYPES
    EST --> SF
    RUNE --> SF
    MCO --> CO
    CO --> VCO
    VMCO --> VCO
    CSSHASH --> CO
```

### 3.2 Position within the compiler architecture

This module sits at the *contract hub* of the compiler infrastructure group. The implementation-side modules produce the values; this module describes them.

```mermaid
flowchart LR
    subgraph Consumers
        BP[Bundler plugins<br/>vite-plugin-svelte, etc.]
        IDE[IDE / language tooling]
        USERS[compile / compileModule callers]
    end

    subgraph Compiler Infrastructure
        ENTRY[compiler_core_entry<br/>compile / compileModule]
        VOPTS[compiler_core_options<br/>validate-options.js]
        DIAGS[compiler_diagnostics<br/>errors · warnings · diagnostic model]
    end

    subgraph Pipeline
        PARSE[compiler_parser]
        ANALYZE[compiler_analyzer]
        CSS[compiler_css_pipeline]
        CLIENT[compiler_client_transform]
        SERVER[compiler_server_transform]
    end

    TYPES[(compiler_types_compiler_api<br/>CompileResult · CompileError ·<br/>Warning · CompileOptions ·<br/>ValidatedCompileOptions)]

    USERS -- "CompileOptions (this module)" --> ENTRY
    ENTRY -- validate via --> VOPTS
    VOPTS -- "ValidatedCompileOptions (this module)" --> ANALYZE
    ENTRY --> PARSE --> ANALYZE
    ANALYZE --> CSS
    ANALYZE --> CLIENT
    ANALYZE --> SERVER
    DIAGS -- "Warning[] / throws CompileError" --> RESULT["CompileResult (this module)"]
    CLIENT & SERVER & CSS -- js / css fields --> RESULT
    RESULT -- returned to --> USERS
    TYPES -. read by .-> BP
    TYPES -. read by .-> IDE
```

---

## 4. Data Flow: how a `CompileResult` is produced

The component entry point (`compile()` in `packages/svelte/src/compiler/index.js`, documented in [compiler_core_entry](compiler_core_entry.md)) orchestrates the pipeline and assembles the value that `CompileResult` describes:

```mermaid
sequenceDiagram
    autonumber
    participant User as Tooling / Application
    participant Entry as compiler_core_entry (compile)
    participant VOpts as compiler_core_options (validate)
    participant Parse as compiler_parser
    participant Analyze as compiler_analyzer
    participant Trans as client/server/css transforms
    participant Diag as compiler_diagnostics

    User->>Entry: compile(source, CompileOptions)
    Entry->>VOpts: validate_component_options(options)
    VOpts-->>Entry: ValidatedCompileOptions<br/>(or throws CompileError)
    Entry->>Parse: _parse(source)
    Parse-->>Entry: AST.Root (+ inline AST.SvelteOptions)
    Note over Entry: merge inline <svelte:options> options<br/>into combined_options.customElementOptions
    Entry->>Analyze: analyze_component(parsed, source, options)
    Analyze->>Diag: push warnings (css_unused_selector, a11y_*)
    Analyze-->>Trans: analysis (Bindings, ExpressionMetadata, StateFields)
    Trans-->>Entry: { js, css, metadata, ast }
    Entry-->>User: CompileResult { js.code, css?, warnings, metadata.runes, ast }
```

For JS/TS modules, `compileModule()` follows the same pattern but with `ModuleCompileOptions` only (hence `metadata.runes` is always `true`).

### Diagnostic flow through the contract

```mermaid
flowchart TD
    SRC[Compiler phases detect issues] --> C{Severity?}
    C -->|warning| W[Warning object built from<br/>message catalogs]
    C -->|error| E[CompileError thrown]
    W --> F{warningFilter?}
    F -->|false| DROP[discarded]
    F -->|true| IG{inside svelte-ignore<br/>ignore_stack?}
    IG -->|yes| DROP2[suppressed]
    IG -->|no| RES[CompileResult.warnings]
    E --> X[compilation aborts —<br/>consumer reads code/start/frame]
```

The ignore stack manipulation (`push_ignore` / `pop_ignore`, see [compiler_core_state](compiler_core_state.md)) and code-frame rendering (`get_code_frame`, see [compiler_diagnostics_diagnostic_model](compiler_diagnostics_diagnostic_model.md)) are implementation details *behind* the `Warning`/`CompileError` shapes defined here.

---

## 5. Component Interaction Summary

| Contract (this module) | Produced / consumed by | Related module docs |
|---|---|---|
| `CompileOptions`, `ModuleCompileOptions` | Authored by callers; validated by `validate-options.js`; merged with inline `<svelte:options>` | [compiler_core_entry](compiler_core_entry.md) · [compiler_core_options](compiler_core_options.md) |
| `ValidatedCompileOptions`, `ValidatedModuleCompileOptions` | Output of option validation; threaded through analyze + transform phases | [compiler_core_options](compiler_core_options.md) · [compiler_analyzer](compiler_analyzer.md) |
| `Warning` | Emitted by analyze/CSS phases (`css_unused_selector`, a11y checks); filtered & returned | [compiler_diagnostics_warnings](compiler_diagnostics_warnings.md) · [compiler_css_pipeline](compiler_css_pipeline.md) |
| `CompileError` | Thrown by any phase (e.g. `block_unclosed`, `css_global_block_invalid_placement`) | [compiler_diagnostics_errors](compiler_diagnostics_errors.md) |
| `CompileResult.js` | Assembled from client/server transform output | [compiler_client_transform](compiler_client_transform.md) · [compiler_server_transform](compiler_server_transform.md) |
| `CompileResult.css` (+ `cssHash`, `css: 'injected' \| 'external'`) | Produced by the CSS scoping pipeline; scoping uses `CssHashGetter` | [compiler_css_pipeline](compiler_css_pipeline.md) |
| `CompileResult.ast` | `AST.Root` public projection; shape governed by `modernAst` | [compiler_types_template_ast](compiler_types_template_ast.md) · [compiler_types_legacy_ast](compiler_types_legacy_ast.md) |
| `BindingKind`, `DeclarationKind`, `ExpressionMetadata`, `StateField` | Filled during analysis; drive reactivity decisions in transforms | [compiler_analyzer_scope](compiler_analyzer_scope.md) · [compiler_client_transform_state_and_reactivity](compiler_client_transform_state_and_reactivity.md) |
| `Binding`, `Scope`, `ReactiveStatement` (re-exports) | Core analyzer data structures referenced throughout phases | [compiler_analyzer_scope](compiler_analyzer_scope.md) |
| `OptimizeOptions` | Optimization intent flags (`hydrate`) consumed by output tuning | [compiler_client_transform](compiler_client_transform.md) |

---

## 6. Usage Examples

### 6.1 Compiling with typed options

```ts
import { compile } from 'svelte/compiler';
import type { CompileOptions, CompileResult, Warning } from 'svelte/compiler'; // re-exported from this module

const options: CompileOptions = {
    filename: 'App.svelte',
    generate: 'client',
    css: 'external',
    dev: true,
    runes: true,
    warningFilter: (w: Warning) => w.code !== 'a11y_missing_attribute'
};

let result: CompileResult;
try {
    result = compile(source, options);
    console.log(result.js.code, result.metadata.runes); // true
} catch (e) {
    // CompileError — same diagnostic fields as Warning
    console.error(e.code, e.start, e.frame);
}
```

### 6.2 Custom scoped-class hashing

```ts
import type { CssHashGetter } from 'svelte/compiler';

const cssHash: CssHashGetter = ({ name, hash, css }) =>
    `${name}-${hash(css).slice(0, 6)}`;

compile(source, { cssHash });
```

### 6.3 Consuming validated options (internal tooling)

```ts
import type { ValidatedCompileOptions } from '../../compiler/types/index.js';
// After validate_component_options(): every key is required-except-explicitly-optional,
// and customElementOptions reflects merged <svelte:options>.
function configure(opts: ValidatedCompileOptions) { /* ... */ }
```

---

## 7. Maintenance Notes

- **Additive evolution**: `CompileResult` and `CompileOptions` are *public API*. New fields must be optional and documented with `@default` / `@since` tags (see `fragments` @since 5.33, `experimental.async` @since 5.36 as precedents).
- **Deprecation lifecycle**: legacy toggles (`accessors`, `immutable`) are marked deprecated and inert in runes mode; removal is handled by the `removed` / `warn_removed` validators in [compiler_core_options](compiler_core_options.md).
- **The `TODO this chain is a bit weird` comment** in the source acknowledges that re-exporting `ReactiveStatement` (a legacy-mode artifact) through the modern types surface is transitional — expect it to move once legacy `$:` support is isolated to [compiler_types_legacy_ast](compiler_types_legacy_ast.md).
- **AST duality**: `CompileResult.ast: any` is deliberate — with `modernAst: false` (Svelte 5 default) the tree is legacy-shaped; only with `modernAst: true` can tooling rely on the interfaces of [compiler_types_template_ast](compiler_types_template_ast.md). Svelte 6 flips the default; Svelte 7 removes the option.
- **Message codes** referenced by `Warning.code` / `CompileError.code` strings are generated from the catalogs in `scripts/process-messages/templates/` — see [compiler_diagnostics_errors](compiler_diagnostics_errors.md) and [compiler_diagnostics_warnings](compiler_diagnostics_warnings.md) for the code registry.
