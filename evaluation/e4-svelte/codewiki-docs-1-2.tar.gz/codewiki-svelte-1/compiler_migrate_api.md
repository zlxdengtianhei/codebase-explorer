# Compiler Migrate API (`compiler_migrate_api`)

> **Source:** `packages/svelte/src/compiler/migrate/index.js`
> **Parent module:** [compiler_migrate](compiler_migrate.md) · **Tooling group:** *Source Migration & Preprocessing Tooling*

## 1. Introduction

`compiler_migrate_api` is the public entry point of the Svelte **4 → 5 codemod engine**. It exposes a single exported function, [`migrate()`](#31-migratesource-options), which performs a *best-effort* rewrite of legacy Svelte components towards runes (`$state`, `$derived`, `$props`, `$bindable`), event attributes (`onclick` instead of `on:click`), snippets/`{@render ...}` tags instead of slots, and `svelte/legacy` fallbacks for anything that cannot be expressed in runes.

Unlike the compile pipeline (see [Compiler Front-End](Compiler_Front-End_(Parsing,_Analysis___CSS_Scoping_Pipeline).md) and [Compiler Back-End](Compiler_Back-End_(Client___Server_Code_Generation).md)), migration **stops after parse + analyze** — it never produces a `CompileResult`. Instead it re-emits *source text* using positional edits on a `MagicString` buffer, so formatting, comments and layout of the original file are preserved as much as possible.

Core components of this module:

| Component | Kind | Visibility | Purpose |
|---|---|---|---|
| `migrate(source, options)` | function | **exported** (also re-exported via `svelte/compiler`) | Runs the full migration pipeline and returns `{ code }` |
| `extract_type_and_comment(declarator, state, path)` | function | internal | Extracts a prop's type annotation and JSDoc comments when converting `export let` into a typed `$props()` declaration |

Everything else in the file (`State`, `MigrationError`, `migrate_css`, `instance_script` / `template` visitor maps, `handle_identifier`, `handle_events`, `migrate_slot_usage`, `trim_block`, `guess_indent`, `get_node_range`) supports these two functions and is documented here or in the sibling module [compiler_migrate_transformations](compiler_migrate_transformations.md).

---

## 2. Position in the System

```mermaid
flowchart TB
    subgraph Parent["compiler_migrate (parent module)"]
        API["compiler_migrate_api<br/>migrate() · extract_type_and_comment()"]
        TR["compiler_migrate_transformations<br/>handle_identifier · handle_events<br/>migrate_slot_usage · trim_block"]
        IG["compiler_migrate_svelte_ignore<br/>migrate_svelte_ignore()"]
        API -->|"drives visitors"| TR
        API -->|"rewrites svelte-ignore codes"| IG
    end

    subgraph Upstream["Compiler front-end (reused, read-only)"]
        P["compiler_parser<br/>parse()"]
        AN["compiler_analyzer<br/>analyze_component()"]
        SC["compiler_analyzer_scope<br/>get_rune() · Scope · Binding"]
        CORE["compiler_core<br/>reset() · validate_component_options()"]
        TYPES["compiler_types<br/>AST · SvelteNode types"]
    end

    subgraph Downstream["Consumers"]
        CLI["Migration CLI<br/>(svelte-migrate / sv migrate)"]
        LEG["legacy_compat<br/>svelte/legacy runtime"]
    end

    P -->|"AST"| API
    AN -->|"ComponentAnalysis"| API
    SC -->|"binding kinds"| API
    CORE -->|"state + option validation"| API
    TYPES -->|"AST node shapes"| API
    API -->|"{ code: migrated source }"| CLI
    TR -.->|"emits imports from svelte/legacy"| LEG

    style API fill:#e8f0fe,stroke:#1a73e8,stroke-width:2px
```

Key architectural properties:

1. **Reuses, but does not run, the compilation front-end.** `parse` ([compiler_parser](compiler_parser.md)) and `analyze_component` ([compiler_analyzer](compiler_analyzer.md)) give the migrator the same AST, scopes and binding kinds (`state`, `bindable_prop`, `store_sub`, `legacy_reactive`, …) that code generation would use — but the transform phase 3 is never invoked.
2. **Edit-buffer based, not AST-serializing.** All output is produced through `MagicString` `prepend/append/overwrite/remove/move/indent` operations keyed on AST `start`/`end` offsets, so untouched code stays byte-identical.
3. **Fail-soft contract.** The function never throws: any error (expected `MigrationError` or an unexpected crash) is converted into an `<!-- @migration-task ... -->` comment plus the original, unmodified source.

---

## 3. Public API

### 3.1 `migrate(source, options)`

```ts
function migrate(
  source: string,
  options?: { filename?: string; use_ts?: boolean }
): { code: string };
```

| Parameter | Type | Description |
|---|---|---|
| `source` | `string` | The Svelte component source to migrate. |
| `options.filename` | `string?` | Used for component-name generation, self-import synthesis (`svelte:self` → `import Name from './File.svelte'`), unique-name collision scope, and console diagnostics. |
| `options.use_ts` | `boolean?` | Prefer TypeScript output (`lang="ts"` + `interface Props`). Ignored (falls back to JSDoc) if the source already contains `@type {` JSDoc hints. The source's `<script lang="ts">` attribute always wins. |

**Returns** `{ code: string }` — the migrated source, or the original source prefixed with a migration-task comment if migration failed (see [§7](#7-error-handling--migration-tasks)).

**Side effects** — compiler-wide state is reset (`reset({ warning: () => false, filename })`, so *warnings are suppressed* while errors still throw), and up to two console messages may be emitted (`console.error` for unexpected failures, and a `console.log` reminder when `@migration-task` comments were inserted).

### 3.2 `extract_type_and_comment(declarator, state, path)`

```ts
function extract_type_and_comment(
  declarator: VariableDeclarator,
  state: State,
  path: AST.SvelteNode[]
): {
  type: string;
  comment?: string;
  trailing_comment?: string;
};
```

Resolves the *type* and *documentation* of an `export let x: T` declaration so the generated `$props()` declaration can be typed. Resolution order (first match wins):

1. **TS annotation** — `declarator.id.typeAnnotation` → type text after the `:`; sets `state.has_type_or_fallback = true`; the leading/trailing comment nodes are *removed from output* (`str.update(start, end, '')`) and returned raw.
2. **JSDoc on the export** — only when the parent is an `ExportNamedDeclaration` and its last leading comment contains `@type {T}`; type `T` is captured, and prose after a ` - ` separator becomes the description.
3. **Literal initializer inference** — `string` / `number` / `boolean` initializers map to the primitive type name (sets `has_type_or_fallback`).
4. **Fallback** — `type: 'any'`.

JSDoc comments are additionally *cleaned* for JS output: `/**`, `*`, `*/`, `//` decorations are stripped, and everything from the first `@tag` line onwards is dropped (only when `state.uses_ts` is `false`; TS output keeps the original comment text verbatim, since TS interfaces preserve comments anyway).

> The collected descriptors are consumed later by the `$props()` generator described in [§6.1](#61-props-declaration-generation).

---

## 4. Internal Architecture

### 4.1 `State` — the migration accumulator

A single mutable-ish state object is threaded through both walks (a shallow copy switches `scope` from the instance scope to the template scope between them):

| Field | Type | Purpose |
|---|---|---|
| `scope` | `Scope` | Current scope; instance scope during script walk, template scope during template walk. |
| `str` | `MagicString` | The positional edit buffer over the source. |
| `analysis` | `ComponentAnalysis` | Result of `analyze_component()` — scopes, bindings, `reactive_statements`, `uses_props` / `uses_rest_props` / `uses_slots`, `accessors`, `custom_element`, component `name`. |
| `filename` | `string?` | Drives self-imports and diagnostics. |
| `indent` | `string` | Guessed indentation unit (`'\t'` or `' '.repeat(min)`) via `guess_indent()`; used for all inserted code. |
| `props` | `Prop[]` | Collected prop descriptors `{ local, exported, init, bindable, slot_name?, optional, type, comment?, trailing_comment?, type_only?, needs_refine_type? }`. |
| `props_insertion_point` | `number` | Character offset where `$props()` / extra props are spliced (after last import, or inside an existing `$props()` destructure). |
| `has_props_rune` | `boolean` | An existing `$props()` was found → augment it instead of creating a new declaration. |
| `has_type_or_fallback` | `boolean` | Type information exists → emit a typed `Props` interface / `@typedef`. |
| `names` | `Record<string, string>` | Collision-free helper names generated from `analysis.root.unique()` — `props`, `rest`, `run`, `handlers`, `preventDefault`, `stopPropagation`, `stopImmediatePropagation`, `self`, `trusted`, `once`, `passive`, `nonpassive`, `createBubbler`, `bubble`. |
| `legacy_imports` | `Set<string>` | `svelte/legacy` exports needed (emits one aliased import statement). |
| `script_insertions` | `Set<string>` | Extra statements (e.g. `const bubble = createBubbler();`). |
| `derived_components` | `Map<string, string>` | Dynamic `<svelte:component this={expr}>` expressions hoisted into `const Name = $derived(expr)`. |
| `derived_conflicting_slots` | `Map<string, string>` | Slots whose rendered name would shadow a slot prop → `const x_render = $derived(x)`. |
| `derived_labeled_statements` | `Set<LabeledStatement>` | `$:` statements already consumed by a `$state`/`$derived` conversion (skipped by the generic `LabeledStatement` visitor). |
| `has_svelte_self` | `boolean` | `svelte:self` was rewritten → a self-import must be injected. |
| `uses_ts` | `boolean` | Output dialect decision: `lang="ts"` + interfaces vs. `@typedef`/`@type` JSDoc. |

### 4.2 Module-level helpers

| Helper | Role |
|---|---|
| `MigrationError` | Error subclass thrown for *expected* "cannot migrate this automatically" situations; silently converted into a migration task (no `console.error`). |
| `migrate_css(state)` | Rewrites the `<style>` block: for compound selectors `:has(...)`, `:is(...)`, `:where(...)` the inner selector is wrapped in `:global(...)` (Svelte 5 scoping semantics). `:not(...)` is skipped. Works on a scratch `MagicString` because the block was blanked earlier. |
| `find_closing_parenthesis(start, code)` | Balanced-paren scan used by `migrate_css`. |
| `guess_indent(content)` | Detects tabs vs. spaces from existing lines (tabs win ties). |
| `get_node_range(source, node)` | Start/end of a `$:` statement *including* its leading/trailing comments, extended left to the beginning of the line — used by reactive-statement reordering. |
| `has_migration_task` | Module-level flag, reset at each `migrate()` call, set when any task comment is produced; drives the `finally` reminder log. Because it is module state, concurrent `migrate()` calls must not interleave. |

The four template/script transformation functions (`handle_identifier`, `handle_events`, `migrate_slot_usage`, `trim_block`) and the visitor maps (`instance_script`, `template`) are specified in [compiler_migrate_transformations](compiler_migrate_transformations.md); this document only references their effects.

---

## 5. Migration Pipeline

`migrate()` executes the following strictly ordered pipeline:

```mermaid
flowchart TD
    A["migrate(source, options)"] --> B["Blank style contents<br/>regex_style_tags → style_placeholder"]
    B --> C["reset({ warning: no-op, filename })"]
    C --> D["parse(source)<br/>via compiler_parser"]
    D --> E["Merge parsed options + customElement<br/>+ validate_component_options defaults<br/>+ experimental.async: true"]
    E --> F["new MagicString(source)<br/>analyze_component() → analysis"]
    F --> G["Remove accessors from svelte:options<br/>restore style contents into buffer"]
    G --> H["Build State<br/>unique helper names, props, imports"]
    H --> I["context='module' → module attr rewrite"]
    I --> J["walk(instance.content, instance_script)"]
    J --> K["walk(fragment, template)"]
    K --> L{"need_script?<br/>legacy imports · derived maps ·<br/>script insertions · props · rest · svelte:self"}
    L -->|"yes, no instance script"| M["Insert &lt;script&gt; (or lang='ts')"]
    L -->|"no"| N["skip script scaffolding"]
    M --> O["svelte:self → inject self-import"]
    N --> O
    O --> P["Emit svelte/legacy import<br/>(aliased unique specifiers)"]
    P --> Q["Emit script_insertions<br/>(e.g. const bubble = createBubbler())"]
    Q --> R{"props to declare?"}
    R -->|"yes"| S["Generate $props() declaration<br/>TS interface or JSDoc typedef (§6.1)"]
    R -->|"no"| T["—"]
    S --> U{"reactive statements need reordering?"}
    T --> U
    U -->|"yes"| V["Move every $: block<br/>(with comments) to end of script"]
    U -->|"no"| W["—"]
    V --> X["Emit $derived consts<br/>(derived_components · derived_conflicting_slots)"]
    W --> X
    X --> Y{"analysis.accessors?"}
    Y -->|"yes"| Z["Re-export non-slot props"]
    Y -->|"no"| AA["—"]
    Z --> AB["Close injected script tag"]
    AA --> AB
    AB --> AC["migrate_css(state)<br/>wrap :has/:is/:where in :global()"]
    AC --> AD["return { code: str.toString() }"]
```

Notable semantics per step:

* **Style blanking (1).** `<style>` bodies (possibly SCSS/Less that the parser cannot read) are replaced by the `/*$$__STYLE_CONTENT__$$*/` placeholder before parsing and restored right after analysis, so CSS never blocks migration.
* **Options handling (4–5).** Parsed `<svelte:options>` attributes are merged over validated defaults; `experimental.async` is force-enabled so await-related analysis matches Svelte 5.
* **Visitor walks (10–11).** The instance walk performs all JS-level rewrites (`$state`, `$derived`, prop collection, `svelte-ignore` comment migration via [compiler_migrate_svelte_ignore](compiler_migrate_svelte_ignore.md)); the template walk performs slot→snippet and event-attribute rewrites ([compiler_migrate_transformations](compiler_migrate_transformations.md)).
* **`need_script` synthesis (12–13).** A component with no `<script>` but legacy requirements gets a fresh script block, positioned and closed around the inserted content; `lang="ts"` is appended when `uses_ts`.
* **Run-name guards.** Before emitting `$props`, `$state`, `$derived` or `$bindable` bindings, `check_rune_binding()` throws a `MigrationError` if the user already declared a variable with that name — a collision would silently break the migrated file.

---

## 6. Output Assembly (Code Generation by Splicing)

### 6.1 Props declaration generation

When `state.props` is non-empty (or `$$props`/`$$restProps` were used), the migrator emits a single `let { ... } = $props();` at `props_insertion_point`:

* **`$$props` present** → destructures `...{names.props}` and types it `{ [key: string]: any }`; every `$$props.x` / bindable-prop reference was already rewritten to `{names.props}.x` by `handle_identifier`.
* **Named props** → `exported: local` entries (renames preserved), each with `= init` defaults and `= $bindable(init)` for reassigned props; `$$restProps` presence appends `...{names.rest}`.
* **Existing `$props()`** (`has_props_rune`) → the extra entries (from render tags / forwarded events / slot inference) are spliced into the existing destructuring instead.
* **Typing** — a `Props` interface (TS) or `@typedef {Object} Props` with `@property` lines (JS) is emitted when `has_type_or_fallback` is set or every prop is a snippet (slot) prop; slot props get `import('svelte').Snippet` / `Snippet<[any]>` types (refined from `[any]` to `Snippet` when first actually rendered without parameters). `type_only` entries from a `$$Props` interface contribute types but no runtime names.
* **`accessors`** — legacy `accessors` option/components get an `export { ... }` re-export block for all non-slot, non-type-only props.

### 6.2 Legacy fallbacks

`$:` statements that are not pure derived expressions become `run(() => { ... })` with `run` imported from `svelte/legacy` (which wraps `$effect.pre` semantics — see [legacy_compat](legacy_compat.md)). Event directives without handlers become `bubble('name')` via `createBubbler()`. All generated names are aliased (`import { run as run_1 }`) when they collide with user code, using the unique names precomputed in `State.names`.

### 6.3 Reactive-statement reordering

Svelte 4 executed `$:` statements in *declaration order of their dependencies*; `$derived` and `$effect.pre` do not. The migrator inspects `analysis.reactive_statements`: if any statement reads a binding declared *after* it (or depends on props), **all** reactive statements are moved to the end of the instance script in their analysis-computed execution order, vacated lines are deleted (CRLF-aware), and leading/trailing comments travel with each block via `get_node_range()`.

---

## 7. Error Handling & Migration Tasks

```mermaid
flowchart TD
    TRY["migrate() body"] --> Q{"exception thrown?"}
    Q -->|"no"| OK["return { code: str.toString() }"]
    Q -->|"MigrationError<br/>(expected: unsupported pattern,<br/>rune-name collision, slot rename)"| FLAG
    Q -->|"any other error"| CE["console.error('Error while migrating Svelte code', e)"]
    CE --> FLAG["has_migration_task = true"]
    FLAG --> TASK["return { code:<br/>'&lt;!-- @migration-task Error while migrating Svelte code: msg --&gt;'<br/>+ original source }"]
    INLINE["In-place task comments<br/>(svelte:self without filename,<br/>invalid slot identifiers)"] --> FLAG
    OK --> FIN
    TASK --> FIN["finally: has_migration_task?<br/>console.log review reminder"]
```

Design rules:

* **Never throw.** The caller (migration CLI, batched over a codebase) always receives usable output.
* **Expected vs. unexpected.** `MigrationError` messages are embedded verbatim in the task comment and are *not* logged to `console.error`; unexpected bugs are logged and additionally produce the task wrapper.
* **Granular bail-outs.** Visitors insert *local* `@migration-task` comments (e.g. "migrate this slot by hand") while continuing to migrate the rest of the file, rather than aborting wholesale.

---

## 8. Component Interaction & Data Flow

```mermaid
sequenceDiagram
    participant CLI as Migration CLI
    participant M as compiler_migrate_api
    participant CP as compiler_parser
    participant CA as compiler_analyzer
    participant TR as compiler_migrate_transformations
    participant SI as compiler_migrate_svelte_ignore
    participant MS as MagicString

    CLI->>M: migrate(source, { filename, use_ts })
    M->>M: blank style blocks · reset() state
    M->>CP: parse(source)
    CP-->>M: AST (instance · module · fragment · css · options)
    M->>CA: analyze_component(ast, source, options)
    CA-->>M: ComponentAnalysis (scopes, bindings, reactive_statements)
    M->>MS: new MagicString(source)
    M->>TR: walk(instance.content, State, instance_script)
    TR->>SI: migrate_svelte_ignore(comment)
    TR->>MS: $state / $derived edits · prop collection · import pruning
    M->>TR: walk(fragment, State, template)
    TR->>MS: {#snippet} · {@render} · on:event → on* edits
    M->>M: assemble $props() · legacy import · reorder reactive statements
    M->>MS: migrate_css() :global wrapping
    M-->>CLI: { code }
```

Data flow summary:

```mermaid
flowchart LR
    S["Source string"] --> BL["style-blanked source"]
    BL --> AST["AST + options"]
    AST --> ANA["ComponentAnalysis<br/>scopes · bindings · reactive_statements"]
    ANA --> ST["State<br/>props · names · legacy_imports<br/>derived_* maps"]
    S --> MS["MagicString<br/>(offset-based edits)"]
    AST --> MS
    ST --> CG["Assembly step<br/>$props() · imports · reordering · $derived"]
    MS --> CG
    CG --> OUT["{ code: migrated source }"]
    OUT -->|"on failure"| TASK["{ code: @migration-task + original }"]
```

---

## 9. Dependencies

| Import | Source module | Used for |
|---|---|---|
| `MagicString` | external (`magic-string`) | Positional source edits |
| `walk`, `Visitors` | external (`zimmerframe`) | AST traversal shared with the analyzer |
| `parse` | [compiler_parser](compiler_parser.md) (`phases/1-parse/index.js`) | Produces the AST |
| `regex_valid_component_name` | [compiler_parser_template_state_machine](compiler_parser_template_state_machine.md) (`state/element.js`) | Validity check for `<svelte:component>` name rewrites |
| `analyze_component` | [compiler_analyzer](compiler_analyzer.md) (`phases/2-analyze/index.js`) | Scopes, binding kinds, `reactive_statements`, usage flags |
| `get_rune` | [compiler_analyzer_scope](compiler_analyzer_scope.md) (`phases/scope.js`) | Detects existing `$props` rune declarations |
| `reset`, `UNKNOWN_FILENAME` | [compiler_core_state](compiler_core_state.md) (`compiler/state.js`) | Compiler-wide state reset; warnings suppressed via no-op handler |
| `validate_component_options` | [compiler_core_options](compiler_core_options.md) (`validate-options.js`) | Baseline validated options object |
| `extract_identifiers`, `extract_all_identifiers_from_expression`, `is_text_attribute` | compiler utils (`utils/ast.js`) | Pattern/identifier analysis for `$:` rewriting |
| `migrate_svelte_ignore` | [compiler_migrate_svelte_ignore](compiler_migrate_svelte_ignore.md) | Rewrites `svelte-ignore a-b-c` codes to snake_case in comments |
| `is_reserved`, `is_svg`, `is_void` | compiler utils (`utils.js`) | Tag classification for self-closing expansion & slot names |
| `regex_is_valid_identifier` | compiler patterns (`phases/patterns.js`) | Slot-name validity for snippet conversion |
| `AST`, `Binding`, `ComponentAnalysis`, `Scope`, `CompileError`, `CompileResult` types | [compiler_types_template_ast](compiler_types_template_ast.md), [compiler_analyzer_scope](compiler_analyzer_scope.md), [compiler_types_compiler_api](compiler_types_compiler_api.md) | Type contracts only |

**Does *not* depend on:** phase-3 transforms ([compiler_client_transform](compiler_client_transform.md), [compiler_server_transform](compiler_server_transform.md)), the CSS transform pipeline ([compiler_css_pipeline](compiler_css_pipeline.md)), or the runtime — although its *output* references `svelte/legacy` ([legacy_compat](legacy_compat.md)) and `import('svelte').Snippet` types at *runtime in user code*, not at module load.

Sibling tooling: [compiler_preprocess](compiler_preprocess.md) addresses the same "non-standard syntax in components" problem for *compilation*, while this module addresses it for *migration* (hence the style-blanking strategy mirrors preprocessor behavior).

---

## 10. Usage Example

```js
import { migrate } from 'svelte/compiler';

const legacy = `
<script>
  export let name = 'world';
  let count = 0;
  $: doubled = count * 2;
</script>

<button on:click={() => count++}>
  {doubled}
  <slot />
</button>
`;

const { code } = migrate(legacy, { filename: 'App.svelte' });
// <script>
//   interface Props { name?: string; children?: import('svelte').Snippet }
//   let { name = 'world', children }: Props = $props();
//   let count = $state(0);
//   let doubled = $derived(count * 2);
// </script>
//
// <button onclick={() => count++}>
//   {doubled}
//   {@render children?.()}
// </button>
```

---

## 11. Related Documentation

* [compiler_migrate](compiler_migrate.md) — parent module overview and migration strategy
* [compiler_migrate_transformations](compiler_migrate_transformations.md) — the actual visitor logic (`handle_identifier`, `handle_events`, `migrate_slot_usage`, `trim_block`)
* [compiler_migrate_svelte_ignore](compiler_migrate_svelte_ignore.md) — `svelte-ignore` code renaming
* [compiler_parser](compiler_parser.md) / [compiler_analyzer](compiler_analyzer.md) — the reused front-end phases
* [compiler_core](compiler_core.md) — compiler state and option validation
* [compiler_diagnostics](compiler_diagnostics.md) — error/warning model (warnings suppressed during migration)
* [legacy_compat](legacy_compat.md) — the `svelte/legacy` runtime that migrated code imports
* [compiler_preprocess](compiler_preprocess.md) — related preprocessing tooling
