# svelte_build_tooling_message_templates

## Introduction

`svelte_build_tooling_message_templates` is the module that owns the **code-generation templates** for every diagnostic (error and warning) that the Svelte compiler and runtimes can emit. It lives at `packages/svelte/scripts/process-messages/templates/` and consists of seven deliberately "incomplete" JavaScript files, each containing placeholder symbols (`CODE`, `MESSAGE`, `PARAMETER`, `CODES`) instead of real diagnostics.

These templates are **not shipped or executed as-is**. They are consumed by the sibling generator script `scripts/process-messages/index.js`, which reads the human-authored message corpus from the `messages/` markdown directory and stamps out one concrete function per diagnostic code into the generated modules under `src/`:

| Template file | Generated output | Purpose |
| --- | --- | --- |
| `compile-errors.js` | `src/compiler/errors.js` | Thrown compile-time errors (`CompileError`) |
| `compile-warnings.js` | `src/compiler/warnings.js` | Buffered compile-time warnings (`CompileWarning`) |
| `client-errors.js` | `src/internal/client/errors.js` | Client runtime errors (DEV-gated) |
| `client-warnings.js` | `src/internal/client/warnings.js` | Client runtime warnings (DEV-gated) |
| `server-errors.js` | `src/internal/server/errors.js` | SSR runtime errors (always thrown) |
| `shared-errors.js` | `src/internal/shared/errors.js` | Errors shared by client & server runtimes |
| `shared-warnings.js` | `src/internal/shared/warnings.js` | Warnings shared by client & server runtimes |

Because every diagnostic in the entire package is funneled through these templates, the module is the single source of truth for the *shape* of Svelte diagnostics: message formatting, the `https://svelte.dev/e/<code>` documentation links, dev-mode gating, and the compile-time ignore/filter machinery.

> **Module position:** child of [svelte_build_tooling](svelte_build_tooling.md), sibling of [svelte_build_tooling_treeshakeability_checker](svelte_build_tooling_treeshakeability_checker.md), inside the Repository Engineering Infrastructure group.

---

## 1. Architecture Overview

The module sits between the human-authored message corpus and the generated source tree. Everything flows one way: markdown → generator → templates → generated modules → compiler/runtime call sites.

```mermaid
flowchart TB
    subgraph SOURCES["Authoring: messages/ markdown corpus"]
        MD["messages/&lt;category&gt;/*.md<br/>## sections: one per diagnostic code<br/>&gt;-quoted paragraphs = message variants"]
    end

    subgraph GEN["Generator (not this module)"]
        IDX["scripts/process-messages/index.js<br/>run(), transform(name, dest)"]
    end

    subgraph TPL["This module: templates/"]
        direction TB
        T1["compile-errors.js"]
        T2["compile-warnings.js"]
        T3["client-errors.js"]
        T4["client-warnings.js"]
        T5["server-errors.js"]
        T6["shared-errors.js"]
        T7["shared-warnings.js"]
    end

    subgraph OUT["Generated modules under src/"]
        O1["compiler/errors.js"]
        O2["compiler/warnings.js"]
        O3["internal/client/errors.js"]
        O4["internal/client/warnings.js"]
        O5["internal/server/errors.js"]
        O6["internal/shared/errors.js"]
        O7["internal/shared/warnings.js"]
    end

    subgraph DOCS["Reference documentation"]
        DOC["documentation/docs/98-reference/.generated/<br/>&lt;category&gt;.md"]
    end

    MD -->|"read + parse + validate"| IDX
    IDX -->|"parse with acorn, clone, substitute"| TPL
    T1 --> O1
    T2 --> O2
    T3 --> O3
    T4 --> O4
    T5 --> O5
    T6 --> O6
    T7 --> O7
    IDX --> DOC
    O1 --> COMP["Compiler phases<br/>(parse / analyze / transform)"]
    O2 --> COMP
    O3 --> CLI["Client runtime"]
    O4 --> CLI
    O5 --> SRV["Server runtime (SSR)"]
    O6 --> CLI
    O6 --> SRV
    O7 --> CLI
    O7 --> SRV
```

Key architectural properties:

- **Declarative, one-way pipeline.** Contributors edit markdown; the templates define structure; the generator merges the two. No diagnostic logic is ever hand-written in `src/`.
- **Template = scaffold + one placeholder function.** Each template contains boilerplate (imports, helper classes/functions) that is copied verbatim, plus exactly one `export function CODE(PARAMETER)` that the generator clones once per code.
- **Shared diagnostics hoisted to a shared template.** `client-errors.js` and `server-errors.js` both begin with `export * from '../shared/errors.js'`, so codes needed in both runtimes are defined once in `shared-errors.js` / `shared-warnings.js` and re-exported.

---

## 2. Template Anatomy and the Placeholder Contract

Every template follows the same pattern: static scaffolding followed by a JSDoc-commented placeholder export. For example, the compile-error template:

```js
// ...scaffolding: InternalCompileError class + e() helper ...

/**
 * MESSAGE                                  ← replaced with the message text
 * @param {null | number | NodeLike} node   ← kept verbatim
 * @param {string} PARAMETER                ← expanded into real @param lines
 * @returns {never}
 */
export function CODE(node, PARAMETER) {
    e(node, 'CODE', `${MESSAGE}\nhttps://svelte.dev/e/${'CODE'}`);
}
```

The generator (see `index.js`) recognizes and replaces the following placeholders:

| Placeholder | Appears as | Replaced with |
| --- | --- | --- |
| `CODE` | `export function CODE(...)`, `'CODE'` string literals | The diagnostic code, e.g. `block_unclosed` (function name and URL fragment) |
| `MESSAGE` | `Identifier` inside a template literal | A message `Literal`, a `TemplateLiteral` with `%var%` → identifier interpolation, or a nested `ConditionalExpression` chain for overload variants |
| `PARAMETER` | An `Identifier` in the parameter list / `@param` JSDoc line | One parameter per `%variable%` found in the message; JSDoc marks first-variant params `{string}`, later ones `{string \| undefined \| null} [name]` |
| `CODES` | `export const codes = CODES` (compile-warnings only) | An `ArrayExpression` of every warning code literal in the category |
| Leading JSDoc block | Block comment directly above the export | Cloned per code: `* MESSAGE` becomes the message text, `PARAMETER` expands into real `@param` lines |

The per-code JSDoc is also populated with the message itself, so the generated modules are self-documenting and IDE hover shows the exact diagnostic text.

---

## 3. The Generation Pipeline

The generator (`scripts/process-messages/index.js`, run from `packages/svelte/`) performs the following steps. It uses `acorn` to parse each template, `zimmerframe` to walk/rewrite the AST, and `esrap` (with the TypeScript printer) to emit code.

```mermaid
flowchart TD
    A["run() invoked (or messages/ changed in watch mode)"] --> B["Scan messages/&lt;category&gt;/*.md"]
    B --> C["Parse ## CODE sections;<br/>extract &gt;-quoted message paragraphs + trailing details"]
    C --> D{"Duplicate code<br/>anywhere?"}
    D -->|yes| E["Throw: Duplicate message code"]
    D -->|no| F["Sort sections alphabetically;<br/>rewrite source .md in place"]
    F --> G["Emit reference docs to<br/>documentation/docs/98-reference/.generated/&lt;category&gt;.md"]
    G --> H["For each of the 7 templates: transform(name, dest)"]
    H --> I["acorn.parse template; collect comments;<br/>replace Identifier CODES with code array"]
    I --> J["Locate export function CODE;<br/>detach it; remember its JSDoc"]
    J --> K["For each code in category:<br/>extract %var% set from each message variant"]
    K --> L{"Multiple variants<br/>(overloads)?"}
    L -->|yes| M["Build nested ConditionalExpression:<br/>each variant must introduce NEW params,<br/>else throw 'Message overloads must have new parameters'"]
    L -->|no| N["Message = Literal or single TemplateLiteral"]
    M --> O["Clone CODE node → rename to code,<br/>splice message expression into template literal,<br/>escape ` and \\${ in raw text"]
    N --> O
    O --> P["Synthesize per-code JSDoc<br/>(message text + typed @param list)"]
    P --> Q["esrap.print; prepend<br/>'This file is generated... Do not edit!' banner"]
    Q --> R["Write to src/... destination"]
    R --> S{"More codes?"}
    S -->|yes| K
    S -->|no| T{"More templates?"}
    T -->|yes| H
    T -->|no| U["Done"]
```

**Watch mode.** Invoking the script with `-w` enables `fs.watch('messages', { recursive: true })` with a small debounce (`running` flag + `setTimeout`), so editing any message markdown immediately regenerates all outputs. This tight loop is what makes the markdown corpus effectively the live source of the diagnostic texts.

**Determinism.** Section headers are re-sorted alphabetically in the source markdown, and codes are emitted in category order, so regenerating produces stable diffs and duplicate codes are rejected eagerly (`Duplicate message code <category>/<code>`).

---

## 4. Generated Behavior by Family

### 4.1 Compile-time errors (`compile-errors.js` → `src/compiler/errors.js`)

Scaffolding copied verbatim into the output:

- `InternalCompileError extends Error` — extends `Error` so bundler plugins and tooling recognize it, but delegates its entire shape to a [`CompileDiagnostic`](compiler_diagnostics_diagnostic_model.md) instance via `Object.assign`, so errors and warnings share one object shape. `stack` is blanked ("avoid unnecessary noise") and `name` is set to `'CompileError'`. It provides `toString()` (code frame rendering) and `toJSON()` for structured output.
- `e(node, code, message)` helper — accepts `null | number | NodeLike` (a raw offset or any AST node with `start`/`end`), normalizes the position to `[start, end ?? start]`, and throws. The generated functions are typed `@returns {never}`, giving the compiler dead-code-elimination-friendly control flow at call sites.

The compile diagnostics themselves (e.g. `block_unclosed`, `css_global_block_invalid_combinator`, `typescript_invalid_feature`) are documented in [compiler_diagnostics_errors](compiler_diagnostics_errors.md).

### 4.2 Compile-time warnings (`compile-warnings.js` → `src/compiler/warnings.js`)

- `InternalCompileWarning extends CompileDiagnostic` with `name = 'CompileWarning'` — warnings are plain data objects, never thrown.
- `w(node, code, message)` helper — the heart of the compile-time ignore system:
  1. Resolves the active ignore context: node-specific `ignore_map` entry (from `<!-- svelte-ignore code -->`-style annotations) falling back to the ambient `ignore_stack` (maintained by [`push_ignore` / `pop_ignore` in compiler state](compiler_core_state.md)).
  2. Skips the warning if the innermost ignore set contains `code`.
  3. Applies the user-supplied `warningFilter` option via `warning_filter`.
  4. Appends the surviving warning to the module-level `warnings` array, which is reset per compilation by `state.reset()` and surfaced on the final `CompileResult`.
- `export const codes = CODES` — the generator expands `CODES` into the full list of warning codes; used by tooling and tests to enumerate the warning surface.

The warning catalogue (e.g. `a11y_incorrect_aria_attribute_type_id`, `css_unused_selector`, `options_renamed_ssr_dom`) is documented in [compiler_diagnostics_warnings](compiler_diagnostics_warnings.md).

### 4.3 Runtime errors — client / server / shared

Three templates share one behavioral contract, differing only in *when* the verbose message is available:

| Family | DEV (`esm-env`) | Production |
| --- | --- | --- |
| `client-errors.js` | `throw` `Error` with code, full message, and doc URL (`name = 'Svelte error'`) | `throw` `Error` with only the doc URL |
| `shared-errors.js` | same as client-errors | same as client-errors |
| `server-errors.js` | always full message + URL (no DEV gate — SSR logs are read by developers) | always full message + URL |

All three annotate errors with `name = 'Svelte error'` and return `never`. `client-errors.js` and `server-errors.js` additionally `export * from '../shared/errors.js'`, making shared codes (e.g. `invalid_default_snippet`, consumed by the [shared runtime diagnostics](shared_runtime_diagnostics.md)) reachable from both runtimes through a single import path.

### 4.4 Runtime warnings — client / shared

`client-warnings.js` and `shared-warnings.js` are identical in shape: a styled `console.warn` in DEV (`%c[svelte] <code>` in bold, message and URL in normal weight) that degrades to a bare doc URL in production. Client-specific codes (e.g. `svelte_boundary_reset_noop`) live in the client template; codes shared with SSR live in the shared template.

### 4.5 The `DEV` gate

All four runtime templates import `DEV` from `esm-env`, a package whose export is statically resolvable at build time. This is what allows production bundles to drop every message string — an important size property that the [treeshakeability checker](svelte_build_tooling_treeshakeability_checker.md) guards.

---

## 5. Data Flow

### 5.1 Compile-time error emission

```mermaid
sequenceDiagram
    participant V as Compiler visitor<br/>(parse/analyze/transform)
    participant E as generated compiler/errors.js<br/>e.g. block_unclosed()
    participant H as e() helper
    participant C as InternalCompileError
    participant D as CompileDiagnostic
    participant S as compiler state.js

    V->>E: block_unclosed(node)
    E->>H: e(node, 'block_unclosed', MESSAGE + doc URL)
    H->>H: normalize node → [start, end ?? start]
    H->>C: new InternalCompileError(code, message, position)
    C->>D: new CompileDiagnostic(code, message, position)
    D->>S: read source, locator, filename
    D-->>D: compute start/end Location + code frame
    C-->>V: throw (never-returning call)
```

The compile templates depend on two modules documented elsewhere: the diagnostic model ([CompileDiagnostic](compiler_diagnostics_diagnostic_model.md)) and the per-compilation [compiler state](compiler_core_state.md) (`source`, `locator`, `filename`, `warnings`, `ignore_stack`, `ignore_map`, `warning_filter`).

### 5.2 Compile-time warning emission (filtering pipeline)

```mermaid
flowchart TD
    A["Visitor detects issue"] --> B["Call generated warning fn<br/>w.g. css_unused_selector(node)"]
    B --> C{"ignore_map has node entry<br/>or ignore_stack top<br/>contains code?"}
    C -->|yes| D["Drop silently<br/>(svelte-ignore honored)"]
    C -->|no| E["Construct InternalCompileWarning<br/>(CompileDiagnostic subclass)"]
    E --> F{"warningFilter option<br/>(state.warning_filter) accepts?"}
    F -->|no| D
    F -->|yes| G["push to state.warnings[]"]
    G --> H["Returned on CompileResult.warnings"]
```

### 5.3 Runtime error emission (DEV gating)

```mermaid
flowchart TD
    A["Runtime invariant violated<br/>(e.g. bind_not_bindable)"] --> B["Generated function in<br/>internal/client/errors.js"]
    B --> C{"DEV ?"}
    C -->|"true (dev build)"| D["throw Error:<br/>code \n message \n https://svelte.dev/e/code<br/>name='Svelte error'"]
    C -->|"false (prod build)"| E["throw Error:<br/>https://svelte.dev/e/code<br/>(message strings tree-shaken)"]
    D --> F["Developer lands on<br/>svelte.dev/e/&lt;code&gt; docs"]
    E --> F
```

---

## 6. Dependencies

### 6.1 Outbound (imports inside templates)

| Import | Used by | Owner module |
| --- | --- | --- |
| `./utils/compile_diagnostic.js` → `CompileDiagnostic` | compile-errors, compile-warnings | [compiler_diagnostics_diagnostic_model](compiler_diagnostics_diagnostic_model.md) |
| `./state.js` → `warnings`, `ignore_stack`, `ignore_map`, `warning_filter` | compile-warnings | [compiler_core_state](compiler_core_state.md) |
| `esm-env` → `DEV` | client-errors, client-warnings, shared-errors, shared-warnings | external (build-time constant) |
| `../shared/errors.js` (re-export) | client-errors, server-errors | [shared_runtime_diagnostics](shared_runtime_diagnostics.md) (generated from this module's `shared-errors.js` template) |

### 6.2 Inbound (consumers of the generated modules)

| Consumer | Generated module | Example symbols (from the module tree) |
| --- | --- | --- |
| Compiler parse/analyze/CSS pipeline | `compiler/errors.js`, `compiler/warnings.js` | `block_unclosed`, `css_global_block_invalid_combinator`, `css_unused_selector` — see [compiler_diagnostics_errors](compiler_diagnostics_errors.md) / [compiler_diagnostics_warnings](compiler_diagnostics_warnings.md) |
| Client runtime core | `internal/client/errors.js`, `internal/client/warnings.js` | `bind_invalid_export`, `bind_not_bindable`, `props_rest_readonly`, `svelte_boundary_reset_onerror`, `svelte_boundary_reset_noop` — see [client_runtime_core_diagnostics](client_runtime_core_diagnostics.md) |
| Server runtime | `internal/server/errors.js` | used throughout SSR rendering and [dev element validation](server_runtime_dev_validation.md) |
| Shared runtime | `internal/shared/errors.js` | `invalid_default_snippet` — see [shared_runtime_diagnostics](shared_runtime_diagnostics.md) |
| Compiler options validation (`validate-options.js`) | `compiler/errors.js` | `options_invalid_value`, `options_removed`, `options_unrecognised` |

Because every phase of the system — [compiler front-end](compiler_front-end_parsing_analysis___css_scoping_pipeline.md), [compiler back-end](compiler_back-end_client___server_code_generation.md), and both rendering backends — raises diagnostics exclusively through generated functions, this module effectively defines the *observable failure surface* of Svelte.

---

## 7. Maintenance Guide

### Adding or changing a diagnostic

1. **Never edit generated files.** Files under `src/compiler/errors.js`, `src/compiler/warnings.js`, and `src/internal/**/errors.js|warnings.js` carry the banner `This file is generated by scripts/process-messages/index.js. Do not edit!`.
2. **Edit the markdown corpus instead.** Add/modify a `## <CODE>` section under the appropriate `messages/<category>/` file. Message paragraphs are written as blockquotes (`> ...`); `%variable%` placeholders in the text become function parameters. Subsequent paragraphs (non-quoted trailing text) become reference details.
3. **Changing behavior (not text)?** Edit the corresponding template in this module — the scaffolding (classes, helpers, DEV gating, ignore handling) is authored here.
4. **Regenerate.** Run the `process-messages` script from `packages/svelte/` (use `-w` for continuous regeneration while editing messages). This also refreshes the public reference docs under `documentation/docs/98-reference/.generated/`.

### Invariants enforced by the generator

- **Unique codes** across the entire corpus (`Duplicate message code` otherwise) — codes double as URL slugs at `https://svelte.dev/e/<code>`.
- **Monotonic overload parameters**: when a code has multiple message variants, each variant must introduce at least one new `%var%`; otherwise generation aborts with `Message overloads must have new parameters`. Variants compile to nested conditional expressions that degrade gracefully as optional parameters are omitted.
- **Escaped template syntax**: backticks and `${` in message text are escaped before being inlined into template literals.
- **Sorted, stable output**: markdown sections are re-sorted in place and generated modules are deterministic, keeping diffs reviewable.

### Design rationale

- **One shape for errors and warnings.** `InternalCompileError` composes a `CompileDiagnostic` via `Object.assign` specifically so compiler errors and warnings are structurally identical for downstream tooling (IDEs, vite-plugin-svelte, testing libraries).
- **Bundler-friendly errors.** Extending `Error` (rather than being a plain diagnostic object) ensures bundler plugins and dev overlays treat compile failures correctly.
- **Small production bundles.** The `DEV`-gated templates guarantee that all human-readable message strings vanish from production builds, leaving only the short documentation URL.
- **Docs generated from the same source.** Emitting `documentation/docs/98-reference/.generated/<category>.md` from the same run guarantees svelte.dev's error reference can never drift from the shipped messages.

---

## 8. Related Modules

- [svelte_build_tooling](svelte_build_tooling.md) — parent module: build script infrastructure, including this generator and the sibling treeshakeability checker.
- [svelte_build_tooling_treeshakeability_checker](svelte_build_tooling_treeshakeability_checker.md) — validates that runtime internals (including the DEV-gated diagnostics produced here) remain tree-shakeable in production.
- [compiler_diagnostics_diagnostic_model](compiler_diagnostics_diagnostic_model.md) — `CompileDiagnostic` and `get_code_frame`, imported by the compile templates.
- [compiler_core_state](compiler_core_state.md) — per-compilation state (`warnings`, `ignore_stack`, `ignore_map`, `warning_filter`) consumed by the compile-warning scaffolding.
- [compiler_diagnostics_errors](compiler_diagnostics_errors.md) / [compiler_diagnostics_warnings](compiler_diagnostics_warnings.md) — the generated compile-time catalogues and their call sites.
- [client_runtime_core_diagnostics](client_runtime_core_diagnostics.md) — consumers of the client error/warning modules.
- [shared_runtime_diagnostics](shared_runtime_diagnostics.md) — shared runtime diagnostics re-exported by the client and server error modules.
- [server_runtime_dev_element_validation](server_runtime_dev_element_validation.md) — server-side validation built atop the generated server error functions.
