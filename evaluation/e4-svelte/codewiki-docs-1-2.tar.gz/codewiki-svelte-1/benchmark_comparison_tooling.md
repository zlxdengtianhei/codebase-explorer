# Benchmark Comparison Tooling (`benchmark_comparison_tooling`)

## 1. Introduction

The **benchmark_comparison_tooling** module (`benchmarking/compare/`) is a small, self-contained developer tool that answers a single question: *"Is the Svelte reactive runtime faster or slower on this branch than on another?"* It does this by checking out two or more git branches one at a time, executing the reactivity benchmark suite in an isolated child process for each branch, persisting the raw timings as JSON, and rendering an ASCII side-by-side comparison report on the console.

It is a member of the [Repository Engineering Infrastructure](Repository_Engineering_Infrastructure_(Benchmarks,_Build_Scripts___Playground).md) family, alongside the benchmark suites themselves ([reactivity_benchmarks](reactivity_benchmarks.md), [ssr_benchmarks](ssr_benchmarks.md)) and other build tooling ([svelte_build_tooling](svelte_build_tooling.md)). While `benchmarking/run.js` measures a *single* working tree, this module automates the otherwise manual "checkout → run → note numbers → repeat → compare" loop across *multiple* git refs.

### At a glance

| Aspect | Detail |
| --- | --- |
| Entry point | `benchmarking/compare/index.js` (run with `node benchmarking/compare/index.js [branch...]`) |
| Companion file | `benchmarking/compare/runner.js` (child process, referenced by `index.js`) |
| Output artifacts | `benchmarking/compare/.results/<branch>.json` (recreated fresh on every run) |
| Output report | Console: per-benchmark `time` / `gc_time` winners plus normalized ASCII bar charts |
| Runtime measured | `svelte/internal/client` — the signals / effects / batching engine of the Reactive Runtime Engine |
| External requirements | Node.js (ESM, top-level await), a git checkout of the svelte repository |
| Suites covered | Reactivity suite only (28 benchmarks); SSR is covered by `run.js`, not this tool |

---

## 2. Architecture

The module follows a **parent/child process split**:

* **`index.js` (parent, orchestrator + renderer)** — owns git interaction, branch lifecycle, forking, IPC collection, JSON persistence, and the final report. The module-tree-listed component `char` lives here; it is the labeling primitive that turns a branch index into a display letter.
* **`runner.js` (child, executor)** — a deliberately tiny script that imports the reactivity benchmark registry, awaits every benchmark, and ships the whole result array back to the parent over Node's IPC channel (`process.send`). Running benchmarks in a forked child guarantees a clean module graph per branch: the parent process never loads branch-specific code, so no stale `svelte/internal/client` instances can leak between measurements.

```mermaid
graph TD
    subgraph COMPARE["benchmarking/compare — benchmark_comparison_tooling"]
        IDX["index.js — parent orchestrator:<br/>arg parsing, git checkouts, fork, IPC,<br/>JSON persistence, report rendering, char"]
        RUN["runner.js — child process:<br/>awaits each benchmark, process.send results"]
        OUT[(".results/&lt;branch&gt;.json —<br/>raw measurement artifacts")]
    end

    subgraph GIT["Git working copy"]
        CO["git checkout branch"]
    end

    subgraph SUITE["reactivity_benchmarks module"]
        REG["benchmarks/reactivity/index.js registry<br/>sbench x10, kairo x16, mol_bench x2"]
        UTILS["benchmarking/utils.js<br/>fastest_test, GarbageTrack, v8-natives"]
    end

    subgraph TARGET["System under test"]
        RT["svelte/internal/client<br/>signals - deriveds - effects - batching"]
    end

    DEV["Developer shell"] -->|"node compare/index.js branchA branchB"| IDX
    IDX -->|"execSync checkout per branch"| CO
    CO -.->|"working tree switches code"| RUN
    IDX -->|"fork runner.js"| RUN
    RUN -->|"imports"| REG
    REG --> UTILS
    UTILS -->|"measures"| RT
    RUN -->|"IPC: results array"| IDX
    IDX -->|"JSON.stringify"| OUT
    OUT -->|"read back for comparison"| IDX
    IDX -->|"grouped bar report"| DEV
```

### Component responsibilities

| Component | File | Responsibility |
| --- | --- | --- |
| Orchestrator / report renderer | `benchmarking/compare/index.js` | Branch argument resolution, `.results` lifecycle, per-branch checkout + fork, IPC result capture, comparison math and console output |
| `char(i)` | `benchmarking/compare/index.js` | `String.fromCharCode(97 + i)` — maps branch index `0,1,2…` to report labels `a,b,c…`, keeping bar-chart rows compact and branch-name-agnostic |
| Benchmark child | `benchmarking/compare/runner.js` | Iterates `reactivity_benchmarks`, logs progress to stderr, transmits the result array to the parent via IPC |
| Benchmark suite | `benchmarking/benchmarks/reactivity/*` | The actual workloads — see [reactivity_benchmarks](reactivity_benchmarks.md) (not duplicated here) |
| Timing / GC tracking | `benchmarking/utils.js` | `fastest_test()` (best-of-N with forced GC), `GarbageTrack` (PerformanceObserver GC entries), powered by `v8-natives` |

---

## 3. Relationship to other modules

```mermaid
graph LR
    REI["Repository Engineering Infrastructure"] --> BCT["benchmark_comparison_tooling<br/>(this module)"]
    REI --> RB["reactivity_benchmarks"]
    REI --> SB["ssr_benchmarks"]
    REI --> BT["svelte_build_tooling"]
    BCT -->|"forks runner.js which imports"| RB
    RB -->|"exercises"| RTE["Reactive Runtime Engine<br/>signals / effects / batching"]
    BCT -.->|"does NOT run<br/>(see run.js)"| SB
    BCT -.->|"complements"| BT
```

* **Depends on** [reactivity_benchmarks](reactivity_benchmarks.md): `runner.js` imports its registry verbatim; the compare tool adds *no* benchmarks of its own.
* **Measures** the Reactive Runtime Engine (client-side signals, deriveds, effects, batching under `packages/svelte/src/internal/client/`). Any optimization or regression in that engine surfaces here as shifted `time` / `gc_time` numbers.
* **Complements** [svelte_build_tooling](svelte_build_tooling.md) (tree-shakeability checks, message-code generation) — both are contributor-facing quality gates, but they validate different properties (runtime performance vs. bundle/pipeline correctness).
* **Does not cover** the [ssr_benchmarks](ssr_benchmarks.md) suite: `runner.js` only imports the reactivity registry, whereas `benchmarking/run.js` runs both reactivity and SSR suites in a single working tree.

---

## 4. End-to-end workflow

```mermaid
sequenceDiagram
    autonumber
    participant Dev as Developer
    participant Idx as index.js — parent
    participant Git as git CLI
    participant Run as runner.js — child
    participant Bench as reactivity_benchmarks
    participant Disk as .results/

    Dev->>Idx: node index.js [branches...]
    Idx->>Idx: resolve branch list (defaults: HEAD, then main)
    Idx->>Idx: rm -rf and recreate .results
    Idx->>Idx: register exit handler -> git checkout branches[0]

    loop for each branch
        Idx->>Git: git checkout branch
        Git-->>Idx: working tree now holds branch code
        Idx->>Run: fork(runner.js)
        loop for each of the 28 reactivity benchmarks
            Run->>Bench: await benchmark()
            Bench->>Bench: JIT warmup, fastest_test best-of-N,<br/>GC tracking via perf_hooks + v8-natives
            Bench-->>Run: benchmark, time, gc_time
            Run-->>Dev: progress line on stderr
        end
        Run-->>Idx: IPC message: full results array
        Idx->>Disk: write branch.json (pretty-printed)
    end

    Idx->>Disk: read every branch.json
    Idx->>Dev: report: fastest branch per metric,<br/>normalized bar charts per benchmark
    Note over Idx,Git: on process exit:<br/>git checkout branches[0] restores the starting ref
```

### Phase-by-phase behavior of `index.js`

1. **Workspace reset** — `.results/` is removed and recreated at startup, so artifacts from previous runs can never contaminate a comparison. Results are written with 2-space indentation for easy manual inspection after a run.
2. **Branch resolution** (see §5) — positional CLI arguments become the branch list; `--`-prefixed flags are ignored (reserved for future options); an argument equal to the script's own resolved filename is skipped defensively.
3. **Per-branch measurement** — `execSync('git checkout <branch>')`, then `fork(runner.js)`. The parent parks on a promise resolved by the child's single IPC `message` and writes `<branch>.json` immediately. A child `error` rejects the promise and aborts the run — but the exit handler still restores the original ref.
4. **Restoration guarantee** — `process.on('exit', …)` synchronously checks out `branches[0]`. This is why the tool can safely mutate the working copy mid-run: control always returns to the starting ref, even on failure.
5. **Comparison & rendering** — all JSON files are read back and compared index-by-index (see §7).

---

## 5. Branch resolution logic

```mermaid
flowchart TD
    A["CLI argv after the script path"] --> B{"any positional<br/>arguments present?"}
    B -- "no" --> C["branches = current ref<br/>git symbolic-ref --short -q HEAD<br/>fallback: git rev-parse --short HEAD<br/>(detached HEAD yields a SHA)"]
    B -- "yes" --> D["branches = positional args<br/>--flags and self-path skipped"]
    C --> E{"exactly one branch?"}
    D --> E
    E -- "yes" --> F["append the default reference 'main'"]
    E -- "no" --> G["keep list as given"]
    F --> H["measure every branch<br/>checkout -> fork runner -> save JSON"]
    G --> H
    H --> I["render comparison report"]
    I --> J["exit: git checkout branches[0]"]
```

| Invocation | Branches compared | Ends on |
| --- | --- | --- |
| `node index.js` | current branch vs. `main` | current branch |
| `node index.js feat-a` | `feat-a` vs. `main` | `feat-a` |
| `node index.js feat-a feat-b` | `feat-a` vs. `feat-b` | `feat-a` (first argument — *not* necessarily your starting ref) |
| `node index.js feat-a --verbose` | `feat-a` vs. `main` (`--verbose` ignored) | `feat-a` |

---

## 6. Benchmark execution contract

`runner.js` performs no timing itself. Each benchmark function (from the [reactivity_benchmarks](reactivity_benchmarks.md) suite) internally warms the JIT, runs `fastest_test(10, …)` best-of-N measurement with a forced `v8.collectGarbage()` before every sample, attributes GC pauses within the sampled window via a `PerformanceObserver('gc')`, and returns:

```mermaid
classDiagram
    class BenchmarkResult {
        +string benchmark  "e.g. kairo_diamond_owned"
        +string time       "wall time ms, toFixed(2)"
        +string gc_time    "GC pause ms, toFixed(2)"
    }
    class BranchResults {
        +BenchmarkResult[] "one entry per registered benchmark, in registry order"
    }
    BranchResults "1" *-- "28" BenchmarkResult : current registry size
    note for BranchResults "serialized to .results/<branch>.json,<br/>sent parent-ward as one IPC message"
```

Key points of the contract:

* Values are **strings** (`toFixed(2)` at the source); the report coerces them back to numbers with unary `+`.
* Ordering matters: the parent aligns results **by array index** across branches, and takes benchmark *names* only from `results[0]` (the first branch measured).
* Progress visibility: `runner.js` echoes each benchmark name to **stderr**, which passes through to the developer's console while the parent's stdout stays reserved for the final report.

---

## 7. Comparison report rendering

For each benchmark and each metric (`time`, then `gc_time`):

1. Collect one value per branch, tracking the minimum (and its branch index) and maximum.
2. Skip rendering if `min === 0` — a zero fastest time would degenerate the scale (division by `max = 0`); the metric block is simply omitted.
3. Otherwise print a `console.group` header `"<metric>: fastest is <char(min_index)> (<branch name>)"` followed by one bar per branch:

```
a: ◼◼◼◼◼◼◼◼◼◼◼◼◼◼◼◼◼◼◼◼ 12.34ms      ← slowest branch (bar fills the full SIZE=20)
b: ◼◼◼◼◼◼◼◼◼◼◼◼          8.21ms      ← bar length = round(20 × time / max)
```

Bars are normalized against the **slowest** branch, so the fastest row visually communicates the margin. `char(i)` (`'a' + i`) labels rows, keeping the chart readable regardless of how long branch names are; the group header maps each letter back to the full branch name. Practical limits: labels extend only through `z`, capping the tool at **26 branches**, and nested `console.group`s are designed for DevTools-style collapsible consoles.

---

## 8. Usage

```bash
# Compare your current working branch against main
node benchmarking/compare/index.js

# Compare a feature branch against main
node benchmarking/compare/index.js my-feature

# Three-way comparison (output: a/b/c rows)
node benchmarking/compare/index.js my-feature optimization-spikes main
```

Afterwards, raw per-branch numbers remain available for further analysis:

```text
benchmarking/compare/.results/<branch>.json
```

---

## 9. Dependencies

| Dependency | Used for |
| --- | --- |
| `node:fs` / `node:path` | `.results` lifecycle, runner path resolution, JSON persistence |
| `node:child_process` (`execSync`, `fork`) | git invocations; spawning the isolated benchmark child with IPC |
| `node:url` (`fileURLToPath`) | resolving `runner.js` and `.results` relative to `index.js` regardless of CWD |
| git CLI | `checkout`, `symbolic-ref` / `rev-parse` (branch detection) |
| `benchmarking/utils.js` → `node:perf_hooks`, `v8-natives` | wall-clock timing and GC-pause attribution (best-of-N via `fastest_test`) |
| `svelte/internal/client` | the reactive runtime engine exercised by every benchmark |

Environment requirements: an ESM Node.js context (the scripts use top-level `await` and `import`), and a git clone where `main` exists when relying on the default branch pair.

---

## 10. Operational notes & caveats

* **Dirty working trees travel between checkouts.** The initial `git status --porcelain` guard is present but commented out; uncommitted modifications are not stashed and will therefore be measured (or conflict) on *every* branch in the run. Commit or stash before comparing.
* **Restore target is `branches[0]`, not "where you started".** When branches are passed explicitly, the shell ends on the first listed branch. Rely on the auto-detected mode (`node index.js`) if you need a guaranteed return to your starting ref.
* **Index-aligned comparison.** If branches differ in the number or order of registered benchmarks (e.g. a branch added one), the report mislabels rows — names come from `results[0]` only — or crashes when a shorter array is indexed out of bounds. Compare branches whose benchmark registries match, or accept that only the first branch's labels are shown.
* **Determinism.** Numbers are wall-clock/GC-time samples on a shared machine; run on a quiet system and treat small deltas with skepticism. Best-of-N sampling in `fastest_test` reduces, but does not eliminate, noise.
* **Scope.** Only the reactivity suite runs in comparison mode. To extend coverage (e.g. add `ssr_benchmarks` from [ssr_benchmarks](ssr_benchmarks.md)), import and iterate the additional registry inside `runner.js` — no parent-side changes are needed, since the IPC message already carries arbitrary arrays.
* **Zero-time guard.** Metrics whose fastest sample rounds to `0.00ms` are skipped entirely in the report rather than rendered with a broken scale.
