# compiler_core_entry

## 1. Introduction

`compiler_core_entry` is the **public entry point of the Svelte compiler** — the module behind the `svelte/compiler` package (`packages/svelte/src/compiler/index.js`). It exposes the stable API surface that all compiler consumers (bundler plugins, IDE tooling, playgrounds, the runtime `mount`/`hydrate` paths' build steps) interact with, and it **orchestrates the three-phase compilation pipeline**:

1. **Parse** — source text → AST
2. **Analyze** — AST + static validation → component/module analysis
3. **Transform** — analysis → generated JavaScript (and CSS)

### Public API surface

| Export | Kind | Purpose |
| --- | --- | --- |
| `compile(source, options)` | function | Compiles a `.svelte` component into a JavaScript module (client or server target) |
| `compileModule(source, options)` | function | Compiles a plain `.js`/`.ts` module that uses runes into an optimized JavaScript module |
| `parse(source, options)` | function | Parses a component and returns **only** its AST (modern or legacy shape) |
| `preprocess` | re-export | Re-exported from [compiler_preprocess](compiler_preprocess.md) |
| `migrate` | re-export | Re-exported from [compiler_migrate](compiler_migrate.md) (Svelte 4 → 5 codemod) |
| `VERSION` | re-export | Compiler version string from `../version.js` |
| `walk` | deprecated | Stub that throws, directing users to `estree-walker` |

> **Related core modules:** options validation lives in [compiler_core_options](compiler_core_options.md), compiler-wide mutable state in [compiler_core_state](compiler_core_state.md), and JS AST construction helpers in [compiler_core_builders](compiler_core_builders.md). All are siblings under [compiler_core](compiler_core.md).

---

## 2. Architecture Overview

The entry module is intentionally thin: it contains **no compilation logic of its own** beyond input sanitation (BOM removal), option merge/normalization, and AST post-processing for the public API. Every heavy operation is delegated to a phase module:

```mermaid
flowchart TD
    subgraph Entry["compiler_core_entry — index.js"]
        COMPILE["compile()"]
        CMODULE["compileModule()"]
        PARSE["parse()"]
        REEX["preprocess / migrate / VERSION re-exports"]
        HELPERS["remove_bom() / to_public_ast()"]
    end

    subgraph Infra["Shared infrastructure"]
        STATE["state.reset()<br/>(compiler_core_state)"]
        VALOPT["validate_component_options()<br/>validate_module_options()<br/>(compiler_core_options)"]
    end

    subgraph Phase1["Phase 1 — Parse (compiler_parser)"]
        P1["_parse(source, loose)"]
        TS["remove_typescript_nodes()"]
    end

    subgraph Phase2["Phase 2 — Analyze (compiler_analyzer)"]
        A1["analyze_component()"]
        A2["analyze_module()"]
    end

    subgraph Phase3["Phase 3 — Transform (compiler_client_transform / compiler_server_transform)"]
        T1["transform_component()"]
        T2["transform_module()"]
    end

    LEGACY["legacy.convert()<br/>(modern AST → LegacyRoot)"]

    COMPILE --> HELPERS
    CMODULE --> HELPERS
    PARSE --> HELPERS
    COMPILE --> STATE
    CMODULE --> STATE
    PARSE --> STATE
    COMPILE --> VALOPT
    CMODULE --> VALOPT
    COMPILE --> P1
    PARSE --> P1
    P1 --> TS
    COMPILE --> TS
    COMPILE --> A1
    CMODULE --> A2
    COMPILE --> T1
    CMODULE --> T2
    HELPERS --> LEGACY
```

### Responsibilities of the entry module

| Responsibility | Implementation |
| --- | --- |
| Input sanitation | `remove_bom()` strips a leading U+FEFF byte-order mark, which would otherwise corrupt template-generation offsets |
| Compiler state lifecycle | `state.reset({ warning, filename })` is called on every entry point to reset module-level flags (`dev`, `runes`), the warnings array, filename normalization, and the warning filter. Phase modules later refine this via `state.adjust()` |
| Options validation & merging | CLI options are validated into `ValidatedCompileOptions`, then **merged with `<svelte:options>` found in the source** — parsed options win, `customElement` is isolated into `customElementOptions` |
| TypeScript normalization | If `parsed.metadata.ts` is set, `remove_typescript_nodes()` strips TS-only constructs from `fragment`, `instance`, `module`, and the `customElementOptions.extend` class |
| Pipeline orchestration | Parse → Analyze → Transform, in that strict order |
| Public AST shaping | `to_public_ast()` strips internal `metadata` fields (modern AST) or delegates to `legacy.convert()` (legacy AST) |

---

## 3. The `compile()` Pipeline (components)

`compile()` is the main workhorse. It turns `.svelte` source into a `CompileResult`:

```javascript
{
  js: { code, map },          // generated JS + source map
  css: { code, map } | null,  // null when injected or absent
  ast,                        // public AST (modern or legacy)
  warnings,                   // accumulated via compiler state
  metadata: { runes }         // whether the component was compiled in runes mode
}
```

### Step-by-step data flow

```mermaid
sequenceDiagram
    autonumber
    participant C as compile()
    participant S as state (compiler_core_state)
    participant V as validate-options (compiler_core_options)
    participant P as Phase 1 — Parse (compiler_parser)
    participant A as Phase 2 — Analyze (compiler_analyzer)
    participant T as Phase 3 — Transform
    participant L as legacy.convert()

    C->>C: remove_bom(source)
    C->>S: reset({ warningFilter, filename })
    C->>V: validate_component_options(options)
    V-->>C: ValidatedCompileOptions
    C->>P: _parse(source)
    P-->>C: Root AST (fragment, instance, module, css, options, metadata.ts)
    C->>C: merge <svelte:options> into validated options
    opt TypeScript source (metadata.ts)
        C->>P: remove_typescript_nodes(fragment/instance/module/extend)
    end
    C->>A: analyze_component(parsed, source, combined_options)
    Note over A: scopes, runes detection, store-subscription synthesis,<br/>CSS analyze + prune, visitors over module/instance/template
    A-->>C: ComponentAnalysis
    C->>T: transform_component(analysis, source, options)
    Note over T: generate = 'client' → client_component()<br/>generate = 'server' → server_component()<br/>generate = false → no output<br/>printed via esrap (+ts comments) with sourcemaps
    T-->>C: { js, css, warnings, metadata }
    C->>C: result.ast = to_public_ast(source, parsed, modernAst)
    alt modernAst = true
        C->>C: walk & delete node.metadata (public modern AST)
    else
        C->>L: convert(source, ast)
        L-->>C: LegacyRoot (Svelte 4 AST shape)
    end
    C-->>C: CompileResult
```

Key details per step:

1. **Options merge** — `parsed.options` (the raw attributes of `<svelte:options>`) are spread **over** the validated CLI options, so in-source configuration takes precedence. `customElement` is split out as `customElementOptions`; its optional `extend` class is also TS-stripped when applicable.
2. **Analyze phase** (see [compiler_analyzer](compiler_analyzer.md) and [compiler_analyzer_scope](compiler_analyzer_scope.md)) — builds the `ScopeRoot`, synthesizes bindings for `$store` subscriptions, decides runes vs. legacy mode (`options.runes ?? (has_await || rune references)`), walks module/instance/template with the visitor set ([compiler_analyzer_block_visitors](compiler_analyzer_block_visitors.md), [compiler_analyzer_template_visitors](compiler_analyzer_template_visitors.md), [compiler_analyzer_js_visitors](compiler_analyzer_js_visitors.md)), and runs CSS analysis ([compiler_css_pipeline_analysis](compiler_css_pipeline_analysis.md)) to mark scoped/unused selectors.
3. **Transform phase** (see [compiler_client_transform](compiler_client_transform.md) and [compiler_server_transform](compiler_server_transform.md)) — chooses the render backend from `options.generate`, prints the resulting program with esrap, embeds the original source for robust source maps, and merges any preprocessor source maps. CSS is rendered separately unless `css: 'injected'` or custom-element mode (`analysis.inject_styles`), in which case styles are emitted into JS at runtime (see [compiler_css_pipeline_transform](compiler_css_pipeline_transform.md) and the `append_styles` runtime helper).
4. **Warnings** — warnings raised anywhere in the pipeline are pushed onto the shared `state.warnings` array ([compiler_diagnostics](compiler_diagnostics.md)); the entry never raises them directly. The filter installed by `state.reset` (`options.warningFilter`) decides inclusion.

---

## 4. The `compileModule()` Pipeline (modules)

For plain JavaScript/TypeScript files using runes (`.svelte.js` / `.svelte.ts` modules):

```mermaid
flowchart LR
    A["source (.js/.ts)"] --> B["remove_bom"]
    B --> C["state.reset"]
    C --> D["validate_module_options"]
    D --> E["analyze_module<br/>(compiler_analyzer)"]
    E --> F["transform_module<br/>(compiler_client_transform /<br/>compiler_server_transform)"]
    F --> G["CompileResult<br/>(css = null, runes = true)"]
```

Differences from component compilation:

- **No template**: the parse phase uses the Acorn-based JS parser directly, and analysis skips template/CSS work entirely (`runes: true`, `immutable: true` are fixed).
- **Version banner**: `transform_module` prepends a `/* <filename> generated by Svelte v<VERSION> */` comment and offsets the source-map mappings accordingly.
- **Store subscription rules** are stricter: `$store` subscriptions inside a module are an error (`store_invalid_subscription_module`).

---

## 5. The `parse()` API and AST modes

`parse()` runs only Phase 1 and returns the AST, supporting two output shapes controlled by the `modern` option (default `false` in Svelte 5, `true` from Svelte 6, removed in Svelte 7):

| `modern` | Result | Mechanism |
| --- | --- | --- |
| `true` | Public **modern AST** (`AST.Root`) — internal `metadata` fields removed from every node, including `<svelte:options>` attributes | `to_public_ast()` walks with `zimmerframe` and deletes `node.metadata` |
| `false` / omitted | **Legacy AST** (`LegacyRoot`) — the Svelte 4 node vocabulary (`Element`, `InlineComponent`, `MustacheTag`, `EventHandler`, `RawMustacheTag`, …) | `legacy.convert(source, ast)` performs a full node-shape translation, re-inserts raw `svelte:options`, reconstructs `ElseBlock`/`PendingBlock` boundaries from source positions |

Additional options:

- `loose` (since 5.13.0) — attempts to always return an AST even for input that would fail compilation.
- The public `filename` option of `parse` is unused and slated for removal in 6.0.
- Warnings are unconditionally suppressed during `parse` (`state.reset({ warning: () => false, ... })`).

---

## 6. Dependency Map

```mermaid
graph LR
    ENTRY["compiler_core_entry"]

    ENTRY --> CORE["compiler_core<br/>(parent orchestrator)"]
    ENTRY --> STATE["compiler_core_state<br/>reset / push_ignore / pop_ignore"]
    ENTRY --> OPTS["compiler_core_options<br/>validate_*_options"]
    ENTRY --> PARSER["compiler_parser"]
    ENTRY --> ANALYZER["compiler_analyzer"]
    ENTRY --> CSS["compiler_css_pipeline"]
    ENTRY --> CLIENT["compiler_client_transform"]
    ENTRY --> SERVER["compiler_server_transform"]
    ENTRY --> TYPES["compiler_types<br/>CompileResult / CompileOptions / AST"]
    ENTRY --> DIAG["compiler_diagnostics<br/>errors / warnings / code frames"]
    ENTRY --> PRE["compiler_preprocess<br/>(re-exported)"]
    ENTRY --> MIG["compiler_migrate<br/>(re-exported)"]

    PARSER --> PSM["compiler_parser_template_state_machine"]
    PARSER --> JS["compiler_parser_js_ts_processing"]
    PARSER --> PU["compiler_parser_parse_utilities"]
    CLIENT --> CT["templates / state &amp; reactivity /<br/>control flow / elements / components"]
    SERVER --> ST["pipeline / control flow /<br/>elements / components / javascript"]
```

Dependency notes:

- **Hard runtime dependencies** (imported by `index.js`): `zimmerframe` (walking), `./legacy.js` (`convert`), `phases/1-parse` (`parse`, `remove_typescript_nodes`), `phases/2-analyze` (`analyze_component`, `analyze_module`), `phases/3-transform` (`transform_component`, `transform_module`), `validate-options.js`, `state.js`, `preprocess`, `migrate`, `version.js`.
- **Error handling**: any phase may throw a `CompileError` carrying position info and a code frame (see [compiler_diagnostics](compiler_diagnostics.md)); the entry module does not catch or translate these — they propagate to the caller.
- **Type contracts**: inputs/outputs are typed by [compiler_types](compiler_types.md) — `CompileOptions`, `ModuleCompileOptions`, `CompileResult`, `AST.Root` and `LegacyRoot`.

---

## 7. Evolution & Compatibility Notes

- **`walk` removal** — exporting a walker was moved to `estree-walker`; the entry keeps a throwing stub so consumers get an actionable error at call time instead of an `undefined` import.
- **AST modernization timeline** — `modern: false` is the Svelte 5 default; Svelte 6 flips the default; Svelte 7 removes the option (and the unused `filename` option). The `modernAst` option of `compile()` controls only the *public* `result.ast` — generation always uses the internal modern AST.
- **TypeScript handling** is normalized early (post-parse) so that the analyze/transform phases operate on a TypeScript-free AST; this is also why `customElementOptions.extend` is stripped at the entry level.
- **BOM handling** exists because a leading U+FEFF shifts character offsets and would break template/`<script>` extraction logic downstream.

---

## 8. See Also

- [compiler_core](compiler_core.md) — parent module: entry, options, state, builders
- [compiler_parser](compiler_parser.md) — Phase 1 (template state machine, JS/TS processing, parse utilities)
- [compiler_analyzer](compiler_analyzer.md) — Phase 2 (scope construction, block/template/JS visitors)
- [compiler_css_pipeline](compiler_css_pipeline.md) — CSS analysis and scoping/transform
- [compiler_client_transform](compiler_client_transform.md) — Phase 3 client code generation
- [compiler_server_transform](compiler_server_transform.md) — Phase 3 server (SSR) code generation
- [compiler_diagnostics](compiler_diagnostics.md) — errors, warnings, code frames
- [compiler_types](compiler_types.md) — AST and option/result type contracts
- [compiler_preprocess](compiler_preprocess.md) — `preprocess()` re-exported by this entry
- [compiler_migrate](compiler_migrate.md) — `migrate()` codemod re-exported by this entry
