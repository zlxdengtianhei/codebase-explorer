# Client Transform: State & Reactivity

## 1. Introduction

The `compiler_client_transform_state_and_reactivity` module is the heart of Svelte's client-side code generation for **reactive state**. During phase 3 of the compilation pipeline (see [compiler_client_transform](compiler_client_transform.md)), it rewrites the *declarative* reactivity of a component — `$state`, `$derived`, `$props`, `$effect` runes, and legacy reactive declarations — into *imperative* calls against the signal-based runtime (`svelte/internal/client`).

Concretely, this module is responsible for:

- **Reads** — rewriting every reference to reactive state (`count`) into a signal read (`$.get(count)`) via the `Identifier`, `MemberExpression` and `build_getter` machinery.
- **Writes** — rewriting assignments and mutations (`count = 0`, `obj.x += 1`) into signal writes (`$.set(count, 0)`, `$.mutate(...)`, `$.assign_and(...)`) via the `AssignmentExpression` visitor and shared assignment infrastructure.
- **Declarations** — transforming rune call expressions (`$state`, `$derived`, `$state.raw`, …) into runtime signal constructors (`$.state`, `$.derived`, `$.async_derived`) via the `CallExpression` and `ClassBody` visitors.
- **Props** — converting component props into lazy, flag-annotated signal sources (`$.prop($$props, name, flags)`) via `get_prop_source` / `is_prop_source`.
- **Function hoisting** — extracting event handlers and other functions into module/instance scope with explicit "hoisted params" (see `visit_function`, `build_hoisted_params`), since signals cannot be closed over safely across component instantiations.
- **Dev-mode instrumentation** — proxy coercion warnings, ownership validation of prop mutations, signal tagging for the dev-tools inspector, and `console.*` state logging.

## 2. Position in the System

The module sits inside the client transform phase, which walks the analyzed AST (produced by [compiler_parser](compiler_parser.md) and enriched by [compiler_analyzer](compiler_analyzer.md) — in particular [compiler_analyzer_scope](compiler_analyzer_scope.md), which supplies the `Binding` records this module queries constantly). Its output is JavaScript source code that is executed by the reactive runtime (see [reactive_runtime_core](reactive_runtime_core.md) and [client_runtime_core](client_runtime_core.md)) and rendered by the DOM backend ([client_dom_renderer](client_dom_renderer.md)).

```mermaid
flowchart LR
    subgraph FE["Compiler Front-End"]
        P["1-parse<br/>(compiler_parser)"] --> A["2-analyze<br/>(compiler_analyzer)<br/>· bindings · scopes · runes"]
    end
    subgraph BE["Compiler Back-End"]
        A --> T["3-transform<br/>(compiler_client_transform)"]
        T --> SR["server transform<br/>(compiler_server_transform)"]
    end
    subgraph THIS["This module:<br/>state &amp; reactivity"]
        T --> M["Reads / Writes /<br/>Declarations / Props /<br/>Hoisting / Dev instrumentation"]
    end
    M --> RT["Reactive Runtime Engine<br/>(client_runtime_core)"]
    M --> DEV["client_dev_mode"]
    RT --> DOM["Component Rendering Backend<br/>(client_dom_renderer)"]
    SR --> SSR["server_runtime"]
```

Within `compiler_client_transform`, the visitor space is partitioned into sibling modules. This module owns the **expression-level** reactivity concerns; the siblings own templates, blocks, elements/directives and components — all of which *depend on* the utilities defined here (e.g. `build_getter` is used by [compiler_client_transform_templates](compiler_client_transform_templates.md), and `create_derived` is used by the memoizer in block visitors).

```mermaid
flowchart TD
    CT[compiler_client_transform<br/>transform-client.js orchestrator]
    CT --> SR2[templates]
    CT --> THISM["⭐ state_and_reactivity<br/>(this module)"]
    CT --> CF[control_flow_blocks]
    CT --> ED[elements_and_directives]
    CT --> CS[components_and_scripts]
    THISM -- "build_getter · create_derived<br/>should_proxy · get_prop_source" --> SR2
    THISM -- "build_getter · validate_mutation<br/>shared/assignments.js" --> CF
    THISM -- "build_getter · is_prop_source<br/>should_proxy" --> ED
    THISM -- "build_getter" --> CS
```

## 3. Core Concepts

### 3.1 Bindings and binding kinds

The analysis phase classifies every variable into a `Binding` with a `kind`: `state`, `raw_state`, `derived`, `prop`, `bindable_prop`, `rest_prop`, `store_sub`, `legacy_reactive`, or plain declarations. This module's decision logic is essentially a large dispatch on `binding.kind` + `binding.reassigned` / `mutated` / `updated` + the component's mode (`analysis.runes`, `analysis.immutable`, `analysis.accessors`).

### 3.2 The `transform` map

`ComponentClientTransformState.transform` is a `Record<string, { read, assign?, mutate? }>`. When a declaration is rewritten into a signal (e.g. `let count = $state(0)` → `let count = $.state(0)`), the transform registry records *how* to read / assign / mutate that name:

| handler | emitted for | example rewrite |
|---|---|---|
| `read(node)` | every reference | `count` → `$.get(count)` |
| `assign(node, value, proxy)` | reassignments to a bare identifier | `count = v` → `$.set(count, v)` |
| `mutate(node, mutation)` | member/deep mutations | `obj.x = v` → `$.mutate(obj, $.proxy(obj).x = v)` |

`build_getter` is the canonical read entry point; `AssignmentExpression` (via `build_assignment`) is the canonical write entry point. The registry is populated mostly by the `VariableDeclaration` visitor (see [compiler_client_transform](compiler_client_transform.md)) and by block visitors such as `{@const}` and `each` items.

### 3.3 Signals vs. plain values

Not every `$state` declaration becomes a signal. `is_state_source` keeps declarations as plain variables when the value cannot change observably: immutable mode with no reassignment and no accessors. Similarly, `is_prop_source` inlines props that are read-only and never reassigned, so trivial components compile without runtime prop machinery. This "signal elision" is a major output-size and performance optimization.

### 3.4 Proxying deep state

`$state` implies deep reactivity: objects assigned into it are wrapped in a reactive `Proxy`. `should_proxy(node, scope)` statically decides whether a value needs `$.proxy()` — literals, template literals, functions, unary/binary expressions and `undefined` never need it; identifiers are resolved through the scope and recursively checked against their initializer (functions, classes, imports, each items and snippets are excluded).

## 4. Architecture

```mermaid
flowchart TB
    subgraph visitors["Expression & class visitors (visitors/)"]
        ID["Identifier.js<br/>Identifier"]
        ME["MemberExpression.js<br/>MemberExpression"]
        AE["AssignmentExpression.js<br/>AssignmentExpression +<br/>build_assignment"]
        CE["CallExpression.js<br/>CallExpression (rune dispatch)"]
        CB["ClassBody.js<br/>ClassBody"]
        AFE["ArrowFunctionExpression.js"]
        FE2["FunctionExpression.js"]
        SHFN["shared/function.js<br/>visit_function"]
        SHUT["shared/utils.js<br/>validate_mutation"]
        SHAS["../shared/assignments.js<br/>visit_assignment_expression"]
    end

    subgraph utils["Core utilities (utils.js)"]
        BGET["build_getter"]
        ISS["is_state_source"]
        IPS["is_prop_source"]
        GPS["get_prop_source"]
        SPX["should_proxy"]
        BHP["build_hoisted_params<br/>get_hoisted_params"]
        CD["create_derived"]
    end

    subgraph infra["Compiler infrastructure"]
        SCOPE["Scope / Binding<br/>(compiler_analyzer_scope)"]
        BUILDERS["AST builders b.*<br/>(compiler_core)"]
        TS["TransformState /<br/>ComponentClientTransformState"]
    end

    subgraph runtime["Runtime symbols emitted ($.*)"]
        R1["$.get · $.set · $.mutate<br/>$.state · $.derived<br/>$.derived_safe_equal · $.proxy"]
        R2["$.prop · $.assign · $.assign_and<br/>$.assign_or · $.assign_nullish"]
        R3["$.async_derived · $.save<br/>$.effect_tracking · $.snapshot<br/>$.effect_root · $.pending"]
        R4["dev: $.tag · $.tag_proxy<br/>$.log_if_contains_state<br/>$$ownership_validator.mutation"]
    end

    ID --> BGET
    ID --> SCOPE
    ME --> TS
    AE --> SHAS
    AE --> SHUT
    AE --> SPX
    AE --> SCOPE
    CE --> SPX
    CE --> SCOPE
    CB --> TS
    AFE --> SHFN
    FE2 --> SHFN
    SHFN --> BHP
    SHUT --> BUILDERS
    BHP --> SCOPE
    SHAS --> AE

    BGET --> TS
    GPS --> SCOPE
    CD --> runtime

    BGET --> R1
    AE --> R1 & R2
    CE --> R1 & R3
    CB --> R1 & R4
    ID --> R4
```

## 5. Component Reference

### 5.1 `utils.js` — transform utilities

The shared toolbox consumed by every other client-transform visitor.

| Function | Purpose |
|---|---|
| `is_state_source(binding, analysis)` | True when a `state`/`raw_state` binding must become a runtime signal: not immutable, reassigned, or accessors requested. Guards the `$.state(...)` wrapping. |
| `build_getter(node, state)` | If `state.transform[node.name]` exists and `node` is not the declaration itself, returns `transform[name].read(node)` (typically `$.get(id)`); otherwise returns the identifier unchanged. Used for reads *and* when exporting getters (see `build_getter` in `transform-client.js`). |
| `build_hoisted_params(node, context)` / `get_hoisted_params` | Computes the explicit parameter list for hoisted functions. Walks `scope.references`; for `store_sub` bindings hoists both the subscription thunk and the store; unwraps `$.get(derived)` member reads to the derived itself; hoists `$$props` for simple prop reads and for `rest_prop` in runes mode; skips imports; in dev mode scans for prop mutations and appends `$$ownership_validator`. If the function had no params, a synthetic `_` (event object) param is added first. Result is memoized on `node.metadata.hoisted_params`. |
| `get_prop_source(binding, state, name, initial)` | Emits `$.prop($$props, name, flags[, initial])`. Flag bits from `constants.js`: `PROPS_IS_BINDABLE`, `PROPS_IS_IMMUTABLE`, `PROPS_IS_RUNES`, `PROPS_IS_UPDATED`, `PROPS_IS_LAZY_INITIAL`. Non-trivial initial values are wrapped in a thunk (or reuse an existing zero-argument callee) so they are evaluated lazily — this is why defaults like `count = $state(expensive())` don't run until the prop is actually passed. |
| `is_prop_source(binding, state)` | True when a prop needs a signal source: legacy mode, accessors, reassigned, has an initial value, or is `updated` (legacy parents need coarse-grained reactivity). |
| `should_proxy(node, scope)` | Static deep-proxy decision (see §3.4). Recursively resolves identifier initializers through the scope. |
| `create_derived(state, expression, async)` | Mode-aware derived creation: `$.derived(thunk)` in runes mode, `$.derived_safe_equal(thunk)` in legacy mode (safe-equals trades update granularity for correctness with untracked mutations). Async variants wrap in `$.async_derived` + `await $.save(...)`. |

### 5.2 `visitors/shared/function.js` — `visit_function`

Single shared implementation for `ArrowFunctionExpression` and `FunctionExpression` visitors (both delegate to it). Responsibilities:

1. Resets `in_constructor` / `in_derived` context flags for the function body (a fresh function is not a constructor context and not a derived expression), except when the function *is* a class constructor (`MethodDefinition` with `kind === 'constructor'`).
2. If `node.metadata.hoisted === true` (set by event-handler/template optimization in sibling modules), replaces the node's params with `build_hoisted_params` output and rewrites the body — converting a lexically-scoped arrow into a **top-level hoisted function** whose closed-over reactive values are passed explicitly as parameters.

### 5.3 `visitors/Identifier.js` — reactive reads

Handles every *reference* to an identifier (via `is-reference`):

- `$$props` is renamed to `$$sanitized_props` (the sanitized rest-props object).
- **Rest-prop fast path** (runes only): a non-computed member read `rest.foo` whose root is a `rest_prop` binding — and which is not itself the target of an assignment/update — is rewritten to `$$props.foo`, skipping signal overhead entirely.
- Otherwise delegates to `build_getter`, producing the signal read.

### 5.4 `visitors/MemberExpression.js` — private state fields

Inside class components, `this.#foo` where `#foo` is a registered `state_fields` entry is rewritten to `$.get(this.#foo)`. The one exception: while inside the constructor, `$state`/`$state.raw` fields are still "raw" — they are read directly as `this.#foo.v` (the signal's internal value slot) because the signal wrapper semantics are only needed after construction.

### 5.5 `visitors/AssignmentExpression.js` — reactive writes

The write path. The visitor first calls `visit_assignment_expression` (shared between client and server transforms; see [compiler_server_transform](compiler_server_transform.md)) which destructures compound patterns (`[a, b] = ...`, `{ x } = ...`) into per-path assignments, caching the RHS in `$$value` and wrapping in an IIFE/sequence when needed. Each path is handled by the local `build_assignment`, then the result is wrapped by `validate_mutation` (dev ownership validation).

`build_assignment(operator, left, right, context)` decision flow:

```mermaid
flowchart TD
    A["AssignmentExpression<br/>operator L = R"] --> B{"runes &amp;&amp;<br/>left is MemberExpression<br/>&amp;&amp; property is state field?"}
    B -- yes --> C1{"constructor declaration?<br/>(field.node is the assignment<br/>and left matches)"}
    C1 -- yes --> C2["this.#field = visit(R)<br/>(dev: wrap in $.tag)"]
    C1 -- no --> C3{"PrivateIdentifier?"}
    C3 -- yes --> C4["$.set(this.#field, value,<br/>needs_proxy?)<br/>proxy only for $state +<br/>non-coercive operator"]
    C3 -- no --> D
    B -- no --> D["resolve root object identifier<br/>&amp; its binding + transform"]
    D --> E{"transform.assign?"}
    E -- yes --> F["REASSIGNMENT:<br/>transform.assign(object, value, proxy)<br/>e.g. $.set(count, v)<br/>proxy flag suppressed for primitive<br/>bindings, prop, bindable_prop,<br/>raw_state, derived, store_sub"]
    E -- no --> G{"transform.mutate?"}
    G -- yes --> H["MUTATION:<br/>transform.mutate(object,<br/>operator-assignment over<br/>visited left/right)"]
    G -- no --> I{"dev &amp;&amp; not ExpressionStatement<br/>&amp;&amp; non-coercive operator (=, ||=,<br/>&amp;&amp;=, ??=) &amp;&amp; left is member?"}
    I -- "yes (after exceptions for<br/>onclick={() =&gt;...} and<br/>bind:/component props)" --> J["$.assign_and / $.assign_or /<br/>$.assign_nullish(object, key, right,<br/>location) — proxy-coercion warning"]
    I -- no --> K["null → keep original JS<br/>semantics (context.next())"]
```

Key subtleties:

- **Coercion analysis** (`is_non_coercive_operator`): only `=`, `||=`, `&&=`, `??=` pass the value through uncoerced, so only those need proxy wrapping (or a dev warning that the proxy isn't created in time — e.g. `(obj.items ??= []).push(v)` pushes to the *proxy*, not the original array).
- **Bind/primitive suppression**: assignments coming from element bindings are known primitives, so the `needs_proxy` argument is `false`.

### 5.6 `visitors/CallExpression.js` — rune compilation

Dispatches on `get_rune(node, scope)` (from [compiler_analyzer_scope](compiler_analyzer_scope.md)):

| Rune | Emitted |
|---|---|
| `$host` | `$$props.$$host` |
| `$effect.tracking()` | `$.effect_tracking()` |
| `$state(v)` / `$state.raw(v)` | `$.state(v)` — with `$.proxy(v)` (see `should_proxy`) for deep `$state` |
| `$derived(e)` | `$.derived(thunk(e))` — body visited with `in_derived: true` so nested reads stay raw |
| `$derived.by(fn)` | `$.derived(fn)` |
| `$state.snapshot(v)` | `$.snapshot(v[, true])` — second arg when `state_snapshot_uncloneable` is ignored |
| `$effect.root(fn)` | `$.effect_root(fn)` |
| `$effect.pending()` | `$.pending()` |
| `$inspect` / `$inspect().with` | `transform_inspect_rune` (dev-mode inspection) |

Additionally, in dev mode, `console.debug/dir/error/group/groupCollapsed/info/log/trace/warn` calls whose arguments may contain state are rewritten to route through `$.log_if_contains_state` so the dev inspector can render signal previews. All other calls fall through with `context.next()`.

### 5.7 `visitors/ClassBody.js` — class-based state

For classes (runes mode), `analysis.classes` maps each `ClassBody` to its `state_fields`. The visitor rebuilds the class body:

- **Constructor-declared fields** (`this.#x = $state(0)` inside `constructor`): synthesizes a backing property plus `get`/`set` accessor pair delegating to `$.get` / `$.set`.
- **Private field definitions** (`#x = $state(0)`): kept as a property whose initializer is the transformed rune call (dev: wrapped in `$.tag`).
- **Public field definitions** (`x = $state(0)`): stored under the *backing key*, with public `get x()` → `$.get(this.#key)` and `set x(v)` → `$.set(this.#key, v, should_proxy)` accessors replacing the original property.
- Every accessor-pair `set` uses `should_proxy = true` for `$state` fields so externally assigned objects become deeply reactive.
- In legacy mode (no `state_fields`), the class body is untouched.

### 5.8 Dev-mode instrumentation woven through this module

| Mechanism | Visitor / utility | Runtime hook |
|---|---|---|
| Signal tagging | `CallExpression`, `ClassBody`, `AssignmentExpression` (constructor declarations) | `$.tag(value, 'Label.field')` — powers the dev-tools component tree (see [client_dev_mode](client_dev_mode.md), `dev/tracing.js`) |
| Proxy tagging | `VariableDeclaration` consumers of `should_proxy` | `$.tag_proxy(value, name)` |
| Ownership validation | `validate_mutation` + `get_hoisted_params` | `$$ownership_validator.mutation(prop, path, expr, line, col)` via `$.create_ownership_validator` (set on state when `analysis.needs_mutation_validation`) |
| Console state logging | `CallExpression` | `$.log_if_contains_state(method, ...args)` |
| Assignment coercion warnings | `AssignmentExpression` | `$.assign_and/or/nullish` |

## 6. Data Flow

```mermaid
flowchart TD
    SRC["`.svelte` source<br/>let count = $state(0)<br/>$: total = count * 2<br/>&lt;button onclick={() =&gt; count++}&gt;"] --> PARSE["parse (compiler_parser)"]
    PARSE --> ANA["analyze (compiler_analyzer)<br/>· Binding{kind:'state', reassigned:true}<br/>· scope.references<br/>· state_fields · metadata.hoisted"]
    ANA --> WALK["transform-client.js<br/>walk(module ast → instance ast → template ast)<br/>with ComponentClientTransformState"]
    WALK --> V["Visitor dispatch<br/>(this module: Identifier, MemberExpression,<br/>AssignmentExpression, CallExpression, ClassBody,<br/>function visitors)"]
    V --> TM["transform registry per name:<br/>read / assign / mutate"]
    TM --> OUT["ESTree Program<br/>let count = $.state(0)<br/>$.derived(() =&gt; $.get(count) * 2)<br/>hoisted: () =&gt; $.update(count)"]
    OUT --> PRINT["esrap print + sourcemaps"]
    PRINT --> BUNDLE["bundler → browser"]
    BUNDLE --> RUN["Reactive Runtime Engine<br/>(signals, effects, batching)"]
```

Two traversals matter for state: the **module/instance pass** (which registers `transform` entries while rewriting declarations) and the **template pass** (which reuses the instance `transform` map so markup expressions compile to the same signal getters).

## 7. Process Flows

### 7.1 Reading reactive state

```mermaid
sequenceDiagram
    participant W as walk (zimmerframe)
    participant ID as Identifier visitor
    participant SC as Scope
    participant BG as build_getter
    participant TR as state.transform
    W->>ID: Identifier(count) in template
    ID->>ID: is_reference(count, parent)? yes
    ID->>SC: scope.get('count')
    SC-->>ID: Binding{kind:'state'}
    ID->>BG: build_getter(node, state)
    BG->>TR: transform['count'].read?
    TR-->>BG: (id) => $.get(id)
    BG-->>ID: $.get(count)
    ID-->>W: CallExpression $.get(count)
```

Notes: the declaration site itself (`let count = ...`) is skipped by the `node !== binding.node` check so the initializer is not self-wrapped; `$$props` references are renamed before this point.

### 7.2 Writing reactive state (member mutation, dev mode)

```mermaid
sequenceDiagram
    participant W as walk
    participant AE as AssignmentExpression
    participant VA as visit_assignment_expression<br/>(shared)
    participant BA as build_assignment
    participant VM as validate_mutation
    W->>AE: obj.count += 1
    AE->>VA: hand off (handles destructuring patterns)
    VA->>BA: ('+=', obj.count, 1)
    BA->>BA: root = obj → binding kind = state
    BA->>BA: transform.mutate? yes
    BA-->>VA: $.mutate(obj, $.proxy(obj).count += 1)
    VA-->>AE: expression
    AE->>VM: wrap (dev only)
    VM->>VM: left is member of prop binding?
    VM-->>AE: $$ownership_validator.mutation(...) or expr
    AE-->>W: final expression
```

### 7.3 Hoisting an event handler

```mermaid
flowchart TD
    A["ArrowFunctionExpression<br/>metadata.hoisted = true<br/>(set by event-attribute optimization)"] --> B["visit_function"]
    B --> C["state: in_constructor=false, in_derived=false"]
    C --> D["build_hoisted_params"]
    D --> E["scan scope.references:<br/>store_sub → sub + store<br/>$.get(derived) → derived<br/>prop/bindable_prop → $$props<br/>rest_prop (runes) → id + $$props<br/>imports → skipped"]
    E --> F{"dev &amp;&amp; body mutates<br/>prop member?"}
    F -- yes --> G["append $$ownership_validator param"]
    F -- no --> H["—"]
    G --> I["replace params;<br/>visit body;<br/>emit hoisted function"]
    H --> I
    I --> J["call sites pass signal values<br/>as arguments instead of closure"]
```

Hoisting lets the compiler emit handlers once per component definition rather than per template evaluation, and is what enables delegated events to receive the `event` object via the synthetic `_` parameter.

### 7.4 Class state field compilation

```mermaid
flowchart LR
    subgraph In["Input (runes)"]
        C1["class Counter {<br/>  x = $state(0)<br/>}"]
    end
    subgraph Out["Output"]
        C2["class Counter {<br/>  #x = $.tag($.state(0), 'Counter.x')<br/>  get x() { return $.get(this.#x) }<br/>  set x(v) { $.set(this.#x, v, true) }<br/>}"]
    end
    C1 -->|"ClassBody visitor +<br/>state_fields from analysis.classes"| C2
```

## 8. Integration with the Runtime

Every signal primitive this module emits resolves to a function in `svelte/internal/client`:

| Emitted call | Runtime location (module doc) |
|---|---|
| `$.state`, `$.get`, `$.set`, `$.update` | sources/effects — [client_runtime_core](client_runtime_core.md) |
| `$.derived`, `$.derived_safe_equal`, `$.async_derived`, `$.save` | `reactivity/deriveds.js`, `reactivity/async.js` |
| `$.prop`, rest/spread prop helpers | `reactivity/props.js` |
| `$.proxy`, `$.snapshot` | `proxy.js` |
| `$.assign`, `$.assign_and/or/nullish` | [client_dev_mode](client_dev_mode.md) `dev/assign.js` |
| `$.tag`, `$.tag_proxy`, `$.log_if_contains_state`, `$$ownership_validator` | `dev/tracing.js`, `dev/console-log.js`, `dev/ownership.js` |
| `$.effect_tracking`, `$.effect_root`, `$.pending` | `runtime.js` / `reactivity/effects.js` |
| `$.store_get`, `$.store_set`, `$.setup_stores` (referenced by hoisted `store_sub` params) | `reactivity/store.js` |

The `flags` bitmask consumed by `$.prop` is defined in `packages/svelte/src/compiler/constants.js` (`PROPS_IS_*`), forming a stable contract between compiler and runtime.

## 9. Design Notes & Invariants

- **Context flags must be reset at function boundaries.** `visit_function` clears `in_constructor`/`in_derived` so that, e.g., a `$derived` expression's thunk body reads fields raw, while code inside a derived *function* passed to `$derived.by` does not.
- **`build_getter` must not wrap declarations.** Without the `node !== binding.node` guard, `let count = $.state(0)` would recursively become `let count = $.get($.state(0))`.
- **Hoisted params are order- and dedup-sensitive.** `push_unique` avoids duplicate parameters; the `_` event-object param must come first for delegated event handlers; `$$props` is added both for simple prop reads and for runes-mode `rest_prop` because it is statically unknown whether the handler will touch rest props.
- **Server symmetry.** `AssignmentExpression` and `visit_assignment_expression` are shared with [compiler_server_transform](compiler_server_transform.md); only `build_assignment` and dev instrumentation are client-specific.
- **Immutable/legacy compatibility.** `create_derived` selects `$.derived_safe_equal` in legacy mode, and `is_state_source`/`is_prop_source` deliberately leave un-observable bindings as plain values — preserving Svelte 4 semantics where plain reassignment does not trigger updates without `$$invalidate`.

## 10. Related Modules

- [compiler_client_transform](compiler_client_transform.md) — parent module; orchestrates the three-pass walk and final assembly of the component function.
- [compiler_client_transform_templates](compiler_client_transform_templates.md) — template emission; consumes `build_getter` for expression attributes/text.
- [compiler_client_transform_control_flow_blocks](compiler_client_transform_control_flow_blocks.md) — `{#if}/{#each}/{#await}`; registers per-branch transforms and uses `create_derived` for memoization.
- [compiler_client_transform_elements_and_directives](compiler_client_transform_elements_and_directives.md) — element attributes, `bind:`, `on:`; relies on assignment suppression paths described in §5.5.
- [compiler_analyzer_scope](compiler_analyzer_scope.md) — bindings, scopes and `get_rune` detection.
- [client_runtime_core](client_runtime_core.md) and [client_dev_mode](client_dev_mode.md) — the runtime implementations of all emitted `$.` calls.
- [compiler_server_transform](compiler_server_transform.md) — SSR counterpart sharing the assignment infrastructure.
