# compiler_analyzer_template_visitors

Template-specific AST **visitor functions** for the Svelte compiler's analysis phase (`phases/2-analyze`). Each exported function handles exactly one node type from the template AST (`types/template.d.ts`) — content tags (`@const`, `@debug`, `{@html}`), attribute directives (`class:`, `style:`), and special elements (`svelte:*`, `<title>`, `<svelte:fragment>`). Visitors enforce template validity, and — just as importantly — **annotate the AST with metadata** (`ExpressionMetadata`, `Fragment.metadata.dynamic`) that later transform phases rely on to emit correct, fine-grained reactive code.

## Module Overview

| Aspect | Detail |
|---|---|
| Location | `packages/svelte/src/compiler/phases/2-analyze/visitors/` |
| Parent module | [compiler_analyzer](compiler_analyzer.md) |
| Sibling modules | [compiler_analyzer_block_visitors](compiler_analyzer_block_visitors.md) (control-flow blocks), [compiler_analyzer_js_visitors](compiler_analyzer_js_visitors.md) (JS/ESM nodes), [compiler_analyzer_scope](compiler_analyzer_scope.md) (scope management) |
| Consumes | Template AST from [compiler_parser](compiler_parser.md), scopes from [compiler_analyzer_scope](compiler_analyzer_scope.md), AST contracts from [compiler_types](compiler_types.md) |
| Produces | Validated AST + per-node metadata consumed by [compiler_client_transform](compiler_client_transform.md), [compiler_server_transform](compiler_server_transform.md), and [compiler_css_pipeline](compiler_css_pipeline.md) |
| Diagnostics | Raises compile errors from [compiler_diagnostics](compiler_diagnostics.md) via `errors.js` |
| Conventions | One function per file, named after the node type; the traversal engine dispatches by `node.type` |

## Architecture & Position in the Compiler Pipeline

This module is one of four visitor groups that together implement the semantic-analysis pass. `analyze_component` (in `2-analyze/index.js`) creates the scope tree, then `walk`s each of the module / instance / template ASTs with a visitor map. When a template node is reached, the walker looks up the visitor by node type, calls it with a zimmerframe `Context`, and the visitor decides whether to validate, mutate metadata, and how/whether to continue traversal.

```mermaid
flowchart LR
    subgraph P1["Phase 1 — Parse"]
        PARSE["parse / acorn<br/>(compiler_parser)<br/>template + JS/TS AST"]
    end

    subgraph P2["Phase 2 — Analyze (compiler_analyzer)"]
        AC["analyze_component<br/>scope creation, runes detection,<br/>walk() dispatch by node.type"]
        subgraph TM["template_visitors (this module)"]
            TV["ConstTag · DebugTag · HtmlTag<br/>ClassDirective · StyleDirective<br/>TitleElement · SvelteFragment<br/>SvelteBody · SvelteBoundary<br/>SvelteDocument · SvelteHead · SvelteWindow"]
        end
        subgraph SIB["Sibling visitor groups"]
            BV["block_visitors"]
            JV["js_visitors"]
            SCP["scope (set_scope)"]
        end
        CSSA["css-analyze"]
    end

    subgraph P3["Phase 3 — Transform"]
        CT["client_transform"]
        ST["server_transform"]
    end

    PARSE --> AC
    AC --> TV
    AC --> BV & JV & SCP
    TV --> CT & ST
    AC --> CSSA --> CT
```

### Component Interaction

All visitors share the same helper layer and error surface:

```mermaid
flowchart LR
    subgraph V["12 template visitors"]
        F["validate placement / attributes / content<br/>write metadata<br/>drive traversal"]
    end
    subgraph SH["visitors/shared/ helpers"]
        U1["validate_opening_tag"]
        U2["mark_subtree_dynamic"]
        U3["validate_slot_attribute"]
        U4["disallow_children"]
    end
    subgraph SUP["Supporting modules"]
        AST["utils/ast.js<br/>get_attribute_chunks · is_event_attribute"]
        ERR["errors.js<br/>(compiler_diagnostics)"]
    end
    F --> U1 & U2 & U3 & U4
    F --> AST
    F --> ERR
    U1 --> ERR
    U3 --> ERR
    U4 --> ERR
```

Helper responsibilities:

| Helper | Behaviour |
|---|---|
| `validate_opening_tag(node, state, '@')` | In runes mode, checks that the character after `<` in the source matches `@` (i.e. `{@const`, `{@debug`, `{@html}` are not confused with block syntax); raises `block_unexpected_character` marking only the first few characters to "avoid a sea of red". |
| `mark_subtree_dynamic(path)` | Walks backwards along `context.path` and sets `metadata.dynamic = true` on every ancestor `Fragment`, stopping early once one is already marked. |
| `validate_slot_attribute(context, attribute)` | Full slot-attribute validation: must be a static text attribute, correct placement relative to the owning component/custom element, no duplicate slot names (`state.component_slots`), and no competing default-slot content. |
| `disallow_children(node)` | Raises `svelte_meta_invalid_content` if the special element's fragment contains any nodes. |

## Visitor Dispatch Contract

Every visitor has the signature `(node: AST.<Type>, context: Context) => void`. The `Context` object (from the `zimmerframe` walker, see [compiler_analyzer](compiler_analyzer.md)) exposes the primitives used throughout this module:

| Context API | Usage in this module |
|---|---|
| `context.next(state?)` | Continue traversal into children, optionally replacing state. Used by nearly every visitor; `HtmlTag`, `ClassDirective` and `ConstTag` pass `{ ...context.state, expression: node.metadata.expression }` so nested expression visitors record state/call/await facts onto this node's `ExpressionMetadata`. `SvelteFragment` passes `parent_element: null` to reset element-context validation for children. |
| `context.visit(node, state?)` | Visit a specific child without continuing automatic traversal. `ConstTag` visits `declaration.id` and `declaration.init` explicitly. |
| `context.path` | Ancestor chain used for placement rules (e.g. `@const` grandparent whitelist, `svelte:fragment` parent check, slot ownership). |
| `context.state.scope` | Current `Scope` (built by [compiler_analyzer_scope](compiler_analyzer_scope.md)); used by `StyleDirective` shorthand to resolve the binding for the property name. |
| `context.state.analysis` | The `ComponentAnalysis` object; `analysis.runes` gates runes-only syntax checks, `analysis.source` is read by `validate_opening_tag`. |
| `context.state.component_slots` | Mutated by `validate_slot_attribute` to detect duplicate slot names. |

## Visitor Reference

### Content / rune tags

#### `ConstTag` — `{@const answer = 42}`
- Validates the `@` opening character in runes mode (`validate_opening_tag`).
- **Placement rule**: must be an *immediate* child of a `Fragment` whose grandparent is one of `IfBlock`, `SvelteFragment`, `Component`, `SvelteComponent`, `EachBlock`, `AwaitBlock`, `SnippetBlock`, `SvelteBoundary`, `KeyBlock`, or a `RegularElement`/`SvelteElement` carrying a `slot` attribute. Otherwise `e.const_tag_invalid_placement`.
- Traversal: visits `declaration.id`, then `declaration.init` with the node's own `metadata.expression` so the initializer's reactivity facts (`has_state`, `has_call`, `has_await`) accumulate on the tag.

#### `DebugTag` — `{@debug}`
- Runes-mode opening-character validation only; everything else is delegated with `context.next()`. Legacy mode accepts it unconditionally.

#### `HtmlTag` — `{@html expr}`
- Runes-mode opening-character validation.
- Calls `mark_subtree_dynamic` — raw HTML output cannot be part of a cached static template, so all ancestor fragments must be treated as dynamic.
- Continues traversal with the node's `metadata.expression` as the ambient expression.

### Attribute directives

#### `ClassDirective` — `class:name={value}`
- Marks the subtree dynamic (class toggling requires a runtime effect).
- Continues traversal with `node.metadata.expression`, collecting reactivity facts from the value expression. No errors are raised here.

#### `StyleDirective` — `style:prop={value}` / `style:prop`
- **Modifier validation**: at most one modifier and only `important`; otherwise `e.style_directive_invalid_modifier`.
- Marks the subtree dynamic.
- **Shorthand form** (`style:prop` with `value === true`): looks up the binding named `prop` in the current scope; if the binding's kind is not `'normal'` (i.e. it is reactive — prop, state, derived, store sub, …), sets `metadata.expression.has_state = true` directly without visiting children.
- **Value form**: visits children (`context.next()`), then aggregates `has_state` / `has_call` / `has_await` from every `ExpressionTag` chunk of the attribute value (`get_attribute_chunks`).

```mermaid
flowchart TD
    A["StyleDirective visitor"] --> B{"modifiers valid?<br/>(max 1, only 'important')"}
    B -- no --> E1["e.style_directive_invalid_modifier"]
    B -- yes --> C["mark_subtree_dynamic(path)"]
    C --> D{"value === true ? (shorthand)"}
    D -- yes --> F["scope.get(node.name)"]
    F --> G{"binding.kind !== 'normal'?"}
    G -- yes --> H["metadata.expression.has_state = true"]
    G -- no --> I["done"]
    D -- no --> J["context.next() — visit value chunks"]
    J --> K["aggregate chunk metadata.expression<br/>has_state / has_call / has_await"]
```

### Special elements

| Visitor | Attribute rules | Content rules | Other effects |
|---|---|---|---|
| `TitleElement` (`<title>`) | *All* attributes rejected → `title_illegal_attribute` | Only `Text` and `ExpressionTag` children allowed → `title_invalid_content` | — |
| `SvelteBody` (`svelte:body`) | No `SpreadAttribute`, no non-event `Attribute` → `svelte_body_illegal_attribute` | Children disallowed via `disallow_children` → `svelte_meta_invalid_content` | — |
| `SvelteDocument` (`svelte:document`) | No `SpreadAttribute`, no non-event `Attribute` → `illegal_element_attribute` | Children disallowed → `svelte_meta_invalid_content` | — |
| `SvelteWindow` (`svelte:window`) | No `SpreadAttribute`, no non-event `Attribute` → `illegal_element_attribute` | Children disallowed → `svelte_meta_invalid_content` | — |
| `SvelteHead` (`svelte:head`) | *All* attributes rejected → `svelte_head_illegal_attribute` | Children allowed | `mark_subtree_dynamic` (head content is rendered out-of-band) |
| `SvelteBoundary` (`svelte:boundary`) | Only `onerror`, `failed`, `pending` → `svelte_boundary_invalid_attribute` | Children allowed | Value must be a single `ExpressionTag` → `svelte_boundary_invalid_attribute_value` |
| `SvelteFragment` (`svelte:fragment`) | Parent must be `Component`/`SvelteComponent` → `svelte_fragment_invalid_placement`; only `slot` `Attribute` or `LetDirective` allowed → `svelte_fragment_invalid_attribute` | Children allowed | `slot` attribute fully validated via `validate_slot_attribute`; resets `parent_element: null` for children |

`is_event_attribute` (attribute value is an expression and name starts with `on`) is what makes `onclick={...}`-style attributes legal on `svelte:body` / `svelte:window` / `svelte:document` while everything else is rejected.

### SvelteFragment slot-validation flow

```mermaid
sequenceDiagram
    participant W as walk (zimmerframe)
    participant SF as SvelteFragment
    participant SA as validate_slot_attribute
    participant ST as state.component_slots
    participant E as errors.js
    W->>SF: visit(node, context)
    SF->>E: svelte_fragment_invalid_placement (parent not Component/SvelteComponent)
    SF->>SF: reject non-slot / non-let attributes
    SF->>SA: validate_slot_attribute(context, 'slot' attribute)
    SA->>E: slot_attribute_invalid (value not static text)
    SA->>ST: add(name) → duplicate? → slot_attribute_duplicate
    SA->>E: slot_default_duplicate (content competing with default slot)
    SF->>W: context.next({...state, parent_element: null})
```

## Data Flow: Metadata Production → Transform Consumption

The defining output of this module is not just validation — it is the **metadata** written onto AST nodes during analysis. These flags are the contract between analysis and code generation:

```mermaid
flowchart TD
    subgraph A["2-analyze (this module)"]
        V1["HtmlTag · ClassDirective · StyleDirective · SvelteHead<br/>mark_subtree_dynamic()"] --> FD["ancestor Fragment.metadata.dynamic = true"]
        V2["ConstTag / HtmlTag / ClassDirective<br/>visit children with expression metadata"] --> EM["node.metadata.expression<br/>has_state · has_call · has_await"]
        V3["StyleDirective<br/>binding-kind check + chunk aggregation"] --> EM
        V4["SvelteFragment<br/>validate_slot_attribute"] --> CS["state.component_slots (duplicate detection)"]
    end

    subgraph B["2-analyze post-processing (analyze_component)"]
        PP["synthetic empty class/style attributes appended to elements<br/>that have ClassDirective / StyleDirective but no class/style attribute<br/>(and scoped-CSS custom elements re-marked dynamic)"]
    end

    subgraph C["3-transform"]
        CT["client_transform:<br/>template caching, set_class/set_style effects,<br/>fine-grained reactive updates"]
        ST["server_transform:<br/>SSR string emission, attribute value building"]
    end

    FD --> CT
    EM --> CT & ST
    CS --> CT
    V1 -.elements reported to analysis.elements.-> PP
    PP --> CT
```

Concretely:
- `Fragment.metadata.dynamic` decides whether a fragment can be compiled into a cached static template or needs runtime cloning — a core performance lever in [compiler_client_transform](compiler_client_transform.md).
- `metadata.expression.has_state` gates whether a directive becomes a static attribute assignment or a reactive `set_class` / `set_style` / `set_html` effect.
- `has_call` / `has_await` inform async/rune handling in both client and server transforms (see [compiler_client_transform](compiler_client_transform.md), [compiler_server_transform](compiler_server_transform.md)).
- Slot validation results (`component_slots`, duplicate-default detection) protect the slot-resolution logic in the render back-ends.

## Error & Diagnostics Contract

All errors are compile errors from `errors.js` (module [compiler_diagnostics](compiler_diagnostics.md)). Summary per visitor:

| Visitor | Errors raised (directly or via helpers) |
|---|---|
| `ConstTag` | `const_tag_invalid_placement`, `block_unexpected_character` |
| `DebugTag` | `block_unexpected_character` |
| `HtmlTag` | `block_unexpected_character` |
| `ClassDirective` | — |
| `StyleDirective` | `style_directive_invalid_modifier` |
| `TitleElement` | `title_illegal_attribute`, `title_invalid_content` |
| `SvelteFragment` | `svelte_fragment_invalid_placement`, `svelte_fragment_invalid_attribute`, `slot_attribute_invalid`, `slot_attribute_invalid_placement`, `slot_attribute_duplicate`, `slot_default_duplicate` |
| `SvelteBody` | `svelte_body_illegal_attribute`, `svelte_meta_invalid_content` |
| `SvelteBoundary` | `svelte_boundary_invalid_attribute`, `svelte_boundary_invalid_attribute_value` |
| `SvelteDocument` | `illegal_element_attribute`, `svelte_meta_invalid_content` |
| `SvelteHead` | `svelte_head_illegal_attribute` |
| `SvelteWindow` | `illegal_element_attribute`, `svelte_meta_invalid_content` |

## Typical Invocation Flow (end to end)

```mermaid
sequenceDiagram
    participant AC as analyze_component
    participant W as walk (zimmerframe)
    participant HT as HtmlTag visitor
    participant MS as mark_subtree_dynamic
    participant CH as child visitors (ExpressionTag etc.)
    participant TR as 3-transform
    AC->>W: walk(template.ast, state, visitors)
    W->>HT: dispatch on type 'HtmlTag'
    HT->>AC: read state.analysis.runes → validate_opening_tag
    HT->>MS: mark_subtree_dynamic(context.path)
    MS-->>HT: ancestor Fragments flagged dynamic
    HT->>CH: context.next({...state, expression: node.metadata.expression})
    CH-->>HT: has_state / has_call / has_await recorded on metadata.expression
    HT-->>W: return; traversal continues
    W-->>AC: analysis complete
    AC->>TR: analysis + annotated AST
```

## Extension Notes for Maintainers

- **Adding a new template node type**: create `visitors/<NodeType>.js` exporting a function named exactly like the node type; it is picked up by the visitor map assembled in `2-analyze/index.js`. Raise errors via `errors.js` (see the generated-code pipeline in `scripts/process-messages/templates/compile-errors.js`) and never throw raw `Error`s.
- **Placement rules** should be expressed via `context.path` checks like `ConstTag`/`SvelteFragment` do — keep the "grandparent whitelist" pattern so error messages point at the offending node.
- **Reactivity metadata** is additive: when visiting children with overridden state, always spread `{ ...context.state, expression: node.metadata.expression }` so nested visitors can report `has_state`/`has_call`/`has_await` upward; forgetting this silently breaks fine-grained updates in the transforms.
- **Runes-gated syntax checks**: any new rune-flavoured tag must call `validate_opening_tag(node, context.state, '@')` under `context.state.analysis.runes` for consistent diagnostics.
- Related documentation: [compiler_analyzer](compiler_analyzer.md) (orchestration), [compiler_analyzer_block_visitors](compiler_analyzer_block_visitors.md), [compiler_analyzer_js_visitors](compiler_analyzer_js_visitors.md), [compiler_analyzer_scope](compiler_analyzer_scope.md), [compiler_parser](compiler_parser.md) (upstream AST), [compiler_types](compiler_types.md) (`template.d.ts` node shapes), [compiler_css_pipeline](compiler_css_pipeline.md) (consumes `analysis.elements` flagged by these visitors), [compiler_client_transform](compiler_client_transform.md) and [compiler_server_transform](compiler_server_transform.md) (downstream consumers).
