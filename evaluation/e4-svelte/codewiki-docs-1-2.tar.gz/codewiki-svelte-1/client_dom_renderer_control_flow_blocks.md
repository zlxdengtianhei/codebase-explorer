# Client DOM Renderer — Control Flow Blocks

> **Module:** `client_dom_renderer_control_flow_blocks`
> **Location:** `packages/svelte/src/internal/client/dom/blocks/`
> **Parent:** [client_dom_renderer](client_dom_renderer.md)

## 1. Introduction

This module is the **runtime counterpart of Svelte 5's template control structures**. The compiler
(see [compiler_client_transform_control_flow_blocks](compiler_client_transform_control_flow_blocks.md))
emits calls into this module — `$.if`, `$.each`, `$.key`, `$.await`, `$.boundary`, `$.snippet`,
`$.slot`, `$.html`, `$.element`, `$.head`, `$.async`, `$.css_props` — and these functions are
responsible for actually **creating, swapping, reconciling and destroying DOM** in response to
reactive change, both during initial mount and during hydration of server-rendered markup.

Every block in this module follows the same core contract:

1. **Anchor-based rendering** — content is inserted before an anchor `Text`/`Comment` node, never
   relying on parent-relative positions, so branches can be moved/removed safely.
2. **Effect-scoped content** — each rendered branch is wrapped in a *branch effect*
   (`branch()` from the effects engine), so its DOM range and child effects can be paused, resumed
   or destroyed as a unit.
3. **Batch-aware commits** — in async mode, DOM mutations may be staged offscreen and committed at
   the end of the current [Batch](client_runtime_core_batching.md) to avoid torn intermediate states.
4. **Hydration-protocol compliance** — blocks read hydration instruction comments
   (`<!---->`-style markers emitted by SSR), consume/verify them, and can *recover* from a
   hydration mismatch by discarding server DOM and rendering fresh.

### Component inventory

| File | Exports | Purpose |
|---|---|---|
| `if.js` | `if_block`, `set_branch` (callback) | `{#if}` / `{:else if}` / `{:else}` conditional rendering |
| `each.js` | `each`, `index`, `current_each_item`, `set_current_each_item` | `{#each}` keyed list rendering with full reconciliation |
| `key.js` | `key` | `{#key}` — destroy & recreate content when the key changes |
| `await.js` | `await_block` | `{#await}` — PENDING/THEN/CATCH promise rendering |
| `async.js` | `async` | Runtime support for `await` expressions inside template blocks |
| `boundary.js` | `boundary`, `Boundary` class, `get_pending_boundary`, `pending` | `<svelte:boundary>` error handling, pending/outro state, `$effect.pending()` |
| `snippet.js` | `snippet`, `wrap_snippet`, `createRawSnippet` | `{#snippet}` / `{@render}` and programmatic raw snippets |
| `slot.js` | `slot`, `sanitize_slots` | `<slot>` rendering incl. snippet interop |
| `html.js` | `html` | `{@html ...}` raw HTML injection (svg/mathml aware) |
| `svelte-element.js` | `element` | `<svelte:element this={...}>` dynamic tag rendering |
| `svelte-head.js` | `head`, `reset_head_anchor` | `<svelte:head>` rendering into `document.head` |
| `css-props.js` | `css_props` | `--style-props` blocks that apply CSS custom properties |

---

## 2. Architecture

### 2.1 Position in the system

The blocks sit between the **compiler-generated component code** (which decides *when* and *with
which arguments* to render) and the **reactive runtime + DOM foundation** (which provide the
mechanisms for *how* to render).

```mermaid
flowchart TB
    subgraph Compiler["Compiler Back-End"]
        GEN["Compiler-generated component code<br/>$.if / $.each / $.key / $.await / ..."]
    end

    subgraph Lifecycle["Lifecycle API"]
        MOUNT["mount()"]
        HYD_API["hydrate()"]
    end

    subgraph ThisModule["Control Flow Blocks (this module)"]
        IF["if.js"]
        EACHF["each.js"]
        KEYF["key.js"]
        AWAITF["await.js"]
        ASYNCF["async.js"]
        BNDF["boundary.js"]
        SNIPF["snippet.js"]
        SLOT["slot.js"]
        HTMLF["html.js"]
        ELEMF["svelte-element.js"]
        HEADF["svelte-head.js"]
        CSSPF["css-props.js"]
    end

    subgraph Runtime["Reactive Runtime Core"]
        EFF["effects engine<br/>block / branch / pause / resume / destroy"]
        SIG["sources &amp; deriveds<br/>source / internal_set / get"]
        BATCH["Batch scheduler<br/>add_callback / skipped_effects"]
        CTX["context / flags<br/>component_context / is_runes / async_mode_flag"]
    end

    subgraph Foundation["DOM Foundation"]
        HYD["hydration.js<br/>hydrate_next / instructions / mismatch recovery"]
        OPS["operations.js<br/>create_text / should_defer_append / get_first_child"]
        TMPL["template.js<br/>assign_nodes"]
        REC["reconciler.js<br/>create_fragment_from_html"]
    end

    GEN -->|invokes at runtime| ThisModule
    MOUNT -->|runs component init effects| ThisModule
    HYD_API -->|enters hydration mode| ThisModule
    ThisModule --> Runtime
    ThisModule --> Foundation
```

### 2.2 Internal structure — block families

The twelve files group into six functional families. Dotted arrows show the notable *intra-module*
dependencies.

```mermaid
flowchart LR
    subgraph Cond["Conditionals"]
        IF["if.js"]
        KEYF["key.js"]
    end

    subgraph Lists["Lists"]
        EACHF["each.js"]
    end

    subgraph AsyncGrp["Async"]
        AWAITF["await.js"]
        ASYNCF["async.js"]
    end

    subgraph ErrGrp["Boundaries"]
        BNDF["boundary.js"]
    end

    subgraph Content["Content &amp; Composition"]
        SNIPF["snippet.js"]
        SLOT["slot.js"]
        HTMLF["html.js"]
    end

    subgraph DynGrp["Dynamic Elements"]
        ELEMF["svelte-element.js"]
        HEADF["svelte-head.js"]
        CSSPF["css-props.js"]
    end

    ASYNCF -.->|get_pending_boundary<br/>update_pending_count| BNDF
    AWAITF -.->|uses hydration<br/>instructions| IF
    ELEMF -.->|current_each_item<br/>for animate: directives| EACHF
    SLOT -.->|slot fns are<br/>snippet-shaped| SNIPF
    HTMLF --> REC
    SNIPF --> REC
```

### 2.3 Shared runtime contracts

All blocks are built on four services. Details live in their own docs; only the block-facing
contract is summarized here.

| Service | Contract used by this module |
|---|---|
| **Effects engine** ([client_runtime_core_effects](client_runtime_core_effects.md)) | `block(fn, flags)` creates a *re-runnable* reactive container; `branch(fn)` creates a content subtree whose DOM range is tracked via `nodes_start`/`nodes_end`; `pause_effect` runs out-transitions then destroys; `resume_effect` resurrects a paused branch; `destroy_effect` tears down immediately. |
| **Signals** ([client_runtime_core_sources](client_runtime_core_sources.md), [client_runtime_core_deriveds](client_runtime_core_deriveds.md)) | `source`/`mutable_source` + `internal_set` let blocks push per-item values (`each` items, `await` resolved values) into the reactive graph; `derived_safe_equal` normalizes the `each` collection; `get()` reads inside the block effect so dependencies are captured. |
| **Batching** ([client_runtime_core_batching](client_runtime_core_batching.md)) | `Batch.add_callback(commit)` defers DOM commits; `batch.skipped_effects.add(effect)` excludes outgoing branches from the current traversal so they are not updated on their way out. |
| **Hydration protocol** ([client_dom_renderer_dom_foundation](client_dom_renderer_dom_foundation.md)) | `hydrating` flag + `hydrate_node` cursor; `hydrate_next()` consumes one SSR node; instruction comments (`HYDRATION_START`, `HYDRATION_START_ELSE`, `HYDRATION_END`, empty `""` for `{@html}`) are read via `read_hydration_instruction`. |

**Effect lifecycle used by every branch-owning block:**

```mermaid
stateDiagram-v2
    direction LR
    [*] --> Active: branch(fn) — effect created, DOM inserted before anchor
    Active --> Paused: pause_effect — out-transitions run
    Paused --> Active: resume_effect — branch re-activated
    Active --> Destroyed: destroy_effect — immediate teardown
    Paused --> Destroyed: out-transitions complete, callback fires
    Destroyed --> [*]: DOM removed, signals disconnected
```

---

## 3. Component Reference

### 3.1 `if.js` — Conditional Rendering (`{#if}`)

```js
if_block(node, fn, elseif = false)
```

The compiler generates a single callback `fn($$render)` that calls the injected `set_branch`
callback: `set_branch(consequent)` for truthy, `set_branch(alternate, false)` for falsy, and
possibly nothing at all.

Key mechanics:

- **Lazy branch creation** — `consequent_effect ??= branch(...)` / `alternate_effect ??= branch(...)`:
  a branch that has never been shown does not exist yet.
- **Change detection** — `update_branch` early-returns when the condition did not flip
  (`if (condition === (condition = new_condition)) return;`).
- **`elseif` flag** — sets `EFFECT_TRANSPARENT` so that `{:else if}` chains share the outer
  `{#if}`'s transition locality (a nested `if` block would localize transitions differently —
  this distinction is deliberate in the compiler, see
  [compiler_client_transform_control_flow_blocks](compiler_client_transform_control_flow_blocks.md)).
- **`commit()`** — resumes the active branch, pauses the inactive one and nulls its reference in
  the pause callback so memory is reclaimed after out-transitions finish.
- **No branch set** — if the generated code never calls `set_branch`, the block renders nothing
  (`update_branch(null, null)`).

```js
// shape of the compiler-generated callback
fn((branch) => {
  if (test) branch(consequent);        // flag defaults to true
  else branch(alternate, false);
});
```

### 3.2 `each.js` — Keyed List Rendering (`{#each}`)

```js
each(node, flags, get_collection, get_key, render_fn, fallback_fn = null)
index(_, i) // trivial key fn for index-keyed lists
```

This is the most complex block. State model:

- **`EachState`** — `{ flags, items: Map<key, EachItem>, first }`. `items` is the authoritative
  key→item map; `first` anchors a doubly-linked list of items.
- **`EachItem`** — `{ i, v, k, a, e, prev, next }`: reactive index and value sources, key,
  optional animation manager (`a`, for `animate:` directives), and the item's branch effect `e`.
- **Collection derived** — `derived_safe_equal(() => normalize(get_collection()))` handles
  array-likes, `null`/`undefined`, and non-array iterables; `safe_equal` prevents redundant
  reconciliations (important because stores can be mutated in place).

**Flags** (see `constants.js`):

| Flag | Meaning |
|---|---|
| `EACH_ITEM_REACTIVE` | item value is a `Source`; updates flow via `internal_set` |
| `EACH_INDEX_REACTIVE` | index is a `Source` (else a plain number is patched) |
| `EACH_ITEM_IMMUTABLE` | items treated as immutable — skips `mutable_source` |
| `EACH_IS_CONTROLLED` | the block renders directly inside its parent element ("controlled" anchor fast path) |
| `EACH_IS_ANIMATED` | `animate:` directives are present; measure/fix/apply choreography |

**Fallback (`{:else}`)** — `fallback_fn` is branched when `array.length === 0` and paused once
items exist again.

**`current_each_item`** — a module-level pointer set during `create_item` so
`<svelte:element>` ([svelte-element.js](#310-svelte-elementjs--dynamic-elements-svelteelement)) and
transition managers can associate themselves with the enclosing keyed item.

### 3.3 `key.js` — Keyed Invalidation (`{#key}`)

```js
key(node, get_key, render_fn)
```

Compares the current key with the previous one using `not_equal` (runes mode) or
`safe_not_equal` (legacy mode). On change, the old branch is paused and a fresh branch is created —
either synchronously via `commit()` or offscreen + `batch.add_callback(commit)` in deferred
(async) mode. Structurally identical to `if_block`, but keyed on an arbitrary value rather than a
boolean.

### 3.4 `await.js` — Promise Blocks (`{#await}`)

```js
await_block(node, get_input, pending_fn, then_fn, catch_fn)
```

Internal tri-state: `PENDING = 0`, `THEN = 1`, `CATCH = 2`.

- The resolved value / error is written into `input_source` / `error_source`
  (`source` in runes mode, `mutable_source` otherwise) which are handed to the `then_fn` /
  `catch_fn` callbacks.
- `update(state, restore)` swaps the three branch effects: resumes the branch for the new state,
  pauses the others, then calls **`flushSync()`** so the DOM updates on the same tick as the
  promise settles (avoids the "two ticks late" surprise).
- **Context restoration** — when a promise resolves asynchronously, `set_active_effect`,
  `set_active_reaction`, `set_component_context` (and dev-mode component function + dev stack) are
  restored around the branch swap so transitions/dev tooling observe the right context, then
  cleared again.
- **Pending debounce** — in non-hydration mode, `update(PENDING)` runs in a *microtask*; if the
  promise already resolved by then, the pending flash is skipped (`resolved` flag).
- **Stale promise guard** — resolution callbacks check `promise !== input` and bail if the input
  expression re-evaluated meanwhile; the block effect teardown returns a cleanup that resets
  `input` to `UNINITIALIZED`, neutering in-flight callbacks on destroy.
- **Uncaught rejection** — if the promise rejects and no `catch_fn` exists, the error is re-thrown
  from the resolution callback (surfacing to the nearest `<svelte:boundary>` or global handler).

```mermaid
stateDiagram-v2
    [*] --> Evaluating: block effect runs, input = get_input()
    Evaluating --> THEN: input is a plain value (synchronous)
    Evaluating --> PENDING: input is a promise (microtask delay)
    Evaluating --> THEN: hydration matched then-branch
    PENDING --> THEN: promise resolves → internal_set(input_source)
    PENDING --> CATCH: promise rejects → internal_set(error_source)
    THEN --> Evaluating: get_input() changes
    CATCH --> Evaluating: get_input() changes
    CATCH --> CATCH: rethrown if no catch_fn provided
    THEN --> [*]: unmount / pause
    CATCH --> [*]: unmount / pause
```

### 3.5 `async.js` — `await` Expressions in Template Blocks

```js
async(node, expressions, fn)
```

When any expression inside a control-flow block header contains `await` (e.g. `{#if await x}`),
the compiler routes rendering through this helper instead of evaluating inline:

1. Finds the nearest boundary **with a pending snippet** via `get_pending_boundary()` (throws
   `await_outside_boundary` if none exists).
2. Increments that boundary's pending count → the pending UI shows.
3. Uses `flatten()` from the async reactivity helpers ([client_runtime_core_async](client_runtime_core_async.md))
   to create async deriveds for each expression.
4. Once all values resolve, **eagerly `get()`s each derived** — so a rejection surfaces as an
   error inside the boundary rather than half-rendering the block — and only then calls `fn(node, ...values)`.
5. Decrements the pending count in a `finally`, hiding the pending UI.

### 3.6 `boundary.js` — `<svelte:boundary>` (Error + Pending)

`boundary(node, props, children)` instantiates the `Boundary` class. Its effect carries
`EFFECT_TRANSPARENT | EFFECT_PRESERVED | BOUNDARY_EFFECT`, and it registers itself as
`active_effect.b` so descendants can find it.

Responsibilities:

- **Main branch** — `#main_effect` wraps `children`. Created synchronously in client mounts; during
  hydration with a pending snippet it is deferred via `Batch.enqueue` so the pending UI paints first.
- **Pending management** — `#pending_count` is incremented by `async` blocks and async deriveds.
  `update_pending_count(d)` **propagates up to the parent boundary** when this boundary has no
  pending snippet of its own. Reaching zero pauses the pending effect and re-inserts the offscreen
  main content (`#offscreen_fragment`).
- **`$effect.pending()`** — `get_effect_pending()` lazily creates a `Source<number>` via
  `createSubscriber` (only if someone actually reads it, avoiding no-op batch flushes), tagged for
  dev tracing.
- **Error handling** — `error(error)`:
  1. Destroys main/pending/failed effects.
  2. During hydration, rewinds the cursor to the boundary's opening comment and strips the
     partially-hydrated server DOM.
  3. Re-throws **unless** an `onerror` or `failed` prop exists — or unless the failure happened
     while rendering the fallback itself (`#is_creating_fallback`), which prevents infinite loops.
  4. Calls `onerror(error, reset)` **with `active_reaction` set to `null`** so signal writes inside
     the handler cannot be attributed to the dying effect.
  5. Queues `failed(anchor, () => error, () => reset)` rendering in a microtask; errors inside the
     fallback go to the *parent* boundary.
  6. `reset()` re-runs `children`; a second reset warns (`svelte_boundary_reset_noop`), and calling
     `reset` from inside `onerror` throws (`svelte_boundary_reset_onerror`).

`get_pending_boundary()` walks `active_effect.b` up the boundary chain looking for one with a
pending snippet; `pending()` implements `$effect.pending()`.

```mermaid
flowchart TD
    A["Error thrown while rendering children"] --> B["Boundary.error(error)"]
    B --> C["destroy main / pending / failed effects"]
    C --> D{"hydrating?"}
    D -->|yes| E["rewind hydration cursor, remove SSR nodes"]
    D -->|no| F{"has onerror or failed prop?"}
    E --> F
    F -->|no| G["rethrow to parent boundary / global handler"]
    F -->|yes| H["onerror(error, reset) — reaction cleared"]
    H --> I{"failed snippet?"}
    I -->|yes| J["microtask: render failed(anchor, error, reset)"]
    I -->|no| K["done — error handled"]
    J --> K
    H --> L["reset() invoked by user"]
    L --> M["pause failed effect, re-run children,<br/>restore pending state if needed"]
```

### 3.7 `snippet.js` — Snippets (`{#snippet}` / `{@render}` / `createRawSnippet`)

- **`snippet(node, get_snippet, ...args)`** — a transparent block effect that tracks the *snippet
  function identity*: when `get_snippet()` returns a different function, the old branch effect is
  destroyed and a new one created. Dev-mode throws `invalid_snippet` when the snippet is
  `null`/`undefined`.
- **`wrap_snippet(component, fn)`** — dev-only wrapper that sets
  `dev_current_component_function` around invocation (ownership validation, better error
  attribution) and prevents snippet stringification
  (see [shared_runtime](shared_runtime.md) `prevent_snippet_stringification`).
- **`createRawSnippet(fn)`** — programmatic API (used by e.g. component wrappers): calls
  `fn(...params)` → `{ render, setup }`, parses `render()` HTML via `create_fragment_from_html`,
  inserts the root element before the anchor, validates in dev that the render output is exactly
  one element (`invalid_raw_snippet_render`), runs `setup(element)` and registers the returned
  teardown via `teardown()`. During hydration it adopts the existing `hydrate_node` element.

### 3.8 `slot.js` — Slots (`<slot>`)

- **`slot(anchor, $$props, name, slot_props, fallback_fn)`** — resolves
  `$$props.$$slots[name]`. Handles **snippet interop**: legacy components receive `slot_fn === true`
  when filled by a snippet, in which case the function is looked up on props
  (`children` for `default`, the prop name otherwise) and slot props are passed as a getter.
  Falls back to `fallback_fn` when unfilled. Render-time only — no effect of its own; the slot
  content's own reactivity comes from the invoked snippet/component.
- **`sanitize_slots(props)`** — builds `{ [name]: true }` for present slots (`children` ⇒
  `default`), used for validation warnings about unknown/missing slots.

### 3.9 `html.js` — Raw HTML Injection (`{@html}`)

```js
html(node, get_value, svg, mathml, skip_warning)
```

Runs inside a `template_effect`. On value change:

1. Removes the previously assigned DOM range via `remove_effect_dom` + resets the effect's node
   boundaries (`assign_nodes` contract from [template.js](client_dom_renderer_dom_foundation.md)).
2. **Hydration path** — walks sibling nodes from the hydration cursor until the sentinel *empty
   comment* (`data === ''`); mismatches throw `HYDRATION_ERROR`. In dev, `check_hash` compares the
   SSR content hash comment against `hash(value)` and warns `hydration_html_changed` (with source
   location when available) instead of attempting repair — `{@html}` mismatches are deliberately
   not reconciled.
3. **Client path** — wraps in `<svg>`/`<math>` when needed, parses with
   `create_fragment_from_html` (scripts are **not** executed, matching `.innerHTML` semantics),
   then inserts before the anchor and assigns first/last nodes to the effect.

### 3.10 `svelte-element.js` — Dynamic Elements (`<svelte:element>`)

```js
element(node, get_tag, is_svg, render_fn, get_namespace, location)
```

A transparent block effect that re-renders whenever the tag (or namespace) changes:

| Situation | Behavior |
|---|---|
| Tag → `null` (`this={undefined}`) | `pause_effect` — element *outros* rather than vanishing |
| Same tag re-asserted during outro | `resume_effect` — aborts the outro |
| Tag → different tag | `destroy_effect` immediately + `set_should_intro(false)` so the replacement mounts without intro transitions |
| SVG context | `document.createElementNS(NAMESPACE_SVG, tag)` (assumption: namespace never changes independently of tag) |

Other details:

- Preserves `current_each_item` across re-runs so `animate:` directives bind to the right keyed item.
- Dev: attaches `element.__svelte_meta` with file/line/column from the `location` argument for
  `{@html}` hash warnings and dev tooling.
- Hydration: adopts the existing SSR element; for raw-text elements (`<textarea>`, `<title>`, ...)
  appends a throwaway comment to keep the hydration cursor consistent; void elements still invoke
  `render_fn` (for actions etc.) even though children would be invalid.

### 3.11 `svelte-head.js` — Head Rendering (`<svelte:head>`)

```js
head(render_fn)
```

- Maintains a module-level `head_anchor` cursor because an app may contain *multiple* head blocks
  that each hydrate an independent region of `document.head`.
- Hydration: scans forward from `head_anchor` for the next `HYDRATION_START` comment; if none is
  found (e.g. head was rendered by a different framework), falls back to plain append and disables
  hydration mode locally, restoring it in `finally`.
- Client render: appends a `Text` anchor to `document.head` and renders into a block effect flagged
  `HEAD_EFFECT` (so unmount knows to clean head content).
- `reset_head_anchor()` is called by `hydrate()` (see
  [client_dom_renderer_lifecycle_api](client_dom_renderer_lifecycle_api.md)) after each hydration
  run so subsequent mounts start scanning from the beginning of `<head>`.

### 3.12 `css-props.js` — CSS Custom Property Blocks

```js
css_props(element, get_styles)
```

Implements the runtime side of `--css-props` style blocks (from scoped CSS `--property:
{ value }` declarations produced by the CSS pipeline, see
[compiler_css_pipeline_analysis](compiler_css_pipeline_analysis.md)). During hydration it skips
past the marker comment child; a `render_effect` then applies each style property with
`element.style.setProperty` / `removeProperty` reactively.

---

## 4. Process Flows

### 4.1 Conditional branch switch (`if_block`)

```mermaid
sequenceDiagram
    autonumber
    participant Sig as Source signal
    participant BE as block effect (if_block)
    participant Gen as Generated callback fn
    participant BR as branch effects
    participant B as current Batch
    participant DOM as Document

    Sig->>BE: dependency changed (dirty)
    BE->>Gen: re-run fn(set_branch)
    Gen->>BE: set_branch(consequentFn) or set_branch(alternateFn, false)
    BE->>BE: update_branch — did condition flip?
    alt unchanged
        BE-->>Sig: no-op return
    end
    alt async mode AND effect already ran (should_defer_append)
        BE->>DOM: build offscreen DocumentFragment, render new branch into it
        BE->>B: skipped_effects.add(inactive branch)
        BE->>B: add_callback(commit)
        Note over B,DOM: batch commits: fragment inserted,<br/>old branch removed in one frame
    else sync mode
        BE->>BE: commit() immediately
    end
    BE->>BR: resume_effect(active branch)
    BE->>BR: pause_effect(inactive branch) — out-transitions, then destroy
```

### 4.2 Each-block update & reconciliation

```mermaid
flowchart TD
    A["block effect re-runs"] --> B["array = get(each_array)"]
    B --> C{"hydrating?"}
    C -->|yes| D["hydrate items in order until<br/>HYDRATION_END comment or end of array;<br/>mismatch → remove_nodes() + client render"]
    C -->|no| E{"should_defer_append?"}
    E -->|yes, async mode| F["create/update items offscreen;<br/>mark outgoing items in batch.skipped_effects;<br/>batch.add_callback(commit)"]
    E -->|no| G["commit() now"]
    D --> H
    F --> H["commit(): reconcile(...)"]
    G --> H
    H --> I{"key present in state.items?"}
    I -->|yes| J["update_item if ITEM/INDEX_REACTIVE;<br/>resume if it was inert (outroing)"]
    J --> K{"item out of position?"}
    K -->|yes| L["move DOM nodes between anchors;<br/>relink prev/next (matched/stashed strategy)"]
    K -->|no| M["advance cursor"]
    I -->|new key, offscreen pending| N["promote from offscreen_items, move into place"]
    I -->|new key, unseen| O["create_item: sources + branch effect"]
    H --> P["items not in new array → pause_effects:<br/>out-transitions, unlink, destroy"]
    P --> Q{"EACH_IS_ANIMATED?"}
    Q -->|yes| R["measure/fix before moves,<br/>apply FLIP animations in microtask"]
    L --> S["update each_effect.first/last"]
    M --> S
    N --> S
    O --> S
    R --> S
```

Notable sub-behaviors:

- **Controlled fast path** — when `EACH_IS_CONTROLLED` and the array empties, the parent element is
  wiped with `clear_text_content` in one operation and the anchor re-appended, instead of removing
  items one by one.
- **First-run graph consistency** — after reconcile, `get(each_array)` is read again: during mount
  the effect wasn't subscribed yet, and a mutation during creation could have left deriveds
  `MAYBE_DIRTY`; the extra read re-establishes a `CLEAN` graph.
- **Empty-array short circuit** — `was_empty` skips all work when nothing changed.

### 4.3 Async block + boundary coordination (`async.js` ⇄ `boundary.js`)

```mermaid
sequenceDiagram
    autonumber
    participant Gen as Generated block code
    participant AS as async()
    participant FL as flatten()
    participant BND as nearest pending Boundary
    participant DOM as Document

    Gen->>AS: async(node, [await-expr thunks], render_fn)
    AS->>BND: get_pending_boundary()
    AS->>BND: update_pending_count(+1) → show pending UI
    AS->>FL: flatten([], expressions, callback)
    FL->>FL: async_derived per expression, Promise.all
    alt all resolve
        FL->>AS: callback(values)
        AS->>AS: eagerly get() each derived (reject early)
        AS->>Gen: fn(node, ...values) — real content renders
    else rejection
        FL->>BND: boundary.error(error) → onerror / failed snippet
    end
    AS->>BND: finally: update_pending_count(-1) → hide pending UI
```

### 4.4 Hydration mismatch recovery (shared pattern)

`if_block`, `each` and `await_block` all implement the same recovery protocol:

```mermaid
flowchart TD
    A["Entering block update while hydrating"] --> B["read_hydration_instruction(anchor)"]
    B --> C{"Instruction matches<br/>expected shape?"}
    C -->|yes| D["hydrate normally:<br/>adopt SSR nodes via hydrate_next"]
    C -->|no| E["remove_nodes() — discard server DOM"]
    E --> F["set_hydrating(false)"]
    F --> G["render client-side into fresh anchor"]
    G --> H["set_hydrating(true) — resume hydration<br/>of subsequent siblings"]
    D --> I["anchor = hydrate_node at block end"]
    H --> I
```

Example: `{#if browser}…{:else}…{/if}` where the server took the else branch but the client takes
the then branch — the server's else content is dropped and rebuilt client-side, then hydration
continues past the block.

---

## 5. Data Flow

The blocks are the *only* place where reactive state turns into DOM structure (element internals —
attributes, events, bindings — live in
[client_dom_renderer_elements_and_events](client_dom_renderer_elements_and_events.md)).

```mermaid
flowchart LR
    subgraph Signals["Reactive graph"]
        S["source / store / derived"]
        D["each_array derived<br/>(derived_safe_equal)"]
        IS["per-item sources (v, i)"]
        AWD["async deriveds"]
    end

    subgraph Blocks["This module"]
        BE["block effect<br/>(re-runs on dirty)"]
        REC["reconcile / update_branch /<br/>update(state)"]
        CI["create_item / branch(fn)"]
    end

    subgraph BatchLayer["Batch"]
        CB["commit callbacks"]
        SKIP["skipped_effects"]
    end

    subgraph DOMLayer["DOM"]
        AN["anchor Text/Comment"]
        FR["branch DOM range<br/>nodes_start..nodes_end"]
    end

    S -->|read by| BE
    S --> D
    D -->|array| REC
    REC -->|internal_set| IS
    IS -->|item render effects| FR
    AWD -->|resolve values| REC
    BE -->|create/pause/resume| FR
    REC -->|insert before| AN
    REC -.->|deferred mode| CB
    REC -.->|outgoing branches| SKIP
    CB -->|swap fragments| AN
```

---

## 6. Dependency Map

### 6.1 On other modules

| Dependency | Module | Used for |
|---|---|---|
| `block`, `branch`, `pause_effect`, `resume_effect`, `destroy_effect`, `run_out_transitions`, `template_effect`, `render_effect`, `teardown` | [client_runtime_core_effects](client_runtime_core_effects.md) | Effect containers and lifecycle for every block |
| `source`, `mutable_source`, `internal_set`, `derived_safe_equal` | [client_runtime_core_sources](client_runtime_core_sources.md) / [client_runtime_core_deriveds](client_runtime_core_deriveds.md) | Per-item/async value plumbing, collection normalization |
| `current_batch`, `Batch`, `Batch.enqueue`, `flushSync`, `effect_pending_updates` | [client_runtime_core_batching](client_runtime_core_batching.md) | Deferred commits, skipped effects, hydration-time deferral |
| `get`, `active_effect`, `active_reaction`, `set_active_effect/reaction`, `tick` | [client_runtime_core_runtime](client_runtime_core_runtime.md) | Reading signals inside effects, context switching |
| `hydrate_next`, `hydrate_node`, `hydrating`, `read_hydration_instruction`, `remove_nodes`, `set_hydrate_node`, `set_hydrating`, `next` | [client_dom_renderer_dom_foundation](client_dom_renderer_dom_foundation.md) (hydration.js) | Hydration cursor protocol |
| `create_text`, `should_defer_append`, `get_first_child`, `get_next_sibling`, `clear_text_content` | [client_dom_renderer_dom_foundation](client_dom_renderer_dom_foundation.md) (operations.js) | Anchor creation, deferred-append decision, DOM traversal |
| `assign_nodes` (template.js), `create_fragment_from_html` (reconciler.js) | [client_dom_renderer_dom_foundation](client_dom_renderer_dom_foundation.md) | Effect DOM-range bookkeeping; HTML parsing for `html`/`createRawSnippet` |
| `component_context`, `is_runes`, `dev_current_component_function`, `dev_stack` | [context_api](context_api.md) | Runes/legacy mode switches, dev context restoration |
| `flatten`, `async_derived`, `save` | [client_runtime_core_async](client_runtime_core_async.md) | `await` expression flattening (`async.js`) |
| `handle_error`, `invoke_error_boundary` | client runtime error handling | Boundary error escalation |
| `noop`, `is_promise`, `array_from`, `is_array` | [shared_runtime](shared_runtime.md) | Small cross-runtime utilities |
| `e.*` / `w.*` diagnostics | [client_runtime_core_diagnostics](client_runtime_core_diagnostics.md) | `invalid_snippet`, `await_outside_boundary`, `svelte_boundary_reset_*`, `hydration_*`, `invalid_raw_snippet_render`, `hydration_html_changed` |
| `createSubscriber`, `tag` (dev tracing) | reactivity / [client_dev_mode](client_dev_mode.md) | `$effect.pending()` lazy source; dev tracing tags |

### 6.2 Consumers of this module

| Consumer | Interaction |
|---|---|
| Compiler back-end — [compiler_client_transform_control_flow_blocks](compiler_client_transform_control_flow_blocks.md) | Emits exactly the calls documented in §3 (`$.if`, `$.each`, …) with compiler-owned flags and anchors |
| Lifecycle API — [client_dom_renderer_lifecycle_api](client_dom_renderer_lifecycle_api.md) | `hydrate()` triggers hydration mode all blocks respect; `unmount()` destroys the effect trees the blocks created; `reset_head_anchor()` consumed by `svelte-head.js` |
| Elements & events — [client_dom_renderer_elements_and_events](client_dom_renderer_elements_and_events.md) | Branch effects created here own the render effects that attributes/events/bindings register inside them; `custom-element.js` uses `create_slot` from this family's slot concept |
| Server renderer — [server_runtime](server_runtime.md) | The SSR twin (`await_block`, `slot`, `sanitize_slots`, `css_props`, `element`, `head` on the server) must emit markup whose hydration instructions this module can consume |

---

## 7. Cross-Cutting Invariants & Gotchas

1. **Anchor discipline.** Branch DOM is always inserted `anchor.before(...)`, and the module-level
   convention is `anchor = hydrate_node` at the end of block setup when hydrating. Violating this
   breaks move/destroy operations, which traverse from `nodes_start` to `nodes_end`.
2. **Deferred append only in async mode.** `should_defer_append()` returns `true` only when
   `async_mode_flag` is set, no eager block effects are running, and the active effect has already
   run. Legacy mode therefore always commits synchronously.
3. **`skipped_effects` must mirror `add_callback`.** Every deferred commit that removes a branch
   also adds it to the batch's `skipped_effects` set — otherwise the outgoing branch would be
   updated during traversal and could throw or flash stale DOM.
4. **Microtask deferral of `{:else}`/pending.** Both `each` fallback handling (via batch callbacks)
   and `await` pending states are intentionally deferred to avoid one-frame flicker for
   fast-resolving async work.
5. **`let mismatch` must stay a `let`.** The hydration-mismatch flags are declared with `let`
   (not `const`) purely so minifiers can treeshake the hydration path in client-only builds.
6. **Transitions are block-scoped.** Whether a transition is "local" depends on block structure —
   this is why `{:else if}` is compiled with the `elseif` flag rather than nesting `if_block`s.
7. **`{@html}` does not repair mismatches.** It validates via hash and warns in dev; repairing
   arbitrary HTML diffs is error-prone and skipped by design.

---

## 8. Related Documentation

- [client_dom_renderer](client_dom_renderer.md) — parent module: full DOM renderer overview
- [client_dom_renderer_dom_foundation](client_dom_renderer_dom_foundation.md) — hydration, operations, template, CSS style injection
- [client_dom_renderer_lifecycle_api](client_dom_renderer_lifecycle_api.md) — `mount` / `hydrate` / `unmount`
- [client_dom_renderer_elements_and_events](client_dom_renderer_elements_and_events.md) — attributes, events, transitions, custom elements
- [client_dom_renderer_bindings](client_dom_renderer_bindings.md) — two-way bindings
- [client_runtime_core](client_runtime_core.md) — signals, effects, batching, proxies, stores
- [compiler_client_transform_control_flow_blocks](compiler_client_transform_control_flow_blocks.md) — the compiler visitors that generate these calls
- [server_runtime](server_runtime.md) — the SSR rendering counterpart
- [shared_runtime](shared_runtime.md) — cross-runtime utilities and flags
