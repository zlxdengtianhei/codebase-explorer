# Server Runtime Blocks (`server_runtime_blocks`)

## 1. Introduction

`server_runtime_blocks` is a small but critical module inside the Svelte server-side rendering (SSR) runtime. It implements the two **"raw output" blocks** of the server renderer:

| Component | File | Purpose |
|---|---|---|
| `html(value)` | `packages/svelte/src/internal/server/blocks/html.js` | Serializes an `{@html ...}` tag into the SSR output stream, wrapped in **hydration anchor comments** |
| `createRawSnippet(fn)` | `packages/svelte/src/internal/server/blocks/snippet.js` | Creates a [snippet](public_api.md) programmatically that renders a **raw HTML string** into the SSR payload |

Both functions are **stream writers**: they never touch the DOM themselves. Instead, they push pre-rendered markup strings into the `Payload.out` buffer (see [server_runtime_payload_model](server_runtime_payload_model.md)), which the rendering core later joins into the final `RenderOutput.body` (see [server_runtime_rendering_core](server_runtime_rendering_core.md)).

Their defining responsibility is to emit markup in a shape that the client renderer can **re-discover and take ownership of during hydration** — the anchor-comment protocol described below. Every function here has a mirror-image counterpart in the client renderer ([client_dom_renderer](client_dom_renderer.md)): `internal/client/dom/blocks/html.js::html` and `internal/client/dom/blocks/snippet.js::createRawSnippet`.

---

## 2. Architecture & Position in the System

The module sits at the **tail end of the SSR pipeline**: the compiler emits calls to these functions, they write into the payload, and the rendering core flushes the payload into the HTTP response.

```mermaid
flowchart TB
    subgraph FE ["Compiler Back-End — compiler_server_transform"]
        HT["HtmlTag visitor<br/>emits <code>$.html(expr)</code>"]
        SB["SnippetBlock / RenderTag visitors<br/>emit snippet invocations"]
    end

    subgraph SRB ["server_runtime_blocks (this module)"]
        H["html.js :: html(value)"]
        S["snippet.js :: createRawSnippet(fn)"]
    end

    subgraph PM ["server_runtime_payload_model"]
        OUT["Payload.out : string[]"]
        RO["RenderOutput { head, body }"]
    end

    subgraph CORE ["server_runtime_rendering_core"]
        R["render(component, options)"]
    end

    subgraph HASH ["shared utils"]
        HSH["utils.js :: hash(str)"]
    end

    HT -->|"generated call"| H
    SB -->|"generated call"| S
    HSH -->|"DEV only"| H

    H -->|"anchor + raw markup"| OUT
    S -->|"trimmed render() output"| OUT
    OUT -->|"join('')"| R
    R --> RO

    RO -->|"SSR HTML → browser"| HYD["client_dom_renderer<br/>(hydration counterparts)"]
```

Key contracts with neighbouring modules:

- **Upstream (compiler)** — the server transform emits `context.state.template.push(b.call('$.html', expression))` for every `{@html ...}` tag, so generated server code calls this module's `html()` once per evaluation of the tag expression.
- **Sideways (payload)** — both writers append to `payload.out`, the ordered string buffer owned by [server_runtime_payload_model](server_runtime_payload_model.md). The order of pushes is the order of markup in the response.
- **Downstream (rendering core)** — `render()` opens the stream with `BLOCK_OPEN`, runs the component, and joins `payload.out` into `RenderOutput.body`.
- **Mirror (client renderer)** — the client-side blocks consume the anchors produced here during `hydrate()`.

---

## 3. Component Reference

### 3.1 `html(value)` — `{@html ...}` SSR serialization

```js
export function html(value) {
	var html = String(value ?? '');
	var open = DEV ? `<!--${hash(html)}-->` : '<!---->';
	return open + html + '<!---->';
}
```

**Signature:** `(value: string) => string` (values are coerced; see below).

**Behaviour:**

1. **Nullish coalescing** — `value ?? ''` converts `null`/`undefined` to the empty string, so the block always emits a well-formed `<!---->…<!---->` pair even for missing data. Other values are stringified with `String(...)`.
2. **Anchor comments** — the raw markup is bracketed by two HTML comments:
   - The **opening anchor** depends on the build:
     - **Production:** `<!---->` — a minimal, position-legal placeholder.
     - **Development:** `<!--{hash}-->` where `hash` is the base-36 djb2-style digest of the content (stripped of `\r`), imported from `packages/svelte/src/utils.js`.
   - The **closing anchor** is always `<!---->`.
3. **No sanitization** — the value is emitted verbatim. This is intentional: `{@html}` is documented as a raw-injection escape hatch with `innerHTML` semantics; escaping here would break its contract (for hardening guidance see [shared_runtime](shared_runtime.md) validation utilities).

**Why anchor comments?** During hydration the client cannot parse raw markup as it does for template elements — it must *find* the server-rendered nodes and claim them. Comments are the only zero-footprint DOM nodes that are valid anywhere in the document, making them ideal delimiters. The client block scans from the opening comment until it encounters the closing `<!---->`, then calls `assign_nodes(first, last)` to take ownership.

**Why the DEV hash?** Raw `{@html}` content is the classic source of hydration drift (e.g., `Date.now()` baked into server output). In dev mode the client counterpart reads the hash from the opening comment's `data` and compares it against the hash of the *current* value via `check_hash(...)`; on mismatch it emits the `hydration_html_changed` warning with source location info instead of attempting costly DOM repair. The dev gate is `import { DEV } from 'esm-env'`, so production bundles tree-shake the entire hashing path.

**Output shape:**

| Build | Output |
|---|---|
| Production | `<!---->` + `String(value ?? '')` + `<!---->` |
| Development | `<!--{hash(value)}-->` + `String(value ?? '')` + `<!---->` |

### 3.2 `createRawSnippet(fn)` — programmatic raw snippets

```js
export function createRawSnippet(fn) {
	return (payload, ...args) => {
		var getters = args.map((value) => () => value);
		payload.out.push(
			fn(...getters)
				.render()
				.trim()
		);
	};
}
```

**Signature:**

```ts
function createRawSnippet<Params extends unknown[]>(
  fn: (...params: Getters<Params>) => {
    render: () => string;
    setup?: (element: Element) => void | (() => void);
  }
): Snippet<Params>
```

**Behaviour:**

1. Returns a **snippet function** — the same shape the compiler generates for `{#snippet ...}` blocks: `(payload, ...args) => void`. This means `createRawSnippet` results can be passed anywhere a snippet is accepted (including `{@render ...}` and component slots).
2. On the server it is invoked with the active `Payload` plus the snippet arguments. Each argument is wrapped in a **getter** (`value => () => value`) so that `fn` sees a uniform `(…getters)` call signature in *every* environment. On the client those getters are live (they re-read reactive values inside `setup`); on the server they simply close over the current values — but the user-facing shape of `fn` never changes.
3. `fn.render()` produces the raw HTML string, which is `.trim()`-ed and pushed onto `payload.out`. Trimming guarantees clean boundaries between the snippet output and surrounding generated markup (no stray whitespace/indentation leaking into `RenderOutput.body`).
4. **`setup` is deliberately not called on the server.** It exists to attach behaviour (event listeners, etc.) to the rendered root element *in the browser*, optionally returning a cleanup function that the client wires into effect teardown. During SSR there is no element to attach to — only markup.
5. This function is part of the **public API**: `packages/svelte/src/index-server.js` re-exports it from the `svelte/server` entry point, so application code can construct snippets imperatively (e.g., for component props that expect snippets). The `html()` block, by contrast, is internal — reachable only through compiler-generated `$.html(...)` calls.

**Hydration contract:** the client counterpart assumes `render()` yields **exactly one root element**. During hydration that element *is* the server-rendered node (the client reuses it instead of re-parsing); outside hydration the client parses the string, warns via `invalid_raw_snippet_render` in dev mode if the root is not a single element, then runs `setup(element)` and registers the returned cleanup.

---

## 4. Data Flow

### 4.1 End-to-end `{@html}` round trip

```mermaid
sequenceDiagram
    autonumber
    participant C as Compiler (server transform)
    participant G as Generated SSR code
    participant SH as server html() (this module)
    participant P as Payload.out
    participant RC as render() (rendering core)
    participant BR as Browser DOM
    participant CH as client html() (hydration)

    C->>G: emit $.html(expression) for {@html}
    Note over G,SH: component runs during SSR
    G->>SH: html(value)
    SH->>SH: String(value ?? '')
    alt DEV build
        SH->>SH: open = "<!--" + hash(html) + "-->"
    else production build
        SH->>SH: open = "<!---->"
    end
    SH->>P: push(open + html + "<!---->")
    RC->>P: out.join("") → RenderOutput.body
    RC->>BR: HTML response
    Note over BR,CH: hydrate() walks server DOM
    CH->>BR: read opening comment anchor
    CH->>BR: consume nodes until closing "<!---->"
    alt DEV build
        CH->>CH: check_hash(anchor.data, current value)<br/>→ warn hydration_html_changed on drift
    end
    CH->>BR: assign_nodes(first, last) — client takes ownership
```

### 4.2 `createRawSnippet` lifecycle across environments

```mermaid
flowchart TD
    A["createRawSnippet(fn)"] --> B["snippet: (payload, ...args) => void"]
    B --> E{Which runtime?}

    E -->|SSR| S1["wrap each arg in a getter<br/>() => value"]
    S1 --> S2["out = fn(...getters).render()"]
    S2 --> S3["payload.out.push(out.trim())"]
    S3 --> S4["setup(element) NOT invoked<br/>(no DOM on server)"]

    E -->|client mount| M1["fragment = create_fragment_from_html(render())"]
    M1 --> M2["element = fragment.firstChild<br/>(DEV: warn if not a single element)"]
    M2 --> M3["anchor.before(element)"]

    E -->|client hydration| Y1["element = hydrate_node<br/>(server-rendered node reused)"]
    Y1 --> Y2["hydrate_next() — advance cursor"]

    M3 --> T["result = setup(element)"]
    Y2 --> T
    T --> T2{"returns function?"}
    T2 -->|yes| T3["register as effect teardown (cleanup)"]
    T2 -->|no| T4["assign_nodes(element, element)"]
```

---

## 5. Component Interaction & Dependencies

```mermaid
flowchart LR
    subgraph this ["server_runtime_blocks"]
        html["html()"]
        crs["createRawSnippet()"]
    end

    utils["utils.js :: hash<br/>(djb2 → base36)"] -->|DEV only| html
    env["esm-env :: DEV flag"] --> html
    payload["Payload.out<br/>(payload model)"] <-- "push markup strings" --> html
    payload <-- "push render().trim()" --> crs
    render_core["render() :: BLOCK_OPEN/ CLOSE<br/>(rendering core)"] --> payload
    transform["compiler_server_transform<br/>HtmlTag visitor"] -->|$.html(expr)| html
    public_api["svelte/server entry<br/>(index-server.js)"] -->|re-export| crs
    client_blocks["client_dom_renderer ::<br/>dom/blocks/{html,snippet}.js"] <-.->|anchor & hash protocol| this
    dev_val["server_runtime_dev_validation<br/>push_element / pop_element"] -.->|surrounding element stack| this
```

**Dependency summary**

| Dependency | Kind | Used for |
|---|---|---|
| `packages/svelte/src/utils.js :: hash` | runtime import | content digest embedded in the DEV opening anchor |
| `esm-env :: DEV` | runtime import | switching between hashed and plain anchors |
| `Payload` (from [server_runtime_payload_model](server_runtime_payload_model.md)) | parameter (snippet call) / implicit (html callers) | the `out` string buffer written by both blocks |
| `Getters` / `Snippet` types (`#shared`, `svelte`) | type-only | public typing of `createRawSnippet` |

---

## 6. Integration with the Rest of the System

- **[compiler_server_transform](compiler_server_transform.md)** — the only caller of `html()`. The `HtmlTag` visitor compiles `{@html expr}` to `$.html(expr)`; the dev-time stack of [server_runtime_dev_validation](server_runtime_dev_validation.md) (`push_element`/`pop_element`) brackets the surrounding elements, not the raw block itself.
- **[server_runtime_rendering_core](server_runtime_rendering_core.md)** — `render()` creates the `Payload`, invokes the component (which triggers these blocks), then joins `payload.out` between `BLOCK_OPEN`/`BLOCK_CLOSE` markers into `RenderOutput`.
- **[server_runtime_payload_model](server_runtime_payload_model.md)** — owns the `Payload`/`HeadPayload` classes and `copy_payload`/`assign_payload` used for streaming and boundary rendering; this module only ever appends to `out`.
- **[client_dom_renderer](client_dom_renderer.md)** — the hydration mirror. Its `dom/hydration.js` state machine (`hydrating`, `hydrate_node`, `hydrate_next`, `reset`) is what makes the anchor-comment protocol work; its dev-mode `check_hash` closes the loop on the hash emitted here.
- **[public_api](public_api.md)** — `createRawSnippet` is surfaced through the `svelte/server` entry so users can build snippets imperatively; it is also exported by the client entry with identical call semantics.
- **[shared_runtime](shared_runtime.md)** — supplies cross-environment helpers (e.g. `invalid_default_snippet` error, `Getters` type) that the snippet contract relies on.

---

## 7. Design Notes & Edge Cases

- **Comment anchors over wrapper elements:** anchors add no layout-affecting nodes and are legal in contexts where `div`s are not (`<table>`, `<head>`, …). The `<!---->` form is byte-cheap in production HTML.
- **Name shadowing:** inside `html()`, the local variable `html` shadows the exported function name — a stylistic quirk to be aware of when editing.
- **Nullish vs. falsy:** only `null`/`undefined` are special-cased (`?? ''`); `0`, `false`, and `''` are stringified as-is (producing `"0"`, `"false"`, `""`).
- **Determinism for hydration:** because the DEV hash is checked against the *current* client value, any non-deterministic `{@html}` output will surface as a `hydration_html_changed` warning in dev — treat such warnings as a signal to stabilize the source expression.
- **`trim()` boundary hygiene:** the snippet block trims its output so generated code can rely on whitespace-independent boundaries; the `html()` block does *not* trim — it must preserve the author's raw markup verbatim.
- **Tree-shakeability:** both files are single tiny functions with no module-level state; the `esm-env` DEV gate ensures the hashing/checking logic is stripped from production builds (verified by `scripts/check-treeshakeability.js`, see [svelte_build_tooling](svelte_build_tooling.md)).
- **SSR benchmarks:** `createRawSnippet` and the html block are exercised by the SSR wrapper benchmark (`benchmarking/benchmarks/ssr/wrapper/wrapper_bench.js`), keeping their hot path measurable — see [ssr_benchmarks](ssr_benchmarks.md).
