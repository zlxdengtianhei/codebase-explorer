# Reactivity Benchmarks — Kairo (`reactivity_benchmarks_kairo`)

## 1. Overview

The `reactivity_benchmarks_kairo` module is a suite of **8 micro-benchmarks (16 exported functions)** that measure the raw performance of **Svelte 5's fine-grained reactive runtime** — its signals (`state`), derived values (`derived`), effects (`effect_root` / `render_effect`) and batched propagation (`flush`). The suite is adapted from the community project [js-reactivity-benchmark](https://github.com/milomg/js-reactivity-benchmark) ("Kairo" is that project's framework test suite name), with timing and workload tweaks specific to Svelte.

Each benchmark constructs a small, precisely-shaped **reactive dependency graph**, hammers it with hundreds of synchronous update cycles, and **asserts correctness of both the computed values and the number of effect runs** while wall-clock and GC time are recorded. The suite therefore serves two purposes simultaneously:

1. **Performance regression detection** — any slowdown in the signal/derived/effect core shows up as increased `time` / `gc_time`.
2. **Correctness regression detection** — built-in `assert` calls fail the entire run if propagation semantics (e.g. glitch-free evaluation, deduplication, effect run counts) ever break.

The benchmarks live under `benchmarking/benchmarks/reactivity/kairo/` and are exercised by the harness described in [Repository Engineering Infrastructure](<Repository_Engineering_Infrastructure_(Benchmarks,_Build_Scripts___Playground).md>). They operate exclusively against the public surface of `svelte/internal/client`; the internals they probe are documented in [Reactive Runtime Engine](<Reactive_Runtime_Engine_(Signals,_Effects___Batching_with_Dev-Mode_Instrumentation).md>) (in particular its [`client_runtime_core`](client_runtime_core.md) subsystem).

---

## 2. Module at a Glance

| Aspect | Detail |
| --- | --- |
| **Location** | `benchmarking/benchmarks/reactivity/kairo/` |
| **Files** | 8 (`kairo_avoidable.js`, `kairo_broad.js`, `kairo_deep.js`, `kairo_diamond.js`, `kairo_mux.js`, `kairo_repeated.js`, `kairo_triangle.js`, `kairo_unstable.js`) |
| **Exports** | 16 async functions — an `*_owned` / `*_unowned` pair per file |
| **Runtime under test** | `svelte/internal/client` (signals, deriveds, effects, batches) |
| **Shared helpers** | `benchmarking/utils.js` (`fastest_test`, `assert`), `kairo/util.js` (`busy`) |
| **Registration** | `benchmarking/benchmarks/reactivity/index.js` → `reactivity_benchmarks` array |
| **Entry point** | `benchmarking/run.js` (awaits every registered benchmark, aggregates totals) |
| **Result shape** | `{ benchmark: string, time: string /* ms */, gc_time: string /* ms */ }` |

---

## 3. Architecture & Context

The module sits at the intersection of the benchmarking infrastructure and the runtime it measures. It has **no state of its own** beyond module-level tuning constants (`len`, `width`, `size`, `iter`); every benchmark is a self-contained *setup → measure → teardown* cycle.

```mermaid
flowchart TB
    subgraph infra["Repository Engineering Infrastructure — benchmarking/"]
        RUN["benchmarking/run.js<br/>suite runner ($.push/$.pop context)"]
        IDX["benchmarks/reactivity/index.js<br/>reactivity_benchmarks registry"]

        subgraph KAIRO["reactivity_benchmarks_kairo (this module)"]
            direction TB
            F1["kairo_avoidable.js"]
            F2["kairo_broad.js"]
            F3["kairo_deep.js"]
            F4["kairo_diamond.js"]
            F5["kairo_triangle.js"]
            F6["kairo_mux.js"]
            F7["kairo_repeated.js"]
            F8["kairo_unstable.js"]
        end

        SB["reactivity_benchmarks_sbench<br/>(sibling module)"]
        MOL["reactivity_benchmarks_mol<br/>(sibling module)"]
        U["benchmarking/utils.js<br/>fastest_test · assert · GarbageTrack"]
        KU["kairo/util.js<br/>busy()"]
    end

    subgraph RUNTIME["Reactive Runtime Engine — svelte/internal/client"]
        CORE["runtime.js<br/>get · set · flush · settled"]
        SRC["reactivity/sources.js<br/>state"]
        DER["reactivity/deriveds.js<br/>derived / user_derived"]
        EFF["reactivity/effects.js<br/>effect_root · render_effect"]
        BAT["reactivity/batch.js<br/>scheduling &amp; batching"]
    end

    RUN --> IDX
    IDX --> KAIRO
    IDX --> SB
    IDX --> MOL
    F1 --> KU
    F1 & F2 & F3 & F4 & F5 & F6 & F7 & F8 --> U
    F1 & F2 & F3 & F4 & F5 & F6 & F7 & F8 --> RUNTIME
    CORE -.-> BAT
```

**Reading the diagram:**

- `run.js` imports the `reactivity_benchmarks` registry, which is dominated by the 16 kairo functions (plus the sbench and mol suites — see [`reactivity_benchmarks_sbench`](reactivity_benchmarks_sbench.md) and [`reactivity_benchmarks_mol`](reactivity_benchmarks_mol.md)).
- Every kairo file depends on exactly three things: the internal client runtime (the code under test), the shared timing/assert helpers, and — in one case — the `busy()` CPU-burn helper.
- Cross-framework result comparison is handled downstream by the [benchmark comparison tooling](benchmark_comparison_tooling.md), which consumes the same js-reactivity-benchmark heritage formats.

---

## 4. Benchmark Catalogue

Each file exports a `*_owned` and a `*_unowned` variant of the same workload (see §7 for the distinction). The registry in `benchmarks/reactivity/index.js` executes them in **owned-then-unowned order per benchmark**, interleaved after the sbench suite:

```
kairo_avoidable_owned, kairo_avoidable_unowned,
kairo_broad_owned,     kairo_broad_unowned,
kairo_deep_owned,      kairo_deep_unowned,
kairo_diamond_owned,   kairo_diamond_unowned,
kairo_triangle_owned,  kairo_triangle_unowned,
kairo_mux_owned,       kairo_mux_unowned,
kairo_repeated_owned,  kairo_repeated_unowned,
kairo_unstable_owned,  kairo_unstable_unowned
```

| Benchmark | Topology class | Graph scale | Update cycles per `run()` | Key invariants asserted | What it isolates |
| --- | --- | --- | --- | --- | --- |
| `kairo_avoidable` | Linear chain with a **value-stable bypass** | `head → c1 → c2 → c3(+busy) → c4 → c5 → effect` | 1001 (`set head`, then 1000 more) | `computed5 === 6` **always**, despite `head` changing | Equality-based pruning: `c2` returns a constant, so downstream heavy work (`busy()`) must be *avoided* when nothing actually changed |
| `kairo_broad` | **Fan-out** into 50 independent 2-hop chains, one effect each | 50 × (`head+i → +1 → effect`) | 51 | `counter === 50 × 50`; `last === i + 50` | Breadth of propagation: many sibling reactions, many effect re-runs |
| `kairo_deep` | **Deep chain** | 50 sequential deriveds, single tail effect | 51 | `counter === 50`; tail `=== len + i` | Depth of propagation: one invalidation must traverse 50 hops exactly once |
| `kairo_diamond` | **Diamond** | 5 parallel branches off `head`, joined by a `sum` derived, single tail effect | 501 | `counter === 500`; `sum === (i+1) × 5` | Shared-dependency deduplication: the join must recompute once per change, not per path |
| `kairo_triangle` | **Triangle** (deep chain + broad fan-in) | 10 chained deriveds; a `sum` derived reads *all* chain levels | 101 | `counter === 100`; `sum` matches closed-form | Combined deep + broad traversal with cumulative sum |
| `kairo_mux` | **Multiplexer** (mass fan-in → fan-out) | 100 source states → 1 `mux` object derived → 100 × 2-hop splits, each with an effect | 20 | `split[i] === i×2 + 1` after each write | Funneling many signals through one keyed derived and re-splitting them (dynamic property access) |
| `kairo_repeated` | **Duplicate dependencies** | One derived reads the same `head` 30× | 101 | `counter === 100`; `current === i × 30` | Cost of repeated reads of one signal inside a single reaction (must dedup deps) |
| `kairo_unstable` | **Dynamic ("unstable") dependencies** | Derived branches `head % 2 ? double : inverse` inside a 20× loop | 101 | `counter === 100`; `current === 40` for odd head | Re-linking of dependency lists when the *set* of read signals changes between runs |

### Reactive graph topologies

```mermaid
flowchart LR
    subgraph avoidable["kairo_avoidable — prunable chain"]
        direction LR
        a0(("state head")) --> a1["c1: get(head)"] --> a2["c2: constant 0"] --> a3["c3: busy()+1"] --> a4["c4: +2"] --> a5["c5: +3"] --> ae["render_effect + busy"]
    end

    subgraph deep["kairo_deep — depth 50"]
        direction LR
        d0(("state head")) --> d1["+1"] --> d2["+1"] --> dDots["⋯ ×50"] --> d50["+1"] --> de["render_effect"]
    end

    subgraph diamond["kairo_diamond — width 5"]
        direction TB
        di0(("state head")) --> diA["+1"] & diB["+1"] & diC["+1"] & diD["+1"] & diE["+1"]
        diA & diB & diC & diD & diE --> diS["sum: reduce"] --> die["render_effect"]
    end

    subgraph triangle["kairo_triangle — width 10"]
        direction TB
        t0(("state head")) --> t1["+1"] --> t2["+1"] --> tDots["⋯"] --> t10["+1"]
        t1 & t2 & t10 --> tS["sum over all levels"] --> te["render_effect"]
    end

    subgraph mux["kairo_mux — 100 heads"]
        direction TB
        m0(("100 × state")) --> mMux["mux: Object.fromEntries"] --> mS0["split[0]: +1"] --> mE0["effect"]
        mMux --> mSN["split[i]: +1"] --> mEN["effect ×100"]
    end
```

> `kairo_broad` (50 sibling chains), `kairo_repeated` (one derived, 30 duplicate reads) and `kairo_unstable` (parity-dependent branching) complete the catalogue; their shapes are the degenerate/special cases of the topologies above.

---

## 5. Anatomy of a Kairo Benchmark

Every file follows an identical skeleton. Understanding one file means understanding all sixteen exported functions.

### 5.1 Graph construction — `setup()`

```javascript
function setup() {
    let head = $.state(0);                       // writable source signal
    let current = head;
    for (let i = 0; i < len; i++) {              // e.g. kairo_deep
        let c = current;
        current = $.derived(() => $.get(c) + 1); // derived, closes over parent
    }

    const destroy = $.effect_root(() => {        // ownership root
        $.render_effect(() => {
            $.get(current);                      // read ⇒ dependency tracked
            counter++;                           // effect-run observability
        });
    });

    return { destroy, run };                     // run() = workload; assert()s inside
}
```

Internal client APIs exercised (their implementation details belong to the [Reactive Runtime Engine](<Reactive_Runtime_Engine_(Signals,_Effects___Batching_with_Dev-Mode_Instrumentation).md>) docs):

| API | Runtime source | Role in the benchmarks |
| --- | --- | --- |
| `$.state(v)` | `reactivity/sources.js` | Create a writable source signal |
| `$.derived(fn)` | `reactivity/deriveds.js` (`user_derived`) | Declare a lazily-evaluated computed value |
| `$.get(signal)` | `runtime.js` (`get`) | Read a value **and register the dependency** on the active reaction; pulls recomputation when dirty |
| `$.set(signal, v)` | `runtime.js` (`set`) | Write a source and mark its reactions for the current batch |
| `$.flush(fn)` | `runtime.js` / `batch.js` | Execute `fn`, then synchronously drain the scheduler so the graph is fully settled |
| `$.effect_root(fn)` | `reactivity/effects.js` | Open an ownership scope; returns a teardown that destroys the subtree |
| `$.render_effect(fn)` | `reactivity/effects.js` | The effect variant Svelte's template renderer would create — the observed "consumer" |

The `counter++` idiom inside each `render_effect` is the correctness oracle: after *n* writes, exactly *n* effect runs must have occurred (glitch-free, no over-firing), and the derived output must match a closed-form expectation. `assert()` throwing propagates up through `run.js`, which exits non-zero — see §8.

### 5.2 Measurement shell — owned/unowned pair

Both variants share the same measurement shell:

```javascript
export async function kairo_<name>_unowned() {
    for (let i = 0; i < 10; i++) {            // JIT warm-up: 10 full cycles
        const { run, destroy } = setup();
        run(); destroy();
    }
    const { run, destroy } = setup();          // fresh graph for measurement

    const { timing } = await fastest_test(10, () => {
        for (let i = 0; i < 1000; i++) run();  // 1000 workloads per timed sample
    });

    destroy();                                 // teardown
    return { benchmark: 'kairo_<name>_unowned', ...timing };
}

export async function kairo_<name>_owned() {
    let run, destroy;
    const destroy_owned = $.effect_root(() => {  // outer ownership root
        for (let i = 0; i < 10; i++) { /* warm-up setup/run/destroy */ }
        ({ run, destroy } = setup());            // setup INSIDE the root
    });
    const { timing } = await fastest_test(10, () => {
        for (let i = 0; i < 1000; i++) run();
    });
    destroy(); destroy_owned();                  // cascade teardown
    return { benchmark: 'kairo_<name>_owned', ...timing };
}
```

---

## 6. Execution & Measurement Pipeline

```mermaid
sequenceDiagram
    autonumber
    participant RUN as run.js
    participant B as Benchmark fn (owned/unowned)
    participant F as fastest_test (utils.js)
    participant T as run_tracked (utils.js)
    participant G as GarbageTrack (PerformanceObserver 'gc')
    participant V as v8-natives
    participant S as run() workload (flush/set/deriveds/effects)

    RUN->>B: await benchmark()
    Note over B: 10× setup/run/destroy — JIT warm-up
    B->>F: fastest_test(10, suiteFn)
    loop 10 timed samples
        F->>T: run_tracked(suiteFn)
        T->>V: collectGarbage() — start from clean heap
        T->>G: watch() — record period [start,end]
        T->>S: suiteFn() → 1000 × run() (flush cycles + asserts)
        S-->>T: done (asserts must all pass)
        T->>G: gcDuration(track_id) — sum 'gc' entries within period
        T-->>F: { result, timing { time, gc_time } }
    end
    F-->>B: fastest sample (min by wall time)
    B-->>RUN: { benchmark, time, gc_time }
```

Key measurement properties:

- **Garbage-collection before every sample** (`v8.collectGarbage()`) and **GC accounting during** it (a `PerformanceObserver` on the `'gc'` entry type, filtered to the timed window) let the suite report `gc_time` separately from `time` — critical because allocation pressure in the scheduler/deps arrays is a real regression vector.
- **Best-of-10 sampling** (min wall time) suppresses noise; the 10 warm-up cycles beforehand ensure V8 has tiered the hot loops up before timing.
- **Scale:** one timed sample executes 1000 `run()` calls; each `run()` performs its benchmark's own flush cycle count (20–1001 depending on the topology, §4).
- The runner (`benchmarking/run.js`) wraps the whole suite in `$.push({}, true)` / `$.pop()` so internal APIs run inside a component context exactly as compiled app code would, then accumulates `suite_time` / `total_time` from each returned object.

### Propagation flow under test

Every `run()` iteration drives the same core loop of the runtime — this is the behaviour whose cost the suite quantifies:

```mermaid
flowchart TD
    A["$.flush(fn)"] --> B["fn: $.set(head, v)<br/>source marked dirty, reactions scheduled in batch"]
    B --> C["batch drains: deriveds recomputed<br/>top-down, each pulls only when dirty ($.get)"]
    C --> D{"derived value actually changed?"}
    D -- "no (equality check)" --> E["downstream skipped<br/>(kairo_avoidable's whole point)"]
    D -- yes --> F["dependent deriveds / effects invalidated"]
    F --> G["render_effect re-runs → counter++"]
    G --> H["assert: output value + run count"]
    H --> I["next flush cycle (×20…1001)"]
```

---

## 7. Ownership Model: `owned` vs `unowned`

The paired exports are not a formatting convention — they measure two different ownership regimes of the runtime, both of which occur in real apps:

| | `*_unowned` | `*_owned` |
| --- | --- | --- |
| `setup()` call site | Top level of the benchmark function (no enclosing scope) | Inside an `$.effect_root(...)` |
| Deriveds created | **Unowned** — no owning effect (the runtime's `get()` marks such deriveds `UNOWNED`) | **Owned** — parented under the root effect, like deriveds inside a mounted component |
| Teardown | Inner `destroy()` tears down the graph's effects; unowned deriveds rely on GC | `destroy_owned()` cascades teardown of **every** reaction created, warm-ups included |
| Real-world analogue | Library / cross-component reactive graphs | Svelte component bodies (effects and deriveds owned by the component's effect tree) |

Differences in dirty-checking paths, dependency re-linking and memory churn between these two regimes are precisely what the paired numbers expose — a regression that only affects owned (or only unowned) reactions is immediately attributable.

```mermaid
flowchart TB
    subgraph UN["unowned variant"]
        u1["setup() at function top level"] --> u2["deriveds: no owner (UNOWNED)"]
        u1 --> u3["render_effect under local effect_root"]
        u3 --> u4["destroy() → effects torn down,<br/>deriveds left to GC"]
    end
    subgraph OW["owned variant"]
        o1["$.effect_root(...)"] --> o2["10 × warm-up setup/run/destroy"]
        o2 --> o3["measured setup() — whole tree owned<br/>by the root effect"]
        o3 --> o4["destroy_owned() → cascading teardown<br/>of every reaction"]
    end
```

---

## 8. Dependencies

### 8.1 Outbound (what this module consumes)

| Dependency | Symbols used | Purpose |
| --- | --- | --- |
| `svelte/internal/client` | `state`, `derived`, `get`, `set`, `flush`, `effect_root`, `render_effect` | The reactive runtime under test (resolves to `packages/svelte/src/internal/client/index.js`) |
| `benchmarking/utils.js` | `fastest_test`, `assert` | GC-aware timing harness and correctness gate |
| `./util.js` (kairo-local) | `busy` | Deliberate CPU payload used **only** by `kairo_avoidable` to make skipped work measurable |

### 8.2 Inbound (what consumes this module)

| Consumer | Usage |
| --- | --- |
| `benchmarking/benchmarks/reactivity/index.js` | Imports all 16 functions and registers them in the `reactivity_benchmarks` array |
| `benchmarking/run.js` | Awaits each registered benchmark; aggregates `time` / `gc_time` into suite and grand totals |
| [benchmark comparison tooling](benchmark_comparison_tooling.md) | Downstream result comparison across reactive frameworks |

```mermaid
flowchart LR
    K["reactivity_benchmarks_kairo"] -- "runtime APIs (state/derived/get/set/flush/effect_root/render_effect)" --> RT["svelte/internal/client<br/>(Reactive Runtime Engine)"]
    K -- "fastest_test, assert" --> UT["benchmarking/utils.js"]
    K -- "busy" --> KU["kairo/util.js"]
    IDX["reactivity/index.js registry"] --> K
    RUNJS["benchmarking/run.js"] --> IDX
    IDX --> SB["reactivity_benchmarks_sbench"]
    IDX --> MOL["reactivity_benchmarks_mol"]
```

---

## 9. Failure Modes & Interpretation

- **`Assertion failed` from `assert`** means propagation semantics regressed (wrong value, or an effect ran more/fewer times than writes). `run.js` catches this, prints `-- Benchmarking Failed --` and exits with status `1` — the suite doubles as a correctness test for the runtime's core.
- **`time` regression** implicates hot paths of `get`/`set`/`flush`, dirty-marking, or dependency array maintenance in the runtime (see [`client_runtime_core`](client_runtime_core.md)).
- **`gc_time` regression** points at allocation churn — e.g. new dependency arrays per update instead of in-place re-linking; the `unstable` and `broad` benchmarks are most sensitive to this.
- **`avoidable` numbers flat** are healthy: that benchmark rewards *not* recomputing. A `time` drop there (with correctness holding) means pruning improved.
- Owned vs unowned diverging sharply usually indicates an ownership-aware fast path (or a missing one) in the scheduler.

---

## 10. Extending the Suite

To add a new Kairo-style benchmark:

1. Create `benchmarking/benchmarks/reactivity/kairo/kairo_<name>.js` with a `setup()` that returns `{ destroy, run }`, embeds `assert` checks for both **values** and **effect-run counts**, and mirrors the `_owned` / `_unowned` shell from §5.2 (10 warm-up cycles → `fastest_test(10, …)` → 1000 `run()` calls → teardown → typed result object).
2. If the workload needs artificial work weight, import `busy` from `./util.js` rather than inlining arbitrary loops, keeping timings comparable across benchmarks.
3. Register both exports in `reactivity_benchmarks` (`benchmarks/reactivity/index.js`), keeping the established owned-then-unowned ordering.
4. Nothing else is required — `run.js` and the aggregation logic pick the new entries up automatically.

For the surrounding harness (timing internals, result aggregation, CLI usage), see the parent documentation: [Repository Engineering Infrastructure](<Repository_Engineering_Infrastructure_(Benchmarks,_Build_Scripts___Playground).md>). For the sibling suites: [`reactivity_benchmarks_sbench`](reactivity_benchmarks_sbench.md) (creation/fan-out ratios of computations) and [`reactivity_benchmarks_mol`](reactivity_benchmarks_mol.md) (the Mol benchmark).

---

## 11. Component Reference Index

| Component | File | Kind |
| --- | --- | --- |
| `kairo_avoidable_owned` / `kairo_avoidable_unowned` | `kairo/kairo_avoidable.js` | benchmark pair — prunable chain with `busy()` payloads |
| `kairo_broad_owned` / `kairo_broad_unowned` | `kairo/kairo_broad.js` | benchmark pair — 50-way fan-out chains |
| `kairo_deep_owned` / `kairo_deep_unowned` | `kairo/kairo_deep.js` | benchmark pair — 50-deep chain |
| `kairo_diamond_owned` / `kairo_diamond_unowned` | `kairo/kairo_diamond.js` | benchmark pair — 5-way diamond with join |
| `kairo_triangle_owned` / `kairo_triangle_unowned` | `kairo/kairo_triangle.js` | benchmark pair — chain + fan-in sum |
| `kairo_mux_owned` / `kairo_mux_unowned` | `kairo/kairo_mux.js` | benchmark pair — 100-head multiplexer |
| `kairo_repeated_owned` / `kairo_repeated_unowned` | `kairo/kairo_repeated.js` | benchmark pair — duplicate dependency reads |
| `kairo_unstable_owned` / `kairo_unstable_unowned` | `kairo/kairo_unstable.js` | benchmark pair — dynamic dependency sets |

*(Supporting, defined outside this module: `fastest_test`, `assert` in `benchmarking/utils.js`; `busy` in `kairo/util.js`; registry in `benchmarks/reactivity/index.js`; runner `benchmarking/run.js`.)*
