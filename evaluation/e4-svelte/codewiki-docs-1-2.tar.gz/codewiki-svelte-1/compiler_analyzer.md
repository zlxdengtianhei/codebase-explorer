# Compiler Analyzer (Phase 2: Semantic Analysis)

## 1. Overview & Purpose

The **compiler_analyzer** module implements the second phase of the Svelte compiler pipeline. Sitting between the parser (phase 1) and the code generators (phase 3), it transforms a *syntactically valid* AST into a fully *semantically understood* one. Its responsibilities are:

- **Validation** — reject illegal placements, malformed tags, invalid attribute combinations and mode-incorrect syntax (runes vs. legacy) with precise diagnostics (see [compiler_diagnostics](compiler_diagnostics.md)).
- **Scope & binding resolution** — build lexical scopes, bind every identifier reference to its declaration, detect reassignments/mutations, and partially evaluate constant expressions.
- **Reactivity classification** — decide for each binding whether it is plain state (`$state`), a derived value (`$derived`), a prop (`$props` / `export let`), an each-item, a store subscription (`$store`), etc.
- **Metadata annotation** — attach analysis results to AST nodes (`node.metadata`) so that the transform phase (see [compiler_client_transform](compiler_client_transform.md) and [compiler_server_transform](compiler_server_transform.md)) can generate code without re-interpreting the template: dynamic fragments, expression state/call/await flags, keyed each blocks, scoped CSS eligibility, and more.
- **Mode detection** — automatically opt components into runes mode when runes, top-level `await`, or store-like rune references are encountered.

### Position in the compiler pipeline

```mermaid
flowchart LR
    SRC["`.svelte` source"] --> PARSE["Phase 1 — Parse<br/>(compiler_parser)"]
    PARSE -->|"AST.Root: module / instance<br/>scripts + template fragment"| ANALYZE["Phase 2 — Analyze<br/>(this module)"]
    ANALYZE -->|"ComponentAnalysis +<br/>annotated AST"| CLIENT["Phase 3a — Client transform<br/>(compiler_client_transform)"]
    ANALYZE --> SERVER["Phase 3b — Server transform<br/>(compiler_server_transform)"]
    ANALYZE --> CSSP["CSS pipeline<br/>(compiler_css_pipeline)"]
    CSSP --> CLIENT
    CSSP --> SERVER
```

The entry points `analyze_component` and `analyze_module` (in `phases/2-analyze/index.js`) are invoked by the top-level orchestrator [compiler_core](compiler_core.md) (`compile` / `compileModule`), which also owns option validation and global compiler state (`state.js`: `push_ignore` / `pop_ignore`, source tracking) that this module consumes.

## 2. Architecture

The module is built around three cooperating layers:

```mermaid
flowchart TB
    subgraph ORCH["Orchestration — 2-analyze/index.js"]
        AM["analyze_module()"]
        AC["analyze_component()"]
    end

    subgraph SCOPE["Scope engine — phases/scope.js"]
        CS["create_scopes()"]
        SC["Scope / Binding"]
        EV["Evaluation<br/>(partial constant folding)"]
        SR["ScopeRoot"]
        SS["set_scope()"]
        GR["get_rune()"]
    end

    subgraph VIS["Visitor registry — zimmerframe walk"]
        FALLBACK["_() fallback:<br/>svelte-ignore + scope sync"]
        BLOCKV["Block visitors"]
        TMPLV["Template tag &amp; element visitors"]
        JSV["JS statement/expression visitors"]
    end

    subgraph POST["Post-walk finalization"]
        STORES["Store subscription<br/>synthesis ($store)"]
        LEGACY["Legacy prop/state<br/>normalization"]
        CSSCALLS["analyze_css / prune /<br/>warn_unused → css pipeline"]
        CHECKS["Cross-node consistency checks<br/>(snippets, slots, events)"]
    end

    AC --> CS
    AM --> CS
    CS --> SC
    SC --> EV
    CS --> SR
    AC -->|"3 walks: module / instance / template"| VIS
    SS -.->|"default visitor"| VIS
    GR -.-> VIS
    VIS --> POST
    CSSCALLS --> CSSP["compiler_css_pipeline"]
```

### 2.1 Two-pass design

Analysis deliberately runs in **two passes** over each AST (`<script module>`, `<script>`, and the template fragment):

1. **Scope-creation pass** — `create_scopes()` walks the AST with its own inline visitor set (see [compiler_analyzer_scope](compiler_analyzer_scope.md)). It declares every `Binding`, records `references` and `updates`, creates a `Scope` per block/function/component/slot, and detects implicit (`$:`) reactive declarations. Doing this first means the analysis pass never meets a reference before its declaration exists.
2. **Analysis pass** — `walk(ast, state, visitors)` from [`zimmerframe`](https://github.com/Rich-Harris/zimmerframe) drives the ~60 node-specific visitors. The special `_` fallback visitor runs for *every* node: it collects `<!-- svelte-ignore ... -->` / `// svelte-ignore ...` comments into the global ignore stack and re-synchronizes `state.scope` with the node's scope (equivalent to `set_scope`).

### 2.2 The AnalysisState carried through the walk

Defined in `phases/2-analyze/types.d.ts`, this state object is the contract between the orchestrator and every visitor:

| Field | Purpose |
|---|---|
| `scope`, `scopes` | Current lexical scope; node→scope map built by `create_scopes` |
| `analysis` | The `ComponentAnalysis` accumulator (see `phases/types.d.ts`) — flags like `uses_slots`, `needs_props`, collected `elements`, `reactive_statements`, CSS info |
| `options` | Validated compile options (`experimental.async`, `runes`, …) |
| `ast_type` | Which of the three ASTs is being walked: `'module' \| 'instance' \| 'template'` |
| `expression` | Current `ExpressionMetadata` — `has_state`, `has_call`, `has_await`, `dependencies` — threaded into nested expressions via `context.next({ ...state, expression })` |
| `fragment` | Innermost `AST.Fragment`, whose `metadata.dynamic` is set by `mark_subtree_dynamic` |
| `parent_element` | Enclosing element tag name, used for HTML content-model validation |
| `component_slots` | Slot names seen on the current component (duplicate detection) |
| `state_fields`, `function_depth`, `reactive_statement`, `has_props_rune` | Class-state analysis, rune/legacy gating, `$:` handling |

Expression metadata itself is created by `create_expression_metadata()` in `phases/nodes.js`.

### 2.3 Component analysis flow

```mermaid
sequenceDiagram
    participant C as compiler_core (compile)
    participant A as analyze_component
    participant S as scope.js
    participant V as visitors
    participant CSS as css pipeline

    C->>A: root AST, source, options
    A->>S: create_scopes(module ast)
    A->>S: create_scopes(instance ast, parent=module scope)
    A->>S: create_scopes(template fragment)
    A->>A: synthesize $store bindings (store_sub)
    A->>A: detect runes mode (option / top-level await / rune refs)
    alt legacy mode
        A->>A: export let → bindable_prop, $$props/$$restProps synthetic
    end
    loop each of module / instance / template
        A->>V: walk(ast, AnalysisState, visitors)
    end
    A->>A: reorder $: reactive statements, unused-prop warnings
    A->>A: snippet/slot conflict + export validation
    A->>CSS: analyze_css → prune → warn_unused
    A->>A: inject synthetic class/style attributes for scoped CSS
    A-->>C: ComponentAnalysis
```

`analyze_module(source, options)` is the simpler `.svelte.js|.svelte.ts` variant: parse, scope, walk once, validate `$`-prefixed references, and return an `Analysis`.

## 3. Sub-modules

The module splits into four sub-modules along its natural seams — the scope foundation, and three visitor families:

| Sub-module | Documentation | Contents |
|---|---|---|
| **Scope & Binding engine** | [compiler_analyzer_scope](compiler_analyzer_scope.md) | `phases/scope.js`: `Scope`, `Binding`, `Evaluation`, `ScopeRoot`, `create_scopes`, `set_scope`, `get_rune`, rune/global keypath resolution |
| **Control-flow block visitors** | [compiler_analyzer_block_visitors](compiler_analyzer_block_visitors.md) | `AwaitBlock`, `IfBlock`, `EachBlock`, `KeyBlock`, `AwaitExpression` — `{#if}/{#each}/{#key}/{#await}` validation, keyed detection, transitive legacy dependency collection, top-level `await` gating |
| **Template tag & element visitors** | [compiler_analyzer_template_visitors](compiler_analyzer_template_visitors.md) | `ConstTag`, `DebugTag`, `HtmlTag`, `ClassDirective`, `StyleDirective`, `TitleElement`, `SvelteFragment`, and the `svelte:*` special elements (`SvelteBody`, `SvelteBoundary`, `SvelteDocument`, `SvelteHead`, `SvelteWindow`) |
| **JS statement & expression visitors** | [compiler_analyzer_js_visitors](compiler_analyzer_js_visitors.md) | `ExportDefaultDeclaration`, `ExportNamedDeclaration`, `ExportSpecifier`, `NewExpression`, `TaggedTemplateExpression`, `TemplateElement` — module export semantics, perf warnings, purity tracking |

### How the visitor families cooperate

```mermaid
flowchart LR
    subgraph BLOCKS["Block visitors"]
        EB["EachBlock<br/>keyed? / transitive deps"]
        IB["IfBlock / KeyBlock / AwaitBlock<br/>empty-block + tag validation"]
    end
    subgraph TEMPLATE["Template visitors"]
        CT["ConstTag<br/>placement rules"]
        ST["StyleDirective / ClassDirective<br/>state propagation"]
        SE["svelte:* elements<br/>attribute whitelists"]
    end
    subgraph JS["JS visitors"]
        EX["ExportNamed/Specifier<br/>exports list, rune guard"]
        NE["NewExpression<br/>needs_context = true"]
        TE["TaggedTemplateExpression<br/>has_call / has_state"]
    end
    SCOPE["Scope &amp; Binding engine"]
    META["ExpressionMetadata<br/>(state.expression)"]
    FRAG["Fragment.metadata.dynamic<br/>(mark_subtree_dynamic)"]

    EB & IB -->|"mark_subtree_dynamic"| FRAG
    CT & ST & SE --> META
    EX & NE & TE --> META
    EB & EX & NE -->|"scope.get(name)"| SCOPE
    ST -->|"binding.kind → state"| SCOPE
```

Common idioms shared by all visitors:

- **`context.next(stateOverride?)`** — continue traversal into children, optionally overriding `state.expression` or `scope`.
- **`validate_opening_tag(node, state, '#'|':'|'@')`** — in runes mode, ensures block/tag delimiters use the correct character (from `visitors/shared/utils.js`).
- **`validate_block_not_empty`** — warns on whitespace-only blocks (from `visitors/shared/utils.js`).
- **`mark_subtree_dynamic(context.path)`** — sets `metadata.dynamic` on enclosing fragments, forcing template-vs-dynamic rendering decisions downstream (from `visitors/shared/fragment.js`).
- **`scope.get(name)` → `Binding`** — visitors read and *mutate* binding kinds (e.g. promoting a shorthand `style:color` binding to state) — the central coupling point with [compiler_analyzer_scope](compiler_analyzer_scope.md).
- **`e.*` / `w.*`** — errors and warnings from [compiler_diagnostics](compiler_diagnostics.md); message texts are generated from `messages/` templates by the build tooling described in the repository engineering docs.

## 4. Outputs consumed by the rest of the compiler

The `ComponentAnalysis` object produced here is the *sole* semantic input of phase 3:

- **Bindings** (`Binding.kind`, `mutated`, `reassigned`, `references`, `legacy_dependencies`) drive client/server variable access, prop generation, and store wiring — consumed by [compiler_client_transform](compiler_client_transform.md) and [compiler_server_transform](compiler_server_transform.md).
- **Template metadata** (`Fragment.metadata.dynamic`, `EachBlock.metadata.keyed/transitive_deps/declarations`, expression `has_state/has_call/has_await`) decides template-literal vs. dynamic rendering and async boundary requirements.
- **`analysis.elements`** with per-node `metadata.scoped` — produced here, pruned/annotated by the [compiler_css_pipeline](compiler_css_pipeline.md), then used by the CSS transforms (`remove_global_pseudo_class`, style hashing).
- **`analysis.exports`, `uses_props`, `snippet_renderers`, `reactive_statements`** — shape the generated component class/function signatures.

## 5. Interaction with other modules

| Module | Relationship |
|---|---|
| [compiler_parser](compiler_parser.md) | Upstream: `analyze_component` receives the parsed `AST.Root` (`<script module>`, `<script>`, template, `<style>`); `analyze_module` calls `parse` from `1-parse/acorn.js` directly for JS-only modules. TS-specific nodes are already stripped by `remove_typescript_nodes` before analysis. |
| [compiler_css_pipeline](compiler_css_pipeline.md) | Downstream callee: after the visitor walk, `analyze_css`, `prune` and `warn_unused` are invoked on `analysis.css.ast`; element scoping metadata is read back to synthesize `class`/`style` attributes. |
| [compiler_core](compiler_core.md) | Caller: `compile`/`compileModule` orchestration, validated options, `state.js` (`push_ignore`/`pop_ignore`, `set_source`, `adjust`), AST builders used for synthetic bindings. |
| [compiler_diagnostics](compiler_diagnostics.md) | Error (`e.*`) and warning (`w.*`) catalog used by every visitor; `CompileDiagnostic`/code frames render positions computed here. |
| [compiler_types](compiler_types.md) | AST node definitions (`AST.*`), `CompileResult`, and the `Binding`/`BindingKind` types that the scope engine instantiates. |

## 6. Documentation map

All pages of this module's documentation (flat directory, link by file name):

- **Main page** — this file, `compiler_analyzer.md`
- **Sub-modules** (generated):
  - [compiler_analyzer_scope.md](compiler_analyzer_scope.md) — Scope, Binding, Evaluation, ScopeRoot, `create_scopes`, `set_scope`, `get_rune`
  - [compiler_analyzer_block_visitors.md](compiler_analyzer_block_visitors.md) — `AwaitBlock`, `AwaitExpression`, `EachBlock`, `IfBlock`, `KeyBlock`
  - [compiler_analyzer_template_visitors.md](compiler_analyzer_template_visitors.md) — `ConstTag`, `DebugTag`, `HtmlTag`, `ClassDirective`, `StyleDirective`, `TitleElement`, `SvelteFragment`, `SvelteBody`, `SvelteBoundary`, `SvelteDocument`, `SvelteHead`, `SvelteWindow`
  - [compiler_analyzer_js_visitors.md](compiler_analyzer_js_visitors.md) — `ExportDefaultDeclaration`, `ExportNamedDeclaration`, `ExportSpecifier`, `NewExpression`, `TaggedTemplateExpression`, `TemplateElement`
- **Related modules** referenced above: [compiler_parser](compiler_parser.md), [compiler_css_pipeline](compiler_css_pipeline.md), [compiler_core](compiler_core.md), [compiler_diagnostics](compiler_diagnostics.md), [compiler_client_transform](compiler_client_transform.md), [compiler_server_transform](compiler_server_transform.md), [compiler_types](compiler_types.md)
