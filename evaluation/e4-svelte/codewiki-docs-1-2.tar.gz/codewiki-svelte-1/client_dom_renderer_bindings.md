# Client DOM Renderer Bindings (`client_dom_renderer_bindings`)

## 1. Introduction

The `client_dom_renderer_bindings` module is the runtime implementation of Svelte's **`bind:` directive** on the client. It lives in `packages/svelte/src/internal/client/dom/elements/bindings/` and is a leaf sub-module of [client_dom_renderer](client_dom_renderer.md), the client-side rendering backend.

When the Svelte compiler (see [Compiler Back-End (Client & Server Code Generation)](Compiler_Back-End_(Client___Server_Code_Generation).md)) encounters a binding such as `<input bind:value={x}>`, its `BindDirective` visitor does **not** generate ad-hoc DOM code. Instead, it emits a call to one of the runtime functions in this module, passing:

- the DOM node,
- a **getter** thunk (`get`) that reads the bound state reactively,
- an optional **setter** (`set`, defaulting to `get`) that writes user edits back to state.

The binding functions then establish a **two-way synchronization channel**: DOM events push user edits into reactive state, and reactive effects push state changes back into the DOM — with guards for focus, selection, hydration, batching, and media/resize timing edge cases.

> **Note:** These functions are exported on the internal `$.` namespace of `svelte/internal/client` and consumed only by compiler output. They are not public API.

### Scope of this module

| File | Responsibilities |
|---|---|
| `shared.js` | Shared listener/teardown plumbing: `listen`, `listen_to_event_and_reset_event`, `without_reactive_context` |
| `input.js` | `bind_value`, `bind_group`, `bind_checked`, `bind_files` |
| `select.js` | `bind_select_value` (+ `select_option`, `init_select` helpers reused by attribute handling) |
| `props.js` | `bind_prop` — bindable component exports via `$$props` |
| `this.js` | `bind_this` — element/component instance bindings |
| `universal.js` | `bind_content_editable`, `bind_focused`, `bind_property` |
| `media.js` | 11 `<audio>`/`<video>` bindings (`currentTime`, `paused`, `volume`, …) |
| `size.js` | `bind_element_size`, `bind_resize_observer`, `ResizeObserverSingleton` |
| `window.js` | `bind_window_scroll`, `bind_window_size` |
| `document.js` | `bind_active_element` |
| `navigator.js` | `bind_online` |

---

## 2. Position in the System

Bindings sit at the intersection of the **DOM backend** and the **reactive runtime**: they are the only place where user DOM interaction flows *backwards* into signals.

```mermaid
flowchart TB
    subgraph Compiler["Compiler Back-End — Client Transform"]
        BDV["BindDirective visitor<br/>(client/visitors/BindDirective.js)"]
    end

    subgraph CDR["client_dom_renderer"]
        LC["lifecycle API<br/>hydrate / mount / unmount"]
        FND["DOM foundation<br/>hydration · operations · template · css"]
        BLK["control-flow blocks<br/>if · each · await · snippet …"]
        ELEM["elements & events<br/>attributes.js · events.js · transitions.js"]
        BIND["<b>client_dom_renderer_bindings</b><br/>(this module)"]
    end

    subgraph RRC["Reactive Runtime Engine (client_runtime_core)"]
        EFF["effects.js<br/>effect · render_effect · teardown"]
        BAT["batch.js<br/>current_batch · previous_batch"]
        RT["runtime.js · proxy.js<br/>tick · untrack · is · STATE_SYMBOL"]
    end

    DEV["client_dev_mode<br/>ownership & validation instrumentation"]

    BDV -- "emits $.bind_xxx(node, get, set)" --> BIND
    LC --> FND
    FND --> BIND
    ELEM --> BIND
    BIND --> EFF
    BIND --> BAT
    BIND --> RT
    BIND -. "DEV-only diagnostics" .-> DEV
```

Related modules (do not re-describe them here):

- **[client_dom_renderer_lifecycle_api](client_dom_renderer_lifecycle_api.md)** — `hydrate`/`mount`/`unmount` drive the init/teardown lifecycle inside which bindings register.
- **[client_dom_renderer_dom_foundation](client_dom_renderer_dom_foundation.md)** — provides the `hydrating` flag (`hydration.js`) that bindings consult to adopt server-rendered DOM values.
- **[client_dom_renderer_elements_and_events](client_dom_renderer_elements_and_events.md)** — `attribute_effect` (attributes.js) reuses this module's `select_option`/`init_select`; `events.js` handles delegated events separately from binding listeners.
- **[client_dom_renderer_control_flow_blocks](client_dom_renderer_control_flow_blocks.md)** — `each` blocks provide the index "parts" used by `bind_group` and `bind_this`.
- **[client_runtime_core](client_runtime_core.md)** / **[client_runtime_core_batching](client_runtime_core_batching.md)** — effect creation, batch bookkeeping, `tick()`, proxies.
- **[server_runtime](server_runtime.md)** — the SSR counterpart (`bind_props`); bindings here are client-only.

---

## 3. The Binding Contract

Every two-way binding function follows the same signature convention:

```js
bind_x(element, get, set = get)
```

- **`element`** — the DOM node (or `window`/`document`/`navigator` proxy target).
- **`get`** — a thunk; calling it inside an effect registers a reactive dependency on the bound state.
- **`set`** — writes user input back to state (defaults to `get`, kept for older/one-way call shapes).

Execution pattern at runtime:

1. **Listeners first.** The binding attaches DOM event listeners *immediately* and usually invokes the handler once synchronously to adopt the element's initial DOM value into state (unless hydration says otherwise).
2. **Writer effect second.** A `render_effect` (cheap, synchronous, render-phase) or `effect` (later, post-mount ordering) reads `get()` and writes the DOM property through **guards** (focus, equality, NaN, timing).
3. **Cleanup via `teardown()`.** Listeners, observers, rAF loops and group memberships are unregistered when the owning effect tree is destroyed (see `unmount` in [client_dom_renderer_lifecycle_api](client_dom_renderer_lifecycle_api.md)).

```mermaid
flowchart LR
    subgraph DOM["DOM element"]
        DOMP["DOM property / state<br/>value · checked · scrollY · currentTime …"]
    end
    subgraph BF["binding function"]
        LIST["DOM event listener<br/>(wrapped in without_reactive_context)"]
        WRITER["writer effect<br/>(render_effect or effect)"]
    end
    ST["Component state<br/>(source signals)"]

    DOMP -- "user interaction event" --> LIST
    LIST -- "set(v) — batched signal write" --> ST
    ST -- "invalidation" --> WRITER
    WRITER -- "guarded property write" --> DOMP
```

Two details are essential:

- **`without_reactive_context`** (`shared.js`) temporarily nulls `active_reaction`/`active_effect` while a DOM event handler runs. Without it, reads inside handlers (e.g. `window.scrollX`) would be recorded as dependencies of whatever effect happens to be flushing.
- **`teardown(fn)`** creates a tiny always-clean effect whose only job is to run `fn` on destruction — the idiomatic cleanup hook for listeners.

---

## 4. Shared Infrastructure (`shared.js`)

### `listen(target, events, handler, call_handler_immediately = true)`
Attaches a single handler to several event names and registers removal in `teardown`. By default the handler runs once immediately — this is how bindings **adopt the DOM's initial value** (e.g. `bind_volume` calls back right away when `get() == null`).

### `listen_to_event_and_reset_event(element, event, handler, on_reset = handler)`
Used by all form-element bindings. In addition to the normal event it wires a **form-reset chain** on the internal `element.__on_r` slot: submitting a form reset re-invokes the handler with `is_reset = true`, and handlers read `defaultValue`/`defaultChecked`/`[selected]` in that case. Chaining `prev()` allows an element to carry *multiple* bindings (the classic `<input type="checkbox" bind:group bind:checked>`). It also calls `add_form_reset_listener()` once per document.

### `without_reactive_context(fn)`
Runs `fn` with the active reaction/effect cleared and restores them afterwards. All user-input handlers funnel through this so writes happen in the **current batch** without polluting dependency graphs.

---

## 5. Binding Families

### 5.1 Form controls — `input.js`

#### `bind_value(input, get, set)`

The most intricate binding. Key behaviours:

- **DOM → state:** on `input` (and form reset), the raw value is coerced — `number`/`range` inputs go through `to_number` (`'' → null`). The batch that carried the edit is recorded in a module-closure `WeakSet batches`, then the handler `await tick()`s (see [client_runtime_core](client_runtime_core.md)) and re-reads `get()`. If accessors/validation changed the value, the input is rewritten and `selectionStart`/`selectionEnd` are restored (clamped to the new length).
- **Initial adoption:** if hydrating and `defaultValue !== input.value`, or if state is `null` while the input has a value, the DOM value is pushed into state (batch recorded).
- **State → DOM (`render_effect`):** guarded writes, each fixing a historical bug class:
  - *Focused-input guard:* while the input `=== document.activeElement` and the pending update originates from a batch this binding itself created (deferred async work such as `<input bind:value={query}><p>{await find(query)}</p>`), the write is **skipped** so the user is never clobbered. `previous_batch ?? current_batch` is checked because render effects can run before `previous_batch` is set in non-async mode.
  - `0` vs `00` on number inputs (identity via `to_number` comparison).
  - Partially-invalid `<input type="date">` states are not cleared while typing.
  - Identical values are not reassigned, so `minlength` validation still works.

```mermaid
sequenceDiagram
    autonumber
    participant U as User
    participant E as input element
    participant L as input handler
    participant B as batch bookkeeping
    participant S as state (get/set)
    participant W as render_effect

    U->>E: types a value
    E->>L: input event
    Note over L: runs via without_reactive_context
    L->>S: set(coerced value)
    L->>B: batches.add(current_batch)
    L->>L: await tick()
    L->>S: value = get()
    alt value changed after accessor validation
        L->>E: input.value = value<br/>(selection restored)
    end
    S-->>W: invalidation
    alt focused AND batch originated from this input
        Note over W: skip — never rewrite a focused input<br/>while its own update is deferred
    else
        W->>E: input.value = get()<br/>(0/00, partial date, identity skips)
    end
```

#### `bind_group(inputs, group_index, input, get, set)`
Shared by checkbox arrays and radio groups:

- `inputs` is a shared per-group array; `group_index` (one entry per enclosing `each` block, from the compiler) drills into nested arrays so each-block iterations get isolated groups.
- On `change`: checkboxes aggregate the `__value`s of all checked inputs (`get_binding_group_value`); radios use proxy-aware equality (`is`) against `input.__value`.
- A `render_effect` applies state → `checked`. During hydration a `defaultChecked`/`checked` mismatch flags a `hydration_mismatch`, resolved in a queued microtask that recomputes the group value from the DOM.
- Group ordering is normalized by sorting members with `compareDocumentPosition` inside a microtask, guarded by a module-level `pending` set so it happens once per group.
- `teardown` splices the input out of the group. The `hydration_mismatch` variable is deliberately `let` so dead code can be tree-shaken in production.

#### `bind_checked(input, get, set)`
`change` (+ reset) listener writes `input.checked` to state; hydration adopts DOM state on mismatch; a `render_effect` coerces state with `Boolean(value)`.

#### `bind_files(input, get, set)`
`change` listener publishes `input.files`. Effectively one-way out (browsers reject programmatic `FileList` assignment); hydration adopts `input.files` if present.

### 5.2 Select — `select.js`

`bind_select_value(select, get, set)` is the `<select bind:value>` implementation and also ships two helpers reused elsewhere (`attribute_effect` in `attributes.js` calls them for static `value` attributes on `<select>`):

- **`select_option(select, value, mounting)`** — syncs option selection; multiple selects require an array (else the `select_multiple_invalid_value` warning fires); single selects match via `is()`, falling back to `selectedIndex = -1`.
- **`init_select(select)`** — a `MutationObserver` (`childList`, `subtree`, `attributes:['value']`) re-applies the cached `select.__value` when `<option>`s are added/removed/re-valued (e.g. options inside `#each`), **without** writing back to state — the model is preserved unless the user changes it.
- **`bind_select_value`** — the `change` handler queries `[selected]` on form reset vs `:checked` normally (multiple → mapped array). Notably the writer is a full **`effect`, not a `render_effect`**, so it runs *after* `each` blocks have updated their options. On mount with `undefined` state, the DOM's `:checked` option is adopted and pushed into state.

### 5.3 Component props — `props.js`

`bind_prop(props, prop, value)` makes a component's *exported* (non-prop) variable reachable through `$$props` so a parent can `bind:x`. It only acts if a **setter descriptor** exists (i.e. the export compiled to an accessor), assigns the initial value, and `teardown`s by assigning `null` so the slot is released on unmount.

### 5.4 `bind:this` — `this.js`

`bind_this(element_or_component, update, get_value, get_parts)` assigns the element/component instance into state:

- A nested **`effect` → `render_effect`** pair tracks only the *parts* (each-block context values), not the bound value itself, avoiding spurious reruns; `untrack` guards the comparison.
- `is_bound_this` matches proxies by their `STATE_SYMBOL` rather than identity.
- On each-block context change, the binding updates the new position **and nullifies the stale position** if it still points at this instance.
- Because effects cannot run during teardown, destruction nulls the binding in a `queue_micro_task`.

### 5.5 Universal — `universal.js`

| Function | Behaviour |
|---|---|
| `bind_content_editable(property, element, get, set)` | `innerHTML` / `innerText` / `textContent`. DOM→state on `input`; state→DOM `render_effect` coerces to string. If state is `null`, the **DOM content is adopted** into state instead. |
| `bind_property(property, event_name, element, set, get?)` | Generic escape hatch driven by the compiler's `binding_properties` table (properties with a configured event, e.g. `indeterminate`). One-way out unless a getter is supplied (bidirectional per the compiler). Explicit `teardown` is added **only** for `document.body` / `window` / `document`, since ordinary elements are destroyed with their effect subtree. |
| `bind_focused(element, set)` | One-way out: `focus`/`blur` → `element === document.activeElement`. |

### 5.6 Media — `media.js`

All eleven functions target `HTMLMediaElement` (`<audio>`/`<video>`):

| Binding | Function | Mechanism | Writer |
|---|---|---|---|
| `currentTime` | `bind_current_time` | `requestAnimationFrame` loop **while playing** + `timeupdate` (covers paused scrubbing via native controls); state→DOM seek only when `!isNaN` | `render_effect` (seek) |
| `buffered` | `bind_buffered` | `loadedmetadata`, `progress`, `timeupdate`, `seeking`; deep range comparison because `TimeRanges` returns a fresh object with no spec'd event | — (out) |
| `played` | `bind_played` | `timeupdate` → range array | — (out) |
| `seekable` | `bind_seekable` | `loadedmetadata` → range array | — (out) |
| `seeking` | `bind_seeking` | `seeking`/`seeked` | — (out) |
| `ended` | `bind_ended` | `timeupdate`/`ended` | — (out) |
| `readyState` | `bind_ready_state` | 7 ready-state events | — (out) |
| `playbackRate` | `bind_playback_rate` | `ratechange`; writer and listener are both `effect`s so the element is mounted first (the browser resets an unmounted element's rate to 1) | `effect` |
| `paused` | `bind_paused` | `play`/`pause`/`canplay`; `effect` drives `media.play()`/`pause()`; a rejected `play()` promise writes `paused = true`; `canplay` catches src swaps that silently pause | `effect` (play/pause control) |
| `volume` | `bind_volume` | `volumechange`; initial adoption when `get() == null` | `render_effect` |
| `muted` | `bind_muted` | `volumechange`; initial adoption when `get() == null` | `render_effect` |

`time_ranges_to_array` converts `TimeRanges` into `{ start, end }[]` for the three range bindings.

### 5.7 Size — `size.js`

Element-dimension bindings are built on **one native `ResizeObserver` per box mode**, wrapped by `ResizeObserverSingleton`:

- `#listeners` is a `WeakMap<Element, Set<listener>>`; `observe()` lazily creates the underlying `ResizeObserver`, fans entries out to all listeners, caches them in the static `entries` WeakMap, and returns an unsubscribe function (used as teardown).
- Three eagerly-created (treeshakeable `/* @__PURE__ */`) singletons: `content-box`, `border-box`, `device-pixel-content-box`.

```mermaid
classDiagram
    direction LR
    class ResizeObserverSingleton {
        -WeakMap~Element~ #listeners
        -ResizeObserver #observer
        -ResizeObserverOptions #options
        +observe(element, listener) Function
        -getObserver() ResizeObserver
        +entries$ WeakMap~Element~
    }
    class ResizeObserver {
        +observe(element, options)
        +unobserve(element)
    }
    ResizeObserverSingleton ..> ResizeObserver : creates lazily, one per singleton
```

```mermaid
flowchart LR
    subgraph SG["Module-level singletons (eagerly created)"]
        CB["resize_observer_content_box<br/>box: 'content-box'"]
        BB["resize_observer_border_box<br/>box: 'border-box'"]
        DP["resize_observer_device_pixel_content_box"]
    end
    BRS["bind_resize_observer<br/>contentRect · contentBoxSize ·<br/>borderBoxSize · devicePixelContentBoxSize"]
    BES["bind_element_size<br/>clientWidth/Height · offsetWidth/Height"]

    BRS --> CB
    BRS --> BB
    BRS --> DP
    BES --> BB
    BB --> OUT["set(element type) on resize<br/>effect wraps the initial untrack'd read"]
```

- `bind_resize_observer(element, type, set)` — one-way out; routes the binding name to the matching singleton.
- `bind_element_size(element, type, set)` — border-box observer; an `effect` performs the initial read inside `untrack` (the update may read signals that must not become dependencies) and returns the unsubscribe function as its teardown.

### 5.8 Window, Document, Navigator

| Binding | Function | Events | Notes |
|---|---|---|---|
| `scrollX` / `scrollY` | `bind_window_scroll(type, get, set)` | `scroll` (passive) | Handler runs in `without_reactive_context`; a `scrolling` flag + 100 ms timeout debounces user scrolling (a `scrollend` upgrade is noted as future work). The writer `render_effect` skips the **first** run for accessibility (never force-scroll on mount) and while `scrolling`. A trailing `effect(target_handler)` captures the initial position, since browsers don't emit `scroll` on load. |
| `innerWidth` / `innerHeight` / `outerWidth` / `outerHeight` | `bind_window_size(type, set)` | `resize` | One-way out, `without_reactive_context`. |
| `activeElement` | `bind_active_element(update)` | `focusin` / `focusout` | Ignores a `focusout` whose `relatedTarget` is set (focus merely moving between elements) to avoid transiently resetting to `document.body`. |
| `online` | `bind_online(update)` | `online` / `offline` | Publishes `navigator.onLine`. |

State machine for `bind_window_scroll`:

```mermaid
stateDiagram-v2
    [*] --> idle
    idle --> scrolling : scroll event → set(scrollX/Y), restart 100 ms timer
    scrolling --> idle : timer expires
    note right of scrolling : writer render_effect is suppressed (user gesture wins)
    note right of idle : writer may scrollTo(get()) unless value is null
```

---

## 6. Compiler Integration

The compiler side (documented in [Compiler Back-End (Client & Server Code Generation)](Compiler_Back-End_(Client___Server_Code_Generation).md), sub-module *compiler_client_transform_elements_and_directives*) maps every `bind:` name to a runtime call in the `BindDirective` visitor. It builds `get` as a thunk of the bound expression and `set` as an arrow performing the assignment (`set` is dropped when identical to `get`, in which case the runtime's `set = get` default applies). In dev mode it additionally calls `validate_binding` (via [client_runtime_core](client_runtime_core.md)) when a member expression is bound inside a control-flow block unless `binding_property_non_reactive` is ignored.

| `bind:` name(s) | Emitted runtime call |
|---|---|
| `value` on `<select>` | `$.bind_select_value(node, get, set)` |
| `value` (other inputs) | `$.bind_value(node, get, set)` |
| `checked` / `group` / `files` | `$.bind_checked` / `$.bind_group(name, eachIndexes, node, get, set)` / `$.bind_files` |
| `this` | `$.bind_this(node, update, get, get_parts)` |
| `innerHTML` / `innerText` / `textContent` | `$.bind_content_editable(prop, node, get, set)` |
| property with configured event (generic) | `$.bind_property(name, event, node, set, get?)` |
| `focused` | `$.bind_focused(node, set)` |
| media (`currentTime`, `paused`, `volume`, …) | `$.bind_*` (media.js) |
| `contentRect`, `contentBoxSize`, `borderBoxSize`, `devicePixelContentBoxSize` | `$.bind_resize_observer(node, name, set)` |
| `clientWidth` / `clientHeight` / `offsetWidth` / `offsetHeight` | `$.bind_element_size(node, name, set)` |
| `scrollX` / `scrollY` | `$.bind_window_scroll('x'\|'y', get, set)` |
| `innerWidth` … `outerHeight` | `$.bind_window_size(name, set)` |
| `activeElement` | `$.bind_active_element(set)` |
| `online` | `$.bind_online(set)` |

**Emission ordering** (inside the visitor):

- Default: the call is pushed to `after_update`, so bindings run *after* attribute render effects and in order relative to events/actions.
- If the element has a `use:` directive, the call is wrapped in `$.effect(() => …)` so the binding initializes after actions.
- `bind:this` is pushed to `init`: it is one-way and can influence the render effect.
- `bind_group` receives the `binding_group_name` plus one index per enclosing `each` block (keyed blocks wrap the index in `$.get`), and folds the element's non-static `value` attribute into the getter so value changes re-trigger group updates.

```mermaid
sequenceDiagram
    autonumber
    participant Src as Svelte source
    participant C as BindDirective (compiler)
    participant G as generated client code
    participant R as runtime binding
    participant S as source signals

    Src->>C: <input bind:value={x}>
    C->>G: $.bind_value(node, () => x, ($$value) => x = $$value)
    Note over G: placed in after_update<br/>(or $.effect wrapper when use: is present)
    G->>R: invoke during component init
    R->>R: listen(node, events, handler)<br/>+ writer effect
    loop on state change
        S-->>R: writer effect reruns
        R->>R: guarded DOM write
    end
    loop on user input
        R->>S: set(value) inside current batch
    end
```

---

## 7. Cross-Cutting Behaviours

### Hydration adoption
Bindings coordinate with `hydrating` from the DOM foundation (see [client_dom_renderer_dom_foundation](client_dom_renderer_dom_foundation.md)): when server markup and client state disagree, **the DOM wins** and is pushed into state.

| Binding | Hydration check |
|---|---|
| `bind_value` | `defaultValue !== value` → adopt (numberlike coerced) |
| `bind_checked` | `defaultChecked !== checked` → adopt |
| `bind_group` | mismatch flagged; microtask recomputes group value from checked inputs |
| `bind_files` | adopt `input.files` if set |
| `bind_select_value` | mount + `undefined` state → adopt `:checked` option |

### Batching & focus safety
`current_batch` / `previous_batch` (see [client_runtime_core_batching](client_runtime_core_batching.md)) are consulted by `bind_value` to implement the "never rewrite a focused input" guarantee, and by `bind_group`'s getter for keyed-each index reads.

### Teardown discipline
Every listener, `MutationObserver`, `ResizeObserver` subscription, rAF loop and group membership is released through `teardown` (or an effect-returned cleanup), so `unmount` ([client_dom_renderer_lifecycle_api](client_dom_renderer_lifecycle_api.md)) fully detaches a component — including bindings targeting globals (`window`, `document`, `navigator`, `<body>`), which hold no DOM reference that dies with the component.

### Dev-mode diagnostics
- `bind:value` on `type="checkbox"` raises `bind_invalid_checkbox_value` (dev only).
- `bind:value` with a non-array on a multiple `<select>` raises `select_multiple_invalid_value`.
- Non-reactive member-expression bindings inside blocks trigger `validate_binding` unless suppressed (`binding_property_non_reactive`), via [client_dev_mode](client_dev_mode.md).

---

## 8. Summary

`client_dom_renderer_bindings` turns the declarative `bind:` directive into a set of small, self-contained runtime adapters. Each adapter pairs an *immediate* DOM-listener side (writes to state, wrapped in `without_reactive_context`, batch-aware) with an *effect-driven* DOM-writer side (guarded against focus loss, identity churn, partial media states and hydration mismatches), and cleans up deterministically through the effect teardown system. The compiler's `BindDirective` visitor is the single integration point that selects and parameterizes the appropriate adapter, keeping the generated output thin and the edge-case logic centralized in this module.
