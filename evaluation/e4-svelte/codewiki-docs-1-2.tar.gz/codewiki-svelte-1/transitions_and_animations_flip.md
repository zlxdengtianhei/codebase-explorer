# Transitions & Animations — FLIP Animation (`svelte/animate`)

> **Module:** `transitions_and_animations_flip`
> **Source:** `packages/svelte/src/animate/index.js` (implementation) · `packages/svelte/src/animate/public.d.ts` (type contracts)
> **Public entry:** `svelte/animate`
> **Parent system:** [transitions_and_animations](transitions_and_animations.md) within the *Motion & Visual Effects System*

---

## 1. Introduction

The **FLIP module** powers Svelte's `animate:flip` directive — a *layout animation* primitive that smoothly moves an element from its old position to its new one when a **keyed `{#each}` block** reorders, inserts, or removes siblings.

`flip` stands for **First, Last, Invert, Play** (Paul Lewis, [aerotwist.com/blog/flip-your-animations](https://aerotwist.com/blog/flip-your-animations/)):

1. **First** — record where the element is *before* the DOM changes;
2. **Last** — record where it is *after* the change;
3. **Invert** — apply a transform that visually snaps it back to the *First* position;
4. **Play** — animate that inverted transform away to identity.

The module itself implements only the **Invert** (geometry math) and **Play** (config generation) steps. The **First/Last** measurements are taken by the client runtime's each-item animation manager, which hands the module two `DOMRect`s and expects an `AnimationConfig` back (see [client_dom_renderer_elements_and_events](client_dom_renderer_elements_and_events.md)). Consequently the module is:

- **Stateless** — unlike `crossfade` (which owns send/receive pairing `Map`s), `flip` keeps no state between calls; all positional bookkeeping lives in the runtime.
- **Pure compute** — one exported factory (`flip`), one private helper (`get_zoom`), and a single import (`cubicOut` from the [easing library](transitions_and_animations_easing.md)).
- **Client-only** — it reads `getComputedStyle`/`clientWidth` at call time, so it is never invoked during SSR; moves only happen in a live DOM.

---

## 2. Module at a Glance

| Property | Value |
|---|---|
| Files | `packages/svelte/src/animate/index.js` (implementation), `packages/svelte/src/animate/public.d.ts` (contracts) |
| Public exports | `flip` (function) · `FlipParams`, `AnimationConfig` (interfaces); `public.d.ts` also re-exports `./index.js` |
| Directive | `animate:flip` / `animate:flip={params}` — must be the immediate child of a **keyed** `{#each}` block (enforced at compile time) |
| Input | the element + `{ from: DOMRect, to: DOMRect }` measured by the runtime before/after reconciliation |
| Output | an `AnimationConfig` consumed by the Web Animations API driver in the client DOM renderer |
| Default easing | `cubicOut` (from [transitions_and_animations_easing](transitions_and_animations_easing.md)) |
| Default duration | distance-adaptive: `(d) => Math.sqrt(d) * 120` ms |
| Dependencies | one import (`cubicOut`) — fully tree-shakeable |
| Environment | browser-only at runtime; a compile-time no-op during SSR |

---

## 3. API Reference

### 3.1 `flip(node, { from, to }, params?)`

```js
/**
 * @param {Element} node
 * @param {{ from: DOMRect; to: DOMRect }} fromTo
 * @param {FlipParams} params
 * @returns {AnimationConfig}
 */
export function flip(node, { from, to }, params = {})
```

| Argument | Type | Meaning |
|---|---|---|
| `node` | `Element` | The element being animated. Sampled once for computed `transform`, `transform-origin`, size and zoom. |
| `from` | `DOMRect` | The element's rect **before** the each-block reconciliation (*First*). |
| `to` | `DOMRect` | The element's rect **after** the reconciliation (*Last*). |
| `params` | `FlipParams` | Optional `delay`, `duration`, `easing` overrides. |

Returns an `AnimationConfig` whose `css(t, u)` generator interpolates `transform: translate(...) scale(...)` (see §4).

### 3.2 `FlipParams` (`public.d.ts`)

```ts
export interface FlipParams {
    delay?: number;
    duration?: number | ((len: number) => number);
    easing?: (t: number) => number;
}
```

| Field | Default | Notes |
|---|---|---|
| `delay` | `0` | Milliseconds before playback starts. |
| `duration` | `(len) => Math.sqrt(len) * 120` | Number **or** a function receiving the straight-line travel distance `len = √(dx² + dy²)` — enabling distance-adaptive timing. |
| `easing` | `cubicOut` | Any `(t) => number` curve from `svelte/easing` (or a custom one). |

### 3.3 `AnimationConfig` (`public.d.ts`)

```ts
export interface AnimationConfig {
    delay?: number;
    duration?: number;
    easing?: (t: number) => number;
    css?: (t: number, u: number) => string;
    tick?: (t: number, u: number) => void;
}
```

- This is the **entire integration surface** with the runtime: the WAAPI driver destructures these five fields, pre-samples `css(t, u)` into keyframes (one per ~60 fps frame), and invokes `tick` per frame for JS-driven effects.
- The source carries the comment *“todo: same as Transition, should it be shared?”* — `AnimationConfig` is structurally identical to `TransitionConfig` from [transitions_and_animations_transitions](transitions_and_animations_transitions.md). The duplication is deliberate for now: `transition:` runs on mount/unmount with in/out directions, while `animate:` only ever plays forward (t: 0 → 1).
- Both `FlipParams` and `AnimationConfig` are surfaced publicly through the package type layer (see [svelte-types](svelte-types.md)).

---

## 4. The FLIP Geometry — How the Invert Is Computed

Steps 1–2 (First/Last) happen in the runtime; everything below is this module's job.

| Quantity | Formula | Meaning |
|---|---|---|
| normalized origin | `[ox, oy] = transformOrigin.split(' ').map(parseFloat)`; `ox /= node.clientWidth`; `oy /= node.clientHeight` | computed `transform-origin` re-expressed as a pair in `[0, 1]` relative to the element box |
| effective zoom | `get_zoom(node)` (§4.1) | compensates CSS `zoom` up the ancestor chain |
| render scale | `sx = clientWidth / to.width / zoom`; `sy = clientHeight / to.height / zoom` | converts *Last*-rect distances into actual rendered pixels, absorbing parent transforms & zoom |
| First origin | `fx = from.left + from.width · ox`; `fy = from.top + from.height · oy` | where the origin sat *before* the reorder |
| Last origin | `tx = to.left + to.width · ox`; `ty = to.top + to.height · oy` | where the origin sits *now* |
| inverse translation | `dx = (fx − tx) · sx`; `dy = (fy − ty) · sy` | the offset that puts the element visually back at *First* |
| inverse scale | `dsx = from.width / to.width`; `dsy = from.height / to.height` | the relative size *at the start* (handles items that also changed size) |

The existing computed `transform` is preserved and **prepended** (`transform === 'none' ? '' : transform`), so `flip` composes with the element's static styling rather than clobbering it.

### Frame semantics of `css(t, u)`

```js
css: (t, u) => {
    var x = u * dx;
    var y = u * dy;
    var sx = t + u * dsx;
    var sy = t + u * dsy;
    return `transform: ${transform} translate(${x}px, ${y}px) scale(${sx}, ${sy});`;
}
```

| `t` (eased progress) | `u = 1 − t` | translate | scale | Visual result |
|---|---|---|---|---|
| `0` | `1` | `(dx, dy)` | `(dsx, dsy)` | element rendered exactly at its **old** position/size |
| `1` | `0` | `(0, 0)` | `(1, 1)` | element settled at its **new** natural position/size |

`animate:flip` always plays *forward* (t: 0 → 1) — there is no in/out duality, unlike `transition:`.

### 4.1 Zoom compensation — `get_zoom(element)`

```mermaid
flowchart TD
    A["get_zoom(element)"] --> B{"'currentCSSZoom' in element ?"}
    B -- "yes — modern engines" --> C["return element.currentCSSZoom<br/>(effective zoom per CSS Viewport spec)"]
    B -- "no — legacy fallback" --> D["walk parentElement chain,<br/>zoom *= +getComputedStyle(current).zoom"]
    C --> E["used to correct sx / sy:<br/>sx = clientWidth / to.width / zoom"]
    D --> E
```

- The fast path reads `currentCSSZoom` — the spec-defined *effective* zoom (see the in-source reference: `https://drafts.csswg.org/css-viewport/#effective-zoom`).
- The fallback multiplies the computed `zoom` of every ancestor (`O(depth)` `getComputedStyle` calls, once per animation start — not per frame).
- Without this correction, a `flip` inside a zoomed container would compute deltas in *zoomed* coordinates and visibly overshoot/undershoot.

### 4.2 Distance-adaptive default duration

The function-form duration is resolved **once**, at animation start:

```
duration = duration(Math.sqrt(dx*dx + dy*dy))   // straight-line travel distance
default:  (d) => Math.sqrt(d) * 120             // ms
```

Example: an item moving 300 px right and 400 px down travels `√(300² + 400²) = 500` px → default duration `√500 · 120 ≈ 2683 ms`. Short hops therefore animate quickly, long jumps slowly — a constant speed feel without any per-frame adaptation.

### 4.3 Computation pipeline

```mermaid
flowchart TD
    A["flip(node, { from, to }, params)"] --> B["apply defaults:<br/>delay = 0 · easing = cubicOut<br/>duration = d => Math.sqrt(d) * 120"]
    B --> C["read computed style once:<br/>transform · transform-origin"]
    C --> D["normalize origin:<br/>ox /= clientWidth · oy /= clientHeight"]
    D --> E["zoom = get_zoom(node)<br/>sx = clientWidth / to.width / zoom<br/>sy = clientHeight / to.height / zoom"]
    E --> F["First origin:<br/>fx = from.left + from.width * ox<br/>fy = from.top + from.height * oy"]
    F --> G["Last origin:<br/>tx = to.left + to.width * ox<br/>ty = to.top + to.height * oy"]
    G --> H["inverse translation:<br/>dx = (fx - tx) * sx · dy = (fy - ty) * sy"]
    G --> I["inverse scale:<br/>dsx = from.width / to.width · dsy = from.height / to.height"]
    H --> J["duration resolved:<br/>duration(Math.sqrt(dx*dx + dy*dy)) if function"]
    I --> J
    J --> K["AnimationConfig:<br/>css(t, u) => 'transform: T translate(u*dx, u*dy)<br/>scale(t + u*dsx, t + u*dsy)'"]
```

---

## 5. Internal Composition & Dependency Graph

The module is tiny and flat: one public factory, one private helper, and one cross-module import.

```mermaid
flowchart TB
    subgraph MODULE["svelte/animate — this module"]
        PUB["public.d.ts<br/>AnimationConfig · FlipParams<br/>export * from './index.js'"]
        subgraph IMPL["index.js"]
            FLIP["flip(node, { from, to }, params)"]
            ZOOM["get_zoom(element)<br/>(private — not exported)"]
        end
    end

    subgraph EASING["svelte/easing"]
        CUBIC["cubicOut(t)<br/>f = t - 1; f³ + 1"]
    end

    WEB["Browser APIs<br/>getComputedStyle · clientWidth/clientHeight<br/>currentCSSZoom / computed zoom"]

    subgraph RUNTIME["Client DOM Renderer"]
        MGR["animation() — EachItem manager<br/>measure / fix / apply / unfix"]
        WAAPI["animate() — keyframe sampler<br/>Web Animations API driver"]
    end

    FLIP -->|"import"| CUBIC
    FLIP -->|"transform-origin sampling"| WEB
    ZOOM -->|"zoom per ancestor"| WEB
    FLIP -->|"get_zoom(node)"| ZOOM
    MGR -->|"fn(element, { from, to }, params)"| FLIP
    FLIP -->|"AnimationConfig"| WAAPI
    PUB -.->|"documents the contract"| FLIP
```

---

## 6. Architecture — Position in the Overall System

`flip` sits at the *end* of a compile-time → runtime → module → WAAPI pipeline. The compiler lowers the directive into a runtime call; the each block measures; the module computes; the driver plays.

```mermaid
flowchart TB
    subgraph USER["User Land"]
        SRC["{#each items as item (item.id)}<br/>  &lt;li animate:flip=&#123;&#123; duration: 300 &#125;&#125;&gt;…&lt;/li&gt;<br/>{/each}"]
    end

    subgraph COMPILER["Compiler Front-End / Back-End"]
        AST["AnimateDirective AST node<br/>(name = 'flip', expression = params)<br/>compiler_types_template_ast"]
        CHECK["analyzer: animate: must be the<br/>immediate child of a keyed each block"]
        GEN["client transform codegen:<br/>$.animation(el, () => flip, () => params)<br/>compiler_client_transform_elements_and_directives"]
    end

    subgraph RENDERER["Client DOM Renderer"]
        MGR["animation() — attaches manager<br/>(measure · fix · apply · unfix) to the each item"]
        EACH["each block reconciliation drives the hooks<br/>client_dom_renderer_control_flow_blocks"]
        DRIVER["animate() — samples css(t, u) keyframes,<br/>plays via element.animate()"]
    end

    MODULE["flip — svelte/animate (this module)"]
    EASE["svelte/easing — cubicOut default"]
    TYPES["svelte-types — FlipParams · AnimationConfig public surface"]
    DOM["DOM element"]

    SRC --> AST --> CHECK --> GEN
    GEN --> MGR
    EACH --> MGR
    MGR -->|"{ from, to } DOMRects + params"| MODULE
    MODULE -->|"import"| EASE
    MODULE -->|"AnimationConfig"| DRIVER --> DOM
    MODULE -.->|"types re-exported"| TYPES
```

**Compile-time contract.** `animate:x` is parsed into an `AnimateDirective` node and validated during analysis — it is only legal as an immediate child of a keyed `{#each}` block, because the runtime feature it depends on (the per-item animation manager registered on `current_each_item`) exists only in that context. The client transform then emits `$.animation(element, () => flip, () => ({ ...params }))`, deferring both the module import and the params evaluation to animation time (good for tree-shaking and dynamic params).

---

## 7. Runtime Integration — the EachItem Animation Manager

`animation()` (in `dom/elements/transitions.js`, see [client_dom_renderer_elements_and_events](client_dom_renderer_elements_and_events.md)) stores a manager on the each item (`item.a`) with four hooks. The keyed-each reconciliation (`commit() → reconcile()`, see [client_dom_renderer_control_flow_blocks](client_dom_renderer_control_flow_blocks.md)) invokes them around the DOM mutation:

| Hook | Responsibility |
|---|---|
| `measure()` | **First** — `from = element.getBoundingClientRect()` before nodes move. |
| `fix()` | Temporarily pins the element (`position: absolute` + fixed width/height + a translate to the old spot) so it does not visually jump the instant the DOM order changes. **Skipped if `element.getAnimations().length > 0`** — an already-running animation (e.g. a `crossfade` translate) would override these inline styles anyway. |
| `apply()` | **Last + Play** — aborts any previous animation, re-measures `to`, and only if the rect actually changed calls `flip(element, { from, to }, params())` and starts `animate(element, config, undefined, 1, callback)`. |
| `unfix()` | Restores the stashed styles — the animation's inverted transform keeps the element visually in place from here on. |

The manager is also re-bound when the element instance changes (e.g. `<svelte:element>` swapping its tag mid-flight), rather than recreated, so a concurrent reconciliation cannot orphan it.

```mermaid
sequenceDiagram
    autonumber
    participant S as state change — array reordered
    participant R as each block reconciliation<br/>(reconcile)
    participant M as EachItem manager (item.a)
    participant F as flip — svelte/animate
    participant W as animate() — WAAPI driver
    participant D as DOM element

    S->>R: derived collection re-evaluated
    R->>D: measure() → from = getBoundingClientRect()
    Note over R,D: DOM nodes moved to the new order
    R->>D: fix() — position absolute + translate to old spot<br/>(skipped if an animation is already running)
    R->>M: apply()
    M->>D: to = getBoundingClientRect()
    alt rect actually changed
        M->>F: flip(element, { from, to }, params)
        F->>F: getComputedStyle once — transform,<br/>transform-origin, effective zoom
        F-->>M: AnimationConfig { delay, duration, easing, css(t, u) }
        M->>W: animate(element, config, undefined, 1, callback)
        loop per keyframe (~60 fps)
            W->>F: css(eased t, 1 - t)
            F-->>W: transform string
        end
        W->>D: play keyframes via element.animate()
        W-->>M: finished → abort bookkeeping
        R->>D: unfix() — restore stashed styles
    else rect unchanged
        Note over M: no animation — element never moved
    end
```

The clock underneath `animate()`'s per-frame `tick` is the shared rAF task queue ([client_runtime_core_runtime](client_runtime_core_runtime.md)).

---

## 8. Usage Examples

### 8.1 Basic reorder animation

```svelte
<script>
  let items = $state([
    { id: 1, name: 'alpha' },
    { id: 2, name: 'beta' },
    { id: 3, name: 'gamma' }
  ]);

  function shuffle() {
    items = items.slice().sort(() => Math.random() - 0.5);
  }
</script>

<button onclick={shuffle}>shuffle</button>

{#each items as item (item.id)}
  <li animate:flip>{item.name}</li>
{/each}
```

### 8.2 Tuned params — fixed duration, custom curve, delay

```svelte
<script>
  import { flip } from 'svelte/animate';
  import { quadOut } from 'svelte/easing';
</script>

{#each items as item (item.id)}
  <li animate:flip={{ delay: 50, duration: 300, easing: quadOut }}>
    {item.name}
  </li>
{/each}
```

### 8.3 Distance-based duration (the same hook the default uses)

```svelte
<li animate:flip={{ duration: (d) => Math.min(d, 600) }}>
  {item.name}
</li>
```

### 8.4 Combining `animate:flip` with `transition:`

```svelte
<script>
  import { flip } from 'svelte/animate';
  import { crossfade } from 'svelte/transition';
</script>

{#each items as item (item.id)}
  <li animate:flip transition:crossfade={{ duration: 200 }}>
    {item.name}
  </li>
{/each}
```

`crossfade` handles *enter/leave* (it pairs nodes across two lists), while `flip` handles *reordering* of survivors. The runtime's `fix()` guard (`getAnimations().length`) exists precisely so the two can run on the same element without their transforms fighting — for the layer-level comparison see [transitions_and_animations](transitions_and_animations.md) §5.1.

---

## 9. Design Characteristics & Caveats

- **Stateless by design.** All positional bookkeeping (First/Last rects, fix/unfix style stashing) belongs to the runtime manager. `flip` is a pure `(rects, params) → config` function — trivially testable and safe to call repeatedly.
- **Style sampling once, interpolation many times.** `getComputedStyle` runs in the factory body; `css(t, u)` only does arithmetic, keeping per-keyframe evaluation cheap.
- **Existing transforms are preserved.** The computed `transform` (if not `'none'`) is prepended, so `flip` composes with static CSS transforms of the element.
- **Transform-origin aware.** The delta is computed for the element's *origin*, not its top-left corner, so elements with non-default origins (e.g. `transform-origin: center`) animate around the correct pivot; the origin is normalized to `[0, 1]` so size changes are also handled.
- **Zoom & parent-transform aware.** `sx`/`sy` correct for effective CSS `zoom` (fast path: `currentCSSZoom`; fallback: ancestor walk) so flips are accurate inside scaled/zoomed containers.
- **Skipped when nothing moved.** The runtime only invokes `flip` if the new rect differs from the old one — no wasted `element.animate()` calls for no-op reorders.
- **Distance-adaptive default.** `duration = √distance · 120 ms` gives constant-speed motion out of the box; override with a number or your own function via `FlipParams.duration`.
- **Forward-only playback.** `animate()` is always called with target `t = 1`; unlike `transition:` there is no interruption/reversal logic in the config itself — a new reorder simply aborts the previous animation in `apply()`.
- **Client-only, tree-shakeable.** The module has no server counterpart and is never reached during SSR; the single `cubicOut` import and side-effect-free exports keep it fully tree-shakeable (see the design notes in [transitions_and_animations](transitions_and_animations.md)).
- **Type duplication, on purpose (for now).** `AnimationConfig` mirrors `TransitionConfig` (the source comments “todo: same as Transition, should it be shared?”). Treat them as independent contracts when writing custom animations vs. transitions.

---

## 10. References

| Topic | Document |
|---|---|
| Parent module: transitions & animations system (incl. crossfade vs. flip) | [transitions_and_animations](transitions_and_animations.md) |
| Built-in transitions (`fade`, `fly`, `crossfade`, …) and `TransitionConfig` | [transitions_and_animations_transitions](transitions_and_animations_transitions.md) |
| Easing library — default `cubicOut` and alternatives | [transitions_and_animations_easing](transitions_and_animations_easing.md) |
| Reactive motion alternatives (`tweened`, `spring`) | [motion_tweened](motion_tweened.md) · [motion_spring](motion_spring.md) |
| Runtime executor: `transition()` / `animation()` / WAAPI driver | [client_dom_renderer_elements_and_events](client_dom_renderer_elements_and_events.md) |
| Keyed each block reconciliation driving measure/fix/apply/unfix | [client_dom_renderer_control_flow_blocks](client_dom_renderer_control_flow_blocks.md) |
| rAF clock shared by all client animations | [client_runtime_core_runtime](client_runtime_core_runtime.md) |
| `AnimateDirective` AST node & compiler analysis/codegen | [compiler_types_template_ast](compiler_types_template_ast.md) · [compiler_client_transform_elements_and_directives](compiler_client_transform_elements_and_directives.md) |
| Public type surface (`FlipParams`, `AnimationConfig`) | [svelte-types](svelte-types.md) |
