# compiler_types_legacy_ast

## 1. Introduction

`compiler_types_legacy_ast` defines the **legacy (Svelte 4) AST node vocabulary** for the Svelte compiler. It lives in a single declaration file:

```
packages/svelte/src/compiler/types/legacy-nodes.d.ts
```

The module declares the `Legacy*` family of interfaces — `LegacyRoot`, `LegacyElement`, `LegacyInlineComponent`, `LegacyEventHandler`, `LegacyMustacheTag`, … — that describe the abstract syntax tree produced when *pre-Svelte-5* component syntax is parsed: `on:click` handlers, `bind:x` directives as standalone nodes, `<slot>` elements, `{#await}` with dedicated `PendingBlock`/`ThenBlock`/`CatchBlock` children, and so on.

Its responsibilities are:

1. **Compatibility contract** — fixing the node vocabulary that Svelte 4-era tooling (language servers, `svelte2tsx`, custom analyzers) was written against, so such tooling keeps compiling against modern `svelte` package types.
2. **Migration catalog** — enumerating exactly the constructs the Svelte 5 migration tooling (see [compiler_migrate](compiler_migrate.md)) recognizes and rewrites into modern syntax.
3. **Bridge definitions** — hosting the `RenderTag` and `SnippetBlock` shapes so consumers of the legacy union types can still represent Svelte 5 snippet constructs that appear in partially migrated or hybrid code.

Like its siblings in `compiler_types`, this module is a **leaf type module**: it contains no runtime code and no runtime dependencies. It only imports `estree` types and the `AST` namespace from the `#compiler` barrel ([compiler_types_compiler_api](compiler_types_compiler_api.md)).

> **Scope note:** The *modern* template AST is documented in [compiler_types_template_ast](compiler_types_template_ast.md) and the *modern* CSS AST in [compiler_types_css_ast](compiler_types_css_ast.md). The public compiler contracts (`CompileResult`, `CompileError`, …) live in [compiler_types_compiler_api](compiler_types_compiler_api.md). The parent module overview is [compiler_types](compiler_types.md).

---

## 2. Architectural Context

### 2.1 Position in the type layer

The module is one of four declaration files under `compiler/types`. It is unique among them in that it describes a **frozen AST dialect** rather than the live pipeline data — the modern compiler pipeline ([compiler_parser](compiler_parser.md) → [compiler_analyzer](compiler_analyzer.md) → [compiler_client_transform](compiler_client_transform.md)/[compiler_server_transform](compiler_server_transform.md)) produces and consumes the `AST` namespace from `template.d.ts`, *not* the `Legacy*` nodes.

```mermaid
flowchart TB
    subgraph types["compiler/types — type contract layer"]
        IDX["index.d.ts — #compiler barrel<br/>CompileResult · CompileError · OptimizeOptions"]
        TPL["template.d.ts — namespace AST<br/>(modern template AST)"]
        CSS["css.d.ts — namespace _CSS<br/>(modern CSS AST)"]
        LEG["legacy-nodes.d.ts<br/>★ this module<br/>(Svelte 4 AST vocabulary)"]
    end

    EST["estree types<br/>Expression · Identifier · Pattern ·<br/>MemberExpression · SequenceExpression ·<br/>AssignmentExpression · ArrayExpression · ObjectExpression"]

    LEG -- "AST.Text · AST.ExpressionTag" --> TPL
    LEG -- "AST.CSS.Combinator · AST.CSS.SimpleSelector" --> CSS
    TPL -. "re-exported through barrel" .-> IDX
    CSS -. "re-exported through barrel" .-> IDX
    LEG --> EST

    LEG -- "type contract for Svelte 4 tooling" --> TOOL["Legacy ecosystem<br/>(language tools / svelte2tsx)"]
    LEG -- "catalog of constructs to rewrite" --> MIG["compiler_migrate<br/>(svelte.migrate)"]
    MIG -- "produces modern syntax" --> MOD["AST.* tree (template.d.ts)<br/>→ normal compile pipeline"]
    LEG -. "RenderTag · SnippetBlock shapes" .-> PUB["public type surface<br/>(svelte-types)"]

    style LEG fill:#fff4e6,stroke:#e6a23c
```

Key relationships:

| Relationship | Counterpart module | Nature |
|---|---|---|
| Borrows leaf types from | [compiler_types_template_ast](compiler_types_template_ast.md) | `AST.Text` (text nodes inside attributes / the umbrella union) and `AST.ExpressionTag` (values in `LegacyStyleDirective`) |
| Borrows selector types from | [compiler_types_css_ast](compiler_types_css_ast.md) | `AST.CSS.Combinator` and `AST.CSS.SimpleSelector` compose `LegacySelector.children` |
| Re-exported via | [compiler_types_compiler_api](compiler_types_compiler_api.md) | The `#compiler` import in this file resolves through the `index.d.ts` barrel |
| Consumed by | [compiler_migrate](compiler_migrate.md) | Migration rewrites exactly the constructs these types describe; the rewriting mechanics (MagicString edits, rune insertion) live there |
| Mirrored on the public surface | [svelte-types](svelte-types.md) | `RenderTag`/`SnippetBlock` and the selector vocabulary reappear in `packages/svelte/types/index.d.ts` |
| Contrast module | [compiler_types_template_ast](compiler_types_template_ast.md) | The modern AST is a *superset redesign* — see the mapping table in §5 |

### 2.2 Why a frozen dialect exists

The Svelte 5 redesign changed nearly every node name and structural convention (fragment-based children, merged directive types, `ExpressionTag`, `@internal metadata`). Re-pointing four years of ecosystem tooling at that new vocabulary was impossible, so the legacy shapes are preserved *verbatim* as a stable contract. The module therefore deliberately:

- **never changes** its exported shapes (additive-only at most),
- **omits** the modern `metadata` protocol (legacy nodes are pure syntax),
- **loosens** types to `any` where Svelte 4 itself was loose (`LegacyRoot.css/instance/module`, `LegacyStyle.attributes/children`), matching what consumers actually relied upon.

---

## 3. Design Conventions & Foundation Types

### 3.1 Conventions

| Convention | Realization | Notes / contrast with modern AST |
|---|---|---|
| **Discriminated unions** | Every concrete node has a string-literal `type` (`'Element'`, `'EventHandler'`, `'Selector'`, …) | Same pattern as the `AST` namespace, but no curated `switch`-target unions per family beyond the four exported aliases (§4.6) |
| **Mandatory source positions** | `BaseNode` requires `start`/`end` | Modern `AST.BaseNode` declares them *optional* ("added by the parser"); the legacy contract hard-guarantees them |
| **No `metadata` protocol** | Nodes are pure syntax | Modern nodes carry `/** @internal */ metadata` filled by [compiler_analyzer](compiler_analyzer.md); legacy nodes are immutable input descriptions |
| **`children` arrays, not `Fragment`s** | `BaseElement.children: LegacyElementLike[]` | Modern `BaseElement` holds a single `fragment: AST.Fragment`; the legacy model has no `Fragment` node — element bodies are flat child lists |
| **Interfaces, not classes** | Plain data, serializable | Enables diffing, pretty-printing, and hash-based cache keys in downstream tooling |

### 3.2 Foundation types (not exported)

```ts
interface BaseNode {
    type: string;   // discriminant for unions
    start: number;  // byte offset of first character
    end: number;    // byte offset after last character
}

interface BaseElement extends BaseNode {
    name: string;                          // tag / construct name
    attributes: Array<LegacyAttributeLike>; // attributes, spreads, directives
    children: Array<LegacyElementLike>;     // element children (no Fragment node)
}
```

These two interfaces are intentionally **module-private**: consumers are expected to narrow via the exported concrete types and unions. Every exported node except `LegacyElement`, `LegacyOptions`, and the two bridge nodes extends one of them (see the hierarchy diagram in §4.2).

---

## 4. Component Breakdown

### 4.1 The root node

#### `LegacyRoot`

The top of a parsed Svelte 4 component:

| Field | Type | Meaning |
|---|---|---|
| `html` | `LegacySvelteNode` | The markup tree. Note the *singular* typing — legacy consumers treat the root loosely, unlike the modern `Root.fragment: AST.Fragment` |
| `css?` | `any` | `<style>` content — deliberately loose (preprocessors may have rewritten it) |
| `instance?` | `any` | `<script>` content |
| `module?` | `any` | `<script context="module">` content |

Compare with the modern `AST.Root`, which types these as `AST.CSS.StyleSheet | null`, `Script | null`, `Script | null` and adds `options` and `comments` (see [compiler_types_template_ast](compiler_types_template_ast.md) §Component Breakdown).

### 4.2 Node hierarchy

```mermaid
classDiagram
    class BaseNode {
        <<not exported>>
        +string type
        +number start
        +number end
    }
    class BaseElement {
        <<not exported>>
        +string name
        +LegacyAttributeLike[] attributes
        +LegacyElementLike[] children
    }

    class LegacyRoot {
        +LegacySvelteNode html
        +any css?
        +any instance?
        +any module?
    }
    class LegacyElement {
        +type = 'Element'  ⚠ discriminant only
    }
    class LegacyOptions {
        +name = 'svelte:options'
        +any[] attributes
    }

    class LegacyBody {
        +name = 'svelte:body'
    }
    class LegacyDocument
    class LegacyHead
    class LegacyInlineComponent {
        +Expression? expression
    }
    class LegacySlot
    class LegacySlotTemplate
    class LegacyTitle {
        +name = 'title'
    }
    class LegacyWindow

    class LegacyPendingBlock {
        +LegacySvelteNode[] children
        +boolean skip
    }
    class LegacyThenBlock {
        +skip
    }
    class LegacyCatchBlock {
        +skip
    }

    class LegacyMustacheTag {
        <<not exported>>
        +Expression expression
    }
    class LegacyRawMustacheTag {
        +Expression expression
    }
    class LegacyComment {
        +string data
        +string[] ignores
    }
    class LegacyConstTag {
        +AssignmentExpression expression
    }
    class SnippetBlock {
        +Identifier expression
        +null|Pattern context
        +LegacySvelteNode[] children
    }
    class RenderTag {
        +Identifier expression
        +null|Expression argument
    }

    class LegacyAttribute {
        +name
        +value: true | Array~Text|MustacheTag|AttributeShorthand~
    }
    class LegacyAttributeShorthand
    class LegacySpread {
        +Expression expression
    }
    class LegacyAction {
        +name +expression?
    }
    class LegacyAnimation {
        +name +expression?
    }
    class LegacyBinding {
        +name
        +Identifier|MemberExpression|SequenceExpression expression
    }
    class LegacyClass {
        +name = 'class'
        +Expression expression
    }
    class LegacyEventHandler {
        +name +expression?
        +string[] modifiers
    }
    class LegacyLet {
        +name
        +null|Identifier|ArrayExpression|ObjectExpression expression
    }
    class LegacyStyleDirective {
        +name
        +value: true | Array~ExpressionTag|Text~
        +'important'[] modifiers
    }
    class LegacyTransition {
        +name +expression?
        +('local'|'global')[] modifiers
        +boolean intro
        +boolean outro
    }

    class LegacyStyle {
        +any[] attributes
        +content{start, end, styles}
        +any[] children
    }
    class LegacySelector {
        +Array~CSS.Combinator|CSS.SimpleSelector~ children
    }

    BaseNode <|-- BaseElement
    BaseElement <|-- LegacyBody
    BaseElement <|-- LegacyDocument
    BaseElement <|-- LegacyHead
    BaseElement <|-- LegacyInlineComponent
    BaseElement <|-- LegacySlot
    BaseElement <|-- LegacySlotTemplate
    BaseElement <|-- LegacyTitle
    BaseElement <|-- LegacyWindow

    BaseNode <|-- LegacyRoot
    BaseNode <|-- LegacyPendingBlock
    BaseNode <|-- LegacyThenBlock
    BaseNode <|-- LegacyCatchBlock
    BaseNode <|-- LegacyMustacheTag
    BaseNode <|-- LegacyRawMustacheTag
    BaseNode <|-- LegacyComment
    BaseNode <|-- LegacyConstTag
    BaseNode <|-- SnippetBlock
    BaseNode <|-- RenderTag
    BaseNode <|-- LegacyAttribute
    BaseNode <|-- LegacyAttributeShorthand
    BaseNode <|-- LegacySpread
    BaseNode <|-- LegacyAction
    BaseNode <|-- LegacyAnimation
    BaseNode <|-- LegacyBinding
    BaseNode <|-- LegacyClass
    BaseNode <|-- LegacyEventHandler
    BaseNode <|-- LegacyLet
    BaseNode <|-- LegacyStyleDirective
    BaseNode <|-- LegacyTransition
    BaseNode <|-- LegacyStyle
    BaseNode <|-- LegacySelector

    LegacyElement ..> BaseNode : "⚠ does NOT extend"
    LegacyOptions ..> BaseNode : "⚠ does NOT extend"
```

### 4.3 Element-like nodes (`extends BaseElement`)

These carry the `name` / `attributes` / `children` triple and form the markup skeleton:

| Node | Source syntax | Notable fields |
|---|---|---|
| `LegacyBody` | `<svelte:body>` | Fixed `name: 'svelte:body'` |
| `LegacyDocument` | `<svelte:document>` | — |
| `LegacyHead` | `<svelte:head>` | — |
| `LegacyInlineComponent` | `<Foo …>`, `<svelte:component this={X}>` | Optional `expression: Expression` — set *only* for `<svelte:component>`; a plain `<Foo>` is distinguished by capitalization of `name` |
| `LegacySlot` | `<slot name="x">…</slot>` | Slot *render site* (vs `LegacySlotTemplate`, the content provider) |
| `LegacySlotTemplate` | `<template slot="x">`, `<svelte:fragment slot="x">` | Slot *filling* content |
| `LegacyTitle` | `<title>` | Fixed `name: 'title'` |
| `LegacyWindow` | `<svelte:window>` | — |

### 4.4 Standalone element shapes

| Node | Quirk |
|---|---|
| `LegacyElement` | Extends **nothing** — declared as a bare `{ type: 'Element' }` discriminant. Consumers that need element internals special-case the `BaseElement`-derived nodes above and treat generic elements via the loose unions. |
| `LegacyOptions` | Also non-`BaseNode`: `{ type: 'Options', name: 'svelte:options', attributes: any[] }`. The modern compiler instead attaches resolved options to `Root.options` (with `AST.SvelteOptionsRaw` as the parse-time intermediate — see [compiler_types_template_ast](compiler_types_template_ast.md)). |

### 4.5 Control-flow, tags, and the snippet bridge

**Await sub-blocks** (`{#await expr}` syntax) share the shape `children: LegacySvelteNode[]` + `skip: boolean` (true when the block was written empty and the compiler should skip emitting it):

- `LegacyPendingBlock` (`'PendingBlock'`), `LegacyThenBlock` (`'ThenBlock'`), `LegacyCatchBlock` (`'CatchBlock'`). The modern AST folds all three into `AST.AwaitBlock`'s `pending` / `then` / `catch` `Fragment` fields.

**Tags and content:**

| Node | Syntax | Fields |
|---|---|---|
| `LegacyMustacheTag` *(not exported)* | `{expr}` | `expression: Expression` — the classic interpolation; modern equivalent is `AST.ExpressionTag` |
| `LegacyRawMustacheTag` | `{@html expr}` | `expression: Expression` → modern `AST.HtmlTag` |
| `LegacyComment` | `<!-- … -->` | `data: string` plus `ignores: string[]` — the parsed `<!-- svelte-ignore a b c -->` directives, one entry per code |
| `LegacyConstTag` | `{@const x = y}` | `expression: AssignmentExpression` (single assignment) → modern `AST.ConstTag` (normalized `VariableDeclaration`) |

**Bridge nodes** (modern Svelte 5 constructs declared in this file for legacy consumers):

| Node | Fields | Purpose here |
|---|---|---|
| `SnippetBlock` | `expression: Identifier`, `context: null \| Pattern`, `children` | The `{#snippet}` block as it existed in early Svelte 5 (`context` was the original name of the modern `parameters: Pattern[]`). Lets legacy-typed walkers represent snippet definitions. |
| `RenderTag` | `expression: Identifier`, `argument: null \| Expression` | The `{@render foo(args)}` invocation, the designated replacement for `<slot>` forwarding during migration. |

> ⚠ Neither bridge node is part of the `LegacySvelteNode` umbrella union — they are exported separately so consumers opt in to handling Svelte 5 constructs.

### 4.6 Attributes & directives (`extends BaseNode`, appear in `BaseElement.attributes`)

| Node | Syntax | Fields of interest |
|---|---|---|
| `LegacyAttribute` | `name="value"` / `name={expr}` | `value: true \| Array<AST.Text \| LegacyMustacheTag \| LegacyAttributeShorthand>` — `true` marks a valueless (boolean) attribute; array values model *mixed* static/dynamic text. `AttributeShorthand` is the `name`-sugar for `{name}`. |
| `LegacySpread` | `{...expr}` | `expression: Expression` → modern `AST.SpreadAttribute` |
| `LegacyAction` | `use:x={y}` | `name`, `expression: null \| Expression` → modern `AST.UseDirective` |
| `LegacyAnimation` | `animate:x={y}` | → modern `AST.AnimateDirective` |
| `LegacyBinding` | `bind:x={y}` | `expression: Identifier \| MemberExpression \| SequenceExpression` → modern `AST.BindDirective` (identical union) |
| `LegacyClass` | `class:x={y}` | `name: 'class'` fixed; → modern `AST.ClassDirective` |
| `LegacyEventHandler` | `on:x={y}` | `modifiers: string[]` (`preventDefault`, `capture`, …) → modern `AST.OnDirective` / event attributes |
| `LegacyLet` | `let:x={y}` | `expression: null \| Identifier \| ArrayExpression \| ObjectExpression` (shorthand or destructure pattern) → modern `AST.LetDirective` |
| `LegacyStyleDirective` | `style:x={y}` | `value: true \| Array<AST.ExpressionTag \| AST.Text>`, `modifiers: Array<'important'>` → modern `AST.StyleDirective` |
| `LegacyTransition` | `transition:|in:|out:` | `modifiers: Array<'local' \| 'global'>` plus `intro`/`outro` booleans disambiguating which of the three spellings was used → modern `AST.TransitionDirective` |

Note how the *values* of `LegacyStyleDirective` already use the modern `AST.ExpressionTag` while `LegacyAttribute` uses the legacy `LegacyMustacheTag` — the file straddles both vocabularies exactly where the Svelte 5 redesign moved the boundary between "attribute chunk" and "expression tag".

### 4.7 CSS nodes (legacy dialect)

| Node | Fields | Contrast with modern CSS AST |
|---|---|---|
| `LegacyStyle` | `attributes: any[]` (e.g. `lang="scss"`), `content: { start, end, styles }` (raw text span), `children: any[]` | The modern pipeline parses `<style>` into a full `_CSS.StyleSheet` tree (see [compiler_types_css_ast](compiler_types_css_ast.md)); the legacy model keeps the raw string so preprocessor-based consumers are unaffected |
| `LegacySelector` | `children: Array<AST.CSS.Combinator \| AST.CSS.SimpleSelector>` | A *flat* selector spine, versus the modern `_CSS.SelectorList → ComplexSelector → RelativeSelector → SimpleSelector` hierarchy |

`LegacySelector`'s reuse of modern `AST.CSS` leaf types is the module's dependency on [compiler_types_css_ast](compiler_types_css_ast.md).

### 4.8 Union type layer

The exported aliases are the practical traversal API — legacy consumers walk a `LegacySvelteNode` and narrow on `type`:

```mermaid
flowchart TD
    LSN["LegacySvelteNode<br/>(umbrella union — everything a<br/>legacy walker may encounter)"]

    LSN --> CT["LegacyConstTag"]
    LSN --> TXT["AST.Text<br/>(borrowed from template AST)"]
    LSN --> SH["LegacyAttributeShorthand"]
    LSN --> AL["LegacyAttributeLike"]
    LSN --> EL["LegacyElementLike"]
    LSN --> CSSN["LegacyCssNode"]

    AL --> ATTR["LegacyAttribute"]
    AL --> SPR["LegacySpread"]
    AL --> DIR["LegacyDirective"]
    DIR --> ACT["LegacyAction"] & ANI["LegacyAnimation"] & BND["LegacyBinding"]
    DIR --> CLS["LegacyClass"] & LET["LegacyLet"] & EVH["LegacyEventHandler"]
    DIR --> STY["LegacyStyleDirective"] & TRA["LegacyTransition"]

    EL --> ELEM["Body · Document · Element · Head ·<br/>InlineComponent · Options · Slot ·<br/>SlotTemplate · Title · Window"]
    EL --> BLK["PendingBlock · ThenBlock · CatchBlock"]
    EL --> TAGS["Comment · MustacheTag · RawMustacheTag"]

    CSSN --> ST["LegacyStyle"]
    CSSN --> SEL["LegacySelector"]

    NOT["⚠ NOT in LegacySvelteNode:<br/>LegacyRoot · SnippetBlock · RenderTag<br/>(exported separately)"]
```

---

## 5. Legacy → Modern AST Mapping

This table is the module's most load-bearing documentation for migration work: it fixes the correspondence between the frozen vocabulary and the live `AST` namespace. The rewriting logic itself lives in [compiler_migrate](compiler_migrate.md); this module supplies the "before" side of every rule.

| Legacy node | Svelte 5 counterpart (`AST.*`) | Migration flavor |
|---|---|---|
| `LegacyRoot` | `Root` | `css`/`instance`/`module` become typed `StyleSheet`/`Script` fields; `html` → `fragment` |
| `LegacyElement` | `RegularElement` | One-to-one rename; `children` list → `fragment` |
| `LegacyInlineComponent` | `Component` / `SvelteComponent` | `<Foo>` → `<Foo>`; `<svelte:component>` → dynamic component (may become `$derived` bindings) |
| `LegacyBody` / `LegacyDocument` / `LegacyHead` / `LegacyWindow` | `SvelteBody` / `SvelteDocument` / `SvelteHead` / `SvelteWindow` | One-to-one renames |
| `LegacyTitle` | `TitleElement` | Rename |
| `LegacyOptions` | `SvelteOptions` on `Root` (parse-time `SvelteOptionsRaw`) | Structured instead of attribute list |
| `LegacyMustacheTag` | `ExpressionTag` | Rename |
| `LegacyRawMustacheTag` | `HtmlTag` | Rename |
| `LegacyAttribute` (+`LegacyAttributeShorthand`) | `Attribute` | Shorthand folded into value array; `MustacheTag` chunks → `ExpressionTag` chunks |
| `LegacySpread` | `SpreadAttribute` | Rename |
| `LegacyEventHandler` | `OnDirective` / DOM event attributes | `on:click={fn}` → `onclick={fn}`; modifiers (`|preventDefault`, …) → wrapper calls |
| `LegacyBinding` | `BindDirective` | Rename |
| `LegacyClass` / `LegacyStyleDirective` | `ClassDirective` / `StyleDirective` | Rename |
| `LegacyTransition` | `TransitionDirective` | `intro`/`outro` flags preserved |
| `LegacyAction` | `UseDirective` | Rename |
| `LegacyAnimation` | `AnimateDirective` | Rename |
| `LegacyLet` | `LetDirective` | `let:x` slot props → snippet parameters |
| `LegacySlot` | `SlotElement` + `RenderTag` | `<slot>` → `{@render children?.()}` forwarding via snippets |
| `LegacySlotTemplate` | `SvelteFragment` / snippet block | Content provider becomes `{#snippet}` |
| `LegacyPendingBlock` / `LegacyThenBlock` / `LegacyCatchBlock` | `AwaitBlock.pending` / `.then` / `.catch` (`Fragment`) | Three child nodes → three fields |
| `LegacyConstTag` | `ConstTag` | `AssignmentExpression` → normalized `VariableDeclaration` |
| `LegacyComment` | `Comment` | `ignores` handling preserved |
| `LegacyStyle` / `LegacySelector` | `AST.CSS.StyleSheet` / selector hierarchy (see [compiler_types_css_ast](compiler_types_css_ast.md)) | Raw-text `styles` span → fully parsed CSS tree |
| `SnippetBlock` / `RenderTag` *(bridge)* | `AST.SnippetBlock` / `AST.RenderTag` | Already modern; `context` → `parameters` |

---

## 6. Usage & Consumption Patterns

### 6.1 Who consumes this vocabulary

```mermaid
flowchart LR
    S4["Svelte 4 component source<br/>(on:click, slots, {#await}…<br/>Legacy* nodes)"]

    subgraph consumers["Consumers of legacy-nodes.d.ts"]
        TOOL["Legacy ecosystem tooling<br/>(language tools, svelte2tsx)<br/>walks LegacySvelteNode"]
        MIG["compiler_migrate<br/>recognizes Legacy* constructs,<br/>rewrites to Svelte 5 syntax"]
    end

    S4 --> TOOL
    S4 --> MIG
    MIG --> OUT["Modern component<br/>(AST.* tree — see<br/>compiler_types_template_ast)"]
    OUT --> PIPE["Standard pipeline:<br/>analyze → transform<br/>(compiler_analyzer →<br/>client/server transform)"]
```

1. **Legacy ecosystem tooling** narrows `LegacySvelteNode` by `type` and relies on the mandatory `start`/`end` offsets for source-mapped edits and diagnostics.
2. **Migration tooling** uses the vocabulary as its recognition catalog. The migration flow (`migrate` in [compiler_migrate](compiler_migrate.md)) parses a component, walks its parts, and applies the §5 mapping — inserting runes (`$props()`, `$bindable()`, `$derived`), rewriting events to property handlers, converting slots to snippets, and importing `svelte/legacy` helpers where behavioral parity is impossible. Unmigratable constructs are annotated with `@migration-task` comments rather than silently dropped.
3. **The public type surface** ([svelte-types](svelte-types.md)) re-exposes the shared selector vocabulary and the `RenderTag`/`SnippetBlock` shapes, keeping this file's declarations aligned with what tooling imports from `svelte/compiler` / `svelte/types`.

### 6.2 Interaction with the modern pipeline

The legacy nodes **never enter** the live compile pipeline — there is no phase that mutates a `LegacyRoot`. Instead the module participates in two indirect flows:

- **Parse-adjacent:** diagnostics such as `block_unclosed` ([compiler_diagnostics_errors](compiler_diagnostics_errors.md)) fire while reading legacy-style markup syntax (e.g. unclosed `{#if}`); their `start`/`end` reporting convention matches `BaseNode`'s mandatory offsets.
- **Migrate → modern hand-off:** once `compiler_migrate` has rewritten a component, the *modern* parser ([compiler_parser](compiler_parser.md)) produces an `AST.Root` and the component re-enters the standard analyze/transform flow described in [compiler_types](compiler_types.md) §Architecture Overview.

---

## 7. Notable Design Details & Gotchas

1. **`LegacyElement` and `LegacyOptions` extend nothing.** They are bare discriminants; any code assuming `BaseNode` members on every `LegacyElementLike` member must guard for these two.
2. **`LegacyMustacheTag` is not exported** yet appears in the exported `LegacyAttribute.value` union and `LegacyElementLike`. Consumers name it structurally or import nothing — a deliberate signal that it is subsumed by `AST.ExpressionTag` going forward.
3. **`BaseNode`/`BaseElement` are module-private.** Only concrete node interfaces and the four unions (`LegacyDirective`, `LegacyAttributeLike`, `LegacyElementLike`, `LegacyCssNode`) plus the umbrella `LegacySvelteNode` are exported.
4. **Positions are mandatory** (`start`/`end: number`), unlike the modern `AST.BaseNode` where they are optional and described as parser-added.
5. **Loose `any` fields are intentional:** `LegacyRoot.css/instance/module`, `LegacyOptions.attributes`, `LegacyStyle.attributes/children`. They encode the Svelte 4 reality that scripts/styles were preprocessor territory; tightening them would break downstream consumers.
6. **No `metadata` protocol.** Legacy nodes describe syntax only; any "what the compiler knows" enrichment (scopes, reactivity, CSS scoping flags) belongs to the modern AST — see the `@internal metadata` pattern in [compiler_types_template_ast](compiler_types_template_ast.md).
7. **Flat children vs. fragments.** `BaseElement.children` is a heterogeneous node array; there is no `Fragment` wrapper. Migration therefore *restructures* (wraps children into fragments), not just renames.
8. **The bridge nodes are excluded from `LegacySvelteNode`** — `SnippetBlock` and `RenderTag` are opt-in so walkers of pure Svelte 4 trees don't need to handle Svelte 5 constructs.
9. **`LegacySelector` is flat** (`Combinator | SimpleSelector` children) versus the modern nested `SelectorList → ComplexSelector → RelativeSelector` model in [compiler_types_css_ast](compiler_types_css_ast.md).

---

## 8. Dependencies & Related Modules

**Depends on (types only):**

- `#compiler` → `AST` namespace ([compiler_types_compiler_api](compiler_types_compiler_api.md) barrel), using:
  - `AST.Text`, `AST.ExpressionTag` — from [compiler_types_template_ast](compiler_types_template_ast.md)
  - `AST.CSS.Combinator`, `AST.CSS.SimpleSelector` — from [compiler_types_css_ast](compiler_types_css_ast.md)
- `estree` — `Expression`, `Identifier`, `MemberExpression`, `SequenceExpression`, `AssignmentExpression`, `ArrayExpression`, `ObjectExpression`, `Pattern`

**Consumed by / related to:**

| Module | Relationship |
|---|---|
| [compiler_migrate](compiler_migrate.md) | Consumes the vocabulary as the catalog of Svelte 4 constructs to rewrite |
| [compiler_types_template_ast](compiler_types_template_ast.md) | Modern counterpart; supplies borrowed leaf types; target of the §5 mapping |
| [compiler_types_css_ast](compiler_types_css_ast.md) | Supplies CSS selector leaf types; modern counterpart of `LegacyStyle`/`LegacySelector` |
| [compiler_types_compiler_api](compiler_types_compiler_api.md) | Barrel (`#compiler`) through which `AST` is imported; `CompileResult.ast` is where an AST — legacy or modern — is surfaced to consumers |
| [compiler_parser](compiler_parser.md) / [compiler_analyzer](compiler_analyzer.md) | Operate on the *modern* AST; listed to clarify what this module does **not** feed |
| [compiler_diagnostics](compiler_diagnostics.md) | Shares the `start`/`end` code-frame convention that legacy `BaseNode` mandates |
| [svelte-types](svelte-types.md) | Public surface mirroring `RenderTag`/`SnippetBlock` and selector vocabulary |
| Parent: [compiler_types](compiler_types.md) | Module overview, conventions, and the four-file composition |

---

*This module is frozen by design: it exists so the Svelte 4 world keeps compiling against Svelte 5 packages. Changes here should be limited to additive declarations; behavioral evolution belongs to [compiler_types_template_ast](compiler_types_template_ast.md) and [compiler_migrate](compiler_migrate.md).*
