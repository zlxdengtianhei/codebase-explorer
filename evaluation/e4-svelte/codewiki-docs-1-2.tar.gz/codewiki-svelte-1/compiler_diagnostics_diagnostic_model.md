# Compiler Diagnostics — Diagnostic Model (`compiler_diagnostics_diagnostic_model`)

## 1. Introduction

The **diagnostic model** module defines the single, shared data structure that every error and warning produced by the Svelte compiler is built upon: the `CompileDiagnostic` class (in `packages/svelte/src/compiler/utils/compile_diagnostic.js`).

Every compile-time problem — whether a fatal `CompileError` thrown from the analyze phase or a non-fatal `CompileWarning` collected during compilation — is materialized through this class. It guarantees that all diagnostics share:

- a stable **object shape** (`code`, `message`, `filename`, `start`/`end` locations, `position`, `frame`),
- consistent **human-readable rendering** (`toString()`) including a source excerpt with a caret marker,
- consistent **machine-readable serialization** (`toJSON()`) for tooling and IDEs.

| Fact | Value |
|---|---|
| Module id | `compiler_diagnostics_diagnostic_model` |
| Parent module | [`compiler_diagnostics`](compiler_diagnostics.md) |
| Source file | `packages/svelte/src/compiler/utils/compile_diagnostic.js` |
| Exported API | `CompileDiagnostic` (class) |
| Internal helpers | `get_code_frame`, `tabs_to_spaces` |
| Public contract | `ICompileDiagnostic` typedef (implemented by the class) |

---

## 2. Purpose and Responsibilities

The module sits at the *representation layer* of the compiler's diagnostics framework:

1. **Uniform diagnostic shape** — both errors and warnings share the exact same fields, so downstream tooling handles them identically.
2. **Position resolution** — converts raw `[start, end]` character offsets into `line`/`column` `Location` objects using the locator configured by the parse phase (see [`compiler_core_state`](compiler_core_state.md)).
3. **Code frame rendering** — renders the offending source line (plus surrounding context) with a right-aligned line-number gutter and a `^` caret pointing at the diagnostic end column.
4. **Dual output modes** — `toString()` for terminal/CLI output, `toJSON()` for structured consumption (editors, Vite plugins, error overlays).

It deliberately contains **no** diagnostic catalog logic (message texts, codes, throw/collect behavior) — that lives in the sibling modules [`compiler_diagnostics_errors`](compiler_diagnostics_errors.md) and [`compiler_diagnostics_warnings`](compiler_diagnostics_warnings.md).

---

## 3. Core Components

### 3.1 `CompileDiagnostic` class (exported)

```javascript
/** @implements {ICompileDiagnostic} */
export class CompileDiagnostic {
    name = 'CompileDiagnostic';
    constructor(code, message, position) { /* … */ }
    toString() { /* … */ }
    toJSON() { /* … */ }
}
```

**Fields**

| Field | Type | Filled when |
|---|---|---|
| `name` | `'CompileDiagnostic'` | Always (overridden by subclasses/consumers, e.g. `'CompileError'`, `'CompileWarning'`) |
| `code` | `string` | Always — stable machine identifier, e.g. `css_unused_selector` |
| `message` | `string` | Always — human-readable text incl. doc URL |
| `filename` | `string?` | Only if `state.filename !== state.UNKNOWN_FILENAME` |
| `position` | `[number, number]?` | Only if the caller supplied a position tuple (character offsets) |
| `start`, `end` | `Location?` | Resolved via `state.locator(position[0])` / `state.locator(position[1])` |
| `frame` | `string?` | Rendered **only if both** `start` and `end` resolve |

**Constructor logic**

1. Stores `code` and `message`.
2. Copies `filename` from the ambient compilation state, unless it is the sentinel `<unknown>` value.
3. If a `position` tuple exists, resolves both offsets into `start`/`end` `Location` objects (`{ line, column, character }` from the `locate-character` package).
4. If both locations resolved, eagerly renders the code frame via the private helper:

```javascript
this.frame = get_code_frame(state.source, this.start.line - 1, this.end.column);
```

Note the asymmetry: the frame is anchored at the diagnostic's **start line** (converted from `locate-character`'s 1-based lines to the helper's 0-based index), while the **caret column** is taken from the diagnostic's **end column**.

**`toString()` output format**

```
{code}: {message}
{filename}:{start.line}:{start.column}
{frame}
```

Each segment is appended only when available, so partial diagnostics (no position) degrade gracefully to `code: message`.

**`toJSON()` output** — a plain object with `code`, `message`, `filename`, `start`, `end`, `position`, `frame`; suitable for structured logging, JSON error manifests, and editor integrations.

### 3.2 `get_code_frame(source, line, column)` (module-private)

Renders the source excerpt shown beneath a diagnostic. Given a 0-based `line` and a `column`:

1. **Windowing** — selects `lines[line - 2 … line + 3]`: up to 2 lines of context before and after the error line.
2. **Gutter sizing** — `digits = String(frame_end + 1).length`; line numbers are right-padded to this width so the gutter never shifts.
3. **Per-line rendering** — each line is emitted as `N: <text>` where `N` is the 1-based line number.
4. **Caret line** — for the error line, an extra line is appended with `' '.repeat(digits + 2 + expanded_prefix_length) + '^'`, so the caret aligns exactly under `column`.
5. **Tab normalization** — tabs are expanded to two spaces (see `tabs_to_spaces`) in both the displayed text *and* in the prefix used to compute the caret offset, keeping alignment consistent regardless of tab width settings.

The result is joined with newlines into a single `frame` string.

### 3.3 `tabs_to_spaces(str)` (module-private)

Replaces leading tab runs (`/^\t+/` per line via the shared `regex_tabs`) with double spaces. Used exclusively for consistent frame/caret alignment.

### 3.4 `ICompileDiagnostic` typedef (public contract)

The documented shape of any compile diagnostic:

```javascript
/**
 * @typedef {{
 *  code: string;
 *  message: string;
 *  stack?: string;
 *  filename?: string;
 *  start?: Location;      // locate-character Location { line, column, character }
 *  end?: Location;
 *  position?: [number, number];
 *  frame?: string;
 * }} ICompileDiagnostic
 */
```

This is the type that the public `CompileError` interface extends (see [`compiler_types`](compiler_types.md)):

```typescript
interface CompileError extends ICompileDiagnostic {}
```

---

## 4. Architecture

### 4.1 Type/class relationships

```mermaid
classDiagram
    direction TB

    class ICompileDiagnostic {
        <<interface / typedef>>
        +string code
        +string message
        +string? stack
        +string? filename
        +Location? start
        +Location? end
        +Array? position
        +string? frame
    }

    class CompileDiagnostic {
        +name = 'CompileDiagnostic'
        +constructor(code, message, position)
        +toString() string
        +toJSON() object
    }

    class InternalCompileWarning {
        +name = 'CompileWarning'
    }

    class InternalCompileError {
        +name = 'CompileError'
        -#diagnostic
        +toString() string
        +toJSON() object
    }

    class Error {
        <<JS builtin>>
    }

    class CompileError {
        <<public interface>>
    }

    ICompileDiagnostic <|.. CompileDiagnostic : implements
    CompileDiagnostic <|-- InternalCompileWarning : extends
    Error <|-- InternalCompileError : extends
    CompileDiagnostic ..> InternalCompileError : "composed, props copied via Object.assign"
    InternalCompileError ..> InternalCompileWarning : "same public shape"
    ICompileDiagnostic <|-- CompileError : public contract extends
```

Key design decisions visible here:

- `InternalCompileError` (`packages/svelte/src/compiler/errors.js`) **extends `Error`** so bundler plugins and dev tooling recognize it as an error, but it **delegates its shape and rendering to a composed `CompileDiagnostic`** instance (`Object.assign(this, this.#diagnostic)`). This keeps error and warning objects structurally identical.
- `InternalCompileWarning` (`packages/svelte/src/compiler/warnings.js`) simply **extends `CompileDiagnostic`** and relabels `name` to `'CompileWarning'`.

### 4.2 Module dependency graph

```mermaid
flowchart TD
    subgraph DM["compiler_diagnostics_diagnostic_model (this module)"]
        CD["CompileDiagnostic"]
        GCF["get_code_frame"]
        T2S["tabs_to_spaces"]
        CD --> GCF --> T2S
    end

    subgraph CS["compiler_core_state — state.js"]
        ST["ambient state:<br/>state.source · state.filename<br/>state.locator · state.UNKNOWN_FILENAME"]
    end

    LC["locate-character (external)<br/>Location type"]

    CD -- "reads source / filename / locator" --> ST
    CD -- "import type Location" --> LC

    subgraph SIB["sibling diagnostics modules"]
        ERR["compiler_diagnostics_errors<br/>e() → InternalCompileError"]
        WARN["compiler_diagnostics_warnings<br/>w() → InternalCompileWarning"]
    end

    ERR -- "composes" --> CD
    WARN -- "extends" --> CD
```

The dependency on `state.js` is an *ambient/global* dependency: `CompileDiagnostic` reads the currently active compilation context (`source`, `filename`, `locator`) that the parse phase installed (see [`compiler_core_state`](compiler_core_state.md)). Diagnostics are therefore only fully positioned when constructed **during an active compile**.

---

## 5. Integration with the Diagnostics Framework

The diagnostic model is the shared foundation of the `compiler_diagnostics` family:

```mermaid
flowchart LR
    subgraph PH["Front-end & back-end phases"]
        A["1-parse<br/>(parser)"]
        B["2-analyze<br/>(visitors, CSS analysis)"]
        C["3-transform<br/>(client/server visitors)"]
    end

    subgraph FAM["compiler_diagnostics"]
        ERR["errors.js<br/>error catalog + e()"]
        WARN["warnings.js<br/>warning catalog + w()"]
        DM["compile_diagnostic.js<br/>CompileDiagnostic + code frames"]
    end

    OUT["compiler output:<br/>thrown CompileError,<br/>warnings array, CompileResult"]

    A & B & C -- "detect issue → e(node, code, msg) / w(node, code, msg)" --> ERR & WARN
    ERR --> DM
    WARN --> DM
    ERR -- "throw" --> OUT
    WARN -- "collect (ignore/filter aware)" --> OUT
```

### 5.1 Error path — composition via `errors.js`

The `e()` helper in [`compiler_diagnostics_errors`](compiler_diagnostics_errors.md):

```javascript
function e(node, code, message) {
    const start = typeof node === 'number' ? node : node?.start;
    const end   = typeof node === 'number' ? node : node?.end;
    throw new InternalCompileError(code, message,
        start !== undefined ? [start, end ?? start] : undefined);
}
```

`InternalCompileError` then builds a `CompileDiagnostic` internally and copies its properties onto the `Error` instance — so `error.code`, `error.start`, `error.frame`, `error.toString()`, `error.toJSON()` all behave exactly like the diagnostic model, while `error instanceof Error` remains `true` for bundler integrations.

### 5.2 Warning path — inheritance via `warnings.js`

The `w()` helper in [`compiler_diagnostics_warnings`](compiler_diagnostics_warnings.md) constructs an `InternalCompileWarning` (a direct subclass), then applies `svelte-ignore` stack checks (`ignore_map` / `ignore_stack` from `state.js`) and the user-supplied `warningFilter` before pushing into the warnings array. The diagnostic model itself is ignore-agnostic — filtering is a consumer concern.

---

## 6. Data Flow: From AST Node to Diagnostic

```mermaid
sequenceDiagram
    autonumber
    participant V as Visitor / phase code
    participant H as e() or w() helper
    participant D as CompileDiagnostic
    participant S as state.js (ambient)
    participant F as get_code_frame
    participant C as caller (throw / warnings[])

    V->>H: (node, code, message)
    H->>H: derive [start, end] character offsets
    H->>D: new (code, message, position)
    D->>S: read state.filename
    Note over D,S: skipped if filename is UNKNOWN sentinel
    D->>S: state.locator(position[0]) → start Location
    D->>S: state.locator(position[1]) → end Location
    D->>F: get_code_frame(state.source, start.line - 1, end.column)
    F-->>D: frame string (context + caret)
    D-->>H: fully populated diagnostic
    alt fatal error
        H->>C: throw InternalCompileError (toString/toJSON delegate to diagnostic)
    else warning
        H->>C: push CompileWarning into warnings array (after ignore/filter)
    end
```

Afterwards, the diagnostic surfaces to users through `CompileResult` (warnings) or as a thrown `CompileError` (see [`compiler_types`](compiler_types.md)).

---

## 7. Code Frame Rendering Detail

### 7.1 Process flow

```mermaid
flowchart TD
    A["get_code_frame(source, line, column)<br/>line is 0-based"] --> B["split source on '\\n'"]
    B --> C["window:<br/>frame_start = max(0, line - 2)<br/>frame_end = min(line + 3, lines.length)"]
    C --> D["digits = width of String(frame_end + 1)"]
    D --> E{"rendered line == error line?"}
    E -- "no" --> F["'N: ' + tabs→spaces(text)"]
    E -- "yes" --> G["'N: ' + tabs→spaces(text)<br/>+ caret line:<br/>' ' × (digits + 2 + expanded prefix) + '^'"]
    F --> H["join('\\n')"]
    G --> H
    H --> I["frame string attached to diagnostic"]
```

### 7.2 Rendering rules

| Rule | Behavior |
|---|---|
| Context window | 2 lines before + the error line + 2 lines after (clipped at file boundaries) |
| Line numbering | 1-based, right-aligned to the widest line number in the window |
| Tab handling | Tabs expanded to **two spaces** in displayed text *and* in caret offset math |
| Caret position | Under `end.column` of the diagnostic range (single `^`) |
| Anchor line | `start.line` of the diagnostic; caret column from `end.column` |

### 7.3 Example output (`toString()`)

For an unused CSS selector starting at `src/App.svelte` line 12:

```
css_unused_selector: Unused CSS selector ".unused"
https://svelte.dev/e/css_unused_selector
src/App.svelte:12:2
10:   color: red;
11: }
12: .unused {
         ^
13:   }
14: }
```

The same diagnostic serialized with `toJSON()`:

```json
{
  "code": "css_unused_selector",
  "message": "Unused CSS selector \".unused\"\nhttps://svelte.dev/e/css_unused_selector",
  "filename": "src/App.svelte",
  "start": { "line": 12, "column": 2, "character": 210 },
  "end":   { "line": 12, "column": 10, "character": 218 },
  "position": [210, 218],
  "frame": "10:   color: red;\n11: }\n12: .unused {\n         ^\n13:   }\n14: }"
}
```

---

## 8. Design Notes and Edge Cases

- **Eager frame rendering** — the frame is computed once in the constructor, snapshotting against `state.source`. It is never recomputed or lazily derived.
- **Graceful degradation** — with no `position` (or an unresolvable locator), `position`/`start`/`end`/`frame` are simply omitted; `toString()` degrades to `code: message` (plus `filename` if known).
- **Filename sentinel** — `filename` is omitted entirely when the ambient state still holds `state.UNKNOWN_FILENAME`, so tooling never sees a fake path.
- **Caret at the range end** — the caret column comes from `end.column`, which keeps the marker inside the reported range for multi-line spans whose start column differs.
- **Locator dependency** — `state.locator` is configured by the parse phase; constructing positioned diagnostics outside an active compile yields location-less diagnostics rather than errors.
- **Immutable-by-convention** — fields are plain public properties; consumers (`Object.assign` in `InternalCompileError`, JSON serialization in tooling) rely on this shape remaining stable, which is codified by `ICompileDiagnostic` and `CompileError`.

---

## 9. Related Documentation

| Module | Relationship |
|---|---|
| [`compiler_diagnostics`](compiler_diagnostics.md) | Parent module: the diagnostics framework overview that bundles this model with the error/warning catalogs |
| [`compiler_diagnostics_errors`](compiler_diagnostics_errors.md) | Sibling: error catalog; wraps this model in `InternalCompileError` and throws it |
| [`compiler_diagnostics_warnings`](compiler_diagnostics_warnings.md) | Sibling: warning catalog; subclasses this model as `InternalCompileWarning`, applies ignore/filtering |
| [`compiler_core_state`](compiler_core_state.md) | Provides the ambient compilation state (`source`, `filename`, `locator`, ignore stack) this model reads at construction time |
| [`compiler_types`](compiler_types.md) | Declares the public `CompileError`/`CompileResult` contracts that extend/consume `ICompileDiagnostic` |
| [`compiler_core_entry`](compiler_core_entry.md) | Compiler entry points (`compile`, `compileModule`) that orchestrate the phases emitting diagnostics |
