# Shared Runtime Utilities

> **Module path:** `packages/svelte/src/internal/shared/` · **Parent:** [Shared Runtime](shared_runtime.md) · **Grandparent:** [Cross-Runtime Platform Services](cross_runtime_platform_services.md)

## Introduction

`shared_runtime_utilities` is the lowest, dependency-free utility stratum of the Svelte runtime. It contains two files:

| File | Kind | Core components |
| --- | --- | --- |
| `internal/shared/utils.js` | Runtime code | `noop`, `run`, `to_array` (plus type predicates, `run_all`, `deferred`, `fallback`, and captured native-global references) |
| `internal/shared/clone.test.ts` | Test suite | `capture_warnings` (test harness helper) |

Its mandate is deliberately narrow:

1. **Provide tiny, side-effect-free primitives** (`noop`, `run`, `to_array`) that are safe to inline into *both* the client and server bundles, and even into compiler-emitted output.
2. **Freeze references to native globals** (`Array.isArray`, `Object.keys`, `Object.prototype`, …) at module-evaluation time so that downstream hot paths cannot be slowed down or broken by monkey-patching.
3. **Guard the correctness of the shared clone/snapshot machinery** through the `clone.test.ts` regression suite, including the exact wording of dev-mode warnings.

Because the module has **no inbound dependencies on any other Svelte module** (only the *test* file imports `clone.js` and `client/proxy.js`), it forms the leaf of the runtime dependency graph. Everything above it — the [Reactive Runtime Engine](reactive_runtime_engine.md), the [Component Rendering Backends](component_rendering_backends.md), and even compiler code generation ([Compiler Client Transform](compiler_client_transform.md), [Compiler Server Transform](compiler_server_transform.md)) — may depend on it, never the reverse.

---

## Architecture

### Position within the platform-services layer

```mermaid
flowchart TB
    subgraph CRS["Cross-Runtime Platform Services"]
        direction TB
        subgraph SR["shared_runtime"]
            UTILS["shared_runtime_utilities<br/>─────────────────<br/>utils.js · clone.test.ts"]
            DIAG["shared_runtime_diagnostics<br/>errors.js · validate.js"]
            FLAGS["shared_runtime_flags<br/>flags/index.js"]
        end
        CTX["context_api<br/>client/context.js · server/context.js"]
    end

    subgraph CONSUMERS["Dependents (upstream)"]
        RT["Reactive Runtime Engine<br/>(signals, effects, proxies)"]
        DOM["Client DOM Renderer"]
        SSR["Server Runtime (SSR)"]
        CODEGEN["Compiler Back-End codegen"]
    end

    RT --> UTILS
    DOM --> UTILS
    SSR --> UTILS
    CODEGEN --> UTILS

    FLAGS -. mode switches .-> RT
    DIAG -. shared error/warning codes .-> RT
```

### Internal composition of the module

```mermaid
flowchart LR
    subgraph U["utils.js"]
        direction TB
        G["Native global snapshot<br/>is_array · index_of · array_from · object_keys<br/>define_property · get_descriptor(s)<br/>object_prototype · array_prototype<br/>get_prototype_of · is_extensible"]
        P["Type predicates<br/>is_function · is_promise"]
        I["Invocation helpers<br/>noop · run · run_all"]
        C["Concurrency helper<br/>deferred"]
        V["Value helpers<br/>fallback · to_array"]
    end

    subgraph T["clone.test.ts"]
        direction TB
        H["capture_warnings"]
        S["snapshot() regression tests<br/>(primitives, arrays, objects,<br/>proxies, cycles, classes,<br/>uncloneable values)"]
        H --> S
    end

    T -- "tests" --> CLONE["shared/clone.js (snapshot)"]
    T -- "tests proxy interop" --> PROXY["client/proxy.js"]
```

---

## Component Reference

### 1. `noop`

```js
export const noop = () => {};
```

The canonical "do nothing" function. It is used:

- as the **default value for optional callbacks/hooks** (transitions, effects, abort handlers), keeping call sites branch-free;
- to keep **hot paths monomorphic** — passing `noop` instead of `null`/`undefined` avoids re-shaping call sites that may receive either nothing or a real function;
- as an inert stand-in in the [Legacy Compatibility Layer](legacy_compat.md) and store interop code, where a no-op unsubscribe/teardown is required.

### 2. `run`

```js
/** @param {Function} fn */
export function run(fn) {
    return fn();
}
```

An indirect single-shot invoker. Wrapping a call in `run(fn)` instead of calling `fn()` directly:

- lets the compiler/runtime pass *thunks* around (e.g. effect and derived functions created by the [Reactive Runtime Engine](reactive_runtime_engine.md)) and execute them at a controlled point;
- avoids de-optimisation of large enclosing functions when a call target is only sometimes present (same reasoning as the monkey-patch guards below);
- is reused by the public-facing legacy adapters (`legacy-client.js` / `legacy-server.js` export a `run` built on this concept).

The plural companion `run_all(arr)` iterates an array of thunks without allocating intermediate arrays or closures — used for teardown lists (destroy callbacks, unsubscribe lists).

### 3. `to_array`

```js
/**
 * When encountering a situation like `let [a, b, c] = $derived(blah())`,
 * we need to stash an intermediate value that `a`, `b`, and `c` derive
 * from, in case it's an iterable
 */
export function to_array(value, n) { /* … */ }
```

**Purpose:** a coercion helper that compiler-emitted output calls when a *reactive* value is destructured. Reactive state must not be consumed lazily or more than once, so the destructuring pattern needs a real, materialised array.

**Decision flow:**

```mermaid
flowchart TD
    A["to_array(value, n)"] --> B{"Array.isArray(value)?"}
    B -- "yes" --> R1["Return value unchanged<br/>(zero-cost fast path)"]
    B -- "no" --> C{"n === undefined<br/>OR value not iterable?"}
    C -- "yes" --> R2["Array.from(value)<br/>(rest elements / array-likes)"]
    C -- "no" --> D["Iterate manually, pushing elements,<br/>breaking once n items are collected"]
    D --> R3["Return the bounded array"]
```

The `n` parameter carries semantic meaning: **`n === undefined` indicates a rest element** (`let [a, ...rest] = …`). In that case unbounded iteration is unavoidable and expected, so `Array.from` is used. With a known bound `n`, the manual loop stops after `n` elements — critical when the source is an *unbounded* or side-effecting iterable (e.g. a generator) that must not be drained.

It is invoked by code generated by the [Compiler Back-End](compiler_back_end.md) when lowering destructured `$state` / `$derived` declarations (see `create_state_declarators` in the client transform and the equivalent server-side lowering).

### 4. Supporting helpers in `utils.js` (non-core but part of the contract)

| Helper | Signature | Role |
| --- | --- | --- |
| `is_function` | `(thing) => thing is Function` | Type predicate used across runtime and bindings. |
| `is_promise` | `(value) => value is PromiseLike<T>` | Promise detection (adapted from `then/is-promise`, MIT); backs `await`-block resolution and async reactivity. |
| `deferred` | `() => { promise, resolve, reject }` | `Promise.withResolvers` polyfill; used by async blocks, batching and `tick()`. |
| `fallback` | `(value, fallback, lazy?) => V` | `undefined`-coalescing with optional lazy evaluation; used for prop defaults and compiled fallback expressions. |
| `run_all` | `(arr: Array<() => void>)` | Sequenced thunk execution without allocation. |

### 5. Captured native globals

```js
export var is_array = Array.isArray;
export var index_of = Array.prototype.indexOf;
export var array_from = Array.from;
export var object_keys = Object.keys;
export var define_property = Object.defineProperty;
export var get_descriptor = Object.getOwnPropertyDescriptor;
export var get_descriptors = Object.getOwnPropertyDescriptors;
export var object_prototype = Object.prototype;
export var array_prototype = Array.prototype;
export var get_prototype_of = Object.getPrototypeOf;
export var is_extensible = Object.isExtensible;
```

These bindings are captured **once, at module-evaluation time**. Two motivations (stated in the source):

1. **Correctness** — if user code (or a popular polyfill/extension) monkey-patches e.g. `Array.prototype.indexOf`, Svelte internals keep working against the original implementations.
2. **Performance** — engines inline native functions; going through a captured local binding avoids megamorphic lookups that would de-opt the surrounding hot code.

They are consumed pervasively; a representative consumer is the reactive `proxy` in `client/proxy.js`, which uses `get_prototype_of`, `object_prototype`, `array_prototype`, `is_array`, and `get_descriptor` to decide proxyability and to resolve writable own properties:

```mermaid
flowchart LR
    P["client/proxy.js<br/>proxy()"] -- "is_array(value)" --> G["shared/utils.js<br/>captured globals"]
    P -- "get_prototype_of / object_prototype / array_prototype" --> G
    P -- "get_descriptor(target, prop)" --> G
    G --> NATIVE["Original native implementations<br/>(immune to monkey-patching)"]
```

### 6. `capture_warnings` (`clone.test.ts`)

```ts
function capture_warnings() {
    const warnings: string[] = [];
    const warn = console.warn;
    console.warn = (message) => warnings.push(message);
    return () => {
        console.warn = warn;
        return warnings;
    };
}
```

A **test harness helper** (not shipped to users) that temporarily replaces `console.warn` with a collector and returns a *restore-and-collect* closure. It exists because `$state.snapshot` — implemented by `snapshot()` in `shared/clone.js` — reports uncloneable values in **dev mode** via a single formatted `console.warn` message (`state_snapshot_uncloneable`, with a link to `https://svelte.dev/e/state_snapshot_uncloneable`). The tests assert the *exact* user-facing text, including the truncation behaviour (first 7 of >10 offending paths are listed, followed by `- ...and N more`).

**Warning-capture flow during tests:**

```mermaid
sequenceDiagram
    participant Test as clone.test.ts test case
    participant CW as capture_warnings
    participant CN as console.warn (overridden)
    participant SN as snapshot() — shared/clone.js
    participant W as state_snapshot_uncloneable warning

    Test->>CW: capture_warnings()
    CW->>CN: replace console.warn with collector
    CW-->>Test: restore() closure
    Test->>SN: snapshot(uncloneableValue)
    SN->>W: w.state_snapshot_uncloneable(...)
    W->>CN: console.warn(formatted message)
    CN-->>CW: warnings.push(message)
    Test->>CW: restore()
    CW->>CN: reinstall original console.warn
    CW-->>Test: captured warnings[]
    Test->>Test: assert.deepEqual(warnings, expected)
```

The surrounding test suite validates `snapshot()` semantics that downstream features rely on (`$state.snapshot`, serialization boundaries):

- primitives pass through; arrays/objects produce deep, non-identical copies;
- **proxied state** snapshots *at the moment of the call* (later mutations don't leak into the copy);
- **cycles** are preserved (the copy references itself);
- class instances snapshot own fields only, honouring `toJSON`;
- reactive built-ins (`SvelteMap`) degrade to their native counterparts (`Map`);
- uncloneable values (functions) are returned as-is with a warning; nested uncloneable properties are individually listed with path-based diagnostics.

---

## Data Flow: how `to_array` travels through the system

```mermaid
flowchart LR
    SRC["User source<br/>let [a, b, c] = $derived(expr)"] --> ANA["Compiler Front-End<br/>(parse → analyze)"]
    ANA --> GEN["Compiler Back-End<br/>VariableDeclaration lowering"]
    GEN -- "emits $.to_array(value, n)" --> OUT["Compiled component"]
    OUT -- "calls at runtime" --> UTIL["shared/utils.js · to_array"]
    UTIL --> MAT["Materialised array feeding<br/>the derived signals for a, b, c"]
    MAT --> REACT["Reactive Runtime Engine<br/>(deriveds read the array)"]
```

The compiler knows the destructuring shape (hence `n` or `undefined` for rest), while the runtime helper performs the safe materialisation — a clean split of **static knowledge (compiler)** and **dynamic safety (runtime)**.

---

## Design Constraints & Invariants

1. **Zero internal dependencies.** `utils.js` imports nothing. Any new dependency would create a cycle risk for every layer above it and would break tree-shaking of individual helpers (see `scripts/check-treeshakeability.js` in [Repository Engineering Infrastructure](repository_engineering_infrastructure.md)).
2. **Environment-agnostic.** All code must run identically in browser, Node (SSR), and test environments; no `window`/`document` access.
3. **Monkey-patch immunity** for anything touching native objects — always via the captured globals above.
4. **Allocation discipline.** Helpers like `run_all` avoid closures/intermediate arrays; `to_array` short-circuits arrays without copying. These functions sit on per-signal/per-effect hot paths.
5. **Warning text is API.** `clone.test.ts` pins the exact `console.warn` payload of dev-mode warnings; changes to warning wording must be made together with this suite.

---

## Relationship to Other Modules

| Related module | Relationship |
| --- | --- |
| [Shared Runtime](shared_runtime.md) | Parent layer bundling cross-runtime concerns. |
| [Shared Runtime Flags](shared_runtime_flags.md) | Sibling; supplies compile-time feature switches (`legacy`, `async`, `tracing`) consumed by runtime code that also uses these utilities. |
| [Shared Runtime Diagnostics](shared_runtime_diagnostics.md) | Sibling; provides the shared error/warning message model. The `state_snapshot_uncloneable` warning exercised by `clone.test.ts` originates from this family. |
| [Context API](context_api.md) | Sibling platform service; client/server context implementations are consumers of the same low-level primitives. |
| [Reactive Runtime Engine](reactive_runtime_engine.md) | Primary consumer — `client_runtime_core`, proxies (`update_path`, `proxy`), and effects use `run`, `noop`, `deferred`, and the captured globals. |
| [Component Rendering Backends](component_rendering_backends.md) | The [Client DOM Renderer](client_dom_renderer.md) and [Server Runtime](server_runtime.md) invoke these helpers in teardown lists, async blocks, and prop fallbacks. |
| [Compiler Back-End](compiler_back_end.md) | Emits calls to `to_array` (and `fallback`) into generated component code for destructured reactive declarations. |
| [Legacy Compatibility](legacy_compat.md) | Legacy adapters reuse the `run` invocation pattern for class-component bridging. |

---

## Maintenance Notes

- **Adding helpers:** only add functions here that are genuinely needed by *both* client and server (or by generated code). Client-only helpers belong under `internal/client/`, server-only ones under `internal/server/`.
- **Changing `to_array`:** remember the `n === undefined` ⇒ rest-element contract; the compiler and runtime must agree on this encoding.
- **Extending `snapshot` warnings:** update `clone.test.ts` first — the tests document the intended user-facing output, including truncation at 7 listed paths and the `...and N more` suffix.
- **Tests location quirk:** `clone.test.ts` lives in `shared/` (next to `clone.js`) even though it imports `client/proxy.js`; this is intentional — it verifies the *interaction* between shared cloning and client proxies.
