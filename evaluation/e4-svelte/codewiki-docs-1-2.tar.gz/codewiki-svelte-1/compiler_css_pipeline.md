# Compiler CSS Pipeline (CSS Scoping, Pruning & Rendering)

## 1. Purpose & Scope

The `compiler_css_pipeline` module implements Svelte's CSS subsystem — the code responsible for turning the raw CSS written inside a component's `<style>` block into **scoped, validated, pruned CSS output**. Svelte's signature styling model is:

> **All component CSS is scoped to the component by default; authors opt *out* of scoping explicitly with `:global`.**

Enforcing that model spans two compiler phases and is implemented by three source files:

| Stage | File | Role |
|---|---|---|
| **Analysis** (phase 2) | `packages/svelte/src/compiler/phases/2-analyze/css/css-analyze.js` | Walks the parsed CSS AST during component analysis: validates `:global` usage, classifies selectors as global/local, detects `:global { }` blocks, collects `@keyframes` names, and marks selectors as *used/unused* relative to the template |
| **Shared helpers** | `packages/svelte/src/compiler/phases/css.js` | Tiny phase-agnostic CSS utilities (browser-vendor prefix removal, `@keyframes` detection) reused by both analysis and transform |
| **Transform** (phase 3) | `packages/svelte/src/compiler/phases/3-transform/css/index.js` | Rewrites the original CSS text via `MagicString`: strips `:global(...)` wrappers, injects the component hash class (`.svelte-<hash>`) onto scoped selectors, renames keyframes, prunes or comments out unused/empty rules, minifies in production, and emits source maps |

The module's core components are:

- **Analysis** — `analyze_css` visitors with helpers `is_global_block_selector`, `is_in_global_block`, `is_unscoped`
- **Shared** — `is_keyframes_node` (plus `remove_css_prefix`, `regex_css_name_boundary`)
- **Transform** — `render_stylesheet` with helpers `remove_global_pseudo_class`, `escape_comment_close`, `is_in_global_block`

## 2. Position in the Compiler

CSS follows the same *parse → analyze → transform* shape as the rest of the language, but as a parallel track beside the template/JS tracks:

```mermaid
flowchart LR
    subgraph P["Phase 1 — Parse (see compiler_parser)"]
        A["template &lt;style&gt; source"] --> B["AST.CSS.StyleSheet<br/>(root.css)"]
    end
    subgraph AN["Phase 2 — Analyze (see compiler_analyzer)"]
        C["analyze_component<br/>creates analysis.css = { ast, hash, keyframes[], has_global }"] --> D["analyze_css()"]
        D --> E["prune(css.ast, element)<br/>per template element"]
        E --> F["warn_unused(css.ast)<br/>(css_unused_selector)"]
    end
    subgraph T["Phase 3 — Transform"]
        G["render_stylesheet()"] --> H["{ code, map, hasGlobal }"]
    end
    B --> C
    F --> G
    H --> O["CompileResult.css<br/>(external file, or injected via inject_styles)"]
```

Key integration points with sibling modules (see their docs for details):

- **`compiler_parser`** — produces the `AST.CSS.StyleSheet` (`root.css`) that this module consumes; the CSS AST node types live in **`compiler_types`** (`types/css.d.ts`: `Rule`, `ComplexSelector`, `RelativeSelector`, `PseudoClassSelector`, `NestingSelector`, `Atrule`, …).
- **`compiler_analyzer`** — `analyze_component` initializes `analysis.css` (computing the scoping hash via `options.cssHash`), invokes `analyze_css`, then runs `prune` and `warn_unused`. The template visitors it defines (e.g. `ClassDirective`, `StyleDirective`) use the resulting scoping hash to attach `.svelte-<hash>` to elements at runtime.
- **`compiler_diagnostics`** — this module raises the `css_*` compile errors (`css_global_block_invalid_*`, `css_global_invalid_*`, `css_nesting_selector_invalid_placement`, `css_type_selector_invalid_placement`) and triggers the `css_unused_selector` warning.
- **`compiler_client_transform` / runtime backends** — `render_stylesheet` output is either emitted as a separate CSS asset or, when `options.css === 'injected'` (or for custom elements), embedded into the generated component via `analysis.inject_styles`; dev-mode cleanup of injected styles is handled by the runtime (`client_dev_mode`).

## 3. Architecture Overview

```mermaid
flowchart TB
    subgraph M["compiler_css_pipeline"]
        subgraph SUB1["CSS Analysis — see compiler_css_pipeline_analysis"]
            CA["css-analyze.js<br/>analyze_css() + css_visitors<br/>is_global_block_selector / is_in_global_block / is_unscoped"]
            SH["phases/css.js (shared)<br/>is_keyframes_node / remove_css_prefix<br/>regex_css_name_boundary"]
        end
        subgraph SUB2["CSS Transform — see compiler_css_pipeline_transform"]
            RS["3-transform/css/index.js<br/>render_stylesheet() + visitors<br/>remove_global_pseudo_class / escape_comment_close / is_in_global_block"]
        end
    end

    AN["compiler_analyzer<br/>(analyze_component)"] -- "analysis.css{ast,hash}" --> CA
    CA -- "metadata.{is_global,is_global_block,used,...}" --> RS
    CA -- "analysis.css.keyframes" --> RS
    CA -- "analysis.css.has_global" --> RS
    SH --> CA
    SH --> RS
    RS --> OUT["css: { code, map, hasGlobal }"]
```

The two stages communicate **exclusively through metadata on the CSS AST** plus two fields of `ComponentAnalysis.css`:

| Signal | Producer | Consumer |
|---|---|---|
| `node.metadata.is_global` / `is_global_like` (RelativeSelector, ComplexSelector) | Analysis | Transform (skip scoping, remove `:global`) |
| `node.metadata.is_global_block` / `has_global_selectors` / `has_local_selectors` (Rule) | Analysis | Transform (unwrap `:global {}`, skip pruning inside) |
| `node.metadata.rule` / `metadata.parent_rule` (ComplexSelector / Rule) | Analysis | Transform (nesting-specificity logic, `&` insertion) |
| `node.metadata.used` (ComplexSelector) | Analysis (after template pruning) | Transform (selector/rule pruning) |
| `analysis.css.keyframes: string[]` | Analysis (Atrule visitor) | Transform (keyframe + `animation-name` renaming) |
| `analysis.css.has_global: boolean` | Analysis | Transform result → `css.hasGlobal` (used for dedup/SSR head handling) |
| `analysis.css.hash: string` | `analyze_component` (`options.cssHash`) | Transform (scoping selector `.<hash>`) |

## 4. Core Concepts

### 4.1 The scoping model

- Every `ComplexSelector` in the component's stylesheet is **scoped by default**: the transform appends the scoping class `.svelte-<hash>` to the first scoppable simple selector.
- **`:global(.foo)`** removes part of a selector from scoping; **bare `:global`** as the first compound of a `Rule` turns the whole rule into a *global block* whose contents are emitted unscoped.
- Selectors consisting purely of "unscopeable" pseudo-classes/elements (`:host`, `:root`, `::view-transition*`) are treated as *global-like* and also left unscoped.

### 4.2 Used vs. unused selectors

Analysis cross-references each selector against the elements collected from the template (`analysis.elements`). Selectors matched by no element are flagged `metadata.used = false`; the transform then either **comments them out in dev** (`/* (unused) ... */`) or **removes them in production** (minify mode). This is what keeps Svelte's CSS output dead-code-free.

### 4.3 Keyframes handling

`@keyframes` names declared in the component are collected during analysis; the transform prefixes them (`-<hash>-name`) and rewrites `animation` / `animation-name` declarations to match. Names already prefixed `-global-` (or inside a `:global` block) are left untouched.

### 4.4 Specificity management

To keep scoped styling predictable, the *first* scoping occurrence per selector uses a plain class (specificity +0-1-0); subsequent occurrences in the same selector list use `:where(.svelte-<hash>)` (zero specificity). Nested rules whose ancestors already carry local selectors skip the bump.

## 5. Sub-modules

Detailed documentation for each pipeline stage lives in its own file (same directory as this document):

- **[`compiler_css_pipeline_analysis.md`](compiler_css_pipeline_analysis.md)** — *CSS Analysis (phase 2)*: the `analyze_css` entry point and `css_visitors` walk (Atrule / ComplexSelector / RelativeSelector / Rule / NestingSelector); the `:global` placement & shape validation rules and the compile errors they raise; global-classification (`is_global_block_selector`), global-block (`is_in_global_block`) and unscoped-path (`is_unscoped`) predicates; the `metadata.*` flags this stage writes for the transform; `@keyframes` collection and `has_global` computation; plus the shared utilities in `phases/css.js` (`is_keyframes_node`, `remove_css_prefix`, `regex_css_name_boundary`).
- **[`compiler_css_pipeline_transform.md`](compiler_css_pipeline_transform.md)** — *CSS Transform (phase 3)*: the `render_stylesheet` entry point and its `MagicString`-based visitors; `:global` stripping (`remove_global_pseudo_class`, including nested `&` insertion); hash-class injection with `:where`-based specificity control; `@keyframes` and `animation-name` renaming; empty/unused rule & selector pruning with dev (comment) vs prod (remove) behavior; minification details and source-map generation (`escape_comment_close`, `is_in_global_block` helpers).

Both stages share the vocabulary defined in [§4 Core Concepts](#4-core-concepts) and communicate exclusively through CSS AST `metadata` and `ComponentAnalysis.css`, as summarized in the table in [§3 Architecture Overview](#3-architecture-overview).

## 6. End-to-End Data Flow

```mermaid
sequenceDiagram
    participant AC as analyze_component (compiler_analyzer)
    participant AN as css-analyze.js
    participant PR as prune / warn_unused
    participant TR as render_stylesheet
    participant OUT as CompileResult.css

    AC->>AN: analyze_css(analysis.css.ast, analysis)
    AN->>AN: walk stylesheet with css_visitors
    Note over AN: validates :global usage<br/>sets is_global / is_global_block<br/>collects keyframes
    AC->>PR: prune(ast, element) for each template element
    Note over PR: marks selectors used/unused<br/>(scoping metadata on elements)
    AC->>PR: warn_unused(ast) → css_unused_selector
    AC->>TR: render_stylesheet(source, analysis, options)
    TR->>TR: walk AST, edit MagicString
    Note over TR: strip :global, inject .svelte-hash,<br/>rename keyframes, prune unused,<br/>minify (prod)
    TR->>OUT: { code, map, hasGlobal }
```

## 7. Error & Warning Surface

All diagnostics raised by this module are defined in `compiler_diagnostics`:

- **Errors** (throw `CompileError`): `css_global_block_invalid_combinator`, `css_global_block_invalid_declaration`, `css_global_block_invalid_list`, `css_global_block_invalid_modifier`, `css_global_block_invalid_modifier_start`, `css_global_block_invalid_placement`, `css_global_invalid_placement`, `css_global_invalid_selector`, `css_global_invalid_selector_list`, `css_nesting_selector_invalid_placement`, `css_selector_invalid`, `css_type_selector_invalid_placement`.
- **Warnings**: `css_unused_selector` (suppressible via `<!-- svelte-ignore css_unused_selector -->`, checked via `extract_svelte_ignore`).

## 8. Design Notes

- **Single-pass, metadata-driven**: both stages are single `zimmerframe` walks that communicate through `node.metadata`; no shared mutable state beyond `ComponentAnalysis`.
- **Text-preserving transforms**: phase 3 edits the *original source string* through `MagicString` (positions from the AST), which is what makes high-fidelity source maps and preprocessor-map merging possible.
- **Dev/prod duality**: dev keeps empty/unused rules as visible comments for debugging; production minify mode removes them and squeezes whitespace (with a special case preserving `--custom-property: ;` semantics for older Chromium).
