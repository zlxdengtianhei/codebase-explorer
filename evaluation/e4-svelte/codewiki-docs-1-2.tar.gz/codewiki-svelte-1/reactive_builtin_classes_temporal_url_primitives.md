# Reactive Temporal & URL Primitives (`SvelteDate`, `SvelteURL`, `SvelteURLSearchParams`)

## 1. Overview

This module implements **reactive, drop-in replacements for three JavaScript built-ins**:

| Class | Wraps | Granularity strategy | File |
|---|---|---|---|
| `SvelteDate` | `Date` | Single coarse-grained `#time` source + lazily cached per-method deriveds | `packages/svelte/src/reactivity/date.js` |
| `SvelteURL` | `URL` | Fine-grained source per URL component (protocol, hostname, port, …) | `packages/svelte/src/reactivity/url.js` |
| `SvelteURLSearchParams` | `URLSearchParams` | Single `#version` counter source (coarse invalidation) | `packages/svelte/src/reactivity/url-search-params.js` |

Their purpose is to make *values that are not plain state* — timestamps, parsed URLs, query strings — participate in Svelte's signal graph. Any read of these objects inside an [`$effect`](https://svelte.dev/docs/svelte/$effect) or `$derived` (via `date.getTime()`, `url.href`, `params.get(...)`, `Intl.DateTimeFormat`, iteration, etc.) registers a dependency, so the consumer re-runs automatically when the underlying value changes. Mutating them (`date.setHours(...)`, `url.pathname = ...`, `params.set(...)`) pushes updates through the same signal engine that `$state` uses.

They are exposed publicly through the `svelte/reactivity` entry point and are **client-only** (see [§10 SSR & Environment Notes](#10-ssr--environment-notes)).

This module is a child of [`reactive_builtin_classes`](reactive_builtin_classes.md), which itself lives under [Reactive State Primitives & Store Interop](Reactive_State_Primitives___Store_Interop.md). Its sibling modules are [`reactive_builtin_classes_collections`](reactive_builtin_classes_collections.md) (`SvelteMap`) and [`reactive_builtin_classes_environment_and_ssr`](reactive_builtin_classes_environment_and_ssr.md) (`MediaQuery`, `createSubscriber`).

---

## 2. System Context

The classes are *pure consumers* of the client reactivity engine. They contain no compiler interaction and no rendering logic — they bridge native Web-platform objects onto the signal runtime.

```mermaid
flowchart TB
    subgraph user["Application code"]
        E["$effect / $derived / template bindings"]
    end

    subgraph this_module["reactive_builtin_classes_temporal_url_primitives"]
        SD["SvelteDate"]
        SU["SvelteURL"]
        SUP["SvelteURLSearchParams"]
    end

    subgraph engine["Reactive Runtime Engine (see Reactive_Runtime_Engine docs)"]
        SRC["reactivity/sources.js<br/>state · set · increment"]
        DRV["reactivity/deriveds.js<br/>derived"]
        RT["runtime.js<br/>get · active_reaction · set_active_reaction"]
        TAG["dev/tracing.js<br/>tag"]
        BAT["batch.js — change scheduling"]
    end

    subgraph native["Native built-ins"]
        D["Date.prototype"]
        U["URL internals"]
        USP["URLSearchParams internals"]
    end

    E -->|"reads & writes"| SD
    E -->|"reads & writes"| SU
    E -->|"reads & writes"| SUP

    SD --> SRC & DRV & RT & TAG
    SU --> SRC & RT & TAG
    SUP --> SRC & RT & TAG

    SU -->|"searchParams instance"| SUP
    SUP -.->|"REPLACE / #update_url"| SU

    SD --> D
    SU --> U
    SUP --> USP

    SRC & DRV & RT --> BAT
```

---

## 3. Core Components

### 3.1 `SvelteDate` — coarse source, per-method derived cache

`SvelteDate` extends `Date`. Instead of making every date field a signal, it tracks **one number**: the epoch milliseconds.

Private state:

- `#time = state(super.getTime())` — the single source of truth.
- `#deriveds: Map<keyof Date, Source>` — per-method memoized deriveds, populated lazily.
- `#reaction = active_reaction` — the reaction that was active when the instance was constructed.

Behaviour is installed **once per process** via `#init()`, which walks `Object.getOwnPropertyNames(Date.prototype)` and patches the prototype (guarded by the module-level `inited` flag):

- **Readers** (`get*`, `to*`, `valueOf`):
  - Called **with arguments** → no memoization: `get(#time)` (dependency tracking only) then delegate straight to the native method. (Arguments can select data that isn't derivable from the memoized zero-arg result, e.g. `getFullYear()` has no args, but defensive handling keeps semantics safe.)
  - Called **without arguments** → lazily create a `derived` that reads `#time` and applies the native method, cache it in `#deriveds`, and return `get(derived)`.
- **Writers** (`set*`): delegate to the native method, then `set(#time, Date.prototype.getTime.call(this))` so all readers invalidate.

A subtle but critical detail: when a derived is first created for a method, the module temporarily restores `set_active_reaction(this.#reaction)` — the construction-time reaction — so the derived is **owned as if it had been created together with the instance**, not by whichever unrelated reaction happened to trigger the lazy creation first. This preserves correct ownership, teardown, and GC behaviour (see [client_runtime_core_deriveds](client_runtime_core_deriveds.md) and [client_runtime_core_runtime](client_runtime_core_runtime.md)).

```js
// Reader shape (zero-arg, first call)
const reaction = active_reaction;
set_active_reaction(this.#reaction);          // attribute ownership to construction site
d = derived(() => { get(this.#time); return Date.prototype[method].apply(this, args); });
this.#deriveds.set(method, d);
set_active_reaction(reaction);                // restore
return get(d);
```

### 3.2 `SvelteURL` — fine-grained source per component

`SvelteURL` extends `URL` and creates a dedicated source for every mutable URL part:

`#protocol`, `#username`, `#password`, `#hostname`, `#port`, `#pathname`, `#hash`, `#search` — plus `#searchParams`, a `SvelteURLSearchParams` built from the initial query string.

- **Getters** call `get(...)` on their backing source(s) before returning the native value. Composite getters depend on multiple sources: `host` reads `#hostname` + `#port`; `origin` reads `#protocol` + `#hostname` + `#port`; `href` reads **all eight** sources, making it the "catch-all" dependency.
- **Setters** are *write-through*: first assign to the `super` property (letting the native parser normalize/split the value), then `set(...)` each affected source from `super.*`. `href` and `search` additionally propagate their effect to the query string via `this.#searchParams[REPLACE](super.searchParams)`.
- `toString()` / `toJSON()` return `this.href`, so serializing the URL tracks every component.
- `searchParams` returns the shared `SvelteURLSearchParams` instance — mutations to it write back into `#search` (see §3.3), keeping the two representations consistent.

The constructor normalizes input through `new URL(url, base)` before `super(url)`, tags all sources in DEV, and performs the **`current_url` handoff** described in [§6.1](#61-construction-sequence--the-current_url-handoff).

### 3.3 `SvelteURLSearchParams` — version-counter invalidation

`SvelteURLSearchParams` extends `URLSearchParams`. Because params are an ordered *multimap* (duplicate keys allowed), per-key signals would be costly and complex; instead the class tracks **one integer**:

- `#version = state(0)` — bumped on every effective mutation.
- `#url` — the owning `SvelteURL`, captured once at construction from the module-level `get_current_url()` (may be `null` for standalone instances).
- `#updating` — re-entrancy guard preventing `params → url.search → REPLACE(params)` infinite recursion.

| Method | Kind | Effect |
|---|---|---|
| `append`, `sort` | mutate | native mutation → `#update_url()` → `increment(#version)` |
| `delete(name[, value])` | mutate | only invalidates if `super.has(name, value)` was true |
| `set(name, value)` | mutate | only invalidates if the joined values for `name` changed (see code comment about `?foo=1&bar=2&foo=3` — `has(name, value)` is deliberately *not* used as the change check) |
| `get`, `getAll`, `has`, `keys`, `values`, `entries`, `toString`, `size`, `[Symbol.iterator]` | read | `get(#version)` → registers a dependency on the caller's active reaction |
| `[REPLACE](params)` *(internal symbol)* | bulk replace | clears + repopulates from a native `URLSearchParams` **without** calling `#update_url`, then increments `#version`. Invoked by `SvelteURL` when `href`/`search` change |

`#update_url()` serializes the params and writes `this.#url.search = search && '?'.concat(search)` — guarded by `#updating` so the resulting `SvelteURL.search` setter's `[REPLACE]` call back into this instance is a no-op. The write-back happens only if a parent URL exists, and change detection in `delete`/`set` prevents no-op invalidations.

`REPLACE` is exported as a `Symbol()` so it stays module-private: it can never collide with user data keys and is not part of the public API.

---

## 4. Class & State Model

```mermaid
classDiagram
    direction LR

    class Date
    class URL
    class URLSearchParams

    class SvelteDate {
        -Source~number~ #time
        -Map~keyof Date, Source~ #deriveds
        -Reaction #reaction
        -#init() void
        +getUTCFullYear() number
        +setHours(...args) number
        +getTime() number
        +toString() string
    }

    class SvelteURL {
        -Source #protocol
        -Source #username
        -Source #password
        -Source #hostname
        -Source #port
        -Source #pathname
        -Source #hash
        -Source #search
        -SvelteURLSearchParams #searchParams
        +href string
        +host string
        +origin string
        +searchParams SvelteURLSearchParams
        +toString() string
        +toJSON() string
    }

    class SvelteURLSearchParams {
        -Source~number~ #version
        -SvelteURL #url
        -boolean #updating
        +append(name, value) void
        +delete(name, value_) void
        +set(name, value) void
        +sort() void
        +get(name) string
        +size number
        +[Symbol.iterator]()
        +[REPLACE](params) void
    }

    Date <|-- SvelteDate
    URL <|-- SvelteURL
    URLSearchParams <|-- SvelteURLSearchParams
    SvelteURL *-- "1" SvelteURLSearchParams : searchParams
    SvelteURLSearchParams --> "optional parent" SvelteURL : #url
```

---

## 5. Reactive Data Flow

### 5.1 Write path (example: `url.pathname = '/new'`)

```mermaid
flowchart LR
    A["Consumer mutates<br/>(effect / event handler / bind:value)"] --> B["setter: super.pathname = value<br/>(native parse &amp; normalize)"]
    B --> C["set(#pathname, super.pathname)"]
    C --> D["Source #pathname marked dirty<br/>reactions scheduled via batching"]
    D --> E["Dependent effects / deriveds<br/>re-run on next flush (tick)"]
```

Writes are subject to the engine's safety checks: `set()` throws `state_unsafe_mutation` if called from inside a derived/block effect, so mutations belong in effects, handlers, or top-level code — exactly like plain `$state` (see [client_runtime_core_sources](client_runtime_core_sources.md)).

### 5.2 Read path (example: `{$derived(url.host)}`)

```mermaid
flowchart LR
    A["Reaction executes"] --> B["getter: get(#hostname), get(#port)"]
    B --> C["runtime get() registers<br/>dependency on active reaction"]
    C --> D["native super.host returned"]
```

Dependency registration, read-versioning, and derived recomputation (`is_dirty` → `update_derived`) are handled entirely by [`runtime.js::get`](client_runtime_core_runtime.md) — this module only calls `get`/`set`.

### 5.3 Bidirectional `SvelteURL` ⇄ `SvelteURLSearchParams` sync

```mermaid
flowchart TD
    subgraph from_url["URL → Params"]
        U1["url.href = ... / url.search = ..."] --> U2["super assignment"]
        U2 --> U3["params[REPLACE](super.searchParams)<br/>(no write-back, no recursion)"]
        U3 --> U4["increment(#version)"]
    end

    subgraph from_params["Params → URL"]
        P1["params.append/set/delete/sort"] --> P2["native mutation"]
        P2 --> P3["#update_url():<br/>#updating = true"]
        P3 --> P4["url.search = '?...'"]
        P4 --> P5["REPLACE blocked by #updating"]
        P5 --> P6["#updating = false"]
    end

    U4 --> R["All readers of #version re-run"]
    P6 --> R
```

---

## 6. Process Flows

### 6.1 Construction sequence & the `current_url` handoff

`SvelteURLSearchParams` needs a reference to its owning `SvelteURL`, yet the parent creates the child **inside its own constructor** (before `this` could be passed explicitly). The module solves this with a module-scoped variable:

```mermaid
sequenceDiagram
    participant C as Consumer
    participant U as SvelteURL
    participant M as module scope (current_url)
    participant P as SvelteURLSearchParams

    C->>U: new SvelteURL(url, base)
    U->>U: url = new URL(url, base) — normalize
    U->>U: super(url); create 8 component sources; DEV tags
    U->>M: current_url = this
    U->>P: new SvelteURLSearchParams(url.searchParams)
    P->>M: this.#url = get_current_url()
    P-->>U: instance (linked)
    U->>M: current_url = null
    U-->>C: reactive URL
```

Notes:
- The handoff window is microscopic and synchronous; standalone `new SvelteURLSearchParams(...)` (no parent URL under construction) yields `#url === null`, and `#update_url` simply does nothing.
- `get_current_url()` exists as a function rather than an exported binding because bundlers/test runners may not respect ES-module live bindings for reassigned variables (per the source comment).

### 6.2 `SvelteDate` reader flow (lazy derived memoization)

```mermaid
flowchart TD
    A["date.getX() / toX() / valueOf()"] --> B{"args.length > 0?"}
    B -- "yes" --> C["get(#time) — track only<br/>delegate to Date.prototype"]
    B -- "no" --> D{"#deriveds.has(method)?"}
    D -- "yes" --> E["get(cached derived)"]
    D -- "no" --> F["save active_reaction,<br/>switch to #reaction (construction site)"]
    F --> G["derived = () => get(#time)<br/>+ native method"]
    G --> H["cache in #deriveds"]
    H --> I["restore active_reaction"]
    I --> E
```

Writers follow the much simpler path: `native set*(...)` → `set(#time, getTime())`.

### 6.3 `SvelteURLSearchParams` mutation flow (guards & change detection)

```mermaid
flowchart TD
    A["append / delete / set / sort"] --> B["native super mutation"]
    B --> C{"changed at all?<br/>(delete: has(name,value)<br/>set: joined values differ)"}
    C -- "no" --> Z["done — no invalidation"]
    C -- "yes" --> D{"#updating, or #url is null?"}
    D -- "yes" --> E["skip URL write-back"]
    D -- "no" --> F["#updating = true"]
    F --> G["#url.search = '?…'"]
    G --> H["REPLACE from URL is<br/>suppressed by guard"]
    H --> I["#updating = false"]
    E --> J["increment(#version)"]
    I --> J
    J --> K["readers of version re-run"]
```

---

## 7. `SvelteURL` Read/Write Dependency Matrix

| Property (accessor) | Reads (dependencies) | Writes (sources updated) | Also propagates to `#searchParams` |
|---|---|---|---|
| `href` | all 8 sources | all 8 sources | ✅ `REPLACE` |
| `search` | `#search` | `#search` | ✅ `REPLACE` |
| `host` | `#hostname`, `#port` | `#hostname`, `#port` | — |
| `origin` | `#protocol`, `#hostname`, `#port` | *(read-only)* | — |
| `protocol` / `username` / `password` / `hostname` / `port` / `pathname` / `hash` | own source | own source | — |
| `searchParams` | *(returns shared child; child tracks reads via `#version`)* | — | — |
| `toString()` / `toJSON()` | via `href` (all 8) | — | — |

This matrix is what makes bindings like `bind:value={url.pathname}` or `bind:value={url.href}` work: every setter updates exactly the sources its getter reads, so the dependency graph stays consistent regardless of which component the user edits.

---

## 8. Design Patterns & Invariants

| # | Pattern | Where | Why |
|---|---|---|---|
| 1 | **Source-per-property (fine-grained)** | `SvelteURL` | URL components are written independently; fine granularity avoids re-running effects for unrelated parts. |
| 2 | **Coarse epoch source + derived cache** | `SvelteDate` | All setters reduce to one number (`time`); per-method deriveds memoize formatting/parsing work per instance without per-field bookkeeping. |
| 3 | **Version-counter invalidation** | `SvelteURLSearchParams` | Multimap semantics (ordered, duplicate keys) make per-key signals impractical; one integer coalesces all changes. |
| 4 | **One-time prototype augmentation** (`inited` flag) | `SvelteDate.#init()` | Installs ~30 wrapped methods once on `SvelteDate.prototype`, shared by all instances; per-instance state stays in private fields. |
| 5 | **Construction-time reaction capture** | `SvelteDate.#reaction` | Lazily created deriveds must be owned/destroyed with the component that created the instance, not with the reaction that first triggered the read. |
| 6 | **Module-scoped context handoff** (`current_url` / `get_current_url()`) | `url.js` ⇄ `url-search-params.js` | Lets a child capture its parent during the parent's constructor, synchronously and without changing the public constructor signature. |
| 7 | **Re-entrancy guard + private `REPLACE` symbol** | `#updating`, `REPLACE` | Breaks the `params → url.search → params` cycle in both directions; `REPLACE` is reserved for URL-driven bulk updates. |
| 8 | **No-op write elision** | `delete`/`set` change checks | Avoids spurious invalidations (which would cause redundant effect runs) when a mutation doesn't actually change the parameter map. |
| 9 | **DEV-only tracing tags** | `tag(source, 'SvelteDate.#time')`, `tag(..., 'SvelteURL.protocol')`, … | Attaches human-readable labels for `$inspect`, tracing mode, and ownership-mismatch warnings; compiled away in production (see [client_dev_mode_debugging](client_dev_mode_debugging.md)). |

**Key invariants**

- **Read/write symmetry**: every getter reads exactly the sources its setter writes (§7).
- **No `set()` from deriveds**: enforced upstream by the engine (`state_unsafe_mutation`).
- **Single serialization truth**: `SvelteURLSearchParams.toString()` is the canonical form; `SvelteURL.search` mirrors it and vice versa, with guards preventing feedback loops.
- **Client-only**: all signal machinery is imported from `internal/client/*`; there is no server implementation of these classes.

---

## 9. Dev-Mode Instrumentation

All three classes call `tag(source, label)` from [`dev/tracing.js`](client_dev_mode_debugging.md) when `DEV` (via `esm-env`) is true:

- `SvelteDate` → `'SvelteDate.#time'`
- `SvelteURL` → `'SvelteURL.protocol'`, `'SvelteURL.username'`, … (one per component source)
- `SvelteURLSearchParams` → `'SvelteURLSearchParams version'`

`tag` sets `source.label` and tags the current value's proxy, improving stack traces, `$inspect` output, and the warnings emitted when state is read across ownership boundaries. Because these calls are guarded by `DEV`, production bundles contain neither the labels nor the branch.

---

## 10. SSR & Environment Notes

- **Client-only exports.** The server entry of `svelte/reactivity` exposes only `MediaQuery` and `createSubscriber` (see [`reactive_builtin_classes_environment_and_ssr`](reactive_builtin_classes_environment_and_ssr.md)). `SvelteDate`, `SvelteURL`, and `SvelteURLSearchParams` are **not available during server-side rendering** — server components must use plain built-ins.
- **Standalone params are legal.** `new SvelteURLSearchParams('a=1')` without a parent `SvelteURL` works fully reactively; only the write-back to `url.search` is skipped (`#url === null`).
- **No DOM dependency.** Unlike `MediaQuery`, these classes need no browser APIs — only the client signal runtime — which keeps them usable in Workers/tests that import the client entry.

---

## 11. Usage (canonical examples from the API docs)

```svelte
<script>
  import { SvelteDate } from 'svelte/reactivity';
  const date = new SvelteDate();
  $effect(() => {
    const interval = setInterval(() => date.setTime(Date.now()), 1000);
    return () => clearInterval(interval);
  });
</script>
<p>{new Intl.DateTimeFormat(undefined, { second: 'numeric' }).format(date)}</p>
```

```svelte
<script>
  import { SvelteURL, SvelteURLSearchParams } from 'svelte/reactivity';
  const url = new SvelteURL('https://example.com/path');
  const params = new SvelteURLSearchParams('message=hello');
</script>

<!-- editing any component updates href and vice versa -->
<input bind:value={url.protocol} />
<input bind:value={url.href} size="65" />

<button onclick={() => params.append('k', 'v')}>append</button>
<p>?{params.toString()}</p>
{#each params as [key, value]}<p>{key}: {value}</p>{/each}
```

Because setters exist for every URL component, template **bindings** (`bind:value={url.pathname}`) work in both directions without extra glue code.

---

## 12. Dependencies & Related Documentation

### Upstream runtime dependencies (all from the [Reactive Runtime Engine](<Reactive_Runtime_Engine_(Signals,_Effects___Batching_with_Dev-Mode_Instrumentation).md>))

| Import | Used by | Purpose | Detailed docs |
|---|---|---|---|
| `state` | all three | create source signals | [client_runtime_core_sources](client_runtime_core_sources.md) |
| `set` | `SvelteDate`, `SvelteURL` | write sources (with unsafe-mutation guard) | [client_runtime_core_sources](client_runtime_core_sources.md) |
| `increment` | `SvelteURLSearchParams` | `set(source, source.v + 1)` version bump | [client_runtime_core_sources](client_runtime_core_sources.md) |
| `derived` | `SvelteDate` | lazily evaluated, cached per-method values | [client_runtime_core_deriveds](client_runtime_core_deriveds.md) |
| `get`, `active_reaction`, `set_active_reaction` | all three | dependency registration & reaction context switching | [client_runtime_core_runtime](client_runtime_core_runtime.md) |
| `tag` | all three (DEV) | tracing labels | [client_dev_mode_debugging](client_dev_mode_debugging.md) |
| `esm-env` (`DEV`) | all three | dev/production dead-code elimination | — |

Change scheduling after `set`/`increment` (batching, flushing, `tick`) is owned by the engine — see [client_runtime_core_batching](client_runtime_core_batching.md).

### Sibling & surrounding modules

- [`reactive_builtin_classes`](reactive_builtin_classes.md) — parent: shared philosophy of wrapping built-ins.
- [`reactive_builtin_classes_collections`](reactive_builtin_classes_collections.md) — `SvelteMap` (per-key signals; contrasts with the version-counter approach).
- [`reactive_builtin_classes_environment_and_ssr`](reactive_builtin_classes_environment_and_ssr.md) — `MediaQuery` / `createSubscriber` (the SSR-available counterparts).
- [`stores`](stores.md) / [`stores_interop`](stores_interop.md) — `fromStore`/`toStore` interop for legacy store-based code.
- [`public_api`](public_api.md) — where `svelte/reactivity` is re-exported to consumers.
- [`compiler_client_transform_state_and_reactivity`](compiler_client_transform_state_and_reactivity.md) — how `$state`/`$derived` in user code compile down to the same `state`/`get`/`set` calls these classes use directly.