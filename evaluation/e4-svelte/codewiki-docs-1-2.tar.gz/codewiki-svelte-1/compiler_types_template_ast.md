# compiler_types_template_ast

## Module Overview

**Location:** `packages/svelte/src/compiler/types/template.d.ts`

The `compiler_types_template_ast` module defines the **canonical Svelte 5 template AST (Abstract Syntax Tree)** — the complete type model that describes every construct expressible in a Svelte component's markup. All interfaces are exported under the `AST` namespace, and the module serves as the *shared data contract* between every compiler phase:

- **[compiler_parser](compiler_parser.md)** *produces* these nodes from source text,
- **[compiler_analyzer](compiler_analyzer.md)** *enriches* them via their `/** @internal */ metadata` blocks and binds them to scopes,
- **[compiler_client_transform](compiler_client_transform.md)** and **[compiler_server_transform](compiler_server_transform.md)** *consume* them to emit reactive client code and SSR output.

Beyond plain structural types, the module encodes several compiler-wide conventions: node categories as discriminated unions (keyed on the `type` field), a strict separation between the *public* AST shape and *internal* analysis metadata, source positions on every node, and a module augmentation of `estree` so that embedded JavaScript expressions participate in the same location-tracking system.

> **Scope note:** This module covers the *template* AST only. Stylesheet nodes live in the sibling `AST.CSS` namespace (see [compiler_types_css_ast](compiler_types_css_ast.md)), the Svelte 4 node model lives in [compiler_types_legacy_ast](compiler_types_legacy_ast.md), and the public compiler entry-point types (`CompileResult`, `CompileError`, …) live in [compiler_types_compiler_api](compiler_types_compiler_api.md).

---

## Architecture

### Position in the Compiler Pipeline

The template AST is the *lingua franca* of the front-end. It is created once by the parser and mutated/annotated in place by later phases, which is why the type definitions contain both the "syntactic truth" (what the user wrote) and `@internal` metadata (what the compiler learned).

```mermaid
flowchart TB
    subgraph SRC["Source: `.svelte` file"]
        A["&lt;template markup&gt;"]
        B["&lt;script&gt; (JS/TS)"]
        C["&lt;style&gt; (CSS)"]
    end

    subgraph PARSE["Phase 1 — Parse (compiler_parser)"]
        P1["state machine:<br/>fragment / element / text"]
        P2["acorn: JS expressions &amp; scripts"]
    end

    subgraph AST["AST namespace (this module)"]
        T1["Root, Fragment,<br/>Elements, Blocks, Tags, Directives"]
        T2["estree nodes<br/>(augmented with start/end)"]
        T3["_CSS nodes<br/>(compiler_types_css_ast)"]
    end

    subgraph ANALYZE["Phase 2 — Analyze (compiler_analyzer)"]
        A1["Visitors walk the AST"]
        A2["populate @internal metadata<br/>+ attach Scope to each node"]
    end

    subgraph TRANSFORM["Phase 3 — Transform"]
        C1["compiler_client_transform<br/>(visitors dispatch on node.type)"]
        C2["compiler_server_transform<br/>(visitors dispatch on node.type)"]
    end

    A --> P1
    B --> P2
    C --> T3
    P1 --> T1
    P2 --> T2
    T1 --> A1
    T2 --> A1
    A1 --> A2 --> C1
    A2 --> C2
    T1 -. "Root.css" .-> T3
```

### Design Principles

| Principle | Realization in this module |
|---|---|
| **Discriminated unions** | Every concrete node has a literal `type` (e.g. `'IfBlock'`, `'BindDirective'`); unions like `Tag`, `Block`, `ElementLike`, `Directive`, `TemplateNode`, `SvelteNode` group them for exhaustive `switch` dispatch in visitors. |
| **Public/private split** | Syntax fields (`expression`, `name`, `modifiers`, `fragment`, …) are public; analysis results live under `/** @internal */ metadata` so the AST stays a stable public API while allowing internal mutation. |
| **Base-class reuse** | `BaseNode` (location + type) and `BaseElement` (`name`, `attributes`, `fragment`) factor out what all element-like constructs share. |
| **Embedded foreign ASTs** | JavaScript syntax uses `estree` node types (augmented in this module); CSS uses the `_CSS` namespace re-exported as `AST.CSS`. |
| **Bidirectional analysis links** | For CSS pruning, `SnippetBlock.metadata.sites` ↔ `Component/SvelteComponent/SvelteSelf/RenderTag.metadata.snippets` form reverse indexes computed during analysis. |

---

## Component Breakdown

### 1. Foundation Types

#### `AST.BaseNode`

The ancestor of every template node:

```ts
interface BaseNode {
    type: string;   // discriminant for unions
    start: number;  // byte offset of first character
    end: number;    // byte offset after last character
}
```

`start`/`end` power error reporting ([compiler_diagnostics](compiler_diagnostics.md) code frames via `get_code_frame`), sourcemaps, and dev-mode location tracking (`add_locations` in the client runtime).

#### `AST.Fragment`

The universal *node container*. Every element body, block body, and the component itself are `Fragment`s:

```ts
interface Fragment {
    type: 'Fragment';
    nodes: Array<Text | Tag | ElementLike | Block | Comment>;
    /** @internal */ metadata: {
        transparent: boolean; // scope is not a real JS scope; delegate identifier naming to parents
        dynamic: boolean;     // mount/hydrate must traverse into this fragment
        has_await: boolean;
    };
}
```

- `transparent` implements the *scope-flatness* optimization: element-level fragments do not introduce JavaScript scopes, so unique-identifier generation (see [compiler_analyzer_scope](compiler_analyzer_scope.md)) defers to the parent scope.
- `dynamic` lets the client transform skip constant subtrees when building mount/hydrate code.

#### `AST.Root`

The top of the tree returned by `parse` and exposed as `CompileResult.ast`:

| Field | Meaning |
|---|---|
| `options: SvelteOptions \| null` | Inline options parsed from `<svelte:options>`; override compile options |
| `fragment: Fragment` | The component markup |
| `css: AST.CSS.StyleSheet \| null` | Parsed `<style>` content ([compiler_types_css_ast](compiler_types_css_ast.md)) |
| `instance: Script \| null` | Parsed `<script>` |
| `module: Script \| null` | Parsed `<script module>` |
| `comments: JSComment[]` | Comments from scripts and `{expressions}` |
| `metadata.ts` | Whether the component was parsed as TypeScript |

#### `SvelteOptions` / `SvelteOptionsRaw`

`SvelteOptionsRaw` is the element-shaped node produced while parsing `<svelte:options>` (marked "intermediate representation — does not exist in the final AST"); the analyzer resolves it into the `SvelteOptions` object attached to `Root.options`, which carries `runes`, `immutable`, `namespace`, `customElement` configuration, etc.

### 2. Node Taxonomy

The `Fragment.nodes` element type is the union of five families. The taxonomy is what every downstream visitor `switch`es on.

```mermaid
classDiagram
    class BaseNode {
        <<interface>>
        +string type
        +number start
        +number end
    }
    class BaseElement {
        <<interface>>
        +string name
        +Array~Attribute|SpreadAttribute|Directive|AttachTag~ attributes
        +Fragment fragment
    }

    class RegularElement
    class SvelteElement {
        +Expression tag
    }
    class Component
    class SvelteComponent {
        +Expression expression
    }
    class SvelteSelf
    class TitleElement
    class SlotElement
    class SvelteBody
    class SvelteHead
    class SvelteWindow
    class SvelteDocument
    class SvelteFragment
    class SvelteBoundary

    class EachBlock {
        +Expression expression
        +Pattern context
        +Fragment body
        +Fragment fallback
        +string index
        +Expression key
    }
    class IfBlock {
        +Expression test
        +Fragment consequent
        +Fragment alternate
        +boolean elseif
    }
    class AwaitBlock {
        +Expression expression
        +Pattern value
        +Pattern error
        +Fragment pending
        +Fragment then
        +Fragment catch
    }
    class KeyBlock {
        +Expression expression
        +Fragment fragment
    }
    class SnippetBlock {
        +Identifier expression
        +Pattern[] parameters
        +Fragment body
    }

    class ExpressionTag
    class HtmlTag
    class ConstTag
    class DebugTag
    class RenderTag
    class AttachTag
    class Text {
        +string data
        +string raw
    }
    class Comment {
        +string data
    }

    BaseNode <|-- BaseElement
    BaseElement <|-- RegularElement
    BaseElement <|-- SvelteElement
    BaseElement <|-- Component
    BaseElement <|-- SvelteComponent
    BaseElement <|-- SvelteSelf
    BaseElement <|-- TitleElement
    BaseElement <|-- SlotElement
    BaseElement <|-- SvelteBody
    BaseElement <|-- SvelteHead
    BaseElement <|-- SvelteWindow
    BaseElement <|-- SvelteDocument
    BaseElement <|-- SvelteFragment
    BaseElement <|-- SvelteBoundary
    BaseElement <|-- SvelteOptionsRaw : intermediate only

    BaseNode <|-- EachBlock
    BaseNode <|-- IfBlock
    BaseNode <|-- AwaitBlock
    BaseNode <|-- KeyBlock
    BaseNode <|-- SnippetBlock

    BaseNode <|-- ExpressionTag
    BaseNode <|-- HtmlTag
    BaseNode <|-- ConstTag
    BaseNode <|-- DebugTag
    BaseNode <|-- RenderTag
    BaseNode <|-- AttachTag
    BaseNode <|-- Text
    BaseNode <|-- Comment
```

#### `ElementLike` — markup constructs (`<div>`, `<Foo/>`, `<svelte:head>`…)

All extend `BaseElement`, giving them `name`, an attribute list, and a child `Fragment`. Highlights:

| Node | Source syntax | Notable fields / metadata |
|---|---|---|
| `RegularElement` | `<div>`, `<svg:g>` | `metadata.svg` / `metadata.mathml` namespace flags, `metadata.has_spread` (forces dynamic attribute application), `metadata.scoped` (CSS scoping — set by [compiler_css_pipeline](compiler_css_pipeline.md)) |
| `SvelteElement` | `<svelte:element this={tag}>` | Dynamic `tag` expression; namespace booleans are *best-effort inferences* since the tag is dynamic |
| `Component` | `<Foo>` | `metadata.scopes` (per-slot `Scope` map), `metadata.snippets` (locally-defined snippets it may render — CSS pruning input) |
| `SvelteComponent` | `<svelte:component this={X}>` | Dynamic component `expression`; same snippet/scopes metadata |
| `SvelteSelf` | `<svelte:self>` | Recursion node; carries snippet/scopes metadata |
| `SlotElement` / `SvelteFragment` | `<slot>` / `<svelte:fragment>` | Slot content vs. slot fallback boundaries |
| `SvelteBoundary` | `<svelte:boundary>` | Error/async recovery boundary (rendered by `boundary` in the client DOM renderer) |
| `SvelteHead`, `SvelteWindow`, `SvelteBody`, `SvelteDocument` | `<svelte:head>` etc. | Render-target relocation nodes |
| `TitleElement` | `<title>` | Fixed `name: 'title'` |

#### `Block` — control flow (`{#if}`, `{#each}`, `{#await}`, `{#key}`, `{#snippet}`)

| Node | Body shape | Key metadata |
|---|---|---|
| `IfBlock` | `consequent` + optional `alternate` Fragments | `elseif: true` marks chains created by `{:else if}` (affects hydration/codegen flattening); `metadata.expression` |
| `EachBlock` | `body` + optional `fallback` (`{:else}`) | `metadata.keyed`, `metadata.is_controlled` (single-child optimization: skip comment anchor + faster insertion), `metadata.contains_group_binding`, `metadata.declarations` (per-item `Binding`s), `metadata.transitive_deps` (legacy invalidation set) |
| `AwaitBlock` | up to three Fragments: `pending` / `then` / `catch` | `value`/`error` patterns bound inside the branches |
| `KeyBlock` | single `fragment` re-created when `expression` changes | — |
| `SnippetBlock` | parameterized, hoistable function-like block | `metadata.can_hoist`, `metadata.sites` (which components/render tags may render it) |

#### `Tag` — inline interpolation & special tags

| Node | Syntax | Purpose |
|---|---|---|
| `ExpressionTag` | `{expr}` | Text interpolation; `metadata.expression` holds reactivity info |
| `HtmlTag` | `{@html expr}` | Raw HTML injection |
| `ConstTag` | `{@const x = expr}` | Block-scoped const; `declaration` is a normalized single-declarator `VariableDeclaration` |
| `DebugTag` | `{@debug a, b}` | Dev-mode logging breakpoint |
| `RenderTag` | `{@render foo(args)}` | Snippet invocation; `metadata.snippets`/`path` used for CSS pruning and hydration path tracking |
| `AttachTag` | `{@attach foo(...)}` | Attachment (new action API) execution |

#### `Directive` — attribute-position constructs

All directives extend `BaseNode` and appear inside `BaseElement.attributes`:

| Directive | Syntax | Notes |
|---|---|---|
| `BindDirective` | `bind:value={x}` | `expression` restricted to `Identifier \| MemberExpression \| SequenceExpression`; `metadata.parent_each_buttons`… rather, `metadata.parent_each_blocks` + `binding_group_name` support grouped input binding |
| `OnDirective` | `on:click={handler}` | `modifiers` whitelist (`preventDefault`, `stopPropagation`, `capture`, `passive`, `trusted`, …) |
| `ClassDirective` | `class:active={cond}` | Shorthand `class:x` infers expression |
| `StyleDirective` | `style:color={c}` | `value` is `true` (shorthand) / `ExpressionTag` / mixed `Array<Text \| ExpressionTag>`; `modifiers: ['important']` |
| `TransitionDirective` | `transition:`, `in:`, `out:` | `intro`/`outro` booleans plus `local`/`global` modifiers replace separate directive types |
| `AnimateDirective` | `animate:flip` | Only valid inside keyed each blocks (enforced by [compiler_analyzer](compiler_analyzer.md)) |
| `UseDirective` | `use:action={params}` | Action invocation |
| `LetDirective` | `let:x` | Slot prop forwarding; `expression` may be `null` (shorthand) or destructure pattern |

The `AttributeLike` alias = `Attribute | SpreadAttribute | Directive`; plain `Attribute` nodes carry `value: true | ExpressionTag | Array<Text | ExpressionTag>` plus `metadata.delegated` (hoisted `DelegatedEvent` for `onclick={...}` delegation) and `metadata.needs_clsx`.

#### Supporting types

- **`Text`** — `data` (entities decoded) vs `raw` (as written); the duality enables hydration and the Prettier plugin to round-trip.
- **`Attribute` / `SpreadAttribute`** — see above; spreads force runtime attribute application.
- **`Script`** — `context: 'default' | 'module'`, `content: Program` (estree), plus source `attributes` (e.g. `lang="ts"`).
- **`JSComment`** — preserved comments with line/column `loc`, emitted into output JS for legal/banner comments.
- **`Namespace`** — `'html' | 'svg' | 'mathml'`, mirrors the runtime template builders `from_html` / `from_svg` / `from_mathml` in the [client_dom_renderer](client_dom_renderer.md).
- **`DelegatedEvent`** — `{hoisted: true, function}` when an inline `onclick={...}` handler can be hoisted for event delegation.

### 3. Union Type Layer

```mermaid
flowchart LR
    subgraph TemplateNode["TemplateNode — every node that can appear in the tree"]
        ROOT["Root"]
        TXT["Text"]
        CMT["Comment"]
        ATTR["Attribute / SpreadAttribute"]
        subgraph DIR["Directive"]
            AN["AnimateDirective"] --- BD["BindDirective"] --- CD["ClassDirective"] --- LD["LetDirective"]
            ON["OnDirective"] --- SD["StyleDirective"] --- TD["TransitionDirective"] --- UD["UseDirective"]
        end
        AT["AttachTag"]
        subgraph TAG["Tag"]
            ET["ExpressionTag"] --- HT["HtmlTag"] --- CT["ConstTag"] --- DT["DebugTag"] --- RT["RenderTag"]
        end
        subgraph EL["ElementLike"]
            RE["RegularElement"] --- SE["SvelteElement"] --- CO["Component"] --- SC["SvelteComponent"] --- ...
        end
        subgraph BLK["Block"]
            IF["IfBlock"] --- EA["EachBlock"] --- AW["AwaitBlock"] --- KB["KeyBlock"] --- SN["SnippetBlock"]
        end
    end
    SNODE["SvelteNode = estree Node | TemplateNode | Fragment | _CSS.Node | Script"]
    TemplateNode --> SNODE
```

`SvelteNode` is the "any node the compiler deals with" union — it is the parameter type of generic traversal helpers such as `set_scope` in `phases/scope.js`, which re-binds the active `Scope` whenever the analyzer descends into a node that owns one.

---

## Data Flow: How a Node Travels Through the Compiler

```mermaid
sequenceDiagram
    participant Parse as compiler_parser (phase 1)
    participant AST as AST namespace (this module)
    participant Ana as compiler_analyzer (phase 2)
    participant Scope as compiler_analyzer_scope
    participant Css as compiler_css_pipeline
    participant Cl as compiler_client_transform
    participant Srv as compiler_server_transform

    Note over Parse: state machine + acorn
    Parse->>AST: instantiate nodes (e.g. RegularElement, IfBlock)<br/>syntax fields only; metadata defaults
    Ana->>AST: walk Root via visitors
    Ana->>Scope: create/lookup Scope per fragment/block/component
    Scope-->>AST: attach scopes; Component.metadata.scopes
    Ana->>AST: fill @internal metadata<br/>(expression reactivity, is_controlled, snippets/sites, path)
    Css->>AST: set RegularElement.metadata.scoped,<br/>prune via SnippetBlock.metadata.sites
    AST->>Cl: visitor dispatch on node.type → client JS
    AST->>Srv: visitor dispatch on node.type → SSR payload code
```

Key behaviors visible in the consumer code:

- **Scope binding:** `set_scope(node, { state })` in `phases/scope.js` checks the node's assigned scope and swaps the visitor state before continuing traversal — the *scope ownership* is decided by analyzer visitors like `SvelteFragment` (which creates a `child()` scope per fragment).
- **Directive referencing:** the `SvelteDirective` scope rule references `node.name.split('.')[0]` and visits `node.expression`, which only type-checks because `Directive` nodes guarantee `name: string` and an optional expression — a direct contract of this module.
- **CSS pruning:** the bidirectional `SnippetBlock.metadata.sites` ↔ `Component.metadata.snippets` / `RenderTag.metadata.snippets` sets let the CSS transform keep selectors only for snippets that can actually be rendered (consumed by [compiler_css_pipeline](compiler_css_pipeline.md)).

---

## Dependencies

```mermaid
flowchart TD
    subgraph THIS["compiler_types_template_ast"]
        TD["template.d.ts<br/>(AST namespace)"]
    end

    EST["estree (external)<br/>Expression, Program, Pattern,<br/>Identifier, MemberExpression, …"]
    AUG["estree module augmentation<br/>BaseNode += start / end / typeAnnotation"]
    CSSMOD["compiler_types_css_ast<br/>(_CSS namespace → AST.CSS)"]
    SCOPET["compiler_analyzer_scope<br/>(Scope type, phases/scope.js)"]
    COMP["compiler_types_compiler_api<br/>(#compiler: Binding, ExpressionMetadata)"]

    EST -->|imports| TD
    TD -->|augments| AUG
    CSSMOD -->|"Root.css, SvelteNode, `export type { _CSS as CSS }`"| TD
    SCOPET -->|"Component/SvelteComponent/SvelteSelf.metadata.scopes"| TD
    COMP -->|"metadata.expression (ExpressionMetadata),<br/>EachBlock.metadata.declarations (Binding)"| TD

    TD -.->|"Root.ast exposed via CompileResult"| COMP2["compiler_types_compiler_api<br/>(CompileResult)"]
```

| Dependency | Direction | Purpose |
|---|---|---|
| `estree` | imported + augmented | JS syntax embedded in tags, directives, attributes; augmentation adds `start`/`end` (Svelte parser) and `typeAnnotation` (acorn-typescript) so expression nodes carry source positions through the template pipeline. |
| `compiler_types_css_ast` (`_CSS`) | imported, re-exported as `AST.CSS` | Stylesheet nodes stored on `Root.css` and included in the `SvelteNode` union. |
| `compiler_analyzer_scope` (`Scope`) | type-only import from `phases/scope.js` | Referenced by component-like metadata (`scopes: Record<string, Scope>`) — links template nodes to the scope tree. |
| `#compiler` (`Binding`, `ExpressionMetadata`) | type-only import | Shared internal analysis types: `ExpressionMetadata` on every reactive expression; `Binding` in each-block declarations & transitive dependency sets. |
| `compiler_types_compiler_api` | downstream | `CompileResult.ast` is the serialized `AST.Root`; see [compiler_types_compiler_api](compiler_types_compiler_api.md). |

**Consumers** (upstream modules that operate on these types): [compiler_parser](compiler_parser.md) (construction), [compiler_analyzer](compiler_analyzer.md) (enrichment), [compiler_css_pipeline](compiler_css_pipeline.md) (scoping flags, pruning), [compiler_client_transform](compiler_client_transform.md) and [compiler_server_transform](compiler_server_transform.md) (codegen dispatch), and [compiler_migrate](compiler_migrate.md) (which instead targets the legacy model — see [compiler_types_legacy_ast](compiler_types_legacy_ast.md)).

---

## Usage Guide for Maintainers

**Adding a new template feature:**
1. Define the interface in the `AST` namespace extending `BaseNode` (or `BaseElement` for element-like syntax) with a literal `type`.
2. Add it to the appropriate union: `Tag`, `Block`, `ElementLike`, or `Directive` — this automatically widens `Fragment.nodes`, `TemplateNode`, and `SvelteNode`.
3. Implement a visitor in `phases/2-analyze/visitors/` (see [compiler_analyzer_template_visitors](compiler_analyzer_template_visitors.md) / [compiler_analyzer_block_visitors](compiler_analyzer_block_visitors.md)) — the analyzer's visitor map is keyed by these `type` strings.
4. Add client and/or server transform visitors ([compiler_client_transform](compiler_client_transform.md), [compiler_server_transform](compiler_server_transform.md)).
5. Add parse support in [compiler_parser_template_state_machine](compiler_parser_template_state_machine.md) and diagnostics in [compiler_diagnostics_errors](compiler_diagnostics_errors.md).

**Conventions to preserve:**
- Never rely on `metadata` being populated outside phase 2+; phase-1 code must treat it as uninitialized.
- Keep `@internal` metadata mutable-by-analyzer only; public syntax fields should be considered frozen after parsing (the migrator and Prettier plugin depend on their fidelity).
- Prefer composing existing union aliases (`Tag`, `ElementLike`, …) over raw node lists so exhaustive switches in transforms stay compiler-checked.
- Shared child-visitor helpers like `visit_function`, `build_attribute_value`, `process_children` are typed against these unions — update them in lockstep with type changes.
