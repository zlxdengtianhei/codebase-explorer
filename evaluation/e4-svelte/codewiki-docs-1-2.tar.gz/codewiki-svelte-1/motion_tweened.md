# motion_tweened

## Introduction

The `motion_tweened` module provides **clock-driven animated values** for Svelte — the `Tween` class and the legacy `tweened()` store. A tweened value does not jump to its new value; instead, when a **target** is set, a **current** value moves towards it smoothly over time, shaped by `delay`, `duration`, and an `easing` function, with values interpolated structurally (numbers, arrays, objects, and `Date`s).

The module lives at `packages/svelte/src/motion/` and is a sub-module of the [Motion & Visual Effects System](Motion___Visual_Effects_System.md):

| File | Core components | Role |
| --- | --- | --- |
| `packages/svelte/src/motion/tweened.js` | `get_interpolator`, `tweened()`, `class Tween` | Implementation: legacy store factory, modern signal-backed class, interpolation engine |
| `packages/svelte/src/motion/public.d.ts` | `Tweened<T>` (interface), re-exports of `tweened`, `Tween`, `spring`, `Spring`, `prefersReducedMotion` | Public type contracts for `svelte/motion` |

Key facts at a glance:

- **Two parallel implementations share one API shape**:
  - `tweened(value, defaults)` — legacy, **deprecated**. Built on the classic [stores](stores.md) model (`writable`).
  - `class Tween<T>` (`>= 5.8.0`) — the recommended replacement. Built on the Svelte 5 signal system (`state()` / `set()` / `get()` / `render_effect()`).
- Animation frames are driven by the shared client runtime **`loop` / `raf`** infrastructure ([client_runtime_core](client_runtime_core.md)), not by `setInterval` — each frame is a pure function of elapsed wall-clock time, so dropped frames never slow the animation down.
- Both APIs are **client-side primitives**: they rely on `requestAnimationFrame` timing (with graceful `Date.now()` fallback outside the browser).
- The sibling [motion_spring](motion_spring.md) module implements the identical `target`/`current` + `set()`/`of()` pattern, but with physics (stiffness/damping) instead of a fixed duration.

---

## Architecture

```mermaid
flowchart TB
    subgraph MT["motion_tweened (this module)"]
        TWEENED["tweened(value, defaults)<br/>@deprecated store factory"]
        TWEEN["class Tween&lt;T&gt;<br/>(since 5.8.0)"]
        OF["Tween.of(fn, options)<br/>static reactive factory"]
        INTERP["get_interpolator(a, b)<br/>recursive interpolation engine"]
        CONTRACT["Tweened&lt;T&gt; interface<br/>(public.d.ts)"]
    end

    subgraph STORES["stores (Reactive State Primitives)"]
        WRITABLE["writable(value)"]
        READABLE["Readable&lt;T&gt; / Unsubscriber"]
    end

    subgraph CORE["client_runtime_core (Reactive Runtime Engine)"]
        SIG["state() / set() / get()<br/>signal sources"]
        LOOP["loop(callback)<br/>rAF task → { promise, abort }"]
        REFFECT["render_effect(fn)"]
        RAF["raf<br/>{ now(), tick(), tasks }"]
    end

    subgraph DEV["client_dev_mode"]
        TAG["tag(source, label)<br/>devtools / tracing"]
    end

    subgraph EASING["transitions_and_animations — easing"]
        LINEAR["linear(t) — default easing"]
        OTHERS["cubicOut, bounceOut, elasticIn, ..."]
    end

    TWEENED -->|wraps| WRITABLE
    TWEENED -->|schedules frames| LOOP
    TWEENED -->|default easing| LINEAR
    TWEENED -->|builds tweens| INTERP
    TWEEN -->|#current / #target| SIG
    TWEEN -->|schedules frames| LOOP
    TWEEN -->|Tween.of()| REFFECT
    TWEEN -->|builds tweens| INTERP
    TWEEN -.->|DEV only: labels signals| TAG
    WRITABLE --> READABLE
    LOOP --> RAF
    CONTRACT -.->|satisfied by| TWEENED
    OTHERS -.->|user-supplied easing option| TWEENED
    OTHERS -.->|user-supplied easing option| TWEEN
```

**Layering in one sentence:** the module is a thin, self-contained orchestration layer that combines the runtime's *frame scheduler* (`loop`/`raf`) with either the *store model* (`writable`) or the *signal model* (`state`/`set`), parameterized by user-supplied `easing` functions and its own structural *interpolation* engine.

---

## Public API

### `Tweened<T>` contract (`public.d.ts`)

```ts
export interface Tweened<T> extends Readable<T> {
    set(value: T, opts?: TweenedOptions<T>): Promise<void>;
    update(updater: Updater<T>, opts?: TweenedOptions<T>): Promise<void>;
}
```

- `set(value, opts)` sets the target and returns a `Promise` that resolves **when the current value catches up** (i.e. when the animation finishes).
- `update(updater, opts)` receives `(target_value, value)` — the *requested* target and the *current* value — and applies the returned value via `set`.
- `Readable<T>` (from the [stores](stores.md) contract) contributes `subscribe(run, invalidate) → Unsubscriber`.

### `tweened(value, defaults?)` — legacy store factory *(deprecated)*

Returns a `Tweened<T>`: `{ set, update, subscribe }`. Use [`Tween`](https://svelte.dev/docs/svelte/svelte-motion#Tween) in new code.

```js
import { tweened } from 'svelte/motion';
import { cubicOut } from 'svelte/easing';

const size = tweened(0, { duration: 400, easing: cubicOut });
await size.set(100, { delay: 200 }); // resolves when the animation ends
size.update((target, current) => target + 10);
```

Implementation notes:

- Internally wraps `writable(value)` from `../store/shared/index.js` — all subscribers are notified through the classic store queue on every animation frame.
- **Null bootstrap:** if the current `value` is `null`/`undefined`, the first `set()` assigns immediately and skips animation (there is nothing to interpolate *from*).
- `duration: 0` (or resolved to `0`) snaps instantly: the previous task is aborted and the store is set synchronously.

### `class Tween<T>` — the modern, signal-backed tween (`>= 5.8.0`)

```svelte
<script>
    import { Tween } from 'svelte/motion';

    const tween = new Tween(0, { duration: 300 });
</script>

<input type="range" bind:value={tween.target} />   <!-- setter → tween.set(v) -->
<input type="range" bind:value={tween.current} disabled /> <!-- animated output -->
```

| Member | Kind | Behaviour |
| --- | --- | --- |
| `#current`, `#target` | private signals | Created with `state(value)`; in `DEV` both are labelled via `tag()` (`'Tween.current'` / `'Tween.target'`) for devtools/tracing. |
| `set(value, options?)` | method | Writes `target`, then runs the frame loop on `current`; returns the completion `Promise`. |
| `get current()` | getter | `get(this.#current)` — subscribes the reading reaction to the animated value. |
| `get target()` / `set target(v)` | accessor pair | Reading returns the raw target; **writing delegates to `set(v)`**, which is what makes `bind:value={tween.target}` animate rather than jump. |
| `static Tween.of(fn, options?)` | factory | Creates `new Tween(fn())` and wires a `render_effect(() => tween.set(fn()))` so the *target* reactively tracks `fn`'s dependencies. Must run inside an effect root (e.g. component initialisation). |

```js
let { number } = $props();
const tween = Tween.of(() => number, { duration: 250 }); // follows `number` reactively
```

---

## The interpolation engine: `get_interpolator(a, b)`

`get_interpolator` is a **recursive factory**: given start value `a` and end value `b`, it returns `fn: (t: number) => T`, where `t ∈ [0, 1]` (post-easing). Leaf values are linearly blended; composites recurse per element/key.

```mermaid
flowchart TD
    A["get_interpolator(a, b)"] --> B{"a === b or<br/>a !== a (NaN)?"}
    B -- "yes" --> C["() =&gt; a<br/>constant function"]
    B -- "no" --> D{"typeof a === typeof b<br/>and Array-ness matches?"}
    D -- "no" --> E["throw Error:<br/>'Cannot interpolate values of different type'"]
    D -- "yes" --> F{"typeof a === 'object'?"}
    F -- "no (number)" --> G["t =&gt; a + t * delta<br/>linear numeric blend"]
    F -- "yes" --> H{"a or b is null?"}
    H -- "yes" --> I["throw Error:<br/>'Object cannot be null'"]
    H -- "no" --> J{"is_date(a) and is_date(b)?"}
    J -- "yes" --> K["blend epoch millis:<br/>t =&gt; new Date(an + t * delta)"]
    J -- "no" --> L["build per-key interpolators<br/>over Object.keys(b)"]
    L --> M["t =&gt; reconstructed result object"]
    F -- "yes (Array)" --> N["pairwise get_interpolator(a[i], b[i])<br/>t =&gt; arr.map(fn =&gt; fn(t))"]
```

| Input shapes | Result per frame `t` |
| --- | --- |
| Equal values, or `NaN` start | constant `a` (short-circuit) |
| `number` → `number` | `a + t * (b - a)` |
| `Array` → `Array` (same length semantics) | per-index blend; arrays are treated structurally, not as objects |
| plain `object` → plain `object` | per-key blend over the keys of `b`, reassembled into a fresh object |
| `Date` → `Date` | interpolation over `getTime()` epoch deltas, returned as a new `Date` |
| anything else (strings, booleans, …) | **snap**: `() => b` — non-numeric leaves jump at the start rather than fail |

Two important consequences:

1. **Type mismatches are fatal** (throws synchronously inside the first animated frame), protecting users from silently broken tweens.
2. **Mixed composites degrade gracefully**: an object like `{ x: 0, label: 'hi' }` tweens `x` numerically while `label` snaps.

Users can replace this engine entirely via the `interpolate` option (see below).

---

## Tween lifecycle & data flow

Both `tweened()` and `Tween.set()` share the same clock-based algorithm. The flow below annotates the shared steps and where the two implementations diverge (store write vs signal write).

```mermaid
sequenceDiagram
    autonumber
    participant C as Consumer (component / binding)
    participant T as tweened store / Tween
    participant I as get_interpolator
    participant L as loop → raf task
    participant S as writable store / #current signal

    C->>T: set(value, opts?)
    T->>T: merge { ...defaults, ...opts }<br/>(delay, duration, easing, interpolate)
    alt duration === 0
        T->>L: previous_task.abort()
        T->>S: current = value (snap)
        T-->>C: Promise.resolve()
    else animated
        T->>S: target = value (Tween only)
        T->>T: start = raf.now() + delay
        T->>L: schedule callback, capture task + promise
        T-->>C: task.promise (completion)
        loop every animation frame(now)
            alt now < start
                Note over L: still delaying — keep task alive
            else first frame past start
                T->>I: interpolate(current, value)
                I-->>T: fn(t)
                T->>T: resolve duration(from, to) if it is a function
                T->>L: previous_task.abort()
            end
            alt elapsed > duration
                T->>S: current = value (settle)
                L-->>C: fulfill task promise
            else in flight
                T->>S: current = fn(easing(elapsed / duration))
            end
        end
    end
```

Expressed as a state machine, a tween instance moves through:

```mermaid
stateDiagram-v2
    [*] --> Idle : new Tween(value) / tweened(value)
    Idle --> Delaying : set(v) — start = now + delay
    Delaying --> Animating : first frame with now >= start<br/>(interpolator built, fn duration resolved, prev task aborted)
    Delaying --> Delaying : newer set(v2) schedules another task
    Animating --> Animating : per frame — current = fn(easing(elapsed/duration))
    Animating --> Animating : set(v2) → previous task aborted at next start
    Animating --> Settled : elapsed > duration — current = target
    Delaying --> Settled : duration === 0 — instant snap
    Settled --> Idle : promise fulfilled
    Settled --> Delaying : set(v3)
```

**Subtle timing detail worth knowing when debugging:** the *previous* task is aborted lazily — only when the new animation actually starts (after its own delay). A rapid `set(a); set(b);` within one frame therefore never renders an intermediate value from `a`, because `a`'s task is removed before it produces a frame.

---

## Options contract: `TweenedOptions<T>` (`private.d.ts`)

| Option | Type | Default | Notes |
| --- | --- | --- | --- |
| `delay` | `number` | `0` | Milliseconds before the animation begins; frames before `start` keep the task alive. |
| `duration` | `number \| (from: T, to: T) => number` | `400` | A function duration is resolved **once, on the first animated frame**, with the interpolated pair — useful for distance-based timing. |
| `easing` | `(t: number) => number` | `linear` | Any function from the [transitions_and_animations](transitions_and_animations.md) easing catalogue (or custom). Applied to normalized elapsed time before interpolation. |
| `interpolate` | `(a: T, b: T) => (t: number) => T` | `get_interpolator` | Full replacement point for the interpolation engine. |

Per-call options in `set(value, opts)` / `update(updater, opts)` are merged over the defaults given at construction (`{ ...defaults, ...opts }`), and each `set` re-resolves the merged options, so per-call overrides never mutate the stored defaults.

---

## Runtime integration

The module leans on four runtime facilities, each documented in its own module:

1. **Frame scheduling — `loop(callback)` ([client_runtime_core](client_runtime_core.md))**
   Registers a task in `raf.tasks`; if this is the first task, arms a `raf.tick`. The returned handle exposes:
   - `promise` — fulfilled only when the callback returns `false` (completion). **An aborted task's promise never settles** — this is deliberate: callers that `await` an interrupted `set()` simply wait until a *newer* tween completes or forever, without spurious rejections.
   - `abort()` — removes the task from the pending set (used for interruption and the `duration === 0` fast path).

2. **Time source — `raf` (`internal/client/timing.js`)**
   `raf.now()` → `performance.now()` in the browser, `Date.now()` otherwise; `raf.tick` defers the `requestAnimationFrame` reference so the code is testable without a DOM and bundles away cleanly outside the browser. This is why the module degrades safely in SSR contexts (animations simply never fire frames).

3. **Signals vs stores.** The legacy `tweened()` writes through `store.set` → classic subscriber queue ([stores](stores.md)); the `Tween` class writes `#current`/`#target` via `set(source, value)` from the signal system and reads via `get()`, so reading `tween.current` inside any `$derived`/`$effect`/template expression creates a **fine-grained reactive dependency that updates ~60×/s** during the animation. `Tween.of()` additionally uses `render_effect` to re-target whenever the source expression changes.

4. **Dev-mode instrumentation — `tag()` ([client_dev_mode](client_dev_mode.md))**
   Under `DEV` (via `esm-env`), both signals get stable labels (`Tween.current`, `Tween.target`) and their (possibly proxied) values are tagged for the Svelte devtools and ownership/tracing tooling. This is compiled out of production builds.

---

## Position in the overall system

```mermaid
flowchart LR
    APP["User components<br/>bind:value={tween.target}<br/>$derived from tween.current"]

    subgraph SYS["svelte package"]
        subgraph MOTION["Motion & Visual Effects System"]
            MT["motion_tweened<br/>(this module)"]
            MS["motion_spring<br/>(same API shape, physics-based)"]
            E["transitions_and_animations<br/>(easing catalogue)"]
            PM["prefersReducedMotion<br/>(reactive_builtin_classes MediaQuery)"]
        end
        subgraph STORESM["Reactive State Primitives & Store Interop"]
            WR["writable / Readable contract"]
        end
        subgraph RT["Reactive Runtime Engine"]
            SIG["signals: state / set / get / render_effect"]
            TASK["loop + raf timing"]
            DEVM["client_dev_mode: tag"]
        end
        subgraph CMP["Compiler Front-End / Back-End"]
            BIND["client transform:<br/>BindDirective / AssignmentExpression"]
        end
    end

    APP -->|"imports Tween / tweened from 'svelte/motion'"| MT
    MT --> WR
    MT --> SIG
    MT --> TASK
    MT -.-> DEVM
    MT ---|"sibling, shared pattern"| MS
    MT -.->|"easing option"| E
    MT -.->|"respect reduced motion"| PM
    BIND -.->|"target = v compiles to setter call"| MT
```

- **Upstream (what it consumes):** [stores](stores.md) (`writable`), [client_runtime_core](client_runtime_core.md) (`state`, `set`, `get`, `render_effect`, `loop`, `raf`), [client_dev_mode](client_dev_mode.md) (`tag`), and optionally the easing catalogue from [transitions_and_animations](transitions_and_animations.md).
- **Downstream (what consumes it):** application code via the `svelte/motion` entry (`packages/svelte/src/motion/index.js`, re-exported through `public.d.ts`). The compiler back-end does not generate tween calls itself, but compiled assignments/bindings to `tween.target` route through the class accessor, and `Tween.of()`'s `render_effect` participates in the component's effect graph created by the [compiler_client_transform](compiler_client_transform.md).
- **Sibling parity:** `Tween.of` / `spring.target` / completion promises mirror [motion_spring](motion_spring.md) exactly — the two modules are intentionally drop-in interchangeable in the `target`/`current` idiom; only the motion profile differs (fixed-duration easing curve vs. physical spring settling).

---

## Design notes, gotchas & maintenance guidance

1. **Prefer `Tween` over `tweened()`.** The store factory is kept only for backwards compatibility; new features land on the class. The `Tweened` interface is retained so legacy code and the class can coexist in the same codebase during migration.
2. **Interrupted animations never reject.** `loop.abort()` silently drops the task; callers `await`-ing a superseded `set()` will not observe completion. Code needing "did it finish?" semantics should race against its own timer or check `tween.current === tween.target`.
3. **Clock-based, not frame-count-based.** Progress is `easing(elapsed / duration)` with wall-clock elapsed time, so slow frames produce larger per-frame deltas — the animation always takes exactly `duration` ms (plus `delay`).
4. **The `interpolate` + `duration(fn)` pairing is computed lazily** on the first animated frame, using the *actual* start value — important when several `set` calls race during the delay window: the interpolator always reflects the value that was current when the animation began.
5. **Structural interpolation allocates per frame** (fresh arrays/objects each `t`). For hot paths with large nested structures, supply a custom `interpolate` that writes into a reusable buffer.
6. **Non-numeric leaves snap, strings never blend.** If char-by-char text morphing is needed, implement it via the `interpolate` option.
7. **SSR / no-DOM safety.** `raf.tick` becomes a no-op outside the browser and `raf.now` falls back to `Date.now()`, so importing the module server-side is harmless — frames just never run. Animations belong to client code paths.
8. **Treeshakeability.** The `DEV` guard around `tag()` and the deferred `requestAnimationFrame` reference keep production bundles free of dev instrumentation; the module has no top-level side effects beyond `prefersReducedMotion` construction (which lives in `motion/index.js`, not here).
9. **Legacy `tweened()` quirk:** `update` reads `target_value` (the last *requested* target), not the animated current — rapid `update` chains compound from the target, which is usually the desired behaviour for incremental adjustments.

---

## Related documentation

- [Motion & Visual Effects System](Motion___Visual_Effects_System.md) — parent module: spring, transitions, animations, easing.
- [motion_spring](motion_spring.md) — sibling primitive with the same `target`/`current` API and physics-based motion.
- [transitions_and_animations](transitions_and_animations.md) — easing functions (`linear`, `cubicOut`, …) usable as the `easing` option.
- [stores](stores.md) — `writable`/`Readable` model backing the legacy `tweened()` store ([Reactive State Primitives & Store Interop](Reactive_State_Primitives___Store_Interop.md)).
- [client_runtime_core](client_runtime_core.md) — signal sources (`state`/`set`), `loop`, `raf`, `get`, `render_effect` ([Reactive Runtime Engine](Reactive_Runtime_Engine_(Signals,_Effects___Batching_with_Dev-Mode_Instrumentation).md)).
- [client_dev_mode](client_dev_mode.md) — `tag()` tracing/devtools instrumentation.
- [reactive_builtin_classes](reactive_builtin_classes.md) — `MediaQuery`, used by `prefersReducedMotion` in the `svelte/motion` entry.
- [compiler_client_transform](compiler_client_transform.md) — how assignments/bindings in templates compile into the setter calls this module exposes.
