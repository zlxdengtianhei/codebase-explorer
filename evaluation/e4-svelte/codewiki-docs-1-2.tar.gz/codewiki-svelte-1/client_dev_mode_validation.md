# Client Dev Mode Validation (`client_dev_mode_validation`)

> **Module path:** `packages/svelte/src/internal/client/dev/{assign,equality,ownership,validation,legacy}.js`
> **Family:** Reactive Runtime Engine → [client_dev_mode](client_dev_mode.md) → `client_dev_mode_validation`

## 1. Introduction

`client_dev_mode_validation` is a **dev-only instrumentation layer** that sits between the code the Svelte compiler generates and the reactive runtime. When a component is compiled with `dev: true`, the client transform rewrites certain expressions (assignments, comparisons, component API usage, snippet calls) into guarded equivalents exported from this module. These guards:

1. **Detect common Svelte 5 foot-guns at runtime** — stale assignment results, proxy/raw-value identity confusion, illegal cross-component state mutation, interrupted binding chains, and misuse of the legacy Svelte 4 component API.
2. **Preserve production semantics** — guarded operations return exactly what the original JavaScript expression would return. Validation never changes program behavior; it only reports (warn) or aborts with a precise error (throw).
3. **Cost nothing in production** — every call site only exists in `dev: true` output; a production build contains none of this code.

The module is one of four dev-mode sub-modules (siblings: [client_dev_mode_hmr](client_dev_mode_hmr.md), [client_dev_mode_debugging](client_dev_mode_debugging.md), [client_dev_mode_locations](client_dev_mode_locations.md)) and consumes services from [client_runtime_core](client_runtime_core.md).

### Guard inventory

| File | Export | Hook | Behaviour on violation |
|---|---|---|---|
| `assign.js` | `assign`, `assign_and`, `assign_or`, `assign_nullish` | `=`, `&&=`, `\|\|=`, `??=` on reactive members | ⚠️ warn `assignment_value_stale` |
| `equality.js` | `equals`, `strict_equals` | `==`, `!=`, `===`, `!==` | ⚠️ warn `state_proxy_equality_mismatch` |
| `equality.js` | `init_array_prototype_warnings` | `indexOf` / `lastIndexOf` / `includes` on arrays | ⚠️ warn `state_proxy_equality_mismatch` |
| `ownership.js` | `create_ownership_validator` | prop mutations & `bind:` forwarding | ⚠️ warn `ownership_invalid_mutation` / `ownership_invalid_binding` |
| `validation.js` | `validate_snippet_args` | snippet function prologue | ❌ throw `invalid_snippet_arguments` |
| `legacy.js` | `check_target`, `legacy_api` | `new Component()`, `$set`/`$on`/`$destroy` | ❌ throw `component_api_invalid_new` / `component_api_changed` |

---

## 2. Architecture

```mermaid
flowchart TB
    SRC["Author .svelte source"] --> CT

    subgraph CTX["Compile time"]
        CT["Client transform (dev: true)<br/>compiler_client_transform_state_and_reactivity<br/>rewrites expressions into guarded calls"]
    end

    CT -- "$.assign* / $.equals / $.strict_equals /<br/>$.validate_snippet_args / $.check_target" --> DEV

    subgraph DEV["client_dev_mode_validation"]
        ASSIGN["assign.js<br/>assign · assign_and · assign_or · assign_nullish"]
        EQ["equality.js<br/>equals · strict_equals<br/>init_array_prototype_warnings"]
        OWN["ownership.js<br/>create_ownership_validator"]
        VAL["validation.js<br/>validate_snippet_args"]
        LEG["legacy.js<br/>check_target · legacy_api"]
    end

    subgraph RT["client_runtime_core services"]
        RUNTIME["runtime.js · untrack"]
        PROXY["proxy.js · get_proxied_value"]
        CONTEXT["context.js · component_context"]
        CONST["constants · STATE_SYMBOL, LEGACY_PROPS, FILENAME"]
        UTILS["internal/utils · sanitize_location"]
        SHARED["shared/utils · get_descriptor"]
    end

    subgraph DIAG["Diagnostics"]
        WARN["client/warnings.js<br/>assignment_value_stale<br/>state_proxy_equality_mismatch<br/>ownership_invalid_mutation<br/>ownership_invalid_binding"]
        ERR["client/errors.js + shared/errors.js<br/>component_api_invalid_new<br/>component_api_changed<br/>invalid_snippet_arguments"]
    end

    ASSIGN --> RUNTIME & UTILS & WARN
    EQ --> PROXY & WARN
    OWN --> CONTEXT & CONST & SHARED & UTILS & WARN
    VAL --> ERR
    LEG --> CONTEXT & CONST & ERR
```

The module is intentionally **thin**: it holds no state of its own (the validator instance aside) and delegates detection primitives (`untrack`, `get_proxied_value`, `STATE_SYMBOL`, `component_context`) to the reactive core, and reporting to the central warnings/errors registries shared with [client_runtime_core](client_runtime_core.md).

---

## 3. Component Reference

### 3.1 Assignment validation — `assign.js`

The compiler rewrites assignments to reactive member expressions, e.g. inside a `$derived` context or on a prop, so the *value of the assignment expression* may diverge from the *value actually stored*. The four wrappers each mirror one assignment operator:

| Export | Mirrors |
|---|---|
| `assign(object, property, value, location)` | `object[property] = value` |
| `assign_and(...)` | `object[property] &&= value` |
| `assign_or(...)` | `object[property] ||= value` |
| `assign_nullish(...)` | `object[property] ??= value` |

**Algorithm (identical for all four):**

```mermaid
flowchart TD
    A["$.assign(object, property, value, location)"] --> B["Perform real assignment<br/>object[property] = value"]
    B --> C["untrack(() => object[property])<br/>read result WITHOUT registering<br/>reactive dependencies"]
    C --> D{"assigned value !==<br/>untracked current value?"}
    D -- "yes" --> E["w.assignment_value_stale(property,<br/>sanitize_location(location))"]
    D -- "no" --> F
    E --> F["Return assignment result<br/>(RHS semantics preserved)"]
```

Key details:

- `untrack` (from [client_runtime_core](client_runtime_core.md)) ensures the verification read does not create reactive dependencies inside the assignment's own expression context.
- The location string (`App.svelte:5:8`) is injected by the compiler and sanitized via `sanitize_location` before being embedded in the warning.
- The inner `compare` helper is unexported; it encapsulates the mismatch check.

> Generated code example: `count = value` in dev mode becomes
> `count = $.assign(/** @type {any} */ (object), "count", value, "App.svelte:5:8")`.

### 3.2 Equality validation — `equality.js`

`$state(...)` wraps objects/arrays in proxies, so a proxy and its raw target have **different identities**. Comparing them (or searching for one inside the other's array) silently fails — this is one of the most common Svelte 5 migration bugs.

**`strict_equals(a, b, equal = true)`** — guards `===` / `!==`:

- Compares raw identity (`a === b`) against proxy-aware identity (`get_proxied_value(a) === get_proxied_value(b)`).
- If they disagree → warn `state_proxy_equality_mismatch('===' | '!==')`.
- **Returns** `(a === b) === equal` — i.e., the genuine JavaScript result; the `equal` flag inverts for `!==` usage.

**`equals(a, b, equal = true)`** — same contract for loose `==` / `!=`.

A `try/catch` around the comparison in `strict_equals` tolerates host objects that forbid property inspection (e.g. cross-origin `iframe.contentWindow`), where the proxy check itself may throw — behavior must never regress because of validation.

**`init_array_prototype_warnings()`** — patches `Array.prototype.indexOf`, `lastIndexOf` and `includes`. When the native method reports "not found" but a scan with `get_proxied_value` finds the item, it warns `state_proxy_equality_mismatch('array.indexOf(...)')` etc. Idempotency is guaranteed by an `Array.__svelte_cleanup` marker which restores the originals before re-patching — necessary because the REPL re-runs this on every evaluation and stacked patches would degrade performance over time.

### 3.3 Ownership validation — `ownership.js`

`create_ownership_validator(props)` returns a validator used by the generated code of the component that owns `props`. It answers two questions about component-boundary discipline:

```mermaid
flowchart TD
    A["mutation(prop, path, result, line, column)"] --> B{"is_bound_or_unset(props, path[0])?"}
    B -- "yes → prop is a bind: or entry prop" --> PASS["Allow — return result unchanged"]
    B -- "no" --> C{"Parent component exists?"}
    C -- "no" --> PASS
    C -- "yes" --> D{"Every intermediate value along path<br/>is proxied $state<br/>(carries STATE_SYMBOL)?"}
    D -- "no → not parent-owned state" --> PASS
    D -- "yes" --> E["warn ownership_invalid_mutation<br/>(name, child file:line:col, prop, parent file)"]
    E --> PASS
```

**`mutation(prop, path, result, line, column)`** — fired when compiled code assigns into a prop-derived value. Walking the `path` proves whether the mutation target chain is owned by the *parent's* `$state`. Violations mean the child is reaching into parent state that was passed by value; the warning suggests `bind:${prop}` or a callback. The component's own `FILENAME` plus `line`/`column` are turned into a location string via `sanitize_location`.

**`binding(key, child_component, value)`** — fired when this component forwards `bind:` to a child. If the prop itself is *not* bound here (no setter on its descriptor), a parent exists, and the forwarded value is proxied state, the **binding chain is interrupted**: warn `ownership_invalid_binding`, telling the developer to create the missing `bind:` between grandparent and parent.

**`is_bound_or_unset(props, prop_name)`** — the allow-list predicate. A prop is considered legal to mutate when:

- its property descriptor has a `set` (the runtime creates setters for `bind:`-bound props), **or**
- `props` is an entry-point props object (`STATE_SYMBOL in props` or `LEGACY_PROPS in props` — e.g. `mount(Component, props)` / `createClassComponent` with `$state` props), **or**
- the prop doesn't exist on `props` at all (local addition).

### 3.4 Snippet argument validation — `validation.js`

`validate_snippet_args(anchor, ...args)` is emitted as the first statement of every generated snippet function in dev mode. It asserts that:

- `anchor` is a DOM `Node` (snippets are rendered at an anchor created by the template runtime), and
- every forwarded argument is a function (snippets are just functions).

Otherwise it throws `invalid_snippet_arguments` ("Snippets should only be instantiated via `{@render ...}`"). Unlike the ownership/equality/assignment guards this is a **hard error**, because a snippet invoked with garbage arguments cannot meaningfully run.

The SSR mirror lives in `internal/server/dev.js` (see [server_runtime](server_runtime.md)) and validates a `Payload`/`HeadPayload` instead of an anchor node — same error, different first argument.

### 3.5 Legacy API guards — `legacy.js`

Runes-mode components no longer support the Svelte 4 class-instance API. These guards turn silent breakage into actionable errors:

- **`check_target(target)`** — called when code attempts `new SomeComponent()`. If `target` is provided, throws `component_api_invalid_new` including the component's file (via `FILENAME`) and name, and points to `compatibility.componentApi: '4'` for third-party code that cannot be migrated.
- **`legacy_api()`** — returns `{ $destroy, $on, $set }`, each a stub that throws `component_api_changed(method, component[FILENAME])`. The generated dev-mode component instance carries these properties so that any legacy method call fails fast with the component's source file in the message.

Both read the current component from `component_context` (see [client_runtime_core](client_runtime_core.md)); the `FILENAME` symbol on the component function is attached by the compiler.

---

## 4. Compiler ↔ Runtime Process Flow

```mermaid
sequenceDiagram
    autonumber
    participant Src as Svelte source
    participant Tr as Client transform (dev: true)
    participant Rt as Generated component code
    participant DV as dev modules (this package)
    participant Dg as warnings.js / errors.js

    Src->>Tr: object.count = value / a === b / new Comp() / {@render ...}
    Tr->>Rt: rewrites into $.assign(...), $.strict_equals(...), $.check_target(...), $.validate_snippet_args(...)

    Note over Rt: application runs in dev mode
    Rt->>DV: invoke guard
    DV->>DV: perform real operation + comparison logic
    alt soft violation (stale assignment / proxy equality / ownership)
        DV->>Dg: warn code (verbose, dev-formatted)
        Dg-->>Rt: console.warn — execution continues
    else hard violation (snippet args / legacy API)
        DV->>Dg: throw Svelte error with https://svelte.dev/e/... link
        Dg-->>Rt: Error thrown
    end
    DV-->>Rt: original operation's return value (soft paths)
```

Production builds (`dev: false`) emit none of these calls; the warnings/errors registries even collapse to one-line URL-only messages when reached, but the module itself is tree-shaken out of bundles (see the treeshakeability checks in the repository tooling).

---

## 5. Dependencies

### Internal (consumed)

| Dependency | Source module | Used by |
|---|---|---|
| `untrack` | `internal/client/runtime.js` → [client_runtime_core](client_runtime_core.md) | `assign*` |
| `get_proxied_value` | `internal/client/proxy.js` → [client_runtime_core](client_runtime_core.md) | `equals`, `strict_equals`, array patches |
| `component_context` | `internal/client/context.js` → [client_runtime_core](client_runtime_core.md) | ownership validator, legacy API |
| `STATE_SYMBOL`, `LEGACY_PROPS`, `FILENAME` | client/shared constants | ownership validator, legacy API |
| `sanitize_location` | `internal/utils.js` | `assign*`, ownership warnings |
| `get_descriptor` | `internal/shared/utils.js` | `is_bound_or_unset` |
| warnings: `assignment_value_stale`, `state_proxy_equality_mismatch`, `ownership_invalid_mutation`, `ownership_invalid_binding` | `internal/client/warnings.js` | soft-violation reporting |
| errors: `invalid_snippet_arguments` (shared), `component_api_invalid_new`, `component_api_changed` (client) | `internal/shared/errors.js`, `internal/client/errors.js` | hard-violation reporting |

### Reverse dependencies (who calls this module)

| Caller | Purpose |
|---|---|
| Client codegen: `AssignmentExpression` / `build_assignment` + `validate_mutation` | emits `$.assign*` and wires `ownership_validator.mutation` — see [compiler_client_transform_state_and_reactivity](compiler_client_transform_state_and_reactivity.md) |
| Client codegen: `BinaryExpression` visitor | emits `$.equals` / `$.strict_equals` in dev mode |
| Client codegen: snippet blocks, `Component`/class component output | emits `$.validate_snippet_args`, `$.check_target`, `legacy_api()` |
| `internal/server/dev.js` | SSR counterpart of `validate_snippet_args` — see [server_runtime](server_runtime.md) |

---

## 6. Position in the System

```mermaid
flowchart LR
    subgraph FE["Compiler front-end"]
        P["parse"] --> A["analyze"] --> T["transform"]
    end
    subgraph DEVM["client_dev_mode family"]
        HMR["hmr"] --- DBG["debugging"] --- LOC["locations"] --- THIS["**validation** (this module)"]
    end
    T -- "dev: true → emits guarded calls" --> THIS
    THIS --> CORE["client_runtime_core<br/>signals · proxies · context"]
    THIS --> DOM["client_dom_renderer<br/>(validated operations run here)"]
    THIS -. "SSR mirror of snippet validation" .-> SSR["server_runtime · dev.js"]
```

- **Upstream:** the compiler front-end ([Compiler Front-End](compiler_front-end_parsing_analysis_css_scoping_pipeline.md)) produces the AST; the back-end client transform decides *whether* to emit validation code (only under `dev: true`) and *what* location strings to embed.
- **Downstream:** the guards operate on the live signal graph of [client_runtime_core](client_runtime_core.md) and the DOM operations of [client_dom_renderer](client_dom_renderer.md); they never mutate that state themselves.
- **Counterpart:** server rendering validates the equivalent SSR invariants in `internal/server/dev.js` — see [server_runtime](server_runtime.md).

## 7. Maintenance Notes

- **Never change return values.** All `equals`/`assign` variants must return exactly what the unguarded expression would, otherwise dev and prod builds diverge.
- **Idempotency matters** for `init_array_prototype_warnings` (REPL re-execution) — keep the `Array.__svelte_cleanup` restore path.
- **Ownership allow-list is intentionally permissive** (`is_bound_or_unset`): it's a lint-time-style nudge at runtime, not a security boundary.
- Warning/error text lives centrally in `internal/client/{warnings,errors}.js` and is generated from message templates (`scripts/process-messages`) — do not inline strings here.
- Related validation that lives *outside* this module: `validate_binding`, `validate_each_keys` (runtime core), `validate_dynamic_element_tag` (shared) — see their module docs before extending.