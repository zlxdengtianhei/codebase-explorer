# stores_interop

> **Module scope:** `packages/svelte/src/store/index-client.js`, `packages/svelte/src/store/index-server.js`
> **Public entry:** exported as `toStore` / `fromStore` from `svelte/store`

## 1. Introduction

`stores_interop` is the **bidirectional bridge between Svelte's legacy store contract and the Svelte 5 runes reactivity system**. It lives at the bottom of the `stores` module family (see [stores](stores.md)) and implements two conversion functions, each shipped in a client and a server variant:

| Function | Direction | Signature | Result |
| --- | --- | --- | --- |
| `toStore(get, set?)` | runes → store | getter + optional setter | `Readable<V>` / `Writable<V>` |
| `fromStore(store)` | store → runes | any store | `{ current: V }` (writable if the store is) |

**Why this module exists.** Svelte 4 reactivity is expressed through the *store contract* — an object with a `subscribe(run)` method (see the `Writable` contract in [stores_contract](stores_contract.md)). Svelte 5 reactivity is expressed through signals, effects and `$state`/`$derived` runes (see [client_runtime_core_signal_model](client_runtime_core_signal_model.md)). Ecosystems, libraries and codebases span both worlds, so this module provides the canonical adapters:

- `toStore` wraps a **reactive getter** (any runes-tracked expression) so it can be consumed by store-based APIs — including third-party libraries that expect `subscribe`.
- `fromStore` wraps a **store** so it can be read/written as a plain object with a reactive `current` property, usable anywhere runes-state is usable (templates, `$derived`, `$effect`).

## 2. Architecture Overview

The module consists of two runtime-specific entry files with identical public shapes. The client file additionally hooks into the signal/effect runtime; the server file is a minimal, SSR-correct implementation with no reactive bookkeeping.

```mermaid
flowchart TB
    subgraph INTEROP["stores_interop (this module)"]
        IC["store/index-client.js<br/>toStore · fromStore"]
        IS["store/index-server.js<br/>toStore · fromStore"]
    end

    subgraph CORE["stores_core"]
        W["writable(value, start)"]
        G["get(store)"]
    end

    subgraph CONTRACT["stores_contract"]
        T["Readable / Writable<br/>store-contract types"]
    end

    subgraph EFFECTS["client_runtime_core_effects"]
        ER["effect_root"]
        RE["render_effect"]
        ET["effect_tracking"]
    end

    subgraph RT["client_runtime_core_runtime"]
        AE["active_effect / set_active_effect"]
        AR["active_reaction / set_active_reaction"]
    end

    subgraph RBC["reactive_builtin_classes"]
        CS["createSubscriber(start)"]
    end

    BUNDLER{{"bundler resolves<br/>'svelte/store' per runtime"}}

    BUNDLER --> IC
    BUNDLER --> IS

    IC -- "creates stores" --> W
    IC -- "one-shot reads" --> G
    IC -- "lazy subscription driver" --> CS
    IC -- "ownership capture" --> AE
    IC -- "ownership capture" --> AR
    CS -- "starts/stops" --> RE
    CS -- "reactivity guard" --> ET
    IC -- "bridges writes through" --> RE
    RE --> ER
    IS -- "creates stores" --> W
    IS -- "one-shot reads" --> G
    INTEROP -. "typed against" .-> T
```

Both files also **re-export** the shared store factory API (`derived`, `get`, `readable`, `readonly`, `writable`) from [stores_core](stores_core.md), so `svelte/store` consumers get a complete, tree-shakeable surface from whichever entry their platform selects.

## 3. Component Reference

### 3.1 `toStore` — runes → store

```ts
// overloads (both runtimes)
function toStore<V>(get: () => V): Readable<V>;
function toStore<V>(get: () => V, set: (v: V) => void): Writable<V>;
```

Creates a store whose value is derived from a getter function. When the getter reads reactive state, the store automatically tracks it. Supplying a `set` function promotes the result to a full `Writable` whose `set`/`update` write through to the underlying state.

**Returned shapes** (mirroring the contract in [stores_contract](stores_contract.md)):

| `set` provided | Returned object |
| --- | --- |
| yes | `{ set, update: (fn) => set(fn(get())), subscribe }` |
| no  | `{ subscribe }` |

### 3.2 `fromStore` — store → runes

```ts
// overloads (both runtimes)
function fromStore<V>(store: Writable<V>): { current: V };
function fromStore<V>(store: Readable<V>): { readonly current: V };
```

Wraps a store in an object exposing a reactive `current` property:

- **Reading** `current` inside a reactive context registers a dependency; changes propagate to effects/deriveds like ordinary `$state` reads.
- **Writing** `current` (writable overload) delegates to `store.set(v)`.
- TypeScript picks the readonly overload for `Readable` stores via the `'set' in store` structural check at runtime, matching the overloads.

### 3.3 Re-exports

Both entries re-export `derived`, `get`, `readable`, `readonly`, `writable` from `store/shared/index.js`. Their behavior is documented in [stores_core](stores_core.md); they are listed here only because they form part of this module's public surface.

## 4. Client Runtime Behavior (`index-client.js`)

The client file is the reactive implementation. Its two functions solve two different integration problems.

### 4.1 `toStore` — reactive pull-to-push adapter

```mermaid
sequenceDiagram
    autonumber
    participant C as Component context
    participant TS as toStore(get, set?)
    participant WS as writable (stores_core)
    participant FX as render_effect
    participant ST as $state source

    C->>TS: toStore(get, set?)
    Note over TS: captures active_effect + active_reaction<br/>(ownership = calling context)
    TS->>WS: writable(get(), start)
    Note over WS: value = get() snapshot<br/>(not yet subscribed)

    C->>TS: store.subscribe(run)
    TS->>WS: subscribers 0 → 1, start(set) fires
    WS->>FX: effect_root(() => render_effect(...))
    FX->>ST: const value = get()  // tracks deps
    ST-->>FX: state changes
    FX-->>WS: set(value)
    WS-->>C: run(value)
```

Implementation details that matter for maintainers:

1. **Ownership capture.** `toStore` records the `active_effect` and `active_reaction` *at call time* and re-installs them (`set_active_effect` / `set_active_reaction`) inside the store's `start` notifier, restoring the previous values in a `finally` block. This is essential: the store's start notifier is invoked later, from an arbitrary `subscribe()` call, where the ambient reaction context would be wrong. The tracking scope therefore belongs to the component that *created* the store, not the one that first subscribed.

2. **Drift detection (`ran` flag).** Between `writable(init_value, …)` construction and the first `subscribe()`, the underlying state may already have changed. `ran = init_value !== get()` detects this and treats the captured value as already applied; the render effect then pushes the fresh value on its first run instead of suppressing it as a no-op.

3. **Teardown.** The `start` notifier returns `effect_root`'s teardown. [stores_core](stores_core.md)'s `writable` calls it when the subscriber count drops to zero, destroying the render effect and releasing all tracked dependencies. This makes `toStore` subscriptions fully lazy and leak-free.

4. **Write path is unreactive by design.** `set` is the user's function; `update` composes `get()` + `set`. No signal machinery is involved in writes — state updates flow back through the ordinary runes system and are observed by the render effect like any other state change.

### 4.2 `fromStore` — store-to-signal lazy adapter

`fromStore` must answer: *"when do we subscribe to the store?"* Subscribing eagerly would break unmount semantics and tree-shaking of unused subscriptions; the answer is **lazily, only while some reactive effect is actually reading `current`**.

```mermaid
flowchart TD
    A["read .current"] --> B{"effect_tracking()?"}
    B -- "yes: inside effect / derived / template" --> C["subscribe() from createSubscriber"]
    C --> D["increment version signal →<br/>registers reactive dependency"]
    D --> E["return cached value"]
    B -- "no: plain JS read / SSR-like context" --> F["get(store)<br/>one-shot subscribe-and-unsubscribe"]
    F --> G["return fresh value<br/>(non-reactive snapshot)"]
```

The reactive branch is driven by `createSubscriber` (defined in `reactivity/create-subscriber.js`, part of [reactive_builtin_classes](reactive_builtin_classes.md)), which manages a reference-counted subscription lifecycle:

```mermaid
stateDiagram-v2
    [*] --> Unsubscribed

    Unsubscribed --> Subscribed : first read of `.current`<br/>inside a reactive effect (count 0→1)<br/>start: store.subscribe(update)
    Subscribed --> Subscribed : store.set(v)<br/>→ update() bumps version signal<br/>→ dependent effects re-run
    Subscribed --> Pending : last reading effect is destroyed
    Pending --> Pending : microtask queued<br/>(count decrement deferred)
    Pending --> Subscribed : new read before microtask runs<br/>(old subscription reused — no churn)
    Pending --> Unsubscribed : microtask fires, count is 0<br/>→ unsubscribe + version bump

    Unsubscribed --> [*]
```

Why the microtask deferral (visible in `createSubscriber`) matters: if an effect teardown and a fresh render run within the same tick (the normal HMR / keyed-block case), decrementing eagerly would hit zero momentarily, causing an unnecessary unsubscribe/resubscribe cycle — and a leak, because the stale teardown of the prior subscription would then run after the new one started. Deferring the count makes the transition idempotent. The version-signal bumps on both *update* and *resubscribe* guarantee dependent deriveds are correctly marked dirty in both directions (see write-version comparison in the deriveds engine, [client_runtime_core_deriveds](client_runtime_core_deriveds.md)).

**Write path.** For a `Writable` store, the returned object pairs the reactive getter with a plain setter — `set current(v) { store.set(v) }` — so assignment syntax (`count.current += 1`) propagates through the store contract to all existing store subscribers, whether they came from `fromStore`, `$store` auto-subscriptions ([client_runtime_core_stores](client_runtime_core_stores.md)), or third-party code.

### 4.3 Round-trip behavior

Because each adapter builds on the store contract (or on tracked getters, which `toStore` itself lowers *into* the contract), the two compose:

```js
import { fromStore, toStore } from 'svelte/store';

let count = $state(0);

const store   = toStore(() => count, (v) => (count = v)); // runes → store
const wrapper = fromStore(store);                          // store → runes

wrapper.current;      // 0 — reactively tracked
store.set(1);
wrapper.current;      // 1
wrapper.current += 1; // 2 — writes through to `count`
```

## 5. Server Runtime Behavior (`index-server.js`)

SSR renders once, synchronously; there is no effect graph, so the server variants deliberately drop all reactivity machinery:

| Aspect | Client | Server |
| --- | --- | --- |
| `toStore` initial value | reactive snapshot wired via `render_effect` on first subscribe | `writable(get())` — plain one-time snapshot |
| `toStore` reactivity | getter tracked; store pushes on change | none — value never updates after creation |
| `toStore` `set`/`update` | delegate to user setter (writes flow back into runes state) | identical delegation; writes are still correct, they just don't re-render |
| `fromStore` read | `effect_tracking()` ? lazy subscription : `get(store)` | always `get(store)` — correct because output is generated eagerly |
| `fromStore` write | `store.set(v)` | `store.set(v)` (identical) |
| Effect context capture | `active_effect`/`active_reaction` captured & restored | not applicable |

This split follows the repository-wide client/server entry convention used across the internal layer (compare `index-client.js` / `index-server.js` in [public_api_client_entry](public_api_client_entry.md) and the server renderer in [server_runtime_rendering_core](server_runtime_rendering_core.md)). A bundler/condition-map selects the right file, so application code imports `'svelte/store'` without runtime branching.

## 6. Data Flow Summary

End-to-end picture of both adapters on the client, from creation through update to teardown:

```mermaid
flowchart LR
    subgraph Creation
        direction TB
        U["$state / $derived state"] -->|toStore(get, set)| W1["writable + start notifier"]
        S1["legacy store"] -->|fromStore| OBJ["{ current } wrapper"]
    end

    subgraph Consumption
        direction TB
        T["template / $effect / $derived"] -- "reads .current" --> OBJ
        C1["consumer code"] -- "store.subscribe(run)" --> W1
        C2["third-party store library"] -- "subscribe" --> OBJ2["toStore output"]
    end

    subgraph Propagation
        direction TB
        U2["state change"] --> RE["render_effect (in start notifier)"]
        RE -->|set| W1 -->|subscriber_queue| C1
        S2["store.set(v)"] --> CS["createSubscriber version bump"] --> OBJ --> T
        S2 -->|other subscribers| OS["external store subscribers"]
    end

    subgraph Teardown
        direction TB
        C1 -. "unsubscribe (last)" .-> TD1["stop() → effect_root teardown"]
        T -. "effect destroyed" .-> TD2["microtask → count 0 → unsubscribe"]
    end
```

Key invariant: **the store contract (`subscribe`/`set`) is always the meeting point.** `toStore` lowers runes reactivity *into* the contract; `fromStore` lifts the contract *into* signal reactivity. Neither adapter couples consumers to the other system directly.

## 7. Relationship to Other Modules

| Related module | Relationship |
| --- | --- |
| [stores_core](stores_core.md) | Provides the `writable` engine (subscriber sets, `start`/`stop` notifiers, `subscriber_queue` batching) and `get` that both interop files build upon. `fromStore`'s non-reactive fallback path is literally `get(store)`. |
| [stores_contract](stores_contract.md) | `Readable`/`Writable` interfaces that define the overload shapes of `toStore`/`fromStore` and the `'set' in store` discriminant. |
| [client_runtime_core_effects](client_runtime_core_effects.md) | `effect_root` / `render_effect` power `toStore`'s tracking; `effect_tracking` decides `fromStore`'s reactive vs. one-shot read. |
| [client_runtime_core_runtime](client_runtime_core_runtime.md) | `active_effect` / `active_reaction` (and their setters) implement `toStore`'s ownership capture. |
| [client_runtime_core_signal_model](client_runtime_core_signal_model.md) | The signal semantics (`source`, dirty checking, equality) that make the `current` getter reactive; `equality.js` governs `safe_not_equal`-style push decisions upstream in `writable`. |
| [client_runtime_core_deriveds](client_runtime_core_deriveds.md) | Downstream consumer of `fromStore`'s `current` reads; write-version comparison is why `createSubscriber` bumps its version signal on resubscribe. |
| [client_runtime_core_stores](client_runtime_core_stores.md) | The *compile-time* `$store` auto-subscription path (`store_get`, `store_unsub`, …). Legacy `$store` syntax and the `fromStore` API solve the same problem from different directions — runtime codegen vs. explicit adapter — and interoperate freely on the same store objects. |
| [reactive_builtin_classes](reactive_builtin_classes.md) | Supplies `createSubscriber`; `SvelteMap`, `MediaQuery`, etc. use the same lazy-subscription primitive, keeping store-interop and built-in reactive classes behaviorally consistent. |
| [public_api_client_entry](public_api_client_entry.md) / public server entry | `svelte/store` is resolved by export conditions to this module's files; the adapters are part of the stable public surface documented for end users. |
| [legacy_compat_client](legacy_compat_client.md) | Legacy class components (`createClassComponent`) rely on store-contract reactivity; `toStore` is the sanctioned way to feed runes state into such consumers. |
| [stores](stores.md) | Parent module; see it for the overall store-family layout and for `writable`/`derived` end-user semantics. |

## 8. Design Notes & Invariants

- **Laziness everywhere.** `toStore` performs no tracking until someone subscribes; `fromStore` performs no subscribing until `current` is read inside a tracked context. Unobserved adapters cost (almost) nothing.
- **Correct ownership.** Effects created by a store's start notifier are attributed to the *creating* context, not the subscribing one — this prevents cross-component dependency pollution and wrong cleanup order.
- **Single notification path.** `writable`'s `subscriber_queue` (see [stores_core](stores_core.md)) deduplicates and batches notifications, so `set` inside a render effect never re-enters synchronously.
- **RxJS tolerance lives downstream.** `subscribe_to_store` (used by `get`) normalizes observables exposing `.unsubscribe`; interop functions inherit that tolerance through `get` and through any store they wrap.
- **SSR purity.** The server file imports nothing from `internal/client`, keeping server bundles free of DOM/effect code and tree-shakeable (see `check-treeshakeability` in [svelte_build_tooling](svelte_build_tooling.md)).
- **No deprecation trap.** Unlike `$store` auto-subscription (legacy syntax), `toStore`/`fromStore` are first-class runes-era APIs — safe to recommend in migrations handled by [compiler_migrate](compiler_migrate.md) tooling.

## 9. Usage Patterns

```svelte
<script>
  import { fromStore, toStore } from 'svelte/store';

  // 1. Use any store in runes-land
  const user = fromStore(userStore);        // user.current is reactive
  $effect(() => console.log(user.current));

  // 2. Expose runes state to store consumers
  let theme = $state('dark');
  const themeStore = toStore(() => theme, (v) => (theme = v));
  // pass themeStore to legacy code / store-based libraries

  // 3. Read-only projection (Readable overload → readonly .current)
  const count = fromStore(counterStore);    // count.current is settable
</script>

<p>{user.current.name}</p>
<button onclick={() => (count.current += 1)}>inc</button>
```

For the underlying store factories and combinators (`writable`, `derived`, `get`, …), see [stores_core](stores_core.md); for the `Writable`/`Readable` type definitions, see [stores_contract](stores_contract.md).
