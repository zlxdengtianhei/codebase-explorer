# Reactive Built-in Classes (`svelte/reactivity`)

## 1. Purpose & Overview

The **`reactive_builtin_classes`** module implements Svelte's reactive replacements for standard JavaScript built-ins, exposed to users through the `svelte/reactivity` entry point:

| Class / Export | Wraps | Source File | Strategy |
| --- | --- | --- | --- |
| `SvelteDate` | `Date` | `src/reactivity/date.js` | Single `#time` signal + lazily memoized `derived` per getter method |
| `SvelteMap` | `Map` | `src/reactivity/map.js` | Per-key `Source` signals + collection-level `#version` / `#size` signals |
| `SvelteURL` | `URL` | `src/reactivity/url.js` | Accessor-pair getters/setters over per-part signals |
| `SvelteURLSearchParams` | `URLSearchParams` | `src/reactivity/url-search-params.js` | Single `#version` counter; bidirectional sync with a parent `SvelteURL` |
| `MediaQuery` | `MediaQueryList` (via `window.matchMedia`) | `src/reactivity/media-query.js` | Extends `ReactiveValue<boolean>` with lazy external-event subscription |
| `MediaQuery` / `createSubscriber` (server) | — | `src/reactivity/index-server.js` | SSR stubs: native aliases + inert placeholders |

**Why it exists.** Svelte 5's runes ($state, $derived, $effect) work on plain values, but the built-in classes (`Date`, `Map`, `URL`, …) keep their data in internal slots that the reactivity engine cannot observe. This module subclasses each built-in and re-routes its read methods through **signal reads** (`get`) and its mutation methods through **signal writes** (`set` / `increment`). The result is a drop-in API: `new SvelteMap()` can replace `new Map()` anywhere, and any effect or derived that reads it automatically re-runs when it changes.

The module is a sibling of [`stores`](stores.md) (the classic store contract) in the *Reactive State Primitives & Store Interop* layer, and it is built directly on top of the signal engine from the [Reactive Runtime Engine](client_runtime_core.md) module.

## 2. Architecture

### 2.1 Position in the system

```mermaid
flowchart TB
    subgraph Public["Public API Surface"]
        ENTRY["svelte/reactivity<br/>(index-client.js / index-server.js)"]
    end

    subgraph MOD["reactive_builtin_classes (this module)"]
        MAP["SvelteMap"]
        DATE["SvelteDate"]
        URLC["SvelteURL"]
        PARAMS["SvelteURLSearchParams"]
        MQ["MediaQuery"]
        RV["ReactiveValue (base, reactivity/reactive-value.js)"]
        CS["createSubscriber (create-subscriber.js)"]
        MQ --> RV --> CS
    end

    subgraph RUNTIME["Reactive Runtime Engine (internal/client)"]
        SOURCES["reactivity/sources.js<br/>state · source · set · increment"]
        CORE["runtime.js<br/>get · active_reaction · set_active_reaction · update_version"]
        DERIVED["client/index.js<br/>derived"]
        TRACE["dev/tracing.js<br/>tag · label (DEV only)"]
    end

    subgraph SSR["Server Build"]
        STUBS["index-server.js<br/>native aliases · inert MediaQuery · no-op createSubscriber"]
    end

    ENTRY --> MAP & DATE & URLC & PARAMS & MQ
    MAP & DATE & URLC & PARAMS --> SOURCES & CORE & DERIVED
    MAP & DATE & URLC & PARAMS --> TRACE
    MQ -->|"on(q, 'change', …)"| EVENTS["dom/elements/events.js (on)"]
    ENTRY -.->|"server build"| STUBS
```

On the **client**, `index-client.js` re-exports the real implementations. On the **server**, `index-server.js` substitutes inert counterparts so application code can import `svelte/reactivity` unconditionally — SSR renders once, so interactivity-driven reactivity has no meaning there. Full details of both the client `MediaQuery`/`ReactiveValue` machinery and these server stubs live in [reactive_builtin_classes_environment_and_ssr.md](reactive_builtin_classes_environment_and_ssr.md).

### 2.2 Class hierarchy and internal signal graph

```mermaid
classDiagram
    class Date
    class Map
    class URL
    class URLSearchParams
    class ReactiveValue {
        -#fn
        -#subscribe
        +get current()
    }

    Date <|-- SvelteDate
    Map <|-- SvelteMap
    URL <|-- SvelteURL
    URLSearchParams <|-- SvelteURLSearchParams
    ReactiveValue <|-- MediaQuery

    class SvelteDate {
        -#time : Source~number~
        -#deriveds : Map~method, Derived~
        -#reaction
    }
    class SvelteMap {
        -#sources : Map~K, Source~number~~
        -#version : Source~number~
        -#size : Source~number~
    }
    class SvelteURL {
        -#protocol / #hostname / #pathname …: Source
        -#searchParams : SvelteURLSearchParams
    }
    class SvelteURLSearchParams {
        -#version : Source~number~
        -#url : SvelteURL
    }
    class MediaQuery {
        +current : boolean
    }

    SvelteURL *-- SvelteURLSearchParams : searchParams
    SvelteDate o-- SvelteDate : #deriveds (lazy, per method)
```

Two implementation families emerge:

1. **Signal-wrapping subclasses** (`SvelteDate`, `SvelteMap`, `SvelteURL`, `SvelteURLSearchParams`) hold private `Source` signals created via `state()`/`source()` from `internal/client/reactivity/sources.js`, and intercept methods/properties to call `get()` on reads and `set()`/`increment()` on writes.
2. **`ReactiveValue`-based classes** (`MediaQuery`) delegate to a `(fn, onsubscribe)` pair; subscription to the *external* world (DOM events) is lazy and reference-counted via `createSubscriber`, so no event listener exists until an effect actually reads `.current`.

### 2.3 Reactive data flow

**Read path** (dependency registration):

```mermaid
sequenceDiagram
    autonumber
    participant E as Effect / Derived (active_reaction)
    participant C as Reactive class method<br/>(e.g. SvelteMap.get)
    participant S as Signal<br/>(Source / Derived)
    participant R as Runtime

    E->>R: executes
    C->>S: get(this.#version) / get(per-key source)
    S->>R: link signal → active_reaction
    R-->>E: return current value
    Note over E,S: Reading an absent Map key tracks #version only,<br/>so a later set(key, …) still invalidates the reader
```

**Write path** (invalidation & re-execution):

```mermaid
sequenceDiagram
    autonumber
    participant U as User code
    participant C as Reactive class method<br/>(e.g. SvelteMap.set)
    participant S as Signals
    participant B as Batcher / Scheduler

    U->>C: mutation call
    C->>C: apply native mutation (super.*)
    C->>S: set(source, v) or increment(version)
    S->>B: mark dependent reactions dirty
    B->>B: schedule & deduplicate work
    B-->>U: effects re-run after flush (tick)
```

`increment` is simply `set(source, source.v + 1)` — a version counter that always looks "changed", which is the correct semantics for collections where individual entries cannot be cheaply diffed (e.g. `SvelteMap` iteration, `SvelteURLSearchParams` reads).

## 3. Sub-modules

The module splits into three coherent sub-modules, each documented in detail:

| Sub-module | Documentation | Components | Focus |
| --- | --- | --- | --- |
| Collections | [reactive_builtin_classes_collections.md](reactive_builtin_classes_collections.md) | `SvelteMap` | Per-key source graphs, version-counter invalidation, `−1` deletion sentinel, minimal-invalidation logic in `set()` |
| Temporal & URL primitives | [reactive_builtin_classes_temporal_url_primitives.md](reactive_builtin_classes_temporal_url_primitives.md) | `SvelteDate`, `SvelteURL`, `SvelteURLSearchParams` | Prototype patching with lazy deriveds, accessor-pair decomposition, parent↔child URL sync via the internal `REPLACE` symbol |
| Environment values & SSR layer | [reactive_builtin_classes_environment_and_ssr.md](reactive_builtin_classes_environment_and_ssr.md) | `MediaQuery` (client + server), `createSubscriber` (server stub) | `ReactiveValue` pattern, lazy event subscription, server aliases and no-ops |

> The sibling `SvelteSet` (`src/reactivity/set.js`) is not part of this module's component set; it follows the same architecture as `SvelteMap` and is re-exported by the same entry point.

## 4. Cross-Cutting Design Patterns

The four signal-wrapping classes share a toolkit of techniques worth knowing when maintaining or extending the module:

### 4.1 Read/write symmetry
Every observable read routes through `get(signal)` (registering a dependency on the current `active_reaction`), and every mutation routes through `set()` or `increment()`. There is no magic proxying — interception is done by **overriding methods** (`SvelteMap`, `SvelteDate`, `SvelteURLSearchParams`) or by **accessor property pairs** (`SvelteURL`).

### 4.2 Version counters for "unknown granularity" reads
Reads that cannot be attributed to a single entry (iteration, `keys()`, `has()` on a missing key, `toString()`) track a coarse `#version` signal. Writes that change the *shape* of the collection bump this version; writes that only change a *known entry* try to avoid bumping it (see 4.4).

### 4.3 Lazy per-instance memoization (SvelteDate)
`SvelteDate` patches its **prototype once** (module-level `inited` guard), yet per-method `derived` signals are created **per instance**, on first parameterless read. Crucially, each derived is created under the instance's *construction reaction* (`set_active_reaction(this.#reaction)`), so ownership is attributed to creation time rather than to whichever effect happened to read first — preventing the derived from becoming a leaked dependency of an arbitrary reader.

### 4.4 Minimal invalidation (SvelteMap.set)
When an existing key's value changes, `SvelteMap` bumps the per-key source, then bumps `#version` **only if** the version's reaction set does not already subsume the key source's reactions. Collection-wide readers get invalidated either way; key-only readers are spared the broader update.

### 4.5 Cycle-proof bidirectional sync (SvelteURL ↔ SvelteURLSearchParams)
`SvelteURL` records itself as the module-level `current_url` while constructing its child `SvelteURLSearchParams`, so the child can push changes *up* (`#update_url`). Updates flowing *down* (via `href`/`search` setters) use the internal `[REPLACE]` symbol, which suppresses the upward propagation with an `#updating` flag — no infinite loops.

### 4.6 Deletion sentinels & no-op suppression
- `SvelteMap` signals deletion by setting a key's source to `-1` (any reader that stored the previous value sees a change), and `clear()` short-circuits when already empty.
- `SvelteURLSearchParams` compares `getAll(name).join('')` before/after `set`/`delete` so genuinely unchanged data does not trigger invalidation.

### 4.7 DEV-only instrumentation
Every internal signal is wrapped in `tag(…, 'SvelteLabel')` (and `label(key)` for map keys) under the `esm-env` `DEV` flag. This powers `$inspect`, tracing, and DevTools affordances with zero production cost. Deep-dive: [client_dev_mode.md](client_dev_mode.md).

## 5. Usage Sketch

```svelte
<script>
        import { SvelteMap, SvelteDate, MediaQuery } from 'svelte/reactivity';

        const board = new SvelteMap();                 // entries reactively read via .get/.has/iteration
        const last = new SvelteDate();                 // formatted reads re-run when .setTime is called
        const large = new MediaQuery('min-width: 800px'); // .current tracks matchMedia 'change'
</script>

<p>{large.current ? 'large' : 'small'} — {board.size} cells — {last.toLocaleTimeString()}</p>
```

Effects/derivatives reading these objects register the private signals as dependencies; mutations invalidate exactly those readers.

## 6. Server-side Rendering (SSR) Behavior

`src/reactivity/index-server.js` keeps the import surface identical across builds:

- `SvelteDate`, `SvelteSet`, `SvelteMap`, `SvelteURL`, `SvelteURLSearchParams` are **aliased to the natives** — SSR output is produced in a single pass, so mutation-driven invalidation is meaningless.
- `MediaQuery` becomes a plain holder (`current` = `matches ?? false`) because the server cannot evaluate media queries; document this hydration caveat in user-facing guidance (the client class docstring does).
- `createSubscriber` returns a no-op function, keeping `ReactiveValue` importable.

This mirrors the pattern used elsewhere in the codebase (e.g. the client/server split in the [Component Rendering Backends](client_dom_renderer.md) and [stores](stores.md) modules).

## 7. Related Modules

- [Reactive Runtime Engine](client_runtime_core.md) — the signal model (`state`, `source`, `set`, `increment`, `get`, `derived`, batching) that this module is written against.
- [Reactive State Primitives & Store Interop](stores.md) — the `writable`/`derived`/`get` store contract and `fromStore`/`toStore` bridges; the classic alternative to these classes.
- [Public API Surface](public_api.md) — where `svelte/reactivity` is wired into the package exports.
- [Dev-mode Instrumentation](client_dev_mode.md) — `tag`/`label` tracing used by this module's DEV branches.
