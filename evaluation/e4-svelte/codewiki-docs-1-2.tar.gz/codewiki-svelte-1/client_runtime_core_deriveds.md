# client_runtime_core_deriveds

> **Module path:** `packages/svelte/src/internal/client/reactivity/deriveds.js`
> **Parent system:** [Reactive Runtime Engine (Signals, Effects & Batching with Dev-Mode Instrumentation)](reactive_runtime_engine_signals_effects_batching_with_dev-mode_instrumentation.md)

---

## 1. Introduction

`client_runtime_core_deriveds` implements **derived signals** — the lazily-evaluated, memoized reactive values that underpin Svelte 5's `$derived` and `$derived.by` runes, as well as the asynchronous `$derived(await …)` form. A derived signal recomputes its value only when one of its tracked dependencies has changed, caching the result until the next invalidation.

This module sits at the heart of the client-side reactivity engine: it bridges the low-level [signal model](client_runtime_core_signal_model.md) (flags, write versions, dependency links), the [generic runtime scheduler](client_runtime_core_runtime.md), [sources](client_runtime_core_sources.md), [effects](client_runtime_core_effects.md), and the [batching system](client_runtime_core_batching.md).

**Key design properties**

| Property | How it is achieved |
|---|---|
| **Lazy evaluation** | A derived never recomputes on write; it is re-evaluated only when its value is *read* through the runtime's dirty-checking (`update_derived` → `execute_derived` → `update_reaction`) |
| **Memoization** | A freshly computed value is stored (`v`) together with a write version (`wv`); equality (`equals`) suppresses downstream propagation when the value is unchanged |
| **Automatic dependency tracking** | Evaluation runs inside `update_reaction`, which records every signal read as a dependency (`deps`) |
| **Ownership scoping** | Deriveds created inside an effect are owned by that effect (`EFFECT_PRESERVED`); free-floating deriveds get the `UNOWNED` flag |
| **Batch-awareness** | Computed values inside a batch are staged in `batch_deriveds` and committed only on batch commit |
| **Async support** | `async_derived` resolves to a `Promise<Source>` and cooperates with boundaries/batches for suspensible async rendering |

---

## 2. Module Purpose within the System

The Svelte client runtime is organized as a graph of three node kinds:

1. **Sources** ([client_runtime_core_sources](client_runtime_core_sources.md)) — writable state (`$state`), invalidated on write.
2. **Deriveds** (this module) — computed, cached nodes (`$derived`).
3. **Effects** ([client_runtime_core_effects](client_runtime_core_effects.md)) — side-effecting reactions (DOM updates, `$effect`, templates).

When a source is written, it marks its dependent reactions `DIRTY`/`MAYBE_DIRTY`; when a derived is subsequently read, this module re-executes it, and—if the value actually changed—propagates the invalidation downstream. Because templates and effects also run through the same reaction protocol, a derived update is what ultimately triggers a targeted DOM update.

Related runtime features implemented on top of this module elsewhere:

- **Props with default expressions** and `rest_props` spreads create deriveds internally (see [client_runtime_core_props](client_runtime_core_props.md)).
- **Store interop** (`store_get`) wraps store values and derives reactivity from them (see [client_runtime_core_stores](client_runtime_core_stores.md)).
- **Async blocks** (`{@await …}`) consume the `Promise<Source>` returned by `async_derived` (see [client_runtime_core_async](client_runtime_core_async.md) and the [client DOM renderer](client_dom_renderer.md)).

---

## 3. Core Components (API Reference)

### 3.1 `derived(fn)` — low-level factory *(internal)*

```js
/** @returns {Derived<V>} */
function derived(fn)
```

Allocates the `Derived` signal object and computes its initial ownership flags:

- Starts with flags `DERIVED | DIRTY` (marked dirty so the first read evaluates it).
- **Parent resolution:** if the current `active_reaction` is itself a derived, that becomes `parent` (a derived chain); otherwise the `parent` is the `active_effect`.
- **`UNOWNED` flag:** applied when there is no active effect, *or* when the parent derived is itself unowned. Unowned deriveds are "read-time" computations (e.g. inside `untrack`-style helpers or template expressions evaluated outside an effect tree) and are never cached across reads.
- **`EFFECT_PRESERVED` flag:** because deriveds evaluate *lazily*, any effects created *inside* a derived's expression would be created too late to be attached to the effect tree. Setting this flag on the parent effect guarantees the parent is never pruned while its subtree is needed.
- Records `ctx` (component context) so evaluation restores the correct component context, `equals` (reference equality by default), and an `ac` slot used by async deriveds.
- **Dev + tracing mode:** attaches `signal.created = get_stack('CreatedAt')` for the [$inspect.trace] / ownership debugger.

### 3.2 `user_derived(fn)` — `$derived` rune entry point

```js
/*#__NO_SIDE_EFFECTS__*/
function user_derived(fn) {
  const d = derived(fn);
  push_reaction_value(d);
  return d;
}
```

The compiler lowers every user-facing `$derived …` / `$derived.by(…)` to a call to `user_derived`. It is a thin wrapper that additionally calls `push_reaction_value` (which snapshots the initial value and hooks dev-mode ownership/tracing for the *user-visible* derived, as opposed to internal ones the runtime creates for its own bookkeeping). The `#__NO_SIDE_EFFECTS__` annotation lets the production build tree-shake derivation wrappers that are never read.

### 3.3 `async_derived(fn, location)` — async deriveds (`$derived(await …)`)

```js
/*#__NO_SIDE_EFFECTS__*/
function async_derived(fn, location): Promise<Source<V>>
```

Implements deriveds whose expressions `await`. Instead of returning a signal, it returns a **promise of a source signal** that resolves once the first value is available:

1. **Orphan check:** requires an `active_effect`; throws `async_derived_orphan` otherwise. The effect's `Boundary` (`parent.b`) is captured for suspension counting.
2. Creates an ordinary `source()` seeded with `UNINITIALIZED`.
3. Spawns an `async_effect` which:
   - Calls `fn()`; every signal read on the returned promise (`.then` access) is tracked as a dependency.
   - Chains promises via `prev?.then(r, r)` so **only the latest computation ever writes** — stale results are silently discarded.
   - **Suspension:** on first run (`should_suspend = !active_reaction`), increments the boundary's pending count and the current batch counter, so SSR/hydration/`<svelte:boundary>` can show pending UI.
   - **Error handling:** on rejection (other than the internal `STALE_REACTION` sentinel) sets the `ERROR_VALUE` flag on the signal and writes the error into it, surfacing it to the nearest boundary.
   - **Dev waterfall warning:** if `location` is provided and the value is not read immediately after update, warns `await_waterfall` (uses the module-level `recent_async_deriveds` set with a `setTimeout` sweep).
   - **Batch neutering:** if the effect re-runs, it schedules `batch.neuter()` via `queueMicrotask`, so a superseded batch does not commit half-finished async state.
4. Returns a promise resolved by the `next`/`go` loop described in §4.3.
5. **Dev only:** flags the source with `ASYNC` so `$inspect.trace()` can print it like a derived.

`set_from_async_derived` / `current_async_effect` track, in dev mode, which async effect is currently producing a value (used for better error attribution).

### 3.4 `derived_safe_equal(fn)`

Same as `derived`, but swaps in `safe_equals`, which delegates to `safe_not_equal` semantics — required where values may be proxies or non-plain objects and reference equality would produce false negatives/positives. Used by internal runtime machinery (e.g. store wrappers), not by the `$derived` rune itself.

### 3.5 `execute_derived(derived)` — evaluate once

1. Resolves the nearest non-derived ancestor effect via `get_derived_parent_effect` (walking up through derived chains) and makes it the `active_effect` — so nested effects land in the right place in the effect tree.
2. **Dev:** pushes the derived onto a module-level `stack` of currently-updating deriveds to detect self-reference (`e.derived_references_self()` — a nicer message than "too much recursion"); also isolates `inspect_effects` during evaluation.
3. Destroys any previous derived's transient effects (`destroy_derived_effects`) and re-runs the function through `update_reaction(derived)`, which swaps in dependency tracking and returns the new value.
4. Restores the previous `active_effect` (and inspect set) in a `finally`.

### 3.6 `update_derived(derived)` — evaluate + memoize

The standard re-evaluation entry point invoked by the runtime when a dirty derived is read:

1. `value = execute_derived(derived)`.
2. If `!derived.equals(value)`, writes `derived.v = value` and bumps `derived.wv = increment_write_version()` (write-version bump is what downstream reactions use to detect change even when object identity would differ).
3. **Cleanup guard:** if currently `is_destroying_effect`, the derived is *not* marked clean — reading a derived inside a cleanup function must not cache a stale value.
4. **Commit:**
   - Inside a batch (`batch_deriveds !== null`): stage the value in the `batch_deriveds` map; the actual status flip happens at batch commit (see [client_runtime_core_batching](client_runtime_core_batching.md)).
   - Otherwise: set status to `CLEAN`, *except* unowned or skipped deriveds with dependencies, which stay `MAYBE_DIRTY` so they are re-checked on every read.

### 3.7 `destroy_derived_effects(derived)`

Destroys (via `destroy_effect`) every effect captured in `derived.effects`. Deriveds spawn effects in two cases: nested `async_effect`s from async derived expressions, and the effect-preservation bookkeeping described in §3.1. Called both before re-execution and during teardown.

---

## 4. Architecture and Data Flow

### 4.1 Component architecture

```mermaid
flowchart TB
    subgraph deriveds["deriveds.js (this module)"]
        UD[user_derived<br/>$derived rune entry]
        D[derived<br/>signal factory]
        ASD[async_derived<br/>Promise&lt;Source&gt;]
        DSE[derived_safe_equal]
        ED[execute_derived]
        UPD[update_derived]
        DDE[destroy_derived_effects]
        GO["go / next<br/>(async promise chain)"]
    end

    subgraph runtime_mod["runtime.js — see client_runtime_core_runtime"]
        AR[active_reaction]
        AE[active_effect]
        UR[update_reaction]
        SSS[set_signal_status]
        IWV[increment_write_version]
        PRV[push_reaction_value]
        SAE[set_active_effect]
        IDE[is_destroying_effect]
    end

    subgraph sources_mod["sources.js — see client_runtime_core_sources"]
        SRC[source]
        IS[internal_set]
        IE[inspect_effects]
    end

    subgraph effects_mod["effects.js — see client_runtime_core_effects"]
        AEFF[async_effect]
        DEFF[destroy_effect]
    end

    subgraph batch_mod["batch.js — see client_runtime_core_batching"]
        CB[current_batch]
        BD[batch_deriveds]
    end

    subgraph other["supporting modules"]
        EQ[equality.js<br/>equals / safe_equals]
        TY[types.d.ts<br/>Signal / Derived]
        BND[Boundary<br/>dom/blocks/boundary.js]
        CTX[context.js<br/>component_context]
        ERR[errors.js / warnings.js<br/>client_runtime_core_diagnostics]
        FLG[flags/index.js<br/>DEV / tracing_mode_flag]
        TRC[dev/tracing.js<br/>get_stack]
    end

    UD --> D
    DSE --> D
    D --> ED
    ASD --> GO
    ASD --> SRC
    ASD --> AEFF
    ASD --> CB
    ASD --> BND
    UPD --> ED
    UPD --> DDE
    UPD --> EQ
    UPD --> IWV
    UPD --> BD
    UPD --> SSS
    ED --> UR
    ED --> SAE
    ED --> DDE
    DDE --> DEFF
    D --> AR
    D --> AE
    ED --> IDE
    ED --> IE
    UD --> PRV
    GO --> IS
    D --> CTX
    D --> FLG
    D --> TRC
    ASD --> ERR

    style deriveds fill:#e8f0fe,stroke:#4285f4
```

### 4.2 The `Derived` node in the signal model

A `Derived` extends the base `Signal` contract (`f` flags bitmask, `wv` write version — see [client_runtime_core_signal_model](client_runtime_core_signal_model.md)) with graph linkage and cache fields:

```mermaid
classDiagram
    class Signal {
        <<interface>>
        +number f        % flags bitmask
        +number wv       % write version
    }
    class Derived {
        +fn              % computation
        +v               % cached value
        +equals          % equality fn
        +deps            % upstream signals
        +reactions       % downstream reactions
        +effects         % nested effects to destroy
        +parent          % Derived or Effect
        +ctx             % component context
        +ac              % async bookkeeping
        +rv              % read version
    }
    class Effect {
        +f
        +wv
        +b               % Boundary
    }
    Signal <|-- Derived : extends
    Derived --> Signal : deps (reads)
    Signal --> Derived : reactions (dependents)
    Derived --> Effect : parent (non-derived ancestor)
```

**Flag lifecycle of a derived:**

```mermaid
stateDiagram-v2
    [*] --> DIRTY: derived(fn) creates<br/>DERIVED | DIRTY
    DIRTY --> CLEAN: read → update_derived,<br/>value unchanged or equal
    DIRTY --> MAYBE_DIRTY: unowned / skipped reaction<br/>stays re-checkable
    CLEAN --> DIRTY: dependency write_version > wv<br/>(lazy invalidation on read)
    MAYBE_DIRTY --> CLEAN: re-check shows value equal
    MAYBE_DIRTY --> DIRTY: re-check shows value changed
    note right of CLEAN
        In a batch, values are staged in
        batch_deriveds instead of being
        marked CLEAN immediately
    end note
```

### 4.3 Synchronous derived evaluation flow

The runtime's `get()` / `check_dirtiness()` machinery calls `update_derived` whenever a read encounters a derived that is (maybe) dirty:

```mermaid
sequenceDiagram
    participant R as Runtime (get/check_dirtiness)
    participant UPD as update_derived
    participant ED as execute_derived
    participant UR as update_reaction (runtime)
    participant FN as fn() — user expression
    participant EQ as equals
    participant B as batch_deriveds (batch)

    R->>UPD: update_derived(d)
    UPD->>ED: execute_derived(d)
    ED->>ED: set_active_effect(nearest non-derived parent)
    Note over ED: DEV: push stack, guard<br/>derived_references_self
    ED->>ED: destroy_derived_effects(d)
    ED->>UR: update_reaction(d)
    UR->>FN: run with dependency tracking
    FN-->>UR: value (deps recorded)
    UR-->>ED: value
    ED-->>UPD: value
    UPD->>EQ: equals(value)
    alt value changed
        UPD->>UPD: d.v = value<br/>d.wv = increment_write_version()
    end
    alt inside batch
        UPD->>B: batch_deriveds.set(d, d.v)
    else no batch
        UPD->>UPD: set_signal_status(d, CLEAN or MAYBE_DIRTY)
    end
    UPD-->>R: done (cached value readable)
```

Because evaluation is lazy, writes to upstream sources only flip flags; the actual recomputation (and thus downstream propagation) is deferred until the value is next read or until an effect flush demands it.

### 4.4 Async derived flow (`async_derived`)

`async_derived` does not evaluate lazily in the classic sense — it wires an effect that produces promises and writes results into a plain source:

```mermaid
sequenceDiagram
    participant C as Compiled $derived(await …)
    participant ASD as async_derived
    participant AE as async_effect
    participant FN as fn() (async expression)
    participant B as Boundary / Batch
    participant S as source signal
    participant GO as next/go chain

    C->>ASD: async_derived(fn, location)
    ASD->>S: source(UNINITIALIZED)
    ASD->>AE: async_effect(producer)
    AE->>FN: call (signals tracked via .then access)
    FN-->>AE: promise p
    AE->>AE: promise = prev.then(r, r) ?? resolve(p)
    AE->>B: boundary.update_pending_count(+1)<br/>batch.increment() (first run only)
    ASD->>GO: next(promise) — returned Promise<Source>

    loop each producer run (latest wins)
        AE->>S: internal_set(value) or ERROR_VALUE + error
        AE->>B: update_pending_count(-1), batch.decrement()
    end

    GO->>GO: go(): p === latest promise ?
    alt yes
        GO-->>C: fulfil(signal)
    else superseded
        GO->>GO: next(newest promise) — keep waiting
    end
```

Notable behaviours:

- **Chained promise:** `promise = prev?.then(r, r) ?? Promise.resolve(p)` guarantees results are applied strictly in issue order; a re-run before the previous settles re-links the chain, and the outer `next`/`go` loop only fulfils the caller's promise when it observes the *latest* promise resolve — otherwise it keeps deferring ("delay resolution until we have a value").
- **Suspension:** only async deriveds created during component initialisation suspend the boundary; re-runs during updates do not.
- **Neutered batches:** if the producer effect re-runs, `queueMicrotask(() => batch.neuter())` prevents the superseded batch from committing.
- **Waterfall detection (dev):** `recent_async_deriveds` + `location` enable the `await_waterfall` warning when a value is produced but not consumed immediately.

---

## 5. Dependency Graph (module level)

```mermaid
flowchart LR
    SIG["client_runtime_core_signal_model<br/>(Signal flags, equality)"] --> DER
    RUN["client_runtime_core_runtime<br/>(update_reaction, versions)"] --> DER["client_runtime_core_deriveds<br/>(this module)"]
    SRC["client_runtime_core_sources<br/>(source, internal_set)"] --> DER
    EFF["client_runtime_core_effects<br/>(async_effect, destroy_effect)"] --> DER
    BAT["client_runtime_core_batching<br/>(current_batch, batch_deriveds)"] --> DER
    DIA["client_runtime_core_diagnostics<br/>(errors, warnings)"] --> DER

    DER --> PRO["client_runtime_core_props<br/>(prop defaults use deriveds)"]
    DER --> STO["client_runtime_core_stores<br/>(store_get/derived_safe_equal)"]
    DER --> ASY["client_runtime_core_async<br/>(async blocks, unset_context)"]
    DER --> DOM["client_dom_renderer<br/>(Boundary, await_block)"]
    DER --> REN["render entrypoints<br/>(mount/hydrate flush)"]

    style DER fill:#e8f0fe,stroke:#4285f4,stroke-width:2px
```

Upstream: the module *consumes* the primitive reaction protocol from [runtime](client_runtime_core_runtime.md) and the flag/equality conventions from the [signal model](client_runtime_core_signal_model.md). Downstream: virtually every feature that computes values — [props](client_runtime_core_props.md), [stores](client_runtime_core_stores.md), [async rendering](client_runtime_core_async.md), and template effects in the [DOM renderer](client_dom_renderer.md) — is expressed through deriveds created here.

---

## 6. Integration Notes & Cross-Cutting Concerns

### 6.1 Ownership and effect trees

- **Owned deriveds** (created inside an effect): the parent effect is flagged `EFFECT_PRESERVED`, so lazily created inner effects are never lost, and the derived dies with its owner on unmount.
- **Unowned deriveds** (`UNOWNED`): evaluated on read, never guaranteed to be re-executed by the scheduler; used for computations outside a reactive owner. Combined with `skip_reaction`, they are left `MAYBE_DIRTY` after each update so reads keep re-checking them.

### 6.2 Batching semantics

Inside a batch (see [client_runtime_core_batching](client_runtime_core_batching.md)), `update_derived` routes freshly computed values into the `batch_deriveds` map rather than flipping the signal `CLEAN` immediately. This lets a batch compute a consistent snapshot and commit all status transitions atomically at flush, avoiding intermediate inconsistent renders.

### 6.3 Dev-mode instrumentation

| Mechanism | Purpose |
|---|---|
| `stack` + `derived_references_self` | Detects infinite recursion (`$derived` reading itself) with a readable error |
| `signal.created` (tracing flag) | Creation stack for `$inspect.trace` / ownership tooling (see `dev/tracing.js`) |
| `recent_async_deriveds` + `location` | `await_waterfall` warning for unconsumed async values |
| `ASYNC` flag on async sources | Lets `$inspect.trace` print async values as deriveds |
| `is_destroying_effect` guard | Prevents caching stale values read inside cleanup functions |

All diagnostics live in the sibling [client_runtime_core_diagnostics](client_runtime_core_diagnostics.md) module; this module only raises them.

### 6.4 Performance & tree-shaking

- All factories are annotated `/*#__NO_SIDE_EFFECTS__*/` so bundlers can drop deriveds that are never read (verified by `scripts/check-treeshakeability.js` — see [Svelte build tooling](svelte_build_tooling.md)).
- Reactivity benchmarks in `benchmarking/benchmarks/reactivity/` (kairo, sbench, mol_bench — see [reactivity_benchmarks](reactivity_benchmarks.md)) exercise derived-heavy graphs; `update_derived`'s equality short-circuit is the primary lever for diamond/triangle graph performance.

---

## 7. Related Documentation

| Module | Relationship |
|---|---|
| [client_runtime_core_signal_model](client_runtime_core_signal_model.md) | Flags (`DERIVED`, `DIRTY`, `MAYBE_DIRTY`, `CLEAN`, `UNOWNED`, …) and equality contracts consumed here |
| [client_runtime_core_runtime](client_runtime_core_runtime.md) | Reaction protocol: `update_reaction`, `set_signal_status`, `set_active_effect`, write-versioning, `tick` |
| [client_runtime_core_sources](client_runtime_core_sources.md) | `source`/`internal_set` used by async deriveds; source invalidation triggers derived re-checks |
| [client_runtime_core_effects](client_runtime_core_effects.md) | `async_effect`/`destroy_effect`; deriveds feed dirty flags into the effect flush |
| [client_runtime_core_batching](client_runtime_core_batching.md) | `current_batch`, `batch_deriveds`, batch commit/neuter interplay |
| [client_runtime_core_props](client_runtime_core_props.md) | Component props implemented with deriveds |
| [client_runtime_core_stores](client_runtime_core_stores.md) | Store interop uses `derived_safe_equal` semantics |
| [client_runtime_core_async](client_runtime_core_async.md) | Async context management (`unset_context`) and async block consumers |
| [client_runtime_core_diagnostics](client_runtime_core_diagnostics.md) | `errors.js` / `warnings.js` raised by this module |
| [client_dom_renderer](client_dom_renderer.md) | `Boundary` (suspension), `await_block` consumers of async deriveds |
| [reactive_runtime_engine_signals_effects_batching_with_dev-mode_instrumentation](reactive_runtime_engine_signals_effects_batching_with_dev-mode_instrumentation.md) | Parent engine overview |
