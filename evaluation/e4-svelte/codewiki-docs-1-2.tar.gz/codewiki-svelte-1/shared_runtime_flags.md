# shared_runtime_flags

> **Module**: `packages/svelte/src/internal/flags/index.js`
> **Parent area**: Cross-Runtime Platform Services (Shared Utilities, Flags & Context Injection)

`shared_runtime_flags` is the **global mode registry** of the Svelte runtime. It owns three process-wide, mutable boolean flags — `async_mode_flag`, `legacy_mode_flag`, and `tracing_mode_flag` — that switch the runtime between fundamentally different execution modes (runes/legacy, sync/async, untraced/traced). Because these flags must be readable *everywhere* in the runtime (reactivity core, context system, public API) but only ever flipped *once, at module-evaluation time*, the module exposes an intentionally tiny surface: mutable `let` bindings plus idempotent `enable_*` setter functions.

The flags are **never enabled by importing `index.js` directly from application code**. Instead, the Svelte compiler injects bare *side-effect activation modules* (`svelte/internal/flags/legacy`, `svelte/internal/flags/async`, `svelte/internal/flags/tracing`) into the JavaScript it generates for each component, based on the component's compile-time analysis. This guarantees that a mode is active before the first line of any affected component's code runs, while keeping the runtime tree-shakeable for apps that never use a given mode.

---

## At a Glance

| Aspect | Detail |
|---|---|
| Module file | `packages/svelte/src/internal/flags/index.js` |
| Companion activation modules | `flags/async.js`, `flags/legacy.js`, `flags/tracing.js` (same folder) |
| State | 3 mutable `let` exports, all default `false` |
| Mutation API | 4 one-way setter functions (3 "public" enables + 1 test-only disable) |
| Who enables them | The compiler, via side-effect imports emitted into generated component code |
| Who reads them | Client runtime core (`tick`), signal model (`source`, `mutable_source`), context system (`push`), public API (`onMount`), legacy compatibility layer (`Svelte4Component`), dev tracing |
| Scope | Per JavaScript realm/bundle — global to the entire application, not per component |

---

## Core Components

### Mutable state (the flags)

| Export | Type | Default | Meaning |
|---|---|---|---|
| `async_mode_flag` | `let boolean` | `false` | Async/reactivity-loss-tolerant mode (experimental `$await`-style rendering). Changes flushing semantics of `tick()` and enables the async effect machinery. |
| `legacy_mode_flag` | `let boolean` | `false` | Svelte 4 compatibility mode. Components compiled without runes run their lifecycle through the legacy `beforeUpdate`/`afterUpdate`/coarse-props machinery. |
| `tracing_mode_flag` | `let boolean` | `false` | Dev-only reactivity tracing. Signals record creation/update stack traces for the interactive reactivity debugger. |

All three are plain module-level `let` bindings. **Importers get live read-only bindings** — they can always observe the latest value, but only code inside `flags/index.js` may assign it.

### Mutation API (the setters)

| Export | Effect | Availability |
|---|---|---|
| `enable_async_mode_flag()` | `async_mode_flag = true` | Called by `flags/async.js` on import |
| `enable_legacy_mode_flag()` | `legacy_mode_flag = true` | Called by `flags/legacy.js` on import |
| `enable_tracing_mode_flag()` | `tracing_mode_flag = true` | Called by `flags/tracing.js` on import |
| `disable_async_mode_flag()` | `async_mode_flag = false` | **Test-only reset** (`/** ONLY USE THIS DURING TESTING */`) |

The setters are deliberately one-liners and are *idempotent* — calling them repeatedly is a no-op after the first call. There is no public "disable" for legacy or tracing; only the async flag can be reset, and exclusively so the test suite can isolate modules that were eagerly activated in the same process.

---

## Architecture

The module sits at the junction of the compiler (which decides *that* a flag must be enabled) and the runtime (which decides *what* the flag changes). The compiler back-end emits activation imports into generated client code; the side-effect modules perform the actual enable; the runtime core branches on the resulting state.

```mermaid
flowchart TB
    subgraph Compiler["Compiler Back-End — see compiler_client_transform"]
        OPT["Per-component analysis:<br/>• options.experimental.async<br/>• analysis.runes (runes vs legacy)<br/>• analysis.tracing"]
        GEN["Generated component module<br/>(client JS output)"]
        OPT -->|"decides which flags to activate"| GEN
    end

    subgraph Activation["Side-effect activation modules (internal/flags/)"]
        FASYNC["flags/async.js"]
        FLEGACY["flags/legacy.js"]
        FTRACE["flags/tracing.js"]
    end

    subgraph Flags["shared_runtime_flags — flags/index.js"]
        direction LR
        AF["async_mode_flag"]
        LF["legacy_mode_flag"]
        TF["tracing_mode_flag"]
        SET["enable_*_mode_flag()"]
    end

    GEN -- "import 'svelte/internal/flags/async'" --> FASYNC
    GEN -- "import 'svelte/internal/flags/legacy'" --> FLEGACY
    GEN -- "import 'svelte/internal/flags/tracing'" --> FTRACE

    FASYNC --> SET
    FLEGACY --> SET
    FTRACE --> SET
    SET --> AF
    SET --> LF
    SET --> TF

    subgraph Runtime["Reactive Runtime Engine — see client_runtime_core_*"]
        TICK["runtime.js :: tick()"]
        SRC["reactivity/sources.js ::<br/>source() / mutable_source()"]
        PUSH["context.js :: push()"]
        ONMOUNT["index-client.js :: onMount()"]
    end

    AF -- "frame-based flushing" --> TICK
    LF -- "legacy component context" --> PUSH
    LF -- "legacy lifecycle routing" --> ONMOUNT
    LF -- "bind signals to legacy ctx" --> SRC
    TF -- "trace metadata (DEV only)" --> SRC

    subgraph Legacy["Legacy Compatibility — see legacy_compat"]
        S4["legacy-client.js ::<br/>Svelte4Component"]
    end

    AF -- "skip flushSync()" --> S4
```

Note that `shared_runtime_flags` has **no runtime dependencies of its own** — it is a leaf module. All arrows above are unidirectional: dependents import the flags; the flags import nothing. This is essential because the reactivity core, context system, and public API all need the flags, and any cycle would break module-initialization order.

---

## Flag Lifecycle

### Phase 1 — Compile-time decision (compiler back-end)

During the transform phase, `client_component()` inspects the component analysis and unshifts bare import statements to the front of the generated module body:

```js
// compiler/phases/3-transform/client/transform-client.js (excerpt)
if (options.experimental.async) {
        body.unshift(b.imports([], 'svelte/internal/flags/async'));
}

if (!analysis.runes) {
        body.unshift(b.imports([], 'svelte/internal/flags/legacy'));
}

if (analysis.tracing) {
        body.unshift(b.imports([], 'svelte/internal/flags/tracing'));
}
```

Decision rules:

```mermaid
flowchart TD
    START["Compile a .svelte component"] --> Q1{"options.experimental.async ?"}
    Q1 -- yes --> E1["emit import 'svelte/internal/flags/async'"]
    Q1 -- no --> N1["no async activation"]
    START --> Q2{"component uses runes?<br/>(analysis.runes)"}
    Q2 -- no (legacy syntax) --> E2["emit import 'svelte/internal/flags/legacy'"]
    Q2 -- yes --> N2["no legacy activation"]
    START --> Q3{"component selected for tracing?<br/>(analysis.tracing)"}
    Q3 -- yes --> E3["emit import 'svelte/internal/flags/tracing'"]
    Q3 -- no --> N3["no tracing activation"]
```

Placing the imports at the **very front** of the module body is not cosmetic: ES module imports are hoisted and evaluated before the module body, so the flags are guaranteed to be `true` before the component function is ever defined, let alone called.

### Phase 2 — Import-time activation

```mermaid
sequenceDiagram
    autonumber
    participant App as Application / bundler
    participant Gen as Compiled Component.js
    participant Act as flags/legacy.js
    participant Flags as flags/index.js
    participant RT as Client runtime internals

    App->>Gen: import Component
    Note over Gen: imports hoisted & evaluated first
    Gen->>Act: import 'svelte/internal/flags/legacy'
    Act->>Flags: enable_legacy_mode_flag()
    Note over Flags: legacy_mode_flag = true
    Gen->>RT: import runtime helpers ($ namespace)
    Gen->>Gen: define & export component function
    App->>Gen: mount(Component, ...)
    RT->>Flags: read legacy_mode_flag / async_mode_flag at runtime
```

Each activation module is exactly two lines: import the setter, call it. This shape is what makes the compiler's job trivial — one bare import statement per required mode — and what allows bundlers to drop modes the app never uses (no import → no module → no activation).

### Phase 3 — Runtime consumption

After activation, every read of a flag reflects the mode for the *entire application*, because the flags are per-realm singletons. All reads in the runtime are conditional branches that pick between modern and legacy behavior (details below).

---

## Flag Semantics & Consumers

### `async_mode_flag`

| | |
|---|---|
| Enabled by | `import 'svelte/internal/flags/async'` — emitted when the component was compiled with `options.experimental.async` (see [compiler_core_options](compiler_core_options.md) for option validation) |
| Purpose | Opts the application into asynchronous component rendering, where top-level `await` inside components is allowed and rendering can pause/resume. |

Consumer branches:

- **`internal/client/runtime.js :: tick()`** — In async mode, `tick()` returns a promise resolved on the next animation frame (yielding to the scheduler instead of force-flushing synchronously). In sync mode it awaits a microtask and then calls `flushSync()`. (See [client_runtime_core_runtime](client_runtime_core_runtime.md).)
- **`src/legacy/legacy-client.js :: Svelte4Component`** — The Svelte-4 class-component wrapper skips its post-mount `flushSync()` when `async_mode_flag` is set, because a synchronous flush is invalid while async work is pending. (See [legacy_compat](legacy_compat.md).)
- **Async machinery** — The flag underpins the behavior of `async_body`, `save`, and reactivity-loss tracking in `reactivity/async.js` and the `boundary` block (see [client_runtime_core_async](client_runtime_core_async.md) and [client_dom_renderer_control_flow_blocks](client_dom_renderer_control_flow_blocks.md)).

### `legacy_mode_flag`

| | |
|---|---|
| Enabled by | `import 'svelte/internal/flags/legacy'` — emitted for any component compiled **without** runes (`!analysis.runes`) |
| Purpose | Lets Svelte 4-era components (option-based props, `beforeUpdate`/`afterUpdate`, reactive statements, coarse-grained props) run correctly on the Svelte 5 signal runtime. |

Consumer branches:

- **`internal/client/context.js :: push(props, runes)`** — A component's context frame gets its legacy annex `l: { s, u, $ }` **only when** `legacy_mode_flag && !runes`. This annex stores the signals that must fire legacy update callbacks, the callback registry, and legacy version counters.
- **`src/index-client.js :: onMount()`** — In legacy mode with a legacy component context, `onMount` callbacks are queued into `context.l.u.m` and orchestrated by the legacy machinery, rather than being implemented as a `$effect`. `beforeUpdate`/`afterUpdate` go through the same registry.
- **`internal/client/reactivity/sources.js :: mutable_source()`** — Legacy reactive sources register themselves in `component_context.l.s` so that mutating them can trigger the component's `beforeUpdate`/`afterUpdate` callbacks, replicating Svelte 4 invalidation semantics. (See [client_runtime_core_signal_model](client_runtime_core_signal_model.md).)

The runtime never relies on the flag alone — every legacy branch *additionally* checks the per-component condition (`component_context.l !== null`). This makes a mixed bundle (runes + legacy components) safe: `legacy_mode_flag` may be `true` globally, but runes-mode components simply never acquire a legacy context annex.

### `tracing_mode_flag`

| | |
|---|---|
| Enabled by | `import 'svelte/internal/flags/tracing'` — emitted when the component analysis was marked for tracing (`analysis.tracing`, typically activated by dev tooling such as the SvelteKit reactivity debugger) |
| Purpose | Enables dev-mode reactivity tracing: every signal records *where it was created*, *where it was updated*, and *whether it was set during an effect*, powering the console-based dependency inspector. |

Consumer branches:

- **`internal/client/reactivity/sources.js :: source()`** — Guarded by `DEV && tracing_mode_flag`: each new signal gets `created` (stack), `updated`, `set_during_effect`, and `trace` metadata fields.
- **`internal/client/dev/tracing.js`** — The `trace()`, `tag()`, and `log_entry()` helpers read that metadata to render collapsed console groups showing dirty/clean dependency states with timings. (See [client_dev_mode_debugging](client_dev_mode_debugging.md).)

Because production builds strip `DEV` blocks entirely, tracing instrumentation costs nothing in production even if the flag were somehow enabled.

---

## Design Rationale

1. **Why mutable `let` + in-module setters?**
   ES module exports are *live* but *read-only* from the importer's side. To share mutable state, the state and its mutation must live in the same module — hence the `enable_*` functions. They keep the mutation surface explicit and auditable (a grep for `enable_async_mode_flag` finds every possible activation site).

2. **Why side-effect activation modules instead of exported init calls?**
   The compiler emits `import 'svelte/internal/flags/legacy'` as a *bare* import. This:
   - keeps generated output minimal (no named binding to wire through minified code),
   - leverages ES module semantics so activation happens **before** any component code evaluates,
   - lets bundlers tree-shake modes an application never compiled against — for a pure runes-mode app, no `flags/legacy.js` import is ever emitted, so legacy mode machinery activation never occurs.

3. **Why global flags rather than per-component configuration?**
   The flags describe *runtime strategy*, not component data — e.g., how `tick()` flushes, or whether signal creation allocates trace metadata. Allocating this per component would duplicate state across every frame and still leave cross-component interactions (a legacy component receiving props from an async parent) ill-defined. Per-component *nuances* (runes vs legacy behavior within one app) are handled separately by the `runes` argument passed to `push()`, layered on top of the global legacy flag.

4. **Why is only `disable_async_mode_flag` provided?**
   Enabling modes is one-way in production by design. The single disable exists solely because the test suite runs many independent compilations in one process and must reset eagerly-imported async activation between cases. Its docblock (`ONLY USE THIS DURING TESTING`) is a hard contract for maintainers.

5. **Immutability of the sibling state modules.**
   The flags module is a deliberate *leaf*: it imports nothing, so it can be imported first by anything. The reactivity core, the context system, the public API, and the legacy compatibility layer all depend on it — never the reverse.

---

## Relationships with Other Modules

| Direction | Module | Relationship |
|---|---|---|
| ⇢ depends on | — | None (leaf module) |
| ⇠ activated by | [compiler_client_transform](compiler_client_transform.md) | Emits the bare `svelte/internal/flags/*` imports into generated client code based on `experimental.async`, `!analysis.runes`, and `analysis.tracing` |
| ⇠ informed by | [compiler_core_options](compiler_core_options.md) | Validates the compile options (e.g. `experimental.async`) that drive activation |
| ⇠ read by | [client_runtime_core_runtime](client_runtime_core_runtime.md) | `tick()` chooses frame-based vs synchronous flushing via `async_mode_flag` |
| ⇠ read by | [client_runtime_core_signal_model](client_runtime_core_signal_model.md) | `source()` attaches tracing metadata; `mutable_source()` registers legacy invalidation signals |
| ⇠ read by | [public_api](public_api.md) | `onMount()`/`beforeUpdate`/`afterUpdate` route through legacy callbacks when `legacy_mode_flag` is set |
| ⇠ read by | [legacy_compat](legacy_compat.md) | `Svelte4Component` avoids `flushSync()` under `async_mode_flag` |
| ⇠ read by | [client_dev_mode_debugging](client_dev_mode_debugging.md) | Dev tracing (`trace`, `tag`) consumes the metadata the tracing flag causes signals to carry |
| ↔ sibling | [shared_runtime_utilities](shared_runtime_utilities.md), [shared_runtime_diagnostics](shared_runtime_diagnostics.md) | Fellow members of the Cross-Runtime Platform Services layer; the flags are the *configuration* axis, while siblings provide *behavior* (`noop`, `run`, `to_array`) and *diagnostics* (`invalid_default_snippet`, element-tag validation) |
| ↔ sibling | context_api (client/server `context.js`) | `push()`/`pop()` implement the legacy context annex whose existence is gated by `legacy_mode_flag` |

Server-side rendering (see [server_runtime_rendering_core](server_runtime_rendering_core.md)) does not branch on these flags directly in its rendering primitives; SSR behavior for async components is driven by the compiler's `generate: 'server'` output and the payload model, which are documented in their own modules.

---

## Maintenance Notes

- **Never read a flag to decide module-level side effects other than mode activation** — flags may be `false` at evaluation time of some modules depending on import order. Read them *inside functions* that run after the app's entry graph has loaded.
- **Keep the module dependency-free.** Any new import into `flags/index.js` risks initialization cycles, since it is at the bottom of nearly every dependency chain.
- **Adding a new flag**: follow the established pattern exactly — a default-`false` `let`, an idempotent `enable_*` function, a two-line activation module in `internal/flags/`, an emission site in the transform phase, and DEV-gated consumption where the flag only exists to aid debugging.
- **Do not expose the flags on the public API.** They are internal plumbing; their activation is the compiler's job. Applications that need legacy/async mode get it automatically through the components they compile, not through runtime calls.
- The `flags/*.js` side-effect modules are part of the package's export surface (`svelte/internal/flags/...`) and are referenced by name from generated code — renaming them or the exported setter names is a **breaking change** for all previously compiled components.
