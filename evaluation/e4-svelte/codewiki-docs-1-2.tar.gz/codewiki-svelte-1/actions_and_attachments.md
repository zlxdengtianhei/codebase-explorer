# Actions & Attachments (`svelte/action` types + `svelte/attachments`)

> **Module tree position:** child of `Public_API_Surface___Compatibility_Layer_(Entries,_Type_Contracts,_Extensions___Legacy_Support)`

## 1. Overview & Purpose

This module provides the **public contract and bridging helpers for element-scoped behaviors** in Svelte. It consists of two small but architecturally distinct pieces:

| Piece | File | Role |
|---|---|---|
| **Action type contract** | `packages/svelte/src/action/public.d.ts` | Pure TypeScript interfaces (`Action`, `ActionReturn`) that type the `use:` directive. No runtime code at all. |
| **Attachment runtime helpers** | `packages/svelte/src/attachments/index.js` | The `svelte/attachments` entry point: `createAttachmentKey()` (programmatic attachments) and `fromAction()` (action → attachment bridge). |

Svelte historically attached reusable DOM behavior to elements via **actions** (`<div use:draggable>`). Svelte 5 introduced **attachments** (`<div {@attach fn}>`) as the reactive successor: an attachment is simply a function that receives the element and may return a cleanup function, and it *re-runs reactively* whenever its identity changes — it does not need a separate `update` protocol. This module is where both concepts meet: it types the legacy mechanism and provides the tooling to adopt (or interoperate with) the new one.

```svelte
<!-- Action: runs once per element, updates via the returned update() hook -->
<div use:draggable={options}>...</div>

<!-- Attachment: re-runs whenever `fn` identity changes, cleanup = returned function -->
<div {@attach tooltip}>...</div>

<!-- Programmatic attachment: a symbol key in a spread props object (Svelte 5.29+) -->
<button {...props}>...</button>
<!-- where props = { class: 'cool', [createAttachmentKey()]: (node) => {...} } -->
```

## 2. Architecture Overview

Although the module itself is tiny, it sits at the junction of three subsystems: the public API surface, the compiler back-end, and the client runtime. The diagram below shows who produces what, and who consumes it.

```mermaid
flowchart TB
    subgraph PublicAPI["This module — Public API"]
        T["action/public.d.ts<br/>Action · ActionReturn<br/>(types only)"]
        K["attachments/index.js<br/>createAttachmentKey()<br/>→ Symbol('@attach')"]
        FA["attachments/index.js<br/>fromAction(action, () => arg)<br/>→ Attachment"]
    end

    subgraph UserCode["User / Library code"]
        U1["use:action={value}"]
        U2["{@attach fn}"]
        U3["{...props} with<br/>[createAttachmentKey()]: fn"]
    end

    subgraph Compiler["Compiler Back-End<br/>(see compiler_client_transform)"]
        V1["UseDirective visitor<br/>→ $.action(node, fn, () => value)"]
        V2["AttachTag visitor<br/>→ $.attach(node, () => fn)"]
        V3["SpreadAttribute / attribute_effect<br/>→ $.attribute_effect(el, () => ({...props}))"]
    end

    subgraph Runtime["Client DOM Renderer<br/>(see client_dom_renderer)"]
        R1["action()<br/>dom/elements/actions.js"]
        R2["attach()<br/>dom/elements/attachments.js"]
        R3["attribute_effect()<br/>dom/elements/attributes.js<br/>(detects Symbol('@attach'))"]
    end

    subgraph Signals["Reactive Runtime Core<br/>(see client_runtime_core)"]
        S1["effect / render_effect / block / branch"]
        S2["untrack"]
        S3["teardown / destroy_effect"]
    end

    U1 --> V1 --> R1
    U2 --> V2 --> R2
    U3 --> V3 --> R3
    R3 --> R2

    T -. types .-> V1
    T -. types .-> R1
    FA -. produces Attachment .-> U2
    FA --> S2
    FA --> S1
    FA --> S3
    R1 --> S1
    R2 --> S1
    R1 --> S2
    R3 --> S3
    K -. symbol description '@attach' .-> R3
```

Key insight: **`createAttachmentKey()` and the runtime are coupled by a string**. `createAttachmentKey()` returns `Symbol(ATTACHMENT_KEY)` where `ATTACHMENT_KEY = '@attach'` (defined in `packages/svelte/src/constants.js`). At runtime, `attribute_effect()` walks `Object.getOwnPropertySymbols(next)` and treats any symbol whose `description === '@attach'` as an attachment, wrapping it in a reactive branch. This is how a plain `{...spread}` of props can carry behavior, not just attributes.

## 3. Sub-modules

<!-- SUBMODULE_LINKS_START -->
| Sub-module | File | Core components | What it covers |
|---|---|---|---|
| Action Type Contract | [actions_and_attachments_action_contract.md](actions_and_attachments_action_contract.md) | `action/public.d.ts::Action` (+ `ActionReturn`) | The `use:` directive's type system: element/parameter/attributes generics, the `undefined extends Parameter` optional-arg trick, and the `$$_attributes` phantom field for declaring extra props/events an action enables. |
| Attachment Runtime Helpers | [actions_and_attachments_attachment_runtime.md](actions_and_attachments_attachment_runtime.md) | `attachments/index.js::createAttachmentKey`, `attachments/index.js::fromAction` | The `svelte/attachments` entry point: the `Symbol('@attach')` spread-props protocol and the reactive action→attachment bridge built on `untrack` / `render_effect` / `teardown`. |

Both sub-module docs link back to this overview and reference the runtime counterparts documented in [client_dom_renderer_elements_and_events](client_dom_renderer_elements_and_events.md) (`action()`, `attach()`, `attribute_effect()`).
<!-- SUBMODULE_LINKS_END -->

## 4. Actions vs. Attachments — Semantic Comparison

Because `fromAction()` exists specifically to translate between the two lifecycles, understanding the difference is central to this module:

| Aspect | Action (`use:`) | Attachment (`{@attach}` / spread key) |
|---|---|---|
| Introduced | Legacy (Svelte 1.x+) | Svelte 5.29 / 5.32 (`fromAction`) |
| Function signature | `(node, parameter?) => void \| ActionReturn` | `(element) => void \| (() => void)` |
| First invocation | Once per element, inside an `effect` (after attributes are applied) | Per element *branch*; re-invoked when the attachment function's **identity** changes |
| Reacting to arguments | Coarse-grained `update(parameter)` hook + `deep_read` of the value | Fine-grained: any signal read inside the attachment body re-runs it |
| Cleanup protocol | `destroy()` method on the returned object | The (optional) function returned by the attachment |
| Programmatic use | Not supported in spread objects | `[createAttachmentKey()]: fn` in a spread props object |
| Type contract | `Action` / `ActionReturn` (this module) | `Attachment<T>` (`attachments/public.d.ts`) |
| Bridge | `fromAction(action, () => arg)` → `Attachment` | — |

## 5. Lifecycle Data Flow

### 5.1 Action lifecycle (`use:action={value}`)

The compiler's `UseDirective` visitor (see [compiler_client_transform_elements_and_directives](compiler_client_transform_elements_and_directives.md)) compiles the directive into a single `$.action(...)` call; the runtime (see [client_dom_renderer_elements_and_events](client_dom_renderer_elements_and_events.md)) executes it:

```mermaid
sequenceDiagram
    participant Out as Compiled output
    participant R as action() runtime
    participant AC as Action function
    participant Eff as Effect tree
    Out->>R: $.action(node, ($$node, $$arg) => act(...), () => value)
    R->>AC: untrack(() => action(node, get_value?.()) || {})
    AC-->>R: { update?, destroy? } | void
    R->>Eff: render_effect: deep_read_state(value)
    Note over R,Eff: on subsequent invalidations, if safe_not_equal(prev, value)
    Eff->>AC: update(value)
    Note over Eff: effect teardown on element unmount
    Eff->>AC: destroy()
```

### 5.2 Attachment lifecycle (`{@attach fn}` and `createAttachmentKey()`)

`{@attach fn}` compiles to `$.attach(node, () => fn)` (see the `AttachTag` visitor). Symbol keys from `createAttachmentKey()` are detected inside spread objects by `attribute_effect()`:

```mermaid
sequenceDiagram
    participant Out as Compiled output
    participant AE as attribute_effect() / attach()
    participant BR as branch()
    participant AT as Attachment fn
    Out->>AE: $.attach(el, () => fn)  or  symbol key in {...props}
    AE->>AE: fn identity changed?
    alt yes (first run or new function)
        AE->>BR: destroy previous branch effect (runs its cleanup)
        AE->>BR: branch(() => attach(el, () => fn))
        BR->>AT: effect(() => fn(el))
        AT-->>BR: optional cleanup fn → registered as effect teardown
        Note over AT: reads of reactive state inside fn re-trigger this effect
    else no
        AE->>AE: keep existing branch, do nothing
    end
```

### 5.3 The `fromAction()` bridge

`fromAction()` merges the two models: it calls the action **once** (untracked), replays `update` through a `render_effect` (skipping the first run, mimicking action semantics), and registers `destroy` through `teardown` so element unmount destroys the action. Details in the [Attachment Runtime Helpers](actions_and_attachments_attachment_runtime.md) sub-module doc.

```svelte
<!-- before (action provided by a library) -->
<div use:foo={bar}>...</div>

<!-- after (bridged to an attachment) -->
<div {@attach fromAction(foo, () => bar)}>...</div>
```

Note the second argument must be a **getter** (`() => bar`), not the value itself — this is what keeps the bridged action reactive.

## 6. Relationship to Other Modules

To avoid duplication, this module's deep-dive material lives in the following sibling/related docs:

| Topic | Where it is documented |
|---|---|
| Public entry points (`svelte`, `svelte/attachments` re-exports, `mount`/`hydrate`) | [public_api](public_api.md) |
| Complete public type re-exports (`Action`, `Attachment`, …) | [svelte-types](svelte-types.md) |
| Compiler visitors that emit `$.action` / `$.attach` / `$.attribute_effect` | [compiler_client_transform_elements_and_directives](compiler_client_transform_elements_and_directives.md) |
| Runtime `action()` / `attach()` / `attribute_effect()` implementations | [client_dom_renderer_elements_and_events](client_dom_renderer_elements_and_events.md) |
| Effect primitives (`effect`, `render_effect`, `branch`, `block`, `teardown`, `untrack`) | [client_runtime_core_effects](client_runtime_core_effects.md) & [client_runtime_core_runtime](client_runtime_core_runtime.md) |

## 7. Practical Notes for Maintainers

- **Type-only module part:** `action/public.d.ts` has no runtime artifact. `Action` is re-exported through the package's public types (`packages/svelte/types/index.d.ts`), so changes there are API-breaking.
- **`undefined extends Parameter` trick:** the `Action` interface deliberately checks `undefined extends Parameter` (not `Parameter extends undefined`) so the parameter is optional in both strict and non-strict TS modes. Preserve this when editing.
- **`ActionReturn.$$_attributes` is a phantom field** — it exists *solely* for type-checking of the `Attributes` generic and must never be read at runtime.
- **Symbol-based protocol:** any change to `ATTACHMENT_KEY` (`packages/svelte/src/constants.js`) must be coordinated with `createAttachmentKey()` and `attribute_effect()`'s symbol scan — they are coupled by the literal description string `'@attach'`.
- **Tree-shaking:** both runtime helpers are individually exported so bundlers can drop the unused one (`createAttachmentKey` vs `fromAction`).
