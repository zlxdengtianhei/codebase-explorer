# Compiler Infrastructure (Core Orchestration, Diagnostics & AST Type Model)

**Path:** `packages/svelte/src/compiler`

## Purpose

This module is the backbone of the Svelte compiler. It does not implement a single compilation phase itself; instead, it provides the shared infrastructure that the front-end pipeline ([parsing, analysis, CSS scoping](compiler_core.md)) and the back-end code generation phases all depend on:

1. **Core orchestration** — the public entry points (`compile()`, `compileModule()`, `parse()`) that wire the `parse → analyze → transform` pipeline together, normalize and validate compiler options, own the per-compilation `CompileState`, and supply AST builder helpers used by every phase.
2. **Diagnostics** — the single source of truth for all errors and warnings: stable diagnostic codes, message templates, the `CompileDiagnostic` model with source positions, and the `error()`/`warning()` helpers that any phase can invoke.
3. **AST & API type model** — the complete type system (template AST, CSS AST, legacy Svelte 3/4 AST shims, and the public `CompileOptions`/`CompileResult` contracts) that defines the data exchanged between phases and with compiler consumers.

Because all three concerns are centralized here, the individual phases remain decoupled from each other, diagnostics stay consistent and tooling-friendly, and client/server transforms can operate independently on a frozen, metadata-annotated AST.

## Architecture

```mermaid
flowchart TD
    subgraph Infra["Compiler Infrastructure (this module)"]
        Core["compiler_core<br/>index.ts entry points · options · state · builders"]
        Diag["compiler_diagnostics<br/>errors.js · warnings.js · CompileDiagnostic"]
        Types["compiler_types<br/>Template AST · CSS AST · legacy AST · API contracts"]
    end

    Source["Component source"] --> Core

    subgraph Pipeline["Compilation phases (other modules)"]
        Parse["1-parse<br/>(front-end)"]
        Analyze["2-analyze<br/>(front-end)"]
        CSS["CSS scoping pipeline"]
        Transform["3-transform<br/>(client & server back-end)"]
    end

    Core -->|"orchestrates"| Parse --> Analyze
    Analyze --> CSS --> Transform

    Parse -.->|"produces nodes of"| Types
    Analyze -.->|"attaches __ metadata to"| Types
    Transform -.->|"reads AST + contracts"| Types

    Parse & Analyze & CSS & Transform -.->|"error() / warning()"| Diag
    Diag -->|"diagnostics"| Core
    Core -->|"CompileResult { js, css, warnings, ast }"| Result["Consumer / bundler"]
```

**Data flow:** `compile()` normalizes options into `ValidatedCompileOptions`, builds a `CompileState`, and drives the source through `parse` → `analyze` → the appropriate client or server `transform`. Template and CSS nodes come from the type model; analysis metadata (`Binding`, `ExpressionMetadata`, …) hangs off `node.__` without changing node shapes. Any phase can raise diagnostics, which are collected (warnings) or thrown (errors), filtered by the user's `warningFilter`, and returned in `CompileResult`.

## Core Components

| Component | Responsibility | Documentation |
|---|---|---|
| **compiler_core** | Compilation entry points, option validation/normalization, compile state, AST builders, error code tables | [compiler_core.md](compiler_core.md) |
| **compiler_diagnostics** | Error/warning code tables, the `CompileDiagnostic` model, positional helpers, warning filtering | [compiler_diagnostics.md](compiler_diagnostics.md) |
| **compiler_types** | Template AST, CSS AST, legacy AST shims, and public compiler API contracts (`CompileOptions`, `CompileResult`) | [compiler_types.md](compiler_types.md) |