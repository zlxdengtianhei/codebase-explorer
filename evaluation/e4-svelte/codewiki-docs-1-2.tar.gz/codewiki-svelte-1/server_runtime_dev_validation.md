# Server Runtime Dev Validation (`server_runtime_dev_validation`)

## 1. Introduction

`server_runtime_dev_validation` is the **development-mode validation layer of Svelte's server-side rendering (SSR) runtime**. Implemented entirely in `packages/svelte/src/internal/server/dev.js`, it provides three public hooks that the compiler's server code-generation back-end injects into generated components **only when the `dev` compile option is enabled**:

| Export | Purpose |
| --- | --- |
| `push_element(payload, tag, line, column)` | Push an element onto the SSR element stack and validate its placement against its parent and all ancestors |
| `pop_element()` | Pop the element stack when an element closes |
| `validate_snippet_args(payload)` | Assert that a value passed to a generated snippet function is a real render payload |

Its mission: **catch invalid HTML nesting at the moment it is rendered on the server**, long before it manifests in the browser as "content shifting around" or a `hydration_mismatch` warning during client hydration. All diagnostics are delivered through a dual channel — the Node/server console *and* an inline `<script>console.error(...)</script>` injected into the rendered `<head>` — so developers see the problem regardless of where they are looking.

> **Note:** The same file is also indexed under the sibling module name [`server_runtime_dev_element_validation`](server_runtime_dev_element_validation.md); both modules cover the identical source file and exports. This document is the canonical reference.

In production builds the compiler omits every call into this module, so the entire subsystem is tree-shaken away and costs nothing at runtime. The client-side counterpart — attaching source locations to DOM nodes in dev builds — is documented in [`client_dev_mode_locations`](client_dev_mode_locations.md).

---

## 2. Component Inventory

| Component | Kind | Visibility | Description |
| --- | --- | --- | --- |
| `push_element` | function | exported | Records an element's render with source location; runs HTML tree-placement validation against parent + ancestors |
| `pop_element` | function | exported | Pops the element stack (`parent = parent.parent`) at element close |
| `validate_snippet_args` | function | exported | Type-guards the payload of generated snippet functions; throws a Svelte error on mismatch |
| `reset_elements` | function | exported (internal use) | Snapshots and clears the element stack, returning a restore closure — used by `render()` for render isolation |
| `print_error` | function | module-private | Deduplicates and reports a placement violation on both diagnostic channels |
| `Element` | typedef | module-private | `{ tag, parent, filename, line, column }` — one node of the validation stack |
| `parent` / `seen` | state | module-private | Current stack top (linked list); set of already-reported messages for dedupe |

---

## 3. Architecture

The module sits between **generated SSR component code** (its only caller) and the **HTML tree validation rule base**, while coordinating with the **server payload model** for diagnostic injection and the **server component context** for source-file attribution.

```mermaid
flowchart TB
    subgraph GEN["Generated component code<br/>(compiler server transform, dev builds only)"]
        G1["$.push_element($$payload, tag, line, col)"]
        G2["$.pop_element()"]
        G3["$.validate_snippet_args(payload)"]
    end

    subgraph MOD["server/dev.js — this module"]
        PE["push_element"]
        PPE["pop_element"]
        VSA["validate_snippet_args"]
        RE["reset_elements"]
        PRINT["print_error (private)"]
        STACK[("parent<br/>element stack (linked list)")]
        SEEN[("seen<br/>message dedupe set")]
    end

    subgraph VAL["html-tree-validation.js"]
        VP["is_tag_valid_with_parent"]
        VA["is_tag_valid_with_ancestor"]
        RULES[("disallowed_children<br/>rule table")]
    end

    subgraph SRV["Server runtime"]
        RENDER["render()<br/>(server_runtime_rendering_core)"]
        CTX["context.js: current_component<br/>(context_api_server)"]
        PAY["Payload / HeadPayload<br/>(server_runtime_payload_model)"]
        CONST["constants.js: FILENAME"]
    end

    G1 --> PE
    G2 --> PPE
    G3 --> VSA

    RENDER -- "DEV: isolate stack" --> RE
    RE --- STACK

    PE -- "attach component filename" --> CTX
    CTX -.-> CONST
    PE -- "push" --> STACK
    PPE -- "pop" --> STACK

    PE -- "direct-child check" --> VP
    PE -- "ancestor-chain check" --> VA
    VP --- RULES
    VA --- RULES

    PE -- "on violation" --> PRINT
    PRINT -- "skip if duplicate" --> SEEN
    PRINT -- "console.error" --> NODE{{"Server console"}}
    PRINT -- "&lt;script&gt;console.error(...)&lt;/script&gt;" --> PAY

    VSA -- "instanceof check" --> PAY
    VSA -- "on failure: throw" --> ERR["invalid_snippet_arguments<br/>(shared_runtime_diagnostics)"]
```

### 3.1 The Element Stack

The stack is a module-level linked list. Each `Element` record points to its parent, so `pop_element()` is a single pointer hop and ancestor traversal in `push_element` is a plain `while (ancestor != null)` walk:

```mermaid
flowchart BT
    A["{ tag: 'table', parent: null }"] -->|"parent"| NULL(("null"))
    B["{ tag: 'tbody', parent: table }"] -->|"parent"| A
    C["{ tag: 'tr', parent: tbody }"] -->|"parent"| B
    D["{ tag: 'td', parent: tr }<br/>← module-level 'parent' pointer"] -->|"parent"| C
```

Because the state is **module-scoped**, it survives across components rendered within one render pass (parent links naturally span component boundaries), but it must be protected against corruption from unbalanced push/pop pairs — which is exactly what `reset_elements` + `render()` do (see §4.4).

---

## 4. Core Component Behavior

### 4.1 `push_element(payload, tag, line, column)` — placement validation

Called by generated code immediately after an element's opening tag is emitted, before children are rendered. The `line`/`column` arguments are compile-time constants produced by the server transform ([`compiler_server_transform_elements`](compiler_server_transform_elements.md)), which emits:

```js
// dev builds only (from server/visitors/RegularElement.js):
$.push_element($$payload, 'div', location.line, location.column);
/* ...children rendering... */
$.pop_element();
```

Processing steps:

```mermaid
flowchart TD
    A["push_element(payload, tag, line, column)"] --> B["filename =<br/>current_component.function[FILENAME]<br/>(dev-only property set by context push)"]
    B --> C["child = { tag, parent, filename, line, column }"]
    C --> D{"parent !== null?"}
    D -- "no (root element)" --> Z["parent = child<br/>return"]
    D -- "yes" --> E["Direct check:<br/>is_tag_valid_with_parent(<br/>tag, parent.tag, child_loc, parent_loc)"]
    E --> F{"message returned?"}
    F -- "yes" --> G["print_error(payload, message)"]
    F -- "no" --> H
    G --> H["ancestor = parent.parent<br/>ancestors = [parent.tag]"]
    H --> I{"ancestor != null?"}
    I -- "yes" --> J["ancestors.push(ancestor.tag)<br/>is_tag_valid_with_ancestor(<br/>tag, ancestors, child_loc, ancestor_loc)"]
    J --> K{"message returned?"}
    K -- "yes" --> G2["print_error(payload, message)"]
    K -- "no" --> L
    G2 --> L["ancestor = ancestor.parent"]
    L --> I
    I -- "no" --> Z
```

Key details:

- **Two rule families** are consulted (see [`shared_runtime_diagnostics`](shared_runtime_diagnostics.md) for the rule-table mechanics):
  - `is_tag_valid_with_parent` — direct-child constraints (`direct`, `descendant`, `only` categories) plus hard structural rules (e.g. `<td>` must be in `<tr>`, `<tbody>` must be in `<table>`).
  - `is_tag_valid_with_ancestor` — descendant constraints (`descendant`) with `reset_by` semantics, so a forbidden descendant check stops at intermediate ancestors that re-enable the tag (or at custom elements, which are always exempt).
- **Source locations** are formatted as `filename:line:column` and embedded directly into the human-readable violation messages, e.g. `` `<td>` (App.svelte:5:8) must be the child of a `<tr>`, not a `<div>` ``, making the offending component trivially locatable.
- Validation is **non-fatal**: violations are reported, rendering continues. This mirrors HTML parsers, which *repair* invalid nesting rather than abort — the diagnostic warns about exactly that repair behavior.

### 4.2 `pop_element()` — stack unwind

A one-line counterpart invoked after the closing tag is emitted. The `parent` pointer is replaced by its own `parent`, matching the generated open/close pairing of `push_element`/`pop_element` in the compiler output.

### 4.3 `print_error(payload, message)` — dual-channel diagnostics

```mermaid
flowchart LR
    M["violation message from<br/>html-tree-validation"] --> P["compose final message:<br/>'node_invalid_placement_ssr: ...'\n\n+ explanation that browser HTML repair<br/>shifts content and will likely cause<br/>a hydration_mismatch warning"]
    P --> D{"seen.has(message)?"}
    D -- "yes" --> S["skip — already reported"]
    D -- "no" --> A["seen.add(message)"]
    A --> C1["console.error(message)<br/>→ server / terminal console"]
    A --> C2["payload.head.out.push(<br/>`&lt;script&gt;console.error(...)&lt;/script&gt;`)<br/>→ embedded in rendered &lt;head&gt;"]
    C2 --> B{{"Browser console during SSR response / hydration"}}
```

Design points:

- The message is prefixed with the **Svelte error code** `node_invalid_placement_ssr`, consistent with the framework's error-code convention (see the generated message-code pipeline in [`svelte_build_tooling_message_templates`](svelte_build_tooling_message_templates.md)).
- The `seen` set is module-level and process-lifetime: the **same violation is logged only once per process**, preventing console spam from repeated renders (e.g. during dev watch loops).
- Injection into `payload.head.out` guarantees the diagnostic also appears in the **browser console**, aligning the server-side symptom with the client-side effect the developer will actually observe (`hydration_mismatch`).

### 4.4 `reset_elements()` — render isolation

`render()` in the SSR core ([`server_runtime_rendering_core`](server_runtime_rendering_core.md)) wraps each render in dev mode:

```js
if (DEV) reset_reset_element = reset_elements();   // snapshot + clear
/* ...component(payload, props, ...)... */
reset_reset_element();                              // restore snapshot
```

The snapshot/restore closure pattern guarantees that a **bad render** (e.g. a component that throws between `push_element` and `pop_element`, or an unbalanced generated pair) cannot leak a corrupted `parent` pointer into subsequent `render()` calls on the same server process — each top-level render starts with a clean validation stack.

### 4.5 `validate_snippet_args(payload)` — snippet payload guard

Generated snippet functions (`{#snippet ...}` / `{@render ...}`) begin with `$.validate_snippet_args($$payload)` in dev builds. The guard verifies the payload is an object and an `instanceof` either `Payload` or `HeadPayload` (the latter supports snippets rendered into head content; see [`server_runtime_payload_model`](server_runtime_payload_model.md)):

```mermaid
flowchart LR
    A["generated snippet fn:<br/>snippet(payload, ...args)"] --> B{"typeof payload === 'object'<br/>and (payload instanceof Payload<br/>or HeadPayload)?"}
    B -- "yes" --> C["continue rendering snippet"]
    B -- "no" --> D["e.invalid_snippet_arguments()<br/>throws 'Svelte error'"]
```

A failure here indicates a programming error (typically calling a snippet function directly instead of through `{@render}`); it is a **hard throw**, unlike the non-fatal placement diagnostics, and the error text comes from the generated diagnostics in `internal/shared/errors.js` (re-exported via `server/errors.js` — see [`shared_runtime_diagnostics`](shared_runtime_diagnostics.md)).

---

## 5. End-to-End Flow: Where This Module Lives in an SSR Request

```mermaid
sequenceDiagram
    autonumber
    participant App as Application code
    participant R as render() (index-server.js / server_runtime_rendering_core)
    participant D as server/dev.js (this module)
    participant V as html-tree-validation.js
    participant G as Generated component (dev build)
    participant H as payload.head.out

    App->>R: render(Component, options)
    R->>D: reset_elements()  [DEV]
    D-->>R: restore closure
    R->>G: component(payload, props, ...)

    Note over G: <table> opening tag emitted
    G->>D: push_element(payload, "table", 4, 0)
    D->>D: parent = { table, parent: null }

    Note over G: <td> opening tag emitted (invalid!)
    G->>D: push_element(payload, "td", 5, 1)
    D->>V: is_tag_valid_with_parent("td", "table", ...)
    V-->>D: "<td> must be the child of a <tr>, not a <table>"
    D->>H: <script>console.error(...)</script>
    D->>D: console.error (server console, deduped via seen)
    D->>D: parent = { td, parent: table }

    G->>G: render children...
    G->>D: pop_element()  → parent = table
    G->>D: pop_element()  → parent = null

    R->>D: restore closure()  [stack isolation]
    R-->>App: { head, html, body }  (diagnostic script inside head)
```

---

## 6. Data Model

```mermaid
classDiagram
    class Element {
        +string tag
        +Element~null~ parent
        +string~null~ filename
        +number line
        +number column
    }
    class Payload {
        +string[] out
        +Set~string~ css
        +HeadPayload head
        +number uid
    }
    class HeadPayload {
        +string[] out
        +Set~string~ css
        +string~null~ title
        +number uid
    }
    Payload *-- HeadPayload : head
    push_element ..> Element : creates child record
    pop_element ..> Element : follows parent link
    validate_snippet_args ..> Payload : instanceof guard
    validate_snippet_args ..> HeadPayload : instanceof guard
    print_error ..> Payload : appends console.error script to head.out
```

---

## 7. Dependencies

### 7.1 Imports (what this module consumes)

| Import | Source | Role |
| --- | --- | --- |
| `FILENAME` | `../../constants.js` | Symbol key under which the compiler attaches the source filename to component functions (dev only) |
| `is_tag_valid_with_parent`, `is_tag_valid_with_ancestor` | `../../html-tree-validation.js` | HTML nesting rule engine (rule table: `direct` / `descendant` / `only` / `reset_by`) |
| `current_component` | `./context.js` | Currently rendering component; its dev-only `.function[FILENAME]` yields the source file for location strings ([`context_api_server`](context_api_server.md)) |
| `e` (errors) | `./errors.js` | Generated Svelte error throwers; `invalid_snippet_arguments` re-exported from shared errors |
| `HeadPayload`, `Payload` | `./payload.js` | Render output containers ([`server_runtime_payload_model`](server_runtime_payload_model.md)) |

### 7.2 Consumers (who calls this module)

| Caller | Context |
| --- | --- |
| **Generated server components** — `$.push_element` / `$.pop_element` around every regular element (dev builds only) | Emitted by [`compiler_server_transform_elements`](compiler_server_transform_elements.md) (`RegularElement` visitor, guarded by `if (dev)`) |
| **Generated snippet functions** — `$.validate_snippet_args($$payload)` | Emitted by the server transform's snippet handling (dev builds only) |
| **`render()`** — `reset_elements()` snapshot/restore | [`server_runtime_rendering_core`](server_runtime_rendering_core.md) |

### 7.3 Related modules (documentation links)

- [`server_runtime_rendering_core`](server_runtime_rendering_core.md) — `render()`, `element()`: owns the render lifecycle that brackets this module's work
- [`server_runtime_payload_model`](server_runtime_payload_model.md) — `Payload` / `HeadPayload` and diagnostics injection surface
- [`server_runtime_blocks`](server_runtime_blocks.md) — raw `html` blocks and raw snippets, which bypass element validation by design
- [`client_dev_mode_locations`](client_dev_mode_locations.md) — client-side sibling: `add_locations` attaches source locations to client DOM nodes
- [`client_dev_mode_validation`](client_dev_mode_validation.md) — client-side dev guards (`validate_snippet_args` mirror, ownership validator, assignment checks)
- [`client_runtime_core_diagnostics`](client_runtime_core_diagnostics.md) — client-side `hydration_mismatch` warning that typically accompanies an uncaught placement violation
- [`context_api_server`](context_api_server.md) — `current_component` lifecycle (`push`/`pop` attach the dev-only component function)
- [`shared_runtime_diagnostics`](shared_runtime_diagnostics.md) — shared error/warning generators and dynamic-element validation
- [`shared_runtime_flags`](shared_runtime_flags.md) — `DEV` flag gating that keeps this module dead code in production
- [`svelte_build_tooling_message_templates`](svelte_build_tooling_message_templates.md) — code-generation pipeline for the error messages (`node_invalid_placement_ssr`, `invalid_snippet_arguments`)

---

## 8. Design Considerations & Behavioral Notes

1. **Zero production cost.** Every entry point is invoked solely from code emitted under `if (dev)` in the server transform; production bundles contain neither the calls nor this module (tree-shakeable, see [`svelte_build_tooling_treeshakeability_checker`](svelte_build_tooling_treeshakeability_checker.md)).
2. **Non-fatal placement diagnostics.** Invalid nesting is reported, not thrown — matching browser parser behavior (repair-and-continue) while explaining the hydration consequences in the message itself.
3. **Cross-component span.** Because `parent` is module state rather than per-component state, ancestor validation sees through component boundaries — a `<td>` rendered inside a child component of a `<div>` is still caught.
4. **Once-per-process dedupe.** The `seen` set is intentionally never reset; a recurring mis-nesting in a dev watch loop logs a single diagnostic rather than flooding the console.
5. **Failure containment.** `render()`'s `reset_elements()` snapshot/restore confines stack corruption from throwing components to a single render call.
6. **Symptom-aligned reporting.** By echoing violations into the page's `<head>` via injected scripts, the module bridges the server-side cause and the browser-side effect (`hydration_mismatch`), which is the most actionable place for the developer to notice.
7. **Custom-element escape hatch.** All validation rules exempt tags containing `-`, so Web Components can nest arbitrarily without false positives; `<template>` immediate children are likewise exempt.

---

## 9. Summary

`server_runtime_dev_validation` is a small but strategically placed subsystem: it converts compile-time source-location metadata (provided by the compiler back-end) plus a declarative HTML nesting rule base into **actionable, dual-channel, deduplicated diagnostics during SSR in dev mode** — with hard stack isolation via `reset_elements()` and a strict payload contract for snippets via `validate_snippet_args()`. It exemplifies the framework's dev-mode philosophy: rich validation where it costs nothing in production, and diagnostics that map directly onto the runtime symptoms developers would otherwise chase in the browser.
