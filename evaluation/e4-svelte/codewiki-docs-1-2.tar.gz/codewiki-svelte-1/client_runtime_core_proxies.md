# client_runtime_core_proxies

## Introduction

`client_runtime_core_proxies` is the module responsible for turning plain JavaScript objects and arrays into **deeply reactive state** in the Svelte 5 client runtime. It lives in a single file — `packages/svelte/src/internal/client/proxy.js` — and implements the machinery behind the `$state` rune for object and array values. Rather than requiring immutable updates, Svelte lets you mutate `$state` objects directly (e.g. `state.count++`, `array.push(...)`, `delete state.key`); this module is what makes those mutations observable, by interposing a `Proxy` that lazily converts each property access into a signal read and each mutation into a signal write.

It is a leaf module within the `client_runtime_core` family of the [Reactive_Runtime_Engine_(Signals,_Effects___Batching_with_Dev-Mode_Instrumentation)](reactive_runtime_engine_signals_effects_batching_with_dev-mode_instrumentation.md), and it delegates the actual signal semantics (dependency tracking, dirty checking, batching) to its sibling modules:

- [client_runtime_core_runtime](client_runtime_core_runtime.md) — `get()`, reaction context, update versions
- [client_runtime_core_sources](client_runtime_core_sources.md) — `state()`, `set()`, `increment()`
- [client_runtime_core_signal_model](client_runtime_core_signal_model.md) — the `Signal` shape and equality semantics
- [client_runtime_core_diagnostics](client_runtime_core_diagnostics.md) — development errors/warnings surfaced by proxy traps
- [client_dev_mode](client_dev_mode.md) — tracing, labelling and `$inspect` instrumentation

---

## Module Purpose and Core Functionality

| Export | Kind | Role |
| --- | --- | --- |
| `proxy(value)` | function (main entry) | Wraps a plain object/array in a reactive `Proxy`, or returns the value untouched if it is not proxyable (primitives, `null`, already-proxied values, non-plain prototypes) |
| `update_path(new_path)` | internal (dev) | Re-labels a proxy and recursively re-labels all of its child sources/proxies; exposed to the outside world through the `PROXY_PATH_SYMBOL` hook |
| `get_proxied_value(value)` | function | Unwraps the raw underlying state object from a proxy (via `STATE_SYMBOL`), with a safety net for cross-origin iframe objects |
| `is(a, b)` | function | Proxy-aware `Object.is` — compares underlying state instead of proxy identities |
| `get_label(path, prop)` | internal (dev) | Formats a debug label such as `state.count`, `state['weird key']` or `state[0]` |
| `inspectable_array(array)` | internal (dev) | Wraps array-mutating methods (`push`, `splice`, `sort`, …) so `$inspect` effects fire exactly once per mutation |

### Proxyability rules

`proxy(value)` is deliberately conservative — it only takes over values it can faithfully emulate:

1. **Non-objects** (`typeof !== 'object'`) and `null` are returned as-is (they need no reactivity).
2. **Already reactive values** (`STATE_SYMBOL in value`) are returned as-is — no double wrapping.
3. **Only plain objects and arrays** (prototype exactly `Object.prototype` or `Array.prototype`) are proxied. Class instances, `Map`/`Set`, DOM nodes etc. are left alone, because `Proxy` invariants cannot be guaranteed for exotic objects.

---

## Architecture

Internally, every proxy owns two pieces of state:

- **`sources`** — a `Map<property, Source>` that maps each *own* property to a lazily created source signal holding the current value. A special `'length'` source is created eagerly for arrays.
- **`version`** — a source signal counting *structural* changes (property additions/deletions). The `ownKeys` trap reads it, so operations like `Object.keys()`, spread and iteration re-run when the shape of the object changes.

Child values that are themselves objects/arrays are recursively wrapped: reading `proxy.child` produces a source whose value is `proxy(child)`, giving deep reactivity with on-demand cost.

```mermaid
graph TB
    subgraph "proxy(value) — one reactive proxy instance"
        P["JS Proxy<br/>(traps: get, set, has, deleteProperty,<br/>defineProperty, ownKeys, ...)"]

        subgraph "internal state"
            SOURCES["sources: Map&lt;prop, Source&gt;<br/>(lazy per-property signals)"]
            VERSION["version: Source&lt;number&gt;<br/>(structural change counter)"]
            PATH["path: string (DEV only)<br/>maintained by update_path()"]
        end

        P -- "get / has" --> SOURCES
        P -- "set / deleteProperty /<br/>defineProperty" --> SOURCES
        P -- "ownKeys" --> VERSION
        P -- "DEV: PROXY_PATH_SYMBOL" --> PATH
        SOURCES -- "tag(child, label)" --> PATH
    end

    subgraph "Value layer"
        V0["Source(propA)"] --> CV0["proxy(childValue)<br/>(recursive, nested proxy)"]
        V1["Source(propB)"] --> CV1["primitive value"]
        VL["Source('length')<br/>(arrays: eager)"]
        VU["Source(UNINITIALIZED)<br/>(deleted / absent props)"]
    end

    SOURCES --- V0
    SOURCES --- V1
    SOURCES --- VL
    SOURCES --- VU
```

### Trap-by-trap behaviour

| Trap | Behaviour |
| --- | --- |
| `get` | Returns the raw state for `STATE_SYMBOL`; returns `update_path` for `PROXY_PATH_SYMBOL` (DEV). Otherwise looks up/creates a per-property source and reads it via `get()` — which registers the dependency on the current reaction. Prototype (non-writable inherited) properties bypass signal creation and fall through to `Reflect.get`. A source holding `UNINITIALIZED` reads as `undefined`. |
| `set` | Writes through `set(source, proxy(value))`. For arrays, `length = n` clears sources with index ≥ `n`, and writing index `n ≥ length` bumps the `length` source. New properties bump `version`. Accessor setters on the target are still invoked. |
| `has` | Reports `true` for `STATE_SYMBOL`; creates a source when inside an active effect; a deleted/absent property reads as `false`. |
| `deleteProperty` | Sets the property source to `UNINITIALIZED` (creating one if the property only existed on the target) and bumps `version`. |
| `defineProperty` | Accepts only *basic* data descriptors (value present, configurable/enumerable/writable all `true`) — anything else raises `state_descriptors_fixed`. Creates or updates the property source. |
| `getOwnPropertyDescriptor` | Splices the live signal value into the descriptor, and synthesises descriptors for source-backed properties that don't exist on the raw target — this keeps `Object.keys`/`JSON.stringify`/spread consistent. |
| `ownKeys` | Reads `version` (making key enumeration reactive), then merges the target's own keys with source-backed keys, omitting any whose value is `UNINITIALIZED`. |
| `setPrototypeOf` | Always throws `state_prototype_fixed` — mutating state objects must not change their prototype. |

### The `with_parent` guard

Child sources are created lazily — possibly long after the proxy itself. `with_parent(fn)` temporarily restores the proxy's *original* `update_version` and clears `active_reaction` while creating the child source, so that a late-created child is never misattributed to whatever reaction happens to be running at creation time. This keeps dependency ownership stable when, e.g., an effect first writes to a property before ever reading it.

---

## Dependencies

### Inbound (consumers)

The proxy module sits near the bottom of the client runtime stack and is consumed widely:

```mermaid
graph LR
    subgraph "Consumers"
        C1["compiler output<br/>(compiled $state bindings)<br/>see: compiler_client_transform_state_and_reactivity"]
        C2["sources.js state()/set()<br/>client_runtime_core_sources"]
        C3["props.js prop()/rest_props()<br/>client_runtime_core_props"]
        C4["dev/equality.js equals()<br/>dev/ownership.js"]
        C5["hydration / render /<br/>blocks (each, keyed logic)"]
    end

    M["client_runtime_core_proxies<br/>proxy.js"]

    C1 --> M
    C2 --> M
    C3 --> M
    C4 --> M
    C5 --> M
```

- **Compiled component code** — the compiler's client transform emits `$.state(...)` for `$state` declarations; `state()` in [client_runtime_core_sources](client_runtime_core_sources.md) delegates object/array initialisation to `proxy()`.
- **`set(..., should_proxy = true)`** in sources.js — when a signal is written with an object/array value, it is wrapped via `proxy(value)` and then dev-tagged with `tag_proxy(new_value, source.label)`, which recursively propagates labels into fresh nested proxies.
- **Props plumbing** — `prop()` in [client_runtime_core_props](client_runtime_core_props.md) wraps bindable prop values (`props[key] = v`) so cross-component binding keeps working through `$state` objects.
- **Dev-mode equality** — `equals`/`strict_equals` in `client_dev_mode` use `get_proxied_value` to compare raw state and emit `state_proxy_equality_mismatch` when source-level and proxy-level comparisons disagree.

### Outbound (imports)

| Import source | Symbols used | Purpose |
| --- | --- | --- |
| `./runtime.js` → [client_runtime_core_runtime](client_runtime_core_runtime.md) | `get`, `active_effect`, `active_reaction`, `update_version`, `set_update_version`, `set_active_reaction` | Reading signals with dependency registration; reaction/version context management for `with_parent` |
| `./reactivity/sources.js` → [client_runtime_core_sources](client_runtime_core_sources.md) | `state` (as `source`), `set`, `increment`, `flush_inspect_effects`, `set_inspect_effects_deferred` | Creating per-property signals, performing reactive writes, bumping `version`, deferring `$inspect` around array mutations |
| `../shared/utils.js` → [shared_runtime](shared_runtime.md) | `array_prototype`, `object_prototype`, `get_prototype_of`, `get_descriptor`, `is_array` | Prototype checks and descriptor inspection used for proxyability and write-permission heuristics |
| `#client/constants` | `STATE_SYMBOL`, `PROXY_PATH_SYMBOL` | Branding symbol ("this is reactive state") and the dev-only relabelling hook |
| `../../constants.js` | `UNINITIALIZED` | Sentinel stored in sources for deleted/never-existing properties |
| `./errors.js` → [client_runtime_core_diagnostics](client_runtime_core_diagnostics.md) | `state_descriptors_fixed`, `state_prototype_fixed` | Invariant-violation errors thrown by `defineProperty` / `setPrototypeOf` traps |
| `./dev/tracing.js` → [client_dev_mode](client_dev_mode.md) | `tag`, `get_stack` | Attaching debug labels to sources and capturing "CreatedAt" stacks in tracing mode |
| `../flags/index.js` → [shared_runtime](shared_runtime.md) | `tracing_mode_flag` | Enables stack capture when tracing is compiled in |
| `esm-env` | `DEV` | Tree-shakeable development-mode gating |

---

## Data Flow

### Read path — making property access reactive

```mermaid
sequenceDiagram
    participant Effect as Effect / Derived<br/>(active reaction)
    participant Code as Compiled user code
    participant PX as proxy get trap
    participant SRC as sources Map
    participant RT as runtime.get()

    Code->>PX: state.count
    PX->>SRC: sources.get('count')
    alt source missing & own/writable prop
        PX->>PX: with_parent(() => source(proxy(value)))
        PX->>SRC: sources.set('count', s)
    end
    PX->>RT: get(s)
    RT-->>Effect: registers s in active_reaction.deps,<br/>links s.reactions
    RT-->>PX: s.v (UNINITIALIZED → undefined)
    PX-->>Code: value
```

Every read inside a tracked context wires the property's source into the reaction's dependency list via [client_runtime_core_runtime](client_runtime_core_runtime.md)'s `get()`. When the value is an object/array, the stored value is itself a nested `proxy`, so the graph deepens lazily along access paths.

### Write path — mutation to invalidation

```mermaid
sequenceDiagram
    participant Code as Compiled user code
    participant PX as proxy set trap
    participant SRC as sources.set()
    participant Batch as Batching / scheduler<br/>client_runtime_core_batching
    participant FX as Effects & deriveds<br/>client_runtime_core_effects/_deriveds

    Code->>PX: state.count = 42
    PX->>SRC: with_parent(() => proxy(42)) — deep-wrap new value
    PX->>SRC: set(source, wrappedValue)
    SRC-->>Batch: mark source dirty, schedule reactions
    opt new property
        PX->>PX: increment(version) — structural change
    end
    opt array index >= length
        PX->>SRC: set(lengthSource, n + 1)
    end
    Batch->>FX: flush dirty effects/deriveds
```

Writes are checked by sources.js for unsafe mutation (writing state synchronously from inside a derived/block effect raises `state_unsafe_mutation`) before being committed. Because the raw target is *never* mutated directly, the proxy target stays a pristine snapshot — this is what allows state to be forked and makes `getOwnPropertyDescriptor` synthesis necessary.

### Structural changes

`deleteProperty`, property-adding `set`/`defineProperty`, and array `length` truncation all call `increment(version)`. The `ownKeys` trap reads `version`, so shape-dependent operations (iteration, `Object.keys`, spread into another proxy, `{...state}`) participate in the same dependency graph as value reads.

---

## Component Interaction: Dev-Mode Path Propagation

`update_path` implements a distributed relabelling protocol across nested proxies. Every proxy advertises its `update_path` function under `PROXY_PATH_SYMBOL`; `tag_proxy(value, label)` (in [client_dev_mode](client_dev_mode.md)) invokes it on any value that has one. The result is that each nested proxy learns its fully-qualified path from its parent.

```mermaid
flowchart TD
    A["tag_proxy(value, label)<br/>(called by sources.set / tag)"] --> B{"value has<br/>PROXY_PATH_SYMBOL?"}
    B -- "no" --> Z["done"]
    B -- "yes" --> C["value[PROXY_PATH_SYMBOL](label)<br/>= update_path(new_path)"]
    C --> D{"already updating?"}
    D -- "yes" --> Z
    D -- "no" --> E["updating = true"]
    E --> F["path = new_path"]
    F --> G["tag(version, path + ' version')"]
    G --> H["for each child source:<br/>tag(source, get_label(path, prop))"]
    H --> I["tag calls tag_proxy(source.v, label)<br/>→ recursion into child proxy's update_path"]
    I --> J["updating = false"]
    J --> Z
```

Key properties of this protocol:

- **Recursion is parent-driven**: `tag()` labels a source *and* forwards the label into the value it holds. A child proxy therefore receives `parent.child` — not just `child` — and relabels its own subtree.
- **Re-entrancy guard**: the `updating` flag makes `update_path` idempotent while the loop over `sources` is in flight, preventing infinite mutual recursion between parent and child relabelling.
- **Purpose**: labels surface in `$inspect` output, `console.log` of state (via `log_if_contains_state`), `$inspect.trace()` and tracing-mode stack annotations (`tag` + `get_stack('CreatedAt')` in [client_dev_mode](client_dev_mode.md)).

`get_label` chooses the syntactically appropriate form per property: `path.prop` for valid identifiers, `path[3]` for numeric indices, `path['odd key']` or `path[Symbol(x)]` otherwise — driven by the `regex_is_valid_identifier` test.

---

## Process Flow: Array Mutation Instrumentation (`inspectable_array`)

In DEV, when a proxy wraps an array, the underlying value is first wrapped in a second, transient proxy whose only job is to intercept mutating methods:

```mermaid
sequenceDiagram
    participant Code as user code
    participant IA as inspectable_array proxy<br/>(DEV only)
    participant PX as reactive proxy traps
    participant I as $inspect effects

    Code->>IA: arr.push(x)
    IA->>IA: set_inspect_effects_deferred()
    IA->>PX: Reflect real method on target
    PX-->>IA: traps fire (set, length updates)
    IA->>I: flush_inspect_effects()
    Note over I: $inspect logs once,<br/>never an intermediate state<br/>(e.g. an emptied slot mid-splice)
    IA-->>Code: result
```

Without this wrapper, a single `splice` would trigger `$inspect` once per element change, logging torn intermediate snapshots. `ARRAY_MUTATING_METHODS` (`copyWithin`, `fill`, `pop`, `push`, `reverse`, `shift`, `sort`, `splice`, `unshift`) are the intercepted set; all other property access is transparent.

---

## Integration in the Overall System

```mermaid
graph TB
    subgraph "Compile time"
        T1["compiler_client_transform_state_and_reactivity<br/>emits $.state / $.get / $.set calls"]
    end
    subgraph "Reactive runtime engine"
        RT["client_runtime_core_runtime<br/>reactions, versions, get()"]
        P["client_runtime_core_proxies<br/>(this module)"]
        S["client_runtime_core_sources<br/>state / set / increment"]
        SIG["client_runtime_core_signal_model<br/>Signal flags, equality"]
        B["client_runtime_core_batching"]
        E["client_runtime_core_effects / deriveds"]
        PR["client_runtime_core_props"]
    end
    subgraph "Dev tooling"
        D["client_dev_mode<br/>tracing, inspect, ownership, equality"]
    end
    subgraph "Rendering backends"
        DOM["client_dom_renderer"]
    end

    T1 --> S
    S --> P
    PR --> P
    P --> RT
    P --> SIG
    S --> B
    B --> E
    P -. "DEV labels" .-> D
    E --> DOM
```

1. **Compiler contract** — the [Compiler Back-End client transform](compiler_client_transform_state_and_reactivity.md) assumes that anything produced by `$.state()` is signal-backed; the proxy fulfils this contract for object/array initial values while `$state(0)` style primitives are handled directly by sources.js.
2. **Props and bindings** — [client_runtime_core_props](client_runtime_core_props.md) relies on `proxy()` so that `bind:` against `$state` object props mutates the parent's state in place; `get_proxied_value` ensures identity comparisons in `prop()` fallback logic see through proxies.
3. **Each blocks and keyed reconciliation** — the DOM renderer's `each` block uses proxy-aware identity (`is`) and the per-property signal graph to surgically update rows when deep state mutates.
4. **Server symmetry** — the server runtime never uses proxies; `$state` on the server is plain values (see [server_runtime](server_runtime.md)). Proxy behaviour is client-only by design.

---

## Error Handling and Invariants

The module enforces several non-negotiable invariants, delegating message creation to [client_runtime_core_diagnostics](client_runtime_core_diagnostics.md):

| Invariant | Enforcement | Error |
| --- | --- | --- |
| State descriptors are fixed | `defineProperty` rejects non-basic descriptors (no getters/setters, no `configurable/enumerable/writable: false`) — otherwise Proxy `getOwnPropertyDescriptor` invariants would be violated since the target is never touched | `state_descriptors_fixed` |
| Prototypes are immutable | `setPrototypeOf` trap always throws | `state_prototype_fixed` |
| No writes during derived evaluation | Performed downstream in `sources.set()` (not here), which throws `state_unsafe_mutation` | raised by sources.js |
| Equality consistency (DEV) | `get_proxied_value` lets dev-mode equality compare raw values and warn on `state_proxy_equality_mismatch` | warning via dev/equality.js |

`get_proxied_value` also contains a notable robustness measure: reading `STATE_SYMBOL` off a cross-origin iframe's `contentWindow` throws, so the check is wrapped in `try/catch` — the value is then treated as an ordinary non-proxy rather than breaking third-party payment/embed scripts.

---

## Design Notes and Trade-offs

- **Lazy, per-property signals** keep memory proportional to what is actually touched, but mean the *first* write to a never-read property must still fabricate a source (the `set` trap does exactly this) so that later reads observe the write — otherwise effect heuristics would differ between read-before-write and write-only orders.
- **The raw target is never mutated.** All state lives in `sources`. This buys forkability (the target can be cloned/`structuredClone`d as the pristine snapshot) at the cost of descriptor synthesis in `getOwnPropertyDescriptor` and key merging in `ownKeys`.
- **`with_parent` context restoration** guards against a subtle ownership bug: a source created inside reaction A must not become a dependency of reaction B merely because B happened to trigger the property's first read/write.
- **Version counter for structure** avoids fan-out invalidation across every per-property signal on add/delete; only key-enumeration readers depend on `version`.
- **Eager `'length'` source for arrays** ensures methods like `push` (which mutate through indices and length) keep the proxy's length view in sync with iteration and `for...of` consumers.
- **DEV-only code paths** (`path` tracking, `get_stack` capture, `inspectable_array`, labelling) are gated on `esm-env`'s `DEV` and `tracing_mode_flag`, keeping the production bundle free of instrumentation — a property the repo verifies with [check-treeshakeability](svelte_build_tooling.md).

---

## Related Documentation

- [client_runtime_core_runtime](client_runtime_core_runtime.md) — reaction registry, `get()`, effect lifecycle
- [client_runtime_core_sources](client_runtime_core_sources.md) — `state`/`set`/`increment`, unsafe-mutation guard
- [client_runtime_core_signal_model](client_runtime_core_signal_model.md) — `Signal` structure and equality helpers
- [client_runtime_core_batching](client_runtime_core_batching.md) — how proxy writes get scheduled into batches
- [client_runtime_core_props](client_runtime_core_props.md) — component prop accessors built on top of proxies
- [client_dev_mode](client_dev_mode.md) — `tag`/`tag_proxy`, `$inspect`, tracing, ownership validation
- [client_runtime_core_diagnostics](client_runtime_core_diagnostics.md) — client error/warning catalogue
- [compiler_client_transform_state_and_reactivity](compiler_client_transform_state_and_reactivity.md) — the compiler side that emits calls into this module
