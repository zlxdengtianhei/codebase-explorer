# Client Runtime Core — Signal Model

## 1. Introduction

`client_runtime_core_signal_model` is the **foundational data model of Svelte 5's reactive runtime**. It defines:

1. **The signal type hierarchy** (`Signal`, `Value`, `Reaction`, `Derived`, `Effect`) — the plain-object shapes that everything reactive in the client runtime is built from (`$state`, `$derived`, `$effect`, props, stores, blocks).
2. **The equality semantics** (`equals`, `safe_equals`, `safe_not_equal`, `not_equal`) — the small set of functions that decide *whether a new value is "different enough" to trigger propagation* through the reactive graph.

The module is intentionally tiny: two numeric fields (`f` — a status flags bitmask, and `wv` — a write version) are the only contract every signal honors. Everything else is layered on top via structural interface composition rather than runtime inheritance. The correctness and throughput of the entire reactive system — dependency tracking, lazy derived evaluation, effect scheduling, and batching — rests on this model.

> **Position in the system:** This module lives inside [client_runtime_core](client_runtime_core.md), the reactivity kernel of the [Reactive Runtime Engine](./reactive_runtime_engine.md). Producer modules ([client_runtime_core_sources](client_runtime_core_sources.md), [client_runtime_core_deriveds](client_runtime_core_deriveds.md), [client_runtime_core_effects](client_runtime_core_effects.md)) instantiate these shapes; the orchestrator ([client_runtime_core_runtime](client_runtime_core_runtime.md)) and the scheduler ([client_runtime_core_batching](client_runtime_core_batching.md)) drive their lifecycle.

### In-module components

| Component | File | Role |
|---|---|---|
| `Signal` | `packages/svelte/src/internal/client/reactivity/types.d.ts` | Base interface: flags bitmask (`f`) + write version (`wv`) |
| `equals` / `safe_equals` / `not_equal` / `safe_not_equal` | `packages/svelte/src/internal/client/reactivity/equality.js` | Equality strategies attached to `Value.equals` |

---

## 2. The Signal Type Model

All reactive primitives are *structurally typed* plain objects — there is no class hierarchy at runtime. The interfaces below describe the shapes created and consumed across the reactivity modules.

```mermaid
classDiagram
    direction TB

    class Signal {
        <<interface base>>
        +number f  "flags bitmask"
        +number wv "write version"
    }

    class Value~V~ {
        <<interface>>
        +Equals equals
        +Reaction[]? reactions "signals reading FROM this"
        +number rv "read version"
        +V v "current value"
    }

    class Reaction {
        <<interface>>
        +ComponentContext? ctx
        +Function? fn "reaction body"
        +Value[]? deps "signals read BY this"
        +AbortController? ac
    }

    class Derived~V~ {
        +Function fn "derived function"
        +Effect[]? effects
        +Effect|Derived parent
    }

    class Effect {
        +TemplateNode? nodes_start
        +TemplateNode? nodes_end
        +Function? fn
        +Function? teardown
        +TransitionManager[]? transitions
        +Effect prev
        +Effect next
        +Effect first
        +Effect last
        +Effect parent
        +Boundary? b
    }

    class Source~V~ {
        <<type alias>>
    }

    Signal <|-- Value : extends
    Signal <|-- Reaction : extends
    Value <|-- Derived : extends
    Reaction <|-- Derived : extends
    Reaction <|-- Effect : extends
    Value <|.. Source : "= Value~V~"
```

### 2.1 `Signal` — the universal base

```ts
export interface Signal {
    /** Flags bitmask */
    f: number;
    /** Write version */
    wv: number;
}
```

- **`f` (flags)** — a bitmask from `packages/svelte/src/internal/client/constants.js`. It encodes *status*, *kind*, and *ownership* in one integer:

| Flag | Value | Category |
|---|---|---|
| `DERIVED` | `1 << 1` | Kind |
| `EFFECT` / `RENDER_EFFECT` / `BLOCK_EFFECT` / `BRANCH_EFFECT` / `ROOT_EFFECT` / `BOUNDARY_EFFECT` | `1 << 2` … `1 << 7` | Kind |
| `UNOWNED` / `DISCONNECTED` | `1 << 8` … `1 << 9` | Ownership |
| `CLEAN` / `DIRTY` / `MAYBE_DIRTY` | `1 << 10` … `1 << 12` | **Status** |
| `INERT` / `DESTROYED` / `EFFECT_RAN` | `1 << 13` … `1 << 15` | Lifecycle |
| `EFFECT_TRANSPARENT` / `INSPECT_EFFECT` / `HEAD_EFFECT` / `EFFECT_PRESERVED` / `USER_EFFECT` | `1 << 16` … `1 << 20` | Effect modifiers |
| `REACTION_IS_UPDATING` / `ASYNC` | `1 << 21` … `1 << 22` | Async |
| `ERROR_VALUE` | `1 << 23` | Error state — when set, `get()` re-throws the stored error |

- **`wv` (write version)** — a global monotonically increasing counter (via `increment_write_version()` in [client_runtime_core_runtime](client_runtime_core_runtime.md)). Every successful write bumps it. It is the backbone of dirty checking: a reaction compares a dependency's `wv` against the version recorded at its last read to decide whether re-execution is *actually* necessary (used heavily in `MAYBE_DIRTY` resolution).

### 2.2 `Value<V>` — a readable (source-like) node

Extends `Signal` with the *value* half of reactivity:

| Field | Purpose |
|---|---|
| `v` | The current value of the signal |
| `equals` | An `Equals` strategy: `(this: Value, value: unknown) => boolean`. Bound-method style — invoked as `signal.equals(newValue)` with the signal itself as `this` |
| `reactions` | **Downstream edges**: signals/effects that read from this value. Populated by `get()` during dependency tracking; walked by `mark_reactions()` on write |
| `rv` | **Read version** — stamped with the current global `read_version` when a reaction reads it, enabling cheap duplicate-dependency detection during re-tracking |

**Dev-only optional fields** (zero cost in production, populated when `tracing_mode_flag` or during effect runs):

| Field | Purpose |
|---|---|
| `label` | Variable name (e.g. `foo` from `let foo = $state(...)`) for `$inspect.trace()` output |
| `created` | Error object whose stack shows *when* the source was created |
| `updated` | Map of stack traces → creation count, showing *when/where* the source was updated |
| `set_during_effect` | Set when the source was written while an effect was running — forces it to appear dirty when that effect re-runs |
| `trace` | Hook used to map state across `each` block items during tracing |

### 2.3 `Reaction` — a node that reads signals

Extends `Signal` with the *consumer* half:

| Field | Purpose |
|---|---|
| `fn` | The reaction function (effect body, derived function, …) |
| `deps` | **Upstream edges**: `Value`s this reaction reads. Mirror image of `Value.reactions` |
| `ctx` | Associated `ComponentContext` (legacy callbacks, ownership) |
| `ac` | `AbortController` aborted when the reaction is destroyed/re-run (async signals) |

The two edge collections (`Value.reactions` ↔ `Reaction.deps`) form a **bidirectional reactive graph**: invalidation is *pushed* along `reactions` (cheap, write-time), while recomputation is *pulled* along `deps` (lazy, read-time).

### 2.4 `Derived<V>` — the dual-nature node

`Derived` extends **both** `Value` and `Reaction`: it *reads* other signals via `deps` and is itself *read* like a value. This duality is what makes lazy computation work:

- It is marked `DIRTY` when an upstream dependency changes, but does **not** recompute until someone `get()`s it.
- `update_derived()` (in [client_runtime_core_deriveds](client_runtime_core_deriveds.md)) executes `fn`, then consults `equals` — an equal result does **not** bump `wv`, cutting off downstream invalidation cascades.
- `parent` links it to its owning effect/derived for ownership and cleanup; `effects` collects effects created during evaluation so they can be destroyed on rerun/cleanup.

### 2.5 `Effect` — a reaction with DOM and lifecycle

Extends `Reaction` with:

- **DOM anchoring** — `nodes_start` / `nodes_end` bracket the rendered range so branch/each effects can be removed or moved wholesale.
- **Effect tree** — a doubly linked list per parent (`prev`/`next` siblings, `first`/`last` children, `parent`) enabling ordered creation, destroy, and subtree moves during `each` reconciliation.
- **Lifecycle** — `teardown` (user cleanup fn), `transitions`, `b` (owning error boundary, see [client_dom_renderer](client_dom_renderer.md)), and kind flags (`ROOT_EFFECT`, `BRANCH_EFFECT`, `BLOCK_EFFECT`, …).

### 2.6 Aliases

- `Source<V> = Value<V>` — semantic alias for writable/readable values used throughout the sources/props modules.
- `MaybeSource<T> = T | Source<T>` — for APIs that accept either a raw value or a signal (e.g. `prop()` in [client_runtime_core_props](client_runtime_core_props.md)).

---

## 3. Equality Semantics

Equality is the **single gatekeeper of propagation**: both write paths — `internal_set()` in [client_runtime_core_sources](client_runtime_core_sources.md) and `update_derived()` in [client_runtime_core_deriveds](client_runtime_core_deriveds.md) — skip value assignment, version bumping, and invalidation entirely when `signal.equals(newValue)` returns `true`.

```js
/** @type {Equals} */
export function equals(value) {
    return value === this.v;   // strict reference equality (default)
}

export function safe_not_equal(a, b) {
    return a != a
        ? b == b
        : a !== b || (a !== null && typeof a === 'object') || typeof a === 'function';
}

export function not_equal(a, b) {
    return a !== b;
}

/** @type {Equals} */
export function safe_equals(value) {
    return !safe_not_equal(value, this.v);
}
```

| Function | Semantics | Typical assignment |
|---|---|---|
| `equals` | Strict `===` reference equality | Default for `source()` and `derived()` (runes mode) |
| `safe_equals` / `safe_not_equal` | **NaN-aware** and **object-transparent**: any object or function is treated as "changed", so mutations through proxies always propagate | `mutable_source()` (unless `immutable`); widely used in legacy-mode code paths |
| `not_equal` | Plain strict inequality | Niche/legacy comparisons |

### 3.1 `safe_not_equal` decision flow

The "safe" strategy implements the same semantics as Svelte's long-standing `safe_not_equal` contract: two `NaN`s are *equal* (never loop forever), while object/function identity is *always unequal* (mutable containers can change without a new reference).

```mermaid
flowchart TD
    A["safe_not_equal(a, b)"] --> B{"a != a<br/>(a is NaN?)"}
    B -- "yes" --> C{"b == b<br/>(b is not NaN?)"}
    C -- "yes: only a is NaN" --> D["true → unequal"]
    C -- "no: both NaN" --> E["false → equal"]
    B -- "no" --> F{"a !== b"}
    F -- "yes: different primitives" --> D
    F -- "no: same reference" --> G{"a is object<br/>or function?"}
    G -- "yes: assume mutated" --> D
    G -- "no: identical primitive" --> H["false → equal"]

    style D fill:#ffe0e0
    style E fill:#e0ffe0
    style H fill:#e0ffe0
```

### 3.2 Why two strategies?

- **Strict (`equals`)** is cheap and precise for immutable-by-convention values. In runes mode, `$state` objects are wrapped in reactive **proxies** (see [client_runtime_core_proxies](client_runtime_core_proxies.md)) whose traps write to the underlying signal on mutation — so identity equality suffices for fine-grained updates.
- **Safe (`safe_equals`)** guards values that can be *mutated in place without the runtime noticing the new identity* — legacy reassignments, mutable component state, props — erring on the side of "notify" to preserve correctness at the cost of some redundant effect scheduling.

---

## 4. Write Path: From Assignment to Invalidation

The signal model's fields come alive in the write path. `set()` (write guard) delegates to `internal_set()`, which is the canonical example of how `equals`, `wv`, and `reactions` cooperate:

```mermaid
sequenceDiagram
    autonumber
    participant U as User code / binding
    participant SET as set (sources)
    participant IS as internal_set (sources)
    participant EQ as signal.equals (this module)
    participant B as Batch (batching)
    participant MR as mark_reactions (runtime)

    U->>SET: set(source, value)
    SET->>SET: unsafe-mutation guard<br/>(write during derived/block-effect?)
    SET->>IS: internal_set(source, new_value)
    IS->>EQ: source.equals(value) // this = source

    alt equals → true (unchanged)
        EQ-->>IS: true
        IS-->>U: value (no version bump, no invalidation)
    else equals → false (changed)
        EQ-->>IS: false
        IS->>IS: old_values.set(source, old_value)
        IS->>IS: source.v = value
        IS->>B: batch.capture(source, old_value)
        Note over B: rollback support for aborted batches
        IS->>IS: source.wv = increment_write_version()
        IS->>MR: mark_reactions(source, DIRTY)
        Note over MR: push DIRTY along source.reactions<br/>(scheduler picks it up later)
        IS->>IS: track untracked_writes for<br/>self-triggering effects
        IS-->>U: value
    end
```

Key model interactions on the write path:

1. **`equals` filters noise** — redundant writes (same primitive, same reference) are complete no-ops beyond the equality check itself.
2. **`wv` records causality** — the write version lets downstream reactions later distinguish "marked dirty but value is actually the same" from "genuinely new data" (the `MAYBE_DIRTY` resolution in the runtime).
3. **`reactions` is the invalidation frontier** — only direct readers are marked; deeper nodes are reached lazily when *their* readers pull on them.
4. **Dev instrumentation hooks in** — when `DEV`, `source.updated` is stamped with the write-site stack, and `set_during_effect` flags in-effect writes for `$inspect.trace()` diagnostics (see [client_dev_mode](client_dev_mode.md)).

### 4.1 Signal status lifecycle

The `CLEAN` / `DIRTY` / `MAYBE_DIRTY` flags in `f` implement a three-state protocol shared by `Derived` and `Effect`:

```mermaid
stateDiagram-v2
    [*] --> CLEAN : created (source(v) / derived(fn))
    CLEAN --> DIRTY : upstream write → mark_reactions
    CLEAN --> MAYBE_DIRTY : upstream became maybe-dirty
    DIRTY --> CLEAN : re-executed, value settled
    MAYBE_DIRTY --> DIRTY : dep.wv > recorded version<br/>(change confirmed)
    MAYBE_DIRTY --> CLEAN : all deps verified unchanged<br/>(wv check spared a rerun)
    DIRTY --> [*] : destroyed / branch discarded
```

`MAYBE_DIRTY` is the model's lazy-verification state: instead of eagerly recomputing on any transitive change, the runtime walks `deps` and compares write versions — recomputation happens **only if** a dependency's `wv` actually advanced since the last read.

---

## 5. Read Path: Dependency Tracking & Lazy Evaluation

`get(signal)` in [client_runtime_core_runtime](client_runtime_core_runtime.md) is the other half of the protocol. It turns every ordinary read into graph maintenance:

```mermaid
flowchart TD
    A["get(signal)"] --> B{"active_reaction present<br/>and not untracking?"}
    B -- "yes: reading inside a reaction" --> C{"signal.rv < read_version?"}
    C -- "yes: first read this cycle" --> D["signal.rv = read_version<br/>record dep in new_deps / deps"]
    D --> E["register back-edge:<br/>signal.reactions.push(active_reaction)"]
    C -- "no: already tracked" --> F["skip re-registration<br/>(skipped_deps optimization)"]
    B -- "no: untracked read" --> G["no graph mutation"]
    E --> H{"signal is Derived?"}
    F --> H
    G --> H
    H -- "yes" --> I{"is_dirty(derived)<br/>(status + wv/rv comparison)"}
    I -- "dirty" --> J["update_derived(derived)<br/>→ fn() → equals → wv bump"]
    I -- "clean" --> K["return cached value"]
    J --> K
    H -- "no" --> L{"f & ERROR_VALUE?"}
    L -- "yes" --> M["throw stored error"]
    L -- "no" --> N["return signal.v"]

    style D fill:#e8f0ff
    style J fill:#e8f0ff
    style M fill:#ffe0e0
```

The model fields used per step:

- **`rv` vs global `read_version`** — the `rv` stamp makes re-tracking idempotent: re-reading the same dependency many times within one reaction run registers it once, and the `skipped_deps` fast path avoids reallocating dependency arrays when a reaction re-runs with identical read order.
- **`deps` + `reactions`** — written together here, torn down by the runtime's dependency cleanup when a reaction's dep set changes between runs.
- **`f & ERROR_VALUE`** — turns `get()` into a throw point, so thrown derived/effect errors propagate at read time.
- **`equals` (via `update_derived`)** — recomputed-but-equal deriveds do not bump `wv`, so their dependents' `MAYBE_DIRTY` checks fail and never re-run. This is the principal mechanism that prunes over-invalidated subtrees.

---

## 6. Module Integration

The signal model defines the *nouns*; sibling modules provide the *verbs*. Composition map:

```mermaid
flowchart TD
    subgraph THIS["client_runtime_core_signal_model"]
        TYPES["types.d.ts<br/>Signal · Value · Reaction<br/>Derived · Effect · Source"]
        EQF["equality.js<br/>equals · safe_equals<br/>safe_not_equal · not_equal"]
    end

    subgraph KERNEL["Reactivity kernel (siblings)"]
        RUNTIME["client_runtime_core_runtime<br/>get · mark_reactions<br/>increment_write_version · is_dirty"]
        SRC["client_runtime_core_sources<br/>source · mutable_source<br/>set · internal_set · update"]
        DER["client_runtime_core_deriveds<br/>derived · execute/update_derived"]
        EFF["client_runtime_core_effects<br/>effect · branch · render effects"]
        BAT["client_runtime_core_batching<br/>Batch · capture · commit"]
    end

    subgraph CONSUMERS["Built on top of the model"]
        PROPS["client_runtime_core_props<br/>prop · rest_props · spread_props"]
        STORES["client_runtime_core_stores<br/>store_get · store_mutate"]
        PROXY["client_runtime_core_proxies<br/>$state deep reactivity"]
        ASYNC["client_runtime_core_async<br/>async deriveds · abort"]
        DOM["client_dom_renderer<br/>blocks & bindings"]
    end

    TYPES -- "instantiates shapes" --> SRC
    TYPES -- "instantiates shapes" --> DER
    TYPES -- "instantiates shapes" --> EFF
    EQF -- "assigned to Value.equals" --> SRC
    EQF -- "assigned to Derived.equals" --> DER
    TYPES -- "walks f · wv · deps · reactions" --> RUNTIME
    RUNTIME -- "schedules/flushes" --> EFF
    BAT -- "captures old values on write" --> SRC
    SRC --> PROPS
    SRC --> STORES
    PROXY -- "traps write to signals" --> SRC
    ASYNC -- "ac AbortController lifecycle" --> TYPES
    EFF -- "creates block/branch effects" --> DOM

    style THIS fill:#fff4d6
```

### Responsibilities per collaborator

| Module | Uses from this model | Responsibility |
|---|---|---|
| [client_runtime_core_runtime](client_runtime_core_runtime.md) | `f`, `wv`, `rv`, `deps`, `reactions` | `get()` (tracking + lazy derived eval), `mark_reactions()` (push invalidation), version counters, flush loops (`tick`, `run_tasks` scheduling — see [client_runtime_core_runtime](client_runtime_core_runtime.md)) |
| [client_runtime_core_sources](client_runtime_core_sources.md) | `Source`, `equals` | `source()` / `mutable_source()` factories, `set`/`internal_set` write path, `update`/`update_pre` increment helpers |
| [client_runtime_core_deriveds](client_runtime_core_deriveds.md) | `Derived`, `equals` | Lazy evaluation (`execute_derived`, `update_derived`), parent/ownership wiring, effect cleanup inside deriveds |
| [client_runtime_core_effects](client_runtime_core_effects.md) | `Effect` | Effect tree construction, branch/each DOM anchoring, teardown lifecycle |
| [client_runtime_core_batching](client_runtime_core_batching.md) | old-value capture of `Value`s | Transactional commits; `Batch.ensure()` is called inside `internal_set` |
| [client_runtime_core_props](client_runtime_core_props.md) | `Source`, `MaybeSource` | Component prop plumbing, `update_prop`/`update_pre_prop` mirror the `update`/`update_pre` pattern |
| [client_runtime_core_stores](client_runtime_core_stores.md) | `Value` + safe equality | Store subscriptions surface as signals; `store_get`/`store_mutate` bridge to the store contract |
| [client_runtime_core_proxies](client_runtime_core_proxies.md) | writes into proxied `Value`s | Deep `$state` — proxy traps call `set` on leaf signals, keeping `equals` strict |
| [client_runtime_core_async](client_runtime_core_async.md) | `Reaction.ac` | Abort-signal propagation and reactivity-loss tracking for async work |
| [client_dev_mode](client_dev_mode.md) | `label`, `created`, `updated`, `trace` | `$inspect`, tracing, ownership validation, HMR wrappers |

### Performance context

The two-field base design (`f` + `wv`) plus struct-of-plain-objects construction is deliberate: reactivity benchmarks ([reactivity_benchmarks](reactivity_benchmarks.md) — kairo, sbench, mol_bench suites) measure exactly the costs this model governs: signal creation, 1:1/1:N dependency graphs, diamond propagation, and unstable-dependency churn. The `rv`/`wv` versioning scheme exists to make the *avoidable re-run* benchmarks (e.g. `kairo_avoidable`) pass through `MAYBE_DIRTY` without executing reaction bodies.

---

## 7. Design Notes & Invariants

1. **Structural typing over classes** — signals are plain object literals shaped by these interfaces. This keeps construction allocation-cheap, enables per-instance field omission (dev-only fields), and preserves treeshakeability of the internal runtime (see `check-treeshakeability` in [svelte_build_tooling](svelte_build_tooling.md)).
2. **`equals` is part of the data, not the algorithm** — each `Value` carries its own strategy, so the same `internal_set`/`update_derived` code paths serve strict runes-mode values and safe legacy values without branching at call sites.
3. **`Equals` is a bound method** — `(this: Value, value: unknown) => boolean`. Strategies must be written to use `this.v` (as `equals`/`safe_equals` do); free-function comparators (`safe_not_equal`, `not_equal`) exist both as building blocks for the bound versions and for legacy direct use.
4. **`wv` strictly increases globally** — any code that writes `signal.v` *must* also bump `wv` (via `increment_write_version()`), otherwise downstream `MAYBE_DIRTY` verification will wrongly conclude "unchanged". Skipping the bump after `equals` is the sanctioned exception: an equal value *is* unchanged by definition.
5. **Mutation of `f` goes through `set_signal_status`** — status transitions maintain invariants relied upon by the scheduler (e.g. a derived only reaching `CLEAN` when fully resolved, `UNOWNED` flipping preserving other bits via `^`).
6. **Dev fields never gate logic in production** — `label`, `created`, `updated`, `set_during_effect`, `trace` are `undefined` outside `DEV`/tracing builds; hot paths must not branch on them.

---

## 8. Quick Reference

```ts
// The entire base contract:
interface Signal  { f: number; wv: number; }              // status + causality
interface Value<V> extends Signal { v: V; rv: number;     // data + read stamp
                                    reactions: Reaction[] | null; equals: Equals; }
interface Reaction extends Signal { fn; deps: Value[] | null; ctx; ac; } // consumer

type Equals = (this: Value, value: unknown) => boolean;

// Equality strategies (equality.js):
equals       // value === this.v              → default for source()/derived()
safe_equals  // NaN-safe; objects/functions always "changed" → mutable_source()
not_equal    // a !== b                       → free comparator
safe_not_equal // inverse of safe_equals      → legacy comparators
```

For how signals are created and written, see [client_runtime_core_sources](client_runtime_core_sources.md); for lazy computation, [client_runtime_core_deriveds](client_runtime_core_deriveds.md); for scheduling and the flush pipeline, [client_runtime_core_runtime](client_runtime_core_runtime.md) and [client_runtime_core_batching](client_runtime_core_batching.md); for dev-time introspection of the fields above, [client_dev_mode](client_dev_mode.md).
