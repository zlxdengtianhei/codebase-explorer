# compiler_preprocess_contracts

## 1. Introduction

`compiler_preprocess_contracts` is the **type-contract layer** of Svelte's preprocessor subsystem. It consists of a single declaration file — `packages/svelte/src/compiler/preprocess/public.d.ts` — that defines the public TypeScript interfaces through which *any* external tool (Vite plugins, `svelte-preprocess`, custom user code) plugs custom source transformations into the Svelte compiler pipeline.

The module defines five exported contracts:

| Export | Kind | Purpose |
|---|---|---|
| `Processed` | `interface` | The result object a preprocessor must return to describe its transformation |
| `MarkupPreprocessor` | callable `type` | Callback contract for transforming the **whole** `.svelte` file |
| `Preprocessor` | callable `type` | Callback contract for transforming `<script>` / `<style>` tag contents |
| `PreprocessorGroup` | `interface` | The aggregate unit (markup + script + style + name) passed by bundler tooling |
| `SveltePreprocessor` | `interface` | ⚠️ Deprecated helper type for wrapping a single preprocessor with options |

Because it is purely declarative, the module has **no runtime behavior of its own** — its value lies in being the stable, versioned seam between third-party preprocessor authors and the compiler's preprocessing engine (see [compiler_preprocess_engine](compiler_preprocess_engine.md)).

---

## 2. Role in the System Architecture

The contracts sit at the **outermost boundary of the compiler**, upstream of parsing. Before any `.svelte` code reaches `1-parse → 2-analyze → 3-transform`, build tooling may run it through a chain of preprocessors to convert TypeScript, SCSS/Sass, PostCSS, etc. into plain JS/CSS that the core compiler understands.

```mermaid
flowchart TB
    subgraph Tooling["External Tooling — implementers of the contracts"]
        VITE["vitePreprocess / svelte-preprocess"]
        CUSTOM["Custom user preprocessors"]
    end

    subgraph Public["Public API Surface"]
        SC["svelte/compiler entry<br/>(src/compiler/public.d.ts)"]
        ROOT["svelte root types<br/>(types/index.d.ts: Processed_1, SveltePreprocessor_1)"]
    end

    subgraph Contracts["compiler_preprocess_contracts (this module)"]
        PUB["preprocess/public.d.ts<br/>Processed · MarkupPreprocessor · Preprocessor · PreprocessorGroup · SveltePreprocessor"]
    end

    subgraph Engine["compiler_preprocess_engine (sibling module)"]
        PRE["preprocess(source, groups, options)<br/>process_markup · process_tag"]
    end

    subgraph CompilerCore["Compiler Front-End pipeline"]
        P1["1-parse"] --> P2["2-analyze"] --> P3["3-transform"]
    end

    VITE -- "implements PreprocessorGroup" --> PUB
    CUSTOM -- "implements MarkupPreprocessor / Preprocessor" --> PUB
    PUB -- "types re-exported" --> SC
    PUB -- "deprecated aliases" --> ROOT
    PRE -- "invokes callbacks & consumes Processed" --> PUB
    PRE -- "emits final Processed.code" --> P1
```

Key architectural relationships:

- **Upstream (consumers of the contract):** Build tools author objects satisfying `PreprocessorGroup`. They never touch compiler internals.
- **Downstream (enforcer of the contract):** The `preprocess()` engine in [compiler_preprocess_engine](compiler_preprocess_engine.md) is the single runtime consumer. It invokes each callback per the contract's call signature and interprets each returned `Processed` object.
- **Public exposure:** Types are re-exported from the `svelte/compiler` entry via `src/compiler/public.d.ts`; deprecated aliases exist in `preprocess/legacy-public.d.ts` ("import this from `svelte/preprocess` instead") and in the root `svelte` type namespace (`Processed_1`, `SveltePreprocessor_1`).
- **Internal boundary:** The engine keeps its own private types (`Source`, `SourceUpdate`, `Replacement` in `preprocess/private.d.ts`). Public contracts are deliberately decoupled from these internals (see §5.3).

---

## 3. Contract Reference

### 3.1 `Processed` — the transformation result

```ts
export interface Processed {
    code: string;
    map?: string | object;
    dependencies?: string[];
    attributes?: Record<string, string | boolean>;
    toString?: () => string;
}
```

| Field | Required | Scope | Contract semantics |
|---|---|---|---|
| `code` | ✅ | All | The transformed source text. For markup preprocessors: the whole file. For script/style preprocessors: the tag content only. |
| `map` | — | All | A source map mapping back to the input. Deliberately typed `string | object` (**opaque**) so public types don't depend on the `@jridgewell/remapping` module. A JSON string is auto-parsed by the engine. |
| `dependencies` | — | All | Extra files the preprocessor read (e.g., `@import`ed stylesheets); surfaced to bundler file watchers. |
| `attributes` | — | Script/style **only** | Replacement attributes for the tag's opening tag (e.g., drop `lang="ts"` after stripping types). If `undefined`, attributes are left unchanged. |
| `toString` | — | Top-level result | Optional legacy convenience so the final engine result stringifies to its code. |

> **No-op convention:** If a callback returns `void`/`undefined`, the input is assumed unchanged. The engine also treats `{ code: <unchanged content> }` without a map as a no-op for tags, preserving original sourcemap positions exactly.

### 3.2 `MarkupPreprocessor` — whole-file transform

```ts
export type MarkupPreprocessor = (options: {
    content: string;    // the whole Svelte file content
    filename?: string;  // the filename of the Svelte file
}) => Processed | void | Promise<Processed | void>;
```

Receives the *entire* component source and may rewrite it arbitrarily (e.g., injecting imports, rewriting markup-level syntax). Runs first within each group.

### 3.3 `Preprocessor` — per-tag transform (`<script>` / `<style>`)

```ts
export type Preprocessor = (options: {
    content: string;                            // the script/style tag content
    attributes: Record<string, string | boolean>; // attributes on the tag (e.g. { lang: "ts" })
    markup: string;                             // the whole Svelte file content
    filename?: string;
}) => Processed | void | Promise<Processed | void>;
```

The engine locates every `<script>`/`<style>` block via regex matching and invokes the callback once per tag, passing the parsed tag attributes plus full markup context. Returning `attributes` in the `Processed` result rewrites the emitted tag opening.

### 3.4 `PreprocessorGroup` — the bundler-facing unit

```ts
export interface PreprocessorGroup {
    name?: string;                    // will be REQUIRED in the next major version
    markup?: MarkupPreprocessor;
    style?: Preprocessor;
    script?: Preprocessor;
}
```

This is what tooling exports and users compose into arrays. `preprocess()` accepts a single group or an array; groups run **in array order**, and within each group the fixed order is **markup → script → style**.

### 3.5 `SveltePreprocessor` ⚠️ Deprecated

```ts
export interface SveltePreprocessor<
    PreprocessorType extends keyof PreprocessorGroup,
    Options = any
> {
    (options?: Options): Required<Pick<PreprocessorGroup, PreprocessorType>>;
}
```

A factory-type utility that produced a `PreprocessorGroup` containing exactly one required hook, letting downstream libraries expose typed single-purpose preprocessors. **Deprecated** — consumers should define this utility type themselves.

---

## 4. Type Relationship Model

```mermaid
classDiagram
    class Processed {
        +string code
        +string|object map
        +string[] dependencies
        +Record~string_string-or-boolean~ attributes
        +fn toString
    }
    class MarkupPreprocessor {
        <<callable type>>
        options : content, filename
        returns Processed or void (maybe Promise)
    }
    class Preprocessor {
        <<callable type>>
        options : content, attributes, markup, filename
        returns Processed or void (maybe Promise)
    }
    class PreprocessorGroup {
        +string name
        +MarkupPreprocessor markup
        +Preprocessor script
        +Preprocessor style
    }
    class SveltePreprocessor {
        <<deprecated>>
        returns Required Pick of PreprocessorGroup
    }
    MarkupPreprocessor ..> Processed : produces
    Preprocessor ..> Processed : produces
    PreprocessorGroup o-- MarkupPreprocessor : markup?
    PreprocessorGroup o-- Preprocessor : script? / style?
    SveltePreprocessor ..> PreprocessorGroup : wraps one hook
```

Both callable contracts produce the same `Processed` shape; the difference is entirely in their **input** context (whole file vs. per-tag content + attributes + markup).

---

## 5. How the Engine Interprets the Contracts

The `preprocess()` function ([compiler_preprocess_engine](compiler_preprocess_engine.md)) is the reference implementation of contract enforcement. A typical run:

```mermaid
sequenceDiagram
    autonumber
    participant T as Tooling (e.g. Vite plugin)
    participant E as preprocess() engine
    participant G as PreprocessorGroup(s)
    participant R as PreprocessResult (internal)

    T->>E: preprocess(source, group | groups, { filename })
    E->>R: new PreprocessResult(source, filename)
    loop each group, in array order
        opt group.markup is defined
            E->>G: markup({ content: fullSource, filename })
            G-->>E: Processed | void
            E->>R: update_source(code, parsed map, dependencies)
        end
        opt group.script is defined
            loop each <script> tag match
                E->>G: script({ content, attributes, markup, filename })
                G-->>E: Processed | void
                Note over E,R: rewrites tag attributes; stitches per-tag sourcemap with offset
            end
        end
        opt group.style is defined
            loop each <style> tag match
                E->>G: style({ content, attributes, markup, filename })
                G-->>E: Processed | void
            end
        end
    end
    E->>R: to_processed()
    R-->>T: Processed { code, map: combined, dependencies: deduped, toString }
```

Mapping of each contract field to engine behavior:

| Contract field | Engine handling |
|---|---|
| `Processed.code` | Replaces source (markup) or tag content (script/style); becomes the final `code` of the aggregate result. |
| `Processed.map` | String maps are `JSON.parse`d; decoded maps get position offsets (`sourcemap_add_offset`) and are chained (`sourcemap_list.unshift`) so all transformations compose into one final map via `combine_sourcemaps`. |
| `Processed.dependencies` | Accumulated across all hooks, de-duplicated (`[...new Set(...)]`) in the final result for file-watchers. |
| `Processed.attributes` | `stringify_tag_attributes` re-serializes them into the emitted `<script …>` / `<style …>` opening tag; if unchanged in length vs. original, the original tag text (and its mappings) is reused for fidelity. |
| `void` return | No-op — the original source slice is preserved byte-for-byte. |

---

## 6. Data Flow Through the Contract Boundary

```mermaid
flowchart LR
    A[".svelte source with<br/>lang='ts' script,<br/>lang='scss' style"] --> B["preprocess()<br/>engine"]
    B -->|"markup({content, filename})"| C["MarkupPreprocessor<br/>contract call"]
    B -->|"script({content, attributes:{lang:'ts'}, markup, filename})"| D["Preprocessor contract call<br/>(per script tag)"]
    B -->|"style({content, attributes:{lang:'scss'}, markup, filename})"| E["Preprocessor contract call<br/>(per style tag)"]
    C --> F["Processed"]
    D --> G["Processed<br/>+ attributes: {} (lang stripped)"]
    E --> H["Processed<br/>+ dependencies: ['vars.scss']"]
    F --> I["Combined result:<br/>code (plain JS/CSS),<br/>composed sourcemap,<br/>deduped dependencies"]
    G --> I
    H --> I
    I --> J["Compiler Front-End<br/>1-parse → 2-analyze → 3-transform"]
```

The essential effect of the contract boundary: after preprocessing, the compiler core only ever sees **plain JavaScript and CSS**, while source maps guarantee diagnostics still point at the original TypeScript/SCSS locations.

---

## 7. Public API Surface & Re-export Chain

```mermaid
flowchart TD
    A["preprocess/public.d.ts<br/>(this module — source of truth)"] --> B["src/compiler/public.d.ts<br/>re-exports: MarkupPreprocessor, Preprocessor,<br/>PreprocessorGroup, Processed"]
    B --> C["svelte/compiler entry<br/>(also exports the preprocess() function)"]
    A --> D["preprocess/legacy-public.d.ts<br/>⚠️ deprecated: 'import from svelte/preprocess instead'"]
    A --> E["packages/svelte/types/index.d.ts<br/>root namespace aliases: Processed_1, SveltePreprocessor_1"]
```

Consumer guidance:

- ✅ Import types from **`svelte/compiler`** (e.g., `import type { PreprocessorGroup } from 'svelte/compiler'`).
- ⚠️ Avoid the root-namespace aliases (`Processed_1`, `SveltePreprocessor_1`) and the deprecated `SveltePreprocessor` helper.
- The `name` field of `PreprocessorGroup` is optional today but **becomes required in the next major version** — tooling authors should set it now.

---

## 8. Design Decisions & Internal Boundary

1. **Opaque source maps.** `map?: string | object` intentionally avoids exposing `@jridgewell/remapping` types in the public API. The engine owns decoding/combining (`decode_map`, `combine_sourcemaps`), keeping the contract implementable by any transpiler that emits standard v3 source maps.
2. **Void-as-no-op.** All callbacks may return `void` or a `Promise<void>`, enabling conditional transforms (e.g., only act when `attributes.lang` is present) without synthetic results.
3. **Context-rich tag calls.** Script/style preprocessors receive `attributes` (routing on `lang=`), `markup` (whole-file context for position-aware tools), and `filename` — sufficient for tools like TypeScript or Sass compilers to produce accurate maps.
4. **Public/private split.** Engine internals (`Source`, `SourceUpdate`, `Replacement` in `preprocess/private.d.ts`) are never exposed. This module is the *only* documented seam; changing internal types is non-breaking, changing these contracts requires a semver-major release.
5. **Async-first, ordered composition.** Every hook is awaited sequentially; sourcemap chains are composed in reverse registration order so the final map reflects all transformations.

---

## 9. Relationship to Other Modules

| Module | Relationship |
|---|---|
| [compiler_preprocess](compiler_preprocess.md) | Parent module containing this contract layer and its engine. |
| [compiler_preprocess_engine](compiler_preprocess_engine.md) | Sibling and sole runtime consumer; implements the semantics described in §5. |
| [public_api](public_api.md) | Exposes `svelte/compiler` (including `preprocess` and these types) as the supported entry point. |
| [compiler_types_compiler_api](compiler_types_compiler_api.md) | The parallel contract layer for compile options/results (`CompileOptions`, `CompileResult`); the preprocess result's `code` feeds directly into `compile()`. |
| [compiler_migrate](compiler_migrate.md) | Fellow member of the Source-Migration & Preprocessing tooling area; migration output is ordinary `.svelte` source that may subsequently pass through these preprocessor contracts. |

---

## 10. Maintainer Notes

- **Stability guarantee:** This file *is* the public surface for preprocessor authors. Any edit here is an API change — treat with semver discipline. The only scheduled breaking change is the required `name` field on `PreprocessorGroup`.
- **Do not** add engine-specific fields to `Processed` (e.g., typed source-map structures); extend the internal `SourceUpdate` type in `private.d.ts` instead.
- The engine contains a few `@ts-expect-error` markers where JS internals and these strict contracts meet (`preprocess/index.js`); tightening those should not require contract changes.
- Tests for contract behavior live with the engine's test-suite (attribute rewriting, sourcemap composition, dependency aggregation) rather than in this module, since contracts alone have no behavior.
