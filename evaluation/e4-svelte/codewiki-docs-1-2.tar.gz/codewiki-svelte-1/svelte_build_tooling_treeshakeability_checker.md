# Svelte Build Tooling — Treeshakeability Checker

> Module: `svelte_build_tooling_treeshakeability_checker`
> Implementation: `packages/svelte/scripts/check-treeshakeability.js`
> Parent area: [Repository Engineering Infrastructure](Repository_Engineering_Infrastructure_(Benchmarks,_Build_Scripts___Playground).md)

## 1. Introduction

The treeshakeability checker is a build-time **quality gate** that enforces one of Svelte's core performance promises: *every public entry point of the `svelte` package must be fully tree-shakeable*, and *dev-only, legacy-only, and hydration-only code paths must never leak into a production bundle*.

It achieves this with a two-phase, self-hosted verification strategy:

1. **Export sweep** — for every condition (`browser` / `default`) of every export declared in `package.json` → `pkg.exports`, the script bundles a *bare import* of that entry file with Rollup. A pure, side-effect-free module must produce an **empty chunk**; any residual code means top-level side effects leaked into the module graph and the check fails.
2. **Feature-marker scan** — the script compiles a synthetic "kitchen-sink" Svelte component (using the real `svelte/compiler` `compile()` API), bundles it together with the client entry (`pkg.exports['.'].browser`), and asserts that known *conditional-only* code markers are **absent** from the result:
   - hydration markers (`hydrate_node`, `hydrate_next`),
   - legacy-mode markers (`component_context.l`),
   - dev tracing markers (`'CreatedAt'` from `$inspect.trace`).

A non-zero exit code and a dumped bundle artifact (`scripts/_bundle.js`) make the check CI-friendly and the failure immediately debuggable.

---

## 2. Module Structure

The module is a single self-contained ESM script executed by Node (it relies on **top-level `await`**):

| Symbol | Kind | Responsibility |
| --- | --- | --- |
| `bundle_code(entry)` | `async` function | Bundles a virtual entry string with Rollup and returns the single output chunk as trimmed source text. |
| `check_bundle(case_name, ...strings)` | function | Marker-presence assertion: reports ✅ when none of the strings appear in the current bundle, ❌ (with a code frame) otherwise. |
| *(top-level orchestration)* | script body | Loads `pkg`, runs the export sweep, compiles + bundles the feature component, runs marker checks, reports, exits. |

**Runtime dependencies** (dev tooling, not shipped):

- `node:fs`, `node:path`, `node:process` — file access, path resolution, exit code.
- `rollup` — bundling engine.
- `@rollup/plugin-virtual` — injects the synthetic `__entry__` module.
- `@rollup/plugin-node-resolve` — resolves third-party modules honoring export conditions.
- `svelte/compiler` — resolved *back to this repo's own compiler* via the custom resolver; supplies `compile()`.

---

## 3. Architecture

```mermaid
flowchart TB
    subgraph script["check-treeshakeability.js"]
        SWEEP["Phase 1 — Export sweep<br/>for key of pkg.exports (with skip list)"]
        COMPILE["Phase 2a — compile() of<br/>feature-complete component"]
        SCAN["Phase 2b — check_bundle()<br/>marker scan (hydration / legacy / dev)"]
        BUNDLEFN["bundle_code(entry)"]
        REPORT["Report ✅/❌ · write scripts/_bundle.js<br/>· process.exit(1) on failure"]
    end

    subgraph harness["Rollup bundling harness"]
        CORE["rollup(input '__entry__')<br/>+ bundle.generate()"]
        VIRT["@rollup/plugin-virtual<br/>(__entry__ = entry string)"]
        CUSTOM["resolve-svelte (custom plugin)<br/>pkg.exports[importee.replace('svelte','.')]"]
        NRES["@rollup/plugin-node-resolve<br/>conditions: production · import · browser · default"]
    end

    PKG["package.json<br/>(pkg.exports map)"]
    COMPILER["Compiler entry ('svelte/compiler')<br/>→ see Compiler Infrastructure"]
    CLIENT["Client public entry<br/>(pkg.exports['.'].browser)<br/>→ see Public API Surface"]
    RUNTIME["internal/client runtime<br/>(hydration · legacy · dev tracing)<br/>→ see Reactive Runtime Engine / Rendering Backends"]

    SWEEP --> BUNDLEFN
    COMPILE --> BUNDLEFN
    BUNDLEFN --> CORE
    CORE -. plugins .-> VIRT
    CORE -. plugins .-> CUSTOM
    CORE -. plugins .-> NRES
    CUSTOM --> PKG
    CUSTOM --> COMPILER
    CUSTOM --> CLIENT
    BUNDLEFN --> SCAN
    SCAN --> RUNTIME
    SCAN --> REPORT
```

### 3.1 `bundle_code(entry)` — the bundling harness

All verification funnels through this function. Its Rollup configuration encodes the checker's assumptions:

- **Virtual entry**: the `input` is always the synthetic module `__entry__`, whose content is the `entry` string passed by the caller (an `import "…"` statement or compiled component JS).
- **Custom `resolve-svelte` plugin**: any import starting with `svelte` is resolved *without hitting `node_modules`*. The plugin maps the specifier through the package's own export map:
  - `importee.replace('svelte', '.')` → export key (e.g. `svelte/internal/client` → `./internal/client`),
  - picks `entry.browser ?? entry.default` and returns `path.resolve(...)` of that file.
  This guarantees the check exercises **exactly the files a consumer would load** under the `browser`/`default` conditions.
- **`nodeResolve` with conditions `['production', 'import', 'browser', 'default']`**: forces the `production` condition so any dependency of the runtime also resolves to its production build.
- **Warning filtering**: `EMPTY_BUNDLE` (the *expected success signal* of Phase 1) and `CIRCULAR_DEPENDENCY` are swallowed; all other warnings are surfaced.
- **Single-chunk invariant**: if `bundle.generate({})` yields more than one chunk the script throws (`'errr what'`) — the checker only reasons about one flat chunk.
- Returns `output[0].code.trim()`, so an all-shaken-out module yields the empty string `''`.

### 3.2 Phase 1 — export sweep

The top-level loop iterates `pkg.exports` and skips five special cases:

| Skipped export key | Reason |
| --- | --- |
| `./compiler` | The compiler is a build-time tool, intentionally not side-effect-free client runtime. |
| `./internal` | Internal runtime plumbing barrel, not a consumer-facing pure leaf. |
| `./internal/disclose-version` | Deliberate side effect (version disclosure). |
| `./internal/flags/legacy` | Deliberate mode flag with initialization side effects. |
| `./internal/flags/tracing` | Deliberate mode flag with initialization side effects. |

For every remaining key, both `browser` and `default` conditions (when present) are checked:

1. `subpackage = path.join(pkg.name, key)`.
2. `code = await bundle_code('import "' + resolved-path + '"')`.
3. `code === ''` → `✅ <subpackage> (<type>)` treeshakeable; otherwise the residual code is printed, `❌` is reported, and the `failed` flag is set.

> **Design contract being verified:** importing an entry point for its types/exports only — with no call sites — must contribute **zero bytes**. Any top-level `fs` access, DOM touch, or eager initialization breaks this and is caught here.

### 3.3 Phase 2 — compiled-component marker scan

A feature-complete component is compiled with the real compiler API (this exercises the full [Compiler Front-End](Compiler_Front-End_(Parsing,_Analysis___CSS_Scoping_Pipeline).md) → [Compiler Back-End](Compiler_Back-End_(Client___Server_Code_Generation).md) pipeline of the *installed* `svelte/compiler`):

- `<svelte:options runes />`, `mount()` from the client entry,
- hydration-relevant features: `<svelte:head>`, `bind:value`, attribute/`class`, `{...spread}`,
- dynamic `<svelte:component>` / `<svelte:element>`, an attachment (`<C {foo} />`),
- `{#if}`, `{#each}`, `{#await}`, `{#key}`, `{#snippet}` + `{@render}`, `{@html}`.

The compiled `js.code` is bundled together with the client entry (`pkg.exports['.'].browser`), forcing the whole feature surface of the runtime into the graph. If every conditional-only pathway is correctly gated behind `DEV` / legacy-mode flags, Rollup eliminates it. `check_bundle` then asserts **absence** of:

| Case name | Marker string(s) | Source area (must be shaken out) |
| --- | --- | --- |
| `Hydration code` | `hydrate_node`, `hydrate_next` | Hydration template machinery of the client DOM renderer (`internal/client/dom/hydration.js`) — see [Component Rendering Backends](Component_Rendering_Backends_(Client_DOM___Server_SSR).md). |
| `Legacy code` | `component_context.l` | Legacy (pre-runes) component-context flags — see [Reactive Runtime Engine](Reactive_Runtime_Engine_(Signals,_Effects___Batching_with_Dev-Mode_Instrumentation).md) (`client_runtime_core_diagnostics` / legacy support). |
| `$inspect.trace` | `'CreatedAt'` | Dev-mode tracing metadata emitted for `$inspect.trace` instrumentation — see the `client_dev_mode` sub-module of [Reactive Runtime Engine](Reactive_Runtime_Engine_(Signals,_Effects___Batching_with_Dev-Mode_Instrumentation).md). |

### 3.4 `check_bundle(case_name, ...strings)`

```mermaid
flowchart TD
    A["check_bundle(case_name, ...strings)"] --> B{"For each string:<br/>bundle.indexOf(string) >= 0 ?"}
    B -- "not found (all strings)" --> C["✅ case treeshakeable"]
    B -- "found" --> D["❌ 'case not treeshakeable'<br/>failed = true"]
    D --> E["Extract 1000-char window<br/>(index − 500 … index + 500), split lines"]
    E --> F["Mark offending line with '>'<br/>print ±5 surrounding lines"]
    F --> G["return (first hit only)"]
```

The code-frame output points the maintainer directly at the first offending line, which is usually enough to identify which runtime file failed to be excluded.

---

## 4. End-to-End Process Flow

```mermaid
sequenceDiagram
    autonumber
    participant S as check-treeshakeability.js
    participant PKG as package.json (exports map)
    participant R as Rollup + plugins
    participant C as svelte/compiler
    participant K as check_bundle

    S->>PKG: read pkg, iterate pkg.exports
    Note over S: skip ./compiler, ./internal,<br/>disclose-version, flags/legacy, flags/tracing
    loop each export × (browser | default)
        S->>R: bundle_code('import "<resolved file>"')
        R-->>S: single chunk, trimmed code
        alt code === '' (EMPTY_BUNDLE expected)
            S->>S: ✅ subpackage (type)
        else residual code
            S->>S: ❌ print code, failed = true
        end
    end

    S->>C: compile(kitchen-sink App.svelte)
    C-->>S: js.code (client transform output)
    S->>R: bundle_code(js.code importing client entry)
    R-->>S: full-feature bundle

    S->>K: check_bundle('Hydration code', 'hydrate_node', 'hydrate_next')
    S->>K: check_bundle('Legacy code', 'component_context.l')
    S->>K: check_bundle('$inspect.trace', "'CreatedAt'")
    K-->>S: ✅ / ❌ per case

    alt any failure
        S->>S: write scripts/_bundle.js (full bundle)<br/>print artifact path
        S->>S: process.exit(1)
    end
```

### Data flow summary

```mermaid
flowchart LR
    E["pkg.exports entries"] -->|"virtual entry:<br/>import '<file>'"| BC["bundle_code"]
    CS["compile() output<br/>(js.code)"] --> BC
    CE["client entry<br/>(exports['.'].browser)"] --> BC
    BC -->|"output[0].code.trim()"| P1{"Phase 1:<br/>code === '' ?"}
    P1 -- yes --> OK1["✅ export pure"]
    P1 -- no --> BAD1["❌ side-effect leak"]
    BC -->|"bundle"| P2{"Phase 2:<br/>markers present?"}
    P2 -- no --> OK2["✅ hydration/legacy/dev<br/>code eliminated"]
    P2 -- yes --> BAD2["❌ code frame +<br/>scripts/_bundle.js"]
    BAD1 --> EXIT["exit 1"]
    BAD2 --> EXIT
```

---

## 5. Integration Within the System

The checker is the *enforcement arm* of design contracts defined elsewhere in the codebase:

| Related module | Relationship |
| --- | --- |
| [Public API Surface & Compatibility Layer](Public_API_Surface___Compatibility_Layer_(Entries,_Type_Contracts,_Extensions___Legacy_Support).md) | The `pkg.exports` map consumed by the sweep is defined by this module (`index-client.js`, `index-server.js`, store/motion/transition entries). The checker guards its treeshakeability guarantee; the root export's `browser` condition supplies the client entry used in Phase 2. |
| [Compiler Infrastructure](Compiler_Infrastructure_(Core_Orchestration,_Diagnostics___AST_Type_Model).md) | `compile` imported from `svelte/compiler` resolves (via the custom resolver) to the compiler entry (`compiler_core_entry`), which orchestrates the parse → analyze → transform pipeline. |
| [Compiler Front-End](Compiler_Front-End_(Parsing,_Analysis___CSS_Scoping_Pipeline).md) / [Compiler Back-End](Compiler_Back-End_(Client___Server_Code_Generation).md) | Implicitly exercised in Phase 2: the synthetic component flows through the parser, analyzer, and client transform visitors; the generated code is the actual input being scanned. |
| [Reactive Runtime Engine](Reactive_Runtime_Engine_(Signals,_Effects___Batching_with_Dev-Mode_Instrumentation).md) | Hosts the code regions whose *absence* is asserted: `client_dev_mode` (tracing/`$inspect` instrumentation, `'CreatedAt'`), legacy-mode context (`component_context.l`). These paths must stay behind `DEV`/mode flags for the check to pass. |
| [Component Rendering Backends](Component_Rendering_Backends_(Client_DOM___Server_SSR).md) | Hydration foundation (`hydrate_node` / `hydrate_next` in `dom/hydration.js`) must not appear in a non-hydrating bundle. |
| [Repository Engineering Infrastructure](Repository_Engineering_Infrastructure_(Benchmarks,_Build_Scripts___Playground).md) | Sibling build tooling (`svelte_build_tooling_message_templates`) and the benchmarking suite live in the same parent area; this script is part of the repo's engineering guardrails rather than shipped code. |

**Coupling note:** the marker strings are *implementation identifiers emitted by the runtime and compiler*. Renaming `hydrate_node`, changing the legacy context shape, or altering `$inspect.trace` metadata requires updating the marker list here — this is intentional, as the markers act as a frozen representation of "code that must never ship."

---

## 6. Output Contract

| Signal | Meaning |
| --- | --- |
| `✅ <subpackage> (<type>)` / `✅ <case> treeshakeable` | Individual check passed. |
| `❌ …` + residual code or code frame | Check failed; the offending source is printed inline. |
| `Full bundle at <cwd>/scripts/_bundle.js` | On any failure, the complete Phase-2 bundle is dumped for offline inspection. |
| Exit code `1` | Any check failed (suitable for CI gating). Exit code `0` only when every export and every marker check passes. |

Console output is wrapped in `console.group('checking treeshakeability')` for readable collapsed logs in CI.

---

## 7. Operating Notes

- **Working directory**: the script resolves `package.json` and writes `scripts/_bundle.js` relative to the current working directory — run it from `packages/svelte`.
- **Environment**: Node ESM with top-level `await` support.
- **Extending the sweep**: new public exports are picked up automatically from `pkg.exports`; deliberate side-effectful internals must be added to the skip list with a stated justification.
- **Extending Phase 2**: when new conditional-only runtime areas are introduced (e.g. additional dev instrumentation), add both (a) a feature to the synthetic component that pulls the code into the graph, and (b) a `check_bundle(...)` marker so regressions fail loudly.
- **Failure triage**: start from the printed code frame in the console; for deeper investigation open the dumped `scripts/_bundle.js` and search for the reported marker. The first failing case short-circuits its own scan, so fix and re-run iteratively.
