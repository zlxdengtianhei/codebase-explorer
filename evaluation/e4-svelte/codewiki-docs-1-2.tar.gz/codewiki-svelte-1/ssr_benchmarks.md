# SSR Benchmarks Module (`ssr_benchmarks`)

## 1. Introduction

The **`ssr_benchmarks`** module is the server-side rendering (SSR) performance suite of the Svelte repository's benchmarking infrastructure. It lives under `benchmarking/benchmarks/ssr/` and is a child module of the broader [Repository Engineering Infrastructure (Benchmarks, Build Scripts & Playground)](repository_engineering_infrastructure_(benchmarks,_build_scripts___playground).md) module.

Its purpose is to measure **how fast Svelte can render components on the server**, exercising the complete SSR path:

1. **Compile** a `.svelte` fixture with the compiler in `generate: 'server'` mode.
2. **Load** the generated server component module.
3. **Render** it repeatedly via `svelte/server`'s `render()` and measure wall-clock time and garbage-collection (GC) pressure.

Currently the suite contains a single benchmark, **`wrapper_bench`**, which acts as the canonical "end-to-end SSR throughput" measurement. Unlike the sibling [reactivity_benchmarks](repository_engineering_infrastructure_(benchmarks,_build_scripts___playground).md) suite (which micro-benchmarks the signal graph directly), this module measures the *component rendering* layer: the compiled server component function executed against the [Server Runtime](component_rendering_backends_(client_dom___server_ssr).md).

---

## 2. Module Layout

```
benchmarking/
├── run.js                              # Orchestrator (imports ssr_benchmarks suite)
├── utils.js                            # Shared timing/GC/IO utilities
└── benchmarks/
    └── ssr/                            # ← this module
        ├── index.js                    # Suite registry: exports ssr_benchmarks array
        └── wrapper/
            ├── wrapper_bench.js        # The benchmark implementation (wrapper_bench)
            ├── App.svelte              # (Expected fixture: SSR component under test)
            └── output/
                └── App.js              # (Generated artifact: compiled server component)
```

| File | Exported Component | Role |
|------|--------------------|------|
| `benchmarks/ssr/index.js` | `ssr_benchmarks` | Registry array consumed by `run.js` |
| `benchmarks/ssr/wrapper/wrapper_bench.js` | `wrapper_bench` | Benchmark: compile → import → render-loop timing |
| `benchmarking/utils.js` | `fastest_test`, `read_file`, `write` | Measurement harness (imported, not part of this module) |

---

## 3. Architecture & Component Relationships

The module is intentionally minimal: a suite registry plus one benchmark function. All heavy lifting (compilation, rendering, timing) is delegated to other modules.

```mermaid
flowchart TD
    subgraph Orchestration["Repository Engineering Infrastructure"]
        RUN["benchmarking/run.js<br/>(suite orchestrator)"]
        UTILS["benchmarking/utils.js<br/>fastest_test · read_file · write<br/>GarbageTrack · run_tracked"]
        REACT["reactivity_benchmarks suite"]
    end

    subgraph SSR["ssr_benchmarks (this module)"]
        IDX["benchmarks/ssr/index.js<br/>ssr_benchmarks = [wrapper_bench]"]
        WB["wrapper/wrapper_bench.js<br/>wrapper_bench()"]
        FIXTURE["App.svelte<br/>(fixture, read at runtime)"]
        OUT["output/App.js<br/>(generated artifact)"]
    end

    subgraph Compiler["Compiler Infrastructure / Back-End"]
        COMPILE["svelte/compiler → compile(source, { generate: 'server' })<br/>parse → analyze → server transform"]
    end

    subgraph ServerRuntime["Component Rendering Backends — Server Runtime"]
        RENDER["svelte/server → render(component)<br/>Payload · element · head · css_props …"]
    end

    RUN -->|"imports suite"| IDX
    RUN -->|"also runs"| REACT
    IDX -->|"iterates benchmarks"| WB
    WB -->|"read_file()"| FIXTURE
    WB -->|"compile()"| COMPILE
    COMPILE -->|"output.js.code"| OUT
    WB -->|"dynamic import(module.default)"| OUT
    WB -->|"render(App) × N"| RENDER
    WB -->|"fastest_test(10, fn)"| UTILS
```

### 3.1 Dependency Summary

| Direction | Dependency | Provided By |
|-----------|-----------|-------------|
| Outgoing | `compile` (source → server JS) | [Compiler Infrastructure](compiler_infrastructure_(core_orchestration,_diagnostics___ast_type_model).md) entry `packages/svelte/src/compiler/index.js` |
| Outgoing | `render` (component → HTML string) | [Server Runtime](component_rendering_backends_(client_dom___server_ssr).md), `packages/svelte/src/internal/server/index.js` |
| Outgoing | `fastest_test`, `read_file`, `write` | Shared benchmarking harness `benchmarking/utils.js` |
| Incoming | Suite consumption | `benchmarking/run.js` (production orchestrator) |

> The `compile` call funnels through the full [Compiler Front-End (Parsing, Analysis & CSS Scoping Pipeline)](compiler_front-end_(parsing,_analysis___css_scoping_pipeline).md) and then the server half of the [Compiler Back-End (Client & Server Code Generation)](compiler_back-end_(client___server_code_generation).md). The produced component, when invoked, drives the [Server Runtime](component_rendering_backends_(client_dom___server_ssr).md) primitives (`element`, `head`, `spread_attributes`, `css_props`, …). Details of those internals are documented in their respective modules and are not repeated here.

---

## 4. Component Reference

### 4.1 `ssr_benchmarks` (suite registry — `benchmarks/ssr/index.js`)

```js
export const ssr_benchmarks = [wrapper_bench];
```

- A flat array of **async zero-argument functions**, one per benchmark.
- Every entry must honor the module-wide **result contract** (see §6).
- `run.js` simply awaits each entry and accumulates the reported times; adding a new SSR benchmark is therefore a one-line change in this file.

### 4.2 `wrapper_bench` (`benchmarks/ssr/wrapper/wrapper_bench.js`)

The sole benchmark. It is split into a setup step and a measurement step:

**Setup — `compile_svelte()`**

```js
const output = compile(read_file(`${dir}/App.svelte`), { generate: 'server' });
write(`${dir}/output/App.js`, output.js.code);
const module = await import(`${dir}/output/App.js`);
return module.default;
```

1. Reads the `App.svelte` fixture from disk (`read_file` also normalizes CRLF → LF).
2. Compiles it in **server mode** — the compiler runs parse → analyze → the *server* transform visitors, emitting a component function that renders to strings (see [Compiler Back-End](compiler_back-end_(client___server_code_generation).md)).
3. Persists the generated code to `output/App.js` (the `write` helper creates parent directories recursively). This artifact doubles as a convenient debugging window into what the server transform produces.
4. Dynamically imports the artifact and returns the **default export** — the server component `function component(payload, props, …)` that `render()` will invoke.

**Measurement**

1. **JIT warm-up**: three unmeasured `render(App)` calls ensure V8 has optimized the hot path before timing begins (a convention shared with the reactivity suites).
2. **Timed phase**: `fastest_test(10, () => { for (let i = 0; i < 100; i++) render(App); })` — ten samples, each rendering the component 100 times; the fastest sample wins.
3. **Result**: returns the contract object with the benchmark name and both timings formatted to two decimals.

```mermaid
sequenceDiagram
    autonumber
    participant Runner as run.js (orchestrator)
    participant WB as wrapper_bench
    participant Utils as utils.js (fastest_test / GarbageTrack)
    participant Compiler as svelte/compiler
    participant FS as filesystem (App.svelte / output/App.js)
    participant Server as svelte/server (render)

    Runner->>WB: await wrapper_bench()
    WB->>FS: read_file(App.svelte)
    WB->>Compiler: compile(source, { generate: 'server' })
    Compiler-->>WB: { js: { code } }
    WB->>FS: write(output/App.js, code)
    WB->>FS: import(output/App.js)
    FS-->>WB: module.default (server component)

    loop 3 × JIT warm-up
        WB->>Server: render(App)
    end

    WB->>Utils: fastest_test(10, render ×100)
    loop 10 samples
        Utils->>Utils: v8.collectGarbage() + start GC observer
        Utils->>Server: render(App) ×100 (timed)
        Utils->>Utils: collect GC pauses in window
    end
    Utils-->>WB: fastest { timing: { time, gc_time } }
    WB-->>Runner: { benchmark, time, gc_time }
```

---

## 5. Measurement Methodology

The statistical rigor of the suite is provided entirely by `benchmarking/utils.js`; `wrapper_bench` only chooses the sample count (10) and inner workload (100 renders).

```mermaid
flowchart LR
    A["fastest_test(times = 10, fn)"] --> B["run_tracked(fn)"]
    B --> C["v8.collectGarbage()<br/>(forced GC before sample)"]
    C --> D["GarbageTrack.watch(run_timed(fn))<br/>records wall-clock window"]
    D --> E["PerformanceObserver 'gc' entries<br/>matched against window"]
    E --> F{"more samples?"}
    F -- yes --> B
    F -- no --> G["reduce → fastest sample by time"]
    G --> H["{ result, timing: { time, gc_time } }"]
```

Key properties:

- **Forced GC per sample** (`v8-natives.collectGarbage`) reduces cross-sample noise so samples are comparable.
- **GC time is observed, not inferred**: a `PerformanceObserver` subscribed to the `'gc'` entry type sums the durations of GC pauses whose `startTime` falls inside the timed window. This separates *rendering cost* from *garbage-collection cost* — two numbers with different optimization strategies.
- **Best-of-N reporting**: the fastest of 10 samples approximates the uncontended steady-state cost, minimizing the influence of background system activity.
- **`gc_time` attribution caveat**: a GC pause triggered by an earlier allocation can occasionally land in a later sample's window; treat `gc_time` as an indicator of allocation pressure rather than an exact per-render cost.

For `wrapper_bench`, the reported `time` is therefore: *milliseconds for 100 server-side renders of `App.svelte`, best of 10 samples* — i.e. the per-render cost is roughly `time / 100`.

---

## 6. Result Contract & Data Flow

Every benchmark in this module (and the sibling reactivity suite) returns the same shape, which `run.js` aggregates:

```js
{
    benchmark: 'wrapper_bench',  // identifier, echoed into logs
    time:    '<ms>',             // wall-clock ms, fastest of 10 samples (string, 2 decimals)
    gc_time: '<ms>'              // accumulated GC pauses during that sample (string, 2 decimals)
}
```

```mermaid
flowchart TD
    S["App.svelte source"] -->|"read_file"| C["compile({ generate: 'server' })"]
    C -->|"js.code"| W["output/App.js (artifact)"]
    W -->|"dynamic import"| M["Server component fn"]
    M -->|"render(App) × 300 warm-up<br/>+ 10 samples × 100"| R["RenderOutput:<br/>{ html, head, body }"]
    R -.->|"timed by"| T["timing { time, gc_time }"]
    T --> O["Result object (contract)"]
    O --> AGG["run.js aggregation:<br/>suite_time / suite_gc_time<br/>total_time / total_gc_time"]
```

`run.js` adds per-suite subtotals (`suite_time`, `suite_gc_time`) and grand totals (`total_time`, `total_gc_time`) and prints them; any thrown error (e.g. a missing fixture) aborts the run with a non-zero exit code. Note that the runner wraps the whole session in the client runtime's `$.push({}, true)` / `$.pop()` (see [Reactive Runtime Engine](reactive_runtime_engine_(signals,_effects___batching_with_dev-mode_instrumentation).md)) so that legacy-mode client APIs used by other suites behave during a shared process — the SSR suite itself does not depend on this.

---

## 7. How It Fits Into the Overall System

```mermaid
flowchart LR
    subgraph Bench["benchmarking/ (Repository Engineering Infrastructure)"]
        direction TB
        R["run.js"] --> RS["reactivity_benchmarks<br/>(signal-graph micro-benches)"]
        R --> SS["ssr_benchmarks<br/>(this module)"]
        CMP["compare/ tooling<br/>(branch-vs-baseline)"]
    end
    SS -->|"exercises"| CE["Compiler phases 1–3<br/>(Front-End + server Back-End)"]
    SS -->|"exercises"| SR["internal/server runtime<br/>(render, payload, blocks)"]
    CE & SR -.->|"the code whose perf<br/>is being guarded"| SRC["packages/svelte runtime+compiler"]
```

- **Guard rail for SSR regressions**: because `wrapper_bench` traverses compile → load → render, changes to the server transform visitors, payload model, or `render()` implementation are all reflected in its numbers. It complements the reactivity suite, which isolates the [signal/derived/batch engine](reactive_runtime_engine_(signals,_effects___batching_with_dev-mode_instrumentation).md) instead.
- **Consistent harness**: it reuses the exact timing utilities of the reactivity suites, so numbers across suites (and across git branches via the `compare/` tooling) are methodologically comparable.
- **Compared with reactivity benchmarks**: reactivity benches operate directly against `packages/svelte/src/internal/client/index.js` primitives (`$.state`, `$.derived`, `effect_root`), whereas this module only interacts with public entries (`svelte/compiler`, `svelte/server`), making it resilient to internal refactors.

---

## 8. Usage

### Running the suite

```bash
# from the repository root — runs both suites (reactivity + SSR)
node benchmarking/run.js
```

The SSR suite appears in the output as:

```
Running server-side rendering benchmarks...

{ benchmark: 'wrapper_bench', time: '12.34', gc_time: '0.56' }

Finished server-side rendering benchmarks.
```

### Adding a new SSR benchmark

1. Create `benchmarking/benchmarks/ssr/<name>/<name>_bench.js` exporting an async function.
2. In setup, compile your fixture with `generate: 'server'`, write/import the output (mirroring `compile_svelte()`), and JIT-warm the render path.
3. Measure with `fastest_test(samples, workload)` from `benchmarking/utils.js`.
4. Return the contract object from §6 with a unique `benchmark` name.
5. Register it in the `ssr_benchmarks` array in `benchmarks/ssr/index.js`.

---

## 9. Operational Notes & Caveats

- **Fixture requirement**: `wrapper_bench` reads `${dir}/App.svelte` at runtime. This file must exist in `benchmarking/benchmarks/ssr/wrapper/` or the run fails (the orchestrator exits with code 1). It is the perf-relevant input and should stay representative of real-world component shapes.
- **Generated artifacts**: `output/App.js` is produced on every run and is safe to delete/ignore; it exists to enable dynamic import of freshly compiled code and to aid manual inspection of server-transform output.
- **CWD dependence**: the fixture path is derived from `process.cwd()`, so the benchmark must be launched from the repository root (as `run.js` does).
- **Process environment**: meaningful GC measurements require a Node.js runtime where `PerformanceObserver` gc entries and the `v8-natives` hooks function; do not run with flags that suppress GC observation.
- **Warm-up count**: the 3-iteration warm-up mirrors the broader benchmarking conventions (some reactivity benches use 10); if you compare absolute numbers across suites, be aware of this difference.
- **Interpretation**: lower `time` = faster SSR throughput; elevated `gc_time` relative to peers usually indicates excess allocation in the render path (e.g. per-render object churn in payload handling).

---

## 10. Related Documentation

- [Repository Engineering Infrastructure (Benchmarks, Build Scripts & Playground)](repository_engineering_infrastructure_(benchmarks,_build_scripts___playground).md) — parent module: reactivity benchmarks, comparison tooling, build scripts.
- [Compiler Infrastructure (Core Orchestration, Diagnostics & AST Type Model)](compiler_infrastructure_(core_orchestration,_diagnostics___ast_type_model).md) — the `compile` entry point invoked by this module.
- [Compiler Front-End (Parsing, Analysis & CSS Scoping Pipeline)](compiler_front-end_(parsing,_analysis___css_scoping_pipeline).md) — parse and analyze phases executed during the setup step.
- [Compiler Back-End (Client & Server Code Generation)](compiler_back-end_(client___server_code_generation).md) — the server transform that produces the component under test.
- [Component Rendering Backends (Client DOM & Server SSR)](component_rendering_backends_(client_dom___server_ssr).md) — the Server Runtime `render()` measured by the benchmark loop.
- [Reactive Runtime Engine (Signals, Effects & Batching with Dev-Mode Instrumentation)](reactive_runtime_engine_(signals,_effects___batching_with_dev-mode_instrumentation).md) — the runtime whose `push`/`pop` the shared orchestrator activates; its client-side engine is covered by the sibling reactivity suite, not here.
