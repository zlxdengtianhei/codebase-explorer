# Client Dev Mode: HMR (Hot Module Replacement)

## 1. Introduction

`client_dev_mode_hmr` is the runtime half of Svelte's Hot Module Replacement (HMR) system. When an application is compiled with the `hmr` option enabled (i.e. during development with a bundler such as Vite), the compiler wraps every compiled component with machinery from this module. The result: when a `.svelte` file is edited and re-compiled, the new component version is **swapped into the running application in place** — no page reload, no loss of the surrounding component tree, and stale component-scoped CSS is cleaned up automatically.

The module consists of two files inside `packages/svelte/src/internal/client/`:

| File | Export | Role |
|---|---|---|
| `dev/hmr.js` | `hmr(original, get_source)` | Factory that wraps a compiled component with an HMR-aware wrapper and a reactive "component source" signal that acts as the update channel |
| `dev/hmr.js` | `wrapper(anchor, props)` *(inner, created by `hmr`)* | Drop-in replacement for the component function that survives hot updates by re-instantiating the latest component version into a stable `instance` object |
| `dev/css.js` | `cleanup_styles(hash)` | Removes all `<style>` elements registered under a component's CSS hash (used by the generated HMR accept handler when CSS changed) |
| `dev/css.js` | `register_style(hash, style)` *(supporting internal)* | Records injected `<style>` elements by CSS hash; called by `append_styles` in dev mode |

Both `hmr` and `cleanup_styles` (plus the `FILENAME` / `HMR` dev symbols) are re-exported from `svelte/internal/client`, which is why generated code can call them through the `$.` namespace (e.g. `$.hmr`, `$.HMR`, `$.cleanup_styles`).

> **Parent context:** This module is one of four dev-mode subsystems under [client_dev_mode](client_dev_mode.md), alongside [client_dev_mode_debugging](client_dev_mode_debugging.md), [client_dev_mode_validation](client_dev_mode_validation.md), and [client_dev_mode_locations](client_dev_mode_locations.md). Unlike most dev-mode code (which is purely additive diagnostics), HMR *changes the shape of the generated component*.

---

## 2. Architecture

HMR is a collaboration between three parties:

1. **The compiler** ([compiler_client_transform](compiler_client_transform.md)): when `options.hmr` is true, `transform-client.js` emits wrapper wiring and an `import.meta.hot.accept` handler instead of a plain `export default`.
2. **This module** (`dev/hmr.js`, `dev/css.js`): provides the runtime functions the generated code calls.
3. **The reactive runtime kernel** ([client_runtime_core](client_runtime_core.md)): supplies the signal/effect machinery that makes "replace the component" just another reactive update.

```mermaid
flowchart TB
    VITE["Bundler / dev server<br/>(e.g. vite-plugin-svelte)"] -->|"compile with hmr: true"| TC

    subgraph CT["Compile time — compiler_client_transform"]
        TC["transform-client.js<br/>(client_component)"] --> GEN["Generated module:<br/>- App[$.FILENAME] = 'App.svelte'<br/>- App = $.hmr(App, ...) inside if (import.meta.hot)<br/>- $.cleanup_styles(css.hash) in accept handler"]
    end

    GEN -->|"imported by the running app"| RT

    subgraph RT["Runtime — svelte/internal/client"]
        subgraph MOD["client_dev_mode_hmr (this module)"]
            HMRFN["hmr(original, get_source)"]
            WRAP["wrapper(anchor, props)"]
            SIG["wrapper[HMR].source<br/>(reactive source signal)"]
            CLEAN["cleanup_styles(hash)"]
            MAP[("all_styles Map<br/>(hash → style elements)")]
        end
        subgraph CORE["client_runtime_core"]
            EFF["block / branch /<br/>destroy_effect<br/>(reactivity/effects.js)"]
            SRC["source / set<br/>(reactivity/sources.js)"]
            GET["get<br/>(runtime.js)"]
        end
        INTRO["set_should_intro<br/>(render.js)"]
        HYD["hydrating / hydrate_node<br/>(dom/hydration.js)"]
        APPSTYLES["append_styles<br/>(dom/css.js, dev only)"]
    end

    HMRFN --> WRAP
    WRAP --> SIG
    WRAP --> EFF
    WRAP --> SRC
    WRAP --> GET
    WRAP --> INTRO
    WRAP --> HYD
    APPSTYLES -->|"dev only"| MAP
    CLEAN --> MAP
```

Key observation from the diagram: the wrapper and the accept handler never talk to each other directly. Their only shared state is the **`wrapper[HMR].source` signal**. The accept handler mutates that signal with `$.set(...)`, and the wrapper's effect — which tracks it via `get(source)` — simply re-runs. "Replace the component" is thereby expressed as an ordinary reactive update, reusing the entire scheduling, batching and effect-destroying machinery of [client_runtime_core_reactivity_effects](client_runtime_core_reactivity_effects.md) and [client_runtime_core_sources](client_runtime_core_sources.md).

---

## 3. Core API Reference

### 3.1 `hmr(original, get_source)`

```js
hmr(original, get_source) // → wrapper function
```

Wraps a compiled component function (`original`) and returns a wrapper with the same call signature `(anchor, props)`. The generated code immediately reassigns the exported binding: `App = $.hmr(App, () => App[$.HMR].source)`.

On the returned wrapper it attaches two dev-time properties (symbols from `src/constants.js`):

| Property | Value | Purpose |
|---|---|---|
| `wrapper[FILENAME]` | `original[FILENAME]` | Lets dev tooling and error messages identify the component by file (`'App.svelte'`), even after wrapping |
| `wrapper[HMR]` | `{ original, source: source(original) }` | The HMR record. `original` is the initial component version; `source` is a reactive [client_runtime_core_signal_model](client_runtime_core_signal_model.md) signal holding the *current* component version — the single point of indirection for all future updates |

A subtlety documented in the source: the `get_source` thunk reads `wrapper[HMR].source`, but the accept handler always overwrites `source` with `previous[HMR].source` first. In practice **the signal object is never replaced — only its value (`original`) is updated** via `$.set`. This keeps the reactive dependency graph stable across any number of hot updates.

### 3.2 `wrapper(anchor, props)` — the swapping component

Each call to the wrapper produces (or updates) one component *instance slot*:

```mermaid
flowchart LR
    subgraph W["wrapper(anchor, props)"]
        INST["instance<br/>(plain object, stable public identity)"]
        BLK["transparent block effect<br/>(EFFECT_TRANSPARENT)"]
        BR["branch effect<br/>(BRANCH_EFFECT + EFFECT_PRESERVED)"]
    end
    SIG["HMR source signal"] -->|"get(source)<br/>creates reactive dependency"| BLK
    BLK -->|"re-run: destroy old,<br/>create new"| BR
    BR -->|"component(anchor, props)"| V["component version N"]
    V -->|"Object.defineProperties(instance,<br/>Object.getOwnPropertyDescriptors(component(...)))"| INST
```

Lifecycle of a single wrapper invocation:

1. **Stable identity** — a plain `instance` object is created once and is the value returned to the caller. Parent code holding a reference to the component (e.g. `bind:this`, exports accessors) keeps a valid reference across hot updates.
2. **Tracking effect** — a `block(...)` effect with the `EFFECT_TRANSPARENT` flag (transparent effects do not create a transition boundary) is created. Inside it, `get(source)` reads the current component, registering a reactive dependency on the HMR source signal.
3. **On re-run (a hot update arrived):**
   - every own key of `instance` is deleted (`for (var k in instance) delete instance[k]`),
   - the previous `branch` effect is torn down via `destroy_effect`, which unmounts the old component's DOM and destroys its effects (transitions, bindings, listeners) through the normal effect lifecycle,
   - intro transitions are suppressed by bracketing the re-instantiation with `set_should_intro(false)` … `set_should_intro(true)` so enter animations do not replay on update.
4. **Re-instantiation** — a fresh `branch` effect instantiates the new component version: `component(anchor, props)`. The result's **property descriptors** (not just values) are copied onto the shared `instance` via `Object.defineProperties(Object.getOwnPropertyDescriptors(...))`, preserving getters/setters so props and exported accessors keep working and stay reactive.
5. **`new.target` propagation** — `new.target ? new component(anchor, props) : component(anchor, props)` lets the wrapper be invoked with `new` (legacy class-component style) and forwards construction mode to the real component. This pairs with the dev-mode `$.check_target` guard from [client_dev_mode_validation](client_dev_mode_validation.md).
6. **Hydration** — if the wrapper runs during hydration, `anchor` is advanced to `hydrate_node` so the new component version attaches to the server-rendered DOM rather than the raw comment anchor.

### 3.3 `cleanup_styles(hash)` and `register_style(hash, style)`

Component CSS is injected at mount time by `append_styles` (`dom/css.js`, see [client_dom_renderer](client_dom_renderer.md)). In dev mode, every injected `<style>` element is registered in a module-level `Map<hash, Set<HTMLStyleElement>>` via `register_style`. Styles are deduplicated by DOM id (the CSS hash), so if a hot update changes a component's CSS, the *old* `<style>` element would block the new one from ever being injected.

`cleanup_styles(hash)` closes that gap: it removes every registered style element for the given hash from the DOM and drops the registry entry. It is called by the generated `import.meta.hot.accept` handler *before* the component swap, guaranteeing that the freshly compiled CSS (with the same hash, new content) gets injected by the new component version.

---

## 4. Integration with the Compiler

When `options.hmr` is set, `transform-client.js` ([compiler_client_transform](compiler_client_transform.md)) replaces the plain `export default App` with the following emitted pattern (schematic):

```js
// dev only — file identity for diagnostics
App[$.FILENAME] = 'App.svelte';

function App($$anchor, $$props) { /* normal compiled component */ }

if (import.meta.hot) {
    // 1. Wrap: App becomes the swapping wrapper
    App = $.hmr(App, () => App[$.HMR].source);

    // 2. Accept updates pushed by the dev server
    import.meta.hot.accept((module) => {
        // 2a. If the component has CSS, drop stale styles first
        $.cleanup_styles('svelte-hash');

        // 2b. Chain the incoming module's HMR record to the existing signal
        module.default[$.HMR].source = App[$.HMR].source;

        // 2c. Push the new component version through the signal
        $.set(App[$.HMR].source, module.default[$.HMR].original);
    });
}

export default App;
```

Contract notes:

- The whole block is guarded by `if (import.meta.hot)`, so bundlers that do not provide an HMR context simply skip it.
- `$.hmr(...)` is called **once, at module evaluation time**, not per render. Component *usage* sites (`Component` visitor in [compiler_client_transform_components_and_scripts](compiler_client_transform_components_and_scripts.md)) are unaware of HMR — they just call the (wrapped) component like any other.
- The `FILENAME` symbol assignment is emitted for every component in dev mode (`if (dev)`), independent of HMR; the wrapper copies it forward so wrapped components remain identifiable.

---

## 5. End-to-End Hot Update Flow

```mermaid
sequenceDiagram
    autonumber
    participant Dev as Dev server (Vite)
    participant Gen as New compiled module
    participant Acc as import.meta.hot.accept handler
    participant Stl as cleanup_styles
    participant Sig as wrapper[HMR].source signal
    participant Blk as wrapper block effect
    participant Old as Old branch effect
    participant NewV as New component version

    Dev->>Gen: recompile App.svelte (hmr: true)
    Dev->>Acc: notify module update
    Acc->>Stl: $.cleanup_styles(css.hash)
    Stl-->>Acc: old <style> elements removed
    Acc->>Acc: module.default[HMR].source = App[HMR].source
    Acc->>Sig: $.set(source, module.default[HMR].original)
    Sig->>Blk: mark dirty, schedule re-run
    Blk->>Old: delete instance keys, destroy_effect(branch)
    Old-->>Blk: old DOM + effects destroyed
    Blk->>NewV: branch(() => component(anchor, props))<br/>(intros suppressed via set_should_intro)
    NewV-->>Blk: new property descriptors
    Blk->>Blk: defineProperties(instance, descriptors)
    Note over Blk: shared instance object identity preserved —<br/>external references stay valid
```

Observable result: the DOM region owned by the component is rebuilt from the new template, props continue to flow (the wrapper passes the same `props` object through), and enter transitions do not replay. Note that **component-internal state is not preserved** — the new version is constructed fresh; HMR in Svelte preserves *identity and bindings*, not local `$state` history.

---

## 6. Dependencies

| Dependency | Used for | Provided by module |
|---|---|---|
| `block`, `branch`, `destroy_effect` | Effect lifecycle for the swap (destroy old subtree, create new) | [client_runtime_core_reactivity_effects](client_runtime_core_reactivity_effects.md) |
| `source`, `set` | The HMR component source signal and its update channel | [client_runtime_core_sources](client_runtime_core_sources.md) |
| `get` | Reading/tracking the source signal inside the wrapper's block effect | [client_runtime_core_runtime](client_runtime_core_runtime.md) |
| `set_should_intro` | Suppressing intro transitions on hot re-mounts | [client_dom_renderer](client_dom_renderer.md) (`render.js`) |
| `hydrating`, `hydrate_node` | Re-anchoring during SSR hydration | [client_dom_renderer](client_dom_renderer.md) (`dom/hydration.js`) |
| `FILENAME`, `HMR` symbols | Dev metadata attached to wrappers (`src/constants.js`) | Compiler infrastructure / internal client index |
| `append_styles` → `register_style` | Dev-time style registration feeding the `all_styles` registry | [client_dom_renderer](client_dom_renderer.md) (`dom/css.js`) |
| `$.hmr`, `$.HMR`, `$.FILENAME`, `$.cleanup_styles` emission | Generated-call surface when `options.hmr` is set | [compiler_client_transform](compiler_client_transform.md) |

Sibling dev-mode modules that frequently appear in the same generated output: [client_dev_mode_debugging](client_dev_mode_debugging.md) (e.g. `$.FILENAME`-based messages), [client_dev_mode_validation](client_dev_mode_validation.md) (`$.check_target` for `new` misuse), [client_dev_mode_locations](client_dev_mode_locations.md) (`add_locations`).

---

## 7. Design Notes & Invariants

- **One signal to rule them all.** All update coordination flows through the single `wrapper[HMR].source` signal. The signal object survives across updates; only `$.set(source, newOriginal)` changes its value. This makes hot updates idempotent, order-independent, and compatible with the batching scheduler.
- **Transparent block effect.** `EFFECT_TRANSPARENT` ensures the wrapper's block does not create a transition boundary, so global/child transition semantics are unaffected by the extra effect layer.
- **Descriptor-level copy.** Copying `Object.getOwnPropertyDescriptors` (rather than `Object.assign`) preserves getters/setters from the component's exported/props surface, keeping two-way bindings and accessors live on the persistent `instance`.
- **Instance-key wipe before re-instantiation.** Deleting all own keys of `instance` prevents stale accessors from a previous component version lingering on the shared object (e.g. a prop removed in the update).
- **No intros on update.** `ran` distinguishes the initial instantiation (intros play) from hot re-instantiations (intros suppressed), avoiding full re-animation of the UI on every save.
- **CSS-first cleanup.** `cleanup_styles` runs *before* `$.set` in the accept handler; since `append_styles` skips injection when a `<style>` with the hash id already exists, removing old styles first is what makes CSS-only hot updates effective.
- **Production cost: zero.** The wrapper and the accept block are emitted only when `options.hmr` is set (development), and `register_style` is only called when `DEV` — the module is tree-shakeable from production bundles.
- **Failure mode.** If `import.meta.hot` is unavailable (plain bundler, SSR build), the `if (import.meta.hot)` guard reduces the emitted block to nothing and the component behaves as a normal compiled component.

---

## 8. See Also

- [client_dev_mode](client_dev_mode.md) — overview of all dev-mode instrumentation
- [client_runtime_core](client_runtime_core.md) — signals, effects and batching used by the swap mechanism
- [client_dom_renderer](client_dom_renderer.md) — DOM operations, `append_styles`, hydration
- [compiler_client_transform](compiler_client_transform.md) — where the HMR wiring is generated (`options.hmr`)
- [compiler_client_transform_components_and_scripts](compiler_client_transform_components_and_scripts.md) — `Component` visitor that instantiates components (HMR-agnostic call sites)
