# `svelte-be645b4` — Repository Overview

## Purpose

This repository contains the **Svelte framework**: a compiler-first UI framework in which `.svelte` single-file components (markup + scoped CSS + JavaScript) are compiled ahead-of-time into minimal, tree-shakeable vanilla JavaScript and CSS. The repo spans two halves of that story:

- **The compiler** (`packages/svelte/src/compiler`) — a three-phase pipeline (parse → analyze → transform) that produces both client-side bundles and server-side (SSR) render code, plus CSS scoping/pruning, diagnostics, and migration/preprocessing tooling.
- **The runtime** (`packages/svelte/src/internal`, `packages/svelte/src`) — a fine-grained reactive engine (signals, deriveds, effects, batching), client DOM and server SSR renderers, shared cross-runtime services, reactive state primitives (`svelte/store`, `svelte/reactivity`), motion/transitions, and the public API surface with legacy (Svelte 4) compatibility.

Supporting infrastructure — benchmarks, build scripts, and an interactive sandbox playground — round out the developer workflow.

## End-to-End Architecture

### Compile & render pipeline

```mermaid
flowchart LR
    src([".svelte source"]) --> pre["Preprocess"]

    subgraph Compiler["Compiler — packages/svelte/src/compiler"]
        pre --> parse["1. Parse<br/>(template state machine, JS/TS)"]
        parse --> analyze["2. Analyze<br/>(scope, template, JS visitors)"]
        analyze --> css["CSS pipeline<br/>(scoping and pruning)"]
        analyze --> transform["3. Transform"]
        transform --> cgen["Client transform<br/>(templates, reactivity, control flow)"]
        transform --> sgen["Server transform<br/>(SSR pipeline)"]
    end

    cgen --> out1(["client JS + CSS output"])
    sgen --> out2(["SSR render function"])

    subgraph Runtime["Runtime — packages/svelte/src/internal"]
        engine["Reactive runtime engine<br/>(signals, effects, batching)"]
        dom["Client DOM renderer<br/>(blocks, elements, bindings)"]
        ssr["Server SSR runtime<br/>(rendering core, payload model)"]
        shared["Shared services<br/>(flags, context, utilities)"]
    end

    out1 --> engine
    engine --> dom
    out2 --> ssr
    shared -. supports .-> engine
    shared -. supports .-> dom
    shared -. supports .-> ssr
```

### Layered module map

```mermaid
flowchart TD
    subgraph PublicAPI["Public API Surface and Compatibility Layer — packages/svelte"]
        EP["Entry points: svelte, svelte/compiler,<br/>svelte/client, svelte/server, svelte/store,<br/>svelte/motion, svelte/transition, svelte/reactivity"]
        EXT["Actions and attachments"]
        LEG["Legacy compat (Svelte 4)"]
        TY["Type contracts, elements.d.ts, HTML typings"]
    end

    subgraph State["Reactive State Primitives and Store Interop"]
        ST["Store contract / core / interop"]
        RC["Reactive built-ins: Map, Set, Date, URL, ..."]
    end

    subgraph VFX["Motion and Visual Effects"]
        MO["spring, tweened"]
        TR["transitions, animate:flip, easing"]
    end

    subgraph Core["Core Implementation"]
        COMP["Compiler (parse, analyze, transform)"]
        RUN["Reactive engine + DOM/SSR renderers"]
        SRV["Cross-runtime services (flags, context, diagnostics)"]
    end

    subgraph Infra["Engineering Infrastructure"]
        BM["Benchmarks (reactivity, SSR) and comparison tooling"]
        TOOLS["Build scripts, treeshakeability checker"]
        PG["playgrounds/sandbox"]
    end

    EP --> COMP
    EP --> RUN
    EXT --> RUN
    ST --> RUN
    RC --> RUN
    MO --> RUN
    TR --> RUN
    SRV --> RUN
    Infra -. dev tooling .-> Core
```

**A component's journey:** a `.svelte` file is preprocessed (e.g., TypeScript, PostCSS), parsed into template/JS/CSS ASTs, analyzed for reactivity and scoping (CSS is scoped and unused rules pruned), then transformed into either a client module wired to the reactive runtime (signals → effects → DOM updates) or an SSR function executed by the server runtime. Everything is surfaced through versioned public entry points, with `svelte-migrate` helping upgrade older code.

## Core Module Documentation

| Module | Scope | Docs |
|---|---|---|
| Compiler Front-End (Parsing, Analysis & CSS Scoping Pipeline) | Template state-machine parser, JS/TS handling; scope/block/template/JS analysis visitors; CSS analysis & transform | [Compiler Front-End](<Compiler_Front-End_(Parsing,_Analysis___CSS_Scoping_Pipeline).md>) |
| Compiler Back-End (Client & Server Code Generation) | Phase-3 client transform (templates, state/reactivity, control flow, elements/directives, components) and server transform pipeline | [Compiler Back-End](<Compiler_Back-End_(Client___Server_Code_Generation).md>) |
| Compiler Infrastructure (Core Orchestration, Diagnostics & AST Type Model) | Compile entry/options/state, AST builders, error/warning diagnostics, template/CSS/legacy AST types | [Compiler Infrastructure](<Compiler_Infrastructure_(Core_Orchestration,_Diagnostics___AST_Type_Model).md>) |
| Source Migration & Preprocessing Tooling | `svelte-migrate` codemods and `svelte-ignore` handling; preprocess engine & contracts | [Migration & Preprocessing](<Source_Migration___Preprocessing_Tooling.md>) |
| Reactive Runtime Engine | Signal model, sources, deriveds, effects, batching, proxies, props, stores bridge, async; dev-mode HMR, debugging, validation, locations | [Reactive Runtime Engine](<Reactive_Runtime_Engine_(Signals,_Effects___Batching_with_Dev-Mode_Instrumentation).md>) |
| Component Rendering Backends | Client DOM renderer (lifecycle, DOM foundation, blocks, elements/events, bindings) and server SSR runtime (rendering core, payload model, dev validation) | [Rendering Backends](<Component_Rendering_Backends_(Client_DOM___Server_SSR).md>) |
| Cross-Runtime Platform Services | Shared utilities, diagnostics, feature flags; context API for client and server | [Platform Services](<Cross-Runtime_Platform_Services_(Shared_Utilities,_Flags___Context_Injection).md>) |
| Public API Surface & Compatibility Layer | Package entry points, type contracts, HTML typings, actions/attachments, legacy client/server support | [Public API & Compatibility](<Public_API_Surface___Compatibility_Layer_(Entries,_Type_Contracts,_Extensions___Legacy_Support).md>) |
| Reactive State Primitives & Store Interop | Store contract/core/interop; reactive collections, temporal/URL primitives, environment & SSR classes | [State Primitives & Stores](<Reactive_State_Primitives___Store_Interop.md>) |
| Motion & Visual Effects System | `spring`/`tweened`; easing, flip animation, transitions | [Motion & Visual Effects](<Motion___Visual_Effects_System.md>) |
| Repository Engineering Infrastructure | Reactivity benchmarks (kairo, sbench, mol), SSR benchmarks, comparison tooling; build scripts & treeshakeability checker | [Engineering Infrastructure](<Repository_Engineering_Infrastructure_(Benchmarks,_Build_Scripts___Playground).md>) |
| Sandbox Playground | Interactive development playground (`playgrounds/sandbox`) | [Sandbox Playground](<sandbox-playground.md>) |