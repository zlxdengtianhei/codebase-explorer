# stores_core

> **Module scope:** `packages/svelte/src/store/shared/index.js`, `packages/svelte/src/store/utils.js`
> **Parent system:** [Reactive_State_Primitives___Store_Interop](Reactive_State_Primitives___Store_Interop.md)

## 1. Introduction

`stores_core` implements the **engine of Svelte's classic store contract**. It provides the factory functions `writable`, `readable`, `derived`, and `readonly`, plus the snapshot helper `get` and the low-level subscription utility `subscribe_to_store`. These functions are runtime-agnostic on the surface (usable in Node and the browser) but integrate deeply with the client reactive runtime: change detection uses the runtime's `safe_not_equal` semantics and subscriptions are established inside `untrack` so that store plumbing never leaks into the signal dependency graph.

The module is intentionally small and dependency-free of the compiler; everything here operates on plain objects conforming to the store interfaces declared in [stores_contract](stores_contract.md). Higher-level interoperability with runes (`fromStore`/`toStore`) is layered on top by [stores_interop](stores_interop.md).

### At a glance

| Export | Kind | Purpose |
| --- | --- | --- |
| `writable(value, start?)` | factory | Store with `set`, `update`, `subscribe`; manages start/stop notifier lifecycle |
| `readable(value, start?)` | factory | Read-only view over a `writable` (only `subscribe` is exposed) |
| `derived(stores, fn, initial_value?)` | factory | Reactive aggregation of one or more stores into a `Readable` |
| `readonly(store)` | adapter | Hides the write API of any store |
| `get(store)` | utility | One-shot subscribe/unsubscribe value snapshot |
| `update(fn)` *(internal)* | method | `set(fn(current))` inside `writable` |
| `subscribe_to_store(store, run, invalidate?)` | utility | Null-safe, untracked, RxJS-compatible subscription |

---

## 2. Architecture

### 2.1 Component relationships

`readable` and `readonly` are thin adapters; `derived` is a composition of `readable` + `subscribe_to_store`; everything funnels raw subscriptions through `subscribe_to_store`, and every value comparison goes through the runtime's `safe_not_equal`.

```mermaid
flowchart TB
    subgraph stores_core ["stores_core"]
        direction TB
        writable["writable(value, start)"]
        readable["readable(value, start)"]
        derived["derived(stores, fn, init)"]
        readonly["readonly(store)"]
        get["get(store)"]
        stt["subscribe_to_store(store, run, invalidate)"]
        updatefn["update(fn) — closure of writable"]
        setfn["set(value) — closure of writable"]
        queue["subscriber_queue — sync flush batching"]

        writable --> setfn
        writable --> updatefn
        updatefn --> setfn
        setfn --> queue
        readable -->|delegates subscribe| writable
        derived -->|creates backing store| readable
        derived -->|subscribes to inputs| stt
        derived -->|unsubscribes all| runall["run_all(unsubscribers)"]
        get --> stt
    end

    subgraph stores_contract ["stores_contract (types only)"]
        iface["Readable / Writable / Updater /\nStartStopNotifier / Unsubscriber"]
    end

    subgraph shared_runtime ["shared_runtime utilities"]
        noop["noop"]
        runall
    end

    subgraph client_runtime_core ["client runtime core"]
        sne["safe_not_equal(a, b)"]
        untrack["untrack(fn)"]
    end

    setfn --> sne
    writable --> noop
    derived --> noop
    stt --> untrack
    stt --> noop
    readable -.->|conforms to| iface
    writable -.->|conforms to| iface
    stt -.->|accepts Readable| iface
```

### 2.2 External dependencies (inbound/outbound)

```mermaid
flowchart LR
    subgraph outbound ["stores_core depends on"]
        direction TB
        A1["internal/shared/utils.js<br/>(noop, run_all) — shared_runtime"]
        A2["internal/client/reactivity/equality.js<br/>(safe_not_equal) — client_runtime_core"]
        A3["index-client.js → internal/client/runtime.js<br/>(untrack) — client_runtime_core"]
        A4["store/public.d.ts<br/>(type contracts) — stores_contract"]
    end

    subgraph inbound ["modules that depend on stores_core"]
        direction TB
        B1["stores_interop<br/>(fromStore / toStore use get + subscribe)"]
        B2["client runtime store bridge<br/>(reactivity/store.js: store_get, store_mutate,<br/>update_store, unsubscribe_stores)"]
        B3["server runtime<br/>(internal/server: derived, update_store,<br/>store_mutate, unsubscribe_stores)"]
        B4["motion<br/>(tweened.js, spring.js built on writable/derived)"]
    end

    stores_core --> A1
    stores_core --> A2
    stores_core --> A3
    stores_core -.-> A4
    B1 --> stores_core
    B2 --> stores_core
    B3 --> stores_core
    B4 --> stores_core
```

**Why `untrack` matters:** `subscribe_to_store` wraps every `store.subscribe(...)` call in `untrack`. Start/stop notifiers may legitimately mutate signals (e.g. a store seeding state on first subscriber); without `untrack` those mutations would be wrongly attributed as dependencies of whichever effect is currently running. See [client_runtime_core](client_runtime_core.md) for the `untracking` flag mechanics.

**Why `safe_not_equal` matters:** identical primitives are not re-broadcast (`NaN` handled via `a != a`), while fresh objects/arrays/functions always are. This keeps the store contract consistent with signal equality semantics in the reactive runtime.

---

## 3. Data & control flow

### 3.1 `writable` subscription lifecycle

The store lazily starts its `StartStopNotifier` when the **first** subscriber arrives and stops it when the **last** subscriber leaves. Each subscriber is stored as a `[run, invalidate]` tuple.

```mermaid
sequenceDiagram
    participant C as Consumer
    participant W as writable store
    participant S as StartStopNotifier (start)

    C->>W: subscribe(run, invalidate?)
    W->>W: subscribers.add([run, invalidate])
    alt first subscriber (size === 1)
        W->>S: start(set, update)
        S-->>W: optional stop function (defaults to noop)
    end
    W-->>C: run(current value) — immediate replay
    W-->>C: returns unsubscriber

    Note over C,W: ... later ...
    C->>W: unsubscriber()
    W->>W: subscribers.delete(tuple)
    alt last subscriber (size === 0)
        W->>S: stop()
        W->>W: stop = null
    end
```

### 3.2 `set` propagation and synchronous queue batching

`set(new_value)` only acts when `safe_not_equal(value, new_value)` holds **and** the store has started (`stop` is non-null). Invalidation callbacks (`invalidate`) for *all* subscribers run first (so derived stores can mark pending inputs), then `run` callbacks are invoked from a flat queue. If `set` is re-entered while a flush is in progress, the inner call enqueues its work and the **outermost** call performs the flush — giving one synchronous, deterministic propagation pass per top-level update.

```mermaid
flowchart TD
    A["set(new_value)"] --> B{"safe_not_equal(value, new_value)?"}
    B -- "no" --> Z0["no-op: same primitive"]
    B -- "yes" --> C["value = new_value"]
    C --> D{"store started?<br/>(stop !== null)"}
    D -- "no" --> Z1["no-op: no subscribers yet;<br/>value applied for next subscribe"]
    D -- "yes" --> E["run_queue = subscriber_queue.length === 0"]
    E --> F["for each subscriber tuple:<br/>1. tuple.invalidate()<br/>2. queue.push(tuple, value)"]
    F --> G{"run_queue (outermost call?)"}
    G -- "yes" --> H["flush: for i step 2,<br/>queue[i].run(queue[i+1])<br/>then queue.length = 0"]
    G -- "no" --> Z2["defer: outermost set() flushes"]
    H --> Z3["done — all subscribers updated once"]
```

### 3.3 `derived` synchronization algorithm

`derived` builds on `readable`, so it inherits the exact start/stop semantics above. Its notifier:

- Normalizes single-store input to an array; **rejects falsy stores** with `'derived() expects stores as input, got a falsy value'`.
- Chooses a mode: **auto** when `fn.length < 2` (a pure `(values) => T` function; its return value is auto-`set`), or **manual** when `fn` accepts `(values, set, update)` and may return a cleanup function.
- Uses a **bitmask** `pending` (`pending |= 1 << i` on input invalidate, `pending &= ~(1 << i)` on input run) so the aggregator only executes once all inputs have delivered an initial value — and never in between.
- Guards against zombie callbacks: after unsubscription, `started = false` prevents queued callbacks from re-syncing a dead derived store.

```mermaid
flowchart TD
    subgraph notifier ["readable notifier (runs on start)"]
        N1["init: values=[], pending=0, cleanup=noop, started=false"]
        N1 --> N2["subscribe to each input via subscribe_to_store"]
        N2 --> N3["started = true; sync()"]
    end

    subgraph onInput ["input callback (run)"]
        R1["values[i] = value"] --> R2["pending &= ~(1 << i)"] --> R3{"started?"}
        R3 -- "yes" --> SYNC
        R3 -- "no (stopped)" --> SKIP["ignore — store already torn down"]
    end

    subgraph onInvalidate ["input invalidate"]
        I1["pending |= 1 << i"]
    end

    subgraph sync ["sync()"]
        S1{"pending !== 0?"} -- "yes: some input lacks value" --> S1X["return"]
        S1 -- "no" --> S2["cleanup()"]
        S2 --> S3{"auto mode?<br/>(fn.length < 2)"}
        S3 -- "yes" --> S4["set(fn(values))"]
        S3 -- "manual" --> S5["result = fn(values, set, update)<br/>cleanup = typeof result === 'function' ? result : noop"]
    end

    subgraph stop ["stop() on last unsubscribe"]
        T1["run_all(unsubscribers)"] --> T2["cleanup()"] --> T3["started = false<br/>(queued callbacks become inert)"]
    end

    N3 --> SYNC
```

### 3.4 `get` and `subscribe_to_store`

`get(store)` performs a subscribe/first-emission/unsubscribe cycle and returns the captured value — the canonical way to read a store outside a reactive context. All subscriptions (including `derived`'s input subscriptions) flow through `subscribe_to_store`, which:

1. Short-circuits `null`/`undefined` stores by calling `run(undefined)` (+ `invalidate(undefined)`) and returning `noop` — this keeps multi-store `derived` code branch-free for optional stores.
2. Establishes the subscription inside `untrack(...)` so notifier side effects don't attach to the ambient reactive effect.
3. Normalizes the unsubscribe handle: RxJS observables return a subscription object with `.unsubscribe()`, which is wrapped into a plain function.

```mermaid
flowchart TD
    G["get(store)"] --> S["subscribe_to_store(store, capture, —)"]
    S --> N{"store == null?"}
    N -- "yes" --> NU["run(undefined); invalidate(undefined);<br/>return noop"]
    N -- "no" --> U["unsub = untrack(() => store.subscribe(run, invalidate))"]
    U --> R{"unsub.unsubscribe?<br/>(RxJS)"}
    R -- "yes" --> W1["return () => unsub.unsubscribe()"]
    R -- "no" --> W2["return unsub"]
    NU --> DONE["value captured → returned to caller"]
    W1 --> DONE
    W2 --> DONE
```

---

## 4. Component reference

### 4.1 `writable(value?, start?)` — `shared/index.js`

The foundational store. Returns `{ set, update, subscribe }` per the [`Writable`](stores_contract.md) contract.

- **`set(new_value)`** — see §3.2. Applies `safe_not_equal` gating and batched invalidation/run flush.
- **`update(fn)`** *(internal)* — sugar for `set(fn(value))`; the current value is passed with a type-assertion because the first emission always initializes it before user code runs.
- **`subscribe(run, invalidate?)`** — see §3.1. `invalidate` defaults to `noop`; `start` defaults to `noop` for purely in-memory stores.
- **Concurrency note:** `subscribers` is a `Set` of tuples, so iteration order is insertion order and re-subscribing the *same* tuple reference is idempotent.

### 4.2 `readable(value?, start?)` — `shared/index.js`

`{ subscribe: writable(value, start).subscribe }` — write methods are simply not exposed. The backing writable is garbage-collectable once its unsubscriber drops the last reference. This is also the substrate used by `derived`.

### 4.3 `derived(stores, fn, initial_value?)` — `shared/index.js`

JSDoc-overloaded factory (two public overloads + implementation):

| Mode | Trigger | `fn` signature | Cleanup |
| --- | --- | --- | --- |
| Auto | `fn.length < 2` | `(values) => T` | Not applicable — result is `set` synchronously |
| Manual | `fn.length >= 2` | `(values, set, update) => Unsubscriber \| void` | Returned function is stored as `cleanup` and re-invoked before each re-sync and on stop |

Accepts a single store or an array; `StoresValues` mapping (single value vs. tuple/array of values) is defined in `store/private.js` and typed in [stores_contract](stores_contract.md). Initial emissions of *all* inputs are coalesced via the `pending` bitmask (§3.3) so `fn` never observes partial initial state.

### 4.4 `readonly(store)` — `shared/index.js`

Returns `{ subscribe: store.subscribe.bind(store) }`. A one-line adapter over *any* store-like object (including foreign stores that merely satisfy `Readable`). Note the code comment: the `bind` is suspected unnecessary but retained for safety with non-plain store implementations.

### 4.5 `get(store)` — `shared/index.js`

Snapshot read: subscribes with a capturing callback, immediately unsubscribes, returns the value. Cheap and side-effect-correct for non-reactive contexts; inside effects prefer [stores_interop](stores_interop.md)'s rune-facing access instead, which subscribes persistently.

### 4.6 `subscribe_to_store(store, run, invalidate?)` — `store/utils.js`

The single subscription choke point (§3.4). Also used by the internal client runtime when bridging stores into runes (`reactivity/store.js`), which is why its untracked/RxJS-normalizing behavior must be preserved exactly.

---

## 5. Design notes & invariants

1. **Synchronous, single-pass propagation.** `set` invalidates all subscribers before running any, and flushes runs only at the outermost call. Combined with `derived`'s `pending` mask, a chain `writable → derived → derived` converges within one top-level `set` without intermediate inconsistent states escaping to observers.
2. **Lazy resource lifecycle.** External resources (timers, websockets, media queries — e.g. `MediaQuery`'s store facade) are acquired on first subscriber and released on last unsubscriber. Never call `subscribe` without keeping the unsubscriber, or the notifier leaks.
3. **Zombie-callback protection.** `derived.stop()` sets `started = false` *after* unsubscribing because callbacks may already be queued in `subscriber_queue`; the flag, not unsubscription alone, makes those callbacks inert.
4. **Runtime-agnostic, client-tuned.** The file itself runs fine on the server (the server runtime re-exports its own `derived`, `update_store`, etc. built on the same primitives), but two imports — `safe_not_equal` and `untrack` — come from the client runtime module graph; they are trivial/no-op-equivalent outside an active effect.
5. **Tree-shakeability.** Each factory is an independent export with no cross-factory eager state other than the lazily-used `subscriber_queue` array, so unused exports drop out of bundles (verified by `check-treeshakeability` tooling — see [svelte_build_tooling](svelte_build_tooling.md)).

---

## 6. Integration map

| Consumer | How it uses stores_core | Where documented |
| --- | --- | --- |
| `stores_contract` | Supplies `Readable`/`Writable`/`Updater`/`StartStopNotifier`/`Unsubscriber` type contracts implemented here | [stores_contract](stores_contract.md) |
| `stores_interop` | `fromStore` wraps `get(store)` for untracked snapshots and `store.subscribe` for persistent rune bridging; `toStore` exposes the reverse direction | [stores_interop](stores_interop.md) |
| Client runtime store bridge | `store_get`, `store_mutate`, `update_store`, `unsubscribe_stores` connect the legacy `$store` auto-subscription to the signal runtime, delegating to `subscribe_to_store` semantics | [client_runtime_core](client_runtime_core.md) |
| Server runtime | SSR rendering uses store-derived helpers (`derived`, `update_store`, `unsubscribe_stores`) when components mix stores into server-rendered output | [server_runtime](server_runtime.md) |
| Motion (`tweened`, `spring`) | Both are implemented as `writable`/`derived` stores whose value is animated over time | [motion](motion.md) |
| Shared runtime utilities | `noop` and `run_all` provide the null-object and bulk-unsubscribe primitives | [shared_runtime](shared_runtime.md) |

---

## 7. Usage sketches

```js
import { writable, derived, readonly, get } from 'svelte/store';

const count = writable(0, (set) => {
  console.log('first subscriber — start');
  return () => console.log('last unsubscriber — stop');
});

const doubled = derived(count, ($count) => $count * 2);          // auto mode
const logged = derived(count, ($count, set) => {                 // manual mode
  const id = setInterval(() => set($count), 1000);
  return () => clearInterval(id);                                // cleanup fn
}, 0);

const publicCount = readonly(count);                             // hide set/update
count.set(1);                        // invalidates + runs subscribers once
count.update((n) => n + 1);          // 2
get(doubled);                        // 4 — subscribe/unsubscribe snapshot
```

---

## 8. Related documentation

- [Reactive_State_Primitives___Store_Interop](Reactive_State_Primitives___Store_Interop.md) — parent system overview
- [stores_contract](stores_contract.md) — `Writable`/`Readable`/`Writable`-family type definitions this module implements
- [stores_interop](stores_interop.md) — runes ↔ store bridges (`fromStore`, `toStore`)
- [client_runtime_core](client_runtime_core.md) — `safe_not_equal`, `untrack`, and the runes store bridge
- [server_runtime](server_runtime.md) — SSR-side store helpers
- [shared_runtime](shared_runtime.md) — `noop`, `run_all` and cross-runtime utilities
- [motion](motion.md) — `tweened`/`spring`, the primary higher-level consumers of these factories
