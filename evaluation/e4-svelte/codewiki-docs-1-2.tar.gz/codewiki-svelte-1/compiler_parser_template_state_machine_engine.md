# compiler_parser_template_state_machine_engine

## 1. Introduction

`compiler_parser_template_state_machine_engine` is the **execution engine of the Svelte template parser's state machine**. It contains the single core component `parse()` (`packages/svelte/src/compiler/phases/1-parse/index.js`), which instantiates and drives the `Parser` class until the entire template source is consumed.

While the individual parser *states* (`fragment`, `element`, `text`, tag readers, …) are implemented in the sibling module [compiler_parser_template_state_machine_states](compiler_parser_template_state_machine_states.md), this module owns:

- the **public entry point** `parse(template, loose)` used by the compiler front-end,
- the `Parser` class that holds **all mutable parse context** (cursor, open-node stack, fragment stack, TypeScript flag, meta-tag bookkeeping),
- the **main state-transition loop** that repeatedly invokes state functions,
- **termination handling** (unclosed element/block detection, strict vs. loose recovery),
- **root finalization** (boundary trimming and `<svelte:options>` extraction).

The engine's output is an `AST.Root` (typed in [compiler_types_template_ast](compiler_types_template_ast.md)), the input to phase 2 of the compiler — see [compiler_analyzer](compiler_analyzer.md).

> **Module placement** — this is the leaf module of
> `compiler_parser_template_state_machine` → `compiler_parser` → [Compiler_Front-End_(Parsing,_Analysis___CSS_Scoping_Pipeline)](Compiler_Front-End_(Parsing,_Analysis___CSS_Scoping_Pipeline).md).

---

## 2. Purpose and Core Functionality

| Aspect | Description |
|---|---|
| **Input** | A Svelte component source string (`template`) and a `loose` flag for error-tolerant parsing. |
| **Output** | An `AST.Root` node containing the template `fragment`, top-level `js`/`css` chunks, parsed `options`, and `comments`. |
| **Strategy** | A hand-written, cursor-based **state machine**: a current-state function receives the `Parser` instance and returns the next state (or `void`, which defaults back to `fragment`). |
| **Error model** | In strict mode, malformed input raises `CompileError`s immediately (via [compiler_diagnostics_errors](compiler_diagnostics_errors.md)). In loose mode (`loose: true`, used by IDE/language tooling), the parser recovers and produces a best-effort AST. |
| **TS awareness** | The constructor pre-scans the source for `<script lang="ts">` to set `parser.ts`, enabling TypeScript-aware downstream parsing (see [compiler_parser_js_ts_processing](compiler_parser_js_ts_processing.md)). |

### 2.1 Public API

```js
/**
 * @param {string} template
 * @param {boolean} [loose]
 * @returns {AST.Root}
 */
export function parse(template, loose = false) {
        state.set_source(template);
        const parser = new Parser(template, loose);
        return parser.root;
}
```

`parse()` performs exactly three steps:

1. **Register the source** — `state.set_source(template)` (from [compiler_core_state](compiler_core_state.md)) stores the raw source in module-level compiler state and builds a line/column `locator` (via `locate-character`) used by *all* subsequent diagnostics and source maps.
2. **Run the engine** — `new Parser(template, loose)` executes the full state-machine loop in its constructor (see §4).
3. **Return the root** — `parser.root`, a fully-shaped `AST.Root`.

---

## 3. Architecture and Component Relationships

The engine is a *hub*: it owns the parse context and cursor primitives, and delegates all template-shape decisions to state functions. States never advance the cursor through raw index arithmetic alone — they rely on the engine's `eat` / `match` / `read*` primitives, which keeps cursor handling and error reporting centralized.

```mermaid
flowchart TB
    subgraph ENTRY["Compiler entry ([compiler_core_entry](compiler_core_entry.md))"]
        COMPILE["compile / compileModule"]
    end

    subgraph ENGINE["this module — state machine engine"]
        PARSEFN["parse(template, loose)"]
        PARSER["Parser class"]
        CURSOR["Cursor primitives<br/>eat / match / match_regex / read<br/>read_identifier / read_until<br/>allow_whitespace / require_whitespace"]
        TREE["Tree-building context<br/>stack / fragments / append / pop / current<br/>meta_tags / last_auto_closed_tag"]
        LOOP["Main loop<br/>state = state(parser) || fragment"]
        FINAL["Root finalization<br/>unclosed-node handling, boundary trim,<br/>svelte:options extraction"]
        PARSER --> CURSOR
        PARSER --> TREE
        PARSER --> LOOP
        PARSER --> FINAL
    end

    subgraph STATES["[compiler_parser_template_state_machine_states](compiler_parser_template_state_machine_states.md)"]
        FRAG["fragment (dispatcher)"]
        ELEM["element / read_attribute"]
        TXT["text"]
    end

    COMPILE --> PARSEFN
    PARSEFN --> PARSER
    LOOP -->|"invokes state fns"| STATES
    FRAG --> ELEM
    FRAG --> TXT
    PARSER -->|"AST.Root"| OUT["Phase 2: [compiler_analyzer](compiler_analyzer.md)"]
```

### 3.1 The `ParserState` protocol

The contract between engine and states is a single type alias:

```ts
/** @typedef {(parser: Parser) => ParserState | void} ParserState */
```

- A state function receives the `Parser` and does **one unit of work** (emit a text node, parse a tag, read attributes, …).
- It returns the **next state**, or returns nothing (`void`) — the loop then falls back to the default `fragment` dispatcher.
- State functions rely exclusively on the engine's cursor primitives, so the engine is the single source of truth for "where are we in the source".

This design makes the parser trivially extensible: adding syntax support means adding a state function in [compiler_parser_template_state_machine_states](compiler_parser_template_state_machine_states.md), not modifying the loop.

---

## 4. Engine Internals

### 4.1 `Parser` instance state

| Property | Type | Purpose |
|---|---|---|
| `template` | `string` (readonly) | The source, `trimEnd()`-ed in the constructor. |
| `loose` | `boolean` | Loose/recovering parsing mode (language-tooling friendly). |
| `index` | `number` | The cursor — the single position of the state machine. |
| `ts` | `boolean` | True when a `<script lang="ts">` was found; propagated as `root.metadata.ts`. |
| `stack` | `AST.TemplateNode[]` | Currently open nodes (`Root`, elements, blocks). Top of stack is the insertion parent. |
| `fragments` | `AST.Fragment[]` | Parallel to `stack`: the fragment each open node owns; `append()` writes into the innermost one. |
| `root` | `AST.Root` | The result skeleton created eagerly: `{ css: null, js: [], fragment, options: null, comments: [], metadata: { ts } }`. |
| `meta_tags` | `Record<string, boolean>` | Deduplication bookkeeping for root-only meta tags (`<svelte:head>`, `<svelte:window>`, …). |
| `last_auto_closed_tag` | `{ tag, reason, depth }?` | Remembers implicitly closed elements (e.g. `<li>` closed by the next `<li>`) so mismatched explicit closing tags can be diagnosed correctly. |

### 4.2 Cursor primitives (used by all states)

| Method | Behavior |
|---|---|
| `match(str)` | Lookahead test at the cursor (single-char fast path for performance). |
| `eat(str, required = false, required_in_loose = true)` | Consume `str` if it matches; otherwise raise `expected_token` when required — unless in loose mode and `required_in_loose` is false. |
| `match_regex(pattern)` / `read(pattern)` | Anchored (`^`-required) regex match/read at the cursor. |
| `read_until(pattern)` | Consume everything up to the first match of `pattern` (or EOF); errors with `unexpected_eof` at EOF in strict mode. |
| `read_identifier(allow_reserved)` | Unicode-aware identifier scanning using acorn's `isIdentifierStart`/`isIdentifierChar`; rejects reserved words via `is_reserved` (`unexpected_reserved_word`). |
| `allow_whitespace()` / `require_whitespace()` | Skip, or demand-and-skip, whitespace (`expected_whitespace`). |
| `acorn_error(err)` | Converts an acorn JS parse error into a compiler `js_parse_error`, stripping acorn's `(line:col)` suffix. |
| `current()` | Top of the open-node stack. |
| `append(node)` | Push a node into the innermost fragment; returns the node. |
| `pop()` | Close the current node: pops both the fragment and node stacks. |

---

## 5. The State Machine

### 5.1 State transition view

The `fragment` state is the *dispatcher*: it inspects the next character and delegates. `text` is the fall-through state that greedily consumes plain content. `element` handles tags (opening/closing, attributes, self-closing, special cases) via helpers from [compiler_parser_parse_utilities](compiler_parser_parse_utilities.md).

```mermaid
stateDiagram-v2
    direction TB
    [*] --> fragment : loop starts with state = fragment

    fragment --> element : parser.match('<')
    fragment --> tag : parser.match('{')
    fragment --> text : otherwise

    text --> fragment : Text node appended<br/>(returns void → default)
    tag --> fragment : expression / block consumed
    element --> fragment : node appended, closed,<br/>or stack adjusted
    element --> element : nested tags / attributes /<br/>auto-closing bookkeeping

    fragment --> [*] : index >= template.length
    note right of fragment
        state = state(parser) || fragment
        "void" returns fall back to fragment
    end note
```

### 5.2 Parse lifecycle (sequence view)

```mermaid
sequenceDiagram
    autonumber
    participant C as Compiler entry<br/>(compile / compileModule)
    participant P as parse()
    participant CS as compiler_core_state<br/>(set_source + locator)
    participant E as Parser engine
    participant ST as State functions<br/>(fragment / element / text)
    participant READER as read_options<br/>(parse utilities)

    C->>P: parse(source, loose?)
    P->>CS: set_source(source)
    Note over CS: source + line/col locator registered<br/>for all later diagnostics
    P->>E: new Parser(source, loose)
    E->>E: type-check input (TypeError if not string)
    E->>E: scan for <script lang="ts"> → this.ts
    E->>E: build AST.Root skeleton, push Root onto stack + fragments
    loop while index < template.length
        E->>ST: state(parser)
        ST->>E: use eat / read / append / pop primitives
        ST-->>E: next state (or void → fragment)
    end
    E->>E: handle unclosed nodes (loose: recover, strict: error)
    E->>E: trim Root start/end to content bounds
    E->>READER: read_options on svelte:options node
    READER-->>E: root.options (validated attributes)
    E-->>P: parser.root
    P-->>C: AST.Root
```

---

## 6. Constructor Flow: Initialization, Loop, Termination

### 6.1 Initialization details

1. **Input validation** — throws `TypeError` if `template` is not a string.
2. **Trailing whitespace trim** — `template.trimEnd()` normalizes the end of input.
3. **TypeScript detection** — `regex_lang_attribute` scans for a `<script ... lang="...">` attribute (comment-tolerant); the loop continues until a match whose second character is `s` (i.e. starts with `<s`), then `this.ts = match_lang?.[2] === 'ts'`. This flag later routes `<script>` contents to the TypeScript-aware JS parser in [compiler_parser_js_ts_processing](compiler_parser_js_ts_processing.md).
4. **Root skeleton** — `create_fragment()` (from the parse utilities) produces the empty `Fragment` node (with `metadata.transparent / dynamic / has_await` flags) used for `root.fragment`.

### 6.2 Main loop

```js
/** @type {ParserState} */
let state = fragment;

while (this.index < this.template.length) {
    state = state(this) || fragment;
}
```

Every iteration is one state transition. States either return the next state explicitly or return `undefined`, which re-enters `fragment` (the dispatcher).

### 6.3 Termination and recovery

After the loop, the engine validates that the document closed cleanly:

```mermaid
flowchart TD
    A["loop finished (index >= length)"] --> B{"stack.length > 1?"}
    B -- "yes, loose mode" --> C["current().end = template.length<br/>(silently close open node)"]
    B -- "yes, strict + RegularElement" --> D["element_unclosed(current, name)<br/>(CompileError)"]
    B -- "yes, strict + block/other" --> E["block_unclosed(current)<br/>(CompileError)"]
    B -- no --> F{"final state !== fragment?"}
    C --> F
    D --> X1["throw"]
    E --> X1
    F -- yes --> G["unexpected_eof(index)<br/>(e.g. unterminated expression tag)"]
    F -- no --> H["proceed to root finalization"]
    G --> X1
```

Error functions come from [compiler_diagnostics_errors](compiler_diagnostics_errors.md); the errors themselves are modeled by [compiler_diagnostics_diagnostic_model](compiler_diagnostics_diagnostic_model.md).

### 6.4 Root finalization

1. **Boundary trimming** — if the root fragment has nodes, `root.start`/`root.end` are narrowed to the first/last non-whitespace characters of the first/last top-level nodes; otherwise both are `null`.
2. **`<svelte:options>` extraction** — the `SvelteOptions` node is spliced out of the root fragment and passed to `read_options()` (from [compiler_parser_parse_utilities](compiler_parser_parse_utilities.md)), which validates attributes (`runes`, `namespace`, `customElement`, `css`, …) into `root.options`. The shared analyzer helper `disallow_children(options)` then rejects any content inside the tag. A non-enumerable `__raw__` property retains the raw node for the legacy AST format.

---

## 7. Strict vs. Loose Parsing

The `loose` flag exists primarily for IDEs / language tooling, where a half-typed document must still yield a usable AST:

| Behavior | Strict (`loose = false`) | Loose (`loose = true`) |
|---|---|---|
| Unclosed element/block at EOF | `element_unclosed` / `block_unclosed` error | Node closed at `template.length`; parse continues |
| Required token (`eat(..., true, false)`) | `expected_token` error | Silently tolerated when `required_in_loose` is false |
| Unterminated trailing construct (`read_until` at EOF) | `unexpected_eof` | Returns `''` and continues |
| Mis-tokenized attribute (e.g. stray `<` of a following tag eaten as attribute name) | n/a (well-formed input) | The element state backtracks the cursor and drops the bogus attribute, re-parsing the tag boundary |
| Invalid element names mid-typing (e.g. `<div.`) | `tag_invalid_name` | Tolerated when the name ends with `.` |

Loose-mode backtracking heuristics live in the `element` state (see [compiler_parser_template_state_machine_states](compiler_parser_template_state_machine_states.md)); the engine supports them via the shared `eat`/`match` cursor and the `last_auto_closed_tag` bookkeeping.

---

## 8. Data Flow

```mermaid
flowchart LR
    SRC["source string"] --> TRIM["trimEnd + TS detection"]
    TRIM --> SM["State machine loop<br/>(this module)"]
    SM --> N1["AST.Text nodes"]
    SM --> N2["AST.RegularElement / Component /<br/>Svelte meta elements"]
    SM --> N3["AST.Comment"]
    SM --> N4["script/style contents →<br/>root.js / root.css"]
    N1 & N2 & N3 --> FRAG["root.fragment<br/>(nested AST.Fragment nodes)"]
    N4 --> ROOT["AST.Root"]
    FRAG --> ROOT
    OPTS["<svelte:options> → read_options"] --> ROOT
    ROOT --> ANALYZE["Phase 2 analyze<br/>([compiler_analyzer](compiler_analyzer.md))"]
    ROOT --> LANGTOOLS["loose parse for<br/>language tooling"]
```

Notable tree-building invariants maintained by the engine:

- `stack` and `fragments` are **parallel stacks** — every open node pushes both, `pop()` removes both, so `append()` always targets the correct parent fragment.
- Self-closing / void elements and `<textarea>`, `<script>`, `<style>` (whose raw content is read as a single `Text` node) never push onto the stack.
- Implicit closing (e.g. `<li>a<li>b`) is handled in the `element` state, which pops parents directly; `last_auto_closed_tag` records `{ tag, reason, depth }` so the engine/state can distinguish legitimate auto-close from a genuinely mismatched `</tag>`.

---

## 9. Dependencies

### 9.1 Internal module dependencies

```mermaid
flowchart LR
    ENGINE["this module<br/>parse / Parser"]

    subgraph PARENT["[compiler_parser_template_state_machine](compiler_parser_template_state_machine.md)"]
        STATES["[compiler_parser_template_state_machine_states](compiler_parser_template_state_machine_states.md)<br/>fragment / element / text"]
    end

    UTIL["[compiler_parser_parse_utilities](compiler_parser_parse_utilities.md)<br/>read_options, create_fragment,<br/>entity decoding, patterns"]
    JSTS["[compiler_parser_js_ts_processing](compiler_parser_js_ts_processing.md)<br/>acorn parse, TS node removal"]
    CSTATE["[compiler_core_state](compiler_core_state.md)<br/>set_source / locator / warnings"]
    ERR["[compiler_diagnostics_errors](compiler_diagnostics_errors.md)<br/>element_unclosed, block_unclosed,<br/>unexpected_eof, expected_token, …"]
    TAST["[compiler_types_template_ast](compiler_types_template_ast.md)<br/>AST.Root / Fragment / …"]
    AN["[compiler_analyzer](compiler_analyzer.md)<br/>disallow_children (shared validation)"]
    ENTRY["[compiler_core_entry](compiler_core_entry.md)<br/>compile / compileModule"]

    ENTRY -->|"calls parse()"| ENGINE
    ENGINE -->|"drives"| STATES
    ENGINE -->|"create_fragment, read_options,<br/>regex_whitespace, entity decoding"| UTIL
    ENGINE -->|"set_source"| CSTATE
    ENGINE -->|"raise CompileErrors"| ERR
    ENGINE -->|"disallow_children"| AN
    ENGINE -->|"produces AST.Root"| TAST
    STATES --> UTIL
    UTIL --> ERR
    JSTS -.->|"consumed later via script contents"| UTIL
```

### 9.2 External dependencies

| Package | Used for |
|---|---|
| `acorn` | `isIdentifierStart` / `isIdentifierChar` for Unicode-correct identifier scanning in `read_identifier`. (The same dependency powers JS/TS parsing in [compiler_parser_js_ts_processing](compiler_parser_js_ts_processing.md).) |
| `locate-character` (indirectly, via [compiler_core_state](compiler_core_state.md)) | `getLocator` for line/column mapping after `set_source`. |

---

## 10. Downstream Integration

- **Compiler pipeline** — `AST.Root` produced here is the input to the analyze phase ([compiler_analyzer](compiler_analyzer.md)) and, subsequently, the client/server transforms (see [compiler_client_transform](compiler_client_transform.md) and [compiler_server_transform](compiler_server_transform.md)). The front-end pipeline as a whole is described in [Compiler_Front-End_(Parsing,_Analysis___CSS_Scoping_Pipeline)](Compiler_Front-End_(Parsing,_Analysis___CSS_Scoping_Pipeline).md).
- **Language tooling** — `parse(source, true)` (loose mode) is the entry point used to parse incomplete documents.
- **Diagnostics** — because `parse()` registers the source and locator *before* any parsing, every `CompileError` and warning raised anywhere in later phases can render accurate code frames (see [compiler_diagnostics_diagnostic_model](compiler_diagnostics_diagnostic_model.md)).
- **Migration/preprocessing** — the [compiler_preprocess](compiler_preprocess.md) module typically runs *before* `parse()` to apply user preprocessor transforms to the raw source; the engine always sees the final source text.

---

## 11. Design Notes & Gotchas

- **Stateful module-level globals.** `parse()` writes to module-level compiler state (`set_source`). This is intentional for performance but means parses must not be interleaved concurrently within a single process.
- **Regex hygiene.** `match_regex`/`read` require `^`-anchored patterns; non-anchored patterns would scan the remainder of the template and silently degrade performance. `regex_lang_attribute` is a module-level regex with the `g` flag and must be reset (`lastIndex = 0`) after the TS-detection scan — a documented pitfall in the source.
- **Root bounds are semantic, not lexical.** `root.start`/`root.end` exclude leading/trailing whitespace, so downstream position math should use node positions rather than assuming `root.start === 0`.
- **`Parser` does the work in its constructor.** There is no separate "run" step — `new Parser(...)` is only legal once per parse; state is not reusable across templates.
- **`append` uses `fragments.at(-1)`**, so states must keep `stack`/`fragments` in sync exclusively through `push`-in-`element` and `pop()`; bypassing these operations corrupts the tree.
- **Reserved words.** `read_identifier` rejects JS reserved words unless `allow_reserved` — relevant for component/tag names and directive keys.
