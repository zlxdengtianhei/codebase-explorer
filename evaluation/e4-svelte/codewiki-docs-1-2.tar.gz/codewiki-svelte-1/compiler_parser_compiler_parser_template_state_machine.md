# compiler_parser_template_state_machine

> **Module path:** `packages/svelte/src/compiler/phases/1-parse/` (state machine core: `index.js`, `state/fragment.js`, `state/element.js`, `state/text.js`)
>
> **Parent module:** [compiler_parser](compiler_parser.md) · **Grandparent:** [Compiler_Front-End_(Parsing,_Analysis___CSS_Scoping_Pipeline)](Compiler_Front-End_(Parsing,_Analysis___CSS_Scoping_Pipeline).md)

---

## 1. Introduction

The **template state machine** is the heart of Svelte compiler's **Phase 1 (Parse)**. It converts a raw Svelte template string (HTML with embedded expressions, blocks, directives, and special elements) into an **Abstract Syntax Tree (AST)** rooted at `AST.Root`.

Instead of using a table-driven or grammar-based parser, Svelte implements a **hand-rolled recursive-descent state machine**: a single `Parser` instance walks the template character-by-character (via an `index` cursor), while a *current state function* is repeatedly invoked to consume tokens and decide the *next* state. The loop:

```js
let state = fragment;
while (parser.index < parser.template.length) {
    state = state(parser) || fragment;   // ← the state machine itself
}
```

Each state function (`fragment`, `element`, `text`, `tag`) inspects the upcoming characters, appends AST nodes to the parser's stack-managed fragments, and returns the next state.

### Core Responsibilities

| Responsibility | Where |
|---|---|
| Cursor management, stack/fragment bookkeeping, primitive lexing (`eat`, `match`, `read_until`, …) | `Parser` class (`index.js`) |
| Top-level parse entry, `Root` construction, `<svelte:options>` extraction, TypeScript detection | `parse()` (module export) |
| Dispatch between markup constructs (`<`, `{`, text) | `state/fragment.js::fragment` |
| Element/tag open–close logic, meta tags, auto-closing, attribute reading, script/style special cases | `state/element.js` |
| Plain text consumption + HTML entity decoding | `state/text.js` |
| Error recovery for editor tooling ("loose" mode) | throughout, guarded by `parser.loose` |

### Outputs Produced

- `AST.Root` containing: `fragment` (all template nodes), `instance` / `module` (`<script>` ASTs), `css` (`<style>` StyleSheet), `options` (parsed `<svelte:options>`), and `comments`.
- Node types: `RegularElement`, `Component`, `SvelteHead`, `SvelteWindow`, `SvelteBody`, `SvelteDocument`, `SvelteOptions`, `SvelteElement`, `SvelteComponent`, `SvelteSelf`, `SvelteFragment`, `SvelteBoundary`, `TitleElement`, `SlotElement`, `Comment`, `Text`, `ExpressionTag`, `Attribute`, `SpreadAttribute`, `AttachTag`, and directives (`OnDirective`, `BindDirective`, `ClassDirective`, `StyleDirective`, `UseDirective`, `AnimateDirective`, `TransitionDirective`, `LetDirective`).

---

## 2. Architecture

### 2.1 Component Overview

The `Parser` is the *context object* passed into every state function. States are pure functions of the parser. Reader helpers (`read_expression`, `read_script`, `read_style`) are delegated to sibling modules; see [compiler_parser_js_ts_processing](compiler_parser_js_ts_processing.md) and [compiler_parser_parse_utilities](compiler_parser_parse_utilities.md).

```mermaid
graph TB
    subgraph Entry["Entry Point"]
        PARSE["parse(template, loose)<br/>(index.js)"]
    end

    subgraph Engine["Parser Engine (index.js)"]
        P["class Parser<br/>─────────────<br/>index: number<br/>template: string<br/>loose / ts flags<br/>stack: TemplateNode[]<br/>fragments: Fragment[]<br/>meta_tags / last_auto_closed_tag"]
        subgraph Primitives["Lexing Primitives"]
            EAT["eat(str, required)"]
            MATCH["match / match_regex"]
            READ["read(pattern)<br/>read_identifier<br/>read_until"]
            WS["allow_whitespace<br/>require_whitespace"]
        end
        subgraph TreeOps["Tree Operations"]
            APPEND["append(node)"]
            POP["pop()"]
            CURR["current()"]
            ACORNERR["acorn_error(err)"]
        end
    end

    subgraph States["State Functions (state/)"]
        FRAG["fragment()<br/>(fragment.js)"]
        ELEM["element()<br/>(element.js)"]
        TEXT["text()<br/>(text.js)"]
        TAG["tag()<br/>(tag.js — sibling module)"]
    end

    subgraph Readers["Attribute & Value Readers (element.js)"]
        RA["read_attribute()"]
        RSA["read_static_attribute()"]
        SEQ["read_sequence(parser, done, loc)"]
    end

    subgraph Delegated["Delegated Readers"]
        REXPR["read_expression<br/>(read/expression.js)"]
        RSCRIPT["read_script<br/>(read/script.js)"]
        RSTYLE["read_style<br/>(read/style.js)"]
        OPTS["read_options<br/>(read/options.js)"]
    end

    subgraph Support["Supporting Utilities"]
        CF["create_fragment<br/>(utils/create.js)"]
        HTML["decode_character_references<br/>(utils/html.js)"]
        CA["create_attribute /<br/>create_expression_metadata<br/>(phases/nodes.js)"]
        ERR["errors.js (e.*) /<br/>warnings.js (w.*)"]
    end

    PARSE -->|"set_source + new Parser"| P
    P -->|"state loop"| FRAG
    FRAG -->|"&lt;"| ELEM
    FRAG -->|"{"| TAG
    FRAG -->|"else"| TEXT
    ELEM --> RA
    ELEM -->|"top-level &lt;script&gt;/&lt;style&gt;"| RSA
    RA --> SEQ
    ELEM --> RSCRIPT
    ELEM --> RSTYLE
    RA --> REXPR
    SEQ --> REXPR
    TAG --> REXPR
    TEXT --> HTML
    SEQ --> HTML
    RSA --> HTML
    P --> Primitives
    P --> TreeOps
    ELEM --> CF
    CA --> APPEND
    States --> ERR
    Readers --> CA
    PARSE --> OPTS
```

### 2.2 Parser Class — Internal State

| Field | Type | Purpose |
|---|---|---|
| `template` | `string` | The (right-trimmed) source text. Read-only. |
| `index` | `number` | Current cursor position — the state machine's "program counter". |
| `loose` | `boolean` | Loose mode: recover from errors so language tools can parse incomplete templates. |
| `ts` | `boolean` | TypeScript mode, auto-detected from `lang="ts"` in the first `<script>` tag via `regex_lang_attribute`. |
| `stack` | `AST.TemplateNode[]` | Currently open nodes (root, elements, blocks). `stack[0]` is always `Root`. |
| `fragments` | `AST.Fragment[]` | Parallel stack of open `Fragment` node lists — `append(node)` pushes into the innermost fragment. |
| `root` | `AST.Root` | The output being built. |
| `meta_tags` | `Record<string, boolean>` | Tracks root-only `svelte:*` meta tags to reject duplicates/placement errors. |
| `last_auto_closed_tag` | `LastAutoClosedTag?` | Bookkeeping for implied end tags (e.g. `<li><li>`), so that an "invalid" closing tag is not falsely reported. |

### 2.3 Relationship to Other Modules

```mermaid
graph LR
    subgraph Phase1["Phase 1 — Parse (compiler_parser)"]
        subgraph THIS["THIS MODULE: template state machine"]
            SM["Parser + fragment/element/text states"]
        end
        JS["compiler_parser_js_ts_processing<br/>(acorn.js parse, remove_this_param)"]
        UTIL["compiler_parser_parse_utilities<br/>(read_options, entities, fuzzymatch)"]
    end
    CORE["compiler_core<br/>(compileModule orchestration)"]
    TYPES["compiler_types<br/>(template.d.ts AST model)"]
    DIAG["compiler_diagnostics<br/>(errors.js, warnings.js, get_code_frame)"]
    ANALYZE["compiler_analyzer<br/>(Phase 2 — visitors/scope)"]
    TRANSFORM["Compiler_Back-End<br/>(Phase 3 — client/server transform)"]

    CORE -->|"calls parse()"| SM
    SM -->|"JS expressions via<br/>parse_expression_at"| JS
    SM -->|"&lt;svelte:options&gt; →<br/>component options"| UTIL
    SM -->|"entity decoding"| UTIL
    TYPES -.->|"AST node shapes"| SM
    DIAG -.->|"error/warning factories"| SM
    SM -->|"AST.Root"| ANALYZE
    ANALYZE --> ANALYZE_OUT["annotated AST"] --> TRANSFORM
```

- **Upstream:** [compiler_core](compiler_core.md) invokes `parse()` (via `compile`/`compileModule` orchestration), after optional [compiler_preprocess](compiler_preprocess.md) has run.
- **Downstream:** the `AST.Root` produced here is consumed by [compiler_analyzer](compiler_analyzer.md), which populates the empty `metadata.expression` placeholders this module creates on every `ExpressionTag`, `Attribute`, and directive.

---

## 3. The State Machine

### 3.1 State Transition Diagram

`fragment` is the *default* state: any state function returning nothing (`void`) falls back to it.

```mermaid
stateDiagram-v2
    [*] --> fragment: parse() starts loop

    fragment --> element: next char is '<'
    fragment --> tag: next char is '{'
    fragment --> text: otherwise

    text --> fragment: consumed until '<' or '{'<br/>(appends AST.Text with<br/>decoded entities)

    element --> fragment: comment &lt;!-- --&gt; consumed
    element --> element_closing: '<' + '/'
    element --> element_open: '<' + name

    state element_closing {
        [*] --> PopStack
        PopStack --> AutoClose: parent name ≠ tag name
        AutoClose --> PopStack: implicitly close open<br/>elements (warn / error)
        PopStack --> [*]: set parent.end
    }
    element_closing --> fragment

    state element_open {
        [*] --> Classify
        Classify --> MetaTag: svelte:head/options/window/<br/>document/body/boundary/<br/>element/component/self/fragment
        Classify --> Component: valid component name<br/>(Uppercase / dotted)
        Classify --> TitleElement: <title> inside svelte:head
        Classify --> SlotElement: <slot> (not shadow-root tpl)
        Classify --> RegularElement: otherwise

        MetaTag --> ReadAttrs
        Component --> ReadAttrs
        TitleElement --> ReadAttrs
        SlotElement --> ReadAttrs
        RegularElement --> ReadAttrs

        ReadAttrs --> ScriptStyle: top-level <script>/<style><br/>(static attrs only)
        ReadAttrs --> Finish: other elements

        ScriptStyle --> FragmentDone: content → root.instance /<br/>root.module / root.css
        Finish --> SelfClose: '/' or void element<br/>(don't push to stack)
        Finish --> Textarea: <textarea> raw-text scan
        Finish --> RawText: nested <script>/<style>
        Finish --> Push: push element onto stack<br/>+ push element.fragment

        Textarea --> FragmentDone
        RawText --> FragmentDone
        Push --> FragmentDone
        SelfClose --> FragmentDone
    }
    element_open --> fragment

    tag --> fragment: {expression}, {#block},<br/>{:else}, {@special} handled<br/>(see compiler_parser)

    fragment --> [*]: index ≥ template.length<br/>(unclosed nodes → error,<br/>or closed in loose mode)
```

### 3.2 `parse()` — End-to-End Process Flow

```mermaid
flowchart TD
    A["parse(template, loose=false)"] --> B["state.set_source(template)<br/>installs line/column locator for diagnostics"]
    B --> C["new Parser(template, loose)"]
    C --> D{"template is string?"}
    D -->|no| E["throw TypeError"]
    D -->|yes| F["trimEnd source; detect lang=<br/>via regex_lang_attribute → parser.ts"]
    F --> G["Build AST.Root skeleton:<br/>{css:null, js:[], fragment:<br/>create_fragment(), options:null,<br/>comments:[], metadata:{ts}}<br/>push root onto stack + fragments"]
    G --> H["Main loop:<br/>state = state(parser) || fragment"]
    H --> I{"index < template.length?"}
    I -->|yes| J["Invoke current state function"]
    J --> H
    I -->|no| K{"stack.length > 1?<br/>(unclosed nodes)"}
    K -->|yes, loose| L["Close current node<br/>at template.length"]
    K -->|yes, strict| M["e.element_unclosed /<br/>e.block_unclosed"]
    K -->|no| N{"final state ≠ fragment?"}
    L --> N
    M --> N
    N -->|yes| O["e.unexpected_eof(index)"]
    N -->|no| P{"root.fragment has nodes?"}
    O --> P
    P -->|yes| Q["Compute root.start/end<br/>trimming surrounding whitespace"]
    P -->|no| R["root.start = root.end = null"]
    Q --> S{"&lt;svelte:options&gt; present?"}
    R --> S
    S -->|yes| T["Splice from fragment;<br/>read_options(options) → root.options;<br/>disallow_children check;<br/>attach non-enumerable __raw__"]
    S -->|no| U["return parser.root"]
    T --> U
```

### 3.3 Element Parsing — Detailed Sequence

The `element` state is by far the largest state, handling open tags, close tags, comments, and three raw-text special cases.

```mermaid
sequenceDiagram
    participant F as fragment state
    participant E as element state
    participant P as Parser
    participant RA as read_attribute
    participant R as read_expression/acorn
    participant AST as root/fragments

    F->>P: match('<') → dispatch element
    E->>P: index++ (consume '<')

    alt Comment
        E->>P: eat('!--'), read_until('-->'), eat('-->')
        E->>AST: append {type:'Comment'}
    else Closing tag "</name>"
        E->>P: eat('/'), read name, eat('>')
        loop while parent.name ≠ name
            E->>P: pop() + close parent<br/>(warn element_implicitly_closed,<br/>or error invalid closing tag;<br/>loose: may backtrack mis-parsed attr)
        end
        E->>P: set parent.end, pop()
    else Opening tag "<name ..."
        E->>E: classify name → node type<br/>(meta tag map / component regex /<br/>title-in-head / slot / regular)
        E->>P: auto-close parent if<br/>closing_tag_omitted(parent, name)
        loop until read_* returns null
            E->>RA: read(parser)
            RA->>R: {expr} / {@attach} / {...spread}
            RA-->>E: Attribute | Directive |<br/>SpreadAttribute | AttachTag
            E->>E: duplicate-attribute check<br/>(per-type unique names)
            E->>AST: element.attributes.push
        end
        alt top-level <script>/<style>
            E->>E: read_static_attribute only<br/>(no expressions allowed)
            E->>P: eat('>'), capture preceding comment
            Note over E: read_script → root.instance /<br/>root.module (context="module")<br/>read_style → root.css
        else SvelteComponent / SvelteElement
            E->>E: extract this="…" attribute →<br/>element.expression / element.tag
        else regular element
            E->>AST: append(element)
            alt self-closing '/' or void
                E->>E: element.end = index (no push)
            else <textarea>
                E->>P: read_sequence until </textarea>
            else nested <script>/<style>
                E->>P: read_until('</name>'), eat close
            else normal open tag
                E->>P: push(element), push(element.fragment)
            end
        end
    end
    E-->>F: return (loop falls back to fragment)
```

### 3.4 Attribute Grammar (read_attribute)

`read_attribute` recognizes, in order of the leading characters:

| Input pattern | Resulting node | Notes |
|---|---|---|
| `{ @attach expr }` | `AttachTag` | Attachment (Svelte 5.29+). |
| `{ ...expr }` | `SpreadAttribute` | Attribute spread. |
| `{ name }` | `Attribute` (shorthand) | Value is an `ExpressionTag` wrapping `Identifier(name)`. |
| `bind:name`, `bind:name={expr}` | `BindDirective` | Name-less form synthesizes `Identifier` expression (e.g. `bind:this`). |
| `on:name`, `on:name={expr}` | `OnDirective` | Event handler. |
| `class:name`, `style:name` | `ClassDirective` / `StyleDirective` | Style directives keep `important` modifiers. |
| `use:action` | `UseDirective` | Actions. |
| `animate:name` | `AnimateDirective` | |
| `in:` / `out:` / `transition:` | `TransitionDirective` | Sets `intro`/`outro` booleans from prefix. |
| `let:name` | `LetDirective` | Legacy slot props. |
| `plain="value"` | `Attribute` | Value: `true`, single `ExpressionTag`, or `Array<Text \| ExpressionTag>`. |

Values are read by `read_attribute_value` → `read_sequence`, which alternates between raw `Text` chunks (entity-decoded via `decode_character_references(raw, true)`) and `{expression}` chunks. `read_sequence` is also reused for `<textarea>` bodies and rejects misplaced `{#block}` / `{@tag}` constructs with dedicated diagnostics (`block_invalid_placement`, `tag_invalid_placement`).

```mermaid
flowchart TD
    S["read_attribute(parser)"] --> T{"eat('{')?"}
    T -->|yes| U{"eat('@attach')?"}
    U -->|yes| V["AttachTag"]
    U -->|no| W{"eat('...')?"}
    W -->|yes| X["SpreadAttribute"]
    W -->|no| Y["read_identifier → shorthand<br/>Attribute + ExpressionTag"]
    T -->|no| Z["read name until token-ender"]
    Z --> AA{"name contains ':'?"}
    AA -->|yes| AB["get_directive_type:<br/>use/animate/bind/class/style/<br/>on/let/in/out/transition"]
    AA -->|no| AC{"eat('=')?"}
    AB --> AC
    AC -->|yes| AD["read_attribute_value →<br/>quoted / unquoted / read_sequence<br/>(Text + ExpressionTag chunks)"]
    AC -->|no| AE{"next is quote?"}
    AE -->|yes| AF["error: expected '='"]
    AE -->|no| AG["value = true"]
    AD --> AH{"directive?"}
    AG --> AH
    AH -->|yes| AI["Build directive node;<br/>validate expression (no text mix);<br/>synth Identifier for bind:/class:;<br/>set intro/outro for transitions"]
    AH -->|no| AJ["create_attribute(name, start, end, value)"]
    AI --> AK["return node"]
    AJ --> AK
    V --> AK
    X --> AK
    Y --> AK
```

---

## 4. Data Flow: Template → AST

```mermaid
flowchart LR
    subgraph Input
        SRC["'&lt;div class={x}&gt;Hello &amp;amp; bye&lt;/div&gt;'"]
    end
    subgraph Parser["Parser + states"]
        LEX["character cursor +<br/>state dispatch"]
        ENT["decode_character_references<br/>(named / &#123;hex / decimal)"]
    end
    subgraph AST_OUT["AST.Root (packages/svelte/src/compiler/types/template.d.ts)"]
        ROOT["Root"]
        FRAG2["Fragment"]
        RE["RegularElement 'div'"]
        ATTR["Attribute class<br/>value: [ExpressionTag(x)]"]
        TXT["Text 'Hello & bye'<br/>(entities decoded)"]
        M1["metadata.expression<br/>{dependencies:Set,<br/>references:Set, has_state,<br/>has_call, …} — empty"]
    end
    SRC --> LEX
    LEX --> RE
    LEX --> TXT
    LEX --> ENT
    ENT --> TXT
    RE --> FRAG2
    ATTR --> RE
    TXT --> FRAG2
    FRAG2 --> ROOT
    M1 -.->|"attached at node creation"| ATTR
    ROOT --> NEXT["→ compiler_analyzer (Phase 2)<br/>fills metadata.expression"]
    style NEXT stroke-dasharray: 5 5
```

Key data-flow invariants established by this module:

1. **Every expression-like node** (`ExpressionTag`, `Attribute`, every directive, `SpreadAttribute`, `AttachTag`) is created with a fresh, *empty* `create_expression_metadata()` placeholder — the analyzer phase is responsible for populating it.
2. **Fragments mirror the stack**: pushing an element pushes its `fragment`; `pop()` pops both, guaranteeing `node.fragment.nodes` only contains direct children.
3. **Positions are absolute**: every node records `start`/`end` offsets into the original template, enabling `get_code_frame` diagnostics (see [compiler_diagnostics](compiler_diagnostics.md)) and source maps.
4. **Comments are preserved**: leading HTML comments before top-level `<script>` are attached as `leadingComments`, and template `{/* comments */}` feed `root.comments`, enabling `svelte-ignore` handling downstream.

---

## 5. Special Behaviors

### 5.1 HTML Auto-Closing (Implied End Tags)

Mirrors browser HTML parsing rules via `closing_tag_omitted` from `html-tree-validation.js`:

- **Opening** a new tag implicitly closes the parent when valid per the HTML spec — e.g. `<li>` inside `<li>`, `<p>` inside `<p>` — emitting `w.element_implicitly_closed` and recording `last_auto_closed_tag` (with stack depth).
- **Closing** `</div>` inside an unclosed `<p>` pops intermediate elements with a warning; in strict mode, closing a tag that was *not* the auto-closer yields `e.element_invalid_closing_tag_autoclosed`.

### 5.2 Meta Tag Rules (`svelte:*`)

| Tag | Node type | Placement rule |
|---|---|---|
| `svelte:head` | `SvelteHead` | anywhere (title specialization below) |
| `svelte:options` | `SvelteOptions` | Root only, once (`svelte_meta_duplicate`, `svelte_meta_invalid_placement`) |
| `svelte:window` | `SvelteWindow` | Root only, once |
| `svelte:document` | `SvelteDocument` | Root only, once |
| `svelte:body` | `SvelteBody` | Root only, once |
| `svelte:element this={tag}` | `SvelteElement` | `this` attribute required → `element.tag` |
| `svelte:component this={C}` | `SvelteComponent` | `this` must be an expression attribute |
| `svelte:self`, `svelte:fragment`, `svelte:boundary` | `SvelteSelf` / `SvelteFragment` / `SvelteBoundary` | placement validated later by [compiler_analyzer](compiler_analyzer.md) |

Unknown `svelte:*` names fail fast with `svelte_meta_invalid_tag` listing valid options.

### 5.3 Raw-Text Elements

- `<textarea>`: children parsed with `read_sequence` until `regex_closing_textarea_tag` (expressions allowed inside).
- Nested `<script>` / `<style>` (non-root): body consumed verbatim as a single `Text` node until the literal closing tag.
- Top-level `<script>`: handed to `read_script` ([compiler_parser_js_ts_processing](compiler_parser_js_ts_processing.md)) which re-parses with **acorn** using a space-padded prefix so acorn positions align with template offsets; `lang="ts"` triggers `parser.ts`, and TypeScript-specific nodes are stripped later via `remove_this_param` etc.
- Top-level `<style>`: handed to `read_style`; CSS analysis continues in [compiler_css_pipeline](compiler_css_pipeline.md).

### 5.4 Loose Mode (Editor/Language-Tool Support)

When `loose=true` (used by the language tools when parsing incomplete buffers):

- Unclosed elements/blocks get `end = template.length` instead of hard errors.
- Partial identifiers (e.g. `<div.`) and empty shorthands (`{}`) are tolerated.
- A mis-tokenized `<` of a *following* element captured as an attribute name is **backtracked** (`parser.index = last.start`, attribute popped) — likewise for a swallowed `{`, `{#`, `{/`, `{@` block prefix.
- `read_expression` falls back to `get_loose_identifier` before surfacing acorn errors.

### 5.5 Error & Warning Integration

All diagnostics flow through the shared `errors.js` (`e.*`, `CompileError` with code frames) and `warnings.js` (`w.*`) modules — see [compiler_diagnostics](compiler_diagnostics.md). The parser also registers the source with `state.set_source()` so error positions can be rendered as line/column code frames via `get_code_frame`.

---

## 6. Public API

```ts
// packages/svelte/src/compiler/phases/1-parse/index.js

/** Entry point — returns AST.Root for the given template source. */
export function parse(template: string, loose?: boolean): AST.Root;

export class Parser {
  constructor(template: string, loose: boolean);
  current(): AST.TemplateNode;
  acorn_error(err: any): never;
  eat(str: string, required?: boolean, required_in_loose?: boolean): boolean;
  match(str: string): boolean;
  match_regex(pattern: RegExp): string | null;
  allow_whitespace(): void;
  read(pattern: RegExp): string | null;
  read_identifier(allow_reserved?: boolean): string | null;
  read_until(pattern: RegExp): string;
  require_whitespace(): void;
  pop(): AST.TemplateNode;
  append<T>(node: T): T;
}

/** A state function: consume input, optionally return next state. */
type ParserState = (parser: Parser) => ParserState | void;
```

**Contract notes**

- `parse()` is exported from `compiler/phases/1-parse/index.js` and re-exported through the compiler's public `parse` entry; `compile()`/`compileModule()` in [compiler_core](compiler_core.md) call it internally.
- `parse` with `loose=false` **throws** `CompileError` on any syntax violation; with `loose=true` it is best-effort and never surfaces recoverable errors — the contract relied upon by editor tooling.

---

## 7. Usage Example

Given:

```svelte
<script lang="ts">
  export let x: number = 1;
</script>

<div class={x > 1 ? 'big' : 'small'}>
  Hello &amp; welcome, {name}
  {#if x > 1}<span>big</span>{/if}
</div>
```

`parse()` yields (simplified):

```js
{
  type: 'Root',
  ts: true /* metadata */,
  options: null,
  instance: { type: 'Script', context: 'default', content: /* acorn Program */ },
  module: null,
  css: null,
  fragment: {
    type: 'Fragment',
    nodes: [
      { type: 'RegularElement', name: 'div',
        attributes: [
          { type: 'ClassDirective', name: '', /* synthesized */ expression: {type:'Identifier', name:'x'} }
          // note: class={…} without colon → Attribute named 'class' holding an ExpressionTag
        ],
        fragment: { nodes: [
          { type: 'Text', data: 'Hello & welcome, ' },
          { type: 'ExpressionTag', expression: { type: 'Identifier', name: 'name' } },
          { type: 'IfBlock', /* … from tag state, sibling module */ }
        ]}
      }
    ]
  }
}
```

---

## 8. Related Documentation

| Module | Relationship |
|---|---|
| [compiler_parser](compiler_parser.md) | Parent module — full Phase 1 overview and entry orchestration. |
| [compiler_parser_js_ts_processing](compiler_parser_js_ts_processing.md) | `read_expression` / `read_script` / `read_style` / acorn integration and TypeScript node stripping. |
| [compiler_parser_parse_utilities](compiler_parser_parse_utilities.md) | `read_options` (`<svelte:options>`), HTML entity decoding, fuzzymatch (`sort_descending`). |
| [compiler_analyzer](compiler_analyzer.md) | Phase 2 consumer; populates expression metadata created here (e.g. `AwaitBlock`, `IfBlock`, `ConstTag` visitors). |
| [compiler_css_pipeline](compiler_css_pipeline.md) | Downstream analysis/transform of the `StyleSheet` produced by `read_style`. |
| [compiler_types](compiler_types.md) | `AST.Root` and all template node type definitions (`template.d.ts`). |
| [compiler_diagnostics](compiler_diagnostics.md) | `errors.js` / `warnings.js` factories and `CompileError` code frames used throughout the states. |
| [compiler_core](compiler_core.md) | Orchestration entry (`compileModule`) that invokes `parse()` within the full compile pipeline. |
| [compiler_preprocess](compiler_preprocess.md) | Optional upstream stage that may rewrite the source before parsing. |
