# client_runtime_core_stores

> **Module location:** `packages/svelte/src/internal/client/reactivity/store.js`
> **Parent subsystem:** `client_runtime_core` (Reactive Runtime Engine)

## 1. Introduction

The `client_runtime_core_stores` module is the **bridge between Svelte's store contract and the signals-based reactive runtime**. It implements the runtime machinery behind the `$store` auto-subscription syntax: when a component reads or writes `$someStore`, the compiler emits calls into this module, which transparently subscribes to the store, mirrors its values into a reactive **mutable source** (signal), and tears the subscription down when the component unmounts.

This is what allows legacy store-based state to participate in fine-grained reactivity:

- Store reads become **tracked signal reads** (effects/deriveds re-run when the store emits).
- Store writes (`$store = v`, `$store += 1`, `$store.x++`) funnel back through `store.set(...)`.
- Store **reassignment** (`store = $anotherStore`) triggers unsubscribe/resubscribe bookkeeping.
- Store **prop bindings** (`<Child bind:x={$y} />`) are flagged so they are treated as mutable even in runes mode.

The module is intentionally **thin**: it does not implement the store contract itself (that lives in the public [`stores`](stores.md) module), nor the signal graph (see [`client_runtime_core_signal_model`](client_runtime_core_signal_model.md) and [`client_runtime_core_sources`](client_runtime_core_sources.md)). It orchestrates the *interplay* between the two.

---

## 2. Core Concepts

| Concept | Description |
|---|---|
| **Store contract** | Any object with a `subscribe(run, invalidate?)` method (plus optional `set` for writables). Optionally RxJS-style observables (`.unsubscribe()` return). |
| **Store references container** | A per-component-instance `Record<store_name, StoreReference>` that caches one subscription + one mirror signal per `$store` name used in the component. Created by `setup_stores()`. |
| **Store reference entry** | `{ store, unsubscribe, source }` — the currently subscribed store, its unsubscribe function (`noop` when none), and the `mutable_source` signal mirroring its value. |
| **Mirror signal** | A `mutable_source` created via [`client_runtime_core_sources`](client_runtime_core_sources.md); store emissions `set()` it, and tracked reads of `$store` `get()` it. |
| **Unmount tombstone** | The `IS_UNMOUNTED` symbol property stamped onto the container after cleanup, preventing new subscriptions and forcing non-reactive fallback reads. |
| **Store-binding flag** | Module-level `is_store_binding` flag, set by `mark_store_binding()` inside compiler-generated prop getters and observed by `capture_store_binding()` in the props layer. |

---

## 3. Component Inventory

| Export | Role | Visibility |
|---|---|---|
| `setup_stores()` | Creates the store-references container + cleanup function; called once at component init by compiler-generated code. | Compiler-emitted |
| `store_get(store, name, stores)` | Reads `$store`; lazily subscribes and mirrors the value into a tracked signal. | Compiler-emitted |
| `store_unsub(store, name, stores)` | Unsubscribes when the referenced store has been reassigned. | Compiler-emitted |
| `store_set(store, value)` | Writes a plain assignment (`$store = value`); returns the value. | Compiler-emitted |
| `store_mutate(store, expression, new_value)` | Writes compound mutations (`$store = mutation of $store`); returns the expression result. | Compiler-emitted |
| `update_store(store, value, d)` | Postfix `$store++` / `$store--` semantics: sets `value + d`, returns the **old** value. | Compiler-emitted |
| `update_pre_store(store, value, d)` | Prefix `++$store` / `--$store` semantics: sets `value + d`, returns the **new** value. | Compiler-emitted |
| `invalidate_store(stores, name)` | Legacy-mode `invalidate()`: pushes the mirror-signal value back into the store. | Legacy runtime |
| `mark_store_binding()` | Flags the current prop read as a store binding (called inside generated prop getters). | Compiler-emitted |
| `capture_store_binding(fn)` | Runs `fn`, reports whether it read a store-bound prop; consumed by [`client_runtime_core_props`](client_runtime_core_props.md). | Runtime-internal |

---

## 4. Architecture

### 4.1 Position in the runtime

```mermaid
flowchart TB
    subgraph Compiler["Compiler Back-End (see compiler_client_transform)"]
        CT["Client transform visitors<br/>(Identifier, AssignmentExpression, ...)"]
        CT -- "emits calls to" --> API
    end

    subgraph Module["client_runtime_core_stores"]
        API["store.js exports<br/>store_get / store_set / store_mutate<br/>update_store / update_pre_store<br/>store_unsub / invalidate_store<br/>setup_stores / mark_store_binding<br/>capture_store_binding"]
        CTX["StoreReferencesContainer<br/>(per component instance)"]
        API --- CTX
    end

    subgraph Stores["Public store layer (see stores)"]
        UTIL["subscribe_to_store<br/>(store/utils.js)"]
        SGET["get (store/shared/index.js)"]
    end

    subgraph Signals["Signals core"]
        SRC["mutable_source / set<br/>(client_runtime_core_sources)"]
        RUN["get / active_reaction tracking<br/>(client_runtime_core_runtime)"]
        EFF["teardown render-effect<br/>(client_runtime_core_effects)"]
    end

    subgraph Props["Props layer (see client_runtime_core_props)"]
        PROP["prop()"]
    end

    API --> UTIL
    API --> SGET
    API --> SRC
    API --> RUN
    API --> EFF
    PROP -- "capture_store_binding()" --> API

    subgraph SSR["Server counterpart (see server_runtime)"]
        SRV["store_mutate / update_store /<br/>update_store_pre / unsubscribe_stores"]
    end
    CT -. "mirrored by" .-> SRV
```

### 4.2 Dependency imports

```mermaid
flowchart LR
    store["store.js"]
    store -->|subscribe_to_store| storeUtils["store/utils.js"]
    store -->|get (one-shot)| storeShared["store/shared/index.js"]
    store -->|define_property, noop| shared["internal/shared/utils.js"]
    store -->|get (signal read)| runtime["reactivity/runtime.js"]
    store -->|teardown| effects["reactivity/effects.js"]
    store -->|mutable_source, set| sources["reactivity/sources.js"]
    store -->|DEV| esmEnv["esm-env"]
```

---

## 5. Data Structures

### `StoreReferencesContainer`

```ts
type StoreReferencesContainer = Record<
  string,
  {
    store: Store<any> | null;   // currently subscribed store (or null)
    unsubscribe: Function;      // active unsubscribe fn; noop when none
    source: Source<any>;        // mirror signal holding the latest value
  }
>;
```

Key properties:

- **Keyed by store name** — the string as it appears in `$name`, so `foo` for `$foo`. One entry per syntactic store reference per component instance.
- **`source` is a mutable source** (not an immutable source): store values are treated as mutable so that `safe_equals` semantics apply and any emission triggers reactions.
- **Tombstoning** — after cleanup, `define_property(stores, IS_UNMOUNTED, { value: true, enumerable: false })` marks the container dead. Membership in the container is then checked with `IS_UNMOUNTED in stores`.

### Module-level flag

```js
let is_store_binding = false; // set by mark_store_binding, observed by capture_store_binding
```

This is a synchronous, single-threaded side channel between compiler-generated prop getters and the props layer — no signal allocation is needed to detect bindings.

---

## 6. Operational Flows

### 6.1 Read path: `store_get` subscription lifecycle

The compiler rewrites `$foo` to `store_get(foo, '$foo', $$stores)` inside any tracked expression. The read path handles four scenarios:

```mermaid
flowchart TD
    A["store_get(store, name, stores)"] --> B{"entry exists for<br/>this store name?"}
    B -- no --> C["Create entry:<br/>{ store: null,<br/>source: mutable_source(undefined),<br/>unsubscribe: noop }<br/>(DEV: label source with store name)"]
    B -- yes --> D
    C --> D{"entry.store !== store<br/>AND not unmounted?"}
    D -- "yes (subscribe / resubscribe)" --> E["entry.unsubscribe()"]
    E --> F{"store == null?"}
    F -- yes --> G["source.v = undefined<br/>unsubscribe = noop"]
    F -- no --> H["subscribe_to_store(store, cb)"]
    H --> I{"First (synchronous)<br/>emission?"}
    I -- yes --> J["entry.source.v = v<br/>(bypasses set() to avoid<br/>state_unsafe_mutation inside deriveds)"]
    I -- no --> K["set(entry.source, v)"]
    D --> L{"IS_UNMOUNTED in stores<br/>AND store != null?"}
    L -- yes --> M["return get_store(store)<br/>(non-reactive one-shot read,<br/>no new subscription, no leak)"]
    G --> N["return get(entry.source)<br/>(tracked signal read)"]
    J --> N
    K --> N
    M --> O["done"]
    N --> O
```

**Why the synchronous-callback special case?** A store's `subscribe` may invoke `run` synchronously. If `store_get` runs inside a *derived* and the callback called `set()` immediately, the runtime would raise `state_unsafe_mutation` (writing a source while a derived is computing). Writing `entry.source.v` directly seeds the value without notifying reactions; subsequent (asynchronous) emissions use the normal `set()` path. See [`client_runtime_core_sources`](client_runtime_core_sources.md) for `set` semantics and [`client_runtime_core_deriveds`](client_runtime_core_deriveds.md) for derived evaluation.

**Why the unmount fallback?** If the owning component is already destroyed (e.g. `store_get` invoked from a lingering teardown path), subscribing again would leak. Instead the current value is pulled with the non-reactive `get()` from [`stores`](stores.md)' shared module — "less performant but consistent", per the source comments.

### 6.2 Reassignment: `store_unsub`

A store *variable* reassignment (`$$appStore = $otherStore`) compiles to:

```
store_unsub(prevStore, '$appStore', $$stores);
prevStore = newStore;
... store_get(newStore, '$appStore', $$stores) ...
```

`store_unsub` closes the old subscription **if** the container entry currently points at a *different* store. It deliberately **does not reset `entry.store`**, so a following `store_get` can detect the change and resubscribe to the new store. This covers the edge case where the assignment is followed by no subsequent read — the old subscription is still released and `unsubscribe` is reset to `noop`.

### 6.3 Teardown: `setup_stores` cleanup

```mermaid
sequenceDiagram
    participant C as Component init (generated)
    participant S as setup_stores()
    participant E as effects.js (teardown)
    participant R as Runtime unmount

    C->>S: setup_stores()
    S-->>C: [ stores, cleanup ]
    C->>E: cleanup registered via teardown(fn)
    Note over E: teardown creates a CLEAN<br/>RENDER_EFFECT with effect.teardown = fn
    R->>E: destroy effect tree
    E->>S: run cleanup fn
    S->>S: for each entry: ref.unsubscribe()
    S->>S: stamp IS_UNMOUNTED onto stores
```

Because cleanup runs inside a **teardown render effect**, unsubscriptions are sequenced correctly with the rest of the component's destruction (see [`client_runtime_core_effects`](client_runtime_core_effects.md)). The `IS_UNMOUNTED` stamp then flips `store_get` into its leak-safe fallback mode (§6.1) and prevents `subscribe_to_store` work for any late reads.

### 6.4 Write paths

| Compiled pattern | Helper called | Semantics |
|---|---|---|
| `$foo = value` | `store_set(foo, value)` | `foo.set(value)`, returns `value` (assignment value) |
| `$foo = <expr mutating $foo>` | `store_mutate(foo, expr, new_value)` | `foo.set(new_value)`, returns `expr` (preserves the value of the whole assignment expression) |
| `$foo++` / `$foo--` | `update_store(foo, v, ±1)` | sets `v + d`, returns **old** `v` |
| `++$foo` / `--$foo` | `update_pre_store(foo, v, ±1)` | sets `v + d`, returns **new** value |

All writes return the value the *original JavaScript expression* would have evaluated to, which is essential for transparent desugaring. The underlying `store.set(...)` is the user's own implementation — this module never mutates store internals.

### 6.5 Legacy invalidation: `invalidate_store`

In legacy mode, `invalidate(name)` needs to push a locally-known value back into the store so that the store and its mirror stay in sync:

```js
invalidate_store(stores, name); // if entry.store !== null → store_set(entry.store, entry.source.v)
```

This pairs with the legacy reactivity helpers in [`client_runtime_core_diagnostics`](client_runtime_core_diagnostics.md) / `invalidate_inner_signals` (see the legacy path in [`client_runtime_core_runtime`](client_runtime_core_runtime.md)).

### 6.6 Store prop bindings: `mark_store_binding` / `capture_store_binding`

For `<Child bind:x={$y} />`, the compiler generates a prop getter that calls `mark_store_binding()`. On the child side, `prop()` in [`client_runtime_core_props`](client_runtime_core_props.md) wraps the initial prop read:

```mermaid
sequenceDiagram
    participant P as prop() in props.js
    participant G as generated prop getter
    participant SB as capture_store_binding()
    participant M as mark_store_binding()

    P->>SB: capture_store_binding(() => props[key])
    SB->>SB: is_store_binding = false
    SB->>G: fn()
    G->>M: mark_store_binding()
    M-->>G: (flag = true)
    G-->>SB: value
    SB-->>P: [ value, is_store_binding = true ]
    Note over P: prop treated as mutable even in runes mode;<br/>binding_property_non_reactive check skipped
```

`capture_store_binding` restores the previous flag in a `finally` block, so nested/exceptional paths cannot leave the flag stuck. The captured boolean also controls whether prop *setters* notify the parent on mutation (`is_store_sub` in `prop()`), since store bindings legitimately mutate through the mirror signal rather than through the state proxy.

---

## 7. Integration Points

| Direction | Module | Relationship |
|---|---|---|
| Consumes | [`stores`](stores.md) | `subscribe_to_store` (subscription with RxJS + null-store handling) and `get` (one-shot read used as unmount fallback) |
| Consumes | [`client_runtime_core_sources`](client_runtime_core_sources.md) | `mutable_source` for mirror signals; `set` for reactive emissions |
| Consumes | [`client_runtime_core_runtime`](client_runtime_core_runtime.md) | `get` for tracked reads and dependency registration |
| Consumes | [`client_runtime_core_effects`](client_runtime_core_effects.md) | `teardown` to register the per-instance cleanup |
| Consumes | `shared_runtime` | `noop`, `define_property` |
| Consumed by | [`client_runtime_core_props`](client_runtime_core_props.md) | `capture_store_binding` used by `prop()` for `bind:x={$store}` |
| Consumed by | [`compiler_client_transform`](compiler_client_transform.md) | all helpers are compiler-emitted call targets for `$store` syntax |
| Mirrored by | [`server_runtime`](server_runtime.md) | server-side `store_mutate`, `update_store`, `update_store_pre`, `unsubscribe_stores` for SSR |
| Related | [`client_runtime_core_batching`](client_runtime_core_batching.md) | `set()` on mirror signals participates in batched flushes |
| Related | [`client_runtime_core_signal_model`](client_runtime_core_signal_model.md) | equality semantics (`safe_equals`) of mirror sources |

---

## 8. Design Notes & Edge Cases

1. **One subscription per store name, not per read site.** Multiple `$foo` reads in a component share a single entry; the subscription is established on first read and refreshed only when the referenced store *object* changes.
2. **Reactivity is mirrored, not native.** The runtime never tracks the store itself; it tracks the mirror source. This keeps the signal graph uniform and lets devtools see labelled signals (`entry.source.label = store_name` in DEV).
3. **Derived-safety on first emission** — synchronous `run` callbacks write `source.v` directly (§6.1) to avoid `state_unsafe_mutation`. The trade-off is that the very first emission does not schedule reactions, which is fine because the value was just read synchronously by the caller.
4. **Leak-proof unmounted reads.** `IS_UNMOUNTED in stores` guards both *subscribing* and *reading* after destruction; the non-reactive `get_store` fallback guarantees consistent values without keeping the component's reaction graph alive.
5. **RxJS compatibility** comes for free via `subscribe_to_store`, which normalizes `{ unsubscribe }` returns to plain functions and maps null stores to `noop`.
6. **Flag hygiene.** `capture_store_binding` saves/restores the previous flag rather than assuming `false`, making it safe under re-entrancy from nested component initialization.
7. **SSR symmetry.** The server has no signals or subscriptions; its helpers (`update_store*`, `store_mutate`) exist purely to preserve expression value semantics, and `unsubscribe_stores` is a no-op-shaped counterpart to `setup_stores` cleanup. See [`server_runtime`](server_runtime.md).

---

## 9. Quick Reference — Call Sites by Feature

| Svelte syntax | Client helper(s) invoked |
|---|---|
| `$store` in template / script (read) | `store_get` |
| `$store = v` | `store_set` |
| `$store += …`, `$store.x = …` (mutation expressions) | `store_mutate` |
| `$store++`, `$store--` | `update_store` |
| `++$store`, `--$store` | `update_pre_store` |
| `$: store = $other` (reassignment) | `store_unsub` + `store_get` |
| Component instance init | `setup_stores` (registers cleanup) |
| `invalidate('$store')` (legacy) | `invalidate_store` |
| `<Child bind:x={$y} />` | generated getter → `mark_store_binding`; child `prop()` → `capture_store_binding` |

For how these call sites are produced during compilation, see [`compiler_client_transform`](compiler_client_transform.md); for the store primitives themselves (`writable`, `derived`, `get`), see [`stores`](stores.md).
