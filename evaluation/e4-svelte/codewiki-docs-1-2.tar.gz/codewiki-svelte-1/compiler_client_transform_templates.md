# compiler_client_transform_templates

## 1. Introduction

`compiler_client_transform_templates` is the sub-module of the Svelte compiler's client back-end that turns a component's **static markup into optimized DOM-construction code**. Instead of creating elements one-by-one at runtime, the module accumulates every static part of a fragment (elements, attributes, text, comments) into a lightweight `Template` structure while the client transform walks the AST. When the fragment has been fully visited, the accumulated structure is compiled down to a single *template factory*:

- **`html` mode (default)** — the `Template` is serialized back to an HTML string (`as_html()`) and emitted as `$.from_html(``)...`` / `$.from_svg` / `$.from_mathml`. At runtime the string is parsed into a `<template>` element **once** and cheaply cloned per component instance.
- **`tree` mode** (`fragments: 'tree'` compile option) — the `Template` is converted into nested array literals (`as_tree()`, e.g. `["div", {class:"wrap"}, ...children]`) and emitted as `$.from_tree(...)`, which builds the DOM imperatively (important for environments without HTML parsing / faster cold start).

Dynamic parts (expression tags, bindings, directives, control flow) are *not* baked into the template. They are rendered into stable anchor positions (`<!>` comment placeholders / `null` slots) and wired up afterwards by traversing the cloned DOM with `$.first_child` / `$.child` / `$.sibling` / `$.next`.

The module lives at `packages/svelte/src/compiler/phases/3-transform/client/` and is orchestrated by the `Fragment` visitor (`visitors/Fragment.js`), which is the mandatory root of every client render function.

> **Context**: This module is a child of [compiler_client_transform](compiler_client_transform.md). Element/directive visitors that *populate* the template are documented in [compiler_client_transform_elements_and_directives](compiler_client_transform_elements_and_directives.md); reactivity wiring (`$.template_effect`, memoization) in [compiler_client_transform_state_and_reactivity](compiler_client_transform_state_and_reactivity.md); control-flow blocks that embed templates in [compiler_client_transform_control_flow_blocks](compiler_client_transform_control_flow_blocks.md).

---

## 2. Architecture

```mermaid
flowchart TB
    subgraph Compiler["Svelte Compiler — phases/3-transform/client"]
        AST["Validated AST<br/>(from Phase 2 analysis,<br/>see compiler_analyzer)"]

        subgraph MODULE["compiler_client_transform_templates"]
            FRAG["Fragment visitor<br/><i>visitors/Fragment.js</i><br/>(orchestrator)"]
            CLEAN["clean_nodes / infer_namespace /<br/>check_nodes_for_namespace (RegularElement)<br/><i>3-transform/utils.js</i>"]
            TMPL["Template<br/><i>transform-template/template.js</i><br/>objectify · stringify"]
            EMIT["transform_template<br/><i>transform-template/index.js</i>"]
            PC["process_children<br/><i>visitors/shared/fragment.js</i>"]
        end

        DISPATCH["Visitor dispatch<br/>(client/utils.js → visit)"]
        ELEMVIS["Element &amp; attribute visitors<br/>(RegularElement, Attribute, …)"]
    end

    subgraph Runtime["Client DOM renderer (internal/client/dom)"]
        FROMS["$.from_html / $.from_svg / $.from_mathml"]
        FROMT["$.from_tree"]
        WSCRIPT["$.with_script"]
        OPS["$.append · $.first_child · $.child ·<br/>$.sibling · $.next · $.text · $.comment"]
    end

    AST --> FRAG
    FRAG --> CLEAN
    CLEAN -- "hoisted / trimmed /<br/>is_standalone / is_text_first" --> FRAG
    FRAG -- "visit(child)" --> DISPATCH
    DISPATCH --> ELEMVIS
    ELEMVIS -- "push_element / set_prop<br/>(see compiler_client_transform_elements_and_directives)" --> TMPL
    FRAG --> PC
    PC -- "push_text (static runs)" --> TMPL
    FRAG -- "fragment complete" --> EMIT
    TMPL -- "as_html()" --> EMIT
    TMPL -- "as_tree()" --> EMIT
    EMIT -- "emits call" --> FROMS
    EMIT -- "emits call" --> FROMT
    EMIT -- "contains_script_tag" --> WSCRIPT
    FRAG -- "emits init statements<br/>that traverse the clone" --> OPS
```

### 2.1 Component responsibilities

| Component | Location | Responsibility |
|---|---|---|
| `Template` (class) | `transform-template/template.js` | Mutable, DOM-like record of all **static** template content, plus the two serialization entry points `as_html()` / `as_tree()`. |
| `stringify` | `transform-template/template.js` | Node → HTML string (consumed by `as_html`). Handles text raws, comments, attribute escaping, void elements. |
| `objectify` | `transform-template/template.js` | Node → ESTree literal/array structure (consumed by `as_tree`). Restores SVG attribute casing, strips `<pre>`/`<textarea>` leading newlines. |
| `Fragment` visitor | `visitors/Fragment.js` | Orchestrates an entire fragment: namespace inference, node cleaning, strategy selection, hoisted-template emission, statement assembly (`init` → render effect → `after_update` → `close`). |
| `clean_nodes` / `infer_namespace` / `RegularElement` (namespace walker) | `3-transform/utils.js` | Shared helpers: hoist-vs-inline classification, whitespace trimming, `{@const}` topological sorting (legacy mode), and `html`/`svg`/`mathml` namespace inference. |
| `transform_template` | `transform-template/index.js` | Consumes the finished `Template` and produces the final `$.from_html` / `$.from_tree` call expression, applying flags, `$.with_script` and dev-mode `$.add_locations` wrappers. |
| `process_children` | `visitors/shared/fragment.js` | Walks fragment children; pushes static text runs into the `Template`, groups `Text`+`ExpressionTag` sequences, and computes anchor-traversal expressions. |

---

## 3. The `Template` data structure

```mermaid
classDiagram
    class Template {
        +boolean contains_script_tag
        +boolean needs_import_node
        +Node[] nodes
        -Node[][] stack
        -Element currentElement
        -Node[] fragment
        +push_element(name, start)
        +push_comment(data)
        +push_text(nodes)
        +pop_element()
        +set_prop(key, value)
        +as_html() TemplateLiteral
        +as_tree() ArrayExpression
    }
    class Element {
        +string name
        +Record~string, string|undefined~ attributes
        +Node[] children
    }
    class TextNode {
        +AST.Text[] nodes
    }
    class CommentNode {
        +string data
    }
    Template o-- Element : nodes
    Element o-- Node : children
    note for Template "Maintains a stack so nested\npush_element/pop_element pairs\nre-parent children correctly"

    class ComponentClientTransformState {
        +Template template
        +Statement[] init
        +Statement[] update
        +Statement[] after_update
        +Identifier node
    }
    ComponentClientTransformState o-- Template : state.template
```

The `Template` is *write-during-transform, read-once-at-the-end*:

1. **Population** — as the visitor walks the AST, `RegularElement` calls `push_element` → `set_prop` for every static attribute → eventually `pop_element`; `process_children` calls `push_text` for static text runs; `push_comment` records comments (which later double as dynamic anchors).
2. **Bookkeeping flags** — set by the element visitors:
   - `contains_script_tag` — a `<script>` exists; the runtime must run cloned scripts (`$.with_script` wrapper).
   - `needs_import_node` — `<video>` or custom elements are present; `cloneNode` would not instantiate the custom-element class until connection (and WebKit needs `importNode` for `<video>` autoplay), so the runtime must use `document.importNode`.
3. **Serialization** — exactly one of `as_html()` / `as_tree()` is chosen by `transform_template`, based on `state.options.fragments`.

### 3.1 Serialization mapping (`stringify` vs `objectify`)

| Template node | `as_html()` → `stringify` | `as_tree()` → `objectify` |
|---|---|---|
| Static text | concatenated **raw source** of the text nodes | string literal of concatenated `data` |
| Comment with data | `<!--data-->` | `['// data']` array literal |
| Empty comment (dynamic anchor) | `<!>` | `null` slot |
| Element open tag | `<name attr="value" …>` with `escape_html(value, true)` | `["name", {attr: value} \| null, …children]` |
| Boolean attribute (`value === undefined`) | bare ` attr` key, no `="…"` | property with `undefined` value |
| Void elements (`<br>`, `<input>`, …) | self-closed `/>` (XHTML compliance) | no children array entries |
| Static attributes keys | used verbatim | passed through `fix_attribute_casing` to restore camelCase **SVG attribute** names (`viewBox`, `preserveAspectRatio`, …) |
| `<pre>` / `<textarea>` | leading newline kept | leading newline **stripped** from first child literal (the browser would drop it otherwise, breaking hydration) |
| First node is a comment | n/a (runtime prepends `<!>` via `has_start`) | an extra empty comment is `unshift`ed so the first real comment is not consumed as `effect.nodes.start` |

---

## 4. `transform_template` — emission and runtime contract

`transform_template(state, namespace, flags)` produces the hoisted template declaration:

```js
// html mode
const root = $.from_html(`<div class="wrap"><span>count: <!></span></div>`);
// tree mode (fragments: 'tree')
const root = $.from_tree(["div", { class: "wrap" }, ["span", null, "count: ", null]]);
```

Flag bits (`packages/svelte/src/constants.js`):

| Flag | Meaning |
|---|---|
| `TEMPLATE_FRAGMENT` (`1`) | Content is a multi-node fragment; the runtime assigns *first/last child* as the effect node range instead of a single node. |
| `TEMPLATE_USE_IMPORT_NODE` (`1 << 1`) | Clone via `document.importNode` (custom elements, `<video>`, Firefox). |
| `TEMPLATE_USE_SVG` (`1 << 2`) | *Tree mode only* — create nodes in the SVG namespace (HTML parsing already infers this in string mode). |
| `TEMPLATE_USE_MATHML` (`1 << 3`) | *Tree mode only* — create nodes in the MathML namespace. |

Emission details:

- **Namespace routing** — string mode selects `$.from_html` / `$.from_svg` / `$.from_mathml` from the inferred namespace; tree mode always emits `$.from_tree` and communicates the namespace through flags instead.
- **Scripts** — if `state.template.contains_script_tag`, the call is wrapped: `$.with_script($.from_html(...))`. The runtime wrapper runs `run_scripts` on the clone (cloned `<script>` elements are inert by spec). A related compile-time safeguard lives in `clean_nodes`: a fragment consisting of a lone `<script>` is padded with an extra comment so the runtime's `node.replaceWith(...)` can never be a no-op on a parentless script.
- **Dev mode** — the call is additionally wrapped in `$.add_locations(call, FILENAME, locations)` using source locations recorded for every template node, powering better dev warnings.
- **Hoisting** — the result is stored in `context.state.hoisted` as `const root = …`, so the string/template is built **once per component class**, not per instance. Instance creation is `const root_1 = root();` in the render function body.

---

## 5. The `Fragment` visitor — orchestration flow

`Fragment` is the entry point for the whole module. It receives the validated `AST.Fragment` plus a `ComponentClientTransformState` (see [compiler_client_transform_state_and_reactivity](compiler_client_transform_state_and_reactivity.md)) whose `state.template` is a **fresh `Template`** created for this fragment.

```mermaid
flowchart TD
    A["Fragment(node) invoked"] --> B["infer_namespace(parent, nodes)<br/>+ clean_nodes(...)"]
    B --> C{"hoisted &amp; trimmed<br/>both empty?"}
    C -- yes --> Z["return empty block"]
    C -- no --> D{"trimmed children shape?"}

    D -- "1 × RegularElement" --> E1["generate element id, visit element<br/>(visitor pushes into Template)"]
    D -- "1 × SvelteFragment /<br/>TitleElement" --> E2["visit directly —<br/>no template needed"]
    D -- "1 × Text" --> E3["$.text(literal)"]
    D -- "only Text +<br/>ExpressionTag" --> E4["use_space_template:<br/>single $.text() node +<br/>process_children sequence"]
    D -- "multiple / mixed" --> F{"is_standalone?<br/>(static &lt;!--&gt; render tag or<br/>non-dynamic component)"}
    F -- yes --> E5["render into the parent's<br/>$$anchor — no template"]
    F -- no --> E6["fragment template:<br/>TEMPLATE_FRAGMENT (+IMPORT_NODE) flags<br/>lone comment → $.comment()<br/>otherwise transform_template"]

    E1 --> G["transform_template(state, ns, flags)<br/>state.hoisted += const root = …<br/>init += const id = root()"]
    E6 --> G
    E3 --> H["close = $.append($$anchor, id)"]
    E1 --> H
    E4 --> H

    G --> I["Assemble body in fixed order:<br/>consts → $.aborted guard (has_await)<br/>→ $.next (is_text_first)<br/>→ init → render effect ($.template_effect)<br/>→ after_update → close (must be last)"]
    H --> I
    I --> J{"has_await?"}
    J -- yes --> K["wrap body in<br/>$.async_body(() => { … })"]
    J -- no --> L["return block"]
    K --> L
```

Key decisions and invariants:

- **`clean_nodes` contract** — returns `{ hoisted, trimmed, is_standalone, is_text_first }`:
  - `hoisted` — nodes rendered outside the template instance: `{@const}` (`ConstTag`), `{@debug}`, `<svelte:body|window|document|head>`, `<title>`, `<snippet>` blocks.
  - `trimmed` — whitespace-normalized remaining nodes (leading/trailing whitespace-only text removed; interior whitespace collapsed to one space, except inside whitespace-ignoring parents such as `select`/`table`/`tr`/`tbody`/`colgroup` or `svg` `<text>`, where it is removed entirely; `<pre>` honors `preserve_whitespace`).
  - `is_standalone` — a single static `RenderTag` or non-dynamic `Component` (no HMR, no `--props`) can reuse the block's `$$anchor` instead of a template clone.
  - `is_text_first` — when a fragment/snippet/each/component starts with text, an anchor comment is injected so its text node cannot fuse with surrounding DOM during hydration; the body then emits `$.next` to skip over it.
  - In **legacy (non-runes) mode**, `clean_nodes` also topologically sorts `{@const}` tags to match Svelte 4 evaluation order and reports cycles via `const_tag_cycle`.
- **Namespace inference** — `infer_namespace` consults element metadata (`metadata.svg`, `metadata.mathml`), resets to `html` inside `foreignObject`, and re-evaluates namespaces inside namespace-resetting parents (`Fragment`, `Root`, components, snippets, slots) via the `check_nodes_for_namespace` walk (its `RegularElement` visitor stops at the first non-SVG/MathML element, declaring the subtree `html`).
- **Statement ordering** — `close` (`$.append($$anchor, id)`) is deliberately the **last** statement: preceding statements may insert elements into the template clone, and the append statement must observe the final list of inner nodes when computing effect boundaries.
- **The local `expression` accessor** — in the multi-child branch, `(is_text) => $.first_child(id, is_text && true)` is handed to `process_children` as the starting point for anchor traversal; `process_children` chains `$.sibling` calls (with skip counts for static siblings) from it.

---

## 6. Data flow — from AST to running DOM

```mermaid
flowchart LR
    subgraph CT["Compile time"]
        ASTN["AST nodes<br/>RegularElement / Text /<br/>ExpressionTag / Comment"]
        CN["clean_nodes<br/>(hoist · trim · classify)"]
        T["Template.nodes<br/>{element \| text \| comment}"]
        STR["stringify<br/>→ HTML string"]
        OBJ["objectify<br/>→ array literals"]
        EMITC["transform_template<br/>$.from_html / $.from_tree"]
        HOIST["const root = … (hoisted)"]
        INST["const root_1 = root()"]
        WIRE["anchor traversal +<br/>attribute/event wiring"]
    end

    subgraph RT["Runtime (client_dom_renderer)"]
        ONCE["parse/build template once"]
        CLONE["clone per instance<br/>(cloneNode / importNode)"]
        EFF["assign effect start/end nodes"]
        APPEND["$.append($$anchor, node)"]
    end

    ASTN --> CN --> T
    T -- "fragments: 'html'" --> STR --> EMITC
    T -- "fragments: 'tree'" --> OBJ --> EMITC
    EMITC --> HOIST --> INST --> APPEND
    INST --> ONCE --> CLONE --> EFF --> APPEND
    INST --> WIRE
```

### 6.1 End-to-end example

Input:

```svelte
<div class="wrap">
  <span>count: {count}</span>
</div>
```

Simplified generated output (client mode):

```js
// hoisted — parsed once
const root = $.from_html(`<div class="wrap"><span>count: <!></span></div>`);

export default function App($$anchor, count) {
    var div = root();                            // template instance (clone)
    var span = $.child(div, true);               // traverse to <span> (text anchor)
    var text = $.child(span, true);              // traverse to <!> anchor

    $.template_effect(() => $.set_text(text, count)); // dynamic part

    $.append($$anchor, div);                     // close — must be last
}
```

The `<!>` placeholder in the string corresponds to the `null` slot in tree mode (`["div", {"class":"wrap"}, ["span", null, "count: ", null]]`): both mark where the dynamic text node is created and where `effect.nodes.start`/`end` get assigned.

---

## 7. Compile-time interaction sequence

```mermaid
sequenceDiagram
    autonumber
    participant F as Fragment visitor
    participant U as clean_nodes / utils.js
    participant V as Element visitors (dispatch)
    participant T as Template
    participant E as transform_template

    F->>U: clean_nodes(parent, nodes, path, ns, state, …)
    U-->>F: { hoisted, trimmed, is_standalone, is_text_first }
    F->>F: select strategy (single element / text /<br/>space template / standalone / fragment)
    F->>V: visit(hoisted nodes)
    F->>V: visit(single element) · process_children(trimmed)
    V->>T: push_element(name, start)
    V->>T: set_prop(key, value)  — static attrs only
    V->>T: pop_element()
    V->>T: push_text(textNodes) — static runs
    T-->>V: flags: needs_import_node, contains_script_tag
    F->>E: transform_template(state, namespace, flags)
    E->>T: as_html() | as_tree()
    T-->>E: TemplateLiteral | ArrayExpression
    E-->>F: $.from_html/.from_svg/.from_mathml/.from_tree call
    F->>F: hoist `const root = …`<br/>init `root()` · render effect · `$.append`
```

---

## 8. Dependencies

**Upstream (consumed by this module):**

- [compiler_analyzer](compiler_analyzer.md) — provides the validated AST with `metadata` (svg/mathml flags, expression `has_state`/`has_await`, `is_controlled`, scoped CSS hash) that drives every specialization here.
- [compiler_core](compiler_core.md) — `builders` (`b.template`, `b.quasi`, `b.array`, `b.literal`, `b.var`, `b.call`, …) used by `as_html`, `as_tree` and `transform_template`; `errors.js` for `const_tag_cycle`.
- [compiler_client_transform](compiler_client_transform.md) — parent module: visitor dispatch (`context.visit`), `ClientTransformState`/`ComponentClientTransformState` types (`state.template`, `state.hoisted`, `state.init/update/after_update`, `state.node` anchor), and option plumbing (`fragments`, `preserveWhitespace`, `preserveComments`, dev mode).
- [compiler_client_transform_elements_and_directives](compiler_client_transform_elements_and_directives.md) — `RegularElement`/`SvelteElement` visitors that call `push_element`/`set_prop`, decide static-attribute inlining (boolean attributes, `is` attribute, scoped `class` hash merging) and set `needs_import_node`/`contains_script_tag`.
- [compiler_client_transform_state_and_reactivity](compiler_client_transform_state_and_reactivity.md) — `Memoizer` and `build_render_statement` used when assembling the fragment's render effect.

**Downstream (runtime contract):**

- [client_dom_renderer](client_dom_renderer.md) — `$.from_html` / `$.from_svg` / `$.from_mathml` / `$.from_tree` / `$.with_script` (template factories) and `$.append`, `$.first_child`, `$.child`, `$.sibling`, `$.next`, `$.text`, `$.comment` (instance wiring). Hydration-aware: during hydration the factories re-attach to existing DOM instead of cloning.
- [client_runtime_core](client_runtime_core.md) — the signals/effects engine the emitted `$.template_effect` closures close over.

---

## 9. Design notes & special-case index

| Concern | Handling |
|---|---|
| Clone correctness for custom elements / `<video>` | `needs_import_node` → `TEMPLATE_USE_IMPORT_NODE` → `document.importNode` (class instantiation + WebKit autoplay). |
| Script execution | `contains_script_tag` → `$.with_script` wrapper; lone `<script>` fragments padded with a comment in `clean_nodes` so `replaceWith` always has a parent. |
| Fragment boundaries | `TEMPLATE_FRAGMENT` + `<!>` leading anchor (string mode) / prepended comment (tree mode) give the runtime stable `effect.nodes.start`/`end`. |
| Whitespace fidelity vs. node count | `clean_nodes` trimming preserves single spaces between text and non-text nodes (`white-space: pre-line` correctness) but removes whitespace entirely inside whitespace-ignoring parents (`select`, `tr`, `table`, `tbody`, `thead`, `tfoot`, `colgroup`, `datalist`, svg `<text>`). |
| `<pre>` / `<textarea>` | `preserve_whitespace` is forced on inside them; tree mode strips the first child's leading newline to match browser parsing (hydration parity). |
| Dynamic text-only fragments | "space template" optimization — a single `$.text()` node instead of a unique template when children are only `Text`/`ExpressionTag`. |
| Lone static comment | `$.comment()` runtime helper instead of a template. |
| Standalone children | static `{@render …}` tags and simple components reuse the parent's `$$anchor` — no template clone at all. |
| Async Svelte (`{await …}` at fragment level) | `has_await` → body wrapped in `$.async_body`, with an early `$.aborted` return after consts. |
| SVG attribute casing in tree mode | `fix_attribute_casing` maps lowercase keys back to canonical SVG casing (e.g. `viewbox` → `viewBox`). |
| Legacy `{@const}` ordering | topological sort in `clean_nodes` (`sort_const_tags`) reproduces Svelte 4 behavior; cycles produce `const_tag_cycle` errors. |
| Dev-mode diagnostics | emitted factories wrapped with `$.add_locations` using per-node source locations. |

---

## 10. File map

```
packages/svelte/src/compiler/phases/3-transform/
├── types.d.ts                          # TransformState (base state)
├── utils.js                            # clean_nodes · infer_namespace ·
│                                       # determine_namespace_for_children ·
│                                       # check_nodes_for_namespace (RegularElement)
│                                       # is_hoisted_function · transform_inspect_rune
└── client/
    ├── transform-template/
    │   ├── template.js                 # Template class · stringify · objectify
    │   ├── index.js                    # transform_template (emitter)
    │   └── fix-attribute-casing.js     # SVG attribute casing lookup
    ├── visitors/
    │   ├── Fragment.js                 # Fragment orchestrator (+ local expression accessor)
    │   └── shared/
    │       ├── fragment.js             # process_children (anchor traversal + text runs)
    │       └── utils.js                # build_render_statement · Memoizer
```

Related client types (`client/types.d.ts`): `ComponentClientTransformState` — carries `template: Template`, `hoisted`, `init`, `update`, `after_update`, `consts`, `memoizer`, `metadata.namespace`, `metadata.bound_contenteditable`, `preserve_whitespace`, and the current anchor `node` identifier.
