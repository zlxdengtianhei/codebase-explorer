# svelte_element_types

## 1. Introduction

`svelte_element_types` is a **type-only module** consisting of a single declaration file, `packages/svelte/elements.d.ts`, which is published as the `svelte/elements` export subpath of the `svelte` package. It defines the **complete TypeScript surface for element attributes in Svelte templates**: every standard HTML element, every SVG element, and every Svelte-specific element (`svelte:window`, `svelte:document`, `svelte:body`, `svelte:fragment`, `svelte:options`, `svelte:head`, `svelte:boundary`) is mapped to a strongly-typed attribute interface.

Key characteristics:

- **Zero runtime** — the file contains only TypeScript interfaces/types. No code is emitted, and nothing is tree-shaken; it exists purely for editors, language tooling, and user type annotations.
- **Derived from React 18 JSX typings** — the file header credits the `@types/react` (DefinitelyTyped) authors; the typings were adapted to Svelte semantics (e.g. `on:` syntax, `bind:` directives, snippets, attachments).
- **Language-server integration point** — the Svelte language server loads these typings (via [public_api_html_typing](public_api_html_typing.md)) to type-check and provide intellisense for template attributes.
- **Four core components** (as surfaced by the module tree): `AriaAttributes`, `DOMAttributes`, `HTMLMediaAttributes`, and `SvelteHTMLElements` — plus the supporting attribute interfaces and helper types they compose.

Typical consumer usage:

```ts
import type { HTMLButtonAttributes, HTMLInputAttributes } from 'svelte/elements';

let { ...rest }: HTMLButtonAttributes = $props();
```

---

## 2. Core Components

### 2.1 `AriaAttributes`

The full **WAI-ARIA 1.1** attribute set (`aria-activedescendant`, `aria-checked`, `aria-live`, `aria-valuemax`, …), one optional property per attribute with W3C-sourced JSDoc. `AriaRole` (exported alongside) provides the union of ARIA role names, with a `(string & {})` escape hatch that preserves autocomplete while allowing custom roles.

### 2.2 `DOMAttributes<T>`

The **event-handler and DOM-behavior layer**, generic over the element's `EventTarget`. It is the anchor of Svelte's event system typing:

| Concern | Typed surface |
|---|---|
| Svelte 4-style events | `'on:click'`, `'on:submit'`, … (quoted, with colon) |
| Svelte 5 delegated events | `onclick`, `onsubmit`, … (lowercase property form) |
| Capture phase | `onclickcapture`, `onsubmitcapture`, … (suffix form) |
| Content (implicit children) | `children?: import('svelte').Snippet` — included so spreading `{...rest}` from an element into props needs no separate interface |
| Element dimension bindings | readonly `bind:clientWidth`, `bind:clientHeight`, `bind:contentRect`, `bind:contentBoxSize`, `bind:borderBoxSize`, `bind:devicePixelContentBoxSize` (backed by `bind_element_size`/`bind_resize_observer` — see [client_dom_renderer_bindings](client_dom_renderer_bindings.md)) |
| Namespace | `xmlns` |

Every handler type derives from the `EventHandler<E, T>` base signature, which augments the event with a precisely typed `currentTarget`. ~20 specialized aliases are exported (`MouseEventHandler<T>`, `KeyboardEventHandler<T>`, `TransitionEventHandler<T>`, …), including Svelte-specific ones for `on:introstart`/`on:outroend` transition events.

### 2.3 `HTMLMediaAttributes<T>`

Shared attribute contract for `<audio>` and `<video>` (via `HTMLAudioAttributes` / `HTMLVideoAttributes`). Beyond standard media attributes (`autoplay`, `controls`, `preload`, …) it declares the **media binding directives** that map 1:1 to runtime binders in the client DOM renderer:

- Mutable: `bind:muted`, `bind:volume`, `bind:currentTime`, `bind:playbackRate`, `bind:paused` (→ `bind_current_time`, `bind_volume`, `bind_playback_rate`, `bind_paused`, `bind_muted` in [client_dom_renderer_bindings](client_dom_renderer_bindings.md))
- Readonly: `bind:readyState`, `bind:duration`, `bind:buffered`, `bind:played`, `bind:seekable`, `bind:seeking`, `bind:ended`

`bind:buffered` / `bind:played` / `bind:seekable` use the exported `SvelteMediaTimeRange` helper (`{ start: number; end: number }`).

### 2.4 `SvelteHTMLElements`

The **element registry**: a single interface keyed by tag name, with a fallback index signature allowing unknown tags (custom elements). Three registry sections:

| Section | Coverage | Example entries |
|---|---|---|
| HTML | 100+ standard (and Electron `webview`) elements | `a: HTMLAnchorAttributes`, `input: HTMLInputAttributes`, `video: HTMLVideoAttributes` |
| SVG | `svg` root + all SVG element names | `circle: SVGAttributes<SVGCircleElement>`, `path: SVGAttributes<SVGPathElement>` |
| Svelte-specific | `svelte:*` elements | `svelte:window: SvelteWindowAttributes`, `svelte:boundary: { onerror, failed, pending }` (snippets referenced from [public_api_type_contracts](public_api_type_contracts.md)) |

The trailing `[name: string]: { [name: string]: any }` index signature is deliberate: it lets `<my-custom-element>` type-check out of the box while still permitting module augmentation for fully-typed custom elements (see §7).

### 2.5 Supporting types exported by the file

Beyond the four core components, the file exports the full family of per-element interfaces and helpers that `SvelteHTMLElements` composes:

- **Root attribute interfaces** — `HTMLAttributes<T>` and `SVGAttributes<T>`, both extending `AriaAttributes` + `DOMAttributes<T>`.
- **Per-element interfaces** — ~55 HTML variants (`HTMLAnchorAttributes`, `HTMLButtonAttributes`, `HTMLFormAttributes`, …) and `SVGAttributes<T>`.
- **Svelte wrapper interfaces** — `SvelteWindowAttributes` (window binds: `innerWidth`, `scrollX`, `online`, …; window-only events) and `SvelteDocumentAttributes` (`bind:activeElement`, `bind:visibilityState`, …).
- **Helper types** — `Booleanish` (`boolean | 'true' | 'false'`), `AriaRole`, `ClassValue` (clsx-shaped: `string | ClassArray | ClassDictionary`), `FullAutoFill`, `HTMLInputTypeAttribute`, `HTMLAttributeAnchorTarget`, `SvelteMediaTimeRange`.

`HTMLAttributes<T>` carries two **special index signatures** that encode Svelte-only attribute semantics:

```ts
// allow any data- attribute
[key: `data-${string}`]: any;

// allow any attachment and falsy values (by using false we prevent the usage of booleans values by themselves)
[key: symbol]: Attachment<T> | false | undefined | null;
```

The `symbol` slot is what makes `{...props}` objects keyed by `createAttachmentKey()` (see [actions_and_attachments](actions_and_attachments.md)) type-check as element attributes.

---

## 3. Architecture: Type Composition Hierarchy

The module is a layered composition: ARIA + DOM event foundations feed the two root attribute interfaces, which specialize into per-element contracts that the `SvelteHTMLElements` registry aggregates.

```mermaid
classDiagram
    direction TB

    class AriaAttributes {
        <<interface>>
        WAI-ARIA 1.1 attribute map
        +aria-label string
        +aria-checked Booleanish
        +aria-live off-assertive-polite
    }
    class DOMAttributes~T~ {
        <<interface>>
        Event handlers + DOM behaviour
        +children Snippet
        +onclick / on:click / onclickcapture
        +bind:clientWidth number
    }
    class HTMLAttributes~T~ {
        <<interface>>
        +class ClassValue
        +role AriaRole
        +data-* any
        +symbol-key Attachment
    }
    class SVGAttributes~T~ {
        <<interface>>
        +viewBox string
        +d string
        +stroke string
    }
    class HTMLMediaAttributes~T~ {
        <<interface>>
        +autoplay boolean
        +bind:duration number
        +bind:currentTime number
    }
    class HTMLButtonAttributes {
        <<interface>>
        +disabled boolean
        +type submit-reset-button
    }
    class HTMLInputAttributes {
        <<interface>>
        +value any
        +bind:checked boolean
        +bind:group any
    }
    class SvelteWindowAttributes {
        <<interface>>
        +bind:innerWidth number
        +bind:scrollX number
    }
    class HTMLVideoAttributes {
        <<interface>>
        +poster string
        +bind:videoWidth number
    }
    class HTMLAudioAttributes {
        <<interface>>
        media attributes only
    }
    class SvelteHTMLElements {
        <<interface>>
        +a HTMLAnchorAttributes
        +button HTMLButtonAttributes
        +input HTMLInputAttributes
        +svg SVGAttributes
        +svelte:window SvelteWindowAttributes
        +name-key any (custom elements)
    }

    class Snippet {
        <<from 'svelte'>>
    }
    class Attachment~T~ {
        <<from 'svelte/attachments'>>
    }
    class ClassValue {
        <<from 'clsx' types>>
    }

    AriaAttributes <|-- HTMLAttributes : extends
    DOMAttributes <|-- HTMLAttributes : extends
    AriaAttributes <|-- SVGAttributes : extends
    DOMAttributes <|-- SVGAttributes : extends
    HTMLAttributes <|-- HTMLMediaAttributes : extends
    HTMLAttributes <|-- HTMLButtonAttributes : extends
    HTMLAttributes <|-- HTMLInputAttributes : extends
    HTMLAttributes <|-- SvelteWindowAttributes : extends
    HTMLMediaAttributes <|-- HTMLAudioAttributes : extends
    HTMLMediaAttributes <|-- HTMLVideoAttributes : extends

    SvelteHTMLElements ..> HTMLButtonAttributes : "button"
    SvelteHTMLElements ..> HTMLInputAttributes : "input"
    SvelteHTMLElements ..> SVGAttributes : "svg / circle / ..."
    SvelteHTMLElements ..> SvelteWindowAttributes : "svelte:window"

    DOMAttributes ..> Snippet : children
    HTMLAttributes ..> Attachment : symbol index
    HTMLAttributes ..> ClassValue : class
```

---

## 4. System Context & Dependencies

`elements.d.ts` sits at the bottom of the **Public API Surface & Compatibility Layer** group. It *imports from* the attachments contract and the `svelte` type contracts, and is *consumed by* the HTML intrinsic-elements bridge (`svelte-html.d.ts`), which is what the Svelte language server loads.

```mermaid
flowchart TB
    subgraph PKG["packages/svelte"]
        direction TB
        subgraph PUB["Public API Surface & Compatibility Layer"]
            ELEM["elements.d.ts<br/>(svelte_element_types — this module)"]
            SHTML["svelte-html.d.ts<br/>global svelteHTML.IntrinsicElements<br/>(public_api_html_typing)"]
            CONTRACTS["src/index.d.ts + types/index.d.ts<br/>Snippet, Component, EventDispatcher<br/>(public_api / svelte-types)"]
            ATT["svelte/attachments<br/>Attachment, createAttachmentKey<br/>(actions_and_attachments)"]
        end
    end

    USER["Component authors &<br/>UI library maintainers"]
    LS["Svelte language server<br/>svelte-check / VS Code extension"]
    TOOLS["Template type-checking pipeline<br/>(svelte2tsx)"]
    RUNTIME["Runtime implementations<br/>(client DOM renderer / server runtime)"]
    AST["Compiler AST element nodes<br/>RegularElement / SvelteElement<br/>(compiler_types_template_ast)"]

    ATT -- "import type { Attachment }" --> ELEM
    CONTRACTS -- "import('svelte').Snippet" --> ELEM
    ELEM -- "SvelteHTMLElements, HTMLAttributes, SVGAttributes" --> SHTML
    SHTML -- "loaded directly by (not in exports map)" --> LS
    ELEM -- "import type from 'svelte/elements'" --> USER
    LS --> TOOLS
    ELEM -. "static contract for" .-> RUNTIME
    ELEM -. "compile-time counterpart: AST nodes, not user typings" .-> AST
```

Relationship notes:

- **Depends on** [actions_and_attachments](actions_and_attachments.md) (`Attachment<T>` type import) and [public_api_type_contracts](public_api_type_contracts.md) (`import('svelte').Snippet` for `children` and `svelte:boundary` snippets).
- **Feeds** [public_api_html_typing](public_api_html_typing.md): `svelte-html.d.ts` does `import * as svelteElements from './elements.js'` and declares `interface IntrinsicElements extends svelteElements.SvelteHTMLElements`.
- **Distinct from** the compiler's AST types: `RegularElement`/`SvelteElement` in [compiler_types_template_ast](compiler_types_template_ast.md) model parsed nodes during compilation (`type`, `metadata.svg`, `metadata.has_spread`, …). They intentionally do **not** reference `elements.d.ts`; the two type universes meet only in tooling.
- **Mirrored at runtime by** [client_dom_renderer_elements_and_events](client_dom_renderer_elements_and_events.md) (`attribute_effect`, `set_custom_element_data`, delegated `event` handling), [client_dom_renderer_bindings](client_dom_renderer_bindings.md) (every `bind:` declared in these typings has a corresponding binder), [server_runtime_rendering_core](server_runtime_rendering_core.md) (`element`, `spread_attributes` for SSR), and [shared_runtime_diagnostics](shared_runtime_diagnostics.md) (`validate_dynamic_element_tag`, `validate_void_dynamic_element` guard `<svelte:element>`).

---

## 5. Typing Data Flow: From Template to Diagnostics

The sequence below shows how a typed template line flows through the module at type-check time, and how the static contract connects to runtime execution.

```mermaid
sequenceDiagram
    participant T as .svelte template
    participant LS as Language server
    participant IE as svelteHTML.createElement
    participant SH as SvelteHTMLElements
    participant HA as HTMLAttributes contract
    participant RT as Runtime (client/server)

    T->>LS: <button bind:value={v} onclick={h} data-x="1">
    LS->>IE: createElement('button', attrs)
    IE->>SH: lookup key 'button'
    SH-->>IE: HTMLButtonAttributes
    IE->>HA: validate bind:/on/data-*/symbol keys
    HA-->>IE: typed attribute surface (incl. Snippet children)
    IE-->>LS: typed element + intellisense / diagnostics
    Note over T,RT: compile phase is type-agnostic<br/>(see compiler AST modules)
    T->>RT: generated code applies attributes/bindings
    RT-->>T: DOM updates (attribute_effect, binders) / SSR string
```

Two contract nuances visible here:

- **Dynamic elements**: for `<svelte:element this={tag}>`, the tag can be any string, so `svelte-html.d.ts` falls back to `HTMLAttributes<any>` (`string extends Key ? ...`) — the loosest contract in the module.
- **Compile/runtime independence**: the Svelte compiler never reads `elements.d.ts`; it parses attributes structurally (see [compiler_parser_template_state_machine](compiler_parser_template_state_machine.md)) and transforms them via [compiler_client_transform_elements_and_directives](compiler_client_transform_elements_and_directives.md). This module only constrains what TypeScript accepts.

---

## 6. Element Registry Layout (`SvelteHTMLElements`)

```mermaid
flowchart LR
    S["SvelteHTMLElements"] --> H["HTML elements<br/>~110 entries<br/>a, button, input, video, ... webview"]
    S --> SV["SVG elements<br/>svg root + ~60 elements<br/>circle, path, feGaussianBlur, ..."]
    S --> SW["Svelte-specific elements"]
    S --> IX["Index signatures<br/>[name: string]: any<br/>(custom elements)"]

    SW --> W1["svelte:window — SvelteWindowAttributes"]
    SW --> W2["svelte:document — SvelteDocumentAttributes"]
    SW --> W3["svelte:body — HTMLAttributes&lt;HTMLElement&gt;"]
    SW --> W4["svelte:fragment — { slot? }"]
    SW --> W5["svelte:options — customElement / namespace / ..."]
    SW --> W6["svelte:head — any"]
    SW --> W7["svelte:boundary — onerror, failed Snippet, pending Snippet"]
```

Notable registry details:

- `svelte:boundary`'s `failed` snippet is typed as `Snippet<[error: unknown, reset: () => void]>` — directly reusing the Snippet contract from [public_api_type_contracts](public_api_type_contracts.md).
- `svelte:options` models the entire custom-element compiler-option surface (`tag`, `shadow`, `props` with `attribute`/`reflect`/`type`, `extend`).
- Each HTML entry exists *twice* in typing practice: once in `SvelteHTMLElements` (canonical, precise) and once re-merged in `svelteHTML.IntrinsicElements` (augmentable by users) — see §7.

---

## 7. Extension Patterns

The module is designed as an **extension surface** for the ecosystem:

1. **Attribute augmentation per element** — `svelte-html.d.ts` builds each `IntrinsicElements` entry as
   `HTMLProps<'tag', HTMLAttributes> = Omit<SvelteHTMLElements['tag'], keyof HTMLAttributes> & HTMLAttributes`.
   Because `svelteHTML.HTMLAttributes`/`SVGAttributes` are empty interfaces merged into a global namespace, users can add attributes via module augmentation and they appear on the matching elements.
2. **Custom element registration** — extend `svelteHTML.IntrinsicElements` with a typed entry for a web component; until then, the fallback index signature keeps unregistered tags compiling as `any`.
3. **Library prop forwarding** — component libraries re-export or reference `HTMLButtonAttributes` etc. for `...rest` prop spreading; the `children` snippet inside `DOMAttributes` keeps such spreads self-contained.
4. **Attachments as spread props** — symbol-keyed index signature accepts `createAttachmentKey()` keys without polluting string-keyed space.
5. **Escape hatches** — `(string & {})` unions (`AriaRole`, `HTMLInputTypeAttribute`, `controlslist`, `command`, …) keep IDE completion while accepting arbitrary strings; `data-*` and `Booleanish` cover common dynamic patterns.

---

## 8. Design Conventions & Rationale

| Convention | Rationale |
|---|---|
| Every attribute optional, typed `X \| undefined \| null` | Svelte removes an attribute when the value is `null` or `undefined`; `null` is admitted as a first-class value (explicit file comment) |
| Triple event syntax (`'on:e'`, `onE`, `onEcapture`) | Backwards compatibility with Svelte 4 `on:` handlers while typing Svelte 5 delegated and capture-phase events |
| `readonly` on one-way binds (`bind:clientWidth`, `bind:duration`, `bind:naturalWidth`, window/document size binds) | Values flow *from* the DOM to state; assignment to them is invalid |
| Dual casing `defaultValue`/`defaultvalue` on input/textarea | Language tools lowercase non-shorthand attribute names; both variants must type-check |
| `ClassValue` from clsx | Accepts string, array, and dictionary class expressions uniformly |
| WAI-ARIA parity + JSDoc | Attributes mirror https://www.w3.org/TR/wai-aria-1.1/ with @see cross-references for documentation on hover |
| `EventHandler` injects `currentTarget: EventTarget & T` | Handlers get precise element types without per-event casting |
| Registry fallback `[name: string]: any` | Unknown tags (custom elements) never block compilation |

---

## 9. Maintenance Notes

- **Hand-maintained**: `elements.d.ts` is *not* regenerated by `scripts/generate-types.js` (which builds the aggregate `types/index.d.ts` for the other subpaths — see [svelte-types](svelte-types.md)). Changes require manual edits, keeping the React-derivation lineage (credited in the header) in sync with new DOM/Svelte features.
- **Language-server loading**: `svelte-html.d.ts` is "deliberately not exposed through the exports map" — it is loaded directly by the Svelte language server; `elements.d.ts` is the exportable half of the pair.
- **Planned churn**: `svelte-html.d.ts` marks its backwards-compat `HTMLAttributes`/`SVGAttributes`/`IntrinsicElements` shims with "TODO remove in Svelte 6"; when that lands, augmentation flows must be re-verified against `SvelteHTMLElements` directly.
- **Adding a new element/attribute**: update the specific `HTMLXAttributes` (or `SVGAttributes`/`SvelteXAttributes`) interface, add/adjust the `SvelteHTMLElements` entry, add matching binders in [client_dom_renderer_bindings](client_dom_renderer_bindings.md) if a new `bind:` is introduced, and update [compiler_client_transform_elements_and_directives](compiler_client_transform_elements_and_directives.md) / [server_runtime_rendering_core](server_runtime_rendering_core.md) if attribute semantics change.

---

## 10. Related Module Documentation

| Module | Relationship |
|---|---|
| [public_api_html_typing](public_api_html_typing.md) | Primary consumer — `svelteHTML.IntrinsicElements` extends `SvelteHTMLElements` |
| [public_api_type_contracts](public_api_type_contracts.md) | Provides `Snippet` (children, boundary snippets) referenced by these typings |
| [actions_and_attachments](actions_and_attachments.md) | Provides the `Attachment<T>` type behind the symbol-key index signature |
| [svelte-types](svelte-types.md) | Sibling aggregated typings bundle (other subpaths; elements is loaded directly) |
| [compiler_types_template_ast](compiler_types_template_ast.md) | Compile-time element node model (`RegularElement`, `SvelteElement`) — separate universe |
| [compiler_parser_template_state_machine](compiler_parser_template_state_machine.md) | Parses attribute syntax that these typings describe statically |
| [compiler_client_transform_elements_and_directives](compiler_client_transform_elements_and_directives.md) | Client transform of attributes/directives declared here |
| [client_dom_renderer_elements_and_events](client_dom_renderer_elements_and_events.md) | Runtime attribute application & event delegation |
| [client_dom_renderer_bindings](client_dom_renderer_bindings.md) | Runtime implementations of every `bind:` in these typings |
| [server_runtime_rendering_core](server_runtime_rendering_core.md) | SSR counterpart (`element`, `spread_attributes`, `attr_class`, `attr_style`) |
| [shared_runtime_diagnostics](shared_runtime_diagnostics.md) | Runtime guards for dynamic/void dynamic elements (`<svelte:element>`) |
