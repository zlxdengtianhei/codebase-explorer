# Sandbox Playground (`playgrounds/sandbox`)

## 1. Overview

The **sandbox playground** is a self-contained developer scratchpad that lives inside the Svelte repository (`playgrounds/sandbox`). It serves as the fastest possible feedback loop for Svelte maintainers: instead of setting up an external project, a developer drops `.svelte` and `.js` files into `playgrounds/sandbox/src/` and uses the tooling in this module to:

1. **Batch-compile** every source file through the real Svelte compiler and dump all artifacts (ASTs, migrated output, client/server JS, sourcemaps, CSS) to disk for inspection ([`run.js`](#2-compilation-driver-runjs)).
2. **Share the current sandbox state** as a single URL that opens on `svelte.dev/playground`, by gzip-compressing and base64-encoding the `src/` contents into a URL hash ([`scripts/hash.js`](#3-share-link-encoder-scriptshashjs)).

The module is intentionally *thin*: it contains no framework logic of its own. All heavy lifting is delegated to the compiler and runtime packages (`svelte/compiler`, `svelte/server`), which means the sandbox automatically exercises whatever code is currently checked out in the workspace.

> **Sibling tooling** (same folder, not core components): `scripts/download.js` performs the *inverse* of `hash.js` (URL → files), `scripts/create-test.js` promotes a sandbox app into a test sample under `packages/svelte/tests`, and `ssr-dev.js` / `ssr-prod.js` / `vite.config.js` form a Vite-based SSR harness to actually *run* the sandbox app in a browser.

### Core components

| File | Component | Role |
| --- | --- | --- |
| `playgrounds/sandbox/run.js` | `write` | Output helper used by the batch-compile driver to persist every compiler artifact |
| `playgrounds/sandbox/scripts/hash.js` | `compress` | Gzip + URL-safe-base64 encoder that turns the `src/` directory into a playground share link |

---

## 2. Compilation driver (`run.js`)

### 2.1 Purpose

`run.js` is a Node script that walks `src/`, feeds every file through the compiler entry points, and writes a complete set of debuggable artifacts into `output/`. It answers questions like *"what AST does the parser produce for this markup?"*, *"what would the Svelte 5 migration look like?"*, and *"what JS does the client/server transform emit?"* — all in one run, with zero configuration.

### 2.2 CLI contract

```bash
node run.js [--runes]
```

- `--runes` (boolean, via `node:util#parseArgs`) is forwarded verbatim to every `compile()` call, letting you toggle runes mode for the whole directory from the command line.

### 2.3 Execution flow

```mermaid
flowchart TD
    A[Start: parse --runes flag] --> B[Wipe output/ dir<br/>keeps .gitkeep]
    B --> C[Glob src/**/*.svelte<br/>and src/**/*.js]
    C --> D{generate mode}
    D -->|client| E1[For each .svelte file]
    D -->|server| E2[For each .svelte file]
    E1 --> F1["parse(source, {modern: true})<br/>→ output/ast/*.json"]
    E1 --> G1["migrate(source)<br/>→ output/migrated/*"]
    E1 --> H["compile(source, {generate})<br/>experimental.async = true"]
    E2 --> H
    H --> I[Print warnings:<br/>code + code frame]
    I --> J1["output/{mode}/*.js<br/>+ sourcemap"]
    J1 -->|client only| K["Recompile with fragments:'tree'<br/>→ output/client/*.tree.js"]
    K --> L{"compiled.css?"}
    J1 --> L
    L -->|yes| M["output/{mode}/*.css"]
    E1 --> N[For each .js file:<br/>compileModule → output/{mode}/*]
    E2 --> N
    L -->|no| D
    M --> D
    N --> D
```

Key behaviours, step by step:

1. **Clean slate** — everything under `output/` is deleted first (`.gitkeep` is preserved), so stale artifacts can never leak into a new run.
2. **Discovery** — `tinyglobby`'s `globSync` finds all `**/*.svelte` and `**/*.js` files relative to `src/`.
3. **Dual-target loop** — the script iterates `generate` over the literal tuple `['client', 'server']`, running the full pipeline twice: once against the client transform, once against the server transform.
4. **Client-only extras** — for `.svelte` files in `client` mode the script additionally:
   - **Parses** with `parse(source, { modern: true })` and serializes the AST to `output/ast/<file>.json` (custom replacer encodes `bigint` values as `["BigInt", "..."]` tuples so `JSON.stringify` never throws).
   - **Migrates** with `migrate(source)` and writes the migrated code to `output/migrated/<file>`, catching failures per-file so one bad file can't abort the batch.
5. **Compilation** — each `compile()` call uses `dev: false`, the real filesystem path as `filename` (so warnings/sourcemaps carry accurate paths), the `--runes` flag, and `experimental: { async: true }`.
6. **Warnings surfaced** — every `compiled.warnings` entry prints its `code` and rendered `frame` to stderr, making it trivial to spot a11y/CSS warnings across the whole fixture set.
7. **Tree-fragment variant** — in `client` mode the source is compiled a *second* time with `fragments: 'tree'` and written alongside the default output as `<file>.tree.js`, letting developers diff the two internal representation strategies the client transform supports.
8. **Plain JS modules** — `**/*.js` files are handled by `compileModule()` (no Svelte markup), with the same `generate` target and options.

### 2.4 Output artifact matrix

| Artifact | Produced when | Written by | Path |
| --- | --- | --- | --- |
| AST dump | `.svelte`, `client` pass | `parse` + `write` | `output/ast/<rel-path>.json` |
| Migrated source | `.svelte`, `client` pass (best-effort) | `migrate` + `write` | `output/migrated/<rel-path>` |
| Compiled JS | every pass | `compile` + `write` | `output/<client\|server>/<rel-path>.js` |
| Sourcemap | every pass | `write` | `output/<mode>/<rel-path>.js.map` |
| Tree-fragment JS | `.svelte`, `client` only | `compile` (`fragments: 'tree'`) | `output/client/<rel-path>.tree.js` (+ `.map`) |
| Compiled CSS | only if the file contains `<style>` | `write` | `output/<mode>/<rel-path>.css` |
| Module JS | `**/*.js` files | `compileModule` | `output/<mode>/<rel-path>` |

### 2.5 The `write` component

`write(file, contents)` is the single sink for all artifacts. It composes two primitives:

- `mkdirp(dir)` — `fs.mkdirSync(dir, { recursive: true })` wrapped in a no-op `catch` (parent dirs that already exist are fine; races are tolerated).
- `fs.writeFileSync(file, contents)`.

Because `write` creates the parent directory of whatever path it receives, the driver never needs to pre-create `output/client/...`, `output/ast/...`, etc. — the target paths in §2.4 can be chosen freely per artifact.

---

## 3. Share-link encoder (`scripts/hash.js`)

### 3.1 Purpose

`hash.js` reproduces the encoding format used by the hosted editor at `svelte.dev/playground`. It snapshots the current sandbox and prints a URL whose *fragment* fully reconstructs the workspace — no server round-trip, no persistence.

### 3.2 The `compress` component

```javascript
async function compress(payload) { /* Blob → gzip → URL-safe base64 */ }
```

The encoding pipeline is:

```mermaid
flowchart LR
    A["JSON payload<br/>{ name, files[] }"] --> B["new Blob([payload]).stream()"]
    B --> C["CompressionStream('gzip')"]
    C --> D["read() loop:<br/>bytes → String.fromCharCode<br/>(byte-wise, NOT utf-8 decode)"]
    D --> E["btoa(buffer)"]
    E --> F["'+' → '-' , '/' → '_'<br/>(URL-safe base64)"]
    F --> G["https://svelte.dev/playground/untitled#&lt;hash&gt;"]
```

Implementation details worth knowing:

- **Payload shape** — `{ name: 'sandbox', files: [{ type: 'file', name, basename, contents, text: true }] }`. Only the *top level* of `src/` is snapshotted (`readdirSync` + `isDirectory()` filter), which mirrors how the playground's flat file model works.
- **Byte-safe base64** — gzip output is binary, but the reader accumulates it with `String.fromCharCode(value[i])` byte-by-byte *before* `btoa`. Decoding the chunk as UTF-8 would corrupt non-ASCII bytes and make `btoa` reject the string (the comment in the source calls this out).
- **URL safety** — standard base64's `+` and `/` are replaced with `-` and `_` so the hash survives URL handling.
- **Streaming** — the whole job is expressed as a `Blob → CompressionStream → reader` pipeline, so arbitrarily large sandboxes compress without building an intermediate buffer of compressed bytes.

### 3.3 Round-trip with `scripts/download.js`

The encoding is exactly inverted by the sibling script `download.js`, completing the loop between the hosted playground and the local sandbox:

```mermaid
sequenceDiagram
    participant Dev as Developer
    participant H as scripts/hash.js
    participant URL as svelte.dev/playground
    participant D as scripts/download.js
    participant FS as src/

    Dev->>H: node scripts/hash.js
    H->>FS: read top-level files
    H->>H: JSON → gzip → URL-safe base64
    H-->>Dev: prints playground/untitled#<hash>
    Dev->>URL: opens link in browser
    URL-->>Dev: sandbox restored from hash
    Dev->>D: node scripts/download.js <url>
    D->>D: base64 → gunzip → JSON.parse
    D->>FS: writeFileSync each file
    Note over FS: (legacy IDs without hash<br/>are fetched via the<br/>playground API instead)
```

---

## 4. Relationship to the rest of the system

The sandbox is a pure *consumer* of the compiler's public API — every entry point it calls is documented in the compiler modules:

```mermaid
flowchart TD
    subgraph sandbox["sandbox-playground (this module)"]
        RUN["run.js<br/>batch compile driver"]
        HASH["scripts/hash.js<br/>share-link encoder"]
    end

    subgraph infra["Compiler Infrastructure"]
        ENTRY["compile / compileModule<br/>compileModule entry point"]
    end

    subgraph fe["Compiler Front-End"]
        PARSE["parse (1-parse)<br/>AST + template state machine"]
        MIG["migrate (migrate module)"]
    end

    subgraph be["Compiler Back-End"]
        CLIENT["client transform<br/>(incl. fragments:'tree')"]
        SERVER["server transform"]
    end

    RUN -->|"parse(source,{modern:true})"| PARSE
    RUN -->|"migrate(source)"| MIG
    RUN -->|"compile(source,{generate})"| ENTRY
    RUN -->|"compileModule(source)"| ENTRY
    ENTRY -->|"client pass"| CLIENT
    ENTRY -->|"server pass"| SERVER
    HASH -.->|"encoded src/ snapshot"| URL["svelte.dev/playground"]
```

- **`parse` and `migrate`** belong to the front-end: see [Compiler Front-End (Parsing, Analysis & CSS Scoping Pipeline)](Compiler_Front-End_(Parsing,_Analysis___CSS_Scoping_Pipeline).md) for the template state machine, JS/TS handling and parse utilities, and [Source Migration & Preprocessing Tooling](Source_Migration___Preprocessing_Tooling.md) for how `migrate` performs codemod-style Svelte 4 → 5 upgrades.
- **`compile` and `compileModule`** are the orchestration entry points of [Compiler Infrastructure (Core Orchestration, Diagnostics & AST Type Model)](Compiler_Infrastructure_(Core_Orchestration,_Diagnostics___AST_Type_Model).md). `compile` fans out into the two back-ends of [Compiler Back-End (Client & Server Code Generation)](Compiler_Back-End_(Client___Server_Code_Generation).md) — the `generate: 'client'` and `generate: 'server'` loop in `run.js` exercises exactly those two visitors trees, and the `fragments: 'tree'` variant additionally compares the template emission strategies.
- The **warnings** printed by `run.js` (a11y, CSS, options deprecations) originate from the diagnostics layer described in the Compiler Infrastructure module, and are rendered to the console as `code` + `frame` produced by `CompileDiagnostic#get_code_frame`.
- The **`experimental: { async: true }`** flag enables the experimental async Svelte features that the [Reactive Runtime Engine](Reactive_Runtime_Engine_(Signals,_Effects___Batching_with_Dev-Mode_Instrumentation).md) implements (async mode flags, `await_block` support), which is why the sandbox is a common testbed for those features.
- The **SSR harness** (`ssr-dev.js`, `ssr-prod.js`) consumes the server-side output path via `svelte/server`'s `render` — the runtime side of that is covered by [Component Rendering Backends (Client DOM & Server SSR)](Component_Rendering_Backends_(Client_DOM___Server_SSR).md).
- The **repository engineering context** (how such scratch tooling relates to benchmarks and build scripts) is described in [Repository Engineering Infrastructure (Benchmarks, Build Scripts & Playground)](Repository_Engineering_Infrastructure_(Benchmarks,_Build_Scripts___Playground).md).

---

## 5. Typical maintainer workflow

```bash
cd playgrounds/sandbox

# 1. grab a workspace (share link, legacy playground link, or scratch files)
node scripts/download.js "https://svelte.dev/playground/untitled#<hash>"

# 2. hack on src/**  (vite dev / SSR harness for live preview)
node ssr-dev.js

# 3. dump all compiler artifacts (AST, migrated, client+server JS, CSS)
node run.js            # add --runes to compile in runes mode
node scripts/hash.js   # optionally publish the current state as a share link

# 4. promote a repro into a permanent test sample
node scripts/create-test.js runtime-runes/my-bug
```

The short feedback cycle — *edit → compile → inspect `output/`* — combined with the share-link encoder is what makes this module the debugging front door of the Svelte compiler.
