# CSS Transform Pipeline (`compiler_css_pipeline_transform`)

## 1. Introduction

`compiler_css_pipeline_transform` is the **final stage of Svelte's CSS scoping pipeline**. It lives in
`packages/svelte/src/compiler/phases/3-transform/css/index.js` and is responsible for converting the
*analyzed* CSS AST (produced by [compiler_css_pipeline_analysis](compiler_css_pipeline_analysis.md))
into the **final CSS output text plus sourcemap** that is shipped with the compiled component.

The module consumes a component's raw `<style>` source together with the analysis metadata computed
during phase 2 and produces, via a single `MagicString` edit buffer:

- **Scoped selectors** — component-scoped selectors get a `.svelte-<hash>` class (first occurrence)
  or a `:where(.svelte-<hash>)` wrapper (subsequent occurrences) so that scoping never leaks
  specificity across selector boundaries.
- **Global handling** — `:global`, `:global(...)`, `:global { ... }` blocks and `-global-` keyframes
  are resolved into plain CSS.
- **Dead-code elimination** — selectors and rules the analyzer marked as unused, and empty rules,
  are removed (production) or commented out (dev).
- **Optional minification** — whitespace removal when styles are injected in production builds.
- **Sourcemap generation** — a source map for the CSS output, merged with any upstream
  preprocessor source map.

| | |
|---|---|
| **Module** | `compiler_css_pipeline_transform` (child of [compiler_css_pipeline](compiler_css_pipeline.md)) |
| **Source file** | `packages/svelte/src/compiler/phases/3-transform/css/index.js` |
| **Entry point** | `render_stylesheet(source, analysis, options)` |
| **Core components** | `escape_comment_close`, `is_in_global_block`, `remove_global_pseudo_class` |
| **Input** | raw CSS source, `analysis.css` (scoped AST + metadata) from [compiler_css_pipeline_analysis](compiler_css_pipeline_analysis.md) |
| **Output** | `{ code, map, hasGlobal }` consumed by [compiler_client_transform](compiler_client_transform.md) / [compiler_server_transform](compiler_server_transform.md) |

---

## 2. Architecture: Position in the System

The transform sits at the **boundary between the compiler front-end and the code-generation
back-end**. Parsing ([compiler_parser](compiler_parser.md)) builds the CSS AST, the analyzer
([compiler_analyzer](compiler_analyzer.md) + [compiler_css_pipeline_analysis](compiler_css_pipeline_analysis.md))
deposits scoping decisions as per-node `metadata`, and this module *realizes* those decisions as
concrete text edits. The result is attached to the compile result and consumed by the client/server
transforms or by bundler tooling.

```mermaid
flowchart TB
    subgraph FE["Compiler Front-End - Parsing, Analysis and CSS Scoping"]
        direction TB
        P["compiler_parser<br/>(1-parse)"]
        A["compiler_analyzer<br/>(2-analyze visitors / scope)"]
        subgraph CSS["compiler_css_pipeline"]
            direction LR
            CA["compiler_css_pipeline_analysis<br/>css-analyze.js - css.js<br/>marks selectors used / scoped / global"]
            CT["compiler_css_pipeline_transform<br/>3-transform/css/index.js<br/>(THIS MODULE)"]
            CA -->|"analysis.css:<br/>ast, hash, keyframes, has_global, metadata"| CT
        end
        P --> A --> CSS
    end

    subgraph BE["Compiler Back-End - Code Generation"]
        direction LR
        CL["compiler_client_transform"]
        SV["compiler_server_transform"]
    end

    subgraph INFRA["Compiler Infrastructure"]
        CORE["compiler_core<br/>state.js: dev flag<br/>mapped_code.js"]
        DIAG["compiler_diagnostics<br/>css_unused_selector warning"]
        TYP["compiler_types<br/>AST.CSS node types"]
    end

    subgraph RT["Runtime consumers of the output"]
        CR["client_dom_renderer<br/>append_styles / css-props"]
        CD["client_dev_mode<br/>cleanup_styles (HMR)"]
    end

    CT -->|"css.code / css.map / css.hasGlobal"| CL
    CT -->|"css.code / css.map / css.hasGlobal"| SV
    CORE -.-> CT
    DIAG -.->|"sets metadata.used during analysis"| CT
    TYP -.-> CT
    CT -.->|"injected styles"| CR
    CT -.->|"HMR style cleanup"| CD
```

**Key architectural property:** the transform performs **no semantic analysis of its own**. Every
decision (which selector is unused, which relative selector is scoped, what counts as a global
block) has already been encoded as `metadata` by the analysis phase. The transform is a pure
*AST-metadata → text-edit* renderer. This keeps it deterministic, fast, and trivially consistent
with the warnings the analyzer emitted (see [compiler_diagnostics](compiler_diagnostics.md)).

---

## 3. Internal Components

```mermaid
flowchart TB
    subgraph MOD["3-transform/css/index.js"]
        RS["render_stylesheet(source, analysis, options)<br/>entry point"]
        ST["State<br/>code, hash, minify, selector,<br/>keyframes, specificity.bumped"]
        V["visitors (zimmerframe)<br/>_ , Atrule, Declaration, Rule,<br/>SelectorList, ComplexSelector,<br/>PseudoClassSelector"]
        G1["is_in_global_block(path)"]
        G2["remove_global_pseudo_class(selector, combinator, state)"]
        G3["escape_comment_close(node, code)"]
        H1["remove_preceding_whitespace(end, state)"]
        H2["is_empty(rule, is_in_global_block)"]
        H3["is_used(rule)"]
    end

    RS -->|"creates"| ST
    RS -->|"walk(ast, state, visitors)"| V
    V <--> ST
    V --> G1
    V --> G2
    V --> G3
    V --> H1
    V --> H2
    H2 --> H3
    G2 -->|"edits"| ST
    G3 -->|"edits"| ST
```

### 3.1 `render_stylesheet(source, analysis, options)` — entry point

Creates a `MagicString` over the raw CSS source, initializes the walk `State`, runs the visitor
walk over `analysis.css.ast`, then trims the output to the stylesheet boundaries, generates the
source map, merges it with any preprocessor map, and returns the final result:

```js
const css = {
  code: code.toString(),
  map: code.generateMap({ includeContent: true, source: options.filename, file: ... }),
  hasGlobal: analysis.css.has_global
};
```

Notable behaviors:

- **State initialization**
  - `hash` — `analysis.css.hash` (e.g. `svelte-1a2b3c`), the component's scoping identity.
  - `selector` — `.${analysis.css.hash}`, the scoping class inserted into selectors.
  - `minify` — `analysis.inject_styles && !options.dev` (minification happens only when styles are
    injected into JS in production; see §8).
  - `keyframes` — names of keyframes declared by this component (from analysis).
  - `specificity.bumped` — mutable flag tracking whether the one-time specificity bump was applied.
- **Boundary trimming** — `code.remove(0, ast.content.start)` and
  `code.remove(ast.content.end, source.length)` strip everything outside the `<style>` content.
- **Dev injection support** — when `dev && options.css === 'injected'`, a
  `/*# sourceMappingURL=... */` comment is appended so browsers can map injected styles.

### 3.2 The visitor set

The walk is driven by a zimmerframe visitor table (`walk(ast, state, visitors)`); `_` runs for
**every** node and records sourcemap locations.

| Visitor | Responsibility |
|---|---|
| `_` | Register `node.start`/`node.end` as sourcemap locations; recurse. |
| `Atrule` | **Keyframes renaming.** Local `@keyframes name` → `@keyframes svelte-<hash>-name`; `-global-` prefix is stripped for globally published keyframes; inside a global block no renaming happens. Returns early — keyframes bodies are never re-processed. |
| `Declaration` | **`animation` / `animation-name` rewriting.** Any animation name that matches a locally declared keyframe gets the `svelte-<hash>-` prefix. In minify mode, collapses whitespace after the colon (except for custom properties `--foo`, which some Chromium versions treat differently). |
| `Rule` | **Pruning & global-block unwrapping.** Strips preceding whitespace when minifying; comments out or removes empty and unused rules; unwraps bare `:global { ... }` blocks by commenting the wrapper selector while recursing only into the body. |
| `SelectorList` | **Selector pruning & specificity bookkeeping.** Comments out or removes unused complex selectors in the list; resets the specificity-bump state per rule prelude, inheriting "already bumped" from ancestor rules that had local selectors. |
| `ComplexSelector` | **Scoping.** For each relative selector: strips `:global`/`:global(...)` (via `remove_global_pseudo_class`), inserts `&` where a nested rule needs it, and appends/prepends the scoping class or `:where(scoping class)` to scoped selectors. Restores the bump state afterwards. |
| `PseudoClassSelector` | Recurses only into logical pseudo-classes `is`, `where`, `has`, `not`, whose arguments contain further selector lists. Other pseudo-classes (`:hover`, …) have no children. |

### 3.3 Core component: `is_in_global_block(path)`

```js
function is_in_global_block(path) {
  return path.some((node) => node.type === 'Rule' && node.metadata.is_global_block);
}
```

Answers: *"is the current node anywhere inside a bare `:global { ... }` rule?"* It scans the
zimmerframe walk `path` (the ancestor stack) for a rule flagged `is_global_block` by the analyzer
(`is_global_block_selector` in [compiler_css_pipeline_analysis](compiler_css_pipeline_analysis.md)).

This predicate gates three behaviors:

1. **No keyframes renaming** inside global blocks (`Atrule` visitor).
2. **No pruning of empty/unused rules** inside global blocks — content there is user-authored
   global CSS and must be preserved verbatim.
3. **No unused-selector comment injection** (`SelectorList` visitor), except for the prelude of a
   multi-selector global-block rule itself.

> Note: the analysis phase contains an identical predicate of the same name; the transform keeps a
> local copy because it must consult the *transform-time* walk path. See the analysis module's
> documentation for how `metadata.is_global_block` is computed.

### 3.4 Core component: `remove_global_pseudo_class(selector, combinator, state)`

Edits the `MagicString` to eliminate a `:global` pseudo-class, with two shapes:

| Input shape | Transformation | Mechanism |
|---|---|---|
| `:global` (bare, `args === null`) as a descendant — `div :global.x` | `div.x` | Whitespace before the pseudo-class is walked back over, then `code.update(start, selector.start + ':global'.length, '')` blanks it. |
| `:global` bare mid-compound — `div:global.x` | `div.x` | Same, without whitespace backtracking. |
| `:global(...)` functional — `:global(body)` | `body` | Removes the `:global(` prefix and the closing `)` separately. |

Implementation details worth knowing:

- The bare case uses **`code.update(..., '')` instead of `code.remove(...)`** deliberately: a
  comment left by unused-selector pruning may already occupy overlapping characters, and `update`
  keeps overlapping edits consistent.
- The `ComplexSelector` visitor also uses this helper indirectly for parent-rule contexts:
  `div { :global.x { ... } }` becomes `div { &.x { ... } }` — the visitor prepends `&` before
  calling this helper's logic, so the nested rule keeps its parent reference after `:global`
  disappears.
- Comma hygiene: when the last selector of a multi-selector rule prelude is a `:global` one and the
  *next* selector in the list is still used, the visitor blanks the comma/gap; if the next selector
  is unused, its own pruning removes the comma instead.

### 3.5 Core component: `escape_comment_close(node, code)`

When a rule is commented out in dev mode (`/* (unused) ... */` or `/* (empty) ... */`), any CSS
comment *inside* the rule that itself ends with `*/` would prematurely terminate the wrapper
comment. This helper performs a linear scan of the original source between `node.start` and
`node.end`, tracking:

- **escape state** — a `\` escapes the following character,
- **comment state** — toggled by `/*` … `*/`,

and rewrites every inner `*/` as `*\/` (via `code.prependRight(++i, '\\')`). The backslash makes
the slash a regular escaped character for CSS parsers, so the wrapper comment stays balanced.

It is only needed in **non-minified mode**, because only that mode wraps dead code in comments;
minify mode removes the text outright.

### 3.6 Supporting helpers

| Helper | Signature | Purpose |
|---|---|---|
| `remove_preceding_whitespace(end, state)` | walks backwards over whitespace | Minification helper: collapses whitespace before rule starts, declaration colons and block closings. |
| `is_empty(rule, is_in_global_block)` | recursive | True if the rule has no declarations, no used non-empty child rules, and no content-bearing at-rules. A `:global` block is empty iff its body is empty. |
| `is_used(rule)` | `rule.prelude.children.some((s) => s.metadata.used)` | True if any complex selector in the prelude was marked used by the analyzer. |

---

## 4. Scoping & Specificity Model

Scoping is applied per **relative selector** flagged `metadata.scoped` by the analyzer, with a
one-time specificity bump per complex selector:

```mermaid
flowchart TD
    S["RelativeSelector (metadata.scoped)"] --> A{"sole selector is ':is' / ':where'?"}
    A -->|yes| SKIP["skip - no modifier"]
    A -->|no| B{"contains a nesting selector '&'?"}
    B -->|yes| SKIP2["skip - '&' already binds scope"]
    B -->|no| C{"specificity.bumped?"}
    C -->|no| D1["use '.svelte-hash'"]
    C -->|yes| D2["use ':where(.svelte-hash)'"]
    D1 --> E["set specificity.bumped = true"]
    D2 --> E
    E --> F{"scan compound from the end:<br/>first Type/Pseudo position?"}
    F -->|"TypeSelector '*'"| G1["replace '*' with the modifier"]
    F -->|"Pseudo class/element<br/>(except ':root' / ':host') at pos 0"| G2["prepend modifier before it"]
    F -->|"otherwise"| G3["append modifier after the compound"]
```

Why this design:

- The **first** scoped selector in a complex selector receives a real class → **+0-1-0 specificity
  bump**, mirroring classic Svelte scoping.
- Every **subsequent** scoped selector in the same complex selector uses `:where(...)` → zero
  specificity cost, so `div.svelte-x p:where(.svelte-x)` and friends behave predictably.
- The bump state is **reset per rule prelude** (`SelectorList` with a `Rule` parent) but starts as
  *already bumped* if any ancestor rule had local selectors (`metadata.has_local_selectors`
  chain). After each `ComplexSelector` finishes, the previous state is restored so sibling
  selectors are unaffected.
- Inside `:is(...)` / `:where(...)` / `:has(...)` / `:not(...)`, the existing state is preserved
  ("keep existing specificity bump state") rather than reset.

---

## 5. Global CSS Handling

All global-authoring constructs are resolved to plain CSS:

```mermaid
flowchart LR
    subgraph Inputs["Authored patterns"]
        I1[":global(...) selector"]
        I2["div :global.x (bare descendant)"]
        I3["div { :global.x { ... } } (nested rule)"]
        I4[":global { ... } (global block)"]
        I5["@keyframes -global-name"]
    end
    subgraph Outputs["Emitted CSS"]
        O1["body"]
        O2["div.x"]
        O3["div { &.x { ... } }"]
        O4["body { ... } (wrapper commented in dev,<br/>braces stripped in minify)"]
        O5["@keyframes name"]
    end
    I1 -->|"remove_global_pseudo_class"| O1
    I2 -->|"remove_global_pseudo_class"| O2
    I3 -->|"prepend '&' + remove_global_pseudo_class"| O3
    I4 -->|"Rule visitor: unwrap, skip scoping/pruning"| O4
    I5 -->|"Atrule visitor: strip prefix"| O5
```

Additional rules enforced by the walk:

- Selectors marked `metadata.is_global` are never scoped; scoped selectors adjacent to them are
  still handled normally.
- A bare `:global` in the **middle** of a compound selector (e.g. `div:global.x`) is stripped
  without touching surrounding characters.
- `@keyframes` bodies are visited but deliberately **not transformed** — the `Atrule` visitor
  returns early after handling the name ("don't transform anything within").
- Inside `:global { ... }` blocks, `@keyframes` names are left untouched (no hash prefix, no
  `-global-` stripping) because everything there is already global.

---

## 6. Pruning: Unused & Empty Code (Dev vs. Production)

The `Rule` visitor implements the decision flow below. Behavior differs by mode:

```mermaid
flowchart TD
    R["visit Rule"] --> M{"minify mode?"}
    M -->|yes| W["strip preceding whitespace<br/>before rule and before block end"]
    M -->|no| E
    W --> E{"rule empty?<br/>is_empty()"}

    E -->|"yes, dev"| CO1["wrap in '/* (empty) ... */'<br/>escape_comment_close()"]
    E -->|"yes, minify"| RM1["remove node"]
    E -->|no| U

    CO1 --> STOP["return - no recursion"]
    RM1 --> STOP

    U{"any selector used?<br/>is_used() AND not in global block"}
    U -->|"no, dev"| CO2["wrap in '/* (unused) ... */'<br/>escape_comment_close()"]
    U -->|"no, minify"| RM2["remove node"]
    U -->|yes| GB
    CO2 --> STOP
    RM2 --> STOP

    GB{"metadata.is_global_block AND<br/>single simple selector in prelude?"}
    GB -->|yes| UW["comment out ':global {' wrapper<br/>recurse into body only"]
    GB -->|no| NEXT["next() - recurse normally"]
    UW --> STOP
```

Key semantics:

- **Dev keeps dead code visible.** Unused/empty rules are wrapped in comments (with inner `*/`
  escaped) so developers can see them in DevTools; that's why `escape_comment_close` exists.
- **Production removes dead code.** When `minify` is on, the node text is deleted outright.
- **Global blocks are never pruned** — `is_in_global_block(path)` suppresses both emptiness- and
  unused-based removal inside them.
- **Selector-level pruning** (`SelectorList` visitor) handles *partially* used selector lists:
  runs of unused complex selectors are commented (`/* (unused) */`, including the preceding
  comma) or removed, while used ones survive. It skips work when nested inside an already-unused
  complex selector (that one is commented as a whole) and handles the special case of a
  multi-selector prelude inside a global-block rule.

The `metadata.used` flags this relies on are produced during analysis — where the
`css_unused_selector` warning is also emitted (see
[compiler_css_pipeline_analysis](compiler_css_pipeline_analysis.md) and
[compiler_diagnostics](compiler_diagnostics.md)). The transform itself never warns or errors.

---

## 7. Minification

Minification activates only when `analysis.inject_styles && !options.dev`, i.e. styles are being
injected into the JS output in a production build. Effects:

- Whitespace before rules and before closing braces is removed
  (`remove_preceding_whitespace`).
- Whitespace after declaration colons is collapsed — **except for custom properties** (`--foo:`),
  because some Chromium versions treat `--foo: ;` and `--foo:;` differently.
- Empty and unused rules are removed instead of commented.
- Global-block wrappers have their braces stripped instead of commented.

---

## 8. Sourcemaps & Preprocessor Integration

```mermaid
flowchart LR
    A["walk: '_' visitor records<br/>start/end of every node"] --> B["code.generateMap(<br/>includeContent: true,<br/>source: filename,<br/>file: cssOutputFilename)"]
    B --> C["merge_with_preprocessor_map<br/>(compiler_core / mapped_code.js)"]
    C --> D{"dev and css==='injected'?"}
    D -->|yes| E["append '/*# sourceMappingURL=... */'"]
    D -->|no| F["return css object"]
    E --> F
```

- `generateMap({ includeContent: true })` embeds the source content, making lookups robust.
- [compiler_core](compiler_core.md)'s `merge_with_preprocessor_map` chains the map with a
  preprocessor-generated map (e.g. from PostCSS), aligning `sources` entries first and making them
  relative afterwards.
- In dev with injected styles, a `sourceMappingURL` comment is appended directly to `css.code` so
  DevTools can resolve mappings for runtime-injected `<style>` elements.

---

## 9. End-to-End Process Flow

```mermaid
sequenceDiagram
    participant C as compile() - compiler_core
    participant An as css_pipeline_analysis
    participant T as css_pipeline_transform (this module)
    participant M as mapped_code.js
    participant O as client / server transform

    C->>An: analyze CSS AST (prune, scope, hash)
    An-->>C: analysis.css { ast, hash, keyframes, has_global, metadata }
    C->>T: render_stylesheet(source, analysis, options)
    T->>T: MagicString created; State built
    T->>T: zimmerframe walk - visitors edit code
    Note over T: scope selectors, strip :global,<br/>rename keyframes, prune unused,<br/>optionally minify
    T->>M: merge_with_preprocessor_map(css, options, source)
    T-->>C: { code, map, hasGlobal }
    C->>O: attach CSS result (external file or injection code)
```

---

## 10. Worked Example

Given a component with hash `svelte-1a2b3c`:

```css
/* authored <style> content */
div {
  color: red;
}
:global(body) {
  margin: 0;
}
.never-used {
  color: blue;
}
@keyframes spin {
  to { transform: rotate(360deg); }
}
p {
  animation: spin 1s linear infinite;
}
```

**Production output** (minified/injected):

```css
div.svelte-1a2b3c{color:red}
body{margin:0}
@keyframes svelte-1a2b3c-spin{to{transform:rotate(360deg)}}
p.svelte-1a2b3c{animation:svelte-1a2b3c-spin 1s linear infinite}
```

**Dev output** (no minify) — the dead rule is preserved as a comment:

```css
div.svelte-1a2b3c { color: red; }
body { margin: 0; }
/* (unused) .never-used {
  color: blue;
} */
@keyframes svelte-1a2b3c-spin { to { transform: rotate(360deg); } }
p.svelte-1a2b3c { animation: svelte-1a2b3c-spin 1s linear infinite; }
```

Visitor mapping: `ComplexSelector` added `.svelte-1a2b3c`, `remove_global_pseudo_class` produced
`body`, `Rule` pruned `.never-used` (using `escape_comment_close` in dev), and the `Atrule` +
`Declaration` visitors renamed both the keyframes and the `animation` reference.

---

## 11. Contract with the Analysis Phase (Data Flow In)

The transform reads the following fields, all established by
[compiler_css_pipeline_analysis](compiler_css_pipeline_analysis.md):

| Input | Set by analysis | Used by the transform to… |
|---|---|---|
| `analysis.css.ast` | parse + analyze | drive the walk (`AST.CSS.StyleSheet`) |
| `analysis.css.hash` | analyze | build `.svelte-<hash>` scope selector and keyframe prefixes |
| `analysis.css.keyframes` | analyze (`is_keyframes_node` collection) | decide which `animation`/`animation-name` names to prefix |
| `analysis.css.has_global` | analyze (`is_unscoped` etc.) | expose `hasGlobal` to downstream tooling |
| `analysis.inject_styles` | options resolution | decide whether minification applies |
| `Selector.metadata.used` | prune pass (emits `css_unused_selector`) | prune rules and complex selectors |
| `RelativeSelector.metadata.is_global` | `is_global_block_selector` / global detection | route to `remove_global_pseudo_class` |
| `RelativeSelector.metadata.scoped` | scoping pass | insert scope class / `:where(...)` |
| `Rule.metadata.is_global_block` | bare `:global {` detection | unwrap global blocks; suppress scoping/pruning |
| `Rule.metadata.parent_rule`, `has_local_selectors` | rule-tree linking | inherit specificity-bump state |

---

## 12. Dependencies

| Import | Origin | Purpose |
|---|---|---|
| `MagicString` | `magic-string` (external) | edit buffer; textual edits and sourcemap generation |
| `walk` | `zimmerframe` (external) | AST traversal with `path` (ancestor stack), `context.next()`, scoped `visit()` |
| `is_keyframes_node`, `regex_css_name_boundary`, `remove_css_prefix` | `phases/css.js` ([compiler_css_pipeline_analysis](compiler_css_pipeline_analysis.md)) | keyframes detection, animation-name tokenization, vendor-prefix stripping |
| `merge_with_preprocessor_map` | `utils/mapped_code.js` ([compiler_core](compiler_core.md)) | chaining with preprocessor sourcemaps |
| `dev` | `state.js` ([compiler_core](compiler_core.md)) | switches dev-vs-production pruning/minify behavior |
| AST types (`AST.CSS.*`) | [compiler_types](compiler_types.md) | typed CSS AST (`Rule`, `SelectorList`, `ComplexSelector`, `PseudoClassSelector`, `Atrule`, `Declaration`, `NestingSelector`, …) |

---

## 13. How the Output Is Consumed

The returned `{ code, map, hasGlobal }` is attached to the compile result and drives:

- **External CSS** (default): the bundler plugin emits `css.code`/`css.map` as a stylesheet asset.
- **Injected styles** (`css: 'injected'`): [compiler_client_transform](compiler_client_transform.md)
  generates code calling the runtime's `append_styles`
  ([client_dom_renderer](client_dom_renderer.md)); in dev,
  `cleanup_styles` ([client_dev_mode](client_dev_mode.md)) removes stale styles during HMR, and the
  `sourceMappingURL` appended by this module keeps DevTools mappings working.
- **SSR**: [compiler_server_transform](compiler_server_transform.md) emits styles into the render
  payload / `<head>` content, honoring `hasGlobal`.

---

## 14. Related Documentation

- [compiler_css_pipeline](compiler_css_pipeline.md) — parent pipeline overview
- [compiler_css_pipeline_analysis](compiler_css_pipeline_analysis.md) — upstream scoping/pruning analysis that produces this module's input metadata
- [compiler_parser](compiler_parser.md) — CSS/JS/template parsing (phase 1)
- [compiler_analyzer](compiler_analyzer.md) — template/JS analysis and scope management (phase 2)
- [compiler_client_transform](compiler_client_transform.md) / [compiler_server_transform](compiler_server_transform.md) — downstream code generation
- [compiler_core](compiler_core.md) — compile orchestration, `dev` state, sourcemap utilities
- [compiler_types](compiler_types.md) — `AST.CSS` node type definitions
- [compiler_diagnostics](compiler_diagnostics.md) — warnings emitted upstream (e.g. `css_unused_selector`)
