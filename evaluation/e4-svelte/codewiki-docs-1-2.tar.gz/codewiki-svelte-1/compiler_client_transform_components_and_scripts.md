# compiler_client_transform_components_and_scripts

> **Module scope:** `packages/svelte/src/compiler/phases/3-transform/client/visitors/` — the client (DOM) transform visitors responsible for **component instantiation** (`<Foo />`, `<svelte:component>`, `<svelte:self>`) and for **script-level statement/expression rewriting** (imports/exports, `$effect` runes, `await` semantics, dev-mode equality, and Svelte 4 legacy `$:` reactive statements).

---

## 1. Overview

This module is a leaf group of the Svelte 5 compiler's client code-generation back-end. After the front-end has produced an analyzed AST (parse → analyze, see [compiler_parser](compiler_parser.md) and [compiler_analyzer](compiler_analyzer.md)), the client transform walks that AST with a visitor registry ([compiler_client_transform](compiler_client_transform.md)) and emits JavaScript that mounts and updates components in the browser.

The visitors in this module cover two complementary concerns — hence the module name:

| Concern | Visitors | What they do |
|---|---|---|
| **Components** | `Component`, `SvelteComponent`, `SvelteSelf` | Serialize component instantiation (props, slots, snippets, events, bindings, CSS custom properties) into runtime calls that render the component at an anchor node. |
| **Scripts** | `ImportDeclaration`, `ExportNamedDeclaration`, `ExpressionStatement`, `AwaitExpression`, `BinaryExpression`, `ForOfStatement`, `LabeledStatement`, `BreakStatement` | Rewrite the `<script>` instance code as it is re-emitted inside the generated component function: hoist/strip module syntax, lower runes to runtime calls, instrument dev-mode semantics, and translate legacy `$:` reactivity. |

The component visitors are thin wrappers: all three delegate to the shared serializer `build_component()` in `visitors/shared/component.js`, differing only in **which name** is used to reference the component function.

---

## 2. Position in the compiler pipeline

```mermaid
flowchart TB
    subgraph FE["Compiler Front-End"]
        P["1-parse<br/>(<a href='compiler_parser.md'>compiler_parser</a>)"] --> A["2-analyze<br/>(<a href='compiler_analyzer.md'>compiler_analyzer</a>)"]
        A --> CSSP["CSS pipeline<br/>(compiler_css_pipeline)"]
    end

    subgraph BE["Compiler Back-End"]
        subgraph CT["client transform<br/>(compiler_client_transform)"]
            TPL["templates<br/>(compiler_client_transform_templates)"]
            SRX["state &amp; reactivity<br/>(compiler_client_transform_state_and_reactivity)"]
            CFB["control-flow blocks<br/>(compiler_client_transform_control_flow_blocks)"]
            EAD["elements &amp; directives<br/>(compiler_client_transform_elements_and_directives)"]
            CS["<b>components &amp; scripts</b><br/>(this module)"]
        end
        SRVT["server transform<br/>(compiler_server_transform)"]
    end

    subgraph RT["Runtime (emitted <code>$.&#42;</code> calls bind here)"]
        CORE["<a href='client_runtime_core.md'>client_runtime_core</a>"]
        DEV["<a href='client_dev_mode.md'>client_dev_mode</a>"]
        DOM["<a href='client_dom_renderer.md'>client_dom_renderer</a>"]
        SHARED["<a href='shared_runtime.md'>shared_runtime</a>"]
    end

    FE -->|"analyzed AST + metadata"| CT
    FE -->|"analyzed AST + metadata"| SRVT
    CT -->|"emits calls"| RT
```

**Key point:** the transform does not *execute* components — it *emits calls* into the reactive runtime engine ([client_runtime_core](client_runtime_core.md), [client_dom_renderer](client_dom_renderer.md)). Every visitor below is best understood as "AST node in → JavaScript + a runtime call out".

---

## 3. Architecture

### 3.1 Visitor dispatch and output buffers

All visitors share the zimmerframe-walk context (`ComponentContext`): each receives the ESTree/AST node plus a context exposing `visit()`, `next()` (default traversal), `stop()`, and the mutable `state`. Visitors communicate results by pushing into **state buffers**, which the main client serializer later assembles into the final module:

```mermaid
flowchart LR
    subgraph WALK["walk(AST, visitors, context)"]
        DISP["visitor registry dispatch<br/>by node.type"]
    end

    DISP --> CV["Component<br/>SvelteComponent<br/>SvelteSelf"]
    DISP --> ID["ImportDeclaration"]
    DISP --> EN["ExportNamedDeclaration"]
    DISP --> ES["ExpressionStatement"]
    DISP --> AE["AwaitExpression"]
    DISP --> BEX["BinaryExpression"]
    DISP --> FOS["ForOfStatement"]
    DISP --> LS["LabeledStatement"]
    DISP --> BS["BreakStatement"]

    CV -->|"build_component()"| INIT["state.init[]<br/>instance statements"]
    EN --> INIT
    ES --> INIT
    ID -->|"when 'hoisted' in state"| HST["state.hoisted[]<br/>module-level imports"]
    AE -->|"node replacement"| AST2["rewritten AST<br/>(returned node)"]
    BEX -->|"dev: node replacement"| AST2
    FOS -->|"dev+async: node replacement"| AST2
    LS -->|"legacy $:"| LRS["state.legacy_reactive_statements<br/>Map&lt;node, stmt&gt;<br/>(topologically sorted later)"]
    BS -->|"break $:"| LRS
    TPLX["state.template<br/>(anchor comments / wrapper elements)"]

    INIT & HST & LRS & AST2 & TPLX --> OUT["final client JS module"]
```

Output channels used by this module:

| Buffer | Producer | Consumer |
|---|---|---|
| `state.init` | `Component`, `SvelteComponent`, `SvelteSelf`, `ExportNamedDeclaration` (indirectly), `ExpressionStatement` | Main component serializer → instance function body |
| `state.hoisted` | `ImportDeclaration` (when present in state, e.g. the class-interop `is_instance` pass) | Module-scope prologue |
| `state.legacy_reactive_statements` | `LabeledStatement` | Inserted in topological dependency order for Svelte 4 compatibility |
| Returned AST nodes | `AwaitExpression`, `BinaryExpression`, `ForOfStatement`, `BreakStatement` | Parent traversal (node replacement) |
| `state.template` | `build_component` (anchor comment, CSS-props wrapper element) | Template serialization (see [compiler_client_transform_templates](compiler_client_transform_templates.md)) |

### 3.2 Decision matrix: which component visitor fires

| Svelte source | AST node | Name passed to `build_component` | Dynamic? |
|---|---|---|---|
| `<Greeting …>` | `Component` | `node.name` (`Greeting`; may be `context.state.scope.generate(name)` if `metadata.dynamic`, i.e. a dotted/complex tag) | only if `metadata.dynamic` |
| `<svelte:component this={X}>` | `SvelteComponent` | `$$component` (intermediate binding resolved at runtime via `$.component`) | always |
| `<svelte:self>` | `SvelteSelf` | `context.state.analysis.name` — the enclosing component's own name | via recursion, not via `$.component` |

---

## 4. Component visitors in depth

### 4.1 The three entry points

All three visitors are one-liners around the shared serializer:

```js
// Component.js — <Greeting />
const component = build_component(node, node.name, context);
context.state.init.push(component);

// SvelteComponent.js — <svelte:component this={X}>
const component = build_component(node, '$$component', context);
context.state.init.push(component);

// SvelteSelf.js — <svelte:self>
const component = build_component(node, context.state.analysis.name, context);
context.state.init.push(component);
```

The name passed in determines **how the component function is referenced** in emitted code:

* `Component` → referenced as an identifier resolved through scope analysis (`Greeting(...)`), unless `metadata.dynamic` (e.g. `<components.Foo />`), in which case it goes through the dynamic path.
* `SvelteComponent` → the tag is only known at runtime, so the emitted code calls `$.component(anchor, () => X, ($$anchor, $$component) => …)`.
* `SvelteSelf` → recursion is expressed by the static component name itself.

### 4.2 What `build_component` produces

`build_component` (in `visitors/shared/component.js`) performs the heavy lifting shared by all three visitors. It consumes analysis metadata created during phase 2 (e.g. `attribute.metadata.expression.has_state`, `node.metadata.scopes`, see [compiler_analyzer](compiler_analyzer.md) and [compiler_analyzer_scope](compiler_analyzer_scope.md)) and emits the instantiation code:

```mermaid
flowchart TD
    START["build_component(node, name, context)"] --> ATTR{"iterate attributes"}
    ATTR -->|"Attribute"| A1["static → b.init prop<br/>stateful → b.get prop<br/>--custom-prop → collected<br/>for $.css_props"]
    ATTR -->|"OnDirective"| A2["build_event_handler →<br/>$$events prop (once → $.once)"]
    ATTR -->|"SpreadAttribute"| A3["static value or<br/>thunk (+ $.get / Memoizer)"]
    ATTR -->|"BindDirective"| A4["get/set prop pair (delayed)<br/>bind:this captured<br/>dev: $.ownership_validator.binding"]
    ATTR -->|"AttachTag"| A5["$.attachment prop"]
    ATTR -->|"LetDirective"| A6["slot-scope lets<br/>(this slot or child slots)"]

    ATTR --> FRAG{"iterate fragment children"}
    FRAG -->|"SnippetBlock"| F1["snippet fn → prop +<br/>$$slots entry (true)"]
    FRAG -->|"element/tag"| F2["group by slot name →<br/>$$anchor, $$slotProps => {…} arrow"]
    F2 --> F3{"default slot?"}
    F3 -->|"no lets, no fragment-lets"| F4["children prop = slot_fn<br/>(dev: $.wrap_snippet)<br/>+ $$slots.default = true"]
    F3 -->|"legacy lets present"| F5["$$slots.default = slot_fn<br/>children = $.invalid_default_snippet"]

    A1 & A2 & A3 & A4 & A5 & A6 & F4 & F5 --> PROPSEXP["props expression:<br/>object literal or $.spread_props(…)"]

    PROPSEXP --> DYN{"dynamic component?"}
    DYN -->|"yes"| D1["$.component(anchor,<br/>thunk(tag-expr),<br/>($$anchor, $$component) => {…})"]
    DYN -->|"no"| D2["name(anchor, props)"]

    D1 & D2 --> CSSP{"custom CSS props?"}
    CSSP -->|"yes"| C1["template: push wrapper element<br/>('g' for svg / svelte-css-wrapper)<br/>$.css_props(anchor, thunk(props))<br/>then fn(anchor.lastChild), $.reset"]
    CSSP -->|"no"| C2["template: push_comment()<br/>emit fn(anchor) + svelte_meta"]

    C1 & C2 --> ASYNC{"async values<br/>(Memoizer)?"}
    ASYNC -->|"yes"| OUT2["$.async(anchor, values,<br/>arrow(statements))"]
    ASYNC -->|"no"| OUT["block / single statement<br/>→ pushed to state.init"]
```

Notable behaviours inherited from `build_component`:

* **Memoization** — expressions with calls/awaits used in props are wrapped in deriveds (`$.get`, via the `Memoizer`) so the child does not over-fire when reading them.
* **Delayed props** — `bind:` getters/setters are pushed *after* spreads so spreads cannot clobber bindings; store subscriptions inject `$.mark_store_binding`.
* **Legacy interop** — `$$legacy: true` prop when the component is non-runes and bound with `bind:`; `children`-prop / `$$slots.default` bridging for components mixing snippets and `<slot>`.
* **Dev-mode ownership validation** — `bind:` to a prop of a runes component registers `$$ownership_validator.binding` (see [client_dev_mode](client_dev_mode.md)).

### 4.3 Example transformation (simplified)

```svelte
<!-- input -->
<script>
  import Greeting from './Greeting.svelte';
  let count = $state(0);
</script>

<Greeting name={count} on:click={handle}>Hello</Greeting>
```

```js
// emitted (greatly simplified) into the instance function
import Greeting from './Greeting.svelte';          // ImportDeclaration (kept via next())
let count = $.source(0);                            // by state-&-reactivity visitors

$$renderer.template.push_comment();                 // anchor <!--> for the component
Greeting($$anchor, {                                // Component visitor via build_component
  name: () => count,                                // stateful attribute → getter prop
  $$events: { click: handle },                      // on:click
  children: $.wrap_snippet(App, ($$anchor) => {     // default slot → children prop (dev)
    $$renderer.template.push('Hello');
  }),
  $$slots: { default: true }
});
```

---

## 5. Script & expression visitors in depth

These visitors run while the `<script>` contents are re-emitted inside the generated instance function (or, in the class-interop pass, `is_instance`).

### 5.1 `ImportDeclaration` — module-level hoisting

* If the current state carries a `hoisted` array (contexts where the instance code is nested and imports must live at module scope), the declaration is **moved** there and `b.empty` is emitted in place.
* Otherwise `context.next()` lets the default traversal copy the import unchanged.

### 5.2 `ExportNamedDeclaration` — export stripping in instance code

* In `is_instance` mode (class-compatible instance pass):
  * with a `declaration` → visits **only the inner declaration**, dropping the `export` keyword (`export function foo() {}` → `function foo() {}`);
  * without a declaration (`export { a };`) → `b.empty`.
* Otherwise → `context.next()`; module-level exports are preserved verbatim.

### 5.3 `ExpressionStatement` — rune lowering

Statement-position rune calls are lowered to runtime constructors (rune detection via [`get_rune`](compiler_analyzer_scope.md) from phase 2's scope machinery):

| Source statement | Emitted |
|---|---|
| `$effect(() => {…});` | `$.user_effect(() => {…});` |
| `$effect.pre(() => {…});` | `$.user_pre_effect(() => {…});` |
| `$inspect.trace(…);` | *(removed)* |
| anything else | unchanged (`context.next()`) |

The emitted callee's `loc` is copied from the original rune call to keep source maps accurate. See [client_runtime_core](client_runtime_core.md) (`reactivity/effects.js`) for what `$.user_effect` / `$.user_pre_effect` do.

### 5.4 `AwaitExpression` — context preservation across async boundaries

Async boundaries break synchronous snapshotting of the signal graph, so awaits are selectively wrapped:

```mermaid
flowchart TD
    A["AwaitExpression"] --> V["visit(argument)"]
    V --> TLA{"top-level await?<br/>is_instance &amp; function_depth === 1"}
    TLA -->|"yes"| SAVE["$.save(await argument)"]
    TLA -->|"no"| REAC{"inside a reactive expression?<br/>state.in_derived or ancestor with<br/>metadata before a function boundary"}
    REAC -->|"no"| DEVCHECK1["no wrapping needed"]
    REAC -->|"yes"| LAST{"is it the LAST evaluated<br/>expression in its chain?<br/>(is_last_evaluated_expression)"}
    LAST -->|"yes"| DEVCHECK1
    LAST -->|"no"| SAVE
    DEVCHECK1 --> DEVCHECK2{"dev &amp; !is_ignored(node,<br/>'await_reactivity_loss')"}
    DEVCHECK2 -->|"yes"| TRACK["$.track_reactivity_loss(await argument)"]
    DEVCHECK2 -->|"no"| PASS["return node with visited argument<br/>(or original node if unchanged)"]
    SAVE --> DEVCHECK2
```

Semantics:

* **`$.save`** captures the current value *before* the await so expressions evaluated **after** the await in the same template/`$derived` chain read a consistent snapshot instead of silently re-reading changed state. It is applied to (a) top-level awaits in the instance function and (b) any await that is *not* the last expression evaluated inside a reactive context.
* `is_last_evaluated_expression` walks the ancestor chain (`ArrayExpression`, `CallExpression` args, `BinaryExpression` sides, `ConditionalExpression` test, template quasis, etc.) to decide whether the await is the final read.
* In dev builds, every unwrapped await is additionally wrapped in **`$.track_reactivity_loss`** to warn about reactivity lost across the boundary, unless suppressed with `<!-- svelte-ignore await_reactivity_loss -->` (`is_ignored`, see [compiler_core](compiler_core.md) `state.js`).

Related: `ForOfStatement` performs the analogous instrumentation for iteration:

* `for await (…)` in dev + experimental async mode wraps the iterable in **`$.for_await_track_reactivity_loss`**; otherwise it is left untouched.
* `BinaryExpression` handles the *sync* dev instrumentation: `===`/`!==` become `$.strict_equals(a, b[, false])` and `==`/`!=` become `$.equals(a, b[, false])` — dev-only signal-aware equality helpers ([client_dev_mode](client_dev_mode.md)); production output passes through unchanged.

### 5.5 `LabeledStatement` / `BreakStatement` — Svelte 4 `$:` compatibility

These two visitors implement the legacy reactive-statement contract when `analysis.runes` is false:

```mermaid
flowchart TD
    L["LabeledStatement label '$'"] --> G1{"runes mode?<br/>or nested (path &gt; 1)<br/>or label ≠ '$'"}
    G1 -->|"yes"| NEXT1["context.next() — keep as-is"]
    G1 -->|"no"| G2{"in analysis.reactive_statements?<br/>(built by compiler_analyzer)"}
    G2 -->|"no"| DROP["ignore"]
    G2 -->|"yes"| SER["serialize body to block"]
    SER --> DEPS["build dependency sequence:<br/>build_getter per visible binding<br/>bindable/props → $.deep_read_state"]
    DEPS --> REG["state.legacy_reactive_statements.set(node,<br/>$.legacy_pre_effect(thunk(deps), thunk(body)))"]
    REG --> EMPT["return b.empty (label removed)"]

    B["BreakStatement label '$'"] --> G3{"runes mode or<br/>label ≠ '$'"}
    G3 -->|"yes"| KEEP["no change — normal break"]
    G3 -->|"no"| G4{"directly inside '$:' ?"}
    G4 -->|"yes"| RET["replace with return; —<br/>early-exits the legacy pre-effect"]
    G4 -->|"no"| KEEP2["no change"]
```

Key details:

* **Untracked effect, tracked deps** — to replicate Svelte 4 behaviour, the effect body itself is untracked; only dependencies the analyzer could *see* are read eagerly in the first thunk (`$.legacy_pre_effect(depsThunk, bodyThunk)`). Bindable props / `$$props` / `$$restProps` are wrapped in `$.deep_read_state` because fine-grained `$state` mutations in a runes child would otherwise not re-trigger.
* **Topological order** — statements are registered in `state.legacy_reactive_statements` (keyed by the original node); the main component serializer later inserts them sorted by their dependency graph.
* **`break $;`** — legal inside a `$:` block in Svelte 4 — is rewritten to an early `return` from the generated effect thunk.
* Effects run via `legacy_pre_effect` / `legacy_pre_effect_reset` in the runtime ([client_runtime_core](client_runtime_core.md)).

---

## 6. Context and state contract

| Field (on `context.state` / `context`) | Used by | Purpose |
|---|---|---|
| `context.visit(node)` / `context.next()` / `context.stop()` | all | child traversal, default traversal, bail-out |
| `context.path` | `AwaitExpression` (reactive-context detection), `BreakStatement` | inspect ancestors |
| `state.init` | `Component*`, `ExpressionStatement` | instance-statement accumulation |
| `state.hoisted` | `ImportDeclaration` | module-scope import hoisting |
| `state.is_instance` | `AwaitExpression` (TLA), `ExportNamedDeclaration` | class-interop instance pass flag |
| `state.scope`, `function_depth` | `ExpressionStatement` (`get_rune`), `AwaitExpression` | rune lookup, nesting depth |
| `state.analysis` | `SvelteSelf` (`name`), `LabeledStatement` (`runes`, `reactive_statements`), `build_component` | analyzer-produced metadata |
| `state.template` | `build_component` | anchor comments / wrapper elements (see [compiler_client_transform_templates](compiler_client_transform_templates.md)) |
| `state.options` | `ForOfStatement` (`experimental.async`) | validated compile options ([compiler_core](compiler_core.md)) |
| `dev`, `is_ignored()` (`state.js`) | `AwaitExpression`, `BinaryExpression`, `ForOfStatement` | dev gating + `svelte-ignore` support |

---

## 7. Runtime contract

Every transformation above bottoms out in an `internal/client` call. This is the interface to the reactive runtime:

| Emitted call | Producer visitor | Runtime home (module) |
|---|---|---|
| `$.save(x)` | `AwaitExpression` | `reactivity/async.js` — [client_runtime_core](client_runtime_core.md) |
| `$.track_reactivity_loss(x)` | `AwaitExpression` (dev) | `reactivity/async.js` — [client_runtime_core](client_runtime_core.md) |
| `$.for_await_track_reactivity_loss(x)` | `ForOfStatement` (dev) | `reactivity/async.js` — [client_runtime_core](client_runtime_core.md) |
| `$.equals(a,b[,expected])` / `$.strict_equals(...)` | `BinaryExpression` (dev) | `dev/equality.js` — [client_dev_mode](client_dev_mode.md) |
| `$.user_effect(fn)` / `$.user_pre_effect(fn)` | `ExpressionStatement` | `reactivity/effects.js` — [client_runtime_core](client_runtime_core.md) |
| `$.legacy_pre_effect(deps, body)` | `LabeledStatement` | `reactivity/effects.js` — [client_runtime_core](client_runtime_core.md) |
| `$.deep_read_state(x)` | `LabeledStatement` (deps) | props helpers — [client_runtime_core](client_runtime_core.md) |
| `$.component(anchor, getTag, render)` | `build_component` (dynamic) | [client_runtime_core](client_runtime_core.md) / [client_dom_renderer](client_dom_renderer.md) |
| `$.spread_props`, `$.get`, `$.mark_store_binding` | `build_component` | `reactivity/props.js`, `store.js` — [client_runtime_core](client_runtime_core.md) |
| `$.css_props(anchor, props)` | `build_component` (`--style-props`) | `dom/blocks/css-props.js` — [client_dom_renderer](client_dom_renderer.md) |
| `$.async(anchor, values, fn)` | `build_component` (async props) | `dom/blocks/async.js` — [client_dom_renderer](client_dom_renderer.md) |
| `$.wrap_snippet`, `$.invalid_default_snippet`, `$.attachment`, `$.once`, `$.ownership_validator.binding` | `build_component` | [client_dom_renderer](client_dom_renderer.md) / [client_dev_mode](client_dev_mode.md) / [shared_runtime](shared_runtime.md) |

> **Treeshaking note:** because all runtime access goes through the single `$.` namespace of generated code, the build tooling can verify unused helpers are tree-shaken (see the repository build tooling, `check-treeshakeability`).

---

## 8. Dependencies and related modules

```mermaid
flowchart LR
    subgraph THIS["this module"]
        V["11 visitors"]
    end
    V -->|"build_component,<br/>build_getter, visit"| SHARED["client transform shared utils<br/>(compiler_client_transform)"]
    V -->|"builders b.*"| BUILDERS["compiler_core<br/>(utils/builders.js)"]
    V -->|"get_rune"| SCOPE["compiler_analyzer_scope<br/>(phases/scope.js)"]
    V -->|"dev, is_ignored"| STATE["compiler_core (state.js)"]
    V -->|"metadata: has_state,<br/>has_await, scopes,<br/>reactive_statements, runes"| ANL["compiler_analyzer<br/>(+ compiler_analyzer_js_visitors)"]
    V -->|"AST types"| TYPES["compiler_types<br/>(template.d.ts, legacy-nodes.d.ts)"]
    V -->|"$.&#42; runtime calls"| RT["client_runtime_core /<br/>client_dev_mode /<br/>client_dom_renderer"]
```

* **Upstream (required inputs):** analyzed AST from [compiler_analyzer](compiler_analyzer.md); node/expression `metadata` produced by the block, template and JS visitors ([compiler_analyzer_block_visitors](compiler_analyzer_block_visitors.md), [compiler_analyzer_template_visitors](compiler_analyzer_template_visitors.md), [compiler_analyzer_js_visitors](compiler_analyzer_js_visitors.md)); builders & flags from [compiler_core](compiler_core.md); node shapes from [compiler_types](compiler_types.md).
* **Sibling groups (same walk):** [compiler_client_transform_templates](compiler_client_transform_templates.md) owns template serialization; [compiler_client_transform_state_and_reactivity](compiler_client_transform_state_and_reactivity.md) owns identifiers/assignments/deriveds (the reactive plumbing that `build_getter` and prop getters rely on); [compiler_client_transform_control_flow_blocks](compiler_client_transform_control_flow_blocks.md) owns `{#if}/{#each}/{#await}/…` (and consumes the same `init`/slot machinery); [compiler_client_transform_elements_and_directives](compiler_client_transform_elements_and_directives.md) owns plain/special elements and their directives.
* **Downstream (output):** the emitted `$.` calls bind to the runtime at module load; for the SSR equivalent of every visitor above, see [compiler_server_transform](compiler_server_transform.md).

---

## 9. Maintenance notes

* **Adding a component variant:** prefer extending `build_component` rather than duplicating it; a new tag becomes a new thin visitor that computes a *name* and delegates (the `Component`/`SvelteComponent`/`SvelteSelf` trio is the template to copy).
* **Runes vs legacy:** the `$:`/`break $` visitors are *no-ops in runes mode* (`context.state.analysis.runes`). Any new syntax that must behave differently in both modes should follow the same early-return pattern.
* **Dev instrumentation must stay dev-gated:** `BinaryExpression`, `AwaitExpression` and `ForOfStatement` only alter output when `dev` is true, and must honour `svelte-ignore` codes (`await_reactivity_loss`, `ownership_invalid_binding`, `binding_property_non_reactive`) via `is_ignored`.
* **Async correctness:** whenever a visitor emits code that evaluates expressions *after* an await, decide whether the value must be snapshotted (`$.save`) — see the `is_last_evaluated_expression` heuristics before changing await wrapping.
