# Compiler Server Transform — JavaScript (compiler_server_transform_javascript)

## Introduction

`compiler_server_transform_javascript` is the JavaScript-handling core of Svelte's server-side rendering (SSR) code generator. It lives in `packages/svelte/src/compiler/phases/3-transform/server/visitors/` and contains the eleven "global" ESTree visitors that rewrite **JavaScript constructs** — declarations, expressions, statements, and class members — into the top-down, payload-based output format that `svelte/internal/server` executes to stream HTML.

While sibling modules handle *template* constructs (elements, control-flow blocks, components — see [compiler_server_transform_elements](compiler_server_transform_elements.md), [compiler_server_transform_control_flow](compiler_server_transform_control_flow.md), [compiler_server_transform_components](compiler_server_transform_components.md)), this module is responsible for everything that is *not* template markup:

| Responsibility | Visitors |
|---|---|
| Variable/props/state declaration rewriting | `VariableDeclaration` |
| Reference resolution (`$$props`, store subscriptions) | `Identifier` |
| Assignment & store mutation lowering | `AssignmentExpression`, `UpdateExpression` |
| Rune calls → server runtime calls | `CallExpression` |
| Removal of client-only statements | `ExpressionStatement` |
| Legacy `$:` reactive statement capture | `LabeledStatement` |
| Top-level `await` policy | `AwaitExpression` |
| Class-based component state (runes on classes) | `ClassBody`, `PropertyDefinition`, `MemberExpression` |

The module is dual-mode: it implements a **runes mode** path (`$state`, `$derived`, `$props`, …) and a **legacy mode** path (`export let`, `$:` reactive statements, `$store` subscriptions), branching on `context.state.analysis.runes`.

---

## 1. Position in the Compiler Pipeline

The Svelte compiler runs three phases (parse → analyze → transform). This module participates exclusively in **phase 3** as part of the server transform, invoked by `server_component()` / `server_module()` in `transform-server.js` (parent module: [compiler_server_transform](compiler_server_transform.md)).

```mermaid
flowchart TD
    subgraph FE["Compiler Front-End"]
        P["1-parse<br/>(compiler_parser)"] --> A["2-analyze<br/>(compiler_analyzer, scope.js)<br/>runes flag · bindings · state_fields · reactive_statements"]
    end
    A --> T["3-transform<br/>(transform-server.js)"]
    subgraph T["Compiler Back-End — server transform"]
        GW["global_visitors<br/>(THIS MODULE)"] --- TV["template_visitors<br/>(elements · control flow · components)"]
    end
    T --> OUT["SSR Program (ESTree) → esrap codegen"]
    OUT --> RT["svelte/internal/server<br/>(server_runtime)"]

    style GW fill:#ffe0b2,stroke:#e65100,stroke-width:2px
```

### 1.1 Visitor wiring (transform-server.js)

`server_component()` walks three separate ASTs — the `<script module>` program, the instance program, and the template AST — with `zimmerframe`. This module's visitors are registered as `global_visitors`, so they apply **everywhere** (module script, instance script, and inside template expressions), while template visitors are layered on top only for the template walk:

```mermaid
flowchart LR
    subgraph server_component
        M["module AST<br/>(script module)"] -->|global_visitors| W1
        I["instance AST<br/>(instance script)"] -->|global_visitors +<br/>ImportDeclaration/ExportNamedDeclaration<br/>hoisting overrides| W2
        Tpl["template AST"] -->|global_visitors +<br/>template_visitors| W3
    end
    W1["walk (zimmerframe)"]
    W2["walk (zimmerframe)"]
    W3["walk (zimmerframe)"]
    W1 & W2 & W3 --> BODY["component_block body<br/>(instance statements + template statements)"]
```

Key effects of the surrounding pipeline this module depends on:

- `state.hoisted` collects the `import * as $ from 'svelte/internal/server'` statement; every `$.xxx` call emitted by this module refers to that namespace.
- `state.legacy_reactive_statements` (this module populates it via `LabeledStatement`) is drained by `server_component()` afterward, which pushes the reactive statements into the instance body in **topological order** computed during analysis.
- If any `store_sub` binding exists, the pipeline prepends `var $$store_subs;` and appends an `if ($$store_subs) $.unsubscribe_stores($$store_subs)` cleanup — the matching `$` references are emitted by `Identifier`, `AssignmentExpression`, and `UpdateExpression` here.

### 1.2 State contract

All visitors receive a zimmerframe `Context` whose `state` is `ServerTransformState`:

```ts
interface TransformState {
    readonly analysis: Analysis;              // includes `runes` flag, `uses_slots`, `classes`
    readonly options: ValidatedModuleCompileOptions;
    readonly scope: Scope;                    // current scope (get, get_bindings, generate)
    readonly scopes: Map<AST.SvelteNode, Scope>;
    readonly state_fields: Map<string, StateField>;
}
interface ServerTransformState extends TransformState {
    readonly legacy_reactive_statements: Map<LabeledStatement, Statement>; // "$:" output sink
}
```

Scope metadata comes from the analysis phase — see [compiler_analyzer_scope](compiler_analyzer_scope.md) (`get_rune`, `Scope`, `Binding.kind` values `state`, `bindable_prop`, `store_sub`, `legacy_reactive`, …).

---

## 2. Architecture & Component Relationships

```mermaid
flowchart TB
    subgraph THIS["compiler_server_transform_javascript"]
        VD["VariableDeclaration"]
        ID["Identifier"]
        AE["AssignmentExpression<br/>+ build_assignment"]
        UE["UpdateExpression"]
        CE["CallExpression"]
        ES["ExpressionStatement"]
        LS["LabeledStatement"]
        AWE["AwaitExpression"]
        CB["ClassBody"]
        PD["PropertyDefinition"]
        ME["MemberExpression"]
    end

    subgraph SHARED["Shared helpers"]
        VAE["3-transform/shared/assignments.js<br/>visit_assignment_expression"]
        IRUNE["transform_inspect_rune<br/>(3-transform/utils.js)"]
        BG["build_getter<br/>(server/visitors/shared/utils.js<br/>→ compiler_server_transform_pipeline)"]
    end

    subgraph SCOPE["Analysis services (compiler_analyzer_scope)"]
        GR["get_rune"]
        SC["Scope / Binding"]
    end

    subgraph INFRA["compiler_core"]
        B["builders (b.*)"]
        ST["state.js (dev, is_ignored)"]
    end

    subgraph RT["server_runtime (svelte/internal/server)"]
        R1["$.store_get / $.store_set / $.store_mutate"]
        R2["$.update_store / $.update_store_pre"]
        R3["$.derived / $.snapshot / $.inspect"]
        R4["$.await_outside_boundary"]
    end

    VD --> B & GR & SC
    ID --> BG & B
    AE --> VAE & GR & B
    CE --> GR & IRUNE & ST & B
    ES --> GR & B
    LS --> B
    AWE --> B
    CB --> B
    PD --> GR & B
    ME --> B
    UE --> B
    ID & UE & AE --> R1 & R2
    CE --> R3
    AWE --> R4
```

All eleven visitors follow the same zimmerframe protocol:

- Return an **AST node** (or a builder-produced node) → replaces the visited node in the output.
- Return `undefined` / call `context.next()` → children are visited with default behavior.
- Return `b.empty` → the construct is erased from SSR output (valid because SSR output is statement-oriented).

---

## 3. Visitor Reference

### 3.1 `VariableDeclaration` — declarations, props, and reactive state

The most substantial visitor. It rebuilds each `VariableDeclaration` declarator-by-declarator.

**Runes mode** (`analysis.runes`):

| Declarator shape | Transformation |
|---|---|
| No rune, or `$effect.tracking` / `$inspect` / `$effect.root` | Visited as-is (these runes have no SSR meaning) |
| `let { ... } = $props.id()` | **Skipped entirely** (component identity is not needed server-side) |
| `let ... = $props()` | Rewritten to bind the pattern to the `$$props` parameter. A `walk` strips `$bindable(...)` defaults, replacing them with the default expression (or `void 0`). Because `$$slots`/`$$events` must never leak into user props, it injects exclusion properties: an `ObjectPattern` with a rest element gets `$$slots` / `$$events` properties spliced before the rest; an `Identifier` id is *replaced* by such an object pattern wrapping the identifier as a rest element. The slots variable is deconflicted to `$$slots_` when `analysis.uses_slots` (the pipeline declares the real `$$slots` via `$.sanitize_slots`). |
| `let x = $derived(expr)` / `$derived.by(fn)` | `$derived.by` → `id = value(...)` (call the function); `$derived` with an `Identifier` id → plain declarator; `$derived` with destructuring → declarator with the visited value (re-evaluated per destructure on the server — reactivity is erased). |
| `let x = $state(...)` / `$state.raw(...)` | Plain declarator bound to the initial value. Destructuring falls through to `create_state_declarators`. |

**Legacy mode:**

- Bindings are inspected via `scope.get_bindings(declarator)`; declarators with neither `state` nor `bindable_prop` bindings pass through unchanged.
- `bindable_prop` (`export let`): the declarator becomes a **props read with fallback** — `x = $$props['x'] ?? default` (built with `build_fallback`, honoring `binding.prop_alias`). For destructured `export let { x: foo } = ...`, the *leaf* identifiers are the prop names (a documented "really really weird" semantic): a `tmp` variable holds the initializer, `extract_paths` yields temporary `$$array` inserts, and each path gets `path.name = $$props[alias ?? name]` with the original init as fallback.
- `state` bindings: `create_state_declarators` — a `tmp` declarator for the whole init, `$$array` temporaries for array-pattern inserts, then one declarator per extracted path (via `extract_paths` from `compiler/utils/ast.js`).

If every declarator was skipped, the whole statement collapses to `b.empty`.

```mermaid
flowchart TD
    S["VariableDeclaration node"] --> R{"analysis.runes?"}
    R -->|yes| Q{"get_rune(init)"}
    Q -->|none / $effect.tracking<br/>$inspect / $effect.root| ASIS["visit as-is"]
    Q -->|"$props.id"| SKIP["skip (no output)"]
    Q -->|"$props"| PROPS["strip $bindable defaults<br/>inject $$slots/$$events exclusions<br/>declarator = $$props"]
    Q -->|"$derived.by"| BY["id = value(...)"]
    Q -->|"$derived"| DER{"id type?"}
    DER -->|Identifier| PLAIN["plain declarator"]
    DER -->|pattern| VIS["visited id = value"]
    Q -->|"$state / $state.raw"| CSD["create_state_declarators<br/>(tmp + $$array inserts + paths)"]
    R -->|no| B{"bindings?"}
    B -->|"no state/bindable_prop"| ASIS
    B -->|bindable_prop| PROP["$$props[alias] ?? default<br/>(leaf names for destructuring)"]
    B -->|state| CSD
    ASIS & SKIP & PROPS & BY & PLAIN & VIS & CSD & PROP --> OUT["rebuilt VariableDeclaration<br/>(b.empty if nothing left)"]
```

### 3.2 `Identifier` — reference resolution

Uses the `is-reference` package to distinguish *reference* identifiers from property keys/shorthand members. Non-references pass through untouched. For references:

- `$$props` → `$$sanitized_props` (the pipeline declares it via `$.sanitize_props` when `uses_props`/`uses_rest_props` is set).
- Any other reference → `build_getter` (defined in [compiler_server_transform_pipeline](compiler_server_transform_pipeline.md)): the identifier is returned unchanged **unless** its binding kind is `store_sub`, in which case it becomes a recursive store read:

```js
// source:  $count
// output:  $.store_get($$store_subs ??= {}, "$count", count)
```

`build_getter` recurses on the un-prefixed store id, so nested member reads like `$user.name` still resolve through the store.

### 3.3 `AssignmentExpression` — assignment & store mutation

Delegates to the shared `visit_assignment_expression(node, context, build_assignment)` (in `3-transform/shared/assignments.js`), which:

- Expands **destructuring assignments** (`[a, b] = …`, `{ x } = …`) into per-path assignments, caching the RHS in `$$value`, hoisting `$$array` temporaries, and wrapping in an async-aware IIFE or a sequence when the assignment appears in expression position. It returns `null` when nothing needed transformation, letting the original assignment survive.

The local `build_assignment(operator, left, right, context)` then decides per-path:

1. **Class state fields (runes mode, `this.x = …` / `this.#x = …`):**
   - *Constructor declaration special case* — if `left` is exactly the LHS of the recorded `AssignmentExpression` that declared the field, the assignment becomes `this.<key> = visit(right)` (choosing the private key when present or when the rune is `$state`/`$state.raw`). This is how `#count = $state(0)` in a constructor is materialized.
   - *`$derived` fields with a private key* — become a **setter call**: `this.#name(visit(build_assignment_value(...)))`, because the derived value is backed by a getter/setter method pair (see 3.9).
2. **Store assignment** (`$store` prefix, only if the un-prefixed name resolves to a binding):
   - Whole-object assignment (`$count = v`) → `$.store_set(count, v)`.
   - Member/partial assignment (`$obj.x = v`, `$arr[i] += v`) → `$.store_mutate($$store_subs ??= {}, "$obj", obj, <reconstructed assignment>)`.
3. Anything else → `null`, i.e. the assignment is emitted as-is (plain variables need no transformation server-side).

`is_store_name` treats `$` followed by `[A-Za-z_]` as a store reference candidate.

### 3.4 `UpdateExpression` — store increments

For `argument++` / `argument--` where the argument's binding kind is `store_sub`:

```js
// source:  $count++      →  $.update_store($$store_subs ??= {}, "$count", count);
// source:  --$count      →  $.update_store_pre($$store_subs ??= {}, "$count", count, -1);
```

Prefix operators route to `$.update_store_pre` and a decrement appends a `-1` literal. All other update expressions fall through via `context.next()`.

### 3.5 `CallExpression` — rune lowering table

| Rune call | SSR output |
|---|---|
| `$host()` | `void 0` (no host component on the server) |
| `$effect.tracking()` | `false` (effects never run) |
| `$effect.root(...)` | A noop cleanup arrow `() => {}` (call itself is erased) |
| `$effect.pending()` | `0` |
| `$state(init)` / `$state.raw(init)` | Visited `init`, or `void 0` — the rune call *disappears*, leaving the raw value |
| `$derived(expr)` | `$.derived(() => expr)` (expr wrapped in a thunk) |
| `$derived.by(fn)` | `$.derived(fn)` |
| `$state.snapshot(x)` | `$.snapshot(x)` — plus a second `true` argument when the `state_snapshot_uncloneable` warning is svelte-ignored (`is_ignored`, from `compiler_core`) |
| `$inspect(...)` / `$inspect(...).with(fn)` | `transform_inspect_rune` (shared `3-transform/utils.js`): emits `$.inspect([...args], fn?)`, but only in dev mode — production builds get `b.empty` |
| anything else | `context.next()` — user code preserved |

### 3.6 `ExpressionStatement` — pruning client-only effects

Statements whose expression is one of `$effect`, `$effect.pre`, `$effect.root`, or `$inspect.trace` are replaced with `b.empty`. Effects and tracing have no server behavior; dropping the statement (rather than just the call) avoids orphaned expression statements in the output.

### 3.7 `LabeledStatement` — legacy `$:` reactive statements

Runs **only** when: not in runes mode, statement is at program top level (`context.path.length <= 1`), and the label is `$`. The body is visited, re-wrapped as `$('...')` (the label is retained because `break $` may appear inside), and registered into `state.legacy_reactive_statements`. The original statement is replaced with `b.empty`.

The parent pipeline later reads that map, matches each entry against `analysis.reactive_statements` (topologically ordered by the analyzer), hoists `let` declarations for assigned `legacy_reactive` bindings, and appends the statements to the instance body — preserving dependency order on the server.

### 3.8 `AwaitExpression` — top-level await policy

```mermaid
flowchart TD
    A["await expr"] --> D{"scope.function_depth === 0<br/>OR inside any function<br/>(arrow/function decl/expression)?"}
    D -->|yes| KEEP["preserved as-is"]
    D -->|no| THROW["$.await_outside_boundary()"]
```

`await` is legal at component top level (SSR component functions are async-capable) and inside `<script module>` or nested functions. An `await` that survives into template rendering *outside* a `{#await}`/boundary context is replaced by a call to the runtime's `$.await_outside_boundary`, which throws a descriptive error at runtime.

### 3.9 Class state: `ClassBody`, `PropertyDefinition`, `MemberExpression` (and `AssignmentExpression`)

Runes mode allows `$state`/`$derived` as class fields (the basis of class components, legacy `createClassComponent` interop, and `AbstractComponent` shapes). The analyzer records each field in `analysis.classes` (surfaced as `state_fields`); this module turns the *declarative* class syntax into backing fields + accessor methods:

- **`ClassBody`** — looks up `state_fields` for the class (legacy mode → untouched). For every `$derived`/`$derived.by` field:
  - Declared as a property definition → emits a backing `prop_def(field.key, visited initializer)` plus a getter (`return this.#key()`) and a setter (`this.#key($$value)`), both generated as methods around the backing key.
  - Assigned in the constructor (field node is an `AssignmentExpression`, see 3.3) → emits the backing `prop_def(null)` and the same getter/setter pair. `#`-private and `$state`/`$state.raw` definitions are visited unchanged. A child state (`{ ...context.state, state_fields }`) is propagated into members.
- **`PropertyDefinition`** — for `key = $state(init)` / `$state.raw(init)` keeps the definition with `value = init` (or `null` when no argument). For `key = $derived(expr)` / `$derived.by(fn)` sets `value = $.derived(() => expr)` / `$.derived(fn)` (or `null`).
- **`MemberExpression`** — reads of a derived field through its private key, `this.#derived`, become calls to the accessor method: `this.#derived()` — because the "value" now lives behind a getter/setter pair. (`AssignmentExpression` handles the write side, 3.3.)

```mermaid
sequenceDiagram
    participant CB as ClassBody
    participant PD as PropertyDefinition
    participant AE as AssignmentExpression
    participant ME as MemberExpression
    participant Out as Generated class

    Note over CB: state_fields from analyzer
    CB->>Out: prop_def #value = $.derived(...)
    CB->>Out: get value() { return this.#value() }
    CB->>Out: set value($$value) { this.#value($$value) }
    PD->>Out: #count = 0  ($state init inlined)
    AE->>Out: this.#count = init (constructor declaration case)
    ME->>Out: this.#derived()  (read via accessor)
    AE->>Out: this.#derived(v)  (write via setter)
```

---

## 4. Data Flow — from source construct to runtime call

```mermaid
flowchart LR
    subgraph SRC[".svelte source"]
        S1["let { a } = $props()"]
        S2["$count = $count + 1"]
        S3["let x = $derived(y * 2)"]
        S4["$: doubled = x * 2"]
    end
    subgraph VIS["This module"]
        F1["VariableDeclaration"]
        F2["AssignmentExpression"]
        F3["CallExpression + VariableDeclaration"]
        F4["LabeledStatement"]
    end
    subgraph GEN["Generated SSR code"]
        G1["let { $$slots, $$events, ...a } = $$props"]
        G2["$.store_set(count, count + 1)"]
        G3["let x = $.derived(() => y * 2)"]
        G4["$$('doubled = x * 2')<br/>(topologically ordered)"]
    end
    subgraph RUN["svelte/internal/server"]
        H1["store_set / store_get /<br/>store_mutate / update_store*"]
        H2["derived / snapshot / inspect"]
        H3["await_outside_boundary"]
    end
    S1 --> F1 --> G1
    S2 --> F2 --> G2 --> H1
    S3 --> F3 --> G3 --> H2
    S4 --> F4 --> G4
```

The `$$store_subs` object written by store helpers is drained at the end of the template by the parent pipeline (`$.unsubscribe_stores`), closing the SSR store lifecycle.

---

## 5. Dependencies

### Upstream (compile-time)

| Dependency | Source module | Used for |
|---|---|---|
| `get_rune`, `Scope`, `Binding` | [compiler_analyzer_scope](compiler_analyzer_scope.md) | Rune detection (`get_rune`), binding kinds (`state`, `bindable_prop`, `store_sub`, `legacy_reactive`), `scope.generate` for `tmp`/`$$array` names |
| `visit_assignment_expression` | parent module [compiler_server_transform](compiler_server_transform.md) (`3-transform/shared/assignments.js`) | Destructuring-assignment expansion shared with the client transform |
| `build_getter` | [compiler_server_transform_pipeline](compiler_server_transform_pipeline.md) (`server/visitors/shared/utils.js`) | Store-subscription reference rewriting |
| `transform_inspect_rune` | parent module (`3-transform/utils.js`) | `$inspect` lowering (dev-only, shared with client) |
| `builders` (`b.*`), `is_ignored`, `dev` | [compiler_core](compiler_core.md) | ESTree node construction; ignore-comments & dev flags |
| `build_fallback`, `extract_paths` | `compiler/utils/ast.js` | Prop/state destructuring elaboration |
| `StateField` / `state_fields`, `Analysis.runes`, `analysis.classes` | [compiler_types](compiler_types.md) + analyzer | Class-field metadata driving `ClassBody`/`PropertyDefinition` |

### Downstream (runtime contract)

Generated code calls into the `svelte/internal/server` namespace — see [server_runtime](server_runtime.md): `$.store_get`, `$.store_set`, `$.store_mutate`, `$.update_store`, `$.update_store_pre`, `$.derived`, `$.snapshot`, `$.inspect`, `$.await_outside_boundary`. Diagnostics referenced by this module (`state_snapshot_uncloneable` ignore handling; `await_outside_boundary` runtime error) relate to [compiler_diagnostics](compiler_diagnostics.md).

### Counterpart

The client twin of this module is [compiler_client_transform_state_and_reactivity](compiler_client_transform_state_and_reactivity.md). Where the server transform *erases* reactivity (values, plain assignments), the client transform *preserves and instruments* it (signals, effects). Keeping the two visitor sets behaviorally symmetric is the main invariant to maintain when changing rune semantics.

---

## 6. Mode Cheat-Sheet (runes vs. legacy)

| Construct | Runes mode output | Legacy mode output |
|---|---|---|
| `let x = $state(0)` | `let x = 0` | — |
| `let { y } = $props()` | pattern bound to `$$props` (slots/events excluded) | — |
| `export let x = 1` | — | `let x = $$props['x'] ?? 1` |
| `let d = $derived(e)` | `let d = $.derived(() => e)` | — |
| `$: stmt` | — (runes mode leaves label untouched → falls through) | captured into `legacy_reactive_statements`, statement erased |
| `$count = v` | (store) `$.store_set(count, v)` | same (store logic is mode-independent) |
| `$effect(...)` / `$effect.pre` statements | erased | erased |
| `$inspect(...)` | `$.inspect(...)` in dev, empty in prod | same |
| top-level `await` in component body | preserved | preserved |
| `await` in template outside boundary | `$.await_outside_boundary()` | `$.await_outside_boundary()` |
| class `#f = $derived(e)` | backing field + get/set accessors | untouched (no runes) |

---

## 7. Maintenance Notes & Gotchas

- **`$props` slot/event hygiene**: any change to how `$$slots`/`$$events` are excluded in `VariableDeclaration` must stay in sync with the pipeline's `$.sanitize_slots` / `$$slots_` deconfliction (`analysis.uses_slots`), otherwise rest props leak internal keys.
- **Constructor-declaration detection** in `build_assignment` matches by object identity (`left === field.node.left`); refactoring field registration in the analyzer will silently break `#field = $state(...)` in constructors.
- **`LabeledStatement` TODO**: module-context `$:` statements are not yet rejected at transform time; the transform relies on the analyzer having already errored.
- **`AwaitExpression` relies on `scope.function_depth`** from the analyzer's scope tree; walking order (`set_scope` as the `_` visitor registered in `global_visitors`) is what keeps `context.state.scope` correct — do not bypass it.
- **`b.empty` semantics**: erased nodes (skipped `$props.id`, effect statements, captured `$:`) rely on SSR output being a statement list; they are invalid inside expression position.
- **Symmetry with client transform**: rune lowering decisions made here (e.g. `$derived` → thunk vs. fn) must mirror [compiler_client_transform_state_and_reactivity](compiler_client_transform_state_and_reactivity.md); a divergence shows up as SSR/client mismatch bugs.
