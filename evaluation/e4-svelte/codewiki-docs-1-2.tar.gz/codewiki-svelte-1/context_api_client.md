# context_api_client

> **Source:** `packages/svelte/src/internal/client/context.js`

## Introduction

The `context_api_client` module implements Svelte's **client-side context system** — the mechanism that lets a component associate arbitrary values (`setContext`) with a key that any descendant component can later retrieve (`getContext` / `hasContext` / `getAllContexts`). It also owns the **component context stack** (`push` / `pop`) that compiled component code uses to bracket each component instance's initialisation, and the **dev-mode instrumentation** (`add_svelte_meta`, dev stack, current component function) that gives Svelte's errors precise file/line/column attribution.

The public API is intentionally identical to the server-side implementation documented in [context_api_server](context_api_server.md); only the runtime mechanics differ (reactivity integration, async-mode validation, deferred legacy effects). Because this module sits at the intersection of the reactive runtime, the compiler's code generation, and the public API surface, understanding it is a prerequisite for touching component lifecycle, dev tooling, or context propagation anywhere in the framework.

---

## 1. Module Overview

| Concern | Export | Notes |
|---|---|---|
| Context map API | `getContext`, `setContext`, `hasContext`, `getAllContexts` | The user-facing context API (re-exported by `svelte` for client builds) |
| Component context stack | `component_context`, `push`, `pop`, `is_runes` | Maintained by compiled output during component init |
| Mutable module state setters | `set_component_context`, `set_dev_stack`, `set_dev_current_component_function` | Used to swap/reset context (e.g. HMR, hydration boundaries) |
| Dev instrumentation | `add_svelte_meta`, `dev_stack`, `dev_current_component_function` | DEV-only bookkeeping for error attribution |

### Key design principles

1. **Lazy, copy-on-write inheritance.** A component's context `Map` is created only on the first context API call and is *seeded with a copy* of the nearest ancestor's map (`new Map(get_parent_context(...))`). Reads never walk the tree at lookup time — inheritance is paid once, eagerly, at first use.
2. **Init-only contract.** Context functions must run during component initialisation. Violations throw `lifecycle_outside_component` (no active component) or, in async mode, `set_context_after_init` (called too late, e.g. after `await` or inside an effect).
3. **Mode awareness.** `push`/`pop` and `is_runes` carry the legacy-vs-runes distinction, and `pop` is the exact point where legacy (`$:`-style) pre-effects captured in `context.e` are flushed into the reactive runtime.
4. **Tree-shakeable dev code.** All dev-only branches are guarded by the `DEV` constant from `esm-env`, so production bundles eliminate the instrumentation entirely.

---

## 2. Architecture

### 2.1 Position in the system

```mermaid
flowchart TB
    subgraph PUB["Public API Surface (public_api)"]
        IDX["src/index-client.js<br/>getContext · setContext · hasContext · getAllContexts"]
    end

    subgraph GEN["Compiler Back-End (compiler_client_transform)"]
        OUT["Compiled component code<br/>emits push()/pop() around init"]
    end

    subgraph RENDER["Component Rendering Backend (client_dom_renderer_lifecycle_api)"]
        MOUNT["mount / hydrate / unmount"]
    end

    subgraph MODULE["context_api_client (this module)"]
        STACK["Component context stack<br/>push / pop / component_context / is_runes"]
        MAP["Context map API<br/>getContext / setContext / hasContext / getAllContexts"]
        DEV["Dev instrumentation<br/>add_svelte_meta / dev_stack"]
    end

    subgraph RT["Reactive Runtime (client_runtime_core)"]
        SIG["active_effect / active_reaction<br/>BRANCH_EFFECT / EFFECT_RAN flags"]
        EFF["reactivity/effects.js<br/>create_user_effect"]
    end

    subgraph FLAGS["Shared Runtime Flags (shared_runtime_flags)"]
        F["async_mode_flag / legacy_mode_flag"]
    end

    subgraph DIAG["Client Diagnostics (client_runtime_core_diagnostics)"]
        ERR["errors.js<br/>lifecycle_outside_component / set_context_after_init"]
    end

    IDX --> MAP
    OUT --> STACK
    OUT --> MAP
    MOUNT --> STACK
    MAP --> STACK
    STACK --> F
    MAP --> F
    MAP --> ERR
    STACK --> ERR
    MAP --> SIG
    DEV --> STACK
    STACK --> EFF
    DEV --> RT
```

### 2.2 Relationship to the server twin

`context_api_client` and [context_api_server](context_api_server.md) form the `context_api` pair inside *Cross-Runtime Platform Services*. The compiler selects the correct module per render target, so component code is target-agnostic. The behavioural differences:

| Aspect | `context_api_client` | `context_api_server` |
|---|---|---|
| Context storage | Lazy `Map` per component, seeded from nearest ancestor copy | Same lazy-`Map` strategy |
| Init validation | Throws on missing context *and* (async mode) on late `setContext` via effect-flag inspection | Only throws on missing context |
| `pop()` semantics | Flushes deferred legacy effects through `create_user_effect`, restores dev component function | Appends collected `ondestroy` callbacks, restores parent |
| Legacy/rune mode | `is_runes()` drives reactivity semantics via `legacy_mode_flag` | Not applicable (no reactivity) |
| Async payloads | Interacts with effects/reactions of the signals engine | N/A |

---

## 3. Data Structures

### 3.1 ComponentContext

The module-level `component_context` variable is the top of a **linked list** of per-component records created by `push`:

```mermaid
classDiagram
    direction LR
    class ComponentContext {
        +ComponentContext p
        +Map c
        +Array e
        +Record s
        +any x
        +LegacyState l
        +Function function
    }
    class LegacyState {
        +any s
        +any u
        +Array dollar
    }
    class DevStackEntry {
        +string type
        +string file
        +number line
        +number column
        +DevStackEntry parent
    }
    ComponentContext "child" --> "0..1 parent" ComponentContext : p
    ComponentContext "1" *-- "0..1" LegacyState : l
    DevStackEntry "entry" --> "0..1 parent" DevStackEntry : parent
```

| Field | Purpose |
|---|---|
| `p` | Parent context — the stack link popped by `pop` |
| `c` | Lazily created context `Map` (`null` until first context API call) |
| `e` | Legacy-mode pre-effect callbacks queued during init, flushed by `pop` |
| `s` | Component props snapshot |
| `x` | Component exports, attached when `pop(component)` receives a component |
| `l` | Legacy-mode state (`null` ⇒ component compiled in runes mode — this is what `is_runes()` inspects) |
| `function` | *(DEV only)* The component function, for error attribution |

### 3.2 DevStackEntry

`add_svelte_meta` builds a linked chain of `DevStackEntry` records describing *where* each block/component sits (file via the `FILENAME` constant, line, column, type), enabling precise code frames in dev errors.

---

## 4. Core Components

### 4.1 Component context stack

- **`push(props, runes = false, fn)`** — Pushes a new `ComponentContext` onto the stack. If running in legacy mode (`legacy_mode_flag && !runes`), allocates the `l` legacy-state object; otherwise leaves `l = null`. In dev mode also records `function` and updates `dev_current_component_function`.
- **`pop(component)`** — Pops the top context. First flushes any queued legacy effects in `context.e` through `create_user_effect` (from [client_runtime_core](client_runtime_core.md)), optionally stores the component's exports into `context.x`, then restores `component_context = context.p` and the dev component function. Returns `component ?? {}`.
- **`is_runes()`** — Returns `true` unless legacy mode is active *and* the current context carries legacy state (`component_context.l !== null`). The reactive runtime and compiled output consult this to pick runes vs. legacy semantics.
- **`set_component_context`, `set_dev_stack`, `set_dev_current_component_function`** — Mutable-state setters used to swap context outside the normal push/pop pairing (e.g. hydration boundaries, HMR from [client_dev_mode](client_dev_mode.md)).

### 4.2 Context map API

All four functions funnel through the private helper `get_or_init_context_map(name)`:

```mermaid
flowchart TD
    A["context API call e.g. getContext(key)"] --> B{"component_context == null?"}
    B -- "yes" --> E1["throw lifecycle_outside_component<br/>'can only be used during component initialisation'"]
    B -- "no" --> C{"context.c already created?"}
    C -- "yes" --> R["return context.c"]
    C -- "no" --> D["walk p-chain via get_parent_context()"]
    D --> F["context.c = new Map(parentMap ?? undefined)<br/>copy-on-write inheritance"]
    F --> R
```

- **`setContext(key, context)`** — Stores `context` in the current component's map and returns it (enables `setContext(key, obj)` chaining). In **async mode** it additionally validates execution timing (see §5.2).
- **`getContext(key)`** — Reads `key` from the (lazily inherited) map; `undefined` when absent.
- **`hasContext(key)`** — Boolean existence check, no map mutation semantics beyond lazy creation.
- **`getAllContexts<T>()`** — Returns the whole `Map`, including entries inherited from ancestors. Intended for programmatically re-provisioning context (e.g. when manually mounting a component).

### 4.3 Dev instrumentation

- **`add_svelte_meta(callback, type, component, line, column, additional)`** — Executes `callback` with a new `DevStackEntry` pushed onto the `dev_stack` chain; restores the previous entry in a `finally` block. Used by compiled dev-mode code so runtime errors can report exact template locations.
- **`dev_current_component_function`** — Tracks which component function is currently initialising, mirroring `component_context` in dev builds; consumed by dev tooling and error code frames (see [compiler_diagnostics](compiler_diagnostics.md) `get_code_frame`).

---

## 5. Process Flows

### 5.1 Context provisioning and resolution (nested components)

```mermaid
sequenceDiagram
    autonumber
    participant P as Parent component init
    participant M as context_api_client
    participant C as Child component init

    P->>M: push(props, runes, fn)
    Note over M: component_context = new node (c = null)
    P->>M: setContext(key, value)
    M->>M: get_or_init_context_map()
    Note over M: creates Map seeded from nearest ancestor (copy)
    M-->>P: value

    C->>M: push(props, runes, fn)
    Note over M: child node linked via p
    C->>M: getContext(key)
    M->>M: get_or_init_context_map()
    Note over M: lazily copies nearest ancestor's map into child
    M-->>C: value (resolved from copied map)
    C->>M: hasContext(key2)
    M-->>C: boolean

    C->>M: pop(childComponent)
    Note over M: flush legacy effects (context.e) via create_user_effect,<br/>restore parent + dev component function
    P->>M: pop(parentComponent)
```

Because inheritance happens by **copying** at first use, a child that calls `getContext` before the parent finishes cannot exist (contexts are set during the parent's own init, which strictly precedes the child's), and later mutations to the parent's map are deliberately **not** visible to children that already materialised their own map.

### 5.2 `setContext` async-mode timing validation

When `async_mode_flag` is enabled, Svelte permits components to `await`; `setContext` must therefore prove it is still running synchronously inside initialisation:

```mermaid
flowchart TD
    A["setContext(key, context)"] --> B{"component_context == null?"}
    B -- yes --> X1["throw lifecycle_outside_component"]
    B -- no --> C{"async_mode_flag?"}
    C -- no --> OK["context_map.set(key, context)<br/>return context"]
    C -- yes --> D["read active_effect.f flags<br/>from client_runtime_core"]
    D --> E{"active_reaction == null<br/>AND flags & BRANCH_EFFECT<br/>AND NOT flags & EFFECT_RAN"}
    E -- yes --> OK
    E -- no --> X2["throw set_context_after_init<br/>'not in a subsequent effect or after await'"]
```

In words: the active effect must be a **branch effect that has not yet run**, and there must be **no active reaction** — i.e. we are inside the component's own template-branch setup, before any resumption point. Anything else means initialisation has already been suspended or completed.

### 5.3 Stack lifecycle across a render tree

```mermaid
stateDiagram-v2
    direction TB
    [*] --> RootCtx: mount()/hydrate() pushes root context
    RootCtx --> ParentCtx: push(props)
    ParentCtx --> ChildCtx: push(props)
    ChildCtx --> GrandchildCtx: push(props)
    GrandchildCtx --> ChildCtx: pop()
    ChildCtx --> ParentCtx: pop()
    ParentCtx --> RootCtx: pop()
    RootCtx --> [*]: unmount
```

Every arrow into a deeper state may interleave context API calls; every `pop` is the commit point that flushes that component's deferred legacy effects.

---

## 6. Error Handling

All failures are routed to the generated error catalogues of [client_runtime_core_diagnostics](client_runtime_core_diagnostics.md) (which, in turn, are produced by the `process-messages` build tooling — see [svelte_build_tooling](svelte_build_tooling.md)):

| Trigger | Error | Condition |
|---|---|---|
| Any context API / `push`-dependent call with `component_context === null` | `lifecycle_outside_component` | Called outside component initialisation |
| `setContext` in async mode after init suspension | `set_context_after_init` | Active effect is not a yet-unrun branch effect, or a reaction is active |

Error factories emit the full message with a docs URL in `DEV` builds and only the short URL in production, keeping prod bundles small.

---

## 7. Dependencies

### 7.1 Upstream (what this module consumes)

```mermaid
flowchart LR
    subgraph this["context_api_client"]
        core["push / pop / is_runes"]
        api["setContext / getContext /<br/>hasContext / getAllContexts"]
        devm["add_svelte_meta"]
    end

    runtime["client_runtime_core<br/>active_effect · active_reaction"]
    effects["client_runtime_core<br/>create_user_effect"]
    flags["shared_runtime_flags<br/>async_mode_flag · legacy_mode_flag"]
    errors["client_runtime_core_diagnostics<br/>lifecycle_outside_component · set_context_after_init"]
    consts["Compiler types / constants<br/>FILENAME · BRANCH_EFFECT · EFFECT_RAN"]
    env["esm-env<br/>DEV"]

    api --> runtime
    core --> flags
    api --> errors
    core --> errors
    core --> effects
    devm --> consts
    this --> env
```

| Dependency | Consumed by | Purpose |
|---|---|---|
| [client_runtime_core](client_runtime_core.md) | `setContext`, `pop` | `active_effect` / `active_reaction` for timing checks; `create_user_effect` to flush legacy effects |
| [shared_runtime](shared_runtime.md) (flags) | `push`, `setContext`, `is_runes` | `async_mode_flag`, `legacy_mode_flag` mode switches |
| [client_runtime_core_diagnostics](client_runtime_core_diagnostics.md) | `get_or_init_context_map`, `setContext` | Generated `Svelte error` factories |
| Compiler constants | `add_svelte_meta`, `push` | `FILENAME` metadata key; effect flag bits |

### 7.2 Downstream (what consumes this module)

| Consumer | Usage |
|---|---|
| [public_api](public_api.md) (`src/index-client.js`) | Re-exports `getContext`, `setContext`, `hasContext`, `getAllContexts` as the `svelte` package API |
| [compiler_client_transform](compiler_client_transform.md) | Emits `push(...)` / `pop(...)` around every component's initialisation in client builds (mirrored by the server transform against [context_api_server](context_api_server.md)) |
| [client_dom_renderer_lifecycle_api](client_dom_renderer_lifecycle_api.md) | `mount` / `hydrate` / `unmount` drive the outermost `push`/`pop` and reset module state via the setters |
| [client_dev_mode](client_dev_mode.md) | HMR and dev tooling read/replace `component_context`, `dev_stack`, and `dev_current_component_function` |

---

## 8. Implementation Notes & Gotchas

- **`get_or_init_context_map` copies, it does not chain.** `new Map(get_parent_context(...) || undefined)` snapshots the ancestor's entries once. Performance is O(ancestor entries) on first use per component; lookups afterwards are O(1) with no tree walk.
- **`pop` returns `component ?? {}`** so compiled code can do `Foo = pop(Foo)` for component exports while snippet/other callers can ignore the return value.
- **Effects queued in `context.e` are legacy-only.** Runes-mode components never populate `e`; the flush loop is a no-op for them.
- **`is_runes()` reads the *current* context**, so it is only meaningful inside a `push`/`pop` bracket — outside any component it reports `!legacy_mode_flag`.
- **State setters exist because module state is mutable singleton state.** Hydration, HMR re-render, and effect-based rerenders must be able to restore the exact prior context, which plain `push`/`pop` cannot express.
- **Do not duplicate server logic here.** Any new context behaviour that is render-target-agnostic belongs in the shared pair of files only if it can be mirrored in [context_api_server](context_api_server.md); otherwise guard it with client-only dependencies (`active_effect`, effects, etc.).
