# Public API Server Entry (`packages/svelte/src/index-server.js`)

## 1. Introduction

`index-server.js` is the **server-side variant of the `svelte` public entry point**. Bundlers resolve it whenever `import { ... } from 'svelte'` is evaluated in a non-browser environment (Node.js / SSR), via the package's conditional `exports` map — the browser condition resolves to the sibling module documented in [public_api_client_entry](public_api_client_entry.md).

Its purpose is threefold:

1. **Provide the subset of the Svelte API that is meaningful during server-side rendering** — `onDestroy`, the context API (`setContext`, `getContext`, `hasContext`, `getAllContexts`), `createRawSnippet`, and `getAbortSignal`.
2. **Preserve API surface parity with the client entry** so that component source code never needs environment branching. APIs that are meaningless on the server are exported as safe **no-op stubs** (`onMount`, `beforeUpdate`, `afterUpdate`, `flushSync`, `createEventDispatcher`, `tick`, `settled`).
3. **Fail loudly and helpfully for client-only APIs** — `mount`, `hydrate`, and `unmount` throw a `Svelte error` of kind `lifecycle_function_unavailable`, since rendering to a live DOM is impossible during SSR.

The module is intentionally tiny, dependency-light, and side-effect-free, which keeps it fully tree-shakeable (verified by the repo tooling described in [svelte_build_tooling](svelte_build_tooling.md)).

---

## 2. Architecture Overview

The entry module is a thin **facade** over four internal packages. It contains almost no logic of its own: every export either delegates to the SSR runtime, aliases a shared utility, or raises a diagnostic error.

```mermaid
flowchart TB
    subgraph ENTRY["public_api_server_entry — index-server.js"]
        direction TB
        F1["onDestroy(fn)"]
        F2["Re-exports: setContext, getContext,<br/>hasContext, getAllContexts"]
        F3["Re-exports: createRawSnippet, getAbortSignal"]
        S1["No-op aliases: onMount, beforeUpdate,<br/>afterUpdate, flushSync"]
        S2["createEventDispatcher() → noop"]
        S3["tick() / settled() → async no-ops"]
        S4["untrack → run (executes fn)"]
        E1["mount() / hydrate() / unmount()<br/>→ lifecycle_function_unavailable"]
    end

    subgraph SSR["Server runtime — internal/server"]
        CTX["context.js<br/>current_component · push/pop<br/>context map · on_destroy queue"]
        ERR["errors.js<br/>lifecycle_function_unavailable<br/>lifecycle_outside_component"]
        ABORT["abort-signal.js<br/>getAbortSignal"]
        SNIP["blocks/snippet.js<br/>createRawSnippet"]
    end

    subgraph SHARED["Cross-runtime — internal/shared"]
        UTILS["utils.js<br/>noop · run"]
    end

    F1 --> CTX
    F2 --> CTX
    F3 --> SNIP
    F3 --> ABORT
    S1 --> UTILS
    S2 --> UTILS
    S4 --> UTILS
    E1 --> ERR
    CTX -. "guards calls<br/>outside components" .-> ERR
```

### Dependency summary

| Export(s) | Source | Dependency module documentation |
|---|---|---|
| `onDestroy` | defined here, writes to `current_component.d` | [context_api_server](context_api_server.md) |
| `setContext`, `getContext`, `hasContext`, `getAllContexts` | re-exported from `internal/server/context.js` | [context_api_server](context_api_server.md) |
| `createRawSnippet` | re-exported from `internal/server/blocks/snippet.js` | [server_runtime_blocks](server_runtime_blocks.md) |
| `getAbortSignal` | re-exported from `internal/server/abort-signal.js` | [server_runtime_payload_model](server_runtime_payload_model.md) |
| `onMount`, `beforeUpdate`, `afterUpdate`, `flushSync`, `createEventDispatcher` | alias of `noop` from `internal/shared/utils.js` | [shared_runtime_utilities](shared_runtime_utilities.md) |
| `untrack` | alias of `run` from `internal/shared/utils.js` | [shared_runtime_utilities](shared_runtime_utilities.md) |
| `mount`, `hydrate`, `unmount` | defined here; throw from `internal/server/errors.js` | [context_api_server](context_api_server.md) |

---

## 3. Public API Reference

| Export | Signature | Server behavior |
|---|---|---|
| `onDestroy` | `(fn: () => void) => void` | ✅ **Functional** — registers `fn` as cleanup for the component currently being rendered. |
| `setContext` | `<T>(key, context: T) => T` | ✅ **Functional** — stores a value in the current component's context map (re-export). |
| `getContext` | `<T>(key) => T` | ✅ **Functional** — reads from the component's context map, inheriting from parents (re-export). |
| `hasContext` | `(key) => boolean` | ✅ **Functional** (re-export). |
| `getAllContexts` | `() => Map<any, any>` | ✅ **Functional** (re-export). |
| `createRawSnippet` | `(fn) => Snippet` | ✅ **Functional** — wraps a render function whose output is pushed verbatim into the SSR payload (re-export). |
| `getAbortSignal` | `() => AbortSignal` | ✅ **Functional** — lazily creates an `AbortController` and returns its signal; allows SSR work to react to render aborts (re-export). |
| `untrack` | `<T>(fn: () => T) => T` | ✅ **Functional** — aliased to `run`, i.e. it *invokes* `fn` and returns its result (there is no reactive graph to untrack from). |
| `onMount` | `(fn) => void` | ⬜ **No-op** — `noop` alias; client-only effect never runs. |
| `beforeUpdate` / `afterUpdate` | `(fn) => void` | ⬜ **No-op** — `noop` aliases. |
| `flushSync` | `(fn?) => void` | ⬜ **No-op** — there is no scheduler/queue to flush synchronously. |
| `createEventDispatcher` | `() => (type, detail?) => void` | ⬜ **No-op** — returns `noop`; dispatching is silently dropped (component events never reach a server). |
| `tick` | `async () => Promise<void>` | ⬜ **Async no-op** — returns a resolved promise so `await tick()` remains valid. |
| `settled` | `async () => Promise<void>` | ⬜ **Async no-op** — returns a resolved promise. |
| `mount` | `(component, options) => never` | ❌ **Throws** `lifecycle_function_unavailable('mount')`. |
| `hydrate` | `(component, options) => never` | ❌ **Throws** `lifecycle_function_unavailable('hydrate')`. |
| `unmount` | `(component, options?) => never` | ❌ **Throws** `lifecycle_function_unavailable('unmount')`. |

> Type-level contracts for these exports (`Component`, `Snippet`, `EventDispatcher`, …) are defined in [public_api_type_contracts](public_api_type_contracts.md).

### Error behavior of client-only functions

`mount`, `hydrate`, and `unmount` delegate to `internal/server/errors.js`:

```javascript
function lifecycle_function_unavailable(name) {
    const error = new Error(
        `lifecycle_function_unavailable\n\`${name}(...)\` is not available on the server\nhttps://svelte.dev/e/lifecycle_function_unavailable`
    );
    error.name = 'Svelte error';
    throw error;
}
```

Key properties of this diagnostic:

- `error.name === 'Svelte error'` makes it trivially recognizable in logs and error overlays.
- The first line of the message is the **machine-readable error code**, matching the codegen'd message catalogs in `scripts/process-messages` (see [svelte_build_tooling](svelte_build_tooling.md)).
- The last line links to stable documentation for the code.

---

## 4. API Resolution Strategy

Every export falls into exactly one of three buckets. This decision flow is the module's core design contract:

```mermaid
flowchart TD
    A["Symbol imported from 'svelte'<br/>(server condition)"] --> B{"Is the API meaningful<br/>during SSR?"}
    B -- "Yes — operates on render<br/>state, context, or payload" --> C["Delegate to server runtime"]
    B -- "No, but harmless in shared<br/>component code" --> D["Export a stub"]
    B -- "No — requires a live DOM /<br/>scheduler / hydration" --> E["Throw Svelte error"]

    C --> C1["onDestroy<br/>setContext · getContext · hasContext · getAllContexts<br/>createRawSnippet · getAbortSignal · untrack"]
    D --> D1["noop: onMount · beforeUpdate · afterUpdate · flushSync<br/>noop-returning: createEventDispatcher<br/>async noop: tick · settled"]
    E --> E1["mount · hydrate · unmount<br/>→ lifecycle_function_unavailable"]
```

Design rationale:

- **No-ops instead of missing exports** guarantee that a single component `<script>` compiles and runs in both environments — the compiled output of a shared component references the same symbol names regardless of the target.
- **Hard errors instead of no-ops for `mount`/`hydrate`/`unmount`** prevents silent bugs: these functions produce a mounted component instance, which cannot exist on the server; an app accidentally importing them into SSR code fails fast with an actionable message.
- **`untrack` executes** (`run`) rather than no-ops: template expressions wrapped by the compiler in `untrack(...)` must still be *evaluated* to produce SSR output.

---

## 5. Component Interaction: `onDestroy` and the Server Component Stack

`onDestroy` is the only export whose logic lives in this file. It cooperates with the push/pop component stack maintained by [context_api_server](context_api_server.md) and consumed by [server_runtime_rendering_core](server_runtime_rendering_core.md):

1. `push(fn)` (called by the SSR renderer for every component instance) sets `current_component = { p: parent, c: null, d: null }` (plus `.function` in dev mode for better error attribution).
2. `onDestroy(fn)` lazily creates the `d` (destroy) array on the current frame and appends `fn`.
3. `pop()` moves the frame's callbacks onto the module-level `on_destroy` queue and restores the parent frame.
4. After the render completes, the renderer flushes the `on_destroy` queue, running cleanups in registration order.

```mermaid
sequenceDiagram
    autonumber
    participant R as SSR renderer<br/>(server_runtime_rendering_core)
    participant C as context.js<br/>(component stack)
    participant E as index-server.js<br/>(onDestroy)
    participant Q as on_destroy queue

    R->>C: push(component_fn)
    C->>C: current_component = { p, c: null, d: null }
    Note over C: component body executes<br/>(runs onDestroy calls, setContext, snippets)
    R->>E: onDestroy(fn)
    E->>C: (current_component.d ??= []).push(fn)
    R->>C: pop()
    C->>Q: on_destroy.push(...frame.d)
    C->>C: current_component = frame.p
    R->>Q: flush after render finishes
    Q-->>Q: fn() for each registered cleanup
```

Implementation detail worth noting: unlike the context API (which guards via `get_or_init_context_map` → `lifecycle_outside_component`), the server `onDestroy` reads `current_component` directly and casts it. Calling it outside component initialisation therefore fails with a raw `TypeError` rather than a formatted `Svelte error`; the structured guard lives one layer down in the context module.

---

## 6. Data Flow: From Import to Server Render

```mermaid
flowchart LR
    SRC["Component source<br/>import { onMount, setContext } from 'svelte'"] --> BUNDLER["Bundler / Node resolver"]
    BUNDLER -->|"browser condition"| CLIENT["index-client.js<br/>(public_api_client_entry)"]
    BUNDLER -->|"server / node condition"| SERVER["index-server.js<br/>(this module)"]
    SERVER --> RENDER["render() in internal/server/index.js<br/>(server_runtime_rendering_core)"]
    RENDER --> PAYLOAD["Payload<br/>(server_runtime_payload_model)"]
    PAYLOAD --> OUT["HTML string + head +<br/>cleanup callbacks flushed"]
```

- The **client** branch is covered in [public_api_client_entry](public_api_client_entry.md); the two entries expose the *same symbol names* (modulo `mount`/`hydrate`/`unmount`, which are functional only on the client).
- The generated code that calls these APIs during SSR is produced by the compiler's server transform (see `Compiler_Back-End_(Client___Server_Code_Generation)` module documentation) — e.g. `$: ` statement handling, `onDestroy` placement, and snippet rendering all target exactly the symbols listed in §3.
- Escaping/serialization of the final HTML happens downstream in the server runtime; this entry never touches strings itself (except via `createRawSnippet`, which pushes raw, author-owned markup into the payload).

---

## 7. Position Within the Public API Surface

This module is one leaf of the `Public_API_Surface___Compatibility_Layer` tree:

```mermaid
flowchart TB
    ROOT["svelte package public surface"] --> MAIN["'svelte' main entry<br/>(this module ↔ index-client.js)"]
    ROOT --> TYPES["Type contracts<br/>(public_api_type_contracts)"]
    ROOT --> HTML["JSX/HTML typings<br/>(public_api_html_typing)"]
    ROOT --> ACTIONS["Actions & attachments<br/>(actions_and_attachments)"]
    ROOT --> LEGACY["Legacy class-component layer<br/>(legacy_compat)"]

    MAIN -. "types for" .-> TYPES
    MAIN -. "element attribute names" .-> HTML
    LEGACY -. "server _render builds on<br/>the same SSR runtime" .-> MAIN
```

Related entry points that are **not** part of this module (each documented separately): `svelte/store` ([stores](stores.md)), `svelte/reactivity` ([reactive_builtin_classes](reactive_builtin_classes.md)), `svelte/motion` ([motion](motion.md)), `svelte/transition` / `svelte/animate` ([transitions_and_animations](transitions_and_animations.md)), and `svelte/compiler` ([compiler_core_entry](compiler_core_entry.md)). Those subpath entries are environment-agnostic or re-export per-condition themselves and do not route through `index-server.js`.

---

## 8. Usage Examples

### 8.1 Component code that is SSR-safe

```svelte
<script>
    import { onMount, onDestroy, setContext, getContext, tick } from 'svelte';

    let data = $state(null);

    // Runs ONLY in the browser; a no-op on the server.
    onMount(() => {
        console.log('client mounted');
    });

    // Runs during SSR *and* after client mount:
    // appends a cleanup callback that fires after render (server)
    // or on component destroy (client).
    onDestroy(() => {
        console.log('cleaning up');
    });

    // Provide values down the tree — works identically in both entries.
    setContext('theme', { color: 'dark' });
    const parent = getContext('theme');

    // await tick() is valid on the server (resolves immediately).
    async function load() {
        data = await fetch('/api').then((r) => r.json());
        await tick();
    }
</script>
```

### 8.2 Server-side application code

```javascript
// SSR driver (framework integrations, custom servers)
import { render } from 'svelte/server'; // built on this module's runtime
import App from './App.svelte';

const { html, head } = render(App, { props: { name: 'world' } });
```

### 8.3 Raw snippets and abortable work

```javascript
import { createRawSnippet, getAbortSignal } from 'svelte';

// Raw markup injected verbatim into the SSR payload
const badge = createRawSnippet((count) => {
    return { render: () => `<b data-count>${count()}</b>` };
});

// Signal fired if the surrounding render is aborted —
// pass it to fetch() calls made during SSR.
fetch('/api/slow', { signal: getAbortSignal() });
```

### 8.4 What fails, and how

```javascript
import { mount } from 'svelte'; // resolved to index-server.js on the server
mount(App, { target: document.body });
// Error [Svelte error]: lifecycle_function_unavailable
// `mount(...)` is not available on the server
// https://svelte.dev/e/lifecycle_function_unavailable
```

---

## 9. Edge Cases, Invariants & Maintenance Notes

- **Symbol parity is a contract.** Any name added to [public_api_client_entry](public_api_client_entry.md) that appears in shared component output must get a counterpart here — stub, delegation, or throw. Breaking this contract surfaces as a runtime `undefined is not a function` only in one environment.
- **`createEventDispatcher` returning `noop`** is safe because the returned dispatcher is *callable*; it simply discards events. This keeps legacy event-style components SSR-compatible; the modern replacement (callback props) is entirely compile-time.
- **`tick` / `settled` are declared `async`**, so `await tick()` always yields a `Promise`. Do not "optimize" them to plain no-op functions without checking compiled output that awaits them.
- **No side effects at module scope** — importing this file does no work. This is an explicit invariant checked by `scripts/check-treeshakeability.js` (see [svelte_build_tooling](svelte_build_tooling.md)); it ensures server bundles only pay for what they call.
- **Dev-mode attribution.** `push()` stores `current_component.function` in dev mode so that errors raised inside context/lifecycle calls can name the offending component; this entry benefits from that indirectly and adds no dev/prod branching of its own.
- **The legacy compatibility layer** ([legacy_compat](legacy_compat.md)) reuses this same SSR runtime through `legacy-server.js`; changes to the stub/delegation semantics here affect `$:` and class-component SSR behavior there as well.
- **Stub drift risk.** `noop as onMount` etc. mean a genuinely client-only side effect placed *inside* those callbacks will silently never run during SSR — expected, but worth remembering when debugging "works in browser, missing content in SSR" reports.

---

## 10. Summary

`public_api_server_entry` is the SSR-facing half of Svelte's dual public entry point. It:

- exposes the genuinely functional server API (`onDestroy`, context API, `createRawSnippet`, `getAbortSignal`, `untrack`),
- absorbs client-only lifecycle noise through no-op aliases so component code stays environment-agnostic,
- converts unrepresentable operations (`mount`, `hydrate`, `unmount`) into precise `Svelte error`s, and
- stays a near-zero-cost facade by delegating all real behavior to the server runtime documented in [context_api_server](context_api_server.md), [server_runtime_rendering_core](server_runtime_rendering_core.md), [server_runtime_blocks](server_runtime_blocks.md), and [server_runtime_payload_model](server_runtime_payload_model.md).
