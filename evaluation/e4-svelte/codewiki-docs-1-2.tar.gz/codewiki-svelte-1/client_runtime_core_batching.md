# client_runtime_core_batching

> **Module:** `packages/svelte/src/internal/client/reactivity/batch.js`
> **Parent:** [client_runtime_core](client_runtime_core.md) (part of the [Reactive Runtime Engine — Signals, Effects & Batching](Reactive_Runtime_Engine_(Signals,_Effects___Batching_with_Dev-Mode_Instrumentation).md))

## 1. Purpose and Scope

`client_runtime_core_batching` is the **transactional scheduling layer** of Svelte 5's client runtime. Every state change in an application — a `$state` write, a prop update, a store mutation — happens *inside a `Batch`*. The batch:

1. **Captures** old and new values of every written source, so multiple writes are coalesced into one atomic update.
2. **Traverses the effect graph**, deciding for each dirty effect whether to run it now, stash it in a typed bucket, or skip it entirely.
3. **Defers async work** (`async_derived` consumers, work under a pending `<svelte:boundary>`) so the UI commits with the latest known values.
4. **Commits DOM mutations** (branch insertion/removal callbacks from `if`/`each`/`key`/etc.) at a well-defined point.
5. **Resolves scheduling promises** (`settled()`) and drives the microtask-based flush pipeline (`flushSync`, `Batch.enqueue`, `dequeue`).

The two components highlighted in the module tree are the bookends of this machinery:

| Component | Visibility | Role |
|---|---|---|
| `clear()` | exported | Forcibly removes **all** live batches to prevent cross-talk between tests (test isolation). |
| `dequeue()` | module-internal | The microtask pump behind `Batch.enqueue()`: drains the internal `tasks` queue **one task per microtask**, so each queued flush runs on its own tick. |

Beyond these, the file hosts the `Batch` class and the flush machinery (`flushSync`, `flush_effects`, `flush_queued_effects`, `schedule_effect`, `suspend`) that the rest of the runtime calls into.

For the vocabulary of effect/signal flags used throughout (`CLEAN`, `DIRTY`, `MAYBE_DIRTY`, `EFFECT`, `RENDER_EFFECT`, `BLOCK_EFFECT`, `ROOT_EFFECT`, `BRANCH_EFFECT`, `ASYNC`, `INERT`, `DESTROYED`), see [client_runtime_core_signal_model](client_runtime_core_signal_model.md). For how a single effect is executed and marked dirty, see [client_runtime_core_runtime](client_runtime_core_runtime.md) and [client_runtime_core_effects](client_runtime_core_effects.md).

---

## 2. Module Architecture

### 2.1 Code Map

| Symbol | Kind | Description |
|---|---|---|
| `Batch` | class | The transaction unit. Captures source values, processes the effect tree, manages async pending counts, commits DOM callbacks. |
| `Batch.ensure()` | static | Get-or-create the current batch; schedules its flush on a microtask (unless inside `flushSync`). |
| `Batch.enqueue(task)` | static | Push a task onto the internal queue; starts `dequeue()` pump via `queueMicrotask`. |
| `current_batch` | export (let) | The batch currently capturing writes; `null` while queued effects run. |
| `previous_batch` | export (let) | Last committed batch; kept (non-async mode only) to avoid overwriting inputs. Slated for removal in 6.0. |
| `batch_deriveds` | export (let) | Time-travel cache: derived values computed against temporary multi-batch values, instead of caching on the derived itself. |
| `effect_pending_updates` | export (let) | Follow-up update callbacks registered while a batch is inactive; drained one-at-a-time by `deactivate()`. |
| `eager_block_effects` | export (let) | Scratch array for block effects scheduled *while* queued effects run; consumed at the end of each `flush_queued_effects` pass. |
| `flushSync(fn?)` | function | Synchronously drain all pending work (optionally running `fn` in between). Forbidden inside effects in async mode. |
| `schedule_effect(effect)` | function | Walk an effect up to its root, dirtying root/branch ancestors, and push the root into `queued_root_effects`. |
| `suspend()` | function | Pair with a pending `<svelte:boundary>`; returns an `unsuspend()` closure. |
| `clear()` | function | **Core component.** Test-isolation hook — drops all live batches. |
| `dequeue()` | internal | **Core component.** Shifts one task off the `tasks` queue and runs it, re-arming a microtask if more remain. |

Internal (private) state of the module: `batches` (all live `Batch` instances), `queued_root_effects`, `last_scheduled_effect` (used to attribute infinite-loop errors), and the re-entrancy guards `is_flushing` / `is_flushing_sync`.

### 2.2 Architecture Diagram

```mermaid
flowchart TB
    subgraph Writers["State writers (capture into batch)"]
        SRC["Sources<br/>(client_runtime_core_sources)"]
        PROPS["Props / stores<br/>(props.js, store.js)"]
    end

    subgraph Batching["batch.js — this module"]
        ENSURE["Batch.ensure()<br/>get-or-create + enqueue flush"]
        BATCH["Batch instance<br/>current / previous maps<br/>effect buckets / pending count"]
        CAPTURE["capture(source, value)"]
        SCHED["schedule_effect()"]
        QRE["queued_root_effects"]
        FLUSHSYNC["flushSync(fn?)"]
        FE["flush_effects()<br/>loop + loop guard"]
        FQE["flush_queued_effects()"]
        DEQ["dequeue()<br/>microtask pump"]
        CLEAR["clear()"]
    end

    subgraph Execution["Effect execution"]
        RT["runtime.js<br/>update_effect / is_dirty"]
        EFF["effects.js<br/>unlink_effect"]
        DOM["DOM blocks<br/>branch callbacks"]
    end

    SRC -->|"Batch.ensure()"| ENSURE
    PROPS --> ENSURE
    ENSURE --> BATCH
    SRC --> CAPTURE
    CAPTURE --> BATCH
    SRC --> SCHED
    SCHED --> QRE
    ENSURE --> DEQ
    DEQ -->|"batch.flush()"| FE
    FLUSHSYNC --> FE
    FE -->|"process()"| BATCH
    BATCH -->|"#traverse_effect_tree()"| RT
    BATCH -->|"#commit() callbacks"| DOM
    BATCH --> FQE
    FQE --> RT
    RT --> EFF
    CLEAR -->|"empty"| BATCH
```

---

## 3. Dependencies

`batch.js` sits at the hub of the reactive engine: it is imported by nearly everything that writes state, while itself depending on the effect executor, the DOM renderer's task queue and boundaries, and shared flags/utilities.

```mermaid
flowchart LR
    BATCH["batch.js"]

    subgraph Siblings["client_runtime_core siblings"]
        RUNTIME["runtime.js<br/>update_effect, is_dirty,<br/>active_effect, set_signal_status"]
        SOURCES["sources.js<br/>old_values"]
        EFFECTS["effects.js<br/>unlink_effect"]
        ASYNC["async.js<br/>unset_context"]
        ERRS["errors.js<br/>flush_sync_in_effect,<br/>effect_update_depth_exceeded"]
    end

    subgraph Shared["shared_runtime"]
        UTILS["shared/utils.js<br/>deferred, define_property"]
        FLAGS["flags/index.js<br/>async_mode_flag"]
    end

    subgraph DOMR["client_dom_renderer"]
        TASK["dom/task.js<br/>flush_tasks"]
        BOUND["dom/blocks/boundary.js<br/>get_pending_boundary"]
    end

    CONST["#client/constants<br/>effect flags"]
    EH["error-handling.js<br/>invoke_error_boundary"]
    DEVFLAG["esm-env<br/>DEV"]

    CONST --> BATCH
    FLAGS --> BATCH
    UTILS --> BATCH
    DEVFLAG --> BATCH
    RUNTIME --> BATCH
    SOURCES --> BATCH
    EFFECTS --> BATCH
    ASYNC --> BATCH
    ERRS --> BATCH
    EH --> BATCH
    TASK --> BATCH
    BOUND --> BATCH
```

| Dependency | Used for |
|---|---|
| `#client/constants` | Effect/signal status flags that drive traversal and bucketing. |
| `runtime.js` | `update_effect` (execute an effect), `is_dirty`, `set_signal_status`, `active_effect`, `is_updating_effect` guards. |
| `sources.js` | `old_values` — reset after each `process()` iteration to release captured pre-update values. |
| `effects.js` | `unlink_effect` — detach dependency-free effects from the graph during GC pass. |
| `async.js` | `unset_context` — released when an async suspension resolves (see [client_runtime_core_async](client_runtime_core_async.md)). |
| `errors.js`, `error-handling.js` | `flush_sync_in_effect`, `effect_update_depth_exceeded`; routing the loop-guard error to the nearest error boundary. |
| `dom/task.js` | `flush_tasks` — drain the renderer's micro/idle task queues inside `flushSync`. |
| `dom/blocks/boundary.js` | `get_pending_boundary` — connect `suspend()`/`unsuspend()` to `<svelte:boundary>` pending counts. |
| `flags/index.js`, `shared/utils.js`, `esm-env` | `async_mode_flag`, `deferred` (for `settled()`), `define_property`, `DEV`. |

---

## 4. Batch Lifecycle

A `Batch` moves through a small, well-defined state machine. Understanding these states explains most of the branching in `process()`, `flush()` and `decrement()`.

```mermaid
stateDiagram-v2
    [*] --> Created: Batch.ensure()
    Created --> Active: enqueue flush task / activate()
    Active --> Flushing: flush() or flushSync()
    Flushing --> Active: process() re-arms current_batch when no new batch was created
    Flushing --> Pending: async effects in flight (#pending > 0) or boundary pending
    Pending --> Flushing: decrement() reaches 0 → reschedule deferred effects
    Flushing --> Committed: #commit() + render/user effects flushed
    Committed --> Discarded: removed from batches set
    Discarded --> [*]
```

Key transitions:

- **Created → Active** — `Batch.ensure()` instantiates a batch, registers it in `batches`, and (outside `flushSync`) enqueues a microtask that calls `batch.flush()`. The enqueued closure re-checks `current_batch === batch` so a concurrent `flushSync` gracefully invalidates it.
- **Active → Flushing** — `flush()` runs `flush_effects()` if root effects are queued, otherwise commits immediately.
- **Flushing → Active** — `process()` deliberately clears `current_batch` while queued render/user effects run, so effect writes start *fresh* batches (preventing infinite self-mixing of old and new source values). If no new batch was created, `process()` reinstates itself, because `flush_effects()` loops.
- **Active → Pending** — `suspend()`/`increment()` put the batch on hold while async effects (`ASYNC` flag) are in flight; collected effects are parked in the deferred buckets.
- **Pending → Flushing** — `decrement()` reaching zero re-marks the parked `#dirty_effects`/`#maybe_dirty_effects` as `DIRTY`/`MAYBE_DIRTY`, schedules them, and flushes again.
- **Neutered batches** — `neuter()` marks a batch whose async effect resolved *after* its parent branch was destroyed; on commit its DOM callbacks are skipped.

---

## 5. Data Flow: From State Write to DOM Update

```mermaid
sequenceDiagram
    participant App as Component / $effect
    participant Src as Source setter
    participant B as Batch
    participant FE as flush_effects
    participant RT as runtime.js
    participant DOM as DOM blocks

    App->>Src: write state
    Src->>B: Batch.ensure()
    B->>B: capture(source, value) — record old + new
    Src->>B: schedule_effect(root)
    Note over B: root pushed to queued_root_effects
    B->>B: Batch.enqueue(flush) → queueMicrotask(dequeue)
    Note over B: dequeue runs one task per microtask
    B->>FE: flush() → flush_effects()
    loop while queued_root_effects not empty
        FE->>B: batch.process(root_effects)
        B->>B: #traverse_effect_tree — bucket or run effects
        B->>RT: update_effect(block effects, immediate)
        B->>DOM: #commit() — branch add/remove callbacks
        B->>RT: flush_queued_effects(render_effects)
        B->>RT: flush_queued_effects(effects / $effect)
        FE->>Src: old_values.clear()
    end
    B-->>App: #deferred resolves → settled() fulfilled
```

### 5.1 Effect Buckets

`process()` and `#traverse_effect_tree()` classify each effect into typed buckets. This is the core scheduling decision table:

| Bucket | Contains | Execution timing |
|---|---|---|
| `#render_effects` | Template effects and `$effect.pre` (`RENDER_EFFECT`, async mode) | On commit, before `$effect`s |
| `#effects` | User `$effect`s (`EFFECT`) | On commit, after render effects |
| `#block_effects` | Block effects (`if`/`each`/`key`/…) that are dirty | **Immediately** during traversal (`update_effect`), then re-queued on later flushes so internal sources (e.g. each-item sources) settle |
| `#async_effects` | `ASYNC`-flagged effects (consumers of `async_derived`) | After the main pass and after time-travel value restoration — they must see the latest values |
| `#boundary_async_effects` | `ASYNC` effects under a *pending* `<svelte:boundary>` | Same as above, but they do **not** block the batch from committing |
| `#dirty_effects` / `#maybe_dirty_effects` | Effects deferred because async work is outstanding (`#defer_effects`) | When `decrement()` reaches 0; statuses are reset to `CLEAN` while parked so they can be re-scheduled by pending async dependencies |
| `skipped_effects` | Branches queued for destruction at commit | Never executed — traversal skips them |

Two commit-time details are worth noting:

- **Branch callbacks** (`add_callback`, run by `#commit()`) are how control-flow blocks apply DOM moves atomically: append new branches, remove skipped ones.
- **Effect GC** in `flush_queued_effects`: an effect that ends up with `deps === null`, `first === null`, `nodes_start === null` is unlinked (`unlink_effect`) if it has no teardown/abort controller, or has `fn = null` to free memory while keeping teardown alive.

---

## 6. Process Flows

### 6.1 Synchronous Flush — `flushSync(fn?)`

```mermaid
flowchart TD
    A["flushSync(fn?)"] --> B{"async_mode_flag and<br/>active_effect set?"}
    B -- yes --> C["throw flush_sync_in_effect"]
    B -- no --> D["is_flushing_sync = true"]
    D --> E{"fn provided?"}
    E -- yes --> F["flush_effects();<br/>result = fn()"]
    E -- no --> G
    F --> G["flush_tasks() — drain micro/idle tasks"]
    G --> H{"queued_root_effects empty?"}
    H -- no --> I["flush_effects()"]
    I --> G
    H -- yes --> J["current_batch.flush()"]
    J --> K{"still empty?<br/>(e.g. $effect.pending updated)"}
    K -- yes --> L["reset last_scheduled_effect;<br/>return result"]
    K -- no --> I
    L --> M["finally: restore is_flushing_sync"]
```

`flushSync` is illegal inside effects when the async mode flag is on — it produces untraceable stack traces and incoherent batches. It loops `flush_tasks()` + `flush_effects()` until the world is quiet, and re-checks quiescence after `current_batch.flush()` since a flush may schedule more work (e.g. `$effect.pending`).

### 6.2 Async Suspension — `suspend()` / `increment()` / `decrement()`

```mermaid
flowchart TD
    S["suspend() — async work begins"] --> T["get_pending_boundary()<br/>boundary.update_pending_count(+1)"]
    T --> U{"boundary already<br/>pending?"}
    U -- no --> V["batch.increment() → #pending +1"]
    U -- yes --> W["batch unaffected"]
    V --> X["effects deferred to<br/>#dirty / #maybe_dirty buckets<br/>(status forced CLEAN)"]
    X --> Y["async work resolves → unsuspend()"]
    Y --> Z["boundary.update_pending_count(-1);<br/>unset_context()"]
    Z --> AA{"boundary was<br/>already pending?"}
    AA -- yes --> AB["batch.deactivate() only"]
    AA -- no --> AC["batch.activate();<br/>batch.decrement()"]
    AC --> AD{"#pending == 0?"}
    AD -- yes --> AE["re-mark + schedule deferred effects;<br/>clear render/effect buckets;<br/>flush()"]
    AD -- no --> AF["deactivate() — drain one<br/>effect_pending_updates entry"]
```

Notes:

- `decrement()` also clears the transient `#render_effects`/`#effects` buckets before re-flushing — those will be re-collected during the new flush with settled async values.
- `deactivate()` clears `current_batch`/`previous_batch` and runs **at most one** callback from `effect_pending_updates` per invocation (loop breaks as soon as a new batch becomes current), avoiding cascades.

### 6.3 Microtask Pump — `Batch.enqueue()` + `dequeue()`

`Batch.enqueue(task)` unshifts onto `tasks`; when the queue was empty it arms `queueMicrotask(dequeue)`. `dequeue()` shifts **one** task, and only re-arms a microtask if tasks remain. This "one task per microtask" pacing guarantees that each scheduled batch flush runs in its own microtask turn, letting interleaved microtasks (resolutions, user code) run in between.

### 6.4 Infinite Loop Guard — `flush_effects()`

Each iteration of the flush loop increments `flush_count`; past **1000** iterations, `infinite_loop_guard()` throws `effect_update_depth_exceeded`. In `DEV`, the runtime aggregates the per-write-stack update counts recorded during tracing (`source.updated`) and logs them first, so the developer sees *which* reactive writes oscillated. The error is then routed to the error boundary nearest `last_scheduled_effect` via `invoke_error_boundary`, so one runaway effect doesn't take down the whole app.

---

## 7. Async Mode & Time Travel

When `async_mode_flag` is enabled, **multiple batches can be alive simultaneously** (one per asynchronous write wave). `process()` implements "time travelling" so effects in each batch are evaluated against *that batch's* view of the world:

1. If `batches.size > 1`, snapshot every source's current `{ v, wv }` into `current_values`.
2. Apply this batch's `current` values to the sources.
3. Roll every *other* live batch's sources back to their `#previous` values (unless already overridden by step 2).
4. Traverse and run the tree in this reconstructed state; derived values computed against temporary values are cached in the shared `batch_deriveds` map (not on the deriveds), see [client_runtime_core_deriveds](client_runtime_core_deriveds.md).
5. After processing, restore snapshotted values — but only where no newer write happened (`source.wv <= wv`), then drop the `batch_deriveds` cache and finally run the collected `#async_effects` / `#boundary_async_effects`, which must observe the *latest* values.

In non-async mode, only one batch is ever live, and `previous_batch` (removed in 6.0) papers over input-overwriting edge cases between consecutive flushes.

---

## 8. Integration with Sibling Modules

| Module | Interaction |
|---|---|
| [client_runtime_core_signal_model](client_runtime_core_signal_model.md) | Supplies the status flags (`CLEAN`, `DIRTY`, `MAYBE_DIRTY`, `ASYNC`, branch/root markers) that drive `#traverse_effect_tree` and `#defer_effects`. |
| [client_runtime_core_runtime](client_runtime_core_runtime.md) | Executor core: `update_effect`, `is_dirty`, `set_signal_status`. Conversely, `runtime.settled()` is just `Batch.ensure().settled()`, and `runtime.tick()` delegates to `flushSync()` (or a rAF in async mode). |
| [client_runtime_core_sources](client_runtime_core_sources.md) | Every write associates itself with the active batch via `capture()`, and `old_values` is cleared after each processing iteration. |
| [client_runtime_core_effects](client_runtime_core_effects.md) | `unlink_effect` garbage-collects dependency-free effects after they run. |
| [client_runtime_core_deriveds](client_runtime_core_deriveds.md) | Deriveds evaluate against temporary values during multi-batch flushes and cache results in `batch_deriveds`. |
| [client_runtime_core_async](client_runtime_core_async.md) | `ASYNC`-flagged effects are bucketed and run last; `unset_context` is released on unsuspend; `suspend()` pairs with boundary pending state. |
| [client_runtime_core_props](client_runtime_core_props.md), [client_runtime_core_stores](client_runtime_core_stores.md) | Prop and store writes are ordinary source writes — they flow through `Batch.ensure()`/`capture()` like any other. |
| [client_runtime_core_diagnostics](client_runtime_core_diagnostics.md) | Errors `flush_sync_in_effect` and `effect_update_depth_exceeded`; DEV loop-guard reporting. |
| [client_dom_renderer](client_dom_renderer.md) | Registers branch callbacks via `add_callback()` (committed atomically), supplies `get_pending_boundary` for suspension, and `flush_tasks` for `flushSync`. |
| [shared_runtime](shared_runtime.md) | `async_mode_flag` gates async bucketing/time travel; `deferred` powers `settled()`. |
| [client_dev_mode](client_dev_mode.md) | Tracing-mode write records (`source.updated`) feed the infinite-loop diagnostics. |

---

## 9. Operational Notes & Testing

- **`clear()` is test-only infrastructure.** It empties the `batches` set so state from one test cannot leak into the next; it does *not* flush or commit anything pending.
- **Writes during flush start fresh batches.** `process()` nulls `current_batch` before running queued render/user effects precisely so that effect-triggered writes cannot contaminate the in-flight batch (a common source of infinite loops in naive schedulers). If no new batch appeared, the original is reinstated because `flush_effects()` may loop again.
- **`#defer_effects` forces status `CLEAN`.** Parked effects must look clean so that, if they depend on still-pending async state, they can be re-scheduled naturally rather than double-run.
- **Boundary async effects never block commits.** Work inside an already-pending `<svelte:boundary>` runs after commit so the fallback UI isn't held hostage by late async results.
- **`flush_count > 1000`** is the hard stop against effect ping-pong; attribution goes to `last_scheduled_effect`, which `schedule_effect` keeps updated.

### Typical test patterns

```js
import { flushSync } from 'svelte';
import { clear } from 'svelte/internal/client/reactivity/batch.js';

// deterministic assertions after a write:
count++;        // schedules a batch
await tick();   // or flushSync() for synchronous assertions
expect(...)     // DOM/effects settled

// between tests, drop all live batches:
beforeEach(() => clear());
```
