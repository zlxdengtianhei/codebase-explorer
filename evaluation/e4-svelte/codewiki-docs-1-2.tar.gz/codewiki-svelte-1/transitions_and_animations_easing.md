# Transitions & Animations — Easing (`svelte/easing`)

> **Module:** `transitions_and_animations_easing`
> **Source:** `packages/svelte/src/easing/index.js`
> **Public entry:** `svelte/easing`
> **Parent system:** [transitions_and_animations](transitions_and_animations.md) within the *Motion & Visual Effects System*

---

## 1. Introduction

The **easing module** is the mathematical heart of Svelte's motion system. It provides **32 pure interpolation functions** that map *normalized time* to *eased progress*, shaping how animations accelerate, decelerate, overshoot, or bounce over their lifetime.

Every easing function has the same trivial signature and the same strict contract:

```js
/**
 * @param {number} t - normalized time, 0 = animation start, 1 = animation end
 * @returns {number}  - eased progress (usually, but not always, in [0, 1])
 */
(t) => number
```

The module itself contains **no state, no dependencies, and no side effects** — it is a collection of standalone named exports (adapted from [`mattdesl/eases`](https://github.com/mattdesl), MIT). This purity is what allows it to be shared freely by the transition functions ([transitions_and_animations_transitions](transitions_and_animations_transitions.md)), the FLIP animator ([transitions_and_animations_flip](transitions_and_animations_flip.md)), and the tweened store ([motion_tweened](motion_tweened.md)).

---

## 2. Module at a Glance

| Property | Value |
|---|---|
| File | `packages/svelte/src/easing/index.js` |
| Exports | 32 easing functions (single file, named exports) |
| Signature contract | `EasingFunction = (t: number) => number` |
| Input domain | `[0, 1]` (normalized elapsed time) |
| Output range | `[0, 1]` for monotonic families; intentionally exceeds `[0, 1]` for `back`, `elastic`; non-monotonic for `bounce` |
| Dependencies | **None** (zero imports — fully tree-shakeable) |
| Environment | Environment-agnostic pure math (usable in SSR code, workers, tests) |
| Provenance | Adapted from `mattdesl/eases` (MIT License) |

### 2.1 Why a shared easing contract matters

Consumers never call easing functions directly — they place them into a config object and let the runtime apply them per frame:

```js
// TransitionConfig / AnimationConfig / TweenedOptions all carry the same field:
{ delay: 0, duration: 400, easing: cubicOut }
```

The `EasingFunction` type is declared once in `packages/svelte/src/transition/public.d.ts` and reused by every motion-facing config type. Any user-supplied `(t) => number` is equally valid, which makes custom curves trivial to adopt.

---

## 3. API Reference — Function Families

All 32 exports, grouped into seven families:

| Family | In (accelerating) | Out (decelerating) | InOut (symmetric) | Curve character |
|---|---|---|---|---|
| **linear** | — | — | `linear` | Identity: `t` (constant speed) |
| **polynomial (power)** | `quadIn` `cubicIn` `quartIn` `quintIn` | `quadOut` `cubicOut` `quartOut` `quintOut` | `quadInOut` `cubicInOut` `quartInOut` `quintInOut` | `tⁿ` for n = 2…5; steeper easing as n grows |
| **sine** | `sineIn` | `sineOut` | `sineInOut` | Quarter-waves of `sin`/`cos`; gentle, never overshoots |
| **circular** | `circIn` | `circOut` | `circInOut` | Quarter-circle arc; stronger start/end inertia than sine |
| **exponential** | `expoIn` | `expoOut` | `expoInOut` | `2^(10·(t−1))`-based; near-frozen start/end (explicit `t === 0 / t === 1` guards) |
| **back** | `backIn` | `backOut` | `backInOut` | Cubic with overshoot constant `s = 1.70158` (× `1.525` for `InOut`); exceeds `[0, 1]` by ~10% |
| **elastic** | `elasticIn` | `elasticOut` | `elasticInOut` | Damped sine oscillation; springs past the target with decaying amplitude |
| **bounce** | `bounceIn` | `bounceOut` | `bounceInOut` | Piecewise-quadratic ball bounce; stays in `[0, 1]` but is **non-monotonic** |

### 3.1 Behavioural caveats for consumers

- **Do not assume clamping.** `back*` and `elastic*` deliberately return values outside `[0, 1]` (e.g. `backOut` reaches ≈ 1.1). Consumers that interpolate between two values (like `flip`'s scale/translate math) get *anticipation/overshoot* for free; consumers that map output to properties with hard limits (opacity) should clamp themselves if required.
- **Do not assume monotonicity.** `bounce*` oscillates — the same eased value can occur at multiple points in time. This matters for anything that treats output as an index or a progress checkpoint.
- **Endpoint precision.** `expoIn`/`expoOut`/`expoInOut` short-circuit exactly at `t = 0` / `t = 1`, and `sineIn` contains a `1e-14` epsilon guard, so all functions return *exactly* `0` and `1` at the endpoints without floating-point noise.

---

## 4. Internal Composition & Dependency Graph

The module is almost entirely **flat** — each function is independent. The single exception is the `bounce` family, where `bounceIn` and `bounceInOut` are *derived* from `bounceOut` via mirror identities:

- `bounceIn(t) = 1 − bounceOut(1 − t)`
- `bounceInOut(t)` reflects `bounceOut` around `t = 0.5`

`bounceOut` itself is a piecewise quadratic with four segments (constants `a = 4/11`, `b = 8/11`, `c = 9/10` delimit the segments).

```mermaid
flowchart TB
    subgraph FAMILIES["svelte/easing — 32 pure functions"]
        direction LR
        subgraph FLAT["standalone functions (no internal deps)"]
            LIN["linear"]
            subgraph POLY["polynomial"]
                Q["quadIn · quadOut · quadInOut"]
                C["cubicIn · cubicOut · cubicInOut"]
                QT["quartIn · quartOut · quartInOut"]
                QN["quintIn · quintOut · quintInOut"]
            end
            subgraph TRANS["transcendental"]
                S["sineIn · sineOut · sineInOut"]
                CI["circIn · circOut · circInOut"]
                EX["expoIn · expoOut · expoInOut"]
            end
            subgraph OVER["overshoot"]
                B["backIn · backOut · backInOut"]
                EL["elasticIn · elasticOut · elasticInOut"]
            end
            BO["bounceOut"]
        end
        subgraph DERIVED["derived functions"]
            BI["bounceIn"]
            BIO["bounceInOut"]
        end
    end

    BI -- "mirror: 1 - bounceOut of 1 - t" --> BO
    BIO -- "piecewise mirror at t = 0.5" --> BO
```

**Maintenance implication:** any change to `bounceOut` affects three of the 32 exports; every other function can be modified in isolation.

---

## 5. Architecture — Position in the Motion & Visual Effects System

The easing module is a **leaf dependency** of the whole motion stack. It ships as the public entry `svelte/easing`, and its functions travel to the runtime *inside config objects* produced by the transition, animation, and motion modules.

```mermaid
flowchart TB
    subgraph PUB["Public API — Motion & Visual Effects System"]
        EASING["svelte/easing<br/>this module · 32 easing functions"]
        TRANS["svelte/transition<br/>fade · fly · slide · scale · blur · draw · crossfade"]
        FLIP["svelte/animate<br/>flip"]
        TWEEN["svelte/motion<br/>tweened"]
    end

    subgraph RT["Client DOM Renderer"]
        DIR["dom/elements/transitions.js<br/>transition() · animation()"]
        ANIM["dom/elements/transitions.js<br/>animate() · runtime linear fallback"]
        LOOP["loop.js · run_tasks · rAF task queue"]
    end

    DOM["DOM element"]
    SIG["reactive store / signals"]

    EASING -- "default linear" --> TRANS
    EASING -- "default cubicOut" --> FLIP
    EASING -- "default linear, or user-supplied" --> TWEEN

    TRANS -- "TransitionConfig.easing" --> DIR
    FLIP -- "AnimationConfig.easing" --> DIR
    TWEEN -- "per-frame easing call" --> LOOP

    DIR --> ANIM
    LOOP --> ANIM
    ANIM -- "eased style keyframes" --> DOM
    LOOP -- "eased store values" --> SIG
```

### 5.1 Default easing per consumer

| Consumer | Config field | Default |
|---|---|---|
| `fade`, `crossfade` (transition) | `TransitionConfig.easing` | `linear` |
| `fly`, `slide`, `scale`, `draw`, `blur` (transition) | `TransitionConfig.easing` | `cubicOut` |
| `flip` (animate directive) | `AnimationConfig.easing` | `cubicOut` |
| `tweened` (motion) | `TweenedOptions.easing` | `linear` |

Details of how each consumer builds its config are documented in the respective module pages: [transitions_and_animations_transitions](transitions_and_animations_transitions.md), [transitions_and_animations_flip](transitions_and_animations_flip.md), [motion_tweened](motion_tweened.md).

---

## 6. Data Flow — How `easing(t)` Is Applied at Runtime

There are **two distinct application strategies** at runtime, both located in the Client DOM Renderer (see [client_dom_renderer_elements_and_events](client_dom_renderer_elements_and_events.md)):

### 6.1 CSS-based transitions & animations — keyframe sampling

The runtime `animate()` function does **not** run the easing in a per-frame JS callback for CSS transitions. Instead it *pre-samples* the eased curve once, when the animation starts, and hands the result to the Web Animations API:

- sample count `n = Math.ceil(duration / (1000 / 60))` — one keyframe per ~60 fps frame;
- for each keyframe `i`: `t = t1 + delta * easing(i / n)`, then `css(t, 1 − t)` produces the style string;
- the browser then interpolates between the pre-eased keyframes linearly;
- the same easing is re-applied in `get_t()` so that `tick` callbacks (JS-driven properties) receive eased progress matching the visual animation.

```mermaid
sequenceDiagram
    autonumber
    participant FX as state change / effect
    participant TM as transition manager — transition
    participant A as animate
    participant E as easing t
    participant C as css t u
    participant W as element.animate WAAPI

    FX->>TM: element enters or leaves DOM
    TM->>A: options from transition fn
    A->>A: easing = options.easing or linear
    A->>A: n = ceil duration / 16.67
    loop for i = 0 .. n
        A->>E: easing i / n
        E-->>A: eased progress
        A->>C: css eased t
        C-->>A: style string
    end
    A->>W: play keyframes linearly over duration
    W-->>FX: onfinish — introend / outroend
```

### 6.2 JS-driven motion — per-frame evaluation

The `tweened` store applies easing **every frame inside JavaScript**, because the animated value feeds the reactive graph rather than a style string:

```mermaid
flowchart LR
    A["tweened.set new_value"] --> B["rAF loop task"]
    B --> C["t = elapsed / duration"]
    C --> D["eased = easing t"]
    D --> E["value = interpolate from to at eased"]
    E --> F["store.set value - reactive update"]
    F -- "elapsed < duration" --> B
    F -- "done" --> G["resolve promise at target"]
```

### 6.3 Where the clock comes from

Both strategies are driven by the shared rAF task queue (`loop.js::run_tasks`, see [client_runtime_core_runtime](client_runtime_core_runtime.md)). The easing function is *stateless*, so all timing state (start time, delay, duration, reversal/`t1` bookkeeping for bidirectional transitions) lives in the consumers — never in this module.

---

## 7. Component Interaction Summary

| Component | Role | Interaction with easing |
|---|---|---|
| `easing/index.js` (this module) | Pure curve library | Exports functions; knows nothing about DOM, stores, or timing |
| `transition/index.js` | Builds `TransitionConfig` | Embeds an easing (its own default or user override) into the returned config |
| `animate/index.js` (`flip`) | Builds `AnimationConfig` | Defaults to `cubicOut`; embeds it in the config alongside a `css` generator |
| `motion/tweened.js` | Reactive value animation | Calls `easing(elapsed / duration)` every frame and writes the result into a store |
| `dom/elements/transitions.js` (`animate`, `transition`, `animation`) | Runtime executor | Destructures `easing` from configs; samples keyframes; supplies the runtime `linear` fallback |
| `internal/client/loop.js` | Clock | Drives rAF ticks consumed by `animate`'s `tick` loop and `tweened`'s task |

---

## 8. Usage Examples

### 8.1 Overriding a transition default

```svelte
<script>
  import { fly } from 'svelte/transition';
  import { elasticOut } from 'svelte/easing';
</script>

{#if visible}
  <div transition:fly={{ y: 24, duration: 600, easing: elasticOut }}>
    springs into place
  </div>
{/if}
```

### 8.2 Tweened values with a custom curve

```js
import { tweened } from 'svelte/motion';
import { cubicOut } from 'svelte/easing';

const progress = tweened(0, { duration: 400, easing: cubicOut });
await progress.set(0.7); // eases with t³ deceleration
```

### 8.3 Custom easings are first-class

```js
// any (t: number) => number works — no registration needed
const overshoot = (t) => 1 + 2.7 * Math.pow(t - 1, 3) + 1.7 * Math.pow(t - 1, 2);
```

---

## 9. Design Characteristics

- **Tree-shakeable by construction.** Each easing is an independent named export with no imports and no side effects; the repo's `check-treeshakeability` tooling can verify that unused curves are dropped from bundles.
- **Zero-dependency purity.** Deterministic outputs make the module trivially unit-testable and safe in any JS environment (SSR, workers, tests). Note that while the math runs anywhere, *animations themselves* execute only on the client — during SSR the eased styles are simply never sampled.
- **Formula symmetry.** `In` variants accelerate, `Out` variants decelerate, `InOut` variants splice the two at `t = 0.5`. The bounce family implements this via explicit mirror identities rather than separate formulas, keeping the curve definition in one place (`bounceOut`).
- **Tuned constants.** `back` uses Penner's overshoot constant `s = 1.70158` (scaled by `1.525` for `InOut`); `bounce` uses the classic four-segment parabolic constants; `expo`/`sine` include endpoint/epsilon guards so curves land exactly on `0` and `1`.
- **No clamping at the source.** Range violations from `back`/`elastic`/`bounce` are a *feature* (anticipation, spring, bounce). Consumers decide whether to clamp.

---

## 10. References

| Topic | Document |
|---|---|
| Parent module: transitions & animations system | [transitions_and_animations](transitions_and_animations.md) |
| Transition functions that consume easing (`fade`, `fly`, `crossfade`, …) | [transitions_and_animations_transitions](transitions_and_animations_transitions.md) |
| FLIP animation (`flip`, `AnimationConfig`) | [transitions_and_animations_flip](transitions_and_animations_flip.md) |
| Tweened reactive motion (per-frame easing consumer) | [motion_tweened](motion_tweened.md) |
| Spring-based alternative to eased tweens | [motion_spring](motion_spring.md) |
| Runtime executor that samples eased keyframes | [client_dom_renderer_elements_and_events](client_dom_renderer_elements_and_events.md) |
| rAF loop / clock that drives eased animations | [client_runtime_core_runtime](client_runtime_core_runtime.md) |
