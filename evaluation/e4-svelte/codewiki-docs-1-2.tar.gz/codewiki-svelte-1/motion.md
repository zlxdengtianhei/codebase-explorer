# Motion (`svelte/motion`)

## 1. Purpose & Overview

The **motion** module implements the public `svelte/motion` entry point: a small but central library of **time-animated reactive values**. Instead of jumping between values, motion values move smoothly over time using one of two paradigms:

| Paradigm | Mechanics | Exports |
|---|---|---|
| **Spring physics** | Damped harmonic oscillator (`stiffness`, `damping`, `precision`) — overshoots and bounces, velocity-aware | `spring` (legacy store), `Spring` class |
| **Tween interpolation** | Fixed `delay` / `duration` / `easing` — deterministic, time-locked transition between two values | `tweened` (legacy store), `Tween` class |

The module ships a **dual API**:

1. **Legacy store factories** — `spring(value, opts)` and `tweened(value, opts)` return Svelte 4–style *stores* (`subscribe`-based). They are **deprecated** since 5.8.0 but retained for compatibility.
2. **Modern classes** — `new Spring(value, opts)` and `new Tween(value, opts)` (since 5.8.0) are backed directly by fine-grained **signals** (`$state`), so `spring.target` / `spring.current` can be bound reactively in templates without any store adapter.

Additionally, `svelte/motion` exports **`prefersReducedMotion`** (since 5.7.0), a reactive `MediaQuery` matching the CSS `prefers-reduced-motion: reduce` media query, which lets applications scale down animations for accessibility.

### Key files

| File | Contents |
|---|---|
| `packages/svelte/src/motion/spring.js` | `tick_spring` physics integrator, legacy `spring()` store, modern `Spring` class |
| `packages/svelte/src/motion/tweened.js` | `get_interpolator` interpolation builder, legacy `tweened()` store, modern `Tween` class |
| `packages/svelte/src/motion/public.d.ts` | Public type contracts — `Spring` (interface + class declaration merging), `Tweened<T>` |
| `packages/svelte/src/motion/private.d.ts` | Internal option contracts — `SpringOpts`, `SpringUpdateOpts`, `TweenedOptions`, `TickContext`, `Updater` |
| `packages/svelte/src/motion/index.js` | Public entry — re-exports everything above plus `prefersReducedMotion` |
| `packages/svelte/src/motion/utils.js` | `is_date` helper shared by both engines |

## 2. Position in the Overall System

Motion sits **on top of the reactive runtime**, gluing together three engine services and exposing one user-facing import:

```mermaid
graph TD
    subgraph USER["User component code"]
        COMP["import { Spring, Tween }<br/>from 'svelte/motion'"]
    end

    subgraph MOTION["motion module (this module)"]
        IDX["motion/index.js<br/>prefersReducedMotion"]
        SPR["motion/spring.js<br/>spring store · Spring class"]
        TWE["motion/tweened.js<br/>tweened store · Tween class"]
        PUB["motion/public.d.ts<br/>Spring · Tweened&lt;T&gt; contracts"]
    end

    subgraph RUNTIME["Reactive Runtime Engine (client)"]
        LOOP["loop.js / timing.js<br/>shared RAF task registry"]
        SIG["sources.js / runtime.js / effects.js<br/>state · set · get · render_effect"]
        TAG["dev/tracing.js<br/>tag()"]
    end

    subgraph STORES["Reactive State Primitives & Store Interop"]
        WR["store/shared/index.js<br/>writable()"]
        MQ["reactivity/media-query.js<br/>MediaQuery"]
    end

    subgraph SIBLINGS["Sibling sub-modules"]
        EAS["transitions_and_animations<br/>easing functions (linear, cubicOut, …)"]
    end

    COMP --> IDX
    COMP --> SPR
    COMP --> TWE
    PUB -.declares.-> SPR
    PUB -.declares.-> TWE

    SPR --> LOOP
    TWE --> LOOP
    SPR --> SIG
    TWE --> SIG
    SPR --> TAG
    TWE --> TAG
    SPR --> WR
    TWE --> WR
    TWE --> EAS
    IDX --> MQ
```

**Consumes from other modules:**

- **Reactive Runtime Engine** — the shared `requestAnimationFrame` task loop (`loop`, `raf` in `internal/client/loop.js` / `timing.js`) drives every animation frame; `state`/`set`/`get` (`internal/client/reactivity/sources.js`, `internal/client/runtime.js`) back the modern `Spring`/`Tween` classes; `render_effect` powers the `Spring.of` / `Tween.of` derived factories; `tag` from [client_dev_mode](client_dev_mode.md) labels signals for the dev-tools debugger.
- **Reactive State Primitives & Store Interop** — `writable()` from [stores_core](stores_core.md) provides the subscriber machinery for the legacy `spring`/`tweened` stores; `MediaQuery` from [reactive_builtin_classes_environment_and_ssr](reactive_builtin_classes_environment_and_ssr.md) backs `prefersReducedMotion`.
- **transitions_and_animations** (sibling sub-module of the parent *Motion & Visual Effects System*) — `tweened`/`Tween` default to the `linear` easing from `src/easing/index.js`, which lives with the transition helpers. See [transitions_and_animations](transitions_and_animations.md).

**Feeds into:** user-facing components via the `svelte/motion` import. The generated component code binds `spring.target` / `spring.current` like any reactive value — no special compiler support is required.

## 3. Architecture & Core Concepts

### 3.1 Shared animation machinery

Both engines (spring and tween) share the same execution skeleton:

```mermaid
sequenceDiagram
    participant U as User / Template
    participant E as Engine (Spring / Tween)
    participant L as loop() RAF registry
    participant S as Store or Signal

    U->>E: set(target, options)
    E->>E: resolve options (delay, stiffness… / easing, duration…)
    E->>L: loop(callback) — schedule per-frame task
    L-->>E: { promise, abort() }
    loop every animation frame until settled
        L->>E: callback(now)
        E->>E: compute next value (physics step or eased interpolation)
        E->>S: update value
        S-->>U: subscribers notified / signals invalidated
    end
    E-->>U: promise resolves when animation completes
```

Robustness rules shared by both engines:

- **Time clamping** — elapsed time per frame is clamped to `1000/30` ms (≈1/30 s), so a blocked thread or inactive tab cannot make the animation "go haywire" with a huge delta.
- **Task lifecycle** — `loop()` returns a `Task` with a `promise` (resolves on completion) and `abort()` (removes the frame callback). Starting a new animation aborts/neutralizes the previous one.
- **Time source abstraction** — `raf.now()` uses `performance.now()` in the browser and `Date.now()` on the server, and `raf.tick` lazily resolves `requestAnimationFrame` so user code stays testable without JSDOM.

### 3.2 Spring engine (physics)

`tick_spring(ctx, last_value, current_value, target_value)` implements a semi-implicit damped harmonic oscillator and **recurses over value shapes**:

- `number` / `Date` → `acceleration = (stiffness·Δ − damping·velocity) · inv_mass`, integrate per normalized `dt`; settles when both velocity and delta fall below `precision`.
- `Array` → per-element recursion.
- `object` → per-key recursion.
- anything else → `Error: Cannot spring <type> values`.

The legacy `spring()` store adds **soft/hard update semantics**: `hard: true` (or initial `undefined` value) snaps immediately, while `soft: true | rate` sets `inv_mass = 0` and ramps it back to 1 over time, making the spring temporarily "infinitely heavy" (unresponsive to spring forces) and gradually restoring agility. The modern `Spring` class replaces this with `instant: true` and `preserveMomentum: ms` (sets `inverse_mass = 0` with a momentum budget — useful for "fling" gestures) and keeps *all* configuration (stiffness, damping, precision, current, target) as reactive signals.

### 3.3 Tween engine (interpolation)

`get_interpolator(a, b)` builds a `(t: number) => T` function by recursion over value shape:

```mermaid
flowchart TD
    A["get_interpolator(a, b)"] --> B{"a === b or NaN?"}
    B -- yes --> C["constant () => a"]
    B -- no --> D{"types / array-ness match?"}
    D -- no --> E["Error: Cannot interpolate<br/>values of different type"]
    D -- yes --> F{"shape?"}
    F -- Array --> G["recursive per element"]
    F -- Date --> H["lerp over getTime()"]
    F -- object --> I["recursive per key<br/>(nulls throw)"]
    F -- number --> J["a + t·(b − a)"]
    F -- other --> K["snap: () => b"]
    G & H & I & J & K --> L["(t) => interpolated T"]
```

Each frame computes `value = fn(easing(elapsed / duration))`; `duration` may be a function `(from, to) => ms` for distance-based timing. `duration: 0` short-circuits to an instant set.

### 3.4 Type contracts & declaration merging

`public.d.ts` performs **declaration merging** for `Spring`: a *store-shaped interface* (`Readable` + `subscribe`/`update` + scalar `stiffness`/`damping`/`precision` fields) is merged with the *class* (`target`/`current` accessors) so that Svelte 4-era code that type-checks against `Spring<T>` keeps compiling, while new code gets `target`/`current`. The comment in the file notes this is transitional — Svelte 6 will split them. `Tweened<T>` remains the plain store contract (`Readable` + `set`/`update`).

## 4. Public API Surface (`svelte/motion`)

| Export | Kind | Since | Notes |
|---|---|---|---|
| `spring(value, opts?)` | store factory | 3.x | **Deprecated** → use `Spring` |
| `Spring` | class | 5.8.0 | `new Spring(value, { stiffness, damping, precision })`; `Spring.of(fn, opts)` for derived springs; `set(value, { instant, preserveMomentum })` |
| `tweened(value, defaults?)` | store factory | 3.x | **Deprecated** → use `Tween` |
| `Tween` | class | 5.8.0 | `new Tween(value, { delay, duration, easing, interpolate })`; `Tween.of(fn, opts)` |
| `prefersReducedMotion` | `MediaQuery` | 5.7.0 | matches `prefers-reduced-motion: reduce` |
| `Spring<T>` (interface), `Tweened<T>` | types | — | declared in `public.d.ts` |

Typical modern usage (from the JSDoc):

```svelte
<script>
        import { Spring } from 'svelte/motion';
        const spring = new Spring(0);
</script>

<input type="range" bind:value={spring.target} />
<input type="range" bind:value={spring.current} disabled />
```

## 5. Sub-module Documentation

The motion module splits cleanly into two engine sub-modules, each documented in its own generated file:

- **[motion_spring](motion_spring.md)** (`motion_spring.md`) — `spring.js`: the `tick_spring` physics integrator, the legacy `spring()` store (hard/soft semantics, token-based promise resolution) and the modern `Spring` class (signal-backed, `of()` factory, `preserveMomentum`).
- **[motion_tweened](motion_tweened.md)** (`motion_tweened.md`) — `tweened.js` and `public.d.ts`: `get_interpolator` recursive interpolation, the legacy `tweened()` store (delay/duration/easing lifecycle) and the modern `Tween` class, plus the public type contracts (`Tweened<T>`, `Spring` interface/class declaration merging).

Both engines share the animation skeleton described in [§3.1 Shared animation machinery](#31-shared-animation-machinery) and differ only in how a single frame's value is computed.

## 6. Related Documentation

- [client_runtime_core_runtime](client_runtime_core_runtime.md) — the shared `loop`/RAF machinery and signal `get` that schedule every animation frame.
- [client_runtime_core_sources](client_runtime_core_sources.md) — `state`/`set`, the signals backing `Spring`/`Tween` instances.
- [client_runtime_core_effects](client_runtime_core_effects.md) — `render_effect`, used by `Spring.of`/`Tween.of`.
- [client_dev_mode_debugging](client_dev_mode_debugging.md) — `tag()` used to label spring/tween signals in dev tools.
- [stores_core](stores_core.md) — `writable()` backing the legacy store factories.
- [reactive_builtin_classes_environment_and_ssr](reactive_builtin_classes_environment_and_ssr.md) — `MediaQuery`, the basis of `prefersReducedMotion`.
- [transitions_and_animations](transitions_and_animations.md) — easing functions and CSS transitions; the default `easing` source for tweens.
