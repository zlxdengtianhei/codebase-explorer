# Reactive Built-in Classes — Environment & SSR (`reactive_builtin_classes_environment_and_ssr`)

## 1. Introduction

This module is the **environment-aware slice** of `svelte/reactivity`. It provides reactive primitives whose values depend on the *execution environment* (viewport, device characteristics, browser vs. server) rather than on application state:

| Component | File | Variant | Purpose |
|---|---|---|---|
| `MediaQuery` | `packages/svelte/src/reactivity/media-query.js` | Client (browser) | Live-reactive wrapper around `window.matchMedia` exposing a `current: boolean` property |
| `MediaQuery` (stub) | `packages/svelte/src/reactivity/index-server.js` | Server (SSR) | Inert stand-in holding a static fallback in `current` (no `window` on the server) |
| `createSubscriber` (stub) | `packages/svelte/src/reactivity/index-server.js` | Server (SSR) | No-op stand-in for the client subscription-lifecycle helper, keeping the server build dependency-free |

Together with its siblings — [Reactive Built-in Classes: Collections](reactive_builtin_classes_collections.md) (`SvelteMap`) and [Reactive Built-in Classes: Temporal, URL & Search-Params Primitives](reactive_builtin_classes_temporal_url_primitives.md) (`SvelteDate`, `SvelteURL`, `SvelteURLSearchParams`) — it forms the `reactive_builtin_classes` family exposed through the public `svelte/reactivity` entry point (see [Public API — Type Contracts](public_api_type_contracts.md)).

**Key design constraint:** browser-only APIs (`window.matchMedia`) cannot exist in an SSR bundle. The module therefore follows Svelte's *dual-export* strategy: bundlers resolve `svelte/reactivity` to the real implementation on the client and to lightweight stubs on the server, so that a single component source compiles and renders in both environments.

---

## 2. Architecture

### 2.1 Client/Server export swapping

The `svelte/reactivity` entry resolves through a condition-based export map:

- **Client build** → `index-client.js`, which re-exports the *real* `MediaQuery` from `media-query.js` and the *real* `createSubscriber` from `create-subscriber.js`.
- **Server build** → `index-server.js`, a **fully self-contained file with zero imports** that defines stub classes/functions inline (and re-aliases the sibling built-ins to `globalThis` equivalents, e.g. `SvelteDate = globalThis.Date` — those aliases belong to the sibling modules documented above).

Because `index-server.js` imports nothing, the server bundle never pulls in the client reactivity engine, DOM event helpers, or dev-mode tooling — guaranteeing the SSR build stays small and environment-safe.

```mermaid
flowchart TB
    APP["Consumer code<br/>import { MediaQuery } from 'svelte/reactivity'"] --> RESOLVE{"Module resolver<br/>(bundler export conditions)"}

    RESOLVE -->|"browser / client build"| IC["reactivity/index-client.js"]
    RESOLVE -->|"server / SSR build"| IS["reactivity/index-server.js<br/>(zero imports, self-contained)"]

    subgraph CLIENT ["Client implementation"]
        MQC["media-query.js :: MediaQuery<br/>extends ReactiveValue"]
        RVC["reactive-value.js :: ReactiveValue"]
        CS["create-subscriber.js :: createSubscriber<br/>(real: effect-tracked, ref-counted)"]
        EV["internal/client/dom/elements/events.js :: on"]
        MQC --> RVC
        MQC --> EV
        RVC --> CS
    end

    subgraph SERVER ["Server stubs (defined inline)"]
        MQS["class MediaQuery<br/>current = matches (static)"]
        CSS["createSubscriber(_) → () => {}<br/>(no-op)"]
        IS --> MQS
        IS --> CSS
    end

    IC --> MQC
    IC --> CS
```

### 2.2 Class model

```mermaid
classDiagram
    class ReactiveValue {
        -#fn: () => T
        -#subscribe: () => void
        +get current() T
        +ReactiveValue(fn, onsubscribe)
    }
    class MediaQuery_client ["MediaQuery (client)"] {
        +«constructor» MediaQuery(query, fallback?)
        +current boolean
    }
    class MediaQuery_server ["MediaQuery (server stub)"] {
        +current boolean
        +«constructor» MediaQuery(query, matches = false)
    }
    class ServerSubscriber ["createSubscriber (server stub)"] {
        +«function» createSubscriber(_) → () => void
    }
    class ClientSubscriber ["createSubscriber (client, reference)"] {
        +«function» createSubscriber(start) → subscribe()
    }

    ReactiveValue <|-- MediaQuery_client
    ServerSubscriber ..> MediaQuery_server : used by ReactiveValue if<br/>ReactiveValue is ever pulled server-side
    ClientSubscriber ..> ReactiveValue : plugs in onsubscribe lifecycle
    note for MediaQuery_client "Read fn: () => q.matches\nSubscribe: on(q, 'change', update)"
```

The generic `ReactiveValue` base class (part of the shared `reactive_builtin_classes` family) implements the read/subscribe contract:

```js
get current() {
    this.#subscribe();   // lazily attach external event source (no-op on server)
    return this.#fn();   // read the current value
}
```

`#subscribe` is produced by `createSubscriber(onsubscribe)` — the *real* version on the client ([client runtime core](client_runtime_core_runtime.md)) and the **no-op stub on the server** (this module). This is precisely how the same `ReactiveValue` code path works in both environments.

---

## 3. Component Reference

### 3.1 `MediaQuery` — client (`packages/svelte/src/reactivity/media-query.js`)

A reactive media query. Added in Svelte **5.7.0**.

```svelte
<script>
    import { MediaQuery } from 'svelte/reactivity';

    const large = new MediaQuery('min-width: 800px');
</script>

<h1>{large.current ? 'large screen' : 'small screen'}</h1>
```

**Constructor behavior — query normalization.** Before calling `window.matchMedia`, the query string is normalized so users may write either full queries (`'screen and (min-width: 800px)'`) or feature-only shorthand (`'min-width: 800px'`):

1. If the query already contains parentheses (matches `/\(.+\)/`) → used as-is.
2. Else, if every whitespace/comma-separated token is one of the **non-parenthesized keywords** `all`, `print`, `screen`, `and`, `or`, `not`, `only` → used as-is (e.g. `new MediaQuery('screen')` must *not* become `(screen)`; see upstream issue svelte#15930).
3. Otherwise → wrapped in parentheses: `'min-width: 800px'` becomes `'(min-width: 800px)'`.

The `some()`-based keyword check (rather than `every`) intentionally tolerates comma-separated query lists such as `'random,screen'` still resolving via `matchMedia`.

**Wiring into reactivity:**

```js
const q = window.matchMedia(final_query);
super(
    () => q.matches,                              // read function
    (update) => on(q, 'change', update)           // lazy subscription setup
);
```

- **Read path:** every access to `.current` evaluates `q.matches`.
- **Subscribe path:** the first read *inside an effect/derived* triggers `on(q, 'change', update)`, which attaches a native `change` listener via the shared DOM event helper [`on`](client_dom_renderer_elements_and_events.md) and returns its detach function. When the last subscriber effect is destroyed, the client `createSubscriber` invokes that cleanup to remove the listener.
- The optional `fallback` parameter is accepted for API parity with the server variant and for developer intent-documentation; it is **not** used by the client implementation (the browser always reports truth via `matchMedia`).

> ⚠️ The constructor **eagerly** calls `window.matchMedia`. This is exactly why the client class cannot be shipped to Node — the server stub exists for that reason.

### 3.2 `MediaQuery` — server stub (`packages/svelte/src/reactivity/index-server.js`)

```js
export class MediaQuery {
    current;
    constructor(query, matches = false) {
        this.current = matches;
    }
}
```

- Mirrors the client shape: constructor takes `(query, matches?)`, exposes `current`.
- **No reactivity at all** — `current` is a plain, frozen-at-construction boolean (default `false`).
- The `query` string is validated implicitly by usage but never evaluated; no `window` access occurs, so instantiation during SSR is safe.

### 3.3 `createSubscriber` — server stub (`packages/svelte/src/reactivity/index-server.js`)

```js
export function createSubscriber(_) {
    return () => {};
}
```

- Ignores its `start` callback and returns a function that does nothing when called as a "subscription".
- Guarantees that any code path shared with the client — most importantly `ReactiveValue`'s `current` getter — remains callable on the server while performing zero work. It also future-proofs the server build: any sibling reactive class that internally relies on `createSubscriber` links and treeshakes cleanly without the client runtime.

For the **real** client-side `createSubscriber` (reference-counted, render-effect–managed external-event bridge used by `MediaQuery` and siblings like `SvelteDate`), see [Client Runtime Core — Runtime](client_runtime_core_runtime.md) and the signal model in [Client Runtime Core — Signal Model](client_runtime_core_signal_model.md). Its lifecycle is not duplicated here.

---

## 4. Behavior & Data Flow

### 4.1 Client lifecycle: first read → live updates → teardown

```mermaid
sequenceDiagram
    autonumber
    participant Effect as Effect / Derived<br/>(client runtime)
    participant Current as MediaQuery.current<br/>(ReactiveValue getter)
    participant Sub as createSubscriber<br/>(client)
    participant MM as matchMedia MQL
    participant on as on(q, 'change', …)

    Note over MM: constructor already ran<br/>window.matchMedia(final_query)

    Effect->>Current: read .current
    Current->>Sub: #subscribe()
    Note over Sub: effect_tracking() === true →<br/>open render_effect, subscribers = 0 → 1
    Sub->>on: start(update)
    on->>MM: addEventListener('change', handler)
    Current->>MM: read q.matches
    MM-->>Current: boolean
    Current-->>Effect: value (tracked)

    MM->>on: 'change' event fires
    on->>Sub: update() → increment(version)
    Sub-->>Effect: effect invalidated → re-run

    Note over Effect,Sub: re-run reads .current again<br/>(subscribers stays ≥ 1, listener kept)

    Effect->>Sub: effect destroyed
    Note over Sub: microtask-deferred teardown:<br/>subscribers 1 → 0 → stop?.()
    Sub->>on: cleanup() → removeEventListener
    Sub->>Sub: increment(version) so a later<br/>re-subscribe dirties dependents
```

Details of reference counting, microtask-deferred teardown, and the version-source invalidation trick belong to the client runtime and are documented in [Client Runtime Core](client_runtime_core_runtime.md).

### 4.2 Server (SSR) flow and hydration contract

```mermaid
flowchart LR
    subgraph Server ["Server render"]
        A["new MediaQuery('min-width: 800px', fallback?)"] --> B["current = matches ?? false"]
        B --> C["SSR HTML emitted using<br/>static fallback value"]
    end
    C --> D["HTML sent to browser"]
    D --> E{"Client hydration"}
    E -->|"fallback === q.matches"| F["✔ No visible change"]
    E -->|"fallback !== q.matches"| G["⚠ Content flips on hydration<br/>(inherent limitation, not a bug)"]
```

**SSR caveat (explicit in the class docs):** during server-side rendering there is *no way to know the correct match state*, so the stub renders the fallback (default `false`). If the real client-side value differs, content changes upon hydration. Recommended mitigations:

- Prefer **CSS media queries** for purely presentational branches — the compiler's CSS pipeline scopes them correctly (see [CSS Pipeline](compiler_css_pipeline_analysis.md)).
- Supply a `fallback` that matches what SSR is expected to render, and keep mismatches non-jarring.
- Accept the one-frame flip for genuinely JS-dependent layout decisions.

---

## 5. Dependencies

```mermaid
flowchart TB
    THIS["this module<br/>reactive_builtin_classes_environment_and_ssr"]

    subgraph SIB ["sibling modules (reactive_builtin_classes)"]
        RV["ReactiveValue<br/>reactive-value.js"]
        CSP["client createSubscriber<br/>create-subscriber.js"]
        SIBS["SvelteDate / SvelteMap /<br/>SvelteURL / SvelteURLSearchParams"]
    end

    subgraph ENGINE ["Reactive Runtime Engine"]
        RUNTIME["client runtime<br/>(get, tick, untrack, effect_tracking)"]
        EFFECTS["effects<br/>(render_effect)"]
        SOURCES["sources<br/>(source, increment)"]
        DEVTOOL["dev tracing<br/>(tag)"]
        TASK["dom/task<br/>(queue_micro_task)"]
    end

    subgraph RENDER ["Component Rendering Backends"]
        EV["on — element event helper<br/>(client DOM events)"]
    end

    THIS --> RV
    THIS --> EV
    RV --> CSP
    CSP --> RUNTIME
    CSP --> EFFECTS
    CSP --> SOURCES
    CSP --> DEVTOOL
    CSP --> TASK
    SIBS -.-> CSP
```

**Outbound dependencies**

| From | To | Nature |
|---|---|---|
| `media-query.js::MediaQuery` | `reactive-value.js::ReactiveValue` | inheritance (read/subscribe contract) |
| `media-query.js::MediaQuery` | `events/index.js` → `internal/client/dom/elements/events.js::on` | native event attach/detach helper |
| `index-server.js` stubs | *(none — zero imports)* | self-contained by design |

**Inbound consumers**

| Consumer | Usage |
|---|---|
| `index-client.js` | re-exports both real implementations as the public `svelte/reactivity` surface ([public API](public_api_type_contracts.md)) |
| `index-server.js` | defines/exports the stubs consumed by SSR builds of user code |
| Sibling reactive classes (`SvelteDate`, …) | share the `ReactiveValue` + `createSubscriber` infrastructure rather than the `MediaQuery` class itself |

---

## 6. Design Notes & Constraints

1. **Stub parity over stub silence.** The server `MediaQuery` keeps the exact constructor signature and `current` field of the client class, so user code compiles and type-checks identically in both environments; only runtime behavior (reactivity) is dropped.
2. **Normalization edge case (svelte#15930).** The keyword whitelist exists because naive auto-parenthesization would turn `new MediaQuery('screen')` into `(screen)` — an invalid query that never matches. The `split(/[\s,]+/).some(...)` check preserves media *types* and combinator-only queries while still wrapping bare *features*.
3. **Eager `matchMedia` is a feature.** Constructing the `MediaQueryList` once in the constructor means the read function `() => q.matches` is a pure field read; laziness is delegated entirely to the subscribe layer, keeping `ReactiveValue` trivial.
4. **Server stub is a boundary artifact, not a fork.** `index-server.js` never imports from the client runtime — the stub `createSubscriber` exists only so that shared code (like `ReactiveValue`) can be linked into a server bundle without dragging in DOM/signal machinery, keeping SSR output treeshakeable and runtime-neutral (it even works in non-Node server environments since it touches no globals).
5. **Hydration honesty.** The module deliberately does *not* attempt to sync server fallback with client state; instead the public docs warn about hydration mismatch and nudge users toward CSS media queries where possible — matching Svelte's general philosophy that environment-dependent presentation belongs in CSS.

---

## 7. Related Modules

- [Reactive Built-in Classes — Collections](reactive_builtin_classes_collections.md) — `SvelteMap`, same export surface.
- [Reactive Built-in Classes — Temporal/URL Primitives](reactive_builtin_classes_temporal_url_primitives.md) — `SvelteDate`, `SvelteURL`, `SvelteURLSearchParams`; the heavier consumers of the real `createSubscriber`.
- [Client Runtime Core — Runtime](client_runtime_core_runtime.md) · [Signal Model](client_runtime_core_signal_model.md) · [Batching](client_runtime_core_batching.md) — the engine backing `ReactiveValue`/`createSubscriber` on the client.
- [Client DOM Renderer — Elements & Events](client_dom_renderer_elements_and_events.md) — home of the `on` helper used to listen for `matchMedia` changes.
- [Public API — Type Contracts](public_api_type_contracts.md) · [Public API — Server Entry](public_api_server_entry.md) — where `svelte/reactivity` and SSR mounting fit into the user-facing surface.
