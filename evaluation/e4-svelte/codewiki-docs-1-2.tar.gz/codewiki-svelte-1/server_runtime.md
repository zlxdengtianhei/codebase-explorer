# Server Runtime (`server_runtime`)

> The server-side rendering (SSR) backend of Svelte 5 — the string-emitting counterpart of the client DOM renderer. It executes components that were compiled with `server: true` and produces raw HTML plus `<head>` content, with hydration markers baked in so the client runtime can later take over.

---

## 1. Purpose

The `server_runtime` module (`packages/svelte/src/internal/server/`) is the **execution environment for server-rendered Svelte components**. Unlike the client runtime, there is no signals graph, no effects and no DOM: a compiled component function is invoked **once, synchronously**, and every template expression it renders is appended as a **string chunk** into an output buffer (`Payload.out`).

Concretely, this module provides:

| Concern | Implementation |
|---|---|
| Public SSR entry point | `render(component, options)` — re-exported as `svelte/server` (`packages/svelte/src/server/index.js`) |
| Element / attribute serialization | `element()`, `attr_class()`, `attr_style()`, `spread_attributes()`, `stringify()` |
| Props, slots & snippet interop | `slot()`, `sanitize_props()`, `sanitize_slots()`, `rest_props()`, `spread_props()`, `bind_props()` |
| Store interop (legacy `$store`) | `store_get()`, `store_set()`, `store_mutate()`, `update_store()`, `update_store_pre()`, `unsubscribe_stores()` |
| Control-flow output markers | `await` (await_block), hydration `BLOCK_OPEN`/`BLOCK_CLOSE` comments |
| Output buffer & IDs | `Payload`, `HeadPayload`, `copy_payload()`, `assign_payload()`, `props_id()` |
| `{@html}` & raw snippets | `html()` (blocks/html.js), `createRawSnippet()` (blocks/snippet.js) |
| Dev-mode HTML-tree validation | `push_element()`, `pop_element()`, `validate_snippet_args()` |
| Async lifecycle coordination | `getAbortSignal()` / `abort()` — cancels stale async work between renders |
| Component context stack | integration with `push()`/`pop()` from the server context API (`context_api` module) |

---

## 2. Position in the Overall System

```
                 ┌──────────────────────────────────────────────┐
                 │  Compiler Back-End → server code generation   │
                 │  (see compiler_server_transform)              │
                 │  emits: component(payload, props) { … }       │
                 │  that calls the helpers below                 │
                 └───────────────────────┬──────────────────────┘
                                         │ imports
 ┌───────────────┐            ┌──────────▼─────────────────────────────────┐
 │  application  │  render()  │            server_runtime (this module)    │
 │  framework ───┼───────────►│  packages/svelte/src/internal/server/      │
 │  `svelte/server`           └──────────┬─────────────────────────────────┘
 └───────────────┘                       │ depends on
                     ┌───────────────────┼──────────────────────────────┐
                     ▼                   ▼                              ▼
        Cross-Runtime Platform      Reactive State Primitives        Client DOM Renderer
        (shared utils/attributes,   (store subscription utils,       (consumes hydration
         context push/pop,          snapshot/cloning)                 markers `<!--[` `]-->`
         DEV flags)                                                   at hydration time)
```

- **Upstream**: the Compiler Back-End's server transform ([compiler_server_transform.md](compiler_server_transform.md)) compiles a `.svelte` file into a component function whose template code calls `element()`, `attr_class()`, `slot()`, `await`, etc. from this module. The compiler chooses exactly these functions so the emitted code is tree-shakeable and allocation-light.
- **Entry**: `packages/svelte/src/server/index.js` re-exports only `render` — this is the entire public surface (`import { render } from 'svelte/server'`).
- **Downstream**: the HTML this module emits contains hydration anchor comments (`<!--[`, `]-->`, `<!---->`) that the **client DOM renderer** ([client_dom_renderer_dom_foundation.md](client_dom_renderer_dom_foundation.md), [client_dom_renderer_lifecycle_api.md](client_dom_renderer_lifecycle_api.md)) walks during `hydrate()`.
- **Shared services**: attribute serialization primitives (`attr`, `clsx`, `to_class`, `to_style`), DEV flags, escaping and the server context API (`push`/`pop`/`getContext`) live in the Cross-Runtime Platform Services module ([Cross-Runtime_Platform_Services_(Shared_Utilities,_Flags___Context_Injection).md](<Cross-Runtime_Platform_Services_(Shared_Utilities,_Flags___Context_Injection).md>)). Store subscription mechanics come from the store interop layer ([Reactive_State_Primitives___Store_Interop.md](Reactive_State_Primitives___Store_Interop.md)).

---

## 3. Architecture Overview

### 3.1 Sub-module map

```mermaid
graph TD
    subgraph server_runtime
        CORE["Rendering Core<br/>(internal/server/index.js)"]
        PAYLOAD["Payload & Output Model<br/>(payload.js, types.d.ts, abort-signal.js)"]
        BLOCKS["Blocks: HTML & Raw Snippets<br/>(blocks/html.js, blocks/snippet.js)"]
        DEV["Dev-mode Validation<br/>(dev.js + html-tree-validation.js)"]
    end

    ENTRY["svelte/server<br/>(src/server/index.js)"] -->|render| CORE
    CORE -->|"payload.out / payload.head"| PAYLOAD
    CORE -->|"html, createRawSnippet"| BLOCKS
    CORE -->|"push_element / pop_element /<br/>validate_snippet_args (DEV)"| DEV
    PAYLOAD -->|"AbortController"| ASYNC["async component work<br/>(await blocks, async derived)"]
    DEV -->|"HTML nesting errors"| PAYLOAD

    CTX["context_api<br/>(server/context.js push/pop)"] --> CORE
    SHARED["shared_runtime<br/>(attr, clsx, to_class, to_style,<br/>is_promise, noop, snapshot)"] --> CORE
    STORES["stores<br/>(subscribe_to_store)"] --> CORE
```

### 3.2 Render pipeline (data flow)

```mermaid
sequenceDiagram
    participant App as Application / framework
    participant R as render() (index.js)
    participant P as Payload (payload.js)
    participant C as compiled component<br/>(compiler_server_transform output)
    participant H as Payload.head (HeadPayload)

    App->>R: render(Component, { props, context, idPrefix })
    R->>P: new Payload(idPrefix) — uid generator "s1, s2, …"
    R->>R: save/swap on_destroy queue, push BLOCK_OPEN "<!--[-->"
    R->>R: (DEV) reset_elements() — isolate HTML-tree validation stack
    opt options.context
        R->>R: push() — new component context frame
    end
    R->>C: component(payload, props, {}, {})
    C-->>P: helpers append string chunks (element, attr_*, slot, await, …)
    C-->>H: <svelte:head>, <title>, CSS <style> hashes
    R->>R: pop() + run queued on_destroy callbacks
    R->>R: payload.out.join('') / payload.head.out.join('')
    R-->>App: RenderOutput { head, html, body }
    Note over R: finally: abort() — AbortController aborts any<br/>still-pending async reactions (STALE_REACTION)
```

### 3.3 The output buffer & hydration markers

Rendering is **append-only string assembly**. `Payload.out` is an array of strings; dynamic regions are fenced with comments so the client-side hydrator can find them later:

| Marker | Constant | Purpose |
|---|---|---|
| `<!--[` | `BLOCK_OPEN` (`hydration.js`) | opens an await block's pending branch / wraps whole render output |
| `]-->` | `BLOCK_CLOSE` | closes a block |
| `<!--[!` | `BLOCK_OPEN_ELSE` | opens the "else"/then branch of an await block |
| `<!---->` | `EMPTY_COMMENT` | separates adjacent text nodes and fences elements so hydration can navigate siblings |

`render()` wraps the whole component body in `BLOCK_OPEN … BLOCK_CLOSE`, appends collected CSS as `<style id="{hash}">…</style>` to the head string, and returns `{ head, html, body }` (`RenderOutput`, see `types.d.ts`). The `html` field is deprecated in favour of `body`.

---

## 4. Sub-module Documentation

Detailed documentation for each sub-module (generated from the source files):

- **[server_runtime_rendering_core.md](server_runtime_rendering_core.md)** — The heart of the module (`internal/server/index.js`): the `render()` entry point, element/attribute serialization, props/slots/snippets interop, legacy store subscription helpers, await/each/select support, and the full re-export surface consumed by compiler-generated code.
- **[server_runtime_payload_model.md](server_runtime_payload_model.md)** — The output model (`payload.js`, `types.d.ts`, `abort-signal.js`): `Payload`/`HeadPayload` string buffers, UID generation (`props_id`), payload copy/assign for legacy bindings, the `Component`/`RenderOutput` type contracts, and the module-level `AbortController` used to cancel stale async work.
- **[server_runtime_blocks.md](server_runtime_blocks.md)** — Block-level renderers (`blocks/html.js`, `blocks/snippet.js`): the `{@html …}` tag wrapper (with dev-mode content hash) and `createRawSnippet()` for programmatic snippets that append rendered strings directly to the payload.
- **[server_runtime_dev_element_validation.md](server_runtime_dev_element_validation.md)** — Dev-mode HTML-tree validation (`dev.js`): the element stack backing `push_element()`/`pop_element()`, nesting-rule enforcement via `html-tree-validation.js` (`node_invalid_placement_ssr`), render-isolation via `reset_elements()`, and `validate_snippet_args()`.

---

## 5. Cross-Module Relationships

| Related module | Relationship |
|---|---|
| `compiler_server_transform` | Generates the component functions that this module executes; every helper exported from `internal/server/index.js` is a potential call target of generated code. |
| `client_dom_renderer_dom_foundation` / `client_dom_renderer_lifecycle_api` | Consumes the hydration markers emitted here; `payload.uid()` IDs (`props_id()`) are reused client-side so SSR and CSR agree on identity. |
| `shared_runtime`, `context_api` | Supplies `attr`/`clsx`/`to_class`/`to_style` serialization, `escape_html`, `is_promise`, `noop`, `snapshot`, shared validators (`validate_dynamic_element_tag`, …) and shared errors (`await_outside_boundary`) — see the [Cross-Runtime Platform Services module](<Cross-Runtime_Platform_Services_(Shared_Utilities,_Flags___Context_Injection).md>). `push()`/`pop()` maintain the component stack (`current_component: { p, c, d, function }`); `getContext`/`setContext` on the server read/write the `c` map of the frame created by `render()`. |
| `stores` | `subscribe_to_store` powers `store_get()`; `snapshot` (shared clone) backs the exported `snapshot` — see the [Reactive State Primitives & Store Interop module](Reactive_State_Primitives___Store_Interop.md). |
| `client_dev_mode` | Mirrors dev-mode philosophy; the server equivalent is `server_runtime_dev_validation` (HTML nesting checks, `node_invalid_placement_ssr`). |

---

## 6. Key Design Notes & Invariants

1. **One-shot, allocation-free rendering** — no virtual DOM, no signals. Every "reactive" helper degrades to a plain function: `derived(fn)` memoizes via a `once()` closure, `await` renders only the pending or already-resolved branch, and `store_get` caches the last subscription in a `store_values` record (`$$store_subs`) keyed by store name.
2. **Deterministic output for hydration** — chunk boundaries (`EMPTY_COMMENT`), block markers and `props_id()` UIDs are emitted unconditionally so that client hydration can replay the exact same structure.
3. **Escaping is centralized** — attribute names are validated against the WHATWG invalid-character regex (`INVALID_ATTR_NAME_CHAR_REGEX`), functions and `$$internal` props are stripped from spreads, and values pass through `escape_html` (shared module).
4. **Render isolation** — `render()` swaps the `on_destroy` queue and (in DEV) the element-validation stack, so concurrent/nested renders cannot corrupt each other's state; `finally { abort() }` guarantees stale async reactions never leak into a subsequent render.
5. **Legacy compatibility** — `bind_props()` propagates fallback values upward for legacy two-way bindings, `copy_payload()`/`assign_payload()` support legacy slot/binding semantics, and `valueless_option()`/`maybe_selected()` reproduce `<option selected>` behaviour for `bind:value` on `<select>` during SSR.
6. **Tree-shakeability** — DEV-only paths are guarded by `DEV` from `esm-env`; production bundles drop `push_element`/`pop_element`, validation and hashed `{@html}` wrappers entirely (verified by `check-treeshakeability` build tooling).
