# Compiler Parser: Template State Machine

## 1. Introduction & Purpose

`compiler_parser_template_state_machine` is the character-level parsing engine of the Svelte compiler's **Phase 1 (`1-parse`)**. It converts raw `.svelte` template source text into an abstract syntax tree (`AST.Root`) using a **hand-written, single-pass state machine** rather than a traditional grammar-based parser generator.

A hand-written state machine is used because Svelte templates combine HTML markup, embedded expressions, and block directives in a way that is context-sensitive (e.g. `</div>` closing implicitly-opened `<p>` tags, `<script>`/`<textarea>` raw-content rules), needs precise error positions for diagnostics, and must support a **"loose" parsing mode** used by language tools / IDEs to parse incomplete, mid-typing templates without hard failures.

**Module location:** `packages/svelte/src/compiler/phases/1-parse/` (files: `index.js`, `state/fragment.js`, `state/element.js`, `state/text.js`, with supporting `state/tag.js`).

**Parent modules:** this module belongs to `compiler_parser`, which is part of the front-end pipeline documented in `Compiler_Front-End_(Parsing,_Analysis___CSS_Scoping_Pipeline)`.

### Documentation Map

| Document | Contents |
|---|---|
| [compiler_parser_template_state_machine.md](compiler_parser_template_state_machine.md) | *(this file)* Overview, architecture, pipeline context, dependency map |
| [compiler_parser_template_state_machine_engine.md](compiler_parser_template_state_machine_engine.md) | `Parser` class, `parse()` entry point, lexer primitives, state machine loop, root construction & post-parse validation |
| [compiler_parser_template_state_machine_states.md](compiler_parser_template_state_machine_states.md) | `fragment`, `element` (+ `read_attribute` / `read_static_attribute`), `text` states and the attribute/directive grammar |

## 2. Architecture Overview

### 2.1 The State Machine Model

The parser is driven by a simple yet powerful contract defined in `index.js`:

```javascript
/** @typedef {(parser: Parser) => ParserState | void} ParserState */
```

Each *state* is a function that receives the `Parser` instance, consumes zero or more characters from `parser.template`, appends AST nodes via `parser.append(...)`, and returns the **next state** (or `undefined`, which falls back to `fragment`). The `Parser` constructor runs the loop:

```javascript
let state = fragment;
while (this.index < this.template.length) {
    state = state(this) || fragment;
}
```

### 2.2 State Machine Diagram

```mermaid
stateDiagram-v2
    [*] --> fragment: parse(template, loose)

    state "fragment (dispatcher)" as fragment
    state "element" as element
    state "tag" as tag
    state "text" as text

    fragment --> element: match('<')<br/>tags, comments, closing tags
    fragment --> tag: match('{')<br/>{#block} {:next} {@special} {expr}
    fragment --> text: otherwise<br/>consume until '<' or '{'

    element --> fragment: node appended / tag closed
    tag --> fragment: chunk appended
    text --> fragment: Text node appended

    fragment --> [*]: index >= template.length
```

All three leaf states return to `fragment` (either explicitly by falling through, or implicitly via the `|| fragment` default), which re-dispatches on the next character.

### 2.3 Component Architecture

```mermaid
flowchart TB
    subgraph Engine["Engine sub-module — index.js"]
        parse["parse(template, loose)<br/>public entry point"]
        Parser["Parser class<br/>index · stack · fragments · root<br/>meta_tags · last_auto_closed_tag · ts · loose"]
        Lexer["Lexer primitives<br/>eat / match / match_regex / read<br/>read_identifier / read_until<br/>allow_whitespace / require_whitespace"]
        TreeOps["Tree operations<br/>append / pop / current"]
        parse --> Parser
        Parser --> Lexer
        Parser --> TreeOps
    end

    subgraph States["States sub-module — state/*.js"]
        fragment["fragment<br/>dispatcher"]
        element["element<br/>open/close tags · meta tags<br/>script/style/textarea · attributes"]
        tagstate["tag<br/>{#block} {:next} {@special} {expr}"]
        text["text<br/>Text nodes + entity decoding"]
        read_attr["read_attribute<br/>directives · spread · attach · shorthand"]
        read_static["read_static_attribute<br/>root-level script/style attrs"]
    end

    fragment --> element
    fragment --> tagstate
    fragment --> text
    element --> read_attr
    element --> read_static

    Engine -- "drives via state = state(this) || fragment" --> States
    States -- "append(node) / pop()" --> TreeOps
    States -- "eat/match/read" --> Lexer
```

### 2.4 Stack-Based Tree Building

Two parallel stacks mirror the AST nesting while parsing:

| Structure | Purpose |
|---|---|
| `parser.stack` | Open AST nodes awaiting a closing tag (`Root`, `RegularElement`, blocks, components…) |
| `parser.fragments` | The `Fragment` node collection that `append()` currently inserts into (element children, block bodies…) |

`create_fragment()` (from `utils/create.js`) manufactures `Fragment` nodes with `metadata.transparent/dynamic/has_await`. A new fragment is pushed when an element/block opens and popped with `parser.pop()` when it closes. `parser.current()` peeks at the top of the stack — this is how the parser knows a tag's parent context.

## 3. How It Fits Into the Compiler Pipeline

```mermaid
flowchart LR
    A[".svelte source text"] --> B["parse()<br/>(this module)"]
    B --> C["AST.Root<br/>fragment · js · css · options"]
    C --> D["Phase 2: analyze<br/>(compiler_analyzer)"]
    C --> E["Phase 3: transform<br/>(compiler_client_transform /<br/>compiler_server_transform)"]
```

- **Input:** the raw template string plus a `loose` flag.
- **Output:** an `AST.Root` node whose shape is defined by `compiler_types_template_ast` (`RegularElement`, `Component`, `IfBlock`, `Attribute`, `BindDirective`, `ExpressionTag`, …).
- **Upstream:** none — this is the compiler's front door for templates (JS/TS *inside* the template is delegated out; see §5).
- **Downstream:** the analyzer walks the produced AST (visitors in `compiler_analyzer_block_visitors` / `compiler_analyzer_template_visitors`), then the transforms generate client/server code.

The `parse()` entry also wires into global compile state: `state.set_source(template)` (from `compiler_core_state`) registers the source and a line/column locator so that every `e.*` error produced during parsing (from `compiler_diagnostics_errors`) carries an exact position and code frame.

## 4. Sub-Modules

### 4.1 Parser Engine — `compiler_parser_template_state_machine_engine.md`

> 📄 Detailed documentation: [compiler_parser_template_state_machine_engine.md](compiler_parser_template_state_machine_engine.md)

Implements the `Parser` class and the public `parse(template, loose)` entry point (`phases/1-parse/index.js`). Responsibilities:

- **Construction of `AST.Root`** — including `lang="ts"` detection via the script `lang` attribute regex, and `metadata.ts` propagation.
- **The state machine loop** — drives `fragment` → `element`/`tag`/`text` until the template is consumed.
- **Low-level lexer primitives** — `eat`, `match`, `match_regex`, `read`, `read_identifier` (with reserved-word checks), `read_until`, `allow_whitespace`, `require_whitespace`. These are the only ways states advance `parser.index`.
- **Tree assembly** — `append` / `pop` / `current` operating on the parallel `stack`/`fragments` stacks.
- **Post-loop validation** — unclosed element/block errors (`element_unclosed`, `block_unclosed` from `compiler_diagnostics_errors`), `unexpected_eof`, root `start`/`end` trimming against surrounding whitespace, and `<svelte:options>` extraction via `read_options` (see `compiler_parser_parse_utilities`).
- **Loose-mode tolerance** — e.g. `required` token errors become recoverable, unterminated input returns instead of throwing in `read_until`.

### 4.2 Template States — `compiler_parser_template_state_machine_states.md`

> 📄 Detailed documentation: [compiler_parser_template_state_machine_states.md](compiler_parser_template_state_machine_states.md)

Implements the individual states of the machine (`phases/1-parse/state/*.js`). Responsibilities:

- **`fragment` (fragment.js)** — the central dispatcher: `<` → `element`, `{` → `tag`, otherwise → `text`.
- **`element` (element.js)** — the largest state:
  - comments (`<!-- -->`), closing tags with **implicit auto-closing** of unclosed elements (via `closing_tag_omitted` HTML tree validation) and `last_auto_closed_tag` tracking;
  - `svelte:*` meta-tag resolution (`root_only_meta_tags` / `meta_tags` maps → `SvelteHead`, `SvelteWindow`, `SvelteBoundary`, …) with duplicate/placement validation;
  - node-type classification: `Component` (uppercase or dotted names), `TitleElement` (inside `svelte:head`), `SlotElement` (unless inside a declarative shadow-root template), `RegularElement`;
  - **special content rules**: top-level `<script>`/`<style>` (read via `read_script`/`read_style`, stored on `root.instance`/`root.module`/`root.css`, previous HTML comment attached for warning suppression), raw `<textarea>` content, raw `<script>`/`<style>` element content, void & self-closing tags;
  - **attribute parsing loop** with duplicate detection (`Attribute`, `BindDirective`, `StyleDirective`, `ClassDirective` keyed by type+name).
  - **loose-mode backtracking** — recovering from a mis-consumed `<` of the next tag, or `{#`/`{/`/`{@`/`{:` of the next block.
- **`read_attribute` / `read_static_attribute` (element.js)** — the attribute grammar: `{@attach}`, `{...spread}`, `{shorthand}`, directive families (`bind:`, `on:`, `class:`, `style:`, `use:`, `animate:`, `transition:`/`in:`/`out:`, `let:`) with modifiers and implicit identifier expressions, quoted/unquoted values, `Text`/`ExpressionTag` chunk sequences (`read_sequence`) and character-reference decoding.
- **`text` (text.js)** — consumes everything up to `<`/`{` and emits a `Text` node with decoded character references.
- **`tag` (tag.js)** — supporting state (dispatched from `fragment`): `{#block}` openers, `{:next}` branches, `{@special}` tags (`{@html}`, `{@const}`, …) and plain `{expression}` → `ExpressionTag`.

## 5. Dependencies & Related Modules

To avoid duplication, the following behaviours are documented in their own modules — this module only consumes them:

| Concern | Provided by | Used here for |
|---|---|---|
| JS/TS expression & script parsing | `compiler_parser_js_ts_processing` (acorn `parse_expression_at`, TypeScript node stripping) | `read_expression` inside `{…}` chunks, attributes and directives; `read_script` for `<script>` contents; `parser.acorn_error` bridging acorn failures |
| HTML character references, `<svelte:options>` reading, fuzzy name suggestions | `compiler_parser_parse_utilities` (`decode_character_references`/`get_entity_pattern`, `read_options`, `sort_descending`) | Text and attribute value decoding; root options extraction; "did you mean …" hints |
| Compile errors & warnings | `compiler_diagnostics` (`compiler_diagnostics_errors`, `compiler_diagnostics_warnings`) | `e.*` thrown from every state (`block_unclosed`, `tag_invalid_name`, `attribute_duplicate`, …), `w.element_implicitly_closed` |
| AST node shapes | `compiler_types_template_ast` (`compiler_types`) | All nodes created by the states (`AST.Root`, `AST.Fragment`, `AST.ElementLike`, directives, tags) |
| Global source registration | `compiler_core_state` | `state.set_source(template)` enabling precise error locators |
| Consumption of the AST | `compiler_analyzer` (block/template/JS visitors) | Phase 2 analysis of everything parsed here |

## 6. Key Design Notes

1. **Errors as control flow, loosely.** In strict mode, malformed input throws compile errors immediately with exact positions. In `loose` mode (language tools), states actively *backtrack* (`element.js` pops a mis-read `<name` attribute, rewinds `{#`/`{/`/`{@`/`{:` prefixes) and construct best-effort ASTs so an IDE can keep working on half-written code.
2. **Implicit HTML closing.** The parser implements real HTML rules: `<p>` inside `<p>`, `<li>` sequences, etc. auto-close the parent (warning `element_implicitly_closed`), recorded in `last_auto_closed_tag` so a later `</p>`-style tag can be validated against what was auto-closed (`element_invalid_closing_tag_autoclosed`).
3. **Context-sensitive node typing.** The same tag text becomes different AST nodes depending on the stack: `title` → `TitleElement` only under `svelte:head`; `slot` → `SlotElement` unless inside a `shadowrootmode` template; uppercase/dotted names → `Component`; `svelte:*` names → their dedicated meta node, root-only ones validated for placement/duplication.
4. **Expression metadata up front.** Every `ExpressionTag` and directive is created with `create_expression_metadata()` so Phase 2 can immediately annotate dependencies without re-shaping nodes.
5. **Performance-minded lexing.** `match` special-cases single characters, regexes are `^`-anchored against a `slice(index)` (documented requirement so matching cannot scan past the current position), and static root-level `script`/`style` attributes skip the full expression-capable grammar via `read_static_attribute`.
