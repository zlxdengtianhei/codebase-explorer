# Client Dev Mode — Runtime Instrumentation for Development

> **Module path:** `packages/svelte/src/internal/client/dev/`
> **Parent module:** [Reactive Runtime Engine (Signals, Effects & Batching with Dev-Mode Instrumentation)](client_runtime_core.md)

## 1. Introduction & Purpose

`client_dev_mode` is the **development-mode instrumentation layer** of the Svelte 5 client runtime. It is a self-contained directory of modules that are **only imported when the code runs in development** (the `DEV` flag from `esm-env` is `true`, which is set when the Svelte compiler runs with `dev: true` or the bundler replaces the `esm-env` condition). When an application is built for production, the compiler does not emit imports into this directory and tree-shaking removes it entirely from the bundle.

The module exists to give developers a safe, observable and debuggable experience that costs **nothing at runtime in production**:

| Capability | What it does for the developer |
|---|---|
| **Hot Module Replacement (HMR)** | Swap a component's implementation at runtime without losing the rendered DOM or reactive state |
| **Reactive debugging** | `$inspect` logging, `$state.trace` expression tracing, effect-tree visualization, `console.log` state snapshots |
| **Runtime validation** | Detects stale assignments, proxy-vs-raw equality mistakes, illegal mutations of parent-owned props, interrupted `bind:` chains, invalid snippet arguments, and forbidden legacy component API usage |
| **Source location tracking** | Attaches `__svelte_meta` (file/line/column) to DOM elements so browser DevTools extensions can map DOM nodes back to `.svelte` source |

Every diagnostic emitted here is backed by the runtime's [warnings and errors registries](#5-related-modules) (`internal/client/warnings.js` and `internal/client/errors.js`), and every warning carries a `https://svelte.dev/e/...` link for documentation.

## 2. Architecture Overview

The module does not implement its own reactivity model — it **observes and instruments** the core signal/effect engine (`internal/client/runtime.js`, `internal/client/reactivity/*`). The Svelte compiler's client transform (see [Compiler Back-End — Client Code Generation](compiler_client_transform.md)) is what *injects* calls into this module: when a component is compiled with `dev: true`, the emitted JavaScript imports functions from `svelte/internal/client/dev/*` and interleaves them with the compiled component code.

```mermaid
flowchart LR
    subgraph CompileTime["Compile time"]
        SRC[".svelte source"] --> CT["Client transform\n(dev: true)"]
        CT -->|"emits imports & calls"| OUT["Compiled component JS"]
    end

    subgraph Runtime["Runtime (browser)"]
        OUT --> DEV["client_dev_mode\n(this module)"]
        DEV --> CORE["Reactivity core\nsignals · effects · batching"]
        DEV --> DOM["DOM renderer\ntemplates · blocks · bindings"]
        CORE --> DOM
        DEV -->|"console.warn / throw"| DIAG["warnings.js / errors.js\nregistries"]
        BUNDLER["Bundler HMR plugin\n(vite-plugin-svelte…)"] -->|"accept → set source"| DEV
    end
```

**Key design properties:**

1. **Zero production footprint** — all entry points are only referenced from code paths guarded by `DEV` or emitted exclusively in dev compiles; the `svelte` package marks `internal/client/dev` as treeshakeable for production builds.
2. **Instrumentation, not duplication** — dev wrappers call into the same primitives the production build uses (`block`, `branch`, `source`, `inspect_effect`, `snapshot`, `untrack`), so behavior stays faithful.
3. **Fail-soft by default** — diagnostics warn (via `console.warn`) rather than throw, except for hard API violations (legacy component API, invalid snippet arguments) which throw `Svelte error`s so mistakes surface immediately.

## 3. Sub-modules

The 12 files of `internal/client/dev/` are organized into four functional sub-modules. Each has a detailed reference document generated alongside this overview:

| # | Sub-module | Files covered | Reference document |
|---|---|---|---|
| 3.1 | Hot Module Replacement (HMR) | `hmr.js`, `css.js` | [client_dev_mode_hmr.md](client_dev_mode_hmr.md) |
| 3.2 | Debugging & Introspection | `inspect.js`, `tracing.js`, `debug.js`, `console-log.js` | [client_dev_mode_debugging.md](client_dev_mode_debugging.md) |
| 3.3 | Runtime Validation & Safety | `assign.js`, `equality.js`, `ownership.js`, `validation.js`, `legacy.js` | [client_dev_mode_validation.md](client_dev_mode_validation.md) |
| 3.4 | Source Location Tracking | `elements.js` | [client_dev_mode_locations.md](client_dev_mode_locations.md) |

### 3.1 Hot Module Replacement (HMR)
**Files:** `hmr.js`, `css.js` → [client_dev_mode_hmr.md](client_dev_mode_hmr.md)

Turns every compiled component into a hot-swappable unit. `hmr()` wraps the compiled component function in a `wrapper` that reads the *current* implementation from a reactive source; a bundler plugin delivers new implementations by writing to `wrapper[HMR].source`, and a transparent `block` effect re-creates the component branch without losing anchors. `css.js` registers `<style>` elements injected by components so they can be removed when a hot update replaces the component's stylesheet (`cleanup_styles`).

### 3.2 Debugging & Introspection
**Files:** `inspect.js`, `tracing.js`, `debug.js`, `console-log.js` → [client_dev_mode_debugging.md](client_dev_mode_debugging.md)

The developer-facing observability tools:
- `inspect` — the `$inspect` rune: an `inspect_effect` that snapshots values and calls an inspector on `init`/`update`.
- `trace` / `tag` / `get_stack` — `$state.trace()` expression tracing: records every signal read during an expression evaluation, prints dependency graphs with stack traces of who created/updated each signal.
- `root` / `log_effect_tree` — prints the effect tree (root/branch/block/boundary/render/effect nodes) with dirty status, from the DevTools console.
- `log_if_contains_state` — intercepts `console.log` inside components; if an argument is reactive `$state`, it logs an unproxied **snapshot** instead of a live proxy, avoiding the classic "the console shows the *current* value, not the logged one" trap.

### 3.3 Runtime Validation & Safety
**Files:** `assign.js`, `equality.js`, `ownership.js`, `validation.js`, `legacy.js` → [client_dev_mode_validation.md](client_dev_mode_validation.md)

The guards that catch common reactive-programming mistakes:
- `assign` / `assign_and` / `assign_or` / `assign_nullish` — detect *stale* assignments (`svelte_assign` instrumentation): warn when the assignment expression evaluates to the right-hand side rather than the newly-written reactive value.
- `equals` / `strict_equals` + `init_array_prototype_warnings` — warn when `==`/`===`/`indexOf`/`includes` compare a `$state` proxy against a raw snapshot value, where identity comparison silently fails.
- `create_ownership_validator` — the `ownership_invalid_mutation` / `ownership_invalid_binding` guards: a parent's state mutated by a child, or a `bind:` chain broken mid-way, is flagged with both file locations.
- `validate_snippet_args` — throws when `{@render children(...)}` receives a non-Node anchor or non-function snippet arguments.
- `check_target` / `legacy_api` — throw `component_api_invalid_new` / `component_api_changed` when Svelte 4 patterns (`new Component()`, `instance.$set(...)`, `$on(...)`, `$destroy()`) touch a Svelte 5 component.

### 3.4 Source Location Tracking
**Files:** `elements.js` → [client_dev_mode_locations.md](client_dev_mode_locations.md)

`add_locations(fn, filename, locations)` wraps the template-construction functions emitted by the compiler so that every created element gets an `__svelte_meta = { loc: { file, line, column }, parent }` property. Hydration-aware traversal (`HYDRATION_START`/`HYDRATION_END` comments are skipped) ensures locations line up correctly on both fresh render and SSR-hydration paths. This is the data source for the Svelte browser DevTools extension.

## 4. How the Pieces Fit Together

### 4.1 Module dependency graph

```mermaid
flowchart TD
    subgraph dev["client_dev_mode (internal/client/dev)"]
        HMR["hmr.js"]
        CSS["css.js"]
        INSPECT["inspect.js"]
        TRACE["tracing.js"]
        DEBUG["debug.js"]
        CLOG["console-log.js"]
        ASSIGN["assign.js"]
        EQ["equality.js"]
        OWN["ownership.js"]
        VAL["validation.js"]
        LEG["legacy.js"]
        ELEM["elements.js"]
    end

    subgraph core["Reactivity core (internal/client)"]
        RT["runtime.js\nuntrack · get · active_reaction"]
        EFF["reactivity/effects.js\nblock · branch · inspect_effect"]
        SRCM["reactivity/sources.js\nsource"]
        PROXY["proxy.js\nget_proxied_value"]
        CTX["context.js\ncomponent_context · dev_stack"]
    end

    subgraph shared["Shared"]
        CLONE["shared/clone.js\nsnapshot"]
        CONST["constants.js\nFILENAME · HMR · HYDRATION_*"]
        WARN["warnings.js"]
        ERR["errors.js"]
    end

    HMR --> EFF & SRCM & RT & CONST
    CSS --> CONST
    INSPECT --> EFF & CLONE & RT
    TRACE --> RT & CLONE & CONST
    DEBUG --> CONST
    CLOG --> CLONE & RT
    ASSIGN --> RT & WARN
    EQ --> PROXY & WARN
    OWN --> CTX & WARN
    VAL --> ERR
    LEG --> CTX & ERR
    ELEM --> CTX & CONST
```

### 4.2 HMR component swap — runtime sequence

```mermaid
sequenceDiagram
    participant App as Application code
    participant W as wrapper (dev/hmr.js)
    participant E as block effect (reactivity/effects.js)
    participant P as HMR plugin (bundler)
    participant S as Source signal

    App->>W: wrapper(anchor, props)
    W->>E: block(..., EFFECT_TRANSPARENT)
    E->>W: read source, run branch
    W->>App: instance (getters/setters preserved)
    Note over P: developer edits .svelte file
    P->>S: source.set(NewComponent)
    S-->>E: invalidates transparent block
    E->>W: re-run → destroy old branch
    W->>E: branch(() => NewComponent(anchor, props))
    Note over W: intros disabled on swap (set_should_intro(false))
    W->>App: same instance object, new implementation
```

### 4.3 Compile-time → runtime contract

The compiler (see [Compiler Back-End](compiler_back_end.md)) and this module share strict conventions that the emitted code relies on:

| Emitted pattern (dev compile) | Dev module invoked | Purpose |
|---|---|---|
| `import * as $$_assign from 'svelte/internal/client/dev/assign'` → `$$_assign.assign(o, 'p', v, loc)` | `assign.js` | stale-assignment warning |
| `$.add_locations($.template(...), filename, [[l,c]])` | `elements.js` | `__svelte_meta` tags |
| wrapper creation with `$$hmr` boundary around the default export | `hmr.js` | hot swapping |
| `$.validate_snippet_args(anchor, ...snippets)` | `validation.js` | snippet contract |
| `$.init_array_prototype_warnings()` (bootstrap) | `equality.js` | array-method equality warnings |
| `$.ownership_validator.mutation(...)` via props proxy handlers | `ownership.js` | prop ownership rules |

## 5. Related Modules

- **[client_runtime_core](client_runtime_core.md)** — the signal/effect/batching engine this module instruments (`untrack`, `block`, `branch`, `source`, `inspect_effect`, effect flags like `CLEAN`/`DIRTY`).
- **[client_dom_renderer](client_dom_renderer.md)** — template & DOM operations whose functions are wrapped by `add_locations`; hydration markers consumed by `elements.js`.
- **[compiler_client_transform](compiler_client_transform.md)** — the compiler phase that decides whether to emit dev instrumentation (option `dev: true`) and generates the exact call sites listed above.
- **[context_api](context_api.md)** — provides `component_context` / `dev_stack` used by `ownership.js`, `legacy.js` and `elements.js` to attribute diagnostics to the running component.

## 6. Quick Reference

| File | Exports | Primary consumers |
|---|---|---|
| `hmr.js` | `hmr(original, get_source)` | compiled component wrappers, HMR plugins |
| `css.js` | `register_style`, `cleanup_styles(hash)` | compiled `<style>` handling / HMR accept handler |
| `inspect.js` | `inspect(get_value, inspector?)` | `$inspect` rune lowering |
| `tracing.js` | `trace`, `tag`, `tag_proxy`, `get_stack`, `label`, `tracing_expressions` | `$state.trace()`, signal tagging |
| `debug.js` | `root`, `log_effect_tree` | `svelte internal` debugging entry points |
| `console-log.js` | `log_if_contains_state(method, ...objs)` | compiled `console.log(...)` calls |
| `assign.js` | `assign`, `assign_and`, `assign_or`, `assign_nullish` | compiled assignments to `$state` |
| `equality.js` | `init_array_prototype_warnings`, `strict_equals`, `equals` | compiled `==`/`===`, array methods |
| `ownership.js` | `create_ownership_validator(props)` | props proxy (mutation/binding traps) |
| `validation.js` | `validate_snippet_args(anchor, ...args)` | `{@render ...}` lowering |
| `legacy.js` | `check_target`, `legacy_api()` | component instance proxies for legacy interop |
| `elements.js` | `add_locations(fn, filename, locations)` | template creation in dev compiles |
