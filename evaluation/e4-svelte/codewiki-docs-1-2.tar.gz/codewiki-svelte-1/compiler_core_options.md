# compiler_core_options — Compiler Options Validation & Normalization

## 1. Introduction

`compiler_core_options` (implemented in `packages/svelte/src/compiler/validate-options.js`) is the **options gateway of the Svelte compiler**. Every programmatic call to `compile()` or `compileModule()` passes its options object through this module before any parsing, analysis, or code generation happens. Its job is threefold:

1. **Validate** — reject unknown options and type-invalid values with precise, keypath-annotated `CompileError`s.
2. **Normalize** — fill in every declared default (e.g. `generate: 'client'`, `css: 'external'`, `dev: false`) so downstream phases can rely on a *fully populated* options object.
3. **Manage option lifecycle** — encode the Svelte 4 → 5 migration story in code: renamed options are translated with a one-time warning, deprecated options warn but keep working, and hard-removed options fail fast with actionable migration messages.

The module is a sibling of [compiler_core_entry](compiler_core_entry.md) (which calls it), [compiler_core_state](compiler_core_state.md) and [compiler_core_builders](compiler_core_builders.md) under the [compiler_core](compiler_core.md) umbrella.

### Exports

| Export | Type | Purpose |
| --- | --- | --- |
| `validate_component_options(options, keypath)` | `Validator<CompileOptions, ValidatedCompileOptions>` | Validates options for `compile()` (full component pipeline) |
| `validate_module_options(options, keypath)` | `Validator<ModuleCompileOptions, ValidatedModuleCompileOptions>` | Validates options for `compileModule()` (rune-enabled `.svelte.js`/`.svelte.ts` modules) |

Everything else in the file — the combinator library (`object`, `string`, `boolean`, `list`, `fun`, `validator`), the lifecycle handlers (`removed`, `warn_removed`, `deprecate`) and the helpers (`warn_once`, `throw_error`) — is module-private. The two exported validators are the only composition roots; the module tree lists the private pieces because they are the conceptual core components of this module.

---

## 2. Architecture Overview

### 2.1 Position in the system

```mermaid
flowchart TB
    subgraph CONSUMERS["Compiler consumers"]
        TOOLS["bundler plugins / IDE tooling / playground / runtime mount + hydrate"]
    end

    subgraph CORE["compiler_core"]
        ENTRY["compiler_core_entry<br/>compile / compileModule / parse"]
        OPTS["compiler_core_options<br/>validate-options.js (this module)"]
        STATE["compiler_core_state<br/>state.reset / warnings array"]
    end

    subgraph DIAG["compiler_diagnostics"]
        ERR["errors.js<br/>options_unrecognised · options_invalid_value · options_removed"]
        WARN["warnings.js<br/>options_deprecated_* · options_removed_* · options_renamed_ssr_dom"]
    end

    subgraph TYPES["compiler_types"]
        CT["CompileOptions / ValidatedCompileOptions<br/>ModuleCompileOptions / ValidatedModuleCompileOptions"]
    end

    PHASES["Phase 1-parse → Phase 2-analyze → Phase 3-transform"]

    TOOLS -->|"raw options"| ENTRY
    ENTRY -->|"validate_component_options(options, '')"| OPTS
    ENTRY -->|"validate_module_options(options, '')"| OPTS
    ENTRY -->|"state.reset — raw warningFilter, filename"| STATE
    OPTS -->|"throws CompileError"| ERR
    OPTS -->|"warn once"| WARN
    OPTS -.->|"input/output typed by"| CT
    OPTS -->|"ValidatedCompileOptions (defaults filled)"| ENTRY
    ENTRY -->|"validated options"| PHASES
```

### 2.2 Design: schema-as-code built from a combinator DSL

Instead of a declarative JSON schema, the option contract is expressed as a tree of *validator functions*. Each node validates one option and returns its normalized value; the root nodes are the two exported validators. This keeps defaults, type checks, migrations and diagnostics colocated in one readable literal per option.

```mermaid
flowchart TD
    subgraph PRIM["Primitive combinators"]
        VAL["validator(fallback, fn)<br/>undefined in → fallback out<br/>else fn applies"]
        STR["string(fallback, allow_empty)"]
        BOOL["boolean(fallback)"]
        LIST["list(options, fallback)"]
        FUN["fun(fallback)"]
    end

    subgraph COMPOSITE["Composite combinator"]
        OBJ["object(children, allow_unknown)"]
    end

    subgraph LIFE["Lifecycle handlers"]
        REM["removed(msg)<br/>hard CompileError"]
        WREM["warn_removed(fn)<br/>warn once · value dropped"]
        DEP["deprecate(fn, validator)<br/>warn once · value kept"]
    end

    subgraph HELP["Support utilities"]
        WO["warn_once(fn)<br/>module-level Set dedup"]
        TE["throw_error(msg)<br/>→ options_invalid_value"]
    end

    subgraph ROOTS["Exported schemas"]
        VCO["validate_component_options<br/>= object common_options + component_options"]
        VMO["validate_module_options<br/>= object common_options + component-key no-op stubs"]
    end

    STR --> VAL
    BOOL --> VAL
    LIST --> VAL
    FUN --> VAL
    VAL --> OBJ
    OBJ --> VCO
    OBJ --> VMO
    DEP --> VAL
    DEP --> WO
    WREM --> WO
    TE --> VAL
```

---

## 3. The Validator DSL

### 3.1 The validator contract

```text
Validator<Input, Output> = (input: Input, keypath: string) => Required<Output>
```

Every validator receives the **raw user value** (`undefined` when the option was omitted) and a **dotted keypath** (top level is `''`, so nested options report e.g. `experimental.async`), and returns the normalized value. The `Required<Output>` typing expresses the core invariant: *the output always contains every schema key*.

### 3.2 Primitive value validators

All primitives are built on top of the `validator(fallback, fn)` combinator: when the input is `undefined` the declared fallback is returned untouched, otherwise `fn` type-checks and returns the value.

| Combinator | Signature | Behavior on invalid input | Used for |
| --- | --- | --- | --- |
| `validator` | `(fallback, fn)` | delegates to `fn` | base of all others; also used directly for `generate`, `css`, `sourcemap` |
| `string` | `(fallback, allow_empty = true)` | `throw_error`: `"<keypath> should be a string, if specified"` (or `cannot be empty`) | `filename`, `name`, `outputFilename`, `rootDir`, `cssOutputFilename` |
| `boolean` | `(fallback)` | `throw_error`: `"<keypath> should be true or false, if specified"` | `dev`, `hmr`, `runes`, `customElement`, … |
| `list` | `(options, fallback = options[0])` | `throw_error` with a generated enumeration message (see below) | `namespace`, `fragments`, `compatibility.componentApi` |
| `fun` | `(fallback)` | `throw_error`: `"<keypath> should be a function, if specified"` | `warningFilter`, `cssHash` |

The `list` error message is grammar-aware: two options produce *"should be either "a" or "b""*; three or more produce *"should be one of "a", "b" or "c""*. Note that `compatibility.componentApi` explicitly overrides the default fallback: `list([4, 5], 5)` defaults to **5**, not the first element.

Two options bypass the type-checking primitives entirely via custom `validator(fallback, fn)` bodies:

- **`generate`** — accepts `'client'` / `'server'` / `false`, silently renames legacy `'dom'`/`'ssr'` values (with a one-time `options_renamed_ssr_dom` warning) and rejects anything else.
- **`sourcemap`** — a deliberate **passthrough**. Source maps arrive as strings, JSON, or map objects from `magic-string`/`source-map`, so no meaningful type check exists; the validator only applies the `undefined` fallback.
- **`css`** — custom fn (no fallback type check) that hard-errors on Svelte-4 booleans (`true`/`false` → use `'injected'`/`'external'`) and on `'none'`, then accepts only `'external' | 'injected'`.

### 3.3 The `object` combinator

`object(children, allow_unknown = false)` is the structural backbone. Its algorithm:

```mermaid
flowchart TD
    A["validator invoked with input + keypath"] --> B{"input truthy but not a plain object,<br/>or an Array?"}
    B -- "yes" --> X1["throw_error: keypath should be an object<br/>(options_invalid_value)"]
    B -- "no" --> C["Phase 1 — scan every key of input"]
    C --> D{"key present in schema children?"}
    D -- "no · strict mode" --> X2["e.options_unrecognised - CompileError<br/>message carries keypath.key"]
    D -- "no · allow_unknown = true" --> D1["copy raw value verbatim into output"]
    D -- "yes" --> C
    D1 --> E["Phase 2 — run every schema validator"]
    C --> E
    E --> F["output.key = children.key - validator called with<br/>input and input.key, keypath = keypath.key"]
    F --> G["return output —<br/>every schema key present, defaults applied"]
```

Key properties:

- **`undefined` input is valid** — a missing options object yields the all-defaults result (each child validator receives `undefined` and returns its fallback).
- **Unknown keys are errors** (both schemas are created in strict mode), with the offending dotted keypath in the message: `Unrecognised compiler option <keypath>`.
- **Output completeness** — because phase 2 iterates the *schema*, not the input, the returned object is always fully populated. Downstream phases never need `?? default` guards for validated options.
- **Errors are thrown, not collected** — the first problem aborts validation, so consumers see the most relevant diagnostic first.

### 3.4 Option lifecycle handlers

Three wrappers encode how an option's *era* changes its behavior:

```mermaid
flowchart TD
    START["validator receives a defined value"] --> KIND{"Option era"}
    KIND -- "active" --> CHK["type / membership check via primitives"]
    CHK -- "invalid" --> IV["throw_error → options_invalid_value"]
    CHK -- "valid" --> OK["return normalized value"]
    KIND -- "renamed: generate dom / ssr" --> RN["warn once options_renamed_ssr_dom<br/>then map dom→client · ssr→server"]
    KIND -- "deprecated: accessors · immutable" --> DEP["warn once options_deprecated_*<br/>then run inner validator — value still honored"]
    KIND -- "warn-removed: enableSourcemap ·<br/>hydratable · loopGuardTimeout" --> WREM["warn once options_removed_*<br/>value silently dropped (undefined)"]
    KIND -- "removed: legacy · format · tag ·<br/>sveltePath · errorMode · varsReport" --> REM["e.options_removed — CompileError thrown"]

    UNDEF["input is undefined"] --> FALL["return declared fallback<br/>(no warning, no error)"]
```

Semantics summary:

| Handler | Option present | Option absent | Value survives? |
| --- | --- | --- | --- |
| `deprecate(warningFn, validator)` | warn **once**, then validate normally | no warning; fallback returned | **yes** |
| `warn_removed(warningFn)` | warn **once** | no warning | **no** — dropped (`undefined`) |
| `removed(message)` | **throws** `options_removed` with the migration message | no-op | **no** |

All warning paths funnel through `warn_once(fn)`, which keys a module-level `warned` Set on the warning factory's identity (see §8 for the cross-compilation implications).

### 3.5 `throw_error`

A thin wrapper that raises `e.options_invalid_value(null, msg)` from [compiler_diagnostics](compiler_diagnostics.md). Because compiler options come from the *caller* and not from source text, all diagnostics in this module are emitted with a `null` node — they carry no code frame or source position, only the message and its `svelte.dev/e/...` documentation link.

---

## 4. The Option Schemas

### 4.1 `common_options` — shared by `compile()` and `compileModule()`

| Option | Type / Allowed values | Default | Notes |
| --- | --- | --- | --- |
| `filename` | string | `'(unknown)'` | Used for diagnostics and source-map sources |
| `rootDir` | string | `process.cwd()` (Node) / `Deno.cwd()` (Deno) / `undefined` | Cross-runtime default; replicates Svelte 4 behavior. **Evaluated once at module load** |
| `dev` | boolean | `false` | Enables dev-mode code paths and runtime assertions |
| `generate` | `'client'` / `'server'` / `false` | `'client'` | Legacy `'dom'`/`'ssr'` renamed with one-time warning; `false` = analyze-only (no output) |
| `warningFilter` | function | `() => true` | Predicate deciding which warnings survive into `CompileResult.warnings` |
| `experimental.async` | boolean (nested `object`) | `false` | Opt-in for experimental async support |

### 4.2 `component_options` — used by `validate_component_options` only

**Active options:**

| Option | Type / Allowed values | Default | Notes |
| --- | --- | --- | --- |
| `css` | `'external'` / `'injected'` | `'external'` | Booleans and `'none'` hard-error with migration guidance (Svelte 4 removal) |
| `cssHash` | function | `({ css, hash }) => \`svelte-${hash(css)}\`` | Custom hash generation for scoped-class names |
| `cssOutputFilename` | string | `undefined` | Filename reported for the emitted CSS |
| `customElement` | boolean | `false` | Emit a custom element wrapper |
| `discloseVersion` | boolean | `true` | Embed the Svelte version banner |
| `name` | string | `undefined` | Component name hint |
| `namespace` | `'html'` / `'mathml'` / `'svg'` | `'html'` | Affects runtime element creation |
| `modernAst` | boolean | `false` | Public `result.ast` shape: modern vs. legacy (see [compiler_core_entry](compiler_core_entry.md) §5) |
| `outputFilename` | string | `undefined` | Used for sourcemap names |
| `preserveComments` | boolean | `false` | Keep HTML comments in output |
| `fragments` | `'html'` / `'tree'` | `'html'` | Client template construction strategy |
| `preserveWhitespace` | boolean | `false` | Keep insignificant whitespace |
| `runes` | boolean / undefined | `undefined` (**tri-state**) | `true` forces runes mode, `false` forces legacy mode, `undefined` lets the analyzer auto-detect |
| `hmr` | boolean | `false` | Hot-module-replacement support |
| `sourcemap` | any (passthrough) | `undefined` | No type check by design (string / JSON / map object) |
| `compatibility.componentApi` | `4` / `5` | `5` | Legacy class-component API compatibility level |

**Deprecated** (warn once, value still honored — see `options_deprecated_accessors` / `options_deprecated_immutable` in [compiler_diagnostics](compiler_diagnostics.md)):

| Option | Effective type / Default |
| --- | --- |
| `accessors` | boolean, `false` — has no effect in runes mode |
| `immutable` | boolean, `false` |

**Warn-removed** (warn once, value dropped):

| Option | Warning |
| --- | --- |
| `enableSourcemap` | `options_removed_enable_sourcemap` |
| `hydratable` | `options_removed_hydratable` |
| `loopGuardTimeout` | `options_removed_loop_guard_timeout` |

**Hard-removed** (any defined value throws `options_removed` with a migration message):

| Option | Migration guidance encoded in the message |
| --- | --- |
| `legacy` | use `compatibility.componentApi` |
| `format` | Svelte 4 removed it; ESM-only output — bump your bundler plugin |
| `tag` | use `<svelte:options customElement="tag-name" />` in the component |
| `sveltePath` | open a GitHub issue if essential |
| `errorMode` | use TypeScript `verbatimModuleSyntax` (svelte-preprocess path) |
| `varsReport` | use TypeScript `verbatimModuleSyntax` (svelte-preprocess path) |

### 4.3 `validate_module_options` — derived schema

The module schema is **derived, not duplicated**:

```javascript
validate_module_options = object({
    ...common_options,
    ...Object.fromEntries(Object.keys(component_options).map((key) => [key, () => {}]))
});
```

Every component option key is replaced by a **no-op validator** that returns `undefined`. Consequences:

- Component-only options passed to `compileModule()` are *recognized but ignored* — they do **not** trigger `options_unrecognised`.
- Tooling can safely pass one shared options object to both `compile()` and `compileModule()`.
- Module compilation genuinely has no template/CSS surface; runes mode and analysis behavior are decided in `analyze_module`, not by these stubs (see [compiler_analyzer](compiler_analyzer.md)).

---

## 5. Validation in the Compilation Pipeline

### 5.1 Component compilation (`compile()`)

```mermaid
sequenceDiagram
    autonumber
    participant U as Consumer (bundler plugin)
    participant E as compile() — compiler_core_entry
    participant S as state — compiler_core_state
    participant V as validate_component_options<br/>(this module)
    participant D as compiler_diagnostics
    participant P as Parse → Analyze → Transform

    U->>E: compile(source, options)
    E->>S: state.reset — raw warningFilter, filename
    E->>V: validate_component_options(options, '')
    V->>V: common_options + component_options run per key
    alt unknown key anywhere in the tree
        V->>D: options_unrecognised(keypath)
        D--xU: CompileError thrown
    else hard-removed option (format, tag, legacy, ...)
        V->>D: options_removed(migration message)
        D--xU: CompileError thrown
    else invalid value for an active option
        V->>D: options_invalid_value(keypath + detail)
        D--xU: CompileError thrown
    else deprecated / renamed / warn-removed
        V->>D: options_deprecated_* / options_renamed_ssr_dom / options_removed_*
        D->>S: warning appended to state.warnings (first occurrence only)
    end
    V-->>E: ValidatedCompileOptions — every key populated
    E->>E: merge parsed <svelte:options> over validated options
    E->>P: phases consume the merged options
    P-->>U: CompileResult
```

Two boundary notes (details live in [compiler_core_entry](compiler_core_entry.md)):

- `state.reset()` runs **before** validation and reads the *raw* `options.warningFilter` / `options.filename`; this module is therefore not involved in the warning-filter installation.
- Options written **inside** the source (`<svelte:options>`) are parsed and merged by the entry module *after* validation; they do not pass through this schema. This module validates the **programmatic** options surface only.

### 5.2 Module compilation (`compileModule()`)

`compileModule()` follows the identical shape — `remove_bom` → `state.reset` → `validate_module_options(options, '')` → `analyze_module` → `transform_module` — but with the derived §4.3 schema. See [compiler_core_entry](compiler_core_entry.md) §4 for the phase behavior that consumes the validated result.

### 5.3 Keypath flow

Keypaths make nested diagnostics precise and are threaded through every composed validator:

- top-level call uses `''` → top-level errors name just the key (`dev should be true or false, if specified`);
- `object` children extend it (`'experimental' + '.' + 'async'` → `experimental.async should be true or false, if specified`).

---

## 6. Diagnostics Integration

All option diagnostics are produced by [compiler_diagnostics](compiler_diagnostics.md) factories; this module only decides *which* factory to call and *when*. Because options errors have no source position, every call passes `node = null` (no code frame).

| Outcome | Diagnostic | Severity | Raised when |
| --- | --- | --- | --- |
| Unknown option | `options_unrecognised` | CompileError | key not in schema (strict `object`) |
| Bad value | `options_invalid_value` | CompileError | primitive type/list checks fail, `css` booleans/`'none'`, non-object trees |
| Removed option | `options_removed` | CompileError | `legacy`, `format`, `tag`, `sveltePath`, `errorMode`, `varsReport` set |
| Deprecated option | `options_deprecated_accessors`, `options_deprecated_immutable` | Warning (once) | `accessors`, `immutable` set |
| Removed-but-soft | `options_removed_enable_sourcemap`, `options_removed_hydratable`, `options_removed_loop_guard_timeout` | Warning (once) | respective options set — value dropped |
| Renamed value | `options_renamed_ssr_dom` | Warning (once) | `generate: 'dom'` or `'ssr'` — value translated |

Warnings issued during validation are appended to the shared `state.warnings` array ([compiler_core_state](compiler_core_state.md)) and surface in `CompileResult.warnings` subject to the user's `warningFilter` — the same funnel used by every other compiler phase.

---

## 7. Dependency Map

```mermaid
graph LR
    OPTS["compiler_core_options<br/>validate-options.js"]

    OPTS --> CORE["compiler_core<br/>parent group"]
    OPTS --> ENTRY["compiler_core_entry<br/>compile / compileModule call the validators"]
    OPTS --> DIAG["compiler_diagnostics<br/>errors.js: options_unrecognised, options_invalid_value, options_removed<br/>warnings.js: options_* warnings"]
    OPTS -.-> TYPES["compiler_types<br/>CompileOptions, ValidatedCompileOptions,<br/>ModuleCompileOptions, ValidatedModuleCompileOptions"]
    OPTS -.-> STATE["compiler_core_state<br/>state.warnings receives option warnings"]
```

Dependency notes:

- **Hard imports** (only two): `./errors.js` (`options_unrecognised`, `options_invalid_value`, `options_removed`) and `./warnings.js` (`options_deprecated_accessors`, `options_deprecated_immutable`, `options_removed_loop_guard_timeout`, `options_removed_enable_sourcemap`, `options_removed_hydratable`, `options_renamed_ssr_dom`).
- **Type-only imports** from `#compiler`: the four options types that type the exported validators ([compiler_types](compiler_types.md)).
- **No phase dependencies** — this module never touches the parser, analyzer, or transforms; it is a pure pre-pipeline gate.

---

## 8. Design Notes & Edge Cases

- **Fully-populated output invariant.** Because `object` iterates the schema (not the input), the validated object contains *every* declared key even when the caller passed `{}` or `undefined`. This is why phase code can read e.g. `options.dev` without fallbacks.
- **Warn-once is process-wide, not per-compilation.** The `warned` Set lives at module scope and is keyed by warning-factory identity, so a deprecation/renaming warning fires only on the *first* compilation that triggers it. Combined with `state.reset()` clearing warnings per compilation, later results will *not* contain the warning — deliberate noise reduction for large builds, but worth knowing when asserting on `CompileResult.warnings` in tests.
- **`rootDir` default is captured at import time.** The `common_options` literal evaluates `process.cwd?.()` (Node) / `Deno.cwd()` once when the module loads, not per validation call; in non-CLI environments the fallback is `undefined`.
- **`runes` is intentionally tri-state.** `boolean(undefined)` means `undefined` is a meaningful "auto-detect" value that the analyzer resolves (see [compiler_analyzer](compiler_analyzer.md)); only explicit non-boolean values are rejected.
- **`generate: false` is analyze-only** — phases produce no code output. The source carries a TODO to eventually replace it with dedicated `analyze`/`analyzeModule` options (svelte-octane #655).
- **`css` booleans fail loudly instead of silently mapping.** Svelte 4's `css: true/false/none` throw with explicit `'injected'`/`'external'` migration text — a deliberate stricter-than-necessary error so broken builds fail at the options gate rather than producing subtly wrong CSS output ([compiler_css_pipeline](compiler_css_pipeline.md) consumes the normalized value).
- **`sourcemap` accepts anything.** Type-checking is impossible across the string/JSON/magic-string/source-map variants, so the validator is a pure fallback-application pass-through.
- **Strictness is uniform.** Both exported schemas are created without `allow_unknown`, so any misspelled option — even nested — fails immediately with its full dotted keypath rather than being ignored.

---

## 9. See Also

- [compiler_core](compiler_core.md) — parent module overview (entry, options, state, builders)
- [compiler_core_entry](compiler_core_entry.md) — the callers: how validated options merge with `<svelte:options>` and flow into the three phases
- [compiler_core_state](compiler_core_state.md) — the warnings funnel and `svelte-ignore` machinery that option warnings flow into
- [compiler_core_builders](compiler_core_builders.md) — sibling: ESTree builders for code generation
- [compiler_diagnostics](compiler_diagnostics.md) — the error/warning factories and `CompileError`/code-frame mechanics referenced throughout
- [compiler_types](compiler_types.md) — `CompileOptions`, `ValidatedCompileOptions`, `ModuleCompileOptions`, `ValidatedModuleCompileOptions` type contracts
- [compiler_analyzer](compiler_analyzer.md) — resolves the tri-state `runes` option and consumes `dev`/`generate` during analysis
- [compiler_css_pipeline](compiler_css_pipeline.md) — consumer of the normalized `css` / `cssHash` / `cssOutputFilename` options
