# Reactive State Primitives & Store Interop

**Path:** `packages/svelte/src` (subdirectories `store/` and `reactivity/`)

## Purpose

This module provides Svelte's two complementary layers of application state management:

1. **Store System (`packages/svelte/src/store`)** — a framework-agnostic implementation of the *store contract*: any object exposing a `subscribe(method) → unsubscribe` function. It supplies the classic factory helpers (`writable`, `readable`, `derived`), the synchronous `get()` accessor, and the glue that lets compiled components auto-subscribe to third-party stores (RxJS, Zustand, etc.) via the `$store` syntax in templates. This is the primary **interop** mechanism between Svelte and the wider ecosystem.

2. **Reactive Built-in Classes (`packages/svelte/src/reactivity`)** — rune-native, signal-backed wrappers around JavaScript built-ins (`SvelteMap`, `SvelteSet`, `SvelteDate`, `SvelteURL`, `SvelteURLSearchParams`). Mutation methods bump an internal version signal to invalidate dependents; read methods register dependencies with the signals runtime, giving fine-grained reactivity for standard collection/date/URL types.

Together they form the developer-facing state primitives sitting on top of the [Reactive Runtime Engine (signals, effects, batching)](packages/svelte/src/internal/client) and re-exported through the Public API Surface (`svelte/store`, `svelte/reactivity`).

## Architecture

```mermaid
flowchart TB
    subgraph publicapi["Public API Surface"]
        exports["svelte/store · svelte/reactivity<br/>(client + server entry splits)"]
    end

    subgraph stores["Store System — packages/svelte/src/store"]
        contract["Store Contract<br/>{ subscribe(fn) → unsubscribe }"]
        core["Core Factories<br/>writable · readable · derived · get"]
        interop["Interop Glue<br/>subscribe_to_store, subscriber queue,<br/>$store auto-subscription in templates"]
    end

    subgraph reactivity["Reactive Built-in Classes — packages/svelte/src/reactivity"]
        engine["create-class / utils<br/>version bump · read tracking · dev tracing"]
        collections["SvelteMap · SvelteSet"]
        temporal["SvelteDate · SvelteURL ·<br/>SvelteURLSearchParams"]
        env["index-server / index-client<br/>SSR-safe environment exports"]
    end

    runtime["Reactive Runtime Engine<br/>(signals · sources · deriveds · effects · batching)"]
    renderer["Component Rendering Backends<br/>(DOM bindings · template compilation)"]

    exports --> core
    exports --> engine
    core --> contract
    interop --> contract
    collections --> engine
    temporal --> engine
    engine --> runtime
    env --> reactivity
    renderer --> interop
    renderer --> collections
```

### Store pipeline

```mermaid
sequenceDiagram
    participant C as Compiled Component
    participant S as Store (writable/derived/external)
    participant Q as Subscriber Queue

    C->>S: subscribe(update_fn)
    S-->>C: unsubscribe function + immediate value
    S->>Q: set(value) → queued notification
    Q-->>C: update_fn(value) after microtask flush
    C->>S: unsubscribe() on destroy
```

- **Contract** — the minimal observable interface everything else builds on.
- **Core** — `writable(initial, start)` / `readable` / `derived` (multi-source, lazy start/stop) / `get` (sync read via temporary subscription).
- **Interop** — private helpers used by generated code so `$store` in markup transparently subscribes/unsubscribes to any contract-compliant store, external or built-in.

### Reactive built-in classes pipeline

```mermaid
flowchart LR
    read["Read method call<br/>(e.g. map.get(k), date.getTime())"] -->|"$.var_probe / dependency signal"| runtime["Signals runtime"]
    write["Mutation call<br/>(e.g. map.set(k,v), date.setHours())"] -->|"increment_version → invalidate"| runtime
    runtime --> effects["Deriveds & effects re-run<br/>fine-grained DOM updates"]
```

## Core Component Documentation

| Sub-module | Coverage | Docs |
|---|---|---|
| `stores` (`packages/svelte/src/store`) | Store contract, core factories (`writable`/`readable`/`derived`/`get`), and interop/auto-subscription glue | [Store System](<stores.md>) |
| `reactive_builtin_classes` (`packages/svelte/src/reactivity`) | Collection classes (`SvelteMap`, `SvelteSet`), temporal/URL primitives (`SvelteDate`, `SvelteURL`, `SvelteURLSearchParams`), and environment/SSR entry splits | [Reactive Built-in Classes](<reactive_builtin_classes.md>) |

## Related Modules

- **Reactive Runtime Engine** — the signals/effects core that both layers depend on for invalidation and batching.
- **Component Rendering Backends** — consumes store auto-subscription and reactive classes for template bindings and control flow.
- **Public API Surface & Compatibility Layer** — re-exports these primitives and hosts the legacy store-based reactive statements bridge.