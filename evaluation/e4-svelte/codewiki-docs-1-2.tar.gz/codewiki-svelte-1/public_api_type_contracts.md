# Public API Type Contracts (`public_api_type_contracts`)

> **Module:** `public_api_type_contracts`
> **Implementation file:** `packages/svelte/src/index.d.ts`
> **Parent module:** [public_api](public_api.md)
> **Core components:** `Component`, `EventDispatcher`, `Snippet`, `SvelteComponentTyped`

---

## 1. Introduction

`public_api_type_contracts` is the **linguistic contract layer** of the Svelte package. It is a
**type-declaration-only module** — it contains no runtime JavaScript — that defines *what the core
entities of the framework are* at the TypeScript level:

- **`Component`** — what a Svelte 5 component *is* (a callable function, not a class).
- **`Snippet`** — what an `{#snippet ...}` block is (a renderable function with tuple parameters).
- **`EventDispatcher`** — what `createEventDispatcher()` returns (a typed event-emitting callable).
- **`SvelteComponentTyped` / `SvelteComponent`** — what Svelte 4 *classes* looked like, kept for
  backwards-compatible typing and legacy tooling.

As the file's header comment states: *"This should contain all the public interfaces (not all of
them are actually importable, check current Svelte for which ones are)."* The module therefore acts
as the **single source of truth for the component/snippet/event type vocabulary** that is consumed
by the runtime entries, the aggregated `svelte/types` entry, the language tooling (svelte2tsx,
IDEs), and by application code everywhere.

It deliberately implements several advanced TypeScript techniques — **branded nominal types**,
**phantom typing properties**, **error-message literal return types**, and **conditional parameter
tuples** — to encode runtime rules (e.g. "snippets may only be called via `{@render}`") into the
type system itself.

---

## 2. Position in the System

The module sits at the top of the public API surface. It is type-only, and it aggregates the
client runtime entry via `export * from './index-client.js'` and pulls in global augmentations via
a side-effect import of `./ambient.js`.

```mermaid
flowchart TB
    subgraph SVELTE["svelte package — main entry surface"]
        direction LR
        TC["<b>index.d.ts</b><br/>public_api_type_contracts<br/>this module — types only"]
        CLIENT["index-client.js<br/>public_api_client_entry<br/>mount / hydrate / unmount / lifecycle"]
        SERVER["index-server.js<br/>public_api_server_entry<br/>SSR runtime entry"]
        AMBIENT["ambient.js<br/>global type augmentations — side-effect import"]
    end

    AGG["svelte/types — types/index.d.ts<br/>aggregated public .d.ts entry<br/>svelte-types module"]
    HTML["svelte-html.d.ts / elements.d.ts<br/>public_api_html_typing + svelte_element_types"]
    LEGACY["legacy-client.js / legacy-server.js<br/>legacy_compat"]
    ACTIONS["actions_and_attachments<br/>Action / Attachment contracts"]
    LANG["Language tooling — svelte2tsx, IDEs"]

    TC ==>"export * from './index-client.js'"==> CLIENT
    TC -.->|"import './ambient.js'"| AMBIENT
    AGG -->|"re-exports these contracts publicly"| TC
    LEGACY -.->|"implements ComponentType / SvelteComponent"| TC
    LANG -.->|"reads phantom fields for inference"| TC
    HTML -.->|"complementary DOM element typings"| TC
    ACTIONS -.->|"complementary extension contracts"| TC
```

**Key integration points:**

| Consumer | Relationship to this module |
|---|---|
| `packages/svelte/src/index-client.js` ([public_api_client_entry](public_api_client_entry.md)) | Re-exported by this module (`export *`); its runtime functions (`mount`, `hydrate`, `unmount`, `onMount`, `createEventDispatcher`) are *typed* by `MountOptions`, `Component`, `EventDispatcher`. |
| `packages/svelte/src/index-server.js` ([public_api_server_entry](public_api_server_entry.md)) | SSR twin of the client entry; `mount`/`hydrate` signatures use the same `Component`/`MountOptions` contracts. |
| `packages/svelte/types/index.d.ts` ([svelte-types](svelte-types.md)) | The published aggregated `.d.ts`; re-publishes `Component`, `EventDispatcher`, `Snippet`, `SvelteComponentTyped` alongside compiler API types from [compiler_types_compiler_api](compiler_types_compiler_api.md). |
| `packages/svelte/src/legacy/legacy-client.js` / `legacy-server.js` ([legacy_compat](legacy_compat.md)) | Implements the *deprecated* class-shaped contracts: `createClassComponent` / `asClassComponent` produce values typed via `ComponentType` / `SvelteComponent`. |
| Language tooling (svelte2tsx, svelte-language-server) | Reads the phantom typing fields (`$$prop_def`, `$$events_def`, `$$slot_def`, `$$bindings`, `z_$$bindings`) to generate component `.d.ts` files typed as `Component<...>`. |
| `svelte-html.d.ts` / `elements.d.ts` ([public_api_html_typing](public_api_html_typing.md), [svelte_element_types](svelte_element_types.md)) | Complementary element-level typings (`IntrinsicElements`, `SvelteHTMLElements`); independent of, but used alongside, the component contracts. |
| Compiler AST types ([compiler_types_template_ast](compiler_types_template_ast.md)) | `Snippet` is the public mirror of the compiler's `SnippetBlock` / `RenderTag` template nodes; `Component` describes the shape of the functions the back-end emits. |

---

## 3. Contract Catalog

The full type topology and its legacy / current split:

```mermaid
flowchart LR
    subgraph CURRENT["Current contracts — Svelte 5"]
        direction TB
        COMPONENT["Component&lt;Props, Exports, Bindings&gt;<br/>callable interface"]
        SNIPPET["Snippet&lt;Parameters&gt;<br/>callable interface"]
        DISPATCHER["EventDispatcher&lt;EventMap&gt;<br/>callable interface"]
        MOUNT["MountOptions&lt;Props&gt;<br/>object type"]
        PROPS["ComponentProps&lt;Comp&gt;<br/>props inference helper"]
    end

    subgraph LEGACY["Deprecated contracts — Svelte 4 compatibility"]
        direction TB
        SC["SvelteComponent&lt;Props, Events, Slots&gt;<br/>typing-only class"]
        SCT["SvelteComponentTyped<br/>deprecated empty alias"]
        CCO["ComponentConstructorOptions&lt;Props&gt;"]
        CTYPE["ComponentType&lt;Comp&gt;"]
        CEVENTS["ComponentEvents&lt;Comp&gt;"]
    end

    INTERNAL["ComponentInternals<br/>branded, opaque — unfakeable"]
    PROPSHELPER["Properties&lt;Props, Slots&gt;<br/>children backwards-compat helper"]
    COPTS["DispatchOptions<br/>cancelable flag"]
    PHANTOM["Phantom typing fields<br/>$$prop_def, $$events_def,<br/>$$slot_def, $$bindings, z_$$bindings"]

    SCT -->|"extends"| SC
    SC -->|"constructor accepts"| CCO
    CCO -->|"props widened via"| PROPSHELPER
    SC --- PHANTOM
    CTYPE -->|"describes constructor of"| SC
    CEVENTS -->|"extracts Events from"| SC
    PROPS -->|"infer over union of"| SC
    PROPS -->|"infer over union of"| COMPONENT
    COMPONENT -->|"first parameter"| INTERNAL
    DISPATCHER -->|"last parameter type"| COPTS
```

### 3.1 `Component<Props, Exports, Bindings>` — the Svelte 5 component type

```ts
export interface Component<
	Props extends Record<string, any> = {},
	Exports extends Record<string, any> = {},
	Bindings extends keyof Props | '' = string
> {
	(this: void, internals: ComponentInternals, props: Props): Exports & LegacyHooks;
	element?: typeof HTMLElement;
	z_$$bindings?: Bindings;
}
```

- **Callable interface, not a class.** A compiled Svelte 5 component is a function
  `(internals, props) => exports`. The generated back-end code (see the compiler back-end
  module documentation) conforms to this exact signature.
- **`ComponentInternals`** (see §3.2) is the opaque first argument that *only Svelte itself* may
  construct — the `this: void` + branding makes it impossible for user code to call a component
  directly.
- **`Exports`** are the component's accessible instance values (`export function foo()` etc.).
  The return type also carries optional, deprecated `$on` / `$set` hooks so Svelte 4-style
  consumers still type-check through the [legacy_compat](legacy_compat.md) helpers.
- **`Bindings`** is the phantom record of `$bindable` prop names, exposed only through
  `z_$$bindings` for language tooling. It does not exist at runtime.
- **`element?: typeof HTMLElement`** is the custom-element constructor when compiled with
  `customElement: true`.

Typical library usage (from the documentation comments):

```ts
import type { Component } from 'svelte';
export declare const MyComponent: Component<{ foo: string }>;
```

### 3.2 `ComponentInternals` and the branding machinery

```ts
declare const brand: unique symbol;
type Brand<B> = { [brand]: B };
type Branded<T, B> = T & Brand<B>;
export type ComponentInternals = Branded<{}, 'ComponentInternals'>;
```

- `ComponentInternals` is **structurally empty but nominally branded**: because the `brand` key is
  a `unique symbol`, no object literal outside this module can satisfy the type. This prevents
  application code from fabricating internals and calling component functions directly.
- This is the module's only "runtime-safety encoded in types" mechanism applied to components;
  `Snippet` uses the same trick differently (§3.7).

### 3.3 `SvelteComponent<Props, Events, Slots>` — the Svelte 4 class shape (typing only)

A class declaration kept purely so that legacy `.d.ts` output, third-party typings and the
[legacy_compat](legacy_compat.md) helpers keep compiling:

```ts
export class SvelteComponent<
	Props extends Record<string, any> = Record<string, any>,
	Events extends Record<string, any> = any,
	Slots extends Record<string, any> = any
> {
	static element?: typeof HTMLElement;
	[prop: string]: any;                       // permissive index signature
	constructor(options: ComponentConstructorOptions<Properties<Props, Slots>>);
	$$prop_def: Props;  $$events_def: Events;  $$slot_def: Slots;  $$bindings?: string;
	$destroy(): void;                          // deprecated
	$on<K extends Extract<keyof Events, string>>(type: K, cb: (e: Events[K]) => void): () => void;
	$set(props: Partial<Props>): void;         // deprecated
}
```

- All `$$*` members and the constructor are marked **"For type checking capabilities only.
  Does not exist at runtime. DO NOT USE"** — they are *phantom properties* consumed by svelte2tsx
  to infer props/events/slots from a class-typed component.
- `Slots` feeds the internal `Properties<Props, Slots>` helper (§3.5) so a default slot
  translates into a `children` prop, preserving Svelte 4 typing behaviour.
- The index signature `[prop: string]: any` mirrors Svelte 4's permissiveness but means
  `SvelteComponent` should never be used as a *base type* for new API design.

### 3.4 `SvelteComponentTyped<Props, Events, Slots>` — deprecated alias

```ts
/** @deprecated Use `Component` instead. */
export class SvelteComponentTyped<Props, Events, Slots> extends SvelteComponent<Props, Events, Slots> {}
```

An empty subclass of `SvelteComponent`. In Svelte 4 this was the *publicly recommended* base for
typed components (`class MyComponent extends SvelteComponentTyped<Props, Events, Slots>`); it now
exists only so such declarations and migration-tool output keep working.

### 3.5 `ComponentConstructorOptions` and `Properties` — legacy plumbing

```ts
/** @deprecated */
export interface ComponentConstructorOptions<Props = Record<string, any>> {
	target: Element | Document | ShadowRoot;
	anchor?: Element;        props?: Props;     context?: Map<any, any>;
	hydrate?: boolean;       intro?: boolean;   recover?: boolean;
	sync?: boolean;          idPrefix?: string; $$inline?: boolean;
}

type Properties<Props, Slots> = Props &
	(Slots extends { default: any }
		? Props extends Record<string, never> ? any : { children?: any }
		: {});
```

- `ComponentConstructorOptions` is the parameter type of the legacy `SvelteComponent`
  constructor (`target`, `hydrate`, `intro`, …) — the Svelte 4 counterpart of `MountOptions`.
- `Properties<Props, Slots>` implements the *"if there is a default slot, add `children` to the
  props"* backwards-compatibility rule. The source documents a known trade-off: when a component
  declares **no props** (`Record<string, never>`), the helper degrades to `any`, because
  TypeScript index signatures would otherwise always win and produce an unsatisfiable `children`
  type. This is an internal helper and is **not exported**.

### 3.6 Inference helpers: `ComponentProps`, `ComponentEvents`, `ComponentType`

| Helper | Status | Signature | Purpose |
|---|---|---|---|
| `ComponentProps<Comp>` | **Current** | `Comp extends SvelteComponent \| Component<any, any>` → infer `Props` | Extract the props a component expects; works for both class-shaped (Svelte 4) and function-shaped (Svelte 5) components, e.g. `const props: ComponentProps<typeof MyComponent> = { foo: 'bar' }`. |
| `ComponentEvents<Comp>` | Deprecated | `Comp extends SvelteComponent<any, infer Events>` → `Events` | Extract the Svelte 4 event map. Obsolete: Svelte 5 `Component` has no `Events` parameter; events are callback props. |
| `ComponentType<Comp>` | Deprecated | `new (options: ComponentConstructorOptions<...>) => Comp` + `element?` | "Constructor-of" type, used for `<svelte:component>` and dynamic class components in Svelte 4. Implemented at runtime by `createClassComponent` / `asClassComponent` in [legacy_compat](legacy_compat.md). |

`ComponentProps` is the bridge between the two component generations — its conditional
`Comp extends SvelteComponent<infer Props> ? Props : Comp extends Component<infer Props, any> ? Props : never`
is why one helper suffices for mixed codebases.

### 3.7 `Snippet<Parameters>` — renderable template fragments

```ts
declare const SnippetReturn: unique symbol;

export interface Snippet<Parameters extends unknown[] = []> {
	(
		this: void,
		...args: number extends Parameters['length'] ? never : Parameters
	): {
		'{@render ...} must be called with a Snippet': "import type { Snippet } from 'svelte'";
	} & typeof SnippetReturn;
}
```

Two deliberate constraints are encoded purely in types:

1. **Tuples only, no arrays.** The rest-parameter guard
   `number extends Parameters['length'] ? never : Parameters` accepts finite tuples
   (`Snippet<[{ text: string }]>`) but rejects unbounded arrays (`Snippet<string[]>`), which
   would imply an unsupported rest-parameter component API.
2. **Uncallable from TypeScript.** The return type is a branded record whose *property name is
   the error message* (`"{@render ...} must be called with a Snippet"`) and whose value tells the
   user what to import. Any direct call produces an unusable value, steering developers to the
   `{@render ...}` tag. The `SnippetReturn` unique symbol brands the result so it can never be
   structurally satisfied elsewhere.

`Snippet` is the public twin of the compiler's `SnippetBlock` / `RenderTag` AST nodes
([compiler_types_template_ast](compiler_types_template_ast.md)): the front-end parses `{#snippet}`
into those nodes; the back-end emits functions matching this interface; `{@render}` compiles to a
plain call.

### 3.8 `EventDispatcher<EventMap>` and `DispatchOptions`

```ts
interface DispatchOptions { cancelable?: boolean }

export interface EventDispatcher<EventMap extends Record<string, any>> {
	<Type extends keyof EventMap>(
		...args: null extends EventMap[Type]
			? [type: Type, parameter?: EventMap[Type] | null | undefined, options?: DispatchOptions]
			: undefined extends EventMap[Type]
				? [type: Type, parameter?: EventMap[Type] | null | undefined, options?: DispatchOptions]
				: [type: Type, parameter: EventMap[Type], options?: DispatchOptions]
	): boolean;
}
```

- **Conditional tuple parameters:** for nullable event payloads (`EventMap['e'] extends null |
  undefined`) the `parameter` argument becomes optional and may be `null | undefined` (both are
  equivalent for `CustomEvent` detail); for required payloads it is mandatory. The source notes
  `undefined extends X` (rather than `X extends undefined`) is used so it behaves identically in
  strict and non-strict mode.
- **`boolean` return:** whether the dispatched event was cancelled (`event.preventDefault()`).
- Produced at runtime by `createEventDispatcher` from both [public_api_client_entry](public_api_client_entry.md)
  and [public_api_server_entry](public_api_server_entry.md).

### 3.9 `MountOptions<Props>` — imperative instantiation contract

```ts
export type MountOptions<Props extends Record<string, any> = Record<string, any>> = {
	target: Document | Element | ShadowRoot;
	anchor?: Node;
	/** @deprecated Use callback props instead. */
	events?: Record<string, (e: any) => any>;
	context?: Map<any, any>;
	intro?: boolean; // default true
} & ({} extends Props ? { props?: Props } : { props: Props });
```

- Types `mount()` from the client and server entries ([public_api_client_entry](public_api_client_entry.md),
  [public_api_server_entry](public_api_server_entry.md)) — it is the Svelte 5 replacement for the
  deprecated `ComponentConstructorOptions`.
- **Conditional `props`:** when the component declares no props (`{} extends Props`), `props` is
  optional; otherwise it is **required**, catching prop omissions at compile time.
- `events` is deprecated in favour of callback props, mirroring the `ComponentEvents`
  deprecation.

---

## 4. Compile-Time Data Flow

The contracts never touch runtime data; they flow from authoring, through the compiler and
language tooling, back to application code:

```mermaid
flowchart TD
    SRC["Component source<br/>.svelte file with script lang=ts"]
    COMP["Svelte compiler<br/>front-end / back-end modules"]
    LANG["Language tooling<br/>svelte2tsx / IDE extensions"]
    TC["public_api_type_contracts<br/>index.d.ts"]
    JSO["Compiled JS<br/>client + server output"]
    DL["Generated component .d.ts<br/>typed as Component / Snippet / EventDispatcher"]
    APP["Application & library code"]
    RUN["Runtime entries<br/>index-client.js / index-server.js"]

    SRC --> COMP
    SRC --> LANG
    COMP -->|"emits functions that satisfy<br/>Component / Snippet signatures"| JSO
    LANG -->|"reads phantom fields,<br/>emits declarations"| DL
    APP -->|"import type { Component, ComponentProps,<br/>Snippet, EventDispatcher, MountOptions }"| TC
    DL --> APP
    APP -->|"mount(MyComponent, opts)<br/>validated against MountOptions"| RUN
    JSO --> RUN
```

Reading the diagram left-to-right:

1. **Authoring** — a `.svelte` component is simultaneously compiled (producing functions that
   *satisfy* `Component`/`Snippet` by construction) and type-extracted by svelte2tsx (producing
   declarations that *reference* these contracts).
2. **Consumption** — application code imports the types from `'svelte'` (this module, or the
   aggregated [svelte-types](svelte-types.md) entry) to type-check props, snippets and events.
3. **Instantiation** — `mount`/`hydrate` from the runtime entries receive components typed as
   `Component` and options typed as `MountOptions`.

---

## 5. Svelte 4 → Svelte 5 Contract Matrix

| Contract | Svelte 4 semantics | Svelte 5 semantics | Status |
|---|---|---|---|
| `Component` | — (no equivalent) | Primary component type: callable function `(internals, props) => exports` | ✅ Current |
| `ComponentProps<Comp>` | worked on classes | works on both shapes | ✅ Current |
| `Snippet<Parameters>` | — (slots era) | Type of `{#snippet}` blocks, rendered via `{@render}` | ✅ Current |
| `EventDispatcher<EventMap>` | `createEventDispatcher` | Still supported; new code prefers callback props | ✅ Current |
| `MountOptions` | — | Options for `mount()` (replaces `ComponentConstructorOptions`) | ✅ Current |
| `ComponentInternals` | — | Opaque branded internals parameter | ✅ Current (internal) |
| `SvelteComponent` | Real base class, primary | Typing-only shell for legacy code & tooling | ⚠️ Deprecated |
| `SvelteComponentTyped` | Recommended typed base | Empty alias of `SvelteComponent` | ⚠️ Deprecated |
| `ComponentConstructorOptions` | Constructor options | Replaced by `MountOptions` | ⚠️ Deprecated |
| `ComponentType<Comp>` | Dynamic class components | Use `Component` generics / `mount` | ⚠️ Deprecated |
| `ComponentEvents<Comp>` | Event-map extraction | No events type param in `Component`; use callback props | ⚠️ Deprecated |
| `Properties<Props, Slots>` | `children` compat via `<slot>` | Same compat rule, internal only | 🔒 Internal |

Every deprecated surface in this module points to the official v5 migration guide
(`Components-are-no-longer-classes`) in its JSDoc, so IDE hover text actively teaches the
migration path.

---

## 6. Design Techniques Reference

| Technique | Where | What it buys |
|---|---|---|
| **Branded nominal types** (`unique symbol` key) | `ComponentInternals`, `Snippet` return | Structural typing cannot fake internals; snippet results cannot be produced outside `{@render}`. |
| **Error-message literal property names** | `Snippet` return type | Compile errors carry actionable text ("must be called with a Snippet" / "import type { Snippet }"). |
| **Phantom typing properties** | `$$prop_def`, `$$events_def`, `$$slot_def`, `$$bindings`, `z_$$bindings` | Language tooling infers props/events/slots/bindables from type position only; stripped at runtime. |
| **Conditional tuple parameters** | `EventDispatcher`, `Snippet` rest guard | Optionality of event payloads; rejection of array-typed snippet parameters. |
| **Conditional required properties** | `MountOptions.props` | `props` becomes required exactly when the component declares props. |
| **Intersection-based compat widening** | `Properties<Props, Slots>` | Default-slot components accept `children` in Svelte 4 style. |
| **Side-effect ambient import** | `import './ambient.js'` | Global augmentations ship with the type entry. |
| **Star re-export of the runtime entry** | `export * from './index-client.js'` | One import path (`'svelte'`) exposes both these contracts and the client runtime's types. |

---

## 7. Maintenance Notes & Gotchas

- **Type-only module.** Nothing here survives bundling; the treeshakeability tooling
  (`scripts/check-treeshakeability.js`, see the repository infrastructure module) only concerns the
  runtime files this module re-exports.
- **Do not "use" the phantom fields.** `$$prop_def`, `$$events_def`, `$$slot_def`, `$$bindings`,
  and `z_$$bindings` are reserved for tooling. They are deliberately prefixed/named to be
  unusable and documented with "DO NOT USE".
- **`SvelteComponent`'s index signature** (`[prop: string]: any`) makes excess-property checking
  useless on legacy components — prefer `Component` + `ComponentProps` in new APIs.
- **`Component`'s default `Bindings = string`** means language tooling treats bindables as
  unconstrained unless a component narrows `Bindings extends keyof Props | ''`.
- **Ordering matters:** the side-effect `ambient.js` import must stay first so global
  augmentations apply to everything below; the `export * from './index-client.js'` must stay last
  so the type surface stays a superset of the client entry.
- **`Properties` degradation to `any`** for prop-less components with a default slot is a known,
  documented compromise — do not "fix" it without addressing TypeScript index-signature
  precedence.

---

## 8. See Also

- Parent module: [public_api](public_api.md) — the overall entry/compatibility surface
- Runtime implementations typed by these contracts:
  [public_api_client_entry](public_api_client_entry.md) ·
  [public_api_server_entry](public_api_server_entry.md)
- Published type aggregation: [svelte-types](svelte-types.md)
- Element-level typings: [public_api_html_typing](public_api_html_typing.md) ·
  [svelte_element_types](svelte_element_types.md)
- Extension contracts: [actions_and_attachments](actions_and_attachments.md) ·
  [stores](stores.md) (`Writable`) · [motion](motion.md) (`Tweened`)
- Legacy compatibility implementing the deprecated class shapes:
  [legacy_compat](legacy_compat.md)
- Compiler-side mirrors: [compiler_types_compiler_api](compiler_types_compiler_api.md) ·
  [compiler_types_template_ast](compiler_types_template_ast.md)
