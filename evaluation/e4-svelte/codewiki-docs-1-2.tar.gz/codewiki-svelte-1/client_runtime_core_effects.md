# client_runtime_core_effects

## 1. Introduction

`client_runtime_core_effects` is the **effect lifecycle engine** of Svelte's client-side reactive runtime. It is implemented almost entirely in [`packages/svelte/src/internal/client/reactivity/effects.js`](https://github.com/sveltejs/svelte/blob/main/packages/svelte/src/internal/client/reactivity/effects.js) and answers three questions for every piece of reactive work in the browser:

1. **How is reactive work represented?** — As `Effect` nodes (a `Signal` subtype) organized in a doubly-linked **effect tree** that mirrors the shape of the component/template hierarchy.
2. **How is reactive work created, ordered, and scheduled?** — Through a family of factory functions (`block`, `branch`, `render_effect`, `template_effect`, `user_effect`, `legacy_pre_effect`, …) that register effects with the [batching system](client_runtime_core_batching.md) and defer execution until a flush.
3. **How is reactive work destroyed, paused, and resumed?** — Through deterministic teardown/destroy routines, `INERT`-based pause/resume used for transitions/outros, and dedicated destroy semantics for control-flow blocks.

### Core components

| Component | Role |
|---|---|
| `block(fn, flags)` | Creates a **block effect** (`BLOCK_EFFECT`) that owns a template control-flow region (`{#if}`, `{#each}`, `{#key}`, `{#await}`, …). Re-running it destroys and rebuilds its children. |
| `legacy_pre_effect(deps, fn)` | Compiles a legacy `$:` reactive **statement** into a render effect plus a bookkeeping token, preserving Svelte 4's pre-flush ordering semantics. |
| `legacy_pre_effect_reset()` | Installs a render effect that re-runs dirty `$:` statements *after* template effects — the piece that makes legacy mode's unusual `$:` ordering correct in runes-era runtime. |

The rest of the file provides the machinery these components stand on: `create_effect` (the universal factory), the effect factories (`user_effect`, `user_pre_effect`, `effect_root`, `component_root`, `render_effect`, `template_effect`, `branch`, `async_effect`, `inspect_effect`, `teardown`), the destroy/pause/resume lifecycle, and validation helpers.

### Where this module sits

This module is a leaf family of the **Reactive Runtime Engine** and depends on its siblings — see [client_runtime_core_runtime.md](client_runtime_core_runtime.md) (signal dirtiness & execution), [client_runtime_core_batching.md](client_runtime_core_batching.md) (scheduling & flush), [client_runtime_core_signal_model.md](client_runtime_core_signal_model.md) (the `Signal` flag model), [client_runtime_core_async.md](client_runtime_core_async.md) (`flatten`, async effects), and [client_runtime_core_diagnostics.md](client_runtime_core_diagnostics.md) (effect-related errors). It is consumed from above by the **client DOM renderer** ([client_dom_renderer.md](client_dom_renderer.md)) and by code **emitted by the compiler** (see the Compiler Back-End → `compiler_client_transform` module).

---

## 2. Core Concepts

### 2.1 The `Effect` node

An effect is a `Signal` (it carries the `f` flags bitmask and `wv` write version, see [client_runtime_core_signal_model.md](client_runtime_core_signal_model.md)) plus tree/graph bookkeeping:

```mermaid
classDiagram
    class Signal {
        <<interface>>
        +number f          // flags bitmask (CLEAN, DIRTY, BLOCK_EFFECT, ...)
        +number wv         // write version for dirtiness checks
    }
    class Effect {
        +ComponentContext ctx
        +Reaction[] deps   // signals this effect depends on
        +TemplateNode nodes_start
        +TemplateNode nodes_end
        +number f
        +Effect first      // effect-tree linked list
        +Effect last
        +Effect next
        +Effect prev
        +Effect parent
        +Batch b           // batch this effect belongs to
        +Function fn       // the effect body
        +Function teardown // cleanup returned by fn
        +TransitionManager[] transitions
        +AbortController ac // async effects: stale-reaction abort
    }
    class Derived {
        +Effect[] effects  // effects captured while the derived was active
    }
    Signal <|-- Effect
    Signal <|-- Derived
    Derived o--> Effect : effects
    Effect --> Effect : parent / first / last / next / prev
```

Key invariants:

- **The effect tree is a doubly-linked list per parent** (`parent.first … parent.last`, threaded with `prev`/`next`). Traversals (batch flush, destroy, pause) walk this list iteratively — there is no recursion through children links.
- **Every effect is created with `f: type | DIRTY`** — a new effect is always considered dirty so its first execution is guaranteed.
- **INERT inheritance**: if the parent effect is `INERT` (paused), a newly created child inherits `INERT`, so no DOM work happens inside a paused/outro-ing branch.
- **Parent skipping**: if an effect ran synchronously, has no deps, no teardown, no DOM nodes, and at most a single child, `create_effect` *pushes the child instead* — keeps the tree free of bookkeeping-only nodes.

### 2.2 The flag vocabulary

`effects.js` is the primary consumer of the flag constants defined in `packages/svelte/src/internal/client/constants.js`:

| Flag | Meaning in this module |
|---|---|
| `EFFECT` | Plain effect (`$effect`, `effect()`); batched as a low-priority "effect". |
| `RENDER_EFFECT` | Pre-flush effect (`$effect.pre`, template effects); flushed before plain effects. |
| `BLOCK_EFFECT` | Control-flow region owner; re-run destroys **non-branch** children only. |
| `BRANCH_EFFECT` | A switchable branch created by `branch()`; preserved and paused/resumed instead of recreated. |
| `ROOT_EFFECT` | Independent root (`effect_root`/`component_root`); survives parent destruction. |
| `EFFECT_PRESERVED` | Not pruned from the tree even when trivial (roots, branches, async effects). |
| `USER_EFFECT` | Authored by the user (`$effect` / `$effect.pre`) — enables dev-mode naming. |
| `INSPECT_EFFECT` | `$inspect` effect; never becomes a parent in dev (skipped by `create_effect`). |
| `HEAD_EFFECT` | `<svelte:head>` content; its DOM is removed even when `destroy_effect(remove_dom=false)`. |
| `EFFECT_TRANSPARENT` | Does not create a transition boundary (`{:else if}`, transparent wrappers). |
| `ASYNC` | Async effect (`async_effect`, used by `{#await}`/async deriveds). |
| Status flags `CLEAN` / `DIRTY` / `MAYBE_DIRTY` / `DESTROYED` / `INERT` / `EFFECT_RAN` | Signal status machine shared with [client_runtime_core_runtime.md](client_runtime_core_runtime.md). |

`set_signal_status` (from the runtime module) writes only the status bits, keeping type bits intact.

---

## 3. Core Components in Detail

### 3.1 `block(fn, flags = 0)`

```js
export function block(fn, flags = 0) {
	var effect = create_effect(BLOCK_EFFECT | flags, fn, true);
	if (DEV) { effect.dev_stack = dev_stack; }
	return effect;
}
```

- **Purpose**: the mount point for every template control-flow block. The generated/blocked code calls `fn`, which reads reactive state and calls block primitives (`set_branch`, `each`, `key`, `await_block`, …) in response.
- **Sync execution**: `create_effect(..., sync = true)` runs `fn` **immediately** via `update_effect`, so the block renders during component initialization (this is why `if_block` can create branch effects on first run).
- **Re-run semantics**: on a later flush, `Batch.process` sees the block effect is dirty, and `update_effect` takes the `BLOCK_EFFECT` branch — it calls `destroy_block_effect_children`, which destroys all children **except `BRANCH_EFFECT`s**. Branches are instead paused/resumed (via `pause_effect`/`resume_effect`), letting `{#if}` toggle cheaply and outro transitions complete.
- **Dev instrumentation**: the current `dev_stack` is captured on the effect so runtime errors inside the block can be reported with the component/owner chain (see [client_dev_mode.md](client_dev_mode.md)); `update_effect` restores `effect.dev_stack ?? dev_stack` while the block runs.

Typical compiled consumer (from [client_dom_renderer.md](client_dom_renderer.md), `if_block`):

```js
block(() => {
  has_branch = false;
  fn(set_branch);            // reads the condition, may call set_branch(...)
  if (!has_branch) update_branch(null, null);
}, flags);                   // `EFFECT_TRANSPARENT` for `{:else if}`
```

### 3.2 `legacy_pre_effect(deps, fn)`

Compiles one legacy `$:` reactive **statement** that should run *before* the template updates (Svelte 4 semantics):

```js
export function legacy_pre_effect(deps, fn) {
	var context = /** @type {ComponentContextLegacy} */ (component_context);
	var token = { effect: null, ran: false, deps };
	context.l.$.push(token);
	token.effect = render_effect(() => {
		deps();                          // re-collect dependencies every run
		if (token.ran) return;           // guard: reset effect may already have run us
		token.ran = true;
		untrack(fn);                     // fn runs untracked, like classic `$:`
	});
}
```

Mechanics:

- Each `$:` statement gets a **token** `{ effect, ran, deps }` stored in the component's legacy context (`component_context.l.$`). The token is the coordination point between the statement's own render effect and the reset effect (§3.3).
- `deps()` is a compiler-generated closure that *reads* the reactive values the statement depends on, wiring the dependency graph; the actual statement body `fn` is run `untrack`ed so incidental reads don't create spurious dependencies.
- The `ran` flag makes the statement **run exactly once per invalidation**, regardless of whether the inner effect or the reset effect gets there first.

Compiled consumer (for `$: console.log(count)`):

```js
legacy_pre_effect(
	() => { count; },               // dependency collector
	() => { console.log(count); }   // statement body
);
```

### 3.3 `legacy_pre_effect_reset()`

Called once, **after** all `legacy_pre_effect` calls during component init. It installs one render effect that re-drives dirty `$:` statements:

```js
export function legacy_pre_effect_reset() {
	var context = /** @type {ComponentContextLegacy} */ (component_context);
	render_effect(() => {
		for (var token of context.l.$) {
			token.deps();
			var effect = token.effect;
			// CLEAN effects must be nudged to MAYBE_DIRTY so dependency
			// traversal actually happens:
			if ((effect.f & CLEAN) !== 0) set_signal_status(effect, MAYBE_DIRTY);
			if (is_dirty(effect)) update_effect(effect);
			token.ran = false;   // re-arm for the next invalidation
		}
	});
}
```

Why it exists: template `render_effect`s run in creation order and may invalidate `$:` statements *during* the same flush. The reset effect — being created last — runs after them, re-checking each token: if a statement's effect became dirty (or was never reached because `ran` short-circuited it), it is now updated in **dependency order rather than declaration order**, matching classic Svelte 4 `$:` behavior, and `ran` is cleared so subsequent invalidations flow through the normal dirty-checking path.

The two components form a protocol:

```mermaid
sequenceDiagram
    participant Init as Compiled component init
    participant LPE as legacy_pre_effect
    participant RT as runtime (update_effect / is_dirty)
    participant LPR as legacy_pre_effect_reset

    Init->>LPE: legacy_pre_effect(deps, fn)  // once per $: statement
    LPE->>LPE: push token {effect, ran, deps} into context.l.$
    LPE->>RT: render_effect -> deps() ; if !ran { ran=true; untrack(fn) }
    Note over RT: initial $: statements run in source order
    Init->>LPR: legacy_pre_effect_reset()  // created LAST
    LPR->>RT: render_effect -> for each token:
    RT->>RT: token.deps()
    RT->>RT: CLEAN ? set_status(MAYBE_DIRTY)
    RT->>RT: is_dirty(effect) ? update_effect(effect)
    RT->>RT: token.ran = false (re-arm)
    Note over RT: on later flushes, dirty $: statements<br/>re-run AFTER template effects
```

---

## 4. Effect Creation, Scheduling and Execution

### 4.1 The factory pipeline

All effect flavors funnel through `create_effect(type, fn, sync, push = true)`:

```mermaid
flowchart TD
    A["create_effect(type, fn, sync, push)"] --> B{"DEV: skip INSPECT_EFFECT parents<br/>inherit INERT from parent"}
    B --> C["allocate Effect: f = type | DIRTY,<br/>ctx, b = parent.b, ac = null"]
    C --> D{"sync?"}
    D -- "yes" --> E["update_effect(effect) now<br/>set EFFECT_RAN<br/>on error: destroy_effect + rethrow"]
    D -- "no (fn ≠ null)" --> F["schedule_effect(effect)"]
    E --> G{"push && trivial?"}
    F --> G
    G -- "no deps, no teardown, no DOM,<br/>single child, not EFFECT_PRESERVED" --> H["skip: use effect.first as node"]
    G -- "keep" --> I["link into parent's list (push_effect)"]
    H --> I
    I --> J{"created inside a DERIVED reaction?"}
    J -- "yes (non-root)" --> K["append to Derived.effects"]
    J -- "no" --> L["return effect"]
    K --> L
```

Flavors produced by the module:

| Factory | Flags | Sync | Typical producer |
|---|---|---|---|
| `block(fn, flags)` | `BLOCK_EFFECT \| flags` | yes | DOM blocks: `if_block`, `each`, `key`, `await_block`, `boundary`, `slot`… |
| `branch(fn)` | `BRANCH_EFFECT \| EFFECT_PRESERVED` | yes | `{#if}`/`{:else}` bodies, each-item branches |
| `render_effect(fn, flags)` | `RENDER_EFFECT \| flags` | yes | attribute/text effects, `legacy_pre_effect`, `teardown()` |
| `template_effect(fn, sync[], async[])` | `RENDER_EFFECT` | yes | dynamic attributes/text via `flatten` from [client_runtime_core_async.md](client_runtime_core_async.md) |
| `user_effect(fn)` / `create_user_effect` | `EFFECT \| USER_EFFECT` | no | compiled `$effect(...)` |
| `user_pre_effect(fn)` | `RENDER_EFFECT \| USER_EFFECT` | yes | compiled `$effect.pre(...)` |
| `effect(fn)` | `EFFECT` | no | internal low-priority effects |
| `inspect_effect(fn)` | `INSPECT_EFFECT` | yes | `$inspect` |
| `effect_root(fn)` | `ROOT_EFFECT \| EFFECT_PRESERVED` | yes | `Batch.ensure()`-scoped manual roots; returns destroy fn |
| `component_root(fn)` | `ROOT_EFFECT \| EFFECT_PRESERVED` | yes | `mount`/`hydrate` roots in [public_api](public_api.md); returns unmount fn with `outro` support |
| `async_effect(fn)` | `ASYNC \| EFFECT_PRESERVED` | yes | `{#await}`/async template work |
| `teardown(fn)` | `RENDER_EFFECT`, `CLEAN`, null fn | no | registering cleanups tied to a parent effect's lifetime |

`user_effect` has one special behavior: a **top-level `$effect` in a not-yet-mounted component** (active effect is a `BRANCH_EFFECT` that hasn't run) is *deferred* by pushing `fn` onto `component_context.e`; the renderer invokes these after mount. Everything else is created immediately.

### 4.2 Validation at creation

Every user-facing factory (`$effect`, `$effect.pre`, `$inspect`) calls `validate_effect(rune)` first, raising diagnostics from [client_runtime_core_diagnostics.md](client_runtime_core_diagnostics.md):

- `effect_orphan(rune)` — no active effect/reaction (used at module top level);
- `effect_in_unowned_derived()` — inside an unowned derived, where effects cannot be owned;
- `effect_in_teardown(rune)` — creating effects while another effect is being destroyed.

`effect_tracking()` backs `$effect.tracking()`; `aborted(effect = active_effect)` reports `DESTROYED` status and is how async work (see [client_runtime_core_async.md](client_runtime_core_async.md)) detects that its owning effect died mid-flight.

### 4.3 Scheduling and re-execution

Deferred effects (`sync = false`) are queued by `schedule_effect` (batching module), which walks **up** the parent chain, dirtying `ROOT_EFFECT`/`BRANCH_EFFECT` ancestors, and enqueues the nearest root into `queued_root_effects`. During a flush, `Batch.process` traverses the effect tree depth-first and:

```mermaid
sequenceDiagram
    participant Src as Source update (update/update_pre)
    participant Sch as schedule_effect
    participant B as Batch.process
    participant E as Effect (BLOCK/RENDER/USER)
    participant U as update_effect / update_reaction

    Src->>Sch: mark dependents dirty
    Sch->>B: enqueue root effect (queued_root_effects)
    B->>B: traverse effect tree (skip INERT & skipped_effects)
    B->>E: kind dispatch
    Note over E: EFFECT → #effects queue<br/>RENDER_EFFECT → #render_effects queue<br/>BLOCK_EFFECT → #block_effects + update now if is_dirty
    B->>U: update_effect(effect)
    U->>U: destroy(_block_)_effect_children
    U->>U: execute_effect_teardown (previous teardown)
    U->>U: update_reaction(effect) → run fn, collect deps
    U->>U: effect.teardown = returned cleanup ; effect.wv = write_version
```

Points of coupling with [client_runtime_core_runtime.md](client_runtime_core_runtime.md) and [client_runtime_core_batching.md](client_runtime_core_batching.md):

- `is_dirty` recursively brings deriveds up to date and compares `wv` versions before an effect is allowed to re-run — effects never re-run for writes they cannot observe.
- `update_effect` sets `active_effect`, restores dev stacks, destroys prior children, runs the previous teardown, then delegates to `update_reaction`, which runs `fn` under dependency tracking.
- `Batch` keeps **three ordered queues** — render effects, effects, block effects — so `$effect.pre`/template work lands before `$effect` work within one commit; block effects may be re-run on subsequent flushes to propagate internal writes (e.g. each-item state).

---

## 5. Destruction, Pause and Resume

### 5.1 Destruction

```mermaid
flowchart TD
    D["destroy_effect(effect, remove_dom = true)"] --> R{"remove_dom or HEAD_EFFECT,<br/>nodes_start..nodes_end set?"}
    R -- "yes" --> RM["remove_effect_dom via get_next_sibling<br/>(removed = true)"]
    R -- "no" --> C
    RM --> C["destroy_effect_children(effect, remove_dom && !removed)"]
    C --> C1["for each child: abort ac with STALE_REACTION<br/>(outside reactive context)"]
    C1 --> C2{"child is ROOT_EFFECT?"}
    C2 -- "yes" --> C3["detach: child.parent = null<br/>(becomes independent root)"]
    C2 -- "no" --> C4["destroy_effect(child) recursively"]
    C3 --> F["remove_reactions(effect, 0)<br/>set_status(DESTROYED)<br/>stop transitions"]
    C4 --> F
    F --> T["execute_effect_teardown:<br/>run teardown with is_destroying_effect = true,<br/>active_reaction = null"]
    T --> UL["unlink_effect: splice out of parent's list<br/>(only if parent still has children)"]
    UL --> N["null out next/prev/teardown/ctx/deps/<br/>fn/nodes/ac (DEV: component_function = null)"]
```

Block-specific destruction (`destroy_block_effect_children`) destroys all children **except `BRANCH_EFFECT`s**, because branches are reused across block re-runs (see §3.1). Note also:

- `unlink_effect` keeps the tree compact: destroyed/trivial effects are spliced out so later traversals do less work.
- Root effects are *never destroyed by their parent* — they are re-parented to `null` and owned by whoever called `effect_root`/`component_root`.
- The `ac` AbortController is aborted with the `STALE_REACTION` sentinel error, which async code can recognize (and users may ignore) via `aborted()`.

### 5.2 Pause / resume (transitions & outros)

When a branch is toggled off, it is not destroyed immediately — outro transitions may need it alive:

```mermaid
flowchart TD
    OFF["branch toggled off"] --> P["pause_effect(effect, callback)"]
    P --> PC["pause_children: XOR-in INERT flag,<br/>collect TransitionManagers<br/>(EFFECT_TRANSPARENT/BRANCH children keep locality)"]
    PC --> Q{"transitions.length > 0?"}
    Q -- "yes" --> O["run_out_transitions: countdown via transition.out(check)"]
    O --> DEST["destroy_effect after last outro completes"]
    Q -- "no" --> DEST
    ON["branch toggled on again"] --> RES["resume_effect"]
    RES --> RC["resume_children: XOR-out INERT,<br/>recurse through transparent/branch children"]
    RC --> DQ{"effect not CLEAN?"}
    DQ -- "yes" --> SCH["set DIRTY + schedule_effect<br/>(catch up updates missed while paused)"]
    DQ -- "no" --> TR["run transition.in() for owned transitions"]
    SCH --> TR
```

This is exactly what `if_block` in the DOM renderer uses (`resume_effect(active)` / `pause_effect(inactive, …)`, coordinating with `Batch.skipped_effects` when appends are deferred). `component_root` uses the same machinery to support `unmount(component, { outro })` from the public API.

---

## 6. Module Dependencies

### 6.1 Import graph

```mermaid
flowchart LR
    subgraph effects["client_runtime_core_effects (effects.js)"]
        direction TB
        CORE["block · legacy_pre_effect · legacy_pre_effect_reset<br/>create_effect · factories · destroy/pause/resume"]
    end

    RT["client_runtime_core_runtime<br/>update_effect · is_dirty · get · remove_reactions<br/>set_signal_status · active_effect/reaction · untrack"]
    BAT["client_runtime_core_batching<br/>Batch.ensure · schedule_effect"]
    ASY["client_runtime_core_async<br/>flatten (template_effect async values)"]
    SIG["client_runtime_core_signal_model<br/>Signal interface · flags (constants)"]
    CTX["context_api<br/>component_context · dev_current_component_function · dev_stack"]
    DOM["client_dom_renderer<br/>get_next_sibling (DOM removal) · without_reactive_context (abort)"]
    SHU["shared_runtime<br/>define_property"]
    DIAG["client_runtime_core_diagnostics<br/>effect_orphan · effect_in_unowned_derived · effect_in_teardown"]
    DEV["client_dev_mode / esm-env<br/>DEV branches: naming, dev_stack, component_function"]

    SIG --> CORE
    RT --> CORE
    BAT --> CORE
    ASY --> CORE
    CTX --> CORE
    DOM --> CORE
    SHU --> CORE
    DIAG --> CORE
    DEV --> CORE
```

### 6.2 Dependency table

| Import | From module | Used for |
|---|---|---|
| `update_effect`, `is_dirty`, `get`, `set_signal_status`, `remove_reactions`, `active_effect`, `active_reaction`, `set_active_reaction`, `is_destroying_effect`, `set_is_destroying_effect`, `untrack`, `untracking` | [client_runtime_core_runtime.md](client_runtime_core_runtime.md) | executing effects, dirtiness checks, status transitions, dependency unlinking, teardown context |
| `Batch`, `schedule_effect` | [client_runtime_core_batching.md](client_runtime_core_batching.md) | `Batch.ensure()` for roots, deferring effects until flush |
| `flatten` | [client_runtime_core_async.md](client_runtime_core_async.md) | `template_effect` sync/async value resolution |
| flag constants (`DIRTY`, `BLOCK_EFFECT`, `INERT`, …), `STALE_REACTION` | [client_runtime_core_signal_model.md](client_runtime_core_signal_model.md) | the effect type/status bitmask |
| `component_context`, `dev_current_component_function`, `dev_stack` | [context_api.md](context_api.md) | component scoping of effects, legacy `$` token storage, dev attribution |
| `get_next_sibling`, `without_reactive_context` | [client_dom_renderer.md](client_dom_renderer.md) | removing an effect's DOM range; aborting stale async effects outside tracking |
| `define_property` | [shared_runtime.md](shared_runtime.md) | naming `fn` as `'$effect'`/`'$effect.pre'` in dev |
| `e.effect_orphan` / `effect_in_unowned_derived` / `effect_in_teardown` | [client_runtime_core_diagnostics.md](client_runtime_core_diagnostics.md) | misuse diagnostics |
| `DEV` | `esm-env` | compile-time dev instrumentation gates |

### 6.3 Consumers

- **Compiler-emitted code** — the client transform (see `compiler_client_transform` in the Compiler Back-End module) emits `block`, `branch`, `render_effect`, `template_effect`, `user_effect`, `user_pre_effect`, `inspect_effect`, `effect_root`, `component_root`, `legacy_pre_effect`, and `legacy_pre_effect_reset` calls directly into generated components.
- **DOM blocks & elements** — `if_block`, `each`, `key`, `await_block`, `boundary`, `slot`, `svelte-head`, attribute/bindings code call `block`, `branch`, `render_effect`, `template_effect`, `pause_effect`, `resume_effect`, `destroy_effect` (see [client_dom_renderer.md](client_dom_renderer.md)).
- **Render entry points** — `mount`/`hydrate`/`unmount` in the public API wrap components in `component_root` and use `pause_effect` for `outro` unmounting.

---

## 7. Interaction Patterns

### 7.1 Block re-run (control-flow update)

```mermaid
sequenceDiagram
    participant S as Signal write (e.g. condition flag)
    participant B as Batch flush
    participant BE as block effect
    participant BR as branch effect (kept)

    S->>B: invalidate dependents
    B->>BE: is_dirty? yes → update_effect
    BE->>BE: destroy_block_effect_children<br/>(branches survive)
    BE->>BE: execute_effect_teardown
    BE->>BR: re-run block fn → set_branch toggles
    BR->>BR: pause_effect(old branch, run outros)<br/>resume_effect(new branch)
    Note over BR: DOM swaps may be deferred<br/>into the batch commit callbacks
```

### 7.2 Async effects and stale reactions

`create_effect` stores an `AbortController` slot (`ac`). Async effect bodies (e.g. inside `{#await}`/`async_derived`) obtain it and, when the effect is destroyed or its block re-runs, `destroy_effect_children` aborts the controller with `STALE_REACTION` **outside** any reactive context (`without_reactive_context`), so in-flight `await`s can detect abandonment via `aborted()` / the signal's reason. This is the glue between this module and [client_runtime_core_async.md](client_runtime_core_async.md) / the `boundary` block.

### 7.3 Effects created inside deriveds

If `create_effect` runs while `active_reaction` is a `DERIVED` (possible for root-effect work spawned during derived evaluation), the effect is additionally registered on `Derived.effects`. The deriveds module ([client_runtime_core_deriveds.md](client_runtime_core_deriveds.md)) uses that list to destroy such effects when the derived itself is destroyed — preventing leaks when unowned deriveds are recomputed.

---

## 8. Invariants & Design Notes

1. **One factory, many flavors.** Every effect type differs only by flags; behavior is entirely flag-driven downstream (batch queues, destroy rules, pause/resume locality).
2. **Sync effects run during creation** (blocks, render effects) so that DOM structure exists when the component initializer returns; deferred effects (`$effect`) always wait for the next batch, and top-level ones wait for mount.
3. **Tree hygiene.** Trivial effects are skipped when pushing (`push_effect` optimization), destroyed effects are unlinked, and fields are nulled — keeps flush/destroy traversals O(live effects) and aids GC.
4. **Branches are assets, not garbage.** `BRANCH_EFFECT | EFFECT_PRESERVED` effects survive block re-runs and are pause/resumed — the basis of cheap `{#if}` toggling and correct outros.
5. **Teardown is part of the run.** `update_effect` always destroys children and runs the previous teardown *before* re-running `fn`, so effect bodies can assume a fresh child tree every run.
6. **Legacy compatibility is explicit.** `legacy_pre_effect`/`legacy_pre_effect_reset` implement Svelte 4 `$:` ordering (declaration-order first run, dependency-order re-runs after template effects, untracked bodies) on top of the runes-era signal engine; they are only emitted in legacy mode and tree-shake away otherwise.
7. **Destruction order matters.** DOM removal → child destruction → reaction unlinking → `DESTROYED` status → transition stops → teardown → unlink → null-out; aborts use `STALE_REACTION` and never run inside a tracked context.
8. **Dev-mode data rides on effects.** `dev_stack` (blocks), `component_function` (all effects) enable precise error attribution and are stripped/nullified outside `DEV`.

---

## 9. Related Modules

| Module | Relationship |
|---|---|
| [client_runtime_core_runtime.md](client_runtime_core_runtime.md) | Executes effects (`update_effect`, `update_reaction`), owns dirtiness (`is_dirty`, `write_version`) and the status machine this module manipulates. |
| [client_runtime_core_batching.md](client_runtime_core_batching.md) | Schedules and flushes effects created here; owns `Batch.process` traversal, queues and commit callbacks. |
| [client_runtime_core_signal_model.md](client_runtime_core_signal_model.md) | Defines the `Signal` contract and flag constants (`BLOCK_EFFECT`, `INERT`, …) this module builds on. |
| [client_runtime_core_sources.md](client_runtime_core_runtime.md) / [client_runtime_core_deriveds.md](client_runtime_core_deriveds.md) | Upstream producers of invalidations; deriveds receive effects created while they were active. |
| [client_runtime_core_async.md](client_runtime_core_async.md) | `flatten` powers `template_effect`; async effects/AbortController protocol defined here. |
| [client_runtime_core_props.md](client_runtime_core_props.md) / [client_runtime_core_stores.md](client_runtime_core_stores.md) | Heavy users of `render_effect`/`user_effect` for prop and store synchronization. |
| [client_runtime_core_diagnostics.md](client_runtime_core_diagnostics.md) | Effect misuse errors and `svelte_boundary` warnings surfaced through `validate_effect`. |
| [client_dom_renderer.md](client_dom_renderer.md) | Primary consumer: blocks, bindings, transitions drive their DOM through the factories and pause/resume API defined here. |
| [client_dev_mode.md](client_dev_mode.md) | Dev instrumentation data (`dev_stack`, `component_function`) attached to effects. |
| [context_api.md](context_api.md) | Provides `component_context` (effect scoping, legacy `$` tokens, deferred `$effect` queue). |
| Compiler Back-End → `compiler_client_transform` | Emits calls to the factories documented here into every compiled client component. |
