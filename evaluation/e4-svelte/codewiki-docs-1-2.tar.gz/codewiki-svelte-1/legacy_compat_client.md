# legacy_compat_client

> **Source:** `packages/svelte/src/legacy/legacy-client.js`
> **Module tree position:** `Public API Surface & Compatibility Layer` → `legacy_compat` → **`legacy_compat_client`**

## 1. Introduction

`legacy_compat_client` is the **client-side legacy compatibility adapter** of Svelte 5. It bridges the gap between the **Svelte 4 imperative component API** (class components constructed with `new`, mutated through `$set`, observed through `$on`, disposed with `$destroy`) and the **Svelte 5 runtime** (function components mounted on a fine-grained signal graph).

Every export in this module is marked `@deprecated` and is intentionally scoped as a **temporary migration aid** — it exists so that applications and libraries written against Svelte 4 keep working while their code is incrementally migrated to runes-based Svelte 5 idioms.

The module provides five concerns:

| Concern | Export | Emulates (Svelte 4) |
|---|---|---|
| Imperative instantiation of runes components | `createClassComponent(options)` | `new Component({ target, props, ... })` |
| Adapting a runes component into a class | `asClassComponent(component)` | Passing a class component where a component is expected |
| `$:` reactive statements | `run(fn)` | Legacy top-level reactive blocks (`$effect.pre` semantics + recursion guard) |
| Multi-handler events with modifiers | `handlers(...handlers)` | `on:event` forwarding of several listeners |
| `on:event` bubbling (handler-less directives) | `createBubbler()` | `on:click` without a handler bubbling to the parent |
| Event modifiers | re-exports of `once`, `preventDefault`, `self`, `stopImmediatePropagation`, `stopPropagation`, `trusted`, `passive`, `nonpassive` | `on:click\|preventDefault` etc. |

Its server-side mirror is documented in [legacy_compat_server](legacy_compat_server.md); together they form the `legacy_compat` layer of the [public_api](public_api.md) surface. On the browser, the module is the implementation behind the `svelte/legacy` entry point (selected via the package's `browser`/`node` export conditions — the `node` condition resolves to `legacy-server.js` instead).

---

## 2. Architecture Overview

The module is a pure **adapter**: it owns no reactivity or DOM logic of its own. It reconstructs Svelte 4 semantics *on top of* the client runtime:

```mermaid
flowchart TB
    subgraph consumers["Svelte 4-style consumers"]
        A1["Imperative app code:<br/>new Component(...), $set, $on, $destroy"]
        A2["Legacy-mode compiled components:<br/>$: statements, on:event|modifier, bubble()"]
    end

    subgraph adapter["legacy_compat_client"]
        B1["createClassComponent"]
        B2["asClassComponent"]
        B3["Svelte4Component<br/>(internal adapter class)"]
        B4["run"]
        B5["handlers"]
        B6["createBubbler"]
        B7["event modifiers (re-exports)"]
    end

    subgraph runtime["Reactive Runtime Engine (client_runtime_core)"]
        C1["Signals: mutable_source / set / get"]
        C2["Effects: user_pre_effect"]
        C3["Batching: flushSync"]
        C4["Runtime core: active_effect, set_signal_status,<br/>DIRTY / MAYBE_DIRTY flags"]
    end

    subgraph renderer["Client DOM Renderer (client_dom_renderer)"]
        D1["mount / hydrate"]
        D2["unmount"]
    end

    subgraph platform["Cross-Runtime Platform Services"]
        E1["Flags: async_mode_flag"]
        E2["Context: component_context"]
        E3["Diagnostics: client errors / warnings"]
    end

    A1 --> B1
    A1 --> B2
    A2 --> B4
    A2 --> B5
    A2 --> B6
    A2 --> B7

    B1 --> B3
    B2 --> B3
    B3 --> C1
    B3 --> D1
    B3 --> D2
    B3 --> C3
    B3 --> E1
    B4 --> C2
    B4 --> C4
    B4 --> E3
    B6 --> E2
    B6 --> E3
```

**Key architectural decisions:**

1. **Everything funnels through one adapter class.** Both public factories (`createClassComponent`, `asClassComponent`) delegate to the internal `Svelte4Component` class, which is the only place where Svelte 4 lifecycle semantics are reconstructed.
2. **Coarse-grained props via a custom Proxy.** Svelte 4 props were "version-bumped" as a whole; Svelte 5 props are fine-grained signals. The adapter wraps props in a hand-rolled `Proxy` with *one mutable source (signal) per property* — deliberately **not** the `$state` proxy, because `$state` provides fine-grained reactivity that would not reproduce legacy update semantics.
3. **Events piggyback on the internal event bus.** `$on` writes into the `$$events` record carried by the props proxy — the exact record that compiled components read via the [context_api](context_api.md) (`component_context.s.$$events`), which is also what `createEventDispatcher` and `createBubbler` consume.
4. **Legacy effects reuse modern primitives.** `run` is implemented as a `user_pre_effect` (`$effect.pre`) with a post-execution dirty-check that downgrades re-dirtied effects to `MAYBE_DIRTY`, reproducing legacy recursion behavior without an infinite loop.

---

## 3. Core Components

### 3.1 `createClassComponent(options)`

Factory wrapper around `new Svelte4Component(options)`. Accepts the same options as a Svelte 4 component constructor (`target`, `anchor`, `props`, `context`, `hydrate`, `intro`, `recover`) plus a `component` field that may be either a compiled Svelte 5 component *function* or a legacy `ComponentType<SvelteComponent>`.

```js
import { mountable } from './App.svelte';
import { createClassComponent } from 'svelte/legacy';

const app = createClassComponent({
  component: mountable,      // runes component function
  target: document.body,
  props: { count: 0 }
});
app.$set({ count: 1 });      // Svelte 4 API works
```

### 3.2 `asClassComponent(component)`

Returns a **class** extending `Svelte4Component` whose constructor pre-binds the given component function. Use this when a *class* is structurally required (e.g. a base class, a framework expecting a constructor, or `new` on an imported component):

```js
import App from './App.svelte';
import { asClassComponent } from 'svelte/legacy';

const AppClass = asClassComponent(App); // behaves like a Svelte 4 class component
const app = new AppClass({ target: el });
```

### 3.3 `Svelte4Component` (internal adapter class)

The heart of the module. Not exported directly; both factories return it.

| Member | Visibility | Behavior |
|---|---|---|
| `#events` | private | Reference to the `props.$$events` record; backing store for `$on`. |
| `#instance` | private | Exports object returned by `mount()`/`hydrate()` for the wrapped component. |
| `constructor(options)` | public | Builds the props proxy, mounts/hydrates, optionally flushes synchronously, exposes instance exports as accessors, installs `$set`/`$destroy`. |
| `$set(props)` | public | `Object.assign(props, next)` against the proxy — triggers per-property signal updates (coarse-grained propagation). |
| `$on(event, callback)` | public | Registers a wrapped callback into `#events[event]` (with `this` bound to the instance) and returns an **unsubscribe** function. |
| `$destroy()` | public | Delegates to `unmount(#instance)` from the renderer lifecycle API. |

The typedef `LegacyComponentType` (exported for tooling) describes the dual nature the adapter satisfies: *callable as a mount function* and *constructable as a class* — mirroring how Svelte 5 component functions double as constructors during the transition period.

### 3.4 `run(fn)`

Legacy `$:` statement support. Compiled legacy components call `run(fn)` for each reactive block. Implementation strategy:

1. Wraps `fn` in a **`user_pre_effect`** — i.e. it runs immediately and re-runs before the component re-renders whenever its dependencies change (matching `$effect.pre` / Svelte 4 pre-render semantics).
2. After `fn()` returns, inspects the `active_effect`: if running `fn` synchronously re-dirtied it (`DIRTY` flag set), Svelte 4 would have recursed. Svelte 5 instead **downgrades the effect to `MAYBE_DIRTY`** so it re-runs on the next flush rather than recursing inline. In dev mode, a `legacy_recursive_reactive_block` warning is emitted first, attributed to the component's source file via `dev_current_component_function[FILENAME]`.

This mirrors the legacy effect helpers (`legacy_pre_effect`, `legacy_pre_effect_reset`) provided by [client_runtime_core_effects](client_runtime_core_effects.md).

### 3.5 `handlers(...handlers)`

Composes multiple event listeners into a single `EventListener`, replicating Svelte 4's multi-handler forwarding:

- Intercepts `event.stopImmediatePropagation` with a wrapper that also raises a local `stopped` flag (the original still executes, so browser-level semantics are preserved).
- Executes handlers in registration order; a handler that throws does **not** prevent later handlers — errors are collected.
- When iteration ends (or `stopImmediatePropagation` fires), each collected error is re-thrown **asynchronously** via `queueMicrotask(() => { throw error; })`, preserving stack behavior without breaking the batch.

### 3.6 `createBubbler()`

Factory that reproduces Svelte 4's handler-less `on:click` bubbling. Must be called during component initialisation (`component_context` must be active, otherwise the `lifecycle_outside_component` error is thrown). It returns `bubble(type)`, which returns an event listener that:

1. Reads the `$$events[type]` handlers from the **captured** component context's props record (`component_context.s`),
2. Invokes each registered callback with `this` set to the component's exports (`component_context.x`),
3. Returns `!event.defaultPrevented` (or `true` when no handlers are registered).

This is the same dispatch path used by `createEventDispatcher` — see [context_api](context_api.md) and [public_api_client_entry](public_api_client_entry.md).

### 3.7 Re-exported event modifiers

`once`, `preventDefault`, `self`, `stopImmediatePropagation`, `stopPropagation`, `trusted`, `passive`, `nonpassive` are re-exported from `internal/client/dom/legacy/event-modifiers.js` (see [client_dom_renderer_elements_and_events](client_dom_renderer_elements_and_events.md)). They implement the Svelte 4 `on:event|modifier` semantics as higher-order functions (`modifier => handler => wrapped handler`) and are consumed by the compiler output for legacy-mode components (see [compiler_client_transform_components_and_scripts](compiler_client_transform_components_and_scripts.md)).

---

## 4. Instantiation Data Flow

```mermaid
sequenceDiagram
    participant App as Svelte 4 app code
    participant API as createClassComponent /<br/>asClassComponent
    participant C as Svelte4Component
    participant P as props Proxy
    participant R as mount() / hydrate()
    participant B as flushSync()

    App->>API: options { component, target, props, context, hydrate?, ... }
    API->>C: new Svelte4Component(options)
    C->>P: create Proxy({ ...props, $$events: {} })
    Note over P: each key lazily gets a mutable_source<br/>(per-property signal)
    C->>R: (options.hydrate ? hydrate : mount)(component, { target, props, context, intro, recover })
    R-->>C: instance exports
    C->>B: flushSync() unless async mode / custom-element host / opted out
    C->>C: define enumerable accessors for each exported key (except $set/$on/$destroy)
    C->>C: install $set = (next) => Object.assign(props, next)<br/>install $destroy = () => unmount(instance)
    C-->>App: Svelte 4-compatible instance

    App->>C: $set(next)
    C->>P: Object.assign — set() each affected signal
    App->>C: $on(event, cb)
    C->>P: push wrapped cb into props.$$events[event]
    C-->>App: unsubscribe()
    App->>C: $destroy()
    C->>R: unmount(instance)
```

Hydration is delegated entirely to `render.js::hydrate` (finding the `HYDRATION_START` anchor, mismatch recovery, etc.) — see [client_dom_renderer_lifecycle_api](client_dom_renderer_lifecycle_api.md). Custom-element wrappers follow a different path (`create_custom_element`, `$$host` in props) and are described in [client_dom_renderer_elements_and_events](client_dom_renderer_elements_and_events.md).

---

## 5. Detailed Process Flows

### 5.1 Props proxy — coarse-grained legacy reactivity

```mermaid
flowchart TD
    A["Trap invoked: get / has / set"] --> B{"Signal exists<br/>for this key?"}
    B -- "no" --> C["add_source(key, value):<br/>mutable_source(value, false, false)<br/>stored in sources Map"]
    B -- "yes" --> D["reuse existing signal"]
    C --> E{"Which trap?"}
    D --> E
    E -- "get" --> F["return get(signal)<br/>registers reactive dependency"]
    E -- "has" --> G{"key === LEGACY_PROPS?"}
    G -- "yes" --> H["return true —<br/>suppresses 'invalid binding'<br/>validation on component side"]
    G -- "no" --> I["get(signal) then<br/>Reflect.has(target, prop)"]
    E -- "set" --> J["set(signal, value) —<br/>propagates update to component<br/>— then Reflect.set"]
```

Notes:

- `mutable_source` is used with `safe_equals` (mutable, non-strict) and *not* auto-registered for legacy `beforeUpdate`/`afterUpdate` tracking, because the adapter manages coarse-grained updates itself.
- The `LEGACY_PROPS` marker (from `internal/client/constants.js`) makes the props object identifiable to dev-time binding validation; it links this adapter with the props machinery described in [client_runtime_core_props](client_runtime_core_props.md).

### 5.2 `run(fn)` — legacy reactive statement semantics

```mermaid
flowchart TD
    A["run(fn) called by legacy compiled code"] --> B["user_pre_effect: create effect<br/>(RENDER_EFFECT + USER_EFFECT, runs immediately)"]
    B --> C["fn() executes"]
    C --> D{"Effect flagged DIRTY<br/>(fn re-triggered it synchronously)?"}
    D -- "no" --> E["done — effect re-runs later only<br/>when dependencies change"]
    D -- "yes" --> F{"DEV mode?"}
    F -- "yes" --> G["warn legacy_recursive_reactive_block<br/>(filename from dev_current_component_function)"]
    F -- "no" --> H
    G --> H["set_signal_status(effect, MAYBE_DIRTY)<br/>— re-run deferred to next flush,<br/>no synchronous recursion"]
```

### 5.3 `handlers(...)` — multi-handler dispatch with deferred errors

```mermaid
flowchart TD
    A["combined handler(event)"] --> B["wrap event.stopImmediatePropagation<br/>to raise local stopped flag"]
    B --> C["iterate handlers in order"]
    C --> D{"handler throws?"}
    D -- "yes" --> E["collect error; continue"]
    D -- "no" --> F["continue"]
    E --> G{"stopped by any handler?"}
    F --> G
    G -- "no, handlers remain" --> C
    G -- "yes or exhausted" --> H["for each error:<br/>queueMicrotask(() => { throw error })"]
```

### 5.4 `createBubbler()` — event bubbling to `$$events`

```mermaid
flowchart TD
    A["createBubbler() during component init"] --> B{"component_context active?"}
    B -- "no" --> C["throw lifecycle_outside_component"]
    B -- "yes" --> D["capture active_component_context"]
    D --> E["bubble(type) returns listener"]
    E --> F["read captured context.s.$$events type"]
    F --> G{"handlers registered?"}
    G -- "no" --> H["return true"]
    G -- "yes" --> I["invoke each callback with<br/>this = context.x (instance exports)"]
    I --> J["return !event.defaultPrevented"]
```

---

## 6. `Svelte4Component` Class Model

```mermaid
classDiagram
    class Svelte4Component {
        -events : Record~string, Function[]~ (#events)
        -instance : ComponentExports (#instance)
        +constructor(options)
        +$set(props) void
        +$on(event, callback) Function
        +$destroy() void
    }
    class LegacyComponentType {
        <<typedef>>
        +new(options) SvelteComponent
        +call(args) ComponentExports
    }
    class createClassComponent {
        <<deprecated factory>>
    }
    class asClassComponent {
        <<deprecated factory>>
        +constructor binds component
    }

    createClassComponent ..> Svelte4Component : constructs
    asClassComponent ..> Svelte4Component : subclass of
    Svelte4Component ..> LegacyComponentType : satisfies shape
```

Exported-instance accessors: every key on the mounted instance except `$set` / `$on` / `$destroy` becomes an enumerable getter/setter on the wrapper, delegating to `#instance[key]`. This reproduces Svelte 4's behavior where `const c = new Comp(); c.exportedValue` and `c.someMethod()` work directly.

---

## 7. Dependency Map

| Dependency (imported) | Source module | Used for |
|---|---|---|
| `mutable_source`, `set` | `internal/client/reactivity/sources.js` | Per-prop signals in the props proxy ([client_runtime_core_sources](client_runtime_core_sources.md)) |
| `get`, `active_effect`, `set_signal_status` | `internal/client/runtime.js` | Reactive reads; `run` dirty-flag inspection ([client_runtime_core](client_runtime_core.md)) |
| `user_pre_effect` | `internal/client/reactivity/effects.js` | `run` effect creation ([client_runtime_core_effects](client_runtime_core_effects.md)) |
| `flushSync` | `internal/client/reactivity/batch.js` | Synchronous first paint after mount ([client_runtime_core_batching](client_runtime_core_batching.md)) |
| `DIRTY`, `MAYBE_DIRTY`, `LEGACY_PROPS` | `internal/client/constants.js` | Signal status flags; legacy-props marker |
| `mount`, `hydrate`, `unmount` | `internal/client/render.js` | Component lifecycle ([client_dom_renderer_lifecycle_api](client_dom_renderer_lifecycle_api.md)) |
| `component_context`, `dev_current_component_function` | `internal/client/context.js` | Bubbler context capture; dev warning attribution ([context_api](context_api.md)) |
| `async_mode_flag` | `internal/flags/index.js` | Gate for `flushSync` ([shared_runtime](shared_runtime.md)) |
| `define_property`, `is_array` | `internal/shared/utils.js` | Accessor definition; handler-array checks |
| `* as e` / `* as w` | `internal/client/errors.js`, `warnings.js` | `lifecycle_outside_component`; `legacy_recursive_reactive_block` |
| `DEV`, `FILENAME` | `esm-env`, `src/constants.js` | Dev-only warning enrichment |
| Event modifiers | `internal/client/dom/legacy/event-modifiers.js` | Re-exported `on:event\|modifier` helpers |

---

## 8. Behavioral Constraints & Gotchas

1. **All APIs are deprecated.** They exist solely to unblock migration; new code should use runes components mounted via `mount`/`hydrate` directly ([public_api_client_entry](public_api_client_entry.md)).
2. **Coarse-grained, not fine-grained.** `$set` updates per-property signals, but propagation semantics intentionally mimic Svelte 4's coarser invalidation — do not expect runes-level dependency precision for legacy-wrapped components.
3. **Synchronous flush rules.** After mount, `flushSync()` is invoked so the first render is applied synchronously (Svelte 4 behavior) — *unless* (a) the async-mode flag is enabled (`flushSync` is disallowed inside effects / async mode), (b) the mount is a custom-element wrapper (`$$host` present in props), or (c) the caller opted out (`sync: false`). See [client_runtime_core_batching](client_runtime_core_batching.md).
4. **`$on` callbacks get instance `this`.** Callbacks are wrapped so `this` inside handlers is the adapter instance, matching Svelte 4; the returned function removes only that exact wrapped callback.
5. **Reserved `$` methods.** `$set`, `$on`, `$destroy` are excluded from the exported-accessor scan; instance exports with these names cannot be surfaced through the adapter.
6. **`run` never recurses synchronously.** The `DIRTY → MAYBE_DIRTY` downgrade trades Svelte 4's synchronous recursive re-run for a deferred re-run; dev builds surface this as a warning naming the offending file.
7. **Bubbler captures creation context.** `createBubbler` snapshots `component_context` when called; the returned `bubble` keeps working after initialisation but dispatches into the creating component's `$$events`. Calling `createBubbler` outside component initialisation throws.
8. **Error deferral in `handlers`.** Handler exceptions are intentionally re-thrown in microtasks, so `try/catch` around event dispatch will not observe them; rely on `window.onerror`/unhandled rejection reporting.

---

## 9. Relationship to Other Modules

```mermaid
flowchart LR
    LC["legacy_compat_client<br/>(this module)"] --- LS["legacy_compat_server<br/>(SSR mirror: _render, asClassComponent)"]
    LC --> PUB["public_api<br/>(svelte/legacy entry)"]
    LC --> CTX["context_api<br/>(component_context, $$events dispatch)"]
    LC --> CRT["client_runtime_core<br/>(signals, effects, batching)"]
    LC --> CDR["client_dom_renderer<br/>(mount / hydrate / unmount)"]
    LC --> CMP["compiler_client_transform_components_and_scripts<br/>(legacy-mode generated code calls run / handlers / modifiers)"]
    LC --> DEV["client_dev_mode<br/>(legacy_api, check_target — dev-only legacy surface)"]
```

- **[legacy_compat_server](legacy_compat_server.md)** — the SSR twin: exposes `asClassComponent` (shared concept) and `_render`, which renders the component to `{ html, head, css }` without DOM. Choosing between the two is done by package export conditions.
- **[client_runtime_core_signal_model](client_runtime_core_signal_model.md)** — signal/derived model the adapter's per-prop sources plug into.
- **[public_api_type_contracts](public_api_type_contracts.md)** — `Component`, `SvelteComponentTyped`, `ComponentConstructorOptions` types used in this module's JSDoc signatures.

## 10. Quick Reference

| Export | Signature | Since | Status |
|---|---|---|---|
| `createClassComponent` | `(options: ComponentConstructorOptions & { component }) => SvelteComponent & Exports` | Svelte 5 | `@deprecated` — migration shim |
| `asClassComponent` | `(component) => ComponentType<SvelteComponent & Exports>` | Svelte 5 | `@deprecated` — migration shim |
| `run` | `(fn: () => void \| (() => void)) => void` | Svelte 5 | `@deprecated` — replaces `$:` |
| `handlers` | `(...handlers: EventListener[]) => EventListener` | Svelte 5 | `@deprecated` |
| `createBubbler` | `() => (type: string) => (event: Event) => boolean` | Svelte 5 | `@deprecated` |
| modifiers | `once`, `preventDefault`, `self`, `stopImmediatePropagation`, `stopPropagation`, `trusted`, `passive`, `nonpassive` | Svelte 5 | `@deprecated` re-exports |