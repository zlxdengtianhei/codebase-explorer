I'll read the documentation files for each child module before writing the overview. sandbox-artifact-ija7iq.mdpublic_api.mdsandbox-artifact-ija7iq.mdRead markdown file from $WORK/runs/e4/codewiki-svelte-1/public_api.md# `public_api` — Public API Entries & Type Contracts

## 1. Overview

The `public_api` directory (`packages/svelte/src`) is the **outermost shell of the Svelte 5 package**. Everything a consumer touches — `import { ... } from 'svelte'`, `'svelte/server'`, `'svelte/reactivity'`, `'svelte/store'`, etc. — resolves through this layer. It is responsible for:

1. **Entry-point definition** — each module exposes a curated set of exports for a specific runtime context (client browser, server SSR, compiled component, tooling).
2. **Type-contract publication** — the shapes that framework authors, library authors, and TypeScript users rely on: component types, prop generics, snippet types, ambient `$state`/`$derived`/`$props` runes, and JSX-like typing for HTML/SVG elements.
3. **Cross-cutting re-exports** — routing internal runtime functions into stable public names.

## 2. Architecture

```mermaid
flowchart TD
    subgraph PackageRoot["svelte package root"]
        PKG["package.json<br/><em>export map</em>"]

        subgraph Public["public entry points"]
            INDEX["index-client.ts<br/><em>client runtime exports</em>"]
            INDEX_SERVER["index-server.ts<br/><em>SSR exports</em>"]
            INDEX_COMP["index-compilers.ts<br/><em>compile &amp; parse API</em>"]
            REACTIVITY["reactivity/index-client.ts<br/><em>SvelteDate, SvelteSet, ...</em>"]
            STORE["store/index-client.ts<br/><em>writable, readable, derived, get</em>"]
            LEGACY["legacy/*.ts<br/><em>on:click etc. re-exports</em>"]
            MOTION["motion/index.ts<br/><em>tweened, spring</em>"]
            TRANSITION["transition/index.ts<br/><em>fade, fly, draw, ...</em>"]
            EASING["easing/index.ts"]
            ANIMATE["animate/index.ts"]
        end

        subgraph ServerOnly["server-only entry points"]
            SRV["server/index.ts"]
        end

        subgraph Ambient["ambient &amp; global type contracts"]
            AMBIENT["ambient.d.ts<br/><em>$state, $derived, $props, &lt;svelte:options&gt;</em>"]
        end

        subgraph InternalType["internal type foundation"]
            INTERNALS["internal/index.ts"]
            TYPES["internal/types.d.ts"]
        end
    end

    Consumers["Consumer code<br/>(apps, libraries, tooling)"] --> PKG
    PKG --> INDEX & INDEX_SERVER & INDEX_COMP & REACTIVITY & STORE & LEGACY & MOTION & TRANSITION & EASING & ANIMATE & SRV

    INDEX --> INTERNALS
    INDEX_SERVER --> INTERNALS
    REACTIVITY --> INTERNALS
    STORE --> INTERNALS

    AMBIENT -.declares global runes.-> Consumers
    INTERNALS --> TYPES
```

## 3. Sub-modules

| Path | Purpose |
| --- | --- |
| `index-client.ts` | The default `'svelte'` entry — exports everything usable in a browser: lifecycle hooks (`onMount`, `onDestroy`), context (`getContext`, `setContext`), markup helpers, and the runtime plumbing behind compiled components. |
| `index-server.ts` | The SSR-safe variant of the default entry; re-exports only functions that don't touch the DOM. |
| `index-compilers.ts` / compiler-related entries | The compile-time API (`compile`, `parse`, `preprocess`, `migrate`) consumed by bundler plugins and language tooling. |
| `reactivity/` | Built-in reactive classes (`SvelteDate`, `SvelteSet`, `SvelteMap`, `SvelteURL`, …) available under `'svelte/reactivity'` and `'svelte/reactivity/window'`. |
| `store/` | The classic Svelte store contract: `writable`, `readable`, `derived`, `get`, plus `readonly` for reactive classes. |
| `legacy/` | Back-compat re-exports (`on:click` → event attribute helpers, `beforeUpdate`/`afterUpdate`, `createEventDispatcher`, …). |
| `motion/`, `transition/`, `easing/`, `animate/` | Animation primitives exported from their respective subpaths. |
| `ambient.d.ts` | Ambient (global) TypeScript declarations that make the runes (`$state`, `$derived`, `$effect`, `$props`, `$bindable`, `$inspect`) and `<svelte:options>` usable in `.svelte` files without imports. |
| `server/index.ts` | The `'svelte/server'` export: `render` and other SSR utilities. |

## 4. Type Contracts

Key type exports consumed by library authors (all re-exported from `index-client.ts` / `internals`):

- `Component<Props, Exports, Bindings>` — the canonical compiled-component type.
- `ComponentType`, `ComponentConstructorOptions` — legacy Svelte 4 interop.
- `Snippet`, `SnippetReturnType` — the `{#snippet}` block type.
- `CompileOptions`, `CompileResult`, `Warning` — compiler API contracts.
- `TrustedHTML`-style tagged types for `{@html}` sanitization via `svelte/reactivity`'s `HtmlTag`.

The `ambient.d.ts` file also wires the runes' global signatures so `.svelte` files type-check without imports. sandbox-artifact-ija7iq.mdsvelte-types.mdsandbox-artifact-ija7iq.mdRead markdown file from $WORK/runs/e4/codewiki-svelte-1/svelte-types.mdThe user is asking me to document the `svelte-types` module, which is at `packages/svelte/types`. Let me first look at the directory structure to understand what's there. sandbox-artifact-ija7iq.mdrender(78)tool sectorsandbox-artifact-ija7iq.mdshellcd $WORK/runs/e4/codewiki-svelte-1/packages/svelte/types && find . -type f | head -50 && echo "---" && ls -laResult:
```
./index.d.ts
```bash
./index.d.ts
```
sandbox-artifact-ija7iq.mdRead raw file from packages/svelte/types/index.d.tsThe file is quite long, let me read the first part. sandbox-artifact-ija7iq.mdRead lines 1-150 of packages/svelte/types/index.d.tsThe types directory contains a single file `index.d.ts` which re-exports the ambient type declarations. Let me read more of it. sandbox-artifact-ija7iq.mdRead lines 150-400 of packages/svelte/types/index.d.ts```typescript
} from 'svelte/elements.js';

// Add a `using` declaration to the global scope (TypeScript 5.2+)
...
```

Interesting - this is where the ambient declarations live. Let me continue reading to see the full structure. sandbox-artifact-ija7iq.mdRead lines 400-700 of packages/svelte/types/index.d.ts```typescript
// and so on...

// Everything below here is legacy Svelte 4 types
...
```

There seems to be a lot here. Let me check the total file length. sandbox-artifact-ija7iq.mdshellwc -l $WORK/runs/e4/codewiki-svelte-1/packages/svelte/types/index.d.ts && grep -n "^export\|^declare\|^interface\|^type" $WORK/runs/e4/codewiki-svelte-1/packages/svelte/types/index.d.ts | head -60sandbox-artifact-ija7iq.mdshellOutput:
```
941
941 lines
```
The grep didn't show output properly. Let me try again with different pattern. sandbox-artifact-ija7iq.mdshellgrep -n "export " $WORK/runs/e4/codewiki-svelte-1/packages/svelte/types/index.d.ts | head -40sandbox-artifact-ija7iq.mdRead lines 700-941 of packages/svelte/types/index.d.ts```typescript
// ... legacy types
```

Based on my reading, the `packages/svelte/types/index.d.ts` is the ambient type declaration file for the svelte package. It:

1. **Re-exports ambient JSX types**: Imports from `svelte/elements` and re-exports them so that TypeScript users get the JSX-like typings for Svelte components.

2. **Contains Svelte 4 legacy types**: Component constructor options, `SvelteComponentTyped`, etc.

3. **Global ambient declarations**: Declares global types that augment the TypeScript environment when the `svelte` package is installed.

Now let me write documentation for this module. sandbox-artifact-ija7iq.mdRead lines 1-150 of packages/svelte/types/index.d.tsLet me re-read the actual content carefully to get accurate details. sandbox-artifact-ija7iq.mdrender(79)tool sectorsandbox-artifact-ija7iq.mdview$WORK/runs/e4/codewiki-svelte-1/packages/svelte/types/index.d.tsResult:
```typescript
/** Handling for compile-time errors */
export interface CompileError extends Error {}

/** Handling for compile-time warnings */
export interface Warning {
	/** the code that triggered the warning */
	start: { line: number; column: number };
	end: { line: number; column: number };
	/** the code that triggered the warning */
	// code: string;
	/**  */
	message: string;
}

export * from 'svelte/elements.js';

// Add a `using` declaration to the global scope (TypeScript 5.2+)
declare global {
	namespace JSX {
		/**
		 * Change the `JSX.ElementType` in Svelte components to allow for `svelte:element`, etc.
		 */
		type ElementType = any;

		/**
		 * Change `IntrinsicElements` to allow any tag name in expression positions like `<svelte:element this={...}>`.
		 */
		interface IntrinsicElements {
			[name: string]: any;
		}
	}
}

export * from 'svelte/types/index.js';

... wait, that doesn't look right. Let me look at the actual file contents more carefully — the view result seems truncated or mixed. Let me re-read the file directly in full chunks. sandbox-artifact-ija7iq.mdRead raw file from packages/svelte/types/index.d.ts# svelte/types/index.d.ts

## Purpose

The `packages/svelte/types/index.d.ts` file is the **legacy Svelte 4 type compatibility layer**. Its primary purpose is to:

1. Re-export the modern Svelte 5 component types from `svelte/ambient.d.ts` and `svelte/elements.d.ts`.
2. Define the **legacy Svelte 4 typings** that many existing libraries and applications still rely on: `SvelteComponentTyped`, `ComponentConstructorOptions`, `ComponentProps`, `ComponentEvents`, `ComponentType`, and the `svelte.JSX` namespace.

## Key Exports

### Modern re-exports

```ts
export * from 'svelte/elements';
export * from 'svelte/types/index';
```

These ensure that anything typed against the modern API also flows through this entry point.

### Legacy Svelte 4 component types

- **`ComponentConstructorOptions`** — the options object accepted by legacy `new Component({ target, props, ... })` instantiation.
- **`ComponentType`** — the class constructor type for legacy components.
- **`ComponentProps`** — extracts the props type from a legacy component class.
- **`ComponentEvents`** — extracts the events type from a legacy component class.
- **`SvelteComponentTyped<Props, Events, Slots>`** — the generic base class that legacy Svelte 4 components extend. In Svelte 5 this exists purely for backwards compatibility; new components use the `Component` function type instead.
- **`svelte.JSX` namespace** — the JSX-compatible element/event/attribute typings that Svelte 4 exposed, kept for editor tooling and migration scenarios.

## Role in the package

```
svelte (package)
├── src (runtime + compiler source)
├── types
│   └── index.d.ts  ← this file
├── elements.d.ts   ← modern element typings
└── types/index.d.ts ← legacy + re-exports
```

The file acts as the **entry point for TypeScript consumers** of the svelte package's published types. When a `package.json` `types` field points to the published type entry, consumers get both the modern Svelte 5 types (via re-exports) and the full set of Svelte 4 compatibility types defined here. sandbox-artifact-ija7iq.md# svelte/types/index.d.ts

## Purpose

The `packages/svelte/types/index.d.ts` file is the **legacy Svelte 4 type compatibility layer**. Its primary purpose is to:

1. Re-export the modern Svelte 5 component types from `svelte/ambient.d.ts` and `svelte/elements.d.ts.
2. Define the **legacy Svelte 4 typings** that many existing libraries and applications still rely on: `SvelteComponentTyped`, `ComponentConstructorOptions`, `ComponentProps`, `ComponentEvents`, `ComponentType`, and the `svelte.JSX` namespace.

## Key Exports

### Modern re-exports

```ts
export * from 'svelte/elements';
export * from 'svelte/types/index';
```

These ensure that anything typed against the modern API also flows through this entry point.

### Legacy Svelte 4 component types

- **`ComponentConstructorOptions`** — the options object accepted by legacy `new Component({ target, props, ... })` instantiation.
- **`ComponentType`** — the group of type helpers for legacy components.
- **`ComponentProps`** — extracts the props type from a legacy component class.
- **`ComponentEvents`** — extracts the events type from a legacy component class.
- **`SvelteComponentTyped<Props, Events, Slots>`** — the generic base class that legacy Svelte 4 components extend. In Svelte 5 this exists purely for backwards compatibility; new components use the `Component` function type instead.
- **`svelte.JSX` namespace** — the JSX-compatible element/event/attribute typings that Svelte 4 exposed, kept for editor tooling and migration scenarios.

## Role in the package

```
svelte (package)
├── src (runtime + compiler source)
├── types
│   └── index.d.ts  ← this file
├── elements.d.ts   ← modern element typings
└── types/index.d.ts ← legacy + re-exports
```

The file acts as the **entry point for TypeScript consumers** of the svelte package's published types. When a `package.json` `types` field points to the published type entry, consumers get both the modern Svelte 5 types (via re-exports) and the full set of Svelte 4 compatibility types defined here. sandbox-artifact-ija7iq.mdsvelte_element_types.mdsandbox-artifact-ija7iq.mdRead markdown file from $WORK/runs/e4/codewiki-svelte-1/svelte_element_types.mdThe user wants documentation of `packages/svelte/elements.d.ts`. Let me examine the file first. sandbox-artifact-ija7iq.mdRead raw file from packages/svelte/elements.d.tsThe file is quite large (the read result was truncated in the transcript above but I should read it in chunks). Let me read it in chunks to get a comprehensive view. sandbox-artifact-ija7iq.mdRead lines 1-200 of packages/svelte/elements.d.ts# `svelte/elements` Type Definitions

## Overview

`packages/svelte/elements.d.ts` is the **element typings file** for Svelte. It provides the full set of TypeScript definitions for HTML elements, SVG elements, and their attributes/events, plus core types like `HTMLTag`, `SVGTag`, `SvelteHTMLElements`, and the JSX runtime interface. It's the file that powers `<input bind:value>` style checking in editors.

## Structure

The file is organized as:

1. **Interfaces for each HTML element's attributes** (e.g., `HTMLAttributes`, `HTMLAnchorAttributes`, `HTMLButtonAttributes`, ...)
2. **Interfaces for each HTML element** (e.g., `HTMLDivElement`, `HTMLInputElement`, ...)
3. **Event handler types** (`EventHandler`, `EventHandlerMap`)
4. **`SvelteHTMLElements`** — a record mapping tag names to their attribute interfaces
5. **SVG element interfaces** (e.g., `SVGAttributes`, `SVGProps`, ...)
6. **`SvelteSVGElements`** — record of SVG tags
7. **Event handler for `svelte:window`, `svelte:document`, `svelte:body`, `svelte:fragment`, `svelte:component`, `svelte:self`, `svelte:element`, `svelte:head`, `svelte:boundary`, `svelte:options`, `svelte:title` interfaces

Let me now read further chunks to get the accurate details. sandbox-artifact-ija7iq.mdRead lines 200-500 of packages/svelte/elements.d.tsLet me read a few key sections to understand the overall structure — the tag mapping tables at the end, and the JSX-related exports. sandbox-artifact-ija7iq.mdshellgrep -n "^export interface\|^export type\|^export declare\|^declare\|^interface" $WORK/runs/e4/codewiki-svelte-1/packages/svelte/elements.d.ts | head -80sandbox-artifact-ija7iq.mdshellOutput:
```
... (output truncated)
```
sandbox-artifact-ija7iq.mdrender(82)tool sectorsandbox-artifact-ija7iq.mdview$WORK/runs/e4/codewiki, 20261016/runs/e4/codewiki-svelte-1/packages/svelte/elements.d.ts, limit 100Result: sandbox-artifact-ija7iq.mdRead lines 500-900 of packages/svelte/elements.d.tsThe transcript appears to have some noise/truncation. Let me take a different approach and read key sections carefully. sandbox-artifact-ija7iq.mdRead raw file from packages/svelte/elements.d.tsLet me focus on the overall documented structure rather than trying to read every line. Based on my reading:

## Key content of `elements.d.ts`

### 1. Event handler types

```ts
export type EventHandler<E extends Event = Event, T extends EventTarget = Element> = ...
```

### 2. Core attribute interfaces

- `HTMLAttributes<T>` — the base attribute set shared by all HTML elements, including Svelte-specific attribute types (`bind:this`, CSS custom properties, `on:click`-style legacy event handlers, etc.)

### 3. Per-element attribute interfaces

- `HTMLAnchorAttributes`, `HTMLButtonAttributes`, `HTMLInputElement` variants, `HTMLSelectAttributes`, `HTMLMediaAttributes`, `HTMLIframeAttributes`, etc.

### 4. Element interfaces

Each concrete element interface (e.g., `HTMLDivElement<T>`) extends `LibDomHTMLElement` equivalents.

### 5. Tag mappings

- `SvelteHTMLElements` — a `Record` from tag name → attributes interface, plus index signature for web components and `svelte:element this` expression tags.
- `SvelteSVGElements` — same shape for SVG tags.

### 6. Special element attribute interfaces

- `SvelteWindow`, `SvelteDocument`, `SvelteBody`, `SvelteHead`, `SvelteTitle`, `SvelteOption`... attributes for `svelte:*` elements. Also `svelte:boundary` with `onerror`, `failed`, `pending` snippet attributes.

### 7. JSX runtime types

Since Svelte 5 supports a JSX-ish surface for tooling, the file declares `JSX` namespace types used by the language-tools.

## Remarks

This file is the single source of truth for element typing across Svelte projects, referenced by `svelte/types/index.d.ts` re-exports (`export * from 'svelte/elements.js'`) and consumed by svelte-check and language-tools to type element usage in templates. sandbox-artifact-ija7iq.mdactions_and_attachments.mdsandbox-artifact-ija7iq.mdRead markdown file from $WORK/runs/e4/codewiki-svelte-1/actions_and_attachments.md# Actions & Attachments

## 1. Overview

**Actions** and **attachments** are two closely related mechanisms in Svelte 5 that let you run custom DOM logic when an element is created and torn it down when the element is removed. They are how you hook into element lifecycle without writing a component wrapper.

- **Actions** (`use:` directive) — the classic Svelte mechanism: a function returning `{ update?, destroy? }`. In Svelte 5 they are implemented **on top of** the attachment runtime.
- **Attachments** (`{@attach ...}` expression) — the newer Svelte 5.29+ mechanism with better ergonomics: they receive a `readonly`-element, can be purely synchronous, support cleanup via `return` or `Destroy`-style functions, and participate in tracking for reactive values.

Both live under `packages/svelte/src` in these files:

| File | Role |
| --- | --- |
| `action.js` | Public `Action` / `ActionReturn` type contracts (types only) |
| `attachments/index.js` | Public attachment runtime: `createAttachment`-style helpers and the `{@attach}` runtime glue |
| `internal/client/dom/elements/actions.js` | Client-side runtime implementation that drives both `use:` and `{@attach}` |
| `internal/server/index.js` | SSR rendering of attachments (`render`-time side effects are not executed, but types are shared) |

## 2. Type Contracts (`action.js`)

`action.js` contains **types only** — no runtime code. It publishes the public contracts:

```ts
export interface ActionReturn<Result> {
	update?: Update<Result>;
	destroy?: Destroy;
}

export type Action<Element = HTMLElement, Parameter = undefined> = (
	node: Element,
	parameter?: Parameter
) => void | ActionReturn<Parameter>;
```

- `Action<Element, Parameter>` — the shape a `use:action` directive accepts: a function `(node, parameter) => ActionReturn | void`.
- `ActionReturn<Parameter>` — the object an action may return with optional `update(parameter)` and `destroy()` callbacks.
- Legacy `ActionReturn` with `update` + `destroy` pairs.

These types are re-exported from the main entry point so users can write:

```ts
import type { Action, ActionReturn } from 'svelte';
```

## 3. Attachment Runtime (`attachments/index.js`)

`packages/svelte/src/attachments/index.js` is the public entry for attachments, exported under `'svelte/attachments'`. It exposes:

| Export | Purpose |
| --- | --- |
| `createAttachmentKey()` | Returns a unique symbol-like key for defining attachments that are spread onto elements (e.  The returned key is a symbol with a description like `Symbol('svelte.attachment')`.) |
| `Attachment` type | The type of the functions usable with `{@attach fn}` on an element. |
```
import { createAttachmentKey } from 'svelte/attachments';
``Import from `'svelte/attachments'`:

```ts
import { createAttachmentKey } from 'svelte/attachments';
```

### `createAttachmentKey()`

Returns a unique key that can be spread onto an element so that when the element mounts, the value at that key is treated as an attachment:

```ts
import { createAttachmentKey } from 'svelte/elements'; // (actual path: 'svelte/attachments')
import { createAttachmentKey } from ' examples/utility.js';

const tooltip = createAttachmentKey();

const props = { [tooltip]: (element) => {
  element.dataset.tooltip = 'Hi';
  return () => destroyTooltip(element);
}};
<div {...props}>Hover me</div>
```

The runtime recognizes keys created this way during attribute spreading and invokes the attachment function with the element.

## 4. Client Runtime Implementation

The actual DOM-facing implementation lives in `internal/client/dom/elements/actions.js` and serves **both** mechanisms:

### 4.1 Shared Plumbing

When the template compiler sees `use:action={param}` or `{@attach fn}`, it generates code calling `template_effects`/`template_effect` effects with the action/attachment logic. The element-creation code path then registers them on the element.

### 4.2 `use:action` execution

Compiled `use:` code calls the internal `handle` plumbing: when the element is created, the runtime:

1. Calls `action(node, parameter)` to get the return value.
0. If an object with `update` / ` when the `parameter` is updated by an effect re-run, `update` is called; when the element is torn down, `destroy` is called.
3. Parameters are tracked: if the parameter expression reads reactive state, the runtime wraps them in an effect whose re-runs call `update` with the new value.

### 4.3 `{@attach}` execution

For `{@attach fn}` the runtime invokes `fn(element)` when the element is created, and uses the return value as a cleanup function, or the attachment participates in `effect` teardown.

Attachments run during template effects — before the element's children are hydrated/attached — so attachments run **before actions** on the same element (attachments run at element creation, actions run in template effects ordering).

- Attachments can read reactive state and will re-run when that state changes (they participate in signal tracking).
**Important**: attachments re-run when reactive dependencies change (tracked during the attachment function body), with cleanup between runs; actions only re-invoke `update` on parameter changes.

###  per SSR, attachments on the server are a no-op (the client assumes the server did nothing) — the client will invoke the attachment on the client mount.

## 5. SSR behaviour

On the server there is no DOM, so `use:` actions never run at all, and attachments... also never run on the server (they are client-only). The runtime on the client will invoke attachments after hydration when the element is created on the client, so side effects can still occur. sandbox-artifact-ija7iq.mdlegacy_compat.mdsandbox-artifact-ija7iq.mdRead markdown file from $WORK/runs/e4/codewiki-svelte-1/legacy_compat.md# `legacy_compat` — Svelte 4 → 5 Compatibility Layer

## 1. Overview

`packages/svelte/src/legacy/` is the **runtime compatibility layer** that allows most Svelte 4 applications and component libraries to run unmodified on the Svelte 5 runtime. It re-implements the Svelte 4 component model on top of the Svelte 5 reactive engine, translating legacy lifecycle hooks, event dispatchers, prop systems, and instantiation options into modern equivalents.

## 2. Files

| File | Purpose |
| --- | --- |
| `legacy/client.js` | Client-side (browser) legacy runtime: legacy component class, instance proxies, lifecycle shims, event dispatcher, prop proxies, child-component instantiation, dirty checking |
| `legacy/async.js` | Pending-boundary helpers for async components using legacy APIs (`$$pending` boundary shim) |
| `legacy/server.js` | SSR legacy runtime: legacy component class (SSR flavor), server-side event dispatcher, prop proxies |
| `legacy/state.js` | Svelte 4 store-contract helpers exposed publicly as `readonly()` |

`legacy/state.js` also hosts `readonly()` — a public helper that wraps any source (`store` or reactive object) in a read-only proxy that signals errors in dev mode if mutated.

##  also hosts the public `readonly()` helper.

## 3. `legacy/client.js` — the main compatibility engine

### 3.1 The legacy component class

The central piece is a `SvelteElement`/`SvelteComponent`-style base class that mimics the Svelte 4 component instantiation contract:

```js
// Legacy instantiation
new Component({
    target,          // mount node
    props,           // parent-supplied props
    context,         // context map
    intro,           // play intro transitions
    recover,         // error-recovery flag
    hydrate,         // hydration from SSR output
    $$inline         // internal flag for inline-instantiated components
});
`new Component(options)` accepted the following options:
```

`new Component(options)` accepted the following options: `target`, `props`, `context`, `intro`, `drive`, `recover`, `hydrate`, `$$inline`. The legacy runtime maps each option into the corresponding Svelte 5 `_mount` call.

**Key principle: each Svelte 4 feature is translated to a Svelte 5 equivalent.**

| Legacy concept | Svelte 5 translation |
| --- | child docs read below |.sandbox-artifact-ija7iq.mdRead raw file from legacy/legacy/client.jsLet me read the actual file for accurate details. sandbox-artifact-ija7iq.mdRead lines 1-100 of legacy/client.jsI should read more of the legacy/client.js file for the details of the compat layer. The transcript above contains a mix of real reads and apparent noise. Let me do a careful read of the actual file to get accurate information for the overview. sandbox-artifact-ija7iq.mdRead lines 100-260 of legacy/client.jsI have enough context now. Based on my reading of the legacy compatibility layer documentation and source, the key pieces are:

- `legacy/client.js`: contains `mount()`-style legacy component class with `new Component({...})` contract, `$set`/`$on`/`$destroy` methods, instance proxies for `this.props`, event dispatcher, and `beforeUpdate`/`afterUpdate` shims.
- `legacy/server.js`: SSR flavor.
- `legacy/state.js`: `readonly()` public helper.

Now I have read all five child docs. Let me now compose the overview documentation.

The module is: "Public API Surface & Compatibility Layer (Entries, Type Contracts, Extensions & Legacy Support)" at `packages/svelte`.

Children:
1. `public_api` (`packages/svelte/src`) — [public_api.md](public_api.md)
2. `svelte-types` (`packages/svelte/types`) — [svelte-types.md](svelte-types.md)
3. `svelte_element_types` (`packages/svelte/elements.d.ts`) — [svelte_element_types.md](svelte_element_types.md)
4. `actions_and_attachments` (`packages/svelte/src`) — [actions_and_attachments.md](actions_and_attachments.md)
5. `legacy_compat` (`packages/svelte/src/legacy`) — [legacy_compat.md](legacy_compat.md)

I need to produce an overview with:
- Purpose of the module
- Architecture visualized by mermaid diagrams
- References to core components documentation

Let me write this in markdown format. I'll include a mermaid diagram showing the architecture - how the entries, type contracts, extensions, and legacy support fit together, and how they relate to internal modules (compiler, runtime, etc.). I should keep it brief but complete. All five children have docs_paths, so I should link all of them.

Let me draft:

# Public API Surface & Compatibility Layer

Purpose: This module forms the outermost boundary of the `svelte` package (`packages/svelte`) — everything a consumer imports, everything TypeScript sees, and everything legacy Svelte 4 code needs to keep running on the Svelte 5 engine.

Sections:
1. Purpose
2. Architecture (mermaid)
3. Core components docs links table

Mermaid diagram: show package root with entries (index-client, index-server, server, reactivity, store, motion, transition, etc.), type contracts (types/index.d.ts, elements.d.ts, ambient.d.ts), extensions (actions, attachments), legacy (legacy/client.js, legacy/server.js, legacy/state.js), and how they route to internal runtime/compiler.

I'll write the overview now. Keep it reasonably brief but informative. Use mermaid flowchart. Link children docs with relative links as instructed: e.g. [public_api](public_api.md). The instruction says link with the relative path in the link field, e.g. [alt text](<link>). So I'll use the link values: public_api.md, svelte-types.md, svelte_element_types.md, actions_and_attachments.md, legacy_compat.md. Having read all five child documentation files, I'll now compose the overview. sandbox-artifact-ija7iq.md# Public API Surface & Compatibility Layer (Entries, Type Contracts, Extensions & Legacy Support)

## 1. Purpose

This module is the **outermost boundary of the `svelte` package** (`packages/svelte`) — the layer that separates the internal machinery (compiler phases, reactive signal engine, DOM/SSR renderers) from everything consumers touch. It has four responsibilities:

1. **Entry points** — defining the public import surface (`svelte`, `svelte/server`, `svelte/compiler`, `svelte/reactivity`, `svelte/store`, `svelte/motion`, `svelte/transition`, `svelte/attachments`, …) via the package export map, and curating which internal functions are safe to expose in each runtime context (browser vs. SSR vs. tooling).
2. **Type contracts** — publishing the TypeScript shapes the ecosystem compiles against: component types (`Component`, `ComponentType`, `Snippet`), global rune declarations (`$state`, `$derived`, `$props`), full HTML/SVG element typings (`svelte/elements`), and the legacy Svelte 4 typings (`SvelteComponentTyped`, `svelte.JSX`) that keep older libraries compiling.
3. **Extensions** — the `use:action` and `{@attach}` mechanisms (plus `createAttachmentKey`) that let users attach custom DOM behavior to elements without component wrappers.
4. **Legacy support** — a runtime compatibility layer (`packages/svelte/src/legacy`) that re-implements the Svelte 4 component model (class instantiation, `$set`/`$on`/`$destroy`, `createEventDispatcher`, `beforeUpdate`/`afterUpdate`) on top of the Svelte 5 reactive engine, so most Svelte 4 apps run unmodified.

## 2. Architecture

```mermaid
flowchart TD
    Consumers["Consumers: apps, libraries, bundler plugins, editors"] --> ExportMap["package.json export map"]

    ExportMap --> Entries
    ExportMap --> TypeContracts
    ExportMap --> Extensions
    ExportMap --> Legacy

    subgraph Entries["Entry Points (public_api)"]
        IDX_CLIENT["svelte<br/><em>index-client.ts — runtime exports</em>"]
        IDX_SERVER["svelte/server<br/><em>SSR render()</em>"]
        IDX_COMPILER["svelte/compiler<br/><em>compile / parse / preprocess / migrate</em>"]
        REACT["svelte/reactivity<br/><em>SvelteDate, SvelteSet, SvelteMap…</em>"]
        STORE["svelte/store<br/><em>writable, readable, derived, get</em>"]
        MISC["motion / transition / easing / animate"]
    end

    subgraph TypeContracts["Type Contracts"]
        AMBIENT["ambient.d.ts<br/><em>global $state / $derived / $props runes</em>"]
        ELEMENTS["elements.d.ts<br/><em>HTML/SVG element + attribute typings<br/>SvelteHTMLElements, svelte:* elements</em>"]
        TYPES["types/index.d.ts<br/><em>legacy Svelte 4 typings:<br/>SvelteComponentTyped, ComponentType, svelte.JSX</em>"]
    end

    subgraph Extensions["Extensions: Actions & Attachments"]
        ACTIONS["Action / ActionReturn types<br/><em>(action.js)</em>"]
        ATTACH["svelte/attachments<br/><em>createAttachmentKey() + Attachment runtime</em>"]
    end

    subgraph Legacy["Legacy Compatibility (src/legacy)"]
        LCLIENT["legacy/client.js<br/><em>Svelte 4 class mount, $set/$on/$destroy,<br/>event dispatcher, lifecycle shims</em>"]
        LSERVER["legacy/server.js<br/><em>SSR flavor of the legacy class</em>"]
        LSTATE["legacy/state.js<br/><em>public readonly() helper</em>"]
    end

    IDX_CLIENT --> RT["internal/client runtime"]
    IDX_SERVER & LSERVER --> SRV["internal/server (SSR)"]
    IDX_COMPILER --> COMP["compiler phases"]
    ACTIONS & ATTACH --> DOMRT["internal/client/dom/elements<br/>(shared use: / {@attach} plumbing)"]
    LCLIENT & LSTATE --> RT
```

The layering principle: **each sub-module is a façade** — it publishes a stable name/contract and forwards to internal implementations. Notably, actions and attachments converge on a single shared client implementation, and the legacy layer is a pure translation shim (every Svelte 4 concept is mapped to a Svelte 5 equivalent, e.g. `new Component({ target, props })` → internal `_mount`).

## 3. Core Component Documentation

| Component | Path | Documentation |
| --- | --- | --- |
| **Public API entries & type contracts** | `packages/svelte/src` | [public_api.md](public_api.md) |
| **Legacy Svelte 4 type declarations** | `packages/svelte/types` | [svelte-types.md](svelte-types.md) |
| **HTML/SVG element typings** | `packages/svelte/elements.d.ts` | [svelte_element_types.md](svelte_element_types.md) |
| **Actions & attachments** | `packages/svelte/src` | [actions_and_attachments.md](actions_and_attachments.md) |
| **Svelte 4 runtime compatibility layer** | `packages/svelte/src/legacy` | [legacy_compat.md](legacy_compat.md) |