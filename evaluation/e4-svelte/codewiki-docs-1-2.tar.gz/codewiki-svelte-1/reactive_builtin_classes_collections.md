# Reactive Built-in Classes — Collections (`SvelteMap`)

## 1. Overview

`reactive_builtin_classes_collections` is the collections module of the **`svelte/reactivity`** package. It provides **`SvelteMap`** — a drop-in, reactive replacement for the built-in JavaScript [`Map`](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Map).

`SvelteMap` extends the native `Map` and wires every read and write into Svelte's signal graph:

- **Reads** (`get`, `has`, `size`, iteration via `forEach` / `keys` / `values` / `entries` / `[Symbol.iterator]`) executed inside an `$effect`, `$derived`, or template expression register the appropriate signals as dependencies, so the consumer re-evaluates when the map changes.
- **Writes** (`set`, `delete`, `clear`) route through the runtime's source-mutation primitives, invalidating exactly the reactions that observed the affected state — per key where possible, map-wide where necessary.

Key design properties:

| Property | Description |
|---|---|
| **Fine-grained tracking** | Each *read* key gets its own lazily created signal; mutating key `a` does not invalidate readers of key `b`. |
| **Coarse-grained fallback** | Map-wide operations (`size`, iteration, membership of *absent* keys) track a single `version` counter signal. |
| **Lazy signal creation** | Signals are created only for keys that are actually observed — an unread 1M-entry map costs nothing. |
| **API-compatible** | Extends native `Map`; values are stored natively (values are **not** made deeply reactive). |
| **Server-safe** | Under SSR the `svelte/reactivity` entry substitutes the native `Map` (see [§9](#9-public-api-surface--ssr-substitution)). |

---

## 2. Module at a Glance

| | |
|---|---|
| **Module path** | `packages/svelte/src/reactivity/map.js` |
| **Exported symbol** | `SvelteMap<K, V>` |
| **Public entry** | `svelte/reactivity` → `src/reactivity/index-client.js` (client) / `index-server.js` (server) |
| **Parent module** | [`reactive_builtin_classes`](reactive_builtin_classes.md) (siblings: temporal/URL primitives, environment/SSR primitives) |
| **Core dependency** | [Reactive Runtime Engine](reactive_runtime_engine.md) — signals, effect scheduling, batching, dev tracing |
| **Consumers** | Application code via `import { SvelteMap } from 'svelte/reactivity'` |

---

## 3. Position in the System

`SvelteMap` is a *bridge class*: it couples plain `Map` semantics to the reactive runtime without introducing any scheduling logic of its own. All invalidation, batching, and dev instrumentation is delegated to the [Reactive Runtime Engine](reactive_runtime_engine.md).

```mermaid
flowchart TB
    subgraph PUB["Public API Surface — svelte/reactivity entry"]
        IC["index-client.js<br/>(browser bundle)"]
        IS["index-server.js<br/>(SSR bundle)"]
    end

    subgraph MOD["reactive_builtin_classes_collections"]
        SM["SvelteMap extends Map"]
    end

    subgraph SIB["Sibling reactive builtin modules"]
        D["SvelteDate · SvelteURL · SvelteURLSearchParams"]
        MQ["MediaQuery · createSubscriber"]
    end

    subgraph RT["Reactive Runtime Engine"]
        SRC["reactivity/sources.js<br/>source · state · set · increment"]
        RUN["runtime.js<br/>get · update_version · current_sources"]
        BATCH["reactivity/batch.js<br/>Batch · flushSync · tick"]
        TRACE["dev/tracing.js<br/>tag · label"]
    end

    DEV["esm-env<br/>DEV flag"]

    IC -->|"exports"| SM
    IS -.->|"server build: SvelteMap = native Map"| SM
    SM --- SIB

    SM -->|"create signals"| SRC
    SM -->|"register deps / read version"| RUN
    SM -->|"mutate signals"| SRC
    SRC -->|"write versioning → schedule"| BATCH
    SM -->|"DEV: label signals"| TRACE
    DEV --> SM
```

Responsibility split:

1. **This module** defines *what* is reactive about a map: which signal to touch for each operation.
2. **The runtime** defines *how* signals propagate: dirty-flagging, derived re-execution, batch flushing, effect scheduling (see [Reactive Runtime Engine](reactive_runtime_engine.md)).
3. **The compiler** is not involved — `SvelteMap` works in plain `.js`/`.ts` modules and inside components alike.

---

## 4. Architecture

### 4.1 Internal tracking model

`SvelteMap` layers a small signal bookkeeping structure on top of the native map. The native `Map` remains the single source of truth for data; the signals are pure *change tokens* — their numeric values are never exposed to callers.

```mermaid
classDiagram
    direction TB
    class Map~K V~ {
        <<native base class>>
        +get(key) V
        +set(key, value) Map
        +has(key) boolean
        +delete(key) boolean
        +clear()
        +keys() Iterator
        +values() Iterator
        +entries() Iterator
        +forEach(cb, thisArg)
        +size number
    }

    class SvelteMap~K V~ {
        -Map #sources
        -Source~number~ #version
        -Source~number~ #size
        -number #update_version
        -#source(value) Source
        -#read_all()
        +constructor(value)
        +get(key) V
        +has(key) boolean
        +set(key, value) Map
        +delete(key) boolean
        +clear()
        +size number
        +forEach(cb, thisArg)
        +keys() Iterator
        +values() Iterator
        +entries() Iterator
        +Symbol.iterator() Iterator
    }

    class Source~number~ {
        <<runtime signal>>
        +v number
        +reactions Reaction[]
        +label string
    }

    Map <|-- SvelteMap
    SvelteMap *-- "0..1 per observed key" Source~number~ : #sources
    SvelteMap *-- "1" Source~number~ : #version
    SvelteMap *-- "1" Source~number~ : #size
```

| Private member | Type | Role | Read by | Written by |
|---|---|---|---|---|
| `#sources` | `Map<K, Source<number>>` | Lazily created **per-key change counters**. Present ⇔ the key has been observed at least once. | `get`, `has`, `set`, `delete`, `clear`, `#read_all` | same |
| `#version` | `Source<number>` | **Whole-map change counter.** The dependency of coarse-grained readers (iteration, `keys()`, `has`/`get` on missing keys). | `keys`, `#read_all`, missing-key paths | `set` (new key / conservative), `delete`, `clear` |
| `#size` | `Source<number>` | Mirrors `map.size` for the `size` getter; its `.v` also serves as a cheap "do all keys have sources?" heuristic in `#read_all`. | `size` getter, `#read_all` (untracked peek) | constructor, `set` (new key), `delete`, `clear` |
| `#update_version` | `number` | Snapshot of the runtime's `update_version` at construction; drives the **ownership heuristic** for lazily created signals (see [§7.1](#71-the-state-vs-source-ownership-heuristic)). | `#source()` | constructor |

Sentinel convention: a per-key counter holding `-1` means *"this key was removed"*; a monotonically increasing value means *"this key's value changed."* Readers never see these numbers — `get()`/`has()` always return the native value/boolean after calling `get(signal)` purely to register the dependency.

### 4.2 Operation → signal mapping

| Public operation | Signals read (deps registered) | Signals written / invalidated |
|---|---|---|
| `get(key)` — key present | per-key source (created lazily) | — |
| `get(key)` / `has(key)` — key absent | `#version` | — |
| `has(key)` — key present | per-key source (created lazily) | — |
| `size` | `#size` | — |
| `keys()` | `#version` only (key-set changes always bump `#version`) | — |
| `forEach`, `values()`, `entries()`, spread / `for…of` | `#version` + **all** per-key sources (`#read_all` back-fills missing ones) | — |
| `set(key, v)` — new key | — | creates per-key source, writes `#size`, increments `#version` |
| `set(key, v)` — existing key, value changed | — | increments per-key source; **conditionally** increments `#version` (see [§6](#6-write-paths)) |
| `set(key, v)` — value unchanged | — | *none* (no-op for reactivity) |
| `delete(key)` — observed key | — | removes source, writes `#size`, sets source to `-1`, increments `#version` |
| `clear()` — non-empty | — | resets `#size`, sets **all** sources to `-1`, increments `#version`, drops source table |
| `constructor(iterable)` | — | seeds native map + `#size` (no invalidation — nothing can observe it yet); DEV-only validation via `new Map(value)` |

---

## 5. Read Paths

All reads are *tracking* reads: they call the runtime's `get(signal)`, which registers the signal as a dependency of the currently executing reaction (if any).

```mermaid
flowchart TD
    A["get(key) / has(key)"] --> B{"#sources has<br/>entry for key?"}
    B -->|"yes"| E["get(per-key source)<br/>→ registers dependency"]
    B -->|"no"| C{"key present in<br/>native Map?"}
    C -->|"yes"| D["s = #source(0)<br/>DEV: tag(s, 'SvelteMap get(key)')<br/>store in #sources"]
    D --> E
    C -->|"no"| F["get(#version)<br/>→ track future shape changes"]
    F --> G["return undefined / false"]
    E --> H["return native value / true"]
```

Coarse-grained reads funnel through `#read_all()`:

```mermaid
flowchart TD
    A["forEach / values / entries / Symbol.iterator"] --> B["get(#version)<br/>— catches future add/delete/shape change"]
    B --> C{"#size.v !== #sources.size ?"}
    C -->|"yes"| D["for each native key without a source:<br/>create + register source (back-fill)"]
    C -->|"no"| E
    D --> E["get(s) for every per-key source<br/>— depends on every value"]
    E --> F["delegate to native Map iteration"]
```

Read-path highlights:

- **`keys()` deliberately tracks only `#version`.** Since any key-set mutation (add / delete / clear) bumps `#version`, the key sequence is fully covered without touching per-key value signals — value-only changes never force a `keys()` consumer to re-run.
- **`size` reads `#size`** but returns the native `super.size`, so the returned number is always accurate; the signal only controls *when* consumers re-run.
- **`#read_all` uses `#size.v !== #sources.size`** as an untracked fast-path check to skip back-filling when the source table is already complete.
- **Absent keys track `#version`** so that a later `set` of that key (which always bumps `#version`) invalidates the reader that once saw `undefined` / `false`.

---

## 6. Write Paths

Writes go through `set` / `increment` from `internal/client/reactivity/sources.js`, which apply runtime guards (e.g. *mutating state inside a `$derived` throws `state_unsafe_mutation`*) and write-version bookkeeping that the batch scheduler consumes (see [Reactive Runtime Engine](reactive_runtime_engine.md)).

```mermaid
flowchart TD
    A["set(key, value)"] --> B{"#sources has entry<br/>for key?"}
    B -->|"no — new key"| C["create source via #source(0)"]
    C --> D["set(#size, super.size)"]
    D --> E["increment(#version)<br/>shape changed: iteration / size /<br/>absent-key readers must re-run"]
    B -->|"yes"| F{"native value<br/>actually changed?"}
    F -->|"no"| G["return — zero invalidation"]
    F -->|"yes"| H["increment(per-key source)"]
    H --> I{"#version has no reactions OR<br/>not every reaction of the key source<br/>is also a reaction of #version?"}
    I -->|"yes — cannot prove key readers<br/>cover the coarse readers"| J["increment(#version) as well"]
    I -->|"no — every key reader also<br/>tracks #version"| K["done: fine-grained only"]

    L["delete(key)"] --> M{"per-key source exists?<br/>(key was observed)"}
    M -->|"yes"| N["remove from #sources · set(#size)<br/>set(s, -1) · increment(#version)"]
    M -->|"no"| O["native delete only"]

    P["clear()"] --> Q{"map empty?"}
    Q -->|"yes"| R["no-op"]
    Q -->|"no"| S["native clear first (nice $inspect output)<br/>set(#size, 0) · set(s, -1) for all sources<br/>increment(#version) · clear #sources"]
```

Invalidation strategy summary:

1. **New key** → the map's *shape* changed, so every coarse reader (`size`, iteration, `keys`, absent-key membership) must be invalidated via `#version` and `#size`.
2. **Existing key, value changed** → the *cheap* path bumps only the per-key counter. The `#version` counter is additionally bumped unless it is provably redundant — i.e. unless the dependency sets have converged such that every reaction watching the key source is *also* watching `#version`. This preserves correctness for coarse-grained readers (iteration, `keys()`) at zero cost once the reader populations have merged, and keeps value-only mutations from waking unrelated `keys()`/`size` subscribers otherwise.
3. **No-op writes** (`set` with an identical value, `clear` on an empty map, `delete` of a missing key) emit **no** invalidations, matching native semantics and avoiding effect churn.

---

## 7. Interaction with the Reactivity Engine

### 7.1 The `state` vs `source` ownership heuristic

Per-key sources are created *lazily*, often while some reaction is running (a template effect reading `map.get(key)`). Whether such a signal may become a dependency of that reaction depends on **who created the map**:

- `runtime.js` maintains a module-level `update_version` that is set to a fresh `read_version` at the start of every reaction run (`update_reaction`). 
- The `SvelteMap` constructor snapshots it into `#update_version` (with `update_version || -1` mapping the initial zero to a sentinel so out-of-reaction construction always behaves like "foreign").
- `#source(value)` compares: if the lazy creation happens **within the same reaction run that constructed the map**, it uses `state(value)`; otherwise `source(value)`.

`state()` additionally calls the runtime's `push_reaction_value`, registering the new signal in `current_sources`. Sources in `current_sources` are **exempt** from dependency registration and self-invalidation for the duration of that reaction run. The class's own comment states the rule:

> *"If the source is being created inside the same reaction as the SvelteMap instance, we use `state` so that it will not be a dependency of the reaction. Otherwise we use `source` so it will be."*

This prevents the common initialization pattern — create a map and populate it inside the same component/effect that renders it — from producing a reaction that invalidates itself.

### 7.2 End-to-end update flow

```mermaid
sequenceDiagram
    autonumber
    participant R1 as Reaction A ($effect / template)
    participant M as SvelteMap
    participant KS as per-key Source ("a")
    participant VS as #version Source
    participant RT as Runtime (get / batch / flush)

    Note over R1: run #1 — dependency collection
    R1->>M: get("a")
    M->>M: no source yet · key exists
    M->>KS: #source(0) → source(0)
    R1->>RT: get(ks) — registers dependency
    M-->>R1: native value

    Note over M: later, event handler / another effect
    M->>KS: set(key, newValue) → increment(ks)
    M->>VS: increment(#version) — if not provably redundant
    RT->>RT: internal_set → write version bump<br/>→ reactions flagged dirty → Batch schedules

    Note over R1: batch flush — reaction re-runs
    R1->>M: get("a")
    M->>KS: get(ks) — still a dependency
    M-->>R1: new native value
```

Because `set`/`increment` delegate to the runtime's guarded setters, mutation inside a `$derived` throws `state_unsafe_mutation`, and multiple mutations within one tick coalesce into a single flush (see [Reactive Runtime Engine](reactive_runtime_engine.md) for batching semantics).

### 7.3 Dev-mode instrumentation

Under `DEV` (from `esm-env`):

- Every signal the map creates is passed to `dev/tracing.js#tag`, labelling it (`'SvelteMap version'`, `'SvelteMap.size'`, `` `SvelteMap get(key)` ``) so Svelte DevTools and `$inspect`/tracing output is readable. `label(key)` renders symbols, functions and objects as short placeholders.
- The constructor round-trips its argument through `new Map(value)` — an invalid iterable raises the **native** `TypeError` with familiar messaging before any state is created.
- `clear()` clears the native map *before* invalidating so `$inspect(map)` prints the post-mutation state.

---

## 8. Dependencies

```mermaid
flowchart LR
    SM["SvelteMap<br/>(this module)"]

    subgraph RUNTIME["Reactive Runtime Engine (internal/client)"]
        SRC["reactivity/sources.js<br/>source · state · set · increment"]
        RUN["runtime.js<br/>get · update_version"]
        TRACE["dev/tracing.js<br/>tag · label"]
    end

    ESM["esm-env (DEV)"]
    NATIVE["native Map"]
    PUB["svelte/reactivity index-client.js"]

    PUB --> SM
    SM -->|"create + mutate signals"| SRC
    SM -->|"dependency tracking · ownership version"| RUN
    SM -->|"DEV labels"| TRACE
    SM --> ESM
    SM -->|"storage (super.*)"| NATIVE
```

| Import | Used for | Owning module |
|---|---|---|
| `source`, `state`, `set`, `increment` | creating per-key / version / size signals; guarded mutation + invalidation | [Reactive Runtime Engine](reactive_runtime_engine.md) → `client_runtime_core_sources` |
| `get`, `update_version` | registering dependencies; same-reaction ownership heuristic | [Reactive Runtime Engine](reactive_runtime_engine.md) → `client_runtime_core_runtime` |
| `tag`, `label` | DEV signal labels for DevTools / tracing | [Reactive Runtime Engine](reactive_runtime_engine.md) → `client_dev_mode_debugging` |
| `DEV` (esm-env) | dead-code-eliminated dev branches | build tooling |
| `Map` (global) | storage; `SvelteMap extends Map` | JS engine |

Upstream, the module does **not** depend on the compiler, DOM renderer, or stores — it sits directly on the signal core. For plain store interop (`.subscribe`-style) see [Reactive State Primitives & Store Interop](stores.md); for converting between signals and stores, use `fromStore`/`toStore` from the same parent area.

---

## 9. Public API Surface & SSR Substitution

`svelte/reactivity` has split entries resolved by the package export map:

- **Client** — `src/reactivity/index-client.js` re-exports the real class:
  ```js
  export { SvelteMap } from './map.js';
  ```
  alongside `SvelteSet`, `SvelteDate`, `SvelteURL`, `SvelteURLSearchParams`, `MediaQuery` and `createSubscriber` (see the sibling modules of [`reactive_builtin_classes`](reactive_builtin_classes.md)).
- **Server** — `src/reactivity/index-server.js` aliases the class to the platform built-in:
  ```js
  export const SvelteMap = globalThis.Map;
  ```
  On the server there is no reactive scheduler to subscribe to, so every reactive builtin degrades to its native counterpart — identical data semantics, zero reactivity overhead. This is the same substitution strategy used by the temporal/URL primitives ([reactive_builtin_classes_temporal_url_primitives](reactive_builtin_classes_temporal_url_primitives.md)) and `MediaQuery` ([reactive_builtin_classes_environment_and_ssr](reactive_builtin_classes_environment_and_ssr.md)).

Public contract: `new SvelteMap<K, V>(iterable?: Iterable<readonly [K, V]> | null | undefined)` and the full `Map<K, V>` interface, including chainable `set()` (returns the map) and boolean `delete()`.

---

## 10. Usage Example

From the class documentation — a tic-tac-toe board where reads drive the UI and writes invalidate exactly the cells involved:

```svelte
<script>
	import { SvelteMap } from 'svelte/reactivity';
	import { result } from './game.js';

	let board = new SvelteMap();
	let player = $state('x');
	let winner = $derived(result(board)); // iterates → tracks #version + all keys

	function reset() {
		player = 'x';
		board.clear(); // marks all keys deleted, bumps #version
	}
</script>

<div class="board">
	{#each Array(9), i}
		<button
			disabled={board.has(i) || winner}
			onclick={() => {
				board.set(i, player);
				player = player === 'x' ? 'o' : 'x';
			}}
		>{board.get(i)}</button>
	{/each}
</div>
```

Typical tracking profile in this example: each button's `board.get(i)` depends only on cell `i`'s counter; `result(board)` (which iterates) depends on `#version` and every key; `board.has(i)` for an unplayed cell depends on `#version`, so the first move invalidates it via the new-key `#version` bump.

---

## 11. Design Invariants & Performance Characteristics

1. **Signals are change tokens, not data.** Numeric counter values (including the `-1` deletion sentinel) are never returned to callers; the native `Map` is always the source of truth. Consequence: extra `get(s)` bookkeeping reads cannot corrupt values.
2. **Laziness bounds cost by observation.** Memory and dependency-graph work scale with the number of *read* keys, not the map size. Unread keys are invisible to the signal graph (shape changes still reach coarse readers via `#version`).
3. **No-op writes are free.** `set` with an equal value, `delete` of a missing key, and `clear` of an empty map perform zero signal writes, so they cannot schedule effects.
4. **Fine-grained first, coarse-grained correct.** Value updates bump a single per-key counter; `#version` is bumped additionally only when redundancy cannot be proven from the current reaction sets, keeping `keys()`/iteration consumers correct without systematically over-invalidating them.
5. **Shallow by contract.** Values are not proxied or made deeply reactive — nested objects stored in a `SvelteMap` are reactive only if they are themselves `$state` proxies or other reactive builtins (documented in the class JSDoc; deep-state behavior belongs to the [Reactive Runtime Engine](reactive_runtime_engine.md)).
6. **Safe self-population.** The `state`-vs-`source` ownership heuristic (§7.1) makes the create-and-render-in-one-reaction pattern loop-free.
7. **Runtime guards inherited.** All mutations flow through the guarded `set()`/`increment()` helpers, inheriting derived-mutation errors, write-versioning, and batch coalescing from the runtime.

---

## 12. Related Documentation

- [`reactive_builtin_classes`](reactive_builtin_classes.md) — parent module: the full reactive builtin family.
- [`reactive_builtin_classes_temporal_url_primitives`](reactive_builtin_classes_temporal_url_primitives.md) — `SvelteDate`, `SvelteURL`, `SvelteURLSearchParams` (wrapper/trap-based tracking rather than counter signals).
- [`reactive_builtin_classes_environment_and_ssr`](reactive_builtin_classes_environment_and_ssr.md) — `MediaQuery` and `createSubscriber` (subscription-based reactivity).
- [Reactive Runtime Engine](reactive_runtime_engine.md) — signals, effects, batching, dev instrumentation consumed by this module.
- [Reactive State Primitives & Store Interop](stores.md) — `writable`/`derived` stores and `fromStore`/`toStore` bridges.
- [Public API Surface & Compatibility Layer](public_api_surface.md) — package entries and type contracts.
