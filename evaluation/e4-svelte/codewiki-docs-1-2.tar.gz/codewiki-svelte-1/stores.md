# Stores Module (`svelte/store`)

## 1. Overview

The **stores** module (`packages/svelte/src/store/`) implements Svelte's *store contract* — a minimal, framework-agnostic subscription protocol — together with the factories that create contract-compliant stores and the bridges that connect stores to Svelte 5's runes-based reactivity (`$state`, `$derived`, effects).

It serves three purposes:

1. **Type contract** — the `Readable` / `Writable` interfaces and supporting callback types (`Subscriber`, `Unsubscriber`, `Updater`, `StartStopNotifier`) that the whole Svelte ecosystem (libraries, `svelte/motion`, legacy components) programs against.
2. **Store factories** — environment-agnostic implementations of `writable`, `readable`, `derived`, `readonly` and the one-shot `get` accessor, usable in any JavaScript runtime (browser, Node/SSR, workers).
3. **Runes ↔ store interop** — `toStore` (wrap reactive getters as a store) and `fromStore` (expose a store as a `{ current }` object that participates in rune reactivity), with *reactive* implementations on the client and *pull-based* implementations on the server.

The module is the last remaining "legacy" state primitive in Svelte 5: components using `$store` auto-subscription, external store libraries, and packages like `svelte/motion` all funnel through this code.

| Public export | Kind | Defined in |
|---|---|---|
| `writable`, `readable`, `derived`, `readonly`, `get` | functions | `store/shared/index.js` |
| `fromStore`, `toStore` | functions | `store/index-client.js` (reactive) / `store/index-server.js` (pull-based) |
| `Readable`, `Writable`, `Subscriber`, `Unsubscriber`, `Updater`, `StartStopNotifier` | types | `store/public.d.ts` |

### Documentation map

This module's documentation is split across four files in this directory:

| File | Scope |
|---|---|
| [stores.md](stores.md) | *(this file)* — module overview, architecture, data flows, system integration |
| [stores_contract.md](stores_contract.md) | The store protocol: `Readable`, `Writable`, `Subscriber`, `Unsubscriber`, `Updater`, `StartStopNotifier` and the private helper types. |
| [stores_core.md](stores_core.md) | The engine: `writable`, `readable`, `derived`, `readonly`, `get`, `subscribe_to_store` — internals, batching queue, cleanup semantics. |
| [stores_interop.md](stores_interop.md) | The `svelte/store` entries: reactive vs. pull-based `fromStore`/`toStore` implementations. |

Read the contract first if you are *implementing* a store, the core for the *runtime semantics* of the built-in factories, and the interop doc for mixing stores with runes.

---

## 2. Architecture

### 2.1 Layering

The module is a thin vertical slice with a strict dependency direction: **entries → shared core → internal runtime primitives**. Nothing in the store module depends on compilation or DOM specifics; only the client entry touches the reactive engine.

```mermaid
flowchart TB
    subgraph entries["Environment entries  (resolved via package export conditions)"]
        IC["index-client.js<br/>browser"]
        IS["index-server.js<br/>node / SSR"]
    end

    subgraph core["Shared core — environment agnostic"]
        SI["shared/index.js<br/>writable · readable · derived · readonly · get"]
        SU["utils.js<br/>subscribe_to_store"]
    end

    subgraph types["Type contract"]
        PUB["public.d.ts<br/>Readable · Writable · Subscriber<br/>Unsubscriber · Updater · StartStopNotifier"]
        PRIV["private.d.ts<br/>Stores · StoresValues · SubscribeInvalidateTuple"]
    end

    subgraph engine["Reactive Runtime Engine (internal — see client_runtime_core)"]
        FX["internal/client/reactivity/effects.js<br/>effect_root · render_effect · effect_tracking"]
        RT["internal/client/runtime.js<br/>active_effect / active_reaction + setters"]
        CS["reactivity/create-subscriber.js<br/>createSubscriber (lazy ref-counted subscription)"]
        EQ["internal/client/reactivity/equality.js<br/>safe_not_equal"]
        UT["internal/shared/utils.js<br/>noop · run_all"]
    end

    IC -- "re-exports shared API" --> SI
    IS -- "re-exports shared API" --> SI
    SI --> SU
    SI -.-> PUB
    SI -.-> PRIV
    IC --> FX
    IC --> RT
    IC --> CS
    SI --> EQ
    SI --> UT
    SU --> UT
    CS --> FX
```

### 2.2 Entry-point resolution

`import ... from 'svelte/store'` resolves through the package's export conditions, so the *same public surface* exists on both platforms while `fromStore`/`toStore` differ in implementation strategy:

```mermaid
flowchart LR
    A["import { writable, fromStore }<br/>from 'svelte/store'"] --> RES{"export conditions"}
    RES -->|"browser"| IC["store/index-client.js"]
    RES -->|"node / SSR"| IS["store/index-server.js"]
    IC --> SH["shared/index.js<br/>(identical core on both)"]
    IS --> SH
```

The client/server asymmetry is intentional:

| Concern | Client (`index-client.js`) | Server (`index-server.js`) |
|---|---|---|
| `fromStore` | Lazily subscribes via `createSubscriber` inside tracked effects; `current` is reactive | Every `current` read is a fresh `get(store)` (subscribe + immediate unsubscribe); no reactivity needed |
| `toStore` | Wires the source getter into an `effect_root`/`render_effect` so the store updates when `$state` changes | Snapshot of the value at creation time; no reactive propagation is possible during SSR |
| `writable`/`derived`/`get` | Shared implementation, works everywhere | same |

### 2.3 File inventory

| File | Responsibility |
|---|---|
| `store/public.d.ts` | The published store contract: `Readable`, `Writable` and the callback types. Re-exported through the package's umbrella `types/index.d.ts`. |
| `store/private.d.ts` | Internal-only helper types: `SubscribeInvalidateTuple`, `Stores`, `StoresValues` (used by `derived`). |
| `store/shared/index.js` | `writable`, `readable`, `derived`, `readonly`, `get` — the complete store engine, runtime-agnostic. |
| `store/utils.js` | `subscribe_to_store`: null-safe store subscription with RxJS-observable support, used by `get` and `derived`. |
| `store/index-client.js` | Client entry: re-exports the shared API + reactive `fromStore`/`toStore` built on effects, `createSubscriber` and the runtime's active effect/reaction context. |
| `store/index-server.js` | Server entry: re-exports the shared API + pull-based `fromStore`/`toStore`. |

---

## 3. Sub-modules

| Sub-module | Documentation | Contents |
|---|---|---|
| **Store contract** | [stores_contract.md](stores_contract.md) | `public.d.ts` — `Readable`, `Writable`, `Subscriber`, `Unsubscriber`, `Updater`, `StartStopNotifier`; plus the private helper types. Defines the *protocol* every store must honor. |
| **Core store engine** | [stores_core.md](stores_core.md) | `shared/index.js` + `utils.js` — `writable` (subscriber set, start/stop notifier, batched invalidation queue), `readable`, `derived` (multi-store fan-in), `readonly`, `get`, `subscribe_to_store`. |
| **Runes interop bridge** | [stores_interop.md](stores_interop.md) | `index-client.js` + `index-server.js` — `toStore` and `fromStore`, and how their client/server implementations diverge. |

---

## 4. Key data flows

### 4.1 `writable` subscription lifecycle and update propagation

The core engine is a subscriber `Set` plus a start/stop notifier, with a **batched invalidation queue** so that synchronously cascading `set()` calls invalidate all subscribers first, then run callbacks in one pass.

```mermaid
sequenceDiagram
    participant C as Consumer
    participant W as writable store
    participant N as StartStopNotifier

    C->>W: subscribe(run, invalidate)
    W->>W: subscribers.add([run, invalidate])
    alt first subscriber
        W->>N: start(set, update)
        N-->>W: optional teardown fn (stored as stop)
    end
    W-->>C: run(current value)

    Note over W,N: ... later ...
    C->>W: set(new) / update(fn)
    W->>W: safe_not_equal(old, new)?
    W->>W: invalidate every subscriber
    W->>W: enqueue [subscriber, value] pairs
    W-->>C: run(value) × subscribers (single queue flush)

    C->>W: unsubscribe()
    W->>W: subscribers.delete(tuple)
    alt last subscriber
        W->>N: stop() — notifier torn down
    end
```

### 4.2 `derived` fan-in

`derived(stores, fn)` subscribes to one or many input stores; a `pending` bitmask with an invalidate callback per input guarantees the combine function only runs when *all* inputs have delivered at least one value.

```mermaid
flowchart LR
    A["store A"] -->|"subscribe"| D["derived<br/>pending bitmask<br/>sync()"]
    B["store B"] -->|"subscribe"| D
    D -->|"auto: set(result)"| R["Readable<T>"]
    D -->|"manual: set/update callbacks"| R
```

### 4.3 Runes ↔ store interop (client)

On the client, `fromStore` converts a store into a getter/setter object whose reads participate in signal tracking; `toStore` goes the opposite way by observing a getter inside an effect and pushing into a `writable`.

```mermaid
flowchart TB
    subgraph FS["fromStore(store)"]
        R["obj.current read"] --> T{"effect_tracking()?"}
        T -->|"inside effect / derived"| CS["createSubscriber:<br/>ref-counted lazy store.subscribe<br/>change -> update() -> version source"]
        CS --> V["return cached value<br/>(effect re-runs on change)"]
        T -->|"untracked context"| G["get(store):<br/>subscribe + immediate unsubscribe"]
    end
    subgraph TS["toStore(get, set)"]
        E["$state / getter"] --> RE["render_effect re-reads get()<br/>inside effect_root captured at call time"]
        RE --> WS["writable.set(value)"]
    end
```

Details and the server variants: [stores_interop.md](stores_interop.md).

---

## 5. Integration with the wider system

The stores module is a *leaf* in the package graph — it consumes the reactive engine but nothing consumes it from within the compiler. Its touch points:

- **Reactive Runtime Engine** — the compile-generated counterpart of store usage lives in the internal runtime (`store_get`, `store_set`, `store_mutate`, `setup_stores`, `invalidate_store`, `mark_store_binding` in `internal/client/reactivity/store.js`). This is what `$store` syntax in templates compiles to; documented in the Reactive Runtime Engine module: [client_runtime_core_stores.md](client_runtime_core_stores.md). The server-side store helpers (`store_get`, `store_mutate`, `unsubscribe_stores`) are part of [server_runtime_rendering_core.md](server_runtime_rendering_core.md).
- **Compiler Back-End** — client/server transform visitors rewrite `$store` references and `bind:` against stores into the internal calls above ([compiler_client_transform.md](compiler_client_transform.md), [compiler_server_transform.md](compiler_server_transform.md)). The store module itself stays compiler-agnostic.
- **Motion & visual effects** — `svelte/motion` (`tweened`, `spring`) exposes `Tweened<T>`, which extends this module's `Writable<T>` contract; see [motion.md](motion.md).
- **Reactive builtin classes** — `SvelteMap`, `SvelteDate`, `SvelteURL`, `MediaQuery` ([reactive_builtin_classes.md](reactive_builtin_classes.md)) are the runes-native alternative to stores; `fromStore`/`toStore` are the connective tissue between the two worlds.
- **Public API surface** — the store types are re-exported through the package's umbrella type definitions ([public_api.md](public_api.md), [svelte-types.md](svelte-types.md)).
- **Cross-runtime platform services** — `writable`/`derived` use `noop`/`run_all` from the shared utils ([shared_runtime.md](shared_runtime.md)) and `safe_not_equal` from the client runtime's equality module.

---

## 6. API quick reference

| API | Signature (essentials) | Notes |
|---|---|---|
| `writable(value?, start?)` | → `{ set, update, subscribe }` | `start(set, update)` runs on first subscriber; its return value becomes the teardown for the last unsubscribe. |
| `readable(value?, start?)` | → `{ subscribe }` | `writable` with the mutators hidden. |
| `derived(stores, fn, initial?)` | → `Readable<T>` | `fn` receives all values; 2+ args switches to manual `set`/`update` mode with optional cleanup return. |
| `readonly(store)` | → `Readable<T>` | Hides `set`/`update` of a writable. |
| `get(store)` | → `T` | Subscribe + immediate unsubscribe; the canonical "read a store once". |
| `toStore(get, set?)` | → `Readable<V>` / `Writable<V>` | Wrap a getter (typically over `$state`) as a store. Client: reactive via effects. Server: static snapshot. |
| `fromStore(store)` | → `{ current }` | Writable stores get a settable `current`; readable stores a readonly one. Client: reactive inside effects. Server: re-reads on every access. |

### Minimal usage

```js
import { writable, derived, get } from 'svelte/store';
import { fromStore, toStore } from 'svelte/store';

// classic stores
const count = writable(0);
const doubled = derived(count, (n) => n * 2);
count.update((n) => n + 1);
get(doubled); // 2

// bridge to runes
let n = $state(0);
const asStore = toStore(() => n, (v) => (n = v)); // store view of runes state
const asState = fromStore(count);                 // runes view of a store
asState.current; // reactive in templates/effects
```
