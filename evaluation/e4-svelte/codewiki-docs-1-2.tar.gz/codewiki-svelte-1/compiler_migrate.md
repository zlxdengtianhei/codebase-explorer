# Compiler Migrate Module

## 1. Introduction & Purpose

The `compiler_migrate` module implements **automated source-to-source migration of Svelte components** from the legacy Svelte 4 syntax (props via `export let`, `$:` reactive statements, `on:`/`on:` event directives, `<slot>` elements, `$$props`/`$$restProps`/`$$slots`) to the Svelte 5 runes-based syntax (`$props()`, `$bindable()`, `$state()`, `$derived()`, `$effect()`, event attributes, `{#snippet}` blocks and `{@render}` tags).

Its public entry point is the `migrate(source, options)` function, which performs a **best-effort, structure-preserving rewrite**:

- It re-uses the compiler's own front-end ([compiler_parser](compiler_parser.md), [compiler_analyzer](compiler_analyzer.md)) to fully *understand* the legacy component (scopes, bindings, reactive statements, slot usage).
- It never re-generates code from the AST. Instead it records precise, character-level edits into a [`MagicString`](https://github.com/Rich-Harris/magic-string) buffer, so **all original formatting, comments and non-legacy code are preserved exactly**.
- When a construct is too complex to migrate safely, it does not fail the build — it inserts a `<!-- @migration-task: ... -->` HTML comment, leaves the original source untouched and logs a reminder. Migration always produces *compilable output or an explicit to-do marker*, never silent breakage.

Typical consumers are the `sv migrate` CLI tool, IDE integrations and test-harness scripts that upgrade large codebases component-by-component.

## 2. Position in the Overall System

```
Source_Migration___Preprocessing_Tooling
├── compiler_migrate          ← this module
└── compiler_preprocess       → compiler_preprocess.md
```

The module is part of the **Source Migration & Preprocessing Tooling** top-level group. Unlike the compile pipeline (parse → analyze → transform), migration runs the front-end phases in *read-only* fashion and then edits the *original source text*, not the AST.

Its building blocks are imported from sibling modules:

| Dependency | Imported from | Used for |
|---|---|---|
| `parse` | [compiler_parser](compiler_parser.md) (1-parse) | Turning source into the Svelte AST (`Root` with `instance`, `module`, `fragment`, `css`, `options`) |
| `analyze_component` | [compiler_analyzer](compiler_analyzer.md) (2-analyze) | Producing `ComponentAnalysis`: scopes, `Binding` kinds (`bindable_prop`, `state`, `legacy_reactive`, `store_sub`…), `reactive_statements` ordering, `uses_props`/`uses_rest_props`/`uses_slots` flags |
| `get_rune`, `Scope` | [compiler_analyzer_scope](compiler_analyzer_scope.md) (phases/scope.js) | Detecting already-migrated rune calls, unique-name generation |
| `reset`, `UNKNOWN_FILENAME` | [compiler_core_state](compiler_core_state.md) (state.js) | Resetting compiler-global warning/state before analysis |
| `validate_component_options` | [compiler_core_options](compiler_core_options.md) (validate-options.js) | Building a valid `ValidatedCompileOptions` object for analysis |
| `migrate_svelte_ignore` | this module (see below) | Rewriting legacy `svelte-ignore` codes |
| `is_reserved`, `is_void`, `is_svg` | shared `utils.js` | Identifier & element validation |
| `regex_valid_component_name`, `regex_is_valid_identifier` | [compiler_parser](compiler_parser.md), [compiler_analyzer](compiler_analyzer.md) helpers | Validating generated snippet/component names |
| warnings (`w.codes`, `legacy_code`, `unknown_code`) | [compiler_diagnostics](compiler_diagnostics.md) | (via `extract_svelte_ignore.js`) warning surfacing during analysis |

## 3. Architecture Overview

The module consists of two source files:

1. **`compiler/migrate/index.js`** — the migration engine: the `migrate()` orchestrator, the two `zimmerframe` visitor sets (`instance_script` and `template`), and the transformation helpers (`extract_type_and_comment`, `handle_events`, `handle_identifier`, `migrate_slot_usage`, `trim_block`).
2. **`compiler/utils/extract_svelte_ignore.js`** — shared utility file containing `extract_svelte_ignore` (used by the analyzer to consume ignore comments) and **`migrate_svelte_ignore`**, which rewrites legacy ignore codes to their modern underscore-style equivalents; it belongs to this module because it is the piece that *edits source text* rather than merely parsing it.

```mermaid
flowchart TB
    subgraph CM["compiler_migrate"]
        M["migrate()<br/>(orchestrator)"]
        IS["instance_script<br/>visitors"]
        TP["template<br/>visitors"]
        ET["extract_type_and_comment"]
        HE["handle_events"]
        HI["handle_identifier"]
        MS["migrate_slot_usage"]
        TB["trim_block"]
        SI["migrate_svelte_ignore"]
        State["State<br/>(scope · MagicString · props ·<br/>legacy_imports · names · derived maps)"]
    end

    subgraph FE["Compiler front-end (read-only)"]
        P["parse()"]
        A["analyze_component()"]
    end

    SRC["Svelte 4 source"] --> P --> AST["AST + options"]
    AST --> A --> AN["ComponentAnalysis<br/>scopes · bindings · reactive_statements"]
    SRC --> MS2["MagicString(source)"]
    AN --> M
    M --> State
    M -->|walk instance.content| IS
    M -->|walk fragment| TP
    IS --> HI
    IS --> SI
    IS --> ET
    TP --> HI
    TP --> MS
    TP --> HE
    TP --> TB
    TP --> SI
    HE & HI & MS & ET & TB -->|record edits| MS2
    IS -->|record edits| MS2
    M -->|props/derived/imports insertion,<br/>reactive statement reordering| MS2
    MS2 --> OUT["Migrated Svelte 5 source<br/>or @migration-task comment + original"]
```

### 3.1 Migration pipeline (per component)

```mermaid
sequenceDiagram
    participant Caller as CLI / tooling
    participant Mig as migrate()
    participant Parser as compiler_parser
    participant Analyzer as compiler_analyzer
    participant Walk as zimmerframe visitors
    participant Str as MagicString

    Caller->>Mig: source, { filename, use_ts }
    Mig->>Mig: blank <style> contents (preprocessor safety)
    Mig->>Parser: parse(source)
    Parser-->>Mig: Root AST (instance/module/fragment/options)
    Mig->>Analyzer: analyze_component(root, source, options)
    Analyzer-->>Mig: ComponentAnalysis (scopes, bindings, flags)
    Mig->>Walk: walk(instance.content, State, instance_script)
    Note over Walk: export let → $props/$bindable,<br/>$: → $derived/$state/run(),<br/>imports & comments
    Mig->>Walk: walk(fragment, State, template)
    Note over Walk: on: → onclick,<br/>slot → {#snippet}/{@render},<br/>$$props/$$slots → props
    Mig->>Str: insert props declaration, legacy imports,<br/>reorder reactive statements, derived consts
    Mig->>Mig: migrate_css() → :global() wrapping
    Str-->>Caller: migrated code
    Note over Mig: On MigrationError: emit<br/><!-- @migration-task --> + original source
```

## 4. Sub-modules

The module is documented in three focused sub-module files (all stored flat in this documentation directory):

| Sub-module | Documentation file | Core components |
|---|---|---|
| Migration Entry Point & Orchestration | 📄 [compiler_migrate_api.md](compiler_migrate_api.md) | `migrate()`, `extract_type_and_comment()` |
| Source Transformation Helpers | 📄 [compiler_migrate_transformations.md](compiler_migrate_transformations.md) | `handle_identifier()`, `handle_events()`, `migrate_slot_usage()`, `trim_block()` |
| Svelte-Ignore Comment Migration | 📄 [compiler_migrate_svelte_ignore.md](compiler_migrate_svelte_ignore.md) | `migrate_svelte_ignore()` |

### 4.1 Migration Entry Point & Orchestration
📄 [compiler_migrate_api.md](compiler_migrate_api.md)

Covers the public `migrate()` function — source preparation (CSS blanking, option combination), `State` construction (unique names, prop collection, legacy import tracking), the instance-script rewrite rules (`export let` → `$props()`/`$bindable()`, `$:` → `$derived`/`$state`/`run()`, `BreakStatement` in `$:` blocks → `return`, `svelte:options accessors` removal), props/interface/typedef generation, reactive-statement reordering for declaration order, and the migration-task fallback strategy. Also includes `extract_type_and_comment`, which salvages TypeScript annotations and JSDoc from legacy `export let` declarations.

### 4.2 Source Transformation Helpers
📄 [compiler_migrate_transformations.md](compiler_migrate_transformations.md)

Covers the shared rewrite helpers invoked from both visitor sets: `handle_identifier` (`$$props`/`$$restProps`/`$$slots` and `$$Props` interface elimination), `handle_events` (`on:click|preventDefault|once` → `onclick={preventDefault(...)}` with Svelte-4 modifier ordering), `migrate_slot_usage` (`slot="name"` + `let:` → `{#snippet name(...)}` / `{@render}` including default-slot splitting and shadow detection), and `trim_block` (cosmetic whitespace normalization inside `{#if}`/`{#await}`/`{@html}`/`{@const}` blocks).

### 4.3 Svelte-Ignore Comment Migration
📄 [compiler_migrate_svelte_ignore.md](compiler_migrate_svelte_ignore.md)

Covers `migrate_svelte_ignore` from `compiler/utils/extract_svelte_ignore.js`: rewriting deprecated kebab-case warning codes inside `<!-- svelte-ignore ... -->` comments and `// svelte-ignore ...` lines to the new snake_case codes (e.g. `unused-export-let` → `export_let_unused`), with comma separation for multi-code ignores.

## 5. Transformation Matrix

| Legacy (Svelte 4) | Migrated (Svelte 5) | Handled by |
|---|---|---|
| `export let x = 1;` (+ types/JSDoc) | `let { x = 1 }: Props = $props();` | `instance_script` + `extract_type_and_comment` |
| `export let x = 1;` (reassigned / `bind:`) | `let { x = $bindable(1) } = $props();` | `instance_script` |
| `let x = 0;` reassigned in `$:`/template | `let x = $state(0);` | `instance_script` |
| `$: doubled = x * 2;` | `let doubled = $derived(x * 2);` | `instance_script` |
| `$: sideEffect(x)` | `run(() => { sideEffect(x); })` (+ `svelte/legacy` import) | `instance_script` |
| `$: { ... break $; }` | `run(() => { ... return; })` | `instance_script` |
| `$: foo = constant;` | `let foo = $state(constant);` | `instance_script` |
| `on:click={fn}` / `on:click` | `onclick={fn}` / `onclick={bubble('click')}` | `handle_events` |
| `on:click|preventDefault\|once` | `onclick={once(preventDefault(fn))}` | `handle_events` |
| `on:click|passive` | `use:passive={['click', () => fn]}` | `handle_events` |
| `<slot name="x" let:p>fallback</slot>` | `{#if x}{@render x({ p })}{:else}fallback{/if}` | `migrate_slot_usage` / `SlotElement` |
| `slot="x"` + `let:` on child of component | `{#snippet x(...)}` wrapping | `migrate_slot_usage` |
| `$$slots.x`, `$$restProps`, `$$props` | `x`, `rest`, `props` generated names | `handle_identifier` |
| `$$Props<T>` interface | merged into generated `Props` interface | `handle_identifier` |
| `<svelte:self>` | self-import of the file (or migration-task) | `template` visitor |
| `<svelte:component this={X}>` | `<X>` (+ `{@const}`/`$derived` extraction) | `template` visitor |
| `context="module"` | `module` script attribute | `migrate()` |
| `<svelte:options accessors>` | attribute stripped; `export { x }` re-added if needed | `migrate()` |
| legacy `svelte-ignore` codes | snake_case replacements | `migrate_svelte_ignore` |
| `:not(:global(...))`, `:is(...)`, `:has(...)` CSS | `:global()` wrappers normalized | `migrate_css` |

## 6. Error-Handling Philosophy

- **`MigrationError`** — thrown when a rewrite would be unsafe (unsupported destructured exports, `$$props` mixed with named props, name collisions with `$props`/`$state`/`$derived`/`$bindable` runes, slot names that are not valid identifiers or would shadow parent props, `beforeUpdate`/`afterUpdate` imports that are actually used).
- **Graceful degradation** — any thrown error (migration or compiler) aborts the rewrite and returns the original source prefixed with `<!-- @migration-task Error while migrating Svelte code: ... -->`; a console reminder is logged.
- **Untouched source invariant** — because all edits flow through `MagicString` offset operations (no string regeneration), a partially migrated file is still valid Svelte 4 code that can be migrated again.

## 7. Related Modules

- [compiler_parser](compiler_parser.md) — parsing and TS-node stripping consumed by `migrate()`.
- [compiler_analyzer](compiler_analyzer.md) — `analyze_component`, scopes and binding kinds that drive every rewrite decision; [compiler_analyzer_scope](compiler_analyzer_scope.md) provides `get_rune`/unique-name generation.
- [compiler_core](compiler_core.md) — `reset()` state handling, option validation, and AST builder utilities.
- [compiler_diagnostics](compiler_diagnostics.md) — warning codes referenced when validating ignore comments.
- [compiler_preprocess](compiler_preprocess.md) — sibling module for running user preprocessors (migration deliberately *skips* preprocessing by blanking `<style>` instead).
- [legacy_compat](legacy_compat.md) — the `svelte/legacy` package whose `run`, `handlers`, `preventDefault`, … helpers the migrated output imports.
