# Client Runtime Core — Runtime (Reactivity Kernel)

> **Module:** `client_runtime_core_runtime` · **Subsystem:** [Reactive Runtime Engine (Signals, Effects & Batching with Dev-Mode Instrumentation)](Reactive_Runtime_Engine_(Signals,_Effects___Batching_with_Dev-Mode_Instrumentation).md)
>
> **Source files:**
> - `packages/svelte/src/internal/client/runtime.js`
> - `packages/svelte/src/internal/client/loop.js`

---

## 1. Introduction

`client_runtime_core_runtime` is the **kernel of Svelte 5's client-side reactive runtime**. Every reactive read, every dependency edge, every effect re-run, and every flush boundary in the browser ultimately passes through `runtime.js`. It owns:

1. **The global execution/tracking state** — which reaction is currently running, whether we are untracking, whether an effect is being destroyed, and the monotonically increasing *write / read / update version* counters that make dirty-checking cheap.
2. **The core algorithms** — dependency registration (`get`), dependency diffing and graph rewiring (`update_reaction` / `remove_reactions`), lazily-evaluated dirtiness propagation (`is_dirty`), and the effect lifecycle driver (`update_effect`).
3. **Time-boundary helpers** — `tick()` and `settled()`, which let user code and compiled output await the moment at which all pending state changes have been applied.
4. **The `requestAnimationFrame` task loop** (`loop.js`) — the pump that drives per-frame work such as transitions, animations and tweens.

This module is deliberately *stateless with respect to application data*: signals, deriveds, effects and batches are data structures created and owned by the sibling subsystems listed below. The runtime kernel only manipulates their flags and links and provides the recursion machinery that walks the reactive graph.

---

## 2. Position in the System

The module sits at the center of the client reactive runtime. Sibling subsystems provide the *node types* (sources, deriveds, effects), the *scheduler* (batching), and the *proxies*; this module provides the *edge construction* and *execution order* logic that ties them together.

```mermaid
flowchart TB
    subgraph OUT["Consumers (upstream)"]
        API["Public API<br/>(mount / hydrate / unmount / tick)"]
        DOMR["Client DOM Renderer<br/>(blocks, elements, bindings)"]
        COMPILED["Compiled component output<br/>($.get / $.set / templates)"]
    end

    subgraph KERNEL["client_runtime_core_runtime — this module"]
        RT["runtime.js<br/>get · update_reaction · update_effect<br/>is_dirty · tick · settled"]
        LP["loop.js<br/>loop · run_tasks"]
    end

    subgraph SIB["Sibling reactivity subsystems"]
        SRC["sources<br/>(set, update, old_values)"]
        DRV["deriveds<br/>(execute_derived, update_derived)"]
        EFF["effects<br/>(teardown, destroy children)"]
        BAT["batching<br/>(Batch, flushSync, schedule_effect)"]
        SIG["signal model<br/>(flags, equality)"]
        PRX["proxies · props · stores · async"]
    end

    DEV["client_dev_mode<br/>(tracing, HMR, ownership)"]
    DIAG["client_runtime_core_diagnostics<br/>(errors, warnings, validation)"]

    API -->|"flush boundaries"| RT
    COMPILED -->|"reads"| RT
    DOMR -->|"reads / updates"| RT
    RT <-->|"is_dirty / update_derived"| DRV
    RT <-->|"teardown / destroy"| EFF
    RT <-->|"schedule_effect / flushSync<br/>batch_deriveds cache"| BAT
    RT -->|"old_values during destroy"| SRC
    RT -->|"flag bitmasks"| SIG
    LP -->|"raf.now / raf.tasks / raf.tick"| MOTION["Motion & transitions<br/>(tweened, spring, draw/fly/…)"]
    RT -.->|"dev hooks"| DEV
    RT -->|"handle_error"| DIAG
    PRX -->|"proxy traps call get/set"| RT
```

For the scheduler side of the picture (how effects are queued and committed), see [client_runtime_core_batching](client_runtime_core_batching.md). For the node types themselves, see [client_runtime_core_signal_model](client_runtime_core_signal_model.md), [client_runtime_core_sources](client_runtime_core_sources.md), [client_runtime_core_deriveds](client_runtime_core_deriveds.md) and [client_runtime_core_effects](client_runtime_core_effects.md).

---

## 3. Global Execution State

`runtime.js` intentionally uses module-level mutable variables instead of an object holding "current" context. This keeps the hot path (signal reads) free of allocations. All of this state is saved/restored in stack discipline by `update_reaction` and `update_effect` (see §6).

| Variable | Type | Meaning |
|---|---|---|
| `active_reaction` | `Reaction \| null` | The derived/effect currently executing; **new signal reads are registered as its dependencies**. |
| `active_effect` | `Effect \| null` | The effect currently executing (used for ownership, boundary lookup, teardown rules). |
| `untracking` | `boolean` | Set by `untrack(fn)`; while `true`, `get()` does not register dependencies. |
| `is_updating_effect` | `boolean` | `true` while an effect body is running (affects `skip_reaction` for unowned deriveds). |
| `is_destroying_effect` | `boolean` | `true` while an effect subtree is being torn down; `get()` resolves reads from `old_values` (see §7.4). |
| `current_sources` | `Source[] \| null` | Sources **created** inside the current reaction; reads/writes of these within the same reaction do not self-invalidate. |
| `new_deps` + `skipped_deps` | `Value[] \| null`, `number` | Dependency diffing scratch space. The fast path: if the reaction reads the *same* dependencies in the *same order* as last run, only a counter is bumped (no allocation). |
| `untracked_writes` | `Source[] \| null` | Writes made inside a reaction that the reaction does not (yet) depend on — fed to `schedule_possible_effect_self_invalidation` so self-invalidation still happens later. |
| `skip_reaction` | `boolean` | `true` for **unowned** deriveds executed outside an effect update; prevents registering reactions and de-duplicates deps (GC leak protection for chain reads without an active container). |
| `write_version` | `number` | Global counter, `++` on every source write (via `increment_write_version`, called by `sources.set`). Drives dirty checks: `dependency.wv > reaction.wv`. Starts at 1 so tracing can distinguish created vs. run deriveds. |
| `read_version` | `number` | Bumped per reaction run (and when returning to an outer reaction); stamps `signal.rv` to de-duplicate dependency registration inside a single run. |
| `update_version` | `number` | Snapshot of the read version for the current update cycle (managed with `set_update_version`). |

State is mutated only through the exported setters (`set_active_reaction`, `set_active_effect`, `set_untracked_writes`, `set_is_updating_effect`, `set_is_destroying_effect`, `set_update_version`), which sibling modules (`effects.js`, `deriveds.js`, `batch.js`, DOM blocks) call around their own operations.

---

## 4. Signal Status State Machine

Every `Signal` carries a flags bitmask (`signal.f`, see [client_runtime_core_signal_model](client_runtime_core_signal_model.md)). The three *status* bits — `DIRTY`, `MAYBE_DIRTY`, `CLEAN` — are exclusively manipulated here through `set_signal_status` (which clears the status bits with `STATUS_MASK` before OR-ing in the new status):

```mermaid
stateDiagram-v2
    [*] --> CLEAN : signal created

    CLEAN --> MAYBE_DIRTY : upstream source written<br/>(MAYBE_DIRTY = check me lazily)
    CLEAN --> DIRTY : direct write to a<br/>dependency of this reaction

    MAYBE_DIRTY --> DIRTY : is_dirty() finds<br/>dep.wv > reaction.wv
    MAYBE_DIRTY --> CLEAN : is_dirty() verified deps<br/>unchanged (dep.wv <= reaction.wv)

    DIRTY --> CLEAN : update_reaction / update_effect<br/>runs the reaction

    CLEAN --> DESTROYED : branch unmounted (effects.js)
    MAYBE_DIRTY --> DESTROYED : branch unmounted (effects.js)
    DESTROYED --> [*]
```

Design invariant: **`MAYBE_DIRTY` is the lazy middle state.** Writing a source marks direct dependents `DIRTY`, but transitive dependents are only marked `MAYBE_DIRTY`; whether they truly re-run is decided later by `is_dirty()` walking the dependency chain and comparing write versions. This turns "fan-out on write" into "fan-in on read" wherever possible.

---

## 5. Exported API Surface

### 5.1 `runtime.js`

| Export | Signature | Purpose |
|---|---|---|
| `get` | `get<V>(signal: Value<V>): V` | **The read primitive.** Registers the dependency on `active_reaction`, resolves deriveds lazily, consults batch/destroy caches, and throws deferred errors (§7). Used by compiled output as `$.get`. |
| `safe_get` | `safe_get<V>(signal?: Value<V>): V \| undefined` | Null-safe wrapper around `get`. Used for `var` declarations that may be read before their signal exists. |
| `untrack` | `untrack<T>(fn: () => T): T` | Runs `fn` with `untracking = true` — reads inside do **not** create dependencies. Publicly documented (`svelte` docs → `untrack`). |
| `tick` | `tick(): Promise<void>` | Resolves once pending state changes have been applied (§8.1). |
| `settled` | `settled(): Promise<void>` | *Since 5.36.* Resolves once state changes **and all resulting async work** have settled and the DOM is updated (§8.2). |
| `is_dirty` *(internal)* | `is_dirty(reaction: Reaction): boolean` | Lazily decides whether a `MAYBE_DIRTY` reaction must re-run; also **reconnects** disconnected/unowned deriveds to the graph. |
| `update_reaction` *(internal)* | `update_reaction(reaction: Reaction): unknown` | Runs a reaction's function with dependency tracking and graph diffing (§6.1). |
| `update_effect` *(internal)* | `update_effect(effect: Effect): void` | Full effect update cycle: destroy children → teardown → run → record (§6.2). |
| `remove_reactions` *(internal)* | `remove_reactions(signal, start_index)` | Unlinks reaction↔dependency edges from an index onwards; may *disconnect* deriveds with no remaining reactions (GC). |
| `set_signal_status` *(internal)* | `set_signal_status(signal, status)` | Atomically replaces the CLEAN/MAYBE_DIRTY/DIRTY status bits. |
| `schedule_possible_effect_self_invalidation` *(internal)* | `(signal, effect, root?)` | Propagates `untracked_writes` so an effect that wrote to a source it later reads still re-runs. |
| `push_reaction_value` *(internal)* | `push_reaction_value(value: Value)` | Registers sources created inside the current reaction into `current_sources` (self-invalidation guard). |
| `deep_read_state` / `deep_read` *(internal)* | `(value) => void` | Touch every property of a (possibly proxied) value so all nested `$state` reads are captured; used e.g. for `each` keys and spread handling (§9). |
| `exclude_from_object` *(internal)* | `(obj, keys) => Record<string, unknown>` | Rest-props helper for compiled output (`let { a, ...rest } = $props()`). |
| State setters | `set_active_reaction`, `set_active_effect`, `set_untracked_writes`, `set_is_updating_effect`, `set_is_destroying_effect`, `set_update_version`, `increment_write_version` | Stack-manipulation primitives consumed by `effects.js`, `deriveds.js`, `batch.js`, DOM blocks and dev tooling. |

### 5.2 `loop.js`

| Export | Signature | Purpose |
|---|---|---|
| `loop` | `loop(callback: TaskCallback): Task` | Creates a per-frame task. The callback receives `now` (from `raf.now()`) each animation frame; returning a falsy value (or calling `abort()`) removes the task and fulfills the returned `promise`. First task schedules `raf.tick(run_tasks)`; the pump re-arms itself while tasks remain. |
| `run_tasks` *(internal)* | `() => void` | The rAF pump: iterates `raf.tasks`, invoking each callback with `raf.now()` (deliberately *not* the rAF callback argument, to avoid timestamp skew), deleting fulfilled tasks and re-ticking if the set is non-empty. |

`loop.js` has exactly one dependency — the `raf` abstraction in `timing.js` — and no knowledge of reactivity. It is the execution substrate for the [Motion & Visual Effects System](Motion___Visual_Effects_System.md) (`tweened`, `spring`, `draw/fly/scale/…` transitions) and for `animate:flip`.

---

## 6. Core Algorithms

### 6.1 `update_reaction` — run a reaction with dependency tracking

This is the most intricate function in the runtime. Its contract: execute `reaction.fn()`, and afterwards `reaction.deps` must **exactly** describe the set of signals the function actually read.

```mermaid
flowchart TB
    A["update_reaction(reaction)"] --> B["Save globals:<br/>new_deps · skipped_deps · untracked_writes<br/>active_reaction · skip_reaction · current_sources<br/>component_context · untracking · update_version"]
    B --> C["Initialize tracking:<br/>new_deps = null, skipped_deps = 0,<br/>active_reaction = reaction (unless branch/root effect)"]
    C --> D{"reaction.ac (async<br/>controller) stale?"}
    D -->|yes| E["Abort via without_reactive_context<br/>(STALE_REACTION), clear ac"]
    D -->|no| F
    E --> F["run reaction.fn()<br/>(reads call get → populate new_deps<br/>or fast-path skipped_deps++)"]
    F --> G{"new_deps?"}
    G -->|"yes (deps changed)"| H["remove_reactions(reaction, skipped_deps)<br/>resize deps array, register reaction<br/>into each new dep.reactions<br/>(unless skip_reaction)"]
    G -->|no| I{"skipped_deps < deps.length?"}
    I -->|yes| J["remove_reactions for the tail —<br/>shorter deps list this run"]
    I -->|no| K
    H --> K{"is_runes() ∧ untracked_writes<br/>∧ reaction is an effect?"}
    K -->|yes| L["schedule_possible_effect_self_invalidation<br/>for each untracked write"]
    K -->|no| M{"returning to a different<br/>outer reaction?"}
    L --> M
    M -->|yes| N["read_version++<br/>merge untracked_writes outward"]
    M -->|no| O["clear ERROR_VALUE flag on success"]
    N --> O
    O --> P["restore all globals (finally)"]
    P --> Q["return fn() result"]
    F -. "throws" .-> R["handle_error(error)<br/>→ boundary / deferred ERROR_VALUE"]
    R --> P
```

Key optimizations and subtleties:

- **Stable-deps fast path.** As long as `get()` observes the same dependency at `deps[skipped_deps]` as last run, it just increments `skipped_deps`; `new_deps` stays `null` and **no arrays are allocated**. Only the first deviating read materializes `new_deps`.
- **Reconnection.** If a derived was previously `DISCONNECTED` (its last reader went away) or `UNOWNED`, `is_dirty()` re-links it to its dependencies when an active effect is present, flipping off `DISCONNECTED`/`UNOWNED` flags as appropriate. This lets long-lived deriveds sleep and wake without leaking.
- **Unowned + `skip_reaction`.** Deriveds evaluated with no owning effect set `skip_reaction`, so reads inside them don't register reactions (they are re-evaluated on demand); but deriveds that *already have* reactions still register as reactions themselves so they stay connected.
- **Error routing.** A thrown error is funneled to `handle_error` ([client_runtime_core_diagnostics](client_runtime_core_diagnostics.md)): unowned deriveds get the `ERROR_VALUE` flag and *defer the throw* until the value is read by `get()`; effects inside a `<svelte:boundary>` route the error to the boundary.

### 6.2 `update_effect` — the effect lifecycle driver

```mermaid
flowchart TB
    A["update_effect(effect)"] --> B{"DESTROYED flag?"}
    B -->|yes| Z["return — nothing to do"]
    B -->|no| C["set status CLEAN<br/>push active_effect, is_updating_effect=true<br/>(DEV: push component fn + dev stack)"]
    C --> D{"BLOCK_EFFECT?"}
    D -->|yes| E["destroy_block_effect_children"]
    D -->|no| F["destroy_effect_children"]
    E --> G["execute_effect_teardown(effect)<br/>(run previous teardown fn)"]
    F --> G
    G --> H["teardown = update_reaction(effect)"]
    H --> I["effect.teardown = teardown if fn<br/>effect.wv = write_version"]
    I --> J{"DEV ∧ tracing ∧ effect was DIRTY?"}
    J -->|yes| K["bump wv of sources flagged<br/>set_during_effect, clear flag"]
    J -->|no| L
    K --> L["restore active_effect,<br/>is_updating_effect, DEV context"]
```

Note that branch/root *structural* effects are excluded from dependency tracking inside `update_reaction` (`active_reaction` is set to `null` for them) — they exist to scope child effect lifetimes, not to react.

### 6.3 `is_dirty` — lazy dirtiness resolution

Called by `get()` (for deriveds) and by `Batch.process` (for effects):

1. `DIRTY` ⇒ trivially dirty.
2. `MAYBE_DIRTY` ⇒ walk `reaction.deps`:
   - Recursively `is_dirty(dep)`; if a dependency derived is dirty, eagerly `update_derived(dep)`.
   - If any `dep.wv > reaction.wv` ⇒ dirty.
   - While walking, **reconnect** `DISCONNECTED`/`UNOWNED` deriveds if an active (non-destroyed) effect exists.
3. Otherwise ⇒ set the reaction `CLEAN` (except unowned signals with no active effect, which must stay resolvable) and report not-dirty.

This is the mechanism that makes diamond-shaped dependency graphs re-evaluate each derived **at most once per flush**.

---

## 7. `get()` — The Read Primitive (Data Flow)

Every reactive read in a running application is a call to `get`. Its full data flow:

```mermaid
flowchart TB
    A["get(signal)"] --> B{"captured_signals? <br/>(legacy mode)"}
    B -->|yes| C["capture for invalidate_inner_signals"]
    B -->|no| D{"active_reaction ≠ null ∧ ¬untracking?"}
    C --> D
    D -->|yes| E{"active effect destroyed?<br/>(async derived post-await)"}
    E -->|yes| F["skip registration —<br/>avoid memory leak"]
    E -->|no| G{"inside update cycle?"}
    G -->|"yes (REACTION_IS_UPDATING)"| H{"signal.rv < read_version?"}
    H -->|yes| I{"deps[skipped_deps] === signal?"}
    I -->|"yes (stable order)"| J["skipped_deps++ (fast path)"]
    I -->|no| K["materialize/append new_deps"]
    G -->|"no (after await)"| L["push signal into<br/>reaction.deps + signal.reactions directly"]
    D -->|"no reaction context"| M{"unowned derived<br/>with no deps/effects?"}
    M -->|yes| N["XOR UNOWNED —<br/>ownership transfer to caller"]
    H -->|no| O
    J --> O
    K --> O
    L --> O
    F --> O
    N --> O{"DEV: async effect<br/>read / tracing?"}
    O -->|dev| P["await_reactivity_loss warning,<br/>recent_async_deriveds bookkeeping,<br/>tracing stack capture"]
    O --> Q{"is_destroying_effect?"}
    Q -->|"yes"| R["resolve from old_values;<br/>derived: recompute if dirty ∧ has reactions<br/>or depends_on_old_values"]
    Q -->|"no, is derived"| S{"batch_deriveds cache<br/>(async-mode time travel)?"}
    S -->|hit| T["return cached value"]
    S -->|miss| U{"is_dirty(derived)?"}
    U -->|yes| V["update_derived(derived)<br/>(delegates to deriveds module)"]
    U -->|no| W
    V --> W{"ERROR_VALUE flag?"}
    R --> W
    T --> W
    W -->|yes| X["throw signal.v<br/>(deferred error surfaces here)"]
    W -->|no| Y["return signal.v"]
```

`safe_get` is the trivial null-tolerant variant used by compiled output for `var`-hoisted declarations.

### 7.4 Reads during teardown (`old_values`)

While an effect subtree is destroyed (`is_destroying_effect === true`), sibling cleanup functions may still read state. To keep those reads *consistent* (the values that were visible when the effect last ran), `get()`:

- returns pre-write values recorded by the sources module in `old_values` (see [client_runtime_core_sources](client_runtime_core_sources.md));
- for deriveds, recomputes only if the derived is dirty *with* reactions or `depends_on_old_values` (a conservative recursive check of its dependency chain against `old_values`), then caches the result in `old_values`.

---

## 8. Time Boundaries: `tick()` and `settled()`

### 8.1 `tick()`

```mermaid
sequenceDiagram
    participant U as User / compiled code
    participant T as tick() in runtime.js
    participant B as Batch (client_runtime_core_batching)

    U->>T: await tick()
    alt async_mode_flag
        T->>T: resolve on next requestAnimationFrame
    else legacy/default mode
        T->>T: await Promise.resolve() (one microtask)
        T->>B: flushSync()
        B-->>T: all queued effects flushed, DOM updated
    end
    T-->>U: promise resolves
```

By calling `flushSync` after a microtask, `tick()` guarantees any pending state changes have been applied after one await boundary.

### 8.2 `settled()` (since 5.36)

`settled()` delegates to `Batch.ensure().settled()` — the current batch's deferred promise, which resolves only when the batch **commits** (all render/effect/block effects flushed and DOM branches appended/removed) and no async effects remain in flight (`#pending === 0`). In async mode, multiple batches can coexist ("time travelling"); `settled()` reflects the batch that is current *now*, including async work spawned by it (see [client_runtime_core_batching](client_runtime_core_batching.md) and [client_runtime_core_async](client_runtime_core_async.md)).

---

## 9. Deep-Read Utilities and Compiled-Output Helpers

- **`deep_read_state(value)` / `deep_read(value, visited?)`** — traverse a value and *read every property* so that proxy traps ([client_runtime_core_proxies](client_runtime_core_proxies.md)) record the reads as dependencies. Guards: skip `EventTarget`s, track a `visited` set against cycles, call `getTime()` on `Date`s (covers `SvelteDate`), and invoke custom-prototype getters (via `get_descriptors`) while swallowing getter exceptions. `deep_read_state` applies the cheaper one-level heuristic when the value itself is not proxied.
- **`exclude_from_object(obj, keys)`** — builds the rest-object for `let { a, b, ...rest } = $props()` (see [client_runtime_core_props](client_runtime_core_props.md)).
- **`push_reaction_value`** — records sources created inside the running reaction into `current_sources`, so reading/writing them again inside the same reaction does not self-invalidate (also consulted by `schedule_possible_effect_self_invalidation` when not in async mode).

---

## 10. The `loop.js` Frame Pump

```mermaid
sequenceDiagram
    participant C as Consumer (tweened / transition / animation)
    participant L as loop()
    participant R as raf (timing.js)

    C->>L: loop(callback)
    alt raf.tasks empty
        L->>R: raf.tick(run_tasks)
    end
    L->>R: add task {c: callback, f: fulfill}
    L-->>C: { promise, abort() }

    loop every animation frame while tasks remain
        R->>R: run_tasks(): now = raf.now()
        R->>C: callback(now)
        alt callback returns falsy
            R->>R: delete task, task.f() (fulfil promise)
        end
    end

    C->>L: task.abort()
    L->>R: remove task (callback no longer invoked)
```

Deliberate details:
- `raf.now()` is used rather than the rAF callback timestamp, so all tasks in a frame observe a consistent clock.
- `run_tasks` re-arms itself (`raf.tick(run_tasks)`) only while the task set is non-empty, so the loop costs nothing when idle.

---

## 11. End-to-End Update Flow

How a single `$state` write travels through this module and its siblings:

```mermaid
sequenceDiagram
    autonumber
    participant App as Compiled code ($state++)
    participant Src as sources.set
    participant B as Batch / schedule_effect
    participant Eff as effects.js
    participant RT as runtime.js
    participant DRV as deriveds.js
    participant DOM as DOM backend

    App->>Src: set(source, value)
    Src->>RT: increment_write_version()
    Src->>B: batch.capture(source) + schedule_effect(reactions)
    B->>B: mark DIRTY / MAYBE_DIRTY, queue root effect
    Note over B: microtask (or flushSync) boundary
    B->>RT: is_dirty(effect) / Batch.process
    RT->>Eff: update_effect(effect)
    Eff->>Eff: destroy children, run teardown
    Eff->>RT: update_reaction(effect)
    RT->>App: run effect fn → reads call get()
    RT->>DRV: is_dirty(derived) → update_derived
    DRV-->>RT: recomputed value + new write version
    RT->>RT: diff deps (skipped_deps / new_deps)
    Eff->>DOM: template effects update DOM
    DOM-->>App: UI updated
    Note over B,RT: settled() resolves after commit
```

---

## 12. Error Handling

- `update_reaction` wraps every reaction run in `try/catch` and forwards exceptions to `handle_error` (`error-handling.js`, [client_runtime_core_diagnostics](client_runtime_core_diagnostics.md)):
  - **Unowned derived** (no active effect): flag `ERROR_VALUE` and return — the error is *re-thrown at read time* by `get()`.
  - **Inside a `<svelte:boundary>`** not yet run: delegated to `boundary.error(error)`.
  - **Otherwise**: bubble via the effect tree / nearest boundary.
- `get()` re-throws stored `ERROR_VALUE` payloads on any subsequent read, matching the deferred-throw semantics.
- Reset-on-error behavior of boundaries (`svelte_boundary_reset_onerror`, `svelte_boundary_reset_noop`) lives in the diagnostics module, not here.

---

## 13. Dev-Mode Integration

`runtime.js` is instrumented through `DEV` gates from `esm-env` so that production builds drop the code entirely:

| Concern | Hook | Module |
|---|---|---|
| Ownership validation (mutation errors) | component function / dev stack pushed around effect runs | [client_dev_mode](client_dev_mode.md) → `ownership.js` |
| Reactivity-loss detection across `await` | `w.await_reactivity_loss`, `current_async_effect`, `recent_async_deriveds` in `get()` | [client_dev_mode](client_dev_mode.md) + [client_runtime_core_async](client_runtime_core_async.md) |
| Expression tracing (`trace` option) | `tracing_expressions` / `get_stack` capture in `get()`; `set_during_effect` version bumps in `update_effect` | [client_dev_mode](client_dev_mode.md) → `tracing.js` |
| HMR | consumed indirectly via component wrappers | [client_dev_mode](client_dev_mode.md) → `hmr.js` |
| Stale async controllers | `reaction.ac` aborted with `STALE_REACTION` inside `update_reaction` via `without_reactive_context` | [client_runtime_core_async](client_runtime_core_async.md) |

Legacy-mode interop: `captured_signals` (from `legacy.js`) is populated on every `get()` and later flushed by `invalidate_inner_signals` — see [client_runtime_core_diagnostics](client_runtime_core_diagnostics.md) and the legacy compatibility layer in [Public API Surface & Compatibility Layer](Public_API_Surface___Compatibility_Layer_(Entries,_Type_Contracts,_Extensions___Legacy_Support).md).

---

## 14. Design Invariants (for maintainers)

1. **Stack discipline.** Every mutation of the module-global tracking state must be paired with save/restore (`update_reaction` and `update_effect` are the canonical patterns). Forgetting a restore corrupts dependency tracking globally.
2. **Versions over traversal.** Dirty checks compare `dependency.wv > reaction.wv` — never "recompute to see if it changed". `write_version` only ever increases (`increment_write_version`).
3. **No allocation on the stable path.** `get()` fast-path (`skipped_deps++`) and read-version stamping exist specifically so that reactions with unchanged dependencies run allocation-free.
4. **Deriveds are lazy and disconnectable.** A derived whose last reaction disappears must be `DISCONNECTED`-flagged and GC-able (`remove_reaction`), and transparently reconnected by `is_dirty()`.
5. **Throw points.** Errors are *never* thrown mid-graph-update for unowned deriveds; they are flagged and thrown at `get()` time to keep the flush loop consistent.
6. **`loop.js` is reactivity-agnostic.** Anything needing per-frame callbacks (motion, transitions) goes through `loop()`; never schedule rAF manually in a subsystem.

---

## 15. Related Documentation

**Parent subsystem**
- [Reactive Runtime Engine (Signals, Effects & Batching with Dev-Mode Instrumentation)](Reactive_Runtime_Engine_(Signals,_Effects___Batching_with_Dev-Mode_Instrumentation).md)

**Sibling modules (client runtime core)**
- [client_runtime_core_signal_model](client_runtime_core_signal_model.md) — `Signal` shape, flags, equality semantics
- [client_runtime_core_sources](client_runtime_core_sources.md) — `set`/`update`, `old_values`
- [client_runtime_core_deriveds](client_runtime_core_deriveds.md) — `execute_derived`, `update_derived`, async deriveds
- [client_runtime_core_effects](client_runtime_core_effects.md) — effect tree, teardown, destruction
- [client_runtime_core_batching](client_runtime_core_batching.md) — `Batch`, `flushSync`, scheduling & commit
- [client_runtime_core_proxies](client_runtime_core_proxies.md) — `$state` proxies, `update_path`
- [client_runtime_core_props](client_runtime_core_props.md) — `prop`, `rest_props`, `spread_props`
- [client_runtime_core_stores](client_runtime_core_stores.md) — store interop
- [client_runtime_core_async](client_runtime_core_async.md) — async mode, `async_body`, reactivity-loss tracking
- [client_runtime_core_diagnostics](client_runtime_core_diagnostics.md) — errors, warnings, legacy signal invalidation

**Adjacent systems**
- [client_dev_mode](client_dev_mode.md) — dev instrumentation consumed by this module
- [Component Rendering Backends (Client DOM & Server SSR)](Component_Rendering_Backends_(Client_DOM___Server_SSR).md) — primary consumer of `get`/`update_effect`
- [Motion & Visual Effects System](Motion___Visual_Effects_System.md) — primary consumer of `loop.js`
- [Public API Surface & Compatibility Layer](Public_API_Surface___Compatibility_Layer_(Entries,_Type_Contracts,_Extensions___Legacy_Support).md) — exposes `tick`, `untrack`, `mount`/`hydrate` built on this kernel
