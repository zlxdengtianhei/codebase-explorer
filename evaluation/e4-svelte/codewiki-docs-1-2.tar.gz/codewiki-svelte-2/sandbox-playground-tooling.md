# Sandbox & Playground Tooling (`sandbox-playground-tooling`)

> Module path: `playgrounds/sandbox/` · Parent: **Engineering Tooling (Benchmarks, Verification & Playground)**

## 1. Introduction & Purpose

The `sandbox-playground-tooling` module provides the developer tooling that powers the local Svelte playground sandbox. It is the bridge between a raw `src/` workspace of Svelte sources and two consumption scenarios:

1. **Compiler output inspection** — `run.js` drives every file in the workspace through the *real* Svelte compiler pipeline (`svelte/compiler` package) for both `client` and `server` generation targets, materialising all intermediate and final artifacts under `output/`: AST dumps, migrated (Svelte 4 → 5) source, compiled JavaScript, source maps and extracted CSS. This makes it a Swiss-army knife for debugging compiler behaviour against arbitrary inputs.
2. **Playground state sharing** — `scripts/hash.js` serialises the current `src/` workspace into a compact, gzipped, base64url-encoded URL hash, producing a `https://svelte.dev/playground/untitled#<hash>` link that reproduces the sandbox state anywhere.

The module is intentionally "dumb plumbing": it holds no compiler logic of its own and instead exercises the public compiler APIs, which is exactly what makes it useful as a verification harness for the [Compiler Pipeline & Language Toolchain](compiler-core_public_api.md).

## 2. Architecture Overview

The module contains two independent, single-file tools. They share the `src/` workspace directory as input but never interact with each other at runtime.

```mermaid
flowchart TB
    subgraph src["src/ workspace (playground sources)"]
        S1["**/*.svelte components"]
        S2["**/*.js modules"]
    end

    subgraph tooling["sandbox-playground-tooling"]
        RUN["run.js<br/>batch compiler driver"]
        HASH["scripts/hash.js<br/>share-link generator"]
    end

    subgraph compilerApi["svelte/compiler public API"]
        PARSE["parse()"]
        MIGRATE["migrate()"]
        COMPILE["compile()"]
        COMPILE_MODULE["compileModule()"]
    end

    subgraph out["output/ artifacts"]
        AST["ast/*.json"]
        MIG["migrated/*"]
        JS["{client,server}/*.js + .map"]
        CSS["*.css"]
        TREE["client/*.tree.js"]
    end

    S1 --> RUN
    S2 --> RUN
    RUN --> PARSE
    RUN --> MIGRATE
    RUN --> COMPILE
    RUN --> COMPILE_MODULE
    RUN --> AST & MIG & JS & CSS & TREE
    S2 --> HASH
    HASH --> URL["svelte.dev/playground/untitled#&lt;hash&gt;"]
```

| Tool | Entry point | Input | Output | Invocation |
| --- | --- | --- | --- | --- |
| Batch compiler driver | `playgrounds/sandbox/run.js` | `src/**/*.svelte`, `src/**/*.js` | `output/{ast,migrated,client,server}/*` | `node run.js [--runes]` |
| Share-link generator | `playgrounds/sandbox/scripts/hash.js` | top-level files in `src/` | printable playground URL | `node scripts/hash.js` |

## 3. Sub-modules

This module splits into two focused sub-modules, each with its own detailed documentation page:

- **[Compile Runner](sandbox-playground-tooling_compile-runner.md)** (`sandbox-playground-tooling_compile-runner.md`) — the batch compilation pipeline (`run.js`): workspace discovery, output-directory hygiene, per-target compilation (default *template* fragments *and* the experimental `fragments: 'tree'` mode), AST serialisation, legacy-code migration, the full artifact matrix, and the deliberate warnings/error-handling policy of the `write()` artifact sink.
- **[Share-Link Hasher](sandbox-playground-tooling_share-link-hash.md)** (`sandbox-playground-tooling_share-link-hash.md`) — the playground URL encoder (`scripts/hash.js`): the `compress()` component, JSON payload format contract, streaming gzip compression via `CompressionStream`, URL-safe base64 encoding, and its round-trip relationship with the inverse `scripts/download.js`.

Both sub-module pages link back here and to each other; this overview stays intentionally high-level to avoid duplication.

## 4. Compilation Pipeline (`run.js`)

The driver executes the following steps for each generation target (`'client'`, then `'server'`):

```mermaid
flowchart TD
    A["node run.js [--runes]"] --> B["clean output/ (preserve .gitkeep)"]
    B --> C["globSync src/**/*.svelte and src/**/*.js"]
    C --> D{"for target in ['client', 'server']"}
    D --> E["Svelte components"]
    D --> F["Plain JS modules"]

    E -->|"target = client"| G["parse(source, { modern: true })<br/>→ output/ast/*.json"]
    G --> H["migrate(source)<br/>→ output/migrated/* (best-effort, errors logged)"]
    H --> I["compile(source, { generate: target, runes, experimental.async })"]
    E -->|"target = server"| I
    I --> J["log warnings (code + frame) to stderr"]
    J --> K["write .js / .js.map / .css"]
    K --> L["client only: compile(source, { fragments: 'tree' })<br/>→ .tree.js + .tree.js.map"]
    F --> M["compileModule(source, { generate: target })"]
    M --> N["write compiled .js"]
```

Key behaviours:

- **Artifact matrix** (see the [Compile Runner](sandbox-playground-tooling_compile-runner.md) for detail):

  | Artifact | Location | Producer | Pass |
  | --- | --- | --- | --- |
  | AST JSON (bigint-safe) | `output/ast/<file>.svelte.json` | `parse()` | client |
  | Migrated source | `output/migrated/<file>` | `migrate()` | client |
  | Compiled JS + source map | `output/<target>/<file>.js(.map)` | `compile()` / `compileModule()` | both |
  | Tree-fragment JS + map | `output/client/<file>.tree.js(.map)` | `compile({ fragments: 'tree' })` | client |
  | Extracted CSS | `output/<target>/<file>.css` | `compiled.css` | both, if present |

- **Warnings are surfaced, never fatal**: every `compiled.warnings` entry prints its `code` and a code `frame` to stderr; compilation continues.
- **Migration is best-effort**: `migrate()` failures are caught per-file with `console.warn`, so one unmigratable component cannot abort the batch.
- **`--runes` CLI flag** (via `node:util.parseArgs`) is forwarded to `compile()` to force rune mode on legacy-looking sources.
- **`experimental: { async: true }`** is enabled on every `compile`/`compileModule`/`migrate` path so the experimental async features are always exercised.
- The shared `write()` helper (core component) guarantees parent directories exist before each `fs.writeFileSync`, acting as `mkdirp` + write for every artifact.

## 5. Share-Link Generation (`scripts/hash.js`)

The hasher implements the inverse of `scripts/download.js` (which decodes playground URLs back into files): it turns the workspace into the canonical playground URL payload.

```mermaid
flowchart LR
    A["fs.readdirSync('src')<br/>(top-level files only)"] --> B["JSON payload<br/>{ name: 'sandbox', files: [...] }"]
    B --> C["new Blob([payload]).stream()"]
    C --> D["CompressionStream('gzip')"]
    D --> E["read loop:<br/>bytes → String.fromCharCode → buffer string"]
    E --> F["btoa(buffer)"]
    F --> G["URL-safe base64url<br/>'+' → '-', '/' → '_'"]
    G --> H["https://svelte.dev/playground/untitled#&lt;hash&gt;"]
```

Notable encoding subtleties (detailed in the [Share-Link Hasher](sandbox-playground-tooling_share-link-hash.md)):

- Gzip output is binary; bytes are accumulated **as a binary Latin-1-style string** (`String.fromCharCode`) because decoding as UTF-8 would make `btoa` reject the buffer.
- The final base64 is converted to **base64url** so it survives inside a URL fragment unescaped.
- The schema `{ name, files: [{ type, name, basename, contents, text }] }` matches what `svelte.dev/playground` and `scripts/download.js` expect.

## 6. Dependencies

```mermaid
flowchart TB
    subgraph module["sandbox-playground-tooling"]
        RUN["run.js"]
        HASH["scripts/hash.js"]
    end
    subgraph svelteApi["svelte/compiler (Compiler Pipeline module)"]
        C1["compile"]
        C2["compileModule"]
        C3["parse"]
        C4["migrate"]
    end
    subgraph platforms["Node.js & Web platform APIs"]
        N1["node:fs / node:path"]
        N2["node:util parseArgs"]
        N3["tinyglobby globSync"]
        N4["Blob + CompressionStream"]
    end
    RUN --> C1 & C2 & C3 & C4
    RUN --> N1 & N2 & N3
    HASH --> N1
    HASH --> N4
```

**Internal dependencies** — all four consumed compiler functions belong to the [Compiler Pipeline & Language Toolchain](compiler-core_public_api.md) module and are documented there; this module only exercises their public contracts:

- `compile()` / `compileModule()` — public entry points ([compiler-core_public_api](compiler-core_public_api.md))
- `parse()` — template parser ([compiler-parser](compiler-parser.md))
- `migrate()` — Svelte 4 → 5 migration codemod ([compiler-migrator](compiler-migrator.md))

**External dependencies** — `tinyglobby` (globbing) and Node.js ≥ 18 built-ins plus the Web `CompressionStream` API (available in Node 18+).

## 7. How It Fits Into the Overall System

`engine-tooling` groups four verification surfaces around the Svelte codebase; the sandbox tooling is the *manual / interactive* one:

- [Reactivity benchmarks](reactivity-benchmarks.md) and [SSR benchmarks](ssr-benchmarks.md) measure performance quantitatively.
- The treeshakeability checker verifies bundle-size properties of the runtime.
- **Sandbox playground tooling** lets maintainers throw arbitrary components at the compiler and eyeball every artifact it produces — the fastest way to reproduce parser/analyzer/transformer bugs during development.

The generated `output/` tree is intentionally disposable (only `.gitkeep` is preserved on reset) and is *not* wired into CI assertions — it is a developer-facing scratch space. Meanwhile `hash.js`/`download.js` form a symmetric pair for moving playground states between the hosted `svelte.dev/playground` and the local sandbox via `src/`.

## 8. Usage Examples

```bash
# Compile the whole workspace for client and server, forcing runes mode
node playgrounds/sandbox/run.js --runes

# Produce a shareable playground URL for the current src/ contents
node playgrounds/sandbox/scripts/hash.js

# Restore a playground link back into src/ (companion script)
node playgrounds/sandbox/scripts/download.js "https://svelte.dev/playground/untitled#<hash>"
```
