# Template Rendering (`compiler-transformer_server-transform_template-rendering`)

This module is the **HTML-generation core of the Svelte server-side transform** (SSR). It contains the visitors that walk static template AST nodes — fragments, elements, `<svelte:head>`, `<svelte:element>`, `<svelte:boundary>`, `{@html ...}` and `<title>` — and rewrite them into JavaScript statements that *push HTML strings into a payload buffer* at runtime. It is a child module of [server-transform](compiler-transformer_server-transform.md), which in turn belongs to the broader [transformer phase](compiler-transformer.md) of the [Svelte compiler pipeline](compiler.md).

---

## 1. Purpose & Responsibilities

During compilation, a Svelte component is lowered from a template AST into a plain JavaScript function. In the server build, that function receives a single `$$payload` argument (the render payload) and must produce markup by appending to `$$payload.out`. This module owns every visitor that decides **what literal HTML and which runtime helper calls** end up in that output:

| Concern | Owner |
|---|---|
| Fragment/template root rendering | `Fragment` |
| Static HTML elements (`<div>`, `<pre>`, `<select>`, …) | `RegularElement` |
| Dynamic elements (`<svelte:element this={tag}>`) | `SvelteElement` |
| Head content hoisting (`<svelte:head>`) | `SvelteHead` |
| Error/async boundary markers (`<svelte:boundary>`) | `SvelteBoundary` |
| Raw HTML insertion (`{@html ...}`) | `HtmlTag` |
| Document title assignment (`<title>`) | `TitleElement` |

The module deliberately contains **no control flow, component, or script visitors** — those live in the sibling modules [control-flow](compiler-transformer_server-transform_control-flow.md), [components-snippets](compiler-transformer_server-transform_components-snippets.md) and [script-transform](compiler-transformer_server-transform_script-transform.md). Shared helpers (`process_children`, `build_template`, `build_attribute_value`) are documented in [shared-utils](compiler-transformer_server-transform_shared-utils.md); only their behavior contracts are summarized here.

---

## 2. Architecture

### 2.1 Component Overview

```mermaid
graph TD
    subgraph ServerTransform["Server Transform (server/index.js)"]
        REG["Visitor registry<br/>(node type → visitor)"]
    end

    subgraph TemplateRendering["Template Rendering (this module)"]
        FRAG["Fragment"]
        RE["RegularElement"]
        SE["SvelteElement"]
        SH["SvelteHead"]
        SB["SvelteBoundary"]
        HT["HtmlTag"]
        TE["TitleElement"]
    end

    subgraph SharedInfra["Shared visitor infrastructure"]
        ELEM["shared/element.js<br/>build_element_attributes<br/>build_spread_object"]
        UTILS["shared/utils.js<br/>process_children · build_template<br/>build_attribute_value · empty_comment"]
        XFORM["3-transform/utils.js<br/>clean_nodes · infer_namespace<br/>determine_namespace_for_children"]
    end

    subgraph Runtime["Server Runtime (emitted calls)"]
        PAY["$$payload<br/>out · head · title · select_value"]
        RT["$.element · $.head · $.html<br/>$.valueless_option · $.push_element<br/>$.pop_element · $.escape · $.attr"]
    end

    REG --> FRAG & RE & SE & SH & SB & HT & TE

    FRAG --> XFORM & UTILS
    RE --> XFORM & UTILS & ELEM
    SE --> ELEM & UTILS
    TE --> UTILS

    FRAG & RE & SE & SH & SB & HT & TE -- "state.template / state.init" --> PAY
    RE & SE & SH & HT -- "b.call('$.…')" --> RT
```

### 2.2 The Output Buffer Model

All visitors in this module share a common code-generation idiom built on the `ComponentServerTransformState` (see [shared-infrastructure](compiler-transformer_shared-infrastructure.md)):

- **`state.template`** — an ordered buffer of *template pieces*: string literals, tagged-template expressions, and pre-built statement nodes. Sibling visitors and the shared attribute builder append to it in document order.
- **`state.init`** — statements that must run *before* markup emission (e.g. hoisted tag constants, dev-mode `push_element`).
- **`build_template(state.template)`** — flushes the buffer into `$$payload.out.push(\`…\`)` statements, fusing adjacent strings into a single template literal.
- The final visitor result is a block statement: `b.block([...state.init, ...build_template(state.template)])`.

### 2.3 Position in the Compiler Pipeline

```mermaid
flowchart LR
    A["Parse (AST)<br/>compiler-parser"] --> B["Analyze (scopes, metadata,<br/>css hashes, expression metadata)<br/>compiler-analyzer"]
    B --> C{"Phase 3: Transform"}
    C -->|generate: 'client'| D["Client transform<br/>(DOM creation + hydration)"]
    C -->|generate: 'server'| E["Server transform<br/>this module's parent"]
    E --> F["Template Rendering<br/>(this module)"]
    F --> G["ESM JS component:<br/>function App($$payload) {…}"]
    G --> H["Server runtime<br/>(internal/server) at execution"]
```

The visitors consume analysis-phase artifacts produced by [compiler-analyzer](compiler-analyzer.md): element `metadata.svg` / `metadata.mathml` / `metadata.scoped` flags, `metadata.dynamic` on render tags, scope-driven static expression evaluation, and the CSS hash used for scoping. They rely on parser output only indirectly through the AST shape ([compiler-parser](compiler-parser.md)).

---

## 3. Component Deep Dive

### 3.1 `Fragment` — the template entry point

`Fragment` is the visitor that every block, snippet, component body, and the component root eventually delegates to. It converts an `AST.Fragment` into a block statement of emit statements.

Processing steps:

1. **Namespace inference** — `infer_namespace()` inspects the parent node and children to select `html`, `svg`, or `mathml` (e.g. a fragment inside `<svg>` stays `svg`; a `foreignObject` flips back to `html`).
2. **Node cleanup** — `clean_nodes()` partitions children into:
   - **`hoisted`** — nodes rendered ahead of position: `ConstTag`, `DebugTag`, `SvelteBody`, `SvelteWindow`, `SvelteDocument`, `SvelteHead`, `TitleElement`, `SnippetBlock` (title/head/snippets are *executed*, not placed inline);
   - **`trimmed`** — regular nodes after whitespace collapsing (respecting `preserve_whitespace` and `preserveComments` options, `<pre>` newline handling, and HTML contexts where whitespace is meaningless such as `<select>`/`<table>` children);
   - plus two flags: `is_standalone` (single dynamic child, e.g. `{#if x}<Foo />{/if}` → skip hydration boundary comments) and `is_text_first`.
3. **Fresh state** — a child state with empty `init`/`template` buffers is created so nested fragments never leak markup into their parent's buffer.
4. **Hoisted visit** — hoisted nodes are visited first so side-effectful statements (const assignments, snippet declarations) precede markup.
5. **Text-anchor guard** — if `is_text_first`, an `empty_comment` (`<!---->`) is pushed so a leading text node cannot be fused with the previous fragment's trailing text.
6. **Child emission** — `process_children(trimmed, …)` walks the remaining nodes, dispatching back through the visitor registry and grouping adjacent text/comments/expression tags into escaped template literals.
7. **Result** — `b.block([...init, ...build_template(template)])`.

```mermaid
sequenceDiagram
    participant P as Parent visitor<br/>(block/component/root)
    participant F as Fragment
    participant CN as clean_nodes
    participant PC as process_children
    participant T as state.template

    P->>F: visit(fragment, state)
    F->>CN: partition nodes
    CN-->>F: { hoisted, trimmed, is_standalone, is_text_first }
    F->>F: new state { init: [], template: [] }
    F->>F: visit each hoisted node
    alt is_text_first
        F->>T: push "<!---->" anchor
    end
    F->>PC: process_children(trimmed)
    PC->>T: template literals + nested visitor dispatch
    F-->>P: b.block([...init, ...build_template(template)])
```

### 3.2 `RegularElement` — static HTML elements

The largest visitor in the module. For `<div class="x">…</div>` it emits literal open/close tags and delegates attribute work:

1. **Namespace & whitespace** — `determine_namespace_for_children()` (svg/mathml via analysis metadata, `foreignObject` → html); whitespace preservation is forced for `<pre>` and `<textarea>`.
2. **Open tag** — pushes literal `<tag`, then `build_element_attributes()` ([shared-utils](compiler-transformer_server-transform_shared-utils.md)) emits attribute literals, `$.attr()` calls, spread handling, class/style directive merging, CSS-hash scoping, and `onload`/`onerror` capture markers for hydration. It returns a *content expression* for `<textarea>`/contenteditable bindings.
3. **Tag closure** — `/>` for void elements (deliberately XHTML-compliant output) or `>` otherwise.
4. **Raw text shortcut** — `<script>`/`<style>` with a single text child emit the text **verbatim** (no escaping, no child processing).
5. **Dev diagnostics** — in dev builds wraps children with `$.push_element($$payload, name, line, column)` … `$.pop_element()` so the server can report misplaced content (see `dev.js` in the [server-runtime](server-runtime.md) module).
6. **`<select>` value mechanism** — if a `value` attribute, `bind:value`, or a spread containing them is present, `$$payload.select_value` is assigned before children are rendered. Descendant `<option>` handling (`$.maybe_selected`, `$.valueless_option`) compares against it to decide the initially selected option; the field is reset (`= undefined`) after the closing tag.
7. **Content vs. children arbitration** — for `<textarea>` value / contenteditable bindings, children are rendered into a nested buffer and emitted as a conditional:
   `if (body) { payload.out.push(body) } else { <rendered children> }` — attribute wins when truthy.
8. **Close tag** — `</tag>` unless void.

```mermaid
flowchart TD
    A[RegularElement node] --> B{void element?}
    B -->|yes| C["push '<tag' + attributes + '/>'"]
    B -->|no| D["push '<tag' + attributes + '>'"]
    C --> Z{raw text element?<br/>script / style}
    D --> Z
    Z -->|single text child| Y["emit text verbatim, close tag"]
    Z -->|no| E[clean_nodes → hoisted + trimmed]
    E --> F{select with value?}
    F -->|yes| G["payload.select_value = …"]
    F -->|no| H["—"]
    G --> I{option without value?}
    H --> I
    I -->|yes| J["$.valueless_option($$payload, thunk(children))"]
    I -->|no| K{content binding?<br/>textarea / contenteditable}
    J --> K
    K -->|yes| L["if (body) push body<br/>else push rendered children"]
    K -->|no| M["process_children(trimmed)"]
    L --> N{select_with_value?}
    M --> N
    N -->|yes| O["payload.select_value = undefined"]
    N -->|no| P["push closing tag"]
    O --> P
```

### 3.3 `SvelteElement` — `<svelte:element>`

Because the tag is a runtime expression, nothing can be emitted literally. The visitor:

1. Visits the `tag` expression; **in dev**, hoists it into a `const $$tag = …` so getters aren't invoked twice, and inserts `$.validate_void_dynamic_element(...)` / `$.validate_dynamic_element_tag(...)` guards.
2. Builds the attribute statements and children block into **separate nested states**.
3. Emits a single call: `$.element($$payload, tag, attrsThunk?, childrenThunk?)`. Thunks (`() => …`) are omitted when empty, so the runtime only pays evaluation cost for non-empty parts.
4. Wraps with dev `push_element`/`pop_element`.

The runtime `element()` (internal/server) brackets output with `<!---->` anchors and appends an empty comment before non-void closing tags — these markers are what hydration ([client-dom-renderer](client-dom-renderer.md)) later matches against.

### 3.4 `SvelteHead` — `<svelte:head>`

Head content must not appear in the body output. The visitor visits the fragment and emits:

```js
$.head($$payload, ($$payload) => { /* rendered children */ });
```

The runtime redirects writes to `payload.head`, a separate `Payload` instance whose contents the host framework (e.g. SvelteKit) flushes into `<head>`. See [server-runtime_payload-and-output](server-runtime_payload-and-output.md) for payload plumbing.

### 3.5 `SvelteBoundary` — `<svelte:boundary>`

Emits hydration stream markers around the boundary's fallback/pending content:

- pushes literal `BLOCK_OPEN` (`<!--[-->`) and `BLOCK_CLOSE` (`<!--]-->`) imported from `internal/server/hydration.js` (shared constants with the client runtime so hydration can locate block boundaries);
- renders, in priority order:
  1. the `pending` **attribute** — invoked as `pendingFn($$payload)` (rendered immediately as the streaming placeholder),
  2. a `pending` **snippet block** declared among the children,
  3. otherwise the ordinary fragment (the boundary's default content).

The markers let the client-side `boundary` block (see [client-dom-renderer_control-flow-blocks](client-dom-renderer_control-flow-blocks.md)) resume a streamed/failed boundary and know which server HTML to replace.

### 3.6 `HtmlTag` — `{@html …}`

The simplest visitor: visits the expression and emits `$.html(expression)`. The runtime pushes the value **unescaped** into `payload.out`; sanitization is the application author's responsibility.

### 3.7 `TitleElement` — `<title>`

Like `SvelteHead`, the title must be diverted away from body output. The visitor builds a local buffer `<title>` + processed children + `</title>`, then flushes it with `build_template(template, b.id('$$payload.title'), '=')`, i.e. it generates an **assignment** (`$$payload.title += \`<title>…\``) rather than a `payload.out.push(...)`. The payload's `title` channel is consumed by the host during rendering.

---

## 4. End-to-End Data Flow

### 4.1 Compile time (AST → JS)

```mermaid
flowchart TB
    AST["Template AST<br/>(Root → Fragment → nodes)"] --> V["Visitor dispatch<br/>(server/index.js registry)"]

    V -->|Fragment| FR["Fragment"]
    V -->|RegularElement| RE["RegularElement"]
    V -->|svelte:element| SE["SvelteElement"]
    V -->|svelte:head| SH["SvelteHead"]
    V -->|svelte:boundary| SB["SvelteBoundary"]
    V -->|"@html"| HT["HtmlTag"]
    V -->|title| TE["TitleElement"]

    RE & SE --> BA["build_element_attributes<br/>+ build_spread_object"]
    FR & RE & SE --> CN["clean_nodes / namespace utils"]
    FR & RE & TE --> PC["process_children<br/>(escape + template fusing)"]

    BA & CN & PC --> BUF["state.template + state.init buffers"]
    BUF --> BT["build_template →<br/>$$payload.out.push(…) statements"]
    BT --> OUT["Generated SSR component function"]
```

### 4.2 Runtime (generated JS → HTML string)

```mermaid
sequenceDiagram
    participant App as Generated component<br/>App($$payload)
    participant Pay as Payload<br/>(payload.js)
    participant RT as Server runtime<br/>(internal/server)
    participant Host as Host framework<br/>(e.g. SvelteKit)

    Host->>Pay: create payload { out: [], head, title, … }
    Host->>App: App($$payload)
    App->>Pay: $$payload.out.push('<div class="x">')
    App->>RT: $.escape(userText) / $.attr(...) / $.clsx(...)
    App->>Pay: $$payload.out.push('</div>')
    App->>RT: $.head($$payload, fn) — writes into payload.head
    App->>Pay: $$payload.title += '<title>…</title>'
    App->>RT: $.element / $.html / $.valueless_option
    App-->>Host: done
    Host->>Host: payload.out.join('') → body HTML<br/>payload.head.join('') → head HTML
```

### 4.3 Emitted helper → runtime contract

| Emitted call / field | Runtime implementation | Purpose |
|---|---|---|
| `$$payload.out.push(…)` | `payload.js` | append markup chunk |
| `$$payload.title += …` | `payload.js` | diverted title channel |
| `$$payload.select_value = …` | `payload.js` | `<select>` selection state |
| `$.element(payload, tag, attrs?, children?)` | `internal/server/index.js` | dynamic `<svelte:element>` with hydration anchors |
| `$.head(payload, fn)` | `internal/server/index.js` | render into head payload |
| `$.html(expr)` | `internal/server/blocks/html.js` | raw `{@html}` insertion |
| `$.valueless_option(payload, children)` | `internal/server/index.js` | infer `selected` for valueless `<option>` |
| `$.maybe_selected(payload, value)` | `internal/server/index.js` | mark matching `<option>` selected |
| `$.escape(x)`, `$.attr(...)`, `$.clsx(...)` | `internal/server/index.js` | escaping & attribute rendering |
| `$.push_element` / `$.pop_element` | `internal/server/dev.js` | dev-only element stack diagnostics |
| `$.validate_dynamic_element_tag` / `$.validate_void_dynamic_element` | `internal/shared/validate.js` | runtime `<svelte:element>` guards |
| `<!--[-->` / `<!--]-->` / `<!---->` | `internal/server/hydration.js` | block anchors for hydration |

---

## 5. Interaction with Sibling Modules

All server-transform visitors share the same `context.state`/`template` buffer, so ordering is inherently correct: children append after whatever their parent pushed.

- **[control-flow](compiler-transformer_server-transform_control-flow.md)** — `IfBlock`, `EachBlock`, `AwaitBlock`, `KeyBlock` wrap their branches in `BLOCK_OPEN`/`BLOCK_CLOSE` markers and delegate each branch body to `Fragment`, inheriting hoisting, whitespace trimming and text-anchor behavior from this module.
- **[components-snippets](compiler-transformer_server-transform_components-snippets.md)** — `Component`, `RenderTag`, `SnippetBlock`, `SlotElement` visitors emit calls that themselves run other generated components (or inline snippet bodies); `clean_nodes`' `is_standalone` flag tells the *parent* whether hydration anchors can be skipped for a lone child component.
- **[script-transform](compiler-transformer_server-transform_script-transform.md)** — expression visitors (`Identifier`, `AssignmentExpression`, `CallExpression`, `ConstTag`, …) handle runes (`$state`, `$derived`, `$effect` — mostly no-ops server-side) and are invoked by this module whenever `context.visit(expression)` is reached, e.g. inside attribute values or `{@html}`.
- **[shared-utils](compiler-transformer_server-transform_shared-utils.md)** — `process_children` (static-evaluates known expressions, escapes the rest into fused template literals), `build_template` (buffer → statements), `build_attribute_value`, `empty_comment`, plus `build_element_attributes` in `shared/element.js` which returns the textarea/contenteditable "content" expression consumed by `RegularElement`.
- **Client counterpart** — every marker and helper emitted here has a hydration-aware counterpart in the [client runtime](client-dom-renderer.md); the byte-exact `<!--…-->` anchor scheme shared via `constants.js`/`hydration.js` is what makes the two outputs compatible.

---

## 6. Design Notes & Invariants

- **Document-order buffer discipline**: visitors *never* return markup directly; they always mutate `state.template` in encounter order. `Fragment` creates a fresh buffer per nesting level, then flushes — this is what guarantees hoisted statements (const tags, snippets) precede markup.
- **Escaping is centralized**: static text and known-valued expressions are HTML-escaped at compile time; dynamic expressions are wrapped in `$.escape()` at runtime. The only deliberate escape hatch is `{@html}`.
- **XHTML-friendly output**: void elements close with `/>`; hydration anchors are standard comments, so output remains parseable as both HTML and XHTML.
- **Whitespace correctness**: `clean_nodes` implements the spec-sensitive trimming rules (`<pre>` leading newline, `<select>`/table-family whitespace removal, `white-space: pre-line`-friendly collapsing) and forces preservation inside `<pre>`/`<textarea>` regardless of options.
- **Dev-only code is conditional**: `push_element`/`pop_element`, tag-evaluation hoisting, and dynamic-element validation are emitted only when `dev` is set, keeping production output lean.
- **Titles/head never touch body output**: both `SvelteHead` and `TitleElement` route content to dedicated payload channels, matching how server hosts assemble the final document.

## 7. Related Documentation

- Parent phase: [compiler-transformer](compiler-transformer.md) · [server-transform](compiler-transformer_server-transform.md)
- Siblings: [control-flow](compiler-transformer_server-transform_control-flow.md) · [components-snippets](compiler-transformer_server-transform_components-snippets.md) · [script-transform](compiler-transformer_server-transform_script-transform.md) · [shared-utils](compiler-transformer_server-transform_shared-utils.md)
- Upstream phases: [compiler-parser](compiler-parser.md) · [compiler-analyzer](compiler-analyzer.md)
- Downstream runtime: [server-runtime](server-runtime.md) · [payload-and-output](server-runtime_payload-and-output.md) · [client-dom-renderer](client-dom-renderer.md)
