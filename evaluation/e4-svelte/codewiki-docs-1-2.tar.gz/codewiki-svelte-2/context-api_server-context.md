# `context-api_server-context`

> **Source:** `packages/svelte/src/internal/server/context.js`
> **Module tree:** Server-Side Rendering & Cross-Target Runtime Services → context-api → `context-api_server-context`

## 1. Introduction

`context-api_server-context` is the **server-side implementation of Svelte's context API** (`setContext`, `getContext`, `hasContext`, `getAllContexts`) together with the **component-context stack** (`push`, `pop`) that gives those functions meaning during server-side rendering (SSR).

Because JavaScript on the server has no reactive effect system and no component instances that live across frames, the server implementation is deliberately minimal:

* A **module-level stack of lightweight component frames** replaces the client's reactive component context.
* Context values are stored in a plain **`Map` per frame**, lazily created and seeded by **copying** the nearest ancestor's map.
* `onDestroy` callbacks registered on a frame are handed off to the render pipeline's `on_destroy` queue when the frame is popped.

The module is the exact API-counterpart of the browser implementation — see [context-api_client-context](context-api_client-context.md). Svelte's compiled *server* output emits calls into this module, so every `.svelte` component rendered on the server passes through this code path.

| Concern | Exports | Primary callers |
|---|---|---|
| Component-context stack | `push`, `pop`, `current_component` | Compiled server components, `render()` |
| Context API | `setContext`, `getContext`, `hasContext`, `getAllContexts` | Compiled server components (re-exported to users via `svelte`) |
| Internal helpers | `get_or_init_context_map`, `get_parent_context` | The four context functions above |

## 2. Architecture and position in the system

The module sits between the **compiler** (whose server transform emits `$.push` / `$.pop` / `$.setContext` calls) and the **server render pipeline** (`render()`, `Payload`), and mirrors its client twin.

```mermaid
flowchart TB
    subgraph CL["Compiler_Pipeline / compiler-transformer_server-transform"]
        compiled["Compiled server component<br/>'Component.js' bodies contain<br/>$.push(fn) … $.pop()"]
    end

    subgraph SSR["Server-Side Rendering — Cross-Target Runtime Services"]
        subgraph ctx["context-api_server-context (this module)"]
            stack["current_component stack<br/>push / pop"]
            api["getContext / setContext<br/>hasContext / getAllContexts"]
            gocm["get_or_init_context_map<br/>+ get_parent_context"]
        end

        subgraph pipe["server-runtime_render-pipeline"]
            render["render()<br/>internal/server/index.js"]
            ondestroy["on_destroy queue<br/>(module-level array)"]
        end

        subgraph pay["server-runtime_payload-and-output"]
            payload["Payload / HeadPayload<br/>payload.js"]
        end

        clientctx["context-api_client-context<br/>(internal/client/context.js)"]
    end

    subgraph PUB["Public_API / index-server.js"]
        pubapi["onDestroy() · createEventDispatcher()"]
    end

    subgraph SHARED["internal-shared-utils"]
        errs["errors.js<br/>lifecycle_outside_component"]
    end

    compiled -->|"$.push(fn) / $.pop()"| stack
    compiled -->|"$.setContext / $.getContext /<br/>$.hasContext / $.getAllContexts"| api
    api --> gocm
    render -->|"seeds options.context via push()/pop()"| stack
    stack -->|"pop() defers frame.d callbacks"| ondestroy
    ondestroy -->|"run after render completes"| render
    render -->|"writes html/head into"| payload
    pubapi -->|"appends to current frame's d"| stack
    gocm -->|"throws when outside a component"| errs
    clientctx -.->|"mirrors the same API surface"| api
```

### How a render drives the module

`render()` (see [server-runtime_render-pipeline](server-runtime_render-pipeline.md)) performs three interactions with this module:

1. **Root context seeding** — when `options.context` (a `Map`) is supplied, `render()` calls `push()` and assigns it directly as `current_component.c`, making it the inheritance root for the whole render.
2. **Stack lifecycle** — the compiled component function itself brackets its body with `$.push(fn)` / `$.pop()`; nested components nest deeper frames.
3. **Cleanup collection** — `pop()` moves each frame's `d` (onDestroy) callbacks into the pipeline's `on_destroy` array; `render()` snapshots, runs and restores that array after the component finishes rendering.

## 3. Data model: the component frame

The stack elements are plain objects of the internal server `Component` type:

```js
{
    p: Component | null,   // parent frame (the stack link)
    c: Map | null,         // context map — created lazily by get_or_init_context_map
    d: Function[] | null,  // onDestroy callbacks (filled by onDestroy())
    function: fn           // DEV only: the component function, for diagnostics
}
```

* `current_component` always points at the **innermost (current)** frame, or `null` when no render is in progress.
* `c` is **lazily allocated**: a component that never touches the context API pays nothing.
* `d` is filled by `onDestroy()` from the public API; `pop()` is the only consumer.

## 4. API reference

### `push(fn?)`
Pushes a fresh frame onto the stack: `current_component = { p: current_component, c: null, d: null }`. In `DEV` builds the component function `fn` is stored on the frame for dev-time diagnostics (e.g. component attribution in errors). Compiled server components wrap their entire body in `$.push()` … `$.pop()`; `render()` also uses `push()` without `fn` when seeding `options.context`.

### `pop()`
Pops the current frame. If the frame carries `d` (onDestroy callbacks), they are appended to the render pipeline's `on_destroy` queue — **cleanup is deferred until the whole render completes**, not run per component. The stack then unwinds to `component.p`. Note the asymmetry with the client version: server `pop()` returns nothing and schedules no effects (there is no effect system on the server).

### `getContext(key): T`
Returns the value stored under `key` in the current frame's context map (`undefined` if absent). The map is created on first access and inherits entries from the nearest ancestor frame that has one.

### `setContext(key, context): T`
Writes `key → context` into the current frame's map and **returns the context value**, so component functions can `return setContext(...)`. Values set here are visible to the frame and to all *descendants* rendered afterwards (via copy-on-init inheritance), never to ancestors.

### `hasContext(key): boolean`
Membership test on the current frame's context map. Like the readers, it triggers lazy map creation.

### `getAllContexts(): Map<unknown, unknown>`
Returns the **live** context Map of the current frame — mutations through it affect subsequent lookups for this frame and for descendants created afterwards. Used by internal machinery (e.g. legacy slot handling) and advanced integrations rather than typical application code.

### `get_or_init_context_map(name)` *(internal)*
The single entry choke-point shared by all four context functions:

1. If `current_component === null`, throws `lifecycle_outside_component(name)` — the API may only be used **during component initialisation** (between `push` and `pop`).
2. Otherwise lazily assigns `current_component.c ??= new Map(get_parent_context(...) || undefined)` and returns it.

### `get_parent_context(frame)` *(internal)*
Walks the `p` chain upward and returns the **first ancestor frame with a non-null context map**, or `null`. This implements single-pass inheritance: the child map is a snapshot copy, created once.

```mermaid
flowchart TD
    A["getContext / setContext / hasContext / getAllContexts"] --> B{"current_component === null ?"}
    B -->|yes| C["throw lifecycle_outside_component(name)<br/>(DEV: full message + docs URL, PROD: docs URL only)"]
    B -->|no| D{"current_component.c already a Map ?"}
    D -->|yes| E["return existing map"]
    D -->|no| F["get_parent_context():<br/>walk p-chain, find nearest<br/>ancestor with non-null c"]
    F --> G{"ancestor map found ?"}
    G -->|yes| H["new Map(parentMap)<br/>— inherited entries copied"]
    G -->|no| I["new Map()"]
    H --> J["current_component.c ??= map"]
    I --> J
    J --> E
```

## 5. Process flows

### 5.1 Server render with context (sequence)

```mermaid
sequenceDiagram
    autonumber
    participant App as Application
    participant R as render() (server-runtime_render-pipeline)
    participant C as Compiled component
    participant SC as server/context.js (this module)
    participant OD as on_destroy queue

    App->>R: render(Component, { context: Map })
    R->>SC: push()
    R->>SC: current_component.c = options.context
    R->>C: component(payload, props)
    C->>SC: push(fn)
    Note over SC: frame = { p: root, c: null, d: null }
    C->>SC: setContext('theme', 'dark')
    SC-->>C: 'dark' (stored in frame.c)
    C->>SC: getContext('theme')
    SC-->>C: 'dark'
    C->>SC: onDestroy(cleanup) via public API
    Note over SC: cleanup appended to frame.d
    C->>SC: pop()
    Note over SC: frame.d → OD queue; stack unwinds
    R->>OD: run all cleanups
    R-->>App: { html, head, body }
```

### 5.2 Stack lifetime during nested rendering (state diagram)

```mermaid
stateDiagram-v2
    direction TB
    [*] --> RootFrame: render() push() + optional context seed
    RootFrame --> CompA: $.push(fnA)
    state CompA {
        [*] --> Init: context map lazy / inherited
        Init --> Ready: setContext / getContext / hasContext
    }
    CompA --> CompB: $.push(fnB)
    CompB --> CompA: $.pop() — fnB frame.d deferred to on_destroy
    CompA --> RootFrame: $.pop() — fnA frame.d deferred
    RootFrame --> [*]: render() runs on_destroy, stack empty
```

## 6. Integration points

| Integration | Direction | Detail |
|---|---|---|
| [compiler-transformer_server-transform](compiler-transformer_server-transform.md) | consumer | Compiled component bodies bracket themselves with `$.push(fn)` / `$.pop()` and call `$.setContext` etc.; the server index re-exports this module's symbols as the `$` helpers. |
| [server-runtime_render-pipeline](server-runtime_render-pipeline.md) | consumer + provider | `render()` seeds root context, and owns the `on_destroy` queue that `pop()` feeds. |
| [server-runtime_payload-and-output](server-runtime_payload-and-output.md) | unrelated | The context stack does not touch `Payload`; HTML accumulation stays in the pipeline. |
| [Public_API___Built-in_Feature_Surface](Public_API___Built-in_Feature_Surface.md) | consumer | `onDestroy()` writes to `current_component.d`; server `createEventDispatcher()` is a no-op (no event bubbling in SSR). |
| [internal-shared-utils](internal-shared-utils.md) | dependency | `lifecycle_outside_component` error factory; message differs between `DEV` (verbose, with `svelte.dev/e/…` link) and production (link only). |
| `esm-env` | dependency | `DEV` flag gates the `function` field on frames. |

## 7. Client/server symmetry

Both implementations share the same exported API surface and the same *copy-on-init* inheritance model, but the frame shape and validation differ:

| Aspect | Server (this module) | Client ([context-api_client-context](context-api_client-context.md)) |
|---|---|---|
| Stack variable | `current_component` | `component_context` |
| Frame fields | `p`, `c`, `d`, DEV `function` | `p`, `c`, `e` (effects), `s` (props), `x` (component instance), `l` (legacy mode state) |
| `push()` | Stack link only | Also captures props, legacy-mode bookkeeping, DEV component fn |
| `pop()` | Defers `d` to `on_destroy` queue | Schedules `e` effects, sets `x`, returns instance |
| `setContext()` timing rules | Must run during initialisation (`lifecycle_outside_component`) | Same check **plus** async-mode validation (`set_context_after_init`) |
| Reactivity coupling | None — plain synchronous `Map` | Deep coupling with the signal graph — see [client-reactivity-engine](client-reactivity-engine.md) |
| `getAllContexts()` | Live server map | Live client map |

## 8. Error handling & DEV behavior

* **`lifecycle_outside_component(name)`** — thrown by every context function when called outside component initialisation. `name` (`'getContext'`, `'setContext'`, …) names the offending call. In `DEV` the error carries the code and a documentation URL; in production only the URL is kept (message-code generation for errors is documented under [message_code_generation_templates_compile_time](message_code_generation_templates_compile_time.md)).
* **DEV frame metadata** — `push(fn)` stores the component function on the frame; production builds omit it entirely, so the frame allocation stays at its minimal three-field shape.
* **Deferred cleanup safety** — because `pop()` only *enqueues* `d` callbacks, an exception thrown deep inside a component render leaves cleanup to the `finally`/post-render logic of `render()` rather than half-running callbacks mid-unwind.

## 9. Design notes, invariants & gotchas

1. **Inheritance is a snapshot, not a live link.** A child's context map is built once (on first context access) by copying the nearest ancestor map. `setContext` in an ancestor *after* the child's map exists is invisible to the child.
2. **Downward visibility only.** `setContext` never affects ancestors or siblings rendered earlier; this matches the documented Svelte contract and makes SSR output deterministic.
3. **Single-threaded, synchronous renders.** `current_component` is module-scoped state; a render must complete before another begins on the same module instance. This holds for normal Node SSR because `render()` is synchronous end-to-end.
4. **Lazy allocation everywhere.** `hasContext`/`getContext` also allocate the map (`get_or_init_context_map` is the only factory), trading an occasional empty `Map` for branch-free call sites.
5. **Cleanup timing.** `onDestroy` callbacks run *after the entire render* (batched by `render()`), not when the individual component finishes — a difference from the client, where they fire at component unmount time.
6. **`render(options.context)` is the inheritance root.** Frameworks and tests inject per-request context here; it is attached by direct assignment to the synthetic root frame's `c`, bypassing lazy init.
7. **`getAllContexts` is a live reference**, suitable for transferring a whole context namespace into a subtree (e.g. `render(Child, { context: getAllContexts() })` in tests).

## 10. Related documentation

* [context-api_client-context](context-api_client-context.md) — browser twin of this module
* [server-runtime_render-pipeline](server-runtime_render-pipeline.md) — `render()`, `head`, block rendering that drives `push`/`pop`
* [server-runtime_payload-and-output](server-runtime_payload-and-output.md) — output accumulation the render pipeline feeds
* [compiler-transformer_server-transform](compiler-transformer_server-transform.md) — generates the `$.push/$.pop/$.setContext` call sites
* [internal-shared-utils](internal-shared-utils.md) — shared error/validation helpers
* [Public_API___Built-in_Feature_Surface](Public_API___Built-in_Feature_Surface.md) — user-facing `onDestroy`/`createEventDispatcher`