# compiler-core_ast_builders

## Introduction

The `compiler-core_ast_builders` module — implemented as a single file, `packages/svelte/src/compiler/utils/builders.js` — is the **ESTree node factory library** of the Svelte compiler. It provides a large set of small, pure functions that construct plain-object nodes conforming to the [ESTree specification](https://github.com/estree/estree), the de-facto standard AST format for JavaScript.

It is the "vocabulary" with which the compiler *writes code*. Instead of generating JavaScript by string concatenation, the transform phases ([compiler-transformer](compiler-transformer.md)) compose output ASTs node-by-node using these builders (conventionally imported as `b`):

```js
import * as b from '../../utils/builders.js';

// produces:  const consequent = ($$anchor) => { ... }
b.var(consequent_id, b.arrow([b.id('$$anchor')], consequent_block));
```

The resulting ESTree tree is handed to the code generator, which prints the final JavaScript (client or server output) together with source maps.

---

## Design Principles

| Principle | How it manifests |
|---|---|
| **Data-first AST** | Every builder returns a plain object literal (`{ type, ... }`), never a class instance. Nodes are cheap to create, trivially serializable, and directly consumable by the walker (`zimmerframe`) and the code generator. |
| **String coercion for ergonomics** | Most builders accept raw strings where an AST node is expected: `b.call('$.append', ...)` becomes an `Identifier` callee, `declarator('x')` becomes `id('x')`, `member(obj, 'prop')` coerces the property name. |
| **Valid-identifier awareness** | `key(name)` inspects `regex_is_valid_identifier` (from `phases/patterns.js`) and returns either an `Identifier` or a string `Literal` — essential when generating object keys from arbitrary source names. |
| **Keyword-safe exports** | JS keywords cannot be function names, so keyword-shaped builders are exported via aliases (`let_builder as let`, `const_builder as const`, `await_builder as await`, `if_builder as if`, ...) alongside shared singleton constants (`true`, `false`, `null`, `this`, `debugger`, `void0`, `empty`). |
| **Sensible defaults** | `computed = false`, `optional = false`, `prefix = false`, `async = false`, `generator = false` — call sites only specify what differs from the common case. |
| **No codegen-visible metadata** | Function nodes are created with `metadata: null`. `metadata` is a Svelte-internal annotation slot populated during analysis; builders reset it so downstream code generation never depends on stale analysis data. |
| **Pure & tree-shakeable** | No side effects at module scope (singletons are immutable-by-convention literals); consumers pull in only the builders they use. |

---

## Architecture: Position in the Compiler Pipeline

The builders are consumed exclusively in **phase 3 (transform)** of the pipeline. Upstream phases operate on the Svelte-specific AST ([compiler-parser](compiler-parser.md), [compiler-analyzer](compiler-analyzer.md)); the transformer is the bridge that re-expresses it as JavaScript via `b.*`.

```mermaid
flowchart LR
    SRC["component.svelte<br/>(source text)"] --> P["Phase 1: Parse<br/>compiler-parser"]
    P --> SAST["Svelte AST<br/>types: compiler-core_type_definitions"]
    SAST --> AN["Phase 2: Analyze<br/>compiler-analyzer"]
    AN --> TR["Phase 3: Transform<br/>compiler-transformer<br/>(client & server visitors)"]
    TR --> EJS["ESTree AST<br/>(plain objects)"]
    EJS --> CG["Code Generator"]
    CG --> OUT["Generated JS<br/>+ sourcemaps"]

    B["compiler-core_ast_builders<br/>builders.js — b.* factories"]
    B -. "supplies node factories" .-> TR
    B -. "output type (estree)" .-> EJS
```

Entry points that drive this pipeline (`compile`, `compileModule`) live in [compiler-core_public_api](compiler-core_public_api.md); compile-time errors and warnings surfaced during analyze/transform are covered in [compiler-core_diagnostics](compiler-core_diagnostics.md).

---

## Internal Composition & Dependencies

The module has only three imports, all used narrowly, and most keyword-style builders are thin wrappers over the core `declaration` / `declarator` / `prop` primitives.

```mermaid
flowchart TD
    subgraph KW["Keyword-style exports (this module's core components)"]
        LET["b.let / b.const / b.var<br/>let_builder / const_builder / var_builder"]
        AWAIT["b.await<br/>await_builder"]
        IF["b.if<br/>if_builder"]
        FORB["b.for<br/>for_builder"]
        RET["b.return<br/>return_builder"]
        INIT["init(name, value)"]
        OBJ["object(properties)"]
        COND["conditional(test, cons, alt)"]
        THROW["throw_error(str)"]
    end

    LET --> DECL["declaration(kind, declarations)"]
    DECL --> DEC["declarator(pattern, init)"]
    DEC --> ID["id(name)"]

    INIT --> PROP["prop('init', key, value)"]
    GETSET["get / set (accessor helpers)"] --> PROP
    PROP --> KEY["key(name)"]
    KEY --> CHECK{"regex_is_valid_identifier<br/>(phases/patterns.js)"}
    CHECK -->|valid| ID
    CHECK -->|invalid| LIT["literal(value)"]

    THROW --> NEW["new_builder('Error', literal(str))"]

    THUNK["thunk(expr)"] --> UTH["unthunk()"]
    UTH --> WALK["zimmerframe walk()<br/>(detects nested awaits)"]
    QUASI["quasi(cooked, tail)"] --> SAN["sanitize_template_string()<br/>(utils/sanitize_template_string.js)"]
```

**External dependencies:**

| Import | Source | Used by |
|---|---|---|
| `walk` | `zimmerframe` | `unthunk()` — scans an async arrow body to detect whether an `AwaitExpression` is nested (prevents unsafe collapsing of `async () => await x(await y)`) |
| `regex_is_valid_identifier` | `../phases/patterns.js` | `key()` — decides `Identifier` vs. string `Literal` for object/class keys |
| `sanitize_template_string` | `./sanitize_template_string.js` | `quasi()` — escapes `` ` ``, `${`, `\` so cooked strings can be emitted as raw template chunks |
| `estree` types | type-only | Return types of every builder |

---

## API Reference

### Core components (this module tree)

| Builder | Signature | ESTree node produced | Purpose |
|---|---|---|---|
| `b.await` (`await_builder`) | `(argument) → AwaitExpression` | `AwaitExpression` | `await expr` in generated async code |
| `b.if` (`if_builder`) | `(test, consequent, alternate?) → IfStatement` | `IfStatement` | statement-level branching; `alternate` optional → `else`-less `if` |
| `b.let` (`let_builder`) | `(pattern \| string, init?) → VariableDeclaration` | `VariableDeclaration` (`let`) | single-declarator `let` |
| `b.const` (`const_builder`) | `(pattern \| string, init) → VariableDeclaration` | `VariableDeclaration` (`const`) | single-declarator `const` (init required) |
| `b.var` (`var_builder`) | `(pattern \| string, init?) → VariableDeclaration` | `VariableDeclaration` (`var`) | single-declarator `var`, often hoisted template blocks |
| `b.for` (`for_builder`) | `(init, test, update, body) → ForStatement` | `ForStatement` | classic `for` loop |
| `b.return` (`return_builder`) | `(argument = null) → ReturnStatement` | `ReturnStatement` | early/void returns supported via default |
| `conditional` | `(test, consequent, alternate) → ConditionalExpression` | `ConditionalExpression` | expression-level ternary (`? :`) |
| `init` | `(name, value) → Property` | `Property` (kind `init`) | object-literal entry; pairs with `object()` |
| `object` | `(properties) → ObjectExpression` | `ObjectExpression` | object literal from property/spread list |
| `throw_error` | `(str) → ThrowStatement` | `ThrowStatement` + `new Error(...)` | **runtime** assertions inside generated code (e.g. `{@debug}` guards). Distinct from compile-time diagnostics in [compiler-core_diagnostics](compiler-core_diagnostics.md), which are code/position-bearing `CompileError`s. |

```js
// b.const('root', b.call('$.template'));          → const root = $.template();
// b.let('i', b.literal(0));                       → let i = 0;
// b.if(test, b.stmt(b.call('$.next')));           → if (test) $.next();
// b.object([b.init('id', b.id('$$anchor'))]);     → ({ id: $$anchor })
// b.throw_error('invalid snippet');               → throw new Error("invalid snippet");
```

### Full export surface (grouped)

**Identifiers & literals** — `id`, `private_id`, `literal`, `key`, `member`, `member_id`, `this`, `null`, `true`, `false`, `void0`, `empty`, `debugger`

**Expressions** — `array`, `arrow`, `assignment`, `assignment_pattern`, `await`, `binary`, `call`, `maybe_call` (optional-call → `ChainExpression`), `conditional`, `logical`, `new_builder` (used internally by `throw_error`), `object`, `sequence`, `spread`, `template` + `quasi`, `thunk` / `unthunk`, `unary`, `update`

**Statements** — `block`, `labeled`, `stmt`, `do_while`, `for`, `for_of`, `if`, `return`, `throw_error`

**Declarations** — `declaration`, `declarator`, `let`, `const`, `var`, `export_default`, `function_declaration`, `function` (as `FunctionExpression`)

**Classes & object shapes** — `method`, `get`, `set`, `prop`, `prop_def`

**Modules** — `import_all` (namespace import), `imports` (named `[[imported, local]]` pairs)

**Patterns** — `array_pattern`, `object_pattern`, `rest`

---

## Component Interaction: A Visitor Using the Builders

Every client/server transform visitor follows the same interaction pattern — read the Svelte AST node, ask scope for unique names, then *compose* the output statement-by-statement. The real `IfBlock` client visitor illustrates it:

```mermaid
sequenceDiagram
    participant TR as Transform walker<br/>(compiler-transformer)
    participant V as IfBlock visitor
    participant B as builders.js (b.*)
    participant AST as Output ESTree tree
    participant CG as Code generator

    TR->>V: visit IfBlock node (Svelte AST)
    V->>B: b.var(id, b.arrow([b.id('$$anchor')], block))
    B-->>AST: VariableDeclaration ← ArrowFunctionExpression
    V->>B: b.if(test, b.stmt(b.call('$$render', id)), alternate_stmt)
    B-->>AST: IfStatement → ExpressionStatement → CallExpression
    V->>B: b.call('$.if', node, render_arrow, b.true?)
    B-->>AST: CallExpression (call coerces string callee → Identifier)
    AST->>CG: print tree
    CG-->>TR: emitted JS for the {#if} block
```

which yields generated code of the shape:

```js
const consequent = ($$anchor) => { /* branch body */ };
$.if(node, ($$render) => {
    if (test) $$render(consequent);
    // else: $$render(alternate, false)
});
```

Other real consumers in [compiler-transformer](compiler-transformer.md):

- **`Fragment` (client)** — builds hoisted `b.var(template_name, template)` declarations, `b.call('$.append', ...)`, and async wrappers via `b.block` / `b.arrow` / `b.if`.
- **`build_attribute_value` (server, shared/utils)** — returns `b.literal` for text, `b.call('$.stringify', expr)` for dynamic chunks, and assembles `b.quasi` / `b.template` for mixed content.

---

## Process Flow: From Template Syntax to Built Nodes

```mermaid
flowchart TD
    A["Svelte template:<br/>{#if visible}<p>hi</p>{/if}"] --> B2["Parser → IfBlock node<br/>(Svelte AST, template.d.ts types)"]
    B2 --> C2["Analyzer attaches metadata<br/>(expression deps, has_await, scope)"]
    C2 --> D2{"Client or server transform?"}
    D2 -->|client| E2["IfBlock visitor composes:<br/>b.var / b.arrow / b.if / b.stmt / b.call"]
    D2 -->|server| F2["SSR visitor composes:<br/>if/else statements emitting HTML strings"]
    E2 --> G2["ESTree nodes returned to walker<br/>and stitched into component body"]
    F2 --> G2
    G2 --> H2["Codegen prints JS<br/>(tree-shakeable $.if / SSR branch)"]
```

Note the asymmetry: the **same** builder vocabulary serves both targets — control flow in client output uses runtime helpers called through `b.call('$.if', ...)`, while server output uses plain `b.if` statements, because SSR is render-once code with no reactivity.

---

## Behavioral Details & Gotchas

1. **`call()` argument repair** — `b.call(callee, ...args)` treats falsy entries (commonly conditional expressions like `alternate_id && ...`) positionally: trailing falsy arguments are *removed*, while falsy arguments *followed by* real ones are replaced with `id('undefined')`. This lets visitors pass optional parameters without manual slicing.
2. **`thunk()` / `unthunk()`** — internal runtime helpers (e.g. `$.get`, `$.async`) expect lazily-evaluated functions. `thunk(expr)` wraps `expr` in an arrow and immediately applies `unthunk`, which (a) collapses identity thunks `(a) => f(a)` → `f`, and (b) rewrites `async () => await x()` → `async () => x` **only when** no nested `await` exists in `x` (verified with the `zimmerframe` walk).
3. **Singletons are shared objects** — `b.true`, `b.false`, `b.null`, `b.this`, `b.empty`, `b.debugger`, `void0` are module-level instances. Never mutate them; clone (`{ ...node }`) if a transform needs an owned copy, as `visit_function` does when hoisting params.
4. **`metadata: null`** — arrow/function builders explicitly null the Svelte `metadata` slot so generated nodes are never mistaken for analyzed source nodes.
5. **`quasi()` raw/cooked split** — the cooked value is kept as-is; the raw value is escaped via `sanitize_template_string`, guaranteeing the printed template literal round-trips to the same cooked string.
6. **`key()` vs `id()`** — use `key()` for property/class-member names derived from source (may become a `Literal`); use `id()` only for known-identifier names.
7. **`maybe_call()`** — returns a `ChainExpression` wrapping an optional call (`f?.(...)`), used where generated code must tolerate missing optional callbacks (e.g. user-supplied hooks).

---

## Related Modules

- [compiler-core_public_api](compiler-core_public_api.md) — `compile` / `compileModule` entry points that orchestrate the pipeline the builders serve.
- [compiler-parser](compiler-parser.md) — produces the Svelte AST that transformer visitors consume and re-express with `b.*`.
- [compiler-analyzer](compiler-analyzer.md) — attaches the metadata and scope information that visitors consult while composing builder calls.
- [compiler-transformer](compiler-transformer.md) — the primary consumer; all client/server visitors import this module as `b`.
- [compiler-core_type_definitions](compiler-core_type_definitions.md) — Svelte AST node types (input universe) complementing the ESTree types (output universe) used here.
- [compiler-core_diagnostics](compiler-core_diagnostics.md) — compile-time errors/warnings; note `throw_error` here instead generates *runtime* `throw new Error(...)` statements in output code.
