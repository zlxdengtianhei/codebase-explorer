# Reactive Built-ins: URL (`reactive-builtins_url`)

## 1. Introduction

The `reactive-builtins_url` module provides **reactive, drop-in replacements for the browser's standard `URL` and `URLSearchParams` objects**:

| Component | File | Wraps |
|---|---|---|
| `SvelteURL` | `packages/svelte/src/reactivity/url.js` | native `URL` |
| `SvelteURLSearchParams` | `packages/svelte/src/reactivity/url-search-params.js` | native `URLSearchParams` |

Both classes are exported to applications through the `svelte/reactivity` public entry point (see [public-api](public-api.md), [reactive-builtins](reactive-builtins.md)). Reading any of their properties inside an `$effect` or `$derived` registers a fine-grained dependency on the reactive signal graph; mutating them invalidates exactly the reactions that observed the changed data, causing automatic re-computation and DOM updates.

They are *structural* built-ins: they extend the native classes rather than proxying them, so they satisfy `instanceof URL` / `instanceof URLSearchParams`, behave identically to the platform API, and can be passed to any browser or library code that expects a `URL`.

> **Scope note:** because the implementation imports directly from `../internal/client/...`, these classes are coupled to the client reactivity engine. The SSR-safe `svelte/reactivity` server entry (`reactivity/index-server.js`) exposes only `MediaQuery` and `createSubscriber` (see [reactive-builtins_media-query](reactive-builtins_media-query.md)); `SvelteURL` and `SvelteURLSearchParams` are surfaced via the client entry. Server-side reactive reading would be meaningless anyway — there is no signal graph to subscribe to outside the client runtime.

---

## 2. Position in the System

The module is a leaf of the `Public_API → reactive-builtins` group. It is a pure *consumer* of the client reactivity engine: it creates signals, reads them, and writes them. All scheduling, dependency tracking, equality checks and batching are delegated downstream.

```mermaid
flowchart TB
    subgraph PUBLIC["Public API surface (svelte/reactivity)"]
        ENTRY["reactivity/index-client.js<br/>(re-exports reactive built-ins)"]
    end

    subgraph MODULE["reactive-builtins_url (this module)"]
        SU["SvelteURL<br/>url.js"]
        SP["SvelteURLSearchParams<br/>url-search-params.js"]
    end

    subgraph ENGINE["Client reactivity engine"]
        direction TB
        SOURCES["reactivity/sources.js<br/>state() · set() · increment()"]
        SIGNAL["runtime.js<br/>get()"]
        BATCH["batch.js / loop.js<br/>flush scheduling"]
    end

    subgraph DEV["Client dev tooling"]
        TAG["dev/tracing.js<br/>tag()"]
    end

    ENTRY --> SU
    ENTRY --> SP

    SU -- "state / set / get" --> SOURCES
    SU -- "get" --> SIGNAL
    SP -- "state / increment / get" --> SOURCES
    SP -- "get" --> SIGNAL

    SU -. "DEV only: label signals" .-> TAG
    SP -. "DEV only: label version" .-> TAG

    SU -- "owns #searchParams" --> SP
    SP -- "get_current_url() → #url back-link" --> SP

    SOURCES ==> BATCH
```

Key dependencies (all internal, all from the client runtime):

* `state(v)` / `set(signal, v)` / `increment(signal)` — from `internal/client/reactivity/sources.js`: create writable source signals and publish new values. Described in [client-reactivity-engine_sources-and-proxies](client-reactivity-engine_sources-and-proxies.md).
* `get(signal)` — from `internal/client/runtime.js`: returns the current value **and registers the signal as a dependency of the currently running reaction** (effect / derived). Described in [client-reactivity-engine_signal-graph](client-reactivity-engine_signal-graph.md).
* `tag(signal, label)` — from `internal/client/dev/tracing.js`: attaches a human-readable label for devtools / `$inspect` / tracing. Described in [client-dev-tooling_state-inspection](client-dev-tooling_state-inspection.md).
* `esm-env`'s `DEV` flag — gates all instrumentation so production bundles stay lean (verified by the treeshakeability checker, see [treeshakeability_checker](treeshakeability_checker.md)).

The engine downstream (batching, scheduling, effect execution) is documented in [client-reactivity-engine](client-reactivity-engine.md) and its scheduling submodule [client-reactivity-engine_batching-scheduling](client-reactivity-engine_batching-scheduling.md).

---

## 3. Architecture

### 3.1 Class structure

```mermaid
classDiagram
    class URL {
        <<native>>
        +href
        +protocol
        +username
        +password
        +host
        +hostname
        +port
        +pathname
        +search
        +hash
        +origin
        +searchParams
    }
    class URLSearchParams {
        <<native>>
        +append(name, value)
        +delete(name, value?)
        +get(name)
        +getAll(name)
        +has(name, value?)
        +set(name, value)
        +sort()
        +keys() +values() +entries()
        +toString()
        +size
    }

    class SvelteURL {
        -#protocol : Signal~string~
        -#username : Signal~string~
        -#password : Signal~string~
        -#hostname : Signal~string~
        -#port : Signal~string~
        -#pathname : Signal~string~
        -#hash : Signal~string~
        -#search : Signal~string~
        -#searchParams : SvelteURLSearchParams
        +get hash() / set hash(v)
        +get host() / set host(v)
        +get hostname() / set hostname(v)
        +get href() / set href(v)
        +get password() / set password(v)
        +get pathname() / set pathname(v)
        +get port() / set port(v)
        +get protocol() / set protocol(v)
        +get search() / set search(v)
        +get username() / set username(v)
        +get origin() «read-only»
        +get searchParams()
        +toString() + toJSON()
    }

    class SvelteURLSearchParams {
        -#version : Signal~number~ «change stamp»
        -#url : SvelteURL «or null»
        -#updating : boolean «cycle guard»
        +REPLACE$(params) «internal»
        -#update_url()
        +append(name, value)
        +delete(name, value?)
        +get(name) +getAll(name) +has(name, value?)
        +set(name, value)
        +sort()
        +keys() +values() +entries()
        +toString() + size
    }

    URL <|-- SvelteURL : extends
    URLSearchParams <|-- SvelteURLSearchParams : extends
    SvelteURL *-- "1" SvelteURLSearchParams : #searchParams
    SvelteURLSearchParams --> "0..1" SvelteURL : #url (owner back-link)
```

### 3.2 Signal inventory

The two classes use **two different granularities** of reactivity:

**`SvelteURL` — fine-grained, one signal per URL component.**

| Accessor | Signals read (`get`) | Signals written (`set`) |
|---|---|---|
| `hash` | `#hash` | `#hash` |
| `host` | `#hostname`, `#port` | `#hostname`, `#port` |
| `hostname` | `#hostname` | `#hostname` |
| `href` | **all eight** | **all eight** + `searchParams[REPLACE]` |
| `password` | `#password` | `#password` |
| `pathname` | `#pathname` | `#pathname` |
| `port` | `#port` | `#port` |
| `protocol` | `#protocol` | `#protocol` |
| `search` | `#search` | `#search` + `searchParams[REPLACE]` |
| `username` | `#username` | `#username` |
| `origin` (read-only) | `#protocol`, `#hostname`, `#port` | — |
| `toString()` / `toJSON()` | (via `href`) all eight | — |

**`SvelteURLSearchParams` — coarse-grained, a single `#version` counter.**

| Operation category | Methods | Effect on `#version` |
|---|---|---|
| Reads | `get`, `getAll`, `has`, `keys`, `values`, `entries`, `toString`, `size`, `[Symbol.iterator]` | `get(#version)` — subscribe |
| Writes | `append`, `sort` | unconditionally `increment(#version)` |
| Conditional writes | `delete` (only if a pair was actually removed), `set` (only if the serialized value changed) | `increment(#version)` on real change |
| Bulk import | `[REPLACE](params)` (internal) | `increment(#version)` |

The version-stamp pattern means the collection cannot express *which* entry changed — any mutation invalidates every reader of the params. That is the correct trade-off for `URLSearchParams`, whose semantics (duplicate keys, ordering, combined `toString()`) make per-key tracking expensive and error-prone. For a per-key granular collection, see the `SvelteMap` sibling in [reactive-builtins_collections](reactive-builtins_collections.md); for a date built-in, [reactive-builtins_temporal](reactive-builtins_temporal.md).

---

## 4. Reactive Mechanics

### 4.1 Read path (dependency registration)

Every reactive read funnels through the engine's `get()`, which links the signal into the currently active reaction:

```mermaid
sequenceDiagram
    autonumber
    participant FX as Effect / $derived
    participant SU as SvelteURL
    participant G as runtime.get()
    participant S as Signal #pathname

    FX->>SU: url.pathname
    SU->>G: get(this.#pathname)
    G->>G: register S as dependency of active_reaction
    G->>G: DEV: tracing / reactvity-loss checks
    G-->>SU: current string value
    SU-->>FX: super.pathname (native value)
    Note over FX,S: Later: set(#pathname, v) marks S dirty →<br/>FX is scheduled for re-run in the current batch
```

Because getters delegate the *actual value* to the native `super` implementation after touching the signal, the returned data is always the browser-canonicalized value (e.g. `pathname` always starts with `/`). Signals only exist to record *who asked* and *when it changed*.

Reads performed **outside** any active reaction (plain script code) simply return the value with no overhead beyond a property access — no dependency is created.

### 4.2 Write path (invalidation)

Every setter follows the same three-step contract: *mutate native → re-sync signal → let the engine schedule*.

```mermaid
flowchart TD
    A["url.pathname = '/about'"] --> B["super.pathname = value<br/>(native URL canonicalization)"]
    B --> C["set(#pathname, super.pathname)"]
    C --> D{"sources.set() guards"}
    D -- "unsafe: mutation inside derived/<br/>effect-init" --> E["throw state_unsafe_mutation"]
    D -- ok --> F{"value changed?<br/>(equality check)"}
    F -- yes --> G["signal marked dirty<br/>dependents enqueued"]
    F -- no --> H["no-op"]
    G --> I["Batch flushes: deriveds recompute,<br/>effects re-run, DOM updates"]
```

Two engine behaviors inherited for free:

* **Idempotence** — assigning the same value does not invalidate anything (`sources.set` → `internal_set` performs an equality check).
* **Mutation safety** — writing a reactive property *while* a derived is computing throws `state_unsafe_mutation` (see [client-reactivity-engine_signal-graph](client-reactivity-engine_signal-graph.md)). `SvelteURL` setters go through `set()`, so they are protected by the same guard.

### 4.3 Construction

```mermaid
flowchart TD
    A["new SvelteURL(url, base?)"] --> B["native URL parse/canonicalize"]
    B --> C["super(url)"]
    C --> D{"DEV?"}
    D -- yes --> E["tag() each component signal<br/>'SvelteURL.protocol' etc."]
    D -- no --> F["skip instrumentation"]
    E & F --> G["current_url = this<br/>(module-level slot)"]
    G --> H["new SvelteURLSearchParams(url.searchParams)<br/>captures get_current_url() as #url"]
    H --> I["current_url = null"]
```

The module-level `current_url` slot is an *ambient registration* mechanism: the `SvelteURLSearchParams` constructor calls `get_current_url()` once to memorize its owning `SvelteURL` in the private `#url` field. This keeps the public constructor signatures identical to the native APIs (`new URL(url, base)`) and avoids any observable coupling on the class surface. Standalone `SvelteURLSearchParams` instances get `#url = null` and simply skip URL synchronization.

---

## 5. Bidirectional `SvelteURL` ⇄ `SvelteURLSearchParams` Synchronization

The two classes form a tightly coordinated pair. A `URL`'s `search` string and its `searchParams` collection are two views of the same data; the module keeps both views *and* their signals consistent in both directions, with a re-entrancy flag (`#updating`) preventing infinite recursion.

```mermaid
sequenceDiagram
    autonumber
    participant U as SvelteURL
    participant P as SvelteURLSearchParams
    participant V as #version signal

    rect rgb(235, 245, 255)
    Note over U,V: Direction 1 — URL changed, params must follow
    U->>U: super.search = '?a=1' (or href setter)
    U->>U: set(#search, ...) → invalidate search readers
    U->>P: params[REPLACE](super.searchParams)
    P->>P: #updating = true  «blocks write-back»
    P->>P: delete all pairs, append new pairs
    P->>V: increment(#version) → invalidate all readers
    P->>P: #updating = false
    end

    rect rgb(235, 255, 240)
    Note over U,V: Direction 2 — params changed, URL must follow
    P->>P: super.append('b', '2')
    P->>U: #update_url() → url.search = '?a=1&b=2'
    U->>U: set(#search, ...) 
    U->>P: search setter calls params[REPLACE](...)
    P->>P: guarded by #updating → no-op (cycle broken)
    P->>V: increment(#version)
    end
```

Details worth knowing:

* `REPLACE` is exported as a module-level `Symbol()`, so the bulk-replace method is effectively **private at runtime** — user code cannot collide with or invoke it.
* `#update_url()` writes ``url.search = search && `?${search}` `` — when the params become empty, the `search` string is left untouched rather than set to a literal empty query, avoiding a spurious trailing `?`.
* No-op suppression: `delete()` bumps the version only if `super.has(name, value)` was true before deletion; `set()` compares `super.getAll(name).join('')` before/after, so setting a param to its existing value (even among duplicates) does not invalidate anything.
* `set()`'s comparison deliberately cannot use `has(name, value)`: for `?foo=1&bar=2&foo=3`, setting `foo=1` deletes `foo=3` even though `has('foo','1')` would still return `true`.

---

## 6. Component Interaction — Typical Usage

```svelte
<script>
	import { SvelteURL } from 'svelte/reactivity';

	const url = new SvelteURL('https://example.com/path?q=1');
</script>

<!-- setters make these inputs two-way bindable -->
<input bind:value={url.pathname} />
<input bind:value={url.href} size="65" />

<p>?{url.searchParams.get('q')}</p>

{#each url.searchParams as [key, value]}
	<p>{key}: {value}</p>
{/each}
```

```mermaid
flowchart LR
    subgraph TEMPLATE["Component template reactions"]
        T1["href text / each block"]
        T2["input value bindings"]
    end

    subgraph USER["User events"]
        E1["typing in pathname input"]
    end

    E1 --> S1["url.pathname = '/x'"]
    S1 --> S2["set(#pathname)"]
    S2 --> S3["href readers invalidated<br/>(href getter reads all 8 signals)"]
    S3 --> S4["batch flush → template re-renders<br/>input + href text stay in sync"]

    T1 -- "read url.searchParams" --> R1["get(#version) subscription"]
    R1 -. "append/set/delete/sort on params" .-> R2["increment(#version) → re-render"]
```

Note how `href` acts as a *projection* of all component signals: reading `url.href` subscribes to everything, and writing `url.href` republishes everything (plus a `searchParams` replace). Bindings work naturally because every writable URL component exposes a setter.

---

## 7. Development-Mode Instrumentation

When `DEV` is true (via `esm-env`):

* Every `SvelteURL` component signal is labeled — `'SvelteURL.protocol'`, `'SvelteURL.pathname'`, etc. — via `tag()` from `internal/client/dev/tracing.js`.
* The `SvelteURLSearchParams` version signal is labeled `'SvelteURLSearchParams version'`.

These labels surface in `$inspect` output, `console.log` state introspection (`log_if_contains_state`), the tracing mode (`$effect.tracking` / tracing flag) and reactivity-loss warnings (`for_await_track_reactivity_loss`) — all documented in [client-dev-tooling](client-dev-tooling.md) and [client-dev-tooling_state-inspection](client-dev-tooling_state-inspection.md). Production builds compile the `if (DEV)` branches away, leaving no label overhead.

---

## 8. Design Decisions & Constraints

1. **Inheritance over proxying.** Extending `URL`/`URLSearchParams` yields exact native semantics (`instanceof`, `toString`, serialization, canonicalization) without the complexity of `Proxy` traps (contrast with the state proxies in [client-reactivity-engine_sources-and-proxies](client-reactivity-engine_sources-and-proxies.md)). The cost is that only *known* accessors can be made reactive — but `URL`'s surface is fixed by the platform, so nothing is lost.
2. **Two granularities, chosen per API.** `SvelteURL` gets per-component signals because URL parts are independently bindable and cheap to track; `SvelteURLSearchParams` gets a single version stamp because entry-level dependency tracking would be disproportionate to its usage patterns.
3. **Re-entrancy safety.** The `#updating` flag is the single guard that makes the bidirectional sync acyclic. Both directions funnel through `REPLACE` or `#update_url`, and both check the flag first.
4. **Ambient owner registration.** The `current_url` slot (set → construct → reset) transmits the owner to the params object without altering the public constructor signature or creating a hard reference cycle in the public API.
5. **Strict native compatibility.** Non-reactive fallbacks exist for every operation: untracked reads work, standalone params work (`#url` null-guard), `origin` stays read-only, and unknown/undocumented `URL` behaviors remain native.
6. **Client-runtime coupling.** The imports of `state`/`set`/`increment`/`get` tie the module to the client runtime; hence its exclusion from the SSR `svelte/reactivity` entry (see [Section 1](#1-introduction) and [server-runtime](server-runtime.md) for the SSR counterpart architecture).

---

## 9. Relationships to Other Modules

| Related module | Relationship |
|---|---|
| [client-reactivity-engine](client-reactivity-engine.md) | Upstream consumer: uses `state`/`set`/`increment` ([…_sources-and-proxies](client-reactivity-engine_sources-and-proxies.md)) and `get` ([…_signal-graph](client-reactivity-engine_signal-graph.md)). Batching/flushing handled by […_batching-scheduling](client-reactivity-engine_batching-scheduling.md). |
| [client-dev-tooling](client-dev-tooling.md) | Uses `tag()` ([…_state-inspection](client-dev-tooling_state-inspection.md)) for DEV labels. |
| [reactive-builtins](reactive-builtins.md) | Parent group; shares the "native object + signals" pattern with [reactive-builtins_collections](reactive-builtins_collections.md) (`SvelteMap`), [reactive-builtins_temporal](reactive-builtins_temporal.md) (`SvelteDate`) and [reactive-builtins_media-query](reactive-builtins_media-query.md) (`MediaQuery`, `createSubscriber`). |
| [public-api](public-api.md) | Exposes the classes via `svelte/reactivity`; types are re-exported in [svelte-public-types](svelte-public-types.md) (`SvelteURL`, `SvelteURLSearchParams`). |
| [server-runtime](server-runtime.md) | No dependency — reactive URL objects are a client-side concern; SSR markup is produced by the compiler's server transform ([compiler-transformer](compiler-transformer.md)). |

---

## 10. Public API Reference

### `class SvelteURL extends URL`

* `new SvelteURL(url: string | URL, base?: string | URL)` — parses via native `URL`; creates one signal per mutable component and a bound `SvelteURLSearchParams`.
* Reactive get/set accessors: `href`, `protocol`, `username`, `password`, `host`, `hostname`, `port`, `pathname`, `search`, `hash`.
* Reactive read-only accessors: `origin` (reads `protocol`, `hostname`, `port`), `searchParams` (returns the bound `SvelteURLSearchParams`).
* `toString()` / `toJSON()` — delegate to the reactive `href` getter.

### `class SvelteURLSearchParams extends URLSearchParams`

* `new SvelteURLSearchParams(init?: string | URLSearchParams | Record<string, string>)` — native init; links to the constructing `SvelteURL` if created inside `new SvelteURL(...)`.
* Reactive reads: `get`, `getAll`, `has(name, value?)`, `keys`, `values`, `entries`, `[Symbol.iterator]`, `toString`, `size`.
* Reactive writes (auto-sync owning URL's `search`): `append`, `delete(name, value?)`, `set`, `sort`.
* Internal: `[REPLACE](params)` — bulk resync from a native `URLSearchParams` after `href`/`search` changes; guarded against re-entrancy.