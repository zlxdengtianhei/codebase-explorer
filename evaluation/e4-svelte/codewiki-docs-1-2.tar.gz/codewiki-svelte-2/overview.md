# `svelte-be645b4` — Repository Overview

## Purpose

This repository is the source of **Svelte**, a compiler-driven JavaScript framework for building user interfaces. Svelte's defining philosophy is to shift framework work from runtime to build time: `.svelte` (and `.svelte.js`) components are compiled ahead-of-time into small, tree-shakeable JavaScript modules and scoped CSS, rather than being interpreted by a large runtime in the browser.

Key characteristics of this generation of Svelte (runes era):

- **Signals-based reactivity** — `$state`, `$derived`, and `$effect` form a fine-grained dependency graph managed by the client runtime, with batched updates and scheduled effects.
- **One component, two targets** — the same source compiles to a *client* version (creates and reactively updates the DOM) and a *server* version (renders to HTML strings + payloads for SSR/hydration).
- **Stable public contract** — applications interact via `mount`, `hydrate`, and `unmount`, with full TypeScript component types.
- **Batteries included** — stores, motion (`spring`/`tweened`), transitions/animations/easing, reactive built-ins (`SvelteMap`, `SvelteSet`, `SvelteDate`, media queries, URL), and actions/attachments ship in the package.
- **Monorepo layout** — the compiler and runtimes live in `packages/svelte`, with `benchmarking/` suites and `playgrounds/` for engineering verification.

## End-to-End Architecture

### Compilation pipeline

```mermaid
flowchart LR
    SRC([".svelte / .svelte.js source"]) --> PRE["Preprocessor<br/>(compiler/preprocess)"]
    PRE --> P["1-parse<br/>template + JS/TS parser"]
    P --> A["2-analyze<br/>scopes · visitors · CSS analysis<br/>warnings & diagnostics"]
    A --> T["3-transform"]
    T --> CJ["client JS<br/>signal graph + DOM ops"]
    T --> SJ["server JS<br/>SSR render functions"]
    T --> CSS["scoped CSS"]
    CJ --> CR["Client runtime<br/>(internal/client)"]
    SJ --> SR["Server runtime<br/>(internal/server)"]
    CR --> APP["mount() / hydrate()<br/>in the browser"]
    SR --> OUT["render() → HTML + payload"]
```

### Module architecture

```mermaid
flowchart TD
    subgraph COMPILER["1 · Compiler Pipeline & Language Toolchain (packages/svelte/src/compiler)"]
        CORE["compiler core<br/>public API · compile state<br/>diagnostics · message codes"]
        PRE["preprocessor"]
        MIG["migrator (v4 → v5 codemods)"]
    end

    subgraph CLIENT["2 · Client Runtime Engine (src/internal/client)"]
        SIG["reactivity engine<br/>signals · deriveds · effects · batching"]
        DOMR["DOM renderer<br/>blocks · bindings · attributes<br/>transitions · custom elements"]
        DEVT["dev tooling<br/>HMR · ownership guards · validation"]
        LEG["legacy compat shims"]
    end

    subgraph SRV["3 · SSR & Cross-Target Services (src/internal)"]
        SSRR["server runtime<br/>render pipeline · payload"]
        CTX["context API (client + server)"]
        SHU["shared utils + snapshot<br/>conformance tests"]
    end

    subgraph API["4 · Public API & Built-in Features (src)"]
        ENT["client/server entries<br/>component types · HTML typings"]
        FEAT["stores · motion · transitions<br/>easing · reactive builtins · attachments"]
    end

    subgraph TOOLS["5 · Engineering Tooling"]
        BENCH["reactivity & SSR benchmarks"]
        TREE["treeshakeability checker"]
        SBX["sandbox playground"]
    end

    COMPILER -->|"emits code for"| CLIENT
    COMPILER -->|"emits code for"| SRV
    CLIENT --> API
    SRV --> API
    API -.->|"exercised by"| TOOLS
```

### Runtime execution flow

```mermaid
flowchart LR
    subgraph Server["Server (SSR)"]
        R["render(component, options)"] --> H["HTML string + payloads"]
    end
    subgraph Browser["Browser"]
        M["mount() / hydrate()"] --> SG["signal graph<br/>$state / $derived"]
        SG --> E["batched effects"]
        E --> D["DOM patches"]
        D -->|"events · bindings"| SG
    end
    H -->|"hydration"| M
```

## Core Modules

| Module | Scope | Documentation |
|---|---|---|
| **Compiler Pipeline & Language Toolchain** (`packages/svelte/src/compiler`) | Parse → analyze → transform phases, preprocessor, v4→v5 migrator, and compile-time/runtime message templates | [Compiler_Pipeline___Language_Toolchain.md](<Compiler_Pipeline___Language_Toolchain.md>) |
| **Client Runtime Engine (Reactivity & DOM Rendering)** (`src/internal/client`) | Signal graph (sources/proxies, deriveds, effects, batching), DOM renderer (control-flow blocks, bindings, transitions, custom elements), dev tooling (HMR, ownership guards), and legacy compatibility shims | [Client_Runtime_Engine_(Reactivity___DOM_Rendering).md](<Client_Runtime_Engine_(Reactivity___DOM_Rendering).md>) |
| **Server-Side Rendering & Cross-Target Runtime Services** (`src/internal`) | Server render pipeline and payload output, context API for both targets, shared utilities with snapshot conformance tests | [Server-Side_Rendering___Cross-Target_Runtime_Services.md](<Server-Side_Rendering___Cross-Target_Runtime_Services.md>) |
| **Public API & Built-in Feature Surface** (`packages/svelte/src`) | Client/server entry points, component contract types, HTML typings, plus built-ins: stores, motion, transitions/animations/easing, reactive collections, and attachments | [Public_API___Built-in_Feature_Surface.md](<Public_API___Built-in_Feature_Surface.md>) |
| **Engineering Tooling (Benchmarks, Verification & Playground)** (`benchmarking/`, `playgrounds/`) | Reactivity benchmark suites (kairo, sbench, mol), SSR benchmark wrapper, benchmark comparison harness, treeshakeability checker, and the sandbox playground (compile runner, share links) | [Engineering_Tooling_(Benchmarks,_Verification___Playground).md](<Engineering_Tooling_(Benchmarks,_Verification___Playground).md>) |

Together these modules implement Svelte's core promise: author simple declarative components, and the toolchain compiles them into minimal reactive code that runs efficiently on both the client and the server.