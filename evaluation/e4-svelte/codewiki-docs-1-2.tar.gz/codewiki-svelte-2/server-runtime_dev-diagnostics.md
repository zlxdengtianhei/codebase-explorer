# server-runtime_dev-diagnostics

The **dev-diagnostics** module provides development-mode-only safety and diagnosability services for Svelte's server-side rendering (SSR) engine. It has two source files, both under `packages/svelte/src/internal/server/`:

| Source file | Components | Responsibility |
|---|---|---|
| `dev.js` | `push_element`, `pop_element`, `validate_snippet_args` (+ internal `print_error`, `reset_elements`) | HTML content-model validation during SSR, snippet argument validation, element-tracking state isolation, and dual-channel (server + client console) error reporting |
| `abort-signal.js` | `getAbortSignal` (+ internal `abort`) | Lifecycle management of the `AbortController` used to cancel stale async work belonging to a finished render |

Everything in this module is **gated behind dev mode**: the compiler only emits calls into it when the `dev` compile option is set, and the render pipeline only wires it up in development. In production builds the module contributes effectively zero runtime cost — no stack tracking, no validation, no abort bookkeeping.

---

## 1. Position in the System

This module is a sub-module of [server-runtime](server-runtime_render-pipeline.md) within the *Server-Side Rendering & Cross-Target Runtime Services* domain. It sits **beside** the render pipeline rather than inside it: the render pipeline ([server-runtime_render-pipeline](server-runtime_render-pipeline.md)) produces markup through the [Payload](server-runtime_payload-and-output.md) abstraction, while dev-diagnostics *observes* that production and reports problems. It is the SSR counterpart of the compile-time diagnostics produced by [compiler-core_diagnostics](compiler-core_diagnostics.md): compile-time diagnostics catch authoring errors before code ships; SSR dev-diagnostics catch structural HTML mistakes that can only be detected while rendering.

```mermaid
flowchart TB
    subgraph CompileTime["Compile time — Compiler Pipeline"]
        TSF["compiler-transformer_server-transform<br/>(RegularElement visitor)"]
        CODE["compiled SSR component code"]
        TSF -- "if dev: emit $.push_element /<br/>$.pop_element" --> CODE
        TSF -- "if dev: emit $.validate_snippet_args" --> CODE
        TSF -- "attaches FILENAME key<br/>to component function" --> CODE
    end

    subgraph ServerRT["Server Runtime — internal/server"]
        subgraph DD["server-runtime_dev-diagnostics"]
            DEVJS["dev.js<br/>push_element / pop_element<br/>reset_elements<br/>validate_snippet_args<br/>print_error (internal)"]
            ABORT["abort-signal.js<br/>getAbortSignal / abort"]
        end
        RP["server-runtime_render-pipeline<br/>render()"]
        CTX["context-api (server side)<br/>current_component, push/pop"]
        PAY["server-runtime_payload-and-output<br/>Payload / HeadPayload"]
        ERR["server error catalog<br/>invalid_snippet_arguments"]
    end

    HTV["html-tree-validation.js<br/>is_tag_valid_with_parent<br/>is_tag_valid_with_ancestor"]
    CONST["src/constants.js<br/>FILENAME"]
    CCONST["client constants<br/>STALE_REACTION"]

    CODE --> RP
    RP -- "reset_elements() + restore()" --> DEVJS
    RP -- "abort() in finally block" --> ABORT
    DEVJS -- "reads current_component.function[FILENAME]" --> CTX
    DEVJS -- "injects console.error script into head.out" --> PAY
    DEVJS -- "throws on bad snippet payload" --> ERR
    DEVJS -- "content-model queries" --> HTV
    DEVJS -- "reads FILENAME key" --> CONST
    ABORT -- "abort reason constant" --> CCONST
```

---

## 2. Components

### 2.1 `dev.js` — element placement tracking & snippet validation

#### `push_element(payload, tag, line, column)`

Called by compiled SSR code immediately before the children of every **non-void element** are rendered. It:

1. Builds an `Element` record for the new tag, capturing the source location:
   - `tag` — element name (e.g. `"option"`),
   - `parent` — the previously open element (a linked list, effectively an explicit stack),
   - `filename` — read from `current_component.function[FILENAME]`, where `FILENAME` is the key under which the compiler attaches the source file to the component function and `current_component` is maintained by the context stack (see [context-api](context-api.md)),
   - `line` / `column` — source location baked into the compiled output by the server transform.
2. If there is an open parent element, validates the placement **against the immediate parent** via `is_tag_valid_with_parent(tag, parent.tag, child_loc, parent_loc)`, then walks **every ancestor** calling `is_tag_valid_with_ancestor(tag, ancestors, child_loc, ancestor_loc)`. This catches "descendant" rules (e.g. `<div>` inside `<p>` is illegal even across intermediate inline elements). Validation rules live in `html-tree-validation.js` and encode the HTML parsing content model, including:
   - `direct` — tags that may not be *direct* children,
   - `descendant` — tags that may not appear anywhere beneath,
   - `only` — whitelist semantics (e.g. `<table>` section elements),
   - `reset_by` — intermediate elements that re-enable otherwise-forbidden descendants,
   - blanket allowances for custom elements (names containing `-`) and direct children of `<template>`.
3. Any produced message is reported through the internal `print_error`, and the element is finally **pushed** onto the open-element stack.

#### `pop_element()`

Pops the stack when the element's children are done: `parent = parent.parent`. The compiler emits one `$.pop_element()` call after each validated element's closing content, keeping the stack perfectly balanced with `push_element`.

#### `reset_elements()`

Returns a closure that snapshots the current stack top, sets it to `null`, and restores the snapshot when invoked. The render pipeline's `render()` calls this in dev mode **before** invoking the user component, specifically to *"prevent parent/child element state being corrupted by a bad render"* — for example when a component throws mid-render and leaves the stack unbalanced, or when `render()` is called from inside another render. See the lifecycle sequence in §4.3.

#### `validate_snippet_args(payload)`

Defensive check emitted at the top of compiled snippet render functions. It verifies that the first argument is an object and an instance of `Payload` **or** `HeadPayload` (the `<svelte:head>` variant, since head snippets are invoked with a `HeadPayload` — see [server-runtime_slots-snippets-and-blocks](server-runtime_slots-snippets-and-blocks.md)). On failure it throws the `invalid_snippet_arguments` error via the server error catalog. This catches the common mistake of calling a snippet function manually with a wrong/missing payload argument.

#### `print_error(payload, message)` (internal)

The single reporting channel used by all placement validation failures:

- Prefixes the message with the runtime code `node_invalid_placement_ssr:` and appends an explanation that the browser will repair the HTML (content "shifts around") and that hydration will likely emit a `hydration_mismatch` warning afterwards.
- **Deduplicates** messages using a module-level `Set` (`seen`), so the same placement mistake — which fires on every render, for every affected node — is logged only once per process.
- Reports the problem on **two channels**:
  1. `console.error(...)` on the server, for the developer running SSR,
  2. an injected inline `<script>console.error(...)</script>` appended to `payload.head.out`, so the identical message appears in the **browser console** during hydration. This is essential for debugging deployed previews where server logs are inaccessible, and correlates directly with the client-side hydration machinery (see [client-dom-renderer_dom-foundation](client-dom-renderer_dom-foundation.md)).

Note that these placement problems are **non-fatal**: rendering continues and markup is still emitted; the goal is diagnosis, not failure. This contrasts with `validate_snippet_args`, which throws.

### 2.2 `abort-signal.js` — stale render cancellation

A tiny, self-contained service around a module-level `AbortController`:

```mermaid
stateDiagram-v2
    direction LR
    [*] --> NoController: module load
    NoController --> Active: getAbortSignal()<br/>lazily creates controller, returns .signal
    Active --> Active: getAbortSignal()<br/>returns same signal
    Active --> NoController: abort() — called in render() finally<br/>reason: STALE_REACTION
    NoController --> Active: next render requests a signal
```

- **`getAbortSignal()`** lazily creates the `AbortController` and returns its `signal`. The signal is handed to asynchronous work scheduled as part of a render (e.g. awaited snippet/async-mode work on the server) so that work can observe cancellation.
- **`abort()`** aborts the controller with the `STALE_REACTION` reason constant (imported from the client constants) and clears the reference. `render()` calls it in its `finally` block, guaranteeing that **every** render — successful or failed — invalidates any async work still attached to it. Because SSR of a single request is effectively synchronous-with-resumed-tasks, this prevents results of a superseded/finished render from leaking into a later one.

---

## 3. Data Structures

```mermaid
flowchart LR
    subgraph Stack["Open-element stack — module-global 'parent' (linked list)"]
        direction TB
        N3["Element { tag:'option', filename:'App.svelte',<br/>line, column, parent }"]
        N2["Element { tag:'select', filename, line, column, parent }"]
        N1["Element { tag:'form', filename, line, column, parent: null }"]
        N3 -- parent --> N2 -- parent --> N1
    end
    SEEN["seen : Set of already-reported messages<br/>(process-wide deduplication)"]
    CTRL["controller : AbortController or null<br/>(lazily created, cleared by abort)"]
```

- The stack is a plain linked list of `Element` records, not an array: each node points to its parent, and `pop_element` walks one link up. `parent === null` means no element is currently open (top of the render).
- `filename`/`line`/`column` are optional-but-populated in dev builds and are interpolated into validation messages so the report points at the exact `.svelte` source location of the offending tag.
- `seen` is **never reset between renders** — deduplication is deliberately process-wide to keep repeated SSR renders and hot-reload loops from spamming identical errors.

---

## 4. Process Flows

### 4.1 Element placement validation during SSR

The compiler's server transform emits the instrumentation **only in dev builds** (see the `RegularElement` visitor in [compiler-transformer_server-transform](compiler-transformer_server-transform.md)):

```js
// compiled output sketch (dev only)
$.push_element($$payload, 'option', 12, 4);
/* ...render children... */
$.pop_element();
```

End-to-end sequence:

```mermaid
sequenceDiagram
    participant App as render(component, options)
    participant DD as dev-diagnostics (dev.js)
    participant V as html-tree-validation
    participant P as Payload / HeadPayload
    participant C as compiled component

    App->>DD: reset_elements()
    DD-->>App: restore() closure
    App->>C: component(payload, props)
    loop for each non-void element with children
        C->>DD: push_element(payload, tag, line, col)
        DD->>DD: build Element record<br/>(filename via current_component.function[FILENAME])
        DD->>V: is_tag_valid_with_parent(tag, parent.tag, childLoc, parentLoc)
        V-->>DD: message | null
        alt message
            DD->>P: print_error → head.out.push(script console.error)
            P-->>App: (script will run in browser during hydration)
        end
        loop for each remaining ancestor
            DD->>V: is_tag_valid_with_ancestor(tag, ancestors, childLoc, ancestorLoc)
            V-->>DD: message | null
            alt message
                DD->>P: print_error(...)
            end
        end
        DD->>DD: parent = child (push)
        C->>DD: (children rendered...)
        C->>DD: pop_element()
        DD->>DD: parent = parent.parent
    end
    App->>App: finally
    App->>DD: restore() and abort()
```

### 4.2 `push_element` decision flow

```mermaid
flowchart TD
    A["push_element(payload, tag, line, column)"] --> B["create child Element record<br/>(tag, parent, filename, line, column)"]
    B --> C{"parent !== null ?"}
    C -- "no — first element of render" --> Z["push: parent = child"]
    C -- yes --> D["query is_tag_valid_with_parent(...)"]
    D --> E{"message?"}
    E -- yes --> F["print_error(payload, message)"]
    E -- no --> G["prepare ancestors walk"]
    F --> G
    G --> H{"ancestor != null ?"}
    H -- yes --> I["query is_tag_valid_with_ancestor(tag, ancestors, ...)"]
    I --> J{"message?"}
    J -- yes --> K["print_error(payload, message)"]
    J -- no --> L["ancestor = ancestor.parent"]
    K --> L
    L --> H
    H -- "no — stack root reached" --> Z
    Z --> Y["return — compiled code renders children"]
```

`print_error` itself short-circuits on the `seen` set, so repeated identical violations across renders cost one `Set.has` lookup:

```mermaid
flowchart LR
    M["validation message"] --> S{"seen.has(message) ?"}
    S -- yes --> X["skip (deduplicated)"]
    S -- "no (first occurrence)" --> A["seen.add(message)"]
    A --> CS["console.error on server"]
    A --> INJ["payload.head.out.push(<br/>inline script: console.error)<br/>→ surfaces in browser console"]
```

### 4.3 Dev render lifecycle (state isolation + abort)

```mermaid
sequenceDiagram
    participant R as render() — render-pipeline
    participant DD as dev-diagnostics
    participant W as user component tree

    R->>DD: reset_elements()
    Note over DD: old stack top saved, parent = null
    R->>W: invoke component(payload, props)
    W->>DD: push_element / pop_element pairs
    alt render throws
        W--xR: error propagates
        Note over DD: unbalanced stack is isolated —<br/>the saved snapshot is unaffected
    else render succeeds
        W-->>R: markup complete
    end
    R->>DD: restore() — reinstate saved stack top
    R->>DD: abort() — finally
    Note over DD: controller.abort(STALE_REACTION),<br/>controller = null
```

---

## 5. Integration Summary

| Direction | Counterpart | Interaction |
|---|---|---|
| Consumer | [server-runtime_render-pipeline](server-runtime_render-pipeline.md) | `render()` calls `reset_elements()` (dev) before rendering, restores afterwards, and calls `abort()` in `finally` |
| Producer | [compiler-transformer_server-transform](compiler-transformer_server-transform.md) | Emits `$.push_element` / `$.pop_element` around non-void element children and `$.validate_snippet_args` at snippet function entry — only when compiling in dev mode |
| Reads | [context-api](context-api.md) | `push_element` reads `current_component.function[FILENAME]` to attribute violations to the owning component's source file |
| Writes | [server-runtime_payload-and-output](server-runtime_payload-and-output.md) | `print_error` appends an inline `console.error` script to `Payload.head.out` |
| Throws via | server error catalog | `validate_snippet_args` raises `invalid_snippet_arguments` |
| Queries | `html-tree-validation.js` | Content-model rule tables and the `is_tag_valid_with_parent` / `is_tag_valid_with_ancestor` predicates |
| Constants | `src/constants.js` (`FILENAME`), client constants (`STALE_REACTION`) | Key for component source filename; abort reason for stale renders |
| Sibling diagnostics | [compiler-core_diagnostics](compiler-core_diagnostics.md) | Compile-time errors/warnings; this module covers what only manifests at render time |
| Downstream effect | [client-dom-renderer_dom-foundation](client-dom-renderer_dom-foundation.md) | Invalid placements trigger browser HTML repair, which the client hydration phase reports as `hydration_mismatch` |

---

## 6. Design Notes & Caveats

- **Dev-only by construction.** No `if (DEV)` branches exist *inside* this module for the tracking path — the gating happens upstream: the compiler simply never emits the calls, and `render()` never wires up `reset_elements`, in production. This keeps the production codegen clean and the hot path untouched.
- **Non-fatal vs. fatal diagnostics.** Element placement violations are logged (twice — server and browser console) but rendering continues, matching browser recovery semantics. Bad snippet arguments throw immediately, since continuing would produce undefined behavior rather than merely mis-nested HTML.
- **Module-global state.** `parent`, `seen`, and `controller` are module-level. This is safe under the SSR model of one render at a time per module instance, and `reset_elements` defends against nested or failing renders corrupting the stack. Multi-instance server setups (worker threads, separate bundles) each get their own state.
- **Process-wide error deduplication.** `seen` intentionally survives across renders so a systematic template error is reported once, not once per request; restart (or HMR reload of the module) resets it.
- **Message portability.** Because violation messages are embedded in the rendered HTML head, they survive serialization to the client — a deliberate choice that makes SSR structure bugs debuggable from the browser alone.
- **The abort signal complements, but does not implement, dev diagnostics.** It lives beside `dev.js` because both services exist to make development-time SSR behavior observable and safe: `dev.js` explains *what* went wrong structurally; `abort-signal.js` ensures *stale* async work from a completed render can never interleave with a subsequent render's output. The re-entrant `getAbortSignal` accessor keeps the API surface to a single function for the async machinery to consume.