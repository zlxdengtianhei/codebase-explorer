# Public API & Built-in Feature Surface

## Purpose

The `Public_API___Built-in_Feature_Surface` module (rooted at `packages/svelte`) constitutes everything that a Svelte consumer directly imports and interacts with. It has two responsibilities:

1. **Public entry points & types** — the `svelte` (client) and `svelte/server` (server) module entry points, the `Component` type model, and the ambient HTML/SVG typings, which together define the stable, versioned contract of the `svelte` package.
2. **Built-in feature libraries** — the batteries-included runtime features that ship with Svelte: the store contract and primitives, motion (`spring`/`tweened`), transitions/animations/easing, reactive wrappers around standard built-ins, and actions/attachments for DOM element integration.

The module is a thin, mostly re-exporting layer: the feature libraries are implemented on top of the internal client/server runtimes (signals, effects, blocks), while the compiler and the type definitions make them usable from `.svelte` files.

## Architecture

```mermaid
flowchart LR
    subgraph Entries["Public Entry Points (public-api)"]
        CE["Client entry<br/>(svelte)"]
        SE["Server entry<br/>(svelte/server)"]
        CT["Component types"]
        HT["HTML typings"]
    end

    subgraph Features["Built-in Feature Libraries"]
        ST["stores<br/>writable · readable · derived · get"]
        MO["motion<br/>spring · tweened"]
        TR["transition<br/>transitions · animations · easing"]
        RB["reactivity<br/>SvelteMap · SvelteSet · SvelteDate · SvelteURL · MediaQuery"]
        AT["attachments/actions<br/>action contract · attachment bridge"]
    end

    subgraph Types["Type Definitions"]
        ID["types/index.d.ts<br/>(public types)"]
        ED["elements.d.ts<br/>(element/attribute typings)"]
    end

    subgraph Internals["Internal Runtimes"]
        CR["Client reactivity engine<br/>(signals, effects, DOM)"]
        SR["Server runtime<br/>(SSR rendering)"]
    end

    CE --> ST & MO & TR & RB & AT
    SE --> TR
    ST & MO & RB & AT --> CR
    TR --> CR
    TR --> SR
    ID --> CT
    ED --> HT
    ST --> MO
```

Key architectural points:

- **Entry-point composition**: `public-api` composes the client and server entries and re-exports the feature libraries, so all user-facing imports resolve through one curated surface (see [public-api](<public-api.md>)).
- **Layered dependency**: `stores` defines the subscription contract and primitives; `motion` is built on top of stores; `reactive-builtins` and `attachments` integrate directly with the client reactivity engine and DOM layering; transitions/animations serve both client-side DOM manipulation and server-side payload rendering.
- **Type-only submodules**: `svelte-public-types` (`packages/svelte/types/index.d.ts`) and `svelte_dom_type_definitions` (`packages/svelte/elements.d.ts`) are pure declaration files — they contribute no runtime code but define the TypeScript surface for components and elements.

## Core Components

| Component | Documentation | Summary |
|---|---|---|
| `public-api` | [public-api.md](<public-api.md>) | Client (`svelte`) and server (`svelte/server`) entry points, `Component` types, and HTML ambient typings — the package's public contract. |
| `stores` | [stores.md](<stores.md>) | The store contract, core primitives (`writable`, `readable`, `derived`), `get`, and bridges between stores and runes. |
| `motion` | [motion.md](<motion.md>) | Reactive value animation via `spring` and `tweened`. |
| `transitions-animations-easing` | [transitions-animations-easing.md](<transitions-animations-easing.md>) | Built-in `transition:` functions (`fade`, `fly`, …), `animate:` helpers, and the easing function catalog. |
| `reactive-builtins` | [reactive-builtins.md](<reactive-builtins.md>) | Reactive replacements for standard built-ins: collections (`SvelteMap`, `SvelteSet`, `SvelteDate`), temporal values, `SvelteURL`, and `MediaQuery`. |
| `actions-attachments` | [actions-attachments.md](<actions-attachments.md>) | The `use:` action contract and the newer `Attachment` type, including bridging between the two styles. |
| `svelte-public-types` | — (`packages/svelte/types/index.d.ts`, no docs page) | Aggregated public type declarations for the package. |
| `svelte_dom_type_definitions` | [svelte_dom_type_definitions.md](<svelte_dom_type_definitions.md>) | `elements.d.ts`: typings for all HTML/SVG elements and attributes, including Svelte-specific ones. |

## Relationship to Other Modules

- It sits **above** the *Client Runtime Engine* and *Server-Side Rendering* modules — the feature libraries delegate reactivity, effects, DOM updates, and SSR payload emission to those internals.
- It is **shaped by** the *Compiler Pipeline*: compiler transforms emit calls into these runtime helpers, and the parser/validations enforce the contracts (e.g., store usage, transition naming) documented here.
- The *Engineering Tooling* module (treeshakeability checker, benchmarks) validates that this surface stays tree-shakeable and performant.