# Public API: HTML Typings for the Language Server (`public-api_html-typings`)

## 1. Purpose & Scope

The **`public-api_html-typings`** module — implemented entirely in `packages/svelte/svelte-html.d.ts` — provides the **TypeScript type surface for Svelte template markup as seen by the Svelte language server**. It answers, at the type level, questions like:

- *Which attributes may appear on `<button>`?* → `HTMLButtonAttributes` merged with global attribute shims
- *What DOM element does `<svg><circle/></svg>` produce?* → `SVGCircleElement`
- *What handler signature satisfies `onclick={...}` on an `<a>`?* → `MouseEventHandler<HTMLAnchorElement>`
- *What happens with a dynamic tag `<svelte:element this={tag}/>`?* → graceful degradation to `any`

Critically, this module contains **no runtime code and is not part of the package exports map**:

```ts
// This file is deliberately not exposed through the exports map.
// It's meant to be loaded directly by the Svelte language server
```

The language server (via `svelte2tsx`) transforms `.svelte` templates into equivalent TypeScript that calls the **`svelteHTML.createElement`** / **`svelteHTML.mapElementTag`** functions declared here, so that the plain TypeScript checker can verify markup. This makes the module the *contract between Svelte language tools and the TypeScript type system*.

For the runtime and type surfaces that *are* publicly imported, see [public-api](public-api.md) and its siblings [public-api_component-types](public-api_component-types.md), [public-api_client-entry](public-api_client-entry.md), and [public-api_server-entry](public-api_server-entry.md). The attribute vocabulary this module composes from lives in [svelte_dom_type_definitions](svelte_dom_type_definitions.md) (`packages/svelte/elements.d.ts`).

---

## 2. Component Inventory

| Declaration | Kind | Stability | Purpose |
|---|---|---|---|
| `namespace svelteHTML` | `declare global { namespace }` | Internal contract (`@internal do not use`) | Ambient global namespace the language server resolves template code against |
| `mapElementTag(tag)` | function (3 overloads) | `@internal do not use` | Maps a tag-name literal to its DOM element class (`ElementTagNameMap` / `SVGElementTagNameMap`), `any` fallback for dynamic tags |
| `createElement(element, attrs)` | function (2 overloads) | `@internal do not use` | Typed stand-in for an element in compiled template code; validates attributes against `IntrinsicElements[Key]` |
| `createElement(element, attrsEnhancers, attrs)` | function overload | `@internal do not use` | Same, with an extra *enhancers* object slot used for attachment keys |
| `HTMLProps<Property, Override>` | type helper | `@internal do not use` | `Omit<SvelteHTMLElements[Property], keyof Override> & Override` — composes per-element types with an augmentable override layer |
| `HTMLAttributes<T>` | `interface` (empty) | ⚠️ Compat shim, slated for removal in Svelte 6 | Declaration-merging hook for *global* HTML attribute augmentations |
| `SVGAttributes<T>` | `interface` (empty) | ⚠️ Compat shim, slated for removal in Svelte 6 | Same hook for SVG attributes |
| `IntrinsicElements` | `interface` | Internal; prefer `SvelteHTMLElements` | Full tag map: ~116 HTML + 58 SVG entries, each typed via `HTMLProps`, extending `svelteElements.SvelteHTMLElements`; open index signature for custom elements |

Nothing is exported. All declarations are **ambient globals** (`declare global { ... }`), activated when the file is pulled into a TS program by the language server.

---

## 3. Position in the System

This module is one of four children of [public-api](public-api.md). Unlike its siblings it is **not reachable through any import specifier** — the language server loads it by file path into every `.svelte`-aware TS program:

```mermaid
flowchart TB
    subgraph IDE["Editor / IDE"]
        DEV["Developer edits template<br/>&lt;button onclick={handler}&gt;"]
        LS["Svelte Language Server<br/>(svelte2tsx)"]
    end

    subgraph MODULE["public-api_html-typings — svelte-html.d.ts (this module)"]
        NS["declare global namespace svelteHTML"]
        CREATE["createElement()"]
        MAP["mapElementTag()"]
        PROPS["HTMLProps&lt;Property, Override&gt;"]
        SHIMS["HTMLAttributes / SVGAttributes<br/>empty compat shims"]
        INTR["IntrinsicElements<br/>~116 HTML + 58 SVG tags"]
    end

    subgraph DEPS["Dependencies"]
        EL["svelte_dom_type_definitions<br/>(packages/svelte/elements.d.ts)<br/>SvelteHTMLElements · HTMLAttributes ·<br/>SVGAttributes · AriaAttributes · DOMAttributes"]
        DOM["TypeScript 'dom' lib<br/>ElementTagNameMap · SVGElementTagNameMap<br/>EventTarget"]
    end

    DEV --> LS
    LS -- "loads file directly<br/>(bypasses exports map)" --> NS
    NS --> CREATE
    NS --> MAP
    NS --> PROPS
    NS --> SHIMS
    NS --> INTR
    INTR == "extends" ==> EL
    PROPS -- "base member" --> EL
    PROPS -- "override member" --> SHIMS
    CREATE -- "return type resolution" --> MAP
    MAP -- "resolves tag to class" --> DOM
    EL -- "attribute/handler types" --> DOM

    style MODULE fill:#e8f0fe,stroke:#3367d6,stroke-width:2px
```

Key relationships:

- **Downward dependency (only one):** `import * as svelteElements from './elements.js'`. Everything attribute-related — `SvelteHTMLElements`, `HTMLAttributes`, `SVGAttributes`, `AriaAttributes`, `DOMAttributes` (event handler maps) — is *inherited* from [svelte_dom_type_definitions](svelte_dom_type_definitions.md). This module adds the *namespace mechanics* and *per-tag composition* on top.
- **Upward consumer:** the Svelte language server / `svelte2tsx`, which emits template code shaped as `svelteHTML.createElement(...)` / `svelteHTML.mapElementTag(...)`.
- **Sibling relationship:** `DOMAttributes` event maps reference `import('svelte').Snippet` (the `children` prop), connecting this module's element types to the `Snippet` contract documented in [public-api_component-types](public-api_component-types.md).
- **Not related to:** [svelte-public-types](svelte-public-types.md) (`packages/svelte/types/index.d.ts`) — that file aggregates *compilation* types; this file is IDE-only and intentionally absent from every public entry point.
- **Unrelated to the compiler:** the [Compiler Pipeline & Language Toolchain](Compiler_Pipeline___Language_Toolchain.md) never reads this file; it validates markup through its own analysis phases. This module only affects *editor diagnostics*, never emitted code.

---

## 4. The `svelteHTML` Namespace — a Contract with Language Tools

The file wraps everything in `declare global { namespace svelteHTML { ... } }`. Per the source comment, *"Every namespace eligible for use needs to implement the following two functions"* — `mapElementTag` and `createElement`. This is the handshake with `svelte2tsx`:

```mermaid
flowchart TB
    subgraph NS["declare global · namespace svelteHTML"]
        direction TB
        F1["mapElementTag()&lt;K&gt;<br/>3 overloads"]
        F2["createElement()&lt;Elements, Key&gt;<br/>2 overloads"]
        T1["type HTMLProps&lt;Property, Override&gt;<br/>= Omit&lt;SvelteHTMLElements[Property], keyof Override&gt;<br/>&amp; Override"]
        I1["interface HTMLAttributes&lt;T&gt; {}<br/>(empty, augmentable)"]
        I2["interface SVGAttributes&lt;T&gt; {}<br/>(empty, augmentable)"]
        I3["interface IntrinsicElements<br/>extends svelteElements.SvelteHTMLElements<br/>+ index signature"]
    end

    F2 -- "resolves element &amp; attr types" --> I3
    F2 -- "return type" --> F1
    I3 -- "each key defined as" --> T1
    T1 -- "Override parameter" --> I1
    T1 -- "Override parameter" --> I2
```

The namespace has **no runtime existence** — the source states: *"This namespace does not exist in the runtime, it is only used for typings."* It exists purely so that generated template code has a well-known, augmentable scope to type against.

---

## 5. Core Type Reference

### 5.1 `HTMLProps<Property, Override>` — the composition primitive

```ts
type HTMLProps<Property extends string, Override> = Omit<
    import('./elements.js').SvelteHTMLElements[Property],
    keyof Override
> & Override;
```

Given a tag-name literal and an override interface, it:

1. **Omits** from the base element type every key present in `Override` — so the override layer can *replace* (not merely add) attributes;
2. **Intersects** the override back in.

Because the shipped `svelteHTML.HTMLAttributes` / `SVGAttributes` are empty, `keyof Override` is `never` out of the box and `HTMLProps<'a', HTMLAttributes>` collapses to exactly `SvelteHTMLElements['a']`. The moment a user augments the shim (see [§8](#8-extending-the-typings-declaration-merging)), their members flow into **every** element through this one helper.

### 5.2 `mapElementTag` — tag name → DOM class

Three overloads implement the resolution order:

| Overload | Input | Return | Use case |
|---|---|---|---|
| 1 | `K extends keyof ElementTagNameMap` | `ElementTagNameMap[K]` | HTML tags, e.g. `'button'` → `HTMLButtonElement` (powers `bind:this` typing) |
| 2 | `K extends keyof SVGElementTagNameMap` | `SVGElementTagNameMap[K]` | SVG tags, e.g. `'circle'` → `SVGCircleElement` |
| 3 | `tag: any` | `any` | `<svelte:element>` with a runtime-computed string |

### 5.3 `createElement` — typed element instantiation

```ts
function createElement<Elements extends IntrinsicElements, Key extends keyof Elements>(
    // "undefined | null" because of <svelte:element>
    element: Key | undefined | null,
    attrs: string extends Key ? svelteElements.HTMLAttributes<any> : Elements[Key]
): Key extends keyof ElementTagNameMap ? ElementTagNameMap[Key]
   : Key extends keyof SVGElementTagNameMap ? SVGElementTagNameMap[Key]
   : any;
```

Design points:

- **`Key | undefined | null`** accepts the possibly-empty `this` binding of `<svelte:element>`.
- **Dynamic-tag fallback:** when `Key` is an unliteral `string`, `string extends Key` becomes true and attributes degrade to the generic `HTMLAttributes<any>` instead of a specific element's contract.
- **Return type** resolves through the tag maps to the concrete DOM class (mirroring `mapElementTag`), or `any`.
- **Second overload** adds an `attrsEnhancers: T` middle parameter whose members are intersected into the attribute check. This is how **attachments** (via `createAttachmentKey()`, see [actions-attachments](actions-attachments.md)) type-check: `svelte2tsx` moves attachment entries into this slot.

### 5.4 `HTMLAttributes` / `SVGAttributes` — empty augmentation shims

```ts
// TODO remove HTMLAttributes/SVGAttributes/IntrinsicElements in Svelte 6
// For backwards-compatibility and ease-of-use, in case someone enhanced
// the typings from import('svelte/elements').HTMLAttributes/SVGAttributes
interface HTMLAttributes<T extends EventTarget = any> {}
interface SVGAttributes<T extends EventTarget = any> {}
```

These deliberately **empty** interfaces are the *global augmentation points* consumed by `HTMLProps`. They exist for two reasons:

1. **Backwards compatibility** — projects that enhanced `svelte.JSX.HTMLAttributes` (Svelte 4) keep compiling.
2. **Ease of use** — a single augmentable interface applies attributes across all elements without touching `elements.d.ts`.

They are marked for removal in Svelte 6; prefer augmenting `import('svelte/elements').HTMLAttributes` (documented in [svelte_dom_type_definitions](svelte_dom_type_definitions.md)).

### 5.5 `IntrinsicElements` — the tag map

```ts
interface IntrinsicElements extends svelteElements.SvelteHTMLElements {
    a: HTMLProps<'a', HTMLAttributes>;
    abbr: HTMLProps<'abbr', HTMLAttributes>;
    /* … ~114 more HTML tags … */
    webview: HTMLProps<'webview', HTMLAttributes>;   // non-standard (Electron)
    // SVG
    svg: HTMLProps<'svg', SVGAttributes>;
    circle: HTMLProps<'circle', SVGAttributes>;
    /* … 56 more SVG tags … */

    [name: string]: { [name: string]: any };   // custom elements / web components
}
```

Composition facts:

- **Extends `SvelteHTMLElements`**, inheriting both real elements and Svelte's special elements (`svelte:window`, `svelte:document`, `svelte:body`, `svelte:fragment`, `svelte:options`, `svelte:head`, `svelte:boundary`) — so `createElement('svelte:boundary', { onerror, failed, pending })` type-checks too.
- **Each HTML key** wraps the specialized base type (e.g. `HTMLButtonAttributes`, `HTMLImgAttributes`, `HTMLInputAttributes`) with the shim override layer. **Each SVG key** likewise wraps `SVGAttributes<SVGCircleElement>`-style bases.
- **Open index signature** `[name: string]: { [name: string]: any }` permits arbitrary custom elements with unchecked attributes — typed opt-in is possible via augmentation ([§8](#8-extending-the-typings-declaration-merging)).
- The doc comment steers consumers: *avoid using this interface directly; use `SvelteHTMLElements` from `svelte/elements`, unless extending with custom elements*.

---

## 6. Type-Checking Data Flow

How a template attribute error becomes an editor squiggle:

```mermaid
sequenceDiagram
    autonumber
    participant Dev as Developer (.svelte file)
    participant S2T as svelte2tsx / Language Server
    participant HTML as svelte-html.d.ts (this module)
    participant EL as elements.d.ts
    participant TS as TypeScript checker

    Dev->>S2T: &lt;button class="primary" onclick={handler}&gt;
    S2T->>HTML: emits svelteHTML.createElement('button', { class: 'primary', onclick: handler })
    HTML->>EL: resolve IntrinsicElements['button'] = HTMLProps<'button', HTMLAttributes>
    EL-->>HTML: base = HTMLButtonAttributes (props + ARIA + DOM events)
    HTML->>TS: attr type = Omit<HTMLButtonAttributes, keyof HTMLAttributes> & HTMLAttributes
    TS->>TS: check handler : (e: MouseEvent) => void against MouseEventHandler<HTMLButtonElement>
    TS-->>Dev: ✓ diagnostics · hover types · attribute completions
```

Dynamic elements follow the *degradation* path instead: `<svelte:element this={maybeUndefined}>` compiles to `createElement(maybeUndefined, …)`, where `Key` is `string | undefined | null` → generic `HTMLAttributes<any>` attributes and an `any` return.

---

## 7. Type Composition Mechanics

```mermaid
flowchart LR
    BASE["SvelteHTMLElements['a']<br/>HTMLAnchorAttributes<br/>(svelte_dom_type_definitions)"] -- "Omit …, keyof Override" --> P["HTMLProps&lt;'a', HTMLAttributes&gt;"]
    SHIM["svelteHTML.HTMLAttributes<br/>empty + user augmentations"] -- "&amp; Override" --> P
    P -- "IntrinsicElements.a" --> CE["createElement('a', attrs)"]
    CE -- "return type" --> MAP["ElementTagNameMap['a']<br/>= HTMLAnchorElement"]

    AUG["declare global augmentation<br/>namespace svelteHTML"] -. "declaration merging" .-> SHIM
    AUG -. "declaration merging" .-> BASE2["IntrinsicElements<br/>(custom element entries)"]

    style P fill:#fff3e0,stroke:#ef6c00
    style CE fill:#e8f5e9,stroke:#2e7d32
```

The orange node is the single point where *vendor-shipped* attribute knowledge ([svelte_dom_type_definitions](svelte_dom_type_definitions.md)) meets *user-extendable* typing — every template attribute check funnels through it.

---

## 8. Extending the Typings (Declaration Merging)

Because everything lives in an ambient namespace, projects and design systems extend typings without forking files:

**a) Add a global attribute to all HTML elements:**

```ts
declare global {
    namespace svelteHTML {
        interface HTMLAttributes {
            'data-analytics-track'?: string;
        }
    }
}
export {}; // keep the file a module
```

The member joins every element via `HTMLProps`'s `& Override` arm ([§7](#7-type-composition-mechanics)).

**b) Type a custom element / web component:**

```ts
declare global {
    namespace svelteHTML {
        interface IntrinsicElements {
            'fancy-chart': {
                theme?: 'dark' | 'light';
                'bind:this'?: FancyChart | null;
            };
        }
    }
}
export {};
```

Without this, `<fancy-chart>` still compiles through the open index signature but with `any` attributes.

**c) The supported alternative:** augment `import('svelte/elements').HTMLAttributes` / `SvelteHTMLElements` directly — these flow into `IntrinsicElements` through the `extends` clause. The `svelteHTML.*` shims exist only as the convenience/compat layer and are scheduled for removal in Svelte 6.

---

## 9. Design Decisions & Constraints

| Decision | Rationale / Consequence |
|---|---|
| **Not in the exports map** | The file is an implementation detail of the language server; it can change between releases without semver implications. Applications must never `import 'svelte/svelte-html'`. |
| **`declare global` namespace** | Generated template code needs no imports; ambient resolution keeps transformed output minimal. |
| **`/// <reference lib="dom" />`** | Guarantees `ElementTagNameMap`, `SVGElementTagNameMap`, and `EventTarget` exist even in `lib`-restricted projects. |
| **`Omit` + intersection (`HTMLProps`)** | Lets the shim layer *override* base attributes, not only add to them. |
| **Empty compat shims with TODO (Svelte 6)** | Preserves v4-era augmentation patterns (`svelte.JSX.HTMLAttributes`) during the migration window. |
| **`undefined | null` element parameter** | First-class support for `<svelte:element this={possiblyEmpty}>`. |
| **`any` fallbacks (`mapElementTag` overload 3, index signature)** | Ensures dynamic tags and unknown custom elements never produce false-positive errors — correctness of *diagnostics* is prioritized over exhaustiveness for unknowable shapes. |
| **`webview` entry** | Non-standard Electron element retained for Electron-based Svelte apps. |
| **No compiler involvement** | Editor-only fidelity; the [compiler](Compiler_Pipeline___Language_Toolchain.md) independently validates markup via its analyze phase (e.g. [compiler-analyzer_visitors](compiler-analyzer_visitors.md)). |

---

## 10. Related Modules

| Module | Relationship |
|---|---|
| [public-api](public-api.md) | Parent module; documents why the language-server typings are one of the package's three responsibilities |
| [svelte_dom_type_definitions](svelte_dom_type_definitions.md) | **Sole dependency** — supplies `SvelteHTMLElements`, `HTMLAttributes`, `SVGAttributes`, `AriaAttributes`, `DOMAttributes` (the actual attribute/event vocabulary) |
| [public-api_component-types](public-api_component-types.md) | `Snippet` contract referenced by the inherited `children` prop on every element; event-handler semantics |
| [svelte-public-types](svelte-public-types.md) | Sibling type aggregator for compile-time types; deliberately does *not* include this IDE-only file |
| [actions-attachments](actions-attachments.md) | `createAttachmentKey()` attachments are typed through `createElement`'s `attrsEnhancers` overload |
| [Compiler_Pipeline___Language_Toolchain](Compiler_Pipeline___Language_Toolchain.md) | Independent markup validation; never consumes this file |
