# internal-shared-utils: Core Utilities

> **Module:** `packages/svelte/src/internal/shared/utils.js`
> **Parent:** [internal-shared-utils](internal-shared-utils.md)
> **Core components:** `noop`, `run`, `to_array`

---

## 1. Introduction

`internal-shared-utils_core-utilities` is the **lowest layer of the Svelte runtime**: a small, dependency-free collection of general-purpose helpers that both the client runtime (reactivity engine + DOM renderer) and the server runtime (SSR) rely on. It exists to guarantee that the *same* primitive operations — invoking callbacks, normalizing iterables, providing a stable "do nothing" function — behave identically across every execution target Svelte supports (browser, Node, custom elements, hydration).

The module lives in a single file, `packages/svelte/src/internal/shared/utils.js`, which is referenced by compiler-emitted component code through the internal `$` namespace (e.g. `$.run`, `$.to_array`, `$.noop`) as well as imported directly by internal client/server modules.

Three properties define this module's role in the architecture:

1. **Leaf module** — it imports nothing from the rest of the codebase (only standard globals), so every subsystem above it may depend on it without creating cycles.
2. **Isomorphic** — every export is safe to execute in the browser *and* on the server; there is no DOM, no `window`, and no Node-specific API usage.
3. **Monkey-patch hardened** — references to frequently-mocked built-ins (`Array.isArray`, `Object.keys`, `Object.prototype`, …) are captured once at module load so popular browser extensions that patch globals cannot de-optimize hot runtime paths.

---

## 2. Position within `internal-shared-utils`

The core-utilities module is one of four children of the [internal-shared-utils](internal-shared-utils.md) module. It provides the *mechanical primitives*; the siblings provide *diagnostics and guarantees* on top of those primitives.

```mermaid
flowchart TB
    subgraph PARENT["internal-shared-utils"]
        direction LR
        CU["<b>core-utilities</b><br/>utils.js<br/><i>(this module)</i>"]
        VG["validation-guards<br/>validate.js"]
        EM["error-messages<br/>errors.js"]
        SCT["snapshot-conformance-tests<br/>clone.test.ts"]
    end

    VG -- "guards before mutating" --> CU
    EM -- "throws typed errors" --> CU
    SCT -- "asserts behavior parity" --> CU

    style CU fill:#4a90d9,color:#fff
    style VG fill:#e8eef7
    style EM fill:#e8eef7
    style SCT fill:#e8eef7
```

- [internal-shared-utils_validation-guards](internal-shared-utils_validation-guards.md) — `validate_dynamic_element_tag` / `validate_void_dynamic_element` assert that runtime values passed to `<svelte:element>` are legal, *before* calling into utilities.
- [internal-shared-utils_error-messages](internal-shared-utils_error-messages.md) — centralized dev/prod error factories such as `invalid_default_snippet`, which generated code invokes when a structural invariant (e.g. `{@render children(...)}` misuse) is violated.
- [internal-shared-utils_snapshot-conformance-tests](internal-shared-utils_snapshot-conformance-tests.md) — conformance tests (e.g. `capture_warnings` in `clone.test.ts`) that pin shared behavior across targets.

---

## 3. Public Surface

### 3.1 Core components (the module's designated API)

| Component | Signature | Purpose |
|---|---|---|
| `noop` | `() => void` | A stable, allocation-free empty function used as a default/placeholder callback. |
| `run` | `(fn: Function) => any` | Invoke `fn()` and return its result. A trivial indirection that keeps generated code small and lets teardown/dispatch paths stay uniform. |
| `to_array` | `<T>(value: ArrayLike<T> \| Iterable<T>, n?: number) => Array<T>` | Normalize an array-like or iterable into a real array, with **bounded iteration** support for unbounded iterables during destructuring. |

```javascript
export const noop = () => {};

/** @param {Function} fn */
export function run(fn) {
	return fn();
}
```

`to_array` implements the strategy required by patterns such as `let [a, b, c] = $derived(blah())`: the intermediate derived value may be *any* iterable (possibly unbounded, like a generator), so the runtime must know how many bindings to drain.

```javascript
export function to_array(value, n) {
	// 1. Arrays pass through unchanged (identity — no copying cost)
	if (Array.isArray(value)) return value;

	// 2. Rest elements (n === undefined) or non-iterables → unbounded convert
	if (n === undefined || !(Symbol.iterator in value)) {
		return Array.from(value);
	}

	// 3. Finite iterable with known arity → drain exactly n items
	const array = [];
	for (const element of value) {
		array.push(element);
		if (array.length === n) break;
	}
	return array;
}
```

```mermaid
flowchart TD
    A["to_array(value, n)"] --> B{"Array.isArray(value)?"}
    B -- "yes" --> R1["<b>return value</b><br/>(same reference, zero-copy)"]
    B -- "no" --> C{"n === undefined<br/>(rest element)<br/>or not iterable?"}
    C -- "yes" --> R2["<b>Array.from(value)</b><br/>(array-likes & rest bindings)"]
    C -- "no" --> D["<b>manual loop, stop at n</b><br/>(bounded drain of a<br/>potentially unbounded iterable)"]
```

### 3.2 Supporting exports in the same file

These helpers are part of the same core-utilities surface and are used pervasively by the runtime:

| Export | Signature | Notes |
|---|---|---|
| `is_function` | `(thing) => thing is Function` | Simple type guard. |
| `is_promise` | `<T>(value) => value is PromiseLike<T>` | Thenable check, adapted from [`then/is-promise`](https://github.com/then/is-promise) (MIT). |
| `run_all` | `(arr: Array<() => void>) => void` | Sequential invocation of teardown/dispose lists (classic `for` loop, no closures). |
| `deferred` | `<T>() => { promise, resolve, reject }` | Exposes a promise's resolver functions — a `Promise.withResolvers` stand-in until browser support is universal. |
| `fallback` | `<V>(value, fallback: V \| (() => V), lazy?) => V` | `undefined`-coalescing for props/params, with optional lazy evaluation of the default. |

### 3.3 Captured globals (monkey-patch defense)

The top of the file caches standard-library references *once*, at module initialization:

| Captured binding | Original |
|---|---|
| `is_array` | `Array.isArray` |
| `index_of` | `Array.prototype.indexOf` |
| `array_from` | `Array.from` |
| `object_keys` | `Object.keys` |
| `define_property` | `Object.defineProperty` |
| `get_descriptor` / `get_descriptors` | `Object.getOwnPropertyDescriptor` / `…Descriptors` |
| `object_prototype` / `array_prototype` | `Object.prototype` / `Array.prototype` |
| `get_prototype_of` | `Object.getPrototypeOf` |
| `is_extensible` | `Object.isExtensible` |

Rationale (from the source comment): popular extensions (ad blockers, dev tools) frequently monkey-patch these globals, which would otherwise cause the runtime's call sites to **de-opt** (fall off the JIT fast path) on every invocation. Freezing the references at load time keeps the reactivity engine's hot loops monomorphic and fast.

---

## 4. Architecture & Dependency View

The core-utilities module sits at the very bottom of the dependency graph. Everything below it is a language global; everything above it — client reactivity, DOM rendering, SSR, context, public stores — may import it.

```mermaid
flowchart BT
    CU["<b>core-utilities</b><br/>utils.js<br/><i>zero internal deps</i>"]

    subgraph RUNTIME["Runtime subsystems"]
        direction LR
        CE["client-reactivity-engine"]
        CD["client-dom-renderer"]
        CTX["context-api<br/>(client + server)"]
        SR["server-runtime<br/>(SSR)"]
    end

    subgraph PUBLIC["Public API surface"]
        ST["stores<br/>(derived / get / update)"]
    end

    GEN["Compiler-emitted<br/>component code<br/>($.run / $.to_array / $.noop)"]

    CU --> CE
    CU --> CD
    CU --> CTX
    CU --> SR
    CU --> ST
    GEN --> CU

    style CU fill:#4a90d9,color:#fff
```

Verified integration points (from the codebase):

| Consumer | Utility used | Where / how |
|---|---|---|
| **client-reactivity-engine** → [props-and-stores](client-reactivity-engine.md) | `noop` | `store_unsub` (client `reactivity/store.js`) swaps a stale store subscription's teardown for `noop` (`entry.unsubscribe = noop`) so later unsubscribe calls are safe no-ops while the reference is resubscribed to a new store. |
| **client-reactivity-engine** → [deriveds-and-async](client-reactivity-engine.md) | `is_promise` | `await_block` (client `dom/blocks/await.js`) uses the thenable check to branch between pending/then/catch effects. |
| **client-dom-renderer** → [control-flow-blocks](client-dom-renderer.md) | `run`, `run_all`, `noop` | Effect teardown and block disposal lists are plain arrays of `() => void`, drained via `run_all`/`run`; unattached hooks default to `noop`. |
| **server-runtime** ([server-runtime](server-runtime.md)) | `run`, `to_array`, `noop` | SSR code paths call the same helpers, guaranteeing client/server parity (destructuring semantics, default callbacks). |
| **Compiler-emitted code** | `$.to_array` | Generated output for `let [a, b] = $derived(...)` calls `to_array(value, n)` — see the file's own doc comment about stashing the intermediate destructuring value. |
| **Public stores** ([stores](stores.md)) | `run`, `noop` | Shared store helpers (`derived`, `get`, `update` in `store/shared/index.js`) reuse the same primitives rather than duplicating them. |

> Because the compiler pipeline (see [Compiler_Pipeline___Language_Toolchain](Compiler_Pipeline___Language_Toolchain.md)) emits calls into this module, **any signature change here is a breaking change for compiled output**, not just for internal callers.

---

## 5. Interaction Flows

### 5.1 Safe store resubscription (`noop` as inert teardown)

When a `{@store}` binding's underlying store is replaced, the old unsubscribe function must be neutralized *without* leaving a dangling call path. `noop` provides the inert terminal value:

```mermaid
sequenceDiagram
    autonumber
    participant G as Generated component code
    participant S as store_get / store_unsub<br/>(client reactivity)
    participant Old as Old store
    participant New as New store

    G->>S: store_get(container, name, Old)
    S->>Old: subscribe(cb)
    Note over S: entry.unsubscribe = Old teardown

    G->>S: store_get(container, name, New)
    S->>S: store_unsub detects entry.store !== store
    S->>Old: entry.unsubscribe()
    S->>S: entry.unsubscribe = <b>noop</b>
    S->>New: subscribe(cb)
    Note over S: Until resubscription resolves,<br/>any teardown call is a safe no-op
```

### 5.2 Destructuring a derived value (`to_array` bounded drain)

```mermaid
sequenceDiagram
    autonumber
    participant C as Generated component
    participant U as core-utilities<br/>to_array
    participant Sig as $derived signal

    C->>Sig: read derived value
    Sig-->>C: iterable / array-like
    C->>U: to_array(value, n = 2)

    alt value is an Array
        U-->>C: same array reference (zero-copy)
    else rest element or non-iterable
        U-->>C: Array.from(value)
    else unbounded iterable (e.g. generator)
        U-->>C: array with exactly n elements<br/>(iteration stops early)
    end

    C->>C: destructure bindings [a, b]
```

The early-exit in branch 3 is what makes destructuring from lazy/infinite iterables safe — only as many elements as there are binding slots are ever pulled.

---

## 6. Design Rationale & Invariants

1. **No internal imports.** The file imports nothing from `svelte/src/**`. This makes it the safe bottom of the graph and keeps client, server, and custom-element bundles free of accidental cross-target coupling.
2. **Isomorphism.** Every helper is environment-agnostic. Target-specific behavior (e.g. `requestAnimationFrame` in `tick`, DOM hydration) lives *above* this layer in [client-reactivity-engine](client-reactivity-engine.md) and [client-dom-renderer](client-dom-renderer.md).
3. **Monkey-patch immunity.** Built-ins are captured as module-level constants. Hot paths (proxy traps, equality checks, prop spread handlers) call the captured bindings, staying monomorphic even if globals are patched later.
4. **Allocation discipline.** Helpers use classic `for` loops (`run_all`, `to_array`) instead of `forEach`/spread, and `noop` is a single shared function instance — important because these are called in per-update paths across every component instance.
5. **Forward-compatible async support.** `deferred` exists only because `Promise.withResolvers` is not yet universally available; it can be deleted once baseline support arrives. `is_promise` accepts any *thenable*, not just native promises, matching Svelte's relaxed `{#await}` semantics.
6. **Tree-shakeability.** All exports are small, independent, side-effect-free functions (only the global-capture constants are module-scope side effects, and they are pure). Unused helpers disappear from production bundles — the same property the [treeshakeability checker](Engineering_Tooling__Benchmarks__Verification___Playground.md) enforces elsewhere.

---

## 7. Change-Impact Notes for Maintainers

- **`to_array` semantics are observable** in compiled output. The three-way branch (array passthrough / `Array.from` / bounded drain) and the meaning of `n === undefined` (rest element ⇒ unbounded conversion is acceptable) are relied upon by the [compiler transformer](Compiler_Pipeline___Language_Toolchain.md) when lowering array/object destructuring patterns.
- **`noop` identity matters.** Code compares or assigns teardown references (see `store_unsub` above); replacing `noop` with an inline `() => {}` would allocate a fresh closure per call site and break fast-path comparisons.
- **`run`/`run_all` are the universal dispatch convention.** Teardown arrays and effect bodies across the client runtime assume "call, in order, synchronously" semantics; introducing async behavior here would ripple through [client-reactivity-engine](client-reactivity-engine.md), [server-runtime](server-runtime.md), and [context-api](context-api.md).

---

## 8. Related Documentation

- Parent module: [internal-shared-utils](internal-shared-utils.md)
- Siblings: [internal-shared-utils_validation-guards](internal-shared-utils_validation-guards.md) · [internal-shared-utils_error-messages](internal-shared-utils_error-messages.md) · [internal-shared-utils_snapshot-conformance-tests](internal-shared-utils_snapshot-conformance-tests.md)
- Consumers: [client-reactivity-engine](client-reactivity-engine.md) · [client-dom-renderer](client-dom-renderer.md) · [server-runtime](server-runtime.md) · [context-api](context-api.md) · [stores](stores.md)
- Wider system: [Server-Side_Rendering___Cross-Target_Runtime_Services](Server-Side_Rendering___Cross-Target_Runtime_Services.md) · [Client_Runtime_Engine_(Reactivity___DOM_Rendering)](Client_Runtime_Engine_(Reactivity___DOM_Rendering).md) · [Public_API___Built-in_Feature_Surface](Public_API___Built-in_Feature_Surface.md)
