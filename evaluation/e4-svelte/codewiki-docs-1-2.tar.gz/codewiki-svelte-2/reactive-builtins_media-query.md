# reactive-builtins_media-query

## 1. Overview

The `reactive-builtins_media-query` module implements **`MediaQuery`**, the reactive class exported from [`svelte/reactivity`](public-api.md) that wraps the browser's `window.matchMedia()` API in Svelte's signal-based reactivity system. It lets components **react to viewport/device media state changes** (screen size, orientation, print mode, `prefers-color-scheme`, etc.) declaratively:

```svelte
<script>
	import { MediaQuery } from 'svelte/reactivity';

	const large = new MediaQuery('min-width: 800px');
</script>

<h1>{large.current ? 'large screen' : 'small screen'}</h1>
```

The module ships **two implementations behind one contract**, selected by environment:

| Component | File | Environment | Behavior |
|---|---|---|---|
| `MediaQuery` (real) | `packages/svelte/src/reactivity/media-query.js` | Client (browser) | Live value driven by `window.matchMedia` + `change` events |
| `MediaQuery` (stub) | `packages/svelte/src/reactivity/index-server.js` | Server (SSR) | Static value from the `fallback` constructor argument (default `false`) |
| `createSubscriber` (stub) | `packages/svelte/src/reactivity/index-server.js` | Server (SSR) | No-op, keeps the reactivity facade import-safe on the server |

Key design properties:

- **Lazy subscriptions** — the underlying `change` event listener is only attached while at least one Svelte effect is reading `.current`; it is torn down (refcount-style) when the last consuming effect is destroyed.
- **SSR-safe** — universal code can instantiate `MediaQuery` on the server without crashing; the server stub resolves `.current` to the provided fallback, which prevents hydration crashes but *can* cause a hydration mismatch (documented caveat below).
- **Ergonomic queries** — a normalizer auto-parenthesizes feature-only queries (`'min-width: 800px'` → `'(min-width: 800px)'`) while preserving valid keyword queries (`'screen'`, `'not print and (color)'`) unchanged.

This module is one of the **[reactive-builtins](reactive-builtins.md)** — alongside [reactive-builtins_collections](reactive-builtins_collections.md) (`SvelteMap`), [reactive-builtins_temporal](reactive-builtins_temporal.md) (`SvelteDate`) and [reactive-builtins_url](reactive-builtins_url.md) (`SvelteURL`, `SvelteURLSearchParams`) — which collectively provide drop-in reactive replacements for platform globals.

---

## 2. Architecture

### 2.1 High-level structure

The module is split along the client/server boundary of the `svelte/reactivity` entry point. Bundlers resolve the export via package export conditions (`browser` → `index-client.js`, server default → `index-server.js`).

```mermaid
flowchart TB
    subgraph Public["Public API — svelte/reactivity (see public-api.md)"]
        EC["Export conditions resolver"]
    end

    subgraph Client["Client bundle (browser)"]
        IC["reactivity/index-client.js<br/>(entry)"]
        MQ["reactivity/media-query.js<br/>MediaQuery extends ReactiveValue&lt;boolean&gt;"]
        RV["reactivity/reactive-value.js<br/>ReactiveValue (base class)"]
        CS["reactivity/create-subscriber.js<br/>createSubscriber"]
        ON["events/index.js → internal/client/dom/elements/events.js<br/>on(element, type, handler)"]
        RE["Client reactivity engine<br/>(source / render_effect / effect_tracking)<br/>see client-reactivity-engine.md"]
    end

    subgraph Server["Server bundle (SSR)"]
        IS["reactivity/index-server.js"]
        MQS["class MediaQuery<br/>{ current = fallback }"]
        CSS["createSubscriber<br/>no-op stub"]
    end

    subgraph Platform["Web platform"]
        MQL["window.matchMedia(query)<br/>MediaQueryList<br/>.matches / 'change' event"]
    end

    EC -->|"browser condition"| IC
    EC -->|"server condition"| IS
    IC --> MQ
    IC --> CS
    MQ -->|"extends"| RV
    RV -->|"uses"| CS
    MQ -->|"listens 'change'"| ON
    ON --> MQL
    CS -->|"sources, render_effects,<br/>effect tracking"| RE
    IS --> MQS
    IS --> CSS
    MQ -->|"constructor calls"| MQL
```

### 2.2 Component reference

#### `MediaQuery` — `packages/svelte/src/reactivity/media-query.js` (client, the real implementation)

```js
export class MediaQuery extends ReactiveValue {
	constructor(query, fallback) { /* ... */ }
}
```

- **`extends ReactiveValue<boolean>`** — inherits the lazy `current` getter (see [§3 Subscription lifecycle](#3-subscription-lifecycle)).
- **`constructor(query: string, fallback?: boolean)`**
  1. **Normalizes** the query (see [§2.3 Query normalization](#23-query-normalization)).
  2. Evaluates `window.matchMedia(final_query)` once, producing a `MediaQueryList`.
  3. Delegates to the base class with:
     - a **value getter** `() => q.matches` — re-evaluated on every read;
     - an **`onsubscribe` callback** `(update) => on(q, 'change', update)` — called by `createSubscriber` the first time `.current` is read inside an effect; `on` returns an unsubscriber that tears the listener down later.
- The `fallback` parameter is accepted for signature parity with the server stub (client code never needs it).
- Public API: `.current` (readonly getter, `boolean`). Available since Svelte 5.7.0.

#### `MediaQuery` — `packages/svelte/src/reactivity/index-server.js` (server stub)

```js
export class MediaQuery {
	current;
	constructor(query, matches = false) {
		this.current = matches;
	}
}
```

- Constructor argument is renamed `matches` (the effective server value) — same positional contract as the client's `fallback`.
- `current` is a plain property, not a getter: no reactivity, no listeners, no DOM access. This guarantees that isomorphic component code (`new MediaQuery('min-width: 800px')`) runs identically during SSR.

#### `createSubscriber` — `packages/svelte/src/reactivity/index-server.js` (server stub)

```js
export function createSubscriber(_) {
	return () => {};
}
```

- Returned function does nothing; the server never tracks effects.
- Exists so `index-server.js` is a self-contained, dependency-free facade mirroring the client entry's export surface.

---

### 2.3 Query normalization

A media feature must be parenthesized in CSS (`(min-width: 800px)`), but bare media types/keywords (`screen`, `print`, `not all`, `only screen and (color)`) must **not** be wrapped. `MediaQuery` applies auto-parenthesization only when it is unambiguous — this fixes false matches such as `new MediaQuery('screen')` being turned into `(screen)` (sveltejs/svelte#15930).

```mermaid
flowchart TD
    A["query input"] --> B{"/\\(.+\\)/ tests true?<br/>(contains parentheses)"}
    B -- yes --> F["use query as-is"]
    B -- no --> C{"every space/comma-separated<br/>token ∈ non_parenthesized_keywords?"}
    C -- "yes (e.g. 'screen', 'not print')" --> F
    C -- "no (e.g. 'min-width: 800px')" --> E["wrap → (query)"]
    F --> G["window.matchMedia(final_query)"]
    E --> G

    K["non_parenthesized_keywords =<br/>{all, print, screen, and, or, not, only}"]
```

> The keyword check uses `Array.prototype.some` on tokens split by `/[\s,]+/`: if **any** token is a recognized keyword, the string is assumed to be a well-formed query and left untouched. This is safe because a keyword can only appear as a bare token in valid query syntax.

---

## 3. Subscription lifecycle

`MediaQuery` has **no listeners at construction time**. Reactivity is wired by `createSubscriber` (see the full engine integration in [client-reactivity-engine_signal-graph.md](client-reactivity-engine_signal-graph.md)), which is reference-counted over Svelte effects:

```mermaid
sequenceDiagram
    participant C as Component code
    participant MQ as MediaQuery
    participant SUB as createSubscriber closure
    participant E as Svelte effects (engine)
    participant MQL as MediaQueryList (matchMedia)

    C->>MQ: new MediaQuery('min-width: 800px')
    MQ->>MQL: window.matchMedia('(min-width: 800px)')
    Note over MQ,MQL: No event listeners attached yet

    C->>E: render_effect(() => mq.current)
    E->>SUB: subscribe() — effect_tracking() === true
    SUB->>SUB: get(version) — registers dependency
    SUB->>E: create render_effect
    Note over SUB: subscribers === 0 → start once
    SUB->>MQL: on(q, 'change', update) via untrack
    SUB->>SUB: subscribers = 1

    MQL-->>SUB: 'change' event (e.g. viewport resized)
    SUB->>SUB: update() → increment(version)
    E-->>C: effect re-runs → reads .current again

    C->>E: effect destroyed
    E->>SUB: teardown (deferred via queue_micro_task)
    SUB->>SUB: subscribers -= 1 → 0
    SUB->>MQL: stop() — remove 'change' listener
    SUB->>SUB: increment(version) — mark dependents dirty<br/>for correct re-subscription later
```

Behavioral rules enforced by `createSubscriber`:

1. **Start-once semantics** — `start` (the `on(q, 'change', …)` wiring) runs only while `subscribers === 0`, regardless of how many effects read `.current`.
2. **Reads outside effects are passive** — `.current` returns `q.matches` without subscribing (`effect_tracking()` is false → no-op).
3. **Microtask-deferred teardown** — the refcount decrements inside a microtask so that a render effect that re-runs in the same tick does not tear down and immediately re-subscribe (which would leak the old listener).
4. **Version bump on stop** — the internal `source(0)` version counter is incremented when the last subscriber leaves, guaranteeing that a `derived` reading `.current` is correctly marked dirty when it re-subscribes later.

The base class glues this together in three lines:

```js
get current() {
	this.#subscribe();   // (re)activate subscription if inside an effect
	return this.#fn();   // () => q.matches
}
```

---

## 4. Data flow

End-to-end path from a platform event to a DOM update:

```mermaid
flowchart LR
    subgraph Browser
        VR["Viewport / device state<br/>(resize, print, color-scheme…)"] -->|change| MQL["MediaQueryList"]
    end
    MQL -->|"on(q, 'change', update)"| U["update callback"]
    U -->|"increment(version)"| V["version source signal"]
    V -->|"invalidates"| EFF["Dependent render_effect"]
    EFF -->|"reads"| CUR["MediaQuery.current"]
    CUR -->|"q.matches"| DOM["Component template / DOM update"]
```

SSR data flow (no signals involved):

```mermaid
flowchart LR
    A["new MediaQuery('min-width: 800px', fallback)"] -->|"index-server.js stub"| B["current = fallback (default false)"]
    B --> C["Serialized into SSR HTML"]
    C -->|hydration| D["Client MediaQuery takes over;<br/>mismatch possible if fallback ≠ actual state"]
```

---

## 5. Relationship to the rest of the system

- **Reactivity engine** — `MediaQuery` builds directly on `ReactiveValue` → `createSubscriber` → the signal graph (`source`, `render_effect`, `effect_tracking`, `untrack`) and the microtask scheduler of [client-reactivity-engine](client-reactivity-engine.md). It is a canonical example of **integrating an external push-based API** into pull-based signals; the same pattern underlies `createSubscriber`'s documented use cases (`IntersectionObserver`, `WebSocket`, etc.).
- **DOM events infrastructure** — listener attachment uses the shared `on()` helper re-exported by `packages/svelte/src/events/index.js` from [client-dom-renderer_attributes-events](client-dom-renderer_attributes-events.md), which guarantees consistent event registration/removal with the renderer's event system.
- **SSR runtime** — the server stub complements the server render pipeline ([server-runtime](server-runtime.md)): components render with the static fallback, hydration then reconciles with real client state.
- **Public surface** — exported from `svelte/reactivity` via [public-api](public-api.md); the type `MediaQuery` is also re-exported from the package-level type surface (`packages/svelte/types/index.d.ts`).
- **Sibling reactive builtins** — same pattern family: [reactive-builtins_collections](reactive-builtins_collections.md), [reactive-builtins_temporal](reactive-builtins_temporal.md), [reactive-builtins_url](reactive-builtins_url.md). Those classes subclass *existing* globals; `MediaQuery` instead wraps a *factory API* (`matchMedia`) on top of the `ReactiveValue` base class, which it shares conceptually with `createSubscriber` users.

---

## 6. Usage guidelines & caveats

1. **Hydration mismatch** — during SSR there is no way to know the true media state; content rendered from `.current` may change upon hydration. Prefer CSS media queries when the effect can be expressed in styles; pass an accurate `fallback` when you must use JS.
2. **Multiple instances, multiple listeners** — each `MediaQuery` instance owns its own `MediaQueryList` and listener; reuse a single instance (module scope or context) rather than constructing per read.
3. **Query normalization is permissive by design** — keyword-containing queries are never wrapped. If a query both lacks parentheses and contains a recognized keyword token (e.g. `'screen, (min-width: 600px)'` — already valid as-is), pass a fully parenthesized string to be explicit.
4. **Availability** — added in Svelte 5.7.0; requires `window` (client) — on the server the stub makes construction safe but inert.

---

## 7. Change checklist for maintainers

When modifying this module, verify:

- [ ] Normalization edge cases: `'screen'`, `'not print and (color)'`, `'min-width: 800px'`, `'random,screen'` (issue #15930 regression test).
- [ ] Listener teardown: destroying the last consuming effect removes the `change` listener (no leak) — governed by `createSubscriber`'s microtask-deferred refcount.
- [ ] Re-subscription correctness: `derived`s reading `.current` after a full teardown must re-run (version bump on stop).
- [ ] Server/client contract parity: constructor signature `(query, fallback|matches)` and the `.current` property must stay in sync between `media-query.js` and `index-server.js`.
