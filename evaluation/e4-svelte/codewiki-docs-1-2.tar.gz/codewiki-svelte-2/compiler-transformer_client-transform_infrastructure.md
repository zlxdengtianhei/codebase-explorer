# Client Transform Infrastructure (`compiler-transformer_client-transform_infrastructure`)

> **Module scope:** `packages/svelte/src/compiler/phases/3-transform/client/utils.js`, `packages/svelte/src/compiler/phases/3-transform/client/transform-template/template.js`, `packages/svelte/src/compiler/phases/3-transform/client/visitors/shared/function.js`

## 1. Introduction

The **client transform infrastructure** module is the shared foundation of the client-side code generation phase of the Svelte compiler. The sibling visitor modules — [structural-visitors](compiler-transformer_client-transform_structural-visitors.md), [expression-visitors](compiler-transformer_client-transform_expression-visitors.md) and [directive-visitors](compiler-transformer_client-transform_directive-visitors.md) — each know how to transform *one* AST node type. This module provides the cross-cutting machinery that *all* of them depend on:

1. **Binding & signal plumbing** (`client/utils.js`) — decides how every value reference, prop and derived signal is *read* and *written* in the generated code, and computes the parameters required when a function is hoisted out of the per-instance render scope.
2. **Static template accumulation** (`client/transform-template/template.js`) — collects the static markup of a component into a `Template` object that is serialized either as an HTML string (`as_html`) or as a JS tree literal (`as_tree`) and instantiated once at module scope.
3. **Function hoisting** (`visitors/shared/function.js`) — `visit_function` rewrites function expressions whose metadata marks them as instance-independent (typically event handlers) into hoistable functions with explicitly computed parameters.

The infrastructure itself contains no per-node-type logic; it is consumed by every visitor of the client transform and is the bridge between the **analyzer output** (scopes, bindings, per-node metadata) and the **client runtime** (`$.prop`, `$.derived`, `$.from_html`, `$.from_tree`, …).

For the overall orchestration of the client transform (entry point, visitor dispatch, output assembly), see [compiler-transformer_client-transform](compiler-transformer_client-transform.md).

---

## 2. Component Inventory

| File | Component | Kind | Responsibility |
|---|---|---|---|
| `client/utils.js` | `visit` (local) | internal helper | Mini visitor used with `zimmerframe`'s `walk` inside `get_hoisted_params`; in dev mode it detects `AssignmentExpression` / `UpdateExpression` on props inside a candidate hoisted function so a `$$ownership_validator` param can be injected. |
| `client/utils.js` | `is_state_source` | predicate | Does a `state` / `raw_state` binding need a reactive signal source? |
| `client/utils.js` | `build_getter` | builder | Rewrites an `Identifier` reference into the read expression installed by its declaration visitor (`state.transform[name].read`). |
| `client/utils.js` | `build_hoisted_params` (+ private `get_hoisted_params`) | builder | Computes the parameter list a hoisted function needs to close over its free bindings explicitly. |
| `client/utils.js` | `get_prop_source` | builder | Emits `$.prop($$props, name, flags, initial?)` with lazily-wrapped initial values. |
| `client/utils.js` | `is_prop_source` | predicate | Must a prop be read through `$.prop` instead of plain `$$props.x` access? |
| `client/utils.js` | `should_proxy` | predicate | Does an initial value need a reactive proxy? |
| `client/utils.js` | `create_derived` | builder | Emits `$.derived` / `$.derived_safe_equal` (and the async `$.async_derived` + `$.save` variant). |
| `transform-template/template.js` | `Template` | class | Stack-based accumulator of static markup; tracks `contains_script_tag` and `needs_import_node` flags. |
| `transform-template/template.js` | `stringify` | serializer | Template node tree → XHTML-compliant HTML string (attributes escaped, `<!>` for empty comments). |
| `transform-template/template.js` | `objectify` | serializer | Template node tree → JS array-literal AST for `$.from_tree`. |
| `visitors/shared/function.js` | `visit_function` | shared visitor | Entry point for `ArrowFunctionExpression` / `FunctionExpression`; applies hoisting when `node.metadata.hoisted === true`. |

---

## 3. Architecture

```mermaid
flowchart TB
    subgraph STATE["ComponentClientTransformState (carried through every visit)"]
        T["template: Template"]
        H["hoisted[]"]
        Q["init[] / update[] / after_update[]"]
        TR["transform{ name → read/assign }"]
    end

    subgraph INFRA["Infrastructure (this module)"]
        UTILS["client/utils.js<br/>build_getter · is_state_source · is_prop_source<br/>get_prop_source · should_proxy · create_derived<br/>build_hoisted_params"]
        TMPL["transform-template/template.js<br/>Template · stringify · objectify"]
        FN["visitors/shared/function.js<br/>visit_function"]
    end

    subgraph VIS["Visitor modules (consumers)"]
        STRUCT["structural-visitors<br/>Fragment · RegularElement · EachBlock …"]
        EXPR["expression-visitors<br/>Identifier · AssignmentExpression …"]
        DIR["directive-visitors<br/>On / Bind / Transition / Use / Let …"]
        SHARED["visitors/shared/utils.js<br/>validate_mutation · build_attribute_value"]
    end

    BLD["compiler-core_ast_builders<br/>(b.* ESTree factory)"]
    SCOPE["compiler-analyzer_scope<br/>(Scope · Binding kinds)"]
    RT["Client Runtime Engine<br/>$.prop · $.derived · $.state<br/>$.from_html · $.from_tree …"]

    STRUCT -- "new Template(), push_element,<br/>set_prop, pop_element" --> TMPL
    EXPR -- "build_getter, is_state_source,<br/>should_proxy, create_derived" --> UTILS
    DIR -- "sets metadata.hoisted = true" --> FN
    FN -- "build_hoisted_params" --> UTILS
    UTILS -- "validate_mutation (dev only)" --> SHARED
    UTILS -- "scope.get(), binding.kind,<br/>references" --> SCOPE
    UTILS -- "b.call, b.thunk, b.id, b.literal" --> BLD
    TMPL -- "b.template, b.quasi, b.array, b.object" --> BLD
    UTILS -.- T
    UTILS -.- TR
    TMPL -.- T
    INFRA -- "emits $.<*> runtime calls" --> RT
```

**Key relationships**

- The transform **state object** (`ComponentClientTransformState`, defined in `3-transform/types.d.ts` / `client/types.js`) is the data bus: it carries the current `Template` accumulator, the statement queues (`init`, `update`, `after_update`, `hoisted`) and the per-binding `transform` map. The infrastructure reads and mutates this state; it owns no global mutable data of its own.
- **Scope/Binding** objects produced by the [analyzer](compiler-analyzer_scope.md) are the input to every predicate in `utils.js` (`binding.kind`, `binding.reassigned`, `binding.updated`, `scope.references`).
- All emitted code is manufactured through the shared AST builders (`b.*`), documented in [compiler-core_ast_builders](compiler-core_ast_builders.md).

---

## 4. Data Flow Through the Client Transform

```mermaid
flowchart LR
    A["Analyzed Svelte AST<br/>scopes · bindings · metadata"] --> B["visit walk<br/>(dispatch per node type)"]
    B --> C{"Node kind?"}
    C -- "static markup" --> D["Template accumulator<br/>push_element / push_text / set_prop"]
    C -- "reactive value read" --> E["build_getter · get_prop_source<br/>create_derived · should_proxy"]
    C -- "function / handler" --> F["visit_function →<br/>build_hoisted_params"]
    D --> G["as_html() or as_tree()"]
    E --> H["init / update / after_update<br/>statement queues + transform map"]
    F --> H
    G --> I["$.from_html / $.from_tree<br/>hoisted module-level variable"]
    H --> J["Component instance function<br/>(CompileResult client output)"]
    I --> J
```

- **Static markup** never becomes statements — it accumulates in the `Template` and is hoisted as one template variable per fragment (created by the `Fragment` visitor).
- **Reactive reads** become either direct identifiers or calls into the runtime, decided by the predicates below.
- **Functions** are either transformed in place or rewritten as hoisted functions with explicit parameters.

---

## 5. Binding Read Infrastructure (`client/utils.js`)

### 5.1 The `state.transform` map and `build_getter`

When a declaration visitor (e.g. for `let x = $state(0)` or a prop) transforms a binding, it installs a *read function* into `state.transform[binding.name]`. Every subsequent identifier reference is routed through `build_getter`:

```js
export function build_getter(node, state) {
  if (Object.hasOwn(state.transform, node.name)) {
    const binding = state.scope.get(node.name);
    if (node !== binding?.node) {                 // don't transform the declaration itself
      return state.transform[node.name].read(node);
    }
  }
  return node;                                    // plain identifier (imports, locals, …)
}
```

This is the single choke point that turns `count` into `$.get(count)`-style reads, `$$props` member accesses, or store reads — the expression-visitors ([Identifier](compiler-transformer_client-transform_expression-visitors.md)) call it for every reference.

### 5.2 Decision predicates and signal factories

```mermaid
flowchart TD
    ID["Identifier reference"] --> G{"state.transform has<br/>binding name?"}
    G -- "no" --> RAW["keep original identifier"]
    G -- "yes" --> T["binding's read function<br/>installed at declaration time"]

    subgraph DEC["Decision helpers used by declaration visitors"]
        K{"binding.kind"}
        K -- "state / raw_state" --> S1{"is_state_source:<br/>!immutable OR reassessed OR accessors"}
        S1 -- "yes" --> S2["reactive source read<br/>(proxy / signal)"]
        S1 -- "no" --> S3["plain value<br/>(no source needed)"]
        K -- "prop / bindable_prop" --> P1{"is_prop_source:<br/>runes-mode accessors, reassignment,<br/>initial, or legacy updates"}
        P1 -- "yes" --> P2["get_prop_source:<br/>$.prop($$props, name, flags, initial?)"]
        P1 -- "no" --> P3["direct $$props.x access"]
        K -- "derived" --> D1["create_derived:<br/>$.derived / $.derived_safe_equal thunk"]
        IN["state initializer"] --> PR["should_proxy:<br/>literals, templates, functions,<br/>unary/binary and undefined → no proxy"]
    end
```

**`get_prop_source` flag bitfield** (constants from `constants.js`):

| Flag | Constant | Set when |
|---|---|---|
| bindable | `PROPS_IS_BINDABLE` | binding kind is `bindable_prop` |
| immutable | `PROPS_IS_IMMUTABLE` | `analysis.immutable` |
| runes | `PROPS_IS_RUNES` | `analysis.runes` |
| updated | `PROPS_IS_UPDATED` | accessors enabled, or binding reassigned/updated (legacy coarse-grained reactivity) |
| lazy initial | `PROPS_IS_LAZY_INITIAL` | initial value wrapped in a thunk to avoid eager evaluation |

`get_prop_source` is careful about evaluation timing: a *simple* initial value is passed directly; a zero-arg call is passed as the function itself; anything else is wrapped with `b.thunk(...)` and flagged `PROPS_IS_LAZY_INITIAL`, so the default is only computed when the prop is actually absent.

**`create_derived`** encodes the legacy/runes split in one place: legacy components get `$.derived_safe_equal` (coarse equality checks), runes-mode components get `$.derived`; async expressions are wrapped as `await $.save($.async_derived(thunk))`.

---

## 6. Function Hoisting (`utils.js` + `visitors/shared/function.js`)

Event handlers and other instance-independent functions are hoisted out of the component instance function so they are created once per component *type* instead of once per instance. Hoisting turns implicit closures into explicit parameters.

### 6.1 Process

```mermaid
sequenceDiagram
    autonumber
    participant V as Directive visitor (e.g. OnDirective)
    participant F as visit_function
    participant U as build_hoisted_params
    participant S as Scope / Binding
    participant O as Output AST

    V->>F: context.visit(arrow / function expression)
    F->>F: state setup (in_constructor, in_derived)
    alt metadata.hoisted === true
        F->>U: build_hoisted_params(node, context)
        U->>S: resolve scope.references
        S-->>U: bindings: store_sub, prop, derived, import …
        U->>U: push_unique params (+ $$props, + validator in dev)
        U-->>F: Pattern[] params (stored on node.metadata.hoisted_params)
        F->>O: rebuild node as { ...node, params }
        F->>F: context.visit(body) with fresh state
        F-->>V: hoisted FunctionExpression
    else not hoisted
        F->>F: context.next(state)
        F-->>V: in-place transformed function
    end
```

### 6.2 Parameter resolution rules (`get_hoisted_params`)

The function walks `scope.references` (free variables) and pushes unique parameters:

- **Store subscriptions** (`$store`): both the subscription *and* the store are passed, because reads need the subscription while writes (`store.set`) need the store object.
- **Derived bindings**: a heuristic extracts the signal reference from the already-built `$.get(x)` member expression and passes `x` directly.
- **Props / bindable props** read through `$$props`: only `$$props` is passed (the reference is an object property access, not the binding variable itself).
- **Rest props** in runes mode: both the destructured binding and `$$props` are passed, since it cannot be known statically whether the delegated handler touches `$$props`.
- **Imports**: skipped entirely (module scope, no closure needed).
- **Dev mode**: the body is walked with a small local `visit` helper; any `AssignmentExpression` / `UpdateExpression` that `validate_mutation` rewrites (i.e. a prop mutation) injects the `$$ownership_validator` parameter so ownership validation works inside hoisted handlers.
- **Synthetic `_` parameter**: if the original function has *no* parameters but needs hoisted params, a `_` identifier (the delegated event object) is added first to keep parameter positions stable.

`visit_function` additionally tracks `in_constructor` (a `FunctionExpression` whose parent is a constructor `MethodDefinition`) and resets `in_derived`, so nested transformations (e.g. rune restrictions, ownership checks) have correct context.

---

## 7. Static Template Accumulation (`transform-template/template.js`)

The `Template` class is a *stack-based* accumulator: the `Fragment` and `RegularElement` visitors push/pop elements as they descend the markup tree, mirroring the source structure.

### 7.1 API and lifecycle

| Method | Effect |
|---|---|
| `push_element(name, start)` | Opens an element; child collections descend into it. |
| `push_comment(data)` / `push_text(nodes)` | Appends a comment / text node to the current fragment. |
| `pop_element()` | Closes the current element, restoring the parent fragment. |
| `set_prop(key, value)` | Records a *static* attribute on the currently open element. |
| `as_html()` | Serializes via `stringify` into a `b.template(...)` tagged-template literal. |
| `as_tree()` | Serializes via `objectify` into a `b.array(...)` literal for `$.from_tree`. |

Two boolean flags drive runtime behavior:

- **`contains_script_tag`** — the template is wrapped in `$.with_script(...)` so the instantiation function executes `<script>` content (see `create_fragment_with_script_from_html` in the runtime).
- **`needs_import_node`** — set for `<video>` and custom elements; the runtime must use `importNode` instead of `cloneNode` because cloning does not instantiate custom element classes and WebKit needs `importNode` for `<video>` autoplay.

### 7.2 From accumulation to runtime call

```mermaid
flowchart TB
    F["Fragment visitor"] --> N1["state.template = new Template()"]
    N1 --> E["RegularElement visitors during traversal"]
    E --> E1["push_element(name, start)"]
    E1 --> E2["set_prop for static attributes<br/>(e.g. is, scoped class hash)"]
    E2 --> E3["flags: needs_import_node,<br/>contains_script_tag"]
    E3 --> E4["process children (recursive)"]
    E4 --> E5["pop_element()"]
    E5 --> T["transform_template(state, namespace, flags)"]
    T --> Q{"options.fragments"}
    Q -- "html" --> H["as_html() → b.template(quasi HTML string)"]
    Q -- "tree" --> R["as_tree() → b.array literal"]
    H --> C1["$.from_html / $.from_svg / $.from_mathml"]
    R --> C2["$.from_tree + TEMPLATE_USE_SVG /<br/>TEMPLATE_USE_MATHML flags"]
    C1 --> W["$.with_script wrapper if script tag<br/>$.add_locations wrapper in dev mode"]
    C2 --> W
    W --> HOIST["b.var(root, …) pushed to state.hoisted<br/>instantiated per fragment with root()"]
```

**Serializer semantics**

- `stringify` produces XHTML-compliant output: void elements self-close (`<br/>`), attribute values are escaped with `escape_html(value, true)`, and empty comments render as `<!>` (the runtime's anchor-marker convention).
- `objectify` produces the compact tree encoding consumed by `$.from_tree`: text → string literal, comment → `[ "// …" ]` or `null`, element → `[name, attributes?, ...children]` with attribute keys normalized by `fix_attribute_casing`. A leading newline is stripped for `<pre>` / `<textarea>` children (HTML parsing quirk), and if the first node is a comment an extra empty comment is prepended so hydration's `effect.start` anchor lands correctly.

### 7.3 Consumers

- **`Fragment`** creates a fresh `Template` per fragment block and hoists `const root = $.from_html(...)` (or `from_tree`) to `state.hoisted`, then instantiates it inside the fragment body (see [structural-visitors](compiler-transformer_client-transform_structural-visitors.md)).
- **`RegularElement`** drives `push_element` / `set_prop` / `pop_element` for every static attribute and toggles the flags.
- **`transform_template`** (`transform-template/index.js`) selects the serialization mode and wraps the call with `$.with_script` / `$.add_locations` as required.

---

## 8. Integration Example

Input:

```svelte
<script>
  let count = $state(0);
</script>

<button onclick={() => count++}>{count}</button>
```

Conceptual client output (illustrative, not literal):

```js
// module scope — hoisted template (Template.as_html)
const root = $.from_html(`<button> </button>`);

// module scope — hoisted handler (visit_function + build_hoisted_params)
/* count is passed as an explicit param instead of a closure */
const onclick = ($_, count) => $.update_count(count);   // $.mutate-style update

// instance scope
export default function App($$anchor, $$props) {
  $.init();
  let count = $.state(0);            // is_state_source → signal source
  const button = root();             // template instantiation
  const [get_count, set_count] = ... // build_getter-based reads/writes
  $.event('click', button, onclick …);
  $.render_effect(() => $.set_text(text_node, $.get(count)));
  $.append($$anchor, button);
}
```

This shows the three infrastructure concerns working together: the `Template` produced the hoisted `root`, the hoisting machinery turned the closure into a parameterized function, and the read/write predicates produced the runtime calls.

---

## 9. Design Notes

- **Why hoisting?** Per-instance closures are the dominant allocation cost for small components. Hoisting moves handler creation to module scope; the price is that every free variable must become an explicit parameter — exactly what `build_hoisted_params` computes. The derived-signal extraction in `get_hoisted_params` is an acknowledged heuristic (`TODO: kill it` in source) that can be revisited without affecting the visitor contract.
- **Why `importNode`?** `cloneNode` does not run custom-element constructors until connection, breaking property assignment timing; WebKit additionally needs it for `<video>` autoplay. Hence the `needs_import_node` flag rather than a blanket policy.
- **Why thunks for prop defaults?** `get_prop_source` must not eagerly evaluate expensive default expressions; `PROPS_IS_LAZY_INITIAL` + `b.thunk` defers them until the prop is missing.
- **Legacy vs runes:** the infrastructure is the single place where the two modes diverge in code shape (`$.derived_safe_equal` vs `$.derived`, `is_prop_source` including `binding.updated` for legacy coarse-grained reactivity), keeping the visitors themselves mode-agnostic.
- **State immutability:** `is_state_source` and `should_proxy` prevent unnecessary proxies/signals for statically analyzable values, directly reducing runtime overhead in immutable analyses.

---

## 10. References

- Parent phase & orchestration: [compiler-transformer_client-transform](compiler-transformer_client-transform.md)
- Sibling consumer modules: [compiler-transformer_client-transform_structural-visitors](compiler-transformer_client-transform_structural-visitors.md) · [compiler-transformer_client-transform_expression-visitors](compiler-transformer_client-transform_expression-visitors.md) · [compiler-transformer_client-transform_directive-visitors](compiler-transformer_client-transform_directive-visitors.md)
- AST factory used everywhere: [compiler-core_ast_builders](compiler-core_ast_builders.md)
- Scope & binding inputs: [compiler-analyzer_scope](compiler-analyzer_scope.md)
- Runtime functions emitted by this module: [client-reactivity-engine](client-reactivity-engine.md) (signals, props, deriveds) · [client-dom-renderer](client-dom-renderer.md) (`$.from_html`, `$.from_tree`, template instantiation, hydration)
