# Compiler Transformer — Server Transform: Components & Snippets

> **Module path:** `packages/svelte/src/compiler/phases/3-transform/server/visitors/`
> **Parent module:** [compiler-transformer_server-transform](compiler-transformer_server-transform.md)
> **Submodule of:** [compiler-transformer](compiler-transformer.md)

## 1. Introduction

The `components-snippets` module implements the **server-side (SSR) code-generation visitors** for everything related to *component composition*:

| Concern | Source syntax | Visitor |
|---|---|---|
| Static child components | `<Card title="…" />` | `Component` |
| Dynamic components | `<svelte:component this={expr} />` | `SvelteComponent` |
| Snippet definitions | `{#snippet name(p)}…{/snippet}` | `SnippetBlock` |
| Snippet invocation | `{@render name(args)}` | `RenderTag` |
| Slot outlets | `<slot name="x">fallback</slot>` | `SlotElement` |

Unlike the client transform (which builds reactive DOM primitives), these visitors emit **plain function calls threaded with a `$$payload` parameter** — the render buffer that accumulates the HTML string during SSR. The module therefore defines the *calling convention* of every server-rendered component and snippet in compiled output:

```js
// Every component/snippet compiled for the server has the shape:
function Component($$payload, $$props) {
    // …push markup into $$payload.out …
}
```

Shared plumbing (prop collection, slot serialization, hydration markers) lives in [compiler-transformer_server-transform_shared-utils](compiler-transformer_server-transform_shared-utils.md) — this module *consumes* those helpers rather than duplicating them.

---

## 2. Position in the Compiler Pipeline

This module is one leaf of the server branch of **Phase 3: Transform**. Parsing and analysis happen upstream ([compiler-parser](compiler-parser.md), [compiler-analyzer](compiler-analyzer.md)); the analyzer has already resolved scopes, snippet hoistability (`metadata.can_hoist`), component dynamics (`metadata.dynamic`) and slot scopes (`node.metadata.scopes`), which these visitors rely on.

```mermaid
flowchart LR
    A["Phase 1 — Parse<br/>(compiler-parser)"] --> B["Phase 2 — Analyze<br/>(compiler-analyzer)"]
    B --> C{"Phase 3 — Transform<br/>(compiler-transformer)"}
    C -->|"generate = client"| D["client/ visitors<br/>(compiler-transformer_client-transform)"]
    C -->|"generate = server"| E["server/ visitors"]
    C -->|"css output"| F["css/ transform<br/>(compiler-transformer_css-transform)"]
    subgraph E["server/ visitors"]
        direction TB
        E1["template-rendering<br/>(elements, text, head)"]
        E2["control-flow<br/>(if, each, await, key)"]
        E3["<b>components-snippets<br/>(this module)</b>"]
        E4["script-transform<br/>(assignments, reactivity)"]
    end
    E3 --> G["Server Runtime<br/>(server-runtime: $.slot, $.spread_props, …)"]
```

**Cross-target symmetry:** nearly every visitor here has a twin in [compiler-transformer_client-transform_structural-visitors](compiler-transformer_client-transform_structural-visitors.md) (`Component`, `SvelteComponent`, `RenderTag`, `SlotElement`, `SnippetBlock`). The two branches share AST node types ([compiler-core_type_definitions](compiler-core_type_definitions.md)) but emit fundamentally different code — DOM construction vs. HTML payload calls.

---

## 3. Internal Architecture & Component Relationships

```mermaid
flowchart TB
    subgraph MOD["components-snippets visitors"]
        CV["Component<br/><code>visitors/Component.js</code>"]
        SCV["SvelteComponent<br/><code>visitors/SvelteComponent.js</code>"]
        SBV["SnippetBlock<br/><code>visitors/SnippetBlock.js</code>"]
        RTV["RenderTag<br/><code>visitors/RenderTag.js</code>"]
        SEV["SlotElement<br/><code>visitors/SlotElement.js</code>"]
    end

    subgraph SHARED["server/visitors/shared (compiler-transformer_server-transform_shared-utils)"]
        BIC["build_inline_component()"]
        SU["empty_comment<br/>build_attribute_value"]
    end

    subgraph CORE["compiler-core"]
        B["builders (<code>b.*</code>)<br/>(compiler-core_ast_builders)"]
        DEV["dev flag<br/>(compiler-core_compile_state)"]
        UO["unwrap_optional()"]
    end

    subgraph TS["types (compiler-transformer_shared-infrastructure)"]
        CTX["ComponentContext /<br/>ComponentServerTransformState"]
    end

    CV -->|delegates| BIC
    SCV -->|delegates| BIC
    CV & SCV & SEV --> B
    CV & SCV & SEV & RTV --> SU
    RTV --> UO
    SBV --> B & DEV
    CV & SCV & SBV & RTV & SEV -->|state + visit| CTX
    BIC -->|"visits SnippetBlock children"| SBV
    BIC --> B
```

### Collaboration model

* **`Component` and `SvelteComponent` are thin shims.** Both delegate to the shared `build_inline_component()` helper in [compiler-transformer_server-transform_shared-utils](compiler-transformer_server-transform_shared-utils.md):
  * `Component` passes a static reference — `b.id(node.name)`.
  * `SvelteComponent` visits `node.expression` first, producing a dynamic callee. Because `this` may be nullish, `build_inline_component` emits an **optional call** (`expr?.($$payload, props)`) for `SvelteComponent` nodes, versus a plain call for `Component`.
* **`SnippetBlock` is both a definition site and a prop source.** When a snippet block is a *direct child of a component*, `build_inline_component` visits it (via this module's `SnippetBlock` visitor) with a redirected `init` array, then turns the resulting function into a prop (`{ footer }` shorthand) and registers it in `$$slots`.
* **`RenderTag` is the call site** of snippets defined by `SnippetBlock` (or received as props): it rewrites `{@render foo(a, b)}` to `foo($$payload, a, b)`.
* **`SlotElement` is the consumer side** of slot props: it reads `$$props` (already scoped by the analyzer) and calls the runtime `$.slot($$payload, $$props, name, props, fallback)`.

---

## 4. Visitor Deep Dives

### 4.1 `Component` — static components

```js
export function Component(node, context) {
    build_inline_component(node, b.id(node.name), context);
}
```

| Input | Output (pushed to `state.template`) |
|---|---|
| `<Card title="Hi">…</Card>` | `Card($$payload, { title: 'Hi', … });` followed by a hydration-boundary comment |

`build_inline_component` (see [compiler-transformer_server-transform_shared-utils](compiler-transformer_server-transform_shared-utils.md)) performs the heavy lifting: it

1. collects attributes into props (`props_and_spreads`), handling spreads via `$.spread_props`;
2. maps `bind:` directives to getter/setter accessor props (delayed so spreads cannot overwrite them);
3. routes `--custom-property` attributes through a `$.css_props(...)` wrapper with a thunk of the component call;
4. groups child nodes by slot name (default children are evaluated in the **component scope**, named slots in the **parent scope** — scopes come from analyzer metadata);
5. serializes slots to `$$slots: { name: fn | true }`, including the legacy `children`-prop interop path.

**Dynamic flag:** for `Component` nodes with `metadata.dynamic === true` (e.g. dynamic tag content), an `empty_comment` anchor is emitted before the call, and the call participates in hydration-boundary handling — see [§6](#6-hydration-boundaries-and-template-emission).

### 4.2 `SvelteComponent` — dynamic components

```js
export function SvelteComponent(node, context) {
    build_inline_component(node, context.visit(node.expression), context);
}
```

Identical pipeline to `Component`, but the callee is the **visited expression** from `<svelte:component this={expr}>`. `build_inline_component` distinguishes the node type and uses `b.maybe_call`, producing:

```js
expr?.($$payload, { /* props */ });
```

so a nullish `this` is a safe no-op at runtime.

### 4.3 `SnippetBlock` — snippet definitions

Rewrites `{#snippet name(p1, p2)}…{/snippet}` into a hoistable function declaration:

```js
function name($$payload, p1, p2) { /* visited body */ }
```

Key behaviors:

* **Placement** — the declaration lands in `state.hoisted` if `node.metadata.can_hoist` (set by the analyzer, i.e. the snippet body references no component-scope bindings), otherwise in `state.init` of the enclosing block/component.
* **Legacy hook** — `fn.___snippet = true` is stamped onto the AST node; the script transform uses this marker while `$$render_inner` legacy binding support still exists (marked in-source as a temporary hack).
* **Dev-mode guards** (when the `dev` compiler flag from [compiler-core_compile_state](compiler-core_compile_state.md) is on):
  * `$.validate_snippet_args($$payload)` is prepended to the body — catches snippets invoked incorrectly (validated by [server-runtime_dev-diagnostics](server-runtime_dev-diagnostics.md) at runtime);
  * `$.prevent_snippet_stringification(name)` is pushed after the declaration, so accidentally stringifying a snippet yields a helpful error instead of source text.

> Snippet **invocation** is handled by `RenderTag`; snippet-as-prop wiring happens inside `build_inline_component` (§4.1). Snippet *parameters* resolution relies on scope chains from [compiler-analyzer_scope](compiler-analyzer_scope.md).

### 4.4 `RenderTag` — snippet invocation

Rewrites `{@render foo(args)}` (including optional-chained `{@render foo?.(args)}`):

```js
foo?.($$payload, args…);
```

Processing steps:

1. `unwrap_optional()` (from [compiler-core](compiler-core.md) AST utils) normalizes optional calls so callee/arguments can be visited uniformly;
2. callee and each argument are visited through `context.visit` (triggering script-transform rewrites such as reactive identifier reads — see [compiler-transformer_server-transform_script-transform](compiler-transformer_server-transform_script-transform.md));
3. a `b.call` (or `b.maybe_call` for `?.`) statement with `$$payload` spliced in as the **first argument** is pushed onto the template;
4. an `empty_comment` hydration anchor is appended unless `state.skip_hydration_boundaries` is set (e.g. inside `<head>` or attribute contexts where comments are illegal).

### 4.5 `SlotElement` — slot outlets

Rewrites `<slot name="x" {…props}>fallback</slot>`:

```js
$.slot($$payload, $$props, 'x', { /* slot props */ }, () => { /* fallback */ });
// wrapped: <!--→ … ←-->
```

Processing steps:

1. **Attributes** → slot configuration:
   * `name="…"` sets the slot name literal (default `'default'`);
   * `slot="…"` is explicitly *ignored* (meaningless on an outlet);
   * `SpreadAttribute`s are visited and collected separately;
   * every other attribute becomes a slot prop via `build_attribute_value(..., is_component = true)` — values are **not** HTML-escaped here (they cross a component boundary as JS values, not markup).
2. **Props expression** — plain `b.object(props)` when there are no spreads, otherwise `$.spread_props([{ …props }, spread1, …])`.
3. **Fallback** — the fragment body is wrapped in `b.thunk(...)` (a lazy `() => …` arrow) so the fallback is *only rendered if the parent did not provide the slot*; an empty fragment becomes `b.null`.
4. **Emission** — `empty_comment` + `$.slot(...)` + `empty_comment` are pushed to the template, giving hydration an anchor pair around the slot region.

The runtime counterpart of `$.slot` (fallback evaluation, `$$slots` lookup, `$$props` scoping) is documented in [server-runtime_slots-snippets-and-blocks](server-runtime_slots-snippets-and-blocks.md).

---

## 5. End-to-End Transformation Flow

The following sequence shows how the visitors cooperate when compiling a component that composes a child with snippets, slots, and a render tag:

```mermaid
sequenceDiagram
    participant Z as zimmerframe walk<br/>(context.visit)
    participant CV as Component visitor
    participant BIC as build_inline_component
    participant SB as SnippetBlock visitor
    participant RT as RenderTag visitor
    participant SE as SlotElement visitor
    participant T as state.template

    Note over Z: <Card title="Hi"><p>body</p><br/>{#snippet footer()}…{/snippet}</Card>
    Z->>CV: AST.Component
    CV->>BIC: build_inline_component(node, id(Card))
    BIC->>BIC: collect props (title="Hi"),<br/>detect snippet child + default children
    BIC->>Z: visit SnippetBlock (init → snippet_declarations)
    Z->>SB: AST.SnippetBlock
    SB->>SB: fn = function footer($$payload,…){}
    SB-->>BIC: declaration recorded<br/>(hoisted or init)
    BIC->>BIC: prop { footer }, $$slots.footer = true,<br/>children → $$slots.default / children prop
    BIC->>T: block[ footer decl + Card($$payload, props) ]
    BIC->>T: empty_comment (hydration anchor)
    Note over Z,SE: …inside Card's own template…
    Z->>SE: AST.SlotElement (fallback)
    SE->>T: $.slot($$payload, $$props, 'default', {}, thunk(fallback))
    Z->>RT: AST.RenderTag {@render footer()}
    RT->>T: footer($$payload, …) + empty_comment
```

The produced payload statements execute at runtime against [server-runtime_render-pipeline](server-runtime_render-pipeline.md), which owns the `$$payload` object (`payload.out` string buffer, head chunks, CSS, `props_id` generation).

---

## 6. Hydration Boundaries and Template Emission

All five visitors write into `ComponentServerTransformState.template` (typed in `phases/3-transform/types.d.ts`, part of [compiler-transformer_shared-infrastructure](compiler-transformer_shared-infrastructure.md)). Two conventions matter for maintainers:

1. **`empty_comment` anchors** — an HTML comment literal (`<!---->`, value of `EMPTY_COMMENT` from `internal/server/hydration.js`) is emitted around components, render tags, and slots. During client hydration these comments delimit regions that may have moved or been removed (mismatch recovery). Emission is suppressed when `state.skip_hydration_boundaries` is `true` (contexts where comments would leak into the output, e.g. `<head>`-internal or attribute positions).
2. **Statement ordering is output ordering** — there is no intermediate template AST; whatever order visitors push statements is the execution order of the SSR program. `hoisted` vs `init` placement (snippets, legacy `$:`) is the only reordering mechanism, resolved later by the server transform entry point.

```mermaid
flowchart LR
    subgraph STATE["ComponentServerTransformState (per component scope)"]
        TPL["template[]<br/>SSR statement stream"]
        INIT["init[]<br/>top-of-function statements"]
        H["hoisted[]<br/>module/function-level decls"]
        FLAG["skip_hydration_boundaries"]
    end
    V["visitors (this module)"] -->|"b.stmt( call ) "| TPL
    V -->|"SnippetBlock decl"| INIT
    V -->|"can_hoist snippets"| H
    V -->|"reads"| FLAG
    TPL --> OUT["component function body:<br/>function C($$payload, $$props){…}"]
    INIT --> OUT
    H --> OUT
```

---

## 7. Source → Output Cheat Sheet

| Source (`.svelte`) | Server output (simplified) | Visitor |
|---|---|---|
| `<Card title={t}>{body}</Card>` | `Card($$payload, { title: t, children: body, $$slots: { default: true } })` | `Component` + `build_inline_component` |
| `<svelte:component this={C} />` | `C?.($$payload, {})` | `SvelteComponent` |
| `{#snippet row(item)}<td/>{/snippet}` | `function row($$payload, item) { … }` (hoisted if possible) | `SnippetBlock` |
| `{@render row(x)}` | `row($$payload, x)` | `RenderTag` |
| `<slot {p}>fallback</slot>` | `$.slot($$payload, $$props, 'default', { p }, () => { fallback })` | `SlotElement` |
| `<Card --color="red" />` | `$.css_props($$payload, true, { '--color': 'red' }, () => Card(…))` | `Component` (via `build_inline_component`) |
| `bind:` on component prop | `{ get p() {…}, set p($$value) {…; $$settled = false } }` appended after spreads | `Component` (via `build_inline_component`) |

---

## 8. Dependencies

### Internal (compile-time)

| Dependency | Used by | Purpose |
|---|---|---|
| `build_inline_component` — [compiler-transformer_server-transform_shared-utils](compiler-transformer_server-transform_shared-utils.md) | `Component`, `SvelteComponent` | Full inline-component serialization |
| `empty_comment`, `build_attribute_value` — same shared-utils module | `RenderTag`, `SlotElement`, (shared/component) | Hydration markers; attribute value → expression |
| `b.*` AST builders — [compiler-core_ast_builders](compiler-core_ast_builders.md) | all visitors | estree node construction (`b.call`, `b.thunk`, `b.function_declaration`, …) |
| `unwrap_optional` — [compiler-core](compiler-core.md) AST utils | `RenderTag` | Normalize optional-call render tags |
| `dev` flag — [compiler-core_compile_state](compiler-core_compile_state.md) | `SnippetBlock` | Dev-only argument/stringification guards |
| Analyzer metadata (`can_hoist`, `dynamic`, `scopes`) — [compiler-analyzer](compiler-analyzer.md), [compiler-analyzer_scope](compiler-analyzer_scope.md) | all visitors | Placement and scoping decisions |
| `ComponentContext` / `ComponentServerTransformState` — [compiler-transformer_shared-infrastructure](compiler-transformer_shared-infrastructure.md) | all visitors | Visitor context contract |

### Runtime (generated code)

| Generated call | Consumer module |
|---|---|
| `$.slot`, `$.spread_props`, `$.css_props`, `$.stringify` | [server-runtime](server-runtime.md) |
| `$.validate_snippet_args`, `$.prevent_snippet_stringification` | [server-runtime_dev-diagnostics](server-runtime_dev-diagnostics.md) / snippet blocks |
| `$.invalid_default_snippet` | [internal-shared-utils_error-messages](internal-shared-utils_error-messages.md) |
| `EMPTY_COMMENT` hydration constant | [server-runtime_payload-and-output](server-runtime_payload-and-output.md) |

---

## 9. Maintenance Notes

* **Adding a component-level attribute behavior?** Implement it in `build_inline_component` (shared-utils), not in `Component`/`SvelteComponent` — both must stay in lockstep with the client-side `Component` visitor in [compiler-transformer_client-transform_structural-visitors](compiler-transformer_client-transform_structural-visitors.md).
* **`fn.___snippet = true`** is a temporary marker; remove it together with legacy `$$render_inner` binding support (tracked in `SnippetBlock.js` source comment).
* **Keep `$$payload` as argument #1** of every emitted component/snippet call — the entire server runtime and hydration protocol assume this convention.
* **Snippet hoisting** interacts with `RenderTag`: a snippet referenced before its declaration only works because `can_hoist` lifts it; if you change hoisting rules, update the analyzer visitor that computes `metadata.can_hoist`, not this module.
* **Tests:** transformations in this module are covered by the SSR render snapshot suites that exercise [server-runtime_slots-snippets-and-blocks](server-runtime_slots-snippets-and-blocks.md); message codes raised at parse/analyze time (not here) live in the diagnostics modules — see [compiler-core_diagnostics](compiler-core_diagnostics.md).

## 10. See Also

* [compiler-transformer_server-transform](compiler-transformer_server-transform.md) — parent module: server transform entry point and visitor registry
* [compiler-transformer_server-transform_template-rendering](compiler-transformer_server-transform_template-rendering.md) — elements, text, `<head>`, `<svelte:boundary>` siblings
* [compiler-transformer_server-transform_control-flow](compiler-transformer_server-transform_control-flow.md) — `if`/`each`/`await`/`key` visitors sharing the same template-push conventions
* [compiler-transformer_server-transform_script-transform](compiler-transformer_server-transform_script-transform.md) — expression-level rewrites invoked via `context.visit` from this module
* [compiler-transformer_client-transform](compiler-transformer_client-transform.md) — client-side counterpart emitting DOM primitives instead of payload calls
* [server-runtime](server-runtime.md) — runtime implementation of `$.slot`, `$.spread_props`, payload management
