# Server Transform — Control Flow (`compiler-transformer_server-transform_control-flow`)

## 1. Overview

This module implements the **server-side (SSR) lowering of Svelte's template control-flow blocks**. It is part of the *server transform* branch of Phase 3 (Transform) of the Svelte 5 compiler and turns the four declarative control-flow constructs of the template language into imperative JavaScript that appends HTML — interleaved with *hydration markers* — to the server render payload (`$$payload.out`):

| Svelte syntax | Visitor | Lowered to |
|---|---|---|
| `{#if}…{:else if}…{:else}…{/if}` | `IfBlock` | A plain `if / else` JavaScript statement + boundary markers |
| `{#each}…{:else}…{/each}` | `EachBlock` | A classic indexed `for` loop (+ `{:else}` length check) + boundary markers |
| `{#await}…{:then v}…{:catch e}…{/await}` | `AwaitBlock` | A single call to the runtime helper `$.await($$payload, …)` |
| `{#key}…{/key}` | `KeyBlock` | The rendered fragment wrapped in empty-comment anchors |

The module is intentionally tiny: each visitor is a pure function `(node, context) => void` that **mutates the shared transform state** (`context.state.template` / `context.state.init`) and **delegates all child traversal back to the walker** via `context.visit`. All validation, scope analysis and reactivity metadata were already produced in Phase 2 (see [compiler-analyzer](compiler-analyzer.md)); this module only *emits code*.

### Files and exports

| File (under `packages/svelte/src/compiler/phases/3-transform/server/visitors/`) | Export | Responsibility |
|---|---|---|
| `IfBlock.js` | `IfBlock` | Lower `{#if}` chains; inject `BLOCK_OPEN` / `BLOCK_OPEN_ELSE` markers into branches |
| `EachBlock.js` | `EachBlock` | Lower `{#each}`; hoist `$.ensure_array_like`; build indexed `for` loop; handle `{:else}` fallback |
| `AwaitBlock.js` | `AwaitBlock` | Lower `{#await}` to `$.await(...)` with pending thunk + then arrow |
| `KeyBlock.js` | `KeyBlock` | Wrap `{#key}` fragment with `<!---->` anchor comments (no runtime logic on the server) |

---

## 2. Position in the Compiler Pipeline

The Svelte compiler runs in three phases: **parse → analyze → transform**. Within the transform phase, three independent targets are produced (client JS, server JS, CSS). This module lives in the *server* target and is registered in the `template_visitors` map of `transform-server.js`, which the `zimmerframe` walker consults while rewriting the component AST.

```mermaid
flowchart LR
    SRC[".svelte source"] --> P1

    subgraph P1["Phase 1 — Parse (see compiler-parser)"]
        AST["Template + JS AST"]
    end

    P1 --> P2
    subgraph P2["Phase 2 — Analyze (see compiler-analyzer)"]
        AN["Scopes, bindings,<br/>block metadata<br/>(e.g. EachBlock metadata)"]
    end

    P2 --> P3
    subgraph P3["Phase 3 — Transform (see compiler-transformer)"]
        direction LR
        CTX["client/ transform"]
        STX["server/ transform<br/>(this module lives here)"]
        CSSX["css/ transform"]
    end

    STX --> SSRJ["SSR component JS<br/>(CompileResult.server)"]
    CTX --> CLIJ["Interactive client JS"]
    CSSX --> CSSO["Scoped CSS"]
```

The sibling *client* counterpart for the same four blocks is documented in [compiler-transformer_client-transform_structural-visitors](compiler-transformer_client-transform_structural-visitors.md); it produces the reactive DOM block functions (`if_block`, `each`, `await_block`, `key`) that consume the hydration markers emitted here.

---

## 3. Architecture

### 3.1 Visitor contract

Every visitor in this module shares the same shape:

```js
/**
 * @param {AST.IfBlock} node      // strongly-typed AST node from Phase 1/2
 * @param {ComponentContext} context  // zimmerframe context: walker + shared state
 */
export function IfBlock(node, context) { /* mutate context.state, call context.visit(...) */ }
```

- **Dispatch** — `server_component()` in `transform-server.js` walks the component AST; whenever the walker meets an `AST.IfBlock`, `AST.EachBlock`, `AST.AwaitBlock` or `AST.KeyBlock` node, the corresponding visitor is invoked.
- **Child traversal** — Visitors never recurse manually. They call `context.visit(childNode)`, which dispatches to the right visitor for the child (a nested `IfBlock`, a `RegularElement`, an `ExpressionTag`, …) and returns the finished ESTree node. In particular, **each block body/branch is an `AST.Fragment`**, so visiting it returns a complete `BlockStatement` containing all `init` and rendered-template statements of that branch.
- **Output** — Visitors push entries into two arrays of the shared `ComponentServerTransformState`:
  - `state.template: (Statement | Expression)[]` — the ordered render output of the current fragment;
  - `state.init: Statement[]` — statements hoisted *before* the render output (e.g. the `each_array` const).

### 3.2 Output assembly

The `Fragment` visitor (see [compiler-transformer_server-transform_template-rendering](compiler-transformer_server-transform_template-rendering.md)) owns fresh `init` / `template` buffers per fragment and finally compiles them with `build_template()` from [compiler-transformer_server-transform_shared-utils](compiler-transformer_server-transform_shared-utils.md):

- adjacent string literals and expressions are merged into `$$payload.out.push(\`…${expr}…\`)` calls;
- **statements flush the string buffer** and are emitted verbatim — which is exactly how the `if` statements / `for` loops emitted by this module are embedded into the surrounding `$$payload.out.push` stream.

### 3.3 Architecture diagram

```mermaid
flowchart TB
    subgraph ENTRY["transform-server.js — server_component(analysis, options)"]
        HOIST["state.hoisted += import * as $ from 'svelte/internal/server'"]
        W["zimmerframe walk(component AST, state, template_visitors)"]
    end

    W -->|"AST.IfBlock"| IF["IfBlock.js::IfBlock"]
    W -->|"AST.EachBlock"| EA["EachBlock.js::EachBlock"]
    W -->|"AST.AwaitBlock"| AW["AwaitBlock.js::AwaitBlock"]
    W -->|"AST.KeyBlock"| KB["KeyBlock.js::KeyBlock"]
    W -->|"every other node"| SIB["sibling visitors<br/>(Fragment, RegularElement, RenderTag, …)"]

    IF -->|"if-statement + block_close literal"| T["state.template<br/>(Statement | Expression)[]"]
    EA -->|"block_open, for-loop, block_close"| T
    AW -->|"$.await(…) call + block_close literal"| T
    KB -->|"empty_comment, fragment, empty_comment"| T
    SIB --> T
    EA -->|"const each_array = $.ensure_array_like(…)"| I["state.init<br/>Statement[]"]
    SIB --> I

    T --> BT["build_template()<br/>(shared/utils.js)"]
    I --> OUT["render body:<br/>init statements + $$payload.out.push(`…`) calls"]
    BT --> OUT

    OUT --> GEN["server component JS"]
    GEN -.->|"runtime calls emitted as code"| RT["svelte/internal/server<br/>$.await · $.ensure_array_like · $$payload.out"]
```

---

## 4. Hydration Marker Contract

The compile-time output of this module is not plain HTML: every conditional/loop boundary is wrapped in HTML comments so the client runtime can locate, match and (re)create the corresponding DOM blocks during hydration. The marker literals are defined once in `internal/server/hydration.js` (values derive from `HYDRATION_START = '['`, `HYDRATION_START_ELSE = '[!'`, `HYDRATION_END = ']'` in `src/constants.js`) and re-exported as ESTree literals by `shared/utils.js`:

| Marker | Value | Emitted by (compile time) | Emitted by (runtime) |
|---|---|---|---|
| `BLOCK_OPEN` (`block_open`) | `<!--[-->` | `IfBlock` (consequent), `EachBlock` (loop) | `$.await` before the pending branch |
| `BLOCK_OPEN_ELSE` | `<!--[!-->` | `IfBlock` (alternate), `EachBlock` (fallback) | `$.await` before the then branch |
| `BLOCK_CLOSE` (`block_close`) | `<!--[/]-->` | all four visitors (as a sibling of the emitted statement) | — |
| `EMPTY_COMMENT` (`empty_comment`) | `<!---->` | `KeyBlock` (also `Fragment` for text-first fragments) | — |

> **Contract invariant:** the client-side visitors and DOM block runtimes (`internal/client/dom/blocks/if.js`, `each.js`, `await.js`, `key.js`) consume exactly these markers. Changing any of them is a cross-module, cross-target change.

The markers shape the rendered HTML as follows:

```mermaid
flowchart LR
    A["&lt;!--[----&gt;"] --> B["consequent markup"]
    B --> C["&lt;!--[/]--&gt;"]
    A -->|"if test is false"| D["&lt;!--[!--&gt;"]
    D --> E["alternate markup"]
    E --> C
    H["client hydration<br/>(marker matching)"] -.-> A
```

---

## 5. Component Reference

### 5.1 `IfBlock`

**Input AST:** `AST.IfBlock { test, consequent, alternate? }`

**Algorithm:**

1. `context.visit(node.test)` → the condition `Expression`.
2. `context.visit(node.consequent)` → a `BlockStatement` (the fully rendered consequent fragment). If `node.alternate` exists it is visited the same way; otherwise an empty block is used.
3. **Unshift** `$$payload.out.push('<!--[-->')` at the top of the consequent body and `$$payload.out.push('<!--[!-->')` at the top of the alternate body (`BLOCK_OPEN_ELSE` is imported directly from `internal/server/hydration.js`).
4. Push `if (test) {…} else {…}` **followed by the `block_close` literal** onto `state.template`.

**Generated shape (illustrative):**

```svelte
{#if user.admin}
  <p>{name} — admin</p>
{:else}
  <p>{name}</p>
{/if}
```

```js
if (user.admin) {
  $$payload.out.push('<!--[--><p>');
  $$payload.out.push(`${$.escape(name)} — admin</p>`);
} else {
  $$payload.out.push('<!--[!--><p>');
  $$payload.out.push(`${$.escape(name)}</p>`);
}
$$payload.out.push('<!--[/]-->');
```

Notes: the condition is evaluated **once per render**; both branches exist in the output but only one executes. `{:else if}` chains are nested `IfBlock` nodes in the AST, so they fall out of recursion for free.

### 5.2 `EachBlock`

**Input AST:** `AST.EachBlock { expression, context?, index?, body, fallback? }` plus `node.metadata` produced by [compiler-analyzer](compiler-analyzer.md) (`contains_group_binding`, synthetic `index` identifier).

**Algorithm:**

1. Visit `node.expression` → the collection `Expression`.
2. **Pick the loop variable**: use the analyzer's synthetic index (`each_node_meta.index`) when the body contains `each`-group bindings or the user declared no index; otherwise use `b.id(node.index)` directly so the user's named index *is* the loop counter.
3. Hoist `const each_array = $.ensure_array_like(collection)` into `state.init` (emitted before the render output of the fragment, but still lexically before the loop).
4. Build a classic `for` loop:
   - init: `let <index> = 0, $$length = each_array.length`
   - test: `<index> < $$length`
   - update: `<index>++`
   - body: `let <item> = each_array[<index>]` (computed member), an optional alias `let <user index> = <index>` when the synthetic index was used but the user still declared one, then the visited body statements.
5. Emit with hydration boundaries:
   - **without `{:else}`:** push `block_open`, the `for` loop, `block_close`;
   - **with `{:else}`:** push `if (each_array.length !== 0) { open-marker + loop } else { fallback (visited, prefixed with `BLOCK_OPEN_ELSE`) }`, `block_close`.

**Generated shape (illustrative, with fallback):**

```js
const each_array = $.ensure_array_like(items);
if (each_array.length !== 0) {
  $$payload.out.push('<!--[-->');
  for (let i = 0, $$length = each_array.length; i < $$length; i++) {
    let item = each_array[i];
    $$payload.out.push(`<li>${$.escape(item.label)}</li>`);
  }
} else {
  $$payload.out.push('<!--[!--><li>none</li>');
}
$$payload.out.push('<!--[/]-->');
```

`$.ensure_array_like` (runtime, see [server-runtime_render-pipeline](server-runtime_render-pipeline.md)) passes array-likes through, converts iterables with `Array.from`, and maps falsy input to `[]` — this is what allows the indexed `for` loop to iterate any iterable safely.

```mermaid
flowchart TD
    S["EachBlock node"] --> V["visit(node.expression) → collection"]
    V --> META{"metadata.contains_group_binding<br/>or no explicit index?"}
    META -->|"yes"| SYN["loop var = metadata.index<br/>(synthetic, collision-safe)"]
    META -->|"no"| USR["loop var = id(node.index)"]
    SYN --> ARR["init.push(const each_array =<br/>$.ensure_array_like(collection))"]
    USR --> ARR
    ARR --> LOOP["build for-loop:<br/>let i = 0, length = each_array.length; i &lt; length; i++"]
    LOOP --> CTX["let item = each_array[i]"]
    CTX --> ALIAS{"user index declared<br/>and differs from loop var?"}
    ALIAS -->|"yes"| AL["let user_index = i"]
    AL --> BODY["visit(node.body) statements"]
    ALIAS -->|"no"| BODY
    BODY --> FB{"node.fallback ({:else})?"}
    FB -->|"yes"| WRAP["emit if (length !== 0)<br/>{open + loop} else {fallback + else-marker}"]
    FB -->|"no"| PLAIN["emit block_open, loop, block_close"]
    WRAP --> DONE["template.push(…, block_close)"]
    PLAIN --> DONE
```

### 5.3 `AwaitBlock`

**Input AST:** `AST.AwaitBlock { expression, pending?, then?, catch?, value?, error? }`

**Algorithm:** unlike `IfBlock`/`EachBlock`, no statement is generated. Instead a **single runtime call** is pushed, followed by `block_close`:

```js
$.await(
  $$payload,
  <visited node.expression>,                       // the awaited value
  () => { …pending branch or empty… },             // b.thunk — lazy pending render
  (<visited node.value?>) => { …then branch… }     // b.arrow — then render, receives value
);
$$payload.out.push('<!--[/]-->');
```

Missing `{:pending}` / `{:then}` branches compile to empty blocks. **The `{:catch}` branch is deliberately not visited**: on the server, a promise is never awaited to completion with error handling — the runtime `$.await` checks `is_promise(expression)`; a promise renders the pending branch (rejections are swallowed with `promise.then(null, noop)`), a non-promise value renders the then branch (the runtime itself pushes `BLOCK_OPEN_ELSE` first). Rendering the rejection path is a client-only capability of the reactive `await_block` DOM runtime (see [compiler-transformer_client-transform_structural-visitors](compiler-transformer_client-transform_structural-visitors.md)). Note also that the *content* of both thunks is eagerly evaluated into the compiled closures, but only the selected closure is invoked at runtime.

### 5.4 `KeyBlock`

**Input AST:** `AST.KeyBlock { expression, fragment }`

**Algorithm:** push `empty_comment`, `context.visit(node.fragment)`, `empty_comment`. The empty comments (`<!---->`) keep the fragment's output from gluing onto neighbouring text and provide stable anchors for hydration. No runtime call is emitted — keyed re-creation is purely a client-side behaviour; on the server the keyed fragment is simply rendered once, exactly like a plain fragment.

---

## 6. Process & Data Flow

### 6.1 Compile-time sequence (nested control flow)

```mermaid
sequenceDiagram
    autonumber
    participant W as zimmerframe walker
    participant IF as IfBlock visitor
    participant EA as EachBlock visitor
    participant ST as ComponentServerTransformState
    participant BT as build_template / Fragment

    W->>IF: dispatch IfBlock node
    IF->>W: visit(node.test), visit(node.consequent), visit(node.alternate)
    W->>EA: dispatch nested EachBlock node
    EA->>ST: init.push(const each_array = $.ensure_array_like(…))
    EA->>W: visit(node.body)
    EA-->>ST: template.push(block_open, for-loop, block_close)
    IF-->>ST: template.push(if-statement, block_close)
    ST->>BT: finalize fragment buffers
    BT-->>ST: init stmts + merged $$payload.out.push(`…`) calls
```

Steps 4–7 show the key recursion pattern: the outer visitor receives the *finished* inner block (as part of a branch `BlockStatement`) and only adds its own markers/statement around it.

### 6.2 Data flow summary

```mermaid
flowchart LR
    A["AST.IfBlock / EachBlock /<br/>AwaitBlock / KeyBlock<br/>(+ analyzer metadata & scopes)"]
    --> V["visitor mutates state"]
    V --> T1["state.init<br/>hoisted statements"]
    V --> T2["state.template<br/>markers + statements"]
    T1 --> BT["build_template()"]
    T2 --> BT
    BT --> G["ESTree render body"]
    G --> C["esm-env code generation<br/>(CompileResult.server)"]
    C --> R["runtime:<br/>$$payload.out / $.await /<br/>$.ensure_array_like"]
```

---

## 7. Dependencies

### Compile-time

| Dependency | Source module | Used for |
|---|---|---|
| `b.*` builders (`b.if`, `b.for`, `b.const`, `b.let`, `b.block`, `b.thunk`, `b.arrow`, `b.member`, `b.literal`, `b.call`, `b.stmt`, `b.binary`, `b.update`, `b.declaration`, `b.declarator`) | [compiler-core_ast_builders](compiler-core_ast_builders.md) | Constructing the emitted ESTree nodes |
| `block_open`, `block_close`, `empty_comment` literals | [compiler-transformer_server-transform_shared-utils](compiler-transformer_server-transform_shared-utils.md) | Hydration marker literals shared across all server visitors |
| `BLOCK_OPEN_ELSE` | `internal/server/hydration.js` (imported directly by `IfBlock.js` / `EachBlock.js`) | Cross-target contract constant shared with the client runtime |
| `ComponentContext`, `ComponentServerTransformState` | [compiler-transformer_shared-infrastructure](compiler-transformer_shared-infrastructure.md) | Walker context and shared mutable state (`template`, `init`, `scope`, …) |
| EachBlock `node.metadata` (`contains_group_binding`, synthetic `index`), `state.scope.root.unique()` | [compiler-analyzer](compiler-analyzer.md) | Collision-safe loop/index identifiers; group-binding detection |

### Runtime (calls *emitted* into the output, not imported at compile time)

| Emitted call | Runtime implementation | Purpose |
|---|---|---|
| `$$payload.out.push(…)` | `Payload.out` | Append HTML / markers to the render stream |
| `$.await($$payload, v, pending, then)` | `await_block` in `internal/server/index.js` | Branch between promise (pending) and value (then) |
| `$.ensure_array_like(x)` | `internal/server/index.js` | Normalize iterables → indexable arrays |

All runtime helpers arrive via the hoisted `import * as $ from 'svelte/internal/server'` created by `server_component()`.

---

## 8. Related Modules

- [compiler-transformer_server-transform_template-rendering](compiler-transformer_server-transform_template-rendering.md) — owns the `template`/`init` buffers, `Fragment` and `process_children`; the fragments these visitors recurse into are rendered there.
- [compiler-transformer_server-transform_shared-utils](compiler-transformer_server-transform_shared-utils.md) — `block_open`/`block_close`/`empty_comment`, `build_template()`, `build_attribute_value()`.
- [compiler-transformer_server-transform_components-snippets](compiler-transformer_server-transform_components-snippets.md) — `SnippetBlock`/`RenderTag`/`SlotElement`; snippets can *contain* these control-flow blocks and vice versa.
- [compiler-transformer_client-transform_structural-visitors](compiler-transformer_client-transform_structural-visitors.md) — client counterparts that must stay marker-compatible with this module.
- [server-runtime_render-pipeline](server-runtime_render-pipeline.md) — the `$.await`, `$.ensure_array_like` and payload implementations invoked by generated code.
- [compiler-analyzer](compiler-analyzer.md) — produces the block metadata and scopes this module relies on; also where control-flow validation errors/warnings originate (this module emits no diagnostics of its own).
- [compiler-core_ast_builders](compiler-core_ast_builders.md) — the ESTree factory functions used throughout.

---

## 9. Design Notes & Invariants

1. **Statements force a flush.** `build_template()` emits buffered strings before any statement. Because `IfBlock`/`EachBlock` push *statements* and the markers are string literals pushed as siblings, the output always interleaves as `push('markers/HTML…') → if/for → push('<!--[/]-->')`.
2. **Branches are whole fragments.** Visiting `node.consequent` / `node.body` / `node.pending` / `node.fragment` returns a `BlockStatement` that already contains nested visitors' `init` + rendered output — the outer visitor only wraps it. Never mutate these returned blocks other than the documented marker `unshift`s.
3. **`state.init` vs `state.template`.** Anything that must execute before output (e.g. `const each_array = …`) goes to `init`; everything that writes HTML goes to `template`. The `Fragment` visitor emits `init` first.
4. **Marker symmetry.** Every `BLOCK_OPEN`/`BLOCK_OPEN_ELSE` opened at compile time (or by `$.await` at runtime) is balanced by exactly one `BLOCK_CLOSE`; `KeyBlock` balances its two `EMPTY_COMMENT`s. Hydration parsing depends on this balance.
5. **`{:catch}` is compile-time accepted, server-ignored.** The analyzer validates `{:catch}` content, but the SSR output never renders it; do not "fix" `AwaitBlock` to visit `node.catch` without changing the runtime `await_block` contract.
6. **Naming safety.** All generated identifiers (`each_array`, `$$length`, synthetic indices) come from `state.scope.root.unique(...)` or analyzer-synthesized names to avoid capturing user bindings.
7. **No diagnostics here.** Errors such as unclosed blocks (`block_unclosed`) or invalid block usage are raised in Phase 1/2 (see [compiler-core_diagnostics](compiler-core_diagnostics.md)); these visitors assume a valid, analyzed AST.

---

## 10. Extending the Module

Adding a new control-flow construct to Svelte SSR requires touching (in order):

1. **Types** — the AST node in `template.d.ts` (see [compiler-core_type_definitions](compiler-core_type_definitions.md));
2. **Parser** — a new block state (see [compiler-parser_parsing-states](compiler-parser_parsing-states.md));
3. **Analyzer** — a visitor producing metadata + validation (see [compiler-analyzer_visitors](compiler-analyzer_visitors.md));
4. **This module** — a `visitors/<New>.js` server visitor following the contract in §3.1, registered in `template_visitors` in `transform-server.js`;
5. **Client transform** — the matching structural visitor ([compiler-transformer_client-transform_structural-visitors](compiler-transformer_client-transform_structural-visitors.md));
6. **Runtime** — any new `$.helper` must be added to `internal/server/index.js` and kept tree-shakeable (see [server-runtime](server-runtime.md)).

Keep the module dependency-free beyond `#compiler/builders`, `./shared/utils.js`, the hydration constants and types — its four visitors are deliberately the smallest, most auditable files in the server transform.
