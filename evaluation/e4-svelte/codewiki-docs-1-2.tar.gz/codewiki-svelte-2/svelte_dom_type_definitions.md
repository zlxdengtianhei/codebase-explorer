# svelte_dom_type_definitions

## 1. Overview

The `svelte_dom_type_definitions` module is a **type-only module** — it contains no runtime code. It lives in a single file, `packages/svelte/elements.d.ts`, and is published publicly as **`svelte/elements`**. Its purpose is to provide the complete, authoritative TypeScript contracts for every HTML, SVG, and Svelte-specific element that can appear in a Svelte template:

- which **attributes** each element accepts (and their value types),
- which **events** each element supports (`on:event`, `onevent`, `on:eventcapture`),
- which **bindings** each element supports (`bind:*`),
- which **Svelte extensions** are legal per element (snippets, attachments, SvelteKit data attributes).

It is adapted from the React 18 JSX type definitions (DefinitelyTyped), reworked for Svelte semantics: Svelte's `on:` directive syntax, `bind:` directives, snippets instead of React children, attachments instead of refs, and `null` treated the same as `undefined` when removing attributes.

| Property | Value |
|---|---|
| File | `packages/svelte/elements.d.ts` |
| Public path | `svelte/elements` |
| Core components | `AriaAttributes`, `DOMAttributes`, `HTMLMediaAttributes`, `SvelteHTMLElements` |
| Runtime code | none (`.d.ts` declarations only) |
| Parent module | [public-api](public-api.md) (Public API & Built-in Feature Surface) |

The module sits at the intersection of **editor tooling** (type checking and autocomplete in `.svelte` files via the language server), **user code** (typing `$props()` spreads, component libraries), and the **runtime** (each `bind:` / `on:` entry it declares is implemented by a corresponding runtime helper — see [client-dom-renderer](client-dom-renderer.md)).

---

## 2. Architecture: the layered type model

The file is organized as a strictly layered composition of interfaces. Low-level building blocks (event handler functions) are composed into shared attribute groups (`DOMAttributes`, `AriaAttributes`), which are combined into concrete element contracts (`HTMLAttributes`, element-specific interfaces), and finally registered in a single tag-name → attributes map (`SvelteHTMLElements`).

```mermaid
flowchart TD
    subgraph L1["Layer 1 - Event handler primitives"]
        EH["EventHandler&lt;E, T&gt;<br/>typed callback with currentTarget narrowed to T"]
        HA["18 typed aliases<br/>MouseEventHandler, KeyboardEventHandler,<br/>FocusEventHandler, TransitionEventHandler, ..."]
        EH --> HA
    end

    subgraph L2["Layer 2 - Shared attribute groups"]
        DOM["DOMAttributes&lt;T&gt;<br/>on:event / onevent / oneventcapture triplets<br/>children?: Snippet<br/>readonly bind: dimension props"]
        ARIA["AriaAttributes<br/>all WAI-ARIA 1.1 aria-* attributes"]
        ROLE["AriaRole<br/>union + string escape hatch"]
    end

    subgraph L3["Layer 3 - Element attribute contracts"]
        HTML["HTMLAttributes&lt;T&gt;<br/>standard / RDFa / SvelteKit attrs<br/>data-* index, symbol Attachment index"]
        SVG["SVGAttributes&lt;T&gt;<br/>SVG + xlink/xml namespace attrs"]
        MEDIA["HTMLMediaAttributes&lt;T&gt;<br/>media attributes + media binds"]
        SPECIFIC["~90 per-element interfaces<br/>HTMLInputAttributes, HTMLAnchorAttributes,<br/>HTMLButtonAttributes, HTMLImgAttributes, ..."]
    end

    subgraph L4["Layer 4 - Svelte special elements"]
        SWIN["SvelteWindowAttributes"]
        SDOC["SvelteDocumentAttributes"]
    end

    subgraph L5["Layer 5 - Tag registry"]
        MAP["SvelteHTMLElements<br/>(tag name to attribute type)"]
    end

    HA --> DOM
    DOM -->|extends| HTML
    ARIA -->|extends| HTML
    ROLE -.->|referenced by| HTML
    DOM -->|extends| SVG
    ARIA -->|extends| SVG
    HTML -->|extends| MEDIA
    HTML -->|extends| SPECIFIC
    MEDIA -->|extends| AUDVID["HTMLAudioAttributes / HTMLVideoAttributes"]
    HTML -->|extends| SWIN
    HTML -->|extends| SDOC
    SPECIFIC --> MAP
    SVG --> MAP
    MEDIA --> MAP
    SWIN --> MAP
    SDOC --> MAP
```

This layering yields heavy reuse: every one of the ~180 registered element entries inherits the full event surface, ARIA surface, data-* escape hatch, and attachment support "for free" from `HTMLAttributes`/`SVGAttributes`, and only declares its element-specific deltas.

---

## 3. Core components

### 3.1 `EventHandler<E, T>` and typed handler aliases

The root primitive. A handler is a function receiving the event `E`, with `currentTarget` narrowed to `EventTarget & T` so that handlers get correctly typed event targets:

```ts
type EventHandler<E extends Event = Event, T extends EventTarget = Element> = (
	event: E & { currentTarget: EventTarget & T }
) => any;
```

Eighteen aliases (`ClipboardEventHandler`, `MouseEventHandler`, `PointerEventHandler`, `AnimationEventHandler`, `ToggleEventHandler`, ...) map DOM event classes to handlers. Svelte also declares handlers for its own synthetic transition events (`on:introstart`, `on:introend`, `on:outrostart`, `on:outroend`), emitted by the transition runtime (see [client-dom-renderer_transitions](client-dom-renderer_transitions.md)).

### 3.2 `DOMAttributes<T>`

The universal event/behavior surface shared by every element. Key members:

| Member group | Description |
|---|---|
| `on:event` / `onevent` / `oneventcapture` | Every event is declared in **three spellings**: the Svelte directive form (`'on:click'`), the property form (`onclick`), and the capture-phase form (`onclickcapture`). This lets both `on:click={...}` templates and `let { onclick } = $props()` style APIs type-check. |
| `children?: Snippet` | The implicit `children` snippet every element accepts, so libraries spreading props (`let { ...props }: HTMLButtonAttributes = $props()`) do not need a separate interface. Snippet itself comes from [public-api_component-types](public-api_component-types.md). |
| `readonly 'bind:clientWidth'`, `'bind:clientHeight'`, `'bind:contentRect'`, `'bind:contentBoxSize'`, `'bind:borderBoxSize'`, `'bind:devicePixelContentBoxSize'` | Read-only dimension bindings implemented by `bind_element_size` / `bind_resize_observer` (shared `ResizeObserverSingleton`) in [client-dom-renderer_bindings](client-dom-renderer_bindings.md). |
| `xmlns` | Namespacing escape for `<svelte:element>`-style dynamic elements. |

### 3.3 `AriaAttributes` (and `AriaRole`)

The full WAI-ARIA 1.1 attribute set (`aria-activedescendant` through `aria-valuetext`), each optional and typed with precise unions (`Booleanish`, `'grammar' | 'spelling'`, live-region politeness values, etc.) and JSDoc documentation for editor hovers. `AriaRole` is a large string union of all ARIA roles plus `(string & {})` — the escape-hatch pattern that keeps autocomplete while still allowing arbitrary custom roles.

> **Complementary checks:** editor-time typing is complemented by the compiler's own a11y analysis (e.g. `a11y_incorrect_aria_attribute_type_id` in [compiler-core_diagnostics](compiler-core_diagnostics.md)), which validates aria attribute values during compilation. The two layers intentionally do not duplicate each other: this module governs what the IDE accepts, the analyzer governs what the compiler warns about.

### 3.4 `HTMLAttributes<T>` (supporting, but central)

Composes `AriaAttributes` + `DOMAttributes<T>` and adds:

- **Standard HTML attributes** (`id`, `class`, `style`, `tabindex`, `lang`, ...) with Svelte value unions (e.g. `class?: ClassValue` accepting clsx-shaped values),
- **RDFa, non-standard, and Living Standard attributes** (`inputmode`, `is`, `popover`, `inert`, ...),
- **contenteditable bindings**: `bind:innerHTML`, `bind:textContent`, `bind:innerText`,
- **element bindings**: readonly `bind:focused`, `bind:offsetWidth`, `bind:offsetHeight`,
- **SvelteKit attributes**: `data-sveltekit-keepfocus`, `data-sveltekit-preload-code`, ... ,
- **two open index signatures**:
  - `[key: \`data-${string}\`]: any` — any data-* attribute,
  - `[key: symbol]: Attachment<T> | false | undefined | null` — attachment props. Attachments are added via `createAttachmentKey()` (a unique symbol, see [actions-attachments_attachment-bridge](actions-attachments_attachment-bridge.md)); `false` is admitted so conditionally-falsy attachment expressions type-check while bare booleans do not.

### 3.5 `HTMLMediaAttributes<T>`

A generic contract parameterized over `HTMLMediaElement` subtypes, extended by `HTMLAudioAttributes` and `HTMLVideoAttributes`. Beyond standard media attributes (`autoplay`, `controls`, `preload`, `volume`, ...), it declares the **media binding surface**:

| Binding | Type | Runtime counterpart |
|---|---|---|
| `bind:currentTime` | `number` | `bind_current_time` (rAF loop + `timeupdate`) |
| `bind:duration`, `bind:readyState` | readonly | media state observers |
| `bind:buffered`, `bind:played`, `bind:seekable` | `SvelteMediaTimeRange[]` | time-range observers |
| `bind:paused`, `bind:muted`, `bind:volume`, `bind:playbackRate`, `bind:ended`, `bind:seeking` | mixed | dedicated bind helpers |

The helper type `SvelteMediaTimeRange { start: number; end: number }` is Svelte-specific — it is not a DOM type. All media bind implementations live in [client-dom-renderer_bindings](client-dom-renderer_bindings.md).

### 3.6 `SvelteHTMLElements` — the tag registry

The culmination of the file: a single interface mapping every usable tag name to its attribute contract, plus a string index fallback.

```mermaid
flowchart LR
    MAP["SvelteHTMLElements"]
    MAP --> HTMLG["~110 HTML elements<br/>a to HTMLAnchorAttributes<br/>input to HTMLInputAttributes<br/>div to HTMLAttributes&lt;HTMLDivElement&gt;<br/>video to HTMLVideoAttributes"]
    MAP --> SVGG["~60 SVG elements<br/>svg, path, circle, filter, text, ...<br/>all to SVGAttributes&lt;T&gt;"]
    MAP --> SVELTEG["7 svelte:* elements<br/>svelte:window - SvelteWindowAttributes<br/>svelte:document - SvelteDocumentAttributes<br/>svelte:body - HTMLAttributes&lt;HTMLElement&gt;<br/>svelte:head, svelte:fragment, svelte:options,<br/>svelte:boundary"]
    MAP --> FALL["string index fallback<br/>name to any-props record<br/>custom and unknown elements"]
```

Notable Svelte-specific entries:

- **`svelte:boundary`** — `onerror?: (error, reset) => void`, `failed?: Snippet<[error, reset]>`, `pending?: Snippet`. The typing mirrors the error-boundary runtime in [client-dom-renderer_control-flow-blocks](client-dom-renderer_control-flow-blocks.md) (including the diagnostics `svelte_boundary_reset_onerror` / `svelte_boundary_reset_noop` in [client-dev-tooling](client-dev-tooling.md)).
- **`svelte:options`** — the compiler-options element, with a fully typed `customElement` configuration (`tag`, `shadow`, per-prop `attribute`/`reflect`/`type`, and an `extend` customizer consumed by the custom-element runtime, [client-dom-renderer_custom-elements](client-dom-renderer_custom-elements.md)).
- **`svelte:window` / `svelte:document`** — readonly size/state bindings (`bind:innerWidth`, `bind:scrollY`, `bind:online`, `bind:visibilityState`, ...) plus window-only events (`on:beforeunload`, `on:popstate`, `on:devicemotion`, ...).
- **`svelte:fragment`** — just `{ slot?: string }`.
- **The `[name: string]` fallback** — ensures custom elements and unknown tags never hard-fail type checking, which is also how `<svelte:element this={...}>` stays permissive.

---

## 4. How the module is consumed (data flow)

The primary consumer is the Svelte language server, through `svelte-html.d.ts` (documented in [public-api_html-typings](public-api_html-typings.md)). That file is deliberately **not** in the package exports map — it is loaded directly by the language tooling and declares a global `svelteHTML` namespace whose `IntrinsicElements` *extends* `SvelteHTMLElements`, wrapping each entry with `Omit<SvelteHTMLElements[tag], keyof HTMLAttributes> & HTMLAttributes` so that user augmentation of `HTMLAttributes` flows into every element.

```mermaid
sequenceDiagram
    autonumber
    participant Dev as Developer (.svelte template)
    participant LS as Svelte language server
    participant SH as svelteHTML global (svelte-html.d.ts)
    participant E as svelte/elements (elements.d.ts)
    participant Comp as Svelte compiler
    participant RT as Client runtime (client-dom-renderer)

    Dev->>LS: writes input with bind:value and onchange
    LS->>SH: resolve tag "input" via IntrinsicElements
    SH->>E: SvelteHTMLElements["input"]
    E-->>SH: HTMLInputAttributes contract
    SH-->>LS: merged element contract
    LS-->>Dev: diagnostics and completions (bind:value, aria-*, data-*, on:*)
    Dev->>Comp: compile component
    Comp->>RT: emits attribute_effect and bind helper calls
    RT-->>Dev: DOM updates driven by the reactivity engine
```

The compiler's *internal* AST has its own node types for the same constructs (`RegularElement`, `SvelteWindow`, `SlotElement`, ... in [compiler-core_type_definitions](compiler-core_type_definitions.md)). Those describe **what the compiler sees**; `svelte/elements` describes **what authors may write**. They are intentionally separate: internal types evolve with the compiler, public types evolve with the HTML/platform surface.

---

## 5. Ecosystem dependency graph

```mermaid
flowchart TD
    ELEM["svelte_dom_type_definitions<br/>packages/svelte/elements.d.ts<br/>public path: svelte/elements"]

    subgraph UP["Type dependencies"]
        ATT["actions-attachments<br/>Attachment"]
        SNIP["public-api_component-types<br/>Snippet"]
        CLSX["clsx (external)<br/>ClassArray / ClassDictionary"]
    end

    subgraph DOWN["Primary consumers"]
        SH["public-api_html-typings<br/>svelteHTML.IntrinsicElements"]
        AGG["svelte-public-types<br/>aggregated package type surface"]
        USER["User code and component libraries<br/>typed $props() spreads, HTMLAttributes extension"]
    end

    subgraph RT["Runtime counterparts (behavior behind the types)"]
        BIND["client-dom-renderer_bindings"]
        ATTR["client-dom-renderer_attributes-events"]
        TRANS["client-dom-renderer_transitions"]
        BLOCKS["client-dom-renderer_control-flow-blocks"]
        CUST["client-dom-renderer_custom-elements"]
    end

    ATT -->|type import| ELEM
    SNIP -->|type import| ELEM
    CLSX -->|type import| ELEM
    ELEM -->|extended by| SH
    ELEM -->|re-exported via| AGG
    SH -->|powers typing for| USER
    ELEM -.->|bind: props| BIND
    ELEM -.->|on: props, attributes| ATTR
    ELEM -.->|intro/outro events| TRANS
    ELEM -.->|svelte:boundary| BLOCKS
    ELEM -.->|svelte:options| CUST
```

### Integration summary

| Module | Relationship | Notes |
|---|---|---|
| [public-api](public-api.md) | parent | This module is the HTML typing slice of the built-in feature surface. |
| [public-api_html-typings](public-api_html-typings.md) | direct consumer | `IntrinsicElements extends SvelteHTMLElements`; entry-point for the language server. |
| [public-api_component-types](public-api_component-types.md) | dependency | `Snippet` used for `children` and boundary snippets. |
| [actions-attachments](actions-attachments.md) | dependency | `Attachment` type referenced by the symbol index signature. |
| [svelte-public-types](svelte-public-types.md) | aggregator | Package-level type index re-exposes element-related types alongside compiler and runtime types. |
| [client-dom-renderer_bindings](client-dom-renderer_bindings.md) | runtime counterpart | Implements every `bind:*` prop declared here. |
| [client-dom-renderer_attributes-events](client-dom-renderer_attributes-events.md) | runtime counterpart | Implements attribute application and event handling for `on:*` props. |
| [client-dom-renderer_transitions](client-dom-renderer_transitions.md) | runtime counterpart | Emits the typed `on:intro*` / `on:outro*` events. |
| [compiler-core_type_definitions](compiler-core_type_definitions.md) | sibling contract | Internal AST node types; do not conflate with these public authoring types. |
| [compiler-core_diagnostics](compiler-core_diagnostics.md) | complement | Compile-time a11y/CSS diagnostics complement editor-time typing. |

---

## 6. Design conventions

Understanding these recurring conventions is essential for reading and extending the file:

1. **Optional + `undefined | null` everywhere.** Svelte removes an attribute when its value is `null` or `undefined`, so virtually every prop is `T | undefined | null`.
2. **`Booleanish`.** `boolean | 'true' | 'false'` supports both real booleans (spread from props) and string attribute forms.
3. **Event triplets.** `on:event`, `onevent`, `oneventcapture` are declared for the same event so both template directive syntax and plain property spreading type-check.
4. **Readonly binds.** Bindings backed by read-only DOM state (`bind:offsetWidth`, `bind:duration`, `bind:readyState`) are marked `readonly` so users cannot assign to them.
5. **Escape-hatch unions.** `'submit' | 'reset' | 'button' | (string & {})` patterns (in `AriaRole`, `HTMLInputTypeAttribute`, `HTMLAttributeAnchorTarget`, ...) preserve literal autocomplete while remaining open-ended.
6. **Index signature escapes.** `data-*` (any value) and `symbol` (attachments) index signatures keep the surface extensible without `any`-casting.
7. **Dual casing defaults.** `input`/`textarea` declare both `defaultValue` and `defaultvalue` because language tooling lowercases non-shorthand attribute names.
8. **Types only, zero runtime.** The file contributes nothing to bundles; there is no tree-shaking concern, unlike runtime modules checked by the treeshakeability script in [treeshakeability_checker](treeshakeability_checker.md).
9. **Provenance.** The file derives from React 18 JSX typings; when porting upstream changes, adapt React-isms (refs → attachments, children → snippets, `onChange` semantics → Svelte's `on:change`).

---

## 7. Maintenance and extension guide

- **Adding a platform attribute/event/binding:** add it to the narrowest layer that applies (shared events → `DOMAttributes`; ARIA → `AriaAttributes`; one element → its `HTML*Attributes` interface). Everything downstream of `SvelteHTMLElements`, including the language-server entry point, updates automatically.
- **Adding an element:** add a key to `SvelteHTMLElements` mapping to `HTMLAttributes<X>` (or a new dedicated interface). If it is a well-known tag, the corresponding `svelte-html.d.ts` entry may also need the `HTMLProps<'tag', ...>` wrapper for augmentation support.
- **User-side extension:** applications extend the `svelteHTML.HTMLAttributes` / `SVGAttributes` interfaces (interface merging, see [public-api_html-typings](public-api_html-typings.md)) or add custom-element entries to `svelteHTML.IntrinsicElements` — not to `svelte/elements` itself.
- **Keep contracts in sync:** whenever a `bind:*` prop is added here, a runtime implementation must exist in [client-dom-renderer_bindings](client-dom-renderer_bindings.md), and vice versa; the types are the author-facing half of that contract. Similarly, `svelte:boundary` props must stay aligned with the boundary block runtime and its dev diagnostics.

---

*Related documentation: [public-api](public-api.md) · [public-api_html-typings](public-api_html-typings.md) · [public-api_component-types](public-api_component-types.md) · [svelte-public-types](svelte-public-types.md) · [actions-attachments](actions-attachments.md) · [client-dom-renderer](client-dom-renderer.md) · [compiler-core_type_definitions](compiler-core_type_definitions.md)*