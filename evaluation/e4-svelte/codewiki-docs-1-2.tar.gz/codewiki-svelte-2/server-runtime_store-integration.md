# Server Runtime — Store Integration (`server-runtime_store-integration`)

> **Location:** `packages/svelte/src/internal/server/index.js`
> **Parent module:** [`server-runtime`](server-runtime_render-pipeline.md) (within *Server-Side Rendering & Cross-Target Runtime Services*)

---

## 1. Introduction

The **store-integration** module implements Svelte's legacy *store auto-subscription* (`$store`) and the server-side *runes* `$derived` behaviour inside the **SSR runtime**. When a component is compiled with the `server` option, every template or script reference to a store is lowered into calls against a small set of exported functions from `packages/svelte/src/internal/server/index.js`:

| Runtime function | Source syntax (compiled away) |
| --- | --- |
| `store_get` | reading `$store` (implicit subscription + cached read) |
| `store_set` | plain assignment `$store = value` |
| `store_mutate` | compound assignment `$store += x`, `$store.field = y` |
| `update_store` | post-increment/decrement `$store++`, `$store--` |
| `update_store_pre` | pre-increment/decrement `++$store`, `--$store` |
| `unsubscribe_stores` | automatic teardown at end of render |
| `derived` | `$derived` rune read/write on the server |

Because server rendering is a **single synchronous pass** (no reactivity graph exists), this module trades the client's signal-based subscription machinery for a **flat, per-component-instance subscription cache** plus **deterministic teardown** orchestrated by the render pipeline. The result is behaviorally equivalent output for one render: values are correct, subscriber callbacks (e.g. `StartStopNotifier`s of `writable` stores) fire exactly once, and every subscription is released before `render()` returns.

For the client-side counterpart — where these same call shapes are wired into the signal graph instead — see [`client-reactivity-engine_props-and-stores`](client-reactivity-engine_props-and-stores.md). For the public `svelte/store` package that produces the stores consumed here, see [`stores`](stores.md).

---

## 2. Architecture

### 2.1 Component overview

All functions live in `packages/svelte/src/internal/server/index.js` and operate on a single shared data structure:

```
store_values (compiled code passes `$$store_subs`)
  Record<string, [store, unsubscribeFn, cachedValue]>
                 ^^^^^  ^^^^^^^^^^^^^^  ^^^^^^^^^^^
                 slot 0      slot 1        slot 2
```

* **slot 0** — the currently bound store instance (used to detect store *switching*, e.g. `$dynamic` reassignments)
* **slot 1** — the unsubscribe function returned by `subscribe_to_store`
* **slot 2** — the most recent value pushed by the store's `subscribe` callback

### 2.2 Architecture diagram

```mermaid
flowchart TB
    subgraph Compiled["Compiled server component ($.js output)"]
        A["read: $store"] -->|"$.store_get($$store_subs, '$store', store)"| SG
        B["assign: $store = v"] -->|"$.store_set(store, v)"| SS
        C["compound: $store += x"] -->|"$.store_mutate(...)"| SM
        D["$store++ / ++$store"] -->|"$.update_store / $.update_store_pre"| UP
        E["cleanup registration<br/>onDestroy(() =&gt; unsubscribe_stores($$store_subs))"] --> CTX
        F["$derived expr"] -->|"$.derived(fn)"| DER
    end

    subgraph API["store-integration API (internal/server/index.js)"]
        SG["store_get"]
        SS["store_set"]
        SM["store_mutate"]
        UP["update_store<br/>update_store_pre"]
        DER["derived (→ once)"]
        US["unsubscribe_stores"]
    end

    SG -->|"subscribe / cache"| REC["store_values record<br/>[store, unsub, value]"]
    SM --> SG
    SM --> SS
    UP --> SG
    US -->|"calls unsub() per key"| REC

    SG -->|"subscribe(run)"| SUB["subscribe_to_store<br/>(store/utils.js — shared)"]
    SUB -->|"store.subscribe(run)"| STORE["User store<br/>writable / readable / derived / custom / RxJS-like"]
    SG -.->|"DEV only"| VAL["validate_store<br/>(shared/validate.js)"]

    CTX["context.js pop()"] -->|"pushes component.d callbacks"| OD["on_destroy queue"]
    OD -->|"flushed by render()"| US

    style API fill:#eef,stroke:#88f
    style REC fill:#ffe,stroke:#cc8
```

### 2.3 Upstream and downstream relationships

```mermaid
flowchart LR
    ST["compiler-transformer_server-transform"] -->|"emits $.store_get / $.store_set /<br/>$.store_mutate / $.update_store(_pre) /<br/>$.unsubscribe_stores / $.derived"| SI["store-integration"]
    SI -->|"consumes Store contract"| PUB["stores (public svelte/store)"]
    SI -->|"shared helpers"| UTIL["internal-shared-utils /<br/>store utils (subscribe_to_store)"]
    SI -->|"cleanup registration via onDestroy"| CTX["context-api (server context)"]
    RP["server-runtime_render-pipeline"] -->|"flushes on_destroy after render"| SI
    DEV["server-runtime_dev-diagnostics"] -.->|"DEV store shape validation"| SI
```

* **Compiler dependency:** the server visitor in [`compiler-transformer_server-transform`](compiler-transformer_server-transform.md) is the *only* producer of these calls — nothing in the runtime invokes them internally except `unsubscribe_stores`, which is invoked by user-registered cleanup.
* **Store contract dependency:** stores only need to satisfy `{ subscribe(run, invalidate?) => unsub }` and optionally `{ set(value) }`. `subscribe_to_store` additionally normalizes `null` stores and RxJS-style observables (`unsub.unsubscribe`).

---

## 3. API Reference

### 3.1 `store_get(store_values, store_name, store)` → `V`

The heart of `$store` reads on the server.

```js
// simplified semantics
function store_get(store_values, store_name, store) {
  if (DEV) validate_store(store, store_name.slice(1));   // '$foo' → error says "foo"

  // 1. Fast path: same store instance already subscribed → cached value
  if (store_name in store_values && store_values[store_name][0] === store) {
    return store_values[store_name][2];
  }

  // 2. Store was switched → release the previous subscription
  store_values[store_name]?.[1]();

  // 3. Subscribe; every push updates the cached slot in place
  store_values[store_name] = [store, null, undefined];
  const unsub = subscribe_to_store(store, (v) => (store_values[store_name][2] = v));
  store_values[store_name][1] = unsub;

  // 4. Return the synchronously-available value
  return store_values[store_name][2];
}
```

Key behaviours:

* **Synchronous first value.** Svelte stores deliver the current value immediately upon `subscribe`, so the read is synchronous — no awaits, no microtasks.
* **Subscription reuse.** Repeated reads of `$foo` within one component render hit the cache and never re-subscribe. This is deliberate: the instance script may eagerly mutate the store, so the *template* always reads the freshest pushed value.
* **Store switching.** If `$foo` is rebound to a different store instance (conditional expressions), the old subscription is torn down before a new one is created.
* **Dev validation.** In `DEV`, `validate_store` rejects objects lacking a `subscribe` method with a descriptive `store_invalid_shape` error using the human-readable name (`store_name.slice(1)` strips the `$`).

### 3.2 `store_set(store, value)` → `V`

Direct passthrough to the store contract:

```js
store.set(value);
return value;
```

Returning the value lets the compiler use it inline in expressions. Used for plain assignments `$store = value`.

### 3.3 `store_mutate(store_values, store_name, store, expression)` → value of `expression`

Lowers compound assignments and property writes on stores:

```js
store_set(store, store_get(store_values, store_name, store));
return expression;
```

The compiled expression argument (e.g. `store.value += 1`) performs the actual arithmetic and write; the preceding `store_set(store, store_get(...))` guarantees the store is **subscribed and its cached value is current** before the expression runs, so mutation side-effects observe a consistent state. The return value preserves expression semantics for statement-position usage.

### 3.4 `update_store(store_values, store_name, store, d = 1)` → old value

Post-increment / post-decrement (`$store++`, `$store--`):

```js
let store_value = store_get(store_values, store_name, store);
store.set(store_value + d);
return store_value;   // OLD value — mirrors `x++` semantics
```

### 3.5 `update_store_pre(store_values, store_name, store, d = 1)` → new value

Pre-increment / pre-decrement (`++$store`, `--$store`):

```js
const value = store_get(store_values, store_name, store) + d;
store.set(value);
return value;         // NEW value — mirrors `++x` semantics
```

Both functions are typed for `Store<number>`; `d` is restricted to `1 | -1` by the compiler.

### 3.6 `unsubscribe_stores(store_values)` → `void`

Teardown for an entire render:

```js
for (const store_name in store_values) {
  store_values[store_name][1]();   // invoke each unsubscribe fn
}
```

Compiled components register this once per component instance (typically as `onDestroy(() => unsubscribe_stores($$store_subs))`). It is idempotent per render because the cleanup functions were created for this specific `store_values` record.

### 3.7 `derived(fn)` → `(new_value?) => T`

Server implementation of the `$derived` rune. It is a **function signal**: call with no arguments to read, with an argument to write.

```js
export function derived(fn) {
  const get_value = once(fn);        // memoized: evaluated at most once per render
  let updated_value;

  return function (new_value) {
    if (arguments.length === 0) {
      return updated_value ?? get_value();   // read: cached write or lazy compute
    }
    updated_value = new_value;               // write: recorded, nothing invalidated
    return updated_value;
  };
}
```

Semantics on the server:

* **Lazy & memoized.** `once` (an `UNINITIALIZED` sentinel wrapper) evaluates `fn` only on first read; subsequent reads return the cache. Order of evaluation therefore follows *render order*, not declaration order.
* **Writes are recorded, not propagated.** Assignments to a `$derived` store the value for later reads but never re-run dependents — correct because a synchronous single-pass render has no later "dirty" phase to invalidate.
* **No dependency tracking.** Unlike the client, there is no signal graph; the compiled `fn` closure reads its sources directly.

---

## 4. Subscription Lifecycle During SSR

The sequence below shows how a single `$count` reference flows from compiled code through subscription, mutation, and guaranteed teardown.

```mermaid
sequenceDiagram
    autonumber
    participant R as render() (render-pipeline)
    participant C as Compiled component
    participant SG as store_get
    participant REC as $$store_subs record
    participant S as User store
    participant OD as on_destroy queue
    participant US as unsubscribe_stores

    R->>R: on_destroy = [] (fresh queue for this render)
    R->>C: component(payload, props, {}, {})
    C->>SG: store_get($$store_subs, '$count', count)
    SG->>SG: DEV: validate_store(count, 'count')
    alt first access or store switched
        SG->>REC: release previous unsub (slot 1) if any
        SG->>S: subscribe(run)
        S-->>SG: run(currentValue)
        SG->>REC: store ['count'] = [store, unsub, currentValue]
    end
    SG-->>C: currentValue (cached — later reads skip subscribe)
    C->>S: store.set(newValue) — store_set / store_mutate / update_store(_pre)
    S-->>REC: run(newValue) → slot 2 updated in place
    Note over C,REC: more template reads reuse the cache; store switching re-subscribes
    C->>C: body finished → pop() (context-api)
    C->>OD: push onDestroy(() => unsubscribe_stores($$store_subs))
    C-->>R: done
    R->>OD: for (cleanup of on_destroy) cleanup()
    OD->>US: unsubscribe_stores($$store_subs)
    US->>S: unsubscribe() for every entry in record
```

### 4.1 How teardown is orchestrated

The unsubscribe path crosses two sibling modules:

1. **Registration** — the compiled component calls the public `onDestroy(cb)` (see [`public-api`](public-api.md)). On the server this appends to `component.d` on the current component context (see [`context-api`](context-api.md)).
2. **Propagation** — `pop()` (server `context.js`) transfers `component.d` callbacks into the module-level `on_destroy` array exported by `index.js`. Nesting is preserved: the array is swapped per `render()` call so concurrent/recursive renders cannot leak cleanups into each other.
3. **Flush** — `render()` (see [`server-runtime_render-pipeline`](server-runtime_render-pipeline.md)) executes `for (const cleanup of on_destroy) cleanup()` *after* the component body, then restores the previous array. This guarantees every store `StartStopNotifier` runs exactly once per render and every subscription is released even if the component throws (the `finally { abort(); }` in `render()` handles abort signalling; subscription cleanup happens on the success path after the body completes).

---

## 5. Server `derived` Evaluation Flow

```mermaid
flowchart TD
    A["Compiled: const doubled = $.derived(() =&gt; count * 2)"] --> B["derived wraps fn with once()"]
    B --> C{"read: doubled()"}
    C -->|"arguments.length === 0"| D{"updated_value set?"}
    D -->|"yes (was written)"| E["return updated_value"]
    D -->|"no"| F{"evaluated before?<br/>(value !== UNINITIALIZED)"}
    F -->|"no"| G["evaluate fn() once → cache"]
    G --> H["return cached value"]
    F -->|"yes"| H
    C -->|"doubled(v) — write"| I["updated_value = v<br/>(no invalidation — single-pass SSR)"]
```

Practical consequences for maintainers:

* Reads inside `if/each/await` branches may or may not trigger evaluation depending on which branches execute — `derived` is *demand-driven*, unlike the client where derivations eagerly participate in the graph.
* `?? get_value()` (rather than `??` on the sentinel) means a write of `undefined`/`null` followed by a read still returns the written value only while `updated_value` is set; a write of `undefined` falls back to the lazy computation. Compiled code never relies on writing `undefined` to a derived, so this is safe in practice.

---

## 6. Template-Syntax → Runtime-Call Mapping

| `.svelte` source (legacy `$store` syntax) | Server output (via [`compiler-transformer_server-transform`](compiler-transformer_server-transform.md)) |
| --- | --- |
| `{$count}` | `$.store_get($$store_subs ??= {}, '$count', count)` |
| `$count = 5` | `$.store_set(count, 5)` |
| `$count += n` | `$.store_mutate($$store_subs, '$count', count, count.value += n)` |
| `$count++` / `$count--` | `$.update_store($$store_subs, '$count', count, 1 / -1)` |
| `++$count` / `--$count` | `$.update_store_pre($$store_subs, '$count', count, 1 / -1)` |
| end of instance script | `onDestroy(() => $.unsubscribe_stores($$store_subs))` |
| `const d = $derived(expr)` | `const d = $.derived(() => expr)` |

> **Note:** `$$store_subs` is hoisted by the compiler to the component body so that all reads/writes across the template share one record — this is what makes cache reuse and single-point teardown possible.

---

## 7. Error Handling & Dev Diagnostics

* **`validate_store`** (DEV only, `internal/shared/validate.js`): raises `store_invalid_shape(name)` when a value referenced via `$name` does not implement `subscribe`. The `$` prefix is stripped from `store_name` (`store_name.slice(1)`) so the error message uses the identifier the developer actually wrote.
* **`null`/`undefined` stores:** `subscribe_to_store` treats them as "no value" — it invokes `run(undefined)` and returns a `noop` unsubscribe. A conditional `$maybeStore` therefore renders `undefined` without crashing.
* **RxJS-style observables:** if `subscribe()` returns an object with `.unsubscribe` (instead of a function), `subscribe_to_store` adapts it: `() => unsub.unsubscribe()`. `unsubscribe_stores` then works uniformly.
* **Store switching:** handled inside `store_get` (old subscription released before re-subscribing) rather than as an error — matching client behaviour where `$store` reassignments swap subscriptions.

For runtime element/snippet diagnostics that share this module's `index.js` file, see [`server-runtime_dev-diagnostics`](server-runtime_dev-diagnostics.md).

---

## 8. Relationship to Other Modules

| Module | Relationship |
| --- | --- |
| [`server-runtime_render-pipeline`](server-runtime_render-pipeline.md) | `render()` owns the `on_destroy` queue lifecycle and flushes `unsubscribe_stores` cleanups; also provides `Payload`, context push/pop around the component call. |
| [`server-runtime_payload-and-output`](server-runtime_payload-and-output.md) | Unrelated to store state itself — store values never enter the `Payload`; they are read into compiled locals during render. |
| [`server-runtime_slots-snippets-and-blocks`](server-runtime_slots-snippets-and-blocks.md) | Snippets/slots rendered from the same component closure observe store values through the shared `$$store_subs` cache. |
| [`context-api`](context-api.md) | Server `push`/`pop` maintain the component context that `onDestroy` callbacks (incl. store teardown) attach to. |
| [`client-reactivity-engine_props-and-stores`](client-reactivity-engine_props-and-stores.md) | Client twin (`internal/client/reactivity/store.js`): identical call shapes (`store_get`, `store_mutate`, `update_store(_pre)`, `unsubscribe_stores`, `invalidate_store`, `setup_stores`) but wired into the signal graph with invalidation and batching. |
| [`stores`](stores.md) | Public `svelte/store` package (`writable`, `readable`, `derived`, `get`) — produces the stores consumed here; `store/shared/derived` itself builds on `subscribe_to_store` from the same `store/utils.js` used by this module. |
| [`public-api`](public-api.md) | Exposes `onDestroy` used by compiled code to register the teardown closure. |
| [`compiler-transformer_server-transform`](compiler-transformer_server-transform.md) | Sole emitter of calls into this API; keeps compiled output tree-shakeable (functions are plain exports). |

---

## 9. Design Notes for Maintainers

1. **Everything is synchronous.** Unlike hydration or the client, no task queue (`loop.js`) or batching (`batch.js`) is involved. Each `store.set` synchronously notifies subscribers; the cached slot (`[2]`) is updated synchronously by the run callback.
2. **One record per component instance, per render.** Because `render()` creates fresh closures and resets `on_destroy`, store subscriptions cannot leak across renders. Never cache `store_values` at module scope.
3. **`store_mutate`'s double-touch is intentional.** `store_set(store, store_get(...))` may look redundant (the compiled expression also writes), but it guarantees subscription establishment *and* subscriber notification ordering before arbitrary user expressions run. Do not "optimize" it away.
4. **`update_store` returns old, `update_store_pre` returns new.** Mirroring `x++` vs `++x` is contractual — the compiler relies on it for expression-position correctness (e.g. `{$count++}` must render the pre-increment value).
5. **`derived` writes are best-effort.** The server write path exists so that legacy patterns assigning to derived-like bindings don't crash; it performs no graph work. If you need write-through semantics for tests, exercise the client runtime instead.
6. **Tree-shakeability.** All functions are individually exported, plain, and free of side effects so bundlers can drop unused ones (checked by `check-treeshakeability` in the *Engineering Tooling* module). Avoid adding module-level mutable state.
7. **Shared contract.** Any change to the `Store` contract must be mirrored in `subscribe_to_store` (`store/utils.js`), the client store module, and the public `svelte/store` docs (see [`stores`](stores.md)).
