# internal-shared-utils: Error Messages

> **Module:** `internal-shared-utils_error-messages`
> **Location:** `packages/svelte/src/internal/shared/errors.js`
> **Parent:** [internal-shared-utils](internal-shared-utils.md) · **Grandparent:** [Server-Side Rendering & Cross-Target Runtime Services](Server-Side_Rendering___Cross-Target_Runtime_Services.md)
> **Core component:** `invalid_default_snippet`

---

## 1. Introduction

This module is the **shared runtime error catalog** of the Svelte compiler/runtime ecosystem. It contains a single source file — `errors.js` — that exports one throwing function per runtime *error code* (e.g. `invalid_default_snippet`, `lifecycle_outside_component`). These functions are the canonical way both the **client runtime** and the **server runtime** abort execution when an unrecoverable invariant is violated at run time (as opposed to compile time, which is covered by the compiler's own diagnostics — see [compiler-core_diagnostics](compiler-core_diagnostics.md)).

The file is **machine-generated** by `scripts/process-messages/index.js` (it begins with a `Do not edit` banner) from the message templates described in [message_code_generation_templates_runtime](message_code_generation_templates_runtime.md). Every exported function follows one strict pattern:

- **DEV builds** (`DEV` flag from `esm-env`): throws an `Error` named `"Svelte error"` whose message contains the error code, a human-readable explanation, and a documentation link `https://svelte.dev/e/<code>`.
- **Production builds**: throws a minimal `Error` containing *only* the documentation URL, so all message strings can be tree-shaken out of the shipped bundle.

The named core component, `invalid_default_snippet`, guards the interaction between legacy `let:` slot directives and snippets: a component that received its default content via `let:` directives cannot also render `{@render children(...)}`.

---

## 2. Error Catalog

`errors.js` currently exports the following error throwers. All are synchronous, take zero or one string argument, are annotated `@returns {never}`, and never return normally.

| Function | Argument | Trigger condition | Docs link |
|---|---|---|---|
| `await_outside_boundary()` | – | `await` (async work) used outside a `<svelte:boundary>` that provides a `pending` snippet | `svelte.dev/e/await_outside_boundary` |
| **`invalid_default_snippet()`** | – | `{@render children(...)}` used while the parent component passes the default slot with `let:` directives | `svelte.dev/e/invalid_default_snippet` |
| `invalid_snippet_arguments()` | – | A snippet function was called directly (with invalid arguments) instead of being instantiated via `{@render ...}` | `svelte.dev/e/invalid_snippet_arguments` |
| `lifecycle_outside_component(name)` | interpolated | A lifecycle function (e.g. `onMount`, `setContext`) was called outside component initialisation | `svelte.dev/e/lifecycle_outside_component` |
| `snippet_without_render_tag()` | – | A snippet was passed as a plain value and stringified instead of rendered with `{@render snippet()}` | `svelte.dev/e/snippet_without_render_tag` |
| `store_invalid_shape(name)` | interpolated | A value used as a store does not expose a `subscribe` method | `svelte.dev/e/store_invalid_shape` |
| `svelte_element_invalid_this_value()` | – | The `this` prop of `<svelte:element>` is defined but not a string | `svelte.dev/e/svelte_element_invalid_this_value` |

Errors that are **client-only** (bindings, ownership, boundary resets, …) live in a separate generated catalog — see [client-dev-tooling_message-catalog](client-dev-tooling_message-catalog.md). Only messages that can be raised from *either* execution target are placed in this shared module, keeping each bundle free of code it can never reach.

---

## 3. Architecture

### 3.1 Position within `internal-shared-utils`

```mermaid
flowchart TB
    subgraph ISR["internal-shared-utils"]
        direction TB
        CU["core-utilities<br/><code>utils.js</code>: noop, run, to_array"]
        VG["validation-guards<br/><code>validate.js</code>: validate_dynamic_element_tag,<br/>validate_void_dynamic_element"]
        EM["<b>error-messages (this module)</b><br/><code>errors.js</code>: invalid_default_snippet, …"]
        SCT["snapshot-conformance-tests<br/><code>clone.test.ts</code>"]
        VG -- "throws via<br/>e.svelte_element_invalid_this_value()" --> EM
        EM -.->|"pure throwers,<br/>no runtime deps"| CU
    end
    ISR --> SSO["Server-Side Rendering &<br/>Cross-Target Runtime Services"]
```

The module is deliberately dependency-free apart from the `DEV` flag from `esm-env`. It does **not** call into [core-utilities](internal-shared-utils_core-utilities.md) or the [validation-guards](internal-shared-utils_validation-guards.md); instead, the dependency points the other way — guards *import* this catalog and invoke the appropriate thrower once a check fails.

### 3.2 Generation pipeline and consumers

```mermaid
flowchart LR
    subgraph SRC["Message sources"]
        DEF["error/warning message<br/>definitions &amp; JSDoc"]
        TPL["templates/shared-errors.js<br/>(CODE template)"]
    end
    GEN["scripts/process-messages/index.js"]
    subgraph CAT["Generated catalogs"]
        SE["internal/shared/errors.js<br/>(this module)"]
        CE["internal/client/errors.js<br/>(client-only)"]
        WE["internal/client/warnings.js &amp;<br/>internal/client/warnings.js (warnings)"]
    end
    subgraph CONS["Consumers (DEV-guarded call sites)"]
        VG2["internal/shared/validate.js<br/>(validation-guards)"]
        CR["internal/client/*<br/>(reactivity, DOM blocks,<br/>snippets, stores, lifecycle)"]
        SR["internal/server/*<br/>(render pipeline, slots,<br/>store integration)"]
    end
    DEF --> GEN
    TPL --> GEN
    GEN -->|"generate"| SE
    GEN -->|"generate"| CE
    GEN -->|"generate"| WE
    SE -->|import| VG2
    SE -->|import| CR
    SE -->|import| SR
```

Because the catalogs are generated from one template per target (`compile-errors.js`, `shared-errors.js`, `client-errors.js`, … — see [message_code_generation_templates](message_code_generation_templates.md)), the throw semantics are identical across compile-time and run-time diagnostics. Compile-time diagnostics complement this module: [compiler-core_diagnostics](compiler-core_diagnostics.md) catches most misuse before code ever ships, while this module covers the invariants that can only be violated at run time.

---

## 4. The Dual-Mode Throw Pattern

Every function is an expansion of the `CODE` template from `templates/shared-errors.js`:

```js
function CODE(PARAMETER) {
	if (DEV) {
		const error = new Error(`${'CODE'}\n${MESSAGE}\nhttps://svelte.dev/e/${'CODE'}`);
		error.name = 'Svelte error';
		throw error;
	} else {
		throw new Error(`https://svelte.dev/e/${'CODE'}`);
	}
}
```

### 4.1 Execution flow

```mermaid
flowchart TD
    A["Runtime code detects<br/>a broken invariant"] --> B{"DEV?<br/>(esm-env)"}
    B -- "true" --> C["new Error(<br/>code + message + doc URL)"]
    C --> D["error.name = 'Svelte error'"]
    D --> E["throw → actionable message,<br/>stack trace, docs link"]
    B -- "false" --> F["new Error('https://svelte.dev/e/&lt;code&gt;')"]
    F --> G["throw → minimal payload,<br/>message strings tree-shaken"]
    E --> H["Caller (or boundary)<br/>handles fatal failure"]
    G --> H
```

### 4.2 Design rationale

| Aspect | Rationale |
|---|---|
| `DEV` runtime branch | Developer builds get full context (code, prose, URL, stack trace); production builds stay lean because the message branches are dead code and eliminated by bundlers. |
| `error.name = 'Svelte error'` | Allows tooling and users to distinguish Svelte invariants from generic JS errors in logs and consoles. |
| `@returns {never}` | Communicates to TypeScript (and readers) that the function never returns, enabling exhaustiveness and control-flow narrowing at call sites. |
| URL-only production message | `https://svelte.dev/e/<code>` resolves to full documentation, so even a tiny production error remains diagnosable. |
| Generated code | Guarantees consistency between the message catalog, the JSDoc, the docs site, and tests; hand-edits would be overwritten (hence the `Do not edit` banner). |

---

## 5. Core Component: `invalid_default_snippet`

```js
/**
 * Cannot use `{@render children(...)}` if the parent component uses `let:` directives.
 * Consider using a named snippet instead
 * @returns {never}
 */
export function invalid_default_snippet() {
	if (DEV) {
		const error = new Error(
			`invalid_default_snippet\nCannot use \`{@render children(...)}\` ... \nhttps://svelte.dev/e/invalid_default_snippet`
		);
		error.name = 'Svelte error';
		throw error;
	} else {
		throw new Error(`https://svelte.dev/e/invalid_default_snippet`);
	}
}
```

### 5.1 What it guards

Svelte supports two mechanisms for passing content into a component:

1. **Snippets** (`{#snippet}` + `{@render}`) — the modern mechanism. The default content arrives as a `children` snippet prop.
2. **Legacy slots with `let:` directives** — the component exposes slot props that the *parent* destructures. In this mode the parent owns the content and the component cannot also render a `children` snippet itself.

If a component's implementation contains `{@render children(...)}` while its invocation uses `let:` directives, the two content models collide. The runtime detects this and calls `invalid_default_snippet()`, which throws immediately with guidance to use a named snippet instead.

### 5.2 Interaction flow

```mermaid
sequenceDiagram
    autonumber
    participant P as Parent component
    participant Comp as Child component
    participant Slot as Slot/snippet machinery<br/>(client or server runtime)
    participant E as shared/errors.js

    P->>Comp: invoke with content
    alt content passed via snippets
        Comp->>Slot: {@render children(...)}
        Slot-->>Comp: renders snippet content
    else content passed via legacy let: directives
        Comp->>Slot: {@render children(...)}
        Note over Slot: children cannot be resolved<br/>alongside let: props
        Slot->>E: invalid_default_snippet()
        E-->>Comp: throws "Svelte error"<br/>(dev: message + docs URL)
    end
```

### 5.3 Related error throwers

`invalid_default_snippet` is part of a family of snippet-integrity guards in the same catalog:

- `invalid_snippet_arguments()` — snippet function invoked outside `{@render}`.
- `snippet_without_render_tag()` — snippet value stringified instead of rendered.
- `await_outside_boundary()` — async rendering requires a `<svelte:boundary>` with a `pending` snippet.

Together these enforce the snippet contract described in the client DOM block documentation ([client-dom-renderer_control-flow-blocks](client-dom-renderer_control-flow-blocks.md)) and its server counterpart ([server-runtime_slots-snippets-and-blocks](server-runtime_slots-snippets-and-blocks.md)).

---

## 6. Data Flow: From Message Definition to Thrown Error

```mermaid
flowchart TD
    A["Developer adds/edits a message<br/>(scripts process-messages sources)"] --> B["Run scripts/process-messages/index.js"]
    B --> C["Template expansion:<br/>code, message, doc URL,<br/>parameter placeholders (%name%)"]
    C --> D["internal/shared/errors.js regenerated<br/>(banner: 'Do not edit')"]
    D --> E["Runtime call sites import<br/>and invoke the thrower on failure"]
    E --> F{"Branch executed?"}
    F -- "DEV" --> G["Rich error: code + prose + URL,<br/>name 'Svelte error'"]
    F -- "production" --> H["Minimal error: URL only<br/>(messages dead-code-eliminated)"]
```

Note that the same generation step also feeds warnings catalogs (e.g. `svelte_boundary_reset_noop` in the client warnings file) — warnings are logged rather than thrown, and are described in [client-dev-tooling_message-catalog](client-dev-tooling_message-catalog.md).

---

## 7. Maintenance Notes

- **Never edit `errors.js` by hand.** Regenerate it via the `process-messages` script after changing message definitions or the shared-error template ([message_code_generation_templates_runtime](message_code_generation_templates_runtime.md)).
- **Adding a new shared error:** add the message definition (code, description, optional `%placeholder%` parameters), add a call site in the appropriate shared guard or runtime module, then regenerate. Follow the existing JSDoc convention — one short sentence, `@param` for placeholders, `@returns {never}`.
- **Choosing the right catalog:** place the error here only if both client and server can raise it; otherwise use the client-only or server-only catalogs to keep bundles minimal.
- **Call-site convention:** guards in [internal-shared-utils_validation-guards](internal-shared-utils_validation-guards.md) import the catalog as a namespace (e.g. `e.svelte_element_invalid_this_value()`) and perform *no* throwing themselves — separation of detection (guards) from reporting (this module).
- **Tests:** conformance/snapshot behavior for shared helpers is covered in [internal-shared-utils_snapshot-conformance-tests](internal-shared-utils_snapshot-conformance-tests.md).

---

## 8. Related Modules

| Module | Relationship |
|---|---|
| [internal-shared-utils_core-utilities](internal-shared-utils_core-utilities.md) | Sibling; generic helpers (`noop`, `run`, `to_array`) used alongside the throwers. |
| [internal-shared-utils_validation-guards](internal-shared-utils_validation-guards.md) | Primary consumer; detection logic that invokes these throwers. |
| [internal-shared-utils_snapshot-conformance-tests](internal-shared-utils_snapshot-conformance-tests.md) | Sibling; snapshot tests for shared helper behavior. |
| [message_code_generation_templates_runtime](message_code_generation_templates_runtime.md) | Owns the `CODE` template from which this file is generated. |
| [client-dev-tooling_message-catalog](client-dev-tooling_message-catalog.md) | Client-only counterpart catalog (bindings, ownership, boundary errors/warnings). |
| [compiler-core_diagnostics](compiler-core_diagnostics.md) | Compile-time diagnostics (errors/warnings raised during parsing/analysis), the static counterpart to this runtime catalog. |
| [client-dom-renderer_control-flow-blocks](client-dom-renderer_control-flow-blocks.md) | Client-side blocks (slots, snippets, boundary) that trigger these errors. |
| [server-runtime_slots-snippets-and-blocks](server-runtime_slots-snippets-and-blocks.md) | Server-side rendering paths that trigger the same shared errors. |
