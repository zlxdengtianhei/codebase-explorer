# Custom Elements Bridge (`client-dom-renderer_custom-elements`)

> **Module file:** `packages/svelte/src/internal/client/dom/elements/custom-element.js`
> **Parent module:** [Client DOM Renderer](client-dom-renderer.md) · **Grandparent:** [Client Runtime Engine (Reactivity & DOM Rendering)](client-reactivity-engine.md)

## 1. Purpose and Scope

This module is the **Web Components bridge** of the Svelte client runtime: it turns a *compiled Svelte component* into a **native custom element** (an `HTMLElement` subclass) that can be used as a regular HTML tag — `<my-widget></my-widget>` — inside any framework or plain HTML page. It is the runtime counterpart of the `<svelte:options customElement="…">` compile option.

The module consists of a single file with one internal export and a set of module-private collaborators:

| Component | Kind | Responsibility |
|---|---|---|
| `create_custom_element(Component, props_definition, slots, exports, use_shadow_dom, extend)` | Internal export | Factory called **only by compiler-generated code**; builds the element class, installs prototype accessors, wires `observedAttributes`, and hands the class to the optional `extend` callback (which the compiler fills with `customElements.define`) |
| `SvelteElement` | Module-private class (extends `HTMLElement`) | All runtime behaviour: lifecycle callbacks (`connectedCallback` / `attributeChangedCallback` / `disconnectedCallback`), event-listener bridging, and the prop↔attribute reflection effect |
| `get_custom_element_value(prop, value, props_definition, transform)` | Module-private helper | Type coercion between DOM attribute strings and JS prop values (`'toProp'` / `'toAttribute'`) |
| `get_custom_elements_slots(element)` | Module-private helper | Scans light-DOM children and returns `{ [slotName]: true }` — which slots actually have content |
| `create_slot(name)` | Local factory (inside `connectedCallback`) | Returns a snippet `(anchor) => …` that renders a `<slot>` element, projecting light-DOM content into the component's slot |

What this module deliberately does **not** do (follow the links instead of duplicating):

- **Mount / hydrate / unmount mechanics** — the element delegates to `createClassComponent`, which calls into the [lifecycle module](client-dom-renderer_lifecycle.md).
- **Own the reactivity machinery** — the reflection effect is just a consumer of [effect primitives](client-reactivity-engine_effects.md); scheduling/batching is described in [client-reactivity-engine_batching-scheduling](client-reactivity-engine_batching-scheduling.md).
- **Attribute reconciliation of *regular* elements or delegated events** — see [client-dom-renderer_attributes-events](client-dom-renderer_attributes-events.md); the event bridging here is specific to the host element ↔ component-instance seam.
- **Compilation of `<svelte:options customElement>`** — that decision is made by the [client transform](compiler-transformer_client-transform.md), which merely *emits a call* to this module.
- **Anything in the public `svelte` package API** — nothing here is re-exported publicly; users reach it only through compiled output (or via the documented `Component.element` static that this module attaches).

## 2. Position in the System

```mermaid
flowchart TB
    subgraph BuildTime["Build time"]
        SRC[".svelte source with<br/>&lt;svelte:options customElement='my-widget' /&gt;"] --> CT["Client transform<br/>(compiler-transformer_client-transform)"]
    end

    subgraph Module["custom-elements (this module)"]
        CCE["create_custom_element"]
        SE["SvelteElement base class"]
        GCEV["get_custom_element_value<br/>attribute ↔ prop coercion"]
        GCES["get_custom_elements_slots"]
        CS["create_slot → &lt;slot&gt; snippet"]
    end

    subgraph Runtime["Browser runtime"]
        LC["legacy-compat:<br/>createClassComponent → Svelte4Component facade"]
        LF["Lifecycle: mount / unmount<br/>(client-dom-renderer_lifecycle)"]
        EFF["effects: effect_root · render_effect<br/>(client-reactivity-engine_effects)"]
        BAT["Batch scheduling<br/>(client-reactivity-engine_batching-scheduling)"]
        DF["DOM foundation: append<br/>(client-dom-renderer_dom-foundation)"]
        SU["internal-shared-utils:<br/>define_property · get_descriptor · object_keys"]
    end

    DOM[("Browser DOM ·<br/>customElements registry")]

    CT -- "Component.element =<br/>$.create_custom_element(…)" --> CCE
    CCE -- "class extends" --> SE
    CCE --> SU
    CCE -- "attach Component.element<br/>+ optional extend(Class)" --> DOM
    SE --> GCEV
    SE --> GCES
    GCES --> CS
    CS -- "append(anchor, &lt;slot&gt;)" --> DF
    SE -- "connectedCallback →" --> LC
    LC --> LF
    LC -. "skips flushSync when $$host present" .-> BAT
    SE -- "reflection effect" --> EFF
    EFF --> BAT
    SE --> DOM
```

Key facts about the integration contract with the compiler (generated code is the *only* intended caller):

- The compiler emits a module-level `Component.element = $.create_custom_element(Component, props_definition, slots, exports, use_shadow_dom, extend)` statement.
- `props_definition` maps each component prop to a `CustomElementPropDefinition`:
  | Field | Meaning |
  |---|---|
  | `attribute` | Attribute name to observe/reflect (defaults to the lowercased prop name) |
  | `reflect` | Mirror prop changes back to the attribute |
  | `type` | `'String' \| 'Boolean' \| 'Number' \| 'Array' \| 'Object'` — drives coercion; derived from type annotations, defaults to identity (`String`) |
- `slots` is the list of slot names the template uses, `exports` the explicitly exported values, and `use_shadow_dom` comes from `<svelte:options shadow="open"|"none">`.
- When a tag name was given, the compiler supplies `extend = (Class) => customElements.define(tag, Class)`, so registration happens as a side effect of `create_custom_element`. Even without it, `Component.element` exposes the class so apps can call `customElements.define` themselves.

## 3. Architecture

### 3.1 The `SvelteElement` base class

The class body is only created when `typeof HTMLElement === 'function'`, so the module can be loaded in non-DOM environments (SSR bundles, tooling) without touching browser globals — though instantiating a wrapper is, by definition, a client-only operation.

All internal state lives in `$$`-prefixed instance fields, mirroring the naming convention of compiled code:

| Field | Type | Role |
|---|---|---|
| `$$ctor` | component function | The compiled Svelte component to instantiate |
| `$$s` | `string[]` | Slot names the component uses |
| `$$c` | instance / `undefined` | The live component instance (a `Svelte4Component` facade), once mounted |
| `$$cn` | `boolean` | Connected flag — drives the deferred connect/disconnect decisions |
| `$$d` | `Record<string, any>` | Buffered props data (source of truth before mount, mirror afterwards) |
| `$$r` | `boolean` | `true` while the reflection effect writes attributes — suppresses `attributeChangedCallback` to break the update loop |
| `$$p_d` | `Record<string, CustomElementPropDefinition>` | Prop definitions (set by the generated subclass constructor) |
| `$$l` / `$$l_u` | listener store / unsubscribe `Map` | Event listeners registered before mount (buffered), and their `$on` unsubscription functions after mount |
| `$$me` | teardown function | Tears down the reflection effect root |

```mermaid
classDiagram
    direction LR
    class HTMLElement {
        <<native>>
    }
    class SvelteElement {
        +$$ctor Any
        +$$s string[]
        +$$c Any
        +$$cn boolean
        +$$d Record
        +$$r boolean
        +$$p_d Record
        +$$l Record
        +$$l_u Map
        +$$me teardownFn
        +constructor(componentCtor, slots, useShadowDom)
        +addEventListener(type, listener, options)
        +removeEventListener(type, listener, options)
        +connectedCallback()
        +attributeChangedCallback(attr, oldValue, newValue)
        +disconnectedCallback()
        -$$g_p(attributeName) string
    }
    class GeneratedElementClass {
        +observedAttributes()$ string[]
        +prop get+set per props_definition
        +exported get-only per exports
    }
    class Svelte4Component {
        +$set(props)
        +$on(event, callback) unsubscribe
        +$destroy()
        +component exports as accessors
    }
    HTMLElement <|-- SvelteElement
    SvelteElement <|-- GeneratedElementClass
    SvelteElement o-- Svelte4Component : $$c — created via createClassComponent()
```

### 3.2 The generated subclass

`create_custom_element` produces a thin subclass per component:

1. **Constructor** passes `Component`, `slots`, `use_shadow_dom` to the base (attaching an *open* shadow root when requested) and installs `$$p_d`.
2. **`static get observedAttributes()`** — every defined prop, mapped to `(attribute || key).toLowerCase()`. Only these attribute names ever trigger `attributeChangedCallback`.
3. **Prototype accessors** for each prop (`Object.defineProperty` via `define_property` from [internal-shared-utils](internal-shared-utils.md)):
   - **get** — reads live from the instance (`this.$$c[prop]`) when mounted, so getter reads always observe component-side updates; falls back to the buffered `$$d[prop]` before mount.
   - **set** — normalizes the value (Boolean truthiness only — JS-side sets are stored raw, no JSON round-trip), writes `$$d`, then pushes to the instance: if the component exposes an own accessor (checked with `get_descriptor(...).get`), it assigns `component[prop] = value` directly; otherwise it calls `component.$set({ [prop]: value })`.
4. **Getter-only accessors** for each name in `exports` — read-through proxies to the instance (`this.$$c?.[property]`), giving elements a public API surface beyond props.
5. If `extend` was supplied, the class is passed through it (that's where `customElements.define` happens), the (possibly replaced) class is stored on `Component.element`, and returned.

### 3.3 Attribute ↔ prop coercion (`get_custom_element_value`)

A Boolean pre-normalization runs first for every call: when `type === 'Boolean'` and the value is not already a boolean, it becomes `value != null` (truthiness, where `''`/`null`/`undefined` → `false`).

| `type` | `'toProp'` (attribute → JS) | `'toAttribute'` (JS → attribute) |
|---|---|---|
| `'String'` / unspecified | value unchanged | value unchanged |
| `'Boolean'` | already normalized above | `''` (attribute present) if truthy, else `null` → attribute removed |
| `'Number'` | `+value` (null-safe) | value unchanged; `null` → attribute removed |
| `'Object'` / `'Array'` | `JSON.parse(value)` | `JSON.stringify(value)`; `null` → attribute removed |
| *(no transform — JS setter path)* | raw value stored as-is | — |

### 3.4 Slot bridging

At upgrade time `get_custom_elements_slots(this)` walks the element's existing `childNodes`; every node without a `slot` attribute counts toward `'default'`, others register their slot name. For each slot name the component actually uses (`$$s`) that has content, a snippet is created with the local `create_slot(name)` factory: the returned function takes an `anchor` (the standard snippet contract — see [client-dom-renderer_control-flow-blocks](client-dom-renderer_control-flow-blocks.md)) and appends a `<slot>` element via the hydration-aware `append` from [client-dom-renderer_dom-foundation](client-dom-renderer_dom-foundation.md). The default slot is delivered through the component's `children` prop (`$$d.children`), with `$$slots.default = true` marking its presence; named slots go into `$$slots[name]`. Because the component renders into `shadowRoot || this`, these `<slot>` elements are what project light-DOM children into the component's rendered output inside a shadow root.

### 3.5 Event bridging

`addEventListener` / `removeEventListener` are overridden to serve two masters: the **DOM** (via `super`) and the **component instance** (via `$on`, once it exists). Listeners added before mount are buffered in `$$l` and replayed onto the instance after it is created; after mount every DOM registration immediately gets a matching `$on` subscription whose unsubscribe function is kept in `$$l_u`. As the code comment states, the runtime cannot know upfront whether a listener targets a browser event or a component-dispatched custom event — so both registrations always happen, and a custom event sharing a name with a native event will be delivered **twice**. This is the seam that lets `createEventDispatcher` events cross the shadow boundary to outside observers.

## 4. Process Flows

### 4.1 Connection (upgrade → mounted component)

```mermaid
sequenceDiagram
    autonumber
    participant B as Browser upgrader
    participant CE as SvelteElement instance
    participant LC as legacy-compat<br/>(createClassComponent)
    participant LF as lifecycle (mount)
    participant EFF as effects (effect_root / render_effect)
    participant C as Component instance

    B->>CE: connectedCallback()
    CE->>CE: $$cn = true
    CE->>CE: await one microtask — let child slot elements be created/mounted
    CE->>CE: guard: still connected ($$cn) and not already mounted ($$c)?
    CE->>CE: get_custom_elements_slots(this) → existing light-DOM slots
    loop each used slot name with content
        CE->>CE: $$slots[name] = create_slot(name) (default → $$d.children)
    end
    loop each attribute
        CE->>CE: $$d[$$g_p(name)] = coerce(value, toProp) — unless already buffered
    end
    loop each pre-init JS prop in $$p_d
        CE->>CE: move this[key] → $$d (raw, no coercion), delete shadowing own property
    end
    CE->>LC: createClassComponent({ component, target: shadowRoot || this,<br/>props: $$d + $$slots + $$host: this })
    LC->>LF: mount(component, { target, props })
    LF-->>CE: instance (exports + $on / $set / $destroy)
    CE->>EFF: $$me = effect_root(() => render_effect(reflect-props))
    loop each buffered listener in $$l
        CE->>C: $on(type, listener) — unsubscribe kept in $$l_u
    end
    CE->>CE: $$l = {}
```

Notes:

- The microtask wait in step 4 plus the `!$$cn || $$c` guard makes connecting idempotent and safe against elements that are removed before their turn.
- Passing `$$host: this` has a side effect in the facade: the initial render is **not** force-flushed with `flushSync` (it is committed through the normal batch instead, and would be required to in async mode) — see the facade's flush logic in [legacy-compat](legacy-compat.md).
- The reflection effect is created once per mount via `effect_root` (a preserved root effect, see [client-reactivity-engine_effects](client-reactivity-engine_effects.md)); `$$me` destroys it on unmount.

### 4.2 Attribute change → prop update

```mermaid
sequenceDiagram
    autonumber
    participant App as App / HTML
    participant CE as element
    participant C as component instance

    App->>CE: setAttribute('my-prop', '42')
    Note over CE: only observedAttributes invoke attributeChangedCallback
    CE->>CE: $$r? → return (reflection in progress)
    CE->>CE: attr = $$g_p(attr) — case-insensitive attribute → prop resolution
    CE->>CE: $$d[attr] = coerce(newValue, toProp)
    CE->>C: $set({ [attr]: value })
    Note over C: update scheduled through the reactivity engine<br/>(client-reactivity-engine_batching-scheduling)
```

`$$g_p` exists because HTML attributes are lowercased by the parser: it finds the prop whose `attribute` matches, or whose lowercased prop name matches, defaulting to the name itself for undefined attributes.

### 4.3 Prop set → attribute reflection

```mermaid
sequenceDiagram
    autonumber
    participant App as App code
    participant CE as element (prototype setter)
    participant D as $$d
    participant C as component instance
    participant RE as reflection render effect

    App->>CE: el.count = 5
    CE->>CE: Boolean normalization only — raw value otherwise
    CE->>D: $$d.count = 5
    CE->>C: own accessor? component.count = 5 : $set({ count: 5 })
    C-->>RE: signal change → render effect re-runs
    RE->>RE: $$r = true (suppress attributeChangedCallback)
    loop each instance key with $$p_d[key].reflect
        RE->>D: $$d[key] = $$c[key]
        RE->>CE: setAttribute(key, coerce(toAttribute)) or removeAttribute when null
    end
    RE->>RE: $$r = false
```

The `$$r` flag is the loop guard: without it, every reflected attribute would immediately re-enter `attributeChangedCallback` and bounce the same value back into the component.

### 4.4 Disconnection / reconnection

```mermaid
sequenceDiagram
    autonumber
    participant B as Browser
    participant CE as element
    participant C as instance

    B->>CE: disconnectedCallback()
    CE->>CE: $$cn = false
    CE->>CE: defer via Promise.resolve().then(…)
    alt still disconnected when the microtask runs
        CE->>C: $destroy() → unmount (client-dom-renderer_lifecycle)
        CE->>CE: $$me() — destroy the reflection effect root
        CE->>CE: $$c = undefined
    else element was re-inserted in the meantime ($$cn true again)
        Note over CE: keep everything mounted — a DOM move is not a teardown
    end
```

The same microtask-deferral pattern on both connect and disconnect means that moving an element within the document (remove + insert inside one task) does not destroy and recreate the component — the deferred disconnect observes `$$cn === true` again and bails out.

## 5. Dependencies

| Dependency | Source module | Used for |
|---|---|---|
| `createClassComponent` | [legacy-compat](legacy-compat.md) (`legacy/legacy-client.js`) | Instantiates the component through the `Svelte4Component` facade, which supplies the `$on` / `$set` / `$destroy` interface the element protocol relies on — the only place the DOM renderer calls into `legacy-compat` |
| `effect_root`, `render_effect` | [client-reactivity-engine_effects](client-reactivity-engine_effects.md) | The reflection effect: a preserved root effect containing a render effect that tracks instance props and rewrites attributes |
| `append` | [client-dom-renderer_dom-foundation](client-dom-renderer_dom-foundation.md) (`dom/template.js`) | Hydration-aware insertion of `<slot>` elements created by `create_slot` |
| `define_property`, `get_descriptor`, `object_keys` | internal-shared-utils (`internal/shared/utils.js`) | Environment-agnostic `Object.*` shims used for prototype accessors and instance introspection |

Runtime data flowing *into* the module comes from compiled code ([compiler-transformer_client-transform](compiler-transformer_client-transform.md)); observable *outputs* are DOM attributes (reflection), `<slot>` elements, dispatched events, and the class exposed as `Component.element`.

## 6. Gotchas & Edge Cases

1. **Client-only.** `SvelteElement` is defined only in DOM environments. Wrappers cannot be server-rendered as elements; SSR output for the wrapped component is produced by the server runtime ([Compiler Pipeline → server transform](compiler-transformer_server-rendering.md)).
2. **Events may fire twice.** Because DOM and component subscriptions are registered in parallel, a component custom event whose name collides with a native event name reaches listeners once per channel.
3. **Everything is lowercased.** `observedAttributes` lowercases attribute names and `$$g_p` resolves case-insensitively — prop names differing only by case cannot coexist as attributes.
4. **Pre-init property writes are buffered, not coerced.** `el.someProp = …` before the element upgrades lands in `$$d` verbatim (only Boolean truthiness normalization applies); at upgrade the shadowing own property is deleted so the prototype accessor takes over.
5. **Reflection is opt-in per prop** (`reflect: true`); unreflected props still update the instance and stay readable through the prototype getter (which reads live from `$$c`), but never appear as attributes.
6. **Attribute values are always strings.** Structural types (`Object` / `Array`) round-trip through JSON; `Number` relies on unary `+`; anything without a `type` annotation behaves as a plain `String`.
7. **`extend` is the last word.** The compiler-provided callback may replace the class entirely (its return value is what gets stored on `Component.element` and returned), which is how `customElements.define` registration is folded into the call.

## 7. Related Modules

| Module | Relationship |
|---|---|
| [Client DOM Renderer](client-dom-renderer.md) | Parent — element-services sub-module alongside attributes/events, bindings, transitions |
| [client-dom-renderer_lifecycle](client-dom-renderer_lifecycle.md) | Provides the actual `mount` / `unmount` reached through the class-component facade |
| [client-dom-renderer_dom-foundation](client-dom-renderer_dom-foundation.md) | `append` used to place `<slot>` elements |
| [client-dom-renderer_attributes-events](client-dom-renderer_attributes-events.md) | Attribute reconciliation / delegated events for *regular* elements; not used by the host-element bridge itself |
| [client-dom-renderer_control-flow-blocks](client-dom-renderer_control-flow-blocks.md) | Defines the snippet contract that `create_slot`-produced functions fulfil |
| [client-reactivity-engine_effects](client-reactivity-engine_effects.md) / [client-reactivity-engine_batching-scheduling](client-reactivity-engine_batching-scheduling.md) | Effect primitives and update scheduling behind prop reflection and `$set` |
| [legacy-compat](legacy-compat.md) | `createClassComponent` / `Svelte4Component` facade |
| [compiler-transformer_client-transform](compiler-transformer_client-transform.md) | Generates the `create_custom_element` call and its arguments |
| [public-api](public-api.md) | The facade internally routes through the same public `mount` / `unmount` entry points documented there |
