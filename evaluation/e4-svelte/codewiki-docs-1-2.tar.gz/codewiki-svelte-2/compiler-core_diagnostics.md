# Compiler Core: Diagnostics Module

## Introduction

The `compiler-core_diagnostics` module implements the **diagnostic subsystem** of the Svelte compiler — the unified machinery for reporting **errors** (fatal, thrown) and **warnings** (non-fatal, collected) to developers. It provides:

- A shared diagnostic object model (`CompileDiagnostic`) that guarantees errors and warnings have an identical, serializable shape (`code`, `message`, `filename`, `start`/`end` locations, and a rendered `frame`).
- Hundreds of generated, individually importable error and warning emitters (`errors.js`, `warnings.js`), each mapped to a stable code and a documentation URL (`https://svelte.dev/e/<code>`).
- The `<!-- svelte-ignore <code> -->` mechanism (parsing, validation, legacy-code migration) that lets authors selectively suppress warnings at any point in a template.

This module is consumed by every compiler phase: the **parser** ([compiler-parser](compiler-parser.md)) throws parse errors and records ignore directives, the **analyzer** ([compiler-analyzer](compiler-analyzer.md)) emits validation warnings, and the **public API** ([compiler-core_public_api](compiler-core_public_api.md)) returns collected warnings inside `CompileResult`.

---

## Module Position in the Compiler Pipeline

```mermaid
flowchart LR
    subgraph Compiler["Svelte Compiler Pipeline"]
        API["compile / compileModule<br/>(compiler-core_public_api)"]
        P["Phase 1: Parse<br/>(compiler-parser)"]
        A["Phase 2: Analyze<br/>(compiler-analyzer)"]
        T["Phase 3: Transform<br/>(compiler-transformer)"]
    end

    subgraph DIAGNOSTICS["compiler-core_diagnostics"]
        ERR["errors.js<br/>throwers"]
        WARN["warnings.js<br/>emitters"]
        IGNORE["extract_svelte_ignore.js"]
        CD["CompileDiagnostic<br/>+ code frames"]
    end

    ST["compile state<br/>(compiler-core_compile_state)<br/>warnings · ignore_stack ·<br/>ignore_map · locator · warning_filter"]

    API -->|state.reset| ST
    P -->|"throw e() on syntax errors"| ERR
    P -->|"<!-- svelte-ignore x -->"| IGNORE
    A -->|"call w() during visits"| WARN
    IGNORE -->|"push_ignore / ignore_map"| ST
    IGNORE -.->|"unknown/legacy code"| WARN
    ERR -->|"new InternalCompileError"| CD
    WARN -->|"new InternalCompileWarning"| CD
    CD -->|"locations + frames"| ST
    WARN -->|"collect into warnings[]"| ST
    ST -->|"CompileResult.warnings"| API
```

Every phase reads the shared [compiler-core_compile_state](compiler-core_compile_state.md) module (mutable module-level state that is reset per compilation), while this module supplies the *reporting behavior* layered on top of it.

---

## Core Components

### 1. `CompileDiagnostic` — the diagnostic object model

**File:** `packages/svelte/src/compiler/utils/compile_diagnostic.js`

The single base class for all diagnostics. Constructed with `(code, message, position)` where `position` is an optional `[start, end]` character-offset pair into the source:

| Property | Source | Description |
|---|---|---|
| `code` | argument | Stable snake_case identifier, e.g. `css_unused_selector` |
| `message` | argument | Human-readable description with parameter interpolation |
| `filename` | `state.filename` | Omitted (`undefined`) when the filename is unknown (`state.UNKNOWN_FILENAME`) |
| `position` | argument | Raw `[start, end]` character offsets (end defaults to start) |
| `start` / `end` | `state.locator(...)` | Resolved `{ line, column }` locations via `locate-character` |
| `frame` | `get_code_frame(...)` | Rendered source excerpt with a `^` caret under the offending span |

**Serialization contract** (the public `Warning` shape in [compiler-core_type_definitions](compiler-core_type_definitions.md)):

- `toString()` → `"CODE: message\nfilename:line:column\n<code frame>"` — used when a `CompileError` is printed or stringified.
- `toJSON()` → plain object `{ code, message, filename, start, end, position, frame }` — used by bundler plugins and test snapshots.

### 2. Code-frame rendering — `get_code_frame`

**File:** `packages/svelte/src/compiler/utils/compile_diagnostic.js`

Produces the familiar compiler output window:

- Shows up to **2 lines before** and **3 lines after** the diagnostic line.
- Line numbers are right-padded to a common width; the caret column is computed after converting tabs to spaces (`tabs_to_spaces`), so mixed indentation renders correctly.
- Example output for a mid-file warning:

```
12:   <div class="widget">
13:     <span>{title}</span>
14:     <p class=foo>text</p>
          ^
15:   </div>
16: </div>
```

The frame is computed lazily inside the `CompileDiagnostic` constructor — only when both `start` and `end` locations resolve — so diagnostics outside the source range degrade gracefully to position-less diagnostics.

### 3. Error emission — `errors.js`

**File:** `packages/svelte/src/compiler/errors.js` *(generated — do not edit)*

Exports one throwing function per compiler error code. Each function:

1. Accepts a `null | number | NodeLike` position argument (`{ start?, end? }` — AST nodes qualify), plus interpolation parameters.
2. Delegates to the internal `e()` helper, which extracts `[start, end]` offsets (number form is used as a single offset) and **throws** an `InternalCompileError` — return type is typed `never`.

Representative core components:

| Component | Code | Trigger |
|---|---|---|
| `block_unclosed(node)` | `block_unclosed` | Parser reaches EOF with an open `{#if}`, `{#each}`, `{#snippet}`, … |
| `css_global_block_invalid_combinator(node, name)` | `css_global_block_invalid_combinator` | `:global` selector used after a combinator such as `>` in CSS analysis |
| `typescript_invalid_feature(node, feature)` | `typescript_invalid_feature` | TS-only syntax (enums, decorators…) found outside `<script>` or without a preprocessor |

**`InternalCompileError` design notes:**

- Extends the native `Error` so bundler plugins and `try/catch`-based toolchains treat it like any thrown error; `name` is set to `'CompileError'`.
- `stack` is blanked ("avoid unnecessary noise") — location information lives on the diagnostic itself.
- Instead of a parallel class hierarchy, it composes an internal `CompileDiagnostic` instance and `Object.assign`s its properties onto itself. This keeps **error and warning objects structurally identical** (same enumerable properties), simplifying downstream tooling and JSON transports.
- `toString()` / `toJSON()` delegate to the diagnostic, so `error.message` (native) and `error.toString()` (diagnostic, with frame) are both useful.

### 4. Warning emission — `warnings.js`

**File:** `packages/svelte/src/compiler/warnings.js` *(generated — do not edit)*

Exports one emitter per warning code plus an alphabetical `codes` array (used for validating `svelte-ignore` inputs). `InternalCompileWarning` **directly extends** `CompileDiagnostic` with `name = 'CompileWarning'`.

Representative core components:

| Component | Code | Trigger |
|---|---|---|
| `a11y_incorrect_aria_attribute_type_id(node, attribute)` | `a11y_incorrect_aria_attribute_type_id` | e.g. `aria-labelledby` value is not a DOM-element-ID string |
| `css_unused_selector(node, name)` | `css_unused_selector` | CSS analyzer proves a selector matches nothing in the template |

**The `w()` collection pipeline** — every emitter calls `w(node, code, message)`:

1. **Resolve suppression stack:** `stack = ignore_map.get(node) ?? ignore_stack`. The per-node map exists because some warnings are emitted *after* the ignore stack frame for that node has already been popped during analysis.
2. **Suppress:** if the top frame of the stack contains this `code`, the warning is discarded silently.
3. **Construct** an `InternalCompileWarning` with `[node.start, node.end ?? node.start]`.
4. **User filter:** apply `state.warning_filter` (from the `warningFilter` compile option) — returning `false` drops the warning. This is how toolchains like `svelte-check` implement custom severity rules.
5. **Collect:** append to `state.warnings`, which the entry point copies into `CompileResult.warnings`.

Unlike errors, warnings **never interrupt compilation** — a file with warnings still compiles successfully.

### 5. `svelte-ignore` handling — `extract_svelte_ignore.js`

**File:** `packages/svelte/src/compiler/utils/extract_svelte_ignore.js`

Handles HTML comments of the form `<!-- svelte-ignore code-a, code-b -->` which the parser encounters while reading comments. Two public functions:

#### `extract_svelte_ignore(offset, text, runes)` → `string[]`

Called during parsing; returns the codes that should be pushed onto the ignore stack (the caller invokes [compiler-core_compile_state](compiler-core_compile_state.md)'s `push_ignore` / records `ignore_map` entries). Behavior differs by mode:

| Aspect | Runes mode (`runes: true`) | Legacy mode |
|---|---|---|
| Syntax | Comma-separated codes; everything after the first non-comma token is treated as prose | Lax: every word-like token is a code |
| Unknown codes | `w.legacy_code` if a mapping exists (e.g. `unused-export-let` → `export_let_unused`), else `w.unknown_code` with a **fuzzy-matched suggestion** (`did you mean 'a11y_unknown_role'?`) | Silently accepted; unmapped codes are additionally translated (`-` → `_`) so both spellings suppress |
| Purpose | Strict validation, catches typos | Backwards compatibility |

The kebab-case → snake_case `replacements` map covers legacy Svelte 4 codes (`non-top-level-reactive-declaration`, `empty-block`, `a11y-structure`, …), enabling incremental migration without breaking existing comments.

Valid inputs for suppression are: all codes from `warnings.codes` **plus** `IGNORABLE_RUNTIME_WARNINGS` (from `src/constants.js` — runtime warnings such as `hydration_attribute_changed` or `ownership_invalid_mutation` that are validated at compile time but fired at runtime via `state.is_ignored`).

#### `migrate_svelte_ignore(text)` → `string`

A pure string transformer used by the **codemod CLI** ([compiler-migrator](compiler-migrator.md)) during `svelte-shift`-style migration: it rewrites `<!-- svelte-ignore kebab-codes -->` comments to the comma-separated snake_case runes-mode format, inserting commas between consecutive codes.

Supporting utilities:

- `get_entity_pattern` / comment scanning happens in the parser; see [compiler-parser](compiler-parser.md).
- `fuzzymatch` (with its internal `sort_descending` ranking) provides "did you mean" suggestions using bigram/trigram cosine similarity + Levenshtein distance, thresholded at `0.7`.

---

## Class & Relationship Architecture

```mermaid
classDiagram
    class CompileDiagnostic {
        +name = 'CompileDiagnostic'
        +code: string
        +message: string
        +filename?: string
        +start?: Location
        +end?: Location
        +position?: [number, number]
        +frame?: string
        +toString() string
        +toJSON() object
    }

    class InternalCompileWarning {
        +name = 'CompileWarning'
    }

    class InternalCompileError {
        -#diagnostic: CompileDiagnostic
        +name = 'CompileError'
        +toString() string
        +toJSON() object
    }

    class Error_native {
        <<JavaScript Error>>
    }

    class errors_js {
        <<generated module>>
        +block_unclosed(node)
        +css_global_block_invalid_combinator(node, name)
        +typescript_invalid_feature(node, feature)
        +e(node, code, message)$ never
    }

    class warnings_js {
        <<generated module>>
        +codes: string[]
        +a11y_incorrect_aria_attribute_type_id(node, attr)
        +css_unused_selector(node, name)
        +w(node, code, message)$
    }

    class extract_svelte_ignore_js {
        +extract_svelte_ignore(offset, text, runes) string[]
        +migrate_svelte_ignore(text) string
        +replacements: Record~string,string~
    }

    class state_js {
        <<compiler-core_compile_state>>
        +warnings: Warning[]
        +ignore_stack: Set~string~[]
        +ignore_map: Map
        +warning_filter
        +locator
        +source, filename
    }

    Error_native <|-- InternalCompileError : extends
    CompileDiagnostic <|-- InternalCompileWarning : extends
    InternalCompileError o-- CompileDiagnostic : Object.assign(properties)
    errors_js ..> InternalCompileError : throws
    warnings_js ..> InternalCompileWarning : creates
    warnings_js --> state_js : suppress-check + collect
    CompileDiagnostic --> state_js : filename/source/locator
    extract_svelte_ignore_js --> warnings_js : legacy_code / unknown_code
    extract_svelte_ignore_js --> state_js : codes validated against
```

**Key insight:** warnings use *inheritance* from `CompileDiagnostic`, while errors use *composition* (to inherit from native `Error`). Both flatten to the same property shape, so downstream code handles them uniformly.

---

## Diagnostic Lifecycle — Data Flow

### Warning flow (non-fatal)

```mermaid
sequenceDiagram
    participant An as Analyzer visitor
    participant W as warnings.js w()
    participant St as compiler state
    participant Diag as InternalCompileWarning
    participant User as Tooling (vite-plugin, svelte-check)

    An->>W: css_unused_selector(node, selector)
    W->>St: ignore_map.get(node) ?? ignore_stack
    alt code suppressed via svelte-ignore
        W-->>An: return (dropped)
    else not suppressed
        W->>Diag: new(code, message, [start, end])
        Diag->>St: locator(start/end) → line:col
        Diag->>St: get_code_frame(source, line, col)
        W->>St: warning_filter(warning)
        alt filter returns false
            W-->>An: return (dropped)
        else filter passes
            W->>St: warnings.push(warning)
        end
    end
    Note over St: compilation continues normally
    User->>St: CompileResult.warnings → report/annotate
```

### Error flow (fatal)

```mermaid
sequenceDiagram
    participant Phase as Parse/Analyze phase
    participant E as errors.js e()
    participant Err as InternalCompileError
    participant Diag as CompileDiagnostic
    participant Bundler as Bundler / build tool

    Phase->>E: block_unclosed(node)
    E->>Err: new(code, message, [start, end])
    Err->>Diag: new CompileDiagnostic(...)
    Diag->>Diag: resolve locations, build frame
    Err->>Err: Object.assign(diagnostic props), stack = ''
    E-->>Phase: throw (never returns)
    Phase--xBundler: compilation aborted
    Bundler->>Bundler: catch → error.frame / error.toJSON()
```

### `svelte-ignore` flow

```mermaid
flowchart TD
    A["Parser reads HTML comment<br/>inside element/block scope"] --> B{"matches /svelte-ignore\\s/?"}
    B -- no --> Z["no effect"]
    B -- yes --> C{"runes mode?"}
    C -- yes --> D["Parse comma-separated codes strictly"]
    D --> E{"code known?"}
    E -- yes --> F["add to ignores[]"]
    E -- "legacy (in replacements map)" --> G["add translation + w.legacy_code warning"]
    E -- unknown --> H["w.unknown_code + fuzzymatch suggestion"]
    C -- legacy --> I["Lax parse: every token is a code<br/>unmapped codes auto-translated (- → _)"]
    I --> F
    F --> J["Caller: state.push_ignore(ignores)<br/>+ ignore_map.set(node, ...)"]
    J --> K["Warnings emitted for nodes in scope<br/>are checked against the stack"]
```

The stack is hierarchical: `push_ignore` merges the new codes with the top frame, so ignores **accumulate inward** across nested blocks; `pop_ignore` restores the outer scope when the parser leaves the block. See [compiler-core_compile_state](compiler-core_compile_state.md) for `push_ignore`/`pop_ignore` and `is_ignored` (runtime variant).

---

## Message Code Generation Pipeline

`errors.js` and `warnings.js` are **build artifacts**. Human-edited message definitions live in `messages/` and are compiled by `scripts/process-messages/index.js` using templates in [message_code_generation_templates](message_code_generation_templates.md):

```mermaid
flowchart LR
    subgraph Sources["Hand-written sources"]
        M1["messages/compile-errors/*.md<br/>(code, message, params)"]
        M2["messages/compile-warnings/*.md"]
        M3["messages/client-errors / client-warnings<br/>server-errors / shared-errors<br/>shared-warnings"]
    end

    subgraph Templates["scripts/process-messages/templates"]
        T1["compile-errors.js → e() thrower"]
        T2["compile-warnings.js → w() emitter"]
        T3["client/server/shared templates"]
    end

    subgraph Generated["Generated (do not edit)"]
        G1["src/compiler/errors.js"]
        G2["src/compiler/warnings.js"]
        G3["src/internal/client/errors.js · warnings.js<br/>src/internal/server/errors.js …"]
    end

    M1 --> T1 --> G1
    M2 --> T2 --> G2
    M3 --> T3 --> G3
    G1 & G2 --> D["compiler-core_diagnostics"]
```

The compile-scoped templates render as:

```js
// compile-errors template    → errors.js artifacts
function CODE(node, PARAMETER) {
    e(node, 'CODE', `${MESSAGE}\nhttps://svelte.dev/e/${'CODE'}`);
}

// compile-warnings template   → warnings.js artifacts
function CODE(node, PARAMETER) {
    w(node, 'CODE', `${MESSAGE}\nhttps://svelte.dev/e/${'CODE'}`);
}
```

Runtime-side diagnostics (`client-errors`, `shared-warnings`, …) follow the same pattern but target the internal client/server modules — see [Client_Runtime_Engine___Reactivity___DOM_Rendering](Client_Runtime_Engine___Reactivity___DOM_Rendering.md) and [Server-Side_Rendering___Cross-Target_Runtime_Services](Server-Side_Rendering___Cross-Target_Runtime_Services.md). Adding a new compiler diagnostic therefore means: **edit the message definition, run the generator — never edit `errors.js`/`warnings.js` directly.**

---

## Diagnostic Code Conventions

1. **Naming:** `snake_case`, usually prefixed by domain — `css_*`, `a11y_*`, `options_*`, `block_*`, `rune_*`, `svelte_options_*`.
2. **Stability:** codes are public API. They appear in `warningFilter` callbacks, test snapshots, and `svelte-ignore` comments; removing one requires a legacy mapping in `extract_svelte_ignore.js`'s `replacements`.
3. **Documentation links:** every message ends with `https://svelte.dev/e/<code>`, which serves both errors and warnings (the docs use a unified code namespace — note the shared `codes` array literally includes `'unknown_code'` handling for both).
4. **Parameterization:** emitters take typed interpolation parameters (`name`, `feature`, `attribute`, `cycle`, …) so messages stay consistent and translatable.
5. **Legacy aliases:** kebab-case Svelte 4 codes (e.g. `unused-export-let`) map to snake_case codes (`export_let_unused`) at the suppression boundary, so old comments keep working in legacy mode and emit actionable `legacy_code` warnings in runes mode.

---

## Integration Map

| Concern | Where handled | Related module |
|---|---|---|
| Per-compilation state reset (`warnings`, `locator`, `warning_filter`) | `state.reset()` in entry points | [compiler-core_compile_state](compiler-core_compile_state.md) |
| Throwing syntax errors while reading the template | parser state machines (`element`, `fragment`, `text`) | [compiler-parser](compiler-parser.md) |
| Semantic warnings during AST analysis | visitor implementations calling `w.*` | [compiler-analyzer](compiler-analyzer.md) |
| CSS-specific errors (`css_global_block_*`) & `css_unused_selector` | `css-analyze.js` + selector usage analysis | [compiler-analyzer](compiler-analyzer.md) |
| Options validation errors/warnings (`options_invalid_value`, `options_removed_*`) | `validate-options.js` before any parsing | [compiler-core_options_validation](compiler-core_options_validation.md) |
| Returning `warnings` to callers / `CompileError` in public types | `compile()`, `CompileResult`, `CompileError` | [compiler-core_public_api](compiler-core_public_api.md), [compiler-core_type_definitions](compiler-core_type_definitions.md) |
| Rewriting ignore comments during Svelte 4 → 5 migration | `migrate()` calls `migrate_svelte_ignore` | [compiler-migrator](compiler-migrator.md) |
| Preprocessor-triggered errors (e.g. `typescript_invalid_feature` guidance) | guidance embedded in error message text | [compiler-preprocessor](compiler-preprocessor.md) |

---

## Developer Guidelines

**Reporting a new diagnostic**

1. Add a message definition under `messages/compile-errors/` or `messages/compile-warnings/` (see [message_code_generation_templates](message_code_generation_templates.md)).
2. Run the message processor to regenerate `errors.js` / `warnings.js`.
3. Call the generated function from the appropriate phase visitor or parser state.
4. If a legacy spelling exists, add an entry to `replacements` in `extract_svelte_ignore.js` and, when the new warning must be suppressible at runtime instead, consider adding it to `IGNORABLE_RUNTIME_WARNINGS`.

**Positional arguments:** accept the widest useful type — `null` (position-less), a `number` offset, or any `NodeLike` (`{ start?, end? }`, satisfied by AST nodes). Ending offsets default to the start offset.

**Never:**
- mutate `state.warnings` directly (always go through `w()` so filtering/suppression applies);
- throw plain `Error`s from compiler phases (breaks the structured-diagnostic contract);
- edit the generated `errors.js` / `warnings.js` by hand.

**Testing:** `CompileDiagnostic.toJSON()` is snapshot-friendly and stable; prefer asserting on the JSON shape rather than `toString()` output when frames/paths may vary across environments.
