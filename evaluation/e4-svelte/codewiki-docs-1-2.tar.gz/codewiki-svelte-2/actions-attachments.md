# Actions & Attachments (`svelte/action`, `svelte/attachments`)

## 1. Purpose & Scope

The **actions-attachments** module is the public API layer for Svelte's two element-level DOM extension mechanisms — small user-supplied functions that attach custom behavior (tooltips, drag-and-drop, focus management, third-party widget wiring, …) directly to rendered elements:

| Mechanism | Template syntax | Entry point | Since |
|---|---|---|---|
| **Actions** | `<div use:myAction={param}>` | `svelte/action` (types only) | legacy (Svelte 1+) |
| **Attachments** | `<div {@attach myAttachment}>` | `svelte/attachments` | Svelte **5.29** |

The module contains two small source files:

- [`packages/svelte/src/action/public.d.ts`](actions-attachments_action-contract.md) — the TypeScript contract (`Action`, `ActionReturn`) used by app authors and library authors to *type* actions.
- [`packages/svelte/src/attachments/index.js`](actions-attachments_attachment-bridge.md) — the runtime helpers `createAttachmentKey()` and `fromAction()` that make attachments usable programmatically and make legacy actions usable as attachments.

Everything else involved in executing actions/attachments lives in *other* modules and is linked to rather than duplicated here:

- **Runtime executors** `$.action()` / `$.attach()` → see [`client-dom-renderer_attributes-events.md`](client-dom-renderer_attributes-events.md)
- **Compiler visitors** `UseDirective` / `AttachTag` → see [`compiler-transformer_client-transform_directive-visitors.md`](compiler-transformer_client-transform_directive-visitors.md)
- **Reactivity primitives** (`render_effect`, `teardown`, `untrack`) → see [`client-reactivity-engine_effects.md`](client-reactivity-engine_effects.md)
- **Public type re-exports** (`Attachment` in `packages/svelte/types/index.d.ts`) → see [`svelte-public-types.md`](svelte-public-types.md)

---

## 2. Architecture Overview

The module is the *contract + bridge* layer that sits between user code (template directives, library prop spreads) and the Svelte 5 client reactivity engine.

```mermaid
flowchart TD
    subgraph UserCode["User / library code"]
        TPL["Template:<br/>use:action={param}<br/>{@attach fn}"]
        SPREAD["Props spread:<br/>{...props} where props[createAttachmentKey()] = fn"]
        LIB["Library exports a typed Action"]
    end

    subgraph Module["actions-attachments (this module)"]
        TYPES["action/public.d.ts<br/>Action · ActionReturn"]
        KEY["createAttachmentKey()<br/>Symbol('@attach')"]
        FA["fromAction(action, () => arg)<br/>Action → Attachment adapter"]
    end

    subgraph CompilerXform["compiler-transformer"]
        UD["UseDirective visitor"]
        AT["AttachTag visitor<br/>→ $.attach(node, thunk(expr))"]
    end

    subgraph Runtime["client-dom-renderer"]
        AE["attribute_effect()"]
        ATTACHFN["$.attach(node, get_fn)<br/>dom/elements/attachments.js"]
        ACTIONFN["$.action(dom, action, get_value)<br/>dom/elements/actions.js"]
    end

    subgraph Reactivity["client-reactivity-engine"]
        EFF["effect / render_effect /<br/>branch / block / teardown / untrack"]
    end

    TPL --> UD --> ACTIONFN
    TPL --> AT --> ATTACHFN
    LIB -. "typed against" .-> TYPES
    SPREAD --> KEY
    SPREAD --> AE
    FA --> TPL

    KEY --> AE
    AE -->|"symbol.description === '@attach'"| ATTACHFN
    FA -. "returns Attachment" .-> AT

    ACTIONFN --> EFF
    ATTACHFN --> EFF
    FA --> EFF
```

**Key idea:** an *attachment* is simply a function `(element) => void | (() => void)`. The runtime wraps it in an **effect**, so anything reactive it reads re-runs it automatically — that is what distinguishes it from an *action*, which runs **once** (untracked) when the element is created and only re-runs its optional `update` hook when its parameter changes.

---

## 3. Sub-modules

| Sub-module | File(s) | Contents | Documentation |
|---|---|---|---|
| **Action type contract** | `src/action/public.d.ts` | `Action` and `ActionReturn` interfaces: the typing rules for `use:` directive functions, including the `Attributes` generic for type-safe events/properties | [actions-attachments_action-contract.md](actions-attachments_action-contract.md) |
| **Attachment bridge utilities** | `src/attachments/index.js` | `createAttachmentKey()` (programmatic `@attach` via prop spread) and `fromAction()` (wraps a legacy action into a reactive attachment) | [actions-attachments_attachment-bridge.md](actions-attachments_attachment-bridge.md) |

---

## 4. Actions vs. Attachments — Semantics Comparison

| Aspect | Action (`use:`) | Attachment (`@attach`) |
|---|---|---|
| Invocation | Once, when the element is created (inside an effect, but `untrack`ed) | Inside an effect owned by the element's branch |
| Reactivity | Only `update(param)` re-runs, and only when the whole parameter is `safe_not_equal` | The entire function body re-runs whenever **any** reactive value it reads changes |
| Argument | Direct value (`use:foo={bar}`) | Function/thunk producing the value; attachment reads state itself |
| Return value | `{ update?, destroy? }` object (`ActionReturn`) | Optional teardown function `() => void` |
| Programmatic usage | Not supported via spread | `createAttachmentKey()` symbol key in a spread object |
| Re-run on identity change | Re-created only when element re-creates | `$.attach` destroys the old effect branch and creates a new one whenever the attachment *function identity* changes |
| Typing | `Action<Element, Parameter, Attributes>` | `Attachment<Element>` — see `svelte-public-types` |

### `fromAction` compatibility mapping

`fromAction()` is the official bridge between the two models:

```mermaid
flowchart LR
    subgraph OldModel["Action semantics"]
        A["action(element, arg)"] -->|"untrack"| R1["{update, destroy}"]
        R1 -->|"render_effect + safe update"| U["update(arg) on change"]
        R1 -->|"teardown"| D["destroy() on unmount"]
    end
    subgraph NewModel["Attachment semantics"]
        W["fromAction wrapper(element)"] --> A
    end
```

Behavior notes (important for migration):

- The action call itself is wrapped in `untrack`, mirroring `$.action` — creating an element does not subscribe to state.
- `update` is driven by a `render_effect` reading the argument thunk `fn`; it is skipped on the first run (`ran` flag) because the action was already invoked with that value.
- `destroy` is registered through `teardown(fn)`, i.e. attached as the teardown of a clean `RENDER_EFFECT`, so it fires when the owning effect graph is destroyed.
- The second argument must be a **function returning** the argument (`() => bar`), not the value itself — this is what allows the update path to stay reactive.

---

## 5. Runtime Integration (delegated)

### 5.1 Directive compilation & execution

The compiler (`compiler-transformer`) lowers template directives to runtime calls:

```mermaid
sequenceDiagram
    participant T as Template author
    participant C as Compiler (AttachTag / UseDirective)
    participant R as Runtime $.attach / $.action
    participant E as Effect graph

    T->>C: <div {@attach fn}> / <div use:fn={x}>
    C->>R: $.attach(node, thunk) / $.action(node, fn, get_value)
    R->>E: create branch + effect
    E->>E: run fn(node) (attachments) or<br/>action(node, value) (actions)
    Note over E: re-runs on dependency change<br/>(attachments: whole fn;<br/>actions: update hook only)
```

- `$.attach(node, get_fn)` uses `block`/`branch`/`effect` (with a TODO to simplify when legacy mode is removed — see PR #15962). If the attachment function identity changes, the previous branch's effects are destroyed first.
- `$.action(dom, action, get_value)` runs the action untracked, re-runs `update` from a `render_effect` (after a `deep_read_state` so `$state` mutations are detected), and returns a teardown that calls `destroy`.

Both executors are documented in detail in [`client-dom-renderer_attributes-events.md`](client-dom-renderer_attributes-events.md).

### 5.2 Programmatic spread (`createAttachmentKey`)

`createAttachmentKey()` returns `Symbol(ATTACHMENT_KEY)` where `ATTACHMENT_KEY = '@attach'` (`src/constants.js`). The attribute spread machinery in the client renderer iterates `Object.getOwnPropertySymbols(next)` and, when a symbol's **description** equals `'@attach'`, routes the value through `$.attach` inside its own branch:

```mermaid
flowchart LR
    P["props = { class: 'cool',<br/>[createAttachmentKey()]: node => {...} }"] --> SP["spread onto element<br/>attribute_effect → set_attributes"]
    SP -->|"own symbol with description '@attach'"| BR["branch → attach(element, () => n)"]
    BR --> EFF["effect(() => n(element))"]
```

This is why the runtime compares `symbol.description === ATTACHMENT_KEY` rather than symbol identity: the key is created per-call by library code, so only the description (`'@attach'`) can be used as the shared contract.

---

## 6. How this module fits into the wider system

```mermaid
flowchart TD
    PUB["Public API & Built-in Feature Surface<br/>(public-api module)"] --> AA["actions-attachments<br/>(this module)"]
    AA -->|"Action types re-exported"| PT["svelte-public-types"]
    AA -->|"executed by"| CDR["client-dom-renderer<br/>($.action / $.attach)"]
    AA -->|"built on"| CRE["client-reactivity-engine<br/>(effects, untrack, teardown)"]
    CTR["compiler-transformer"] -->|"compiles use: / @attach"| CDR
    AA -.->|"AttachTag output: $.attach"| CTR
```

- It depends on nothing above it — only on internal client reactivity primitives.
- It is consumed by end-user components and UI libraries; the `Attachment`/`Action` types are re-exported through `packages/svelte/types/index.d.ts` (`svelte-public-types`).
- SSR has **no** counterpart: actions and attachments are client-only constructs (nothing in `internal/server` executes them).

---

## 7. Public API summary

```ts
// svelte/action (types only)
interface ActionReturn<Parameter, Attributes> {
  update?: (parameter: Parameter) => void;
  destroy?: () => void;
}
interface Action<Element, Parameter, Attributes> {
  (node: Element, parameter?: Parameter): void | ActionReturn<Parameter, Attributes>;
}

// svelte/attachments (runtime, since 5.29 / 5.32)
function createAttachmentKey(): symbol;                    // since 5.29
function fromAction<E, T>(action: Action<E, T>, fn?: () => T): Attachment<E>; // since 5.32
```

For deeper detail on each piece, see the sub-module pages listed in section 3.

## 8. Generated documentation index

All pages of this module's documentation (flat folder, wiki-wide unique names):

- [actions-attachments.md](actions-attachments.md) — this overview page
- [actions-attachments_action-contract.md](actions-attachments_action-contract.md) — `Action` / `ActionReturn` typing contract (`src/action/public.d.ts`)
- [actions-attachments_attachment-bridge.md](actions-attachments_attachment-bridge.md) — `createAttachmentKey()` and `fromAction()` runtime bridge (`src/attachments/index.js`)

Related pages from other modules (do not duplicate content, always link):

- [client-dom-renderer_attributes-events.md](client-dom-renderer_attributes-events.md) — `$.action` / `$.attach` executors and spread recognition
- [client-reactivity-engine_effects.md](client-reactivity-engine_effects.md) — `effect`, `render_effect`, `teardown`, `block`/`branch` primitives
- [compiler-transformer_client-transform_directive-visitors.md](compiler-transformer_client-transform_directive-visitors.md) — `UseDirective` / `AttachTag` visitors
- [svelte-public-types.md](svelte-public-types.md) — aggregated public type re-exports (incl. `Attachment`)
