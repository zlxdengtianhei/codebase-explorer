# internal-shared-utils / validation-guards

> **Module scope:** `packages/svelte/src/internal/shared/validate.js` — `validate_dynamic_element_tag`, `validate_void_dynamic_element`
> **System area:** Server-Side Rendering & Cross-Target Runtime Services → [internal-shared-utils](internal-shared-utils.md)

## 1. Introduction

The **validation-guards** module implements the runtime counterparts of `<svelte:element>`'s static guarantees. Svelte's dynamic element tag (`<svelte:element this={...}>`) defers the element identity to a runtime expression, which means the compiler *cannot* fully verify two things at build time:

1. that the resolved `this` value is actually a tag string, and
2. that a void element (which cannot contain children) is not being given children.

These two functions are the **dev-mode runtime guards** that close that gap. They are injected into generated client and server output by the compiler's `SvelteElement` transform visitors and never execute in production builds, making misuse cheap to catch during development and free at runtime in production.

| Guard | Failure mode | Trigger condition |
|---|---|---|
| `validate_dynamic_element_tag` | **Throws** `svelte_element_invalid_this_value` | `this` is truthy but not a `string` |
| `validate_void_dynamic_element` | **Warns** `dynamic_void_element_content` | tag resolves to an HTML void element while children exist |

---

## 2. Design Principles

The guards follow four deliberate conventions shared across Svelte's internal runtime:

### 2.1 Dev-only cost, zero prod cost
The compiler emits calls to these functions **only inside `if (dev)` branches** (see §4.2). In production bundles the calls are eliminated entirely — no dead branches, no thunk allocations, no runtime overhead.

### 2.2 Thunk-based (lazy) evaluation
Both guards accept a **getter function** (`() => string`) rather than a value:

- The tag expression may be a reactive signal read or an arbitrary expression; wrapping it in a thunk defers evaluation to exactly the moment the guard runs.
- Each guard calls `tag_fn()` **exactly once**, ensuring side-effectful `this` expressions (e.g. `this={computeTag()}`) do not execute multiple times.
- On the server side, the transform visitor additionally memoizes the tag in a local `const` before building thunks, so a getter is never re-invoked just for validation.

### 2.3 One implementation, two targets
The identical functions serve the client runtime and the SSR runtime. Compiled client code and compiled server code both call the same `$.validate_*` names from `internal/shared`, keeping behavior consistent between hydration and server rendering.

### 2.4 Error vs. warning semantics
The two conditions have different severities on purpose:

- A non-string `this` would produce a fundamentally broken DOM (`document.createElement(<object>)` is invalid) → **hard error**.
- Children of a void element are simply discarded by the DOM/serializer — the app still runs, but the markup is silently lost → **console warning** so the developer notices without the app crashing.

---

## 3. API Reference

### 3.1 `validate_dynamic_element_tag(tag_fn)`

```js
/** @param {() => unknown} tag_fn */
export function validate_dynamic_element_tag(tag_fn) {
	const tag = tag_fn();
	const is_string = typeof tag === 'string';
	if (tag && !is_string) {
		e.svelte_element_invalid_this_value();
	}
}
```

| Aspect | Behavior |
|---|---|
| Evaluation | Calls `tag_fn()` once |
| Pass | `tag` is falsy (`null` / `undefined` / `''` — element is not rendered) or a `string` |
| Fail | Throws `svelte_element_invalid_this_value`: *"The `this` prop on `<svelte:element>` must be a string, if defined"* |

Note the asymmetry: an **empty string** is tolerated (treated like "no element"), but any **truthy non-string** is rejected.

### 3.2 `validate_void_dynamic_element(tag_fn)`

```js
/** @param {() => string} tag_fn */
export function validate_void_dynamic_element(tag_fn) {
	const tag = tag_fn();
	if (tag && is_void(tag)) {
		w.dynamic_void_element_content(tag);
	}
}
```

| Aspect | Behavior |
|---|---|
| Evaluation | Calls `tag_fn()` once |
| Pass | `tag` is falsy, or not a void element |
| Fail | Emits `dynamic_void_element_content` warning: *"`<svelte:element this="…">` is a void element — it cannot have content"* |
| Void check | Delegates to `is_void` (`src/utils.js`), which matches the standard HTML void element names (`br`, `img`, `input`, `hr`, `meta`, …) plus the `!doctype` special case |

The offending tag name is interpolated into the warning so the developer immediately knows which dynamic element is affected.

---

## 4. Architecture

### 4.1 Module position and dependencies

The module sits at the bottom of the dependency graph: it depends only on the shared message catalogs and a DOM utility, and is consumed solely by **compiler-generated application code** (indirectly — no first-party runtime module calls it directly).

```mermaid
flowchart TB
    subgraph COMPILER["Compiler Pipeline - transform phase (dev builds only)"]
        VT["SvelteElement visitor<br/>client transform"]
        VS["SvelteElement visitor<br/>server transform"]
    end

    subgraph GUARDS["validation-guards (this module)"]
        VDT["validate_dynamic_element_tag"]
        VVE["validate_void_dynamic_element"]
    end

    subgraph CATALOGS["internal/shared message catalogs"]
        ERR["errors.js<br/>svelte_element_invalid_this_value"]
        WARN["warnings.js<br/>dynamic_void_element_content"]
    end

    UTIL["src/utils.js :: is_void"]
    APP["Generated component code<br/>client and server bundles"]

    VT -->|"emits $.validate_* statements"| APP
    VS -->|"emits $.validate_* statements"| APP
    APP -->|"invoked in dev only"| GUARDS
    VDT --> ERR
    VVE --> WARN
    VVE --> UTIL
```

**Dependency details:**

| Import | Source | Used for |
|---|---|---|
| `is_void` | `src/utils.js` | Void-element detection for the warning guard |
| `w` (warnings) | `internal/shared/warnings.js` | `dynamic_void_element_content` console warning |
| `e` (errors) | `internal/shared/errors.js` | `svelte_element_invalid_this_value` thrown error |

The module also **re-exports** `invalid_default_snippet` from `errors.js`; that guard belongs to the [internal-shared-utils / error-messages](internal-shared-utils_error-messages.md) module and is documented there.

### 4.2 How the guards reach application code

Neither the client `<svelte:element>` block ([client-dom-renderer](client-dom-renderer.md)) nor the SSR `$.element` ([server-runtime](server-runtime.md)) calls these guards themselves. The **compiler** wires them in during the transform phase — client-side in the [client-transform](compiler-transformer_client-transform.md) `SvelteElement` visitor, server-side in the [server-transform](compiler-transformer_server-transform.md) equivalent:

```mermaid
sequenceDiagram
    autonumber
    participant SRC as svelte:element node in source
    participant TR as SvelteElement visitor (transform)
    participant GEN as generated JS output
    participant RT as validation-guards (runtime)

    SRC->>TR: visited during 3-transform
    TR->>TR: count fragment children statically

    alt dev mode AND element has children
        TR->>GEN: $.validate_void_dynamic_element(() => tag)
    end
    alt dev mode (always)
        TR->>GEN: $.validate_dynamic_element_tag(() => tag)
    end

    TR->>GEN: $.element(node, () => tag, render_fn / children_fn)
    Note over GEN,RT: steps 2-3 are absent from production builds (dev flag is compile-time)

    GEN->>RT: invoked when the component initializes / the element renders
    RT-->>GEN: pass, throw, or warn (see §4.3)
```

Key injection details:

- **Client**: the void check is emitted only when the element's fragment statically contains children (`node.fragment.nodes.length > 0`) — an element known to be empty needs no guard. Both calls receive the same `get_tag` thunk that `$.element` itself will use.
- **Server**: if the tag expression is not a plain identifier it is first bound to a generated `const` (`$$tag`), guaranteeing the expression is evaluated once even though both the guard and the rendering code reference it. The void check likewise appears only when children exist.
- **Ordering**: the void-content warning is emitted *before* the tag-type check in generated code; both precede the actual `$.element` render call, so failures surface before any DOM/payload is produced.

### 4.3 Runtime decision flow

```mermaid
flowchart TD
    subgraph TAG["validate_dynamic_element_tag - hard failure"]
        A1["tag_fn() evaluated once"] --> A2{"tag truthy?"}
        A2 -->|"null / undefined / empty string"| PASS1["OK - element intentionally absent"]
        A2 -->|"value present"| A3{"typeof tag is string?"}
        A3 -->|"yes"| PASS1
        A3 -->|"no - number, object, boolean, function..."| ERR["throw svelte_element_invalid_this_value"]
    end

    subgraph VOID["validate_void_dynamic_element - soft failure"]
        B1["tag_fn() evaluated once"] --> B2{"tag truthy?"}
        B2 -->|"no"| PASS2["OK"]
        B2 -->|"yes"| B3{"is_void tag?"}
        B3 -->|"no - regular element"| PASS2
        B3 -->|"yes - br, img, input, hr, meta, ..."| WARN["console.warn dynamic_void_element_content with tag name"]
    end
```

After the void warning fires, rendering continues: on the client the child DOM is created and then silently discarded (void elements can't take children), and on the server `$.element` skips child serialization entirely because `is_void(tag)` short-circuits the children thunk (see [server-runtime / render-pipeline](server-runtime_render-pipeline.md)).

### 4.4 Build-mode message handling

Both guards funnel into message helpers that adapt their output to the build mode — the same pattern used by every runtime message in `internal/shared`:

```mermaid
flowchart LR
    subgraph DEV["DEV build"]
        direction TB
        DE["Error named 'Svelte error'<br/>full message + docs URL + stack trace"]
        DW["console.warn<br/>full message + docs URL"]
    end
    subgraph PROD["PRODUCTION build"]
        direction TB
        PE["Error containing<br/>docs URL only - small payload"]
        PW["console.warn<br/>docs URL only"]
    end
    ERRFN["svelte_element_invalid_this_value"] --> DE
    ERRFN --> PE
    WARNFN["dynamic_void_element_content"] --> DW
    WARNFN --> PW
```

- **Dev**: human-readable message, the offending value (for the warning) and a deep link to `https://svelte.dev/e/<message_code>` for full documentation.
- **Prod**: only the documentation URL remains — keeping error payloads tiny while remaining actionable.

---

## 5. Data Flow Walk-through

For a component using `<svelte:element this={tag}><p>hi</p></svelte:element>` compiled for the **client** in dev mode, the generated init code conceptually contains:

```js
// dev-only statements injected by the SvelteElement visitor
$.validate_void_dynamic_element(() => tag);   // fragment has children
$.validate_dynamic_element_tag(() => tag);

$.element($$node, () => tag, false, ($$element, $$anchor) => {
    // child rendering ...
});
```

Runtime sequence:

1. Component initializes; the reactive tag value is read via the thunk.
2. `validate_void_dynamic_element` fires first — if `tag` is e.g. `"img"`, a warning names the element and the developer knows the `<p>hi</p>` content will be dropped.
3. `validate_dynamic_element_tag` fires — if `tag` is e.g. `42`, a `Svelte error` is thrown with a stack trace pointing at the component.
4. Only if both guards pass does `$.element` create/patch the DOM node.

On the **server** the same two statements run inside the SSR render pass (see [server-runtime](server-runtime.md)), before the tag/attributes/children are pushed to the output payload — guaranteeing that invalid input never reaches the serialized HTML.

---

## 6. File Context

`validate.js` hosts this module's two guards alongside two related utilities that belong to other concerns of the shared-utils layer:

- `validate_store(store, name)` — store-shape validation used by the runtime store integration.
- `prevent_snippet_stringification(fn)` — overrides `toString` on snippet functions so accidental string coercion raises `snippet_without_render_tag` instead of silently stringifying code.

Neither is part of the `svelte:element` guard set, but they share the same conventions (dev-first diagnostics, shared message catalogs) described in §2 and §4.4.

---

## 7. Related Documentation

| Topic | Module |
|---|---|
| Parent shared-utils layer | [internal-shared-utils](internal-shared-utils.md) |
| `invalid_default_snippet` and the shared error catalog | [internal-shared-utils / error-messages](internal-shared-utils_error-messages.md) |
| Core helpers (`noop`, `run`, `to_array`) | [internal-shared-utils / core-utilities](internal-shared-utils_core-utilities.md) |
| Compiler-side injection into client output | [compiler-transformer / client-transform](compiler-transformer_client-transform.md) |
| Compiler-side injection into server output | [compiler-transformer / server-transform](compiler-transformer_server-transform.md) |
| Client-side `<svelte:element>` rendering block | [client-dom-renderer](client-dom-renderer.md) |
| SSR render pipeline consuming the guards | [server-runtime](server-runtime.md) |
| Compile-time (vs. runtime) diagnostics | [compiler-core / diagnostics](compiler-core_diagnostics.md), [message-code-generation-templates](message_code_generation_templates.md) |
