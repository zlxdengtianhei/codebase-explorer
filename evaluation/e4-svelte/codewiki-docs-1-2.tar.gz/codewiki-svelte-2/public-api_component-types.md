# Public API: Component Type Contracts (`public-api_component-types`)

## 1. Purpose & Scope

The **`public-api_component-types`** module is the *type-level heart of the Svelte component model*. It is implemented in a single file — `packages/svelte/src/index.d.ts` — and declares the TypeScript contracts that describe:

- **What a compiled Svelte component *is*** (`Component`, `ComponentInternals`),
- **How reusable template fragments are typed** (`Snippet`),
- **How component events are dispatched and typed** (`EventDispatcher`),
- **How components are instantiated imperatively** (`MountOptions`),
- **How legacy Svelte 4 class components keep type-checking** (`SvelteComponent`, `SvelteComponentTyped`, `ComponentType`, `ComponentEvents`),
- **How consumers extract a component's prop types** (`ComponentProps`).

This module is **purely declarative**: it contains zero runtime code. Every declaration is erased by TypeScript at build time. The only statements with side effects are:

| Statement | Effect |
|---|---|
| `import './ambient.js'` | Pulls ambient/global declaration context into scope |
| `export * from './index-client.js'` | Folds the *runtime* client API surface (see [public-api_client-entry](public-api_client-entry.md)) into the same type surface, so `import { mount } from 'svelte'` resolves through this file |

All *behaviour* behind these types lives elsewhere: the browser entry ([public-api_client-entry](public-api_client-entry.md)), the SSR entry ([public-api_server-entry](public-api_server-entry.md)), and the legacy compatibility shims ([legacy-compat](legacy-compat.md), [legacy-compat_component-api-shims](legacy-compat_component-api-shims.md)).

---

## 2. Component Inventory

### 2.1 Publicly exported declarations

| Declaration | Kind | Stability | Purpose |
|---|---|---|---|
| `Component<Props, Exports, Bindings>` | `interface` (callable) | ✅ Current (Svelte 5+) | Shape of a compiled component function |
| `ComponentInternals` | branded `type` | Internal-use (exported) | Opaque token Svelte passes as the first argument of a component function |
| `Snippet<Parameters>` | `interface` (callable) | ✅ Current | Type of a `{#snippet}` block, renderable only via `{@render}` |
| `EventDispatcher<EventMap>` | `interface` (callable) | ⚠️ Supported (callback props preferred) | Typed return value of `createEventDispatcher()` |
| `ComponentProps<Comp>` | `type` helper | ✅ Current | Extracts the `Props` of any component (v4 *or* v5 shape) |
| `MountOptions<Props>` | `type` | ✅ Current | Options accepted by `mount()` |
| `SvelteComponent` | `class` | ❌ Deprecated | Svelte 4 base-class typing |
| `SvelteComponentTyped` | `class` | ❌ Deprecated | Empty subclass alias of `SvelteComponent` |
| `ComponentConstructorOptions` | `interface` | ❌ Deprecated | Options object for the legacy class constructor |
| `ComponentEvents<Comp>` | `type` helper | ❌ Deprecated | Extracts the v4 `Events` type map |
| `ComponentType<Comp>` | `type` helper | ❌ Deprecated | v4 constructor type (for `<svelte:component>` switching) |

### 2.2 Internal (non-exported) declarations

| Declaration | Kind | Purpose |
|---|---|---|
| `Brand<B>` / `Branded<T, B>` | types | Nominal-typing utility: makes structurally identical types incompatible |
| `SnippetReturn` | `unique symbol` | Phantom brand inside `Snippet`'s return type |
| `DispatchOptions` | `interface` | `{ cancelable?: boolean }` — parameter of `EventDispatcher` |
| `Properties<Props, Slots>` | type helper | Legacy compat: adds `children?: any` to props when the component has a default slot |

> **Note:** `DispatchOptions` is *not* re-exported; it surfaces only as an optional third argument of `EventDispatcher`'s call signature.

---

## 3. Position in the System

This module is one of four children of [public-api](public-api.md) — the front door of the `svelte` package. Its siblings provide the runtime halves of the same contract:

```mermaid
flowchart TB
    subgraph PA["public-api — svelte package entry points"]
        direction LR
        CT["index.d.ts<br/>Component · Snippet · EventDispatcher<br/>MountOptions · legacy types<br/>(this module)"]
        CE["index-client.js<br/>browser implementation"]
        SE["index-server.js<br/>SSR implementation"]
        HT["svelte-html.d.ts<br/>IntrinsicElements / IDE typings"]
    end

    CT ==>"export * — runtime API re-typed here"==> CE
    CT -.->"MountOptions types mount()"--> CE
    CT -.->"same names, server throws/no-ops"--> SE
    CT -.->"event attribute typing for the language server"--> HT

    LEG["legacy-compat<br/>createClassComponent · asClassComponent"] -.->"runtime behind deprecated classes"--> CT
    SPT["svelte-public-types<br/>packages/svelte/types/index.d.ts"] -.->"aggregated public re-exports"--> CT
    CDT["compiler-core_type_definitions<br/>SnippetBlock · Root · template AST"] -.->"AST nodes ↔ these types"--> CT

    style CT fill:#e8f0fe,stroke:#3367d6,stroke-width:2px
```

**Key invariant:** the types defined here are *environment-neutral*. The same `Component` type describes a component whether it is mounted in a browser or rendered to a string on the server; only the sibling entry files differ (client `mount()` works, server `mount()` throws `lifecycle_function_unavailable`, server `createEventDispatcher()` returns a no-op).

---

## 4. Core Type Reference

### 4.1 `Component` — the Svelte 5 component contract

```ts
interface Component<
    Props extends Record<string, any> = {},
    Exports extends Record<string, any> = {},
    Bindings extends keyof Props | '' = string
> {
    (this: void, internals: ComponentInternals, props: Props):
        { $on?(...); $set?(...) /* deprecated legacy stubs */ } & Exports;
    element?: typeof HTMLElement;   // present when compiled with `customElement`
    z_$$bindings?: Bindings;        // phantom, typing-only bind: support
}
```

Design points:

- **Components are functions, not classes.** The call signature `(internals, props) => exports` mirrors exactly what the [compiler pipeline](Compiler_Pipeline___Language_Toolchain.md) emits for a `.svelte` file. `exports` are the component's non-prop exported values (e.g. exported functions), plus deprecated `$on`/`$set` stubs so code written against the v4 class API keeps compiling.
- **`this: void`** forbids calling a component function as a method of another object, enforcing correct call style at type level.
- **`ComponentInternals`** is a *branded* empty type — applications can never construct it; only the runtime engine can. It is Svelte's hidden per-instance state handle.
- **`Bindings`** feeds `bind:this`-style / `bind:` prop typing via the phantom `z_$$bindings` member (no runtime footprint).
- **`element`** mirrors the compiler's `customElement: true` option, letting the same type describe custom-element builds.

### 4.2 `ComponentInternals` and branding

```ts
declare const brand: unique symbol;
type Brand<B> = { [brand]: B };
type Branded<T, B> = T & Brand<B>;
export type ComponentInternals = Branded<{}, 'ComponentInternals'>;
```

Because TypeScript is structurally typed, `{}` alone would be forgeable. The unique-symbol brand makes `ComponentInternals` *nominal*: no user object can satisfy the first parameter of `Component`, which is precisely the point — it is reserved for the [Client Runtime Engine](client-reactivity-engine.md) and [Server Runtime](server-runtime.md).

### 4.3 `Snippet` — typed render fragments

```ts
interface Snippet<Parameters extends unknown[] = []> {
    (this: void, ...args: number extends Parameters['length'] ? never : Parameters):
        { '{@render ...} must be called with a Snippet': "import type { Snippet } from 'svelte'" } & typeof SnippetReturn;
}
```

- Corresponds one-to-one with the compiler's `SnippetBlock` AST node (see [compiler-core_type_definitions](compiler-core_type_definitions.md)) and is consumed at runtime by the snippet block implementations of the [client DOM renderer](client-dom-renderer_control-flow-blocks.md) and [server runtime slots module](server-runtime_slots-snippets-and-blocks.md).
- **Tuple-only parameters.** The conditional `number extends Parameters['length'] ? never : Parameters` accepts tuples (`[string, number]`) but rejects plain arrays — arrays would imply unsupported rest parameters.
- **Self-documenting misuse error.** The return type is a branded object whose *property name* is an error message. If a developer tries to call a snippet like a function outside `{@render}`, hover diagnostics literally instruct them to use `{@render ...}`.
- Typical use — declaring a component's snippet expectations:

```ts
let { banner }: { banner: Snippet<[{ text: string }]> } = $props();
```

### 4.4 `EventDispatcher` and `DispatchOptions`

```ts
interface DispatchOptions { cancelable?: boolean; }

interface EventDispatcher<EventMap extends Record<string, any>> {
    <Type extends keyof EventMap>(...args:
        null extends EventMap[Type]        ? [type: Type, parameter?: EventMap[Type] | null | undefined, options?: DispatchOptions] :
        undefined extends EventMap[Type]   ? [type: Type, parameter?: EventMap[Type] | null | undefined, options?: DispatchOptions] :
                                             [type: Type, parameter: EventMap[Type], options?: DispatchOptions]
    ): boolean;
}
```

- **Conditional arity**: if a mapped event's detail may be `null`/`undefined`, the `parameter` argument becomes optional; otherwise it is required. `undefined extends X` (rather than `X extends undefined`) keeps this working in both strict and non-strict modes.
- **Returns `boolean`** — whether the event finished without `preventDefault()`.
- **Runtime mapping:**

| Environment | Implementation | Behaviour |
|---|---|---|
| Client | `createEventDispatcher()` in `index-client.js` ([public-api_client-entry](public-api_client-entry.md)) | Looks up `$$events` on the active component context, creates a `CustomEvent`, invokes each listener, returns `!event.defaultPrevented` |
| Server | `createEventDispatcher()` in `index-server.js` ([public-api_server-entry](public-api_server-entry.md)) | Returns `noop` — dispatch is meaningless during SSR |

- `EventDispatcher` remains supported but the idiomatic Svelte 5 pattern is **callback props**; the deprecated `events` option of `MountOptions` relates to this (§4.6).

### 4.5 Legacy class component types (Svelte 4 compatibility)

```ts
class SvelteComponent<Props, Events, Slots> {
    static element?: typeof HTMLElement;
    $$prop_def: Props;      // typing-only phantoms — DO NOT USE
    $$events_def: Events;
    $$slot_def: Slots;
    constructor(options: ComponentConstructorOptions<Properties<Props, Slots>>);
    $destroy(): void;
    $on<K>(type: K, callback: (e: Events[K]) => void): () => void;
    $set(props: Partial<Props>): void;
}
class SvelteComponentTyped<P, E, S> extends SvelteComponent<P, E, S> {}
```

- These classes **have no real runtime implementation inside this module**. The actual behaviour is provided by the [legacy-compat](legacy-compat.md) module's component API shims (`createClassComponent`, `asClassComponent` wrapping the internal `Svelte4Component`) — see [legacy-compat_component-api-shims](legacy-compat_component-api-shims.md).
- `Properties<Props, Slots>` implements a subtle compat rule: **if the component has a default slot, `children` is added to its props** so `mount()`/class construction type-check slot content passed as `children`. The source documents a known trade-off: components that accept *no* props (`Record<string, never>`) degrade to `any` because TypeScript index signatures would otherwise make the `children` type unsatisfiable.
- `$$prop_def` / `$$events_def` / `$$slot_def` / `$$bindings` are **phantom members** — used solely by the type extractor helpers below, never present at runtime.
- `SvelteComponentTyped` exists only as an empty subclass so older libraries that `extends SvelteComponentTyped` continue to compile.

### 4.6 Type-extraction helpers

| Helper | Definition shape | Works with | Notes |
|---|---|---|---|
| `ComponentProps<Comp>` | conditional `infer Props` over `SvelteComponent` **or** `Component` | v4 *and* v5 | The recommended way to obtain a component's prop type |
| `ComponentEvents<Comp>` | `infer Events` over `SvelteComponent` | v4 only | Obsolete — the v5 `Component` type has no dedicated events map; use callback-prop types instead |
| `ComponentType<Comp>` | constructor type `(options) => Comp` | v4 only | For `<svelte:component this={...}>` dynamic switching under the class model |

`MountOptions<Props>` — consumed exclusively by the client `mount()` implementation ([public-api_client-entry](public-api_client-entry.md)); the server entry exports the same name but rejects it at runtime:

```ts
type MountOptions<Props = Record<string, any>> = {
    target: Document | Element | ShadowRoot;   // required
    anchor?: Node;                             // render immediately before this node
    events?: Record<string, (e: any) => any>;  // deprecated — use callback props
    context?: Map<any, any>;                   // seed for getContext()
    intro?: boolean;                           // transitions on initial render (default true)
} & ({} extends Props ? { props?: Props } : { props: Props });
```

The final intersection makes `props` **conditionally required**: a component with mandatory props forces callers to supply them.

---

## 5. Architecture

### 5.1 Type hierarchy

```mermaid
classDiagram
    direction TB

    class Component~Props, Exports, Bindings~ {
        <<interface Svelte5>>
        +element? : typeof HTMLElement
        +z_$$bindings? : Bindings
        +call(internals, props) Exports
    }
    class ComponentInternals {
        <<branded type>>
    }
    class Snippet~Parameters~ {
        <<interface>>
        +render(args) SnippetReturn
    }
    class EventDispatcher~EventMap~ {
        <<interface>>
        +dispatch(type, parameter, options) boolean
    }
    class DispatchOptions {
        <<internal interface>>
        +cancelable? : boolean
    }
    class SvelteComponent~Props, Events, Slots~ {
        <<deprecated class>>
        +$$prop_def : Props
        +$$events_def : Events
        +$$slot_def : Slots
        +$destroy() void
        +$on(type, callback) Function
        +$set(props) void
    }
    class SvelteComponentTyped~Props, Events, Slots~ {
        <<deprecated class>>
    }
    class ComponentConstructorOptions~Props~ {
        <<deprecated interface>>
        +target : Element
        +anchor? : Element
        +props? : Props
        +context? : Map
        +hydrate? : boolean
        +intro? : boolean
    }
    class MountOptions~Props~ {
        +target : Document
        +anchor? : Node
        +props : Props
        +context? : Map
        +intro? : boolean
        +events? : Record
    }
    class ComponentProps~Comp~ {
        <<type helper>>
    }
    class ComponentEvents~Comp~ {
        <<type helper deprecated>>
    }
    class ComponentType~Comp~ {
        <<type helper deprecated>>
    }

    SvelteComponentTyped --|> SvelteComponent : extends
    SvelteComponent ..> ComponentConstructorOptions : constructor options
    Component ..> ComponentInternals : first parameter
    EventDispatcher ..> DispatchOptions : optional 3rd arg
    Snippet ..> "SnippetReturn (unique symbol)" : branded return
    ComponentProps ..> Component : infers Props
    ComponentProps ..> SvelteComponent : infers Props
    ComponentEvents ..> SvelteComponent : infers Events
    ComponentType ..> SvelteComponent : constructor of
    MountOptions ..> Component : instantiates via mount()
```

### 5.2 Authoring → compiling → consuming (type data flow)

```mermaid
flowchart LR
    SRC[".svelte / .svelte.js source"]
    COMP["Compiler pipeline<br/>compile() / compileModule()"]
    OUT["Compiled export<br/>function(internals, props) → exports"]
    DTS["index.d.ts — this module<br/>Component · Snippet · EventDispatcher<br/>MountOptions · helpers"]
    APP["Typed application /<br/>component library code"]
    MOUNT["mount(component, options)<br/>index-client.js"]
    SSR["SSR render<br/>index-server.js → server runtime"]
    ENG["Client runtime engine<br/>signal graph · DOM rendering"]

    SRC --> COMP
    COMP --> OUT
    OUT -.-> "output conforms to" .-> DTS
    DTS --> APP
    APP -->|"Component + MountOptions"| MOUNT
    APP -->|"Component (render pass)"| SSR
    MOUNT --> ENG
```

The compiler does **not** import this module — instead, this module is hand-maintained to mirror the compiler's output contract. Any change to compiled component shape (see [compiler-core_type_definitions](compiler-core_type_definitions.md) for the corresponding AST types such as `Root` and `SnippetBlock`) must be reflected here.

### 5.3 End-to-end instantiation sequence

```mermaid
sequenceDiagram
    autonumber
    participant App as Application code
    participant M as mount() — index-client.js
    participant C as Compiled component (Component type)
    participant E as Client runtime engine

    App->>M: mount(MyComponent, { target, props } : MountOptions<Props>)
    M->>C: MyComponent(ComponentInternals, props)
    Note over C: internals is branded — only Svelte can supply it
    C-->>M: exports object (Exports & legacy $on/$set stubs)
    M->>E: render template · establish signals · bind events
    E-->>App: exports (e.g. exported functions for imperative use)
    Note over App,E: All type safety comes from THIS module;<br/>all behaviour comes from the runtime modules
```

---

## 6. Integration Map — type ↔ runtime ↔ compiler

| Type (this module) | Compiler counterpart | Runtime counterpart | Doc link |
|---|---|---|---|
| `Component` | compiled output of `compile()` / `compileModule()` | invoked by `mount()` / SSR `render()` | [compiler-core_public_api](compiler-core_public_api.md), [public-api_client-entry](public-api_client-entry.md) |
| `Snippet` | `SnippetBlock` AST node | `snippet` / `createRawSnippet` block implementations (client & server) | [compiler-core_type_definitions](compiler-core_type_definitions.md), [client-dom-renderer_control-flow-blocks](client-dom-renderer_control-flow-blocks.md), [server-runtime_slots-snippets-and-blocks](server-runtime_slots-snippets-and-blocks.md) |
| `EventDispatcher` | — (runtime API) | `createEventDispatcher()` — client dispatch / server `noop` | [public-api_client-entry](public-api_client-entry.md), [public-api_server-entry](public-api_server-entry.md) |
| `MountOptions` | — | `mount()` / `hydrate()` / `unmount()` entry points | [public-api_client-entry](public-api_client-entry.md), [public-api_server-entry](public-api_server-entry.md) |
| `SvelteComponent*` family | `legacy` AST node families (e.g. `LegacyRoot`) | `createClassComponent` / `asClassComponent` shims | [legacy-compat_component-api-shims](legacy-compat_component-api-shims.md) |
| `Component.element` | `customElement` compile option | `create_custom_element` runtime | [client-dom-renderer_custom-elements](client-dom-renderer_custom-elements.md) |
| Aggregate public surface | — | — | [svelte-public-types](svelte-public-types.md) (`packages/svelte/types/index.d.ts` re-exports these declarations), [public-api_html-typings](public-api_html-typings.md) for DOM-side attribute typing |

---

## 7. Usage Patterns

### 7.1 Typing a component library export

```ts
// component-library/index.d.ts
import type { Component } from 'svelte';

export declare const MyComponent: Component<{ foo: string }>;
```

Consumers then get full intellisense in `<MyComponent foo={'bar'} />` inside Svelte+TS files.

### 7.2 Extracting props for wrapper components

```ts
import type { Component, ComponentProps } from 'svelte';
import MyComponent from './MyComponent.svelte';

const props: ComponentProps<typeof MyComponent> = { foo: 'bar' }; // errors if wrong

function withProps<T extends Component<any>>(c: T, props: ComponentProps<T>) {}
withProps(MyComponent, { foo: 'bar' }); // second arg must match first arg's props
```

### 7.3 Typed snippet props

```svelte
<script lang="ts">
    import type { Snippet } from 'svelte';
    let { row, actions }: { row: Item; actions: Snippet<[Item]> } = $props();
</script>

{@render actions(row)}
```

### 7.4 Typed event dispatch (legacy-compatible code)

```ts
const dispatch = createEventDispatcher<{ close: { code: number } }>();
// parameter is REQUIRED because the detail type is not null/undefined:
dispatch('close', { code: 0 });          // ✅
dispatch('close');                       // ❌ type error
dispatch('ping');                        // ❌ 'ping' not in EventMap
```

---

## 8. Svelte 4 → 5 Migration Summary

| Svelte 4 pattern | Svelte 5 replacement |
|---|---|
| `class MyComp extends SvelteComponent<Props, Events, Slots>` | `Component<Props, Exports>` function type |
| `new MyComponent({ target, props })` | `mount(MyComponent, { target, props })` — typed by `MountOptions` |
| `ComponentType` + `<svelte:component this={...}>` | plain components are dynamic by default |
| `ComponentEvents<C>` / `createEventDispatcher` maps | callback props (typed via `Props`) |
| `$$prop_def` / `$$events_def` / `$$slot_def` | never needed — use `ComponentProps<C>` |
| default-slot → `children` prop (implicit) | explicit `Snippet` props via `Properties` compat bridge |

All deprecated members carry `@deprecated` JSDoc pointing to the migration guide, so IDEs surface strikethroughs and hints automatically.

---

## 9. Design Notes

1. **Types are the contract, not the implementation.** This module deliberately ships zero JS; every behavioural concern is pushed to sibling entry modules. This keeps the type surface reviewable in one file and makes the runtime free to differ per environment.
2. **Nominal typing via unique symbols** (`brand`, `SnippetReturn`) turns TypeScript's structural system into an access-control mechanism: internals cannot be forged, and snippets cannot be invoked as ordinary functions.
3. **Errors encoded in types.** `Snippet`'s return type embeds the fix ("must be called with a Snippet / `{@render ...}`") directly into the hover diagnostics — no runtime check is needed for the common misuse.
4. **Phantom members over runtime fields.** `$$prop_def`, `z_$$bindings` etc. exist only so helper types can `infer` from them; they never appear in emitted JS.
5. **Conditional utilities keep one API for two component eras.** `ComponentProps` and the `MountOptions` conditional-`props` trick let v4 classes and v5 functions coexist behind a single recommended helper, which is what makes gradual migration viable.

---

## 10. Related Documentation

- [public-api](public-api.md) — parent module: dual-entry resolution and facade layering
- [public-api_client-entry](public-api_client-entry.md) — browser runtime (`mount`, `unmount`, lifecycle functions, real `createEventDispatcher`)
- [public-api_server-entry](public-api_server-entry.md) — SSR runtime (`hydrate`/`mount`/`unmount` guards, no-op dispatcher)
- [public-api_html-typings](public-api_html-typings.md) — `IntrinsicElements` IDE typings
- [legacy-compat](legacy-compat.md) / [legacy-compat_component-api-shims](legacy-compat_component-api-shims.md) — runtime behind the deprecated class types
- [compiler-core_type_definitions](compiler-core_type_definitions.md) — AST node types (`SnippetBlock`, `Root`, template elements) that mirror these public contracts
- [svelte-public-types](svelte-public-types.md) — aggregated re-export surface of `packages/svelte/types/index.d.ts`
- [Client Runtime Engine (Reactivity & DOM Rendering)](client-reactivity-engine.md) — engine that supplies `ComponentInternals` and invokes component functions
- [Server-Side Rendering & Cross-Target Runtime Services](server-runtime.md) — SSR counterpart (`RenderOutput`, server slots/snippets)
