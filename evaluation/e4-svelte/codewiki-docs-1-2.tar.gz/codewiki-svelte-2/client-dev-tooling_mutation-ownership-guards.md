# Mutation & Ownership Guards (`client-dev-tooling_mutation-ownership-guards`)

> **Module path:** `packages/svelte/src/internal/client/dev/{assign.js, equality.js, ownership.js}`
> **Parent module:** [client-dev-tooling](client-dev-tooling.md) → Client Runtime Engine

## 1. Introduction

This module implements Svelte's **dev-mode-only runtime guards** for the two classes of bugs that static analysis cannot fully catch: **identity mismatches between `$state` proxies and the raw values they wrap**, and **ownership violations across the component prop chain** (mutating or re-binding props a component does not own).

The guards are *advisory*: they emit `console.warning` diagnostics (see the [message-catalog](client-dev-tooling_message-catalog.md)) but **never alter program semantics** — every guard function returns the value the original expression would have produced, so generated code behaves identically whether or not warnings fire. In production builds the compiler does not emit calls to these functions and the module is tree-shaken away entirely (verified by the [treeshakeability checker](treeshakeability_checker.md)).

The module consists of three complementary guards:

| File | Guard | Catches |
|---|---|---|
| `assign.js` | Stale-assignment guards | Assignment expression values that differ from what a `$state` proxy actually stores |
| `equality.js` | Proxy-identity equality guards | `===` / `==` / `indexOf` / `includes` comparisons broken by proxy identity |
| `ownership.js` | Ownership validator | Mutating unbound parent-owned props; forwarding `bind:` through a non-binding chain |

## 2. Position in the System

```
.svelte source
   │  compile (dev build)
   ▼
Compiler Pipeline ── client-transform emits guard calls into generated JS
   │
   ▼
Generated component code ──► $.assign / $.equals / $.strict_equals / validator.mutation / validator.binding
   │
   ▼
mutation-ownership-guards ──► reactivity engine (proxy, runtime, context) ──► warning catalog
```

- **Upstream (compile-time consumer):** the [client-transform](compiler-transformer_client-transform.md) phase rewrites assignment expressions ([expression visitors](compiler-transformer_client-transform_expression-visitors.md)) and equality expressions into guard calls, attaching sanitized source locations (`file:line:column`). A per-component ownership validator is instantiated during component bootstrap and consulted at mutation and `bind:`-forwarding sites.
- **Downstream (runtime dependencies):** the guards lean on the reactivity engine's foundations — `untrack` from the [signal graph](client-reactivity-engine_signal-graph.md), `get_proxied_value` / `STATE_SYMBOL` from [sources-and-proxies](client-reactivity-engine_sources-and-proxies.md), and `component_context` — and on the [props subsystem](client-reactivity-engine_props-and-stores.md), whose bindable-setter semantics the ownership validator mirrors.
- **Sibling modules:** [runtime-validation](client-dev-tooling_runtime-validation.md) (hard errors, e.g. invalid bindings) and [state-inspection](client-dev-tooling_state-inspection.md) (`$inspect`, tracing, `$state.snapshot` logging). This module is the *soft* layer: warnings about likely mistakes, not fatal validation.

## 3. Architecture

```mermaid
flowchart TB
    subgraph CT["Compiler — client-transform (dev mode only)"]
        AV["AssignmentExpression visitor<br/>(build_assignment + validate_mutation)"]
        EV["BinaryExpression visitor<br/>(equality rewriting)"]
        CV["Component visitor<br/>(validator bootstrap)"]
    end

    subgraph GUARDS["mutation-ownership-guards"]
        A["assign.js<br/>assign / assign_and /<br/>assign_or / assign_nullish"]
        E["equality.js<br/>equals / strict_equals /<br/>init_array_prototype_warnings"]
        O["ownership.js<br/>create_ownership_validator"]
    end

    subgraph ENGINE["Client Runtime Engine"]
        R["runtime.js<br/>untrack"]
        P["proxy.js<br/>get_proxied_value · STATE_SYMBOL"]
        CX["context.js<br/>component_context"]
        PR["props.js<br/>bindable-setter semantics"]
    end

    subgraph CATALOG["message-catalog"]
        W["assignment_value_stale<br/>state_proxy_equality_mismatch<br/>ownership_invalid_mutation<br/>ownership_invalid_binding"]
    end

    AV -->|"emits $.assign*"| A
    EV -->|"emits $.equals / $.strict_equals"| E
    CV -->|"instantiates validator"| O
    A --> R
    A --> W
    E --> P
    E --> W
    O --> CX
    O --> P
    O --> W
    O -.->|"mirrors"| PR
```

## 4. Core Components

### 4.1 Stale-Assignment Guards — `assign.js`

**Problem solved.** When the compiler inlines an assignment `obj.prop = value` where `obj` is a `$state` proxy, the assignment *expression* evaluates to `value`, but the value the proxy stores may differ (e.g. objects get wrapped in a new proxy). Code like `let x = (obj.prop = { a: 1 })` then holds a *stale*, unproxied reference. This guard detects the divergence at the moment it is created.

**API** — four functions covering the full assignment-operator set:

| Function | Rewritten source |
|---|---|
| `assign(object, property, value, location)` | `=` |
| `assign_and(object, property, value, location)` | `&&=` |
| `assign_or(object, property, value, location)` | `\|\|=` |
| `assign_nullish(object, property, value, location)` | `??=` |

**Mechanism.** Each function performs the real assignment, then reads the property back inside `untrack(...)` (so the read does not register a reactive dependency) and passes both values to the internal `compare` helper. If the freshly-written value and the untracked post-write read diverge, `assignment_value_stale` is emitted with the property name and the compiler-supplied location.

### 4.2 Proxy-Identity Equality Guards — `equality.js`

**Problem solved.** `$state` deep-proxies objects and arrays. A raw object and its proxy are `===`-distinct, so `arr.indexOf(myRawObj)` returns `-1` and `rawObj === stateObj` is `false` even though they "are" the same data. These guards make such identity mismatches visible.

**API:**

- `strict_equals(a, b, equal = true)` — dev replacement for `===` / `!==`. Compares raw identity (`a === b`) against proxy-normalized identity (`get_proxied_value(a) === get_proxied_value(b)`). On divergence it warns `state_proxy_equality_mismatch`. It **returns the raw comparison** (xor'd with `equal` for `!==`), preserving exact expression semantics. Property access on `a`/`b` is wrapped in `try/catch` because operand values may be exotic (e.g. cross-origin iframe `contentWindow`).
- `equals(a, b, equal = true)` — identical strategy for the loose `==` / `!=` operators (no `try/catch` needed, since loose equality doesn't dereference).
- `init_array_prototype_warnings()` — patches `Array.prototype.indexOf`, `lastIndexOf` and `includes`. When the native method reports "not found" but a manual scan finds an element whose `get_proxied_value` matches the search item, `state_proxy_equality_mismatch` is warned with the method name, and the *native* result is still returned. Patching is idempotent: the `Array.__svelte_cleanup` marker restores the original methods and prevents the REPL from stacking duplicate patches on hot reload.

### 4.3 Ownership Validator — `ownership.js`

**Problem solved.** In Svelte's ownership model, a prop passed down as `prop={value}` is *owned* by the parent; the child may not mutate it (use `bind:prop={value}` instead). Likewise, a child may only forward `bind:` further down if it itself received a binding. The validator enforces these rules at runtime along the *path* of the mutation, not just the root.

**API:**

```js
create_ownership_validator(props) → { mutation(prop, path, result, line, column), binding(key, child_component, value) }
```

`create_ownership_validator` captures the current component and its parent from `component_context` at bootstrap time. The returned handlers are consulted by compiler-emitted instrumentation:

#### `mutation(...)` decision flow

```mermaid
flowchart TD
    M["mutation(prop, path, result, line, column)"] --> B1{"Root prop bound<br/>(has setter) or unset?"}
    B1 -- "yes" --> ALLOW["return result — no warning"]
    B1 -- "no" --> P{"Parent component exists?"}
    P -- "no" --> ALLOW
    P -- "yes" --> WALK["Walk path[0 .. len-2]<br/>through props"]
    WALK --> S{"Every intermediate<br/>value is state-proxied<br/>(STATE_SYMBOL present)?"}
    S -- "no" --> ALLOW
    S -- "yes" --> WARN["ownership_invalid_mutation:<br/>root name · child location<br/>mutated prop · parent filename"]
    WARN --> ALLOW
```

Key behaviors:
- **Path-aware:** `props.a.b.c = x` is checked segment by segment. Mutations inside *non-proxied* data cannot be attributed to the parent's state and are allowed to pass silently.
- **Bound props are exempt:** if the root prop has a setter (i.e. the parent used `bind:`), mutation is the intended mechanism.
- **Entry props are exempt:** props objects created directly via `mount(Component, $state({...}))` or `createClassComponent` (`STATE_SYMBOL` / `LEGACY_PROPS` present) are user-owned, not parent-owned.
- **Warn-only:** `result` (the assigned value) is always returned unchanged so the surrounding assignment expression keeps its value.

#### `binding(...)` decision flow

```mermaid
flowchart TD
    B["binding(key, child_component, value)"] --> C1{"Prop bindable,<br/>entry-prop, or unset?"}
    C1 -- "yes" --> OK["no warning"]
    C1 -- "no" --> C2{"Parent exists AND value<br/>is state-proxied?"}
    C2 -- "no" --> OK
    C2 -- "yes" --> WB["ownership_invalid_binding:<br/>parent → child with bind:,<br/>but grandparent did not bind"]
```

This detects an *interrupted binding chain*: component A passes `x={...}` to B, and B forwards `bind:x` to C. Writes from C stop at B and silently break reactivity for A.

#### Shared predicate: `is_bound_or_unset(props, prop_name)`

Returns `true` (mutation/binding allowed) when any of:
1. the prop descriptor exposes a `set` — the parent declared it bindable;
2. `props` is an entry-props object and the key exists on it;
3. the key does not exist in `props` at all (nothing to attribute).

This deliberately mirrors the bindable-setter resolution logic inside `prop()` in the [props subsystem](client-reactivity-engine_props-and-stores.md), keeping guard semantics and runtime semantics in lockstep.

## 5. End-to-End Data Flow (assignment guard)

```mermaid
sequenceDiagram
    participant Src as Svelte source: obj.prop = value
    participant CT as client-transform (dev)
    participant Gen as Generated JS
    participant Gd as $.assign
    participant Eng as proxy / runtime
    participant Cat as warnings

    Src->>CT: parse · analyze · transform
    CT->>Gen: emit assign(obj, 'prop', value, "App.svelte:12:5")
    Gen->>Gd: call guard
    Gd->>Eng: perform obj.prop = value (proxy stores value)
    Gd->>Eng: untrack(() => obj.prop)
    Eng-->>Gd: stored value
    alt stored value !== written value
        Gd->>Cat: assignment_value_stale('prop', location)
    end
    Gd-->>Gen: return assigned value (expression result preserved)
```

## 6. Warning Codes Emitted

All diagnostics are routed through the [message-catalog](client-dev-tooling_message-catalog.md) (`console.warn`; in production only the `svelte.dev/e/...` link is printed).

| Code | Guard | Message gist |
|---|---|---|
| `assignment_value_stale` | `assign*` | Assignment to `prop` evaluates to the RHS, not the post-assignment value of `prop` |
| `state_proxy_equality_mismatch` | `equals` / `strict_equals` / patched array methods | `$state` proxies and raw values have different identities; comparison results are unreliable |
| `ownership_invalid_mutation` | `validator.mutation` | Mutating unbound props is discouraged; use `bind:` in the parent (or a callback) |
| `ownership_invalid_binding` | `validator.binding` | `bind:` forwarded to a child although the parent did not declare a binding |

## 7. Dev-Mode Gating & Production Behavior

- Guards are **referenced only in dev builds**: the client transform emits guard calls when the `dev` compile option is on; `equality.js`'s `init_array_prototype_warnings()` is likewise invoked only in dev initialization paths.
- Every handler is non-throwing by design (compare the *hard* errors of [runtime-validation](client-dev-tooling_runtime-validation.md)). Ownership paths tolerate exotic values (cross-origin objects, secure contexts) via `try/catch` and `get_proxied_value`'s own defensive checks.
- Because warning functions are gated on the `DEV` flag internally as well, the whole chain tree-shakes to nothing in production — an invariant checked by the [treeshakeability checker](treeshakeability_checker.md).

## 8. Dependencies Summary

| Dependency | Source module | Used for |
|---|---|---|
| `untrack` | [client-reactivity-engine_signal-graph](client-reactivity-engine_signal-graph.md) | Read-back of assigned properties without registering dependencies |
| `get_proxied_value`, `STATE_SYMBOL` | [client-reactivity-engine_sources-and-proxies](client-reactivity-engine_sources-and-proxies.md) | Normalize raw ↔ proxy identity; detect state-proxied nodes on the ownership path |
| `component_context` | context subsystem | Resolve current component + parent (filenames) for ownership attribution |
| `get_descriptor`, `sanitize_location`, `FILENAME` | internal shared utils | Bindable-setter detection, location formatting |
| warning functions (`w.*`) | [client-dev-tooling_message-catalog](client-dev-tooling_message-catalog.md) | All four diagnostics |
| guard call emission | [compiler-transformer_client-transform](compiler-transformer_client-transform.md) | Compile-time wiring of guards into generated code |

## 9. Maintenance Notes

- **Semantics must stay warn-only.** Any change that makes a guard throw or alter a return value would break the "dev build behaves identically to prod" contract.
- **Keep `is_bound_or_unset` in sync with `prop()`.** The props subsystem resolves bindable setters with equivalent logic; if one changes, the other must follow or ownership warnings will drift from actual reactivity behavior.
- **`compare` must return `a` (the write result), not `b`.** Generated code relies on the guard returning exactly what the original assignment expression evaluated to.
- **Array prototype patching is intentionally global and reversible.** `Array.__svelte_cleanup` must be preserved — it guards against patch stacking in HMR/REPL scenarios.
- New guard diagnostics belong in the [message-catalog](client-dev-tooling_message-catalog.md) module; only detection logic belongs here.
