# Parsing States — Svelte Template Parser

## Introduction

The `compiler-parser_parsing-states` module implements the **state functions** of the Svelte template parser — a character-driven state machine that converts a raw `.svelte` template string into an Abstract Syntax Tree (AST). While the [compiler-parser_parser-core](compiler-parser_parser-core.md) module owns the `Parser` class and the driving loop, this module contains the actual parsing logic that decides *what the next character means*: an element, an expression tag, or text.

Each state function follows a uniform contract:

```javascript
/** @param {Parser} parser */
export default function state(parser) {
    // 1. inspect the template at parser.index
    // 2. consume characters / append AST nodes
    // 3. return the next state function (or undefined → defaults back to `fragment`)
}
```

The three core files are:

| File | Component | Responsibility |
|---|---|---|
| `phases/1-parse/state/fragment.js` | `fragment` | **Dispatcher state** — peeks at the next character and delegates to `element`, `tag`, or `text` |
| `phases/1-parse/state/element.js` | `element`, `read_attribute`, `read_static_attribute` | Parses HTML/Svelte elements, closing tags, comments, and the full attribute/directive grammar |
| `phases/1-parse/state/text.js` | `text` | Consumes raw text runs and decodes HTML character references |

The output of this module is a tree of AST nodes (`Root`, `RegularElement`, `Component`, `Text`, `ExpressionTag`, directives, …) whose shapes are defined in [compiler-core_type_definitions](compiler-core_type_definitions.md). Downstream, this AST feeds the [compiler-analyzer](compiler-analyzer.md) and [compiler-transformer](compiler-transformer.md) modules.

---

## 1. Architecture: The Parser State Machine

The `Parser` (see [compiler-parser_parser-core](compiler-parser_parser-core.md)) runs a loop in its constructor:

```javascript
/** @type {ParserState} */
let state = fragment;

while (this.index < this.template.length) {
    state = state(this) || fragment;
}
```

Key mechanics:

- **Explicit state return:** `fragment` *returns* the next state function (`element`, `tag`, or `text`).
- **Implicit return to `fragment`:** the terminal states (`element`, `tag`, `text`) consume one syntactic unit and return `undefined`; the `|| fragment` fallback restarts the dispatch cycle.
- **Two parallel stacks** coordinate nesting:
  - `parser.stack` — open elements/blocks (`Root`, `RegularElement`, `IfBlock`, …) for matching closing tags.
  - `parser.fragments` — the open `AST.Fragment` collections; `parser.append(node)` always appends to the *innermost* fragment, so content lands inside whichever element/block is currently open.
- **Loose mode:** `parser.loose` enables error-resilient parsing (backtracking instead of hard failures) so that language tools can parse incomplete templates.

```mermaid
flowchart TB
    subgraph CORE["Parser core — compiler-parser_parser-core"]
        LOOP["state loop<br/>state = state(parser) &#124;&#124; fragment"]
        H["helpers: match / eat / read_until /<br/>allow_whitespace / read_identifier /<br/>append / pop"]
        ST["parser.stack: TemplateNode[]<br/>parser.fragments: Fragment[]<br/>parser.index · parser.loose · parser.ts"]
    end

    subgraph STATES["Parsing states — this module"]
        F["fragment<br/>(dispatcher)"]
        E["element<br/>+ read_attribute<br/>+ read_static_attribute<br/>+ read_sequence"]
        T["text"]
    end

    subgraph SIB["Sibling state — state/tag.js"]
        TG["tag → open / close /<br/>next / special<br/>(blocks & {@...} tags)"]
    end

    subgraph DEPS["Supporting modules"]
        JS["compiler-parser_js-ts-parsing<br/>read_expression · read_script · read_style"]
        HTML["compiler-parser_parsing-utilities<br/>decode_character_references"]
        DIAG["compiler-core_diagnostics<br/>errors (e) / warnings (w)"]
        TYPES["compiler-core_type_definitions<br/>AST node shapes"]
    end

    LOOP -->|"invoke"| F
    F -->|"next char '<'"| E
    F -->|"next char '{'"| TG
    F -->|"otherwise"| T
    E -->|"child elements"| E
    T & E & TG -.->|"return undefined"| LOOP
    E --> JS
    E & T --> HTML
    E & T --> DIAG
    STATES -->|"append(node)"| TYPES
    TYPES --> OUT["AST.Root → compiler-analyzer → compiler-transformer"]
```

---

## 2. State Transition Diagram

The runtime state graph is deliberately tiny — the complexity lives *inside* each state:

```mermaid
stateDiagram-v2
    [*] --> fragment: new Parser(template, loose)

    fragment --> element: template[index] === '<'
    fragment --> tag: template[index] === '{'
    fragment --> text: any other character

    text --> fragment: consumed text run,<br/>stops before '<' or '{'
    element --> fragment: node appended /<br/>stack updated
    tag --> fragment: expression tag emitted<br/>or block pushed/popped

    fragment --> fragment: loop continues<br/>while index < length
    fragment --> [*]: EOF — validate<br/>stack empty & final state is fragment
```

> **Note:** `tag` (in `state/tag.js`) handles `{#if}`/`{#each}`/`{:else}`/`{@html}` etc. It is the third dispatch target of `fragment` and shares the same stack/fragment conventions as this module; its block semantics (`open`, `next`, `close`, `special`) are documented with the [compiler-parser_parser-core](compiler-parser_parser-core.md) module.

---

## 3. Component Deep Dive

### 3.1 `fragment` — The Dispatcher

`fragment.js` is intentionally minimal. It never consumes input; it only classifies the upcoming character:

```javascript
export default function fragment(parser) {
    if (parser.match('<')) return element;  // HTML/Svelte markup
    if (parser.match('{'))  return tag;     // expressions & blocks
    return text;                            // everything else
}
```

This dispatch boundary is the fundamental lexer-level split of a Svelte template into three token worlds. Because `fragment` returns the state function rather than mutating anything, the top-level loop in `Parser` remains trivial and each state owns its own grammar.

```mermaid
flowchart LR
    FR["fragment"] -->|"'<'"| EL["element:<br/>elements, components,<br/>svelte:* meta tags,<br/>comments, closing tags"]
    FR -->|"'{'"| TG["tag:<br/>{expr} · {#if} · {:else}<br/>{@html} · {@render} · {/if}"]
    FR -->|"other"| TX["text:<br/>raw text runs with<br/>entity decoding"]
```

---

### 3.2 `element` — Element & Markup Parsing

`element.js` contains the largest state and several file-private helpers. It is invoked whenever `fragment` sees `<`.

#### 3.2.1 Overall Flow

```mermaid
flowchart TD
    A["element(parser)<br/>consume '<' (start = index++)"] --> B{"eat '!--' ?"}
    B -->|yes| C["read until '-->' →<br/>append Comment node"]
    B -->|no| D{"eat '/' ? — closing tag?"}
    D -->|yes| E["read name · allow whitespace<br/>· eat '>'"]
    E --> E1{"is_void(name)?"}
    E1 -->|yes| ERR1["error void_element_invalid_content"]
    E1 -->|no| E2["while parent.name ≠ name:<br/>loose backtracking · implicit-close<br/>warnings · invalid-close errors"]
    E2 --> E3["parent.end = index<br/>parser.pop() · update last_auto_closed_tag"]
    D -->|no| F["read element name<br/>validate svelte:* meta tags<br/>validate name regexes"]
    F --> G["resolve node type<br/>(see 3.2.2)"]
    G --> H["implicit close of parent if<br/>closing_tag_omitted(parent, name)<br/>→ warning + last_auto_closed_tag"]
    H --> I["attribute loop:<br/>read_static_attribute (top-level<br/>script/style) or read_attribute<br/>+ duplicate-name check"]
    I --> J{"top-level<br/>&lt;script&gt; / &lt;style&gt;?"}
    J -->|yes| K["eat '>' · read_script / read_style<br/>attach preceding HTML comment<br/>(warning suppression)"]
    J -->|no| L["parser.append(element)"]
    L --> M{"eat '/' or is_void(name)<br/>→ self-closing?"}
    M -->|yes| N["element.end = index (done)"]
    M -->|no| O{"name === 'textarea'?"}
    O -->|yes| P["read_sequence until<br/>regex_closing_textarea_tag"]
    O -->|no| Q{"name is script/style<br/>(nested)?"}
    Q -->|yes| R["raw Text until '&lt;/tag&gt;'"]
    Q -->|no| S["push element + element.fragment<br/>onto stack/fragments"]
```

#### 3.2.2 Element Type Resolution

After reading the tag name, `element` classifies the node. The resulting `type` string matches the AST definitions in [compiler-core_type_definitions](compiler-core_type_definitions.md):

| Condition | Resulting node type |
|---|---|
| Name found in `meta_tags` map | `SvelteHead`, `SvelteOptions`, `SvelteWindow`, `SvelteDocument`, `SvelteBody`, `SvelteElement`, `SvelteComponent`, `SvelteSelf`, `SvelteFragment`, `SvelteBoundary` |
| Name matches `regex_valid_component_name` (uppercase start or dotted identifier) — or a trailing `.` in loose mode | `Component` |
| `title` inside `<svelte:head>` | `TitleElement` |
| `slot` **not** inside a declarative shadow-root template (`shadowrootmode` attribute) | `SlotElement` |
| Everything else | `RegularElement` |

Additional validation performed before/around classification:

- **Unknown `svelte:*` tags** → `e.svelte_meta_invalid_tag` (with a fuzzy list of valid names, see [compiler-parser_parsing-utilities](compiler-parser_parsing-utilities.md)).
- **Root-only meta tags** (`svelte:head`, `svelte:options`, `svelte:window`, `svelte:document`, `svelte:body`) must appear directly in `Root` and only once → `e.svelte_meta_invalid_placement`, `e.svelte_meta_duplicate`.
- **Malformed names** → `e.tag_invalid_name` (skipped in loose mode while "typing", e.g. `<div.`).
- **`<svelte:component this=…>`** — the `this` attribute is *extracted* from the attribute list into `element.expression` (`e.svelte_component_missing_this`, `e.svelte_component_invalid_this` otherwise).
- **`<svelte:element this=…>`** — the `this` attribute becomes `element.tag`; a static string triggers the preserved Svelte 4 behavior `w.svelte_element_invalid_this` (legacy compat).

#### 3.2.3 Closing Tags & HTML Recovery

Closing-tag handling is where the parser implements several HTML-compatibility behaviors:

- **Implicit closing:** when `</div>` arrives while a `<p>` is open (per the HTML tree-validation rules), the inner element is implicitly closed with `w.element_implicitly_closed`. The `parser.last_auto_closed_tag` bookkeeping distinguishes legitimate auto-closure from a later erroneous `</p>` (`e.element_invalid_closing_tag_autoclosed` vs `e.element_invalid_closing_tag`).
- **Loose-mode backtracking:** if the parser misinterpreted a following `<name>` opening tag as an attribute literally named `<name`, it rewinds `parser.index` to the attribute start, drops the bogus attribute, and treats the construct as a proper closing tag. Similar rewinding happens when an unclosed opening tag swallowed `{/`, `{#`, `{@`, or `{:` sequences, and when an attribute named `<` was eaten — each case restores `parser.index` so the following construct parses correctly.

#### 3.2.4 Script & Style Special Cases

- **Top-level** `<script>` / `<style>`: attributes are read with the *static-only* reader (`read_static_attribute`), the `>` is required, and content parsing is delegated to `read_script`/`read_style` from [compiler-parser_js-ts-parsing](compiler-parser_js-ts-parsing.md). A directly preceding HTML comment is captured and attached to the parsed content (`leadingComments` / `comment`) so the warning engine can honor `<!-- svelte-ignore … -->`. Duplicates raise `e.script_duplicate` / `e.style_duplicate`.
- **Nested** `<script>`/`<style>` (e.g., inside an element): treated as raw text — everything up to `</script>` / `</style>` becomes a single `Text` node with no interpolation.
- **`<textarea>`**: parsed via `read_sequence` (supporting `{expr}` interpolation) until the closing-tag regex matches.

---

### 3.3 `read_attribute` — Attribute & Directive Grammar

`read_attribute` implements the full modern Svelte attribute surface. Its decision tree:

```mermaid
flowchart TD
    A["read_attribute(parser)"] --> B{"eat '{' ?"}
    B -->|yes| C{"eat '@attach' ?"}
    C -->|yes| D["AttachTag<br/>{ @attach fn }"]
    C -->|no| E{"eat '...' ?"}
    E -->|yes| F["SpreadAttribute<br/>{ ...expr }"]
    E -->|no| G["shorthand { name }<br/>→ Attribute with synthetic<br/>Identifier ExpressionTag"]
    G --> G1["loose: '#' '/' '@' ':' → null<br/>(partial block being typed)<br/>'}' → empty shorthand name"]
    B -->|no| H["read name until<br/>regex_token_ending_character"]
    H --> I{"name contains ':' ?"}
    I -->|no| K["plain Attribute<br/>value = true / ExpressionTag /<br/>Array&lt;Text&#124;ExpressionTag&gt;"]
    I -->|yes| J["prefix → directive type:<br/>use·animate·bind·class·style·<br/>on·let·in/out/transition"]
    J --> L{"eat '=' ?"}
    L -->|"yes, next is '/&gt;'"| M1["value = [Text '/']<br/>(interpolated-component quirk)"]
    L -->|yes| M2["read_attribute_value"]
    L -->|no| N["value = true<br/>(quoted-value-without-= →<br/>e.expected_token '=')"]
    M1 & M2 & N --> O["build Directive:<br/>name = token after ':'<br/>modifiers split on '|'"]
    O --> P{"StyleDirective?"}
    P -->|yes| Q["keep array value +<br/>'important' modifiers"]
    P -->|no| R["require single ExpressionTag<br/>(else e.directive_invalid_value)<br/>→ directive.expression"]
    R --> S["TransitionDirective:<br/>set intro / outro flags<br/>(in|out|transition)"]
    S --> T{"bind:/class:<br/>without value?"}
    T -->|yes| U["synthesize Identifier<br/>expression from name"]
    T -->|no| V["directive complete"]
    K --> W["create_attribute(...)"]
```

Highlights:

- **Directive mapping** (`get_directive_type`): `use`→`UseDirective`, `animate`→`AnimateDirective`, `bind`→`BindDirective`, `class`→`ClassDirective`, `style`→`StyleDirective`, `on`→`OnDirective`, `let`→`LetDirective`, `in`/`out`/`transition`→`TransitionDirective`.
- **Empty directive names** (`on:="x"`) → `e.directive_missing_name`.
- **Duplicate detection** happens in the `element` attribute loop, not here: keys are normalized (`BindDirective` → `Attribute`) so `<div bind:value value>` errors, while `class:x` + `style:x` can coexist. `this` is exempted (needed by `svelte:element bind:this this=…`).
- **Every directive/attribute** is created with fresh `metadata.expression` (the expression-analysis slot consumed later by the [compiler-analyzer](compiler-analyzer.md)).

#### 3.3.1 `read_static_attribute`

A reduced reader used exclusively for top-level `<script>`/`<style>` tags, where dynamic attributes are meaningless: only `name`, `name="static"` are accepted (values decoded with **attribute** entity rules). A quote appearing where `=` is expected raises `e.expected_token(index, '=')`.

#### 3.3.2 `read_attribute_value` & `read_sequence`

- `read_attribute_value` resolves the quoting context (`"`, `'`, or unquoted), then delegates chunk collection to `read_sequence`, guarding against the empty-quoted-value case and normalizing the result: a lone `ExpressionTag` is returned directly; anything else is an `Array<Text | ExpressionTag>`. A JS parse error caused by an unterminated `<Component test={{a:1} />` is translated into `e.expected_token` at the `/>`.
- `read_sequence` is the shared chunk builder for attribute values and `<textarea>` bodies. It accumulates raw text into a running `Text` chunk, and on `{`:
  - `{#` → `e.block_invalid_placement` (blocks are illegal in attribute values),
  - `{@` → `e.tag_invalid_placement` (no `{@html}` etc.),
  - otherwise reads an expression via `read_expression` ([compiler-parser_js-ts-parsing](compiler-parser_js-ts-parsing.md)) and emits an `ExpressionTag`.
  
  Text chunks are flushed through `decode_character_references` with **attribute-value** semantics ([compiler-parser_parsing-utilities](compiler-parser_parsing-utilities.md)); hitting EOF in strict mode raises `e.unexpected_eof`.

---

### 3.4 `text` — Text Runs

The `text` state consumes characters until the next `<` or `{`, then appends a single `Text` node:

```javascript
export default function text(parser) {
    const start = parser.index;
    let data = '';
    while (parser.index < parser.template.length && !parser.match('<') && !parser.match('{')) {
        data += parser.template[parser.index++];
    }
    parser.append({
        type: 'Text',
        start,
        end: parser.index,
        raw: data,
        data: decode_character_references(data, false) // content semantics: &amp; etc.
    });
}
```

Two entity-decoding contexts exist: `false` (element content) vs `true` (attribute values) — some entities are only decoded in one context; both are implemented by `get_entity_pattern`/`decode_character_references` in [compiler-parser_parsing-utilities](compiler-parser_parsing-utilities.md).

---

## 4. Interaction with the Parser — Worked Example

Parsing `<div class:x>hi {name}</div>`:

```mermaid
sequenceDiagram
    autonumber
    participant L as Parser loop
    participant F as fragment
    participant E as element
    participant T as text

    L->>F: index=0, char '<'
    F-->>L: return element
    L->>E: invoke
    E->>E: read name "div" → RegularElement
    E->>E: read_attribute → class:x → ClassDirective
    E->>E: eat '>' → push element+fragment
    E-->>L: undefined → back to fragment
    L->>F: index=15, char 'h'
    F-->>L: return text
    L->>T: consume "hi " → append Text (decoded)
    T-->>L: undefined → fragment
    L->>F: index=18, char '{'
    Note over F: returns tag (state/tag.js)
    Note over L: tag reads "name" →<br/>ExpressionTag appended to innermost fragment
    L->>F: char '<'
    F-->>L: return element
    L->>E: closing tag "div" matches stack top
    E->>E: parent.end = index · parser.pop()
    E-->>L: done
    L->>L: index ≥ length → validate stack empty,<br/>return AST.Root
```

The two parallel stacks make nesting transparent: while `div` is open, both `Text` and `ExpressionTag` are appended to `element.fragment`; after the closing tag, `parser.pop()` restores the previous fragment (ultimately `root.fragment`).

---

## 5. Loose Parsing Mode

The states contain explicit `parser.loose` branches so that incomplete/invalid templates still yield a usable AST (critical for the editor/language-tools integrations):

| Situation | Strict mode | Loose mode |
|---|---|---|
| Unclosed opening tag at EOF (`element_unclosed` / `block_unclosed`) | error | current node extended to template end |
| Element name ends with `.` mid-typing (`<div.`) | `e.tag_invalid_name` | accepted (as a Component) |
| `{#if x` unclosed before attributes (`'#'`, `'/'`, `'@'`, `':'` seen) | `e.attribute_empty_shorthand` / hard error | return `null`, close the tag gracefully |
| Partial `{#` / `{@` / `{/` swallowed by a tag | hard error | `parser.index` rewound, tokens re-read |
| `<name` misread as attribute before `</name>` | — | attribute dropped, index rewound |
| EOF inside attribute sequence | `e.unexpected_eof` | chunks returned as-is |
| Closing tag not matching any open element | `e.element_invalid_closing_tag*` / `e.block_unexpected_close` | closest matching block popped recursively |

---

## 6. Diagnostics Raised

All diagnostics are defined in the [compiler-core_diagnostics](compiler-core_diagnostics.md) module (message sources generated from `scripts/process-messages` templates). Raised by this module:

| Diagnostic | Raised when |
|---|---|
| `e.void_element_invalid_content` | `</br>`-style closing tag for a void element |
| `e.element_invalid_closing_tag` / `..._autoclosed` | mismatched closing tag / tag already auto-closed by a sibling |
| `w.element_implicitly_closed` | `<div><p></div>` — omitted closing tag (warning) |
| `e.svelte_meta_invalid_tag` / `e.svelte_meta_duplicate` / `e.svelte_meta_invalid_placement` | unknown/duplicate/misplaced `svelte:*` tags |
| `e.tag_invalid_name` | invalid element or component name |
| `e.attribute_duplicate` | duplicate attribute/directive (normalized key) |
| `e.svelte_component_missing_this` / `e.svelte_component_invalid_this` | `<svelte:component>` without/with static `this` |
| `w.svelte_element_invalid_this` / `e.svelte_element_missing_this` | `<svelte:element this>` issues (legacy behavior preserved) |
| `e.script_duplicate` / `e.style_duplicate` | multiple top-level `<script context=module>`/`<script>`/`<style>` |
| `e.expected_attribute_value` / `e.expected_token` / `e.expected_whitespace` | malformed attribute syntax |
| `e.attribute_empty_shorthand` | `{}` with no identifier |
| `e.directive_missing_name` / `e.directive_invalid_value` | `on:="…"` / `on:click="text {expr}"` |
| `e.block_invalid_placement` / `e.tag_invalid_placement` | `{#if}` / `{@html}` inside attribute values |
| `e.unexpected_eof` | template ends mid-construct (strict mode) |

`<!-- svelte-ignore … -->` comments are preserved as `Comment` nodes and attached to adjacent `<script>`/`<style>` content so the warning engine can suppress `w.*` diagnostics.

---

## 7. Inputs, Outputs & Data Flow

```mermaid
flowchart LR
    IN["inputs<br/>template string · loose flag ·<br/>lang='ts' detection (Parser ctor)"] --> P["Parser loop<br/>(compiler-parser_parser-core)"]
    P -->|"state(parser) · match/eat/read ·<br/>stack + fragments"| STATES["parsing states<br/>(this module)"]
    STATES -->|"appends"| AST["AST nodes<br/>(compiler-core_type_definitions):<br/>Root · RegularElement · Component ·<br/>Svelte* meta nodes · Text · ExpressionTag ·<br/>Comment · Attribute · directives ·<br/>SpreadAttribute · AttachTag"]
    AST --> OPT["root.options<br/>via read_options<br/>(compiler-parser_options-reading)"]
    OPT --> AN["compiler-analyzer<br/>(validation · scopes · CSS)"]
    AN --> TR["compiler-transformer<br/>(client / server codegen)"]
```

**Inputs**
- The template string and `loose` flag (threaded through from `compile`/`compileModule` in [compiler-core_public_api](compiler-core_public_api.md)).
- `Parser` facilities: `match`, `eat`, `match_regex`, `read`, `read_until`, `read_identifier`, `allow_whitespace`, `require_whitespace`, `append`, `pop`, `current`.

**Outputs**
- A populated `AST.Root` (`root.fragment`, `root.instance`/`root.module` from `<script>`, `root.css` from `<style>`, `root.options` via [compiler-parser_options-reading](compiler-parser_options-reading.md), `root.comments`).
- Per-node `metadata.expression` slots (initially empty), filled by the [compiler-analyzer](compiler-analyzer.md).

---

## 8. Related Modules

| Module | Relationship |
|---|---|
| [compiler-parser_parser-core](compiler-parser_parser-core.md) | Owns `parse()`, the `Parser` class, and the driving loop that invokes these states. |
| [compiler-parser_parsing-utilities](compiler-parser_parsing-utilities.md) | HTML entity decoding (`decode_character_references`, `get_entity_pattern`) used by `text`, `read_sequence`, and attribute readers; fuzzy matching for error hints. |
| [compiler-parser_js-ts-parsing](compiler-parser_js-ts-parsing.md) | `read_expression` (acorn-based) used by attribute values, `element` interpolation, and `read_script`/`read_style` for top-level tags; TypeScript node stripping. |
| [compiler-parser_options-reading](compiler-parser_options-reading.md) | Converts the parsed `<svelte:options>` node into validated compile options. |
| [compiler-core_type_definitions](compiler-core_type_definitions.md) | Canonical AST shapes produced by these states (`template.d.ts`, `legacy-nodes.d.ts`, `css.d.ts`, `index.d.ts`). |
| [compiler-core_diagnostics](compiler-core_diagnostics.md) | All `e.*` errors and `w.*` warnings emitted here; code frames via `compile_diagnostic`. |
| [compiler-analyzer](compiler-analyzer.md) | First consumer of the AST: validates placements, scopes, CSS — the `metadata` objects initialized here are its input slots. |
| [compiler-transformer](compiler-transformer.md) | Consumes the analyzed AST to generate client/server output. |

### Extension Guide

- **New directive type:** add the prefix mapping in `get_directive_type`, the AST type in [compiler-core_type_definitions](compiler-core_type_definitions.md), validation in [compiler-analyzer](compiler-analyzer.md), and codegen in [compiler-transformer](compiler-transformer.md). The duplicate-check loop in `element` may need the normalized-key rule updated.
- **New `svelte:*` meta tag:** extend the `meta_tags` / `root_only_meta_tags` maps in `element.js` and add the corresponding AST type and transform visitors.
- **Loose-mode recovery:** follow the established pattern — record the construct's start offset, verify with lookahead on `parser.template`, then restore `parser.index` instead of throwing.