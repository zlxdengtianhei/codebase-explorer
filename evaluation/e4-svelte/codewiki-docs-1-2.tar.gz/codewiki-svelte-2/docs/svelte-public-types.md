# svelte-public-types

## 1. Overview

`svelte-public-types` is the **public TypeScript contract of the `svelte` package**. It consists of a single artifact — `packages/svelte/types/index.d.ts` — which is a *generated* ambient declaration file describing every public type, function and namespace that downstream TypeScript users can import from `svelte` and its subpath exports (`svelte/compiler`, `svelte/store`, `svelte/motion`, `svelte/transition`, `svelte/reactivity`, `svelte/legacy`, `svelte/server`, `svelte/action`, `svelte/attachments`, `svelte/animate`, `svelte/easing`, `svelte/events`, and the deprecated `svelte/types/compiler/*` paths).

Key facts:

| Property | Value |
| --- | --- |
| Artifact | `packages/svelte/types/index.d.ts` |
| Nature | **Generated, committed** — never edited by hand |
| Generator | `packages/svelte/scripts/generate-types.js` (uses `dts-buddy`'s `createBundle`) |
| Inputs | `src/index.d.ts`, `src/ambient.d.ts`, per-feature `public.d.ts` files, and JSDoc-annotated JS modules |
| Shape | A series of `declare module '<name>' { ... }` ambient blocks + global rune declarations (`$state`, `$derived`, `$effect`, `$props`, `$bindable`, `$inspect`, `$host`) |
| Consumers | Application code, component libraries, `svelte-check` / Svelte language tools, bundler plugins |

The module is intentionally **compile-time only**: every declaration in this file is a type-level description of behaviour implemented by the runtime modules. The implementations live in sibling modules of this documentation set (see [§4 Module inventory](#4-module-inventory) for the mapping), so this document describes *what the contract guarantees* and links to the modules that *fulfil* it.

## 2. Position in the system

This module sits under **Public_API___Built-in_Feature_Surface** alongside the runtime feature modules it documents. Its neighbours:

- [public-api](public-api.md) — client/server entry points (`mount`, `hydrate`, `unmount`, lifecycle helpers) whose signatures are typed by the `declare module 'svelte'` block.
- [stores](stores.md), [motion](motion.md), [transitions-animations-easing](transitions-animations-easing.md), [reactive-builtins](reactive-builtins.md), [actions-attachments](actions-attachments.md) — feature implementations whose public contracts are declared here.
- [svelte_dom_type_definitions](svelte_dom_type_definitions.md) — the companion `packages/svelte/elements.d.ts` / `svelte-html.d.ts` DOM element typings (a separate generated file, out of scope here).
- Upstream, `compiler-core_type_definitions` ([compiler-core_type_definitions](compiler-core_type_definitions.md)) holds the *internal* compiler AST types; the `AST` namespace published via `svelte/compiler` here is the *public, API-stable* mirror of that surface.

```mermaid
flowchart TB
    subgraph Pkg["svelte package"]
        GEN["scripts/generate-types.js<br/>(build-time)"]
        DTS["types/index.d.ts<br/><b>svelte-public-types (this module)</b>"]
        ELS["elements.d.ts / svelte-html.d.ts<br/>(svelte_dom_type_definitions)"]
        SRC["src/ runtime + compiler sources"]
    end
    subgraph Down["Downstream"]
        APP["Application code (TS)"]
        LIB["Component libraries"]
        TOOLS["svelte-check / language-tools / bundler plugins"]
    end

    SRC -->|"JSDoc + public.d.ts entry points"| GEN
    GEN --> DTS
    GEN --> ELS
    DTS --> APP
    DTS --> LIB
    DTS --> TOOLS
```

## 3. Generation pipeline

`types/index.d.ts` is produced by `scripts/generate-types.js`. The script:

1. **Writes re-export stubs** so that TypeScript setups without `moduleResolution: 'bundler'` can resolve subpath imports. Each stub (e.g. `action.d.ts`, `store.d.ts`, `compiler.d.ts`, `types/compiler/preprocess.d.ts`) contains exactly one statement: `import './types/index.js';`, which pulls the ambient declarations into the program.
2. **Bundles declarations** with `dts-buddy#createBundle`, mapping each public import path to its *source of truth*:

| Ambient module | Generation input (source of truth) |
| --- | --- |
| `svelte` | `src/index.d.ts` (which side-effect imports `src/ambient.d.ts` for `*.svelte` + runes) |
| `svelte/action` | `src/action/public.d.ts` |
| `svelte/animate` | `src/animate/public.d.ts` |
| `svelte/attachments` | `src/attachments/public.d.ts` |
| `svelte/compiler` | `src/compiler/public.d.ts` |
| `svelte/easing` | `src/easing/index.js` (types inferred from JSDoc) |
| `svelte/legacy` | `src/legacy/legacy-client.js` (JSDoc) |
| `svelte/motion` | `src/motion/public.d.ts` |
| `svelte/reactivity` | `src/reactivity/index-client.js` |
| `svelte/reactivity/window` | `src/reactivity/window/index.js` |
| `svelte/server` | `src/server/index.d.ts` |
| `svelte/store` | `src/store/public.d.ts` |
| `svelte/transition` | `src/transition/public.d.ts` |
| `svelte/events` | `src/events/public.d.ts` |
| `svelte/types/compiler/preprocess` *(deprecated)* | `src/compiler/preprocess/legacy-public.d.ts` |
| `svelte/types/compiler/interfaces` *(deprecated)* | `src/compiler/types/legacy-interfaces.d.ts` |

3. **Enforces invariants** (see [§7 Design invariants](#7-design-invariants-and-generator-guards)): strips `@internal` declarations (`stripInternal: true`), rejects relative links in JSDoc (they must be absolute `https://svelte.dev/...`), and rejects `export { ... }` re-export statements which break downstream `.d.ts` generation.

```mermaid
flowchart LR
    subgraph Sources["Type sources (src/)"]
        IDX["src/index.d.ts<br/>'svelte' surface"]
        AMB["src/ambient.d.ts<br/>'*.svelte' module + runes"]
        PUBS["per-feature public.d.ts files<br/>action · animate · attachments · compiler<br/>motion · server · store · transition · events"]
        JSDOC["JSDoc-annotated JS<br/>easing · legacy · reactivity<br/>reactivity/window"]
        LEG["legacy shims<br/>compiler/preprocess/legacy-public.d.ts<br/>compiler/types/legacy-interfaces.d.ts"]
    end

    GEN["scripts/generate-types.js<br/>dts-buddy createBundle<br/>stripInternal · link check · export check"]
    DTS["types/index.d.ts<br/>(ambient module declarations)"]
    STUBS["Stub re-exports:<br/>index · compiler · action · animate · easing<br/>motion · store · transition · legacy<br/>types/compiler/preprocess · interfaces"]

    IDX --> GEN
    AMB --> GEN
    PUBS --> GEN
    JSDOC --> GEN
    LEG --> GEN
    GEN --> DTS
    GEN --> STUBS
    DTS --> USERS["TypeScript users,<br/>IDEs, tooling"]
    STUBS --> USERS
```

```mermaid
sequenceDiagram
    autonumber
    participant Dev as Maintainer
    participant Src as src/ type sources
    participant Gen as generate-types.js
    participant Dts as types/index.d.ts
    participant CI as CI / release
    participant Down as Downstream TS projects

    Dev->>Src: edit JSDoc or public.d.ts (never the generated file)
    Dev->>Gen: run type generation
    Gen->>Dts: merge modules, strip @internal, emit ambient blocks
    Gen->>Gen: fail on relative JSDoc links / export {...} statements
    Dts-->>Dev: reviewed + committed artifact
    CI->>Down: publish package (types resolved via stubs)
    Down->>Dts: import type { Component } from 'svelte'
```

## 4. Module inventory

The file is organised as one `declare module` block per public import path, plus global ambient declarations. Each block maps to a runtime implementation documented elsewhere — follow the links instead of re-reading type bodies here.

| Declaration block | Representative exports | Runtime implementation docs |
| --- | --- | --- |
| `'svelte'` | `Component`, `ComponentInternals`, `SvelteComponent`, `SvelteComponentTyped`, `ComponentConstructorOptions`, `ComponentProps`, `ComponentEvents`, `ComponentType`, `MountOptions`, `Snippet`, `EventDispatcher`, `DispatchOptions`; `mount`, `hydrate`, `unmount`, `tick`, `settled`, `flushSync`, `untrack`, `createRawSnippet`, `getAbortSignal`; `onMount`, `onDestroy`, `beforeUpdate`, `afterUpdate`, `createEventDispatcher`; `setContext`, `getContext`, `hasContext`, `getAllContexts` | [public-api](public-api.md), [context-api](context-api.md), [client-reactivity-engine](client-reactivity-engine.md) |
| `'svelte/action'` | `Action`, `ActionReturn` | [actions-attachments](actions-attachments.md) |
| `'svelte/attachments'` | `Attachment`, `createAttachmentKey`, `fromAction` | [actions-attachments](actions-attachments.md) |
| `'svelte/animate'` | `AnimationConfig`, `FlipParams`, `flip` | [transitions-animations-easing](transitions-animations-easing.md) |
| `'svelte/compiler'` | `compile`, `compileModule`, `parse` (overloads), `preprocess`, `migrate`, `walk` (deprecated), `VERSION`; `CompileOptions`, `ModuleCompileOptions`, `CompileResult`, `Warning`, `CompileError`, `Namespace`; `Processed`, `MarkupPreprocessor`, `Preprocessor`, `PreprocessorGroup`; `AST` namespace | [compiler-core](compiler-core.md), [compiler-core_type_definitions](compiler-core_type_definitions.md), [compiler-preprocessor](compiler-preprocessor.md), [compiler-migrator](compiler-migrator.md) |
| `'svelte/easing'` | `linear`, `backIn/Out`, `bounceIn/Out`, `circIn/Out`, `cubicIn/Out`, `elasticIn/Out`, `expoIn/Out`, `quadIn/Out`, `quartIn/Out`, `quintIn/Out`, `sineIn/Out` (+ `InOut` variants) | [transitions-animations-easing](transitions-animations-easing.md) |
| `'svelte/legacy'` | `createClassComponent`, `asClassComponent`, `run`, `handlers`, `createBubbler`, `LegacyComponentType`, event-modifier substitutes (`preventDefault`, `stopPropagation`, `stopImmediatePropagation`, `self`, `trusted`, `once`, `passive`, `nonpassive`) | [legacy-compat](legacy-compat.md) |
| `'svelte/motion'` | `Spring`, `Tween` (classes), `spring`, `tweened` (deprecated stores), `Tweened`, `SpringOpts`, `SpringUpdateOpts`, `TweenedOptions`, `prefersReducedMotion` | [motion](motion.md) |
| `'svelte/reactivity'` | `SvelteDate`, `SvelteSet`, `SvelteMap`, `SvelteURL`, `SvelteURLSearchParams`, `MediaQuery`, `ReactiveValue`, `createSubscriber` | [reactive-builtins](reactive-builtins.md) |
| `'svelte/reactivity/window'` | `scrollX`, `scrollY`, `innerWidth`, `innerHeight`, `outerWidth`, `outerHeight`, `screenLeft`, `screenTop`, `online`, `devicePixelRatio` | [reactive-builtins](reactive-builtins.md) |
| `'svelte/server'` | `render`, `RenderOutput` | [server-runtime](server-runtime.md) |
| `'svelte/store'` | `Readable`, `Writable`, `Subscriber`, `Unsubscriber`, `Updater`, `StartStopNotifier`, `Stores`, `StoresValues`; `readable`, `writable`, `derived`, `readonly`, `get`, `fromStore`, `toStore` | [stores](stores.md) |
| `'svelte/transition'` | `TransitionConfig`, `EasingFunction`, `BlurParams`, `FadeParams`, `FlyParams`, `SlideParams`, `ScaleParams`, `DrawParams`, `CrossfadeParams`; `blur`, `fade`, `fly`, `slide`, `scale`, `draw`, `crossfade` | [transitions-animations-easing](transitions-animations-easing.md) |
| `'svelte/events'` | `on` (overloads for `Window`, `Document`, `HTMLElement`, `MediaQueryList`, `EventTarget`) | [client-dom-renderer](client-dom-renderer.md) |
| `'svelte/types/compiler/preprocess'` *(deprecated)* | `MarkupPreprocessor_1`, `Preprocessor_1`, `PreprocessorGroup_1`, `Processed_1`, `SveltePreprocessor_1` | [compiler-preprocessor](compiler-preprocessor.md) |
| `'svelte/types/compiler/interfaces'` *(deprecated)* | `CompileOptions_1`, `Warning_1` | [compiler-core_type_definitions](compiler-core_type_definitions.md) |
| global `declare module '*.svelte'` | default export typed as `LegacyComponentType` *and* `SvelteComponent` | [public-api](public-api.md), [legacy-compat](legacy-compat.md) |
| global rune declarations | `$state` (+ `.raw`, `.snapshot`, `Cloneable`, `Snapshot`, `NonReactive`), `$derived` (+ `.by`), `$effect` (+ `.pre`, `.pending`, `.tracking`, `.root`), `$props` (+ `.id`), `$bindable`, `$inspect` (+ `.trace`), `$host` | [client-reactivity-engine](client-reactivity-engine.md) |

```mermaid
flowchart TD
    T["types/index.d.ts"]

    T --> M1["'svelte'<br/>component model · lifecycle · mount/hydrate"]
    T --> M2["'svelte/action'"]
    T --> M3["'svelte/attachments'"]
    T --> M4["'svelte/compiler'<br/>compile · parse · preprocess · migrate · AST"]
    T --> M5["'svelte/easing'"]
    T --> M6["'svelte/legacy'"]
    T --> M7["'svelte/motion'"]
    T --> M8["'svelte/reactivity'<br/>'svelte/reactivity/window'"]
    T --> M9["'svelte/server'"]
    T --> M10["'svelte/store'"]
    T --> M11["'svelte/transition'"]
    T --> M12["'svelte/events'"]
    T --> M13["deprecated:<br/>'svelte/types/compiler/preprocess'<br/>'svelte/types/compiler/interfaces'"]
    T --> M14["ambient '*.svelte' module<br/>+ global rune declarations"]
```

## 5. Type-domain architecture

### 5.1 Component model

The `declare module 'svelte'` block encodes the Svelte 4 → 5 transition: components changed from **classes** to **functions**. The public types therefore contain a modern surface (`Component`) and a legacy surface (`SvelteComponent`, `SvelteComponentTyped`, `ComponentType`, `ComponentEvents`) kept only for compatibility. The `*.svelte` ambient module bridges both worlds by exposing the default export as `LegacyComponentType` — usable *both* as a function (`mount`-style) and as a constructor (`new`-style).

- Modern instantiation/imperative API: `mount`, `hydrate`, `unmount`, `MountOptions` — implemented by [public-api](public-api.md) (see [public-api_client_entry](public-api_client_entry.md) and [public-api_server_entry](public-api_server_entry.md)).
- Legacy shims that convert between the two shapes: `createClassComponent` / `asClassComponent` in `'svelte/legacy'` — implemented by [legacy-compat](legacy-compat.md).

```mermaid
classDiagram
    direction LR

    class Component {
        <<interface · Svelte 5>>
        invoke(internals, props) Exports
    }
    class ComponentInternals {
        <<branded · opaque>>
    }
    class SvelteComponent {
        <<class · legacy>>
        $on(type, callback) unsubscribe
        $set(props) void
        $destroy() void
    }
    class SvelteComponentTyped {
        <<deprecated alias>>
    }
    class Snippet {
        <<interface>>
        invoke(args) SnippetReturn-guard
    }
    class EventDispatcher {
        <<interface · deprecated pattern>>
        dispatch(type, detail, options) boolean
    }
    class LegacyComponentType {
        <<callable + constructable>>
    }
    class ComponentProps {
        <<utility type>>
    }
    class ComponentType {
        <<deprecated utility type>>
    }
    class MountOptions {
        target · anchor · props · context · intro
    }

    SvelteComponentTyped --|> SvelteComponent : extends
    Component ..> ComponentInternals : receives as 1st arg
    ComponentProps ..> Component : infers Props
    ComponentProps ..> SvelteComponent : infers Props
    ComponentType ..> SvelteComponent : constructor shape
    LegacyComponentType ..> Component : callable form
    LegacyComponentType ..> SvelteComponent : constructable form
```

Notable design details worth knowing when touching this file:

- `ComponentInternals` is a *branded* type (`Branded<{}, 'ComponentInternals'>`) so user code cannot construct or fake it.
- `Snippet`'s call signature deliberately rejects rest-parameter-style arrays (via `number extends Parameters['length'] ? never : Parameters`) and its return type embeds a self-documenting error message if called directly instead of through `{@render ...}`.
- `SvelteComponent` carries type-checking-only members (`$$prop_def`, `$$events_def`, `$$slot_def`) that **do not exist at runtime**.
- The internal `Properties<Props, Slots>` helper conditionally injects `children?: any` when a component has a default slot — the reason "no props" components type-check loosely.

### 5.2 Runes and the `*.svelte` ambient layer

`src/ambient.d.ts` (merged into the generated file via `src/index.d.ts`) declares two globally-visible things:

1. **`declare module '*.svelte'`** — teaches TypeScript what importing a `.svelte` file yields (a dual callable/constructable component). Language tools override this for richer inference, but it is the baseline.
2. **Rune declarations** — `$state`, `$derived`, `$effect`, `$props`, `$bindable`, `$inspect`, `$host` are ambient *functions with a namespace companion*, giving pseudo-methods (`$state.snapshot`, `$effect.root`, `$props.id`, …) typed signatures even though runes are compile-time constructs rewritten by the compiler (see [compiler-transformer_client-transform](compiler-transformer_client-transform.md) for the transformation, and [client-reactivity-engine](client-reactivity-engine.md) for the runtime). Each namespace also re-declares `Function.prototype` members as `never` to stop editor auto-complete from offering irrelevant suggestions.

`$state` additionally exports the `Snapshot<T>` / `Cloneable` conditional types used by `$state.snapshot` — a small type-level model of the structured-clone algorithm that also unwraps `SvelteDate`/`SvelteMap`/`SvelteSet` back to their native counterparts (`NonReactive<T>`).

### 5.3 Compiler surface (`svelte/compiler`)

The largest declaration block. It mirrors — but is deliberately **decoupled from** — the internal compiler types (see [compiler-core_type_definitions](compiler-core_type_definitions.md)). Components:

- **Entry functions**: `compile`, `compileModule`, `parse` (two overloads: `modern: true` → `AST.Root`, legacy → `Record<string, any>`), `preprocess`, `migrate`, `walk` (deprecated → `estree-walker`), `VERSION`.
- **Options**: `ModuleCompileOptions` (`dev`, `generate`, `filename`, `rootDir`, `warningFilter`, `experimental.async`) extended by `CompileOptions` (`runes`, `css`, `cssHash`, `customElement`, `fragments`, `hmr`, `modernAst`, …). Deprecated legacy options exist as documented footguns (`accessors`, `immutable`).
- **Results & diagnostics**: `CompileResult` (js/css artifacts + `warnings` + `metadata.runes`), `Warning` and `CompileError` both extending the `ICompileDiagnostic` shape (`code`, `message`, `start`/`end` `Location`s, `position`, `frame`). The set of possible `code` values is generated from the message templates — see [message_code_generation_templates](message_code_generation_templates.md).
- **Preprocessor contracts**: `Processed`, `MarkupPreprocessor`, `Preprocessor`, `PreprocessorGroup` — implemented by [compiler-preprocessor](compiler-preprocessor.md). Note `map?: string | object` is intentionally *opaque* so the public types never depend on the source-map-remapping library.
- **`AST` namespace** — the public template AST:

```mermaid
flowchart TD
    ROOT["AST.Root"] --> FRAG["AST.Fragment"]
    ROOT --> OPT["AST.SvelteOptions"]
    ROOT --> SHEET["AST.CSS.StyleSheet"]
    ROOT --> SCRIPT["AST.Script<br/>(instance / module)"]
    FRAG --> KINDS["Text · Comment<br/>Tag · ElementLike · Block"]

    TAG["Tag union"] --> ET["ExpressionTag"] & HT["HtmlTag"] & CT["ConstTag"] & DT["DebugTag"] & RT["RenderTag"] & AT["AttachTag"]

    EL["ElementLike union"] --> RE["RegularElement"] & CO["Component"] & SE["SvelteBody · SvelteBoundary · SvelteDocument<br/>SvelteElement · SvelteFragment · SvelteHead<br/>SvelteOptionsRaw · SvelteSelf · SvelteWindow"] & TE["TitleElement"] & SLE["SlotElement"]

    BL["Block union"] --> EB["EachBlock"] & IB["IfBlock"] & AB["AwaitBlock"] & KB["KeyBlock"] & SB["SnippetBlock"]

    DIR["Directive union"] --> AD["AnimateDirective"] & BD["BindDirective"] & CD["ClassDirective"] & LD["LetDirective"] & OD["OnDirective"] & SD["StyleDirective"] & TD["TransitionDirective"] & UD["UseDirective"]

    SHEET --> RULE["Rule · Atrule · Block · Declaration"]
    RULE --> SL["SelectorList"] --> CXS["ComplexSelector"] --> RS["RelativeSelector"] --> SS["SimpleSelector union:<br/>TypeSelector · IdSelector · ClassSelector · AttributeSelector<br/>PseudoElementSelector · PseudoClassSelector<br/>Percentage · Nth · NestingSelector"]
```

All template nodes share `BaseNode` (`type`, `start`, `end`); element-like nodes share `BaseElement` (`name`, `attributes`, `fragment`). The CSS sub-namespace is declared as `_CSS` and re-exported as `AST.CSS` so the [compiler-analyzer_css_analysis](compiler-analyzer_css_analysis.md) and [compiler-transformer_css_transform](compiler-transformer_css_transform.md) passes have a stable public shape for selector inspection (e.g. `css_unused_selector` warnings carry these nodes).

### 5.4 Stores contract

`declare module 'svelte/store'` defines the **store contract** (`Readable`, `Writable`, `Subscriber`, `Unsubscriber`, `Updater`, `StartStopNotifier`, plus the `Stores`/`StoresValues` helper generics) and the factory functions `readable`, `writable`, `derived`, `readonly`, `get`, as well as the runes bridges `fromStore` / `toStore`. The implementation is documented in [stores](stores.md) (contract in [stores_contract](stores_contract.md), bridges in [stores_bridge](stores_bridge.md)). Note that the store contract is consumed *by the compiler and runtime* too — e.g. `store_get` / `invalidate_store` in [client-reactivity-engine_props_and_stores](client-reactivity-engine_props_and_stores.md) operate on exactly these interfaces.

### 5.5 Reactivity built-ins

`'svelte/reactivity'` declares `SvelteMap`, `SvelteSet`, `SvelteDate`, `SvelteURL`, `SvelteURLSearchParams`, `MediaQuery` (extending the internal-but-public `ReactiveValue<T>` base) and `createSubscriber`. `'svelte/reactivity/window'` declares the singleton reactive window values (`scrollX`, `innerWidth`, `devicePixelRatio`, `online`, …) all typed as `ReactiveValue<number | undefined>`-style getters that are `undefined` on the server. Implementations: [reactive-builtins](reactive-builtins.md).

### 5.6 Motion

`'svelte/motion'` declares the Svelte 5 classes `Spring<T>` / `Tween<T>` (with static `.of()` factories, `target`/`current` accessors) alongside the deprecated store factories `spring()` / `tweened()` and their `Tweened<T>` interface — with declaration merging keeping the old `Spring` interface (extends `Readable`) and the new class in one name. `prefersReducedMotion` is exported here as a `MediaQuery` instance (its *type* comes from `'svelte/reactivity'`, an example of cross-block dependency inside the file). Implementation: [motion](motion.md).

### 5.7 Transitions, animations, easing

`'svelte/transition'` types the built-in transition functions and their parameter objects (`TransitionConfig`, `BlurParams`, `FadeParams`, `FlyParams`, `SlideParams`, `ScaleParams`, `DrawParams`, `CrossfadeParams`); `'svelte/animate'` types `flip` with `AnimationConfig`/`FlipParams`; `'svelte/easing'` carries the 31 easing functions inferred straight from JSDoc'd JS. Implementations: [transitions-animations-easing](transitions-animations-easing.md). The `css`/`tick` callback shape of `TransitionConfig`/`AnimationConfig` is what the runtime transition engine in [client-dom-renderer_transitions](client-dom-renderer_transitions.md) consumes.

### 5.8 Actions, attachments and events

`'svelte/action'` defines the `Action`/`ActionReturn` contract (including the type-checking-only `$$_attributes` mechanism for attribute augmentation); `'svelte/attachments'` defines `Attachment`, `createAttachmentKey`, and `fromAction` — the latter's signature *references* `Action`/`ActionReturn`, i.e. the attachments module depends on the action module's types. `'svelte/events'` provides the overloaded `on()` helper. Implementations: [actions-attachments](actions-attachments.md), [actions-attachments_attachment_bridge](actions-attachments_attachment-bridge.md), and the delegated-event machinery in [client-dom-renderer_attributes_events](client-dom-renderer_attributes-events.md).

### 5.9 Server rendering

`'svelte/server'` declares `render()` with a conditional-arity signature (props optional only when the component's props are all-optional) returning `RenderOutput { head, body, html (deprecated) }`. Implemented by [server-runtime](server-runtime.md); the payload/id-generation behaviour implied by `idPrefix` is covered in [server-runtime_payload_and_output](server-runtime_payload-and-output.md).

### 5.10 Legacy compatibility

`'svelte/legacy'` declares `createClassComponent`, `asClassComponent`, `run`, `handlers`, `createBubbler`, the `LegacyComponentType` dual-shape type, and function-wrapping substitutes for the old `on:` event modifiers. All marked `@deprecated` with migration links. Implemented by [legacy-compat](legacy-compat.md) ([legacy-compat_component_api_shims](legacy-compat_component-api-shims.md)).

### 5.11 Deprecated alias modules

Two legacy import paths exist purely so tooling that historically imported them (`svelte/types/compiler/preprocess`, `svelte/types/compiler/interfaces`) keeps working across Svelte 4/5/6. They are **type aliases only**, resolved at generation time to canonical names. The `_1` suffixes in the exported names (`Processed_1`, `CompileOptions_1`, `Warning_1`, `SveltePreprocessor_1`, `MarkupPreprocessor_1`, `Preprocessor_1`, `PreprocessorGroup_1`) are an artifact of `dts-buddy` renaming duplicates when merging modules with same-named types.

```mermaid
flowchart LR
    subgraph Dep["Deprecated import paths"]
        DP["svelte/types/compiler/preprocess"]
        DI["svelte/types/compiler/interfaces"]
    end
    subgraph Cur["Canonical targets"]
        C1["svelte/compiler<br/>Processed · MarkupPreprocessor · Preprocessor<br/>PreprocessorGroup · SveltePreprocessor"]
        C2["svelte<br/>CompileOptions · Warning"]
    end
    DP -->|"alias chain"| C1
    DI -->|"alias chain"| C2
```

## 6. Intra-file dependency graph

Although the file is one artifact, its declaration blocks reference each other. These edges are the reason the generator must bundle *all* modules in one pass:

```mermaid
flowchart TD
    SVT["declare module '*.svelte'"]
    SV["'svelte'"]
    LEG["'svelte/legacy'"]
    SRV["'svelte/server'"]
    MOT["'svelte/motion'"]
    REA["'svelte/reactivity'"]
    ATT["'svelte/attachments'"]
    ACT["'svelte/action'"]
    CMP["'svelte/compiler'"]
    STO["'svelte/store'"]

    SVT -->|"SvelteComponent"| SV
    SVT -->|"LegacyComponentType"| LEG
    LEG -->|"Component · SvelteComponent · ComponentType<br/>ComponentConstructorOptions"| SV
    SRV -->|"ComponentProps · Component<br/>SvelteComponent · ComponentType"| SV
    MOT -->|"MediaQuery for prefersReducedMotion"| REA
    ATT -->|"Action · ActionReturn for fromAction"| ACT
    SV -->|"Readable consumed by Spring interface"| STO
```

Consequences for maintainers:

- Renaming or restructuring a type in `'svelte'` (e.g. `Component`) ripples into `'svelte/legacy'`, `'svelte/server'` and the `*.svelte` ambient module in the same regeneration run — the bundler will fail loudly if a referenced type disappears.
- `mount` / `hydrate` accept both `ComponentType<SvelteComponent<Props>>` and `Component<Props, Exports>` on purpose: this is the type-level seam that lets Svelte 4-style and Svelte 5-style components coexist during migration.

## 7. Design invariants and generator guards

The generator enforces rules that contributors must respect in *source* files:

1. **`stripInternal: true`** — anything tagged `@internal` (and types reachable only through it) never reaches the public file. This is the mechanism that keeps e.g. internal `Signal` machinery (see [client-reactivity-engine_signal_graph](client-reactivity-engine_signal-graph.md)) invisible.
2. **Absolute documentation links** — every JSDoc link must start with `https://svelte.dev`; relative links fail the build (they would be dead in editors once types are copied into `node_modules`).
3. **No `export { ... }` statements** — declarations must be exported inline (`export interface Foo {}`), because TypeScript fails to follow re-export lists when downstream packages generate their own `.d.ts` via `@sveltejs/package`.
4. **Opaque where possible** — deliberately loose types (e.g. `Processed['map']`, `CompileResult['ast']`) prevent private dependencies from leaking into the public surface.
5. **Stubs for all TS module resolutions** — subpath entry files exist only to `import './types/index.js'`; imports in them must end in `.js` to resolve in every TS `moduleResolution` mode.
6. **Deprecations are typed, not deleted** — legacy types survive with `@deprecated` JSDoc (surfaced as editor strikethroughs) and migration-guide links; removal is deferred to major versions (e.g. `svelte/types/compiler/*` shims are slated for removal in Svelte 6).

## 8. Process flow: changing a public type

```mermaid
flowchart TD
    A["Need a public type change"] --> B["Locate the source of truth<br/>(public.d.ts, index.d.ts, ambient.d.ts or JSDoc'd JS)"]
    B --> C["Edit the source file + JSDoc<br/>(use https://svelte.dev links, mark @internal / @deprecated appropriately)"]
    C --> D["Regenerate types/index.d.ts + stubs"]
    D --> E{"Generator guards pass?"}
    E -->|"No"| C
    E -->|"Yes"| F["Review the committed diff of types/index.d.ts<br/>(it is the public API changelog)"]
    F --> G["Runtime implementation updated in the owning module<br/>(see module links in §4)"]
    G --> H["Tests: type tests, runtime tests,<br/>treeshakeability check"]
```

## 9. Relationship to other type surfaces

| Surface | File | Doc |
| --- | --- | --- |
| Public API types (this module) | `packages/svelte/types/index.d.ts` | — |
| DOM element/attribute typings (`SvelteHTMLElements`, `AriaAttributes`, `HTMLMediaAttributes`, `DOMAttributes`, `IntrinsicElements`) | `packages/svelte/elements.d.ts`, `packages/svelte/svelte-html.d.ts` | [svelte_dom_type_definitions](svelte_dom_type_definitions.md) |
| Internal compiler AST / options types | `src/compiler/types/*.d.ts` | [compiler-core_type_definitions](compiler-core_type_definitions.md) |
| Runtime signal types (private) | `src/internal/client/reactivity/types.d.ts` (`Signal`) | [client-reactivity-engine_signal_graph](client-reactivity-engine_signal-graph.md) |
| Server render output (private) | `src/internal/server/types.d.ts` (`RenderOutput` impl-side) | [server-runtime_payload_and_output](server-runtime_payload-and-output.md) |

Together, `types/index.d.ts` and `elements.d.ts` form the complete published type story of `svelte`; everything else is internal and stripped or never exposed.

## 10. Maintenance checklist

- **Never edit `types/index.d.ts` directly** — it is regenerated; edits will be silently overwritten.
- To add a new public subpath: create the feature's `public.d.ts`, add it to the `modules` map in `generate-types.js`, and (if needed for non-bundler resolution) to the stub-file loop.
- To deprecate: keep the type, add `@deprecated` + migration link; do not remove until a major release.
- To remove legacy shims (`svelte/types/compiler/*`): delete the two entries and stub writes in the generator — the script already marks them "TODO remove in Svelte 6".
- When adding runes or rune sub-APIs, update `src/ambient.d.ts` (function overload + namespace + intellisense-blocking `never` members) — the compiler-side enforcement lives in the analyzer visitors ([compiler-analyzer_visitors](compiler-analyzer_visitors.md)) and `throw_rune_error` in [public-api_client_entry](public-api_client_entry.md).

## 11. Related documentation

- Parent module: [Public_API___Built-in_Feature_Surface](Public_API___Built-in_Feature_Surface.md)
- Runtime contracts implemented by: [public-api](public-api.md) · [stores](stores.md) · [motion](motion.md) · [transitions-animations-easing](transitions-animations-easing.md) · [reactive-builtins](reactive-builtins.md) · [actions-attachments](actions-attachments.md) · [legacy-compat](legacy-compat.md) · [context-api](context-api.md) · [server-runtime](server-runtime.md) · [client-dom-renderer](client-dom-renderer.md) · [client-reactivity-engine](client-reactivity-engine.md)
- Compiler contracts implemented by: [compiler-core](compiler-core.md) · [compiler-core_type_definitions](compiler-core_type_definitions.md) · [compiler-preprocessor](compiler-preprocessor.md) · [compiler-parser](compiler-parser.md) · [compiler-analyzer](compiler-analyzer.md) · [compiler-transformer](compiler-transformer.md) · [compiler-migrator](compiler-migrator.md) · [message_code_generation_templates](message_code_generation_templates.md)
- Companion DOM typings: [svelte_dom_type_definitions](svelte_dom_type_definitions.md)
