# Stores Bridge (`stores_bridge`)

## 1. Introduction

The **stores bridge** module is the interop layer between Svelte's two state paradigms:

1. **The store contract** — the classic `svelte/store` ecosystem of `Readable`/`Writable` objects with an `subscribe`/`set` interface (defined in [stores_contract](stores_contract.md), implemented by [stores_core](stores_core.md)).
2. **The runes signal system** — the fine-grained reactive signal graph (`$state`, `$derived`, effects) that powers Svelte 5 components, owned by the [Client Reactivity Engine](client-reactivity-engine_signal-graph.md).

The module exposes exactly two adapters, each available in a client and a server variant:

| Adapter | Direction | Client (`index-client.js`) | Server (`index-server.js`) |
|---|---|---|---|
| `toStore(get, set?)` | **runes → store** | Live, lazily-tracked bridge backed by effects | Static snapshot of one evaluation |
| `fromStore(store)` | **store → runes** | Reactive `{ current }` object via `createSubscriber` | Pull-based `{ current }` object via `get(store)` |

Both entry files also **re-export** the core store combinators (`derived`, `get`, `readable`, `readonly`, `writable`) from [stores_core](stores_core.md), so that `svelte/store` remains a complete, self-contained public module (see [public-api](public-api.md)).

Both adapters are **type-polymorphic overloads**:

- `toStore(get)` returns a `Readable<V>`; `toStore(get, set)` returns a `Writable<V>`.
- `fromStore(writableStore)` returns `{ current: V }` (readable *and* writable); `fromStore(readableStore)` returns `{ readonly current: V }`.

---

## 2. Architecture and Position in the System

`svelte/store` resolves to one of the two entry files through package export conditions (browser/client builds get `index-client.js`, server/SSR builds get `index-server.js`) — the same conditional-export strategy used by the main `svelte` entry described in [public-api](public-api.md).

```mermaid
flowchart TD
    ENTRY["svelte/store<br/>(public entry point)"]

    subgraph BRIDGE["stores_bridge (this module)"]
        IC["index-client.js<br/>toStore · fromStore (reactive)"]
        IS["index-server.js<br/>toStore · fromStore (snapshot)"]
    end

    subgraph CORE["stores_core"]
        SHARED["store/shared/index.js<br/>writable · get · derived · readable · readonly"]
    end

    subgraph ENGINE["Client Reactivity Engine"]
        EFFECTS["reactivity/effects.js<br/>effect_root · render_effect · effect_tracking"]
        RUNTIME["runtime.js signal graph<br/>active_effect · active_reaction<br/>set_active_effect · set_active_reaction"]
        SUBS["reactivity/create-subscriber.js<br/>createSubscriber"]
    end

    TYPES["stores_contract<br/>Readable · Writable types"]

    ENTRY -->|"client/browser condition"| IC
    ENTRY -->|"server/node condition"| IS
    IC -->|"re-exports + calls writable()/get()"| SHARED
    IS -->|"re-exports + calls writable()/get()"| SHARED
    IC --> EFFECTS
    IC --> RUNTIME
    IC --> SUBS
    IC -.->|"typed as"| TYPES
    IS -.->|"typed as"| TYPES
```

Key architectural properties:

- **Asymmetric dependency footprint.** The server entry depends only on [stores_core](stores_core.md) (no reactive primitives), keeping the SSR bundle lean and free of client runtime code. The client entry additionally reaches into the [Client Reactivity Engine](client-reactivity-engine_signal-graph.md) (effects) and the `createSubscriber` primitive from [reactive-builtins](reactive-builtins.md).
- **Thin translation layer.** Neither adapter implements its own notification or scheduling logic; `toStore` composes on top of `writable()` from [stores_core](stores_core.md), and `fromStore` delegates to `createSubscriber` + the effect system.
- **Mirror-shaped API.** Both entries export the identical function names and overload signatures, so application code is identical on client and server; only the behavior (live-reactive vs. pull-based snapshot) differs.

---

## 3. Component Reference

### 3.1 `toStore(get, set?)` — runes → store

Creates a store from a getter function that reads runes state, with an optional setter that makes the store writable.

```js
import { toStore } from 'svelte/store';

let count = $state(0);

const store = toStore(() => count, (v) => (count = v));
```

#### Client implementation (`index-client.js`)

The client version keeps the bridge *live* by binding the getter to the reactive context that existed when `toStore` was called:

1. **Context capture.** On invocation, the current `active_effect` and `active_reaction` are captured from the [signal graph runtime](client-reactivity-engine_signal-graph.md). This binds the store's internal tracking to the owner context (typically the component initialization effect), ensuring correct teardown when the component is destroyed.
2. **Initial snapshot.** `get()` is evaluated once; the result seeds a `writable(init_value, start)` from [stores_core](stores_core.md).
3. **Lazy start.** The `start` callback runs only when the first subscriber arrives:
   - `ran = init_value !== get()` — if the underlying state already changed between `toStore()` and the first `subscribe()`, the change is treated as *already applied*, avoiding a redundant push.
   - Inside an `effect_root` → `render_effect` pair (see [client-reactivity-engine_effects](client-reactivity-engine_effects.md)), the captured reaction/effect context is temporarily restored via `set_active_reaction` / `set_active_effect`, the getter is tracked, and its value is pushed with `set(value)`. The previous context is restored in a `finally` block.
   - `ran` flips to `true` after the first run; every subsequent re-run of the render effect (i.e., whenever a tracked dependency changes) pushes the new value to store subscribers.
4. **Teardown.** The `effect_root` cleanup function is returned, so the underlying tracking effect is destroyed when the last subscriber unsubscribes.

#### Server implementation (`index-server.js`)

The server has no signal graph, so `toStore` degenerates to a snapshot: `writable(get())`. The `set`/`update` methods still delegate to the user-provided setter, and `update` calls `set(fn(get()))` with a *fresh* evaluation of the getter — but `subscribe` will always yield the value captured at creation time. Reactivity simply does not exist server-side (compare with [server-runtime](server-runtime.md)).

#### Resulting shapes

```js
// with setter → Writable<V>
{ set: (v) => ..., update: (fn) => set(fn(get())), subscribe }

// without setter → Readable<V>
{ subscribe }
```

Note that `update` reads the **source expression** via `fn(get())` (a fresh getter call), not the store's internally cached value.

---

### 3.2 `fromStore(store)` — store → runes

Wraps a store in an object with a reactive `current` property, making store values readable/writable through normal property syntax in runes code.

```js
import { fromStore, get, writable } from 'svelte/store';

const store = writable(0);
const count = fromStore(store);

count.current;  // 0
store.set(1);
count.current;  // 1

count.current += 1;
get(store);     // 2
```

#### Client implementation (`index-client.js`)

- **Lazy, ref-counted subscription.** The subscription to the store is created through `createSubscriber` from [reactive-builtins](reactive-builtins.md). The underlying `store.subscribe` only starts while at least one reactive consumer is reading `current`, and is torn down (via a microtask-delayed ref-count) once nobody is reading.
- **Version-based invalidation.** The subscriber callback caches the latest value in `value`; after the first synchronous emission, every subsequent emission calls `update()`, which increments an internal version signal. That invalidates dependent deriveds/effects, which re-run and re-read `current` — this is how store updates propagate into the signal graph.
- **Context-aware read.** The `current` getter checks `effect_tracking()` (from [client-reactivity-engine_effects](client-reactivity-engine_effects.md)):
  - *Inside a reactive context* → `subscribe()` (ensure the live subscription exists) and return the cached `value`. This read is properly tracked.
  - *Outside any reactive context* → fall back to `get(store)` from [stores_core](stores_core.md), a one-shot pull with no subscription.
- **Read/write shaping.** `'set' in store` distinguishes `Writable` (getter + setter, where `set current(v)` proxies to `store.set(v)`) from `Readable` (getter only).

#### Server implementation (`index-server.js`)

`current` is a plain pull-based accessor: every read executes `get(store)` (subscribe-and-unsubscribe immediately, returning the current value). The setter likewise proxies to `store.set`. No `createSubscriber` involvement — during SSR each read is a deterministic one-shot evaluation (see [server-runtime](server-runtime.md)).

---

### 3.3 Behavior Matrix

| Aspect | `toStore` client | `toStore` server | `fromStore` client | `fromStore` server |
|---|---|---|---|---|
| Reactive propagation | ✅ via tracked render effect | ❌ creation-time snapshot | ✅ via `createSubscriber` version bump | ❌ pull on each read |
| Subscription lifecycle | starts on first subscriber, ends on last unsubscribe | n/a | ref-counted, starts on tracked read | per-read subscribe/unsubscribe |
| Writes | delegate to user `set`; `update` uses fresh `get()` | same as client | `set current` → `store.set` | `set current` → `store.set` |
| Signal-graph dependencies | [stores_core](stores_core.md) + [effects](client-reactivity-engine_effects.md) + [runtime](client-reactivity-engine_signal-graph.md) | [stores_core](stores_core.md) only | [reactive-builtins](reactive-builtins.md) + [effects](client-reactivity-engine_effects.md) | [stores_core](stores_core.md) only |
| Untracked read of `current` | — | — | one-shot `get(store)` | one-shot `get(store)` |

---

## 4. Data Flow and Process Diagrams

### 4.1 Direction of the two bridges

```mermaid
flowchart LR
    subgraph RUNES["Runes world (signal graph)"]
        STATE["$state / $derived<br/>expressions"]
    end

    subgraph STORES["Store contract world"]
        STORE["Readable / Writable<br/>(subscribe · set)"]
    end

    TS["toStore(get, set?)"] -->|"wraps tracked getter<br/>into a store"| STORE
    FS["fromStore(store)"] -->|"exposes reactive<br/>.current property"| STATE

    STATE -.->|"read by get()"| TS
    STORE -.->|"subscribe()"| FS
```

### 4.2 `toStore` client lifecycle

```mermaid
sequenceDiagram
    autonumber
    participant U as User code
    participant TS as toStore (client)
    participant W as writable (stores_core)
    participant FX as effect_root / render_effect
    participant RT as runtime (signal graph)

    U->>TS: toStore(get, set?)
    TS->>RT: capture active_effect / active_reaction
    TS->>TS: init_value = get()
    TS->>W: writable(init_value, start)
    U->>W: subscribe(run)  %% first subscriber
    W->>TS: invoke start(set)
    TS->>TS: ran = init_value !== get()
    TS->>RT: set_active_reaction / set_active_effect (captured ctx)
    TS->>FX: effect_root(() => render_effect(...))
    FX->>FX: track get(), push set(value)
    TS->>RT: restore previous reaction/effect (finally)
    Note over FX,RT: on every dependency change the render effect re-runs and set(value) notifies subscribers
    U->>FX: teardown()  %% last subscriber leaves
    FX->>FX: destroy tracking effect
```

### 4.3 `fromStore` client read and update propagation

```mermaid
sequenceDiagram
    autonumber
    participant Eff as Consumer effect
    participant Cur as bridge.current getter
    participant CS as createSubscriber
    participant S as store (stores contract)
    participant SG as signal graph

    Eff->>Cur: read current (reactive context)
    Cur->>Cur: effect_tracking() === true
    Cur->>CS: subscribe()
    CS->>S: store.subscribe(callback)
    S-->>Cur: initial value cached (ran = true)
    CS->>SG: render_effect + ref-counted teardown
    Cur-->>Eff: return cached value
    Note over S,CS: later — store.set(v) fires callback
    S->>Cur: value = v, then update()
    Cur->>SG: bump version signal → invalidate dependents
    SG->>Eff: re-run → re-reads current → sees v
```

### 4.4 `fromStore(...).current` decision logic

```mermaid
flowchart TD
    A["read obj.current"] --> B{"'set' in store?"}
    B -->|"yes (Writable)"| C["getter + setter object<br/>set current(v) → store.set(v)"]
    B -->|"no (Readable)"| D["read-only getter object"]
    C --> E{"effect_tracking()?"}
    D --> E
    E -->|"client, inside effect/reaction"| F["ensure createSubscriber subscription<br/>return tracked cached value"]
    E -->|"client, untracked — or — server entry"| G["one-shot pull: get(store)"]
```

---

## 5. Dependencies

### 5.1 Internal dependencies

| Dependency | Source module | Used by | Purpose |
|---|---|---|---|
| `writable`, `get` | [stores_core](stores_core.md) (`store/shared/index.js`) | all four functions | store construction and one-shot pulls |
| `Readable`, `Writable` | [stores_contract](stores_contract.md) (`store/public.d.ts`) | type signatures | the interop contract being bridged |
| `effect_root`, `render_effect`, `effect_tracking` | [client-reactivity-engine_effects](client-reactivity-engine_effects.md) | `toStore` client, `fromStore` client | creating/destroying the tracking effect; detecting reactive context |
| `active_effect`, `active_reaction`, `set_active_effect`, `set_active_reaction` | [client-reactivity-engine_signal-graph](client-reactivity-engine_signal-graph.md) | `toStore` client | capturing and restoring the creation-time reactive context |
| `createSubscriber` | [reactive-builtins](reactive-builtins.md) (`reactivity/create-subscriber.js`) | `fromStore` client | lazy, ref-counted store subscription with version-based invalidation |

### 5.2 Reverse dependencies (who consumes the bridge)

- **[public-api](public-api.md)** — `svelte/store` is part of the supported public surface; the bridge functions ship as documented API.
- **Application & library code** — the bridge is the sanctioned path for gradually migrating from store-based libraries to runes (and vice versa) without rewriting state management in one step.
- Store usage *inside component templates* does **not** go through this module — the compiler lowers store references to `store_get` / `store_set` primitives in [client-reactivity-engine_props-and-stores](client-reactivity-engine_props-and-stores.md) (client) and `store_mutate` / `update_store` in [server-runtime](server-runtime.md) (server). This module covers the *script-side*, manual interop cases.

---

## 6. Design Notes

- **Why context capture in `toStore`?** Restoring the creation-time `active_reaction`/`active_effect` before installing the tracking effect means the effect is owned by the correct scope (e.g., the component's init effect), so destroying the component destroys the bridge's tracking — no leaked subscriptions or misattributed dependencies.
- **Why the `ran` flag?** Between `toStore()` and the first `subscribe()`, the source expression may already have changed. The first render-effect run suppresses the push in that case (the value is considered already observed), and all later runs always push.
- **Why laziness in `fromStore`?** `createSubscriber` keeps the store subscription alive only while something reactively reads `current`, with a microtask-delayed ref-count teardown that avoids unsubscribe/resubscribe churn. The version-signal bump on unsubscribe/resubscribe guarantees dependent deriveds re-read correctly when a subscription is picked up again later.
- **Why the untracked fallback?** Reading `current` outside a component/effect (tests, plain modules, event handlers) still needs to return a sane value: the one-shot `get(store)` pull provides that without starting any subscription machinery.
- **Why is the server side so small?** SSR is a single render pass; pull-based reads via `get` are deterministic and avoid importing any client runtime code, preserving tree-shakeability of the server bundle.

---

## 7. Related Modules

- [stores_core](stores_core.md) — `writable` / `derived` / `get` implementations reused and re-exported by this module.
- [stores_contract](stores_contract.md) — the `Readable` / `Writable` interface definitions that define both sides of the bridge.
- [client-reactivity-engine_signal-graph](client-reactivity-engine_signal-graph.md) — the signal graph runtime whose active reaction/effect context `toStore` captures.
- [client-reactivity-engine_effects](client-reactivity-engine_effects.md) — the effect primitives (`effect_root`, `render_effect`, `effect_tracking`) used for live bridging.
- [reactive-builtins](reactive-builtins.md) — `createSubscriber`, the ref-counted subscription primitive behind `fromStore`.
- [public-api](public-api.md) — the public API surface module that exposes `svelte/store`.
- [server-runtime](server-runtime.md) — the server-side rendering runtime that shapes SSR semantics of the server variant.
