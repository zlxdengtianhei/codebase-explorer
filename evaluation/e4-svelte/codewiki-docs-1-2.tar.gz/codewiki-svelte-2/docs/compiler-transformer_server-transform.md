# Server Transform (`compiler-transformer_server-transform`)

## 1. Introduction

The **server-transform** module is the phase-3 code generator of the Svelte compiler for the `generate: 'server'` target. It consumes the *analyzed* Svelte AST produced by [compiler-analyzer](compiler-analyzer.md) (which in turn is fed by [compiler-parser](compiler-parser.md) on top of shared foundations from [compiler-core](compiler-core.md)) and rewrites it into a plain ESTree JavaScript program: a **component function** that appends HTML strings to a `$$payload` object for Server-Side Rendering (SSR).

It is a sibling of the client generator ([compiler-transformer_client-transform](compiler-transformer_client-transform.md)) within the transformer phase ([compiler-transformer](compiler-transformer.md)), sharing utilities with it through [compiler-transformer_shared-infrastructure](compiler-transformer_shared-infrastructure.md) and delegating all stylesheet rewriting to [compiler-transformer_css-transform](compiler-transformer_css-transform.md).

**Design philosophy — "flattening to a string builder":** whereas the client transform emits reactive graph construction, the server transform is *single-pass and synchronous*. Reactivity is emulated or erased:

| Source concept | Server-side representation |
| --- | --- |
| Template markup | Static HTML literals interleaved in `$$payload.out.push(...)` calls |
| Expressions | `$.escape(...)` / `$.stringify(...)` calls inside template literals |
| `{#if}` / `{#each}` | Native `if` / `for` statements wrapped in hydration boundary comments |
| `{#await}` | `$.await(payload, promise, pending, then)` runtime call |
| Snippets & `{@render}` | Hoisted `function` declarations + direct invocation |
| Slots | `$.slot($$payload, $$props, name, props, fallback)` runtime call |
| `$state`, `$derived`, `$props` runes | Reduced to plain variables / parameters / `$.derived(...)` one-shot values |
| `export let` (legacy) | Destructuring from `$$props` with fallbacks |
| `$store` auto-subscriptions | `$.store_get(...)` / `$.store_set(...)` / `$.store_mutate(...)` calls + `$$store_subs` cleanup |
| `$:` reactive statements | Collected, topologically ordered, appended to the instance body |

The emitted program depends on the runtime contract exported by `svelte/internal/server` (see the [server-runtime](server-runtime.md) module), imported once and aliased as `$`.

---

## 2. Module Map

| File | Components | Role |
| --- | --- | --- |
| `transform-server.js` | `server_component`, `server_module` | Entry points; visitor registry; final program assembly |
| `types.d.ts` | `ServerTransformState`, `ComponentServerTransformState` | Transform state contracts |
| `visitors/shared/utils.js` | `process_children`, `build_template`, `build_attribute_value`, `build_getter`, `block_open`, `block_close`, `empty_comment` | Core output-construction infrastructure |
| `visitors/shared/element.js` | `build_element_attributes`, `build_spread_object` | Attribute serialization for elements |
| `visitors/shared/component.js` | `build_inline_component` | Component instantiation / slot serialization |
| `visitors/Fragment.js` | `Fragment` | Fragment → rendered block; resets per-fragment state |
| `visitors/RegularElement.js` | `RegularElement` | Static HTML elements (`<div>`, …) |
| `visitors/SvelteElement.js` | `SvelteElement` | `<svelte:element>` dynamic elements |
| `visitors/IfBlock.js`, `EachBlock.js`, `AwaitBlock.js`, `KeyBlock.js` | same | Control-flow blocks |
| `visitors/Component.js`, `SvelteComponent.js`, `SvelteSelf.js` | same | Component instantiation |
| `visitors/SlotElement.js`, `SvelteFragment.js` | same | Slot projection |
| `visitors/SnippetBlock.js`, `RenderTag.js` | same | Snippet definitions and renders |
| `visitors/HtmlTag.js` | `HtmlTag` | `{@html …}` raw injection |
| `visitors/SvelteHead.js`, `TitleElement.js` | same | `<head>` content / `<title>` handling |
| `visitors/SvelteBoundary.js` | `SvelteBoundary` | `<svelte:boundary>` pending-snippet rendering |
| `visitors/ConstTag.js` | `ConstTag` | `{@const}` → `const` in `state.init` |
| `visitors/VariableDeclaration.js` | `VariableDeclaration`, `create_state_declarators` | Runes-mode & legacy variable handling |
| `visitors/AssignmentExpression.js` | `AssignmentExpression`, `build_assignment` | Assignment lowering (class state fields, stores) |
| `visitors/UpdateExpression.js` | `UpdateExpression` | `++`/`--` on store subscriptions |
| `visitors/CallExpression.js` | `CallExpression` | Rune calls → runtime calls / constants |
| `visitors/Identifier.js` | `Identifier` | Reference rewriting (`$$props`, `$store`) |
| `visitors/AwaitExpression.js` | `AwaitExpression` | Top-level `await` placement validation |
| `visitors/ClassBody.js`, `PropertyDefinition.js`, `MemberExpression.js` | same | Class field runes → backing fields + accessors |
| `visitors/LabeledStatement.js` | `LabeledStatement` | Legacy `$:` capture |
| `visitors/ExpressionStatement.js`, `DebugTag.js`, `SpreadAttribute.js` | same | Minor rewrites ({@debug}, spread flattening) |

---

## 3. Architecture

### 3.1 Position in the Compiler Pipeline

```mermaid
flowchart LR
    SRC[".svelte source"] --> PARSE["Phase 1 — Parse<br/>(compiler-parser)"]
    PARSE --> ANALYZE["Phase 2 — Analyze<br/>(compiler-analyzer)<br/>scopes · metadata · css"]
    ANALYZE --> XFORM{"Phase 3 — Transform<br/>(compiler-transformer)"}
    XFORM -->|generate: 'client'| CLIENT["client-transform<br/>(reactivity + DOM)"]
    XFORM -->|generate: 'server'| SERVER["**server-transform**<br/>(this module)"]
    XFORM --> CSS["css-transform<br/>(compiler-transformer_css-transform)"]
    SERVER --> GEN["ESTree Program<br/>→ esrap code generation"]
    GEN --> OUT["server-compiled component<br/>(JS module)"]
    OUT --> RUNTIME["linked against<br/>svelte/internal/server<br/>(server-runtime)"]
```

The compiler façade ([compiler-core_public_api](compiler-core_public_api.md)) selects `server_component` / `server_module` from this module when `generate === 'server'`.

### 3.2 Entry Points and Orchestration (`transform-server.js`)

`server_component(analysis, options)` performs **three separate `zimmerframe` walks** of the analyzed AST, then stitches the results into one `Program`:

```mermaid
flowchart TB
    subgraph W["server_component(analysis, options)"]
        direction TB
        S1["1. walk(module.ast)<br/>global_visitors<br/>+ set_scope"] --> M["module.body"]
        S2["2. walk(instance.ast)<br/>global_visitors<br/>+ ImportDeclaration/ExportNamed elision"] --> I["instance.body"]
        S3["3. walk(template.ast)<br/>global_visitors + template_visitors"] --> T["template.body"]
        M --> ASM["Final assembly"]
        I --> ASM
        T --> ASM
        ASM --> PRG["Program =<br/>hoisted[] ++ module.body ++ component_block"]
    end
```

The two visitor registries determine what runs where:

| Registry | Applied to | Members |
| --- | --- | --- |
| `global_visitors` | `<script module>`, `<script>` (instance), and the template (for embedded expressions) | `_` → `set_scope`, `AssignmentExpression`, `AwaitExpression`, `CallExpression`, `ClassBody`, `ExpressionStatement`, `Identifier`, `LabeledStatement`, `MemberExpression`, `PropertyDefinition`, `UpdateExpression`, `VariableDeclaration` |
| `template_visitors` | Template only | `AwaitBlock`, `Component`, `ConstTag`, `DebugTag`, `EachBlock`, `Fragment`, `HtmlTag`, `IfBlock`, `KeyBlock`, `RegularElement`, `RenderTag`, `SlotElement`, `SnippetBlock`, `SpreadAttribute`, `SvelteComponent`, `SvelteElement`, `SvelteFragment`, `SvelteHead`, `SvelteSelf`, `TitleElement`, `SvelteBoundary` |

The initial `ComponentServerTransformState` seeds:

- `hoisted` — starts with `import * as $ from 'svelte/internal/server'`; gains hoisted statements (module script output, instance imports, hoistable snippet declarations).
- `legacy_reactive_statements` — `Map<LabeledStatement, Statement>` filled by the `LabeledStatement` visitor for legacy `$:` blocks.
- `namespace`, `preserve_whitespace`, `skip_hydration_boundaries` — refined as visitors descend.
- `init` / `template` — `null` until the root `Fragment` visitor allocates them.

### 3.3 Transform State Model

State flows down the recursion and is forked at scope boundaries (from `types.d.ts`):

```mermaid
classDiagram
    class TransformState {
        <<shared-infrastructure>>
        +Analysis analysis
        +ValidatedModuleCompileOptions options
        +Scope scope
        +Map~SvelteNode,Scope~ scopes
        +Map~string,StateField~ state_fields
    }
    class ServerTransformState {
        +Map legacy_reactive_statements
    }
    class ComponentServerTransformState {
        +ComponentAnalysis analysis
        +ValidatedCompileOptions options
        +Statement[] init
        +Array hoisted
        +Array template
        +Namespace namespace
        +boolean preserve_whitespace
        +boolean skip_hydration_boundaries
    }
    TransformState <|-- ServerTransformState
    ServerTransformState <|-- ComponentServerTransformState
```

- **`init`** — statements that must execute *before* the template output of the current block (e.g. `const` from `{@const}`, `each_array`, `$.derived` wiring, dev validations).
- **`template`** — an ordered sequence of `Expression | Statement`: HTML string literals, `$$payload.out.push(...)` calls, block open/close markers, and nested statements awaiting `build_template`.
- **`hoisted`** — module-level and function-level statements that escape the component block (imports, hoistable snippets, CSS object).
- Visitors **fork the state** when entering isolated regions (`RegularElement` inner body, `SvelteElement`, `TitleElement`) so partial output can be captured, then spliced back.

### 3.4 Component Relationships

```mermaid
flowchart TB
    subgraph ENTRY["Orchestration"]
        TS["transform-server.js"]
    end
    subgraph GLOBAL["global_visitors — script/expression lowering"]
        VD["VariableDeclaration"]
        CE["CallExpression"]
        AE["AssignmentExpression"]
        UE["UpdateExpression"]
        ID["Identifier"]
        CB["ClassBody"]
        PD["PropertyDefinition"]
        ME["MemberExpression"]
        LS["LabeledStatement"]
        AX["AwaitExpression"]
    end
    subgraph TPL["template_visitors — markup lowering"]
        FR["Fragment"]
        RE["RegularElement"]
        SE["SvelteElement"]
        IB["IfBlock · EachBlock<br/>AwaitBlock · KeyBlock"]
        CM["Component · SvelteComponent"]
        SL["SlotElement · SvelteFragment"]
        SN["SnippetBlock · RenderTag"]
        HT["HtmlTag"]
        HD["SvelteHead · TitleElement<br/>SvelteBoundary · ConstTag"]
    end
    subgraph SHARED["shared helpers"]
        SU["utils.js<br/>process_children · build_template<br/>build_attribute_value · build_getter"]
        EL["element.js<br/>build_element_attributes"]
        CO["component.js<br/>build_inline_component"]
    end
    BLD["b (builders)<br/>(compiler-core_ast_builders)"]
    RT["$ svelte/internal/server<br/>(server-runtime)"]

    TS --> GLOBAL & TPL
    TPL --> SHARED
    GLOBAL --> SU
    RE --> EL
    CM --> CO
    GLOBAL & TPL & SHARED --> BLD
    TS & SU & EL & CO --> RT
```

---

## 4. Output Construction Model

### 4.1 Payload & Hydration Markers

The generated component receives `($$payload, $$props)` and appends to `$$payload.out` (a string array). Hydration-critical comments come from `internal/server/hydration.js` and are baked in as *literals* by `shared/utils.js`:

| Constant | Value | Purpose |
| --- | --- | --- |
| `BLOCK_OPEN` | `<!--[-->` | Opens an `{#if}`/`{#each}`/boundary region for hydration matching |
| `BLOCK_OPEN_ELSE` | `<!--[!-->` | Marks the `:else`/`:then`-fallback branch |
| `BLOCK_CLOSE` | `<!--]-->` | Closes a region; doubles as an anchor node |
| `EMPTY_COMMENT` | `<!---->` | Text-node separator / anchor for components, snippets, key blocks |

### 4.2 Template Merging — `process_children` + `build_template`

`process_children` is the heart of static-output generation. It **buffers runs** of adjacent `Text` / `Comment` / `ExpressionTag` nodes and *flushes* them into a single ES template literal:

```mermaid
flowchart TD
    A["nodes[]"] --> B{"node type?"}
    B -->|"Text / Comment / ExpressionTag"| C["push onto sequence buffer"]
    B -->|"other (element, block, …)"| D{"sequence non-empty?"}
    D -->|yes| E["flush(): build template literal"]
    D -->|no| F["visit node normally"]
    C --> G{"more nodes?"}
    F --> G
    E --> F
    G -->|yes| B
    G -->|no| H{"sequence non-empty?"}
    H -->|yes| I["flush()"]
    H -->|no| J["done"]
    I --> J
```

During a flush:

1. `Text` chunks are HTML-escaped (`escape_html`) and appended to the current *cooked* quasi.
2. `Comment` chunks become literal `<!--data-->`.
3. Each `ExpressionTag` is first **constant-folded** via `state.scope.evaluate(expression)`; if `is_known`, the serialized value is inlined into the string (zero runtime cost). Otherwise a runtime `$.escape(...)` call becomes an expression hole and a new quasi starts.
4. Cooked quasis are re-encoded with `sanitize_template_string` so the output is a syntactically valid template literal.

`build_template(template, out = $$payload.out, operator = 'push')` then compiles the accumulated `template` array into statements:

- Consecutive `Literal`s merge into one string.
- `TemplateLiteral`s are flattened in place (quasis concatenated, expressions preserved).
- Strings/expressions flush as `$$payload.out.push(\`...\`)`.
- Real statements split the stream (flush first, then emit verbatim).
- A custom `operator` (e.g. `'='` with `out = $$payload.title`, used by `TitleElement`) emits assignments instead of pushes.

### 4.3 Attribute Values — `build_attribute_value`

Normalizes `AST.Attribute['value']` into an ESTree `Expression`:

| Input shape | Output |
| --- | --- |
| `true` (boolean attribute) | `true` literal |
| Single `Text` chunk | escaped string literal (optionally whitespace-trimmed via `regex_whitespaces_strict`) |
| Single expression chunk | visited expression as-is |
| Multiple chunks | template literal whose holes are `$.stringify(visited)` calls (no escaping — used for component props) |

### 4.4 Reference Resolution — `build_getter` & `Identifier`

`Identifier` rewrites *references* (via `is_reference`):

- `$$props` → `$$sanitized_props` (the props object minus internal/alias keys, produced by `$.sanitize_props`).
- Store subscriptions (`$name`, binding kind `store_sub`) → `$.store_get($$store_subs ??= {}, '$name', name)` — memoized per render so each store is subscribed at most once; `$$store_subs` is declared by the orchestrator when any store is used, and `$.unsubscribe_stores($$store_subs)` is emitted at the end of the template.

`build_getter` is idempotent: the declaration site or unresolved identifiers pass through untouched.

---

## 5. Template Visitor Reference

### 5.1 Fragment (entry for every render region)

`Fragment` is invoked for the component root and every nested block body. It:

1. Infers the child namespace (`infer_namespace`) and runs `clean_nodes` (shared with the client transform) to drop removable whitespace/comments and partition **hoisted** vs. **trimmed** nodes; detects `is_standalone` / `is_text_first`.
2. Forks state: fresh `init` + `template`, and sets `skip_hydration_boundaries` when the fragment stands alone (no anchor needed).
3. Visits hoisted nodes, optionally emits `empty_comment` (`is_text_first` guard), then delegates children to `process_children`.
4. Returns `b.block([...state.init, ...build_template(state.template)])` — the canonical shape of *every* region on the server.

### 5.2 Structural Blocks

| Visitor | Emission strategy |
| --- | --- |
| `IfBlock` | Visits `test`/`consequent`/`alternate`; unshifts `$$payload.out.push(BLOCK_OPEN)` into the consequent and `push(BLOCK_OPEN_ELSE)` into the alternate; pushes `b.if(...)` + `block_close` marker into `state.template`. |
| `EachBlock` | `const each_array = $.ensure_array_like(collection)` into `init`; emits a `for (let i = 0, $$length = each_array.length; i < $$length; i++)` loop binding the context variable (`let item = each_array[i]`). Index variables are the analyzer's `metadata.index` when the body contains group bindings (they need the *iterating* index). Fallback bodies become the else-branch of a wrapping `if`, prefixed with `BLOCK_OPEN_ELSE`. Whole construct is wrapped in `block_open` / `block_close`. |
| `AwaitBlock` | Delegates entirely to runtime: `$.await($$payload, promise, () => {pending}, (value) => {then})`, followed by `block_close`. |
| `KeyBlock` | `empty_comment` + fragment block + `empty_comment` (anchor only — keys have no SSR meaning beyond node separation). |
| `ConstTag` | `{@const x = e}` → `const x = e` appended to `state.init` of the enclosing block. |

### 5.3 Elements

**`RegularElement`** lowers static elements into raw string output:

1. Opens the tag: `push('<name')`, then `build_element_attributes` serializes attributes (literals inlined with the CSS scoping hash appended to `class` when present; dynamic attributes become `$.attr('name', value, isBoolean)`; `class`/`style` directives are folded into `attr_class`/`attr_style` helpers; spreads become a `$.spread_attributes(...)` call; event-handler attributes for `load`/`error` on media elements are captured as `onerror="this.__e=event"` hooks).
2. Emits `/>` for void elements (XHTML compliance) or `>`; single-text-child `<script>`/`<style>` bodies are inlined verbatim.
3. Special elements:
   - **`<select>`** with `value` attribute/binding or spread: computes `$$payload.select_value` so descendant `<option>`s can self-select.
   - **`<option>`** without an explicit value: children render into a thunk passed to `$.valueless_option($$payload, () => …)` so the option value derives from its text.
   - **`<textarea value>`** / contenteditable bindings: body expression is bound to `$$body`; output becomes `if ($$body) … else …children…`.
   - `<pre>` / `<textarea>` set `preserve_whitespace` for descendants.
4. Dev mode wraps the body with `$.push_element($$payload, name, line, column)` / `$.pop_element` for ownership-violation messages.
5. Closes with `</name>`.

**`SvelteElement`** (`<svelte:element this={tag}>`) memoizes the tag expression in dev, injects `$.validate_dynamic_element_tag` / `$.validate_void_dynamic_element` checks, builds attributes and children into *separate thunks*, and emits a single call: `$.element($$payload, tag, attrs?, children?)`.

### 5.4 Components, Slots & Snippets

**`build_inline_component`** (shared by `Component`, `SvelteComponent`, `SvelteSelf`) is the most involved emitter:

```mermaid
flowchart LR
    A["attributes"] --> B{"kind?"}
    B -->|Attribute| C["push_prop(name, build_attribute_value)"]
    B -->|Attribute --css| D["custom_css_props.push"]
    B -->|BindDirective| E["delayed getter/setter props<br/>+ $$settled flag"]
    B -->|SpreadAttribute| F["props_and_spreads.push(expr)"]
    G["children"] --> H["group by slot name<br/>(slot attr / snippet blocks)"]
    H --> I{"default slot, no lets,<br/>no children prop?"}
    I -->|yes| J["children prop + $$slots.default = true"]
    I -->|no| K["$$slots.slotName = (payload, lets) => block"]
    C & D & E & F --> L{"spreads?"}
    K & J --> L
    L -->|no| M["Component$$payload, props"]
    L -->|yes| N["$.spread_props([props, …spreads])"]
    D --> O["$.css_props(payload, isHtml, props, thunk, dynamic?)"]
    M & N --> P["template.push(stmt)<br/>+ hydration anchors"]
```

Notable behaviors:

- Bindings are pushed **last** (delayed props) so spreads cannot overwrite them; a `SequenceExpression` binding (get/set pair) becomes getter/setter accessor props.
- Inline `SnippetBlock` children become both a prop (the function) and a `$$slots.<name>: true` entry, smoothing slots/snippet interop.
- `dynamic` components (`<svelte:component>` or non-static component tags) get an `empty_comment` hydration anchor before and after.
- A default-slot block without `svelte:fragment`/`let` and without a `children` prop is passed as the `children` prop (guarded in dev by `$.prevent_snippet_stringification`); otherwise it goes to `$$slots.default` and `children` becomes `$.invalid_default_snippet` (runtime error on access).

**`SlotElement`** (`<slot name="x" {props}>fallback</slot>`) emits
`$.slot($$payload, $$props, name, propsObject | $.spread_props([...]), fallbackThunk)`
bookended by `empty_comment` anchors. `SvelteFragment` simply renders its fragment (its `slot`/`let` attributes were consumed by `build_inline_component`).

**`SnippetBlock`** declares `function snippet($$payload, …params) { … }`, placed in `hoisted` when `metadata.can_hoist` (not referencing component-local reactive state) else in `init`. Dev adds `$.validate_snippet_args($$payload)` and `$.prevent_snippet_stringification(fn)`. The function node is tagged `___snippet` so the orchestrator can hoist snippet declarations above the legacy-binding re-render loop.

**`RenderTag`** (`{@render foo(args)}`) emits `foo($$payload, ...args)` — using `b.maybe_call` when the callee is an optional chain — plus an `empty_comment` anchor unless hydration boundaries are skipped.

### 5.5 Head, Title & Boundary

- **`SvelteHead`**: `$.head($$payload, ($$payload) => { …block… })` — content is captured during SSR and replayed into `<head>` by the host.
- **`TitleElement`**: children (text/expressions only) are rendered into a scratch template, then committed via assignment: `build_template(template, b.id('$$payload.title'), '=')`, i.e. `$$payload.title += '<title>…</title>'`.
- **`SvelteBoundary`**: pushes `BLOCK_OPEN`, renders either the `pending` attribute snippet (invoked directly with `$$payload`), a local `pending` SnippetBlock body, or the default fragment; closes with `BLOCK_CLOSE`. Server-side it is a *delimiting* mechanism for streaming/error recovery rather than active error handling.

### 5.6 Other Template Visitors

- **`HtmlTag`**: `{@html x}` → `$.html(x)` (runtime performs trust checks/branching).
- **`DebugTag`**: `{@debug}` emits a dev-only `console.log` of the listed identifiers.
- **`SpreadAttribute`**: transparent — visits the spread expression.

---

## 6. Script & Expression Visitors (Rune/Legacy Lowering)

### 6.1 Rune Call Mapping — `CallExpression`

| Rune call | Server output |
| --- | --- |
| `$host()` | `void 0` |
| `$effect.tracking()` | `false` |
| `$effect.root(cb)` | `() => {}` (noop mimicking cleanup fn) |
| `$effect.pending()` | `0` |
| `$state(v)` / `$state.raw(v)` | `v` (or `void 0`) |
| `$derived(expr)` | `$.derived(() => expr)` |
| `$derived.by(fn)` | `$.derived(fn)` |
| `$state.snapshot(x)` | `$.snapshot(x, ignored?)` (second arg set when `state_snapshot_uncloneable` is svelte-ignored) |
| `$inspect(...)` / `$inspect(...).with(fn)` | `transform_inspect_rune` output |
| anything else | unchanged (`context.next()`) |

### 6.2 Declarations — `VariableDeclaration`

**Runes mode** (`analysis.runes`):

- `$props` declaration → `let <pattern> = $$props`; `$bindable(x)` defaults collapse to plain assignment-pattern defaults `x = x`; a rest element (or identifier prop reference) is rewritten so `$$slots`/`$$events` internals are never exposed (`$$slots` renamed to `$$slots_` when the component itself uses slots).
- `$props.id` declarator → dropped (orchestrator emits `const <id> = $.props_id($$payload)` as the first component statement).
- `$derived` → `let x = <value>`; `$derived.by` → `let x = fn()` (call once).
- `$state` / other rune initializers → plain declarators; destructuring state patterns are exploded by `create_state_declarators` into `tmp` + `extract_paths` inserts.
- Non-rune declarations pass through unchanged (except `$effect.tracking`, `$inspect`, `$effect.root` initializers, which are treated as normal expressions).

**Legacy mode** (bindings from the analyzer):

- `bindable_prop` bindings (`export let x`) → destructuring from `$$props` with fallbacks: `build_fallback($$props['alias-or-name'], default)`. Destructured `export let { x: [a, b] = … }` forms are exploded via `extract_paths` into `tmp`/`$$array` temporaries.
- `state` bindings (implicit reactivity) → `create_state_declarators`.
- Pure declarations pass through; an all-empty declaration collapses to `b.empty`.

### 6.3 Class Fields — `ClassBody` / `PropertyDefinition` / `MemberExpression`

For runes-mode classes the analyzer records `state_fields` per `ClassBody`:

- `$state` / `$state.raw` property definitions keep their (visited) initializer; private `#`-fields are left alone.
- `$derived` / `$derived.by` fields become a backing private field (`field.key`, initialized to `$.derived(…)` or `$.derived.by(…)` from `PropertyDefinition`) plus **getter/setter accessor pair** (`get name()` → `this.#key()`, `set name($$value)` → `this.#key($$value)`).
- Fields only assigned in the constructor get synthesized backing definitions + accessors (`AssignmentExpression.build_assignment` detects `this.x = $state(...)`-style constructor writes).
- `MemberExpression` rewrites reads of derived private fields (`this.#d`) into method calls (`this.#d()`), matching the signal-implementation detail; plain `context.next()` otherwise.

### 6.4 Reactivity Emulation

**`AssignmentExpression` → `build_assignment`** (via shared `visit_assignment_expression`):

1. Runes-mode class state (`this.x = …` in constructor): assigns to the backing key; derived private fields are instead *called*: `this.#derived(value)` (signals accept write-through).
2. `$store = value` → `$.store_set(store, value)`; nested `$store.x op= y` → `$.store_mutate($$store_subs ??= {}, '$store', store, …)` (triggers store invalidation).
3. Everything else returns `null`, letting the default visitor proceed.

**`UpdateExpression`**: `$store++` / `--$store` → `$.update_store` / `$.update_store_pre` with the same `$$store_subs` memo pattern.

**`LabeledStatement`** (legacy `$: …`): each statement is visited into a labeled statement (`$: <body>` kept so `break $` still works), stored in `state.legacy_reactive_statements`, and removed from the flow (`b.empty`). The orchestrator later appends them to the instance body in the **topological order pre-computed by the analyzer**, hoisting `let` declarations for assigned `legacy_reactive` bindings.

**`AwaitExpression`**: allows `await` at the top level of the component body (`function_depth === 0`) or inside any nested function; any other placement is replaced by `$.await_outside_boundary`, which throws a runtime error.

---

## 7. End-to-End Data Flow

```mermaid
flowchart TB
    subgraph COMPILE["server_component(analysis, options)"]
        HOIST0["hoisted: import * as $ from 'svelte/internal/server'"]
        W1["walk module.ast<br/>(global_visitors)"] --> MOD["module.body statements"]
        W2["walk instance.ast<br/>(global_visitors)"] --> INST["instance.body statements"]
        W3["walk template.ast<br/>(global + template visitors)"] --> TMPL["template.body statements"]
        MOD & INST --> ASM["Program assembly"]
        TMPL --> ASM
    end
    subgraph RUNTIME_POST["Post-walk fixups"]
        LR["append legacy $: statements<br/>(topological order)"]
        BIND["uses_component_bindings →<br/>do/while($$settled) re-render loop<br/>with $$render_inner + copy_payload"]
        STORE["declare $$store_subs;<br/>if ($$store_subs) $.unsubscribe_stores(...)"]
        PROPS["$.bind_props($$props, {bindables…, exports…})"]
        CTX["dev/needs_context → $.push(name) … $.pop()"]
        SAN["$$sanitized_props / $$restProps / $$slots consts"]
        PID["analysis.props_id → const id = $.props_id($$payload) first line"]
        CSSI["css: 'injected' → $$css const + $$payload.css.add($$css)<br/>(render_stylesheet from css-transform)"]
    end
    ASM --> RUNTIME_POST
    RUNTIME_POST --> FINAL["Program:<br/>[...hoisted, ...module.body, component_block(instance ++ template)]"]
    FINAL --> ESRAP["esrap printing"]
```

### 7.1 Worked Example

Input:

```svelte
<script>
	let { items } = $props();
</script>

{#if items.length > 0}
	<ul>
		{#each items as item}
			<li>{item.name}</li>
		{/each}
	</ul>
{:else}
	<p>nothing</p>
{/if}
```

Conceptual output (elided for readability):

```js
import * as $ from 'svelte/internal/server';

export default function App($$payload, $$props) {
	$$payload.out += `<!--[-->`;

	$$payload.out += `<ul>`;
	{
		const each_array = $.ensure_array_like(items);
		$$payload.out += `<!--[-->`;
		for (let index = 0, $$length = each_array.length; index < $$length; index++) {
			let item = each_array[index];
			$$payload.out += `<li>${$.escape(item.name)}</li>`;
		}
		$$payload.out += `<!--]-->`;
	}
	$$payload.out += `</ul>`;

	$$payload.out += `<!--]-->`;
}
```

Observations: the `{:else}` branch becomes the `if`-alternate guarded by `<!--[!-->`; static text inside each `<li>` merges into one literal per dynamic hole; `{item.name}` (not statically evaluable) survives as `$.escape(...)` inside the template literal.

### 7.2 Runtime Render Sequence

```mermaid
sequenceDiagram
    autonumber
    participant HOST as Application / framework SSR host
    participant FN as Compiled component function
    participant PAY as $$payload (out, title, css, select_value)
    participant RT as $ (svelte/internal/server)

    HOST->>FN: Component($$payload, $$props)
    FN->>RT: $.push(componentName)   (dev / needs_context)
    FN->>PAY: out.push(`static html…`)
    FN->>RT: $.escape(expr) / $.attr(...) / $.stringify(...)
    FN->>RT: $.slot / $.await / $.head / $.element (as needed)
    FN->>RT: $.derived(expr) (one-shot values)
    FN->>RT: $.unsubscribe_stores($$store_subs)  (if stores used)
    FN->>RT: $.bind_props($$props, {...})  (bindable props / exports)
    FN->>RT: $.pop()
    HOST->>HOST: payload.out.join('') → HTML string
```

---

## 8. Runtime Contract (functions referenced as `$.…`)

The transform assumes these exports exist in `svelte/internal/server` — implemented by the [server-runtime](server-runtime.md) module:

| Category | Functions |
| --- | --- |
| Serialization | `escape`, `stringify`, `attr`, `attr_class`, `attr_style`, `spread_attributes`, `spread_props`, `clsx`, `snapshot` |
| Elements | `element`, `maybe_selected`, `valueless_option`, `html` |
| Blocks | `await`, `await_outside_boundary`, `head`, `ensure_array_like` |
| Components/slots | `slot`, `sanitize_slots`, `sanitize_props`, `rest_props`, `bind_props`, `css_props`, `invalid_default_snippet`, `prevent_snippet_stringification` |
| Payload | `props_id`, `copy_payload`, `assign_payload` |
| Context/dev | `push`, `pop`, `push_element`, `pop_element`, `validate_dynamic_element_tag`, `validate_void_dynamic_element`, `validate_snippet_args` |
| Reactivity/stores | `derived`, `store_get`, `store_set`, `store_mutate`, `update_store`, `update_store_pre`, `unsubscribe_stores` |

Hydration markers `BLOCK_OPEN` / `BLOCK_OPEN_ELSE` / `BLOCK_CLOSE` / `EMPTY_COMMENT` are imported at compile time from `internal/server/hydration.js` and inlined as string literals, keeping server output marker-compatible with client hydration.

---

## 9. Dependencies

### Upstream (consumed)

| Module | What is used |
| --- | --- |
| [compiler-analyzer](compiler-analyzer.md) | `Analysis`/`ComponentAnalysis`, scopes & bindings, `state_fields`, `each`/component metadata, reactive-statement ordering, css hash/ast, `uses_*` flags |
| [compiler-core_ast_builders](compiler-core_ast_builders.md) | The `b` builder kit (`b.template`, `b.call`, `b.stmt`, `b.if`, `b.for`, …) used by every visitor |
| [compiler-core_compile_state](compiler-core_compile_state.md) | `dev` flag, `locator` for dev element positions, `is_ignored` |
| [compiler-core_diagnostics](compiler-core_diagnostics.md) | Context for errors surfaced while transforming (e.g. invalid await placement reports flow through diagnostics) |
| [compiler-transformer_shared-infrastructure](compiler-transformer_shared-infrastructure.md) | `TransformState` base, shared `utils.js` (`clean_nodes`, `infer_namespace`, `determine_namespace_for_children`, `RegularElement` namespace probe, `transform_inspect_rune`) |
| [compiler-transformer_css-transform](compiler-transformer_css-transform.md) | `render_stylesheet` for `css: 'injected'` builds |
| [server-runtime](server-runtime.md) | Runtime functions called through the `$` alias; hydration marker constants |

### Downstream (consumers)

| Consumer | Usage |
| --- | --- |
| Compiler façade / [compiler-core_public_api](compiler-core_public_api.md) | Invokes `server_component` / `server_module` for `generate: 'server'` |
| [message_code_generation_templates](message_code_generation_templates.md) | Provides `server-errors.js` codes thrown at runtime by the `$.` helpers this transform emits calls to |
| Application SSR hosts (e.g. SvelteKit) | Execute the generated component functions, feeding `$$payload` and rendering `out` |

Peer generators: [compiler-transformer_client-transform](compiler-transformer_client-transform.md) (interactivity) and [compiler-preprocessor](compiler-preprocessor.md) / [compiler-migrator](compiler-migrator.md) operate before compilation entry and are unaffected by this module.

---

## 10. Behavioral Notes & Edge Cases

- **Whitespace/comments** are trimmed by `clean_nodes` unless `preserveWhitespace` (or a `<pre>`/`<textarea>` ancestor); comments are dropped unless `preserveComments`.
- **CSS scoping**: literal `class` values gain the component's scoping hash when the element is scoped; `needs_clsx` attributes are wrapped in `$.clsx`.
- **XHTML correctness**: void elements self-close (`/>`).
- **Hydration anchors** are omitted (`skip_hydration_boundaries`) for standalone fragments and for non-dynamic component calls to minimize payload noise; text-first fragments insert `<!---->` to prevent gluing.
- **Store lifecycle**: `$$store_subs` is a lazily-initialized object (`??= {}`), guaranteed present at the end of the template for `unsubscribe_stores`.
- **Legacy component bindings** (`uses_component_bindings`) trigger the `do/while (!$$settled)` re-render loop with `$$copy_payload`-isolated inner payloads — an SSR-only compatibility shim scheduled for removal with legacy syntax.
- **Dev-only emissions** (all removed in production builds): element ownership stack (`push_element`/`pop_element`), dynamic-element tag validation, snippet argument validation & stringification guards, context push with component name.
- **Deterministic ordering**: `init` statements always precede template output within a block, and the component block is `[...instance.body, ...template.body]`, so setup (props destructuring, derived values) precedes any markup emission.

---

## 11. Related Documentation

- Parent phase: [compiler-transformer](compiler-transformer.md)
- Sibling generators: [compiler-transformer_client-transform](compiler-transformer_client-transform.md) · [compiler-transformer_css-transform](compiler-transformer_css-transform.md) · [compiler-transformer_shared-infrastructure](compiler-transformer_shared-infrastructure.md)
- Foundations: [compiler-core](compiler-core.md) · [compiler-parser](compiler-parser.md) · [compiler-analyzer](compiler-analyzer.md)
- Companion runtime: [server-runtime](server-runtime.md) (within Server-Side Rendering & Cross-Target Runtime Services)
