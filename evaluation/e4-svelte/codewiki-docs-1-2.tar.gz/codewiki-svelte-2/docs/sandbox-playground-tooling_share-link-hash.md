# sandbox-playground-tooling_share-link-hash

## 1. Introduction

`sandbox-playground-tooling_share-link-hash` is a small, focused module within the Svelte repository's engineering tooling. Its single responsibility is to **encode a local sandbox workspace (`playgrounds/sandbox/src/`) into a shareable svelte.dev playground URL**.

It works by serializing every top-level file in the sandbox's `src/` directory into a JSON payload, compressing that payload with gzip, and encoding the result as URL-safe base64. The encoded string becomes the URL fragment (`#hash`) of a `svelte.dev/playground` link — a form of state-in-URL persistence that requires no server-side storage, since the fragment never leaves the browser.

| Property | Value |
|---|---|
| **Location** | `playgrounds/sandbox/scripts/hash.js` |
| **Core component** | `compress` |
| **Parent group** | `sandbox-playground-tooling` → [Engineering Tooling (Benchmarks, Verification & Playground)](Engineering_Tooling_%28Benchmarks%2C_Verification___Playground%29.md) |
| **Runtime** | Node.js ≥ 18 (top-level `await`, global `Blob`, `CompressionStream`, `btoa`) |
| **Input** | Top-level files in `playgrounds/sandbox/src/` |
| **Output** | `https://svelte.dev/playground/untitled#<hash>` printed to stdout |
| **Depends on** | Node built-ins (`node:fs`) + Web Streams APIs only — no Svelte compiler involvement |

## 2. Position in the System

The sandbox playground is a local mirror of the svelte.dev playground, used by maintainers to exercise the compiler built from source against real components. The share-link-hash module closes the loop of that workflow: after editing or generating code locally, a developer can produce a URL that reproduces the exact workspace in the hosted playground (and vice versa, via the `download.js` inverse script).

```mermaid
flowchart TB
    subgraph SB["playgrounds/sandbox"]
        direction TB
        subgraph SRC["src/ — shared workspace (top-level files)"]
            F["*.svelte, *.js, ..."]
        end
        subgraph SCRIPTS["scripts/"]
            HASH["hash.js — <b>compress</b><br/>(this module: encode → share URL)"]
            DL["download.js — decode<br/>(inverse: URL → src/, not a module in the tree)"]
        end
        RUNNER["run.js — compile runner<br/>(see <a href='sandbox-playground-tooling_compile-runner.md'>compile-runner</a>)"]
    end

    subgraph CP["Compiler Pipeline & Language Toolchain"]
        COMP["svelte/compiler:<br/>compile / compileModule / parse / migrate"]
    end

    SITE["svelte.dev/playground<br/>(client decodes #fragment)"]

    F -- "read files" --> HASH
    F -- "glob + read sources" --> RUNNER
    HASH -- "gzip + URL-safe base64 → #hash" --> SITE
    SITE -- "paste URL" --> DL
    DL -- "gunzip → JSON.parse → writeFileSync" --> F
    RUNNER -- "invoke" --> COMP
```

**Key relationships:**

- **Sibling module — compile runner.** `run.js` (module `sandbox-playground-tooling_compile-runner`) reads the same `src/` workspace convention and feeds it to the Svelte compiler. See [sandbox-playground-tooling_compile-runner](sandbox-playground-tooling_compile-runner.md) for the compilation side. This module, by contrast, is purely a transport codec: it never parses or compiles Svelte code, only packages file contents verbatim.
- **Inverse operation — `download.js`.** Lives in the same `scripts/` folder and implements the exact decoding counterpart (see §6).
- **External consumer — svelte.dev playground.** The URL fragment is decoded *client-side* by the playground application to hydrate its editor state. Nothing is uploaded to a server.

## 3. Core Component: `compress`

The module's only code component, `compress`, is an `async` function that transforms a JSON string into a URL-safe base64 gzip blob:

```js
async function compress(payload) {
	const reader = new Blob([payload])
		.stream()
		.pipeThrough(new CompressionStream('gzip'))
		.getReader();

	let buffer = '';
	for (;;) {
		const { done, value } = await reader.read();

		if (done) {
			reader.releaseLock();
			return btoa(buffer).replaceAll('+', '-').replaceAll('/', '_');
		} else {
			for (let i = 0; i < value.length; i++) {
				// decoding as utf-8 will make btoa reject the string
				buffer += String.fromCharCode(value[i]);
			}
		}
	}
}
```

### Stage-by-stage behavior

| Stage | Mechanism | Detail |
|---|---|---|
| 1. Byte stream source | `new Blob([payload]).stream()` | The UTF-8 encoded JSON payload becomes a `ReadableStream` of `Uint8Array` chunks. |
| 2. Compression | `.pipeThrough(new CompressionStream('gzip'))` | Native gzip compression via the Web Compression Streams API (no npm dependency). |
| 3. Byte accumulation | `reader.read()` loop → `String.fromCharCode(value[i])` | Each byte is appended to a string as a *latin-1 character*. This is deliberate: `btoa` only accepts "binary strings" whose char codes are ≤ 0xFF. Decoding the bytes as UTF-8 first would introduce multi-byte replacement sequences and make `btoa` throw (see the in-code comment). |
| 4. Base64 + URL safety | `btoa(buffer)` → `replaceAll('+' , '-')` → `replaceAll('/', '_')` | Standard base64 is converted to the URL-safe alphabet (`-` and `_`). The `=` padding is retained, which is legal inside a URL fragment. The stream lock is released before returning. |

### Script-level orchestration

`hash.js` is a standalone CLI script that runs the whole pipeline at top level:

1. Enumerates `src/` with `fs.readdirSync`, **skipping subdirectories** (`fs.statSync(...).isDirectory()`), and reads each file as UTF-8 text.
2. Wraps each file in a descriptor object and builds the payload (see §4).
3. Calls `await compress(payload)` (top-level `await`).
4. Prints the finished share link to `stdout`.

## 4. Payload Format Contract

The module defines a serialization contract that must remain stable, because it is shared with the playground client and `download.js`:

```jsonc
{
  "name": "sandbox",
  "files": [
    {
      "type": "file",
      "name": "App.svelte",       // display/basename — identical to basename here
      "basename": "App.svelte",
      "contents": "<full UTF-8 file text>",
      "text": true                // TODO might not be (see §7 limitations)
    }
  ]
}
```

### Wire format

```mermaid
flowchart LR
    A["src/ top-level files<br/>(UTF-8 text)"] -->|"readdirSync + readFileSync"| B["files[] descriptors"]
    B -->|"JSON.stringify"| C["payload (JSON string)"]
    C -->|"Blob(...).stream()"| D["ReadableStream<br/>(UTF-8 bytes)"]
    D -->|"pipeThrough"| E["CompressionStream('gzip')"]
    E -->|"gzip byte chunks"| F["per-byte String.fromCharCode<br/>→ binary string buffer"]
    F -->|btoa| G["standard base64"]
    G -->|" '+' → '-' , '/' → '_' "| H["URL-safe base64 hash"]
    H --> I["https://svelte.dev/playground/untitled#&lt;hash&gt;"]

    style H fill:#e8f5e9,stroke:#2e7d32
    style I fill:#fff8e1,stroke:#f9a825
```

Encoding summary: **UTF-8 text → JSON → gzip → base64 (URL-safe alphabet) → URL fragment.**

## 5. Process Flow

```mermaid
sequenceDiagram
    autonumber
    participant Dev as Developer
    participant FS as src/ (workspace)
    participant Web as Web Streams / btoa
    participant Play as svelte.dev playground

    Dev->>Dev: node scripts/hash.js
    Dev->>FS: readdirSync('src'), statSync, readFileSync
    FS-->>Dev: top-level file names + UTF-8 contents
    Dev->>Dev: JSON.stringify({ name:'sandbox', files })
    Dev->>Web: Blob(payload).stream().pipeThrough(gzip)
    loop until done
        Web-->>Dev: Uint8Array gzip chunk
        Dev->>Dev: append bytes to binary-string buffer
    end
    Dev->>Web: btoa(buffer) → URL-safe base64
    Dev-->>Dev: console.log share URL (stdout)
    Dev->>Play: open / share URL — fragment decoded client-side
```

Notes:

- Because the state lives entirely in the **URL fragment**, sharing the link transmits no data to the server; the playground app reconstructs the workspace in the browser.
- gzip typically shrinks the JSON payload substantially, keeping URLs within practical fragment-length limits.

## 6. Round-Trip with the Inverse Operation

`scripts/download.js` implements the exact inverse transform, enabling a bidirectional local ⇄ hosted workflow. The transformations mirror each other step for step:

| Direction | hash.js (encode) | download.js (decode) |
|---|---|---|
| Alphabet | `+ → -`, `/ → _` | `- → +`, `_ → /` |
| Base64 | `btoa(buffer)` | `atob(...)` |
| String ⇄ bytes | bytes → binary string (`String.fromCharCode`) | binary string → bytes (`Uint8Array` + `charCodeAt`) — the code notes that feeding the string directly to `Blob` corrupts the file |
| Compression | `CompressionStream('gzip')` | `DecompressionStream('gzip')` |
| Framing | `JSON.stringify({name, files})` | `JSON.parse(json).files` |
| File I/O | read from `src/` | `writeFileSync` into `src/` |

```mermaid
sequenceDiagram
    autonumber
    participant Local as Local sandbox (src/)
    participant H as hash.js (this module)
    participant URL as Playground URL (#fragment)
    participant D as download.js (inverse)

    Note over Local,H: Publish: local workspace → share link
    Local->>H: read top-level files
    H->>URL: gzip + URL-safe base64 → hash
    Note over URL,D: Pull back: share link → local workspace
    URL->>D: paste URL argument
    D->>D: un-swap alphabet → atob → Uint8Array
    D->>D: DecompressionStream('gzip') → JSON.parse
    D->>Local: writeFileSync each file
```

`download.js` also handles *id-based* playground URLs (no fragment) by fetching `https://svelte.dev/playground/api/<id>.json`, mapping the returned components to the same file-descriptor shape produced by this module — confirming the descriptor schema is the integration contract between both tools and the hosted service.

## 7. Constraints, Limitations & Implementation Notes

- **Top-level files only.** Subdirectories inside `src/` are skipped (`isDirectory()` check), so nested project structures are not representable in a share link.
- **Text-only assumption.** Files are read as UTF-8 and flagged `text: true` with an in-code `TODO might not be` marker. Binary assets would be corrupted by this pipeline.
- **`btoa` binary-string subtlety.** The per-byte `String.fromCharCode` accumulation is essential correctness code, not style: the gzip output is arbitrary binary, and any UTF-8 reinterpretation before `btoa` would either throw (char codes > 0xFF) or silently lose data.
- **No padding stripping.** The base64 `=` padding is kept; URL fragments legally allow `=`, and `atob` on the decode side accepts it.
- **Node version floor.** Requires Node.js ≥ 18 for top-level `await` and the global `Blob`, `CompressionStream`, and `btoa` APIs — the same Web-platform APIs the browser-side playground uses, which keeps the encoder and decoder symmetric.
- **One-shot CLI.** The module has no exports consumed elsewhere in the repository; `compress` is local to the script, and the script's sole output is the logged URL.

## 8. Related Documentation

- [sandbox-playground-tooling_compile-runner](sandbox-playground-tooling_compile-runner.md) — sibling module; compiles the same `src/` workspace with the local compiler build.
- [Compiler_Pipeline___Language_Toolchain](Compiler_Pipeline___Language_Toolchain.md) — the compiler (`compile`, `compileModule`, `parse`, `migrate`) that the sandbox exists to exercise.
- [Engineering_Tooling_(Benchmarks,_Verification___Playground)](Engineering_Tooling_%28Benchmarks%2C_Verification___Playground%29.md) — the parent engineering-tooling group containing benchmarks, comparison tooling, and the sandbox playground.