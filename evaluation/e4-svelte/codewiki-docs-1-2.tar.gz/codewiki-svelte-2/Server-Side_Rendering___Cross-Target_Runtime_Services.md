<SYSTEM>
Reading the child module documentation files before generating the overview.
<SYSTEM_ERROR>
<status>success</status>
<file_path>$WORK/runs/e4/codewiki-svelte-2/server-runtime.md</file_path>
<content>
# Server Runtime (`packages/svelte/src/internal/server`)

## Overview

The server runtime implements Svelte's server-side rendering (SSR) pipeline. It is the counterpart of the client runtime (`internal/client`), exposing the same component API surface (contracts defined in `index.js`) but producing **strings** instead of DOM mutations. Because output must be emitted in a single, forward-only pass, the design differs fundamentally from the client: there is no reactive graph, no effects, and no patching — components execute top-to-bottom, writing directly into an output payload.

Two execution modes are supported:

- **Synchronous rendering** — components run as plain functions; `render()` returns `{ html, head, body, css }`.
- **Asynchronous rendering** — component functions become `async`, and rendering resolves `Promise`s throughout (any awaited task inside a component suspends the segment being rendered, and `await board()` suspends the *entire* branch until all pending tasks in it settle).

## Key Files

| File | Purpose |
| --- | --- |
| `index.js` | Entry point. `render()` / `render_response()` — the complete SSR pipeline. Component API surface, lifecycle (`push`, `pop`, `spread`, `attributes`, etc.) |
| `renderer.js` | The renderer / payload state machine — output queues, per-component segments, hoisting, escapes |
| `context.js` | Server-side context API (`set_context`, `get_context`, `push`, `pop`) |
| `blocks.js` | Output block creation and management (`Branch`, `Flag`, `Text`, etc.) |
| `async.js` | Asynchronous rendering support — `AsyncBody`, `await_block`, `BranchManager` |
| `hydration.js` | Hydration support — HTML comments that delimit component / block boundaries |
| `dom.js` | Shared DOM-traversal helpers used during rendering |
| `elements.js` | Rendering of element openings, attributes, and custom element tags |
| `transform.js` | Server-side output transformation (`SvelteTransform` for directive-based server transforms) |
| `types.d.ts` | TypeScript declarations for internal structures |
| `validate.js` | Development-time diagnostics and boundary helpers (`boundary`, slot validation) |

## Architecture

The renderer is the heart of the module. Every rendered component gets its own **`Renderer`** instance which owns:

- **Output queues** — a tree of `Block`s (`Branch`, `Flag`, `Text`, …) that model the eventual HTML output in document order.
- **Hoisting** — early-emitted content is recorded in `hoisted` and replayed in the correct position by `_hoisted()` before child output.
- **Escaping** — each output chunk is `stringify`-escaped on flush, so untrusted content is neutralized at the latest possible moment.
- **Reset state** — a module-level `renderer_stack`; `pop()` restores the previous renderer so nested component boundaries work correctly.

```mermaid
flowchart TD
    subgraph Entry
        A["render()"] --> B["render_response()"]
    end

    subgraph Pipeline
        B --> C["new Renderer()"]
        C --> D["component function executes"]
        D --> E["output blocks: Branch / Flag / Text"]
        E --> F{"async mode?"}
        F -- "yes" --> G["BranchManager + await_block<br/>(suspends & resumes)"]
        F -- "no" --> H["immediate commit"]
        G --> I["flush()"]
        H --> I
        I --> J["stringify() escaping"]
        J --> K["hoisted replay _hoisted()"]
        K --> L["final HTML string"]
    end

    subgraph Payload
        L --> M["html"]
        L --> N["head (hoisted)"]
        L --> O["css / body"]
    end
```

During a render, each component writes into the *current* renderer's root block. Head content (e.g. `<title>`, `<svelte:head>`) is hoisted rather than emitted inline; comment anchors record block boundaries so the client can hydrate the exact same regions.

### Hydration annotations

When `hydratable` output is requested, `hydration.js` emits HTML comments around component and control-flow block boundaries, e.g. `<!--[-->` / `<!--]-->` and `<!--svelte-anchor...-->`. These markers let the client-side hydration pass match server-rendered regions to live component instances without re-rendering.

### Asynchronous rendering

In async mode, `async.js` provides `AsyncBody`, `await_block()` and `BranchManager`. Any `Promise` in a component is awaited; branches render in parallel but are emitted in document order. `await board()` waits for *all* tasks inside the current branch, which makes error propagation and ordering deterministic.

```mermaid
sequenceDiagram
    participant C as Component
    participant R as Renderer
    participant B as BranchManager
    C->>R: render task (Promise)
    R->>B: await_block(promise, body)
    B-->>C: pending branch placeholder
    Note over C,B: branches render in parallel
    B-->>R: resolved output, document order
    R-->>C: flushed HTML segment
```

## Notable Behaviors

- **`stringify()`** is the single escape point for all output; it handles string, number, `null`, `undefined`, and `Saturation` markers.
- **`Renderer.push()` / `pop()`** maintain a module-level stack so nested renders (e.g. a child component rendering into a parent slot) never corrupt each other's queues.
- **Hoisting guarantees head elements land in `<head>`** regardless of the order the component happened to emit them.
- **Hydration comments** are only produced when rendering is `hydratable`; they are invisible anchors that the client runtime understands.
- **The whole module is synchronous by default**; async rendering is opt-in (`svelte:async` boundaries / `experimental.async`) and changes the shape of the exported `render()` result to awaitable.

## Public API surface

Exported from `index.js` (and re-exported by the `svelte/server` entry point):

| Symbol | Purpose |
| --- | --- |
| `render` | Render a component to `{ html, head, body, css }` |
| `push` / `pop` | Component lifecycle: enter / exit a component scope |
| `context` | Server-side context access |
| `set_context` / `get_context` | Explicit context read/write |
| `spread` / `attributes` | Spread & attribute-string helpers |
| `escape` | HTML escaping of raw values |
| `validate_store` | Dev-mode store contract check |
| `boundary` | Async/error boundary helper |
| `await_block` | Async content block |
| `stringify` | Coerce value into safe output text |
</content>
</SYSTEM_ERROR>
<SYSTEM_ERROR>
<status>success</status>
<file_path>$WORK/runs/e4/codewiki-svelte-2/context-api.md</file_path>
<content>
# Context API (`packages/svelte/src/internal`)

## Overview

The Context API allows components to share values with their descendants without prop drilling. It is implemented across two coordinated files:

- `internal/client/context.js` — client-side implementation backed by the reactive runtime
- `internal/server/context.js` — server-side implementation used during SSR

Both expose the same public surface: `set_context`, `get_context`, `has_context`, and the lower-level `push`/`pop` component scope helpers. This split is a classic example of Svelte's cross-target architecture: identical public API, target-specific internal representation.

## Key Files

| File | Purpose |
| --- | --- |
| `internal/client/context.js` | Client-side context, integrated with the component effects/lifecycle system |
| `internal/server/context.js` | Server-side context backed by a plain `Map` per component frame |

## Architecture

### Client-side context

On the client, a context map is attached to the *current component context* object, which itself participates in the reactive effects graph. `set_context` writes to the current frame's map; `get_context` walks up the parent chain (via `component_context.p`) until a match is found or the root is reached.

```mermaid
flowchart TD
    A["component_context (client)"] --> B["ctx: Map()"]
    B --> C["key: SomeSymbol -> value"]
    A --> D["p: parent component_context"]
    D --> E["ctx: Map()"]
    E --> F["key: SomeSymbol -> value"]
    C -. "get_context walks .p chain" .-> E
```

### Server-side context

On the server there is no persistent component instance; instead each SSR component frame maintains its own `Map`. `push` creates a fresh frame and saves the previous one; `pop` restores it. Because rendering is strictly depth-first and synchronous (or driven by the async scheduler), a simple stack is sufficient.

```mermaid
flowchart TD
    S["server render stack"] --> F1["frame 1: Map()"]
    F1 --> F2["frame 2: Map()"]
    F2 --> F3["frame 3: Map()"]
    F3 -. "get_context: walk frames" .-> F1
```

### Shared contract

Both implementations share the same lookup semantics:

1. `set_context(key, value)` — stores `value` under `key` in the *current* component's context.
2. `get_context(key)` — searches the current frame, then each ancestor frame in order.
3. `has_context(key)` — boolean variant of the lookup.
4. `push`/`pop` — component lifecycle boundaries that create and dispose frames.

## Public API surface

| Symbol | Client | Server | Notes |
| --- | --- | --- | --- |
| `set_context` | ✅ | ✅ | Must be called during component initialisation |
| `get_context` | ✅ | ✅ | Walks up the ancestor chain |
| `has_context` | ✅ | ✅ | Boolean lookup |
| `push` / `pop` | ✅ | ✅ | Scope frame management (used by generated code) |

## Notable Behaviors

- Keys are usually module-level `Symbol()`s to avoid collisions.
- On the server, `push`/`pop` are re-entrant and can be nested arbitrarily deep during a single `render()` call.
- On the client, context is captured at component *init* time — mutations after init are not reactive; to share reactive values, put a store or reactive object in context.
- `has_context` avoids the "not found" undefined-check pattern and is compiled to a cheaper check in output code.
</content>
</SYSTEM_ERROR>
<SYSTEM_ERROR>
<status>success</status>
<file_path>$WORK/runs/e4/codewiki-svelte-2/internal-shared-utils.md</file_path>
<content>
# Shared Internal Utilities (`packages/svelte/src/internal/shared`)

## Overview

This directory contains utilities shared between the client and server runtimes — and, transitively, by other `internal` packages. Anything that must behave identically on both targets (validation guards, error text, common helpers) lives here so the two runtimes never drift apart.

## Key Files

| File | Purpose |
| --- | --- |
| `utils.js` | Common helpers used by both runtimes (equality checks, lifecycle guards, etc.) |
| `validate.js` | Runtime validation guards shared across targets |
| `errors.js` / `warnings.js` | Canonical error/warning message catalogues |
| `state.js` | Shared state-related helpers |

## Architecture

```mermaid
flowchart TD
    U["internal/shared"] --> C["internal/client"]
    U --> S["internal/server"]
    U --> O["other internal consumers"]

    C --> P["Public API<br/>(svelte)"]
    S --> P2["Public API<br/>(svelte/server)"]
```

Because both runtimes import from `shared`, any behavioural change (e.g. a new dev-mode check, a reworded error) only has to be made once. The package has **no target-specific code** of its own — it is deliberately platform-agnostic.

## Notable Behaviors

- **`utils.js`** provides tiny, hot-path helpers (object equality, `define_property` wrappers) that must be tree-shakeable and free of target assumptions.
- **`validate.js`** groups dev-only assertions shared by both runtimes; they are stripped in production builds.
- **`errors.js` / `warnings.js`** centralise message strings so that compile-time message templates (`scripts/process-messages/templates`) and runtime diagnostics stay in sync.
- **Tests** (`tests` folder next to sources) verify that behaviour is identical whichever runtime consumes the helper — snapshot conformance tests compare client and server output.
</content>
</SYSTEM_ERROR>done display> #[[SERVER-SIDE RENDERING & CROSS-TARGET RUNTIME SERVICES]]

# Server-Side Rendering & Cross-Target Runtime Services (`packages/svelte/src/internal`)

## Overview

This module is the **server-side counterpart** of Svelte's runtime. Where the client runtime maintains a live reactive graph and patches the DOM, this module renders components to **strings** in a single forward-only pass, and houses the services that must behave identically across both targets: the context API and the shared utility layer.

The module consists of three subsystems:

| Subsystem | Path | Responsibility |
| --- | --- | --- |
| [Server Runtime](<server-runtime.md>) | `internal/server` | The SSR pipeline: renders components to `{ html, head, css, body }` strings |
| [Context API](<context-api.md>) | `internal/client/context.js` + `internal/server/context.js` | Cross-target value sharing without prop drilling |
| [Shared Utilities](<internal-shared-utils.md>) | `internal/shared` | Target-agnostic helpers, validation guards, and error catalogues |

## Purpose

1. **Server-side rendering** — execute a compiled component as a plain (or async) function and emit HTML text directly into an output payload, with no reactive graph, no effects, and no patching.
2. **Cross-target parity** — expose the *same* public API (`set_context`, `get_context`, `push`/`pop`, etc.) on client and server, backed by target-specific implementations, so compiled output works unchanged in either environment.
3. **Shared correctness guarantees** — centralise escaping, validation, and diagnostics in one place so the two runtimes can never drift apart behaviourally.

## Architecture

At the top level, the module is a hub: the server runtime consumes the shared utilities, the context API exists in two parallel implementations, and everything is surfaced through the public entry points (`svelte` on the client, `svelte/server` on the server).

```mermaid
flowchart TD
    subgraph Module["internal (this module)"]
        SR["server/<br/>SSR render pipeline"]
        CA["context API<br/>(client + server impls)"]
        SH["shared/<br/>utils · validate · errors"]
    end

    P["svelte (client entry)"]
    PS["svelte/server (SSR entry)"]

    SH --> SR
    SH --> CA
    CA --> SR
    SR --> PS
    CA --> P
```

### Server render pipeline

The heart of the module is the renderer state machine. Each rendered component gets a `Renderer` instance that owns a tree of output `Block`s, hoists head content, and escapes every chunk at flush time. Synchronous rendering commits immediately; asynchronous rendering suspends and resumes branches while emitting in document order.

```mermaid
flowchart TD
    A["render()"] --> B["render_response()"]
    B --> C["new Renderer()"]
    C --> D["component executes<br/>(top-to-bottom)"]
    D --> E["output blocks:<br/>Branch / Flag / Text"]
    E --> F{"async mode?"}
    F -- "yes" --> G["BranchManager + await_block<br/>(suspends & resumes, order-safe)"]
    F -- "no" --> H["immediate commit"]
    G --> I["flush()"]
    H --> I
    I --> J["stringify() escaping"]
    J --> K["hoisted replay → <head>"]
    K --> L["{ html, head, css, body }"]
```

When hydration is enabled, `hydration.js` interleaves HTML comment anchors (`<!--[-->` / `<!--]-->`, `<!--svelte-anchor...-->`) around component and block boundaries so the client runtime can later match server output to live instances without re-rendering.

### Cross-target context API

The context API is the canonical example of the module's split-target design: identical lookup semantics, two representations. On the client the context `Map` hangs off the reactive `component_context` and lookup walks the `.p` parent chain; on the server each SSR frame keeps its own `Map`, and a push/pop stack is sufficient because rendering is strictly depth-first.

```mermaid
flowchart TD
    subgraph Client["client: reactive context chain"]
        A["component_context"] --> B["ctx: Map"]
        A --> D["p: parent"]
        D --> E["ctx: Map"]
        B -. "get_context walks .p" .-> E
    end

    subgraph Server["server: frame stack"]
        S["render stack"] --> F1["frame 1: Map"]
        F1 --> F2["frame 2: Map"]
        F2 --> F3["frame 3: Map"]
        F3 -. "walk frames" .-> F1
    end
```

Shared contract: `set_context(key, value)` writes to the current frame; `get_context(key)` searches the current frame then each ancestor; `has_context(key)` is the boolean variant; `push`/`pop` create and dispose frames.

### Shared utilities layer

`internal/shared` has no target-specific code of its own. Both runtimes import from it, so a new dev-mode guard or a reworded error only has to be made once — and snapshot conformance tests verify the behaviour is identical whichever runtime consumes it.

```mermaid
flowchart TD
    U["internal/shared<br/>utils · validate · errors/warnings · state"]
    U --> C["internal/client"]
    U --> S2["internal/server"]
    C --> P["Public API (svelte)"]
    S2 --> P2["Public API (svelte/server)"]
```

## Core Components

| Component | Documentation | Highlights |
| --- | --- | --- |
| Server Runtime | [server-runtime.md](<server-runtime.md>) | `render()` pipeline, `Renderer` blocks & hoisting, `stringify()` escaping, hydration annotations, async rendering (`await_block`, `BranchManager`), full public API table |
| Context API | [context-api.md](<context-api.md>) | Client/server implementations, lookup semantics, `set_context` / `get_context` / `has_context` / `push` / `pop` |
| Shared Utilities | [internal-shared-utils.md](<internal-shared-utils.md>) | Hot-path helpers, dev-only validation guards, canonical error/warning catalogues, snapshot conformance tests |

## Notable Design Points

- **Forward-only output** — no patching: components write into ordered output queues; head content is hoisted so it lands in `<head>` regardless of emission order.
- **Late escaping** — every output chunk passes through `stringify()` at flush time, the single escape point for untrusted values.
- **Deterministic async** — async branches render in parallel but are emitted in document order; `await board()` settles an entire branch before it is flushed.
- **Re-entrancy via stacks** — a module-level renderer stack (`push`/`pop`) and per-frame context stacks let nested component renders never corrupt each other's state.
- **One source of truth** — shared validation, errors, and helpers live in `internal/shared` so client and server stay behaviourally identical.
</OVERVIEW>