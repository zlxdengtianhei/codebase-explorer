# Message Code Generation Templates

## 1. Introduction & Purpose

The `message_code_generation_templates` module lives at `packages/svelte/scripts/process-messages/templates/` and contains **seven blueprint files** that drive Svelte's diagnostics code-generation pipeline. Each template defines a single placeholder function named `CODE(...)` plus the surrounding scaffolding (imports, helper classes, DEV-mode gating, ignore/filter logic) that a *generated* error or warning module should carry.

The companion generator script (`scripts/process-messages/index.js`) reads a markdown catalogue of compiler/runtime messages from `messages/<category>/<code>.md`, parses each template into an AST, and for **every message code** emits one concrete exported function into the corresponding generated module. This gives the Svelte repo a single source of truth where one markdown message simultaneously produces:

1. A typed, documented error/warning function in the compiler or runtime source tree.
2. A human-readable reference page under `documentation/docs/98-reference/.generated/`.
3. A stable `https://svelte.dev/e/<code>` permalink embedded in every diagnostic.

> **Key idea:** the template files in this module are never executed in their template form — `CODE`, `MESSAGE`, `PARAMETER` and `CODES` are placeholders that the generator replaces during a build step (`node scripts/process-messages/index.js`, with an optional `-w` watch flag).

## 2. Placeholder Contract

Every template honours the same placeholder contract, which the generator substitutes via AST surgery (acorn parse → `zimmerframe` walk → esrap print):

| Placeholder | Where it appears | Replaced with |
|---|---|---|
| `CODE` | Function name `export function CODE(...)`, and `'CODE'` string literals (used in `https://svelte.dev/e/${'CODE'}`) | The concrete message code, e.g. `block_unclosed` |
| `MESSAGE` | Inside the diagnostic text template literal | A template literal built from the markdown message, with `%variable%` tokens turned into interpolated expressions; multi-variant messages become conditional-expression chains |
| `PARAMETER` | A function parameter | The real parameter names extracted from `%variable%` tokens in the message (later overloads become optional `[name]` JSDoc params) |
| `CODES` | An identifier reference (used only by `compile-warnings.js` to export `codes`) | An array literal of **all** message codes in the category |
| ` * MESSAGE` / `PARAMETER` in JSDoc | The template JSDoc block | Per-code doc text and one `@param` entry per interpolated variable |

## 3. Architecture Overview

### 3.1 Generation pipeline

```mermaid
flowchart TB
    subgraph Sources["Message Sources"]
        MD["messages/&lt;category&gt;/&lt;code&gt;.md<br/>## CODE headings + '&gt;' message paragraphs + details"]
    end

    subgraph Generator["scripts/process-messages/index.js (generator)"]
        PARSE["Parse markdown catalogue<br/>validate duplicate codes, sort codes"]
        REFDOCS["Regenerate reference docs<br/>documentation/docs/98-reference/.generated/"]
        TRANSFORM["transform(name, dest)<br/>acorn parse template → AST walk<br/>substitute CODE / MESSAGE / PARAMETER / CODES<br/>clone function per message code"]
        PRINT["esrap print<br/>+ cloned JSDoc<br/>+ 'Do not edit' banner"]
    end

    subgraph Templates["This module: templates/"]
        CE["compile-errors.js"]
        CW["compile-warnings.js"]
        CLE["client-errors.js"]
        CLW["client-warnings.js"]
        SE["server-errors.js"]
        SHE["shared-errors.js"]
        SHW["shared-warnings.js"]
    end

    subgraph Outputs["Generated modules (packages/svelte/src/)"]
        GE["compiler/errors.js"]
        GW["compiler/warnings.js"]
        GCE["internal/client/errors.js"]
        GCW["internal/client/warnings.js"]
        GSE["internal/server/errors.js"]
        GSHE["internal/shared/errors.js"]
        GSHW["internal/shared/warnings.js"]
    end

    MD --> PARSE
    PARSE --> REFDOCS
    PARSE --> TRANSFORM
    CE --> TRANSFORM
    CW --> TRANSFORM
    CLE --> TRANSFORM
    CLW --> TRANSFORM
    SE --> TRANSFORM
    SHE --> TRANSFORM
    SHW --> TRANSFORM
    TRANSFORM --> PRINT
    PRINT --> GE & GW & GCE & GCW & GSE & GSHE & GSHW
```

### 3.2 Template → generated-module mapping

The generator hard-wires each template to its destination:

| Template (this module) | Generated destination | Consumed by |
|---|---|---|
| `compile-errors.js` | `src/compiler/errors.js` | All compiler phases (e.g. `block_unclosed`, `css_*` errors, `typescript_invalid_feature`) — see [Compiler Pipeline & Language Toolchain](Compiler_Pipeline___Language_Toolchain.md) |
| `compile-warnings.js` | `src/compiler/warnings.js` | Analyze visitors & option validation (e.g. `css_unused_selector`, `a11y_*`, `options_removed_*`) — see [Compiler Pipeline & Language Toolchain](Compiler_Pipeline___Language_Toolchain.md) |
| `client-errors.js` | `src/internal/client/errors.js` | Client runtime (e.g. `bind_invalid_export`, `svelte_boundary_reset_onerror`) — see [Client Runtime Engine](Client_Runtime_Engine_(Reactivity___DOM_Rendering).md) |
| `client-warnings.js` | `src/internal/client/warnings.js` | Client runtime (e.g. `svelte_boundary_reset_noop`) — see [Client Runtime Engine](Client_Runtime_Engine_(Reactivity___DOM_Rendering).md) |
| `server-errors.js` | `src/internal/server/errors.js` | SSR runtime — see [Server-Side Rendering & Cross-Target Runtime Services](Server-Side_Rendering___Cross-Target_Runtime_Services.md) |
| `shared-errors.js` | `src/internal/shared/errors.js` | Code shared by client & server (e.g. `invalid_default_snippet`) — see [Server-Side Rendering & Cross-Target Runtime Services](Server-Side_Rendering___Cross-Target_Runtime_Services.md) |
| `shared-warnings.js` | `src/internal/shared/warnings.js` | Code shared by client & server |

### 3.3 Compile-time vs runtime template families

The seven templates fall into two families that are documented separately:

- **Compile-time templates** — [`message_code_generation_templates_compile_time.md`](message_code_generation_templates_compile_time.md)
  `compile-errors.js` and `compile-warnings.js`. These embed the richest machinery: the `InternalCompileError` class (an `Error` subclass whose shape mirrors `CompileDiagnostic`), the `InternalCompileWarning` class (directly extends `CompileDiagnostic`), `svelte-ignore` stack handling and warning-filter integration.

- **Runtime templates** — [`message_code_generation_templates_runtime.md`](message_code_generation_templates_runtime.md)
  `client-errors.js`, `client-warnings.js`, `server-errors.js`, `shared-errors.js` and `shared-warnings.js`. These implement a uniform DEV-vs-production behaviour matrix: rich, styled, code-linked messages in development; terse `https://svelte.dev/e/<code>`-only output in production bundles.

## 4. Data Flow of a Generated Diagnostic

```mermaid
sequenceDiagram
    participant Dev as Svelte Developer
    participant Gen as process-messages/index.js
    participant Tpl as templates/*.js (this module)
    participant Out as Generated errors.js / warnings.js
    participant Comp as Compiler / Runtime (consumers)

    Dev->>Gen: writes messages/<category>/<code>.md
    Gen->>Gen: parse + validate + sort codes
    Gen->>Tpl: read template source (acorn parse)
    Tpl-->>Gen: AST with CODE/MESSAGE/PARAMETER/CODES placeholders
    Gen->>Gen: clone export function CODE per message,<br/>substitute placeholders, clone JSDoc
    Gen->>Out: write generated module ("Do not edit" banner)
    Comp->>Out: call generated function (e.g. error('block_unclosed', node))
    Out-->>Comp: throws InternalCompileError / Error (errors)<br/>or pushes CompileWarning / console.warn (warnings)
    Dev->>Dev: sees message + https://svelte.dev/e/<code> link
```

## 5. Sub-modules

| Sub-module | Templates | Documentation file (generated) |
|---|---|---|
| Compile-time diagnostics templates | `compile-errors.js`, `compile-warnings.js` | 📄 [message_code_generation_templates_compile_time.md](message_code_generation_templates_compile_time.md) — `InternalCompileError` / `InternalCompileWarning` machinery, `svelte-ignore` handling, `CompileDiagnostic` integration |
| Runtime diagnostics templates | `client-errors.js`, `client-warnings.js`, `server-errors.js`, `shared-errors.js`, `shared-warnings.js` | 📄 [message_code_generation_templates_runtime.md](message_code_generation_templates_runtime.md) — DEV-vs-production behaviour matrix, `esm-env` gating, styled console output, shared-error re-exports |

## 6. Relationship to the Rest of the System

This module sits in the **engineering tooling** layer of the Svelte repository: it is build-time infrastructure, not shipped code. Its outputs, however, are woven through every phase of the toolchain:

```mermaid
flowchart LR
    MCGT["message_code_generation_templates<br/>(this module)"]

    subgraph Compiler["Compiler Pipeline & Language Toolchain"]
        DIR1["compiler-core_diagnostics<br/>(errors.js / warnings.js consumers)"]
        DIAG["CompileDiagnostic + compile state<br/>(utils/compile_diagnostic.js, state.js)"]
    end

    subgraph Client["Client Runtime Engine"]
        DIR2["client-dev-tooling<br/>(internal/client/errors.js, warnings.js)"]
    end

    subgraph Server["SSR & Cross-Target Runtime"]
        DIR3["server-runtime + internal-shared-utils<br/>(internal/server/errors.js, internal/shared/*)"]
    end

    MCGT -->|generates| DIR1
    MCGT -->|generates| DIR2
    MCGT -->|generates| DIR3
    DIAG -.imported by compile-* templates.-> MCGT
    DIR1 -.uses.-> Compiler
    DIR2 -.uses.-> Client
    DIR3 -.uses.-> Server
```

- The **compile-time templates** import `CompileDiagnostic` from `src/compiler/utils/compile_diagnostic.js` and the ignore/filter state from `src/compiler/state.js` (`warnings`, `ignore_stack`, `ignore_map`, `warning_filter`). These are maintained in the [Compiler Pipeline & Language Toolchain](Compiler_Pipeline___Language_Toolchain.md) module (see its `compiler-core_diagnostics` sub-module).
- The **runtime templates** only depend on the `DEV` flag from `esm-env` (plus the re-export of shared errors), keeping generated runtime modules dependency-light and tree-shakeable.
- Messages consumed by the [Public API & Built-in Feature Surface](Public_API___Built-in_Feature_Surface.md) tooling (e.g. compiler options deprecations such as `options_removed_enable_sourcemap`) are also routed through the generated `src/compiler/warnings.js`.

## 7. Why Code Generation?

1. **Single source of truth** — the markdown catalogue simultaneously feeds generated code and generated documentation, so message text, codes, permalinks and docs can never drift apart.
2. **Ergonomics & type safety** — every generated function receives real parameter names derived from `%variable%` tokens, plus fully expanded JSDoc (`@param {string} name`, with optional params for later overloads).
3. **Bundle size** — DEV-only branches in the templates mean production bundles throw/warn with just the short permalink URL, and minifiers can strip the verbose text.
4. **Consistency guarantees** — duplicate codes fail the build, message overloads must introduce *new* parameters, and each output file is stamped with a "Do not edit" banner, protecting generated code from hand edits.

---
*Related modules: [Compiler Pipeline & Language Toolchain](Compiler_Pipeline___Language_Toolchain.md) · [Client Runtime Engine](Client_Runtime_Engine_(Reactivity___DOM_Rendering).md) · [SSR & Cross-Target Runtime Services](Server-Side_Rendering___Cross-Target_Runtime_Services.md) · [Public API & Built-in Feature Surface](Public_API___Built-in_Feature_Surface.md)*
