# compiler-core_type_definitions

## Introduction

`compiler-core_type_definitions` is the **type layer** of the Svelte compiler core. It contains no runtime logic: it is a set of TypeScript declaration files (`.d.ts`) under `packages/svelte/src/compiler/types/` that define the compiler's public API contract, the shape of the Abstract Syntax Trees (ASTs) the compiler produces, and the metadata contracts that flow between the compiler's analysis and transformation phases.

The module consists of four declaration files, each owning a distinct type domain:

| File | Namespace / Exports | Purpose |
| --- | --- | --- |
| `types/index.d.ts` | `CompileResult`, `CompileError`, `Warning`, `CompileOptions`, `ModuleCompileOptions`, `OptimizeOptions`, `BindingKind`, `DeclarationKind`, `ExpressionMetadata`, `StateField` | The compiler API contract (`compile` / `compileModule` inputs & outputs) and analysis-phase metadata types. Acts as the **barrel file** for the whole type layer. |
| `types/template.d.ts` | `AST` namespace, `Namespace`, `DelegatedEvent` | The modern (Svelte 5) template AST: every node type a `.svelte` file can produce, plus the union taxonomies (`SvelteNode`, `TemplateNode`, `Tag`, `Block`, `ElementLike`, `Directive`) used to traverse it. |
| `types/css.d.ts` | `_CSS` namespace | The CSS AST extracted from `<style>` blocks: stylesheets, rules, at-rules, and selectors, with scoping-analysis metadata. |
| `types/legacy-nodes.d.ts` | `Legacy*` interfaces, `LegacySvelteNode` | The Svelte 4 AST shape, retained so the [compiler-migrator](compiler-migrator.md) can parse old code and upgrade it. |

These types are the **lingua franca** of the entire compiler pipeline: the parser produces nodes shaped by them, the analyzer populates their `metadata` fields, and the transformer consumes both. They also leak (intentionally) into the public API — `packages/svelte/types/index.d.ts` re-exports types such as `CompileResult`, `Root`, `BaseNode`, `CompileError` to end users (see [svelte-public-types](svelte-public-types.md)).

---

## Architecture Overview

### File Composition and Internal Dependencies

```mermaid
flowchart TD
    subgraph types["compiler/types/ (this module)"]
        INDEX["index.d.ts<br/>CompileResult · CompileError · Warning<br/>CompileOptions · ModuleCompileOptions<br/>OptimizeOptions · BindingKind · DeclarationKind<br/>ExpressionMetadata · StateField"]
        TEMPLATE["template.d.ts<br/>AST namespace · Namespace · DelegatedEvent"]
        CSS["css.d.ts<br/>_CSS namespace"]
        LEGACY["legacy-nodes.d.ts<br/>Legacy* node types"]
    end

    subgraph internal["Compiler internals referenced"]
        SCOPE["phases/scope.js<br/>Binding · Scope (runtime classes)"]
        DIAG["utils/compile_diagnostic.js<br/>ICompileDiagnostic typedef"]
        PHASETYPES["phases/types.d.ts<br/>ReactiveStatement"]
        UTILS["src/utils.js<br/>StateCreationRuneName"]
    end

    subgraph external["External type packages"]
        ESTREE["estree<br/>(JS AST nodes)"]
        MAGICSTRING["magic-string<br/>(SourceMap)"]
        ACORN_TS["acorn-typescript<br/>(typeAnnotation augment)"]
    end

    INDEX -- "export * (re-exports entire AST)" --> TEMPLATE
    INDEX -- "export { Binding, Scope }" --> SCOPE
    INDEX -- "export { ReactiveStatement }" --> PHASETYPES
    INDEX -- "Warning / CompileError extend" --> DIAG
    INDEX -- "StateField uses" --> UTILS

    TEMPLATE -- "AST.* · ExpressionMetadata · Binding · Scope" --> INDEX
    CSS -- "imports AST (Comment in StyleSheet content)" --> TEMPLATE
    LEGACY -- "mixes AST.Text / AST.CSS.* into legacy unions" --> TEMPLATE
    LEGACY -- "LegacySelector children" --> CSS

    INDEX -- "js.map / css.map" --> MAGICSTRING
    TEMPLATE -- "augments BaseNode<br/>start · end · typeAnnotation" --> ESTREE
    TEMPLATE -- "typeAnnotation (via acorn-typescript)" --> ACORN_TS
    INDEX -- "estree nodes in StateField / ExpressionMetadata hosts" --> ESTREE
```

Key observations:

- **`index.d.ts` is the entry point.** `export * from './template.js'` means every consumer that imports from `#compiler` (the internal alias) gets the full `AST` namespace through it. It also re-exports the runtime classes `Binding` and `Scope` from [`compiler-analyzer`](compiler-analyzer.md)'s `phases/scope.js` so that phase modules can share one import surface.
- **`template.d.ts` and `css.d.ts` are mutually referencing namespaces.** The template AST holds `AST.CSS.StyleSheet` (the parsed `<style>`), and the CSS AST references `AST.Comment` (a possible comment atop a style tag) and is exposed back as `AST.CSS` via `export type { _CSS as CSS }`.
- **`legacy-nodes.d.ts` is deliberately hybrid.** Legacy nodes reuse modern leaf types (`AST.Text`, `AST.ExpressionTag`, `AST.CSS.Combinator`, `AST.CSS.SimpleSelector`) wherever the old and new grammars agree, so the migrator only needs to rewrite genuinely changed constructs.
- **estree augmentation.** `template.d.ts` declares `declare module 'estree'` to add `start`/`end` (added by the Svelte parser) and `typeAnnotation` (added by acorn-typescript) to every JS node — this is how Svelte attaches positions to script code.

---

## `index.d.ts` — The Compile API Contract

### `CompileResult`

The return value of `compile()` from `svelte/compiler` (see [compiler-core_public_api](compiler-core_public_api.md)):

```ts
interface CompileResult {
    js:   { code: string; map: SourceMap };              // generated JavaScript
    css:  null | { code: string; map: SourceMap;
                   hasGlobal: boolean };                 // null when css: 'external' and no styles
    warnings: Warning[];                                 // compiler warnings (code, message, start/end)
    metadata: { runes: boolean };                        // whether runes mode was used
    ast: any;                                            // the parsed AST
}
```

`CompileError` and `Warning` are both **empty interfaces extending `ICompileDiagnostic`** (a typedef from `utils/compile_diagnostic.js`):

```ts
{
    code: string;            // e.g. 'css_unused_selector' — see compiler-core_diagnostics
    message: string;
    stack?: string;
    filename?: string;
    start?: Location; end?: Location;   // from locate-character
    position?: [number, number];
    frame?: string;          // code frame rendered by get_code_frame
}
```

They are deliberately the same shape: warnings returned in `CompileResult.warnings`, errors thrown. The diagnostic catalog itself lives in [compiler-core_diagnostics](compiler-core_diagnostics.md); this module only fixes the envelope.

### Options Types

`CompileOptions extends ModuleCompileOptions` — the split mirrors the two public entry points (`compile` vs `compileModule`, the latter only accepting the shared subset):

```mermaid
classDiagram
    class ModuleCompileOptions {
        +dev? boolean
        +generate? 'client' | 'server' | false
        +filename? string
        +rootDir? string
        +warningFilter? (w: Warning) => boolean
        +experimental? { async?: boolean }
    }
    class CompileOptions {
        +name? string
        +customElement? boolean
        +namespace? Namespace
        +css? 'injected' | 'external'
        +cssHash? CssHashGetter
        +fragments? 'html' | 'tree'
        +runes? boolean
        +discloseVersion? boolean
        +compatibility? { componentApi?: 4 | 5 }
        +sourcemap? object | string
        +outputFilename? string
        +cssOutputFilename? string
        +hmr? boolean
        +modernAst? boolean
        +preserveComments? boolean
        +preserveWhitespace? boolean
    }
    class ValidatedModuleCompileOptions {
        «Omit~Required, 'rootDir'~ + rootDir»
    }
    class ValidatedCompileOptions {
        «Required fields + customElementOptions: AST.SvelteOptions['customElement']»
    }
    class OptimizeOptions {
        +hydrate? boolean
    }
    ModuleCompileOptions <|-- CompileOptions : extends
    ModuleCompileOptions <|-- ValidatedModuleCompileOptions
    CompileOptions <|-- ValidatedCompileOptions
```

- `ModuleCompileOptions` covers everything relevant to plain JS/TS modules (`dev`, `generate`, sourcemap bookkeeping, warning filtering, the experimental async flag).
- `CompileOptions` adds component-specific behavior: CSS strategy (`css`/`cssHash`), DOM cloning strategy (`fragments`), runes forcing, legacy compatibility switches (`accessors`, `immutable`, `compatibility.componentApi`), and HMR/modern-AST toggles.
- **`ValidatedCompileOptions` / `ValidatedModuleCompileOptions`** describe the state *after* validation by [compiler-core_options_validation](compiler-core_options_validation.md): defaults are applied (`Required<...>` minus fields allowed to stay `undefined`), `compatibility` becomes fully required, and — notably — `customElementOptions` is populated from the parsed `<svelte:options>` AST node (`AST.Svelte['customElement']`), showing how inline component options merge with compile-time options.
- `OptimizeOptions` is a small internal shape (`hydrate`) used by SvelteKit-adjacent optimization entry points.

### Analysis Metadata Types

These types define what the [compiler-analyzer](compiler-analyzer.md) computes and attaches to AST nodes:

| Type | Role |
| --- | --- |
| `BindingKind` | Discriminates the *kind* of variable binding: `normal`, `prop`, `bindable_prop`, `rest_prop`, `raw_state`, `state`, `derived`, `each`, `snippet`, `store_sub`, `legacy_reactive`, `template`, `static`. Stored on the runtime `Binding` class (`kind` field). |
| `DeclarationKind` | The JS declaration form: `var`/`let`/`const`/`function`/`import`/`param`/`rest_param`/`synthetic`. Stored on `Binding.declaration_kind`. |
| `ExpressionMetadata` | Per-expression reactivity analysis attached (via `/** @internal */ metadata.expression`) to nearly every expression-bearing node: eager `dependencies` vs all `references` (both `Set<Binding>`), plus boolean flags `has_state`, `has_call`, `has_await`, `has_member_expression`, `has_assignment` that drive transformation decisions (e.g. wrapping in deriveds, async handling). |
| `StateField` | One `$state`/`$derived` class field record: the rune used (`StateCreationRuneName`), the property-definition or assignment node, the private key identifier, and the rune `CallExpression`. Collected into `Analysis.classes` (see `phases/types.d.ts`). |

The `Binding`/`Scope` runtime classes that consume `BindingKind`/`DeclarationKind` are documented in [compiler-analyzer](compiler-analyzer.md).

---

## `template.d.ts` — The Modern Template AST (`AST` namespace)

This is the largest and most central declaration file. Every node is a **discriminated union member identified by its `type` string**, extending `BaseNode`:

```ts
interface BaseNode { type: string; start: number; end: number; }
```

### Node Taxonomy

```mermaid
classDiagram
    class BaseNode {
        +type string
        +start number
        +end number
    }
    class Fragment {
        +nodes: Array~Text|Tag|ElementLike|Block|Comment~
        +metadata: transparent · dynamic · has_await
    }
    class Root {
        +options: SvelteOptions | null
        +fragment: Fragment
        +css: AST.CSS.StyleSheet | null
        +instance: Script | null
        +module: Script | null
        +comments: JSComment[]
        +metadata: ts
    }
    BaseNode <|-- Root
    BaseNode <|-- Fragment

    namespace Tag {
        ExpressionTag
        HtmlTag
        ConstTag
        DebugTag
        RenderTag
        AttachTag
    }
    namespace Block {
        EachBlock
        IfBlock
        AwaitBlock
        KeyBlock
        SnippetBlock
    }
    namespace ElementLike {
        Component
        RegularElement
        SvelteElement
        SvelteComponent
        SvelteSelf
        SvelteBoundary
        SvelteBody
        SvelteDocument
        SvelteFragment
        SvelteHead
        SvelteWindow
        TitleElement
        SlotElement
        SvelteOptionsRaw
    }
```

The `Fragment.nodes` union (`Text | Tag | ElementLike | Block | Comment`) composes the four families:

- **Tag** — `{...}` interpolations and special tags: `ExpressionTag`, `HtmlTag` (`{@html}`), `ConstTag` (`{@const}`), `DebugTag` (`{@debug}`), `RenderTag` (`{@render}`), `AttachTag` (`{@attach}`).
- **ElementLike** — everything with `name` + `attributes` + `fragment` via `BaseElement`: `RegularElement`, `Component`, `SvelteComponent`, `SvelteSelf`, `SvelteElement`, the `svelte:` specials (`SvelteBody`, `SvelteBoundary`, `SvelteDocument`, `SvelteFragment`, `SvelteHead`, `SvelteWindow`), `TitleElement`, `SlotElement`, and `SvelteOptionsRaw` (parse-time-only intermediate for `<svelte:options>`; becomes `AST.SvelteOptions` on `Root.options`).
- **Block** — control flow: `EachBlock`, `IfBlock`, `AwaitBlock`, `KeyBlock`, `SnippetBlock`.
- **Directives** (`AttributeLike`) — `BindDirective`, `OnDirective`, `ClassDirective`, `StyleDirective`, `TransitionDirective`, `AnimateDirective`, `UseDirective`, `LetDirective` — attached to elements through `BaseElement.attributes: Array<Attribute | SpreadAttribute | Directive | AttachTag>`.
- **Supporting nodes** — `Text` (with decoded `data` and raw `raw`), `Comment`, `Attribute` (value is `true | ExpressionTag | Array<Text | ExpressionTag>`), `SpreadAttribute`, `Script` (wraps an estree `Program`, `context: 'default' | 'module'`), and `JSComment` (preserved script/expression comments).

### The `metadata` Pattern

Most nodes carry a `/** @internal */ metadata` field. This is the compiler's convention for **separating what the user wrote from what the compiler derived**:

```ts
export interface EachBlock extends BaseNode {
    type: 'EachBlock';
    expression: Expression;
    context: Pattern | null;
    body: Fragment;
    /* ... */
    /** @internal */
    metadata: {
        expression: ExpressionMetadata;      // ← defined in index.d.ts
        keyed: boolean;
        contains_group_binding: boolean;
        declarations: Map<string, Binding>;  // ← runtime class from phases/scope.js
        is_controlled: boolean;              // single-child optimization
        transitive_deps: Set<Binding>;
    };
}
```

| Node(s) | Notable internal metadata | Consumer |
| --- | --- | --- |
| `Fragment` | `transparent` (scope delegation), `dynamic` (mount/hydrate traversal), `has_await` | transformer |
| `Root` | `ts` (parsed with TypeScript) | parser / analyzer |
| All expression-bearing nodes | `metadata.expression: ExpressionMetadata` | analyzer writes, transformer reads |
| `RegularElement` / `SvelteElement` | `svg`, `mathml`, `has_spread`, `scoped`, `path` | CSS scoping, transformer |
| `Component` / `SvelteComponent` / `SvelteSelf` / `RenderTag` / `SnippetBlock` | `snippets` / `sites` sets — cross-referencing snippet definitions and their render sites for **CSS pruning** | analyzer / CSS transform |
| `EachBlock` | `is_controlled`, `transitive_deps`, `declarations` | client transformer |
| `Attribute` | `delegated` (`DelegatedEvent`), `needs_clsx` | client transformer |
| `BindDirective` | `binding_group_name`, `parent_each_blocks` | `bind_group` logic |

### Top-Level Types

- **`Namespace`** — `'html' | 'svg' | 'mathml'`; determined per-element by the parser and surfaced as `RegularElement.metadata.svg/mathml` and `CompileOptions.namespace`.
- **`DelegatedEvent`** — marks event attributes eligible for event delegation: `{ hoisted: true; function: ... }` (handler extracted to module scope) or `{ hoisted: false }`.
- **`SvelteNode`** — the grand traversal union: `Node | TemplateNode | AST.Fragment | _CSS.Node | Script`. The transformer's generic `visit` (see [compiler-transformer](compiler-transformer.md)) walks exactly this union, and scopes are keyed by it (`Map<AST.SvelteNode, Scope>` in `phases/types.d.ts`).
- **`TemplateNode`** — everything that can appear in a template (Root, Text, all Tags, ElementLike, Attributes, Directives, Comment, Block).
- **`SvelteOptions`** — the typed inline options of `<svelte:options>` (`runes`, `immutable`, `accessors`, `preserveWhitespace`, `namespace`, `css: 'injected'`, and the full `customElement` config incl. `props` and `extend`). These override `CompileOptions` per component — the merge is reflected in `ValidatedCompileOptions.customElementOptions`.

---

## `css.d.ts` — The CSS AST (`_CSS` namespace)

The CSS AST mirrors the cascade structure of a stylesheet, from sheet down to individual simple selectors, and carries the scoping metadata that makes Svelte's scoped styles work:

```mermaid
classDiagram
    class StyleSheet {
        +attributes any[]
        +children: Array~Atrule|Rule~
        +content: { styles, comment }
    }
    class Atrule {
        +name string
        +prelude string
        +block Block | null
    }
    class Rule {
        +prelude SelectorList
        +block Block
        +metadata: parent_rule · has_local_selectors<br/>has_global_selectors · is_global_block
    }
    class Block {
        +children: Array~Declaration|Rule|Atrule~
    }
    class Declaration {
        +property string
        +value string
    }
    class SelectorList {
        +children: ComplexSelector[]
    }
    class ComplexSelector {
        +children: RelativeSelector[]
        +metadata: rule · is_global · used
    }
    class RelativeSelector {
        +combinator Combinator | null
        +selectors SimpleSelector[]
        +metadata: is_global · is_global_like · scoped
    }
    class Combinator {
        +name string
    }
    class SimpleSelector {
        «union»
    }
    class TypeSelector
    class IdSelector
    class ClassSelector
    class AttributeSelector {
        +matcher / value / flags
    }
    class PseudoElementSelector
    class PseudoClassSelector {
        +args SelectorList | null
    }
    class Percentage
    class Nth
    class NestingSelector {
        +name '&'
    }

    StyleSheet --> Atrule
    StyleSheet --> Rule
    Rule --> SelectorList
    Rule --> Block
    Atrule --> Block
    Block --> Declaration
    Block --> Rule
    Block --> Atrule
    SelectorList --> ComplexSelector
    ComplexSelector --> RelativeSelector
    RelativeSelector --> Combinator
    RelativeSelector --> SimpleSelector
    SimpleSelector --> TypeSelector
    SimpleSelector --> IdSelector
    SimpleSelector --> ClassSelector
    SimpleSelector --> AttributeSelector
    SimpleSelector --> PseudoElementSelector
    SimpleSelector --> PseudoClassSelector
    SimpleSelector --> Percentage
    SimpleSelector --> Nth
    SimpleSelector --> NestingSelector
```

Design highlights:

- **Selector granularity matters for scoping.** The four-level chain `SelectorList → ComplexSelector → RelativeSelector → SimpleSelector` exists so the analyzer can decide, per *relative* selector, whether it is `is_global` (e.g. `:global(...)`), `is_global_like` (`:root`, `:host`, `::view-transition`, or selectors following a `:global`), or needs scoping. The predicates consuming this metadata (`is_in_global_block`, `is_unscoped`, `is_global_block_selector`) live in [compiler-analyzer](compiler-analyzer.md) (`css/css-analyze.js`), and `ComplexSelector.metadata.used` records whether a selector matched any element during pruning.
- **`Rule.metadata`** tracks `parent_rule` (for CSS nesting), `has_local_selectors`, `has_global_selectors`, and `is_global_block` — the last one corresponds directly to the `@global`-style `:global { ... }` blocks whose errors/warnings (`css_global_block_invalid_*`) are catalogued in [compiler-core_diagnostics](compiler-core_diagnostics.md).
- **`_CSS.Node`** is the traversal union for the CSS walker (`StyleSheet | Rule | Atrule | SelectorList | Block | ComplexSelector | RelativeSelector | Combinator | SimpleSelector | Declaration`), explicitly noted in source as being shaped "for zimmerframe" (the tree-walking utility).
- The namespace is exported back into the template world as `AST.CSS` (`export type { _CSS as CSS }` in `template.d.ts`), which is why `Root.css` is typed `AST.CSS.StyleSheet | null`.

---

## `legacy-nodes.d.ts` — The Svelte 4 AST

This file preserves the **pre-Svelte-5 node shapes** (`Legacy*` names map to old `type` strings like `'Element'`, `'InlineComponent'`, `'MustacheTag'`, `'EventHandler'`, `'Action'`, `'Binding'`). It exists to serve the [compiler-migrator](compiler-migrator.md), which parses legacy sources into these structures, transforms them, and emits Svelte 5 code.

Key structural differences from the modern AST:

| Concept | Legacy shape | Modern equivalent |
| --- | --- | --- |
| Root | `LegacyRoot { html, css?, instance?, module? }` (loose `any` children) | `Root` (fully typed) |
| Text interpolation | `LegacyMustacheTag` / `LegacyRawMustacheTag` | `ExpressionTag` / `HtmlTag` |
| Event handlers | `LegacyEventHandler` (attribute-like) | `OnDirective` |
| Actions | `LegacyAction` | `UseDirective` |
| Two-way bindings | `LegacyBinding` | `BindDirective` |
| Class/style toggles | `LegacyClass`, `LegacyStyleDirective` | `ClassDirective`, `StyleDirective` |
| `svelte:` specials | `LegacyWindow`, `LegacyHead`, `LegacyBody`, `LegacyDocument` | `SvelteWindow`, `SvelteHead`, `SvelteBody`, `SvelteDocument` |
| Slots | `LegacySlot`, `LegacySlotTemplate`, `LegacyLet` | `SlotElement`, `SnippetBlock` + `children`/`Snippet` props |
| Await blocks | `LegacyPendingBlock`, `LegacyThenBlock`, `LegacyCatchBlock` (children arrays) | single `AwaitBlock` with `pending/then/catch` `Fragment`s |

The union taxonomies `LegacyAttributeLike` (`LegacyAttribute | LegacySpread | LegacyDirective`), `LegacyElementLike` (16 node types), and the top-level `LegacySvelteNode` define the migrator's traversal space. Deliberately hybrid nodes keep the migration surface small:

- `SnippetBlock` and `RenderTag` already exist here with legacy-compatible shapes (Svelte 5 features that can be *emitted* by migration).
- `LegacySelector` reuses `AST.CSS.Combinator` / `AST.CSS.SimpleSelector` for CSS, and `LegacyAttribute.value` reuses `AST.Text` / `AST.ExpressionTag`.
- `LegacyComment` carries `ignores: string[]` — the `<!-- svelte-ignore ... -->` directives that [compiler-core_compile_state](compiler-core_compile_state.md) (`push_ignore`/`pop_ignore`) and [compiler-core_diagnostics](compiler-core_diagnostics.md) (`migrate_svelte_ignore`) process.

---

## Data Flow Through the Compiler Pipeline

The type definitions are the *contract* each phase signs; no phase owns them. The diagram below shows where each type family is produced, populated, and consumed:

```mermaid
flowchart TD
    SRC["`.svelte source`"] --> PRE["preprocess<br/>(compiler-preprocessor)<br/>types: Processed, SveltePreprocessor"]

    PRE --> PARSE["1-parse<br/>(compiler-parser)"]
    PARSE -->|"creates AST nodes<br/>AST.Root · Fragment · Tag ·<br/>ElementLike · Block · Attribute ·<br/>_CSS.StyleSheet · Script"| AST0["Fresh AST<br/>(metadata empty/default)"]

    AST0 --> VALOPT["validate-options<br/>(compiler-core_options_validation)<br/>CompileOptions → ValidatedCompileOptions<br/>(merges &lt;svelte:options&gt; / AST.SvelteOptions)"]

    VALOPT --> ANALYZE["2-analyze<br/>(compiler-analyzer)"]
    ANALYZE -->|"fills metadata.expression:<br/>ExpressionMetadata (deps, has_state,<br/>has_call, has_await ...)<br/>creates Binding / Scope<br/>CSS: is_global, used, is_global_block"| AST1["Analyzed AST<br/>(metadata populated)"]

    AST1 --> CHECKS{"diagnostics<br/>(compiler-core_diagnostics)"}
    CHECKS -->|"Warning[] / throws CompileError<br/>(ICompileDiagnostic shape)"| RESULT

    AST1 --> TRANSFORM["3-transform<br/>(compiler-transformer)<br/>walks AST.SvelteNode + _CSS.Node<br/>reads ExpressionMetadata, BindingKind,<br/>snippets/sites sets, scoping flags"]
    TRANSFORM -->|"js: { code, map }<br/>css: { code, map, hasGlobal } | null"| RESULT["CompileResult<br/>(types/index.d.ts)"]
    AST1 -.->|"ast field"| RESULT
    CHECKS -.->|"warnings field"| RESULT

    SRC -.->|"legacy code"| MIGRATE["migrate<br/>(compiler-migrator)<br/>LegacyRoot / LegacySvelteNode"] -.->|"Svelte 5 code"| PARSE

    RESULT --> PUBLIC["Public types<br/>(svelte-public-types)<br/>re-exports CompileResult, Root,<br/>BaseNode, CompileError ..."]
```

Phase responsibilities by type:

1. **Parse** ([compiler-parser](compiler-parser.md)) instantiates the node shapes — every `type`, `start`, `end`, and user-authored field originates here. Legacy sources route through `Legacy*` shapes via the migrator instead.
2. **Validate options** ([compiler-core_options_validation](compiler-core_options_validation.md)) narrows `CompileOptions` into `ValidatedCompileOptions`, folding in `AST.SvelteOptions` from `<svelte:options>`.
3. **Analyze** ([compiler-analyzer](compiler-analyzer.md)) is the *producer* of almost all `metadata`: it creates `Binding`/`Scope` instances (keyed by `SvelteNode`), computes `ExpressionMetadata` for each expression, marks CSS selector globals/usage, cross-links `SnippetBlock`/render sites for pruning, and collects `StateField`s.
4. **Diagnostics** ([compiler-core_diagnostics](compiler-core_diagnostics.md)) emit `Warning`/`CompileError`, both constrained by `ICompileDiagnostic` as defined here.
5. **Transform** ([compiler-transformer](compiler-transformer.md)) is the primary *consumer*: client and server visitors switch on `node.type` across `AST.SvelteNode` and branch on analyzer metadata (`has_state`, `is_controlled`, `scoped`, `delegated`, ...) to generate output; the final shape of that output is `CompileResult`.
6. **Public API** ([compiler-core_public_api](compiler-core_public_api.md), [svelte-public-types](svelte-public-types.md)) exposes `compile`/`compileModule` with the `CompileOptions → CompileResult` signature, and re-exports a curated subset of these types to library consumers.

---

## Design Conventions

When extending or modifying this module, follow these invariants:

1. **Discriminated unions by `type`.** Every node family is a string-literal union on `type`; visitors and transformers switch on it. Adding a node means: add the interface, add it to the correct taxonomy union (`Tag`/`Block`/`ElementLike`/`Directive`), and add `Fragment.nodes` compatibility implicitly.
2. **`/** @internal */` metadata.** User-facing fields are stable and documented; compiler-derived fields live under `metadata` and are *not* part of the public AST contract (unless `modernAst` semantics change). Keep derived state out of the user-facing surface.
3. **Positions are mandatory.** `BaseNode.start`/`end` (and the estree augmentation for JS nodes) back the `ICompileDiagnostic.position/start/end/frame` machinery — never introduce a node without offsets.
4. **One source of truth per domain.** Re-export through `index.d.ts` (`export * from './template.js'`, `export { Binding, Scope }`) rather than redefining; downstream modules import from `#compiler`.
5. **Legacy types never modernize silently.** `legacy-nodes.d.ts` mirrors the Svelte 4 grammar for the migrator's benefit; share modern leaf types only where the grammars genuinely coincide.

---

## Related Modules

- [compiler-core_public_api](compiler-core_public_api.md) — the `compile`/`compileModule` entry points whose signatures are defined here.
- [compiler-core_options_validation](compiler-core_options_validation.md) — produces `ValidatedCompileOptions` from `CompileOptions` + `AST.SvelteOptions`.
- [compiler-core_diagnostics](compiler-core_diagnostics.md) — error/warning catalogs typed by `Warning`/`CompileError`.
- [compiler-core_compile_state](compiler-core_compile_state.md) — the `svelte-ignore` state machine interacting with `LegacyComment.ignores`.
- [compiler-core_ast_builders](compiler-core_ast_builders.md) — builders that construct estree nodes compatible with the augmented estree types.
- [compiler-parser](compiler-parser.md) — creates the `AST` and `_CSS` trees.
- [compiler-analyzer](compiler-analyzer.md) — populates `metadata`, `Binding`, `Scope`, `StateField`.
- [compiler-transformer](compiler-transformer.md) — consumes `AST.SvelteNode`/`_CSS.Node` to emit `CompileResult.js`/`css`.
- [compiler-migrator](compiler-migrator.md) — consumes `LegacySvelteNode` shapes.
- [svelte-public-types](svelte-public-types.md) — the public re-export surface for these types.
