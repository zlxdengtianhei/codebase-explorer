# Context API (`context-api`)

## 1. Purpose and Overview

The **context-api** module implements Svelte's *component context system* — the mechanism that lets a component associate arbitrary values with itself (`setContext`) and lets any descendant retrieve them (`getContext`, `hasContext`, `getAllContexts`) without prop drilling. It also owns the **component context stack**: the linked-list of per-component records that the runtime pushes/pops while a component initialises, and which underpins related runtime services such as legacy-mode detection (`is_runes`), deferred effect flushing, `onDestroy` collection, and dev-mode error location tracking (`add_svelte_meta`).

Because Svelte components compile to **two different runtimes**, the same public semantics are implemented twice (each documented in detail in its own sub-module file):

| Implementation | File | Consumer | Sub-module docs |
|---|---|---|---|
| **Client** (reactive, effect-driven) | `packages/svelte/src/internal/client/context.js` | Compiled client-side components, re-exported by `index-client.js` | [context-api_client-context.md](context-api_client-context.md) |
| **Server** (synchronous SSR) | `packages/svelte/src/internal/server/context.js` | Compiled server-side components, re-exported by `index-server.js` | [context-api_server-context.md](context-api_server-context.md) |

Both files expose the identical public surface — `setContext`, `getContext`, `hasContext`, `getAllContexts` — plus platform-specific lifecycle helpers (`push`/`pop`) that the compiler emits at the start/end of every component body. The public functions themselves are documented in the [public-api](public-api.md) module; this module documents the internal machinery.

### Public surface (identical on both targets)

| Function | Description |
|---|---|
| `setContext(key, context)` | Associates `context` with the current component under `key`; returns `context` |
| `getContext(key)` | Returns the value stored under `key` by the closest ancestor (or `undefined`) |
| `hasContext(key)` | Returns whether `key` exists in the inherited context |
| `getAllContexts<T>()` | Returns the whole (inherited) context `Map`, e.g. to forward context when creating a component programmatically |

## 2. Architecture Overview

```mermaid
flowchart TB
    subgraph PUB["Public API module — public-api"]
        IC["index-client.js<br/>setContext / getContext / hasContext / getAllContexts"]
        IS["index-server.js<br/>setContext / getContext / hasContext / getAllContexts"]
    end

    subgraph CA["context-api module"]
        CC["internal/client/context.js<br/>client implementation + component stack"]
        SC["internal/server/context.js<br/>server implementation + component stack"]
    end

    subgraph CRE["Client Runtime Engine module — client-reactivity-engine"]
        RT["runtime.js<br/>active_effect · active_reaction"]
        EF["reactivity/effects.js<br/>create_user_effect"]
        FL["flags/index.js<br/>async_mode_flag · legacy_mode_flag"]
    end

    subgraph SR["Server Runtime module — server-runtime"]
        SI["internal/server/index.js<br/>on_destroy queue"]
    end

    ERR["errors.js (client &amp; server)<br/>lifecycle_outside_component · set_context_after_init"]

    IC -->|"re-export"| CC
    IS -->|"re-export"| SC

    CC -->|"guards setContext"| RT
    CC -->|"flush deferred effects on pop()"| EF
    CC -->|"mode detection"| FL
    SC -->|"forward onDestroy callbacks"| SI
    CC -.-> ERR
    SC -.-> ERR
```

### Component context records

Both implementations keep a module-level "current component" variable that points at the top of a **singly linked stack** (the `p` parent pointer). Each record carries a lazily created context map `c`:

```mermaid
classDiagram
    class ComponentContext_client {
        +ComponentContext|null p   parent (linked list)
        +Map|null c                context map (lazily created)
        +Array|null e              deferred effects, flushed by pop()
        +Record s                  props (legacy / createEventDispatcher)
        +Record|null x             exports
        +LegacyRecord|null l       legacy $: / lifecycle state (runes check)
        +any function              DEV only: component function
    }
    class Component_server {
        +Component|null p          parent (linked list)
        +Map|null c                context map (lazily created)
        +Array|null d              onDestroy callbacks, drained by pop()
        +any function              DEV only: component function
    }
```

### Context inheritance — lazy copy-on-first-use

The central trick of this module is that **context is not stored in a global tree**. When a component first calls any context function, its map is created and *seeded with a snapshot of the nearest ancestor's map* (via `new Map(parentMap)`). This makes reads O(1) after initialisation and gives every subtree an isolated map that only inherits entries that existed above it.

```mermaid
sequenceDiagram
    autonumber
    participant C as Component (child)
    participant G as get_or_init_context_map()
    participant P as Ancestor records

    C->>G: any context API call
    G->>G: current record is null?<br/>throw lifecycle_outside_component
    alt record.c is null (first use)
        G->>P: get_parent_context(): walk p chain
        P-->>G: nearest non-null ancestor map (or null)
        G->>G: record.c = new Map(parentMap | undefined)
    end
    G-->>C: operate on record.c (get / set / has / map)
```

> **Consequence:** a child's `getAllContexts()` returns a *copy* — writes to it do not leak into the parent's context; only `setContext` on the child affects the child's own map (and its future descendants).

## 3. Key Flows

### 3.1 Component initialisation (shared skeleton)

The compiler emits `push(...)` at the start and `pop(...)` at the end of each component function, nesting them exactly like the component tree:

```mermaid
sequenceDiagram
    autonumber
    participant Compiled as Compiled component
    participant CX as context.js
    participant Out as Runtime output

    Compiled->>CX: push(props, runes, fn)
    Note over CX: new record pushed onto stack<br/>(client: props/effects/legacy state;<br/>server: onDestroy bucket)
    Compiled->>Compiled: run template / init code<br/>→ setContext allowed here
    Compiled->>CX: pop(component)
    alt client
        CX->>Out: flush record.e via create_user_effect
    else server
        CX->>Out: forward record.d into on_destroy queue
    end
    Note over CX: stack pointer restored to parent
```

### 3.2 Client-side `setContext` guard (async mode)

In async mode (see [flags in the client-reactivity-engine](client-reactivity-engine.md)) a component's initialisation can be suspended by `await`. To keep context resolution deterministic, `setContext` is only legal while the component's *branch effect* exists but has **not run yet**, and outside any reactive computation:

```mermaid
flowchart TD
    A["setContext(key, ctx)"] --> B{"async_mode_flag?"}
    B -- "no" --> OK["record.c.set(key, ctx)"]
    B -- "yes" --> C{"active_reaction === null<br/>AND active_effect is BRANCH_EFFECT<br/>AND EFFECT_RAN flag not set"}
    C -- "valid" --> OK
    C -- "invalid" --> E["throw set_context_after_init"]
```

The same guard does **not** exist on the server because SSR render is strictly synchronous — initialisation can never be resumed later.

### 3.3 Dev metadata stack (`add_svelte_meta`, client only)

`add_svelte_meta(callback, type, component, line, column, additional)` temporarily pushes a `DevStackEntry` (file/line/column/type + parent chain) around a callback. This is how dev-mode errors such as "rendered \$state was mutated" can point at the exact `<Component>` / `{#if}` / `{#each}` / `{#await}` / `{#key}` / `{@render}` construct that caused them. The stack pointer lives in this module (`dev_stack`), even though it is only consulted by dev tooling (see [client-dev-tooling](client-dev-tooling.md)).

## 4. Client vs Server — Implementation Notes

| Aspect | Client (`internal/client/context.js`) | Server (`internal/server/context.js`) |
|---|---|---|
| Stack state | `component_context: ComponentContext \| null` (+ `set_component_context`) | `current_component: Component \| null` |
| `push` | Builds rich record: props `s`, exports `x`, legacy state `l` (unless runes), `function` in DEV | Builds minimal record `{ p, c, d }` (+ `function` in DEV) |
| `pop` | Flushes deferred `e` effects through `create_user_effect`, stores `x`, restores parent, restores `dev_current_component_function` | Pushes collected `d` callbacks onto the SSR `on_destroy` queue (drained at end of `render`), restores parent |
| `setContext` guard | Rejects calls after init in async mode (`set_context_after_init`) | None — synchronous render makes it impossible |
| Context-map creation | Identical: `record.c ??= new Map(parent_map)` | Identical |
| Error on misuse | `lifecycle_outside_component(name)` when no component is active | Same |
| Extra exports | `add_svelte_meta`, `dev_stack`, `dev_current_component_function`, `is_runes`, `set_dev_stack`, `set_dev_current_component_function` | — |
| `is_runes()` | `!legacy_mode_flag \|\| (component_context.l === null)` — tells the runtime whether the current component uses runes | n/a (server is always runes-mode) |

## 5. Sub-modules

Detailed documentation for each implementation:

- **[Client context runtime](context-api_client-context.md)** — `packages/svelte/src/internal/client/context.js`: the reactive runtime's context implementation, component context stack, deferred effect flushing, async-mode `setContext` validation, `is_runes()`, and the dev metadata stack.
- **[Server context runtime](context-api_server-context.md)** — `packages/svelte/src/internal/server/context.js`: the synchronous SSR context implementation, `push`/`pop` component stack, and `onDestroy` queue forwarding.

## 6. Relation to Other Modules

- **[public-api](public-api.md)** — re-exports the four context functions from `index-client.js` / `index-server.js`; the user-facing documentation of `setContext` etc. lives there.
- **[client-reactivity-engine](client-reactivity-engine.md)** — provides `active_effect` / `active_reaction` (used to validate `setContext` timing), `create_user_effect` (flushes deferred effects on `pop`), and the mode flags (`async_mode_flag`, `legacy_mode_flag`). The signal graph and batching machinery are documented there and are *not* repeated here.
- **[server-runtime](server-runtime.md)** — hosts the `on_destroy` queue that server `pop()` drains into, and the render pipeline that owns the server `push`/`pop` cadence.
- **[client-dev-tooling](client-dev-tooling.md)** — consumes `dev_stack` / `add_svelte_meta` metadata to produce precise error locations.
- **[legacy-compat](legacy-compat.md)** — relies on `component_context` (`s` props, `x` exports, `l` legacy state) and `is_runes()` for Svelte 4 `class`-component shims and `$:` semantics.
