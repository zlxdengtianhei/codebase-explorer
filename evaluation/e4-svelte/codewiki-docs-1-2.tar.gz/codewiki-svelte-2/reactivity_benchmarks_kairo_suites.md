# Reactivity Benchmarks — Kairo Suites (`reactivity_benchmarks_kairo_suites`)

> **Module path:** `benchmarking/benchmarks/reactivity/kairo/`
> **Parent module:** [Engineering Tooling (Benchmarks, Verification & Playground)](Engineering_Tooling_(Benchmarks,_Verification___Playground).md)
> **Engine under test:** [Client Runtime Engine (Reactivity & DOM Rendering)](Client_Runtime_Engine_(Reactivity___DOM_Rendering).md)

## 1. Overview

The **Kairo suites** are a family of eight micro-benchmark files (16 exported benchmark functions) that stress Svelte 5's internal signals runtime (`svelte/internal/client`) across the most important **dependency-graph topologies** a reactivity engine must handle: linear chains, wide fan-out, deep propagation, diamond merges, many-to-many multiplexing, repeated dependency reads, cascading triangles, and unstable (branching) dependencies.

They are adapted from the [js-reactivity-benchmark](https://github.com/milomg/js-reactivity-benchmark) project (whose reactivity core is named "Kairo"), with the tests tweaked to capture additional data — most notably each topology is measured in an **owned** and an **unowned** variant, isolating the cost of signal ownership bookkeeping inside `$.effect_root` scopes.

Every benchmark doubles as a **correctness conformance test**: each `run()` invocation asserts exact computed values and exact effect-execution counts, so a performance regression that also breaks semantics fails loudly (the harness exits with code 1).

**Key characteristics:**

- **16 exports** — 8 topologies × 2 ownership modes (`*_owned` / `*_unowned`)
- **Uniform shape** — every file follows the same `setup() → warm-up → fastest_test()` template, making results directly comparable
- **Self-validating** — `assert()` guards on values *and* effect counts; a benchmark that silently computes wrong results cannot "pass"
- **GC-aware timing** — wall-clock time *and* garbage-collection time are reported separately per benchmark

## 2. Position in the System

The Kairo suites are one of three reactivity benchmark families aggregated by `benchmarking/benchmarks/reactivity/index.js`:

| Suite family | Focus | Documentation |
|---|---|---|
| **Kairo suites** (this module) | Dependency-graph *topologies*: propagation, dedup, ownership | *this document* |
| `sbench.js` | Signal/derived *creation cost* and fan-out ratios (0→1, 1→1, … 1→1000) | [reactivity_benchmarks_sbench](reactivity_benchmarks_sbench.md) |
| `mol_bench.js` | Object-signal graph from the Moli project | [reactivity_benchmarks_mol_bench](reactivity_benchmarks_mol_bench.md) |

Together they form the `reactivity_benchmarks` suite executed by the top-level harness `benchmarking/run.js`, which also runs the SSR suite (see [ssr_benchmarks](ssr_benchmarks.md)). Results are consumed for cross-library comparison via [benchmark_comparison](benchmark_comparison.md).

## 3. Architecture

### 3.1 Component diagram

```mermaid
flowchart TB
    subgraph harness["Benchmark Harness"]
        RUN["benchmarking/run.js<br/>entry point<br/>$.push({}, true) → run suites → aggregate totals"]
        IDX["benchmarks/reactivity/index.js<br/>reactivity_benchmarks registry<br/>(imports all 16 kairo exports)"]
    end

    subgraph kairo["reactivity_benchmarks_kairo_suites (this module)"]
        direction LR
        A["kairo_avoidable.js"]
        B["kairo_broad.js"]
        DE["kairo_deep.js"]
        DI["kairo_diamond.js"]
        MU["kairo_mux.js"]
        RE["kairo_repeated.js"]
        TR["kairo_triangle.js"]
        UN["kairo_unstable.js"]
        KU["kairo/util.js<br/>busy()"]
    end

    subgraph shared["Shared benchmark utilities"]
        UTIL["benchmarking/utils.js<br/>fastest_test(), run_tracked(),<br/>run_timed(), GarbageTrack, assert()"]
    end

    subgraph engine["Svelte Client Runtime — engine under test"]
        API["svelte/internal/client<br/>state · derived · get · set<br/>flush · effect_root · render_effect"]
    end

    RUN --> IDX
    IDX --> A & B & DE & DI & MU & RE & TR & UN
    A -- "artificial load" --> KU
    A & B & DE & DI & MU & RE & TR & UN --> UTIL
    A & B & DE & DI & MU & RE & TR & UN --> API
    UTIL --> API
```

### 3.2 File & export inventory

| File | Exports | Topology under test |
|---|---|---|
| `kairo_avoidable.js` | `kairo_avoidable_owned`, `kairo_avoidable_unowned` | Linear chain with skippable (constant) links + deliberate heavy work |
| `kairo_broad.js` | `kairo_broad_owned`, `kairo_broad_unowned` | 1 source → 50 parallel 2-deep chains, each with its own effect |
| `kairo_deep.js` | `kairo_deep_owned`, `kairo_deep_unowned` | 50-deep linear chain, single sink effect |
| `kairo_diamond.js` | `kairo_diamond_owned`, `kairo_diamond_unowned` | Fan-out (×5 branches) then merge into a `sum` node |
| `kairo_mux.js` | `kairo_mux_owned`, `kairo_mux_unowned` | 100 sources → multiplexer object → 100 split chains |
| `kairo_repeated.js` | `kairo_repeated_owned`, `kairo_repeated_unowned` | One derived reading the *same* source 30 times |
| `kairo_triangle.js` | `kairo_triangle_owned`, `kairo_triangle_unowned` | 10-level cascade merged by a single `sum` node |
| `kairo_unstable.js` | `kairo_unstable_owned`, `kairo_unstable_unowned` | Derived whose dependency set flips with input parity |

**Supporting files (outside the module, depended upon):**

- `benchmarking/utils.js` — measurement primitives (`fastest_test`, `run_tracked`, `GarbageTrack`, `run_timed`) and the `assert` guard
- `benchmarking/benchmarks/reactivity/kairo/util.js` — `busy()`, a ~100-iteration no-op loop used as artificial CPU load (imported only by `kairo_avoidable.js`)

## 4. Benchmark Anatomy

### 4.1 The shared template

All eight files are structurally identical. Every export follows this recipe:

```js
function setup() {
    // 1. BUILD — create the signal graph
    let head = $.state(0);                       // writable source
    let current = $.derived(() => $.get(head));  // computed nodes
    // … more deriveds …

    // 2. OBSERVE — sink effect inside an ownership root
    const destroy = $.effect_root(() => {
        $.render_effect(() => {
            $.get(tail);        // establish dependencies
            counter++;          // execution counter for assertions
        });
    });

    // 3. EXERCISE — drive updates and validate invariants
    return {
        destroy,
        run() {
            $.flush(() => $.set(head, 1));       // batched update
            assert($.get(tail) === EXPECTED);    // value correctness
            for (/* N iterations */) {
                $.flush(() => $.set(head, i));
                assert($.get(tail) === EXPECTED(i));
            }
            assert(counter === EXPECTED_COUNT);  // effect-count correctness
        }
    };
}

export async function kairo_x_unowned() {
    // 4. WARM-UP — 10 build/run/destroy cycles to let the JIT settle
    for (let i = 0; i < 10; i++) {
        const { run, destroy } = setup();
        run();
        destroy();
    }

    const { run, destroy } = setup();

    // 5. MEASURE — best-of-10 reps, each running the workload 1000×
    const { timing } = await fastest_test(10, () => {
        for (let i = 0; i < 1000; i++) run();
    });

    destroy();
    return { benchmark: 'kairo_x_unowned', time: timing.time.toFixed(2), gc_time: timing.gc_time.toFixed(2) };
}
```

### 4.2 Benchmark lifecycle (sequence)

```mermaid
sequenceDiagram
    autonumber
    participant H as run.js (harness)
    participant B as kairo_*_owned / _unowned()
    participant F as fastest_test → run_tracked
    participant G as GarbageTrack (PerformanceObserver 'gc')
    participant S as svelte/internal/client ($)

    H->>B: await benchmark()
    B->>S: 10× [setup() → run() → destroy()]  %% JIT warm-up
    B->>S: final setup() → { run, destroy }
    B->>F: fastest_test(10, measureFn)
    loop 10 reps (keep fastest)
        F->>G: v8.collectGarbage(), open watch window
        F->>B: measureFn()
        B->>S: 1000 × run() → flush(set) → propagate → assert
        G->>F: gc_time (sum of 'gc' entries in window)
    end
    F-->>B: fastest { time, gc_time }
    B-->>H: { benchmark, time, gc_time }
    B->>S: destroy() [ _owned: also destroy_owned() ]
```

### 4.3 Owned vs. unowned variants

The central experimental variable in this module is **signal ownership**, which maps directly onto the engine's memory-management paths (see [client-reactivity-engine_signal-graph](Client_Runtime_Engine_(Reactivity___DOM_Rendering).md)):

```mermaid
flowchart TB
    subgraph unowned["*_unowned variant"]
        direction TB
        U1["setup() called at function scope"] --> U2["deriveds created with NO owner<br/>(module-scope unowned context,<br/>entered via $.push({}, true) in run.js)"]
        U2 --> U3["$.effect_root owns only the render_effects"]
        U3 --> U4["destroy() disposes effects;<br/>orphan deriveds are left to GC"]
    end

    subgraph owned["*_owned variant"]
        direction TB
        O1["outer $.effect_root(...) opened first"] --> O2["setup() runs INSIDE the root<br/>→ every derived is owned by the root"]
        O2 --> O3["inner $.effect_root owns the render_effects"]
        O3 --> O4["both destroy() and destroy_owned()<br/>must be called (ownership teardown)"]
    end
```

- **`*_unowned`**: the graph is built where the harness has already pushed an unowned/allow-state context (`$.push({}, true)` in `benchmarking/run.js`). Computed signals have no owner, so the engine skips ownership bookkeeping during creation, but the graph cannot be collectively disposed — it relies on `destroy()` for effects plus garbage collection for the rest.
- **`*_owned`**: `setup()` is invoked inside `$.effect_root(() => { … })`, so every `$.derived` created during setup registers an owner. This exercises owner-linking during creation and owner-unlinking on the paired `destroy_owned()` call — the costs a real component pays, since Svelte components always own their signals.

Comparing `time`/`gc_time` between the two variants quantifies the overhead of ownership tracking per topology.

## 5. Topology Atlas

The eight suites cover the distinct graph shapes a signal engine must optimize. Each diagram below shows one `setup()` graph; `((…))` = writable source, `[…]` = derived, `{{…}}` = render effect sink.

```mermaid
flowchart LR
    subgraph avoidable["kairo_avoidable — skippable chain + busy work"]
        a0((head)) --> a1[c1] --> a2["c2 (value dropped)"] --> a3["c3 + busy()"] --> a4[c4] --> a5[c5] --> ae{{"effect + busy()"}}
    end

    subgraph broad["kairo_broad — wide fan-out (×50 chains)"]
        b0((head)) --> b1[d_i] --> b2[d_i+1] --> be{{effect ×50}}
        b0 -.->|"×50"| b1
    end

    subgraph deep["kairo_deep — 50-deep chain"]
        d0((head)) --> d1[+1] --> d2[+1] --> d3["… ×50"] --> de{{effect}}
    end

    subgraph diamond["kairo_diamond — merge (width 5)"]
        i0((head)) --> i1[b1] & i2[b2] & i3["b3…b5"]
        i1 & i2 & i3 --> i4[sum] --> ie{{effect}}
    end

    subgraph mux["kairo_mux — many↔many (100 sources)"]
        m0((h0…h99)) --> m1[mux object] --> m2["split_i"] --> m3[+1] --> me{{effect ×100}}
    end

    subgraph repeated["kairo_repeated — repeated reads (×30)"]
        r0((head)) --> r1["derived reads head ×30"] --> re{{effect}}
    end

    subgraph triangle["kairo_triangle — cascade + merge (width 10)"]
        t0((head)) --> t1[d1] --> t2[d2] --> t3["… d10"] 
        t0 & t1 & t2 --> ts[sum] --> te{{effect}}
    end

    subgraph unstable["kairo_unstable — branching deps"]
        u0((head)) --> u1[double] & u2[inverse]
        u0 --> u3["×20: head%2 ? double : inverse"] --> ue{{effect}}
    end
```

### 5.1 Suite-by-suite reference

#### `kairo_avoidable` — avoidable recomputation

- **Graph:** `head → c1 → c2 → c3 → c4 → c5 → render_effect`, where `c2` reads `c1` but discards its value (returns `0`), `c3` performs `busy()` before adding, and the sink effect also calls `busy()`.
- **Workload:** 1 + 1000 `flush(set)` cycles per `run()`. Expected value of `c5` is **6 for every input** (`0 + 1 + 2 + 3`).
- **What it measures:** whether the engine avoids propagating through downstream deriveds when an upstream output is unchanged, and the floor cost of "unavoidable" heavy work. `busy()` amplifies wasted-work signals so skippage is visible in timings.

#### `kairo_broad` — wide fan-out

- **Graph:** one `head` feeds 50 independent chains (`derived(+i) → derived(+1)`), each terminated by its own `render_effect`.
- **Workload:** 1 + 50 `flush` cycles; asserts `last === i + 50` and `counter === 50 * 50` (2 500 effect executions per `run()`).
- **What it measures:** scheduling cost of one source change reaching 50 sinks; batch/flush throughput under many observers.

#### `kairo_deep` — deep propagation

- **Graph:** `head` chained through 50 deriveds (`+1` each); a single `render_effect` reads the tail.
- **Workload:** 1 + 50 `flush` cycles; asserts `tail === len + i` and, critically, `counter === 50` — **one** effect run per update despite 50 dirty links.
- **What it measures:** cost of dirty-flag traversal along a long chain, and laziness (intermediate nodes must not re-trigger the sink).

#### `kairo_diamond` — fan-out then merge

- **Graph:** `head` → 5 branch deriveds (`+1`) → a `sum` derived (map + reduce) → one render effect.
- **Workload:** 1 + 500 `flush` cycles; asserts `sum === (i + 1) * width` and `counter === 500` — the merge node must deduplicate so the sink runs **once** per source change.
- **What it measures:** diamond-deduplication correctness and cost (no exponential re-evaluation at merge points).

#### `kairo_mux` — multiplexed many-to-many

- **Graph:** 100 head states → a `mux` derived that reads all heads into one object → 100 split chains (`derived(get(mux)[index]) → derived(+1)`), each with its own render effect.
- **Workload:** two passes of 10 `flush` cycles, each touching one head (`heads[i] = i`, then `heads[i] = i*2`); asserts `splited[i] === i + 1` / `i * 2 + 1`.
- **What it measures:** fan-in (one derived consuming 100 sources) followed by fan-out (100 deriveds consuming one), i.e. the overhead of partial invalidation through a shared aggregation node.

#### `kairo_repeated` — repeated same-dependency reads

- **Graph:** one derived that reads `head` **30 times** inside a loop; one render effect.
- **Workload:** 1 + 100 `flush` cycles; asserts `current === i * size` and `counter === 100`.
- **What it measures:** dependency-deduplication — 30 reads must register a single dependency — plus per-`$.get` overhead when the same signal is read many times within one computation.

#### `kairo_triangle` — cascading triangle

- **Graph:** a 10-level cascade (`d_i = d_{i-1} + 1`, rooted at `head`), with a `sum` derived reading **all** levels plus `head` itself; one render effect.
- **Workload:** 1 + 100 `flush` cycles; asserts `sum === constant − width + i * width` (45 + 10·i) and `counter === 100`.
- **What it measures:** overlapping dependency chains that would cost O(2¹⁰) in a naive pull model; verifies linear-time recomputation of layered graphs.

#### `kairo_unstable` — unstable (branching) dependencies

- **Graph:** `head`, `double = head * 2`, `inverse = -head`, and a derived that loops 20 times: `result += head % 2 ? get(double) : get(inverse)`.
- **Workload:** 1 + 100 `flush` cycles cycling `head` through even and odd values; asserts the initial result `=== 40` (20 × `double`) and `counter === 100`.
- **What it measures:** the cost of a derived whose *dependency set* changes with its inputs — the engine must re-link dependencies when the branch flips while producing correct, stale-free results.

### 5.2 Workload parameters at a glance

| Suite | Sources | Deriveds | Sink effects | `run()` flushes | Expected sink runs / `run()` | Artificial load |
|---|---|---|---|---|---|---|
| avoidable | 1 | 5 | 1 | 1 + 1000 | value-stable (6) | `busy()` ×2 |
| broad | 1 | 100 (50 × 2) | 50 | 1 + 50 | 2 500 | — |
| deep | 1 | 50 | 1 | 1 + 50 | 50 | — |
| diamond | 1 | 6 (5 + sum) | 1 | 1 + 500 | 500 | — |
| mux | 100 | 201 (mux + 100 × 2) | 100 | 20 | — | — |
| repeated | 1 | 1 | 1 | 1 + 100 | 100 | — |
| triangle | 1 | 11 (10 + sum) | 1 | 1 + 100 | 100 | — |
| unstable | 1 | 3 | 1 | 1 + 100 | 100 | — |

> Every measured rep wraps **1000 × `run()`**; `fastest_test` keeps the fastest of **10** reps.

## 6. Execution Pipeline & Measurement

### 6.1 Data flow

```mermaid
flowchart TD
    A["node benchmarking/run.js"] --> B["$.push({}, true)<br/>unowned allow-state context"]
    B --> C["reactivity_benchmarks registry<br/>(sbench ×10 · kairo ×16 · mol ×2)"]
    C --> D["next kairo benchmark fn"]
    D --> E["JIT warm-up:<br/>10 × (setup → run → destroy)"]
    E --> F["fastest_test(10, measureFn)"]
    F --> G["v8.collectGarbage()"]
    G --> H["GarbageTrack.watch(run_timed(fn))<br/>records perf.now() window"]
    H --> I["measureFn: 1000 × run()"]
    I --> J{"all asserts pass?"}
    J -- "no" --> X["throw → run.js catches,<br/>prints '-- Benchmarking Failed --',<br/>process.exit(1)"]
    J -- "yes" --> K["await gcDuration():<br/>sum PerformanceObserver 'gc' entries<br/>inside the window"]
    K --> L["keep rep with smallest time"]
    L --> M["return { benchmark, time, gc_time }"]
    M --> N["run.js adds into<br/>suite_time / total_time"]
    N --> D
```

### 6.2 Measurement primitives (`benchmarking/utils.js`)

| Helper | Role |
|---|---|
| `fastest_test(times, fn)` | Runs `fn` `times` times through `run_tracked`, returns the result with the smallest `timing.time` (best-of-N reduces noise) |
| `run_tracked(fn)` | Forces `v8.collectGarbage()` first, then times `fn` inside a `GarbageTrack` watch window and awaits its `gc_time` |
| `run_timed(fn)` | Plain `performance.now()` wall-clock bracket |
| `GarbageTrack` | `PerformanceObserver` on the `'gc'` entry type; `gcDuration(track_id)` sums GC durations falling inside a recorded time window |
| `assert(cond)` | Throws `'Assertion failed'` — the correctness gate that turns benchmarks into conformance tests |

### 6.3 Result contract

Every exported function resolves to:

```js
{
    benchmark: 'kairo_<suite>_<owned|unowned>', // stable identifier
    time:    '<ms, 2 decimal places>',          // fastest of 10 reps
    gc_time: '<ms, 2 decimal places>'           // GC time inside that rep
}
```

`benchmarking/run.js` sums `time` and `gc_time` into per-suite and grand totals and prints each result object to stdout; [benchmark_comparison](benchmark_comparison.md) reuses the exported functions for cross-library comparisons.

## 7. Dependencies

### 7.1 On the Client Runtime Engine

The suites import the *entire* runtime as `svelte/internal/client` (`import * as $`) and use this API surface (documented in [Client Runtime Engine (Reactivity & DOM Rendering)](Client_Runtime_Engine_(Reactivity___DOM_Rendering).md)):

| API | Used for | Engine area |
|---|---|---|
| `$.state(v)` | writable source signals | signal-graph / sources-and-proxies |
| `$.derived(fn)` | computed signals under test | signal-graph / deriveds |
| `$.get(signal)` | dependency-tracking read | runtime core |
| `$.set(signal, v)` | source writes | sources (`update`) |
| `$.flush(fn)` | synchronous batched propagation | batching & scheduling (`batch.js`, `loop.js`) |
| `$.effect_root(fn)` | ownership scope → `destroy` | effects |
| `$.render_effect(fn)` | sink effects + execution counters | effects |

Because benchmarks call the internal API directly, they measure engine-level behavior with no component/compile-layer noise — the compiler (see [Compiler Pipeline & Language Toolchain](Compiler_Pipeline___Language_Toolchain.md)) is not involved at all.

### 7.2 Sibling modules

- [reactivity_benchmarks_sbench](reactivity_benchmarks_sbench.md) — creation-cost and fan-out-ratio benchmarks (`0→1 … 1→1000`); complements Kairo's propagation-focused topologies.
- [reactivity_benchmarks_mol_bench](reactivity_benchmarks_mol_bench.md) — object-graph benchmark from the Moli suite.
- [ssr_benchmarks](ssr_benchmarks.md) — the other suite executed by the same harness.
- [benchmark_comparison](benchmark_comparison.md) — comparative runner consuming the same exported benchmark functions.

## 8. Extending the Suites

To add a new Kairo topology (e.g. `kairo_<shape>.js`):

1. **Follow the template** (§4.1): a `setup()` returning `{ destroy, run }`, a sink `render_effect` with a `counter`, and exported `*_owned` / `*_unowned` pairs.
2. **Assert values *and* effect counts** — the counters are what make propagation semantics observable; without them, a lazy engine could return correct values via wrong work.
3. **Export the standard result object** with the `kairo_<name>_<mode>` identifier so aggregation and comparison tooling recognize it.
4. **Register both exports** in `benchmarking/benchmarks/reactivity/index.js` (the `reactivity_benchmarks` array).
5. Keep per-`run()` iteration counts high enough (hundreds+) that per-update costs dominate measurement overhead, and rely on `fastest_test`'s warm-up + best-of-10 to control variance.

## 9. Operational Notes

- **Runner:** `node benchmarking/run.js` from the repository root (imports the runtime directly from `packages/svelte/src/internal/client/index.js` — no build step required for the reactivity suites).
- **Environment requirements:** a Node build exposing `v8.collectGarbage()` and `PerformanceObserver` `'gc'` entries (e.g. `--expose-gc`) for the GC-time pipeline; `performance.now()` for wall-clock timing.
- **Failure mode:** any failed `assert` propagates to `benchmarking/run.js`, which prints `-- Benchmarking Failed --`, logs the error, and exits with status `1` — treat a failed run as a *correctness* regression first, not a performance one.
- **Interpreting results:** compare `*_owned` vs `*_unowned` pairs for ownership overhead, and per-suite times to detect regressions in specific propagation strategies (dedup, dirty tracking, batching). Timings are wall-clock milliseconds for 10 000 `run()` invocations (10 reps × 1 000), best-of-10.