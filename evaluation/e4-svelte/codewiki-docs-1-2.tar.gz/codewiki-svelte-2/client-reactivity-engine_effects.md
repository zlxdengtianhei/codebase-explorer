# client-reactivity-engine_effects

## Introduction

The **effects module** (`packages/svelte/src/internal/client/reactivity/effects.js`) is the effect lifecycle engine at the heart of Svelte's client-side reactivity system. While [sources and proxies](client-reactivity-engine_sources-and-proxies.md) hold *state* and [deriveds](client-reactivity-engine_deriveds-and-async.md) compute *values*, **effects are the subscribers of the signal graph** — units of work that re-execute when the reactive state they depend on changes. Everything a Svelte component does at runtime (updating the DOM, running `$effect`, driving transitions, tearing down on unmount) is expressed as an effect.

This module is responsible for:

1. **Effect creation** — a family of factory functions that build the different effect flavors used by compiler output (`$effect`, `$effect.pre`, `$effect.root`, `$inspect`, `$:` statements) and by the DOM renderer (template updates, structural blocks, branches).
2. **Effect tree management** — every effect lives in a doubly linked tree (`parent`/`first`/`last`/`prev`/`next`) that mirrors component structure, enabling scoped teardown and cheap traversal.
3. **Effect lifecycle** — synchronous execution vs. deferred scheduling, teardown execution, destruction with DOM removal, unlinking, and the *pause/resume* protocol that keeps outro transitions alive when a block is removed.

> **Runes ↔ functions:** `$effect` → `user_effect`, `$effect.pre` → `user_pre_effect`, `$effect.root` → `effect_root`, `$effect.tracking` → `effect_tracking`, `$inspect` → `inspect_effect`, `$:` → `legacy_pre_effect`/`legacy_pre_effect_reset`.

---

## Architecture

The module sits between the *scheduler* and the *signal graph*: it creates effects and links them into the tree, but it never flushes them itself. Dirty effects are handed to [batching-scheduling](client-reactivity-engine_batching-scheduling.md), which later calls back into [signal-graph](client-reactivity-engine_signal-graph.md) (`update_effect`) to actually run them.

```mermaid
flowchart TB
    subgraph Compiler["Compiler Pipeline → Language Toolchain"]
        CT["compiler-transformer client transform<br/>emits calls to <i>block</i>, <i>template_effect</i>,<br/><i>render_effect</i>, <i>branch</i>…"]
    end

    subgraph Engine["client-reactivity-engine"]
        SRC["sources-and-proxies<br/>(writes bump write versions)"]
        SG["signal-graph (runtime.js)<br/>update_effect · get · is_dirty ·<br/>set_signal_status · remove_reactions"]
        DER["deriveds-and-async"]
        BS["batching-scheduling<br/>schedule_effect · Batch.ensure"]
        PS["props-and-stores"]
        FND["foundation (flags, equality)"]
        EFF["⭐ effects.js (this module)<br/>create · link · destroy · pause/resume"]
    end

    subgraph DOM["client-dom-renderer"]
        BLOCKS["dom blocks (if, each, await, key,<br/>snippet, svelte-element…)"]
        ATTRS["attributes / bindings"]
        TRANS["transitions (TransitionManager)"]
        RENDER["render.js: mount / hydrate / unmount"]
    end

    LEGACY["legacy-compat<br/>(compiled <code>$:</code> statements)"]

    CT -- "generates effect calls" --> EFF
    LEGACY -- "legacy_pre_effect / _reset" --> EFF
    EFF -- "runs effects via<br/>update_effect / get" --> SG
    EFF -- "schedule_effect /<br/>Batch.ensure" --> BS
    BS -- "flush: update_effect<br/>on dirty effects" --> SG
    SRC -- "write version > effect.wv<br/>⇒ effect becomes dirty" --> SG
    RENDER -- "component_root (root<br/>effect per component)" --> EFF
    BLOCKS -- "block / branch /<br/>pause / resume / destroy" --> EFF
    ATTRS -- "render_effect / template_effect" --> EFF
    TRANS -- "out()/in() during<br/>pause_effect / resume_effect" --> EFF
```

**Key contracts:**

- `create_effect` inherits `INERT` from a paused parent, so new work inside an inert (outroing) subtree is itself inert.
- Effects created inside a *derived* are additionally registered on that derived (`derived.effects`), so destroying the derived destroys them.
- `Batch.ensure()` is required before any synchronous root effect runs (`effect_root`, `component_root`), guaranteeing a commit context exists.

For the runtime primitives this module consumes (`update_effect`, `is_dirty`, `set_signal_status`, dependency tracking), see [client-reactivity-engine_signal-graph](client-reactivity-engine_signal-graph.md).

---

## The Effect data structure

An `Effect` extends the base [`Signal` interface](client-reactivity-engine_signal-graph.md) (`f` = flags bitmask, `wv` = write version) with tree, DOM, and lifecycle state:

```mermaid
classDiagram
    class Signal {
        <<interface>>
        +number f   // type | status flags
        +number wv  // last-seen write version
    }
    class Effect {
        +Function fn          // the work
        +Function teardown    // returned cleanup fn
        +Effect parent
        +Effect first         // children (linked list head/tail)
        +Effect last
        +Effect prev          // siblings
        +Effect next
        +Array deps           // tracked signal dependencies
        +TemplateNode nodes_start  // owned DOM range
        +TemplateNode nodes_end
        +ComponentContext ctx // component context at creation
        +Array transitions    // TransitionManagers
        +AbortController ac   // for async effects
        +number b             // batch reference (boundary/branch)
    }
    Signal <|.. Effect : extends
    Effect "1" --> "0..1" Effect : parent
    Effect "1" --> "0..*" Effect : first / last (children)
    Effect "0..1" --> "0..*" Effect : prev / next (siblings)
```

### Flag vocabulary

The `f` bitmask packs an *effect type* and a *status* (status bits are swapped atomically via `set_signal_status`, which masks with `STATUS_MASK`). The flags that drive this module's behavior:

| Category | Flag | Meaning |
|---|---|---|
| Status | `CLEAN` / `MAYBE_DIRTY` / `DIRTY` | Scheduling states; dirty effects re-run on flush |
| Status | `DESTROYED` | Teardown done; `update_effect` and `aborted` check this |
| Status | `INERT` | Paused subtree (outro in progress) — skips updates |
| Type | `RENDER_EFFECT` | Runs before mutations are committed (template updates, `$effect.pre`) |
| Type | `EFFECT` / `USER_EFFECT` | `$effect`-style, runs after render effects on commit |
| Type | `BLOCK_EFFECT` | Re-runnable structural block body (if/each/await/key…) |
| Type | `BRANCH_EFFECT` + `EFFECT_PRESERVED` | Component/branch container, kept in tree even when empty |
| Type | `ROOT_EFFECT` + `EFFECT_PRESERVED` | Independent tree root (`$effect.root`, component mount) |
| Type | `INSPECT_EFFECT` | `$inspect` (excluded from parenting in DEV) |
| Type | `HEAD_EFFECT` | `<svelte:head>` content — DOM removed even when `remove_dom=false` |
| Type | `ASYNC` + `EFFECT_PRESERVED` | Async work spawned by async deriveds |
| Marker | `EFFECT_TRANSPARENT` | Passes "localness" through during pause/resume traversal |
| Marker | `EFFECT_RAN` | Has executed at least once (drives `$effect` deferral) |

---

## Effect taxonomy

Every public factory funnels through the single private `create_effect(type, fn, sync, push)` primitive:

```mermaid
flowchart TD
    CREATE["create_effect(type, fn, sync, push)"]

    CREATE --> R["render_effect(fn, flags)<br/>RENDER_EFFECT, sync — internal DOM<br/>and attribute updates"]
    CREATE --> TE["template_effect(fn, sync[], async[])<br/>RENDER_EFFECT — compiled template<br/>updates with async dep flattening"]
    CREATE --> B["⭐ block(fn, flags)<br/>BLOCK_EFFECT, sync — structural block body<br/>dev_stack attached in DEV"]
    CREATE --> BR["branch(fn, push)<br/>BRANCH_EFFECT + EFFECT_PRESERVED, sync —<br/>component instance branch"]
    CREATE --> UE["user_effect(fn) / create_user_effect(fn)<br/>EFFECT + USER_EFFECT, deferred — $effect"]
    CREATE --> UP["user_pre_effect(fn)<br/>RENDER_EFFECT + USER_EFFECT, sync — $effect.pre"]
    CREATE --> ROOT["effect_root(fn) / component_root(fn)<br/>ROOT_EFFECT + EFFECT_PRESERVED, sync —<br/>$effect.root · mount/unmount boundary"]
    CREATE --> AE["async_effect(fn)<br/>ASYNC + EFFECT_PRESERVED, sync —<br/>async derived continuation"]
    CREATE --> IE["inspect_effect(fn)<br/>INSPECT_EFFECT, sync — $inspect"]
    CREATE --> TD["teardown(fn)<br/>RENDER_EFFECT, fn = null —<br/>cleanup-only effect"]
    CREATE --> LPE["legacy_pre_effect(deps, fn)<br/>$: statements via render_effect tokens"]
    CREATE --> EF["effect(fn)<br/>EFFECT, deferred — internal bookkeeping"]
```

---

## Component reference

### ⭐ `block(fn, flags = 0)`

Creates a **`BLOCK_EFFECT`** and runs it *synchronously* (`sync = true`). Block effects are the re-runnable bodies that the [client-dom-renderer](client-dom-renderer.md) builds for every structural construct — `{#if}`, `{#each}`, `{#await}`, `{#key}`, `<svelte:element>`, snippets — and are also what the [compiler transformer](compiler-transformer_client-transform.md) emits around those constructs.

Behavioral details:

- **Synchronous first run:** the body executes immediately inside `update_effect`, recording its signal dependencies. If it throws, the half-built effect is destroyed before the error propagates.
- **Selective child reset on re-run:** `update_effect` treats `BLOCK_EFFECT` specially — re-running a block calls `destroy_block_effect_children`, which destroys all non-branch children but **preserves `BRANCH_EFFECT` subtrees**, letting block implementations (e.g. `if.js`) manage branch creation/destruction themselves.
- **DEV metadata:** `effect.dev_stack = dev_stack` is captured so runtime errors inside the block resolve to source locations (`add_locations` / component stacks in [client-dev-tooling](client-dev-tooling.md)).
- **Tree pruning:** because it is sync, the "skip trivial wrapper" optimization in `create_effect` may bypass the block node itself (linking its single child directly) when it has no deps, teardown, DOM nodes, or multiple children, and is not `EFFECT_PRESERVED`.

### ⭐ `legacy_pre_effect(deps, fn)`

Emulates the **initialization ordering of Svelte 4 `$:` reactive statements** for compiled legacy components (see [legacy-compat](legacy-compat.md)). It does not run `fn` eagerly; instead it registers a *token* `{ effect, ran, deps }` in `component_context.l.$` and creates a render effect that:

1. Calls `deps()` — subscribing the effect to the statement's reactive dependencies;
2. Runs `untrack(fn)` — the statement body executes *untracked*, so reads inside it don't create new dependencies — **but only if it has not run before** (`token.ran` guard).

### ⭐ `legacy_pre_effect_reset()`

Creates a companion render effect that closes the loop after component initialization:

1. For every registered token, re-evaluates `deps()`;
2. Flips effects still in `CLEAN` status to `MAYBE_DIRTY`, forcing `is_dirty` to walk their dependency edges and compare write versions;
3. Re-runs any effect that `is_dirty` reports as changed, then clears `token.ran` so future changes flow through the normal dirty path.

Together the two functions reproduce the legacy guarantee that *all* `$:` dependency expressions are evaluated before *any* statement body runs during init, while bodies still re-run on later changes.

### Other lifecycle primitives

| Function | Role |
|---|---|
| `create_effect(type, fn, sync, push)` | Core factory: inherits `INERT`, runs sync or schedules, links into parent tree, registers on active derived, applies tree-pruning |
| `validate_effect(rune)` | DEV guards: throws `effect_orphan` / `effect_in_unowned_derived` / `effect_in_teardown` (errors live in [client-dev-tooling](client-dev-tooling.md)) |
| `user_effect(fn)` | `$effect` — deferred until mount when top-level in an unmounted component (`context.e` queue), else `create_user_effect` |
| `user_pre_effect(fn)` / `inspect_effect(fn)` | `$effect.pre` / `$inspect` — both run synchronously at creation |
| `effect_root(fn)` / `component_root(fn)` | Independent roots; `component_root` returns an unmount function that supports `outro` (runs `pause_effect` before destroy) — used by `mount`/`hydrate`/`unmount` in [client-dom-renderer](client-dom-renderer.md) |
| `render_effect(fn, flags)` / `template_effect(fn, sync, async)` | Template machinery; `template_effect` uses [`flatten` from deriveds-and-async](client-reactivity-engine_deriveds-and-async.md) to await async deps before invoking `fn(...values)` |
| `effect_tracking()` | `$effect.tracking()` — true when an active reaction exists and we're not `untracking` |
| `push_effect` | Doubly-linked-list insertion at the tail of `parent_effect`'s children |

---

## Creation & scheduling flow

```mermaid
sequenceDiagram
    autonumber
    participant C as Caller<br/>(compiler output / DOM block)
    participant E as effects.js
    participant R as signal-graph<br/>(runtime.js)
    participant B as batching-scheduling<br/>(batch.js)

    C->>E: block(fn) / user_effect(fn) / render_effect(fn)
    E->>E: validate_effect (DEV orphan/teardown guards)
    E->>E: create_effect: build node,<br/>inherit INERT from parent
    alt sync = true (block, render_effect, effect.pre…)
        E->>R: update_effect(effect)
        R->>R: destroy children → teardown → run fn →<br/>record deps via get()
        E->>E: mark EFFECT_RAN
    else sync = false ($effect, internal effect)
        E->>B: schedule_effect(effect)
    end
    E->>E: push_effect → link into parent's list<br/>(skip trivial wrapper if eligible)
    Note over B: on flush: Batch.process(root_effects)<br/>traverses tree, defers/commits
    B->>R: update_effect for each dirty effect
    R-->>E: teardown captured for next run
```

---

## Lifecycle state model

```mermaid
stateDiagram-v2
    [*] --> Created: create_effect
    Created --> Running: sync run (update_effect)
    Created --> Scheduled: schedule_effect
    Scheduled --> Running: batch flush
    Running --> Clean: fn executed, deps recorded
    Clean --> Dirty: dependency write version > effect.wv
    Dirty --> Running: next flush
    Running --> Inert: parent block paused (pause_effect)
    Inert --> Running: state reverses (resume_effect)
    Inert --> Destroyed: outro completes → destroy_effect
    Clean --> Destroyed: destroy_effect
    Destroyed --> [*]
```

---

## Destruction

`destroy_effect(effect, remove_dom = true)` implements the full teardown protocol:

```mermaid
flowchart TD
    A["destroy_effect(effect, remove_dom)"] --> B{"remove_dom or HEAD_EFFECT,<br/>and owns DOM nodes?"}
    B -- yes --> C["remove_effect_dom:<br/>walk siblings via get_next_sibling,<br/>remove each node until nodes_end"]
    B -- no --> D
    C --> D["destroy_effect_children<br/>(abort async controllers, recurse;<br/>ROOT_EFFECT children are orphaned,<br/>not destroyed)"]
    D --> E["remove_reactions:<br/>unlink effect from all dependency<br/>reaction lists (signal-graph)"]
    E --> F["set_signal_status → DESTROYED"]
    F --> G["stop all owned transitions"]
    G --> H["execute_effect_teardown:<br/>run effect.teardown with<br/>is_destroying_effect = true,<br/>active_reaction = null"]
    H --> I{"parent has other children?"}
    I -- yes --> J["unlink_effect:<br/>stitch prev/next and parent<br/>first/last pointers"]
    I -- no --> K
    J --> K["null out fn, deps, teardown,<br/>DOM refs, ctx (parent kept for<br/>error propagation)"]
```

Notes:

- `destroy_effect_children(signal, remove_dom)` resets `first`/`last` before iterating, so re-entrant destruction is safe; async effects get their `AbortController` aborted with `STALE_REACTION` inside `without_reactive_context`.
- `destroy_block_effect_children` is the `BLOCK_EFFECT`-specific variant that spares `BRANCH_EFFECT` children (used by `update_effect` on re-run).
- `unlink_effect` frees the node from the tree so later traversals ([batching-scheduling](client-reactivity-engine_batching-scheduling.md)) skip it entirely.
- `aborted(effect)` answers "was I destroyed?" — used by async continuations ([deriveds-and-async](client-reactivity-engine_deriveds-and-async.md)) to bail out.

---

## Pause / resume (outro transitions)

When a block is removed, its DOM may not disappear instantly: outro transitions must play first. The module implements a *pause* protocol that keeps the subtree alive but inert, and a *resume* protocol that revives it if the state change is reversed (e.g. `{#if x}` toggles false → true before the outro ends):

```mermaid
flowchart TD
    A["Block removed<br/>(e.g. {#if x} branch dropped)"] --> B{"outro transitions<br/>to play?"}
    B -- "no" --> D["destroy_effect<br/>(see destruction flow)"]
    B -- "yes" --> P["pause_effect: pause_children"]
    P --> P1["flip INERT on each effect<br/>(skip already-inert subtrees)"]
    P1 --> P2["collect TransitionManagers —<br/>global transitions always,<br/>local ones only while local<br/>(EFFECT_TRANSPARENT / BRANCH pass localness)"]
    P2 --> O["run_out_transitions:<br/>count-down remaining;<br/>when zero → destroy_effect + callback"]
    P -. "state flips back first" .-> R["resume_effect: resume_children"]
    R --> R1["clear INERT recursively"]
    R1 --> R2{"effect is not CLEAN?"}
    R2 -- yes --> R3["set DIRTY + schedule_effect<br/>(catch up on writes that<br/>happened while paused)"]
    R2 -- no --> R4
    R3 --> R4["play in() transitions<br/>(same global/local rules)"]
```

Key subtleties:

- `pause_children` uses `EFFECT_TRANSPARENT` and `BRANCH_EFFECT` to decide whether `local` propagates downward — this mirrors the scoping rules of `|local` transitions.
- `resume_children` deliberately does **not** use `is_dirty` to catch up: it sets `DIRTY` and defers to the scheduler, avoiding eager recomputation of deriveds like `{#if foo}{foo.bar()}{/if}` when `foo` has become `undefined`.
- `component_root`'s returned unmount function uses `pause_effect` when called with `{ outro: true }`, giving `unmount` (in [client-dom-renderer](client-dom-renderer.md)) its awaited-outro behavior.

---

## Interaction with the wider system

| Partner module | Interaction |
|---|---|
| [client-reactivity-engine_signal-graph](client-reactivity-engine_signal-graph.md) | `update_effect` (run), `is_dirty` (status checks), `set_signal_status`, `remove_reactions`, `get` (dependency capture), global `active_effect`/`active_reaction` |
| [client-reactivity-engine_batching-scheduling](client-reactivity-engine_batching-scheduling.md) | `schedule_effect` (deferred creation), `Batch.ensure()` (root contexts), flush-time state transitions |
| [client-reactivity-engine_sources-and-proxies](client-reactivity-engine_sources-and-proxies.md) | Writes bump write versions; effects compare `dep.wv > effect.wv` to detect dirtiness |
| [client-reactivity-engine_deriveds-and-async](client-reactivity-engine_deriveds-and-async.md) | `template_effect` flattens async deps; effects created under a derived are registered for derived-scoped teardown; `ASYNC` effects |
| [client-dom-renderer](client-dom-renderer.md) | Blocks (`if`, `each`, `await`, `key`, `element`…) are `block`/`branch` consumers; `render.js` owns `component_root`; transitions provide `TransitionManager.in/out/stop`; bindings use `render_effect` |
| [compiler-transformer_client-transform](compiler-transformer_client-transform.md) | Emits calls to `block`, `template_effect`, `render_effect`, `branch`, `teardown`, `effect_root` into compiled components |
| [client-dev-tooling](client-dev-tooling.md) | `validate_effect` errors, `dev_stack` on block effects, `INSPECT_EFFECT` parenting exemption, `component_function` capture |
| [legacy-compat](legacy-compat.md) | `legacy_pre_effect` / `legacy_pre_effect_reset` implement `$:` semantics; `validate_effect` allows effects inside legacy lifecycles |

---

## Design notes & invariants

1. **One primitive, many flavors.** All effect kinds share `create_effect`; behavior differences are encoded purely in the `f` bitmask. Adding a new effect kind is a flags change, not a new object shape.
2. **Sync effects own their failures.** A synchronous effect that throws during creation is destroyed before the error escapes, leaving no half-linked tree nodes behind.
3. **The tree is the component tree.** Parent/child links enable scoped destruction (unmount a component = destroy its root's subtree) and lets the batch scheduler traverse exactly the affected region.
4. **Pausing ≠ destroying.** Outros require the DOM and effect graph to stay alive; `INERT` + rescheduling-on-resume gives correct semantics both for completed outros and reversed state changes.
5. **Legacy fidelity is localized.** All `$:`-ordering emulation is confined to the token mechanism of `legacy_pre_effect`/`legacy_pre_effect_reset`, keeping runes-mode effects free of legacy branching.
