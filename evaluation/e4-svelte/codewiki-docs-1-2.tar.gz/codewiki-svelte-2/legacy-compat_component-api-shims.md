# Component API Shims (`legacy-compat_component-api-shims`)

## 1. Introduction & Purpose

This module is the **public-facing half of the legacy compatibility layer** (see [legacy-compat](legacy-compat.md)). It exposes the `svelte/legacy` entry point — `createClassComponent`, `asClassComponent`, `run`, `handlers`, `createBubbler`, and the event-modifier re-exports — which lets **unmodified Svelte 4-style consumer code** (imperative `new Component(...)`, `comp.$set()`, `comp.$on()`, `comp.$destroy()`, `Comp.render()`, multi-listener handlers, and `on:event` bubbling) drive **Svelte 5 function components** without recompiling the caller.

The module exists in two condition-specific entry points:

| File | Package condition | Role |
|---|---|---|
| `packages/svelte/src/legacy/legacy-client.js` | browser/client | The real machinery: the internal `Svelte4Component` bridge class plus `run`, `handlers`, `createBubbler`, and event-modifier re-exports |
| `packages/svelte/src/legacy/legacy-server.js` | node/SSR | Delegates the class API to the client file, adds the Svelte 4 static `.render()` on top of the SSR `render()`, and provides `noop` stand-ins for everything event-related |

The split is deliberate (per the source comment): *"By having this as a separate entry point for server environments, we save the client bundle from having to include the server runtime."*

> **Every export in this module is explicitly `@deprecated`.** These are temporary migration aids; the compiler migrator ([compiler-migrator](compiler-migrator.md), `svelte migrate`) rewrites source code away from them. New code should use `mount()`, props, callback props, and snippets.

**In one sentence:** the module *translates* Svelte 4's imperative class-component contract onto the Svelte 5 runtime (signal graph + `mount`/`hydrate`/`unmount`), and *erases* itself on the server by mapping everything to a single synchronous `render()` call.

---

## 2. Source Layout & Exports

### 2.1 `legacy-client.js`

| Export | Signature (simplified) | Purpose |
|---|---|---|
| `createClassComponent(options)` | `(ComponentConstructorOptions & {component}) => Svelte4 instance` | Instantiates a Svelte 5 component through a Svelte 4-style constructor call |
| `asClassComponent(component)` | `(SvelteComponent \| Component) => class` | Returns a Svelte 4-compatible **constructor** for a Svelte 5 component function |
| `Svelte4Component` *(internal)* | `class` | The actual bridge; emulates `$set` / `$on` / `$destroy` / instance exports |
| `run(fn)` | `(() => void \| (() => void)) => void` | Svelte 4 `$:` reactive statement semantics on top of `$effect.pre` |
| `handlers(...h)` | `(...EventListener) => EventListener` | Combines multiple listeners into one, with `stopImmediatePropagation` short-circuit and async error rethrow |
| `createBubbler()` | `() => (type) => (event) => boolean` | Creates a `send(...)`-style bubbler mimicking Svelte 4 handler-less `on:click` forwarding |
| `once, preventDefault, self, stopImmediatePropagation, stopPropagation, trusted, passive, nonpassive` | re-exports | Event-modifier substitutes — documented in [legacy-compat_legacy-events-and-props](legacy-compat_legacy-events-and-props.md) |

### 2.2 `legacy-server.js`

| Export | Client counterpart | Server behaviour |
|---|---|---|
| `createClassComponent` | `new Svelte4Component(options)` | **Re-export** of the client implementation |
| `asClassComponent(component)` | `class extends Svelte4Component` | Wraps the client constructor and attaches the static `Component.render()` (legacy `{ html, head, css }` shape) |
| `run(fn)` | `user_pre_effect` + `MAYBE_DIRTY` downgrade | Just `fn()` — run once, no reactivity on the server |
| `handlers`, `createBubbler`, `once`, `preventDefault`, `self`, `stopImmediatePropagation`, `stopPropagation`, `trusted`, `passive`, `nonpassive` | real implementations | All mapped to a single `noop` — *"event stuff, no need to worry about it for SSR but needs to be there or it will crash"* |

---

## 3. Architecture Overview

```mermaid
flowchart TB
    subgraph Consumers["Consumer code (Svelte 4 style, unmodified)"]
        APP["new Comp() · comp.$set() · comp.$on()<br/>comp.$destroy() · handlers(...) · send('click')<br/>Comp.render() (SSR)"]
    end

    subgraph Shims["component-api-shims (this module)"]
        direction LR
        LC["legacy-client.js<br/>Svelte4Component · createClassComponent · asClassComponent<br/>run · handlers · createBubbler"]
        LSRV["legacy-server.js (server condition)<br/>asClassComponent + static .render()<br/>run = fn() · noop event shims"]
    end

    subgraph Engine["Client Runtime Engine"]
        SIG["signal graph<br/>mutable_source · set · get<br/>(client-reactivity-engine_signal-graph)"]
        EFF["effects<br/>user_pre_effect · set_signal_status<br/>(client-reactivity-engine_effects)"]
        BAT["batching<br/>flushSync<br/>(client-reactivity-engine_batching-scheduling)"]
        RND["render lifecycle<br/>mount · hydrate · unmount<br/>(client-dom-renderer_lifecycle)"]
        CTX["component context<br/>component_context · dev_current_component_function"]
        FLAGS["foundation<br/>async_mode_flag · DEV · DIRTY/MAYBE_DIRTY/LEGACY_PROPS<br/>(client-reactivity-engine_foundation)"]
    end

    SSR["Server Runtime<br/>render()<br/>(server-runtime)"]
    MODS["event modifiers<br/>(legacy-compat_legacy-events-and-props)"]

    APP --> LC & LSRV
    LSRV -->|"re-exports createClassComponent,<br/>wraps asClassComponent"| LC
    LSRV -->|"render(component, {props, context})"| SSR
    LC --> RND & BAT & CTX & FLAGS
    LC --> SIG & EFF
    LC -.->|"pure re-exports"| MODS

    style Shims fill:#fdf6e3,stroke:#b7791f
    style Engine fill:#e9f7ef,stroke:#276749
    style SSR fill:#e8f4fd,stroke:#2b6cb0
```

### Design principles

- **Translation, not reimplementation.** The shims never re-implement Svelte 4's runtime; they *re-shape the API surface*: `$set` becomes `Object.assign` onto a proxy whose traps write to per-key signals; `$destroy` becomes `unmount()`; `$:` becomes a `$effect.pre` with a compatibility tweak.
- **Coarse-grained on purpose.** `Svelte4Component` deliberately builds a props proxy with **one `mutable_source` per property key** instead of using the fine-grained `$state` proxy — compiled legacy components expect "the props object changed" semantics (see [client-reactivity-engine_props-and-stores](client-reactivity-engine_props-and-stores.md) and [legacy-compat_legacy-lifecycle](legacy-compat_legacy-lifecycle.md)).
- **Single event channel.** Both `$on` and `createBubbler` funnel through the same `$$props.$$events` delegation store that modern event handling uses, so bubbling behaves identically in both paradigms.
- **Server = degenerate client.** On the server, reactivity, effects, batching, and events are meaningless; the server entry keeps the *same API names* so shared component code runs, but replaces everything with one synchronous call or a `noop`.

---

## 4. Core Component Deep-Dives

### 4.1 `Svelte4Component` — the bridge class

The internal class behind both public factory functions. Its private state:

- `#events` — the `$$events` record captured from the props proxy (the delegation channel).
- `#instance` — the **exports object** returned by `mount()`/`hydrate()`.

**Constructor pipeline:**

1. **Source map setup.** `sources = new Map()`; `add_source(key, value)` creates `mutable_source(value, false, false)`. The two `false`s matter:
   - `immutable = false` → the source uses `safe_equals` (loose equality, matching Svelte 4 dirty-checking);
   - `trackable = false` → the source is **not** registered into `component_context.l.s`, i.e. the shim's own coarse-grained channel is independent of the compiled `beforeUpdate`/`afterUpdate` observation set built by `init()` (see [legacy-compat_legacy-lifecycle](legacy-compat_legacy-lifecycle.md)).
2. **Props proxy.** Wraps `{ ...(options.props ?? {}), $$events: {} }` with three traps:
   - `get` — reads through the per-key source (`get(source)`), lazily creating it, so reads register reactive dependencies;
   - `has` — returns `true` for the internal `LEGACY_PROPS` symbol (a `Symbol('legacy props')` marker) so the component side does **not** reject the proxy as an "invalid binding" target; otherwise registers the dependency and defers to `Reflect.has`;
   - `set` — writes through `set(source, value)` **and** the target, producing fine-grained downstream updates on `$set`.
3. **Mount delegation.** `(options.hydrate ? hydrate : mount)(options.component, { target, anchor, props, context, intro: options.intro ?? false, recover })` — see [client-dom-renderer_lifecycle](client-dom-renderer_lifecycle.md).
4. **Synchronous flush (conditional).** `flushSync()` is skipped when:
   - `async_mode_flag` is on (`flushSync()` fails in async mode),
   - the component is a **custom-element wrapper** (`options.props.$$host` present), or
   - the caller passed `sync: false`.
5. **Event capture + export forwarding.** `#events = props.$$events`; every export key on `#instance` (except `$set`/`$on`/`$destroy`) becomes an enumerable **accessor property** on the wrapper via `define_property`, so `component.someExport()` keeps working unchanged.
6. **Method installation.** `#instance.$set = (next) => Object.assign(props, next)` (flows through the proxy `set` traps) and `#instance.$destroy = () => unmount(#instance)`.

Public methods `$set`, `$on`, `$destroy` delegate to the installed instance methods; `$on` wraps each callback so its `this` is the wrapper and returns an unsubscribe function that filters the callback back out of `#events[event]`.

```mermaid
sequenceDiagram
    autonumber
    participant App as Svelte 4-style caller
    participant W as Svelte4Component wrapper
    participant P as props Proxy (per-key mutable_sources)
    participant R as render.js (mount / hydrate)
    participant C as Svelte 5 component function

    App->>W: new (via createClassComponent / asClassComponent)
    W->>P: create Proxy({props, $$events:{}}) with get/has/set traps
    Note over P: get & has lazily add_source(key) →<br/>mutable_source(value, false, false)
    W->>R: (options.hydrate ? hydrate : mount)(component,<br/>{target, anchor, props, context, intro, recover})
    R->>C: invoke component fn with the props proxy
    C-->>R: exports object
    R-->>W: instance (exports)
    W->>W: #events = props.$$events
    W->>W: defineProperty accessors for every export<br/>(skip $set/$on/$destroy)
    W->>W: install $set = Object.assign(props, ·), $destroy = unmount
    W->>R: flushSync() unless async-mode / $$host / sync === false
    W-->>App: Svelte 4-compatible instance
```

### 4.2 `createClassComponent` and `asClassComponent`

- **`createClassComponent(options)`** is a one-liner: `new Svelte4Component(options)`. `options` accepts Svelte 4 `ComponentConstructorOptions` (`target`, `anchor`, `props`, `context`, `hydrate`, `intro`, `recover`, plus the shim-specific `sync`) and the `component` to instantiate.
- **`asClassComponent(component)`** returns `class extends Svelte4Component` whose constructor calls `super({ component, ...options })`. This gives callers a genuine constructor they can `new`, `extend`, or attach statics to — the typical target of `export default class App extends SvelteComponent`-style code. The `LegacyComponentType` typedef makes the result usable as **both a class and a function** during the transition period.

The server variant of `asClassComponent` is layered on top of the client one and additionally attaches the legacy **static `.render()`** — see §4.6.

### 4.3 `run(fn)` — reactive-statement emulation

Svelte 4's `$:` statements could re-trigger themselves recursively (a statement writing a value it also reads). Svelte 5 marks synchronous self-re-dirtying effects as errors. `run` restores the old behaviour with a deliberate deviation from `$effect.pre`:

```mermaid
flowchart TD
    R0["run(fn) called"] --> CL{"which entry?"}
    CL -->|"client"| C1["user_pre_effect(() => { fn(); … })<br/>(client-reactivity-engine_effects)"]
    C1 --> C2{"effect re-dirtied synchronously?<br/>(effect.f & DIRTY)"}
    C2 -- "no" --> C3["done — behaves like $effect.pre"]
    C2 -- "yes" --> C4["DEV: warn legacy_recursive_reactive_block(filename)<br/>filename from dev_current_component_function[FILENAME]<br/>or \"a file (we can't know which one)\""]
    C4 --> C5["set_signal_status(effect, MAYBE_DIRTY)<br/>emulates Svelte 4 recursive self-invalidation"]
    CL -->|"server"| S1["fn() — called exactly once, no reactivity"]
    style C5 fill:#fff3cd,stroke:#b7791f
```

On the client the effect is created via `user_pre_effect` (a `RENDER_EFFECT | USER_EFFECT`), and `active_effect` / `set_signal_status` come from the runtime's signal machinery ([client-reactivity-engine_signal-graph](client-reactivity-engine_signal-graph.md)). On the server `run` is simply `fn()`, mirroring how SSR evaluates top-level statements once.

### 4.4 `handlers(...)` — multi-listener composition

Svelte 4 allowed multiple listeners per `on:` directive (`on:click={a} on:click={b}`). `handlers` returns a single `EventListener` that composes any number of handlers:

1. **Intercepts `stopImmediatePropagation`** on the event object, wrapping it so the chain knows when to stop (the original method still runs, so native behaviour is preserved).
2. Invokes each handler with the **original `this`**.
3. **Never lets one broken handler break the chain**: thrown errors are collected and re-thrown asynchronously via `queueMicrotask(() => { throw error })` — matching Svelte 4's event semantics where a failing listener didn't prevent later listeners (the error surfaces as an uncaught exception afterwards).

```mermaid
flowchart TD
    A["handlers(h1, h2, h3)(event)"] --> B["wrap event.stopImmediatePropagation<br/>→ sets stopped flag + calls original"]
    B --> C["invoke h1.call(this, event)"]
    C --> D{"threw?"}
    D -- "yes" --> E["collect error, continue"]
    D -- "no" --> F{"stopImmediatePropagation called?"}
    E --> F
    F -- "no" --> G["next handler…"]
    F -- "yes" --> H["stop chain"]
    G --> H
    H --> I["for each collected error:<br/>queueMicrotask(() => throw error)"]
    style I fill:#fdecea,stroke:#c53030
```

### 4.5 `createBubbler()` — handler-less `on:event` forwarding

Svelte 4 forwarded an event to the parent when `on:click` had **no handler**. `createBubbler()` produces that behaviour manually:

```mermaid
sequenceDiagram
    autonumber
    participant App as consumer
    participant B as createBubbler() / send(type)
    participant Ctx as component_context
    participant EV as props.$$events delegation store

    App->>B: const send = createBubbler()
    B->>Ctx: capture active component_context
    Note over B,Ctx: throws lifecycle_outside_component('createBubbler')<br/>if called outside component initialisation
    App->>App: on:click={send('click')} — B returns (event) => …
    App->>B: event fires
    B->>EV: look up $$events['click']
    alt handlers present
        B->>B: invoke each callback with component context as this
        B-->>App: !event.defaultPrevented
    else no handlers
        B-->>App: true
    end
```

It reads the **same** `$$events` store that `$on` writes to and that the delegated DOM listener dispatches into (see [legacy-compat_legacy-events-and-props](legacy-compat_legacy-events-and-props.md) for `bubble_event` and the root-level listener). Because SSR never dispatches events, the server build substitutes `noop`.

### 4.6 Server entry (`legacy-server.js`)

```mermaid
flowchart LR
    subgraph LS["legacy-server.js"]
        A["asClassComponent(component)"] --> B["client asClassComponent:<br/>class extends Svelte4Component"]
        A --> C["attach static .render(props, {context})"]
    end
    C --> D["server render(component, {props, context})<br/>(server-runtime)"]
    D --> E["result: { head, html/body }"]
    C --> F["legacy shape returned:<br/>{ html: result.body, head,<br/>css: { code: '', map: null } }"]
    RE["createClassComponent"] -.->|"re-export"| B
    NOOPS["handlers · createBubbler · once ·<br/>preventDefault · self · stopImmediatePropagation ·<br/>stopPropagation · trusted · passive · nonpassive"] --> NOOP["noop"]
```

Notable details:

- **CSS is faked.** `.render()` always returns `css: { code: '', map: null }` — Svelte 5 no longer extracts CSS at SSR runtime; styles are emitted into `head`.
- **Field mapping.** The legacy `html` field is fed from the modern `result.body`; `head` passes through unchanged.
- **`run` degrades to a plain call.** `fn()` runs once; there is no effect scheduling server-side.
- **`noop` as structural filler.** Every event-related export is aliased to `noop` so that shared component code that references `on:click|preventDefault`-style transformed output or `send(...)` calls does not crash during SSR.

---

## 5. Runtime Data Flows

### 5.1 `$set` / `$on` / `$destroy` after instantiation

```mermaid
flowchart TD
    A["caller: comp.$set({ count: 2 })"] --> B["Object.assign(props, next)<br/>(installed on #instance)"]
    B --> C{"proxy set trap, per key"}
    C --> D["set(source, value)<br/>signal graph write<br/>(client-reactivity-engine_signal-graph)"]
    D --> E["fine-grained downstream updates —<br/>only reactions that read that key re-run"]
    F["caller: comp.$on('click', cb)"] --> G["push wrapped cb (this = wrapper)<br/>into #events['click']<br/>returns unsubscribe()"]
    H["caller: comp.$destroy()"] --> I["unmount(#instance)<br/>(client-dom-renderer_lifecycle)"]
```

### 5.2 Dual-entry resolution

```mermaid
flowchart LR
    IMP["import { asClassComponent } from 'svelte/legacy'"] --> RES{"package export<br/>condition"}
    RES -- "browser / client" --> CL["legacy-client.js<br/>full client implementation"]
    RES -- "node / SSR" --> SV["legacy-server.js<br/>delegates class API → legacy-client.js<br/>adds .render() · run = fn() · noop events"]
    SV --> CL
    CL --> ENG["Client Runtime Engine"]
    SV --> SSRM["Server Runtime render()"]
```

This is why server bundles never pull the DOM renderer and client bundles never pull the SSR runtime, even though the public import specifier is identical.

---

## 6. Error & Warning Contracts

| Condition | Behaviour | Source |
|---|---|---|
| `createBubbler()` called outside component initialisation (`component_context === null`) | Throws `lifecycle_outside_component('createBubbler')` | `internal/client/errors.js` (see [client-dev-tooling_message-catalog](client-dev-tooling_message-catalog.md)) |
| `run()` effect re-dirtied synchronously (client, DEV) | Warns `legacy_recursive_reactive_block(filename)`; filename from `dev_current_component_function[FILENAME]`, else `"a file (we can't know which one)"` | `internal/client/warnings.js` |
| `run()` effect re-dirtied synchronously (client, prod) | Silently downgrades effect status to `MAYBE_DIRTY` (keeps legacy recursion working) | `set_signal_status` |
| A handler passed to `handlers()` throws | Error collected; chain continues; error re-thrown in a microtask | `queueMicrotask` |
| Props proxy probed with the `LEGACY_PROPS` symbol | `has` returns `true` — prevents "invalid binding" validation errors on the component side | `Symbol('legacy props')` |

---

## 7. Integration with the Rest of the System

| Direction | Interaction | See |
|---|---|---|
| ← **Client Runtime Engine** | Consumes `mount`/`hydrate`/`unmount` (DOM lifecycle), `mutable_source`/`set`/`get` (signal graph), `user_pre_effect` (effects), `flushSync` (batching), `component_context` (context stack), `async_mode_flag`/`DEV`/signal flags (`DIRTY`, `MAYBE_DIRTY`, `LEGACY_PROPS`) | [client-reactivity-engine](client-reactivity-engine.md), [client-dom-renderer_lifecycle](client-dom-renderer_lifecycle.md), [client-reactivity-engine_foundation](client-reactivity-engine_foundation.md) |
| ↔ **Sibling: legacy lifecycle** | The coarse-grained props proxy created here is what compiled legacy components read through; `init()`/`invalidate_inner_signals` (legacy lifecycle module) observe the component's own signals, not the shim's untracked sources | [legacy-compat_legacy-lifecycle](legacy-compat_legacy-lifecycle.md) |
| ↔ **Sibling: legacy events & props** | Re-exports all eight event modifiers verbatim; shares the `$$events` delegation store with `bubble_event`/`add_legacy_event_listener` | [legacy-compat_legacy-events-and-props](legacy-compat_legacy-events-and-props.md) |
| ← **Server-Side Rendering module** | `legacy-server.asClassComponent` attaches `.render()` implemented with the server `render()` | [server-runtime](server-runtime.md) |
| ↔ **Compiler Pipeline & migrator** | Everything here is `@deprecated`; `svelte migrate` rewrites class components, `$:`, `on:` forwarding, and event modifiers so consumers can drop these shims. `handlers`/modifiers exist because the *compiler* of Svelte 4 emitted multi-listener / modifier chains that migrated output still references | [Compiler_Pipeline___Language_Toolchain](Compiler_Pipeline___Language_Toolchain.md), [compiler-migrator](compiler-migrator.md) |
| ← **Dev tooling message catalog** | `lifecycle_outside_component` (error), `legacy_recursive_reactive_block` (warning) | [client-dev-tooling_message-catalog](client-dev-tooling_message-catalog.md) |

---

## 8. Deprecation & Migration Notes

- Every export is framed by upstream docs as a **temporary migration aid**; none should be used in new code.
- `run()` deviates from `$effect.pre` **on purpose** (`MAYBE_DIRTY` downgrade + DEV warning) — do not "fix" this to throw; it would break migrated `$:` blocks that legitimately self-invalidate.
- `handlers()` rethrows collected errors in microtasks intentionally; surfacing them synchronously would change which handler "wins" in console/telemetry.
- The `$$host` check in the `flushSync()` guard exists because **custom element wrappers** manage their own flush timing.
- The props proxy is **not** the `$state` proxy: it has per-key version sources and a `LEGACY_PROPS` marker. Passing arbitrary objects through it expects coarse-grained semantics.
- `.render()` on the server returns **empty CSS** by design — runtime CSS extraction no longer exists in Svelte 5.
- `asClassComponent`-produced classes support the `LegacyComponentType` dual class/function calling convention; drop the dual usage when migrating.

## 9. Quick Reference

| Svelte 4 idiom | Shim used (client) | Server path | Svelte 5 replacement |
|---|---|---|---|
| `new Component({ target, props })` | `createClassComponent` → `Svelte4Component` | re-export of client impl | `mount()` |
| `class App extends Component` / `export default class` | `asClassComponent` | client impl + static `.render()` | plain function components |
| `comp.$set(props)` | props-proxy `Object.assign` → per-key `set()` | n/a (no DOM) | assignable props |
| `comp.$on(ev, cb)` / unsub | `#events[ev]` push / filter | `noop` | callback props |
| `comp.$destroy()` | `unmount()` | n/a | `unmount()` |
| `$: statement` (incl. self-recursive) | `run` via `user_pre_effect` + `MAYBE_DIRTY` | `fn()` once | `$derived` / `$effect` |
| `on:click={a} on:click={b}` | `handlers(a, b)` | `noop` | one handler calling both |
| `on:click` without handler (forwarding) | `createBubbler()` | `noop` | `onclick={...}` callback prop |
| `on:click\|preventDefault\|once\|passive…` | modifier re-exports | `noop` | inline handler logic / attachments |
| `Component.render(props)` (SSR) | — | server `asClassComponent(...).render()` | server `render()` |
