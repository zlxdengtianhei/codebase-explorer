# compiler-core_compile_state

> **Module path:** `packages/svelte/src/compiler/state.js`
> **Core components:** `push_ignore`, `pop_ignore`
> **Parent module:** [compiler-core](compiler-core.md) · **Sibling modules:** [compiler-core_public_api](compiler-core_public_api.md), [compiler-core_diagnostics](compiler-core_diagnostics.md)

## 1. Introduction

`compiler-core_compile_state` implements the **compiler-wide mutable state singleton** for the Svelte compiler. Because a single compilation is a *synchronous, single-threaded* operation that flows through parsing → analysis → transformation, the compiler avoids threading a large context object through every function signature. Instead, `state.js` exposes module-level variables (the current `source`, `filename`, `dev`/`runes` flags, the source `locator`, collected `warnings`, and the `svelte-ignore` bookkeeping structures) together with the lifecycle functions that initialize and mutate them.

The two core components documented here, **`push_ignore`** and **`pop_ignore`**, manage a stack of warning-suppression scopes. They are populated by the parser whenever a `<!-- svelte-ignore code1, code2 -->` comment is encountered, and are the mechanism that makes warning suppression *scope-aware*: a warning code pushed inside a block is no longer active once that block is left.

## 2. Module Surface

The file exports one cohesive state namespace. `push_ignore`/`pop_ignore` are the core components; the remaining exports are consumed by sibling modules and documented here for completeness of the data-flow picture.

### 2.1 Lifecycle functions

| Export | Called by | Purpose |
|---|---|---|
| `reset(state)` | `compile()` / `compileModule()` ([compiler-core_public_api](compiler-core_public_api.md)) | Wipes all state before each compilation; installs `warningFilter` and `filename`; normalizes Windows path separators. |
| `set_source(value)` | `parse()` ([compiler-parser](compiler-parser.md)) | Stores the raw source text and rebuilds the `locate-character` locator used for line/column resolution. |
| `adjust(state)` | `analyze_component()` ([compiler-analyzer](compiler-analyzer.md)) | Runs *after* parsing: sets `dev`, `runes`, final `component_name`; relativizes `filename` against `rootDir`; clears the ignore stack/map (parse-time ignores no longer apply). |
| `push_ignore(ignores)` | Parser comment handling | Pushes a new `Set<string>` of warning codes that accumulates the parent scope's codes. |
| `pop_ignore()` | Parser comment handling | Pops the innermost ignore scope when the associated node/block closes. |
| `is_ignored(node, code)` | Client transform visitors ([compiler-transformer](compiler-transformer.md)) | Returns `true` only in `dev` mode when `code` is registered for `node` in `ignore_map` — used to suppress *runtime* warnings. |
| `locate_node(node)` | Diagnostics / dev-mode output | Renders `"filename:line:column"` for a node using the current locator. |

### 2.2 State variables

| Export | Type | Role |
|---|---|---|
| `warnings` | `Warning[]` | Accumulated compile warnings; filtered per-emission by `warning_filter` before being appended by the diagnostics layer. |
| `warning_filter` | `(warning) => boolean` | User-supplied `CompileOptions.warningFilter`, installed by `reset`. |
| `source` | `string` | The original source text; feeds code frames via `get_code_frame` in [compiler-core_diagnostics](compiler-core_diagnostics.md). |
| `locator` | `Locator` | `locate-character` locator; maps character offsets → `{ line, column }`. |
| `filename` / `UNKNOWN_FILENAME` | `string` | Normalized (forward-slash) filename, optionally relativized to `rootDir`; `'(unknown)'` fallback. |
| `component_name` | `string` | Name used for the generated `export default function ...` statement. |
| `dev` / `runes` | `boolean` | Compilation mode flags set by `adjust`. |
| `ignore_stack` | `Set<string>[]` | Lexically scoped stack of active ignore codes (see §3.2). |
| `ignore_map` | `Map<node, Set<string>[]>` | Per-node ignore codes captured at parse time, consumed later by `is_ignored` during transformation. |

## 3. Architecture

### 3.1 Position in the compiler pipeline

`state.js` is a **shared hub** with no functional logic of its own: it is written by the pipeline entry points and read by every downstream phase.

```mermaid
flowchart TB
    subgraph PublicAPI["compiler-core_public_api"]
        API["compile() / compileModule()"]
    end

    subgraph CoreState["compiler-core_compile_state (state.js)"]
        RESET["reset()"]
        SETSRC["set_source()"]
        ADJUST["adjust()"]
        PUSH["push_ignore()"]
        POP["pop_ignore()"]
        ISIGN["is_ignored()"]
        LOC["locate_node()"]
        VARS["warnings · source · locator · filename · dev · runes · component_name · warning_filter · ignore_stack · ignore_map"]
    end

    subgraph Parser["compiler-parser (phases/1-parse)"]
        P["parse()"] -->|"reads svelte-ignore comments"| PUSH & POP
    end

    subgraph Analyzer["compiler-analyzer (phases/2-analyze)"]
        A["analyze_component()"] --> ADJUST
        A --> XSEXT["extract_svelte_ignore()"]
    end

    subgraph Transformer["compiler-transformer (phases/3-transform)"]
        T["client/server visitors"] --> ISIGN
    end

    subgraph Diag["compiler-core_diagnostics"]
        E["errors.js → e.* (CompileError + code frame)"]
        W["warnings.js → w.* (Warning)"]
    end

    API --> RESET
    P --> SETSRC
    E & W -->|"read source/locator/warning_filter"| VARS
    W -->|"append filtered warnings"| VARS
    E -->|"throw CompileError"| API
    XSEXT -->|"codes parsed from comments"| PUSH
```

### 3.2 The ignore stack and ignore map

Warnings in Svelte are suppressed in two distinct ways, and `state.js` carries the bookkeeping for both:

1. **`ignore_stack` — compile-time scope** (driven by `push_ignore` / `pop_ignore`).
   Each entry is a `Set<string>` that *merges* the previous scope's codes with the newly declared ones, producing proper lexical nesting: inner scopes inherit all outer suppressions.

2. **`ignore_map` — node-attached, runtime-warning scope.**
   Not all warnings are emitted while the stack is live (e.g. reactivity warnings fire during the client transform, long after parsing). The parser therefore also records the ignore sets *per AST node* in `ignore_map`. `is_ignored(node, code)` later consults this map — but only when `dev === true`, because these codes (`IGNORABLE_RUNTIME_WARNINGS`, such as `state_referenced_locally` / ownership warnings) are dev-only.

```mermaid
flowchart TD
    subgraph ParseTime["Parse time (compiler-parser)"]
        C["comment: &lt;!-- svelte-ignore a11y_missing_attribute, non_reactive_update --&gt;"] --> EX["extract_svelte_ignore() → ['a11y_missing_attribute', 'non_reactive_update']"]
        EX --> PI["push_ignore(ignores)"]
        PI -->|"new Set(parent ∪ ignores)"| ST["ignore_stack: [{a11y_missing_attribute, non_reactive_update}]"]
        ST --> MAP["ignore_map.set(scopeNode, [codes])"]
        NODEEND["scope/node closed"] --> PO["pop_ignore()"]
        PO --> ST2["ignore_stack: [...] (codes no longer active)"]
    end
    subgraph AnalyzeTime["Analyze time (compiler-analyzer)"]
        W1["w.non_reactive_update(...)"] --> CHK{"code in ignore_stack top?"}
        CHK -->|yes| DROP["warning suppressed"]
        CHK -->|no| EMIT["warning appended to state.warnings"]
    end
    subgraph TransformTime["Transform time (compiler-transformer)"]
        T1["visitor e.g. AssignmentExpression"] --> II["is_ignored(node, 'state_referenced_locally')"]
        II -->|"dev && ignore_map has code"| SKIP["skip runtime warning instrumentation"]
    end
```

### 3.3 `push_ignore` / `pop_ignore` semantics

```javascript
export function push_ignore(ignores) {
    const next = new Set([...(ignore_stack.at(-1) || []), ...ignores]);
    ignore_stack.push(next);
}

export function pop_ignore() {
    ignore_stack.pop();
}
```

Key behaviors:

- **Inheritance by union.** The new scope is `parent ∪ ignores`, so nested `svelte-ignore` comments compose — an inner comment need not repeat codes suppressed by an enclosing one.
- **LIFO discipline.** `pop_ignore` is unconditionally paired with `push_ignore` by the parser; there is no reference counting, so callers must guarantee balanced push/pop.
- **Stack-empty safety.** `ignore_stack.at(-1) || []` makes the first push on an empty stack well-defined (after `reset`/`adjust`, which both clear the stack).
- **Snapshot, not live view.** Because each scope is an immutable copy, later `push_ignore` calls never retroactively alter an already-pushed parent scope.

## 4. Compilation Lifecycle (data flow through state)

The sequence below shows one `compile()` call ([compiler-core_public_api](compiler-core_public_api.md)) and every touch point on the state singleton.

```mermaid
sequenceDiagram
    autonumber
    participant API as compile() / compileModule()
    participant ST as state.js
    participant VAL as validate-options
    participant PRS as parser (1-parse)
    participant ANA as analyzer (2-analyze)
    participant TRA as transformer (3-transform)
    participant DIA as warnings.js / errors.js

    API->>ST: reset({ warningFilter, filename })
    Note over ST: warnings=[], ignore_stack=[], ignore_map=[], dev=false, runes=false
    API->>VAL: validate options
    API->>PRS: _parse(source)
    PRS->>ST: set_source(source)
    Note over ST: source set, locator rebuilt
    loop each svelte-ignore comment
        PRS->>ST: push_ignore(codes) / pop_ignore()
    end
    PRS-->>ANA: AST + comments
    ANA->>ST: adjust({ dev, runes, component_name, rootDir })
    Note over ST: ignore stack/map cleared, filename relativized
    ANA->>DIA: e.*() on invalid input
    DIA->>ST: read source + locator (code frames)
    DIA-->>API: throws CompileError (aborts pipeline)
    ANA->>DIA: w.*() for warnings
    DIA->>ST: warning_filter passes? → push to warnings[]
    ANA-->>TRA: ComponentAnalysis
    TRA->>ST: is_ignored(node, code) per dev-only warning site
    TRA-->>API: CompileResult { warnings: state.warnings, ... }
```

## 5. Component Interaction Details

### 5.1 Producers of state

| Producer | Module | Interaction |
|---|---|---|
| `compile` / `compileModule` | [compiler-core_public_api](compiler-core_public_api.md) | Sole entry point for `reset()`; guarantees each compilation starts from a pristine state. |
| `parse` | [compiler-parser](compiler-parser.md) | Calls `set_source()`; pairs `push_ignore`/`pop_ignore` around template regions covered by `svelte-ignore` comments (codes are extracted by `extract_svelte_ignore`, defined in the diagnostics utility module). |
| `analyze_component` | [compiler-analyzer](compiler-analyzer.md) | Calls `adjust()` once the component name, runes mode, and dev flag are resolved; ignores captured during parse are intentionally discarded here. |

### 5.2 Consumers of state

| Consumer | Module | Interaction |
|---|---|---|
| `warnings.js` (`w.*`, e.g. `css_unused_selector`) | [compiler-core_diagnostics](compiler-core_diagnostics.md) | Builds warning objects with locations from `locator`, applies `warning_filter`, appends surviving warnings to `warnings[]`. |
| `errors.js` (`e.*`, e.g. `block_unclosed`) | [compiler-core_diagnostics](compiler-core_diagnostics.md) | Uses `source` + `locator` to render code frames (`get_code_frame`) and throws `CompileError`. |
| Client/server transform visitors | [compiler-transformer](compiler-transformer.md) | Query `is_ignored()` to skip dev-only runtime-warning instrumentation; use `locate_node()` in dev-mode output. |
| `extract_svelte_ignore` / `migrate_svelte_ignore` | [compiler-core_diagnostics](compiler-core_diagnostics.md) | Translate comment text into the code lists handed to `push_ignore`; the migrator rewrites legacy hyphenated codes to rune-era names. |

### 5.3 Options validation boundary

`reset()` receives the user's `warningFilter` and `filename`, which have passed through option validation ([compiler-core_options_validation](compiler-core_options_validation.md)). Removed/renamed compile options (e.g. `enableSourcemap`, `hydratable`) are rejected there, so `state.js` can rely on a minimal, already-validated shape.

## 6. Design Notes & Constraints

- **Module-global by design.** The state is intentionally a mutable singleton: the compiler pipeline is synchronous, so a compilation's state can never interleave with another. This trades thread-safety/re-entrancy for simpler signatures across thousands of visitor functions. Callers must not run `compile()`/`compileModule()` concurrently *within the same JS context* in a way that interleaves their synchronous sections (which plain JS scheduling prevents anyway).
- **Two-phase initialization.** Some facts are only known after parsing (component name, runes mode, dev flag). `adjust()` formalizes this second initialization step, which is why `reset()` uses conservative defaults (`dev = false`, `runes = false`, `component_name = '(unknown)'`).
- **`runes` defaults to `false`** at declaration and in `reset()`, but `adjust()` is always called with the analyzer-resolved value (explicit option, or inferred from rune usage / top-level await — see [compiler-analyzer](compiler-analyzer.md)).
- **Filename normalization.** Backslashes are converted to forward slashes at both `reset` and `adjust`, and `rootDir` is stripped so emitted locations are stable across OSes and build setups. `sanitize_location` additionally inserts zero-width spaces after `/` so location strings cannot accidentally form links in terminals/HTML.
- **Ignore map exists "in addition to" the stack** precisely because warnings are not emitted in parse order — the map decouples *where a suppression is declared* from *where the offending code is detected*.

## 7. Related Modules

| Module | Relationship |
|---|---|
| [compiler-core_public_api](compiler-core_public_api.md) | Drives the lifecycle (`reset` → parse → analyze → transform). |
| [compiler-parser](compiler-parser.md) | Writes `source`/`locator`, produces ignore scopes via `push_ignore`/`pop_ignore`. |
| [compiler-analyzer](compiler-analyzer.md) | Finalizes mode flags via `adjust()`. |
| [compiler-transformer](compiler-transformer.md) | Reads `is_ignored()` / `locate_node()` during code generation. |
| [compiler-core_diagnostics](compiler-core_diagnostics.md) | Reads `source`, `locator`, `warning_filter`; writes `warnings[]`; raises `CompileError`. |
| [compiler-core_options_validation](compiler-core_options_validation.md) | Guarantees the option shape consumed by `reset()`. |
