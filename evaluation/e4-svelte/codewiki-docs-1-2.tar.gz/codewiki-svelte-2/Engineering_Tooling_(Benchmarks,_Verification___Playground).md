# Engineering Tooling (Benchmarks, Verification & Playground)

## Purpose

This module groups the **development- and quality-facing infrastructure** that surrounds the Svelte compiler and runtime. It contains no code shipped to end users; instead it serves three purposes:

1. **Performance benchmarking** — measures the speed of Svelte 5's signal-based reactivity engine and the server-side renderer using several established community benchmark suites, then aggregates the results into comparable reports.
2. **Verification** — guards the quality of the published package, most notably asserting that every public export of `svelte` remains tree-shakeable so bundlers can eliminate unused code.
3. **Interactive experimentation** — powers the browser-based sandbox playground (used on svelte.dev), which compiles Svelte source entirely client-side and encodes editor sessions into shareable URL hashes.

## Architecture

### Module layout

```mermaid
flowchart TB
    ROOT["Engineering Tooling"] --> BENCH["Benchmarking<br/>(benchmarking/)"]
    ROOT --> VERIFY["Verification<br/>(packages/svelte/scripts)"]
    ROOT --> PLAY["Playground<br/>(playgrounds/sandbox)"]

    BENCH --> RB["Reactivity Benchmarks<br/>benchmarking/benchmarks/reactivity"]
    BENCH --> SSRB["SSR Benchmarks<br/>benchmarking/benchmarks/ssr/wrapper"]
    BENCH --> CMP["Benchmark Comparison<br/>benchmarking/compare"]

    RB --> K["kairo_suites"]
    RB --> S["sbench"]
    RB --> M["mol_bench"]

    VERIFY --> TS["Tree-shakeability Checker<br/>check-treeshakeability.js"]

    PLAY --> SBX["Sandbox Playground Tooling"]
    SBX --> CR["Compile Runner"]
    SBX --> SLH["Share-Link Hash"]
```

### Relationship to the Svelte core

```mermaid
flowchart LR
    subgraph CORE["Svelte core (packages/svelte)"]
        COMP["Compiler pipeline"]
        REACT["Client reactivity engine"]
        SRV["Server runtime (SSR)"]
        PKG["Public API surface"]
    end

    subgraph TOOLS["Engineering tooling"]
        RB["Reactivity benchmarks"]
        SSRB["SSR benchmarks"]
        TC["Tree-shakeability checker"]
        SBX["Sandbox playground"]
    end

    RB -- "measures" --> REACT
    SSRB -- "measures" --> SRV
    TC -- "verifies" --> PKG
    SBX -- "exercises compiler" --> COMP
```

The benchmark suites feed raw measurements into the comparison tooling, which normalizes them into cross-framework / cross-commit reports. The playground is deliberately self-contained: it loads the full compiler into a Web Worker so users can compile and preview components without any server round-trip.

## Core Components

| Component | Location | Role |
|---|---|---|
| [Reactivity Benchmarks](<reactivity_benchmarks.md>) | `benchmarking/benchmarks/reactivity` | Runs three community signal-performance suites — **kairo**, **sbench**, and **mol_bench** — against Svelte 5's reactivity engine, covering graph construction, update propagation, and large-scale dependency scenarios. |
| [SSR Benchmarks](<ssr_benchmarks.md>) | `benchmarking/benchmarks/ssr/wrapper` | Measures server-side rendering throughput by wrapping the SSR pipeline and rendering components to strings at scale. |
| [Benchmark Comparison](<benchmark_comparison.md>) | `benchmarking/compare` | Orchestrates and normalizes results from the benchmark suites, producing side-by-side comparisons across frameworks and compiler versions. |
| [Tree-shakeability Checker](<treeshakeability_checker.md>) | `packages/svelte/scripts/check-treeshakeability.js` | Verification script that bundles imports of the package's public API and asserts unused exports are eliminated, keeping the `svelte` package tree-shakeable. |
| [Sandbox Playground Tooling](<sandbox-playground-tooling.md>) | `playgrounds/sandbox` | The in-browser REPL/playground: a **compile runner** executes the full Svelte compiler inside a Web Worker, and the **share-link hash** serializes editor state (source + options) into URL hashes for shareable sessions. |