# Client Runtime Engine (Reactivity & DOM Rendering)

**Path:** `packages/svelte/src`

## Purpose

This module is the browser-side runtime that every compiled Svelte component links against. While the [compiler pipeline](<../Compiler_Pipeline___Language_Toolchain/index.md>) turns `.svelte` files into JavaScript, that generated code is only a thin driver: the heavy lifting at runtime — tracking reactive state, propagating updates, building and patching the DOM — is implemented here.

The module provides four cooperating subsystems:

1. **Reactivity engine** – a fine-grained, push/pull signal system (sources, deriveds, async deriveds), an effect system for re-running work, microtask-based batching/scheduling, and the plumbing for component props and stores.
2. **DOM renderer** – template-based DOM construction (clone templates produced by the compiler), control-flow blocks (`if`/`each`/`key`/`await`/snippets), attributes & event delegation, two-way bindings, transitions, custom elements, and the public `mount`/`hydrate`/`unmount` lifecycle.
3. **Dev tooling** – development-only instrumentation: ownership/mutation guards, runtime validation, `$inspect` & state tracing, HMR support, and the runtime error/warning message catalog.
4. **Legacy compatibility** – shims that let Svelte 4–style compiled components (`new Component()`, `$set`/`$on`/`$destroy`, `createEventDispatcher`) run inside a Svelte 5 application.

## Architecture

The runtime is layered: a low-level foundation (context, untracking, component instantiation) supports a signal graph; effects subscribe to that graph and are driven by a central scheduler; the DOM renderer expresses all rendering as effects, so **every UI update is just a reactive effect being flushed**. Dev tooling wraps the core with checks, and legacy compat sits beside it as an adapter facade.

```mermaid
flowchart TB
    M["Client Runtime Engine<br/>packages/svelte/src"]

    M --> RE["client-reactivity-engine<br/>internal/client"]
    M --> DR["client-dom-renderer<br/>internal/client/dom"]
    M --> DT["client-dev-tooling<br/>internal/client/dev"]
    M --> LG["legacy-compat<br/>legacy/"]

    RE --> sg["signal-graph<br/>sources & dependencies"]
    RE --> sp["sources-and-proxies<br/>deep reactive state"]
    RE --> da["deriveds-and-async<br/>computed + async deriveds"]
    RE --> ef["effects<br/>render / user / pre effects"]
    RE --> bs["batching-scheduling<br/>Batch & flush queue"]
    RE --> ps["props-and-stores<br/>prop plumbing, store bridge"]
    RE --> fd["foundation<br/>context, untrack, instantiation"]

    DR --> lc["lifecycle<br/>mount / hydrate / unmount"]
    DR --> df["dom-foundation<br/>templates, fragments, reconciler"]
    DR --> cf["control-flow-blocks<br/>if / each / key / await / snippet"]
    DR --> ae["attributes-events<br/>attr, class, style, delegation"]
    DR --> bd["bindings<br/>two-way inputs, media, window"]
    DR --> ce["custom-elements<br/>svelte custom element wrapper"]
    DR --> tr["transitions<br/>transition / animation runtime"]

    DT --> d1["mutation-ownership-guards"]
    DT --> d2["message-catalog"]
    DT --> d3["runtime-validation"]
    DT --> d4["state-inspection ($inspect, tracing)"]
    DT --> d5["hmr-support"]
    DT --> d6["legacy-and-metadata"]

    LG --> l1["component-api-shims"]
    LG --> l2["legacy-lifecycle"]
    LG --> l3["legacy-events-and-props"]
```

### Update pipeline

Rendering and updates flow through the subsystems as follows — the DOM is never patched directly by application code; everything is mediated by the signal graph and the scheduler:

```mermaid
flowchart LR
    GEN["Compiled component code"] -->|"mount() / hydrate()"| LIF["lifecycle"]
    LIF -->|"clone template"| TPL["dom-foundation<br/>fragments & template nodes"]
    TPL --> BUILD["effects: render effects<br/>build blocks, attrs, events"]
    BUILD --> GRAPH["signal-graph<br/>state / derived signals"]
    BUILD --> DOM["Live DOM tree"]

    USER["User interaction /<br/>async data"] -->|"signal set"| GRAPH
    BIND["bindings"] -->|"two-way writes"| GRAPH
    GRAPH -->|"mark dirty"| BATCH["batching-scheduling<br/>microtask flush"]
    BATCH -->|"flush dirty effects"| BUILD
    BUILD -->|"patch text / attrs / blocks"| DOM

    DEV["dev-tooling guards"] -.->|"validate"| GRAPH
    LEG["legacy-compat shims"] -.->|"adapt"| GRAPH
```

## Core Components

| Subsystem | Documentation | Responsibility |
|---|---|---|
| `client-reactivity-engine` | [client-reactivity-engine.md](<client-reactivity-engine.md>) | The signals core: signal graph, sources & deep proxies, deriveds & async deriveds, effects, batching/scheduling, props & store integration, and the runtime foundation (context, untrack, mount internals). |
| `client-dom-renderer` | [client-dom-renderer.md](<client-dom-renderer.md>) | All DOM concerns: the `mount`/`hydrate`/`unmount` lifecycle, template cloning & reconciliation, control-flow blocks, attributes/events, bindings, transitions, and custom elements. |
| `client-dev-tooling` | [client-dev-tooling.md](<client-dev-tooling.md>) | Development-mode safety nets: cross-component ownership & mutation guards, runtime validation, `$inspect`/state tracing, HMR support, and the error/warning message catalog. |
| `legacy-compat` | [legacy-compat.md](<legacy-compat.md>) | Compatibility shims for Svelte 4–style components: class-based component API (`$set`, `$on`, `$destroy`), legacy lifecycle hooks, and legacy event/prop semantics. |

Together, these four subsystems form the complete execution environment for compiled Svelte components on the client: the reactivity engine answers *"what changed?"*, the DOM renderer answers *"how is it shown?"*, dev tooling answers *"did the developer break the rules?"*, and legacy compat ensures older compiled output keeps working.