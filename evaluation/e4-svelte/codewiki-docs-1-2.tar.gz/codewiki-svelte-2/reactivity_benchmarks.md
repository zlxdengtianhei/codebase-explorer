# Reactivity Benchmarks (`benchmarking/benchmarks/reactivity/`)

## 1. Purpose

The **reactivity_benchmarks** module is the performance-measurement suite for Svelte 5's client-side
reactivity engine — the signal graph that powers `$state`, `$derived`, and effects. It answers the
question *"how fast is the reactive runtime?"* in a structured, reproducible, and correctness-checked way.

The suite is adapted from the community
[js-reactivity-benchmark](https://github.com/milomg/js-reactivity-benchmark) project (see the credit
comment in `index.js`), trimmed and tweaked to capture the data points the Svelte team cares about:

- **Signal creation & wiring cost** — how expensive it is to build large graphs (up to 100,000 nodes).
- **Update propagation cost** — how efficiently a single source change fans out through chains,
  diamonds, triangles, multiplexers and other dependency-graph shapes.
- **Scheduling & dirty-checking quality** — whether work that *should* be skipped actually is
  (`kairo_avoidable`), and how dynamic ("unstable") dependency sets are handled (`kairo_unstable`).
- **Memory/GC pressure** — every benchmark reports `gc_time` alongside wall-clock `time`.
- **Ownership overhead** — most suites run in an `_owned` and an `_unowned` flavor to isolate the
  cost of owner/scope linking done inside `$.effect_root`.

Every benchmark doubles as a **correctness smoke test**: each iteration asserts exact expected values
via `assert(...)`, so a runtime regression either fails loudly or produces visibly wrong timings.

## 2. Position in the system

```
Engineering_Tooling (Benchmarks, Verification & Playground)
├── reactivity_benchmarks   ← this module (pure functions + result contract, no CLI of its own)
├── ssr_benchmarks          ← sibling SSR benchmark suite
├── benchmark_comparison    ← the CLI that *runs* this module per git branch and renders results
├── treeshakeability_checker
└── sandbox-playground-tooling
```

The benchmarks themselves are **library code**: they export async functions that return measurement
objects. They are consumed by the **benchmark_comparison** module
(`benchmarking/compare/index.js` + `benchmarking/compare/runner.js`), which forks a runner per git
branch and renders bar-chart comparisons.

```mermaid
flowchart LR
    subgraph TOOLING["Engineering tooling"]
        CMP["benchmark_comparison<br/>compare/index.js · runner.js"]
        RB["<b>reactivity_benchmarks</b><br/>(this module)"]
        SSR["ssr_benchmarks"]
    end
    subgraph RUNTIME["Runtime under test"]
        CRT["Client Runtime Engine<br/>svelte/internal/client<br/>(signal graph, scheduler, effects)"]
    end
    CMP -- "forks runner.js per branch;<br/>runner imports reactivity_benchmarks array" --> RB
    RB -- "$.state / $.derived / $.get / $.set /<br/>$.effect_root / $.render_effect / $.flush" --> CRT
```

The measured primitives are documented in the **Client Runtime Engine (Reactivity & DOM Rendering)**
module — in particular its *signal graph*, *sources & proxies*, *effects* and *batching/scheduling*
sub-modules. This document deliberately does not re-explain how the runtime works; it documents what
is measured and how.

## 3. Architecture overview

### 3.1 File map and dependencies

```mermaid
flowchart TD
    RUNNER["benchmarking/compare/runner.js<br/>(forked child process, one per branch)"]
    IDX["benchmarks/reactivity/index.js<br/><b>reactivity_benchmarks</b>: ordered array of 28 benchmark fns"]

    IDX --> SB["sbench.js<br/>10 creation-topology benchmarks<br/>(fan-in / fan-out at 100k scale)"]
    IDX --> MOL["mol_bench.js<br/>dense A–G graph with fib(16) payload"]
    IDX --> K["kairo/*.js<br/>8 graph-shape suites × owned/unowned"]

    SB -- "fastest_test · assert" --> UTIL["benchmarking/utils.js<br/>timing + GC harness"]
    MOL -- "fastest_test · assert" --> UTIL
    K -- "fastest_test · assert" --> UTIL
    K -- "busy()" --> KBUSY["kairo/util.js<br/>deterministic CPU load"]

    SB -- "imported directly from<br/>packages/svelte/src/internal/client/index.js" --> INT["svelte/internal/client"]
    MOL -- "svelte/internal/client" --> INT
    K -- "svelte/internal/client" --> INT

    IDX -.-> RUNNER
```

> **Import detail:** `sbench.js` imports the runtime via the *source path*
> (`../../../packages/svelte/src/internal/client/index.js`), while the kairo and mol suites import
> the package specifier `svelte/internal/client`. Behavior is identical; the difference is historical.

### 3.2 Logical sub-modules

| Sub-module | Documentation | Files | Focus |
|---|---|---|---|
| **kairo suites** | [reactivity_benchmarks_kairo_suites.md](reactivity_benchmarks_kairo_suites.md) | `kairo/` — avoidable, broad, deep, diamond, mux, repeated, triangle, unstable | **Update propagation** across canonical dependency-graph shapes; every suite ships `_owned` + `_unowned` variants |
| **sbench** | [reactivity_benchmarks_sbench.md](reactivity_benchmarks_sbench.md) | `sbench.js` | **Creation & wiring cost** of signals/deriveds across star topologies (0→1, 1→1, 2→1, 4→1, 1000→1, 1→2, 1→4, 1→8, 1→1000) at ~100k nodes |
| **mol bench** | [reactivity_benchmarks_mol_bench.md](reactivity_benchmarks_mol_bench.md) | `mol_bench.js` | **Dense, expensive graph**: mixed reads/writes, custom equality, `fib(16)`-heavy recomputation, 10k iterations |

All three are aggregated by `index.js` into the canonical `reactivity_benchmarks` array — the *public
surface* of this module. **The array order is the execution order** and must stay in sync with the
runner: `benchmarking/compare/index.js` zips results across branches **by index**, and only uses the
`benchmark` name as a display title.

```javascript
// benchmarking/benchmarks/reactivity/index.js (excerpt)
export const reactivity_benchmarks = [
        sbench_create_signals, sbench_create_0to1, /* … 8 more sbench … */
        kairo_avoidable_owned, kairo_avoidable_unowned, /* … 14 more kairo … */
        mol_bench_owned, mol_bench_unowned
]; // 28 entries total
```

## 4. Benchmark anatomy & execution model

### 4.1 Runtime primitives under test

| Primitive | Role in benchmarks |
|---|---|
| `$.state(v)` | create a writable source signal (bench "head") |
| `$.derived(fn)` | create a computed node; its function reads upstream signals via `$.get` |
| `$.get(s)` | read a signal; registers a dependency when called inside an active reactive context |
| `$.set(s, v)` | write a signal inside a `$.flush` batch, scheduling propagation |
| `$.effect_root(fn)` | open an ownership root scope; returns a `destroy` teardown |
| `$.render_effect(fn)` | create an effect that tracks the signals it reads (bench "sink"/counter) |
| `$.flush(fn)` | apply mutations, then synchronously drain the scheduler |

### 4.2 Shared harness (`benchmarking/utils.js`)

All suites time work with one helper and verify results with another:

- **`fastest_test(times, fn)`** — runs `fn` inside `run_tracked`, which (1) forces a full GC via
  `v8-natives`, (2) wall-clock times the call, (3) collects `'gc'` `PerformanceObserver` entries that
  fall inside the measured window to derive `gc_time`, then repeats `times` times and returns the
  **fastest** pass. Best-of-N plus forced GC keeps numbers comparable across branches.
- **`assert(cond)`** — throws `Assertion failed` on any violated invariant, inside the timed loop.

### 4.3 The canonical kairo/mol lifecycle

Every kairo suite and `mol_bench` follows the same template:

```mermaid
sequenceDiagram
    autonumber
    participant B as benchmark fn<br/>(e.g. kairo_deep_owned)
    participant S as setup()
    participant H as fastest_test<br/>+ GarbageTrack
    B->>S: setup() — build graph (state/derived/render_effect)
    S-->>B: { run, destroy }
    B->>B: 10 × warm-up (setup → run → destroy) — JIT warm-up
    B->>H: fastest_test(10, timed workload)
    H->>H: v8.collectGarbage() before each pass
    H->>H: time pass + observe 'gc' entries in window
    Note over H: workload = 1000 × run():<br/>$.flush(set head) → assert expected values
    H-->>B: { time, gc_time } of fastest pass
    B->>B: destroy() (+ destroy_owned() when owned)
    B-->>B: return { benchmark, time, gc_time }
```

Key conventions:

- **Warm-up before timing.** ~10 discarded setup/run/destroy cycles let the JIT settle; sbench uses 3.
- **Assertions inside the hot loop.** Expected values are recomputed per shape, so the benchmark
  cannot silently drift from correctness while staying "fast".
- **`$.flush(() => $.set(head, i))`** is the atomic update unit — one source write, one synchronous
  propagation drain. `run()` typically performs 100–1000 of these per pass.
- **Owned vs unowned.**
  - `_unowned`: graphs are created at the top level of the benchmark function — no owner scope.
  - `_owned`: an identical `setup()` runs *inside* `$.effect_root(...)`; nodes are linked to the root
    and torn down by `destroy()`. Comparing the pair isolates the overhead of ownership bookkeeping.
- **Result contract.** Each exported fn returns
  `{ benchmark: string, time: "ms", gc_time: "ms" }` — numbers formatted to 2 decimals (as strings,
  hence the `+result[i][metric]` coercion in the compare tool).

```mermaid
flowchart LR
    A["setup():<br/>build signal graph<br/>in/without $.effect_root"] --> B["warm-up<br/>10 × (setup·run·destroy)"]
    B --> C["fastest_test(10 passes)"]
    C --> D["pass = N × run()<br/>flush·set·assert"]
    D --> E["destroy graph"]
    E --> F["{ benchmark, time, gc_time }"]
```

## 5. What each shape measures (suite catalog)

```mermaid
flowchart TB
    subgraph SHAPES["Dependency-graph shapes exercised by the suites"]
        DEEP["deep — 50-node chain<br/>sequential propagation"]
        BROAD["broad — 50 parallel branches<br/>broadcast to many sinks"]
        DIAMOND["diamond — 1→5→1<br/>fan-out + join dedup"]
        TRIANGLE["triangle — chain + aggregate<br/>overlapping paths"]
        MUX["mux — 100→object→100<br/>multiplex/demultiplex"]
        REPEATED["repeated — 1 derived<br/>reads head 30× per pass"]
        UNSTABLE["unstable — parity-switched deps<br/>dynamic dependency set"]
        AVOIDABLE["avoidable — constant short-circuit<br/>skip-work / dirty-checking"]
        MOL["mol — dense A–G graph<br/>expensive fib(16) payload"]
        SB["sbench — star topologies<br/>creation & wiring at 100k scale"]
    end
```

| Suite (files) | Graph shape | Isolates |
|---|---|---|
| `kairo/kairo_deep.js` | `state → 50 × derived(+1) → render_effect` | linear propagation cost per hop |
| `kairo/kairo_broad.js` | `state → 50 × (derived → derived → effect)` | broadcast to many independent branches (asserts 50×50 effect runs) |
| `kairo/kairo_diamond.js` | `state → 5 deriveds → sum → effect` | fan-out + join; effect must run exactly once per update |
| `kairo/kairo_triangle.js` | chain of 10, sum over *all* chain nodes | overlapping/redundant paths to one sink |
| `kairo/kairo_mux.js` | 100 sources → one `Object.fromEntries` derived → 100 split deriveds + effects | multiplexing through object-valued deriveds, then demultiplexing |
| `kairo/kairo_repeated.js` | one derived reads `head` 30× in a loop | cost of repeated reads of the same dependency |
| `kairo/kairo_unstable.js` | derived reads `double` or `inverse` based on `head` parity (×20) | unstable/dynamic dependency sets |
| `kairo/kairo_avoidable.js` | chain where node 2 always returns 0; `busy()` markers downstream | avoidance of provably-unaffected work; result must stay `6` |
| `mol_bench.js` | A,B → C,D,E,F,G with custom array equality on D | dense mixed graph, expensive recompute (`fib(16)`), exact-value asserts (`3198/1601/3195/1598`) |
| `sbench.js` | `Nto1` fan-in and `1toN` fan-out stars, plus raw signal creation | node creation & wiring throughput (~100k nodes) |

## 6. How results are consumed

1. `benchmarking/compare/index.js` parses branch args (defaults to `HEAD` vs `main`), checks out each
   branch, and **forks** `benchmarking/compare/runner.js`.
2. The runner imports the `reactivity_benchmarks` array, awaits every benchmark in order, and
   `process.send`s the array of result objects back over IPC.
3. Results are written to `benchmarking/compare/.results/<branch>.json`, then printed as
   normalized 20-character bar charts (`◼` blocks) per benchmark for both `time` and `gc_time`;
   the fastest branch per benchmark is labeled `a`/`b`/…

Run a full cross-branch comparison with:

```bash
node benchmarking/compare/index.js            # current branch vs main
node benchmarking/compare/index.js feat main  # explicit branches
```

Individual benchmarks can also be imported and awaited directly (e.g. from a scratch script), since
each is a self-contained async function.

## 7. Sub-module documentation

The detailed references below use the final generated file names (all flat in this directory):

- **[reactivity_benchmarks_kairo_suites.md](reactivity_benchmarks_kairo_suites.md)** — the eight
  canonical graph-shape benchmarks (`kairo_avoidable` … `kairo_unstable`), the owned/unowned pattern,
  per-shape correctness invariants, and the shared `busy()` helper from `kairo/util.js`.
- **[reactivity_benchmarks_sbench.md](reactivity_benchmarks_sbench.md)** — creation-topology
  benchmarks: pure signal creation and the nine fan-in/fan-out wiring shapes.
- **[reactivity_benchmarks_mol_bench.md](reactivity_benchmarks_mol_bench.md)** — the dense
  expensive-graph benchmark ported from js-reactivity-benchmark, including its custom equality hook
  and exact-value assertions.

Adding a new benchmark? Export it from its suite file, add it to the `reactivity_benchmarks` array in
`index.js` (order matters — results are zipped by index across branches), and document the shape in
the relevant sub-module page.

## 8. Related modules

- **Client Runtime Engine (Reactivity & DOM Rendering)** — implements every `$.` primitive exercised
  here; its *signal graph*, *effects*, and *batching/scheduling* sub-modules are the code whose
  performance this suite quantifies.
- **benchmark_comparison** — the branch-diff CLI that executes `reactivity_benchmarks` and renders
  the results.
- **ssr_benchmarks** — the sibling suite measuring server-side rendering throughput rather than
  reactivity.
