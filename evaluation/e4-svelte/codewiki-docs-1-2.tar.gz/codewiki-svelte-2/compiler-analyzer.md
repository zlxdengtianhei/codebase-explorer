# Compiler Analyzer (Phase 2: Semantic Analysis)

> **Module scope:** `packages/svelte/src/compiler/phases/2-analyze/` and the scope machinery in `packages/svelte/src/compiler/phases/scope.js`

## 1. Introduction & Purpose

The **compiler-analyzer** is the second phase of the Svelte compiler pipeline (`Compiler_Pipeline___Language_Toolchain`). It sits between the parser and the transformer and answers one broad question for every component: *what does this code mean, and is it valid?*

Concretely, the analysis phase:

- **Builds the scope & binding graph** — every identifier declaration and reference in the `<script module>`, `<script>` (instance) and template sections is resolved to a `Binding` object inside a lexical `Scope` tree.
- **Classifies reactivity** — determines whether the component is in **runes mode** or **legacy mode**, and annotates every binding with a `BindingKind` (`state`, `derived`, `prop`, `bindable_prop`, `store_sub`, `legacy_reactive`, `each`, `template`, …).
- **Validates the component** — enforces language rules (placement of `{#if}`/`{#each}`/`{#await}` blocks, `{@const}` placement, `:global` CSS usage, export restrictions, attribute legality on `<svelte:*>` elements, event syntax mixing, etc.) by raising compile errors and warnings.
- **Collects transformation metadata** — visitors populate `node.metadata` (expression dependencies, reactivity, dynamic fragments, keyed-ness of each blocks, CSS scoping) and a component-wide `ComponentAnalysis` object (`uses_slots`, `needs_props`, `reactive_statements`, `snippet_renderers`, `css.hash`, …) that the downstream transformer consumes verbatim.
- **Analyzes CSS scoping** — walks the CSS AST to determine which selectors are global vs. scoped, validates `:global` usage, tracks keyframes, and decides whether a component ships global CSS (`css.has_global`).

The phase is read-mostly over the AST: it never rewrites the tree (that is Phase 3's job), but it *does* heavily annotate it — the transformer's behaviour is driven almost entirely by the metadata computed here.

## 2. Position in the Compiler Pipeline

```mermaid
flowchart LR
    SRC[.svelte source] --> P["Phase 1 — Parse<br/>(see compiler-parser)"]
    P --> AST["AST<br/>Root { module, instance,<br/>fragment, css, options }"]
    AST --> A["Phase 2 — Analyze<br/>(this module)"]
    A --> CA["ComponentAnalysis +<br/>annotated AST"]
    CA --> T["Phase 3 — Transform<br/>(see compiler-transformer)"]
    T --> OUT["client.js / server.js / css output"]
    E["errors.js / warnings.js<br/>(see compiler-core)"] -.diagnostics.-> A
```

**Inputs** — the AST produced by [`compiler-parser`](compiler-parser.md) (`parse()` in `phases/1-parse/index.js`), plus validated compile options.
**Outputs** — a `ComponentAnalysis` (`phases/types.d.ts`) and an AST whose `node.metadata` fields are fully populated.
**Dependencies** — diagnostics and AST builders come from [`compiler-core`](compiler-core.md) (`errors.js`, `warnings.js`, `utils/builders.js`, `utils/ast.js`); the walk engine is `zimmerframe`.

## 3. Architecture Overview

The module has one orchestrator and three cooperating subsystems:

| Subsystem | Location | Responsibility |
|---|---|---|
| **Orchestrator** | `phases/2-analyze/index.js` → `analyze_component()` | Drives the whole phase: creates scopes, synthesises store subscriptions, decides runes mode, walks all three ASTs with the visitor map, then runs CSS analysis/pruning and final consistency checks. |
| **Scope & Binding system** | `phases/scope.js` | `Scope`, `Binding`, `Evaluation`, `ScopeRoot` classes; `create_scopes()` first pass; `set_scope()` re-binding visitor used during later walks. |
| **Node visitors** | `phases/2-analyze/visitors/*.js` | One exported function per AST node type (~60 files). Each validates its node, propagates expression/fragment metadata, and recurses via `context.next()`. Shared helpers live in `visitors/shared/`. |
| **CSS analysis** | `phases/2-analyze/css/css-analyze.js` (+ `css-prune.js`, `css-warn.js`, `css/utils.js`) | Validates `:global` usage, classifies selectors as global/scoped/unused, tracks keyframes, computes `has_global`. |

```mermaid
flowchart TB
    subgraph Orchestrator["analyze_component (2-analyze/index.js)"]
        direction TB
        S1["1. create_scopes() for module / instance / template"]
        S2["2. Synthesise $store bindings,<br/>detect runes mode"]
        S3["3. walk(module/instance/template, visitors)"]
        S4["4. analyze_css() + prune + warn_unused"]
        S5["5. Final checks & returns ComponentAnalysis"]
        S1 --> S2 --> S3 --> S4 --> S5
    end

    SCOPE["Scope subsystem<br/>phases/scope.js"] --> S1
    SCOPE -. "set_scope helper" .-> S3
    VIS["Visitor map<br/>visitors/*.js"] --> S3
    CSSA["CSS analysis<br/>css/css-analyze.js"] --> S4
    CORE["compiler-core<br/>errors / warnings / builders"] -.-> VIS
    CORE -.-> CSSA
    CORE -.-> SCOPE
```

### 3.1 Execution flow of a component analysis

```mermaid
sequenceDiagram
    participant C as compile()/compileModule()
    participant A as analyze_component()
    participant SC as create_scopes()
    participant W as zimmerframe walk
    participant V as visitor map
    participant CSS as analyze_css()

    C->>A: root AST + source + options
    A->>SC: build Scope tree & Bindings (pass 1)
    SC-->>A: { scope, scopes, has_await }
    A->>A: synthesise store_sub bindings,<br/>decide runes mode
    loop for each of [module, instance, template]
        A->>W: walk(ast, AnalysisState, visitors)
        W->>V: dispatch per node.type
        V->>V: validate, mutate Binding & node.metadata
        V-->>W: context.next()
    end
    A->>CSS: walk(css ast, CssState, css_visitors)
    CSS-->>A: keyframes, has_global, selector metadata
    A->>A: prune unused CSS, emit remaining diagnostics
    A-->>C: ComponentAnalysis
```

## 4. Key Concepts

### 4.1 Two-pass design

1. **Scope creation pass** — `create_scopes()` walks the whole AST once, declaring every identifier (`Binding`) and recording every reference/mutation *after the fact*, so forward references work. It also returns `has_await`, which lets a top-level `await` automatically opt a component into runes mode.
2. **Analysis pass** — `analyze_component()` re-walks module/instance/template ASTs with the visitor map, carrying an `AnalysisState` that includes the matching `Scope` per node (via `set_scope`), the `ComponentAnalysis` accumulator, and the current `ExpressionMetadata` chain.

### 4.2 Binding kinds drive code generation

Every declaration is stamped with a `BindingKind`. The transformer switches on this value, so the analyzer's classification is the single source of truth for "is this reactive?":

| Kind | Meaning | Typical origin |
|---|---|---|
| `normal` | plain local variable | `let x = 1` |
| `state` / `raw_state` | `$state()` rune | runes mode |
| `derived` | `$derived()` rune | runes mode |
| `prop` / `bindable_prop` / `rest_prop` | component inputs | `export let x` (legacy) / `$props()` |
| `store_sub` | synthetic `$store` subscription | `analyze_component` |
| `legacy_reactive` | `$: a = ...` target | legacy mode |
| `each`, `template`, `snippet`, `param`, `import` | contextual declarations | blocks & functions |

### 4.3 Expression & fragment metadata

`create_expression_metadata()` (in `phases/nodes.js`) produces `{ dependencies, references, has_state, has_call, has_member_expression, has_assignment, has_await }`. Visitors propagate this object down expression trees (`context.state.expression`) and aggregate results upward, telling the transformer whether a value is static, reactive, or async. Similarly, `mark_subtree_dynamic()` (in `visitors/shared/fragment.js`) flags enclosing `Fragment`s as `metadata.dynamic` so the renderer knows which blocks need reactive updates.

### 4.4 Runes vs. legacy mode

The analyzer is the component that *decides* the mode: explicit `runes` compiler option wins; otherwise any rune reference, blocking `await`, or rune-like `$name` store subscription turns it on. Legacy mode adds behaviour handled here — `export let` → `bindable_prop`, `$:` reactive statements (`analysis.reactive_statements`, topologically ordered via `order_reactive_statements`), and promotion of `normal` bindings to `state` when they are mutated and referenced reactively.

## 5. Sub-module Documentation

The module is split into three documented sub-modules. All documentation files live in the same flat directory as this file:

| # | Documentation file | Source | Contents |
|---|---|---|---|
| 1 | **[compiler-analyzer_scope.md](compiler-analyzer_scope.md)** | `phases/scope.js` | `Scope`, `Binding`, `Evaluation`, `ScopeRoot` classes; `create_scopes()` first pass; the `set_scope()` walk helper; scope-related template visitors (`SvelteFragment`, `SvelteDirective`); static partial evaluation (`Scope.evaluate`) and rune detection (`get_rune`). The semantic backbone every visitor and the transformer rely on. |
| 2 | **[compiler-analyzer_visitors.md](compiler-analyzer_visitors.md)** | `phases/2-analyze/visitors/*.js` | Per-node-type analysis functions: control-flow blocks (`AwaitBlock`, `EachBlock`, `IfBlock`, `KeyBlock`), tags & directives (`ConstTag`, `HtmlTag`, `ClassDirective`, `StyleDirective`, `DebugTag`), special elements (`SvelteBody`, `SvelteBoundary`, `SvelteDocument`, `SvelteFragment`, `SvelteHead`, `SvelteWindow`, `TitleElement`), module semantics (`ExportDefaultDeclaration`, `ExportNamedDeclaration`, `ExportSpecifier`), JS expressions (`AwaitExpression`, `NewExpression`, `TaggedTemplateExpression`, `TemplateElement`), and shared validation helpers (`validate_opening_tag`, `validate_block_not_empty`, `mark_subtree_dynamic`). |
| 3 | **[compiler-analyzer_css_analysis.md](compiler-analyzer_css_analysis.md)** | `phases/2-analyze/css/css-analyze.js` | The CSS visitor set (`Atrule`, `ComplexSelector`, `RelativeSelector`, `Rule`, `NestingSelector`) with helpers `is_global_block_selector()`, `is_in_global_block()`, `is_unscoped()`: validates `:global` placement, classifies global/unscoped selectors and keyframes, and feeds `css-prune.js` / `css-warn.js` downstream. |

## 6. Data Flow Summary

```mermaid
flowchart LR
    subgraph Inputs
        AST[AST nodes]
        SRC[source string]
        OPT[compile options]
    end
    subgraph Analyzer
        SC[Scope/Binding graph]
        ST[AnalysisState per walk]
        VIS2[Visitor dispatch]
        CSSM[CSS metadata]
    end
    subgraph Outputs["ComponentAnalysis"]
        META[node.metadata:<br/>expression deps, dynamic, keyed, scoped]
        BIND[Binding.kind / mutated / reassigned]
        FLAGS[runes, needs_props, uses_slots,<br/>reactive_statements, css.hash ...]
    end
    AST --> SC
    SC --> ST
    ST --> VIS2
    VIS2 --> META
    VIS2 --> BIND
    VIS2 --> FLAGS
    CSSM --> FLAGS
    SRC --> VIS2
    OPT --> FLAGS
```

## 7. How This Module Fits Into the System

- **Consumed by the transformer**: [`compiler-transformer`](compiler-transformer.md) reads `analysis.runes`, binding kinds, `node.metadata`, `analysis.css.hash` etc. to decide between client/server/CSS transform strategies. Nothing is re-derived there — if the analyzer's metadata is wrong, the output is wrong.
- **Depends on the parser**: [`compiler-parser`](compiler-parser.md) guarantees a syntactically valid AST (including `<svelte:options>` extraction and TypeScript stripping); the analyzer only performs *semantic* validation.
- **Shares diagnostics with compiler-core**: [`compiler-core`](compiler-core.md) owns `errors.js` / `warnings.js` (e.g. `css_global_block_invalid_placement`, `block_unclosed`, `css_unused_selector`), the `compile_diagnostic` code-frame printer, and the `builders` used to synthesise synthetic declarations (`b.id(...)`).
- **Preprocessors & migrator** operate *before/outside* this phase — see [`compiler-preprocessor`](compiler-preprocessor.md) and [`compiler-migrator`](compiler-migrator.md).

## 8. Maintenance Notes

- **Adding a new node type?** Create `visitors/<NodeType>.js` exporting a function with the same name, import it into the `visitors` map in `2-analyze/index.js`, and (if it declares identifiers) extend `create_scopes()` in `phases/scope.js`.
- **Adding a validation rule?** Prefer a specific named error in `compiler-core/errors.js` (message templates live under `scripts/process-messages/templates/`) over generic errors — each has an associated docs page slug.
- **CSS behaviour changes** almost always touch three places consistently: `css/css-analyze.js` (validity + metadata), `css/css-prune.js` (scoped/unused marking) and `css/css-warn.js` (`css_unused_selector`).
- The `Evaluation` class performs *static partial evaluation* with a `current_evaluations` guard against recursion; it may only be called once scopes are fully generated (see `Scope.evaluate` JSDoc).
