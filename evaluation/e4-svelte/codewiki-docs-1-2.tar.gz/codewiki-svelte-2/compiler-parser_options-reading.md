# compiler-parser: Options Reading (`read_options`)

## 1. Introduction

The **options-reading** module is a small but critical subsystem of the Svelte compiler's parsing phase (Phase 1). Its single exported entry point, [`read_options`](../../../packages/svelte/src/compiler/phases/1-parse/read/options.js), is responsible for interpreting the raw `<svelte:options>` element found at the top of a `.svelte` file and converting it into a validated, structured options object (`AST.SvelteOptions`) that is attached to the parse-tree `Root` node.

Because `<svelte:options>` is the only mechanism by which a component author can embed **inline compiler configuration** directly in a template, this module acts as the gatekeeper for that configuration surface: it whitelists known option names, coerces static values, enforces domain rules (e.g. valid custom-element tag names, legal namespace values), and raises precise, linked diagnostics for anything invalid.

> **Inline options vs. API options:** This module handles options written *inside the template* (`<svelte:options runes ... />`). Options passed *programmatically* to `compile(...)` are validated by a separate subsystem — see [compiler-core_options_validation](compiler-core_options_validation.md). Per the `AST.Root` contract, inline options **override** the compile-call options.

---

## 2. Module Overview

| Aspect | Detail |
| --- | --- |
| **Location** | `packages/svelte/src/compiler/phases/1-parse/read/options.js` |
| **Core component** | `read_options(node: AST.SvelteOptionsRaw): AST.Root['options']` |
| **Phase** | `1-parse` (template parsing) |
| **Inputs** | Raw `AST.SvelteOptions` element produced by the `element` parser state (attributes as unparsed `AST.Attribute` nodes) |
| **Outputs** | `AST.SvelteOptions` object assigned to `Root.options` |
| **Dependencies** | `constants.js` (`NAMESPACE_SVG`, `NAMESPACE_MATHML`), `errors.js` (option diagnostics) |
| **Consumers** | Parser core (append hook), then Analysis (Phase 2) and Transformation (Phase 3) read `analysis.options` |

### Supported inline options

| Option | Value form | Behavior |
| --- | --- | --- |
| `runes` | boolean | Forces rune-based reactivity mode |
| `tag` | — | **Deprecated** — immediately raises `svelte_options_deprecated_tag` (superseded by `customElement`) |
| `customElement` | string *or* object `{ tag, props, shadow, extend }` | Enables custom-element compilation; deeply validated (see §5) |
| `namespace` | `html` \| `svg` \| `mathml` \| full namespace URI | Normalizes known namespace URLs (`http://www.w3.org/2000/svg`, `http://www.w3.org/1998/Math/MathML`) to the shorthand strings |
| `css` | `injected` | Only the literal `"injected"` is accepted; anything else errors |
| `immutable` | boolean | Immutable data mode |
| `preserveWhitespace` | boolean | Keeps whitespace nodes verbatim |
| `accessors` | boolean | Generates accessor properties |
| *(anything else)* | — | `svelte_options_unknown_attribute`, including a list of legal names |

All values must be **static**: dynamic attribute values (`runes={someVar}`) are rejected with `svelte_options_invalid_attribute`, because compiler configuration must be known at parse time.

---

## 3. Position in the Compiler Pipeline

`read_options` sits at the tail end of the parse phase. The parser's generic `element` state recognizes `<svelte:options>` as a root-only *meta tag*, builds a raw `SvelteOptions` element node (an `AST.BaseElement` with `name: 'svelte:options'`), and collects its attributes using the normal attribute reader. When the node is appended to the root fragment, the parser invokes `read_options` to finalize it.

```mermaid
flowchart LR
    A["compile(source, options)"] --> B["validate-options.js\n(validate compile-call options)"]
    A --> C["Phase 1: parse(template)\nsee compiler-parser_parser-core"]
    C --> D["parser states: fragment / element / text\nsee compiler-parser_parsing-states"]
    D -->|"<svelte:options> detected\n(root-only meta tag)"| E["Raw SvelteOptionsRaw node\n(name, attributes[])"]
    E --> F["read_options(node)\n(this module)"]
    F --> G["AST.SvelteOptions\nattached to Root.options"]
    C --> H["Root: instance / module / css / fragment"]
    G --> I["Phase 2: Analyze\nsee compiler-analyzer"]
    H --> I
    I --> J["Phase 3: Transform\nsee compiler-transformer"]
```

Related parser modules — each documented separately — feed into or consume this module's output:

- **[compiler-parser_parser-core](compiler-parser_parser-core.md)** — the `Parser` class, `parse` entry point, and the append hook that dispatches to `read_options`.
- **[compiler-parser_parsing-states](compiler-parser_parsing-states.md)** — the `element` state that validates `<svelte:options>` placement (root-only, no duplicates) before this module sees the node.
- **[compiler-parser_parsing-utilities](compiler-parser_parsing-utilities.md)** — `fuzzymatch` helpers used by diagnostics elsewhere; the unknown-attribute error here follows the same "did you mean …?" convention.
- **[compiler-parser_js-ts-parsing](compiler-parser_js-ts-parsing.md)** — Acorn-based script parsing; its output occupies the sibling `Root.instance` / `Root.module` slots that `Root.options` complements.

---

## 4. Data Flow: From Raw Element to Root Options

```mermaid
sequenceDiagram
    participant P as Parser (element state)
    participant RO as read_options (this module)
    participant E as errors.js (diagnostics)
    participant R as AST.Root

    P->>P: Match <svelte:options> as root-only meta tag
    P->>P: Collect attributes via read_attribute()
    P->>RO: read_options(SvelteOptionsRaw)
    loop for each attribute
        RO->>RO: Dispatch on attribute.name
        alt known option
            RO->>RO: get_static_value / get_boolean_value
            RO->>RO: coerce & store on component_options
        else invalid
            RO->>E: raise svelte_options_* error
            E-->>P: CompileError (with code + docs URL)
        end
    end
    RO-->>R: AST.SvelteOptions { start, end, attributes, runes?, customElement?, ... }
    Note over R: options override compile() options,<br/>consumed by analyze & transform phases
```

Key invariants of the flow:

1. **Fail-fast**: the first invalid attribute raises a `CompileError` via the central diagnostics module ([compiler-core_diagnostics](compiler-core_diagnostics.md)); parsing aborts with a source-located, code-linked message.
2. **Even a `null`/missing node is representable**: `read_options` always returns a `component_options` skeleton (`start`, `end`, `attributes`), so downstream code can rely on the shape.
3. **Namespace normalization**: full WHATWG namespace URLs (`NAMESPACE_SVG`, `NAMESPACE_MATHML` constants) are folded into the terse `'svg'` / `'mathml'` markers that the rest of the compiler understands.

---

## 5. Validation Logic Deep Dive

### 5.1 Attribute dispatch

`read_options` performs a `switch` over each attribute name. The dispatch flow is:

```mermaid
flowchart TD
    A["attribute"] --> B{"type === 'Attribute'?"}
    B -- "no" --> B1["error: svelte_options_invalid_attribute\n(dynamic values not allowed)"]
    B -- "yes" --> C{"name"}
    C -- "runes / immutable /\npreserveWhitespace / accessors" --> D["get_boolean_value\n(error if not true/false)"]
    C -- "tag" --> E["error: svelte_options_deprecated_tag\n(use customElement instead)"]
    C -- "namespace" --> F{"get_static_value"}
    F -- "SVG/MathML URL or shorthand" --> F1["store 'svg' | 'mathml' | 'html'"]
    F -- "other" --> F2["error: svelte_options_invalid_attribute_value\n('html', 'mathml' or 'svg')"]
    C -- "css" --> G{"value === 'injected'?"}
    G -- "yes" --> G1["store css = 'injected'"]
    G -- "no" --> G2["error: svelte_options_invalid_attribute_value"]
    C -- "customElement" --> H["Deep object validation\n(see §5.2)"]
    C -- "unknown" --> I["error: svelte_options_unknown_attribute\n(lists legal names)"]
```

The two value-extraction helpers power all checks:

- **`get_static_value(attribute)`** — returns the value only when it is a single `Text` chunk or a `Literal` expression; returns `null` for dynamic or multi-chunk values. This is the "staticness" enforcement point.
- **`get_boolean_value(attribute)`** — wraps `get_static_value` and raises `svelte_options_invalid_attribute_value` unless the result is a strict boolean.

### 5.2 `customElement` option

The `customElement` option supports both legacy (`customElement="my-element"`) and modern (`customElement={{ ... }}`) forms and is validated recursively:

```mermaid
flowchart TD
    A["customElement attribute"] --> B{"value form"}
    B -- "true / missing value" --> C["error: svelte_options_invalid_customelement"]
    B -- "Text chunk (string)" --> T["validate_tag()"]
    B -- "ObjectExpression" --> O["iterate properties"]
    B -- "null literal (Svelte 4 compat)" --> S["silently ignored\n(legacy: explicit null was required)"]
    B -- "anything else" --> C

    subgraph TagValidation ["validate_tag (WHATWG rules)"]
        T --> T1{"matches regex_valid_tag_name?\n(lowercase, contains hyphen)"}
        T1 -- "no" --> T2["error: svelte_options_invalid_tagname"]
        T1 -- "yes" --> T3{"in reserved names?\n(annotation-xml, font-face, …)"}
        T3 -- "yes" --> T4["error: svelte_options_invalid_tagname\n(reserved)"]
        T3 -- "no" --> T5["ce.tag = value"]
    end

    O --> P1{"each property is\nnon-computed Identifier key?"}
    P1 -- "no" --> P2["error: svelte_options_invalid_customelement"]
    P1 -- "yes" --> P3{"key"}
    P3 -- "tag" --> P4["validate_tag()"]
    P3 -- "props" --> P5["per-prop validation:\ntype ∈ String/Number/Boolean/Array/Object,\nreflect: boolean,\nattribute: string"]
    P3 -- "shadow" --> P6{"'open' | 'none'?"}
    P6 -- "no" --> P7["error: svelte_options_invalid_customelement_shadow"]
    P3 -- "extend" --> P8["stored verbatim\n(AST expression)"]
    P5 -- "invalid" --> P9["error: svelte_options_invalid_customelement_props"]
```

The resulting object is stored as `component_options.customElement` and later drives the custom-element generator in the transform phase (see [compiler-transformer](compiler-transformer.md)).

### 5.3 Custom-element tag-name grammar

Tag validation follows the [WHATWG custom-elements spec](https://html.spec.whatwg.org/multipage/custom-elements.html#valid-custom-element-name): the name must start with a lowercase ASCII letter, contain at least one hyphen, and consist of valid Unicode name characters. A dedicated character class (`tag_name_char`) plus the reserved-names list (`annotation-xml`, `color-profile`, `font-face*`, `missing-glyph`) implement this without external dependencies.

---

## 6. Error Surface

All diagnostics raised by this module come from the compiler-wide catalog ([compiler-core_diagnostics](compiler-core_diagnostics.md)), which guarantees consistent `{code, message, start, end}` `CompileError` objects with documentation links:

| Error code | Trigger |
| --- | --- |
| `svelte_options_invalid_attribute` | Non-static attribute (e.g. `{...spread}` or directive) |
| `svelte_options_unknown_attribute` | Attribute outside the whitelist |
| `svelte_options_deprecated_tag` | Legacy `<svelte:options tag="...">` usage |
| `svelte_options_invalid_attribute_value` | Bad value for boolean / `css` / `namespace` options |
| `svelte_options_invalid_customelement` | Malformed `customElement` value |
| `svelte_options_invalid_customelement_props` | Malformed entry in `customElement.props` |
| `svelte_options_invalid_customelement_shadow` | `shadow` not `open`/`none` |
| `svelte_options_invalid_tagname` | Tag fails WHATWG grammar or is reserved |

Complementary compile-time diagnostics about removed/renamed *API* options (`options_removed_enable_sourcemap`, `options_removed_hydratable`, `options_removed_loop_guard_timeout`, `options_renamed_ssr_dom`) live in the warnings catalog and are emitted by [compiler-core_options_validation](compiler-core_options_validation.md), not by this module.

---

## 7. Relationship to the Broader System

```mermaid
flowchart TB
    subgraph Parse ["Phase 1 — Parse"]
        direction LR
        PC["parser-core"] --> PS["parsing-states"]
        PS --> OR["options-reading (this module)"]
        JTP["js-ts-parsing\n(acorn)"] -.-> PC
        PU["parsing-utilities\n(fuzzymatch, html entities)"] -.-> PS
    end
    subgraph Core ["compiler-core"]
        VAL["options-validation\n(validate-options.js)"]
        DIAG["diagnostics\n(errors.js / warnings.js)"]
        TYPES["type-definitions\n(SvelteOptionsRaw, Root, SvelteOptions)"]
        BUILD["ast-builders"]
        STATE["compile-state"]
        PUB["public-api (compile/compileModule)"]
    end
    OR --> DIAG
    OR --> TYPES
    VAL --> DIAG
    OR -->|Root.options| AZ["compiler-analyzer"]
    VAL -->|CompileOptions| AZ
    AZ --> TF["compiler-transformer"]
    PUB --> PC
    PUB --> VAL
```

- **Upstream (producer):** the element parsing state creates the `SvelteOptionsRaw` node and enforces placement rules (`root_only_meta_tags`, duplicate detection) *before* deferring semantic interpretation of attributes to this module — a clean separation of *syntactic* vs. *semantic* validation.
- **Downstream (consumers):** `analysis.options` is consulted during analysis (e.g. rune detection when `runes: true` is forced) and transformation (custom-element wrapper generation, namespace-aware element creation, CSS injection mode).
- **Sibling validator:** `validate-options.js` performs the mirror-image job for the `compile()` JavaScript API using composable validator combinators (`boolean`, `string`, `list`, `object`, `deprecate`, `removed`). The two systems together form the complete options surface; note that unknown inline options are a hard error here, while the API validator uses the shared error catalog's `options_unrecognised`.

---

## 8. Design Notes for Maintainers

1. **Staticness is non-negotiable.** Compiler options must resolve to literals at parse time; this module is deliberately strict (`get_static_value` returns `null` for anything dynamic) so later phases never deal with indirection.
2. **Backwards compatibility pocket.** `customElement={null}` is silently accepted: Svelte 4 required an explicit `null` to suppress a warning, and Svelte 5 tolerates it to avoid breaking existing code.
3. **Errors are data, not exceptions to format later.** Every failure delegates to `errors.js`, keeping message text, error codes, and doc URLs centralized — extend that file, not this one, when adding new diagnostics.
4. **Adding a new inline option** requires: (a) a `case` in the dispatch switch, (b) a `SvelteOptions` field in [compiler-core_type_definitions](compiler-core_type_definitions.md), (c) documentation, and — if it can also be an API option — a matching combinator in `validate-options.js`.
5. **Loose-mode interplay.** In editor "loose" parsing (used by language tools), incomplete attributes may reach the parser; the element state filters those before this module runs, so `read_options` can assume well-formed `AST.Attribute` nodes and need not handle partial input.
