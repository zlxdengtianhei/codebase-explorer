# Compiler Analyzer — Visitors (`compiler-analyzer_visitors`)

## 1. Introduction

The **`compiler-analyzer_visitors`** module implements the node-type–specific analysis logic of **Phase 2 (Analyze)** of the Svelte compiler. It lives in:

```
packages/svelte/src/compiler/phases/2-analyze/visitors/
```

Every file in the module exports a single **visitor function named after the AST node type it analyzes** (e.g. `AwaitBlock.js → AwaitBlock`, `StyleDirective.js → StyleDirective`). During analysis, the analyzer's tree walker (`walk`) dispatches each AST node to its matching visitor, which:

1. **Validates** placement, syntax, and mode-specific (runes vs. legacy) rules — reporting diagnostics through the compiler-wide error/warning registries.
2. **Decorates the AST with `metadata`** (`Fragment.metadata.dynamic`, `node.metadata.expression`, `EachBlock.metadata.keyed`, …) that the downstream [compiler-transformer](compiler-transformer.md) phase depends on.
3. **Enriches component-level analysis state** (`analysis.exports`, `analysis.needs_context`, binding kinds such as `state`/`derived`, slot bookkeeping, await tracking).
4. **Continues traversal** via `context.next()` / `context.visit(child)` so nested nodes are analyzed with the correct scope and expression context.

This module is the "rules engine" of the analyzer: the surrounding orchestration (scope creation, store-subscription synthesis, runes-mode inference, CSS post-processing) is described in [compiler-analyzer.md](compiler-analyzer.md), while lexical scoping itself is covered in [compiler-analyzer_scope.md](compiler-analyzer_scope.md).

---

## 2. Role in the Compiler Pipeline

The Svelte compiler executes three phases (see [Compiler_Pipeline___Language_Toolchain.md](Compiler_Pipeline___Language_Toolchain.md)):

- **Phase 1 — Parse** ([compiler-parser](compiler-parser.md)): produces the Svelte AST (template + `<script>` ESTree nodes + CSS).
- **Phase 2 — Analyze** (this module's parent): walks that AST, validates it, resolves bindings, and computes metadata.
- **Phase 3 — Transform** ([compiler-transformer](compiler-transformer.md)): turns the annotated AST into client JS, server JS, and CSS.

```mermaid
flowchart LR
    subgraph P1["Phase 1 · Parse — compiler-parser"]
        AST["AST (template, module, instance, css)"]
    end

    subgraph P2["Phase 2 · Analyze — compiler-analyzer"]
        AI["analyze_component()<br/>(2-analyze/index.js)"]
        SC["Scopes &amp; Bindings<br/>[compiler-analyzer_scope]"]
        VIS["visitors/ ← this module<br/>(23 node-type visitors)"]
        CSS["css-analyze.js<br/>[compiler-analyzer_css_analysis]"]
    end

    subgraph P3["Phase 3 · Transform — compiler-transformer"]
        T["client / server / css transforms"]
    end

    AST --> AI
    AI --> SC
    SC --> VIS
    VIS -->|"metadata + analysis"| CSS
    VIS -->|"annotated AST + ComponentAnalysis"| T
    CSS --> T
```

The visitors are pure analysis functions — they never emit code. Everything they compute is either a **diagnostic** (error/warning) or **metadata consumed by the transformer**.

---

## 3. Architecture Overview

### 3.1 Dispatch Mechanism

`analyze_component()` (in `2-analyze/index.js`) builds a `ComponentAnalysis` object, then walks the **module `<script>`**, **instance `<script>`**, and **template fragment** with a shared visitors map. For each node the walker looks up a visitor by `node.type`; if none exists, generic handlers from `phases/scope.js` (see [compiler-analyzer_scope.md](compiler-analyzer_scope.md)) create/restore scopes and keep walking.

```mermaid
flowchart TB
    A["analyze_component(root, source, options)"] --> B["build ScopeRoot · module/instance scopes"]
    B --> C["infer runes mode (options, $-refs, await usage)"]
    C --> D{"walk each AST:<br/>module → instance → template"}
    D --> E["walker resolves scope via<br/>set_scope() (scope.js)"]
    E --> F{"visitor exists for node.type?"}
    F -->|"yes"| G["visitor(node, context)"]
    F -->|"no"| H["generic scope handler<br/>[compiler-analyzer_scope]"]
    G --> I["1 · validate → errors.js / warnings.js<br/>2 · decorate node.metadata<br/>3 · update context.state"]
    H --> I
    I --> J["context.next(state?) or<br/>context.visit(child, state?)"]
    J --> E
    G --> K["post-walk: CSS analysis, unused-selector<br/>pruning, snippet/reactive-statement checks"]
```

### 3.2 The Visitor Contract

Every visitor has the signature:

```js
/**
 * @param {AST.Node | estree.Node} node  — the node being analyzed
 * @param {Context} context              — traversal + state handle
 */
export function Visitor(node, context) { /* ... */ }
```

The `Context` object exposes the traversal primitives used throughout this module:

| Member | Purpose | Example from this module |
|---|---|---|
| `context.state` | Shared `AnalysisState` (see below) | `context.state.analysis.runes` |
| `context.path` | Ancestor chain (root → current node) | `context.path.at(-1)` in `ConstTag`, `mark_subtree_dynamic(context.path)` |
| `context.next(state?)` | Continue traversal into children, optionally overriding state | `context.next({...context.state, expression: node.metadata.expression})` in `ClassDirective` |
| `context.visit(node, state?)` | Visit a specific node explicitly | `context.visit(node.expression, ...)` in `AwaitBlock` |

Key fields of `context.state` referenced by the visitors:

| Field | Meaning | Consumers |
|---|---|---|
| `analysis` | The `ComponentAnalysis` accumulator: `runes`, `exports`, `elements`, `needs_context`, `component_slots`, CSS info, … | Nearly all visitors |
| `scope` | Current lexical `Scope`; `scope.get(name)` resolves a `Binding` | `StyleDirective`, `EachBlock`, `ExportNamedDeclaration`, `TaggedTemplateExpression` |
| `ast_type` | `'module' \| 'instance' \| 'template'` | `AwaitExpression` (top-level await detection), `ExportSpecifier`, `ExportNamedDeclaration` |
| `expression` | Active `ExpressionMetadata` accumulator (`has_state` / `has_call` / `has_await`) | `AwaitExpression`, `TaggedTemplateExpression`, `StyleDirective` |
| `fragment` | Root template fragment (for fragment-level await marking) | `AwaitExpression` |
| `function_depth` | Current function nesting level | `AwaitExpression`, `NewExpression` |
| `options` | Compile options (e.g. `options.experimental.async`) | `AwaitExpression` |

### 3.3 Visitor Taxonomy

The 23 visitors fall into five functional families:

```mermaid
mindmap
  root(("2-analyze/visitors"))
    Template control blocks
      AwaitBlock
      EachBlock
      IfBlock
      KeyBlock
    Special elements
      SvelteBody
      SvelteBoundary
      SvelteDocument
      SvelteFragment
      SvelteHead
      SvelteWindow
      TitleElement
    Directives &amp; template tags
      ClassDirective
      StyleDirective
      ConstTag
      DebugTag
      HtmlTag
    Script exports
      ExportDefaultDeclaration
      ExportNamedDeclaration
      ExportSpecifier
    JavaScript expressions
      AwaitExpression
      NewExpression
      TaggedTemplateExpression
      TemplateElement
```

---

## 4. Visitor Catalog

### 4.1 Template Control Blocks

These visitors validate `{#...}` block structure and drive the compiler's **dynamic-fragment** and **reactivity** bookkeeping.

| Visitor | Validations | Metadata / state effects |
|---|---|---|
| `AwaitBlock` | `pending`/`then`/`catch` sub-blocks non-empty; runes-mode opening tag starts with `#`; rejects stray `:` inside `:then` / `:catch` destructuring by inspecting the source slice before the value identifiers | `mark_subtree_dynamic`; visits `expression` with its `metadata.expression`; then `pending`, `then`, `catch` |
| `EachBlock` | Opening tag `#`; body & `fallback` non-empty; rejects `{#each x as $state}` (invalid rune placement); computes `metadata.keyed` (keyed unless key is exactly the index reference) | Visits `expression` in the **parent scope**; legacy mode: walks transitive `legacy_reactive` dependencies and promotes mutated `normal` bindings to `state` so they become invalidatable sources; `mark_subtree_dynamic` |
| `IfBlock` | `consequent` & `alternate` non-empty; opening tag `#` (or `:` for `{:else if}`) in runes mode | `mark_subtree_dynamic`; visits `test` with `metadata.expression`, then branches |
| `KeyBlock` | Fragment non-empty; opening tag `#` in runes mode | `mark_subtree_dynamic`; visits `expression` + `fragment` |

**Shared helper — `mark_subtree_dynamic(path)`** (`visitors/shared/fragment.js`): walks the ancestor path and sets `Fragment.metadata.dynamic = true` up to the nearest already-dynamic fragment. This is the signal the transformer uses to decide between static template cloning and dynamic per-instance rendering.

### 4.2 Special Elements (`svelte:*`, `<title>`)

These visitors enforce strict attribute/child contracts for meta-elements. `SvelteBody`, `SvelteDocument`, and `SvelteWindow` share the same shape via `disallow_children` (`shared/special-element.js`), which raises `svelte_meta_invalid_content` for any non-empty fragment.

| Visitor | Rules enforced |
|---|---|
| `SvelteBody` | No children; only event-handler attributes allowed (no `SpreadAttribute`, no plain attributes) → `svelte_body_illegal_attribute` |
| `SvelteBoundary` | Only `onerror`, `failed`, `pending` attributes; each must be exactly one `ExpressionTag` value → `svelte_boundary_invalid_attribute(_value)` |
| `SvelteDocument` | No children; only event attributes → `illegal_element_attribute` |
| `SvelteFragment` | Must be a **direct child** of `Component`/`SvelteComponent` → `svelte_fragment_invalid_placement`; only `slot=` (validated via `validate_slot_attribute`) and `let:` directives allowed; resets `parent_element` state for children |
| `SvelteHead` | No attributes at all → `svelte_head_illegal_attribute`; `mark_subtree_dynamic` |
| `SvelteWindow` | No children; only event attributes → `illegal_element_attribute` |
| `TitleElement` | No attributes → `title_illegal_attribute`; content limited to `Text` / `ExpressionTag` → `title_invalid_content` |

`validate_slot_attribute` (`shared/attribute.js`) — used by `SvelteFragment` — locates the slot **owner** (component, `svelte:component`, `svelte:self`, `svelte:element`, or custom element), rejects misplaced/duplicate slot names, and detects conflicting implicit/explicit default-slot content.

### 4.3 Directives & Template Tags

| Visitor | Behavior |
|---|---|
| `ClassDirective` | `mark_subtree_dynamic`; propagates `node.metadata.expression` downward so children know the class value's reactivity. |
| `StyleDirective` | Rejects invalid modifiers (only `important` is allowed) → `style_directive_invalid_modifier`; `mark_subtree_dynamic`; for shorthand (`style:color`) promotes the referenced binding to reactive by setting `has_state`; otherwise aggregates `has_state` / `has_call` / `has_await` from all `ExpressionTag` chunks of the value. |
| `ConstTag` | Runes-mode `@` opening-tag check; **placement validation**: must sit in a `Fragment` whose parent is one of `IfBlock`, `SvelteFragment`, `Component`, `SvelteComponent`, `EachBlock`, `AwaitBlock`, `SnippetBlock`, `SvelteBoundary`, `KeyBlock`, or a `(svelte:)element` carrying a `slot` attribute — otherwise `const_tag_invalid_placement`. Visits declaration id + init with the tag's `metadata.expression`. |
| `DebugTag` | Runes-mode `@` opening-tag check; otherwise falls through. |
| `HtmlTag` | Runes-mode `@` opening-tag check; `mark_subtree_dynamic` (raw HTML can repair otherwise-invalid markup, so the surrounding fragment must render dynamically). |

### 4.4 Script Exports

These visitors implement the component I/O contract — the difference between **component props/exports** (instance script) and **module exports** (`<script context="module">` / `.svelte.js` files).

```mermaid
flowchart TB
    subgraph EXP["Export visitors"]
        EDD["ExportDefaultDeclaration"]
        END_["ExportNamedDeclaration"]
        ES["ExportSpecifier"]
    end

    EDD -->|"in .svelte.js module"| E1["error: module_illegal_default_export"]
    EDD -->|"in component"| E2["validate_export: no re-exporting<br/>instance bindings as default"]

    END_ --> N1{"where?"}
    N1 -->|"module"| N2["error on `export ... as default`"]
    N1 -->|"instance · runes"| N3["error: legacy_export_invalid<br/>(`export let` forbidden)"]
    N1 -->|"instance · legacy"| N4["bindings become props<br/>(handled by analyze_component)"]

    END_ --> N5["binding-kind checks per declarator:<br/>derived_invalid_export<br/>state_invalid_export (reassigned $state)"]
    END_ --> N6["runes: collect analysis.exports<br/>(functions, classes, const identifiers)"]

    ES -->|"instance · runes"| S1["record export name/alias in<br/>analysis.exports; binding.reassigned = true"]
    ES -->|"elsewhere"| S2["validate_export"]
```

Notes:

- `ExportNamedDeclaration` records instance exports (`analysis.exports.push({name, alias})`) for functions/classes/consts so the transformer can generate public accessors/exports; it also guards the runes-mode invariants `derived_invalid_export` and `state_invalid_export`.
- `ExportSpecifier` **forces `binding.reassigned = true`** for re-exported instance bindings — re-exporting an instance value implies it may change, which affects reactivity decisions.

### 4.5 JavaScript Expression Visitors

| Visitor | Behavior |
|---|---|
| `AwaitExpression` | Implements **await suspension analysis** (see §6). Marks the active `expression.has_await`; if a `ConstTag` is on the path, also marks `fragment.metadata.has_await`. Detects *suspension points* (top-level await in the instance script, or await inside template expressions) and requires both `runes` mode and `options.experimental.async`, else `experimental_async` / `legacy_await_invalid`. |
| `NewExpression` | Warns `perf_avoid_inline_class` for `new (class {...})()` inside functions (breaks optimizations); sets `analysis.needs_context = true` since instantiated objects may capture component context. |
| `TaggedTemplateExpression` | If the tag expression is not provably pure (`is_pure` helper: literals, pure call chains, non-binding identifiers/member chains), marks `expression.has_call = true` and `has_state = true`. |
| `TemplateElement` | Warns `bidirectional_control_characters` when template-literal text contains bidi control characters (security hygiene against trojan-source obfuscation). |

---

## 5. Shared Visitor Infrastructure

The module delegates repeated logic to `visitors/shared/*`:

| Helper | File | Used by | Summary |
|---|---|---|---|
| `validate_block_not_empty` | `shared/utils.js` | `AwaitBlock`, `EachBlock`, `IfBlock`, `KeyBlock` | Warns `block_empty`; suppresses the warning for whitespace-only fragments still being typed. |
| `validate_opening_tag` | `shared/utils.js` | All block/tag visitors (runes mode) | Ensures the character after `{` is the expected sigil (`#` for blocks, `@` for tags), avoiding "a sea of red" by only flagging the first few characters. |
| `is_pure` | `shared/utils.js` | `TaggedTemplateExpression` | Conservative purity check for identifiers/member/call chains (globals assumed safe; `$effect.tracking` never pure). |
| `validate_export` | `shared/utils.js` | `ExportDefaultDeclaration`, `ExportSpecifier` | Rejects exports of undeclared or instance-scoped bindings in module context. |
| `mark_subtree_dynamic` | `shared/fragment.js` | Blocks, directives, `HtmlTag`, `SvelteHead` | Sets `Fragment.metadata.dynamic` along the ancestor path. |
| `disallow_children` | `shared/special-element.js` | `SvelteBody`, `SvelteDocument`, `SvelteWindow` | Errors `svelte_meta_invalid_content` on any child content. |
| `validate_slot_attribute` | `shared/attribute.js` | `SvelteFragment` (and other slot-site visitors in the analyzer) | Slot ownership, duplicate-slot and default-content-conflict detection. |

Additionally, general AST utilities from `compiler/utils/ast.js` (part of [compiler-core_ast_builders](compiler-core_ast_builders.md)) are used: `extract_identifiers` (pattern destructuring → identifiers), `get_attribute_chunks`, `is_event_attribute`.

All diagnostics are raised through the central registries `compiler/errors.js` and `compiler/warnings.js` (see [compiler-core_diagnostics.md](compiler-core_diagnostics.md)); `svelte-ignore` suppression for these registries is handled by `push_ignore`/`pop_ignore` in [compiler-core_compile_state.md](compiler-core_compile_state.md).

---

## 6. Behavioral Deep Dives

### 6.1 Reactivity metadata propagation (`has_state` / `has_call` / `has_await`)

Expression metadata flows **bottom-up**: children visited with `context.next({ ...state, expression: childMeta })` populate their own metadata, and parents aggregate it:

```mermaid
flowchart BT
    STY["StyleDirective<br/>aggregates chunks:<br/>has_state ||= / has_call ||= / has_await ||="]
    TE["TemplateElement<br/>(bidi-char warning only)"]
    TTE["TaggedTemplateExpression<br/>impure tag → has_call, has_state"]
    AE["AwaitExpression<br/>→ has_await (+ fragment-level)"]
    EM["ExpressionMetadata<br/>has_state · has_call · has_await"]
    T["Transformer decides:<br/>expression closure vs. inline,<br/>template-dynamic vs. static"]

    STY --> EM
    TTE --> EM
    AE --> EM
    EM --> T
```

### 6.2 Await suspension analysis (`AwaitExpression`)

```mermaid
flowchart TB
    A["AwaitExpression node"] --> B{"state.expression set?<br/>(inside analyzed template expression)"}
    B -->|"yes"| C["expression.has_await = true<br/>ConstTag in path → fragment.metadata.has_await"]
    B --> D{"suspend =<br/>ast_type === 'instance' AND<br/>function_depth === 1"}
    C --> D2["suspend = true"]
    D --> D2
    D2 --> E{"options.experimental.async?"}
    E -->|"no"| F["error: experimental_async"]
    D2 --> G{"analysis.runes?"}
    G -->|"no"| H["error: legacy_await_invalid"]
    E -->|"yes & runes"| I["context.next()<br/>(await is legal here)"]
```

The resulting `has_await` flags are what let the transformer introduce `$.async` boundaries / `SvelteBoundary`-compatible suspension, and what feeds `analysis.async_deriveds` handled at the [compiler-analyzer](compiler-analyzer.md) level.

### 6.3 Legacy-mode mutation repair (`EachBlock`)

In legacy (non-runes) mode, reassigning an each-item (`{#each list as item}` + `item = …`) must invalidate the *iterated expression*. The visitor:

1. Detects mutation of the context identifier via `scope.get(...).mutated`.
2. Collects the expression's bindings plus their **transitive** `legacy_reactive` dependencies into `node.metadata.transitive_deps`.
3. Promotes `normal` bindings declared with `const`/`let`/`var` to `kind = 'state'` so the transformer creates mutable sources and invalidation edges.

This mirrors the store-subscription synthesis and `export let` prop promotion performed by `analyze_component` — see [compiler-analyzer.md](compiler-analyzer.md).

### 6.4 Runes-mode syntax gates

`IfBlock`, `EachBlock`, `KeyBlock`, `AwaitBlock`, `ConstTag`, `DebugTag`, `HtmlTag` all call `validate_opening_tag(node, state, '#'|'@')` **only when `analysis.runes`**. In runes mode, the compiler enforces canonical sigils, catching typos like `{ if }` early and keeping legacy-mode leniency intact.

---

## 7. Metadata & Analysis Contracts with the Transformer

Everything the visitors compute is consumed downstream by [compiler-transformer](compiler-transformer.md):

| Producer (this module) | Output | Transformer consumer |
|---|---|---|
| Block/tag visitors via `mark_subtree_dynamic` | `Fragment.metadata.dynamic` | Chooses static template cloning vs. dynamic effect-driven rendering |
| `AwaitExpression`, `TaggedTemplateExpression`, `StyleDirective`, block `metadata.expression` | `ExpressionMetadata { has_state, has_call, has_await }` | Expression inlining vs. closure creation; async suspension setup |
| `EachBlock` | `metadata.keyed`, `metadata.transitive_deps` | Each-block reconciliation strategy & legacy invalidation wiring |
| `ExportNamedDeclaration` / `ExportSpecifier` | `analysis.exports[]`, `binding.reassigned` | Generated component exports/accessors |
| `NewExpression` | `analysis.needs_context` | Whether `$.getContext`-preserving wrappers must be emitted |
| `StyleDirective` / `ClassDirective` (with analyzer post-pass) | attribute/value reactivity flags, scoped-CSS class injection prep | `set_class`/`set_style` effect generation (with `append_styles` from the client DOM renderer) |

---

## 8. End-to-End Analysis Flow (Sequence Example)

```mermaid
sequenceDiagram
    autonumber
    participant IDX as analyze_component
    participant W as walk()
    participant AB as AwaitBlock
    participant U as shared/utils
    participant F as shared/fragment
    participant SC as Scope layer<br/>(compiler-analyzer_scope)
    participant CSS as css-analyze<br/>(compiler-analyzer_css_analysis)

    IDX->>W: walk(instance/template ast, state, visitors)
    W->>SC: set_scope / scope.child() for block nodes
    W->>AB: dispatch by node.type === 'AwaitBlock'
    AB->>U: validate_block_not_empty(pending/then/catch)
    AB->>U: validate_opening_tag(node, state, '#') [runes]
    AB->>F: mark_subtree_dynamic(context.path)
    AB->>SC: visit(expression) → bindings resolved in scope
    AB->>W: visit(pending) · visit(then) · visit(catch)
    W-->>IDX: traversal complete
    IDX->>CSS: analyze_css(analysis.css.ast) + prune + warn_unused
    IDX-->>IDX: return ComponentAnalysis (annotated AST + metadata)
```

---

## 9. Integration Map

| Related module | Relationship |
|---|---|
| [compiler-parser.md](compiler-parser.md) | Supplies the AST node types (`AST.*`, plus ESTree nodes) that visitors dispatch on. |
| [compiler-core.md](compiler-core.md) | Parent project layer: `types/` definitions (`AST.Root`, `CompileResult`), public `compile` entry that drives `analyze`. |
| [compiler-core_diagnostics.md](compiler-core_diagnostics.md) | `errors.js` / `warnings.js` registries visitors raise diagnostics through; `CompileError`/code-frame rendering. |
| [compiler-core_compile_state.md](compiler-core_compile_state.md) | `push_ignore` / `pop_ignore` implement `svelte-ignore` suppression around diagnostics emitted here. |
| [compiler-core_ast_builders.md](compiler-core_ast_builders.md) | `utils/ast.js` helpers (`extract_identifiers`, `get_attribute_chunks`, `is_event_attribute`) used by visitors. |
| [compiler-analyzer.md](compiler-analyzer.md) | Orchestrates this module: builds `ComponentAnalysis`, infers runes mode, runs post-walk passes (CSS analysis, slot/render-tag conflict checks). |
| [compiler-analyzer_scope.md](compiler-analyzer_scope.md) | Provides `Scope`/`Binding` resolution and the default `set_scope`/child-scope handlers the walker applies between visitors. |
| [compiler-analyzer_css_analysis.md](compiler-analyzer_css_analysis.md) | Sibling CSS pass (`is_in_global_block`, `is_unscoped`, …) executed after the visitor walk; visitors record `analysis.elements` it consumes. |
| [compiler-transformer.md](compiler-transformer.md) | Primary consumer of the metadata and `analysis` produced here (client/server/css transforms, `visit` in `client/utils.js`). |

---

## 10. Extending the Module (Adding a Visitor)

To support a new AST node type or tighten existing rules:

1. **Define/confirm the node type** in `compiler/types/template.d.ts` (template nodes) or rely on an ESTree type — see [compiler-core_type_definitions.md](compiler-core_type_definitions.md).
2. **Create `visitors/<NodeType>.js`** exporting a single function with the node-type name:
   ```js
   /** @import { AST } from '#compiler' */
   /** @import { Context } from '../types' */
   export function NodeType(node, context) {
     // 1) validate → import * as e / * as w from '../../../errors|warnings.js'
     // 2) decorate → node.metadata.*
     // 3) traverse → context.next(...) / context.visit(child, ...)
   }
   ```
3. **Register it** in the visitors map in `2-analyze/index.js` (the walker dispatches purely by `node.type`).
4. **Reuse shared helpers** (`validate_opening_tag`, `mark_subtree_dynamic`, `disallow_children`, …) instead of duplicating checks.
5. **Add messages** to the `compile-errors` / `compile-warnings` templates (see [message_code_generation_templates.md](message_code_generation_templates.md)) so codes stay generated and centralized.
6. **Mirror client/server behavior** if the node affects runtime output — coordinate with the corresponding visitors under `3-transform/client/visitors/` and `3-transform/server/visitors/` in [compiler-transformer.md](compiler-transformer.md).

> **Convention reminder:** a visitor that only validates may end with `context.next()`; one that passes expression context must spread `{ ...context.state, expression: node.metadata.expression }` so child expression metadata aggregates correctly.

---

## 11. Summary

`compiler-analyzer_visitors` is the rulebook of Svelte's analysis phase:

- **23 focused visitors**, one per AST node type, grouped into *control blocks*, *special elements*, *directives/tags*, *script exports*, and *JS expressions*.
- They guarantee **mode-correct syntax** (runes sigils, `export let` bans, await suspension rules), **structural integrity** (block emptiness, special-element contracts, slot placement), and **security/perf hygiene** (bidi characters, inline classes, impure tagged templates).
- Their lasting output is **metadata** (`dynamic` fragments, expression reactivity, keyed-each strategy, export lists, binding-kind promotions) — the exact contract the [compiler-transformer](compiler-transformer.md) translates into client, server, and CSS output.
