# internal-shared-utils

> **Module path:** `packages/svelte/src/internal/shared/` · **Parent module:** [Server-Side Rendering & Cross-Target Runtime Services](server-side-rendering-cross-target-runtime-services.md)

## 1. Overview

`internal-shared-utils` is the **isomorphic support layer** of the Svelte runtime. Everything in `packages/svelte/src/internal/shared/` is deliberately environment-agnostic: it is imported by both the **client runtime** (`internal/client/*`) and the **server runtime** (`internal/server/*`), and by the code that the Svelte compiler emits into every compiled component. Keeping these primitives in one shared location guarantees that both render targets behave identically and that no client- or server-only dependency leaks into the other bundle.

The module provides four concerns:

| Concern | File | What it gives the rest of the runtime |
|---|---|---|
| Foundational JS helpers | `utils.js` | `noop`, `run`, `run_all`, `deferred`, `fallback`, `is_promise`, `is_function`, `to_array`, plus **cached references to globals** (`Array.isArray`, `Object.keys`, …) |
| Runtime validation guards | `validate.js` | `validate_void_dynamic_element`, `validate_dynamic_element_tag`, `validate_store`, `prevent_snippet_stringification` |
| Diagnostics catalog (errors) | `errors.js` | Generated, DEV-aware error throwers — `invalid_default_snippet`, `await_outside_boundary`, `lifecycle_outside_component`, `snippet_without_render_tag`, `store_invalid_shape`, `svelte_element_invalid_this_value`, … |
| Snapshot conformance tests | `clone.test.ts` | Behavioral contract for `$state.snapshot` (`clone.js`), including the `capture_warnings` test helper |

Its sibling file `warnings.js` (the warning counterpart to `errors.js`) is also part of this directory and is consumed by `validate.js` and `clone.js`; it is covered alongside the diagnostics catalog in the sub-module documentation.

### Design principles

1. **Zero-friction, tree-shakeable micro-helpers** — every export is a tiny standalone function so bundlers can drop what a given compiled component never uses (see the [treeshakeability checker](engineering-tooling-benchmarks-verification-playground.md)).
2. **Dual DEV/PROD diagnostics** — error and warning helpers gate rich, actionable messages (code name, explanation, `https://svelte.dev/e/...` link) behind the `DEV` flag from `esm-env`; production builds emit only the documentation URL to minimize payload size.
3. **Generated code** — `errors.js` and `warnings.js` are produced by `scripts/process-messages` from the templates documented in [message code generation templates](compiler-pipeline-language-toolchain.md). They must never be edited by hand.
4. **Monkey-patch immunity** — `utils.js` captures references to `Array`/`Object` prototype methods and constructors once at module load, so popular browser extensions or polyfills that patch globals cannot de-optimize the runtime.

## 2. Architecture

```mermaid
flowchart TD
    subgraph SHARED["internal/shared (this module)"]
        U["utils.js<br/>noop · run · run_all · deferred<br/>fallback · is_promise · to_array<br/>cached global refs"]
        V["validate.js<br/>validate_void_dynamic_element<br/>validate_dynamic_element_tag<br/>validate_store · prevent_snippet_stringification"]
        E["errors.js (generated)<br/>invalid_default_snippet · await_outside_boundary<br/>lifecycle_outside_component · …"]
        W["warnings.js (generated)<br/>dynamic_void_element_content<br/>state_snapshot_uncloneable · …"]
        C["clone.js<br/>snapshot ($state.snapshot)"]
        T["clone.test.ts<br/>capture_warnings + conformance suite"]
    end

    V -->|"throws errors"| E
    V -->|"emits warnings"| W
    V -->|"is_void(tag)"| CU["src/utils.js (compiler-root utils)<br/>VOID_ELEMENT_NAMES"]
    C -->|"uncloneable state warning"| W
    T -->|"tests"| C
    T -->|"creates proxied state"| P["internal/client/proxy.js<br/>(client reactivity engine)"]

    subgraph CONSUMERS["Consumers"]
        SR["server-runtime<br/>internal/server/*"]
        CR["client runtime<br/>internal/client/*"]
        GEN["compiler-generated<br/>component code"]
    end

    U -.->|imported by| SR
    U -.->|imported by| CR
    U -.->|imported by| GEN
    V -.->|guards used by| GEN
    E -.->|thrown by| SR
    E -.->|thrown by| CR
```

### Dependency direction

The module sits at the **bottom of the internal runtime dependency graph**:

- It depends **only** on `esm-env` (`DEV` flag), the compiler-root `src/utils.js` (`is_void`, shared with the [compiler pipeline](compiler-pipeline-language-toolchain.md)), and — in tests only — the client `proxy`.
- Both runtimes and generated code depend **on it**. This one-way flow is what keeps the package installable in non-DOM environments (SSR, edge).

```mermaid
flowchart LR
    A["Public API<br/>(mount/hydrate, $state.snapshot, runes)"] --> B["Client Runtime Engine<br/>(reactivity + DOM)"]
    A --> C["Server Runtime<br/>(SSR render pipeline)"]
    B --> D["internal-shared-utils"]
    C --> D
    E["Compiler-generated code"] --> D
    D --> F["esm-env / compiler-root utils"]
```

## 3. Sub-modules

Detailed documentation lives in these generated files (flat directory, sibling to this overview):

| Sub-module | Documentation file | Source | Summary |
|---|---|---|---|
| Core Utilities | [internal-shared-utils_core-utilities.md](internal-shared-utils_core-utilities.md) | `utils.js` | The runtime's JavaScript foundation: promise/deferred plumbing, `noop`/`run`/`run_all`, `fallback` for optional props, and `to_array` — the destructuring-safe iterable converter that backs `let [a, b] = $derived(...)` |
| Runtime Validation Guards | [internal-shared-utils_validation-guards.md](internal-shared-utils_validation-guards.md) | `validate.js` | Cheap DEV-time guards for `<svelte:element this={...}>`, store contracts, and snippet stringification, wired into the generated diagnostics catalogs |
| Diagnostics Catalog | [internal-shared-utils_error-messages.md](internal-shared-utils_error-messages.md) | `errors.js` (+ sibling `warnings.js`) | Generated DEV/PROD dual-mode error throwers and warnings, produced by `scripts/process-messages` |
| Snapshot Conformance Tests | [internal-shared-utils_snapshot-conformance-tests.md](internal-shared-utils_snapshot-conformance-tests.md) | `clone.test.ts` | The behavioral contract of `$state.snapshot`: primitives, cycles, proxies, classes, `toJSON`, and uncloneable-value warning paths (via `capture_warnings`) |

## 4. Key data flows

### 4.1 Runtime validation → user-facing diagnostic

```mermaid
sequenceDiagram
    participant G as Compiler-generated code
    participant V as validate.js
    participant E as errors.js / warnings.js
    participant U as console (user)

    G->>V: validate_void_dynamic_element(tag_fn)
    V->>V: tag = tag_fn() · is_void(tag) ?
    alt void element with children
        V->>E: w.dynamic_void_element_content(tag)
        E->>U: DEV → styled message + svelte.dev link<br/>PROD → bare URL
    else tag is not a string
        V->>E: e.svelte_element_invalid_this_value()
        E->>U: throws Svelte error (DEV) / URL-only Error (PROD)
    else valid
        V-->>G: return (no-op)
    end
```

### 4.2 `$state.snapshot` warning path (exercised by `clone.test.ts`)

```mermaid
sequenceDiagram
    participant Dev as Developer code ($state.snapshot)
    participant C as clone.js::snapshot
    participant W as warnings.js
    participant T as clone.test.ts

    Dev->>C: snapshot(value)
    C->>C: clone(value, Map(), '', paths[])
    alt uncloneable paths found (DEV)
        C->>W: state_snapshot_uncloneable(paths)
        W->>W: console.warn("%c[svelte] …", bold, normal)
        T->>T: capture_warnings() captured the output
    end
    C-->>Dev: plain (non-reactive) deep copy
```

## 5. How this module fits into the system

- **[Server-side rendering & cross-target runtime services](server-side-rendering-cross-target-runtime-services.md)** — parent module. The [server-runtime](server-runtime.md) render pipeline uses `utils.js` helpers (`run`, `to_array`, `fallback`) and throws this module's errors; the [context API](context-api.md) relies on the same `lifecycle_outside_component` diagnostics.
- **[Client Runtime Engine](client-runtime-engine-reactivity-dom-rendering.md)** — the reactivity engine consumes the cached global references and `deferred`/`run_all` for batching; `clone.test.ts` validates `snapshot()` against the reactivity engine's `proxy()` output.
- **[Compiler pipeline](compiler-pipeline-language-toolchain.md)** — shares `is_void` via `src/utils.js`, and its [message code generation templates](compiler-pipeline-language-toolchain.md) are the source from which `errors.js`/`warnings.js` are regenerated. The compiler's own `validate-options.js` follows the same DEV-gating pattern.
- **[Public API](public-api-built-in-feature-surface.md)** — `$state.snapshot` (backed by `clone.js`, tested here) and rune-adjacent runtime errors surface these helpers to end users.

## 6. Usage notes for maintainers

- **Never hand-edit `errors.js` or `warnings.js`** — regenerate via `scripts/process-messages`; update the templates in the compiler-pipeline module instead.
- Keep helpers **free of imports from `internal/client` or `internal/server`**; the only permitted runtime dependency is `esm-env`. The test file is the sole exception (it imports `proxy` for fixtures).
- Diagnostics style is fixed: `"%c[svelte] <code>\n%c<message>\nhttps://svelte.dev/e/<code>"` in DEV (styled via `%c`), bare URL in PROD — see the assertions in `clone.test.ts`.
- New guards belong in `validate.js` and must be cheap: they run on every render in DEV and should be `if (DEV)`-removable in production bundles.
