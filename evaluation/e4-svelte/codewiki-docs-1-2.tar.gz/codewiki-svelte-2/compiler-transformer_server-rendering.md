# Server-Side Rendering Transform (`compiler-transformer_server-rendering`)

> **Module root:** `packages/svelte/src/compiler/phases/3-transform/server/`
>
> **Parent module:** [compiler-transformer](compiler-transformer.md) · **Sibling:** [compiler-transformer_client-transform](compiler-transformer_client-transform.md) · **Runtime counterpart:** [server-runtime](server-runtime.md)

## 1. Introduction

The `compiler-transformer_server-rendering` module is the **SSR code-generation core** of the Svelte compiler. It consumes the *analyzed* component AST (produced by [compiler-parser](compiler-parser.md) and enriched by [compiler-analyzer](compiler-analyzer.md)) and emits a self-contained ES module whose default export is a plain JavaScript function that renders the component to an HTML string.

```svelte
<!-- Input: App.svelte -->
<script>
	let { name } = $props();
</script>
<h1>Hello {name}!</h1>
```

```js
// Output (generate: 'server', abridged)
import * as $ from 'svelte/internal/server';

function App($$payload, $$props) {
	let { name } = $$props;
	$$payload.out.push(`<h1>Hello ${$.escape(name)}!</h1>`);
}

export default App;
```

At runtime, the host framework calls `render(Component, { props })` from `svelte/server` (see [public-api](public-api.md)), which creates a `Payload` object and invokes the component function; every visitor-emitted statement appends fragments to `$$payload.out`, which is finally joined into the HTML response.

### Defining characteristics

| Property | Description |
|---|---|
| **Codegen model** | *Payload-driven*: visitors push literal strings and runtime calls into a `template` buffer; `build_template` coalesces them into `$$payload.out.push(...)` statements. No DOM, no signals. |
| **Reactivity** | Compiled away. Runes become plain values or one-shot `$.derived` calls; `$effect.*` runes are inert. |
| **Visitor architecture** | Built on the `zimmerframe` AST walker; two visitor registries (`global_visitors` for JS semantics, `template_visitors` for markup) merged per walk. |
| **Hydration protocol** | HTML comments (`<!--[-->`, `<!--]-->`, `<!---->`) delimit blocks so the client bundle ([compiler-transformer_client-transform](compiler-transformer_client-transform.md) + [client-dom-renderer](client-dom-renderer.md)) can re-attach during hydration. |
| **Dual syntax support** | Both runes mode (`$state`, `$derived`, `$props`) and legacy mode (`export let`, `$:`) are transformed in one pass. |

## 2. Position in the Compiler Pipeline

The module is Phase 3 ("transform") of the compiler, selected when compiling with `generate: 'server'`. It is registered by the compiler core entry point ([compiler-core_public_api](compiler-core_public_api.md)):

```mermaid
flowchart LR
    A["compile() / compileModule()<br/>(compiler-core_public_api)"] --> B["Phase 1 — parse<br/>(compiler-parser)"]
    B --> C["Phase 2 — analyze<br/>(compiler-analyzer)<br/>scopes · bindings · metadata"]
    C --> D{"generate target?"}
    D -- "client" --> E["client transform<br/>(compiler-transformer_client-transform)"]
    D -- "server" --> F["server transform<br/>(this module)"]
    E -. "hydration markers<br/>must align" .-> F
    F --> G["esrap → JS source"]
    G --> H["svelte/internal/server<br/>(server-runtime)"]
```

For the shared phases and CSS handling that wrap this module, see [compiler-transformer](compiler-transformer.md) and [compiler-transformer_css-transform](compiler-transformer_css-transform.md).

## 3. Architecture

### 3.1 Entry points (`transform-server.js`)

| Export | Purpose |
|---|---|
| `server_component(analysis, options)` | Compiles a full component. Performs **three ordered walks** over the analysis AST — `<script module>`, `<script>` (instance), and template — then assembles, patches, and exports the final `Program`. |
| `server_module(analysis, options)` | Compiles a module-only file (`compileModule`). A single walk of the module script, prefixed with the runtime import. |

### 3.2 Visitor registries

```mermaid
graph TD
    TS["transform-server.js<br/>server_component / server_module"]

    subgraph GV["global_visitors — applied to every walk (JS semantics)"]
        G1[Identifier]
        G2[AssignmentExpression]
        G3[CallExpression]
        G4[UpdateExpression]
        G5[AwaitExpression]
        G6[VariableDeclaration]
        G7[ClassBody]
        G8[PropertyDefinition]
        G9[MemberExpression]
        G10[ExpressionStatement]
        G11[LabeledStatement]
    end

    subgraph TV["template_visitors — template walk only (markup &amp; blocks)"]
        T1[Fragment]
        T2[RegularElement / SvelteElement]
        T3[Component / SvelteComponent / SvelteSelf]
        T4[EachBlock / IfBlock / AwaitBlock / KeyBlock]
        T5[RenderTag / HtmlTag / SlotElement]
        T6[SnippetBlock / ConstTag / DebugTag]
        T7[SvelteHead / TitleElement / SvelteBoundary]
        T8[SvelteElement / SvelteFragment / SpreadAttribute]
    end

    subgraph SH["shared builders"]
        S1["visitors/shared/utils.js<br/>process_children · build_template<br/>build_attribute_value · build_getter<br/>block_open/close · empty_comment"]
        S2["visitors/shared/element.js<br/>build_element_attributes"]
        S3["visitors/shared/component.js<br/>build_inline_component"]
        S4["../../utils.js<br/>clean_nodes · infer_namespace<br/>determine_namespace_for_children"]
    end

    TS --> GV
    TS --> TV
    GV --> S1
    TV --> S1
    TV --> S2
    TV --> S3
    TV --> S4
    SH --> OUT["ComponentServerTransformState<br/>init · template · hoisted"]
    OUT --> ASM["Program assembly"]
```

Each visitor has the signature `(node, context)` where `context` is a `zimmerframe` context bundling the current `state` (`ComponentContext`/`Context`) and a `visit` continuation. Visitors return a replacement AST node, push code into the state buffers, or delegate via `context.next()`.

### 3.3 State model

The state types (`server/types.d.ts`, `../types.d.ts`) thread compilation data and emission buffers through the walk:

```mermaid
classDiagram
    class TransformState {
        <<../types.d.ts>>
        +Analysis analysis
        +ValidatedModuleCompileOptions options
        +Scope scope
        +Map scopes
        +Map state_fields
    }
    class ServerTransformState {
        <<server/types.d.ts>>
        +Map~LabeledStatement,Statement~ legacy_reactive_statements
    }
    class ComponentServerTransformState {
        <<server/types.d.ts>>
        +ComponentAnalysis analysis
        +Statement[] init
        +Statement[] hoisted
        +Array template
        +Namespace namespace
        +boolean preserve_whitespace
        +boolean skip_hydration_boundaries
    }
    class Context {
        <<zimmerframe>>
        +visit(node)
        +next()
        +path
        +state
    }
    TransformState <|-- ServerTransformState : extends
    ServerTransformState <|-- ComponentServerTransformState : extends
    Context o-- ComponentServerTransformState : ComponentContext
    Context o-- ServerTransformState : Context
```

| Buffer | Filled by | Consumed by |
|---|---|---|
| `template` | markup visitors (literals, `$.xxx(...)` calls) | `build_template` → `$$payload.out.push(...)` statements |
| `init` | statements that must precede markup (`{@const}`, snippet declarations, temp vars) | prepended to the emitted block |
| `hoisted` | import statements, hoistable snippet function declarations | module top level |
| `legacy_reactive_statements` | `LabeledStatement` (`$:`) | topologically ordered after the template walk |

### 3.4 Compile-time data flow

```mermaid
flowchart TD
    A["ComponentAnalysis<br/>module/instance/template AST + scopes"] --> B["server_component(analysis, options)"]
    B --> C["walk module AST<br/>global_visitors"]
    B --> D["walk instance AST<br/>global_visitors + Import/Export handling"]
    B --> E["walk template AST<br/>global_visitors + template_visitors"]
    E --> F["template buffer<br/>(strings + runtime calls)"]
    C --> G["Program assembly"]
    D --> G
    F --> G
    G --> H{"post-walk patches"}
    H --> I["order legacy $: statements<br/>+ reactive declarations"]
    H --> J["uses_component_bindings?<br/>do/while $$render_inner loop<br/>$.copy_payload / $.assign_payload"]
    H --> K["store_sub bindings?<br/>$$store_subs var + $.unsubscribe_stores"]
    H --> L["bindable props / exports?<br/>$.bind_props($$props, {...})"]
    H --> M["dev / needs_context?<br/>$.push / $.pop context"]
    H --> N["$$sanitized_props · $$slots · props_id · injected CSS"]
    I & J & K & L & M & N --> O["component function<br/>function App($$payload, $$props)"]
    O --> P["hoisted imports (svelte/internal/server)<br/>+ module body + export default"]
    P --> Q["estree Program → esrap → JS"]
```

## 4. Core Components

### 4.1 Shared codegen utilities — `visitors/shared/utils.js`

The vocabulary every template visitor is written in:

| Component | Role |
|---|---|
| `block_open` / `block_close` | Literal hydration markers `<!--[-->` / `<!--]-->`; delimit `{#if}`, `{#each}`, `{#await}`, `{#snippet}` regions so the client can remove mismatched nodes. |
| `empty_comment` | Literal `<!---->`; separates adjacent text nodes (prevents "gluing" across fragment/component boundaries) and anchors hydration for components/render tags. |
| `process_children(nodes, context)` | Groups consecutive sibling `Text` / `Comment` / `ExpressionTag` nodes into a **single template literal**. HTML-escapes text and comments; folds compile-time-known expressions into the literal (via scope evaluation) and emits unknown ones as `${$.escape(expr)}`. Delegates non-text nodes to their visitors. |
| `build_template(template, out, operator)` | Flushes the buffer: coalesces strings/expressions into `out.push(...)` calls (or `out += ...` assignments — used by `TitleElement` to write `$$payload.title`); hoists interleaved statements between pushes. |
| `build_attribute_value(value, context, trim_whitespace, is_component)` | Converts an attribute value (`true`, `Text`, or mixed `Text`/`ExpressionTag` array) into an estree expression — a literal (HTML-escaped, whitespace-normalized) or a template literal using `$.stringify(...)` for dynamic parts. |
| `build_getter(node, state)` | Resolves identifier references against scope bindings. `store_sub` bindings become `$.store_get(($$store_subs ??= {}), '$store', store)`; declaration nodes pass through unchanged. |

### 4.2 Template structural visitors

| Visitor | Input construct | Emission |
|---|---|---|
| `Fragment` | component body / block contents | Infers namespace, runs `clean_nodes` (whitespace/comment trimming, const/debug/snippet/head **hoisting**, `is_standalone`/`is_text_first` detection), pushes `empty_comment` when a fragment starts with text, then `process_children`; returns a block of `init + build_template(template)`. |
| `RegularElement` | `<div …>` | Pushes `<tag` literal, delegates attributes to `build_element_attributes`, closes with `>` or `/>` (XHTML compliance). Handles raw `<script>`/`<style>` content, whitespace preservation in `pre`/`textarea`, dev-mode `$.push_element`/`$.pop_element`, `<select>`/`<option>` value semantics (`$$payload.select_value`, `$.maybe_selected`, `$.valueless_option`), and conditional textarea/contenteditable body emission. |
| `SvelteElement` | `<svelte:element this={tag}>` | Dev-validates the tag (`$.validate_dynamic_element_tag`, `$.validate_void_dynamic_element`) and emits `$.element($$payload, tag, attrsThunk?, childrenThunk?)`. |
| `Component` / `SvelteComponent` / `SvelteSelf` | `<Foo …>`, `<svelte:component this={x}>` | Delegate to `build_inline_component` (below). |
| `SnippetBlock` | `{#snippet name(params)}` | Emits `function name($$payload, params) { … }` into `hoisted` (when hoistable) or `init`; dev mode adds `$.validate_snippet_args` and `$.prevent_snippet_stringification`; tags the function `___snippet` for the legacy-binding re-render loop. |
| `RenderTag` | `{@render foo(args)}` | `foo($$payload, args)` (optional-chained via `maybe_call` when needed) plus `empty_comment` anchor unless `skip_hydration_boundaries`. |
| `SlotElement` | `<slot name="x">fallback</slot>` | `$.slot($$payload, $$props, name, propsOrSpread, fallbackThunk?)` wrapped in `empty_comment` anchors. |
| `IfBlock` | `{#if}…{:else}…{/if}` | `if (test) { …push(BLOCK_OPEN)… } else { …push(BLOCK_OPEN_ELSE)… }` followed by `block_close`. |
| `EachBlock` | `{#each items as item, i}…{:else}…{/each}` | `const each_array = $.ensure_array_like(items)` + a classic indexed `for` loop; index bindings honor `each_node_meta` (group bindings need the internal index); `{:else}` renders a fallback branch behind `BLOCK_OPEN_ELSE`; wrapped in block markers. |
| `AwaitBlock` | `{#await expr}…{:then v}…{/await}` | `$.await($$payload, expr, pendingThunk, (v) => thenBlock)` + `block_close`. |
| `KeyBlock` | `{#key expr}…{/key}` | Fragment output anchored between two `empty_comment`s. |
| `HtmlTag` | `{@html expr}` | `$.html(expr)` — trusted, unescaped insertion. |
| `SvelteHead` | `<svelte:head>…</svelte:head>` | `$.head($$payload, ($$payload) => { … })` — content routes to the head payload. |
| `TitleElement` | `<title>…</title>` | Builds `<title>…</title>` and assigns it with `build_template(…, $$payload.title, '=')`. |
| `SvelteBoundary` | `<svelte:boundary>` | Renders `BLOCK_OPEN`, then either the `pending` attribute snippet, a `pending` snippet block, or the children; closed by `BLOCK_CLOSE`. |
| `ConstTag` | `{@const x = …}` | `const x = …` pushed into `init`. |
| `DebugTag` | `{@debug …}` | Dev-only `console.log` of the referenced bindings (from [compiler-transformer_shared-infrastructure](compiler-transformer_shared-infrastructure.md) utils). |

#### Component & slot machinery — `build_inline_component`

`Component`, `SvelteComponent` and `SvelteSelf` funnel into `visitors/shared/component.js`, which performs the entire props/slots protocol:

1. **Props** — plain attributes become object properties; spreads become `$.spread_props` arguments; `bind:` directives become **getter/setter pairs** and are *delayed* so spreads cannot overwrite them; `--css-custom-props` are split out and rendered via `$.css_props(...)`.
2. **Slots** — child nodes are grouped by slot name (via `slot` attributes / `svelte:fragment`), each group compiled to an arrow function `($$payload, letParams?) => …` evaluated in the correct scope (default slot in component scope, named slots in parent scope) and passed as `$$slots.<name>`; a default slot without `let:` directives is passed as the `children` prop plus `$$slots.default: true` for legacy interop.
3. **Call** — `Foo($$payload, propsExpr)` (`maybe_call` for dynamic components), wrapped in `empty_comment` anchors (unless the parent block already provides one via `is_standalone`), or wrapped by `$.css_props` when custom properties are present.

### 4.3 Expression & statement visitors (JS semantics)

| Visitor | Behavior |
|---|---|
| `Identifier` | Rewrites `$$props` references to `$$sanitized_props`; routes other identifiers through `build_getter` (store subscriptions). |
| `AssignmentExpression` | Delegates to shared `visit_assignment_expression` with the server-specific `build_assignment`: class `$derived` private-field writes become `this.#key(value)` setter calls; constructor `$state` declarations become plain member assignments; `$store = v` → `$.store_set`, `obj.$store …` → `$.store_mutate`; everything else stays vanilla JS. |
| `UpdateExpression` | `$store++` / `--$store` → `$.update_store(_pre)(...)` bookkeeping on `$$store_subs`. |
| `CallExpression` | **Rune lowering** (table below); `$inspect` handled by `transform_inspect_rune` from the shared transform utils. |
| `ExpressionStatement` | Drops inert effect statements (`$effect`, `$effect.pre`, `$effect.root`, `$inspect.trace`); everything else passes through. |
| `AwaitExpression` | Top-level `await` is permitted (boundary rendering is async); `await` inside a non-inline function compiles to `$.await_outside_boundary()` — a runtime error call. |
| `VariableDeclaration` | **Runes mode:** `$state(x)` → `x`, `$derived(e)` → `$.derived(() => e)`, `$derived.by(f)` → `$.derived(f)`, `$props` → destructure `$$props` (strips `$bindable()` defaults, hides `$$slots`/`$$events` via rest-pattern injection, deconflicts to `$$slots_` when the component uses slots), `$props.id` skipped, `$effect.tracking`/`$inspect`/`$effect.root` passed through untouched. **Legacy mode:** `export let` → destructuring from `$$props` with default fallbacks (`build_fallback`, honoring `export let` aliases and nested destructuring); `$state` bindings expanded by `create_state_declarators`. |
| `ClassBody` / `PropertyDefinition` / `MemberExpression` | Class state fields: `$state` fields inlined as plain properties; `$derived` fields become a private backing property plus getter/setter methods (`this.#key()`); reads of derived private fields rewritten to `this.#key()` calls. Legacy classes are left untouched. |
| `LabeledStatement` | Captures legacy `$:` statements into `legacy_reactive_statements` (keeping the `$` label for `break $`); they are topologically ordered and appended to the instance body by `server_component`. |

### 4.4 Rune semantics on the server

| Rune | Server lowering | Notes |
|---|---|---|
| `$state(expr)` / `$state.raw(expr)` | `expr` | Plain immutable value during a render pass. |
| `$derived(expr)` | `$.derived(() => expr)` | Single evaluation. |
| `$derived.by(fn)` | `$.derived(fn)` | |
| `$props` | destructure of `$$props` | Sanitized; `$$slots`/`$$events` hidden from rest spreads. |
| `$bindable(x)` | `x` | Binding writes are deferred to the client; server honors defaults. |
| `$props.id()` | *(omitted)* | `server_component` injects `const $$props_id = $.props_id($$payload)` in the component prologue when needed. |
| `$effect(fn)` / `$effect.pre` | *(removed)* | `ExpressionStatement` → `b.empty`. |
| `$effect.tracking()` | `false` | |
| `$effect.root(fn)` | `() => {}` | Mimics the cleanup function. |
| `$effect.pending()` | `0` | |
| `$host()` | `void 0` | |
| `$state.snapshot(x)` | `$.snapshot(x, ignoreUncloneable?)` | |
| `$inspect(...)` | debug statement | Via `transform_inspect_rune`. |
| `$store` (auto-subscription) | `$.store_get(($$store_subs ??= {}), '$store', store)` | Unsubscribed at end of render via `$.unsubscribe_stores`. |

### 4.5 Runtime contract

Every generated module starts with `import * as $ from 'svelte/internal/server'` (the first `hoisted` entry). The emitted code therefore depends on the SSR runtime described in [server-runtime](server-runtime.md) and [internal-shared-utils](internal-shared-utils.md):

| Emitted call | Runtime responsibility |
|---|---|
| `$$payload.out.push(str)` | Append markup fragment to the `Payload.out` array (`payload.js`). |
| `$.escape`, `$.stringify`, `$.attr`, `$.attr_class`, `$.attr_style`, `$.spread_attributes` | HTML escaping / attribute serialization. |
| `$.element`, `$.html`, `$.head`, `$.slot`, `$.await`, `$.css_props`, `$.maybe_selected`, `$.valueless_option`, `$.derived` | Structural/behavioral primitives for dynamic elements, trusted HTML, head content, slot fallbacks, async blocks, style props, `<select>`/`<option>` semantics. |
| `$.spread_props`, `$.rest_props`, `$.sanitize_props`, `$.sanitize_slots`, `$.bind_props` | Component props/slots protocol. |
| `$.store_get/set/mutate`, `$.update_store(_pre)`, `$.unsubscribe_stores` | Auto-subscription bookkeeping via `$$store_subs`. |
| `$.push` / `$.pop`, `$.push_element` / `$.pop_element`, `$.validate_*`, `$.prevent_snippet_stringification` | Context stack and **dev-mode-only** validation/instrumentation (see [server-runtime](server-runtime.md) `dev.js`). |
| `$.props_id`, `$.copy_payload`, `$.assign_payload` | ID generation for hydration, and the legacy-binding re-render loop. |

**Hydration markers** (defined in `internal/server/hydration.js`, sourced from `constants.js`):

| Constant | Value | Emitted by |
|---|---|---|
| `BLOCK_OPEN` | `<!--[-->` | `IfBlock` (consequent), `EachBlock`, `SvelteBoundary` |
| `BLOCK_OPEN_ELSE` | `<!--[!-->` | `{:else}` / `{:catch}` / fallback branches |
| `BLOCK_CLOSE` | `<!--]-->` | end of every block region |
| `EMPTY_COMMENT` | `<!---->` | text-node separation, component/render/slot anchors |

The client transformer emits *matching* markers, which is what allows [client-dom-renderer](client-dom-renderer.md) (`hydration.js`) to walk server output and claim nodes.

## 5. Component Interaction

```mermaid
sequenceDiagram
    autonumber
    participant W as walker (template walk)
    participant F as Fragment visitor
    participant CN as clean_nodes (shared utils)
    participant PC as process_children
    participant RE as RegularElement
    participant EA as build_element_attributes
    participant CO as Component visitor
    participant BIC as build_inline_component
    participant ST as state.template / state.init

    W->>F: AST.Fragment
    F->>CN: trim/hoist/is_standalone/is_text_first
    F->>ST: empty_comment (if text-first)
    F->>PC: process_children(trimmed)
    PC->>ST: coalesced template literal (text + $.escape)
    PC->>RE: AST.RegularElement
    RE->>ST: literal '<div'
    RE->>EA: attributes
    EA->>ST: literals / $.attr / $.attr_class / $.attr_style / $.spread_attributes
    RE->>PC: children
    PC->>CO: AST.Component
    CO->>BIC: node, expression
    BIC->>BIC: props + delayed bind getters + $$slots serialization
    BIC->>ST: Foo($$payload, {...}) (+ empty_comment anchors)
    RE->>ST: literal '</div>'
    F-->>W: b.block([...init, ...build_template(template)])
```

## 6. Process Flow — Rendering at Runtime

```mermaid
sequenceDiagram
    autonumber
    participant App as Host application
    participant R as render() (svelte/server, public-api)
    participant P as Payload (server-runtime payload.js)
    participant C as App($$payload, $$props) — generated by this module
    participant $ as svelte/internal/server helpers

    App->>R: render(Component, { props, context })
    R->>P: new Payload(id_prefix)  // out[], css Set, head: HeadPayload, uid
    R->>C: App(payload, props)
    C->>C: push context (dev) · sanitize props/slots · derive $$props_id
    C->>P: $$payload.out.push('<ul><!--[-->')
    C->$: $.ensure_array_like(items)
    loop for each item
        C->>$: $.escape(item)
        C->>P: $$payload.out.push(`<li>${escaped}</li>`)
    end
    C->$: $.slot / $.head / $.await (as needed)
    C->$: $.unsubscribe_stores($$store_subs)
    C->>P: $$payload.out.push('<!--]--></ul>')
    C-->>R: return
    R-->>App: { html: out.join(''), head, css }
```

## 7. Worked Example

**Input**

```svelte
<script>
	let { items, label = 'List' } = $props();
</script>

<section data-label={label}>
	{#each items as item}
		<li>{item.name}</li>
	{:else}
		<p>empty</p>
	{/each}
</section>
```

**Generated output (abridged)**

```js
import * as $ from 'svelte/internal/server';

function App($$payload, $$props) {
	// let declarations from $props (bindable defaults preserved)
	let { items, label = 'List' } = $$props;

	$$payload.out.push(`<section${$.attr('data-label', label, false)}>`);
	{
		$$payload.out.push(`<!--[-->`); // block_open
		const each_array = $.ensure_array_like(items);
		if (each_array.length !== 0) {
			for (let index = 0, $$length = each_array.length; index < $$length; index++) {
				let item = each_array[index];
				$$payload.out.push(`<li>${$.escape(item.name)}</li>`);
			}
		} else {
			$$payload.out.push(`<!--[!-->`); // BLOCK_OPEN_ELSE
			$$payload.out.push(`<p>empty</p>`);
		}
		$$payload.out.push(`<!--]-->`); // block_close
	}
	$$payload.out.push(`</section>`);
}

export default App;
```

Note how the `EachBlock` visitor ([EachBlock.js](#)) produced the loop and markers, `build_element_attributes` turned `data-label={label}` into a `$.attr` call, and `process_children` folded static text while escaping the dynamic expression.

## 8. Design Notes & Invariants

- **Marker symmetry is mandatory.** Every `block_open`/`empty_comment` emitted here must have a consumer on the client; `skip_hydration_boundaries` (set by `Fragment` when the fragment is a single standalone component/render tag) is the escape hatch that suppresses redundant anchors and relies on the parent block's marker instead.
- **Text adjacency.** `<!---->` prevents two sibling text nodes from fusing into one hydration segment; `is_text_first` adds it when a snippet/component/each block begins with text.
- **Compile-time folding.** `process_children` and `build_attribute_value` inline expressions the analyzer proved static (`scope.evaluate`), avoiding needless `$.escape` calls and stringification.
- **Escaping is centralized.** All text interpolation goes through `$.escape`; attribute serialization through `$.attr*`; raw insertion only via `{@html}` → `$.html`.
- **Whitespace policy.** `preserve_whitespace` is honored from options or forced inside `<pre>`/`<textarea>`; otherwise `clean_nodes` collapses inter-node whitespace to single spaces (keeping `white-space: pre-line` behavior inside text runs).
- **Dev-only cost.** Element stack tracking (`$.push_element`/`$.pop_element`), snippet argument validation, dynamic-tag validation, and the `App[$.FILENAME]` marker are emitted only when `dev` is true, so production output contains no bookkeeping.
- **Legacy interop.** `uses_component_bindings` triggers the `do/while ($$settled)` re-render loop (`$.copy_payload` → `$$render_inner` → `$.assign_payload`) so bidirectional props converge during SSR; `componentApi: 4` restores a `Component.render()` static via `svelte/server`'s `_render`.
- **Deterministic output.** Legacy `$:` statements are topologically sorted; snippet declarations hoisted per `can_hoist` metadata to keep function declarations order-independent.

## 9. Related Modules

| Module | Relationship |
|---|---|
| [compiler-core](compiler-core.md) | Entry API (`compile`, `compileModule`), AST node/builders (`#compiler/builders`), diagnostics, options validation. |
| [compiler-parser](compiler-parser.md) | Produces the AST transformed here. |
| [compiler-analyzer](compiler-analyzer.md) | Produces the scopes, bindings (`store_sub`, `bindable_prop`, `legacy_reactive`, …), rune metadata, `each_node_meta`, and component metadata this module relies on. |
| [compiler-transformer](compiler-transformer.md) | Parent module; owns shared transform infrastructure (`clean_nodes`, namespace inference, `visit_assignment_expression`, CSS injection via [compiler-transformer_css-transform](compiler-transformer_css-transform.md)). |
| [compiler-transformer_client-transform](compiler-transformer_client-transform.md) | Client counterpart; marker emission must stay in lockstep for hydration. |
| [server-runtime](server-runtime.md) | The runtime being called: `Payload`/`HeadPayload`, context stack, hydration constants, all `$.` helpers. |
| [internal-shared-utils](internal-shared-utils.md) | Shared runtime validation used by emitted code (`validate_dynamic_element_tag`, etc.). |
| [public-api](public-api.md) | `render`/`hydrate`/`mount` entry points that invoke the generated component functions. |
| [client-dom-renderer](client-dom-renderer.md) | Client-side hydration that consumes the markers this module emits. |
| [legacy-compat](legacy-compat.md) | Legacy `render` shim wired up when `compatibility.componentApi === 4`. |
