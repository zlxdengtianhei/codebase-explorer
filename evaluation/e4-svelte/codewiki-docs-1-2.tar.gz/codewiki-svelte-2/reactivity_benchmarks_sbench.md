# Reactivity Benchmarks — sbench (`reactivity_benchmarks_sbench`)

## 1. Overview

The `reactivity_benchmarks_sbench` module implements the **"sbench" (Svelte benchmark) suite** — a family of micro-benchmarks that measure the **cost of creating reactivity graphs** with the Svelte 5 client reactivity engine (`svelte/src/internal/client`). It lives in a single file:

```
benchmarking/benchmarks/reactivity/sbench.js
```

Each exported benchmark builds a dependency topology with a fixed workload size (`COUNT = 1e5` total signal edges) and reports **wall-clock time** and **GC time** for signal/derived allocation. Unlike the [kairo suites](reactivity_benchmarks_kairo_suites.md), which stress *update propagation* through live graphs, sbench isolates **construction cost**: sources created via `$.state`, deriveds created via `$.derived`, all scoped inside an `$.effect_root` so the entire graph can be deterministically destroyed between timed iterations.

| | |
|---|---|
| **Module path** | `benchmarking/benchmarks/reactivity/sbench.js` |
| **Parent module** | [reactivity_benchmarks](reactivity_benchmarks.md) |
| **Grandparent** | [Engineering Tooling (Benchmarks, Verification & Playground)](engineering_tooling_benchmarks_verification_playground.md) |
| **Sibling modules** | [kairo suites](reactivity_benchmarks_kairo_suites.md), [mol_bench](reactivity_benchmarks_mol_bench.md) |
| **Primary dependency** | [Client Runtime Engine (Reactivity & DOM Rendering) → client-reactivity-engine](client-reactivity-engine.md) |
| **Runtime target** | Node.js (needs `v8.collectGarbage`, i.e. `--expose-gc`, via the shared harness) |
| **Exports** | 10 async benchmark functions, each returning `{ benchmark, time, gc_time }` |

---

## 2. Role in the System

Sbench is the **construction-cost baseline** of the reactivity benchmark family. Together with its siblings it forms a triangulated performance profile of the internal signal implementation:

```mermaid
flowchart LR
    subgraph ENG["Engineering Tooling"]
        RB["reactivity_benchmarks"]
        CMP["benchmark_comparison"]
    end
    subgraph RB_CHILDREN["reactivity_benchmarks children"]
        KAIRO["kairo_suites<br/>(update propagation)"]
        SBENCH["sbench<br/>(graph creation)"]
        MOL["mol_bench<br/>(mixed workload)"]
    end
    ENG_CORE["Svelte internal<br/>client reactivity engine"]

    RB --> KAIRO & SBENCH & MOL
    KAIRO --> ENG_CORE
    SBENCH --> ENG_CORE
    MOL --> ENG_CORE
    CMP -.consumes results from.-> RB_CHILDREN
```

Results are plain data objects (`{ benchmark, time, gc_time }`), designed to be aggregated by the comparison tooling ([benchmark_comparison](benchmark_comparison.md)) when tracking regressions across engine changes.

---

## 3. Architecture

### 3.1 Module context and external dependencies

`sbench.js` has exactly two imports:

| Import | Provider | Purpose |
|---|---|---|
| `fastest_test` | `benchmarking/utils.js` | Repetition + timing harness; returns the fastest of N tracked runs |
| `* as $` | `packages/svelte/src/internal/client/index.js` | The internal reactivity API: `state`, `derived`, `get`, `effect_root` |

```mermaid
flowchart LR
    subgraph SB["benchmarking/benchmarks/reactivity/sbench.js"]
        direction TB
        EXP["10 exported benchmarks<br/>sbench_create_*"]
        B["bench(fn, count, scount)"]
        BUILDERS["create_computations_*<br/>(graph shape builders)"]
        DATA["create_data_signals(n, sources)"]
    end

    subgraph UTILS["benchmarking/utils.js"]
        FT["fastest_test(times, fn)"]
        RT["run_tracked(fn)<br/>v8.collectGarbage + GarbageTrack"]
    end

    subgraph ENGINE["internal/client (via $ namespace)"]
        ST["state(v)"]
        DRV["derived(fn)"]
        GET["get(signal)"]
        ER["effect_root(fn)"]
    end

    EXP --> B
    B --> DATA
    B --> BUILDERS
    EXP --> FT
    FT --> RT
    B --> ST & DRV
    BUILDERS --> DRV & GET
    EXP --> ER
    ST & DRV & GET -.implemented in.-> ENG_CORE["runtime.js /<br/>reactivity/sources.js /<br/>reactivity/deriveds.js /<br/>reactivity/effects.js"]
```

### 3.2 Internal composition

The file is organized in three layers:

1. **Shape builders (internal)** — `create_data_signals`, `create_computation_0/1/2/4/1000`, and the `create_computations_<fan>` loops that assemble graphs of a given arity.
2. **Driver (internal)** — a single `bench(fn, count, scount)` helper that (a) allocates `scount` source signals, then (b) hands them to a shape builder to create `count` deriveds.
3. **Exported benchmarks** — ten `sbench_create_*` async functions that share one measurement protocol (see §5).

---

## 4. Benchmark Catalog

All benchmarks use `COUNT = 1e5`. The suite sweeps the **fan-in / fan-out space** while keeping the total number of source→derived edges constant at `1e5`, so differences in timings isolate the cost of the *vertex mix* (sources vs. deriveds) and of *arity per derived*.

### 4.1 Exported benchmarks

| Export | Shape builder | Sources created | Deriveds created | Topology |
|---|---|---|---|---|
| `sbench_create_signals` | `create_data_signals` | `1e5` | 0 | sources only (baseline allocation cost) |
| `sbench_create_0to1` | `create_computations_0to1` | 0 | `1e5` | deriveds with **no** dependencies (constant expressions) |
| `sbench_create_1to1` | `create_computations_1to1` | `1e5` | `1e5` | 1 source → 1 derived |
| `sbench_create_2to1` | `create_computations_2to1` | `1e5` | `5e4` | 2 sources → 1 derived |
| `sbench_create_4to1` | `create_computations_4to1` | `1e5` | `2.5e4` | 4 sources → 1 derived |
| `sbench_create_1000to1` | `create_computations_1000to1` | `1e5` | `100` | 1000 sources → 1 derived (sums `sources[i*1000 … i*1000+999]`) |
| `sbench_create_1to2` | `create_computations_1to2` | `5e4` | `1e5` | 1 source → 2 deriveds |
| `sbench_create_1to4` | `create_computations_1to4` | `2.5e4` | `1e5` | 1 source → 4 deriveds |
| `sbench_create_1to8` | `create_computations_1to8` | `1.25e4` | `1e5` | 1 source → 8 deriveds |
| `sbench_create_1to1000` | `create_computations_1to1000` | `100` | `1e5` | 1 source → 1000 deriveds |

> **Naming convention:** `XtoY` reads *X inputs → 1 derived* (fan-in) for `2to1/4to1/1000to1`, and *1 source → Y deriveds* (fan-out) for `1to2/1to4/1to8/1to1000`. `0to1` denotes deriveds with zero inputs.

### 4.2 Topology patterns

```mermaid
flowchart TB
    subgraph FANIN["Fan-in (2to1 · 4to1 · 1000to1)"]
        direction LR
        s1((s1)) --> d1{{derived}}
        s2((s2)) --> d1
        s3((s3)) --> d1
        s4((s4)) --> d1
    end
    subgraph FANOUT["Fan-out (1to2 · 1to4 · 1to8 · 1to1000)"]
        direction LR
        s((s)) --> dA{{d1}}
        s --> dB{{d2}}
        s --> dC{{d3}}
        s --> dD{{d4}}
    end
    subgraph DEGENERATE["Edge cases"]
        direction LR
        n0{{"derived (0 inputs)"}}:::noop
        srcs["1e5 bare sources"]:::src
    end
    classDef noop fill:#f9f,stroke:#333;
    classDef src fill:#bbf,stroke:#333;
```

The two families probe different engine behaviors:

- **Fan-in** varies the dependency list length per derived (`1`, `2`, `4`, `1000` `$.get` calls inside the derived closure) with a fixed derived count.
- **Fan-out** varies the reaction (subscriber) list length per source with a fixed derived count.

### 4.3 Internal shape builders

| Internal function | Role |
|---|---|
| `create_data_signals(n, sources)` | Allocates `n` source signals via `$.state(i)`, filling `sources[i]` |
| `create_computation_0(i)` | `$.derived(() => i)` — input-free derived |
| `create_computation_1(s1)` | `$.derived(() => $.get(s1))` — single-input derived |
| `create_computation_2(s1, s2)` | Sum of two reads |
| `create_computation_4(s1…s4)` | Sum of four reads |
| `create_computation_1000(ss, offset)` | Loop-sums `$.get(ss[offset + i])` for `i < 1000` |
| `create_computations_0to1 / 1to1 / 2to1 / 4to1 / 1000to1` | Fan-in loops (index into consecutive source slots) |
| `create_computations_1to2 / 1to4 / 1to8 / 1to1000` | Fan-out loops (attach 2/4/8/1000 single-input deriveds per source) |
| `bench(fn, count, scount)` | Common driver: `create_data_signals(scount)` → `fn(count, sources)` |

---

## 5. Execution Protocol

Every exported benchmark (except `sbench_create_signals`, which has no graph and therefore no ownership scope) follows the identical four-phase protocol:

```mermaid
sequenceDiagram
    autonumber
    participant B as sbench_create_*
    participant U as fastest_test / run_tracked
    participant E as $ (engine)
    participant D as V8 GC

    Note over B: Phase 1 — JIT warm-up
    loop 3 times (outside effect_root)
        B->>E: bench(builder, count, scount)<br/>$.state × scount, $.derived × count
    end

    Note over B: Phase 2 — timed runs
    B->>U: fastest_test(10, callback)
    loop 10 times
        U->>D: v8.collectGarbage() (pre-run)
        U->>E: callback(): effect_root(fn)
        E-->>B: destroy handle
        loop 10 iterations
            B->>E: bench(...) inside root
        end
        B->>E: destroy() → destroy_effect(root)
        U->>D: GarbageTrack.gcDuration (async)
    end
    U-->>B: fastest run { time, gc_time }

    Note over B: Phase 3 — report
    B-->>B: { benchmark, time: t.toFixed(2), gc_time: g.toFixed(2) }
```

Step-by-step:

1. **Warm-up** — three un-timed `bench` calls let the JIT compile the builders and the engine hot paths. Warm-up graphs are *not* destroyed (they stay reachable only through the loop scope and become collectible afterwards).
2. **Ownership scope** — `$.effect_root(() => …)` creates a `ROOT_EFFECT | EFFECT_PRESERVED` effect (and guarantees a `Batch` exists). Every derived created inside is parented under the active effect tree, so a single `destroy()` call tears down the whole graph. This keeps heap pressure reproducible across the 10 inner iterations.
3. **Measurement** — `fastest_test(10, callback)` executes the callback ten times, each wrapped by `run_tracked`, which:
   - forces a full `v8.collectGarbage()` **before** the run (requires `--expose-gc`),
   - times `callback` wall-clock via `run_timed`,
   - measures **GC time** attributable to the run via `GarbageTrack`,
   - and `fastest_test` keeps the run with the **smallest wall time** (GC time is reported from that same run).
4. **Reporting** — the result object uses the stable contract consumed by the comparison tooling:

```js
{
  benchmark: 'sbench_create_1to1', // stable identifier
  time:    '<wall seconds, 2dp>',  // string
  gc_time: '<gc seconds, 2dp>'     // string
}
```

**Special case — `sbench_create_signals`:** pure `$.state` allocation. Warm-up is 3 × `bench(create_data_signals, COUNT, COUNT)`; the timed callback runs **100** repetitions and, since no effects/deriveds are created, runs without an `effect_root` scope.

---

## 6. Engine API Surface Under Test

The suite exercises exactly four primitives of the client reactivity engine (documented in depth in [client-reactivity-engine](client-reactivity-engine.md)):

| API | Engine location | Behavior relevant to sbench |
|---|---|---|
| `$.state(v)` | `reactivity/sources.js` → `source(v)` | Allocates a source signal, pushes an initial reaction value slot |
| `$.derived(fn)` | `reactivity/deriveds.js` | Allocates a `Derived` signal (`DERIVED \| DIRTY` flags, `UNINITIALIZED` value, `equals`, parent linkage). **Lazy**: `fn` is not executed at creation; ownership (`UNOWNED` vs. effect-parented) is decided here based on the active effect |
| `$.get(signal)` | `runtime.js` | Dependency registration on the active reaction and lazy evaluation of dirty deriveds. Inside sbench closures it defines *which* edges a derived *would* subscribe on first read |
| `$.effect_root(fn)` | `reactivity/effects.js` | Ensures a `Batch`, creates the root effect, returns a `destroy()` closure used to deterministically dispose each timed graph |

### 6.1 What is actually measured

An important subtlety: Svelte deriveds evaluate **lazily**. sbench never reads the created deriveds and no effects subscribe to them, so the closures passed to `$.derived` (and thus the `$.get` dependency registration inside them) never run. Consequently each benchmark isolates:

- **signal/derived object allocation** (object shape setup, flag computation, parent linking, closure capture),
- **source allocation** including initial reaction-value bookkeeping (`push_reaction_value`),
- **effect-tree parenting overhead** when created inside the root effect,
- and, via the destroy step + `gc_time`, **teardown/garbage-collect cost** of large graphs.

The "topology" of each benchmark therefore describes the *potential* graph (what would be subscribed on first read) as well as the allocation profile (number and arity of closures created), not live propagation — that dimension is covered by the [kairo suites](reactivity_benchmarks_kairo_suites.md) and [mol_bench](reactivity_benchmarks_mol_bench.md).

---

## 7. Dependency Graph

```mermaid
flowchart TD
    SB["sbench.js"] -->|"import { fastest_test }"| U["benchmarking/utils.js<br/>fastest_test → run_tracked<br/>(v8.collectGarbage, GarbageTrack)"]
    SB -->|"import * as $"| IDX["internal/client/index.js"]
    IDX --> RT["runtime.js<br/>(get, active reaction/deps bookkeeping)"]
    IDX --> SRC["reactivity/sources.js<br/>(state → source)"]
    IDX --> DRV["reactivity/deriveds.js<br/>(derived)"]
    IDX --> EFF["reactivity/effects.js<br/>(effect_root, destroy_effect)"]

    subgraph EXPORTS["exported benchmarks"]
        S1["sbench_create_signals"]
        FANIN_B["sbench_create_0to1 · 1to1 · 2to1 ·<br/>4to1 · 1000to1"]
        FANOUT_B["sbench_create_1to2 · 1to4 · 1to8 · 1to1000"]
    end

    EXPORTS --> BENCH["bench(fn, count, scount)"]
    BENCH --> SIGS["create_data_signals<br/>$.state × n"]
    BENCH --> SHAPES["create_computations_*<br/>$.derived × n (reads via $.get)"]
    FANIN_B & FANOUT_B --> ER["$.effect_root(fn) + destroy()"]
```

---

## 8. Extending the Suite

To add a new graph shape:

1. Add a private builder following the existing convention — e.g. `create_computation_K(s1…sK)` plus a `create_computations_Kto1(n, sources)` loop (or a `1toK` fan-out loop), keeping the *total edges = `COUNT`* invariant by choosing the loop bound `n / K` or `COUNT / K` sources.
2. Export `sbench_create_Kto1` (or `sbench_create_1toK`) by copying an existing benchmark body and adjusting the `(count, scount)` pair passed to `bench` in both the warm-up and the timed callback — both must use identical parameters.
3. Keep the result contract intact: `benchmark` string matching the export name, `time`/`gc_time` produced by `fastest_test` and `toFixed(2)`.

Because every benchmark only touches the stable `$` namespace and `fastest_test`, no engine or harness changes are required for new shapes.

---

## 9. Related Modules

- [reactivity_benchmarks](reactivity_benchmarks.md) — parent module; benchmark family overview and shared conventions.
- [reactivity_benchmarks_kairo_suites](reactivity_benchmarks_kairo_suites.md) — sibling suite stressing *update propagation* (owned/unowned variants of diamond, triangle, mux, deep, broad, unstable graphs).
- [reactivity_benchmarks_mol_bench](reactivity_benchmarks_mol_bench.md) — sibling mixed-workload benchmark.
- [client-reactivity-engine](client-reactivity-engine.md) — the engine under test: signal graph, sources & proxies, deriveds, effects, batching/scheduling.
- [benchmark_comparison](benchmark_comparison.md) — tooling that consumes/compares results across suites.
- [Engineering Tooling (Benchmarks, Verification & Playground)](engineering_tooling_benchmarks_verification_playground.md) — grandparent module grouping all engineering benchmark/verification tooling.
