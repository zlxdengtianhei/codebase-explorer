# Compiler Core — Options Validation (`compiler-core_options_validation`)

## Introduction

The **options validation** module is the gatekeeper of the Svelte compiler's configuration surface. It lives in a single file — [`packages/svelte/src/compiler/validate-options.js`](https://github.com/sveltejs/svelte/blob/main/packages/svelte/src/compiler/validate-options.js) — and is responsible for:

1. **Validating** every user-supplied compiler option before compilation begins (type checks, enum membership, shape checks).
2. **Normalizing** raw option objects into fully-populated `ValidatedCompileOptions` / `ValidatedModuleCompileOptions` objects with all defaults applied.
3. **Guarding API evolution** by rejecting removed options with hard errors, warning about soft-removed options, and emitting deprecation notices for options that still work but will disappear.

The module implements a small, declarative **validator-combinator DSL**: instead of imperative `if`-checks, every option is described by a tiny validator function (`string()`, `boolean()`, `list()`, `fun()`, `object()`, …) that returns the *coerced, defaulted* value or throws a diagnostic. This makes the entire options contract inspectable in one place and keeps behavior consistent between `compile()` and `compileModule()`.

**Exported API of this module:**

| Export | Purpose |
| --- | --- |
| `validate_component_options(options, keypath)` | Validates `CompileOptions` for `compile()` → returns `ValidatedCompileOptions` |
| `validate_module_options(options, keypath)` | Validates `ModuleCompileOptions` for `compileModule()` → returns `ValidatedModuleCompileOptions` |

---

## Position in the Compiler Pipeline

Options validation is the **first substantive step** of every compilation. Both public entry points in `packages/svelte/src/compiler/index.js` reset compiler state (partially from validated inputs) and immediately invoke this module before any parsing or analysis occurs.

```mermaid
flowchart LR
    subgraph PublicAPI["Public API (index.js)"]
        compile["compile(source, options)"]
        compileModule["compileModule(source, options)"]
    end

    subgraph ThisModule["compiler-core_options_validation"]
        VCO["validate_component_options"]
        VMO["validate_module_options"]
    end

    subgraph Parser["compiler-parser"]
        P["1-parse"]
        RO["read_options<br/>&lt;svelte:options&gt; in source"]
    end

    subgraph Analyzer["compiler-analyzer"]
        A["2-analyze"]
    end

    subgraph Transformer["compiler-transformer"]
        T["3-transform<br/>(client / server / css)"]
    end

    subgraph Diagnostics["compiler-core_diagnostics"]
        E["errors.js<br/>options_* error codes"]
        W["warnings.js<br/>options_* warning codes"]
        S["state.js"]
    end

    compile --> VCO
    compileModule --> VMO
    VCO -- "ValidatedCompileOptions" --> P
    VMO -- "ValidatedModuleCompileOptions" --> A
    P --> A --> T
    RO -. "per-component overrides<br/>(runes, css, namespace, …)" .-> P
    VCO & VMO -. "throws options_removed /<br/>options_unrecognised /<br/>options_invalid_value" .-> E
    VCO & VMO -. "emits options_removed_* /<br/>options_renamed_ssr_dom /<br/>deprecation warnings" .-> W
    VCO & VMO -. "warningFilter registered<br/>via state.reset()" .-> S
```

> ℹ️ Note the interplay with the parser: options can come from **two sources** — the JS options object validated here, and `<svelte:options>` attributes inside the source, which are validated separately by `read_options` in the [compiler-parser](compiler-parser.md) module. The combined result (validated JS options overlaid with parsed in-source options) feeds the [compiler-analyzer](compiler-analyzer.md) and [compiler-transformer](compiler-transformer.md) phases.

---

## Architecture

### Validator Combinator Model

Every validator has the uniform signature:

```ts
type Validator<Input = any, Output = Input> =
  (input: Input, keypath: string) => Required<Output>;
```

- `input` — the raw (possibly `undefined`) user value.
- `keypath` — the dotted path of the current option (e.g. `"experimental.async"` or `"cssHash"`) used to build precise error messages.
- Return value — the **fully normalized value**: either the user input (validated) or the declared fallback/default.

Validators compose recursively: `validate_component_options` is itself just an `object({...})` combinator whose children are option validators, giving the whole system a tree structure.

```mermaid
flowchart TD
    subgraph RootValidators["Entry-point validators (exported)"]
        VCO["validate_component_options<br/>= object(common + component options)"]
        VMO["validate_module_options<br/>= object(common + no-op stubs)"]
    end

    subgraph Combinators["Structural combinators"]
        OBJ["object(children, allow_unknown)<br/>recursive; rejects unknown keys;<br/>always produces complete output"]
        VAL["validator(fallback, fn)<br/>applies fallback when input === undefined"]
    end

    subgraph LeafValidators["Leaf type validators"]
        STR["string(fallback, allow_empty)"]
        BOOL["boolean(fallback)"]
        LIST["list(options, fallback)<br/>enum membership"]
        FUN["fun(fallback)<br/>function-typed options"]
    end

    subgraph LifecycleDecorators["Option-lifecycle decorators"]
        DEP["deprecate(warnFn, validator)<br/>warn once, then delegate"]
        WREM["warn_removed(warnFn)<br/>warn once, value discarded"]
        REM["removed(msg)<br/>hard error, value discarded"]
    end

    %% Root validators are themselves object() combinators
    VCO --> OBJ
    VMO --> OBJ
    OBJ --> VAL
    VAL --> STR & BOOL & LIST & FUN
    DEP -->|wraps| BOOL
    WREM --> VAL
    REM -->|throws via| ERR["errors.js<br/>options_removed"]
```

### How the `object` Combinator Works

`object(children, allow_unknown)` is the heart of the system:

1. Rejects non-object (or array) inputs with `options_invalid_value`.
2. Iterates **user keys first**: any key not declared in `children` triggers the `options_unrecognised` error (unless `allow_unknown` is set, in which case the key is passed through untouched).
3. Iterates **declared keys second**, calling each child validator — even for missing keys, passing `undefined` so that defaults get filled in.
4. Returns a new object containing *every declared key*, guaranteeing downstream phases never need `?.`-style defensive access.

### Module vs. Component Options

The two exported validators differ in one subtle way:

```js
// validate_module_options: component-only keys are "recognized but ignored"
object({
    ...common_options,
    ...Object.fromEntries(Object.keys(component_options).map((key) => [key, () => {}]))
})
```

Passing a component-only option (e.g. `css`) to `compileModule()` is **silently accepted and discarded** rather than raising `options_unrecognised` — a deliberate compatibility affordance for tooling that shares one options object across both entry points. Only `common_options` are actually validated for modules.

### Once-Only Warning Machinery

A module-level `Set` deduplicates warning emissions:

```js
const warned = new Set();
function warn_once(fn) { /* invoke fn(null) only if not already seen */ }
```

Because validators run on **every compilation**, this prevents tools watching hundreds of files from being flooded with the same `generate: "dom"` or `enableSourcemap` warning. All lifecycle decorators (`warn_removed`, `deprecate`, and the inline `warn_once` in the `generate` validator) route through this set.

---

## The Three-Tier Option Lifecycle

The module encodes Svelte's API-evolution policy as three explicit tiers. Each tier maps to a specific diagnostic from the [compiler-core_diagnostics](compiler-core_diagnostics.md) module:

```mermaid
flowchart LR
    subgraph Tier1["Tier 1 — Hard removed (errors)"]
        REM["removed(msg)"]
        E1["options_removed<br/>compile FAILS"]
    end
    subgraph Tier2["Tier 2 — Soft removed (warnings)"]
        WREM["warn_removed(warnFn)"]
        E2["options_removed_enable_sourcemap<br/>options_removed_hydratable<br/>options_removed_loop_guard_timeout<br/>compile SUCCEEDS"]
    end
    subgraph Tier3["Tier 3 — Deprecated (still functional)"]
        DEP["deprecate(warnFn, validator)"]
        E3["options_deprecated_accessors<br/>options_deprecated_immutable<br/>value still validated & used"]
    end
    REM -->|"throws"| E1
    WREM -->|"warn_once, return undefined"| E2
    DEP -->|"warn_once + delegate"| E3
```

Complete inventory of option declarations:

**Common options** (valid for both `compile` and `compileModule`):

| Option | Validator | Default | Notes |
| --- | --- | --- | --- |
| `filename` | `string` | `'(unknown)'` | |
| `rootDir` | `string` | `process.cwd()` / `Deno.cwd()` | Replicates Svelte 4 behavior; runtime-guarded for non-Node environments |
| `dev` | `boolean` | `false` | |
| `generate` | custom `validator` | `'client'` | Accepts `'client' \| 'server' \| false`; warns + renames legacy `'dom'`/`'ssr'` |
| `warningFilter` | `fun` | `() => true` | Registered into `state.reset()` **before** validation runs |
| `experimental.async` | nested `object` → `boolean` | `false` | |

**Component-only options:**

| Option | Tier | Validator / Diagnostic |
| --- | --- | --- |
| `css` | active | Rejects legacy booleans (`true`/`false`) and `'none'`; requires `'external'` or `'injected'` |
| `cssHash` | active | `fun` with default hash implementation |
| `cssOutputFilename`, `outputFilename`, `name` | active | `string` |
| `customElement`, `preserveComments`, `preserveWhitespace`, `hmr`, `discloseVersion`, `modernAst` | active | `boolean` |
| `namespace` | active | `list(['html', 'mathml', 'svg'])` |
| `compatibility.componentApi` | active | `list([4, 5], 5)` |
| `fragments` | active | `list(['html', 'tree'])` |
| `runes` | active | `boolean(undefined)` — `undefined` means "infer from usage" |
| `sourcemap` | active | Pass-through validator (sourcemaps have heterogeneous shapes) |
| `accessors`, `immutable` | **Tier 3** | `deprecate(...)` wrapping `boolean` |
| `enableSourcemap`, `hydratable`, `loopGuardTimeout` | **Tier 2** | `warn_removed(...)` → warning codes `options_removed_*` |
| `legacy`, `format`, `tag`, `sveltePath`, `errorMode`, `varsReport` | **Tier 1** | `removed(msg)` → error code `options_removed` with migration guidance (e.g. `tag` → `<svelte:options customElement>`, `errorMode`/`varsReport` → TS `verbatimModuleSyntax`) |

---

## Validation Flow

### Sequence: `compile()` Through Validation

```mermaid
sequenceDiagram
    participant User as Bundler plugin / user
    participant Idx as index.js (compile)
    participant ST as state.js
    participant VO as validate-options.js
    participant ERR as errors.js
    participant WARN as warnings.js
    participant PIPE as parse → analyze → transform

    User->>Idx: compile(source, options)
    Idx->>ST: state.reset({ warning: options.warningFilter, filename })
    Note over ST: warningFilter is consumed *before* validation<br/>(can't warn about itself)
    Idx->>VO: validate_component_options(options, '')
    activate VO

    rect rgb(235, 244, 255)
        Note over VO: object() walks every declared key
        loop each option key
            VO->>VO: child validator(input, keypath)
            alt input === undefined
                VO->>VO: return declared fallback (default applied)
            else unknown key
                VO->>ERR: options_unrecognised(keypath)
                ERR--xUser: CompileError thrown
            else wrong type / value
                VO->>ERR: options_invalid_value(msg)
                ERR--xUser: CompileError thrown
            else removed option (Tier 1)
                VO->>ERR: options_removed(msg)
                ERR--xUser: CompileError thrown
            else soft-removed (Tier 2)
                VO->>WARN: warn_once(options_removed_*)
            else deprecated (Tier 3)
                VO->>WARN: warn_once(options_deprecated_*)
                VO->>VO: inner validator still runs
            end
        end
    end

    VO-->>Idx: ValidatedCompileOptions (complete, defaulted)
    deactivate VO
    Idx->>PIPE: parse(source) → analyze → transform
    Note over PIPE: Parsed <svelte:options> overlays<br/>validated options before analyze
    PIPE-->>User: CompileResult
```

### Data Transformation Example

A raw options object is reshaped into the validated contract:

```js
// Input (user-supplied CompileOptions)
{ generate: 'dom', css: true, enableSourcemap: false, accessors: true }

// validate_component_options() output
{
  generate: 'server',            // renamed 'dom' → 'server'; warned options_renamed_ssr_dom
  css: /* CompileError thrown:  */ // boolean css rejected — "Use 'external'/'injected'"
  // (had css been valid:)
  filename: '(unknown)',         // default injected
  dev: false,                    // default injected
  warningFilter: () => true,     // default injected
  accessors: true,               // kept; warned options_deprecated_accessors
  enableSourcemap: undefined,    // discarded; warned options_removed_enable_sourcemap
  // ...every remaining declared key present with its default
}
```

### Error & Warning Contract

All diagnostics raised here carry stable codes with documentation links, generated by the templating system described in [message_code_generation_templates](message_code_generation_templates.md):

| Code | Kind | Raised by | Message shape |
| --- | --- | --- | --- |
| `options_unrecognised` | Error | `object()` on undeclared key | `Unrecognised compiler option {keypath}` |
| `options_invalid_value` | Error | leaf validators, `css`, `generate` | `Invalid compiler option: {details}` |
| `options_removed` | Error | `removed(msg)` | `Invalid compiler option: {details}` |
| `options_removed_enable_sourcemap` | Warning | `warn_removed` | Option removed; sourcemaps always generated |
| `options_removed_hydratable` | Warning | `warn_removed` | Components always hydratable now |
| `options_removed_loop_guard_timeout` | Warning | `warn_removed` | Option removed |
| `options_renamed_ssr_dom` | Warning | inline in `generate` validator | `dom`/`ssr` renamed to `client`/`server` |

Errors/warnings flow through the compile-diagnostic machinery (including code frames via `get_code_frame`) documented in [compiler-core_diagnostics](compiler-core_diagnostics.md).

---

## Key Design Decisions

1. **Declarative over imperative.** Each option is one line of composition; adding an option means adding one validator entry — no scattered conditional logic, and the full contract is greppable in a single object literal.

2. **Total output objects.** `object()` unconditionally emits all declared keys, so downstream phases ([compiler-analyzer](compiler-analyzer.md), [compiler-transformer](compiler-transformer.md)) receive `ValidatedCompileOptions` where every field is present and type-safe — `undefined` only where meaningful (e.g. `runes: undefined` = auto-detect).

3. **Keypath-threaded errors.** The `keypath` parameter propagates through nested `object()` calls, producing messages like `experimental.async should be true or false, if specified` — precise for nested option trees.

4. **Warn-before-validate ordering.** `deprecate()` warns *then* delegates to the inner validator, so a deprecated-but-invalid value produces both the deprecation warning and the validation error.

5. **Environment-portable defaults.** `rootDir` probes `process.cwd?.()` / `Deno.cwd()` with `typeof` guards, keeping the compiler usable in Deno and non-Node runtimes (mirroring Svelte 4 behavior).

6. **Cross-runbook deduplication.** The shared `warned` Set is process-global, not per-compilation — intentional for build tools compiling many files with the same stale options.

---

## Related Modules

| Module | Relationship |
| --- | --- |
| [compiler-core](compiler-core.md) | Parent module bundling core compiler infrastructure; this is one of its sub-modules |
| [compiler-core_public_api](compiler-core_public_api.md) | `compile()` / `compileModule()` are the primary **consumers** of the two exported validators |
| [compiler-core_diagnostics](compiler-core_diagnostics.md) | Supplies the `errors.js` / `warnings.js` diagnostics, `state.js` warning filtering, and code-frame rendering used by this module |
| [compiler-parser](compiler-parser.md) | `read_options` performs the analogous validation of in-source `<svelte:options>` attributes (a separate contract: `tag` is an error there, `css` only accepts `'injected'`, etc.) |
| [compiler-analyzer](compiler-analyzer.md) | Consumes `ValidatedCompileOptions` (e.g. `runes`, `dev`, `namespace`) to steer analysis |
| [compiler-transformer](compiler-transformer.md) | Consumes validated options (`generate`, `css`, `customElement`, `hmr`, …) to select output targets and codegen behavior |
| [message_code_generation_templates](message_code_generation_templates.md) | Source templates from which the `options_*` diagnostic messages are generated |
| [svelte-public-types](svelte-public-types.md) | Publishes `CompileOptions`, `CompileResult`, `ModuleCompileOptions` — the public type contract this module enforces at runtime |
