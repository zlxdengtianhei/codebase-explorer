# client-dev-tooling_legacy-and-metadata

## 1. Introduction

`client-dev-tooling_legacy-and-metadata` is a leaf module of the Svelte 5 client runtime's development tooling layer. It provides two complementary, **dev-only** services that are compiled into applications only when the `dev` compile option is enabled:

1. **Legacy component API diagnostics** (`dev/legacy.js`) — guards that turn the Svelte 4-era component API misuse (`new Component()`, `instance.$set(...)`, `instance.$on(...)`, `instance.$destroy()`) into clear, actionable `Svelte error` exceptions instead of silent misbehavior.
2. **DOM source-location metadata** (`dev/elements.js`) — an instrumentation layer that stamps every element created from a compiled template with its original source position (`file`, `line`, `column`) plus its enclosing block/component hierarchy, enabling tooling such as the Svelte devtools browser extension and hydration mismatch reporting.

Both services follow the same design philosophy as the rest of the [client-dev-tooling](client-dev-tooling.md) family: **zero cost in production builds** — the compiler emits calls to these helpers only in `dev` mode (see [compiler-transformer_client-transform](compiler-transformer_client-transform.md)).

```
Source layout (packages/svelte/src/internal/client/dev/):
├── legacy.js        → check_target, legacy_api
└── elements.js      → add_locations (+ internal assign_location / assign_locations)
```

---

## 2. Position in the System

This module sits at the intersection of the **compiler pipeline** (which generates the calls), the **client runtime engine** (which hosts the helpers), and **external tooling** (which consumes the metadata).

```mermaid
flowchart TB
    subgraph Compiler["Compiler Pipeline — dev codegen"]
        CT["client transform<br/>(transform-client.js)"]
        TT["transform_template<br/>(transform-template/index.js)"]
    end

    subgraph Module["client-dev-tooling_legacy-and-metadata"]
        LEGACY["dev/legacy.js<br/>check_target · legacy_api"]
        ELEMS["dev/elements.js<br/>add_locations"]
    end

    subgraph Runtime["Client Runtime Engine"]
        ERR["message-catalog<br/>errors.js"]
        CTX["context-api<br/>component_context · dev_stack"]
        HYD["dom-foundation<br/>hydration state · template fns"]
        LC["legacy-compat<br/>componentApi: 4 shims"]
    end

    subgraph Consumers
        DEVTOOLS["Svelte Devtools<br/>(reads __svelte_meta)"]
        DEV["Developer<br/>(reads thrown errors)"]
    end

    CT -- "$.check_target(new.target)<br/>...$.legacy_api()" --> LEGACY
    TT -- "$.add_locations(templateFn,<br/>Comp[$.FILENAME], locations)" --> ELEMS
    LEGACY --> ERR
    LEGACY --> CTX
    ELEMS --> CTX
    ELEMS --> HYD
    LC -. "componentApi === 4<br/>replaces both guards" .-> LEGACY
    ELEMS --> DEVTOOLS
    LEGACY --> DEV
```

For the surrounding infrastructure — mutation guards, HMR support, state inspection and the client message catalog — see the parent module [client-dev-tooling](client-dev-tooling.md).

---

## 3. Core Components

### 3.1 `check_target(target)` — `dev/legacy.js`

Guards against instantiating a Svelte 5 component as a class:

```js
import App from './App.svelte';
const app = new App({ target: document.body }); // ❌ throws in dev
```

- The compiler inserts `$.check_target(new.target)` as the **first statement** of every generated component function (dev mode, when `compatibility.componentApi !== '4'`).
- `new.target` is only defined when the component function is invoked with `new`. The guard throws `component_api_invalid_new` from the client [message catalog](client-dev-tooling_message-catalog.md), including the component's source filename (read from the `FILENAME` symbol property the compiler attaches to the component function).
- The error message points users to the escape hatch: `compatibility.componentApi: '4'` for third-party code they cannot change.

```js
// dev/legacy.js (verbatim)
export function check_target(target) {
  if (target) {
    e.component_api_invalid_new(target[FILENAME] ?? 'a component', target.name);
  }
}
```

### 3.2 `legacy_api()` — `dev/legacy.js`

Produces throwing stubs for the three Svelte 4 instance methods that no longer exist in Svelte 5:

| Stub          | Thrown error             | Svelte 4 behavior replaced            |
| ------------- | ------------------------ | ------------------------------------- |
| `$destroy()`  | `component_api_changed`  | tear down the component instance      |
| `$on(...)`    | `component_api_changed`  | subscribe to component events         |
| `$set(...)`   | `component_api_changed`  | update props imperatively             |

- The compiler spreads `...$.legacy_api()` into the component's returned exports object (dev mode, `componentApi !== '4'`), so **every component instance** carries these guards.
- The closure reads `component_context.function` (the current component function, provided by [context-api](context-api.md)) to report *which* `.svelte` file received the illegal call.
- Each error message references `https://svelte.dev/e/component_api_changed` for documentation, and reminds the developer that Svelte 5 uses callbacks/props instead.

```js
// dev/legacy.js (verbatim)
export function legacy_api() {
  const component = component_context?.function;
  function error(method) {
    e.component_api_changed(method, component[FILENAME]);
  }
  return {
    $destroy: () => error('$destroy()'),
    $on: () => error('$on(...)'),
    $set: () => error('$set(...)')
  };
}
```

> **Note:** when `compatibility.componentApi === '4'` is set, the compiler emits *working* shims instead — `$.update_legacy_props` for `$set` and `$.add_legacy_event_listener` for `$on`, both supplied by [legacy-compat](legacy-compat.md). `legacy_api()` is the dev-mode **failure-with-guidance** alternative.

### 3.3 `add_locations(fn, filename, locations)` — `dev/elements.js`

A higher-order function the compiler wraps around **template instantiation calls** in dev builds:

```js
// Generated dev output (simplified):
const root_1 = $.add_locations($.from_html(`<div><span>x</span></div>`), App[$.FILENAME], [[1, 8], [1, 13]]);
// ...later, per render:
const div = root_1();
```

- `fn` — the underlying DOM factory (e.g. `$.from_html`, `$.from_tree`, `$.text`, `$.comment` from the [client DOM foundation](client-dom-renderer_dom-foundation.md)).
- `filename` — `Component[$.FILENAME]`, the symbol-keyed source filename the compiler attaches in dev builds.
- `locations` — a precomputed, nested `[line, column, childLocations?]` array with one entry per element of the template, in document order.

The returned wrapper:

1. Calls the factory to create (or hydrate) the DOM.
2. Locates the traversal start node: the DOM itself while hydrating, otherwise the first child for fragments or the node itself.
3. Delegates to the internal `assign_locations` walker.

```js
// dev/elements.js (verbatim, abridged)
export function add_locations(fn, filename, locations) {
  return (...args) => {
    const dom = fn(...args);
    var node = hydrating ? dom : dom.nodeType === DOCUMENT_FRAGMENT_NODE ? dom.firstChild : dom;
    assign_locations(node, filename, locations);
    return dom;
  };
}
```

### 3.4 `assign_location` / `assign_locations` (internal) — `dev/elements.js`

The metadata writers:

- **`assign_location(element, filename, location)`** — writes an expando property onto the element:

  ```js
  element.__svelte_meta = {
    parent: dev_stack,                                  // enclosing block/component chain
    loc: { file: filename, line: location[0], column: location[1] }
  };
  ```

  It then recurses into `element.firstChild` if the location entry carries nested child locations — giving inner elements their own metadata.

- **`assign_locations(node, filename, locations)`** — walks the sibling chain, assigning each element its location in order. While **hydrating**, it tracks a *depth counter* over Svelte's hydration comment markers (`[` / `[!` start markers, `]` end marker, see [constants](#62-shared-constants)) so that elements inside conditional branches are skipped or matched correctly, and only top-level-in-scope elements consume location entries.

---

## 4. Generated-Code Integration (Compiler Side)

Both services are pure consumers of decisions made by the client transform phase. The relevant emission logic lives in `transform-client.js` and `transform-template/index.js` (documented in [compiler-transformer_client-transform](compiler-transformer_client-transform.md)):

| Dev instrumentation emitted by the compiler                                  | Runtime entry point          |
| ---------------------------------------------------------------------------- | ---------------------------- |
| `App[$.FILENAME] = 'App.svelte'` at module top                                | `FILENAME` symbol, read by both helpers |
| `function App($$anchor, $$props) { $.check_target(new.target); ... }`        | `check_target`               |
| `return { ..., ...$.legacy_api() }` (spread into exports)                    | `legacy_api`                 |
| `const root = $.add_locations($.from_html(...), App[$.FILENAME], [[l,c],...])` | `add_locations`            |
| `$.add_svelte_meta(fn, type, component, line, column, ...)` around blocks/components | populates the `dev_stack` consumed by `assign_location` |

```mermaid
flowchart LR
    subgraph S["App.svelte source"]
        TPL["&lt;div&gt;…&lt;/div&gt;"]
    end
    subgraph C["Compile (dev = true)"]
        P["parse → analyze"]
        G1["emit App[FILENAME] = 'App.svelte'"]
        G2["emit $.check_target(new.target)"]
        G3["spread ...$.legacy_api() into exports"]
        G4["emit $.add_locations($.from_html(html),<br/>App[$.FILENAME], locations)"]
    end
    subgraph R["Runtime (browser)"]
        N1["module init: filename tag"]
        N2["new App() → error"]
        N3["app.$set() → error"]
        N4["render: DOM stamped with __svelte_meta"]
    end
    TPL --> P --> G1 & G2 & G3 & G4
    G1 --> N1
    G2 --> N2
    G3 --> N3
    G4 --> N4
```

---

## 5. Process Flows

### 5.1 Legacy API misuse → guided error

```mermaid
sequenceDiagram
    participant U as Application code
    participant CF as Compiled component fn
    participant LA as legacy_api stubs
    participant E as errors.js (message catalog)
    U->>CF: new App({ target })
    CF->>CF: check_target(new.target)
    CF-->>U: throw component_api_invalid_new<br/>("Attempted to instantiate App.svelte with `new App`…<br/>set compatibility.componentApi to 4 …")
    U->>LA: app.$set({ count: 1 })
    LA->>E: component_api_changed('$set(...)', 'App.svelte')
    E-->>U: throw Svelte error + svelte.dev/e/ link
```

### 5.2 Template rendering with location metadata

```mermaid
flowchart TD
    A["Compiler emits<br/>add_locations(from_html(...), FILENAME, locations)"] --> B{Render call}
    B -->|first render| C["factory clones template DOM"]
    B -->|hydrating| D["factory returns existing<br/>server-rendered node"]
    C --> E["start node =<br/>fragment ? firstChild : node"]
    D --> F["start node = dom itself"]
    E --> G["assign_locations walk"]
    F --> G
    subgraph G_walk["assign_locations"]
        G --> H{node is element<br/>AND depth === 0?}
        H -->|yes| I["assign_location:<br/>__svelte_meta = { parent: dev_stack,<br/>loc: { file, line, column } }"]
        I --> J["recurse into children<br/>via location[2]"]
        H -->|no| K["advance sibling"]
        J --> K
        K --> L{hydrating?}
        L -->|yes| M["track depth over<br/>[ / [! / ] comments"]
        L -->|no| N{more nodes &<br/>locations?}
        M --> N
        N -->|yes| H
        N -->|no| O["done — devtools can now<br/>map any DOM node to source"]
    end
```

---

## 6. Dependencies

### 6.1 Internal runtime dependencies

| Dependency                              | Source module                                                     | Used by                      | Purpose                                                        |
| --------------------------------------- | ----------------------------------------------------------------- | ---------------------------- | -------------------------------------------------------------- |
| `e.component_api_invalid_new`, `e.component_api_changed` | [client-dev-tooling_message-catalog](client-dev-tooling_message-catalog.md) (`../errors.js`) | `check_target`, `legacy_api` | throwing the documented, link-carrying Svelte errors           |
| `component_context`                     | [context-api](context-api.md) (`../context.js`)                    | `legacy_api`                 | resolves the current component function to report its filename |
| `dev_stack`                             | [context-api](context-api.md) (`../context.js`)                    | `assign_location`            | links `__svelte_meta.parent` into the enclosing block/component chain (built by `$.add_svelte_meta`) |
| `hydrating`                             | [client-dom-renderer](client-dom-renderer.md) DOM foundation (`../dom/hydration.js`) | `add_locations`, `assign_locations` | chooses traversal mode (fresh clone vs. server HTML)          |
| `FILENAME`, `HYDRATION_START`, `HYDRATION_START_ELSE`, `HYDRATION_END` | shared `src/constants.js`                        | all                          | symbol-keyed filename property; hydration comment markers     |
| DOM factories (`from_html`, `from_tree`, `text`, `comment`) | [client-dom-renderer_dom-foundation](client-dom-renderer_dom-foundation.md) | `add_locations` argument `fn` | the wrapped element-producing functions                      |

### 6.2 Shared constants

```js
// packages/svelte/src/constants.js
export const FILENAME = Symbol('filename');   // dev-time component property
export const HYDRATION_START = '[';           // `[` — block start marker
export const HYDRATION_START_ELSE = '[!';     // `[!` — `{:else}` branch marker
export const HYDRATION_END = ']';             // `]` — block end marker
```

### 6.3 Compiler counterpart

The `dev` flag and the `locator` (from `compiler/state.js`, see [compiler-core_compile_state](compiler-core_compile_state.md)) drive emission: `build_locations()` in `transform-template/index.js` converts each template element's `node.start` offset into `[line, column]` pairs that exactly mirror what `assign_locations` expects at runtime.

### 6.4 Compatibility boundary

```mermaid
flowchart LR
    OPT{"compatibility.componentApi"}
    OPT -->|"4"| LC["legacy-compat shims:<br/>$set → update_legacy_props<br/>$on → add_legacy_event_listener<br/>new → createClassComponent"]
    OPT -->|"default (5)"| DEV["this module (dev only):<br/>check_target + legacy_api<br/>→ throwing diagnostics"]
    OPT -->|"production build"| OFF["no code emitted —<br/>misuse fails naturally"]
```

The production-mode counterpart is *nothing*: neither the guards nor the metadata calls exist in non-dev bundles, keeping the runtime lean (verified by the treeshakeability checker, see [treeshakeability_checker](treeshakeability_checker.md)).

---

## 7. Data Contracts

### 7.1 `__svelte_meta` (expando on each instrumented `Element`)

```ts
interface SvelteMeta {
  parent: DevStackEntry | null;         // enclosing block/component chain
  loc: {
    file: string;                       // e.g. 'src/lib/App.svelte'
    line: number;                       // 1-based
    column: number;                     // 0-based
  };
}
```

`DevStackEntry` (maintained by `add_svelte_meta` in [context-api](context-api.md)) is a linked list: `{ type, file, line, column, parent, ...additional }`. Together they let a devtools extension reconstruct *why* an element exists — e.g. `div ← {#if} block ← Component.svelte ← parent slot`.

### 7.2 Locations array (compiler → runtime)

```ts
type SourceLocation = [line: number, column: number, children?: SourceLocation[]];
```

- One entry per element, **document order**, sibling-major.
- The optional third slot holds nested element locations, consumed recursively by `assign_location` via `element.firstChild`.

---

## 8. Relationship to Sibling Dev-Tooling Modules

| Sibling                                                                                       | Overlap / boundary                                                                                             |
| --------------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------- |
| [message-catalog](client-dev-tooling_message-catalog.md)                                       | supplies the errors this module throws (`component_api_invalid_new`, `component_api_changed`)                   |
| [state-inspection](client-dev-tooling_state-inspection.md)                                     | complementary introspection: `inspect`, `tracing.tag`, `log_if_contains_state`; metadata here targets DOM, not signals |
| [mutation-ownership-guards](client-dev-tooling_mutation-ownership-guards.md)                   | guards *state mutations*; this module guards *API usage* and enriches *DOM*                                     |
| [runtime-validation](client-dev-tooling_runtime-validation.md)                                 | validates bindings/snippet args at runtime; same "dev-only, fail-loud" pattern                                  |
| [hmr-support](client-dev-tooling_hmr-support.md)                                               | also relies on the compiler-injected `FILENAME` metadata ecosystem                                              |
| [legacy-compat](legacy-compat.md)                                                              | the functional alternative when `componentApi: '4'`; this module is the *diagnostic* alternative                 |
| [client-dom-renderer](client-dom-renderer.md) (lifecycle: `mount`/`hydrate`)                    | drives the `hydrating` flag consumed by `add_locations`; component instances created here carry `legacy_api` stubs |

---

## 9. Design Notes & Invariants

1. **Dev-only by construction.** Every emission is gated on `if (dev)` in the client transform. Production output contains no calls into this module, and tree-shaking can drop it entirely.
2. **Fail loud, not silently.** Instead of the Svelte 4 methods silently doing nothing (or surfacing cryptic errors), developers get named errors (`component_api_invalid_new`, `component_api_changed`) with documentation links and a migration path.
3. **Metadata is non-invasive.** Source positions are stored in a single `__svelte_meta` expando per element — no wrappers, no proxies, no behavioral change to the rendered DOM.
4. **Hydration-correct.** `assign_locations` compensates for hydration comment markers with depth tracking, so metadata lines up with server-rendered markup even across `{#if}`/`{:else}` boundaries; the wrapped factories must not be marked side-effect-free because hydration needs to walk all nodes (consistent with the template functions in [client-dom-renderer_dom-foundation](client-dom-renderer_dom-foundation.md)).
5. **Filename via symbol.** `FILENAME` is a `Symbol`, so the tag never collides with component exports and is invisible to spread/serialization — yet readable by `check_target`, `legacy_api`, `validate_binding` warnings, and devtools.
6. **Escape hatch preserved.** All diagnostics explicitly reference `compatibility.componentApi: '4'`, deferring to [legacy-compat](legacy-compat.md) when the user opts in.

## 10. Quick Reference

```js
// What the developer sees (dev build):
import App from './App.svelte';

new App({ target: document.body });
// ⛔ Svelte error: component_api_invalid_new
//    Attempted to instantiate App.svelte with `new App`, which is no longer valid in Svelte 5.
//    If this component is not under your control, set the `compatibility.componentApi`
//    compiler option to `4` to keep it working.  https://svelte.dev/e/component_api_invalid_new

app.$set({ foo: 1 });
// ⛔ Svelte error: component_api_changed
//    Calling `$set(...)` on a component instance (of App.svelte) is no longer valid in Svelte 5
//    https://svelte.dev/e/component_api_changed

// And in the Elements panel of devtools:
// <div __svelte_meta="{ parent: {...}, loc: { file: 'App.svelte', line: 1, column: 8 } }">
```
