# Transitions, Animations & Easing

## 1. Purpose and Scope

The `transitions-animations-easing` module is a leaf module of the **Public API & Built-in Feature Surface** parent. It implements Svelte's motion primitives — the entire user-facing surface for animating elements:

| Area | Location | What it provides |
|------|----------|------------------|
| **Transitions** | `packages/svelte/src/transition/` | Parameterized element transitions (`transition:`, `in:`, `out:` directives): `blur`, `fade`, `fly`, `slide`, `scale`, `draw`, `crossfade` |
| **Animations** | `packages/svelte/src/animate/` | Keyed-list flip animations (`animate:` directive): `flip` (First-Last-Invert-Play) |
| **Easing** | `packages/svelte/src/easing/` | 30 pure interpolation functions across 10 curve families (back, bounce, circ, cubic, elastic, expo, linear, quad, quart, quint, sine), each in `In`, `Out` and `InOut` variants |

The module is deliberately **framework-agnostic at its core**: every exported function is a pure factory that inspects the element's computed style and returns a declarative `TransitionConfig` / `AnimationConfig` object (`delay`, `duration`, `easing`, `css(t, u)`, `tick(t, u)`). The **client runtime engine** (see [Client Runtime Engine (Reactivity & DOM Rendering)](client-runtime-engine-reactivity-dom-rendering.md) → [client-dom-renderer_transitions](client-dom-renderer_transitions.md)) owns the actual playback: it measures progress, computes the easing-corrected `t` (and the mirrored `u = 1 - t`), and invokes the config's `css`/`tick` callbacks per frame.

## 2. Architecture Overview

```mermaid
flowchart TB
    subgraph Template["Svelte template (authoring)"]
        T1["transition:fly={{ y: 20 }}"]
        T2["in:fade / out:blur"]
        T3["animate:flip={{ duration: 200 }}"]
    end

    subgraph Compiler["Compiler Pipeline & Language Toolchain"]
        C1["TransitionDirective /<br/>AnimateDirective AST nodes<br/>(compiler-core_type_definitions)"]
        C2["Client transform visitors<br/>compiler-transformer_client-transform_directive-visitors<br/>(TransitionDirective.js, TransitionDirective for animate)"]
        C3["Runtime calls: $.transition(flags, ...) / $.animation(...)"]
    end

    subgraph Module["transitions-animations-easing (this module)"]
        A1["transition/index.js<br/>blur fade fly slide scale draw crossfade"]
        A2["transition/public.d.ts<br/>TransitionConfig + *Params types"]
        A3["animate/index.js<br/>flip"]
        A4["animate/public.d.ts<br/>AnimationConfig + FlipParams"]
        A5["easing/index.js<br/>30 easing functions"]
    end

    subgraph Runtime["Client Runtime Engine"]
        R1["internal/client/dom/elements/transitions.js<br/>transition() · animation() managers"]
        R2["Low-level animate() driver<br/>rAF scheduling, easing application,<br/>css()/tick() invocation"]
        R3["each-item manager (item.a)<br/>measure / apply / fix / unfix"]
    end

    T1 & T2 --> C1 --> C2 --> C3 --> R1
    T3 --> C1 --> C2 --> C3 --> R3 --> R1

    A1 --> A2
    A3 --> A4
    A1 -- "easing defaults:<br/>cubic_out, cubic_in_out, linear" --> A5
    A3 -- "easing default: cubicOut" --> A5
    A2 -- "EasingFunction type" --> A5

    R1 -- "consumes TransitionConfig" --> A2
    R3 -- "consumes AnimationConfig" --> A4
    R1 --> R2
```

**Key insight:** the built-in transitions hard-wire sensible easing defaults (`fly`/`slide`/`scale`/`crossfade` → `cubic_out`, `blur`/`draw` → `cubic_in_out`, `fade` → `linear`), so the easing library and the transitions are functionally coupled even though the runtime accepts *any* `EasingFunction`.

### 2.1 How a config is executed at runtime

```mermaid
sequenceDiagram
    participant TE as Runtime transition manager<br/>(Client Runtime Engine)
    participant CF as Config factory (this module)<br/>e.g. fly()
    participant DV as animate() driver
    participant DOM as Element style

    TE->>CF: fn(element, params, { direction })
    CF->>DOM: getComputedStyle(element)
    Note over CF: Snapshot target opacity/transform,<br/>split CSS units, resolve duration
    CF-->>TE: TransitionConfig { delay, duration, easing, css(t, u) }
    TE->>DV: animate(element, config, counterpart, target_t, on_finish)
    loop every animation frame
        DV->>DV: t' = easing(t), u = 1 - t'
        DV->>CF: css(t', u) → string
        DV->>DOM: element.style.cssText = result
    end
    DV->>TE: on_finish → dispatch introend/outroend
```

Details of the runtime side (intro/outro lifecycle, `inert` handling, reversal smoothing via cached `current_options`, each-item `fix()`/`unfix()` positioning) live in the [client-dom-renderer_transitions](client-dom-renderer_transitions.md) documentation and are not duplicated here.

## 3. Sub-modules

This module splits cleanly into three sub-modules, each documented in its own file (all docs share one flat directory):

### 3.1 [transitions-animations-easing_transitions.md](transitions-animations-easing_transitions.md) — Built-in Transitions
- **Files:** `packages/svelte/src/transition/index.js`, `packages/svelte/src/transition/public.d.ts`
- **Contents:** The seven built-in transitions (`blur`, `fade`, `fly`, `slide`, `scale`, `draw`, `crossfade`), the private easing defaults (`linear`, `cubic_out`, `cubic_in_out`), the shared `split_css_unit` helper, and the `TransitionConfig` / `EasingFunction` / `*Params` type contracts (`BlurParams`, `FadeParams`, `FlyParams`, `SlideParams`, `ScaleParams`, `DrawParams`, `CrossfadeParams`).

### 3.2 [transitions-animations-easing_animations.md](transitions-animations-easing_animations.md) — FLIP Animations
- **Files:** `packages/svelte/src/animate/index.js`, `packages/svelte/src/animate/public.d.ts`
- **Contents:** The `flip` animation (First-Last-Invert-Play) with transform-origin and CSS `zoom`-aware geometry, the private `get_zoom` helper, and the `AnimationConfig` / `FlipParams` type contracts. Invoked by the each-item animation manager in the Client Runtime Engine.

### 3.3 [transitions-animations-easing_easing.md](transitions-animations-easing_easing.md) — Easing Functions
- **Files:** `packages/svelte/src/easing/index.js`
- **Contents:** 30 pure easing functions covering 10 curve families (linear, back, bounce, circ, cubic, elastic, expo, quad, quart, quint, sine) in `In`, `Out` and `InOut` variants (adapted from mattdesl/eases, MIT). These are the default easings wired into the transitions above and the canonical vocabulary for user-supplied `easing` parameters.

## 4. Data Flow Summary

```mermaid
flowchart LR
    A["Author params<br/>{ delay, duration, easing, ... }"] --> B["Factory inspects<br/>getComputedStyle(node)"]
    B --> C["TransitionConfig /<br/>AnimationConfig"]
    C --> D{"css or tick?"}
    D -->|"css(t, u) → string"| E["Runtime injects style<br/>string per frame"]
    D -->|"tick(t, u) → void"| F["Runtime invokes JS<br/>callback per frame"]
    E --> G["WAAPI-adjacent frame loop<br/>(Client Runtime Engine)"]
    F --> G
    G --> H["introend / outroend /<br/>animation finished"]
```

- `t` is eased progress from 0 → 1 (1 = fully "in"); `u = 1 - t` lets `css` writers express "distance from target" symmetrically, which is what makes the same config work for both `in:` and `out:` directions.
- Config factories are called **once per transition instance** and are expected to be side-effect free apart from the initial style read; the runtime caches options so a reversing transition does not re-measure mid-flight.

## 5. Relationship to Other Modules

- **[Client Runtime Engine (Reactivity & DOM Rendering)](client-runtime-engine-reactivity-dom-rendering.md)** — the sole *consumer* of this module's return values. The `transition()`/`animation()` managers documented under [client-dom-renderer_transitions](client-dom-renderer_transitions.md) implement direction handling (`in`/`out`/`both`), `|global` vs. local scoping, Safari overflow workaround, and the each-item FLIP orchestration (`measure` → `fix` → `apply` → `unfix`) that calls `flip()`.
- **[Compiler Pipeline & Language Toolchain](compiler-pipeline-language-toolchain.md)** — `TransitionDirective`/`AnimateDirective` AST nodes are defined in [compiler-core_type_definitions](compiler-core_type_definitions.md); the client transform's [compiler-transformer_client-transform_directive-visitors](compiler-transformer_client-transform_directive-visitors.md) lower these directives into `$.transition(...)` / `$.animation(...)` runtime calls, binding the user-chosen factory from this module.
- **Sibling public API modules** — `motion/spring.js` and `motion/tweened.js` (see the parent [Public API & Built-in Feature Surface](public-api-built-in-feature-surface.md) docs) implement store-based animation and reuse the same easing vocabulary, though through a different (store-driven) mechanism.
- **Type re-exports** — `packages/svelte/types/index.d.ts` ([svelte-public-types](svelte-public-types.md)) re-exports `TransitionConfig`, `AnimationConfig`, `BlurParams`, `DrawParams`, `FadeParams`, `FlyParams`, `ScaleParams`, `SlideParams`, `CrossfadeParams` and `FlipParams` as top-level public types.

## 6. Design Notes for Maintainers

1. **Pure factories, declarative configs.** No module here touches timers, rAF, or the DOM beyond reading computed styles once. All playback logic belongs to the runtime; keep it that way when adding transitions.
2. **Internal duplicates are intentional.** `transition/index.js` re-declares `linear`, `cubic_out`, and `cubic_in_out` privately instead of importing from `easing/index.js`, to keep the bundle for simple transitions tree-shakeable; `check-treeshakeability` (Engineering Tooling) guards this.
3. **`split_css_unit` is the unit-compatibility seam.** It accepts `number | string` for `blur.amount`, `fly.x/y`, so both `{ y: 20 }` and `{ y: '20vh' }` work; re-use it for any new dimensional parameter.
4. **Dev-only warnings.** `slide` emits `w.transition_slide_display` (via the runtime's warning catalog) once per burst when used on `contents`/`inline`/`table` displays — an example of the DEV-gated diagnostics pattern shared with `client-dev-tooling`.
5. **`crossfade` is a factory-of-factories.** It returns a `[send, receive]` pair sharing two key→element maps; the fallback argument is invoked when a counterpart is missing. Its runtime behavior depends on the each-block orchestration in the Client Runtime Engine.
