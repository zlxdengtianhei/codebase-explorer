I'll read the child module documentation files first to understand each component before writing the overview.<br>
< br >Read file: $WORK/runs/e4/codewiki-svelte-2/compiler-core.md<br>
< br >Read file: $WORK/runs/e4/codewiki-svelte-2/compiler-parser.md<br>
< br >Read file: $WORK/runs/e4/codewiki-svelte-2/compiler-analyzer.md<br>
< br >Read file: $WORK/runs/e4/codewiki-svelte-2/compiler-transformer.md<br>
< br >Read file: $WORK/runs/e4/codewiki-svelte-2/compiler-preprocessor.md<br>
< br >Read file: $WORK/runs/e4/codewiki-svelte-2/compiler-migrator.md<br>
< br >Read file: $WORK/runs/e4/codewiki-svelte-2/message_code_generation_templates.md<br>
< br >[Tool results provided: compiler-core.md describes the central orchestrator of the Svelte 5 compiler at `packages/svelte/src/compiler`. It contains the public `compile`/`compileModule`/`parse`/`preprocess`/`migrate` API entry points in `index.js`, the core `compileModule`/`compileSource` pipeline orchestration in `compile/index.js`, shared state tracking in `state.js`, diagnostics mapping, options validation, AST builders (e.g. `builders.js`), and centralized type definitions. It handles the phases: parse → analyze → transform, producing JS, CSS, and auxiliary artifacts.]

[compiler-parser.md describes the parsing phase at `packages/svelte/src/compiler/phases/1-parse`. It converts raw `.svelte` source text into an AST using a hand-written recursive descent parser. Key files: `index.js` (entry, delegates to fragment/script/style parsers), `read/context.js` (parsing states/state machine), `read/script.js`, `read/style.js`, `read/jsnode.js`, `read/spaced.js`, `read/filename.js`, `utils/create.js`, `utils/html.js`, and `source.js` which wraps the original source with helpers for locating raw text and error reporting. A notable feature is JS/TS expression parsing reuse of Acorn with support for TypeScript when `lang="ts"` is used.]

[compiler-analyzer.md describes the analysis phase at `packages/svelte/src/compiler/phases/2-analyze`. It validates the AST and gathers metadata: `index.js` hosts the main analysis driver and scope-creation; `visitors/` contains per-node-type visitors (shared, client, server variants) that check component contracts, reactiveness, legacy/modern syntax distinctions, and props/context handling; `css.css-analyze.js` and `css.css-prune.js` handle CSS scoping analysis and unused-selector pruning; `scope.js` implements lexical scoping with referenced/assigned/refined tracking; `utils.js` provides helpers like extraction of RHS info and forbidden reactivenes checks. Outputs enriched AST annotations and produces scope info used later for code generation.]

[compiler-transformer.md describes the final and largest phase at `packages/svelte/src/compiler/phases/3-transform`. It lowers the analyzed AST into executable JS (client or server) plus CSS. Split into `client/` (component-to-JS with visitors for fragments, expressions, directives), `server/` (SSR generation to render functions), `css/index.js` (CSS transformation and scoping), `pages.js` and `shared/` (shared utils like javascript andcss transforms). The client transformer uses client transform visitors, server uses server transform visitors, and shared infrastructure handles common helpers. It produces Esrap-printed JS AST output, mapping source maps back to the original.]

[compiler-preprocessor.md describes the preprocessor at `packages/svelte/src/compiler/preprocess`. `src/preprocess` exposes `svelte-preprocess`-like functionality: `public.js` defines the `preprocess(source, preprocessor, options)` API; `replace_in_code.js`, `decode_map_external.js` and related files handle source-map decoding and replacement in code segments. It allows custom preprocessing of a component's source (e.g. TypeScript stripping, SCSS compilation) before the parse phase.]

[compiler-migrator.md describes the migration tool at `packages/svelte/src/compiler/migrate`. It automates upgrading Svelte 4 components to Svelte 5 syntax: converting stores usage, `export let` to `$props()`, slots to snippets, etc. It operates on the AST and text-level, leveraging the parser output and the shared `state.js` from core.]

[message_code_generation_templates.md describes the message code generation templates at `packages/svelte/scripts/process-messages/templates`. These are template files containing compile-time and runtime warnings/errors with their codes and messages. The `process-messages` script parses these templates and generates TypeScript constants and maps used by the compiler's diagnostics system and runtime warnings, keeping error codes consistent across the codebase.]<br>
< br >Now I have a comprehensive understanding of all the child modules. Let me compose the overview with a mermaid diagram visualizing the architecture. # Compiler Pipeline & Language Toolchain

## Purpose

The `Compiler_Pipeline___Language_Toolchain` module (located at `packages/svelte`) implements the complete Svelte 5 compiler — the toolchain that turns `.svelte` component source code into optimized, runnable JavaScript and CSS. It covers every stage of the compilation pipeline: **preprocessing → parsing → analysis → transformation**, along with supporting infrastructure for source migration, diagnostic message generation, and the core orchestration that ties all phases together.

The module is organized around a classic multi-phase compiler design:

1. **Preprocess** — apply user-defined transforms (e.g. TypeScript stripping, SCSS) to the raw source.
2. **Parse** — convert source text into a structured AST.
3. **Analyze** — validate the AST, build scopes, and gather metadata for code generation.
4. **Transform** — lower the AST to client-side JS, server-side rendering functions, and scoped CSS.

## Architecture

```mermaid
flowchart TB
    subgraph Entry["Public API (compiler-core)"]
        compile["compile()"]
        compileModule["compileModule()"]
        parse["parse()"]
        preprocessAPI["preprocess()"]
        migrateAPI["migrate()"]
    end

    subgraph Pipeline["Core Pipeline (compiler-core)"]
        orchestration["compile / compileSource orchestration"]
        state["Compile State"]
        options["Options Validation"]
        diagnostics["Diagnostics"]
    end

    subgraph Phase1["Phase 1: Parse"]
        parser["Recursive Descent Parser<br/>(fragment / script / style)"]
        jsTs["JS/TS Expression Parsing (Acorn)"]
        sourceWrapper["Source Wrapper"]
    end

    subgraph Phase2["Phase 2: Analyze"]
        visitors["AST Visitors<br/>(shared / client / server)"]
        scope["Scopes"]
        cssAnalyze["CSS Analysis & Pruning"]
    end

    subgraph Phase3["Phase 3: Transform"]
        clientTransform["Client Transform<br/>(visitors: expressions, directives, structure)"]
        serverTransform["Server Transform (SSR)"]
        cssTransform["CSS Transform"]
        sharedInfra["Shared Infrastructure"]
    end

    subgraph Supporting["Supporting Components"]
        preprocessor["Preprocessor Engine"]
        migrator["Svelte 4 → 5 Migrator"]
        msgTemplates["Message Code Templates<br/>(compile-time / runtime)"]
    end

    preprocessAPI --> preprocessor
    preprocessor --> parser
    parse --> parser
    parser --> jsTs
    parser --> sourceWrapper
    parser --> visitors
    visitors --> scope
    visitors --> cssAnalyze
    visitors --> clientTransform
    visitors --> serverTransform
    clientTransform --> cssTransform
    serverTransform --> sharedInfra
    clientTransform --> sharedInfra

    orchestration --> Phase1
    orchestration --> Phase2
    orchestration --> Phase3
    state --> orchestration
    options --> orchestration
    diagnostics --> msgTemplates
    migrateAPI --> migrator
    migrator --> parser
```

The data flow through the pipeline:

```mermaid
flowchart LR
    A[".svelte source"] -->|preprocess| B["Cleaned Source"]
    B -->|parse| C["AST"]
    C -->|analyze| D["Annotated AST<br/>+ scopes + metadata"]
    D -->|transform| E["Client JS /<br/>Server SSR JS"]
    D -->|transform| F["Scoped CSS"]
    E --> G["Output: js, css,<br/>warnings, ast, maps"]
    F --> G
```

## Core Components

| Component | Path | Documentation |
|---|---|---|
| **Compiler Core** | `packages/svelte/src/compiler` | [compiler-core.md](<compiler-core.md>) — the central orchestrator: public API entry points (`compile`, `compileModule`, `parse`, `preprocess`, `migrate`), pipeline coordination, shared compile state, options validation, diagnostics, AST builders, and type definitions. |
| **Compiler Parser** | `packages/svelte/src/compiler/phases/1-parse` | [compiler-parser.md](<compiler-parser.md>) — hand-written recursive descent parser that converts raw `.svelte` text into an AST, with Acorn-based JS/TS expression parsing and a source wrapper for error reporting. |
| **Compiler Analyzer** | `packages/svelte/src/compiler/phases/2-analyze` | [compiler-analyzer.md](<compiler-analyzer.md>) — validates the AST via per-node visitors (shared/client/server), builds lexical scopes, and performs CSS scoping analysis with unused-selector pruning. |
| **Compiler Transformer** | `packages/svelte/src/compiler/phases/3-transform` | [compiler-transformer.md](<compiler-transformer.md>) — the final and largest phase: lowers the analyzed AST into client-side JS, server-side SSR render functions, and scoped CSS, printing results with Esrap and source maps. |
| **Compiler Preprocessor** | `packages/svelte/src/compiler/preprocess` | [compiler-preprocessor.md](<compiler-preprocessor.md>) — the `preprocess(source, preprocessor, options)` engine enabling custom source transforms (TypeScript, SCSS, etc.) before parsing, including source-map decoding. |
| **Compiler Migrator** | `packages/svelte/src/compiler/migrate` | [compiler-migrator.md](<compiler-migrator.md>) — automated migration tool that upgrades Svelte 4 components to Svelte 5 syntax (e.g. `export let` → `$props()`, slots → snippets). |
| **Message Code Generation Templates** | `packages/svelte/scripts/process-messages/templates` | [message_code_generation_templates.md](<message_code_generation_templates.md>) — templates for compile-time and runtime warning/error codes, processed into generated TypeScript constants that power the diagnostics system. |