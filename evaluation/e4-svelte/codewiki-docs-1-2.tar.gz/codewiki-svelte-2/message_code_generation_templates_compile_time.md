# Compile-Time Message Code Generation Templates

## Overview

The `message_code_generation_templates_compile_time` module contains the two **AST transformation templates** from which the Svelte compiler's compile-time diagnostics layer is generated:

| Template | Consumed by generator | Produces |
|---|---|---|
| `packages/svelte/scripts/process-messages/templates/compile-errors.js` | `scripts/process-messages/index.js` | `src/compiler/errors.js` — one named `throw` function per compile **error** code |
| `packages/svelte/scripts/process-messages/templates/compile-warnings.js` | `scripts/process-messages/index.js` | `src/compiler/warnings.js` — one named emitter function per compile **warning** code, plus the `codes` registry |

These files are **not runtime code**. They are *meta-source*: each exports a placeholder function literally named `CODE` (with `MESSAGE`, `PARAMETER`, and `CODES` placeholder markers in its body and JSDoc). A build-time script parses the template with `acorn`, walks its AST, clones the placeholder function once per message code defined in the Markdown message catalog, and prints the result with `esrap` into the generated diagnostics modules that ship inside the `svelte` package.

Because compile-time diagnostics are the user-facing contract of the compiler (every `svelte.dev/e/<code>` link in a compiler error or warning is minted here), the templates also guarantee that **errors** and **warnings** share an identical object shape (`code`, `message`, `filename`, `start`, `end`, `position`, `frame`) via the shared `CompileDiagnostic` class.

> **Note:** This module covers the *compile-time* templates only. The remaining five templates (client/server/shared runtime errors and warnings) are documented in [message_code_generation_templates_runtime](message_code_generation_templates_runtime.md). The parent module, [message_code_generation_templates](message_code_generation_templates.md), gives an overview of all seven.

---

## Position in the System

The module sits in the **engineering toolchain**, upstream of the entire compiler. It never executes during a Svelte compilation; instead, it executes (as data) during development builds of the `svelte` package.

```mermaid
flowchart TB
    subgraph sources["Message catalog (Markdown, source of truth)"]
        MDE["messages/compile-errors/*.md"]
        MDW["messages/compile-warnings/*.md"]
    end

    subgraph this_module["This module: compile-time templates"]
        T1["templates/compile-errors.js<br/>placeholder CODE(...) + MESSAGE / PARAMETER"]
        T2["templates/compile-warnings.js<br/>placeholder CODE(...) + CODES export"]
    end

    subgraph generator["Generator script (build time)"]
        GEN["scripts/process-messages/index.js<br/>acorn → zimmerframe walk → esrap print"]
    end

    subgraph artifacts["Generated artifacts (checked into src/compiler)"]
        GE["src/compiler/errors.js<br/>error throwers (return type never)"]
        GW["src/compiler/warnings.js<br/>warning emitters + codes array"]
        GD["documentation/docs/98-reference/.generated/*.md"]
    end

    subgraph compiler["Compiler phases (consume the generated functions)"]
        P["phases/1-parse"]
        A["phases/2-analyze<br/>(incl. CSS analysis)"]
        VO["validate-options.js"]
        MG["migrate/index.js"]
    end

    MDE --> GEN
    MDW --> GEN
    T1 --> GEN
    T2 --> GEN
    GEN --> GE
    GEN --> GW
    GEN --> GD
    GE --> P
    GE --> A
    GE --> VO
    GE --> MG
    GW --> A
```

Key characteristics of this position:

- **Single source of truth**: message wording lives only in Markdown; function names, JSDoc, URLs, and parameter lists are all derived. Hand-editing `src/compiler/errors.js` or `warnings.js` is forbidden — both files start with a `/* This file is generated … Do not edit! */` banner.
- **Compile-time vs. runtime split**: error/warning *emission* at compile time goes through these templates; diagnostics raised by the shipped runtime go through the sibling runtime templates (see [message_code_generation_templates_runtime](message_code_generation_templates_runtime.md)).

---

## Core Components

### 1. `compile-errors.js::CODE` — the error-function template

```js
/**
 * MESSAGE
 * @param {null | number | NodeLike} node
 * @param {string} PARAMETER
 * @returns {never}
 */
export function CODE(node, PARAMETER) {
	e(node, 'CODE', `${MESSAGE}\nhttps://svelte.dev/e/${'CODE'}`);
}
```

This single declaration is expanded into every exported error function in `src/compiler/errors.js`. The file also carries fixed scaffolding that is copied verbatim into the output:

- **`InternalCompileError extends Error`** — extends `Error` so bundler plugins (Vite, rollup-plugin-svelte, etc.) recognize and pretty-print it. To keep the object shape identical to warnings, it wraps a private `CompileDiagnostic` instance and `Object.assign`s its properties onto the error (`code`, `message`, `filename`, `start`, `end`, `position`, `frame`). `toString()` and `toJSON()` delegate to the diagnostic. `stack` is deliberately blanked and `message` is made an *enumerable* own property.
- **`e(node, code, message)`** — the internal thrower. Accepts `null`, a numeric character offset, or a `NodeLike` (`{ start?, end? }`); normalizes it into a `[start, end]` position pair and throws the `InternalCompileError`. All generated functions are typed `@returns {never}`.

### 2. `compile-warnings.js::CODE` — the warning-function template

```js
/**
 * MESSAGE
 * @param {null | NodeLike} node
 * @param {string} PARAMETER
 */
export function CODE(node, PARAMETER) {
	w(node, 'CODE', `${MESSAGE}\nhttps://svelte.dev/e/${'CODE'}`);
}
```

Expanded into every warning emitter in `src/compiler/warnings.js`. Fixed scaffolding:

- **`InternalCompileWarning extends CompileDiagnostic`** — warnings are data, not exceptions; the class simply stamps `name = 'CompileWarning'` on top of the shared diagnostic shape.
- **`w(node, code, message)`** — the internal emitter implementing suppression semantics (see [Generated Artifact Behavior](#generated-artifact-behavior)).
- **`export const codes = CODES;`** — the only occurrence of the `CODES` placeholder among all templates; the generator rewrites it into a sorted literal array of every warning code (e.g. `'a11y_accesskey'`, `'css_unused_selector'`, …). This registry is used for `svelte-ignore` validation and tooling.

### Placeholder contract

The generator (`scripts/process-messages/index.js`) recognizes these markers inside any template:

| Marker | Kind | Rewritten to |
|---|---|---|
| `CODE` | function identifier | the message code, e.g. `block_unclosed` |
| `CODE` | string literal `'CODE'` | the message code as a string (both in `e(...)`'s code argument and inside the `https://svelte.dev/e/${'CODE'}` URL) |
| `MESSAGE` | identifier | a `Literal`, `TemplateLiteral`, or nested `ConditionalExpression` built from the Markdown message text; `%var%` placeholders become `${var}` interpolations |
| `PARAMETER` | function parameter | the message's variable names as individual parameters (e.g. `node, name, type`) |
| `CODES` | identifier | `['code_a', 'code_b', …]` — an `ArrayExpression` of every code in the category |

The JSDoc block immediately preceding `export function CODE` is cloned per function too: the `MESSAGE` line is replaced with the concrete message text, and the `PARAMETER` line is replaced by one `@param {string} name` entry per placeholder variable (variables introduced only in later message overloads become `@param {string | undefined | null} [name]`).

---

## The Code Generation Pipeline

`transform(name, dest)` in `scripts/process-messages/index.js` performs the expansion. For the compile-time module it is invoked as:

```js
transform('compile-errors',  'src/compiler/errors.js');
transform('compile-warnings', 'src/compiler/warnings.js');
```

```mermaid
flowchart TD
    S0["Read Markdown catalog<br/>messages/&lt;category&gt;/*.md"] --> S1["Extract ## CODE sections<br/>blockquote = message text,<br/>trailing prose = details<br/>(fail on duplicate codes, missing text)"]
    S1 --> S2["Sort Markdown sections in place<br/>+ regenerate reference docs<br/>docs/98-reference/.generated/&lt;category&gt;.md"]
    S2 --> A["Read template file<br/>(this module)"]
    A --> B["acorn.parse with locations:<true,<br/>collect block comments"]
    B --> C["walk AST: Identifier 'CODES'<br/>→ ArrayExpression of codes"]
    C --> D["Find ExportNamedDeclaration of<br/>FunctionDeclaration named 'CODE'<br/>+ last comment before it = JSDoc"]
    D --> E["Detach template node from body;<br/>print base program (classes, helpers, imports)"]
    E --> F{"For each message code<br/>in category"}
    F --> G["Scan message text for %var%<br/>→ build MESSAGE expression:<br/>• no vars → Literal<br/>• vars → TemplateLiteral<br/>• overloads → nested ConditionalExpression<br/>(each overload must add ≥1 new var)"]
    G --> H["Clone template node:<br/>• id CODE → code<br/>• PARAMETER → var list<br/>• Identifier MESSAGE → message expr<br/>• Literal 'CODE' → code<br/>• merge TemplateLiteral quasis"]
    H --> I["Clone JSDoc:<br/>' * MESSAGE' → message text<br/>'PARAMETER' line → @param entries<br/>(extra overload vars optional)"]
    I --> J["esrap.print clone + jsdoc;<br/>append to printed.code;<br/>push clone back into body"]
    J --> F
    F -->|done| K["Write dest with<br/>/* generated … Do not edit! */ banner"]
```

Notes on the trickier steps:

- **Message overloads**: a code may have multiple message sections, each introducing additional `%vars%`. The generator folds them into a chain of `ConditionalExpression`s keyed on the newly introduced variable, producing optional-parameter overloads (e.g. `a11y_incorrect_aria_attribute_type_boolean(node, attribute)` refining `a11y_incorrect_aria_attribute_type(node, attribute, type)`). An overload that adds no new parameter is a build error (`"Message overloads must have new parameters"`).
- **Template literal splicing**: when `MESSAGE` expands to a `TemplateLiteral`, its quasis/expressions are spliced into the surrounding `` `${MESSAGE}\nhttps://svelte.dev/e/${'CODE'}` `` literal so the output stays a single template literal; static messages are concatenated into the raw quasi instead.
- **Escaping**: backticks and `${` in message text are escaped before being embedded in raw quasis; `\r\n` is normalized to `\n` everywhere.
- **Import passthrough**: the generator preserves the templates' import statements verbatim. The templates therefore write their imports *relative to the destination directory*, not their own location — `compile-errors.js` imports `./utils/compile_diagnostic.js` and `compile-warnings.js` imports `./state.js`, which resolve correctly once printed into `src/compiler/`.
- **Watch mode**: running the script with `-w` (the `build` pipeline of the `svelte` package) watches the `messages/` tree recursively and regenerates all outputs (debounced) after any edit.

### Message catalog format

Each code is a Markdown `## ` section whose message lines are blockquotes; any non-blockquote trailing paragraphs become the "details" prose published in the generated reference docs:

```markdown
## css_unused_selector

> `:is(...)` selector is not supported…

> Unused CSS selector "%selector%"
Details paragraph here…
```

The **last** quoted section becomes the runtime message; earlier ones participate in overload construction. Details are documentation-only and never enter the generated JS.

---

## Generated Artifact Behavior

The two artifacts implement complementary compile-time semantics, both rooted in the shared `CompileDiagnostic` (documented under [compiler-core_diagnostics](compiler-core_diagnostics.md)).

### Error path — abort compilation

```mermaid
sequenceDiagram
    participant Phase as Compiler phase<br/>(parse/analyze/validate)
    participant Fn as Generated error fn<br/>e.g. block_unclosed()
    participant Err as InternalCompileError
    participant Diag as CompileDiagnostic

    Phase->>Fn: block_unclosed(node)
    Fn->>Err: e(node, 'block_unclosed', MESSAGE + url)
    Note over Err: normalizes NodeLike/offset<br/>to [start, end]
    Err->>Diag: new CompileDiagnostic(code, message, position)
    Diag-->>Err: code, message, filename,<br/>start/end (via state.locator), frame
    Note over Err: Object.assign(this, diagnostic)<br/>name = 'CompileError', stack = ''
    Err-->>Phase: throws (typed never)
    Note over Phase: compile() aborts;<br/>bundler plugin surfaces error;<br/>toString() renders code frame
```

Because `CompileDiagnostic` reads `state.source`, `state.filename`, and `state.locator` (see [compiler-core_compile_state](compiler-core_compile_state.md)), the thrown error renders a `line: column` location and a caret code frame without any extra work at the call site.

### Warning path — accumulate, filter, suppress

```mermaid
flowchart TD
    A["Analyzer / CSS pass calls<br/>generated fn, e.g. css_unused_selector(node, selector)"] --> B["w(node, code, message)"]
    B --> C{"code in ignore_map.get(node)<br/>or ignore_stack top?<br/>(svelte-ignore handling)"}
    C -->|suppressed| Z["Return silently"]
    C -->|not suppressed| D["new InternalCompileWarning<br/>(extends CompileDiagnostic)"]
    D --> E{"User warningFilter option<br/>(state.warning_filter)"}
    E -->|rejected| Z
    E -->|accepted| F["Push onto state.warnings"]
    F --> G["Collected into CompileResult.warnings;<br/>rendered by tooling / migrate"]
```

Two independent suppression layers are honored by `w()`:

1. **`svelte-ignore` comments** — the analyzer maintains `ignore_stack` (scoped, via `push_ignore`/`pop_ignore`) and `ignore_map` (per-node, for warnings emitted after the stack frame has closed). If the code appears in the innermost applicable set, the warning is dropped.
2. **`warningFilter` compile option** — user-supplied predicate consulted before the warning is stored.

The `codes` export (built from the `CODES` placeholder) is what allows the compiler to validate that an ignored code is actually a known warning.

---

## Integration with the Compiler

The generated functions are the *only* sanctioned way for compiler code to report diagnostics:

- **Errors** (e.g. `block_unclosed`, `css_global_block_invalid_combinator`, `typescript_invalid_feature`) are thrown from the parser states, analyzer visitors, `validate-options.js`, CSS analysis, and the migrator. Callers pass whatever node-like object they have; positions are resolved later against compiler state.
- **Warnings** (e.g. `css_unused_selector`, `a11y_incorrect_aria_attribute_type_id`, `options_removed_enable_sourcemap`) are emitted the same way but only accumulate — a single compilation can produce many.
- The emitted `CompileResult` (see [compiler-core_public_api](compiler-core_public_api.md)) exposes `errors` as thrown exceptions and `warnings` as the collected array, both shaped by `CompileDiagnostic`, which is also the shape published in `packages/svelte/types/index.d.ts`.

Consuming modules and their details are documented under [compiler-core](compiler-core.md), with the parse phase in [compiler-parser](compiler-parser.md), analysis in [compiler-analyzer](compiler-analyzer.md), and options validation in [compiler-core_options_validation](compiler-core_options_validation.md).

---

## Design Notes & Invariants

1. **One shape, two behaviors.** Errors must be `Error` subclasses (bundler plugin integration); warnings must be plain serializable data (`toJSON`). Wrapping a shared `CompileDiagnostic` and copying properties keeps `Object.keys(error)` identical to `Object.keys(warning)`.
2. **No stack noise.** `InternalCompileError` assigns `this.stack = ''` *inside the constructor* — as a class field it would become an enumerable own property and break shape parity.
3. **Templates are destination-relative.** Imports (`./state.js`, `./utils/compile_diagnostic.js`) resolve only after printing into `src/compiler/`; moving the generated files breaks them.
4. **Codes are URLs.** Every generated function appends `\nhttps://svelte.dev/e/<code>`, making the code identifier itself part of the public documentation contract. Renaming a code is therefore a breaking change for tooling and docs links.
5. **Determinism.** Sections are re-sorted in the Markdown catalog on every run and outputs are fully derived, so regeneration is idempotent and reviewable in diffs.
6. **Fail loudly at build time.** Duplicate codes across categories, a code without message text, and overloads without new parameters all abort generation rather than shipping subtle runtime bugs.
7. **Documentation is generated in lockstep.** The same run writes `documentation/docs/98-reference/.generated/compile-errors.md` and `compile-warnings.md`, keeping the public reference aligned with the binary.

---

## How to Add a New Compile-Time Diagnostic

1. **Choose the channel**: does the condition make compilation impossible (error → `messages/compile-errors/`) or merely suspect (warning → `messages/compile-warnings/`)?
2. **Add a Markdown section** in the appropriate category file: `## my_new_code`, followed by `> message text` (use `%placeholder%` for interpolated variables; add extra quoted sections if you need optional-parameter overloads, each introducing at least one new variable).
3. **Regenerate**: run the `svelte` package build (or `process-messages` with `-w` during development). `src/compiler/errors.js` / `warnings.js`, the `codes` array, JSDoc, and the reference docs are updated automatically.
4. **Emit it** from a phase: for errors call the generated function (typed `never`, so control flow is preserved); for warnings call it with the relevant node so `svelte-ignore` scoping applies. Analyzer-side details are in [compiler-analyzer](compiler-analyzer.md).
5. **Never edit the generated files** — the banner comment and CI diff checks will (rightly) reject it.

---

## Related Modules

- [message_code_generation_templates](message_code_generation_templates.md) — parent module covering the whole generation subsystem.
- [message_code_generation_templates_runtime](message_code_generation_templates_runtime.md) — sibling templates for client/server/shared runtime diagnostics (different scaffolding: `DEV`-gated plain `Error`s instead of `CompileDiagnostic`s).
- [compiler-core_diagnostics](compiler-core_diagnostics.md) — the generated outputs, `CompileDiagnostic`, `get_code_frame`, and `svelte-ignore` extraction, as seen from the compiler's perspective.
- [compiler-core_compile_state](compiler-core_compile_state.md) — compiler state (`warnings`, `ignore_stack`, `ignore_map`, `warning_filter`, `locator`) that the generated emitters bind to.
- [compiler-core_public_api](compiler-core_public_api.md) — `compile`/`compileModule`, where thrown errors and collected warnings become `CompileResult`.
- [compiler-analyzer](compiler-analyzer.md) — heaviest consumer of generated warning emitters (template, accessibility, and CSS checks).
