# Client DOM Renderer — Attributes & Events (`client-dom-renderer_attributes-events`)

> **Module scope:** `packages/svelte/src/internal/client/dom/elements/` — the runtime layer that applies declarative **attributes, properties, and event handlers** to real DOM elements, and keeps them synchronized with Svelte's reactive signal graph.

---

## 1. Introduction

Every Svelte component eventually compiles down to plain JavaScript that must manipulate the DOM. This module is the *bridge* between the compiled template instructions and the browser: it turns attribute objects produced by the compiler into actual DOM writes, and it wires up event handlers using an efficient **delegation strategy**.

It consists of three co-located files:

| File | Responsibility |
|---|---|
| `dom/elements/attributes.js` | Reactive attribute/property application, attribute spreading, custom-element and form-input special cases |
| `dom/elements/events.js` | Listener creation, event delegation at the root, propagation control, SSR event replay, dev-mode handler validation |
| `dom/elements/misc.js` | Element-level edge cases: `autofocus`, textarea hydration, document-level form-reset coordination |

The module is a child of **[client-dom-renderer](client-dom-renderer.md)**, which in turn belongs to the **Client Runtime Engine (Reactivity & DOM Rendering)**. It consumes services from **[client-reactivity-engine](client-reactivity-engine.md)** (signals, effects, scheduling) and **[client-dom-renderer_dom-foundation](client-dom-renderer_dom-foundation.md)** (hydration flags, task queues, DOM operations).

**Why a dedicated module?** Attributes and events are the two highest-frequency, most browser-quirk-ridden surfaces of a UI framework. Centralizing them lets Svelte:

1. Diff attribute objects once (`set_attributes`) instead of per-attribute effects.
2. Register a **single root listener per delegated event type** instead of one listener per element.
3. Run all user event handlers **outside the reactive context**, preventing cross-contamination between user code and Svelte's internal effect tracking.
4. Handle hydration edge cases (`value`/`checked`/`defaultValue`, `src`/`srcset`, SSR `onload`/`onerror` replay) in one auditable place.

---

## 2. Position in the System

```
Client Runtime Engine (Reactivity & DOM Rendering)
└── client-dom-renderer
    ├── lifecycle            ← mount / hydrate / unmount (entry points)
    ├── dom-foundation       ← templates, operations, hydration flags, tasks
    ├── control-flow-blocks  ← if/each/await/snippet rendering
    ├── bindings             ← two-way bindings (uses this module's primitives)
    ├── custom-elements      ← custom element wrapper (uses set_custom_element_data)
    ├── transitions          ← transition/animation plumbing
    └── attributes-events    ← ★ THIS MODULE ★
```

Compiled output from **[compiler-transformer_client-transform](compiler-transformer_client-transform.md)** (visitors such as `Attribute`, `SpreadAttribute`, `RegularElement`, `OnDirective`) emits direct calls into this module:

```js
// Schematic (not literal output) of what compiled code does:
element(node);                                  // from dom/blocks/svelte-element.js
attribute_effect(node, () => ({                 // dynamic attributes → reactive effect
  class: cls, disabled: flag, onclick: handler
}));
event('click', node, handler);                  // on:click directive → listener
```

---

## 3. Architecture

```mermaid
flowchart TB
    subgraph Compiler["Compiler pipeline — compile time"]
        VIS["client-transform visitors:<br/>Attribute · SpreadAttribute · OnDirective · RegularElement"]
    end

    subgraph Module["client-dom-renderer_attributes-events"]
        direction TB
        subgraph ATTR["attributes.js"]
            AEF["attribute_effect"]
            SA["set_attributes — spread diff"]
            SETA["set_attribute"]
            PROPS["set_value / set_checked / set_selected<br/>set_default_value / set_default_checked"]
            CED["set_custom_element_data"]
            XLINK["set_xlink_attribute"]
            RID["remove_input_defaults"]
        end
        subgraph EVTS["events.js"]
            CREATE["create_event / on / event"]
            DEL["delegate"]
            HEP["handle_event_propagation"]
            REPLAY["replay_events"]
            APPLY["apply — dev guard"]
        end
        subgraph MISC["misc.js"]
            AF["autofocus"]
            RTC["remove_textarea_child"]
            FRL["add_form_reset_listener"]
        end
    end

    subgraph RE["client-reactivity-engine"]
        GET["runtime.js — get, active_reaction/effect"]
        EFF["effects.js — block, effect, branch,<br/>destroy_effect, teardown"]
        FLAT["async.js — flatten"]
    end

    subgraph FOUND["client-dom-renderer_dom-foundation"]
        HYD["hydration.js — hydrating, set_hydrating"]
        TASK["task.js — queue_micro_task, queue_idle_task"]
        OPS["operations.js — get_first_child, clear_text_content"]
    end

    subgraph SIB["sibling renderer modules"]
        SEL["bindings/select.js — init_select, select_option"]
        BSH["bindings/shared.js — without_reactive_context"]
        ATTACH["attachments.js — attach"]
        CS["class.js / style.js — set_class, set_style"]
    end

    LIFECYCLE["client-dom-renderer_lifecycle<br/>mount / hydrate / unmount"]
    ROOTL["Root event listener (document)"]

    VIS -->|"emits runtime calls"| AEF
    VIS -->|"emits runtime calls"| CREATE
    AEF --> GET
    AEF --> EFF
    AEF --> FLAT
    AEF --> SA
    AEF --> SEL
    AEF --> ATTACH
    SA --> SETA
    SA --> CS
    SA -->|"on* keys"| CREATE
    SA -->|"on* keys"| DEL
    SETA --> HYD
    CED --> HYD
    CREATE --> HEP
    HEP --> BSH
    HEP --> GET
    LIFECYCLE -->|"registers root_event_handles"| DEL
    DEL --> ROOTL
    ROOTL -->|"delegated events"| HEP
    REPLAY --> TASK
    RID --> TASK
    RID --> FRL
    RTC --> OPS
    AF --> TASK
```

**Key architectural properties:**

- **Unidirectional data flow:** signals → `attribute_effect` → `set_attributes` diff → DOM mutation. The DOM is never a *source* of truth; two-way flows are handled by [client-dom-renderer_bindings](client-dom-renderer_bindings.md), which sits *on top of* this module.
- **Delegation by default:** for common bubble-phase event types (decided by `is_delegated` from the shared `src/utils.js`, the same list the compiler uses), handlers are stored on element **expandos** (`element.__click`, `element.__input`, …) and a single root listener walks the propagation path.
- **Context isolation:** all entry points that invoke *user* code (`set_custom_element_data`, `handle_event_propagation`, `apply`) clear `active_reaction`/`active_effect` first so that user side effects cannot accidentally capture Svelte-internal signal dependencies.

---

## 4. Component Reference

### 4.1 `attributes.js` — attribute & property application

| Export | Kind | Purpose |
|---|---|---|
| `attribute_effect(element, fn, sync, async, css_hash, skip_warning)` | effect factory | Creates a reactive **block effect** that re-evaluates `fn` and applies the resulting attribute object whenever its inputs change. Also drives **attachments** (symbol keys with `ATTACHMENT_KEY`) and `<select>` value syncing. |
| `set_attributes(element, prev, next, css_hash, skip_warning)` | diff/apply | The workhorse: diffs `next` against `prev`, mutates `next` into the "current" snapshot, and dispatches to specialized setters (`set_class`, `set_style`, event wiring, property vs. attribute decisions). Returns the new snapshot. |
| `set_attribute(element, attribute, value, skip_warning)` | setter | Low-level single-attribute setter. Chooses property vs. `setAttribute`, handles hydration (`src`/`srcset`/`href` are deliberately **not** reset to avoid network refetch), and the `loading` attribute symbol. |
| `set_value` / `set_checked` | property setters | Property writes with memoization via the element's `__attributes` cache — redundant DOM writes are skipped. Treats `null`/`undefined` identically. |
| `set_selected(option, selected)` | setter | Sets the `selected` **attribute** (not the property) so form reset reflects it; guards against clobbering user selection. |
| `set_default_value` / `set_default_checked` | setters | Write `defaultValue`/`defaultChecked` while **preserving** the live `value`/`checked` — the correct semantics for template-level `value`/`checked` attributes. |
| `remove_input_defaults(input)` | hydration | Removes SSR-rendered `value`/`checked` attributes *after hydration* (deferred via idle task) while preserving runtime values. Registers `input.__on_r` for the form-reset listener. |
| `set_custom_element_data(node, prop, value)` | setter | Custom-element-aware setter: consults a cached list of prototype setters; falls back to `setAttribute` with stringification. Runs entirely outside the active reaction/effect and suspends hydration mode to avoid re-entering sibling custom-element lifecycle code. |
| `set_xlink_attribute(dom, attribute, value)` | setter | Namespaced setter for SVG `xlink:*` attributes. |
| `CLASS`, `STYLE` | symbols | Compile-time markers that force routing through `set_class`/`set_style` even when the plain `class`/`style` keys are absent (scoped-CSS hash handling). |
| *(internal)* `get_attributes(element)` | cache | Lazily creates `element.__attributes` — a per-element memo storing `IS_CUSTOM_ELEMENT`, `IS_HTML`, and last-written attribute values. |
| *(internal)* `get_setters(element)` | cache | Walks the prototype chain up to `Element.prototype`, collecting property **setters**; cached per tag name in `setters_cache`. Powers the property-vs-attribute decision. |
| *(internal)* `check_src_in_dev_hydration` + `src_url_equal` / `srcset_url_equal` | dev diagnostics | Dev-only hydration-mismatch warnings for `src`/`srcset` that differ only by URL resolution. |

**Special keys recognized by `set_attributes`:**

| Key pattern | Handling |
|---|---|
| `class` | Routed to `set_class` (supports `clsx`-style objects/arrays and the scoped-CSS hash). |
| `style` | Routed to `set_style`; also forced via the `STYLE` symbol. |
| `on<event>` | Event wiring — delegated (expando + `delegate()`) or direct (`create_event`); `…capture` suffix stripped into `capture: true`. |
| `$$*` prefix | Internal bookkeeping — skipped. |
| `autofocus` | Deferred focus via `misc.js#autofocus`. |
| `value` / `__value` (non-custom-element) | Written as `element.value = element.__value = v` (Lit-compatible semantics). |
| `selected` on `<option>` | `set_selected` (attribute-based). |
| `value`/`checked` set to `null` | Attribute removed **while preserving** `defaultValue`/`defaultChecked`, distinguishing "removal after initial render" (`prev !== undefined`) from first render. |
| `defaultValue` / `defaultChecked` | Direct property assignment. |
| setter on prototype + non-string value (or custom element) | Property assignment. |
| `<option value={null|undefined}>` | Normalized to empty string (attribute removal would otherwise make value equal text content). |
| symbol key with `ATTACHMENT_KEY` description | Not applied by `set_attributes`; intercepted by `attribute_effect`, which creates/destroys **attachment** effects via `branch(() => attach(...))`. |

### 4.2 `events.js` — listener management & delegation

| Export | Kind | Purpose |
|---|---|---|
| `all_registered_events` | `Set<string>` | Global registry of every event type that uses delegation. |
| `root_event_handles` | `Set<fn>` | Callbacks (registered by each mounted root, see [client-dom-renderer_lifecycle](client-dom-renderer_lifecycle.md)) that install real root listeners for newly delegated event types. |
| `delegate(events)` | registration | Adds names to `all_registered_events` and notifies all `root_event_handles` so the root listener picks them up. |
| `create_event(name, dom, handler, options)` | factory | Wraps a handler in `target_handler`; in the bubble phase it first runs `handle_event_propagation` (so delegated handlers fire in correct order), then the user handler *outside the reactive context*. Defers attachment for `pointer*`/`touch*`/`wheel` via microtask (Chrome `cloneNode` bug). |
| `on(element, type, handler, options)` | API | `addEventListener` wrapper that preserves handler ordering relative to delegated (attribute-style) handlers; returns a removal function. |
| `event(name, dom, handler, capture, passive)` | compiled `on:` runtime | Creates the listener; registers teardown-based removal when the target is `body`, `window`, `document`, or a media element (Firefox `canplay` quirk). |
| `handle_event_propagation(event)` | delegation engine | Bound to the **root listener**. Walks `event.composedPath()` from the target toward the root, invoking each element's `__<event>` expando handler, proxying `event.currentTarget`, skipping already-handled subtrees of nested mounts (`event.__root`), and aggregating errors. |
| `replay_events(dom)` | hydration | The server renders `onload`/`onerror` **attributes** on elements to catch events firing *before* hydration finishes (stored on `dom.__e`). This function removes those attributes and re-dispatches the stored event (if the element is still connected) via microtask. |
| `apply(thunk, element, args, component, loc, …)` | dev guard | Invokes an event-attribute handler; in dev, warns (with filename/line/col and a fix suggestion) when the handler is not a function — e.g. the user wrote `onclick={handler()}` instead of `onclick={handler}`. |
| `target_handler` | internal | The per-listener closure created by `create_event`. |

**Notable behaviors of `handle_event_propagation`:**

- **Nested mounts:** `event.__root` records where handling stopped; a parent document/window listener will not re-run handlers for the subtree of a nested `mount()`, but resets `__root` so programmatically re-dispatched events are processed again.
- **`currentTarget` proxying:** `event.currentTarget` is redefined as a getter that always returns the element currently being processed, then deleted afterwards.
- **Disabled elements:** delegated handlers on `disabled` elements are skipped — *unless* the element is the event's original target (it could only emit if it wasn't disabled when the event started).
- **Error aggregation:** the first handler error is rethrown synchronously after the walk; subsequent errors are re-thrown one per microtask so they don't mask each other.
- **Firefox GC pinning:** `last_propagated_event` holds a reference to the event object between microtasks — otherwise Firefox may collect the event and lose the `__root` expando, causing double handling.

### 4.3 `misc.js` — element edge cases

| Export | Purpose |
|---|---|
| `autofocus(dom, value)` | Sets the `autofocus` property and queues a **microtask** to call `dom.focus()` — only if `document.activeElement` is still `body`, so an earlier-focused element wins. |
| `remove_textarea_child(dom)` | During hydration, clears `<textarea>` children: SSR text content corresponds to `defaultValue`, and leaving it breaks form reset. |
| `add_form_reset_listener()` | Idempotent, capture-phase document `reset` listener. One tick after a non-prevented reset it re-runs every element's `__on_r` hook (registered by `remove_input_defaults`) so stripped defaults stay consistent with the reset state. |

---

## 5. Reactive Attribute Pipeline

`attribute_effect` is the standard entry point for *dynamic* attributes. One effect per element (per attribute spread) — not one per attribute.

```mermaid
sequenceDiagram
    autonumber
    participant C as Compiled component
    participant F as flatten (async.js)
    participant E as attribute_effect
    participant R as Reactivity engine
    participant S as set_attributes
    participant D as DOM

    C->>E: attribute_effect(el, fn, sync, async, css_hash)
    E->>F: flatten(sync, async, callback)
    F->>E: values ready (async deps resolved)
    E->>R: block(callback body)
    loop whenever a tracked signal changes
        R->>E: re-run effect body
        E->>R: next = fn(...values.map(get))
        E->>S: set_attributes(el, prev, next, css_hash)
        S->>S: diff prev vs next (keys + symbols)
        S->>D: setAttribute / property writes / removeAttribute
        S->>D: set_class / set_style routing
        S->>S: on* keys → create_event or delegate
        S-->>E: return current snapshot
        E->>E: prev = current
        Note over E,R: symbol keys with ATTACHMENT_KEY:<br/>branch() new attachments,<br/>destroy_effect() removed ones
    end
    opt element is a SELECT
        E->>R: effect(() => select_option(el, prev.value, true) + init_select(el))
    end
```

Design highlights:

- **`block` vs. `effect`:** the attribute application runs as a *block effect*, which the reactivity engine can destroy along with its owning branch — attribute updates never outlive their element.
- **Snapshot diffing:** `set_attributes` mutates `next` into the *current* state and returns it; keys present in `prev` but missing in `next` are pre-set to `null` so they get removed. Unchanged values are skipped (with an escape hatch: `undefined` values are still applied if the element still carries the attribute, to allow attribute removal).
- **Class/style shortcuts:** `next.class` is normalized through `clsx`; when only a scoped-CSS hash exists, `next.class = null` is used to *force* a call to `set_class`.
- **Select coordination:** for `<select>`, a second effect keeps the selection in sync after options render — connecting to [client-dom-renderer_bindings](client-dom-renderer_bindings.md) (`select_option`, `init_select`).

---

## 6. Event Handling Pipeline

### 6.1 Delegated events (default path)

```mermaid
sequenceDiagram
    autonumber
    participant M as mount/hydrate (lifecycle)
    participant DG as delegate()
    participant B as Browser
    participant RL as Root listener (document)
    participant H as handle_event_propagation
    participant X as Element expandos (__click…)
    participant U as User handler

    M->>DG: root_event_handles.add(register)
    DG->>DG: all_registered_events.add(type)
    DG->>RL: install one listener per delegated type
    Note over X: set_attributes stored handler:<br/>element.__click = fn
    B->>RL: user clicks a child button
    RL->>H: handle_event_propagation.call(root, event)
    H->>H: path = event.composedPath()
    H->>H: skip subtree if event.__root already handled<br/>(nested mounts)
    loop from target toward root
        H->>X: current_target['__' + event.type]
        alt handler present and element not disabled
            X->>U: handler.call(current_target, event)
        end
        H->>H: stop on event.cancelBubble or reaching root
    end
    H->>H: event.__root = root; delete currentTarget proxy;<br/>restore reactive context
```

Why delegation?

- **Ordering guarantee:** because `create_event`'s bubble-phase wrapper runs `handle_event_propagation` *before* the element's own listener body, declaratively-delegated handlers always run before/around imperative listeners in a predictable order (see the documented rationale in `on()`).
- **Cheaper teardown:** elements can be removed without `removeEventListener` bookkeeping; the expando dies with the element.
- **Fewer listeners:** one root listener per event type regardless of element count.

### 6.2 Direct (non-delegated) events

For event types that don't bubble, must be captured, or are unsuitable for delegation (e.g. media element events), `event()` attaches a real listener via `create_event`. Cleanup is registered through `teardown()` only for global targets (`document`, `window`, `body`, media elements) — element listeners die with the element.

### 6.3 SSR event replay (hydration)

```mermaid
flowchart TD
    A["SSR output carries onload/onerror attributes"] --> B["Early event fires before hydration"]
    B --> C["Attribute handler stores event on dom.__e"]
    C --> D["Hydration runs"]
    D --> E["replay_events(dom): removes onload/onerror"]
    E --> F{"dom.__e set and dom connected?"}
    F -->|yes| G["queueMicrotask: dom.dispatchEvent(event)"]
    F -->|no| H["discard"]
```

### 6.4 Dev-mode handler validation (`apply`)

`apply` wraps event-attribute invocation. If the thunk produces a non-function (typically `onclick={handler()}` evaluated eagerly, or `onclick` forgotten), it emits `event_handler_invalid` from [client-dev-tooling](client-dev-tooling.md) with the exact filename/line/column and a concrete suggestion (`add a leading () =>` / `remove the trailing ()`), re-throws any evaluator error, then invokes the handler.

---

## 7. Hydration Coordination

This module owns several hydration-only behaviors. Hydration state lives in [client-dom-renderer_dom-foundation](client-dom-renderer_dom-foundation.md) (`hydrating` / `set_hydrating`); this module *reacts* to it:

```mermaid
flowchart TD
    H["hydrating = true (hydrate() started)"] --> Q{"Element kind?"}
    Q -->|"input with value/checked"| R1["remove_input_defaults:<br/>queue_idle_task strips attributes,<br/>preserves runtime values,<br/>registers __on_r"]
    Q -->|"textarea"| R2["remove_textarea_child:<br/>clear children (= SSR defaultValue)"]
    Q -->|"src/srcset/href attr"| R3["set_attribute: skip rewrite to avoid<br/>network refetch; dev-only mismatch check<br/>(src_url_equal / srcset_url_equal)"]
    Q -->|"custom element"| R4["set_attributes / set_custom_element_data:<br/>temporarily suspend hydrating to prevent<br/>re-entering element lifecycle logic"]
    Q -->|"element with SSR onload/onerror"| R5["replay_events"]
    R1 --> FR["add_form_reset_listener:<br/>capture-phase 'reset' → one tick later<br/>re-run __on_r on all form controls"]
    R2 --> FR
```

**Form-reset correctness:** Svelte distinguishes *template* (`defaultValue`-backed) values from *runtime* values. `remove_input_defaults` and `remove_textarea_child` exist solely so that a user pressing "Reset" in a form behaves per HTML semantics — and the deferred idle-task strategy keeps hydration fast while the `__on_r` hook keeps reset behavior correct even if the reset fires before the idle callback runs.

---

## 8. Caches & Performance Design

| Cache | Scope | Contents | Benefit |
|---|---|---|---|
| `element.__attributes` | per element | `IS_CUSTOM_ELEMENT`, `IS_HTML`, memoized attribute values | O(1) change detection; namespace/case handling decided once |
| `setters_cache` | per tag name | List of prototype property setters (walked up to `Element.prototype`) | Avoids `getOwnPropertyDescriptors` walks on every attribute write |
| `element.__<event>` expandos | per element | Delegated handler (possibly `[fn, ...data]` tuples) | No listener objects; natural cleanup with element |
| `all_registered_events` | global | Delegated event type names | One root listener per type |
| `last_propagated_event` | module | Pin to current event | Firefox GC workaround preserving `event.__root` |

Additional performance strategies:

- `queue_idle_task` for default-stripping during hydration (keeps hydration off the critical path).
- `queue_micro_task` deferral for pointer/touch/wheel listeners (Chrome `cloneNode` bug) and for `autofocus`.
- Single-diff-per-element model in `attribute_effect` avoids N attribute effects per element.
- Property-vs-attribute decision prefers **attributes** unless a prototype setter exists and the value is non-string (or the element is a custom element) — attribute writes are cheaper and serialize correctly for SSR.

---

## 9. Reactivity Context Isolation

A recurring pattern in this module: **user code must never run inside Svelte's reactive context.**

```mermaid
flowchart LR
    A["Entry point invoking user code"] --> B{"Which?"}
    B -->|"handle_event_propagation"| C["set_active_reaction(null)<br/>set_active_effect(null)<br/>… run handlers …<br/>finally: restore"]
    B -->|"set_custom_element_data"| D["same + suspend<br/>hydrating flag"]
    B -->|"create_event handler call"| E["without_reactive_context(fn)<br/>(bindings/shared.js)"]
    C --> F["Prevents user handlers from<br/>capturing internal dependencies<br/>(e.g. sync blur events during<br/>DOM removal in Chromium)"]
    D --> F
    E --> F
```

Consequences:

- Signal reads *inside* event handlers are untracked — handlers are imperative escape hatches.
- Setting custom-element properties can synchronously run other custom elements' lifecycle code; isolating the reaction/effect (and hydration flag) prevents attribution bugs and infinite effect loops.

---

## 10. Dependencies & Integration Map

### Depends on

| Dependency | From | Used for |
|---|---|---|
| `get`, `active_reaction`, `active_effect`, `set_active_*` | [client-reactivity-engine](client-reactivity-engine.md) (`runtime.js`) | Reading signals; context save/restore |
| `block`, `effect`, `branch`, `destroy_effect`, `teardown` | [client-reactivity-engine](client-reactivity-engine.md) (`reactivity/effects.js`) | Effect creation/destruction for attributes, select sync, attachments, listener teardown |
| `flatten` | [client-reactivity-engine](client-reactivity-engine.md) (`reactivity/async.js`) | Resolving async attribute expressions |
| `hydrating`, `set_hydrating` | [client-dom-renderer_dom-foundation](client-dom-renderer_dom-foundation.md) (`hydration.js`) | Hydration-aware setters |
| `queue_micro_task`, `queue_idle_task` | [client-dom-renderer_dom-foundation](client-dom-renderer_dom-foundation.md) (`task.js`) | Deferred work |
| `get_first_child`, `clear_text_content` | [client-dom-renderer_dom-foundation](client-dom-renderer_dom-foundation.md) (`operations.js`) | Textarea hydration |
| `init_select`, `select_option`, `without_reactive_context` | [client-dom-renderer_bindings](client-dom-renderer_bindings.md) (`bindings/select.js`, `bindings/shared.js`) | Select value sync; untracked handler execution |
| `set_class`, `set_style` | sibling `class.js` / `style.js` | Routed attribute application |
| `attach` | sibling `attachments.js` | `ATTACHMENT_KEY` symbol handling in `attribute_effect` |
| `is_delegated`, `is_capture_event`, `normalize_attribute` | `src/utils.js` (shared compiler/runtime list) | Delegation decisions identical at compile and runtime |
| `clsx`, `get_descriptors`, `get_prototype_of`, `define_property`, `is_array` | `internal/shared/*` | Utility functions |
| `hydration_attribute_changed`, `event_handler_invalid` warnings | [client-dev-tooling](client-dev-tooling.md) | Dev diagnostics |
| `FILENAME`, `ATTACHMENT_KEY`, `LOADING_ATTR_SYMBOL`, `NAMESPACE_HTML`, `UNINITIALIZED` | client constants | Bookkeeping |

### Consumed by

| Consumer | Usage |
|---|---|
| Compiled component code via [compiler-transformer_client-transform](compiler-transformer_client-transform.md) | `attribute_effect`, `set_attribute`, `set_attributes`, `event`, `apply`, `remove_input_defaults`, `set_custom_element_data`, `set_xlink_attribute`, … |
| [client-dom-renderer_lifecycle](client-dom-renderer_lifecycle.md) (`mount`/`hydrate`) | Registers `root_event_handles` during render; hydration replay |
| [client-dom-renderer_bindings](client-dom-renderer_bindings.md) | Binding effects compose with attribute setters (e.g. `bind_value` + `set_value`) |
| [client-dom-renderer_custom-elements](client-dom-renderer_custom-elements.md) | Property/attribute application inside the custom element wrapper |
| [client-dom-renderer_control-flow-blocks](client-dom-renderer_dom-foundation.md) / blocks | Elements created by blocks rely on attribute effects for props |
| `on()` (imperative listener API) | Used by actions and transition plumbing in [client-dom-renderer_transitions](client-dom-renderer_transitions.md) |

---

## 11. Design Notes, Invariants & Edge Cases

1. **One effect per attribute spread.** `attribute_effect` uses a single `block` effect and re-diffs the whole object; granular per-attribute effects would multiply scheduler overhead.
2. **`null` and `undefined` are equivalent** for `value`/`checked`/attribute removal, except where explicitly preserved (`defaultValue` semantics, `<option value>`).
3. **`src`/`srcset`/`href` are never rewritten during hydration** — equality checks are expensive and an incorrect rewrite triggers a network refetch; dev builds surface genuine mismatches instead.
4. **Delegated handler lists support extra arguments** (`[fn, ...data]` tuples), enabling parameterized delegated handlers without closures per element.
5. **`cancelBubble` is honored** by the delegation walker — user handlers can stop propagation of delegated handling, not just the native event.
6. **Attribute case sensitivity:** for non-HTML namespaces, attribute names are normalized (`normalize_attribute`) because SVG/MathML are case-sensitive in the DOM but the template markup may not be.
7. **Custom elements get property-first semantics** only when a real setter exists *and* the element is registered (unregistered elements use an object-heuristic to avoid caching setters too early, since upgrades can add setters).
8. **`style` is always set via `set_attribute`** in the spread path (string form) to avoid the `style` property setter, which behaves inconsistently across engines; `set_style` handles the structured path.
9. **Errors never abort the whole propagation walk silently** — the first error propagates synchronously, the rest are re-thrown on individual microtasks.

---

## 12. Related Documentation

- [client-dom-renderer](client-dom-renderer.md) — parent module: template creation, blocks, renderer overview
- [client-dom-renderer_lifecycle](client-dom-renderer_lifecycle.md) — `mount` / `hydrate` / `unmount`; registers root event handles
- [client-dom-renderer_dom-foundation](client-dom-renderer_dom-foundation.md) — hydration flags, task queues, DOM operations, templates
- [client-dom-renderer_bindings](client-dom-renderer_bindings.md) — two-way bindings built atop these primitives (incl. select sync)
- [client-dom-renderer_custom-elements](client-dom-renderer_custom-elements.md) — custom element wrapper consuming `set_custom_element_data`
- [client-dom-renderer_transitions](client-dom-renderer_transitions.md) — transitions/animations using listener APIs
- [client-reactivity-engine](client-reactivity-engine.md) — signals, effects, batching/scheduling underneath this module
- [client-dev-tooling](client-dev-tooling.md) — dev warnings and validation surfaced by this module
- [compiler-transformer_client-transform](compiler-transformer_client-transform.md) — the compiler visitors that emit calls into this module
