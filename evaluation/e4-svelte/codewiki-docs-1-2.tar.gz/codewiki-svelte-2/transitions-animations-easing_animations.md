# Animations (`svelte/animate`)

## 1. Introduction

The **animations** module (`packages/svelte/src/animate/`) provides Svelte's built-in *layout animation* primitives. It currently exposes a single animation function, **`flip`**, which animates an element between its old and new position when it is *moved* by a keyed `{#each}` block reconciliation.

Unlike transitions (which run when elements enter or leave the DOM — see [transitions-animations-easing_transitions.md](transitions-animations-easing_transitions.md)), animations run when an element *stays* in the DOM but changes position. They are activated with the `animate:` directive:

```svelte
{#each list as item (item.id)}
    <li animate:flip>{item.label}</li>
{/each}
```

The module consists of:

| File | Responsibility |
|---|---|
| `packages/svelte/src/animate/index.js` | `flip` implementation (plus internal `get_zoom` helper) |
| `packages/svelte/src/animate/public.d.ts` | Public types: `FlipParams`, `AnimationConfig` |

It is one of three siblings under the `transitions-animations-easing` family:

- **Transitions** → [transitions-animations-easing_transitions.md](transitions-animations-easing_transitions.md)
- **Animations** (this document)
- **Easing** → [transitions-animations-easing_easing.md](transitions-animations-easing_easing.md)

---

## 2. Purpose & Core Functionality

### 2.1 The FLIP technique

`flip` implements the **F**irst, **L**ast, **I**nvert, **P**lay animation strategy (coined by Paul Lewis):

1. **First** — measure where the element *was* (`from` bounding rect).
2. **Last** — let the DOM update, then measure where the element *is* (`to` bounding rect).
3. **Invert** — apply a transform that visually places the element back at its old position (translation + scale).
4. **Play** — animate the transform back to identity, producing a smooth movement.

### 2.2 Function signature

```js
flip(node, { from, to }, params) → AnimationConfig
```

| Argument | Type | Description |
|---|---|---|
| `node` | `Element` | The element being animated. |
| `{ from, to }` | `{ from: DOMRect, to: DOMRect }` | Bounding rects captured *before* and *after* the DOM change. Provided by the runtime. |
| `params` | `FlipParams` | Optional configuration. |

### 2.3 Parameters (`FlipParams`)

| Param | Type | Default | Description |
|---|---|---|---|
| `delay` | `number` | `0` | Milliseconds before the animation starts. |
| `duration` | `number \| ((len: number) => number)` | `(d) => Math.sqrt(d) * 120` | Duration in ms. As a function it receives the *distance* (px) between start and end — longer distances animate longer, following a `√d` curve. |
| `easing` | `(t: number) => number` | `cubicOut` | Easing function from the [easing module](transitions-animations-easing_easing.md). |

### 2.4 Return value (`AnimationConfig`)

`flip` returns an `AnimationConfig` consumed by the runtime animation driver (see [client-dom-renderer_transitions.md](client-dom-renderer_transitions.md)):

```ts
{
    delay: number,
    duration: number,          // resolved by invoking duration(len)
    easing: (t: number) => number,
    css: (t: number, u: number) => string   // keyframe style generator
}
```

The `css` callback interpolates the inverted transform: `t` goes 0→1 over the animation and `u = 1 - t`; at `t = 0` the element is visually at its *old* position/scale, at `t = 1` the transform is neutral and the existing `transform` style is restored.

---

## 3. Geometry Computation (how `flip` works)

`flip` performs several coordinate transforms so the animation remains correct even under parent transforms and CSS `zoom`:

1. **Preserve existing transforms** — the element's current computed `transform` (if not `'none'`) is captured and prepended to the generated keyframe style, so pre-existing rotations etc. are not clobbered.
2. **Normalize the transform origin** — `style.transformOrigin` is parsed and divided by `node.clientWidth` / `clientHeight`, yielding a normalized origin pair `(ox, oy)` in `[0, 1]`.
3. **Compensate for parent transforms and zoom** —
   - `get_zoom(node)` resolves the *effective* CSS zoom: it prefers the modern `element.currentCSSZoom` property, otherwise it walks up the ancestor chain multiplying each element's computed `zoom` value.
   - Scale factors `sx = clientWidth / to.width / zoom` and `sy = clientHeight / to.height / zoom` cancel out any scaling applied by ancestors between the two measurements.
4. **Locate the transform origin before and after** — the measured rect is offset by the normalized origin:
   - start: `fx = from.left + from.width * ox`, `fy = from.top + from.height * oy`
   - end: `tx = to.left + to.width * ox`, `ty = to.top + to.height * oy`
5. **Invert** — translation `dx = (fx - tx) * sx`, `dy = (fy - ty) * sy`; relative scale `dsx = from.width / to.width`, `dsy = from.height / to.height`.
6. **Resolve duration** — if `duration` is a function, it is called once with the Euclidean distance `√(dx² + dy²)`.

The returned `css(t, u)` then composes:

```
transform: <existing> translate(u·dx px, u·dy px) scale(t + u·dsx, t + u·dsy)
```

```mermaid
flowchart TD
    A["flip(node, {from, to}, params)"] --> B["Read computed style:<br/>transform + transformOrigin"]
    B --> C["Normalize origin (ox, oy) ÷ client size"]
    A --> D["get_zoom(node)<br/>(currentCSSZoom or<br/>ancestor zoom product)"]
    C --> E["sx, sy = clientSize ÷ toSize ÷ zoom"]
    D --> E
    E --> F["Origin positions:<br/>fx, fy (start) / tx, ty (end)"]
    F --> G["Invert: dx, dy translation<br/>dsx, dsy relative scale"]
    G --> H{"duration is fn?"}
    H -- yes --> I["duration(√(dx² + dy²))"]
    H -- no --> J["duration as-is"]
    I --> K["AnimationConfig<br/>{ delay, duration, easing, css(t,u) }"]
    J --> K
```

---

## 4. Architecture & Component Relationships

The module is intentionally tiny — it is a *pure calculator*. The surrounding machinery lives elsewhere:

```mermaid
flowchart LR
    subgraph Public["Public API — svelte/animate"]
        FLIP["flip()<br/><i>src/animate/index.js</i>"]
        TYPES["FlipParams / AnimationConfig<br/><i>src/animate/public.d.ts</i>"]
    end

    subgraph Easing["easing module"]
        CUBIC["cubicOut (default easing)<br/>see transitions-animations-easing_easing.md"]
    end

    subgraph Compiler["Compiler pipeline<br/>see compiler-transformer_client-transform_*"]
        AD["AnimateDirective AST node"]
        ADV["AnimateDirective visitor →<br/>emits $.animation(node, fn, params)<br/>in after_update"]
        EBV["EachBlock visitor →<br/>sets EACH_IS_ANIMATED flag"]
    end

    subgraph Runtime["Client runtime<br/>see client-dom-renderer_transitions.md"]
        MGR["animation(element, get_fn, get_params)<br/>per-each-item manager<br/>measure / apply / fix / unfix"]
        DRV["animate(element, options, ...)<br/>Web Animations API driver<br/>(keyframes, easing, delay, tick)"]
        EACH["each block reconciliation"]
    end

    USER["Template:<br/>&#123;#each items as item (item.key)&#125;<br/>  &lt;li animate:flip&gt;&lt;/li&gt;<br/>&#123;/each&#125;"]

    USER --> AD
    AD --> ADV
    AD --> EBV
    ADV --> MGR
    EBV --> EACH
    MGR -->|"calls fn(element, {from,to}, params)"| FLIP
    FLIP -->|"imports default easing"| CUBIC
    FLIP -->|"typed by"| TYPES
    MGR --> DRV
    EACH -->|"measure() → apply()"| MGR
```

**Key relationships**

- **Compile time** — the `AnimateDirective` AST node (name + optional parameter expression) is collected by the `RegularElement` visitor and lowered by the `AnimateDirective` client visitor into a `$.animation(node, fn, params)` call, deliberately scheduled in `after_update` so it always runs *after* `bind:this` actions. When the containing `{#each}` is keyed and hosts an animate directive, the `EachBlock` visitor adds the `EACH_IS_ANIMATED` flag so reconciliation knows to measure elements around the DOM update. Details: [compiler-transformer_client-transform_directive-visitors.md](compiler-transformer_client-transform_directive-visitors.md) and [compiler-transformer_client-transform_structural-visitors.md](compiler-transformer_client-transform_structural-visitors.md).
- **Run time** — the runtime `animation()` helper attaches a per-each-item animation manager (`item.a`) exposing the FLIP hooks; the `animate()` driver turns the returned `AnimationConfig` into Web Animations API keyframes. Details: [client-dom-renderer_transitions.md](client-dom-renderer_transitions.md).
- **Easing** — `cubicOut` is imported from the easing module as `flip`'s default easing; all easing functions are interchangeable. Details: [transitions-animations-easing_easing.md](transitions-animations-easing_easing.md).

---

## 5. Runtime Lifecycle (process flow)

The sequence below shows what happens when an array reorder causes a keyed `{#each}` item to move:

```mermaid
sequenceDiagram
    participant State as Reactive state<br/>(array reorder)
    participant Each as each block<br/>reconciliation
    participant Mgr as item.a<br/>animation manager
    participant Flip as flip()
    participant WAAPI as animate() driver<br/>(Web Animations API)
    participant DOM as DOM

    State->>Each: collection changes
    Note over Each: EACH_IS_ANIMATED flag set<br/>(determined at compile time)
    Each->>Mgr: measure()
    Mgr->>DOM: from = el.getBoundingClientRect()
    Each->>DOM: apply reconciliation (move element)
    Each->>Mgr: apply()
    Mgr->>DOM: to = el.getBoundingClientRect()
    alt position changed
        Mgr->>Flip: fn(element, { from, to }, params)
        Flip-->>Mgr: AnimationConfig { delay, duration, easing, css }
        Mgr->>Mgr: fix() — pin size, absolute-position,<br/>translate to pre-update spot
        Mgr->>WAAPI: element.animate(keyframes…)
        WAAPI->>DOM: play interpolated transform,<br/>eased via easing(t)
        WAAPI->>Mgr: on_finish → abort(), unfix()
        Mgr->>DOM: restore original inline styles
    else position unchanged
        Mgr->>Mgr: no animation needed
    end
```

Notes on the manager's internal hooks (owned by the runtime, not this module):

- **`measure()`** — captures the *First* rect before DOM mutation.
- **`apply()`** — captures the *Last* rect after mutation, invokes the user's animation function (`flip`), and starts playback. Any in-flight animation is aborted first.
- **`fix()`** / **`unfix()`** — temporarily pin the element (`position: absolute`, fixed width/height, compensating translate) so the animation is not distorted by layout during playback; styles are restored on finish. `fix()` is skipped when a `getAnimations()`-visible animation is already running, so bidirectional/crossfade transitions are not fought over (relevant for `crossfade`, see [transitions-animations-easing_transitions.md](transitions-animations-easing_transitions.md)).
- Because `<svelte:element>` can swap its tag without unmounting, `animation()` re-binds the element on the existing manager rather than creating a new one.

---

## 6. Usage Rules & Example

Constraints enforced by the compiler/runtime design:

1. `animate:` must be on an element that is the **sole child of a keyed `{#each}` block** (the key is what identifies "the same" item across reorders). The `EachBlock` visitor relies on this to detect animation at compile time.
2. The directive is applied to *moving* elements only — intro/outro needs are handled by [transitions](transitions-animations-easing_transitions.md).
3. Only one animation directive per element; the parameter expression (e.g. `animate:flip={{ duration: 300 }}`) is evaluated lazily via a thunk and re-read each time an animation starts.
4. Compiled output schedules `$.animation(...)` in `after_update`, guaranteeing refs bound via `bind:this` exist first.

```svelte
<script>
    import { flip } from 'svelte/animate';
    let list = $state([
        { id: 1, label: 'alpha' },
        { id: 2, label: 'beta' },
        { id: 3, label: 'gamma' }
    ]);

    function shuffle() {
        list = list.toSorted(() => Math.random() - 0.5);
    }
</script>

<button onclick={shuffle}>shuffle</button>

{#each list as item (item.id)}
    <!-- distance-based duration + custom easing -->
    <li animate:flip={{ duration: (d) => Math.min(d * 2, 400), easing: cubicInOut }}>
        {item.label}
    </li>
{/each}
```

---

## 7. Data Flow Summary

```mermaid
flowchart TD
    P["FlipParams<br/>(delay, duration, easing)"] --> F
    R["DOMRect from / DOMRect to<br/>(measured by runtime manager)"] --> F
    CS["computed style:<br/>transform, transformOrigin<br/>zoom / currentCSSZoom"] --> F
    F["flip() geometry engine"] --> C["AnimationConfig"]
    C --> K["css(t, u) keyframes →<br/>element.animate()"]
    K --> V["Smooth layout animation<br/>of moved each items"]
```

Inputs flow strictly one way: the runtime supplies measured geometry, the developer supplies `FlipParams`, the browser supplies computed styles (transform origin + zoom), and `flip` emits a declarative `AnimationConfig` with a stateless `css(t, u)` generator that the animation driver samples into keyframes.

---

## 8. Design Notes & Edge Cases

- **Distance-proportional duration** — the default `(d) => Math.sqrt(d) * 120` keeps small nudges snappy and long travel perceptible without linear time scaling, using a square-root curve.
- **Zoom correctness** — legacy browsers without `currentCSSZoom` fall back to multiplying computed `zoom` up the ancestor chain (`get_zoom`), matching the [CSS Viewport draft](https://drafts.csswg.org/css-viewport/#effective-zoom) behavior.
- **Existing transforms are respected** — a pre-set `transform` (e.g. a constant rotation) is baked into every generated keyframe, so `flip` composes rather than overrides.
- **Transform-origin aware** — anchoring measurements at the element's transform origin prevents "hinge" artifacts when the element is also scaled.
- **Treeshakeability** — the module is a self-contained pure function; bundlers drop it entirely when `flip` is unused (see [treeshakeability_checker.md](treeshakeability_checker.md)).

## 9. Related Modules

- [transitions-animations-easing_transitions.md](transitions-animations-easing_transitions.md) — enter/leave transitions (`fade`, `fly`, `crossfade`, …) and `TransitionConfig`.
- [transitions-animations-easing_easing.md](transitions-animations-easing_easing.md) — the easing function library (`cubicOut` and friends).
- [client-dom-renderer_transitions.md](client-dom-renderer_transitions.md) — the runtime `animation()` manager and `animate()` WAAPI driver that consume `AnimationConfig`.
- [client-dom-renderer_control-flow-blocks.md](client-dom-renderer_control-flow-blocks.md) — the `each` block whose reconciliation drives FLIP measurement.
- [compiler-transformer_client-transform_directive-visitors.md](compiler-transformer_client-transform_directive-visitors.md) — how `animate:` directives are lowered to `$.animation(...)` calls.
- [public-api.md](public-api.md) — where `svelte/animate` sits in the package's public export surface.
