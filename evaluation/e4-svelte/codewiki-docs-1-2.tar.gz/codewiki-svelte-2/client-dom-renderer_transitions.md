# client-dom-renderer_transitions

## 1. Introduction

The `client-dom-renderer_transitions` module is the **client-side runtime for Svelte's transition and animation directives**. It is a sub-module of [`client-dom-renderer`](client-dom-renderer.md) inside the *Client Runtime Engine (Reactivity & DOM Rendering)* subsystem.

It implements the machinery behind:

- `transition:`, `in:` and `out:` directives → the exported **`transition()`** function
- `animate:` directives inside keyed `{#each}` blocks → the exported **`animation()`** function
- the default **`linear`** easing used when a `TransitionConfig` does not specify one

Source: `packages/svelte/src/internal/client/dom/elements/transitions.js`

The module's central job is to **bridge the reactive effect lifecycle** (branch creation / pause / destroy, managed by the [`client-reactivity-engine`](client-reactivity-engine.md)) **with the browser's Web Animations API (WAAPI)**. It does not contain the transition implementations themselves (`fade`, `fly`, `crossfade`, `flip`, …) — those live in the public [`transitions-animations-easing`](transitions-animations-easing.md) module and are passed in as callbacks by compiler-generated code.

```
Compiler emits:  $.transition(flags, element, () => fn, params)   // transition:/in:/out:
                 $.animation(element, () => fn, params)           // animate: (keyed each)
Public API provides: fn → AnimationConfig { delay, duration, easing, css, tick }
This module:     orchestrates when/why animations run and drives WAAPI
```

---

## 2. Module at a Glance

| Export | Kind | Purpose |
| --- | --- | --- |
| `transition(flags, element, get_fn, get_params)` | runtime function (called as `$.transition(...)`) | Creates a **TransitionManager**, attaches it to the active effect, and schedules intros. The effects engine later calls `tm.in()` / `tm.out(fn)` on branch resume / pause. |
| `animation(element, get_fn, get_params)` | runtime function (called as `$.animation(...)`) | Creates an **EachAnimationManager** (measure / fix / apply / unfix) attached to the current `EachItem`, enabling FLIP-style move animations when an each block reorders. |
| `linear` | easing `(t) => t` | Identity easing; the default when a transition config omits `easing`. |
| `animate(...)` *(internal)* | WAAPI driver | Converts an `AnimationConfig` into real keyframes, handles delay via a dummy animation, smooth reversal via a `counterpart`, `tick` callbacks through the rAF loop, and clean abort semantics. |
| `css_to_keyframe`, `css_property_to_camelcase`, `dispatch_event` *(internal)* | helpers | CSS-string → `Keyframe` parsing; kebab→camelCase property conversion; `introstart`/`introend`/`outrostart`/`outroend` event dispatch. |

---

## 3. Architecture & Component Relationships

The module sits at the intersection of four subsystems. Compiler-generated calls feed it transition functions; the reactivity engine tells it *when* to run them; sibling DOM-renderer modules supply the environment guards; and the browser animates the pixels.

```mermaid
flowchart TB
    subgraph Compiler["Compiler pipeline (build time)"]
        TV["TransitionDirective visitor<br/>(client transform)"]
        EV["Element / each visitors<br/>(animate: codegen)"]
    end

    subgraph Public["Public API"]
        TF["transition functions<br/>fade, fly, blur, slide, scale, draw, crossfade"]
        EAS["easing functions<br/>cubic_out, ..."]
        FLIP["flip() (AnimateFn)"]
    end

    subgraph This["client-dom-renderer_transitions (this module)"]
        T["transition()"]
        A["animation()"]
        AN["animate() (internal)"]
        KF["css_to_keyframe()<br/>css_property_to_camelcase()"]
        DE["dispatch_event()"]
    end

    subgraph Engine["client-reactivity-engine"]
        RT["runtime.js<br/>active_effect / untrack"]
        FX["effects.js<br/>pause_effect / resume_effect"]
        EF2["effect() factory"]
        LP["loop.js (rAF task loop)"]
    end

    subgraph Siblings["client-dom-renderer siblings"]
        LC["lifecycle (render.js)<br/>should_intro"]
        EACH["control-flow-blocks (each.js)<br/>current_each_item"]
        BS["bindings/shared.js<br/>without_reactive_context"]
        TASK["task.js<br/>queue_micro_task"]
    end

    WAAPI["Browser WAAPI<br/>element.animate()"]

    TV -->|"$.transition(flags, ...)"| T
    EV -->|"$.animation(element, ...)"| A
    TF -->|"AnimationConfig"| AN
    EAS -->|"easing"| AN
    FLIP -->|"config from {from,to}"| AN

    T --> AN
    A --> AN
    AN --> KF
    T --> DE
    T --> EF2
    AN --> LP
    AN --> WAAPI
    T -.->|"registers TransitionManager"| FX
    FX -.->|"tm.in() / tm.out(destroy)"| T
    T --> LC
    T --> RT
    T --> BS
    A --> EACH
    AN --> TASK
```

Key relationships:

- **Upstream (compile time):** the client transform's directive visitors emit `$.transition(...)` / `$.animation(...)` calls — see [`compiler-transformer_client-transform_directive-visitors`](compiler-transformer_client-transform_directive-visitors.md).
- **Upstream (public API):** user-chosen transition/animate functions return `AnimationConfig` objects — see [`transitions-animations-easing`](transitions-animations-easing.md).
- **Triggering:** the effects engine owns *when* transitions run: `resume_effect` triggers intros, `pause_effect` triggers outros and defers effect destruction until they finish — see [`client-reactivity-engine`](client-reactivity-engine.md).
- **Sibling integration:** `should_intro` (from `render.js`, documented in [`client-dom-renderer_lifecycle`](client-dom-renderer_lifecycle.md)) gates initial intros; `current_each_item` (documented in [`client-dom-renderer_control-flow-blocks`](client-dom-renderer_control-flow-blocks.md)) links an `animate:` directive to its each item.

---

## 4. Runtime Data Structures

`transition()` and `animation()` do not animate immediately — they **attach manager objects** to effects / each items, which are driven later by the engine.

```mermaid
classDiagram
    class Effect {
        +number f
        +Effect parent
        +TransitionManager[] transitions
    }
    class TransitionManager {
        +boolean is_global
        +in()
        +out(fn)
        +stop()
    }
    class EachItem {
        +EachAnimationManager a
        +Effect e
    }
    class EachAnimationManager {
        +Element element
        +measure()
        +apply()
        +fix()
        +unfix()
    }
    class AnimationFacade {
        +abort()
        +deactivate()
        +reset()
        +t() number
    }
    Effect "1" o-- "0..*" TransitionManager : e.transitions
    EachItem "1" o-- "0..1" EachAnimationManager : item.a
    TransitionManager ..> AnimationFacade : created per intro/outro
    EachAnimationManager ..> AnimationFacade : created per move
```

**TransitionManager contract** (consumed by `effects.js`):

| Method | Invoked by | Behaviour |
| --- | --- | --- |
| `in()` | `resume_effect` → `resume_children` | Restores `element.inert`, dispatches `introstart`, aborts a stale unidirectional intro, then runs `animate(..., t2 = 1, ...)`; on completion dispatches `introend`, aborts the animation, clears cached options and restores the saved `overflow` style. If the manager is intro-only and an outro is running, the outro is aborted and reset instead. |
| `out(fn)` | `pause_effect` → `run_out_transitions` | Sets `element.inert = true`, dispatches `outrostart`, runs `animate(..., t2 = 0, ...)`; `fn` (which destroys the effect) runs only after `outroend`. Outro-only managers simply call `fn()` immediately. |
| `stop()` | teardown paths | Aborts any in-flight intro and outro. |

**EachAnimationManager contract** (consumed by the each-block reconciler): `measure()` captures the "from" rect, `fix()`/`unfix()` bracket DOM moves, `apply()` captures the "to" rect and starts the flip animation. See [§7.4](#74-animateflip-move-lifecycle-keyed-each).

---

## 5. `transition()` — Directive Registration

### 5.1 Flag decoding

| Flag | Set by | Meaning |
| --- | --- | --- |
| `TRANSITION_IN` | `transition:` / `in:` | Plays an intro when the owning branch effect resumes. |
| `TRANSITION_OUT` | `transition:` / `out:` | Plays an outro when the owning branch effect pauses (delaying destruction). |
| `TRANSITION_GLOBAL` | `|global` modifier | Intro plays even if the state change originated outside the owning block; without it the transition is **local**. |

`direction` is derived as `'both' | 'in' | 'out'` and passed to the transition function, so bidirectional configs can adapt (e.g. `crossfade`).

### 5.2 Registration and intro scheduling

```mermaid
flowchart TD
    A["transition(flags, element, get_fn, get_params)"] --> B["decode flags:<br/>is_intro / is_outro / is_global"]
    B --> C["build TransitionManager { in, out, stop }<br/>stash element.inert + overflow style"]
    C --> D["push manager onto active effect:<br/>(e.transitions ??= []).push(tm)"]
    D --> E{"is_intro && should_intro()?"}
    E -- "no" --> F["done — in()/out() fire later via<br/>resume_effect / pause_effect"]
    E -- "yes" --> G{"is_global?"}
    G -- "yes" --> J["effect(() => untrack(() => tm.in()))"]
    G -- "no" --> H["walk up effect tree:<br/>skip EFFECT_TRANSPARENT parents<br/>(snippets, else-if branches)"]
    H --> I{"nearest BLOCK_EFFECT<br/>has EFFECT_RAN flag?"}
    I -- "yes" --> J
    I -- "no" --> F
    J --> F
```

Notes:

- **Local-transition semantics:** a local intro only plays if the state change happened *in the same block*. This is decided by walking the effect tree from the directive's effect, skipping `EFFECT_TRANSPARENT` effects (snippet bodies, else-if chains), and checking whether the nearest `BLOCK_EFFECT` is currently initializing (no `EFFECT_RAN` flag means the block itself is new — i.e. the change *did* originate here, so the intro plays).
- **`should_intro()`** (from `render.js`) returns `false` for `mount(..., { intro: false })` and for hydration, suppressing first intros — see [`client-dom-renderer_lifecycle`](client-dom-renderer_lifecycle.md).
- The intro runs inside a child `effect()` with `untrack`, so animation bookkeeping reads never create reactive dependencies.

---

## 6. `animate()` — The WAAPI Driver

`animate(element, options, counterpart, t2, on_finish)` is the single place where DOM animations are actually created. `t2` is the target progress: `1` for intros/moves, `0` for outros.

### 6.1 Keyframe pipeline

```mermaid
flowchart TD
    A["animate(element, options, counterpart, t2, on_finish)"] --> B{"options is a function?<br/>(deferred, e.g. crossfade)"}
    B -- "yes" --> C["queue_micro_task(() => resolve config<br/>after the DOM update)"]
    C --> Z["return synchronous facade<br/>{ abort, deactivate, reset, t } forwarding to the real animation"]
    B -- "no" --> D["counterpart.deactivate()<br/>(neutralises its on_finish)"]
    D --> E{"options.duration truthy?"}
    E -- "no" --> F["on_finish() immediately;<br/>return no-op facade with t() = t2"]
    E -- "yes" --> G{"is_intro && no counterpart?"}
    G -- "yes" --> H["tick(0, 1);<br/>keyframes = [css(0,1), css(0,1)]"]
    G -- "no" --> I["keyframes = []"]
    H --> J["dummy animation:<br/>element.animate(keyframes, { duration: delay, fill: 'forwards' })"]
    I --> J
    J --> K["onfinish: cancel dummy;<br/>t1 = counterpart.t() ?? 1 - t2;<br/>counterpart.abort()"]
    K --> L["delta = t2 - t1"]
    L --> M["n = ceil(duration / (1000/60));<br/>for i = 0..n:<br/>t = t1 + delta * easing(i / n)<br/>push keyframe css_to_keyframe(css(t, 1 - t))"]
    M --> N{"css output includes<br/>overflow: hidden?"}
    N -- "yes" --> O["element.style.overflow = 'hidden'<br/>(Safari &lt; 18 workaround)"]
    N -- "no" --> P
    O --> P["if tick: loop(() => tick(t, 1 - t))<br/>while animation.playState === 'running'"]
    P --> Q["main animation:<br/>element.animate(keyframes, { duration, fill: 'forwards' })"]
    Q --> R["onfinish: tick(t2, 1 - t2); on_finish()"]
```

### 6.2 Behavioural details worth knowing

- **Deferred transitions.** If `options` is a *function* (the shape `crossfade` produces), it must be called **after** the DOM update. `animate` queues the call via `queue_micro_task` and immediately returns a facade object, so all callers stay synchronous. Aborting before the microtask simply cancels it.
- **Smooth reversal.** `TransitionManager` caches the `AnimationConfig` in `current_options` while a transition is in flight, so an in-progress intro that reverses into an outro re-uses the same config (a changed `duration` would otherwise make the element jump). The new animation starts from `counterpart.t()` — the exact progress of the animation being replaced — rather than from `0`/`1`.
- **`counterpart.deactivate()`** no-ops the replaced animation's `on_finish`, preventing the old direction from firing completion events after it has been superseded.
- **Delay as a real animation.** The delay is implemented as a dummy animation with `fill: 'forwards'`. Besides respecting browser devtools time-multipliers, this guarantees keyframes are only created once the DOM has settled (see [svelte#14732](https://github.com/sveltejs/svelte/issues/14732)).
- **Frame-accurate keyframes.** Keyframes are sampled at `ceil(duration / (1000/60))` steps so the eased `t2` endpoint is never missed, with the `easing` function applied during sampling — the browser interpolates linearly between samples.
- **`tick` callbacks** (used by JS-driven transitions such as `spring`/`tweened` integrations) are driven by the shared rAF `loop()` from [`client-reactivity-engine`](client-reactivity-engine.md) batching/scheduling, and stop as soon as `playState !== 'running'`.
- **Leak & ghost-finish prevention** in `abort()`: `animation.effect = null` (avoids a Chromium leak) and `animation.onfinish = noop` (prevents `onfinish` firing after `cancel()` — [svelte#13681](https://github.com/sveltejs/svelte/issues/13681)).
- **`reset()`** on an outro facade calls `tick(1, 0)` so an aborted outro leaves the DOM in the "visible" state.

---

## 7. Process Flows

### 7.1 Intro — effect branch resumes

```mermaid
sequenceDiagram
    autonumber
    participant E as effects.js (engine)
    participant TM as TransitionManager
    participant A as animate()
    participant B as WAAPI / loop

    Note over E: branch resumes (e.g. {#if} flips true)
    E->>TM: in()
    TM->>TM: element.inert = inert (restore)
    TM->>TM: dispatch introstart (without_reactive_context)
    TM->>A: animate(element, get_options(), outro, 1, onfinish)
    A->>A: outro?.deactivate()
    A->>B: dummy animate(keyframes, { duration: delay, fill: 'forwards' })
    B-->>A: onfinish (delay elapsed)
    A->>A: t1 = outro.t() ?? 0 — continue from current progress
    A->>A: sample keyframes css(t, 1-t) with easing
    A->>B: animate(keyframes, { duration, fill: 'forwards' })
    loop while running (only if tick provided)
        A->>B: loop(() => tick(t, 1 - t))
    end
    B-->>A: onfinish
    A->>TM: onfinish → dispatch introend, abort animation,<br/>restore overflow, clear current_options
```

### 7.2 Outro — effect branch pauses

```mermaid
sequenceDiagram
    autonumber
    participant E as pause_effect (effects.js)
    participant TM as TransitionManager
    participant A as animate()
    participant B as WAAPI

    Note over E: state change pauses a branch
    E->>TM: out(destroy_callback)
    alt not an outro transition
        TM->>E: fn() immediately (destroy now)
    else outro transition
        TM->>TM: element.inert = true
        TM->>TM: dispatch outrostart
        TM->>A: animate(element, get_options(), intro, 0, onfinish)
        A->>A: intro?.deactivate() — cancel stale completion
        A->>B: delay dummy → keyframes towards t = 0
        B-->>A: onfinish
        A->>E: onfinish → dispatch outroend → fn() → destroy_effect
    end
```

The `out(fn)` callback design is what makes outros *destruction-deferring*: the effects engine cannot destroy the branch until the DOM animation has visually completed.

### 7.3 Transition registration (compile-time contract)

```mermaid
sequenceDiagram
    autonumber
    participant C as generated component code
    participant T as transition()
    participant E as active Effect

    C->>T: $.transition(flags, el, () => fn, params)
    T->>T: decode flags, capture inert + overflow
    T->>E: (e.transitions ??= []).push(manager)
    T->>T: if intro && should_intro():<br/>decide local vs global via effect tree
    opt intro should run now
        T->>T: effect(() => untrack(manager.in))
    end
    Note over E: manager now participates in<br/>resume_effect / pause_effect
```

### 7.4 `animate:flip` move lifecycle (keyed each)

Implemented by `animation()` in cooperation with the each-block reconciler — see [`client-dom-renderer_control-flow-blocks`](client-dom-renderer_control-flow-blocks.md).

```mermaid
sequenceDiagram
    autonumber
    participant R as each reconciliation
    participant M as EachItem.a manager
    participant FN as get_fn() e.g. flip()
    participant A as animate()

    Note over R: derived collection reordered
    R->>M: measure() — capture "from" bounding rect
    R->>M: fix() — position:absolute + fixed size + translate offset<br/>(skipped if element.getAnimations() is non-empty)
    R->>R: DOM nodes moved into new order
    R->>M: unfix() — restore original inline styles
    R->>M: apply()
    M->>M: abort previous animation; capture "to" rect
    alt element actually moved
        M->>FN: fn(element, { from, to }, params)
        FN-->>M: AnimationConfig
        M->>A: animate(element, config, undefined, 1, done)
    end
```

Details:

- The manager is stored once per item (`item.a ??= {...}`); for `<svelte:element>` tag swaps `animation()` re-points `item.a.element` to the new element instead of creating a second manager, so a concurrent reconciliation stays coherent.
- `fix()` deliberately **destructures** computed style values (`position`, `width`, `height`) before mutating, because the style objects have getters and e.g. switching to `position: absolute` would otherwise change the measured `width`. It also refuses to fix while animations run, so a `crossfade`'s `translate(...)` is never overruled by the fix-up transform.
- `measure`/`fix`/`apply`/`unfix` are orchestrated by the reconciler inside the batch commit, which is why move animations start *after* the DOM is in its final layout.

---

## 8. Dependencies

### 8.1 On other internal modules

| Dependency | Used for | Documented in |
| --- | --- | --- |
| `internal/shared/utils.js` (`noop`, `is_function`) | abort/deactivate no-ops; detecting deferred transition configs | [`internal-shared-utils`](internal-shared-utils.md) |
| `reactivity/effects.js` (`effect`) | wrapping scheduled intros in a real effect | [`client-reactivity-engine`](client-reactivity-engine.md) |
| `runtime.js` (`active_effect`, `active_reaction`, `set_active_effect`, `set_active_reaction`, `untrack`) | finding the owning effect; temporarily neutralising the reactive context | [`client-reactivity-engine`](client-reactivity-engine.md) |
| `loop.js` (`loop`) | driving `tick` callbacks per animation frame | [`client-reactivity-engine`](client-reactivity-engine.md) (batching & scheduling) |
| `render.js` (`should_intro`) | honouring `intro: false` / hydration | [`client-dom-renderer_lifecycle`](client-dom-renderer_lifecycle.md) |
| `blocks/each.js` (`current_each_item`) | binding an `animate:` directive to its each item | [`client-dom-renderer_control-flow-blocks`](client-dom-renderer_control-flow-blocks.md) |
| `bindings/shared.js` (`without_reactive_context`) | event dispatch and config resolution without creating signal reads | [`client-dom-renderer_bindings`](client-dom-renderer_bindings.md) |
| `dom/task.js` (`queue_micro_task`) | deferring deferred-transition config resolution to post-DOM-update | [`client-reactivity-engine`](client-reactivity-engine.md) |
| `constants.js` (`TRANSITION_IN/OUT/GLOBAL`, `BLOCK_EFFECT`, `EFFECT_RAN`, `EFFECT_TRANSPARENT`) | flag decoding and effect-tree traversal | [`client-reactivity-engine`](client-reactivity-engine.md) (foundation) |

### 8.2 Consumed by

| Consumer | Interaction |
| --- | --- |
| Generated client code (`transition:` / `in:` / `out:` directives) | calls `$.transition(flags, element, () => fn, params)` |
| Generated client code (`animate:` in keyed each) | calls `$.animation(element, () => fn, params)` |
| `effects.js` (`resume_effect` / `pause_effect` / teardown) | invokes `TransitionManager.in()`, `out(fn)`, `stop()` |
| Each-block reconciler | invokes `EachAnimationManager.measure/fix/apply/unfix` |
| Public `svelte/animate` (`flip`) and `svelte/transition` | supply the `AnimateFn` / `TransitionFn` callbacks and easing curves — see [`transitions-animations-easing`](transitions-animations-easing.md) |

---

## 9. Design Notes, Invariants & Edge Cases

1. **Managers, not animations.** Registering a directive never starts an animation; it attaches a manager. All timing decisions belong to the effect lifecycle — this is what makes transitions compose correctly with `{#if}`, `{#key}`, `{#await}`, each-item recycling, and snippets.
2. **Local vs global intros.** Local transitions replay only when their own block re-runs; `|global` transitions run on any resume. The distinction is computed by walking parents and skipping `EFFECT_TRANSPARENT` effects, because snippet bodies and else-if chains would otherwise mask the true owning block.
3. **Reversal must be seamless.** Three mechanisms cooperate: cached `current_options`, starting from `counterpart.t()`, and `deactivate()` silencing the replaced animation's completion callback.
4. **Intro-then-outro-then-intro.** A unidirectional (`in:` only) intro aborts a still-running previous intro; a bidirectional one keeps it as the `counterpart` so the reversal starts from the current visual state.
5. **`inert` handling.** The element is made `inert` for the whole outro (uninteractable while disappearing) and restored to its original value at `in()` — the original value is captured once, at registration.
6. **Safari < 18 overflow bug.** If a `css()` function emits `overflow: hidden`, it is re-applied as an inline style during the animation and restored afterwards (`overflow` stashed at registration). Marked for removal in Svelte 6.
7. **No stray reactive reads.** Both `dispatch_event` and `get_options()` run inside `without_reactive_context`, and the scheduled intro is `untrack`ed — animations must never create dependencies on component state.
8. **Hydration & first paint.** Intros are suppressed during hydration and when `mount(..., { intro: false })` is used, via `should_intro()`.
9. **Resource hygiene.** Aborts cancel the `Animation`, null its `effect`, and silence `onfinish`; completed intros abort their own animation to prevent leaks; outro facades `reset` to the visible state.
10. **Events.** `introstart`, `introend`, `outrostart`, `outroend` are dispatched as `CustomEvent`s on the element, giving application code the same hooks as Svelte 4's transition events.

---

## 10. Related Documentation

- [`client-dom-renderer`](client-dom-renderer.md) — parent module: DOM creation, hydration, blocks, attributes, bindings.
- [`client-dom-renderer_lifecycle`](client-dom-renderer_lifecycle.md) — `mount` / `hydrate` / `unmount`, `should_intro` gating.
- [`client-dom-renderer_control-flow-blocks`](client-dom-renderer_control-flow-blocks.md) — each-block reconciliation that drives `animate:flip`.
- [`client-dom-renderer_bindings`](client-dom-renderer_bindings.md) — `without_reactive_context` and binding infrastructure.
- [`client-reactivity-engine`](client-reactivity-engine.md) — effects (`pause_effect`/`resume_effect`), runtime context, rAF loop, flags.
- [`transitions-animations-easing`](transitions-animations-easing.md) — public `TransitionConfig`/`AnimationConfig` producers (`fade`, `fly`, `crossfade`, `flip`) and easing library.
- [`compiler-transformer_client-transform_directive-visitors`](compiler-transformer_client-transform_directive-visitors.md) — codegen that emits `$.transition(...)` / `$.animation(...)`.
- [`internal-shared-utils`](internal-shared-utils.md) — shared `noop`, `is_function`, `run` helpers.
