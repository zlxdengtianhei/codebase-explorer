# Module: server-runtime_payload-and-output

> **Hierarchy:** [Server-Side Rendering & Cross-Target Runtime Services](Server-Side_Rendering___Cross-Target_Runtime_Services.md) → `server-runtime` → **`server-runtime_payload-and-output`**

## 1. Introduction

The `server-runtime_payload-and-output` module defines the **data containers, buffering strategy, and output contract** of Svelte's server-side renderer. Every server render of a component writes its HTML into a mutable `Payload` object; this module owns that object, the helpers that snapshot and restore it, the unique-ID generator that keeps server-rendered identifiers stable across hydration, and the `RenderOutput` shape that `render()` ultimately returns to embedders.

In short, this module is responsible for:

| Concern | Components | File |
|---|---|---|
| Output buffering (body + head + CSS + title) | `Payload`, `HeadPayload` | `packages/svelte/src/internal/server/payload.js` |
| Payload snapshot / merge (legacy bindings) | `copy_payload`, `assign_payload` | `packages/svelte/src/internal/server/payload.js` |
| Unique, hydration-stable ID generation | `props_id_generator` (private), `props_id` (public) | `payload.js`, `packages/svelte/src/internal/server/index.js` |
| Public render-result contract | `RenderOutput` | `packages/svelte/src/internal/server/types.d.ts` |

This module is a *pure data/contract* layer: it does not itself emit HTML elements — that is the job of the sibling modules documented in [server-runtime_render-pipeline](server-runtime_render-pipeline.md), which create the `Payload`, drive component execution, and serialize it into the final strings.

## 2. Core Components

### 2.1 `HeadPayload` (class)

Accumulates everything destined for the document `<head>` during one render:

| Field | Type | Purpose |
|---|---|---|
| `css` | `Set<{ hash, code }>` | Scoped component styles, deduplicated by CSS hash |
| `out` | `string[]` | String fragments emitted by `<svelte:head>` content |
| `title` | `string` | Title text accumulated from `<svelte:title>` |
| `uid` | `() => string` | Shared unique-ID generator (assigned from the owning `Payload`) |

### 2.2 `Payload` (class)

The root render buffer passed through the entire component tree:

| Field | Type | Purpose |
|---|---|---|
| `out` | `string[]` | Body HTML fragments (the main output stream) |
| `css` | `Set<{ hash, code }>` | Body-level scoped styles (deduplicated, serialized into `head` by `render()`) |
| `uid` | `() => string` | Unique-ID generator created by `props_id_generator(idPrefix)` in the constructor |
| `select_value` | `any` | Transient state for legacy `<select>`/`<option>` selection; consumed by `maybe_selected()` / `valueless_option()` in the [render pipeline](server-runtime_render-pipeline.md) |
| `head` | `HeadPayload` | Nested head accumulator; its `uid` is the **same function instance** as the payload's |

```javascript
constructor(id_prefix = '') {
    this.uid = props_id_generator(id_prefix);
    this.head.uid = this.uid; // shared generator → IDs unique across head AND body
}
```

### 2.3 `copy_payload(payload) → Payload`

Creates an isolated snapshot of a payload, used by **compiled legacy-mode components to handle `bind:` directives**. Copies are structural where it matters:

- `out` → new array with the same fragments
- `css` → new `Set` with the same entries
- `head` → new `HeadPayload` with copied `out` / `css`, same `title`
- `uid` → **the same generator function reference** (so the counter keeps incrementing globally — no ID collisions between parent and copy)

### 2.4 `assign_payload(p1, p2)`

Merges the *result* of a render performed against `p2` back into `p1`:

- `p1.out = [...p2.out]` (copied)
- `p1.css = p2.css`, `p1.head = p2.head`, `p1.uid = p2.uid` (re-pointed by reference)

Together with `copy_payload` this forms an *isolate-then-merge* pattern: a child render runs against a copy so partial writes cannot corrupt the parent's buffer, and the parent adopts the finished result afterwards. See §5.

### 2.5 `props_id_generator(prefix) → () => string` (private)

A closure-based monotonic counter:

```javascript
let uid = 1;
return () => `${prefix}s${uid++}`;   // → "app-s1", "app-s2", ...
```

The prefix comes from the `idPrefix` render option (`options.idPrefix + '-'`), allowing applications that render multiple roots on one page to namespace their IDs.

### 2.6 `props_id(payload) → string`

The public server helper backing the **`$props.id()`** rune. It draws the next unique ID from `payload.uid()` and emits it as a hydration marker comment into the body stream:

```javascript
export function props_id(payload) {
    const uid = payload.uid();
    payload.out.push('<!--#' + uid + '-->');
    return uid;
}
```

The generated value is returned to component code immediately, and the marker (`<!--#s1-->`) is left in the HTML so that the client-side hydration process (see [client-dom-renderer](client-dom-renderer.md)) can recognize the same ID instead of generating a fresh one — guaranteeing server/client ID parity.

### 2.7 `RenderOutput` (interface, `types.d.ts`)

The contract returned by `render()` to the embedder (frameworks such as SvelteKit):

| Field | Description |
|---|---|
| `head` | HTML for the document `<head>` (head fragments + title + serialized `<style id>` tags) |
| `body` | HTML for somewhere in the `<body>` — the canonical field |
| `html` | **Deprecated** alias of `body`, retained for backwards compatibility (consumed by legacy adapters such as [`legacy-server._render`](legacy-compat.md)) |

`RenderOutput` is re-exported through the public type surface — see [svelte-public-types](svelte-public-types.md).

## 3. Architecture

### 3.1 Data structure relationships

```mermaid
classDiagram
    class Payload {
        +Set~css~ css
        +string[] out
        +uid() string
        +any select_value
        +HeadPayload head
    }
    class HeadPayload {
        +Set~css~ css
        +string[] out
        +uid() string
        +string title
    }
    class RenderOutput {
        +string head
        +string html deprecated
        +string body
    }
    Payload *-- HeadPayload : head
    Payload ..> props_id_generator : creates uid closure
    RenderOutput ..> Payload : serialized by render()
```

### 3.2 Position in the SSR pipeline

```mermaid
flowchart LR
    subgraph render-pipeline["server-runtime_render-pipeline"]
        R["render(component, options)"]
        W["element / head / slot / await_block / css_props writers"]
        S["serialize: join out arrays, build head string"]
    end
    subgraph payload-and-output["server-runtime_payload-and-output (this module)"]
        P["Payload / HeadPayload buffers"]
        PID["props_id + props_id_generator"]
        CP["copy_payload / assign_payload"]
        RO["RenderOutput contract"]
    end
    subgraph consumers
        EMBED["Embedder (e.g. SvelteKit)"]
        HYD["Client hydration"]
    end
    R -->|"new Payload(idPrefix)"| P
    W -->|"push fragments"| P
    PID --> P
    CP --> P
    P --> S
    S --> RO
    RO --> EMBED
    RO -->|"marker comments in HTML"| HYD
```

## 4. Data Flow: Payload Lifecycle During `render()`

The lifecycle below shows how the buffers owned by this module flow through the [render pipeline](server-runtime_render-pipeline.md):

```mermaid
flowchart TD
    A["render(component, options)"] --> B["new Payload(idPrefix + '-')"]
    B --> C["props_id_generator closure becomes payload.uid"]
    C --> D["Compiled component function executes with payload"]
    D --> D1["element/tag writers push to payload.out"]
    D --> D2["<svelte:head> writers push to payload.head.out / .title"]
    D --> D3["Component styles register {hash, code} in payload.css"]
    D --> D4["props_id(payload) pushes marker comment + returns uid"]
    D1 --> E["payload.out.join('') → body / html"]
    D2 --> F["head.out.join + title + style tags → head"]
    D3 --> F
    D4 --> E
    E --> G["RenderOutput { head, body, html }"]
    F --> G
```

Key behaviors at each stage:

1. **Creation** — `render()` instantiates `Payload` with the optional `idPrefix`; the same `uid` closure is shared with the nested `HeadPayload`, so generated IDs are unique across *both* streams.
2. **Accumulation** — the entire component tree mutates the payload via the helpers of the sibling modules ([attributes & props](server-runtime_attributes-and-props.md), [slots/snippets/blocks](server-runtime_slots-snippets-and-blocks.md), [store integration](server-runtime_store-integration.md)). The payload itself is append-only string-array buffering; fragments are joined **once** at the end.
3. **Deduplication** — `css` is a `Set`, so a component's scoped style (identified by its hash) is serialized exactly once, even if the component renders repeatedly.
4. **Serialization** — `render()` (render-pipeline module) turns the buffers into a single `RenderOutput`; the `html` field is populated for backwards compatibility with `@deprecated` semantics.
5. **Cleanup** — `render()`'s `finally` block aborts any pending [abort signals](server-runtime_dev-diagnostics.md) (dev diagnostics module), independent of payload contents.

## 5. Process Flow: Legacy Payload Copying (`copy_payload` / `assign_payload`)

When legacy-mode components use `bind:`, the compiled SSR code renders the child into an isolated copy of the payload and then merges the result back:

```mermaid
sequenceDiagram
    participant LC as Legacy component (compiled SSR code)
    participant P as Parent Payload
    participant CP as Copied Payload
    participant U as Shared uid closure
    LC->>P: copy_payload(P)
    P-->>CP: new Payload with copied out/css/head, same uid fn
    Note over CP: Child renders into CP — partial writes are isolated from P
    CP->>U: uid() calls keep incrementing the global counter
    LC->>P: assign_payload(P, CP)
    Note over P: P adopts child's out (copied), css/head/uid (by reference)
```

Two deliberate asymmetries are worth noting:

- `copy_payload` is **defensive**: collections are duplicated so the copy starts as a true snapshot.
- `assign_payload` is **cheap**: only `out` is copied; `css`, `head`, and `uid` are re-pointed by reference because the copy's buffers are now the authoritative result.
- The `uid` reference is shared in both operations, guaranteeing that IDs generated during the isolated render remain unique within the whole document.

## 6. Unique ID Generation and Hydration Consistency

`$props.id()` requires an identifier that is *the same on the server and the client*. This module implements the server half:

```mermaid
flowchart LR
    A["render(c, { idPrefix })"] -->|"prefix + '-'"| B["props_id_generator(prefix)"]
    B -->|"uid = () => prefix + 's' + n++"| C["payload.uid"]
    D["$props.id() in compiled component"] --> E["props_id(payload)"]
    C --> E
    E -->|"emit marker comment into payload.out"| F["Body HTML"]
    E -->|"return uid string"| G["Component logic"]
    F -->|"hydration recognizes marker"| H["Client adopts same ID"]
```

Consequences of this design:

- **Monotonic uniqueness** — one closure per `render()` call; IDs never repeat within a render.
- **Namespacing** — `idPrefix` prevents collisions when multiple independent roots are server-rendered into one document.
- **Server/client parity** — the `<!--#uid-->` marker embedded in the output stream is the coordination point with client-side hydration (see [client-dom-renderer](client-dom-renderer.md)); the client adopts the server's ID rather than minting its own.

## 7. The `RenderOutput` Contract

```typescript
export interface RenderOutput {
    /** HTML that goes into the `<head>` */
    head: string;
    /** @deprecated use `body` instead */
    html: string;
    /** HTML that goes somewhere into the `<body>` */
    body: string;
}
```

- `render()` currently populates **all three** fields; `body` and `html` hold identical content.
- New embedders should read `body`; `html` exists for legacy consumers such as [`legacy-server._render`](legacy-compat.md), which maps it into the old `{ css, head, html }` shape.
- The exact composition of the `head` string (fragment join + title + `<style id="hash">` tags) is defined by the render pipeline — see [server-runtime_render-pipeline](server-runtime_render-pipeline.md); this module only guarantees the *shape* of the buffers that feed it.

## 8. Integration with Other Modules

| Interaction | Direction | Details |
|---|---|---|
| [server-runtime_render-pipeline](server-runtime_render-pipeline.md) | consumes | `render()` creates `Payload`, drives writers into it, serializes to `RenderOutput`; `head()`, `element()`, `await_block()`, `css_props()` all write into payload buffers |
| [server-runtime_dev-diagnostics](server-runtime_dev-diagnostics.md) | adjacent | `render()`'s `finally` aborts pending signals (`abort-signal.js`); dev element tracking is orthogonal to payload contents |
| [server-runtime_attributes-and-props](server-runtime_attributes-and-props.md) | produces strings for | `spread_attributes`, `stringify`, `attr_class`/`attr_style` build the strings that element writers push into `payload.out` |
| [server-runtime_slots-snippets-and-blocks](server-runtime_slots-snippets-and-blocks.md) | consumes | `slot()` dispatches to slot/snippet functions that receive the payload and append to it |
| [context-api](context-api.md) | adjacent | Context push/pop wraps component execution around payload writes; the payload itself carries no context |
| [client-dom-renderer](client-dom-renderer.md) | cross-target contract | Hydration markers emitted into the payload (`<!--#uid-->`, block-open/close comments) are recognized client-side so IDs and block boundaries match |
| [legacy-compat](legacy-compat.md) | consumes | `copy_payload`/`assign_payload` support legacy `bind:` semantics; `legacy-server._render` maps `RenderOutput.body` into the legacy `html` field |
| [svelte-public-types](svelte-public-types.md) | re-exports | `RenderOutput` is part of the public `svelte` type surface |
| [internal-shared-utils](internal-shared-utils.md) | uses | `noop` and shared validation helpers are used alongside payload handling in the server runtime |

## 9. Design Notes

- **Append-only string arrays.** `out` arrays are pushed to during the tree walk and joined a single time at the end — avoiding quadratic string concatenation while keeping streaming-style emission trivial for writers.
- **Set-based CSS deduplication.** Identical scoped styles (same hash) from repeated component instances are collected once; `render()` serializes each entry as `<style id="{hash}">{code}</style>` in the head.
- **Shared `uid` closure.** A single generator instance spans body, head, and any legacy payload copies — this is what makes ID uniqueness a *document-level* invariant rather than a per-buffer one.
- **Synchronous buffers, asynchronous content.** The payload is a synchronous accumulator; async content (`{#await}`) is emitted as pending-branch HTML plus hydration markers by `await_block()` in the render pipeline — the payload never blocks on promises.
- **Backwards compatibility discipline.** The deprecated `html` field and the legacy copy/assign pair show the module's role as the seam between the modern `render()` API and pre-Svelte-5 server rendering expectations.
