# State Inspection & Debug Instrumentation (`client-dev-tooling_state-inspection`)

> Position in the module tree:
> `Client_Runtime_Engine_(Reactivity___DOM_Rendering)` → [client-dev-tooling](client-dev-tooling.md) → **`client-dev-tooling_state-inspection`**

## 1. Introduction

`client-dev-tooling_state-inspection` is the **runtime half of Svelte's developer-facing introspection features**. It gives developers visibility into reactive state and effects at runtime:

| File | Key exports | User-facing feature it powers |
|---|---|---|
| `internal/client/dev/inspect.js` | `inspect` | the `$inspect(...)` rune |
| `internal/client/dev/tracing.js` | `trace`, `tag`, `tag_proxy`, `get_stack`, `label`, `tracing_expressions` | the `$inspect.trace()` rune and named signals in dev diagnostics |
| `internal/client/dev/console-log.js` | `log_if_contains_state` | "you logged a `$state` proxy" warnings + console snapshots |
| `internal/client/dev/debug.js` | `root`, `log_effect_tree` | effect-tree debugging helpers |

Everything in this module is **development-only instrumentation**. The compiler gates all calls into these functions behind the `dev` flag (see [compiler-transformer_client-transform](compiler-transformer_client-transform.md)), so production bundles contain none of this code — there is no runtime cost for end users.

Design principles shared by all four subcomponents:

1. **Never break user code** — reads are `try/catch`-guarded, logging is `untrack`ed so diagnostics never create accidental reactive dependencies, and all console output happens inside `untrack(...)`.
2. **Snapshot, don't alias** — live `$state` proxies are deep-cloned via `snapshot()` before logging, so the console shows point-in-time values instead of values that mutate as you expand them in devtools.
3. **Synchronous & trace-preserving where it matters** — `$inspect` effects run synchronously so captured stack traces are useful.

## 2. Architecture

The module sits at the boundary between the **compiler** (which injects the calls), the **reactivity engine** (which provides effects, the signal graph, and proxies), and the **console/devtools** (where output lands).

```mermaid
flowchart TB
    subgraph compiler["Compiler — dev build only"]
        CT["client transform visitors<br/>CallExpression / VariableDeclaration /<br/>ExpressionStatement"]
    end

    subgraph stateinsp["client-dev-tooling_state-inspection"]
        INSPECT["dev/inspect.js<br/>inspect()"]
        TRACE["dev/tracing.js<br/>trace() / tag() / tag_proxy()<br/>get_stack() / label()"]
        CLOG["dev/console-log.js<br/>log_if_contains_state()"]
        DEBUG["dev/debug.js<br/>root() / log_effect_tree()"]
    end

    subgraph engine["client-reactivity-engine"]
        EFF["reactivity/effects.js<br/>inspect_effect / render_effect /<br/>validate_effect / effect_tracking"]
        RT["runtime.js<br/>untrack / active_reaction /<br/>signal graph + batching"]
        SRC["sources.js / deriveds.js<br/>signal.created / signal.updated"]
        PX["proxy.js<br/>update_path / PROXY_PATH_SYMBOL"]
    end

    SHARED["internal/shared/clone.js<br/>snapshot()"]
    WARN["client warnings.js<br/>console_log_state"]
    CONST["constants.js<br/>STATE_SYMBOL / PROXY_PATH_SYMBOL /<br/>INSPECT_EFFECT / flag bitmasks"]

    CT -->|"$.inspect(...)"| INSPECT
    CT -->|"$.trace(...)"| TRACE
    CT -->|"$.tag / $.tag_proxy"| TRACE
    CT -->|"$.log_if_contains_state(...)"| CLOG

    INSPECT -->|"create effects"| EFF
    INSPECT -->|"untrack"| RT
    INSPECT -->|"deep clone"| SHARED
    TRACE -->|"untrack / active_reaction"| RT
    TRACE -->|"flags, symbols"| CONST
    TRACE -->|"snapshot"| SHARED
    CLOG -->|"untrack"| RT
    CLOG -->|"detect proxies"| CONST
    CLOG -->|"snapshot"| SHARED
    CLOG -->|"warning"| WARN
    DEBUG -->|"flag bitmasks"| CONST

    PX -->|"re-label nested proxies"| TRACE
    RT -.->|"records created/updated<br/>while tracing is active"| SRC
```

### Component relationships

```mermaid
flowchart LR
    subgraph siblings["client-dev-tooling (siblings)"]
        OWN["mutation-ownership-guards"]
        VAL["runtime-validation"]
        MSG["message-catalog"]
        SI["state-inspection (this module)"]
    end
    MSG -->|"console_log_state warning text"| SI
    VAL -.->|"validate_effect used by inspect()"| SI
    SI --- OWN
```

- **`inspect()`** consumes the effect infrastructure of [client-reactivity-engine_effects](client-reactivity-engine_effects.md): it validates its call site with `validate_effect('$inspect')` (same family as [client-dev-tooling_runtime-validation](client-dev-tooling_runtime-validation.md)) and creates an `inspect_effect` (`INSPECT_EFFECT` flag) plus a companion `render_effect`.
- **`tracing.js`** is read/write-heavy on the [signal graph](client-reactivity-engine_signal-graph.md): it inspects `signal.f` flags (`DERIVED`, `ASYNC`), `signal.wv` write versions, `deps`, `label`, `created`, and `updated`. Conversely, the engine's source/derived implementations consult the module-level `tracing_expressions` state to record `Error` stack traces when signals are created or invalidated, which `log_entry()` later renders.
- **`tag()` / `tag_proxy()`** are the write side of proxy labeling. `proxy.js`'s `update_path()` (see [client-reactivity-engine_sources-and-proxies](client-reactivity-engine_sources-and-proxies.md)) calls back into `tag()` to rename child sources when a nested proxy's path changes (e.g. `obj.foo version`).
- **`log_if_contains_state()`** emits its warning through [client-dev-tooling_message-catalog](client-dev-tooling_message-catalog.md) (`w.console_log_state`).

## 3. Compile-time → Runtime data flow

The compiler is responsible for *instrumenting user code*; this module provides the *receivers*. All emission happens only when `dev` is true:

```mermaid
flowchart LR
    subgraph S["User source (.svelte)"]
        A["$inspect(a).with(cb)"]
        B["$inspect.trace() / $inspect.trace(fn)"]
        C["let count = $state(0)<br/>let double = $derived(count * 2)"]
        D["console.log(someState)"]
    end
    subgraph G["Generated component code (dev)"]
        A --> A2["$.inspect(() => [a], cb)"]
        B --> B2["$.trace(() => label, () => expr)<br/>(bare statements are dropped)"]
        C --> C2["$.tag($.state(0), 'count')<br/>$.tag($.derived(thunk), 'double')<br/>$.tag_proxy($.proxy(v), name)"]
        D --> D2["console.log(...$.log_if_contains_state('log', someState))"]
    end
    subgraph R["This module (runtime)"]
        A2 --> R1["inspect"]
        B2 --> R2["trace"]
        C2 --> R3["tag / tag_proxy"]
        D2 --> R4["log_if_contains_state"]
    end
    R --> O["Browser console / devtools"]
```

Key details of the emission contract (from the client-transform visitors):

- **`$state`/`$derived` declarations**: every dev-mode signal source or derived is wrapped with `$.tag(signal, '<variable name>')`; destructured patterns get synthetic labels like `[$state object]`, `[$derived iterable]`. Proxied *non-source* values get `$.tag_proxy(value, name)` instead.
- **`$inspect` / `$inspect().with`**: lowered to `$.inspect(get_value, inspector)` where `get_value` is a thunk so the effect can re-read on change.
- **`$inspect.trace()` as a statement** is a no-op (`b.empty`); as an expression wrapper it becomes `$.trace(...)`.
- **`console.{debug,dir,error,group,groupCollapsed,info,log,trace,warn}`** calls whose arguments cannot be statically evaluated are rewritten to spread through `$.log_if_contains_state(methodName, ...args)`.

## 4. Subcomponent reference

### 4.1 `inspect()` — the `$inspect` rune runtime

```js
inspect(get_value, inspector = console.log)
```

Implementation outline:

1. `validate_effect('$inspect')` — rejects calls outside a component initialisation context.
2. Creates an **inspect effect** (`create_effect(INSPECT_EFFECT, fn, true)`). It runs *synchronously* with its dependencies rather than deferred, precisely so captured stack traces stay useful. Because it runs eagerly, reading the value can legitimately throw (e.g. `$inspect(object.property)` placed before the `{#if object}` branch that creates `object`).
3. Therefore the read is wrapped in `try/catch`: a thrown error is stashed in a local `error` slot (initialized to `UNINITIALIZED`) and **not** rethrown.
4. On success, the value is deep-cloned with `snapshot(value, /* skip_warning */ true, /* no_tojson */ true)` and the inspector is invoked inside `untrack(...)` with `'init'` on the first run and `'update'` thereafter.
5. A companion **render effect** also calls `get_value()` (to stay in sync with the inspect effect's lifecycle). If it observes a stashed error, it reports it once via `console.error` and clears the slot. If the render effect *never* runs, the `$inspect` was destroyed — the error is simply discarded, which is the desired behavior.

```mermaid
sequenceDiagram
    participant U as User code ($inspect)
    participant I as inspect()
    participant IE as inspect_effect (sync)
    participant F as inspector callback
    participant RE as render_effect
    U->>I: $.inspect(() => [value], cb?)
    I->>IE: create INSPECT_EFFECT
    IE->>IE: try get_value()
    alt read throws (not yet defined)
        IE->>IE: stash error (UNINITIALIZED slot)
    else read succeeds
        IE->>IE: snapshot(value, true, true)
        IE->>F: untrack → inspector('init' | 'update', ...snap)
    end
    RE->>RE: runs alongside inspect effect
    alt stashed error present
        RE->>F: console.error(error) — exactly once
    else effect destroyed before running
        RE->>RE: discard error silently
    end
```

### 4.2 `tracing.js` — signal labeling and `$inspect.trace()`

**Module state.** `tracing_expressions` holds `{ reaction, entries: Map<Value, { traces: Error[] }> }` while a trace is active. The signal-graph implementations in the engine push `Error` stack traces into `entries` when signals are created or invalidated during `fn()`; this module only *reads* them back. Nested traces save/restore the previous state in a `finally` block.

**`trace(label, fn)`** — runtime of `$inspect.trace()`:

```mermaid
flowchart TD
    A["$.trace(labelFn, fn)"] --> B["save previous tracing_expressions;<br/>install { reaction: active_reaction, entries: new Map() }"]
    B --> C["t0 = performance.now(); value = fn()<br/>(signal reads register deps + created/updated traces)"]
    C --> D["time = elapsed ms"]
    D --> E{"effect_tracking()?"}
    E -->|"no"| F["console.log — 'ran outside of an effect (Xms)'"]
    E -->|"yes"| G{"entries.size === 0?"}
    G -->|"yes"| H["console.log — 'no reactive dependencies'"]
    G -->|"no"| I["console.group(label Xms)<br/>for each signal → log_entry(signal, traces)"]
    F --> J["restore previous tracing_expressions<br/>return value"]
    H --> J
    I --> J
```

**`log_entry(signal, entry)`** renders one signal as a collapsible console group:

- **Type** via `get_type()`: `$derived` if the `DERIVED | ASYNC` flags are set, otherwise `store` when the label starts with `$`, else `$state`.
- **Dirtiness** via write-version comparison `signal.wv > current_reaction.wv || current_reaction.wv === 0` — dirty entries are styled bold/CornflowerBlue, clean ones grey.
- **Value**: proxied objects (those carrying `STATE_SYMBOL`) are printed as `snapshot(value, true)`; everything else raw.
- For `$derived` signals it **recurses into `deps`**, showing the dependency chain.
- It prints `signal.created` (creation stack) and, for dirty signals, each `signal.updated` error, followed by the collected `entry.traces`.

**`get_stack(label)`** builds a sanitised `Error` for stack capture:

- Filters out `Error` header lines and all frames containing `svelte/src/internal`;
- bails out entirely (`null`) if the stack passes through `validate_each_keys` (avoids noisy derived-in-each traces);
- renames the error to `` `${label}Error` `` so devtools render it with the right prefix.

**`tag(source, label)` / `tag_proxy(value, label)`** — the labeling write-path:

- `tag` sets `source.label` (used by `log_entry` and dev error messages) and forwards the value to `tag_proxy`.
- `tag_proxy` invokes `value?.[PROXY_PATH_SYMBOL]?.(label)` — the proxy's internal path-update hook.
- The proxy layer calls back: `proxy.js`'s `update_path(new_path)` re-tags the version source and every child source with `get_label(path, prop)`, so nested proxies stay correctly named (e.g. `obj.foo version`).
- `label(value)` renders a value compactly for diagnostics: `Symbol(description)`, `<function>`, `<object>`, or `String(value)`.

### 4.3 `log_if_contains_state()` — console interception

```js
log_if_contains_state(method, ...objects) // returns objects
```

```mermaid
flowchart TD
    A["console.log(x, y) inside a component (dev)"] --> B["compiler rewrite:<br/>console.log(...$.log_if_contains_state('log', x, y))"]
    B --> C["untrack(() => { try { ... } catch {} })"]
    C --> D{"arg is object &&<br/>STATE_SYMBOL in arg ?"}
    D -->|"yes"| E["push snapshot(obj, true)<br/>has_state = true"]
    D -->|"no"| F["pass argument through unchanged"]
    E --> G{"has_state?"}
    F --> G
    G -->|"yes"| H["warn console_log_state<br/>(message-catalog)"]
    G -->|"no"| I["no output"]
    H --> J["console.log '%c[snapshot]' + transformed args"]
    I --> K["return original objects<br/>(spread preserves call semantics)"]
    J --> K
```

The whole detection is wrapped in `untrack` (no accidental dependencies) and `try/catch` (never breaks user logging), and the function **returns the original arguments** so the surrounding `console.*(...)` spread behaves exactly like the uninstrumented call. The warning it emits comes from [client-dev-tooling_message-catalog](client-dev-tooling_message-catalog.md) and points users at `$inspect` / `$state.snapshot`.

### 4.4 `debug.js` — effect-tree debugging

- **`root(effect)`** walks `effect.parent` until `null` and returns the top-most effect — the anchor of an effect subtree, useful when tooling needs to reason about ownership from the top rather than a leaf.
- **`log_effect_tree(effect, depth = 0)`** recursively prints the effect tree:
  - **Label** resolved from the flag bitmask (`ROOT_EFFECT`, `BOUNDARY_EFFECT`, `BLOCK_EFFECT`, `ASYNC`, `BRANCH_EFFECT`, `RENDER_EFFECT`, `EFFECT`) → `root` / `boundary` / `block` / `async` / `branch` / `render effect` / `effect`.
  - **Status** from `CLEAN` / `MAYBE_DIRTY` / dirty → styled bold when not clean.
  - At `depth 0` it extracts and prints the **callsite** from `new Error().stack`; deeper nodes print their `effect.fn` in a collapsed group.
  - Dependencies render via **`log_dep`**, which recurses into `derived` chains (`DERIVED` flag) showing current values.
  - Children are visited via the intrusive `first`/`next` linked list.
- These helpers are strictly **read-only** diagnostics; they never mutate signals or scheduling state.

## 5. How the module fits into the overall system

```mermaid
flowchart LR
    subgraph pipeline["Developer experience loop"]
        C["Compiler<br/>(dev instrumentation)"] --> G["Generated component code"]
        G --> E["Reactivity engine<br/>(signal graph, effects, proxies)"]
        E --> SI["state-inspection<br/>(this module)"]
        SI --> CON["Console / DevTools"]
    end
```

- **Upstream (compile time):** the client transform (see [compiler-transformer_client-transform](compiler-transformer_client-transform.md)) decides *when* this module's functions appear in output — only under `dev`. Type-level contracts (`Signal`, `Value`, `Derived`, `Reaction`, flag bitmasks) are defined by the engine (see [client-reactivity-engine_signal-graph](client-reactivity-engine_signal-graph.md)).
- **Downstream (runtime):** this module never schedules work itself; it rides on engine primitives — `inspect_effect`/`render_effect` ([client-reactivity-engine_effects](client-reactivity-engine_effects.md)), `untrack`/`active_reaction` ([client-reactivity-engine](client-reactivity-engine.md)) — and shares the snapshot machinery with `$state.snapshot` ([internal-shared-utils](internal-shared-utils.md)).
- **Adjacent dev tooling:** ownership/assignment guards ([client-dev-tooling_mutation-ownership-guards](client-dev-tooling_mutation-ownership-guards.md)) produce the *errors* this module's traces help diagnose; the message catalog supplies warning/error text.

## 6. Dependencies summary

| Dependency | Used by | Purpose |
|---|---|---|
| `reactivity/effects.js` — `inspect_effect`, `render_effect`, `validate_effect`, `effect_tracking` | `inspect`, `trace` | effect creation/validation, tracking queries |
| `runtime.js` — `untrack`, `active_reaction` | all four files | dependency-free reads; current reaction for dirtiness/trace scoping |
| `shared/clone.js` — `snapshot` | `inspect`, `trace`, `log_if_contains_state` | detached deep clones of proxied state |
| `constants.js` — `STATE_SYMBOL`, `PROXY_PATH_SYMBOL`, `INSPECT_EFFECT`, flag bitmasks, `UNINITIALIZED` | all four files | proxy detection, effect kind, sentinel values |
| `client/warnings.js` — `console_log_state` | `log_if_contains_state` | warning emission (message catalog) |
| `proxy.js` — `update_path` (reverse dependency) | calls `tag` | keeps nested-proxy labels in sync |

## 7. Invariants & gotchas for maintainers

1. **Dev-only surface.** Never call these functions from production code paths; the compiler only emits them under `dev`. Adding a call elsewhere leaks dev code into prod bundles.
2. **`inspect` error deferral is deliberate.** A read error is only reported if the companion render effect actually runs; relying on `inspect_effect` alone would either throw too early or swallow errors after teardown.
3. **`untrack` everywhere you log.** Any signal read inside diagnostics would create a dependency and alter app behavior; every console output in this module is untracked.
4. **`tracing_expressions` is a module-level singleton** with save/restore semantics — the signal graph depends on its exact shape (`entries: Map<Value, { traces }>`); changing it requires touching `sources.js`/`deriveds.js`.
5. **Labels are a user-facing contract.** `tag()` labels appear in dev error messages and `$inspect.trace()` output; the compiler synthesizes names for destructured patterns (`[$state object]`, `[$derived iterable]`) — keep them stable.
6. **Snapshots are point-in-time.** `log_if_contains_state` returns the *original* objects; only the extra `[snapshot]` line is cloned. Don't "optimize" the clone away — live proxies would show stale-on-expand values in devtools.
