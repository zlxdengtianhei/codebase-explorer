# JS/TS Parsing (`compiler-parser_js-ts-parsing`)

## 1. Overview

`compiler-parser_js-ts-parsing` is a submodule of the Svelte compiler's **parse phase (Phase 1)**. While the Svelte template syntax (tags, blocks, attributes) is parsed by a hand-written state machine (see [compiler-parser_parser-core](compiler-parser_parser-core.md) and [compiler-parser_parsing-states](compiler-parser_parsing-states.md)), everything that is *actual JavaScript or TypeScript* is delegated to this module:

| File | Responsibility |
| --- | --- |
| `packages/svelte/src/compiler/phases/1-parse/acorn.js` | Thin, offset-preserving bridge to the [Acorn](https://github.com/acornjs/acorn) parser (optionally extended with `@sveltejs/acorn-typescript`). Parses `<script>` contents as full `Program`s and inline `{…}` template expressions. Also recovers **comments**, which Acorn does not attach to the AST by itself. |
| `packages/svelte/src/compiler/phases/1-parse/remove_typescript_nodes.js` | Post-parse AST normalizer that converts the TypeScript-flavored ESTree output into **plain ESTree JavaScript** — erasing types, dropping type-only declarations, unwrapping TS wrapper expressions, and rejecting non-erasable TS features. |

Two invariants drive the design:

1. **Offset fidelity** — every `start`/`end` in the returned ESTree AST must point at the exact character positions in the original `.svelte` file, because diagnostics, source maps, code frames (`get_code_frame`), and editor tooling all depend on them.
2. **Plain JavaScript downstream** — the analyze and transform phases (see [compiler-analyzer](compiler-analyzer.md), [compiler-transformer](compiler-transformer.md)) and the `esrap` code generator must never encounter TS-only node types or properties. TS support in `<script lang="ts">` is limited to *erasable* syntax; anything that requires a semantic transform must be preprocessed first (see [compiler-preprocessor](compiler-preprocessor.md)).

---

## 2. Architecture

### 2.1 Context within the compiler

```mermaid
flowchart TB
    subgraph callers["Upstream callers"]
        PARSER["Parser class<br/>(1-parse/index.js)<br/>see compiler-parser_parser-core"]
        READ_SCRIPT["read_script()<br/>(read/script.js)"]
        READ_EXPR["read_expression()<br/>(read/expression.js)"]
        COMPILE["compile() / compileModule()<br/>(compiler/index.js)<br/>see compiler-core_public_api"]
    end

    subgraph module["compiler-parser_js-ts-parsing"]
        direction TB
        subgraph acornjs["1-parse/acorn.js"]
            PARSE["parse()"]
            PARSE_EXPR["parse_expression_at()"]
            HANDLERS["get_comment_handlers()"]
        end
        subgraph tsjs["1-parse/remove_typescript_nodes.js"]
            RTS["remove_typescript_nodes()"]
            RTP["remove_this_param()"]
        end
    end

    subgraph libs["External libraries"]
        ACORN["acorn"]
        TSPLUGIN["@sveltejs/acorn-typescript"]
        ZIMMER["zimmerframe (walk)"]
    end

    subgraph downstream["Downstream phases"]
        ANALYZE["Phase 2: Analyze<br/>see compiler-analyzer"]
        TRANSFORM["Phase 3: Transform<br/>see compiler-transformer"]
    end

    PARSER -->|"sets parser.ts,<br/>owns root.comments"| READ_SCRIPT
    PARSER --> READ_EXPR
    READ_SCRIPT -->|"full Program"| PARSE
    READ_EXPR -->|"single Expression"| PARSE_EXPR
    PARSE --> HANDLERS
    PARSE_EXPR --> HANDLERS
    HANDLERS --> ACORN
    PARSE -.->|"when typescript === true"| TSPLUGIN
    PARSE_EXPR -.->|"when typescript === true"| TSPLUGIN
    COMPILE -->|"if metadata.ts"| RTS
    RTS --> ZIMMER
    RTS -->|"plain ESTree JS"| ANALYZE
    PARSE -->|"comments feed svelte-ignore"| ANALYZE
    ANALYZE --> TRANSFORM
```

### 2.2 Component inventory

| Component | Kind | Purpose |
| --- | --- | --- |
| `acorn.js::parse` | exported function | Parse a complete JS/TS module (typically a `<script>` body) into an ESTree `Program`. |
| `acorn.js::parse_expression_at` | exported function | Parse a single expression starting at a given character index (inline template expressions, directive values, spread attributes, attachments). |
| `acorn.js::get_comment_handlers` | internal factory | Produces the `onComment` collector and the `add_comments` AST post-processor that jointly reconstruct Acorn's missing comment support. |
| `remove_typescript_nodes.js::remove_typescript_nodes` | exported function | Walk a TS-flavored AST and rewrite it in place into plain JavaScript. |
| `remove_typescript_nodes.js::remove_this_param` | internal visitor | Strip the synthetic `this` parameter that `acorn-typescript` inserts on functions. |

---

## 3. Component Reference

### 3.1 `parse(source, comments, typescript, is_script)` — `1-parse/acorn.js`

Parses `source` as an ES module and returns an ESTree `Program`.

**Behaviour details:**

- **Parser selection** — uses `acorn.Parser` for JavaScript and `acorn.Parser.extend(tsPlugin())` (created once at module scope as `ParserWithTS`) when `typescript === true`.
- **Parse options** — always `sourceType: 'module'`, `ecmaVersion: 16` (latest supported syntax), `locations: true`, plus the `onComment` handler from `get_comment_handlers`.
- **`is_script` mode** — when parsing a `<script>` body, the module *temporarily patches `parser.prototype.parseStatement`* to reset `this.undefinedExports = {}` after every statement. Rationale: a `<script>` may legitimately `export` a binding that is not declared inside that same script (e.g. instance/module script split, legacy `export let` props), which would otherwise make Acorn throw *"Export 'x' is not defined"*. The original prototype method is restored in a `finally` block so the patch can never leak.
- **Offset preservation** — callers blank out the portion of the template that precedes the script (replacing non-newline characters with spaces) so that AST offsets align with the full `.svelte` source. See `read_script()` in the [compiler-parser_parser-core](compiler-parser_parser-core.md) module.
- **Comment attachment** — after parsing, `add_comments(ast)` attaches the collected comments as `leadingComments` / `trailingComments` on AST nodes (see §4).

### 3.2 `parse_expression_at(source, comments, typescript, index)` — `1-parse/acorn.js`

Uses `parser.parseExpressionAt(source, index, …)` to parse exactly one expression beginning at character `index`. This powers every inline JS island in the template:

- `{expression}` expression tags
- shorthand/spread attributes (`{foo}`, `{...rest}`) and `@attach` values
- directive expressions (`onclick={handler}`, `bind:value={x}`, …)

The `index` argument is also passed to `get_comment_handlers` so that only comments *at or after* the expression start are attached to the expression AST — comments preceding the expression are consumed by the caller (`read_expression` walks the shared `comments` array backwards to advance `parser.index` past leading comments).

The caller relies on root-level `trailingComments` (see §4.2) to determine where an expression tag truly ends when comments follow the expression.

### 3.3 `get_comment_handlers(source, comments, index)` — internal factory

Returns `{ onComment, add_comments }`. Acorn only *reports* comments via a callback; it never puts them in the AST. This factory provides both halves of the reconstruction:

1. **`onComment(block, value, start, end, start_loc, end_loc)`** — pushes `{ type: 'Block' | 'Line', value, start, end, loc }` into the caller-owned `comments` array (which is `AST.Root.comments`, shared across the whole template parse). For multi-line **block** comments it computes the indentation of the line the comment starts on and strips that prefix from every line (`^indent` regex with the `gm` flag), so `comment.value` is de-indented and normalized.

2. **`add_comments(ast)`** — post-parse walk (via `zimmerframe`'s catch-all `_` visitor) that distributes the comments onto nodes:

```mermaid
flowchart TB
    A["Acorn comment callbacks<br/>(block, value, start, end, loc)"] --> B{"onComment():<br/>multiline block comment?"}
    B -->|"yes"| C["compute first-line indentation,<br/>strip it from every line (gm flag)"]
    B -->|"no"| D["keep value as-is"]
    C --> E["push into shared comments array<br/>type / value / start / end / loc"]
    D --> E
    E --> F["add_comments(ast) — walk AST"]
    F --> G["catch-all '_' visitor per node"]
    G --> H{"comment.start < node.start?"}
    H -->|"yes"| I["append to node.leadingComments"]
    H -->|"no"| J{"after next(): what sits<br/>between node.end and comment?"}
    J -->|"node is last in body<br/>(Program / BlockStatement /<br/>ArrayExpression / ObjectExpression)"| K["collect ALL trailing comments<br/>up to parent.end"]
    J -->|"only separators<br/>(',' ')' whitespace)"| L["attach single<br/>node.trailingComments"]
    J -->|"otherwise"| M["leave comment<br/>for an ancestor node"]
    F --> N{"leftover comments start at/after<br/>ast.end, or ast is a Program?"}
    N -->|"yes"| O["append to root trailingComments<br/>— used to detect the true end of<br/>expression tags"]
    I --> P["consumed by Phase 2:<br/>extract_svelte_ignore →<br/>push_ignore / pop_ignore<br/>(see compiler-core_compile_state)"]
    O --> P
```

**Why this exists:**

- `svelte-ignore` comments written *inside* JavaScript (e.g. above a `$derived` that intentionally has an unused dependency) must reach the analyzer. Phase 2 reads `leadingComments` of each JS node and runs them through `extract_svelte_ignore` → `push_ignore`/`pop_ignore` (see [compiler-core_diagnostics](compiler-core_diagnostics.md) and [compiler-core_compile_state](compiler-core_compile_state.md)).
- Formatting tools such as `prettier-plugin-svelte` consume the attached comments so round-tripping a component doesn't drop them.

### 3.4 `remove_typescript_nodes(ast)` — `1-parse/remove_typescript_nodes.js`

A `zimmerframe` walk with a visitor map that rewrites a TypeScript ESTree AST into plain JavaScript. It runs **once per compilation**, after parsing and *before* analysis, applied by `compile()` in `compiler/index.js` whenever `parsed.metadata.ts` is true — to the template `fragment` (which contains inline expression ASTs), the `instance` and `module` scripts, and the custom-element `extend` class.

```javascript
// compiler/index.js (excerpt)
if (parsed.metadata.ts) {
    parsed = {
        ...parsed,
        fragment: parsed.fragment && remove_typescript_nodes(parsed.fragment),
        instance: parsed.instance && remove_typescript_nodes(parsed.instance),
        module: parsed.module && remove_typescript_nodes(parsed.module)
    };
    // … plus customElementOptions.extend
}
```

**Transformation matrix:**

| TS construct encountered | Action | Result |
| --- | --- | --- |
| `TSAsExpression`, `TSSatisfiesExpression`, `TSNonNullExpression`, `TSTypeAssertion`, `TSInstantiationExpression` | Unwrap | `context.visit(node.expression)` — the inner expression replaces the wrapper. |
| `TSInterfaceDeclaration`, `TSTypeAliasDeclaration`, `TSDeclareFunction` | Drop | Replaced by `b.empty` (the shared `EmptyStatement` singleton from `utils/builders.js`, see [compiler-core_ast_builders](compiler-core_ast_builders.md)). |
| `ImportDeclaration` with `importKind === 'type'`, or whose specifiers are all `type` | Drop / filter | Whole node becomes `b.empty`; otherwise type-only specifiers are filtered out of the (copy of the) node. |
| `ExportNamedDeclaration` / `ExportDefaultDeclaration` / `ExportAllDeclaration` with `exportKind === 'type'` | Drop / filter | `b.empty`, or type-only specifiers filtered. If a named export's `declaration` collapses to an `EmptyStatement`, the whole export becomes `b.empty`. |
| TS-only properties on any node (`typeAnnotation`, `typeParameters`, `typeArguments`, `returnType`, `accessibility`) | Delete | The catch-all `_` visitor deletes them so the code generator (`esrap`) is never confused. |
| Synthetic `this` parameter on `FunctionExpression` / `FunctionDeclaration` | Shift off | `remove_this_param()` removes a leading `Identifier` named `this` (inserted by `acorn-typescript` to support `this`-types). |
| `declare` on `VariableDeclaration` / `ClassDeclaration` / `PropertyDefinition` | Drop | `b.empty`; `ClassBody` filters out `declare` property definitions. |
| `abstract` `MethodDefinition`; `implements` clause | Drop / delete property | `b.empty` / `delete node.implements`. |
| `TSParameterProperty` (constructor parameter properties) | Unwrap | Visits the underlying parameter — **unless** it has `readonly`/accessibility modifiers in a constructor, which is an error. |
| `TSModuleDeclaration` (namespace) | Inspect body | `b.empty` if empty/type-only; **error** if the namespace contains non-type nodes. |
| Decorators, `accessor` fields, `TSEnumDeclaration` (enums) | **Reject** | `typescript_invalid_feature` compile error. |

```mermaid
flowchart TB
    IN["TypeScript-flavored ESTree AST<br/>(output of acorn-typescript)"] --> W["zimmerframe walk<br/>with visitor map"]
    W --> CAT{"Node category?"}
    CAT -->|"TS wrapper expression"| U["unwrap to inner expression<br/>TSAs / TSSatisfies / TSNonNull /<br/>TSTypeAssertion / TSInstantiation"]
    CAT -->|"type-only declaration"| D["replace with b.empty<br/>(shared EmptyStatement)<br/>interfaces, type aliases, declare fns,<br/>type imports/exports, declare classes/vars"]
    CAT -->|"TS-only node properties"| P["delete typeAnnotation, typeParameters,<br/>typeArguments, returnType, accessibility<br/>(catch-all '_' visitor)"]
    CAT -->|"synthetic this parameter"| T["remove_this_param():<br/>shift leading 'this' Identifier<br/>off FunctionExpression/Declaration"]
    CAT -->|"non-erasable TS feature"| E["error typescript_invalid_feature<br/>decorators, enums, accessor fields,<br/>accessibility modifiers on ctor params,<br/>namespaces with runtime code"]
    U --> OUT["Plain ESTree JavaScript AST"]
    D --> OUT
    P --> OUT
    T --> OUT
```

### 3.5 `remove_this_param(node, context)` — internal visitor

```javascript
function remove_this_param(node, context) {
    if (node.params[0]?.type === 'Identifier' && node.params[0].name === 'this') {
        node.params.shift();
    }
    return context.next();
}
```

`acorn-typescript` models TS `this` parameters (`function f(this: Foo) { … }`) as a real leading parameter. Since the compiler must emit plain JavaScript, this visitor removes it; any *type annotation* attached to remaining parameters disappears with the generic property-deletion pass.

---

## 4. Runtime Data Flow

### 4.1 Parsing a `<script lang="ts">`

```mermaid
sequenceDiagram
    autonumber
    participant P as Parser (1-parse/index.js)
    participant RS as read_script() (read/script.js)
    participant AP as acorn.js parse()
    participant A as acorn / acorn-typescript
    participant C as root.comments array
    participant CP as compile() (compiler/index.js)

    P->>P: regex_lang_attribute match → parser.ts = true (lang="ts")
    P->>P: initialize root.comments = [], root.metadata.ts = parser.ts
    P->>RS: `<script>` tag encountered
    RS->>RS: slice script body; blank out preceding template<br/>(spaces, newlines kept → offsets preserved)
    RS->>AP: parse(source, root.comments, parser.ts, is_script = true)
    AP->>AP: patch parseStatement → reset undefinedExports per statement
    AP->>A: parser.parse(source, onComment, module, ecmaVersion 16, locations)
    A-->>C: onComment callbacks → Block/Line comment records (+loc)
    A-->>AP: Program AST (TS nodes if lang="ts")
    AP->>C: add_comments() → leading/trailing comments attached to nodes
    AP-->>RS: Program
    RS->>P: AST.Script node (content = Program)
    Note over RS,P: on Acorn error → parser.acorn_error()<br/>→ js_parse_error (strips Acorn's "(line:col)" suffix)
    CP->>CP: parsed.metadata.ts === true ?
    CP->>CP: remove_typescript_nodes(fragment / instance / module / extend)
    CP-->>CP: analyze_component() proceeds on plain ESTree JS
```

### 4.2 Parsing inline expressions

`read_expression()` (called by the template states — see [compiler-parser_parsing-states](compiler-parser_parsing-states.md)) invokes `parse_expression_at` with the shared `root.comments` array and the current `parser.index`. It then:

1. rewinds `parser.index` past any comments that Acorn consumed before the expression node starts,
2. counts `(` characters between the tag open and `node.start` so unbalanced parentheses inside the tag are detected,
3. advances `parser.index` to `node.end` (or past the last trailing comment / unmatched `)`) — this is exactly where root-level `trailingComments` from `add_comments` become load-bearing.

On failure, the error is converted via `parser.acorn_error(err)` (or, in `loose` mode used by tooling/editor integrations, a partial identifier expression may be recovered).

### 4.3 Where the outputs go

```mermaid
flowchart LR
    SRC[".svelte / .js source"] --> P["Phase 1: Parse<br/>Parser state machine + acorn.js"]
    P --> TS{"root.metadata.ts?"}
    TS -->|"yes"| STRIP["remove_typescript_nodes.js"]
    TS -->|"no"| AN
    STRIP --> AN["Phase 2: Analyze<br/>see compiler-analyzer"]
    P -->|"comments → svelte-ignore"| AN
    AN --> TR["Phase 3: Transform<br/>client / server / css<br/>see compiler-transformer"]
    TR --> OUT["JS output + CSS + public AST + warnings"]
```

- The cleaned `Program` ASTs and the template `Fragment` feed `analyze_component` / `analyze_module` (scope creation, rune detection, CSS analysis, warning emission).
- `analyze_module` (the `compileModule` entry point, see [compiler-core_public_api](compiler-core_public_api.md)) calls `parse(source, comments, false, false)` directly — `.js` module sources are always plain JavaScript.
- Comments travel with the `Analysis` object; every visitor consults them via the `_` catch-all to manage the ignore stack (`push_ignore` / `pop_ignore` in `state.js` — see [compiler-core_compile_state](compiler-core_compile_state.md)).

---

## 5. Error Handling

| Failure | Raised by | Mechanism |
| --- | --- | --- |
| JavaScript/TypeScript syntax error | `parse` / `parse_expression_at` | Thrown Acorn error is caught by `read_script` / `read_expression` and converted with `Parser.acorn_error()` → `js_parse_error` (the compiler strips Acorn's trailing `(line:col)` because it computes positions itself from `err.pos`). |
| Non-erasable TypeScript feature | `remove_typescript_nodes` | `typescript_invalid_feature(node, feature)` from `errors.js` (see [compiler-core_diagnostics](compiler-core_diagnostics.md)). The message explains that such features are unsupported *outside* `<script>` tags and discouraged inside them, pointing users at preprocessors (e.g. `vitePreprocess({ script: true })`) — see [compiler-preprocessor](compiler-preprocessor.md). |

Rejected features (current list): **decorators**, **enums**, **accessor fields**, **accessibility modifiers on constructor parameters**, **namespaces containing non-type (runtime) nodes**.

---

## 6. Dependencies

### 6.1 External

| Package | Used for |
| --- | --- |
| `acorn` | Core JS parsing (`Parser`, `Parser.parse`, `Parser.parseExpressionAt`). |
| `@sveltejs/acorn-typescript` | `tsPlugin()` — extends the parser so *erasable* TS syntax lexes/parses; produces TS-flavored ESTree nodes that `remove_typescript_nodes.js` then normalizes. |
| `zimmerframe` | AST walking (comment attachment in `add_comments`; the rewrite walk in `remove_typescript_nodes`). |

### 6.2 Internal

| Symbol (source module) | Relationship |
| --- | --- |
| `Parser` — [compiler-parser_parser-core](compiler-parser_parser-core.md) | Detects `lang="ts"` (regex over `<script …>` tags), owns the shared `root.comments` array and `metadata.ts`, exposes `acorn_error()` for error translation, and drives the template state machine. |
| `read_script` / `read_expression` — [compiler-parser_parsing-states](compiler-parser_parsing-states.md) | The two call-sites into `acorn.js`; responsible for offset blanking, paren balancing and error recovery. |
| `b.empty` — [compiler-core_ast_builders](compiler-core_ast_builders.md) | Shared `EmptyStatement` singleton used as the tombstone for removed TS declarations. |
| `typescript_invalid_feature` — [compiler-core_diagnostics](compiler-core_diagnostics.md) | Compile-error factory for unsupported TS features. |
| `extract_svelte_ignore` — [compiler-core_diagnostics](compiler-core_diagnostics.md) | Downstream consumer of the comments this module attaches (`leadingComments` → `svelte-ignore` handling, incl. kebab→snake code migration via `migrate_svelte_ignore`). |
| `push_ignore` / `pop_ignore` — [compiler-core_compile_state](compiler-core_compile_state.md) | Ignore-stack management driven by the extracted comments. |
| Phase 2 / Phase 3 — [compiler-analyzer](compiler-analyzer.md), [compiler-transformer](compiler-transformer.md) | Consumers of the (de-TypeScripted) AST; they must never see TS nodes. |
| `compile` / `compileModule` — [compiler-core_public_api](compiler-core_public_api.md) | Orchestrate parse → strip → analyze → transform. |

---

## 7. Design Notes & Caveats

- **Prototype patching is temporary and synchronous.** `parse()` mutates the *shared* `acorn.Parser.prototype` (or the extended TS parser prototype) while `is_script` is set and restores it in `finally`. This is safe only because compilation is single-threaded and synchronous — do not introduce async re-entrancy around these calls.
- **`ecmaVersion: 16` everywhere.** Both entry points force the latest supported syntax level so users don't need to configure parser capabilities.
- **Comments are a shared, ordered resource.** The `comments` array is threaded through the *entire* parse (template comments land there too), and `add_comments` consumes it monotonically (shifting entries as it attaches them). Anything that re-orders or re-parses expressions must share the same array instance to keep indices meaningful.
- **Erasure-only TS support.** The compiler deliberately supports only *erasable* TypeScript. Constructs needing semantic transformation (enums, namespaces with runtime code, parameter properties, decorators) fail fast at compile time with actionable guidance, keeping the compiler's responsibility boundary clean: full TS lowering belongs to userland preprocessors (see [compiler-preprocessor](compiler-preprocessor.md)).
- **Offsets over locations.** Although `locations: true` is requested (tools like `get_code_frame` need line/column), the compiler's internal bookkeeping is offset-based; the `<script>` offset blanking trick is what makes "one AST, one coordinate space" work for the whole `.svelte` file.

---

## 8. Related Documentation

- [compiler-core](compiler-core.md) — compiler-wide overview: public API, diagnostics, options validation, AST builders, type definitions.
- [compiler-parser_parser-core](compiler-parser_parser-core.md) — the template `Parser` class and main `parse()` entry.
- [compiler-parser_parsing-states](compiler-parser_parsing-states.md) — `fragment`/`element`/`text` states that invoke expression reading.
- [compiler-parser_options-reading](compiler-parser_options-reading.md) — `<svelte:options>` parsing.
- [compiler-parser_parsing-utilities](compiler-parser_parsing-utilities.md) — fuzzy matching and HTML entity handling.
- [compiler-analyzer](compiler-analyzer.md) — Phase 2: scopes, bindings, runes, CSS analysis.
- [compiler-transformer](compiler-transformer.md) — Phase 3: client/server/CSS transforms.
- [compiler-preprocessor](compiler-preprocessor.md) — the supported path for non-erasable TypeScript.
- [compiler-core_public_api](compiler-core_public_api.md) — `compile`, `compileModule`, `parse` entry points.
- [compiler-core_diagnostics](compiler-core_diagnostics.md) — error/warning infrastructure, including `typescript_invalid_feature` and `svelte-ignore` extraction.
