# Client Reactivity Engine — Deriveds & Async (`deriveds-and-async`)

> **Source files**
> - `packages/svelte/src/internal/client/reactivity/deriveds.js`
> - `packages/svelte/src/internal/client/reactivity/async.js`

## 1. Overview

`deriveds-and-async` is a sub-module of the [client-reactivity-engine](client-reactivity-engine.md). It implements two tightly coupled concerns of Svelte 5's client runtime:

1. **Derived signals** — lazily-evaluated, memoized values that recompute when their dependencies change (`$derived` in user code). This covers plain deriveds, legacy-safe deriveds, and **async deriveds** whose values resolve from promises.
2. **Async reactivity plumbing** — the runtime support that makes top-level `await` reactive inside components: context capture/restore across `await` points, flattening of mixed sync/async expressions, boundary suspension while async work is in flight, and development-mode "reactivity loss" diagnostics.

The module is deliberately small in surface but central in role: it is the bridge between the pure [signal graph](client-reactivity-engine_signal-graph.md) (which knows nothing about asynchrony) and the async, promise-driven execution model of compiled components.

---

## 2. Placement in the Reactivity Engine

```
client-reactivity-engine
├── signal-graph ............ core signal/reaction machinery (runtime.js)
├── sources-and-proxies ..... writable sources + deep proxies
├── deriveds-and-async ...... ◄ THIS MODULE
├── effects ................. effect creation/teardown (incl. async_effect)
├── batching-scheduling ..... Batch, microtask scheduling, suspension
├── props-and-stores ........ component props + store wiring
└── foundation .............. equality functions, compile-time flags
```

Compiled client code (produced by [compiler-transformer_client-transform](compiler-transformer_client-transform.md)) calls directly into this module: `$derived` compiles to `$.user_derived`, `await` expressions compile to `$.save(...)`, async expressions in templates compile to `$.async_derived` / `$.flatten(...)`, and async-mode component bodies compile to `$.async_body(...)`.

---

## 3. Component Inventory

### `reactivity/deriveds.js`

| Symbol | Kind | Purpose |
| --- | --- | --- |
| `derived(fn)` | factory | Creates a lazy `Derived` signal around `fn`. Never evaluates eagerly. |
| `user_derived(fn)` | factory | `derived` + `push_reaction_value` — the compiled form of the `$derived` rune. |
| `derived_safe_equal(fn)` | factory | `derived` with `safe_equals` semantics (legacy mode). |
| `async_derived(fn, location)` | factory | Returns `Promise<Source<V>>`; resolves the signal when `fn()`'s promise settles. Powers `await`-derived values. |
| `execute_derived(derived)` | executor | Runs the derived's function within the correct effect context. |
| `update_derived(derived)` | executor | Executes, applies equality check, bumps write version, resolves status. |
| `destroy_derived_effects(derived)` | teardown | Destroys effects created during a previous evaluation (e.g. a superseded `async_effect`). |
| `set_from_async_derived(v)` | setter | Tracks `current_async_effect` (DEV reactivity-loss diagnostics). |
| `recent_async_deriveds` | state | `Set` of async deriveds resolved "recently" — deduplicates waterfall warnings. |
| `get_derived_parent_effect`, `stack` | internal | Parent-effect resolution and DEV infinite-recursion detection. |

### `reactivity/async.js`

| Symbol | Kind | Purpose |
| --- | --- | --- |
| `save(promise)` | helper | Compiles `await a + b` into `(await $.save(a))() + b`; restores the effect context before the continuation runs. |
| `capture()` / restore thunk | helper | Snapshots `active_effect`, `active_reaction`, `component_context`, and `current_batch` so async continuations rejoin the reactive context. |
| `flatten(sync, async, fn)` | helper | Turns mixed sync/await expression parts into deriveds and invokes `fn` once async parts resolve. |
| `async_body(fn)` | helper | Runs an async-mode component body inside boundary suspension (`suspend()` / `unsuspend()`). |
| `track_reactivity_loss(promise)` | DEV | Preserves `current_async_effect` across an `await` to detect reads outside reactive tracking. |
| `for_await_track_reactivity_loss(iterable)` | DEV | `for await` shim (ECMA-262 ForIn/OfBodyEvaluation + AsyncIteratorClose) with reactivity-loss tracking on each iterator step. |
| `unset_context()` | helper | Nulls active effect/reaction/component context after async completions, preventing context leakage into microtasks. |

---

## 4. Architecture & Dependencies

```mermaid
flowchart TB
    subgraph MOD["deriveds-and-async"]
        DER["deriveds.js<br/>derived · async_derived · user_derived<br/>derived_safe_equal · execute_derived<br/>update_derived · destroy_derived_effects"]
        ASY["async.js<br/>flatten · save · capture<br/>async_body · track_reactivity_loss<br/>for_await_track_reactivity_loss · unset_context"]
    end

    SG["client-reactivity-engine_signal-graph<br/>update_reaction · active_effect / active_reaction<br/>set_signal_status · increment_write_version<br/>push_reaction_value · skip_reaction"]
    SRC["client-reactivity-engine_sources-and-proxies<br/>source · internal_set · inspect_effects"]
    EFF["client-reactivity-engine_effects<br/>async_effect · destroy_effect · aborted"]
    BAT["client-reactivity-engine_batching-scheduling<br/>current_batch · batch_deriveds · suspend<br/>Batch activate / increment / decrement / neuter"]
    FND["client-reactivity-engine_foundation<br/>equals · safe_equals · tracing_mode_flag"]
    BND["client-dom-renderer<br/>Boundary · get_pending_boundary"]
    CTX["context-api<br/>component_context · set_component_context · is_runes"]
    DEV["client-dev-tooling<br/>async_derived_orphan · derived_references_self<br/>await_waterfall · get_stack"]
    EH["error-handling<br/>invoke_error_boundary"]

    ASY --> DER
    DER --> SG
    DER --> SRC
    DER --> EFF
    DER --> BAT
    DER --> FND
    DER --> BND
    DER --> CTX
    DER --> DEV
    ASY --> SG
    ASY --> BAT
    ASY --> EFF
    ASY --> BND
    ASY --> CTX
    ASY --> EH
    ASY --> DEV
```

**Key observations**

- `async.js` is a *consumer* of `deriveds.js` (`async_derived`, `derived`, `derived_safe_equal`, `current_async_effect`), never the reverse.
- The module writes values exclusively through `internal_set` ([sources-and-proxies](client-reactivity-engine_sources-and-proxies.md)) so change tracking, batching and dev tracing remain centralized.
- All effect creation/destruction goes through [effects](client-reactivity-engine_effects.md) — deriveds never create raw effects themselves.

---

## 5. Derived Signals: Creation & Lifecycle

### 5.1 Creation (`derived` / `user_derived` / `derived_safe_equal`)

`derived(fn)` allocates the signal object without evaluating `fn`:

- **Flags** — starts as `DERIVED | DIRTY`. If created outside any effect (or under an `UNOWNED` parent derived) it is marked `UNOWNED`; otherwise the owning effect receives the `EFFECT_PRESERVED` flag, because deriveds evaluate lazily and any effects created *inside* them would otherwise attach to the effect tree too late.
- **Ownership chain** — `parent` is the enclosing derived, or the active effect if there is none.
- **Context capture** — `ctx` stores `component_context` so evaluation later can restore component scope.
- **Equality** — defaults to `equals` from [foundation](client-reactivity-engine_foundation.md); `derived_safe_equal` swaps in `safe_equals` (needed in legacy mode where values may be objects/`undefined` and `===` comparisons are unsafe).
- **DEV tracing** — with `tracing_mode_flag`, records a `CreatedAt` stack via `get_stack`.

`user_derived` is the user-facing wrapper: after creating the signal it calls `push_reaction_value(d)`, registering the new derived as a source value of the reaction currently running (i.e., linking `const total = $derived(a + b)` into the component's reaction). `derived_safe_equal` is what `flatten` uses when `is_runes()` is `false`.

### 5.2 Evaluation pipeline

```mermaid
flowchart TD
    A["read: derived flagged DIRTY / MAYBE_DIRTY"] --> B["update_derived(d)"]
    B --> C["execute_derived(d)"]
    C --> C1["set_active_effect to nearest<br/>non-derived ancestor effect"]
    C1 --> C2{"DEV mode?"}
    C2 -- "yes" --> C3["recursion guard:<br/>stack check, derived_references_self"]
    C3 --> C4["destroy_derived_effects(d)<br/>(teardown stale inner effects)"]
    C2 -- "no" --> C4
    C4 --> C5["update_reaction(d) — signal graph<br/>re-runs fn, re-collects dependencies"]
    C5 --> D{"equals(newValue, cached)?"}
    D -- "equal" --> E["keep cached v and wv<br/>(no downstream invalidation)"]
    D -- "changed" --> F["v = newValue<br/>wv = increment_write_version()"]
    E --> G{"is_destroying_effect?"}
    F --> G
    G -- "yes" --> H["return early — do NOT cache<br/>(cleanup fns must read live state)"]
    G -- "no" --> I{"batch_deriveds map active?"}
    I -- "yes: concurrent batches" --> J["record d.v in batch_deriveds<br/>(per-batch value bookkeeping)"]
    I -- "no" --> K["set_signal_status:<br/>CLEAN, or MAYBE_DIRTY when<br/>UNOWNED / skip_reaction with deps"]
```

Notable behaviours:

- **Lazy + memoized** — recomputation happens only when a reader encounters a dirty derived; `equals` short-circuits downstream propagation when the recomputed value is unchanged.
- **Correct `active_effect`** — `execute_derived` walks the `parent` chain (deriveds may nest inside deriveds) to find the first non-`DERIVED` ancestor, since the derived's `fn` must run with the owning *effect* active.
- **Write versioning** — `increment_write_version()` (signal graph) keeps the global `wv` monotonic; the graph's `rv`/`wv` comparison scheme (see [signal-graph](client-reactivity-engine_signal-graph.md)) uses this to decide staleness.
- **Concurrency-aware** — when multiple batches exist, `Batch.process` sets up the `batch_deriveds` map ("time travel" between concurrent batches). `update_derived` records computed values there instead of settling the status, so each batch observes values consistent with its own writes (see [batching-scheduling](client-reactivity-engine_batching-scheduling.md)).

---

## 6. Async Deriveds (`async_derived`)

`async_derived(fn, location)` is the runtime backing for values derived from promises (e.g. `const x = $derived(await fetchJson(...))` in async mode, and `$.flatten` calls). Unlike plain deriveds it:

1. Creates a regular **`source(UNINITIALIZED)`** as the output signal (async values are *written*, not recomputed on read).
2. Spawns an **`async_effect`** (`ASYNC | EFFECT_PRESERVED`, see [effects](client-reactivity-engine_effects.md)) that invokes `fn()` and commits the result into the source.
3. Returns a **`Promise<Source<V>>`** that code may `await` to obtain the signal itself.

```mermaid
sequenceDiagram
    participant C as Compiled component / effect
    participant AD as async_derived
    participant AE as async_effect body
    participant B as parent Boundary
    participant BA as current Batch
    participant S as output Source

    C->>AD: async_derived(fn)
    AD->>B: resolve boundary (parent.b), error if orphan
    AD->>S: source(UNINITIALIZED)
    AD->>AE: queue async_effect
    Note over AE: runs during batch flush
    AE->>AE: p = fn() — reads p.then eagerly<br/>so promise-related signals are tracked
    AE->>B: update_pending_count(+1)  [initialising only]
    AE->>BA: batch.increment()
    AE->>AE: chain: promise = prev.then(() => p)<br/>(superseded runs swallow rejections)
    AE-->>S: promise.then(handler)
    Note over AE,S: promise settles
    AE->>BA: batch.activate()
    AE->>S: internal_set(signal, value)<br/>(or set ERROR_VALUE + write error)
    AE->>B: update_pending_count(-1)
    AE->>BA: batch.decrement()
    AE->>AE: unset_context()
    BA-->>BA: pending == 0 → commit batch,<br/>flush deferred effects
    C-->>C: returned Promise fulfils with S
```

Mechanics worth knowing:

- **Orphan check** — called with no active effect, `async_derived` raises `async_derived_orphan` immediately.
- **Suspension scope** — `should_suspend = !active_reaction`: only deriveds created during *initialisation* suspend the boundary/batch; re-runs of an existing async derived never re-suspend.
- **Chained promises** — each run chains off the previous promise (`prev?.then(() => p)`), so results are applied strictly in effect-run order. Superseded promises only get `.catch(() => {})` (unhandled-rejection suppression); their results are never written.
- **Error path** — a rejected `fn()` sets the `ERROR_VALUE` flag on the signal and writes the error object into it via `internal_set`. Consumers (e.g. the `await` block in [client-dom-renderer](client-dom-renderer.md)) interpret the flag. The sentinel `STALE_REACTION` is ignored — it signals a cancelled run, not a real error.
- **The `next`/`go` dance** — the returned promise fulfils with the signal only once the *current* promise chain (`p === promise`) has settled; if the effect re-ran in the meantime, `go` re-waits on the newer chain. This prevents handing out a signal whose value does not yet correspond to the latest dependencies.
- **Cleanup / neutering** — when the async effect is destroyed or re-runs, it schedules `queueMicrotask(() => batch.neuter())`, marking the in-flight batch so a late commit cannot apply DOM callbacks to a deleted branch.
- **Waterfall diagnostics** — with a `location` (DEV), successful resolutions register the signal in `recent_async_deriveds` and schedule an `await_waterfall` warning if nobody reads the value promptly.

---

## 7. Reactive `await`: Capture, `save`, and `flatten`

JavaScript `await` severs the synchronous execution context, but Svelte's dependency tracking is synchronous (via `active_reaction`/`active_effect` from the [signal graph](client-reactivity-engine_signal-graph.md)). This module reintroduces the context after every `await`:

```mermaid
flowchart LR
    subgraph SRC["source expression"]
        E1["await a + b"]
    end
    subgraph OUT["compiled output"]
        E2["(await $.save(a))() + b"]
    end
    E1 --> E2
    E2 --> E3["save(a): capture context → await promise →<br/>return () => { restore(); return value }"]
    E3 --> E4["thunk invoked with active_effect / active_reaction /<br/>component_context / current_batch reinstated →<br/>read of b is tracked as a dependency"]
```

- **`capture()`** snapshots `active_effect`, `active_reaction`, `component_context` and `current_batch`; the returned `restore()` reinstates them and (DEV) clears `current_async_effect`.
- **`save(promise)`** is the per-`await` wrapper the compiler emits. Without it, `b` in `await a + b` would be read with no active reaction and silently become non-reactive.
- **`flatten(sync, async, fn)`** handles template expressions that mix synchronous and awaited parts (compiled to `$.flatten([...], [...], fn)`):
  - *All-sync fast path* — maps each expression through `derived` (runes) or `derived_safe_equal` (legacy) and invokes `fn` synchronously.
  - *Mixed path* — captures context, builds one `async_derived` per async expression, and on `Promise.all` completion re-activates the batch, restores context, and calls `fn` with the combined values. Errors in `fn` go through `invoke_error_boundary` (skipped when the parent effect is already destroyed); rejections of the async work itself route to `boundary.error(error)`.
- **`unset_context()`** is called whenever async work completes *outside* a captured continuation, so stale effect/reaction/component contexts cannot leak into unrelated microtasks.

---

## 8. Top-Level Await: `async_body`

In async mode, a component's initialisation body may itself `await`. The compiled body is wrapped by `async_body(fn)`:

```mermaid
flowchart TD
    S["async_body(fn)"] --> T["suspend() — boundary pending(+1)<br/>+ batch.increment()"]
    T --> U["await fn() — component body"]
    U --> V{"error thrown?"}
    V -- "yes" --> W{"aborted(active effect)?"}
    W -- "no" --> X["invoke_error_boundary(error, effect)"]
    W -- "yes" --> Y["swallow — branch already destroyed"]
    V -- "no" --> Z["continue"]
    X --> Z
    Y --> Z
    Z --> F["finally: unsuspend() —<br/>boundary pending(-1), batch.decrement(),<br/>flush deferred effects, unset_context()"]
```

This mirrors the suspension bookkeeping that `async_derived` performs inline (see `Batch.suspend` in [batching-scheduling](client-reactivity-engine_batching-scheduling.md)): while pending count is non-zero the batch defers committing render/effect work, then flushes deferred DIRTY/MAYBE_DIRTY effects once it reaches zero.

---

## 9. Development-Mode Instrumentation

| Feature | Mechanism | Outcome |
| --- | --- | --- |
| Infinite derived recursion | `stack` push/pop in `execute_derived` | `derived_references_self` error instead of "too much recursion" |
| Reactivity loss after `await` | `track_reactivity_loss` preserves `current_async_effect`; `for_await_track_reactivity_loss` wraps every iterator `next()`/`return()` (following ECMA-262 ForIn/OfBodyEvaluation + AsyncIteratorClose, including `iterator.return()` on normal completion) | `await_reactivity_loss` warnings when a read happens outside reactive tracking |
| Await waterfalls | `async_derived`'s `location` + `recent_async_deriveds` + deferred timeout | `await_waterfall` warning when an async derived resolves but is not read promptly |
| Signal tracing | `tracing_mode_flag` → `get_stack('CreatedAt')` on deriveds | ownership/origin stacks surfaced by dev tooling ([client-dev-tooling](client-dev-tooling.md)) |

All DEV paths are guarded by `esm-env`'s `DEV` and are removed from production bundles (together with the `/*#__NO_SIDE_EFFECTS__*/` annotations that keep the factories tree-shakeable — see the treeshakeability checker in the engineering tooling docs).

---

## 10. Error Handling Summary

| Situation | Handling |
| --- | --- |
| `async_derived` with no active effect | Synchronous `async_derived_orphan` error |
| `fn()` rejects | `ERROR_VALUE` flag set on the signal; error written as its value (ignored when `STALE_REACTION`) |
| `Promise.all` rejection in `flatten` | `boundary.error(error)` on the pending boundary |
| `fn` callback error in `flatten` | `invoke_error_boundary`, skipped if parent effect is `DESTROYED` |
| Error inside `async_body` | `invoke_error_boundary` unless the effect already aborted |
| Deriveds re-entering themselves (DEV) | `derived_references_self` error |

---

## 11. Related Modules

- [client-reactivity-engine](client-reactivity-engine.md) — parent module overview.
- [client-reactivity-engine_signal-graph](client-reactivity-engine_signal-graph.md) — `update_reaction`, status flags, `active_effect`/`active_reaction` and version counters this module builds upon.
- [client-reactivity-engine_sources-and-proxies](client-reactivity-engine_sources-and-proxies.md) — `source`/`internal_set`; async results are written through the same pipeline as user `$state` writes.
- [client-reactivity-engine_effects](client-reactivity-engine_effects.md) — `async_effect`, `destroy_effect`, `aborted`.
- [client-reactivity-engine_batching-scheduling](client-reactivity-engine_batching-scheduling.md) — `Batch` lifecycle (`increment`/`decrement`/`activate`/`neuter`), `suspend`, microtask flushing.
- [client-reactivity-engine_foundation](client-reactivity-engine_foundation.md) — equality functions (`equals`, `safe_equals`) and compile-time flags.
- [client-reactivity-engine_props-and-stores](client-reactivity-engine_props-and-stores.md) — sibling reactive plumbing for props/stores.
- [client-dom-renderer](client-dom-renderer.md) — `Boundary` / `get_pending_boundary` and the `await` block that surfaces async derived state.
- [context-api](context-api.md) — component context captured/restored across `await` points.
- [client-dev-tooling](client-dev-tooling.md) — errors, warnings and tracing used by the DEV instrumentation.
- [compiler-transformer_client-transform](compiler-transformer_client-transform.md) — the compiler phase that emits calls into `$.user_derived`, `$.async_derived`, `$.save`, `$.flatten` and `$.async_body`.

## 12. Maintainer Notes

- **Never write a derived's value directly.** Use `internal_set` (sources) or the update path in `update_derived`; the write-version and batch-capture side effects are load-bearing.
- **`should_suspend` asymmetry is intentional** — only initialisation-time async deriveds participate in boundary suspension; keep this distinction when refactoring.
- **Promise chaining order matters** — the `prev?.then` chain is what guarantees a stale resolution can never overwrite a newer one. Any new write path must preserve it.
- **`update_derived` intentionally skips status settling during effect destruction** (`is_destroying_effect`) so cleanup functions never observe cached stale values.
- The factories are annotated `/*#__NO_SIDE_EFFECTS__*/`; adding side effects to `derived`/`user_derived`/`async_derived`/`derived_safe_equal` would break bundler optimisations.
