# Legacy Lifecycle (`legacy-compat_legacy-lifecycle`)

## 1. Introduction

The **`legacy-compat_legacy-lifecycle`** module is the piece of the Svelte 5 client runtime that keeps the **Svelte 4 component lifecycle** (`onMount`, `beforeUpdate`, `afterUpdate`) working for components that are compiled in **legacy mode** (`runes: false`). It lives under the [`legacy-compat`](legacy-compat.md) compatibility layer inside the [Client Runtime Engine (Reactivity & DOM Rendering)](Client_Runtime_Engine_(Reactivity___DOM_Rendering).md) and consists of two small but central files:

| File | Export | Role |
| --- | --- | --- |
| `packages/svelte/src/internal/client/dom/legacy/lifecycle.js` | `init(immutable?)` | Wires `onMount` / `beforeUpdate` / `afterUpdate` callbacks into the modern effect system for legacy components |
| `packages/svelte/src/internal/client/legacy.js` | `invalidate_inner_signals(fn)`, `captured_signals` | Deprecated coarse-grained invalidation helper that emulates Svelte 4's `$$invalidate` semantics on top of fine-grained signals |

Everything in this module is marked `@deprecated` and is scheduled for removal in **Svelte 6.0** — it exists purely so that unmigrated Svelte 4 codebases continue to behave identically on the Svelte 5 runtime.

> **Scope note.** This module only covers the *lifecycle* half of legacy compatibility. Component class shims (`createClassComponent`, `asClassComponent`, `Svelte4Component`) are documented in [`legacy-compat_component-api-shims`](legacy-compat_component-api-shims.md), and legacy events/props plumbing (`bubble_event`, event modifiers, `update_legacy_props`, …) in [`legacy-compat_legacy-events-and-props`](legacy-compat_legacy-events-and-props.md).

---

## 2. Position in the System

Legacy lifecycle support is *activated* by three cooperating layers:

1. **The compiler** ([Compiler Pipeline & Language Toolchain](Compiler_Pipeline___Language_Toolchain.md)) — when compiling a component without runes, the client transform ([compiler-transformer_client-transform](compiler-transformer_client-transform.md)) emits a `$.init(immutable)` call at the top of the generated instance function, right after the `$.push(props, runes, fn)` context push. Users calling `onMount`/`beforeUpdate`/`afterUpdate` inside the instance get their callbacks registered into the component context.
2. **The public API** ([public-api](public-api.md), `index-client.js`) — `onMount`, `beforeUpdate`, `afterUpdate` detect the legacy context (`component_context.l !== null`) and push the callbacks into the legacy registry `context.l.u` instead of creating plain effects.
3. **This module** — `init()` reads that registry and translates it into modern render/user effects, while `invalidate_inner_signals()` provides the reactive-invalidation primitive used by legacy reactivity paths.

```mermaid
flowchart LR
    subgraph Compiler["Compiler Pipeline (legacy / no-runes mode)"]
        CT["client transform<br/>(compiler-transformer_client-transform)"]
    end

    subgraph PublicAPI["Public API (index-client.js)"]
        OM["onMount(fn)"]
        BU["beforeUpdate(fn)"]
        AU["afterUpdate(fn)"]
    end

    subgraph Module["legacy-compat_legacy-lifecycle (this module)"]
        INIT["init(immutable)"]
        IIS["invalidate_inner_signals(fn)"]
        CAP["captured_signals"]
    end

    subgraph Engine["Client Reactivity Engine"]
        CTX["component_context<br/>(context-api)"]
        UE["user_effect / user_pre_effect<br/>(client-reactivity-engine_effects)"]
        DRV["derived<br/>(client-reactivity-engine_deriveds-and-async)"]
        SRC["internal_set<br/>(client-reactivity-engine_sources-and-proxies)"]
        RT["get / untrack / deep_read_state<br/>(client-reactivity-engine_signal-graph)"]
    end

    CT -- "emits $.init(immutable) in<br/>legacy instance function" --> INIT
    OM & BU & AU -- "register callbacks into<br/>context.l.u (a/b/m arrays)" --> CTX
    CTX -- "context.l (ComponentContextLegacy)" --> INIT
    INIT -- "creates effects" --> UE
    INIT -- "immutable-mode version counter" --> DRV
    INIT -- "subscribes signals" --> RT
    IIS -- "re-sets each captured signal" --> SRC
    IIS -.-> CAP
    SRC -- "marks dependents dirty" --> RT
```

---

## 3. Architecture & Components

### 3.1 The legacy component context (`ComponentContextLegacy`)

The whole module revolves around the `l` slot of the client `ComponentContext`, which [`context-api`](context-api.md)'s `push()` populates whenever a component is created while `legacy_mode_flag` is on and the component is not runes-based:

```ts
// packages/svelte/src/internal/client/types.d.ts
type ComponentContext = {
    p: null | ComponentContext;            // parent
    c: null | Map<unknown, unknown>;       // context map
    e: null | Array<() => void>;           // deferred effects
    s: Record<string, unknown>;            // props (legacy lifecycle / dispatcher)
    x: Record<string, any> | null;         // exports / accessors
    l: null | {                            // legacy stuff (@deprecated, remove in 6.0)
        s: null | Source[];                // local signals (read by before/afterUpdate)
        u: null | {                        // update callbacks
            a: Array<() => void>;          // afterUpdate callbacks
            b: Array<() => void>;          // beforeUpdate callbacks
            m: Array<() => any>;           // onMount callbacks
        };
        $: any[];                          // `$:` statement tokens (legacy_pre_effect)
    };
    function?: any;                        // dev: the component function
};

type ComponentContextLegacy = ComponentContext & {
    l: NonNullable<ComponentContext['l']>;
};
```

`init()` is the only consumer that *activates* `l.u`; the `$:` statement machinery fills `l.$` via `legacy_pre_effect` (see [`client-reactivity-engine_effects`](client-reactivity-engine_effects.md)).

### 3.2 `init(immutable)` — the legacy lifecycle bootstrap

```js
export function init(immutable = false) {
    const context = /** @type {ComponentContextLegacy} */ (component_context);
    const callbacks = context.l.u;
    if (!callbacks) return;
    ...
}
```

Responsibilities:

1. **Bail-out fast path** — if the component registered no lifecycle callbacks (`context.l.u` is `null`), `init` does nothing. This keeps the runtime cost for legacy components *without* `onMount`/`beforeUpdate`/`afterUpdate` at zero.
2. **Build a `props` reader** — by default `() => deep_read_state(context.s)`, which recursively *reads* every prop signal so they all get registered as dependencies of whichever effect currently observes them.
3. **Immutable-mode guard** — when `immutable` is `true` (the compiler passes this for legacy components, where Svelte 4 only re-fired `beforeUpdate`/`afterUpdate` on prop *identity* changes), it wraps the props read in a `derived` that:
   - compares each prop against its previous value (`prev[key] !== props[key]`),
   - only bumps an internal `version` counter when at least one prop object identity changed,
   - so downstream effects re-run on identity changes rather than on every fine-grained signal mutation.
4. **Register the three callback groups as effects:**

| Callback group | Effect primitive | Semantics |
| --- | --- | --- |
| `callbacks.b` (`beforeUpdate`) | `user_pre_effect` (render effect) | Runs before each render where observed state changed: first `observe_all(context, props)` to subscribe to all local signals + props, then `run_all(callbacks.b)` |
| `callbacks.m` (`onMount`) | `user_effect` | Runs **once** after mount (untracked), collects each callback's returned cleanup function and returns a teardown that invokes them on unmount. Must run *before* `afterUpdate` |
| `callbacks.a` (`afterUpdate`) | `user_effect` | Runs after mount and re-runs after each render where observed state changed: `observe_all(...)` then `run_all(callbacks.a)` |

5. **`observe_all(context, props)`** (module-private) — the subscription bridge: it `get()`s every signal in `context.l.s` (the component's local signals) and then invokes the `props()` reader. Both happen *inside* the surrounding effect, which is what makes the effect re-run exactly when "anything the component could observe" changed — Svelte 4's coarse-grained update contract.

### 3.3 `invalidate_inner_signals(fn)` & `captured_signals`

```js
export let captured_signals = null;      // @deprecated, nested Set<Value> stack

function capture_signals(fn) {           // module-private
    // swap in a fresh Set, run fn untracked, merge into parent set, restore
}

export function invalidate_inner_signals(fn) {   // @deprecated
    for (var signal of capture_signals(fn)) {
        internal_set(signal, signal.v);  // re-assign current value => invalidate
    }
}
```

- `capture_signals(fn)` temporarily installs a fresh `Set` into the module-global `captured_signals`. Every signal *read* while `fn` executes is recorded there by the signal-reading fast path in the [reactivity engine](client-reactivity-engine_signal-graph.md). Sets nest: an inner capture merges into its enclosing capture.
- `invalidate_inner_signals(fn)` runs `fn`, captures everything it read, and then calls [`internal_set(signal, signal.v)`](client-reactivity-engine_sources-and-proxies.md) on each captured signal. Re-setting a signal to its current value bumps its write version and marks all dependents dirty — i.e. it **force-invalidates** the observable neighborhood of `fn`. This reproduces Svelte 4's `$$invalidate` behaviour (invalidate what you touched, let the scheduler figure out the rest) on top of Svelte 5's fine-grained signal graph.
- It is the reactive-invalidation counterpart of the `$:` tracking pair `legacy_pre_effect` / `legacy_pre_effect_reset` and shares the `@deprecated` removal horizon of the rest of the legacy surface.

---

## 4. Process Flows

### 4.1 Mounting a legacy component

```mermaid
sequenceDiagram
    participant App as Application code
    participant M as mount()/hydrate()<br/>(client-dom-renderer_lifecycle)
    participant P as push() (context-api)
    participant IF as Compiled legacy<br/>instance function
    participant API as onMount/beforeUpdate/<br/>afterUpdate (public-api)
    participant I as init() (this module)
    participant E as Effects engine<br/>(client-reactivity-engine_effects)
    participant DOM as DOM renderer

    App->>M: mount(Component, { target, props })
    M->>P: push(props, runes=false, fn)
    Note over P: legacy_mode_flag && !runes →<br/>context.l = { s:null, u:null, $:[] }
    M->>IF: invoke instance fn
    IF->>API: onMount / beforeUpdate / afterUpdate calls
    API->>P: push fns into context.l.u.m / .b / .a
    IF->>I: $.init(immutable)
    I->>I: context.l.u null? → return (no-op)
    I->>E: user_pre_effect(beforeUpdate runner)
    I->>E: user_effect(onMount runner + cleanup)
    I->>E: user_effect(afterUpdate runner)
    E->>DOM: flush effects: render component DOM
    Note over E: onMount callbacks run once<br/>(before afterUpdate), cleanups captured
    M->>DOM: hydrate/anchor template
```

### 4.2 Update propagation (`beforeUpdate` → render → `afterUpdate`)

```mermaid
flowchart TD
    A["A signal in the component's<br/>observable neighborhood changes<br/>(prop identity in immutable mode,<br/>any local signal otherwise)"] --> B{"immutable mode?"}
    B -- "yes" --> C["derived version counter bumps<br/>(prop identity comparison)"]
    B -- "no" --> D["props() = deep_read_state(context.s)<br/>re-read registers deps"]
    C --> E["beforeUpdate pre-effect re-runs:<br/>observe_all(context, props)<br/>→ run_all(callbacks.b)"]
    D --> E
    E --> F["Render effects update the DOM<br/>(client-dom-renderer)"]
    F --> G["afterUpdate user-effect re-runs:<br/>observe_all(context, props)<br/>→ run_all(callbacks.a)"]
    G --> H["onMount callbacks do NOT re-run<br/>(collected once at mount, cleanups<br/>invoked on unmount)"]
```

### 4.3 Coarse invalidation via `invalidate_inner_signals`

```mermaid
flowchart LR
    A["legacy code path calls<br/>invalidate_inner_signals(fn)"] --> B["capture_signals(fn):<br/>fn runs untracked;<br/>every signal read is added<br/>to captured_signals Set"]
    B --> C["for each captured signal:<br/>internal_set(signal, signal.v)"]
    C --> D["write version bumped,<br/>dependents marked DIRTY"]
    D --> E["batch scheduler flushes<br/>affected effects<br/>(client-reactivity-engine_batching-scheduling)"]
```

---

## 5. Dependencies

### 5.1 Internal dependency map

```mermaid
graph TD
    subgraph ThisModule["legacy-compat_legacy-lifecycle"]
        INIT["dom/legacy/lifecycle.js :: init"]:::this
        OBS["lifecycle.js :: observe_all"]:::this
        IIS["legacy.js :: invalidate_inner_signals"]:::this
        CAP["legacy.js :: captured_signals / capture_signals"]:::this
    end

    INIT -->|"component_context"| CTX["client/context.js"]
    INIT -->|"run, run_all"| SHARED["internal/shared/utils.js"]
    INIT -->|"user_pre_effect, user_effect"| EFF["client/reactivity/effects.js"]
    INIT -->|"derived"| DRV["client/reactivity/deriveds.js"]
    INIT -->|"get, untrack, deep_read_state"| RUN["client/runtime.js"]
    OBS --> RUN
    IIS -->|"internal_set"| SRC["client/reactivity/sources.js"]
    IIS -->|"untrack"| RUN
    CAP --> RUN

    EFF --> RUN
    DRV --> RUN
    classDef this fill:#e8f0fe,stroke:#4285f4
```

### 5.2 Consumed APIs

| Consumed symbol | Source module / file | Why it's needed |
| --- | --- | --- |
| `component_context` | [`context-api`](context-api.md) (`internal/client/context.js`) | Read the currently-installed `ComponentContextLegacy` (set by `push()`) |
| `run`, `run_all` | `internal/shared/utils.js` ([internal-shared-utils](internal-shared-utils.md)) | Invoke individual and arrays of lifecycle callbacks |
| `user_pre_effect` | [`client-reactivity-engine_effects`](client-reactivity-engine_effects.md) | `beforeUpdate` runner (render effect, runs before DOM update) |
| `user_effect` | [`client-reactivity-engine_effects`](client-reactivity-engine_effects.md) | `onMount` and `afterUpdate` runners (effects run after render) |
| `derived` | [`client-reactivity-engine_deriveds-and-async`](client-reactivity-engine_deriveds-and-async.md) | Immutable-mode version counter derived |
| `get` | [`client-reactivity-engine_signal-graph`](client-reactivity-engine_signal-graph.md) | Subscribe to local signals (`context.l.s`) and derived version inside effects |
| `deep_read_state` | [`client-reactivity-engine_signal-graph`](client-reactivity-engine_signal-graph.md) | Recursively read prop state to register dependencies |
| `untrack` | [`client-reactivity-engine_signal-graph`](client-reactivity-engine_signal-graph.md) | Run `onMount` callbacks / captured functions without creating dependencies |
| `internal_set` | [`client-reactivity-engine_sources-and-proxies`](client-reactivity-engine_sources-and-proxies.md) | Force-invalidate captured signals |
| `legacy_mode_flag` | [`client-reactivity-engine_foundation`](client-reactivity-engine_foundation.md) (`internal/flags`) | Decides `push()` whether to allocate the `l` legacy block at all |

### 5.3 Consumers of this module

| Consumer | Interaction |
| --- | --- |
| Compiler client transform ([compiler-transformer_client-transform](compiler-transformer_client-transform.md)) | Emits `$.init(immutable)` into legacy instance functions (import of `dom/legacy/lifecycle.js`); emits `$.legacy_pre_effect` for `$:` statements which populates `context.l.$` |
| Public API ([public-api](public-api.md), `index-client.js`) | `onMount`/`beforeUpdate`/`afterUpdate` write into `context.l.u` in legacy mode — the data `init()` consumes. `beforeUpdate`/`afterUpdate` are legacy-only and error in runes mode |
| Component API shims ([legacy-compat_component-api-shims](legacy-compat_component-api-shims.md)) | `Svelte4Component` / `asClassComponent` mount legacy components via `mount`/`hydrate`; the resulting components run this module's lifecycle effects |
| Legacy events & props ([legacy-compat_legacy-events-and-props](legacy-compat_legacy-events-and-props.md)) | Sibling compatibility surface; `update_legacy_props` mutates the same coarse `context.s` props that `observe_all` reads |
| `$:` statement runtime ([client-reactivity-engine_effects](client-reactivity-engine_effects.md)) | `legacy_pre_effect`/`legacy_pre_effect_reset` use `context.l.$` from the same legacy context block |

---

## 6. Design Notes & Gotchas

- **Ordering guarantee:** `init` registers `onMount` as a `user_effect` *before* the `afterUpdate` effect, so on first mount the callbacks observe Svelte 4's ordering: `beforeUpdate` → DOM → `onMount` → `afterUpdate`. On subsequent updates: `beforeUpdate` → DOM → `afterUpdate` (no `onMount`).
- **`onMount` runs untracked:** callbacks execute inside `untrack(...)` so reads inside them do not create dependencies; returned cleanup functions are collected and invoked on teardown.
- **Coarse subscription on purpose:** `observe_all` deliberately reads *every* local signal and *deep-reads* props. This is what makes `beforeUpdate`/`afterUpdate` fire for "any change the component could see" — matching Svelte 4 semantics, at the cost of granularity.
- **Immutable vs. mutable props:** legacy components default to immutable prop semantics — `init(immutable=true)` means callbacks re-fire only when a prop's *identity* changes (the derived version-counter trick). Runes components that pass fine-grained `$state` props into legacy components would otherwise not be seen as changes.
- **Zero-cost opt-out:** legacy components that use none of the three hooks never allocate `context.l.u`, and `init` returns immediately.
- **Everything is `@deprecated`:** `init`, `invalidate_inner_signals`, `captured_signals`, and the whole `ComponentContext.l` block are annotated for removal in Svelte 6.0. New runtime features must not depend on them; compiler-side migration support lives in [compiler-migrator](compiler-migrator.md) (`svelte-migrate`), and options diagnostics for removed legacy APIs in [`compiler-core_options_validation`](compiler-core_options_validation.md).

---

## 7. Related Documentation

- [legacy-compat](legacy-compat.md) — parent compatibility layer overview
- [legacy-compat_component-api-shims](legacy-compat_component-api-shims.md) — `createClassComponent`, `asClassComponent`, `Svelte4Component`
- [legacy-compat_legacy-events-and-props](legacy-compat_legacy-events-and-props.md) — event modifiers, bubbling, legacy prop updates
- [client-reactivity-engine](client-reactivity-engine.md) — signal graph, effects, batching powering the lifecycle effects
- [client-dom-renderer_lifecycle](client-dom-renderer_lifecycle.md) — `mount`/`hydrate`/`unmount` entry points
- [context-api](context-api.md) — `push`/`pop` and `component_context` management
- [public-api](public-api.md) — user-facing `onMount`, `beforeUpdate`, `afterUpdate`, `createEventDispatcher`
- [Compiler_Pipeline___Language_Toolchain](Compiler_Pipeline___Language_Toolchain.md) — where `$.init(...)` calls and legacy callback registrations are generated
