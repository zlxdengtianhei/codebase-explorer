# Parsing Utilities (`compiler-parser_parsing-utilities`)

## 1. Overview

`compiler-parser_parsing-utilities` is a small, stateless support module inside **Phase 1 — Parse** of the Svelte compiler. It does not build AST nodes and holds no parser state; instead it provides two focused utility areas that the surrounding parser machinery depends on:

| Area | File | Responsibility |
|---|---|---|
| **Fuzzy name matching** | `phases/1-parse/utils/fuzzymatch.js` | Approximate string matching (QGram/cosine similarity refined by Levenshtein distance) used to produce *"did you mean …?"* suggestions for typos in diagnostics. |
| **HTML character reference decoding** | `phases/1-parse/utils/html.js` | Decoding of named, decimal and hexadecimal HTML entities (`&amp;`, `&#38;`, `&#x26;`, …) in template **text content** and **attribute values**, following the WHATWG HTML parsing rules. |

Both files are pure helpers: they take strings in and return strings/patterns out. All stateful parsing behaviour lives in the sibling modules documented by [compiler-parser.md](compiler-parser.md) — the state machine in [compiler-parser_parser-core.md](compiler-parser_parser-core.md) and the grammar states in [compiler-parser_parsing-states.md](compiler-parser_parsing-states.md).

---

## 2. Position in the Compiler Pipeline

The utilities sit at the bottom of the parse phase's dependency graph. They are consumed by the parser states while the template is scanned, and their results end up directly inside the AST produced by `compile()` / `compileModule()` (see [compiler-core_public_api.md](compiler-core_public_api.md)).

```mermaid
flowchart LR
    SRC["Svelte source<br/>(template string)"] --> PH1["Phase 1 — Parse"]
    PH1 --> PH2["Phase 2 — Analyze<br/>(compiler-analyzer)"]
    PH2 --> PH3["Phase 3 — Transform<br/>(compiler-transformer)"]

    subgraph PARSE ["Phase 1 — Parse internals"]
        direction TB
        CORE["parser-core<br/>index.js — Parser state machine"]
        STATES["parsing-states<br/>fragment.js · element.js · text.js"]
        OPTS["options-reading<br/>read/options.js"]
        JSTS["js-ts-parsing<br/>acorn.js · TS node stripping"]
        UTILS["parsing-utilities (this module)<br/>utils/fuzzymatch.js · utils/html.js"]

        CORE --> STATES
        CORE --> OPTS
        CORE --> JSTS
        STATES --> UTILS
        OPTS -.-> UTILS
    end

    PARSE --> AST["AST.Root<br/>(compiler-core_type_definitions)"]
```

- `text.js` and `element.js` (attribute values) call `decode_character_references(...)` for **every** raw text chunk and quoted attribute value they read.
- `fuzzymatch` backs approximative name lookup for diagnostic suggestions ("did you mean `svelte:head`?" style hints). Its output flows into the error/warning machinery described in [compiler-core_diagnostics.md](compiler-core_diagnostics.md).

---

## 3. Module Composition

| File | Export | Visibility | Description |
|---|---|---|---|
| `utils/fuzzymatch.js` | `fuzzymatch(name, names)` | default export (module-private within compiler) | Returns the closest candidate from `names` for `name`, or `null` if nothing scores above `0.7`. |
| `utils/fuzzymatch.js` | `sort_descending(a, b)` | internal | Comparator for `[score, string]` match tuples (`b[0] - a[0]`), used to rank match results in descending score order. |
| `utils/fuzzymatch.js` | `_distance`, `levenshtein`, `iterate_grams`, `gram_counter`, `class FuzzySet` | internal | Algorithmic building blocks of the fuzzy matcher (see §5). |
| `utils/html.js` | `get_entity_pattern(is_attribute_value)` | internal (cached at module scope) | Builds the regular expression that recognises character references, with attribute-value-specific semantics. |
| `utils/html.js` | `decode_character_references(html, is_attribute_value)` | export | Replaces all character references in `html` with their Unicode equivalents. |
| `utils/html.js` | `validate_code(code)` | internal | Sanitises decoded code points to match browser leniency (see §4.4). |
| `utils/html.js` | `windows_1252` | internal | Lookup table mapping code points 128–159 to their Windows-1252 equivalents. |
| `utils/entities.js` | `entities` (default) | data dependency | Named-entity → code point table (e.g. `amp → 38`); not part of this module but consumed by `html.js`. |

---

## 4. Character Reference Decoding (`utils/html.js`)

### 4.1 Purpose

Raw template text and attribute values may contain HTML character references. The parser stores the **raw** source slice (`raw`) alongside the **decoded** value (`data`) on `AST.Text` nodes, so downstream phases (analysis, transformation, SSR) always operate on decoded strings. The type shapes live in [compiler-core_type_definitions.md](compiler-core_type_definitions.md).

```js
// produced by text()
{
  type: 'Text',
  start, end,
  raw: '&amp;hello',          // untouched source slice
  data: decode_character_references('&amp;hello', false) // '&hello'
}
```

### 4.2 Pattern construction — `get_entity_pattern(is_attribute_value)`

Two regular expressions are built **once at module load** and cached, so decoding never pays pattern-construction costs per call:

```mermaid
flowchart TD
    A["get_entity_pattern(is_attribute_value)"] --> B["Numeric part:<br/>'#(?:x[a-fA-F\\d]+|\\d+)(?:;)?'"]
    A --> C["Named part:<br/>every key of entities.js"]
    C --> D{"is_attribute_value?"}
    D -- "yes" --> E["Names not ending in ';'<br/>become 'name\\b(?!=)'"]
    D -- "no" --> F["Names used verbatim"]
    B --> G["Final pattern:<br/>&( numeric | named1 | named2 | … ) with /g flag"]
    E --> G
    F --> G
    G --> H["Cached as entity_pattern_content (false)<br/>or entity_pattern_attr_value (true)"]
```

The attribute-value nuance implements the WHATWG *named character reference state*: inside an attribute value, a named reference **without a trailing semicolon** must *not* be decoded when immediately followed by `=`, an alphanumeric, or other word characters. Hence:

- Content mode: `&amp;` and `&amp` (no semicolon) both decode.
- Attribute mode: `&amp;` decodes, but `href="?a=1&amp=b"` or `&ampx` deliberately do **not** — the `\b(?!=)` suffix blocks a match when the next character is `=` or a word character.

### 4.3 Decoding flow — `decode_character_references(html, is_attribute_value)`

```mermaid
flowchart TD
    A["html string + mode flag"] --> B{"Select cached pattern"}
    B -- "content" --> C["entity_pattern_content"]
    B -- "attribute value" --> D["entity_pattern_attr_value"]
    C --> E["Replace every '&…' match"]
    D --> E
    E --> F{"Entity kind?"}
    F -- "named (no '#')" --> G["code = entities[entity]"]
    F -- "'&#x…'" --> H["code = parseInt(hex, 16)"]
    F -- "'&#…'" --> I["code = parseInt(dec, 10)"]
    G --> J{"code truthy?"}
    H --> J
    I --> J
    J -- "no" --> K["Keep original match text"]
    J -- "yes" --> L["String.fromCodePoint(validate_code(code))"]
    L --> M["Decoded string"]
    K --> M
```

Key behaviours:

1. **Three reference forms** are supported: named (`&copy;`), decimal (`&#169;`) and hexadecimal (`&#xA9;`); numeric semicolons are optional.
2. **Unknown/zero code points** (e.g. `&#0;`) leave the source text untouched rather than injecting `NUL`.
3. **Case-sensitive names**: the pattern is generated from the exact keys of the entity table, so `&Aacute;` and `&aacute;` are distinct entries, matching the HTML spec.

### 4.4 Code point sanitisation — `validate_code(code)`

Browsers silently repair some illegal code points; since the compiler bypasses the browser's own parser, `validate_code` reproduces that leniency:

| Input code point | Result | Rationale |
|---|---|---|
| `10` (line feed) | `32` (space) | LF is normalised to generic whitespace. |
| `< 128` | unchanged | ASCII pass-through. |
| `128–159` (C1 controls) | `windows_1252[code - 128]` | Browsers map this range to Windows-1252 (e.g. `&#128;` → `€`); without this, `€` signs would go missing. |
| `55296–57343` (UTF-16 surrogate halves) | `NUL` (`0`) | Lone surrogates are invalid scalar values. |
| Valid BMP / supplementary-plane ranges (incl. planes 1–2 and special-purpose ranges `0xE0000–0xE07F`, `0xE0100–0xE01EF`) | unchanged | Legal scalar values pass through. |
| Anything else (e.g. non-characters outside listed planes) | `NUL` (`0`) | Illegal code points are neutralised. |

### 4.5 Consumers and data flow

The decoding utilities are invoked synchronously from the grammar states while characters are consumed:

```mermaid
sequenceDiagram
    participant P as Parser (parser-core)
    participant F as fragment()
    participant T as text()
    participant E as element()/read_attribute()
    participant H as decode_character_references
    participant A as AST (Text / Attribute value)

    P->>F: dispatch on next char
    F->>T: plain text run (not '<' or '{')
    T->>T: accumulate raw slice
    T->>H: decode(raw, false)  — content mode
    H-->>T: decoded string
    T-->>A: { raw, data } appended

    F->>E: '<tag …'
    E->>E: read_attribute_value() collects quoted chunks
    E->>H: decode(chunk, true)  — attribute mode
    H-->>E: decoded string
    E-->>A: value chunks (Text/ExpressionTag)
```

Both call sites live in the parsing-states module — see [compiler-parser_parsing-states.md](compiler-parser_parsing-states.md) for the surrounding state machine (`fragment` → `element` / `text` dispatch).

---

## 5. Fuzzy Matching (`utils/fuzzymatch.js`)

### 5.1 Public API

```js
fuzzymatch(name, names) // → string | null
```

Given a possibly misspelled `name` and a list of valid `names`, returns the best candidate **only if its similarity score exceeds `0.7`**, otherwise `null`. This strict threshold prevents bogus suggestions like `svelte:head` → `svelte:he` being offered in error messages. The result feeds the diagnostics layer (see [compiler-core_diagnostics.md](compiler-core_diagnostics.md)), which attaches source location and code frames via helpers such as `get_code_frame`.

### 5.2 Algorithm walkthrough

The implementation is an adapted, type-annotated copy of `Glench/fuzzyset.js` (BSD-licensed, incorporated in 2016). Matching proceeds in two stages — a cheap **QGram/cosine** ranking, then a precise **Levenshtein** rescoring of the top candidates:

```mermaid
flowchart TD
    A["fuzzymatch(name, names)"] --> B{"names empty?"}
    B -- "yes" --> Z["return null"]
    B -- "no" --> C["Construct FuzzySet(names)<br/>gram sizes 2 and 3, exact_set index"]
    C --> D{"Exact (case-insensitive)<br/>match in exact_set?"}
    D -- "yes" --> E["score = 1 — immediate hit"]
    D -- "no" --> F["Try gram size 3:<br/>cosine similarity over shared grams"]
    F --> G{"Any results?"}
    G -- "no" --> H["Retry with gram size 2"]
    H --> G
    G -- "yes" --> I["Sort descending by cosine score<br/>truncate to top 50"]
    I --> J["Rescore each candidate with<br/>normalised Levenshtein distance"]
    J --> K["Keep all candidates tied<br/>with the best distance"]
    K --> L["Return best matches (score, string)"]
    E --> L
    L --> M{"matches[0].score > 0.7?"}
    M -- "yes" --> N["return matching string"]
    M -- "no" --> Z
```

### 5.3 Internal building blocks

**Gram generation**

- `iterate_grams(value, gram_size)` — normalises the input to `'-' + lowercase(value with non-word chars stripped) + '-'`, pads with `'-'` when shorter than the gram size, and slides a window to emit character n-grams. The leading/trailing `-` gives word edges their own signal.
- `gram_counter(value, gram_size)` — converts the gram list into a `Record<string, count>` bag.

**Scoring**

- `FuzzySet.__get` computes a **cosine similarity** between the query's gram bag and each indexed item's bag: `Σ(query_count × item_count) / (‖query‖ × ‖item‖)`, where the per-item vector norms are precomputed in `FuzzySet._add`. Shared grams are located in O(1) via `match_dict` (`gram → [[itemIndex, count], …]`).
- `_distance(str1, str2)` converts an edit distance into a similarity in `[0, 1]`: `1 - levenshtein / max(len1, len2)`.
- `levenshtein` is a classic dynamic-programming implementation using a single rolling row (`current[]`), giving O(n·m) time with O(n) extra memory.

**Ranking helpers**

- `sort_descending(a, b)` — the comparator applied to `MatchTuple` results (`[score: number, match: string]`), ordering strictly by descending score. It is used twice: after cosine ranking and again after Levenshtein rescoring.
- After rescoring, only candidates **tied with the best score** are returned; `fuzzymatch` then inspects just the first one.

**FuzzySet data structures**

| Field | Shape | Role |
|---|---|---|
| `exact_set` | `normalized → original` | Case-insensitive deduplication and the exact-match fast path; also maps normalised winners back to their original strings. |
| `match_dict` | `gram → [[index, count], …]` | Inverted index from each 2-/3-gram to the items containing it. |
| `items` | `gram_size → [[vector_normal, normalized_value], …]` | Per-gram-size item table with precomputed norms for cosine scoring. |

### 5.4 Behavioural guarantees and edge cases

- **Empty candidate list** → `null` without constructing a `FuzzySet`.
- **Exact match** (case-insensitive) short-circuits with score `1`.
- **No match above threshold** → `null`; callers must treat the suggestion as optional in messages.
- **Gram-size fallback** (3 → 2) trades precision for recall: trigrams give fewer false positives, bigrams rescue short strings with no trigram overlap.
- **Deterministic**: results depend only on inputs; ties are resolved by array construction order.
- The source retains a few `@ts-ignore` markers on the adapted library code — behaviour is intentionally preserved from the upstream implementation.

---

## 6. Dependencies

### Internal

| Dependency | Used by | Purpose |
|---|---|---|
| `utils/entities.js` (data) | `html.js` | Named-entity → code point table used both for pattern generation and decoding. |
| Parsing states `state/text.js`, `state/element.js` | `html.js` | Decode raw text and attribute values during parsing ([compiler-parser_parsing-states.md](compiler-parser_parsing-states.md)). |
| Diagnostics layer | `fuzzymatch.js` | "Did you mean" suggestions embedded into compile errors ([compiler-core_diagnostics.md](compiler-core_diagnostics.md)). |

### External

- None at runtime. Both files are dependency-free apart from the entity data module; `fuzzymatch.js` contains a fully self-contained port of the fuzzyset algorithm.

```mermaid
flowchart LR
    subgraph MODULE ["compiler-parser_parsing-utilities"]
        FM["fuzzymatch.js<br/>FuzzySet · levenshtein<br/>sort_descending"]
        HTML["html.js<br/>get_entity_pattern<br/>decode_character_references<br/>validate_code"]
    end

    ENT["utils/entities.js<br/>(named-entity table)"] --> HTML
    HTML --> TEXT["state/text.js<br/>AST.Text.data"]
    HTML --> ATTR["state/element.js<br/>attribute value chunks"]
    FM --> DIAG["errors.js / diagnostics<br/>'did you mean' hints"]
    TEXT --> AST2["AST (compiler-core_type_definitions)"]
    ATTR --> AST2
```

---

## 7. Design and Performance Notes

1. **Module-scope caching in `html.js`.** Both entity regexes are compiled once at import time. Generation iterates the full entity table and joins it into one alternation, so per-call decoding cost is a single `String.replace` with a shared global regex.
2. **Two patterns instead of runtime branching.** Content vs. attribute semantics differ structurally (`\b(?!=)` suffixes); baking them into two static patterns avoids per-match conditional logic.
3. **Bounded fuzzy search.** Cosine ranking is truncated to the top 50 candidates before the more expensive Levenshtein rescoring, keeping worst-case cost roughly `50 × O(n·m)` per lookup regardless of candidate-list size.
4. **Zero-dependency, pure functions.** The utilities are safe to call during parsing without side effects and are trivially tree-shakeable in builds that don't exercise the corresponding paths (see [treeshakeability_checker.md](treeshakeability_checker.md) for how the team verifies this).
5. **Legacy-provenance code.** The `FuzzySet` implementation is a 2016 adaptation of `fuzzyset.js`; a few `@ts-ignore` annotations mark spots where the original dynamic behaviour is intentionally retained over strict typing.

---

## 8. Related Documentation

- [compiler-parser.md](compiler-parser.md) — parent module: Phase 1 parse overview.
- [compiler-parser_parser-core.md](compiler-parser_parser-core.md) — the `Parser` class and state-machine driver that invokes the grammar states.
- [compiler-parser_parsing-states.md](compiler-parser_parsing-states.md) — `fragment()` / `element()` / `text()` grammar states, the direct consumers of entity decoding.
- [compiler-parser_options-reading.md](compiler-parser_options-reading.md) — `<svelte:options>` attribute reading (shares the attribute-value path that uses entity decoding).
- [compiler-parser_js-ts-parsing.md](compiler-parser_js-ts-parsing.md) — JS/TS expression parsing inside templates.
- [compiler-core.md](compiler-core.md) — compiler core: public API, state, diagnostics, AST builders and type definitions.
- [compiler-core_diagnostics.md](compiler-core_diagnostics.md) — error/warning infrastructure that fuzzy suggestions and code frames plug into.
- [compiler-core_type_definitions.md](compiler-core_type_definitions.md) — `AST.Text`, attribute and directive node types produced using these utilities.