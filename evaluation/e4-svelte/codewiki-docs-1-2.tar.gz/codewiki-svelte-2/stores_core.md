# stores_core

## Introduction

`stores_core` is the shared implementation engine of Svelte's classic **store contract** — the framework-agnostic reactive value containers (`writable`, `readable`, `derived`, `readonly`) plus the synchronous value accessor `get`. It lives in a single file, `packages/svelte/src/store/shared/index.js`, and is deliberately **platform-independent**: the same implementation is served to both client and server entry points, which is why it sits in the `store/shared/` directory.

The module implements the store contract defined by the `stores_contract` types ([stores_contract.md](stores_contract.md)) — `Readable<T>`, `Writable<T>`, `Stores`, and `StoresValues` — and serves as the foundation for the `fromStore`/`toStore` adapters in [stores_bridge.md](stores_bridge.md), which bridge classic stores to Svelte 5's runes-based reactivity system.

### At a Glance

| Export | Kind | Purpose |
|---|---|---|
| `writable(value, start?)` | factory | Full store with `set`, `update`, `subscribe` |
| `readable(value, start?)` | factory | Read-only view over a `writable` |
| `derived(stores, fn, initial_value?)` | factory | Store computed from one or more input stores |
| `readonly(store)` | utility | Strips write access from an existing store |
| `get(store)` | utility | Synchronously snapshot a store's current value |
| `subscriber_queue` | internal | Module-level batching queue for notifications |

### Design Principles

1. **Push-based subscription** — consumers subscribe with a `run` callback (and optional `invalidate` cleanup); the store pushes values to all subscribers on change.
2. **Lazy lifecycle** — an optional `StartStopNotifier` runs only while at least one subscriber exists and is torn down when the last subscriber leaves. This makes derived chains and side-effectful sources cheap when unused.
3. **Change detection** — updates are filtered through `safe_not_equal` so subscribers are not notified when a value does not meaningfully change (identical primitives; `NaN` is handled specially).
4. **Batched invalidation** — a module-level `subscriber_queue` guarantees all subscribers in a dependency chain are *invalidated* before any *run* callbacks execute, so consumers never observe torn/partial intermediate states.

---

## Architecture

### Position within the stores family

`stores_core` sits at the center of the three-part stores subsystem of the `Public_API___Built-in_Feature_Surface` module:

```mermaid
flowchart TB
    subgraph stores ["stores subsystem"]
        direction TB
        CONTRACT["stores_contract<br/>(public.d.ts / private.d.ts)<br/>Readable · Writable · Stores · StoresValues"]
        CORE["<b>stores_core</b><br/>(store/shared/index.js)<br/>readable · writable · derived<br/>readonly · get"]
        BRIDGE["stores_bridge<br/>(index-client.js / index-server.js)<br/>fromStore · toStore"]
        UTILS["store/utils.js<br/>subscribe_to_store"]
    end

    CONTRACT -- "types constrain API surface" --> CORE
    CORE -- "consumes subscribe_to_store()" --> UTILS
    CORE -- "writable() reused by toStore()" --> BRIDGE
    BRIDGE -- "fromStore() falls back to get()" --> CORE
```

### External dependencies

`stores_core` is intentionally minimal in its dependencies — only three imports, all of which are cross-cutting utilities:

```mermaid
flowchart LR
    CORE["<b>stores_core</b><br/>store/shared/index.js"]

    subgraph deps ["Dependencies"]
        direction TB
        EQ["client-reactivity-engine<br/>internal/client/reactivity/equality.js<br/>safe_not_equal"]
        SHARED["internal-shared-utils<br/>internal/shared/utils.js<br/>noop · run_all"]
        SUB["store/utils.js<br/>subscribe_to_store"]
    end

    EQ -- "change detection in writable.set()" --> CORE
    SHARED -- "default notifier / teardown loops" --> CORE
    SUB -- "uniform subscription incl. RxJS-compat" --> CORE

    CORE --> BRIDGE["stores_bridge<br/>(fromStore · toStore)"]
    CORE --> MOTION["motion<br/>(spring · tweened build on writable)"]
```

- **`safe_not_equal`** ([client-reactivity-engine.md](client-reactivity-engine.md)): the equality predicate used by `writable.set` to decide whether subscribers must be notified. It treats two identical primitives as "equal" (skip), `NaN` compared against anything as "not equal" (always notify), and objects/functions as always "not equal" (reference identity).
- **`noop` and `run_all`** ([internal-shared-utils.md](internal-shared-utils.md)): default no-op notifier and the helper that invokes every unsubscriber during teardown.
- **`subscribe_to_store`** (`store/utils.js`): a defensive subscription wrapper that (a) calls `run`/`invalidate` with `undefined` instead of crashing on `null` stores, (b) wraps `store.subscribe` in `untrack` so that starting a notifier inside a runes effect doesn't get captured, and (c) normalizes RxJS observables (`.unsubscribe()` methods) into plain Svelte unsubscribers. `derived` and `get` route all subscriptions through it.

The store *contract* itself (`Readable`, `Writable`, `Stores`, `StoresValues`) is documented in [stores_contract.md](stores_contract.md) and is not re-described here.

---

## Component Reference

### `writable(value, start = noop)`

The foundational factory. Everything else in the module is either built on top of it (`readable`, `derived`) or operates on its products (`readonly`, `get`).

**Internal state per instance**

| Field | Type | Role |
|---|---|---|
| `value` | `T` (closure) | Current value; replaced in place on `set` |
| `subscribers` | `Set<[run, invalidate]>` | Registered subscriber tuples |
| `stop` | `Unsubscriber \| null` | Teardown handle of the `start` notifier; `null` while inactive |
| `subscriber_queue` | module-level array | Flat pairs of `[subscriber, value]` pending notification |

**`set(new_value)` — the notification pipeline**

```mermaid
flowchart TD
    A["set(new_value)"] --> B{"safe_not_equal(value, new_value)?"}
    B -- "no (equal)" --> Z1["no-op: no notification"]
    B -- "yes" --> C["value = new_value"]
    C --> D{"stop !== null?<br/>(store is active)"}
    D -- "no (no subscribers)" --> Z2["done — value stored<br/>for the next subscriber"]
    D -- "yes" --> E["for each subscriber:<br/>1. invoke invalidate()<br/>2. push [subscriber, value] to queue"]
    E --> F{"queue was empty<br/>before this set?<br/>(run_queue)"}
    F -- "yes (outermost set)" --> G["flush queue:<br/>for i step 2:<br/>subscriber[i](value[i+1])"]
    G --> H["queue.length = 0"]
    F -- "no (nested set from<br/>a run callback)" --> Z3["defer — outermost<br/>set() will flush"]
```

Key behaviors:

- **Change filtering**: identical primitive values never notify. This is what allows `set` to be called optimistically (e.g. from `update` or derived `sync`) without spurious re-renders.
- **Two-phase flush**: `invalidate` callbacks for *all* affected stores run before *any* `run` callback. The `run_queue` flag ensures only the outermost, non-reentrant `set` performs the flush; nested `set` calls (triggered from within a subscriber callback, e.g. a derived store writing downstream) simply append to the queue and are drained by the original flush. The net effect: every store touched in a transaction is invalidated before any subscriber observes new values.
- **Dormant writes are cheap**: if the store has no active subscribers (`stop === null`), `set` only replaces `value`. The new value is delivered to whoever subscribes next (subscribers receive the current value immediately upon subscription).

**`update(fn)`** — convenience wrapper: `set(fn(current_value))`. This is the `update` component named in the module's core components.

**`subscribe(run, invalidate = noop)`**

```mermaid
sequenceDiagram
    participant C as Consumer
    participant W as writable instance
    participant S as StartStopNotifier

    C->>W: subscribe(run, invalidate)
    W->>W: subscribers.add([run, invalidate])
    alt first subscriber (size === 1)
        W->>S: start(set, update)
        S-->>W: optional cleanup fn (stored as stop)
    end
    W->>C: run(current value) — synchronous initial delivery
    W-->>C: unsubscriber()
    Note over C,W: later...
    C->>W: unsubscriber()
    W->>W: subscribers.delete(tuple)
    alt last subscriber left (size === 0)
        W->>S: stop() — tear down notifier
        W->>W: stop = null
    end
```

The start/stop lifecycle means resource-backed stores (timers, `EventSource`, media queries) only run while observed.

### `readable(value, start)`

A one-liner: creates a `writable` and returns an object exposing only its `subscribe` method. Ideal for exposing state that should never be written externally (e.g. the result of `derived` or vendor data sources).

### `derived(stores, fn, initial_value)`

The most complex component: creates a `Readable` whose value is computed from one or more input stores. It supports two overloaded shapes (see JSDoc overloads):

- **Auto mode** (`fn.length < 2`, i.e. `fn(values) => T`): the return value of `fn` is pushed via `set` automatically.
- **Manual mode** (`fn(values, set, update)`): `fn` decides when/what to publish and may return an optional cleanup function, which is treated as the derived store's per-recomputation teardown (e.g. to unsubscribe from an inner async chain).

**Dependency fan-in and the `pending` bitmask**

```mermaid
flowchart TD
    subgraph inputs ["Input stores (array or single)"]
        S0["store 0"]
        S1["store 1"]
        Sn["store N"]
    end

    subgraph tracking ["per-subscription tracking"]
        V["values[i] — latest value per input"]
        P["pending bitmask —<br/>bit i set while store i<br/>has not emitted its<br/>first value"]
    end

    S0 -->|"subscribe_to_store:<br/>run → values[0] = v,<br/>pending &amp;= ~(1<<0)"| V
    S1 -->|"invalidate →<br/>pending |= 1<<1"| P
    Sn --> V

    V --> SYNC{"sync():<br/>pending === 0?"}
    P --> SYNC
    SYNC -- "no — an input is still<br/>waiting for first value" --> Z["hold — do not compute"]
    SYNC -- "yes" --> CL["cleanup() from previous<br/>computation (manual mode)"]
    CL --> FN["result = fn(values,<br/>set, update)"]
    FN --> AUTO{"auto mode?<br/>(fn.length < 2)"}
    AUTO -- "yes" --> SETV["set(result) →<br/>notify derived's subscribers"]
    AUTO -- "no" --> MANUAL["cleanup = result if<br/>it is a function"]
```

**Flow narrative**

1. **Normalization**: `stores` may be a single `Readable` or an array; internally normalized to `stores_array`. Falsy entries throw immediately: `derived() expects stores as input, got a falsy value`.
2. **Subscription phase**: each input is subscribed via `subscribe_to_store`. The *invalidate* callback sets bit `i` in `pending`; the *run* callback stores the value in `values[i]`, clears bit `i`, and — only after the initial handshake (`started === true`) — triggers `sync()`.
3. **Initial sync**: after subscribing to all inputs, `started` is flipped to `true` and `sync()` runs once. Because every input's invalidate callback fired during subscription, `pending` is non-zero until each input has delivered its first value; `sync` therefore waits for the complete initial fan-in before computing anything. This prevents the derived store from publishing a value computed from a partially initialized `values` array.
4. **Recomputation**: every subsequent input emission calls `sync()`, which tears down the previous manual-mode cleanup, re-invokes `fn` with the aggregate `values`, and publishes (auto) or defers (manual) the result. A subtree of inputs updating in quick succession still produces one downstream notification per `set` thanks to `writable`'s queue flush semantics.
5. **Teardown (`stop`)**: when the derived store's last subscriber leaves, the `StartStopNotifier` returned to `readable` runs: `run_all(unsubscribers)` detaches from every input, `cleanup()` runs the last manual cleanup, and `started` is set to `false`. The `started = false` step is subtle and explicitly commented in the source: queued input callbacks may still fire after unsubscription (they were enqueued before the unsubscribe), so the flag is the guard that prevents stale callbacks from re-entering `sync()` on a dead derived store.

**Semantics summary**

| Aspect | Behavior |
|---|---|
| Input arity | 1 store or an array of stores |
| Value shape passed to `fn` | unwrapped value for single input; array for multiple |
| First publication | only after *all* inputs have emitted at least once (`pending === 0`) |
| Eager vs lazy | lazy: input subscriptions exist only while the derived store has subscribers |
| Manual cleanup | `fn` may return a function; invoked before each recompute and at teardown |
| Re-entrancy safety | `started` flag blocks post-unsubscribe queued callbacks |

### `readonly(store)`

Returns `{ subscribe }` bound to the wrapped store's `subscribe`. It does not create a copy or intercept values — it is purely an access-control wrapper (the source carries a `@ts-expect-error` noting the `bind` may be unnecessary; it is kept as a defensive measure for stores implemented with `this`-dependent methods).

### `get(store)`

Synchronously snapshots a store's value without keeping a subscription:

```javascript
let value;
subscribe_to_store(store, (_) => (value = _))();
return value;
```

Because Svelte stores deliver the current value synchronously on subscription, the run callback fires immediately, capturing the value; the returned unsubscriber is invoked in the same statement, so no long-lived subscription exists. In runes components, prefer `$store` auto-subscription; `get` is for use *outside* reactive contexts (event handlers, module code, tests). Note that `stores_bridge`'s `fromStore` uses exactly this fallback when `get current` is evaluated outside effect tracking.

---

## Interaction with the Broader System

### Who consumes `stores_core`

```mermaid
flowchart TD
    CORE["<b>stores_core</b><br/>writable · readable · derived · readonly · get"]

    BRIDGE["stores_bridge<br/>toStore() wraps writable()<br/>fromStore() falls back to get()"]
    MOTION["motion package<br/>spring() / tweened()<br/>implemented over writable"]
    PUBLIC["svelte/store public surface<br/>(re-exported to users)"]
    USER["User code & legacy<br/>components using $store"]

    CORE --> PUBLIC
    CORE -. "writable()" .-> MOTION
    CORE -. "writable() / get()" .-> BRIDGE
    PUBLIC --> USER
```

- **`stores_bridge`** ([stores_bridge.md](stores_bridge.md)): `toStore(get, set)` calls `writable(get())` from this module to hold the underlying state; `fromStore` uses `get` as the non-tracking fallback path. These adapters are the recommended interop layer between classic stores and runes-based reactivity.
- **`motion`** (`spring`, `tweened`): both build on `writable`'s subscription lifecycle, attaching a per-frame animation driver as the `StartStopNotifier` so the animation loop only runs while the store is subscribed.
- **Server parity**: because the implementation uses no DOM or client-only APIs, `index-server.js` can re-export the identical store API, satisfying SSR requirements (see [server-runtime.md](server-runtime.md) for the SSR pipeline that *consumes* stores, e.g. via `store_mutate`/`update_store`).

### Relationship to the runes reactivity engine

The two systems are deliberately decoupled:

- `stores_core` depends on only one symbol from the client reactivity engine's neighborhood (`safe_not_equal`, a pure function) — it never creates signals, effects, or batches.
- Traffic in the opposite direction is mediated by `subscribe_to_store`'s `untrack` wrapper and by [stores_bridge.md](stores_bridge.md), ensuring classic stores neither capture nor are captured by runes effect scopes unintentionally.
- Compiler-level auto-subscription of `$store` syntax is handled elsewhere in the toolchain (see [compiler-core.md](compiler-core.md) for the public API and [compiler-analyzer.md](compiler-analyzer.md)/[compiler-transformer.md](compiler-transformer.md) for the analysis and transformation phases).

---

## Data Flow End-to-End

The following sequence traces a typical chained-derivation: two sources feed a derived store, which is consumed by a component.

```mermaid
sequenceDiagram
    autonumber
    participant SrcA as source store A
    participant SrcB as source store B
    participant D as derived store
    participant C as subscriber (component)

    C->>D: subscribe(run)
    Note over D: start notifier begins
    D->>SrcA: subscribe(values[0] ←, invalidate)
    D->>SrcB: subscribe(values[1] ←, invalidate)
    Note over D: pending = 0b11 (neither has emitted)
    SrcA-->>D: v0 → values[0], pending = 0b10
    SrcB-->>D: v1 → values[1], pending = 0b00
    D->>D: sync() → fn([v0, v1]) → set(result)
    D-->>C: run(result)

    SrcA-->>D: v0' (update)
    D->>D: sync() → fn([v0', v1]) → set(result')
    D-->>C: run(result')

    C->>D: unsubscribe()
    Note over D: stop(): run_all(unsubscribers)
    D->>SrcA: unsubscribe
    D->>SrcB: unsubscribe
    Note over D: started = false →<br/>late queued callbacks ignored
```

**Invariant guaranteed by the batching queue:** if `SrcA` and `SrcB` update within a single synchronous transaction, all invalidations are queued before any run callback fires, so downstream consumers observe a consistent pair of values and derived recomputations are effectively coalesced per flush.

---

## Edge Cases & Gotchas

| Scenario | Behavior |
|---|---|
| `set` with an equal primitive | Silent no-op (`safe_not_equal` filter) |
| `set` of `NaN` | Always notifies (`a != a` special case) — intentional |
| Mutating an object held in a store | *Not detected*; objects compare by reference — call `set({...obj})` or `update` |
| Falsy entry in `derived` input array | Immediate `Error: derived() expects stores as input, got a falsy value` |
| Manual-mode `fn` returning a non-function | Treated as "no cleanup" (`noop`) |
| Input emits while derived is mid-unsubscribe | Blocked by `started = false`; queued callbacks see the dead flag |
| RxJS observable passed as a store | Supported via `subscribe_to_store`'s `.unsubscribe` normalization |
| `get()` on a store with a start notifier | Notifier starts and immediately stops (subscribe → unsubscribe in one tick) |
| >31 inputs to `derived` | `pending` is a JS number bitmask; beyond ~31 inputs the mask no longer distinguishes all indices — practical inputs are small |

---

## Extension Notes for Maintainers

- **Keep `store/shared/` environment-agnostic.** Any DOM, Node, or client-runtime import breaks the server/client parity that motivates this module's location. Pure helpers belong here or in `internal/shared/utils.js` ([internal-shared-utils.md](internal-shared-utils.md)).
- **`subscriber_queue` is module-level state**, shared by all writable instances. This is what makes cross-store batch flushing work; converting it to per-instance state would break the "invalidate-all-then-run-all" invariant across chained stores.
- **New store combinators** should follow the `derived` pattern: use `subscribe_to_store` for input subscription, a lazily-started `writable`/`readable` as the output, and mirror the `started`-flag re-entrancy guard if inputs can emit during teardown.
- **Migration direction**: new Svelte 5 code should prefer runes plus `fromStore`/`toStore` ([stores_bridge.md](stores_bridge.md]); `stores_core` remains the compatibility and interop backbone and is subject to tree-shaking checks — see the repo's `check-treeshakeability` tooling under the Engineering Tooling module so unused store helpers do not bloat bundles.
