# Client Context API (`context-api_client-context`)

> **Source:** `packages/svelte/src/internal/client/context.js`
> **Parent module:** [context-api](context-api.md) (under *Server-Side Rendering & Cross-Target Runtime Services*)
> **Counterpart module:** [context-api_server-context](context-api_server-context.md)

## Introduction

The **client context** module implements Svelte's component **context API** for browser-side execution — the mechanism behind the public `setContext`, `getContext`, `hasContext`, and `getAllContexts` functions. Beyond the public API surface, this module is the owner of the **component context stack**: a linked-list of per-component-invocation frames that the compiler-generated code (`push`/`pop`) maintains as components mount and unmount. The context stack doubles as the runtime's notion of *"which component is initializing right now"*, which the reactivity engine ([client-reactivity-engine](client-reactivity-engine.md)), legacy-mode support, and dev-time diagnostics all depend on.

Because the module operates on a shared mutable module state (`component_context`, `dev_stack`, `dev_current_component_function`), it also exports low-level setters used by the effect/branch teardown machinery to save and restore that state when components are torn down and later re-created (e.g., inside `<svelte:boundary>` resets or HMR swaps).

---

## Module Responsibilities

| Responsibility | Functions | Consumers |
|---|---|---|
| Public context API | `setContext`, `getContext`, `hasContext`, `getAllContexts` | Compiled components, [public-api](public-api.md) re-exports |
| Component context stack lifecycle | `push`, `pop`, `set_component_context` | Compiler-generated client component code, `mount`/`hydrate` in [client-dom-renderer_lifecycle](client-dom-renderer_lifecycle.md) |
| Lazy, inherited context-map initialization | `get_or_init_context_map`, `get_parent_context` (internal) | All context API functions |
| Deferred-effect flushing at component completion | `pop` → `create_user_effect` | [client-reactivity-engine_effects](client-reactivity-engine_effects.md) |
| Runes vs. legacy mode detection | `is_runes` | [client-reactivity-engine](client-reactivity-engine.md), [legacy-compat](legacy-compat.md) |
| Async-mode write validation | `setContext` guard | [client-reactivity-engine_deriveds-and-async](client-reactivity-engine_deriveds-and-async.md) consumers |
| Dev-mode error attribution & metadata | `add_svelte_meta`, `dev_stack`, `set_dev_stack`, `set_dev_current_component_function` | [client-dev-tooling](client-dev-tooling.md) (ownership validation, HMR, tracing) |

---

## Architecture

The module sits at the intersection of three layers of the client runtime:

1. **Public API layer** — the four context functions that user code and compiled output call during component initialization.
2. **Stack management layer** — `push`/`pop` maintain a linked list of `ComponentContext` frames; the *head* of the list (`component_context`) identifies the currently-initializing component.
3. **Diagnostics layer (dev only)** — `dev_stack` and `add_svelte_meta` record *where* (file/line/column) blocks and components were created, enabling high-quality error messages and ownership validation.

```mermaid
flowchart TB
    subgraph Public["Public Context API"]
        setContext["setContext(key, ctx)"]
        getContext["getContext(key)"]
        hasContext["hasContext(key)"]
        getAllContexts["getAllContexts()"]
    end

    subgraph Stack["Component Context Stack Management"]
        push["push(props, runes, fn)"]
        pop["pop(component)"]
        cc["component_context : ComponentContext | null"]
        setcc["set_component_context()"]
    end

    subgraph LazyInit["Lazy Map Initialization (internal)"]
        gocm["get_or_init_context_map(name)"]
        gpc["get_parent_context(ctx)"]
    end

    subgraph Dev["Dev-Mode Diagnostics"]
        asm["add_svelte_meta(callback, type, ...)"]
        ds["dev_stack : DevStackEntry | null"]
        dccf["dev_current_component_function"]
    end

    subgraph Deps["Runtime Dependencies"]
        RE["runtime.js<br/>(active_effect, active_reaction)"]
        EF["reactivity/effects.js<br/>(create_user_effect)"]
        FL["flags/index.js<br/>(async_mode_flag, legacy_mode_flag)"]
        ER["errors.js<br/>(lifecycle_outside_component,<br/>set_context_after_init)"]
        CO["constants.js<br/>(FILENAME, BRANCH_EFFECT, EFFECT_RAN)"]
    end

    setContext --> gocm
    getContext --> gocm
    hasContext --> gocm
    getAllContexts --> gocm
    gocm --> gpc
    gocm -- "no active component_context" --> ER
    setContext -- "async_mode_flag" --> RE
    setContext -- "invalid timing" --> ER

    push --> cc
    pop --> cc
    pop -- "flushes deferred effects" --> EF
    pop -- "DEV: restore" --> dccf
    push -- "DEV: set" --> dccf
    setcc --> cc

    asm -- "wraps callback with" --> ds
    push -- "DEV: reads" --> ds

    gocm --> cc
    cc --> gpc
```

### The `ComponentContext` Frame

Each entry on the stack is a lightweight record created by `push`:

| Field | Meaning |
|---|---|
| `p` | Link to the **parent** `ComponentContext` (forms the stack). |
| `c` | **Context map** (`Map<unknown, unknown>`); `null` until a context API function is first called (lazy). |
| `e` | **Deferred effects** — lifecycle callbacks collected during init, flushed by `pop`. |
| `s` | The component's **props** object. |
| `x` | **Exports** — populated by `pop(component)` with the component's exported values. |
| `l` | **Legacy record** (`{ s, u, $ }`) only when `legacy_mode_flag` is on and the component is not in runes mode; drives `beforeUpdate`/`afterUpdate` handling. |
| `function` | *(DEV only)* the component function, for error attribution. |

The context map itself is **copy-on-init**: the first time any context function is called for a component, a fresh `Map` is created seeded from the *closest ancestor that has a map*. Subsequent reads resolve against the local map and then implicitly against the snapshot inherited from ancestors.

---

## Component Reference

### Public Context API

#### `setContext(key, context) → T`

Associates `context` with `key` for the current component; children (including slotted content and snippets) can retrieve it with `getContext`. Returns the context for ergonomic chaining.

- Delegates to `get_or_init_context_map('setContext')`, which **throws `lifecycle_outside_component`** if no component is initializing.
- **Async-mode guard:** when `async_mode_flag` is active, writes are only permitted during the *initial* branch effect of a component — i.e., `active_reaction` must be null, the active effect must carry the `BRANCH_EFFECT` flag, and it must *not* yet have run (`EFFECT_RAN` unset). Any other timing throws `set_context_after_init`. This prevents context writes after a component's initialization has already raced ahead (important with partial/async hydration in async mode).

#### `getContext(key) → T`

Returns the value stored for `key` in the closest parent that set it (`undefined` if absent). Must be called during component initialization.

#### `hasContext(key) → boolean`

Checks whether `key` exists in the current inherited context. Cheaper and safer than `getContext(key) !== undefined` when `undefined` is a legitimate value.

#### `getAllContexts() → Map`

Returns the whole context map of the closest parent component. Intended for programmatic component creation where the existing context must be forwarded (e.g., mounting a child imperatively inside a library component).

### Stack Management

#### `push(props, runes = false, fn)`

Creates a new `ComponentContext` frame and makes it the current one. Called by compiler-generated code at the start of every component instantiation.

- Wires `p` to the previous head and `s` to the incoming props.
- Allocates the **legacy record** only when `legacy_mode_flag` is on *and* `runes` is false — this is exactly the condition later probed by `is_runes()`.
- *(DEV)* stores the component function on the frame and syncs `dev_current_component_function`.

#### `pop(component)`

Completes the component initialization and discards the frame.

1. **Flushes deferred effects:** if `context.e` is non-null, each collected callback is turned into a real user effect via `create_user_effect`. This is what makes lifecycle hooks registered *during init* (e.g., `onMount`-style `$effect` ordering guarantees) run only after the component tree beneath has finished constructing.
2. Attaches `component` (the exported values object) to `context.x`.
3. Pops the stack (`component_context = context.p`) and *(DEV)* restores `dev_current_component_function` from the parent frame.
4. Returns the exports (or a fresh `{}` when called without an argument).

#### `set_component_context(context)`

Low-level setter for the module-global head pointer. Used by the effect/branch machinery to save/restore context around teardowns where compiled code no longer brackets execution (branch destruction, `<svelte:boundary>` resets, HMR).

#### `is_runes() → boolean`

Reports whether the current component runs in **runes mode**: true when legacy mode is off globally, or when the current frame has no legacy record (`l === null`). The reactivity engine consults this to decide between signal-based and legacy invalidation semantics (see [client-reactivity-engine_signal-graph](client-reactivity-engine_signal-graph.md) and [legacy-compat](legacy-compat.md)).

### Dev-Mode Diagnostics

#### `add_svelte_meta(callback, type, component, line, column, additional?)`

Executes `callback` with a new `dev_stack` entry pushed on top of the current one. The entry records the block/component `type`, source position (`component[FILENAME]`, `line`, `column`), optional extra properties, and a `parent` link. The stack is restored in a `finally` block, making the wrapper exception-safe. Client transform visitors emit these calls so that dev-mode errors can point at the originating template location (consumed by [client-dev-tooling_state-inspection](client-dev-tooling_state-inspection.md) and ownership validation).

#### `dev_stack` / `set_dev_stack(stack)` and `dev_current_component_function` / `set_dev_current_component_function(fn)`

Mutable module state plus corresponding setters, mirroring `component_context`. The setters exist so non-component code paths (effect teardown, boundary resets) can bracket execution without a compiled `push`/`pop` pair.

---

## Process Flows

### Component Initialization (push / setContext / pop)

```mermaid
sequenceDiagram
    participant CC as Compiled Component Code
    participant CTX as context.js (this module)
    participant EFF as effects.js
    participant CH as Child Component

    CC->>CTX: push(props, runes, fn)
    Note over CTX: new ComponentContext { p: parent, c: null, e: null, s: props }
    CTX-->>CC: frame active (component_context = frame)

    CC->>CTX: setContext(key, value)
    CTX->>CTX: get_or_init_context_map()
    Note over CTX: lazy: new Map seeded from nearest<br/>ancestor with a context map
    CTX-->>CC: value

    CC->>CH: instantiate child
    Note over CH: child repeats push/setContext/getContext cycle
    CH->>CC: child exports (via child's pop)

    CC->>CTX: pop(exports)
    alt deferred effects exist (context.e)
        CTX->>EFF: create_user_effect(fn)  × n
        Note over EFF: effects scheduled in reactivity engine
    end
    CTX->>CTX: component_context = frame.p
    CTX-->>CC: exports
```

### `setContext` Timing Validation (async mode)

```mermaid
flowchart TD
    A["setContext(key, context) called"] --> B{"component_context<br/>=== null ?"}
    B -- "yes" --> E1["throw lifecycle_outside_component"]
    B -- "no" --> C{"async_mode_flag<br/>enabled ?"}
    C -- "no" --> OK["context_map.set(key, context)<br/>return context"]
    C -- "yes" --> D{"active_reaction<br/>=== null ?"}
    D -- "no" --> E2["throw set_context_after_init"]
    D -- "yes" --> F{"effect has<br/>BRANCH_EFFECT flag ?"}
    F -- "no" --> E2
    F -- "yes" --> G{"effect has<br/>EFFECT_RAN flag ?"}
    G -- "yes" --> E2
    G -- "no" --> OK
```

### Context Resolution (`get_parent_context`)

```mermaid
flowchart LR
    A["getContext/hasContext/<br/>getAllContexts/setContext"] --> B["get_or_init_context_map(name)"]
    B --> C{"component_context<br/>=== null ?"}
    C -- "yes" --> D["throw lifecycle_outside_component"]
    C -- "no" --> E{"frame.c already<br/>initialized ?"}
    E -- "yes" --> R["return frame.c"]
    E -- "no" --> F["walk parent chain (p → p → …)<br/>until first non-null c"]
    F --> G{"ancestor map found ?"}
    G -- "yes" --> H["frame.c = new Map(ancestorMap)"]
    G -- "no" --> I["frame.c = new Map()"]
    H --> R
    I --> R
```

---

## Dependency Graph

```mermaid
graph TD
    subgraph ThisModule["context-api_client-context"]
        A["client/context.js"]
    end

    subgraph Upstream["Depends On"]
        B1["internal/client/runtime.js<br/>active_effect · active_reaction"]
        B2["internal/client/reactivity/effects.js<br/>create_user_effect"]
        B3["internal/flags/index.js<br/>async_mode_flag · legacy_mode_flag"]
        B4["internal/client/errors.js<br/>error catalog"]
        B5["constants.js<br/>FILENAME · BRANCH_EFFECT · EFFECT_RAN"]
        B6["esm-env<br/>DEV"]
    end

    subgraph Downstream["Depended On By"]
        C1["Compiled client components<br/>(push · pop · context API)"]
        C2["public-api<br/>(setContext · getContext ·<br/>hasContext · getAllContexts re-exports)"]
        C3["client-reactivity-engine<br/>(component_context for signal ownership,<br/>is_runes for mode selection)"]
        C4["client-dom-renderer_lifecycle<br/>(mount/hydrate orchestration)"]
        C5["client-dev-tooling<br/>(dev_stack · ownership · HMR)"]
        C6["legacy-compat<br/>(legacy record · is_runes)"]
    end

    B1 --> A
    B2 --> A
    B3 --> A
    B4 --> A
    B5 --> A
    B6 --> A

    A --> C1
    A --> C2
    A --> C3
    A --> C4
    A --> C5
    A --> C6
```

---

## Client vs. Server Context

This module is one half of the cross-target context API. The server counterpart ([context-api_server-context](context-api_server-context.md)) exposes the *same public API* so that compiled source can be shared between targets, but the implementations diverge where the runtimes diverge:

| Aspect | Client (this module) | Server ([context-api_server-context](context-api_server-context.md)) |
|---|---|---|
| Frame holder | `component_context` (exported, restored via `set_component_context`) | `current_component` (module-local) |
| Lazy context map | ✔ (`get_or_init_context_map` + parent-chain inheritance) | ✔ (same lazy pattern) |
| Deferred effects (`e`) | ✔ flushed by `pop` → `create_user_effect` | ✖ not applicable |
| `onDestroy` handling | via effects / `public-api` | collected in frame `d`, queued to `on_destroy` by `pop` |
| Legacy record (`l`) | ✔ (legacy mode `{s, u, $}`) | ✖ |
| Async-mode write guard | ✔ (`BRANCH_EFFECT`/`EFFECT_RAN` checks) | ✖ (render is synchronous) |
| Dev stack metadata | ✔ (`add_svelte_meta`, `dev_stack`) | limited |

> ⚠️ Keep the two implementations **API-compatible** when making changes: compiler output calls `push`/`pop`/`setContext`/`getContext` identically on both targets, and the payload/render integration on the server is documented in [server-runtime_render-pipeline](server-runtime_render-pipeline.md).

---

## Edge Cases & Error Handling

- **Outside component initialization:** any context API call with a null `component_context` throws `lifecycle_outside_component`. This includes calls from `$effect`, event handlers, and module scope.
- **Late writes in async mode:** `setContext` after the component's branch effect has started running throws `set_context_after_init`, protecting against context values that mutate across async boundaries.
- **Context is snapshot-inherited:** a child's map is copied from the nearest ancestor map *at first access*. A parent calling `setContext` *after* the child already initialized (possible with out-of-order snippet rendering) is therefore invisible to the child — the copy-on-init semantics make each frame's map independent once created.
- **`getAllContexts` ownership:** the returned map is the live map of the current frame; mutating it affects the current component's context namespace (and future children), not ancestors'.
- **`pop` without exports:** when compiled code calls `pop()` with no argument (module-level scripts, non-component frames), an empty object is returned to keep the generated code shape uniform.
- **DEV-stack hygiene:** `add_svelte_meta` restores `dev_stack` in a `finally`, so errors thrown inside the callback still leave correct stack state; `block()` effects snapshot `dev_stack` at creation time for later attribution (see [client-reactivity-engine_effects](client-reactivity-engine_effects.md)).

---

## Related Documentation

- [context-api](context-api.md) — overview of the cross-target context subsystem
- [context-api_server-context](context-api_server-context.md) — SSR implementation of the same API
- [client-reactivity-engine](client-reactivity-engine.md) — signal graph that `component_context`/`is_runes` feed into
- [client-reactivity-engine_effects](client-reactivity-engine_effects.md) — `create_user_effect`, `block`, and dev-stack snapshots
- [client-reactivity-engine_deriveds-and-async](client-reactivity-engine_deriveds-and-async.md) — async mode motivating the `setContext` guard
- [client-dom-renderer_lifecycle](client-dom-renderer_lifecycle.md) — `mount`/`hydrate`/`unmount` entry points bracketing the stack
- [public-api](public-api.md) — user-facing re-exports of the context functions
- [client-dev-tooling](client-dev-tooling.md) — consumers of `dev_stack` and `add_svelte_meta`
- [legacy-compat](legacy-compat.md) — legacy record semantics on the context frame
