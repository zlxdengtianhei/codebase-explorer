# svelte-public-types

> **Module artifact:** `packages/svelte/types/index.d.ts`
> **Category:** Public API & Built-in Feature Surface
> **Nature:** Generated TypeScript declaration bundle (not hand-written source)

---

## 1. Introduction

`svelte-public-types` is the **single, generated TypeScript type bundle that defines the entire public type surface of the `svelte` npm package**. Its sole artifact — `packages/svelte/types/index.d.ts` — aggregates the type declarations of every public entry point (`svelte`, `svelte/compiler`, `svelte/store`, `svelte/motion`, `svelte/transition`, `svelte/reactivity`, …) into one ambient declaration file, and additionally installs the global rune declarations (`$state`, `$derived`, `$effect`, …) and the `declare module '*.svelte'` wildcard used by every Svelte + TypeScript project.

The bundle is **never edited by hand**. It is produced by `packages/svelte/scripts/generate-types.js`, which runs [`dts-buddy`](https://github.com/Rich-Harris/dts-buddy) over the per-module `public.d.ts` files maintained alongside each feature implementation. This guarantees that the published types can never drift from the runtime code they describe: a type is only public if a feature module explicitly exports it through its public entry file.

### Key characteristics

| Property | Value |
|---|---|
| Artifact | `packages/svelte/types/index.d.ts` |
| Generator | `packages/svelte/scripts/generate-types.js` (`dts-buddy` → `createBundle`) |
| Declares | 14 public subpath modules + 2 deprecated alias modules + rune globals + `*.svelte` wildcard |
| Internal stripping | `stripInternal: true` — all `@internal` JSDoc-tagged types are removed |
| Sibling type files (not part of bundle) | `packages/svelte/elements.d.ts`, `packages/svelte/svelte-html.d.ts` (DOM typings — see [svelte_dom_type_definitions](svelte_dom_type_definitions.md)) |
| Regeneration trigger | Any change to a `public.d.ts`, `src/index.d.ts`, `src/ambient.d.ts`, or generator script |

---

## 2. Architecture

### 2.1 Generation pipeline

The bundle sits at the end of a one-way pipeline: hand-maintained source declarations → bundler → generated artifact → resolution shims → consumers.

```mermaid
flowchart TB
    subgraph SRC["Hand-maintained type sources"]
        direction LR
        A["src/index.d.ts<br/>+ src/ambient.d.ts<br/>'svelte' + runes"]
        B["src/action/public.d.ts<br/>'svelte/action'"]
        C["src/animate/public.d.ts<br/>'svelte/animate'"]
        D["src/attachments/public.d.ts<br/>'svelte/attachments'"]
        E["src/compiler/public.d.ts<br/>'svelte/compiler'"]
        F["src/easing/index.js<br/>'svelte/easing'"]
        G["src/legacy/legacy-client.js<br/>'svelte/legacy'"]
        H["src/motion/public.d.ts<br/>'svelte/motion'"]
        I["src/reactivity/index-client.js<br/>'svelte/reactivity'"]
        J["src/reactivity/window/index.js<br/>'svelte/reactivity/window'"]
        K["src/server/index.d.ts<br/>'svelte/server'"]
        L["src/store/public.d.ts<br/>'svelte/store'"]
        M["src/transition/public.d.ts<br/>'svelte/transition'"]
        N["src/events/public.d.ts<br/>'svelte/events'"]
    end

    GEN["scripts/generate-types.js<br/>dts-buddy createBundle()<br/>stripInternal: true"]
    BUNDLE["packages/svelte/types/index.d.ts<br/>single ambient declaration bundle"]
    SHIMS["Resolution shims (generated)<br/>index.d.ts, compiler.d.ts, action.d.ts,<br/>animate.d.ts, easing.d.ts, motion.d.ts,<br/>store.d.ts, transition.d.ts, legacy.d.ts,<br/>types/compiler/preprocess.d.ts,<br/>types/compiler/interfaces.d.ts<br/>each: import './types/index.js'"]
    CONS["Consumers<br/>TS compiler, IDE / language-tools,<br/>component libraries, bundler plugins"]

    SRC --> GEN --> BUNDLE
    BUNDLE --> SHIMS --> CONS
```

### 2.2 Why a single bundle?

`generate-types.js` documents the rationale directly:

1. **`moduleResolution: bundler` compatibility.** Not all consumers use modern package `exports` resolution. The generated stub files (`action.d.ts`, `store.d.ts`, …) each contain only `import './types/index.js';` so TypeScript can resolve every subpath in every resolution mode. (The comments note this pattern may be removable in Svelte 6/7.)
2. **Type/runtime colocation without coupling.** Feature modules keep their types next to their code (`public.d.ts` files); the bundle merges them into the shape required by the package's `imports`/`exports` map.
3. **A single file to publish, tree-shake nothing, and lint everything.** The generator runs two hard validation gates on the output (see [§4](#4-generation-and-validation-process)).

### 2.3 Declared-module inventory

Each `declare module '…'` block in the bundle maps 1:1 to a package subpath and a source-of-truth file owned by a feature module. **This documentation does not re-describe those feature modules** — follow the links for behavior and runtime details.

| Declared module | Source of truth | Owning module (docs) | Notable types in bundle |
|---|---|---|---|
| `'svelte'` | `src/index.d.ts` (+ `src/ambient.d.ts` inlined) | [public-api](public-api.md) | `Component`, `SvelteComponent`, `SvelteComponentTyped`, `Snippet`, `EventDispatcher`, `ComponentProps`, `ComponentType`, `ComponentEvents`, `MountOptions`, lifecycle & mount functions |
| `'svelte/action'` | `src/action/public.d.ts` | [actions-attachments](actions-attachments.md) | `Action`, `ActionReturn` |
| `'svelte/attachments'` | `src/attachments/public.d.ts` | [actions-attachments](actions-attachments.md) | `Attachment`, `createAttachmentKey`, `fromAction` |
| `'svelte/animate'` | `src/animate/public.d.ts` | [transitions-animations-easing](transitions-animations-easing.md) | `AnimationConfig`, `FlipParams`, `flip` |
| `'svelte/transition'` | `src/transition/public.d.ts` | [transitions-animations-easing](transitions-animations-easing.md) | `TransitionConfig`, `BlurParams`, `FadeParams`, `FlyParams`, `ScaleParams`, `SlideParams`, `DrawParams`, `CrossfadeParams` |
| `'svelte/easing'` | `src/easing/index.js` | [transitions-animations-easing](transitions-animations-easing.md) | 31 easing functions (`linear`, `backIn`, `cubicOut`, …) |
| `'svelte/motion'` | `src/motion/public.d.ts` | [motion](motion.md) | `Spring`, `Tween` classes + legacy `spring`, `tweened`, `Tweened` |
| `'svelte/store'` | `src/store/public.d.ts` | [stores](stores.md) | `Readable`, `Writable`, `Subscriber`, `Unsubscriber`, `Updater`, `StartStopNotifier`, `toStore`, `fromStore` |
| `'svelte/reactivity'` | `src/reactivity/index-client.js` | [reactive-builtins](reactive-builtins.md) | `SvelteDate`, `SvelteSet`, `SvelteMap`, `SvelteURL`, `SvelteURLSearchParams`, `MediaQuery`, `createSubscriber` |
| `'svelte/reactivity/window'` | `src/reactivity/window/index.js` | [reactive-builtins](reactive-builtins.md) | `scrollX`, `scrollY`, `innerWidth`, `innerHeight`, `outerWidth`, `outerHeight`, `screenLeft`, `screenTop`, `online`, `devicePixelRatio` |
| `'svelte/server'` | `src/server/index.d.ts` | [server-runtime](server-runtime.md) | `render`, `RenderOutput` |
| `'svelte/events'` | `src/events/public.d.ts` | [public-api](public-api.md) (client events) | strongly-typed `on()` overloads |
| `'svelte/legacy'` | `src/legacy/legacy-client.js` | [legacy-compat](legacy-compat.md) | `createClassComponent`, `asClassComponent`, `run`, `handlers`, `createBubbler`, modifier shims, `LegacyComponentType` |
| `'svelte/compiler'` | `src/compiler/public.d.ts` | [compiler-core_public_api](compiler-core_public_api.md), [compiler-core_type_definitions](compiler-core_type_definitions.md), [compiler-preprocessor_api](compiler-preprocessor_api.md) | `compile`, `compileModule`, `parse`, `preprocess`, `migrate`, `VERSION`, `CompileOptions_1`, `ModuleCompileOptions`, `CompileResult`, `Warning`, `CompileError`, `Processed`, `PreprocessorGroup`, `AST` namespace (incl. `_CSS`) |
| `'svelte/types/compiler/preprocess'` *(deprecated)* | `src/compiler/preprocess/legacy-public.d.ts` | [compiler-preprocessor_api](compiler-preprocessor_api.md) | `Processed_1`, `MarkupPreprocessor_1`, `Preprocessor_1`, `PreprocessorGroup_1`, `SveltePreprocessor_1` |
| `'svelte/types/compiler/interfaces'` *(deprecated)* | `src/compiler/types/legacy-interfaces.d.ts` | [compiler-core_public_api](compiler-core_public_api.md) | `CompileOptions_1`, `Warning_1`, `Namespace`, `ICompileDiagnostic` |
| *ambient globals* | `src/ambient.d.ts` | [public-api](public-api.md) (runes) | `$state`, `$derived`, `$effect`, `$props`, `$bindable`, `$inspect`, `$host`, `declare module '*.svelte'` |

> **Naming note — the `_1` suffix.** `dts-buddy` merges all declarations into one file, so same-named types from different declared modules must be disambiguated. The deprecated compatibility modules re-declare names that already exist in the modern modules, and the bundler renames the colliding duplicates with `_1`: `CompileOptions_1`, `Processed_1`, `Preprocessor_1`, `SveltePreprocessor_1`. These are the exact symbols listed for this module in the system module tree. They exist only so tooling built on the old `svelte/types/compiler/*` import paths keeps working across Svelte 4–6; they are scheduled for removal.

---

## 3. What lives in the bundle

### 3.1 Component model (`'svelte'`)

The heart of the bundle is the dual component typing that spans Svelte 4 and Svelte 5:

```mermaid
classDiagram
    class Component {
        <<interface · Svelte 5>>
        +call(internals, props) Exports_and_legacy_shims
        +element? typeof HTMLElement
        +z_$$bindings? Bindings
    }
    class ComponentInternals {
        <<branded type>>
    }
    class SvelteComponent {
        <<class · Svelte 4 legacy>>
        +$$prop_def Props
        +$$events_def Events
        +$$slot_def Slots
        +$destroy()$
        +$on(type, cb)$
        +$set(props)$
    }
    class SvelteComponentTyped {
        <<deprecated alias>>
    }
    class Snippet {
        <<interface>>
        +call(...Parameters) SnippetReturn_brand
    }
    class EventDispatcher~EventMap~ {
        +dispatch(type, parameter?, options?) boolean
    }
    class MountOptions~Props~ {
        +target
        +anchor?
        +props
        +context?
        +intro?
    }
    class ComponentProps {
        <<utility type>>
    }
    Component --> ComponentInternals : receives
    SvelteComponentTyped --|> SvelteComponent : extends
    ComponentProps ..> Component : infers Props from
    ComponentProps ..> SvelteComponent : infers Props from
    MountOptions ..> ComponentProps : props option required when non-empty
    Component ..> Snippet : props may contain
```

Key design points encoded purely at the type level:

- **`Component` is a callable interface**, mirroring Svelte 5's function components: `(internals, props) => exports`. `ComponentInternals` is a *branded* type (`Branded<{}, 'ComponentInternals'>`), so user code can never construct it.
- **`Snippet` uses a branded return type** (`typeof SnippetReturn`) so that calling a snippet anywhere except `{@render ...}` produces a self-explanatory type error.
- **`SvelteComponentTyped`, `ComponentEvents`, `ComponentType`, `$on`/`$set`/`$destroy`** are all `@deprecated` shims for Svelte 4 class-style components, kept so legacy code and the [legacy-compat](legacy-compat.md) shims type-check.
- **`MountOptions`/`hydrate` options use a conditional `{} extends Props` check**: props become *required* only when the component declares any.
- Functions like `mount`, `hydrate`, `unmount`, `tick`, `settled`, `flushSync`, `untrack`, `onMount`, `onDestroy`, `beforeUpdate`, `afterUpdate`, `createEventDispatcher`, `createRawSnippet`, and the context API (`setContext`/`getContext`/`hasContext`/`getAllContexts`) are declared here as *signatures only* — their runtime behavior lives in the client runtime (see [client-reactivity-engine](client-reactivity-engine.md)) and server runtime (see [server-runtime](server-runtime.md)).

### 3.2 Compiler surface (`'svelte/compiler'`)

The largest declared module. It re-exposes, as ambient declarations:

- **API functions:** `compile`, `compileModule`, `parse` (overloads for `modern: true/false`), `preprocess`, `migrate`, a deprecated `walk` stub, and `VERSION`.
- **Options:** `CompileOptions_1 extends ModuleCompileOptions` — every documented compiler flag (`runes`, `generate`, `customElement`, `css`, `fragments`, `hmr`, `modernAst`, …). These options are consumed and validated by the compiler at runtime — see [compiler-core_options_validation](compiler-core_options_validation.md).
- **Results & diagnostics:** `CompileResult` (js/css outputs, `warnings`, `metadata.runes`, `ast`), `Warning`, `CompileError` — all diagnostics share the `ICompileDiagnostic` shape (`code`, `message`, `start`, `end`, `position`, `frame`) produced by the compiler's diagnostic system ([compiler-core_diagnostics](compiler-core_diagnostics.md)).
- **`AST` namespace:** the full template AST node hierarchy — `Root`, `Fragment`, all `*Element`/`*Directive`/`*Tag`/`*Block` nodes (sourced from `src/compiler/types/template.d.ts`) — plus the `_CSS` namespace exposing the CSS AST (`StyleSheet`, `Rule`, `SelectorList`, `ComplexSelector`, `RelativeSelector`, every `SimpleSelector` variant, `Declaration`, …) from `src/compiler/types/css.d.ts`.

The AST types declared here are the *contract* between the parser, analyzer, and transformer phases described in [Compiler_Pipeline___Language_Toolchain](Compiler_Pipeline___Language_Toolchain.md) — refer there for how these nodes are produced and consumed; this module only freezes their public shape.

### 3.3 Feature-module surfaces

Each remaining declared module is a thin, typed façade over a runtime module. The bundle declares signatures and parametric types; behavior is documented by the owning module:

- **Stores** ([stores](stores.md)): `Readable`/`Writable` contract, `derived`, `get`, `readonly`, `writable`, `readable` signatures plus the runes bridge `fromStore`/`toStore`.
- **Motion** ([motion](motion.md): `Spring`/`Tween` classes (with `Spring.of`/`Tween.of` static constructors) and the deprecated `spring()`/`tweened()` stores. Note the deliberate *declaration merging*: `interface Spring` (legacy store shape) and `class Spring` (Svelte 5) are merged in one name.
- **Reactive built-ins** ([reactive-builtins](reactive-builtins.md)): `SvelteMap`, `SvelteSet`, `SvelteDate`, `SvelteURL`, `SvelteURLSearchParams` (each carrying `#private` fields and, for `SvelteURLSearchParams`, the internal `[REPLACE]` method), `MediaQuery extends ReactiveValue<boolean>`, `createSubscriber`, and the `svelte/reactivity/window` value set.
- **Transitions/animations/easing** ([transitions-animations-easing](transitions-animations-easing.md)): every transition function and its params interface, `crossfade`'s paired send/receive signature, `flip`, and the easing function family.
- **Server** ([server-runtime](server-runtime.md)): the `render()` overload signature (conditional on whether `Props` is empty) returning `RenderOutput { head, html?, body }`. `RenderOutput` mirrors the internal `RenderOutput` type in `src/internal/server/types.d.ts` ([server-runtime_payload-and-output](server-runtime_payload-and-output.md)).
- **Events:** five `on()` overloads (`Window`, `Document`, `HTMLElement`, `MediaQueryList`, generic `EventTarget`), each returning an unsubscriber, typed to preserve delegated-handler ordering guarantees.
- **Legacy** ([legacy-compat](legacy-compat.md)): `createClassComponent`/`asClassComponent`, `run`, `handlers`, `createBubbler`, `LegacyComponentType`, and per-modifier wrapper functions — all `@deprecated`.
- **Actions & attachments** ([actions-attachments](actions-attachments.md)): `Action<Element, Parameter, Attributes>` and `ActionReturn`, plus the newer `Attachment<T>`, `createAttachmentKey`, and the two `fromAction` overloads.

### 3.4 Ambient globals (runes + `*.svelte`)

The tail of the bundle (originating in `src/ambient.d.ts`, pulled in because `src/index.d.ts` does `import './ambient.js'`) declares:

- **The seven runes** as global functions with companion namespaces: `$state` (incl. `$state.raw`, `$state.snapshot` and the `Snapshot<T>`/`Cloneable` machinery), `$derived` (incl. `$derived.by`), `$effect` (incl. `pre`, `pending`, `tracking`, `root`), `$props` (incl. `$props.id`), `$bindable`, `$inspect` (incl. `$inspect.trace`), and `$host`.
- **Intelliisense hardening:** each rune namespace deliberately re-declares `Function.prototype` members (`apply`, `call`, `bind`, `name`, …) as `never`/`@deprecated` so editors do not offer nonsensical completions on runes.
- **`declare module '*.svelte'`:** types every `.svelte` import as both `SvelteComponent` (type position) and `LegacyComponentType` (value position), which is what lets the same import work in Svelte 4- and Svelte 5-style code.

### 3.5 Relation to the DOM typings

The bundle intentionally **excludes** HTML/SVG element and attribute typings. Those live in the separate, hand-maintained `packages/svelte/elements.d.ts` (`SvelteHTMLElements`, `AriaAttributes`, `DOMAttributes`, …) and `svelte-html.d.ts` (the language-server-only `svelteHTML` global namespace). See [svelte_dom_type_definitions](svelte_dom_type_definitions.md).

---

## 4. Generation and validation process

`scripts/generate-types.js` runs as part of the package build. Its execution is a strict, gated pipeline:

```mermaid
flowchart TD
    START(["Run generate-types.js"]) --> PKG["Read package.json<br/>collect pkg.imports → TS paths mapping"]
    PKG --> SHIM["Write resolution shims<br/>action/animate/easing/motion/store/<br/>transition/legacy/index/compiler .d.ts<br/>+ deprecated types/compiler/*.d.ts<br/>each containing: import './types/index.js'"]
    SHIM --> BUNDLE["dts-buddy createBundle<br/>modules map: 16 entry points → output<br/>compilerOptions.stripInternal = true"]
    BUNDLE --> APPEND["Ambient declarations from<br/>src/ambient.d.ts land in output<br/>runes + '*.svelte' module"]
    APPEND --> CHECK1{"Gate 1:<br/>all JSDoc links absolute?<br/>must start with https://svelte.dev"}
    CHECK1 -- "relative /rooted link found" --> FAIL1["Log offending links<br/>exit 1"]
    CHECK1 -- pass --> CHECK2{"Gate 2:<br/>no 'export { ... }' statements?"}
    CHECK2 -- "re-export found" --> FAIL2["Explain: re-exports break<br/>downstream d.ts generation via<br/>@sveltejs/package — exit 1"]
    CHECK2 -- pass --> DONE(["types/index.d.ts ready"])

    style FAIL1 fill:#fdd,stroke:#c00
    style FAIL2 fill:#fdd,stroke:#c00
```

**Gate details (why they matter for maintainers):**

1. **Absolute documentation links.** JSDoc comments are copied verbatim into the bundle and surface in editor hovers worldwide; a root-relative link like `(/docs/foo)` would 404. All links must be prefixed with `https://svelte.dev`.
2. **No `export { … }` statements.** TypeScript's d.ts generation (used by `@sveltejs/package` for downstream libraries) is unreliable when following re-export statements. The rule enforced on Svelte itself — `export interface Foo {}` inline, never `interface Foo {}` + `export { Foo }` — propagates to every contributor via this gate.
3. **`stripInternal: true`.** Anything tagged `@internal` (and types only reachable through it) is dropped, which is why runtime-only helpers such as `RenderOutput`'s internal dependencies or compiler `Binding` types do not leak into public types.

**Adding a new public subpath** requires touching exactly three places, in this order:

1. The feature module's source (e.g. a new `public.d.ts`);
2. `package.json` — `exports`, `imports`, and (for TS path mapping) the import map consumed by the generator;
3. `scripts/generate-types.js` — add the module to the `modules` map (and, if it is not resolvable via `exports` alone, to the shim-writing list).

---

## 5. Module relationships and dependencies

`svelte-public-types` is a *dependent* of every feature module and a *dependency* of every consumer. The graph below shows the compile-time type dependencies (dashed = "declares types for"):

```mermaid
flowchart LR
    PT["svelte-public-types<br/>types/index.d.ts"]

    subgraph FEATURES["Feature modules (own the source types)"]
        PA["public-api"]
        ST["stores"]
        MO["motion"]
        TAE["transitions-animations-easing"]
        RB["reactive-builtins"]
        AA["actions-attachments"]
        LG["legacy-compat"]
        CCPA["compiler-core_public_api"]
        CCTD["compiler-core_type_definitions"]
        CPA["compiler-preprocessor_api"]
        SR["server-runtime"]
    end

    DOM["svelte_dom_type_definitions<br/>elements.d.ts / svelte-html.d.ts<br/>(separate artifact)"]
    CRE["client-reactivity-engine"]
    CDR["client-dom-renderer"]

    PA -->|src/index.d.ts, ambient.d.ts| PT
    ST -->|store/public.d.ts| PT
    MO -->|motion/public.d.ts| PT
    TAE -->|animate, transition, easing| PT
    RB -->|reactivity/index-client.js| PT
    AA -->|action, attachments public.d.ts| PT
    LG -->|legacy-client.js| PT
    CCPA -->|compiler/types/index.d.ts| PT
    CCTD -->|template.d.ts, css.d.ts, legacy-nodes.d.ts| PT
    CPA -->|preprocess/public.d.ts| PT
    SR -->|server/index.d.ts, internal RenderOutput| PT

    PT -.->|types every .svelte import| DOM
    CRE -.->|runtime for mount/tick/settled| PT
    CDR -.->|runtime for transitions, events, bindings| PT
```

Reading the dashed edges: the bundle knows nothing about the runtimes — it only asserts the contracts the runtimes implement. Conversely, the runtime modules never import the bundle; the correspondence is enforced by Svelte's own test-suite compilations against these types.

**Typical consumer flows through the bundle:**

```mermaid
sequenceDiagram
    participant App as Application / Library TS
    participant TS as TypeScript compiler
    participant Exports as package exports map
    participant Shims as generated shim d.ts
    participant Bundle as types/index.d.ts

    App->>TS: import { mount } from 'svelte'<br/>import type { Component } from 'svelte'
    TS->>Exports: resolve 'svelte' types condition
    Exports->>Shims: packages/svelte/index.d.ts
    Shims->>Bundle: import './types/index.js'
    Bundle-->>TS: declare module 'svelte' { mount(), interface Component }
    TS->>TS: check against declared module '*.svelte'<br/>(App.svelte default export = SvelteComponent / LegacyComponentType)
    TS-->>App: typed mount(App, { target, props })
```

---

## 6. Maintenance guide

### Do

- **Edit the sources, never the bundle.** Change behavior/types in the owning `public.d.ts` (or `src/index.d.ts`/`src/ambient.d.ts`), then regenerate.
- **Treat JSDoc as public API.** Every comment in the source files ships verbatim in the bundle and appears in user hovers. Keep examples compilable and links absolute (`https://svelte.dev/...`).
- **Export interfaces/types inline** (`export interface Foo {}`) — the `export {}` gate will reject anything else.
- **Mark anything not meant for consumption as `@internal`** — `stripInternal` will keep it out of the published surface.
- **Run the generator after merging type changes**; the checked-in `types/index.d.ts` must always equal the regenerated output.

### Don't

- **Don't add runtime code** to `public.d.ts` files — they are declarations only (the runtime implementations live in the sibling `.js` entry points described by [public-api](public-api.md), [stores](stores.md), etc.).
- **Don't introduce a second name for an existing public type** across declared modules without expecting an `_N` suffix — check the bundle output before picking names for deprecated aliases.
- **Don't extend the deprecated modules** (`svelte/types/compiler/preprocess`, `svelte/types/compiler/interfaces`) — they are frozen compatibility shims slated for removal.
- **Don't hand-edit generated shims** (`index.d.ts`, `compiler.d.ts`, `action.d.ts`, … at the package root) — they are overwritten on every build.

---

## 7. Related documentation

- [public-api](public-api.md) — the runtime entry points (`svelte`, `svelte/mount`, lifecycle functions) whose signatures this bundle declares.
- [stores](stores.md) · [motion](motion.md) · [transitions-animations-easing](transitions-animations-easing.md) · [reactive-builtins](reactive-builtins.md) · [actions-attachments](actions-attachments.md) — feature modules owning the per-subpath `public.d.ts` sources.
- [svelte_dom_type_definitions](svelte_dom_type_definitions.md) — the separate hand-maintained DOM element/attribute typings (`elements.d.ts`, `svelte-html.d.ts`).
- [compiler-core_public_api](compiler-core_public_api.md) · [compiler-core_type_definitions](compiler-core_type_definitions.md) · [compiler-preprocessor_api](compiler-preprocessor_api.md) — sources of the `'svelte/compiler'` declared module; see [Compiler_Pipeline___Language_Toolchain](Compiler_Pipeline___Language_Toolchain.md) for the compiler that implements these types.
- [server-runtime](server-runtime.md) / [server-runtime_payload-and-output](server-runtime_payload-and-output.md) — implements the `render()` / `RenderOutput` contract declared in `'svelte/server'`.
- [legacy-compat](legacy-compat.md) / [legacy-compat_component-api-shims](legacy-compat_component-api-shims.md) — runtime shims matching the `'svelte/legacy'` declarations and the deprecated `SvelteComponent` class typing.
- [client-reactivity-engine](client-reactivity-engine.md) · [client-dom-renderer](client-dom-renderer.md) — runtimes behind `mount`/`tick`/`settled`, transitions, events and bindings.
