# Structural Visitors — Client Transform

> **Module**: `compiler-transformer_client-transform_structural-visitors`
> **Location**: `packages/svelte/src/compiler/phases/3-transform/client/visitors/` (structural group)
> **Parent**: [Client Transform](compiler-transformer_client-transform.md) · [Transformer](compiler-transformer.md)

---

## 1. Overview

The **structural visitors** form the group of client-transform visitors responsible for translating the *structural* nodes of the analyzed Svelte AST — fragments, elements, components, snippets, and control-flow blocks — into JavaScript that **imperatively constructs and updates the DOM** using the Svelte client runtime (`$` internal module).

While the sibling groups handle orthogonal concerns:

- [Expression Visitors](compiler-transformer_client-transform_expression-visitors.md) — reactive JavaScript expressions (identifiers, assignments, calls)
- [Directive Visitors](compiler-transformer_client-transform_directive-visitors.md) — `bind:`, `on:`, `transition:`, `use:`, `let:` attributes
- [Infrastructure](compiler-transformer_client-transform_infrastructure.md) — the `visit` walker, `Template` builder, shared function handling

…the structural visitors decide **what kind of runtime construct** each piece of markup becomes: a hoisted cloneable template, a control-flow block (`$.if`, `$.each`, `$.await`), a dynamic element factory, a component mount, or a snippet call. They own the "shape" of the generated component's render code.

### Visitor inventory

| Visitor file | AST node | Responsibility |
|---|---|---|
| `Fragment.js` | `AST.Fragment` | Root/body container; template hoisting, node trimming, `$.append` |
| `RegularElement.js` | `AST.RegularElement` | Static/dynamic HTML/SVG/MathML elements; attributes, scoped CSS, special inputs |
| `SvelteElement.js` | `AST.SvelteElement` | `<svelte:element {tag}>` — runtime-dynamic element types |
| `Component.js` | `AST.Component` | Component instantiation (delegates to `build_component`) |
| `SnippetBlock.js` | `AST.SnippetBlock` | `{#snippet}` → reusable render functions; hoisting to module/instance scope |
| `RenderTag.js` | `AST.RenderTag` | `{@render foo(args)}` — static & dynamic snippet invocation |
| `IfBlock.js` | `AST.IfBlock` | `{#if}/{:else if}/{:else}` → `$.if` blocks |
| `EachBlock.js` | `AST.EachBlock` | `{#each}` → `$.each` keyed/non-keyed list rendering |
| `KeyBlock.js` | `AST.KeyBlock` | `{#key}` → `$.key` destroy/recreate blocks |
| `AwaitBlock.js` | `AST.AwaitBlock` | `{#await}` → `$.await` pending/then/catch blocks |
| `HtmlTag.js` | `AST.HtmlTag` | `{@html}` → `$.html` raw insertion |
| `SlotElement.js` | `AST.SlotElement` | `<slot>` → `$.slot` with slot props + fallback |
| `SvelteBoundary.js` | `AST.SvelteBoundary` | `<svelte:boundary>` → `$.boundary` error boundary |

---

## 2. Position in the Compiler Pipeline

Structural visitors run in **phase 3** of the compilation pipeline, consuming output of phase 2. See [Analyzer](compiler-analyzer.md) and [Parser](compiler-parser.md) for upstream details.

```mermaid
flowchart LR
    subgraph P1["Phase 1 — Parse"]
        A[Svelte source] --> B[AST + CSS AST]
    end
    subgraph P2["Phase 2 — Analyze<br/>(see analyzer module)"]
        B --> C["Annotated AST<br/>metadata: has_state, has_await,<br/>has_call, dynamic, scoped, is_controlled…"]
    end
    subgraph P3["Phase 3 — Transform"]
        C --> D{Transform target}
        D -->|client| E["client/visitors<br/>■ structural (this module)<br/>□ expressions<br/>□ directives"]
        D -->|server| F[server/visitors]
        D -->|css| G[css/index.js]
        E --> H[estree JS → render JS]
        F --> I[SSR string JS]
        G --> J[scoped CSS]
    end
    H --> K[CompileResult.js / .js.map]
    I --> K
```

The structural visitors only run for the **client** target (`compile(source, { target: 'client' })`, the default). The server-side counterparts of these same nodes live in the transformer module's server-transform group ([Server Transform](compiler-transformer_server-transform.md)); the two must stay semantically aligned because hydration expects client DOM to match SSR output.

---

## 3. Architecture

### 3.1 Component relationships

All visitors are pure functions `(node, context) => Statement | BlockStatement | void` invoked by the shared `visit` walker ([Infrastructure](compiler-transformer_client-transform_infrastructure.md)). They cooperate through **shared helpers** and **state threading**, and they emit calls into the **client runtime**:

```mermaid
flowchart TB
    subgraph INFRA["Infrastructure (client/utils.js)"]
        VISIT["visit walker<br/>dispatches by node.type"]
    end

    subgraph STRUCT["Structural visitors (this module)"]
        FRAG["Fragment"]
        RE["RegularElement"]
        SE["SvelteElement"]
        COMP["Component"]
        SNIP["SnippetBlock"]
        RT["RenderTag"]
        IF["IfBlock"]
        EACH["EachBlock"]
        KEY["KeyBlock"]
        AW["AwaitBlock"]
        HT["HtmlTag"]
        SLOT["SlotElement"]
        BND["SvelteBoundary"]
    end

    subgraph SHARED["Shared helpers (visitors/shared/)"]
        PC["process_children"]
        BC["build_component"]
        BU["build_expression · Memoizer<br/>build_render_statement · add_svelte_meta"]
        EL["build_attribute_value<br/>build_attribute_effect · build_set_class/style"]
        DEC["get_value"]
        CC["clean_nodes · infer_namespace<br/>(3-transform/utils.js)"]
    end

    subgraph CORE["Compiler core"]
        B["builders (b.*)<br/>(see AST builders module)"]
        SCOPE["Scope / Binding<br/>(see scope module)"]
    end

    subgraph RUNTIME["Client runtime ($ namespace)<br/>(see Client Runtime Engine)"]
        TPL["$.from_html · $.append · $.child<br/>$.first_child · $.sibling · $.next"]
        BLOCKS["$.if · $.each · $.key · $.await<br/>$.async · $.async_body · $.get"]
        REACT["$.template_effect · $.derived<br/>$.derived_safe_equal · $.untrack"]
        DOM["$.set_text · $.set_attribute<br/>$.set_value · $.init_select …"]
        META["$.component · $.snippet · $.slot<br/>$.boundary · $.element · $.html"]
    end

    VISIT --> STRUCT
    FRAG --> PC & CC & BU
    RE --> PC & EL & BU & CC
    SE --> EL & BU & CC
    COMP --> BC
    SNIP --> DEC
    EACH --> DEC & BU
    IF --> BU
    AW --> DEC & BU
    KEY & HT & RT --> BU
    SLOT --> EL & BU & DEC
    BND --> B
    SHARED --> B & SCOPE & RUNTIME
    STRUCT --> RUNTIME
```

### 3.2 The `context` / state contract

Every visitor receives a `ComponentContext` (see `3-transform/types.d.ts` → [Shared Infrastructure](compiler-transformer_shared-infrastructure.md)) whose `state` is a `ComponentClientTransformState` — a **mutable accumulator** that flows down the tree:

| Field | Purpose |
|---|---|
| `state.template` | `Template` builder — collects *static* markup (`push_element`, `push_comment`, `push_text`, `set_prop`, `pop_element`) for hoisted cloning |
| `state.init` | Statements run once at block setup (create nodes, mount blocks, one-time attribute sets) |
| `state.update` | Statements inside the block's `$.template_effect(...)` render effect (reactive attribute/text updates) |
| `state.after_update` | Statements run after the render effect (event listener setup, transitions, replay) |
| `state.node` | Expression pointing at the current anchor/DOM node (`$$anchor`, element id, …) |
| `state.transform` | Per-binding `read`/`assign`/`mutate` hooks (see [Expression Visitors](compiler-transformer_client-transform_expression-visitors.md)) |
| `state.memoizer` | `Memoizer` — deduplicates stateful expressions into `$.derived` declarations |
| `state.metadata` | `{ namespace, bound_contenteditable, … }` inherited down the tree |
| `state.scopes` / `scope` | From the [analyzer's scope module](compiler-analyzer_scope.md); used to look up `Binding`s and generate unique names |

Visitors that create a **new scope boundary** (Fragment, RegularElement children, each-item, snippet params, await then/catch) clone the state (`{ ...context.state, transform: {...} }`) so binding transforms do not leak across boundaries.

---

## 4. Core Concepts & Cross-Cutting Patterns

### 4.1 Static template vs. imperative code

The central design decision of the client transform: **static markup is hoisted into template literals** and cloned cheaply at mount; only *dynamic* parts become imperative statements.

```mermaid
flowchart LR
    subgraph Source["&lt;div class=static&gt;Hello {name}&lt;/div&gt;"]
        S1[Static element shell] --> S2[Dynamic expression]
    end
    subgraph Hoisted["Module-hoisted (state.hoisted)"]
        H1["const root = $.from_html('&lt;div class=static&gt;Hello &lt;!&gt;&lt;/div&gt;')"]
    end
    subgraph Init["state.init (runs once)"]
        I1["const div = root()"]
        I2["const text = $.text()"]
        I3["$.append($$anchor, div)"]
    end
    subgraph Update["state.update → $.template_effect"]
        U1["$.set_text(text, name)"]
    end
    S1 -- Template builder --> H1
    S2 -- process_children --> I2 & U1
    H1 --> I1
```

- **`clean_nodes`** (`3-transform/utils.js`) normalizes a node list before templating: it hoists `ConstTag`/`DebugTag`/`SnippetBlock`/`Svelte{Head,Body,Window,Document}`/`TitleElement`, trims whitespace (preserving `pre`/`textarea`/SVG `text` semantics), and computes `is_standalone` / `is_text_first` optimizations.
- **`process_children`** (shared) walks a trimmed child list, fusing adjacent `Text`/`ExpressionTag` runs into a single `$.set_text` target, inserting anchor `<!>` comments, and computing `$.sibling` hops for hydration.

### 4.2 Anchor comments

Every control-flow construct pushes a **comment anchor** (`state.template.push_comment()`) into the template. At runtime the anchor becomes a `<!>` node that the runtime block (`$.if`, `$.each`, …) uses as its insertion point. `Fragment` compensates for a leading text node (`is_text_first`) by emitting `$.next` so hydration does not fuse the anchor with adjacent text.

### 4.3 Memoization and render effects

- `Memoizer` (shared/utils.js) rewrites *stateful or calling* expressions into cached identifiers: sync values become `let $n = $.derived(...)` (runes) or `$.derived_safe_equal(...)` (legacy); awaited values become async inputs.
- `build_render_statement` closes the block's `update` list into `$.template_effect(() => {...}, sync_values, async_values)` — the unit of client-side reactivity for DOM attributes/text.

### 4.4 Experimental async support

When analysis marks an expression `has_await` (Svelte's experimental async components), structural visitors generate a **two-layer construct**:

1. the *sync* path reads a locally-bound value via `$.get($$placeholder)`;
2. the whole block is wrapped in `$.async(anchor, [thunk…], ($$anchor, $$placeholder) => {...})` (or `$.async_body` inside `Fragment`), guarded by `$.aborted` checks.

This pattern appears in `Fragment`, `IfBlock`, `EachBlock`, `KeyBlock`, `AwaitBlock`, `HtmlTag`, `RenderTag`, `SlotElement`, and `SvelteElement`.

### 4.5 Dev-mode instrumentation

Under `dev` (see [Compiler Core / compile state](compiler-core_compile_state.md)):
- `add_svelte_meta(...)` wraps block creations (`if`, `each`, `component`, `render`, …) with source locations for tooling;
- validation calls are emitted: `$.validate_each_keys` (EachBlock), `$.validate_snippet_args` (SnippetBlock), `$.validate_dynamic_element_tag` / `$.validate_void_dynamic_element` (SvelteElement);
- snippets become real functions wrapped in `$.wrap_snippet` (enables stack traces & argument checking).

### 4.6 Hydration contract

Several visitors emit hydration-specific logic: `is_ignored(node, 'hydration_html_changed')` flags (HtmlTag, RegularElement attributes), `$.hydrate_template`/`$.reset` for `<template>` and inner-hydration scoping (RegularElement), `$.next(skipped)` traversal in `process_children`, and `$.replay_events` for `onload`/`onerror` on media elements.

---

## 5. Visitor Deep Dives

### 5.1 `Fragment` — the body compiler

Every block body and the component root is an `AST.Fragment`. The visitor:

1. Infers the namespace (`html`/`svg`/`mathml`) from parent + content (`infer_namespace`).
2. Runs `clean_nodes` → `hoisted` + `trimmed` lists.
3. Chooses one of several **shape strategies**:

| Condition | Generated shape |
|---|---|
| empty | `b.block([])` — nothing emitted |
| single `RegularElement` | template + `const el = root(); …; $.append($$anchor, el)` |
| single `SvelteFragment`/`TitleElement` | no template — child visits directly into parent anchor |
| single `Text` | `$.text(literal)` + append |
| text/expression mix only | shared `$.text()` node (spaces preserved between expressions) |
| standalone (single non-dynamic render/component) | renders directly into `$$anchor`, no wrapper |
| general | template + `const fragment = root()` + `$.first_child` positioning + append |

4. Assembles the block: `consts → ($.aborted guard) → ($.next) → init → $.template_effect render → after_update → append(close)`.
5. Wraps in `$.async_body` when the fragment can suspend (`has_await`).

The hoisted template (`root = $.from_html(...)` / `$.from_svg` / `$.from_mathml` via `transform_template` + `Template.stringify`) is pushed to `state.hoisted` and lands at module scope of the output.

### 5.2 `RegularElement` — the workhorse

The largest visitor. Processing stages:

```mermaid
flowchart TD
    A["push_element(name)"] --> B{"noscript?"}
    B -->|yes| Z1["pop_element · done"]
    B -->|no| C["Set template flags:<br/>needs_import_node (custom el / video)<br/>contains_script_tag (script)"]
    C --> D["Partition attributes:<br/>attributes · class_directives · style_directives<br/>other_directives (on/bind/use/transition/animate/@attach) · lets"]
    D --> E["Visit lets first (scope setup)<br/>then other_directives → element_state"]
    E --> F{"input / textarea / select?"}
    F -->|value/checked/spread| G["$.remove_input_defaults /<br/>$.remove_textarea_child / select sync"]
    G --> H{"has_spread?"}
    H -->|yes| I["build_attribute_effect<br/>(single reactive $.spread_attributes effect)"]
    H -->|no| J["Per attribute:<br/>static → template.set_prop<br/>event → visit_event_attribute<br/>class/style → build_set_class/style<br/>custom element → $.set_custom_element_data<br/>dynamic → build_element_attribute_update"]
    I & J --> K["load/error elements → $.replay_events"]
    K --> L["clean_nodes children → hoisted + trimmed"]
    L --> M{"all-static expressions<br/>only?"}
    M -->|yes| N["textContent assignment"]
    M -->|no| O["process_children<br/>(template element → $.hydrate_template + content)"]
    N & O --> P["Merge child_state into<br/>init/update/after_update"]
    P --> Q{"dir attribute?"}
    Q -->|yes| R["self-assign dir fix (Chromium)"]
    R --> S{"select/option/input<br/>value binding?"}
    S -->|yes| T["build_element_special_value_attribute<br/>($$__value + $.select_option / $.init_select)"]
    T --> U["pop_element"]
```

Notable behaviors:
- **Scoped CSS**: static `class` values are augmented with the component's `analysis.css.hash` (see [CSS Transform](compiler-transformer_css-transform.md)).
- **`build_element_attribute_update`** maps attribute names to the correct runtime setter: DOM *properties* (`is_dom_property`) become plain assignments; `value`/`checked`/`selected`/`defaultValue`/`defaultChecked` use dedicated `$.set_*` helpers; `xlink:*` uses `$.set_xlink_attribute`; everything else `$.set_attribute`. Dynamic values get the "compare-and-swap" `template_effect` shape (`if (value !== (value = …))`).
- **Special value handling** for `<option value>`, `<select bind:value>` (legacy `setup_select_synchronization` invalidates inner signals via `$.invalidate_inner_signals`).
- If the fragment contains a `SnippetBlock`, child statements are wrapped in a nested `{ … }` block to avoid declaration clashes.

### 5.3 Control-flow blocks

All four follow the same skeleton: **push comment anchor → visit children into arrow functions → emit runtime block call → (optional) async wrap**.

#### `IfBlock`
```js
// generated sketch
$.if($$anchor, ($$render) => { if (test) $$render(consequent); else $$render(alternate, false); });
```
- `consequent` / `alternate` bodies become `($$anchor) => {...}` arrows (visited as child state).
- The trailing `true` argument marks `{:else if}` chains so transitions play *locally* on any branch change.

#### `EachBlock`
The most state-sensitive block:
- **Flags bitmask** (`EACH_INDEX_REACTIVE`, `EACH_ITEM_REACTIVE`, `EACH_ITEM_IMMUTABLE`, `EACH_IS_ANIMATED`, `EACH_IS_CONTROLLED`) computed from metadata: keyed+index, key-is-item, store subscriptions, `animate:` presence, controlled (sole child of element).
- The **collection expression is evaluated in the parent scope** (the each-item scope does not exist yet).
- Item/context patterns get `transform` entries: plain identifier → `array[index]` reads (legacy reassignment) or `get_value`; destructuring patterns → `$.derived`/`$.derived_safe_equal` declarations with eager dev evaluation to surface TDZ errors.
- Legacy mode additionally collects `transitive_deps` (including parent each blocks) to build an invalidation sequence; `store_to_invalidate` produces `$.invalidate_store`.
- Key function is `$.index` for non-keyed, or an arrow over `(item[, index])` otherwise; dev adds `$.validate_each_keys`.
- Fallback (`{:else}`) becomes an extra `($$anchor) => {...}` argument.
- A unique `$$array` id is allocated when inner scope shadows outer names (needed for `bind:group` invalidation).

#### `KeyBlock`
`$.key($$anchor, key_thunk, ($$anchor) => { body })` — contents are destroyed and recreated whenever the key changes. Supports async keys via `$.async`.

#### `AwaitBlock`
- The awaited **expression is visited first** (before then/catch) to keep scope ordering correct; emitted as a thunk (async-aware).
- `create_derived_block_argument` compiles `then (value)` / `catch (error)` parameters: identifiers get a `read: get_value` transform; destructuring patterns become a `$$value` derived of the destructured object plus per-identifier deriveds.
- Emits `$.await($$anchor, expr, pending, then, catch)` where missing branches are `null`.

### 5.4 Snippets & render tags

#### `SnippetBlock`
Compiles `{#snippet name(params)}body{/snippet}`:
- Signature: `($$anchor, param = $.noop, …)`.
- Identifier params get `transform[name] = { read: b.call }` (values are signals inside snippet scope); destructured params get derived declarations (`get_value` reads), with default values guarded by `$.derived_safe_equal` so they evaluate only once.
- Dev: body begins with `$.validate_snippet_args(...arguments)` and eager reads; the snippet becomes a `function` wrapped by `$.wrap_snippet(analysis.name, fn)` instead of an arrow.
- **Hoisting**: top-level snippets go to `module_level_snippets` (if `metadata.can_hoist`) or `instance_level_snippets`; nested snippets are pushed into `state.init` of their enclosing block.

#### `RenderTag`
Compiles `{@render fn(args)}`:
- Arguments are memoized (`Memoizer`) when they contain calls or awaits; each becomes a thunk.
- **Dynamic** (callee not a static snippet reference, e.g. through props/chains): `$.snippet($$anchor, () => fn, ...thunks)` with a `?? $.noop` fallback for optional chains.
- **Static**: direct invocation `fn($$anchor, ...thunks)` (optional-call aware).
- Wraps with `$.async` when awaited values are involved; anchors via `push_comment`.

### 5.5 Components, slots & boundaries

#### `Component`
A thin shim: `context.state.init.push(build_component(node, node.name, context))`. All heavy lifting — prop/spread assembly, slot serialization (`$$slots`), `children` prop interop, `bind:this`, attachments (`$.attachment`), CSS custom props (`--foo` → `$.css_props` wrapper element), dynamic components via `$.component`, dev ownership validation — lives in the shared `build_component` helper so `SvelteComponent`/`SvelteSelf` can reuse it (those node types route through the same helper via the component group of visitors).

#### `SlotElement`
Compiles `<slot {a} name="x">fallback</slot>`:
- Attributes become a props object; stateful ones use getters (`get a() { return value }`), memoized when calling/awaited; spreads become `$.spread_props` arguments; `let:` directives are visited first.
- Fallback children become `($$anchor) => {...}` or `null`.
- Emits `$.slot($$anchor, $$props, name_literal, props_object, fallback)` — wrapped in `$.async` when needed.

#### `SvelteBoundary`
Compiles `<svelte:boundary>`:
- Attributes → props object (get-props when stateful).
- **`const:` handling**: non-async mode visits `ConstTag`s into a `const_tags` list and *duplicates* those declarations into every non-`pending`/`failed` snippet (historical allowance, flagged as a mistake in comments); async mode keeps const tags inside the boundary fragment.
- Snippets named `pending`/`failed` are exposed as boundary props; other snippets are hoisted out of the fragment.
- Emits `$.boundary($$anchor, props, ($$anchor) => { block })` after pushing an anchor comment.

### 5.6 Dynamic & raw content

#### `SvelteElement` (`<svelte:element this={tag}>`)
- Because the tag is unknown at compile time, **all attributes go through `build_attribute_effect`** (runtime attribute-setting logic), except the static-class-only fast path via `build_set_class`.
- Attributes/directives are processed in an **inner context** bound to a generated `$$element` id; results (init/update/after_update) become the *body of a function* passed to the runtime.
- Dynamic `xmlns` attribute supported; child namespace computed with `determine_namespace_for_children`.
- Emits `$.element($$anchor, tag_thunk, svgFlag, inner_fn, ns_thunk, [line, col])`; dev adds tag/void validations and location info; async tags use `$.async`.

#### `HtmlTag` (`{@html expr}`)
`$.html($$anchor, thunk, isSvg, isMathml, hydration_ignore_flag)`; the comment anchor supports hydration diffing; async expressions wrap in `$.async`. Pushed to `init` deliberately *after* template concerns so later bindings can override hydration.

---

## 6. Data Flow

```mermaid
flowchart TD
    subgraph Input
        AST["Annotated AST node<br/>(type + metadata)"]
        CTX["ComponentContext<br/>state: init/update/after_update,<br/>template, transform, memoizer, scope"]
    end
    subgraph Visitor["Structural visitor"]
        V1["Inspect metadata<br/>(has_state/has_await/dynamic/keyed…)"]
        V2["Push static pieces → state.template"]
        V3["Visit children with derived state<br/>(new scope / transform boundary)"]
        V4["Serialize expressions<br/>build_expression → Memoizer"]
        V5["Compose runtime call (b.call '$.…')<br/>+ add_svelte_meta in dev"]
        V6["Append to state.init / state.update /<br/>state.after_update / state.hoisted"]
        V7["Return block statement<br/>(Fragment returns b.block)"]
    end
    subgraph Output
        JS["estree AST<br/>const root = $.from_html('…')<br/>export default App($$anchor, $$props) { … }"]
        MAP["Runtime wiring<br/>(see Client Runtime Engine)"]
    end
    AST --> V1
    CTX --> V2
    V1 --> V2 --> V3 --> V4 --> V5 --> V6 --> V7
    CTX --> V3
    V7 --> JS
    V6 --> JS
    JS --> MAP
```

**Example** — `<div class="wrap">{#if ok}<p>hi</p>{/if}</div>` compiles to (simplified):

```js
import * as $ from 'svelte/internal/client';

const root = $.from_html(`<div class="wrap svelte-hash"><!></div>`);

export default function App($$anchor, $$props) {
	$.push(true, 0);
	var div = root();
	var node = $.child(div, true);
	$.add_svelte_meta?.(() =>                                   // dev only
		$.if(node, ($$render) => {
			if (ok) $$render(($$anchor) => {                     // consequent arrow
				var p = $.from_html(`<p>hi</p>`)();
				$.append($$anchor, p);
			});
		}), 'if', App.name, 1, 20);
	$.reset(div);
	$.append($$anchor, div);
	$.pop();
}
```

---

## 7. Process Flow: Compiling a Fragment (end-to-end)

```mermaid
sequenceDiagram
    participant W as visit walker
    participant F as Fragment visitor
    participant CN as clean_nodes
    participant RE as RegularElement visitor
    participant TB as Template builder
    participant ST as ComponentClientTransformState
    participant RT as Runtime calls (emitted)

    W->>F: visit(Fragment, ctx)
    F->>F: infer_namespace(parent)
    F->>CN: nodes, preserve_whitespace/comments
    CN-->>F: hoisted[], trimmed[], is_standalone, is_text_first
    alt single RegularElement
        F->>RE: visit(element, state{node: id})
        RE->>TB: push_element/set_prop/pop_element
        RE->>ST: init/after_update (attrs, directives)
        F->>ST: hoisted += root = $.from_html(…)
        F->>ST: init += const el = root()
    else mixed content
        F->>F: process_children(trimmed)
        loop each child / text run
            F->>TB: push_comment / push_text
            F->>W: visit(child, state{node: anchor})
            W-->>ST: init/update statements (blocks, tags)
        end
        F->>ST: hoisted += fragment template (unless standalone)
    end
    F->>ST: body = consts → init → render_effect → after_update → append
    alt has_await
        F-->>W: $.async_body(() => { body })
    else
        F-->>W: block(body)
    end
    Note over RT: At runtime: template cloned via root(),<br/>blocks attach at comment anchors,<br/>render effect updates reactive chunks
```

---

## 8. Runtime Contract (emitted API surface)

Structural visitors emit calls grouped by runtime area (implemented in the [Client Runtime Engine](client-runtime-engine.md), [DOM Renderer](client-dom-renderer.md), [Reactivity Engine](client-reactivity-engine.md) modules):

| Area | Functions emitted by this module |
|---|---|
| Templates & DOM ops | `$.from_html/from_svg/from_mathml`, `$.append`, `$.child`, `$.first_child`, `$.sibling`, `$.next`, `$.comment`, `$.text`, `$.set_text`, `$.set_attribute`, `$.set_xlink_attribute`, `$.set_value`, `$.set_checked`, `$.set_selected`, `$.set_default_value`, `$.set_default_checked`, `$.set_custom_element_data`, `$.autofocus`, `$.remove_input_defaults`, `$.remove_textarea_child`, `$.hydrate_template`, `$.reset` |
| Control flow | `$.if`, `$.each`, `$.key`, `$.await`, `$.element`, `$.html`, `$.snippet`, `$.component`, `$.slot`, `$.boundary`, `$.async`, `$.async_body`, `$.aborted` |
| Reactivity | `$.template_effect`, `$.derived`, `$.derived_safe_equal`, `$.get`, `$.untrack`, `$.deep_read_state`, `$.spread_props`, `$.index`, `$.noop` |
| Legacy | `$.invalidate_inner_signals`, `$.invalidate_store`, `$.init_select`, `$.select_option`, `$.replay_events`, `$.validate_binding` (dev) |
| Dev-only | `$.add_svelte_meta`, `$.wrap_snippet`, `$.validate_snippet_args`, `$.validate_each_keys`, `$.validate_dynamic_element_tag`, `$.validate_void_dynamic_element` |

Treeshakeability of the runtime depends on emitting only the `$.` calls a component actually uses — the [treeshakeability checker](treeshakeability_checker.md) guards this invariant.

---

## 9. Related Modules

- [Compiler Transformer (parent)](compiler-transformer.md) — overall phase-3 architecture, `TransformState`
- [Client Transform (parent)](compiler-transformer_client-transform.md) — visitor map, component entry points
- [Client Transform Infrastructure](compiler-transformer_client-transform_infrastructure.md) — `visit`, `Template`, `transform_template`
- [Client Transform Expression Visitors](compiler-transformer_client-transform_expression-visitors.md) — consume the `transform` maps these visitors install
- [Client Transform Directive Visitors](compiler-transformer_client-transform_directive-visitors.md) — invoked by `RegularElement`/`SvelteElement` via attribute dispatch
- [Server Transform](compiler-transformer_server-transform.md) — SSR twins of these visitors
- [CSS Transform](compiler-transformer_css-transform.md) — provides `analysis.css.hash` used for scoped classes
- [Analyzer](compiler-analyzer.md) — produces all `node.metadata.*` consumed here
- [AST Builders](compiler-core_ast_builders.md) — the `b.*` factory API used throughout
- [Client Runtime Engine](client-runtime-engine.md) / [DOM Renderer](client-dom-renderer.md) / [Client Reactivity](client-reactivity-engine.md) — the `$` functions generated code links against
- [Compiler Core Types](compiler-core_type_definitions.md) — `AST.Root`, `AST.Fragment`, `RegularElement`, … type definitions
