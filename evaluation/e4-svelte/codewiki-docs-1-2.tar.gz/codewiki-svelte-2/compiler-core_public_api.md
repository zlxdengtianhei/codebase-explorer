# compiler-core_public_api

> **Source:** `packages/svelte/src/compiler/index.js` — the single entry file that forms the *public API surface* of the Svelte compiler core (what tooling and end users import as `svelte/compiler`).

## 1. Overview

`compiler-core_public_api` is the **facade module** of the compiler pipeline. It exposes a small, stable set of functions that orchestrate the entire compilation workflow — parsing, analysis, and transformation — while hiding the internal phase machinery behind clean entry points:

| Export | Kind | Purpose |
|---|---|---|
| `compile(source, options)` | function | Compiles a `.svelte` component into a JavaScript module + CSS. |
| `compileModule(source, options)` | function | Compiles a plain JavaScript/TypeScript module that uses runes (`$state`, `$derived`, …). |
| `parse(source, options)` | function | Parses a component and returns **only** its AST (no code generation). |
| `preprocess` | re-export | Runs user-supplied markup/script/style preprocessors (async). |
| `migrate` | re-export | Rewrites Svelte 4 syntax to Svelte 5 runes syntax. |
| `VERSION` | constant | The current compiler version string. |
| `walk` | **deprecated** | Stub that throws — `walk` must now be imported from `estree-walker`. |

The module contains **no compilation logic of its own**. Every entry point follows the same discipline:

1. **Sanitize input** (strip the UTF-8 byte-order mark).
2. **Reset global compile state** (`state.reset`) so compilations are isolated.
3. **Validate user options**.
4. **Delegate to the pipeline phases** (parse → analyze → transform).
5. **Post-process the result** into the public `CompileResult` shape.

This makes it the *composition root* of the compiler and the only module that downstream tools (bundlers, `vite-plugin-svelte`, language tools, playgrounds) should depend on.

---

## 2. Position in the System

The module is the top child of `compiler-core`, which in turn is one sub-pipeline of the overall `Compiler_Pipeline___Language_Toolchain`. It wires together the sibling phases:

```mermaid
flowchart TB
    subgraph USER["Consumers"]
        BUNDLER["Bundlers / vite-plugin-svelte"]
        TOOLING["Language tools / playgrounds"]
    end

    subgraph CORE["compiler-core"]
        subgraph PUBLIC["compiler-core_public_api (this module)"]
            API["compile / compileModule / parse"]
        end
        OPTVAL["compiler-core_options_validation"]
        CSTATE["compiler-core_compile_state"]
        DIAG["compiler-core_diagnostics"]
        BUILDERS["compiler-core_ast_builders"]
        TYPES["compiler-core_type_definitions"]
    end

    subgraph PIPE["Compiler Pipeline (phases)"]
        PARSER["compiler-parser<br/>(phases/1-parse)"]
        ANALYZER["compiler-analyzer<br/>(phases/2-analyze)"]
        TRANSFORMER["compiler-transformer<br/>(phases/3-transform)"]
    end

    PREPROC["compiler-preprocessor"]
    MIGRATOR["compiler-migrator"]

    USER --> API
    API --> OPTVAL
    API --> CSTATE
    API --> PARSER
    PARSER --> ANALYZER
    ANALYZER --> TRANSFORMER
    ANALYZER --> DIAG
    PARSER --> DIAG
    OPTVAL --> DIAG
    ANALYZER --> BUILDERS
    TRANSFORMER --> BUILDERS
    API -. re-exports .-> PREPROC
    API -. re-exports .-> MIGRATOR
    TRANSFORMER --> TYPES
```

The re-exported functions (`preprocess`, `migrate`) are *pre/post-processing utilities* that operate on raw source text rather than on the pipeline itself — `preprocess` typically runs **before** `compile`, and `migrate` is an offline codemod.

---

## 3. Architecture of the Entry Points

### 3.1 `compile(source, options)`

The main component compiler. Internal steps, in order:

1. `remove_bom(source)` — strips `U+FEFF`, which would corrupt template-generation offsets.
2. `state.reset({ warning: options.warningFilter, filename })` — initializes per-compilation state (warning filter, filename, warning buffer, `svelte-ignore` stack). See [compiler-core_compile_state](compiler-core_compile_state.md).
3. `validate_component_options(options, '')` — normalizes/validates `CompileOptions`, removing unknown keys and warning about deprecated/removed ones. See [compiler-core_options_validation](compiler-core_options_validation.md).
4. `_parse(source)` — full parse of template + `<script>` blocks + `<svelte:options>`. See [compiler-parser](compiler-parser.md).
5. **Option merging** — `<svelte:options>` attributes parsed from the source override the validated JS options (`customElement` is carried separately as `customElementOptions`).
6. **TypeScript stripping** — if `parsed.metadata.ts` is set, `remove_typescript_nodes` is applied to the `fragment`, `instance`, and `module` ASTs (and to `customElementOptions.extend`), converting TS-only syntax into plain JS before analysis.
7. `analyze_component(parsed, source, combined_options)` — scope creation, binding classification, runes-mode inference, store-subscription synthesis, CSS analysis and pruning. See [compiler-analyzer](compiler-analyzer.md). During analysis the compile state is adjusted via `state.adjust({ component_name, dev, rootDir, runes })`.
8. `transform_component(analysis, source, combined_options)` — emits the output program. Honors `options.generate`: `'client'` (default), `'server'` (SSR), or `false` (analysis-only). Output is printed with source-map support and merged with preprocessor source maps. See [compiler-transformer](compiler-transformer.md).
9. `to_public_ast(...)` — attaches the AST to the result:
   - `modernAst: true` → walks the AST and **deletes all `metadata` nodes**, exposing only the public `AST.Root` shape (see [compiler-core_type_definitions](compiler-core_type_definitions.md)).
   - otherwise → `convert(source, ast)` produces the **legacy AST** (`LegacyRoot`) for backwards compatibility.

```mermaid
sequenceDiagram
    autonumber
    participant U as Caller
    participant API as compile entry
    participant S as compile_state state.js
    participant V as options_validation
    participant P as compiler-parser
    participant A as compiler-analyzer
    participant T as compiler-transformer

    U->>API: source, CompileOptions
    API->>API: remove_bom(source)
    API->>S: state.reset({warningFilter, filename})
    API->>V: validate_component_options(options)
    V-->>API: ValidatedCompileOptions
    API->>P: _parse(source)
    P-->>API: Root AST (+ <svelte:options>, metadata.ts)
    API->>API: merge parsed options,<br/>strip TS nodes if needed
    API->>A: analyze_component(parsed, source, options)
    A->>S: state.adjust({name, dev, rootDir, runes})
    A-->>API: ComponentAnalysis (+warnings)
    API->>T: transform_component(analysis, source, options)
    T-->>API: {js, css, warnings, metadata}
    API->>API: result.ast = to_public_ast(...)
    API-->>U: CompileResult
```

### 3.2 `compileModule(source, options)`

Compiles **non-component JS modules** that use runes (e.g. `.svelte.js` files):

1. BOM strip + `state.reset` (same as `compile`).
2. `validate_module_options(options, '')` — a stricter subset of options (no template/CSS options).
3. `analyze_module(source, validated)` — JS-only scope & rune analysis.
4. `transform_module(analysis, source, validated)` — emits the module; prepends a `/* file.js generated by Svelte vX.Y.Z */` banner and always reports `metadata.runes: true`.

Unlike `compile`, there is no template parsing and `css` is always `null`.

```mermaid
flowchart LR
    A["source (JS with runes)"] --> B["remove_bom"]
    B --> C["state.reset"]
    C --> D["validate_module_options"]
    D --> E["analyze_module"]
    E --> F["transform_module<br/>(client or server)"]
    F --> G["prepend version banner + fix sourcemap offset"]
    G --> H["CompileResult<br/>(js, warnings, metadata.runes = true, css = null)"]
```

### 3.3 `parse(source, { modern, loose, filename? })`

Parse-only entry point used by tooling:

- Suppresses all warnings (`state.reset({ warning: () => false })`).
- Returns the AST without compiling; throws on syntax errors unless `loose: true`, which attempts to always return an AST even for input that would not compile.
- `modern: true` returns the cleaned modern AST (`AST.Root`, metadata stripped); default (`false`, until Svelte 6) returns the legacy AST via `convert`.
- The `filename` option is unused and slated for removal in Svelte 6.

### 3.4 Re-exports

| Export | Origin | Behaviour |
|---|---|---|
| `preprocess(source, preprocessor, options?)` | [compiler-preprocessor](compiler-preprocessor.md) | Async; runs `markup`, `script`, and `style` preprocessors in sequence, accumulating a combined source map. Returns `Processed { code, map, dependencies }`. |
| `migrate(source, { filename?, use_ts? })` | [compiler-migrator](compiler-migrator.md) | Codemod: Svelte 4 → 5 (`export let` → `$props()`, `$:` → `$derived`/`$effect`, event directives → props, slots → snippets). On failure it embeds an `@migration-task` comment instead of throwing. |

---

## 4. Public Data Contracts

### `CompileResult` (returned by `compile` / `compileModule`)

```ts
interface CompileResult {
  js: {
    code: string;        // generated JavaScript
    map: SourceMap;      // source map
  };
  css: null | {
    code: string;
    map: SourceMap;
    hasGlobal: boolean;  // whether CSS includes global rules
  };
  warnings: Warning[];   // { code, message, start?, end? } — see diagnostics module
  metadata: {
    runes: boolean;      // whether runes mode was used (always true for compileModule)
  };
  ast: any;              // public AST (modern or legacy, per options)
}
```

Type definitions for options, AST nodes (template, CSS, legacy) and `CompileError` live in [compiler-core_type_definitions](compiler-core_type_definitions.md). Errors and warnings are produced by the [compiler-core_diagnostics](compiler-core_diagnostics.md) system and flow through the compile state described in [compiler-core_compile_state](compiler-core_compile_state.md).

### Compile state interaction

Each public entry point is *self-isolating*: `state.reset(...)` clears the module-scoped state (warning buffer, warning filter, filename, ignore stack) before work begins, and analysis calls `state.adjust(...)` once runes mode and the component name are known. This is what makes the public API safe for concurrent/sequential use inside a bundler process.

---

## 5. End-to-End Compilation Flow

```mermaid
flowchart TB
    SRC["Input sources"] --> PRE["preprocess()<br/>(optional, async)"]
    PRE --> CMP["compile(source, options)"]
    JS["JS module with runes<br/>(.svelte.js)"] --> CM["compileModule(source, options)"]
    SRC --> MIG["migrate(source)<br/>(Svelte 4 → 5 codemod)"]
    MIG --> CMP
    SRC --> PARSE["parse(source, {modern, loose})"]

    CMP --> OUT["CompileResult"]
    CM --> OUT
    PARSE --> AST["AST.Root (modern)<br/>LegacyRoot (default)"]

    OUT --> CLI["generate: 'client'<br/>→ DOM components"]
    OUT --> SSR["generate: 'server'<br/>→ SSR render functions"]
    OUT --> ANL["generate: false<br/>→ analysis-only (no code)"]
```

Target selection is entirely option-driven: `compile` never branches on environment; `transform_component` picks `client_component` or `server_component` based on `options.generate`.

---

## 6. Related Modules

- [compiler-parser](compiler-parser.md) — phase 1: tokenizer/parser for templates, scripts and `<svelte:options>`, invoked as `_parse` by `compile` and `parse`.
- [compiler-analyzer](compiler-analyzer.md) — phase 2: scopes, bindings, runes inference, CSS pruning; produces the `ComponentAnalysis` consumed by the transformer.
- [compiler-transformer](compiler-transformer.md) — phase 3: client/server code generation, CSS rendering and printing (with source maps).
- [compiler-preprocessor](compiler-preprocessor.md) — the `preprocess` re-export implementation.
- [compiler-migrator](compiler-migrator.md) — the `migrate` re-export implementation.
- [compiler-core_options_validation](compiler-core_options_validation.md) — `validate_component_options` / `validate_module_options` used by every entry point.
- [compiler-core_compile_state](compiler-core_compile_state.md) — module-scoped compile state (`reset`, `adjust`, warning buffer, `push_ignore`/`pop_ignore`).
- [compiler-core_diagnostics](compiler-core_diagnostics.md) — error/warning code registry (`CompileError`, `Warning`) and code-frame rendering.
- [compiler-core_ast_builders](compiler-core_ast_builders.md) — ESTree node builders used heavily during transform.
- [compiler-core_type_definitions](compiler-core_type_definitions.md) — `CompileResult`, `CompileError`, template/CSS/legacy AST type definitions.
- [svelte-public-types](svelte-public-types.md) — the bundled `svelte/types` surface that re-exposes `CompileResult`, `ModuleCompileOptions`, and AST types to end users.
