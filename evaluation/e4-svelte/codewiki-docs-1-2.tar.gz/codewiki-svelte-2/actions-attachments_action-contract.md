# Action Type Contract (`actions-attachments_action-contract`)

> Sub-module of **actions-attachments** — see the parent overview in [`actions-attachments.md`](actions-attachments.md).

## 1. Purpose & Scope

This sub-module is the **type-level contract** for Svelte *actions* — the mechanism behind the `use:` template directive. It lives in a single file:

| File | Contents |
|---|---|
| [`packages/svelte/src/action/public.d.ts`](../packages/svelte/src/action/public.d.ts) | `Action` and `ActionReturn` interfaces |

The module is **purely declarative**: it contains no runtime JavaScript. `svelte/action` ships *only* these types, and its output is fully tree-shakeable. The contract exists so that:

- **app authors** can write `<div use:myAction={param}>` and get parameter, element, and event type-safety;
- **library authors** can export actions with a precise, publicly documented signature;
- **the runtime and compiler** have a stable, documented behavioral promise (invoke once on create → `update` on parameter change → `destroy` on unmount) to implement against.

Runtime execution of actions is *not* part of this module — it is delegated (and documented separately):

- compiler lowering (`use:` → `$.action(...)`) → [`compiler-transformer_client-transform_directive-visitors.md`](compiler-transformer_client-transform_directive-visitors.md)
- runtime executor `$.action()` → [`client-dom-renderer_attributes-events.md`](client-dom-renderer_attributes-events.md)
- the legacy-action ⇄ attachment bridge (`fromAction`) → sibling module [`actions-attachments_attachment-bridge.md`](actions-attachments_attachment-bridge.md)

---

## 2. Public Surface

```ts
// packages/svelte/src/action/public.d.ts

interface ActionReturn<
  Parameter = undefined,
  Attributes extends Record<string, any> = Record<never, any>
> {
  update?: (parameter: Parameter) => void;
  destroy?: () => void;
  /** DO NOT USE — phantom property that exists solely to carry `Attributes` for type-checking. */
  $$_attributes?: Attributes;
}

interface Action<
  Element = HTMLElement,
  Parameter = undefined,
  Attributes extends Record<string, any> = Record<never, any>
> {
  <Node extends Element>(
    ...args: undefined extends Parameter
      ? [node: Node, parameter?: Parameter]
      : [node: Node, parameter: Parameter]
  ): void | ActionReturn<Parameter, Attributes>;
}
```

```mermaid
classDiagram
    class Action~Element, Parameter, Attributes~ {
        <<interface>>
        +call(node : Node extends Element, parameter?) void | ActionReturn~Parameter, Attributes~
    }
    class ActionReturn~Parameter, Attributes~ {
        <<interface>>
        +update?(parameter : Parameter) void
        +destroy?() void
        -$$_attributes? : Attributes
    }
    Action ..> ActionReturn : returns
    note for ActionReturn "$$_attributes is a phantom field:\nexists only so TypeScript can check\nAttributes — never set at runtime"
```

---

## 3. Type-System Design Details

### 3.1 Conditional parameter arity

The call signature's rest parameter is conditional:

```
undefined extends Parameter  →  [node, parameter?]      (parameter optional)
otherwise                    →  [node, parameter]       (parameter required)
```

Consequences:

| Author writes | Callers must pass |
|---|---|
| `Action<HTMLDivElement>` | node only |
| `Action<HTMLDivElement, undefined>` | node only |
| `Action<HTMLDivElement, string \| undefined>` | node, and `parameter?` is optional |
| `Action<HTMLDivElement, string>` | node **and** `parameter: string` |

The implementation note in the source explains the deliberate choice of `undefined extends X` instead of `X extends undefined`: it behaves correctly under **both** `strict` and non-strict `tsconfig` settings (under non-strict mode every type absorbs `undefined`, so `X extends undefined` would wrongly make required parameters optional).

### 3.2 The `Attributes` phantom generic

`Action<Element, Parameter, Attributes>` lets an action *declare* extra attributes/events/properties it makes available on the host element. This is compile-time only:

```ts
interface Attributes {
  newprop?: string;
  'on:event': (e: CustomEvent<boolean>) => void;
}

export function myAction(node: HTMLElement, parameter: Parameter): ActionReturn<Parameter, Attributes> {
  // ...
  return { update: (p) => {...}, destroy: () => {...} };
}
```

Because TypeScript cannot otherwise express "this function adds attributes to the element it is applied to", the `ActionReturn` object carries the `Attributes` type on the never-populated `$$_attributes` field, marked `### DO NOT USE THIS` in the docs — setting it has **no effect at runtime**. The `Attributes` must always be passed via the generic, never by assigning to `$$_attributes`.

### 3.3 The `void |` return union

Returning nothing from an action is legal (`use:` directives that just poke the DOM on create/destroy need no lifecycle object). The executor treats a missing/empty return as `{}` — see §5.

---

## 4. Lifecycle Contract

The interfaces encode a fixed runtime promise. Actions are invoked **once**, when the element is created:

```mermaid
sequenceDiagram
    participant C as Component
    participant R as Runtime $.action()
    participant A as action(node, param)

    C->>R: element created (use:myAction={param})
    R->>A: action(node, param) — called untracked
    A-->>R: void | { update?, destroy? }

    loop every parameter change (after markup updates)
        R->>A: payload.update(newParam)
        Note over A: only if action returned update;<br/>only when safe_not_equal(prev, param)
    end

    C->>R: element unmounted
    R->>A: payload.destroy()
    Note over A: only if action returned destroy
```

Semantics guaranteed by the runtime that fulfills this contract:

- **`update`** is called "whenever that parameter changes, immediately *after* Svelte has applied updates to the markup" (per the interface docs) — so `update` may safely measure/mutate the DOM.
- **`destroy`** is called *after* the element is unmounted.
- Both hooks are **optional**; `ActionReturn` and `ActionReturn<undefined>` mean the action accepts no parameters.

---

## 5. Parameter Reactivity Semantics

The contract's most subtle clause is what "the parameter changed" means. The runtime compares snapshots of the parameter expression using **coarse-grained `safe_not_equal`** equality (documented in [`client-reactivity-engine_foundation.md`](client-reactivity-engine_foundation.md)):

| Parameter kind | `update` fires when |
|---|---|
| Primitive (`string`, `number`, …) | value differs (with `NaN` treated as always-changed) |
| Object / array / function | **reference** differs — in-place `$state` mutation alone does *not* fire it |

The runtime bridges the object-mutation gap by performing a `deep_read_state` on the parameter before comparing, so `$state` proxies are traversed and the effect re-runs; the `safe_not_equal` reference check then decides whether the user's `update` hook is actually invoked (see the executor source in [`client-dom-renderer_attributes-events.md`](client-dom-renderer_attributes-events.md)). Action `update` is therefore *deliberately* less reactive than an attachment's whole-body re-run — for fine-grained reactivity, migrate via `fromAction` ([`actions-attachments_attachment-bridge.md`](actions-attachments_attachment-bridge.md)).

---

## 6. How the Contract Flows Through the System

```mermaid
flowchart TD
    subgraph Types["this module — types only"]
        ACT["Action&lt;E, P, Attrs&gt;"]
        RET["ActionReturn&lt;P, Attrs&gt;"]
        ACT --> RET
    end

    subgraph Author["Authoring surfaces"]
        LIB["Library exports<br/>const a: Action&lt;E, P&gt; = ..."]
        TPL["Template<br/>use:a={expr}"]
    end

    subgraph Compile["compiler-transformer"]
        UD["UseDirective visitor:<br/>$.action($$node, action, () => expr)"]
    end

    subgraph Run["client-dom-renderer"]
        EXE["$.action(dom, action, get_value)<br/>untrack call · render_effect for update<br/>teardown for destroy"]
    end

    subgraph Bridge["actions-attachments sibling"]
        FA["fromAction(action, () => arg)<br/>Action → Attachment adapter"]
        ATT["{@attach ...} / spread"]
    end

    subgraph Pub["svelte-public-types"]
        RE["packages/svelte/types/index.d.ts<br/>re-exports Action"]
    end

    LIB -.typed against.-> ACT
    TPL --> UD --> EXE
    EXE -.honors lifecycle of.-> RET
    LIB --> FA
    FA --> ATT
    ACT -.re-exported.-> RE
```

Key interactions, in order of importance:

1. **Template consumption** — the `UseDirective` compiler visitor lowers `<div use:a={expr}>` into `$.action($$node, a, () => expr)`, preserving the contract's arity rule (the thunk argument is emitted only when a directive value exists). Details: [`compiler-transformer_client-transform_directive-visitors.md`](compiler-transformer_client-transform_directive-visitors.md).
2. **Runtime fulfillment** — `$.action` invokes the action untracked inside an effect, wires `update` to a `render_effect`, and returns the effect teardown as `destroy`. Details: [`client-dom-renderer_attributes-events.md`](client-dom-renderer_attributes-events.md).
3. **Attachment bridging** — `fromAction` consumes any `Action` and re-exposes it under attachment semantics; note that its argument must be a *thunk* (`() => param`) to keep the update path reactive. Details: [`actions-attachments_attachment-bridge.md`](actions-attachments_attachment-bridge.md).
4. **Type re-export** — `Action` is surfaced through the package's public `types/index.d.ts`; see [`svelte-public-types.md`](svelte-public-types.md).

> **No SSR counterpart:** actions/attachments are client-only constructs — `internal/server` contains no executor for this contract (see [`server-runtime.md`](server-runtime.md)).

---

## 7. Typing Recipes

```ts
// 1. Simplest — no parameter, generic element
export const autofocus: Action = (node) => {
  node.focus();
};

// 2. Element-constrained, required parameter
export const tooltip: Action<HTMLDivElement, string> = (node, text) => {
  // node is HTMLDivElement; text: string (required at call sites)
};

// 3. Optional parameter with a default
export const myAction: Action<HTMLDivElement, { someProperty: boolean } | undefined> =
  (node, param = { someProperty: true }) => { /* ... */ };

// 4. Declaring extra attributes/events on the host element
interface Attributes {
  newprop?: string;
  'on:event': (e: CustomEvent<boolean>) => void;
}
export const declarer: Action<HTMLElement, string, Attributes> = (node, p) => {
  return { update: (p2) => {}, destroy: () => {} };
};
// <div use:declarer={'x'} on:event={...} newprop={'y'} /> — all type-checked
```

### Gotchas

- `Action<E>` and `Action<E, undefined>` are the canonical "no parameters" spellings — *not* `Action<E, void>` (which would require callers to pass `undefined` explicitly is avoided only because of the `undefined extends` conditional; stick to the documented forms).
- `update` receives the **whole** parameter; there is no per-property diffing. Deep mutation of a `$state` object triggers the *effect* but, absent a reference change, does **not** call `update`.
- Never assign `$$_attributes`; pass `Attributes` through the generic.
- The action function itself is called **once** per element instance; re-creating behavior on state change is the job of `update` (or of switching to attachments).

---

## 8. Related Documentation

| Topic | Page |
|---|---|
| Parent module overview, actions vs attachments comparison | [`actions-attachments.md`](actions-attachments.md) |
| `fromAction` / `createAttachmentKey` runtime bridge | [`actions-attachments_attachment-bridge.md`](actions-attachments_attachment-bridge.md) |
| Compiler lowering of `use:` directives | [`compiler-transformer_client-transform_directive-visitors.md`](compiler-transformer_client-transform_directive-visitors.md) |
| `$.action()` / `attribute_effect` executors | [`client-dom-renderer_attributes-events.md`](client-dom-renderer_attributes-events.md) |
| `safe_not_equal` equality primitives | [`client-reactivity-engine_foundation.md`](client-reactivity-engine_foundation.md) |
| Public type re-exports (`Action`, `Attachment`, …) | [`svelte-public-types.md`](svelte-public-types.md) |
