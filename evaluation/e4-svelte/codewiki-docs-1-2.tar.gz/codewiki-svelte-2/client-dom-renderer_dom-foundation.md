# client-dom-renderer_dom-foundation

## 1. Introduction

`client-dom-renderer_dom-foundation` is the **lowest layer of Svelte's client-side DOM renderer**. It provides the primitive, zero-abstraction machinery that every compiled Svelte component relies on at runtime:

| File | Responsibility |
|---|---|
| `internal/client/dom/operations.js` | Low-level DOM traversal (`child`, `first_child`, `sibling`), node creation (`create_element`, `create_text`, `create_comment`, `create_fragment`), attribute writing (`set_attribute`), and one-time runtime environment bootstrap (`init_operations`). |
| `internal/client/dom/template.js` | Template factories (`from_html`, `from_svg`, `from_mathml`, `from_tree`) that parse markup once and clone it cheaply; anchors for dynamic content (`text`, `comment`, `append`); script execution handling (`with_script`); instance UIDs (`props_id`). |
| `internal/client/dom/hydration.js` | The hydration cursor state machine: the `hydrating` flag, the `hydrate_node` cursor, and the walkers (`hydrate_next`, `next`, `reset`, `remove_nodes`, `hydrate_template`, `read_hydration_instruction`). |
| `internal/client/dom/css.js` | Scoped stylesheet injection (`append_styles`) that targets `document.head` or a `ShadowRoot` depending on where the component lives. |

This module is intentionally **dual-mode**: every entry point branches on `hydrating` to either *create* fresh DOM (client-side mount) or *claim* server-rendered DOM (hydration). This lets the compiler emit one template function per component that works for both `mount()` and `hydrate()`.

> **Position in the system:** This module is a child of [client-dom-renderer](client-dom-renderer.md), which also contains the [lifecycle](client-dom-renderer_lifecycle.md), [control-flow blocks](client-dom-renderer_control-flow-blocks.md), [attributes & events](client-dom-renderer_attributes-events.md), [bindings](client-dom-renderer_bindings.md), [custom elements](client-dom-renderer_custom-elements.md) and [transitions](client-dom-renderer_transitions.md) subsystems. All of them are built on top of the primitives documented here. Reactivity is supplied by [client-reactivity-engine](client-reactivity-engine.md); the compiled code that *calls* these primitives is produced by [compiler-transformer_client-transform](compiler-transformer_client-transform.md).

---

## 2. Architecture

### 2.1 Module relationship graph

```mermaid
graph TD
    subgraph "client-dom-renderer_dom-foundation"
        OPS["operations.js<br/>child / first_child / sibling<br/>create_element / set_attribute<br/>init_operations"]
        TPL["template.js<br/>from_html / from_svg / from_mathml / from_tree<br/>text / comment / append / props_id / with_script"]
        HYD["hydration.js<br/>hydrating / hydrate_node<br/>hydrate_next / reset / remove_nodes<br/>hydrate_template / next"]
        CSS["css.js<br/>append_styles"]
    end

    subgraph "Reactivity engine (client-reactivity-engine)"
        RT["runtime.js<br/>active_effect"]
        EFF["reactivity/effects.js<br/>effect()"]
        BAT["reactivity/batch.js<br/>eager_block_effects"]
        FLG["flags/index.js<br/>async_mode_flag"]
    end

    subgraph "Dev tooling (client-dev-tooling)"
        DEVCSS["dev/css.js<br/>register_style / cleanup_styles"]
        DEQ["dev/equality.js<br/>init_array_prototype_warnings"]
        WARN["warnings.js<br/>hydration_mismatch"]
    end

    subgraph "Sibling subsystems"
        LC["lifecycle (render.js)<br/>mount / hydrate / unmount"]
        CFB["control-flow blocks<br/>if / each / key / await / snippet"]
        AE["attributes & events<br/>attribute_effect / event delegation"]
        BIND["bindings"]
        CE["custom elements"]
    end

    subgraph "Build time"
        COMP["Compiler client transform<br/>emits $.from_html, $.child, $.sibling, $.text ..."]
    end

    TPL -->|"imports traversal,<br/>node creation"| OPS
    TPL -->|"branches on / advances cursor"| HYD
    OPS -->|"branches on,<br/>moves cursor"| HYD
    OPS -->|"reads active_effect,<br/>async_mode_flag, eager_block_effects"| RT
    TPL -->|"assign_nodes →<br/>effect.nodes_start/end"| RT
    CSS -->|"inserts inside effect"| EFF
    CSS -->|"DEV: HMR registry"| DEVCSS
    OPS -->|"DEV: array warnings"| DEQ
    HYD -->|"mismatch warnings"| WARN

    LC -->|"init_operations,<br/>hydration walkers"| OPS
    LC -->|"set_hydrating / reset"| HYD
    CFB -->|"anchors, traversal"| TPL
    CFB -->|"traversal"| OPS
    AE -->|"__attributes / __click<br/>prototype slots"| OPS
    BIND -->|"attribute setters"| OPS
    CE -->|"template cloning"| TPL
    COMP -.->|"codegen targets"| TPL

    REC["reconciler.js<br/>create_fragment_from_html"] -->|"HTML → DocumentFragment"| TPL
```

### 2.2 The template protocol

The compiler's client transform emits, for every component, a `template` effect function that follows a strict convention:

```js
// generated (simplified)
function demo($$anchor, $$props) {
  $.append_styles($$anchor, { hash: '...', code: '...' });

  // 1. Obtain template DOM — creates on mount, claims on hydration
  var p = $.from_html(`<p>Hello <!><!></p>`, $.TEMPLATE_FRAGMENT)();

  // 2. Walk to anchor nodes — during hydration this *moves the cursor*
  var text = $.sibling(p.firstElementChild);
  $.text(text); // or assign a reactive effect to it

  // 3. Attach the result into the document
  $.append($$anchor, p);
}
```

The DOM-foundation module is what makes this protocol work in both modes:

- **Mount mode:** factories parse markup *once* and return cheap `cloneNode(true)` copies; traversal functions are plain pointer moves; `text`/`comment` allocate fresh nodes.
- **Hydration mode:** factories return the *existing* server-rendered node at the cursor; traversal functions advance the cursor and *synthesize missing text nodes* (e.g. when SSR produced an empty `{expression}`).

---

## 3. Core components

### 3.1 Runtime bootstrap — `init_operations` and global captures

`operations.js` lazily initializes client-side globals on first use:

```js
export function init_operations() {
  if ($window !== undefined) return; // idempotent
  $window = window;
  $document = document;
  is_firefox = /Firefox/.test(navigator.userAgent);

  first_child_getter  = get_descriptor(Node.prototype, 'firstChild').get;
  next_sibling_getter = get_descriptor(Node.prototype, 'nextSibling').get;

  // hidden, fast-access slots on Element.prototype / Text.prototype
  element_prototype.__click = undefined;
  element_prototype.__className = undefined;
  element_prototype.__attributes = null;
  element_prototype.__style = undefined;
  element_prototype.__e = undefined;
  text_prototype.__t = undefined;
  // DEV only: __svelte_meta (source locations), array prototype warnings
}
```

Key design points:

- **Lazy + idempotent** — the module can be imported in a server context without crashing; initialization only happens when client rendering actually starts ([client-dom-renderer_lifecycle](client-dom-renderer_lifecycle.md) calls `init_operations()` from `mount`/`hydrate`). This avoids a separate server entry point.
- **Native prototype getters** — `get_first_child`/`get_next_sibling` call the *bound native accessors* extracted from `Node.prototype` descriptors instead of ordinary property access. This measurably speeds up the DOM walks performed for every component instantiation.
- **Element prototype slots** — `__attributes`, `__click`, `__className`, `__style`, `__e` are per-element storage slots that avoid `WeakMap` lookups. They are written/read by [client-dom-renderer_attributes-events](client-dom-renderer_attributes-events.md) (attribute effects, event delegation) and transitions.
- **Firefox detection** — Firefox is slower at `cloneNode` for templates, so template cloning switches to `document.importNode` there.

### 3.2 DOM traversal — `child`, `first_child`, `sibling`

These three functions are the workhorses of the template protocol. Their signatures deliberately couple traversal with hydration:

| Function | Mount mode | Hydration mode |
|---|---|---|
| `child(node, is_text)` | returns `get_first_child(node)` | descends into `hydrate_node.firstChild`; **advances the cursor**; creates an empty `Text` node if the element has no child (SSR rendered `<p>{''}</p>` → `<p></p>`), or splices in a text node if a text expression is expected but the next node is not text |
| `first_child(fragment, is_text)` | first node of a cloned `DocumentFragment`; skips the empty `<!---->` anchor comment that `create_fragment_from_html` inserts for `<!>` markers | returns the cursor itself; synthesizes a missing text node like `child` |
| `sibling(node, count, is_text)` | moves `count` siblings forward from `node` | walks from the *cursor* (not `node`); advances the cursor; synthesizes missing text nodes at the end position |

All three are intentionally **not** marked side-effect-free, because the hydration code paths must never be dropped by the bundler when hydration is possible.

Empty-text synthesis is the trickiest invariant: because Svelte SSR collapses empty expressions (`{value}` where `value === ''`), the server HTML may simply *lack* the text node the client expects. The traversal functions repair this on the fly and register the synthesized node via `set_hydrate_node`.

### 3.3 Node creation & attributes — small but load-bearing helpers

- `create_element(tag, namespace, is)` — creates elements in the HTML, SVG or MathML namespace, with `is` support for customized built-in elements.
- `create_text(value)` / `create_comment(data)` / `create_fragment()` — thin wrappers that keep hot paths allocation-friendly and let the compiler target a single internal API.
- `set_attribute(element, key, value)` — routes `xlink:*` attributes through `setAttributeNS` (required for SVG links), otherwise `setAttribute`.
- `clear_text_content(node)` — used by the hydration **recovery path**: if hydration fails, [client-dom-renderer_lifecycle](client-dom-renderer_lifecycle.md) clears the target and falls back to a full client-side mount.
- `should_defer_append()` — coordination hook for async mode: reports whether a control-flow branch should defer its DOM insertion until other pending updates in the current `<svelte:boundary>` flush together (reads `async_mode_flag`, `eager_block_effects` and `active_effect.f & EFFECT_RAN`). Consumed by [client-dom-renderer_control-flow-blocks](client-dom-renderer_control-flow-blocks.md).

### 3.4 Template factories — `from_html`, `from_svg`, `from_mathml`, `from_tree`

Each factory has the signature `(content, flags) => () => Node | Node[]` and is marked `#__NO_SIDE_EFFECTS__` so bundlers can treeshake unused variants.

```mermaid
flowchart TD
    A["factory(content, flags)"] --> B{"hydrating?"}
    B -- "yes" --> C["assign_nodes(hydrate_node, null)<br/>return cursor — claim SSR DOM"]
    B -- "no" --> D{"template parsed<br/>before?"}
    D -- "no" --> E["Parse once:<br/>from_html → create_fragment_from_html<br/>from_svg/mathml → wrap in <svg>/<math><br/>from_tree → build DOM from structure"]
    E --> F["optional: extract single root<br/>if not TEMPLATE_FRAGMENT"]
    D -- "yes" --> G["clone stored node"]
    F --> G
    G --> H{"use_import_node<br/>or is_firefox?"}
    H -- "yes" --> I["document.importNode"]
    H -- "no" --> J["node.cloneNode(true)"]
    I --> K["assign_nodes(start, end)<br/>on active_effect"]
    J --> K
    K --> L["return clone"]
```

Behaviour details:

- **Parse-once, clone-many** — the expensive HTML→DOM conversion (`create_fragment_from_html` via `<template>.innerHTML`) happens exactly once; every subsequent instantiation is a clone. This is the core performance rationale of the whole design.
- **`<!>` start markers** — the compiler prefixes content with `<!>` when a fragment's first child is not itself an element/text node (e.g. it starts with a block). The factory re-writes this to `<!---->` (empty comment) during parsing so the clone always has a node to serve as `effect.nodes_start`; `first_child` then skips that empty comment.
- **Flags** — `TEMPLATE_FRAGMENT` (keep multiple roots), `TEMPLATE_USE_IMPORT_NODE` (force `importNode`), `TEMPLATE_USE_SVG` / `TEMPLATE_USE_MATHML` (namespace selection for `from_tree`).
- **`assign_nodes(start, end)`** — records the claimed/created DOM range on the *current effect* (`effect.nodes_start` / `effect.nodes_end`) only if not already set. [client-dom-renderer_lifecycle](client-dom-renderer_lifecycle.md) uses this range to remove components on `unmount`, and transitions/removal logic walks from `nodes_start` to `nodes_end`.
- **`from_tree(structure, flags)`** — builds DOM from a JSON template *structure* (nested `[tag, attributes, ...children]` arrays) rather than an HTML string. It handles namespaces (`svg`, `math`, `foreignObject` boundary reset), `<template>.content` placement, comments encoded as `['// <data>']`, and static attributes via `set_attribute`. The server compiler uses the same structure to emit SSR HTML, guaranteeing shape parity.

### 3.5 Dynamic content anchors — `text`, `comment`, `append`, `with_script`, `props_id`

- **`text(value)`** — creates (or claims) a `Text` node for `{expression}` output and assigns it to the effect. Hydration path reuses the SSR text node, inserting an empty one if the expression was empty on the server.
- **`comment()`** — creates a `[<!-- -->…text-anchor…]` fragment used as the *start/end bracket* for dynamic blocks (each branch, if branch, etc.). Notably it is *not* built from a template string, purely for performance.
- **`append(anchor, dom)`** — inserts the claimed/created range before `anchor`. During hydration it only advances the cursor (`hydrate_next`) and stamps `nodes_end`. `anchor === null` covers the void `<svelte:element>` edge case.
- **`with_script(fn)`** — wraps a template factory so `<script>` tags inside rendered HTML actually execute: cloned scripts are inert, so `run_scripts` re-creates each script element (copying attributes and `textContent`), fixing `effect.nodes_start`/`nodes_end` if a script sits at the fragment edges. During hydration this is skipped — the server already executed them.
- **`props_id()`** — generates the per-instance UID used by `css_props`/`<svelte:options css='inlined'>` scoping. When hydrating, it *reads back* the UID the server serialized as a `#cN` comment, so scoped CSS hashing matches across SSR and client.

### 3.6 Hydration cursor — `hydration.js`

This file is a tiny but critical state machine. Everything here must remain treeshakeable when hydration is unused (the `hydrating` flag guards all hydration-only code paths).

```mermaid
stateDiagram-v2
    [*] --> Idle: module load (hydrating = false)
    Idle --> Hydrating: render.js hydrate():<br/>find <!--[--> comment,<br/>set_hydrating(true),<br/>set_hydrate_node(start), hydrate_next()
    Hydrating --> Hydrating: child / sibling / first_child /<br/>hydrate_next / next(count)<br/>cursor advances through SSR DOM
    Hydrating --> Hydrating: hydrate_template():<br/>cursor enters <template>.content
    Hydrating --> Hydrating: remove_nodes():<br/>depth-aware removal up to <!--]-->
    Hydrating --> BlockExit: reset(anchor):<br/>assert no leftover siblings,<br/>cursor = block end anchor
    BlockExit --> Hydrating: continue outer template
    Hydrating --> Idle: render.js:<br/>verify cursor is <!--]-->,<br/>set_hydrating(false),<br/>restore previous cursor
    Hydrating --> Recovery: set_hydrate_node(null)<br/>or reset() with leftovers
    Recovery --> Idle: warnings.hydration_mismatch()<br/>throw HYDRATION_ERROR →<br/>render.js falls back to mount
```

Components:

| Export | Purpose |
|---|---|
| `hydrating` | Global mode flag. Every DOM-foundation function branches on it. Guarded so hydration code can be treeshaken out when unused. |
| `hydrate_node` | The **cursor**: the node currently being claimed. Sits on block-opening comments when entering blocks (`{#if}`, `{#each}`, …) and on the closing `<!--]-->` when the block ends, which then doubles as the block's runtime anchor. |
| `set_hydrating(v)` / `set_hydrate_node(n)` | State setters. `set_hydrate_node(null)` triggers `hydration_mismatch` and throws the sentinel `HYDRATION_ERROR`. |
| `hydrate_next()` | Advance the cursor to the next sibling — called whenever a claimed node is consumed. |
| `reset(node)` | Exit a block: fail loudly (via warning + `HYDRATION_ERROR`) if unclaimed siblings remain inside the block, then park the cursor on the closing anchor. |
| `next(count)` | Skip `count` siblings without claiming (used for skipped markup such as ignored attributes/comments). |
| `hydrate_template(template)` | Move the cursor *inside* a `<template>` element's `.content` (used by e.g. `<template>`-based blocks). |
| `read_hydration_instruction(node)` | Read the comment payload (`<!--[-->`, `<!--[!=-->`, `<!--]-->`) so block code can branch on which SSR instruction it is standing on. |
| `remove_nodes()` | Depth-aware walk from the cursor that removes all nodes up to the matching end comment, tracking nesting of start/end instructions (used when a hydrated block must be torn down, e.g. hydration recovery or dynamic branch replacement). |

The `<!--[-->` / `<!--]-->` (plus `<!--[!=-->` for else-branches) delimiters are emitted by the server renderer (see [compiler-transformer_server-rendering](compiler-transformer_server-rendering.md) and [server-runtime](server-runtime.md)) and recognized here — this shared vocabulary is the entire SSR/client contract.

### 3.7 Scoped CSS — `append_styles`

```js
export function append_styles(anchor, css /* { hash, code } */)
```

- Runs **inside an `effect()`** so the anchor is guaranteed to be in the DOM when the style root is resolved.
- Resolves the insertion target: if `anchor.getRootNode()` is a `ShadowRoot` (custom elements — see [client-dom-renderer_custom-elements](client-dom-renderer_custom-elements.md)), styles go into the shadow root; otherwise into `document.head`.
- Deduplicates by querying `#<css.hash>` on every call. The code comment explains the deliberate trade-off: always querying performs the same as (or better than) maintaining a cache, with less code.
- In `DEV`, registers inserted `<style>` elements via `dev/css.js::register_style` so HMR can garbage-collect superseded styles with `cleanup_styles` (see [client-dev-tooling](client-dev-tooling.md)).

---

## 4. Process flows

### 4.1 Hydration end-to-end

The sequence below shows how the foundation module participates in `hydrate()` from [client-dom-renderer_lifecycle](client-dom-renderer_lifecycle.md):

```mermaid
sequenceDiagram
    participant App as App code
    participant LC as render.js (lifecycle)
    participant OPS as operations.js
    participant HYD as hydration.js
    participant TPL as template.js
    participant DOM as SSR HTML

    App->>LC: hydrate(Component, { target })
    LC->>OPS: init_operations()
    LC->>DOM: scan for <!--[--> (get_first_child / get_next_sibling)
    LC->>HYD: set_hydrating(true); set_hydrate_node(start); hydrate_next()
    LC->>TPL: component template code runs

    rect rgb(235, 244, 255)
        note over TPL,HYD: claim phase — cursor advances through SSR DOM
        TPL->>HYD: from_html(...)() → assign_nodes(hydrate_node, null)
        TPL->>OPS: child() / sibling() → cursor advances,<br/>missing text nodes synthesized
        TPL->>TPL: text() claims SSR text / comment() claims block anchors
        TPL->>HYD: reset(end_anchor) per block
        TPL->>CSS: append_styles(anchor, css)
    end

    LC->>HYD: assert cursor is <!--]-->
    alt cursor is <!--]-->
        LC->>HYD: set_hydrating(false)
        LC-->>App: component instance
    else mismatch / error
        HYD->>LC: HYDRATION_ERROR (after hydration_mismatch warning)
        LC->>OPS: clear_text_content(target)
        LC->>LC: fallback → mount(Component, options)
    end
```

### 4.2 Mount (no SSR) instantiation

1. `mount()` → `init_operations()`.
2. Template effect executes: `from_html(...)` parses once (or clones from cache), `assign_nodes` records `nodes_start`/`nodes_end` on the effect.
3. `child`/`sibling` are plain pointer reads (no cursor movement — `hydrating` is `false`).
4. Reactive effects created by [client-reactivity-engine](client-reactivity-engine.md) later update text via [client-dom-renderer_attributes-events](client-dom-renderer_attributes-events.md) setters.
5. `append(anchor, dom)` splices the fragment before the parent anchor.

---

## 5. Dependencies

### 5.1 Upstream (what this module consumes)

| Dependency | Used by | Purpose |
|---|---|---|
| `runtime.js::active_effect` | `operations.js`, `template.js` | Current effect to stamp `nodes_start`/`nodes_end`; `should_defer_append` reads its flags. See [client-reactivity-engine](client-reactivity-engine.md). |
| `reactivity/effects.js::effect` | `css.js` | Styles are (re-)inserted inside an effect so DOM membership is guaranteed. |
| `reactivity/batch.js::eager_block_effects`, `flags/index.js::async_mode_flag` | `operations.js` | Append-deferral decision for async `<svelte:boundary>` batching. |
| `reconciler.js::create_fragment_from_html` | `template.js` | `<template>.innerHTML` parsing with `<!>` → `<!---->` normalization. |
| `constants.js` (`TEMPLATE_*`, `HYDRATION_*`, `NAMESPACE_*`) | `template.js`, `hydration.js` | Bit flags and the `<!--[-->` / `<!--]-->` SSR instruction vocabulary. |
| `dev/css.js`, `dev/equality.js`, `warnings.js` | `css.js`, `operations.js`, `hydration.js` | DEV-only HMR style registry, array-method warnings, `hydration_mismatch` diagnostics. See [client-dev-tooling](client-dev-tooling.md). |
| `shared/utils.js` (`get_descriptor`, `is_extensible`) | `operations.js` | Safe prototype getter extraction / slot patching. |

### 5.2 Downstream (who consumes this module)

| Consumer | Usage |
|---|---|
| [client-dom-renderer_lifecycle](client-dom-renderer_lifecycle.md) (`render.js`) | `init_operations`, `clear_text_content`, hydration state setters/walkers, native getters for the `<!--[-->` scan, recovery fallback. |
| [client-dom-renderer_control-flow-blocks](client-dom-renderer_control-flow-blocks.md) | `comment()` anchors for if/each/key/await branches, `child`/`sibling` traversal, `should_defer_append`, `html`/`with_script` for `{@html}`. |
| [client-dom-renderer_attributes-events](client-dom-renderer_attributes-events.md) | Element prototype slots (`__attributes`, `__click`, `__style`, `__className`), `set_attribute`, `set_xlink_attribute` conventions. |
| [client-dom-renderer_bindings](client-dom-renderer_bindings.md), [client-dom-renderer_transitions](client-dom-renderer_transitions.md), [client-dom-renderer_custom-elements](client-dom-renderer_custom-elements.md) | Traversal, cloning, slot patching, shadow-root style insertion via `append_styles`. |
| [compiler-transformer_client-transform](compiler-transformer_client-transform.md) | Emits calls to `$.from_html`/`$.from_tree`/`$.child`/`$.sibling`/`$.text`/`$.comment`/`$.append`/`$.append_styles`/`$.props_id` — the compile-time counterpart of this runtime contract. |
| [server-runtime](server-runtime.md) / [compiler-transformer_server-rendering](compiler-transformer_server-rendering.md) | Emit the matching `<!--[-->`/`<!--]-->` comments, `#uid` comments for `props_id`, and identical template structures consumed by `from_tree`/hydration. |

---

## 6. Key design decisions

1. **One code path, two modes.** Branching on the single `hydrating` flag lets the compiler emit identical template code for mount and hydration, keeping compiled output small and behavior provably symmetric.
2. **Parse once, clone forever.** All template instantiation cost is paid once per component *shape*; per-instance cost is a `cloneNode`/`importNode` plus cursor walks.
3. **Prototype patching over data structures.** Hidden slots on `Element.prototype`/`Text.prototype` (`__attributes`, `__click`, `__t`, …) give O(1) field access for the hot attribute/event paths owned by sibling modules.
4. **Self-healing hydration.** Traversal functions synthesize missing text nodes for empty SSR expressions, so minor SSR/client divergence doesn't abort hydration; genuine mismatches warn (`hydration_mismatch`) and throw the `HYDRATION_ERROR` sentinel, which `render.js` converts into a clean full client mount (`recover !== false`).
5. **Treeshakeability discipline.** `#__NO_SIDE_EFFECTS__` on factories, lazy `init_operations`, and the `hydrating` guard ensure that unused features (hydration, specific template kinds, dev hooks) disappear from production bundles. The treeshakeability of the whole package is verified by the [treeshakeability_checker](treeshakeability_checker.md).
6. **Effect-owned node ranges.** `assign_nodes` binds every created/claimed range to the active effect — the same mechanism [client-reactivity-engine](client-reactivity-engine.md) uses to tear down effects — so DOM removal, transitions and unmounting never need a separate bookkeeping structure.

## 7. See also

- [client-dom-renderer](client-dom-renderer.md) — parent renderer subsystem overview
- [client-dom-renderer_lifecycle](client-dom-renderer_lifecycle.md) — `mount` / `hydrate` / `unmount`, the entry points that drive this module
- [client-dom-renderer_control-flow-blocks](client-dom-renderer_control-flow-blocks.md) — the block system built on these anchors
- [client-dom-renderer_attributes-events](client-dom-renderer_attributes-events.md) — attribute effects & delegated events using the prototype slots
- [client-reactivity-engine](client-reactivity-engine.md) — effects, batches and the `active_effect` this module stamps node ranges onto
- [compiler-transformer_client-transform](compiler-transformer_client-transform.md) — codegen that emits calls into this module
- [server-runtime](server-runtime.md) — the SSR half of the hydration instruction contract
