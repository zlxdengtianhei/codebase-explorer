# Compiler Preprocessor (`packages/svelte/src/compiler/preprocess`)

## 1. Introduction & Purpose

The **compiler-preprocessor** module implements Svelte's source-code preprocessing stage — the *first* hook of the compiler pipeline, executed **before** parsing. It provides the public `svelte.preprocess(source, preprocessor, options)` API that lets the ecosystem (e.g. `svelte-preprocess`, `vite-plugin-svelte`) arbitrarily transform component source *text* before the compiler ever sees it.

Typical use cases:

- Compiling `<script lang="ts">` TypeScript down to JavaScript before the Svelte parser reads it.
- Compiling `<style lang="scss">` / `<style lang="sass">` blocks into vanilla CSS.
- Stripping custom markup syntax or injecting code at the top of a component.

Beyond string replacement, the module's defining responsibility is **source-map fidelity**: every transformation is tracked as a `MappedCode` segment, stitched together, and ultimately folded into a single combined source map (`Processed.map`) that maps the preprocessed output all the way back to the original `.svelte` file. It also aggregates every file a preprocessor declares as `dependencies` (used by bundlers/dev servers for watch-mode invalidation).

```
Input:  "<script lang="ts">let x: number = 1</script>"
Output: { code: "<script>let x = 1</script>", map: <combined sourcemap>, dependencies: [...] }
```

## 2. Position in the Compiler Pipeline

Preprocessing is a purely *lexical* phase: it runs on raw text, before the AST exists, and produces the text that the parser consumes.

```mermaid
flowchart LR
    A[".svelte source file"] --> B["preprocess<br/>(this module)"]
    B --> C["1-parse<br/>compiler-parser"]
    C --> D["2-analyze<br/>compiler-analyzer"]
    D --> E["3-transform<br/>compiler-transformer<br/>(client / server / css)"]
    E --> F["CompileResult"]

    G["PreprocessorGroup<br/>(svelte-preprocess, plugins)"] -.-> B
```

- The `Processed.map` produced here becomes the base source map that later phases build upon, so stack traces and editor tooling still resolve to the user's original code.
- The public type contract consumed by preprocessor authors lives in `public.d.ts` and is re-exported through the top-level type surface (see the `svelte-public-types` module in [Public_API___Built-in_Feature_Surface](Public_API___Built-in_Feature_Surface.md)).

## 3. Architecture Overview

The module consists of two files with a deliberate split between **contract** and **engine**:

```mermaid
flowchart TB
    subgraph public_api["Public API contract — public.d.ts"]
        P1["Processed"]
        P2["MarkupPreprocessor"]
        P3["Preprocessor"]
        P4["PreprocessorGroup"]
        P5["SveltePreprocessor (deprecated)"]
    end

    subgraph engine["Preprocessing engine — index.js"]
        E1["preprocess() entry point"]
        E2["PreprocessResult<br/>(mutable Source state)"]
        E3["process_markup()"]
        E4["process_tag() + process_single_tag()"]
        E5["processed_tag_to_code()/<br/>processed_content_to_code()"]
        E6["parse/stringify_tag_attributes()"]
    end

    subgraph infra["Shared infrastructure (compiler-core)"]
        I1["MappedCode<br/>(compiler/utils/mapped_code.js)"]
        I2["combine_sourcemaps()"]
        I3["replace_in_code() / slice_source()<br/>(preprocess/replace_in_code.js)"]
        I4["decode_map()<br/>(preprocess/decode_sourcemap.js)"]
    end

    P2 & P3 --> P4
    P4 --> E1
    E1 --> E3 & E4
    E3 & E4 --> E2
    E4 --> E6
    E4 --> E5
    E5 --> I1
    E2 --> I2
    I1 --> I3
    P1 --> E5
    I4 --> I1
```

### Key design points

| Concern | Mechanism |
|---|---|
| Mutable intermediate state | `PreprocessResult` implements the internal `Source` interface (`source`, `filename`, `get_location`, `file_basename`) and accumulates `SourceUpdate`s |
| Source-map ordering | Maps are `unshift`ed into `sourcemap_list` (newest first), matching the ordering expected by `combine_sourcemaps` / `@jridgewell/remapping` |
| Tag rewriting | `<script>` / `<style>` tags are located with regexes that skip HTML comments; replacements are built as `MappedCode` chains so open tag, content, and close tag each keep precise mappings |
| Attribute round-trip | Preprocessors may return replacement `attributes`; if the generated open tag's length differs from the original, a synthetic mapping for the open tag is generated so positions still resolve |
| Fast path | If a preprocessor returns nothing, or returns identical code with no map, the original slice is reused via a no-change `MappedCode` |
| Dependencies | `Processed.dependencies` from every preprocessor run is collected and de-duplicated (`Set`) in the final result |

## 4. Core Components

### Engine (`index.js`)

| Component | Kind | Responsibility |
|---|---|---|
| `preprocess` | exported function | Public entry point. Normalizes the `PreprocessorGroup(s)`, then runs each group's `markup` → `script` → `style` hooks in order, threading the evolving source through `PreprocessResult`, and finally produces the `Processed` output |
| `process_single_tag` | internal function | Handles one matched `<script>`/`<style>` tag: parses its attributes, invokes the preprocessor with `{content, attributes, markup, filename}`, handles the no-change fast path, and converts the result into a `MappedCode` replacement |
| `PreprocessResult` | internal class | Intermediate state container (implements `Source`): holds the current `source` string, a `getLocator`-based position locator, the reversed `sourcemap_list`, and accumulated `dependencies`; produces the final `Processed` via `to_processed()` |
| `process_markup` | internal function | Runs a `MarkupPreprocessor` over the whole file content; accepts back code, a raw or JSON-string map, and dependencies |
| `process_tag` | internal function | Scans the current source for all `<style>` or `<script>` tags with dedicated regexes (comment-aware) and applies `replace_in_code` with `process_single_tag` as the replacement factory |
| `processed_tag_to_code` / `processed_content_to_code` | internal functions | Source-map stitching: map the replaced tag content (offset by the tag's location), remap the open tag when generated attributes change its length, and re-attach the original close tag |
| `parse_tag_attributes` / `stringify_tag_attributes` | internal helpers | Round-trip tag attributes between string form and the `Record<string, string \| boolean>` form preprocessors receive |

Detailed documentation: [compiler-preprocessor_engine.md](compiler-preprocessor_engine.md)

### Public contract (`public.d.ts`)

| Type | Responsibility |
|---|---|
| `Processed` | Result of one preprocessor run: `code`, optional `map`, `dependencies`, and (for script/style) replacement `attributes` |
| `MarkupPreprocessor` | Signature for whole-file transforms: `({content, filename}) => Processed \| void` |
| `Preprocessor` | Signature for tag transforms: `({content, attributes, markup, filename}) => Processed \| void` |
| `PreprocessorGroup` | Named bundle of up to three hooks (`markup`, `script`, `style`) — the unit users pass to `svelte.preprocess` |
| `SveltePreprocessor` | **Deprecated** helper type for extracting a typed preprocessor factory; authors should declare it themselves |

Detailed documentation: [compiler-preprocessor_api.md](compiler-preprocessor_api.md)

## 5. Processing Flow

The full lifecycle of one `preprocess()` call:

```mermaid
sequenceDiagram
    participant U as Consumer (bundler/plugin)
    participant PP as preprocess()
    participant PR as PreprocessResult
    participant MG as process_markup
    participant TG as process_tag / process_single_tag
    participant FN as user preprocessor fn
    participant MC as MappedCode infra

    U->>PP: source, PreprocessorGroup(s), {filename}
    PP->>PR: new PreprocessResult(source, filename)

    loop over each PreprocessorGroup
        opt group.markup
            PP->>MG: process(markup, result)
            MG->>FN: {content, filename}
            FN-->>MG: Processed? (code, map, dependencies)
            MG-->>PR: SourceUpdate (string, map, dependencies)
        end
        opt group.script
            PP->>TG: process_tag('script', fn, result)
            TG->>FN: {content, attributes, markup, filename}
            FN-->>TG: Processed?
            TG->>MC: processed_tag_to_code → MappedCode
            TG-->>PR: SourceUpdate
        end
        opt group.style
            PP->>TG: process_tag('style', fn, result)
            TG-->>PR: SourceUpdate
        end
    end

    PP->>PR: to_processed()
    PR->>MC: combine_sourcemaps(file_basename, sourcemap_list)
    PR-->>U: Processed {code, map, dependencies}
```

### Tag replacement & map stitching detail

For every `<script>`/`<style>` tag that changes:

1. `slice_source` creates a sub-`Source` whose locator is offset by the tag position.
2. The replacement is assembled as three `MappedCode` segments: open tag → content → close tag, then concatenated (`.concat` merges mappings, sources, and names in place).
3. Content mappings coming from the preprocessor's own map are decoded (`decode_map`) and shifted by the tag's location via `sourcemap_add_offset` — but only for segments that point at the original component file, leaving mappings into imported files untouched.
4. If the preprocessor returned replacement `attributes` with a different length than the original, a hand-built mapping for the open tag preserves positional fidelity.
5. `parse_attached_sourcemap` honors inline `sourceMappingURL` comments returned by the preprocessor.

```mermaid
flowchart LR
    T["matched tag slice<br/>&lt;style lang=scss&gt;...&lt;/style&gt;"] --> A{"changed?"}
    A -- "no / fast path" --> N["identity MappedCode<br/>via slice_source"]
    A -- yes --> B["build open-tag code<br/>(identity or synthetic map)"]
    B --> C["content code<br/>decode_map + sourcemap_add_offset"]
    C --> D["close-tag code<br/>(identity map)"]
    D --> E["MappedCode.concat chain"]
    E --> F["replace_in_code<br/>splices result into source"]
    F --> G["SourceUpdate → PreprocessResult"]
```

## 6. Sub-module Documentation

This module is split into two documented sub-modules:

| Sub-module | File | Contents |
|---|---|---|
| Public API contract | [compiler-preprocessor_api.md](compiler-preprocessor_api.md) | `Processed`, `MarkupPreprocessor`, `Preprocessor`, `PreprocessorGroup`, `SveltePreprocessor` |
| Preprocessing engine | [compiler-preprocessor_engine.md](compiler-preprocessor_engine.md) | `preprocess`, `process_single_tag` and the internal machinery (`PreprocessResult`, `process_markup`, `process_tag`, map stitching) |

## 7. Relationships to Other Modules

- **[compiler-core](compiler-core.md)** — supplies the shared source-map infrastructure this module builds on: `MappedCode`, `combine_sourcemaps`, `sourcemap_add_offset`, `parse_attached_sourcemap`, `get_basename` (`compiler/utils/mapped_code.js`), plus diagnostics/builders used across the compiler.
- **[compiler-parser](compiler-parser.md)** — the direct downstream consumer: the `Processed.code` output becomes the input text for `parse()` in `phases/1-parse`; the combined `Processed.map` seeds the source-map chain used by later phases.
- **[compiler-migrator](compiler-migrator.md)** — sibling tooling that also consumes raw Svelte source; `extract_svelte_ignore.migrate_svelte_ignore` (compiler-core) complements preprocessing-era `<!-- svelte-ignore -->` migration.
- **[Public_API___Built-in_Feature_Surface](Public_API___Built-in_Feature_Surface.md)** — re-exports the preprocessing types (`Processed_1`, `SveltePreprocessor_1` in `packages/svelte/types/index.d.ts`) as the stable public API surface.

## 8. Usage Sketch

```js
import { preprocess } from 'svelte/compiler';

const { code, map, dependencies } = await preprocess(
  source,
  [
    {
      name: 'typescript',
      async script({ content, attributes }) {
        if (attributes.lang !== 'ts') return;
        const { code, map, dependencies } = await compileTypeScript(content);
        return { code, map, dependencies, attributes: { ...attributes, lang: 'js' } };
      }
    },
    {
      name: 'sass',
      async style({ content, attributes }) {
        if (attributes.lang !== 'scss') return;
        return sass.compileString(content, { sourceMap: true }); // { code, map }
      }
    }
  ],
  { filename: 'src/App.svelte' }
);
```

Returning `undefined`/nothing signals "unchanged" — the original text (and mappings) are preserved. Returning `{ code }` with no map yields an identity-mapped result; returning a map enables accurate back-tracing to the original file.
