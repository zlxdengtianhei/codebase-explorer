# reactive-builtins_collections

## 1. Overview

`reactive-builtins_collections` is the submodule of the [reactive-builtins](reactive-builtins.md) family (itself part of the [Public_API___Built-in_Feature_Surface](public-api.md)) that provides **reactive collection types**. Its single core component is:

| Component | Location | Public export |
|---|---|---|
| `SvelteMap` | `packages/svelte/src/reactivity/map.js` | `import { SvelteMap } from 'svelte/reactivity'` |

`SvelteMap` is a drop-in subclass of the built-in [`Map`](https://developer.mozilla.org/en-US/docs/Web-JavaScript/Reference/Global_Objects/Map) whose reads (`get`, `has`, `size`, iteration) are wired into Svelte's signal graph. Any [effect](client-reactivity-engine_effects.md) or [derived](client-reactivity-engine_deriveds-and-async.md) that reads the map re-runs automatically when the map is mutated — without the consumer needing `$state` wrapping, `.snapshot()`, or store plumbing.

It is the collection-oriented sibling of the other reactive built-ins:

- [reactive-builtins_temporal](reactive-builtins_temporal.md) — `SvelteDate`
- [reactive-builtins_url](reactive-builtins_url.md) — `SvelteURL`, `SvelteURLSearchParams`
- [reactive-builtins_media-query](reactive-builtins_media-query.md) — `MediaQuery`, `createSubscriber`

### Key design properties

1. **Subclass, not proxy.** Unlike `$state` objects (which are wrapped in `Proxy`es by the [sources-and-proxies engine](client-reactivity-engine_sources-and-proxies.md)), `SvelteMap` extends `Map` and overrides its methods. This is the only reliable way to intercept `Map` internals (the internal slots of `Map`/`Set` are not proxy-observable).
2. **Fine-grained per-key signals.** Each key gets its own `Source<number>` signal, created *lazily* on first read. Reading `map.get('a')` does not create dependencies on key `'b'`.
3. **Coarse structural signals.** A `#version` signal covers structural/full reads (iteration, `keys()`, reads of missing keys); a `#size` signal serves `size`.
4. **Shallow by design.** Values are *not* made deeply reactive; mutating an object stored in the map does not trigger reactivity (only key-level mutations do).

---

## 2. Architecture

### 2.1 Context diagram

`SvelteMap` is a thin adapter layer that composes three primitives of the client reactivity engine — `source`/`state` signals, the `get()` dependency-tracking read, and `set()`/`increment()` writes — around a native `Map`:

```mermaid
graph TB
    subgraph Public["Public API surface"]
        IDX["svelte/reactivity<br/>index-client.js"]
    end

    subgraph Module["reactive-builtins_collections"]
        SM["SvelteMap extends Map<br/><i>packages/svelte/src/reactivity/map.js</i>"]
    end

    subgraph Engine["Client reactivity engine"]
        SRC["sources.js<br/>source / state / set / increment"]
        RT["runtime.js<br/>get / update_version"]
        TRC["dev/tracing.js<br/>tag / label"]
    end

    ENV["esm-env<br/>DEV flag"]

    IDX -->|"export { SvelteMap }"| SM
    SM -->|"create / write signals"| SRC
    SM -->|"track reads, capture update_version"| RT
    SM -->|"DEV-only labels"| TRC
    SM -.->|"compile-time flag"| ENV
    SRC --> RT
```

### 2.2 Import dependency graph

```mermaid
graph LR
    MAP["map.js<br/>(SvelteMap)"] -->|"set, source, state, increment"| SOURCES["internal/client/reactivity/sources.js"]
    MAP -->|"get, update_version (live binding)"| RUNTIME["internal/client/runtime.js"]
    MAP -->|"tag, label"| TRACING["internal/client/dev/tracing.js"]
    MAP -->|"DEV"| ESMENV["esm-env"]
    SOURCES --> RUNTIME
```

Detail on the engine primitives used (see [client-reactivity-engine_signal-graph](client-reactivity-engine_signal-graph.md) for the full picture):

| Primitive | Source file | Role in `SvelteMap` |
|---|---|---|
| `source(v)` | `sources.js` | Creates a plain tracked signal used for per-key counters (when created *outside* the owning reaction). |
| `state(v)` | `sources.js` | `source(v)` + `push_reaction_value(v)` — used for per-key counters (and `#version` / `#size`) created *inside* the same reaction as the map, so they are excluded from that reaction's dependency set and cannot self-trigger it. |
| `set(signal, value)` | `sources.js` | Guarded write; throws `state_unsafe_mutation` if invoked inside a derived/block effect while reacting. |
| `increment(signal)` | `sources.js` | `set(signal, signal.v + 1)` — bumps a version counter to dirty all reactions subscribed to that signal. |
| `get(signal)` | `runtime.js` | Read that registers `active_reaction` as a dependency of the signal (classic push–pull dependency tracking). |
| `update_version` | `runtime.js` | Module-level live binding; snapshot-compared per instance to decide `state` vs `source` (see [§5](#5-the-statesource-selection--update_version)). |
| `tag(signal, label)`, `label(value)` | `dev/tracing.js` | DEV-mode signal labels for the Svelte devtools / trace views (see [client-dev-tooling_state-inspection](client-dev-tooling_state-inspection.md)). |

### 2.3 Internal signal layout

Each `SvelteMap` instance carries three layers of signals **plus** the native `Map` storage:

```mermaid
graph TB
    subgraph SM["SvelteMap instance"]
        NATIVE["native Map storage<br/>(super.get / super.set …)"]
        subgraph SIGNALS["per-instance signals"]
            SRCMAP["#sources : Map&lt;K, Source&lt;number&gt;&gt;<br/><i>lazy, one counter per key</i>"]
            VER["#version : Source&lt;number&gt;<br/><i>structural / full-read counter</i>"]
            SIZE["#size : Source&lt;number&gt;<br/><i>mirrors map cardinality</i>"]
        end
        UV["#update_version : number<br/><i>snapshot of runtime update_version<br/>taken at construction</i>"]
    end

    SRCMAP -->|"one Source per key"| K1["K₁ → counter"] 
    SRCMAP --> K2["K₂ → counter"]
    SRCMAP --> KN["Kₙ → counter"]

    NATIVE <-->|"kept in sync by set/delete/clear"| SIZE
    NATIVE <-->|"keys / values"| SRCMAP
```

**Invariant:** after a full read (`#read_all`), `#sources.size === native size === #size.v`. The mismatch check `#size.v !== sources.size` in `#read_all` is what triggers (re)population of per-key sources, e.g. after construction-with-initial-values or after untracked mutations.

---

## 3. Component reference — `SvelteMap`

```
class SvelteMap<K, V> extends Map<K, V>
```

### 3.1 Private state

| Member | Type | Purpose |
|---|---|---|
| `#sources` | `Map<K, Source<number>>` | Lazily-created counter signal per key. Counters are *not* values — the value always comes from the native map; the counter only needs to *change* to invalidate readers. |
| `#version` | `Source<number>` | Coarse-grained counter. Read by `keys()`, by reads of *missing* keys (so a later insertion still invalidates them), and by all full iterations. |
| `#size` | `Source<number>` | Counter mirrored to `super.size`; read by the `size` getter. |
| `#update_version` | `number` | Snapshot of the global `update_version` at construction; used by `#source()` to pick `state` vs `source`. |
| `#source(value)` | `(T) => Source<T>` | Factory choosing `state()` or `source()` per [§5](#5-the-statesource-selection--update_version). |
| `#read_all()` | `() => void` | Tracks a full read: bumps `#version`, backfills missing per-key sources, and `get()`s every one of them. |

### 3.2 Public surface (override matrix)

| Member | Kind | Tracking behaviour |
|---|---|---|
| `constructor(value?)` | method | Seeds the native map directly via `super.set` (no signals fired); initializes `#size.v = super.size`. In DEV, wraps the argument in a native `Map` so an invalid iterable throws the *native* error, and tags `#version` / `#size` for devtools. |
| `get(key)` | read | Per-key: reads/creates `#sources.get(key)`; **missing key** → tracks `#version` instead and returns `undefined`. |
| `has(key)` | read | Same tracking scheme as `get`, returns `boolean`. |
| `size` | read | Tracks `#size`. |
| `keys()` | read | Tracks `#version` only (key structure, not values). |
| `values()` / `entries()` / `[Symbol.iterator]` | read | Full read via `#read_all()` (version + every per-key source). |
| `forEach(cb, thisArg)` | read | Full read via `#read_all()`, then delegates to `super.forEach`. |
| `set(key, value)` | write | Per-key increment, conditional version increment, size sync — see [§4.2](#42-write-path--set). |
| `delete(key)` | write | Removes the native entry, drops the per-key source, syncs `#size`, poisons the counter with `-1`, increments `#version`. |
| `clear()` | write | Early-returns when empty; clears the native map *first* (so `$inspect`/console output looks right), syncs `#size`, poisons every per-key counter, increments `#version`, then clears `#sources`. |

> **Why `-1`?** Per-key signals hold monotonically increasing counters starting at `0`. `delete`/`clear` write the sentinel `-1` via `set(s, -1)` purely to guarantee the counter *changes*, dirtying reactions. Any later `set(key, …)` recreates a fresh source because the stale entry was removed from `#sources`.

---

## 4. Data flow

### 4.1 Read path (`get` / `has`)

```mermaid
flowchart TD
    A["get(key) / has(key)"] --> B{"#sources has key?"}
    B -->|"no"| C["super.get(key) !== undefined?"]
    C -->|"value exists"| D["create source via #source(0)<br/>(DEV: tag with 'SvelteMap get(key)')<br/>store in #sources"]
    C -->|"missing"| E["get(#version)<br/>track structural signal"] --> F["return undefined / false"]
    D --> G["get(s) → registers active_reaction<br/>as dependency of the per-key counter"]
    B -->|"yes"| G
    G --> H["return super.get(key) / true"]
```

Notes:

- **Missing-key reads track `#version`** ("We should always track the version in case the Map ever gets this value in the future"). This is what makes `board.has(i) → false` followed by `board.set(i, …)` correctly re-run a waiting effect — even though no per-key signal existed for that key at read time.
- Signals are created **lazily** — a map with 100k untouched keys holds zero per-key sources.

### 4.2 Write path (`set`)

```mermaid
flowchart TD
    A["set(key, value)"] --> B["s = #sources.get(key)<br/>prev = super.get(key)<br/>super.set(key, value)"]
    B --> C{"s === undefined<br/>(new key, or read never happened<br/>/ was deleted)"}
    C -->|"yes"| D["create + register fresh source<br/>set(#size, super.size)<br/>increment(#version)"]
    C -->|"no"| E{"prev !== value?"}
    E -->|"no"| F["no-op — no signals touched<br/>(identity-equal write is free)"]
    E -->|"yes"| G["increment(s)"]
    G --> H{"every reaction of s is<br/>also a reaction of #version?"}
    H -->|"yes (subset)"| I["done — fine-grained readers<br/>covered by s alone"]
    H -->|"no"| J["increment(#version)<br/>safety net for coarse readers"]
    D --> K["return res"]
    I --> K
    J --> K
```

Key mechanics:

1. **New key** → version *and* size must change, because structural readers (`keys()`, size readers, previous missing-key readers) are affected.
2. **Value change on a tracked key** → only the per-key counter is incremented. The global `#version` is additionally bumped **only when some subscriber of the per-key signal does not also subscribe to `#version`** — an over-invalidation guard keeping coarse-grained readers correct while letting pure `get(key)`-style effects stay untouched by unrelated structural churn.
3. **Same-value writes** (`prev === value`, strict `!==` comparison) touch no signals at all.
4. `set()` delegates to the engine's guarded `set()`, so mutating a map *inside a derived or block effect* still raises the standard `state_unsafe_mutation` error (see [client-reactivity-engine_sources-and-proxies](client-reactivity-engine_sources-and-proxies.md)).

### 4.3 Delete / clear

`delete(key)`:

```mermaid
sequenceDiagram
    participant R as Reaction (effect/derived)
    participant SM as SvelteMap
    participant SIG as per-key Source
    participant V as #version
    R->>SM: delete(key)
    SM->>SM: super.delete(key)
    SM->>SM: #sources.delete(key)
    SM->>SIG: set(s, -1)  (dirty readers of this key)
    SM->>SM: set(#size, super.size)
    SM->>V: increment(#version)
    Note over R: scheduled → batched flush<br/>(client-reactivity-engine_batching-scheduling)
```

`clear()` performs the same invalidation en masse: `#size → 0`, every existing per-key counter set to `-1`, one `increment(#version)`, then `#sources.clear()`.

### 4.4 Full read (`#read_all`)

Used by `forEach`, `values`, `entries` and the spread/iteration protocol (`[Symbol.iterator]`):

1. `get(#version)` — subscribe to structural changes.
2. If `#size.v !== #sources.size` (e.g. first full read after seeding the constructor, or reads occurred while untracked), backfill missing per-key sources from `super.keys()`.
3. `get(s)` for every source — subscribe to every value.

`keys()` deliberately reads **only** `#version`: key order changes on delete/re-insert, but pure value changes need not re-run a `keys()` consumer.

### 4.5 End-to-end invalidation sequence

```mermaid
sequenceDiagram
    autonumber
    participant Eff as Effect
    participant SM as SvelteMap
    participant SIG as Source(counter)
    participant Bat as Batch / scheduler

    Eff->>SM: map.get('a')
    SM-->>SIG: get(s) → Eff registered in s.reactions
    Note over Eff: render / derive with current value
    App->>SM: map.set('a', newValue)
    SM->>SIG: increment(s)
    SIG-->>Bat: reactions marked dirty
    Bat->>Eff: scheduled → re-run
    Eff->>SM: map.get('a')
    SM-->>Eff: newValue (native storage)
```

---

## 5. The state/source selection — `update_version`

The private `#source()` factory decides *how* a new signal is born:

```js
#source(value) {
    return update_version === this.#update_version ? state(value) : source(value);
}
```

- `#update_version` snapshots the module-level `update_version` live-binding (from `runtime.js`) **at instance construction**.
- If, later, a signal is created while the global `update_version` still equals that snapshot, the map instance and the new signal share "the same reaction epoch" → use `state()`, which registers the signal in `current_sources`. Sources in `current_sources` do **not** become dependencies of, and cannot re-trigger, the reaction that created them (see `push_reaction_value` in [client-reactivity-engine_signal-graph](client-reactivity-engine_signal-graph.md)).
- Otherwise → plain `source()`, which *is* trackable by whatever reaction reads it next.

Practical consequence: code that creates **and** mutates a `SvelteMap` inside the same effect does not cause infinite re-run loops. `#version` and `#size` always use `state()` at construction time for the same reason.

---

## 6. Environment-specific behaviour

### 6.1 Client (reactive implementation)

Full implementation above; exported from `index-client.js` and re-exported by the public `svelte/reactivity` entry point.

### 6.2 Server (SSR — zero-cost alias)

```js
// packages/svelte/src/reactivity/index-server.js
export const SvelteMap = globalThis.Map;
```

Under server-side rendering the binding is aliased to the **native `Map`**. SSR renders once with no reactive graph and no post-render mutations, so per-key signals would be pure overhead. The API surface (constructor, `get`/`set`/`has`/`size`, iteration) is identical, so component code needs no conditional imports. The same aliasing strategy is applied to `SvelteDate`, `SvelteSet`, `SvelteURL` and `SvelteURLSearchParams` — see [reactive-builtins_temporal](reactive-builtins_temporal.md), [reactive-builtins_url](reactive-builtins_url.md) and the SSR pipeline in [server-runtime_render-pipeline](server-runtime_render-pipeline.md).

### 6.3 DEV-mode diagnostics

When `esm-env`'s `DEV` flag is set:

- The constructor argument is normalized through a native `new Map(value)` so invalid iterables throw the **native** exception rather than a confusing signal-layer error.
- `tag(signal, 'SvelteMap version' | 'SvelteMap.size' | 'SvelteMap get(<label(key)>)')` attaches devtools labels; `label()` renders keys readably (`Symbol(description)`, `<function>`, `<object>`, or `String(value)`). Covered in [client-dev-tooling_state-inspection](client-dev-tooling_state-inspection.md).

---

## 7. Usage

Classic tic-tac-toe scenario from the JSDoc — note how `board.has(i)`, `board.get(i)` and the `result(board)` derived each establish precise dependencies:

```svelte
<script>
    import { SvelteMap } from 'svelte/reactivity';
    import { result } from './game.js';

    let board = new SvelteMap();
    let player = $state('x');
    let winner = $derived(result(board)); // iterates → full-read tracking

    function reset() {
        player = 'x';
        board.clear(); // one version bump dirties every reader
    }
</script>

{#each Array(9), i}
    <button
        disabled={board.has(i) || winner}
        onclick={() => {
            board.set(i, player);
            player = player === 'x' ? 'o' : 'x';
        }}
    >{board.get(i)}</button>
{/each}
```

Behavioural caveats worth documenting for consumers:

- **Shallow reactivity**: `map.set(k, obj); obj.field = 1;` does *not* notify — re-`set` the key (a different object identity) to trigger.
- **Identity-based change detection** for existing keys (`prev !== value`).
- **Safe inside effects**: creating/mutating within the creating reaction is loop-safe thanks to `state`/`current_sources` ([§5](#5-the-statesource-selection--update_version)), but mutating during a *derived* evaluation is an error (`state_unsafe_mutation`).
- `SvelteMap` is **not** a store: do not pass it to `$`-prefixed auto-subscription; read its methods directly in templates/effects.

---

## 8. Testing & quality

- Unit coverage lives next to the implementation in `packages/svelte/src/reactivity/map.test.ts` (constructor seeding, tracking of reads, deletion/clear invalidation, iteration).
- Treeshakeability of the export is guarded by `packages/svelte/scripts/check-treeshakeability.js` (see [treeshakeability_checker](treeshakeability_checker.md)); reactivity performance envelopes for the underlying signal machinery are tracked by the kairo/sbench suites in [reactivity_benchmarks](reactivity_benchmarks.md).

## 9. Related documentation

| Topic | Document |
|---|---|
| Parent module (all reactive built-ins) | [reactive-builtins](reactive-builtins.md) |
| `SvelteDate` | [reactive-builtins_temporal](reactive-builtins_temporal.md) |
| `SvelteURL` / `SvelteURLSearchParams` | [reactive-builtins_url](reactive-builtins_url.md) |
| `MediaQuery` / `createSubscriber` | [reactive-builtins_media-query](reactive-builtins_media-query.md) |
| Signal graph, `get`/dependency tracking | [client-reactivity-engine_signal-graph](client-reactivity-engine_signal-graph.md) |
| `source`/`state`/`set`/proxies | [client-reactivity-engine_sources-and-proxies](client-reactivity-engine_sources-and-proxies.md) |
| Batching & scheduling of invalidations | [client-reactivity-engine_batching-scheduling](client-reactivity-engine_batching-scheduling.md) |
| Equality semantics backing no-op writes | [client-reactivity-engine_foundation](client-reactivity-engine_foundation.md) |
| DEV tracing/labels | [client-dev-tooling_state-inspection](client-dev-tooling_state-inspection.md) |
| SSR rendering context | [server-runtime_render-pipeline](server-runtime_render-pipeline.md) |
| Public entry points | [public-api](public-api.md) |
