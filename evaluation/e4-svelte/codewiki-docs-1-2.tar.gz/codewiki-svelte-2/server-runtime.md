# Server Runtime (SSR)

> **Module location:** `packages/svelte/src/internal/server/`
> **Sibling modules:** [context-api](context-api.md) · [internal-shared-utils](internal-shared-utils.md)
> **Parent group:** Server-Side Rendering & Cross-Target Runtime Services

---

## 1. Overview & Purpose

The **server-runtime** module is the execution engine for Svelte components on the server. When a component is compiled with `generate: 'server'` (the Compiler Pipeline emits a plain JavaScript function instead of a reactive component class), that function needs a set of primitives to turn the component tree into HTML **synchronously**. This module provides those primitives:

- **`render(component, options)`** – the entry point that executes a compiled component and produces `{ head, html, body }`.
- **HTML emission primitives** – `element`, `await_block`, `css_props`, `head`, `html`, `createRawSnippet`, etc.
- **Attribute & prop serialization** – `attr_class`, `attr_style`, `spread_attributes`, `spread_props`, `stringify`, `rest_props`, `sanitize_props`, `bind_props`.
- **Slot / snippet dispatch** – `slot`, `sanitize_slots`, `createRawSnippet`.
- **Store integration** – simulated one-shot subscriptions (`store_get`, `store_mutate`, `update_store*`, `unsubscribe_stores`) so the legacy store contract works without reactivity.
- **Output buffering** – the `Payload` / `HeadPayload` classes that accumulate HTML fragments, CSS, `<title>` and scoped-IDs.
- **Dev-mode diagnostics** – HTML-tree validation (`push_element` / `pop_element`), snippet argument validation, and abort-signal handling for async work.

Unlike the client runtime (see [client-reactivity-engine](client-reactivity-engine.md) and [client-dom-renderer](client-dom-renderer.md)), there is **no reactivity, no scheduling and no DOM** — every primitive appends strings to a buffer and returns.

---

## 2. Position in the Overall System

```mermaid
flowchart TB
    subgraph Compile["Compiler Pipeline &amp; Language Toolchain"]
        C1["compiler (generate: 'server')"]
    end
    subgraph Public["Public API &amp; Built-in Feature Surface"]
        P1["index-server.js<br/>render / hydrate / mount / unmount"]
    end
    subgraph Sibling["Sibling modules (this group)"]
        CTX["context-api<br/>push / pop / current_component"]
        SHARED["internal-shared-utils<br/>noop, is_promise, validate, snapshot"]
    end
    subgraph THIS["server-runtime (this module)"]
        R["render() pipeline<br/>+ emission primitives"]
    end
    subgraph Consumers["Consumers"]
        F["Frameworks (e.g. SvelteKit)<br/>SSR responses"]
    end

    C1 -->|"emits compiled component<br/>calling $$runtime primitives"| R
    P1 -->|"re-exports render()"| R
    CTX -->|"component context stack"| R
    SHARED -->|"attribute / validation helpers"| R
    R -->|"RenderOutput {head, body}"| F
```

**Key relationships:**

| Dependency | What server-runtime uses it for |
|---|---|
| [context-api](context-api.md) | `push` / `pop` manage the `current_component` stack; `pop` feeds `onDestroy` callbacks into `on_destroy`, which `render()` drains. |
| [internal-shared-utils](internal-shared-utils.md) | `noop`, `is_promise`, `run`, `fallback`, `to_array`, `snapshot`, plus shared validators (`validate_dynamic_element_tag`, `validate_void_dynamic_element`, `invalid_default_snippet`). |
| `../shared/attributes.js` | `attr`, `clsx`, `to_class`, `to_style` – the low-level serialization used by `attr_class` / `attr_style` / `spread_attributes`. |
| `../../escaping.js` | `escape_html` – content & attribute escaping. |
| `../../utils.js` | `is_void`, `is_raw_text_element`, `is_boolean_attribute`, `hash`. |
| `../../html-tree-validation.js` | Parent/ancestor tag rules used by dev-mode `push_element`. |
| `../../store/utils.js` | `subscribe_to_store` – one-shot store subscription. |
| `../server/hydration.js` | `BLOCK_OPEN` / `BLOCK_CLOSE` / `BLOCK_OPEN_ELSE` / `EMPTY_COMMENT` markers that let the client runtime match server output during hydration. |

---

## 3. Architecture

### 3.1 File map

| File | Responsibility |
|---|---|
| `index.js` | The main API surface: `render`, `element`, `head`, `css_props`, `await_block`, attribute/prop helpers, slot dispatch, store helpers. Also re-exports from the other files. |
| `payload.js` | `Payload` / `HeadPayload` output buffers, payload copy/assign, unique-ID generator. |
| `types.d.ts` | `Component` and `RenderOutput` type contracts. |
| `dev.js` | Dev-mode element-stack validation (`push_element`, `pop_element`, `reset_elements`), `validate_snippet_args`. |
| `abort-signal.js` | Single `AbortController` per render; `getAbortSignal` / `abort` for async reactions. |
| `blocks/html.js` | `{@html ...}` block emission with dev-mode hash comments. |
| `blocks/snippet.js` | `createRawSnippet` – programmatic snippets whose `render()` output is pushed to the payload. |

### 3.2 Internal dependency graph

```mermaid
flowchart LR
    subgraph SR["server-runtime"]
        IDX["index.js<br/>(render + primitives)"]
        PAY["payload.js<br/>Payload / HeadPayload"]
        TYPES["types.d.ts<br/>RenderOutput"]
        DEV["dev.js"]
        SIG["abort-signal.js"]
        HTML["blocks/html.js"]
        SNIP["blocks/snippet.js"]
    end

    IDX -->|"buffers HTML / collects css"| PAY
    IDX -->|"contract of return value"| TYPES
    IDX -->|"reset_elements() guard, element checks"| DEV
    IDX -->|"finally: abort()"| SIG
    IDX -->|"re-export html"| HTML
    SNIP -->|"payload.out.push"| PAY
    DEV -->|"injects error script"| PAY
```

### 3.3 Render sequence

```mermaid
sequenceDiagram
    autonumber
    participant App as Framework (SvelteKit)
    participant R as render()
    participant P as Payload
    participant C as Compiled component fn
    participant X as on_destroy cleanups

    App->>R: render(component, { props, context, idPrefix })
    R->>P: new Payload(idPrefix?)
    R->>R: swap on_destroy = []
    R->>P: out.push(BLOCK_OPEN)
    opt DEV
        R->>R: reset_elements() (isolate element stack)
    end
    opt options.context
        R->>R: push() + attach context Map
    end
    R->>C: component(payload, props, {}, {})
    C-->>P: out.push("<div>…</div>"), head.out.push(...), css.add(...)
    opt options.context
        R->>R: pop()
    end
    R->>P: out.push(BLOCK_CLOSE)
    R->>X: run every collected cleanup
    R->>R: head = head.out.join('') + title + <style> per css entry
    R-->>App: { head, html: body, body }
    Note over R: finally: abort() – cancels any<br/>pending async reaction signal
```

---

## 4. Sub-modules

Detailed documentation for each area lives in its own file:

| Sub-module | File | Contents |
|---|---|---|
| [server-runtime_render-pipeline](server-runtime_render-pipeline.md) | `index.js` | `render`, `head`, `element`, `await_block`, `css_props`, `valueless_option`, `maybe_selected`, `ensure_array_like` – orchestration and block emission. |
| [server-runtime_payload-and-output](server-runtime_payload-and-output.md) | `payload.js`, `types.d.ts` | `Payload`/`HeadPayload`, `copy_payload`, `assign_payload`, `props_id_generator`, `props_id`, `RenderOutput`. |
| [server-runtime_attributes-and-props](server-runtime_attributes-and-props.md) | `index.js` | `attr_class`, `attr_style`, `spread_attributes`, `spread_props`, `stringify`, `rest_props`, `sanitize_props`, `bind_props`. |
| [server-runtime_slots-snippets-and-blocks](server-runtime_slots-snippets-and-blocks.md) | `index.js`, `blocks/*` | `slot`, `sanitize_slots`, `createRawSnippet`, `html`. |
| [server-runtime_store-integration](server-runtime_store-integration.md) | `index.js` | `store_get`/`store_set`/`store_mutate`, `update_store`, `update_store_pre`, `unsubscribe_stores`, `derived`, `once`. |
| [server-runtime_dev-diagnostics](server-runtime_dev-diagnostics.md) | `dev.js`, `abort-signal.js` | `push_element`, `pop_element`, `reset_elements`, `validate_snippet_args`, `getAbortSignal`, `abort`. |

---

## 5. Export Catalog (by concern)

### Orchestration
| Export | Purpose |
|---|---|
| `render(component, options)` | Executes a compiled server component; returns `RenderOutput`. Swaps/restores `on_destroy`, wraps output in hydration markers, collects head/CSS, always `abort()`s in `finally`. |
| `head(payload, fn)` | Routes content into `payload.head.out` wrapped in block markers. |
| `element(payload, tag, attributes_fn, children_fn)` | Emits `<tag …>` respecting void elements, raw-text elements, and `<!---->` separators. |
| `await_block(payload, promise, pending_fn, then_fn)` | Synchronous `{:await}` – renders the pending branch if the value is a promise, otherwise the `then` branch immediately. |

### Attributes & props
| Export | Purpose |
|---|---|
| `attr_class(value, hash, directives)` / `attr_style(value, directives)` | Serialized `class=` / `style=` strings (empty string if nothing to emit). |
| `spread_attributes(attrs, css_hash, classes, styles, flags)` | Full attribute serialization: merges styles/classes, skips functions, `$$`-prefixed keys and invalid names; lowercases unless `ELEMENT_PRESERVE_ATTRIBUTE_CASE`. |
| `spread_props(props[])` | Merges objects preserving property descriptors (getters survive). |
| `rest_props(props, rest)` | Everything except the listed keys. |
| `sanitize_props(props)` | Strips `children` / `$$slots` before props are forwarded. |
| `bind_props(props_parent, props_now)` | Legacy two-way binding: pushes fallback values up to the parent when the parent prop was `undefined` and has a setter. |
| `stringify(value)` | Template-stringification (`null`/`undefined` → `''`). |

### Slots & snippets
| Export | Purpose |
|---|---|
| `slot(payload, $$props, name, slot_props, fallback_fn)` | Invokes the matching snippet from `$$props.$$slots` (with `true` → `children` interop) or renders the fallback. |
| `sanitize_slots(props)` | Boolean map of which slots a caller provided. |
| `createRawSnippet(fn)` (blocks/snippet.js) | Wraps a `{ render, setup? }` factory into a `Snippet` compatible with server rendering. |
| `html(value)` (blocks/html.js) | `{@html}` emission wrapped in comments; in DEV the opening comment carries a `hash` so hydration can verify content. |

### Stores (legacy contract)
| Export | Purpose |
|---|---|
| `store_get(store_values, name, store)` | Validates (DEV), caches `[store, unsubscribe, value]`, subscribes once. |
| `store_set` / `store_mutate` / `update_store` / `update_store_pre` | Assign / `$store = expr` / postfix & prefix `++`/`--` semantics. |
| `unsubscribe_stores(store_values)` | Called at the end of a component to release subscriptions. |

### IDs, CSS & selection helpers
| Export | Purpose |
|---|---|
| `props_id(payload)` | Emits `<!--#sN-->` and returns the uid (scoped-ID chaining across component boundaries). |
| `css_props(payload, is_html, props, component, dynamic)` | Emits `<svelte-css-wrapper style="display: contents; …">` (or `<g>` in SVG) around children. |
| `valueless_option(payload, children)` | Buffers `<option>` children and retro-tags the parent tag with ` selected` when the body equals `payload.select_value`. |
| `maybe_selected(payload, value)` | Returns `' selected'` when the value matches `payload.select_value`. |
| `ensure_array_like(x)` | Normalizes iterables to arrays for `{#each}`. |

### Re-exports (public within the internal package)
`FILENAME`, `HMR`, `attr`, `clsx`, `html`, `push`, `pop`, `push_element`, `pop_element`, `validate_snippet_args`, `assign_payload`, `copy_payload`, `snapshot`, `fallback`, `to_array`, `invalid_default_snippet`, `validate_dynamic_element_tag`, `validate_void_dynamic_element`, `prevent_snippet_stringification`, `escape`, `await_outside_boundary`, `inspect`.

---

## 6. Cross-Cutting Behaviors & Conventions

1. **Everything is synchronous.** The compiled component pushes strings into `payload.out`; there are no effects, signals or microtasks. `await_block` renders whichever branch is immediately renderable.
2. **Hydration markers.** Output is bracketed with `BLOCK_OPEN`/`BLOCK_CLOSE` comments; every block boundary uses `<!---->` (`EMPTY_COMMENT`) separators so the client runtime can walk the DOM and pair segments one-to-one (see [client-dom-renderer](client-dom-renderer.md)).
3. **Single abort scope.** `getAbortSignal()` hands out one `AbortController` signal per render; async reactions register on it, and `render()`'s `finally` calls `abort()` with `STALE_REACTION` so late resolutions are discarded and cannot leak into the next render.
4. **`on_destroy` lifecycle.** `render()` swaps the module-level `on_destroy` array; `pop()` (context-api) appends the finished component's `onDestroy` callbacks to it; after the component returns, `render()` drains the array. This is the only lifecycle hook that fires on the server.
5. **Head & CSS aggregation.** `<svelte:head>` content goes to `payload.head.out`; component CSS is a `Set<{hash, code}>` rendered as `<style id="{hash}">` entries appended to `head`, enabling CSS de-duplication across component instances.
6. **Dev-mode safety rails** – HTML-tree validation, snippet-arg checks and element-stack isolation are all no-ops in production. Details in [server-runtime_dev-diagnostics](server-runtime_dev-diagnostics.md).

---

## 7. Related Modules

- **Client Runtime Engine** – the browser counterpart: signals, effects, DOM blocks ([client-reactivity-engine](client-reactivity-engine.md), [client-dom-renderer](client-dom-renderer.md), [client-dev-tooling](client-dev-tooling.md)). Server output is designed to be hydration-compatible with it.
- **Compiler Pipeline & Language Toolchain** – generates the code that calls these primitives (see [compiler-transformer_server-transform](compiler-transformer_server-transform.md) for the server transform); the shape of generated calls is defined there.
- **Public API & Built-in Feature Surface** – `svelte/server` (`render`, `hydrate`, `mount`, `unmount`) wraps this module; see [public-api](public-api.md).
- **[context-api](context-api.md)** and **[internal-shared-utils](internal-shared-utils.md)** – sibling modules shared by client and server runtimes.
