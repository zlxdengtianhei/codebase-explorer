# Public API — `svelte` Package Entry Points (`public-api`)

## 1. Purpose & Scope

The **`public-api` module is the front door of the Svelte package.** Everything a Svelte user writes — `import { mount, onMount, ... } from 'svelte'` — resolves through the files documented here. The module has three distinct responsibilities:

1. **Environment-specific runtime entry points** — two parallel implementation files (`index-client.js` and `index-server.js`) that expose the *same* named API surface but behave differently depending on whether code runs in a browser or on a server during SSR. A bundler's export conditions pick the right one.
2. **The canonical TypeScript type surface** — `index.d.ts` defines the types that make Svelte components, snippets, and event dispatchers statically checkable (`Component`, `Snippet`, `EventDispatcher`, `MountOptions`, legacy `SvelteComponent*` types).
3. **Editor/language-server typings** — `svelte-html.d.ts` provides the global `svelteHTML` typing map consumed directly by the Svelte language server (never imported at runtime).

> **Relationship to other modules.** This module is almost entirely a *facade*: nearly every exported function is a thin, guarded wrapper around — or a direct re-export from — the internal engines:
> - Client behaviour delegates to the **[Client Runtime Engine (Reactivity & DOM Rendering)](Client_Runtime_Engine.md)** (`runtime.js`, `render.js`, `context.js`, `reactivity/*`).
> - Server behaviour delegates to the **[Server-Side Rendering & Cross-Target Runtime Services](Server-Side_Rendering___Cross-Target_Runtime_Services.md)** (`internal/server/*`, `internal/shared/*`).
> - Feature sub-libraries (`svelte/store`, `svelte/motion`, `svelte/transition`, `svelte/animate`, `svelte/easing`, `svelte/reactivity`, `svelte/action`, `svelte/attachments`) are **separate sibling modules** of the same *Public API & Built-in Feature Surface* parent — see [§7 Feature Sub-Libraries](#7-feature-sub-libraries-sibling-modules).

---

## 2. Architecture Overview

### 2.1 Dual-entry module resolution

A bundler (Vite, webpack, Rollup, SvelteKit) resolves `import { x } from 'svelte'` through the package `exports` map. The `"browser"` / `"node"` / `"default"` conditions select exactly one implementation file, so application code never branches manually:

```mermaid
flowchart TD
    subgraph User["User / Tooling"]
        APP["Application & component code<br/>import { mount } from 'svelte'"]
        LS["Svelte Language Server<br/>(IDE intellisense)"]
    end

    subgraph Module["public-api module"]
        INDEX_DTS["index.d.ts<br/>Component · Snippet · EventDispatcher<br/>MountOptions · legacy types"]
        CLIENT["index-client.js<br/>(browser / CSR implementation)"]
        SERVER["index-server.js<br/>(node / SSR implementation)"]
        HTML_DTS["svelte-html.d.ts<br/>global svelteHTML namespace<br/>IntrinsicElements"]
    end

    subgraph Engines["Internal engine modules"]
        CRTL["Client Runtime Engine<br/>runtime · render · context · reactivity"]
        SRTL["Server Runtime Services<br/>internal/server/* · internal/shared/*"]
    end

    APP -- "condition: browser/client" --> CLIENT
    APP -- "condition: node/server" --> SERVER
    CLIENT -- "wraps & re-exports" --> CRTL
    SERVER -- "wraps & re-exports" --> SRTL
    INDEX_DTS == "export * from './index-client.js'" ==> CLIENT
    LS -- "loads directly (not in exports map)" --> HTML_DTS
```

Key invariant: **both entries export the same names.** Client code written once compiles for either target without conditional imports. Functions that *cannot* work on the server (`mount`, `hydrate`, `unmount`) exist there but throw a descriptive `lifecycle_function_unavailable` error; functions that are meaningless on the server (`onMount`, `beforeUpdate`, `afterUpdate`, `tick`, `settled`, `createEventDispatcher`, `flushSync`) degrade to no-ops.

### 2.2 Facade layering

```mermaid
flowchart LR
    subgraph PublicAPI["public-api (facade)"]
        direction TB
        GUARD["Guards & legacy shims<br/>lifecycle_outside_component ·<br/>legacy_mode branching ·<br/>rune access traps (DEV)"]
        REEXPORT["Pure re-exports<br/>mount · hydrate · unmount · tick ·<br/>untrack · settled · flushSync ·<br/>setContext/getContext · createRawSnippet"]
    end

    subgraph ClientEngine["Client Runtime Engine"]
        RUNTIME["runtime.js<br/>active_reaction · component_context"]
        EFFECTS["user_effect / reaction teardown"]
        RENDER["render.js<br/>_mount · hydrate · unmount registry"]
        BATCH["batch.js<br/>flushSync"]
        CTX["context.js<br/>context Map per component"]
    end

    subgraph ServerEngine["Server Runtime"]
        SCURRENT["server/context.js<br/>current_component"]
        SABORT["server/abort-signal.js"]
        SNOOP["shared/utils.js noop / run"]
    end

    GUARD --> RUNTIME
    GUARD --> EFFECTS
    REEXPORT --> RENDER
    REEXPORT --> BATCH
    REEXPORT --> CTX
    GUARD --> SNOOP
    REEXPORT --> SABORT
    REEXPORT --> SCURRENT
```

The facade adds exactly three kinds of value over the raw internals:

| Value added | Example |
|---|---|
| **Component-scope guards** | `onMount` throws `lifecycle_outside_component` when no `component_context` / `current_component` is active |
| **Legacy-mode compatibility** | `onMount`/`beforeUpdate`/`afterUpdate` route into `context.l.u` callback arrays in legacy mode, `$effect`-style user effects in runes mode |
| **Safety rails (DEV only)** | `throw_rune_error` installs getter traps on `globalThis` so `$state`, `$effect`, … throw a helpful error when referenced outside compiled Svelte code |

---

## 3. Exported API Surface

### 3.1 Lifecycle functions

| Export | Client | Server | Notes |
|---|---|---|---|
| `onMount(fn)` | Schedules `fn` once after DOM mount; a synchronously-returned function becomes the cleanup handler | `noop` | Legacy mode defers to `context.l.u.m` queue; runes mode wraps in `user_effect` + `untrack` |
| `onDestroy(fn)` | Cleanup on unmount (implemented *via* `onMount`) | Pushed onto `current_component.d` | **The only lifecycle hook that runs on the server** |
| `beforeUpdate(fn)` ⚠️deprecated | Legacy update-queue (`context.l.u.b`) | `noop` | Legacy-only: throws `lifecycle_legacy_only` outside legacy mode. Use `$effect.pre` |
| `afterUpdate(fn)` ⚠️deprecated | Legacy update-queue (`context.l.u.a`) | `noop` | Legacy-only. Use `$effect` |

Detailed behaviour: [public-api_client-entry.md](public-api_client-entry.md) and [public-api_server-entry.md](public-api_server-entry.md).

### 3.2 Mounting & teardown (client-only)

`mount(component, options)`, `hydrate(component, options)` and `unmount(component, options)` are direct re-exports from `internal/client/render.js`:

- **`mount`** appends a freshly rendered component to a `target`, returns its exports.
- **`hydrate`** locates the `<!--ssr--->` hydration anchor, reuses server-rendered DOM, and *recovers* by falling back to a client-side `mount` if the markup mismatches (unless `recover: false`).
- **`unmount`** runs the teardown registered at mount time (warns on double-unmount in DEV).

`MountOptions` (from `index.d.ts`) types the options object: `target`, `anchor`, `props`, `context`, `intro`, deprecated `events`.

### 3.3 Reactivity control

| Export | Semantics |
|---|---|
| `tick()` | Client: `flushSync()` after a microtask (rAF in async mode). Server: `async` no-op |
| `settled()` | Resolves when all pending work settles; async no-op on the server |
| `untrack(fn)` | Run `fn` without subscribing to signals (aliased to `run` on the server) |
| `flushSync()` | Force-synchronous batch flush (client entry re-exports from `reactivity/batch.js`; server: no-op) |

### 3.4 Context, events, snippets, utilities

- **`setContext` / `getContext` / `hasContext` / `getAllContexts`** — re-exported from the per-environment context implementations (client: per-component `Map` inside the signal graph; server: `current_component` stack). Documented in the [context-api](context-api.md) sub-module of the SSR module.
- **`createEventDispatcher()`** ⚠️deprecated — client: closes over the creation-time `component_context` and dispatches `CustomEvent`s to `$$events` handlers, returning `!event.defaultPrevented`; server: returns `noop`. Prefer callback props / `$host()`.
- **`createRawSnippet(render)`** — builds a snippet from raw DOM (client) / HTML string (server).
- **`getAbortSignal()`** — returns an `AbortSignal` tied to the running reaction; aborts when a `$derived`/`$effect` re-runs or is destroyed. Client: lazy `active_reaction.ac` controller; server: module-level controller. Throws `get_abort_signal_outside_reaction` if no reaction is active.
- **`throw_rune_error` (DEV, internal)** — installs `globalThis` getter traps for `$state`, `$effect`, `$derived`, `$inspect`, `$props`, `$bindable` so that referencing a rune in non-compiled JS yields the `rune_outside_svelte` diagnostic instead of `undefined`.

---

## 4. Type Surface (`index.d.ts`)

`index.d.ts` is the single source of truth for public typings; it re-exports everything from `index-client.js` (`export * from './index-client.js'`).

| Type | Role |
|---|---|
| `Component<Props, Exports, Bindings>` | **The Svelte 5 component shape**: a plain function `(internals, props) => exports & legacy shims`, branded via `ComponentInternals` |
| `Snippet<Parameters>` | Type of `{#snippet}` blocks — callable only via `{@render}`; its clever return type produces a compile error message when called directly in TS |
| `EventDispatcher<EventMap>` | Typed dispatcher contract (arity of `detail` inferred from `null`/`undefined` in the map) |
| `MountOptions<Props>` | Options for `mount()`; `props` becomes required when the component has required props |
| `ComponentProps` / `ComponentEvents` / `ComponentType` | Inference helpers over `Component` / legacy `SvelteComponent` |
| `SvelteComponent`, `SvelteComponentTyped`, `ComponentConstructorOptions` | ⚠️Deprecated Svelte 4 class-based types, kept for the compatibility shims (`asClassComponent` etc.) |

Full details: [public-api_component-types.md](public-api_component-types.md). The aggregated rollup of *all* package types lives in the sibling [svelte-public-types](svelte-public-types.md) module (`packages/svelte/types/index.d.ts`), and DOM element typings in [svelte_dom_type_definitions](svelte_dom_type_definitions.md) (`elements.d.ts`).

---

## 5. Language-Server Typings (`svelte-html.d.ts`)

`packages/svelte/svelte-html.d.ts` is **deliberately not in the exports map** — the language server loads it directly. It declares the global `svelteHTML` namespace containing:

- `mapElementTag` / `createElement` — typing bridges the template's tag name to the correct DOM class (handles `<svelte:element>` dynamic tags).
- `IntrinsicElements` — an interface extending `SvelteHTMLElements` (from the sibling [svelte_dom_type_definitions](svelte_dom_type_definitions.md) module) with an entry for every HTML and SVG element, merged with any user augmentation.

Detailed description: [public-api_html-typings.md](public-api_html-typings.md).

---

## 6. Data & Call Flow

### 6.1 `onMount` — client, runes mode

```mermaid
sequenceDiagram
    participant C as Compiled component
    participant API as index-client.js
    participant CC as component_context
    participant RT as Client Runtime (user_effect)

    C->>API: onMount(fn)
    API->>CC: component_context === null ?
    alt outside component
        CC-->>API: throw lifecycle_outside_component('onMount')
    end
    alt legacy mode && context.l
        API->>CC: init_update_callbacks().m.push(fn)
    else runes mode
        API->>RT: user_effect(() => { cleanup = untrack(fn); ... })
        Note over RT: effect runs once after mount;<br/>returned cleanup runs on destroy
    end
```

### 6.2 Environment split of one export (`getAbortSignal`)

```mermaid
flowchart TD
    A["import { getAbortSignal } from 'svelte'"] --> B{"bundler condition"}
    B -->|browser| C["index-client.js::getAbortSignal"]
    B -->|server| D["index-server.js<br/>re-export from internal/server/abort-signal.js"]
    C --> E{"active_reaction === null?"}
    E -->|yes| F["throw get_abort_signal_outside_reaction"]
    E -->|no| G["return (active_reaction.ac ??= new AbortController()).signal<br/>signal aborts on effect/derived re-run or destroy"]
    D --> H["return (controller ??= new AbortController()).signal<br/>(module-scoped, lives for the request/render)"]
```

---

## 7. Feature Sub-Libraries (sibling modules)

The root `svelte` package exposes feature libraries through sub-path exports. They are documented as their own modules and are **not** repeated here:

| Import path | Module doc | Contents |
|---|---|---|
| `svelte/store` | [stores](stores.md) | `writable`, `readable`, `derived`, `get`; Svelte 5 bridges `fromStore` / `toStore` |
| `svelte/motion` | [motion](motion.md) | `spring`, `tweened` |
| `svelte/transition`, `svelte/animate`, `svelte/easing` | [transitions-animations-easing](transitions-animations-easing.md) | `fade`, `fly`, `slide`, …, `flip`, 31 easing functions |
| `svelte/reactivity` | [reactive-builtins](reactive-builtins.md) | `SvelteDate`, `SvelteMap`, `SvelteSet`, `SvelteURL`, `SvelteURLSearchParams`, `MediaQuery`, `createSubscriber` |
| `svelte/action`, `svelte/attachments` | [actions-attachments](actions-attachments.md) | `Action` type, `createAttachmentKey`, `fromAction` |
| (types rollup) | [svelte-public-types](svelte-public-types.md) | `packages/svelte/types/index.d.ts` |
| (DOM typings) | [svelte_dom_type_definitions](svelte_dom_type_definitions.md) | `elements.d.ts`, `SvelteHTMLElements` |

## 8. Sub-module Documentation

| Sub-module | File(s) | Summary |
|---|---|---|
| Client entry | [public-api_client-entry.md](public-api_client-entry.md) | `index-client.js`: lifecycle hooks, legacy shims, event dispatcher, abort signals, DEV rune traps, re-exports |
| Server entry | [public-api_server-entry.md](public-api_server-entry.md) | `index-server.js`: SSR-safe substitutes — no-op lifecycles, throwing mount functions, server `onDestroy` |
| Component types | [public-api_component-types.md](public-api_component-types.md) | `index.d.ts`: `Component`, `Snippet`, `EventDispatcher`, `MountOptions`, legacy class types |
| HTML typings | [public-api_html-typings.md](public-api_html-typings.md) | `svelte-html.d.ts`: global `svelteHTML` namespace and `IntrinsicElements` for the language server |

## 9. Related Modules

- **[Client Runtime Engine (Reactivity & DOM Rendering)](Client_Runtime_Engine_(Reactivity___DOM_Rendering).md)** — implements everything the client entry delegates to (signal graph, effects, batching, DOM blocks, bindings). Key touch-points: `runtime.js` (`active_reaction`, `tick`), `render.js` (`mount`/`hydrate`/`unmount`), `context.js` (`component_context`, context API), `reactivity/batch.js` (`flushSync`).
- **[Server-Side Rendering & Cross-Target Runtime Services](Server-Side_Rendering___Cross-Target_Runtime_Services.md)** — implements the server entry (render pipeline, payload, shared utils) and hosts the shared [context-api](context-api.md) and [internal-shared-utils](internal-shared-utils.md) sub-modules that both entries re-export from.
- **[Compiler Pipeline & Language Toolchain](Compiler_Pipeline___Language_Toolchain.md)** — emits the compiled component code that calls these entry points, and its public types are rolled up into `packages/svelte/types/index.d.ts` ([svelte-public-types](svelte-public-types.md)).

> Generated sub-module documentation for this module (confirmed filenames): [public-api_client-entry.md](public-api_client-entry.md) · [public-api_server-entry.md](public-api_server-entry.md) · [public-api_component-types.md](public-api_component-types.md) · [public-api_html-typings.md](public-api_html-typings.md).
