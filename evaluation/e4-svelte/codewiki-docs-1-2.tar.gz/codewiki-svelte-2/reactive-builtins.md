# Reactive Builtins (`svelte/reactivity`)

## 1. Overview

The **reactive-builtins** module (source directory `packages/svelte/src/reactivity/`) provides **drop-in, reactive replacements for JavaScript and browser built-in objects**. Each class mirrors the API of its native counterpart one-for-one — `Date`, `Map`, `URL`, `URLSearchParams`, plus the browser `MediaQuery` wrapper — but with one crucial difference: **reading them inside an `$effect` or `$derived` registers a fine-grained dependency**, so any mutation to the object automatically re-runs exactly the reactions that observed it.

```svelte
<script>
        import { SvelteMap } from 'svelte/reactivity';

        const board = new SvelteMap();

        $effect(() => {
                // reading `board.get(...)` / `board.size` here creates a dependency;
                // `board.set(...)` anywhere will re-run this effect
                console.log(board.get('key'), board.size);
        });
</script>
```

The module ships two personalities selected by the bundler's environment condition:

| Entry | File | Behavior |
|---|---|---|
| `svelte/reactivity` (client) | `index-client.js` → `date.js`, `map.js`, `set.js`, `url.js`, `url-search-params.js`, `media-query.js` | Fully reactive implementations wired into the signal runtime |
| `svelte/reactivity` (server) | `index-server.js` | Inert fallbacks: `SvelteDate = Date`, `SvelteMap = Map`, etc., plus a static `MediaQuery` and a no-op `createSubscriber` |

This client/server duality means component code can use the reactive classes unconditionally while remaining SSR-safe: on the server the classes are *structurally identical* (same constructor signatures, same `.current`/read APIs) but never track or notify.

### Core components

| Component | File | Wraps | Tracking granularity |
|---|---|---|---|
| `SvelteMap` | `reactivity/map.js` | `Map` | Per-key `Source` + global `version` signal + `size` signal |
| `SvelteDate` | `reactivity/date.js` | `Date` | Single `#time` source; per-method lazily-created `derived`s |
| `SvelteURL` | `reactivity/url.js` | `URL` | One `Source` per URL component (`protocol`, `host`, `path`, …) |
| `SvelteURLSearchParams` | `reactivity/url-search-params.js` | `URLSearchParams` | Single `version` counter, incremented on every mutation |
| `MediaQuery` | `reactivity/media-query.js` | `window.matchMedia` | `ReactiveValue` with lazily-attached `change` listener |
| `MediaQuery` (stub) | `reactivity/index-server.js` | — | Static `current` field from a fallback value |
| `createSubscriber` (stub) | `reactivity/index-server.js` | — | Returns a no-op subscribe function |

---

## 2. Position in the Svelte System

`reactive-builtins` is a leaf consumer of the **Client Runtime Engine** reactivity core and a published member of the **Public API** surface (`svelte/reactivity`). It adds no new machinery of its own — every class is a thin, pattern-driven composition of the primitives exported by `packages/svelte/src/internal/client/`:

- `source` / `state` / `set` / `increment` from `internal/client/reactivity/sources.js` — writable signals
- `derived` from `internal/client/index.js` — lazily memoized computed signals
- `get` from `internal/client/runtime.js` — *the* dependency-registration chokepoint: any `get(signal)` call inside an active reaction links the signal into that reaction's dependency list
- `tag` / `label` from `internal/client/dev/tracing.js` — dev-mode signal naming for `$inspect`, tracing and the Svelte DevTools

```mermaid
flowchart TB
    subgraph User["User component code"]
        E["$effect / $derived / template reads"]
    end

    subgraph RB["reactive-builtins (svelte/reactivity)"]
        MAP["SvelteMap"]
        DATE["SvelteDate"]
        URL["SvelteURL"]
        PARAMS["SvelteURLSearchParams"]
        MQ["MediaQuery"]
    end

    subgraph RT["Client Runtime Engine — reactivity core"]
        SRC["sources.js<br/>source · state · set · increment"]
        DER["deriveds<br/>(derived signals)"]
        RUN["runtime.js<br/>get() — dependency registration"]
        TRACE["dev/tracing.js<br/>tag · label"]
    end

    E -- "reads establish deps" --> MAP
    E --> DATE
    E --> URL
    E --> MQ
    MAP --> SRC
    MAP --> DER
    DATE --> SRC
    DATE --> DER
    DATE --> RUN
    URL --> SRC
    PARAMS --> SRC
    MQ -- "extends ReactiveValue" --> RUN
    RB --> TRACE
    SRC --> RUN
    DER --> RUN
```

> **Related modules**
> - The signal machinery consumed here is documented in [Client Runtime Engine — Reactivity & DOM Rendering](client-runtime-engine.md) (signal graph, sources, deriveds).
> - The public re-export surface and the rest of the built-in feature set (stores, motion, transitions) are documented in [Public API & Built-in Feature Surface](public-api.md).
> - The performance of these classes is tracked by [Engineering Tooling — Reactivity Benchmarks](engineering-tooling.md).

---

## 3. Architecture

### 3.1 Composition

The module is organized around **four implementation strategies**, each matched to how its native object is actually read and mutated:

```mermaid
flowchart LR
    subgraph Strategies
        direction TB
        S1["<b>Per-key sources + version</b><br/>SvelteMap<br/><i>get/has → key source;<br/>iterate/missing key → version</i>"]
        S2["<b>Single source + method weaving</b><br/>SvelteDate<br/><i>get*/to*/valueOf → lazy derived;<br/>set* → set #time</i>"]
        S3["<b>Per-component sources</b><br/>SvelteURL<br/><i>8 accessor pairs;<br/>searchParams delegated</i>"]
        S4["<b>Version counter</b><br/>SvelteURLSearchParams<br/><i>coarse: any mutation bumps version</i>"]
        S5["<b>Push subscription</b><br/>MediaQuery<br/><i>ReactiveValue + lazy change listener</i>"]
    end
```

### 3.2 The universal read pattern

Every reactive read funnels through `get()` from the runtime. This is the line that makes an object reactive:

```js
get(name) {
    get(this.#version);        // ← registers `#version` as a dependency
    return super.get(name);    // ← of whatever reaction is currently executing
}
```

`get()` checks `active_reaction` (the currently-running effect/derived) and, if present, appends the signal to its dependency list and itself to the signal's reaction list. No proxies, no global diffing — the dependency graph is built *by ordinary property access at read time*.

### 3.3 The universal write pattern

Mutations follow one of two shapes:

1. **Targeted invalidate** — update the stored value and call `set(source, value)` (which marks dependents dirty and schedules them) and/or `increment(version)` (bump a monotonic counter so version-based readers re-run). `SvelteMap.set()` and `SvelteDate` setters use this.
2. **Coarse invalidate** — re-run the native mutation on `super`, then `increment(#version)` once. `SvelteURLSearchParams` uses this exclusively.

```mermaid
sequenceDiagram
    participant U as User code
    participant M as SvelteMap
    participant S as Source signal
    participant R as Reaction (effect/derived)

    U->>R: reads map.get("a") inside $effect
    R->>M: get("a")
    M->>S: get(key source) — dependency linked
    Note over R,S: effect now depends on source("a")

    U->>M: map.set("a", 2)
    M->>S: increment(source("a"))
    S-->>R: marks reaction dirty → scheduled
    R->>M: re-runs get("a")
    M-->>R: 2
```

### 3.4 Client / server duality

```mermaid
flowchart TB
    subgraph Import["import { SvelteMap } from 'svelte/reactivity'"]
        COND{"environment<br/>condition"}
    end
    COND -- "browser / client build" --> C["index-client.js<br/>SvelteMap extends Map<br/>SvelteDate extends Date<br/>SvelteURL extends URL<br/>SvelteURLSearchParams extends URLSearchParams<br/>MediaQuery extends ReactiveValue<br/>+ SvelteSet"]
    COND -- "server build" --> SV["index-server.js<br/>SvelteDate = globalThis.Date<br/>SvelteMap = globalThis.Map<br/>SvelteSet = globalThis.Set<br/>SvelteURL = globalThis.URL<br/>SvelteURLSearchParams = globalThis.URLSearchParams<br/>MediaQuery: static current<br/>createSubscriber: () => {}"]
```

The server stubs exist for **SSR safety and treeshakeability**: no signal machinery is ever pulled into a server bundle, and because `SvelteDate` etc. alias the globals, `instanceof` checks keep working. `MediaQuery` on the server resolves to the `fallback` constructor argument (documented as a hydration-mismatch hazard in its docs).

---

## 4. Cross-Cutting Design Patterns

These five patterns recur in every sub-module; understanding them once explains the whole module.

### 4.1 Transparent subclassing
Every class `extends` its native counterpart. All unknown members fall through to native implementations, so `SvelteMap` gains `instanceof Map`, JSON serialization, spread behavior, etc. for free. Only read methods that must register dependencies and write methods that must invalidate are overridden.

### 4.2 Lazy dependency creation
Dependencies are created **only when observed**:
- `SvelteMap` allocates a per-key `Source` the first time that key is read (`get`/`has`); never-read keys cost nothing. Missing keys track the `version` signal instead — so a read of an absent key correctly re-runs when that key is later added.
- `SvelteDate` wraps each zero-arg `get*`/`to*`/`valueOf` method in a `derived` created **on first call**, as though it had existed since construction (the owning reaction is captured in the constructor and temporarily restored via `set_active_reaction` so ownership is correct). Methods called with arguments skip memoization.
- `MediaQuery` attaches its `matchMedia` `change` listener only when `current` is first read inside a reaction (`ReactiveValue` → `createSubscriber`), and detaches when the last subscriber unsubscribes — zero listeners for unobserved media queries.

### 4.3 Version-counter fan-out
Granular per-key sources handle *same-key* invalidation cheaply, but iteration (`forEach`, `values`, `entries`, `size`-changes, key addition/removal) must invalidate everyone. The `#version` signal is the coarse channel: writers call `increment(#version)` when the *set of keys* changed, and iterators call `get(#version)` on read. `SvelteMap.set()` contains the key optimization: it only bumps `version` when the per-key source's reaction set isn't already a subset of the version's reactions.

### 4.4 `state` vs `source` ownership
`SvelteMap` (and its sibling `SvelteSet`) choose the signal flavor by construction context: if the map is created during the same reaction/version that reads it (`update_version === this.#update_version`), keys use `state()` — untracked at construction — otherwise `source()`. This prevents a map built inside an effect from accidentally becoming a dependency of the effect that builds it.

### 4.5 Dev-mode observability
Under `DEV` (esm-env), every signal is `tag()`ged — `SvelteDate.#time`, `SvelteMap get(key)`, `SvelteURL.protocol`, `SvelteURLSearchParams version` — which surfaces readable names in the tracing mode, `$inspect`, and devtools instead of anonymous signals.

---

## 5. Sub-modules

The module splits cleanly along implementation strategy. Detailed documentation lives in these files:

| Sub-module | File(s) | Contents |
|---|---|---|
| **Reactive Collections** — per-key tracking, version counters, size signals | [reactive-builtins_collections.md](reactive-builtins_collections.md) | `SvelteMap` (and the parallel `SvelteSet` pattern) |
| **Reactive Temporal** — method weaving and lazy deriveds | [reactive-builtins_temporal.md](reactive-builtins_temporal.md) | `SvelteDate` |
| **Reactive URL State** — component-level accessors and URL↔params coupling | [reactive-builtins_url.md](reactive-builtins_url.md) | `SvelteURL`, `SvelteURLSearchParams` |
| **Media Queries & Server Fallbacks** — push-based subscriptions, SSR strategy | [reactive-builtins_media-query.md](reactive-builtins_media-query.md) | `MediaQuery`, `ReactiveValue`, server `createSubscriber` stub |

---

## 6. Data Flow Summary

```mermaid
flowchart TD
    MUT["Mutation<br/>(map.set / date.setTime / url.href= / params.append)"] --> W{"Writer strategy"}
    W -- "targeted" --> TS["set(key source)<br/>+ maybe increment(version)"]
    W -- "coarse" --> CI["increment(version)"]
    W -- "push (MediaQuery)" --> EV["matchMedia change event<br/>→ update()"]
    W -- "SvelteDate setters" --> TIME["set(#time, getTime())"]
    TIME --> DER["per-method deriveds marked dirty"]
    TS --> PROP["signals propagate:<br/>dependents marked dirty → batched flush"]
    CI --> PROP
    EV --> PROP
    DER --> PROP
    PROP --> FX["effects re-run / deriveds re-evaluate<br/>→ DOM updates"]
```

---

## 7. Usage Notes & Caveats

- **Values inside collections are not deeply reactive.** `new SvelteMap([['k', {deep: 1}]])` makes the map reactive, not the stored object. Wrap nested values with `$state` if needed.
- **SSR + `MediaQuery`**: the server cannot know the viewport; the constructor's `fallback` is used, so prefer CSS media queries when possible to avoid hydration mismatches.
- **`SvelteURLSearchParams` ↔ `SvelteURL` coupling**: when created inside `new SvelteURL(...)`, params mutations write back to `url.search` (guarded against re-entrancy by the `#updating` flag); the internal `REPLACE` symbol lets `SvelteURL` bulk-replace params without triggering a write-back loop.
- **Treeshakeability**: classes initialize their method overrides on first instantiation (`SvelteDate.#init()`), so an app that never imports `SvelteDate` pays nothing.
- **Missing-key tracking**: reading `map.get(missing)` tracks the version, so effects re-run when the key later appears — at the cost of re-running on any structural change.

---

## 8. Verification

The reactivity characteristics of these classes (fine-grained invalidation, diamond dependencies, avoidable recomputation) are continuously measured by the `benchmarking/benchmarks/reactivity/` suite — see [Engineering Tooling](engineering-tooling.md) for the Kairo/SBench/Mol benchmark harnesses that exercise exactly the signal paths described above.
