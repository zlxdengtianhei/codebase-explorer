# public-api_client-entry

> **Module:** `packages/svelte/src/index-client.js` — the browser-side entry point of the `svelte` public API.

## 1. Overview

`public-api_client-entry` is the **client (browser) entry point** of the `svelte` package. When application code writes `import { onMount } from 'svelte'` in a bundle that targets the browser, package `exports` conditions resolve to this module. It is the public façade in front of the internal client runtime (see [client-reactivity-engine](client-reactivity-engine.md) and [client-dom-renderer](client-dom-renderer.md)).

The module has three distinct responsibilities:

1. **Component lifecycle functions** — `onMount` and `onDestroy` (runes-mode safe), plus the legacy `beforeUpdate` / `afterUpdate` hooks (deprecated, legacy-mode only).
2. **Legacy event dispatch** — `createEventDispatcher()`, the pre-v5 component-event mechanism.
3. **Async cancellation** — `getAbortSignal()`, a bridge from the reactivity engine to the DOM `AbortSignal` API.

Additionally, the file bottom is a **re-export façade** that publishes internal client capabilities (`mount`, `hydrate`, `unmount`, `tick`, `untrack`, `settled`, `flushSync`, the context API, `createRawSnippet`) as the public API surface, and a **DEV-only guard** (`throw_rune_error`) that turns accidental use of runes in uncompiled code into a clear error.

### Public surface

| Export | Kind | Status | Description |
| --- | --- | --- | --- |
| `onMount(fn)` | function | stable | Runs `fn` once after the component is mounted; a synchronously returned function is used as cleanup. |
| `onDestroy(fn)` | function | stable | Runs `fn` on unmount. Implemented on top of `onMount`; the only lifecycle hook that also runs during SSR. |
| `beforeUpdate(fn)` | function | **deprecated** | Legacy hook; runs before every update. Replaced by `$effect.pre`. |
| `afterUpdate(fn)` | function | **deprecated** | Legacy hook; runs after every update. Replaced by `$effect`. |
| `createEventDispatcher()` | factory | **deprecated** | Returns a dispatcher for legacy component events (`CustomEvent` based). Replaced by callback props / `$host()`. |
| `getAbortSignal()` | function | stable | Returns an `AbortSignal` tied to the current `$derived`/`$effect` reaction. |
| `mount`, `hydrate`, `unmount` | re-export | stable | Component bootstrap / teardown (from [client-dom-renderer](client-dom-renderer.md)). |
| `tick`, `untrack`, `settled` | re-export | stable | Reactivity utilities (from [client-reactivity-engine](client-reactivity-engine.md)). |
| `flushSync` | re-export | stable | Synchronous batch flush (from [client-reactivity-engine](client-reactivity-engine.md)). |
| `setContext`, `getContext`, `hasContext`, `getAllContexts` | re-export | stable | Client half of the context API (see [context-api](context-api.md)). |
| `createRawSnippet` | re-export | stable | Low-level raw-snippet factory. |

## 2. Position in the overall system

The module sits at the boundary between **user-facing API** and **internal runtime**. Compiled components (emitted by [compiler-transformer_client-transform](compiler-transformer_client-transform.md)) establish a `component_context` via `push()`/`pop()`; the functions in this module consult that context to decide whether a call is legal and which execution mode (runes vs. legacy) applies.

```mermaid
flowchart TB
    subgraph consumer["Consumers"]
        CC["Compiled Svelte components<br/>(client transform output)"]
        UD["Application code<br/>importing from 'svelte'"]
    end

    subgraph entry["public-api_client-entry (index-client.js)"]
        LIFE["Lifecycle: onMount / onDestroy"]
        LEGACY["Legacy hooks: beforeUpdate / afterUpdate"]
        DISPATCH["createEventDispatcher"]
        ABORT["getAbortSignal"]
        GUARD["throw_rune_error (DEV only)"]
        FACADE["Re-export façade:<br/>mount · hydrate · unmount · tick · untrack ·<br/>settled · flushSync · context API · createRawSnippet"]
    end

    subgraph internal["Internal client runtime"]
        RT["reactivity/runtime.js<br/>active_reaction · untrack · tick"]
        FX["user_effect (effects)"]
        BATCH["batch.js · flushSync"]
        RENDER["render.js · mount/hydrate/unmount"]
        CTX["context.js · component_context"]
        SNIP["blocks/snippet.js · createRawSnippet"]
        ERRS["errors.js / warnings.js<br/>(message catalog)"]
    end

    CC -->|"push/pop · legacy callbacks"| LIFE
    CC -->|"l.u buckets"| LEGACY
    CC -->|"$$events handlers"| DISPATCH
    CC -->|"$derived / $effect bodies"| ABORT
    UD --> FACADE
    UD --> LIFE
    UD --> DISPATCH
    UD --> ABORT

    LIFE --> CTX
    LIFE --> FX
    LIFE --> ERRS
    ABORT --> RT
    DISPATCH --> ERRS
    FACADE --> BATCH
    FACADE --> RENDER
    FACADE --> CTX
    FACADE --> RT
    FACADE --> SNIP
    GUARD --> ERRS
```

### Import / re-export dependency map

```mermaid
flowchart LR
    subgraph IC["index-client.js"]
        direction TB
        G["getAbortSignal"]
        OM["onMount / onDestroy"]
        BU["beforeUpdate / afterUpdate"]
        CED["createEventDispatcher"]
        TRE["throw_rune_error"]
        RE["export { … } from …"]
    end

    RUNTIME["internal/client/runtime.js<br/>(client-reactivity-engine)"]
    EFFECTS["internal/client/index.js<br/>user_effect"]
    ERRS["internal/client/errors.js<br/>error catalog"]
    FLAGS["internal/flags/index.js<br/>legacy_mode_flag"]
    CCTX["internal/client/context.js<br/>component_context"]
    SHARED["internal/shared/utils.js<br/>is_array"]
    BATCH["internal/client/reactivity/batch.js<br/>flushSync"]
    RENDER["internal/client/render.js"]
    SNIPPET["internal/client/dom/blocks/snippet.js"]
    ENV["esm-env · DEV flag"]

    G --> RUNTIME
    OM --> EFFECTS
    OM --> CCTX
    OM --> FLAGS
    BU --> CCTX
    CED --> CCTX
    CED --> SHARED
    TRE --> ERRS
    TRE --> ENV
    RE --> BATCH
    RE --> CCTX
    RE --> RENDER
    RE --> RUNTIME
    RE --> SNIPPET
```

## 3. Component reference

### 3.1 Lifecycle functions (`onMount`, `onDestroy`)

Both functions enforce the fundamental invariant **“must be called during component initialisation”**: if `component_context` is `null` (i.e. called outside `push()`/`pop()` of a compiling component), they throw `lifecycle_outside_component`.

- **`onMount(fn)`** — in runes mode it wraps `fn` in a `user_effect` (a non-reactive effect that runs once after mount) and runs the body through `untrack`, so reads inside `fn` never create reactive dependencies. If `fn` synchronously returns a function, that function becomes the cleanup on unmount. In **legacy mode** (when `legacy_mode_flag` is set and the component context carries a legacy record `context.l`), `fn` is instead queued in `context.l.u.m` and invoked by the legacy update machinery.
- **`onDestroy(fn)`** — implemented as `onMount(() => () => untrack(fn))`; the cleanup of the mount effect destroys on unmount. Unlike the other hooks, it has a working counterpart in the server entry, making it the only lifecycle function that runs inside server-side components (see [public-api_server-entry](public-api_server-entry.md)).

```mermaid
sequenceDiagram
    participant App as Application
    participant R as render.js (mount)
    participant CI as Compiled component (push/pop)
    participant LC as index-client.js (onMount)
    participant E as effects engine

    App->>R: mount(Component, { target })
    R->>CI: invoke component function
    CI->>CI: push(props, runes, fn) — context.l set in legacy mode
    CI->>LC: onMount(fn) during initialisation
    LC->>CI: component_context === null ? throw lifecycle_outside_component
    alt legacy mode (context.l !== null)
        LC->>CI: l.u.m.push(fn)
    else runes mode
        LC->>E: user_effect(() => untrack(fn))
        Note over E: runs once after mount;<br/>returned function = cleanup
    end
    CI->>CI: pop(component)
    R-->>App: component exports
    Note over E: mount effects flush → fn executes
```

### 3.2 Legacy update hooks (`beforeUpdate`, `afterUpdate`) — deprecated

These hooks are **legacy-mode only**: calling them outside a legacy component (context without a legacy record `l`) throws `lifecycle_legacy_only`. Both funnel through the internal helper `init_update_callbacks(context)`, which lazily creates the callback buckets `{ a: [], b: [], m: [] }` on `context.l.u`. The legacy runtime then invokes them around every component update cycle (see [legacy-compat](legacy-compat.md)).

```mermaid
flowchart LR
    subgraph L["component_context.l — legacy record"]
        U["u (update callbacks)"]
        U --> A["a: afterUpdate[]"]
        U --> B["b: beforeUpdate[]"]
        U --> M["m: onMount[] (legacy path)"]
    end
    BU["beforeUpdate(fn)"] -->|"init_update_callbacks().b.push"| B
    AU["afterUpdate(fn)"] -->|"init_update_callbacks().a.push"| A
    OMM["onMount — legacy path"] --> M
    L -->|"invoked around each legacy update"| LR["legacy update cycle"]
```

Migration: `beforeUpdate` → `$effect.pre`, `afterUpdate` → `$effect`. Both hooks are slated for removal in Svelte 6.

### 3.3 `createEventDispatcher()` — deprecated

Creates a dispatcher for legacy component events. Key behaviours:

- On **creation** it captures the currently active `component_context`; the dispatcher remains bound to that component even if the returned function is passed around.
- On **dispatch** it looks up handlers registered by the parent under `$$events[type]` on the captured context, builds a `CustomEvent(type, { detail, bubbles, cancelable })`, and invokes every handler with `this` bound to the component’s export object (`context.x`).
- Return value: `!event.defaultPrevented` (or `true` when no listeners exist). Events **do not bubble**.
- Typing is narrowed via generics: `createEventDispatcher<{ change: string }>()`.

The parent-side handler registration (`on:click={...}` → `$$events`) is produced by the compiler; see [compiler-transformer_client-transform](compiler-transformer_client-transform.md). Replacement pattern: callback props, or `$host()` for custom elements.

```mermaid
sequenceDiagram
    participant C as Component initialisation
    participant F as createEventDispatcher()
    participant CTX as component_context
    participant P as Parent ($$events)

    C->>F: dispatch = createEventDispatcher()
    F->>CTX: capture active_component_context
    C->>F: dispatch('change', detail, options)
    F->>CTX: read $$events['change']
    alt handlers registered
        F->>F: create_custom_event(type, detail, options)
        loop each handler (copied array)
            F->>P: handler.call(instance_exports, event)
        end
        F-->>C: return !event.defaultPrevented
    else no handlers
        F-->>C: return true
    end
```

### 3.4 `getAbortSignal()`

Bridges the reactivity engine to the DOM abort protocol. It requires an **active reaction** — i.e. it must be called inside a `$derived` or `$effect` (including async bodies). If `active_reaction` is `null` it throws `get_abort_signal_outside_reaction`. Otherwise it lazily attaches an `AbortController` to the reaction (`active_reaction.ac ??= new AbortController()`) and returns its `signal`; the engine aborts the controller when the reaction re-runs or is destroyed, so in-flight `fetch`/`abortable` work is cancelled.

```mermaid
sequenceDiagram
    participant D as $derived / $effect body
    participant GAS as getAbortSignal()
    participant RT as runtime (active_reaction)
    participant AC as AbortController

    D->>GAS: signal = getAbortSignal()
    GAS->>RT: active_reaction === null ?
    alt outside any reaction
        RT-->>D: throw get_abort_signal_outside_reaction
    else inside reaction
        GAS->>AC: reaction.ac ??= new AbortController()
        GAS-->>D: controller.signal
        Note over RT,AC: reaction re-runs or is destroyed →<br/>controller.abort()
    end
```

Typical usage is inside an async `$derived` that fetches data keyed by a reactive value (see the JSDoc example in the source).

### 3.5 DEV guard: `throw_rune_error`

Compiled only when `DEV` is truthy (`esm-env`). At module load it installs a **trapping accessor on `globalThis`** for each rune name (`$state`, `$effect`, `$derived`, `$inspect`, `$props`, `$bindable`):

- **Read:** if the global has never been assigned, it throws `rune_outside_svelte` (via the internal error catalog — see [client-dev-tooling](client-dev-tooling.md) and [message_code_generation_templates](message_code_generation_templates.md)), turning “runes used in uncompiled `.js`” into an actionable error instead of a silent `undefined`.
- **Write:** values are stored and later returned, so legitimate code that happens to define such globals (e.g. testing helpers) keeps working.

### 3.6 Re-export façade

The bottom of the file forwards internal client capabilities to the public API. The implementations live in and are documented by the runtime modules:

| Re-export | Source | Owning module documentation |
| --- | --- | --- |
| `flushSync(fn)` | `internal/client/reactivity/batch.js` | [client-reactivity-engine](client-reactivity-engine.md) |
| `tick`, `untrack`, `settled` | `internal/client/runtime.js` | [client-reactivity-engine](client-reactivity-engine.md) |
| `setContext`, `getContext`, `hasContext`, `getAllContexts` | `internal/client/context.js` | [context-api](context-api.md) |
| `mount`, `hydrate`, `unmount` | `internal/client/render.js` | [client-dom-renderer](client-dom-renderer.md) |
| `createRawSnippet` | `internal/client/dom/blocks/snippet.js` | [client-dom-renderer](client-dom-renderer.md) |

Note that `flushSync` **throws `flush_sync_in_effect`** when invoked from inside an effect while async mode is active — one of the few façade exports with entry-relevant behaviour worth knowing about.

## 4. Client vs. server entry

This module is one of a mirrored pair. The server counterpart (`packages/svelte/src/index-server.js`) is documented in [public-api_server-entry](public-api_server-entry.md); the shared types in [public-api_component-types](public-api_component-types.md).

| Symbol | Client entry (`index-client.js`) | Server entry (`index-server.js`) |
| --- | --- | --- |
| `mount` / `hydrate` / `unmount` | Real implementations (DOM rendering, hydration) | Stubs that throw `lifecycle_function_unavailable` |
| `onDestroy` | Effect-cleanup based | Works inside SSR components (only lifecycle hook that runs server-side) |
| `onMount`, `beforeUpdate`, `afterUpdate` | Implemented (browser-only semantics) | Not applicable during render |
| `createEventDispatcher` | CustomEvent dispatch via `$$events` | Minimal legacy-compatible implementation |
| `getAbortSignal` | Tied to client reaction graph | Provided via internal server `abort-signal.js` |
| Context API | Client map per component context | Server push/pop stack (see [context-api](context-api.md)) |

Bundlers select the correct entry via package `exports` conditions (browser vs. node/server), which is why both files must keep the same export *names* with target-appropriate *bodies*.

## 5. Error and validation behaviour

All guards surface diagnostics from the shared message system:

| Situation | Diagnostic | Thrown by |
| --- | --- | --- |
| Lifecycle function called outside component initialisation | `lifecycle_outside_component` | `onMount`, `onDestroy`, `beforeUpdate`, `afterUpdate`, `createEventDispatcher` |
| `beforeUpdate` / `afterUpdate` in runes mode | `lifecycle_legacy_only` | legacy hooks |
| Rune global read in uncompiled code (DEV) | `rune_outside_svelte` | `throw_rune_error` traps |
| `getAbortSignal()` outside `$derived`/`$effect` | `get_abort_signal_outside_reaction` | `getAbortSignal` |
| `flushSync` inside an effect (async mode) | `flush_sync_in_effect` | re-exported `flushSync` |

Message strings are generated from the templates described in [message_code_generation_templates](message_code_generation_templates.md); the client-side catalog itself is maintained in [client-dev-tooling](client-dev-tooling.md).

## 6. Design notes & invariants

- **Thin façade, heavy runtime:** almost all logic is delegated to `internal/client/*`; this file only owns mode dispatch (legacy vs. runes) and legacy shims, keeping the public surface tree-shakeable (see [treeshakeability_checker](treeshakeability_checker.md)).
- **Initialisation-time capture:** `createEventDispatcher` binds to `component_context` at creation, not at dispatch — passing the dispatcher to children or timers is safe.
- **`untrack` discipline:** `onMount`/`onDestroy` bodies are always executed untracked so lifecycle code never subscribes to state.
- **Legacy bucket strategy:** in legacy mode, callbacks are queued (`context.l.u.{a,b,m}`) and replayed by the legacy update cycle, preserving Svelte 4 semantics (`onMount` before first update, etc.). See [legacy-compat](legacy-compat.md).
- **Mirror-surface constraint:** every name exported here must exist in the server entry (even as throwing stubs) so that universal components compile against one import path.

## 7. Related modules

- Parent: [public-api](public-api.md) — the whole built-in feature surface.
- Siblings: [public-api_server-entry](public-api_server-entry.md), [public-api_component-types](public-api_component-types.md) (`EventDispatcher`, `Component`, `Snippet` types used above), [public-api_html-typings](public-api_html-typings.md).
- Runtime dependencies: [client-reactivity-engine](client-reactivity-engine.md), [client-dom-renderer](client-dom-renderer.md), [context-api](context-api.md), [legacy-compat](legacy-compat.md), [internal-shared-utils](internal-shared-utils.md), [client-dev-tooling](client-dev-tooling.md).
- Producer of callers: [compiler-transformer_client-transform](compiler-transformer_client-transform.md) (compiled components establish `component_context` and `$$events` consumed by this module).
