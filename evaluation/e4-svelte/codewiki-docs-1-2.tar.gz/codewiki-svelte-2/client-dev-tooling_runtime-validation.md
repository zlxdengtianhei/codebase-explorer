# client-dev-tooling_runtime-validation

## 1. Introduction

`client-dev-tooling_runtime-validation` is the **runtime validation layer** of Svelte's client-side developer tooling. It contains the small set of functions that the Svelte compiler injects into **development builds** of components to catch, at runtime, the classes of mistakes that cannot be (or are only partially) detected at compile time:

| Validator | Guarded language feature | Failure mode | Outcome |
|---|---|---|---|
| `validate_each_keys` | Keyed `{#each}` blocks | Duplicate keys within one collection | **Throws** `each_key_duplicate` |
| `validate_binding` | `bind:` directives (runes mode) | Binding target property is not reactive | **Warns once** `binding_property_non_reactive` |
| `validate_snippet_args` | Snippet functions (`{#snippet}` / `{@render}`) | Snippet invoked with a non-`Node` anchor or non-function arguments | **Throws** `invalid_snippet_arguments` |

### Source components

| File | Exported components |
|---|---|
| `packages/svelte/src/internal/client/validate.js` | `validate_binding`, `validate_each_keys` |
| `packages/svelte/src/internal/client/dev/validation.js` | `validate_snippet_args` |

All three functions live in the internal (non-public) API surface. They are **only referenced from compiler-generated code** — a hand-written application never imports them directly. Because the compiler emits the calls under `if (dev && …)` guards, the entire module is dead code in production bundles (see [§7 Dev vs. production behaviour](#7-dev-vs-production-behaviour)).

---

## 2. Position in the system

The module is the `runtime-validation` child of [client-dev-tooling](client-dev-tooling.md), which in turn is part of the [Client Runtime Engine (Reactivity & DOM Rendering)](Client_Runtime_Engine_(Reactivity___DOM_Rendering).md). It is the *checker* sibling of three other dev-tooling children:

```mermaid
graph LR
    subgraph CRT["Client Runtime Engine"]
        subgraph CDT["client-dev-tooling"]
            MO["mutation-ownership-guards<br/>(assign · equality · ownership)"]
            RV["⭐ runtime-validation<br/>(this module)"]
            MC["message-catalog<br/>(errors.js · warnings.js)"]
            SI["state-inspection<br/>(inspect · tracing · console-log · debug)"]
        end
        REE["client-reactivity-engine<br/>(effects · signals · stores)"]
        DR["client-dom-renderer"]
    end
    CTX["compiler-transformer_client-transform<br/>(dev-mode output)"] -->|"injects calls to"| RV
    RV -->|"render_effect · capture_store_binding"| REE
    RV -->|"throw e.* / warn w.*"| MC
    DR -.->|"component context<br/>(dev_current_component_function)"| RV
```

* **consumes** the reactivity engine ([client-reactivity-engine_effects](client-reactivity-engine_effects.md), [client-reactivity-engine_props-and-stores](client-reactivity-engine_props-and-stores.md)) — both effect-based validators piggyback on Svelte's dependency tracking to perform their checks;
* **consumes** the message catalog ([client-dev-tooling_message-catalog](client-dev-tooling_message-catalog.md)) for every diagnostic it emits;
* **is invoked by** generated code from [compiler-transformer_client-transform](compiler-transformer_client-transform.md) (see [§5 Compiler integration](#5-compiler-integration)).

Sibling subsystems that provide related but distinct checks are documented separately and are **not** part of this module:

* compile-time static validation of markup/script → [compiler-analyzer_visitors](compiler-analyzer_visitors.md), [compiler-parser_options-reading](compiler-parser_options-reading.md) and the diagnostics infrastructure of [compiler-core_diagnostics](compiler-core_diagnostics.md);
* shared server/client runtime checks (`validate_dynamic_element_tag`, `validate_void_dynamic_element`) → [internal-shared-utils](internal-shared-utils.md);
* the SSR mirror of `validate_snippet_args` (validating `Payload`/`HeadPayload` instead of DOM `Node`s) → [server-runtime](server-runtime.md) (`internal/server/dev.js`).

---

## 3. Architecture

```mermaid
graph TB
    subgraph FILES["Module files"]
        V["<b>internal/client/validate.js</b><br/>validate_each_keys<br/>validate_binding"]
        DV["<b>internal/client/dev/validation.js</b><br/>validate_snippet_args"]
    end

    subgraph MSG["client-dev-tooling_message-catalog"]
        E["errors.js<br/>each_key_duplicate(a, b, key)<br/>invalid_snippet_arguments()"]
        W["warnings.js<br/>binding_property_non_reactive(binding, location)"]
    end

    subgraph REACT["client-reactivity-engine"]
        RE["reactivity/effects.js :: render_effect(fn)"]
        CSB["reactivity/store.js :: capture_store_binding(fn)"]
    end

    CTX["context.js ::<br/>dev_current_component_function<br/>constants.js :: FILENAME"]
    UTIL["internal-shared-utils :: is_array"]

    V -->|"throws duplicate key"| E
    V -->|"warns once"| W
    V -->|"creates validating effects"| RE
    V -->|"exempts $store bindings"| CSB
    V -->|"builds 'file:line:col' location"| CTX
    V -->|"normalises iterables"| UTIL
    DV -->|"throws invalid anchor/args"| E
```

The two files differ in **placement discipline**:

* `dev/validation.js` lives in the `dev/` folder together with the rest of the dev-only helpers — it is *purely* a dev guard with no reactivity involvement (a plain, synchronous argument check).
* `validate.js` sits at the client root because its functions are *reactivity-aware*: they create `render_effect`s and therefore participate in the signal graph (see [client-reactivity-engine_signal-graph](client-reactivity-engine_signal-graph.md)). They are unconditional modules in `validate.js`, but the *calls* into them are dev-only.

---

## 4. Component reference

### 4.1 `validate_each_keys(collection, key_fn)`

Guards keyed `{#each}` blocks against duplicate keys — a data bug that would otherwise silently corrupt reconciliation.

```js
validate_each_keys(collection, key_fn)
// collection: () => any          thunk returning the array/iterable
// key_fn:     (item, index) => string   the compiled key expression
```

Behaviour:

1. Wraps the entire check in a `render_effect`, so the validation **re-runs automatically** whenever the collection (or anything the key function reads) changes. This is what makes it a *runtime* check rather than a one-shot startup check.
2. Normalises the collection: arrays pass through, `null`/`undefined` becomes `[]`, any other iterable is converted with `Array.from` (via `is_array` from [internal-shared-utils](internal-shared-utils.md)).
3. Iterates items, computing `key = key_fn(item, i)` and recording key → index in a `Map`.
4. On the first duplicate it throws `e.each_key_duplicate(a, b, key)` with the two colliding indexes. If the key stringifies to an `[object …]` shape, the key is omitted from the message to avoid unhelpful noise.

```mermaid
flowchart TD
    A["generated call:<br/>$.validate_each_keys(collection, key_fn)"] --> B["render_effect wrapper<br/>(re-runs on any dependency change)"]
    B --> C["collection()"]
    C --> D{"is_array?"}
    D -- "no" --> E["null/undefined → []<br/>otherwise Array.from"]
    D -- "yes" --> F["iterate items"]
    E --> F
    F --> G["key = key_fn(item, i)"]
    G --> H{"key already in Map?"}
    H -- "yes" --> I["throw each_key_duplicate<br/>(indexes a & b, key omitted if '[object …]')"]
    H -- "no" --> J["Map.set(key, i)"]
    J --> K{"more items?"}
    K -- "yes" --> G
    K -- "no" --> L["validation passes;<br/>effect stays live for updates"]
```

### 4.2 `validate_binding(binding, get_object, get_property, line, column)`

Guards `bind:` directives whose target property is **not reactive** — a common Svelte 5 pitfall when binding into plain objects.

```js
validate_binding(binding, get_object, get_property, line, column)
// binding:     string                source text of the binding, e.g. "bind:value={obj.value}"
// get_object:  () => Record<string, any>
// get_property:() => string
// line/column: number                source location of the binding
```

Behaviour:

1. **Store exemption** — runs the object getter inside `capture_store_binding(get_object)`. If the read touched a store subscription (`is_store_sub === true`), validation is skipped: store state is always reactive from the binding's point of view. (The compiler *also* suppresses emission for `$store…` targets — a belt-and-braces double exemption.)
2. **Nested-effect probe** — creates an inner `render_effect` that only reads `object[property]`. The trick (quoted from the source): *“by making the … assumption that a getter has a corresponding setter, we can determine if a property is reactive by seeing if this effect has dependencies.”* Svelte's dependency tracking means:
   * `effect.deps === null` → reading the property registered **no** dependencies → it is a plain, non-reactive value → warn.
   * otherwise the property is reactive → no diagnostic.
3. **Location reporting** — the warning carries `${filename}:${line}:${column}`, where `filename` comes from `dev_current_component_function[FILENAME]` (the currently-executing component's source file, tracked by the component context — see [§2](#2-position-in-the-system)).
4. **Warn once** — the `warned` flag guarantees the outer effect warns at most one time per binding site, even if the effect re-runs.

```mermaid
sequenceDiagram
    autonumber
    participant Gen as Generated component code
    participant VB as validate_binding
    participant ST as capture_store_binding<br/>(props-and-stores)
    participant FX as render_effect<br/>(effects)
    participant WN as warnings catalog

    Gen->>VB: $.validate_binding(binding, get_object, get_property, line, col)
    VB->>ST: capture_store_binding(get_object)
    ST-->>VB: [object, is_store_sub]
    alt is_store_sub = true
        Note over VB: store subscription — always reactive<br/>skip silently
    else plain state read
        VB->>FX: render_effect(() => object[property])
        Note over FX: inner effect registers dependencies<br/>via the signal graph
        alt effect.deps === null
            VB->>WN: binding_property_non_reactive(binding, "filename:line:column")
            Note over VB: warned = true (never warn again for this site)
        else effect.deps !== null
            Note over VB: property is reactive — no diagnostic
        end
    end
```

> The compiler-side helper that emits this call (also named `validate_binding`, in `phases/3-transform/client/visitors/shared/utils.js`) further restricts emission to: dev builds, runes mode, member-expression targets, bindings nested inside `{#if}`/`{#each}`/`{#await}`/`{#key}` branches, and sites not annotated with `<!-- svelte-ignore binding_property_non_reactive -->`.

### 4.3 `validate_snippet_args(anchor, ...args)`

Guards that snippet functions are only invoked the way the compiler intends them to be. Snippets compile to plain functions, so nothing at the language level prevents them from being called manually — this validator turns that mistake into an immediate, actionable error.

* `anchor` must be an instance of DOM `Node` (the insertion anchor every compiled snippet receives as first argument);
* every additional argument must be a `function` (snippets passed as props compile to functions);
* any violation throws `e.invalid_snippet_arguments()` → *“A snippet function was passed invalid arguments. Snippets should only be instantiated via `{@render ...}`”*.

Because the check must inspect *all* arguments, the compiler compiles snippets as **`FunctionExpression`s in dev builds** so the generated body can call `$.validate_snippet_args(...arguments)` before any user code runs. Production builds compile snippets to arrow functions with no validation at all.

**Server counterpart.** During SSR the same contract is enforced by `internal/server/dev.js::validate_snippet_args`, which instead checks that the payload is a `Payload`/`HeadPayload` instance. It is documented with the server runtime: [server-runtime](server-runtime.md). The error function itself is shared and lives in [internal-shared-utils](internal-shared-utils.md) (`internal/shared/errors.js`).

---

## 5. Compiler integration

The runtime-validation functions are *consumers-only* from the runtime's point of view: they are wired in by the client transform phase, which injects the calls at code-generation time.

```mermaid
flowchart LR
    subgraph CT["compiler-transformer_client-transform (dev build)"]
        EBV["EachBlock visitor<br/>(keyed)"] -->|"$ .validate_each_keys(thunk, key_fn)<br/>emitted before '$.each(...)' "| OUT
        BDV["BindDirective visitor<br/>+ shared/utils::validate_binding"] -->|"$ .validate_binding(text, thunk, thunk, line, col)<br/>emitted into init/after_update"| OUT
        SBV["SnippetBlock visitor"] -->|"$ .validate_snippet_args(...arguments)<br/>first statement of snippet body<br/>(compiled as FunctionExpression + wrap_snippet)"| OUT
    end
    OUT["generated component module"] --> RV["runtime-validation functions<br/>(internal/client)"]
    RV --> RES["diagnostic surfaced to the developer<br/>(thrown 'Svelte error' or console.warn)"]
```

Notes on the interaction contracts:

* **EachBlock** — the validator receives *the same* collection thunk and key function that are forwarded to `$.each`, guaranteeing the validation observes exactly what the reconciler observes. The call is pushed **before** the `$.each` statement so a duplicate-key crash happens before any DOM work; inside async (`has_await`) blocks both statements are wrapped in `$.async`.
* **BindDirective** — emission is conditional (dev + runes + member expression + inside a branch + not svelte-ignored, as listed above); the compiler wraps the object expression with `$.mark_store_binding` when the component uses stores, which is what `capture_store_binding` detects at runtime.
* **SnippetBlock** — the injected statement is the *first* statement of the snippet body, so an invalid call fails before destructuring parameters or evaluating declarations.

Compile-time (static) counterparts of these checks — e.g. duplicate-key analysis is impossible statically because keys are arbitrary expressions — are out of scope here; see the analyzer visitors in [compiler-analyzer_visitors](compiler-analyzer_visitors.md).

---

## 6. Diagnostics & message catalog

All diagnostics funnel through the generated catalogs `internal/client/errors.js` and `internal/client/warnings.js` ([client-dev-tooling_message-catalog](client-dev-tooling_message-catalog.md)). Those files are **generated** by the `process-messages` build script from the template modules documented in [message_code_generation_templates](message_code_generation_templates.md) (`compile-errors.js`, `compile-warnings.js`, …) — do not edit the catalogs by hand.

| Diagnostic | Kind | Emitted by | Developer-facing contract |
|---|---|---|---|
| `each_key_duplicate(a, b, key)` | Error (throw, `name: 'Svelte error'`) | `validate_each_keys` | <https://svelte.dev/e/each_key_duplicate> |
| `binding_property_non_reactive(binding, location)` | Warning (`console.warn`, bold label) | `validate_binding` | <https://svelte.dev/e/binding_property_non_reactive> |
| `invalid_snippet_arguments()` | Error (throw, `name: 'Svelte error'`) | `validate_snippet_args` (client & server) | <https://svelte.dev/e/invalid_snippet_arguments> |

In non-DEV builds the catalog functions degrade to throwing/warning only the short documentation URL — but as noted below, the validator calls themselves are already stripped by then. Closely related catalog entries that this module does **not** emit (e.g. `bind_not_bindable`, `props_rest_readonly` from props validation, `svelte_boundary_reset_noop`) belong to sibling dev-tooling and dom-renderer modules.

---

## 7. Dev vs. production behaviour

```mermaid
flowchart TD
    SRC[".svelte source"] --> C{"build mode?"}
    C -- "production" --> P["transform visitors skip validation emission<br/>(snippets → arrow functions, no probe effects)<br/>→ module tree-shaken out"]
    C -- "development" --> D["visitors inject $.validate_each_keys /<br/>$.validate_binding / $.validate_snippet_args"]
    D --> R["runtime checks run inside the effect graph<br/>re-validate on every relevant state change"]
    R --> X{"violation?"}
    X -- "yes" --> TH["throw 'Svelte error'<br/>or console.warn with source location"]
    X -- "no" --> OK["render proceeds normally"]
```

Key properties:

* **Zero-cost in production.** All emission is gated on the compiler's `dev` flag; combined with the `DEV` guards inside the message catalogs, no validation code survives into prod bundles. The repo's [treeshakeability_checker](treeshakeability_checker.md) keeps this guarantee under test.
* **Effect-graph-aware, not one-shot.** `validate_each_keys` and `validate_binding` both use `render_effect`, so a collection that becomes duplicated (or a property that stops being reactive) after the initial mount is still caught. This is the essential difference from plain runtime assertion helpers.
* **Fail loud for hard errors, warn once for soft ones.** Duplicate keys and malformed snippet invocations *throw* (they indicate a programming error); non-reactive binding targets only *warn* (they are legal-but-suspicious and can be silenced per-site with `svelte-ignore binding_property_non_reactive`).

---

## 8. Related modules

| Module | Relationship |
|---|---|
| [client-dev-tooling](client-dev-tooling.md) | Parent subsystem: dev-mode guards, message catalogs, state inspection. |
| [client-dev-tooling_message-catalog](client-dev-tooling_message-catalog.md) | Provides `errors.js` / `warnings.js` consumed by all validators. |
| [client-dev-tooling_mutation-ownership-guards](client-dev-tooling_mutation-ownership-guards.md) | Sibling guards (`assign*`, dev `equality`, `create_ownership_validator`) for state mutation and cross-component ownership. |
| [client-dev-tooling_state-inspection](client-dev-tooling_state-inspection.md) | Sibling `inspect`/`tracing`/`console-log`/`debug` helpers used with `$inspect` and tracing mode. |
| [client-reactivity-engine_effects](client-reactivity-engine_effects.md) | `render_effect` — the execution substrate for both effect-based validators. |
| [client-reactivity-engine_props-and-stores](client-reactivity-engine_props-and-stores.md) | `capture_store_binding` / `mark_store_binding` — store-subscription exemption in `validate_binding`. |
| [compiler-transformer_client-transform](compiler-transformer_client-transform.md) | Injects every call site into generated components (EachBlock, BindDirective, SnippetBlock visitors). |
| [message_code_generation_templates](message_code_generation_templates.md) | Source templates for the generated diagnostic catalogs. |
| [server-runtime](server-runtime.md) | Hosts the SSR twin `internal/server/dev.js::validate_snippet_args`. |
| [internal-shared-utils](internal-shared-utils.md) | `is_array` (iterable normalisation), shared `invalid_snippet_arguments`, and the shared dynamic-element validators. |
