# Client Dev Tooling (Development-Mode Runtime Infrastructure)

## 1. Overview

**`client-dev-tooling`** is the development-mode support layer of Svelte's client runtime (`packages/svelte/src/internal/client/dev/*` plus the runtime-side `errors.js`, `warnings.js` and `validate.js`).

Everything in this module exists for one reason: **making it easy to author and debug Svelte applications**. It provides:

- **Rich diagnostics** — generated catalogs of errors and warnings with formatted console output, source locations and documentation links.
- **Reactive state inspection** — the `$inspect` rune implementation, signal/effect tracing (`$.tag`, `trace`), console-logging guardrails and effect-tree debugging helpers.
- **Mutation & ownership guardrails** — detection of stale compound assignments, proxy-vs-raw-value comparison mismatches, and illegal mutation of parent-owned props.
- **Runtime validation** — checks that only *runtime* can perform: duplicate `{#each}` keys, `bind:` targets that are not reactive, invalid snippet arguments.
- **Hot Module Replacement (HMR)** — component hot-replacement wrappers and dev-mode CSS style cleanup.
- **Legacy API guards** — hard errors when removed Svelte 4 component instance APIs (`$set`, `$on`, `$destroy`, `new Component()`) are used.
- **Source-location metadata** — attaching `__svelte_meta` (file/line/column) to created DOM elements for devtools.

> **Key property:** all of this code is only *reachable* when a component is compiled with `dev: true`. The compiler only emits calls into these helpers from dev-gated code paths, and the generated message modules check the `DEV` flag from `esm-env`, so production builds tree-shake the entire layer away with zero runtime cost.

## 2. Position in the System

This module is a leaf of the **Client Runtime Engine** (see `Client_Runtime_Engine_(Reactivity___DOM_Rendering)` overview), sitting next to the reactivity engine and the DOM renderer. It is a *consumer* of runtime internals and a *provider* of developer-facing behavior:

```mermaid
flowchart TB
    subgraph Compile["Compiler Pipeline (build time)"]
        CT["compiler-transformer<br/>(client transform visitors)"]
        MSG["message_code_generation_templates<br/>+ scripts/process-messages"]
    end

    subgraph CRE["client-reactivity-engine"]
        RT["runtime.js<br/>(untrack, get)"]
        EFF["reactivity/effects.js<br/>(render_effect, inspect_effect,<br/>branch, block, destroy_effect)"]
        SRC["reactivity/sources.js<br/>(source)"]
        PRX["proxy.js<br/>(get_proxied_value, proxy handlers)"]
        STO["reactivity/store.js<br/>(capture_store_binding)"]
    end

    subgraph CDR["client-dom-renderer"]
        HYD["dom/hydration.js<br/>(hydrating, hydrate_node)"]
        RND["render.js<br/>(set_should_intro)"]
    end

    subgraph ISU["internal-shared-utils"]
        CLN["shared/clone.js<br/>(snapshot)"]
        SUT["shared/utils.js<br/>(get_descriptor, define_property, is_array)"]
    end

    subgraph CDT["client-dev-tooling (this module)"]
        DEV["dev/* helpers"]
        VAL["validate.js"]
        CAT["errors.js / warnings.js<br/>(generated catalogs)"]
    end

    MSG -- "generates" --> CAT
    CT -- "emits dev-only calls:<br/>$.tag, $.assign, $.add_locations,<br/>$.validate_snippet_args, $.hmr ..." --> DEV
    CT -- "emits dev-only calls:<br/>$.validate_binding, $.validate_each_keys" --> VAL
    DEV --> RT
    DEV --> EFF
    DEV --> SRC
    DEV --> PRX
    VAL --> STO
    VAL --> EFF
    DEV --> HYD
    DEV --> RND
    DEV --> CLN
    DEV --> SUT
    DEV & VAL -- "report problems via" --> CAT
```

Relationships to sibling modules (documented separately — follow the links instead of repeating details here):

| Depends on | What it uses | Where documented |
|---|---|---|
| `client-reactivity-engine` | `untrack`/`get` (runtime), effect constructors, signal `source()`, `get_proxied_value`, `capture_store_binding` | [client-reactivity-engine.md](client-reactivity-engine.md) |
| `client-dom-renderer` | hydration state (`hydrating`, `hydrate_node`), `set_should_intro` for HMR intros | [client-dom-renderer.md](client-dom-renderer.md) |
| `internal-shared-utils` | `snapshot` (deep-unwrapped copies of state), generic helpers | [internal-shared-utils.md](internal-shared-utils.md) |
| `message_code_generation_templates` | source templates from which `errors.js`/`warnings.js` are generated | [message_code_generation_templates.md](message_code_generation_templates.md) |
| `compiler-transformer` (emits calls *into* this module) | dev-gated call sites in compiled output | [compiler-transformer_client-transform.md](compiler-transformer_client-transform.md) |

## 3. Architecture

The module is organized by *developer-experience concern* rather than by pipeline phase. Six sub-modules cover the surface:

```mermaid
flowchart LR
    subgraph client-dev-tooling
        SI["state-inspection<br/>inspect.js · tracing.js ·<br/>console-log.js · debug.js"]
        MOG["mutation-ownership-guards<br/>assign.js · equality.js · ownership.js"]
        RV["runtime-validation<br/>validate.js · validation.js"]
        HMR["hmr-support<br/>hmr.js · css.js"]
        LMD["legacy-and-metadata<br/>legacy.js · elements.js"]
        MC["message-catalog<br/>errors.js · warnings.js"]
    end

    SI --> MC
    MOG --> MC
    RV --> MC
    LMD --> MC
    MOG -->|"get_proxied_value"| PRX["proxy.js<br/>(reactivity engine)"]
    SI -->|"snapshot"| SH["shared utils"]
```

### How dev checks flow at runtime

```mermaid
sequenceDiagram
    participant App as Compiled component (dev build)
    participant Dev as dev helper (this module)
    participant Re as Reactivity engine
    participant Cat as errors.js / warnings.js

    App->>Dev: call emitted by compiler, e.g. $.tag(sig, "count") / $.assign(obj, "prop", v, loc)
    Dev->>Re: perform work (untrack / read signal / write prop)
    Re-->>Dev: result + reactive side effects
    Dev->>Dev: compare expectation vs reality (stale value? proxy mismatch? ownership violation?)
    alt problem detected
        Dev->>Cat: warning(code, ...args) or error(code, ...args)
        Cat-->>App: console.warn with formatted message + https://svelte.dev/e/<code> — or throw
    else no problem
        Dev-->>App: transparent passthrough of result
    end
```

All generated messages follow one contract: in `DEV` builds they produce readable text (`[svelte] code_name`, explanation, doc URL, console styling); in production they throw/warn only the doc URL, keeping bundles small.

## 4. Sub-modules

Each sub-module has its own detailed documentation file (all files live flat in this documentation directory):

| Sub-module | Files | Documentation |
|---|---|---|
| **State Inspection** | `dev/inspect.js`, `dev/tracing.js`, `dev/console-log.js`, `dev/debug.js` | [client-dev-tooling_state-inspection.md](client-dev-tooling_state-inspection.md) — `$inspect` rune, signal tagging & dependency tracing, console-logging state guardrails, effect-tree debugging. |
| **Mutation & Ownership Guards** | `dev/assign.js`, `dev/equality.js`, `dev/ownership.js` | [client-dev-tooling_mutation-ownership-guards.md](client-dev-tooling_mutation-ownership-guards.md) — stale compound-assignment warnings, proxy equality mismatch detection (incl. patched `Array.prototype` search methods), prop-ownership mutation/binding validation. |
| **Runtime Validation** | `validate.js`, `dev/validation.js` | [client-dev-tooling_runtime-validation.md](client-dev-tooling_runtime-validation.md) — runtime-only checks impossible at compile time: duplicate `{#each}` keys, non-reactive `bind:` targets, invalid snippet arguments. |
| **HMR Support** | `dev/hmr.js`, `dev/css.js` | [client-dev-tooling_hmr-support.md](client-dev-tooling_hmr-support.md) — component hot-replacement wrapper (`hmr`/`wrapper`) that re-creates invalidated components without losing getters/setters; registry for removing stale dev styles on CSS hot updates. |
| **Legacy & Metadata** | `dev/legacy.js`, `dev/elements.js` | [client-dev-tooling_legacy-and-metadata.md](client-dev-tooling_legacy-and-metadata.md) — hard guards against Svelte 4 component APIs, and `__svelte_meta` source-location attachment for devtools. |
| **Message Catalog** | `errors.js`, `warnings.js` | [client-dev-tooling_message-catalog.md](client-dev-tooling_message-catalog.md) — generated error/warning functions shared by all dev helpers; the single formatting contract for all Svelte client diagnostics. |

## 5. Key Behaviors Worth Knowing

- **Tree-shakeability**: nothing here runs unless the compiler emitted a dev call. The only module-global state are small registries (`all_styles` in `css.js`, `tracing_expressions` in `tracing.js`, the `Array.prototype` patch in `equality.js`) that only materialize in dev.
- **No behavior changes by design**: guards like `assign`, `equals`, `strict_equals` *return the original result* — they only observe and warn. HMR (`wrapper`) and style cleanup are the only pieces that actively alter behavior, and only under `HMR`.
- **Errors vs warnings**: errors (`errors.js`) represent broken invariants (throw, aborting execution); warnings (`warnings.js`) represent suspicious-but-working patterns (console.warn and continue).
- **Extensibility via the message pipeline**: adding a new diagnostic means editing the template catalogs in `scripts/process-messages/templates/` (see `message_code_generation_templates`) and regenerating — both compiler-time and client-runtime catalogs share this pipeline.

## 6. See Also

- [client-reactivity-engine.md](client-reactivity-engine.md) — the signal graph, effects, batching and proxies that these tools observe.
- [client-dom-renderer.md](client-dom-renderer.md) — hydration and rendering internals used by `add_locations` and the HMR wrapper.
- [legacy-compat.md](legacy-compat.md) — the actual Svelte 4 compatibility shims (contrast with the hard *refusals* implemented here).
- [message_code_generation_templates.md](message_code_generation_templates.md) — where all diagnostic texts originate.
- [compiler-transformer_client-transform.md](compiler-transformer_client-transform.md) — how dev-mode call sites are emitted into compiled output.
