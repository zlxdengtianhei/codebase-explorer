# compiler-transformer_css-transform

## 1. Introduction

The **CSS transform** module is the final stage of Svelte's CSS processing pipeline. It converts the *analyzed* CSS AST of a component's `<style>` block into its final, shippable form by rewriting the original stylesheet text with [`MagicString`](https://github.com/Rich-Harris/magic-string) so that:

- **scoped selectors** receive the component's scoping class (`.svelte-<hash>`) using a *specificity-aware* strategy,
- **`:global` / `:global(...)` selectors and `:global { }` blocks** are unwrapped so they compile to plain, unscoped CSS,
- **locally declared `@keyframes`** (and every `animation` / `animation-name` declaration that references them) are namespaced with the component hash,
- **unused and empty rules** are pruned (removed in production, commented out in development),
- **optional minification** strips insignificant whitespace,
- **source maps** are generated and merged with any preprocessor-provided map.

The module owns the selector-scoping and keyframes-scoping semantics that give Svelte its component-level style encapsulation, and it emits the `css` object (`{ code, map, hasGlobal }`) that appears on `CompileResult`.

**Source files:**

| File | Responsibility |
|---|---|
| `packages/svelte/src/compiler/phases/3-transform/css/index.js` | `render_stylesheet` entry point, the zimmerframe visitor set, and all rewrite helpers |
| `packages/svelte/src/compiler/phases/css.js` | Small shared CSS utilities reused across phases (`is_keyframes_node`, `remove_css_prefix`, `regex_css_name_boundary`) |

## 2. Module Architecture

The module is built around a single traversal. `render_stylesheet` drives a `zimmerframe` walk over the `AST.CSS.StyleSheet` node that the [compiler-analyzer_css_analysis](compiler-analyzer_css_analysis.md) phase has already annotated with `metadata.used`, `metadata.scoped`, `metadata.is_global`, `metadata.is_global_block` and `has_local_selectors` flags. Every visitor mutates a shared `State` (the `MagicString` instance plus scoping context) rather than rebuilding the AST — the *edits* to the original source text *are* the output.

```mermaid
flowchart TB
    subgraph MODULE["compiler-transformer_css-transform"]
        direction TB
        RS["render_stylesheet<br/>(public entry point)"]

        subgraph VISITORS["visitors (zimmerframe walk)"]
            W["_ (wildcard):<br/>record sourcemap locations"]
            AT["Atrule:<br/>scope / unscope @keyframes"]
            DE["Declaration:<br/>namespace animation names,<br/>minify values"]
            RU["Rule:<br/>prune empty &amp; unused,<br/>unwrap :global blocks"]
            SL["SelectorList:<br/>prune unused complex selectors,<br/>reset specificity bump"]
            CS["ComplexSelector:<br/>apply scoping class,<br/>strip :global pseudo-classes"]
        end

        subgraph HELPERS["local helpers"]
            H1["is_in_global_block"]
            H2["remove_global_pseudo_class"]
            H3["escape_comment_close"]
            H4["remove_preceding_whitespace<br/>is_empty / is_used"]
        end

        RS --> VISITORS
        VISITORS --> HELPERS
    end

    subgraph SHARED["phases/css.js — shared utilities"]
        KF["is_keyframes_node"]
        RCP["remove_css_prefix"]
        NB["regex_css_name_boundary"]
    end

    subgraph CORE["compiler-core infrastructure"]
        MS["MagicString"]
        MP["merge_with_preprocessor_map"]
        ST["state.js — dev flag"]
    end

    subgraph ANALYSIS["compiler-analyzer_css_analysis (upstream)"]
        CA["css-analyze.js<br/>used / scoped / is_global_block<br/>hash, keyframes, has_global"]
    end

    subgraph RUNTIME["client runtime (client-dom-renderer)"]
        APS["append_styles"]
        CLN["cleanup_styles (dev / HMR)"]
    end

    CA -- "analysis.css:<br/>hash, keyframes, has_global,<br/>ast + selector metadata" --> RS
    AT --> KF
    DE --> RCP
    DE --> NB
    RS --> MS
    RS --> MP
    RS --> ST
    RS -- "css: { code, map, hasGlobal }" --> APS
    APS -.-> CLN
```

### 2.1 Transform state

A single `State` object threads through the walk (see also `TransformState` in [compiler-transformer](compiler-transformer.md) for the JS-side counterpart):

| Field | Type | Purpose |
|---|---|---|
| `code` | `MagicString` | Performs all edits over the original stylesheet text; also produces the source map |
| `hash` | `string` | The component's CSS hash (e.g. `svelte-abc123`), from `analysis.css.hash` |
| `minify` | `boolean` | `analysis.inject_styles && !options.dev` — enables dead-code *removal* and whitespace stripping |
| `selector` | `string` | `.${analysis.css.hash}` — the scoping class injected into selectors |
| `keyframes` | `string[]` | Names of keyframes declared *inside this component* (`analysis.css.keyframes`) |
| `specificity` | `{ bumped: boolean }` | Tracks whether the current selector list has already applied the "strong" scoping class (see §4.1) |

## 3. Position in the Compiler Pipeline

The CSS transform runs during **Phase 3 (transform)**, in parallel with the client/server JS transforms. It depends on Phase 2 (analyze) having computed all decision metadata, and its output is consumed either by the bundler (external CSS) or by the client runtime (injected CSS).

```mermaid
flowchart LR
    SRC["'.svelte' source"] --> P1["Phase 1: parse<br/>(compiler-parser)"]
    P1 -- "Root.css =<br/>AST.CSS.StyleSheet" --> P2["Phase 2: analyze<br/>(compiler-analyzer_css_analysis)"]
    P2 -- "annotated CSS AST +<br/>hash / keyframes / has_global" --> P3["Phase 3: transform"]
    P3 --> JS["client transform<br/>(compiler-transformer_client-transform)"]
    P3 --> SSR["server transform<br/>(compiler-transformer_server-transform)"]
    P3 --> CSSTX["render_stylesheet<br/>(this module)"]
    CSSTX -- "'{ code, map, hasGlobal }'" --> RES["CompileResult.css"]
    RES -- "css: 'injected'" --> RT["embedded in component JS;<br/>append_styles at runtime"]
    RES -- "css: 'external'" --> ASSET["emitted '.css' asset for bundler"]
```

`render_stylesheet` is invoked by the compile orchestrator described in [compiler-core_public_api](compiler-core_public_api.md); the `css_unused_selector` warnings that the analyze phase emits based on the same `metadata.used` flags are documented in [compiler-core_diagnostics](compiler-core_diagnostics.md).

## 4. Core Function Reference

### 4.1 `render_stylesheet(source, analysis, options)`

The single public entry point.

```js
render_stylesheet(source, analysis, options) → { code: string, map: SourceMap, hasGlobal: boolean }
```

**Steps:**

1. Wraps the raw `<style>` content in a `MagicString`.
2. Builds the `State` described in §2.1 (minify only when styles will be injected into JS *and* the build is not a dev build).
3. Walks the analyzed `AST.CSS.StyleSheet` with `visitors`.
4. Trims everything outside the stylesheet bounds (`ast.content.start … ast.content.end`); if minifying, also strips whitespace preceding the end.
5. Generates a source map with `includeContent: true`, `source: options.filename`, `file: options.cssOutputFilename || options.filename`.
6. Merges the map with any map produced by `svelte.preprocess` via `merge_with_preprocessor_map` — so positions survive the round trip back to the original pre-preprocessed file.
7. In dev mode with `css: 'injected'`, appends a `/*# sourceMappingURL=<data URL> */` comment so browser devtools can map injected styles.
8. Returns `{ code, map, hasGlobal }`, where `hasGlobal` mirrors `analysis.css.has_global` (the stylesheet contains unscoped/`:global` selectors — significant for bundler-level deduplication and runtime style bookkeeping).

```mermaid
sequenceDiagram
    participant C as compile orchestrator
    participant RS as render_stylesheet
    participant W as walk (zimmerframe)
    participant V as visitors
    participant MS as MagicString

    C->>RS: source, analysis, options
    RS->>MS: new MagicString(source)
    RS->>RS: build State (hash, minify, selector, keyframes)
    RS->>W: walk(css.ast, state, visitors)
    loop over each CSS node
        W->>V: dispatch visitor
        V->>MS: scope / unwrap / prune / minify edits
    end
    RS->>MS: trim outside ast.content bounds
    RS->>MS: generateMap({ includeContent: true })
    Note over RS: merge_with_preprocessor_map<br/>(reconcile with svelte.preprocess map)
    RS-->>C: { code, map, hasGlobal }
```

### 4.2 The visitor set

The wildcard visitor (`_`) registers `addSourcemapLocation` for **every** node's start and end before recursing, guaranteeing fine-grained map fidelity.

| Visitor | Responsibility |
|---|---|
| **`Atrule`** | Detects `@keyframes` (via `is_keyframes_node`, which tolerates vendor prefixes like `@-webkit-keyframes`). Locates the keyframes *name* token: if the prelude starts with `-global-`, the 8-character prefix is deleted (truly global keyframes); otherwise the component hash is prepended (`spin` → `svelte-abc123-spin`) **unless** the at-rule sits inside a `:global { }` block. Returns early — nothing inside keyframes is scoped or pruned. |
| **`Declaration`** | After normalizing the property with `remove_css_prefix` (strips `-webkit-`/`-moz-`/`-o-`/`-ms-`): for `animation` / `animation-name`, scans the value character-by-character using `regex_css_name_boundary` (`/^[\s,;}]$/`) to split names, and prepends the hash to any name present in `state.keyframes` — keeping JS-side animation references and CSS declarations in sync. When minifying, strips whitespace between property and value, **except** for custom properties (`--foo`) because old Chromium treats `--foo: ;` and `--foo:;` differently. |
| **`Rule`** | The pruning and global-block visitor (details in §5). |
| **`SelectorList`** | Prunes individual `ComplexSelector`s whose `metadata.used` is `false` (comment out or remove, trimming the correct surrounding commas), unless we are inside an unused complex selector or a global block. Then computes the **specificity bump state** for the child `ComplexSelector`s: fresh `{ bumped: false }` for the list's owning rule, flipped to `bumped: true` if any *ancestor* rule `metadata.has_local_selectors` — so nested rules keep their ancestor's bump and don't stack specificity. |
| **`ComplexSelector`** | Per *relative selector* (compound selector): if `metadata.is_global`, calls `remove_global_pseudo_class` (and, for nested bare `:global.x`, rewrites it to `&.x` by prepending `&`; also removes the now-orphaned comma when the following selector in the parent rule's list is used). If `metadata.scoped`, appends the scoping class using the first-bump / rest-`:where` strategy (§4.1 / §6). Restores the previous `specificity.bumped` value after recursing. |
| **`PseudoClassSelector`** | Only recurses into the *functional* pseudo-classes `:is`, `:where`, `:has`, `:not`, so selectors inside their argument lists are scoped as well; other pseudo-classes are left untouched. |

### 4.3 `is_in_global_block(path)`

```js
is_in_global_block(path) → boolean
```

Returns `true` if any node on the walk `path` is a `Rule` with `metadata.is_global_block`, i.e. the traversal is inside a `:global { ... }` block. Inside global blocks, scoping, pruning and keyframes hashing are all suppressed. Note this is a *deliberate duplicate* of the same helper in `css-analyze.js` — each phase keeps its own copy so it can operate on its own walk context.

### 4.4 `remove_global_pseudo_class(selector, combinator, state)`

Erases the `:global` marker from the emitted text:

- **Bare `:global` (`args === null`)**: blanks the `:global` text via `code.update(...)`. `update` — not `remove` — is used deliberately: a pruning comment (`/* (unused) ... */`) may already sit at the end of the range, and removing content would corrupt it. When the preceding combinator is a descendant combinator (`' '`), preceding whitespace is also retracted so `div :global.x` becomes `div.x`.
- **Functional `:global(...)`**: removes only the `:global(` opener and the matching `)`, leaving the inner selector intact — `:global(.foo)` becomes `.foo`.

### 4.5 `escape_comment_close(node, code)`

Supports the dev-mode "comment out instead of delete" strategy. When a rule is wrapped in an outer `/* ... */` pair, any `*/` *already inside* the wrapped text (i.e. the end of a nested CSS comment) would terminate the wrapper early. This helper scans the node's range tracking escape (`\`) and comment state, and inserts a backslash before every nested `*/` → `*\/`, which is inert inside a CSS comment.

### 4.6 Shared utilities (`phases/css.js`)

| Export | Signature | Used by |
|---|---|---|
| `is_keyframes_node` | `(node: AST.CSS.Atrule) => boolean` — `remove_css_prefix(node.name) === 'keyframes'` | `Atrule` visitor; also the analyze phase's keyframes collection |
| `remove_css_prefix` | `(name: string) => string` — strips the browser-prefix regex `/^-((webkit)\|(moz)\|(o)\|(ms))-/` | `Declaration` visitor, keyframes detection |
| `regex_css_name_boundary` | `/^[\s,;}]$/` | character-level name splitting in the `Declaration` visitor |
| `regex_css_browser_prefix` | (internal) | `remove_css_prefix` |

## 5. Pruning Semantics (`Rule` and `SelectorList` visitors)

Pruning decisions all derive from `metadata.used`, computed by the analyze phase (see [compiler-analyzer_css_analysis](compiler-analyzer_css_analysis.md)). Behavior differs by mode:

| Situation | dev (`minify: false`) | production (`minify: true`) |
|---|---|---|
| **Empty rule** (no used declarations/children) | Kept, commented as `/* (empty) … */` — empty rules are visible in devtools | Removed (whitespace ahead of it cleaned up) |
| **Unused rule** (`is_used` false, not in global block) | Commented as `/* (unused) … */` with `escape_comment_close` protection | Removed |
| **Unused complex selector inside a used list** | `/* (unused) */` wrapped around the specific selector(s) | Selector(s) plus surrounding comma removed |
| **`:global { }` block** | Selector part and braces commented out; declarations remain, **never pruned or scoped** | Same, but braces removed outright |

Additional details:

- `is_empty` recurses into nested rules — a rule containing only unused children counts as empty — and treats `:global` blocks according to their own child count.
- `is_used` checks whether *any* complex selector in the rule's prelude is used (a rule survives if at least one selector matched template elements).
- The `SelectorList` pruning loop tracks `prune_start`, `last` and `has_previous_used` so that the correct side of each comma is trimmed in minify mode (e.g. `a, b, c` with `b` unused → `a, c`), while dev mode wraps precisely the unused selector in a comment.

## 6. Scoping & Specificity Strategy

The scoping mechanism is the heart of the module. For each **relative selector** (compound selector inside a complex selector) marked `metadata.scoped`:

```mermaid
flowchart TD
    START["relative selector<br/>(compound selector)"] --> G{"metadata.is_global?"}
    G -- "yes" --> RM["remove_global_pseudo_class<br/>':global' → ''<br/>':global(x)' → 'x'<br/>nested bare ':global.x' → '&amp;.x'"]
    G -- "no" --> S{"metadata.scoped?"}
    S -- "no" --> NEXT["leave untouched"]
    S -- "yes" --> K{"standalone :is / :where,<br/>or contains NestingSelector (&amp;)?"}
    K -- "yes" --> NEXT
    K -- "no" --> B{"state.specificity.bumped?"}
    B -- "false (first in list)" --> PLAIN["append '.svelte-hash'<br/>→ +0-1-0 specificity bump"]
    B -- "true" --> WHERE["append ':where(.svelte-hash)'<br/>→ zero specificity"]
    PLAIN --> SET["specificity.bumped = true"]
    SET --> NEXT2["next relative selector"]
    WHERE --> NEXT2
    RM --> NEXT2
```

**Insertion point** — the visitor walks the compound selector *backwards* to find where the modifier goes:

- Pseudo-elements/pseudo-classes are skipped (`div:hover` → `div.svelte-hash:hover`), except `:root`/`:host`, which are left completely unmodified.
- If the compound is *only* pseudo-classes (e.g. `:hover`), the modifier is prepended (`:hover` → `.svelte-hash:hover`).
- A universal selector `*` is **replaced** by the modifier (`*` → `.svelte-hash`); any other selector receives the modifier appended after it.

**Specificity policy** — the *first* scoped relative selector of a selector list gets the plain class (guaranteeing every scoped rule at least one class' worth of specificity, needed to beat pre-existing global styles); all *subsequent* scoped selectors use `:where(.svelte-hash)`, which adds zero specificity, so nesting doesn't cause specificity explosions. For rules nested inside other rules, `SelectorList` seeds `bumped: true` when an ancestor rule has local selectors, so the ancestor's single bump covers the whole tree.

### End-to-end example

Given hash `svelte-abc123` (dev mode, non-minified):

```css
/* input */                              /* output */
div { color: red; }                      div.svelte-abc123 { color: red; }

:global(.active) div, span {             .active div, span.svelte-abc123 {
  color: blue;                             color: blue;
}                                        }

@keyframes spin {                        @keyframes svelte-abc123-spin {
  from { opacity: 0 }                      from { opacity: 0 }
}                                        }

div { animation: spin 1s linear; }       div.svelte-abc123 { animation: svelte-abc123-spin 1s linear; }

.deleted { color: green; }               /* (unused) .deleted { color: green; } */

:global {                                /* .panel { */ .panel { color: teal; } /* } */
  .panel { color: teal; }
}

@-global-keyframes fade { }              @keyframes fade { }
```

Note how `:global(.active) div` stays unscoped on its left side, while the sibling `span` in the same list is scoped and takes the first bump; the `.deleted` rule is commented (not deleted) because dev preserves evidence of *why* code was dropped.

## 7. Runtime Integration

When `css: 'injected'`, the client transform (see [compiler-transformer_client-transform](compiler-transformer_client-transform.md)) embeds the emitted `code` into the component and calls `append_styles` from the client runtime (see [client-dom-renderer](client-dom-renderer.md)), which inserts a `<style id={hash}>` into `document.head` (or the nearest `ShadowRoot`, enabling same-hash styles to be scoped per shadow tree). In dev, `register_style`/`cleanup_styles` bookkeep these tags for HMR replacement. The `specificity bump` strategy matters here: because injected styles compete with global stylesheet order, Svelte guarantees the deterministic `+0-1-0` bump per rule.

For `css: 'external'`, the same output is simply handed to the bundler as an asset; `hasGlobal` lets tooling know the stylesheet contains component-agnostic (global) rules.

## 8. Error & Warning Surface

The transform itself throws no diagnostics — validation happens earlier:

- `css_unused_selector` warnings (see [compiler-core_diagnostics](compiler-core_diagnostics.md)) are emitted during *analyze*, based on the same `metadata.used` flags consumed here.
- `:global`-related *errors* (`css_global_block_invalid_*`, `css_global_invalid_*`, `css_nesting_selector_invalid_placement`, `css_type_selector_invalid_placement`) are enforced by the analyze phase, so `render_stylesheet` can assume structurally valid global usage.

## 9. Design Notes & Invariants

1. **Text surgery, not AST re-generation** — all changes are `MagicString` edits, which keeps positions valid for source maps and preserves the author's formatting outside edited regions.
2. **Analyze/transform contract** — the transform *trusts* the metadata produced by [compiler-analyzer_css_analysis](compiler-analyzer_css_analysis.md) (`used`, `scoped`, `is_global`, `is_global_block`, `has_local_selectors`, `parent_rule` chains); it contains no selector-matching logic of its own.
3. **Dev/prod parity with evidence** — dev mode comments out pruned code (`(unused)` / `(empty)`) so developers can see what was dropped and why; production removes it outright.
4. **Keyframes are namespaced, never inlined** — both the `@keyframes` declaration and every local `animation`/`animation-name` reference receive the same hash prefix, including inside vendor-prefixed at-rules.
5. **`:global` unwrapping is purely textual** — `remove_global_pseudo_class` edits only the `:global` tokens, so selectors like `:global(.a):hover` survive with their other pseudo-classes intact.
6. **Sourcemap completeness** — every AST node boundary is registered as a sourcemap location, and the final map is reconciled with preprocessor maps so positions point at the original (e.g. TypeScript-preprocessed) source file.