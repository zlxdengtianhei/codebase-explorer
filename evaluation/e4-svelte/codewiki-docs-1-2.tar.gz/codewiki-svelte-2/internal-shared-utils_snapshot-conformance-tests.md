# internal-shared-utils — snapshot-conformance-tests

> **Module path:** `packages/svelte/src/internal/shared/clone.test.ts`
> **Parent module:** [internal-shared-utils](internal-shared-utils.md)
> **Grandparent subsystem:** Server-Side Rendering & Cross-Target Runtime Services

## 1. Introduction

The **snapshot-conformance-tests** module is the behavioral contract suite for Svelte's `$state.snapshot` utility — implemented as `snapshot()` in `packages/svelte/src/internal/shared/clone.js`. Because `snapshot()` is a **cross-target shared utility** (used by both client reactive state and server-side rendering paths), its semantics must be pinned down precisely: deep-clone behavior, cycle handling, proxy unwrapping, class/toJSON treatment, and — critically for developers — the exact dev-mode diagnostics emitted when a value cannot be cloned.

The module's sole core component, **`capture_warnings()`**, is a test-local console interceptor that makes those diagnostics assertable. It monkey-patches `console.warn`, records every warning string emitted during a test, and returns a restore-and-collect closure that reinstates the original logger.

In the broader repository, this suite is the only executable specification of the `state_snapshot_uncloneable` warning's message format, path-listing layout, and truncation policy.

## 2. Position in the System

```
Server-Side Rendering & Cross-Target Runtime Services
└── internal-shared-utils                        ← shared, isomorphic runtime helpers
    ├── core-utilities        (utils.js: noop, run, to_array)
    ├── validation-guards     (validate.js)
    ├── error-messages        (errors.js)
    └── snapshot-conformance-tests  ← THIS MODULE (clone.test.ts)
```

While its siblings (`core-utilities`, `validation-guards`, `error-messages`) ship *inside* the compiled bundle, this module is **test-only code**: it is never imported by runtime code and is excluded from published artifacts. Its influence is contractual — it fails CI when `snapshot()` drifts from its specified behavior, protecting every downstream consumer (the client reactivity engine's proxy unwrapping, dev tooling, and the documented `$state.snapshot` public API).

## 3. Core Component: `capture_warnings()`

### 3.1 Signature and behavior

```typescript
function capture_warnings(): () => string[]
```

| Phase | Action |
|---|---|
| **Install** | Saves a reference to the original `console.warn`, then replaces it with a stub that pushes each message argument into a private `warnings: string[]` array. |
| **Capture** | While installed, every `console.warn(...)` call — including those routed through `state_snapshot_uncloneable()` — is silently recorded instead of printed. |
| **Restore & collect** | The returned closure reinstates the original `console.warn` and returns the accumulated message array for assertion. |

The design is intentionally minimal:

- **No global state leaks** — each test creates a fresh interceptor; restoring before assertions guarantees subsequent tests see the real logger.
- **First-argument fidelity** — the stub records only the message argument, not the style arguments (`bold`/`normal` `%c` payloads) emitted alongside it, so assertions match against the human-readable string exactly.
- **Closure scoping** — the `warnings` array is unreachable except through the returned closure, making the fixture immune to cross-test pollution.

### 3.2 Lifecycle

```mermaid
sequenceDiagram
    autonumber
    participant T as Test case
    participant CW as capture_warnings
    participant C as console
    participant S as snapshot() [clone.js]
    participant W as state_snapshot_uncloneable() [warnings.js]

    T->>CW: const restore = capture_warnings()
    CW->>C: save original console.warn
    CW->>C: console.warn = (msg) => warnings.push(msg)
    CW-->>T: restore closure

    T->>S: snapshot(uncloneableValue)
    S->>S: clone() collects uncloneable paths
    S->>W: state_snapshot_uncloneable(pathList)
    W->>C: console.warn(formattedMessage, bold, normal)
    C-->>CW: stub records formattedMessage

    T->>CW: const warnings = restore()
    CW->>C: console.warn = original
    CW-->>T: string[] of captured messages
    T->>T: assert.deepEqual(warnings(), [expected])
```

## 4. Architecture & Component Relationships

```mermaid
flowchart TB
    subgraph THIS["snapshot-conformance-tests (this module)"]
        TESTFILE["clone.test.ts<br/>11 conformance tests"]
        CW["capture_warnings()<br/>console.warn interceptor"]
    end

    subgraph SUT["internal-shared-utils — system under test"]
        SNAPSHOT["snapshot(value, skip_warning, no_tojson)<br/>clone.js"]
        CLONE["clone()<br/>recursive deep clone + path tracking"]
        WARNFN["state_snapshot_uncloneable()<br/>warnings.js (DEV console.warn)"]
        SNAPSHOT --> CLONE
        SNAPSHOT -->|"DEV + uncloneable paths"| WARNFN
    end

    subgraph CLIENT["client-reactivity-engine (test dependency)"]
        PROXY["proxy(value)<br/>proxy.js — reactive state wrapper"]
    end

    VITEST["vitest<br/>test() / assert"]

    TESTFILE --> CW
    TESTFILE -->|"imports { snapshot }"| SNAPSHOT
    TESTFILE -->|"imports { proxy }"| PROXY
    TESTFILE --> VITEST
    WARNFN -->|"console.warn()"| CW
```

**Dependency notes**

| Dependency | Kind | Reason |
|---|---|---|
| `./clone` → `snapshot` | System under test | The entire suite exercises its clone/warn contract. |
| `../client/proxy` → `proxy` | Test fixture only | Fabricates genuinely reactive state so the "proxied state" test proves snapshots *detach* from the signal graph. See [client-reactivity-engine_sources-and-proxies](client-reactivity-engine_sources-and-proxies.md). |
| `vitest` | External framework | `test` runner and `assert` matchers. |
| `warnings.js` (indirect) | Assertion target | The interceptor's raison d'être — verifying its exact output format. |

> This is the only place where `internal-shared-utils` reaches **upward** into the client runtime engine — but only at test time. The runtime dependency graph itself remains one-directional; see [client-reactivity-engine_signal-graph](client-reactivity-engine_signal-graph.md) for the production-side counterpart.

## 5. Conformance Contract (Test Inventory)

Each test pins one clause of the `snapshot()` contract. Together they form the executable specification of `$state.snapshot`.

### 5.1 Cloning semantics

| Test | Fixture | Contract clause | Warning asserted |
|---|---|---|---|
| `primitive` | `42` | Primitives pass through by value (`assert.equal`) | — |
| `array` | `[1, 2, 3]` | Deep-equal copy, **new reference** (`deepEqual` + `notEqual`) | — |
| `object` | `{ a, b, c }` | Deep-equal copy, **new reference** | — |
| `proxied state` | `proxy({ a: { b: { c: 1 } } })` | Reactive proxies deeply unwrapped to plain state; snapshot is **isolated** — mutating `object.a.b.c = 2` afterwards leaves `copy.a.b.c === 1` | — |
| `cycles` | `object.self = object` | Cycle-safe: `copy.self === copy` (identity preserved *within* the snapshot via the internal `cloned` memo `Map`) | — |
| `class with state field` | class with own `x`, private `#y` + getter | Only **own enumerable** fields are cloned (`{ x: 1 }`); prototype getters and privates are dropped | — |
| `class with toJSON` | class implementing `toJSON()` | `toJSON()` output is cloned in place of the instance (`{ x: 1, y: 2 }`) | — |
| `reactive class` | `class SvelteMap extends Map` | Built-in subclasses are **downgraded** to plain built-ins (`instanceof Map`, not `instanceof SvelteMap`) | — |

### 5.2 Uncloneable-value diagnostics

| Test | Fixture | Contract clause | Warning asserted |
|---|---|---|---|
| `uncloneable value` | top-level `() => {}` | Original reference returned; **whole-value** warning emitted | 1 message: `Value cannot be cloned with \`$state.snapshot\` — the original value was returned` |
| `uncloneable properties` | object mixing cloneable and uncloneable props (`a`, `b`, `c[0..7]`) | Uncloneable members returned **by reference** (`copy.a === object.a`), cloneable containers still copied (`copy.c !== object.c`); **one aggregated** warning lists all offending paths | Path list: `- <value>.a`, `- <value>.b`, `- <value>.c[0]` … `- <value>.c[7]` |
| `many uncloneable properties` | array of 100 functions | Truncation policy for large path sets | Truncated list: first 7 entries + `- ...and 93 more` |

### 5.3 Warning message format (asserted verbatim)

All diagnostics tests assert the full three-line envelope produced by `state_snapshot_uncloneable()`:

```
%c[svelte] state_snapshot_uncloneable
%c<body>
https://svelte.dev/e/state_snapshot_uncloneable
```

- Line 1/2 prefixes (`%c`) correspond to `bold` / `normal` style arguments applied by the warning function; the interceptor records only the message string, so the envelope (including `%c`) is part of the pinned contract.
- `<body>` is either the whole-value sentence or the `The following properties cannot be cloned...` path listing.
- The trailing URL is the stable developer-facing documentation link.

## 6. Data Flow: Warning Generation → Capture → Assertion

```mermaid
flowchart TD
    A["snapshot(value) in DEV mode"] --> B["clone() recursively walks value,<br/>recording DEV paths ('.prop' / '[i]') for each<br/>structuredClone failure into paths[]"]
    B --> C{"paths.length?"}
    C -->|"0"| D["no warning — clean clone returned"]
    C -->|"1 and paths[0] === ''"| E["whole-value failure:<br/>state_snapshot_uncloneable()"]
    C -->|"> 1"| F["partial failure:<br/>format path list"]
    F --> G{"paths.length > 10?"}
    G -->|"yes"| H["slice first 7 paths +<br/>'- ...and N more'"]
    G -->|"no"| I["list up to 10 paths"]
    E --> J["console.warn(envelope, bold, normal)"]
    H --> J
    I --> J
    J --> K["capture_warnings stub<br/>pushes message into warnings[]"]
    K --> L["restore() returns warnings[]<br/>assert.deepEqual pins exact output"]
```

**Path notation contract:** object keys render as `<value>.key`, array indices as `<value>[i]` — derived directly from the DEV path strings built inside `clone()`. Any change to that notation will (correctly) fail this suite.

## 7. Process Flow: How the Suite Runs

```mermaid
flowchart LR
    subgraph CI["Test execution (vitest)"]
        direction TB
        T1["clone.test.ts loaded"] --> T2["import snapshot, proxy, vitest"]
        T2 --> T3["tests run sequentially in file:<br/>each capture_warnings() install →<br/>act → restore → assert"]
        T3 --> T4["console.warn restored after every test —<br/>no leakage across cases"]
    end
    T4 -->|pass| OK["Contract held — snapshot() may ship"]
    T4 -->|fail| FAIL["CI blocks — snapshot()/warnings/paths drifted"]
```

## 8. Maintenance & Extension Guide

**Adding a warning-asserting test** (canonical pattern):

```typescript
test('my new case', () => {
	const warnings = capture_warnings();          // 1. install interceptor FIRST
	const copy = snapshot(/* value */);           // 2. act
	assert.deepEqual(warnings(), [/* exact */]);  // 3. restore + assert exact strings
});
```

Rules to keep the contract airtight:

1. **Install before acting.** `capture_warnings()` must wrap the `snapshot()` call, or early warnings are lost.
2. **Always consume the returned closure.** It both restores `console.warn` and yields the array — asserting against a stale reference skips the restore step.
3. **Assert full strings, not substrings.** `deepEqual` against the complete expected message is what makes this a conformance suite; `assert.ok(warnings()[0].includes(...))` would let format regressions slip through.
4. **Remember DEV gating.** Warnings (and path collection) only occur in DEV builds of the runtime; production-mode behavior (silent clone-with-originals fallback) is exercised implicitly by the same tests because `snapshot()` itself is called in-process.

Known fragility to keep in mind: the suite patches the *global* `console`. Vitest runs test files in parallel but tests within a file sequentially, so the patch/unpatch windows never overlap — do not introduce concurrent warning capture within a single file.

## 9. Related Documentation

- [internal-shared-utils](internal-shared-utils.md) — parent module: shared isomorphic runtime helpers.
- [internal-shared-utils_core-utilities](internal-shared-utils_core-utilities.md) — `noop` / `run` / `to_array`, the production siblings guarded by this suite's quality bar.
- [internal-shared-utils_error-messages](internal-shared-utils_error-messages.md) — the DEV-gated error pattern (`Error` with doc URL) that `state_snapshot_uncloneable`'s warning mirrors.
- [internal-shared-utils_validation-guards](internal-shared-utils_validation-guards.md) — dev-mode validation guards for dynamic elements.
- [client-reactivity-engine_sources-and-proxies](client-reactivity-engine_sources-and-proxies.md) — the `proxy()` implementation used as a test fixture; explains the signal sources a snapshot must detach from.
- [client-reactivity-engine_signal-graph](client-reactivity-engine_signal-graph.md) — production signal graph that `$state.snapshot` consumers escape.
