# Stores Bridge — Interoperability Between Svelte Stores and Runes

## 1. Overview

`stores_bridge` is the two-way adapter that lets Svelte's **legacy store contract** (`Readable`/`Writable` objects exposing `subscribe`/`set`/`update`) and Svelte 5's **runes-based reactivity** (`$state`, effects, the signal graph) work together inside a single component.

It exports exactly two conversion functions, each available in a client and a server (SSR) variant:

| Export | Direction | Purpose |
|---|---|---|
| `toStore(get, set?)` | Runes → Store | Wrap rune-backed state (a getter, optionally a setter) as a store consumable by `$:`-era code, legacy components, or any store-compliant consumer. |
| `fromStore(store)` | Store → Runes | Expose a store as a plain object with a reactive `current` property that can be read (and written, if writable) directly in runes mode. |

**Source files** (both are also the platform entry points for the entire `svelte/store` namespace):

- `packages/svelte/src/store/index-client.js` — reactive, effect-aware implementations selected by bundler export conditions for browser/client bundles.
- `packages/svelte/src/store/index-server.js` — simplified, non-reactive implementations used during server-side rendering.

Both files re-export the platform-independent store API from the shared core:

```js
export { derived, get, readable, readonly, writable } from './shared/index.js';
```

This means the client/server split applies to the whole `svelte/store` surface, but `fromStore`/`toStore` are the **only** members whose behaviour genuinely differs between the two targets.

## 2. Role in the System

`stores_bridge` sits at the seam between three neighbouring subsystems:

```mermaid
flowchart TB
    subgraph pub["Public API (svelte/store entry points)"]
        IC["index-client.js"]
        IS["index-server.js"]
    end

    subgraph bridge["stores_bridge (this module)"]
        TS["toStore"]
        FS["fromStore"]
    end

    subgraph core["Store world"]
        CORE["stores_core<br/>writable / readable / derived / get"]
        CONTRACT["stores_contract<br/>Readable / Writable types"]
    end

    subgraph runes["Runes world (Svelte 5 reactivity)"]
        SIGNALS["client-reactivity-engine<br/>signal graph (active_effect / active_reaction)"]
        EFFECTS["client-reactivity-engine<br/>effect_root / render_effect / effect_tracking"]
        SUBSCR["reactive-builtins<br/>createSubscriber"]
    end

    IC --> TS & FS
    IS --> TS & FS
    TS -->|"writable(value, start)"| CORE
    FS -->|"get(store) fallback"| CORE
    TS & FS -.->|"shapes of"| CONTRACT
    TS -->|"capture + restore context"| SIGNALS
    TS -->|"effect_root + render_effect"| EFFECTS
    FS -->|"lazy ref-counted subscription"| SUBSCR
    FS -->|"effect_tracking()"| EFFECTS
```

- **Upstream contract**: the shape of stores is defined in `stores_contract` (`Readable`, `Writable`, `StartStopNotifier`, …). See [stores_contract.md](stores_contract.md).
- **Downstream engine**: `toStore` builds on `writable`/`get` from the shared core — see [stores_core.md](stores_core.md) — and on the signal runtime documented in [client-reactivity-engine_signal-graph.md](client-reactivity-engine_signal-graph.md) and [client-reactivity-engine_effects.md](client-reactivity-engine_effects.md).
- **Subscription primitive**: the client `fromStore` uses `createSubscriber` (documented with the reactive built-ins, [reactive-builtins_media-query.md](reactive-builtins_media-query.md)) for lazily managed, ref-counted store subscriptions.

The whole mechanism is bidirectional and lossless in intent: state expressed with runes can be exposed as a store, and stores can be consumed as if they were rune-backed objects.

## 3. Architecture

### 3.1 Two targets, one API

The bundler-facing export map chooses one of the two files per environment:

```mermaid
flowchart LR
    SRC["svelte/store"] -->|"browser condition"| CLIENT["index-client.js<br/>reactive implementation"]
    SRC -->|"node/server condition"| SERVER["index-server.js<br/>snapshot implementation"]
    CLIENT --> SHARED["store/shared/index.js<br/>(re-exported verbatim)"]
    SERVER --> SHARED
```

| Aspect | `index-client.js` | `index-server.js` |
|---|---|---|
| Reactivity model | Full signal graph: effects, tracking, batching | None — SSR renders once, output is static HTML |
| `toStore` | Live: a tracked `render_effect` pushes state changes into the store while subscribed | Snapshot: `writable(get())` captures the value once |
| `fromStore` | Lazily subscribes via `createSubscriber` while `current` is read inside a tracked effect | `current` getter calls `get(store)` on every access |
| Extra dependencies | `internal/client/reactivity/*`, `internal/client/runtime.js` | Only `store/shared/index.js` |

### 3.2 The two conversion directions

```mermaid
flowchart LR
    subgraph runesSide["Runes world"]
        STATE["let count = $state(0)"]
        CUR["obj.current"]
    end
    subgraph bridge["stores_bridge"]
        TOSTORE["toStore(get, set?)"]
        FROMSTORE["fromStore(store)"]
    end
    subgraph storeSide["Store world"]
        STORE["writable / readable<br/>subscribe / set / update"]
    end

    STATE -- "get()/set() closures" --> TOSTORE
    TOSTORE -- "Readable/Writable object" --> STORE
    STORE -- "store object" --> FROMSTORE
    FROMSTORE -- "{ current } object" --> CUR
```

## 4. Public Surface

### 4.1 `toStore(get, set?)` — runes state as a store

Two overloads:

- `toStore(get: () => V, set: (v: V) => void) → Writable<V>`
- `toStore(get: () => V) → Readable<V>`

```js
import { toStore } from 'svelte/store';

let count = $state(0);

const store = toStore(() => count, (v) => (count = v));
```

Behaviour:

1. Snapshots `get()` as the store's initial value.
2. The heavy lifting happens inside the **start/stop notifier** passed to `writable` — i.e. only while at least one subscriber exists.
3. If `set` is provided, the returned object exposes `set`/`update` that delegate **directly to the caller's setter** (bypassing the internal store value — writes always go straight to the rune state); otherwise only `subscribe` is exposed, making the result a `Readable`.

### 4.2 `fromStore(store)` — stores as reactive objects

Two overloads:

- `fromStore(store: Writable<V>) → { current: V }` (read/write)
- `fromStore(store: Readable<V>) → { readonly current: V }`

```js
import { fromStore, get, writable } from 'svelte/store';

const count = fromStore(writable(0));

count.current;     // 0
count.current += 1;
get(store);        // 1
```

Behaviour:

- Reads of `current` inside a reactive context subscribe to the store and keep `current` live.
- Reads outside any reactive context fall back to a synchronous one-shot read.
- Writes to `current` (only present when the store has a `set` method) delegate to `store.set(v)`.

## 5. Client Implementation (`index-client.js`)

### 5.1 `toStore` — tracking rune state inside a store's lifecycle

```js
export function toStore(get, set) {
    var effect = active_effect;      // capture caller context…
    var reaction = active_reaction;  // …at creation time
    var init_value = get();

    const store = writable(init_value, (set) => {
        // if the value changed before first subscribe, it must be pushed now
        var ran = init_value !== get();

        var previous_reaction = active_reaction;
        var previous_effect = active_effect;
        set_active_reaction(reaction);   // re-enter the captured context
        set_active_effect(effect);
        try {
            teardown = effect_root(() => {
                render_effect(() => {
                    const value = get();
                    if (ran) set(value);
                });
            });
        } finally {
            set_active_reaction(previous_reaction); // restore
            set_active_effect(previous_effect);
        }
        ran = true;
        return teardown; // stops the effects when the last subscriber leaves
    });
    // returns { set, update, subscribe } (writable) or { subscribe } (readable)
}
```

Key mechanics:

1. **Context capture.** `active_effect` and `active_reaction` are captured *when `toStore()` is called* — i.e. inside the component/initialisation scope — and re-installed when the store's notifier starts later. This scopes the tracking effect to the creating component, which matters for teardown order and HMR.
2. **Lifecycle-bound reactivity.** `effect_root(() => render_effect(...))` creates the tracking effect only for the duration of an active subscription: the notifier runs on the *first* subscriber, the returned teardown runs when the subscriber count drops back to zero. A store nobody listens to costs nothing.
3. **The `ran` flag.** The first run of the render effect is suppressed unless the underlying state changed between `toStore()` and the first subscription. Without this, the effect would redundantly `set()` the same initial value (or, worse, the effect would look like the only "delivery" of the initial value to any subscriber that joins later — `writable` already replays the current value to every new subscriber).
4. **Write-through.** For writable results, `set`/`update` bypass the internal store entirely:
   - `set(v)` → calls the user setter directly (writes the rune state),
   - `update(fn)` → `set(fn(get()))` reads the *live rune state*, applies `fn`, writes back.

```mermaid
sequenceDiagram
    participant C as Component ($state)
    participant TS as toStore store
    participant W as writable
    participant E as render_effect (tracked)
    participant S as Subscribers

    C->>TS: toStore(get, set)
    TS->>W: writable(get(), start)
    Note over TS,E: store dormant — no effects yet
    S->>W: subscribe(run)
    W->>TS: start(set)  [first subscriber]
    TS->>E: effect_root + render_effect
    E->>C: get()  (tracked dependency)
    Note over E: ran = false ⇒ skip first push
    C->>C: count = 42 ($state write)
    E->>W: set(42)
    W->>S: run(42)
    S->>W: unsubscribe (last one)
    W->>TS: teardown()
    TS->>E: destroy effects
```

### 5.2 `fromStore` — lazily subscribed, ref-counted bridge

```js
export function fromStore(store) {
    let value = undefined;

    const subscribe = createSubscriber((update) => {
        let ran = false;
        const unsubscribe = store.subscribe((v) => {
            value = v;
            if (ran) update();   // invalidate dependents on later emissions
        });
        ran = true;
        return unsubscribe;
    });

    function current() {
        if (effect_tracking()) {
            subscribe();   // registers tracking, starts the subscription
            return value;  // cached, kept fresh by the subscription
        }
        return get(store); // one-shot read outside reactive contexts
    }

    if ('set' in store) {
        return {
            get current() { return current(); },
            set current(v) { store.set(v); }
        };
    }
    return { get current() { return current(); } };
}
```

Key mechanics:

1. **`createSubscriber` (lazy + ref-counted).** The store subscription starts only when some effect actually reads `current`, and is torn down — with a deliberate *microtask delay* — when the last reading effect stops. The version counter inside `createSubscriber` is bumped on every store emission and on teardown/restart boundaries so dependent deriveds are correctly dirtied.
2. **Two read modes.**
   - *Reactive context* (`effect_tracking()` is true): `subscribe()` installs a render effect that both manages the underlying store subscription and makes the read a tracked dependency; the cached `value` is returned.
   - *Non-reactive context* (plain JS, event handlers): falls back to `get(store)` — a subscribe→capture→unsubscribe one-shot that goes through `subscribe_to_store` and therefore even tolerates RxJS-style observables (`unsub.unsubscribe`).
3. **Value cache + `update()`.** While subscribed, store emissions write into the `value` cache and call `update()` to bump the version, which invalidates every reactive consumer of `current`. The `ran` flag suppresses the redundant invalidation for the initial synchronous delivery.
4. **Write shape detection.** `'set' in store` decides whether `current` is a getter/setter pair (writable) or a getter only (readable).

```mermaid
sequenceDiagram
    participant ST as Store (writable)
    participant CS as createSubscriber
    participant FG as fromStore
    participant E as Consumer effect

    E->>FG: read obj.current (in effect)
    FG->>FG: effect_tracking() === true
    FG->>CS: subscribe()
    CS->>ST: store.subscribe(v => …)
    ST-->>FG: v (initial) → value cache
    FG-->>E: value
    ST->>CS: set(next) → update()
    CS->>E: version bumped → effect re-runs
    E->>FG: read obj.current
    FG-->>E: next
    Note over E,CS: effect destroyed
    CS->>ST: unsubscribe (after microtask)
```

## 6. Server Implementation (`index-server.js`)

During SSR there is no signal graph, no effects and no subscription lifetime to manage — the server versions are deliberately minimal:

- **`toStore(get, set?)`** → `writable(get())`: a one-shot snapshot of the getter's value. If `set` was supplied, `set`/`update` still delegate to it (harmless during render, useful if the object escapes into hydration code paths); otherwise the result is read-only.
- **`fromStore(store)`** → `{ get current() { return get(store); } }`: every access performs a fresh synchronous read; no caching is possible or needed without reactivity. Writes still delegate to `store.set(v)` when present.

This keeps the server bundle free of client runtime imports and guarantees identical *shapes* between environments, so component code needs no branching.

## 7. Edge Cases and Invariants

| Concern | How it is handled |
|---|---|
| State changed before the first subscriber (`toStore`) | The `ran` flag initialises to `init_value !== get()`, so the first render-effect run pushes the fresh value instead of suppressing it. |
| Store with no subscribers (`toStore`) | The start/stop notifier is not invoked — no `effect_root`, no tracking, zero ongoing cost. |
| Multiple readers of `current` (`fromStore`) | `createSubscriber` ref-counts readers; one shared store subscription serves them all. |
| Readers appearing/disappearing rapidly (`fromStore`) | Teardown is deferred to a microtask to avoid churn (unsubscribing and immediately resubscribing) and the leaked-subscription memory hazard. |
| Read outside any effect (`fromStore`) | Falls back to `get(store)` — correct but non-reactive; subscriptions are not left dangling. |
| Readable vs writable | `'set' in store` (and the presence of the `set` argument for `toStore`) selects the read-only or read/write shape of the result. |
| Environment differences | Identical exported shapes; only update *mechanics* differ (live tracking vs. snapshot/pull). |

## 8. Usage Patterns

```js
// Runes → store: expose $state to legacy code / store consumers
let count = $state(0);
const countStore = toStore(() => count, (v) => (count = v));
countStore.subscribe((v) => console.log(v)); // starts tracking
countStore.set(5);                           // writes straight to count

// Store → runes: consume any store without $ syntax
const theme = fromStore(writable('dark'));
// in a component: theme.current is reactive in templates and effects
theme.current = 'light';                     // if the store is writable
```

Typical call sites are the `mount`/`hydrate`/`unmount` lifecycles of the public API (see [public-api_client-entry.md](public-api_client-entry.md), [public-api_server-entry.md](public-api_server-entry.md)); on the client, `toStore`'s captured effects are destroyed with the component's effect tree, and `fromStore`'s subscriptions stop when the last consumer effect unmounts.

## 9. Design Rationale

- **Lifecycle-scoped tracking** (`toStore`): wiring a render effect at *creation* time instead of *subscription* time would keep effects alive for idle stores and break teardown ordering; the start/stop notifier is exactly the right hook.
- **Lazy pull-based `current`** (`fromStore`): eager subscription would fire store updates even when nobody observes them and would complicate unmount handling. `createSubscriber` + `effect_tracking()` gives precise, garbage-free lifetimes.
- **Straight delegation on writes**: both directions route writes directly to the source of truth (the rune setter or `store.set`), so the bridge never becomes a stale middle copy.
- **Symmetric API across targets**: identical shapes on client and server mean user code is environment-agnostic; only the scheduler inside differs.

## 10. Related Documentation

| Topic | Document |
|---|---|
| Store contract types (`Readable`, `Writable`, …) | [stores_contract.md](stores_contract.md) |
| Core store implementations (`writable`, `derived`, `get`) | [stores_core.md](stores_core.md) |
| Signal runtime (`active_effect`, `active_reaction`) | [client-reactivity-engine_signal-graph.md](client-reactivity-engine_signal-graph.md) |
| Effect machinery (`effect_root`, `render_effect`, `effect_tracking`) | [client-reactivity-engine_effects.md](client-reactivity-engine_effects.md) |
| Batching and scheduling of updates | [client-reactivity-engine_batching-scheduling.md](client-reactivity-engine_batching-scheduling.md) |
| `createSubscriber` and related reactive built-ins | [reactive-builtins_media-query.md](reactive-builtins_media-query.md) |
| Client / server public entry points (`mount`, `hydrate`, `unmount`) | [public-api_client-entry.md](public-api_client-entry.md) / [public-api_server-entry.md](public-api_server-entry.md) |
