# motion_tweened

## Overview

The `motion_tweened` module implements Svelte's **tweened motion primitive** — a mechanism for smoothly interpolating a value from its current state toward a target value over time. It is a leaf module of the `Public_API___Built-in_Feature_Surface → motion` family and is consumed by application code through the `svelte/motion` entry point.

The module provides two coexisting implementations of the same concept:

| Export | Kind | Status | Backing mechanism |
|---|---|---|---|
| `tweened(value, defaults)` | Store factory (`Tweened<T>`) | **Deprecated** (since 5.8.0) | Legacy `writable` store + `loop` animation tasks |
| `class Tween<T>` | Class (runes-era) | **Current** (since 5.8.0) | Reactive `state()` sources + `loop` animation tasks |
| `Tweened<T>` | Type interface (`public.d.ts`) | Current | Type contract for the legacy store shape |

Both share the same numeric core: a recursive **interpolator factory** (`get_interpolator`) that can tween numbers, arrays, plain objects and `Date` instances, with well-defined fallbacks for everything else. Animation frames are driven by the shared client frame clock (`raf.now()` / `loop()`), exactly the machinery described in [client-reactivity-engine](client-reactivity-engine.md).

> The deprecation is purely about the *access pattern* (store contract vs. class with bindable `target`/`current`), not the animation semantics — the timing model (`delay`, `duration`, `easing`, `interpolate`) is identical in both.

---

## Module at a Glance

**Source files**

- `packages/svelte/src/motion/tweened.js` — `tweened()`, `class Tween`, internal `get_interpolator()`
- `packages/svelte/src/motion/public.d.ts` — `Tweened<T>` interface (and shared motion re-exports)
- `packages/svelte/src/motion/private.d.ts` — `TweenedOptions<T>` (publicly consumed, internally declared):

  ```ts
  interface TweenedOptions<T> {
      delay?: number;
      duration?: number | ((from: T, to: T) => number);
      easing?: (t: number) => number;              // default: linear
      interpolate?: (a: T, b: T) => (t: number) => T; // default: get_interpolator
  }
  ```

**Exported API surface**

| Member | Signature (essentials) | Notes |
|---|---|---|
| `tweened()` | `(value?: T, defaults?: TweenedOptions<T>) => Tweened<T>` | Returns `{ set, update, subscribe }`; `set`/`update` return a `Promise<void>` that resolves when the animation settles |
| `Tween` | `new Tween(value, options?)` | `.current` getter, `.target` getter/setter (settable → `bind:value`), `.set(value, options?)`, static `Tween.of(fn, options?)` |
| `Tweened<T>` | `interface Tweened<T> extends Readable<T>` | `set(value, opts?): Promise<void>`, `update(updater, opts?): Promise<void>` |

---

## Architecture

The module sits between user-facing reactivity and the animation scheduler. It owns **no DOM code** — it only publishes intermediate values, and whoever reads them (a template binding, a style, a store subscriber) reacts. This is what distinguishes motion values from DOM transitions (see [client-dom-renderer](client-dom-renderer.md), which owns enter/leave transition effects).

```mermaid
flowchart TB
    subgraph pub["Public API surface"]
        ENTRY["svelte/motion entry<br/>(public-api)"]
    end

    subgraph mod["motion_tweened module"]
        TWEENED["tweened(value, defaults)<br/><i>deprecated store factory</i>"]
        TWEEN["class Tween<br/>#current / #target / #task"]
        INTERP["get_interpolator(a, b)<br/>recursive interpolator factory"]
        TYPE["Tweened&lt;T&gt; interface<br/>public.d.ts"]
    end

    subgraph storemod["stores module"]
        WRITABLE["writable()"]
    end

    subgraph reactivity["client-reactivity-engine"]
        STATE["state() / set()<br/>(signal sources)"]
        GET["get()"]
        RE["render_effect()"]
    end

    subgraph sched["client-reactivity-engine<br/>batching &amp; scheduling"]
        LOOP["loop()<br/>Task { abort(), promise }"]
        RAF["raf.now()<br/>(shared frame clock)"]
    end

    EASING["transitions-animations-easing<br/>linear() (default easing)"]
    DEVTOOL["client-dev-tooling<br/>tag() (DEV builds only)"]
    UTILS["motion/utils<br/>is_date()"]

    ENTRY -->|"exports"| TWEENED & TWEEN
    TYPE -.->|"types the legacy store"| TWEENED

    TWEENED --> WRITABLE
    TWEENED --> LOOP & RAF & EASING
    TWEENED --> INTERP

    TWEEN --> STATE & GET
    TWEEN -->|"Tween.of()"| RE
    TWEEN --> LOOP & RAF & EASING
    TWEEN --> INTERP

    INTERP --> UTILS
    TWEEN -.->|"DEV: label sources<br/>'Tween.current' / 'Tween.target'"| DEVTOOL
```

**Key architectural decisions**

1. **Two backends, one animation core.** The deprecated `tweened()` publishes through a `writable` store (see [stores](stores.md)); the modern `Tween` publishes through raw `state()` sources from the signal graph (see [client-reactivity-engine](client-reactivity-engine.md)). Both call the same scheduling and interpolation code paths.
2. **Push-based, consumer-agnostic.** The module never touches the DOM. Every frame it *sets* a value; downstream effects (render effects created by compiled templates) pick the change up through normal reactivity.
3. **Task-based cancellation.** Each animation is a `Task` from `loop()`, exposing `.abort()` and `.promise`. Starting a new tween aborts the previous one, so rapid `set()` calls always converge on the latest target.
4. **Uniform frame clock.** `raf.now()` is the single time source (not the rAF callback timestamp), matching the scheduler contract in [client-reactivity-engine](client-reactivity-engine.md).

---

## Component Reference

### `tweened(value?, defaults?)` — legacy store factory

Creates a store-compatible tween. The returned object satisfies the store contract from [stores](stores.md) (`subscribe` returns an unsubscriber) extended with the `Tweened<T>` mutation API:

- **`set(new_value, opts?)`** — retargets the tween and returns the animation promise.
  - If the tween has never held a value (`value == null`, i.e. created without an initial value), the first `set()` **snaps instantly** — there is nothing to interpolate from.
  - Options are merged as `{ ...defaults, ...opts }` with per-call overrides winning.
  - `duration === 0` short-circuits: the previous task (if any) is aborted and the store jumps to the target.
  - Otherwise an animation `Task` is scheduled with `start = raf.now() + delay`. On the first active frame it builds `fn = interpolate(value, new_value)`, resolves a function-valued `duration(from, to)`, and aborts the previous task. Each frame applies `fn(easing(elapsed / duration))` and pushes the result into the store; when `elapsed > duration` the exact final value is committed and the task ends.
- **`update(fn, opts?)`** — convenience wrapper: `set(fn(target_value, current_value), opts)`. Note the updater receives the **target** first and the current value second, matching `Updater<T>`.
- **`subscribe`** — delegates to the underlying writable store.

```mermaid
flowchart TD
    A["set(new_value, opts?)"] --> B{"value == null?<br/>(never initialized)"}
    B -->|yes| C["store.set(value = new_value)<br/>return resolved promise"]
    B -->|no| D{"duration === 0?"}
    D -->|yes| E["abort previous task<br/>store.set final value<br/>return resolved promise"]
    D -->|no| F["start = raf.now() + delay<br/>schedule loop() task"]
    F --> G{"per frame (now)"}
    G -->|"now &lt; start"| G
    G -->|"first active frame"| H["fn = interpolate(value, new_value)<br/>resolve duration(from, to)<br/>abort previous_task"]
    G -->|"elapsed &gt; duration"| I["store.set exact final value<br/>end task → promise resolves"]
    G -->|otherwise| J["store.set(value = fn(easing(elapsed / duration)))<br/>continue task"]
```

### `get_interpolator(a, b)` — interpolation core

A recursive factory returning `(t: number) => T` where `t` ∈ [0, 1] (already passed through the easing function). It performs a strict type-dispatch, throwing early on incompatible pairs:

```mermaid
flowchart TD
    A["get_interpolator(a, b)"] --> B{"a === b<br/>or a is NaN?"}
    B -->|yes| C["constant: () => a"]
    B -->|no| D{"typeof mismatch<br/>or array-ness mismatch?"}
    D -->|yes| E["throw Error<br/>'Cannot interpolate values of different type'"]
    D -->|no| F{"Array.isArray(a)?"}
    F -->|yes| G["build element-wise interpolators<br/>return t => arr.map(fn => fn(t))"]
    F -->|no| H{"typeof a === 'object'?"}
    H -->|yes| I{"!a &#124;&#124; !b?"}
    I -->|yes| J["throw Error<br/>'Object cannot be null'"]
    I -->|no| K{"is_date(a) &amp;&amp; is_date(b)?"}
    K -->|yes| L["interpolate Date.getTime()<br/>return new Date(an + t * delta)"]
    K -->|no| M["build per-key interpolators<br/>over Object.keys(b)<br/>return t => result object"]
    H -->|no| N{"typeof a === 'number'?"}
    N -->|yes| O["linear lerp: a + t * (b - a)"]
    N -->|no| P["non-numeric: snap to b immediately"]

    style E fill:#fdd
    style J fill:#fdd
```

Behavioral notes:

- Recursion makes arbitrary **nested structures** tweenable (e.g. `{ pos: [x, y], alpha: 1 }`), including arrays of objects.
- **`Date` values** are special-cased (via `is_date`) and tween their timestamps, yielding new `Date` instances.
- Object interpolation iterates **`Object.keys(b)`** — keys that exist only on `a` are ignored in the result shape.
- Non-numeric leaves (strings, booleans, `null`) **snap** to `b` at `t = 0` rather than erroring, so structural tweens degrade gracefully.
- `NaN` or referential equality short-circuits to a constant function — no work per frame.
- A custom `interpolate` option completely replaces this factory.

### `class Tween<T>` — runes-era motion primitive (since 5.8.0)

A class wrapper around two reactive sources plus one animation task:

- `#current = state(value)` — the animated, consumer-facing value (tagged `'Tween.current'` in DEV for [tracing](client-dev-tooling.md)).
- `#target = state(value)` — the goal value (tagged `'Tween.target'` in DEV).
- `#task` — the in-flight `loop()` task or `null`.

**Members**

| Member | Behavior |
|---|---|
| `constructor(value, options?)` | Initializes both sources to `value`; stores default options. |
| `set(value, options?)` | Sets `#target`, then runs the same delay/duration/easing/interpolate pipeline as `tweened().set`, writing each frame into `#current`. Reads the previous value from `#current.v` when building the interpolator. `duration === 0` aborts and snaps. Returns the task promise. |
| `get current` | `get(this.#current)` — reading it inside a template/effect creates a reactive dependency in the signal graph. |
| `get target` / `set target` | Getter returns `#target`; the setter simply calls `this.set(v)`, which is what makes `bind:value={tween.target}` work in templates. |
| `static of(fn, options?)` | Creates a tween from a getter and wires `render_effect(() => tween.set(fn()))`. **Must be called inside an effect root** (e.g. component initialisation) so the effect can be disposed with the component; when a dependency of `fn` changes, the tween retargets automatically. |

Because `current`/`target` are real signals rather than a store, `Tween` composes naturally with runes (`$derived`, `$effect`), does not need `subscribe`, and integrates with ownership/HMR dev tooling.

### `Tweened<T>` interface (`public.d.ts`)

The type contract for the **legacy store shape**:

```ts
interface Tweened<T> extends Readable<T> {
    set(value: T, opts?: TweenedOptions<T>): Promise<void>;
    update(updater: Updater<T>, opts?: TweenedOptions<T>): Promise<void>;
}
```

It extends the framework-agnostic `Readable<T>` from [stores](stores.md), which is what allows tweened values to be consumed outside Svelte components by any store subscriber. The `Promise<void>` return of `set`/`update` resolves when the animation settles — enabling `await tween.set(x)` before cleanup or navigation.

---

## Data Flow: One Tween Lifecycle

```mermaid
sequenceDiagram
    autonumber
    participant U as Consumer<br/>(template / JS)
    participant M as Tween / tweened store
    participant S as Signal source or<br/>writable store
    participant L as loop() task runner
    participant R as raf frame clock

    U->>M: set(newValue, opts?)
    M->>M: merge options<br/>{delay:0, duration:400, easing:linear, interpolate:get_interpolator}
    M->>S: publish target (Tween: set(#target))
    alt duration === 0
        M->>S: publish final value
        M-->>U: resolved promise
    else animated
        M->>M: start = raf.now() + delay
        M->>L: schedule task(now)
        M-->>U: task.promise (pending)
        loop each animation frame
            R->>L: run_tasks(now)
            alt now < start
                Note over L: task kept (returns true)
            else first active frame
                L->>M: tick
                M->>M: fn = interpolate(current, target)<br/>resolve duration(from, to)<br/>abort previous task
            end
            alt elapsed > duration
                M->>S: publish exact final value
                L->>L: remove task, resolve promise
            else
                M->>S: publish fn(easing(elapsed / duration))
            end
        end
        L-->>U: promise resolves on settle
    end
    Note over S,U: downstream render effects re-run<br/>through normal reactivity
```

**Interruption semantics.** Calling `set()` again mid-flight never restarts from the original value: the new task's first active frame interpolates from **wherever the value currently is** to the new target, then aborts the previous task. There is also no per-instance race guard on promise resolution in `tweened()` — the awaited promise belongs to the task captured at call time — whereas the sibling `spring()` (see [motion_spring](motion_spring.md)) additionally token-checks which `set()` call "owns" resolution.

---

## Relationship to Other Modules

```mermaid
flowchart LR
    subgraph motion["svelte/motion"]
        TS["motion_tweened<br/>(this module)"]
        SP["motion_spring"]
    end
    ST["stores<br/>writable / Readable"]
    CRE["client-reactivity-engine<br/>state/set/get, loop, raf, render_effect"]
    CDT["client-dev-tooling<br/>tag (DEV tracing)"]
    TAE["transitions-animations-easing<br/>linear + easing curves"]
    PA["public-api<br/>svelte/motion exports"]
    DOMR["client-dom-renderer<br/>transitions (DOM effects)"]

    PA --> TS & SP
    TS -->|"legacy backend"| ST
    TS & SP -->|"scheduler + clock"| CRE
    TS & SP -->|"easing functions"| TAE
    TS -->|"DEV source labels"| CDT
    TS -.->|"complementary:<br/>value animation vs element enter/leave"| DOMR
```

- **[public-api](public-api.md)** — `tweened`, `Tween` and the `Tweened` type are re-exported through the `svelte/motion` public surface; this module never imports application-facing code.
- **[stores](stores.md)** — `tweened()` is built on `writable()` and its `Tweened<T>` type extends `Readable<T>`. The store contract, subscription semantics and `get()`/`update()` helpers are documented there.
- **[client-reactivity-engine](client-reactivity-engine.md)** — supplies both backends: `state()`/`set()`/`get()` signal sources and `render_effect()` for `Tween`, and the `loop()` task scheduler with `raf.now()` clock (batching-scheduling subsystem) for both implementations. The `Task` type (`abort()`, `promise`) also lives there.
- **[transitions-animations-easing](transitions-animations-easing.md)** — provides `linear()` (the default easing) and the catalog of curves users pass via `easing`. Easing here maps `elapsed/duration → t` before interpolation.
- **[motion_spring](motion_spring.md)** — the sibling physics-based primitive. Choose `Tween`/`tweened` for predictable, time-bound interpolation (`duration`), `Spring` for velocity-based settling (`stiffness`/`damping`/`precision`). Both share the `raf`/`loop` machinery and the same `set → Promise` contract.
- **[client-dom-renderer](client-dom-renderer.md)** — owns CSS/element *transitions* (`transition:`/`animate:` directives), which animate element enter/leave via effects. Tweened values are independent of elements and typically feed styles/attributes through ordinary bindings; the two can be combined (e.g. tween a value that an element transition reads).
- **[client-dev-tooling](client-dev-tooling.md)** — `Tween` tags its `#current`/`#target` sources in DEV builds, integrating with state tracing/inspection.

---

## Usage Patterns

### Classic store usage (deprecated `tweened`)

```js
import { tweened } from 'svelte/motion';
import { cubicOut } from 'svelte/easing';

const size = tweened(0, { duration: 400, easing: cubicOut });

await size.set(100, { delay: 200 });        // resolves when settled
size.update((target, current) => target + 10);
const unsubscribe = size.subscribe((v) => console.log(v));
```

### Runes usage (`Tween`, since 5.8.0)

```svelte
<script>
    import { Tween } from 'svelte/motion';

    const tween = new Tween(0);
</script>

<input type="range" bind:value={tween.target} />   <!-- setter retargets -->
<input type="range" bind:value={tween.current} disabled /> <!-- getter reads signal -->
```

### Derived tweens (`Tween.of`)

```svelte
<script>
    import { Tween } from 'svelte/motion';
    let { number } = $props();

    // must run inside an effect root (component init)
    const tween = Tween.of(() => number, { duration: 300 });
    // when `number` changes, the tween retargets automatically
</script>
```

---

## Edge Cases & Design Notes

- **Uninitialized tweens snap.** `tweened()` without an initial value jumps to the first `set()` value instead of animating — interpolation needs a concrete `from`.
- **`duration: 0`** (or a duration function returning `0`) means "commit immediately", aborting any in-flight animation.
- **Function-valued `duration`** is evaluated lazily on the first active frame as `duration(from, to)`, allowing distance-based durations.
- **Type errors throw eagerly at animation start**, not at construction: interpolating `1 → 'a'` (or array vs. non-array) throws `Cannot interpolate values of different type`; interpolating to/from `null` objects throws `Object cannot be null`. These are plain `Error`s raised inside the tick, surfacing to the caller of `set`.
- **Per-frame cost scales with structure size**: every frame rebuilds nested result objects via the interpolator tree; very large arrays/objects animate at O(size) per frame.
- **Non-numeric leaves snap** rather than throw, so partially-numeric structures animate their numeric parts and jump the rest.
- **Migration**: `tweened()` is deprecated in favor of `Tween`. The interface differences to account for: no `subscribe`/`update` on `Tween` (use `tween.target`/`tween.current` and `Tween.of`), options and timing semantics otherwise identical.
- **SSR neutrality**: the module is client-only in behavior (`raf`, `loop`, `state`); during server rendering it is simply not exercised — tweened values render at their initial/target value. Runtime client services it depends on are documented in [client-reactivity-engine](client-reactivity-engine.md).
