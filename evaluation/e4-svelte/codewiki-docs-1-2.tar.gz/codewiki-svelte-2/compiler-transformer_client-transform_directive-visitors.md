# Directive Visitors — Client Transform

> **Module:** `compiler-transformer_client-transform_directive-visitors`
> **Location:** `packages/svelte/src/compiler/phases/3-transform/client/visitors/`
> **Parent:** [Client Transform](compiler-transformer_client-transform.md)

## 1. Introduction

This module implements the **client-side code generation for Svelte directives** — the imperative "wiring" attributes that connect DOM elements to component state and behavior. While [structural visitors](compiler-transformer_client-transform_structural-visitors.md) create the DOM template and blocks, the visitors in this module emit the calls that **bind state to elements** (`bind:`), **attach listeners** (`on:`), **run actions** (`use:`), **play transitions** (`transition:` / `in:` / `out:`), **forward slot props** (`let:`), and **support debugging** (`{@debug ...}`).

Each visitor is a pure function of two arguments:

```js
/**
 * @param {AST.<DirectiveType>} node   – the analyzed AST node
 * @param {ComponentContext} context   – zimmerframe context: { visit, state, path, next, stop }
 */
export function DirectiveName(node, context) { /* ... */ }
```

Visitors **do not execute anything at compile time**; they push generated ESTree statements into the shared `ComponentClientTransformState` queues (`context.state.init`, `context.state.after_update`) or return expressions that the enclosing element visitor incorporates. The emitted calls target the `svelte/internal/client` runtime (imported as the `$` namespace by `transform-client.js`), which is documented in [Client Runtime Engine](client-reactivity-engine.md) and [DOM Renderer](client-dom-renderer.md).

## 2. Architecture & Position in the Compiler

The directive visitors are **leaf code generators** in phase 3 of the compiler pipeline. They consume the output of [phase 2 analysis](compiler-analyzer_visitors.md) (scopes, bindings, and `node.metadata` such as `parent_each_blocks`, `binding_group_name`, and expression reactivity flags) and produce plain JavaScript AST nodes.

```mermaid
flowchart TB
    subgraph P1["Phase 1 — Parse"]
        PARSE["parser<br/>(compiler-parser)"]
    end
    subgraph P2["Phase 2 — Analyze"]
        ANALYZE["analysis visitors<br/>(compiler-analyzer_visitors)<br/>scopes • bindings • metadata"]
    end
    subgraph P3["Phase 3 — Transform (this module's home)"]
        TC["transform-client.js<br/>visitors map + walk()"]
        subgraph DIRECTIVES["directive visitors (this module)"]
            BD["BindDirective"]
            OD["OnDirective"]
            TD["TransitionDirective"]
            UD["UseDirective"]
            LD["LetDirective"]
            DT["DebugTag"]
        end
        subgraph SHARED["shared helpers"]
            EV["shared/events.js"]
            UT["shared/utils.js"]
            EL["shared/element.js"]
        end
        STRUCT["structural visitors<br/>(RegularElement, Fragment, ...)"]
        EXPR["expression visitors<br/>(Identifier, AssignmentExpression, ...)"]
    end
    subgraph RT["svelte/internal/client (runtime)"]
        BINDS["$.bind_* · $.bind_property"]
        EVENTS["$.event · $.delegate"]
        TRANS["$.transition"]
        ACTION["$.action"]
        DERIVED["$.derived"]
    end

    PARSE --> ANALYZE --> TC
    TC -->|dispatch by node type| DIRECTIVES
    BD -.-> UT & EL
    OD -.-> EV
    TD & UD -.-> UT
    LD --> DERIVED
    TC --> STRUCT --> EXPR
    DIRECTIVES -->|emit $. calls| RT
    STRUCT -.->|consume emitted statements<br/>init / after_update| DIRECTIVES
```

### 2.1 Visitor registration and dispatch

`transform-client.js` imports every visitor and assembles them into a single `visitors` map keyed by AST node type. The `zimmerframe` `walk()` function traverses the analyzed template/instance/module ASTs and invokes the matching visitor for each node:

```js
// transform-client.js (excerpt)
const visitors = {
    _: function set_scope(node, { next, state }) { /* scope bookkeeping */ },
    BindDirective,       // bind:*
    OnDirective,         // on:*
    TransitionDirective, // transition: / in: / out:
    UseDirective,        // use:*
    LetDirective,        // let:*
    DebugTag,            // {@debug}
    /* ... ~60 other visitors ... */
};

walk(analysis.template.ast, state, visitors);
```

The `_: set_scope` pre-visitor swaps in the correct scope/transform maps per node, which is what allows directive visitors to read reactive bindings via `context.state.transform`.

### 2.2 Component relationships

```mermaid
flowchart LR
    subgraph Inputs
        NODE["AST directive node<br/>+ node.metadata (from analyze)"]
        CTX["ComponentContext<br/>{ visit, state, path, next }"]
        STATE["ComponentClientTransformState<br/>init · after_update · transform<br/>node · scope · analysis"]
    end
    subgraph Visitors["This module"]
        V["Visitor fn"]
    end
    subgraph Helpers["Shared helpers"]
        H1["build_event_handler / build_event"]
        H2["parse_directive_name"]
        H3["build_bind_this / validate_binding"]
        H4["build_attribute_value"]
        H5["create_derived"]
        H6["binding_properties table"]
    end
    subgraph Builders["AST Builders"]
        B["b.* (builders.js)"]
    end
    OUT["ESTree statements / expressions<br/>pushed to init · after_update<br/>or returned to parent visitor"]

    NODE --> V
    CTX --> V
    V --> H1 & H2 & H3 & H4 & H5 & H6
    V --> B --> OUT
    STATE --> OUT
```

## 3. Component Reference

### 3.1 `BindDirective` — `bind:` directives

**File:** `visitors/BindDirective.js` · **Syntax:** `<input bind:value={x} />`, `<canvas bind:this={c} />`, `<input type="checkbox" bind:group={g} />`

The largest visitor in the module. It turns a two-way binding into getter/setter closures and a runtime `$.bind_*` call.

Processing flow:

```mermaid
flowchart TD
    A["BindDirective(node)"] --> B["visit(node.expression)"]
    B --> C{"expression is<br/>SequenceExpression?"}
    C -->|yes| D["get/set = expressions"]
    C -->|no| E{"dev ∧ runes ∧ MemberExpression<br/>∧ inside If/Each/Await/Key block<br/>∧ not svelte-ignore<br/>binding_property_non_reactive"}
    E -->|yes| F["emit $.validate_binding(...) → state.init<br/>(dev-only reactivity warning)"]
    E -->|no| G["get = thunk(expr)<br/>set = unthunk(arrow $$value → expr = $$value)"]
    F --> G
    D --> H{"binding_properties[name].event<br/>exists? (generic DOM property)"}
    H -->|yes| I["$.bind_property(name, event, node,<br/>set, bidirectional && get)"]
    H -->|no| J{"special case switch(node.name)"}
    J --> K["window: online, scrollX/Y,<br/>innerWidth/Height, outerWidth/Height"]
    J --> L["document: activeElement"]
    J --> M["media: muted, paused, volume,<br/>currentTime, buffered, ..."]
    J --> N["dimensions: clientWidth/Height,<br/>offsetWidth/Height, contentRect, ..."]
    J --> O["value (select vs input), files,<br/>checked, focused, textContent/innerHTML/innerText"]
    J --> P["this → build_bind_this()"]
    J --> Q["group → $.bind_group(...)"]
    J --> R["unknown → throw"]
    I & K & L & M & N & O & P & Q --> S{"placement"}
    P -->|bind:this| T["state.init.push(call)"]
    Q --> S
    S -->|"sibling use: present"| U["state.init.push($.effect(thunk(call)))"]
    S -->|otherwise| V["state.after_update.push(call)"]
```

Key details:

- **`binding_properties` lookup** (`phases/bindings.js`): the shared table declares, per property, whether an `event` notifies changes, whether it is `bidirectional`, and element validity. Properties *with* an event use the generic `$.bind_property`; everything else falls into the hard-coded special cases.
- **`bind:group`** aggregates the enclosing `each` block indexes (`node.metadata.parent_each_blocks`; keyed indexes are read via `$.get`) and — when the sibling `<input value=...>` is dynamic — evaluates the value attribute inside the getter so updating the value re-registers the binding dependency.
- **`bind:this`** is one-way and can influence the render effect, so it is emitted into `init` *before* everything else.
- **Ordering with actions:** if the parent element also has a `use:` directive, the binding call is wrapped in `$.effect(() => …)` inside `init` so it executes in order with the action; otherwise it goes to `after_update` (after attribute updates and the render effect).

### 3.2 `OnDirective` — `on:` event handlers

**File:** `visitors/OnDirective.js` · **Syntax:** `<button onclick={fn} />`, `<button on:click />`, `<div on:click|once|preventDefault={fn} />`

Emits the DOM event registration that is folded into the element's attribute effect by the enclosing element visitor.

```mermaid
flowchart TD
    A["OnDirective(node)"] --> B{"node.expression<br/>missing?"}
    B -->|yes| C["analysis.needs_props = true<br/>(forwarded event → bubble)"]
    B -->|no| D["handler = visit(expression)"]
    C --> E["handler = bubble_event fn"]
    D --> F["apply modifiers in fixed order:<br/>stopPropagation · stopImmediatePropagation<br/>preventDefault · self · trusted · once<br/>→ handler = $.<modifier>(handler)"]
    E --> F
    F --> G{"flags"}
    G --> H["capture = |capture modifier<br/>passive = passive / nonpassive"]
    H --> I["return build_event(name, node, handler,<br/>capture, passive)<br/>⇒ $.event(name, node, handler, ...)"]
```

The heavy lifting is in the shared helper **`build_event_handler`** (see [§4 Shared helpers](#41-sharedeventsjs)):

| Handler shape | Emitted strategy |
|---|---|
| No expression (`on:click`) | `function ($$arg) { $.bubble_event.call(this, $$props, $$arg) }` |
| Inline arrow / function expression | Used verbatim (no wrapper) |
| Identifier bound to a function | Used verbatim |
| Non-dev local variable | Used verbatim |
| Identifier with call side effects (`on:click={fn()}`) or dev/imported | Memoized in `$.derived` when it has calls, then wrapped in `function (...$$args) { handler.apply(this, $$args) }` so the expression is re-evaluated per event |
| Dev mode (non-trivial) | Wrapped via `$.apply(thunk, this, $$args, componentName, [line, col], ...)` to keep warnings/debug info accurate |

At module level, delegated event names collected in `state.events` produce one `$.delegate([...])` call, letting the runtime use a single root listener (`handle_event_propagation` in [DOM Renderer](client-dom-renderer.md)).

### 3.3 `TransitionDirective` — `transition:` / `in:` / `out:`

**File:** `visitors/TransitionDirective.js`

Combines direction and locality into a bitflag argument and schedules the transition after the element is mounted:

```js
let flags = node.modifiers.includes('global') ? TRANSITION_GLOBAL : 0;
if (node.intro) flags |= TRANSITION_IN;   // in: / transition:
if (node.outro) flags |= TRANSITION_OUT;  // out: / transition:
// $.transition(flags, node, () => name, () => params) → state.after_update
```

- The transition *function* is resolved with `parse_directive_name`, so namespaced members like `transition:fx.fade` become member expressions.
- Emitted into `after_update` explicitly so it always runs **after `bind:this`**.
- The runtime counterpart (`transition`/`animation` in [DOM Renderer](client-dom-renderer.md)) pairs with public transition functions from [Transitions & Animations](transitions-animations-easing.md).

### 3.4 `UseDirective` — `use:` actions

**File:** `visitors/UseDirective.js`

Generates a parametrized action invocation whose parameter object is re-evaluated on change:

```js
// use:action={params}
$.action(node, ($$node, $$action_arg) => action?.($$node, $$action_arg), () => params)
```

- Pushed into `state.init`; the runtime's `$.action` itself registers the update/destroy lifecycle so the action executes **after attribute updates, in order with bindings and events**.
- Calls `context.next()` so traversal of the node's children continues (unlike most visitors that rely on the default traversal, this keeps the walk explicit for the directive node).

### 3.5 `LetDirective` — `let:` slot-prop forwarding (legacy)

**File:** `visitors/LetDirective.js`

Bridges legacy slot props into the runes-era derived system. It has two shapes:

| Syntax | Emission |
|---|---|
| `let:x` or `let:x={y}` (identifier) | `const x = create_derived(state, $$slotProps.x)` plus `state.transform.x = { read: (n) => $.get(n) }` so subsequent reads rewrite to `$.get(x)` |
| `let:x={{y, z}}` (pattern) | `const derived_x = $.derived(() => { const {y, z} = $$slotProps.x; return { y, z } })`, and every destructured binding gets a `transform` entry reading `$.get(derived_x).y` etc. |

This visitor returns a declaration to its parent (the `<slot>`/component element) and also mutates `state.transform`, the mechanism documented in [Client Transform Infrastructure](compiler-transformer_client-transform_infrastructure.md).

### 3.6 `DebugTag` — `{@debug a, b}`

**File:** `visitors/DebugTag.js`

```js
// {@debug a, b} ≈
$.template_effect(() => {
    console.log({ a: $.snapshot(a), b: $.snapshot(b) });
    debugger;
});
```

- `$.snapshot` deep-unwraps reactivity for readable logging; in runes mode it is called directly, in legacy mode it is wrapped in `$.untrack(() => …)` to avoid creating dependencies.
- Emitted as a `template_effect` so the log fires whenever any of the listed identifiers change.

## 4. Shared Helpers

The directive visitors deliberately stay thin by delegating to `visitors/shared/`:

### 4.1 `shared/events.js`

- **`build_event(name, node, handler, capture, passive)`** — canonical `$.event(...)` call construction used by `OnDirective`.
- **`build_event_handler(node, metadata, context)`** — strategy table described in [§3.2](#32-ondirective--on-event-handlers); also memoizes call-having expressions in `$.derived` and attaches dev-mode source locations.

### 4.2 `shared/utils.js`

- **`parse_directive_name(name)`** — converts `"fx.fade"` into `fx.fade` (member expressions with computed fallbacks for non-identifier parts). Used by `UseDirective` and `TransitionDirective`.
- **`build_bind_this(expression, value, context)`** — powers `bind:this`. Handles sequence expressions (`get`/`set` pairs), captures each-context variables so stale values can be nulled on teardown, and optional-chains member accesses to survive teardown order.
- **`validate_binding(state, node, expression)`** — dev/runes-only `$.validate_binding(...)` emission warning when a bound property is not reactive (suppressed via `svelte-ignore binding_property_non_reactive` / `is_ignored` from [compile state](compiler-core_compile_state.md)).

### 4.3 `shared/element.js`

- **`build_attribute_value(value, context, memoize?)`** — used by `BindDirective` for `bind:group` to inline the sibling `value` attribute into the group getter; handles static text, single expressions (with `has_state` metadata), and multi-chunk templates.

### 4.4 Supporting modules

| Dependency | Provides | Used by |
|---|---|---|
| `#compiler/builders` ([AST Builders](compiler-core_ast_builders.md)) | `b.thunk`, `b.arrow`, `b.call`, `b.const`, `b.derived`, … | all visitors |
| `phases/bindings.js` | `binding_properties` table | `BindDirective` |
| `../../state.js` ([Compile State](compiler-core_compile_state.md)) | `dev`, `is_ignored` | `BindDirective` |
| `../utils.js` ([Infrastructure](compiler-transformer_client-transform_infrastructure.md)) | `create_derived`, `visit` mutation validation | `LetDirective`, dev ownership checks |
| `../../../constants.js` | `TRANSITION_GLOBAL / TRANSITION_IN / TRANSITION_OUT` | `TransitionDirective` |

## 5. Output Ordering Semantics

Because directives interact (e.g., a checkbox with `bind:group` + `use:action` + `on:change`), execution order is contractual:

```mermaid
timeline
    title Per-element statement order in generated code
    section init (before render effect)
        bind:this : $.bind_this(...) — may influence render effect
        actions   : $.action(node, fn, params) — runs after attrs, ordered with binds/events
        bindings w/ use: : $.effect(() => $.bind_*(...)) — wrapped to interleave with actions
        validate_binding (dev) : dev-only reactivity check
        debug tags : $.template_effect(() => console.log + debugger)
    section after_update (after render effect / attribute updates)
        bindings  : $.bind_value / $.bind_property / ...
        transitions : $.transition(flags, node, name, params)
```

Rationale, as encoded in the visitors:

1. **Attribute updates first** — bindings read/write element properties that attributes initialized.
2. **Bindings before actions/transitions** — `UseDirective`'s comment: *"actions need to run after attribute updates in order with bindings/events"*; `BindDirective` wraps itself in `$.effect` only when a `use:` sibling exists, to preserve relative order.
3. **`bind:this` before everything** — one-way and potentially feeding the render effect.
4. **Transitions last** — after `bind:this`, so the element identity is settled before animating.

## 6. Data Flow Example

Compiling `<input bind:value={name} on:input />` inside a runes-mode component:

```mermaid
sequenceDiagram
    participant W as walk() (zimmerframe)
    participant RE as RegularElement visitor
    participant BD as BindDirective (this module)
    participant OD as OnDirective (this module)
    participant S as TransformState
    participant R as $. runtime (client)

    W->>RE: visit RegularElement input
    RE->>BD: visit child BindDirective
    BD->>S: dev? push $.validate_binding (if member expr in block)
    BD->>BD: get = () => name ; set = ($$value) => name = $$value
    BD->>S: after_update += $.bind_value(node, get, set)
    BD-->>RE: done
    RE->>OD: visit child OnDirective
    OD->>OD: build_event_handler(null) → bubble fn
    OD->>S: analysis.needs_props = true
    OD-->>RE: returns $.event("input", node, handler)
    RE->>RE: fold $.event into template_effect for the element
    Note over S: component assembly (transform-client.js):<br/>init → consts → update → after_update → render
    W->>R: at mount: render effect creates element;<br/>event delegated ($.delegate);<br/>after_update: bind_value subscribes two-way sync
```

## 7. Interaction with the Runtime

Every emitted call has a counterpart in `svelte/internal/client`. The contract between compiler and runtime:

| Compiler emits | Runtime module (link) |
|---|---|
| `$.bind_value`, `$.bind_checked`, `$.bind_group`, … | [`dom/elements/bindings/*`](client-dom-renderer.md) |
| `$.bind_property` (generic DOM property binding) | [`dom/elements/bindings/props.js`](client-dom-renderer.md) |
| `$.bind_this` | [`dom/elements/bindings/this.js`](client-dom-renderer.md) |
| `$.event`, `$.delegate`, modifier wrappers | [`dom/elements/events.js`](client-dom-renderer.md) |
| `$.transition`, `$.animation` | [`dom/elements/transitions.js`](client-dom-renderer.md) + [Transitions](transitions-animations-easing.md) |
| `$.action`, `$.effect`, `$.template_effect` | [runtime effects](client-reactivity-engine.md) |
| `$.derived`, `$.get` | [`reactivity/deriveds.js`](client-reactivity-engine.md) |
| `$.snapshot`, `$.untrack` | [runtime core](client-reactivity-engine.md) |
| `$.validate_binding`, `$.bubble_event`, `$.apply` | dev-tooling surface ([Client Dev Tooling](client-dev-tooling.md)) |

The SSR equivalents for directives that affect markup (`bind:group`'s `checked`/`value` seeds, `bind:this` omission, `omit_in_ssr` flags in `binding_properties`) live in the [Server Transform](compiler-transformer_server-transform.md), which consumes the same `binding_properties` table.

## 8. Maintenance Notes

- **Adding a new bind target:** extend `binding_properties` (for event-driven DOM properties) *or* add a `case` in `BindDirective` plus a runtime `$.bind_*` implementation; keep SSR parity via `omit_in_ssr`.
- **Adding an event modifier:** extend the `modifiers` const array in `OnDirective.js` and the runtime wrappers in `dom/legacy/event-modifiers.js`; order in the array is application order.
- **Dev-mode invariants:** `$.apply` (events), `$.validate_binding`, and `$.validate_binding`'s ignore mechanism rely on `locator()` and `is_ignored`; changes must keep production builds free of these calls.
- **Legacy vs runes:** `LetDirective`, `DebugTag` (untrack), and `OnDirective`'s bubbling path are legacy-mode concerns; runes-mode tests should cover the transforms map behavior in `state.transform`.
- **Related docs:** [Client Transform Infrastructure](compiler-transformer_client-transform_infrastructure.md) (visit/create_derived, template machinery), [Expression Visitors](compiler-transformer_client-transform_expression-visitors.md) (how `state.transform` rewrites identifier reads emitted here), [Structural Visitors](compiler-transformer_client-transform_structural-visitors.md) (parents that consume `init`/`after_update` queues), [Analyzer Visitors](compiler-analyzer_visitors.md) (producer of `node.metadata`).
