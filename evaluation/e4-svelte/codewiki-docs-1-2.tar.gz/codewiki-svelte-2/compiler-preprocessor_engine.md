# compiler-preprocessor_engine

## 1. Overview

The **compiler-preprocessor_engine** module implements the *execution engine* behind `svelte.preprocess()` — Svelte's mechanism for arbitrarily transforming component source code **before** it reaches the actual compilation pipeline (parse → analyze → transform).

Its core responsibilities are:

- **Orchestration** — running a chain of user-supplied `PreprocessorGroup`s over a `.svelte` source string, in order, with three hook categories per group: `markup` (whole-file), `script` (per `<script>` tag) and `style` (per `<style>` tag).
- **Source state management** — threading the (possibly rewritten) source string through successive preprocessing steps via the `PreprocessResult` state container.
- **Position-faithful source map stitching** — every replacement is represented as a `MappedCode` (string + decoded source map). The engine offsets tag-local maps back into component coordinates, maintains a composed chain of maps, and finally folds them into a single map from the preprocessed output back to the *original* file using `@jridgewell/remapping`.
- **Dependency bookkeeping** — collecting files that preprocessor outputs depend on (e.g. imported `.scss` partials) and returning them deduplicated, so bundlers can watch them for changes.

> This module is the engine sub-module of the broader `compiler-preprocessor` module. The public contract (the `Processed`, `MarkupPreprocessor`, `Preprocessor`, `PreprocessorGroup` and `SveltePreprocessor` types) is documented separately in [compiler-preprocessor_api](compiler-preprocessor_api.md); the parent module is described in [compiler-preprocessor](compiler-preprocessor.md).

**Core components:**

| Component | File | Role |
|---|---|---|
| `preprocess` | `packages/svelte/src/compiler/preprocess/index.js` | Public async entry point / orchestrator |
| `process_single_tag` | `packages/svelte/src/compiler/preprocess/index.js` | Per-tag hook driving a single `<script>`/`<style>` replacement |

Supporting internals of the same file: `PreprocessResult`, `process_markup`, `process_tag`, `processed_tag_to_code`, `processed_content_to_code`, `parse_tag_attributes`, `stringify_tag_attributes`.

---

## 2. Position in the Compiler System

The preprocessing engine is a **pre-compile** stage. It is target-agnostic and runs before all three compiler phases:

```mermaid
flowchart LR
    A["Tooling / Bundler plugins<br/>(e.g. vite-plugin-svelte)"] --> B["preprocess()<br/>this module"]
    B -->|"Processed { code, map, dependencies }"| C["compile()<br/>(see compiler-core_public_api)"]
    C --> D["Phase 1: Parse<br/>(see compiler-parser)"]
    D --> E["Phase 2: Analyze<br/>(see compiler-analyzer)"]
    E --> F["Phase 3: Transform<br/>(see compiler-transformer)"]
```

Key integration facts:

- The engine does **not** parse the document structurally — it scans for tags with regular expressions. This is deliberate: preprocessing must work even on malformed or exotic markup that the strict parser would reject (this is how Sass/TypeScript/Markdown-in-Svelte tooling bootstraps itself).
- The returned `Processed.map` is a composed source map from the *final* preprocessed code back to the *original* `.svelte` file. Downstream, this is the map that eventually surfaces as `CompileResult.map` (see [compiler-core_public_api](compiler-core_public_api.md)).
- `Processed.dependencies` tells bundlers which extra files to watch for HMR.

---

## 3. Architecture

### 3.1 Internal component layout

```mermaid
flowchart TB
    subgraph engine["compiler-preprocessor_engine (preprocess/index.js)"]
        PRE["preprocess()<br/>orchestrator / public entry"]
        STATE["PreprocessResult<br/>mutable Source state:<br/>source · filename · file_basename<br/>get_location · sourcemap_list · dependencies"]
        MARKUP["process_markup()<br/>whole-file hook"]
        TAG["process_tag()<br/>regex scan + replace driver"]
        SINGLE["process_single_tag()<br/>per-tag hook (core component)"]
        ATTR["parse_tag_attributes()<br/>stringify_tag_attributes()"]
        TAGCODE["processed_tag_to_code()<br/>open tag + close tag mapping"]
        CONTENT["processed_content_to_code()<br/>content mapping + offset"]
    end

    subgraph siblings["Adjacent preprocess support files"]
        REPLACE["replace_in_code.js<br/>replace_in_code · slice_source"]
        DECODE["decode_sourcemap.js<br/>decode_map"]
        TYPES["public.d.ts / private.d.ts<br/>Processed · PreprocessorGroup · Source · SourceUpdate"]
    end

    subgraph shared["compiler/shared utils"]
        MAPPED["utils/mapped_code.js<br/>MappedCode · combine_sourcemaps<br/>sourcemap_add_offset · parse_attached_sourcemap<br/>get_basename"]
        LOC["locate-character<br/>getLocator (external)"]
        REMAP["@jridgewell/remapping (external)"]
    end

    PRE -->|"creates & threads"| STATE
    PRE --> MARKUP
    PRE --> TAG
    MARKUP -->|"SourceUpdate"| STATE
    TAG --> SINGLE
    TAG --> REPLACE
    SINGLE --> ATTR
    SINGLE --> TAGCODE
    SINGLE -->|"MappedCode replacement"| REPLACE
    TAGCODE --> CONTENT
    CONTENT --> DECODE
    STATE -->|"combine_sourcemaps at the end"| MAPPED
    REPLACE --> MAPPED
    CONTENT --> MAPPED
    TAGCODE --> MAPPED
    STATE --> LOC
    MAPPED --> REMAP
    TYPES -.->|"shapes all inputs/outputs"| PRE
```

### 3.2 Component responsibilities

| Component | Responsibility | Notes |
|---|---|---|
| `preprocess` | Normalize arguments (single group vs. array, legacy `filename` on the group), iterate groups sequentially, finalize result | The only export; mirrors the documented `svelte.preprocess` API |
| `PreprocessResult` | Single source of truth for the evolving document. Implements the `Source` interface (`source`, `get_location`, `file_basename`, `filename`) | `update_source()` swaps the string, rebuilds the character→line/column locator, and `unshift`s new maps onto `sourcemap_list` |
| `process_markup` | Invokes a `MarkupPreprocessor` with the whole current content; JSON-parses string maps if needed | Returns an empty object when the hook declines to change anything |
| `process_tag` | Owns the tag regex (`regex_script_tags` / `regex_style_tags`), delegates to `replace_in_code`, accumulates tag-level `dependencies` | Skips HTML comments via the `<!--[^]*?-->` alternation at the head of both regexes |
| `process_single_tag` | The per-match callback: decides *change vs. no-change*, calls the user preprocessor, and produces the replacement `MappedCode` | See the decision flow in §5.2 |
| `processed_tag_to_code` | Reassembles a full tag (`<style …>content</style>`) as one concatenated `MappedCode`; synthesizes an explicit map for the open tag when generated attributes differ in length from the original ones | Length-preserving attributes take the cheap identity path (`build_mapped_code`) |
| `processed_content_to_code` | Decodes the preprocessor's returned map and shifts segments that point at the component file by the tag's absolute position | Only segments whose `sources` entry equals the component's basename are offset |
| `parse_tag_attributes` / `stringify_tag_attributes` | Attribute string ⇄ record round-trip so preprocessors can mutate tag attributes (e.g. drop `lang="sass"`) | Values may be `string \| boolean` (bare attributes become `true`) |

---

## 4. Data Flow — End-to-End Preprocessing Run

```mermaid
sequenceDiagram
    autonumber
    participant U as Caller (bundler / compile pipeline)
    participant P as preprocess()
    participant S as PreprocessResult (Source state)
    participant H as User preprocessor hooks
    participant R as replace_in_code + MappedCode utils
    participant SM as sourcemap utils (decode, offset, remapping)

    U->>P: await preprocess(source, groups, { filename })
    P->>S: new PreprocessResult(source, filename)
    Note over S: locator built via getLocator,<br/>file_basename derived via get_basename

    loop for each PreprocessorGroup in order
        alt group.markup is defined
            P->>H: markup({ content: full source, filename })
            H-->>P: Processed | void
            P->>S: update_source({ string, map, dependencies })
            Note over S: map unshifted → newest map is index 0
        end
        alt group.script is defined
            P->>R: replace_in_code(regex_script_tags, process_single_tag, source)
            R->>H: script({ content, attributes, markup, filename }) per match
            H-->>R: Processed | void
            R->>SM: decode_map + sourcemap_add_offset + tag stitching
            R-->>P: SourceUpdate { string, map, dependencies }
            P->>S: update_source(...)
        end
        alt group.style is defined
            Note over P,R: same driver as script,<br/>using regex_style_tags
            P->>S: update_source(...)
        end
    end

    P->>S: to_processed()
    S->>SM: combine_sourcemaps(file_basename, sourcemap_list)
    SM-->>S: single DecodedSourceMap (original file → final code)
    S-->>U: Processed { code, dependencies (deduped), map, toString() }
```

### 4.1 The `Source` / `SourceUpdate` state contract

The engine threads state through a small, explicit interface (defined in the parent module's `private.d.ts`):

```ts
interface Source {
  source: string;                            // current document text
  get_location: (index: number) => Location; // index → { line, column }
  file_basename: string;                     // last path segment, used as sourcemap `sources` key
  filename?: string;
}
interface SourceUpdate {
  string?: string;      // new document text (if hook changed it)
  map?: DecodedSourceMap; // map from new text back to previous text
  dependencies?: string[]; // additional files to watch
}
```

Every `update_source` call is *append-only with respect to maps*: the new map is pushed to the **front** of `sourcemap_list`, keeping the list ordered newest → oldest. This ordering is exactly what `combine_sourcemaps`/`remapping` expects to compose a transformation chain.

---

## 5. Core Component Deep Dive

### 5.1 `preprocess` — the orchestrator

```
preprocess(source, preprocessor, options?) → Promise<Processed>
```

Execution order per group is **fixed and significant**: `markup` → `script` → `style`. Markup preprocessors therefore always see and may rewrite what script/style preprocessors will subsequently scan (e.g. a global import-injection preprocessor runs before the TypeScript preprocessor strips types).

Behavioral details:

- A single group is normalized to a one-element array; `null`/`undefined` groups lists are tolerated (result is the identity transformation).
- **Legacy fallback:** if `options.filename` is absent, `preprocessor.filename` (a property on the array itself, from older tooling) is honored.
- Each group's hooks are invoked only if defined; hooks may be sync or async (everything is `await`ed).
- All failures inside user hooks propagate to the caller — the engine adds no error wrapping of its own.

### 5.2 `process_single_tag` — per-tag decision flow

```mermaid
flowchart TD
    M["Regex match: full tag + attributes + content + offset"] --> Q1{"attributes empty<br/>and content empty?"}
    Q1 -- "yes" --> NC["no_change() —<br/>identity MappedCode via slice_source"]
    Q1 -- "no" --> PA["parse_tag_attributes(attributes)"]
    PA --> CALL["await preprocessor({ content, attributes, markup, filename })"]
    CALL --> Q2{"returned Processed?"}
    Q2 -- "no" --> NC
    Q2 -- "yes" --> DEP["collect processed.dependencies"]
    DEP --> Q3{"map present<br/>or code changed?"}
    Q3 -- "no (no map + identical code)" --> NC
    Q3 -- "yes" --> PTC["processed_tag_to_code(<br/>processed, tag_name,<br/>original attributes,<br/>stringified processed.attributes,<br/>sliced content Source)"]
    PTC --> OUT["MappedCode replacement returned<br/>to perform_replacements"]
```

The **no-change fast paths** are an important performance and correctness feature: when nothing changes, the replacement is a *sliced identity map* of the original text, so downstream source maps remain high-resolution rather than degrading through a pointless transformation layer.

### 5.3 Tag replacement & attribute rewriting

`processed_tag_to_code` splits the replacement into three concatenated parts:

1. **Open tag** — `<{tag}{attributes}>`. If the preprocessor returned `attributes` whose stringified form has a *different length* than the original attribute string, the engine cannot use the identity map and instead **synthesizes a hand-built map** that maps the generated open tag back to the original open tag's position (handling multi-line tags by repeating the tag-start segment per line). If lengths match, a cheap positional slice is used.
2. **Content** — delegated to `processed_content_to_code`.
3. **Close tag** — `</{tag}>`, always a positional slice.

The concatenated result becomes the `replacement` handed back to `perform_replacements` (from `replace_in_code.js`), which splices it between unchanged prefix/suffix slices:

```mermaid
flowchart LR
    subgraph doc["Current document text"]
        P1["unchanged prefix"] --> T["matched tag<br/>(replaced)"] --> P2["unchanged suffix"]
    end
    subgraph out["Result MappedCode (concatenated)"]
        A["identity map of prefix"] --> B["map of new tag<br/>(open + content + close)"] --> C["identity map of suffix"]
    end
    P1 -.-> A
    T -.-> B
    P2 -.-> C
```

### 5.4 Content mapping details (`processed_content_to_code`)

For the tag *content* the engine must translate the preprocessor's map — which is expressed in *content-local* coordinates — into *document-global* coordinates:

1. `decode_map` normalizes the returned map: JSON string → object, VLQ `mappings` string → decoded segments, and imports maps from `SourceMapGenerator` instances.
2. `sourcemap_add_offset(map, location_of_content_start, source_index)` shifts only the segments whose `sources[source_index]` equals the component's `file_basename`. Segments pointing at *other* files (e.g. imported Sass partials) are left untouched — they are already in the right file's coordinate system.
3. The shifted map is wrapped via `MappedCode.from_processed`, which pads the mappings to match the generated line count (some tools emit fewer lines).

---

## 6. Source Map Strategy (Design Notes)

The engine's sourcemap handling follows one invariant: **the final map must be a faithful composition from final code back to the original `.svelte` file**, no matter how many preprocessors ran or which of them produced maps.

1. **Per-step maps:** each hook that changes the source must return a map from its output back to its input (the input at that moment in the chain). The engine unshifts it onto `sourcemap_list`.
2. **Attached maps:** preprocessors that cannot return a map programmatically may embed a `//# sourceMappingURL=data:application/json;base64,…` comment in `processed.code`. `parse_attached_sourcemap` extracts data-URI maps (stripping the comment) and warns — but does not fail — when the attachment is unusable (external URL, or both attached and explicit map present).
3. **Final composition:** `to_processed()` calls `combine_sourcemaps`, which:
   - uses `remapping`'s fast **array interface** when every intermediate map has exactly one source,
   - otherwise falls back to the **loader interface**, chaining older maps under the file's basename,
   - guarantees `sources` contains the component basename even when the leading map was empty.

Because `get_basename` is the join key for composition, preprocessor-generated maps are expected to name the input file by its **basename** (e.g. `App.svelte`) in `sources`.

---

## 7. Dependencies

### 7.1 Internal

```mermaid
flowchart TD
    IDX["preprocess/index.js<br/>(this engine)"] --> REPLACE["preprocess/replace_in_code.js<br/>replace_in_code · slice_source"]
    IDX --> DECODE["preprocess/decode_sourcemap.js<br/>decode_map"]
    IDX --> MAPPED["utils/mapped_code.js<br/>MappedCode · combine_sourcemaps ·<br/>sourcemap_add_offset · parse_attached_sourcemap · get_basename"]
    IDX --> TYPES["preprocess/public.d.ts · private.d.ts<br/>(type-only)"]
    IDX --> LOC["locate-character<br/>getLocator (npm)"]
    REPLACE --> MAPPED
    MAPPED --> REMAP["@jridgewell/remapping (npm)"]
```

| Dependency | Used for |
|---|---|
| `locate-character` | `getLocator(source)` — O(1)-ish index → `{line, column}` lookups used for all positional mapping |
| `../utils/mapped_code.js` | The `MappedCode` value type (string + decoded map with concat/merge semantics) and all sourcemap composition helpers |
| `./decode_sourcemap.js` | Normalizing JSON strings, VLQ mapping strings and `SourceMapGenerator` instances into decoded maps |
| `./replace_in_code.js` | Regex-driven replacement orchestration: runs matches concurrently (`Promise.all`), then splices replacements between identity-mapped slices |
| `public.d.ts` / `private.d.ts` | The `Processed`, `MarkupPreprocessor`, `Preprocessor`, `PreprocessorGroup` and `Source`, `SourceUpdate` contracts — documented in [compiler-preprocessor_api](compiler-preprocessor_api.md) |

### 7.2 Consumers / downstream

- **Bundler tooling** (vite-plugin-svelte, rollup-plugin-svelte, svelte.config.js `preprocess` arrays) call `preprocess()` before `compile()`.
- **`compile()` / `compileModule()`** in the compiler entry ([compiler-core_public_api](compiler-core_public_api.md)) receive the preprocessed code; the composed map flows through to `CompileResult.map`.
- The **parser** ([compiler-parser](compiler-parser.md)) then consumes the transformed source; anything the engine let through (e.g. unresolved `lang="ts"` when no TS preprocessor was configured) will surface as parser/analyzer diagnostics ([compiler-core_diagnostics](compiler-core_diagnostics.md)).

---

## 8. Usage Example

```js
import { preprocess, compile } from 'svelte/compiler';

const { code, map, dependencies } = await preprocess(
  fs.readFileSync('App.svelte', 'utf8'),
  [
    {
      name: 'typescript',
      markup: ({ content }) => ({ code: content }),           // optional whole-file hook
      script: async ({ content, attributes }) => {           // per <script> hook
        if (attributes.lang !== 'ts') return;
        const { code, map, dependencies } = await esbuildTransform(content);
        return { code, map, dependencies, attributes: { ...attributes, lang: undefined } };
      },
      style: async ({ content, attributes }) => { /* e.g. sass */ }
    }
  ],
  { filename: 'src/App.svelte' }
);

const result = compile(code, { filename: 'src/App.svelte' });
// `map` from preprocess composes with the compiler's own map for accurate debugging
```

Note how the `script` hook returns `attributes` without `lang` — `stringify_tag_attributes` renders this back onto the tag so the compiler never sees `lang="ts"`.

---

## 9. Key Invariants & Edge Cases (Maintainer Notes)

1. **Hook order is a contract:** `markup` → `script` → `style`, groups in array order. Changing this order changes observable toolchain behavior.
2. **`sourcemap_list` ordering:** always `unshift`; index 0 is the *newest* map. `combine_sourcemaps` depends on this.
3. **Basename join key:** composition relies on preprocessor maps listing the component file's *basename* in `sources`. Maps with other `sources` entries are offset-skipped, not shifted.
4. **Identity preservation:** no-map + unchanged output (and empty attribute/content tags) short-circuit to sliced identity mappings — never drop through a "transparent" transform that would coarsen the final map.
5. **Attributes are lossy-tolerant:** `parse_tag_attributes` uses a pragmatic regex (`[\w-$]+ = "..." | '...' | bare`); it is not an HTML parser. Bare attributes normalize to `true` and re-serialize as bare.
6. **Comments are skipped:** both tag regexes lead with a `<!--[^]*?-->` alternative so commented-out `<script>`/`<style>` blocks are never preprocessed.
7. **Self-relative locations:** `PreprocessResult` initializes `get_location` from the *initial* source, and every `update_source` rebuilds it — all positional math (offsets, tag maps) is always relative to the *current* string plus absolute offsets captured at match time.
8. **`Processed.toString()`** returns the final code — retained for backwards compatibility with consumers that stringified the result.
9. **No sandboxing:** user hooks are arbitrary async functions; exceptions and malformed maps (e.g. invalid JSON) surface directly. The engine only *warns* for the sourcemap-attachment mismatches it can recover from.
