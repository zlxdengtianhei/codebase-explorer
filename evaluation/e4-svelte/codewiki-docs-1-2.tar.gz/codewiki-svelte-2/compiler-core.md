# compiler-core

## 1. Introduction & Purpose

`compiler-core` is the **foundation layer of the Svelte compiler toolchain** (rooted at `packages/svelte/src/compiler/`). It contains everything that is *shared by* and *orchestrates* the three compiler phases, but deliberately excludes the phase implementations themselves:

| Responsibility | Where it lives |
|---|---|
| Public compiler entry points (`compile`, `compileModule`, `parse`) | `src/compiler/index.js` |
| Per-compilation global state (source, locator, warnings, `svelte-ignore` scopes) | `src/compiler/state.js` |
| Diagnostics infrastructure (errors, warnings, code frames, ignore-comment handling) | `src/compiler/errors.js`, `warnings.js`, `utils/compile_diagnostic.js`, `utils/extract_svelte_ignore.js` |
| Declarative validation of compiler options | `src/compiler/validate-options.js` |
| ESTree AST builders used during code generation | `src/compiler/utils/builders.js` |
| Canonical type definitions (template/CSS/legacy AST, options, results) | `src/compiler/types/*.d.ts` |

The actual phases are owned by sibling modules and documented separately:
**[compiler-parser](compiler-parser.md)** (phase 1 – parsing), **[compiler-analyzer](compiler-analyzer.md)** (phase 2 – analysis), **[compiler-transformer](compiler-transformer.md)** (phase 3 – code generation), **[compiler-preprocessor](compiler-preprocessor.md)** (source preprocessing), and **[compiler-migrator](compiler-migrator.md)** (Svelte 4 → 5 migration).

> **Note on generated code:** `errors.js` and `warnings.js` are *generated* files — they are stamped out by the message pipeline described in [message_code_generation_templates](message_code_generation_templates.md) from `scripts/process-messages/templates/*.js`. Never edit them by hand.

---

## 2. Architecture Overview

### 2.1 Position in the toolchain

`compiler-core` sits *above* the three phases. Its public API composes them into the pipelines exposed to bundlers and tooling, while its state, diagnostics and validation utilities are consumed *by* every phase.

```mermaid
flowchart LR
    subgraph compiler-core
        API["Public API<br/>compile / compileModule / parse"]
        OPT["validate-options.js"]
        STATE["state.js<br/>(session state)"]
        DIAG["errors.js / warnings.js<br/>compile_diagnostic.js<br/>extract_svelte_ignore.js"]
        BUILD["utils/builders.js<br/>(ESTree factories)"]
        TYPES["types/*.d.ts<br/>(AST + result types)"]
    end

    subgraph Compiler Phases
        P1["compiler-parser<br/>(1-parse)"]
        P2["compiler-analyzer<br/>(2-analyze)"]
        P3["compiler-transformer<br/>(3-transform)"]
    end

    SRC[".svelte / .svelte.js source"] --> API
    API --> OPT
    OPT -- "ValidatedCompileOptions" --> API
    API --> P1
    P1 -- "AST.Root" --> P2
    P2 -- "ComponentAnalysis" --> P3

    STATE <-. "read / written" .-> P1
    STATE <-. "read / written" .-> P2
    STATE <-. "read / written" .-> P3
    DIAG -. "error / warning calls" .-> P1
    DIAG -. "error / warning calls" .-> P2
    BUILD -. "code output" .-> P3
    TYPES -. "node shapes" .-> P1
    TYPES -. "node shapes" .-> P2
    TYPES -. "node shapes" .-> P3

    P3 --> RES["CompileResult<br/>{ js, css, warnings, ast, metadata }"]
    RES --> OUT["Bundler / Dev tooling"]
```

### 2.2 Component map

| File | Role | Sub-module documentation |
|---|---|---|
| `index.js` | Public API — orchestrates validate → parse → analyze → transform; exposes `compile`, `compileModule`, `parse`, re-exports `preprocess`, `migrate`, `VERSION` | [compiler-core_public_api.md](compiler-core_public_api.md) |
| `state.js` | Compilation-scoped mutable state: `source`, `locator`, `filename`, `dev`, `runes`, `warnings`, `warning_filter`, ignore stack/map; `reset()`/`adjust()` lifecycle | [compiler-core_compile_state.md](compiler-core_compile_state.md) |
| `errors.js` *(generated)* | `InternalCompileError` (extends `Error`) + ~130 typed error constructors (e.g. `block_unclosed`, `css_global_block_invalid_combinator`, `typescript_invalid_feature`) | [compiler-core_diagnostics.md](compiler-core_diagnostics.md) |
| `warnings.js` *(generated)* | `InternalCompileWarning` + ~80 typed warning emitters (e.g. `css_unused_selector`, `a11y_*`) and the canonical `codes` list | [compiler-core_diagnostics.md](compiler-core_diagnostics.md) |
| `utils/compile_diagnostic.js` | `CompileDiagnostic` base class shared by errors and warnings; renders `file:line:column` + source code frame | [compiler-core_diagnostics.md](compiler-core_diagnostics.md) |
| `utils/extract_svelte_ignore.js` | Parses `<!-- svelte-ignore code1, code2 -->` comments, maps legacy kebab-case codes to modern snake_case codes | [compiler-core_diagnostics.md](compiler-core_diagnostics.md) |
| `validate-options.js` | Combinator validators (`string`, `boolean`, `list`, `fun`, `object`, `removed`, `warn_removed`, `deprecate`) composed into `validate_component_options` / `validate_module_options` | [compiler-core_options_validation.md](compiler-core_options_validation.md) |
| `utils/builders.js` | Factories for ESTree nodes (`b.id`, `b.call`, `b.let`, `b.if`, `b.const`, `b.return`, `b.throw_error`, …) used by code generation | [compiler-core_ast_builders.md](compiler-core_ast_builders.md) |
| `types/template.d.ts` | Modern template AST (`AST.Root`, `AST.Fragment`, elements, directives, blocks, tags) | [compiler-core_type_definitions.md](compiler-core_type_definitions.md) |
| `types/css.d.ts` | CSS AST (`_CSS.StyleSheet`, `Rule`, `SelectorList`, `ComplexSelector`, …) | [compiler-core_type_definitions.md](compiler-core_type_definitions.md) |
| `types/legacy-nodes.d.ts` | Svelte 4 legacy AST shapes (returned by `parse` without `modern: true`) | [compiler-core_type_definitions.md](compiler-core_type_definitions.md) |
| `types/index.d.ts` | `CompileResult`, `CompileOptions`, `ModuleCompileOptions`, `Warning`, `CompileError`, `BindingKind`, `ExpressionMetadata`, `StateField` | [compiler-core_type_definitions.md](compiler-core_type_definitions.md) |

---

## 3. Compilation Data Flow

`compile()` is the canonical walk through the whole toolchain — each arrow below is implemented in `compiler-core`'s public API:

```mermaid
sequenceDiagram
    autonumber
    participant T as Bundler / Tooling
    participant API as compile() — index.js
    participant VO as validate-options.js
    participant ST as state.js
    participant P as parser (1-parse)
    participant A as analyzer (2-analyze)
    participant X as transformer (3-transform)

    T->>API: (source, CompileOptions)
    API->>API: remove_bom(source)
    API->>ST: reset({ warningFilter, filename })
    API->>VO: validate_component_options(options, '')
    VO-->>API: ValidatedCompileOptions | throws CompileError
    API->>P: _parse(source)
    P-->>API: AST.Root { fragment, css, instance, module, options }
    API->>API: merge <svelte:options> + strip TypeScript nodes (if metadata.ts)
    API->>A: analyze_component(parsed, source, options)
    Note over A: runs visitors, builds scopes,<br/>emits errors/warnings
    A-->>API: ComponentAnalysis
    API->>X: transform_component(analysis, source, options)
    X-->>API: { js, css } (source-mapped)
    API->>API: attach public AST<br/>(modernAst ? cleaned AST : legacy convert())
    API-->>T: CompileResult
```

Key behaviours owned by `compiler-core` in this flow:

- **BOM removal** — a leading byte-order mark (`\uFEFF`) would break template generation, so it is stripped before anything else.
- **State reset** — `state.reset()` must run before each compilation; the phases rely on the global `source`/`locator` to build code frames and diagnostics positions.
- **Option merging** — validated CLI/bundler options are merged with inline `<svelte:options>` attributes parsed from the file; inline options win.
- **TypeScript tolerance** — when the parse detects `lang="ts"`, `remove_typescript_nodes()` strips TS-only nodes from fragment/instance/module before analysis (full TS preprocessing is the job of [compiler-preprocessor](compiler-preprocessor.md)).
- **Public AST post-processing** — `to_public_ast()` either strips internal `metadata` fields (modern AST) or converts the whole tree to legacy Svelte-4 shapes via `convert()` in `legacy.js`.

`compileModule()` runs the same pipeline for plain JS/TS modules containing runes — it skips parsing/merging of `<svelte:options>` and is always in runes mode. `parse()` stops after step 6 and only returns the AST.

---

## 4. Diagnostics Flow

All error and warning reporting in the compiler funnels through the shared diagnostics infrastructure. Errors **throw** and abort the compilation; warnings are *collected* and returned in `CompileResult.warnings`.

```mermaid
flowchart TD
    Z["Phase code detects a problem<br/>(parser / analyzer / option validation)"] --> Q{Error or warning?}

    Q -- error --> E["errors.js<br/>e.g. block_unclosed(), css_global_invalid_selector()"]
    E --> CE["InternalCompileError extends Error<br/>copies properties from CompileDiagnostic<br/>name = 'CompileError'"]
    CE --> TH["throw → compilation aborts<br/>(toString() renders code frame)"]

    Q -- warning --> W["warnings.js<br/>e.g. css_unused_selector(), a11y_*"]
    W --> IG{"code in current<br/>svelte-ignore scope?<br/>(state.ignore_stack / ignore_map)"}
    IG -- yes --> DROP["dropped"]
    IG -- no --> F{"state.warning_filter<br/>(from CompileOptions)"}
    F -- false --> DROP
    F -- true --> COL["state.warnings[]"]
    COL --> RES["CompileResult.warnings"]

    E -.->|"wraps"| CD["CompileDiagnostic<br/>(utils/compile_diagnostic.js)"]
    W -.->|"extends"| CD
    CD --> FR["get_code_frame(): renders source lines<br/>with ^ marker at file:line:column"]
```

Supporting pieces:

- **`svelte-ignore` handling** — `extract_svelte_ignore()` reads ignore comments found by the parser. In runes mode it enforces comma-separated, known codes (warning via `legacy_code` / `unknown_code` with fuzzy suggestions otherwise); in legacy mode it is lax and also *pushes* modern replacements for old kebab-case codes. `migrate_svelte_ignore()` rewrites legacy codes to the new format in-place (used by the migrator — see [compiler-migrator](compiler-migrator.md)).
- **Runtime-warning suppression** — `state.push_ignore()` / `pop_ignore()` maintain the ignore scope stack during traversal, while `ignore_map` records per-node ignores for warnings emitted later (e.g. `is_ignored()` consulted by the client runtime in dev mode).

---

## 5. Sub-module Index

Detailed documentation for each sub-module:

1. **[compiler-core_public_api.md](compiler-core_public_api.md)** — `compile()`, `compileModule()`, `parse()`, AST post-processing, BOM handling, deprecation shims (`walk`), re-exports (`preprocess`, `migrate`, `VERSION`).
2. **[compiler-core_compile_state.md](compiler-core_compile_state.md)** — the global compilation session: `reset()`/`adjust()` lifecycle, source locator, filename/rootDir handling, warning filter, ignore stack/map.
3. **[compiler-core_diagnostics.md](compiler-core_diagnostics.md)** — `CompileDiagnostic`, generated error/warning constructors, code frames, `svelte-ignore` extraction & migration.
4. **[compiler-core_options_validation.md](compiler-core_options_validation.md)** — the validator-combinator DSL and the full option tables (common, component-only, removed/renamed options).
5. **[compiler-core_ast_builders.md](compiler-core_ast_builders.md)** — ESTree node factories (`b.*`) that the transformer uses to emit client/server code.
6. **[compiler-core_type_definitions.md](compiler-core_type_definitions.md)** — the three AST flavours (modern template, CSS, legacy) plus compile options/results/binding metadata types.

---

## 6. Relationship to the Rest of the System

```mermaid
flowchart TD
    CC["compiler-core<br/>(this module)"]

    CP["compiler-parser<br/>acorn JS parsing, template tokenizer,<br/>CSS parsing, svelte:options reading"]
    CA["compiler-analyzer<br/>scope creation, visitor passes,<br/>CSS analysis/pruning, runes validation"]
    CT["compiler-transformer<br/>client/server visitors, CSS transform,<br/>template/fragment building"]
    CPR["compiler-preprocessor<br/>replace/_markup/script/style processors"]
    CM["compiler-migrator<br/>Svelte 4 → 5 codemods"]
    MSG["message_code_generation_templates<br/>generates errors.js / warnings.js"]

    PUB["Public package surface<br/>packages/svelte/types/index.d.ts"]
    RT["Client runtime / SSR runtime<br/>(generated code targets)"]

    CP -->|"AST.Root"| CC
    CA -->|"ComponentAnalysis"| CC
    CT -->|"js/css output"| CC
    CC -->|"compile()/parse()"| PUB
    CC -->|"b.* builders"| CT
    MSG -->|"codegen"| CC
    CC -->|"emits imports of svelte/internal/*"| RT
    CC -->|"preprocess re-export"| CPR
    CC -->|"migrate re-export"| CM
```

- **compiler-parser** produces the `AST.Root` (defined by `compiler-core`'s `types/template.d.ts`, `types/css.d.ts`) and reads `<svelte:options>` into `parsed.options`.
- **compiler-analyzer** consumes parsed ASTs and validated options, emits most errors/warnings through `compiler-core` diagnostics, and depends on `state.adjust()` being called with the resolved `runes`/`dev`/`component_name`.
- **compiler-transformer** consumes the `ComponentAnalysis` and emits code exclusively through `compiler-core`'s `utils/builders.js`, targeting the runtime modules documented under *Client Runtime Engine* and *Server-Side Rendering*.
- **compiler-preprocessor / compiler-migrator** are re-exported as part of the `svelte/compiler` public surface (`preprocess`, `migrate`) but documented in their own modules.
