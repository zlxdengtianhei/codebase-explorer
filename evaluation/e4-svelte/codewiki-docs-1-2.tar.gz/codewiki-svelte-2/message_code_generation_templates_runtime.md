# Message Code Generation Templates — Runtime (`message_code_generation_templates_runtime`)

## 1. Introduction

This module hosts the **five code-generation templates** from which every *runtime* error and warning helper in the Svelte package is mechanically derived:

| Template | Generated destination | Kind |
| --- | --- | --- |
| `templates/client-errors.js` | `src/internal/client/errors.js` | Errors (browser/client runtime) |
| `templates/client-warnings.js` | `src/internal/client/warnings.js` | Warnings (browser/client runtime) |
| `templates/server-errors.js` | `src/internal/server/errors.js` | Errors (SSR / server runtime) |
| `templates/shared-errors.js` | `src/internal/shared/errors.js` | Errors (shared by client **and** server) |
| `templates/shared-warnings.js` | `src/internal/shared/warnings.js` | Warnings (shared by client **and** server) |

The templates are **not imported by application or runtime code directly**. They are *stencils*: each contains a single placeholder function named `CODE` whose body references `MESSAGE` and `PARAMETER` placeholders. At build time, the script `packages/svelte/scripts/process-messages/index.js` expands this stencil **once per message** defined in the markdown message sources (one `## <code>` section per message), producing the concrete modules listed above — all of which carry a `/* This file is generated … Do not edit! */` banner.

This design gives Svelte a single source of truth for diagnostics (markdown), consistent UX (dev-mode rich messages, production minimal messages), a published error reference (generated docs), and byte-efficient production bundles (message strings are stripped in production builds).

> **Scope note:** this document covers the *runtime* templates. The compile-time templates (`compile-errors.js`, `compile-warnings.js` → `src/compiler/errors.js` / `src/compiler/warnings.js`) share the same machinery and are documented in [Compile-time Message Templates](message_code_generation_templates_compile_time.md). Both are children of [Message Code Generation Templates](message_code_generation_templates.md).

---

## 2. Position in the system

```mermaid
flowchart LR
    subgraph tooling["Build-time tooling"]
        MD["messages/&lt;template&gt;/*.md<br/>(message sources)"]
        TPL["scripts/process-messages/templates/*.js<br/>(THIS MODULE)"]
        GEN["scripts/process-messages/index.js<br/>(generator)"]
    end

    subgraph pkg["svelte package source (generated)"]
        CE["src/internal/client/errors.js"]
        CW["src/internal/client/warnings.js"]
        SE["src/internal/server/errors.js"]
        SHE["src/internal/shared/errors.js"]
        SHW["src/internal/shared/warnings.js"]
        COMP["src/compiler/errors.js + warnings.js"]
    end

    subgraph runtime["Runtime subsystems (consumers)"]
        CR["Client Runtime Engine"]
        SR["Server-Side Rendering"]
        SH["Internal shared utils"]
    end

    REF["Generated reference docs<br/>documentation/docs/98-reference/.generated/*.md"]

    MD --> GEN
    TPL --> GEN
    GEN --> CE
    GEN --> CW
    GEN --> SE
    GEN --> SHE
    GEN --> SHW
    GEN --> COMP
    GEN --> REF
    CE --> CR
    CW --> CR
    SE --> SR
    SHE --> SH
    SHW --> SH
```

The module sits at the junction between three larger areas of the codebase:

- **[Client Runtime Engine (Reactivity & DOM Rendering)](client_runtime_engine_reactivity___dom_rendering.md)** — imports the generated `internal/client/errors.js` and `internal/client/warnings.js` helpers for dev-mode validation, binding checks, boundary handling, HMR, and ownership validation.
- **[Server-Side Rendering & Cross-Target Runtime Services](Server-Side_Rendering___Cross-Target_Runtime_Services.md)** — imports `internal/server/errors.js` plus the shared modules.
- **[Compiler Core — Diagnostics](compiler-core_diagnostics.md)** — the *conceptual sibling*: compile-time diagnostics follow the same pipeline but originate from the compile-time templates (see [Compile-time Message Templates](message_code_generation_templates_compile_time.md)).

---

## 3. Template anatomy

All five templates follow the same skeleton. A representative shape (client errors):

```js
import { DEV } from 'esm-env';

export * from '../shared/errors.js';

/**
 * MESSAGE
 * @param {string} PARAMETER
 * @returns {never}
 */
export function CODE(PARAMETER) {
	if (DEV) {
		const error = new Error(`${'CODE'}\n${MESSAGE}\nhttps://svelte.dev/e/${'CODE'}`);
		error.name = 'Svelte error';
		throw error;
	} else {
		throw new Error(`https://svelte.dev/e/${'CODE'}`);
	}
}
```

### 3.1 Placeholders

| Placeholder | Location | Meaning after expansion |
| --- | --- | --- |
| `CODE` | function name + string literals | the stable message code, e.g. `invalid_default_snippet`; also finalizes the docs URL `https://svelte.dev/e/<code>` |
| `MESSAGE` | inside the template literal | the human-readable message text, inlined as literals and/or template-literal expressions derived from `%var%` parameters |
| `PARAMETER` | function parameter list | replaced by the concrete `%var%` names extracted from the message text |
| `CODES` (identifier) | optional, not used by runtime templates | replaced by an array literal of all codes in the category (used by some compile-time templates) |

The JSDoc comment above the function is also a placeholder: `* MESSAGE` becomes the message text and the `@param {string} PARAMETER` line is rewritten per-message with real parameter names.

### 3.2 Per-template behavioral differences

| Template | `DEV` gate? | Error/warning payload in DEV | Payload in production | Re-exports |
| --- | --- | --- | --- | --- |
| `client-errors.js` | ✅ (`esm-env`) | `Error` named `'Svelte error'` with `code\nmessage\nURL` | `Error` containing only `https://svelte.dev/e/<code>` | `export * from '../shared/errors.js'` |
| `shared-errors.js` | ✅ (`esm-env`) | same as client-errors | same as client-errors | — |
| `server-errors.js` | ❌ | always full `Error` with code, message, docs URL | (server output is never shipped to browsers, so no prod minimization is needed) | `export * from '../shared/errors.js'` |
| `client-warnings.js` | ✅ (`esm-env`) | styled `console.warn('%c[svelte] code\n%cmessage\nURL', bold, normal)` | `console.warn('https://svelte.dev/e/<code>')` | — |
| `shared-warnings.js` | ✅ (`esm-env`) | styled `console.warn` (same format) | `console.warn('https://svelte.dev/e/<code>')` | — |

Key points:

- The `DEV` flag comes from the [`esm-env`](https://www.npmjs.com/package/esm-env) package, so bundlers can statically eliminate the unused branch per build mode.
- Error helpers are typed `@returns {never}` (they always throw); warning helpers return `void`.
- Both `client-errors.js` and `server-errors.js` re-export `../shared/errors.js` — the relative path resolves to `src/internal/shared/errors.js` from *both* destination folders, so shared diagnostics are reachable from whichever error module a subsystem already imports.
- Warning templates define module-level `bold` / `normal` font-weight CSS strings for `%c` console styling in dev.

### 3.3 Verified generated outputs

```js
// src/internal/shared/errors.js (from shared-errors.js template)
export function invalid_default_snippet() {
	if (DEV) {
		const error = new Error(`invalid_default_snippet\nCannot use \`{@render children(...)}\` …\nhttps://svelte.dev/e/invalid_default_snippet`);
		error.name = 'Svelte error';
		throw error;
	} else {
		throw new Error(`https://svelte.dev/e/invalid_default_snippet`);
	}
}
```

Other real outputs: `bind_invalid_export` / `svelte_boundary_reset_noop` in `src/internal/client/{errors,warnings}.js` — note how the `%component%`, `%key%`, `%name%` placeholders of the `bind_invalid_export` message became the function's parameters in dev builds.

---

## 4. Code generation pipeline

```mermaid
flowchart TD
    A["Read message sources<br/>messages/&lt;template-name&gt;/*.md"] --> B["Parse '## CODE' sections<br/>(reject duplicates, sort codes)"]
    B --> C["Emit generated reference docs<br/>documentation/docs/98-reference/.generated/&lt;category&gt;.md"]
    C --> D["Read template: scripts/process-messages/templates/&lt;name&gt;.js"]
    D --> E["acorn.parse (sourceType: module, comments captured)"]
    E --> F["Rewrite 'CODES' identifiers into an array of code literals (if present)"]
    F --> G["Locate 'export function CODE' + nearest preceding JSDoc block"]
    G --> H["For each message code:"]
    H --> H1["Extract %var% tokens → function parameters"]
    H --> H2["Build MESSAGE expression<br/>(literal / template literal / conditional overloads)"]
    H --> H3["Clone template AST:<br/>CODE→code, MESSAGE→text, PARAMETER→vars, rewrite JSDoc"]
    H1 --> H3
    H2 --> H3
    H3 --> I["esrap.print → source text"]
    I --> J["Write destination file with<br/>'generated by scripts/process-messages' banner"]
    J --> K{"more codes?"}
    K -->|yes| H
    K -->|no| L{"more templates?"}
    L -->|yes| D
    L -->|no| M["done — supports '-w' watch mode<br/>(fs.watch on messages/)"]
```

Step by step:

1. **Message sources.** The generator reads markdown files under `messages/<template-name>/*.md`. Each `## <CODE>` heading introduces one diagnostic; the leading `> `-quoted paragraphs are the message text(s); trailing unquoted paragraphs are explanatory *details* used only for documentation. Codes must be globally unique — duplicates abort the run.
2. **Reference docs.** For every category the generator also writes a sorted reference page into `documentation/docs/98-reference/.generated/`, keeping svelte.dev's error/warning documentation in lock-step with the code.
3. **AST-level stencil expansion.** The template is parsed with `acorn` (comments preserved), and the `export function CODE` node plus its JSDoc are extracted. For each message, the AST is cloned with `zimmerframe.walk` and rewritten:
   - every `Literal`/string `'CODE'` and the function name become the concrete code;
   - the `MESSAGE` identifier is replaced by the message expression — plain literal, or a template literal whose expressions are the `%var%` parameters;
   - if a message defines multiple quoted paragraphs with increasing parameter sets, nested `ConditionalExpression`s are produced ("overloads"): later parameters are optional (`string | undefined | null`) and select the more specific message text;
   - the `PARAMETER` parameter is expanded to the concrete variable list, and the JSDoc is regenerated with the final message and `@param` lines.
4. **Printing.** `esrap` prints the transformed AST back to JavaScript, prefixed with the do-not-edit banner, and the file is written to the destination shown in §1.

> The mapping `template name → destination` is hardcoded at the bottom of `scripts/process-messages/index.js` (`transform('client-errors', 'src/internal/client/errors.js')`, etc.). Adding a new template requires a matching entry there **and** a `messages/<name>/` source directory.

---

## 5. Runtime emission behavior

```mermaid
flowchart TD
    CALL["Generated helper invoked by runtime code"] --> KIND{"Template family"}

    KIND -->|"client-errors / shared-errors"| D{"DEV flag (esm-env)"}
    D -->|true| E1["throw Error (name = 'Svelte error')<br/>message = code + human text + docs URL"]
    D -->|false| E2["throw Error with only<br/>https://svelte.dev/e/&lt;code&gt;"]

    KIND -->|server-errors| E3["always throw full Error:<br/>code + human text + docs URL<br/>(no DEV gate)"]

    KIND -->|"client-warnings / shared-warnings"| W{"DEV flag (esm-env)"}
    W -->|true| W1["console.warn styled:<br/>bold '[svelte] code' + normal message + URL"]
    W -->|false| W2["console.warn with only<br/>https://svelte.dev/e/&lt;code&gt;"]

    E1 --> X["developer sees actionable message<br/>and a permanent docs link"]
    E2 --> X2["production keeps URL only<br/>(minimal bundle size)"]
    E3 --> X3["server logs are always complete"]
    W1 --> Y["dev-time console warning"]
    W2 --> Y2["prod console warning, URL only"]
```

Behavioral contract:

- **Errors always throw** (return type `never`). In development the thrown `Error` carries `name = 'Svelte error'`, the code, the full human message, and the canonical `https://svelte.dev/e/<code>` URL. In production the same helper throws an `Error` whose message is only the URL — enough to paste into a browser console and look up, while keeping megabytes-scale message text out of shipped bundles.
- **Warnings never throw.** They `console.warn`, using `%c` styling in dev (bold code prefix) and degrade to a bare URL in production.
- **Server-side helpers are never minimized**: since SSR output stays on the server, `server-errors.js` always emits the full message regardless of build mode.

---

## 6. Message definition format (source of truth)

A message entry in `messages/<template-name>/*.md`:

```markdown
## bind_invalid_export

> Component `%component%` has an export named `%key%` that a consumer component is trying to
> access using `bind:%key%`, which is disallowed. Instead, use `bind:this` …

> Component `%component%` has an export named `%key%` …

(optional trailing paragraphs become docs "details")
```

- `%name%` tokens become **function parameters** of the generated helper and expression interpolations of the message.
- Multiple quoted paragraphs act as **overloads**: each additional paragraph must introduce new parameters; the generator nests conditional expressions so the most specific matching message is shown, and later parameters are typed optional in JSDoc.

---

## 7. Consumers & dependency graph

```mermaid
flowchart LR
    subgraph generated["Generated modules (this module's outputs)"]
        CE["internal/client/errors.js"]
        CW["internal/client/warnings.js"]
        SE["internal/server/errors.js"]
        SHE["internal/shared/errors.js"]
        SHW["internal/shared/warnings.js"]
    end

    subgraph client["Client Runtime Engine"]
        DEVT["internal/client/dev/*<br/>(ownership, hmr, validation, legacy)"]
        REACT["internal/client/runtime.js, props.js, store.js"]
        BLOCKS["internal/client/dom/blocks/*<br/>(boundary, snippet, each, …)"]
    end

    subgraph server["Server-Side Rendering"]
        SIDX["internal/server/index.js"]
        SBLK["internal/server/blocks/*, dev.js"]
    end

    SUB["internal/shared/*<br/>(utils, validate, clone)"]

    CE --> DEVT
    CE --> REACT
    CE --> BLOCKS
    CW --> BLOCKS
    CW --> DEVT
    SHE --> SUB
    SHW --> SUB
    SUB --> client
    SUB --> server
    SE --> SIDX
    SE --> SBLK
    SHE -.->|"re-exported by"| CE
    SHE -.->|"re-exported by"| SE
```

Representative consumers (see the linked module docs for full detail):

- **Client runtime** — `bind_invalid_export`, `bind_not_bindable`, `props_rest_readonly`, `svelte_boundary_reset_onerror` (errors) and `svelte_boundary_reset_noop` (warning) are raised by the reactivity/props/boundary subsystems and dev tooling such as ownership validation and HMR wrappers.
- **Server runtime** — `internal/server/index.js` and block helpers raise server errors for invalid props/snippets/etc. during SSR.
- **Shared code** — `invalid_default_snippet` and friends live in `internal/shared/errors.js` and are reachable from both targets via the `export * from '../shared/errors.js'` re-export in the client/server error modules.

---

## 8. Integration with other modules

| Related module | Relationship |
| --- | --- |
| [Message Code Generation Templates](message_code_generation_templates.md) | Parent module; owns the generator script and the template directory as a whole. |
| [Compile-time Message Templates](message_code_generation_templates_compile_time.md) | Sibling; same pipeline, feeds `src/compiler/errors.js` / `warnings.js` used by the analysis phase. |
| [Compiler Core — Diagnostics](compiler-core_diagnostics.md) | Consumer-side counterpart: how compile-time diagnostics (`CompileError`, code frames, `svelte-ignore`) are surfaced to users. |
| [Client Runtime Engine (Reactivity & DOM Rendering)](client_runtime_engine_reactivity___dom_rendering.md) | Primary consumer of `client-errors.js` / `client-warnings.js` outputs. |
| [Server-Side Rendering & Cross-Target Runtime Services](Server-Side_Rendering___Cross-Target_Runtime_Services.md) | Primary consumer of `server-errors.js` and shared modules. |

---

## 9. Developer workflow: adding a runtime error or warning

1. **Define the message** — add a `## <code>` section (unique, snake_case) with its quoted message paragraphs to the appropriate `messages/<template-name>/*.md` file. Use `%var%` tokens for dynamic parts.
2. **Regenerate** — run the message processor (supports `-w` watch mode). This rewrites the destination modules **and** the generated reference docs.
3. **Consume** — import the newly generated named export (e.g. `import { my_new_error } from '../errors.js';`) in the relevant client/server/shared runtime code and call it with the message parameters.
4. **Never edit generated files** — `src/internal/**/errors.js`, `warnings.js` and the `.generated` docs are output artifacts; edit the markdown source instead.

---

## 10. Design rationale

- **Single source of truth** — message text, docs, and code are all derived from one markdown entry, eliminating drift between svelte.dev documentation and runtime behavior.
- **Production payload hygiene** — `esm-env`'s static `DEV` flag lets bundlers tree-shake full message strings out of production builds; users still get a resolvable `https://svelte.dev/e/<code>` URL.
- **Consistent developer experience** — every diagnostic carries the same shape (`code / message / URL`), styled warning prefixes, and an `error.name` of `'Svelte error'` for easy filtering.
- **Ergonomic parameterization** — `%var%` placeholders and overload paragraphs generate properly typed helpers (required first-message params; `string | undefined | null` optional params for overloads) with full JSDoc, with zero hand-written plumbing.
- **Deterministic output** — codes are de-duplicated and sorted; every generated file is reproducible from the sources, reviewable in diffs, and clearly marked as generated.