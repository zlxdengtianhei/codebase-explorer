# Compiler Migrator

## Overview

The **compiler-migrator** module (`packages/svelte/src/compiler/migrate/index.js`) implements automated, best-effort migration of **Svelte 4 (legacy syntax) components to Svelte 5 (runes, snippets, event attributes)**. It exposes a single public entry point, `migrate(source, options)`, which returns rewritten source code.

Unlike the rest of the compiler, the migrator does **not** regenerate code from the AST. It performs *surgical, text-preserving edits* on the original source using [`magic-string`](https://github.com/Rich-Harris/magic-string), so comments, formatting, and indentation survive the transformation. When a construct cannot be migrated safely, the migrator throws an internal `MigrationError`; the top-level `migrate()` call catches it and injects an `<!-- @migration-task ... -->` comment next to the untouched original code, flagging the file for manual attention.

### Key Design Properties

- **Idempotent output target**: produces code that compiles under Svelte 5 runes mode (`$props()`, `$state()`, `$derived()`, snippets, event attributes).
- **Lossless fallback**: on any failure, the original source is returned verbatim, prefixed with a migration-task comment — a migration never produces a *partially* broken file.
- **Reuses compiler front-end**: parses and analyzes with the exact same [compiler-parser](compiler-parser.md) and [compiler-analyzer](compiler-analyzer.md) used for compilation, guaranteeing the input model matches what the production compiler sees.
- **Delegates to `svelte/legacy`**: behaviors that have no runes equivalent (e.g., `$:` blocks with side effects, event modifiers) are rewritten to imports from the runtime's [legacy-compat](legacy-compat.md) layer.

---

## Architecture

The migrator is orchestrated by `migrate()`, which chains the parser and analyzer, then walks the instance script and the template with two dedicated visitor maps (`instance_script`, `template`). Shared helpers perform the recurring transformation families (events, slots, identifiers, types).

```mermaid
flowchart TB
    subgraph MIG["compiler-migrator (this module)"]
        direction TB
        M["migrate(source, { filename, use_ts })<br/>orchestrator + error guard"]
        IS["instance_script visitors<br/>(script transformations)"]
        TV["template visitors<br/>(markup transformations)"]
        HLP["Shared helpers<br/>handle_events · handle_identifier<br/>migrate_slot_usage · extract_type_and_comment<br/>trim_block · migrate_css · guess_indent"]
    end

    subgraph CORE["[compiler-core](compiler-core.md)"]
        ST["state.reset()"]
        VO["validate_component_options()"]
        DI["migrate_svelte_ignore()<br/>(see [compiler-core_diagnostics](compiler-core_diagnostics.md))"]
        ASTU["utils/ast.js<br/>extract_identifiers · is_text_attribute"]
    end

    subgraph PAR["[compiler-parser](compiler-parser.md)"]
        P["parse()"]
        OPT["read_options()"]
        VN["regex_valid_component_name"]
    end

    subgraph ANA["[compiler-analyzer](compiler-analyzer.md)"]
        AC["analyze_component()"]
        SC["Scope · get_rune()"]
    end

    subgraph OUT["Outputs / Consumers"]
        MS["MagicString<br/>(positional edits)"]
        RES["{ code } — migrated Svelte 5 source"]
        TASK["@migration-task comment<br/>+ original source (on failure)"]
        LEG["import { run, handlers,<br/>createBubbler, preventDefault, ... }<br/>from 'svelte/legacy'"]
        LEGIMPL["[legacy-compat](legacy-compat.md)<br/>runtime implementation"]
    end

    M -->|"source"| P
    P --> OPT
    M --> ST
    M --> VO
    P -->|"AST"| AC
    AC --> SC
    M -->|"instance AST"| IS
    M -->|"fragment AST"| TV
    IS --> HLP
    TV --> HLP
    HLP --> DI
    HLP --> ASTU
    HLP --> VN
    HLP --> MS
    M --> MS
    MS --> RES
    M -.->|"MigrationError"| TASK
    M -->|"legacy_imports set"| LEG
    LEG --> LEGIMPL
```

> The migrator intentionally does **not** use [compiler-transformer](compiler-transformer.md): the transformer *generates* runtime output, while the migrator *edits user source*. Both share the same AST shape and visitor idioms, but the migrator runs in isolation of phases 3.

---

## Core Components

### 1. `migrate(source, options)` — Orchestrator

The only exported function. Accepts `{ filename?: string, use_ts?: boolean }` and returns `{ code: string }`.

Responsibilities, in order:

1. **Blank `<style>` blocks** — replaces CSS contents with a placeholder (`style_placeholder`) before parsing, since preprocessor languages (SCSS, etc.) cannot be parsed by the Svelte CSS parser. Contents are restored into the MagicString at the end.
2. **Reset compiler state** — `reset({ warning: () => false, filename })`. All compiler warnings are *suppressed* during migration because legacy Svelte 4 code triggers dozens of deprecation warnings that are irrelevant here.
3. **Parse & analyze** — `parse()` from [compiler-parser](compiler-parser.md), then `analyze_component()` from [compiler-analyzer](compiler-analyzer.md) with merged options (including `experimental.async: true`). This yields `ComponentAnalysis` with scopes, binding kinds (`state`, `bindable_prop`, `legacy_reactive`, `store_sub`, …), flags (`uses_props`, `uses_rest_props`, `uses_slots`), and `reactive_statements`.
4. **Initialize `State`** — the shared context threaded through every visitor (see [State Object](#state-object)). Uniquely-generated collision-free names are allocated here (`props`, `rest`, `run`, `handlers`, `createBubbler`, every event modifier, …) via `analysis.root.unique()`.
5. **Strip `<svelte:options accessors>`** and restore preprocessor style contents.
6. **Walk the instance script** (`instance_script` visitors), **walk the template** (`template` visitors).
7. **Post-processing pass** — builds the final edits:
   - insert a `<script>` tag if the component had none but now needs one (plus `lang="ts"` when TypeScript is detected);
   - add the `svelte/legacy` import line and collected script insertions;
   - emit the `let { ... } = $props()` declaration with an inferred `Props` interface (TS) or `@typedef` (JSDoc);
   - **reorder reactive statements** when Svelte 4's implicit reordering semantics require it (`$derived`/`$effect.pre` do not reorder);
   - append `$derived(...)` constants for migrated dynamic components and shadowed slots;
   - emit the `export { ... }` accessor block when `accessors` was requested.
8. **CSS migration** (`migrate_css`) — wraps `:has`, `:is`, `:where`, `:not` arguments (and any selector matching an earlier `:global(...)` continuation) in `:global(...)`, mirroring the scoping-rule change of Svelte 5.
9. **Error guard** — any `MigrationError` becomes an `@migration-task` comment + original source; unexpected exceptions are additionally `console.error`-ed. A module-level `has_migration_task` flag drives a final user-facing `console.log` reminding authors to finish the migration manually.

### 2. `instance_script` — Script Visitors

Walked over `parsed.instance.content` with the instance scope. Key visitors:

| Visitor | Migration behavior |
| --- | --- |
| `_` (fallback) | Rewrites `// svelte-ignore some-code` comments via `migrate_svelte_ignore()` (kebab-case → snake_case codes; see [compiler-core_diagnostics](compiler-core_diagnostics.md)). |
| `Identifier` | Delegates to `handle_identifier()` for `$$props` / `$$restProps` / `$$slots` / `$$Props` interface handling. |
| `ImportDeclaration` | Removes now-unused `beforeUpdate` / `afterUpdate` specifiers from `import 'svelte'` (and the whole import if unused); throws `MigrationError` if they are actually referenced. Tracks the props insertion point (after the last import). |
| `ExportNamedDeclaration` | Drops re-exports (`export { foo }`) of identifiers that became bindable props, since they are covered by `$props()`. |
| `VariableDeclaration` | **The heart of the migration.** For top-level declarations in the instance scope:<br/>• `export let x = 1` → removed from source; recorded as a prop entry → later emitted inside `let { ... } = $props()`<br/>• `let x = 1` with `state` binding kind → wraps initializer: `let x = $state(1)`<br/>• Uninitialized `let x` reassigned only inside a single `$:` statement → becomes `let x = $derived(...)` or `let x = $state(...)`, consuming the labeled statement<br/>• Detects an existing `$props` rune (`has_props_rune`) to splice extra props into it |
| `BreakStatement` | `break $` inside `$: { ... }` → `return;` (used by the legacy `run` wrapper). |
| `LabeledStatement` | `$:` handling:<br/>• `$: y = expr` → `let y = $derived(expr)` (when all targets are legacy_reactive, not stores/members)<br/>• `$: x = literal` with no deps → inlined into `$state(...)`<br/>• implicit declarations → hoisted `let x = $state(...)` lines<br/>• anything else (side effects, blocks, store deps) → `run(() => { ... })` with `state.str.indent()` re-indentation, importing `run` from `svelte/legacy` |

A local `check_rune_binding()` guard runs before every rune insertion: if the user already has a variable named `state`, `derived`, `props`, or `bindable`, migration aborts with a `MigrationError` telling them to rename first.

### 3. `template` — Markup Visitors

Walked over `parsed.fragment` with the template scope.

| Visitor | Migration behavior |
| --- | --- |
| `RegularElement` | Slot migration, event migration (`handle_events`), and rewriting self-closing syntax `<div />` → `<div></div>` for non-void, non-SVG elements (HTML5 validity). |
| `SvelteElement` | Slot migration, event migration; converts static `tag="..."` literals to expression syntax `{tag="..."}`. |
| `SvelteSelf` | `<svelte:self>` → `<ComponentName />` (open + closing tags), inserting `import ComponentName from './file.svelte'`. Without a filename, emits a migration task. |
| `SvelteComponent` | `<svelte:component this={C}>` → `<C />`. Non-identifier expressions are hoisted: `{@const tmp = expr}` inside block scopes, or a shared `const tmp = $derived(expr)` at script level. Removes the `this={...}` attribute. |
| `SlotElement` | `<slot name="x" prop={v}>fallback</slot>` → `{#if x}{@render x({ prop: v })}{:else}fallback{/if}`; default slot without props → `{@render children?.()}`. Registers slot snippets as `$props()` entries typed `import('svelte').Snippet`. Handles name shadowing via `$derived` aliases (`derived_conflicting_slots`). Skipped for custom elements. |
| `SvelteFragment` | `<svelte:fragment slot="x" let:p>` → wraps content in `{#snippet x({ p })}...{/snippet}`. |
| `Component` | Slot migration on the receiving side (`<Comp>` with `slot=` / `let:` children). |
| `SvelteWindow` / `SvelteBody` / `SvelteDocument` | Event migration (`handle_events`). |
| `Comment` | Migrates `<!-- svelte-ignore code-a code-b -->` codes to snake_case. |
| `HtmlTag` / `ConstTag` / `IfBlock` / `AwaitBlock` / `KeyBlock` | `trim_block()` — collapses insignificant whitespace inside `{ ... }` expression braces so the printed expressions are clean. |

### 4. Shared Helpers

- **`handle_events(element, state)`** — converts `on:click={fn}` directives to event attributes. Groups handlers per event name (+`capture`); wraps bodies with legacy modifier helpers in Svelte-4 order: `preventDefault`, `stopPropagation`, `stopImmediatePropagation`, `self`, `trusted`, `once` — each added to `legacy_imports`. `passive`/`nonpassive` become `use:passive={['click', fn]}` actions instead. Multiple handlers for one event become `onclick={handlers(fn1, fn2)}`. Handler-less `on:click` becomes `onclick={bubble('click')}` via `createBubbler()`.
- **`handle_identifier(node, state, path)`** — rewrites `$$props`/`$$restProps` to the generated `props`/`rest` names; rewrites `$$slots.x` member accesses to snippet references (`children` for `default`), registering `Snippet<[any]>` props (type refined lazily via `needs_refine_type`); expands a `$$Props` TS interface into individual prop entries (with types, optionality, leading/trailing comments) and deletes the interface.
- **`migrate_slot_usage(node, path, state)`** — for `slot="name"` attributes and `let:` directives on component children: emits `{#snippet name({ let bindings })}` around the content, removes the directives, splits interleaved default/named content, guards against invalid identifiers, reserved words, and props shadowing (emitting migration tasks when blocked).
- **`extract_type_and_comment(declarator, state, path)`** — infers a prop's type from, in priority order: a TS `typeAnnotation` on the declarator, an `@type {...}` JSDoc on the preceding comment, or a literal initializer (`string`/`number`/`boolean`); falls back to `any`. Cleans and preserves JSDoc descriptions and trailing comments (respecting TS vs JSDoc output mode) and strips `@`-annotation blocks.
- **`trim_block(state, start, end)`** — normalizes whitespace inside block-level `{ }` expressions.
- **`get_node_range(source, node)`** — computes a reactive statement's true span including leading/trailing comments, snapped to line start (used by the reordering pass).
- **`guess_indent(content)`** — detects tabs vs spaces so inserted code matches file style.

### State Object

The `State` typedef threads mutable migration context through all walks:

```js
{
  scope,                    // current Scope (instance → swapped to template scope)
  str,                      // MagicString — all edits accumulate here
  analysis,                 // ComponentAnalysis from compiler-analyzer
  indent,                   // detected indentation unit
  props: [],                // collected prop descriptors { local, exported, init,
                            //   bindable, optional, type, comment, slot_name?, ... }
  props_insertion_point,    // where the $props() declaration is spliced
  has_props_rune,           // component already declares $props()
  names: { props, rest, run, handlers, createBubbler, preventDefault, ... },
  legacy_imports,           // svelte/legacy specifiers to import
  script_insertions,        // e.g. const bubble = createBubbler();
  derived_components,       // hoisted $derived consts for dynamic components
  derived_conflicting_slots,// $derived aliases for shadowed slot names
  derived_labeled_statements, // $: statements consumed by earlier rewrites
  has_svelte_self, uses_ts  // flags driving import/export emission
}
```

---

## Migration Process Flow

```mermaid
flowchart TD
    A["migrate(source, { filename, use_ts })"] --> B["Blank <style> contents<br/>(preprocessor-safe)"]
    B --> C["reset() — suppress warnings,<br/>set filename"]
    C --> D["parse() → AST<br/>[compiler-parser](compiler-parser.md)"]
    D --> E["validate_component_options +<br/>merge parsed <svelte:options>"]
    E --> F["analyze_component() → ComponentAnalysis<br/>[compiler-analyzer](compiler-analyzer.md)"]
    F --> G["Init MagicString + State<br/>(unique names, empty import sets)"]
    G --> H["walk(instance, instance_script)<br/>props · $state · $derived · run()"]
    H --> I["walk(fragment, template)<br/>slots · events · svelte:component/self"]
    I --> J{"needs <script>?"}
    J -- yes --> K["Insert <script>[ lang=ts] ·<br/>svelte/legacy imports · insertions"]
    J -- no --> L["Emit $props() declaration +<br/>Props interface / @typedef"]
    K --> L
    L --> M{"Reactive statements<br/>out of declaration order?"}
    M -- yes --> N["Move $: statements (with comments)<br/>to end of instance script"]
    M -- no --> O
    N --> O["Append $derived consts<br/>(components · shadowed slots) · export accessors"]
    O --> P["Close inserted </script>"]
    P --> Q["migrate_css(): wrap :has/:is/:where/:not<br/>in :global(...)"]
    Q --> R["Restore real style contents"]
    R --> S["Return { code }"]

    H -. throws .-> X["catch (e)"]
    I -. throws .-> X
    X -->|"MigrationError"| T["code = '<!-- @migration-task: e.message -->'<br/>+ original source"]
    X -->|"unexpected"| Y["console.error(e)"] --> T
    T --> Z["finally: log manual-migration reminder"]
    S --> Z
```

### Data Flow: Source → Edits → Output

```mermaid
flowchart LR
    SRC["Svelte 4 source<br/>(string)"] -->|"parse + analyze"| AST["AST + Scopes +<br/>Binding kinds"]
    AST -->|"zimmerframe walk<br/>(2 passes)"| STATE["State (props,<br/>imports, names)"]
    STATE -->|"update / remove /<br/>prepend / append / move / indent"| MS["MagicString"]
    SRC -.original positions.-> MS
    MS --> OUT1["migrated code"]
    AST -->|"unmigratable"| ERR["MigrationError"]
    ERR --> OUT2["@migration-task +<br/>original code"]
```

### Sequence: A Typical Migration

```mermaid
sequenceDiagram
    autonumber
    participant Tool as Codemod tooling<br/>(e.g. svelte-migrate)
    participant M as migrate()
    participant P as parse — [compiler-parser](compiler-parser.md)
    participant A as analyze_component — [compiler-analyzer](compiler-analyzer.md)
    participant V as visitors (instance + template)
    participant MS as MagicString
    participant L as svelte/legacy — [legacy-compat](legacy-compat.md)

    Tool->>M: source, { filename, use_ts }
    M->>P: parse(source)
    P-->>M: AST { instance, module, fragment, css, options }
    M->>A: analyze_component(ast, source, options)
    A-->>M: analysis { scopes, bindings, reactive_statements, uses_* flags }
    M->>V: walk(instance content)
    V->>MS: rewrite export let / $: statements
    M->>V: walk(fragment)
    V->>MS: on:click → onclick, slot → snippet, $$slots → children
    M->>MS: inject $props() declaration, legacy imports
    MS-->>M: toString()
    M-->>Tool: { code }
    Note over M,L: Generated code references `run`, `handlers`, `preventDefault`, …<br/>which resolve to L at runtime.
```

---

## Key Transformation Reference

| Svelte 4 input | Migrated Svelte 5 output | Implemented by |
| --- | --- | --- |
| `export let count = 0` | `let { count = 0 } = $props();` | `instance_script.VariableDeclaration` |
| `export let x /** @type {number} */` / typed `export let` | `Props` interface or `@typedef {Object} Props` + `let { x }: Props = $props();` | `extract_type_and_comment` |
| `let n = 0` (reassigned) | `let n = $state(0)` | `instance_script.VariableDeclaration` |
| `$: doubled = n * 2` | `let doubled = $derived(n * 2);` | `instance_script.LabeledStatement` |
| `$: { doThing(); }` | `run(() => { doThing(); });` + `import { run } from 'svelte/legacy'` | `instance_script.LabeledStatement` |
| `$: { … break $; }` | `run(() => { … return; })` | `instance_script.BreakStatement` |
| `on:click={fn}` | `onclick={fn}` | `handle_events` |
| `on:click|preventDefault|once={fn}` | `onclick={once(preventDefault(fn))}` | `handle_events` |
| `on:click|passive={fn}` | `use:passive={['click', fn]}` | `handle_events` |
| `on:click` (no handler) | `onclick={bubble('click')}` + `createBubbler()` | `handle_events` |
| `<slot name="head" let:item>fb</slot>` | `{#if head}{@render head({ item })}{:else}fb{/if}` + `head` snippet prop | `template.SlotElement` |
| `<slot />` | `{@render children?.()}` | `template.SlotElement` |
| `<Comp><div slot="x" let:p>…</div></Comp>` | `<Comp>{#snippet x({ p })}…{/snippet}</Comp>` | `migrate_slot_usage` |
| `$$slots.default` / `$$props` / `$$restProps` | `children` / `props` / `rest` | `handle_identifier` |
| `<svelte:component this={C} />` | `<C />` (+ hoisted `{@const}` / `$derived` when needed) | `template.SvelteComponent` |
| `<svelte:self />` | `<Name />` + `import Name from './Name.svelte'` | `template.SvelteSelf` |
| `<svelte:options accessors />` | attribute removed + `export { count, … }` | `migrate()` post-pass |
| `<script context="module">` | `<script module>` | `migrate()` |
| `<!-- svelte-ignore a11y-missing-attribute -->` | `<!-- svelte-ignore a11y_missing_attribute -->` | `template.Comment` / `migrate_svelte_ignore` |
| `<div />` | `<div></div>` | `template.RegularElement` |
| `.foo:is(a, b) { }` | `.foo:is(:global(a), :global(b)) { }` | `migrate_css` |

---

## Error Handling & Migration Tasks

The migrator follows a **fail-safe-per-file** policy:

```mermaid
flowchart LR
    subgraph normal["Normal path"]
        V1[Visitor] -->|"applies edits"| OK["str.update / remove / append"]
    end
    subgraph failure["Failure path"]
        V2[Visitor] -->|"cannot migrate safely"| ME["throw new MigrationError(msg)"]
        ME --> C["migrate() catch"]
        C -->|"MigrationError"| OUT["<!-- @migration-task: msg -->\noriginal source"]
        C -->|"other exception"| LOG["console.error"] --> OUT
        OUT --> FIN["finally: has_migration_task →<br/>console.log reminder"]
    end
```

**Cases that deliberately throw `MigrationError`** (instead of silently mis-migrating):

- Using `beforeUpdate`/`afterUpdate` while they are still referenced;
- Unsupported destructuring forms in `export let` (`export let { x: foo } = …`);
- `$$props` mixed with named props having initializers/updates;
- A user variable shadowing a rune name required by the migration (`props`, `state`, `derived`, `bindable`);
- Slot names that are invalid identifiers/reserved, or whose rename would break the component;
- Slots whose snippet name would shadow a parent component prop.

**Best-effort soft failures** inject `@migration-task` comments *inline* and continue (e.g., `<svelte:self>` without a known filename, invalid slot names caught during slot migration).

---

## Dependencies & Integration

### Internal Dependencies

| Dependency | Source module | Used for |
| --- | --- | --- |
| `parse` | [compiler-parser](compiler-parser.md) | Produce the component AST (instance/module/fragment/css/options) |
| `read_options` (indirectly via `parsed.options`) | [compiler-parser](compiler-parser.md) | Honor `<svelte:options>` (e.g. `runes`, `accessors`, `customElement`) |
| `regex_valid_component_name` | [compiler-parser](compiler-parser.md) | Decide if a `<svelte:component>` expression can be a tag name |
| `analyze_component` | [compiler-analyzer](compiler-analyzer.md) | Scopes, binding kinds, `uses_props/uses_rest_props/uses_slots`, `reactive_statements`, legacy-mode classification (`runes` vs `maybe_runes`) |
| `Scope`, `get_rune` | [compiler-analyzer](compiler-analyzer.md) (scope) | Resolve bindings; detect pre-existing runes (`$props`, `$state`, …) |
| `reset`, `UNKNOWN_FILENAME` | [compiler-core](compiler-core.md) (compile state) | Initialize per-migration compiler state; suppress warnings |
| `validate_component_options` | [compiler-core_options_validation](compiler-core_options_validation.md) | Baseline default options before merging parsed options |
| `migrate_svelte_ignore` | [compiler-core_diagnostics](compiler-core_diagnostics.md) | Convert legacy kebab-case ignore codes to current snake_case codes |
| `extract_identifiers`, `extract_all_identifiers_from_expression`, `is_text_attribute` | [compiler-core](compiler-core.md) (ast utils) | Pattern analysis for props and reactive statements |
| Analysis results / error codes | [compiler-core_diagnostics](compiler-core_diagnostics.md), [message_code_generation_templates](message_code_generation_templates.md) | Analysis-phase diagnostics flow through the same message pipeline (muted during migration) |

### External Dependencies

- **`magic-string`** — all source edits (positional `update`/`remove`/`prepend`/`append`/`move`/`indent`/`snip`).
- **`zimmerframe`** — `walk` traversal with the standard compiler visitor protocol (`path`, `state`, `next`, `visit`).

### Consumers & Runtime Coupling

- **Tooling** — `migrate()` is consumed by migration tooling (e.g., the `svelte-migrate` codemod) and editors that offer "migrate component" actions. It is a *pure function* over source text: no filesystem, no compiler instance.
- **`svelte/legacy`** — the emitted `import { run, handlers, createBubbler, preventDefault, … } from 'svelte/legacy'` statements bind migrated components to the runtime's [legacy-compat](legacy-compat.md) implementations (`legacy-client.js` / `legacy-server.js`, `dom/legacy/*` event modifiers). This is the migrator's only runtime footprint.
- **Compiler suite** — because it reuses the same parse/analyze front-end, any AST or binding-kind change in [compiler-parser](compiler-parser.md) or [compiler-analyzer](compiler-analyzer.md) can affect migration output; the migrator must be kept in sync with those modules' contracts.

```mermaid
flowchart LR
    subgraph suite["Compiler pipeline"]
        CP[[compiler-parser]] --> CA[[compiler-analyzer]] --> CT[[compiler-transformer]]
    end
    MIG[[compiler-migrator]]
    CP -.-> MIG
    CA -.-> MIG
    MIG ==>"generates code importing"==> LC[[legacy-compat<br/>client runtime]]
    TOOL[[Migration tooling]] ==> MIG
```

---

## Maintenance Notes

- **Never regenerate, always edit**: new migrations should express changes as MagicString operations keyed off AST node positions, preserving surrounding formatting.
- **Guard rune-name collisions**: any new rune insertion must run through a `check_rune_binding(...)` equivalent before editing.
- **Comment fidelity**: reordering and rewriting passes must carry leading/trailing comments along (see `get_node_range` and the labeled-statement comment transfer logic).
- **Both output modes**: prop typing must support TypeScript (`interface Props`) and JSDoc (`@typedef`) — driven by the `uses_ts` heuristic (`use_ts` option minus `@type {` occurrences, or `<script lang="ts">`).
- **Custom elements are exempt**: `<slot>`-related rewrites are skipped when `analysis.custom_element` is true, since custom elements keep native slot semantics.
