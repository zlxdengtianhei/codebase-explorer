# Component Lifecycle (`client-dom-renderer_lifecycle`)

> **Module file:** `packages/svelte/src/internal/client/render.js`
> **Parent module:** [Client DOM Renderer](client-dom-renderer.md) · **Grandparent:** [Client Runtime Engine (Reactivity & DOM Rendering)](client-reactivity-engine.md)

## 1. Purpose and Scope

This module is the **component lifecycle driver** of the client runtime. It is the narrow, well-defined seam between application code and everything else Svelte does at runtime: it takes a compiled component plus options, brings it to life in the DOM (**`mount`**), adopts pre-rendered server markup instead of re-creating it (**`hydrate`**), and tears the whole component tree down again (**`unmount`**). It also exports two small utilities used pervasively by generated code: **`set_text`** (diffed text-node updates) and **`should_intro`** (the global gate for initial intro transitions).

Everything the module does on the DOM itself is delegated — it *orchestrates* rather than *implements*:

| Export | Kind | Responsibility |
|---|---|---|
| `mount(component, options)` | Public API | Mount a component to a target element; returns component exports |
| `hydrate(component, options)` | Public API | Adopt SSR output inside `target`; falls back to client render on mismatch |
| `unmount(component, options?)` | Public API | Destroy a mounted/hydrated instance; optionally play outro transitions first |
| `set_text(text, value)` | Internal helper | Write a text node's `nodeValue` only when the value actually changed |
| `should_intro` / `set_should_intro(value)` | Internal flag | Global switch controlling whether intro transitions play on block creation |

Out of scope (documented elsewhere — follow the links, this page does not repeat them): how effects and batches are scheduled ([client-reactivity-engine_effects](client-reactivity-engine_effects.md), [client-reactivity-engine_batching-scheduling](client-reactivity-engine_batching-scheduling.md)), how the hydration cursor walks server markup ([client-dom-renderer_dom-foundation](client-dom-renderer_dom-foundation.md)), how delegated events dispatch handlers ([client-dom-renderer_attributes-events](client-dom-renderer_attributes-events.md)), and how intro/outro transitions are animated ([client-dom-renderer_transitions](client-dom-renderer_transitions.md)).

## 2. Position in the System

The [public API module](public-api.md) re-exports `mount`, `hydrate` and `unmount` verbatim from this file — `import { mount } from 'svelte'` lands here. Compiled component functions (produced by [compiler-transformer_client-transform](compiler-transformer_client-transform.md)) are *invoked* by this module (`Component(anchor, props)`), and every helper those render functions call lives in the parent module's other sub-modules.

```mermaid
flowchart TB
    subgraph App["Application code"]
        APP["import { mount, hydrate, unmount } from 'svelte'"]
    end

    subgraph PA["Public API (public-api.md)"]
        IDX["index.js re-exports"]
    end

    subgraph LF["lifecycle — render.js (this module)"]
        M["mount / _mount"]
        H["hydrate"]
        U["unmount"]
        ST["set_text"]
        SI["should_intro"]
        MC[("mounted_components<br/>WeakMap")]
        DL[("document_listeners<br/>ref-count map")]
    end

    subgraph CRE["client-reactivity-engine"]
        EFF["effects: component_root · branch<br/>(client-reactivity-engine_effects)"]
        BAT["Batch.ensure() · teardown scheduling<br/>(client-reactivity-engine_batching-scheduling)"]
        SIG["active_effect signal context<br/>(client-reactivity-engine_signal-graph)"]
    end

    subgraph CDR["client-dom-renderer siblings"]
        DF["DOM foundation: init_operations ·<br/>create_text · clear_text_content ·<br/>hydration cursor · assign_nodes<br/>(client-dom-renderer_dom-foundation)"]
        AE["Events: all_registered_events ·<br/>root_event_handles · handle_event_propagation<br/>(client-dom-renderer_attributes-events)"]
        CF["Blocks: reset_head_anchor ·<br/>set_should_intro consumers<br/>(client-dom-renderer_control-flow-blocks)"]
        TR["Transitions: intros gated by should_intro,<br/>outros via pause_effect<br/>(client-dom-renderer_transitions)"]
    end

    COMP["Compiled component fn<br/>(compiler-transformer_client-transform)"]
    DOM[("Browser DOM")]

    APP --> IDX --> M & H & U
    M --> MC
    H -- "delegates" --> M
    U -- "teardown lookup" --> MC
    M -- "component_root(() => branch(fn))" --> EFF
    EFF --> BAT
    EFF -- "runs fn under" --> SIG
    M -- "renders" --> COMP
    M -- "event wiring" --> AE
    M & H -- "init_operations() · anchor scanning" --> DF
    U -- "outro: pause_effect" --> TR
    M & H --> ST & SI
    SI -. "read by" .-> CF
    M & H --> DOM
    ST --> DOM
```

**Contract with the reactivity engine.** `_mount` does not create effects directly; it hands a closure to `component_root`, which (a) calls `Batch.ensure()` so any writes during initial render are captured, (b) creates a `ROOT_EFFECT | EFFECT_PRESERVED` effect that runs synchronously, and (c) returns a teardown function that either destroys immediately or, with `outro: true`, first calls `pause_effect` (running outro transitions) before `destroy_effect`. See [client-reactivity-engine_effects](client-reactivity-engine_effects.md) for effect flags, pausing semantics and the branch state machine.

## 3. The Mount Path

### 3.1 `mount` → `_mount` walkthrough

`mount(component, options)` is a thin typed wrapper over the internal `_mount`. `_mount` performs five phases, all synchronously:

1. **DOM bootstrap** — `init_operations()` (idempotent; installs fast `firstChild`/`nextSibling` prototype getters and pre-seeds hidden-class expandos — see [client-dom-renderer_dom-foundation](client-dom-renderer_dom-foundation.md)).
2. **Root event wiring** — registers delegated listeners for every event type the app might use (§3.2).
3. **Effect tree creation** — `component_root(() => { … })` returns the teardown; inside it, `branch()` creates a preserved branch effect that runs the component function synchronously, so **exports are defined before `mount` returns**.
4. **Component invocation** — `Component(anchor_node, props)` executes the compiled render function. Before the call, the module: pushes user `context` onto the context stack (`ctx.c`), making `getContext` work for the root instance; attaches `events` as `props.$$events`; and, when hydrating, calls `assign_nodes(anchor_node, null)` so the branch effect records the start of its owned DOM range. After the call, `active_effect.nodes_end = hydrate_node` closes that range during hydration.
5. **Bookkeeping** — the instance/teardown pair is stored in the `mounted_components` `WeakMap` (keyed by the exports object, so it never leaks) and the exports are returned.

```mermaid
sequenceDiagram
    autonumber
    participant App as App code
    participant M as mount / _mount
    participant EV as events.js (attributes-events)
    participant EFF as effects.js (reactivity-engine)
    participant BR as branch effect body
    participant C as Compiled component
    participant DF as DOM foundation
    participant WM as mounted_components

    App->>M: mount(Component, { target, props, events, context, intro=true })
    M->>DF: init_operations()
    M->>EV: addEventListener(event, handle_event_propagation)<br/>on target for all_registered_events
    M->>EV: ref-counted document listener (document_listeners)
    M->>EV: root_event_handles.add(event_handle)
    M->>EFF: component_root(fn)
    EFF->>EFF: Batch.ensure(); create ROOT_EFFECT, run synchronously
    EFF->>BR: branch(() => { ... })
    BR->>BR: push({}) + ctx.c = context (if given)
    BR->>BR: props.$$events = events (if given)
    BR->>BR: hydrating ? assign_nodes(anchor, null)
    BR->>C: should_intro = intro; Component(anchor_node, props)
    C->>DF: from_html/child/sibling/append …<br/>template_effect($ => set_text(...))
    C->>EV: create_event / delegate (expando handlers)
    C-->>BR: exports object
    BR->>BR: hydrating ? active_effect.nodes_end = hydrate_node
    BR->>BR: pop() context
    BR-->>EFF: cleanup closure (listeners, anchor removal)
    EFF-->>M: teardown(options) → Promise
    M->>WM: mounted_components.set(exports, teardown)
    M-->>App: exports

    Note over App,WM: Later: unmount(exports, { outro }) → WM lookup → teardown(options)
```

**Anchor semantics.** If no `anchor` option is supplied, `_mount` appends a fresh text node to `target` and uses it as the insertion anchor (compiled fragments insert content *before* their anchor). Because content is inserted before it, the cleanup closure removes this auto-created node — but only when `anchor_node !== anchor`, i.e. only when the module created it itself.

### 3.2 Root event wiring (delegation + ref counting)

Svelte uses **event delegation**: declarative handlers live as `element.__click`-style expandos, and one real DOM listener per event type dispatches them (algorithm in [client-dom-renderer_attributes-events](client-dom-renderer_attributes-events.md)). The lifecycle module owns the *root* side of that system:

- For each name in `all_registered_events` (populated as the component renders), `addEventListener` is placed on **both** the mount `target` (catches events even if inner content stops propagation) and the `document`.
- The `document` listener is a safety net for events originating from elements that were manually moved *outside* the container (e.g. portals). It is **ref-counted** in the `document_listeners` `Map`, so many mounted apps share one document listener; it is removed only when the count hits zero.
- `event_handle` is also stored in `root_event_handles`. When a *second* mount happens later (e.g. a nested `mount` call), each component's `event()` helper consults `root_event_handles` and re-registers its event names on the existing roots, so late-mounted subtrees stay delegatable.
- Passivity is decided once per event name by `is_passive_event` (a static list of high-frequency events like `touchstart`, `wheel`).

The same `registered_events` set drives symmetric teardown in the cleanup closure: remove target listeners, decrement document listeners, and drop `event_handle` from `root_event_handles`.

## 4. The Hydrate Path

`hydrate` wraps `_mount` with SSR-adoption logic. The invariant: server output is bracketed by `<!--[-->` (`HYDRATION_START`) and `<!--]-->` (`HYDRATION_END`) comment markers, and the *same* compiled render functions must, when the `hydrating` flag is set, walk existing nodes with the cursor from [client-dom-renderer_dom-foundation](client-dom-renderer_dom-foundation.md) instead of creating DOM.

```mermaid
flowchart TD
    A["hydrate(Component, options)"] --> B["options.intro ??= false<br/>(intros off by default when hydrating)"]
    B --> C["scan target's children for a comment node<br/>whose data === HYDRATION_START"]
    C -- "not found" --> X["throw HYDRATION_ERROR sentinel"]
    C -- "found" --> D["set_hydrating(true)<br/>set_hydrate_node(marker); hydrate_next()"]
    D --> E["_mount(Component, { ...options, anchor })"]
    E --> F["render fn walks SSR DOM via cursor<br/>(child / sibling / hydrate_next / block markers)"]
    F --> G{"cursor now at HYDRATION_END comment?"}
    G -- "yes" --> H["set_hydrating(false)<br/>return exports — DOM adopted"]
    G -- "no" --> I["warn hydration_mismatch (dev-tooling)<br/>throw HYDRATION_ERROR"]
    F -- "block-level mismatch mid-walk<br/>(if/each/html/element repair)" --> J["remove_nodes() → client-render that subtree<br/>hydration continues"]
    H --> K
    I --> L{"error is a Svelte error?<br/>(message line starts with<br/>https://svelte.dev/e/)"}
    L -- "yes" --> RT["re-throw — never masked<br/>as a hydration failure"]
    L -- "no" --> M2{"options.recover === false ?"}
    J --> M2
    M2 -- "yes" --> HF["throw hydration_failed<br/>(errors.js, dev-tooling)"]
    M2 -- "no / unset" --> REC["console.warn('Failed to hydrate: ', err)<br/>init_operations(); clear_text_content(target)<br/>return mount(Component, options)"]
    X --> L

    H --> FIN["finally: restore previous<br/>hydrating / hydrate_node<br/>reset_head_anchor()"]
    REC --> FIN
    RT --> FIN
    HF --> FIN
```

Key behaviours:

- **Two-level mismatch handling.** Individual control-flow blocks repair *local* mismatches themselves (via `remove_nodes()` + client rendering from that point — see [client-dom-renderer_control-flow-blocks](client-dom-renderer_control-flow-blocks.md)). `hydrate` only handles *global* failure: cursor not at `HYDRATION_END` after mount, or the start marker being absent entirely.
- **Svelte errors are never swallowed.** Error objects whose message contains a line starting with `https://svelte.dev/e/` are genuine Svelte errors (they carry a doc link) and are re-thrown as-is; only unexpected errors (including the `HYDRATION_ERROR` sentinel itself) enter the recovery path.
- **Recovery = full client render.** `clear_text_content(target)` wipes the (mismatched) SSR output, then a plain `mount` runs from scratch. `options.recover: false` turns this into a hard `hydration_failed` error instead.
- **Nested-safety.** The `finally` block restores the *previous* `hydrating`/`hydrate_node` values and calls `reset_head_anchor()` (from the `<svelte:head>` block), so `hydrate` calls nest correctly (e.g. an island hydration inside a larger hydration).
- **`try/catch` asymmetry note.** If the marker scan itself throws (it runs before `init_operations()`), recovery re-runs `init_operations()` before clearing the target — operations may not be initialised yet at that point.

## 5. The Unmount Path

`unmount(component, options)` is the public counterpart of `mount`. The `mounted_components` `WeakMap` maps the exports object returned by `mount`/`hydrate` to its `component_root` teardown.

```mermaid
flowchart TD
    A["unmount(component, { outro })"] --> B{"mounted_components.get(component)"}
    B -- "not found (double unmount)" --> DEV{"DEV?"}
    DEV -- "yes" --> W["warn lifecycle_double_unmount"]
    DEV -- "no" --> P2["return Promise.resolve()"]
    W --> P2
    B -- "found" --> C["delete WeakMap entry"]
    C --> D{"options.outro === true ?"}
    D -- "yes" --> E["pause_effect(root):<br/>outro transitions play<br/>(client-dom-renderer_transitions)"]
    E --> F["destroy_effect() after all outros complete"]
    D -- "no" --> G["destroy_effect() immediately"]
    F --> H["cleanup closure runs:<br/>remove target/document listeners<br/>remove auto-created anchor<br/>delete from root_event_handles"]
    G --> H
    H --> I["Promise&lt;void&gt; resolves"]
```

Details worth knowing:

- **Since 5.13.0** `unmount` returns a `Promise<void>` that resolves *after* the last outro transition finishes when `outro: true` (previously it returned `void`). Without `outro`, the promise resolves immediately after synchronous teardown.
- **Outros, not intros.** Outro playback is implemented by the reactivity engine's `pause_effect` (the engine waits for `run_out_transitions` before removing `nodes_start…nodes_end`); the transitions themselves are managed by the `TransitionManager` — see [client-dom-renderer_transitions](client-dom-renderer_transitions.md) and the branch state machine in [client-dom-renderer_effects](client-reactivity-engine_effects.md).
- **WeakMap by design.** Keying on the exports object means holding a reference to a mounted app never prevents garbage collection of anything except through that app itself.

## 6. Component Lifecycle State Machine

From the application's point of view, every component instance managed by this module moves through the following states:

```mermaid
stateDiagram-v2
    [*] --> Mounting: mount(Component, opts)
    [*] --> HydratingInstance: hydrate(Component, opts)

    Mounting --> Mounted: render fn ran synchronously,<br/>exports returned
    HydratingInstance --> Mounted: markers matched (intro = false by default)
    HydratingInstance --> Mounting: mismatch + recover !== false<br/>(clear target, client render)
    HydratingInstance --> Failed: recover === false → hydration_failed

    Mounted --> Unmounting: unmount(exports, { outro })
    Unmounting --> Destroyed: immediate destroy (no outro)
    Unmounting --> OutroPlaying: outro: true → pause_effect
    OutroPlaying --> Destroyed: all transitions finished

    Destroyed --> [*]: listeners removed,<br/>WeakMap entry deleted

    Failed --> [*]
```

Invariants maintained by the module: `mount` never returns before the tree is in the DOM (synchronous root effect); `hydrate` restores global hydration state on every exit path; a destroyed instance is untraceable (WeakMap entry removed, listeners removed, `should_intro` restored to `true`).

## 7. `set_text` — Diffed Text Updates

`set_text(text, value)` is the helper behind every plain `{expression}` interpolation in text position. It is deliberately tiny and allocation-free because it sits on the hot path of every reactive text update:

1. **Coerce once, diff cheaply.** `value` is coerced to a string *before* comparison (`value + ''` for objects; `''` for `null`/`undefined`). Coercing objects also matters for reactivity: the string conversion touches the proxied object's properties, so a `$state` array/object reference read inside a template effect gets tracked correctly (see [client-reactivity-engine_sources-and-proxies](client-reactivity-engine_sources-and-proxies.md)).
2. **Cache the last value on the node.** The previous string is stashed in the `__t` expando (pre-seeded with the initial `nodeValue` via `??=`). The DOM write `text.nodeValue = str` happens **only if** the new string differs from `__t`, avoiding layout-invalidating writes for unchanged values (a common case in `{#each}` loops where only one item changed).

```mermaid
flowchart LR
    V["value (string / object / null)"] --> CO["coerce: '' for null ·<br/>String(value) for objects"]
    CO --> CMP{"str !== (text.__t ??=<br/>text.nodeValue) ?"}
    CMP -- "unchanged" --> SKIP["no DOM write"]
    CMP -- "changed" --> WR["text.__t = str<br/>text.nodeValue = str"]
```

## 8. `should_intro` — The Intro Gate

`should_intro` is a module-level boolean that gates whether *intro* transitions run when a block effect creates fresh DOM (consumed by the control-flow blocks and transition manager — see [client-dom-renderer_transitions](client-dom-renderer_transitions.md)).

| Context | Value | Why |
|---|---|---|
| Normal mounting | `true` | New content should animate in |
| Hydration (default) | `false` (`options.intro ?? false` in `hydrate`) | Content already exists on the page; animating server-rendered markup would be jarring |
| `hydrate(..., { intro: true })` | `true` | Opt-in replays intros during hydration |
| Inside a `<svelte:element>` whose tag just changed | `false` (via `set_should_intro`) | The element's children are recreated mechanically during the tag swap; animating them would be noise. See [client-dom-renderer_control-flow-blocks](client-dom-renderer_control-flow-blocks.md) |

The lifecycle module sets it around the `Component(anchor_node, props)` call in `_mount` (`should_intro = intro; Component(...); should_intro = true`) so the flag reflects only the *initial* render of the root tree; per-block updates afterwards consult it dynamically.

## 9. Error Handling & DEV Behaviour Summary

| Situation | Mechanism | Source |
|---|---|---|
| No `HYDRATION_START` marker in target | `throw HYDRATION_ERROR` (sentinel, not an `Error`) | this module |
| Cursor not at `HYDRATION_END` after mount | `w.hydration_mismatch()` warning + `HYDRATION_ERROR` | this module + [client-dev-tooling](client-dev-tooling.md) warnings |
| Recovery disabled (`recover: false`) on mismatch | `e.hydration_failed()` thrown | this module + [client-dev-tooling](client-dev-tooling.md) errors |
| Unexpected error during hydration | `console.warn('Failed to hydrate: ', err)` then full client re-render | this module |
| Genuine Svelte error during hydration (message contains `https://svelte.dev/e/…` line) | re-thrown untouched | this module |
| `unmount` called twice on same instance | `w.lifecycle_double_unmount()` warning (DEV only); still resolves a promise | this module + dev-tooling |

## 10. Related Modules

- **[client-dom-renderer](client-dom-renderer.md)** — parent module: overall renderer architecture, design concepts (anchor patching, effect-owned DOM ranges, delegation, batched commits).
- **[client-reactivity-engine_effects](client-reactivity-engine_effects.md)** — `component_root`/`branch`/`pause_effect`/`destroy_effect`: what the teardown promise actually does.
- **[client-reactivity-engine_batching-scheduling](client-reactivity-engine_batching-scheduling.md)** — `Batch.ensure()` called by `component_root`; how initial writes are flushed.
- **[client-dom-renderer_dom-foundation](client-dom-renderer_dom-foundation.md)** — `init_operations`, template cloning, the hydration cursor (`hydrating`, `hydrate_node`, `hydrate_next`) used by `hydrate`.
- **[client-dom-renderer_attributes-events](client-dom-renderer_attributes-events.md)** — `handle_event_propagation`, `all_registered_events`, `root_event_handles`: the dispatch half of the delegation system whose registration lives here.
- **[client-dom-renderer_control-flow-blocks](client-dom-renderer_control-flow-blocks.md)** — `reset_head_anchor`, per-block mismatch repair, `should_intro` consumers.
- **[client-dom-renderer_transitions](client-dom-renderer_transitions.md)** — intro gating and the outro playback that `unmount({ outro: true })` waits on.
- **[client-dev-tooling](client-dev-tooling.md)** — `hydration_mismatch`, `lifecycle_double_unmount`, `hydration_failed` and other diagnostics.
- **[public-api](public-api.md)** — where `mount`/`hydrate`/`unmount` are surfaced as `svelte` package exports.
