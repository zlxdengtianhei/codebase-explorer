# Props & Stores — `client-reactivity-engine_props-and-stores`

> **Source files**
> - `packages/svelte/src/internal/client/reactivity/props.js`
> - `packages/svelte/src/internal/client/reactivity/store.js`
>
> **Parent module:** [client-reactivity-engine](client-reactivity-engine.md)
> **Sibling modules:** [client-reactivity-engine_signal-graph](client-reactivity-engine_signal-graph.md) · [client-reactivity-engine_sources-and-proxies](client-reactivity-engine_sources-and-proxies.md) · [client-reactivity-engine_deriveds-and-async](client-reactivity-engine_deriveds-and-async.md) · [client-reactivity-engine_effects](client-reactivity-engine_effects.md) · [client-reactivity-engine_batching-scheduling](client-reactivity-engine_batching-scheduling.md) · [client-reactivity-engine_foundation](client-reactivity-engine_foundation.md)

---

## 1. Introduction

This module is the **adapter layer between compiler-emitted component code and the client signal graph**. Every Svelte component, once compiled for the browser, receives its inputs as a single `$$props` object and optionally interacts with legacy Svelte *stores* (`$store` auto-subscription syntax). This module implements both bridges:

1. **`props.js` — the props pipeline.** Exposes `$$props` to component internals as fine-grained reactive state:
   - `prop()` synchronizes a possibly-bound prop with inner component state (the heart of `bind:` two-way binding).
   - `rest_props()` / `legacy_rest_props()` create reactive proxy views over `$$props` that exclude named keys (`const { x, ...rest } = $props()`, `$$restProps`, `$$props`).
   - `spread_props()` merges layered prop sources (`<Comp {...a} {...b} />`) into one reactive object.
   - `update_prop()` / `update_pre_prop()` implement `x++` / `++x` semantics on props.

2. **`store.js` — the store bridge.** Implements automatic subscribe/unsubscribe lifecycle for `$store` usage: reads become reactive signals, writes are forwarded to the store, cleanup happens on component destroy, and store *bindings* (`<Child bind:x={$y} />`) are detected so props stay mutable across mode boundaries.

Both files are internal (not public API) and are consumed almost exclusively by **code emitted by the Svelte compiler** — see [Compiler_Pipeline___Language_Toolchain](Compiler_Pipeline___Language_Toolchain.md), specifically the client transform (documented in `compiler-transformer_client-transform`).

---

## 2. Architecture

### 2.1 Position within the reactivity engine

The module sits *on top of* the engine primitives (sources, deriveds, runtime) and *below* everything the compiler emits for prop/store syntax. It deliberately contains no scheduling logic — invalidation is delegated to the batch/scheduler subsystem.

```mermaid
flowchart LR
    subgraph CTX["Compiler-generated client code"]
        VIS["Component · BindDirective · AssignmentExpression ·
            EachBlock · RenderTag visitors"]
    end

    subgraph MOD["props-and-stores — this module"]
        P["props.js"]
        S["store.js"]
    end

    subgraph ENG["Reactivity engine primitives"]
        SRC["sources.js — source · set · update · mutable_source"]
        DRV["deriveds.js — derived · derived_safe_equal"]
        RT["runtime.js — get · untrack · active_effect · set_active_effect"]
        PRX["proxy.js — proxy"]
        EFF["effects.js — teardown"]
    end

    subgraph INF["Shared infrastructure"]
        CONST["constants.js — PROPS_IS_* flags"]
        STU["store/utils + store/shared — subscribe_to_store · get"]
        UTIL["shared/utils — get_descriptor · is_function · define_property"]
        FLAGS["flags — legacy_mode_flag · DEV"]
        ERR["internal errors"]
    end

    DR["client-dom-renderer — bind_prop · attribute_effect"]
    LG["legacy-compat"]
    SSR["server-runtime — SSR counterparts of rest_props / spread_props / store_mutate"]

    VIS --> P
    VIS --> S
    P --> SRC
    P --> DRV
    P --> RT
    P --> PRX
    P --> CONST
    P --> FLAGS
    P --> ERR
    P --> S
    S --> SRC
    S --> RT
    S --> EFF
    S --> STU
    S --> UTIL
    DR --> P
    LG --> S
    SSR -. "mirror implementations" .-> MOD
```

Key relationships:

| Dependency | Used for |
| --- | --- |
| `sources.js` (`source`, `mutable_source`, `set`, `update`) | Creating the reactive cells behind props, `$$props` version counters and store values |
| `deriveds.js` (`derived`, `derived_safe_equal`) | Local, overridable views of writable props |
| `runtime.js` (`get`, `untrack`, `active_effect`, `set_active_effect`, `is_destroying_effect`) | Dependency registration, ownership of created signals, teardown awareness |
| `proxy.js` (`proxy`) | Wrapping bindable object props so deep mutations propagate to the parent |
| `effects.js` (`teardown`) | Registering store-unsubscription cleanup on component destroy |
| Public store utils (`subscribe_to_store`, `get`) | Talking to arbitrary Svelte-compatible stores — see [stores](stores.md) in the Public API |
| `constants.js` (`PROPS_IS_*`) | The compiler → runtime flags contract for `prop()` |

---

## 3. Component inventory

### `props.js`

| Component | Kind | Purpose |
| --- | --- | --- |
| `prop(props, key, flags, fallback)` | factory | Returns a read/write accessor for one prop; syncs bound props with parent state |
| `rest_props(props, exclude, name)` | factory | Proxy view of `$$props` minus named keys (runes `...rest` destructuring) |
| `legacy_rest_props(props, exclude)` | factory | Proxy for legacy `$$restProps` / `$$props` with coarse-grained invalidation |
| `spread_props(...props)` | factory | Proxy merging ordered prop sources, incl. lazily evaluated ones |
| `update_prop(fn, d)` | helper | Post-increment/decrement on a prop (`x++` → old value) |
| `update_pre_prop(fn, d)` | helper | Pre-increment/decrement on a prop (`++x` → new value) |
| `rest_props_handler`, `legacy_rest_props_handler`, `spread_props_handler` | internal | `ProxyHandler` objects implementing the semantics above |

### `store.js`

| Component | Kind | Purpose |
| --- | --- | --- |
| `setup_stores()` | factory | Creates the per-instance `StoreReferencesContainer` + destroy cleanup; returns `[stores, cleanup]` |
| `store_get(store, name, stores)` | read | Lazily subscribes to a store and exposes its value as a reactive `mutable_source` |
| `store_unsub(store, name, stores)` | lifecycle | Detaches a subscription when the store instance changed |
| `store_set(store, value)` | write | `store.set(value)`; returns the value |
| `store_mutate(store, expr, new_value)` | write | Sets the store, returns the original expression (for `$store += …`) |
| `update_store(store, v, d)` | write | `$store++` / `$store--` — returns *old* value |
| `update_pre_store(store, v, d)` | write | `++$store` / `--$store` — returns *new* value |
| `invalidate_store(stores, name)` | write | Pushes the current reactive source value back into the store |
| `mark_store_binding()` | protocol | Flag setter used inside compiled prop getters |
| `capture_store_binding(fn)` | protocol | Probe: runs `fn` and reports whether it read a store-bound prop |

---

## 4. The props pipeline (`props.js`)

### 4.1 `prop()` — the prop synchronization core

`prop()` is emitted by the compiler whenever a component **reads a prop it also writes, or that has a default value**. It is the single place that decides *how* a prop behaves reactively.

**Compiler flags contract** (`constants.js`):

| Flag | Meaning |
| --- | --- |
| `PROPS_IS_RUNES` | The component uses runes — prop behaves in runes mode even when the app is in legacy mode |
| `PROPS_IS_BINDABLE` | The prop participates in two-way binding (`bind:` or `$bindable`) |
| `PROPS_IS_LAZY_INITIAL` | The fallback is a function; evaluate it lazily and untracked, only when first needed |
| `PROPS_IS_IMMUTABLE` | Use strict-equality `derived` (immutable inputs) instead of safe-equality |
| `PROPS_IS_UPDATED` | The component writes to the prop — a getter-only accessor is not enough |

**Execution modes.** Depending on flags and the shape of `props`, `prop()` returns one of three accessor implementations:

```mermaid
flowchart TD
    A["prop(props, key, flags, fallback)"] --> B{"runes mode AND
        not PROPS_IS_UPDATED ?"}
    B -- "yes: never written" --> C["Return plain getter.
        Reads $$props[key]; falls back when undefined"]
    B -- "no" --> D{"bindable AND setter found
        (parent used bind: or entry props)"}
    D -- "yes" --> E["Return delegating accessor:
        writes call parent setter; reads use getter"]
    D -- "no" --> F["Create local derived:
        derived (immutable) or derived_safe_equal"]
    F --> G["Return shadowing accessor:
        writes set(derived, value) locally;
        reads get(derived) unless destroyed"]
```

**Mode 1 — read-only getter** *(runes, no `PROPS_IS_UPDATED`)*
The cheapest path. The accessor reads `props[key]`, returning the lazy fallback while the prop is `undefined`. In runes mode the fallback is *re-armed* whenever the prop has a value (`fallback_dirty = true`), so the prop reverting to `undefined` falls back again. Legacy mode differs intentionally: once the prop has had a value, the fallback is permanently discarded.

**Mode 2 — delegating accessor** *(bindable prop with a setter)*
When the parent wrote `bind:x={...}`, the incoming prop object exposes a setter (or is entry props created via `mount()` / `createClassComponent()`, detected via the `STATE_SYMBOL` / `LEGACY_PROPS` markers). Writes are forwarded straight to the parent:

```js
if (!runes || !mutation || legacy_parent || is_store_sub) {
    setter(mutation ? getter() : value);
}
```

The guard encodes an important rule: **mutations of objects/arrays must not be pushed back to the parent in runes mode** — the parent's state proxy already propagates those. Pushing is required in legacy mode, for legacy parents, and for store bindings, where the parent cannot detect the mutation itself.

**Mode 3 — shadowing derived** *(writable but unbound, or any legacy-mode prop)*
A local `derived` wraps the getter. Writes call `set(d, value)`, making the local view take precedence ("overridden") over the parent value. Notable details:

- `PROPS_IS_IMMUTABLE` selects the strict default-equality `derived`; otherwise `derived_safe_equal` avoids invalidating when a primitive is reassigned to an equal value (Svelte 4 behaviour preserved in legacy mode).
- In DEV the derived is labelled with the prop key for tracing/inspection.
- Bindable props eagerly `get(d)` once to capture the initial value.
- Object values written from runes-mode bindable props are wrapped with `proxy()` so deep mutations remain reactive.
- **Teardown edge case:** while an effect is being destroyed (`is_destroying_effect && overridden`) or the owning effect is already `DESTROYED`, the accessor returns the raw `d.v` without going through `get()` — this exists because `bind:this` callbacks can legally read props after destruction.

**Fallback initialisation.** If the prop is initially `undefined` and a fallback exists, the fallback becomes the initial value. With a setter present, it is pushed to the parent — unless runes mode, where this raises the `props_invalid_value` error. Lazy fallbacks (`PROPS_IS_LAZY_INITIAL`) are evaluated once via `untrack()` so the initialiser does not create dependencies.

**Store-binding interplay.** For bindable props the initial read is wrapped in `capture_store_binding()` from `store.js` (see [§5.5](#55-store-binding-detection-protocol)) so that `bind:x={$y}` props are treated as mutable even in runes mode.

### 4.2 Data flow: bound-prop write-back

```mermaid
sequenceDiagram
    autonumber
    participant U as User event
    participant CC as Child component code
    participant AC as prop() accessor
    participant PS as Parent state
    participant BS as Batch / scheduler
    participant PE as Parent effects

    U->>CC: assignment x = v
    CC->>AC: accessor(v)
    alt bound prop (setter available)
        AC->>PS: setter(v) — writes $$props[key]
    else unbound writable prop
        AC->>AC: set(local derived, proxy(value))
    end
    AC-->>CC: returns v
    PS->>BS: marks dependents dirty
    BS->>PE: flush queued effects
    PE->>CC: child re-reads prop via getter
```

Invalidation and effect flushing are handled by [client-reactivity-engine_batching-scheduling](client-reactivity-engine_batching-scheduling.md); this module only creates and writes the signals.

### 4.3 `rest_props()` and `legacy_rest_props()`

Both are `Proxy` views over the full `$$props` object with an `exclude` list.

| Trap | `rest_props` (runes `...rest`) | `legacy_rest_props` (`$$restProps` / `$$props`) |
| --- | --- | --- |
| `get` | `undefined` for excluded keys, else `props[key]` | Reads the `version` source first (registers a dependency), then `special[key]()` override or `props[key]` |
| `set` | **Dev-only error** `props_rest_readonly`; always rejected | Lazily creates a `prop()` override under the stored `parent_effect` (with `PROPS_IS_UPDATED`), writes to it, then bumps `version` |
| `deleteProperty` | — | Pushes the key onto `exclude` and bumps `version` (Svelte 4 allowed deleting from `$$restProps`) |
| `getOwnPropertyDescriptor` / `has` / `ownKeys` | Filtered by `exclude` | Filtered by `exclude` |

The **legacy variant is deliberately coarse-grained**: every write or delete increments a single `version: source(0)`, and every read depends on it — so `$$props.y` readers re-run when `$$props.x` changes. This replicates Svelte 4's whole-object `$$props` semantics on top of the fine-grained engine.

```mermaid
flowchart LR
    W["$$props.x = v"] --> T["proxy set trap"]
    T --> SP["special[x] lazily created
        via prop() under parent_effect"]
    SP --> W2["special[x](v)"]
    W2 --> U["update(version source)"]
    U --> RR["all $$props.* readers re-run
        — coarse-grained invalidation"]
```

`rest_props` is annotated `/*#__NO_SIDE_EFFECTS__*/` so bundlers can tree-shake it (see `treeshakeability_checker` in the Engineering Tooling tree).

### 4.4 `spread_props(...props)`

Implements `<Comp {...a} {b} />` by wrapping the ordered argument list (objects *or* getter functions returning objects — the functions are invoked on every trap call, keeping lazy spreads reactive):

- **`get`** — scans layers **last → first**, first layer containing the key wins (later spreads override earlier ones, matching JS object-spread semantics).
- **`set`** — walks last → first and uses the first layer with a *setter descriptor*; if none exists the write fails (props are effectively read-only).
- **`getOwnPropertyDescriptor`** — returns the layer's descriptor, forcing `configurable: true` to avoid the proxy-invariant *"non-configurability report"* `TypeError` (the array target does not actually own the property).
- **`has`** — returns `false` for `STATE_SYMBOL` and `LEGACY_PROPS` so that `prop()`'s `is_entry_props` detection cannot produce a false positive on spread collections.
- **`ownKeys`** — deduplicated union of keys and symbols across all layers.

### 4.5 `update_prop()` / `update_pre_prop()`

Tiny helpers the compiler emits for `x++`, `x--`, `++x`, `--x` on props. `fn` is a closure that reads the prop when called without arguments and writes it when called with one:

| Helper | Semantics | Returns |
| --- | --- | --- |
| `update_prop(fn, d = 1)` | `const old = fn(); fn(old + d)` | **old** value (post-increment) |
| `update_pre_prop(fn, d = 1)` | `const next = fn() + d; fn(next)` | **new** value (pre-increment) |

---

## 5. The store bridge (`store.js`)

Legacy Svelte stores are *not* signals. This module grafts them onto the signal graph: every `$store` read in a component becomes a read of a `mutable_source` that is kept in sync by a real store subscription.

### 5.1 `setup_stores()` — per-instance lifecycle

```mermaid
flowchart TD
    A["Component init"] --> B["stores = {} container"]
    B --> C["teardown(cleanup) — a RENDER_EFFECT
        owned by the component"]
    A --> D["Component destroyed"]
    D --> E["cleanup: unsubscribe every entry,
        mark container with IS_UNMOUNTED symbol"]
    E --> F["Subsequent store_get calls fall back
        to non-reactive get_store — no leaks,
        values stay consistent"]
```

- Returns `[stores, cleanup]`; the compiler stores the container as `$$store_subs` and invokes cleanup via the engine's teardown mechanism (see [client-reactivity-engine_effects](client-reactivity-engine_effects.md)).
- The non-enumerable `IS_UNMOUNTED` symbol distinguishes *"container no longer attached to a live component"* from *"simply no subscription yet"*.

### 5.2 `store_get()` — reactive store reads

```mermaid
sequenceDiagram
    autonumber
    participant C as Component (compiled)
    participant SG as store_get
    participant EC as $$store_subs entry
    participant ST as Svelte store
    participant SR as mutable_source

    C->>SG: store_get(store, 'name', $$store_subs)
    SG->>EC: entries.name ??= { store: null, source, unsubscribe: noop }
    alt store instance changed (and not unmounted)
        SG->>EC: entry.unsubscribe()
        SG->>ST: subscribe_to_store(store, callback)
        ST-->>SG: callback(v) — first call is synchronous
        Note over SR: sync write entry.source.v = v<br/>(avoids state_unsafe_mutation inside deriveds)
        ST-->>SG: callback(v) — subsequent emissions
        SG->>SR: set(entry.source, v) — normal invalidation
    end
    SG-->>C: get(entry.source) → reactive value
```

Design details worth knowing:

- **One entry per store *name*, not per store instance.** Reassignments (`store = otherStore`) reuse the same `mutable_source`; only the subscription is swapped. This is what `store_unsub` assists with: it closes a stale subscription without resetting the entry, so a following `store_get` can resubscribe.
- **Synchronous first callback** writes `entry.source.v` directly instead of `set()`, because the first emission can happen while a `derived` is still initialising — a regular `set` there would trigger `state_unsafe_mutation`.
- **After unmount**, reads bypass the (now stale) source and use the public `get()` — slightly slower, but correct and leak-free.
- In DEV the created source is labelled with the store name for tracing.

### 5.3 Write-side helpers

All writes terminate in the store's own `set()`; none of them touch the local source — the store's subscription loop will feed the new value back through `store_get`'s callback.

| Compiled syntax | Emitted call | Return value |
| --- | --- | --- |
| `$store = v` | `store_set(store, v)` | `v` |
| `$store += expr` (any mutation expression) | `store_mutate(store, expr, new_value)` | the original `expr` |
| `$store++` / `$store--` | `update_store(store, v, ±1)` | old value |
| `++$store` / `--$store` | `update_pre_store(store, v, ±1)` | new value |
| legacy `$$invalidate` of a reassigned store | `invalidate_store($$store_subs, name)` | — |

`invalidate_store` is the mirror of reading: it takes the value currently held in the reactive source (`entry.source.v`) and pushes it back into the store, covering legacy assignment-invalidation flows.

### 5.4 Store-binding detection protocol

`<Child bind:x={$y} />` must behave as a *mutable* prop even in runes mode, and must skip the `binding_property_non_reactive` validation. The two modules cooperate via a module-level flag:

```mermaid
sequenceDiagram
    autonumber
    participant CH as Child bind:x = $y
    participant P as prop()
    participant CSB as capture_store_binding
    participant PG as compiled getter (props.x)
    participant MSB as mark_store_binding

    CH->>P: prop($$props, 'x', PROPS_IS_BINDABLE)
    P->>CSB: capture_store_binding(() => props[x])
    CSB->>PG: evaluate getter
    PG->>MSB: mark_store_binding()
    Note over MSB: sets module flag
    CSB-->>P: [initial_value, is_store_sub]
    Note over P: prop treated as store-bound:<br/>mutable in runes mode, mutation<br/>writes forwarded, validation skipped
```

`capture_store_binding` saves/restores the previous flag so nested evaluations cannot corrupt state. The resulting `is_store_sub` boolean is later used inside `prop()`'s delegating accessor to decide whether mutation writes must be forwarded to the parent (see [§4.1](#41-prop--the-prop-synchronization-core)).

---

## 6. Compiler ↔ runtime contract

Summary of which compiled syntax maps to which helper of this module (compiler side documented in [Compiler_Pipeline___Language_Toolchain](Compiler_Pipeline___Language_Toolchain.md)):

| Source syntax | Runtime call(s) |
| --- | --- |
| `let { x } = $props()` (read-only) | accessor from `prop()` (getter-only path) |
| `let { x = $bindable() } = $props()` / writes to `x` | `prop()` — delegating or derived-shadowing path |
| `const { a, b, ...rest } = $props()` | `rest_props($$props, ['a', 'b'])` |
| `$$props` / `$$restProps` (legacy) | `legacy_rest_props(...)` |
| `<Comp {...a} {...b} />` | `spread_props(a, b)` |
| `x++` on a prop | `update_prop` / `update_pre_prop` |
| `$store` (read) | `store_get(store, '$name', $$store_subs)` |
| `$store = v` / `$store += e` / `$store++` | `store_set` / `store_mutate` / `update_store` / `update_pre_store` |
| Component init / destroy | `setup_stores()` / teardown cleanup |
| `bind:x={$y}` | `mark_store_binding()` in getter + `capture_store_binding()` inside `prop()` |

Related DOM-side consumers (bindings that *use* these accessors) are documented in [client-dom-renderer](client-dom-renderer.md) (`bind_prop`, `bind_value`, `bind_group`, `attribute_effect`, …), and the legacy escape hatches in [legacy-compat](legacy-compat.md).

---

## 7. Cross-target note: SSR counterparts

The server runtime mirrors part of this surface with **non-reactive** implementations (`rest_props`, `spread_props`, `store_mutate`, `update_store`, `update_store_pre`, `unsubscribe_stores` in `packages/svelte/src/internal/server/index.js`), since server rendering is a single synchronous pass. These live in the [server-runtime](server-runtime.md) module; do not confuse them with the reactive implementations documented here.

---

## 8. Error handling & DEV behaviour

| Situation | Behaviour |
| --- | --- |
| Writing to a runes-mode rest prop (`rest.x = …`) | `props_rest_readonly` error (DEV only) |
| Bindable prop defaulting to fallback via parent setter in runes mode | `props_invalid_value` error |
| First store emission during derived initialisation | Silent direct write `entry.source.v = v` to avoid `state_unsafe_mutation` |
| Reading a store after its component unmounted | Non-reactive `get(store)` fallback; no resubscription, no leak |
| Spread property described as non-configurable | Descriptor coerced to `configurable: true` to satisfy proxy invariants |
| DEV tracing | Deriveds labelled (`d.label = key`, store sources labelled with store name); state proxies tagged via `tag_proxy` |

---

## 9. Performance & design notes

- **Getter-only fast path** — props that are never written skip derived creation entirely (`PROPS_IS_UPDATED` flag), keeping read-only components cheap.
- **Lazy fallbacks** — `PROPS_IS_LAZY_INITIAL` defaults evaluate once, untracked, on first need.
- **`derived_safe_equal`** — primitives assigned equal values do not invalidate downstream effects (legacy-mode parity).
- **Coarse vs fine invalidation** — modern destructured props are per-key signals; legacy `$$props` intentionally uses one `version` source for whole-object semantics.
- **Entry-per-name store cache** — reassigning a store swaps only the subscription, not the reactive cell.
- **Tree-shaking** — `rest_props` is marked `/*#__NO_SIDE_EFFECTS__*/` so unused paths can be dropped (verified by `check-treeshakeability`).
- **No scheduling here** — all dirty-flagging funnels into the engine's batch system; see [client-reactivity-engine_batching-scheduling](client-reactivity-engine_batching-scheduling.md).

---

## 10. Related documentation

- [client-reactivity-engine](client-reactivity-engine.md) — parent engine overview
- [client-reactivity-engine_signal-graph](client-reactivity-engine_signal-graph.md) — signal lifecycle, `tick`, `settled`
- [client-reactivity-engine_sources-and-proxies](client-reactivity-engine_sources-and-proxies.md) — `source`/`set`/`update` and deep proxies
- [client-reactivity-engine_deriveds-and-async](client-reactivity-engine_deriveds-and-async.md) — `derived` execution model
- [client-reactivity-engine_effects](client-reactivity-engine_effects.md) — effect trees and `teardown`
- [client-reactivity-engine_foundation](client-reactivity-engine_foundation.md) — flags and equality semantics
- [client-dom-renderer](client-dom-renderer.md) — element bindings consuming prop accessors
- [legacy-compat](legacy-compat.md) — `$$props`-era component compatibility
- [Compiler_Pipeline___Language_Toolchain](Compiler_Pipeline___Language_Toolchain.md) — the visitors that emit calls into this module
- [server-runtime](server-runtime.md) — SSR counterparts
- [stores](stores.md) — the public store contract (`subscribe_to_store`, `get`) this bridge adapts
