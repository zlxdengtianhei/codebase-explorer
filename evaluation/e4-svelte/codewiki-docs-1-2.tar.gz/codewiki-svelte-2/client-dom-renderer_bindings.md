# client-dom-renderer_bindings

## Introduction

`client-dom-renderer_bindings` is the **runtime two-way data binding layer** of Svelte's client-side renderer. It lives under `packages/svelte/src/internal/client/dom/elements/bindings/` and provides one specialized `bind_*` function per Svelte `bind:` directive flavor (e.g. `bind:value`, `bind:group`, `bind:currentTime`, `bind:this`, `bind:window.innerWidth`).

These functions are **not called by application code directly**. The Svelte compiler ([compiler-transformer_client-transform](compiler-transformer_client-transform.md)), specifically the `BindDirective` visitor, translates each `bind:property` directive in a template into a generated call such as `$.bind_value(element, get_thunk, set_fn)`. At runtime, each binding function wires up:

- a **DOM → state** path: event listeners (and/or media events, resize observers, rAF loops) that push DOM values back into reactive state via the `set` callback;
- a **state → DOM** path: a `render_effect` or `effect` that reads state through the `get` thunk and writes it to the element whenever the state changes;
- **lifecycle cleanup**: `teardown` registrations so listeners, observers and group memberships are removed when the effect tree is destroyed.

The module depends heavily on the signal graph and effect scheduler provided by [client-reactivity-engine](client-reactivity-engine.md), and on hydration state tracked by [client-dom-renderer_dom-foundation](client-dom-renderer_dom-foundation.md).

## Module position in the system

```mermaid
flowchart TB
    subgraph Compiler["Compiler Pipeline — compiler-transformer_client-transform"]
        BD["BindDirective visitor<br/>(bind:name → $.bind_xxx(...))"]
    end

    subgraph G["Generated component code (per <bind:> directive)"]
        CALL["$.bind_value(node, get, set)<br/>$.bind_group(...) / $.bind_this(...) / ..."]
    end

    subgraph M["client-dom-renderer_bindings (this module)"]
        direction TB
        SH["shared.js<br/>listen / listen_to_event_and_reset_event /<br/>without_reactive_context"]
        subgraph FAMILIES["Binding families"]
            IN["input.js"]
            SEL["select.js"]
            MED["media.js"]
            SZ["size.js"]
            UNI["universal.js"]
            TH["this.js"]
            WIN["window.js"]
            DOC["document.js"]
            NAV["navigator.js"]
            PR["props.js"]
        end
    end

    subgraph RE["client-reactivity-engine"]
        EFF["effects.js<br/>render_effect / effect / teardown"]
        RUN["runtime.js<br/>tick / untrack"]
        BAT["batch.js<br/>current_batch / previous_batch"]
        PRX["proxy.js<br/>is()"]
    end

    subgraph HF["client-dom-renderer_dom-foundation"]
        HYD["hydration.js<br/>hydrating flag"]
        OPS["operations.js / template.js<br/>DOM primitives"]
    end

    subgraph DEV["client-dev-tooling"]
        ERR["errors.js<br/>bind_invalid_checkbox_value ..."]
        WARN["warnings.js"]
        VAL["validate.js<br/>validate_binding"]
    end

    BD --> CALL
    CALL --> FAMILIES
    FAMILIES --> SH
    SH --> EFF
    FAMILIES --> EFF
    FAMILIES --> RUN
    FAMILIES --> BAT
    FAMILIES --> PRX
    FAMILIES --> HYD
    FAMILIES --> ERR
    FAMILIES --> WARN
    BD -. dev-mode validation .-> VAL
    M --> OPS
```

All binding functions are invoked **after attribute updates** during component initialization (`after_update` in generated code), ensuring DOM attributes are settled before bindings attach. Two exceptions handled by the compiler: `bind:this` is pushed into `init` (it is one-way and may influence the render effect), and a binding on an element that also has a `use:` directive is wrapped in `$.effect(...)` so it runs in order with actions.

## Core contract: the `get`/`set` thunk pair

Every two-way binding receives:

| Parameter | Meaning |
| --- | --- |
| `element` / `target` | The DOM node (or `$$props` object, or window/document) being bound. |
| `get` | A **reactive thunk** (`() => expression`) that reads the bound state. Called inside render effects so that reads are tracked as signal dependencies. |
| `set` | A **setter callback** (`($$value) => expression = $$value`) that writes a DOM-originated value back into state. Defaults to `get` when the bound expression is a simple assignable identifier. |

The compiler builds these from the directive's expression; dev-mode additionally wraps the pair with [validate_binding](client-dev-tooling.md) to warn about bindings to non-reactive (getterless) expressions.

## Component inventory

### `input.js` — form input bindings

| Function | Directive | Behavior highlights |
| --- | --- | --- |
| `bind_value(input, get, set)` | `bind:value` | Handles `input` + form-reset events, number/range coercion (`'' → null`), hydration fallback to live DOM value, selection-range restoration after coercion, focus protection, and batch-aware suppression of updates while the input is focused and the pending batch originated from user input. |
| `bind_group(inputs, group_index, input, get, set)` | `bind:group` | Maintains a **shared binding-group array** across sibling checkboxes/radios; `group_index` nests arrays per `#each` level; sets values via `input.__value`; sorts the group by document position (`compareDocumentPosition`) in a microtask; removes the input from the group in `teardown`; resolves hydration mismatches after mount. |
| `bind_checked(input, get, set)` | `bind:checked` | `change` event → `set(checked)`, render effect writes `Boolean(value)` back; hydration-aware. |
| `bind_files(input, get, set)` | `bind:files` | Read-only-style binding over `input.files` with hydration fallback. |

Helper: `get_binding_group_value(group, __value, checked)` computes the checkbox group's array value from all checked members.

### `select.js` — `<select>` bindings

- `bind_select_value(select, get, set)` — `bind:value` on a `<select>`. Uses an `effect` (not a render effect) so updates happen **after** each-block children update; on first run with `undefined` it adopts the DOM's `:checked` option. Tracks `select.__value`.
- `select_option(select, value, mounting)` — applies a value to single/multiple selects; warns via `select_multiple_invalid_value` when a non-array is given to `multiple`.
- `init_select(select)` — `MutationObserver` on child/option-value changes so dynamic `<option>` lists (e.g. inside `{#each}`) re-sync the selection without overwriting the model.

### `media.js` — `<audio>` / `<video>` bindings

| Function | Directive(s) | Sync mechanism |
| --- | --- | --- |
| `bind_current_time` | `bind:currentTime` | `requestAnimationFrame` loop while playing **plus** `timeupdate` (covers native-control scrubbing while paused); render effect writes `media.currentTime` back. |
| `bind_buffered` | `bind:buffered` | Listens to `loadedmetadata`/`progress`/`timeupdate`/`seeking`; **deep-compares** `TimeRanges` (spec always returns a new object) before setting. |
| `bind_played` / `bind_seekable` / `bind_seeking` / `bind_ended` / `bind_ready_state` | respective | Event-driven, one-way (DOM → state) via `listen`. |
| `bind_playback_rate` | `bind:playbackRate` | Bidirectional; `effect`-based so the element is mounted before `playbackRate` is set (browser resets it to `1` otherwise); `ratechange` listener registered inside an effect for the same reason. |
| `bind_paused` | `bind:paused` | Bidirectional; `play`/`pause`/`canplay` listeners (detects src-switch auto-pause); `effect` calls `media.play()/pause()`, catching a rejected `play()` promise and setting `paused = true`. |
| `bind_volume` / `bind_muted` | `bind:volume`, `bind:muted` | Bidirectional over `volumechange`; initialize from media if state is `null`. |

Helper: `time_ranges_to_array(ranges)` converts a `TimeRanges` into `[{ start, end }]`.

### `size.js` — element dimension bindings

- **`ResizeObserverSingleton`** — a per-box-mode singleton wrapper (`content-box`, `border-box`, `device-pixel-content-box` instances created eagerly at module scope). Keeps one native `ResizeObserver` per mode and a `WeakMap<Element, Set<listener>>`; `observe()` returns an unsubscribe function. A static `entries` WeakMap caches the latest `ResizeObserverEntry` per element.
- `bind_resize_observer(element, type, set)` — `bind:contentRect` / `contentBoxSize` / `borderBoxSize` / `devicePixelContentBoxSize`; DOM → state only.
- `bind_element_size(element, type, set)` — `bind:clientWidth` / `clientHeight` / `offsetWidth` / `offsetHeight`; observes border-box and pushes `element[type]` inside an `effect` wrapped in `untrack` (size reads must not create dependencies).

### `universal.js` — cross-element bindings

- `bind_content_editable(property, element, get, set)` — `bind:textContent` / `innerHTML` / `innerText`; `input` listener → state; render effect writes back, adopting the DOM value when state is `null`.
- `bind_property(property, event_name, element, set, get)` — the **generic escape hatch** used by the compiler's `binding_properties` table (e.g. `bind:indeterminate` with its change event). One-way when no `get` is supplied; `teardown` is only registered for global targets (`document`, `window`, `document.body`), because ordinary element cleanup is handled by effect-tree destruction.
- `bind_focused(element, set)` — `bind:focused`; one-way over `focus`/`blur`.

### `this.js` — `bind:this`

`bind_this(element_or_component, update, get_value, get_parts)` assigns the element (or component instance exports) into the bound variable, and **nullifies** it on teardown (via microtask, since effects cannot be created in teardown). Inside `{#each}` blocks, `get_parts` returns the each-context parts; only those parts are tracked (not the value itself) to avoid needless reruns, and a stale position is cleared when the binding "moves". Identity checks use `is_bound_this`, which also resolves proxies through `STATE_SYMBOL`.

### `window.js` — `<svelte:window>` bindings

- `bind_window_scroll(type, get, set)` — `bind:scrollX` / `scrollY`. Passive `scroll` listener wrapped in `without_reactive_context`; a `scrolling` flag + 100 ms timeout suppresses feedback loops (a stand-in for `scrollend`); the **first** render effect run intentionally does not scroll (accessibility: don't jump on mount).
- `bind_window_size(type, set)` — `bind:innerWidth` / `innerHeight` / `outerWidth` / `outerHeight`; one-way on `resize`.

### `document.js` — `<svelte:document>` bindings

- `bind_active_element(update)` — `bind:activeElement`; listens to `focusin`/`focusout`, ignoring `focusout` events that have a `relatedTarget` (focus merely moved between elements, avoiding a transient reset to `document.body`).

### `navigator.js` — `<svelte:window bind:online>`

- `bind_online(update)` — one-way over `window` `online`/`offline` events, reading `navigator.onLine`.

### `props.js` — component export binding (legacy)

- `bind_prop(props, prop, value)` — makes an `export`ed (non-prop) variable visible on `$$props` so a parent can `bind:x` on the component. Only acts when the props object exposes a setter descriptor; nulls the value on teardown.

## Shared infrastructure (`bindings/shared.js`)

| Helper | Purpose |
| --- | --- |
| `listen(target, events, handler, call_handler_immediately = true)` | Attaches one handler to multiple event names and registers `teardown` removal. Handlers typically run once immediately so initial DOM state propagates. |
| `listen_to_event_and_reset_event(element, event, handler, on_reset = handler)` | Attaches the user-input listener (wrapped in `without_reactive_context`) **and** chains an `element.__on_r` callback so a `<form>` reset restores the binding from `defaultValue`/`defaultChecked` semantics. Supports the checkbox special case of two binds (`group` + `checked`) by chaining previous reset handlers. |
| `without_reactive_context(fn)` | Temporarily clears `active_reaction` / `active_effect` so DOM-event handlers can write state **without** creating accidental signal dependencies. |

## Data flow

### Two-way binding round trip (e.g. `bind:value`)

```mermaid
sequenceDiagram
    participant U as User
    participant DOM as <input>
    participant B as bind_value closures
    participant RE as client-reactivity-engine
    participant RF as render_effect (state → DOM)

    Note over B: mount: hydration check —<br/>if hydrating && defaultValue !== value,<br/>set(DOM value) is called first
    U->>DOM: types "42"
    DOM->>B: input event (via listen_to_event_and_reset_event)
    B->>B: without_reactive_context → to_number("42")
    B->>RE: set(42) → source update (batched)
    RE->>RF: schedules render effects
    Note over B: await tick() then compare get() —<br/>coercion mismatch? restore DOM value +<br/>selectionStart/selectionEnd
    RF->>DOM: if input not focused-with-pending-batch<br/>and value changed → input.value = get()
```

### DOM → state for one-way DOM-state bindings (e.g. `bind:currentTime`)

```mermaid
flowchart LR
    A[Media events / rAF loop] --> B[compare with cached value]
    B -->|changed| C[set media.currentTime]
    C --> D[source signal update]
    D --> E[scheduler / batch commit]
    E --> F[render_effect reads get]
    F --> G[write media.currentTime]
    G -.->|value unchanged → no-op| H[settled]
```

### `bind:group` lifecycle

```mermaid
flowchart TB
    subgraph Mount
        M1["bind_group(inputs, group_index, input, get, set)"] --> M2["descend group_index arrays<br/>(one level per #each block)"]
        M2 --> M3["push input into binding_group"]
        M3 --> M4["change listener:<br/>checkbox → get_binding_group_value(...)"]
        M3 --> M5["microtask: sort group by<br/>compareDocumentPosition (pending set)"]
        M3 --> M6["render_effect: input.checked =<br/>is(__value, get())"]
        M3 --> M7["hydration mismatch? →<br/>resolve from group after mount"]
    end
    subgraph Runtime
        R1["User toggles checkbox"] --> R2["set(group value)"]
        R2 --> R3["render effects update all<br/>group members' checked state"]
    end
    subgraph Destroy
        D1["teardown()"] --> D2["splice input out of binding_group"]
    end
    M4 --> R1
```

## Interaction with the reactivity engine

Bindings are thin adapters between the DOM and the signal graph owned by [client-reactivity-engine](client-reactivity-engine.md):

- **Effects.** `render_effect` (DOM-sync writes) is preferred because it runs in the render phase before user `$effect`s; `effect` is chosen where execution must be deferred until after block updates / insertion into the DOM (`bind_select_value`, `bind_this`, `bind_element_size`, `bind_playback_rate`, `bind_paused`). `teardown` registers cleanup as a pseudo-effect.
- **Untracked writes and reads.** Event handlers run inside `without_reactive_context`; size reads use `untrack`; `bind_value`/`bind_checked`/`bind_files` read initial state with `untrack(get)` during mount to avoid capturing spurious dependencies.
- **Batches.** `bind_value` records the `current_batch` in a `WeakSet` whenever user input writes state. Later, in the render effect, if the input is focused and the active batch (`previous_batch ?? current_batch`) is one of those recorded, the DOM write is skipped — protecting cursor position when async work (e.g. `{#await}` on the bound value) defers updates. See [client-reactivity-engine_batching-scheduling](client-reactivity-engine_batching-scheduling.md) for the `Batch` commit pipeline that drives these effects.
- **Async mode.** `tick()` awaits pending flushes; `bind_value` uses it after user input before deciding whether to force-rewrite the input.
- **Proxy equality.** `bind_group` and `select_option` compare values with `is()` (from `proxy.js`) so proxy-wrapped state compares equal to raw DOM values.

## Interaction with hydration

During [client-dom-renderer_dom-foundation](client-dom-renderer_dom-foundation.md) hydration, `hydrating` is true while the DOM is adopted from server output. Form bindings consult both state and DOM:

- If the DOM value diverged from the rendered markup (e.g. user typed before hydration finished, or `defaultValue` differs), the binding **prefers the live DOM value** and writes it into state.
- `bind_group` flags a `hydration_mismatch` and resolves the correct group value in a queued microtask after the whole group is mounted (so all members are registered first).
- `bind_value` additionally special-cases partially-typed `date` inputs and numeric equivalence (`0` vs `00`) to avoid clobbering in-progress input.

## Compilation contract (how these functions get called)

The [compiler-transformer_client-transform](compiler-transformer_client-transform.md) `BindDirective` visitor performs the mapping:

1. Splits the directive expression into `get` (thunk) and `set` (`($$value) => expr = $$value`); in dev + runes mode it may inject `validate_binding` for member-expression bindings inside control-flow blocks.
2. Resolves the binding name via a static `binding_properties` table:
   - **Special-cased names** map to dedicated runtime functions: `value` (→ `bind_value`, or `bind_select_value` when the parent is a `<select>`), `checked`, `group`, `files`, `this`, `focused`, `textContent`/`innerHTML`/`innerText`, `online`, `scrollX`/`scrollY`, `innerWidth` etc., `activeElement`, all media names, and dimension names (`clientWidth`…, `contentRect`…).
   - **Table-driven names** fall back to the generic `bind_property(name, event, node, set, get?)` with an optional bidirectional getter.
3. Places the call in generated code: `after_update` (default), wrapped in `$.effect` when the element also has a `use:` directive (ordering with actions), or `init` for `bind:this`.

`bind:group` generation also threads the shared `inputs` array name and per-`#each` `group_index` array (keyed blocks wrap the index in a `$.get` source), and makes the option `value` attribute effect register as a dependency so value updates refresh the group.

Dev-mode diagnostics used by this module's callers: `bind_invalid_checkbox_value` (`bind:value` on a checkbox), `bind_invalid_export`, `bind_not_bindable`, and the `binding_property_non_reactive` warning — see [client-dev-tooling](client-dev-tooling.md).

## Design notes & invariants

- **Bindings never own DOM creation** — they only attach behavior to nodes produced by the template layer ([client-dom-renderer_dom-foundation](client-dom-renderer_dom-foundation.md)); teardown of element listeners is normally handled by effect-tree destruction, with explicit `removeEventListener` teardown only for global targets and media/rAF/observer resources.
- **Every binding is idempotent about its listener lifetime**: all listeners, observers, rAF loops, MutationObservers and group memberships have matching `teardown` registrations.
- **DOM wins on mount, state wins afterwards** — initial hydration prefers live DOM state; after mount, the reactive render effect enforces state on the DOM (with the documented focus/UX exceptions).
- **Event handlers must not create reactive dependencies** — enforced centrally by `without_reactive_context`.
- **One native `ResizeObserver` per box mode**, regardless of how many elements are bound (the `ResizeObserverSingleton` pattern), limiting observer overhead.
- **`bind:this` nullification must run in a microtask**, because effects cannot be created during teardown.

## Related modules

- [client-reactivity-engine](client-reactivity-engine.md) — signals, effects, batching, proxies consumed by every binding.
- [client-dom-renderer_dom-foundation](client-dom-renderer_dom-foundation.md) — DOM operations, templates, hydration primitives.
- [client-dom-renderer_attributes-events](client-dom-renderer_attributes-events.md) — one-way attribute/property effects and event delegation that bindings complement with the reverse (DOM → state) direction.
- [client-dom-renderer_lifecycle](client-dom-renderer_lifecycle.md) — `mount`/`hydrate`/`unmount` entry points that create and destroy the effect trees bindings register into.
- [client-dom-renderer_control-flow-blocks](client-dom-renderer_control-flow-blocks.md) — `{#each}` / `{#if}` / `{#await}` blocks that produce the branch contexts `bind:group` / `bind:this` must account for.
- [compiler-transformer_client-transform](compiler-transformer_client-transform.md) — generates the `$.bind_*` calls, including the directive→function mapping table.
- [client-dev-tooling](client-dev-tooling.md) — dev-only binding validation, errors and warnings.
- [context-api](context-api.md), [internal-shared-utils](internal-shared-utils.md) — shared utilities (`get_descriptor`, `is_array`) used by `bind_prop` and `select_option`.
