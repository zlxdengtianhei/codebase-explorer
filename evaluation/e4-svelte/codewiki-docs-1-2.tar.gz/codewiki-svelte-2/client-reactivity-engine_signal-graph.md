# Client Reactivity Engine — Signal Graph

## Overview

The **signal-graph** module is the kernel of Svelte's fine-grained reactivity system. It defines the fundamental data model of reactive nodes (`Signal`, `Value`, `Reaction`, `Derived`, `Effect`) and implements the core algorithms that keep a live, lazily-evaluated dependency graph consistent: **dependency tracking**, **dirty checking via version counters**, **lazy derived evaluation**, **graph (re-)linking and pruning**, and **controlled flushing primitives** (`tick`, `settled`).

Everything else in the client runtime is expressed in terms of this module:

- **Sources** are created/written by [client-reactivity-engine_sources-and-proxies](client-reactivity-engine_sources-and-proxies.md), but every read flows through this module's `get()`.
- **Deriveds** own their computation functions ([client-reactivity-engine_deriveds-and-async](client-reactivity-engine_deriveds-and-async.md)), but their lazy re-evaluation, dirty resolution and dependency linking are driven by `is_dirty()` / `update_reaction()` here.
- **Effects** are created and managed in [client-reactivity-engine_effects](client-reactivity-engine_effects.md), but their re-execution lifecycle (`update_effect`) and scheduling hooks (`schedule_possible_effect_self_invalidation`) live here.
- **Scheduling/flushing** (when dirty effects actually run) is orchestrated by [client-reactivity-engine_batching-scheduling](client-reactivity-engine_batching-scheduling.md), which calls back into `update_effect()` / `is_dirty()`.

**Source files:**

| File | Role |
| --- | --- |
| `packages/svelte/src/internal/client/runtime.js` | The graph engine: global graph state, tracking, dirty checking, updates, public timing utilities |
| `packages/svelte/src/internal/client/reactivity/types.d.ts` | The node type model shared by the whole reactivity engine |

---

## Module Composition

```text
internal/client/
├── runtime.js                     ← THIS MODULE (graph engine)
│     exported: get, untrack, is_dirty, update_reaction, update_effect,
│              remove_reaction(s), set_signal_status, tick, settled,
│              safe_get, deep_read_state, deep_read, exclude_from_object,
│              push_reaction_value, set_active_reaction/effect, ... (+ graph registers)
└── reactivity/
    └── types.d.ts                 ← THIS MODULE (node model)
          exported: Signal, Value<V>, Reaction, Derived<V>, Effect, Source<V>, MaybeSource<T>
```

### Exported utility components

| Component | Signature / Purpose |
| --- | --- |
| `get(signal)` | **The single read primitive.** Registers the reading reaction as a dependent and lazily evaluates deriveds. |
| `safe_get(signal)` | `signal && get(signal)` — tolerant read used for `var` declarations that may be accessed before declaration. |
| `settled()` | Returns a `Promise` that resolves once pending state changes **and their async fallout** have resolved and the DOM is updated (delegates to `Batch.ensure().settled()`; since 5.36). |
| `tick()` | Returns a `Promise` resolving after pending state changes are applied. In async mode it aligns with a `requestAnimationFrame`; otherwise it awaits a microtask then calls `flushSync()`. |
| `exclude_from_object(obj, keys)` | Shallow copy of `obj` minus `keys` — used for rest-props style extraction during component render. |
| `deep_read_state(value)` / `deep_read(value)` | Walk an object (one level / recursively) reading every property so `$state` proxies register dependencies (including getters on custom prototypes and `Date#getTime()` for `SvelteDate`). |
| `set_signal_status(signal, status)` | Atomically swap the `DIRTY`/`MAYBE_DIRTY`/`CLEAN` bits of `signal.f` via a status mask. |
| `untrack(fn)` | Execute `fn` with dependency tracking disabled. |
| `is_dirty(reaction)` | Resolve whether a reaction must re-run, recursively validating `MAYBE_DIRTY` dependencies. |
| `update_reaction(reaction)` | Run a reaction's function while (re)building its dependency list. |
| `update_effect(effect)` | Full effect re-execution cycle: destroy children, teardown, re-run, capture teardown. |
| `remove_reaction` / `remove_reactions` | Detach stale dependency edges; garbage-collect disconnected deriveds. |
| `push_reaction_value(value)` | Register a source created inside the currently running reaction (prevents self-triggered re-runs). |

---

## Core Data Model

`types.d.ts` defines a small, composable node model. Two axes are mixed in via interfaces:

- **Value** axis — things that *hold data* and can be *read*.
- **Reaction** axis — things that *run code* and *depend on values*.

```mermaid
classDiagram
    direction LR
    class Signal {
        <<interface>>
        +number f  "flags bitmask (status + kind)"
        +number wv "write version"
    }
    class Value~V~ {
        <<interface>>
        +Equals equals
        +Reaction[] reactions "downstream: who reads me"
        +number rv "read version"
        +V v "current value"
    }
    class Reaction {
        <<interface>>
        +ComponentContext ctx
        +Function fn
        +Value[] deps "upstream: what I read"
        +AbortController ac
    }
    class Derived~V~ {
        +Function fn "computation"
        +Effect[] effects
        +Effect|Derived parent
    }
    class Effect {
        +TemplateNode nodes_start
        +TemplateNode nodes_end
        +Function teardown
        +TransitionManager[] transitions
        +Effect prev
        +Effect next
        +Effect first
        +Effect last
        +Effect parent
        +Boundary b
    }
    class Source~V~ {
        <<type alias of Value~V~>>
    }

    Signal <|-- Value : holds data
    Signal <|-- Reaction : runs code
    Value <|-- Derived
    Reaction <|-- Derived
    Reaction <|-- Effect
    Value <|-- Source
```

### Field semantics

| Field | On | Meaning |
| --- | --- | --- |
| `f` | all | Bitmask combining **status** (`DIRTY`/`MAYBE_DIRTY`/`CLEAN`) with **kind/behaviour** flags (`DERIVED`, `UNOWNED`, `DISCONNECTED`, `DESTROYED`, `BLOCK_EFFECT`, `ROOT_EFFECT`, …) defined in `constants.js`. |
| `wv` | all | **Write version.** Bumped on every committed write that changes a value. The engine-wide `write_version` counter lives in `runtime.js`. |
| `rv` | `Value` | **Read version**, stamped with the reaction's `read_version` when read inside an update cycle — prevents duplicate dependency entries within one run. |
| `reactions` | `Value` | Downstream edges: the list of reactions that read this value. |
| `deps` | `Reaction` | Upstream edges: the values this reaction read during its most recent run. |
| `equals` | `Value` | Equality function (from [client-reactivity-engine_foundation](client-reactivity-engine_foundation.md)) deciding whether a new computed/written value counts as a change. |
| `ac` | `Reaction` | `AbortController` aborted (`STALE_REACTION`) when the reaction is destroyed or superseded — used by async deriveds. |
| `effects`, `parent` | `Derived` | Effects created inside the derived (destroyed with it) and its owning effect/derived (ownership for GC). |
| `first/last/prev/next/parent` | `Effect` | The **effect tree** — a hierarchy that mirrors component/block structure (see [client-reactivity-engine_effects](client-reactivity-engine_effects.md)). |
| `label`, `created`, `updated`, `set_during_effect`, `trace` | `Value` (dev only) | `$inspect.trace` / `$inspect` support: labels, creation/update stacks, and write-during-effect tracking. |

---

## Graph Topology

The signal graph is a **bipartite-ish DAG** connecting `Value` nodes (sources & deriveds) to `Reaction` nodes (deriveds & effects). `Derived` sits on both sides of the bipartition. Every read of a value inside a running reaction creates two mirrored edges:

- `reaction.deps` → the value (upstream)
- `value.reactions` → the reaction (downstream)

```mermaid
flowchart LR
    subgraph V["Value nodes (data)"]
        S1["Source: count<br/>v = 1 · wv = 7"]
        S2["Source: name<br/>v = 'ada' · wv = 3"]
        D1["Derived: doubled<br/>deps: [count]"]
        D2["Derived: label<br/>deps: [count, doubled]"]
    end
    subgraph R["Reaction nodes (code)"]
        D1r[" reaction: fn(count) "]
        D2r[" reaction: fn(count, doubled) "]
        E1["Effect: render block<br/>deps: [label, name]"]
    end

    S1 -.->|"deps ↑"| D1r
    D1r -.->|"reactions ↓"| S1
    S1 -.->|"deps ↑"| D2r
    D1 -.->|"deps ↑"| D2r
    D2 -.->|"reactions ↓"| E1
    S2 -.->|"deps ↑"| E1
```

> In practice each derived node *is* both the value and its reaction (`Derived extends Value, Reaction`); they are drawn separately above only to make the two edge directions explicit. **Data flows downstream** (source → derived → effect) while **invalidation propagates the same way**: writing a source marks its reactions dirty, and flush executes them.

Deriveds that are read *outside* any active effect are **unowned** (`UNOWNED` flag) and may become **disconnected** (`DISCONNECTED` flag) when their last reader goes away — the pruning algorithm below re-links them on demand or lets the VM garbage-collect them.

---

## Global Graph Registers (`runtime.js`)

The engine is driven by a small set of module-level variables that together describe *where we are* in the graph at any instant:

| Register | Type | Purpose |
| --- | --- | --- |
| `active_reaction` | `Reaction \| null` | The reaction whose function is currently executing; `get()` attaches new deps to it. |
| `active_effect` | `Effect \| null` | The nearest effect in the current execution context (ownership for created nodes). |
| `untracking` | `boolean` | Set by `untrack()`; suppresses dependency registration. |
| `new_deps` / `skipped_deps` | `Value[] / number` | Dependencies collected during the current `update_reaction` run, with a fast path when the prefix matches the previous run. |
| `current_sources` | `Source[] \| null` | Sources created within the running reaction — reading/writing them inside the same reaction must not re-trigger it. |
| `untracked_writes` | `Source[] \| null` | Writes performed inside a reaction that it didn't (yet) depend on — later self-invalidation bookkeeping. |
| `skip_reaction` | `boolean` | When inside an unowned derived, avoid registering duplicate reactions (memory-leak guard for detached chains). |
| `write_version` | `number` | Global monotonic counter; sources/deriveds stamp their `wv` from it. Starts at 1. |
| `read_version` / `update_version` | `number` | Per-run read stamping; incremented on nested/returning reaction switches so stamps stay unique. |
| `is_updating_effect` / `is_destroying_effect` | `boolean` | Contextual guards used by `set()` (unsafe-mutation detection) and teardown-time reads (`old_values` fallback). |

These registers are saved/restored around each `update_reaction` call, making the engine re-entrant.

---

## Versioning & Dirty-State Model

Dirty checking is **pull-based and version-annotated** — no eager topological re-computation happens on write. A reaction re-runs only when something pulls it (an effect flush, or a `get()` of a derived).

**Version rule:** a dependency is *newer* than a reaction when `dep.wv > reaction.wv` (the reaction's `wv` is stamped with the global `write_version` after each successful run).

```mermaid
stateDiagram-v2
    direction LR
    CLEAN --> MAYBE_DIRTY: transitive dep changed
    CLEAN --> DIRTY: direct dep.wv > reaction.wv
    MAYBE_DIRTY --> DIRTY: is_dirty() finds newer dep
    MAYBE_DIRTY --> CLEAN: all deps verified current
    DIRTY --> CLEAN: update_reaction() re-ran
    note right of MAYBE_DIRTY
        "maybe" = a dependency-of-a-dependency
        may have changed; resolve lazily by
        recursing through is_dirty(dep)
    end note
```

- `set_signal_status()` rewrites only the status bits (`STATUS_MASK = ~(DIRTY | MAYBE_DIRTY | CLEAN)`), preserving kind flags like `DERIVED`, `UNOWNED`, `BRANCH_EFFECT`.
- Unowned signals are deliberately **never** cached as `CLEAN` unless they are safely inside an active effect — otherwise a detached read would pin stale values.

---

## Key Algorithms

### 1. Reading a signal — `get()`

`get()` is the heart of the engine. Every reactive read in a compiled component routes through it.

```mermaid
sequenceDiagram
    autonumber
    participant R as Running reaction
    participant G as get(signal)
    participant U as update_derived<br/>(deriveds module)
    R->>G: get(signal)
    Note over G: captured_signals?.add(signal) (legacy mode)
    alt active_reaction ≠ null and not untracking
        alt inside update cycle (rv stamping)
            G->>G: stamp signal.rv = read_version
            G->>G: same slot as before? skipped_deps++ (fast path)
            else new/changed dep
            G->>G: new_deps.push(signal)
        end
        G->>G: after await (outside cycle):<br/>reaction.deps.push(signal),<br/>signal.reactions.push(reaction)
    end
    alt signal is Derived
        G->>G: is_dirty(derived)?
        alt dirty
            G->>U: update_derived(derived)
            U->>G: update_reaction(derived) — recursive tracking
            U->>U: equals check → bump derived.wv
        end
    end
    Note over G: ERROR_VALUE flag → throw stored error
    G-->>R: signal.v
```

Key details:

- **During an update cycle** (`REACTION_IS_UPDATING` set), deps are staged in `new_deps` and spliced into `reaction.deps` afterwards (see algorithm 2). **Outside a cycle** (e.g. reads after an `await` inside an async derived), edges are appended immediately.
- Reads while the containing effect is **being destroyed** resolve against `old_values` (populated by the sources module) so teardown code observes consistent pre-update snapshots.
- Reading a derived whose ownership is ambiguous flips it to `UNOWNED` so it can be collected instead of leaking through a stale parent link.
- Dev-mode additions: reactivity-loss warnings for async effects (`await_reactivity_loss`), `$inspect.trace` stack capture, and `recent_async_deriveds` bookkeeping.

### 2. Running a reaction — `update_reaction()`

```mermaid
flowchart TD
    A["Save all registers<br/>(deps, reaction, sources, ctx, versions…)"] --> B["Reset: new_deps=null, skipped_deps=0,<br/>current_sources=null, untracking=false"]
    B --> C{"reaction has<br/>AbortController?"}
    C -->|yes| D["Abort with STALE_REACTION<br/>inside without_reactive_context"]
    C -->|no| E["Set REACTION_IS_UPDATING,<br/>run reaction.fn()"]
    D --> E
    E --> F{"new_deps collected?"}
    F -->|yes| G["remove_reactions(reaction, skipped_deps);<br/>splice new_deps into deps;<br/>register back-edges in value.reactions"]
    F -->|no| H{"stale tail deps?"}
    H -->|yes| I["remove_reactions(reaction, skipped_deps);<br/>truncate deps.length = skipped_deps"]
    H -->|no| J
    G --> J{"untracked_writes and<br/>runes mode?"}
    I --> J
    J -->|yes| K["schedule_possible_effect_self_invalidation()<br/>for each write"]
    J -->|no| L{"returning to a different<br/>previous reaction?"}
    K --> L
    L -->|yes| M["read_version++ (fresh stamp space);<br/>propagate untracked_writes upward"]
    L -->|no| N["Return fn() result"]
    M --> N
    N --> O["finally: restore all registers"]
    E -->|"error"| P["handle_error(error)<br/>(error-handling module)"]
```

The **`skipped_deps` fast path** is a major optimization: if the reaction reads its dependencies in the same order as the previous run (the overwhelmingly common case), no array rebuilding, no back-edge re-registration, and no GC churn occur — the engine merely advances a counter.

### 3. Dirty resolution — `is_dirty()`

1. `DIRTY` flag set → `true` immediately.
2. `MAYBE_DIRTY` → walk `deps`, recursively resolving each derived dependency (`is_dirty(dep)` then `update_derived(dep)`), then compare versions: any `dep.wv > reaction.wv` → dirty.
3. As a side effect, this step **reconnects** disconnected/unowned deriveds: missing back-edges in `dependency.reactions` are restored, `DISCONNECTED`/`UNOWNED` flags cleared when the reaction is properly owned again, and the reaction is downgraded to `CLEAN` when nothing changed.

### 4. Lazy derived evaluation

Deriveds never run eagerly. `get(derived)` → `is_dirty(derived)` → `update_derived()` (in [client-reactivity-engine_deriveds-and-async](client-reactivity-engine_deriveds-and-async.md)) which calls back into this module's `execute_derived`-driven `update_reaction(derived)`. The computed result is committed only if `!derived.equals(newValue)`, in which case `derived.wv = increment_write_version()` — so downstream reactions compare *versions*, not deep values. Batch-aware caching (`batch_deriveds` map) lets concurrent batches time-travel consistently.

### 5. Effect re-execution — `update_effect()`

1. Skip if `DESTROYED`; mark `CLEAN`.
2. Swap in `active_effect` / `is_updating_effect` (and dev component/stack context).
3. Destroy child effects (`destroy_effect_children`, or block-aware `destroy_block_effect_children`) and run the previous `teardown`.
4. Delegate to `update_reaction(effect)`; store the returned function as the new `teardown`; stamp `effect.wv = write_version`.
5. In dev tracing mode, bump `wv` of sources written during the effect (`set_during_effect`) so the *next* run correctly sees them as dirty.

The scheduler ([client-reactivity-engine_batching-scheduling](client-reactivity-engine_batching-scheduling.md)) invokes `update_effect` only for effects whose `is_dirty()` check passed during batch traversal.

### 6. Graph pruning — `remove_reaction()` / `remove_reactions()`

When a run ends with fewer dependencies than before, the stale tail is removed: the reaction is spliced out of each dropped value's `reactions` (swap-and-pop). Crucially, if a **derived** loses its last reaction (and it isn't about to be re-added by `new_deps`), the engine marks it `MAYBE_DIRTY`, sets `DISCONNECTED`, destroys its owned child effects (`destroy_derived_effects`) and recursively detaches *its* dependencies — collapsing whole dead sub-graphs so the VM can reclaim them. Reconnection happens transparently in `is_dirty()` on the next read.

### 7. Untracked writes & self-invalidation

A reaction that writes to a source it never read (`untracked_writes`) could hide its own invalidation. After the run, `schedule_possible_effect_self_invalidation(signal, effect)` walks `signal.reactions`: derived chains are followed recursively until an effect is reached; that effect is marked `DIRTY` (or `MAYBE_DIRTY` if clean) and pushed to `schedule_effect` (batching module). In non-async mode, writes to sources *created in the same reaction* (`current_sources`) are excluded to avoid redundant self-scheduling.

### 8. Escapes: `untrack`, `deep_read_state`, `deep_read`

- `untrack(fn)` toggles the `untracking` register so reads inside `fn` create no edges (used e.g. to log without subscribing).
- `deep_read_state` performs a cheap **one-level** scan so that passing a `$state` object to a child component registers top-level dependencies; `deep_read` recurses (visited-set guarded), invokes getters on non-standard prototypes and forces `SvelteDate` reads — the blunt instrument behind `<svelte:boundary>`-reset, legacy `beforeUpdate` compatibility and each-block snapshotting.

---

## Public Timing Utilities

| Utility | Async-mode behaviour | Legacy/sync-mode behaviour |
| --- | --- | --- |
| `tick()` | Resolves on the next `requestAnimationFrame` — async flushing never blocks the frame. | Awaits one microtask, then `flushSync()` — guarantees pending writes are committed after one tick. |
| `settled()` | `Batch.ensure().settled()` — resolves when the current batch commits **and** all in-flight async effects (`$effect.pending`, async deriveds) have drained, DOM included. | Same deferred-promise mechanism via the current batch. |

Both are the sanctioned ways for application code and tests to await graph convergence; they delegate all real work to the batching module.

---

## Write-to-DOM Update Pipeline (cross-module data flow)

```mermaid
flowchart TD
    W["App code: count++<br/>→ set(source) (sources module)"] --> GUARD{"safe context?<br/>not inside derived/block effect"}
    GUARD -->|no| ERR["state_unsafe_mutation error"]
    GUARD -->|yes| CAP["Batch.capture(source, old value)<br/>(batching module)"]
    CAP --> WV["source.wv = increment_write_version()"]
    WV --> SCHED["For each reaction in source.reactions:<br/>status = DIRTY/MAYBE_DIRTY;<br/>schedule_effect → root queued"]
    SCHED --> FLUSH["Batch.process / flushSync<br/>(batching module)"]
    FLUSH --> TRAV["#traverse_effect_tree:<br/>is_dirty(effect)? (this module)"]
    TRAV -->|dirty| UE["update_effect(effect) (this module)"]
    TRAV -->|clean| SKIP2["skip subtree"]
    UE --> UR["update_reaction → effect.fn()"]
    UR --> G2["DOM writes via get()/template bindings<br/>(client-dom-renderer)"]
    G2 --> G3["New reads → new_deps relinking<br/>(this module)"]
    G3 --> DONE["commit: branch callbacks append/remove DOM"]
```

---

## Integration Map

```mermaid
flowchart TB
    subgraph SG["signal-graph (this module)"]
        RUN["runtime.js<br/>get · update_reaction · update_effect<br/>is_dirty · remove_reactions · tick · settled"]
        TYP["types.d.ts<br/>Signal · Value · Reaction · Derived · Effect · Source"]
    end

    SP["sources-and-proxies<br/>source() · set() · update()/update_pre() · proxy()"]
    DA["deriveds-and-async<br/>derived() · user_derived() · update_derived()<br/>execute_derived() · async deriveds"]
    EF["effects<br/>create_effect() · branch() · effect()"]
    BS["batching-scheduling<br/>Batch · flushSync · schedule_effect<br/>run_tasks (loop)"]
    FDN["foundation<br/>flags (async/legacy/tracing) · equality fns"]
    PS["props-and-stores<br/>prop() · store_get() · spread_props()"]
    DR["client-dom-renderer<br/>blocks · attributes · hydration · transitions"]
    LEG["legacy-compat<br/>invalidate_inner_signals · captured_signals"]

    TYP --- RUN

    SP -->|"set() bumps wv via increment_write_version();<br/>reads via get()"| RUN
    RUN -->|"lazy evaluation of dirty deriveds"| DA
    DA -->|"update_reaction · is_dirty · set_signal_status"| RUN
    EF -->|"runs effect bodies through update_effect"| RUN
    RUN -->|"schedule_effect · Batch · flushSync · batch_deriveds"| BS
    BS -->|"flush loop calls is_dirty/update_effect"| RUN
    FDN -->|"equals / not_equal · mode flags"| RUN
    PS -->|"all prop/store reads are get() calls"| RUN
    DR -->|"template effects created via effects module"| EF
    LEG -->|"captured_signals registered in get()"| RUN
```

**Contract summary:** this module owns the *edges, versions and statuses*; sibling modules own *node creation* (sources, deriveds, effects) and *when work happens* (batches, the microtask/frame loop). Nothing outside `runtime.js` mutates `deps`/`reactions` or compares `wv`s directly.

---

## Error Handling & Dev Behaviour

- **Errors inside reactions** are routed through `handle_error` (error-handling module), which funnels into `<svelte:boundary>` or rethrows. A reaction that threw is flagged `ERROR_VALUE`; the next `get()` of it re-throws the stored value.
- **Stale async work:** any `AbortController` attached to a reaction is aborted (`STALE_REACTION`) at the start of its next update and on teardown, via `without_reactive_context`.
- **Unsafe mutation:** `set()` (sources module) uses this module's `active_reaction`/`untracking` registers to reject writes from inside deriveds/block effects.
- **Dev tracing:** with `tracing_mode_flag`, `get()` records creation/update stacks onto `Value` nodes and invokes `signal.trace()` hooks for each-block item signals; effect-internal writes flip `set_during_effect` so `update_effect` can version-bump them.
- **Legacy mode:** `captured_signals` (legacy-compat) collects every signal read during component init to support `invalidate_inner_signals`.

---

## Design Invariants & Performance Notes

1. **Laziness** — writes never compute; they only stamp versions and mark statuses. Computation happens on pull (`get` / flush).
2. **Edge symmetry** — `deps` and `reactions` are always kept mutually consistent; every mutation path in this module maintains both directions.
3. **Version monotonicity** — `write_version` only increases; stale-cache detection is a single integer comparison (`dep.wv > reaction.wv`), giving O(1) per-edge checks.
4. **Cheap steady-state** — the `skipped_deps` prefix-matching fast path makes re-runs with unchanged dependency shape nearly allocation-free.
5. **GC-friendliness** — unowned/disconnected deriveds collapse their sub-graphs when unobserved and transparently re-link when read again.
6. **Re-entrancy** — every algorithm saves/restores the full register set, so nested reactions, deriveds-reading-deriveds and async interleaving are all safe.

---

## Related Documentation

- Parent engine: [client-reactivity-engine](client-reactivity-engine.md)
- Source creation & mutation: [client-reactivity-engine_sources-and-proxies](client-reactivity-engine_sources-and-proxies.md)
- Derived & async computations: [client-reactivity-engine_deriveds-and-async](client-reactivity-engine_deriveds-and-async.md)
- Effect lifecycle & tree: [client-reactivity-engine_effects](client-reactivity-engine_effects.md)
- Batching & scheduling: [client-reactivity-engine_batching-scheduling](client-reactivity-engine_batching-scheduling.md)
- Props & store bridges: [client-reactivity-engine_props-and-stores](client-reactivity-engine_props-and-stores.md)
- Flags & equality primitives: [client-reactivity-engine_foundation](client-reactivity-engine_foundation.md)
- DOM application of updates: [client-dom-renderer](client-dom-renderer.md)
