# client-reactivity-engine_batching-scheduling

## Introduction

The **batching-scheduling module** (`packages/svelte/src/internal/client/reactivity/batch.js` + `packages/svelte/src/internal/client/loop.js`) is the *transaction manager and work scheduler* of Svelte's client runtime. It is the counterpart of the [signal graph](client-reactivity-engine_signal-graph.md): while the signal graph knows *how* to run an effect, this module decides *when*, *in what order*, and *how many times* effects run in response to state changes.

Every state write in a Svelte 5 application is coalesced into a **`Batch`** — an atomic unit of work that records which sources changed, traverses the effect tree, commits DOM updates, and (in async mode) suspends itself while async deriveds settle. The module additionally provides:

1. **Batch transactions** — capture of previous/current source values per update, enabling rollback ("time travelling") when several async batches are in flight, and `settled()` promises for awaiting quiescence.
2. **Scheduling** — deterministic effect ordering (block → render → user → async), a microtask-based flush queue (`Batch.enqueue`/`dequeue`), and the `flushSync` escape hatch.
3. **Async coordination** — a pending-work counter (`increment`/`decrement`), the `suspend`/`unsuspend` protocol used with `<svelte:boundary>` and async deriveds, and deferral of effects until async work completes.
4. **Frame-loop tasks** (`loop.js`) — a `requestAnimationFrame` task queue that powers transitions and animations in the [client-dom-renderer](client-dom-renderer.md).

> **Where it sits:** this is the `client-reactivity-engine_batching-scheduling` child of [client-reactivity-engine](client-reactivity-engine.md). For how effects are *created and destroyed*, see [effects](client-reactivity-engine_effects.md); for how *writes* reach a batch, see [sources-and-proxies](client-reactivity-engine_sources-and-proxies.md).

---

## Architecture

```mermaid
flowchart TB
    subgraph Engine["client-reactivity-engine"]
        SRC["sources-and-proxies<br/>internal_set → Batch.ensure() +<br/>batch.capture() · old_values"]
        SG["signal-graph (runtime.js)<br/>update_effect · is_dirty ·<br/>set_signal_status · tick · settled"]
        DER["deriveds-and-async<br/>ASYNC effects · async_derived<br/>reads batch_deriveds"]
        EFF["effects<br/>block/branch effects · unlink_effect"]
        PS["props-and-stores<br/>update_prop / update_store run<br/>as effects inside batches"]
        FND["foundation<br/>async_mode_flag · equality"]
        BS["⭐ batching-scheduling (this module)<br/>Batch · flushSync · schedule_effect ·<br/>suspend · Batch.enqueue/dequeue · loop()"]
    end

    subgraph DOM["client-dom-renderer"]
        TASK["dom/task.js<br/>flush_tasks (micro + idle)"]
        BND["dom/blocks/boundary.js<br/>get_pending_boundary ·<br/>update_pending_count"]
        BLOCKS["dom blocks (if/each/key/await…)<br/>commit callbacks swap branches"]
        TRANS["transitions & animations<br/>loop() consumers"]
        RENDER["render.js<br/>mount / hydrate / unmount"]
    end

    TOOLS["client-dev-tooling<br/>errors · invoke_error_boundary ·<br/>DEV loop diagnostics"]
    BENCH["reactivity benchmarks<br/>(kairo / sbench / mol)"]

    SRC -- "write → Batch.ensure()<br/>capture(source, old_value)" --> BS
    EFF -- "schedule_effect →<br/>queued_root_effects" --> BS
    PS -- "render effects,<br/>flushed per batch" --> BS
    BS -- "flush: update_effect,<br/>is_dirty, set_signal_status" --> SG
    SG -- "tick() → flushSync<br/>settled() → Batch.settled()" --> BS
    DER -- "ASYNC effects collected,<br/>run after commit" --> BS
    BS -- "flush_tasks()" --> TASK
    BS -- "suspend() / pending counts" --> BND
    BS -- "#commit() runs branch<br/>DOM add/remove callbacks" --> BLOCKS
    BS -- "flushSync(fn)" --> RENDER
    TRANS -- "loop(cb) raf tasks" --> BS
    BS -- "infinite loop guard" --> TOOLS
    BENCH -. "measures scheduling<br/>throughput" .-> BS
    FND -. "gates async features" .-> BS
```

**Key contracts:**

- **Writes never flush directly.** `internal_set` (see [sources-and-proxies](client-reactivity-engine_sources-and-proxies.md)) only calls `Batch.ensure()` + `batch.capture(source, old_value)` and marks reactions `DIRTY`; actual execution happens in `Batch.process()` during a flush.
- **One batch per logical update wave.** `Batch.ensure()` returns the current batch or creates one; the flush task is queued as a microtask (never while `is_flushing_sync`).
- **Ordering guarantee per flush:** dirty *block* effects run inline during tree traversal → `#commit()` swaps DOM branches → queued *render* effects (`$effect.pre`, template updates) → queued *user* effects (`$effect`) → *async* effects last (they must see final values).
- **`flushSync` is the only synchronous path**, and in async mode it is forbidden inside effects (`flush_sync_in_effect`).

---

## Module state (batch.js)

All scheduler state lives in module-level mutable variables — this subsystem is a singleton per app:

| Variable | Purpose |
|---|---|
| `batches: Set<Batch>` | Registry of all live (uncommitted) batches |
| `current_batch: Batch \| null` | The batch that new writes attach to |
| `previous_batch: Batch \| null` | Non-async-mode compatibility shim (slated for removal in 6.0) |
| `batch_deriveds: Map \| null` | Time-travel cache: derived values computed against a batch's *view* of sources, instead of cached on the deriveds themselves |
| `effect_pending_updates: Set<fn>` | Callbacks deferred while their batch was deactivated; drained one-at-a-time on `deactivate()` |
| `tasks: Array<fn>` | Microtask work list backing `Batch.enqueue`/`dequeue` (LIFO: `unshift`/`shift`) |
| `queued_root_effects: Effect[]` | Root effects scheduled for the next flush (`schedule_effect` pushes here) |
| `last_scheduled_effect` | Most recently scheduled effect — anchor for the infinite-loop error boundary |
| `is_flushing` / `is_flushing_sync` | Re-entrancy guards |
| `eager_block_effects: Effect[] \| null` | Hand-off list: effects scheduled *during* an effect's execution that must run eagerly in the same commit (drained by `flush_queued_effects`) |

---

## The Batch class

```mermaid
classDiagram
    class Batch {
        <<transaction>>
        +Map~Source,any~ current
        +Set~Effect~ skipped_effects
        +process(root_effects)
        +capture(source, value)
        +activate()
        +deactivate()
        +neuter()
        +flush()
        +increment()
        +decrement()
        +add_callback(fn)
        +settled() Promise
        +ensure()$ Batch
        +enqueue(task)$
    }
    note for Batch "private (JS #) members:
    previous        Map Source → value before this batch
    callbacks       Set of fns run at #commit (branch DOM swap)
    pending         number of in-flight async effects
    deferred        { promise, resolve, reject } backing settled()
    neutered        true when an async effect resolved but its
                    parent branch was already destroyed → skip commit
    async_effects   ASYNC effects, run after everything else
    boundary_async_effects  same, but inside a pending svelte:boundary
                    (do not block commit)
    render_effects  RENDER_EFFECT list — flushed at commit time
    effects         user EFFECT list — flushed after render effects
    block_effects   BLOCK_EFFECT list — may re-run on later flushes
    dirty_effects / maybe_dirty_effects  deferred until async completes"
```

The work-list split is the heart of the ordering guarantee. Each category maps to an effect flag from `#client/constants`:

| List | Flag | When it runs |
|---|---|---|
| `#block_effects` | `BLOCK_EFFECT` | Inline during traversal (if dirty); re-runnable on later flushes for internal sources (e.g. each-block items) |
| `#render_effects` | `RENDER_EFFECT` (async mode) | After `#commit()`, before user effects |
| `#effects` | `EFFECT` / `USER_EFFECT` | After render effects |
| `#async_effects` / `#boundary_async_effects` | `ASYNC` | After the rest of the batch — they must always observe the latest values |
| `#dirty_effects` / `#maybe_dirty_effects` | `DIRTY` / `MAYBE_DIRTY` | Deferred while async work is pending; rescheduled by `decrement()` |

---

## Batch lifecycle

```mermaid
stateDiagram-v2
    [*] --> Active: Batch.ensure() — added to `batches`,<br/>flush task enqueued unless flushing sync
    Active --> Active: capture() records writes ·<br/>schedule_effect adds root effects
    Active --> Processing: flush() / flushSync()
    Processing --> Processing: process() loop inside flush_effects
    Processing --> Committing: no ASYNC effects and #pending = 0
    Processing --> Awaiting: ASYNC effects found or #pending > 0<br/>→ render/user/block effects deferred
    Committing --> Active: batch re-instated (if effects<br/>started no new batch) · settled() resolves
    Awaiting --> Committing: last decrement() reschedules<br/>deferred effects, then flush()
    Awaiting --> Dormant: deactivate() so other batches proceed
    Dormant --> Committing: unsuspend() → activate() + decrement()
    Committing --> [*]: #pending = 0 → removed from `batches`
```

A batch becomes **`neutered`** when an async effect resolves but its parent branch was destroyed in the meantime — `#commit()` then skips its DOM callbacks to avoid resurrecting dead DOM.

---

## The flush pipeline

```mermaid
sequenceDiagram
    autonumber
    participant App as component code
    participant S as sources (internal_set)
    participant B as Batch (batch.js)
    participant M as microtask queue<br/>(enqueue / dequeue)
    participant SG as signal-graph (runtime.js)
    participant DOM as branches (commit callbacks)

    App->>S: set(source, value)
    S->>S: old_values.set(source, old)
    S->>B: Batch.ensure()
    B->>M: Batch.enqueue(flush task)<br/>(first task also schedules dequeue)
    S->>B: batch.capture(source, old_value)
    Note over B: previous / current recorded
    S->>SG: mark_reactions(source, DIRTY)
    SG->>B: schedule_effect(effect)
    B->>B: dirty ROOT/BRANCH ancestors,<br/>push root → queued_root_effects
    Note over M: microtask fires
    M->>B: dequeue() → batch.flush()
    B->>B: flush_effects(): batch.process(roots)
    B->>B: #traverse_effect_tree —<br/>dirty block effects run inline;<br/>render/user/async effects collected
    alt no async work outstanding
        B->>DOM: #commit() → branch callbacks
        B->>SG: flush_queued_effects(render_effects)
        B->>SG: flush_queued_effects(effects)
        B-->>App: settled() promises resolve
    else async effects or #pending > 0
        B->>B: #defer_effects → #dirty/#maybe_dirty_effects<br/>(status reset to CLEAN)
    end
```

### `process(root_effects)` in detail

```mermaid
flowchart TD
    R["process(root_effects)"] --> TT{"async_mode_flag and<br/>batches.size > 1?"}
    TT -- yes --> TTV["time travel: stash live source values,<br/>apply this batch's current values,<br/>undo other batches' writes,<br/>enable batch_deriveds cache"]
    TT -- no --> TR
    TTV --> TR["for each root: #traverse_effect_tree"]
    TR --> MORE{"more nodes?"}
    MORE -- yes --> KIND{"node kind?"}
    KIND -- "skippable: clean branch,<br/>INERT, or in skipped_effects" --> MORE
    KIND -- "BRANCH / ROOT" --> BR["toggle CLEAN off, descend"]
    KIND -- "EFFECT (user)" --> UE["push to #effects"]
    KIND -- "RENDER_EFFECT<br/>(async mode only)" --> RE["push to #render_effects"]
    KIND -- "ASYNC" --> AE["push to #async_effects,<br/>or #boundary_async_effects when<br/>inside a pending svelte:boundary"]
    KIND -- "other dirty effect" --> BE["BLOCK_EFFECT also pushed to<br/>#block_effects · update_effect now"]
    BR --> MORE
    UE --> MORE
    RE --> MORE
    AE --> MORE
    BE --> MORE
    MORE -- no --> DEC{"#async_effects empty<br/>and #pending = 0?"}
    DEC -- yes --> COM["#commit() callbacks · swap work lists ·<br/>previous_batch = current · current = null ·<br/>flush_queued_effects(render, then effects) ·<br/>re-instate batch or delete it · resolve settled()"]
    DEC -- no --> DEF["#defer_effects: stash render / user / block<br/>lists as dirty or maybe-dirty,<br/>reset status to CLEAN"]
    COM --> REST{"was time travelling?"}
    DEF --> REST
    REST -- yes --> RS["restore stashed source values<br/>(unless source.wv advanced),<br/>clear batch_deriveds"]
    REST -- no --> ASY
    RS --> ASY["update_effect on #async_effects,<br/>then #boundary_async_effects,<br/>then clear both lists"]
```

Notes on the commit path:

- `current_batch` is deliberately nulled **before** render/user effects run. If an effect writes to sources during its own flush, a *fresh* batch is created rather than mixing old and new writes (which would loop forever). If no new batch appeared, the current batch is re-instated because `flush_effects()` may iterate again.
- `flush_queued_effects` also prunes the effect tree: an effect with no deps, children, DOM nodes and teardown is `unlink_effect`-ed entirely (courtesy of [effects](client-reactivity-engine_effects.md)), or merely has `fn` nulled when teardown/abort state must survive.
- The hand-off list `eager_block_effects` catches effects scheduled in the middle of another effect's execution; they are updated immediately after the current effect, with `old_values` cleared in between.

---

## `flushSync` — the synchronous escape hatch

```mermaid
flowchart TD
    A["flushSync(fn?)"] --> B{"async_mode_flag<br/>and active_effect?"}
    B -- yes --> E["throw flush_sync_in_effect<br/>(see client-dev-tooling)"]
    B -- no --> C["is_flushing_sync = true"]
    C --> D{"fn provided?"}
    D -- yes --> D1["flush_effects()<br/>then result = fn()"]
    D -- no --> L
    D1 --> L["loop:"]
    L --> L1["flush_tasks()<br/>(micro + idle tasks from dom/task.js)"]
    L1 --> L2{"queued_root_effects<br/>empty?"}
    L2 -- no --> L3["flush_effects()"] --> L
    L2 -- yes --> L4["current_batch?.flush()"]
    L4 --> L5{"still empty?<br/>(e.g. $effect.pending<br/>scheduled more work)"}
    L5 -- yes --> L6["last_scheduled_effect = null<br/>return result"]
    L5 -- no --> L3
    L6 --> F["finally: restore is_flushing_sync"]
```

`flushSync` drives the same `flush_effects()` loop as the microtask path, but never yields until the scheduler is quiet. It is the primitive behind `tick()` and `settled()` in the [signal graph](client-reactivity-engine_signal-graph.md), `mount`/`hydrate`/`unmount` in [client-dom-renderer](client-dom-renderer.md), and user-facing `flushSync` from `svelte`.

---

## Async work, suspension and boundaries

Async deriveds (see [deriveds-and-async](client-reactivity-engine_deriveds-and-async.md)) create `ASYNC` effects whose work completes *after* the flush that started it. The batch tracks this with `#pending` and the `suspend()`/`unsuspend()` protocol:

```mermaid
flowchart TD
    A["async work starts<br/>(async_derived continuation)"] --> B{"inside a pending<br/>svelte:boundary?"}
    B -- yes --> B1["boundary.update_pending_count(1)<br/>(does not block this batch)"]
    B -- no --> C["batch.increment() → #pending += 1"]
    B1 --> R["return unsuspend() closure"]
    C --> R
    R --> W["ASYNC effect runs after the rest<br/>of the batch (or after the last<br/>decrement, via deferred lists)"]
    W --> U["unsuspend()"]
    U --> V{"boundary was<br/>already pending?"}
    V -- yes --> V1["boundary.update_pending_count(-1)<br/>batch.deactivate()"]
    V -- no --> V2["batch.activate()<br/>batch.decrement()"]
    V1 --> X["unset_context (async.js)"]
    V2 --> Z{"#pending = 0?"}
    Z -- no --> Y["deactivate() — let other<br/>batches proceed"]
    Z -- yes --> Z1["reschedule deferred effects:<br/>#dirty_effects → DIRTY,<br/>#maybe_dirty_effects → MAYBE_DIRTY<br/>via schedule_effect"]
    Z1 --> Z2["flush()"]
```

Design consequences:

- While async work is in flight, `process()` does **not** commit; instead `#defer_effects` stashes render/user/block effects and resets their status to `CLEAN` so they can be re-scheduled cleanly when the data arrives (or when dependencies change again).
- `Batch.settled()` returns a promise resolved at commit — this is what `settled()` in the signal graph exposes, and what `$effect.pending`-style logic and tests await.
- `deactivate()` drains `effect_pending_updates` **one at a time**, stopping as soon as a new batch activates — preventing unbounded cascades.
- Effects found inside a pending `<svelte:boundary>` go to `#boundary_async_effects` and are updated after the batch commits without holding it open (boundary error UI shows immediately; data lands later).

---

## Time travelling (concurrent async batches)

In async mode several batches can exist at once (e.g. two overlapping `await`-derived updates). Because `process()` runs effects synchronously against the *live* sources, the batch temporarily rewrites the world to its own point of view:

```mermaid
flowchart LR
    subgraph BA["Batch A (earlier update)"]
        A1["previous x = 1"] --> A2["current x = 2"]
    end
    subgraph BB["Batch B (this process call)"]
        B1["previous x = 2"] --> B2["current x = 3"]
    end
    X["live source x.v"] --> ST["1. stash live values<br/>2. apply B.current → x = 3<br/>3. for sources B did not touch,<br/>revert other batches' writes"]
    ST --> D["effects/deriveds evaluate<br/>against B's view; derived results<br/>cached in batch_deriveds,<br/>not on the derived itself"]
    D --> RS["after traversal: restore stashed<br/>values unless source.wv shows a<br/>newer write won the race"]
```

This is why `batch_deriveds` exists: a derived evaluated during B's traversal must not cache a value that is only valid inside B's timeline.

---

## The infinite loop guard

`flush_effects()` counts process iterations per flush; past **1000** it triggers `infinite_loop_guard()`:

- In DEV, it aggregates the `source.updated` diagnostics that [sources-and-proxies](client-reactivity-engine_sources-and-proxies.md) records per call stack and logs each distinct offender before throwing.
- The `effect_update_depth_exceeded` error is routed through `invoke_error_boundary` anchored at `last_scheduled_effect` — best-effort, the boundary nearest the most recently scheduled effect — so `<svelte:boundary>` can render a fallback (see [client-dom-renderer](client-dom-renderer.md) and [client-dev-tooling](client-dev-tooling.md)).

`schedule_effect` complements this by bailing out when a `BLOCK_EFFECT` schedules work on its own internal source while `is_flushing` — otherwise each/await blocks would force a second flush for every iteration.

---

## Component reference

### ⭐ `clear()`

Forcibly empties the `batches` registry: `batches.clear()`. It exists purely for **test isolation** — removing all current batches prevents cross-talk between tests that each create their own reactive universes. It intentionally does *not* touch `current_batch` or queued effects; it only drops the registry so leftover uncommitted batches from one test cannot be flushed by another.

### ⭐ `dequeue()`

The drain function behind `Batch.enqueue(task)`:

1. `tasks.shift()` — take the front task (the array is LIFO: `enqueue` *unshifts*, so the most recently scheduled flush task runs first);
2. if more tasks remain, re-queue `dequeue` with `queueMicrotask` — **each task runs in its own microtask**, letting other microtasks (promise continuations from async work) interleave;
3. run the task — typically `batch.flush()` with a guard that no `flushSync` has replaced the current batch in the meantime.

`Batch.enqueue(task)` only schedules `dequeue` when `tasks` transitions from empty to non-empty; subsequent enqueues while a drain is pending simply prepend.

### ⭐ `run_tasks()` (loop.js)

The animation-frame task runner backing `loop(callback)`:

```mermaid
flowchart TD
    A["loop(callback)"] --> B{"raf.tasks empty?"}
    B -- yes --> C["raf.tick(run_tasks)"]
    B -- no --> D
    C --> D["add task { c: callback, f: fulfill }"]
    D --> E["return { promise, abort() }"]
    E --> F["next animation frame"]
    F --> G["run_tasks(): now = raf.now()"]
    G --> H{"callback returns truthy?"}
    H -- yes --> K["keep task"]
    H -- no --> I["delete task · task.f() fulfills promise"]
    K --> J{"tasks remain?"}
    I --> J
    J -- yes --> G
    J -- no --> L["raf loop idles until the<br/>next loop() call"]
```

Details:

- Uses `raf.now()` rather than the rAF callback argument for a consistent clock (see the linked fix in the source comments).
- A task that keeps returning truthy survives to the next frame; a falsy return (or `abort()`) removes it and fulfills the `loop()` promise.
- The `raf` abstraction (and its SSR fallback) lives in the sibling `timing.js`. Consumers are the transition/animation machinery in [client-dom-renderer](client-dom-renderer.md) — every `Transition` and spring-driven animation runs as a `loop()` task.

### Other members

| Member | Role |
|---|---|
| `flushSync(fn?)` | Synchronous flush to quiescence (see flow above); returns `fn()`'s result |
| `flush_effects()` | Process loop with re-entrancy guards and the 1000-iteration DEV diagnostics |
| `flush_queued_effects(list)` | Runs commit-time render/user effects; prunes trivial effects; drains `eager_block_effects` |
| `schedule_effect(effect)` | Dirty-casts ancestors up to the nearest root/branch and queues the root; bail-outs for block effects during flush |
| `suspend()` / `unsuspend()` | Pending-work protocol for async deriveds and boundaries |
| `Batch.ensure()` (static) | Get-or-create the current batch; enqueues its flush task unless `is_flushing_sync` |
| `Batch.enqueue(task)` (static) | Microtask work list used for batch flushes (pairs with `dequeue`) |
| `batch.capture(source, value)` | Record a write: previous value once, current value always |
| `batch.add_callback(fn)` / `#commit()` | Register and run branch DOM swap callbacks exactly once per commit |
| `batch.neuter()` | Mark batch as un-committable (parent branch already destroyed) |
| `batch.settled()` | Promise resolving when the batch commits |

---

## Interaction with the wider system

| Partner module | Interaction |
|---|---|
| [client-reactivity-engine_signal-graph](client-reactivity-engine_signal-graph.md) | `update_effect`, `is_dirty`, `set_signal_status`, `is_updating_effect`, `active_effect` drive flushing; `tick()` calls `flushSync`; `settled()` delegates to `Batch.settled()` |
| [client-reactivity-engine_sources-and-proxies](client-reactivity-engine_sources-and-proxies.md) | `internal_set` opens/captures into batches; `old_values` is cleared after each `process()`; write versions decide dirtiness during traversal |
| [client-reactivity-engine_effects](client-reactivity-engine_effects.md) | `schedule_effect` entry point; `unlink_effect` used for tree pruning; block/branch effect semantics shape traversal skipping |
| [client-reactivity-engine_deriveds-and-async](client-reactivity-engine_deriveds-and-async.md) | `ASYNC` effects are collected and run last; `batch_deriveds` caches time-travel derived values; `unset_context` on unsuspend |
| [client-reactivity-engine_props-and-stores](client-reactivity-engine_props-and-stores.md) | `update_prop`/`update_store` and their `pre` variants run as render effects scheduled into the current batch |
| [client-reactivity-engine_foundation](client-reactivity-engine_foundation.md) | `async_mode_flag` gates render-effect deferral, time travelling and the flushSync-in-effect ban; equality (`safe_equals`) feeds `is_dirty` |
| [client-dom-renderer](client-dom-renderer.md) | `flush_tasks` drains micro/idle tasks inside flushSync; boundary pending counts integrate with `suspend`; commit callbacks swap branch DOM; transitions/animations run on `loop()` tasks; `mount`/`hydrate`/`unmount` use `flushSync` |
| [client-dev-tooling](client-dev-tooling.md) | `flush_sync_in_effect`, `effect_update_depth_exceeded` errors; DEV per-stack update diagnostics; `invoke_error_boundary` |
| [legacy-compat](legacy-compat.md) | Legacy mode keeps `previous_batch` semantics and permits (discouraged) `flushSync` inside effects |
| [reactivity_benchmarks](reactivity_benchmarks.md) | kairo/sbench/mol suites measure exactly this module's scheduling throughput (batch creation → flush latency) |

---

## Design notes & invariants

1. **Writes are cheap; flushes are structured.** A `set` only records a capture and dirties reactions — all ordering decisions are centralized in one place, which is what makes `flushSync`, async suspension and time travelling expressible at all.
2. **Four-phase ordering per wave:** dirty block effects (inline) → commit callbacks (DOM swap) → render effects → user effects, with ASYNC effects strictly last so they always observe final values.
3. **Batches are transactions.** `#previous`/`current` maps plus the `source.wv` restore check give rollback semantics; `settled()` exposes commit completion; `#neutered` prevents committing into destroyed subtrees.
4. **Re-entrancy is managed, not forbidden.** `is_flushing`/`is_flushing_sync` plus the batch swap-out in `process()` let effects that write spawn fresh batches instead of corrupting the current one; the loop guard catches the pathological cases with dev-attributable errors.
5. **Microtask granularity is deliberate.** `dequeue` runs one task per microtask so async continuations can interleave, which the async/suspension machinery depends on.
6. **Sync escape hatches are fenced.** `flushSync` inside an effect in async mode is a hard error — it would make effect ordering un-reasonable — while legacy mode retains the permissive behavior.
7. **The frame loop is isolated.** `loop.js` knows nothing about effects; it is a minimal rAF task queue, which keeps transition timing independent from reactive flush cycles (and, per the source TODO, a candidate to merge into `timing.js`).
