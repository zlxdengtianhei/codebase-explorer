# public-api_server-entry

> **Module**: `packages/svelte/src/index-server.js`
> **Core components**: `createEventDispatcher`, `hydrate`, `mount`, `onDestroy`, `unmount`
> **Parent**: [public-api](public-api.md) · **Counterpart**: [public-api_client-entry](public-api_client-entry.md)

## 1. Introduction

`public-api_server-entry` is the **server-side entry point** of Svelte's public API. When application or framework code imports from the `svelte` package in a server (SSR / Node) environment, module-resolution conditions map the bare specifier to `packages/svelte/src/index-server.js` instead of the browser bundle.

Its defining design goal is **API-shape parity with the client entry**: it exports the *same set of names* as [public-api_client-entry](public-api_client-entry.md) (`mount`, `hydrate`, `unmount`, `onDestroy`, `createEventDispatcher`, `setContext`, ...), so that isomorphic source code imports identically on both targets — only the *behavior* of each export differs per platform. Every export falls into exactly one of three behavior classes:

1. **Fully functional** — operations that are meaningful during server rendering (`onDestroy`, context API, raw snippets, abort signals, `untrack`).
2. **Deliberate no-ops** — browser-only or timing-based operations that are safely skipped on the server (`onMount`, `beforeUpdate`, `afterUpdate`, `flushSync`, `createEventDispatcher`, `tick`, `settled`).
3. **Fail-fast stubs** — DOM-mounting operations that can never be meaningful on the server and therefore throw immediately (`mount`, `hydrate`, `unmount`).

This makes the module the compatibility "front door" that connects user-facing imports to the [Server-Side_Rendering___Cross-Target_Runtime_Services](server-runtime.md) engine, while preventing incorrect browser-only usage with clear, documented errors.

## 2. Export Surface and Behavior Classification

| Export | Source | Behavior on server | Notes |
|---|---|---|---|
| `onDestroy(fn)` | local | ✅ **Functional** | Appends `fn` to `current_component.d` (destroy-hook list); executed when the component render is torn down. |
| `untrack` | `internal/shared/utils.js` (`run`) | ✅ **Functional** | Server code is not reactive, so `untrack(fn)` is simply `fn()`. |
| `setContext`, `getContext`, `hasContext`, `getAllContexts` | `internal/server/context.js` | ✅ **Functional** | Server implementation of the context API — see [context-api](context-api.md). |
| `createRawSnippet` | `internal/server/blocks/snippet.js` | ✅ **Functional** | Wraps a snippet factory so its `render()` output is pushed into the SSR payload. |
| `getAbortSignal` | `internal/server/abort-signal.js` | ✅ **Functional** | Lazily creates an `AbortController` and exposes its signal for render cancellation. |
| `onMount`, `beforeUpdate`, `afterUpdate`, `flushSync` | `internal/shared/utils.js` (`noop`) | ⏭️ **No-op** | DOM/flush concepts do not exist during SSR; the hooks still *exist* so shared code can call them. |
| `createEventDispatcher()` | local | ⏭️ **No-op factory** | Returns `noop`; dispatched events are dropped (no client to receive them). |
| `tick()`, `settled()` | local | ⏭️ **Async no-op** | Remain `async` so `await tick()` keeps working shape-wise across targets. |
| `mount()`, `hydrate()`, `unmount()` | local | ❌ **Throws** | Raise `lifecycle_function_unavailable` from `internal/server/errors.js`. |

## 3. Architecture

### 3.1 Component map

The module itself is thin: two small local functions plus a set of re-exports. It acts as a **facade** over internal server modules.

```mermaid
flowchart TB
    subgraph consumers["Consumers"]
        APP["Application SSR bootstrap<br/>(imports 'svelte')"]
        COMPILED["Compiled server components<br/>(from compiler-transformer)"]
        FW["Frameworks (e.g. SvelteKit)"]
    end

    subgraph entry["packages/svelte/src/index-server.js"]
        OD["onDestroy"]
        CED["createEventDispatcher"]
        STUBS["mount / hydrate / unmount<br/>(fail-fast stubs)"]
        REEXPORT["re-exports:<br/>onMount, beforeUpdate, afterUpdate,<br/>flushSync (noop), untrack (run),<br/>tick, settled (async noop)"]
        CTX["setContext / getContext /<br/>hasContext / getAllContexts"]
        SNIP["createRawSnippet"]
        ABRT["getAbortSignal"]
    end

    subgraph internals["Internal server modules"]
        SCTX["internal/server/context.js<br/>(current_component, context map)"]
        SHARED["internal/shared/utils.js<br/>(noop, run)"]
        ERRS["internal/server/errors.js<br/>(lifecycle_function_unavailable)"]
        SNIPPET["internal/server/blocks/snippet.js"]
        ABORT["internal/server/abort-signal.js"]
    end

    subgraph engine["Server-Side Rendering engine"]
        RENDER["internal/server/index.js<br/>(render, unsubscribe_stores)"]
    end

    APP --> entry
    FW --> entry
    COMPILED --> entry

    OD --> SCTX
    CTX --> SCTX
    CED --> SHARED
    REEXPORT --> SHARED
    STUBS --> ERRS
    SNIP --> SNIPPET
    ABRT --> ABORT

    SCTX --> RENDER
```

### 3.2 Relationship to the client entry

The client twin exposes identical names but different implementations. The bundler's export conditions (browser vs. node/server) decide which entry is linked at build time — application source code never changes.

```mermaid
flowchart LR
    SRC["Isomorphic source<br/>import { mount, onDestroy } from 'svelte'"]

    SRC --> RES{"Bundler export<br/>conditions"}

    RES -->|"browser"| CE["public-api_client-entry<br/>index-client.js<br/>real mount/hydrate/unmount"]
    RES -->|"node / server"| SE["public-api_server-entry<br/>index-server.js<br/>no-ops + fail-fast stubs"]

    CE --> CR["Client_Runtime_Engine<br/>(Reactivity & DOM Rendering)"]
    SE --> SSR["Server-Side Rendering &<br/>Cross-Target Runtime Services"]
```

## 4. Component Behavior Details

### 4.1 `onDestroy(fn)` — the only local, fully functional lifecycle hook

```javascript
export function onDestroy(fn) {
    var context = /** @type {Component} */ (current_component);
    (context.d ??= []).push(fn);
}
```

- Reads the module-level `current_component` state owned by `internal/server/context.js` and lazily initializes the component's destroy-hook list `d`.
- During SSR, components are executed exactly once per request, so "destroy" means *end-of-render teardown*: releasing resources such as unsubscribed stores (`unsubscribe_stores`) or other per-request cleanup.
- The server runtime consumes these callbacks when rendering finishes (see the data-flow section below).
- Unlike the client entry, the server version does **not** perform an explicit `lifecycle_outside_component` guard — it is only meaningful inside component initialization, which the context module enforces for context functions via `get_or_init_context_map`.

### 4.2 `createEventDispatcher()` — no-op factory

```javascript
export function createEventDispatcher() {
    return noop;
}
```

Returns the shared `noop` from [internal-shared-utils](internal-shared-utils.md). Component code can therefore call the dispatcher unconditionally; calls are silently dropped because there is no client to receive DOM events during server rendering.

### 4.3 `mount` / `hydrate` / `unmount` — fail-fast stubs

```javascript
export function mount() {
    e.lifecycle_function_unavailable('mount');
}
```

Each stub immediately throws a `Svelte error` carrying the code `lifecycle_function_unavailable` and a documentation link (e.g. `https://svelte.dev/e/lifecycle_function_unavailable`). This converts a would-be silent misconfiguration (running browser bootstrap code in Node) into an immediate, actionable failure.

```mermaid
flowchart TD
    A["Call mount() / hydrate() / unmount() on server"] --> B["lifecycle_function_unavailable(name)"]
    B --> C["Create Error:<br/>'`name(...)` is not available on the server'"]
    C --> D["Set error.name = 'Svelte error'"]
    D --> E["Throw<br/>SSR bootstrap aborts with clear message"]
```

### 4.4 Re-exports

| Re-export | Bound to | Rationale |
|---|---|---|
| `beforeUpdate`, `afterUpdate`, `onMount`, `flushSync` | `noop` | No DOM to patch and no scheduler to flush during SSR. |
| `untrack` | `run` | Server expressions are evaluated once; "tracking" is meaningless, so just invoke the callback. |
| `tick`, `settled` | `async () => {}` | Preserve the awaited-call contract of the client API. |
| `setContext`, `getContext`, `hasContext`, `getAllContexts` | `internal/server/context.js` | Request-scoped context implemented via a `Map` stored on `current_component.c`, chaining to the parent component's map — documented in [context-api](context-api.md). |
| `createRawSnippet` | `internal/server/blocks/snippet.js` | Wraps `fn(...getters).render()` output into `payload.out` — part of the [server-runtime](server-runtime.md) slots/snippets pipeline. |
| `getAbortSignal` | `internal/server/abort-signal.js` | Lazy `AbortController`; the render pipeline aborts it in its `finally` block after `render()` completes. |

## 5. Data Flow: `onDestroy` Registration → Teardown

```mermaid
sequenceDiagram
    participant App as Compiled component code
    participant Entry as index-server.js (onDestroy)
    participant Ctx as internal/server/context.js
    participant RT as Server runtime (render pipeline)

    App->>Entry: onDestroy(cleanupFn)
    Entry->>Ctx: read current_component
    Ctx-->>Entry: component instance
    Entry->>Entry: component.d ??= []
    Entry->>Entry: push(cleanupFn)

    Note over RT: component render completes
    RT->>RT: run registered teardown callbacks<br/>(e.g. unsubscribe_stores releases store subscriptions)
```

The lifecycle of a full server render (from the [server-runtime](server-runtime.md) `render` pipeline) contextualizes when these hooks fire:

```mermaid
flowchart TD
    S["render(component, options)"] --> P["Create Payload<br/>(html/head buffers, css, props id)"]
    P --> CX{"options.context?"}
    CX -->|yes| PUSH["context push / seed map"]
    CX -->|no| EXEC
    PUSH --> EXEC["Execute component function<br/>(runs generated SSR code)"]
    EXEC --> HOOKS["Component init calls onDestroy / setContext /<br/>createRawSnippet via this entry"]
    HOOKS --> OUT["Append markup to payload.out"]
    OUT --> CLEAN["Execute teardown callbacks<br/>(onDestroy hooks, store unsubscription)"]
    CLEAN --> ABORT["Abort signal fired in finally"]
    ABORT --> R["Return { head, html, body }"]
```

## 6. Dependencies

### 6.1 Internal (upstream) dependencies

| Dependency | Module | Used for |
|---|---|---|
| `current_component` | [context-api](context-api.md) (`context-api_server-context`) | Locating the currently initializing component for `onDestroy`. |
| `setContext`, `getContext`, `hasContext`, `getAllContexts` | [context-api](context-api.md) | Re-exported server context API. |
| `noop`, `run` | [internal-shared-utils](internal-shared-utils.md) | No-op lifecycle hooks and `untrack`. |
| `lifecycle_function_unavailable` | `internal/server/errors.js` (message catalog) | Fail-fast stub errors for `mount` / `hydrate` / `unmount`. |
| `createRawSnippet` | [server-runtime](server-runtime.md) (`server-runtime_slots-snippets-and-blocks`) | Raw-snippet SSR support. |
| `getAbortSignal` | [server-runtime](server-runtime.md) (`server-runtime_dev-diagnostics` / abort support) | Render cancellation signals. |

### 6.2 Downstream consumers

- **Compiled server components** — the server transform of the compiler (see [compiler-transformer](compiler-transformer.md)) emits code that imports exactly these names, which is why every name must exist in both entries.
- **Application / framework bootstrap code** — imports `mount`, `hydrate`, etc. from `svelte`; on the server these intentionally fail fast instead of touching the DOM.
- **The render pipeline** ([server-runtime](server-runtime.md)) — consumes the destroy hooks registered through this module and drives context push/pop and abort signaling.

## 7. Design Rationale

1. **Isomorphic import safety.** Sharing one import specifier (`svelte`) across targets eliminates `if (browser)` import switching in user code. Parity of *names* is the contract; parity of *behavior* is explicitly not.
2. **Fail loudly where recovery is impossible.** `mount` / `hydrate` / `unmount` cannot degrade gracefully on the server, so they throw a coded, linkable `Svelte error` rather than misbehaving silently.
3. **Degrade gracefully where a no-op is correct.** Timing hooks (`onMount`, `flushSync`, `tick`) and `createEventDispatcher` genuinely have no work to do during one-shot server rendering; returning no-ops keeps shared component code running unchanged.
4. **Keep real functionality real.** Teardown (`onDestroy`), context propagation, raw snippets, and abort signals *are* meaningful server concepts and are wired to the actual server engine rather than stubbed.
5. **Token-efficiency.** Local logic is limited to `onDestroy` (3 lines) and the three throwing stubs; everything else delegates to single-source-of-truth internal modules, minimizing divergence between entries.

## 8. Related Modules

| Module | Relationship |
|---|---|
| [public-api_client-entry](public-api_client-entry.md) | Client twin: same export names, browser implementations (`mount`/`hydrate`/`unmount` actually mount DOM). |
| [public-api](public-api.md) | Parent module grouping both entries plus `index.d.ts` and HTML typings. |
| [public-api_component-types](public-api_component-types.md) | Type-level surface (`Component`, `Snippet`, `EventDispatcher`) referenced by this entry's JSDoc imports. |
| [server-runtime](server-runtime.md) | The SSR engine this entry fronts: render pipeline, payload/output, attributes/props, slots & snippets, store teardown, dev diagnostics, abort signals. |
| [context-api](context-api.md) | Implements the context API and the `current_component` state consumed by `onDestroy`. |
| [internal-shared-utils](internal-shared-utils.md) | Provides `noop` / `run` backing the no-op re-exports. |
| [compiler-transformer](compiler-transformer.md) | Generates the server component code whose imports this entry must satisfy. |
