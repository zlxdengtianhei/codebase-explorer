# Legacy Compatibility Layer (`legacy-compat`)

## 1. Introduction & Purpose

The `legacy-compat` module is Svelte 5's **backward-compatibility bridge** for Svelte 4 code. The Svelte 5 runtime (signals, fine-grained effects, function components) is fundamentally different from the Svelte 4 runtime (class components, coarse-grained dirty checking, `beforeUpdate`/`afterUpdate`), yet a huge amount of production code still depends on the old model. This module makes the two worlds interoperable through three distinct mechanisms:

1. **Public migration shims** (`svelte/legacy` entry point) — `createClassComponent`, `asClassComponent`, `run`, `handlers`, `createBubbler` and the event-modifier re-exports. These let imperatively-written Svelte 4 code drive Svelte 5 components, and vice versa, *without* a recompile of the calling code.
2. **Runtime emulation hooks** (internal) — functions that the *legacy-mode compiler output* calls: `init` (legacy `onMount`/`beforeUpdate`/`afterUpdate` ordering), coarse-grained `invalidate_inner_signals`, event delegation (`bubble_event`, `add_legacy_event_listener`), `$set` simulation (`update_legacy_props`), and `reactive_import` for module-level reactive imports.
3. **Event modifier substitutes** — higher-order-function replacements for the Svelte 4 `on:click|preventDefault`-style modifiers, which no longer exist as syntax in Svelte 5.

> **Everything in this module is explicitly `@deprecated`.** It exists only to smooth the migration path; the compiler's migrator (`svelte migrate`, part of the Compiler Pipeline & Language Toolchain) rewrites source code away from these APIs. New code should use runes, snippets, callback props and attachments.

**Location in the module tree:** child of `Client_Runtime_Engine (Reactivity & DOM Rendering)`, sibling to `client-reactivity-engine`, `client-dom-renderer`, and `client-dev-tooling`. It sits *on top of* those modules rather than beside them — nearly every shim is a thin translation layer that delegates to the modern reactivity engine and DOM renderer.

---

## 2. Source Layout

| File | Role | Key exports |
|---|---|---|
| `src/legacy/legacy-client.js` | Public `svelte/legacy` client entry | `createClassComponent`, `asClassComponent`, `run`, `handlers`, `createBubbler` + modifier re-exports |
| `src/legacy/legacy-server.js` | Public `svelte/legacy` server condition | `asClassComponent` (adds `.render()`), `createClassComponent` (re-export), `run` (sync), `noop` stand-ins for all event APIs |
| `src/internal/client/legacy.js` | Coarse-grained invalidation | `invalidate_inner_signals`, `captured_signals` |
| `src/internal/client/dom/legacy/lifecycle.js` | Legacy lifecycle ordering | `init` |
| `src/internal/client/dom/legacy/misc.js` | Legacy events/props emulation | `reactive_import`, `bubble_event`, `add_legacy_event_listener`, `update_legacy_props` |
| `src/internal/client/dom/legacy/event-modifiers.js` | Event modifier substitutes | `preventDefault`, `stopPropagation`, `stopImmediatePropagation`, `self`, `trusted`, `once`, `passive`, `nonpassive` |

The two `legacy/` entry points exist because of the dual-condition package exports: server bundles resolve `legacy-server.js` (so client bundles never pull in the SSR runtime), which in turn delegates the class-component machinery to `legacy-client.js`.

---

## 3. Architecture Overview

```mermaid
flowchart TB
    subgraph Public["Public surface — 'svelte/legacy' entry"]
        direction LR
        LB["legacy-client.js<br/>Svelte4Component · createClassComponent<br/>asClassComponent · run · handlers · createBubbler"]
        LS["legacy-server.js (server condition)<br/>.render() · run() sync · noop event shims"]
    end

    subgraph Emulation["Internal emulation hooks (called by legacy-mode compiled output)"]
        direction LR
        LCY["dom/legacy/lifecycle.js<br/>init(immutable)"]
        LEG["internal/client/legacy.js<br/>invalidate_inner_signals"]
        LMOD["dom/legacy/misc.js<br/>reactive_import · bubble_event<br/>add_legacy_event_listener · update_legacy_props"]
        LEV["dom/legacy/event-modifiers.js<br/>preventDefault · self · trusted · once ·<br/>passive · nonpassive · …"]
    end

    subgraph Engine["Client Runtime Engine (parent module)"]
        direction LR
        SRC["reactivity/sources.js<br/>source · mutable_source · set · internal_set"]
        EFF["reactivity/effects.js<br/>user_pre_effect · user_effect"]
        RT["runtime.js<br/>get · untrack · active_effect"]
        BAT["reactivity/batch.js<br/>flushSync"]
        RND["render.js<br/>mount · hydrate · unmount"]
        CTX["context.js<br/>component_context"]
    end

    SSR["Server Runtime<br/>internal/server render()"]
    EVT["dom/elements/events.js<br/>on() (delegated listeners)"]

    LS -->|"delegates class API"| LB
    LS -->|"SSR render"| SSR
    LB --> RND & BAT & CTX
    LB --> SRC & EFF & RT
    LCY --> EFF & RT & CTX
    LEG --> SRC & RT
    LMOD --> SRC & RT
    LEV --> EFF
    LEV --> EVT

    style Public fill:#e8f4fd,stroke:#2b6cb0
    style Emulation fill:#fdf6e3,stroke:#b7791f
    style Engine fill:#e9f7ef,stroke:#276749
```

### Design principles

- **Translation, not reimplementation.** Svelte 4 semantics are *emulated* on top of the signal graph. Example: `$set` becomes `Object.assign` onto a per-key `mutable_source` map; `beforeUpdate` becomes a `user_pre_effect`; `$:` invalidation becomes "capture every signal read, then re-set each one".
- **Opt-in granularity.** Legacy semantics only activate via flags: `legacy_mode_flag` (compilation target), `compatibility.componentApi === 4`, `immutable` props, and the async-mode guard around `flushSync()` in `Svelte4Component`.
- **Single side of the wire.** Event emulation funnels everything through `$$props.$$events` — the same delegation store used by modern `on()` handling — so bubbling behaves identically in both modes.

---

## 4. Sub-modules (detailed docs)

> All sub-module documentation lives alongside this file in the same flat folder. Links use the final generated file names.

### 4.1 [Component API Shims](legacy-compat_component-api-shims.md) — `legacy-compat_component-api-shims.md`

*Files: `src/legacy/legacy-client.js`, `src/legacy/legacy-server.js`*

The public-facing half of the module: the internal `Svelte4Component` bridge class, `createClassComponent`, `asClassComponent` (client + SSR `.render()` variant), `run`, `handlers`, `createBubbler`, and the server-side `noop` strategy. Covers how a Svelte 4-style class instance is *bridged* onto a Svelte 5 component function via a coarse-grained props proxy, delegated `$$events`, instance-export accessor properties, and `mount`/`hydrate`/`unmount` — plus the `flushSync` timing rules and the dual client/server entry-point split.

### 4.2 [Legacy Lifecycle & Invalidation](legacy-compat_legacy-lifecycle.md) — `legacy-compat_legacy-lifecycle.md`

*Files: `src/internal/client/legacy.js`, `src/internal/client/dom/legacy/lifecycle.js`*

The runtime half that legacy-mode compiler output depends on: `init(immutable)` implementing the Svelte 4 `beforeUpdate` → `onMount` → `afterUpdate` ordering with `user_pre_effect`/`user_effect`, signal observation via `component_context.l.s` (populated by `mutable_source` when `legacy_mode_flag` is set, including the immutable identity-check version counter), and `invalidate_inner_signals`'s capture-and-replay invalidation used by `$:` reactive statements.

### 4.3 [Legacy Event & Prop Emulation](legacy-compat_legacy-events-and-props.md) — `legacy-compat_legacy-events-and-props.md`

*Files: `src/internal/client/dom/legacy/event-modifiers.js`, `src/internal/client/dom/legacy/misc.js`*

All event-modifier substitutes (`preventDefault`, `stopPropagation`, `stopImmediatePropagation`, `self`, `trusted`, `once`, `passive`, `nonpassive`) plus the events/props shims: `bubble_event` and `add_legacy_event_listener` (delegation + `$on` simulation), `update_legacy_props` (`$set` simulation via prop setters), and `reactive_import` for reactive module imports. Includes the modifier composition table (HOF vs. action-style) and the `$$events` delegation contract.

---

## 5. Key Data Flows

### 5.1 Bridging a Svelte 4 component instance onto a Svelte 5 component

```mermaid
sequenceDiagram
    autonumber
    participant App as Consumer code (Svelte 4 style)
    participant C4 as Svelte4Component
    participant RT as Client Runtime Engine

    App->>C4: new Svelte4Component({component, target, props, …})
    C4->>C4: build props Proxy — one mutable_source per key (coarse-grained)
    C4->>RT: hydrate()/mount() (component fn, { props, context, intro, recover })
    RT-->>C4: instance exports
    C4->>C4: defineProperty accessors for each export,<br/>attach $set / $destroy, capture $$events
    Note over C4,RT: flushSync() unless async mode,<br/>custom-element ($$host) or sync === false
    App->>C4: $set(props) → Object.assign(props, next)
    C4->>RT: set(source, value) per key → fine-grained downstream updates
    App->>C4: $on(event, cb) → push into $$events[event]
    App->>C4: $destroy() → RT: unmount(instance)
```

Key subtleties:

- The props proxy intentionally uses **per-property version sources** (not the `$state` proxy) because compiled legacy components expect coarse-grained "props object changed" semantics.
- `has()` returns `true` for the internal `LEGACY_PROPS` symbol so the component side doesn't reject the proxy as an "invalid binding" target.
- Export keys (`$set`, `$destroy`, `$on` excepted) become live accessor properties on the wrapper, so `component.someExport()` works unchanged.

### 5.2 Legacy lifecycle ordering (compiled legacy mode)

```mermaid
flowchart TD
    A["legacy component initialises<br/>(compiler emits $.init(immutable))"] --> B["context.l.u callbacks present?"]
    B -- no --> Z["nothing to do"]
    B -- yes --> C["beforeUpdate → user_pre_effect:<br/>observe_all(context, props) + run callbacks.b"]
    C --> D["onMount → user_effect:<br/>(scheduled first so it runs before afterUpdate)"]
    D --> E["afterUpdate → user_effect:<br/>observe_all + run callbacks.a"]
    E --> F{"prop / state change"}
    F --> G{"immutable?"}
    G -- yes --> H["derived version counter —<br/>fires only when prop object identity changes"]
    G -- no --> I["deep_read_state(context.s)<br/>+ get() every signal in context.l.s"]
    H --> J["effect re-runs →<br/>beforeUpdate/afterUpdate replay"]
    I --> J
```

`observe_all` re-reads every signal registered in `context.l.s` — the set that `mutable_source` populates whenever `legacy_mode_flag && component_context.l` — which is what gives `beforeUpdate`/`afterUpdate` their "anything might have changed" semantics.

### 5.3 Event delegation & modifier composition

```mermaid
flowchart LR
    EV["DOM event fires"] --> R["root-level delegated listener<br/>(dom/elements/events.js)"]
    R --> BE["bubble_event($$props, event)<br/>or createBubbler()(type)(event)"]
    BE --> L["$$props.$$events[event.type]<br/>function or function[]"]
    L --> H["user callbacks invoked with<br/>original 'this' preserved"]
    M["modifier chain<br/>$.preventDefault($.once(handler))"] -.-> R
```

Modifiers never touch the DOM event options except through `on(node, type, handler, {passive})` — they are pure higher-order wrappers, which is why the server build can safely replace every one of them with `noop`.

---

## 6. Integration with the Rest of the System

| Direction | Interaction |
|---|---|
| ← **Client Runtime Engine** (parent) | Consumes `mount`/`hydrate`/`unmount` (render), `user_pre_effect`/`user_effect` (effects), `source`/`set`/`mutable_source`/`internal_set` (signal graph), `flushSync` (batching), `component_context` (component stack), `get`/`untrack` (runtime). See the `client-reactivity-engine` and `client-dom-renderer` sub-module docs for the machinery being wrapped. |
| ← **Server-Side Rendering module** | `legacy-server.js` calls the server `render()` to implement the Svelte 4 `Component.render()` API (returning `{ html, head, css: {code: '', map: null} }`). |
| ← **Compiler Pipeline** | The compiler, when a component compiles without runes (or with `compatibility.componentApi === 4`), emits calls directly into the internal hooks: `$.init`, `$.bubble_event`, `$.reactive_import`, `$.add_legacy_event_listener`, `$.update_legacy_props`, and modifier wrappers. Compiled `$:` statements use `legacy_pre_effect`/`legacy_pre_effect_reset` from the reactivity engine; the public `run()` provides the same semantics for hand-migrated code. |
| ↔ **Compiler migrator** | `svelte migrate` (compiler `migrate/`) rewrites legacy syntax (slots, events, `on:`, class components) so consumers can eventually drop these shims. |
| ← **flags** | `legacy_mode_flag`, `async_mode_flag`, and DEV guard behaviour across the module (e.g. recursive `$:` warning with component filename). |

---

## 7. Deprecation & Migration Notes

- **Every export is `@deprecated`.** The docs consistently frame them as *temporary migration aids*.
- `run(fn)` deviates deliberately from `$effect.pre`: if the effect is re-dirtied synchronously, its status is downgraded to `MAYBE_DIRTY` (plus a `legacy_recursive_reactive_block` warning in DEV naming the offending file) to emulate Svelte 4's recursive reactive statements. The server version simply runs `fn()` once.
- `handlers(...)` re-throws handler errors via `queueMicrotask` so one failing Svelte 4 handler cannot prevent later handlers in the chain (matching old event semantics).
- `createBubbler` requires an active component context and throws `lifecycle_outside_component` otherwise.
- `update_legacy_props` only works with **component accessors** enabled; it cannot update `$$props`/`$$restProps`.
- The `svelte/legacy` server entry intentionally returns empty CSS (`{ code: '', map: null }`) from `.render()` — CSS extraction no longer happens at runtime in Svelte 5.

## 8. Quick Reference

| Svelte 4 concept | legacy-compat provider | Modern replacement |
|---|---|---|
| `new Component({ target, props })` | `createClassComponent` | `mount()` |
| `Component` used as class | `asClassComponent` | — (function components) |
| `$set` / `$on` / `$destroy` | `Svelte4Component` methods / `add_legacy_event_listener` / `update_legacy_props` | props, callback props, `unmount()` |
| `$: statement` | `run` (public) / `invalidate_inner_signals`, `legacy_pre_effect` (compiled) | `$derived`, `$effect` |
| `beforeUpdate` / `afterUpdate` / `onMount` ordering | `init` | `$effect.pre` / `$effect` / `onMount` |
| `on:click\|preventDefault\|once` | modifier HOFs | inline code in handlers, attachments/actions |
| `on:click` (no handler, forward) | `createBubbler` / `bubble_event` | `onclick={...}` callback props |
| `Component.render()` SSR | `legacy-server.asClassComponent.render` | server `render()` |
