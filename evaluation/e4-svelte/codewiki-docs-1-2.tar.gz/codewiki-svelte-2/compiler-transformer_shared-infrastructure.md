# compiler-transformer_shared-infrastructure

**Module files:**
- `packages/svelte/src/compiler/phases/3-transform/types.d.ts` — `TransformState`
- `packages/svelte/src/compiler/phases/3-transform/utils.js` — shared transform utilities

---

## 1. Overview

`compiler-transformer_shared-infrastructure` is the **common foundation of Phase 3 (code generation)** of the Svelte compiler. Every `.svelte` component is ultimately lowered to JavaScript along one of two targets — a hydrated client runtime bundle or an SSR (server) render function — and both lowering passes are built on top of the exact same pieces this module provides:

1. **`TransformState`** — the base state object threaded through the `zimmerframe` AST walk by every client and server visitor. It carries the Phase-2 analysis results, validated compile options, and the lexical-scope information visitors need to resolve identifiers and generate unique names.
2. **`utils.js`** — target-agnostic helpers that both transform passes call: fragment-child normalization (`clean_nodes`), HTML/SVG/MathML namespace inference, legacy `{@const}` ordering, hoisted-function detection, and `$inspect` rune lowering.

By centralizing these concerns, the [client transform](compiler-transformer_client-transform.md) and [server transform](compiler-transformer_server-transform.md) stay symmetric: they differ in *what* they emit (template clone blocks vs. HTML string templates), but share *how* they traverse, normalize, and interpret the component AST.

> This module is a child of [compiler-transformer](compiler-transformer.md), alongside its sibling output passes. It consumes types from [compiler-core_type_definitions](compiler-core_type_definitions.md), diagnostics from [compiler-core_diagnostics](compiler-core_diagnostics.md), and scope machinery from [compiler-analyzer_scope](compiler-analyzer_scope.md).

---

## 2. Positioning in the Compiler Pipeline

The module sits at the seam between analysis (Phase 2) and code generation (Phase 3). Analysis *produces* the data that `TransformState` wraps; both output passes *consume* it.

```mermaid
flowchart TB
    subgraph P1["Phase 1 — Parse ([compiler-parser](compiler-parser.md))"]
        AST["Template + JS AST"]
    end

    subgraph P2["Phase 2 — Analyze ([compiler-analyzer](compiler-analyzer.md))"]
        AN["Analysis, scopes map,<br/>bindings, hoisting metadata,<br/>state fields"]
    end

    subgraph P3S["Phase 3 — Shared infrastructure (this module)"]
        TS["TransformState<br/>(types.d.ts)"]
        U["utils.js:<br/>clean_nodes · infer_namespace<br/>sort_const_tags · transform_inspect_rune<br/>is_hoisted_function · determine_namespace_for_children"]
    end

    subgraph P3C["Phase 3 — Client output ([compiler-transformer_client-transform](compiler-transformer_client-transform.md))"]
        CV["client/visitors/*<br/>(template clone + reactive effects)"]
    end

    subgraph P3V["Phase 3 — Server output ([compiler-transformer_server-transform](compiler-transformer_server-transform.md))"]
        SV["server/visitors/*<br/>(HTML string templates)"]
    end

    AST --> P2
    AN -->|"seeds initial state"| TS
    TS --> CV
    TS --> SV
    U --> CV
    U --> SV
    CV --> OUT1["Client JS (reactivity + DOM)"]
    SV --> OUT2["Server JS (SSR)"]
```

The CSS pass ([compiler-transformer_css-transform](compiler-transformer_css-transform.md)) runs in parallel and does **not** consume `TransformState`; it operates on the CSS AST produced during analysis.

---

## 3. `TransformState` — the shared state contract

`TransformState` is the immutable "context state" that `zimmerframe` threads through every visitor call. Both output passes define their own entry states by extending it, and visitors derive per-subtree states via object spread (e.g. `{ ...context.state, in_derived: true }`) — the base fields are always preserved.

### 3.1 Fields

| Field | Type | Origin | Purpose |
|---|---|---|---|
| `analysis` | `Analysis` | Phase 2 analyzer | Whole-component facts: `runes` / legacy mode, `immutable`, `tracing`, module & instance JS, comments, `classes` → `StateField` map, `accessors`, `async_deriveds`. Read constantly (e.g. `clean_nodes` checks `analysis.runes` to decide legacy compat behavior). |
| `options` | `ValidatedModuleCompileOptions` | `compile()` entry → validated by `validate-options.js` (see [compiler-core_options_validation](compiler-core_options_validation.md)) | Validated options such as `generate`, `dev`, `hmr`, `preserveComments`. Read-only after validation. |
| `scope` | `Scope` | Restored during the walk via `set_scope` (see [compiler-analyzer_scope](compiler-analyzer_scope.md)) | Current lexical scope: identifier→`Binding` resolution, unique name generation, static expression evaluation. |
| `scopes` | `Map<AST.SvelteNode, Scope>` | Phase 2 analyzer | Node→scope lookup table. `set_scope` consults it so the walker re-establishes the correct scope on every descent (this module itself uses it inside `sort_const_tags`). |
| `state_fields` | `Map<string, StateField>` | Phase 2 | Class `$state` fields keyed by name, used when transforming class components / constructors. |

### 3.2 Type hierarchy

`ClientTransformState` and `ServerTransformState` extend the base contract with target-specific fields; the component-level variants add per-fragment accumulation buffers used during template emission.

```mermaid
classDiagram
    class TransformState {
        <<interface>>
        +Analysis analysis
        +ValidatedModuleCompileOptions options
        +Scope scope
        +Map~AST.SvelteNode, Scope~ scopes
        +Map~string, StateField~ state_fields
    }
    class ClientTransformState {
        <<interface>>
        +boolean in_constructor
        +boolean in_derived
        +boolean is_instance
        +Record~string, Transform~ transform
    }
    class ComponentClientTransformState {
        +List~Statement~ hoisted
        +List~Statement~ init
        +List~Statement~ update
        +List~Statement~ after_update
        +Template template
        +Memoizer memoizer
    }
    class ServerTransformState {
        <<interface>>
        +Map~LabeledStatement, Statement~ legacy_reactive_statements
    }
    class ComponentServerTransformState {
        +List~Statement~ init
        +List~string~ template
        +boolean skip_hydration_boundaries
    }

    TransformState <|.. ClientTransformState : extends
    TransformState <|.. ServerTransformState : extends
    ClientTransformState <|.. ComponentClientTransformState : extends
    ServerTransformState <|.. ComponentServerTransformState : extends
```

- `ClientTransformState.transform` maps state identifiers to rewriter functions (`read` / `assign` / `mutate` / `update`) that turn source expressions like `foo++` into `$.update(foo)`-style runtime calls.
- `ServerTransformState.legacy_reactive_statements` collects `$:` statements so they can be dependency-ordered at the end of the server render function.
- The component-level variants are created by the `Fragment` / `Component` visitors of each pass (see §5).

---

## 4. Shared utilities (`utils.js`)

| Function | Export | Purpose | Main consumers |
|---|---|---|---|
| `is_hoisted_function(node)` | ✅ | Reports whether the analyzer flagged a function node with `metadata.hoisted`, meaning it is safe to emit once at component init instead of inline. | Event-handler / directive construction in the client transform (avoids re-wrapping already-hoisted callbacks). |
| `clean_nodes(parent, nodes, path, namespace, state, preserve_whitespace, preserve_comments)` | ✅ | The canonical normalization step for any node list: legacy `{@const}` ordering, hoisting partition, whitespace policy, hydration-sensitive special cases. Returns `{ hoisted, trimmed, is_standalone, is_text_first }`. | `Fragment` visitors of both client and server transforms (and block visitors that process children lists). |
| `sort_const_tags(nodes, state)` | internal | Svelte-4-compatibility: topologically orders `{@const}` declarations when **not** in runes mode. | called by `clean_nodes` |
| `infer_namespace(namespace, parent, nodes)` | ✅ | Derives the `html` / `svg` / `mathml` namespace for the children of a node. | `Fragment` visitors of both transforms |
| `check_nodes_for_namespace(nodes, namespace)` | internal | Heuristic walk backing `infer_namespace` for namespace-resetting containers. | internal |
| `determine_namespace_for_children(node, namespace)` | ✅ | Namespace of a specific element's children (checks `foreignObject`, `metadata.svg`, `metadata.mathml`). | element visitors (`RegularElement`, `SvelteElement`) |
| `transform_inspect_rune(node, context)` | ✅ | Lowers `$inspect(...)` / `$inspect(...).with(...)` into a `$.inspect` runtime call — dev mode only; a no-op in production builds. | `CallExpression` rune handling in both transforms |

### 4.1 `clean_nodes` — child-list normalization

`clean_nodes` is the most consequential helper: every fragment/body children list passes through it before visitors emit code. Its decisions directly affect hydration correctness and rendered whitespace.

```mermaid
flowchart TD
    START(["clean_nodes(parent, nodes, path, namespace, state, preserve_whitespace, preserve_comments)"]) --> LEGACY{"state.analysis.runes?"}
    LEGACY -- "no → legacy mode" --> SORT["sort_const_tags:<br/>topologically order {@const} declarations"]
    LEGACY -- "yes" --> PART
    SORT --> PART["Partition children:<br/>hoisted = ConstTag · DebugTag · SnippetBlock ·<br/>SvelteWindow / SvelteBody / SvelteDocument ·<br/>SvelteHead · TitleElement<br/>regular = everything else<br/>(Comments dropped unless preserve_comments)"]
    PART --> TRIM{"preserve_whitespace?"}
    TRIM -- "yes" --> PRE
    TRIM -- "no" --> WS["Whitespace policy:<br/>· trim leading/trailing whitespace-only text<br/>· collapse inner whitespace to a single space<br/>· drop entirely inside whitespace-insensitive parents<br/>(select, table/tr/tbody/thead/tfoot, colgroup,<br/>datalist, svg text)"]
    WS --> PRE["'pre' special case:<br/>discard a leading single newline<br/>(the browser would strip it anyway)"]
    PRE --> SCRIPT{"trimmed is a lone 'script' element?"}
    SCRIPT -- "yes" --> ANCHOR["Append an empty Comment anchor<br/>so run_scripts can node.replaceWith() it"]
    SCRIPT -- "no" --> RESULT
    ANCHOR --> RESULT["Return { hoisted, trimmed,<br/>is_standalone, is_text_first }"]
```

The returned flags enable anchor optimizations:

- **`is_standalone`** — the single remaining child is a non-dynamic `<RenderTag />` (snippet render) or a non-dynamic component without `--style` props and without HMR; the child can render directly into the *parent block's anchor* instead of allocating a new one.
- **`is_text_first`** — the block starts with text/expression content; callers must insert an anchor comment (client: `$.next()` skip; server: `<!---->` separator) so the text node cannot be fused with surrounding fragments during hydration.

### 4.2 `sort_const_tags` — legacy `{@const}` ordering (Svelte 4 behavior)

Runes mode evaluates `{@const}` in source order, but Svelte 4 computed const declarations in dependency order. This helper reproduces that behavior only when `analysis.runes` is `false`.

```mermaid
flowchart TD
    A["Walk each ConstTag declaration<br/>(zimmerframe walk + set_scope,<br/>is-reference filters real identifier references)"] --> B["Map each declared binding<br/>→ { node, deps: Set of Binding }"]
    B --> C["Build binding dependency edges<br/>(tag → tag)"]
    C --> D{"check_graph_for_cycles<br/>(reused from compiler-analyzer)<br/>finds a cycle?"}
    D -- "yes" --> E["Throw const_tag_cycle via<br/>compiler-core_diagnostics<br/>(message lists the binding cycle a → b → a)"]
    D -- "no" --> F["DFS topological sort:<br/>deps always emitted before dependents"]
    F --> G["Return sorted ConstTags,<br/>all other nodes appended unchanged"]
```

Note the deliberate reuse of `check_graph_for_cycles` from the [compiler-analyzer](compiler-analyzer.md) utility belt and of `set_scope` from [compiler-analyzer_scope](compiler-analyzer_scope.md) — the scopes map inside `TransformState` is what makes correct scope-resolved dependency extraction possible during a transform-phase walk.

### 4.3 Namespace inference (`infer_namespace` / `determine_namespace_for_children`)

Templates can mix HTML, SVG and MathML content. The transform must pick the right serialization (`from_html` vs `from_svg` vs `from_mathml` templates on the client; escaping behavior on the server).

```mermaid
flowchart TD
    A["infer_namespace(current, parent, nodes)"] --> B{"parent is 'foreignObject'?"}
    B -- "yes" --> HTML["html"]
    B -- "no" --> C{"parent element metadata"}
    C -- "metadata.svg" --> SVG["svg"]
    C -- "metadata.mathml" --> MATH["mathml"]
    C -- "plain element" --> D{"Parent resets namespace?<br/>Fragment · Root · Component ·<br/>SvelteComponent · SvelteFragment ·<br/>SnippetBlock · SlotElement"}
    D -- "yes" --> E["check_nodes_for_namespace walk:<br/>any non-svg/mathml element ⇒ html;<br/>non-empty text ⇒ maybe_html"]
    D -- "no" --> F["Scan sibling RegularElements:<br/>agreed svg/mathml namespace or<br/>any plain element ⇒ html"]
    E --> G{"unambiguous result?<br/>(not 'keep' / 'maybe_html')"}
    F --> G
    G -- "yes" --> SAME["use derived namespace"]
    G -- "no" --> FALL["keep the incoming namespace"]
```

`determine_namespace_for_children` is the element-level variant used while emitting an element's opening machinery: `foreignObject` forces `html`, otherwise the element's own svg/mathml metadata decides.

### 4.4 `transform_inspect_rune` — dev-only `$inspect` lowering

- Returns `b.empty` unless the [compiler-core_compile_state](compiler-core_compile_state.md) `dev` flag is set — `$inspect` compiles away in production.
- Wraps each argument through the shared `visit` machinery, then emits `$.inspect(args, withArg?)` from the client runtime.
- The two targets differ slightly: on the client (`options.generate === 'client'`) the inspected arguments are passed as a **thunk** (`() => [...]`) so values are re-read on each run; on the server they are passed as a plain array.

Both `CallExpression` visitors route `$inspect` and `$inspect().with` through this single implementation, guaranteeing identical semantics across targets.

---

## 5. Component interaction — a `Fragment` visit

The clearest view of how client and server visitors cooperate with this module is the `Fragment` visit, which both passes implement with the same three shared calls:

```mermaid
sequenceDiagram
    participant W as zimmerframe walk
    participant FV as Fragment visitor (client or server)
    participant U as shared utils.js (this module)
    participant ST as TransformState

    W->>FV: visit(Fragment, state)
    FV->>ST: read current namespace
    FV->>U: infer_namespace(namespace, parent, node.nodes)
    U-->>FV: 'html' | 'svg' | 'mathml'
    FV->>U: clean_nodes(parent, node.nodes, path, namespace, state, preserve_whitespace, options.preserveComments)
    U->>ST: analysis.runes, scope, options, scopes (via set_scope)
    U-->>FV: { hoisted, trimmed, is_standalone, is_text_first }
    FV->>FV: create derived state spread<br/>(client: init/update/template/memoizer;<br/>server: init/template/skip_hydration_boundaries)
    FV->>W: visit(hoisted nodes, derived state)
    FV->>W: visit(trimmed nodes, derived state)<br/>using is_standalone / is_text_first anchors
    W-->>FV: emitted block
```

Typical divergence after the shared calls:

- **Client** (`compiler-transformer_client-transform`): builds a hoisted `$.from_html(...)` template plus init/update/after-update statement buckets, and may reuse the parent anchor when `is_standalone`.
- **Server** (`compiler-transformer_server-transform`): appends to an HTML string template; `is_standalone` sets `skip_hydration_boundaries` and `is_text_first` injects a `<!---->` separator. Text/expression runs are batched into templates by `process_children` (documented in the server-transform module).

---

## 6. Dependencies

### 6.1 What this module depends on

```mermaid
flowchart LR
    subgraph THIS["this module"]
        TS["types.d.ts<br/>TransformState"]
        U["utils.js"]
    end

    TS --> AN["phases/types.js Analysis<br/>(produced by compiler-analyzer)"]
    TS --> SC["compiler-analyzer_scope<br/>(Scope, set_scope)"]
    TS --> OPT["compiler-core_options_validation<br/>(ValidatedModuleCompileOptions)"]
    TS --> TD["compiler-core_type_definitions<br/>(AST, StateField)"]

    U --> BL["compiler-core_ast_builders<br/>(#compiler/builders: b.call, b.array, b.thunk, b.empty)"]
    U --> DG["compiler-core_diagnostics<br/>(e.const_tag_cycle)"]
    U --> CS["compiler-core_compile_state<br/>(dev flag)"]
    U --> SC
    U --> CYC["compiler-analyzer<br/>(check_graph_for_cycles)"]
    U --> PAT["compiler-core<br/>(phases/patterns.js regexes,<br/>utils/ast.js extract_identifiers)"]
    U --> ZF["external: zimmerframe (walk)"]
    U --> IR["external: is-reference"]
```

### 6.2 Who depends on this module

| Consumer | Uses |
|---|---|
| [compiler-transformer_client-transform](compiler-transformer_client-transform.md) | `TransformState` (via `ClientTransformState` / `ComponentClientTransformState`), `clean_nodes`, `infer_namespace`, `determine_namespace_for_children`, `transform_inspect_rune`, `is_hoisted_function` |
| [compiler-transformer_server-transform](compiler-transformer_server-transform.md) | `TransformState` (via `ServerTransformState` / `ComponentServerTransformState`), `clean_nodes`, `infer_namespace`, `transform_inspect_rune` |
| Transform entry points (`client/index.js`, `server/index.js`) | construct the initial state from `Analysis` + validated options, then start the walk |

---

## 7. End-to-end data flow

```mermaid
flowchart LR
    SRC[".svelte source"] --> PARSE["1-parse"]
    PARSE --> ASTD["AST + scopes + bindings"]
    ASTD --> ANALYZE["2-analyze visitors<br/>(compiler-analyzer)"]
    ANALYZE --> ANA["Analysis"]
    ANA --> ENTRY["transform entry:<br/>state = { analysis, options, scope,<br/>scopes, state_fields }"]
    ENTRY --> WALK["zimmerframe walk<br/>(set_scope restores scope per node)"]
    WALK --> CLI["client pass →<br/>reactive client component"]
    WALK --> SRV["server pass →<br/>SSR render function"]
    CLI --> RUN["Client runtime engine"]
    SRV --> RUN2["Server runtime services"]
```

At runtime, the generated code hands off to entirely different modules — see [Client Runtime Engine (Reactivity & DOM Rendering)](client-runtime-engine_reactivity-dom-rendering.md) and [Server-Side Rendering & Cross-Target Runtime Services](server-side-rendering-cross-target-runtime-services.md).

---

## 8. Design notes & invariants

1. **Immutable state threading.** Visitors never mutate shared state; they create spread-derived copies (`{ ...context.state, ... }`). Base fields in `TransformState` are `readonly`, so derived states can be safely discarded when leaving a subtree.
2. **Single source of truth for normalization.** Because *both* output passes call `clean_nodes`, client and server agree on whitespace, hoisting, and anchor semantics — a precondition for hydration, where the server HTML must match the client's template clones exactly.
3. **Legacy compatibility is quarantined.** Svelte-4 behaviors (`sort_const_tags`, topological `{@const}` evaluation) only activate when `analysis.runes === false`, keeping the runes pipeline free of compat branches.
4. **Namespace correctness is metadata-driven.** All namespace decisions read `metadata.svg` / `metadata.mathml` flags computed during analysis; the transform phase performs no raw string sniffing.
5. **Errors flow through the shared diagnostics module.** Cycle detection in `sort_const_tags` raises `const_tag_cycle` with a formatted cycle path (`a → b → a`), which [compiler-core_diagnostics](compiler-core_diagnostics.md) turns into a code frame via `get_code_frame`.
6. **Dev-only instrumentation is centralized.** `$inspect` lowering checks the `dev` compile-state flag in one place, so production output contains no inspection machinery on either target.

---

## 9. Related modules

- [compiler-transformer](compiler-transformer.md) — parent module grouping all Phase-3 passes
- [compiler-transformer_client-transform](compiler-transformer_client-transform.md) — primary consumer (structure, directives, expression visitors)
- [compiler-transformer_server-transform](compiler-transformer_server-transform.md) — primary consumer (SSR templates)
- [compiler-transformer_css-transform](compiler-transformer_css-transform.md) — sibling CSS pass (independent state)
- [compiler-analyzer](compiler-analyzer.md) / [compiler-analyzer_scope](compiler-analyzer_scope.md) — produces `Analysis`, scopes, bindings, hoisting metadata
- [compiler-core](compiler-core.md) — builders, diagnostics, compile state, AST builders, type definitions
- [compiler-parser](compiler-parser.md) — upstream producer of the AST this module reshapes
