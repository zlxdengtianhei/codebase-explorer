# Sources & Proxies (`client-reactivity-engine_sources-and-proxies`)

## 1. Overview

This module implements the **write side of the signal graph** and the **deep-reactivity layer** of Svelte's client runtime. It consists of two tightly coupled files:

| File | Responsibility |
|---|---|
| `packages/svelte/src/internal/client/reactivity/sources.js` | Creation of *source signals* (`source`, `state`, `mutable_source`) and every path that writes to them (`set`, `internal_set`, `mutate`, `update`, `update_pre`, `increment`), plus downstream dirty propagation (`mark_reactions`). |
| `packages/svelte/src/internal/client/proxy.js` | The `proxy()` factory that wraps plain objects/arrays in a `Proxy` whose property reads/writes are translated into signal reads/writes, lazily materializing one source per property. Also provides dev-only identity/label tooling (`update_path`, `get_label`, `tag_proxy` integration) and proxy unwrapping (`get_proxied_value`, `is`). |

Everything a Svelte component mutates at runtime ultimately flows through this module: `$state` variables are sources, `$state` objects/arrays are proxies, and operators like `count++` compile to `update()`/`update_pre()` calls defined here.

**Core components documented in depth:**

- [`sources.js::update`](#5-update--update_pre-postfix-incrementdecrement) — implements `x++` / `x--`
- [`sources.js::update_pre`](#5-update--update_pre-postfix-incrementdecrement) — implements `++x` / `--x`
- [`proxy.js::update_path`](#8-update_path--dev-path-relabeling) — dev-only debug-path relabeling for proxies

## 2. Position in the system

This module is a child of the **client-reactivity-engine** (the `packages/svelte/src/internal/client/` runtime). It sits between the compiled component code (which is produced by the [Compiler Pipeline & Language Toolchain](Compiler_Pipeline___Language_Toolchain.md)) and the effect scheduler that flushes updates to the DOM.

```mermaid
flowchart LR
    C["Compiler output<br/>(compiled .svelte components)"] -->|"$.state(), $.set(),<br/>$.update(), $.proxy()"| SP["sources-and-proxies<br/>(this module)"]
    SP -->|"mark_reactions →<br/>schedule_effect"| BS["Batch & scheduler<br/>(see client-reactivity-engine_batching-scheduling)"]
    BS -->|"flushes dirty effects"| EFF["Effects<br/>(see client-reactivity-engine_effects)"]
    EFF -->|"reads values via get()"| SG["Signal graph core<br/>(see client-reactivity-engine_signal-graph)"]
    EFF -->|"re-runs template code"| DOM["DOM renderer<br/>(see client-dom-renderer)"]
```

Sibling sub-modules of the reactivity engine build directly on top of this one:

- [client-reactivity-engine_signal-graph.md](client-reactivity-engine_signal-graph.md) — owns `get()`, reaction tracking and signal status flags; this module calls into it on every read and write.
- [client-reactivity-engine_batching-scheduling.md](client-reactivity-engine_batching-scheduling.md) — `Batch.ensure()` / `schedule_effect()` used by every write.
- [client-reactivity-engine_deriveds-and-async.md](client-reactivity-engine_deriveds-and-async.md) — `execute_derived()`, called when a dirty derived is written to.
- [client-reactivity-engine_props-and-stores.md](client-reactivity-engine_props-and-stores.md) — `prop()`, `store_get()` etc. are built from `mutable_source()` + `set()`.
- [client-reactivity-engine_foundation.md](client-reactivity-engine_foundation.md) — `equality.js` (used by every source) and compile-time `flags`.

## 3. Architecture

```mermaid
flowchart TB
    subgraph SRC["sources.js — value sources and write paths"]
        direction TB
        F["Factories<br/>source() · state() · mutable_source()"]
        W["Public writers<br/>set() · mutate()"]
        U["Arithmetic writers<br/>update() · update_pre() · increment()"]
        IS["internal_set()<br/>(single write choke point)"]
        MR["mark_reactions()<br/>recursive dirty propagation"]
        DEV["Dev instrumentation<br/>inspect_effects · old_values<br/>flush_inspect_effects()"]
        F -->|"creates Source signals"| IS
        W --> IS
        U --> IS
        IS --> MR
        IS --> DEV
    end

    subgraph PX["proxy.js — deep reactivity"]
        direction TB
        P["proxy()"]
        T["Proxy traps<br/>get · set · has · ownKeys · deleteProperty<br/>defineProperty · getOwnPropertyDescriptor"]
        V["Internal signals<br/>version source · length source<br/>per-property sources Map"]
        UP["update_path()<br/>(dev label renames)"]
        P --> T
        T --> V
        UP -.->|"retags labels"| V
    end

    T -->|"get(s) / set(s, v)"| W
    T -->|"increment(version)"| U
    W -->|"tag_proxy(value, label)"| UP
    MR -->|"schedule_effect()<br/>eager_block_effects"| BS["Batch & scheduler<br/>(batching-scheduling module)"]
```

The two files form a loop: **proxies materialize sources** (one per object property, plus a `version` source per object) and **every source write funnels through `internal_set()`**, which batches the change, bumps the write version and propagates dirtiness to dependent reactions.

## 4. Signal sources — the creation API

A source signal is a minimal mutable cell described by the `Signal` interface (`reactivity/types.d.ts`: flags `f`, write version `wv`) extended with the current value and downstream bookkeeping:

```js
{
  f: 0,            // flags bitmask (CLEAN/DIRTY/DERIVED/...)
  v,               // current value
  reactions: null, // list of downstream reactions (effects/deriveds/proxies)
  equals,          // equality function (see foundation module)
  rv: 0,           // last read version (GC optimization in get())
  wv: 0            // write version, bumped on every change
}
```

| Factory | Behavior |
|---|---|
| `source(v, stack)` | Plain source with strict `===` equality (`equals`). In dev tracing mode records `created`/`updated` stacks, `set_during_effect` and `trace`. |
| `state(v, stack)` | `source()` plus `push_reaction_value(s)` — registers the new signal on the active reaction so it is reclaimed with its owning effect. Annotated `/*#__NO_SIDE_EFFECTS__*/` for tree-shaking. This is the lowering target of the `$state` rune. |
| `mutable_source(v, immutable = false, trackable = true)` | Uses `safe_equals` (any object/array/function assignment counts as a change — legacy mutation semantics) unless `immutable` is set. In `legacy_mode_flag`, the source is registered in `component_context.l.s` so legacy `beforeUpdate`/`afterUpdate` invalidation ([legacy-compat](legacy-compat.md)) can find it. |

## 5. `update` / `update_pre` — postfix and prefix increment/decrement

The compiler lowers `count++`, `count--`, `++count` and `--count` on reactive values to these two helpers. They exist to preserve **JavaScript evaluation-order semantics** (which value the surrounding expression observes) while still performing a fully tracked, batched write.

```js
export function update(source, d = 1) {        // x++ / x--
  var value = get(source);
  var result = d === 1 ? value++ : value--;    // result = OLD value
  set(source, value);
  return result;                               // postfix semantics
}

export function update_pre(source, d = 1) {   // ++x / --x
  var value = get(source);
  return set(source, d === 1 ? ++value : --value); // returns NEW value
}
```

Key properties:

1. **Read through `get(source)`** — the read participates in dependency tracking exactly like a manual read: the enclosing effect/derived registers (or keeps) its dependency edge, and for deriveds the value is resolved lazily. This matters for self-referential expressions such as `$effect(() => x++)`.
2. **Write through `set()`** — the new value passes through all guards and the full `internal_set()` pipeline (batching, versioning, propagation). It is *not* a raw mutation.
3. **Return-value fidelity** — `update()` returns the pre-write value, `update_pre()` returns the post-write value, mirroring JS postfix/prefix operators so compiled expressions like `arr[i++]` or `f(++x)` behave identically to source.
4. **Direction flag** — `d = 1` increments, `d = -1` decrements.

Related helpers in the same write family:

| Helper | Semantics |
|---|---|
| `increment(source)` | `set(source, source.v + 1)` **without** calling `get()` — silently bypasses dependency registration. Used internally by `proxy()` to bump its `version` source on key-set changes. |
| `mutate(source, value)` | Untracked read + `set()` — the lowering of legacy-style in-place mutation (`$.mutate`). |

## 6. Write path — `set()` and `internal_set()`

All writes — from `update()`, from compiled assignments (`$.set`), and from proxy traps — converge on `internal_set()`, the single choke point of the module.

```mermaid
sequenceDiagram
    autonumber
    participant App as Compiled code / Proxy trap
    participant U as update / update_pre / set
    participant IS as internal_set
    participant EQ as equality.js
    participant B as Batch (batching-scheduling)
    participant MR as mark_reactions
    participant E as Scheduled effects

    App->>U: write (x++, ++x, assignment, trap)
    U->>U: guard: state_unsafe_mutation check
    U->>IS: set(source, value[, should_proxy])
    IS->>EQ: source.equals(value)
    alt equal → no-op
        EQ-->>IS: true
    else different
        EQ-->>IS: false
        IS->>IS: old_values.set(source, old/new)
        IS->>B: Batch.ensure().capture(source, old)
        Note over B: current/previous value snapshot<br/>for time-travelling async batches
        IS->>IS: wv = increment_write_version()
        IS->>MR: mark_reactions(source, DIRTY)
        MR->>E: set_signal_status + schedule_effect per reaction
        IS->>IS: untracked_writes bookkeeping (self-scheduling effects)
    end
    Note over E: effects actually run later,<br/>during the batch flush (microtask)
```

**Safety guard in `set()`** — raises `state_unsafe_mutation` when state is written while the active reaction is a `DERIVED`, `BLOCK_EFFECT`, `ASYNC` reaction or `INSPECT_EFFECT` (even under `untrack()` for inspect effects), unless the source is currently in the reaction's `current_sources` (i.e. it is being read by the very expression performing the write, as in `count = count + 1`).

**`internal_set()` responsibilities, in order:**

1. **Equality short-circuit** — no-op when the value is unchanged (strict `===` for normal sources; `safe_equals` for mutable sources).
2. **`old_values` bookkeeping** — the module-level `Map<Source, any>` preserves values across effect teardown: normal writes store the *previous* value; writes performed *while* `is_destroying_effect` store the *new* value. `get()` in the [signal-graph](client-reactivity-engine_signal-graph.md) module serves these values to cleanup functions so teardown code observes a consistent snapshot.
3. **Batch capture** — `Batch.ensure()` guarantees a batch exists and `batch.capture()` snapshots previous/current values so concurrent async batches can "time travel" (see [client-reactivity-engine_batching-scheduling.md](client-reactivity-engine_batching-scheduling.md)).
4. **Dev tracing** — in tracing mode (or any in-effect write) records an `UpdatedAt` stack on the signal (aggregated with hit counts) and flags `set_during_effect` for `$inspect.trace` diagnostics.
5. **Derived status fix-up** — if the target is a `Derived` that is currently `DIRTY`, it is eagerly re-executed (`execute_derived()`) to refresh its dependency list, then set to `CLEAN` (or `MAYBE_DIRTY` if unowned). See [client-reactivity-engine_deriveds-and-async.md](client-reactivity-engine_deriveds-and-async.md).
6. **Write version bump** — `increment_write_version()` establishes a global happens-after ordering used by `get()`'s caching.
7. **`mark_reactions(source, DIRTY)`** — downstream propagation (below).
8. **`untracked_writes`** — if a *clean*, non-branch/root effect writes to state while running, the source is recorded so the effect is re-scheduled after it finishes (supports `$effect(() => x++)` without infinite synchronous recursion).
9. **Inspect flushing** — in dev, pending `$inspect` effects are flushed immediately after the write (unless deferred by an array-mutating method, see §7.4).

### 6.1 Dirty propagation — `mark_reactions()`

```mermaid
flowchart TD
    A["mark_reactions(signal, status)"] --> B{"signal.reactions?"}
    B -- "null" --> Z["return"]
    B -- "list" --> C{"for each reaction"}
    C -->|"legacy mode && reaction === active_effect"| C
    C -->|"DEV && INSPECT_EFFECT"| D["add to inspect_effects set"]
    C -->|"already DIRTY"| E["skip status write"]
    C -->|"otherwise"| F["set_signal_status(reaction, DIRTY / MAYBE_DIRTY)"]
    F -->|"reaction is DERIVED"| G["recurse with MAYBE_DIRTY"]
    F -->|"reaction is effect"| H{"BLOCK_EFFECT?"}
    H -- yes --> I["push to eager_block_effects"]
    H -- no --> J["schedule_effect(reaction)"]
    I --> J
```

Two details worth noting:

- Derived chains are walked recursively but only *marked* (`MAYBE_DIRTY`) — they are evaluated lazily when read, keeping deriveds pull-based.
- `BLOCK_EFFECT`s (template blocks such as `each`/`if`) are pushed into `eager_block_effects` so the scheduler can process them with priority; actual execution order is owned by the [batching-scheduling](client-reactivity-engine_batching-scheduling.md) module.

## 7. Deep reactivity — `proxy()`

`$state` objects and arrays are wrapped by `proxy()`, which converts ordinary property traffic into signal traffic:

```mermaid
flowchart TD
    A["Read: obj.x"] --> B{"sources.has('x')?"}
    B -- "no (own & writable or missing)" --> C["with_parent: create source,<br/>recursively proxy(target.x)"]
    C --> D["get(s) — registers dependency"]
    B -- yes --> D
    D --> E{"v === UNINITIALIZED?"}
    E -- "yes" --> F["return undefined"]
    E -- "no" --> G["return value"]

    H["Write: obj.x = v"] --> I{"sources.has('x')?"}
    I -- no --> J["create source, then set(s, proxy(v))"]
    I -- yes --> K["set(s, proxy(v))"]
    J --> L["array length sync /<br/>increment(version) when key set changes"]
    K --> L
    L --> M["internal_set → batching + propagation"]
```

### 7.1 Proxyability rules

- Only values whose prototype is `Object.prototype` or `Array.prototype` are proxied; already-proxied values are returned as-is (detected via the `STATE_SYMBOL` brand).
- Class instances, `Map`/`Set`, DOM nodes, functions, etc. pass through untouched — use the reactive builtins (`SvelteMap`, `SvelteSet`, `SvelteDate`, `SvelteURL`, see [reactive-builtins.md](reactive-builtins.md)) for those.
- Changing the prototype is rejected with `state_prototype_fixed`.

### 7.2 Internal structure

| Piece | Purpose |
|---|---|
| `sources: Map<prop, Source>` | Lazily created per property. Reads (`get`/`has`/`ownKeys`) and writes (`set`/`defineProperty`/`deleteProperty`) both ensure a source exists first, so *write-before-read* still produces identical dependency heuristics. |
| `version = source(0)` | A numeric counter incremented (via `increment()`) whenever the **key set** changes (property added/deleted). `ownKeys` reads it with `get(version)` so `each`-style iteration over keys/entries is reactive. |
| `length` source (arrays) | Created eagerly for arrays. `arr.push`-style index writes bump it (`set(ls, n + 1)`); `length = n` shrinks by setting all indices `>= n` to `UNINITIALIZED`. |
| `with_parent(fn)` | Ownership guard: child sources created *after* the proxy itself (e.g. on first access from an unrelated reaction) are created with `active_reaction` neutralized and the proxy's original `update_version` restored, preventing accidental capture by the currently-running reaction. |
| `UNINITIALIZED` sentinel | Represents "deleted / not yet defined". Stored in sources by `deleteProperty` and length-shrink; `get` maps it to `undefined`, `has` maps it to `false`. |

### 7.3 Trap reference

| Trap | Signal behavior |
|---|---|
| `get` | Returns raw target for `STATE_SYMBOL`; dev-only `PROXY_PATH_SYMBOL` → `update_path`. Otherwise creates + nests proxies as needed and returns `get(s)` (dependency registration happens inside `get`). |
| `set` | `set(s, proxy(value))`; runs target accessor setters with the receiver; syncs array `length`; `increment(version)` for new keys. |
| `has` | `STATE_SYMBOL` → `true`; `UNINITIALIZED` → `false`; otherwise `get(s)` after ensuring a source exists. |
| `ownKeys` | `get(version)` + merge of surviving target keys and source-added keys. |
| `getOwnPropertyDescriptor` | Materializes descriptors from current source values; synthesizes descriptors for source-only properties (needed by spread and `Object.assign`). |
| `defineProperty` | Rejects non-basic descriptors (`state_descriptors_fixed` — required to keep proxies forkable); otherwise creates or `set`s the source with `should_proxy = true`. |
| `deleteProperty` | `set(s, UNINITIALIZED)` + `increment(version)`. |
| `setPrototypeOf` | Throws `state_prototype_fixed`. |

### 7.4 Dev-only array instrumentation

`inspectable_array` (applied in dev) wraps array-mutating methods (`push`, `splice`, `sort`, …) with `set_inspect_effects_deferred()` / `flush_inspect_effects()` so `$inspect` fires **once** with the post-mutation array instead of observing intermediate states (e.g. transiently empty arrays).

## 8. `update_path` — dev path relabeling

```js
function update_path(new_path) {
  if (updating) return;   // re-entrancy guard
  updating = true;
  path = new_path;
  tag(version, `${path} version`);
  for (const [prop, source] of sources) {
    tag(source, get_label(path, prop));  // renames children & nested proxies
  }
  updating = false;
}
```

`update_path` is the mechanism that keeps **debug labels correct as proxies move around the application**. It is reachable only in dev builds: the proxy's `get` trap returns `update_path` when queried with `PROXY_PATH_SYMBOL`, and `tag_proxy()` (from `dev/tracing.js`) invokes it:

```js
// sources.js, inside set():
if (DEV) tag_proxy(new_value, source.label);
// dev/tracing.js:
value?.[PROXY_PATH_SYMBOL]?.(label);
```

So when a proxied object is assigned to a `$state` variable (or nested inside another state object), the proxy and **all of its transitive child sources and child proxies** are re-labeled to the new logical path — e.g. `user.name` instead of the location where the object literal was first created. This is what makes `$inspect.trace()`, `/console.log($state(...))` snapshots ([client-dev-tooling.md](client-dev-tooling.md)) and ownership validation show meaningful signal names.

Label formatting is handled by `get_label(path, prop)`:

| Property | Label |
|---|---|
| `x` (valid identifier) | `path.x` |
| `0` (numeric) | `path[0]` |
| `weird key` | `path['weird key']` |
| `Symbol.iterator` | `path[Symbol(iterator)]` |

The `updating` boolean guard prevents infinite recursion when object graphs are cyclic (`tag → tag_proxy → nested update_path → …`), and re-tagging the `version` source ensures key-iteration dependencies also carry the fresh label.

Unwrapping counterpart: `get_proxied_value(v)` returns the raw target for branded proxies (with a `try/catch` so cross-origin iframe objects are passed through safely), and `is(a, b)` performs `Object.is` on unwrapped values — both are used across the runtime (e.g. equality checks in bindings and props).

## 9. Dev instrumentation summary

| Facility | Export | Consumer |
|---|---|---|
| `inspect_effects` set, `set_inspect_effects`, `set_inspect_effects_deferred`, `flush_inspect_effects` | sources.js | `$inspect` effects ([client-dev-tooling.md](client-dev-tooling.md), `dev/inspect.js`); proxy array methods; clean inspect effects are marked `MAYBE_DIRTY` and re-checked via `is_dirty` to avoid over-firing |
| `old_values` map | sources.js | `get()` during effect teardown (consistent teardown snapshots) |
| `created` / `updated` stacks, `set_during_effect` | sources.js (on the signal) | tracing mode & `$inspect.trace` diagnostics |
| `tag_proxy` → `update_path` | proxy.js + dev/tracing.js | `set()` labeling of assigned proxies, HMR wrappers, ownership validator |

## 10. Invariants and error contracts

| Invariant | Enforcement |
|---|---|
| No state writes during derivation | `set()` → `state_unsafe_mutation` for `DERIVED` / `BLOCK_EFFECT` / `ASYNC` / `INSPECT_EFFECT` reactions |
| Property descriptors stay basic (value, writable, enumerable, configurable) | `defineProperty` trap → `state_descriptors_fixed` |
| Prototype of proxied state is fixed | `setPrototypeOf` trap → `state_prototype_fixed` |
| One source per property per proxy | `sources` map; creation is idempotent via `with_parent` |
| Key-set changes are individually observable | `version` source + `increment()` |
| Identical writes are free | `equals` / `safe_equals` short-circuit in `internal_set` |

## 11. Dependency and consumer map

```mermaid
flowchart LR
    SG["signal-graph<br/>runtime.js: get, active_reaction,<br/>untracked_writes, write versions"] --> SP["sources-and-proxies<br/>(this module)"]
    FND["foundation<br/>equality.js, flags/index.js"] --> SP
    BS["batching-scheduling<br/>Batch, schedule_effect,<br/>eager_block_effects"] --> SP
    DER["deriveds-and-async<br/>execute_derived"] --> SP
    CTX["context-api<br/>context.js: component_context, is_runes"] --> SP
    DEV["client-dev-tooling<br/>dev/tracing.js: tag, tag_proxy, get_stack"] --> SP
    SP --> P1["props-and-stores<br/>prop(), store_get() built on<br/>mutable_source + set"]
    SP --> P2["reactive-builtins<br/>SvelteMap/Set/Date/URL<br/>wrap sources & proxies"]
    SP --> P3["client-dom-renderer<br/>attribute_effect and template<br/>effects read/write sources"]
    SP --> P4["legacy-compat<br/>invalidate_inner_signals walks<br/>mutable_source lists"]
```

**Upstream (this module imports):** `runtime.js` (signal-graph), `equality.js` and `flags` (foundation), `Batch`/`schedule_effect`/`eager_block_effects` (batching-scheduling), `execute_derived` (deriveds-and-async), `component_context`/`is_runes` (context), `proxy` (intra-module), `get_stack`/`tag`/`tag_proxy` (dev tooling), shared utils (`is_array`, descriptors, prototypes) and client `errors.js`.

**Downstream (who depends on this module):**

- **Compiled components** — `$state` → `state()`; assignments → `set()`; `x++` / `++x` → `update()` / `update_pre()`; object/array literals → `proxy()`.
- [client-reactivity-engine_props-and-stores.md](client-reactivity-engine_props-and-stores.md) — `prop()` wraps mutable sources; store subscriptions source their values from sources updated via this module.
- [client-reactivity-engine_deriveds-and-async.md](client-reactivity-engine_deriveds-and-async.md) — deriveds are themselves signal cells whose status is repaired by `internal_set`.
- [reactive-builtins.md](reactive-builtins.md) — `SvelteMap`/`SvelteSet`/`SvelteDate`/`SvelteURL` compose sources/proxies for non-plain-object built-ins.
- [client-dom-renderer.md](client-dom-renderer.md) — template effects read sources and reflect writes into the DOM during batch flush.
- [legacy-compat.md](legacy-compat.md) — legacy component invalidation iterates the `mutable_source` lists registered here.

## 12. Performance notes

- **Lazy materialization** — proxy property sources are created on first access, so unused object shapes cost one `Map` entry plus a numeric `version` source, nothing more.
- **Version counter trick** — key-set reactivity costs a single `get(version)` per `ownKeys`, instead of per-key dependencies.
- **`skipped_deps`-friendly reads** — because `update()`/`update_pre()` go through `get()`, repeated reads inside the effect init/update cycle reuse the existing dependency ordering (see `get()` in the [signal-graph](client-reactivity-engine_signal-graph.md) docs).
- **Equality short-circuit** — `x = x` style writes exit before batching, propagation or scheduling.
- **Tree-shakeability** — factories are annotated `/*#__NO_SIDE_EFFECTS__*/`; the whole runtime is verified by the treeshakeability checker (see [treeshakeability-checker.md](treeshakeability-checker.md)) and performance is tracked by the reactivity benchmark suites (see [reactivity-benchmarks.md](reactivity-benchmarks.md)), including `sbench`/`kairo` graph shapes that stress `mark_reactions` fan-out.
