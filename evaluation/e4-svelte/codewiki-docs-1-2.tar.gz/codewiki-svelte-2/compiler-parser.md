# Compiler Parser (`phases/1-parse`)

## 1. Introduction & Purpose

The **compiler-parser** module is the **first phase** of the Svelte compiler pipeline. It transforms raw `.svelte` source text into an Abstract Syntax Tree (`AST.Root`) that all subsequent phases consume. It is a *hybrid parser*:

- A **hand-written, character-level state machine** parses the template (HTML elements, Svelte blocks, directives, text and mustache tags).
- **Acorn** (extended with `@sveltejs/acorn-typescript`) parses embedded JavaScript/TypeScript — both full `<script>` contents and inline `{expressions}`.

```mermaid
flowchart LR
    A[".svelte source text"] --> B["1-parse (this module)"]
    B --> C["AST.Root<br/>(fragment + js + css + options)"]
    C --> D["2-analyze"]
    D --> E["3-transform<br/>(client / server / css)"]
    E --> F["JS + CSS output"]
```

Its output is the contract with the rest of the compiler:

| Output part | Produced by | Consumed by |
|---|---|---|
| `root.fragment` (template nodes) | template state machine | analyzer & transformer visitors |
| `root.js` (instance/module `Script` nodes) | Acorn integration | script analysis & code generation |
| `root.css` (`StyleSheet` node) | `read/style.js` via the state machine | CSS analyze/transform phase |
| `root.options` (`<svelte:options>`) | options reader | compiler option validation |
| `root.comments` (all JS comments) | Acorn comment handlers | `svelte-ignore` handling, formatter support |

> For the bigger picture of how this phase fits into the whole toolchain, see the [Compiler Pipeline & Language Toolchain](compiler-pipeline.md) overview, and the sibling modules [compiler-analyzer](compiler-analyzer.md), [compiler-transformer](compiler-transformer.md), [compiler-core](compiler-core.md) and [compiler-preprocessor](compiler-preprocessor.md).

## 2. Architecture Overview

The parser is organized around three cooperating concerns:

1. **Parser core** — the `Parser` class holding all cursor state (`index`, `stack` of open elements, `fragments` stack) and the primitive lexing operations (`eat`, `match`, `read`, `read_until`, `read_identifier`). It drives the state-machine loop in its constructor.
2. **Parsing states** — functions with signature `(parser) => ParserState | void`. `fragment` dispatches to `element`, `tag` (mustache syntax) or `text` depending on the next character. States append finished nodes to the current fragment and push/pop the element stack.
3. **Language integrations** — Acorn for JS/TS (with a custom comment handler so comments survive parsing) and a TypeScript-node stripper that erases type-only syntax before code printing.

```mermaid
flowchart TB
    subgraph "Entry points"
        P["parse(template, loose)<br/>index.js"]
    end

    P --> SM["Parser state-machine loop"]
    SM --> FRAG["state/fragment.js<br/>(dispatcher)"]
    FRAG -->|"<"| EL["state/element.js<br/>elements & attributes"]
    FRAG -->|"{"| TAG["state/tag.js<br/>blocks & expressions"]
    FRAG -->|"else"| TXT["state/text.js"]

    EL -->|"top-level <script>"| RS["read/script.js"]
    EL -->|"top-level <style>"| RST["read/style.js"]
    EL -->|"<svelte:options>"| OPT["read/options.js"]

    RS --> AC["acorn.js<br/>(JS/TS → estree AST)"]
    TAG --> RE["read/expression.js"]
    RE --> AC

    AC --> TS["remove_typescript_nodes.js<br/>(TS erasure walk)"]

    subgraph "Utilities"
        HTML["utils/html.js<br/>entity decoding"]
        FUZZY["utils/fuzzymatch.js<br/>error suggestions"]
    end
    TXT --> HTML
    EL --> HTML

    SM --> ROOT["AST.Root"]
```

### 2.1 Module decomposition

| Sub-module | Files | Responsibility | Documentation |
|---|---|---|---|
| Parser core | `phases/1-parse/index.js` | `Parser` class, `parse()` entry point, state-machine driver, loose mode, `AST.Root` assembly | [compiler-parser_parser-core](compiler-parser_parser-core.md) |
| Parsing states | `state/fragment.js`, `state/element.js`, `state/text.js` | Recursive-discent template parsing: dispatch, elements/attributes/directives, text nodes | [compiler-parser_parsing-states](compiler-parser_parsing-states.md) |
| JS/TS parsing | `acorn.js`, `remove_typescript_nodes.js` | Acorn integration with comment preservation; TypeScript type erasure | [compiler-parser_js-ts-parsing](compiler-parser_js-ts-parsing.md) |
| Options reading | `read/options.js` | `<svelte:options>` validation and conversion into `root.options` | [compiler-parser_options-reading](compiler-parser_options-reading.md) |
| Parsing utilities | `utils/fuzzymatch.js`, `utils/html.js` | Fuzzy name matching for diagnostics; HTML character-reference decoding | [compiler-parser_parsing-utilities](compiler-parser_parsing-utilities.md) |

## 3. Data Flow: Source to AST

```mermaid
sequenceDiagram
    participant API as parse(template, loose)
    participant P as Parser
    participant S as States (fragment/element/text/tag)
    participant A as Acorn + TS plugin
    participant O as read_options

    API->>P: state.set_source(template); new Parser(template, loose)
    P->>P: detect lang="ts" via regex on <script> tags<br/>initialize AST.Root
    loop while index < template.length
        P->>S: state(parser)
        S->>S: append nodes / push / pop stack
        S->>A: read_expression / read_script (expressions, scripts)
        A-->>S: estree nodes + comments
    end
    P->>P: unclosed-tag handling (strict vs loose)
    P->>O: extract <svelte:options> from fragment
    O-->>P: root.options (runes, namespace, customElement, ...)
    P-->>API: AST.Root
```

## 4. Sub-module Details (high level)

### 4.1 Parser core
`parse()` sets the module-level source (used by the diagnostic code-frame generator), instantiates `Parser`, and returns `parser.root`. The `Parser` constructor performs the entire template parse synchronously: it trims trailing whitespace, sniffs TypeScript mode from the first `<script lang="ts">`, creates the `Root` node, then repeatedly invokes the current state function. On completion it reports unclosed elements/blocks (respecting loose mode), computes `root.start/end` bounds and lifts `<svelte:options>` out of the fragment via `read_options`. Helper primitives (`eat`, `match`, `match_regex`, `read`, `read_until`, `read_identifier`, `allow_whitespace`, `require_whitespace`) are shared by every state; `acorn_error` rethrows Acorn errors as Svelte compile errors. Details: [compiler-parser_parser-core](compiler-parser_parser-core.md).

### 4.2 Parsing states
`fragment` is the dispatcher: `<` → element, `{` → tag (blocks `#if`, `:else`, `@render`… or plain expressions), everything else → text. `element` is the largest state: it reads opening/closing tags, resolves meta tags (`svelte:head`, `svelte:options`, `svelte:window`, …), distinguishes components from regular elements, reads attributes/directives/spreads/attachments, handles implicit closing of HTML elements, special-cases `<textarea>`, non-top-level `<script>`/`<style>`, and backtracks intelligently in loose (IDE-friendly) mode. `text` consumes raw characters and decodes HTML entities. Details: [compiler-parser_parsing-states](compiler-parser_parsing-states.md).

### 4.3 JS/TS parsing
`acorn.js` wraps Acorn (with the TypeScript plugin when needed) and installs `onComment` handlers so every comment is captured with source locations and later re-attached as `leadingComments`/`trailingComments` — required for `svelte-ignore` in JS and for formatter round-tripping. `parse_script` also patches `parseStatement` so `<script>` may re-export names defined elsewhere in the component. `remove_typescript_nodes.js` is a zimmerframe walk that deletes type annotations, drops type-only imports/exports/interfaces, unwraps `TSAsExpression`/`TSSatisfiesExpression`/`TSNonNullExpression`, removes parameter `this`, and raises `typescript_invalid_feature` errors for unsupported TS features (enums, decorators, namespaces with runtime code…). Details: [compiler-parser_js-ts-parsing](compiler-parser_js-ts-parsing.md).

### 4.4 Options reading
`read_options` converts the raw attributes of `<svelte:options>` into a validated options object: booleans (`runes`, `immutable`, `preserveWhitespace`, `accessors`), `namespace` (`html`/`svg`/`mathml`), `css="injected"`, and the deeply structured `customElement` config (tag-name validation per the HTML spec, props with `type`/`reflect`/`attribute`, shadow mode, `extend`). Unknown or deprecated attributes produce precise compile errors. Details: [compiler-parser_options-reading](compiler-parser_options-reading.md).

### 4.5 Parsing utilities
`html.js` builds two regexes (content vs attribute-value context, following the WHATWG named-character-reference rules) and decodes named/decimal/hex entities, including Windows-1252 fixes for code points 128–159 and rejection of illegal code points. `fuzzymatch.js` embeds a small fuzzy-set implementation (2/3-gram cosine similarity + Levenshtein refinement) used to produce "did you mean X?" suggestions in error messages. Details: [compiler-parser_parsing-utilities](compiler-parser_parsing-utilities.md).

## 5. Key Design Concepts

### 5.1 Loose parsing mode
`parse(template, loose = true)` enables an IDE-oriented mode (used by the language server) that recovers from incomplete code: missing `>` is tolerated, partially typed attribute shorthands are skipped, `<div.` is accepted mid-typing, and attribute names that swallowed a following `<` are undone via backtracking. In strict mode the same situations raise compile errors (`element_unclosed`, `block_unclosed`, `unexpected_eof`, …).

### 5.2 Implicit element closing
Following the HTML spec, the parser auto-closes elements whose end tags may be omitted (e.g. `<li><li>`, `<p>` before block elements) using `html-tree-validation.js`, records the auto-close in `last_auto_closed_tag` (so `</p>` later doesn't error), and emits `element_implicitly_closed` warnings instead of errors.

### 5.3 Comment preservation
Acorn discards comments by default. The custom `get_comment_handlers` factory (a) collects all comments into `root.comments` with locations (dedenting multi-line block comments), and (b) re-attaches them to AST nodes as leading/trailing comments. This is what makes `<!-- svelte-ignore ... -->`-adjacent JS comments and `svelte-ignore` in scripts work, and keeps comments stable for `prettier-plugin-svelte`.

### 5.4 TypeScript handling
TypeScript mode is detected once from a `<script lang="ts">` attribute and threaded through every expression and script parse. Because the compiler prints JS, all TS-only syntax must be erased during parsing — that is `remove_typescript_nodes`' job. Features that have no JS counterpart (enums, decorators, `accessor` fields, namespaces with runtime code) are rejected with `typescript_invalid_feature`.

### 5.5 Error strategy
- Diagnostics are raised through the generated error/warning catalogs in [compiler-core_diagnostics](compiler-core_diagnostics.md) (`errors.js` / `warnings.js`), which attach code frames via `state.js` source tracking.
- `fuzzymatch` powers suggestions for invalid meta tags and directive names.
- Acorn errors are translated by `parser.acorn_error()`, stripping Acorn's `(line:col)` suffix since Svelte computes positions itself.

## 6. Interaction with Sibling Modules

```mermaid
flowchart LR
    subgraph "compiler-core"
        T["types/template.d.ts<br/>(AST node shapes)"]
        D["errors.js / warnings.js"]
        B["utils/builders.js"]
    end
    subgraph "compiler-parser"
        P["Parser & states"]
        A["acorn.js"]
    end
    subgraph "compiler-analyzer"
        V["visitors/*"]
    end
    T --> P
    D --> P
    B --> TS2["remove_typescript_nodes"]
    P -->|AST.Root| V
    A -->|Program nodes| V
```

- **compiler-core** supplies the `AST` type definitions that every parsed node instantiates, the error/warning catalogs used for diagnostics, and the `builders` used when replacing TS constructs (see [compiler-core](compiler-core.md)).
- **compiler-analyzer** walks the produced `AST.Root` and attaches expression/scope metadata (see [compiler-analyzer](compiler-analyzer.md)).
- **compiler-preprocessor** runs *before* parsing in user-facing `preprocess()` pipelines; its `Processed.code` output is what this parser consumes (see [compiler-preprocessor](compiler-preprocessor.md)).
- The **Client Runtime Engine** and **Server-Side Rendering** modules never see source text — they receive only the transformed output of later phases.

## 7. Component Index

| File | Core exports | Role |
|---|---|---|
| `phases/1-parse/index.js` | `parse`, `Parser` | Entry point + state-machine driver |
| `phases/1-parse/acorn.js` | `parse`, `parse_expression_at`, `get_comment_handlers` | JS/TS → estree AST with comments |
| `phases/1-parse/remove_typescript_nodes.js` | `remove_typescript_nodes` (`remove_this_param` visitor) | TS syntax erasure |
| `phases/1-parse/read/options.js` | `read_options` | `<svelte:options>` → `root.options` |
| `phases/1-parse/state/fragment.js` | `fragment` | State dispatcher |
| `phases/1-parse/state/element.js` | `element`, `read_attribute`, `read_static_attribute` | Elements, attributes, directives |
| `phases/1-parse/state/text.js` | `text` | Text nodes with entity decoding |
| `phases/1-parse/utils/fuzzymatch.js` | `fuzzymatch` (`sort_descending`) | Error-suggestion matching |
| `phases/1-parse/utils/html.js` | `decode_character_references` (`get_entity_pattern`) | HTML entity decoding |
| supporting | `state/tag.js`, `read/expression.js`, `read/script.js`, `read/style.js`, `utils/create.js` | Mustache tags, expression/script/style readers, fragment factory |

## 8. Documentation Map

All documentation for this module (flat directory, links by file name):

- **Main overview:** `compiler-parser.md` (this file)
- **Sub-module deep dives:**
  - [compiler-parser_parser-core.md](compiler-parser_parser-core.md) — `Parser` class, `parse()` entry, state-machine loop, loose mode, `AST.Root` assembly
  - [compiler-parser_parsing-states.md](compiler-parser_parsing-states.md) — `fragment` dispatcher, `element`/`text` states, attribute & directive reading
  - [compiler-parser_js-ts-parsing.md](compiler-parser_js-ts-parsing.md) — Acorn/TypeScript integration and TS-node erasure
  - [compiler-parser_options-reading.md](compiler-parser_options-reading.md) — `<svelte:options>` parsing & validation
  - [compiler-parser_parsing-utilities.md](compiler-parser_parsing-utilities.md) — HTML entity decoding and fuzzy error suggestions
- **Sibling modules:** [compiler-core](compiler-core.md), [compiler-analyzer](compiler-analyzer.md), [compiler-transformer](compiler-transformer.md), [compiler-preprocessor](compiler-preprocessor.md), [compiler-migrator](compiler-migrator.md)
