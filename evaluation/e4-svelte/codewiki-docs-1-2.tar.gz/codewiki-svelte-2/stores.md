# Stores (`svelte/store`)

> Module: **Public API & Built-in Feature Surface → stores**
> Location: `packages/svelte/src/store/`

## 1. Purpose

The `stores` module implements Svelte's **store contract** — the minimal, framework-agnostic observable interface (`subscribe` / `set` / `update`) that predates runes — plus the modern **bridges** that interoperate stores with the runes reactivity system (`$state`). It is the code behind the public `svelte/store` import and remains the canonical way to share reactive state *outside* of components (framework-agnostic libraries, module-level singletons, SSR-safe state).

The module has three responsibilities:

1. **Define the contract** — the `Readable<T>` / `Writable<T>` interfaces and the callback types (`Subscriber`, `Updater`, `Unsubscriber`, `StartStopNotifier`) that any conforming store must implement. See [Store Contract & Types](stores_contract.md).
2. **Implement the factories** — `writable`, `readable`, `derived`, `readonly` and `get`, all target-agnostic and shared by both the client and server entries. See [Core Store Implementations](stores_core.md).
3. **Bridge stores ↔ runes** — `toStore` (wrap `$state` as a store) and `fromStore` (expose a store as a reactive `{ current }` object), with a reactive client implementation and a plain, non-reactive server implementation. See [Runes ↔ Stores Bridge](stores_runes_bridge.md).

## 2. Position in the System

The stores module is a leaf of the **Public API & Built-in Feature Surface**. It is deliberately thin on runtime magic: it depends on a *small, well-defined* subset of the internal runtime and is in turn consumed by several other modules.

```mermaid
flowchart LR
    subgraph consumers["Depends on (internal runtime)"]
        EQ["client-reactivity-engine<br/>equality · effects · runtime context"]
        SU["internal-shared-utils<br/>noop · run_all"]
        CS["reactive-builtins pattern<br/>createSubscriber"]
    end

    subgraph stores_mod["stores (this module)"]
        PD["public.d.ts — contract"]
        SH["shared/index.js — factories"]
        IC["index-client.js — reactive bridge"]
        IS["index-server.js — plain bridge"]
    end

    subgraph downstream["Consumed by"]
        MO["motion (spring · tweened)"]
        PA["public-api entries"]
        CRE["client-reactivity-engine<br/>(store_get · invalidate_store)"]
        SRV["server-runtime<br/>(update_store · unsubscribe_stores)"]
        LEG["legacy-compat ($: statements)"]
    end

    EQ --> SH
    EQ --> IC
    SU --> SH
    CS --> IC
    PD --> IC
    PD --> IS
    SH --> IC
    SH --> IS

    stores_mod --> MO
    stores_mod --> PA
    stores_mod --> CRE
    stores_mod --> SRV
    stores_mod --> LEG
```

- **Upstream**: the *client reactivity engine* provides `safe_not_equal` (change detection), the effect primitives (`effect_root`, `render_effect`, `effect_tracking`) and the `active_effect` / `active_reaction` context that `toStore` captures; `internal/shared/utils` provides `noop` / `run_all`; the lazy-subscription helper `createSubscriber` (shared with `reactive-builtins` such as `MediaQuery`) powers `fromStore` on the client.
- **Downstream**: the `motion` module builds `spring`/`tweened` directly on `writable`/`derived`; the compiler's `$store` auto-subscription lowers to `store_get` / `store_set` / `invalidate_store` in the client runtime and `update_store` / `unsubscribe_stores` in the *server runtime*; `legacy-compat` uses stores for `$:` reactive statements.

## 3. Architecture Overview

### 3.1 File layout and entry-point resolution

```mermaid
flowchart TB
    USER["import { writable, derived, fromStore } from 'svelte/store'"] --> EXPORTS{"package exports<br/>(browser vs server condition)"}

    EXPORTS -- "client bundle" --> IC["index-client.js<br/>toStore · fromStore<br/>+ re-exports shared factories"]
    EXPORTS -- "server / SSR bundle" --> IS["index-server.js<br/>toStore · fromStore (non-reactive)<br/>+ re-exports shared factories"]

    subgraph shared_core["Target-agnostic core"]
        SH["shared/index.js<br/>writable · readable · derived · readonly · get"]
        UT["utils.js<br/>subscribe_to_store (null-safe, untracked, RxJS-compatible)"]
        PVT["private.d.ts<br/>Stores · StoresValues"]
    end

    PD["public.d.ts<br/>Readable · Writable · Subscriber · Updater ·<br/>Unsubscriber · StartStopNotifier"]

    subgraph internal_rt["Internal runtime (other modules)"]
        RT["client/runtime.js<br/>active_effect · active_reaction"]
        EF["client/reactivity/effects.js<br/>effect_root · render_effect · effect_tracking"]
        SUBS["reactivity/create-subscriber.js<br/>createSubscriber"]
        EQ2["client/reactivity/equality.js<br/>safe_not_equal"]
        U2["internal/shared/utils.js<br/>noop · run_all"]
    end

    IC --> SH
    IS --> SH
    IC --> RT
    IC --> EF
    IC --> SUBS
    SH --> EQ2
    SH --> U2
    SH --> UT
    SH --> PVT
```

The **exact same public API** is available on both targets; only `toStore` / `fromStore` differ in behavior (reactive tracking vs. plain reads). Everything else — `writable`, `readable`, `derived`, `readonly`, `get` — is compiled once into `shared/index.js` and used verbatim on the server and the client.

### 3.2 The store contract

```mermaid
classDiagram
    class Readable~T~ {
        +subscribe(run, invalidate?) Unsubscriber
    }
    class Writable~T~ {
        +set(value) void
        +update(updater) void
    }
    class Subscriber~T~ {
        <<callback>>
        run(value)
    }
    class Updater~T~ {
        <<callback>>
        updater(current) next
    }
    class Unsubscriber {
        <<callback>>
        ()
    }
    class StartStopNotifier~T~ {
        <<callback>>
        start(set, update) teardown?
    }
    Writable --|> Readable : extends
    Readable ..> Subscriber : invokes on change
    Writable ..> Updater : used by update()
    Readable ..> Unsubscriber : returned by subscribe()
    Readable ..> StartStopNotifier : first/last subscriber lifecycle
```

The contract is intentionally tiny so *any* object with a `subscribe` method works — including RxJS observables (handled by `subscribe_to_store`). Full type definitions and the private `Stores` / `StoresValues` inference helpers are documented in [Store Contract & Types](stores_contract.md).

## 4. Sub-modules

| Sub-module | Files | Contents |
|---|---|---|
| [Store Contract & Types](stores_contract.md) | `public.d.ts`, `private.d.ts` | `Readable`, `Writable`, callback types; `Stores` / `StoresValues` inference helpers used by `derived` |
| [Core Store Implementations](stores_core.md) | `shared/index.js`, `utils.js` | `writable`, `readable`, `derived`, `readonly`, `get`, `subscribe_to_store`; subscriber lifecycle, change batching, derived synchronization |
| [Runes ↔ Stores Bridge](stores_runes_bridge.md) | `index-client.js`, `index-server.js` | `toStore`, `fromStore`; client reactive wiring vs. server plain reads |

## 5. Key Data Flows

### 5.1 `writable` set → batched notification

`writable` keeps a `Set` of `[run, invalidate]` tuples and a module-level `subscriber_queue`. On `set`, invalidations run *first* for all subscribers, then `run` callbacks are flushed from the queue — and only by the **outermost** `set` (the queue was empty when it started), which coalesces nested/ cascading updates into a single pass.

```mermaid
sequenceDiagram
    autonumber
    participant Src as set() caller (user or notifier)
    participant Store as writable instance
    participant Subs as subscribers Set
    participant Queue as subscriber_queue
    participant Con as consumer callbacks

    Src->>Store: set(newValue)
    Store->>Store: safe_not_equal(old, newValue)?
    alt equal → skip
        Store-->>Src: (no-op)
    else store inactive (no subscribers)
        Store->>Store: value = newValue only
    else store active
        loop for each subscriber
            Store->>Con: invalidate() (deferred reactions)
            Store->>Queue: push [subscriber, newValue]
        end
        alt queue was empty (outermost set)
            loop queued pairs
                Queue->>Con: run(newValue)
            end
            Store->>Queue: length = 0 (flush done)
        end
    end
end
```

**Lifecycle guarantees:** the `start` notifier runs exactly once when the first subscriber arrives (receiving `set`/`update` to push values from external sources); its teardown runs when the last subscriber leaves, resetting to allow a future restart.

### 5.2 `derived` — synchronized inputs, two callback shapes

```mermaid
flowchart TD
    A["derived(stores, fn, initial_value?)"] --> B{"single store?"}
    B -- "yes" --> C["wrap in one-element array"]
    B -- "no" --> D["use array directly"]
    C --> E["readable(initial, start)"]
    D --> E
    E --> F["first subscribe → start(set, update)"]
    F --> G["subscribe to every input store<br/>one pending bit per input"]
    G --> H{"all pending bits cleared?"}
    H -- "no (some input has no value yet)" --> I["defer until all inputs delivered"]
    H -- "yes" --> J["sync(): cleanup(); fn(values, set?, update?)"]
    J --> K{"auto mode? fn.length < 2"}
    K -- "yes (sync shape)" --> L["set(fn result)"]
    K -- "no (manual shape)" --> M["result is a cleanup fn → stored as cleanup"]
    J --> N["on stop: run_all(unsubscribers)<br/>cleanup(); started = false"]
```

The bitmask `pending` ensures the aggregation function only fires once *every* input store has delivered its initial value, regardless of subscription order. The two overload shapes (sync aggregation vs. manual `set`/`update` with optional cleanup) are described in [Core Store Implementations](stores_core.md).

### 5.3 Bridge direction (client vs. server)

```mermaid
flowchart LR
    subgraph runes["Runes world"]
        ST["count = $state(0)"]
        OBJ["obj = fromStore(store)"]
    end
    subgraph bridge["stores bridge"]
        TS["toStore(get, set?)"]
        FS["fromStore(store)"]
    end
    subgraph storeworld["Store world"]
        W["writable / Readable · Writable"]
    end
    subgraph signalrt["Client signal runtime"]
        EFF["effect_root + render_effect<br/>(captures active context)"]
        CSUB["createSubscriber<br/>(lazy, ref-counted, microtask teardown)"]
        TRK["effect_tracking()"]
    end

    ST -- "get() / set(v)" --> TS
    TS -- "writable(init, start)" --> W
    TS -- "client: subscribes via" --> EFF
    W -- "store" --> FS
    FS -- "current getter" --> CSUB
    FS -- "effect_tracking()? subscribe : get(store)" --> TRK
    OBJ -- "obj.current reads/writes" --> FS
```

- **`toStore`** (client) re-enters the *captured* effect/reaction context of the call site inside an `effect_root`, so the resulting store updates when the underlying runes state changes — even though the store may be subscribed later from a different context. A `ran` flag suppresses the first redundant emission when the value already changed before the first subscription. On the server there is no reactive graph, so `toStore` simply snapshots `get()` once and delegates `set`/`update` to the caller's functions.
- **`fromStore`** (client) wraps the store in a lazy, ref-counted `createSubscriber`. The `current` getter checks `effect_tracking()`: inside a reactive effect it *subscribes* (so `current` participates in the signal graph); outside any effect it performs a one-shot `get(store)`. Writes to `current` on a writable store pass through to `store.set`. On the server, both directions collapse to a plain `get(store)` read.

Details and edge cases: [Runes ↔ Stores Bridge](stores_runes_bridge.md).

## 6. Integration Points (cross-references)

| Area | Relationship |
|---|---|
| [Client Reactivity Engine](client-reactivity-engine.md) | Supplies `safe_not_equal` (equality foundation), effect primitives & `active_effect`/`active_reaction` context (signal graph), and `createSubscriber`. The compiler lowers `$store` usage to `store_get` / `store_set` / `invalidate_store` / `mark_store_binding` here. |
| [Internal Shared Utils](internal-shared-utils.md) | `noop` and `run_all` are the only shared-runtime dependencies of the core factories. |
| [Motion](motion.md) | `spring` and `tweened` are store-based: both are built on `writable`/`derived` from this module. |
| [Reactive Builtins](reactive-builtins.md) | Shares the `createSubscriber` lazy-subscription pattern used by `fromStore` (also used by `MediaQuery`). |
| [Server Runtime](server-runtime.md) | SSR components interact with stores via `update_store`, `update_store_pre`, `store_mutate`, `unsubscribe_stores` — the server counterparts of the client store integration. |
| [Public API entries](public-api.md) | `svelte/store` is re-exported through the platform entry points; the store contract types surface in the public type definitions. |
| Legacy compat | `legacy-compat` and the legacy client runtime (`invalidate_inner_signals`, `$:` statements) build on stores/readable semantics for backward-compatible reactivity. |

## 7. Behavioral Invariants & Gotchas

- **`safe_not_equal` semantics**: `NaN !== NaN` still *propagates* (`a != a ? b == b`); objects and functions are *always* considered changed (no deep equality) — every `set(newObj)` notifies subscribers.
- **Batched flush, invalidate-before-run**: within one `set`, all `invalidate` callbacks run before any `run` callback; nested `set` calls during a flush reuse the same queue and are flushed by the outermost `set` only.
- **Start/stop symmetry**: `start` fires on the *first* subscriber, teardown on the *last* unsubscribe; subscribing again restarts the notifier with a fresh closure.
- **`derived` deferral**: callbacks are deferred (pending bitmask) until all input stores have delivered an initial value; unsubscribing runs `run_all(unsubscribers)` plus the manual-shape cleanup, and marks `started = false` so late queued callbacks are ignored.
- **`get()` is untracked**: `subscribe_to_store` wraps `store.subscribe` in `untrack`, so a `get(store)` inside a runes effect never creates a reactive dependency.
- **RxJS compatibility**: any store whose `subscribe` returns `{ unsubscribe }` is supported via `subscribe_to_store`.
- **Lazy, ref-counted client subscriptions**: `fromStore(...).current` inside effects subscribes only while at least one effect depends on it; teardown is deferred to a microtask to avoid subscribe/unsubscribe churn.
- **Server safety**: `index-server.js` never touches effects or the signal graph — `fromStore(store).current` is just a snapshot read, `toStore` never subscribes.

## 8. Documentation Map

- [Store Contract & Types](stores_contract.md) — interfaces and type-level guarantees
- [Core Store Implementations](stores_core.md) — `writable` / `readable` / `derived` / `readonly` / `get` internals
- [Runes ↔ Stores Bridge](stores_runes_bridge.md) — `toStore` / `fromStore`, client vs. server behavior
