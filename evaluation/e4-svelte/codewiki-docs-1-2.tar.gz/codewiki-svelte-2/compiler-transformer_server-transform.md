# compiler-transformer_server-transform

## 1. Introduction & Purpose

`compiler-transformer_server-transform` is the **server-side (SSR) half of Phase 3 of the Svelte 5 compiler**. It takes the *analyzed* AST produced by Phase 1 (parse) and Phase 2 (analyze) and rewrites it into a plain, executable ES module: a component function that receives a `$$payload` object and renders the component as an **HTML string** by appending to `$$payload.out`.

In other words, this module answers the question: *“How do we turn this Svelte component into JavaScript that runs on a Node server?”*

Key responsibilities:

- **Markup emission** — serialize elements, text and expressions into template-literal strings pushed onto `$$payload.out`, with correct HTML escaping.
- **Control-flow lowering** — compile `{#if}`, `{#each}`, `{#await}`, `{#key}` into plain JS `if`/`for` statements wrapped in hydration markers.
- **Component/snippet/slot plumbing** — compile component invocations, `{@render}` tags, `<slot>` and `{#snippet}` blocks into function calls and `$$slots` props.
- **Runes & legacy script rewriting** — strip reactivity from `$state`/`$derived` (server render is a single synchronous pass), rewrite `$props` destructuring, `export let`, `$:` reactive statements, and `$store` auto-subscriptions.
- **Dev-mode instrumentation** — element stack tracking (`push_element`/`pop_element`), snippet argument validation, dynamic-element validation.
- **Hydration markers** — emit `<!--$-->`, `<!--/$-->` and `<!---->` comments so the client runtime can later adopt server-rendered DOM.

The generated code depends on runtime helpers (`$.escape`, `$.attr`, `$.slot`, `$.await`, …) that are implemented by the **server runtime** — see the [Server-Side Rendering & Cross-Target Runtime Services](server-runtime.md) module documentation. Conversely, the client twin of this module is documented in [compiler-transformer_client-transform](compiler-transformer_client-transform.md).

## 2. Position in the Compiler Pipeline

```mermaid
flowchart LR
    A[".svelte source"] --> B["Phase 1: Parse<br/>(compiler-parser)"]
    B --> C["Phase 2: Analyze<br/>(compiler-analyzer)<br/>scopes · bindings · metadata"]
    C --> D{"Phase 3: Transform"}
    D -->|"generate: 'dom'"| E["Client Transform<br/>(compiler-transformer_client-transform)"]
    D -->|"generate: 'server'"| F["Server Transform<br/>(this module)"]
    F --> G["Code printing (esrap)"]
    G --> H["Executed by server runtime<br/>svelte/internal/server<br/>(server-runtime module)"]
    E --> I["Client runtime<br/>svelte/internal/client"]
```

The server transform is selected by `compile(..., { generate: 'server' })` (see [compiler-core_public_api](compiler-core_public_api.md)). It consumes the `Analysis` produced by the [compiler-analyzer](compiler-analyzer.md) module and shares infrastructure (AST builders, `clean_nodes`, shared assignment handling) with the rest of Phase 3 via [compiler-transformer_shared-infrastructure](compiler-transformer_shared-infrastructure.md).

## 3. Architecture Overview

### 3.1 Entry points & orchestration

The orchestration lives in `phases/3-transform/server/transform-server.js`, which exposes two exports used by `compiler/index.js`:

| Export | Input | Output |
|---|---|---|
| `server_component(analysis, options)` | `ComponentAnalysis` of a `.svelte` file | `Program` exporting the component render function |
| `server_module(analysis, options)` | `Analysis` of a `<script module>` | `Program` with rewritten module script |

`server_component` performs five steps:

```mermaid
flowchart TD
    A["server_component(analysis, options)"] --> B["Init ComponentServerTransformState<br/>hoisted = [import * as $ from 'svelte/internal/server']"]
    B --> C["1. Walk <script module> AST<br/>with global_visitors"]
    C --> D["2. Walk <script instance> AST<br/>global_visitors + import/export handling"]
    D --> E["3. Walk template AST<br/>global_visitors + template_visitors"]
    E --> F["4. Post-processing<br/>• order legacy reactive statements<br/>• settle-loop for component bindings<br/>• $$store_subs cleanup<br/>• bind_props / props_id / context push-pop<br/>• CSS injection (css: 'injected')"]
    F --> G["5. Assemble component function<br/>and export default"]
```

### 3.2 The two visitor registries

The module is built around the `zimmerframe` AST walker: every node type can have a visitor function `(node, context) => replacement | undefined`. Visitors are split into two registries:

- **`global_visitors`** — applied to *both* scripts and inline JS in the template. These handle JavaScript-level semantics: runes (`CallExpression`, `VariableDeclaration`, `PropertyDefinition`, `ClassBody`, `MemberExpression`), stores (`Identifier`, `AssignmentExpression`, `UpdateExpression`), legacy syntax (`LabeledStatement` for `$:`), and `{@const}` / `await` rules.
- **`template_visitors`** — applied only to the template AST. These emit markup and runtime calls: elements, blocks, components, snippets, slots.

```mermaid
flowchart LR
    subgraph global_visitors ["global_visitors (JS semantics)"]
        V1["VariableDeclaration<br/>runes / export let"]
        V2["AssignmentExpression<br/>state fields + stores"]
        V3["CallExpression<br/>rune lowering"]
        V4["Identifier<br/>$$props, store_get"]
        V5["ClassBody / PropertyDefinition /<br/>MemberExpression"]
        V6["UpdateExpression<br/>store ++/--"]
        V7["LabeledStatement ($:)"]
        V8["ConstTag · AwaitExpression"]
    end
    subgraph template_visitors ["template_visitors (markup emission)"]
        T1["Fragment · RegularElement ·<br/>SvelteElement · SvelteHead ·<br/>SvelteBoundary · HtmlTag · TitleElement"]
        T2["IfBlock · EachBlock ·<br/>AwaitBlock · KeyBlock"]
        T3["Component · SvelteComponent ·<br/>RenderTag · SlotElement · SnippetBlock"]
    end
    W["zimmerframe walk"] --> global_visitors
    W --> template_visitors
```

### 3.3 State-driven template accumulation

Visitors do not return strings directly. Instead they cooperate through `ComponentServerTransformState` (defined in `server/types.d.ts`):

| Field | Purpose |
|---|---|
| `init: Statement[]` | Statements that must run before rendering (consts, snippet declarations, store subs) |
| `template: (Statement \| Expression)[]` | The SSR output being built: string literals, expressions, nested blocks |
| `hoisted: Statement[]` | Module-level statements (imports, hoistable snippets) |
| `namespace` / `preserve_whitespace` | HTML/SVG/MathML context, whitespace handling |
| `skip_hydration_boundaries` | Suppresses `<!---->` anchors (e.g. standalone slots) |
| `analysis` / `scope` / `scopes` | From Phase 2 — drives all runes/store/binding decisions |

At the end of a fragment, [`build_template`](compiler-transformer_server-transform_shared-utils.md) collapses the accumulated `template` array into `$$payload.out.push(\`...\`)` calls, interleaving literal strings with dynamic expressions.

```mermaid
flowchart LR
    subgraph VS ["Visitor state"]
        init["init[]"]
        tpl["template[]"]
        hst["hoisted[]"]
    end
    A["AST node visited"] --> B["Visitor emits"]
    B -->|"literals + expressions"| tpl
    B -->|"const / let declarations"| init
    B -->|"snippet functions"| hst
    tpl --> C["build_template(...)"]
    C --> D["$$payload.out.push(`literal ${expr} literal`)"]
    init --> E["Component block body"]
    hst --> F["Module top level"]
```

### 3.4 Hydration markers

The template accumulates special literal markers imported from `internal/server/hydration.js` (implemented by the server runtime module):

| Marker | Meaning |
|---|---|
| `<!--$-->` (`BLOCK_OPEN`) | Start of an `{#if}` / `{#each}` branch — allows the hydrator to prune mismatched nodes |
| `<!--/$-->` (`BLOCK_CLOSE`) | End of such a block; also acts as an anchor |
| `<!--/-->` (`BLOCK_OPEN_ELSE`) | Marks the `:else`/`:else if` branch of a block |
| `<!---->` (`EMPTY_COMMENT`) | Separator/anchor for text nodes, slots, render tags, keyed blocks |

### 3.5 Output contract

Every component is emitted as:

```js
import * as $ from 'svelte/internal/server';

export default function App($$payload, $$props /* only when props are used */) {
  // instance script statements (props destructuring, consts…)
  // template statements → $$payload.out.push(...)
}
```

Optional extras injected by post-processing: `const $$id = $.props_id($$payload)` (hydration), `$.push(...)` / `$.pop()` (dev context), `$$sanitized_props` / `$$restProps` / `$$slots`, `$.bind_props(...)` (bound-prop propagation), `$.unsubscribe_stores($$store_subs)` (auto-subscription cleanup), and a `do/while` **settle loop** that re-renders until legacy component bindings stabilize.

### 3.6 Worked example

Input:

```svelte
<script>
	let count = $state(0);
</script>

{#if count > 1}
	<p>count is {count}</p>
{:else}
	<p>nothing to see</p>
{/if}
```

Simplified output of this module:

```js
import * as $ from 'svelte/internal/server';

export default function App($$payload, $$props) {
	$$payload.out += `<!--[-->`;
	if (count > 1) {
		$$payload.out += `<p>count is ${$.escape(count)}</p>`;
	} else {
		$$payload.out += `<p>nothing to see</p>`;
	}
	$$payload.out += `<!--/$-->`;
}
```

Note how: `$state` disappears (server render is one-shot), the `{#if}` becomes a plain `if` plus hydration markers, and the expression tag is wrapped in `$.escape` by [`process_children`](compiler-transformer_server-transform_shared-utils.md).

## 4. Sub-modules

The module splits into five logical areas. Detailed documentation:

| Sub-module | Files | Responsibility |
|---|---|---|
| [Template & Element Rendering](compiler-transformer_server-transform_template-rendering.md) | `Fragment`, `RegularElement`, `SvelteElement`, `SvelteHead`, `SvelteBoundary`, `HtmlTag`, `TitleElement` | Serialize static/dynamic markup into `$$payload.out`; namespaces, `<head>` content, boundaries, raw HTML, `<title>` |
| [Control Flow Blocks](compiler-transformer_server-transform_control-flow.md) | `IfBlock`, `EachBlock`, `AwaitBlock`, `KeyBlock` | Lower `{#if}`/`{:else}`, `{#each}`, `{#await}`, `{#key}` to JS statements + hydration markers |
| [Components, Snippets & Slots](compiler-transformer_server-transform_components-snippets.md) | `Component`, `SvelteComponent`, `RenderTag`, `SlotElement`, `SnippetBlock` | Invoke child components, render snippets, project content via `$$slots` |
| [Script & Expression Transformation](compiler-transformer_server-transform_script-transform.md) | `VariableDeclaration`, `AssignmentExpression`, `CallExpression`, `Identifier`, `AwaitExpression`, `UpdateExpression`, `ClassBody`, `MemberExpression`, `PropertyDefinition`, `ConstTag`, `LabeledStatement` | Runes, legacy `export let`/`$:`, `$store` subscriptions, class fields, `await` rules |
| [Shared Utilities](compiler-transformer_server-transform_shared-utils.md) | `shared/utils.js` | `process_children`, `build_template`, `build_attribute_value`, `build_getter`, hydration marker literals |

### Visitor → runtime helper map

The table below maps template/script visitors to the `svelte/internal/server` helpers they emit (helpers themselves are documented in the [server runtime](server-runtime.md) module):

| Helper call | Emitted from | Purpose |
|---|---|---|
| `$.escape(expr)` | `process_children`, attribute building | HTML-escape dynamic text/attribute values |
| `$.stringify(expr)` | `build_attribute_value` | Stringify expressions inside mixed attributes |
| `$.attr` / `$.attr_class` / `$.attr_style` | `RegularElement` (via `shared/element.js`) | Serialize attributes, `class`, `style` |
| `$.clsx` | `shared/element.js` | Merge class strings/directives |
| `$.html(expr)` | `HtmlTag` | Raw (unescaped) HTML output |
| `$.ensure_array_like(expr)` | `EachBlock` | Runtime guard for array-likes |
| `$.await(payload, expr, pending, then)` | `AwaitBlock` | Async render boundary |
| `$.await_outside_boundary()` | `AwaitExpression` | Error for illegal top-level `await` in template |
| `$.slot(payload, $$props, name, props, fallback)` | `SlotElement` | Slot content resolution |
| `$.spread_props([...])` | `SlotElement`, `build_inline_component` | Merge spread props/attrs |
| `$.head(payload, fn)` | `SvelteHead` | Collect `<head>` content |
| `$.element(payload, tag, attrs, children)` | `SvelteElement` | `<svelte:element>` rendering |
| `$.derived(fn)` | `CallExpression`, `PropertyDefinition` | `$derived` in SSR (computed once) |
| `$.snapshot(expr)` | `CallExpression` | `$state.snapshot` deep clone |
| `$.store_get` / `$.store_set` / `$.store_mutate` | `build_getter`, `build_assignment` | Auto-subscription protocol |
| `$.update_store` / `$.update_store_pre` | `UpdateExpression` | `$store++` / `$store--` |
| `$.unsubscribe_stores($$store_subs)` | post-processing (`transform-server.js`) | Subscription cleanup after render |
| `$.push` / `$.pop` | post-processing (`transform-server.js`) | Component context stack (dev/effects) |
| `$.push_element` / `$.pop_element` | `RegularElement`, `SvelteElement` (dev) | Element stack for improved error messages |
| `$.validate_dynamic_element_tag` / `$.validate_void_dynamic_element` | `SvelteElement` (dev) | `<svelte:element>` guards |
| `$.validate_snippet_args` / `$.prevent_snippet_stringification` | `SnippetBlock` (dev) | Snippet misuse guards |
| `$.maybe_selected` / `$.valueless_option` | `RegularElement` | `<select>`/`<option>` value semantics |
| `$.css_props` | `build_inline_component` | Component-scoped CSS custom properties (`--foo={…}`) |
| `$.props_id` / `$.bind_props` | post-processing (`transform-server.js`) | Hydration IDs, bound-prop propagation |

## 5. Relationship to Other Modules

- **[compiler-analyzer](compiler-analyzer.md)** — supplies `Scope`, `Binding` kinds (`store_sub`, `bindable_prop`, `state`, `legacy_reactive`), rune detection (`get_rune`) and node `metadata` (e.g. `contains_group_binding`, `svg`/`mathml`). Every decision in this module reads analysis results; nothing is re-derived here.
- **[compiler-transformer_client-transform](compiler-transformer_client-transform.md)** — the DOM counterpart. Mirrors the visitor layout but builds reactive templates instead of HTML strings. Both share `clean_nodes`, namespace inference and `visit_assignment_expression` from [compiler-transformer_shared-infrastructure](compiler-transformer_shared-infrastructure.md).
- **[compiler-transformer_css-transform](compiler-transformer_css-transform.md)** — `render_stylesheet` is invoked by `server_component` when `css: 'injected'`, producing the `$$css` object added to the payload.
- **[server-runtime](server-runtime.md)** — implements every `$.` helper referenced by generated code, plus the `BLOCK_OPEN`/`BLOCK_CLOSE`/`EMPTY_COMMENT` hydration constants. The contract between the two modules is: *this module emits calls, that module implements them*.
- **[compiler-core_type_definitions](compiler-core_type_definitions.md)** — `CompileResult.js`/`CompileResult.server.js` shape and AST node types consumed here.
