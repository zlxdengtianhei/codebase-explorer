# Server Transform Shared Utils

> **Module:** `compiler-transformer_server-transform_shared-utils`
> **Location:** `packages/svelte/src/compiler/phases/3-transform/server/visitors/shared/utils.js`

## 1. Introduction

This module is the **shared utility layer of the server-side code generator** in the Svelte compiler. During the *3-transform* phase, every server visitor (elements, fragments, blocks, components, snippets, script nodes) must emit JavaScript that appends HTML to the SSR payload buffer (`$$payload.out`). This module centralizes the code-building primitives needed to do that consistently and efficiently:

| Export | Kind | Purpose |
| --- | --- | --- |
| `process_children` | function | Walks a list of template child nodes, coalescing adjacent text/comments/expression tags into single HTML template literals and delegating structural nodes back to the visitor |
| `build_attribute_value` | function | Compiles an attribute value (static text, dynamic expression, or mixed chunks) into a single estree expression |
| `build_template` | function | Merges a stream of strings/expressions/statements into minimal `$$payload.out.push(...)` (or assignment) statements |
| `build_getter` | function | Rewrites identifiers referencing `$store` subscriptions into `$.store_get(...)` runtime calls |
| `block_open`, `block_close` | constants | Hydration boundary marker literals (`BLOCK_OPEN` / `BLOCK_CLOSE`) delimiting if/each/await/key blocks in SSR output |
| `empty_comment` | constant | Empty-comment literal (`EMPTY_COMMENT`) used as an anchor and to keep adjacent text nodes separate |

Because it is shared by **all** server visitors, this module is the choke point where the analyzer's static-evaluation information, the AST builder DSL, and the server runtime's escape/stringify conventions meet. Changes here affect the shape of every SSR payload statement the compiler emits.

For the overall phase architecture see [compiler-transformer](compiler-transformer.md); for the client-side counterpart utilities see [compiler-transformer_client-transform_infrastructure](compiler-transformer_client-transform_infrastructure.md).

---

## 2. Position in the Compiler Pipeline

The module sits at the leaf of the server transform stage. It is *stateless* — all state (scope, options, template accumulator) is passed in through the `ComponentContext` / `ServerTransformState` objects defined in [compiler-transformer_shared-infrastructure](compiler-transformer_shared-infrastructure.md).

```mermaid
flowchart TB
    subgraph Pipeline["Compiler Pipeline (Language Toolchain)"]
        P["1-parse<br/>(compiler-parser)"] --> A["2-analyze<br/>(compiler-analyzer: scope, visitors, CSS)"]
        A --> T["3-transform<br/>(compiler-transformer)"]
    end

    subgraph ServerXform["3-transform / server/ visitors"]
        direction TB
        FR["Fragment<br/>(template-rendering)"]
        EL["RegularElement / SvelteElement / TitleElement<br/>(template-rendering)"]
        CF["IfBlock / EachBlock / AwaitBlock / KeyBlock<br/>(control-flow)"]
        CO["Component / RenderTag / SnippetBlock / SlotElement<br/>(components-snippets)"]
        SC["Identifier / AssignmentExpression / …<br/>(script-transform)"]
        SHARED["🟢 shared/utils.js<br/>(THIS MODULE)"]
    end

    T --> ServerXform
    FR --> SHARED
    EL --> SHARED
    CF --> SHARED
    CO --> SHARED
    SC --> SHARED

    subgraph Runtime["Server Runtime (SSR output dependencies)"]
        RT["$.escape / $.stringify / $.store_get<br/>$$payload.out (server-runtime)"]
    end

    SHARED -- "emits calls into" --> Runtime
```

The generated code emitted by this module calls into the server runtime (`packages/svelte/src/internal/server`), documented under [Server-Side_Rendering___Cross-Target_Runtime_Services](Server-Side_Rendering___Cross-Target_Runtime_Services.md). The compiler itself never executes that code — it only produces it.

---

## 3. Component Reference

### 3.1 `process_children`

```js
function process_children(nodes, { visit, state })
```

Processes an array of template nodes, joining sibling **text / comment / expression-tag** runs and recursing into everything else. This is the single entry point every structural server visitor uses to render element/fragment children.

**Algorithm:**

1. Iterate `nodes`. Nodes of type `Text`, `Comment`, or `ExpressionTag` are buffered into a `sequence`.
2. On the first structural node (element, block, component, directive target, …):
   - `flush()` the buffered sequence into one template literal pushed onto `state.template`;
   - delegate the structural node to `visit(node, { ...state })` (a shallow state copy so nested visitors may extend state without affecting siblings).
3. Flush any remaining sequence after the loop.

**Inside `flush()` — building one template literal:**

| Sequence node | Handling |
| --- | --- |
| `Text` | `escape_html(node.data)` appended to the current quasi's `cooked` string |
| `Comment` | Preserved verbatim as `<!--${node.data}-->` in the quasi |
| `ExpressionTag` | Statically evaluated via `state.scope.evaluate(...)`:<br>• `evaluated.is_known` → the value (coerced to string, `null`/`undefined` → `''`) is HTML-escaped and **inlined** into the quasi (constant folding at compile time)<br>• otherwise → the visited expression is wrapped as `$.escape(<expr>)` and appended to the template's `expressions` |

Finally, every quasi's `raw` value is derived from `cooked` via `sanitize_template_string` (escapes backticks, `${` and `\` so the generated template literal is syntactically safe), and the result is pushed as `b.template(quasis, expressions)`.

**Key design points:**

- *Fewer payload writes*: maximal runs of static + dynamic text collapse into a single template expression per run instead of one statement per node.
- *Compile-time escaping*: static HTML is escaped once by the compiler; runtime escaping (`$.escape`) is only paid for genuinely dynamic content.
- *Constant folding*: expressions the analyzer proved static (see [compiler-analyzer_scope](compiler-analyzer_scope.md)) never reach the generated code.
- *Hydration fidelity*: comments are preserved in the payload so the client can re-hydrate against the same DOM shape (markers, see §3.4).

### 3.2 `build_attribute_value`

```js
function build_attribute_value(value, context, trim_whitespace = false, is_component = false)
```

Compiles an `AST.Attribute`'s `value` (either `true`, a single `Text`/`ExpressionTag` chunk, or an array of chunks) into one estree `Expression`.

| Input shape | Result |
| --- | --- |
| `value === true` (boolean/empty attribute) | `true` literal — presence semantics are decided by the calling attribute builder |
| Single `Text` chunk | `b.literal(data)`; if `trim_whitespace`, whitespace runs are collapsed via `regex_whitespaces_strict` and trimmed; text is HTML-escaped with `escape_html(data, true)` (attribute-context escaping, includes quotes) **unless** `is_component` (component props are raw values, never HTML) |
| Single expression chunk | The visited expression, passed through untouched (no `$.stringify` wrapper — the caller decides coercion) |
| Multiple chunks (mixed text/expressions) | A template literal (`b.template`): text quasis carry the (optionally trimmed) raw text, dynamic chunks become `$.stringify(<expr>)` calls |

The multi-chunk branch is where attribute-specific dynamics differ from body text: instead of `$.escape`, dynamic attribute chunks are coerced with the runtime's `$.stringify` (returns strings as-is, `null`/`undefined` → `''`, everything else stringified). Final quoting/escaping of the attribute *name=value* pair is the responsibility of the attribute-building visitor that consumes this expression.

### 3.3 `build_template`

```js
function build_template(template, out = b.id('$$payload.out'), operator = 'push')
```

Converts the template accumulator — an interleaved array of string expressions, template literals and full statements — into a minimal statement list:

- Adjacent string-ish parts (`Literal`, `TemplateLiteral` quasis, expressions) are **coalesced** into the fewest possible calls:
  - default `operator = 'push'` → `$$payload.out.push(`template`)` statements;
  - an assignment operator (e.g. `'='`, `'+='`) → `$$payload.title =` / `+=` template, used e.g. by `TitleElement` to build the head's title buffer.
- Statements (detected by the internal `is_statement` helper: `*Statement` / `*Declaration`) are emitted in order, flushing any pending string run first.

This is what turns `state.template` (built up by visitors + `process_children`) into the executable payload statements returned by `Fragment` and friends.

### 3.4 Hydration marker constants

```js
block_open   // b.literal(BLOCK_OPEN)
block_close  // b.literal(BLOCK_CLOSE)
empty_comment // b.literal(EMPTY_COMMENT)
```

These constants wrap the SSR hydration markers from `packages/svelte/src/internal/server/hydration.js`:

- **`BLOCK_OPEN` / `BLOCK_CLOSE`** are comment-based markers the server writer emits around conditional/iterative content (`IfBlock` unshifts `block_open` into the branch and appends `block_close` after). During hydration the client runtime matches or removes DOM nodes between the markers, making SSR hydration resilient to branch mismatches.
- **`EMPTY_COMMENT`** is inserted to (a) provide an anchor node where a template must not be glued to preceding content (e.g. text-first fragments in `Fragment`) and (b) keep otherwise-adjacent text nodes distinguishable in the serialized payload.

See also the control-flow visitors in [compiler-transformer_server-transform_control-flow](compiler-transformer_server-transform_control-flow.md).

### 3.5 `build_getter`

```js
function build_getter(node, state)
```

Resolves an identifier during server script transformation:

- No binding, or the identifier *is* its own declaration node → returned unchanged.
- `binding.kind === 'store_sub'` → the `$store` prefix identifier is rewritten to
  `$.store_get(($$store_subs ??= {}), '<name>', <store>)`, lazily initializing the per-render subscription cache `$$store_subs` and delegating to the runtime's store handling (see [server-runtime_store-integration](server-runtime_store-integration.md)).

---

## 4. Data Flow

### 4.1 End-to-end template generation

```mermaid
sequenceDiagram
    autonumber
    participant V as Server Visitor<br/>(e.g. Fragment / RegularElement)
    participant CN as clean_nodes<br/>(whitespace hoisting)
    participant PC as process_children
    participant EV as Scope.evaluate<br/>(analyzer)
    participant ESC as escape_html
    participant ACC as state.template
    participant BT as build_template
    participant OUT as Generated SSR code

    V->>CN: child nodes
    CN-->>V: hoisted + trimmed nodes
    V->>PC: process_children(trimmed, context)
    loop each node
        alt Text / Comment / ExpressionTag
            PC->>PC: buffer into sequence
        else structural node
            PC->>ACC: flush sequence → template literal
            PC->>V: visit(node, {...state})
        end
    end
    PC->>EV: evaluate(ExpressionTag)
    alt statically known
        PC->>ESC: escape_html(value)
        PC->>ACC: inline into quasi.cooked
    else dynamic
        PC->>ACC: $.escape(expr) → expressions
    end
    PC->>ACC: final flush
    V->>BT: build_template(state.template)
    BT-->>OUT: $$payload.out.push(`…${$.escape(x)}…`)
```

### 4.2 Worked example

Given the markup `<div class={cls}>Hi {name}!</div>` with `name` dynamic and `cls` dynamic:

```js
// conceptually generated by visitors using this module's helpers
$$payload.out.push(`<div class="`);
$$payload.out.push($.stringify(cls));   // build_attribute_value (multi/single chunk path)
$$payload.out.push(`">Hi ${$.escape(name)}!</div>`); // process_children + build_template coalescing
```

Static segments (`">Hi `, `!`) are compile-time escaped and merged into a single template; only genuinely dynamic slots pay runtime cost. A statically evaluable `{'<b>'}` would instead be inlined (escaped) with **no** runtime expression at all.

### 4.3 Attribute value decision flow

```mermaid
flowchart TD
    A["AST.Attribute.value"] --> B{value === true?}
    B -- yes --> T["return b.true<br/>(boolean attribute)"]
    B -- no --> C{single chunk?}
    C -- Text --> D{trim_whitespace?}
    D -- yes --> E["collapse ws + trim"]
    D -- no --> F["escape_html(data, true)<br/>(skip if is_component)"]
    E --> F
    C -- ExpressionTag --> G["context.visit(expr)"]
    C -- array of chunks --> H["template literal:<br/>quasis = raw text chunks<br/>expressions = $.stringify(visit(expr))"]
```

---

## 5. Dependencies

### 5.1 Upstream (what this module consumes)

```mermaid
flowchart LR
    subgraph THIS["shared/utils.js"]
        PC[process_children]
        BAV[build_attribute_value]
        BT[build_template]
        BG[build_getter]
        MK[block_open/close, empty_comment]
    end

    B1["compiler-core_ast_builders<br/>(b.literal, b.template, b.call,<br/>b.quasi, b.stmt, b.assignment…)"]
    SC["compiler-analyzer_scope<br/>Scope.evaluate → constant folding"]
    ES["src/escaping.js<br/>escape_html"]
    ST["compiler utils<br/>sanitize_template_string"]
    PT["compiler/phases/patterns.js<br/>regex_whitespaces_strict"]
    HY["internal/server/hydration.js<br/>BLOCK_OPEN / BLOCK_CLOSE / EMPTY_COMMENT"]
    TY["compiler-transformer_shared-infrastructure<br/>ComponentContext, ServerTransformState"]

    PC --> B1
    PC --> SC
    PC --> ES
    PC --> ST
    BAV --> B1
    BAV --> ES
    BAV --> PT
    BT --> B1
    BG --> B1
    MK --> HY
    PC -.-> TY
    BAV -.-> TY
```

- **Builders (`b`)** — the estree construction DSL from [compiler-core_ast_builders](compiler-core_ast_builders.md). Every emission in this module goes through it.
- **Scope analysis** — `state.scope.evaluate` provides the `is_known` constant folding in `process_children`; maintained by the analyzer ([compiler-analyzer_scope](compiler-analyzer_scope.md)).
- **`escape_html`** — single source of truth for HTML escaping, shared with the runtime.
- **`sanitize_template_string`** — makes accumulated HTML safe to embed in a JS template literal.
- **Hydration markers** — shared contract with the client hydration code, ensuring server output and client expectations never drift.

### 5.2 Downstream (who consumes this module)

All server visitors listed under [compiler-transformer_server-transform](compiler-transformer_server-transform.md):

| Consumer group | Typical usage |
| --- | --- |
| [template-rendering](compiler-transformer_server-transform_template-rendering.md) (`Fragment`, `RegularElement`, `SvelteElement`, `SvelteHead`, `SvelteBoundary`, `HtmlTag`, `TitleElement`) | `process_children` for bodies; `build_attribute_value` for attributes (e.g. `<select value>`); `build_template` to finalize; `empty_comment` for text-first fragments; `build_template(…, $$payload.title, '=')` for `<title>` |
| [control-flow](compiler-transformer_server-transform_control-flow.md) (`IfBlock`, `EachBlock`, `AwaitBlock`, `KeyBlock`) | `block_open` / `block_close` markers around branches |
| [components-snippets](compiler-transformer_server-transform_components-snippets.md) (`Component`, `RenderTag`, `SnippetBlock`, `SlotElement`) | `process_children` for fallback/snippet bodies; `build_attribute_value(..., is_component = true)` for raw props |
| [script-transform](compiler-transformer_server-transform_script-transform.md) (`Identifier`, `AssignmentExpression`, `UpdateExpression`, …) | `build_getter` for `$store` subscriptions; `build_template` for statement/flush merging |

---

## 6. Integration: How a Fragment Becomes a Payload Statement

The `Fragment` visitor illustrates the canonical collaboration between this module and its consumers:

```mermaid
flowchart TB
    subgraph FragmentVisitor["Fragment visitor"]
        F1["clean_nodes(...) — hoist + trim"] --> F2["new state { init, template }"]
        F2 --> F3{"is_text_first?"}
        F3 -- yes --> F4["push empty_comment"]
        F3 -- no --> F5
        F4 --> F5["process_children(trimmed, context)"]
        F5 --> F6["b.block([...init, ...build_template(template)])"]
    end

    subgraph IfBlockVisitor["IfBlock visitor (control flow)"]
        I1["consequent.body.unshift(push(block_open))"] --> I2["state.template.push(b.if(...), block_close)"]
    end

    F6 --> M["merged into parent's template accumulator"]
    I2 --> M
    M --> BT["build_template at root"] --> OUT["$$payload.out.push(...) statements"]
```

This cooperative design — visitors push *parts*, `build_template` merges them — keeps each visitor simple while guaranteeing optimal output shape.

---

## 7. Design Considerations & Invariants

1. **Escaping correctness is centralized.** Body text and static values escape via `escape_html`; attribute text escapes with the attribute flag (`true`); dynamic body values defer to runtime `$.escape`; dynamic attribute chunks defer to `$.stringify` + the attribute builder. Never bypass these paths when adding a new visitor.
2. **Compile-time evaluation is opportunistic.** `process_children` only trusts `scope.evaluate(...).is_known`; anything else stays dynamic. This keeps folding sound even with stores, props, or mutable state.
3. **State is copied, never mutated across branches.** `visit(node, { ...state })` in `process_children` and the `{ ...state, template: [], init: [] }` pattern in `RegularElement` isolate nested template accumulators (e.g. valueless `<option>`, textarea fallback bodies).
4. **Hydration contract.** `BLOCK_OPEN`/`BLOCK_CLOSE`/`EMPTY_COMMENT` come from `internal/server/hydration.js` and must match what the client hydrator consumes; they are re-exported here as ready-made literals so visitors cannot typo them.
5. **Output compactness.** `build_template`'s coalescing plus `process_children`' run-buffering minimizes the number of `push` calls, directly reducing SSR bundle size and per-render overhead.
6. **Server/client parity.** The client transform has its own infrastructure ([compiler-transformer_client-transform_infrastructure](compiler-transformer_client-transform_infrastructure.md)); this module deliberately shares *nothing* with it beyond the AST/builders, because DOM template creation and string payload writing have different optimization goals.

---

## 8. Related Modules

- [compiler-transformer_server-transform](compiler-transformer_server-transform.md) — parent stage; all server visitors
- [compiler-transformer_server-transform_template-rendering](compiler-transformer_server-transform_template-rendering.md) — element/fragment/head visitors (heaviest consumers)
- [compiler-transformer_server-transform_control-flow](compiler-transformer_server-transform_control-flow.md) — block visitors using hydration markers
- [compiler-transformer_server-transform_components-snippets](compiler-transformer_server-transform_components-snippets.md) — component, snippet, slot, render-tag visitors
- [compiler-transformer_server-transform_script-transform](compiler-transformer_server-transform_script-transform.md) — script-level rewrites using `build_getter`
- [compiler-transformer_shared-infrastructure](compiler-transformer_shared-infrastructure.md) — `TransformState` / context types
- [compiler-core_ast_builders](compiler-core_ast_builders.md) — the `b` builder DSL used throughout
- [compiler-analyzer_scope](compiler-analyzer_scope.md) — scope & static evaluation powering constant folding
- [Server-Side_Rendering___Cross-Target_Runtime_Services](Server-Side_Rendering___Cross-Target_Runtime_Services.md) — the runtime (`$.escape`, `$.stringify`, `$.store_get`, `$$payload`) the generated code calls into
- [Compiler_Pipeline___Language_Toolchain](Compiler_Pipeline___Language_Toolchain.md) — overall compilation pipeline
