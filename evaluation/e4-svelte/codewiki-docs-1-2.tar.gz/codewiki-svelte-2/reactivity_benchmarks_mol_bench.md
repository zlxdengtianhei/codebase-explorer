# Reactivity Benchmarks — mol_bench (`reactivity_benchmarks_mol_bench`)

## 1. Introduction

`reactivity_benchmarks_mol_bench` is a micro-benchmark module that measures the throughput of Svelte's
fine-grained reactivity engine (the signal graph in `svelte/internal/client`) against the well-known
**"moltar" (Mol) benchmark workload**: a fixed, hand-tuned dependency graph with a diamond-shaped
topology, an expensive derived computation, a custom equality check, and a conditional dependency.
The workload is exercised by repeatedly pushing batches of state updates through the graph and
measuring how fast the engine propagates them to its effects.

The module exports two variants of the same workload:

| Export | Signal-graph creation context | What it isolates |
| --- | --- | --- |
| `mol_bench_owned()` | Inside an `$.effect_root(...)` scope — signals are *owned* and destroyed with the root | Full engine path incl. ownership bookkeeping & teardown |
| `mol_bench_unowned()` | At top level of the benchmark function — signals have no owning reaction | Detached (unowned) signal creation and propagation |

Comparing the two timings quantifies the overhead (or savings) of ownership tracking in the
[Client Runtime Engine (Reactivity & DOM Rendering)](client_runtime_engine_reactivity_dom_rendering.md).

This module is one of three micro-benchmark suites in
[Reactivity Benchmarks](reactivity_benchmarks.md), alongside
[kairo topology suites](reactivity_benchmarks_kairo_suites.md) and
[sbench fan-in/out suites](reactivity_benchmarks_sbench.md), within the
[Engineering Tooling (Benchmarks, Verification & Playground)](engineering_tooling_benchmarks_verification_playground.md) module.

---

## 2. Module identity

| Property | Value |
| --- | --- |
| File | `benchmarking/benchmarks/reactivity/mol_bench.js` |
| Exports | `mol_bench_owned()`, `mol_bench_unowned()` (both `async`) |
| Internal helpers | `fib(n)`, `hard(n)`, `numbers`, `setup()` |
| Harness dependency | `assert`, `fastest_test` from `benchmarking/utils.js` |
| Runtime dependency | `svelte/internal/client` (re-exported as `$`) |
| Output contract | `{ benchmark: string, time: string, gc_time: string }` |
| Correctness gate | `assert(res[0] === 3198 && res[1] === 1601 && res[2] === 3195 && res[3] === 1598)` |

---

## 3. Architecture & component relationships

The module is a pure consumer of the client reactivity engine: it constructs a signal graph through
the internal runtime API, drives it with batched updates, and times the propagation. All timing and
verification plumbing lives in the shared benchmark harness utilities.

```mermaid
flowchart TB
    subgraph tooling["Engineering Tooling — benchmark harness"]
        UTILS["benchmarking/utils.js<br/>assert(cond) · fastest_test(times, fn)"]
    end

    subgraph module["reactivity_benchmarks_mol_bench"]
        SETUP["setup()<br/>builds graph, returns { run, destroy }"]
        OWNED["mol_bench_owned()"]
        UNOWNED["mol_bench_unowned()"]
        RUN["run(i)<br/>2 × flush(update batch) + assert"]
        HELPERS["fib(n) · hard(n)<br/>numbers = [0..4]"]
        SETUP --> RUN
        HELPERS --> SETUP
        OWNED --> SETUP
        UNOWNED --> SETUP
    end

    subgraph runtime["Client Runtime Engine (Reactivity & DOM Rendering)"]
        CRE["client-reactivity-engine<br/>state · set · get<br/>derived (user_derived) · flush<br/>effect_root · render_effect"]
    end

    OWNED -->|"$ .effect_root"| CRE
    UNOWNED -->|"top-level creation"| CRE
    RUN -->|"$ .flush / $ .set / $ .get"| CRE
    OWNED -->|"timed loop ×10"| UTILS
    UNOWNED -->|"timed loop ×10"| UTILS
    RUN -->|"result check"| UTILS
```

### Component responsibilities

| Component | Responsibility |
| --- | --- |
| `fib(n)` | Naive recursive Fibonacci; `fib(16) === 1597` (~2,600 calls). Amplifies the cost of every derived recomputation so propagation overhead dominates wall time. |
| `hard(n)` | `n + fib(16)` — the "expensive node" workload used by `E`, `F` and the effects. |
| `numbers` | Constant array `[0, 1, 2, 3, 4]` mapped inside derived `D`. |
| `setup()` | Builds the full signal graph inside `$.effect_root`, returns `{ destroy, run }`. `run(i)` performs two batched update waves and asserts the exact expected outputs. |
| `mol_bench_owned()` | Warm-up (10 JIT loops), then `setup()` **inside an outer `$.effect_root`** (owned signals); runs 10,000 iterations × 10 repeats, reports the fastest. |
| `mol_bench_unowned()` | Identical, but `setup()` runs **outside any reaction scope** (unowned signals). |

---

## 4. Benchmark workload — the signal graph

`setup()` wires a seven-node graph with three render effects. `A` and `B` are state signals; `C`,
`D`, `E`, `F`, `G` are deriveds; `G` feeds two effects and `F` feeds one.

```mermaid
flowchart LR
    A(("A : state")):::state --> C
    B(("B : state")):::state --> C
    A --> D
    B --> D

    C(("C<br/>(A%2)+(B%2)")):::derived --> E
    A --> E
    D(("D<br/>numbers.map(+A%2 −B%2)<br/>custom .equals")):::derived --> E
    D --> F
    B --> F

    E(("E<br/>hard(C+A+D[0])")):::derived --> G
    C(("C")):::derived --> G
    D(("D[0]")):::derived --> G
    F(("F<br/>hard(D[0] && B)")):::derived --> G

    G(("G<br/>C + (C‖E%2) + D[0] + F")):::derived --> FX1["render_effect<br/>res.push(hard(G))"]
    G --> FX2["render_effect<br/>res.push(G)"]
    F --> FX3["render_effect<br/>res.push(hard(F))"]

    classDef state fill:#e1f5fe,stroke:#0288d1
    classDef derived fill:#fff3e0,stroke:#f57c00
```

### Why this graph is interesting

The moltar workload is designed to punish engines that propagate *everything* on every update.
Three properties are deliberately encoded:

1. **Custom equality on `D`** — `D.equals` performs an element-wise comparison against the stored
   value (`this.v`). Across the benchmark's update pattern, `D` recomputes to the same array
   (`[0,1,2,3,4]`) every time, so a correct engine must *cut propagation* at `D` and never re-run
   dependents `E`, `F` or the `G` parts that depend on `D[0]` alone.
2. **Stable derived `F`** — `D[0]` is always `0` and `hard(0) === 1597` regardless of `B`, so `F`'s
   value never changes. Consequently the third render effect must **never fire** during the timed
   runs; only `G`'s two effects fire (once per flush). The final `assert` verifies exactly this:
   `res = [hard(G)₁, G₁, hard(G)₂, G₂] = [3198, 1601, 3195, 1598]`.
3. **Conditional dependency** — in `G`, the expression `(C || E % 2)` short-circuits: whenever
   `C` is truthy, `$.get(E)` is not called, so `E` becomes a *dynamic* (dropped) dependency. This
   exercises the engine's dependency re-collection path in `get()` (see the
   [client reactivity engine](client_reactivity_engine.md) documentation).

### One `run(i)` — two propagation waves

```mermaid
flowchart TB
    START(["run(i)"]) --> CLEAR["res.length = 0"]
    CLEAR --> B1["flush #1:<br/>set(B, 1)<br/>set(A, 1 + 2i)"]
    B1 --> P1["propagate: C=2, D unchanged, E=hard(3), F unchanged, G=1601<br/>effects fire: res += [hard(G)=3198, G=1601]"]
    P1 --> B2["flush #2:<br/>set(A, 2 + 2i)<br/>set(B, 2)"]
    B2 --> P2["propagate: C=0, D unchanged, E=hard(2), F unchanged, G=1598<br/>effects fire: res += [hard(G)=3195, G=1598]"]
    P2 --> CHK["assert(res[0]===3198 && res[1]===1601<br/>&& res[2]===3195 && res[3]===1598)"]
    CHK --> OK(["correct — F's effect never fired"])
```

Because the assertion pins exact numeric outcomes, `run(i)` doubles as a **regression test**: any
change to the engine that breaks dirty-checking, equality-based cut-off, or batching will throw
`Assertion failed` instead of silently producing wrong timings.

---

## 5. Execution flow

Both exported benchmarks follow the same protocol; they differ only in where `setup()` is invoked.

```mermaid
sequenceDiagram
    participant H as Harness (compare runner)
    participant B as mol_bench_owned / mol_bench_unowned
    participant U as benchmarking/utils.js
    participant R as svelte/internal/client

    H->>B: await benchmark()
    B->>R: 10 × { setup(); run(0); destroy() }  %% JIT warm-up
    B->>B: setup() → graph { destroy, run }
    Note over B: owned variant: setup() runs inside<br/>an outer $.effect_root scope
    B->>U: fastest_test(10, fn)
    loop 10 measured repetitions
        U->>B: fn()
        loop 10,000 iterations
            B->>B: run(i) → 2 × flush(set A, set B) + assert
            B->>R: $.set / $.get / $.flush on signal graph
        end
        U-->>U: record { time, gc_time }
    end
    U-->>B: fastest timing { time, gc_time }
    B->>R: destroy() (owned: destroy both roots)
    B-->>H: { benchmark, time, gc_time } (strings, 2 dp)
```

Key measurements:

- **Inner loop**: `10,000` × `run(i)` per repetition → `20,000` flush waves and `40,000` state
  writes per repetition.
- **Repetitions**: `fastest_test(10, fn)` runs the whole loop `10` times and keeps the *fastest*
  result, damping scheduler/GC noise.
- **`time`**: wall time of the best repetition; **`gc_time`**: additional timing captured by the
  tracked runner (forcing GC via the harness in `benchmarking/utils.js`), indicating how much
  garbage the allocation-heavy signal graph produces.

---

## 6. Owned vs. unowned variants

The single behavioral difference between the two exports is **when and where the signal graph is
created**:

```mermaid
flowchart TB
    subgraph owned["mol_bench_owned()"]
        O1["const destroy_owned = $.effect_root(() => { … setup() … })"]
        O2["signals created while an effect root is active<br/>→ owned by the root, reaped on destroy()"]
        O1 --> O2
    end
    subgraph unowned["mol_bench_unowned()"]
        U1["const { run, destroy } = setup()"]
        U2["signals created with no active reaction<br/>→ flagged UNOWNED, detached lifetime"]
        U1 --> U2
    end
```

- **Owned**: `$.effect_root` establishes an ownership scope; every `state`/`derived` created within
  it is registered as a child, and calling the returned destroy function tears the whole graph down.
  This measures the engine's realistic component-scoped behavior, including ownership bookkeeping
  during graph construction and teardown cost.
- **Unowned**: signals are created outside any reaction. In the engine, a derived read with no
  active reaction/owner is marked with the `UNOWNED` flag (visible in `get()`'s parent-flag
  handling), and the graph survives until explicitly destroyed. This variant isolates propagation
  speed from ownership/teardown overhead.

Comparing `time` (and `gc_time`) between the two exports quantifies the price of ownership
management — information used when tuning scope/owner handling in the
[client reactivity engine](client_reactivity_engine.md).

---

## 7. Dependencies

| Dependency | Provided by | Used for |
| --- | --- | --- |
| `assert`, `fastest_test` | `benchmarking/utils.js` (shared harness, part of [Engineering Tooling](engineering_tooling_benchmarks_verification_playground.md)) | correctness gate; best-of-N timing with GC accounting |
| `$.state`, `$.set`, `$.get` | `svelte/internal/client` — [client-reactivity-engine](client_reactivity_engine.md) | source signals, writes, tracked reads (dependency registration) |
| `$.derived` (`user_derived`) | `svelte/internal/client` | the five computed nodes, incl. the custom-equality `D` |
| `$.flush` | `svelte/internal/client` — batching/scheduling | synchronous batch semantics for the two update waves |
| `$.effect_root`, `$.render_effect` | `svelte/internal/client` — [effects subsystem](client_reactivity_engine.md) | ownership scopes; the three output-recording effects |

For how the engine implements these primitives (signal flags, dirty checking, batch queues,
scheduling loop), see the
[Client Runtime Engine (Reactivity & DOM Rendering)](client_runtime_engine_reactivity_dom_rendering.md)
documentation — it is not duplicated here.

### Sibling suites

- [reactivity_benchmarks_kairo_suites](reactivity_benchmarks_kairo_suites.md) — parameterized
  graph topologies (deep, broad, diamond, triangle, mux, …), owned/unowned pairs.
- [reactivity_benchmarks_sbench](reactivity_benchmarks_sbench.md) — fan-in/fan-out scaling sweeps
  (1→1, 1→1000, 1000→1, …) for signal creation and computation counts.

`mol_bench` complements these by pinning one *specific* dense graph whose correctness and
performance are both assertable, making it useful as a fast sanity check before comparing full
suites with the harness in [benchmark_comparison](engineering_tooling_benchmarks_verification_playground.md).

---

## 8. Output contract

Each export resolves to a plain result object consumed by the comparison runner:

```javascript
{
  benchmark: 'mol_bench_owned' | 'mol_bench_unowned',
  time: '<wall time of fastest repetition, 2 decimal places>',
  gc_time: '<forced-GC time of fastest repetition, 2 decimal places>'
}
```

Interpretation guidelines:

- **Lower `time` is better**; it reflects raw propagation throughput of the signal graph.
- **`gc_time`** highlights allocation pressure — relevant when evaluating changes that touch
  dependency arrays (`new_deps`/`deps` reuse in `get()`), derived caching, or batch objects.
- A thrown `Assertion failed` means the engine produced wrong results — treat it as a correctness
  regression, not a slow benchmark.

---

## 9. Extending / maintaining this benchmark

- Keep `fib(16)` and the expected assertion values stable: they encode the moltar workload's
  contract; changing them breaks comparability across engine versions.
- Any new benchmark should follow the same shape as `setup()`: build graph → return `{ run,
  destroy }` → gate `run` with exact assertions → report via `fastest_test` + the standard result
  object so the shared compare tooling can ingest it.
- The owned/unowned pairing should be preserved when adding variants (e.g., new graph shapes under
  [reactivity_benchmarks](reactivity_benchmarks.md)), so ownership overhead remains measurable
  across all suites.
