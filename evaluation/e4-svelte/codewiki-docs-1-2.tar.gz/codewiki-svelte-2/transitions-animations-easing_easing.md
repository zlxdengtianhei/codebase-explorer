# Easing (transitions-animations-easing_easing)

## 1. Purpose and Scope

`packages/svelte/src/easing/index.js` is a **dependency-free, pure-function library of 31 easing functions** used to shape the progress of animations and transitions. It is the deepest leaf of the `transitions-animations-easing` sub-module tree under the [Public API & Built-in Feature Surface](public-api.md), exposed publicly as `svelte/easing`.

Every export is a classic "ease" of the form:

```js
/**
 * @param {number} t  progress, normally in [0, 1]
 * @returns {number}  eased progress
 */
(t) => number
```

The module provides:

- **`linear`** — the identity `f(t) = t`
- **10 curve families**, each as an `In` / `Out` / `InOut` triad: `back`, `bounce`, `circ`, `cubic`, `elastic`, `expo`, `quad`, `quart`, `quint`, `sine` (30 functions)
- **`bounceOut`** is additionally meaningful as the shared mathematical base from which `bounceIn` and `bounceInOut` are derived

The code is adapted from [mattdesl/eases](https://github.com/mattdesl/eases) (MIT). It contains **no state, no DOM access, no reactivity and no side effects**, which makes every export fully tree-shakeable (continuously verified by `packages/svelte/scripts/check-treeshakeability.js` in the Engineering Tooling area).

For how easing values are *produced into motion* (the transition/animation factories), see the sibling docs [transitions-animations-easing_transitions.md](transitions-animations-easing_transitions.md) and [transitions-animations-easing_animations.md](transitions-animations-easing_animations.md).

## 2. Design Contract

| Property | Guarantee |
|----------|-----------|
| **Signature** | `(t: number) => number` — the type the sibling modules publish as `EasingFunction` |
| **Domain** | `t` is normalized progress (elapsed / duration), conventionally `[0, 1]` |
| **Range** | Typically `[0, 1]`; `back*` and `elastic*` deliberately overshoot outside `[0, 1]` mid-flight before converging to `1` |
| **Purity** | No side effects, no closures over mutable state; safe to call any number of times with any `t` |
| **Endpoint fidelity** | `f(0) === 0` and `f(1) === 1` for all functions (with explicit numeric guards where floating-point math would otherwise be inexact — see §6) |
| **Tree-shakeability** | Independent named ESM exports, zero side effects — a bundle importing only `cubicOut` ships only `cubicOut` |
| **Target** | Isomorphic: usable identically in client and server bundles (it is pure math), though it only becomes *observable* through client-side animation |

> **Style note for readers:** several triad implementations intentionally mutate their local parameter copy (`t *= 2`, `t -= 2`, `--t`). This is harmless because parameters are pass-by-value scalars, and it keeps the closed-form expressions compact.

## 3. Architecture and Dependencies

The easing module sits at the very bottom of the motion stack: it **depends on nothing** in the codebase and is consumed by the transition factories, the FLIP animation, the `tweened` store, and — at frame time — by the client runtime's animation driver.

```mermaid
flowchart TB
    subgraph Public["Public API & Built-in Feature Surface"]
        subgraph TAE["transitions-animations-easing"]
            TR["transition/index.js<br/>fade · blur · fly · slide · scale · draw · crossfade"]
            AN["animate/index.js<br/>flip"]
            EA["easing/index.js<br/>(this module — 31 pure functions)"]
        end
        MO["motion/tweened.js<br/>(see motion_tweened.md)"]
        TYPES["transition/public.d.ts + animate/public.d.ts<br/>publish EasingFunction parameter type"]
    end

    subgraph Runtime["Client Runtime Engine"]
        MGR["TransitionManager / each-item manager<br/>(client-dom-renderer_transitions)"]
        DRV["animate() driver — rAF frame loop"]
        LOOP["rAF scheduler<br/>(client-reactivity-engine_batching-scheduling)"]
    end

    TR -- "hard-wired defaults:<br/>linear, cubicOut, cubicInOut" --> EA
    AN -- "hard-wired default: cubicOut" --> EA
    MO -- "hard-wired default: linear" --> EA
    TR & AN -.->|"user-supplied easing<br/>(any (t)=>number)"| EA
    TYPES -.->|"type-level reference"| EA

    MGR --> DRV
    DRV --> LOOP
    DRV -- "per frame: t' = easing(elapsed / duration)" --> EA
```

### 3.1 Concrete consumption points

| Consumer | Import / usage | Default easing |
|----------|----------------|----------------|
| `fade(node, params)` | `easing = linear` default → passed through into `TransitionConfig.easing` | `linear` |
| `blur`, `fly`, `slide`, `scale`, `crossfade` | local `cubic_out` equivalents built into the transition module for bundle-size reasons; accept user easing via params | `cubicOut` (equivalent) |
| `draw(node, params)` | `easing = cubic_in_out` default | `cubicInOut` |
| `flip(node, {from,to}, params)` | `easing = cubicOut` default in `AnimationConfig` | `cubicOut` |
| `tweened(value, defaults)` | `easing = linear` default; applied as `fn(easing(elapsed / duration))` each frame | `linear` |
| Runtime `animate()` driver | takes `config.easing` from whatever config object it was handed and applies it every animation frame | (whatever the config carries) |

**Key architectural insight:** the easing library and the transition/animation factories are functionally coupled through these defaults, but the *runtime* accepts any `(t) => number` — user code can pass a custom easing function without importing `svelte/easing` at all. The library exists to provide well-tested, endpoint-correct curves.

## 4. Curve Family Catalog

```mermaid
flowchart LR
    E["svelte/easing"]

    subgraph ID["Identity"]
        LIN["linear — f(t) = t"]
    end

    subgraph POLY["Polynomial power curves"]
        QUAD["quad — t²"]
        CUBIC["cubic — t³"]
        QUART["quart — t⁴"]
        QUINT["quint — t⁵"]
    end

    subgraph EXP["Exponential"]
        EXPO["expo — 2^(10(t−1))<br/>guarded endpoints"]
    end

    subgraph TRIG["Trigonometric"]
        SINE["sine — quarter-wave sin/cos"]
        CIRC["circ — quarter-circle arcs<br/>√(1−t²)"]
    end

    subgraph OSC["Overshooting / oscillatory"]
        BACK["back — cubic with overshoot<br/>constant s = 1.70158"]
        ELASTIC["elastic — damped oscillation<br/>sin · 2^(10(t−1))"]
        BOUNCE["bounce — piecewise-quadratic<br/>impact approximation"]
    end

    E --> ID & POLY & EXP & TRIG & OSC
```

Each family (except `linear`) follows the same triad semantics:

| Variant | Shape over `[0, 1]` | Typical use |
|---------|---------------------|-------------|
| `*In` | starts slow, accelerates into the target | elements entering with momentum |
| `*Out` | starts fast, decelerates to rest | entrances/exits that should "settle" |
| `*InOut` | slow–fast–slow symmetric composition | camera-like, deliberate motion |

### 4.1 Function reference

| Function | Formula sketch | Notes |
|----------|----------------|-------|
| `linear` | `t` | identity; also mirrored inside the runtime as a local fallback |
| `quadIn/Out/InOut` | `t²`, `−t(t−2)`, symmetric piecewise | gentlest polynomial |
| `cubicIn/Out/InOut` | `t³`, `(t−1)³+1`, symmetric piecewise | the workhorse — default of `fly`, `slide`, `scale`, `crossfade`, `flip` |
| `quartIn/Out/InOut` | `t⁴`, `−8(t−1)⁴+1` … | sharper than cubic |
| `quintIn/Out/InOut` | `t⁵`, `−t⁵+1` … | sharpest polynomial |
| `sineIn/Out/InOut` | `1−cos(π/2·t)`, `sin(π/2·t)`, `−½(cos(πt)−1)` | smooth; `sineIn` has an ε-guard (§6) |
| `circIn/Out/InOut` | `1−√(1−t²)`, `√(1−(t−1)²)`, symmetric | quarter-circle arcs |
| `expoIn/Out/InOut` | `2^(10(t−1))`, `1−2^(−10t)`, symmetric | exact-`0`/`1` endpoint guards (§6) |
| `backIn/Out/InOut` | cubic with `s = 1.70158` (`s·1.525` for InOut) | overshoots ~10% past the target |
| `elasticIn/Out/InOut` | `sin(13πt/2)·2^(10(t−1))` ± variants | multiple damped oscillations |
| `bounceIn/Out/InOut` | piecewise quadratics with breakpoints `4/11`, `8/11`, `9/10` | `bounceIn = 1 − bounceOut(1−t)`; `bounceInOut` mirrors at `t = 0.5` |

## 5. Runtime Integration — How an Easing Function Is Applied

The easing functions never run themselves; they are invoked once per animation frame by the client runtime's `animate()` driver (see [client-dom-renderer_transitions.md](client-dom-renderer_transitions.md)). The frame loop computes raw progress `t = elapsed / duration`, maps it through the config's easing, and feeds the corrected values into the config's own `css(t, u)` / `tick(t, u)` callbacks, where `u = 1 − t'` is the mirrored progress.

```mermaid
sequenceDiagram
    participant TR as Transition/Animation factory<br/>(transitions & animations sub-modules)
    participant CF as Config<br/>{ delay, duration, easing, css(t,u) }
    participant DRV as animate() driver<br/>(Client Runtime Engine)
    participant EA as easing fn (this module)
    participant DOM as Element style / store

    TR->>CF: builds config, wiring default or user easing
    DRV->>DRV: elapsed = now − start
    DRV->>DRV: t = elapsed / duration
    DRV->>EA: t' = easing(t)
    EA-->>DRV: eased progress t'
    DRV->>DRV: u = 1 − t'
    DRV->>CF: css(t', u)
    CF-->>DOM: e.g. "opacity: t' · target" / "stroke-dashoffset: u · len"
    Note over DRV,DOM: repeats every rAF tick until t reaches 1
```

The same contract powers all three motion surfaces without any easing-specific runtime code:

| Surface | `t` source | Eased value drives |
|---------|-----------|--------------------|
| `transition:` directives | `animate()` driver over `TransitionConfig` | CSS string produced by `css(t, u)` |
| `animate:flip` | same driver over `AnimationConfig` | `transform: translate/scale` from `css(t, u)` |
| `tweened` store | `loop()` task in the motion module | `store.set(fn(easing(elapsed / duration)))` — easing output interpolates the *value*, not a CSS string |

Because easing is applied to *normalized progress*, changing a curve never changes the destination value — only the velocity profile along the way. Overshooting curves (`back*`, `elastic*`) are safe for interpolatable properties (opacity, transforms, stroke offsets) but can produce out-of-range numbers, so they are generally paired with transform-based transitions.

## 6. Edge Cases and Numerical Notes

The library is deceptively small but contains deliberate numerical hardening:

1. **`expoIn` / `expoOut` / `expoInOut` endpoint guards** — `Math.pow(2, 10·(t−1))` at `t = 0` yields `2⁻¹⁰ ≈ 0.000977`, not `0`. The functions special-case `t === 0` (and `t === 1` for `expoOut`/`expoInOut`) to return the exact endpoint, guaranteeing `f(0) === 0` and `f(1) === 1` so animations always land precisely on their final state.
2. **`sineIn` epsilon guard** — `1 − cos(π/2)` leaves a floating-point residue (~`6.1e−17`) instead of `0`; a `Math.abs(v) < 1e-14` check snaps the result to exactly `1`, avoiding a sub-pixel "final frame not fully applied" artifact.
3. **`bounceOut` is exported, not private** — the public export lets user code compose bounce behavior and keeps `bounceIn`/`bounceInOut` as thin reflections over it: `bounceIn(t) = 1 − bounceOut(1 − t)`; `bounceInOut` mirrors `bounceOut` around `t = 0.5`.
4. **Overshoot families exceed `[0, 1]`** — `back*` (single overshoot via `s = 1.70158`) and `elastic*` (damped oscillation) intentionally return values outside `[0, 1]` mid-flight. This is the correct behavior for the `css(t, u)` interpolation model used by the transitions module, but callers applying eased values to non-interpolatable or clamped properties should be aware.

## 7. Relationship to Other Modules

| Module | Relationship | Documentation |
|--------|--------------|---------------|
| `transitions-animations-easing` (parent) | This module is its easing sub-module; parent doc covers the shared `TransitionConfig`/`AnimationConfig` playback model | [transitions-animations-easing.md](transitions-animations-easing.md) |
| **Transitions** | Consumes easing as defaults (`linear`, `cubicOut`, `cubicInOut`) and as user-supplied params; publishes the `EasingFunction` param type | [transitions-animations-easing_transitions.md](transitions-animations-easing_transitions.md) |
| **Animations (FLIP)** | `flip` defaults to `cubicOut` in its `AnimationConfig` | [transitions-animations-easing_animations.md](transitions-animations-easing_animations.md) |
| **Motion (`tweened`)** | Applies easing per frame to interpolate store values: `fn(easing(elapsed / duration))` | [motion_tweened.md](motion_tweened.md) |
| **Client DOM renderer → transitions** | The only code that *executes* easing at frame time via the `animate()` driver | [client-dom-renderer_transitions.md](client-dom-renderer_transitions.md) |
| **Public API** | Exposed to users as `import { cubicOut, ... } from 'svelte/easing'` | [public-api.md](public-api.md) |
| **Compiler pipeline** | No compile-time coupling — easing is resolved entirely at runtime through the config object built by transition factories | [Compiler_Pipeline___Language_Toolchain.md](Compiler_Pipeline___Language_Toolchain.md) |

## 8. Usage

```js
// Built-in usage via transition params
import { fade, fly } from 'svelte/transition';
import { elasticOut, cubicIn } from 'svelte/easing';

// element with a custom curve
// <div in:fly={{ y: 20, easing: elasticOut }} out:fade={{ easing: cubicIn }}>

// Standalone use — the functions are plain math with no Svelte coupling
import { backOut } from 'svelte/easing';

const progress = 0.5;
backOut(progress); // ≈ 1.0877 — overshoots past 1, then settles at 1 for t = 1
```

## 9. Maintenance Guide

When adding or modifying an easing function:

- **Preserve the contract** — `f(0) === 0`, `f(1) === 1`, pure, allocation-free, single-argument.
- **Guard inexact endpoints** — if the formula involves `Math.pow`/`Math.cos` near the endpoints, add explicit guards like the `expo*` and `sineIn` functions do (§6); otherwise the runtime may never observe the exact final state.
- **Keep exports side-effect-free** — any module-level initialization would break the tree-shakeability guarantee checked by `packages/svelte/scripts/check-treeshakeability.js`.
- **Triads should be symmetric** — follow the existing pattern where `InOut` composes the `In` and `Out` halves around `t = 0.5` (as closed forms where possible, as with `bounceInOut`'s reflection of `bounceOut`).
- **New consumers** — if a new motion surface needs a default curve, prefer an existing family (`cubicOut` is the conventional default) rather than adding a private duplicate, and document the default in the consuming module's docs.
