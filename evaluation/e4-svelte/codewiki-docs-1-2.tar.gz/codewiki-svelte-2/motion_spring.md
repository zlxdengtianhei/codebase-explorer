# motion_spring

## 1. Introduction

`motion_spring` is the module behind **spring-based motion** in Svelte (`svelte/motion`). It implements a small, dependency-free physics simulation — a **damped harmonic oscillator** — that animates a value toward a target over time, producing natural, "bouncy" movement instead of linear interpolation.

The module exposes two APIs for the same physics core:

| Export | Kind | Status | Reactivity model | Introduced |
|---|---|---|---|---|
| `spring(value, opts)` | Factory function returning a [store](stores.md) | **Deprecated** since 5.8.0 | Legacy store contract (`writable`) | Svelte 1.x era |
| `class Spring<T>` | Runes-era reactive class | **Recommended** | Native signals (`state`/`set`/`get`) | 5.8.0 |

Both share a single simulation kernel, `tick_spring`, which recurses through numbers, `Date` objects, arrays, and plain objects so entire nested value trees can be animated at once.

> **Location:** `packages/svelte/src/motion/spring.js`
> **Parent surface:** [public-api](public-api.md) → `svelte/motion`
> **Sibling module:** [motion_tweened](motion_tweened.md) (duration-based tweening with easing functions)

---

## 2. Module Purpose & Core Functionality

The module answers one question continuously: *"given where the value is, where it was, and where it should be — where is it next frame?"*

### 2.1 The physics kernel: `tick_spring(ctx, last_value, current_value, target_value)`

For scalar leaves (numbers and `Date` instances) the kernel performs explicit Euler integration of spring dynamics per animation frame:

```text
delta        = target − current
velocity     = (current − last) / (dt || 1/60)      // guarded against div-by-zero
spring_force = stiffness × delta
damper       = damping   × velocity
acceleration = (spring_force − damper) × inv_mass
d            = (velocity + acceleration) × dt
```

- If `|d| < precision` **and** `|delta| < precision`, the spring has **settled** and the exact `target_value` is returned.
- Otherwise `ctx.settled = false` is signalled (telling the frame loop to keep ticking) and `current + d` is returned — or `new Date(current.getTime() + d)` for dates.
- `dt` is normalized to 60 fps units (`(elapsed_ms × 60) / 1000`), and `elapsed` is **clamped to 1/30 s** so a blocked thread or inactive tab cannot make the spring "go haywire".

For composite values the kernel recurses — arrays are mapped element-wise, plain objects are rebuilt key-by-key — so `TickContext` state (`inv_mass`, `dt`, `opts`, `settled`) is shared across the whole value tree. Any other type throws:

```text
Error: Cannot spring <typeof> values
```

```mermaid
flowchart TD
    A["tick_spring(ctx, last, current, target)"] --> B{"typeof current?"}
    B -- "number / Date" --> C["delta = target − current<br/>velocity = (current − last) / dt<br/>accel = (stiffness × delta − damping × velocity) × inv_mass<br/>d = (velocity + accel) × dt"]
    C --> D{"|d| < precision AND<br/>|delta| < precision ?"}
    D -- "yes (settled)" --> E["return target_value"]
    D -- "no" --> F["ctx.settled = false<br/>return current + d (or new Date)"]
    B -- "Array" --> G["map each element →<br/>tick_spring(...) recursively"]
    B -- "object" --> H["rebuild object, recursing<br/>per key with tick_spring(...)"]
    B -- "other" --> I["throw Error:<br/>Cannot spring typeof values"]
    E --> J["shared ctx carries inv_mass, dt,<br/>opts, settled across all leaves"]
    F --> J
```

### 2.2 `TickContext`

Declared in `motion/private.d.ts` — the contract between the animation drivers and the kernel:

| Field | Type | Meaning |
|---|---|---|
| `inv_mass` | `number` | Inverse mass; `0` = infinite mass (immune to spring forces while it recovers toward `1`) |
| `dt` | `number` | Frame delta normalized to 60 fps units |
| `opts.stiffness` | `number` | Spring constant (0–1) |
| `opts.damping` | `number` | Damping factor (0–1) |
| `opts.settled` | `boolean` | Output flag: stays `true` only if every leaf settled this frame |

---

## 3. Architecture

The module is a thin orchestration layer that binds one physics kernel to two reactivity channels — the **legacy store pipeline** and the **native signal graph** — and to the shared **rAF task loop**.

```mermaid
flowchart TB
    subgraph motionpkg["svelte/motion (this module family)"]
        SPRING["spring()<br/>(deprecated store factory)"]
        CLASS["class Spring&lt;T&gt;<br/>(signals-based)"]
        KERNEL["tick_spring()<br/>shared physics kernel"]
        UTILS["is_date()<br/>(motion/utils.js)"]
    end

    subgraph stores_mod["stores module"]
        W["writable()<br/>(store/shared/index.js)"]
    end

    subgraph engine["client reactivity engine"]
        SRC["state() / set()<br/>(reactivity/sources.js)"]
        EFF["render_effect()<br/>(reactivity/effects.js)"]
        RT["get()<br/>(runtime.js)"]
    end

    subgraph sched["client scheduling"]
        LOOP["loop()<br/>(client/loop.js)"]
        RAF["raf<br/>(client/timing.js:<br/>now / tick / tasks)"]
    end

    subgraph devtooling["client dev tooling"]
        TAG["tag()<br/>(dev/tracing.js)"]
    end

    SHARED["internal/shared/utils.js<br/>(deferred, noop)"]

    SPRING --> W
    SPRING --> LOOP
    CLASS --> SRC
    CLASS --> EFF
    CLASS --> RT
    CLASS --> SHARED
    SPRING --> SHARED
    SPRING & CLASS --> KERNEL
    KERNEL --> UTILS
    SPRING & CLASS --> LOOP
    SPRING & CLASS --> RAF
    CLASS -. "DEV only" .-> TAG
```

**Key architectural decisions:**

1. **One kernel, two drivers.** `tick_spring` is shared verbatim; only the plumbing around it (store vs. signals, promise/token handling) differs.
2. **Time comes exclusively from `raf.now()`** (usually `performance.now`), never from wall-clock or accumulator state in the module itself.
3. **Animation is a rAF task, not a timer.** Both APIs create a single `loop()` task per animation and cancel it the moment the spring settles — zero work while at rest.
4. **Frame clamp guards real-world conditions.** Elapsed time is capped at `1000/30` ms so throttled tabs or long GC pauses produce a bounded step, not an explosion.

---

## 4. Public API Reference

### 4.1 `class Spring<T>` (recommended, since 5.8.0)

```svelte
<script>
    import { Spring } from 'svelte/motion';

    const spring = new Spring(0);
</script>

<input type="range" bind:value={spring.target} />
<input type="range" bind:value={spring.current} disabled />
```

```mermaid
classDiagram
    class Spring~T~ {
        -Source~T~ #current
        -Source~T~ #target
        -Source~number~ #stiffness = 0.15
        -Source~number~ #damping = 0.8
        -Source~number~ #precision = 0.01
        -T #last_value
        -number #last_time
        -number #inverse_mass = 1
        -number #momentum = 0
        -Task #task
        -Deferred #deferred
        +Spring(value, options)
        +of(fn, options)$ Spring~U~
        -update(value) Promise~void~
        +set(value, options) Promise~void~
        +current() T
        +target() T
        +stiffness() number
        +stiffness(v) void
        +damping() number
        +damping(v) void
        +precision() number
        +precision(v) void
    }
    class SpringOpts {
        +number stiffness
        +number damping
        +number precision
    }
    class SpringUpdateOpts {
        +boolean instant
        +number preserveMomentum
    }
    Spring ..> SpringOpts : constructor
    Spring ..> SpringUpdateOpts : set()
```

**Construction.** `#current` and `#target` are created as real **sources** via `state()`. `stiffness` and `damping` are **clamped to `[0, 1]`**; `precision` is accepted as-is. In dev builds every field is labelled with `tag()` (`'Spring.current'`, `'Spring.stiffness'`, …) so the [client dev tooling](client-dev-tooling.md) can attribute signal reads/writes during tracing and HMR inspection.

**`Spring.of(fn, options)` (static).** Creates a spring whose target is *bound* to a reactive expression:

```svelte
<script>
    import { Spring } from 'svelte/motion';
    let { number } = $props();
    const spring = Spring.of(() => number);
</script>
```

Internally it seeds a spring with `fn()` and registers a **`render_effect`** that calls `spring.set(fn())` whenever the expression's dependencies change. Because the effect must attach to an effect root, `Spring.of` **must be called during component initialisation** (or inside an explicit effect root).

**`set(value, options?) → Promise<void>`** — the heart of the class:

1. Rejects any previously pending deferred with `Error('Aborted')` — *latest write wins*.
2. **`options.instant === true`** (or `#current` is still `undefined`): aborts any running task, writes the value into *both* `#target` and `#current` in one synchronous pass, and resolves immediately.
3. **`options.preserveMomentum === n`**: sets `#inverse_mass = 0` (infinite mass) and records `n` (milliseconds); the spring therefore keeps travelling on its current trajectory for `n` ms before the target's pull resumes — designed for "fling" gestures. Mass recovery per frame is `1000 / (momentum × 60)`.
4. Otherwise defers to `#update(value)` and resolves when the animation settles — but only if this `set` is still the latest one.

**`#update(value)`** — writes `#target`, back-fills `#current`/`#last_value` when undefined, and lazily starts the rAF task:

```mermaid
sequenceDiagram
    autonumber
    participant App as Consumer / effect
    participant S as Spring
    participant T as #target / #current (signals)
    participant L as loop (rAF tasks)
    participant K as tick_spring
    participant E as Effects / subscribers

    App->>S: set(value, options)
    S->>T: set(#target, value)
    alt instant or current undefined
        S->>T: set(#current, value)
        S-->>App: Promise.resolve()
    else animated
        S->>L: start task (if none running)
        loop every animation frame until settled
            L->>S: callback(now)
            S->>S: recover inverse_mass, clamp elapsed ≤ 1/30 s<br/>dt = (elapsed × 60) / 1000
            S->>K: tick(ctx, last, current, target)
            K-->>S: next value (ctx.settled flag)
            S->>T: set(#current, next)
            T-->>E: signal invalidation → effects rerun → DOM updates
        end
        L-->>S: task settles, removed from raf.tasks
        S-->>App: deferred promise resolves
    end
```

Note that the frame callback reads `#stiffness.v`, `#damping.v`, and `#precision.v` **on every tick** — because these are signals, changing them reactively mid-flight (e.g. from a slider binding) takes effect immediately without restarting the animation.

**Reactive accessors.** `current` and `target` are read-only getters over signals (readable anywhere, trackable inside effects/templates). `stiffness`, `damping`, and `precision` have both getters and setters; the setters clamp (`stiffness`, `damping`) and route through `set()` so downstream reactions fire. The `target` setter simply delegates to `set(value)` — so `bind:value={spring.target}` composes binding machinery with spring physics.

### 4.2 `spring(value, opts?)` — deprecated store factory

Returns a `SpringStore<T>` (store-contract object) built on `writable()` from the [stores](stores.md) module:

| Member | Behaviour |
|---|---|
| `set(value, opts?)` | Begins (or retargets) the animation; returns a promise resolved when settled |
| `update(fn, opts?)` | `set(fn(target_value, value), opts)` |
| `subscribe(run)` | Standard store subscription, delegating to `writable` |
| `stiffness`, `damping`, `precision` | Frozen snapshot of the options (not reactive — see note below) |

`SpringUpdateOpts` for this API: **`hard: true`** snaps immediately, **`soft: true | number`** temporarily gives the spring "infinite mass" that recovers over time — `soft: true` is equivalent to `0.5`, a number `n` sets the recovery rate to `1 / (n × 60)`. A set is also implicitly instant when the current value is `null`, or when `stiffness ≥ 1 && damping ≥ 1`.

Concurrency is handled with **token comparison** rather than rejection: every `set` creates a fresh `current_token`; the pending promise only resolves if its token is still the latest one at settle time.

> ⚠️ **Why it was deprecated:** parameter values (`stiffness`/`damping`/`precision`) are *static* properties captured at creation, writes go through the legacy store channel, and updates can't compose with runes bindings. The `Spring` class provides all of this natively. Prefer `Spring` in new code; the function remains for backwards compatibility and is usable wherever the store contract applies (`$spring`, `get(spring)`, `derived([spring], …)`).

---

## 5. Data Flow

```mermaid
flowchart LR
    subgraph inputs["Writes"]
        U1["bind:value / user code<br/>spring.set(x)"]
        U2["Reactive dependency change<br/>(Spring.of render_effect)"]
    end

    subgraph signals["Signal layer"]
        TGT["#target source"]
        CUR["#current source"]
    end

    subgraph sim["Simulation (rAF task)"]
        LOOPC["loop callback<br/>per frame"]
    end

    subgraph out["Reads"]
        E1["Template / effects<br/>read spring.current"]
        E2["Devtools / $inspect<br/>via tagged signals"]
    end

    U1 --> TGT
    U2 --> TGT
    TGT --> LOOPC
    LOOPC -- "tick_spring(next)" --> CUR
    CUR --> E1
    CUR --> E2
    E1 -- "DOM reflects animated value" --> RENDERED["Rendered UI"]
```

Reads of `current` inside effects/templates register dependencies in the signal graph (see [client-reactivity-engine](client-reactivity-engine.md)), so every `set(#current, …)` during a frame automatically invalidates exactly the reactions that consumed the value — no manual subscription or teardown wiring is needed anywhere in the module.

---

## 6. Dependencies

### 6.1 Internal dependency graph

```mermaid
flowchart TD
    SPRING["motion/spring.js"] --> S1["store/shared/index.js<br/>writable()"]
    SPRING --> S2["internal/client/loop.js<br/>loop()"]
    SPRING --> S3["internal/client/timing.js<br/>raf.now()"]
    SPRING --> S4["internal/client/reactivity/sources.js<br/>state(), set()"]
    SPRING --> S5["internal/client/reactivity/effects.js<br/>render_effect()"]
    SPRING --> S6["internal/client/runtime.js<br/>get()"]
    SPRING --> S7["internal/client/dev/tracing.js<br/>tag()"]
    SPRING --> S8["internal/shared/utils.js<br/>deferred(), noop()"]
    SPRING --> S9["motion/utils.js<br/>is_date()"]
    SPRING --> S10["motion/private.d.ts / public.d.ts<br/>SpringOpts, SpringUpdateOpts,<br/>TickContext, SpringStore"]
    SPRING --> S11["esm-env<br/>DEV flag"]
```

### 6.2 Module relationships

| Consumes from | What | Why |
|---|---|---|
| [stores](stores.md) | `writable()` | Subscription plumbing for the deprecated `spring()` store |
| [client-reactivity-engine](client-reactivity-engine.md) | `state`/`set`/`get` (signal graph), `render_effect` (effects), `loop` + `run_tasks` (rAF batching/scheduling), `Task` type | The class's reactive fields, the reactive binding of `Spring.of`, and all frame scheduling |
| [client-dom-renderer](client-dom-renderer.md) | timing infrastructure (`raf`) shared with DOM rendering | Consistent frame timing with the render pipeline |
| [client-dev-tooling](client-dev-tooling.md) | `tag()` (dev only) | Labels sources for tracing/ownership diagnostics (`Spring.current`, `Spring.stiffness`, …) |
| [internal-shared-utils](internal-shared-utils.md) | `deferred()`, `noop()` | Cancellable, latest-write-wins promises for `Spring.set` |

**Exposed upstream:** `spring` and `Spring` are re-exported through the `svelte/motion` entry point of [public-api](public-api.md), with the `SpringStore`/`Spring` types surfaced in `packages/svelte/types/index.d.ts`.

### 6.3 Comparison with motion_tweened

See [motion_tweened](motion_tweened.md) for the sibling implementation. The essential differences:

| Aspect | `Spring` (this module) | `Tweened` (sibling) |
|---|---|---|
| Motion model | Physics: stiffness/damping/velocity (stateful, history-aware) | Time: duration + easing function (deterministic) |
| Duration | Emergent — depends on physics and precision | Explicit (`delay`, `duration`) |
| Interrupt behaviour | Retargets seamlessly, inherits velocity (natural) | Restarts interpolation |
| Parameter mutability | Live & reactive (class) | Per-call `opts` merge |
| Value types | numbers, Dates, arrays, plain objects | any (via interpolator) |

---

## 7. Behavioural Details & Edge Cases

- **Settling criterion** is a conjunction: per-frame step magnitude `|d|` *and* remaining distance `|delta|` must both fall below `precision` (default `0.01`) before the task is cancelled and the exact target is assigned.
- **First-frame velocity guard:** `dt || 1/60` prevents a divide-by-zero on the very first tick.
- **Tab throttling / main-thread stalls:** elapsed time is clamped to `1000/30` ms per frame, so worst case the simulation runs at 30 fps steps rather than jumping.
- **Composite values:** `tick_spring` recurses into arrays and plain objects; every leaf must ultimately be a `number` or `Date`, otherwise `Error: Cannot spring <type> values` is thrown (e.g. `spring({ x: 'nope' })`).
- **Dates:** animated by mutating *time* — a new `Date` is constructed per tick (`current.getTime() + d`), detected via `is_date()`.
- **Chained updates:** `set()` never restarts from zero; because `last_value`/`current` are carried over, retargeting mid-flight preserves momentum — the signature spring feel.
- **Promise semantics diverge between APIs:** the class **rejects** superseded promises with `Error('Aborted')` (with a `noop` catch attached so it never surfaces as unhandled); the deprecated function resolves only the latest promise and leaves older ones pending silently.
- **Dev-mode extras:** signal labelling via `tag()` is compiled to a no-op cost in production builds (`DEV` from `esm-env`).

---

## 8. Usage Notes & Constraints

- **Client-only.** The module imports client runtime internals (`raf`, signals, effects); there is no SSR rendering path. During SSR, imports of `svelte/motion` should be treated as client components of [public-api](public-api.md).
- **`Spring.of` requires an effect root.** Calling it outside component initialisation (or an explicit `effect_root`) will fail to attach the internal `render_effect`.
- **`stiffness`/`damping` clamping** (`0–1`) happens only in the class; the deprecated function trusts its inputs, which is another reason it's deprecated.
- **Never mutate composite values in place** and expect animation — always write a fresh object/array through `set`/`target` so the kernel receives new source/target trees.
- **Treeshaking:** `Spring` and `spring()` live in the same file but are independent exports; applications importing only `Spring` in runes mode pay only for the signals + loop path (see the repo's `check-treeshakeability` tooling under Engineering Tooling).

---

## 9. Related Documentation

- [motion_tweened](motion_tweened.md) — duration/easing-based alternative in `svelte/motion`
- [stores](stores.md) — store contract powering the deprecated API's `subscribe` channel
- [client-reactivity-engine](client-reactivity-engine.md) — signal graph, effects, and rAF task scheduling this module builds on
- [client-dev-tooling](client-dev-tooling.md) — dev-mode signal tagging/tracing used by `Spring`
- [public-api](public-api.md) — the `svelte/motion` public surface and type re-exports
- Svelte docs: [svelte/motion — Spring](https://svelte.dev/docs/svelte/svelte-motion#Spring)