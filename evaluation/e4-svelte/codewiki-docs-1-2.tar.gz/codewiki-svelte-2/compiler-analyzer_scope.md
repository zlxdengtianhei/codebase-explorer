# compiler-analyzer_scope

## 1. Overview

`compiler-analyzer_scope` is the **lexical scope infrastructure** of the Svelte compiler. It lives in a single file — `packages/svelte/src/compiler/phases/scope.js` — and provides everything the compiler needs to answer the questions *"where is this identifier declared?"*, *"what kind of binding is it?"*, *"is it mutated?"*, and *"can its value be known at compile time?"*.

The module is consumed primarily by **Phase 2 (analyze)** of the compiler pipeline, but its output (`Scope`, `Binding`, and the `scopes` map) flows all the way into **Phase 3 (transform)** where it drives client/server code generation.

The module tree identifies three core components:

| Component | Visibility | Role |
|---|---|---|
| `set_scope` | exported | Default zimmerframe visitor that keeps the walk state's `scope` synchronized with the scope map while traversing the AST |
| `SvelteDirective` | internal visitor | Collects references for `use:`, `transition:`, and `animate:` directives during scope construction |
| `SvelteFragment` | internal visitor | Creates a dedicated child scope for element-like template nodes (`SvelteFragment`, `SlotElement`, `SvelteElement`, `RegularElement`) |

Together with the supporting machinery defined in the same file (`Scope`, `Binding`, `Evaluation`, `ScopeRoot`, `create_scopes`, `get_rune`), these components form the semantic backbone of Svelte's reactivity analysis.

---

## 2. Position in the Compiler Pipeline

The compiler processes a `.svelte` file in three phases (see [compiler-analyzer](compiler-analyzer.md)):

1. **Parse** ([compiler-parser](compiler-parser.md)) — produces the AST (template fragments + JS module/instance scripts).
2. **Analyze** — `analyze_component` (in `phases/2-analyze/index.js`) builds the semantic model. **This module is invoked here**: `create_scopes()` runs over every AST region before the analysis visitors walk the tree.
3. **Transform** ([compiler-transformer](compiler-transformer.md)) — client and server visitors read the bindings recorded by this module to decide how state, props, each-items, stores, and snippets are compiled.

```mermaid
flowchart LR
    subgraph Phase1["Phase 1 — Parse (compiler-parser)"]
        P[parse&lt;br/&gt;AST: module / instance / template]
    end
    subgraph Phase2["Phase 2 — Analyze (compiler-analyzer)"]
        AS["analyze_component"]
        subgraph THIS["compiler-analyzer_scope (this module)"]
            CS["create_scopes()"]
            SS["set_scope() / visitors"]
        end
        AV["analysis visitors&lt;br/&gt;(compiler-analyzer_visitors)"]
    end
    subgraph Phase3["Phase 3 — Transform (compiler-transformer)"]
        TR["client / server / css transforms"]
    end

    P --> AS
    AS -->|"module & instance &lt;br/&gt;js(root, root, allow_reactive)"| CS
    AS -->|"template fragment"| CS
    CS -->|"{ has_await, scope, scopes }"| AS
    AS -->|"walk(ast, { scope, scopes }, visitors, _ = set_scope)"| SS
    SS --> AV
    AV -->|"refine Binding.kind, flags"| AS
    AS -->|"analysis (bindings + scopes)"| TR
```

A typical entry point is `compileModule` / `compile()` in [compiler-core_public_api](compiler-core_public_api.md), which ultimately triggers `analyze_component`.

---

## 3. Architecture

### 3.1 Core Class Model

```mermaid
classDiagram
    direction LR

    class ScopeRoot {
        +Set~string~ conflicts
        +unique(preferred_name) Identifier
    }

    class Scope {
        +ScopeRoot root
        +Scope parent
        -boolean #porous
        +Map~string, Binding~ declarations
        +Map~declarator, Binding[]~ declarators
        +Map~string, Reference[]~ references
        +number function_depth
        +Expression tracing
        +declare(node, kind, decl_kind, initial) Binding
        +child(porous) Scope
        +generate(preferred_name) string
        +get(name) Binding$
        +get_bindings(node) Binding[]
        +owner(name) Scope$
        +reference(node, path)
        +evaluate(expression) Evaluation
    }

    class Binding {
        +Scope scope
        +Identifier node
        +BindingKind kind
        +DeclarationKind declaration_kind
        +initial
        +Reference[] references
        +Binding[] legacy_dependencies
        +string prop_alias
        +metadata
        +boolean mutated
        +boolean reassigned
        +updated() boolean
        +is_function() boolean
    }

    class Evaluation {
        +Set~any~ values
        +boolean is_known
        +boolean has_unknown
        +boolean is_defined
        +boolean is_string
        +boolean is_number
        +boolean is_function
        +any value
    }

    class EvaluationCache["current_evaluations (module map)"] {
        Map~Expression, Evaluation~
    }

    Scope "1" --> "0..1" Scope : parent / child()
    ScopeRoot "1" o-- "1..*" Scope : root
    Scope "1" *-- "0..*" Binding : declarations
    Binding "1" --> "1" Scope : scope
    Scope ..> Evaluation : evaluate()
    Evaluation ..> EvaluationCache : cycle guard
```

**Key relationships:**

- A single `ScopeRoot` is created per component (`analyze_component`). It accumulates a global set of name `conflicts` so that generated identifiers can never collide with user or generated names.
- `Scope` forms a tree mirroring lexical scoping. Declarations bubble upward for `var` (in *porous* scopes) and `import` declarations, mirroring JavaScript hoisting semantics.
- Each `Binding` records its declaring `Scope`, its AST identifier, its classification (`BindingKind` / `DeclarationKind`), its initializer, and every reference to it — this is the primary artifact consumed by the analysis visitors and the transformer.
- `Evaluation` performs **partial evaluation** of expressions against the scope tree to infer exact values or rough types (used to prune reactivity and validate things like `bind:` targets).

### 3.2 `BindingKind` taxonomy

Defined in [compiler-core_type_definitions](compiler-core_type_definitions.md) and assigned by this module plus refined by the analysis visitors:

| Kind | Meaning |
|---|---|
| `normal` | A plain variable, nothing special |
| `prop` / `bindable_prop` | Component props (the latter supports `bind:`) |
| `rest_prop` | Rest props (`$$restProps`, `{ ...rest } = $props()`) |
| `raw_state` / `state` | `$state` variables (`state` is deeply reactive) |
| `derived` | `$derived` variables |
| `each` | `{#each}` block parameters |
| `snippet` | Snippet block parameters |
| `store_sub` | Synthetic bindings for `$store` subscriptions |
| `legacy_reactive` | Implicitly declared `$: a = ...` reactive statements |
| `template` | Bindings declared in the template (`const` tags, `await` values, `let:` directives) |
| `static` | Non-keyed each-block indexes |

`DeclarationKind` mirrors JS declaration forms: `var | let | const | function | import | param | rest_param | synthetic`.

---

## 4. Core Components

### 4.1 `create_scopes(ast, root, allow_reactive_declarations, parent)`

The module's workhorse. It performs a **single `zimmerframe` walk** over an AST (module script, instance script, or template fragment) and returns:

```js
{ has_await, scope, scopes }
// scope  – the root Scope for this AST region
// scopes – Map<AST.SvelteNode, Scope> for every node that owns (or is associated with) a scope
// has_await – whether a top-level await was seen (auto-enables runes mode; see §6.4)
```

The walk is organized into three logical passes, executed in one traversal plus three fix-up loops:

```mermaid
flowchart TD
    A["Walk AST (zimmerframe)"] --> B["Pass 1: declarations<br/>declare() → Binding per identifier<br/>scopes.set(node, child) for scope owners"]
    A --> C["Pass 1b: collect references<br/>is_reference() → references[] (deferred)"]
    A --> D["Pass 1c: collect updates<br/>AssignmentExpression / UpdateExpression /<br/>BindDirective → updates[]"]
    A --> E["Pass 1d: implicit reactive declarations<br/>$: a = … → possible_implicit_declarations[]"]
    B --> F
    C --> F["Post-pass: scope.reference(node, path)<br/>for every collected reference"]
    D --> G["Post-pass: unwrap_pattern + object()<br/>→ binding.reassigned / binding.mutated"]
    E --> H["Post-pass: declare legacy_reactive<br/>bindings for un-declared $: targets"]
    F --> I["Return { has_await, scope, scopes }"]
    G --> I
    H --> I
```

**Why references are deferred:** a reference may textually appear *before* its declaration (`hoisting`). Collecting references during the walk and applying them afterwards guarantees that `scope.reference()` always finds the final `Binding` (or registers the name as a global conflict at the root).

### 4.2 `set_scope(node, { next, state })`

The **default visitor** (`_`) used by `zimmerframe` walks in the analysis phase:

```js
export function set_scope(node, { next, state }) {
    const scope = state.scopes.get(node);
    next(scope !== undefined && scope !== state.scope ? { ...state, scope } : state);
}
```

```mermaid
flowchart TD
    A["Visitor fires for node N"] --> B{"scopes.has(N)?"}
    B -- "no" --> C["continue with current state.scope"]
    B -- "yes" --> D{"scope !== state.scope?"}
    D -- "no" --> C
    D -- "yes" --> E["clone state with scope = scopes.get(N)<br/>and descend with next(...)"]
```

Every analysis visitor in [compiler-analyzer_visitors](compiler-analyzer_visitors.md) relies on `context.state.scope` being correct; `set_scope` is what keeps it correct as the walk enters functions, blocks, each-branches, snippets, component slots, and element scopes — without each visitor having to manage scope manually. It is also reused ad hoc (e.g. in `analyze_component`'s legacy each-block mutation sweep) via the `{ _: set_scope }` walker option.

### 4.3 `SvelteDirective` visitor (internal)

Handles `TransitionDirective`, `AnimateDirective`, and `UseDirective` during `create_scopes`:

- References the base name of the directive — `node.name.split('.')[0]` — so `transition:fade|local` registers a reference to `fade` and `use:thing` to `thing`. This makes local/params modifiers irrelevant for binding resolution while still validating that the referenced value exists.
- Visits the directive `expression` (the value passed to the directive), so parameters/arguments inside it get their references recorded.

`StyleDirective` deliberately uses **its own** handler instead: style directives have no expressions and shorthand form (`<button style:height />`) must reference the variable whose name equals the CSS property. That special case is handled inline in the walk.

### 4.4 `SvelteFragment` visitor (internal)

Assigned to `SvelteFragment`, `SlotElement`, `SvelteElement`, and `RegularElement`. Each of these template nodes receives a **fresh non-porous child scope**:

```mermaid
flowchart LR
    subgraph Template["Template AST"]
        RE["&lt;RegularElement&gt;"] --> LET["let:color={c}"]
        SF["&lt;slot name='x'&gt;"] --> LET2["let:item"]
    end
    RE -. "child() scope" .-> S1["Scope (declarations: color → template/const)"]
    SF -. "child() scope" .-> S2["Scope (declarations: item → template/const)"]
```

This exists because `let:` directives on elements and slots declare **template bindings** (`kind: 'template'`, `declaration_kind: 'const'`) that must not leak into the surrounding scope. `LetDirective` registers the bindings in the current element scope and self-references them (they are *defined and used* here, not passed down).

### 4.5 `get_rune(node, scope)` / `get_global_keypath(node, scope)`

- `get_rune(node, scope)` — if `node` is a `CallExpression` whose callee is an unshadowed global keypath matching a rune pattern (checked with `is_rune()` from the compiler's shared utils), returns the rune name (`'$state'`, `'$derived.by'`, `'$props.id'`, …), otherwise `null`.
- `get_global_keypath` resolves dotted/callable keypaths (`Math.floor`, `String.fromCharCode`, `$state.raw`, `$effect.tracking()`) by walking `MemberExpression`/`CallExpression` chains; resolution stops if any segment is computed, non-identifier, or the base identifier resolves to a **binding** (i.e. shadowed — `$foo` referring to a store, `Math` reassigned locally).

Used by `Evaluation`, by the store-subscription detection in `analyze_component`, and by rune-placement validation in the analysis visitors.

### 4.6 `Evaluation` — compile-time partial evaluation

`Scope.evaluate(expression)` returns an `Evaluation` describing the set of possible values:

```mermaid
flowchart TD
    A["expression"] --> B{"type?"}
    B -->|Literal| C["add exact value"]
    B -->|Identifier| D{"binding known &<br/>not updated & not prop?"}
    D -- yes --> E["recurse into initial"]
    D -- no --> F["UNKNOWN"]
    B -->|Binary / Logical / Unary| G{"operands known?"}
    G -- yes --> H["fold with operator table<br/>(binary / unary / logical maps)"]
    G -- no --> I["infer type: NUMBER / STRING /<br/>true+false / UNKNOWN"]
    B -->|CallExpression| J{"global keypath?"}
    J -- rune --> K["$state/$derived → eval arg<br/>$props.id → STRING<br/>$effect.tracking → {false,true}<br/>$derived.by → eval arrow body"]
    J -- known global fn --> L["apply fn if args known,<br/>else yield declared type<br/>(Math.*, Number.*, String.*, BigInt)"]
    J -- else --> F
    B -->|MemberExpression| M{"global constant?<br/>(Math.PI, Math.E, …)"}
    M -- yes --> N["exact constant value"]
    M -- no --> F
    B -->|TemplateLiteral| O["concat known parts,<br/>else STRING"]
    B -->|functions| P["FUNCTION symbol"]
```

The result is summarized by read-only flags: `is_known` (exactly one value), `is_defined` (definitely not nullish), `is_string`, `is_number`, `is_function`, `value` (the single value if known). Special *symbol witnesses* `UNKNOWN`, `NUMBER`, `STRING`, `FUNCTION` occupy the value set to express "value of this type, unknown which".

**Cycle guard:** `current_evaluations` maps expressions currently being evaluated to their in-flight `Evaluation`, so mutually-recursive initializers (`const a = b + 1; const b = a + 1`) cannot loop forever — a re-entrant lookup returns the partial evaluation.

### 4.7 Module-level lookup tables

- `globals` — maps well-known global functions (`Math.*`, `Number.*`, `String`, `BigInt`) to `[type witness, native fn]` pairs for evaluation and type inference.
- `global_constants` — `Math.PI`, `Math.E`, etc., resolved exactly for `MemberExpression` evaluation.
- `binary`, `unary`, `logical` — operator → pure-function tables used by `Evaluation` to fold known operands.

---

## 5. Scope Creation Rules

Where new `Scope` objects are created during `create_scopes`, and whether they are **porous** (i.e. `var` declarations bubble past them to the enclosing scope, mirroring JS hoisting):

| AST node | New scope? | Porous | Declarations registered |
|---|---|---|---|
| `Fragment` | ✔ | iff `metadata.transparent` | — |
| `FunctionDeclaration` | ✔ | no | function id (`function`), params |
| `FunctionExpression` | ✔ | no | its own id, params |
| `ArrowFunctionExpression` | ✔ | no | params |
| `ForStatement` / `ForInStatement` / `ForOfStatement` / `SwitchStatement` | ✔ | yes | — |
| `BlockStatement` (not a function body) | ✔ | yes | — |
| `CatchClause` (with param) | ✔ | yes | catch param (`let`) |
| `LabeledStatement` `$:` (legacy, if allowed) | ✔ | yes | implicit `legacy_reactive` targets |
| `EachBlock` | ✔ | no | context ids (`each`), index (`static` or `template` const); sets `metadata` incl. `$$index`, `declarations`, `transitive_deps` |
| `AwaitBlock` | ✔ (value/error scopes) | no | `value`/`error` as `template` const in pending/then/catch scope *and* `normal` const in the value/error scope |
| `SnippetBlock` | ✔ (param scope) | no | snippet name (`function`), parameters (`snippet`/`let`) |
| `Component` / `SvelteSelf` / `SvelteComponent` | ✔ per slot (`metadata.scopes`) | no | `let:` directive bindings (`template`/`const`) |
| `SvelteFragment` / `SlotElement` / `SvelteElement` / `RegularElement` | ✔ | no | (populated by `LetDirective`) |
| `ImportDeclaration` | ✖ (bubbles to parent) | — | specifiers (`normal`/`import`) |
| `ClassDeclaration` | ✖ | — | class id (`let`) |
| `VariableDeclaration` | ✖ | — | declarators registered in `scope.declarators`; `const`-tag children get `kind: 'template'` |

`Scope.function_depth` increases on every **non-porous** scope, and is used by `validate_identifier_name` (from [compiler-analyzer_visitors](compiler-analyzer_visitors.md)) to restrict `$`-prefixed identifiers to component top level, and by analysis to detect state referenced from its own scope.

---

## 6. Data Flow & Component Interaction

### 6.1 End-to-end analysis sequence

```mermaid
sequenceDiagram
    autonumber
    participant A as analyze_component
    participant SR as ScopeRoot
    participant CS as create_scopes
    participant SS as set_scope (default visitor)
    participant V as analysis visitors
    participant T as Phase 3 transforms

    A->>SR: new ScopeRoot()
    A->>CS: js(module) — scopes for &lt;script&gt; (non-reactive)
    A->>CS: js(instance) — scopes, allow_reactive_declarations = true
    A->>CS: create_scopes(template fragment, root, false, instance.scope)
    CS-->>A: { scope, scopes, has_await } for each region
    Note over A: store-subscription detection & runes-mode decision<br/>(options.runes ?? has_await || rune-like references)
    loop for each region (module / instance / template)
        A->>SS: walk(ast, { scope, scopes, analysis, … }, visitors, _ = set_scope)
        SS->>V: dispatch with correct scope per node
        V->>V: scope.get(), binding.kind refinement,<br/>expression dependency tracking
    end
    A-->>T: ComponentAnalysis (template = { ast, scope, scopes })
    T->>T: visitors resolve bindings via scope.get()/evaluate()<br/>to generate client & server output
```

### 6.2 Binding lifecycle

```mermaid
flowchart LR
    D["Declaration encountered<br/>var/let/const/function/import/param"] --> E["Scope.declare() → Binding<br/>validate_identifier_name<br/>($-prefix rules)"]
    E --> R["References applied post-walk<br/>binding.references[] populated"]
    R --> U["Updates resolved<br/>reassigned (direct) / mutated (member/pattern)"]
    U --> K{"Kind refinement<br/>(analysis visitors / analyze_component)"}
    K -->|"legacy export let / $: usage"| S1["prop · bindable_prop · state ·<br/>legacy_reactive · store_sub"]
    K -->|"runes mode"| S2["stays as declared by $state/$derived/$props"]
    S1 --> X["Consumed by compiler-transformer<br/>(client & server codegen)"]
    S2 --> X
```

Examples of consumption downstream:

- `EachBlock` visitor (see [compiler-analyzer_visitors](compiler-analyzer_visitors.md)) reads `binding.mutated` and `node.metadata.expression.dependencies` to promote legacy bindings to `state`.
- `analyze_component` promotes exported `let` bindings to `bindable_prop` and synthesizes `store_sub` bindings for `$name` references found in `scope.references`.
- The transformer uses `binding.is_function()` to decide whether a value can be inlined directly as an event handler, and `evaluate()` to prune static class/style directives.

### 6.3 Reference resolution flow

```mermaid
flowchart TD
    ID["Identifier node + path"] --> Q{"is_reference(node, parent)<br/>&& !TS node?"}
    Q -- no --> SKIP["ignored (property access, etc.)"]
    Q -- yes --> BUF["buffered in references[]"]
    BUF --> APP["after walk: scope.reference(node, path)"]
    APP --> F{"declared in this scope?"}
    F -- yes --> BIND["binding.references.push({node, path})"]
    F -- no --> UP["bubble to parent scope"]
    UP --> ROOT{"at root scope?"}
    ROOT -- no --> F
    ROOT -- yes --> GLOB["root.conflicts.add(name)<br/>(treated as global)"]
```

### 6.4 Design notes

- **Porous scopes** implement JS `var` hoisting: `Scope.declare` forwards `var` declarations through porous children to the nearest non-porous ancestor. `import` declarations likewise always land in the parent, so module and instance scripts share import bindings (`js(instance …, parent = module.scope)`).
- **Unique-name generation** (`Scope.generate`, `ScopeRoot.unique`) consults `references`, `declarations`, `root.conflicts`, and reserved words to mint collision-free identifiers for generated code (`$$index`, component names, helper bindings).
- **`has_await` side-channel**: `create_scopes` flags top-level `AwaitExpression`s (outside any function) so `analyze_component` can auto-opt a component into runes mode without an extra pre-pass.
- **`tracing`** field on `Scope` records an optional expression enabling `$inspect.trace`-style dependency tracing for the subtree (wired through the analysis/transform state).
- **`evaluate()` must be called only after scope construction completes** — evaluating during the construction walk would read incomplete declarations and yield wrong results.

---

## 7. Dependencies

### 7.1 Upstream (consumed by this module)

| Dependency | Source module | Usage |
|---|---|---|
| `walk` / `zimmerframe` | external | AST traversal in `create_scopes` |
| `is_reference` | external (`is-reference`) | Distinguishes identifier *references* from property keys |
| `b.id` (builders) | [compiler-core_ast_builders](compiler-core_ast_builders.md) | Synthetic identifiers (`b.id(name)`) for directive/each-index references |
| `e.*` (errors) | [compiler-core_diagnostics](compiler-core_diagnostics.md) | `declaration_duplicate` (thrown by `Scope.declare`) |
| `extract_identifiers`, `extract_identifiers_from_destructuring`, `object`, `unwrap_pattern` | [compiler-core](compiler-core.md) `utils/ast.js` | Pattern destructuring for declarations and updates |
| `is_reserved`, `is_rune` | [compiler-core](compiler-core.md) `utils.js` | Name generation and rune keypath detection |
| `create_expression_metadata` | [compiler-analyzer](compiler-analyzer.md) `phases/nodes.js` | Per-`EachBlock` expression metadata (dependencies, state/call flags) |
| `determine_slot` | [compiler-analyzer](compiler-analyzer.md) `phases/utils/slot.js` | Slot targeting for component scope setup |
| `validate_identifier_name` | [compiler-analyzer_visitors](compiler-analyzer_visitors.md) | `$`-prefix and `$`-binding validation on declaration |
| `BindingKind`, `DeclarationKind`, `AST` types | [compiler-core_type_definitions](compiler-core_type_definitions.md) | Type vocabulary for bindings |

### 7.2 Downstream (consumers of this module)

| Consumer | Module | Usage |
|---|---|---|
| `analyze_component` | [compiler-analyzer](compiler-analyzer.md) | `ScopeRoot`, `create_scopes`, `get_rune`, `set_scope`, store-sub synthesis, runes detection, export-let handling |
| All analysis visitors | [compiler-analyzer_visitors](compiler-analyzer_visitors.md) | `scope.get()`, `binding.references`, `binding.updated`, `evaluate()` |
| CSS analysis | [compiler-analyzer_css_analysis](compiler-analyzer_css_analysis.md) | Scope of the component context (indirect via analysis) |
| Client/server visitors | [compiler-transformer](compiler-transformer.md) | Binding kinds/flags decide reactivity codegen (`$state` sources, props, each items, snippets) |

### 7.3 Input contract

`create_scopes` operates on ASTs produced by [compiler-parser](compiler-parser.md) (`parse` → `{ js: { module, instance }, fragment, css, options }`). TypeScript-specific nodes are expected to have been stripped by the parse phase (`remove_typescript_nodes`), except during `svelte-migrate` runs — hence the defensive `TS*` filtering in the `Identifier` visitor.

---

## 8. Related Documentation

- [compiler-analyzer](compiler-analyzer.md) — parent module: the full Phase-2 analysis, `analyze_component`, and CSS analysis.
- [compiler-analyzer_visitors](compiler-analyzer_visitors.md) — the per-node visitors that run under `set_scope` and refine bindings.
- [compiler-analyzer_css_analysis](compiler-analyzer_css_analysis.md) — CSS scoping/`{}`-global analysis performed after JS/template analysis.
- [compiler-core](compiler-core.md) — shared AST utilities, builders, errors/warnings infrastructure.
- [compiler-parser](compiler-parser.md) — produces the AST consumed by `create_scopes`.
- [compiler-transformer](compiler-transformer.md) — Phase-3 consumers of `Scope`/`Binding` metadata (client, server, CSS transforms).
- [compiler-core_diagnostics](compiler-core_diagnostics.md) — error/warning codes referenced by scope validation.
- [compiler-core_public_api](compiler-core_public_api.md) — `compile()` / `compileModule()` entry points that drive the whole pipeline.
