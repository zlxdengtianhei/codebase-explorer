# Compiler Transformer

## 1. Overview

The **compiler-transformer** is the third and final phase of the Svelte compiler pipeline (`packages/svelte/src/compiler/phases/3-transform/`). It receives the **validated, analyzed AST** produced by [compiler-analyzer](compiler-analyzer.md) and lowers it into executable artifacts:

| Target | Output | Produced by |
|---|---|---|
| `generate: 'client'` (default) | Interactive component code that calls into the **client runtime** (`svelte/internal/client`) | client visitors |
| `generate: 'server'` | SSR render function that pushes HTML strings into `$$payload.out` via the **server runtime** (`svelte/internal/server`) | server visitors |
| both | **Scoped, pruned, (optionally minified) CSS** via `render_stylesheet` | CSS transformer |

Its public entry point is `transform_component(analysis, source, options)` / `transform_module(...)` in `phases/3-transform/index.js`. Both functions:

1. Dispatch to the client- or server-side transform based on `options.generate`.
2. Print the resulting ESTree program with `esrap` (TypeScript printer), attaching comments and merged preprocessor source maps.
3. Return a `CompileResult` (`{ js, css, metadata, warnings, ast }`) — the shape documented in [compiler-core](compiler-core.md) (`CompileResult` in `compiler/types/index.d.ts`).

> The transformer performs **no validation** of user code. All errors and warnings were already emitted during [analysis](compiler-analyzer.md); here the AST is trusted and rewritten.

## 2. Architecture Overview

The transformer is a set of **target-specific visitor maps** applied with the `zimmerframe` `walk` engine. Each AST node type is handled by a visitor function that returns a *new* ESTree node (or mutates the surrounding output state), while shared state flows down the traversal.

```mermaid
flowchart TD
    subgraph INPUT
        A["AST (Root) + Analysis\n(scopes, bindings, metadata)"]
        O["ValidatedCompileOptions"]
    end

    subgraph "3-transform/index.js — orchestration"
        E["transform_component\ntransform_module"]
    end

    subgraph TARGETS
        C["client/\nclient_component / client_module\n(transform-client.js)"]
        S["server/\nserver_component / server_module\n(transform-server.js)"]
        CSS["css/\nrender_stylesheet"]
    end

    subgraph SHARED ["Shared infrastructure"]
        U["utils.js — clean_nodes,\nnamespaces, inspect runes"]
        T["types.d.ts — TransformState"]
    end

    subgraph OUTPUT
        P["esrap print → js + sourcemap"]
        R["CompileResult"]
    end

    A --> E
    O --> E
    E -->|generate = client| C
    E -->|generate = server| S
    E --> CSS
    C --> U
    S --> U
    C --> P
    S --> P
    P --> R
    CSS --> R
    T -. state contract .-> C
    T -. state contract .-> S
```

### 2.1 Sub-modules

| Sub-module | Location | Responsibility | Documentation |
|---|---|---|---|
| **Client transform** | `3-transform/client/` | Lowers the AST into a hydrated, reactive client component: hoisted HTML templates, signal reads/writes, effects, DOM blocks, events, bindings, transitions, class `#state` fields | [compiler-transformer_client-transform.md](compiler-transformer_client-transform.md) |
| **Server transform** | `3-transform/server/` | Lowers the AST into a synchronous SSR function that streams template literals (with hydration markers) into `$$payload.out` | [compiler-transformer_server-rendering.md](compiler-transformer_server-rendering.md) |
| **CSS transform** | `3-transform/css/` + `phases/css.js` | Scopes selectors with the component hash, rewrites `:global`/`-global-` keyframes, prunes unused rules, bumps specificity, minifies, generates CSS source maps | [compiler-transformer_css-transform.md](compiler-transformer_css-transform.md) |
| **Shared infrastructure** | `3-transform/utils.js`, `3-transform/types.d.ts` | Node cleaning/hoisting (`clean_nodes`), html/svg/mathml namespace inference, `$inspect` lowering, base `TransformState` contract | [compiler-transformer_shared-infrastructure.md](compiler-transformer_shared-infrastructure.md) |

### 2.2 The visitor/state model

Every target builds a `Visitors` object — a map from `AST.SvelteNode.type` (template nodes) or `estree` node type (script nodes) to a handler — and calls `walk(ast, state, visitors)`. State objects (declared in `types.d.ts` files) carry everything a visitor needs:

```mermaid
classDiagram
    class TransformState {
        +Analysis analysis
        +ValidatedCompileOptions options
        +Scope scope
        +Map scopes
        +Map state_fields
    }
    class ClientTransformState {
        +bool in_constructor
        +bool in_derived
        +bool is_instance
        +Record transform
    }
    class ComponentClientTransformState {
        +Statement[] init
        +Statement[] update
        +Statement[] after_update
        +Statement[] consts
        +Statement[] hoisted
        +Template template
        +Memoizer memoizer
        +Identifier node
        +Map legacy_reactive_statements
        +VariableDeclaration[] instance_level_snippets
        +VariableDeclaration[] module_level_snippets
    }
    class ServerTransformState {
        +Statement[] init
        +Expression[] template
        +Namespace namespace
        +bool skip_hydration_boundaries
    }
    TransformState <|-- ClientTransformState
    TransformState <|-- ServerTransformState
    ClientTransformState <|-- ComponentClientTransformState
```

The most important piece of state is the **`transform` map** (client side): for each binding that represents reactive state, it records *how to read / assign / mutate / update* it at this position in the tree. Visitors rewrite identifiers through it via `build_getter`, turning `count` into `$.get(count)` or `$$props.count` depending on the binding kind (`state`, `derived`, `prop`, `store_sub`, …).

### 2.3 Runtime contract

Generated code is only half of the story: the visitors emit calls into `$.`-namespaced runtime helpers (e.g. `$.get`, `$.template_effect`, `$.each`, `$.if`, `$.await`, `$.slot`, `$.html`, `$.store_set`, `$.escape`). Those helpers live in the sibling runtimes:

- Client helpers → [Client Runtime Engine (Reactivity & DOM Rendering)](Client_Runtime_Engine.md) (`internal/client/reactivity/*`, `internal/client/dom/blocks/*`)
- Server helpers → [Server-Side Rendering & Cross-Target Runtime Services](Server-Side_Rendering___Cross-Target_Runtime_Services.md) (`internal/server/index.js`, `internal/server/hydration.js`)

## 3. Data Flow

```mermaid
sequenceDiagram
    participant CP as compiler/index.js
    participant AN as Analyzer (phase 2)
    participant TR as transform_component
    participant CV as Client visitors
    participant SV as Server visitors
    participant CS as CSS transform
    participant PR as esrap print

    CP->>AN: analyze(parse result)
    AN-->>CP: ComponentAnalysis (scopes, bindings, css.ast, metadata)
    CP->>TR: (analysis, source, options)
    alt generate = client
        TR->>CV: walk(module.ast), walk(instance.ast), walk(template.ast)
        CV-->>TR: ESTree Program (hoisted templates + component body)
    else generate = server
        TR->>SV: walk(module.ast), walk(instance.ast), walk(template.ast)
        SV-->>TR: ESTree Program (server render function)
    end
    TR->>CS: render_stylesheet(source, analysis, options)
    CS-->>TR: { code, map, hasGlobal }
    TR->>PR: print(program, ts(...))
    PR-->>CP: CompileResult { js, css, metadata, warnings }
```

### 3.1 Client-side assembly (`client_component`)

The client transform walks three ASTs in order — **module** (`<script module>` context), **instance** (`<script>` context), and **template** — sharing accumulated state. Afterwards it stitches the final component function:

- store subscriptions (`$.setup_stores`) and legacy reactive declarations,
- topologically ordered `$:` reactive statements,
- hoisted templates (`$.from_html`/`$.from_tree`),
- the exported object (getters/setters for `accessors`, `$$props` handling),
- `$.push(...)` / `$.pop(...)` legacy context frame, CSS injection (`$.append_styles`) when `injectStyles` is set.

### 3.2 Server-side assembly (`server_component`)

Mirrors the client but produces a single synchronous render function. Template visitors append string literals and expressions to `state.template`, which `build_template` concatenates into `$$payload.out.push(...)` calls. Control blocks (`{#if}`, `{#each}`, `{#await}`, `<svelte:boundary>`) are wrapped in the special hydration comments `BLOCK_OPEN`/`BLOCK_CLOSE`/`EMPTY_COMMENT` from `internal/server/hydration.js` so the client can patch them later.

## 4. Key Concepts

- **Runes vs legacy mode**: visitors branch on `analysis.runes`. In runes mode `$state`/`$derived` calls become `$.state`/`$.derived` signals; in legacy mode `export let` becomes prop destructuring, `$:` labels become `$.legacy_pre_effect` calls, and stores are auto-subscribed.
- **Hoisting**: functions referenced from templates get their free variables turned into explicit parameters (`build_hoisted_params`, `visit_function`) so handlers can live outside the component body; snippets are hoisted to instance/module scope (`SnippetBlock` visitors).
- **Static/dynamic split**: static markup is compiled into an HTML string template (client) or string literal (server); only dynamic parts generate effects/updates. `clean_nodes` performs whitespace trimming, comment removal and const-tag hoisting that both targets rely on.
- **Dev-mode instrumentation**: `dev`-gated code adds reactivity tags (`$.tag`), ownership validation, equality checks (`$.equals`), snippet-arg validation, and `{@debug}`/`$inspect` support.
- **Async (experimental)**: expressions containing top-level `await` are wrapped in `$.async`/`$.async_body` blocks so the client can resume rendering after resolution (`has_await` metadata computed in the analyzer).

## 5. Related Modules

- [compiler-core](compiler-core.md) — AST node types, ESTree **builders** (`b.*`), errors/warnings/state used throughout the transformer.
- [compiler-analyzer](compiler-analyzer.md) — produces the `Analysis`, scopes, bindings and per-node `metadata` the transformer consumes.
- [compiler-preprocessor](compiler-preprocessor.md) — sourcemaps produced upstream are merged back into the transformer's output via `merge_with_preprocessor_map`.
- [compiler-parser](compiler-parser.md) — upstream phase; [compiler-migrator](compiler-migrator.md) reuses the transform's AST shape for codemods.
- [Public API & Built-in Feature Surface](Public_API___Built-in_Feature_Surface.md) — `compile`/`compileModule` options that steer the transformer (`generate`, `css`, `dev`, `preserveWhitespace`, …).
