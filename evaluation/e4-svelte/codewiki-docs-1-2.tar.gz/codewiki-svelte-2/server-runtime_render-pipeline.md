# Server Runtime — Render Pipeline

## Overview

The `server-runtime_render-pipeline` module is the orchestrating heart of Svelte's server-side rendering (SSR) engine, implemented in `packages/svelte/src/internal/server/index.js`. It takes a **compiled component function** (emitted by the compiler's server transform — see [compiler-transformer_server-transform](compiler-transformer_server-transform.md)) and drives it to produce a plain string of HTML that can be streamed or returned to clients, with hydration markers embedded so the client runtime can later take over (see [client-dom-renderer](client-dom-renderer.md)).

Its public surface is the `render(component, options)` function — re-exported to applications as `svelte/server`'s `render` (see [public-api](public-api.md)) — plus a set of low-level template emission helpers (`element`, `head`, `await`, `css_props`, `valueless_option`, `maybe_selected`, `ensure_array_like`) that generated component code calls directly.

### Core Responsibilities

| Concern | Implementation | Notes |
|---|---|---|
| Render orchestration | `render()` | Creates the `Payload`, invokes the component, assembles `RenderOutput` |
| Head content assembly | `head()` | Delegates into the payload's head sub-buffer |
| Element emission | `element()` | Tag + attributes + children, with hydration anchors |
| Async control flow | `await_block` (exported as `await`) | Synchronous pending/then branching for promises |
| Scoped CSS properties | `css_props()` | Emits `<svelte-css-wrapper>` / `<g>` style carriers |
| `<option>` selection | `valueless_option()`, `maybe_selected()` | Valueless-option `selected` detection via output comparison |
| Each-block input normalization | `ensure_array_like()` | Coerces iterables to arrays |
| Cleanup & teardown | `on_destroy` queue + `abort()` | Runs `onDestroy` callbacks; cancels stale reactive contexts |

### Position in the System

```mermaid
flowchart TB
    subgraph Compiler["Compiler Pipeline (build time)"]
        CT[compiler-transformer_server-transform<br/>emits component code that calls SSR helpers]
    end

    subgraph Public["Public API"]
        PA["svelte/server — render()<br/>(public-api)"]
    end

    subgraph ThisModule["server-runtime_render-pipeline (this module)"]
        R["render()"]
        EL["element()"]
        HD["head()"]
        AW["await_block()"]
        CP["css_props()"]
        OPT["valueless_option() / maybe_selected()"]
        EAL["ensure_array_like()"]
    end

    subgraph Siblings["Sibling server-runtime modules"]
        PY["payload-and-output<br/>Payload · assign/copy_payload · props_id"]
        AT["attributes-and-props<br/>attr_class · attr_style · spread_* · stringify"]
        SL["slots-snippets-and-blocks<br/>slot · sanitize_slots · html · createRawSnippet"]
        ST["store-integration<br/>store_get · store_mutate · update_store"]
        DD["dev-diagnostics<br/>push/pop_element · validate_snippet_args · getAbortSignal"]
    end

    subgraph Cross["Cross-cutting modules"]
        CX["context-api<br/>push() · pop() · current_component"]
        SH["internal-shared-utils<br/>noop · run · to_array · escape_html"]
        CR["client-dom-renderer<br/>consumes hydration markers on hydration"]
    end

    CT -->|"generated code calls"| ThisModule
    PA --> R
    R --> EL & HD & AW & CP & OPT & EAL
    R -->|"payload buffers"| PY
    EL -->|"attribute emission"| AT
    R -->|"slot resolution"| SL
    ST -->|"store values interpolated into output"| EL
    R -->|"DEV element stack"| DD
    R -->|"context push/pop"| CX
    ThisModule --> SH
    ThisModule -->|"\<!--\[--> markers"| CR

    style ThisModule fill:#2d4a3e,color:#fff
```

---

## Architecture

The module follows a **buffer-driven, push-based emission model**: nothing builds an intermediate DOM or virtual tree. Every helper appends string fragments into `payload.out` (an ordered `string[]`), and `render()` finally joins them. This keeps SSR allocation-light and naturally ordered.

```mermaid
flowchart LR
    subgraph RenderEntry["render()"]
        A["1. new Payload(idPrefix)"] --> B["2. Swap on_destroy queue"]
        B --> C["3. Emit BLOCK_OPEN marker"]
        C --> D{"options.context?"}
        D -->|yes| E["push() + attach context map"]
        D -->|no| F
        E --> F["4. component(payload, props, {}, {})"]
        F --> G{"options.context?"}
        G -->|yes| H["pop()"]
        G -->|no| I
        H --> I["5. Emit BLOCK_CLOSE marker"]
        I --> J["6. Run onDestroy cleanups"]
        J --> K["7. Join head + css styles"]
        K --> L["8. Join body"]
        L --> M["Return { head, html, body }"]
        M --> N["finally: abort()"]
    end

    subgraph Buffers["Payload state (see server-runtime_payload-and-output)"]
        O["out: string[] — body fragments"]
        P["head.out: string[] — head fragments"]
        Q["css: Set — {hash, code} style entries"]
        S["uid(): unique id generator"]
        T["select_value: current select value"]
    end

    F -->|"appends"| O
    HD --> P
    Q --> K
```

### Component Inventory

| Export | Kind | Contract |
|---|---|---|
| `render(component, options?)` | Entry point | `component` is the compiled `(payload, props, $$sanitized_props?, $$slots?)` function. Returns `RenderOutput { head, html, body }`. |
| `head(payload, fn)` | Buffer writer | Runs `fn` against `payload.head`, wrapped in hydration open/close markers. |
| `element(payload, tag, attributes_fn?, children_fn?)` | Buffer writer | Emits one HTML element with `<!---->` anchors before/after. |
| `await_block(payload, promise, pending_fn, then_fn)` — exported as `await` | Control flow | Synchronous promise inspection; never awaits. |
| `css_props(payload, is_html, props, component, dynamic?)` | Style scoping | Emits a wrapper element carrying CSS custom properties. |
| `valueless_option(payload, children)` | HTML semantics | Renders `<option>` children and marks ` selected` by comparing rendered text to `payload.select_value`. |
| `maybe_selected(payload, value)` | HTML semantics | Returns `' selected'` when `value === payload.select_value`. |
| `ensure_array_like(v)` | Utility | Returns arrays/array-likes as-is, materializes iterables, defaults to `[]`. |
| `on_destroy` (module-level, mutable) | Cleanup registry | Collected `onDestroy` callbacks for the current render; swapped/restored per render for reentrancy. |

---

## Data Flow: A `render()` Call End-to-End

```mermaid
sequenceDiagram
    autonumber
    participant App as Application / Framework
    participant RP as render() (this module)
    participant PY as Payload (payload-and-output)
    participant C as Compiled Component
    participant H as Helper functions
    participant CX as context-api
    participant DD as dev-diagnostics

    App->>RP: render(Component, { props, context, idPrefix })
    RP->>PY: new Payload(idPrefix)
    Note over PY: out=[], css=Set, uid=props_id_generator(prefix), head=HeadPayload
    RP->>RP: on_destroy = [] (save previous queue)
    RP->>PY: out.push("<!--svelte-->") (BLOCK_OPEN)
    opt options.context provided
        RP->>CX: push()
        RP->>CX: current_component.c = context map
    end
    RP->>C: component(payload, props, {}, {})
    loop during component execution
        C->>H: element / attr / slot / await / store_get ...
        H->>PY: out.push(fragment) / head.out.push(fragment)
        opt DEV
            H->>DD: push_element / pop_element (HTML nesting validation)
        end
    end
    opt options.context provided
        RP->>CX: pop() (drains component.d → on_destroy)
    end
    RP->>PY: out.push("<!--/svelte-->") (BLOCK_CLOSE)
    RP->>RP: for cleanup of on_destroy: cleanup()
    RP->>RP: restore previous on_destroy queue
    RP->>RP: head = head.out.join('') + head.title<br/>head += <style id=hash> for each css entry
    RP->>RP: body = out.join('')
    RP-->>App: { head, html: body, body }
    RP->>DD: finally → abort() (cancel stale AbortController)
```

Key behaviors worth noting:

- **Reentrancy safety**: `on_destroy` is saved and restored around each `render()` call, and `pop()` (from [context-api](context-api.md)) pushes the component's registered `onDestroy` callbacks (stored as `component.d`) onto the active queue — so nested/serialized renders never leak callbacks into each other.
- **Guaranteed teardown**: `abort()` runs in a `finally` block, so even a throwing component cancels any in-flight reactive contexts via the stale-reaction signal (see [server-runtime_dev-diagnostics](server-runtime_dev-diagnostics.md)).
- **DEV corruption guard**: in dev mode, `render()` snapshots the element-validation stack via `reset_elements()` and restores it afterwards, so a bad render cannot poison the parent's push/pop element state.

---

## Process Flows

### Element Emission (`element`)

`element()` surrounds the tag with `<!---->` empty comments. These anchors give the client hydration pass stable "reset" points so it can unambiguously walk the server HTML regardless of surrounding content.

```mermaid
flowchart TD
    S["element(payload, tag, attrs_fn, children_fn)"] --> A["out.push('\<!----\>')"]
    A --> B{"tag truthy?"}
    B -->|no| Z["out.push('\<!----\>')"] --> End([done])
    B -->|yes| C["out.push('\<tag')"]
    C --> D["attributes_fn() — writes attributes<br/>(see server-runtime_attributes-and-props)"]
    D --> E["out.push('\>')"]
    E --> F{"is_void(tag)<br/>e.g. br, img, input?"}
    F -->|yes| Z
    F -->|no| G["children_fn()"]
    G --> H{"is_raw_text_element(tag)<br/>script, style, textarea?"}
    H -->|yes| I["no anchor (preserve raw text)"]
    H -->|no| J["out.push(EMPTY_COMMENT)"]
    I --> K["out.push('\</tag\>')"]
    J --> K
    K --> Z

    style S fill:#2d4a3e,color:#fff
```

The void/raw-text decisions mirror the HTML spec, ensuring e.g. `<script>` contents are not polluted with hydration comments while regular containers receive exactly one trailing anchor.

### Async Branching (`await_block`, exported as `await`)

SSR **never awaits** promises — it synchronously inspects them and renders one branch, leaving resumption to the client (or to streaming wrappers built atop this module):

```mermaid
flowchart TD
    S["await(payload, promise, pending_fn, then_fn)"] --> Q{"is_promise(promise)?"}
    Q -->|yes| P1["out.push(BLOCK_OPEN '·\<!--svelte--\>')"]
    P1 --> P2["promise.then(null, noop)<br/>(swallow unhandled rejection)"]
    P2 --> P3{"pending_fn !== null?"}
    P3 -->|yes| P4["pending_fn() — render pending branch"]
    P3 -->|no| Done([done])
    P4 --> Done
    Q -->|no, already resolved| T1{"then_fn !== null?"}
    T1 -->|yes| T2["out.push(BLOCK_OPEN_ELSE)"]
    T2 --> T3["then_fn(value) — render then branch with the value"]
    T1 -->|no| Done
    T3 --> Done

    style S fill:#2d4a3e,color:#fff
```

The emitted `<!--svelte-->` / `<!--svelte-else-->` markers are exactly the constants the client's await block expects when hydrating — the two runtimes are marker-compatible by design (see [client-dom-renderer](client-dom-renderer.md), `dom/blocks/await.js`).

### CSS Custom Property Scoping (`css_props`)

CSS custom properties (`--x: …`) set via `style:` directives inside a component must be scoped to that component's subtree. On the server this is materialized as a wrapper element:

- HTML namespace → `<svelte-css-wrapper style="display: contents; --x: …">` — the `display: contents` keeps the wrapper layout-neutral.
- SVG namespace → `<g style="--x: …">` — because `display: contents` and the custom element are invalid in SVG.

When `dynamic` is true (values can change after hydration), an extra `<!---->` anchor is emitted immediately after the opening tag so the client can re-target the style without disturbing children.

### `<option>` Selection (`valueless_option`, `maybe_selected`)

A `<option>` without a `value` attribute uses its text content as its value. Since the server cannot compare against DOM text before writing it, `valueless_option()` uses a **write-then-inspect** strategy:

1. Record the current `payload.out` length index `i`.
2. Render the option's children into the buffer.
3. Join the fragments written after `i`, strip `<!---->` anchors, and compare the resulting text to `payload.select_value` (set upstream by the `<select>` handling).
4. On a match, rewrite the *previous* buffer entry: replace its trailing `>` with ` selected>` and collapse the appended children into a single buffer entry (minimizing string array churn).

`maybe_selected()` is the simpler sibling for options rendered with an explicit `value`: it returns `' selected'` when the value matches `payload.select_value`.

### Each-Block Input Normalization (`ensure_array_like`)

`{#each}` blocks accept arrays, strings, and arbitrary iterables. `ensure_array_like` returns array-likes (anything with a `length`) untouched, materializes iterables via `Array.from`, and coerces `null`/`undefined` to `[]` — guaranteeing generated code can always index with `[i]` and read `.length`.

---

## Component Interaction Map

How the render pipeline collaborates with its sibling modules inside `server-runtime`:

```mermaid
flowchart TB
    subgraph Generated["Generated component function (per component)"]
        G["component(payload, props, {}, {})"]
    end

    G -->|"create + read/destroy"| SG["server-runtime_store-integration<br/>store_get allocates + subscribes;<br/>unsubscribe_stores tears down at render end"]
    G -->|"attrs → string"| AB["server-runtime_attributes-and-props<br/>attr_class / attr_style / spread_attributes / stringify"]
    G -->|"slot dispatch"| SB["server-runtime_slots-snippets-and-blocks<br/>slot() resolves \$\$slots or children prop;<br/>html() / createRawSnippet() push raw fragments"]
    G -->|"fragment ids"| PO["server-runtime_payload-and-output<br/>props_id() → '\<!--#sN--\>' via payload.uid()"]
    G -->|"DEV: HTML nesting checks"| DV["server-runtime_dev-diagnostics<br/>push_element / pop_element / validate_snippet_args"]

    AB -->|"attr()/escape_html"| Shared["internal-shared-utils & shared/attributes.js"]
    DV -->|"renders warnings into head"| Head["payload.head.out"]
```

Note the deliberate division of labor: this module owns **orchestration and template-level emission** (the structural skeleton of the output), while siblings own **value-level concerns** (attribute serialization, prop merging, store lifecycle, snippet plumbing, diagnostics).

---

## Output Contract

`render()` returns a `RenderOutput` (typed in [server-runtime_payload-and-output](server-runtime_payload-and-output.md)):

- **`head`** — concatenation of the head payload's fragments, the head's `title`, and one `<style id="{hash}">…</style>` per entry in `payload.css` (component-scoped CSS collected by the compiler's CSS transform, see [compiler-transformer_css-transform](compiler-transformer_css-transform.md)).
- **`html`** *(deprecated alias)* and **`body`** — the joined body fragments, i.e. everything between the outer `<!--svelte-->` / `<!--/svelte-->` hydration markers.

Consumers typically splice `head` into the document's `<head>` and `body` into the response. The hydration markers at the boundaries let [client-dom-renderer](client-dom-renderer.md) locate the component's root during `hydrate()`.

---

## Integration Summary

| Interaction | Direction | Module |
|---|---|---|
| Receives compiled component code that calls `element`, `attr`, `slot`, `await`, … | inbound | [compiler-transformer_server-transform](compiler-transformer_server-transform.md) / [compiler-transformer_server-rendering](compiler-transformer_server-rendering.md) |
| Uses `push`/`pop` and `current_component` for context propagation and `onDestroy` collection | inbound dependency | [context-api](context-api.md) |
| Buffers output in `Payload`; generates unique ids via `props_id_generator` | inbound dependency | [server-runtime_payload-and-output](server-runtime_payload-and-output.md) |
| Serializes attributes/classes/styles into `payload.out` | called by generated code | [server-runtime_attributes-and-props](server-runtime_attributes-and-props.md) |
| Resolves slots/snippets and raw HTML fragments | called by generated code | [server-runtime_slots-snippets-and-blocks](server-runtime_slots-snippets-and-blocks.md) |
| Provides store subscribe/mutate/unsubscribe helpers used inside renders | called by generated code | [server-runtime_store-integration](server-runtime_store-integration.md) |
| Supplies `abort()`, element-stack reset, and DEV snippet validation | inbound dependency | [server-runtime_dev-diagnostics](server-runtime_dev-diagnostics.md) |
| Shares `noop`, `run`, `to_array`, `escape_html`, `attr`, `clsx`, `to_class`, `to_style`, `is_void`, `is_raw_text_element`, `is_promise` | inbound dependency | [internal-shared-utils](internal-shared-utils.md) |
| Exposes `render` publicly as `svelte/server` | outbound | [public-api](public-api.md) |
| Consumes emitted hydration markers (`<!--svelte-->`, `<!---->`, `<!--#sN-->`) during client hydration | outbound contract | [client-dom-renderer](client-dom-renderer.md) |

## Design Notes for Maintainers

1. **Strings, not structures.** Every helper appends to `payload.out` directly; there is no intermediate AST at render time. Any new template-level construct must follow the *anchor discipline*: wrap content in `<!---->` (or the named `<!--svelte…-->` markers) so client hydration can re-derive boundaries — see `dom/hydration.js` in the client runtime for the consuming side.
2. **`on_destroy` is module-global by design** (avoids threading state through every helper), which is exactly why `render()` must swap and restore it; never assume it outlives a single render call.
3. **Buffer index manipulation** (`valueless_option` rewriting `out[i - 1]` and splicing) is intentional micro-optimization; preserve the invariant that anchors are only removed from the *comparison copy*, never from the real buffer before emission.
4. **The `finally { abort() }` is load-bearing**: it prevents leaked `AbortController`s across renders and signals stale reactions, complementing `getAbortSignal()` in [server-runtime_dev-diagnostics](server-runtime_dev-diagnostics.md).
5. **Error swallowing in `await_block`** (`promise.then(null, noop)`) is deliberate: an unhandled rejection during SSR would crash the server even though the pending branch was intentionally rendered.
