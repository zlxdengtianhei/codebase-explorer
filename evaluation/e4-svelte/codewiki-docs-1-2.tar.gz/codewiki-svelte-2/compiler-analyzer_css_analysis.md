# compiler-analyzer_css_analysis

## 1. Introduction

`compiler-analyzer_css_analysis` is the CSS sub-module of the Svelte compiler's **analysis phase (Phase 2)**. It is implemented in a single file, `packages/svelte/src/compiler/phases/2-analyze/css/css-analyze.js`, which exports one entry point — `analyze_css()` — plus the internal predicates `is_global_block_selector`, `is_in_global_block`, and `is_unscoped`.

Svelte components can embed `<style>` blocks. Before Svelte can compile those styles into scoped CSS (hash-scoped class selectors, renamed keyframes, pruned unused rules), the compiler must **understand** the stylesheet:

- **Classify** every selector as *scoped*, *global* (`:global(...)`), or *global-like* (`:host`, `:root`, `view-transition` pseudo-elements, …).
- **Validate** the placement and shape of `:global` usage so that removing `:global(...)` later cannot produce invalid or unintended CSS.
- **Record** which `@keyframes` names exist and whether the component contributes *unscoped global CSS* at all.

This module performs exactly that classification, validation, and metadata bookkeeping. It **does not** rewrite or remove CSS — transformation happens later in the [compiler-transformer](compiler-transformer.md) module, and "unused selector" detection is split between this module (which seeds `metadata.used` for global selectors) and the sibling pruning/warning steps (`css-prune.js`, `css-warn.js`).

---

## 2. Location in the Compiler Pipeline

The Svelte compiler is organized in three phases (see [Compiler_Pipeline___Language_Toolchain](Compiler_Pipeline___Language_Toolchain.md)):

1. **Parse** ([compiler-parser](compiler-parser.md)) — produces the component AST including a `StyleSheet` AST (`AST.CSS.StyleSheet`) for `<style>` content.
2. **Analyze** ([compiler-analyzer](compiler-analyzer.md)) — walks the AST, builds scopes, collects bindings, and validates semantics. `analyze_component()` (`phases/2-analyze/index.js`) owns the overall flow; this module is the CSS branch of that flow.
3. **Transform** ([compiler-transformer](compiler-transformer.md)) — emits client/server output. The CSS transform (`phases/3-transform/css/index.js`) consumes the metadata this module computes.

Within Phase 2 the module sits in a three-step CSS pipeline, all orchestrated from `analyze_component()`:

| Step | File | Responsibility |
|---|---|---|
| **1. Analyze** *(this module)* | `phases/2-analyze/css/css-analyze.js` | Validate `:global` usage, classify selectors, collect keyframes, seed `used` flags, set `css.has_global` |
| **2. Prune** | `phases/2-analyze/css/css-prune.js` (`prune()`) | For each rendered element, try to match selectors; mark matching `ComplexSelector`s as `used` |
| **3. Warn** | `phases/2-analyze/css/css-warn.js` (`warn_unused()`) | Emit the `css_unused_selector` warning for selectors that were never marked used |

```mermaid
flowchart TB
    subgraph Phase1["Phase 1 — compiler-parser"]
        PARSER["parse()<br/>(phases/1-parse)"] --> CSSAST["AST.CSS.StyleSheet<br/>(css.d.ts node types)"]
    end

    subgraph Phase2["Phase 2 — compiler-analyzer"]
        AC["analyze_component()<br/>phases/2-analyze/index.js"]
        subgraph THIS["css_analysis (this module)"]
            AZ["analyze_css()<br/>+ is_global_block_selector /<br/>is_in_global_block / is_unscoped"]
            VIS["css_visitors: Atrule, Rule,<br/>RelativeSelector, ComplexSelector,<br/>NestingSelector"]
            AZ --> VIS
        end
        PRUNE["css-prune.js :: prune()"]
        CSWARN["css-warn.js :: warn_unused()"]
    end

    subgraph Core["compiler-core (shared)"]
        ERR["errors.js — css_* CompileError codes"]
        WARN["warnings.js — css_unused_selector"]
        UTILS["2-analyze/css/utils.js —<br/>is_global(), is_unscoped_pseudo_class()"]
        CSSJS["phases/css.js — is_keyframes_node()"]
    end

    subgraph Phase3["Phase 3 — compiler-transformer"]
        XFORM["3-transform/css/index.js<br/>remove_global_pseudo_class(),<br/>keyframes renaming, scoping"]
    end

    CSSAST --> AC
    AC -->|"if analysis.css.ast"| AZ
    UTILS --> VIS
    CSSJS --> VIS
    VIS -->|"throws"| ERR
    AC --> PRUNE
    AC --> CSWARN
    CSWARN --> WARN
    PRUNE --> XFORM
    CSWARN --> XFORM
```

---

## 3. Module Architecture

### 3.1 Public entry point

```js
/**
 * @param {AST.CSS.StyleSheet} stylesheet
 * @param {ComponentAnalysis} analysis
 */
export function analyze_css(stylesheet, analysis)
```

`analyze_css()` initializes a `CssState` object and walks the entire stylesheet AST with the `zimmerframe` `walk()` utility, applying the `css_visitors` visitor map. The function returns nothing — **all results are expressed as in-place mutations** of the CSS AST node `metadata` objects and of the shared `ComponentAnalysis`.

### 3.2 Traversal state (`CssState`)

```js
/** @typedef {{
 *   keyframes: string[];              // alias of analysis.css.keyframes
 *   rule: AST.CSS.Rule | null;        // innermost enclosing rule being visited
 *   analysis: ComponentAnalysis;      // the shared per-component analysis
 * }} CssState
 */
```

| Field | Purpose |
|---|---|
| `keyframes` | Direct reference to `analysis.css.keyframes`; the `Atrule` visitor appends local (scoped) `@keyframes` names here. |
| `rule` | Points to the `Rule` currently being visited. The `Rule` visitor pushes a fresh state (`{ ...context.state, rule: node }`) when descending into `prelude` and `block`, which lets descendants link `metadata.parent_rule` / `metadata.rule` back to their owner. |
| `analysis` | The component-wide analysis object; the visitors write `analysis.css.has_global` and read/write `analysis.css.keyframes`. |

### 3.3 Internal predicates

| Function | Signature | Semantics |
|---|---|---|
| `is_global_block_selector` | `(SimpleSelector) → boolean` | `true` for a **bare** `:global` — a `PseudoClassSelector` named `global` whose `args === null`. This is the form that opens a global *block* (`:global { … }`), as opposed to the functional form `:global(…)`. |
| `is_unscoped` | `(path: SvelteNode[]) → boolean` | `true` if **every** `Rule` on the ancestor `context.path` has `metadata.has_global_selectors` — i.e. the enclosing rule chain constrains nothing, so styles emitted there are unconditionally global. |
| `is_in_global_block` | `(path: CSS.Node[]) → boolean` | `true` if **any** `Rule` on the path is a global block (`metadata.is_global_block`). Used to skip collecting keyframes names that will be emitted unscoped anyway. |

These predicates are consumed by the visitors (and `is_unscoped`/`is_in_global_block` logic is re-implemented in the transform phase's `phases/3-transform/css/index.js`, which mirrors the same notion when stripping `:global`).

### 3.4 Shared helpers (defined in sibling files, linked for reference)

- `is_global(relative_selector)` and `is_unscoped_pseudo_class(selector)` — `phases/2-analyze/css/utils.js`. `is_global` decides whether a whole relative selector is global; `is_unscoped_pseudo_class` encodes the subtle rules for `:has` / `:is` / `:where` / `:not` (e.g. `:not(.x .y)` still scopes because multiple inner selectors force scoping).
- `is_keyframes_node(atrule)` — `phases/css.js`: true when the at-rule name, with any vendor prefix removed, equals `keyframes`.

---

## 4. CSS AST Metadata Model

The CSS AST node types live in `compiler/types/css.d.ts` (part of [compiler-core_type_definitions](compiler-core_type_definitions.md)). The analysis phase decorates each node's `metadata` bag; this module is the primary **writer** of the flags below, while `css-prune.js` and the transform phase are consumers.

```mermaid
classDiagram
    direction LR
    class StyleSheet
    class Rule {
        +metadata.parent_rule : Rule~null~
        +metadata.is_global_block : boolean
        +metadata.has_global_selectors : boolean
        +metadata.has_local_selectors : boolean
    }
    class SelectorList
    class Block
    class ComplexSelector {
        +metadata.rule : Rule~null~
        +metadata.is_global : boolean
        +metadata.used : boolean
    }
    class RelativeSelector {
        +metadata.is_global : boolean
        +metadata.is_global_like : boolean
    }
    class ComponentAnalysis {
        +css.keyframes : string[]
        +css.has_global : boolean
    }
    StyleSheet "1" --> "*" Rule : content
    Rule "1" --> "1" SelectorList : prelude
    Rule "1" --> "1" Block : block
    SelectorList --> "*" ComplexSelector
    ComplexSelector --> "*" RelativeSelector : children
    Rule ..> Rule : parent_rule link
    ComplexSelector ..> Rule : metadata.rule link
    CSS_ANALYZE["css-analyze.js"] --> ComponentAnalysis : writes keyframes / has_global
    CSS_ANALYZE --> Rule : writes metadata
    CSS_ANALYZE --> ComplexSelector : writes metadata
    CSS_ANALYZE --> RelativeSelector : writes metadata
```

**How each flag is computed and used:**

| Metadata | Written by | Meaning | Consumed by |
|---|---|---|---|
| `Rule.metadata.parent_rule` | this module (`Rule` visitor) | Enclosing nested rule (CSS nesting chain). | `ComplexSelector`/`NestingSelector` visitors; transform |
| `Rule.metadata.is_global_block` | this module | Rule starts with bare `:global` — everything inside must be emitted unscoped. | `css-prune.js` (visits only preludes of global blocks), transform |
| `Rule.metadata.has_global_selectors` / `has_local_selectors` | this module | Whether the rule's prelude mixes/exclusively-contains global complex selectors. | `is_unscoped()` on ancestor paths; `css.has_global` computation |
| `ComplexSelector.metadata.is_global` | this module | All relative selectors are global or global-like → selector needs no scoping. | `Rule` visitor (aggregates into `has_global_selectors`), `used` seeding |
| `ComplexSelector.metadata.used` | this module (seeded `true` for global selectors), `css-prune.js` (set when an element matches) | Selector applies to at least one element (or is inherently global). | `css-warn.js` → `css_unused_selector` warning |
| `ComplexSelector.metadata.rule` | this module | Back-link from selector to its owning rule. | `css-prune.js` match propagation |
| `RelativeSelector.metadata.is_global` / `is_global_like` | this module | Per-relative-selector globality (`:global(...)` vs `:host`, `:root`, `view-transition`, selectors after bare `:global`). | aggregated by `ComplexSelector` visitor |
| `analysis.css.keyframes` | this module (`Atrule` visitor) | Names of **local** `@keyframes` (global `-global-` ones excluded). | transform renames them to `name-hash` |
| `analysis.css.has_global` | this module | Component contributes CSS that is not scoped (global rules/keyframes with declarations). | output generation & dev-mode style bookkeeping |

---

## 5. Visitor Reference (`css_visitors`)

The traversal order is driven by `Rule`: the `Rule` visitor validates the rule head, then **visits `prelude` first** (so child selector metadata is populated) and only afterwards computes `has_global_selectors` / `has_global`, then visits `block`. The `ComplexSelector` visitor calls `context.next()` **before** its own checks — analysis of nested selectors happens in post-order so inner metadata is already settled.

```mermaid
flowchart TD
    START["analyze_css(stylesheet, analysis)"] --> INIT["CssState = { keyframes, rule: null, analysis }"]
    INIT --> WALK["walk(stylesheet, css_state, css_visitors)"]

    WALK --> ATRULE["Atrule visitor"]
    WALK --> REL["RelativeSelector visitor"]
    WALK --> RULE["Rule visitor"]
    WALK --> NEST["NestingSelector visitor"]
    WALK --> CSEL["ComplexSelector visitor<br/>(post-order)"]

    ATRULE --> KF{"is_keyframes_node?"}
    KF -->|"yes, plain name"| COLLECT["push name → analysis.css.keyframes<br/>(skipped when is_in_global_block)"]
    KF -->|"yes, '-global-' prefix"| GLOBALKF["analysis.css.has_global ||= is_unscoped(path)"]
    KF -->|"no"| NEXT1["context.next()"]

    REL --> COMB["reject leading combinator<br/>(css_selector_invalid)"]
    COMB --> GLOB["compute metadata.is_global via is_global()"]
    GLOB --> GLIKE["compute metadata.is_global_like:<br/>:host, view-transition pseudo-elements,<br/>:root (unless :has(...) present)"]
    GLIKE --> SEED["walk nested selectors: mark used = true<br/>so :root:not(.x) isn't reported unused"]

    RULE --> LINK["metadata.parent_rule = state.rule"]
    LINK --> VALG["validate every bare :global in prelude:<br/>modifier-start / combinator / list /<br/>declaration errors; set is_global_block;<br/>mark trailing selectors used"]
    VALG --> VISP["visit prelude (child metadata first)"]
    VISP --> AGG["has_global_selectors / has_local_selectors<br/>from ComplexSelector.metadata.is_global"]
    AGG --> HG["analysis.css.has_global ||=<br/>has_global_selectors && block has Declarations<br/>&& is_unscoped(path)"]
    HG --> VISB["visit block with rule = node"]

    NEST --> PN{"parent_rule?"}
    PN -->|"none"| CHK["only valid as sole selector of lone :global(...)<br/>else css_nesting_selector_invalid_placement"]
    PN -->|"global block"| CHKB["reject &.foo inside :global {...}<br/>(css_global_block_invalid_modifier_start)"]

    CSEL --> NEXTP["context.next() first"]
    NEXTP --> CHK1["nested bare :global in pseudoclass →<br/>css_global_block_invalid_placement"]
    CHK1 --> CHK2[":global(...) mid-sequence →<br/>css_global_invalid_placement"]
    CHK2 --> CHK3["per-relative-selector checks:<br/>css_global_invalid_selector_list,<br/>css_type_selector_invalid_placement,<br/>css_global_invalid_selector"]
    CHK3 --> META["metadata.rule = state.rule<br/>metadata.is_global = all children global/global-like<br/>metadata.used ||= is_global"]
    META --> NESTUSE["&:hover under :global(.foo) parent →<br/>mark used"]
```

### 5.1 `Atrule` — keyframes accounting

- **Plain `@keyframes name`** (name not starting with `-global-`) that is **not** inside a global block: the name is pushed to `analysis.css.keyframes`. The transform phase later renames these to `name-hash` so keyframes are component-scoped.
- **`@keyframes -global-name`**: contributes to `analysis.css.has_global` when `is_unscoped(context.path)` holds. The block is not required to be non-empty (the name is honored even if the keyframe ends up empty).
- All other at-rules (`:media`, `:supports`, …) just continue traversal via `context.next()`.

### 5.2 `RelativeSelector` — globality classification

1. **Leading combinator check** — a relative selector that begins with a combinator (`>`, `+`, `~`), sits at position 0 of its complex selector, has no parent rule, and is not itself inside a pseudo-class argument is invalid (`css_selector_invalid`).
2. `metadata.is_global` is set from `is_global(node)` — i.e. starts with `:global` and, when arguments are present, every remaining simple selector keeps it global (unscoped pseudo-classes or pseudo-elements).
3. `metadata.is_global_like` is set for:
   - selectors consisting purely of pseudo-class/pseudo-element selectors whose first is `:host`, or a `view-transition*` pseudo-element;
   - selectors containing `:root` — unless they also contain `:has(...)`, because `:root.y:has(.x)` still requires `.x` to be scoped.
4. For global/global-like selectors, nested `ComplexSelector`s (inside `:not(...)`, `:is(...)`, …) are pre-marked `used = true` so that constructs like `:root:not(.x)` do not produce false "unused selector" warnings.

### 5.3 `Rule` — `:global` block validation and aggregation

For each `ComplexSelector` in the prelude:

- `is_global_block_selector()` locates a **bare** `:global` within each relative selector:
  - **`idx === 0`** (selector *starts* with `:global`):
    - A top-level `:global x { … }` (bare `:global` followed by more selectors, first in the list, no parent rule) is rejected with `css_global_block_invalid_modifier_start`. Nested rules or selector lists keep working so that preprocessor output like `:global x, :global y` remains valid.
    - Otherwise the rule becomes a **global block** (`metadata.is_global_block = true`): the remaining selectors are marked `used`, and the following are validated:
      - a non-descendant combinator after `:global` → `css_global_block_invalid_combinator`;
      - `:global, :global x { … }` (a lone-`:global` entry mixed into a list) → `css_global_block_invalid_list`, because it would silently constrain `x`;
      - declarations directly inside a top-level lone `:global { … }` (e.g. `:global { color: red }`) → `css_global_block_invalid_declaration`.
  - **`idx > 0`** (`:global` in the middle of a compound) → `css_global_block_invalid_modifier`.
- If a rule is a global block but *another* entry of the selector list is not → `css_global_block_invalid_list`.

After validation the visitor descends in two steps:

1. Visit `prelude` first, then derive `has_global_selectors` / `has_local_selectors` from each `ComplexSelector.metadata.is_global`.
2. `analysis.css.has_global ||= has_global_selectors && block contains Declarations && is_unscoped(path)` — i.e. the component contains real, unscoped global CSS.
3. Visit `block` with the updated state (`rule: node`) so nested rules link `parent_rule` correctly.

### 5.4 `ComplexSelector` — `:global(...)` placement validation

Run **post-order** (children analyzed first), then:

- Nested bare `:global` inside a pseudo-class (`:not(:global)`) → `css_global_block_invalid_placement`.
- `:global(...)` used mid-sequence (not first/last relative selector, with a non-global selector after it) → `css_global_invalid_placement`; consecutive `:global(...)` entries are allowed.
- Per relative selector, for each `global` pseudo-class:
  - `:global(element)` not at position 0 of a compound → `css_global_invalid_selector_list`;
  - a type selector following `:global(...)` (`:global(.a)element`) → `css_type_selector_invalid_placement`;
  - `:global(a, b)` with multiple selectors inside a compound context → `css_global_invalid_selector`.
- Sets `metadata.rule`, computes `metadata.is_global` (all children global/global-like), seeds `metadata.used ||= is_global`.
- CSS-nesting special case: `&:hover` inside `:global(.foo) { &:hover { … } }` is marked used, since `&` carries no scoping there.

### 5.5 `NestingSelector` — `&` placement

- **Without a parent rule**: `&` is only legal as the sole selector of a lone top-level `:global(&)` (per the CSS nesting spec for `&` outside nested rules); anything else → `css_nesting_selector_invalid_placement`.
- **Inside a top-level bare `:global { … }` block**: `&.foo { … }` → `css_global_block_invalid_modifier_start` (nesting cannot extend a global block at top level).

---

## 6. Error Surface

All failures are hard `CompileError`s thrown through `compiler-core`'s diagnostics registry (see [compiler-core_diagnostics](compiler-core_diagnostics.md)). Each code links to its `svelte.dev/e/<code>` doc page.

| Error code | Thrown from | Scenario |
|---|---|---|
| `css_global_block_invalid_placement` | `ComplexSelector` | bare `:global` nested inside a pseudo-class |
| `css_global_invalid_placement` | `ComplexSelector` | `:global(...)` in the middle of a selector sequence |
| `css_global_invalid_selector_list` | `ComplexSelector` | `:global(element)` not first in a compound selector |
| `css_type_selector_invalid_placement` | `ComplexSelector` | type selector directly after `:global(...)` |
| `css_global_invalid_selector` | `ComplexSelector` | multiple selectors inside `:global(...)` in a compound context |
| `css_selector_invalid` | `RelativeSelector` | relative selector starting with a combinator |
| `css_global_block_invalid_modifier_start` | `Rule`, `NestingSelector` | `:global x { … }` at top level; `&.foo` inside `:global { … }` |
| `css_global_block_invalid_combinator` | `Rule` | non-descendant combinator following bare `:global` |
| `css_global_block_invalid_list` | `Rule` | lone `:global` mixed with non-`:global` list entries; mixed global-block selector lists |
| `css_global_block_invalid_declaration` | `Rule` | declarations directly in a top-level `:global { … }` |
| `css_global_block_invalid_modifier` | `Rule` | bare `:global` not at the start of a selector |
| `css_nesting_selector_invalid_placement` | `NestingSelector` | `&` outside a rule and outside lone `:global(&)` |

One **warning** is related but emitted by the sibling `css-warn.js` step: `css_unused_selector` (see [compiler-core_diagnostics](compiler-core_diagnostics.md)) — this module only *seeds* `metadata.used` so that genuinely-global selectors are never falsely reported.

---

## 7. Integration Flow

`analyze_css()` is invoked once per component from `analyze_component()` (in `phases/2-analyze/index.js`), **after** template/JS walking has collected `analysis.elements`. The sequence below shows the full CSS pipeline handoff:

```mermaid
sequenceDiagram
    autonumber
    participant AC as analyze_component<br/>(2-analyze/index.js)
    participant AZ as analyze_css<br/>(this module)
    participant AST as CSS AST metadata
    participant PR as prune<br/>(css-prune.js)
    participant WN as warn_unused<br/>(css-warn.js)
    participant TX as CSS transform<br/>(3-transform/css)

    AC->>AST: create analysis.css { ast, hash, keyframes: [], has_global: false }
    AC->>AZ: analyze_css(analysis.css.ast, analysis)
    AZ->>AST: set Rule/ComplexSelector/RelativeSelector metadata
    AZ-->>AC: analysis.css.keyframes, analysis.css.has_global populated
    loop for each element in analysis.elements
        AC->>PR: prune(analysis.css.ast, element)
        PR->>AST: ComplexSelector.metadata.used = true on match<br/>(global-block rules: prelude only)
    end
    AC->>WN: warn_unused(analysis.css.ast)
    WN->>WN: css_unused_selector warning for !metadata.used
    Note over TX: later, Phase 3 consumes metadata:<br/>strips :global, scopes selectors,<br/>renames local keyframes
```

Key contract points of this handoff:

- **This module must run before pruning**: `prune()` relies on `Rule.metadata.is_global_block` (to skip matching inside global blocks) and on `ComplexSelector.metadata.rule` back-links, both established here.
- **`metadata.used` seeding is a prerequisite for correct warnings**: global selectors start as `used`; only genuinely matchless *scoped* selectors end up flagged by `css-warn.js`. The `svelte-ignore css_unused_selector` comment is honored by `analyze_component` via `extract_svelte_ignore` before calling `warn_unused`.
- **`analysis.css.has_global` and `analysis.css.keyframes` are outputs consumed by Phase 3** ([compiler-transformer](compiler-transformer.md)): local keyframes get hash-renamed, `-global-` keyframes keep their names with prefix stripped, and `:global` wrappers are removed via `remove_global_pseudo_class` only where this module proved the placement valid.

---

## 8. Dependencies

| Dependency | Kind | Used for |
|---|---|---|
| `zimmerframe` (npm) | external library | `walk()` traversal engine and `Visitors` type; provides `context.next()`, `context.visit()`, `context.path` |
| `compiler/errors.js` | [compiler-core_diagnostics](compiler-core_diagnostics.md) | all `css_*` compile errors thrown during validation |
| `phases/css.js` | sibling phase util | `is_keyframes_node()` |
| `phases/2-analyze/css/utils.js` | sibling CSS util | `is_global()`, `is_unscoped_pseudo_class()` |
| `compiler/types/css.d.ts` | [compiler-core_type_definitions](compiler-core_type_definitions.md) | `AST.CSS.*` node shapes incl. `metadata` bags (`Rule`, `ComplexSelector`, `RelativeSelector`, `SimpleSelector`, `PseudoClassSelector`, `NestingSelector`, `Atrule`, `StyleSheet`) |
| `phases/types.js` (`ComponentAnalysis`) | analyzer state | the shared `analysis` object written into (`css.keyframes`, `css.has_global`) |

---

## 9. Design Notes & Invariants

- **Metadata as the communication channel.** Phases communicate through `node.metadata` rather than by rewriting the AST; this keeps analysis side-effect-free with respect to source text and makes the transform phase the single place that mutates CSS output.
- **Post-order selector analysis.** `ComplexSelector` visits children before validating itself, guaranteeing `RelativeSelector.metadata` is complete before aggregation. Conversely, `Rule` visits its prelude before reading `ComplexSelector.metadata.is_global`.
- **Bare vs. functional `:global`.` `is_global_block_selector` distinguishes `:global { … }` (block scope, `args === null`) from `:global(…)` (functional, `args` present). The two forms follow very different validity rules — blocks propagate unscopedness downward, functions are point-wise removals.
- **`is_unscoped` is chain-based.** A keyframe or declaration counts as global only if *every* enclosing rule is global-selector-only; a single scoped ancestor re-scopes the whole subtree.
- **Deliberate leniency for preprocessor output.** Forms like `:global x, :global y { … }` are accepted (only the *first* selector of a top-level list may not extend a bare `:global`), because preprocessors expand `:global { x, y { … } }` into exactly that shape.
- **Empty `:global` keyframes still count.** `analysis.css.has_global` is updated for `-global-` keyframes regardless of block emptiness, so downstream tooling (HMR style cleanup, injection decisions) never loses track of global styles.

---

## 10. Related Documentation

- [compiler-analyzer](compiler-analyzer.md) — parent analysis phase, `analyze_component()` orchestration, scope construction
- [compiler-analyzer_scope](compiler-analyzer_scope.md) — JS/template scope machinery that runs alongside this CSS pass
- [compiler-analyzer_visitors](compiler-analyzer_visitors.md) — the template/JS visitors executed by the same walk
- [compiler-core_type_definitions](compiler-core_type_definitions.md) — `AST.CSS.*` node and metadata types referenced here
- [compiler-core_diagnostics](compiler-core_diagnostics.md) — error/warning codes incl. `css_unused_selector`
- [compiler-parser](compiler-parser.md) — produces the `StyleSheet` AST consumed by `analyze_css`
- [compiler-transformer](compiler-transformer.md) — consumes this module's metadata (`used`, `is_global_block`, keyframes, `has_global`)
- [Client_Runtime_Engine_(Reactivity___DOM_Rendering)](Client_Runtime_Engine_(Reactivity___DOM_Rendering).md) — runtime counterpart (`append_styles`, `cleanup_styles`) for the emitted CSS
