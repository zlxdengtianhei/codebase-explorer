# Control Flow Blocks (`client-dom-renderer_control-flow-blocks`)

## 1. Introduction

**Control flow blocks** are the runtime primitives that implement Svelte's declarative control flow — `{#if}`, `{#each}`, `{#await}`, `{#key}`, `{#snippet}`, `{#svelte:boundary}`, `{@html}`, `{@render}`, `<svelte:element>`, `<svelte:head>` and CSS-property blocks — in the **client (browser) runtime**.

Every template construct that conditionally creates, destroys, reorders, or retargets DOM nodes at runtime is backed by one of the functions in this module. The compiler emits calls to these functions from compiled component code (see [compiler-transformer_client-transform](compiler-transformer_client-transform.md)), and the blocks in turn coordinate with the signal graph, the effect scheduler, and the DOM reconciliation helpers.

At their core, all blocks share the same architecture:

- They are mounted at an **anchor node** (a comment or text placeholder in the DOM).
- They create a reactive **`block` effect** that re-runs when inputs (conditions, collections, promises, keys, tags) change.
- They render content as **`branch` effects**, which can be **paused** (playing out transitions, then destroyed) or **resumed** (cached content brought back) — instead of naively destroying/recreating DOM.
- They are **hydration-aware** (participating in SSR output reconciliation) and **batch-aware** (deferring DOM commits to the end of a reactive batch).

## 2. Module Inventory

| File | Exports | Svelte syntax | Responsibility |
| --- | --- | --- | --- |
| `dom/blocks/if.js` | `if_block`, `set_branch` | `{#if}/{:else if}/{:else}` | Conditional branch switching with cached branch effects |
| `dom/blocks/each.js` | `each`, `index` | `{#each}` / `{#each ... :else}` | Keyed list rendering with in-place reconciliation (linked list), fallbacks, animations |
| `dom/blocks/await.js` | `await_block` | `{#await ... then ... catch ...}` | Promise state machine (PENDING/THEN/CATCH) driven by effect re-runs |
| `dom/blocks/async.js` | `async` | async expressions (async mode) | Registers pending expressions with the nearest boundary and renders content when values flatten |
| `dom/blocks/boundary.js` | `boundary`, `Boundary`, `get_pending_boundary`, `pending` | `{#svelte:boundary}` | Error boundaries, pending/fallback snippets, `$effect.pending()` support |
| `dom/blocks/key.js` | `key` | `{#key}` | Teardown + re-creation of content when a key expression changes |
| `dom/blocks/snippet.js` | `snippet`, `wrap_snippet`, `createRawSnippet` | `{#snippet}` / programmatic snippets | Dynamic snippet rendering, dev-mode wrapping, raw-snippet creation |
| `dom/blocks/slot.js` | `slot`, `sanitize_slots` | `<slot>` / `{@render children}` | Slot resolution incl. snippet interop and fallbacks |
| `dom/blocks/html.js` | `html` | `{@html ...}` | Raw HTML injection with hash verification during hydration |
| `dom/blocks/css-props.js` | `css_props` | CSS property blocks | Reactive `style.setProperty`/`removeProperty` for `--custom-props` |
| `dom/blocks/svelte-element.js` | `element` | `<svelte:element this={tag}>` | Dynamic tag creation/destruction incl. namespaces and animation context |
| `dom/blocks/svelte-head.js` | `head`, `reset_head_anchor` | `<svelte:head>` | Mounts render effects into `document.head` with independent hydration tracking |

## 3. Architecture

### 3.1 Position in the Client Runtime

The control flow blocks are one child module of the **client DOM renderer**. They sit *between* the reactivity engine (which owns the signal graph and effect scheduling) and the DOM foundation (which owns anchors, templates, and hydration state). Attribute/binding/transition machinery is applied *inside* the render functions that blocks invoke.

```mermaid
graph TB
    subgraph Compiler["Compiler (compile-time)"]
        CT["client transform visitors<br/><i>compiler-transformer_client-transform</i>"]
    end

    subgraph Blocks["client-dom-renderer_control-flow-blocks (this module)"]
        subgraph Conditional["Conditional & Iteration"]
            IF["if.js — if_block"]
            EACH["each.js — each / index"]
            KEY["key.js — key"]
        end
        subgraph AsyncGroup["Async"]
            AWAIT["await.js — await_block"]
            ASYNC["async.js — async"]
            BND["boundary.js — Boundary"]
        end
        subgraph Composition["Composition"]
            SNP["snippet.js — snippet / wrap_snippet / createRawSnippet"]
            SLOT["slot.js — slot / sanitize_slots"]
            HTML["html.js — html"]
        end
        subgraph Special["Special Targets"]
            ELEM["svelte-element.js — element"]
            HEAD["svelte-head.js — head"]
            CSSP["css-props.js — css_props"]
        end
    end

    subgraph Engine["client-reactivity-engine"]
        EFF["reactivity/effects.js<br/>block · branch · pause_effect · resume_effect · destroy_effect"]
        SRC["reactivity/sources.js<br/>source · mutable_source · internal_set"]
        DER["reactivity/deriveds.js<br/>derived_safe_equal"]
        BATCH["reactivity/batch.js<br/>Batch · current_batch · flushSync"]
        RASYNC["reactivity/async.js<br/>flatten"]
        RT["runtime.js<br/>get · active_effect · set_active_effect/reaction"]
    end

    subgraph Foundation["client-dom-renderer_dom-foundation"]
        OPS["operations.js<br/>create_text · get_first_child · get_next_sibling · remove_nodes"]
        HYD["hydration.js<br/>hydrating · hydrate_node · hydrate_next"]
        TMPL["template.js<br/>assign_nodes"]
        REC["reconciler.js<br/>create_fragment_from_html"]
    end

    subgraph Siblings["client-dom-renderer siblings"]
        ATTR["attributes-events"]
        TRANS["transitions"]
        LIFECYCLE["lifecycle (render.js)"]
    end

    CT -->|"emits calls to"| Blocks
    IF --> EFF & OPS & HYD & BATCH
    EACH --> EFF & SRC & DER & OPS & HYD & BATCH
    KEY --> EFF & BATCH
    AWAIT --> EFF & SRC & RT & HYD
    ASYNC --> RASYNC & BND
    BND --> EFF & BATCH & SRC
    SNP --> EFF & REC & TMPL
    HTML --> EFF & REC & TMPL & HYD
    ELEM --> EFF & OPS & HYD
    HEAD --> EFF & HYD & OPS
    CSSP --> EFF & HYD

    Blocks -->|"render_fn builds DOM inside"| Foundation
    Blocks -->|"intros/outros, bindings"| Siblings
    EFF --> RT
```

### 3.2 The Anchor + Effect Model

Every block follows the same skeleton:

1. **Capture the anchor.** The compiler emits an anchor (comment/text) where the block's content belongs. During hydration the anchor is replaced by `hydrate_node`.
2. **Create a reactive block.** `block(() => {...}, flags)` registers an effect that re-runs whenever the block's *input expression* (condition, array, promise, key, tag) changes. `EFFECT_TRANSPARENT` is used when children should not be intro'd/outro'd by the block itself.
3. **Render content as branches.** Content render functions run inside `branch(() => render_fn(anchor))`, producing a *branch effect* that owns the created DOM (`nodes_start`/`nodes_end`) and all child effects.
4. **Toggle by pausing/resuming.** Instead of destroying content, blocks often *pause* the old branch (letting transitions play out) and *resume* the cached branch — `commit()` in `if.js`, `update()` in `await.js`, and `update_branch()` are all variations of this pattern.
5. **Optionally defer to a batch.** When `should_defer_append()` is true, new content is built in an **offscreen `DocumentFragment`**, the batch marks the outgoing effects as `skipped_effects`, and `batch.add_callback(commit)` swaps content in a single paint.

```mermaid
stateDiagram-v2
    direction LR
    [*] --> Active: branch(fn) creates effect + DOM
    Active --> Active: effect re-runs on input change
    Active --> Paused: pause_effect → run out transitions → destroy
    Paused --> Active: resume_effect (cached branch reused)
    Active --> Destroyed: destroy_effect (immediate teardown)
    Paused --> Destroyed: outro transitions finished
    Destroyed --> [*]: DOM removed, teardown fns run
```

> The `block`/`branch`/`pause`/`resume` machinery lives in the reactivity engine — see [client-reactivity-engine](client-reactivity-engine.md) for the scheduling and dirty-checking details.

## 4. Component Reference

### 4.1 `if.js` — Conditional Blocks

`if_block(node, fn, elseif)` implements `{#if}` chains. The user-facing `fn` is invoked eagerly on every re-run and *picks* the active branch by calling the injected `set_branch(fn, flag)` callback — this callback pattern keeps the condition-checking code authored in user space while the runtime owns effect lifecycle:

- On change, `update_branch` compares old/new condition, handles **hydration mismatch** (`HYDRATION_START_ELSE` vs. truthiness → `remove_nodes()` and continue client-side), builds the new branch into an offscreen fragment if deferral is active, and schedules `commit()`.
- `commit()` resumes the active branch and pauses the inactive one (transition-aware).
- The `elseif` flag marks `{:else if}` chains as `EFFECT_TRANSPARENT`, which affects which transitions count as *local*.
- If `fn` never calls `set_branch`, the block clears itself (`update_branch(null, null)`).

### 4.2 `each.js` — List Blocks

`each(node, flags, get_collection, get_key, render_fn, fallback_fn)` is the most complex block. Key design points:

- **Normalization.** The collection is read through `derived_safe_equal` so arrays, iterables, and `null` produce a stable `V[]`; this also supports store *mutation* (same array identity) in legacy mode.
- **EachItem linked list.** Each row is an `EachItem { i, v, k, a, e, prev, next }`. `state.items` maps keys → items, and `state.first`/`prev`/`next` pointers give O(1) neighbor access. The doubly-linked list is kept in sync with both the logical order (`state.first`, `item.next`) and the effect order (`item.e.next`).
- **Reconciliation (`reconcile`).** An insertion-sort-style diff: existing keys are matched and moved minimally, unmatched keys are inserted (reusing items stashed from a previous run via `offscreen_items`), and leftovers are paused/destroyed. The `matched`/`stashed`/`seen` sets implement the "move run to front vs. back" optimization: whichever side is shorter gets moved.
- **Flags** (`EACH_ITEM_REACTIVE`, `EACH_INDEX_REACTIVE`, `EACH_ITEM_IMMUTABLE`, `EACH_IS_CONTROLLED`, `EACH_IS_ANIMATED`) decide whether `item.v`/`item.i` are reactive sources updated in place, whether the block *controls* a parent element's content (fast-path `clear_text_content`), and whether FLIP measurements are taken.
- **Deferred appends.** In batch mode, new items are created offscreen (`create_item(..., deferred=true)`), doomed items get `batch.skipped_effects.add(item.e)`, and `commit()` performs the swap — avoiding intermediate-layout flicker.
- **Hydration.** Iterates server-rendered rows, detects `HYDRATION_END` early (server rendered *fewer* rows), `remove_nodes()` on mismatch, and `set_hydrating` toggles are restored afterwards.
- **Animation support.** `current_each_item`/`set_current_each_item` let `animate:` directives bind to the row being updated (also restored around `<svelte:element>` tag changes). `item.a?.measure()/fix()/unfix()/apply()` are the FLIP hooks; queued in a microtask so all measurements happen pre-mutation.
- `index(_, i)` is the identity key/index function used when no key is specified.

### 4.3 `await.js` — Await Blocks

`await_block(node, get_input, pending_fn, then_fn, catch_fn)` is a small state machine (`PENDING=0`, `THEN=1`, `CATCH=2`):

```mermaid
flowchart TD
    A[block effect re-runs] --> B{input changed?}
    B -->|"no (input === prev)"| Z[return]
    B -->|yes| C{hydrating?}
    C -->|"mismatch: is_promise vs HYDRATION_START_ELSE"| D[remove_nodes + leave hydration mode]
    C --> E{is_promise input?}
    E -->|"yes: promise"| F["promise.then(onFulfilled, onRejected)<br/>guard: promise === input"]
    F -->|resolve| G["internal_set(input_source, value)<br/>update(THEN)"]
    F -->|reject| H["internal_set(error_source, error)<br/>update(CATCH)<br/>rethrow if no catch_fn"]
    E -->|"no: plain value"| I["internal_set(input_source, input)<br/>update(THEN, restore=false)"]
    E --> J["queue_micro_task → if !resolved<br/>update(PENDING)"]
    G & H --> K[pause other branch effects<br/>flushSync for DOM update]
    D --> M[restore hydrating=true]
```

Details worth noting:

- Resolved values are stored in **sources** (`input_source`, `error_source`) so `{@const}`/child expressions stay reactive to *re-resolved* values even if the promise identity didn't change semantics.
- `update(state, restore)` temporarily restores `active_effect`/`active_reaction`/component context (and dev stack) so branch creation happens in the correct ownership scope — critical for context API and dev ownership validation.
- Stale promises are guarded by the `promise !== input` check plus a cleanup returning `() => input = UNINITIALIZED`.
- Without `flushSync()` in the `finally`, the DOM would lag two ticks behind promise resolution.

### 4.4 `async.js` — Async Expressions

`async(node, expressions, fn)` supports async-mode expressions. It:

1. Finds the nearest boundary with a pending snippet via `get_pending_boundary()` (walks up `Boundary.parent`, erroring with `await_outside_boundary` if none).
2. Increments `boundary.update_pending_count(1)`.
3. Uses `flatten` from the reactivity async module to resolve all expressions; values are eagerly `get()`-ed (surfacing rejection *before* creating any blocks), then `fn(node, ...values)` renders; the pending count is decremented in `finally`.

### 4.5 `boundary.js` — `{#svelte:boundary}`

`boundary(node, props, children)` instantiates the `Boundary` class — the runtime's dual-purpose **error boundary** and **async/pending coordinator**. It is the hub that `async.js` (and async deriveds) coordinate with.

```mermaid
sequenceDiagram
    participant C as Child effect (main)
    participant B as Boundary
    participant P as pending snippet
    participant F as failed snippet
    participant A as async.js / async deriveds

    Note over B: constructor: block(() => …, EFFECT_TRANSPARENT|PRESERVED|BOUNDARY)
    C->>B: children run
    A->>B: update_pending_count(+1)
    alt has pending snippet & count 0→1
        B->>B: #show_pending_snippet()<br/>move main DOM into #offscreen_fragment
        B->>P: branch(() => pending(anchor))
    else no pending snippet
        B->>B: delegate count to parent boundary
    end
    A-->>B: update_pending_count(−1)
    Note over B: count === 0 → pause pending effect,<br/>re-insert offscreen fragment before anchor
    Note over C: error thrown during children
    C->>B: error(error)
    B->>B: destroy main/pending/failed effects<br/>hydration: rewind to #hydrate_open, remove_nodes
    B->>B: onerror?.(error, reset)  (active_reaction = null)
    B->>F: queue_micro_task → branch(failed(anchor, () => error, () => reset))
    B-->>B: reset() → pause failed effect, re-run children<br/>warn svelte_boundary_reset_noop / error svelte_boundary_reset_onerror
```

Key mechanisms:

- **Effect flags** `EFFECT_TRANSPARENT | EFFECT_PRESERVED | BOUNDARY_EFFECT`: the boundary survives parent teardown and is discoverable through `effect.b` (see `get_pending_boundary`).
- **Pending counting.** `update_pending_count(d)` only mutates local count if the boundary *has* a pending snippet; otherwise it delegates to `parent` — so the nearest *renderable* boundary tracks the count. `effect_pending_updates` batches the `$effect.pending()` source updates.
- **`$effect.pending()` support.** `get_effect_pending()` uses a lazy `createSubscriber`: the pending-count `source` is only created while something actually reads it (in dev it is tagged `$effect.pending()`).
- **Error handling.** `#run` swaps in the boundary's own effect/reaction/context so errors are attributed correctly; `handle_error` forwards to the compiler-visible error path and `invoke_error_boundary` escalates to the parent boundary when the fallback itself throws (`#is_creating_fallback` guard prevents infinite loops).
- **Hydration rewind.** On error during hydration, the pointer is rewound to `#hydrate_open`, and `remove_nodes()` clears the server output before rendering the fallback.
- `pending()` returns the active boundary's pending count for `$effect.pending()`; `get_pending_boundary()` throws `await_outside_boundary` when there is no boundary with a pending snippet.

### 4.6 `key.js` — Keyed Re-rendering

`key(node, get_key, render_fn)` re-creates content whenever the key expression changes (using `not_equal`/`safe_not_equal` depending on runes mode). It always *destroys-by-pause* the old content and builds a fresh branch (no caching, unlike `if`), optionally deferring the swap to a batch commit.

### 4.7 `snippet.js` — Snippets

- `snippet(node, get_snippet, ...args)` renders whichever snippet `get_snippet()` currently returns, destroying the previous snippet effect on change (`EFFECT_TRANSPARENT`). In dev, `null` snippets raise `invalid_snippet`.
- `wrap_snippet(component, fn)` (dev-only) wraps a snippet so the correct `dev_current_component_function` is active during rendering (ownership validation) and prevents stringification of the snippet function.
- `createRawSnippet(fn)` builds a snippet programmatically: `render()` HTML is parsed via `create_fragment_from_html`, the first element is inserted before the anchor (hydration-aware: reuses `hydrate_node`), `setup(element)` runs and its return value is registered as teardown. Dev mode validates that raw snippets render exactly one element.

### 4.8 `slot.js` — Slots

- `slot(anchor, $$props, name, slot_props, fallback_fn)` resolves `$$props.$$slots[name]`; supports **snippet interop** (a slot filled by `children` snippet — `slot_fn === true` maps to `$$props[name]` and passes slot props through a getter); falls back to `fallback_fn` when undefined.
- `sanitize_slots(props)` produces the boolean slot-presence map used by `$$slots` consumers (default slot from `props.children`).

### 4.9 `html.js` — `{@html}`

`html(node, get_value, svg, mathml, skip_warning)` renders raw HTML through `create_fragment_from_html` (scripts are *not* executed, matching `.innerHTML` semantics; SVG/MathML content is wrapped in `<svg>`/`<math>` for parsing then unwrapped). A `template_effect` diffs stringified values, removing the previous effect-owned DOM (`remove_effect_dom`). During hydration it scans to the sentinel empty comment, and — in dev — verifies the server-rendered hash (`check_hash`) to warn `hydration_html_changed` with source location when the markup drifted.

### 4.10 `css-props.js` — CSS Property Blocks

`css_props(element, get_styles)` creates a `render_effect` that applies each `--property: value` via `style.setProperty`/`removeProperty`. During hydration it advances `hydrate_node` to the element's first child. (Server-side counterpart lives in the server runtime: `internal/server/index.js::css_props`.)

### 4.11 `svelte-element.js` — `<svelte:element>`

`element(node, get_tag, is_svg, render_fn, get_namespace, location)` recreates the actual DOM element whenever `get_tag()` changes:

- Namespace resolution: explicit `get_namespace()`, `is_svg`, or `svg` tag → `NAMESPACE_SVG`.
- Effect choreography: same tag during outro → `resume_effect` (abort outro); `null` tag → `pause_effect` (outro); different tag → `destroy_effect` with `set_should_intro(false)` so the new element mounts without intro transitions.
- Hydration-aware child anchoring, raw-text-element guard (appends a placeholder comment to avoid hydration glitches), dev-only `__svelte_meta` location tagging, and `active_effect.nodes_end` assignment so parent ranges end at the element.
- Preserves/restores `current_each_item` so `animate:` directives rebind to the correct row across tag changes.

### 4.12 `svelte-head.js` — `<svelte:head>`

`head(render_fn)` mounts a `HEAD_EFFECT` block whose render function targets `document.head`:

- Maintains a module-level `head_anchor` so **multiple** head blocks hydrate independently (each walks to the next `HYDRATION_START` comment); if no marker is found, hydration is disabled for head and a fresh text anchor is appended.
- `reset_head_anchor()` is called by [render.js::hydrate](client-dom-renderer_lifecycle.md) to reset the cursor between hydration runs.
- Save/restore of `hydrating`/`hydrate_node` in `finally` keeps sibling blocks unaffected.

## 5. Cross-Cutting Mechanisms

### 5.1 Hydration Participation

Every block is written to work in both "mount" and "hydrate" modes. The hydration state itself (`hydrating`, `hydrate_node`, `hydrate_next()`) is owned by the DOM foundation — see [client-dom-renderer_dom-foundation](client-dom-renderer_dom-foundation.md) and entry points in [client-dom-renderer_lifecycle](client-dom-renderer_lifecycle.md). The blocks' responsibilities are:

| Concern | Handling |
| --- | --- |
| Advancing the pointer | `hydrate_next()` at block entry (if, each, await, key, snippet, slot, element, head) |
| Claiming existing nodes | `hydrate_node` replaces the anchor; `assign_nodes` bounds effect DOM ranges |
| Mismatch recovery | `remove_nodes()` + `set_hydrating(false)` → render client-side, then `set_hydrating(true)` to continue (if/each/await) |
| Server marker decoding | `read_hydration_instruction` (`HYDRATION_START_ELSE`) for else-branches and empty collections |
| Head independence | per-block `HYDRATION_START` scan in `svelte-head.js` |
| Content verification | `hash` check for `{@html}` (dev), pending/else markers for boundaries |

### 5.2 Deferred Commits (Batched DOM Swaps)

`should_defer_append()` (DOM foundation) + `current_batch.add_callback(commit)` let `if`, `each`, and `key` build new content offscreen and swap atomically at batch commit, adding outgoing effects to `batch.skipped_effects` so they don't flush mid-batch. This eliminates intermediate DOM states during synchronous multi-update batches — see [client-reactivity-engine](client-reactivity-engine.md) for batch semantics.

### 5.3 Error Propagation

Errors thrown inside block render functions bubble through the effect system; only `boundary.js` *catches* (its `#run` try/catch and `error()`). `await_block` re-throws promise rejections when no `catch_fn` exists so the nearest boundary (or global handler) sees them. Dev attribution (`dev_stack`, `dev_current_component_function`) is saved/restored around branch creation.

## 6. Interaction Flows

### 6.1 `each` Reconciliation

```mermaid
flowchart TD
    S[block effect re-runs] --> N["array = get(each_array)"]
    N --> E0{"was_empty && length === 0?"}
    E0 -->|yes| Z[skip]
    E0 -->|no| H{"hydrating?"}
    H -->|yes| H1{"marker === HYDRATION_START_ELSE<br/>vs length?"}
    H1 -->|mismatch| H2[remove_nodes, exit hydrating]
    H1 -->|ok| H3["create_item per row from hydrate_node<br/>stop at HYDRATION_END comment"]
    H2 & H3 --> C
    H -->|no| D{"should_defer_append?"}
    D -->|yes| D1["create/update offscreen_items,<br/>skip doomed effects, batch.add_callback(commit)"]
    D -->|no| C["commit → reconcile()"]
    C --> R["for each key: match / move / insert<br/>(linked-list re-link + move DOM nodes)"]
    R --> A{"EACH_IS_ANIMATED?"}
    A -->|yes| A1["measure + fix survivors,<br/>microtask → apply FLIP"]
    R --> P["pause_effects for unmatched rows<br/>(out transitions → destroy, unlink)"]
    P --> F{"fallback_fn?"}
    F -->|"length === 0"| F1[resume/branch fallback]
    F -->|"length > 0"| F2[pause fallback]
    A1 & F1 & F2 --> END[re-link each_effect.first/last]
```

### 6.2 Compiler → Block Call Sites

```mermaid
flowchart LR
    subgraph Template["Source template"]
        T1["{#if cond}…{/if}"]
        T2["{#each list as item (key)}"]
        T3["{#await p}…"]
        T4["<svelte:element this={tag}>"]
        T5["{@render children()}"]
    end
    subgraph Generated["Compiled client code"]
        G1["if_block(anchor, (set_branch) => …)"]
        G2["each(anchor, flags, get_collection, get_key, render_fn, fallback)"]
        G3["await_block(anchor, get_input, pending, then, catch)"]
        G4["element(anchor, get_tag, is_svg, render_fn)"]
        G5["snippet(anchor, get_snippet)"]
    end
    T1 --> G1
    T2 --> G2
    T3 --> G3
    T4 --> G4
    T5 --> G5
```

For how these call sites are generated (flags, tree-shaking of unused branches), see [compiler-transformer_client-transform](compiler-transformer_client-transform.md).

## 7. Dependencies

### 7.1 Inbound (who uses this module)

| Consumer | Usage |
| --- | --- |
| **Compiled component code** (`compiler-transformer_client-transform`) | Emits calls to every block exported here |
| `dom/elements/custom-element.js` (`create_slot`) | Uses slot resolution for custom-element slots |
| `render.js` (`hydrate`) | Calls `reset_head_anchor()` after hydration |
| Sibling blocks | `async.js` → `boundary.js` (`get_pending_boundary`); `svelte-element.js` ↔ `each.js` (`current_each_item`); `snippet.js` ↔ `slot.js` interop |

### 7.2 Outbound (what this module uses)

| Dependency | Provided by | Purpose |
| --- | --- | --- |
| `block`, `branch`, `pause_effect`, `resume_effect`, `destroy_effect`, `render_effect`, `template_effect`, `teardown`, `run_out_transitions`, `pause_children` | [client-reactivity-engine](client-reactivity-engine.md) (`reactivity/effects.js`) | Effect creation & lifecycle |
| `source`, `mutable_source`, `internal_set`, `derived_safe_equal` | [client-reactivity-engine](client-reactivity-engine.md) | Row/value signals, await inputs |
| `Batch`, `current_batch`, `flushSync` | [client-reactivity-engine](client-reactivity-engine.md) (`reactivity/batch.js`) | Deferred commits, synchronous flush after promise resolution |
| `get`, `active_effect`, `active_reaction`, `set_active_effect`, `set_active_reaction`, `set_component_context` | `runtime.js` / `context.js` | Ownership scope restoration during branch creation |
| `flatten` | `reactivity/async.js` | Async expression resolution |
| `hydrating`, `hydrate_node`, `hydrate_next`, `set_hydrate_node`, `set_hydrating`, `read_hydration_instruction`, `remove_nodes` | [client-dom-renderer_dom-foundation](client-dom-renderer_dom-foundation.md) (`hydration.js`) | Hydration cursor control |
| `create_text`, `get_first_child`, `get_next_sibling`, `clear_text_content`, `should_defer_append`, `set_attribute` | DOM foundation (`operations.js`) | Anchor & DOM traversal primitives |
| `create_fragment_from_html`, `assign_nodes` | DOM foundation (`reconciler.js`, `template.js`) | `{@html}` & raw snippet parsing, effect DOM range bookkeeping |
| Transitions infrastructure (`TransitionManager` via `pause_children`/`run_out_transitions`) | [client-dom-renderer_transitions](client-dom-renderer_transitions.md) | Outros when pausing branches |
| `handle_error`, `invoke_error_boundary` | `error-handling.js` | Boundary error routing |

## 8. Design Notes & Invariants

1. **Anchor invariance.** Blocks never move their own anchor; content is inserted *before* it (`anchor.before(...)`, offscreen fragment re-insertion). The anchor also carries hydration instructions as comment data.
2. **Branch caching.** `if_block` keeps both branch effects alive (paused when inactive) so toggling conditions don't rebuild DOM; `key` and snippet replacement intentionally destroy instead, because their inputs imply *new content semantics*.
3. **Stale-async guards.** `await_block` compares `promise !== input` and resets `input` to `UNINITIALIZED` in its cleanup; `async.js` eagerly reads flattened values before rendering so rejections don't create orphan blocks.
4. **Boundary delegation.** Pending counts walk up to the nearest boundary *with a pending snippet*; errors escalate to parents only when the boundary cannot handle them (no handlers, or the failure snippet itself throws).
5. **Treeshaking-conscious code.** Hydration mismatch flags and dev branches are written so they are statically removable (`let mismatch` comments, `DEV` guards from `esm-env`).
6. **No cross-module DOM mutation of other blocks' ranges** — effects own `nodes_start`/`nodes_end` and `assign_nodes`/`remove_effect_dom` are the only sanctioned way to adjust them.

## 9. Related Documentation

- [client-dom-renderer](client-dom-renderer.md) — overview of the client DOM renderer and its submodules
- [client-dom-renderer_dom-foundation](client-dom-renderer_dom-foundation.md) — anchors, templates, hydration cursor, operations
- [client-dom-renderer_lifecycle](client-dom-renderer_lifecycle.md) — `mount`/`hydrate`/`unmount` entry points
- [client-dom-renderer_attributes-events](client-dom-renderer_attributes-events.md) — attribute effects and event delegation applied within render functions
- [client-dom-renderer_bindings](client-dom-renderer_bindings.md) — two-way bindings
- [client-dom-renderer_transitions](client-dom-renderer_transitions.md) — transition/animation managers invoked during pauses
- [client-reactivity-engine](client-reactivity-engine.md) — signals, effects, batching that power the blocks
- [compiler-transformer_client-transform](compiler-transformer_client-transform.md) — how templates compile into these runtime calls
