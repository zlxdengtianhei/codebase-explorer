# Server Runtime — Slots, Snippets & Blocks

> **Module:** `server-runtime_slots-snippets-and-blocks` (child of [server-runtime](server-runtime.md) within *Server-Side Rendering & Cross-Target Runtime Services*)
> **Source files:** `packages/svelte/src/internal/server/index.js` · `packages/svelte/src/internal/server/blocks/snippet.js` · `packages/svelte/src/internal/server/blocks/html.js`

## 1. Introduction

This module implements the **content-composition primitives** of Svelte's server-side rendering (SSR) runtime. On the server a compiled component is a plain JavaScript function that writes HTML strings into a `Payload` buffer (see [server-runtime_payload-and-output](server-runtime_payload-and-output.md)). When one component renders content *into* another — via `<slot>`, content passed as children, `{#snippet}` blocks, programmatic snippets, or `{@html ...}` — the compiled code calls the primitives provided by this module:

1. **Slot dispatch** — [`slot()`](#51-slotpayload-props-name-slot_props-fallback_fn) resolves the content a parent passed for a slot (a modern *snippet function*, a legacy `$$slots` marker, or nothing) and renders either it or the `<slot>` fallback.
2. **Legacy slot introspection** — [`sanitize_slots()`](#52-sanitize_slotsprops) builds the boolean `$$slots` map that legacy (Svelte 4-style) components use to test slot availability.
3. **Programmatic snippets** — [`createRawSnippet()`](#53-createrawsnippetfn) turns a user-supplied `{ render(), setup() }` factory into a snippet function compatible with the compiled calling convention.
4. **Raw-HTML blocks** — [`html()`](#54-htmlvalue) serializes `{@html ...}` output with the comment markers required for hydration alignment.

Everything here is **synchronous, string-based and side-effect-free** with respect to the DOM: functions either *return* a string (`html`) or *push* strings into `payload.out` (`slot`, `createRawSnippet`). There is no reactivity and no scheduling — the reactive counterparts live in the [Client Runtime Engine](Client_Runtime_Engine_(Reactivity___DOM_Rendering).md).

---

## 2. Responsibilities Overview

| Export | Source file | Responsibility | Compiled-code trigger |
|---|---|---|---|
| `slot(payload, $$props, name, slot_props, fallback_fn)` | `index.js` | Dispatch slot content: render the parent-supplied snippet (modern or legacy) or the `<slot>` fallback into `payload.out` | `<slot ...>` element |
| `sanitize_slots(props)` | `index.js` | Build `Record<string, boolean>` of available slots (`default` ← `children` prop, plus every `$$slots` key) for legacy `$$.slots` checks | Legacy component bodies / `<slot>` presence tests |
| `createRawSnippet(fn)` | `blocks/snippet.js` | Wrap a `{ render(), setup? }` factory into a server snippet that appends `render().trim()` to `payload.out` | Public API `svelte/server` `createRawSnippet()` |
| `html(value)` | `blocks/html.js` | Return `<!--marker-->raw-html<!---->` for a `{@html value}` expression (marker carries a content hash in DEV) | `{@html expr}` tag |

Supporting members re-exported through `index.js` that collaborate closely with this module (documented with their owners): `validate_snippet_args` and `prevent_snippet_stringification` (`server-runtime_dev-diagnostics` / `internal-shared-utils`), `invalid_default_snippet` (`internal-shared-utils`), and the sibling attribute helpers of [server-runtime_attributes-and-props](server-runtime_attributes-and-props.md).

---

## 3. Position in the Overall System

```mermaid
flowchart TB
    subgraph COMPILER["Compiler Pipeline — server transform<br/>(see compiler-transformer_server-transform)"]
        SE["SlotElement visitor"]
        SB["SnippetBlock visitor"]
        HT["HtmlTag visitor"]
        CV["Component visitor<br/>(packs snippets as props)"]
    end

    subgraph MODULE["server-runtime_slots-snippets-and-blocks"]
        SLOT["slot()"]
        SS["sanitize_slots()"]
        CRS["createRawSnippet()"]
        HTMLB["html()"]
    end

    subgraph SIB["server-runtime siblings"]
        PAY["Payload / HeadPayload<br/>payload.out buffer"]
        PIPE["render() pipeline"]
        DEVD["dev.js<br/>validate_snippet_args"]
    end

    subgraph SHARED["internal-shared-utils"]
        PSS["prevent_snippet_stringification"]
        INV["invalid_default_snippet"]
    end

    subgraph CLIENT["Client Runtime Engine<br/>(hydration counterpart)"]
        CSNIP["dom/blocks/snippet.js<br/>snippet / wrap_snippet / createRawSnippet"]
        CHTML["dom/blocks/html.js<br/>hydration hash check"]
    end

    SE -->|"$.slot($$payload, $$props, …)"| SLOT
    CV -->|"children / named snippet props<br/>+ $$slots markers"| SLOT & SS
    SB -->|"snippet fn + dev guards"| DEVD & PSS
    HT -->|"$.html(expr)"| HTMLB
    SLOT -->|"slot_fn(payload, props)"| PAY
    CRS -->|"push render().trim()"| PAY
    SLOT -->|"runs within render()"| PIPE
    HTMLB -->|"marker string"| PAY
    HTMLB -.->|"markers matched during hydration"| CHTML
    CRS -.->|"same snippet contract"| CSNIP
    INV -.->|"thrown by compiled<br/>{@render children}"| SLOT
```

**Key relationships:**

| Partner | Relationship |
|---|---|
| [server-runtime_render-pipeline](server-runtime_render-pipeline.md) | `render()` / `element()` / `head()` execute the component function that calls `slot()`; other control-flow blocks (`if`, `each`, `await_block`, …) belong to the render pipeline, not this module. |
| [server-runtime_payload-and-output](server-runtime_payload-and-output.md) | All HTML produced here lands in `Payload.out` (or `payload.head.out` for `<svelte:head>` slots); `slot()` accepts either payload shape. |
| [compiler-transformer_server-transform](compiler-transformer_server-transform.md) / [compiler-transformer_server-rendering](compiler-transformer_server-rendering.md) | The compiler is the *only* intended caller of `slot()`/`html()`; it emits the exact call shapes described below. |
| [client-dom-renderer_control-flow-blocks](client-dom-renderer_control-flow-blocks.md) | Client twin of every primitive: `snippet`/`wrap_snippet`/`createRawSnippet` insert DOM nodes, and the client `html` block verifies the DEV hash marker during hydration. |
| `server-runtime_dev-diagnostics` · `internal-shared-utils` | Dev-mode guards (`validate_snippet_args`, `prevent_snippet_stringification`) and the `invalid_default_snippet` error attach to snippet calls generated by the compiler. |

---

## 4. Architecture

### 4.1 File map

| File | Contents | Notes |
|---|---|---|
| `internal/server/index.js` | `slot`, `sanitize_slots` (plus the rest of the runtime facade, which re-exports `html`, `validate_snippet_args`, `prevent_snippet_stringification`, `invalid_default_snippet`, …) | Single import surface for compiled code: everything is namespaced as `$.` in generated output. |
| `internal/server/blocks/snippet.js` | `createRawSnippet(fn)` | Server half of the programmatic-snippet API; the client half lives in `internal/client/dom/blocks/snippet.js`. |
| `internal/server/blocks/html.js` | `html(value)` | Tiny pure function; DEV behaviour depends on `esm-env` `DEV` flag and `hash()` from `utils.js`. |

### 4.2 Internal dependency view

```mermaid
flowchart LR
    subgraph MODULE["slots-snippets-and-blocks"]
        SLOT["slot()"]
        SS["sanitize_slots()"]
        CRS["createRawSnippet()"]
        HTMLB["html()"]
    end

    subgraph DEPS["Direct dependencies"]
        P["Payload.out<br/>(string buffer)"]
        CTX["context.js<br/>current_component"]
        HASH["utils.js<br/>hash()"]
        ESMENV["esm-env<br/>DEV flag"]
        NOOP["shared/utils.js"]
    end

    subgraph GUARDS["Dev guards (attached by compiler)"]
        VSA["validate_snippet_args()"]
        PSST["prevent_snippet_stringification()"]
        IDS["invalid_default_snippet()"]
    end

    SLOT -->|"append HTML"| P
    SLOT -->|"slot_fn closes over<br/>component context"| CTX
    SLOT -.->|"guard: {@render children}<br/>with legacy let: parent"| IDS
    CRS -->|"append render().trim()"| P
    HTMLB -->|"hash content in DEV"| HASH
    HTMLB -->|"pick marker"| ESMENV
    SS -->|"reads children / $$slots"| P
    SLOT & CRS -.->|"payload validated in DEV"| VSA
    CRS -.->|"fn.toString poisoned by compiler"| PSST
    NOOP -.->|"default fallback thunks"| SLOT
```

---

## 5. Component Reference

### 5.1 `slot(payload, $$props, name, slot_props, fallback_fn)`

The single dispatch point for every `<slot>` occurrence in a component rendered on the server.

**Parameters**

| Param | Type | Meaning |
|---|---|---|
| `payload` | `Payload` \| `HeadPayload` | Output buffer receiving the rendered slot content. |
| `$$props` | `Record<string, unknown>` | Props of the component **containing** the `<slot>`; must expose `$$slots` and/or snippet props. |
| `name` | `string` | Slot name — `'default'` or a named slot from `<slot name="…">`. |
| `slot_props` | `Record<string, unknown>` | Slot parameters (from `<slot {param}>` / `<slot {...spread}>`), forwarded to the snippet. |
| `fallback_fn` | `null \| (() => void)` | Thunk rendering the `<slot>` fallback fragment; `null` when the slot is empty. |

**Algorithm**

1. Look up `slot_fn = $$props.$$slots?.[name]`.
2. **Legacy interop:** if `slot_fn === true`, the parent is a legacy-style component that passed a *presence marker*; resolve the real function from the props bag — `$$props['children']` when `name === 'default'`, otherwise `$$props[name]`. This is what lets a modern component fill the slots of a Svelte-4-flavoured component (and vice-versa) with snippets.
3. If a function was resolved, invoke `slot_fn(payload, slot_props)` — snippet functions have the exact signature `($$payload, ...params)`, so this directly appends the parent's content to the buffer.
4. Otherwise invoke `fallback_fn?.()` to render the fallback fragment (a no-op when the `<slot>` has no fallback).

**Error contract:** `slot()` itself does not throw. The compiler wraps the *default-content* render (`{@render children(...)}`) with a check that throws [`invalid_default_snippet`](internal-shared-utils) when a parent supplied content via legacy `let:` directives — those cannot be converted into a `children` snippet.

**Caller (compiler contract):** the `SlotElement` visitor emits, wrapped in `<!---->` hydration markers:

```js
$.slot($$payload, $$props, 'header', { /* slot props or $.spread_props([...]) */ }, fallback === null ? null : () => { /* fallback fragment */ });
```

### 5.2 `sanitize_slots(props)`

Builds the **slot-availability map** used by legacy-compiled components, which test slot presence with expressions like `{#if $$slots.header}`.

- Starts from the modern default channel: `props.children` truthy ⇒ `sanitized.default = true`.
- Copies every key of `props.$$slots` as `true`.

The result is a plain `Record<string, boolean>` — no functions — so it can be safely spread into child props as `$$slots` while `slot()` treats each entry as a *marker* (see the interop branch above). In the common case the compiler folds this to a constant object; the runtime helper remains for dynamic prop bags.

### 5.3 `createRawSnippet(fn)`

Creates a snippet **programmatically** (public API, re-exported by `svelte/server`). This is the SSR counterpart of the client implementation documented in [client-dom-renderer_control-flow-blocks](client-dom-renderer_control-flow-blocks.md); both produce values that satisfy the same snippet calling convention `($$payload | anchor, ...params)`.

```js
const snippet = createRawSnippet((name) => ({
  render: () => `<b>Hello ${name()}</b>`,
  setup: (element) => { /* client-only side effects */ },
}));
```

**Server-side behaviour** (`blocks/snippet.js`):

1. The returned function receives `(payload, ...args)`.
2. Each argument is captured as a **getter** — `args.map((value) => () => value)` — so the user factory receives lazy `() => value` accessors, mirroring the client API where values must be re-read on updates. On the server, values are final at call time, so getters simply return the captured value.
3. `fn(...getters)` must return `{ render: () => string, setup?: (element) => void | (() => void) }`.
4. `render()` is called once, the result **trimmed** and pushed into `payload.out`. The rendered string should contain exactly one root element — the client runtime warns (`invalid_raw_snippet_render`) if hydration finds more, so treat "single root element" as the contract.
5. `setup()` is **ignored on the server** (no element exists); on the client it runs after DOM insertion and its return value is registered for teardown.

**Dev-mode hardening (applied by the compiler to normal `{#snippet}` functions, and relevant to any snippet-like function):** compiled snippet bodies start with `$.validate_snippet_args($$payload)`, which throws `invalid_snippet_arguments` when the first argument is not a `Payload`/`HeadPayload` (e.g. a snippet invoked outside a render), and `$.prevent_snippet_stringification(fn)` replaces `fn.toString` so that interpolating a snippet (`{mySnippet}` instead of `{@render mySnippet()}`) throws `snippet_without_render_tag` instead of leaking source code.

### 5.4 `html(value)`

Implements `{@html value}` for SSR. Pure function — the compiled `HtmlTag` visitor pushes its return value into the payload:

```js
$.html(some_expression); // template.push(b.call('$.html', expression))
```

**String construction:**

1. `value` is coerced with `String(value ?? '')` — `null`/`undefined` render as the empty string; everything else is stringified **without escaping** (unescaped output is the entire purpose of `{@html}`; content safety is the developer's responsibility).
2. An opening marker is chosen:
   - **Production:** `<!---->` — a plain comment boundary.
   - **Development:** `<!--{hash}-->` where `hash` is the DJB2-style hash (base-36, `\r` stripped) of the exact HTML string.
3. The raw HTML follows, and a closing `<!---->` always terminates the block.

**Why the markers matter:** the client runtime locates and (in DEV) verifies the raw-HTML boundary during hydration — the client `html` block checks that the hydrated comment's hash matches the freshly rendered string, catching mismatches early. This is the SSR side of the hydration handshake described in [client-dom-renderer_dom-foundation](client-dom-renderer_dom-foundation.md) and [client-dom-renderer_control-flow-blocks](client-dom-renderer_control-flow-blocks.md).

---

## 6. Data Flows & Process Flows

### 6.1 Slot dispatch (modern snippets + legacy interop + fallback)

```mermaid
sequenceDiagram
    autonumber
    participant CC as Compiled child component
    participant S as slot()
    participant PR as $$props ($$slots + snippet props)
    participant SN as Parent snippet fn
    participant P as Payload.out

    CC->>S: slot(payload, $$props, 'header', slotProps, fallbackThunk)
    S->>PR: read $$slots['header']
    alt slot_fn === true (legacy interop marker)
        S->>PR: resolve $$props['header'] (or 'children' for default)
    end
    alt slot_fn defined
        S->>SN: slot_fn(payload, slotProps)
        SN->>P: push parent content HTML
    else no slot provided
        S->>P: fallbackThunk() → fallback fragment HTML
    end
    Note over P,CC: content is framed by <!----> markers<br/>emitted by the SlotElement visitor
    CC->>P: continues rendering siblings
```

Modern parents pass snippets directly (`children` for default content, named snippets as props) together with `$$slots: { default: true, … }` markers so that legacy descendants can introspect them; legacy parents pass only the markers plus plain functions, which branch 2 of the algorithm resolves. `sanitize_slots()` is what produces those marker maps when legacy code computes `$$slots` dynamically.

### 6.2 Programmatic raw snippet (`createRawSnippet`)

```mermaid
sequenceDiagram
    autonumber
    participant U as User code
    participant CRS as createRawSnippet(fn)
    participant CC as Compiled component
    participant P as Payload.out

    U->>CRS: createRawSnippet((a, b) => ({ render, setup }))
    CRS-->>U: snippet(payload, ...params)
    CC->>CRS: snippet($$payload, valueA, valueB)
    CRS->>CRS: wrap args as getters (() => value)
    CRS->>U: fn(getterA, getterB)
    U-->>CRS: { render: () => string, setup? }
    CRS->>P: push render().trim()
    Note over P: setup() is skipped on the server —<br/>the client twin runs it after DOM insertion
```

### 6.3 `{@html}` block emission

```mermaid
flowchart LR
    A["Template: {@html value}"] -->|"HtmlTag visitor"| B["$.html(value)"]
    B --> C["String(value ?? '')"]
    C --> D{"DEV build?"}
    D -->|"yes"| E["open = &lt;!--hash--&gt;<br/>(djb2 → base36 of html)"]
    D -->|"no"| F["open = &lt;!----&gt;"]
    E --> G["open + raw html + &lt;!----&gt;"]
    F --> G
    G -->|"return value"| H["pushed to Payload.out<br/>by compiled caller"]
    H -.->|"hydration"| I["client html block<br/>validates DEV hash marker"]
```

---

## 7. Compilation Contract Summary

The compiler (see [compiler-transformer_server-transform](compiler-transformer_server-transform.md)) is the primary consumer; it emits this exact runtime surface:

| Template syntax | Transform visitor | Emitted runtime interaction |
|---|---|---|
| `<slot name="x" {p} {…spread}>fallback</slot>` | `SlotElement` | `$.slot($$payload, $$props, 'x', propsObject, fallbackThunk)` wrapped in `<!---->` |
| Content inside `<Comp>…</Comp>` | `SnippetBlock` + `Component` | Implicit `{#snippet children()}` compiled to a fn passed as the `children` prop (+ `$$slots` markers) |
| `{#snippet name(p)}…{/snippet}` | `SnippetBlock` | Function declaration `($$payload, p) => {…}`; in DEV: leading `$.validate_snippet_args` + `$.prevent_snippet_stringification` |
| `{@render children(…)}` with legacy-`let:` parent | `RenderTag` | Guard that throws `$.invalid_default_snippet()` |
| `{@html expr}` | `HtmlTag` | `$.html(expr)` |
| `{#if $$slots.x}` (legacy bodies) | legacy slot checks | Map produced by `$.sanitize_slots($$props)` |
| `createRawSnippet()` (user API) | — | Returned function used anywhere a snippet prop is expected |

---

## 8. Related Documentation

- Parent module overview: [server-runtime](server-runtime.md)
- Execution context around these primitives: [server-runtime_render-pipeline](server-runtime_render-pipeline.md)
- Output buffering consumed by this module: [server-runtime_payload-and-output](server-runtime_payload-and-output.md)
- Adjacent prop plumbing (`sanitize_props`, `spread_props`, …): [server-runtime_attributes-and-props](server-runtime_attributes-and-props.md)
- Compiler side (slot/snippet/html code generation): [compiler-transformer_server-transform](compiler-transformer_server-transform.md) · [compiler-transformer_server-rendering](compiler-transformer_server-rendering.md)
- Client counterparts (hydration & DOM insertion): [client-dom-renderer_control-flow-blocks](client-dom-renderer_control-flow-blocks.md) · [client-dom-renderer_dom-foundation](client-dom-renderer_dom-foundation.md)
- Whole-system views: [Compiler_Pipeline___Language_Toolchain](Compiler_Pipeline___Language_Toolchain.md) · [Client_Runtime_Engine_(Reactivity___DOM_Rendering)](Client_Runtime_Engine_(Reactivity___DOM_Rendering).md)
