# Client Transform (`compiler-transformer_client-transform`)

## Overview

The **client transform** is the browser-target half of the Svelte compiler's third phase (*transformation*). It consumes the **analyzed AST** produced by the [compiler-analyzer](compiler-analyzer.md) (nodes annotated with scopes, bindings and expression metadata) and emits a plain **ESTree JavaScript program** that — when executed together with `svelte/internal/client` (the *Client Runtime Engine*) — creates real DOM from hoisted HTML templates and wires up Svelte's fine-grained reactivity.

In concrete terms, it turns this:

```svelte
<script>
        let count = $state(0);
</script>

<button onclick={() => count++}>
        {count}
</button>
```

into runtime code of this shape:

```js
import * as $ from 'svelte/internal/client';

// hoisted static template (module scope)
const root = $.template(`<button> </button>`);

export default function App($$anchor, $$props) {
        $.push($$props, true);

        // instance body — reactive state
        let count = $.state(0);

        // template body
        const button = root();
        let button_1;
        // ... event handler wiring ...
        {
                let count_1 = $.derived(() => $.get(count));
                $.template_effect(() => $.set_text(button_1, $.get(count_1)));
        }
        $.append($$anchor, button);

        $.pop();
}
```

The module lives at `packages/svelte/src/compiler/phases/3-transform/client/` and is one of three sibling transforms inside the [compiler-transformer](compiler-transformer.md) module — the others being the [server transform](compiler-transformer_server-transform.md) (SSR output) and the [CSS transform](compiler-transformer_css-transform.md).

## Role in the Compiler Pipeline

```mermaid
flowchart TB
    subgraph Phase1["Phase 1 — Parse"]
        P["Svelte source → AST<br/>(compiler-parser)"]
    end

    subgraph Phase2["Phase 2 — Analyze"]
        A["Scopes, bindings,<br/>expression metadata<br/>(compiler-analyzer)"]
    end

    subgraph Phase3["Phase 3 — Transform (3 targets)"]
        direction LR
        CT["client_transform<br/>⚡ this module"]
        ST["server_transform<br/>(SSR strings)"]
        CS["css_transform<br/>(scoped CSS)"]
    end

    subgraph Runtime["Execution targets"]
        CR["Client Runtime Engine<br/>svelte/internal/client"]
        SR["Server Runtime<br/>svelte/internal/server"]
    end

    Source["`.svelte` file"] --> P --> A
    A -->|"`generate: 'client'`"| CT
    A -->|"`generate: 'server'`"| ST
    CT -->|"emits calls into"| CR
    ST -->|"emits calls into"| SR
    CT -.->|"`$.append_styles` when<br/>`css: 'injected'`"| CS
```

`client_component(analysis, options)` (in `transform-client.js`) is invoked from the top-level `compile()` entry point of [compiler-core](compiler-core.md) whenever client code is requested. It returns the ESTree `Program` that is later printed to JS by the code generator (esrap).

## Architecture

### Entry point: `client_component()`

`transform-client.js` exports `client_component(analysis, options)`, which:

1. Builds the root **`ComponentClientTransformState`** (see below), seeded with an import of `svelte/internal/client` into the `hoisted` bucket.
2. Walks **three separate ASTs** with the *same* visitor map, using `zimmerframe`'s `walk`:
   - the **module script** AST (`<script module>` context),
   - the **instance script** AST (`<script>` context, `is_instance: true`),
   - the **template** AST (sharing the instance scope so template code can read instance bindings).
3. Assembles the final program: hoisted statements (templates, CSS, module snippets), legacy `$:` reactive statements, store setup/teardown, exported accessors / `$$sanitized_props`, `$.push` / `$.pop` component context, and the template body.

```mermaid
flowchart TB
    subgraph Entry["client_component()"]
        W1["walk(module.ast)"] --> W2["walk(instance.ast)"] --> W3["walk(template.ast)"]
    end

    subgraph VisitorsMap["Shared visitor map (transform-client.js)"]
        SS["`_` set_scope visitor<br/>(scope switching +<br/>transform-map pruning)"]
        V["~60 node-type visitors"]
    end

    W1 & W2 & W3 --> VisitorsMap

    subgraph Output["Generated ESTree Program"]
        H["hoisted:<br/>$.template / $.from_html(...),<br/>imports, module snippets"]
        B["component function body:<br/>$.push → stores → instance stmts<br/>→ render/init/after_update → $.pop"]
    end

    VisitorsMap --> Output
```

### The core state: `ComponentClientTransformState`

Defined in `types.d.ts`, this is the blackboard every visitor reads from and writes to:

| Field | Purpose |
| --- | --- |
| `transform` | **The heart of the transform.** Per-binding rewriters `{ read, assign?, mutate?, update? }` that convert plain identifiers/assignments into runtime calls — e.g. `count` → `$.get(count)`, `count = x` → `$.set(count, x)`. Populated by block visitors (each items, snippets, `{@const}`, legacy `$:`), pruned by the `set_scope` visitor for non-reactive bindings. |
| `init` | Statements that run once, before any render effect (element creation, block setup). |
| `update` | Statements that belong *inside* the render effect (`$.template_effect(...)`), i.e. DOM updates that depend on reactive state. |
| `after_update` | Statements that must run after the render effect: bindings, actions, transitions, events on elements with `use:`. |
| `consts` | Transformed `{@const}` declarations (`$.derived(...)`). |
| `hoisted` | Module-level statements: the static templates and the runtime import. |
| `template` | The [`Template`](#template-emission) accumulator collecting the current fragment's static HTML. |
| `memoizer` | A [`Memoizer`](#expression-memoization) that de-duplicates shared sub-expressions. |
| `node` | Identifier of the current **anchor** node — every block/element visitor inserts relative to it. |
| `metadata` | Current namespace (`html`/`svg`/`mathml`) and `bound_contenteditable` flag. |
| `analysis`, `scope(s)`, `options` | From the analyzer / compiler options (runes mode, dev mode, namespaces...). |
| `legacy_reactive_statements`, `instance_level_snippets`, `module_level_snippets`, `events` | Assembly buckets for legacy `$:` labels and hoisted snippets. |

### Template emission

Static markup is *not* generated statement-by-statement. Instead, while visitors descend the template tree, every static element/text/comment is recorded into a `Template` instance (`transform-template/template.js`). When a [`Fragment`](#structural-visitors) is closed, `transform_template()` (`transform-template/index.js`) converts the accumulated tree into a single hoisted runtime call:

- `as_html()` → `$.from_html('<button> </button>')` — an HTML string compiled into a `<template>` element (used by default, per `options.fragments`),
- `as_tree()` → `$.from_tree(['button', {...}, ' '])` — a compact nested-array description built by `objectify()` / `stringify()`,
- plus flags such as `TEMPLATE_FRAGMENT` (multi-root), `TEMPLATE_USE_IMPORT_NODE` (custom elements / `<video>` / `<script>`), `TEMPLATE_USE_SVG`, `TEMPLATE_USE_MATHML`, wrapped in `$.with_script(...)` when a `<script>` tag is embedded, and annotated with source locations in dev mode.

### Statement buckets & the render effect

Every visitor pushes generated statements into one of the buckets above. `Fragment` (and `RegularElement` for children) finally composes them in a fixed order:

```mermaid
flowchart LR
    A["consts<br/>{@const} deriveds"] --> B["init<br/>creation + block setup"]
    B --> C["update bucket"]
    C -->|"if non-empty"| D["`$.template_effect(() => {...})`<br/>render effect (build_render_statement)"]
    D --> E["after_update<br/>bindings · actions · transitions"]
    E --> F["close: `$.append($$anchor, node)`"]
```

`build_render_statement()` (`visitors/shared/utils.js`) merges the `update` bucket with the `Memoizer`'s captured values into a single `$.template_effect` call, so an arbitrary number of reactive updates collapse into one effect per scope.

### Expression memoization

The `Memoizer` (`visitors/shared/utils.js`) assigns stable identifiers (`$0`, `$1`, ...) to expressions that are evaluated more than once or shared between an element's template and its render effect (`has_call` / `has_await` metadata from the analyzer decides). Async-memoized values are passed through `$.async` blocks (experimental async support), and synchronous ones become `$.derived`s when needed.

### Dev-mode & async concerns

Cross-cutting behavior applied throughout the visitors:

- **Ownership validation** — hoisted event handlers receive a `$$ownership_validator` param (`get_hoisted_params` in `utils.js`); mutations are checked with `validate_mutation`.
- **`validate_snippet_args`**, `$.tag` debug labels, `$.add_locations`, `console.log` state introspection, reactivity-loss tracking for `await` (`AwaitExpression`).
- **Experimental async** — nodes whose expression metadata carries `has_await` are wrapped in `$.async(anchor, values, cb)` and values are unwrapped via `$.get` / `$.save` (`create_derived(..., async)`).

## Sub-modules

The module is organized into four sub-modules:

| Sub-module | Contents | Documentation |
| --- | --- | --- |
| **Transform Infrastructure & Template Emission** | `utils.js` (binding rewriters, hoisted params, prop sources, proxying, derived creation), `transform-template/template.js` (`Template`, `stringify`, `objectify`), `visitors/shared/function.js` (`visit_function`) | [compiler-transformer_client-transform_infrastructure.md](compiler-transformer_client-transform_infrastructure.md) |
| **Structural Visitors** (template blocks & elements) | `Fragment`, `RegularElement`, `Component`, `SnippetBlock`, `EachBlock`, `IfBlock`, `AwaitBlock`, `KeyBlock`, `HtmlTag`, `RenderTag`, `SlotElement`, `SvelteElement`, `SvelteBoundary` | [compiler-transformer_client-transform_structural-visitors.md](compiler-transformer_client-transform_structural-visitors.md) |
| **Expression & Reactivity Visitors** (script logic) | `Identifier`, `AssignmentExpression`, `CallExpression`, `AwaitExpression`, `ConstTag`, `ClassBody`, `LabeledStatement` | [compiler-transformer_client-transform_expression-visitors.md](compiler-transformer_client-transform_expression-visitors.md) |
| **Directive Visitors** | `BindDirective`, `OnDirective`, `TransitionDirective`, `UseDirective`, `LetDirective`, `DebugTag` | [compiler-transformer_client-transform_directive-visitors.md](compiler-transformer_client-transform_directive-visitors.md) |

```mermaid
flowchart TB
    TC["transform-client.js<br/>client_component() + visitors map"]

    subgraph INFRA["Infrastructure"]
        U["utils.js<br/>build_getter · build_hoisted_params<br/>get_prop_source · is_prop_source<br/>should_proxy · create_derived"]
        T["transform-template/template.js<br/>Template · stringify · objectify"]
        F["shared/function.js<br/>visit_function"]
    end

    subgraph SV["Structural visitors"]
        FR["Fragment"] --- RE["RegularElement"] --- CO["Component"] --- SN["SnippetBlock"]
        EA["EachBlock"] --- IF["IfBlock"] --- AW["AwaitBlock"] --- KE["KeyBlock"]
        HT["HtmlTag"] --- RT["RenderTag"] --- SL["SlotElement"]
        SE["SvelteElement"] --- SB["SvelteBoundary"]
    end

    subgraph EV["Expression visitors"]
        ID["Identifier"] --- AE["AssignmentExpression"] --- CE["CallExpression"]
        AWE["AwaitExpression"] --- CT2["ConstTag"] --- CB["ClassBody"] --- LS["LabeledStatement"]
    end

    subgraph DV["Directive visitors"]
        BD["BindDirective"] --- OD["OnDirective"] --- TD["TransitionDirective"]
        UD["UseDirective"] --- LD["LetDirective"] --- DT["DebugTag"]
    end

    TC --> INFRA & SV & EV & DV
    SV & EV & DV -->|"helpers"| INFRA
    SV -->|"child traversal"| SHARED["visitors/shared/*<br/>process_children · build_render_statement<br/>Memoizer · build_expression · get_value<br/>events · element · component helpers"]
```

## Output Contract: the `$.` runtime API

Every expression emitted by this module is a call into `svelte/internal/client`. The mapping is maintained by hand across visitors; the main categories:

| Category | Runtime functions referenced by visitors |
| --- | --- |
| Templates | `$.template` / `$.from_html` / `$.from_svg` / `$.from_mathml` / `$.from_tree`, `$.comment`, `$.text`, `$.with_script` |
| DOM traversal | `$.child`, `$.first_child`, `$.sibling`, `$.next`, `$.append`, `$.reset`, `$.hydrate_template` |
| Reactivity | `$.state`, `$.derived`, `$.derived_safe_equal`, `$.get`, `$.set`, `$.assign*`, `$.proxy`, `$.snapshot` |
| Effects | `$.template_effect`, `$.effect`, `$.effect_root`, `$.render_effect`, `$.legacy_pre_effect*` |
| Blocks | `$.if`, `$.each`, `$.key`, `$.await`, `$.snippet`, `$.slot`, `$.html`, `$.element`, `$.boundary`, `$.async` / `$.async_body` / `$.aborted` / `$.save` |
| Attributes | `$.set_attribute`, `$.set_class`, `$.set_style`, `$.attr`, `$.spread_attributes`, `$.set_value` / `$.set_checked` / `$.set_selected` ... |
| Bindings | `$.bind_value`, `$.bind_group`, `$.bind_this`, `$.bind_window_scroll`, `$.bind_element_size`, ... (one per bind target) |
| Events / Extras | `$.event`, `$.on`, modifiers (`$.stopPropagation`, `$.preventDefault`, ...), `$.action`, `$.transition`, `$.prop`, `$.rest_props`, `$.spread_props` |
| Component lifecycle | `$.push`, `$.pop`, `$.setup_stores`, `$.store_get`, `$.invalidate*`, `$.append_styles` |
| Dev-only | `$.tag`, `$.validate_snippet_args`, `$.validate_each_keys`, `$.add_locations`, `$.ownership_validator`, `$.log_if_contains_state`, `$.track_reactivity_loss` |

The implementation of these functions belongs to the **Client Runtime Engine** module (`packages/svelte/src/internal/client/…`): reactivity primitives live in `runtime.js` / `reactivity/*`, block implementations in `dom/blocks/*`, and attribute/event helpers in `dom/elements/*`. Consult that module's documentation for runtime semantics — this module only *emits calls* into it.

## Dependency Map

```mermaid
flowchart LR
    subgraph Upstream["Upstream (inputs)"]
        CP["compiler-parser<br/>AST nodes"]
        CA["compiler-analyzer<br/>Scopes · Bindings ·<br/>expression metadata"]
        CC["compiler-core<br/>AST types · builders `b`<br/>constants · errors/warnings"]
    end

    subgraph ThisModule["compiler-transformer_client-transform"]
        direction TB
        ENTRY["client_component()"]
        VIS["visitors/*"]
        INFRA["utils.js · template.js"]
    end

    subgraph Siblings["Sibling transforms"]
        SSTR["server transform"]
        CSTR["css transform<br/>render_stylesheet()"]
    end

    subgraph Downstream["Downstream (outputs)"]
        GEN["Code generator (esrap)"]
        RTM["svelte/internal/client<br/>Client Runtime Engine"]
    end

    CP --> ENTRY
    CA -->|"ComponentAnalysis + scopes"| ENTRY
    CC -->|"builders & types"| INFRA
    ENTRY --> VIS
    INFRA --> VIS
    VIS -->|"ESTree Program"| GEN
    VIS -->|"$. / $$ runtime calls"| RTM
    ENTRY -.->|"css: 'injected'"| CSTR
    SREN["server runtime"]:::hidden
    classDef hidden display:none;
```

## Key Invariants

1. **Static-first templates** — anything that cannot change is baked into the hoisted template string/tree; only reactive leaves get render-effect updates. This is what keeps output size and hydration cost low.
2. **One render effect per scope** — all `update` statements in a fragment are merged into a single `$.template_effect` (via `build_render_statement` + `Memoizer`).
3. **Anchor-relative insertion** — every block/element receives its anchor via `state.node` (`$$anchor`) and appends itself with `$.append`, `$.child`, `$.sibling` — no DOM queries are emitted.
4. **Reads vs. mutations are mode-aware** — the `transform` map decides whether an identifier read becomes `$.get(x)`, a raw identifier, or `$$props.foo`; runes mode is fine-grained, legacy mode uses `derived_safe_equal` / `invalidate_inner_signals` to emulate coarse-grained reactivity.
5. **Ordering matters** — `init` → render effect → `after_update` → `close` (`$.append`) must stay in that order; e.g. `bind:` directives deliberately land in `after_update` so they observe fully-populated attributes, and `bind:this` goes to `init`.

## Related Documentation

### Sub-module documentation (this module)

- [compiler-transformer_client-transform_infrastructure.md](compiler-transformer_client-transform_infrastructure.md) — transform infrastructure: binding rewriters (`build_getter`, `get_prop_source`, `should_proxy`, `create_derived`, hoisted params), the `Template` accumulator (`stringify` / `objectify` → `$.from_html` / `$.from_tree`), and `visit_function` (hoisted function params)
- [compiler-transformer_client-transform_structural-visitors.md](compiler-transformer_client-transform_structural-visitors.md) — template block & element visitors: `Fragment` (template creation + statement-bucket assembly), `RegularElement` (attributes/bindings/special value handling), `Component`, `SnippetBlock`, `EachBlock`, `IfBlock`, `AwaitBlock`, `KeyBlock`, `HtmlTag`, `RenderTag`, `SlotElement`, `SvelteElement`, `SvelteBoundary`
- [compiler-transformer_client-transform_expression-visitors.md](compiler-transformer_client-transform_expression-visitors.md) — script reactivity visitors: `Identifier` (getter rewriting), `AssignmentExpression` (assign/mutate/`$.set`), `CallExpression` (rune lowering), `AwaitExpression`, `ConstTag`, `ClassBody` (`$state`/`$derived` fields), `LabeledStatement` (legacy `$:`)
- [compiler-transformer_client-transform_directive-visitors.md](compiler-transformer_client-transform_directive-visitors.md) — directive visitors: `BindDirective`, `OnDirective`, `TransitionDirective`, `UseDirective`, `LetDirective`, `DebugTag`

### Sibling & upstream modules

- [compiler-transformer](compiler-transformer.md) — parent module: shared transform types (`TransformState`), shared utils, CSS/server transforms
- [compiler-transformer_server-transform](compiler-transformer_server-transform.md) — the SSR counterpart; shares assignment handling concepts (`visit_assignment_expression`) but emits string-building code
- [compiler-analyzer](compiler-analyzer.md) — produces the `analysis`, scopes, bindings and `metadata.expression` (`has_state`, `has_call`, `has_await`) fields this module relies on
- [compiler-core](compiler-core.md) — public `compile()` entry, AST/builder utilities (`#compiler/builders`), diagnostic infrastructure
- **Client Runtime Engine** (`packages/svelte/src/internal/client/`) — the execution target of all emitted code; reactivity primitives in `runtime.js`/`reactivity/*`, block implementations in `dom/blocks/*`, attribute/event/bind helpers in `dom/elements/*`
