# compiler-preprocessor_api

> **Module location:** `packages/svelte/src/compiler/preprocess/public.d.ts`
> **Parent module:** [compiler-preprocessor](compiler-preprocessor.md) · **Sibling module:** [compiler-preprocessor_engine](compiler-preprocessor_engine.md)

## Introduction

`compiler-preprocessor_api` defines the **public type contract** of the Svelte preprocessor system. It is a pure declaration module (`.d.ts`) containing **no runtime code** — instead, it establishes the interface through which external code transformation tools (TypeScript, Sass, PostCSS, Markdown-based components, etc.) hook into the Svelte build pipeline.

Everything a preprocessor author and the preprocessor engine exchange flows through the shapes declared here:

| Export | Kind | Purpose |
| --- | --- | --- |
| `Processed` | `interface` | The result object a preprocessor must return to describe its transformation |
| `MarkupPreprocessor` | `function type` | Hook that receives the **whole file** and returns a transformed version |
| `Preprocessor` | `function type` | Hook that receives a single **`<script>` / `<style>` tag body** and returns a transformed version |
| `PreprocessorGroup` | `interface` | A named bundle (`name` + `markup` / `script` / `style`) passed to `svelte.preprocess()` |
| `SveltePreprocessor` | `interface` (deprecated) | Utility type for building typed preprocessor factories |

The runtime consumer of these types is the [compiler-preprocessor_engine](compiler-preprocessor_engine.md) (`preprocess/index.js`), which re-exports the single entry point `preprocess()` from the `svelte/compiler` package (see [compiler-core_public_api](compiler-core_public_api.md)).

---

## Architecture

### Position in the system

The module sits at the **boundary between third-party tooling and the compiler pipeline**. Bundler plugins invoke `preprocess()` *before* parsing/compiling; the resulting `Processed` object (transformed `code` + merged `map`) becomes the input to `compile()` / `parse()`.

```mermaid
flowchart LR
    subgraph Tooling["Ecosystem / Tooling Layer"]
        PP["Preprocessor packages<br/>(svelte-preprocess, vitePreprocess,<br/>custom Sass/TS/MD preprocessors)"]
        BP["Bundler plugins<br/>(vite-plugin-svelte,<br/>rollup-plugin-svelte)"]
    end

    subgraph CompilerPkg["svelte/compiler package"]
        subgraph Pre["compiler-preprocessor"]
            subgraph API["compiler-preprocessor_api<br/>(this module — public.d.ts)"]
                T["Processed<br/>MarkupPreprocessor<br/>Preprocessor<br/>PreprocessorGroup<br/>SveltePreprocessor"]
            end
            subgraph ENG["compiler-preprocessor_engine"]
                E["preprocess()<br/>process_tag() / process_single_tag()<br/>PreprocessResult"]
            end
        end
        ENTRY["compiler entry (index.js)<br/>compile · compileModule · parse<br/>— re-exports preprocess —"]
        subgraph Pipeline["Compilation phases"]
            P1["1-parse<br/>(compiler-parser)"]
            P2["2-analyze<br/>(compiler-analyzer)"]
            P3["3-transform<br/>(compiler-transformer)"]
        end
    end

    PP -- "implements the hook signatures" --> T
    T -. "type-only contract" .-> ENG
    BP -- "1. await preprocess(source, groups, {filename})" --> E
    E -- "2. Processed { code, map, dependencies }" --> BP
    BP -- "3. compile(processed.code, { sourcemap: processed.map })" --> ENTRY
    ENTRY --> P1 --> P2 --> P3
```

Key integration facts:

- **Types only, zero runtime cost** — the engine imports `Processed`, `MarkupPreprocessor`, `Preprocessor`, `PreprocessorGroup` via `/** @import */` JSDoc annotations; the module exists solely so JS code (JSDoc-typed) and TS tooling share one authoritative contract.
- **Public surfacing** — these declarations are re-exported into the package-level type surface ([svelte-public-types](svelte-public-types.md)) as the `Processed_1` / `SveltePreprocessor_1` aliases found in `packages/svelte/types/index.d.ts`.
- **Upstream of all compiler phases** — the parser never sees preprocessor syntax (`lang="ts"`, `lang="sass"`); by the time [compiler-parser](compiler-parser.md) runs, tags are already plain HTML/CSS/JS.

### Type model

```mermaid
classDiagram
    class Processed {
        +string code
        +string | object? map
        +string[]? dependencies
        +Record~string, string|boolean~? attributes
        +(() => string)? toString
    }
    class MarkupPreprocessor {
        <<function type>>
        call(options : {content, filename?}) Processed | void | Promise
    }
    class Preprocessor {
        <<function type>>
        call(options : {content, attributes, markup, filename?}) Processed | void | Promise
    }
    class PreprocessorGroup {
        +string? name
        +MarkupPreprocessor? markup
        +Preprocessor? script
        +Preprocessor? style
    }
    class SveltePreprocessor {
        <<deprecated utility type>>
        call(options?) Required_Pick_PreprocessorGroup_T
    }
    MarkupPreprocessor ..> Processed : may return
    Preprocessor ..> Processed : may return
    PreprocessorGroup o-- MarkupPreprocessor : markup
    PreprocessorGroup o-- Preprocessor : script · style
    SveltePreprocessor ..> PreprocessorGroup : Required~Pick~T~~
```

---

## Core Components

### `Processed` — the transformation result

The single most important type: every hook returns either `void` ("unchanged") or a `Processed` object.

| Field | Type | Required | Semantics |
| --- | --- | --- | --- |
| `code` | `string` | ✅ | The new code replacing the input (whole file for markup, tag body for script/style) |
| `map` | `string \| object` | — | Source map mapping the output back to the original. **Deliberately opaque** (`string \| object`) so public types don't depend on `@jridgewell/remapping` |
| `dependencies` | `string[]` | — | Extra files to watch for changes (e.g. `@import`ed Sass partials) — surfaced for HMR/file-watchers |
| `attributes` | `Record<string, string \| boolean>` | — | **Script/style only**: replacement attributes for the host tag. `undefined` keeps original attributes |
| `toString` | `() => string` | — | Optional legacy convenience so a `Processed` can stringify to its `code` |

The engine's `PreprocessResult.to_processed()` constructs the *final* `Processed` exactly with these fields:

```js
return {
    code: this.source,
    dependencies: [...new Set(this.dependencies)],  // deduplicated
    map,                                            // all per-hook maps chained via combine_sourcemaps()
    toString: () => this.source
};
```

### Hook signatures

**`MarkupPreprocessor`** — runs first, sees the entire component:

```ts
(options: { content: string; filename?: string }) => Processed | void | Promise<Processed | void>
```

**`Preprocessor`** (script/style) — runs per matching tag, with richer context:

```ts
(options: {
    content: string;                                 // tag body
    attributes: Record<string, string | boolean>;    // parsed tag attributes, e.g. { lang: 'ts' }
    markup: string;                                  // whole file content
    filename?: string;
}) => Processed | void | Promise<Processed | void>
```

**`PreprocessorGroup`** — the unit users compose in `svelte.config.js`:

```ts
{ name?: string; markup?: MarkupPreprocessor; style?: Preprocessor; script?: Preprocessor }
```

> `name` is optional today but **will become required in the next major version** (per the inline documentation) — it is used for error attribution and debugging.

### `SveltePreprocessor` (deprecated)

```ts
interface SveltePreprocessor<PreprocessorType extends keyof PreprocessorGroup, Options = any> {
    (options?: Options): Required<Pick<PreprocessorGroup, PreprocessorType>>;
}
```

A helper for libraries (historically `svelte-preprocess`) that export option-taking factories, e.g. `typescript(): SveltePreprocessor<'script', CompilerOptions>` producing `{ script: Preprocessor }` — typed as `Required<Pick<PreprocessorGroup, 'script'>>`. Marked `@deprecated`: **create this utility type yourself** rather than importing it.

---

## Contract Semantics (how the engine honors the API)

The [compiler-preprocessor_engine](compiler-preprocessor_engine.md) maps each field of the contract to concrete behavior:

| `Processed` field | Engine consumption point | Behavior |
| --- | --- | --- |
| *(return `void`)* | `process_single_tag` / `process_markup` | Treated as **"no change"** — original source is sliced through untouched |
| `code` (unchanged, no `map`) | `process_single_tag` | `if (!processed.map && processed.code === content)` → optimized no-op |
| `code` (changed) | `processed_tag_to_code` | Tag body replaced; open/close tags re-mapped so positions stay aligned |
| `map` (string) | `decode_map()` / `process_markup` | `JSON.parse`d into a source map object |
| `map` (object) | `decode_map()` | Used as-is (also accepts `SourceMapGenerator` instances, decoding `._mappings`) |
| `//# sourceMappingURL=data:…` embedded in `code` | `parse_attached_sourcemap()` | Extracted into `map` and stripped from `code`; warns if *both* inline attachment and `map` field exist |
| `dependencies` | `process_tag` closure → `PreprocessResult.dependencies` | Accumulated across all hooks, **deduplicated** in the final result |
| `attributes` | `stringify_tag_attributes()` | Re-serialized into the rewritten `<script …>` / `<style …>` opening tag; `true` renders as a bare attribute. `undefined` preserves the original tag |
| `toString` | `to_processed()` | Re-supplied on the aggregated result so tooling can treat it like the code string |

Two contract subtleties worth knowing:

1. **Ordering is fixed per group**: `markup` → `script` → `style`, and multiple groups are applied strictly sequentially. Each hook sees the output of the previous one.
2. **Legacy `filename`**: `preprocess()` falls back to `(preprocessor).filename` if `options.filename` is absent — a Svelte-4 compatibility path where the filename was attached to the group itself.

---

## Data Flow

### End-to-end preprocessing sequence

```mermaid
sequenceDiagram
    autonumber
    participant BP as Bundler plugin
    participant Eng as preprocess() engine
    participant Impl as Preprocessor implementation
    participant Res as PreprocessResult

    BP->>Eng: preprocess(source, groups[], { filename })
    Eng->>Res: new PreprocessResult(source, filename)

    loop each PreprocessorGroup (in array order)
        opt group.markup
            Eng->>Impl: markup({ content: whole file, filename })
            Impl-->>Eng: Processed | void
            Eng->>Res: update_source({ string: code, map: JSON.parse(map), dependencies })
        end
        opt group.script
            Eng->>Eng: regex scan for <script> tags
            Eng->>Impl: script({ content, attributes, markup, filename })
            Impl-->>Eng: Processed | void
            Eng->>Eng: parse_attached_sourcemap() — lift embedded sourceMappingURL
            Eng->>Res: update_source({ string, map, dependencies })
        end
        opt group.style
            Eng->>Eng: regex scan for <style> tags
            Eng->>Impl: style({ content, attributes, markup, filename })
            Impl-->>Eng: Processed | void
            Eng->>Eng: parse_attached_sourcemap()
            Eng->>Res: update_source({ string, map, dependencies })
        end
    end

    Eng->>Res: to_processed()
    Res-->>BP: Processed { code, map (all maps chained), dependencies (deduped), toString }
```

### Sourcemap lifecycle of a single `Processed`

```mermaid
flowchart TD
    A["Hook returns Processed"] --> B{"map provided?"}
    B -- "no + code unchanged" --> Z["no-op: original bytes sliced through"]
    B -- "no + code changed" --> C["positional remap:<br/>replacement is anchored to the tag's<br/>original line/column via get_location()"]
    B -- "yes" --> D["decode_map():<br/>JSON string → object ·<br/>mappings string → segments ·<br/>SourceMapGenerator → decoded"]
    D --> E{"sources include the<br/>component file basename?"}
    E -- yes --> F["sourcemap_add_offset(): segments shifted<br/>to absolute position of the tag"]
    E -- no --> G["kept as-is"]
    C --> H
    F --> H
    G --> H["unshifted into sourcemap_list<br/>(reverse application order)"]
    H --> I["combine_sourcemaps(file_basename, list)<br/>→ one chained map on the final Processed"]
    I --> J["Consumed by compile() via the<br/>CompileOptions.sourcemap option,<br/>merged into the compiler's output map"]
```

This is why the public `map` type is intentionally opaque: the engine normalizes whatever the preprocessor emits (raw JSON string, plain object, `SourceMapGenerator`, or data-URI attachment) into a single `@jridgewell/remapping`-compatible chain.

---

## Writing a Preprocessor (consumer guide)

A minimal group that adds TypeScript support, illustrating every part of the contract:

```js
/** @type {import('./public.js').PreprocessorGroup} */
export default {
    name: 'my-typescript',
    async script({ content, attributes, filename }) {
        if (attributes.lang !== 'ts') return;          // void ⇒ "unchanged"
        const { code, map, dependencies } = await compileTypeScript(content, filename);
        return {
            code,                                       // required: transformed body
            map,                                        // opaque: string or object
            dependencies,                               // optional: watched imports
            attributes: { ...attributes, lang: undefined } // optional: rewrite the tag
        };
    }
};
```

Guidelines:

- **Return `void`** (or nothing) when the input needs no transformation — this is cheaper than returning identical `code`, because the engine then slices the original source through and skips sourcemap bookkeeping.
- **Prefer the `map` field** over appending `//# sourceMappingURL=` comments; the engine supports the attachment convention for script/style but warns when a preprocessor uses both channels.
- **Populate `dependencies`** for anything referenced but not statically visible in the file (Sass `@use`, `@import`, custom directives) so dev-mode file watching stays correct.
- **Use `attributes`** to normalize the tag after transformation (e.g. drop `lang="sass"` once output is plain CSS) — otherwise downstream tooling may re-apply the preprocessor.

---

## Related Modules

| Module | Relationship |
| --- | --- |
| [compiler-preprocessor](compiler-preprocessor.md) | Parent module grouping the whole preprocessor subsystem |
| [compiler-preprocessor_engine](compiler-preprocessor_engine.md) | The runtime implementation (`preprocess()`, `process_single_tag()`, `PreprocessResult`) that consumes this module's types |
| [compiler-core_public_api](compiler-core_public_api.md) | `svelte/compiler` entry (`compile` / `compileModule` / `parse`) which re-exports `preprocess` and receives preprocessed code + `sourcemap` option |
| [compiler-parser](compiler-parser.md) | First compiler phase run on the *post-preprocessing* source |
| [compiler-analyzer](compiler-analyzer.md) / [compiler-transformer](compiler-transformer.md) | Downstream phases; never interact with preprocessor syntax |
| [svelte-public-types](svelte-public-types.md) | Surfaces these declarations publicly (`Processed_1`, `SveltePreprocessor_1` aliases in `packages/svelte/types/index.d.ts`) |

---

## Maintenance Notes

- **Stability**: This file is part of the documented public API — every field of `Processed` and every hook signature is a compatibility surface. Changes require a semver-major release and a migration note.
- **Keep it dependency-free**: The comment `// we are opaque with the type here to avoid dependency on the remapping module for our public types` is a design constraint — do not import library types (e.g. `RawSourceMap`) into this file.
- **`name` migration**: When the next major lands, `PreprocessorGroup.name` flips from optional to required; the engine already reads it (`(preprocessor).filename` legacy handling shows how group-level properties are accessed defensively today).
- **`toString` is vestigial**: It exists to keep older tooling working when the `Processed` result is embedded where a string was expected. New tooling should read `.code` explicitly.
- **Typed from JSDoc**: The engine is plain JS with JSDoc imports (`/** @import { Processed, ... } from './public.js' */`); keep declaration names in sync when refactoring.
