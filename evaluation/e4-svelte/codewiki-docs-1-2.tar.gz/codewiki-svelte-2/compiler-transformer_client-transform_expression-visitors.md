# compiler-transformer_client-transform_expression-visitors

## 1. Introduction

The **expression-visitors** module is the expression-level heart of the Svelte 5 **client transform** (phase 3 of the compiler). Each file in `packages/svelte/src/compiler/phases/3-transform/client/visitors/` that is listed here exports a single visitor function which is registered in the client transform's visitor map and invoked by the zimmerframe-based traversal driver ([compiler-transformer_client-transform_infrastructure](compiler-transformer_client-transform_infrastructure.md)).

The module's job is to **rewrite ordinary JavaScript expressions, statements and class constructs into calls against the internal client runtime (`$.…`)**, so that:

- reading a reactive variable compiles to a **signal read** (`$.get`),
- assigning/mutating one compiles to a **signal write** (`$.set` / `$.assign` family),
- runes (`$state`, `$derived`, `$effect.*`, `$inspect`, `$host`) compile to their **runtime primitives**,
- template `{@const}` tags become **derived signals**,
- class `$state`/`$derived` fields become **backing fields + reactive accessors**,
- legacy `$:` statements become **`$.legacy_pre_effect`** calls, and
- `await` expressions **preserve template/derived context** across async boundaries.

In short: *everything a component author writes as reactive-looking JavaScript leaves this module as explicit calls into the [Client Runtime Engine](client-reactivity-engine.md) (signals, effects, proxies) plus a set of dev-only instrumentation hooks ([client-dev-tooling](client-dev-tooling.md))*.

---

## 2. Position in the compiler pipeline

The visitors run on the **annotated AST produced by phase 2 (analyze)** — they never discover reactivity themselves; they *consume* the scopes, bindings, rune analysis and expression metadata created by the [analyzer](compiler-analyzer.md), and *emit* code that the [structural visitors](compiler-transformer_client-transform_structural-visitors.md) and [directive visitors](compiler-transformer_client-transform_directive-visitors.md) embed into the final component.

```mermaid
flowchart TD
    P["Phase 1 — Parse"] --> A["Phase 2 — Analyze<br/>(scopes, bindings, rune/reference analysis,<br/>expression metadata: references / has_call / has_await …)"]
    A --> CT
    subgraph CT["Phase 3 — Client transform (see compiler-transformer_client-transform)"]
        INFRA["Infrastructure<br/>visit · build_getter · should_proxy · create_derived<br/>(compiler-transformer_client-transform_infrastructure)"]
        STRUCT["Structural visitors<br/>Fragment · RegularElement · EachBlock · SnippetBlock …"]
        DIRS["Directive visitors<br/>BindDirective · OnDirective · UseDirective …"]
        EXPR["<b>Expression visitors — this module</b><br/>Identifier · AssignmentExpression · CallExpression<br/>AwaitExpression · ConstTag · ClassBody · LabeledStatement"]
        INFRA --> STRUCT
        INFRA --> DIRS
        INFRA --> EXPR
    end
    STRUCT -- "inline & attribute expressions" --> EXPR
    DIRS -- "handler / binding expressions" --> EXPR
    CT --> OUT["Client-side JS component code"]
    OUT --> RTE["Client Runtime Engine<br/>$.get · $.set · $.derived · $.proxy · effects · DOM"]
```

### Visitor dispatch model

Every visitor receives a zimmerframe `Context` object (`node`, `path`, `state`, `visit`, `next`) where `state` is a `ComponentClientTransformState` carrying, among other things:

| State field | Used by | Purpose |
|---|---|---|
| `scope` | all | current scope; binding lookup (`scope.get(name)`), rune resolution (`get_rune`), fresh name generation |
| `transform` | Identifier, AssignmentExpression, ConstTag | per-binding *read/assign/mutate* hooks — the reactive "wiring map" |
| `analysis` | all | runes-mode flag, `classes` → state fields, `reactive_statements`, template expression metadata |
| `consts` | ConstTag | accumulated instance-level declarations to hoist into the component init |
| `legacy_reactive_statements` | LabeledStatement | deferred `$:` effects, inserted later in topological order |
| `in_derived` / `in_constructor` / `is_instance` | CallExpression, AwaitExpression, visit_function | mode flags that steer codegen |

The traversal is a single pass: [structural visitors](compiler-transformer_client-transform_structural-visitors.md) build `$.template()` fragments and branches, and every expression they encounter (attribute values, event handlers, children expressions) is funneled through the visitors in this module.

---

## 3. Core components

### 3.1 `Identifier` — reactive reads

`visitors/Identifier.js::Identifier`

- Uses the external `is-reference` helper to distinguish genuine **variable references** from property keys / member paths (only the former become reactive reads).
- **`$$props` → `$$sanitized_props`**: component code reading `$$props` gets the sanitized public props object.
- **Rest-prop read optimization** (runes mode only): a non-computed, *read-only* member access on a `rest_prop` binding (e.g. `$$restProps.foo`) compiles to a direct `$$props.foo` access — legal only for reads, so assignments/updates on the path are excluded.
- All other references go through **`build_getter(node, state)`**, which consults `state.transform`:

```mermaid
flowchart TD
    A["Identifier node"] --> B{"is_reference(node, parent)?"}
    B -- "no (key, member, …)" --> Z["return unchanged"]
    B -- "yes" --> C{"name === '$$props'?"}
    C -- "yes" --> D["return $$sanitized_props"]
    C -- "no" --> E{"runes mode && binding.kind === 'rest_prop'<br/>&& plain member <b>read</b>?"}
    E -- "yes" --> F["return $$props"]
    E -- "no" --> G["build_getter(node, state)"]
    G --> H{"name registered in<br/>state.transform?"}
    H -- "no" --> I["identifier kept as-is<br/>(plain JS variable)"]
    H -- "yes" --> J["transform[name].read(node)<br/>e.g. $.get(x), $.get(tmp).member …"]
```

This is the module that *converts every subsequent mention of a reactive name into its runtime read* — the `transform` map entries themselves are installed by `ConstTag` (below), by the structural visitors (`$state` declarations, each items, snippet args), and by directive visitors.

### 3.2 `AssignmentExpression` — reactive writes & mutations

`visitors/AssignmentExpression.js::AssignmentExpression`

Entry point routes through the shared `visit_assignment_expression` (handles destructuring targets by rewriting them into sequences/IIFEs of simple assignments) and finally wraps the result in **`validate_mutation`** (dev-only ownership checks for `prop`/`bindable_prop` mutations — see [client-dev-tooling](client-dev-tooling.md)).

The local `build_assignment(operator, left, right, context)` implements the actual strategy, in priority order:

1. **Class state fields (runes mode)** —
   *constructor declaration* `this.field = $state(…)` / `$derived(…)` becomes an assignment to the private backing field (`this.#field`), with the rune call visited in a state where `in_constructor` is set; in dev the value is wrapped with `$.tag` for debug labels.
   *private field writes* (`this.#field = v`) become `$.set(left, value, needs_proxy)`, where `needs_proxy` applies only to `$state` fields with **non-coercive** operators (`=`, `&&=`, `||=`, `??=`) and values that `should_proxy` deems proxy-able.
2. **Reassignment of a registered binding** — if the root object is in `state.transform` and provides `assign`, delegate to it, passing a `should_proxy` flag (computed only for non-coercive operators and non-primitive binding kinds) so e.g. `list = value` deep-proxies plain objects.
3. **Mutation of a registered binding** — `transform.mutate` wraps the raw assignment expression (`list[i] = x`, `obj.a.b++`) so the *containing* signal is reassigned.
4. **Dev-only ownership/proxy diagnostics** — for member assignments in expression position, the assignment is rewritten to `$.assign`-family calls (`callees` map below) so the runtime can warn when a proxy value "escapes" (e.g. `(obj.items ??= []).push(v)`), while special-casing event-handler arrows, `bind:` directives and component props where primitive semantics are known.

| Operator | Emitted dev helper |
|---|---|
| `=` | `$.assign(obj, key, value, loc)` |
| `&&=` | `$.assign_and(obj, key, value, loc)` |
| `\|\|=` | `$.assign_or(obj, key, value, loc)` |
| `??=` | `$.assign_nullish(obj, key, value, loc)` |

```mermaid
sequenceDiagram
    autonumber
    participant V as visit (infrastructure)
    participant AE as AssignmentExpression
    participant VAE as visit_assignment_expression (shared)
    participant BA as build_assignment
    participant TR as state.transform hooks
    participant RT as Client runtime

    V->>AE: AssignmentExpression node
    AE->>VAE: route node
    Note over VAE: destructuring targets are<br/>expanded into simple assignments
    VAE->>BA: operator · left · right
    alt class state field in constructor / private field
        BA->>RT: this.#f = $.state(...) · $.set(this.#f, v, proxy?)
    else reassignment (transform.assign exists)
        BA->>TR: assign(node, value, should_proxy?)
        TR->>RT: e.g. $.set / prop / store update
    else mutation (transform.mutate exists)
        BA->>TR: mutate(node, raw assignment)
    else dev + member assignment in expression position
        BA->>RT: $.assign / assign_and / assign_or / assign_nullish
    else no reactive binding involved
        BA-->>VAE: null (keep source semantics)
    end
    VAE-->>AE: transformed expression
    AE->>AE: validate_mutation (dev ownership wrapper)
    AE-->>V: result
```

### 3.3 `CallExpression` — rune desugaring

`visitors/CallExpression.js::CallExpression`

Resolves the callee via `get_rune(node, scope)` (a rune is a `$`-prefixed global keypath not shadowed by a local binding) and dispatches:

| Rune | Emitted client code | Notes |
|---|---|---|
| `$host` | `$$props.$$host` | inside custom elements |
| `$effect.tracking()` | `$.effect_tracking()` | |
| `$state(v)` / `$state.raw(v)` | `$.state($.proxy(v)?)` / `$.state(v)` | `$.proxy` added when `should_proxy(v)`; used for constructor field declarations |
| `$derived(expr)` | `$.derived(() => expr)` | argument visited with `in_derived: true` |
| `$derived.by(fn)` | `$.derived(fn)` | function passed as-is |
| `$state.snapshot(x)` | `$.snapshot(x, ignore?)` | `ignore` is `true` when `svelte-ignore state_snapshot_uncloneable` is present |
| `$effect.root(fn…)` | `$.effect_root(fn…)` | |
| `$effect.pending()` | `$.pending()` | |
| `$inspect(...)` / `$inspect(...).with(fn)` | `$.inspect(...)` (dev only, via `transform_inspect_rune`) | compiles to nothing in production |

Additionally, **in dev mode**, any `console.*` call whose arguments may reference state is wrapped through `$.log_if_contains_state` so reactive values are annotated in the console. Non-rune calls fall through with `context.next()`.

### 3.4 `AwaitExpression` — async context preservation

`visitors/AwaitExpression.js::AwaitExpression`

An `await` inside a template or `$derived` expression would otherwise lose the current *signal-reading context*. This visitor decides whether to wrap the awaited value:

```mermaid
flowchart TD
    A["AwaitExpression"] --> B{"top-level await in instance?<br/>is_instance && function_depth === 1"}
    B -- yes --> S["await $.save(argument)"]
    B -- no --> C{"inside a reactive expression?<br/>in_derived || ancestor has metadata<br/>(stop at function boundaries)"}
    C -- no --> D{"dev && !svelte-ignore<br/>await_reactivity_loss"}
    D -- yes --> T["await $.track_reactivity_loss(argument)"]
    D -- no --> U["plain await argument"]
    C -- yes --> E{"is_last_evaluated_expression?<br/>(await is the last value read in its chain)"}
    E -- "no (later expressions still read context)" --> S
    E -- yes --> U
```

Key details:

- `is_reactive_expression` walks the ancestor path: any node carrying template `metadata` marks a reactive expression; function nodes terminate the search; `state.in_derived` short-circuits to `true`.
- `is_last_evaluated_expression` implements a per-parent-type check (last element of arrays/sequences/calls, right-hand side of binaries, non-computed member objects, etc.) — only awaits *followed by more evaluation* need `$.save`.
- The analyzer's `metadata.expression.has_await` flag (set during phase 2) is what lets *callers* (`ConstTag`, template builders) choose `$.async_derived`/async blocks — this visitor handles the *inner* preservation.
- Dev instrumentation `$.track_reactivity_loss` warns about reactivity that silently breaks across the await boundary.

### 3.5 `ConstTag` — `{@const}` as derived signals

`visitors/ConstTag.js::ConstTag`

Transforms each `{@const name = expr}` (only valid directly inside blocks) into a **derived signal** registered in the current scope's transform map:

- **Simple identifier**: the init expression is built via `build_expression` (which applies legacy deep-read semantics via `$.untrack` + eager getter sequences when not in runes mode), wrapped by `create_derived` → `$.derived(() => …)` (or `await $.save($.async_derived(() => …))` when `metadata.expression.has_await`). In dev the value is `$.tag`-ged. The declaration is pushed onto `state.consts`, and `state.transform[name] = { read: get_value }` is installed so *every later `Identifier` read becomes `$.get(name)`*. Dev mode also eagerly emits `$.get(name)` to surface "cannot access before initialization" errors at the right place.
- **Destructuring pattern**: a fresh `computed_const` identifier holds a derived block that destructures the init and returns an object of the extracted identifiers; each identifier's transform entry reads `$.get(tmp).member`. This keeps pattern members as *reads of one derived*, not independent signals.

### 3.6 `ClassBody` — class `$state` fields

`visitors/ClassBody.js::ClassBody`

Uses `analysis.classes.get(node)` (populated during analysis) to find `StateField`s; if absent (legacy mode) the class is traversed unchanged. Otherwise:

- **Constructor-assigned fields** (`this.x = $state(…)` in the constructor) get a synthesized backing field plus a getter (`return $.get(this.#x)`) and setter (`$.set(this.#x, value, proxy?)`) pair.
- **Declared public fields** (`x = $state(…)` / `$derived(…)`): the `PropertyDefinition` is replaced by a **private backing field** initialized with the transformed rune call, plus the same accessor pair. The getter/setter indirection is what makes `instance.x` reactive both inside the class and for external consumers.
- **Private `#fields`** keep their name but receive transformed initial values.
- Dev mode tags all field initializers with `$.tag` labels of the form `ClassName.field` for the dev-tools inspector.

This visitor pairs with `AssignmentExpression`'s constructor/private-field special cases — writes land in `$.set` on the same backing fields.

### 3.7 `LabeledStatement` — legacy `$:` reactive statements

`visitors/LabeledStatement.js::LabeledStatement`

Active **only in legacy mode at instance top level** (`!runes && path.length === 1 && label === '$'`). For a `$:` block:

1. Reads the dependency set pre-computed by the analyzer (`analysis.reactive_statements`).
2. Builds a deps thunk: each reactive dependency is read through `build_getter`; props / `$$props` / `$$restProps` / `bindable_prop` dependencies are force-read via `$.deep_read_state` to replicate Svelte 4's coarse-grained invalidation.
3. Emits `$.legacy_pre_effect(depsThunk, bodyThunk)` and stores it in `state.legacy_reactive_statements`, keyed by the labeled node; the statement in place becomes `b.empty`. The component-level visitor later inserts these effects **in topological dependency order** into the instance function.

In runes mode the statement is left untouched (a `$:` label is simply a label).

---

## 4. Component relationships & dependencies

```mermaid
graph LR
    subgraph VIS["Expression visitors (this module)"]
        ID["Identifier"]
        AE["AssignmentExpression"]
        CE["CallExpression"]
        AWE["AwaitExpression"]
        CT["ConstTag"]
        CB["ClassBody"]
        LS["LabeledStatement"]
    end

    subgraph INFRA["Infrastructure — client/utils.js<br/>(compiler-transformer_client-transform_infrastructure)"]
        BG["build_getter"]
        SP["should_proxy"]
        CD["create_derived"]
    end

    subgraph SHARED["Shared transform helpers"]
        VAE["visit_assignment_expression<br/>(3-transform/shared/assignments.js)"]
        VM["validate_mutation<br/>(visitors/shared/utils.js)"]
        BE["build_expression<br/>(visitors/shared/utils.js)"]
        GV["get_value<br/>(visitors/shared/declarations.js)"]
        VF["visit_function<br/>(visitors/shared/function.js)"]
        TIR["transform_inspect_rune<br/>(3-transform/utils.js)"]
    end

    subgraph CORE["Compiler core"]
        B["builders (b.*)<br/>compiler-core_ast_builders"]
        GR["get_rune / Scope<br/>(compiler-analyzer)"]
        ST["dev · is_ignored · locate_node<br/>(compiler-core)"]
        META["AST utils & expression metadata"]
    end

    ID --> BG
    LS --> BG
    AE --> SP
    CE --> SP
    AE --> VAE
    AE --> VM
    CT --> CD
    CT --> BE
    CT --> GV
    CE --> TIR
    ID & CE & AWE & CT --> GR
    AE & CE & AWE & CT & CB --> ST
    VIS --- B
    AE & ID & CT & LS --> META
    VF -. "resets in_derived / in_constructor<br/>around function bodies" .-> VIS
```

Dependency summary:

- **From infrastructure** ([compiler-transformer_client-transform_infrastructure](compiler-transformer_client-transform_infrastructure.md)): `visit` traversal driver, `build_getter` (read-funnel used by `Identifier` & `LabeledStatement`), `should_proxy` (deep-proxy heuristics), `create_derived` (`$.derived` vs `$.derived_safe_equal` vs async `$.async_derived` selection).
- **From the analyzer** ([compiler-analyzer](compiler-analyzer.md)): `get_rune`, binding kinds (`rest_prop`, `prop`, `bindable_prop`, …), `analysis.classes` state fields, `analysis.reactive_statements`, `node.metadata.expression` (`references`, `has_await`, `has_call`, …).
- **From compiler core** ([compiler-core](compiler-core.md), [compiler-core_ast_builders](compiler-core_ast_builders.md)): the `b.*` AST builders, `dev`/`is_ignored`/`locate_node` from compile state, AST utilities (`extract_identifiers`, `get_name`, `get_parent`, `get_attribute_expression`, `is_event_attribute`, `build_assignment_value`).
- **External**: `is-reference` (reference detection in `Identifier`).
- **Sibling visitor groups**: expressions reached through [structural visitors](compiler-transformer_client-transform_structural-visitors.md) (templates, blocks, elements) and [directive visitors](compiler-transformer_client-transform_directive-visitors.md) (`on:click={…}`, `bind:value={…}`) are themselves processed by these visitors through the shared traversal. The server-side counterparts live in [compiler-transformer_server-transform](compiler-transformer_server-transform.md) (e.g. its own `AssignmentExpression.build_assignment`, `ConstTag`, `CallExpression`) — same *shape*, different emission targets.

---

## 5. End-to-end data flow

### 5.1 Reactive read/write wiring

The central mechanism is the `state.transform` map: **declaration-side visitors register hooks; this module's `Identifier`/`AssignmentExpression` visitors consume them.**

```mermaid
flowchart LR
    subgraph REG["Hook registration (elsewhere in client transform)"]
        R1["$state / $derived declarations<br/>(Fragment/Component visitors)"]
        R2["{@const} → ConstTag (this module)"]
        R3["class fields → ClassBody (this module)"]
        R4["each items, snippet args, stores,<br/>bindable props (structural/directive visitors)"]
    end
    REG -- "transform[name] = {read, assign?, mutate?}" --> MAP[("state.transform")]
    MAP -- "every reference" --> RD["Identifier → read(name)<br/>= $.get / member read"]
    MAP -- "every write" --> WR["AssignmentExpression →<br/>assign(name) / mutate(name)"]
    RD & WR --> OUT["component code calling<br/>$.get · $.set · $.assign …"]
```

### 5.2 Typical compile trace

For a component like:

```svelte
<script>
  let count = $state(0);
  const doubled = $derived(count * 2);
</script>
<button on:click={() => count++}>{doubled}</button>
```

1. Phase 2 marks `count` as a `$state` binding and the template expressions with metadata.
2. The instance visitor declares `count` via `$.state(...)` and registers `transform.count`.
3. `CallExpression` rewrites `$state(0)` → `$.state(0)` and `$derived(count * 2)` → `$.derived(() => count * 2)` (the inner `count` read is turned into `$.get(count)` by `Identifier` while visiting with `in_derived: true`).
4. `ConstTag`/`$derived` registration makes the `{doubled}` text expression read via `$.get(doubled)` inside the template effect built by the [structural visitors](compiler-transformer_client-transform_structural-visitors.md).
5. `AssignmentExpression` rewrites `count++` (inside the arrow handled through the [directive visitors](compiler-transformer_client-transform_directive-visitors.md)) into `$.set(count, …)` via the binding's `mutate`/`assign` hook.

---

## 6. Runtime contract (emitted APIs)

Everything this module emits targets the internal `$.` namespace. Ownership:

| Emitted call | Emitted by | Runtime home |
|---|---|---|
| `$.get`, `$.set`, `$.state`, `$.derived`, `$.proxy`, `$.snapshot`, `$.effect_tracking`, `$.effect_root`, `$.pending`, `$.save`, `$.async_derived`, `$.deep_read_state`, `$.untrack`, `$.legacy_pre_effect` | all visitors | [Client Runtime Engine](client-reactivity-engine.md) (signals, effects, stores, async) |
| `$.assign` / `$.assign_and` / `$.assign_or` / `$.assign_nullish` | `AssignmentExpression` (dev) | [client-dev-tooling](client-dev-tooling.md) (`dev/assign.js`) |
| `$.tag` | `ConstTag`, `ClassBody`, `AssignmentExpression` (dev) | [client-dev-tooling](client-dev-tooling.md) (debug/tracing) |
| `$.log_if_contains_state` | `CallExpression` (dev) | [client-dev-tooling](client-dev-tooling.md) (`dev/console-log.js`) |
| `$.track_reactivity_loss` | `AwaitExpression` (dev) | [Client Runtime Engine](client-reactivity-engine.md) (`reactivity/async.js`) |
| `$.inspect` | `CallExpression` via `transform_inspect_rune` (dev) | [client-dev-tooling](client-dev-tooling.md) (`dev/inspect.js`) |
| `$$ownership_validator.mutation` | `AssignmentExpression` via `validate_mutation` (dev) | [client-dev-tooling](client-dev-tooling.md) (`dev/ownership.js`) |
| `$$sanitized_props`, `$$props.$$host` | `Identifier`, `CallExpression` | component props plumbing ([compiler-transformer_client-transform](compiler-transformer_client-transform.md)) |

Because dev-mode helpers (`$.tag`, `$.inspect`, `$.assign*`, ownership validation) must disappear in production builds, every emission site checks the `dev` flag from [compiler-core](compiler-core.md) state, and several honor `svelte-ignore` comments via `is_ignored` (`state_snapshot_uncloneable`, `await_reactivity_loss`, `ownership_invalid_mutation`).

---

## 7. Mode matrix (runes vs. legacy)

| Visitor | Runes mode | Legacy mode |
|---|---|---|
| `Identifier` | rest-prop read optimization active; all reads via transform hooks | reads via transform hooks (proxy-based props); no rest-prop shortcut |
| `AssignmentExpression` | class-state special cases, proxy flags, dev `$.assign*` | transforms via legacy binding hooks only |
| `CallExpression` | full rune desugaring | runes ignored (`get_rune` requires runes-compatible scope); only dev console wrapping may apply |
| `AwaitExpression` | `$.save` in TLA / reactive expressions | same rules (legacy async templates) |
| `ConstTag` | `$.derived` | `$.derived_safe_equal` (via `create_derived`); `build_expression` adds coarse deep-read sequence |
| `ClassBody` | backing fields + accessors | **no-op** (plain traversal) |
| `LabeledStatement` | untouched (`context.next()`) | `$:` → `$.legacy_pre_effect`, deferred + topologically sorted |

---

## 8. Design notes & gotchas for maintainers

- **Never bypass `build_getter`**: any new code path that reads a user variable must funnel through it (or a registered `read` hook), or reactivity silently breaks.
- **`in_derived` discipline**: `visit_function` (shared) resets `in_derived`/`in_constructor` when crossing function boundaries; `CallExpression` sets it for `$derived` arguments; `ConstTag` sets it for its init. Await and getter decisions depend on these flags being correct.
- **Metadata is the analyzer's contract**: `node.metadata.expression` (`has_await`, `references`, …) and path-node `metadata` (template ownership) are trusted by `AwaitExpression`/`build_expression`; changes in the [analyzer](compiler-analyzer.md) can ripple here.
- **Coercive vs non-coercive assignment**: only `=`, `&&=`, `||=`, `??=` trigger proxying decisions — compound arithmetic (`+=`) coerces, so proxying is unnecessary.
- **Dev-only rewrites must be expression-preserving**: `$.assign*` and ownership-wrapped mutations keep the assignment's value semantics (the value of the expression stays the assigned value).
- **`LabeledStatement` ordering**: the emitted effect is *not* placed inline; insertion order is resolved later — don't assume positional output.
- **Server symmetry**: when changing read/assign semantics here, mirror the change in the corresponding [server-transform](compiler-transformer_server-transform.md) visitor (e.g. `build_assignment`, `ConstTag`) so SSR output stays consistent.

## 9. Related documentation

- Parent phase: [compiler-transformer_client-transform](compiler-transformer_client-transform.md)
- Traversal & core helpers: [compiler-transformer_client-transform_infrastructure](compiler-transformer_client-transform_infrastructure.md)
- Sibling visitor groups: [compiler-transformer_client-transform_structural-visitors](compiler-transformer_client-transform_structural-visitors.md) · [compiler-transformer_client-transform_directive-visitors](compiler-transformer_client-transform_directive-visitors.md)
- Analysis inputs: [compiler-analyzer](compiler-analyzer.md) · [compiler-core](compiler-core.md) · [compiler-core_ast_builders](compiler-core_ast_builders.md)
- Runtime targets: [client-reactivity-engine](client-reactivity-engine.md) · [client-dev-tooling](client-dev-tooling.md)
- SSR counterpart: [compiler-transformer_server-transform](compiler-transformer_server-transform.md)
