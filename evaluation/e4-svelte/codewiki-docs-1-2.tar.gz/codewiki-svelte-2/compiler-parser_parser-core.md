# compiler-parser/parser-core

## Introduction

The **parser-core** module is the heart of Phase 1 (parsing) of the Svelte compiler. It exposes the `parse()` entry point and the `Parser` class, which convert a raw Svelte template string into an **Abstract Syntax Tree (AST)** rooted at `AST.Root`. Everything downstream — analysis, CSS scoping, and client/server code generation — operates on the tree this module produces.

Unlike a grammar-driven parser, this module implements a **character-level state machine**: the `Parser` walks the template byte-by-byte and delegates to swappable *state functions* (`fragment`, `element`, `text`, `tag`, …) that decide how to interpret the next construct. This design makes the parser tolerant of Svelte's mixed syntax (HTML + mustache tags + embedded `<script>`/`<style>` blocks) and enables a **loose mode** used by language tooling (IDEs) where recovery from incomplete code matters more than failing fast.

**Source location:** `packages/svelte/src/compiler/phases/1-parse/index.js`

**Module lineage:** `Compiler_Pipeline___Language_Toolchain` › `compiler-parser` › `compiler-parser_parser-core`

---

## Module Overview

| Aspect | Description |
|---|---|
| **Public API** | `parse(template, loose?) → AST.Root` |
| **Core class** | `Parser` — lexer primitives, node stack, fragment stack, error reporting |
| **Inputs** | Svelte source string; `loose` flag for error-tolerant parsing |
| **Outputs** | `AST.Root` containing `fragment`, `instance`/`module` scripts, `css`, and `options` |
| **Key collaborators** | [parsing-states](compiler-parser_parsing-states.md), [options-reading](compiler-parser_options-reading.md), [js-ts-parsing](compiler-parser_js-ts-parsing.md), [parsing-utilities](compiler-parser_parsing-utilities.md), [compiler-core_diagnostics](compiler-core_diagnostics.md) |
| **Consumers** | [compiler-core_public_api](compiler-core_public_api.md) (`compile` / `compileModule`) and the [compiler-analyzer](compiler-analyzer.md) phase |

### Key behaviours

1. **State-machine parsing** — a loop invokes the current state function, which consumes characters and returns the next state (or `undefined` to fall back to `fragment`).
2. **Loose parsing mode** — when `loose === true`, the parser recovers from incomplete/invalid markup (trailing `<div.`, unclosed tags, half-typed expressions) instead of throwing. This powers IDE features such as completions and embedded formatting.
3. **TypeScript detection** — a regex scan of `<script lang="ts">` sets `parser.ts` / `Root.metadata.ts` *before* parsing begins, so embedded JS/TS can be parsed with the right parser later.
4. **`<svelte:options>` extraction** — the options element is removed from the fragment, validated, and hoisted onto `Root.options` (with the raw node attached non-enumerably for the legacy AST).
5. **Implicit close handling** — HTML's optional closing tags (e.g. `<li>`, `<p>`) auto-close open elements with a warning; invalid closings error out.

---

## Architecture

```mermaid
flowchart TB
    subgraph Consumers
        API["compile / compileModule<br/>(compiler-core_public_api)"]
    end

    subgraph ParserCore["parser-core (this module)"]
        PARSE["parse(template, loose)"]
        PARSER["Parser class"]
        subgraph LexerPrimitives["Lexer primitives"]
            EAT["eat / match / match_regex"]
            READ["read / read_until / read_identifier"]
            WS["allow_whitespace / require_whitespace"]
        end
        subgraph StackMgmt["Stack & fragment management"]
            STACK["stack: AST nodes"]
            FRAGS["fragments: AST.Fragment"]
            APPEND["append(node)"]
            POP["pop()"]
        end
    end

    subgraph States["parsing-states module"]
        FRAGMENT["fragment()"]
        ELEMENT["element()"]
        TEXT["text()"]
        TAG["tag()"]
    end

    subgraph Support
        OPT["read_options<br/>(options-reading)"]
        CREATE["create_fragment<br/>(parsing utilities)"]
        ACORN["acorn.js parse<br/>(js-ts-parsing, invoked per &lt;script&gt;)"]
    end

    subgraph Diagnostics["compiler-core_diagnostics"]
        ERR["errors.js"]
        WARN["warnings.js"]
        STATE["state.js (set_source locator)"]
    end

    API --> PARSE
    PARSE -->|"state.set_source()"| STATE
    PARSE --> PARSER
    PARSER -->|"state = state(parser) loop"| FRAGMENT
    FRAGMENT -->|"&lt;"| ELEMENT
    FRAGMENT -->|"{"| TAG
    FRAGMENT -->|"otherwise"| TEXT
    ELEMENT -->|"attributes"| FRAGMENT
    ELEMENT -->|"&lt;script&gt; body"| ACORN
    ELEMENT --> APPEND
    TEXT --> APPEND
    PARSER --- EAT
    PARSER --- READ
    PARSER --- WS
    PARSER --- STACK
    PARSER --- FRAGS
    PARSER -->|"&lt;svelte:options&gt;"| OPT
    PARSER -->|"root.fragment"| CREATE
    ELEMENT --> ERR
    ELEMENT --> WARN
    PARSER --> ERR
    PARSER -->|"AST.Root"| API
    PARSER -->|"AST.Root"| ANALYZER["compiler-analyzer<br/>(Phase 2)"]

    style ParserCore fill:#e8f4f8,stroke:#0b7285
    style States fill:#fff4e6,stroke:#e8590c
    style Diagnostics fill:#fff0f6,stroke:#c2255c
```

---

## Public API

### `parse(template, loose = false) → AST.Root`

```javascript
export function parse(template, loose = false) {
	state.set_source(template);

	const parser = new Parser(template, loose);
	return parser.root;
}
```

**Steps:**

1. Registers the source with the module-level compiler state (`state.set_source`), which builds a line/column **locator** so every subsequent diagnostic (`CompileError`, warnings, code frames from `get_code_frame`) can report precise positions.
2. Instantiates `Parser`, whose constructor performs the entire parse.
3. Returns the completed `AST.Root`.

> The returned `Root` is the canonical input to `analyse_component` in the [compiler-analyzer](compiler-analyzer.md) phase. Public callers reach it through `compile()` / `compileModule()` documented in [compiler-core_public_api](compiler-core_public_api.md).

### `ParserState` type

```javascript
/** @typedef {(parser: Parser) => ParserState | void} ParserState */
```

A state function receives the parser and either returns the next state function or nothing (meaning: continue in `fragment`). This is the contract every module in [compiler-parser_parsing-states](compiler-parser_parsing-states.md) fulfils.

---

## The `Parser` Class

### Instance state

| Member | Purpose |
|---|---|
| `template` | The (right-trimmed) source string. **Readonly.** |
| `loose` | Error-tolerant mode flag — see [Loose parsing mode](#loose-parsing-mode). |
| `index` | Current cursor position in `template`. |
| `ts` | `true` when the source declares `<script lang="ts">`; also propagated to `Root.metadata.ts`. |
| `stack` | Stack of currently open `AST.TemplateNode`s (init: `[root]`). `current()` peeks. |
| `fragments` | Parallel stack of open `AST.Fragment`s so `append(node)` always targets the innermost fragment. |
| `root` | The `AST.Root` being assembled (fragment, `js`, `css`, `options`, `comments`, `metadata.ts`). |
| `meta_tags` | Tracks which `svelte:*` root-only meta tags were already used (for duplicate detection). |
| `last_auto_closed_tag` | `{ tag, reason, depth }` bookkeeping for implicitly closed elements. |

### Constructor flow

```mermaid
flowchart TD
    A["new Parser(template, loose)"] --> B{"typeof template === 'string'?"}
    B -- no --> B1["throw TypeError"]
    B -- yes --> C["this.template = template.trimEnd()"]
    C --> D["Regex-scan for <script lang='ts'><br/>→ set this.ts"]
    D --> E["Initialise AST.Root<br/>{ css: null, js: [], fragment, options: null, comments: [] }"]
    E --> F["Push root onto stack & fragments"]
    F --> G{"index < template.length"}
    G -- yes --> H["state = state(parser) || fragment"]
    H --> G
    G -- no --> I{"stack.length > 1<br/>(unclosed element/block?)"}
    I -- "yes, loose" --> I1["close current node at template.length"]
    I -- "yes, RegularElement" --> I2["error: element_unclosed"]
    I -- "yes, other" --> I3["error: block_unclosed"]
    I1 --> J{"finished in a non-fragment state?"}
    I2 --> J
    I3 --> J
    J -- yes --> J1["error: unexpected_eof"]
    J -- no --> K["Trim root.start/end to first/last node"]
    K --> L{"<svelte:options> present?"}
    L -- yes --> M["read_options(node) → Root.options<br/>disallow_children(node)<br/>attach non-enumerable __raw__"]
    L -- no --> N["return root"]
    M --> N
```

Highlights:

- **`ts` detection** happens *before* parsing: the `regex_lang_attribute` regex matches `<script ... lang="ts">` attributes and sets `parser.ts`, which is embedded into `Root.metadata.ts` for later phases (the [compiler-transformer](compiler-transformer.md) reuses this when emitting JS).
- **Root boundary trimming**: whitespace around the component is excluded from `Root.start/end`, which matters for sourcemap fidelity.
- **Options extraction**: `<svelte:options>` is spliced out of the top-level fragment, validated by `read_options` (see [compiler-parser_options-reading](compiler-parser_options-reading.md)), and validated as child-free via `disallow_children` (a shared analyzer helper). The raw node is retained as a hidden `__raw__` property for the legacy AST format.

### Lexer primitives

These methods are the vocabulary used by all state functions:

| Method | Description |
|---|---|
| `match(str)` | `true` if `str` starts exactly at `index` (special-cased 1-char fast path). |
| `eat(str, required?, required_in_loose?)` | If `match`, advance past `str` and return `true`. When `required` and not in loose mode (or `required_in_loose`), throw `expected_token`; otherwise return `false`. |
| `match_regex(pattern)` / `read(pattern)` | Anchor a `^`-anchored regex at `index`; `read` also advances. |
| `read_until(pattern)` | Consume (and return) all characters up to the next match of `pattern`; errors with `unexpected_eof` at end of input (returns `''` in loose mode). |
| `read_identifier(allow_reserved?)` | Unicode-aware identifier scanner (surrogate-pair safe) built on Acorn's `isIdentifierStart/Char`; rejects reserved words via `is_reserved`. |
| `allow_whitespace()` / `require_whitespace()` | Skip whitespace; the required variant throws `expected_whitespace` when none is present. |
| `acorn_error(err)` | Converts an Acorn position error into a Svelte `js_parse_error`, stripping Acorn's ` (line:col)` suffix in favour of the internal locator. |

### Stack & fragment management

- `push`/`pop` — elements with children are pushed onto `stack` with their fragment pushed onto `fragments`; closing tags pop both.
- `append(node)` — attaches a node to the **innermost** fragment (`this.fragments.at(-1).nodes`) and returns it, allowing fluent state-function returns.
- `current()` — peeks the open node; used by `element` to match closing tags, implement auto-closing, and enforce `svelte:*` placement rules.

---

## Parsing State Machine

The parse loop is tiny — all complexity lives in the states:

```javascript
let state = fragment;
while (this.index < this.template.length) {
    state = state(this) || fragment;
}
```

```mermaid
stateDiagram-v2
    [*] --> fragment

    fragment --> element : matches '<'
    fragment --> tag : matches '{'
    fragment --> text : otherwise

    text --> fragment : consumed until '<' or '{'<br/>(HTML entities decoded)

    element --> fragment : Comment node
    element --> element : read attributes<br/>(read_attribute / read_static_attribute)
    element --> fragment : self-closing / void / loose-unclosed
    element --> fragment : textarea / script / style<br/>(raw-text special cases)
    element --> fragment : closing tag matches stack
    element --> element : implicit close<br/>(e.g. <li> closes <li>)

    tag --> fragment : expression / block tags<br/>({#if}, {:else}, {/if}, {@html}, …)

    note right of element
        Unclosed element at EOF:
        • loose mode  → close silently
        • strict mode → element_unclosed / block_unclosed
    end note
```

The `element` state (implemented in [compiler-parser_parsing-states](compiler-parser_parsing-states.md)) is the largest state and handles:

- **Comments** (`<!-- … -->`) and closing tags, matching against `parser.stack`.
- **Implicit closing** of HTML elements with omitted end tags, emitting `element_implicitly_closed` warnings and recording `last_auto_closed_tag` so that an *explicit* close of an already auto-closed element becomes an error.
- **Tag classification**: `svelte:*` meta tags (validated against the known set), components (capitalised names, or `.`-suffixed partial names in loose mode), `TitleElement`, `SlotElement`, `RegularElement`.
- **Duplicate attribute detection** (normalising `bind:x` to `Attribute` so `bind:x` + `x` collide, while `class:x`/`style:x` may coexist).
- **`<svelte:element/‌svelte:component>` `this=`** extraction into the element's `expression`/`tag` field.
- **Top-level `<script>`/`<style>`** — raw-text reading, leading-comment capture (used later for `<!-- svelte-ignore … -->` warning suppression), duplicate detection, and delegation to `read_script`/`read_style`, which call the Acorn-based parser in [compiler-parser_js-ts-parsing](compiler-parser_js-ts-parsing.md).
- **Loose-mode backtracking** — e.g. undoing a next element's `<` that was misparsed as an attribute named `<`, or rewinding over a partial `{#`/`{/`/`{:` block opening.

---

## Data Flow

```mermaid
flowchart LR
    SRC["Svelte source<br/>(string)"] --> P["parse()"]
    P --> L["state.set_source<br/>→ line/col locator"]
    P --> SM["Parser state machine"]
    SM --> F["Root.fragment nodes:<br/>Text · RegularElement · Component<br/>IfBlock · EachBlock · HtmlTag …"]
    SM --> JS["Root.instance / Root.module<br/>(Script nodes, via Acorn)"]
    SM --> CSS["Root.css<br/>(Style node)"]
    SM --> OPT["Root.options<br/>(SvelteOptions)"]
    SM --> CMT["Root.comments<br/>+ leadingComments on scripts"]
    F --> A2["Phase 2: analyse<br/>(compiler-analyzer)"]
    JS --> A2
    CSS --> A2
    OPT --> A2
    A2 --> T3["Phase 3: transform<br/>(compiler-transformer:<br/>client / server / css)"]

    style SRC fill:#e9f7ef,stroke:#2f9e44
    style A2 fill:#fff4e6,stroke:#e8590c
    style T3 fill:#fff4e6,stroke:#e8590c
```

The parse result intentionally keeps JS and CSS as *raw text nodes with metadata* (start offsets, attributes) — no deep parsing happens here beyond locating boundaries. Full JS parsing via Acorn (with optional TypeScript support) is owned by [compiler-parser_js-ts-parsing](compiler-parser_js-ts-parsing.md), and entity decoding / fuzzymatching helpers live in [compiler-parser_parsing-utilities](compiler-parser_parsing-utilities.md).

---

## Error Handling & Loose Mode

### Strict mode (default)

Violations raise `CompileError`s through the centralised catalogue in [compiler-core_diagnostics](compiler-core_diagnostics.md) (message codes, e.g. `block_unclosed`, `unexpected_eof`, `expected_token`, `js_parse_error`, `tag_invalid_name`, `svelte_meta_*`). Because `parse()` called `state.set_source`, every error carries precise line/column info and a code frame via `get_code_frame`.

Notable strict-mode rules enforced during (or immediately around) parsing:

- **Unclosed constructs** — `element_unclosed` / `block_unclosed` when `stack.length > 1` at EOF; `unexpected_eof` if parsing terminated mid-token.
- **Invalid closing tags** — mismatched or re-closing an auto-closed tag.
- **Meta-tag placement** — root-only tags (`svelte:head`, `svelte:window`, …) must sit at the root and appear once.
- **`svelte:options`** — must be childless; attributes validated by `read_options`.

### Loose mode (`loose = true`)

Used by language tools (`svelte-language-tools`) to parse *work in progress*. Behaviours:

| Situation | Strict behaviour | Loose behaviour |
|---|---|---|
| Unclosed element/block at EOF | Throw | Set `end = template.length`, continue |
| EOF inside `read_until` | `unexpected_eof` | Return `''` |
| Tag name like `div.` (mid-typing) | `tag_invalid_name` | Treated as a `Component` |
| Missing `>` after tag | `expected_token` | Backtrack / absorb whitespace so tooling sees full context |
| `<` of next element misparsed as attribute | — | Rewind `parser.index` and drop the bogus attribute |
| Partial block opener `{#`/`{/`/`{:` swallowed | — | Rewind up to 2 characters |
| `eat(..., required)` | Throws | Only throws when `required_in_loose` is set |

Loose mode never produces "successful" output guarantees — the goal is a *best-effort AST* plus diagnostics, keeping IDEs responsive.

---

## Component Interaction (sequence)

```mermaid
sequenceDiagram
    autonumber
    participant C as compile() (public API)
    participant P as parse()
    participant S as compiler state (locator)
    participant PC as new Parser()
    participant ST as state fns (fragment/element/text/tag)
    participant RO as read_options()
    participant AN as Phase 2 analyse

    C->>P: parse(source, loose)
    P->>S: set_source(source)
    P->>PC: construct(template, loose)
    activate PC
    PC->>PC: detect lang="ts" → this.ts
    PC->>PC: init Root + stacks
    loop until EOF
        PC->>ST: state(parser)
        ST-->>PC: next state | void
        ST->>PC: append(node) / push / pop
    end
    alt <svelte:options> found
        PC->>RO: read_options(raw node)
        RO-->>PC: validated SvelteOptions
    end
    PC-->>P: root (AST.Root)
    deactivate PC
    P-->>C: AST.Root
    C->>AN: analyse(component, root)
```

---

## Dependencies

### Internal (upstream)

| Dependency | Module | Usage |
|---|---|---|
| `fragment`, `element`, `text`, `tag` states | [compiler-parser_parsing-states](compiler-parser_parsing-states.md) | The state-machine implementation |
| `read_options` | [compiler-parser_options-reading](compiler-parser_options-reading.md) | `<svelte:options>` validation |
| `create_fragment` | [compiler-parser_parsing-utilities](compiler-parser_parsing-utilities.md) | Fragment factory used for root and element children |
| `get_entity_pattern` (indirectly, via text state) | [compiler-parser_parsing-utilities](compiler-parser_parsing-utilities.md) | HTML entity decoding in `Text` nodes |
| `parse` (acorn wrapper) & `remove_this_param` | [compiler-parser_js-ts-parsing](compiler-parser_js-ts-parsing.md) | JS/TS `<script>` contents (invoked from `read_script`) |
| `errors.js` (`e.*`), `warnings.js` (`w.*`) | [compiler-core_diagnostics](compiler-core_diagnostics.md) | All diagnostics raised during parsing |
| `state.js` (`set_source`) | [compiler-core_compile_state](compiler-core_compile_state.md) | Source registration & position locator shared with diagnostics |
| AST types (`AST.Root`, `Fragment`, `TemplateNode`, …) | [compiler-core_type_definitions](compiler-core_type_definitions.md) | Node contracts produced by the parser |

### Internal (downstream consumers)

| Consumer | Module | Relationship |
|---|---|---|
| `compile` / `compileModule` | [compiler-core_public_api](compiler-core_public_api.md) | Invoke `parse` as step 1 of compilation |
| `analyse_component` | [compiler-analyzer](compiler-analyzer.md) | Walks the produced AST, building scopes & diagnostics |
| Client/server/CSS transforms | [compiler-transformer](compiler-transformer.md) | Consume the analyzer's output, which originates here |

### External

| Package | Usage |
|---|---|
| `acorn` | `isIdentifierStart` / `isIdentifierChar` for Unicode-correct identifier scanning in markup (full JS parsing lives in [compiler-parser_js-ts-parsing](compiler-parser_js-ts-parsing.md)) |

```mermaid
flowchart TD
    CORE["compiler-core<br/>(state · diagnostics · types · builders)"] --> PARSER_CORE
    STATES["parsing-states"] --> PARSER_CORE
    OPTS["options-reading"] --> PARSER_CORE
    UTIL["parsing-utilities"] --> PARSER_CORE
    JSTS["js-ts-parsing"] --> PARSER_CORE
    PARSER_CORE --> PUB["compiler-core_public_api<br/>(compile / compileModule)"]
    PARSER_CORE --> ANALYZER["compiler-analyzer"]
    ACORN_EXT["acorn (external)"] --> PARSER_CORE

    style PARSER_CORE fill:#e8f4f8,stroke:#0b7285
```

---

## Extension Notes for Maintainers

- **Adding a new state** (e.g. a new block type): implement it as a `(parser) => ParserState | void` function in [compiler-parser_parsing-states](compiler-parser_parsing-states.md) and route to it from `fragment`/`tag`. Prefer using the existing lexer primitives over raw index arithmetic so loose-mode semantics stay consistent.
- **New diagnostics**: add the message to the templates in the [message code generation templates](message_code_generation_templates.md) (generated into `errors.js`/`warnings.js`), then raise it with bounds for precise highlighting.
- **Loose-mode invariants**: any new strict error should consider what loose mode does — IDEs rely on the parser never throwing for incomplete-but-plausible input. Backtracking must restore `parser.index` exactly, as done in the attribute/`{#` recovery paths.
- **Performance**: `match` special-cases single characters; `read`/`match_regex` require `^`-anchored patterns to avoid unbounded scans. Keep hot loops allocation-free where possible.
- **Legacy compatibility**: `Root.options.__raw__` is non-enumerable on purpose — it exists solely so the legacy AST converter (see [compiler-core_public_api](compiler-core_public_api.md)) can reconstruct the old format; don't serialise it.

---

## See Also

- [compiler-parser](compiler-parser.md) — parent module grouping all Phase 1 parsing concerns
- [compiler-parser_parsing-states](compiler-parser_parsing-states.md) — `fragment`, `element`, `text`, `tag` implementations
- [compiler-parser_js-ts-parsing](compiler-parser_js-ts-parsing.md) — Acorn/TypeScript script parsing
- [compiler-parser_options-reading](compiler-parser_options-reading.md) — `<svelte:options>` handling
- [compiler-parser_parsing-utilities](compiler-parser_parsing-utilities.md) — fuzzymatch, HTML entities, fragment factory
- [compiler-analyzer](compiler-analyzer.md) — Phase 2, the direct consumer of the AST
- [compiler-transformer](compiler-transformer.md) — Phase 3, code generation for client/server/CSS
- [compiler-core_diagnostics](compiler-core_diagnostics.md) — error/warning infrastructure used throughout parsing
