# ssr_benchmarks Module

> **Location:** `benchmarking/benchmarks/ssr/` · **Parent:** [Engineering_Tooling_(Benchmarks,_Verification___Playground)](Engineering_Tooling_(Benchmarks,_Verification___Playground).md)

## Introduction

The `ssr_benchmarks` module houses the **server-side rendering (SSR) performance benchmarks** for the Svelte framework. Its purpose is to quantitatively measure how fast the server rendering pipeline — compilation with `generate: 'server'` followed by repeated `render()` invocations — executes end-to-end, reporting wall-clock time and garbage-collection time per benchmark.

Currently the module contains a single benchmark, **`wrapper_bench`**, which exercises the full SSR path: it compiles a Svelte component (`App.svelte`) into a server module, imports the generated code, and times hundreds of server render calls under a statistically controlled harness (JIT warm-up + fastest-of-N rounds + explicit GC tracking).

This module is intentionally small and declarative: each benchmark is an `async` function returning a `{ benchmark, time, gc_time }` record, which the shared harness aggregates and reports.

---

## Module Overview

| Aspect | Detail |
|---|---|
| **Core component** | `benchmarking/benchmarks/ssr/wrapper/wrapper_bench.js::wrapper_bench` |
| **Suite registry** | `benchmarking/benchmarks/ssr/index.js` exports `ssr_benchmarks = [wrapper_bench]` |
| **Measured surface** | `render()` from `svelte/server` (server runtime render pipeline) |
| **Upstream code generation** | `compile()` from `svelte/compiler` with `generate: 'server'` |
| **Harness utilities** | `fastest_test`, `read_file`, `write` from `benchmarking/utils.js` |
| **Entry point** | Invoked by `benchmarking/run.js` as the `"server-side rendering benchmarks"` suite |
| **Artifacts** | Writes compiled output to `benchmarking/benchmarks/ssr/wrapper/output/App.js` |

---

## Architecture

The module sits at the intersection of three systems: the **compiler** (produces the renderable server component), the **server runtime** (executes rendering), and the **benchmark harness** (controls timing and measurement noise).

```mermaid
graph TD
    subgraph Runner["benchmarking/run.js (suite orchestrator)"]
        RUN["run.js<br/>suites: reactivity + ssr"]
    end

    subgraph SSR["ssr_benchmarks (this module)"]
        IDX["benchmarks/ssr/index.js<br/>ssr_benchmarks = [wrapper_bench]"]
        WB["wrapper_bench.js::wrapper_bench"]
        CS["wrapper_bench.js::compile_svelte<br/>(internal helper)"]
        IDX --> WB
        WB --> CS
    end

    subgraph Harness["Shared Benchmark Harness (parent module)"]
        FT["utils.js::fastest_test"]
        RT["utils.js::run_tracked<br/>+ GarbageTrack"]
        IO["utils.js::read_file / write"]
        FT --> RT
    end

    subgraph Compiler["Compiler Pipeline (generated module)"]
        CMP["svelte/compiler::compile<br/>generate: 'server'"]
    end

    subgraph Server["Server-Side Rendering (generated module)"]
        RND["svelte/server::render<br/>Payload → head/html/body"]
    end

    RUN -->|"imports ssr_benchmarks"| IDX
    RUN -->|"invokes each benchmark()"| WB
    CS -->|"read_file(App.svelte)"| IO
    CS -->|"compile(source, opts)"| CMP
    CS -->|"write(output/App.js)"| IO
    CS -->|"dynamic import()"| RND
    WB -->|"fastest_test(10, 100×render)"| FT
    FT -.->|"collectGarbage + gc_time"| RT
    CMP -.->|"emits server component"| RND
```

**Key relationships:**

- `ssr_benchmarks` depends on the **Compiler Pipeline** to produce server-target code at benchmark runtime (not at build time), keeping benchmarks synchronized with the current compiler behavior.
- It depends on the **Server-Side Rendering runtime** (`render`) — the actual code under measurement.
- It reuses the harness utilities defined for the whole Engineering Tooling module rather than duplicating timing logic; the same `fastest_test` harness is shared with the [reactivity_benchmarks](reactivity_benchmarks.md) suite.

---

## Core Component: `wrapper_bench`

`benchmarking/benchmarks/ssr/wrapper/wrapper_bench.js` exposes a single async entry point:

```javascript
export async function wrapper_bench() {
    const App = await compile_svelte();      // 1. compile + import server component
    for (let i = 0; i < 3; i++) render(App); // 2. JIT warm-up (3 passes)

    const { timing } = await fastest_test(10, () => { // 3. 10 measured rounds
        for (let i = 0; i < 100; i++) render(App);    //    100 renders each
    });

    return { benchmark: 'wrapper_bench',
             time: timing.time.toFixed(2),
             gc_time: timing.gc_time.toFixed(2) };
}
```

### Behavior breakdown

1. **`compile_svelte()` (private helper)**
   - Reads `benchmarking/benchmarks/ssr/wrapper/App.svelte` via `read_file` (normalizing CRLF → LF).
   - Calls `compile(source, { generate: 'server' })`, producing the server-rendering JS variant of the component.
   - Persists the generated code to `output/App.js` (`write` creates parent directories as needed) so the emitted artifact can be inspected or reused for debugging.
   - Dynamically `import()`s the written module and returns its **default export** — the server component function that `render()` consumes.

2. **JIT warm-up** — three un-timed `render(App)` passes let V8 inline hot paths (template cloning, attribute serialization, payload assembly) before measurement, matching the convention used by `sbench` benchmarks.

3. **Measurement** — delegates to the shared `fastest_test(10, fn)` harness: 10 rounds, each round rendering the component 100 times. Only the **fastest round** is reported, mitigating scheduler noise, GC pauses, and OS interference.

4. **Result record** — returns `{ benchmark, time, gc_time }` (fixed to 2 decimals, in milliseconds). `run.js` accumulates these into suite and grand totals; the comparison tooling serializes them to JSON per branch.

> **Note on the fixture:** `App.svelte` and `output/` are **not checked in** as static artifacts of the benchmark setup — `App.svelte` is the benchmark fixture consumed at runtime and `output/App.js` is generated on every run. Keeping compilation inside the benchmark also makes *compile-then-render* cost visible when iterating on compiler changes.

---

## Benchmark Execution Flow

```mermaid
sequenceDiagram
    autonumber
    participant R as run.js
    participant WB as wrapper_bench
    participant C as svelte/compiler (compile)
    participant FS as utils (read_file/write)
    participant M as output/App.js (ESM)
    participant SR as svelte/server (render)
    participant H as fastest_test / run_tracked

    R->>WB: await wrapper_bench()
    WB->>FS: read_file(App.svelte)
    FS-->>WB: source string
    WB->>C: compile(source, { generate: 'server' })
    C-->>WB: { js: { code } }
    WB->>FS: write(output/App.js, code)
    WB->>M: await import(output/App.js)
    M-->>WB: default → server component
    rect rgb(235, 245, 255)
        note over WB,SR: JIT warm-up — 3 × render(App), un-timed
        WB->>SR: render(App) ×3
    end
    WB->>H: fastest_test(10, fn)
    loop each of 10 rounds (only fastest reported)
        H->>H: v8.collectGarbage() + start GarbageTrack
        loop 100 ×
            H->>SR: render(App) → { head, html, body }
        end
        H->>H: stop timer, await gcDuration()
    end
    H-->>WB: { timing: { time, gc_time } } (min round)
    WB-->>R: { benchmark, time, gc_time }
    R->>R: accumulate suite_time / total_time, print
```

---

## Data Flow

```mermaid
flowchart LR
    A["App.svelte<br/>(fixture source)"] -->|"read_file (LF-normalized)"| B["source string"]
    B -->|"compile({generate:'server'})"| C["output/App.js<br/>(server ESM module)"]
    C -->|"dynamic import"| D["default export:<br/>server component fn"]
    D -->|"render(App) ×300 measured<br/>+ ×3 warm-up"| E["RenderOutput<br/>{ head, html, body }"]
    E --> F["timings per round"]
    F -->|"min over 10 rounds"| G["{ time, gc_time }"]
    G --> H["run.js totals & console report"]
    G --> I["compare/.results/&lt;branch&gt;.json<br/>(branch-to-branch comparison)"]
```

**Artifacts produced by the module:**

| Path | Nature | Lifetime |
|---|---|---|
| `benchmarking/benchmarks/ssr/wrapper/output/App.js` | Compiled server-target component | Regenerated on every benchmark run (build artifact; safe to delete) |
| `benchmarking/compare/.results/<branch>.json` | Serialized benchmark results per git branch | Written by the comparison runner, consumed for cross-branch regression analysis |

---

## Timing Methodology

The measurement quality comes from the shared harness (documented alongside its consumers in the parent module):

- **`run_tracked`** — forces a full `v8.collectGarbage()` before each timed round, wraps execution in a `GarbageTrack` instance, and awaits `gcDuration()` after the run. This separates *useful work time* (`time`) from *collector time* (`gc_time`), so GC pauses don't masquerade as SSR cost.
- **`fastest_test`** — executes the timed function `times` (here 10) rounds and reduces to the round with the smallest `timing.time`. Combined with the 3-pass warm-up, this produces stable, comparable numbers across runs and branches.
- **Workload sizing** — 100 renders per round amortizes per-render timer overhead; 10 rounds give the harness enough samples to filter outliers.

The identical protocol is used by the reactivity suites (`mol_bench`, `sbench`, kairo suites), which keeps client and server numbers directly comparable in the aggregated report.

---

## Integration with the Engineering Tooling Ecosystem

```mermaid
graph TD
    subgraph ET[Engineering Tooling]
        SB[ssr_benchmarks<br/>ssr/wrapper/wrapper_bench]
        RB[reactivity_benchmarks]
        CMP[benchmark_comparison<br/>compare/index.js + runner.js]
        RUNNER[run.js aggregator]
    end
    RUNNER -->|"suite: 'server-side rendering<br/>benchmarks'"| SB
    RUNNER -->|"suite: 'reactivity benchmarks'"| RB
    CMP -->|"fork(runner.js) per git branch<br/>→ .results/&lt;branch&gt;.json"| RUNNER
```

- **`benchmarking/benchmarks/ssr/index.js`** — the module's public surface; exports the `ssr_benchmarks` array. New SSR benchmarks are added here and are automatically picked up by the runner.
- **`benchmarking/run.js`** — imports the registry alongside `reactivity_benchmarks`, prints per-benchmark and per-suite `{ time, gc_time }` summaries, and exits non-zero on failure. Notably, it wraps execution in the client reactivity engine's root push/pop (`$.push({}, true)` / `$.pop()`), which makes `render()`-based server benchmarks safe to run in the same process as client-side suites.
- **`benchmarking/compare/`** — checks out each requested branch (defaulting current branch vs `main`), forks the runner in each, and writes results to `.results/<branch>.json` for table-based regression comparison. Because compilation happens *inside* the benchmark, compiler regressions on either branch surface directly in `wrapper_bench` numbers.

---

## Dependencies on Other Modules

| Dependency | Import | Used for | Documentation |
|---|---|---|---|
| Compiler (component) | `svelte/compiler → compile` | Server-target code generation of `App.svelte` (`generate: 'server'`), including options validation, parse, analyze, and server transform phases | [Compiler_Pipeline___Language_Toolchain](Compiler_Pipeline___Language_Toolchain.md) |
| Server runtime | `svelte/server → render` | The measured workload: builds a `Payload`, invokes the component with props, assembles `head` (incl. inlined `<style>` blocks) and `html`/`body` output, runs `on_destroy` cleanups, and aborts pending signals | [Server-Side_Rendering___Cross-Target_Runtime_Services](Server-Side_Rendering___Cross-Target_Runtime_Services.md) |
| Shared harness | `benchmarking/utils.js → fastest_test, read_file, write` | GC-aware timing rounds, fixture IO, artifact writing (shared with reactivity suites) | [Engineering_Tooling_(Benchmarks,_Verification___Playground)](Engineering_Tooling_(Benchmarks,_Verification___Playground).md) |

The module does **not** depend on the [Client_Runtime_Engine_(Reactivity___DOM_Rendering)](Client_Runtime_Engine_(Reactivity___DOM_Rendering).md) directly; SSR components compiled with `generate: 'server'` avoid the client signal/DOM machinery, which is precisely what makes `wrapper_bench` a *pure server-pipeline* measurement.

---

## Extending the Module

To add a new SSR benchmark:

1. Create `benchmarking/benchmarks/ssr/<name>/<name>_bench.js` exporting an async benchmark function that follows the shared convention:

   ```javascript
   export async function my_ssr_bench() {
       // optional: compile fixture via compile(source, { generate: 'server' })
       for (let i = 0; i < 3; i++) render(App);        // JIT warm-up
       const { timing } = await fastest_test(10, () => { /* workload */ });
       return { benchmark: 'my_ssr_bench',
                time: timing.time.toFixed(2),
                gc_time: timing.gc_time.toFixed(2) };
   }
   ```

2. Register it in `benchmarking/benchmarks/ssr/index.js` (`ssr_benchmarks.push(...)` or extend the literal array). The runner and comparison tooling require no further changes.
3. Keep the returned shape `{ benchmark, time, gc_time }` intact — `run.js` and `benchmark_comparison` both parse these keys numerically.

**Guidelines:** avoid global mutable state between benchmarks, keep fixtures self-contained per directory, and prefer amortized loops (100+ iterations) inside a single timed round so timer overhead stays negligible relative to workload.

---

## See Also

- [reactivity_benchmarks](reactivity_benchmarks.md) — sibling suite sharing `fastest_test`/`run_tracked` and the same reporting contract.
- [benchmark_comparison](benchmark_comparison.md) — branch-to-branch regression tooling that executes this suite via `runner.js`.
- [Compiler_Pipeline___Language_Toolchain](Compiler_Pipeline___Language_Toolchain.md) — `compile()` phases invoked by `compile_svelte()`.
- [Server-Side_Rendering___Cross-Target_Runtime_Services](Server-Side_Rendering___Cross-Target_Runtime_Services.md) — the `render()` render pipeline under measurement.
