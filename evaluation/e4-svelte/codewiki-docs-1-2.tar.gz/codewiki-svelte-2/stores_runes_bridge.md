# stores_runes_bridge

> **Module tree position:** `Public_API___Built-in_Feature_Surface` → `stores` → `stores_runes_bridge`

## 1. Introduction

`stores_runes_bridge` is the **bidirectional interop layer between the legacy Svelte store contract and the Svelte 5 runes (signal-based) reactivity system**. It lives in two environment-specific entry files:

| File | Exports | Environment |
|---|---|---|
| `packages/svelte/src/store/index-client.js` | `toStore`, `fromStore` (plus re-exports of `derived`, `get`, `readable`, `readonly`, `writable`) | Browser / hydrated client |
| `packages/svelte/src/store/index-server.js` | `toStore`, `fromStore` (plus the same re-exports) | Server / SSR |

The two bridging functions solve one problem in each direction:

- **`toStore(get, set?)`** — *runes → store*. Wraps a getter function (typically one reading `$state`) into a `Readable`/`Writable` store so it can be consumed by store-aware APIs (e.g. legacy components, `$store` auto-subscription, third-party libraries expecting the store contract).
- **`fromStore(store)`** — *store → runes*. Wraps a store into a plain object exposing a **reactive `current` property** that can be read inside templates, `$derived`, and `$effect`, so legacy stores can be used seamlessly in runes-mode components.

Both functions are polymorphic: `toStore` returns a `Writable` when a `set` function is provided and a `Readable` otherwise; `fromStore` returns an object with a *settable* `current` for `Writable` stores and a *readonly* `current` for `Readable` stores.

---

## 2. Architecture

The module is a thin, environment-partitioned facade. All shared store mechanics are delegated to `stores_core` (`get`, `writable`), and all client-side reactive plumbing is delegated to the client reactivity engine (`effect_root`, `render_effect`, `effect_tracking`, `active_effect`/`active_reaction`) and `createSubscriber`.

```mermaid
graph TD
    subgraph "stores_runes_bridge"
        IC["index-client.js<br/>(toStore, fromStore)"]
        IS["index-server.js<br/>(toStore, fromStore)"]
    end

    subgraph "stores_core (shared)"
        G["get()"]
        W["writable()"]
    end

    subgraph "client reactivity engine"
        EF["effects.js<br/>effect_root / render_effect / effect_tracking"]
        RT["runtime.js<br/>active_effect / active_reaction<br/>set_active_effect / set_active_reaction"]
        CS["create-subscriber.js<br/>createSubscriber"]
    end

    subgraph "stores_contract (types)"
        T["Readable / Writable interfaces"]
    end

    IC -- "re-exports + uses" --> G
    IC -- "creates backing store" --> W
    IC -- "captures/restores context,<br/>tracks getter" --> EF
    IC -- "reads active effect/reaction" --> RT
    IC -- "lazy ref-counted store subscription" --> CS
    IS -- "re-exports + uses" --> G
    IS -- "creates backing store" --> W
    IC -. "implements" .-> T
    IS -. "implements" .-> T
```

**Key design point:** the public API signature of both files is identical, so bundlers can swap implementations per target (`svelte` package exports map), while the *semantics* differ: the client version participates in the signal graph; the server version is pull-based and reactive-free.

---

## 3. API Reference

### 3.1 `toStore(get, set?)`

```ts
// Overload 1 — writable
function toStore<V>(get: () => V, set: (v: V) => void): Writable<V>;
// Overload 2 — readable
function toStore<V>(get: () => V): Readable<V>;
```

Creates a store whose value is produced by `get` and (optionally) written back through `set`.

```js
import { toStore } from 'svelte/store';

let count = $state(0);
const store = toStore(() => count, (v) => (count = v));
```

### 3.2 `fromStore(store)`

```ts
// Overload 1 — writable store → settable current
function fromStore<V>(store: Writable<V>): { current: V };
// Overload 2 — readable store → readonly current
function fromStore<V>(store: Readable<V>): { readonly current: V };
```

Converts a store into an object with a reactive `current` property:

```js
import { fromStore, get, writable } from 'svelte/store';

const store = writable(0);
const count = fromStore(store);

count.current;   // 0
store.set(1);
count.current;   // 1
count.current += 1;
get(store);      // 2
```

### 3.3 Re-exports

Both entry files also re-export the shared store toolkit — `derived`, `get`, `readable`, `readonly`, `writable` — from `stores_core`. Those are documented in [stores_core.md](stores_core.md) and their contracts in [stores_contract.md](stores_contract.md).

---

## 4. Component Behavior

### 4.1 Client `toStore` — runes-backed store

The client implementation makes the store *track* the getter through the signal graph:

1. **Context capture.** At `toStore()` call time, `active_effect` and `active_reaction` are captured. The store may be created during component initialisation, but subscriptions happen later; the captured context ensures the tracking effect belongs to the *creator's* reactive scope.
2. **Backing store.** A `writable(init_value)` is created (see [stores_core.md](stores_core.md)). Its `start` callback runs on first subscriber.
3. **Deferred tracking.** The `start` callback:
   - Reads `get()` again and sets `ran = true` if the value changed between `toStore()` and subscription (the initial push must not be skipped);
   - Swaps in the captured effect/reaction (`set_active_effect`/`set_active_reaction`), creates an `effect_root` containing a `render_effect` that calls `get()` and pushes new values to subscribers, then restores the previous context in a `finally` block;
   - Returns the `effect_root` teardown as the store's `stop` function, so the tracking effect is destroyed when the last subscriber unsubscribes.
4. **Write path.** If `set` was supplied, the returned object exposes `set` directly and `update(fn) => set(fn(get()))`; otherwise only `subscribe` is exposed.

### 4.2 Client `fromStore` — store-backed reactive object

The returned object's `current` getter behaves differently depending on whether it is read inside a reactive context:

```mermaid
flowchart TD
    A["read `count.current`"] --> B{"effect_tracking()?"}
    B -- "yes (inside $effect / $derived / template)" --> C["subscribe() via createSubscriber"]
    C --> D["store.subscribe records latest value;<br/>each emission calls update() →<br/>invalidates dependent signals"]
    D --> E["return cached `value`"]
    B -- "no (event handler, plain JS)" --> F["get(store):<br/>synchronous subscribe → capture →<br/>immediate unsubscribe (pull read)"]
    F --> G["return live value"]
```

Details:

- `createSubscriber` (see [reactive-builtins.md](reactive-builtins.md)) provides **lazy, ref-counted subscription**: the underlying `store.subscribe` only starts while at least one render effect is active, and teardown is deferred to a microtask to avoid resubscription churn. A `version` source signal guarantees downstream deriveds are dirtied correctly when the subscription restarts.
- **Writable detection:** `'set' in store` selects whether `current` also gets a setter that delegates to `store.set(v)`. `Readable` stores get a getter-only property (assignment silently throws in strict mode / class contexts).

### 4.3 Server variants (SSR)

Because there is no signal graph at render time, the server implementations are deliberately trivial:

- `toStore` creates `writable(get())` once — no effect tracking, no teardown.
- `fromStore`'s `current` getter is simply `get(store)` (a subscribe-once pull read) plus a delegating setter for `Writable` stores.

### 4.4 Client vs Server comparison

| Aspect | Client (`index-client.js`) | Server (`index-server.js`) |
|---|---|---|
| `toStore` reactivity | Tracks `get()` via `effect_root` + `render_effect`; pushes updates on change | Static: initial value only, no updates |
| `toStore` edge case | Detects value change before first subscribe (`ran` flag) | Not applicable |
| `toStore` lifecycle | Teardown returned to `writable`'s `stop`; runs on last unsubscribe | None |
| `fromStore.current` (read) | Reactive when tracked (push), `get(store)` fallback when untracked (pull) | Always `get(store)` (pull) |
| `fromStore.current` (write) | Delegates to `store.set` for `Writable` | Same |
| Dependencies | effects.js, runtime.js, create-subscriber.js | `shared/index.js` only |

---

## 5. Data Flow

### 5.1 `fromStore` reactive read + store write (client)

```mermaid
sequenceDiagram
    participant C as Component ($effect / template)
    participant F as fromStore object
    participant S as createSubscriber
    participant ST as Store (writable)
    participant R as Signal graph

    C->>F: read `current`
    F->>F: effect_tracking() === true
    F->>S: subscribe()
    S->>ST: store.subscribe(cb)
    ST-->>S: cb(value) → cache value
    Note over F,C: getter returns cached value;<br/>read is registered as a dependency
    C->>ST: store.set(newValue)
    ST-->>S: cb(newValue) → cache + update()
    S->>R: increment version source
    R-->>C: effect/derived invalidated → re-reads `current`
    Note over S,ST: when no readers remain,<br/>unsubscribe happens after a microtask
```

### 5.2 `toStore` subscription lifecycle (client)

```mermaid
sequenceDiagram
    participant U as User code
    participant TS as toStore store
    participant W as writable (stores_core)
    participant EF as effect_root / render_effect

    U->>TS: toStore(get, set)
    Note over TS: captures active_effect / active_reaction
    U->>TS: subscribe(cb)  (first subscriber)
    TS->>W: writable.start(set)
    W->>TS: start(set, update)
    TS->>EF: set_active_effect/reaction(captured)
    TS->>EF: effect_root(() => render_effect(get → set))
    TS->>TS: restore previous effect/reaction
    EF-->>W: pushes new values on getter change
    U->>TS: unsubscribe (last)
    TS->>EF: teardown = destroy tracking effect
```

---

## 6. Dependencies & Related Modules

| Dependency | Consumed symbols | Owning module (doc) |
|---|---|---|
| `src/store/shared/index.js` | `get`, `writable` | [stores_core.md](stores_core.md) |
| `src/store/public.js` / `private.d.ts` | `Readable`, `Writable` types | [stores_contract.md](stores_contract.md) |
| `src/internal/client/reactivity/effects.js` | `effect_root`, `render_effect`, `effect_tracking` | [client-reactivity-engine_effects.md](client-reactivity-engine_effects.md) |
| `src/internal/client/runtime.js` | `active_effect`, `active_reaction`, `set_active_effect`, `set_active_reaction` | [client-reactivity-engine_signal-graph.md](client-reactivity-engine_signal-graph.md) |
| `src/reactivity/create-subscriber.js` | `createSubscriber` | [reactive-builtins.md](reactive-builtins.md) |
| `src/internal/shared/utils.js` | `noop` (default `start`) | [internal-shared-utils_core-utilities.md](internal-shared-utils_core-utilities.md) |

Sibling module note: [stores_bridge.md](stores_bridge.md) documents the same two entry files from the perspective of the overall store entry points (`svelte/store` public surface); this document focuses specifically on the runes-interop functions `fromStore` / `toStore`. The store contract itself is specified in [stores_contract.md](stores_contract.md).

Upstream/downstream relationships inside the Svelte package:

- **Consumed by:** runes-mode user components migrating legacy stores; the compiler's client transform emits `$.store_get`-style helpers rather than these APIs, so this module serves the *public* interop path only.
- **Depends on the compiler pipeline** only indirectly: stores referenced with the `$` prefix in templates are lowered by the compiler to runtime helpers (see [Compiler_Pipeline___Language_Toolchain.md](Compiler_Pipeline___Language_Toolchain.md)); `fromStore`/`toStore` complement those helpers for explicit, hand-written interop.

---

## 7. Design Notes & Edge Cases

1. **Late-change guard (`ran` flag).** In client `toStore`, the initial value passed to `writable` may already be stale by the time the first subscriber attaches (e.g. `$state` mutated between creation and subscription). The start callback re-reads `get()` and, if it differs, treats the *next* render-effect run as the first real push.
2. **Context restoration.** `set_active_effect`/`set_active_reaction` are always paired in `try/finally`, so creating a store inside an unrelated reactive scope never leaks ownership of the tracking effect.
3. **Root-effect teardown = store stop.** The teardown returned by `effect_root` doubles as the writable's `stop`; this guarantees the tracking effect is destroyed exactly when subscriber count drops to zero (see `writable` in [stores_core.md](stores_core.md)).
4. **Microtask-deferred unsubscribe.** `createSubscriber` decrements its reader count inside `queue_micro_task`; without this, a render effect that re-runs in the same tick would tear down and immediately re-subscribe, leaking the old subscription.
5. **Version bump on restart.** When the subscription stops, the `version` source in `createSubscriber` is incremented so dependent deriveds compare write versions correctly and re-run when the subscription is picked up again.
6. **Dual-overload type safety.** Both functions use JSDoc `@overload` annotations so TypeScript users get `Writable<V>` vs `Readable<V>` and settable vs readonly `current` based on the arguments/store shape — no runtime type checks beyond the `'set' in store` property test.
7. **Tree-shakeability.** The server entry avoids all client-runtime imports, keeping SSR bundles free of the reactivity engine (see [treeshakeability_checker.md](treeshakeability_checker.md) for how this is verified).
```
