# Client Reactivity Engine — Foundation

> **Module:** `client-reactivity-engine_foundation`
> **Parent:** [client-reactivity-engine](client-reactivity-engine.md) (part of [Client Runtime Engine — Reactivity & DOM Rendering](Client_Runtime_Engine_(Reactivity___DOM_Rendering).md))
> **Source files:**
> - `packages/svelte/src/internal/flags/index.js`
> - `packages/svelte/src/internal/client/reactivity/equality.js`

---

## 1. Introduction

The **foundation** module provides the two lowest-level primitives of Svelte 5's client-side reactivity engine:

1. **Runtime mode flags** (`internal/flags/index.js`) — module-scoped, one-way boolean latches (`async_mode_flag`, `legacy_mode_flag`, `tracing_mode_flag`) that select which behavioral "mode" the entire runtime operates in.
2. **Equality semantics** (`internal/client/reactivity/equality.js`) — the comparison predicates that decide whether a written value is *actually new*, and therefore whether a change propagates through the signal graph at all.

Both are deliberately tiny, dependency-free leaf modules. Every other reactivity subsystem — the [signal graph](client-reactivity-engine_signal-graph.md), [sources and proxies](client-reactivity-engine_sources-and-proxies.md), [deriveds and async signals](client-reactivity-engine_deriveds-and-async.md), [effects](client-reactivity-engine_effects.md), [batching and scheduling](client-reactivity-engine_batching-scheduling.md), and [props and stores](client-reactivity-engine_props-and-stores.md) — builds directly on top of these primitives. The module has **zero runtime dependencies** of its own (only type-level imports), which makes it the true root of the client dependency graph.

---

## 2. Architecture

### 2.1 Module composition

```mermaid
graph TB
    subgraph Foundation["client-reactivity-engine_foundation"]
        FLAGS["flags/index.js<br/>---<br/>async_mode_flag<br/>legacy_mode_flag<br/>tracing_mode_flag<br/>---<br/>enable_async_mode_flag()<br/>disable_async_mode_flag() *(testing only)*<br/>enable_legacy_mode_flag()<br/>enable_tracing_mode_flag()"]
        EQ["reactivity/equality.js<br/>---<br/>equals(value)<br/>not_equal(a, b)<br/>safe_not_equal(a, b)<br/>safe_equals(value)"]
    end

    subgraph Siblings["Sibling reactivity modules"]
        SG["signal-graph<br/>(runtime.js)"]
        SP["sources-and-proxies"]
        DA["deriveds-and-async"]
        EFF["effects"]
        BS["batching-scheduling"]
        PS["props-and-stores"]
    end

    subgraph External["Other engine consumers"]
        DOM["client-dom-renderer"]
        DEV["client-dev-tooling"]
        LEG["legacy-compat"]
    end

    SG -- "reads async_mode_flag (tick)" --> FLAGS
    SP -- "uses equals via set()" --> EQ
    DA -- "safe equality defaults" --> EQ
    EFF -- "value-changed checks" --> EQ
    BS -- "skip-if-unchanged pruning" --> EQ
    PS -- "prop/store update checks" --> EQ
    DOM -- "mode-dependent rendering" --> FLAGS
    DEV -- "tracing_mode_flag, dev equality" --> FLAGS
    LEG -- "legacy_mode_flag" --> FLAGS
```

### 2.2 Design role

| Concern | Provided by | Design contract |
|---|---|---|
| *Which mode am I running in?* | Flags | Global, one-way latch; set once during bootstrap before components mount |
| *Did this value really change?* | Equality | Strategy functions attached to signals; consulted on every write |

The foundation intentionally contains **no** signal structures, queues, or DOM code. It only supplies the decision primitives; *where* and *when* those decisions are used is documented in the sibling modules linked above.

---

## 3. Runtime Mode Flags

### 3.1 API

Source: `packages/svelte/src/internal/flags/index.js`

```js
export let async_mode_flag = false;
export let legacy_mode_flag = false;
export let tracing_mode_flag = false;

export function enable_async_mode_flag() { async_mode_flag = true; }
export function disable_async_mode_flag() { async_mode_flag = false; } // ONLY USE DURING TESTING
export function enable_legacy_mode_flag() { legacy_mode_flag = true; }
export function enable_tracing_mode_flag() { tracing_mode_flag = true; }
```

### 3.2 Flag semantics

| Flag | Default | Enabled by | Governs |
|---|---|---|---|
| `async_mode_flag` | `false` | `enable_async_mode_flag()` (bootstrap / `mount`/`hydrate` prelude) | Asynchronous Svelte: async deriveds and awaited blocks, `tick()` using `requestAnimationFrame` instead of a microtask flush, experimental `<svelte-boundary>` async semantics |
| `legacy_mode_flag` | `false` | `enable_legacy_mode_flag()` (compiler-selected for pre-Svelte-5-permissive components) | Svelte 4 compatibility: `$:` reactive statement re-run semantics via `invalidate_inner_signals`, legacy prop propagation in [legacy-compat](legacy-compat.md) |
| `tracing_mode_flag` | `false` | `enable_tracing_mode_flag()` (dev builds / tracing harness) | Dev-mode signal tagging: `tag()` calls inside [sources-and-proxies](client-reactivity-engine_sources-and-proxies.md) (e.g. `update_path` tags `version` and child sources), served by [client-dev-tooling](client-dev-tooling.md) |

### 3.3 Lifecycle invariants

```mermaid
flowchart LR
    A["Module load<br/>all flags = false"] --> B["Bootstrap:<br/>enable_*_mode_flag() called once"]
    B --> C["Flags are latched ON<br/>for lifetime of the app"]
    C --> D{"async_mode_flag?"}
    D -- "yes" --> E["Async mode paths<br/>(await blocks, rAF ticks)"]
    D -- "no" --> F["Sync microtask paths"]
    B -. "testing only" .-> G["disable_async_mode_flag()<br/>resets latch between tests"]
```

Key invariants:

- **One-way latches.** Only `disable_async_mode_flag()` can turn a flag off, and it exists *exclusively for test isolation*. Production code must never disable flags mid-session, because components capture mode-dependent behavior at mount time.
- **Set before mount.** Flags must be enabled before the first `mount()`/`hydrate()` call; mode checks are plain boolean reads performed inline in hot paths (e.g. `tick()`, effect creation), so there is no subscription or re-configuration mechanism.
- **Zero-cost when off.** Each flag guards a distinct code path, so disabled modes contribute no runtime overhead beyond a boolean check.

### 3.4 Cross-module interaction example: `tick()`

The signal-graph module's `tick()` (see [client-reactivity-engine_signal-graph](client-reactivity-engine_signal-graph.md)) demonstrates the flag branch pattern:

```js
async function tick() {
    if (async_mode_flag) {
        return new Promise((f) => requestAnimationFrame(() => f()));
    }
    await Promise.resolve();
    flushSync(); // pending state changes applied after one tick
}
```

In async mode, `tick()` defers to the next animation frame (allowing async work to settle); in sync mode it resolves on the microtask queue and then forces a synchronous flush via the [batching-scheduling](client-reactivity-engine_batching-scheduling.md) subsystem.

---

## 4. Equality Semantics

### 4.1 Why equality lives at the foundation

Every reactive write funnels through a single question: *"Is the new value different from the stored value?"* If not, the write is a no-op and the entire downstream propagation — dirty marking, batch scheduling, effect re-runs — is skipped. Getting this predicate right is what gives Svelte its fine-grained, no-diff-required update model. The strategy is attached **per signal**: each source signal stores an `equals` function that is invoked as a method, with the signal itself as `this` (`this.v` is the currently stored value).

### 4.2 API

Source: `packages/svelte/src/internal/client/reactivity/equality.js`
(uses the `Equals` type from the client internal types)

| Function | Signature | Semantics |
|---|---|---|
| `equals` | `(value) => boolean`, bound to signal | **Strict equality** strategy: `value === this.v`. The default for primitive-typed sources; cheapest possible check. |
| `not_equal` | `(a, b) => boolean` | Free-standing strict predicate: `a !== b`. Used where a standalone comparison (not bound to a signal) is needed. |
| `safe_not_equal` | `(a, b) => boolean` | **NaN-aware** (`a != a ? b == b : …`): `NaN` is treated as unequal to everything *including itself*, so a `NaN` write always propagates. Objects and functions are **always considered changed** (no deep comparison is performed — mutation-based updates must propagate). |
| `safe_equals` | `(value) => boolean`, bound to signal | Bound counterpart: `!safe_not_equal(value, this.v)`. Default strategy for deriveds, props, and store-backed values. |

### 4.3 Decision logic of `safe_not_equal`

```mermaid
flowchart TD
    A["safe_not_equal(a, b)"] --> B{"a != a ?<br/>(is a NaN?)"}
    B -- "yes (a is NaN)" --> C{"b == b ?<br/>(is b a number?)"}
    C -- "yes" --> D["true — NaN → number<br/>always propagates"]
    C -- "no (b is also NaN)" --> E["false — NaN → NaN<br/>skips propagation"]
    B -- "no" --> F{"a !== b ?"}
    F -- "different primitives" --> G["true"]
    F -- "identical primitives" --> H["false"]
    F -- "a is object/function" --> I{"a !== null &&<br/>typeof a === 'object'<br/>|| typeof a === 'function'"}
    I -- "yes" --> J["true — objects/functions<br/>ALWAYS count as changed"]
    I -- "no (a is null)" --> K["false"]
```

Practical consequences:

- Writing `NaN` to a signal always marks dependents dirty (even `NaN → NaN` would be *equal*, but `NaN → anything else` always propagates — the asymmetry protects derived numeric chains).
- Assigning the *same* primitive skips everything — this is the "did nothing change?" fast path used constantly by template expressions.
- Assigning an **object** (even the identical reference? — no: identical reference passes `a !== b` as false *only if the same reference*; a new object literal always propagates). Mutating an object in place does **not** propagate unless the object is wrapped in a reactive proxy — see [sources-and-proxies](client-reactivity-engine_sources-and-proxies.md) for `$state` deep proxying, which bumps a version signal instead.

### 4.4 Write-path data flow

The equality strategies are consulted on every write, before anything reaches the scheduler:

```mermaid
sequenceDiagram
    participant C as Component code<br/>(e.g. counter++)
    participant U as sources.js<br/>update()/update_pre()
    participant R as runtime set()<br/>(signal-graph)
    participant EQ as equality.js<br/>signal.equals(v)
    participant B as batch.js<br/>(batching-scheduling)
    participant E as effects<br/>(effects module)

    C->>U: update(source, +1)
    U->>R: set(source, newValue)
    R->>EQ: signal.equals(newValue)  // this.v = oldValue
    alt equal — no change
        EQ-->>R: true
        R-->>U: write discarded, graph untouched
    else not equal
        EQ-->>R: false
        R->>R: this.v = newValue, bump write version (wv)
        R->>B: mark dependents dirty, schedule in current batch
        B->>E: flush → re-run dirty effects / template updates
    end
```

The `update` / `update_pre` pair shown above (post-increment vs pre-increment) is a thin convenience layer from [sources-and-proxies](client-reactivity-engine_sources-and-proxies.md) over this path; the equality check itself is always the gatekeeper.

### 4.5 Strategy selection across the engine

| Consumer module | Typical strategy | Rationale |
|---|---|---|
| [signal-graph](client-reactivity-engine_signal-graph.md) `set()` | `equals` (strict) for `state()` primitives | Cheapest correct check for primitives |
| [deriveds-and-async](client-reactivity-engine_deriveds-and-async.md) | `safe_equals` defaults | Deriveds may produce `NaN`/objects; safe semantics avoid lost updates |
| [props-and-stores](client-reactivity-engine_props-and-stores.md) `prop`, `store_get` | `safe_equals` | Store contracts follow legacy `safe_not_equal` semantics (Svelte 4 store compatibility) |
| [client-dev-tooling](client-dev-tooling.md) `dev/equality.js` | `equals`, `strict_equals` (DEV only) | Warnings for equality-based code smells; swapped in during development builds |

---

## 5. Dependency Graph

The foundation is the **root** of the client runtime dependency graph — everything flows *out* of it, nothing flows *in* (besides type imports):

```mermaid
graph BT
    F["★ foundation<br/>flags + equality"]

    subgraph Reactivity["client-reactivity-engine"]
        SG["signal-graph"]
        SP["sources-and-proxies"]
        DA["deriveds-and-async"]
        EFF["effects"]
        BS["batching-scheduling<br/>(batch.js, loop.js)"]
        PS["props-and-stores"]
    end

    DR["client-dom-renderer"]
    DT["client-dev-tooling"]
    LC["legacy-compat"]
    PUB["public-api / reactive-builtins<br/>(SvelteMap, SvelteDate, motion…)"]

    SG --> F
    SP --> F
    SP --> SG
    DA --> F
    DA --> SP
    EFF --> F
    EFF --> BS
    BS --> F
    PS --> F
    PS --> SP
    DR --> F
    DR --> EFF
    DT --> F
    LC --> F
    LC --> DT
    PUB --> F
    PUB --> SP
```

Reading the graph bottom-up: flags and equality are consumed (1) by the core signal machinery for graph maintenance, (2) by scheduling/effect layers for flush-time pruning, and (3) by mode-aware peripheral layers (dev tooling, legacy compat) that branch on runtime mode.

---

## 6. Process Flows

### 6.1 Application bootstrap (flag setting)

```mermaid
sequenceDiagram
    participant App as Application entry
    participant F as flags/index.js
    participant M as mount()/hydrate()<br/>(public-api)
    participant R as runtime (signal-graph)

    App->>F: enable_async_mode_flag()  (if compiled for async)
    App->>F: enable_legacy_mode_flag() (compiler-inferred)
    App->>F: enable_tracing_mode_flag() (dev harness)
    App->>M: mount(Component, target)
    M->>R: create root effect & signals
    Note over R: from here on, every hot path<br/>reads the latched flags directly
    App->>R: tick() → branches on async_mode_flag
```

### 6.2 Equality gate in a state write (detail)

1. **Write initiated** — assignment compiled by the [compiler pipeline](Compiler_Pipeline___Language_Toolchain.md) (e.g. `AssignmentExpression` client visitor) calls `$.set(signal, value)` or a `sources.js` helper.
2. **Equality consulted** — `signal.equals(value)` executes the bound strategy; `this.v` is the previous value.
3. **Fast path** — equal → return immediately. No version bump, no dirty marking, no batch work.
4. **Slow path** — different → store value, bump `wv` (write version per the `Signal` interface: `{ f: flags bitmask, wv: write version }`), mark dependents, and let the [batching-scheduling](client-reactivity-engine_batching-scheduling.md) layer coalesce the flush.

---

## 7. Design Notes & Invariants

- **Leaf by design.** The module imports nothing at runtime. This keeps the deepest layer of the engine tree-shakeable and trivially testable — the [treeshakeability checker](Engineering_Tooling_(Benchmarks,_Verification___Playground).md) relies on such clean leaves.
- **`this`-bound strategies, not per-call arguments.** Attaching `equals`/`safe_equals` to the signal lets `set()` run one branch-free call `signal.equals(v)` instead of threading strategy flags through the write path; the free functions (`not_equal`, `safe_not_equal`) remain available for non-signal contexts (stores, props, hydration comparisons).
- **Safe-by-default for aggregates.** Because `safe_not_equal` treats every object/function as changed, correctness never depends on deep-equality cost; deep reactivity is instead achieved structurally via proxies ([sources-and-proxies](client-reactivity-engine_sources-and-proxies.md)).
- **Flags are not configuration.** There is no API to read-and-react to flag changes — code that needs mode-aware behavior branches inline. Changing flags after components exist is unsupported (outside tests) and will produce inconsistent behavior.
- **`Signal` interface dependency.** The engine-wide signal contract (`f` flags bitmask + `wv` write version) is defined in the sibling [signal-graph](client-reactivity-engine_signal-graph.md) module's types; the equality layer operates on `this.v` and must never mutate `f`/`wv` itself — that is exclusively the signal graph's job.

---

## 8. Related Modules

| Module | Relationship |
|---|---|
| [client-reactivity-engine](client-reactivity-engine.md) | Parent — engine overview and how foundation primitives are orchestrated |
| [client-reactivity-engine_signal-graph](client-reactivity-engine_signal-graph.md) | Primary consumer — `set()`, `get()`, `tick()`, `Signal` type, flag branching |
| [client-reactivity-engine_sources-and-proxies](client-reactivity-engine_sources-and-proxies.md) | Uses equality on every source write; proxies bump version signals for deep state |
| [client-reactivity-engine_deriveds-and-async](client-reactivity-engine_deriveds-and-async.md) | Derived/async signals default to `safe_equals`; async features gated by `async_mode_flag` |
| [client-reactivity-engine_effects](client-reactivity-engine_effects.md) | Effect re-run decisions terminate in the equality gate |
| [client-reactivity-engine_batching-scheduling](client-reactivity-engine_batching-scheduling.md) | Flush coalescing benefits from equality pruning; `tick()` mode branch |
| [client-reactivity-engine_props-and-stores](client-reactivity-engine_props-and-stores.md) | Prop and store update semantics built on `safe_not_equal` |
| [client-dev-tooling](client-dev-tooling.md) | DEV equality variants, `tracing_mode_flag` consumers (`tag`) |
| [legacy-compat](legacy-compat.md) | `legacy_mode_flag` consumer — Svelte 4 re-run semantics |
| [Compiler_Pipeline___Language_Toolchain](Compiler_Pipeline___Language_Toolchain.md) | Compiler decides which `enable_*_mode_flag` calls the output contains |
