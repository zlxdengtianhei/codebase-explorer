# Treeshakeability Checker

The **treeshakeability checker** (`packages/svelte/scripts/check-treeshakeability.js`) is a self-verification tool for the Svelte package that runs as a CI gate. It enforces two critical bundle-size invariants: (1) **every public export entry point** declared in `package.json` → `exports` is side-effect-free, so importing it without using anything from it bundles to **zero bytes**; and (2) **opt-in runtime features** — hydration, legacy mode, and `$inspect.trace` dev tracing — are fully eliminated from production bundles that never request them. Any violation fails the script with exit code `1`.

---

## 1. Purpose and Scope

| Aspect | Detail |
|---|---|
| Location | `packages/svelte/scripts/check-treeshakeability.js` |
| Module | `treeshakeability_checker` (child of [Engineering Tooling (Benchmarks, Verification & Playground)](<Engineering_Tooling_(Benchmarks,_Verification___Playground).md>)) |
| Type | Standalone verification script (no exported API) |
| Strategy | Two-phase: *per-export empty-bundle check* + *feature-gated bundle string assertion* |
| Failure mode | Console diagnostics + full bundle artifact dump + `process.exit(1)` |

### Why it exists

Svelte's runtime is designed so that applications only pay for what they use: importing `svelte/store` without using a store, or compiling a component without hydration, must contribute nothing to the final bundle. This is a *contract* between the compiler, the runtime, and the package's `exports` map. The checker continuously validates that contract:

1. **Per-export check** — for each entry in the `exports` map (under both `browser` and `default` conditions), bundling a bare `import` must yield an empty chunk.
2. **Feature-gating check** — a feature-rich component (exercising every syntax that emits hydration-aware DOM code) is compiled and bundled with the client runtime; dev-only / opt-in code paths must then be tree-shaken away.

---

## 2. Module Context

The checker is one of five tooling submodules under Engineering Tooling. Unlike its siblings, which measure *performance* (reactivity/SSR benchmarks, cross-implementation comparison) or support *development* (sandbox playground), this module performs *correctness verification of bundle output*.

| Sibling module | Concern |
|---|---|
| [reactivity_benchmarks](reactivity_benchmarks.md) | Performance of the signal graph (kairo, sbench, mol benchmarks) |
| [ssr_benchmarks](ssr_benchmarks.md) | SSR rendering throughput |
| [benchmark_comparison](benchmark_comparison.md) | Cross-implementation result comparison |
| [sandbox-playground-tooling](sandbox-playground-tooling.md) | Interactive playground output/hash tooling |
| **treeshakeability_checker** (this module) | Bundle-size / dead-code correctness gate |

---

## 3. Architecture Overview

The script is a single file with three logical parts: an implicit main flow, the `bundle_code` bundling utility, and the `check_bundle` assertion helper. The main flow drives everything; `bundle_code` wraps a fully configured Rollup pipeline; `check_bundle` performs negative string assertions against the final feature bundle.

```mermaid
graph TB
    subgraph Script["packages/svelte/scripts/check-treeshakeability.js"]
        MAIN["Main verification flow"]
        BC["bundle_code(entry)"]
        CB["check_bundle(case_name, ...strings)"]
    end

    subgraph RollupStack["Rollup bundling stack"]
        R["rollup()"]
        V["@rollup/plugin-virtual<br/>__entry__ module"]
        RS["resolve-svelte plugin<br/>exports-map self-resolution"]
        NR["@rollup/plugin-node-resolve<br/>production/browser conditions"]
    end

    subgraph SUT["Svelte package under test"]
        PKG["package.json → exports map"]
        CC["svelte/compiler → compile()"]
        CR["Client runtime modules<br/>hydration / legacy / tracing"]
    end

    MAIN -->|"per-export entry code"| BC
    MAIN -->|"compiled fixture code"| BC
    MAIN -->|"fixture source"| CC
    CC -->|"js.code"| MAIN
    PKG -->|"entry resolution"| RS
    BC --> V
    BC --> RS
    BC --> NR
    V --> R
    RS --> R
    NR --> R
    CR -.->|"included only if<br/>still reachable"| R
    R -->|"single output chunk"| BC
    BC -->|"bundled code"| CB
    CB -->|"✅ / ❌ + failed flag"| MAIN
```

### Core components

| Component | Kind | Responsibility |
|---|---|---|
| `bundle_code(entry)` | `async` function | Bundles arbitrary entry code through Rollup and returns the (possibly empty) single-chunk output |
| Main flow | top-level script logic | Iterates the `exports` map, compiles the fixture, orchestrates both check phases |
| `check_bundle(case_name, ...strings)` | function | Asserts that none of the probe strings appear in the feature bundle; prints diagnostics on failure |

---

## 4. Component Reference

### 4.1 `bundle_code(entry)`

Bundles the caller-supplied `entry` source through Rollup and returns the trimmed output of the single generated chunk.

```js
async function bundle_code(entry) { /* rollup({ input: '__entry__', plugins: [...] }) */ }
```

Implementation details:

- **Virtual entry** — `@rollup/plugin-virtual` exposes the `entry` string as a module named `__entry__`, which is also the Rollup `input`. No temporary files are needed.
- **`resolve-svelte` plugin** — a custom `resolveId` hook that intercepts any bare import starting with `svelte` (e.g. `svelte`, `svelte/store`, `svelte/internal/client`) and rewrites it via the package's own `exports` map: `pkg.exports[importee.replace('svelte', '.')]`, resolving to `entry.browser ?? entry.default`. This makes the bundler consume the *local working copy* of Svelte rather than a published version — the package tests itself.
- **`nodeResolve`** — resolves remaining imports with `exportConditions: ['production', 'import', 'browser', 'default']`, so production builds (no dev warnings module, etc.) are simulated.
- **Warning policy** — `EMPTY_BUNDLE` (the expected *success* signal of the per-export checks) and `CIRCULAR_DEPENDENCY` (known, tolerated internal cycles) are swallowed; all other warnings surface normally.
- **Single-chunk invariant** — after `bundle.generate({})`, more than one output chunk throws (`'errr what'`), guarding against accidental code-splitting that would break the empty-string assertions.
- **Return value** — `output[0].code.trim()`; an empty string means the import contributed zero bytes.

```mermaid
flowchart TD
    A["bundle_code(entry)"] --> B["rollup({ input: '__entry__' })"]
    B --> C["virtual plugin<br/>exposes entry as __entry__"]
    B --> D["resolve-svelte plugin<br/>bare 'svelte*' imports → exports map<br/>(browser ?? default)"]
    B --> E["nodeResolve<br/>production / import / browser / default"]
    C --> F["bundle.generate({})"]
    D --> F
    E --> F
    F --> G{"output.length > 1 ?"}
    G -->|"yes"| H["throw Error"]
    G -->|"no"| I["return output[0].code.trim()"]
```

### 4.2 Main verification flow

Phase 1 — **per-export empty-bundle check**:

1. Read `package.json` from the current working directory (`pkg`).
2. Iterate every key in `pkg.exports`, **skipping the special cases** (see table below).
3. For each export × each condition in `['browser', 'default']` (missing conditions skipped):
   - build entry code `import "<absolute path of the condition entry>"`,
   - run `bundle_code` and assert the result is the empty string `''`
   - `''` → report `✅ <svelte-name/key> (<type>)`; anything else → print the leaked code, report `❌`, set `failed = true`.

Skipped exports and why:

| Skipped key | Reason |
|---|---|
| `./compiler` | Node-only compiler tool; not expected to bundle to zero (see [Compiler Pipeline — Language Toolchain](<Compiler_Pipeline___Language_Toolchain.md>)) |
| `./internal` | Implementation barrel; covered indirectly through public entries and the fixture |
| `./internal/disclose-version` | Intentionally side-effectful (discloses the Svelte version on import) |
| `./internal/flags/legacy` | Force-enabled flag module — importing it *deliberately* turns on legacy mode (a side effect) |
| `./internal/flags/tracing` | Force-enabled flag module — importing it *deliberately* turns on dev tracing (a side effect) |

Phase 2 — **feature-gating check**:

1. Compile a fixture component with `compile(source, { filename: 'App.svelte' })` (runes mode via `<svelte:options runes />`). The fixture deliberately covers *"all features which contain hydration code"*:
   - `mount()` from the client main entry (`.` → `browser` condition → `src/index-client.js`),
   - `<svelte:head>` / `<title>`, `bind:value` on `<input>`,
   - dynamic `href`/`class` attributes and attribute spread (`{...foo}`),
   - `<svelte:component>`, `<svelte:element>`, a component with props (`<C {foo} />`),
   - `{#if}`, `{#each}`, `{#await}`, `{#key}`, `{#snippet}`, `{@render}`, `{@html}`.
2. Bundle the compiled `js.code` (with the `mount` import) via `bundle_code`.
3. Run the three `check_bundle` assertions (Section 4.3) against the resulting bundle.

Teardown: if any check failed, the full bundle is written to `scripts/_bundle.js` (path printed for debugging) and the script exits `1`; otherwise it exits cleanly.

### 4.3 `check_bundle(case_name, ...strings)`

A negative string-assertion helper over the Phase-2 bundle:

```mermaid
flowchart TD
    A["check_bundle(case_name, ...strings)"] --> B{"any probe string found?<br/>bundle.indexOf(string) >= 0"}
    B -->|"yes (first match wins)"| C["❌ case_name not treeshakeable"]
    C --> D["slice ±500 chars around the match"]
    D --> E["print context window,<br/>failing line marked with '>',<br/>neighbors with '|' (5 lines each side)"]
    E --> F["set failed = true, return"]
    B -->|"no (all probes absent)"| G["✅ case_name treeshakeable"]
```

The ±500-character context window (rendered as a small excerpt with the offending line prefixed by `>`) gives maintainers an immediate answer to *what* pulled the leaked code in. The helper returns after the first failing probe string, keeping the report focused.

---

## 5. Verification Workflow

```mermaid
sequenceDiagram
    autonumber
    participant S as Script (main flow)
    participant P as package.json
    participant R as Rollup (bundle_code)
    participant C as svelte/compiler
    participant K as check_bundle

    S->>P: read exports map
    loop for each export key × condition (browser, default)
        S->>R: bundle_code(`import "<resolved entry>"`)
        R-->>S: chunk code
        alt code === ""
            S->>S: report ✅ treeshakeable
        else code !== ""
            S->>S: print leaked code, report ❌, failed = true
        end
    end

    S->>C: compile(feature-rich App.svelte fixture)
    C-->>S: compiled js.code
    S->>R: bundle_code(fixture + `import { mount } from client main`)
    R-->>S: bundle
    S->>K: check_bundle("Hydration code", "hydrate_node", "hydrate_next")
    S->>K: check_bundle("Legacy code", "component_context.l")
    S->>K: check_bundle("$inspect.trace", "'CreatedAt'")

    alt any failure
        S->>S: dump full bundle → scripts/_bundle.js, process.exit(1)
    else all pass
        S->>S: exit 0
    end
```

End-to-end data flow:

```mermaid
flowchart LR
    A["package.json<br/>exports map"] --> B["per-export entry paths<br/>(browser + default)"]
    B --> C["entry source:<br/>import &lt;abs path&gt;"]
    C --> D["Rollup bundle"]
    D --> E{"empty string?"}
    E -->|yes| F["✅ export is side-effect-free"]
    E -->|no| G["❌ print code, failed"]
    H["fixture .svelte source"] --> I["compile() → js.code"]
    I --> J["fixture bundle<br/>(+ mount import)"]
    J --> K{"probe strings<br/>absent?"}
    K -->|yes| L["✅ hydration / legacy / tracing<br/>tree-shaken"]
    K -->|no| M["❌ context window dump, failed"]
    F --> N["exit code"]
    L --> N
    G --> N
    M --> N
```

---

## 6. Verified Invariants and Probe Strings

Each Phase-2 probe string targets a specific opt-in code path of the [Client Runtime Engine (Reactivity & DOM Rendering)](<Client_Runtime_Engine_(Reactivity___DOM_Rendering).md>). Its presence in a client-only bundle means the tree-shaking boundary is broken.

| Case name | Probe strings | Runtime source | Violation meaning |
|---|---|---|---|
| `Hydration code` | `hydrate_node`, `hydrate_next` | `internal/client/dom/hydration.js` (used by `hydrate()` in `internal/client/render.js`, all calls gated on the `hydrating` flag) | Hydration machinery leaked although `mount()` was called without hydration |
| `Legacy code` | `component_context.l` | Legacy-mode component context (created only under `legacy_mode_flag` runtime) | Legacy-mode runtime leaked into a runes-mode bundle |
| `$inspect.trace` | `'CreatedAt'` | `internal/client/dev/tracing.js` (dev-only tracing payload emitted by `$inspect.trace`) | Dev-only tracing code leaked into a production bundle |

Phase 1 has a single, uniform invariant per entry point:

| Phase | Invariant |
|---|---|
| Per-export (`browser` + `default`) | `bundle_code('import "<entry>"') === ''` — no side effects, no residual code |
| Feature bundle | `hydrate_node`, `hydrate_next`, `component_context.l`, `'CreatedAt'` all absent |

---

## 7. External Dependencies

| Dependency | Role |
|---|---|
| `rollup` | Bundler whose tree-shaking engine is the object of the verification |
| `@rollup/plugin-virtual` | Injects caller-supplied entry code as the in-memory `__entry__` module |
| `@rollup/plugin-node-resolve` | Resolves module specifiers with explicit export conditions (`production`, `import`, `browser`, `default`) |
| `svelte/compiler` | Compiles the fixture — self-referential use of the package's own [Compiler Pipeline — Language Toolchain](<Compiler_Pipeline___Language_Toolchain.md>) |
| `node:fs` / `node:path` / `node:process` | Reading `package.json`, path resolution, artifact writing, exit codes |

---

## 8. Integration with Other Modules

```mermaid
graph LR
    TSC["treeshakeability_checker"] -->|"reads exports map,<br/>imports client main (mount)"| PUB["Public API —<br/>Built-in Feature Surface"]
    TSC -->|"compile() builds the fixture"| CP["Compiler Pipeline —<br/>Language Toolchain"]
    TSC -->|"asserts absence of<br/>hydration / legacy / tracing"| CRE["Client Runtime Engine"]
    TSC -.->|"default-condition entries<br/>(e.g. svelte/server)"| SSR["Server-Side Rendering"]
    PUB -.->|"runtime backed by"| CRE
    CP -.->|"emits calls into"| CRE
```

- **[Public API — Built-in Feature Surface](<Public_API___Built-in_Feature_Surface.md>)** — the `exports` map iterated in Phase 1 *is* the Public API surface; the checker guarantees that entries such as `svelte`, `svelte/store`, `svelte/motion`, `svelte/transition`, `svelte/easing`, `svelte/animate`, `svelte/reactivity`, `svelte/action`, `svelte/attachments`, and `svelte/server` are free to import-and-drop. The client main entry (browser condition, `src/index-client.js`) provides the `mount()` used by the fixture.
- **[Compiler Pipeline — Language Toolchain](<Compiler_Pipeline___Language_Toolchain.md>)** — supplies `compile()` for the Phase-2 fixture. Phase 2 also implicitly validates the compiler↔runtime contract: the code the compiler emits for common features must become dead weight when hydration/legacy/tracing are off.
- **[Client Runtime Engine (Reactivity & DOM Rendering)](<Client_Runtime_Engine_(Reactivity___DOM_Rendering).md>)** — the primary code under test: the hydration helpers (`dom/hydration.js`, client-dom-renderer → dom-foundation), the legacy runtime, and the dev tooling tracing module must all stay out of minimal production bundles.
- **[Server-Side Rendering — Cross-Target Runtime Services](<Server-Side_Rendering___Cross-Target_Runtime_Services.md>)** — covered by the per-export loop's `default` condition (e.g. `svelte/server` → `src/index-server.js`), asserting server entries are likewise side-effect-free.

---

## 9. Failure Handling and Diagnostics

| Situation | Behavior |
|---|---|
| Export bundles to non-empty code | Leaked code printed, `❌` reported, `failed = true` |
| Probe string found in feature bundle | `❌ <case> not treeshakeable` + ±500-char context window with the failing line marked `>` and `|` gutter lines (5 lines each side); first match only |
| Rollup produces multiple chunks | Immediate `throw` (single-chunk invariant broken) |
| Any failure at end | Full bundle written to `scripts/_bundle.js` (absolute path printed) and `process.exit(1)` |

---

## 10. Usage

Run from the `packages/svelte` directory (the script resolves `package.json` and the `scripts/_bundle.js` artifact relative to the current working directory):

```sh
cd packages/svelte
node scripts/check-treeshakeability.js
```

Exit codes: `0` — all exports and feature gates verified; `1` — at least one violation (see `scripts/_bundle.js` for the offending bundle). Typical CI usage is a dedicated verification job alongside the benchmark suites of [reactivity_benchmarks](reactivity_benchmarks.md) and [ssr_benchmarks](ssr_benchmarks.md).

---

## 11. Maintenance Notes

- **New public export** — automatically covered by the Phase-1 loop with no script changes, *provided* the entry remains side-effect-free. A new intentionally-side-effectful entry (like the flag modules) must be added to the skip list.
- **New opt-in / dev-only runtime feature** — add a probe case via `check_bundle('<case>', '<unique string from that feature>')`; choose a string that exists *only* in the gated code path.
- **Warning policy** — `EMPTY_BUNDLE` is filtered because emptiness is the *goal* of Phase 1; if that filter is removed, every success would log noise. `CIRCULAR_DEPENDENCY` suppresses known internal cycles; revisit if new cycles appear.
- **Condition list** — `['browser', 'default']` mirrors the two real consumption targets (browser bundles vs. Node). Adding a new package export condition (e.g. a bundler-specific one) requires extending this list.
- **Single-chunk invariant** — the `output.length > 1` throw protects the empty-string and `indexOf`-based assertions from being invalidated by code-splitting; keep `bundle.generate({})` argument-free.