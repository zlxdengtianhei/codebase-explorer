# Compile Runner (`sandbox-playground-tooling_compile-runner`)

## 1. Overview

The **compile runner** is the batch-compilation driver of the Svelte sandbox playground, implemented entirely in `playgrounds/sandbox/run.js`. It takes every Svelte component (`.svelte`) and JavaScript module (`.js`) placed in the sandbox's `src/` directory and pushes it through the *real* `svelte/compiler` public API, persisting all final and intermediate artifacts under `output/`:

- **Client and server** compilations of every component,
- the **parsed AST** serialized as JSON,
- **legacy-to-runes migrated** sources,
- **source maps** and **extracted CSS**,
- an alternative client build using `fragments: 'tree'`,
- compiled outputs for plain `.js` modules via `compileModule()`.

The module's designated core component is [`write()`](#3-core-component-write), the single artifact sink used by every stage of the run.

**Primary use cases:**

| Audience | What the runner provides |
|---|---|
| Compiler maintainers | Deterministic, on-disk inspection of exactly what `compile()` / `compileModule()` emit for a given source tree (including warnings and code frames) |
| Runtime maintainers | Comparison of the default (fragment-based) client output against the `fragments: 'tree'` variant |
| Test authors | Reproducible build results for playground bundles; the sibling `scripts/create-test.js` promotes the same `src/` into a regression test fixture |
| Playground users (via `scripts/download.js` inverse workflow) | An offline reproduction path for bugs reported from svelte.dev/playground |

---

## 2. Position in the System

The compile runner is a **leaf consumer** of the compiler and a **producer** of artifacts consumed by developer tooling and tests. It sits inside the sandbox tooling family:

```
Engineering_Tooling_(Benchmarks,_Verification___Playground)
└── sandbox-playground-tooling
    ├── sandbox-playground-tooling_compile-runner   ← this module (run.js)
    └── sandbox-playground-tooling_share-link-hash  ← sibling (hash.js::compress)
```

- Upstream, it depends exclusively on the **public API of the Svelte compiler** (`compile`, `compileModule`, `parse`, `migrate` re-exported from `svelte/compiler`). The internal phases (parse → analyze → transform) are documented in the [Compiler Pipeline & Language Toolchain](Compiler_Pipeline___Language_Toolchain.md) module — this document does not duplicate them.
- Downstream, the generated code targets the [Client Runtime Engine](Client_Runtime_Engine_(Reactivity___DOM_Rendering).md) (`generate: 'client'`) and the [Server-Side Rendering runtime](Server-Side_Rendering___Cross-Target_Runtime_Services.md) (`generate: 'server'`), so the runner exercises both runtime targets end-to-end.
- The sibling [share-link hash module](sandbox-playground-tooling_share-link-hash.md) handles the gzip + base64url compression of playground payloads; `scripts/download.js` is its runtime inverse (`atob` + `DecompressionStream`) and feeds the `src/` tree that this runner consumes.

### System Context

```mermaid
flowchart TB
    subgraph input["Inputs"]
        src["playgrounds/sandbox/src/**\n(*.svelte and *.js)"]
        flags["CLI flag: --runes / --no-runes"]
    end

    subgraph runner["compile-runner — run.js"]
        clean["1. Clean output/ (keep .gitkeep)"]
        glob["2. Discover sources (tinyglobby)"]
        loop["3. Per-target loop: client → server"]
        sink["write() artifact sink\n(mkdirp + writeFileSync)"]
    end

    subgraph compiler["svelte/compiler — public API"]
        parse["parse()"]
        compile["compile()"]
        compileModule["compileModule()"]
        migrate["migrate()"]
    end

    subgraph output["playgrounds/sandbox/output/"]
        ast["ast/*.json"]
        mig["migrated/*"]
        js["{client,server}/*.js + .js.map"]
        css["{client,server}/*.css"]
        tree["client/*.tree.js + .map"]
    end

    consumers["Consumers:\n• manual inspection / diffs\n• vite dev server + ssr-*.js playground\n• packages/svelte/tests fixtures"]

    src --> glob --> loop
    flags --> loop
    clean --> glob
    loop -- "source text" --> compiler
    compiler -- "AST / CompileResult / migrated code" --> loop
    loop --> sink --> output
    output --> consumers
```

---

## 3. Core Component: `write`

```js
/**
 * @param {string} file
 * @param {string} contents
 */
function write(file, contents) {
	mkdirp(path.dirname(file));
	fs.writeFileSync(file, contents);
}
```

`write()` is the **single choke point through which every generated artifact reaches disk**. Its responsibilities:

| Aspect | Behavior |
|---|---|
| Directory creation | `mkdirp(dir)` calls `fs.mkdirSync(dir, { recursive: true })` inside a `try/catch` — best-effort and idempotent (pre-existing directories and `EEXIST` errors are swallowed) |
| File writing | `fs.writeFileSync(file, contents)` is **fail-fast**: an I/O error (permissions, disk full) throws and aborts the run, which is the correct behavior since a partially written artifact set would be misleading |
| Content mode | Text (UTF-8) writes; binary artifacts never occur because every output (JS, maps, CSS, JSON, migrated code) is textual |
| Naming | Paths are composed with `node:path` (`path.dirname`, `path.basename`), keeping the runner platform-portable |

Because `write()` guarantees parent directories exist, the compile loops can remain declarative — each stage simply computes an output path and hands it to `write()`. The supporting `mkdirp()` helper is deliberately separate so that output-path setup failures (e.g., the pre-existing directory case) never mask genuine write failures.

Supporting script-level helpers (same file): `mkdirp()`, the top-level `output/` cleanup routine (removes every entry except `.gitkeep` via `fs.rmSync(..., { recursive: true })`, swallowing errors), and the CLI bootstrap with `node:util.parseArgs`.

---

## 4. Execution Flow

The script is a top-level ESM program — it runs to completion when invoked with `node run.js [--runes]` from `playgrounds/sandbox/`:

1. **Argument parsing** — `parseArgs({ options: { runes: { type: 'boolean' } } })` accepts `--runes` / `--no-runes`, forwarded to every component compilation.
2. **Workspace reset** — `output/` is emptied (except `.gitkeep`) so results always reflect the *current* compiler and sources.
3. **Source discovery** — `globSync('**/*.svelte')` and `globSync('**/*.js')` relative to `src/`.
4. **Target loop** — for each of `['client', 'server']` (a `const` tuple, iteration order guaranteed):
   - Every `.svelte` file is compiled (plus client-only extras, see below).
   - Every `.js` file is compiled with `compileModule()`.
5. All results are persisted through `write()`.

```mermaid
flowchart TD
    A["node run.js [--runes]"] --> B["parseArgs: read --runes flag"]
    B --> C{"output/ exists?"}
    C -- yes --> D["remove all entries except .gitkeep"]
    C -- no --> E
    D --> E["glob src/**/*.svelte and src/**/*.js"]
    E --> F["for target in ['client', 'server']"]
    F --> G["iterate *.svelte files"]
    G --> H{"target == 'client' ?"}
    H -- yes --> H1["parse(source, { modern: true })"]
    H1 --> H2["write output/ast/{file}.json\n(bigint-safe serializer)"]
    H2 --> H3{"migrate(source) throws?"}
    H3 -- no --> H4["write output/migrated/{file}"]
    H3 -- yes --> H5["console.warn — continue"]
    H -- no --> I
    H4 --> I["compile() → CompileResult"]
    H5 --> I
    I --> J["log warning.code + warning.frame to stderr"]
    J --> K["write {file}.js with sourceMappingURL\nwrite {file}.js.map"]
    K --> L{"target == 'client' ?"}
    L -- yes --> L1["compile() with fragments: 'tree'"]
    L1 --> L2["write {file}.tree.js + {file}.tree.js.map"]
    L -- no --> M
    L2 --> M{"compiled.css present?"}
    M -- yes --> M1["write {file}.css"]
    M -- no --> N
    M1 --> N{"more .svelte files?"}
    N -- yes --> G
    N -- no --> O["iterate *.js files"]
    O --> P["compileModule(source, options)"]
    P --> Q["write output/{target}/{file}"]
    Q --> R{"more .js files?"}
    R -- yes --> O
    R -- no --> S{"more targets?"}
    S -- yes --> F
    S -- no --> T["done"]
```

**Client-only extras** — AST dumps and migrated sources are target-independent, so they are produced exactly once, during the first (`client`) pass:

- **AST JSON**: `parse(source, { modern: true })` returns the modern AST. `JSON.stringify` is called with a custom replacer that converts `BigInt` values (legal in component expressions, e.g. `1n`) into `["BigInt", "<digits>"]` tuples, since `JSON` has no BigInt representation.
- **Migration**: `migrate(source)` rewrites legacy syntax to runes-based syntax. Its result (`migrated.code`) lands in `output/migrated/{file}`. Migration is *exploratory* here — a `try/catch` turns failures into `console.warn` messages so one bad component cannot abort the remaining work.

---

## 5. Artifact Matrix

All paths are relative to `playgrounds/sandbox/output/`, where `{file}` mirrors the source path under `src/`:

| Artifact | Path | Producer API | When | Notes |
|---|---|---|---|---|
| AST dump | `ast/{file}.json` | `parse(source, { modern: true })` | client pass | BigInt-safe serialization, tab-indented |
| Migrated source | `migrated/{file}` | `migrate(source)` → `.code` | client pass | errors logged, never fatal |
| Compiled JS | `{target}/{file}.js` | `compile()` | both targets | `dev: false`; `//# sourceMappingURL=<name>.js.map` appended |
| Source map | `{target}/{file}.js.map` | `compile()` | both targets | `compiled.js.map.toString()` (JSON) |
| Tree-fragment JS | `client/{file}.tree.js` (+ `.tree.js.map`) | `compile()` with `fragments: 'tree'` | client pass only | second full compilation of the same source |
| Styles | `{target}/{file}.css` | `compile()` | both targets | written only when `compiled.css` is truthy |
| Module JS | `{target}/{file}` | `compileModule()` | both targets | plain `.js` modules; extension preserved |

---

## 6. Compiler API Surface Used

The runner is intentionally a thin driver: all compilation intelligence lives in the compiler package (see [Compiler Pipeline & Language Toolchain](Compiler_Pipeline___Language_Toolchain.md)). The invoked entry points:

| API | Internal pipeline (summary) | Used for |
|---|---|---|
| `parse(source, { modern: true })` | Phase 1 only — Svelte template/script parsing | AST dumps for inspection |
| `compile(source, options)` | validate options → Phase 1 parse → Phase 2 analyze → Phase 3 transform (+ CSS transform) | `.svelte` components, both targets |
| `compileModule(source, options)` | `remove_bom` → `validate_module_options` → `analyze_module` → `transform_module` | `.js` module files (no template) |
| `migrate(source)` | legacy → runes codemod over the AST | `output/migrated/` sources |

```mermaid
sequenceDiagram
    autonumber
    participant R as run.js
    participant C as svelte/compiler
    participant F as filesystem (output/)

    Note over R,F: per .svelte file, target = client
    R->>C: parse(source, { modern: true })
    C-->>R: AST
    R->>F: write ast/{file}.json
    R->>C: migrate(source)
    alt migration succeeds
        C-->>R: { code }
        R->>F: write migrated/{file}
    else migration throws
        C--xR: error
        R->>R: console.warn (non-fatal, loop continues)
    end
    R->>C: compile(source, { generate: 'client', dev: false, ... })
    C-->>R: CompileResult { js, css?, warnings }
    loop over warnings
        R->>R: console.warn(warning.code); console.warn(warning.frame)
    end
    R->>F: write client/{file}.js (+ sourceMappingURL)
    R->>F: write client/{file}.js.map
    R->>C: compile(source, { fragments: 'tree', ... })
    C-->>R: CompileResult (tree-fragment output)
    R->>F: write client/{file}.tree.js + client/{file}.tree.js.map
    opt compiled.css present
        R->>F: write client/{file}.css
    end
```

For `target = 'server'` the flow is the same minus steps 1–2 (AST/migration) and the `fragments: 'tree'` pass; `.js` files take the simpler `compileModule()` branch in both targets.

---

## 7. Compilation Options

Options passed to `compile()` / `compileModule()` on every invocation:

| Option | Value | Rationale |
|---|---|---|
| `dev` | `false` | production-grade output, matching what end users ship |
| `filename` | absolute source path | accurate diagnostics and source-map `sources` entries |
| `generate` | `'client'` \| `'server'` | dual-target output in one run |
| `runes` | `argv.values.runes` (or `undefined`) | lets maintainers force rune/legacy interpretation via `--runes` / `--no-runes`; omitted for `compileModule()` |
| `experimental.async` | `true` | mirrors the sandbox's own `svelte.config.js` (`compilerOptions.experimental.async`) so async features are exercised |
| `fragments` | `'tree'` | only on the second client pass — produces the alternative tree-based DOM construction strategy for comparison |

Note the consistency contract: `experimental: { async: true }` in the runner must match `svelte.config.js`, otherwise the runner's output would diverge from what the live vite/SSR playground produces for the same sources.

---

## 8. Diagnostics & Error-Handling Semantics

The runner applies a deliberate, asymmetric error policy:

| Signal | Policy | Mechanism |
|---|---|---|
| Compiler **warnings** (`compiled.warnings`) | Never fatal; surfaced with full context | `console.warn(warning.code)` + `console.warn(warning.frame)` (code frame from the compiler's diagnostics — see `compile_diagnostic.js` in the compiler module docs) |
| **Migration failures** | Non-fatal, per-file | `try/catch` around `migrate()`; run continues with remaining files |
| **Cleanup / mkdirp failures** | Best-effort, swallowed | `try { ... } catch {}` — idempotent reruns |
| **Artifact write failures** | Fatal, fail-fast | `writeFileSync` exceptions propagate and abort the script |
| **Progress/status** | On stderr | `console.error('--- generating <target> ---')` |

Because all logs go to **stderr**, stdout remains clean — the runner can be piped or wrapped in CI without polluting captured output.

---

## 9. Usage

```bash
cd playgrounds/sandbox

# optional: materialize a playground bundle into src/
node scripts/download.js "https://svelte.dev/playground/xxxx"

# compile everything (legacy mode)
node run.js

# or force runes interpretation
node run.js --runes
```

Typical follow-ups:

- **Inspect** `output/ast/`, `output/migrated/`, `output/client/`, `output/server/` to review compiler behavior.
- **Preview** the same sources in the live sandbox (`vite.config.js`, `ssr-dev.js` / `ssr-prod.js`) — the runner and the dev server must agree because they share `svelte.config.js`.
- **Promote to a regression test**: `node scripts/create-test.js <name>` copies the `src/` tree (following relative imports from `App.svelte`) into `packages/svelte/tests/runtime-*/samples/<name>/`, where the test harness asserts against compiler output like the one the runner produced.

---

## 10. Related Documentation

- [Compiler Pipeline & Language Toolchain](Compiler_Pipeline___Language_Toolchain.md) — upstream dependency; details of `parse`, `compile`, `compileModule`, `migrate`, and the warning/error catalogs (`errors.js`, `warnings.js`, message templates).
- [sandbox-playground-tooling](sandbox-playground-tooling.md) — parent module grouping the sandbox tooling scripts.
- [sandbox-playground-tooling share-link-hash](sandbox-playground-tooling_share-link-hash.md) — sibling module; gzip/base64url `compress()` for share links, inverted by the runner's companion `scripts/download.js`.
- [Engineering Tooling (Benchmarks, Verification & Playground)](Engineering_Tooling_(Benchmarks,_Verification___Playground).md) — grandparent module: reactivity/SSR benchmarks, treeshakeability checker, and the playground tooling family.
- [Client Runtime Engine (Reactivity & DOM Rendering)](Client_Runtime_Engine_(Reactivity___DOM_Rendering).md) — runtime targeted by `generate: 'client'` output.
- [Server-Side Rendering & Cross-Target Runtime Services](Server-Side_Rendering___Cross-Target_Runtime_Services.md) — runtime targeted by `generate: 'server'` output.
