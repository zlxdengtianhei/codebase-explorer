# Motion Module (`svelte/motion`)

## Overview

The **motion module** provides Svelte's animated-value primitives, published as the `svelte/motion` entry point. It implements two complementary animation models:

- **Spring motion** — physics-based animation (`spring` store, `Spring` class) where values accelerate/decelerate according to stiffness and damping, producing natural, velocity-aware motion.
- **Tweened motion** — time-based animation (`tweened` store, `Tween` class) where values travel from A to B over a fixed duration along an easing curve.

Both models share the same execution backbone: an animation loop driven by `requestAnimationFrame` (see the *Client Runtime Engine* module), reactive signal writes that update the UI, and a `Promise` that resolves once the animation settles. Each model exists in two generations:

| Generation | Spring | Tweened | Status |
|---|---|---|---|
| Legacy store contract | `spring(value, opts)` | `tweened(value, defaults)` | Deprecated since 5.8.0 |
| Modern class (runes) | `new Spring(value, opts)` / `Spring.of(fn)` | `new Tween(value, opts)` / `Tween.of(fn)` | Current, since 5.8.0 |

The module entry point (`index.js`) also exports `prefersReducedMotion`, a reactive `MediaQuery` that lets applications respect the user's OS-level reduced-motion preference (see the *Reactive Built-ins* module for `MediaQuery`).

## Purpose & Responsibilities

1. **Animate state over time** — turn discrete target-value changes into smooth sequences of intermediate values.
2. **Preserve the store contract for legacy code** — legacy `spring`/`tweened` factories wrap `writable` (see the *Stores* module) so they interoperate with `$store` auto-subscriptions.
3. **Expose rune-native classes** — `Spring`/`Tween` are built directly on internal signals (`state`/`set`/`get`), making their `target` and `current` accessors bindable (`bind:value={tween.target}`).
4. **Handle rich value types** — numbers, `Date`s, arrays and plain objects are animated recursively, element by element / key by key.
5. **Compose with the animation ecosystem** — tweened easing delegates to `svelte/easing`, and `prefersReducedMotion` integrates transitions (see the *Transitions, Animations & Easing* module) with accessibility preferences.

## Architecture Overview

```mermaid
flowchart TB
    subgraph motion["svelte/motion"]
        direction TB
        index["index.js<br/>public entry point<br/>re-exports + prefersReducedMotion"]

        subgraph spring_mod["Spring Motion — physics model"]
            spring_fn["spring() store<br/>(deprecated)"]
            spring_cls["Spring class<br/>(runes-based)"]
            tick["tick_spring()<br/>damped-spring integrator"]
            clamp["clamp()"]
        end

        subgraph tween_mod["Tweened Motion — time/easing model"]
            tweened_fn["tweened() store<br/>(deprecated)"]
            tween_cls["Tween class<br/>(runes-based)"]
            interp["get_interpolator()<br/>recursive interpolator builder"]
        end

        types["public.d.ts / private.d.ts<br/>API contracts: Spring, Tweened,<br/>SpringOpts, TweenedOptions, TickContext"]
        utils["utils.js<br/>is_date()"]
    end

    index --> spring_mod
    index --> tween_mod
    spring_fn --> tick
    spring_cls --> tick
    tick --> utils
    spring_cls --> clamp
    tweened_fn --> interp
    tween_cls --> interp
    interp --> utils
```

Both sub-modules follow the same layered shape — a deprecated store factory, a modern class, and a pure math kernel:

```mermaid
flowchart LR
    subgraph layers["Shared architecture per sub-module"]
        direction TB
        L1["Public API layer<br/>store factory (deprecated) · class + static of()"]
        L2["Animation engine<br/>rAF task via internal loop"]
        L3["Value math kernel<br/>spring physics · eased interpolation"]
        L1 --> L2 --> L3
        L3 --> S["Signal / store write<br/>(state·set or store.set)"]
    end
```

## Sub-modules

The module is split into two detailed sub-module documents, one per animation model. Full component-level documentation — including code walkthroughs of the deprecated factories, the class implementations, and the shared math kernels — lives in these files:

| Sub-module | Document | Core components |
|---|---|---|
| Spring motion | **[motion_spring.md](motion_spring.md)** | `spring.js` — `spring` store (deprecated), `Spring` class, `tick_spring` integrator |
| Tweened motion | **[motion_tweened.md](motion_tweened.md)** | `tweened.js` — `tweened` store (deprecated), `Tween` class, `get_interpolator` builder; type contract `Tweened` in `public.d.ts` |

**Spring motion** ([motion_spring.md](motion_spring.md)) solves Hooke's-law damped-spring equations each frame (`acceleration = stiffness × delta − damping × velocity`, scaled by inverse mass). It never knows its end time — it iterates until velocity and remaining delta fall below `precision`. Class-only options include `instant` (snap immediately) and `preserveMomentum` (continue trajectory for fling gestures).

**Tweened motion** ([motion_tweened.md](motion_tweened.md)) precomputes an interpolator function `(t) => T` between the start and target values, then each frame evaluates `interpolator(easing(elapsed / duration))`. It supports `delay`, constant or value-dependent `duration`, and a pluggable `interpolate` strategy.

### API surface at a glance

```mermaid
classDiagram
    class Spring~T~ {
        -state~T~ #current
        -state~T~ #target
        -state~number~ #stiffness
        -state~number~ #damping
        -state~number~ #precision
        +of(fn, options)$ Spring~U~
        +set(value, options) Promise~void~
        +target T
        +current T
        +stiffness number
        +damping number
        +precision number
    }
    class Tween~T~ {
        -state~T~ #current
        -state~T~ #target
        -TweenedOptions~T~ #defaults
        +of(fn, options)$ Tween~U~
        +set(value, options) Promise~void~
        +target T
        +current T
    }
    class spring_store {
        <<deprecated>>
        +set(value, opts) Promise~void~
        +update(fn, opts) Promise~void~
        +subscribe(fn) Unsubscriber
        +stiffness number
        +damping number
        +precision number
    }
    class tweened_store {
        <<deprecated>>
        +set(value, opts) Promise~void~
        +update(fn, opts) Promise~void~
        +subscribe(fn) Unsubscriber
    }
    class Tweened~T~ {
        <<interface>>
        +set(value, opts) Promise~void~
        +update(fn, opts) Promise~void~
    }
    Spring ..> spring_store : supersedes
    Tween ..> tweened_store : supersedes
    tweened_store ..|> Tweened : implements
```

The `Spring` type in `public.d.ts` uses **declaration merging**: a store-style `interface Spring<T>` (legacy `subscribe`/`update` surface) coexists with the `class Spring<T>` (the `target`/`current` surface) so the rename from store to class is non-breaking; the interface half will be removed in Svelte 6.

## Animation Execution Model

Both models share the same runtime flow; only the per-frame math differs:

```mermaid
sequenceDiagram
    participant U as Application code
    participant M as Spring / Tween (or legacy store)
    participant L as loop() — rAF task queue
    participant R as Reactive state / store
    participant V as UI subscribers

    U->>M: set(newTarget) / target = newTarget / Tween.of(fn) render_effect
    M->>M: merge options · record start time · abort superseded task
    M->>L: schedule per-frame callback (if not already running)
    loop every animation frame until settled
        L->>M: callback(now)
        M->>M: spring physics tick OR interpolator(easing(elapsed/duration))
        M->>R: write next value (set(state) or store.set)
        R-->>V: notify subscribers → DOM updates
    end
    L-->>M: task settles (returns false)
    M-->>U: Promise resolves when current reaches target
```

Guarantees shared by both engines:

- **Frame-time clamping** — elapsed time is clamped to 1/30 s so a blocked thread or inactive tab cannot make the animation jump "haywire".
- **Single-flight animation** — a new `set()` supersedes the in-flight task (store-based tween aborts the previous task; the `Spring` class rejects the previous deferred with `Aborted`).
- **Promise completion** — every `set()` returns a `Promise<void>` resolving when the animation finishes.
- **Rich value support** — `tick_spring` and `get_interpolator` both recurse through numbers, `Date`s (via timestamps), arrays and plain objects; unsupported/`null` values throw or snap.

## Module Dependencies

The motion module is a consumer of platform services from sibling modules; it owns no DOM logic itself.

```mermaid
flowchart LR
    subgraph motion_mod["Motion module"]
        API["spring / Spring / tweened / Tween"]
    end

    subgraph client_runtime["Client Runtime Engine module"]
        loop["loop() + raf — frame scheduling"]
        sig["state / set / get — signals"]
        eff["render_effect — Spring.of / Tween.of binding"]
        tag["tag — DEV signal tracing"]
    end

    subgraph stores_mod["Stores module"]
        wr["writable — legacy store contract"]
    end

    subgraph easing_mod["Transitions, Animations & Easing module"]
        lin["linear default easing"]
    end

    subgraph react_mod["Reactive Built-ins module"]
        mq["MediaQuery — prefersReducedMotion"]
    end

    shared["internal/shared/utils — deferred, noop"]

    API --> loop
    API --> sig
    API --> eff
    API --> tag
    API --> wr
    API --> lin
    index_mq["index.js: prefersReducedMotion"] --> mq
    API --> shared
```

| Dependency | Source | Used for |
|---|---|---|
| `writable` | `../store/shared/index.js` (Stores module) | Legacy `spring`/`tweened` subscribe/set plumbing |
| `loop`, `raf` | `../internal/client/loop.js`, `timing.js` (Client Runtime Engine) | Frame-synchronized animation tasks with `abort()`/`promise` |
| `state`, `set`, `get` | `../internal/client/reactivity/sources.js`, `runtime.js` | `Spring`/`Tween` reactive `current`/`target`/options signals |
| `render_effect` | `../internal/client/reactivity/effects.js` | `Spring.of()` / `Tween.of()` — re-set when source expression changes |
| `tag` | `../internal/client/dev/tracing.js` | DEV-mode signal naming for debugging/tracing |
| `linear` | `../easing/index.js` | Default easing curve for tweens |
| `MediaQuery` | `../reactivity/media-query.js` | `prefersReducedMotion` export |
| `deferred`, `noop` | `../internal/shared/utils.js` | Promise plumbing for animation completion |

> **Note** — motion values are pure reactive state: they neither mount DOM nor schedule effects beyond their own animation task. Integration with DOM rendering, transitions (`svelte/transition`) and FLIP animations (`svelte/animate`) happens in their respective modules.

## Usage Patterns

```svelte
<script>
    import { Tween, Spring, prefersReducedMotion } from 'svelte/motion';

    // declarative: follows `number` reactively
    const size = Tween.of(() => number, { duration: prefersReducedMotion.current ? 0 : 400 });

    // imperative: fling gesture with momentum
    const position = new Spring(0);
</script>

<input type="range" bind:value={size.target} />
<input type="range" bind:value={size.current} disabled />

<button onclick={(e) => position.set(e.clientX, { preserveMomentum: 300 })}>
    fling
</button>
```

Key idioms:

- **Bind `.target`, display `.current`** — the class pair is designed for two-way binding of the goal value while animating the observed value.
- **`X.of(fn)` for derived motion** — must run inside an effect root (e.g. component initialisation); a `render_effect` re-invokes `set()` whenever `fn`'s dependencies change.
- **Accessibility** — gate durations/physics on `prefersReducedMotion.current` or use `duration: 0` / `instant: true` to skip animation entirely.

## Related Documentation

- **Stores module** — the store contract (`Readable`, `Writable`) implemented by the deprecated factories and the type contract in `public.d.ts`.
- **Client Runtime Engine module** — `loop`, `raf`, signals (`state`/`set`/`get`), `render_effect`, and DEV tracing used as the animation backbone.
- **Transitions, Animations & Easing module** — easing functions accepted by `TweenedOptions.easing`, plus CSS/FLIP alternatives for enter/exit and layout animation.
- **Reactive Built-ins module** — `MediaQuery`, which powers `prefersReducedMotion`.
