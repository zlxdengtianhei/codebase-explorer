# Benchmark Comparison (`benchmark_comparison`)

## 1. Overview

The `benchmark_comparison` module is the **orchestration layer of Svelte's benchmarking infrastructure**. It provides a small CLI driver (`benchmarking/compare/index.js`) that:

1. Benchmarks the current reactivity engine implementation **across multiple git branches** by checking out each branch and executing the shared benchmark runner in a child process.
2. Persists per-branch measurement results as JSON.
3. Renders a comparative **ASCII bar-chart report** (wall-clock `time` and GC `gc_time`) so maintainers can quantify the performance impact of a change (e.g. a feature branch vs. `main`).

It sits inside the **Engineering Tooling** umbrella of the repository, alongside the suites it measures and the sibling verification/playground tools.

| | |
|---|---|
| **Module path** | `benchmarking/compare/` |
| **Entry point** | `benchmarking/compare/index.js` (run directly with Node) |
| **Core component** | `char(index)` — chart label helper (`0 → 'a'`, `1 → 'b'`, …) |
| **Companion file** | `benchmarking/compare/runner.js` — forked child process |
| **Runtime requirements** | Node.js (ESM, top-level `await`), `git` CLI on `PATH`, `v8-natives` dependency |
| **Artifacts** | `benchmarking/compare/.results/<branch>.json` (ephemeral, wiped every run) |

---

## 2. Module Composition

| File | Role | Process |
|---|---|---|
| `benchmarking/compare/index.js` | CLI orchestrator: argument parsing, branch switching, child-process management, result persistence, comparison & report rendering. Exports nothing — executed as a top-level script. | Parent |
| `benchmarking/compare/runner.js` | Benchmark executor: imports the `reactivity_benchmarks` registry from the *currently checked-out* working tree, runs each suite, and returns the results array to the parent over IPC (`process.send`). | Child (forked) |
| `benchmarking/compare/.results/` | Generated output directory; removed and recreated at the start of every invocation. | — |

> The runner is intentionally *not* bundled into the parent: forking lets each branch's code (runner, benchmark suites and the engine they exercise) be loaded fresh from the checked-out working tree, while the parent — the comparison/reporting logic — stays fixed.

---

## 3. Architecture

```mermaid
graph TB
    subgraph OPS["Operator / CI shell"]
        OP[("node benchmarking/compare<br/>[branch…] [--flags]")]
    end

    subgraph PARENT["Parent process — compare/index.js (orchestrator)"]
        ARGS["Branch argument resolution"]
        GIT["git via execSync<br/>(checkout, current-branch detection)"]
        STORE[(".results/&lt;branch&gt;.json")]
        REPORT["Comparison engine +<br/>ASCII report renderer"]
        CHAR["char(i)<br/>label helper"]
    end

    subgraph CHILD["Child process — compare/runner.js (forked via child_process.fork)"]
        RUN["Iterate registry, await each benchmark,<br/>process.send(results)"]
    end

    subgraph SUITES["Measured suites — benchmarking/benchmarks/reactivity"]
        REG["reactivity_benchmarks<br/>(28 benchmark functions)"]
    end

    subgraph INFRA["Shared timing infrastructure"]
        UTIL["benchmarking/utils.js<br/>fastest_test / run_tracked / GarbageTrack"]
    end

    subgraph SUT["System under test"]
        ENGINE["packages/svelte/src/internal/client<br/>(reactivity engine, imported from source)"]
    end

    OP --> ARGS
    ARGS --> GIT
    GIT -.->|"working tree now holds branch code"| RUN
    ARGS -->|"fork(runner.js)"| RUN
    RUN --> REG
    REG --> UTIL
    REG --> ENGINE
    UTIL -->|"v8-natives: forced GC,<br/>perf_hooks: timing + GC observer"| ENGINE
    RUN -->|"IPC message: results[]"| STORE
    STORE --> REPORT
    REPORT --> CHAR
    REPORT -->|"console.group / console.log"| OP
```

**Key architectural decision:** the benchmarks import the engine **directly from source** (`packages/svelte/src/internal/client/index.js`), not from a build artifact. Because the runner is forked *after* `git checkout`, each fork transparently measures whatever engine implementation the checked-out branch contains — no rebuild step is required. See [client-reactivity-engine](client-reactivity-engine.md) for the engine being measured.

---

## 4. Command-Line Interface

### 4.1 Usage

```bash
# current branch vs main
node benchmarking/compare

# explicit branches (labels a, b, c… follow argument order)
node benchmarking/compare my-feature main

# any number of branches (up to 26 due to letter labels)
node benchmarking/compare a-branch another-branch third-branch
```

### 4.2 Argument parsing rules

| Input | Behaviour |
|---|---|
| Argument starting with `--` | Ignored (reserved for future flags). |
| Argument equal to the script's own path (`filename`) | Skipped. |
| Any other argument | Added to `branches` in order. |
| **No** branch arguments | `branches = [<current git branch>, 'main']` (current branch detected via `git symbolic-ref --short -q HEAD`, falling back to `git rev-parse --short HEAD`). |
| **One** branch argument | `'main'` is appended as the comparison baseline. |

### 4.3 Side effects

1. **Working tree mutation** — the tool literally checks out each branch with `execSync` before forking the runner.
2. **`.results/` is destroyed and recreated** on every run; results of previous comparisons are never reused.
3. **Exit hook** — a `process.on('exit')` handler runs `git checkout <branches[0]>`, restoring the *first* branch in the list when the process terminates.

---

## 5. Execution Flow

### 5.1 Branch resolution and setup

```mermaid
flowchart TD
    A(["Start: node benchmarking/compare …"]) --> B["Collect positional CLI args<br/>(skip --flags and script path)"]
    B --> C{"branches.length?"}
    C -->|"0"| D["branches =<br/>[current branch, 'main']"]
    C -->|"1"| E["branches.push('main')"]
    C -->|">= 2"| F["use args as-is"]
    D --> G
    E --> G
    F --> G["Register exit hook:<br/>git checkout branches[0]"]
    G --> H["Delete + recreate<br/>benchmarking/compare/.results/"]
    H --> I["For each branch:<br/>checkout → fork runner → await IPC results"]
    I --> J["Load all JSON files,<br/>render comparison report"]
    J --> K(["Process exit: hook restores branches[0]"])
```

### 5.2 End-to-end run (sequence)

```mermaid
sequenceDiagram
    autonumber
    participant O as Operator
    participant P as compare/index.js<br/>(orchestrator)
    participant G as git CLI
    participant R as runner.js<br/>(forked child)
    participant B as reactivity_benchmarks<br/>(28 suites)
    participant U as benchmarking/utils.js<br/>(fastest_test, GarbageTrack)
    participant E as svelte/internal/client<br/>(engine under test)

    O->>P: node benchmarking/compare [branch…]
    P->>P: resolve branches, register exit hook, reset .results/
    loop per branch
        P->>G: git checkout <branch>
        G-->>P: working tree updated
        P->>R: fork(runner.js)
        loop for each of 28 benchmarks
            R->>B: await benchmark()
            B->>E: build signal graphs, set sources, flush effects
            B->>U: fastest_test(10, fn)
            U->>U: v8.collectGarbage(), time fn,<br/>observe 'gc' PerformanceObserver entries
            U-->>B: { time, gc_time }
            B-->>R: { benchmark, time: "xx.xx", gc_time: "xx.xx" }
            R-->>O: progress: benchmark name on stderr
        end
        R-->>P: IPC: process.send(results[])
        P->>P: write .results/<branch>.json (pretty-printed)
    end
    P->>P: read all .json files, compare per benchmark × metric
    P-->>O: ASCII bar-chart report (labels a, b, c …)
    P->>G: exit hook → git checkout branches[0]
```

### 5.3 Metric rendering

```mermaid
flowchart LR
    A["One results[] array<br/>per branch"] --> B["Outer loop i over<br/>results[0] (benchmark index)"]
    B --> C["Metric loop:<br/>'time' then 'gc_time'"]
    C --> D["Coerce with unary +,<br/>track min / max / min_index"]
    D --> E{"min !== 0 ?"}
    E -->|"no — e.g. gc_time = 0<br/>(no GC pauses observed)"| C
    E -->|"yes"| F["'fastest is a (branch)'"]
    F --> G["Bar: n = round(20 × time / max),<br/>print 'a: ◼◼◼… 123.45ms'"]
    G --> C
```

---

## 6. Core Components

### 6.1 `char(index)` — chart label helper

```javascript
function char(i) {
    return String.fromCharCode(97 + i);
}
```

Maps a zero-based branch index to a lowercase letter (`0 → 'a'`, `1 → 'b'`, …). It is the visual "legend" of the report: every bar line and the *"fastest is X (branch-name)"* annotation use the same letter, while the console group headers (`console.group(\`Benchmarking ${branch}\`)`) establish which letter belongs to which branch (argument order). This keeps the bar chart compact when comparing many branches. The practical ceiling is 26 branches (`'a'`–`'z'`).

### 6.2 Orchestrator responsibilities (`index.js`)

| Responsibility | Mechanism |
|---|---|
| Branch discovery | Positional `process.argv` filtering + `git symbolic-ref` / `git rev-parse` fallback |
| Tree switching | `execSync('git checkout <branch>')` per branch |
| Child execution | `fork(runner)`; a Promise resolves on the child's IPC `message`, rejects on child `error` |
| Result persistence | `fs.writeFileSync('.results/<branch>.json', JSON.stringify(results, null, 2))` |
| Comparison | For each benchmark index and each metric: unary `+` coercion → min / max / argmin |
| Rendering | `console.group` nesting + fixed-width bars (`SIZE = 20`) scaled by `time / max` |
| Cleanup | `process.on('exit')` → restore `branches[0]` |

### 6.3 Runner (`runner.js`) — companion component

```javascript
const results = [];
for (const benchmark of reactivity_benchmarks) {
    const result = await benchmark();
    console.error(result.benchmark);   // progress on stderr
    results.push(result);
}
process.send(results);                 // IPC back to parent
```

The runner has no branching logic of its own — it is a thin executor over the suite registry. Progress is written to **stderr** so it can be separated from the parent's stdout report when piping output.

---

## 7. Data Contracts

### 7.1 Benchmark result record

Each benchmark function returns (and the runner forwards verbatim over IPC):

```json
{
  "benchmark": "kairo_avoidable_unowned",
  "time": "1842.55",
  "gc_time": "37.20"
}
```

| Field | Type | Meaning |
|---|---|---|
| `benchmark` | `string` | Suite name, used as the report group header |
| `time` | `string` (2 dp) | Wall-clock milliseconds of the **fastest of N repetitions** (`fastest_test`) |
| `gc_time` | `string` (2 dp) | Summed duration of GC pause events whose start fell inside the timed window of that same fastest run |

Strings are produced by `toFixed(2)` in the suites; the comparison layer coerces them back to numbers with the unary `+` operator before min/max calculations.

### 7.2 Timing pipeline (shared infra)

`benchmarking/utils.js` provides the measurement primitives consumed by every suite:

- `v8.collectGarbage()` before each timed repetition to reduce cross-run GC noise.
- A `PerformanceObserver` on the `'gc'` entry type records all GC pauses; those overlapping the measured period are summed into `gc_time`.
- `fastest_test(times, fn)` keeps the best repetition, minimizing scheduler jitter.
- Suites additionally run warm-up iterations to trigger JIT optimization before timing.

### 7.3 Persisted format

`​.results/<branch>.json` — a JSON array of §7.1 records in registry order. Because branch checkouts change the registry contents, **results are compared strictly by array index**: the report iterates `results[0].length` and assumes every branch produced the same benchmarks in the same order.

---

## 8. Report Output Format

For every benchmark the tool prints two groups (`time` first, then `gc_time`; a metric is skipped entirely when the fastest value is `0`, which happens for `gc_time` when no garbage was collected during the winning run):

```text
kairo_avoidable_unowned
  time: fastest is b (main)
  a: ◼◼◼◼◼◼◼◼◼◼◼◼◼◼◼◼◼   212.51ms
  b: ◼◼◼◼◼◼◼◼◼◼◼◼◼◼◼      183.04ms
  gc_time: fastest is a (my-feature)
  a: ◼                     12.40ms
  b: ◼◼                    18.75ms
```

- Letters (`a`, `b`, …) map to branch order (established by the per-branch `Benchmarking <branch>` console groups during collection).
- Bar width is `round(20 × time / max_time)` — the slowest branch always renders a full 20-cell bar; padding spaces keep numeric values aligned.
- The `fastest is` line names both the winning letter and the winning branch.

---

## 9. Design Notes, Assumptions & Caveats

1. **Checkout-based isolation** — the tool compares code by swapping the working tree, not by building packages. This works because the reactivity suites import the engine from source; it also means any *uncommitted changes are silently discarded* on the first checkout. A working-directory cleanliness guard exists in the source but is commented out — run the tool from a clean tree for trustworthy results.
2. **Index-based alignment** — if branches add, remove, or reorder benchmarks in the registry, columns of the report will misalign silently (the loops are driven by `results[0]`).
3. **Child failure aborts the run** — a crashed runner rejects the awaited Promise; there is no retry or partial-report fallback (already-written `.results/*.json` files remain on disk).
4. **Restore semantics** — the exit hook checks out `branches[0]`. When you pass exactly one branch, that means you *finish on the branch you asked to benchmark*, not on the branch you started from.
5. **Fork resolution timing** — `fork(runner)` resolves the runner path at fork time, so the child always executes the code of the just-checked-out branch; the parent script itself is never reloaded.
6. **Environment sensitivity** — timings depend on the machine, Node version, and background load; comparisons are only meaningful within a single session (all branches measured back-to-back by the same invocation).

---

## 10. Relationship to Other Modules

| Module | Relationship |
|---|---|
| [reactivity_benchmarks](reactivity_benchmarks.md) | **Measured payload.** The runner executes exactly the `reactivity_benchmarks` registry (10 `sbench` variants, 16 `kairo` graph-topology variants, 2 `mol_bench` variants) exported by this module. Suite composition and result-shape guarantees live there — this module only orchestrates and renders. |
| [client-reactivity-engine](client-reactivity-engine.md) | **System under test.** Benchmarks drive the engine's internal API (`$.state`, `$.derived`, `$.effect_root`, `$.render_effect`, `$.set`, `$.get`, `$.flush`) straight from source, so the report measures each branch's runtime implementation. |
| [ssr_benchmarks](ssr_benchmarks.md) | **Sibling suite.** `wrapper_bench` shares `fastest_test` from `benchmarking/utils.js` and emits the identical `{ benchmark, time, gc_time }` contract, but is *not* currently wired into the compare runner (which imports only the reactivity registry). Extending the runner to include it would only require appending the registry. |
| [treeshakeability_checker](treeshakeability_checker.md) | Sibling engineering tool; bundling-based verification of the published surface. Independent of this module. |
| [sandbox-playground-tooling](sandbox-playground-tooling.md) | Sibling engineering tool for interactive experimentation. Independent of this module. |

---

## 11. Summary

`benchmark_comparison` is a deliberately small, dependency-light orchestration module: it converts *git branches* into *benchmark runs* by combining shell-level checkouts with a forked runner, then turns numeric JSON results into a human-readable letter-labeled bar chart. All domain knowledge — which graphs to build, how to time them, what the engine does — is delegated to the [reactivity_benchmarks](reactivity_benchmarks.md) suites, [client-reactivity-engine](client-reactivity-engine.md) internals, and the shared `benchmarking/utils.js` timing infrastructure, keeping this module focused purely on **comparison and reporting**.
