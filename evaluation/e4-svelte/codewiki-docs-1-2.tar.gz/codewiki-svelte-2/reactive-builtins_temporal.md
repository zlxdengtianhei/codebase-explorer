# Reactive Built-ins — Temporal (`reactive-builtins_temporal`)

## 1. Introduction

The `reactive-builtins_temporal` module provides **`SvelteDate`** — a drop-in, reactive subclass of the JavaScript built-in [`Date`](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Date). It lives in a single source file:

- `packages/svelte/src/reactivity/date.js` → exports `SvelteDate`

`SvelteDate` lets Svelte applications treat dates as reactive state: reading a `SvelteDate` inside an [effect](https://svelte.dev/docs/svelte/$effect) or [derived](https://svelte.dev/docs/svelte/$derived) (including indirectly, e.g. via `Intl.DateTimeFormat.format(date)`) automatically establishes a signal dependency, so the consumer re-runs whenever the date is mutated through any of its `set*` methods.

The module is deliberately small in surface area but is a precise integration point with the [Client Runtime Engine (Reactivity & DOM Rendering)](client-runtime-engine-reactivity-dom-rendering.md): it wraps the engine's *source* (`state`/`set`) and *derived* signal primitives around the native `Date` API without duplicating any of `Date`'s logic.

> This module is one of four reactive built-ins exported from `svelte/reactivity`. See the parent overview [Public API & Built-in Feature Surface](public-api-builtin-feature-surface.md) and the sibling modules:
> - [`reactive-builtins_collections`](reactive-builtins_collections.md) — `SvelteMap`
> - [`reactive-builtins_url`](reactive-builtins_url.md) — `SvelteURL`, `SvelteURLSearchParams`
> - [`reactive-builtins_media-query`](reactive-builtins_media-query.md) — `MediaQuery`, `createSubscriber`

---

## 2. Design Goals

| Goal | How it is achieved |
|---|---|
| **Full API compatibility** | `SvelteDate extends Date`; native behavior is preserved for every method. |
| **Automatic dependency tracking** | Reads (`get*`, `to*`, `valueOf`) are routed through the signal graph; writes (`set*`) update a single source signal. |
| **Zero-cost when unused** | Per-method `derived` signals are created **lazily**, only for methods that are actually read, and only when called with **no arguments**. |
| **Correct ownership/lifetime** | Lazily created `derived`s are registered under the reaction that was active at construction time (`#reaction`), not the reaction of the first reader — preventing mis-owned effects and memory leaks. |
| **Single source of truth** | All mutations funnel through one `#time` source (epoch milliseconds); every getter derives from it. |
| **Production efficiency** | Dev-only instrumentation (`tag`) is guarded by `esm-env`'s `DEV` flag so it is tree-shaken from production bundles. |

---

## 3. Architecture

### 3.1 Class structure

```mermaid
classDiagram
    class Date {
        <<native>>
        +getTime() number
        +setTime(ms) number
        +get*/to*/valueOf() value
        +set*() number
    }
    class SvelteDate {
        -Source #time
        -Map~string, Derived~ #deriveds
        -Reaction #reaction
        +constructor(params)
        -init()$ %one-time prototype patch%
    }
    class Source_#time {
        <<signal: source>>
        epoch milliseconds
    }
    class Derived_getFullYear {
        <<signal: derived, lazy>>
        reads #time
    }
    class Derived_toISOString {
        <<signal: derived, lazy>>
        reads #time
    }
    class Derived_valueOf {
        <<signal: derived, lazy>>
        reads #time
    }
    Date <|-- SvelteDate : extends
    SvelteDate *-- "1" Source_#time : owns
    SvelteDate o-- "0..n per method" Derived_getFullYear : memoizes
    SvelteDate o-- "0..n per method" Derived_toISOString : memoizes
    SvelteDate o-- "0..n per method" Derived_valueOf : memoizes
```

### 3.2 Key components

| Component | Kind | Role |
|---|---|---|
| `#time` | private field, **source signal** created via `state(super.getTime())` | The canonical reactive value: the date as epoch milliseconds. Every write invalidates everything derived from the date. |
| `#deriveds` | private `Map<method, Derived>` | Per-instance memoization of lazily created derived signals, one entry per *zero-argument getter method that has been read*. |
| `#reaction` | private field capturing `active_reaction` at construction | Ownership anchor: deriveds are created *as if* during the constructor's reaction context. |
| `#init()` | private, runs **once per module** (guarded by module-level `inited` flag) | Patches `SvelteDate.prototype` (never `Date.prototype`) by wrapping every native `Date.prototype` method in tracked read/write logic. |
| `constructor(...params)` | forwards all parameters to `super(...)` unchanged | `new SvelteDate()` behaves exactly like `new Date()`; in `DEV`, `#time` is labelled for tracing. |

### 3.3 Prototype patching rules (applied once by `#init()`)

For every method name on `Date.prototype`:

- **`get*`, `to*`, and `valueOf`** → **tracked read** (see §4.1).
- **`set*`** → **tracked write** (see §4.2).
- Anything else (e.g. `Symbol.toPrimitive` quirks, statics like `Date.now`/`Date.parse`) → untouched; statics live on `Date`, not `Date.prototype`, so they are inherently non-reactive.

---

## 4. Runtime Behavior

### 4.1 Read path (getters: `get*`, `to*`, `valueOf`)

```mermaid
flowchart TD
    A["date.method() called"] --> B{"Arguments present?"}
    B -- "yes (e.g. getTimezoneOffset edge cases)" --> C["get(#time) — track the date<br/>then call native method directly<br/>(no memoization)"]
    B -- no --> D{"#deriveds.has(method)?"}
    D -- yes --> E["get(d) — reuse cached derived"]
    D -- no --> F["Save current active_reaction"]
    F --> G["set_active_reaction(#reaction)<br/>(adopt constructor-time ownership)"]
    G --> H["derived(() => { get(#time);<br/>return Date.prototype[method].apply(this) })"]
    H --> I["Store in #deriveds map"]
    I --> J["Restore previous active_reaction"]
    J --> K["get(d) — registers dependency<br/>on the active effect/derived"]
    C --> L["Value returned to caller"]
    E --> L
    K --> L
```

Two read modes exist:

1. **Memoized read (no arguments)** — the common case. A `derived` signal is created lazily (once per method per instance) that internally reads `#time` and applies the native method. The outer call then performs `get(d)`, which registers `d` as a dependency of the currently active reaction (effect, derived, or template effect). Because the derived is cached, repeated reads are cheap and deduplicated by the signal graph.
2. **Unmemoized read (with arguments)** — the value may be argument-dependent, so the derived layer is skipped: `#time` is still tracked (via `get(this.#time)`) and the native method is applied directly. Tracking still guarantees correctness of invalidation.

### 4.2 Write path (`set*` mutators)

```mermaid
flowchart TD
    A["date.setHours(9) called"] --> B["Call native Date.prototype.setHours.apply(this, args)"]
    B --> C["set(#time, Date.prototype.getTime.call(this))<br/>— one source write with fresh epoch ms"]
    C --> D{"Inside a derived /<br/>block effect?"}
    D -- yes --> E["state_unsafe_mutation error<br/>(engine safety check inside set)"]
    D -- no --> F["#time marked dirty"]
    F --> G["All memoized deriveds in #deriveds<br/>marked dirty (batched)"]
    G --> H["Dependent effects scheduled<br/>via batch → loop → microtask flush"]
    H --> I["Effects re-run, re-read getters,<br/>re-subscribe to updated deriveds"]
    B --> J["Native result (epoch ms) returned to caller"]
```

The write path has a deliberately **coarse invalidation granularity**: every `set*` method computes the new epoch milliseconds and writes it into the single `#time` source. This means any mutation invalidates all derived reads of the date — simple, predictable, and immune to inconsistencies (e.g. a `setFullYear` that also shifts the time value).

### 4.3 End-to-end reactive cycle

```mermaid
sequenceDiagram
    participant C as Component init
    participant D as SvelteDate instance
    participant S as #time (source)
    participant R as Signal graph (runtime)
    participant E as $effect / $derived consumer

    C->>D: new SvelteDate() (inside active reaction)
    D->>S: state(super.getTime())
    Note over D: #reaction = active_reaction (ownership anchor)

    E->>D: date.getTime() (during effect run)
    D->>R: lazily create derived (owned by #reaction)
    D->>R: get(derived) → dependency registered on E
    R-->>E: epoch ms

    Note over E: e.g. Intl.DateTimeFormat.format(date) triggers internal get*/to* reads
    C->>D: setInterval(() => date.setTime(Date.now()))
    D->>D: native setTime
    D->>S: set(#time, getTime())
    S->>R: mark dirty → batch schedules effects
    R->>E: re-run effect (reads re-execute)
```

---

## 5. Dependencies

### 5.1 Dependency graph

```mermaid
graph LR
    subgraph "reactive-builtins_temporal"
        SD["date.js<br/>SvelteDate"]
    end

    subgraph "Client Runtime Engine (see client-runtime-engine-reactivity-dom-rendering.md)"
        RT["runtime.js<br/>active_reaction · get · set_active_reaction<br/>(signal graph, dependency registration)"]
        SRC["reactivity/sources.js<br/>state · set<br/>(source signals, write safety checks)"]
        DRV["client/index.js re-export → deriveds.js<br/>derived<br/>(lazy memoized computations)"]
        TRC["dev/tracing.js<br/>tag<br/>(DEV signal labelling)"]
    end

    ENV["esm-env<br/>DEV flag<br/>(tree-shake dev code)"]
    NATIVE["Native Date<br/>Date.prototype"]

    SD -->|"derived"| DRV
    SD -->|"state, set"| SRC
    SD -->|"active_reaction, get, set_active_reaction"| RT
    SD -->|"tag (DEV only)"| TRC
    SD -->|"feature flag"| ENV
    SD -->|"extends / delegates all logic"| NATIVE
    DRV -.-> RT
    SRC -.-> RT
```

### 5.2 Dependency detail

| Import | Provider module | Why it is needed |
|---|---|---|
| `derived` | `../internal/client/index.js` (re-export of the deriveds primitive) | Creates the per-method memoized computations that read `#time`. |
| `state`, `set` | `../internal/client/reactivity/sources.js` | `state` creates the `#time` source; `set` performs writes with the engine's safety checks (e.g. `state_unsafe_mutation` when mutating during a derived read). |
| `active_reaction`, `get`, `set_active_reaction` | `../internal/client/runtime.js` | `active_reaction` is captured at construction for ownership; `get` performs tracked reads and dependency registration; `set_active_reaction` temporarily restores the constructor-time reaction while lazily creating deriveds. |
| `tag` | `../internal/client/dev/tracing.js` | In `DEV`, labels the `#time` signal (`'SvelteDate.#time'`) so it is identifiable in tracing/devtools output. |
| `DEV` | `esm-env` | Compile-time feature flag; ensures `tag`-related code is stripped from production builds. |

All heavy lifting (dirty checking, batching, effect scheduling, dependency bookkeeping) is delegated to the reactivity engine — this module contains **no scheduling or graph logic of its own**. For the engine internals (signal graph, batching/scheduling, sources & proxies), see [Client Runtime Engine (Reactivity & DOM Rendering)](client-runtime-engine-reactivity-dom-rendering.md).

---

## 6. Design Decisions & Invariants

1. **Patch the subclass prototype, never `Date.prototype`.**
   `#init()` writes overrides onto `SvelteDate.prototype`. Native `Date` instances are completely unaffected, and all `SvelteDate` instances share the patched methods (no per-instance closures for getters/setters).

2. **One-time initialization.**
   The module-level `inited` boolean guarantees `#init()` runs once per module load regardless of how many instances are created.

3. **Laziness of deriveds.**
   A `derived` per method is created only on first zero-argument read. Applications that never call `getFullYear` never pay for it. The `#deriveds` map grows proportionally to the *methods actually used*, not to the `Date` API surface (~45 methods).

4. **Ownership anchoring via `#reaction`.**
   Without `set_active_reaction(this.#reaction)`, a lazily created derived would be owned by whichever effect first read it — potentially a different component. That would produce leaks (a short-lived reader keeps deriveds alive) or premature teardown. Anchoring to the constructor's reaction makes the deriveds behave as though they were created with the instance itself.

5. **Single `#time` source ⇒ coarse invalidation.**
   All setters converge on `set(#time, getTime())`. Correctness is trivially maintained (one source of truth); the trade-off is that changing one field (e.g. minutes) invalidates deriveds of unrelated fields (e.g. `getFullYear`). This is accepted because date reads are cheap and the simplification eliminates an entire class of partial-update bugs.

6. **Argument-dependent reads skip memoization.**
   `getMonth()` (0 args) is cacheable; anything called with arguments is computed on demand after still tracking `#time`, since caching a keyed result per argument set is not worth the complexity.

7. **Dev observability.**
   `tag(this.#time, 'SvelteDate.#time')` gives the source signal a human-readable label, which surfaces in tracing mode (`tracing_mode_flag`), `$inspect` output, and reactivity-loss warnings — all governed by the `DEV` flag from `esm-env` so production builds carry no overhead.

8. **Static methods are intentionally not reactive.**
   `Date.now()` and `Date.parse()` are functions on the constructor, not instance state; there is nothing to invalidate, so they remain native.

---

## 7. Integration with the Overall System

### 7.1 Position in the public API

```mermaid
graph TD
    PUB["Public API & Built-in Feature Surface<br/>(public-api-builtin-feature-surface.md)"] --> RB["svelte/reactivity<br/>reactive-builtins"]
    RB --> COLL["reactive-builtins_collections<br/>SvelteMap"]
    RB --> TEMP["reactive-builtins_temporal<br/>SvelteDate ← this module"]
    RB --> URL["reactive-builtins_url<br/>SvelteURL · SvelteURLSearchParams"]
    RB --> MQ["reactive-builtins_media-query<br/>MediaQuery · createSubscriber"]
    TEMP --> CRE["Client Runtime Engine<br/>(client-runtime-engine-reactivity-dom-rendering.md)"]
    COLL -.->|"same engine primitives"| CRE
    URL -.->|"same engine primitives"| CRE
    MQ -.->|"createSubscriber / effect_root"| CRE
    TEMP -.->|"SvelteDate type re-exported"| TYPES["svelte-public-types<br/>packages/svelte/types/index.d.ts"]
```

- **Consumer-facing export:** `import { SvelteDate } from 'svelte/reactivity'`. The class type is also re-exported through the package-level type barrel (`packages/svelte/types/index.d.ts`).
- **Compiler independence:** unlike most of the framework, `SvelteDate` needs no compiler support — it is pure runtime composition over the engine's signal primitives. Compiled template code interacts with it exactly as with any reactive value: reads inside template expressions become template effects, which track the per-method deriveds, which track `#time`.
- **Interop with standard APIs:** because `SvelteDate` *is* a `Date`, standard consumers work out of the box — `Intl.DateTimeFormat.format(date)`, `date.toJSON()`, `+date` (via overridden `valueOf`), `Date` comparison helpers, etc. — and all of those internal reads are tracked automatically.

### 7.2 Relation to sibling reactive built-ins

All four built-ins follow the same pattern: wrap a platform object, route reads through the signal graph and writes through `set`/internal invalidation, and label signals in `DEV`. Differences:

| Built-in | Wrapper strategy | Invalidation granularity |
|---|---|---|
| `SvelteMap` (this module's sibling, [docs](reactive-builtins_collections.md)) | Proxy-like subclass delegating to an inner `Map` | Per-key / per-size sources |
| **`SvelteDate`** (this module) | Subclass + one-time prototype patch | **Single `#time` source (coarse)** |
| `SvelteURL` / `SvelteURLSearchParams` ([docs](reactive-builtins_url.md)) | Subclass + per-field sources | Per-property |
| `MediaQuery` ([docs](reactive-builtins_media-query.md)) | Event-driven external source (`matchMedia`) | External change events via `createSubscriber` |

### 7.3 Performance context

The underlying `state`/`set`/`derived`/`get` primitives used here are exercised directly by the reactivity benchmark suite (see [Engineering Tooling — Benchmarks, Verification & Playground](engineering-tooling-benchmarks-verification-playground.md)), which keeps the cost of `SvelteDate` reads/writes aligned with overall engine performance targets (kairo/sbench graph topologies: diamond, triangle, repeated, etc.).

---

## 8. Usage Notes, Edge Cases & Limitations

**Typical usage** (from the class JSDoc):

```svelte
<script>
	import { SvelteDate } from 'svelte/reactivity';

	const date = new SvelteDate();

	const formatter = new Intl.DateTimeFormat(undefined, {
		hour: 'numeric', minute: 'numeric', second: 'numeric'
	});

	$effect(() => {
		const interval = setInterval(() => date.setTime(Date.now()), 1000);
		return () => clearInterval(interval);
	});
</script>

<p>The time is {formatter.format(date)}</p>
```

**Edge cases to be aware of:**

- **Mutation inside a derived** (or other block effect) triggers the engine's `state_unsafe_mutation` error — inherited from `set`'s safety checks. Mutate in effects/handlers instead.
- **`toString()`-family reads are memoized per instance** (`toString`, `toISOString`, `toLocaleString`, …). After any `set*`, all memoized values invalidate together (coarse granularity, §6.5).
- **Zero-argument reads are the only memoized ones**; `getTimezoneOffset()` and other getters called with arguments compute directly while still tracking `#time`.
- **`instanceof Date` is `true`** — `SvelteDate` can be passed anywhere a `Date` is expected.
- **Serialization caveat:** `JSON.stringify(date)` invokes `toJSON()` *outside* a tracked reaction (e.g. during snapshot/serialization), so the resulting string is a plain value, not reactive — same as with `$state.snapshot` semantics elsewhere in Svelte.
- **Statics stay native:** `Date.now()` and `Date.parse()` are unaffected and untracked.
- **Tree-shaking:** dev-only paths are guarded by `esm-env`'s `DEV`; production bundles contain only the source/derived wiring. The module is designed to be side-effect-free apart from the idempotent prototype patch that runs on first instantiation (`#init` is invoked from the constructor, not at module evaluation).

---

## 9. Related Documentation

- [Public API & Built-in Feature Surface](public-api-builtin-feature-surface.md) — parent module: the full `svelte` export surface, including stores, motion, transitions, and the reactivity built-ins group.
- [reactive-builtins_collections](reactive-builtins_collections.md) — `SvelteMap`.
- [reactive-builtins_url](reactive-builtins_url.md) — `SvelteURL`, `SvelteURLSearchParams`.
- [reactive-builtins_media-query](reactive-builtins_media-query.md) — `MediaQuery`, `createSubscriber`.
- [Client Runtime Engine (Reactivity & DOM Rendering)](client-runtime-engine-reactivity-dom-rendering.md) — the signal graph, sources (`state`/`set`), deriveds, batching/scheduling, and dev tracing primitives this module builds upon.
- [Engineering Tooling (Benchmarks, Verification & Playground)](engineering-tooling-benchmarks-verification-playground.md) — reactivity benchmarks covering the engine primitives used by `SvelteDate`.
