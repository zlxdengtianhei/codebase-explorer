# stores_contract

## Overview

`stores_contract` is the **declarative type-contract layer** of the Svelte store subsystem. It contains no runtime logic at all — it defines, in pure TypeScript, the *store contract*: the minimal, duck-typed interface (`Readable` / `Writable`) that any object must satisfy to participate in Svelte's reactivity, plus the private type utilities (`Stores`, `StoresValues`) used to express "one or more stores" signatures throughout the store implementation.

Because the contract is expressed structurally (interfaces, not classes), **any library's observable can act as a Svelte store** — this is what enables transparent interoperability with RxJS and similar ecosystems.

The module lives at:

- `packages/svelte/src/store/public.d.ts` — public contract types (`Writable`, `Readable`, `Subscriber`, `Unsubscriber`, `Updater`, `StartStopNotifier`)
- `packages/svelte/src/store/private.d.ts` — internal type utilities (`Stores`, `StoresValues`, `SubscribeInvalidateTuple`)

It is a leaf module of the `stores` subsystem under [Public_API___Built-in_Feature_Surface](public-api.md), consumed by [stores_core](stores_core.md) (the reference implementation) and [stores_bridge](stores_bridge.md) (runes ⇄ store adapters).

---

## Core Components

### Public contract (`public.d.ts`)

| Type | Kind | Purpose |
|---|---|---|
| `Subscriber<T>` | Type alias | Callback `(value: T) => void` invoked on every value update (and once immediately on subscribe). |
| `Unsubscriber` | Type alias | `() => void` returned by `subscribe`; calling it detaches the subscription. |
| `Updater<T>` | Type alias | Callback `(value: T) => T` used by `Writable.update` to compute the next value from the current one. |
| `StartStopNotifier<T>` | Type alias | Optional start/stop hook: called with `(set, update)` when the **first** subscriber subscribes; may return a cleanup function invoked when the **last** subscriber unsubscribes. |
| `Readable<T>` | Interface | The minimal contract: `subscribe(this: void, run: Subscriber<T>, invalidate?: () => void): Unsubscriber`. |
| `Writable<T>` | Interface | Extends `Readable<T>` with `set(this: void, value: T): void` and `update(this: void, updater: Updater<T>): void`. |

Note the `this: void` annotations on `subscribe`/`set`/`update`: they forbid calling these methods with a bound `this`, which lets implementations be detached and passed around as plain functions.

The file ends with `export * from './index-client.js'`, making it the re-export surface that folds the [stores_bridge](stores_bridge.md) adapters (`fromStore`, `toStore`) into the same module namespace as the contract.

### Private utilities (`private.d.ts`)

| Type | Definition | Consumers |
|---|---|---|
| `SubscribeInvalidateTuple<T>` | `[Subscriber<T>, () => void]` — a subscriber paired with its invalidator. Used internally by the `writable` implementation's subscriber `Set`. | [stores_core](stores_core.md) |
| `Stores` | `Readable<any> \| [Readable<any>, ...Array<Readable<any>>] \| Array<Readable<any>>` — "one or more `Readable`s". | `derived`, compiler-generated code |
| `StoresValues<T>` | Conditional type that extracts the union of value types from one or more stores: unwraps `Readable<infer U>` for a single store, or maps each tuple/array member to its unwrapped value type. | `derived`, `safe_not_equal`-style helpers |

`StoresValues<T>` is the typing backbone of `derived()`: given `Stores`, it yields the exact shape the combiner callback receives — a single value for a single store, a tuple/array of values otherwise.

---

## Type Hierarchy

```mermaid
classDiagram
    direction LR

    class Subscriber~T~ {
        <<type alias>>
        +(value: T) void
    }
    class Unsubscriber {
        <<type alias>>
        +() void
    }
    class Updater~T~ {
        <<type alias>>
        +(value: T) T
    }
    class StartStopNotifier~T~ {
        <<type alias>>
        +(set, update) void | () void
    }

    class Readable~T~ {
        <<interface>>
        +subscribe(this:void, run: Subscriber~T~, invalidate?) Unsubscriber
    }
    class Writable~T~ {
        <<interface>>
        +set(this:void, value: T) void
        +update(this:void, updater: Updater~T~) void
    }

    class Stores {
        <<type alias>>
        Readable | tuple/array of Readable
    }
    class StoresValues~T~ {
        <<conditional type>>
        unwraps Readable~infer U~ → U
    }
    class SubscribeInvalidateTuple~T~ {
        <<type alias>>
        [Subscriber~T~, () => void]
    }

    Readable <|.. Writable : extends
    Writable ..> Subscriber : uses
    Writable ..> Updater : uses
    Readable ..> Subscriber : uses
    Readable ..> Unsubscriber : returns
    StartStopNotifier ..> Updater : uses
    SubscribeInvalidateTuple ..> Subscriber : composes
    Stores ..> Readable : composed of
    StoresValues ..> Stores : unwraps values of
```

---

## Architecture & Component Relationships

The contract sits at the top of the store subsystem and constrains everything below it. All runtime modules are *implementations of* or *adapters around* these interfaces — none of them extend the contract itself.

```mermaid
flowchart TB
    subgraph PA["public-api (svelte package surface)"]
        IDX["svelte (index)"]
    end

    subgraph CONTRACT["stores_contract — types only, zero runtime"]
        PUB["public.d.ts<br/>Readable / Writable<br/>Subscriber · Unsubscriber<br/>Updater · StartStopNotifier"]
        PRIV["private.d.ts<br/>Stores · StoresValues<br/>SubscribeInvalidateTuple"]
        PUB --> PRIV
    end

    subgraph CORE["stores_core (see stores_core.md)"]
        W["writable(value, start)"]
        R["readable(value, start)"]
        D["derived(stores, fn)"]
        G["get(store)"]
        U["update(fn)"]
        UTILS["utils.js · subscribe_to_store()"]
    end

    subgraph BRIDGE["stores_bridge (see stores_bridge.md)"]
        FS["fromStore(store)"]
        TS["toStore(get, set)"]
    end

    subgraph EXT["External / userland"]
        RX["RxJS observables &<br/>any duck-typed observable"]
        USER["Application stores"]
    end

    W -->|"implements"| PUB
    R -->|"implements"| PUB
    D -->|"signatures use"| PRIV
    D -->|"creates"| W
    UTILS -->|"accepts any"| PUB
    G --> UTILS
    FS -->|"runtime check: 'set' in store<br/>(Writable vs Readable)"| PUB
    TS -->|"produces"| PUB
    RX -.->|"structurally satisfies"| PUB
    USER -.->|"structurally satisfies"| PUB

    CORE --> IDX
    BRIDGE --> IDX
```

### Key relationships

1. **[stores_core](stores_core.md)** is the *canonical implementation* of the contract. `writable()` returns an object literal `{ set, update, subscribe }` that satisfies `Writable<T>`; `readable()` projects only `subscribe` to satisfy `Readable<T>`. Internally, `writable` stores each pair of callbacks as a `SubscribeInvalidateTuple<T>` in a `Set`, invokes the `StartStopNotifier` when `subscribers.size === 1`, and calls its returned cleanup when the set empties.
2. **[stores_bridge](stores_bridge.md)** adapts the contract to the runes world. `fromStore()` performs a *structural* runtime check — `'set' in store` — which mirrors the type-level difference between `Writable` and `Readable`: the presence of `set` decides whether the returned proxy exposes a writable `current`. `toStore()` runs a runes `effect_root` and exposes it through the contract, returning `{ subscribe }` or `{ set, update, subscribe }`.
3. **subscribe_to_store** (`store/utils.js`, used by `derived` and `get`) is deliberately tolerant: it calls `store.subscribe(run, invalidate)` on *any* object, and normalizes RxJS-style results via `unsub.unsubscribe`. This is the runtime face of the contract's duck-typing philosophy.

---

## Contract Semantics (what implementations must guarantee)

The interfaces encode behavioral obligations beyond their signatures:

1. **Immediate synchronous call** — `subscribe(run)` must call `run(currentValue)` synchronously with the current value; subscribers never miss the initial state.
2. **Idempotent unsubscription** — the returned `Unsubscriber` must be safe to call, and after the last unsubscription the store must invoke the `StartStopNotifier` cleanup (if any).
3. **Equality-gated updates** — implementations (see `writable` in [stores_core](stores_core.md)) only notify subscribers when `safe_not_equal(value, new_value)` holds, so reactive consumers such as `derived` can rely on `invalidate` signaling *actual* changes.
4. **Valid-after-unsubscribe discipline** — `derived`'s stop function explicitly resets its `started` flag because queued callbacks may still fire after unsubscription; contract consumers must tolerate callbacks racing teardown.
5. **Structural, not nominal** — nothing is imported, instantiated, or `instanceof`-checked anywhere in the runtime. The contract is satisfied purely by shape.

---

## Data Flow: Subscription Lifecycle

The sequence below shows how the contract types flow through the reference implementation when a store is created, subscribed, updated, and torn down:

```mermaid
sequenceDiagram
    participant User as Consumer
    participant Store as writable (stores_core)
    participant Notif as StartStopNotifier<T>
    participant Sub as Subscriber<T>

    User->>Store: writable(value, start)
    Note over Store: subscribers = Set<SubscribeInvalidateTuple<T>>

    User->>Store: subscribe(run, invalidate)
    Store->>Store: add [run, invalidate] tuple
    alt first subscriber
        Store->>Notif: start(set, update)
        Notif-->>Store: optional cleanup fn (Unsubscriber)
    end
    Store->>Sub: run(currentValue) — synchronously
    Store-->>User: Unsubscriber

    User->>Store: set(newValue)
    alt safe_not_equal(old, new)
        Store->>Store: invalidate each tuple
        Store->>Sub: run(newValue) — batched via subscriber_queue
    end

    User->>Store: update(updater)
    Store->>Store: set(updater(currentValue))

    User->>Store: unsubscribe()
    Store->>Store: remove tuple
    alt last subscriber
        Store->>Notif: cleanup()
    end
```

---

## Process Flow: Contract-Based Capability Detection

`fromStore` in [stores_bridge](stores_bridge.md) demonstrates the contract's practical power: a single structural probe (`'set' in store`) maps the type-level `Readable`/`Writable` split onto two different runtime proxies.

```mermaid
flowchart TD
    A["fromStore(store)"] --> B{"'set' in store ?"}
    B -->|"yes — store satisfies Writable<T>"| C["return proxy with<br/>get current() → reactive value<br/>set current(v) → store.set(v)"]
    B -->|"no — store satisfies only Readable<T>"| D["return proxy with<br/>read-only get current()"]

    subgraph "client vs server (stores_bridge)"
        C1["client: current() tracks via<br/>createSubscriber + effect tracking;<br/>falls back to get(store)"]
        D1["server: current() = get(store)<br/>(one-shot synchronous read)"]
    end

    C -.-> C1
    D -.-> D1
```

The same structural principle underlies `subscribe_to_store`'s RxJS normalization: `unsub.unsubscribe ? () => unsub.unsubscribe() : unsub` accepts observables whose `subscribe` returns an `unsubscribe`-carrying object instead of a bare function.

---

## How This Module Fits the Overall System

```mermaid
flowchart LR
    subgraph Compile["Compiler Pipeline (see compiler-core_public_api.md)"]
        C["svelte compiler"]
    end
    subgraph Public["Public API — Built-in Feature Surface"]
        API["svelte entrypoints"]
        subgraph Stores["stores subsystem"]
            SC["stores_contract<br/>(this module)"]
            CORE["stores_core"]
            BRIDGE["stores_bridge"]
        end
        MOTION["motion"]
        RB["reactive-builtins"]
    end
    subgraph Runtime["Client Runtime Engine"]
        RE["reactivity engine (runes)"]
    end

    C -->|"compiles $store auto-subscription<br/>to get/update/store_get calls"| CORE
    SC --> CORE
    SC --> BRIDGE
    CORE --> API
    BRIDGE -->|"fromStore/toStore"| RE
    BRIDGE --> API
    SC -.->|"typed via StoresValues"| MOTION
    SC -.->|"typed via Readable"| RB
```

- The **compiler** desugars `$store` syntax into calls against [stores_core](stores_core.md) helpers (`get`, `store_get`, `update_store`), whose parameter types are declared using this contract's `Stores`/`StoresValues` utilities.
- The **runes reactivity engine** never touches stores directly; it meets them only through [stores_bridge](stores_bridge.md) (`fromStore`/`toStore`), which speaks the contract on one side and signals on the other.
- Userland and third-party observables interoperate for free because satisfying the contract requires only the right shape.

---

## Related Modules

| Module | Relationship |
|---|---|
| [stores_core](stores_core.md) | Reference implementation of the contract: `writable`, `readable`, `derived`, `get`, `update`. |
| [stores_bridge](stores_bridge.md) | Adapters (`fromStore`, `toStore`) between the contract and runes-based reactivity; re-exported through `public.d.ts`. |
| [public-api](public-api.md) | Parent feature surface; `svelte/store` exposes these types plus the bridge helpers. |
| [compiler-core_public_api](compiler-core_public_api.md) | The compiler generates store-integration calls (`get`, `update_store`, …) whose signatures are typed by this contract. |
| [client-reactivity-engine_props-and-stores](client-reactivity-engine_props-and-stores.md) | Runtime-side store integration (`store_get`, `store_mutate`) consumed by compiled client code. |
