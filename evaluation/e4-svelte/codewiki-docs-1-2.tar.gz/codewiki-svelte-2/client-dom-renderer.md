# Client DOM Renderer (`client-dom-renderer`)

> **Module root:** `packages/svelte/src/internal/client/` — lifecycle entry point `render.js`, DOM machinery under `dom/`.
> **Parent module:** [Client Runtime Engine (Reactivity & DOM Rendering)](client-reactivity-engine.md) · **Sibling:** client reactivity engine (`client-reactivity-engine`)

## 1. Purpose and Scope

The **client DOM renderer** is the DOM-facing half of Svelte 5's internal client runtime. It is the code that compiled components actually *call at runtime*: the compiler never touches the DOM itself — it emits render functions whose statements invoke the helpers documented here.

Concretely, this module is responsible for:

| Responsibility | Where |
|---|---|
| Component `mount` / `hydrate` / `unmount` entry points | `render.js` |
| DOM construction & adoption — template cloning, node walking, hydration cursor | `dom/operations.js`, `dom/template.js`, `dom/hydration.js` |
| Control-flow blocks — `{#if}`, `{#each}`, `{#key}`, `{#await}`, async expressions, `<svelte:boundary>`, snippets, slots, `{@html}`, `<svelte:element>`, `<svelte:head>`, CSS properties | `dom/blocks/*` |
| Element services — attribute reconciliation, event delegation, two-way bindings, transitions/animations, custom elements | `dom/elements/*` |
| Scoped style injection | `dom/css.js` |

What it deliberately does **not** do (handled by sibling modules — follow the links rather than duplicating):

- **Own the signal graph.** Sources, deriveds, effects and `Batch` scheduling live in the client reactivity engine (`client-reactivity-engine`). Every DOM mutation performed here happens *inside* an effect owned by that engine.
- **Dev-mode instrumentation** (HMR wrappers, ownership validation, tracing tags, element locations) — see `client-dev-tooling`.
- **Legacy class components / event modifiers** — see `legacy-compat` (the custom-element bridge is the one place this module calls into it, via `createClassComponent`).

## 2. Position in the System

The [compiler pipeline](compiler-transformer_client-transform.md) (`compiler-transformer_client-transform`) lowers each component into a render function that is essentially a sequence of calls into this module:

```js
// Simplified sketch of compiler output for <p>Count: {count}</p>
import * as $ from 'svelte/internal/client';

export default function App($$anchor, $$props) {
  $.push($$props, true);

  var p = $.from_html('<p>Count: <!> </p>')();     // clone template (template.js)
  var t = $.sibling($.child(p), 2);                 // walk to text node (operations.js)
  $.template_effect(() => $.set_text(t, count())); // reactive update (render.js + effects)
  $.append($$anchor, p);                            // insert before anchor (template.js)

  $.pop();
}
```

```mermaid
flowchart LR
    subgraph BuildTime["Build time"]
        SRC[".svelte source"] --> CP["Compiler pipeline<br/>(compiler-transformer_client-transform)"]
    end

    subgraph RunTime["Browser runtime"]
        PA["Public API<br/>mount · hydrate · unmount"]
        subgraph CDR["client-dom-renderer (this module)"]
            LF["lifecycle (render.js)"]
            CF["control-flow blocks (dom/blocks)"]
            ES["element services (dom/elements):<br/>attributes · events · bindings ·<br/>transitions · custom elements"]
            DF["DOM foundation:<br/>operations · template · hydration · css"]
        end
        CRE["client-reactivity-engine<br/>signals · effects · Batch"]
    end

    BDOM[("Browser DOM")]

    CP -- "render fn calls $.helpers" --> LF
    PA --> LF
    LF --> CF
    LF --> DF
    CF --> ES
    CF --> DF
    ES --> DF
    LF -- "component_root / branch / pause" --> CRE
    CF -- "block / branch / sources" --> CRE
    ES -- "render effects / batches" --> CRE
    LF --> BDOM
    DF --> BDOM
```

The [public API](public-api.md) module simply re-exports `mount`, `hydrate` and `unmount` from `render.js`; `svelte/transition`, `svelte/motion` and `svelte/easing` functions are *consumed* by the transition manager implemented in this module (they supply the `TransitionFn`/easing parameters).

## 3. Architecture Overview

### 3.1 Sub-modules

| Sub-module | Files | Responsibility | Docs |
|---|---|---|---|
| **Lifecycle** | `render.js` | `mount`/`hydrate`/`unmount`, root event registration, `set_text` diffing | [client-dom-renderer_lifecycle.md](client-dom-renderer_lifecycle.md) |
| **DOM foundation** | `dom/operations.js`, `dom/template.js`, `dom/hydration.js`, `dom/css.js` | Hydration-aware node walking, template clone factories, hydration cursor, style injection | [client-dom-renderer_dom-foundation.md](client-dom-renderer_dom-foundation.md) |
| **Control-flow blocks** | `dom/blocks/*.js` (12 files) | Runtime implementations of every template block | [client-dom-renderer_control-flow-blocks.md](client-dom-renderer_control-flow-blocks.md) |
| **Attributes & events** | `dom/elements/attributes.js`, `events.js`, `misc.js` | Attribute/prop diffing, delegated event system, form-reset & textarea quirks | [client-dom-renderer_attributes-events.md](client-dom-renderer_attributes-events.md) |
| **Two-way bindings** | `dom/elements/bindings/*.js` (10 files) | `bind:` directive implementations for inputs, media, selects, size, window, document, `this`, … | [client-dom-renderer_bindings.md](client-dom-renderer_bindings.md) |
| **Custom elements** | `dom/elements/custom-element.js` | `create_custom_element` — Svelte components as native custom elements | [client-dom-renderer_custom-elements.md](client-dom-renderer_custom-elements.md) |
| **Transitions & animations** | `dom/elements/transitions.js` | `TransitionManager` (Web Animations API), `animate:` per-item animation managers | [client-dom-renderer_transitions.md](client-dom-renderer_transitions.md) |

### 3.2 Core Design Concepts

These five ideas explain almost every file in the module:

1. **Anchor-based patching.** Compiled fragments never assume a parent structure. Every dynamic region is delimited by an *anchor* (a comment or text node), and content is inserted *before* that anchor. This makes blocks parent-agnostic and movable.

2. **Effects own DOM ranges.** Every block wraps its DOM in a `branch` effect (or a `block` effect that re-runs). While it runs, `assign_nodes()` records the produced DOM range onto the effect as `nodes_start` … `nodes_end`. Removing/updating a block therefore means pausing/resuming/destroying *the effect*, not hand-deleting nodes — the reactivity engine drives all teardown, and transitions run via `run_out_transitions` before nodes are removed.

3. **Hydration cursor.** SSR output is bracketed by `<!--[-->` / `<!--]-->` comments (`HYDRATION_START`/`HYDRATION_END`, plus `HYDRATION_START_ELSE` for else-branches). When `hydrating` is `true`, the *same* render functions walk the existing DOM using the `hydrate_node` cursor instead of creating nodes (`child`, `sibling`, `hydrate_next`, …). The flag is written so hydration code can be treeshaken out when `hydrate` is never used.

4. **Event delegation.** Declarative handlers (`onclick={...}`) are stored on the element as expando properties (`element.__click`); a single listener per event type on the mount target (and one ref-counted listener on `document`) dispatches handlers by walking `event.composedPath()` in `handle_event_propagation`.

5. **Batched, deferred commits.** In async mode, `should_defer_append()` defers block switches (if/each/key) to the end of the current `Batch`: new content is built into an offscreen `DocumentFragment` and inserted atomically by a batch callback, while outgoing branches join `batch.skipped_effects` — this keeps a `<svelte:boundary>`'s DOM consistent while async work is in flight.

### 3.3 Component lifecycle flow

```mermaid
sequenceDiagram
    autonumber
    participant App as Application code
    participant L as render.js (lifecycle)
    participant E as Reactivity engine
    participant C as Compiled component fn
    participant F as DOM foundation
    participant S as Element services

    App->>L: mount(Component, { target, props, events, context, intro })
    L->>F: init_operations() — cache getters, expando defaults
    L->>L: register delegated events on target (+ ref-counted document listener)
    L->>E: component_root(() => branch(() => { ... }))
    E->>C: Component(anchor_node, props)
    C->>F: from_html/text/comment → clone templates, assign effect DOM range
    F-->>C: anchors + nodes_start/nodes_end
    C->>S: attribute_effect, bindings, transition(), event expandos
    S->>E: create render effects, read signals
    C-->>L: component exports
    L-->>App: exports (stored in mounted_components WeakMap)

    App->>L: unmount(app, { outro })
    L->>E: component_root teardown → optional pause_effect (outros) → destroy
    L-->>App: Promise<void>
```

Key details:

- `mount` returns the component's exports; the render effect runs synchronously so they are available immediately.
- `context` is pushed as a component-context entry so `getContext` works for the top-level instance; `events` are attached as `props.$$events`.
- Event listeners added at the root are ref-counted (`document_listeners` map) so multiple mounted apps share document-level listeners safely.
- `should_intro` gates initial intro transitions (disabled during hydration unless `options.intro`).

### 3.4 Hydration model

```mermaid
flowchart TD
    A["hydrate(Component, options)"] --> B["scan target children for HYDRATION_START comment"]
    B -- "not found" --> X["throw HYDRATION_ERROR"]
    B -- "found" --> C["set_hydrating(true), hydrate_node = marker"]
    C --> D["_mount() runs the normal render fn with anchor = marker"]
    D --> E["helpers walk SSR DOM via cursor<br/>(child / sibling / hydrate_next / block markers)"]
    E -- "structure matches" --> F{"cursor at HYDRATION_END?"}
    F -- "yes" --> G["DOM adopted — done"]
    F -- "no" --> H["warn hydration_mismatch"]
    E -- "block-level mismatch" --> I["remove_nodes() → render client-side from that point"]
    H --> J{"options.recover !== false ?"}
    I --> J
    J -- "true" --> K["clear target, mount() from scratch"]
    J -- "false" --> L["throw hydration_failed"]
```

Mismatch handling happens at two levels: individual blocks (if/each/await, `{@html}`, `<svelte:element>`) repair themselves via `remove_nodes()` and continue; `hydrate()` performs the global fallback (full client re-render) unless `recover: false`. Svelte-specific errors (messages starting with `https://svelte.dev/e/`) are always re-thrown instead of being treated as hydration failures.

### 3.5 Block & effect DOM lifecycle

All control-flow content lives in branch effects. This is the state machine the blocks drive:

```mermaid
stateDiagram-v2
    [*] --> Active: branch(fn) creates + runs content
    Active --> Paused: pause_effect() — outros run, then DOM removed/offscreened
    Paused --> Active: resume_effect() — intros run, DOM reinserted
    Paused --> Destroyed: destroy_effect() after outros complete
    Active --> Destroyed: destroy_effect() (immediate, e.g. error/tag switch)
    Destroyed --> [*]
```

### 3.6 Template syntax ↔ runtime helpers

| Template syntax | Runtime helper (module) |
|---|---|
| static markup | `from_html` / `from_svg` / `from_mathml` / `from_tree`, `text`, `comment`, `append` (dom-foundation) |
| `{expression}` text | `text` + `set_text` + `template_effect` |
| `{#if}` / `{:else if}` | `if_block` / `set_branch` (blocks) |
| `{#each}` (+ key, `{:else}`) | `each`, `index` (blocks) |
| `{#key}` | `key` (blocks) |
| `{#await}` | `await_block` (blocks) |
| top-level `await` expressions (async mode) | `async` + `flatten` (blocks/reactivity) |
| `<svelte:boundary>` | `boundary` (blocks) |
| `{#snippet}` / `{@render}` | `snippet`, `wrap_snippet`, `createRawSnippet` (blocks) |
| `<slot>` | `slot`, `sanitize_slots` (blocks) |
| `{@html}` | `html` (blocks) |
| `<svelte:element>` | `element` (blocks) |
| `<svelte:head>` | `head` (blocks) |
| `--custom-prop` style props | `css_props` (blocks) |
| `class:` / `style:` / attributes / spreads | `attribute_effect`, `set_attributes`, `set_class`, `set_style` (attributes-events) |
| `on:` / `on*` handlers | `event`, `create_event`, `delegate`, `handle_event_propagation` (attributes-events) |
| `bind:*` | `bind_*` family (bindings) |
| `transition:` / `in:` / `out:` | `transition` (transitions) |
| `animate:` | `animation` (transitions) |
| `<svelte:options customElement>` | `create_custom_element` (custom-elements) |
| `<style>` (scoped CSS) | `append_styles` (dom-foundation) |

## 4. Sub-module Documentation

Detailed documentation for each sub-module (generated files, cross-referenced from the table in §3.1):

- **[Component Lifecycle](client-dom-renderer_lifecycle.md)** (`client-dom-renderer_lifecycle.md`) — `mount`, `hydrate`, `unmount`, root event wiring, `set_text`.
- **[DOM Foundation](client-dom-renderer_dom-foundation.md)** (`client-dom-renderer_dom-foundation.md`) — node walking & hydration cursor (`hydration.js`), template clone factories (`template.js`), hydration-aware `child`/`sibling`/`first_child` (`operations.js`), style injection (`css.js`).
- **[Control-Flow Blocks](client-dom-renderer_control-flow-blocks.md)** (`client-dom-renderer_control-flow-blocks.md`) — every template block: if, each (+ reconciliation algorithm), key, await, async, boundary, html, snippet, slot, svelte:element, svelte:head, css props.
- **[Attributes & Events](client-dom-renderer_attributes-events.md)** (`client-dom-renderer_attributes-events.md`) — `attribute_effect`/`set_attributes` reconciliation, custom-element data, event delegation internals, form quirks.
- **[Two-Way Bindings](client-dom-renderer_bindings.md)** (`client-dom-renderer_bindings.md`) — the `bind_*` family across input, select, media, size, window, document, navigator, `this`, universal and component props.
- **[Custom Elements](client-dom-renderer_custom-elements.md)** (`client-dom-renderer_custom-elements.md`) — packaging components as native custom elements with attribute reflection.
- **[Transitions & Animations](client-dom-renderer_transitions.md)** (`client-dom-renderer_transitions.md`) — the `TransitionManager`, Web Animations bridging, and per-item `animate:` managers.

## 5. Cross-Cutting Behaviour

- **Treeshakeability guards.** `hydrating` (`hydration.js`) and `DEV` (`esm-env`) guard hydration paths and diagnostics so they can be compiled away. Several mismatch flags are declared with `let` (not `const`) specifically so dead branches DCE cleanly.
- **Error strategy.** `<svelte:boundary>` (blocks) catches render errors of its subtree, supports `onerror`/`failed` snippets and reset semantics; uncaught boundary errors propagate to the parent boundary via `invoke_error_boundary`. Hydration errors use the `HYDRATION_ERROR` sentinel plus warnings from `client-dev-tooling`.
- **SSR parity.** Comment markers, `props_id()` (unique component scope ids) and `replay_events()` (re-dispatch of SSR-captured `onload`/`onerror`) make client output line up with `server-runtime`'s output; the actual server rendering lives in the `Server-Side Rendering` module.
- **Performance notes.** `init_operations()` swaps `firstChild`/`nextSibling` for direct prototype getters, pre-seeds expando slots (`__click`, `__attributes`, `__t`, …) to keep hidden classes stable, and parses each template once (`create_fragment_from_html` via `<template>` innerHTML) then clones per instance (`importNode` on Firefox).
- **Dev-only behaviours** (HMR, ownership validation, location metadata `__svelte_meta`, `apply()` handler validation) are documented with `client-dev-tooling`; this module provides the hooks they attach to.

## 6. Related Modules

- [`client-reactivity-engine`](client-reactivity-engine.md) — the signal/effect/batch engine this renderer builds on. Read its signal-graph and batching docs for update scheduling semantics.
- [`client-dev-tooling`](client-dev-tooling.md) — DEV-mode validation, HMR wrappers and tracing used by the hooks described above.
- [`legacy-compat`](legacy-compat.md) — class components, `createBubbler`, legacy event modifiers (`nonpassive`, `once`, `self`, `trusted`, `stopPropagation`-style modifiers) and `invalidate_inner_signals`.
- [Compiler pipeline → client transform](compiler-transformer_client-transform.md) — generates the `$.helper` call sites consumed here.
- [Public API](public-api.md) — user-facing `mount`/`hydrate`/`unmount`, transitions and motion libraries.
