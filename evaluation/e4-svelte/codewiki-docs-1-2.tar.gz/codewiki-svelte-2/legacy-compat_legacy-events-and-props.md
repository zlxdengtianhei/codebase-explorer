# Legacy Events and Props Compatibility (`legacy-compat_legacy-events-and-props`)

## Introduction

The **legacy events and props** module is a sub-module of the [legacy-compat](legacy-compat.md) compatibility layer. It provides runtime shims that emulate two categories of Svelte 4 behavior inside the Svelte 5 client runtime:

1. **Legacy event modifiers** — function wrappers that reproduce the compile-time event modifiers (`|preventDefault`, `|stopPropagation`, `|once`, `|self`, `|trusted`, `|passive`, `|nonpassive`, …) that were removed from the Svelte 5 template language. In legacy mode the compiler emits calls to these substitute functions instead.
2. **Legacy event bubbling & props mutation** — helpers that simulate the Svelte 4 component API surface (`$on`, `$set`, forwarded DOM events, and reactive dynamic imports) on top of Svelte 5's rune-based reactivity, primarily when `compatibility.componentApi === 4`.

All exported functions are **deprecated by design**: they exist purely so that un-migrated Svelte 4 components keep working. New code should use the modern event handler and props idioms instead (see [public-api](public-api.md) for `createEventDispatcher` and the current event model).

> **Module location:** `packages/svelte/src/internal/client/dom/legacy/`
> **Files:** `event-modifiers.js`, `misc.js`

---

## Architecture Overview

The module consists of two cooperating files:

- **`event-modifiers.js`** — eight stateless higher-order "modifier" wrappers plus two action-based passive listeners. Each wrapper returns a new handler that decorates the user's handler with modifier behavior (filtering, one-shot execution, or native event-method side effects).
- **`misc.js`** — four utilities bridging legacy component semantics onto the modern signal graph: event bubbling through `$$props.$$events`, `$on`/`$set` simulation, and reactive dynamic imports.

```mermaid
flowchart TB
    subgraph legacy["legacy-compat_legacy-events-and-props"]
        subgraph EM["event-modifiers.js"]
            direction TB
            subgraph Handlers["Handler-wrapping modifiers"]
                trusted["trusted(fn)"]
                self["self(fn)"]
                once["once(fn)"]
                stopProp["stopPropagation(fn)"]
                stopImm["stopImmediatePropagation(fn)"]
                prevent["preventDefault(fn)"]
            end
            subgraph Actions["Action-based modifiers"]
                passive["passive(node, [event, handler])"]
                nonpassive["nonpassive(node, [event, handler])"]
            end
        end
        subgraph MISC["misc.js"]
            bubble["bubble_event($$props, event)"]
            addListener["add_legacy_event_listener($$props, name, cb)"]
            updateProps["update_legacy_props($$new_props)"]
            reactiveImport["reactive_import(fn)"]
        end
    end

    subgraph DEPS["Runtime dependencies"]
        effects["reactivity/effects.js<br/>user_pre_effect"]
        onEv["dom/elements/events.js<br/>on"]
        sources["reactivity/sources.js<br/>source, set"]
        runtime["runtime.js<br/>get"]
        shared["internal/shared/utils.js<br/>noop, is_array"]
    end

    Actions -->|"register listener in<br/>pre-effect teardown scope"| effects
    Actions -->|"attach passive listener"| onEv
    Actions --> shared
    reactiveImport -->|"create + bump signal"| sources
    reactiveImport -->|"read signal (track deps)"| runtime
    bubble --> shared
    addListener -->|"writes $$events map"| bubble

    style legacy fill:#1e293b,color:#e2e8f0,stroke:#475569
    style EM fill:#312e81,color:#e2e8f0,stroke:#6366f1
    style MISC fill:#312e81,color:#e2e8f0,stroke:#6366f1
    style DEPS fill:#134e4a,color:#e2e8f0,stroke:#14b8a6
```

---

## Event Modifiers (`event-modifiers.js`)

In Svelte 4, modifiers were part of the template syntax:

```svelte
<!-- Svelte 4 -->
<button on:click|once|preventDefault={handler}>...</button>
<a href="..." on:click|passive={handler}>...</a>
```

In Svelte 5 those modifiers no longer exist. The legacy compiler output instead **wraps the user handler** by emitting a call to the corresponding substitute function from this file:

```js
// Svelte 5 legacy output (schematic)
bind_this.addEventListener('click', once(preventDefault(handler)), ...);
```

### Handler-wrapping modifiers

Each wrapper is a higher-order function: it takes the user handler and returns a decorated handler with identical signature `(event, ...args)`. The wrapper preserves `this` by invoking the handler with `fn?.apply(this, args)`.

| Modifier | Behavior | Return value forwarded to caller? |
|---|---|---|
| `trusted(fn)` | Invokes `fn` **only if** `event.isTrusted === true` (blocks programmatic/synthetic dispatch) | No (implicitly `undefined`) |
| `self(fn)` | Invokes `fn` **only if** `event.target === this` (event originated on the bound element, not a descendant) | No |
| `once(fn)` | Invokes `fn` exactly one time; subsequent calls are no-ops via a closure `ran` flag | Yes (first call only) |
| `stopPropagation(fn)` | Calls `event.stopPropagation()`, then invokes `fn` | Yes |
| `stopImmediatePropagation(fn)` | Calls `event.stopImmediatePropagation()`, then invokes `fn` | Yes |
| `preventDefault(fn)` | Calls `event.preventDefault()`, then invokes `fn` | Yes |

```mermaid
flowchart TD
    Start(["DOM dispatches event"]) --> Dispatch["Decorated handler called<br/>(this = element, args = [event, ...])"]
    Dispatch --> Branch{"Modifier type?"}

    Branch -->|"trusted"| T{"event.isTrusted?"}
    T -->|no| Skip1["Skip handler"]
    T -->|yes| Run

    Branch -->|"self"| S{"event.target === this?"}
    S -->|no| Skip2["Skip handler"]
    S -->|yes| Run

    Branch -->|"once"| O{"ran === true?"}
    O -->|yes| Skip3["Return undefined"]
    O -->|no| SetFlag["ran = true"] --> Run

    Branch -->|"preventDefault"| P["event.preventDefault()"] --> Run
    Branch -->|"stopPropagation"| SP["event.stopPropagation()"] --> Run
    Branch -->|"stopImmediatePropagation"| SIP["event.stopImmediatePropagation()"] --> Run
    Branch -->|"none"| Run

    Run["fn.apply(this, args)<br/>preserves 'this' context"] --> Done(["Return fn's result<br/>for side-effect modifiers"])

    style Start fill:#14532d,color:#f0fdf4,stroke:#22c55e
    style Run fill:#14532d,color:#f0fdf4,stroke:#22c55e
    style Done fill:#14532d,color:#f0fdf4,stroke:#22c55e
    style Skip1 fill:#7f1d1d,color:#fef2f2,stroke:#ef4444
    style Skip2 fill:#7f1d1d,color:#fef2f2,stroke:#ef4444
    style Skip3 fill:#7f1d1d,color:#fef2f2,stroke:#ef4444
```

### Action-based passive modifiers

`passive` and `nonpassive` cannot be expressed as handler wrappers because `passive` is an **`addEventListener` option**, not a handler-time behavior. They are therefore implemented as **Svelte actions** (`use:`) that receive `[event, handler]` and attach the listener with the matching `passive` option:

```js
// passive: attach with { passive: true } — never calls preventDefault
// nonpassive: attach with { passive: false } — may call preventDefault
export function passive(node, [event, handler]) {
    user_pre_effect(() => {
        return on(node, event, handler() ?? noop, { passive: true });
    });
}
```

Implementation notes:

- `user_pre_effect` (from the [client-reactivity-engine](client-reactivity-engine.md) effects module) runs the registration as a `$effect.pre` scoped to the component's lifecycle. The **return value** of `on(...)` — a cleanup closure that calls `removeEventListener` — becomes the effect teardown, so listeners are automatically removed when the component unmounts.
- `on(...)` (from the [client-dom-renderer](client-dom-renderer.md) events module) is the canonical modern event-attachment primitive; reusing it keeps passive listeners aligned with event delegation and cleanup rules.
- `handler()` is invoked lazily inside the effect and falls back to `noop` if it yields `null`/`undefined`, so a missing handler never crashes registration.

---

## Legacy Event Bubbling and Props (`misc.js`)

While `event-modifiers.js` decorates *individual handlers*, `misc.js` restores the *component-level* event and props semantics of Svelte 4 on top of Svelte 5's `$$props` object.

### `bubble_event($$props, event)`

Emulates Svelte 4's automatic DOM event forwarding. In legacy-compiled components, inline element handlers call `bubble_event` so that events "bubble" to whatever the parent registered on the component tag:

1. Look up `event.type` in `$$props.$$events` (the map parents populate via `on:click` on a `<Component>` tag).
2. Normalize the stored value — it may be a single function or an array of functions — into a **copy of the array** (`events.slice()`), so mutation during iteration is safe.
3. Invoke each callback with `fn.call(this, event)`, preserving the original `this` (the originating element) so handler-wrapping modifiers like `self` keep working.

### `add_legacy_event_listener($$props, event_name, event_callback)`

Simulates the Svelte 4 **`$on` instance method** when `compatibility.componentApi === 4`. It mutates the shared `$$events` map:

```js
$$props.$$events ||= {};
$$props.$$events[event_name] ||= [];
$$props.$$events[event_name].push(event_callback);
```

Because it writes into the same `$$events` structure that `bubble_event` and [`createBubbler`](legacy-compat_component-api-shims.md) read, external `$on('click', cb)` registrations participate in the same bubbling pipeline as declarative `on:click` attributes.

### `update_legacy_props($$new_props)`

Simulates the Svelte 4 **`$set` instance method** when `compatibility.componentApi === 4`. It is `this`-bound to the component instance (invoked as `instance.$set(props)`):

- Iterates `$$new_props` keys and assigns `this[key] = $$new_props[key]` **only for keys that already exist on the instance**.
- The assignment targets the instance's **accessors** (compiler-generated prop setters), which propagate into the signal graph and trigger downstream updates.
- Documented limitation: because it relies on instance accessors, updates to `$$props` or `$$restProps` *themselves* are not supported.

### `reactive_import(fn)`

Under legacy mode, `import(`…`)`-bound values (module-level bindings used reactively) must be tracked by the signal graph. The compiler rewrites such imports to wrap them with `reactive_import`:

```mermaid
flowchart LR
    subgraph RA["reactive_import(fn)"]
        S["s = source(0)<br/>(version counter signal)"]
        W["returned wrapper()"]
    end
    Read["Wrapper called<br/>with 0 arguments<br/>(read)"] -->|"get(s) registers<br/>current effect as dependency"| EVAL["return fn()<br/>(evaluate import)"]
    Write["Wrapper called<br/>with 1 argument<br/>(invalidate)"] -->|"set(s, get(s) + 1)<br/>notifies dependents"| Pass["return arguments[0]"]
```

- **Read path:** calling the wrapper with no arguments performs `get(s)`, which (per the [reactivity engine](client-reactivity-engine_reactivity-engine.md)) registers the currently-running effect as a subscriber of `s`, then evaluates and returns the underlying import expression `fn()`.
- **Invalidate path:** calling it with one argument increments the counter signal via `set(s, get(s) + 1)`, dirtying every dependent effect, and returns the passed argument unchanged (so the rewrite stays transparent at call sites).
- The counter starts at `0` (`source(0)`); its *value* is meaningless — only the mutation causes propagation.

---

## End-to-End Data Flow: Legacy Event Dispatch

The two files cooperate during an actual DOM event in a legacy component. Below is the sequence for `on:click|preventDefault={handler}` on an inner element of `<Component on:click={parentHandler}>`:

```mermaid
sequenceDiagram
    participant DOM as DOM (element)
    participant DH as Decorated handler<br/>(preventDefault wrap)
    participant BE as bubble_event
    participant Props as $$props.$$events
    participant P as Parent callback

    DOM->>DH: dispatch 'click'
    DH->>DH: event.preventDefault()
    DH->>DH: fn.apply(this, [event])
    DH->>BE: bubble_event($$props, event)
    BE->>Props: $$events['click']
    Props-->>BE: parentHandler (fn | fn[])
    BE->>BE: normalize to array copy
    BE->>P: fn.call(this, event)<br/>(this = originating element)
    Note over P: Parent handler sees correct<br/>'this' and event with defaults prevented
```

For instance-API consumers (`componentApi === 4`), the same `$$events` map is the rendezvous point for `$on`:

```mermaid
sequenceDiagram
    participant App as Application code
    participant AL as add_legacy_event_listener
    participant Inst as Component instance
    participant BE as bubble_event

    App->>Inst: instance.$on('click', cb)
    Inst->>AL: add_legacy_event_listener($$props, 'click', cb)
    AL->>AL: $$props.$$events['click'].push(cb)
    Note over AL,Inst: Later, a DOM event bubbles...
    BE->>App: cb(event) via bubble_event
```

---

## Dependencies

### Upstream (what this module consumes)

| Dependency | Source module | Used by | Purpose |
|---|---|---|---|
| `user_pre_effect` | [client-reactivity-engine_effects](client-reactivity-engine.md) | `passive`, `nonpassive` | Run listener registration in a component-scoped pre-effect whose return value acts as teardown |
| `on` | [client-dom-renderer](client-dom-renderer.md) (elements/events) | `passive`, `nonpassive` | Attach the listener and obtain the removal closure |
| `source`, `set` | [client-reactivity-engine](client-reactivity-engine.md) (sources) | `reactive_import` | Create the version-counter signal and propagate invalidation |
| `get` | [client-reactivity-engine](client-reactivity-engine.md) (runtime) | `reactive_import` | Read the signal inside effects to register dependencies |
| `noop` | [internal-shared-utils](internal-shared-utils.md) | `passive`, `nonpassive` | Fallback handler when the action yields none |
| `is_array` | [internal-shared-utils](internal-shared-utils.md) | `bubble_event` | Normalize single-callback vs. array callback storage |

### Downstream (what consumes this module)

| Consumer | Relationship |
|---|---|
| **Compiler (legacy mode)** | The compiler's `3-transform/client` phase emits calls to these functions when compiling Svelte 4-style `on:event|modifier` syntax and reactive dynamic imports. See [compiler-transformer_client-transform](compiler-transformer_client-transform.md). |
| **[legacy-compat_component-api-shims](legacy-compat_component-api-shims.md)** | `Svelte4Component` (via `createClassComponent`) implements `$on`/`$set` by delegating to `add_legacy_event_listener` / `update_legacy_props`; `createBubbler` reads the same `$$events` map written by `add_legacy_event_listener` and read by `bubble_event`. |
| **[legacy-compat_legacy-lifecycle](legacy-compat_legacy-lifecycle.md)** | Provides the surrounding legacy lifecycle (`init`, `invalidate_inner_signals`) in which these shims operate; `invalidate_inner_signals` covers mutable-state invalidation that `reactive_import`'s signal bumping complements. |

### High-level dependency graph

```mermaid
flowchart LR
    Compiler["compiler-transformer<br/>(legacy mode output)"] -->|"emits calls"| Module["legacy-events-and-props"]
    Module -->|"user_pre_effect, source, set, get"| Reactivity["client-reactivity-engine"]
    Module -->|"on"| DOMRenderer["client-dom-renderer"]
    Module -->|"noop, is_array"| Shared["internal-shared-utils"]
    Shims["legacy-compat_<br/>component-api-shims"] -->|"$on / $set delegation"| Module
    Module -->|"$$events map"| Shims2["createBubbler reads<br/>$$events"]

    style Module fill:#312e81,color:#e2e8f0,stroke:#6366f1,stroke-width:3px
    style Compiler fill:#7c2d12,color:#fff7ed,stroke:#f97316
    style Reactivity fill:#134e4a,color:#e2e8f0,stroke:#14b8a6
    style DOMRenderer fill:#134e4a,color:#e2e8f0,stroke:#14b8a6
    style Shared fill:#134e4a,color:#e2e8f0,stroke:#14b8a6
    style Shims fill:#4a044e,color:#fdf4ff,stroke:#d946ef
    style Shims2 fill:#4a044e,color:#fdf4ff,stroke:#d946ef
```

---

## Integration in the Overall System

- **Compile-time contract:** This module is the *runtime half* of a compiler/runtime contract. When the compiler runs in legacy compatibility mode, it statically rewrites Svelte 4 constructs into calls exported here. The module therefore has **no public API surface** — it lives under `internal/` and is only reachable via compiler-generated code.
- **Reactivity transparency:** All shims funnel through the modern signal graph (`source`/`set`/`get`, `user_pre_effect`), so legacy components still participate correctly in batching, derived tracking, and effect teardown managed by the [client-reactivity-engine](client-reactivity-engine.md).
- **Lifecycle safety:** The only resources this module creates outside closures are DOM listeners, and those are always registered inside pre-effects that return their own cleanup — guaranteeing leak-free unmounting even for long-lived delegated events.
- **Debug builds:** The reactivity functions consumed here apply DEV-mode guards (`state_unsafe_mutation` checks in `set`, dependency capture in `get`), so legacy shims get the same dev-time safety guarantees as modern code. See [client-dev-tooling](client-dev-tooling.md) for the dev-mode guard catalogue.

## Deprecation & Migration Notes

- Every export in `event-modifiers.js` is marked `@deprecated`. They exist only because the compiler may still emit them for un-migrated Svelte 4 syntax.
- For `misc.js`, the triggering condition is `compatibility.componentApi === 4` (set via `svelte({ compatibility: { componentApi: 4 } })` in tooling, or the compile option `compatibility.componentApi`). When this option is off, none of these functions are referenced by generated code.
- Migration path for dependent code:
  - `on:event|modifier` → explicit handler bodies (`e.preventDefault()` calls) or the `on` helper.
  - `$on` / DOM event forwarding → callback props or [`createEventDispatcher`](public-api.md) (which itself is deprecated in favor of callback props in Svelte 5).
  - `$set` → normal rune-based props (`$props()` / `$state()`).
  - Reactive dynamic imports → explicit `$state`/`$derived` bindings.

## Related Documentation

- [legacy-compat](legacy-compat.md) — parent module: overall compatibility strategy
- [legacy-compat_component-api-shims](legacy-compat_component-api-shims.md) — `createClassComponent`, `asClassComponent`, `createBubbler` (consumers of `add_legacy_event_listener` / `update_legacy_props`)
- [legacy-compat_legacy-lifecycle](legacy-compat_legacy-lifecycle.md) — `init`, `invalidate_inner_signals`
- [client-reactivity-engine](client-reactivity-engine.md) — signal graph primitives (`source`, `set`, `get`, `user_pre_effect`)
- [client-dom-renderer](client-dom-renderer.md) — `on`, event delegation, listener teardown
- [compiler-transformer_client-transform](compiler-transformer_client-transform.md) — compiler phase that emits calls into this module
- [public-api](public-api.md) — modern `createEventDispatcher` and event idioms
- [internal-shared-utils](internal-shared-utils.md) — shared `noop`, `is_array` helpers
