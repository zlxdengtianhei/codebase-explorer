# client-reactivity-engine

## 1. Introduction & Purpose

`client-reactivity-engine` is the **fine-grained signals runtime** that powers client-side reactivity in Svelte 5 (rooted at `packages/svelte/src/internal/client/`). It implements the machinery behind the runes — `$state`, `$derived`, `$effect`, `$props`, `$effect.pre`, `$inspect` — as well as the batching scheduler that turns writes into minimal, ordered DOM work.

The engine is a **lazy, pull-based dependency graph with push-based invalidation**:

| Responsibility | Where it lives |
|---|---|
| Dependency tracking, dirty-checking, signal reads (`get`), `untrack`, `tick`/`settled` | `internal/client/runtime.js` |
| Signal type model (`Signal` / `Value` / `Reaction` / `Derived` / `Effect`) | `internal/client/reactivity/types.d.ts` |
| State creation & writes (`source`, `state`, `set`, `internal_set`, `mutate`, `update`) | `internal/client/reactivity/sources.js` |
| Deep reactive objects & arrays (ES `Proxy` over sources) | `internal/client/proxy.js` |
| Derived (computed) signals, incl. async deriveds | `internal/client/reactivity/deriveds.js` |
| Effects: creation, scheduling, teardown, destruction, pause/resume | `internal/client/reactivity/effects.js` |
| Batching, flush cycles, `flushSync`, scheduling, suspension | `internal/client/reactivity/batch.js` |
| rAF-driven long-running tasks (transitions/animations) | `internal/client/loop.js` |
| Async reactivity (`await` in components, context capture/restore) | `internal/client/reactivity/async.js` |
| Component props (bindable props, rest/spread props) | `internal/client/reactivity/props.js` |
| Svelte store auto-subscription bridge | `internal/client/reactivity/store.js` |
| Operating-mode switches (legacy / async / tracing) | `internal/flags/index.js` |
| Equality strategies per signal | `internal/client/reactivity/equality.js` |

The engine deliberately does **not** own DOM structure. It computes *what* changed and *when* to run effects; *how* the DOM is created, hydrated, patched, transitioned, or destroyed is owned by the sibling module **[client-dom-renderer](client-dom-renderer.md)**. Dev-only diagnostics (ownership validation, `$inspect`, HMR wrappers, location tagging) live in **[client-dev-tooling](client-dev-tooling.md)**, and Svelte 4 compatibility shims in **[legacy-compat](legacy-compat.md)**.

---

## 2. Position in the Client Runtime

The Svelte **compiler** (see [compiler-transformer](compiler-transformer.md)) does not emit framework calls at runtime — it emits calls *into this module*. A compiled component is essentially a script of `$.` primitives that build and drive the signal graph:

```mermaid
flowchart LR
    subgraph Compiler["Compiler (build time)"]
        X["compiler-transformer<br/>client visitors"]
    end

    subgraph Engine["client-reactivity-engine (this module)"]
        CORE["runtime.js<br/>tracking + dirty checks"]
        SRC["sources.js / proxy.js<br/>state"]
        DER["deriveds.js<br/>computed + async"]
        EFF["effects.js<br/>reaction tree"]
        BAT["batch.js / loop.js<br/>scheduler"]
        SURF["props.js / store.js<br/>component surface"]
        FLAGS["flags/index.js + equality.js"]
    end

    subgraph DOM["client-dom-renderer"]
        BLOCKS["dom/blocks/*<br/>if / each / await / boundary"]
        ATTRS["attributes, bindings,<br/>transitions, hydration"]
    end

    X -- "emits $.get / $.set / $.state /<br/>$.user_effect / $.proxy / $.prop ..." --> Engine
    Engine -- "template_effect(fn), block(),<br/>attribute_effect(...)" --> DOM
    DOM -- "reads/writes signals" --> Engine
    BAT -- "commit callbacks append/remove<br/>branches" --> DOM
```

Every UI framework feature is expressed through this vocabulary:

- `let count = $state(0)` → `$.state(0)` (a `Source`, optionally wrapped in `$.proxy` for objects)
- `let doubled = $derived(count * 2)` → `$.derived(() => ...)`
- `$effect(() => console.log(count))` → `$.user_effect(() => ...)`
- `<button on:click={() => count++}>` → `$.update(count_source)` inside an event handler
- `let { value = 0 } = $props()` → `$.prop($$props, 'value', flags, 0)`

---

## 3. Architecture Overview

### 3.1 Layered view

```mermaid
flowchart TB
    subgraph L4["Component binding surface"]
        PROPS["props.js<br/>prop / rest_props / spread_props"]
        STORE["store.js<br/>store_get / setup_stores"]
    end

    subgraph L3["Async reactivity"]
        ASYNC["async.js<br/>save / flatten / async_body"]
    end

    subgraph L2["Scheduling & effects"]
        EFF["effects.js<br/>create_effect / destroy / pause / resume"]
        BAT["batch.js<br/>Batch / flushSync / schedule_effect / suspend"]
        LOOP["loop.js<br/>loop / run_tasks (rAF)"]
    end

    subgraph L1["Signal graph core"]
        RUNTIME["runtime.js<br/>get / update_reaction / is_dirty /<br/>update_effect / tick / untrack"]
        SOURCES["sources.js<br/>source / set / internal_set /<br/>mark_reactions / update"]
        DERIVEDS["deriveds.js<br/>derived / async_derived /<br/>execute_derived / update_derived"]
        PROXY["proxy.js<br/>proxy() traps over sources"]
    end

    subgraph L0["Foundation"]
        TYPES["types.d.ts<br/>Signal / Value / Reaction /<br/>Derived / Effect"]
        FLAGS["flags/index.js<br/>legacy / async / tracing modes"]
        EQ["equality.js<br/>equals / safe_equals"]
    end

    L0 --> L1
    L1 --> L2
    L2 --> L3
    L1 --> L4
    L2 --> L4
```

### 3.2 The signal model

All graph nodes share a compact shape (see [client-reactivity-engine_signal-graph](client-reactivity-engine_signal-graph.md)):

```mermaid
classDiagram
    class Signal {
        +number f   // flags bitmask: status + kind
        +number wv  // write version
    }
    class Value {
        +Equals equals
        +Reaction[] reactions
        +number rv  // last-read version
        +any v      // current value
    }
    class Reaction {
        +ComponentContext ctx
        +Function fn
        +Value[] deps
        +AbortController ac
    }
    class Derived {
        +Effect[] effects
        +Effect|Derived parent
    }
    class Effect {
        +TemplateNode nodes_start
        +TemplateNode nodes_end
        +Function teardown
        +TransitionManager[] transitions
        +Effect prev / next / first / last
        +Effect parent
        +Boundary b
    }
    Signal <|-- Value : "is a readable"
    Signal <|-- Reaction : "is a runnable"
    Value <|-- Source : "state"
    Value <|-- Derived
    Reaction <|-- Derived
    Reaction <|-- Effect
```

Three design invariants make the graph cheap:

1. **Version numbers instead of eager recomputation.** Every write bumps a global `write_version` and stamps the signal's `wv`. A reaction's dirtiness is checked by comparing dependency `wv`s against the reaction's own `wv` — *no value is recomputed until someone actually reads it* (`get()` → `is_dirty()` → `update_derived()`).
2. **Read-version de-duplication.** While a reaction runs, each dependency read is stamped with the current `read_version` (`rv`), so a signal read twice is registered as a dependency only once. If a reaction reads the same dependencies in the same order as its last run, only `skipped_deps` is bumped — avoiding array allocation in the common "unchanged deps" case.
3. **Flat linked-list effect trees.** Effects form a tree via `first/last/prev/next`, enabling O(1) insertion, whole-subtree destruction, and pruning: effects with no deps/teardown/DOM are unlinked from the graph as soon as they have run.

### 3.3 Signal status lifecycle

Statuses are bits in `signal.f` managed by `set_signal_status()`:

```mermaid
stateDiagram-v2
    [*] --> DIRTY : created (derived/effect start dirty)
    [*] --> CLEAN : source created
    CLEAN --> MAYBE_DIRTY : dependency wv bumped (mark_reactions)
    CLEAN --> DIRTY : direct write / branch resume
    MAYBE_DIRTY --> DIRTY : any dep wv > reaction wv (is_dirty)
    MAYBE_DIRTY --> CLEAN : is_dirty() verified all deps unchanged
    DIRTY --> CLEAN : update_reaction ran (update_effect / update_derived)
    CLEAN --> DESTROYED : destroy_effect / unlink
    DIRTY --> DESTROYED
    MAYBE_DIRTY --> DESTROYED
```

`MAYBE_DIRTY` is the engine's key optimization: a deep dependency change marks ancestors *maybe* dirty rather than dirty, so `is_dirty()` can walk only as far as the first unchanged dependency and conclude "clean" without recomputing anything.

---

## 4. Write → Flush Pipeline

The complete journey of a state change (the per-phase details are in the sub-module docs):

```mermaid
sequenceDiagram
    autonumber
    participant U as User code / event handler
    participant S as set() — sources.js
    participant B as Batch — batch.js
    participant E as effects tree
    participant R as runtime.js
    participant D as client-dom-renderer

    U->>S: set(source, value) / proxy trap / update()
    S->>S: guard state_unsafe_mutation<br/>equality check via equals()
    S->>B: Batch.ensure().capture(source, old)
    S->>S: source.wv = ++write_version
    S->>B: mark_reactions → DIRTY, schedule_effect
    B->>B: walk parents to root,<br/>queue root effect

    Note over B: microtask (or flushSync)
    B->>E: Batch.process(root_effects)
    E->>E: traverse tree, skip clean/inert branches
    E->>R: update_effect(effect) [dirty effects]
    R->>R: destroy children, run teardown,<br/>update_reaction: set active_reaction,<br/>run effect fn
    R->>R: get(signal) inside fn →<br/>registers deps, lazily updates deriveds
    R->>D: template_effect writes → text/attr updates
    B->>D: #commit() → add/remove branch callbacks
```

Key behaviours owned by each layer:

- **`set()` guards**: writes from inside deriveds/block-effects throw `state_unsafe_mutation` (runes mode); writes are associated with the active `Batch` for time-travel support when multiple concurrent batches exist (async mode).
- **`mark_reactions()`**: pushes `DIRTY` to direct reactions, `MAYBE_DIRTY` cascades through deriveds, schedules block effects, and in DEV queues inspect effects (`$inspect`) to run immediately.
- **`Batch.process()`**: in async mode, if any async effects are in flight, sync work is *deferred* (`#defer_effects`) and flushed when the batch's pending counter hits zero — enabling `await` in components without tearing.
- **`untracked_writes`**: writes performed inside an effect that the effect doesn't (yet) read are remembered so that `schedule_possible_effect_self_invalidation()` can self-invalidate the effect if it later reads them (e.g. `$effect(() => x++)`).

---

## 5. Operating Modes

Module-level flags in `internal/flags/index.js` (see [client-reactivity-engine_foundation](client-reactivity-engine_foundation.md)) select execution paths throughout the engine:

| Flag | Enabled by | Effect on the engine |
|---|---|---|
| `legacy_mode_flag` | Compiling without runes / `createClassComponent` | Props fall back to Svelte 4 semantics (`derived_safe_equal`, never reverting to fallback), `$$props` coarse-grained versioning, legacy `$:` statements via `legacy_pre_effect`, `mutable_source` registers with component context for `beforeUpdate`/`afterUpdate` |
| `async_mode_flag` | `{ experiments: { async } }` | `tick()` waits a frame instead of flushing sync; multiple concurrent batches "time travel" source values; `#render_effects` deferred; `$effect.pending`/boundary suspension (`suspend()`) gate commits; `flushSync` inside effects is forbidden |
| `tracing_mode_flag` | `$inspect.trace()` in DEV | Sources record `created`/`updated` stacks; `get()` captures traces per reaction; proxies tag themselves with dev labels via `update_path` |

---

## 6. Sub-modules

```mermaid
flowchart TB
    F["**Foundation**<br/>flags / equality<br/><i>client-reactivity-engine_foundation</i>"]
    SG["**Signal graph core**<br/>runtime.js / types.d.ts<br/><i>client-reactivity-engine_signal-graph</i>"]
    SP["**Sources & state proxies**<br/>sources.js / proxy.js<br/><i>client-reactivity-engine_sources-and-proxies</i>"]
    DA["**Deriveds & async reactivity**<br/>deriveds.js / async.js<br/><i>client-reactivity-engine_deriveds-and-async</i>"]
    EFF["**Effects**<br/>effects.js<br/><i>client-reactivity-engine_effects</i>"]
    BS["**Batching & scheduling**<br/>batch.js / loop.js<br/><i>client-reactivity-engine_batching-scheduling</i>"]
    PS["**Props & stores**<br/>props.js / store.js<br/><i>client-reactivity-engine_props-and-stores</i>"]

    F --> SG
    F --> SP
    F --> DA
    SG --> SP
    SG --> DA
    SG --> EFF
    SP --> DA
    SP --> PS
    DA --> BS
    EFF --> BS
    BS --> SG
    EFF --> DA
```

| Sub-module | Files | Documentation |
|---|---|---|
| **Signal graph core** | `runtime.js`, `reactivity/types.d.ts` — dependency tracking, `get`, `update_reaction`, `is_dirty`, `update_effect`, `tick`/`settled`, `untrack` | [client-reactivity-engine_signal-graph](client-reactivity-engine_signal-graph.md) |
| **Sources & state proxies** | `reactivity/sources.js`, `proxy.js` — signal creation, writes, invalidation, deep reactive objects/arrays | [client-reactivity-engine_sources-and-proxies](client-reactivity-engine_sources-and-proxies.md) |
| **Deriveds & async reactivity** | `reactivity/deriveds.js`, `reactivity/async.js` — computed signals, async deriveds, `await` context capture | [client-reactivity-engine_deriveds-and-async](client-reactivity-engine_deriveds-and-async.md) |
| **Effects** | `reactivity/effects.js` — effect kinds, creation, destruction, pause/resume, teardown | [client-reactivity-engine_effects](client-reactivity-engine_effects.md) |
| **Batching & scheduling** | `reactivity/batch.js`, `loop.js` — `Batch`, `flushSync`, effect scheduling, rAF tasks | [client-reactivity-engine_batching-scheduling](client-reactivity-engine_batching-scheduling.md) |
| **Props & stores** | `reactivity/props.js`, `reactivity/store.js` — bindable/rest/spread props, store auto-subscription | [client-reactivity-engine_props-and-stores](client-reactivity-engine_props-and-stores.md) |
| **Foundation** | `internal/flags/index.js`, `reactivity/equality.js` — mode flags, equality strategies | [client-reactivity-engine_foundation](client-reactivity-engine_foundation.md) |

---

## 7. Relationship to Other Modules

- **[Compiler_Pipeline___Language_Toolchain](Compiler_Pipeline___Language_Toolchain.md)** — the [client transform](compiler-transformer_client-transform.md) emits every primitive this engine exports (`$.state`, `$.derived`, `$.user_effect`, `$.template_effect`, `$.block`, `$.prop`, `$.store_get`, …). The shape of the engine API *is* the compiler's code-generation target.
- **[client-dom-renderer](client-dom-renderer.md)** — template cloning, blocks (`each`, `if`, `await`, `boundary`), attribute/bindings, transitions and hydration consume the engine: they run inside `block()`/`branch()` effects, receive values via `template_effect`, and register DOM-removal work as batch commit callbacks. `render.js` (`mount`/`hydrate`/`unmount`) wraps components in `component_root()` effect roots.
- **[client-dev-tooling](client-dev-tooling.md)** — the engine calls *into* dev tooling: `dev/tracing.js` (`tag`, `get_stack`) for `$inspect.trace`, `dev/ownership.js` for cross-component mutation validation, `dev/inspect.js` for `$inspect` effects. The engine's ERROR_VALUE protocol and dev warnings (`state_unsafe_mutation`, `await_reactivity_loss`) surface through it.
- **[legacy-compat](legacy-compat.md)** — legacy components are bridged via `invalidate_inner_signals`, `captured_signals` (imported by `runtime.js`) and `legacy_pre_effect`/`legacy_pre_effect_reset` in `effects.js`.
- **[Public_API___Built-in_Feature_Surface](Public_API___Built-in_Feature_Surface.md)** — `tick`/`settled`/`flushSync` semantics back the public `svelte` API; the [stores](Public_API___Built-in_Feature_Surface.md) module's `subscribe_to_store`/`get` are consumed by `store.js`, and `toStore`/`fromStore` convert between stores and sources. `motion` (spring/tweened) and `transition` run their timelines on `loop.js`'s rAF scheduler.
- **[Engineering_Tooling](Engineering_Tooling_(Benchmarks,_Verification___Playground).md)** — the `reactivity_benchmarks` (kairo/sbench/mol) exercise exactly these primitives (`$state`/`$derived`/`$effect` graphs) to guard performance characteristics such as diamond dependency and broad-update throughput.

---

## 8. Error Handling & Correctness Guarantees

The engine enforces several invariants at runtime (errors are defined in `internal/client/errors.js` and surfaced via `handle_error`/`invoke_error_boundary` in `error-handling.js`):

| Guarantee | Mechanism |
|---|---|
| No state mutation during derived evaluation | `set()` throws `state_unsafe_mutation` when `active_reaction` is a derived/block/async/inspect effect |
| No `flushSync` inside effects (async mode) | `e.flush_sync_in_effect()` |
| Infinite update loops detected | `flush_effects` counts >1000 flush iterations → `effect_update_depth_exceeded`, routed to the nearest boundary; DEV mode prints per-source update stacks |
| Errors in deriveds defer until read | `handle_error` sets `ERROR_VALUE` on unowned deriveds; `get()` throws `signal.v` at the read site |
| Errors bubble to `<svelte:boundary>` | effects with `EFFECT_RAN` → `invoke_error_boundary`; creation-time errors walk to `Boundary.error()`; async effects inside boundaries collect via `#boundary_async_effects` and don't block commits |
| Self-referential deriveds caught in DEV | `execute_derived` maintains a stack → `derived_references_self` |
| Stale async work aborted | reaction `ac` (`AbortController`) aborted with `STALE_REACTION` on destroy or re-run; `old_values` map serves consistent values to teardown functions running after writes |

---

## 9. Quick Reference — Engine Primitives

| Compiled output | Engine function | Module |
|---|---|---|
| `$state(v)` | `state(v)` / `proxy(v)` for objects | sources-and-proxies |
| `x = y`, `x++` | `set`, `update`, `update_pre`, `mutate` | sources-and-proxies |
| `$derived(expr)` | `user_derived` / `derived` / `derived_safe_equal` | deriveds-and-async |
| `await expr` (async mode) | `save` / `flatten` / `async_body` | deriveds-and-async |
| `$effect(fn)` / `$effect.pre(fn)` | `user_effect` / `user_pre_effect` / `render_effect` | effects |
| `{#if}` / `{#each}` / `{#await}` / `{#key}` | `block` / `branch` | effects |
| `untrack(expr)` | `untrack` | signal-graph |
| `$effect.root(fn)` / component root | `effect_root` / `component_root` | effects |
| `{@render snippet(...)}` args | `block`-scoped effects + snippet wrappers | effects / client-dom-renderer |
| `$props()` destructuring | `prop`, `rest_props`, `spread_props` | props-and-stores |
| `$store` auto-subscription | `store_get`, `setup_stores`, `store_mutate` | props-and-stores |
| `$inspect.trace()` | tracing flags + `get_stack` hooks | foundation / client-dev-tooling |
