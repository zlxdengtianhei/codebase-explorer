# Server Transform — Script Transform (`compiler-transformer_server-transform_script-transform`)

## 1. Introduction

The **script-transform** module is the collection of **JavaScript/AST rewriting visitors** inside the Svelte compiler's server-side transform phase (`3-transform/server`). While the sibling sub-modules of `server-transform` render the *template* (HTML fragments, control-flow blocks, components and snippets) into SSR output code, this module is responsible for everything that turns the **script-level code** of a `.svelte` component — `<script>` content, class state fields, `{@const}` tags and legacy `$:` reactive statements — into **plain, synchronous JavaScript** that executes during server-side rendering (SSR).

Its core responsibilities are:

1. **Rune desugaring** — rewriting runes (`$state`, `$derived`, `$props`, `$effect.*`, `$inspect`, `$host`) into plain expressions plus calls to runtime helpers from `svelte/internal/server` (referenced as `$.*`).
2. **Legacy syntax lowering** — converting `export let` props, `$store` auto-subscriptions, and `$:` labeled reactive statements into explicit SSR-compatible code.
3. **Class state lowering** — transforming class field runes (`$state` / `$derived` on class properties) into backing fields with getter/setter accessors.
4. **Server-specific semantics enforcement** — e.g. rejecting `await` outside `<svelte:boundary>`, neutralizing client-only runes (`$effect.tracking` → `false`, `$host` → `void 0`), and funneling identifier references through store getters / sanitized props.
5. **Emitting into shared statement buffers** — pushing statements into the component `init` / `hoisted` / template buffers that `transform-server.js` assembles into the final `Program`.

Every visitor in this module is a **pure AST-to-AST function** `(node, context) => Node | void` driven by the [zimmerframe](https://github.com/Rich-Harris/zimmerframe) walker: returning `undefined` (or calling `context.next()`) continues traversal, returning a node replaces it.

> **Module location:** `packages/svelte/src/compiler/phases/3-transform/server/visitors/`
> **Part of:** [Compiler Pipeline — Language Toolchain](compiler-core.md) → `compiler-transformer` → `server-transform` → `script-transform`

---

## 2. Position in the Compiler Pipeline

The script-transform visitors are registered as `global_visitors` in `transform-server.js` and are applied during **all three** walk passes (module script, instance script, and template AST — where they are merged with the template-specific visitors). This is because script-level constructs (identifiers, assignments, rune calls, class bodies) can appear inside template expressions such as `{a + b}` or event/attribute expressions.

```mermaid
flowchart TB
    P1["1-parse<br/>(parser, read_options)"] --> P2["2-analyze<br/>(scope, visitors, css-analyze)"]
    P2 --> Phase3

    subgraph Phase3["3-transform — server generation"]
        direction TB
        TS["transform-server.js<br/>server_component(analysis, options)"]
        subgraph GV["global_visitors (script-transform — this module)"]
            V1["VariableDeclaration"]
            V2["AssignmentExpression"]
            V3["CallExpression"]
            V4["Identifier"]
            V5["AwaitExpression"]
            V6["UpdateExpression"]
            V7["ClassBody / PropertyDefinition / MemberExpression"]
            V8["ConstTag / LabeledStatement"]
        end
        TV["template_visitors<br/>(Fragment, RegularElement, EachBlock, …)"]
        OUT["Assembled ESTree Program<br/>(hoisted + instance + template)"]
    end

    P2 -.->|"analysis: bindings, scopes,<br/>runes flag, state_fields"| GV
    GV -->|"rewritten AST + buffered statements"| TS
    TV -->|"SSR template statements"| TS
    TS --> OUT
    OUT --> RT["Server Runtime<br/>svelte/internal/server (dollar helpers)"]
    OUT -.->|"calls helpers in at runtime"| RT
```

The final output imports `svelte/internal/server` as `$` (the first hoisted statement) and every helper call emitted by this module (`$.store_get`, `$.derived`, …) resolves against that namespace. The helper implementations live in the [Server-Side Rendering & Cross-Target Runtime Services](server-runtime.md) module.

---

## 3. Architecture & Component Relationships

### 3.1 Visitor catalog

| Visitor file | Node(s) handled | Mode(s) | Summary |
|---|---|---|---|
| `VariableDeclaration.js` | `VariableDeclaration` | runes + legacy | Lowers `$props`, `$state`, `$derived` declarations and `export let` into plain declarators (with destructuring expansion). |
| `AssignmentExpression.js` | `AssignmentExpression` | runes + legacy | Dispatches to shared destructuring logic; handles store assignment (`$store = …`) and class state-field assignment. Exports `build_assignment`. |
| `CallExpression.js` | `CallExpression` | runes + legacy | Desugars rune calls (`$state()`, `$derived()`, `$effect.*`, `$inspect`, `$host`, `$state.snapshot`). |
| `Identifier.js` | `Identifier` | runes + legacy | Rewrites references: `$$props` → `$$sanitized_props`; `$store` subs → `$.store_get(...)`. |
| `AwaitExpression.js` | `AwaitExpression` | both | Allows top-of-script / in-function `await`; rewrites illegal `await` to `$.await_outside_boundary()`. |
| `UpdateExpression.js` | `UpdateExpression` | legacy | Rewrites `$store++` / `$store--` into `$.update_store(_pre)` calls. |
| `ClassBody.js` | `ClassBody` | runes (noop legacy) | Inserts backing fields + accessor pairs for `$derived` class state; handles constructor-declared fields. |
| `MemberExpression.js` | `MemberExpression` | runes | Turns `this.#derivedField` reads into getter calls `this.#derivedField()`. |
| `PropertyDefinition.js` | `PropertyDefinition` | runes | Lowers class fields: `$state` → plain value, `$derived` → `$.derived(thunk)` backing field. |
| `ConstTag.js` | `AST.ConstTag` | both | `{@const x = e}` → `const` statement pushed into the component `init` buffer. |
| `LabeledStatement.js` | `LabeledStatement` | legacy only | Captures `$:` statements into `legacy_reactive_statements` for later topological ordering; emits `b.empty` in place. |

### 3.2 Component interaction map

```mermaid
flowchart LR
    subgraph Walk["zimmerframe walk (transform-server.js)"]
        Z["walk(ast, state, visitors)"]
    end

    subgraph Module["script-transform visitors"]
        VD[VariableDeclaration]
        AE[AssignmentExpression<br/>+ build_assignment]
        CE[CallExpression]
        ID[Identifier]
        AW[AwaitExpression]
        UE[UpdateExpression]
        CB[ClassBody]
        ME[MemberExpression]
        PD[PropertyDefinition]
        CT[ConstTag]
        LS[LabeledStatement]
    end

    subgraph SharedInfra["Shared infrastructure"]
        VA["shared/assignments.js<br/>visit_assignment_expression"]
        SU["shared/utils.js<br/>build_getter<br/>(see shared-utils module)"]
        TU["3-transform/utils.js<br/>transform_inspect_rune"]
        B["compiler-core builders (b.*)"]
        SC["phases/scope.js<br/>get_rune, Scope, set_scope"]
        AU["utils/ast.js<br/>extract_paths, build_fallback,<br/>build_assignment_value"]
    end

    subgraph State["Transform state"]
        STS["ServerTransformState<br/>analysis · options · scope · scopes · state_fields<br/>legacy_reactive_statements"]
        CSTS["ComponentServerTransformState<br/>init[] · hoisted[] · template[]"]
    end

    Z --> Module
    VD --> SC & AU & B
    AE --> VA & SC
    VA --> AU
    ID --> SU
    CE --> TU & SC
    LS --> STS
    CT --> CSTS
    CB --> STS
    Module -->|"mutates / reads"| State
```

### 3.3 Execution flow: how a script-level node is transformed

```mermaid
flowchart TD
    A["walk visits AST node"] --> B{"Visitor registered<br/>for node.type?"}
    B -->|yes| C["Invoke visitor(node, context)"]
    B -->|no| D["default descent<br/>(context.next)"]
    C --> E{"visitor transforms node?"}
    E -->|"returns new node"| F["replacement replaces original<br/>children (if any) are re-walked"]
    E -->|"returns undefined / context.next()"| D
    F --> G["continue with next node"]
    D --> G
```

Key conventions shared by all visitors in this module:

- **`get_rune(node, scope)`** (`phases/scope.js`) is the gatekeeper: it resolves a `CallExpression` callee to a rune keypath (e.g. `'$derived.by'`) only if it is an unshadowed global reference. Visitors branch on the returned rune.
- **`context.state.analysis.runes`** distinguishes runes mode from legacy mode; several visitors maintain two entirely separate code paths.
- **`b.*` builders** (`compiler/utils/builders.js`) construct all replacement ESTree nodes (see [compiler-core AST builders](compiler-core_ast_builders.md)).

---

## 4. Component Details

### 4.1 `VariableDeclaration` — declarations & props lowering

The largest visitor. It processes each declarator independently and rebuilds the declaration.

**Runes mode (`analysis.runes === true`)**

| Declarator shape | Transformation |
|---|---|
| No rune call, or `$effect.tracking` / `$inspect` / `$effect.root` | Visited as-is (no reactive semantics on the server). |
| `$props.id()` | Dropped entirely (`continue`) — ids are meaningless during SSR. |
| `let { … } = $props()` | Becomes `= $$props` with two safeguards: (a) `$bindable(x)` defaults are unwrapped to `x` via an `AssignmentPattern` walk; (b) if a rest element exists (or `$props` is captured as a plain identifier), the rest pattern is rewritten to omit internals — `$$slots` is re-bound to `$$slots_` when `analysis.uses_slots` to deconflict, and `$$events` is excluded from rest spread. |
| `let x = $derived(expr)` | `declarator` kept, but the visited `expr` becomes the initializer directly (no call wrapper — SSR evaluates deriveds eagerly). |
| `let x = $derived.by(fn)` | Initializer becomes a call of the visited function: `x = fn()`. |
| `let {a} = $state(init)` / destructured rune init | Delegated to `create_state_declarators` (see below). |
| Identifier declarators with any rune | Initializer becomes the visited first argument (or `void 0`). |

**Legacy mode**

Declarators are classified through `scope.get_bindings`:

- No `state` / `bindable_prop` bindings → visited as-is.
- **`export let x = fallback`** → `x = $.fallback($$props['x' /* or prop_alias */], <visited fallback>)`. `build_fallback` (`utils/ast.js`) emits `$.fallback(expr, fallback[, eager])`, wrapping non-simple fallbacks in thunks and awaiting async ones.
- **Destructured `export let { x: foo, z: [bar] } = …`** → leaf names become the props. Implementation: a temp identifier (`tmp`) receives the visited init, `extract_paths` splits the pattern into `inserts` (array-index temporaries, renamed via `scope.generate('$$array')`) and `paths`; each leaf is initialized from `$$props[alias ?? name]` with its destructuring default as fallback.
- **`let x = <init>` where binding kind is `state`** → `create_state_declarators` expands destructured initializers:
  1. `tmp` declarator holding the raw init,
  2. `inserts` temporaries for nested array access,
  3. one declarator per extracted path.

If nothing remains, the visitor returns `b.empty` (the whole statement disappears); otherwise it returns the original node with the rebuilt `declarations` array.

### 4.2 `AssignmentExpression` & `build_assignment` — writes

```mermaid
flowchart TD
    A["AssignmentExpression node"] --> B["visit_assignment_expression<br/>(shared/assignments.js)"]
    B --> C{"left is destructuring pattern<br/>(Array/Object/Rest)?"}
    C -->|yes| D["explode via extract_paths;<br/>per-path build_assignment;<br/>wrap in IIFE/sequence when in expression position"]
    C -->|no| E["build_assignment(operator, left, right, context)"]
    E --> F{"runes mode AND<br/>this.#field / this.field<br/>assignment?"}
    F -->|"'this.x = $state(...)' in constructor"| G["plain assignment to<br/>this.#key or this.key"]
    F -->|"'this.#derived = v'"| H["this.#derivedGetter(value)<br/>(derived setter call)"]
    F -->|no| I{"root object is a<br/>$store auto-subscription?"}
    I -->|"whole left is $store"| J["$.store_set(store, value)"]
    I -->|"$store.member …"| K["$.store_mutate($$store_subs ??= {},<br/>  '$store', store, assignment)"]
    I -->|no| L["null → keep original<br/>(context.next fallback)"]
```

Key behaviors:

- **Constructor state initialization**: during class lowering, `$state` fields declared *inside the constructor* appear as `this.x = $state(v)` assignments. The visitor consults `state_fields` (`analysis.classes`) — if the field's recorded node is exactly this assignment and the right-hand side is a rune, it emits a plain assignment keyed on `this.<property>` (private identifier, or the analysis-computed `field.key` for `$state`/`$state.raw`).
- **Derived writes**: `this.#derivedField op= value` compiles to `this.#derivedField(<combined value>)` — the lowered accessor pair generated by `ClassBody` exposes a setter that forwards into the underlying `$.derived` signal.
- **Store assignments** (`is_store_name`: leading `$` followed by `[A-Za-z_]`, and the un-prefixed name resolves in scope):
  - `left` *is* the store root → `$.store_set(name, value)`.
  - assignment targets a member/index of the store → `$.store_mutate($$store_subs ??= {}, '$name', name, <rewritten assignment>)`. `$$store_subs` is the deferred-unsubscribe registry that `transform-server.js` drains at the end of rendering (`$.unsubscribe_stores`).

### 4.3 `CallExpression` — rune desugaring table

| Rune | Server output | Rationale |
|---|---|---|
| `$host()` | `void 0` | No component host element exists during SSR. |
| `$effect.tracking()` | `false` | Never inside a reactive effect context on the server. |
| `$effect.root(fn)` | `() => { … }` (no-op arrow mimicking cleanup fn) | Effects never run during SSR; cleanup is a noop. |
| `$effect.pending()` | `0` | No pending async work signal server-side. |
| `$state(v)` / `$state.raw(v)` | visited `v`, or `void 0` | State is a plain value during render. |
| `$derived(expr)` | `$.derived(() => expr)` | Thunk preserves laziness for the runtime helper. |
| `$derived.by(fn)` | `$.derived(fn)` | Function passed directly. |
| `$state.snapshot(x)` | `$.snapshot(x, ignored?)` | Second arg is `true` when `state_snapshot_uncloneable` is in the ignore list (`is_ignored` from `compiler/state.js`). |
| `$inspect(...)` / `$inspect(...).with(fn)` | `$.inspect([...], fn)` — dev only, `b.empty` in production | Via shared `transform_inspect_rune`. |
| anything else | `context.next()` | Ordinary call — descend. |

### 4.4 `Identifier` — reference rewriting

Only **references** (determined with the `is-reference` helper against the parent node) are rewritten; binding sites are left alone:

- `$$props` → `$$sanitized_props` (the runtime pre-filters reserved keys such as `$$slots`/`$$events`; see [server-runtime attributes-and-props](server-runtime.md)).
- Bindings of kind `store_sub` (`$name` in templates/scripts) → `$.store_get($$store_subs ??= {}, '$name', name)` via `build_getter` (`shared/utils.js`). The getter recursively walks the store id, so `name` (the actual store variable) resolves normally.
- Everything else passes through unchanged (function returns `undefined`).

### 4.5 `AwaitExpression` — top-level await policing

The visitor first checks `context.state.scope.function_depth === 0` or whether any ancestor is a function node — if the `await` is at the top level of the instance/module script, or inside *any* function body, it is kept (`context.next()`), because the render function is `async` and `<script module>` code runs at module scope.

Otherwise — i.e. `await` in the *template* outside a `<svelte:boundary>` — the expression is replaced by `$.await_outside_boundary()`, a runtime helper that throws the corresponding compile/runtime error when executed. (The analysis phase raises the static diagnostic; this is the server-side escape hatch for dynamic cases.)

### 4.6 `UpdateExpression` — store increments

For `argument` being an identifier whose binding kind is `store_sub`:

```
$store++   →  $.update_store($$store_subs ??= {}, '$store', store)          // postfix
++$store   →  $.update_store_pre($$store_subs ??= {}, '$store', store)      // prefix
$store--   →  $.update_store($$store_subs ??= {}, '$store', store, -1)      // direction literal
```

A `b.literal(-1)` argument is appended *only* for the `--` operator (the 4th parameter is `undefined` otherwise, so `node.operator === '--' && b.literal(-1)` evaluates to `false`, which the builder drops). Non-store updates fall through via `context.next()`.

### 4.7 `ClassBody` — class state lowering

Runes-mode only; legacy classes are passed through untouched.

```mermaid
flowchart TD
    A["ClassBody node"] --> B{"analysis.classes.get(node)<br/>has state_fields?"}
    B -->|no| C["legacy mode → context.next()"]
    B -->|yes| D["child_state = state + state_fields"]
    D --> E{"for each field (name, field):"}
    E -->|"constructor-declared derived field<br/>(field.node is AssignmentExpression)"| F["emit private backing property +<br/>get/set accessor pair forwarding to<br/>this.backingKey() / this.backingKey(value)"]
    E -->|"private field declaration"| G["visited as-is"]
    D --> H{"for each definition in node.body:"}
    H -->|non-PropertyDefinition| I["visit with child_state"]
    H -->|PropertyDefinition without known field| I
    H -->|"private / state / state.raw field"| J["visited as-is (already lowered<br/>by PropertyDefinition)"]
    H -->|"derived field declared as property"| K["replace with:<br/>backingKey = derived value (visited)<br/>get key() returns this.backingKey()<br/>set key(value) forwards to this.backingKey(value)"]
```

The generated public accessors are what `MemberExpression` and `AssignmentExpression` later target (`this.#derived()` reads / `this.#derived(v)` writes).

### 4.8 `MemberExpression` — derived field reads

In runes mode, a member expression of the form `this.#privateName` whose field type (from `state.state_fields`) is `$derived`/`$derived.by` is rewritten to a **call** of that member — `b.call(node)` — i.e. `this.#field` becomes `this.#field()`. This matches the accessor layout produced by `ClassBody`/`PropertyDefinition`, where the backing private field holds the `$.derived` function rather than a value.

### 4.9 `PropertyDefinition` — class field initializers

For runes-mode fields whose initializer is a rune call:

| Field | Output |
|---|---|
| `x = $state(v)` / `x = $state.raw(v)` | `x = <visited v>` (initializer dropped entirely when no argument is passed) |
| `x = $derived(expr)` | `x = $.derived(() => expr)` (thunk) |
| `x = $derived.by(fn)` | `x = $.derived(fn)` |
| anything else | `context.next()` |

### 4.10 `ConstTag` — `{@const}` tags

Does *not* return a replacement node. Instead it visits the tag's declaration (`id` and `init`) and **pushes a `const` statement into `context.state.init`** — the component's initialization statement buffer consumed by the template walk (the `Fragment` visitor). This guarantees `{@const}` bindings exist before the surrounding markup renders, matching Svelte's "const is hoisted to its immediate block render" semantics in the flat SSR output.

### 4.11 `LabeledStatement` — legacy `$:` reactive statements

```mermaid
sequenceDiagram
    participant W as walk (transform-server)
    participant LS as LabeledStatement visitor
    participant ST as state.legacy_reactive_statements (Map)
    participant TS as transform-server.js (post-pass)

    W->>LS: LabeledStatement `$: stmt`
    alt runes mode OR nested OR label ≠ `$`
        LS-->>W: undefined (skip — plain label)
    else legacy top-level `$:`
        LS->>LS: visit(node.body)
        Note over LS: label kept — user code may `break $`
        LS->>ST: set(node, b.labeled('$', visitedBody))
        LS-->>W: b.empty (removed in place)
    end
    Note over TS: after all walks:
    TS->>ST: iterate in analysis.reactive_statements order
    TS->>TS: hoist `let` declarators for legacy_reactive bindings
    TS->>TS: append ordered statements to instance.body
```

Details:

- Guard: only legacy mode (`!analysis.runes`), path length 1 (top level of the instance script), and label `$` are captured; all other labeled statements are ignored (returned `undefined`, so the walker descends normally).
- The captured statement is registered in `state.legacy_reactive_statements`; `transform-server.js` later replays them in the **topologically-sorted order precomputed by the analysis phase** (`analysis.reactive_statements`), prepending a single `let` declaration for every `legacy_reactive` binding assigned by an `$: x = …` statement so the statements may execute in dependency order rather than source order.

---

## 5. State & Context Model

All visitors receive the zimmerframe `Context`, typed in `server/types.d.ts`:

```ts
interface TransformState {              // 3-transform/types.d.ts
    readonly analysis: Analysis;         // runes flag, classes (state_fields), uses_slots, …
    readonly options: ValidatedModuleCompileOptions;
    readonly scope: Scope;               // current lexical scope (set per node by set_scope)
    readonly scopes: Map<AST.SvelteNode, Scope>;
    readonly state_fields: Map<string, StateField>;
}

interface ServerTransformState extends TransformState {
    readonly legacy_reactive_statements: Map<LabeledStatement, Statement>;  // `$:` buffer
}

interface ComponentServerTransformState extends ServerTransformState {
    readonly analysis: ComponentAnalysis;
    readonly options: ValidatedCompileOptions;
    readonly init: Statement[];          // ConstTag pushes here; drained by Fragment
    readonly hoisted: Array<Statement | ModuleDeclaration>;  // imports + module-level code
    readonly template: Array<Statement | Expression>;        // SSR output statements
    readonly namespace: Namespace;
    readonly preserve_whitespace: boolean;
    readonly skip_hydration_boundaries: boolean;
}
```

Statement buffers are the module's main **output channel**: `ConstTag` → `init`; `LabeledStatement` → `legacy_reactive_statements`; the hoisting of imports/`$$store_subs` is finalized by `transform-server.js` after all walks complete.

---

## 6. Runtime Helper Contract

Every `$.*` call emitted by this module is fulfilled by the server runtime (see [server-runtime](server-runtime.md) / [internal-shared-utils](internal-shared-utils.md)):

| Emitted helper | Purpose | Provided by |
|---|---|---|
| `$.store_get`, `$.store_set`, `$.store_mutate`, `$.update_store`, `$.update_store_pre`, `$.unsubscribe_stores` | Legacy store auto-subscription protocol; `$$store_subs` registry drained after render. | `server-runtime_store-integration` |
| `$.derived` | Server derived evaluation. | `server-runtime_render-pipeline` |
| `$.snapshot` | `$state.snapshot` deep clone. | server runtime |
| `$.inspect` | Dev-only `$inspect` logging (no-op path is compiled out in production). | server runtime |
| `$.await_outside_boundary` | Throws for illegal `await`. | server runtime |
| `$.fallback` | Prop/destructuring default evaluation with "changed" detection. | server runtime |
| `$.stringify` | Value escaping inside templates (used by shared template utils, not directly here). | `internal-shared-utils_core-utilities` |

---

## 7. Dependencies

```mermaid
flowchart TD
    subgraph This["script-transform (this module)"]
        V["11 visitors"]
    end

    CC["compiler-core<br/>errors, warnings, builders,<br/>state.is_ignored, types"]
    AN["compiler-analyzer<br/>scope/get_rune, binding kinds,<br/>state_fields, reactive_statements"]
    PA["compiler-parser<br/>produces the parsed AST walked here"]
    SS["server-transform siblings<br/>shared/assignments.js and shared/utils.js"]
    TI["3-transform/utils.js<br/>transform_inspect_rune"]
    ZW["zimmerframe (walk/Context)"]
    IR["is-reference"]
    RT["svelte/internal/server runtime"]

    V --> CC & AN & SS & TI & ZW & IR
    AN --> PA
    V -.->|"emits calls into"| RT
```

- **Upstream (consumes):** the analysis phase output (scopes, bindings, runes classification, `state_fields`, `reactive_statements` ordering) — see [compiler-analyzer](compiler-analyzer.md) and [compiler-analyzer scope](compiler-analyzer_scope.md); AST node types from [compiler-core type definitions](compiler-core_type_definitions.md).
- **Downstream (feeds):** `transform-server.js` assembly, then the emitted component executes against the [server runtime](server-runtime.md).
- **Peer visitors** that consume the same state buffers: [template-rendering](compiler-transformer_server-transform_template-rendering.md) (drains `init`, renders elements), [control-flow](compiler-transformer_server-transform_control-flow.md), [components-snippets](compiler-transformer_server-transform_components-snippets.md), [shared-utils](compiler-transformer_server-transform_shared-utils.md).

---

## 8. End-to-End Process Flow

```mermaid
sequenceDiagram
    autonumber
    participant API as compile API
    participant TS as transform-server.server_component
    participant W as zimmerframe walk
    participant SV as script-transform visitors
    participant BUF as state buffers

    API->>TS: (analysis, options) with server generation
    TS->>BUF: hoisted gets import of svelte/internal/server
    TS->>W: walk module AST with global_visitors
    W->>SV: module-level nodes (vars, classes, calls)
    SV->>BUF: rewrite runes and buffer statements
    TS->>W: walk instance AST with global_visitors plus import/export shims
    W->>SV: instance nodes
    SV->>SV: props lowering, reactive label capture, store rewrites
    SV->>BUF: legacy_reactive_statements and init statements
    TS->>W: walk template AST with global + template visitors
    W->>SV: embedded expressions (identifiers, assignments, calls)
    SV->>BUF: rewritten expressions into template buffer
    TS->>TS: order reactive statements topologically
    TS->>TS: hoist let declarations for legacy_reactive bindings
    TS->>TS: drain store_subs registry (unsubscribe_stores guard)
    TS-->>API: assembled ESTree Program
```

---

## 9. Design Notes & Extension Guidance

- **Adding a rune:** extend `CallExpression` (inline expression contexts) and/or `VariableDeclaration`/`PropertyDefinition` (declaration contexts); never assume client semantics — server transforms must stay synchronous and side-effect-minimal.
- **Destructuring:** any place a pattern may appear (`$props`, `$state`, `export let`, destructuring assignment) must go through `extract_paths` + `create_state_declarators`/`visit_assignment_expression` to keep expansion consistent.
- **Legacy vs. runes:** keep the two code paths separate — legacy behavior is frozen (it exists for compatibility), while runes-mode is where new features land.
- **Class state:** the accessor layout (`#key` backing field + public get/set + derived-as-method) is a cross-cutting contract shared by `ClassBody`, `PropertyDefinition`, `MemberExpression`, and `AssignmentExpression` — changes must update all four consistently (the client transformer mirrors this design; see [client-transform structural visitors](compiler-transformer_client-transform_structural-visitors.md)).
- **Pure visitors:** visitors must not rely on evaluation order beyond the walker's; all cross-statement coordination happens through the state buffers listed in §5.
