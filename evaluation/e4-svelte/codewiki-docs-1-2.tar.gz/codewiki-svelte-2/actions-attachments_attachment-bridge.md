# Attachment Bridge (`actions-attachments_attachment-bridge`)

> **Module location:** `packages/svelte/src/attachments/index.js`
> **Parent module:** [`actions-attachments`](actions-attachments.md) → [`Public_API___Built-in_Feature_Surface`](public-api.md)
> **Stability:** Public API — `createAttachmentKey` (since 5.29), `fromAction` (since 5.32)

## 1. Introduction

The **attachment bridge** is a small but strategically important module in Svelte 5's public API surface. It sits between two element-augmentation paradigms:

- **Actions** — the legacy Svelte 4 mechanism, applied via the `use:` directive, following the `Action` contract: `(node, parameter) => void | { update?, destroy? }`.
- **Attachments** — the Svelte 5 mechanism, applied via the `{@attach ...}` tag (or programmatically via a spread key), following the `Attachment` contract: `(element) => void | (() => void)`.

The module exports exactly two functions:

| Export | Purpose | Since |
|---|---|---|
| `createAttachmentKey()` | Produces a `Symbol` key that, when spread onto an element, is interpreted as an attachment — the programmatic counterpart of `{@attach ...}` | 5.29 |
| `fromAction(action, fn?)` | Adapts an existing `Action` into an `Attachment`, preserving update/destroy semantics — the migration bridge from `use:` to `{@attach}` | 5.32 |

Both functions are intended primarily for **library authors** who need to ship behavior that works through the attachment pipeline without requiring consumers to author attachments directly.

## 2. Public API Reference

### 2.1 `createAttachmentKey()`

```js
function createAttachmentKey(): symbol
```

Returns `Symbol(ATTACHMENT_KEY)` where `ATTACHMENT_KEY = '@attach'` (defined in `packages/svelte/src/constants.js`). Because the key is a symbol with the reserved `'@attach'` description, the runtime's attribute/spread handling recognizes it specially: when an object containing this key is spread onto an element (`{...props}`), the value under the key is treated as an attachment function rather than a plain attribute.

```svelte
<script>
	import { createAttachmentKey } from 'svelte/attachments';

	const props = {
		class: 'cool',
		onclick: () => alert('clicked'),
		[createAttachmentKey()]: (node) => {
			node.textContent = 'attached!';
		}
	};
</script>

<button {...props}>click me</button>
```

**Key characteristics:**
- Pure function with no side effects; each call yields a distinct symbol, but all such symbols share the `'@attach'` description that the runtime dispatches on.
- The symbol's description — not its identity — is what matters, so keys can be created anywhere (component, library, utility module).

### 2.2 `fromAction(action, fn?)`

```js
function fromAction<E extends EventTarget, T>(
	action: Action<E, T> | ((element: E, arg: T) => void | ActionReturn<T>),
	fn?: () => T // default: noop (returns undefined)
): Attachment<E>
```

Returns an `Attachment<E>` — a function `(element) => void` — that, when invoked by the attachment runtime, runs the wrapped action and keeps its `update`/`destroy` lifecycle intact. It supports two overloads: one for actions with a reactive parameter, one for parameterless actions.

```svelte
<!-- with an action -->
<div use:foo={bar}>...</div>

<!-- equivalent with an attachment -->
<div {@attach fromAction(foo, () => bar)}>...</div>
```

**Critical contract detail:** the second argument is a *getter function* that *returns* the argument (`() => bar`), not the argument itself. This indirection is what allows `fromAction` to track reactivity of the parameter and invoke the action's `update` hook when it changes.

## 3. Architecture and Component Relationships

The bridge module is a thin adapter layer composed of three cooperating pieces: the action contract (input side), the attachment contract (output side), and the client reactivity engine (lifecycle plumbing).

```mermaid
flowchart TB
    subgraph Public["Public API surface"]
        CAK["createAttachmentKey()<br/>packages/svelte/src/attachments/index.js"]
        FA["fromAction(action, fn?)<br/>packages/svelte/src/attachments/index.js"]
    end

    subgraph Contracts["Type contracts"]
        ACT["Action&lt;E, T&gt;<br/>(node, param) => void &#124; ActionReturn<br/>action/public.d.ts"]
        ATT["Attachment&lt;T&gt;<br/>(element) => void &#124; (() => void)<br/>types/index.d.ts"]
    end

    subgraph Runtime["Client runtime (internal)"]
        UT["untrack()<br/>runtime.js — suspend dependency tracking"]
        RE["render_effect()<br/>reactivity/effects.js — reactive update effect"]
        TD["teardown(fn)<br/>reactivity/effects.js — register cleanup hook"]
        ATTACH["attach(node, get_fn)<br/>dom/elements/attachments.js — attachment consumer"]
        SPREAD["Spread-attribute handling<br/>recognizes Symbol('@attach') keys"]
    end

    CONST["ATTACHMENT_KEY = '@attach'<br/>constants.js"]

    FA -- "wraps / adapts" --> ACT
    FA -- "returns" --> ATT
    CAK -- "Symbol(ATTACHMENT_KEY)" --> CONST
    CAK -- "value consumed by" --> SPREAD
    ATT -- "invoked inside branch effect of" --> ATTACH
    FA --> UT
    FA --> RE
    FA --> TD
```

### Dependency map

| Symbol used | Source | Role in the bridge |
|---|---|---|
| `noop` | `svelte/internal/client` | Default parameter getter for parameterless actions |
| `render_effect` | `internal/client/reactivity/effects.js` | Creates the effect that re-runs `update(arg)` when `fn()` changes |
| `teardown` | `internal/client/reactivity/effects.js` | Registers the action's `destroy` callback on a dedicated clean render effect, so it fires when the owning attachment effect is destroyed |
| `untrack` | `index-client.js` → `internal/client/runtime.js` | Executes the initial action call outside dependency tracking |
| `ATTACHMENT_KEY` | `../constants.js` | Reserved symbol description (`'@attach'`) that triggers attachment dispatch on spread |

The effect primitives themselves are documented in [`client-reactivity-engine_effects`](client-reactivity-engine_effects.md), and the tracking machinery behind `untrack` in [`client-reactivity-engine_signal-graph`](client-reactivity-engine_signal-graph.md).

## 4. How the System Consumes Attachments

`fromAction` and `createAttachmentKey` only *produce* attachment values — two downstream mechanisms consume them:

### 4.1 The `{@attach ...}` compiler path

The client transformer's `AttachTag` visitor (see [`compiler-transformer_client-transform_directive-visitors`](compiler-transformer_client-transform_directive-visitors.md)) compiles

```svelte
<div {@attach fromAction(foo, () => bar)}>...</div>
```

into an initialization statement:

```js
$.attach(node, () => fromAction(foo, () => bar));
```

### 4.2 The runtime `attach` consumer

The internal `attach(node, get_fn)` function (`internal/client/dom/elements/attachments.js`) re-evaluates the thunk inside a `block` effect. Whenever the returned attachment function's **identity changes**, it destroys the previous branch effect (firing all `teardown`-registered cleanups — including action `destroy` callbacks registered by `fromAction`) and creates a new branch in which the attachment function is invoked with the node. The attachment body itself runs inside an `effect`, so reactive reads made by the attachment re-execute it.

### 4.3 The spread-attribute path (`createAttachmentKey`)

When props objects are spread onto elements, the attribute-handling layer (see [`client-dom-renderer_attributes-events`](client-dom-renderer_attributes-events.md)) inspects each key; keys that are symbols with the `'@attach'` description are dispatched to the same attachment machinery instead of being set as DOM attributes. This is what makes `createAttachmentKey()` work with plain `{...props}` syntax — no compiler involvement required.

```mermaid
flowchart LR
    A["Source: {@attach expr}"] --> B["Compiler: AttachTag visitor<br/>(3-transform/client)"]
    B --> C["$.attach(node, () => expr)"]
    D["Source: {...props} with<br/>Symbol('@attach') key"] --> E["Spread attribute handling<br/>(client runtime)"]
    E --> C
    C --> F["attach(): block effect<br/>tracks attachment identity"]
    F --> G["branch effect: fn(node)"]
    G --> H["teardown hooks fire on<br/>identity change / unmount"]
```

## 5. `fromAction` Lifecycle (Process Flow)

The sequence below traces what happens from attachment creation to teardown:

```mermaid
sequenceDiagram
    participant C as Compiler/runtime
    participant FA as fromAction wrapper
    participant AC as Action (user code)
    participant FX as Reactivity engine

    C->>FA: invoke attachment(element)
    FA->>FX: untrack(...)
    FA->>AC: action(element, fn())  [initial run, untracked]
    AC-->>FA: { update?, destroy? } (may be undefined → {})
    alt action returns update
        FA->>FX: render_effect(() => { if ran: update(fn()) })
        Note over FA: ran=false → first run skipped<br/>(initial arg already passed)
        FA->>FA: ran = true
    end
    alt action returns destroy
        FA->>FX: teardown(destroy)
    end

    Note over FX: Later — fn() changes:
    FX->>AC: update(newArg)  (via render_effect)

    Note over FX: Later — element removed or<br/>attachment identity changed:
    FX->>AC: destroy()  (teardown hook fires)
```

### Behavioral contract details

1. **Untracked initialization.** The initial `action(element, fn())` call is wrapped in `untrack`, so any reactive state read during action setup does *not* create dependencies. Only the `render_effect` (which reads `fn()` per invocation) subscribes to the parameter.
2. **The `ran` flag.** Render effects execute their body once immediately upon creation. The `ran` sentinel ensures this first execution does not redundantly call `update` with the value already passed during the direct initial call; only subsequent runs (i.e., actual parameter changes) invoke `update`.
3. **Null-safe destructuring.** Actions may return `undefined` (parameterless side effects only). The `?? {}` coalescing makes `update`/`destroy` lookups safe without requiring action authors to return an object.
4. **Destroy propagation.** By registering `destroy` through `teardown`, the callback is wired into the effect tree: it fires when the branch effect owning the attachment is destroyed — either on element unmount *or* when the `{@attach}` expression produces a new function identity (the runtime `attach` consumer then re-runs the whole lifecycle with the new attachment).
5. **Default parameter getter.** When `fn` is omitted, `noop` supplies `undefined` as the parameter, matching actions declared as `Action<E>` (i.e., `Parameter = undefined`).

## 6. Design Rationale

- **Migration, not replacement.** Large ecosystems of `use:` actions exist. `fromAction` lets component authors adopt attachments (which compose better with snippets, SSR-safe spreading, and reactive parameters as getters) while continuing to consume third-party actions unchanged.
- **Contract translation.** The action contract (object with `update`/`destroy` members, parameter passed positionally) is materially different from the attachment contract (optional cleanup function returned, parameters captured via closure/getter). `fromAction` is the single, well-tested point where that translation happens.
- **Library ergonomics.** `createAttachmentKey` extends attachment support to imperative scenarios (component libraries exporting props bags) where template-level `{@attach}` tags are not expressible.

## 7. Usage Guidelines

**Do** use `fromAction` when composing existing action libraries inside attachment-based components or libraries.

**Do** pass a *getter* for the parameter — `<div {@attach fromAction(fx, () => param)}>` — otherwise changes to `param` will not trigger the action's `update` hook.

**Avoid** using `createAttachmentKey` in app code where the `{@attach}` tag is directly writable; it exists chiefly for programmatic/library scenarios.

**Note** that attachments (and therefore `fromAction` wrappers) run **client-side only**; unlike plain attributes, they have no server-render representation.

## 8. Related Documentation

- [`actions-attachments`](actions-attachments.md) — parent module overview and action/attachment ecosystem
- [`actions-attachments_action-contract`](actions-attachments_action-contract.md) — the `Action` / `ActionReturn` type contract this bridge adapts
- [`public-api`](public-api.md) — full public API surface, including `Attachment` in `svelte/types/index.d.ts`
- [`compiler-transformer_client-transform_directive-visitors`](compiler-transformer_client-transform_directive-visitors.md) — `AttachTag` visitor that lowers `{@attach}` to `$.attach`
- [`client-reactivity-engine_effects`](client-reactivity-engine_effects.md) — `render_effect` / `teardown` primitives used by the bridge
- [`client-reactivity-engine_signal-graph`](client-reactivity-engine_signal-graph.md) — `untrack` and dependency-tracking semantics
- [`client-dom-renderer_attributes-events`](client-dom-renderer_attributes-events.md) — spread-attribute handling that dispatches `Symbol('@attach')` keys
- [`client-dom-renderer_control-flow-blocks`](client-dom-renderer_control-flow-blocks.md) — effect branching/teardown lifecycle that governs attachment cleanup
