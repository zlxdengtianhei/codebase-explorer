#!/usr/bin/env python3
"""Independent recomputation from raw judge text, plus filtered gateway accounting."""
import csv
import hashlib
import io
import json
from pathlib import Path
import statistics
import subprocess

D=Path(__file__).resolve().parent
QFILES=[D.parent/'verify'/p/'questions_verified.jsonl' for p in ['A','B']]
EXPECTED_SHA256=['67e128d378d5ab82b256f4c0e19912e243ed0f1a0d9816c05f229df52faee187','94dad9d9ae901061c20c939dd76b8d61857cb2dbece7043229adc2d2021dfcdb']
assert [hashlib.sha256(p.read_bytes()).hexdigest() for p in QFILES]==EXPECTED_SHA256,'Frozen question inputs changed during production'
def lines(path):return [json.loads(s) for s in path.read_text().splitlines() if s.strip()]
qs=sorted([q for p in QFILES for q in lines(p)],key=lambda q:q['cid'])
qmap={q['cid']:q for q in qs}

def independently_score(row):
    q=qmap[row['cid']];answer=row['answer'];votes={r['id']:[] for r in q['rubric']}
    if any(r['status']!='ok' for r in row['replicates']):
        assert row['score'] is None
        return None
    assert len(row['replicates'])==3
    for replicate in row['replicates']:
        raw=replicate['attempts'][-1]['response']['choices'][0]['message']['content'].strip()
        if raw.startswith('```'):raw=raw.split('\n',1)[1].rsplit('```',1)[0].strip()
        obj=json.loads(raw);items=obj['items'] if isinstance(obj,dict) else obj
        assert len(items)==len(votes)
        for item in items:
            valid=bool(item['quote'].strip()) and item['quote'].strip().lower() in answer.strip().lower()
            votes[item['id']].append(item['satisfied'] and valid)
    majority={rid:sum(v)>=2 for rid,v in votes.items()}
    weight=sum(r['weight'] for r in q['rubric'] if r['kind']!='negative')
    earned=sum(r['weight'] for r in q['rubric'] if r['kind']!='negative' and majority[r['id']])
    penalty=sum(majority[r['id']] for r in q['rubric'] if r['kind']=='negative')
    score=max(0,100*(earned-penalty)/weight)
    core=all(majority[r['id']] for r in q['rubric'] if r['kind']=='core')
    assert abs(score-row['score'])<1e-9,(row['cid'],score,row['score'])
    assert row['core_all_satisfied']==core
    assert all(i['satisfied']==majority[i['id']] for i in row['items'])
    return score

ref=lines(D/'refcheck.jsonl');wrong=lines(D/'sanity_wrong.jsonl');closed=lines(D/'closed_book_scores.jsonl');answers=lines(D/'closed_book_answers.jsonl')
assert {r['cid'] for r in ref}==set(qmap) and len(ref)==len(qs)
assert {r['cid'] for r in closed}==set(qmap) and len(closed)==len(qs)
assert {r['cid'] for r in answers}==set(qmap) and len(answers)==len(qs)
assert len(wrong)==3
amap={a['cid']:a for a in answers}
assert all(r['answer']==amap[r['cid']]['answer'] for r in closed),'Scored answer differs from captured answer'
assert all(r['answer']==qmap[r['cid']]['reference_answer'] for r in ref),'Reference self-check input mismatch'
wrong_inputs={a['answer_id']:a['answer'] for a in lines(D/'sanity_wrong_answers.jsonl')}
assert all(r['answer']==wrong_inputs[r['answer_id']] for r in wrong)
for row in ref+wrong+closed:independently_score(row)
assert all(r['score'] is not None and r['score']<70 for r in wrong),'Sanity wrong answer did not lose sufficient points'
# Verify the closed-book input whitelist and that tool configuration never enters messages.
template=(D/'closed_book_prompt.txt').read_text()
system_template,user_template=template.split('\n\nUSER\n',1)
system_template=system_template.removeprefix('SYSTEM\n')
for row in answers:
    user=row['messages'][1]['content'];q=qmap[row['cid']]
    assert row['messages']==[{'role':'system','content':system_template},{'role':'user','content':user_template.format(question=q['question'],build_assumptions=q['build_assumptions'])}]
    assert q['question'] in user and q['build_assumptions'] in user
    assert q['reference_answer'] not in user
    assert '<build_assumptions>' in user

protocol=json.loads((D/'protocol_deviation.json').read_text())
protocol_affected=set(protocol['affected_cids_inferred'])
rows=[{'cid':r['cid'],'protocol_affected_inferred':r['cid'] in protocol_affected,'layer':qmap[r['cid']]['layer'],'swe_type':qmap[r['cid']]['swe_type'],
       'score':r['score'],'exclude':None if r['score'] is None else r['score']>=70,
       'core_all_satisfied':r['core_all_satisfied']} for r in sorted(closed,key=lambda r:r['cid'])]
valid=[r['score'] for r in rows if r['score'] is not None]
removed=[r['cid'] for r in rows if r['exclude']]
by_layer={str(k):{'total':sum(r['layer']==k for r in rows),'excluded':sum(r['layer']==k and bool(r['exclude']) for r in rows)} for k in sorted({r['layer'] for r in rows})}
by_type={k:{'total':sum(r['swe_type']==k for r in rows),'excluded':sum(r['swe_type']==k and bool(r['exclude']) for r in rows)} for k in sorted({r['swe_type'] for r in rows})}
hist={f'{lo}-{lo+10}'+(' inclusive' if lo==90 else ' exclusive upper'):sum(lo<=s and (s<=100 if lo==90 else s<lo+10) for s in valid) for lo in range(0,100,10)}
percentiles=statistics.quantiles(valid,n=100,method='inclusive')
result={'threshold':70,'protocol_deviation':protocol,'quantiles':{f'p{p}':percentiles[p-1] for p in [10,25,50,75,90]},'inputs':[{'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in QFILES],
        'questions':rows,'excluded_cids':removed,'excluded_count':len(removed),'excluded_fraction':len(removed)/len(rows),
        'n':len(rows),'NA':len(rows)-len(valid),'mean':statistics.mean(valid),'median':statistics.median(valid),
        'min':min(valid),'max':max(valid),'histogram':hist,'by_layer':by_layer,'by_type':by_type,
        'halt_over_half':len(removed)>len(rows)/2,
        'verification':'Independently parsed final raw response of each replicate, checked quote substrings, recomputed item majorities, penalties, score and core flag.'}
(D/'filter.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
# Query gateway via CLI and persist ONLY this task's sessions.
proc=subprocess.run(['magpie','usage','--csv','--last','24h'],text=True,capture_output=True,check=True,timeout=60)
reader=csv.DictReader(io.StringIO(proc.stdout));fields=reader.fieldnames
usage=[r for r in reader if r['session'] in {'e5q2-refcheck','e5q2-sanity','e5q2-closedbook-answer','e5q2-closedbook'}]
with (D/'gateway_window.csv').open('w') as f:
    w=csv.DictWriter(f,fields);w.writeheader();w.writerows(usage)
summary={}
for session in sorted({r['session'] for r in usage}):
    rs=[r for r in usage if r['session']==session]
    s={'requests':len(rs)}
    for k in ['input_tokens','output_tokens','cache_read_tokens','cache_write_tokens','reasoning_tokens','cost_usd']:
        s[k]=sum(float(r[k] or 0) for r in rs)
    s['total_tokens_including_cache']=sum(s[k] for k in ['input_tokens','output_tokens','cache_read_tokens','cache_write_tokens'])
    s['statuses']={k:sum(r['status']==k for r in rs) for k in sorted({r['status'] for r in rs})}
    summary[session]=s
(D/'gateway_usage.json').write_text(json.dumps(summary,indent=2)+'\n')
gateway_ids={(r['session'],r['response_id']) for r in usage if r.get('response_id')}
expected_ids=[]
for row in ref+wrong+closed:
    for replicate in row['replicates']:
        for attempt in replicate['attempts']:
            if attempt.get('response',{}).get('id'):
                assert attempt['response']['model']=='gpt-6.1-sol','Unexpected served judge model'
                expected_ids.append((row['session'],attempt['response']['id']))
for row in answers:
    assert row['request']['response']['model']=='glm-5.3-flash','Unexpected served answer model'
    expected_ids.append(('e5q2-closedbook-answer',row['request']['response']['id']))
assert len(expected_ids)==len(set(expected_ids)),'A response ID was reused across judgments/answers'
assert set(expected_ids)<=gateway_ids,'Some raw successful responses are not attributable by gateway session/response_id'
assert sum(hist.values())==len(valid)
timed_requests=[a for row in ref+wrong+closed for rep in row['replicates'] for a in rep['attempts'] if 'started_epoch' in a]+[a['request'] for a in answers]
request_span=max(a['started_epoch']+a['wall_seconds'] for a in timed_requests)-min(a['started_epoch'] for a in timed_requests)
checks={'questions':len(qs),'answer_wall_seconds':{'median':statistics.median(a['request']['wall_seconds'] for a in answers),'max':max(a['request']['wall_seconds'] for a in answers)},'model_request_span_seconds':request_span,'gateway_response_ids_matched':len(expected_ids),'scores_recomputed':len(ref)+len(wrong)+len(closed),'ref_mean':statistics.mean(r['score'] for r in ref if r['score'] is not None),
        'ref_below_90':[{'cid':r['cid'],'score':r['score'],'missing':[i['id'] for i in r['items'] if i['kind']!='negative' and not i['satisfied']]} for r in ref if r['score'] is None or r['score']<90],
        'sanity':[{'cid':r['cid'],'score':r['score'],'negative_violations':r.get('negative_violations')} for r in wrong],
        'closed_book':{k:result[k] for k in ['excluded_count','excluded_fraction','mean','median','min','max','NA','halt_over_half']},
        'gateway_sessions':summary}
(D/'verification.json').write_text(json.dumps(checks,indent=2)+'\n')
print(json.dumps(checks,indent=2))
