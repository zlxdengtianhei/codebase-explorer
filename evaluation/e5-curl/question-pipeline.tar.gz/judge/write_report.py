"""Render the coordinator report after independent recomputation succeeds."""
import os
os.environ.setdefault('WORK', os.environ.get('CBE_WORK_ROOT', os.getcwd()))
os.environ.setdefault('TMP', os.environ.get('TMPDIR', '/tmp'))
import json
from pathlib import Path
import statistics
D = Path(__file__).resolve().parent
out = Path(os.path.expandvars('$TASK_DIR/scratch/opt_e5/e5q2_result.md'))
f = json.loads((D / 'filter.json').read_text())
v = json.loads((D / 'verification.json').read_text())
usage = json.loads((D / 'gateway_usage.json').read_text())
refs = [json.loads(x) for x in (D / 'refcheck.jsonl').read_text().splitlines()]
closed = [json.loads(x) for x in (D / 'closed_book_scores.jsonl').read_text().splitlines()]
rows = f['questions']
b11 = next((r for r in closed if r['cid'] == 'B11'))
b11_r1 = next((i for i in b11['items'] if i['id'] == 'r1'))
b11_upper = b11['score'] + (0 if b11_r1['satisfied'] else b11_r1['weight'] / b11['positive_weight'] * 100)
L = ['# E5q2：rubric 判官与闭卷过滤', '', f"55 道核过候选的判官自检与闭卷过滤已执行；参考自判均分 **{v['ref_mean']:.2f}**，闭卷剔除 **{f['excluded_count']}/55（{100 * f['excluded_fraction']:.2f}%）**，阈值固定 ≥70。", '本轮闭卷“一题答一次”有偏离：首轮有一份成功答案在保存前丢失，随后重答。本结果需由主会话决定是否采用；作者程序自验成立。判官脚本为 `runs/e5q/judge/rubric_judge.py`，选题和 rubric 处置仍由主会话负责。', '', '## 判官与自检', '', '判官 codex/gpt-6.1-sol，经指定 Magpie；每份答案三次独立判定，逐条多数。仅给题面、构建前提、rubric 与待判答案，不给另附参考答案正文或源码。', '正向加权，反向每违反一条扣 1，除以正向总权重后乘 100、最低 0；引文经 trim+lower 子串校验。解析/请求失败最多重试两次，失败副本使答案记 NA。', f"参考自判范围 {min((r['score'] for r in refs)):.2f}–{max((r['score'] for r in refs)):.2f}；核心条全满足 {sum((r['core_all_satisfied'] for r in refs))}/55。低于 90 的题：B11，83.33（r1 三次均不满足）。", 'B11 归为判官问题（变量代入过严的假阴性，待主会话确认）：参考答案写“maxdownload = Y-X+1, here 100 bytes”和“resume_from to X”；题面给 X=100，但判官未认可 resume_from=100。', '定位：`refcheck.jsonl` cid=B11、replicates[*].items[id=r1]；输入 B/questions_verified.jsonl 的 reference_answer 首段与 rubric r1。未读源码，未改 rubric；正式使用前建议主会话决定是否校准变量代入规则。', f"B11 闭卷 {b11['score']:.2f}；仅把 r1 补为满足的分数上界为 {b11_upper:.2f}，{('仍低于 70，不改变本题过滤决定' if b11_upper < 70 else '可能影响过滤，需主会话复核')}。此项为单条敏感性界限，未用于正式得分。", '其余非满分：' + '；'.join((f"{r['cid']} {r['score']:.2f}" for r in refs if r['score'] != 100 and r['cid'] != 'B11')) + '。', '错答自检 A01、B01、B02 各 0 分；前两题各识别两条反向违反，第三题无关函数/流程不获正向分。三份全文、逐次判词均保存在 sanity_wrong*.jsonl。', '', '## 闭卷设置与分布', '', '作答 zai/glm-5.3-flash；temperature=0、无工具；仅题面与构建前提。每题保留一份答案，但首轮有成功响应丢失后重答，偏离“一题答一次”，详见末段。完整提示模板 closed_book_prompt.txt，逐题实际 messages 在 closed_book_answers.jsonl。', '提示来自 e1 harness 的 qa_agent.py 作答提示：去掉工具说明、工具步骤与仓路径，保留详细全面回答和英文要求；加入尽力按已有知识回答。未用 E2 的精简直答提示。', f"闭卷均分 {f['mean']:.2f}，最小 {f['min']:.2f}，最大 {f['max']:.2f}；NA={f['NA']}。核心条全满足 {sum((r['core_all_satisfied'] is True for r in closed))}/55。分位数：" + '；'.join((f'{k.upper()}={x:.2f}' for k, x in f['quantiles'].items())) + '。', '分箱左闭右开，最后一箱含 100：' + '；'.join((f"{k.split(' ')[0]}: {n}" for k, n in f['histogram'].items())) + '。', '', '| 分组 | 候选 | 剔除 |', '|---|---:|---:|']
L += [f"| 层 {k} | {x['total']} | {x['excluded']} |" for k, x in f['by_layer'].items()]
L += [f"| {k} | {x['total']} | {x['excluded']} |" for k, x in f['by_type'].items()]
L += ['', '剔除名单为空；各层、各题型剔除数均为 0。' if not f['excluded_count'] else '剔除名单按层、题型（括号内闭卷分）：']
if f['excluded_count']:
    L.append('')
    for layer in sorted({r['layer'] for r in rows}):
        chunks = []
        for typ in sorted({r['swe_type'] for r in rows}):
            rs = [r for r in rows if r['layer'] == layer and r['swe_type'] == typ and r['exclude']]
            if rs:
                chunks.append(typ + ' ' + ', '.join((f"{r['cid']}({r['score']:.2f})" for r in rs)))
        L.append(f'- 层 {layer}：' + ('；'.join(chunks) if chunks else '无') + '。')
L += ['', f"每题分数与是否剔除见 filter.json 的 questions；完整剔除 ID 数组为 excluded_cids。{('剔除超过一半，已按要求停止并升级，不放宽阈值。' if f['halt_over_half'] else '剔除未超过一半，未触发停止升级条件。')}", '', '## 网关花费', '', '按 X-Magpie-Session 从 magpie usage --csv 的逐请求记录筛选；CSV 原件 gateway_window.csv，合计 gateway_usage.json。输入栏为未缓存输入，缓存读单列；输出含推理 token，不再重复相加。cost_usd 为网关标价成本，不等于另核实的订阅现金支出。', '', '| Session | 请求 | 输入 | 输出 | 缓存读 | 缓存写 | cost_usd |', '|---|---:|---:|---:|---:|---:|---:|']
for s, x in usage.items():
    L.append(f"| {s} | {x['requests']} | {int(x['input_tokens'])} | {int(x['output_tokens'])} | {int(x['cache_read_tokens'])} | {int(x['cache_write_tokens'])} | {x['cost_usd']:.6f} |")
L += ['', f"总计 {sum((x['requests'] for x in usage.values()))} 请求,含缓存 token {int(sum((x['total_tokens_including_cache'] for x in usage.values())))},网关标价 ${sum((x['cost_usd'] for x in usage.values())):.6f}。模型请求跨度 {v['model_request_span_seconds'] / 60:.1f} 分钟;单份保留答案耗时中位数/最大值 {v['answer_wall_seconds']['median']:.1f}/{v['answer_wall_seconds']['max']:.1f} 秒。", '请求均带指定 X-Magpie-Agent；网关 agent 栏归一成 Python-urllib，但 session 头原样进入记录，已实证可以筛出本实验。', '', '## 复核、输入与边界', '', f"独立复算脚本 recompute_results.py 从原始响应重解析全部 {v['scores_recomputed']} 份判分、逐条验引文并重算多数、得分、核心标记,与输出一致；覆盖数与闭卷提示白名单通过，{v['gateway_response_ids_matched']} 个原始响应均按 ID 匹配对应网关 session。", '本地检查覆盖大小写/首尾空白、虚构正反引文、反向扣分、缺失副本 NA、缺项与非布尔 schema、每副本最多两次重试及末次恢复；不是独立语义验收。', 'A sha256：`' + f['inputs'][0]['sha256'] + '`。', 'B sha256：`' + f['inputs'][1]['sha256'] + '`。', '未读 curl 源码、禁区或 docs 目录，未跑 cbe、未派 agent、未装包、未提交或推送。写域仅 judge/ 与本报告。', '协议偏离：首轮 600 秒超时使收集循环停下而线程池继续排队；停止后保留 A01/A04/A05 三份。首轮共 9 请求（4 成功、5 个 499），其中 1 份成功正文未落盘；缺题在修复逐题异常处理、仅延长客户端等待为 1800 秒后重试，无按分数挑答案。按排序队列和开始时间重建，受影响 CID 为 A02、A06–A10（首次未逐请求记 CID，此映射标为推断；丢失的成功响应重建为 A06）；filter.json 单列 protocol_affected_inferred，未把它混入 ≥70 剔除规则。详见 protocol_deviation.json；499 的实际未回报 token 无法核实。', '未完成项/边界：首份成功答案丢失后重答，未完全满足“一题答一次”；B11 判官假阴性未擅自调整；全量判分仅程序复算，未由独立人审语义；最终选题、rubric 处置和正式评测由主会话负责。', '复用示例：`python3 runs/e5q/judge/rubric_judge.py --questions runs/e5q/verify/A/questions_verified.jsonl runs/e5q/verify/B/questions_verified.jsonl --answers <answers.jsonl> --output <scores.jsonl> --session e5q2-formal --concurrency 4`。']
out.write_text('\n'.join(L) + '\n')
print(out, 'lines', len(L))
