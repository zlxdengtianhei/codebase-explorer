#!/usr/bin/env python3
"""E5q2 production driver; bounded, resumable, no tool access for answer model."""
import concurrent.futures
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time
import traceback
import rubric_judge as j
D = Path(__file__).resolve().parent
QFILES = [D.parent/'verify'/part/'questions_verified.jsonl' for part in ['A','B']]
QS = j.load_questions(QFILES)
TERM = 'term_7e363686-1e4e-474f-844d-d094639edc7f'
TASK = 'task_44e958371f4b'
DISPATCH = 'ctx_b73d98432574'
last_hb = 0

def write_jsonl(path, rows):
    path.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows))

def status(phase, n=0):
    global last_hb
    (D/'STATUS.json').write_text(json.dumps({'phase':phase,'completed':n,'epoch':time.time()}))
    if time.time()-last_hb >= 240:
        subprocess.run(['orca','orchestration','send','--from',TERM,'--type','heartbeat','--subject',f'{phase} {n}', '--task-id',TASK,'--dispatch-id',DISPATCH,'--phase','reviewing' if 'judge' in phase else 'implementing'],check=True)
        last_hb = time.time()

def checkpoint():
    subprocess.run(['orca','orchestration','check','--terminal',TERM,'--json'],check=True)

def judge_phase(answers, output, session):
    existing = j.load_jsonl(D/output) if (D/output).exists() else []
    seen = {a['answer_id'] for a in existing}
    qmap = {q['cid']:q for q in QS}
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool, (D/output).open('a') as f:
        pending = {pool.submit(j.judge,qmap[a['cid']],a,session) for a in answers if a.get('answer_id',a['cid']) not in seen}
        count = len(existing)
        # Maximum production window 12 h; each individual call is bounded at 600 s.
        for _ in range(2160):
            if not pending: break
            done,pending = concurrent.futures.wait(pending,timeout=20,return_when=concurrent.futures.FIRST_COMPLETED)
            for future in done:
                row=future.result(); f.write(json.dumps(row,ensure_ascii=False)+'\n');f.flush()
                count += 1; print(output,row['cid'],row['score'],flush=True)
            status(session,count)
        else: raise TimeoutError('Production phase exceeded 12h')
    # Canonical input order on completion.
    rows = j.load_jsonl(D/output)
    write_jsonl(D/output,sorted(rows,key=lambda r:r['answer_id']))
    checkpoint()

def answer_phase():
    path = D/'closed_book_answers.jsonl'
    existing = j.load_jsonl(path) if path.exists() else []
    seen = {a['cid'] for a in existing}
    template=(D/'closed_book_prompt.txt').read_text()
    system, user = template.split('\n\nUSER\n',1)
    system=system.removeprefix('SYSTEM\n')
    answer_lock = __import__('threading').Lock()
    def answer(q):
        messages=[{'role':'system','content':system},{'role':'user','content':user.format(question=q['question'],build_assumptions=q['build_assumptions'])}]
        with answer_lock, (D/'answer_requests.jsonl').open('a') as log:
            log.write(json.dumps({'cid':q['cid'],'started_epoch':time.time(),'client_timeout':1800})+'\n')
        record = j.request(messages,'zai/glm-5.3-flash','e5q2-closedbook-answer','e5-closedbook-answer',timeout=1800)
        text = record['response']['choices'][0]['message']['content']
        if not isinstance(text,str) or not text.strip(): raise ValueError('Empty answer')
        return {'cid':q['cid'],'answer':text,'request':record,'messages':messages}
    failures=[]
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool,path.open('a') as f:
        pending={pool.submit(answer,q):q['cid'] for q in QS if q['cid'] not in seen}
        count=len(existing)
        for _ in range(2160):
            if not pending:break
            done,_=concurrent.futures.wait(pending,timeout=20,return_when=concurrent.futures.FIRST_COMPLETED)
            for future in done:
                cid=pending.pop(future)
                try:
                    row=future.result();f.write(json.dumps(row,ensure_ascii=False)+'\n');f.flush()
                    count+=1;print('answer',row['cid'],flush=True)
                except Exception as exc:
                    failure={'cid':cid,'error':type(exc).__name__,'message':str(exc)[:500],'epoch':time.time()}
                    failures.append(failure)
                    with (D/'answer_transport_errors.jsonl').open('a') as errors:
                        errors.write(json.dumps(failure)+'\n')
                    print('ANSWER_FAILED',cid,failure['error'],flush=True)
            status('closedbook-answer',count)
        else:raise TimeoutError('Answer phase exceeded 12h')
    write_jsonl(path,sorted(j.load_jsonl(path),key=lambda r:r['cid']))
    checkpoint()
    if failures:raise RuntimeError(f'{len(failures)} answer transport failures, all other completed answers retained')
    return j.load_jsonl(path)

def main():
    j.ensure_key()
    (D/'input_manifest.json').write_text(json.dumps({'inputs':[{'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in QFILES], 'cids':[q['cid'] for q in QS]},indent=2))
    refs=[{'cid':q['cid'],'answer':q['reference_answer']} for q in QS]
    write_jsonl(D/'refcheck_answers.jsonl',refs)
    judge_phase(refs,'refcheck.jsonl','e5q2-refcheck')
    # Three deliberately contradictory answers; each asserts explicit negative rubric claims.
    wrong=[{'cid':'A01','answer_id':'A01-wrong','answer':'Curl_cwriter_add must link the gzip writer first, then add the pause writer. The call order is what places the pause writer before the new writer in the data flow. Curl_cwriter_free unlinks the writer from data->req.writer.stack, so freeing a linked writer is always safe. There is no risk of a dangling pointer or double free.'},
           {'cid':'B01','answer_id':'B01-wrong','answer':'libcurl blocks inside the close call, polling and waiting until all filters have finished shutdown. The connection stays in the connection pool (cpool) throughout shutdown. It then frees the connection immediately; there is no shutdown list, no admin handle retry, and no timer.'},
           {'cid':'B02','answer_id':'B02-wrong','answer':'This feature is handled entirely by printf and strlen. The program ignores all build assumptions and returns success without any callbacks, state changes, or allocation. No other functions participate.'}]
    write_jsonl(D/'sanity_wrong_answers.jsonl',wrong)
    judge_phase(wrong,'sanity_wrong.jsonl','e5q2-sanity')
    answers=answer_phase()
    judge_phase(answers,'closed_book_scores.jsonl','e5q2-closedbook')
    status('done',len(QS))
    (D/'DONE.json').write_text(json.dumps({'epoch':time.time(),'questions':len(QS)}))

if __name__=='__main__':
    try:main()
    except BaseException:
        (D/'FAILED.txt').write_text(traceback.format_exc());raise
