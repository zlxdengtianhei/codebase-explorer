# Testing Support (`flask.testing`)

> **Module:** Developer Interface → Testing Tooling → `testing-support`
> **Source code:** `src/flask/testing.py`
> **Test suite:** `tests/test_testing.py`

---

## 1. Purpose

The **testing-support** module is Flask's in-process testing toolkit. It allows developers to exercise an entire Flask application — routing, request handling, sessions, JSON serialization, error handling and CLI commands — **without starting a real HTTP server**. Instead of opening sockets, the toolkit builds WSGI environments programmatically and dispatches them straight into `Flask.wsgi_app()`.

The module answers three fundamental testing needs:

| Testing need | Solution | Wraps |
|---|---|---|
| Simulate HTTP requests against the app | `FlaskClient` | `werkzeug.test.Client` |
| Build WSGI environments/requests with app-aware defaults | `EnvironBuilder` | `werkzeug.test.EnvironBuilder` |
| Invoke CLI commands in-process | `FlaskCliRunner` | `click.testing.CliRunner` |

All three classes are created through factory methods on the [`Flask`](application-core.md) application object (`app.test_client()`, `app.test_request_context()`, `app.test_cli_runner()`), which keeps the public API centered on the app itself.

---

## 2. Architecture Overview

The module is a thin but critical **adapter layer**: it subclasses generic Werkzeug/Click test primitives and binds them to a specific `Flask` application, injecting app configuration (e.g. `SERVER_NAME`, `PREFERRED_URL_SCHEME`, `APPLICATION_ROOT`), Flask's context lifecycle, the app's JSON provider, and the session interface.

```mermaid
classDiagram
    direction LR

    class EnvironBuilder_werkzeug["werkzeug.test.EnvironBuilder"] {
        +get_environ() WSGIEnvironment
        +get_request() Request
    }
    class EnvironBuilder {
        +app: Flask
        +json_dumps(obj) str
    }
    class Client_werkzeug["werkzeug.test.Client"] {
        +open(request) TestResponse
    }
    class FlaskClient {
        +preserve_context: bool
        +environ_base: dict
        +open(...)
        +session_transaction()
        +__enter__/__exit__
    }
    class CliRunner_click["click.testing.CliRunner"] {
        +invoke(cli, args, **kwargs) Result
    }
    class FlaskCliRunner {
        +app: Flask
        +invoke(cli, args, **kwargs) Result
    }

    class Flask {
        +test_client() FlaskClient
        +test_request_context(...) RequestContext
        +test_cli_runner() FlaskCliRunner
        +wsgi_app(environ, start_response)
    }
    class ScriptInfo

    EnvironBuilder --|> EnvironBuilder_werkzeug
    FlaskClient --|> Client_werkzeug
    FlaskCliRunner --|> CliRunner_click

    Flask ..> FlaskClient : factory "test_client()"
    Flask ..> EnvironBuilder : factory "test_request_context()"
    Flask ..> FlaskCliRunner : factory "test_cli_runner()"
    FlaskClient ..> EnvironBuilder : builds every request
    FlaskCliRunner ..> ScriptInfo : injects as click "obj"
    EnvironBuilder ..> Flask : reads config + json provider
```

### 2.1 Request flow through the test client

Every `client.get(...)` / `client.post(...)` call follows this path. Note how the client mediates between the test code and the WSGI application, managing Flask's context stack along the way:

```mermaid
sequenceDiagram
    autonumber
    participant T as Test code
    participant C as FlaskClient
    participant EB as EnvironBuilder
    participant W as Flask.wsgi_app
    participant X as RequestContext

    T->>C: get("/path", json={"a": 1})
    C->>C: merge environ_base (REMOTE_ADDR, User-Agent)
    C->>EB: EnvironBuilder(app, *args, **kwargs)
    EB-->>C: Request (JSON serialized via app.json)
    C->>C: close previously preserved contexts (ExitStack)
    C->>W: super().open(request)
    W->>X: ctx.push() (app + request context)
    W->>W: full_dispatch_request()
    W-->>C: Response
    W->>X: ctx.pop() — deferred if preserve_context
    C-->>T: TestResponse (json_module = app.json)
```

### 2.2 Context preservation mechanism

The defining Flask-specific feature of `FlaskClient` is **context preservation**. Werkzeug pops the request context at the end of every request; Flask defers this when the client is used inside a `with` block so tests can inspect `flask.request`, `flask.g`, and `flask.session` after a call:

```mermaid
flowchart TB
    subgraph with_block["with client:  (__enter__ sets preserve_context = True)"]
        A["client.get('/')"] --> B["wsgi_app stores context via
        environ['werkzeug.debug.preserve_context']
        = client._new_contexts.append"]
        B --> C["Response returned, context NOT popped"]
        C --> D["Test asserts on flask.g / flask.request"]
    end
    D --> E["__exit__: preserve_context = False,
    _context_stack.close() pops all contexts"]
    E --> F["Next request closes stale contexts first
    (no leakage across requests/redirects)"]
```

---

## 3. Core Components

| Component | Kind | Responsibility |
|---|---|---|
| [`EnvironBuilder`](testing-support_test-client.md) | `class` (extends `werkzeug.test.EnvironBuilder`) | Builds WSGI environments using app config defaults (`SERVER_NAME`, `APPLICATION_ROOT`, `PREFERRED_URL_SCHEME`), supports `subdomain` / `url_scheme` shortcuts, and serializes `json=` payloads with the **app's** JSON provider. Also reused internally by `Flask.test_request_context()`. |
| [`FlaskClient`](testing-support_test-client.md) | `class` (extends `werkzeug.test.Client`) | The test browser. Dispatches requests to the app in-process, maintains a configurable `environ_base`, wires up context preservation (`with` blocks, `ExitStack`), provides `session_transaction()` for direct session manipulation, and links responses to `app.json`. |
| [`FlaskCliRunner`](testing-support_cli-runner.md) | `class` (extends `click.testing.CliRunner`) | Runs Click commands bound to `app.cli` without a subprocess, automatically injecting a `ScriptInfo` that resolves to the app under test — enabling `@with_appcontext` commands to run inside tests. |

Detailed behavior of each component is documented in the sub-module pages:

- **[Test Client Infrastructure](testing-support_test-client.md)** — `EnvironBuilder` and `FlaskClient`, including the request-building pipeline, context preservation, and session transactions.
- **[CLI Runner](testing-support_cli-runner.md)** — `FlaskCliRunner` and its integration with the [command-line-interface](command-line-interface.md) module.
- **[Test Suite](testing-support_test-suite.md)** — what `tests/test_testing.py` verifies and the observable contracts it locks in.

---

## 4. Sub-Module Map

Detailed documentation for each part of this module lives in its own file (all docs share one flat directory):

| Sub-module | File | Contents |
|---|---|---|
| Test Client Infrastructure | [testing-support_test-client.md](testing-support_test-client.md) | `EnvironBuilder` (app-aware WSGI environment construction) and `FlaskClient` (request dispatch, context preservation, session transactions). |
| CLI Runner | [testing-support_cli-runner.md](testing-support_cli-runner.md) | `FlaskCliRunner` — in-process invocation of `app.cli` commands with automatic `ScriptInfo` injection. |
| Test Suite | [testing-support_test-suite.md](testing-support_test-suite.md) | `tests/test_testing.py` — the behavioral contracts for everything above (environ defaults, context binding, sessions, JSON, subdomains, CLI). |

---

## 5. Integration with the Rest of the System

The testing-support module is intentionally small because it **orchestrates** facilities owned by other modules rather than re-implementing them:

| Dependency | Module | How it is used here |
|---|---|---|
| `Flask.wsgi_app`, `Flask.full_dispatch_request` | [application-core](application-core.md) | The WSGI entry point the client drives; `wsgi_app` also invokes the `werkzeug.debug.preserve_context` hook the client plants in the environ. |
| `Flask.test_client()`, `test_cli_runner()`, `test_request_context()` | [application-core](application-core.md) | Factory methods on the app that instantiate this module's classes (respecting `test_client_class` / `test_cli_runner_class` overrides). |
| `RequestContext` / `AppContext` push/pop | [contexts](contexts.md) | Context preservation is implemented as deferred push/pop via the client's `ExitStack`; `appcontext_popped` signal is used to assert cleanup. |
| `session_interface.open_session` / `save_session`, `SessionMixin` | [sessions](sessions.md) | `session_transaction()` opens/saves a real session through the app's configured session interface. |
| `ScriptInfo`, `app.cli` | [command-line-interface](command-line-interface.md) | `FlaskCliRunner` passes a `ScriptInfo(create_app=lambda: self.app)` as Click's `obj` so commands can locate the app under test. |
| `app.json` (JSON provider) | [json-serialization](json-serialization.md) | `EnvironBuilder.json_dumps()` and `TestResponse.json_module` delegate to the app's JSON provider so test payloads follow app-level JSON customization. |
| `app`, `client`, `app_ctx`, `req_ctx` fixtures | [test-infrastructure](test-infrastructure.md) | `tests/test_testing.py` is built on the shared pytest fixtures defined in `tests/conftest.py`. |

---

## 6. Typical Usage Patterns

```python
import flask

app = flask.Flask(__name__)

@app.route("/greet", methods=["POST"])
def greet():
    return f"Hello, {flask.request.json['name']}!"

client = app.test_client()          # factory from application-core

# 1. Plain request/response testing (contexts cleaned up automatically)
rv = client.post("/greet", json={"name": "Flask"})
assert rv.get_json()  # response JSON decoded with the app's provider

# 2. Context preservation with a `with` block
with client:
    rv = client.get("/")
    assert flask.request.path == "/"        # request context still active
    assert flask.g is not None              # g accessible after the request

# 3. Direct session manipulation
with client.session_transaction() as session:
    session["user"] = "alice"               # saved back into the cookie on exit

# 4. CLI testing
runner = app.test_cli_runner()
result = runner.invoke(args=["--help"])
assert result.exit_code == 0
```

> **Tip:** custom subclasses can be plugged in via `app.test_client_class` and `app.test_cli_runner_class` without changing any call sites — see the factory docs in [application-core](application-core.md).

---

## 7. Design Notes

1. **Adapter, not reimplementation.** All HTTP-level mechanics (multipart encoding, cookie jars, redirect following, response wrapping) come from Werkzeug's test utilities; Flask only layers app-awareness on top.
2. **Config-driven defaults.** `EnvironBuilder` derives `http_host`, script root, and scheme from `SERVER_NAME`, `APPLICATION_ROOT`, and `PREFERRED_URL_SCHEME`, so tests automatically reflect deployment-like configuration (`test_environ_defaults_from_config`).
3. **App-owned serialization.** Both request bodies (`json=`) and response decoding route through `app.json`, keeping test data consistent with production JSON behavior.
4. **Deliberate context hygiene.** Preserved contexts are popped when the `with` block exits *and* defensively at the start of every `open()` call, preventing context leakage across redirects and successive requests (`test_client_pop_all_preserved`).
