# Command-Line Interface (CLI)

## 1. Overview

The **command-line-interface** module implements the `flask` command — the primary developer tool for discovering, configuring, running, debugging, and inspecting Flask applications from a terminal. It is implemented in [`src/flask/cli.py`](../src/flask/cli.py) and built on top of [Click](https://click.palletsprojects.com/), extended with Flask-specific behaviour.

Its responsibilities are:

| Capability | Components | Description |
|---|---|---|
| **Application discovery & loading** | `ScriptInfo`, `_set_app` | Locates and imports the `Flask` app from `--app`/`FLASK_APP`, factory functions, or `wsgi.py`/`app.py` conventions. Caches the result for the process lifetime. |
| **CLI framework** | `FlaskGroup` | A `click.Group` subclass that merges built-in commands, `flask.commands` plugin entry points, and commands registered on `app.cli` / blueprint CLIs — pushing an app context when app commands run. |
| **Built-in commands** | `run_command`, `shell_command`, `routes_command` | `flask run` (Werkzeug dev server), `flask shell` (REPL in the app context), `flask routes` (route table). |
| **TLS / certificate options** | `CertParamType`, `_validate_key` | Parses `--cert` (file, `adhoc`, or `ssl.SSLContext` import) and pairs it with `--key`. |
| **Environment configuration** | `_env_file_callback`, `_set_debug`, `_path_is_ancestor` | Eager option callbacks that load `.env`/`.flaskenv` files via `load_dotenv()` and propagate `--debug` into `FLASK_DEBUG` *before* the app is imported. |

Everything on this page is described in detail by the sub-module documentation linked in [§5](#5-sub-modules).

## 2. Architecture

### 2.1 Class & component hierarchy

```mermaid
classDiagram
    direction LR
    class click_Group["click.Group"]
    class click_ParamType["click.ParamType"]
    class click_Path["click.Path"]

    class AppGroup {
        +command(with_appcontext=True)
        +group(cls=AppGroup)
    }
    class FlaskGroup {
        +create_app: Callable
        +load_dotenv: bool
        +set_debug_flag: bool
        +make_context()
        +parse_args()
        +get_command(ctx, name)
        +list_commands(ctx)
        -_load_plugin_commands()
    }
    class ScriptInfo {
        +app_import_path
        +create_app
        +set_debug_flag
        +load_dotenv_defaults
        +load_app() Flask
        -_loaded_app
    }
    class CertParamType {
        +convert(value, param, ctx)
    }
    class SeparatedPathType {
        +convert(value, param, ctx)
    }

    click_Group <|-- AppGroup : command() wraps in with_appcontext
    AppGroup <|-- FlaskGroup : merges app + plugin commands
    click_ParamType <|-- CertParamType : --cert option type
    click_Path <|-- SeparatedPathType : --extra-files / --exclude-patterns

    FlaskGroup o-- ScriptInfo : ctx.ensure_object(ScriptInfo)
    FlaskGroup o-- run_command : default command
    FlaskGroup o-- shell_command : default command
    FlaskGroup o-- routes_command : default command
    run_command ..> CertParamType : --cert
    run_command ..> SeparatedPathType : --extra-files / --exclude-patterns
```

Two layers are intentionally distinct:

* **`AppGroup`** — a small mixin that makes `command()` wrap callbacks in [`with_appcontext`](#32-how-app-commands-get-an-app-context). One instance lives on every `Flask` app as `app.cli` (see [application-core](application-core.md)); the same class is also used for custom command groups.
* **`FlaskGroup`** — the top-level `flask` group. It *loads* commands lazily from three sources and tolerates a broken/unfindable app while doing so (help and error messages still work without a loadable app).

### 2.2 End-to-end invocation flow (`flask --app hello:app run`)

```mermaid
flowchart TD
    A["flask --app hello:app run"] --> B["FlaskGroup.parse_args"]
    B --> C["Eager: -e/--env-file → _env_file_callback → load_dotenv()"]
    C --> D["Eager: -A/--app → _set_app → ScriptInfo.app_import_path"]
    D --> E["--debug/--no-debug → _set_debug → sets FLASK_DEBUG env var"]
    E --> F["make_context: sets FLASK_RUN_FROM_CLI=true,\ncreates ScriptInfo as click obj"]
    F --> G["run_command"]
    G --> H["ScriptInfo.load_app() (cached)"]
    H --> H1{"create_app callback?"}
    H1 -- yes --> H2["call create_app()"]
    H1 -- no --> H3{"--app / FLASK_APP given?"}
    H3 -- yes --> H4["prepare_import(path) + locate_app()\n→ find_best_app / find_app_by_string"]
    H3 -- no --> H5["auto-discovery: try wsgi.py, then app.py\nin the current directory"]
    H2 --> I["set_debug_flag: app.debug = FLASK_DEBUG"]
    H4 --> I
    H5 --> I
    I --> J["show_server_banner()"]
    J --> K["werkzeug.serving.run_simple()\n(reloader, debugger, threads, TLS)"]
    H -. "NoAppException" .-> X["red error on stderr, no traceback"]
```

Key ordering constraints enforced by the code:

* `-e/--env-file` is processed **before** `-A/--app` and `--debug` so environment variables loaded from files can influence app selection and debug mode. All three are *eager* Click options driven by callbacks, not by a group callback, so user-defined group callbacks don't lose this behaviour.
* `--app` is processed before `--help` so that `flask --help` can already list commands contributed by the app. `FlaskGroup.parse_args` re-applies the eager options manually when `no_args_is_help` would otherwise bypass them.
* `FLASK_RUN_FROM_CLI=true` makes `Flask.run()` a safe no-op (see [application-core](application-core.md)) so an unguarded `app.run()` in the app module cannot start a second server while the CLI command runs.

### 2.3 Command resolution & the app context

```mermaid
flowchart LR
    subgraph FlaskGroup["FlaskGroup.get_command / list_commands"]
        P["1. plugin commands\nentry_points(group='flask.commands')"] --> B["2. built-in + group commands\n(run, shell, routes)"]
        B --> A["3. app commands\nScriptInfo.load_app().cli"]
    end
    A --> CTX["push app.app_context()\nunless current_app already active"]
    CTX --> CMD["command callback runs with\ncurrent_app, g, config available"]
```

* Built-in and plugin commands are listed even when the app cannot be loaded; app-command discovery failures are reported as a short red `Error: ...` line (`NoAppException`) or a full traceback for other exceptions.
* Because `FlaskGroup` pushes the app context itself, commands registered on `app.cli` (via `@app.cli.command()`) do **not** need `@with_appcontext`. The decorator remains necessary for standalone Click commands run under a `FlaskGroup`, and `AppGroup.command(with_appcontext=False)` opts out.

## 3. Key behaviours

> Each behaviour below is documented in depth in its sub-module page: [application discovery](command-line-interface_app-discovery.md) · [CLI framework](command-line-interface_cli-framework.md) · [built-in commands](command-line-interface_built-in-commands.md) · [environment configuration](command-line-interface_environment-config.md) · [test suite](command-line-interface_test-suite.md).

### 3.1 Application discovery rules

`ScriptInfo.load_app()` resolves the app with this precedence:

1. An explicit `create_app` callable passed to `FlaskGroup(create_app=...)` (used heavily by tests and `FlaskCliRunner`).
2. `--app`/`FLASK_APP`, in the form `module` or `module:name`, where `name` may be an attribute or a call expression with literal arguments (e.g. `factory:create_app("dev")`), parsed safely with `ast`.
3. Auto-discovery: import `wsgi.py`, then `app.py`, from the current directory.
4. Otherwise raise `NoAppException` with remediation hints.

Within a module, `find_best_app` prefers attributes named `app`/`application`, then the *only* `Flask` instance, then `create_app`/`make_app` factories (distinguishing "called with wrong args" from a factory that raised `TypeError` internally via `_called_with_wrong_args`). File paths given to `--app` are converted to importable module names by `prepare_import`, which also prepends the package root to `sys.path`.

### 3.2 How app commands get an app context

`with_appcontext` checks the `current_app` proxy (see [contexts](contexts.md)); if no app context is active it loads the app through the current `ScriptInfo` and enters `app.app_context()` as a Click context resource. This is why `flask shell` and `flask routes` can use `current_app` directly, and why app/broadcast CLI commands share the *same* app instance that the `FlaskGroup` loaded (cached on `ScriptInfo`).

### 3.3 Environment variable interface

| Variable | Set by | Consumed by | Meaning |
|---|---|---|---|
| `FLASK_APP` | user | `ScriptInfo.load_app` | Default value for `--app` (auto_envvar_prefix `FLASK`). |
| `FLASK_DEBUG` | `_set_debug` (`1`/`0`) | `helpers.get_debug_flag()` → `app.debug` | Debug mode; survives into factory functions and the reloader child process. |
| `FLASK_RUN_FROM_CLI` | `FlaskGroup.make_context` | `Flask.run()` | Disables unguarded `app.run()` calls during CLI execution. |
| `FLASK_SKIP_DOTENV` | user | `helpers.get_load_dotenv()` | Skips loading `.env`/`.flaskenv`. |
| `.env` / `.flaskenv` files | `load_dotenv()` | `os.environ` | `.flaskenv` (tool defaults) is loaded first, then `.env` (project secrets); explicit `--env-file` wins over both; existing environment values are never overwritten. |

### 3.4 Development server

`flask run` delegates to Werkzeug's `run_simple` with: host/port, threaded execution (default on), reloader and debugger (defaulting to the debug flag), extra watch files, exclude patterns, and an `ssl_context` produced by `CertParamType` (path pair, `'adhoc'` — requires `cryptography` — or an imported `ssl.SSLContext`). If the app fails to load *inside* the reloader, the error is printed immediately but deferred into a WSGI callable that re-raises, so the interactive debugger can present it.

## 4. Integration with the rest of Flask

```mermaid
flowchart LR
    CLI["command-line-interface\n(src/flask/cli.py)"]
    APP["application-core\nFlask.cli = AppGroup,\nFlask.run() no-op guard"]
    BP["blueprints\nBlueprint.cli groups"]
    CTX["contexts\nAppContext / current_app"]
    CFG["configuration / helpers\nFLASK_DEBUG, dotenv flags"]
    TS["testing-support\nFlaskCliRunner"]
    WZ["Werkzeug\nrun_simple, reloader"]
    EP["Other packages\nflask.commands entry points"]

    APP -- "registers @app.cli.command()" --> CLI
    BP -- "registers blueprint CLI groups" --> CLI
    EP -- "contributes commands" --> CLI
    CLI -- "pushes app context" --> CTX
    CLI -- "reads debug/dotenv flags" --> CFG
    CLI -- "serves via run_simple" --> WZ
    TS -- "invokes commands in tests" --> CLI
```

* **application-core** ([application-core](application-core.md)): every `Flask` instance owns an `AppGroup` at `app.cli`; `Flask.run()` consults `FLASK_RUN_FROM_CLI` and calls back into this module (`cli.load_dotenv`, `cli.show_server_banner`) when run directly.
* **blueprints** ([blueprints](blueprints.md)): `Blueprint`s attach their own CLI group (`cli_group` parameter, `None` merges into the app group); `FlaskGroup` exposes them via `app.cli`.
* **contexts** ([contexts](contexts.md)): `with_appcontext` provides the app context that CLI commands rely on; the loaded app is guaranteed to be the object behind `current_app`.
* **configuration** ([configuration](configuration.md)) & **helpers**: `FLASK_DEBUG`/`FLASK_SKIP_DOTENV` semantics are owned by `flask.helpers`; the CLI is the primary writer of `FLASK_DEBUG`.
* **testing-support** ([testing-support](testing-support.md)): `FlaskCliRunner` (returned by `app.test_cli_runner()`) invokes commands against this module with a supplied app, forming the basis of the module's own test suite.
* **test-infrastructure** ([test-infrastructure](test-infrastructure.md)): shared fixtures (`test_apps`, `app`, `app_ctx`) used by `tests/test_cli.py`.

## 5. Sub-modules

| Sub-module | Contents | Documentation |
|---|---|---|
| Application discovery & loading | `ScriptInfo`, `_set_app`, `find_best_app`, `find_app_by_string`, `prepare_import`, `locate_app`, `NoAppException` | [command-line-interface_app-discovery.md](command-line-interface_app-discovery.md) |
| CLI framework & command groups | `FlaskGroup`, `AppGroup`, `with_appcontext`, `pass_script_info`, `version_option` | [command-line-interface_cli-framework.md](command-line-interface_cli-framework.md) |
| Built-in commands & TLS options | `run_command`, `shell_command`, `routes_command`, `CertParamType`, `_validate_key`, `SeparatedPathType`, `show_server_banner` | [command-line-interface_built-in-commands.md](command-line-interface_built-in-commands.md) |
| Environment configuration | `_env_file_callback`, `_set_debug`, `_path_is_ancestor`, `load_dotenv`, dotenv precedence | [command-line-interface_environment-config.md](command-line-interface_environment-config.md) |
| Test suite | `tests/test_cli.py`, fixture apps (`tests/test_apps/cliapp`, `tests/test_apps/helloworld`) | [command-line-interface_test-suite.md](command-line-interface_test-suite.md) |

## 6. Extension points

* **Custom commands:** `@app.cli.command()` (app context provided automatically) or `click.Group(cls=AppGroup)` for reusable groups; blueprint commands via `@bp.cli.command()` (see [blueprints](blueprints.md)).
* **Plugins:** distribute commands as `flask.commands` entry points — loaded once per process, without importing the app.
* **Custom scripts:** instantiate `FlaskGroup` directly (optionally with `create_app`, `load_dotenv`, `set_debug_flag`) to embed the full Flask CLI into another Click application, or subclass it — see the `custom-scripts` pattern referenced in the `FlaskGroup` docstring.
* **Programmatic use:** `ScriptInfo(create_app=...)` + `with_appcontext` is the supported way to run CLI-adjacent code with a specific app without environment-variable discovery.
