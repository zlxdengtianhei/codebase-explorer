# JSON Serialization Provider (`flask.json.provider`)

## 1. Introduction

The `json-serialization_provider` module implements **Flask's pluggable JSON strategy**. Introduced in Flask 2.2, it decouples *what* JSON operations an application offers (serialize, deserialize, build JSON responses) from *how* those operations are performed (which JSON library and which type-conversion rules are used).

The module lives in `src/flask/json/provider.py` and consists of three components:

| Component | Kind | Role |
|---|---|---|
| `JSONProvider` | Abstract base class | Defines the standard set of JSON operations an app exposes via `app.json`; holds a `weakref` to the application |
| `DefaultJSONProvider` | Concrete implementation | Implements the operations using Python's built-in `json` library, with Flask-specific type defaults (`datetime`, `UUID`, `Decimal`, dataclasses, `Markup`) |
| `_default` | Module-level function | The fallback serializer applied by `DefaultJSONProvider` to objects that `json.dumps` cannot handle natively |

Everything in Flask that touches JSON — `flask.jsonify()`, `flask.json.dumps()/loads()`, dict/list view returns, `request.get_json()`, and the Jinja `|tojson` filter — ultimately routes through an instance of this provider attached to the application as `app.json`. Because the provider is a replaceable object, an application can swap the entire JSON behavior (e.g. use `orjson` or `ujson`) by assigning a single attribute.

This module is the "provider" half of the broader JSON subsystem; for the tag-based lossless serializer used by session cookies, see [json-serialization_tag](json-serialization_tag.md). For the public `flask.json.*` API and `jsonify`, see the parent [json-serialization](json-serialization.md) documentation.

---

## 2. Core Components

### 2.1 `JSONProvider` (abstract base)

```python
class JSONProvider:
    def __init__(self, app: App) -> None:
        self._app: App = weakref.proxy(app)
```

**Key design points:**

- **Application back-reference via weakref.** The constructor stores the app as a `weakref.proxy` on the `_app` attribute. This avoids a reference cycle between the app and its provider and lets provider code access app state (e.g. `self._app.debug`, `self._app.response_class`) without keeping the app alive.
- **Extensibility contract.** A provider for a third-party JSON library only needs to implement `dumps()` and `loads()`; every other method has a usable default implementation.
- **Operations defined by the interface:**

| Method | Purpose | Default behavior |
|---|---|---|
| `dumps(obj, **kwargs)` | Serialize to a JSON `str` | *Abstract* — raises `NotImplementedError` |
| `loads(s, **kwargs)` | Deserialize from `str`/UTF-8 `bytes` | *Abstract* — raises `NotImplementedError` |
| `dump(obj, fp, **kwargs)` | Serialize and write to a text file | `fp.write(self.dumps(obj, **kwargs))` |
| `load(fp, **kwargs)` | Deserialize from a file | `self.loads(fp.read(), **kwargs)` |
| `response(*args, **kwargs)` | Serialize and wrap in an `application/json` `Response` | Uses `_prepare_response_obj()` + `_app.response_class` |
| `_prepare_response_obj(args, kwargs)` | Normalize `jsonify`-style arguments (private) | See argument rules below |

**Argument normalization rules** (`_prepare_response_obj`, shared by `jsonify` and `make_response`):

- Both positional args *and* keyword args → `TypeError` ("takes either args or kwargs, not both").
- Neither → `None` is serialized.
- Exactly one positional arg → that value itself.
- Multiple positional args → the `args` tuple is serialized as a JSON array.
- Keyword args only → the `kwargs` dict is serialized as a JSON object.

### 2.2 `DefaultJSONProvider`

The concrete provider built on the standard library's `json` module. It is the default value of `App.json_provider_class`, so every Flask application uses it unless it is replaced.

**Configurable class/instance attributes:**

| Attribute | Default | Effect |
|---|---|---|
| `default` | `staticmethod(_default)` | Fallback converter for unknown types; passed to `json.dumps(default=...)` |
| `ensure_ascii` | `True` | Escape non-ASCII characters (better client compatibility; disable for smaller payloads) |
| `sort_keys` | `True` | Sort dict keys alphabetically (deterministic output for caching; disable for performance) |
| `compact` | `None` | Controls response formatting: `True` or `None` out of debug mode → compact separators `(,, :)`; `False` or `None` in debug mode → `indent=2` pretty printing |
| `mimetype` | `"application/json"` | Mimetype assigned by `response()`; may be customized (e.g. `"application/vnd.api+json"`) |

**Behavior overrides:**

- `dumps()` sets parameter defaults from `default`, `ensure_ascii`, and `sort_keys` before delegating to `json.dumps(obj, **kwargs)`. Callers can still override any parameter per-call via keyword arguments (`kwargs.setdefault` semantics).
- `loads()` delegates directly to `json.loads(s, **kwargs)`.
- `response()` adds a trailing newline (`"\n"`) to the serialized body and chooses between pretty-printed and compact output based on the `compact` attribute and `self._app.debug`.

### 2.3 `_default` (fallback type converter)

Applied by `json.dumps` to any object it does not know how to serialize. The conversion order is:

```mermaid
flowchart TD
    A["Unknown object o"] --> B{"isinstance(o, date)<br/>(datetime is a date)"}
    B -- "yes" --> C["http_date(o)<br/>RFC 822 / HTTP date string"]
    B -- "no" --> D{"decimal.Decimal<br/>or uuid.UUID?"}
    D -- "yes" --> E["str(o)"]
    D -- "no" --> F{"dataclasses.is_dataclass(o)?"}
    F -- "yes" --> G["dataclasses.asdict(o)<br/>(recursed by json.dumps)"]
    F -- "no" --> H{"has __html__?<br/>(e.g. Markup)"}
    H -- "yes" --> I["str(o.__html__())"]
    H -- "no" --> J["raise TypeError:<br/>Object of type ... is not JSON serializable"]
```

Notes:

- `datetime.datetime` and `datetime.date` both serialize to HTTP-date (RFC 822) strings via Werkzeug's `http_date`. Timezone-aware datetimes are converted to GMT.
- `Decimal` is intentionally serialized as a string to avoid precision loss (not as a JSON number).
- `Markup` and any object exposing `__html__` are converted through their HTML-safe representation.
- This function is also used as the fallback `default` by `flask.json.dumps()/dump()` when they are called **outside** an active application context (see [§4.2](#42-the-flaskjson-public-api-delegation-layer)).

---

## 3. Architecture

### 3.1 Component class diagram

```mermaid
classDiagram
    direction LR

    class JSONProvider {
        <<abstract>>
        +App _app  (weakref.proxy)
        +__init__(app)
        +dumps(obj, **kwargs)* str
        +loads(s, **kwargs)* Any
        +dump(obj, fp, **kwargs) void
        +load(fp, **kwargs) Any
        +response(*args, **kwargs) Response
        -_prepare_response_obj(args, kwargs) Any
    }

    class DefaultJSONProvider {
        +default = staticmethod(_default)
        +ensure_ascii = True
        +sort_keys = True
        +compact = None
        +mimetype = "application/json"
        +dumps(obj, **kwargs) str
        +loads(s, **kwargs) Any
        +response(*args, **kwargs) Response
    }

    class DefaultFunction {
        <<module function>>
        +_default(o) Any
    }

    class App {
        +type json_provider_class = DefaultJSONProvider
        +JSONProvider json
    }

    JSONProvider <|-- DefaultJSONProvider : inherits
    DefaultJSONProvider ..> DefaultFunction : json.dumps(default=...)
    App o-- JSONProvider : app.json = json_provider_class(app)
    JSONProvider ..> App : weakref back-reference (_app)
```

### 3.2 System context — who uses the provider

```mermaid
flowchart LR
    subgraph PublicAPI["flask.json (public API layer)"]
        jsonify["jsonify()"]
        dumps["dumps() / dump()"]
        loads["loads() / load()"]
    end

    subgraph FlaskCore["Flask application core"]
        APP["Flask / App<br/>json_provider_class,<br/>app.json instance"]
        MR["Flask.make_response()<br/>(dict / list returns)"]
        JINJA["create_jinja_environment()<br/>json.dumps_function policy"]
        REQ["Request.get_json()<br/>(via json_module)"]
    end

    PROVIDER["app.json<br/>(JSONProvider /<br/>DefaultJSONProvider)"]
    RC["app.response_class<br/>(flask.Response)"]
    TAG["TaggedJSONSerializer<br/>(sessions)"]
    CTX["current_app proxy<br/>(app context)"]

    CTX --> APP
    jsonify -->|"app.json.response()"| PROVIDER
    dumps -->|"app.json.dumps()"| PROVIDER
    loads -->|"app.json.loads()"| PROVIDER
    MR -->|"self.json.response(rv)"| PROVIDER
    JINJA -->|"policies[json.dumps_function]<br/>= self.json.dumps"| PROVIDER
    REQ -->|"flask.json.loads()"| PROVIDER
    TAG -->|"flask.json.dumps/loads"| PROVIDER
    PROVIDER -->|"creates JSON Response"| RC
    APP -->|"instantiates"| PROVIDER
```

Dependency summary:

- **Depends on (upstream):** Werkzeug's `http_date` (date formatting) and the `Response`/`App` types (imported only under `TYPE_CHECKING` to avoid circular imports).
- **Depended on (downstream):** the app object wires one provider instance per application; `flask.json` delegates to it through `current_app`; `make_response` uses it for `dict`/`list` view returns; the Jinja environment receives its `dumps` as the `tojson` policy; the session tag serializer (see [json-serialization_tag](json-serialization_tag.md)) routes its compact dumps/loads through the same provider.
- **Context requirement:** dispatching through `current_app` requires an active application context. See [contexts_app_context](contexts_app_context.md) for how the context lifecycle is managed.

---

## 4. Integration with Flask

### 4.1 Wiring at application startup

The provider is instantiated exactly once per application, in `App.__init__` (`src/flask/sansio/app.py`):

```python
json_provider_class: type[JSONProvider] = DefaultJSONProvider  # class attribute

...
self.json: JSONProvider = self.json_provider_class(self)       # instance attribute
```

There are two equivalent customization points:

1. **Before instantiation** — set `json_provider_class` on a `Flask` subclass.
2. **After instantiation** — assign an instance directly: `app.json = CustomProvider(app)`.

### 4.2 The `flask.json` public API (delegation layer)

The `flask.json` package (`src/flask/json/__init__.py`) is a thin dispatcher: when an application context is active it forwards to the provider; otherwise it falls back to the standard library using `_default` directly:

```python
def dumps(obj, **kwargs):
    if current_app:
        return current_app.json.dumps(obj, **kwargs)   # provider path
    kwargs.setdefault("default", _default)             # no-app fallback
    return _json.dumps(obj, **kwargs)
```

`dump`, `loads`, and `load` follow the same two-path pattern; `jsonify()` requires an app context and always uses `current_app.json.response(...)`.

### 4.3 Request/response integration

- **View return values.** `Flask.make_response()` converts a `dict` or `list` returned by a view via `self.json.response(rv)` — the same code path as `jsonify`.
- **JSON request bodies.** `flask.Request` and `flask.Response` hold `json_module = flask.json`, so `request.get_json()` (and `response.json` in tests) parse through `flask.json.loads` → `app.json.loads`. Malformed bodies raise `BadRequest`; in debug mode the underlying decode error message ("Failed to decode JSON object") is preserved (see `Request.on_json_loading_failed`).

### 4.4 Jinja `|tojson` filter

`Flask.create_jinja_environment()` registers the provider's serializer as Jinja's JSON policy:

```python
rv.policies["json.dumps_function"] = self.json.dumps
```

The built-in Jinja `|tojson` filter therefore produces output consistent with `app.json.dumps` (HTML-unsafe characters escaped, datetimes as HTTP dates), keeping templates and API responses in sync. Template-side details are covered in [templating_rendering_context](templating_rendering_context.md).

---

## 5. Data Flows

### 5.1 Serialization → JSON response (`jsonify` / dict-returning views)

```mermaid
sequenceDiagram
    autonumber
    participant V as View function
    participant FJ as flask.json.jsonify<br/>(or Flask.make_response)
    participant P as app.json<br/>(DefaultJSONProvider)
    participant STDLIB as json.dumps + _default
    participant RC as app.response_class

    V->>FJ: return dict / jsonify(data)
    FJ->>P: response(*args, **kwargs)
    P->>P: _prepare_response_obj(args, kwargs)<br/>single value | list(args) | kwargs dict | None
    P->>P: choose formatting:<br/>debug or compact=False → indent=2<br/>otherwise → separators=(",", ":")
    P->>STDLIB: dumps(obj, default=_default,<br/>ensure_ascii=True, sort_keys=True)
    STDLIB-->>P: JSON string<br/>(dates→HTTP date, UUID/Decimal→str,<br/>dataclass→dict, Markup→str)
    P->>RC: response_class(json + "\n", mimetype="application/json")
    RC-->>V: Response (application/json)
```

### 5.2 Deserialization of a JSON request body

```mermaid
sequenceDiagram
    autonumber
    participant V as View function
    participant R as flask.request
    participant FJ as flask.json.loads
    participant P as app.json.loads
    participant WZ as Werkzeug BadRequest

    V->>R: request.get_json()
    R->>FJ: loads(raw body)
    FJ->>P: current_app.json.loads(s)
    P->>P: json.loads(s)
    alt decoding succeeds
        P-->>R: Python object (dict/list/...)
        R-->>V: parsed data
    else decoding fails (ValueError)
        P-->>R: ValueError
        R->>WZ: on_json_loading_failed(e)
        Note over WZ: debug mode → re-raise with detail<br/>("Failed to decode JSON object")<br/>otherwise → generic 400 BadRequest
    end
```

The debug-vs-production distinction in step 9 is what `test_bad_request_debug_message` verifies: the detailed message only appears in the response body when `DEBUG` is enabled.

### 5.3 `|tojson` filter flow

```mermaid
flowchart LR
    T["Template: {{ data|tojson }}"] --> E["Jinja Environment<br/>policies['json.dumps_function']"]
    E --> D["app.json.dumps (provider)"]
    D --> O["Escaped, sort_keys output<br/>safe to embed in script tags"]
```

---

## 6. Extension Guide

### 6.1 Adjusting serialization of custom types

Subclass `DefaultJSONProvider` and replace (or wrap) the `default` converter. This is the pattern exercised by `test_json_customization`, which also customizes deserialization via an `object_hook`:

```python
from flask.json.provider import DefaultJSONProvider

class X:
    def __init__(self, val):
        self.val = val

def default(o):
    if isinstance(o, X):
        return f"<{o.val}>"
    return DefaultJSONProvider.default(o)   # keep Flask's built-ins

class CustomProvider(DefaultJSONProvider):
    def object_hook(self, obj):             # applied on loads()
        if len(obj) == 1 and "_foo" in obj:
            return X(obj["_foo"])
        return obj

    def loads(self, s, **kwargs):
        kwargs.setdefault("object_hook", self.object_hook)
        return super().loads(s, **kwargs)

app.json = CustomProvider(app)
app.json.default = default
```

### 6.2 Switching JSON libraries

A provider for another library only has to implement `dumps` and `loads`; `dump`, `load`, and `response` are inherited:

```python
from flask.json.provider import JSONProvider
import orjson

class OrjsonProvider(JSONProvider):
    def dumps(self, obj, **kwargs):
        return orjson.dumps(obj, default=...).decode()

    def loads(self, s, **kwargs):
        return orjson.loads(s)
```

```python
# Option A: per-instance
app.json = OrjsonProvider(app)

# Option B: subclass default
class MyApp(Flask):
    json_provider_class = OrjsonProvider
```

### 6.3 Tuning output for an API

Because attributes are plain class/instance attributes, minor tweaks need no subclassing:

```python
app.json.ensure_ascii = False        # emit raw UTF-8 (smaller payloads)
app.json.sort_keys = False           # preserve insertion order, faster
app.json.compact = False             # always pretty-print responses
app.json.mimetype = "application/vnd.api+json"
```

> **Tip:** `sort_keys=True` (default) yields deterministic output, which helps HTTP caching and snapshot tests; `ensure_ascii=True` (default) maximizes client compatibility. Disable them deliberately, e.g. for performance-sensitive payloads.

---

## 7. Testing

The module's behavior is verified in `tests/test_json.py`. The tests assigned to this module:

| Test | Aspect covered |
|---|---|
| `test_jsonify_dicts` | `jsonify(dict)` and `jsonify(**kwargs)` produce equivalent `application/json` responses through `app.json.response` |
| `test_jsonify_aware_datetimes` | Timezone-aware `datetime` values are converted to GMT and rendered as RFC 822 strings by `_default` |
| `test_json_customization` | Subclassing `DefaultJSONProvider` with a custom `default` converter and `loads`/`object_hook` hook, assigned via `app.json = CustomProvider(app)` |
| `test_tojson_filter` | Jinja's `|tojson` uses the provider (`json.dumps_function` policy): HTML-unsafe output escaped, datetimes as HTTP dates |
| `test_json_key_sorting` | `sort_keys=True` sorts keys as strings (alphabetical `"0", "1", "10", ...` order) in pretty-printed debug output |
| `test_bad_request_debug_message` | Malformed JSON bodies return 400; the "Failed to decode JSON object" detail appears only when `DEBUG` is enabled |

Related tests in the same file (owned by the parent [json-serialization](json-serialization.md) module) exercise basic types, arrays, UUIDs, `Decimal`, `ensure_ascii`, file dump/load, custom mimetypes, and the `__html__` protocol. The session-side tag serializer is covered separately in [json-serialization_tag](json-serialization_tag.md).

---

## 8. Related Documentation

- [json-serialization](json-serialization.md) — parent module: the `flask.json` public API, `jsonify`, and subsystem overview
- [json-serialization_tag](json-serialization_tag.md) — sibling module: `TaggedJSONSerializer` and `JSONTag` classes for lossless serialization (used by sessions)
- [application-core_flask-app](application-core_flask-app.md) — `Flask` class, `make_response`, and `create_jinja_environment` wiring
- [application-core_sansio-foundation](application-core_sansio-foundation.md) — sansio `App` base: `json_provider_class` / `app.json` initialization
- [contexts_app_context](contexts_app_context.md) — application context required by the `current_app` delegation layer
- [templating_rendering_context](templating_rendering_context.md) — Jinja environment and template rendering that consume the `tojson` policy
- [testing-support](testing-support.md) — test client helpers (`test_client`) used by the JSON tests for request/response round-trips
