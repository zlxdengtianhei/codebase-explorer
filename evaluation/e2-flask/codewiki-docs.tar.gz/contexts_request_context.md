# contexts_request_context

## Overview

The `contexts_request_context` module implements Flask's **request context** — the runtime binding between a WSGI request and the code that handles it. Its core is the `RequestContext` class in [`src/flask/ctx.py`](../src/flask/ctx.py), which:

- Wraps a WSGI environment in a Flask `Request` object and a URL map adapter,
- Ensures an `AppContext` is active for the owning application,
- Opens (or creates a null) session for the request,
- Performs URL matching and records the result (or the routing exception) on the request object,
- And, on pop, runs all `teardown_request` callbacks before unbinding everything.

It also exposes two public helpers that operate on the *current* request context:

| Helper | Purpose |
|---|---|
| `after_this_request(f)` | Register a function to run on the response object after the current request completes (before regular `after_request` handlers). |
| `copy_current_request_context(f)` | Decorator that copies the active request context so a function can be executed in a greenlet (or another task) while still accessing `flask.request` and `flask.session`. |

### Position in the module tree

```
Core_Application_Engine___Modular_Composition
├── application-core
│   └── application-core_flask-app        ← Flask.wsgi_app / dispatch pipeline (consumer of this module)
├── contexts
│   ├── contexts_app_context              ← sibling: AppContext, _AppCtxGlobals, has_app_context
│   └── contexts_request_context          ← THIS MODULE
│       ├── src/flask/ctx.py: RequestContext, after_this_request, copy_current_request_context
│       └── tests/test_reqctx.py:         ← context lifecycle, session, teardown, greenlet tests
└── blueprints
```

The request context is the *innermost* of Flask's two context layers: pushing a `RequestContext` guarantees an `AppContext` is also active (see [contexts_app_context](contexts_app_context.md)).

---

## Core Concepts: Context Variables and Proxies

Flask's thread-safe, async-safe "magic" globals are built on two mechanisms (see `src/flask/globals.py`):

1. **`contextvars.ContextVar`** — the true storage for the active contexts:
   - `_cv_request: ContextVar[RequestContext]`
   - `_cv_app: ContextVar[AppContext]`
2. **`werkzeug.local.LocalProxy`** — user-facing objects that resolve lazily against those context vars:

| Proxy | Resolves to | Unbound behavior |
|---|---|---|
| `request_ctx` | the active `RequestContext` | raises `RuntimeError` |
| `request` | `request_ctx.request` | raises `RuntimeError`; falsy when unbound |
| `session` | `request_ctx.session` | raises `RuntimeError` |
| `current_app` / `g` / `app_ctx` | `app_ctx.app` / `app_ctx.g` / the app context | see [contexts_app_context](contexts_app_context.md) |

`RequestContext.push()` performs `_cv_request.set(self)` and records the returned token; `pop()` resets it. This is why `request` and `session` "just work" anywhere below a pushed context, and why a `with` block (or manual `push()`/`pop()`) is required to use them.

---

## Architecture

```mermaid
classDiagram
    direction TB

    class Flask {
        <<application>>
        +request_context(environ) RequestContext
        +test_request_context(args, kwargs) RequestContext
        +wsgi_app(environ, start_response)
        +do_teardown_request(exc)
        +process_response(response) Response
        +session_interface SessionInterface
        +request_class type
    }

    class RequestContext {
        <<per-request context>>
        +app Flask
        +request Request
        +url_adapter MapAdapter
        +session SessionMixin
        +flashes list
        -_after_request_functions list
        -_cv_tokens list
        +push() void
        +pop(exc) void
        +match_request() void
        +copy() RequestContext
    }

    class AppContext {
        <<per-app-execution context>>
        +app Flask
        +url_adapter MapAdapter
        +g _AppCtxGlobals
        +push() void
        +pop(exc) void
    }

    class Request {
        <<werkzeug subclass>>
        +environ dict
        +url_rule Rule
        +view_args dict
        +routing_exception HTTPException
    }

    class SessionInterface {
        +open_session(app, request) SessionMixin
        +make_null_session(app) NullSession
        +save_session(app, session, response)
    }

    class globals {
        <<src/flask/globals.py>>
        _cv_request ContextVar
        _cv_app ContextVar
        request_ctx LocalProxy
        request LocalProxy
        session LocalProxy
        current_app LocalProxy
        g LocalProxy
    }

    Flask --> RequestContext : creates and pushes in wsgi_app
    Flask --> AppContext : app_context factory
    Flask --> SessionInterface : default SecureCookieSessionInterface
    RequestContext *-- Request : owns
    RequestContext --> AppContext : pushes one if none active
    RequestContext --> SessionInterface : open_session / make_null_session
    RequestContext ..> globals : binds itself via _cv_request
    AppContext ..> globals : binds itself via _cv_app
    globals ..> Flask : current_app
```

**Key relationships**

- `Flask` is the factory: `Flask.request_context(environ)` / `Flask.test_request_context(...)` build `RequestContext` instances; application code should never construct one directly.
- `RequestContext` *composes* an `AppContext`: on `push()`, if no app context for the same app is active, it creates and pushes one via `Flask.app_context()` and remembers it in `_cv_tokens` so it can pop it later.
- The `SessionInterface` (see [sessions](sessions.md)) is consulted during `push()`, not during routing — deliberately, so custom URL converters and interfaces can use `flask.request`.

---

## Component Reference

### `RequestContext`

Created by `Flask.request_context()` / `Flask.test_request_context()`; the canonical usage is as a context manager:

```python
with app.test_request_context("/?name=World"):
    flask.request.args["name"]      # bound
# unbound here — proxy raises RuntimeError
```

#### Construction

```python
RequestContext(app, environ, request=None, session=None)
```

| State | Initialized with |
|---|---|
| `app` | The owning `Flask` application. |
| `request` | `app.request_class(environ)` if not supplied; `request.json_module` is set to `app.json`. A pre-built request may be injected (used by `copy()` and the test client). |
| `url_adapter` | Result of `app.create_url_adapter(request)`. If that raises an `HTTPException` (e.g. untrusted/invalid `Host`), **nothing is raised here** — the exception is stored as `request.routing_exception` and surfaces later during dispatch (see [URL Matching](#url-matching-and-routing-exceptions)). |
| `session` | Caller-supplied session or `None`; only opened on first `push()`. |
| `flashes` | `None`; caches flashed messages for `get_flashed_messages` (see [helpers](helpers.md)). |
| `_after_request_functions` | Empty list; target of `after_this_request()`. |
| `_cv_tokens` | Empty list of `(token, AppContext or None)` tuples; supports nested push/pop. |

#### `push()` — binding the context

```mermaid
flowchart TD
    A["RequestContext.push()"] --> B{"App context active<br>for *this* app?"}
    B -- "no / different app" --> C["app.app_context().push()<br>(runs appcontext_pushed signal)"]
    B -- "yes" --> D["reuse active AppContext"]
    C --> E["_cv_request.set(self)<br>store (token, app_ctx) in _cv_tokens"]
    D --> E
    E --> F{"session is None?<br>(first push only)"}
    F -- "yes" --> G["session_interface.open_session(app, request)"]
    G --> H{"session returned?"}
    H -- "no" --> I["make_null_session(app)<br>(e.g. missing SECRET_KEY)"]
    H -- "yes" --> J["use opened session"]
    F -- "no (re-push)" --> J
    I --> K{"url_adapter available?"}
    J --> K
    K -- "yes" --> L["match_request():<br>set url_rule / view_args<br>or store routing_exception"]
    K -- "no" --> M["skip matching<br>(Host validation already failed)"]
    L --> N["context active:<br>request / session / request_ctx proxies resolve"]
    M --> N
```

Design decisions encoded here:

- **Nested pushes are cheap and safe.** Each `push()` appends a token to `_cv_tokens`. Re-pushing the same context (as `stream_with_context` and the preserved-context debug/test paths do) does *not* reopen the session — this prevents a stale/duplicate session object.
- **Session opens before routing.** `match_request()` runs *after* the session is available so custom URL converters may read `flask.session` (verified by `test_session_dynamic_cookie_name`).
- **Routing errors are deferred.** A bad environment (e.g. a non-printable `HTTP_HOST` byte) does not fail in the constructor; the stored `routing_exception` becomes a 400 during `full_dispatch_request`.

#### `pop()` — unbinding and teardown

```mermaid
flowchart TD
    A["pop(exc)"] --> B{"last push?<br>len(_cv_tokens) == 1"}
    B -- "yes" --> C["exc = sys.exc_info()[1] if sentinel<br>do_teardown_request(exc)<br>request.close()"]
    B -- "no (nested push)" --> F
    C --> F["token, app_ctx = _cv_tokens.pop()<br>_cv_request.reset(token)"]
    F --> G{"last push?"}
    G -- "yes" --> H["environ['werkzeug.request'] = None<br>(break reference cycle,<br>no GC dependency)"]
    G -- "no" --> J
    H --> J{"was the AppContext<br>created by this push()?"}
    J -- "yes" --> K["app_ctx.pop(exc)<br>(app teardown, appcontext_popped)"]
    J -- "no" --> L["assert popped context is self<br>else AssertionError"]
    K --> L
```

Important behaviors:

- **Teardown runs exactly once**, on the outermost pop. The exception passed to `teardown_request` handlers is the *in-flight* exception from `sys.exc_info()` — but only if the context is being popped while that exception is unhandled. If the exception was already handled (e.g. caught in a `try/except` inside the `with` block) or is unrelated (a previous exception in the interpreter), handlers receive `None` (verified by `test_teardown_on_pop`, `test_teardown_with_previous_exception`, `test_teardown_with_handled_exception`).
- **`Flask.do_teardown_request`** (blueprint + app teardown funcs, then the `request_tearing_down` signal) is invoked here; the corresponding app-level teardown is invoked transitively through `AppContext.pop` — see [contexts_app_context](contexts_app_context.md).
- **Reference-cycle hygiene:** setting `environ["werkzeug.request"] = None` allows the environ/request pair to be reclaimed deterministically without relying on the garbage collector (`test_app_freed_on_zero_refcount` in the application-core module depends on this).
- **Ordering guarantee:** the request context is popped *before* the app context it pushed, so `teardown_request` handlers still have `current_app`/`g` available.
- **Session errors cannot wedge the context:** if `open_session` raises, the exception propagates, WSGI error handling produces a 500, and the `finally` blocks in `pop()` still fully unbind both contexts (`test_session_error_pops_context`).

#### `match_request()` — URL matching hook

```python
def match_request(self) -> None:
    try:
        result = self.url_adapter.match(return_rule=True)
        self.request.url_rule, self.request.view_args = result
    except HTTPException as e:
        self.request.routing_exception = e
```

A documented override point: subclasses can customize or short-circuit matching. Success populates `request.url_rule` / `request.view_args` (which drive `request.endpoint` and `request.blueprint`); failure stores the `HTTPException` (typically `NotFound`, `MethodNotAllowed`, or a `RequestRedirect`) instead of raising.

#### `copy()` — context transfer for greenlets

Returns a **new** `RequestContext` that shares the *same* `Request` object, its environ, and the *current session object* (since Flask 1.1 — avoids pointing at an out-of-date session). The copy starts with fresh `_after_request_functions` and `_cv_tokens`.

> ⚠️ **Not thread-safe.** The shared request object means `copy()` is safe for greenlets (cooperative scheduling) but not for OS threads unless request access is externally locked.

This method underpins both `copy_current_request_context()` and the greenlet test suite `TestGreenletContextCopying`.

---

### `after_this_request(f)`

Registers `f` on the active context's `_after_request_functions` list. Raises `RuntimeError` if no request context is active.

Execution order within `Flask.process_response`:

```mermaid
flowchart LR
    V["view returns value"] --> MR["Flask.make_response"]
    MR --> P["Flask.process_response(response)"]
    P --> D["1. ctx._after_request_functions<br>(registered via after_this_request)"]
    D --> B["2. blueprint + app after_request funcs<br>(reverse registration order)"]
    B --> S["3. session_interface.save_session<br>(skipped for null sessions)"]
    S --> R["final Response"]
```

Typical use: a decorator or helper that must add headers/cookies without owning the response:

```python
@app.route('/')
def index():
    @after_this_request
    def add_header(response):
        response.headers['X-Foo'] = 'Parachute'
        return response
    return 'Hello World!'
```

---

### `copy_current_request_context(f)`

Decorator form of `copy()` for offloading work while retaining request access:

```python
@app.route('/')
def index():
    @copy_current_request_context
    def do_some_work():
        ...  # flask.request and flask.session available here

    gevent.spawn(do_some_work)
    return 'Regular response'
```

Mechanics:

1. Grabs the active `RequestContext` (raises `RuntimeError` if none).
2. Calls `ctx.copy()` **at decoration time**.
3. Returns a wrapper that does `with ctx: return ctx.app.ensure_sync(f)(...)` — so async functions are supported, and the copied context is bound only for the duration of the call.
4. Preserves the wrapped function's metadata via `functools.update_wrapper`.

---

## End-to-End Request Lifecycle

The following sequence shows where this module sits inside `Flask.wsgi_app` (details of the dispatch pipeline itself are covered in [application-core_flask-app](application-core_flask-app.md)):

```mermaid
sequenceDiagram
    autonumber
    participant W as WSGI Server
    participant F as Flask.wsgi_app
    participant RC as RequestContext
    participant AC as AppContext
    participant SI as SessionInterface
    participant UA as URL Adapter
    participant D as full_dispatch_request

    W->>F: __call__(environ, start_response)
    F->>RC: request_context(environ)
    F->>RC: push()
    RC->>AC: push() if no app context for this app
    RC->>SI: open_session(app, request)
    alt open_session returns None
        RC->>SI: make_null_session(app)
    end
    RC->>UA: match_request()
    UA-->>RC: url_rule + view_args | routing_exception
    F->>D: dispatch, preprocess, finalize
    D-->>F: Response
    F->>RC: pop(error)
    RC->>F: do_teardown_request(error) + request.close()
    RC->>AC: pop(exc) if it was pushed here
    F->>W: response(environ, start_response)
```

Error-path notes (from `wsgi_app`):

- Any exception during `push()` or dispatch is funneled to `handle_exception` → a 500 (or re-raise when `PROPAGATE_EXCEPTIONS`/debug applies); `ctx.pop(error)` still runs in the `finally` block, so **teardown always executes** even for fatal errors and `BaseException`s.
- Under the interactive debugger, or when the test client requests context preservation, `wsgi_app` passes the live `AppContext` and `RequestContext` to `environ["werkzeug.debug.preserve_context"]` *before* popping, so `request`/`g` remain inspectable afterwards — with the caveat (documented on the class) that teardown has already run and resources such as DB connections may be closed. See [testing-support](testing-support.md) for the client-side mechanics.

---

## Session Integration

`RequestContext.push()` is the single point where a session comes to life:

1. `session_interface.open_session(app, request)` is called **after** the context is bound, so custom interfaces may legitimately read `flask.request` (e.g. deriving the cookie name from the URL — see `test_session_dynamic_cookie_name`).
2. `None` means "not an error, just no session data" → `make_null_session(app)` produces a `NullSession` that raises a helpful error on writes (e.g. missing `SECRET_KEY`).
3. The session is stored on the context, which is exactly what the `flask.session` proxy resolves to; `process_response` later calls `save_session` for non-null sessions.
4. `copy()` re-uses the session object rather than re-decoding the cookie, keeping greenlet copies consistent with the parent context.

A raising `open_session` is treated like any dispatch failure: 500 response, context fully popped. Session backend details live in [sessions](sessions.md).

---

## URL Matching and Routing Exceptions

- **Adapter creation** happens in the constructor via `Flask.create_url_adapter`, which also validates `Host` against `TRUSTED_HOSTS`. Invalid hosts (e.g. `"\x8a"`) raise an `HTTPException` that is parked in `request.routing_exception` → later surfaces as **400 Bad Request** (`test_bad_environ_raises_bad_request`); IDNA-compatible unicode hosts and punycode hosts are accepted (`test_environ_for_valid_idna_completes`, `test_normal_environ_completes`).
- **Matching** happens in `push()` → `match_request()`, storing `url_rule`/`view_args` or a `routing_exception` (`NotFound`, `MethodNotAllowed`, `RequestRedirect`).
- **Consumption** happens in `Flask.dispatch_request`, which re-raises the stored exception — in debug mode potentially converting method/body-discarding redirects into `FormDataRoutingRedirect` for developer guidance (see [debug-helpers](debug-helpers.md)).
- `Flask.url_for` and `Flask.make_default_options_response` read the adapter **from the active request context** (`request_ctx.url_adapter`), which is why URL building behaves differently inside vs. outside a request (`test_proper_test_request_context`, `test_url_generation_requires_server_name` in the sibling app-context module).

---

## Context Detection and Nested Usage

Related helpers (defined in the same file, documented with the parent/sibling modules):

| Helper | Defined in | Question answered |
|---|---|---|
| `has_request_context()` | `contexts` (this file) | Is any `RequestContext` active? |
| `has_app_context()` | [contexts_app_context](contexts_app_context.md) | Is an `AppContext` active? |

Because `LocalProxy` is falsy when unbound, `if request:` is an accepted idiom equivalent to `has_request_context()` (`test_context_test`).

Nested pushes (two `push()` calls without an intervening `pop()`) are fully supported:

- The inner push stores another `(token, None)` entry — no duplicate app context, no session reload.
- The inner `pop()` only resets the contextvar; teardown and environ cleanup are reserved for the outermost pop.

---

## Concurrency Model

| Scenario | Mechanism | Safety |
|---|---|---|
| Multiple concurrent WSGI requests | One `RequestContext` per request; isolation via `contextvars` (correct under threads, greenlets, and asyncio) | Safe |
| Greenlets (gevent, Werkzeug dev server) | `ctx.copy()` / `copy_current_request_context` | Safe — cooperative scheduling; session object shared by design |
| OS threads sharing a copy | same `Request` object mutated concurrently | **Unsafe** unless access is locked (documented on `copy()`) |
| Async views | contexts are normal contextvars; `app.ensure_sync` bridges coroutines back to WSGI | Safe |

The greenlet path is exercised by `TestGreenletContextCopying`, which verifies both `request_ctx.copy()` and the `@copy_current_request_context` decorator, including access to `request.args` and a session value written before the copy.

---

## Testing Integration

- `Flask.test_request_context(*args, **kwargs)` builds an environ with `EnvironBuilder` (from [testing-support](testing-support.md)) and returns a ready-to-push `RequestContext` — the recommended way to unit-test view functions and helpers that need `request` (`test_manual_context_binding` shows manual `push()`/`pop()`; outside the context, calling the view raises `RuntimeError` from the proxy).
- `app.request_context(environ)` accepts a raw WSGI environ for low-level tests.
- The `FlaskClient` can *preserve* the request context after a request for debugging; `RequestContext`/`AppContext` cooperate via the token list and `werkzeug.debug.preserve_context` hook (see [testing-support](testing-support.md)).

---

## Test Coverage Map

`tests/test_reqctx.py` pins the module's behavioral contract:

| Test | Verified behavior |
|---|---|
| `test_teardown_on_pop` | `teardown_request` runs on `pop()` with `exc=None` for a clean request. |
| `test_teardown_with_previous_exception` | A stale in-flight exception is *not* leaked into teardown of a clean context. |
| `test_teardown_with_handled_exception` | Exceptions already handled inside the context are not passed to teardown. |
| `test_proper_test_request_context` | External `url_for` under `SERVER_NAME`, subdomain rules, host/port/scheme variants. |
| `test_context_binding` | Views resolve `flask.request` only while bound; proxies unbound after pop. |
| `test_context_test` | Proxy truthiness and `has_request_context()` toggle with push/pop. |
| `test_manual_context_binding` | Manual push/pop; `RuntimeError` when accessing `request` unbound. |
| `TestGreenletContextCopying` | `copy()` and `copy_current_request_context` carry request **and session** into greenlets, and unbind on exit. |
| `test_session_error_pops_context` | Raising `open_session` → 500; request/app contexts still fully popped. |
| `test_session_dynamic_cookie_name` | Session interface can inspect `flask.request` (session opens before routing). |
| `test_bad_environ_raises_bad_request` | Non-printable `Host` → deferred routing exception → 400. |
| `test_environ_for_valid_idna_completes` | Unicode IDNA hosts accepted. |
| `test_normal_environ_completes` | Punycode hosts accepted through the normal client path. |

---

## Design Notes & Invariants

1. **Push/pop symmetry with tokens.** `_cv_tokens` makes nested pushes re-entrant and allows external parties (debugger, test client) to delay or re-establish binding without corrupting state.
2. **Fail-late routing.** Environment/host problems are captured, not thrown, so the standard error-handling machinery produces well-formed HTTP error responses.
3. **Teardown-only-once.** Only the outermost pop triggers `do_teardown_request`; the pushed `AppContext` (if any) pops immediately after, preserving app resources for request teardown handlers.
4. **Deterministic cleanup.** The environ `werkzeug.request` nulling breaks the request↔environ cycle; both contexts pop in `finally` blocks so no signal or callback ordering can leak an active context on error paths.
5. **Single source of session truth.** The context's `session` attribute is what the proxy reads, what `copy()` shares, and what `process_response` saves — one object per request, opened at most once.

---

## Related Modules

| Module | Relationship |
|---|---|
| [contexts_app_context](contexts_app_context.md) | Sibling module: `AppContext`, `_AppCtxGlobals` (`g`), `has_app_context` — pushed/consumed by this module. |
| [contexts](contexts.md) | Parent module: shared context model, `has_request_context`, copy helpers overview. |
| [application-core_flask-app](application-core_flask-app.md) | `Flask.wsgi_app`, `full_dispatch_request`, teardown registration — drives push/pop in production. |
| [sessions](sessions.md) | `SessionInterface.open_session` / `make_null_session` invoked by `push()`. |
| [testing-support](testing-support.md) | `EnvironBuilder` (backs `test_request_context`), `FlaskClient` context preservation. |
| [debug-helpers](debug-helpers.md) | `FormDataRoutingRedirect` raised when dispatch re-raises deferred routing exceptions in debug mode. |
| [helpers](helpers.md) | `get_flashed_messages` reads `request_ctx.flashes`; `stream_with_context` re-pushes the request context. |
