# application-core_debug-helpers

## 1. Introduction

The `application-core_debug-helpers` module wraps `src/flask/debughelpers.py`, the small but high-leverage corner of Flask whose sole job is to **convert confusing runtime failures into actionable developer diagnostics**. It contains no request-processing logic of its own; instead it provides:

- **Three purpose-built exception types** — `DebugFilesKeyError`, `FormDataRoutingRedirect`, and `UnexpectedUnicodeError` — that replace generic errors (`KeyError`, `RequestRedirect`, `UnicodeError`) with messages that explain *why* the failure happened and *how to fix it*.
- **Three helper functions** — `attach_enctype_error_multidict`, `explain_template_loading_attempts`, and the private `_dump_loader_info` — that the framework core calls at well-defined hook points, but only when a debug/explain flag is active.

The module is deliberately defensive of production behavior: every feature it provides is **gated behind debug mode or an explicit configuration flag**, so a fully-configured production app pays zero runtime cost and sees none of these patched behaviors.

| Source component | Kind | Role |
|---|---|---|
| `src/flask/debughelpers.py::DebugFilesKeyError` | Exception (`KeyError`, `AssertionError`) | Explains `request.files[...]` misses caused by a missing `enctype="multipart/form-data"` |
| `src/flask/debughelpers.py::FormDataRoutingRedirect` | Exception (`AssertionError`) | Explains redirects that would silently drop a non-GET request body |
| `src/flask/debughelpers.py::UnexpectedUnicodeError` | Exception (`AssertionError`, `UnicodeError`) | Public type for places wanting better reporting of unexpected unicode/binary data |
| `attach_enctype_error_multidict(request)` | Function (private, `:meta private:`) | Patches a request's `files` multidict with the error-raising subclass |
| `explain_template_loading_attempts(app, template, attempts)` | Function | Logs a per-loader report of a failed/suspicious template lookup |
| `_dump_loader_info(loader)` | Function (private) | Renders a Jinja loader's public attributes for the report above |

**Source of truth:** `src/flask/debughelpers.py` · **Tests:** `tests/test_basic.py::test_enctype_debug_helper`, `tests/test_basic.py::test_routing_redirect_debugging`, `tests/test_subclassing.py::test_suppressed_exception_logging`

---

## 2. Architecture Overview

`debughelpers` is a *leaf* module: it imports from the framework (app, blueprints, globals, sansio types) and from Jinja/Werkzeug, but **nothing in Flask imports it at module load time**. All three integration points use *deferred, in-function imports* (`from .debughelpers import ...`) so the helpers are only loaded when a debug path is actually taken.

```mermaid
flowchart LR
    subgraph consumers["Framework integration points"]
        REQ["flask.wrappers.Request<br/>_load_form_data()"]
        DISPATCH["flask.app.Flask<br/>dispatch_request() -&gt;<br/>raise_routing_exception()"]
        LOADER["flask.templating.<br/>DispatchingJinjaLoader<br/>_get_source_explained()"]
    end

    subgraph module["src/flask/debughelpers.py"]
        MULTIDICT["attach_enctype_error_multidict()"]
        FKE["DebugFilesKeyError"]
        FRR["FormDataRoutingRedirect"]
        EXPLAIN["explain_template_loading_attempts()"]
        DUMP["_dump_loader_info()"]
        UUE["UnexpectedUnicodeError"]
    end

    subgraph deps["Dependencies"]
        WZ["werkzeug.routing.RequestRedirect"]
        JJ["jinja2.loaders.BaseLoader"]
        CTX["flask.globals.request_ctx"]
        BP["flask.blueprints.Blueprint"]
        APP["flask.sansio.app.App"]
    end

    REQ -- "gate: current_app.debug<br/>and mimetype != multipart/form-data<br/>and no files parsed" --> MULTIDICT
    MULTIDICT -- "attaches subclass that raises" --> FKE
    DISPATCH -- "gate: app.debug, RequestRedirect<br/>code not 307/308, method not GET/HEAD/OPTIONS" --> FRR
    LOADER -- "gate: EXPLAIN_TEMPLATE_LOADING" --> EXPLAIN
    EXPLAIN --> DUMP
    EXPLAIN -.-> CTX
    EXPLAIN -.-> BP
    EXPLAIN -.-> APP
    FRR -.-> WZ
    LOADER -.-> JJ
    UUE -.-> API["public debugging API<br/>for extensions"]
```

Key architectural properties:

1. **Lazy coupling** — `flask.wrappers.Request._load_form_data()`, `Flask.raise_routing_exception()`, and `DispatchingJinjaLoader._get_source_explained()` all import from `debughelpers` *inside the function body*, keeping the framework's import graph acyclic and the module optional in spirit.
2. **Single-tenant patching** — `attach_enctype_error_multidict` mutates only the *current request object's* files multidict class (`request.files.__class__ = newcls`), never global state, so concurrent requests are unaffected.
3. **AssertionError lineage** — all three exceptions derive from `AssertionError`, signaling "this is a bug in *your* code" rather than a client error; Flask maps none of them to HTTP status codes, so they propagate to the debugger/test runner.
4. **Read-only diagnostics** — `explain_template_loading_attempts` only observes and logs; it never changes which template is selected.

---

## 3. Component Reference

### 3.1 `DebugFilesKeyError(KeyError, AssertionError)`

Raised *from `request.files` access during debugging* when a key is missing from `request.files` **but exists in `request.form`**. The constructor builds the message eagerly and stores it on `self.msg`; `__str__` returns it.

Message anatomy (built from the live request):

```
You tried to access the file {key!r} in the request.files dictionary but it does
not exist. The mimetype for the request is {request.mimetype!r} instead of
'multipart/form-data' which means that no file contents were transmitted. To fix
this error you should provide enctype="multipart/form-data" in your form.
```

If the same key *was* submitted as a plain form field, an evidentiary appendix is appended:

```
The browser instead transmitted some file names. This was submitted: 'index.txt'
```

**Why the dual inheritance?**
- `KeyError` base: it surfaces at the same expression where a `KeyError` would have been raised, and remains catchable as `KeyError`.
- `AssertionError` base: it is a *developer* error, so it is not eligible for HTTP error-handler mapping or 500 conversion semantics — it escapes to the interactive debugger.
- Crucially, it is **not** a `werkzeug.exceptions.BadRequestKeyError`, so the `TRAP_BAD_REQUEST_ERRORS` machinery (see [configuration](configuration.md)) does not apply; the full diagnostic message is always shown rather than being condensed into a 400 response.

### 3.2 `attach_enctype_error_multidict(request)`

The patching mechanism that makes `DebugFilesKeyError` reachable. Called from `flask.wrappers.Request._load_form_data()` **only when all of the following hold**:

- `current_app.debug` is truthy,
- `request.mimetype != "multipart/form-data"`,
- no file parts were parsed (`not self.files`).

Mechanics:

1. Captures `oldcls = request.files.__class__`.
2. Defines `newcls(oldcls)` overriding `__getitem__`:
   - On `KeyError`, checks `key in request.form`.
   - If present → raises `DebugFilesKeyError(request, key)`, **preserving the original traceback** via `.with_traceback(e.__traceback__)`.
   - If absent → re-raises the plain `KeyError` (genuinely unknown key behaves normally).
3. Copies `oldcls.__name__` and `oldcls.__module__` onto the subclass so tracebacks/reprs do not reveal the debug shim.

### 3.3 `FormDataRoutingRedirect(AssertionError)`

Raised *in debug mode only* when URL routing wants to issue a redirect that a browser would execute in a **data-destroying** way: a 301/302 redirect on a `POST`/`PUT`/... request drops the method *and* the body, silently sending an empty `GET` to the target.

Raised by `Flask.raise_routing_exception()` (called from `Flask.dispatch_request()` whenever `request.routing_exception` is set) under this precise gate:

| Condition | Required value |
|---|---|
| `app.debug` | `True` |
| `request.routing_exception` | instance of `werkzeug.routing.RequestRedirect` |
| redirect status code | **not** `307` / `308` (those re-send method + body) |
| request method | **not** `GET`, `HEAD`, or `OPTIONS` (no body to lose) |

Message anatomy (two variants):

- Always: `A request was sent to '{request.url}', but routing issued a redirect to the canonical URL '{exc.new_url}'.`
- If the redirect is exactly the request URL plus a trailing slash (`f"{request.base_url}/" == exc.new_url.partition("?")[0]`), an explanation of Flask's trailing-slash redirect behavior is inserted.
- Always closed with the prescription: *send requests to the canonical URL, or use 307/308 for routing redirects — otherwise browsers will drop form data* — and the note **"This exception is only raised in debug mode."**

### 3.4 `UnexpectedUnicodeError(AssertionError, UnicodeError)`

A public exception type for code paths that want better reporting of unexpected unicode or binary data. It is part of Flask's stable debugging API surface: catching it as `UnicodeError` works for encoding-sensitive handlers, while its `AssertionError` base keeps it in the "application bug" diagnostic family. Unlike the other two members it takes no constructor logic and carries no framework-specific message.

### 3.5 `explain_template_loading_attempts(app, template, attempts)` and `_dump_loader_info(loader)`

Called exclusively by `flask.templating.DispatchingJinjaLoader._get_source_explained()` when `EXPLAIN_TEMPLATE_LOADING` is enabled. It receives the full list of `(loader, source_object, result_triple)` attempts made across the app and every registered blueprint, and produces a log report:

1. Header: `Locating template {template!r}:`
2. Per attempt:
   - `{idx:5}: trying loader of application {import_name!r}` / `... of blueprint {name!r} ({import_name})` / fallback `repr(srcobj)`
   - Loader dump from `_dump_loader_info`: the loader's `class: module.Name` plus every *public* attribute whose value is a string, number, bool, or list-of-strings (e.g. `searchpath` entries of a `FileSystemLoader`).
   - Outcome: `-> no match` or `-> found ({filename!r})`
3. Verdicts:
   - `total_found == 0` → `Error: the template could not be found.`
   - `total_found > 1` → `Warning: multiple loaders returned a match for the template.` (shadowing alert — template resolution order is *app first, then blueprints*)
4. If the verdict was suspicious **and** the lookup originated from a blueprint endpoint (detected via the `request_ctx` global proxy from [contexts](contexts.md)), extra hints are appended pointing at blueprint template folders, with a link to the Flask blueprint docs.
5. The report is emitted via `app.logger.info(...)` — see [logging](logging.md) for how Flask's logger resolves handlers (including the `wsgi_errors_stream` fallback).

---

## 4. Process Flows

### 4.1 Enctype debugging flow (`DebugFilesKeyError`)

```mermaid
sequenceDiagram
    autonumber
    participant C as Browser / Test Client
    participant R as flask Request
    participant DH as debughelpers
    participant V as View function

    C->>R: POST /upload, data=foo=value, form-urlencoded
    R->>R: _load_form_data()
    Note over R: gate: app.debug and mimetype != multipart/form-data and no files parsed
    R->>DH: attach_enctype_error_multidict(request)
    DH->>DH: request.files.__class__ = patched subclass
    R->>V: dispatch to view
    V->>R: request.files["foo"]
    R->>DH: KeyError("foo")
    DH->>DH: "foo" in request.form ?
    DH--xC: raise DebugFilesKeyError with actionable message
    Note over C: AssertionError propagates to debugger / test runner,<br/>never converted to a 400 or 500
```

Behavior when debug is **off**: the patch is never attached; `request.files["foo"]` raises an opaque bare `KeyError`, which surfaces as a generic 500.

### 4.2 Routing-redirect debugging flow (`FormDataRoutingRedirect`)

```mermaid
flowchart TD
    A["dispatch_request(): request.routing_exception is not None"] --> B{"app.debug?"}
    B -- No --> P["raise routing_exception as-is<br/>(e.g. 308 redirect, browser resends body)"]
    B -- Yes --> C{"routing_exception is a RequestRedirect?"}
    C -- No --> P
    C -- Yes --> D{"code is 307 or 308?"}
    D -- Yes --> P
    D -- No --> E{"method is GET / HEAD / OPTIONS?"}
    E -- Yes --> P
    E -- No --> F["raise FormDataRoutingRedirect(request)"]
    F --> G["AssertionError surfaces with guidance:<br/>use the canonical URL, or define the redirect as 307/308"]
```

Both branches are exercised by `test_routing_redirect_debugging`: with Werkzeug's modern default 308, `POST /user` + `follow_redirects=True` works and the form data survives; after monkeypatching `RequestRedirect.code = 301`, the same request raises an `AssertionError` whose text contains `canonical URL 'http://localhost/user/'`.

### 4.3 Template-loading explanation flow (`EXPLAIN_TEMPLATE_LOADING`)

```mermaid
flowchart TD
    A["render_template / Jinja get_source"] --> B{"EXPLAIN_TEMPLATE_LOADING?"}
    B -- No --> C["_get_source_fast():<br/>first loader to find the template wins"]
    B -- Yes --> D["_get_source_explained():<br/>probe app loader + every blueprint loader,<br/>collect attempts"]
    D --> E["explain_template_loading_attempts(app, template, attempts)"]
    E --> F["Format lines: loader class, public attrs (_dump_loader_info),<br/>per-attempt match result, source object app or blueprint"]
    F --> G{"total_found"}
    G -- "0" --> H["Error: the template could not be found."]
    G -- "1" --> J["Normal report"]
    G -- "&gt;1" --> I["Warning: multiple loaders returned a match."]
    H --> K{"lookup from a blueprint endpoint?<br/>(via request_ctx proxy)"}
    I --> K
    K -- Yes --> L["Append blueprint template-folder hints + docs link"]
    K -- No --> M["app.logger.info(report)"]
    L --> M
```

The `request_ctx` check is written defensively (`if request_ctx and request_ctx.request.blueprint is not None`): the proxy is falsy outside a request, so the function also works for `render_template` calls made under a bare [app context](contexts.md).

---

## 5. Integration with the Framework

| Integration point | Producer module | debughelpers member | Activation gate |
|---|---|---|---|
| `Request._load_form_data()` | `flask/wrappers.py` | `attach_enctype_error_multidict` → `DebugFilesKeyError` | `current_app.debug` ∧ non-multipart ∧ no files parsed |
| `Flask.raise_routing_exception()` ← `dispatch_request()` | [application-core_flask-app](application-core_flask-app.md) | `FormDataRoutingRedirect` | `app.debug` ∧ `RequestRedirect` ∧ code ∉ {307, 308} ∧ method ∉ {GET, HEAD, OPTIONS} |
| `DispatchingJinjaLoader._get_source_explained()` | [templating](templating.md) | `explain_template_loading_attempts` + `_dump_loader_info` | `EXPLAIN_TEMPLATE_LOADING = True` |
| Routing exceptions originate as `request.routing_exception` | [contexts](contexts.md) (`RequestContext.match_request` / `create_url_adapter`) | — (consumed by the flow above) | always |
| Loader report enumerates app + blueprint template folders | [blueprints](blueprints.md) | `Blueprint` / `App` type checks for source labels | always |
| Diagnostics output | [logging](logging.md) (`app.logger`, `wsgi_errors_stream`) | report emission | always (INFO level) |

**Related-but-separate mechanisms** (do not confuse with this module):

- `TRAP_BAD_REQUEST_ERRORS` / `BadRequestKeyError.show_exception` — the debug-ish reporting path for *form* key errors, implemented in `Flask.handle_user_exception` (see [application-core_flask-app](application-core_flask-app.md)). `DebugFilesKeyError` intentionally bypasses it by subclassing plain `KeyError`.
- `TRAP_HTTP_EXCEPTIONS` — re-raises HTTP exceptions instead of handling them; orthogonal to `FormDataRoutingRedirect`, which fires *before* any HTTP exception handling because `RoutingException`s (like `RequestRedirect`) are excluded from error handlers.
- `Flask.log_exception` — the unhandled-exception logging hook. `test_suppressed_exception_logging` demonstrates the extension contract: a subclass overriding `log_exception` with a no-op still produces the 500 response, but nothing is written to stderr — the same "diagnostics without behavior change" principle this module embodies.

---

## 6. Configuration Interplay

The module's behavior is controlled entirely through app configuration (see [configuration](configuration.md) and the `default_config` in [application-core_sansio-foundation](application-core_sansio-foundation.md)):

| Config key | Default | Effect on debug-helpers |
|---|---|---|
| `DEBUG` | `None` | Master gate for `attach_enctype_error_multidict` and `FormDataRoutingRedirect` |
| `EXPLAIN_TEMPLATE_LOADING` | `False` | Switches `DispatchingJinjaLoader` to the explained (reporting) source lookup |
| `PROPAGATE_EXCEPTIONS` | `None` (→ `testing or debug`) | Ensures `AssertionError`-based diagnostics escape `Flask.handle_exception` to the debugger instead of becoming a 500 |
| `TESTING` | `False` | Also enables exception propagation, so tests observe these errors directly |

In production (`DEBUG=False`, `TESTING=False`): no multidict patching, redirects behave as plain HTTP redirects, template loads use the fast path, and none of the exceptions here are ever constructed.

---

## 7. Testing Coverage

The module's own tests live in the shared basic/subclassing suites (broader suite: [application-core_test-suite](application-core_test-suite.md)):

| Test | What it validates |
|---|---|
| `tests/test_basic.py::test_enctype_debug_helper` | With `app.debug = True`, a non-multipart POST followed by `request.files["foo"]` raises `DebugFilesKeyError`; message contains *"no file contents were transmitted"* and *"This was submitted: 'index.txt'"* |
| `tests/test_basic.py::test_routing_redirect_debugging` | `POST /user` → `/user/` with default 308 preserves form data (`rv.data == b"success"`); with `RequestRedirect.code` monkeypatched to 301, `follow_redirects=True` raises an `AssertionError` naming the canonical URL |
| `tests/test_subclassing.py::test_suppressed_exception_logging` | Subclass overriding `Flask.log_exception` suppresses stderr output for unhandled exceptions while still returning 500 — validating the diagnostics hook the debug helpers rely on |

Note the test technique of monkeypatching `RequestRedirect.code` — production Werkzeug already emits 307/308 for rule redirects, so forcing a legacy 301 is the only way to reach the `FormDataRoutingRedirect` branch deterministically.

---

## 8. Usage Examples

```python
# Catching the debug error in a test to assert the diagnosis
import pytest
from flask.debughelpers import DebugFilesKeyError

def test_missing_enctype(app, client):
    app.debug = True

    @app.post("/upload")
    def upload():
        return flask.request.files["file"].filename

    with pytest.raises(DebugFilesKeyError) as e:
        client.post("/upload", data={"file": "notes.txt"})

    assert 'enctype="multipart/form-data"' in str(e.value)
```

```python
# Reading the routing-redirect diagnosis
from flask.debughelpers import FormDataRoutingRedirect

try:
    client.post("/user", data={"status": "x"}, follow_redirects=True)
except FormDataRoutingRedirect as e:
    # 'A request was sent to ... but routing issued a redirect to the
    #  canonical URL ... Send requests to the canonical URL, or use 307
    #  or 308 for routing redirects.'
    print(e)
```

```python
# Diagnosing template resolution across app + blueprints
app.config["EXPLAIN_TEMPLATE_LOADING"] = True
# Each template load now logs, e.g.:
#   Locating template 'admin/index.html':
#       1: trying loader of application 'myapp'
#          class: jinja2.loaders.FileSystemLoader
#          searchpath:
#            - /srv/myapp/templates
#       -> no match
#       2: trying loader of blueprint 'admin' (admin)
#       -> found ('templates/admin/index.html')
```

---

## 9. Design Notes & Maintenance Guidance

- **Keep the module leaf-shaped.** All core callers use deferred imports; do not move `debughelpers` imports to module level in `app.py`/`wrappers.py`/`templating.py`, or you risk import cycles and eager loading in production.
- **Messages are API.** Tests assert on message *content* (e.g. `"This was submitted: 'index.txt'"`); rewording strings is a user-visible change.
- **Preserve traceback fidelity.** `attach_enctype_error_multidict` chains the original `KeyError` traceback via `with_traceback`, and the subclass copies `__name__`/`__module__` from the original class — both details keep debugger output truthful.
- **AssertionError semantics are load-bearing.** The `AssertionError` bases ensure these diagnostics are treated as developer errors (propagated, not status-mapped). Do not re-parent them to `Exception` subclasses that Flask's error-handler lookup would consume.
- **Scope patches per request.** `attach_enctype_error_multidict` mutates only the current request's files dict; never broaden it to a global monkeypatch.

---

## 10. Related Documentation

- [application-core](application-core.md) — overall core engine and module composition
- [application-core_flask-app](application-core_flask-app.md) — `Flask.dispatch_request` / `raise_routing_exception` / exception-handling pipeline
- [application-core_sansio-foundation](application-core_sansio-foundation.md) — sansio `App`/`Scaffold`, `setupmethod`, and `default_config` (including `DEBUG`, `EXPLAIN_TEMPLATE_LOADING`)
- [application-core_test-suite](application-core_test-suite.md) — shared behavioral tests (`test_trap_bad_request_key_error`, `test_exception_propagation`)
- [contexts](contexts.md) — `RequestContext.match_request` (origin of `routing_exception`) and the `request_ctx` proxy
- [blueprints](blueprints.md) — blueprint loaders and naming as surfaced in template reports
- [templating](templating.md) — `DispatchingJinjaLoader` and `Environment`
- [logging](logging.md) — `app.logger`, `wsgi_errors_stream`, handler resolution for the template report
- [configuration](configuration.md) — `Config` object loading the flags above
- [testing-support](testing-support.md) — `FlaskClient` behavior for exception propagation in tests
