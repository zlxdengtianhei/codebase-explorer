# Blueprints Module

> **Module scope:** `src/flask/blueprints.py`, `src/flask/sansio/blueprints.py`  
> **Child of:** [Core_Application_Engine___Modular_Composition](Core_Application_Engine___Modular_Composition.md)

## 1. Purpose & Core Functionality

The **blueprints module** implements Flask's application composition mechanism. A
`Blueprint` is a collection of routes, error handlers, request callbacks, template
filters/tests/globals, URL processors, and CLI commands that is defined *without*
requiring an application object, and is later applied to a real `Flask` app with a
single call to `app.register_blueprint(bp, **options)`.

Key capabilities delivered by this module:

| Capability | Where it lives |
|---|---|
| Deferred setup (`record` / `record_once`) and the registration pipeline (`register`) | `src/flask/sansio/blueprints.py` (sansio `Blueprint`) |
| `BlueprintSetupState` — the temporary binding between a blueprint and the target app (URL prefix, subdomain, name, URL defaults, `add_url_rule`) | `src/flask/sansio/blueprints.py` |
| Nested blueprint registration with prefix/subdomain/name composition | `src/flask/sansio/blueprints.py` |
| Blueprint-scoped vs. app-wide decorator variants (`before_app_request`, `app_errorhandler`, `app_template_filter`, …) | `src/flask/sansio/blueprints.py` (inherited setup methods) |
| Per-blueprint static file serving (`send_static_file`, `get_send_file_max_age`) | `src/flask/blueprints.py` (concrete `Blueprint`) |
| Per-blueprint resource access (`open_resource`) | `src/flask/blueprints.py` |
| Per-blueprint Click command group (`self.cli = AppGroup()`) | `src/flask/blueprints.py` + `src/flask/cli.py` |

Because a blueprint's `name` is prepended to every endpoint it registers
(`"name.endpoint"`) and its `url_prefix` is prepended to every URL rule, the same
blueprint can be registered multiple times under different names and prefixes —
the foundation of modular, reusable Flask applications.

## 2. Architecture Overview

### 2.1 Class hierarchy

The module follows Flask's **sansio pattern**: framework-independent logic lives in
`src/flask/sansio/blueprints.py`, while WSGI-bound conveniences live in
`src/flask/blueprints.py`. Both blueprints and apps derive from the shared
`Scaffold` base class, which is why decorators like `@bp.route(...)` mirror
`@app.route(...)` exactly.

```mermaid
classDiagram
    class Scaffold {
        <<sansio/scaffold.py>>
        +import_name
        +root_path
        +view_functions: dict
        +error_handler_spec: dict
        +before_request_funcs / after_request_funcs
        +teardown_request_funcs / template_context_processors
        +url_default_functions / url_value_preprocessors
        +route(rule) +get() +post() +put() +delete() +patch()
        +errorhandler(code) +context_processor(f)
    }
    class SansioBlueprint {
        <<sansio/blueprints.py>>
        +name : str
        +url_prefix / subdomain
        +deferred_functions : list
        +url_values_defaults : dict
        +cli_group
        +_blueprints : list~tuple~
        +record(func) +record_once(func)
        +make_setup_state(app, options, first)
        +register_blueprint(bp, **options)
        +register(app, options)
        -_merge_blueprint_funcs(app, name)
    }
    class BlueprintSetupState {
        <<sansio/blueprints.py>>
        +app : Flask
        +blueprint : Blueprint
        +options : dict
        +first_registration : bool
        +url_prefix / subdomain / name
        +url_defaults : dict
        +add_url_rule(rule, endpoint, view_func)
    }
    class Blueprint {
        <<blueprints.py>>
        +cli : AppGroup
        +get_send_file_max_age(filename)
        +send_static_file(filename)
        +open_resource(resource)
    }
    class AppGroup {
        <<cli.py>>
        +command() +group()
    }
    class Flask {
        <<app.py>>
        +blueprints : dict
        +register_blueprint(bp, **options)
        +add_url_rule(rule, endpoint, view_func)
        +cli : AppGroup
    }
    Scaffold <|-- SansioBlueprint : inherits setup methods
    SansioBlueprint <|-- Blueprint
    SansioBlueprint ..> BlueprintSetupState : make_setup_state()
    BlueprintSetupState --> Flask : app.add_url_rule()
    Blueprint ..> AppGroup : creates per-BP CLI group
    Flask o-- SansioBlueprint : app.blueprints registry
```

### 2.2 Registration pipeline

`Flask.register_blueprint()` simply delegates to `Blueprint.register()`. All real
work — name composition, uniqueness validation, static route setup, merging of
callbacks/error handlers, replaying deferred setup functions, CLI merging, and
recursive registration of child blueprints — happens there:

```mermaid
sequenceDiagram
    participant App as Flask app
    participant BP as Blueprint
    participant St as BlueprintSetupState
    participant Fn as deferred functions

    App->>BP: register(app, options)
    BP->>BP: compose name (name_prefix.name) and reject duplicates
    BP->>App: app.blueprints[name] = self (locks setup)
    BP->>St: make_setup_state(app, options, first_registration)
    alt static_folder configured
        BP->>St: state.add_url_rule(static_url_path + filename, static)
    end
    BP->>App: _merge_blueprint_funcs(app, name)
    Note over App,BP: merges error handlers, view functions,<br/>request and teardown funcs, url processors
    loop every recorded deferred function
        BP->>Fn: deferred(state)
        Fn->>St: state.add_url_rule(rule, endpoint, view)
        St->>App: app.add_url_rule(prefixed rule, name.endpoint, view)
    end
    BP->>App: merge self.cli into app.cli (per cli_group policy)
    loop each child in self._blueprints
        BP->>BP: child.register(app, merged prefix / subdomain / name_prefix)
    end
```

### 2.3 Runtime data flow (after registration)

Once registered, blueprint data has been *merged into the app's flat registries*.
At request time the dispatch pipeline consults `request.blueprints` (the chain of
blueprint names for the matched endpoint, outermost → innermost) to apply
blueprint-scoped behavior:

```mermaid
flowchart TD
    A[Request arrives] --> B[RequestContext.push<br/>routing matches endpoint e.g. 'admin.index2']
    B --> C[request.blueprints = chain of BP names]
    C --> D[preprocess_request<br/>url_value_preprocessors + before_request_funcs<br/>for None and reversed request.blueprints]
    D --> E[dispatch_request<br/>app.view_functions 'admin.index2']
    E --> F[process_response<br/>after_request_funcs: request.blueprints then None]
    F --> G[teardown on ctx.pop<br/>teardown_request_funcs per scope]
    E -. exception .-> H[_find_error_handler<br/>scoped by request.blueprints]
    G --> I[render_template? DispatchingJinjaLoader<br/>app loader then each blueprint's loader]
```

Details of the loader side are documented in
[Request_Services___Response_Rendering](Request_Services___Response_Rendering.md)
(`templating.py`); context pushing/popping in the [contexts](contexts.md) module.

## 3. Sub-modules

Detailed documentation is split by concern. Each link below points to the generated
sub-module documentation file in this docs directory:

1. **[Registration machinery](blueprints_registration_machinery.md)**
   (`blueprints_registration_machinery.md`) — the sansio
   `Blueprint` and `BlueprintSetupState` from `src/flask/sansio/blueprints.py`: the
   deferred-setup pattern, the full
   registration algorithm, nested-blueprint composition rules (URL prefixes,
   subdomains, dotted names), scoped-vs-app-wide decorators, and the setup-time
   lock that prevents post-registration mutation.
2. **[Concrete blueprint capabilities](blueprints_resources_and_cli.md)**
   (`blueprints_resources_and_cli.md`) — the
   WSGI-era `Blueprint` in `src/flask/blueprints.py`: per-blueprint static file
   serving, `SEND_FILE_MAX_AGE_DEFAULT` handling, `open_resource`, and the
   per-blueprint Click CLI group.
3. **[Test suite & example applications](blueprints_test_suite.md)**
   (`blueprints_test_suite.md`) —
   `tests/test_blueprints.py` and the `tests/test_apps/blueprintapp` demo apps
   (`admin`, `frontend`) that exercise templates, static files, nesting, renaming,
   and error-handling precedence.

## 4. Key Concepts

### 4.1 The deferred-setup pattern

Decorating with `@bp.route(...)` does **not** touch an app. Instead the blueprint
records a closure via `record()`; each closure receives the `BlueprintSetupState`
created at registration time. This is the inversion that lets blueprints be defined
in modules and libraries independent of any application instance:

```python
bp = Blueprint("admin", __name__, url_prefix="/admin")

@bp.route("/")                 # records deferred state.add_url_rule(...)
def index(): ...

app.register_blueprint(bp)     # replays all deferred functions with a fresh state
```

`record_once()` wraps a callback so it runs only when `state.first_registration`
is true — used heavily by the app-wide decorator variants.

### 4.2 Namespacing rules

| Concept | Rule |
|---|---|
| Blueprint name | Must be non-empty, may **not** contain `.` (dots are the endpoint separator) |
| Endpoint | Registered as `"[name_prefix.]name.endpoint"`; endpoints themselves may not contain dots |
| URL rule | `url_prefix` is joined to the rule with slash normalization (`/foo/` + `/bar` → `/foo/bar`) |
| Nested names | Child gets dotted registered name (`parent.child`); `name=` at registration renames a whole subtree |
| Duplicate registration | Same blueprint object + same name → `ValueError`; `name=` allows registering the same blueprint under multiple names |
| Self-registration | `bp.register_blueprint(bp)` raises `ValueError` |

### 4.3 Blueprint-scoped vs. app-wide decorators

| Scoped to blueprint's requests | App-wide variant (recorded `record_once`) |
|---|---|
| `before_request` / `after_request` / `teardown_request` | `before_app_request` / `after_app_request` / `teardown_app_request` |
| `context_processor` | `app_context_processor` |
| `errorhandler` | `app_errorhandler` |
| `url_defaults` / `url_value_preprocessor` | `app_url_defaults` / `app_url_value_preprocessor` |
| `template_filter` / `template_test` / `template_global` (via `Scaffold`) | `app_template_filter` / `app_template_test` / `app_template_global` |

Scoped callbacks are stored under the blueprint's name key in the app's
`*_funcs` dictionaries; app-wide variants are stored under the `None` key
(the app scope), exactly as if registered on the app directly.

### 4.4 Setup-time lock

Every setup method is wrapped by the `setupmethod` decorator (from
`Scaffold`, see the *sansio-foundation* sub-module of
[Core_Application_Engine___Modular_Composition](Core_Application_Engine___Modular_Composition.md)).
The sansio `Blueprint._check_setup_finished()` consults `_got_registered_once`,
which flips to `True` during the first `register()` call. After that, calling
`bp.route(...)`, `bp.errorhandler(...)`, etc. raises an `AssertionError`, because
further changes would not be applied consistently to already-registered apps.

### 4.5 Nested blueprints

Children registered with `bp.register_blueprint(child, **options)` are stored and
recursively registered when the parent registers. Composition rules:

- **URL prefix:** child prefix appended to parent's (`/parent` + `/child` → `/parent/child`), slash-normalized; either side may supply it.
- **Subdomain:** child first, dotted with parent's (`child="api"`, parent state `"parent"` → `"api.parent"`).
- **Name:** `name_prefix` accumulates parent names, producing fully-qualified endpoints such as `parent.child.endpoint`.
- **Error handlers** cascade outward: a grandchild `403` abort is handled by the grandchild handler, then the child's, then the parent's, then the app's.

## 5. How This Module Fits Into the System

- **[Core_Application_Engine___Modular_Composition](Core_Application_Engine___Modular_Composition.md)** — `Flask` is both the registration target (`register_blueprint`) and the dispatch engine whose flat registries (`view_functions`, `before_request_funcs`, `error_handler_spec`, …) blueprints populate. The concrete `Blueprint` deliberately duplicates `Flask.get_send_file_max_age` / `send_static_file` / `open_resource` so both objects expose identical file/resource APIs.
- **[contexts](contexts.md)** — `RequestContext` computes `request.blueprints`, the scope chain used by every blueprint-scoped callback, error handler lookup, and context processor ordering (`app → parent → child`).
- **[Request_Services___Response_Rendering](Request_Services___Response_Rendering.md)** — `DispatchingJinjaLoader` iterates `app.iter_blueprints()` so each blueprint's `template_folder` joins the app's template search path (app templates take precedence); `helpers.send_from_directory` powers blueprint static files.
- **[Developer_Interface___Testing_Tooling](Developer_Interface___Testing_Tooling.md)** — the per-blueprint `AppGroup` CLI is merged into `app.cli` at registration and surfaced by the `flask` CLI (`FlaskGroup`/`ScriptInfo`); `FlaskClient`/`FlaskCliRunner` drive most of the tests referenced below.
- **[Runtime_Configuration___Diagnostics](Runtime_Configuration___Diagnostics.md)** — blueprint behavior reads shared app config such as `SEND_FILE_MAX_AGE_DEFAULT` (static caching) through `current_app`.

## 6. Component Inventory

| Component | File | Responsibility |
|---|---|---|
| `Blueprint` (sansio) | `src/flask/sansio/blueprints.py` | Deferred setup recording, registration algorithm, nesting, scoped/app-wide decorators |
| `BlueprintSetupState` | `src/flask/sansio/blueprints.py` | Per-registration binding: app, options, resolved prefix/subdomain/name, prefixed `add_url_rule` |
| `Blueprint` (concrete) | `src/flask/blueprints.py` | Static file serving, cache max-age, `open_resource`, per-blueprint CLI group |
| `tests/test_blueprints.py` | tests | ~47 tests covering registration, nesting, renaming, processors, error handling, templates/static |
| `blueprintapp` demo apps | `tests/test_apps/blueprintapp/apps/{admin,frontend}` | Realistic blueprints with templates + static folders used by template/static tests |
