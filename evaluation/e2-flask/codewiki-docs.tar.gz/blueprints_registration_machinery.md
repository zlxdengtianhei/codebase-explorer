# Blueprints: Registration Machinery (`blueprints_registration_machinery`)

## 1. Introduction

The `blueprints_registration_machinery` module implements the **core deferred-registration pattern** that makes Flask blueprints possible. It lives in `src/flask/sansio/blueprints.py` and contains exactly two cooperating classes:

| Component | Role |
|---|---|
| `Blueprint` (sansio) | A *deferred collection* of routes, callbacks, error handlers and template functions. Decorators on a blueprint **record** closures instead of acting immediately. |
| `BlueprintSetupState` | A *temporary context object* created at registration time. It carries the resolved registration options (`url_prefix`, `subdomain`, `name`, `url_defaults`, …) and is handed to every recorded closure so it can finally talk to the real application. |

The key design idea: **a blueprint never modifies an application directly while it is being written**. Instead, every decorator call appends a function of the form `(state: BlueprintSetupState) -> None` to `Blueprint.deferred_functions`. Only when the application owner calls `app.register_blueprint(bp, ...)` are those functions replayed against a single setup state, translating "blueprint-relative" definitions into app-level registrations.

```
Definition time (import time)                Registration time
┌──────────────────────────┐                 ┌────────────────────────────────┐
│ @bp.route("/x")          │                 │ app.register_blueprint(bp)     │
│   → record(lambda s: …)  │  ── replay ──▶  │   → state = BlueprintSetupState│
│ @bp.before_app_request   │                 │   → deferred(state)            │
│   → record_once(…)       │                 │   → app.add_url_rule(...)      │
└──────────────────────────┘                 └────────────────────────────────┘
```

This module is the *sansio* (framework-agnostic) half of the blueprint feature. The concrete, WSGI-aware `flask.blueprints.Blueprint` — which adds the `cli` command group and static-file serving — is documented in [blueprints_resources_and_cli](blueprints_resources_and_cli.md), and the behavioral test coverage lives in [blueprints_test_suite](blueprints_test_suite.md).

---

## 2. Architecture & Component Relationships

### 2.1 Class hierarchy

Both classes inherit from infrastructure provided by [application-core](application-core.md):

- `Scaffold` (`src/flask/sansio/scaffold.py`) supplies the shared data structures (`view_functions`, `before_request_funcs`, `error_handler_spec`, …) and the blueprint-side decorators (`route`, `before_request`, `errorhandler`, …).
- `setupmethod` (`src/flask/sansio/scaffold.py`) is a decorator that wraps every *setup* method with a `_check_setup_finished` guard, freezing the object once it has been used.
- `App` / `Flask` is the registration *target*: `Flask.register_blueprint()` is the single public entry point into this module's machinery.

```mermaid
classDiagram
    direction LR

    class Scaffold {
        <<abstract, sansio>>
        +str import_name
        +str name
        +dict view_functions
        +dict error_handler_spec
        +dict before_request_funcs
        +dict after_request_funcs
        +dict teardown_request_funcs
        +dict template_context_processors
        +dict url_value_preprocessors
        +dict url_default_functions
        +route(rule, **options)
        +add_url_rule(rule, endpoint, view_func)*
        +before_request(f)*
        +errorhandler(code_or_exception)*
        +_check_setup_finished(f_name)*
    }

    class Blueprint {
        <<sansio, this module>>
        +str name
        +str url_prefix
        +str subdomain
        +dict url_values_defaults
        +list~DeferredSetupFunction~ deferred_functions
        +list~tuple~ _blueprints
        +bool _got_registered_once
        +record(func)
        +record_once(func)
        +make_setup_state(app, options, first) BlueprintSetupState
        +register_blueprint(blueprint, **options)
        +register(app, options)
        -_merge_blueprint_funcs(app, name)
        +add_url_rule(rule, endpoint, view_func)
        +app_template_filter(f, name)
        +before_app_request(f)
        +app_errorhandler(code)
    }

    class ConcreteBlueprint {
        <<flask.blueprints.Blueprint>>
        +AppGroup cli
        +send_static_file(filename) Response
        +open_resource(resource) IO
    }

    class BlueprintSetupState {
        <<sansio, this module>>
        +App app
        +Blueprint blueprint
        +dict options
        +bool first_registration
        +str subdomain
        +str url_prefix
        +str name
        +str name_prefix
        +dict url_defaults
        +add_url_rule(rule, endpoint, view_func, **options)
    }

    class App {
        <<flask.Flask>>
        +dict~str, Blueprint~ blueprints
        +register_blueprint(blueprint, **options)
        +add_url_rule(rule, endpoint, view_func)
    }

    Scaffold <|-- Blueprint : inherits
    Blueprint <|-- ConcreteBlueprint : adds CLI + static files
    Blueprint "1" *-- "*" BlueprintSetupState : make_setup_state()
    Blueprint "1" o-- "*" Blueprint : _blueprints (nested)
    BlueprintSetupState ..> App : add_url_rule()
    App "1" o-- "*" Blueprint : blueprints registry
```

### 2.2 Module dependency map

```mermaid
flowchart TD
    subgraph ThisModule["blueprints_registration_machinery (sansio/blueprints.py)"]
        BP[Blueprint]
        ST[BlueprintSetupState]
    end

    subgraph AppCore["application-core"]
        SCAF[Scaffold / setupmethod]
        APP[Flask / App]
        ROUTE[url_map + view_functions]
    end

    subgraph Sibling["blueprints_resources_and_cli"]
        CBP[Concrete Blueprint with cli AppGroup]
    end

    subgraph Ctx["contexts"]
        CTX[RequestContext / AppContext]
    end

    subgraph Tmpl["Request_Services: templating"]
        JINJA[jinja_env filters/tests/globals]
    end

    BP -->|inherits| SCAF
    ST -->|calls app.add_url_rule| APP
    APP -->|register_blueprint → bp.register| BP
    APP --> ROUTE
    CBP -->|extends| BP
    BP -->|record_once closures write| JINJA
    BP -->|name-scoped funcs consumed by| CTX
```

- **Upstream (definition time):** application code imports `Blueprint` and uses decorators inherited from `Scaffold` plus the `app_*` variants defined here.
- **Downstream (run time):** after registration, blueprint-scoped callbacks are consumed by request dispatching in [application-core](application-core.md) via [contexts](contexts.md) (`request.blueprints` drives `preprocess_request`, `process_response`, `do_teardown_request`, and `_find_error_handler`).

---

## 3. Component Reference

### 3.1 `BlueprintSetupState`

*"Temporary holder object for registering a blueprint with the application."*

Created once per `Blueprint.register()` call by `Blueprint.make_setup_state()`. Attributes:

| Attribute | Source | Purpose |
|---|---|---|
| `app` | registration target | Application the blueprint is attaching to |
| `blueprint` | owner | The blueprint that created this state |
| `options` | `register_blueprint(**options)` | Keyword overrides (may be extended during nested registration) |
| `first_registration` | computed in `register()` | `True` when this *blueprint object* has never been attached to this app — drives `record_once` semantics |
| `subdomain` | `options["subdomain"]` else `blueprint.subdomain` | Default subdomain for all of this blueprint's routes |
| `url_prefix` | `options["url_prefix"]` else `blueprint.url_prefix` | Path prefix prepended to all of this blueprint's rules |
| `name` / `name_prefix` | `options` (dotted composition) | Final, fully-qualified blueprint name and its parent chain |
| `url_defaults` | `blueprint.url_values_defaults` merged with `options["url_defaults"]` | Default view-argument values injected into every rule |

**`BlueprintSetupState.add_url_rule(rule, endpoint, view_func, **options)`** — the workhorse that converts blueprint-relative definitions into app registrations:

1. **URL prefixing** — if `url_prefix` is set, joins it with the rule: `"/".join((url_prefix.rstrip("/"), rule.lstrip("/")))`; if the rule is empty the prefix *is* the rule.
2. **Subdomain default** — `options.setdefault("subdomain", self.subdomain)`.
3. **Endpoint derivation** — falls back to `_endpoint_from_view_func(view_func)` (the function `__name__`).
4. **URL defaults merge** — per-rule `defaults` win over the state's `url_defaults`.
5. **Endpoint namespacing** — calls `app.add_url_rule(rule, f"{name_prefix}.{name}.{endpoint}".lstrip("."), ...)`.

> 💡 The `.lstrip(".")` at the top level means endpoints of a root-level blueprint are simply `name.endpoint`.

### 3.2 `Blueprint`

*"Represents a blueprint, a collection of routes and other app-related functions that can be registered on a real application later."*

#### Constructor validation

| Check | Error |
|---|---|
| `name` empty | `ValueError("'name' may not be empty.")` |
| `name` contains `.` | `ValueError("'name' may not contain a dot '.' character.")` |

Dots are reserved as the **blueprint hierarchy separator** (see §5). The constructor stores `url_prefix`, `subdomain`, `url_values_defaults`, `cli_group`, initializes the empty `deferred_functions` list, the nested `_blueprints` list, and the `_got_registered_once` latch.

#### The recording API — deferred setup

```mermaid
flowchart LR
    subgraph Decorators
        D1["@bp.route / add_url_rule"]
        D2["@bp.before_app_request / after_app_request / teardown_app_request"]
        D3["@bp.app_errorhandler"]
        D4["@bp.app_template_filter / test / global"]
        D5["@bp.context_processor / url_defaults / url_value_preprocessor (inherited)"]
    end
    D1 -- "record(λ s: s.add_url_rule(...))" --> Q
    D2 -- "record_once(λ s: s.app.*_funcs[None].append(f))" --> Q
    D3 -- "record_once(λ s: s.app.errorhandler(code)(f))" --> Q
    D4 -- "record_once(λ s: s.app.jinja_env.filters[name] = f)" --> Q
    D5 -- "record to self-scoped dicts" --> Q
    Q[("deferred_functions: list[DeferredSetupFunction]")]

    Q -- "replayed with state at register()" --> R[App-level structures]
```

- **`record(func)`** — appends `func` to `deferred_functions`. Wrapped by `@setupmethod`, so it is rejected after the first registration.
- **`record_once(func)`** — wraps `func` in a closure that only forwards to it when `state.first_registration` is `True`; `functools.update_wrapper` preserves the original function's metadata. Used for all *app-wide* registrations (`before_app_request`, `app_template_filter`, …) so registering the same blueprint under several names does not duplicate app-level handlers.
- **`make_setup_state(app, options, first_registration)`** — factory for `BlueprintSetupState`; **public extension point**: subclasses may return their own state subclass to customize registration.

Two scopes exist side by side, mirroring `Scaffold` semantics:

| Scope | Blueprint-scoped (`@bp.before_request`) | App-scoped (`@bp.before_app_request`) |
|---|---|---|
| Registration target | `self.before_request_funcs[name]` (merged per-name later) | `app.before_request_funcs[None]` via `record_once` |
| Runs for | requests handled by this blueprint | every request |

#### `register_blueprint(blueprint, **options)` — nesting

Appends `(blueprint, options)` to `self._blueprints`; nothing is executed yet. Guard: `ValueError("Cannot register a blueprint on itself")` prevents cycles. Actual (recursive) registration happens inside `register()`; options composition rules are in §5.2.

#### `register(app, options)` — the heart of the machinery

See the detailed walkthrough in §4 and §5.

#### `_merge_blueprint_funcs(app, name)` — merging scoped data

Copies blueprint-scoped registrations into the app's data structures, **rewriting every `None` scope key to the blueprint's final name** (and `key` to `f"{name}.{key}"` for endpoint-keyed entries):

```mermaid
flowchart LR
    subgraph BP["Blueprint (before merge)"]
        A1["error_handler_spec[None]"] --> A2["error_handler_spec[name]"]
        B1["view_functions[endpoint]"] --> B2["app.view_functions[name.endpoint]"]
        C1["before_request_funcs[None]"] --> C2["app.before_request_funcs[name]"]
        D1["after/teardown/url_default/url_preprocessor/context_processor funcs"] --> D2["same rewrite, per-key"]
    end
```

Error handlers get an extra transformation: each `(code → {exc_class → handler})` map is rebuilt as a fresh `defaultdict(dict, …)` so the app's structure stays independent from the blueprint's. This name-scoped layout is what lets [application-core](application-core.md)'s `_find_error_handler` prefer blueprint-local handlers while falling back to app-wide (`None`) ones.

---

## 4. Registration Lifecycle

### 4.1 State machine

```mermaid
stateDiagram-v2
    [*] --> Constructed : Blueprint(name, import_name, ...)
    Constructed --> Configuring : name validated (non-empty, dot-free)
    state Configuring {
        [*] --> Recording
        Recording : route() / before_request() / record() / record_once()
        Recording : closures appended to deferred_functions
        Recording --> Recording
    }
    Configuring --> Registered : app.register_blueprint(bp) → register(app, options)
    state Registered {
        [*] --> Frozen
        Frozen : _got_registered_once = True
        Frozen : any setupmethod call → AssertionError
        Frozen : nested children + re-registration still possible
    }
    Registered --> Registered : re-register under a different name= (record_once callbacks skipped)
    Registered --> [*]
```

The freeze is enforced by the `setupmethod` wrapper (from `sansio/scaffold.py`): every public setup method first calls `_check_setup_finished(f_name)`, which raises an `AssertionError` telling the developer to complete imports and decorators *before* registering. This prevents the subtle bug class where a route is added after registration and silently never takes effect. The app object has the analogous `_got_first_request` guard — both concepts are covered by tests in [blueprints_test_suite](blueprints_test_suite.md) (`test_self_registration`, `test_unique_blueprint_names`, `test_no_setup_after_first_request`).

### 4.2 End-to-end registration sequence

```mermaid
sequenceDiagram
    autonumber
    participant User as Application code
    participant BP as Blueprint
    participant App as Flask app
    participant State as BlueprintSetupState
    participant Def as deferred_functions

    Note over User,BP: Definition time (import time)
    User->>BP: bp = Blueprint("admin", __name__, url_prefix="/admin")
    User->>BP: @bp.route("/index") / @bp.before_app_request / ...
    BP->>Def: record(λ state: ...) / record_once(...)

    Note over User,State: Registration time
    User->>App: app.register_blueprint(bp, name="panel", url_defaults={...})
    App->>BP: bp.register(app, options)
    BP->>BP: name = f"{name_prefix}.{options.name or bp.name}".lstrip(".")
    BP->>BP: collision check against app.blueprints
    BP->>App: app.blueprints[name] = self, set _got_registered_once
    BP->>BP: first_bp_registration / first_name_registration computed
    BP->>State: state = make_setup_state(app, options, first_bp_registration)

    alt bp.has_static_folder
        BP->>State: state.add_url_rule(static_url_path + "/<path:filename>", "static", send_static_file)
        State->>App: app.add_url_rule(prefixed rule, "admin.static", ...)
    end

    alt first_bp_registration or first_name_registration
        BP->>App: _merge_blueprint_funcs(app, name)
        Note over App: view_functions, error handlers,<br/>request/teardown/url/context funcs merged (name-scoped)
    end

    loop over deferred_functions
        BP->>Def: deferred(state)
        Def->>State: state.add_url_rule(rule, endpoint, view_func, ...)
        State->>App: app.add_url_rule(url_prefix+rule, "name.endpoint", view_func)
        App->>App: Rule added to url_map, view_functions[endpoint] = view_func
    end

    Note over App: CLI group attached (concrete Blueprint only —<br/>see blueprints_resources_and_cli)

    loop over _blueprints (nested)
        BP->>BP: compose child url_prefix / subdomain / name_prefix
        BP->>BP: child.register(app, bp_options) - recursion
    end
```

---

## 5. Name & URL Composition Rules

### 5.1 Endpoint and blueprint naming

Blueprint names form a dotted tree; endpoints are always `<full bluepring path>.<endpoint>`:

| Concept | Rule | Example |
|---|---|---|
| Blueprint name | must be non-empty, **no dots** | `Blueprint("admin", __name__)` ✔ |
| Nested name | `f"{name_prefix}.{self_name}".lstrip(".")` | parent `parent`, child `admin` → `parent.admin` |
| `name=` override | rename at registration (same object may appear multiple times) | `app.register_blueprint(bp, name="admin2")` → `admin2.index` |
| Final endpoint | `f"{name_prefix}.{name}.{endpoint}".lstrip(".")` | `admin.index`, `parent.admin.index` |
| Dots in `endpoint` / `view_func.__name__` | rejected in `Blueprint.add_url_rule` (`ValueError`) | protects the `.` separator |
| Duplicate final name | `ValueError("The name '…' is already registered for … Use 'name=' to provide a unique name.")` — message distinguishes *"this"* vs *"a different"* blueprint | both cases covered by `test_unique_blueprint_names` |

### 5.2 Nested blueprint option composition

When a parent `register()` replays its `_blueprints` list, each child's options are **resolved and composed with the parent state** before recursion:

| Option | Child explicit | Resolution |
|---|---|---|
| `subdomain` | set | if parent state also has one → `child + "." + parent` (child domain nested inside parent) |
| | unset | parent state's subdomain, else `None` |
| `url_prefix` | set | if parent state also has one → `parent.rstrip("/") + "/" + child.lstrip("/")` |
| | unset | parent state's prefix, else `None` |
| `name_prefix` | — | always the parent's fully resolved name |
| `cli_group`, `url_defaults`, `name`, … | — | passed through inside `bp_options` for the child's own resolution logic |

Example (`test_nesting_url_prefixes` / `test_nesting_subdomains`):

```python
parent = Blueprint("parent", __name__, subdomain="api")
child  = Blueprint("child", __name__, url_prefix="/items")
parent.register_blueprint(child)
app.register_blueprint(parent, url_prefix="/v1")
# child routes live at /v1/items/... on subdomain "api"
# endpoints: parent.some_view, parent.child.item_view
```

---

## 6. Interaction with the Rest of Flask

```mermaid
flowchart TB
    subgraph Registration["Registration (this module)"]
        REG[Blueprint.register]
    end

    REG -->|app.blueprints name → bp| REGISTRY[(app.blueprints)]
    REG -->|rules via SetupState| UMAP[(app.url_map<br/>Werkzeug Rules)]
    REG -->|name.endpoint| VIEWS[(app.view_functions)]
    REG -->|name-scoped merge| FUNCS[(before/after/teardown funcs,<br/>error_handler_spec, url processors,<br/>template_context_processors)]
    REG -->|record_once closures| JINJA[(app.jinja_env<br/>filters / tests / globals)]
    REG -->|static route| STATIC["name.static static-file route"]
    REG -->|self.cli → app.cli| CLI[(flask CLI groups)]

    subgraph RequestTime["Request time (application-core and contexts)"]
        DISPATCH[full_dispatch_request] -->|request.blueprints chain| FUNCS
        ERRHANDLING[_find_error_handler] --> FUNCS
        BUILD[url_for / inject_url_defaults] --> FUNCS
        TEMPLATES[DispatchingJinjaLoader] --> JINJA
        ROUTEMATCH[URL matching] --> UMAP
        ROUTEMATCH --> VIEWS
    end
```

- **Routing / view dispatch** — rules and view functions land in the app's `url_map` / `view_functions`; dispatching, `url_for` endpoint resolution (including leading-dot relative endpoints) are handled by [application-core](application-core.md).
- **Scoped callbacks** — `preprocess_request`, `process_response`, `do_teardown_request` and template-context handling walk the `request.blueprints` chain (innermost-first, maintained by [contexts](contexts.md)) and look handlers up under the exact names this module produced.
- **Templates** — blueprint `template_folder` loaders are consumed by `DispatchingJinjaLoader`; blueprint-level filters/tests/globals are injected into `app.jinja_env` by `record_once` closures. Details in [templating](templating.md).
- **CLI** — the sansio `register()` contains the generic attachment logic (`cli_group=None` merges commands into the root group; `_sentinel` uses the dotted blueprint name; otherwise the given group name). The `cli` attribute itself (`AppGroup`) is created by the concrete Blueprint in [blueprints_resources_and_cli](blueprints_resources_and_cli.md).
- **Static files** — when `static_folder` is set, a rule `<static_url_path>/<path:filename>` with endpoint `<name>.static` is registered through the setup state; precedence caveats vs. the app's `/static` route are documented in [blueprints_resources_and_cli](blueprints_resources_and_cli.md).

---

## 7. Invariants, Error Conditions & Edge Cases

| Situation | Behavior |
|---|---|
| Empty blueprint `name` | `ValueError` at construction |
| `.` in blueprint `name` | `ValueError` at construction (reserved separator) |
| `bp.register_blueprint(bp)` (self-registration) | `ValueError("Cannot register a blueprint on itself")` |
| Registering under a name already present in `app.blueprints` | `ValueError` — even if it is the *same* object under the *same* name (Flask ≥ 2.1); guidance to use `name=` |
| `endpoint` or view-function name containing `.` in `Blueprint.add_url_rule` | `ValueError` |
| Any `@setupmethod` call after first `register()` | `AssertionError` with actionable message ("Make sure all imports, decorators, functions… are done before registering") |
| Same blueprint registered under two names | `record_once` callbacks run only for the first (guarded by `first_registration` / `first_bp_registration`); routes and scoped handlers are merged per name; app-wide handlers not duplicated |
| Same blueprint object registered twice under the same name | hard error (name collision) |
| Blueprint with no routes | legal — may only contribute callbacks, template functions, or CLI commands |
| First-request guard (app side) | `register_blueprint` is itself a `setupmethod`; after the first request the app refuses new blueprints (`test_no_setup_after_first_request`) |

Two distinct "first" flags drive merge behavior and are worth keeping straight:

- `first_bp_registration` — identity-based: `not any(bp is self for bp in app.blueprints.values())`. `False` when re-registering the *same object* under a new name.
- `first_name_registration` — name-based: the computed dotted name is new to `app.blueprints`.
- `_merge_blueprint_funcs` runs when **either** is `True`, ensuring every name gets its scoped handler entries while object-level one-time work stays one-time.

---

## 8. Extension Points

1. **`make_setup_state` override** — return a `BlueprintSetupState` subclass to customize registration (e.g., to transform rules or inject extra options). This is the sanctioned hook; do not override `register` itself.
2. **`record` / `record_once`** — third-party code can add arbitrary deferred behavior tied to the registration lifecycle.
3. **Naming (`name=`, `name_prefix=`)** — enables registering one blueprint implementation multiple times with distinct URL namespaces (`test_blueprint_renaming`).
4. **Nesting** — `parent.register_blueprint(child, **options)` builds hierarchical applications with composed prefixes/subdomains (`test_nested_blueprint`, `test_nested_callback_order`).

---

## 9. Testing & Verification

Behavioral guarantees described above are exercised in the sibling test module [blueprints_test_suite](blueprints_test_suite.md) (`tests/test_blueprints.py` + `tests/test_apps/blueprintapp`), notably:

- **Deferred semantics:** `test_request_processing`, `test_app_request_processing`, `test_context_processing`, `test_template_global`
- **`record_once` / first-registration semantics:** `test_default_static_max_age`, `test_app_url_processors`
- **Naming:** `test_blueprint_renaming`, `test_unique_blueprint_names`, `test_self_registration`, `test_dotted_name_not_allowed`, `test_empty_name_not_allowed`, `test_endpoint_decorator`, `test_route_decorator_custom_endpoint_with_dots`
- **Nesting:** `test_nested_blueprint`, `test_nesting_url_prefixes`, `test_nested_callback_order`
- **Subdomains:** `test_nesting_subdomains`, `test_child_and_parent_subdomain`
- **Error handlers:** `test_blueprint_specific_error_handling`, `test_blueprint_app_error_handling`, `test_blueprint_specific_user_error_handling`
- **URL machinery:** `test_blueprint_url_defaults`, `test_blueprint_url_processors`, `test_app_url_processors`
- **Assets:** `test_templates_and_static`, `test_templates_list`

Related app-level guarantees (setup freeze, error-handler precedence with blueprint scoping) live in [application-core](application-core.md)'s `application-core_test_suite` (`test_no_setup_after_first_request`, `test_errorhandler_precedence`, `test_inject_blueprint_url_defaults`).

---

## 10. Related Documentation

| Module | Relationship |
|---|---|
| [application-core](application-core.md) | `Flask`/`App`: registration entry point, `add_url_rule`, `url_map`, request dispatch that consumes blueprint-scoped registrations |
| [blueprints_resources_and_cli](blueprints_resources_and_cli.md) | Concrete `flask.blueprints.Blueprint`: CLI `AppGroup`, static file serving, `open_resource` |
| [blueprints_test_suite](blueprints_test_suite.md) | Behavioral specification of this machinery |
| [contexts](contexts.md) | `RequestContext`/`AppContext`: how `request.blueprints` is tracked and consumed at request time |
| [templating](templating.md) | `DispatchingJinjaLoader` & Jinja environment receiving blueprint filters/tests/globals and template folders |
| [command-line-interface](command-line-interface.md) | `flask` CLI consuming blueprint-registered command groups |

---

*Source files: `src/flask/sansio/blueprints.py` (`Blueprint`, `BlueprintSetupState`); supporting behavior referenced from `src/flask/sansio/scaffold.py`, `src/flask/sansio/app.py`, `src/flask/blueprints.py`.*
