# Logging Module (`flask.logging`)

## 1. Overview & Purpose

The `flask.logging` module bridges Flask applications with Python's standard `logging` framework. Its responsibilities are deliberately narrow and focused on **sensible defaults**:

1. **Context-aware stream routing** — Route log output to the active WSGI request's `wsgi.errors` stream when handling a request, falling back to `sys.stderr` otherwise. This is critical in WSGI deployments where `sys.stderr` may be detached, buffered, or captured by the server (e.g. Gunicorn, uWSGI).
2. **Handler detection** — Determine whether a user's own logging configuration already covers the app logger, so Flask only attaches its default handler when *nothing* would otherwise emit the records.
3. **Logger bootstrap** — Provide a lazily-created, per-application logger (`app.logger`) that respects debug mode and never double-configures an already-configured logging setup.

The module lives within the **Runtime Configuration & Diagnostics** family, alongside its sibling `configuration` module (see [configuration.md](configuration.md)); the `DEBUG` config key consumed by `create_logger` originates there.

### Module Contents

| Component | Kind | Responsibility |
|---|---|---|
| `wsgi_errors_stream` | `LocalProxy` to a function | Resolves the best error stream (`wsgi.errors` during a request, else `sys.stderr`) |
| `has_level_handler(logger)` | function | Walks the logger hierarchy to check if any handler would emit records at the logger's effective level |
| `default_handler` | `logging.StreamHandler` | Module-level handler writing to `wsgi_errors_stream` with the standard Flask log format |
| `create_logger(app)` | function | Entry point used by `App.logger`; fetches and configures the application's logger |

Tests live in `tests/test_logging.py` and are described in [§7 Testing](#7-testing).

---

## 2. Architecture

### 2.1 Component Diagram

```mermaid
graph TD
    subgraph flask_logging["flask/logging.py"]
        WES["wsgi_errors_stream<br/>(LocalProxy)"]
        HLH["has_level_handler(logger)"]
        DH["default_handler<br/>StreamHandler(wsgi_errors_stream)"]
        CL["create_logger(app)"]
    end

    subgraph stdlib["Python stdlib"]
        LOG["logging.Logger<br/>hierarchy"]
        SH["logging.StreamHandler"]
        FMT["logging.Formatter"]
    end

    subgraph flask_runtime["Flask runtime"]
        APP["App.logger<br/>(cached_property, sansio/app.py)"]
        REQ["flask.globals.request<br/>(LocalProxy over request ctx)"]
        LOGE["Flask.log_exception /<br/>Flask.handle_exception<br/>(app.py)"]
    end

    subgraph wsgi["WSGI environment"]
        ENV["environ['wsgi.errors']"]
        STDERR["sys.stderr"]
    end

    CL -- "logging.getLogger(app.name)" --> LOG
    CL -- "app.debug → setLevel(DEBUG)" --> LOG
    CL -- "guarded by has_level_handler" --> DH
    HLH -- "walks propagate chain" --> LOG
    DH -- "stream=" --> WES
    DH --> SH
    DH --> FMT
    APP -- "calls once, caches" --> CL
    LOGE -- "self.logger.error(...)" --> APP
    WES -- "request active?" --> ENV
    WES -- "no request" --> STDERR
    WES -. "truthiness check" .-> REQ
```

### 2.2 Dependency Flow

```mermaid
flowchart LR
    subgraph external["External dependencies"]
        WZ["werkzeug.local.LocalProxy"]
        SL["stdlib logging / sys"]
    end
    subgraph this_module["flask.logging (this module)"]
        direction TB
        A["wsgi_errors_stream"]
        B["has_level_handler"]
        C["default_handler"]
        D["create_logger"]
    end
    subgraph sibling_modules["Sibling / related modules"]
        E["flask.globals.request<br/>(Contexts module)"]
        F["App.logger<br/>(Application Core module)"]
        G["Flask.handle_exception / log_exception<br/>(Application Core module)"]
        H["DEBUG config key<br/>(Configuration module)"]
        I["FlaskClient errors_stream<br/>(Testing Support module)"]
    end

    A --> WZ
    A --> E
    A --> SL
    B --> SL
    C --> A
    D --> B
    D --> C
    D --> H
    F --> D
    G --> F
    I -. "injects wsgi.errors into environ" .-> E
```

**Relationships to other documented modules:**

| Related module | Relationship |
|---|---|
| **Application Core & Modular Composition** (`app.py`, `sansio/app.py`) | `App.logger` is a `cached_property` that calls `create_logger(self)` exactly once per app. `Flask.handle_exception` → `Flask.log_exception` write to that logger (see [application_core.md](application_core.md)). |
| **Contexts** (`ctx.py`, `globals.py`) | `wsgi_errors_stream` probes the `request` proxy; a truthy `request` means a `RequestContext` is active, whose environ carries `wsgi.errors` (see [contexts.md](contexts.md)). |
| **Configuration** (`config.py`) | `app.debug` maps to the `DEBUG` config key; `create_logger` raises the logger level to `DEBUG` when it is enabled (see [configuration.md](configuration.md)). |
| **Developer Interface & Testing Tooling** (`testing.py`) | `FlaskClient`/`EnvironBuilder` accept an `errors_stream` argument that populates `environ["wsgi.errors"]` — the mechanism the tests use to capture log output (see [testing_support.md](testing_support.md)). |

---

## 3. Core Components

### 3.1 `wsgi_errors_stream`

```python
@LocalProxy
def wsgi_errors_stream() -> t.TextIO:
    if request:
        return request.environ["wsgi.errors"]
    return sys.stderr
```

A `werkzeug.local.LocalProxy` wrapping a resolver function. Every access re-evaluates the **current** context, which is what makes it safe to bind into a module-level handler at import time:

- **Request active** → returns `request.environ["wsgi.errors"]`, the error stream supplied by the WSGI server (or by a test client). This is where per-request output *should* go in production servers.
- **No request** (CLI commands, startup, teardown) → returns `sys.stderr`.

Because it is a proxy, `wsgi_errors_stream` itself is truthy only when the underlying resolution succeeds; tests use `wsgi_errors_stream._get_current_object()` to compare the *resolved* stream identity.

Referencing from file- or dict-based logging configs without importing: `ext://flask.logging.wsgi_errors_stream`.

### 3.2 `has_level_handler(logger)`

```python
def has_level_handler(logger: logging.Logger) -> bool:
    level = logger.getEffectiveLevel()
    current = logger
    while current:
        if any(handler.level <= level for handler in current.handlers):
            return True
        if not current.propagate:
            break
        current = current.parent
    return False
```

Implements a conservative "would anything actually get logged?" check:

1. Compute the logger's **effective level** (inherited from ancestors if unset).
2. Walk **up** the logger hierarchy (`self → root`), stopping at a logger with `propagate = False`.
3. At each node, a handler qualifies if `handler.level <= effective_level` (i.e. the record wouldn't be filtered out before emission).

A logger with a handler attached but with `propagate=False` and *no* qualifying handler of its own returns `False` — Flask will then attach `default_handler`, ensuring the app is never silently un-logged.

### 3.3 `default_handler`

A module-level singleton:

```python
default_handler = logging.StreamHandler(wsgi_errors_stream)
default_handler.setFormatter(
    logging.Formatter("[%(asctime)s] %(levelname)s in %(module)s: %(message)s")
)
```

- **Stream**: the `wsgi_errors_stream` proxy — resolved *per log record*, so the same handler instance correctly switches between `wsgi.errors` and `sys.stderr` depending on the calling context.
- **Format**: `[2026-01-01 12:00:00,000] ERROR in app: message` — timestamp, level, originating module name, message.

Because it is a singleton shared by all apps that lack their own configuration, handlers added to individual loggers remain distinct even when they all write through the same proxy.

### 3.4 `create_logger(app)`

The integration entry point, invoked lazily by `App.logger` (`src/flask/sansio/app.py`):

```mermaid
flowchart TD
    S([create_logger app]) --> N["logger = logging.getLogger(app.name)"]
    N --> D{"app.debug<br/>and logger.level is unset?"}
    D -- "yes" --> SD["logger.setLevel(logging.DEBUG)"]
    D -- "no" --> H
    SD --> H{"has_level_handler<br/>(logger)?"}
    H -- "yes: user config covers it" --> R["return logger<br/>(no handler added)"]
    H -- "no" --> AD["logger.addHandler(default_handler)"]
    AD --> R
```

Key behaviours:

- **Naming**: the logger name equals `app.name` (the import name; see `App.name` in the application-core module) — one logger per application, not a shared `"flask.app"` logger.
- **Debug mode**: when `app.debug` is `True` and the user has not set an explicit level (`logger.level` falsy, i.e. `NOTSET`/0), the level is raised to `logging.DEBUG`. If a user explicitly set a level, it is never overridden. Note the level is set once at logger creation; it does *not* track later changes to `app.debug`.
- **Handler policy**: add `default_handler` **only** when `has_level_handler` finds no handler anywhere in the hierarchy that would emit at the effective level. This makes Flask cooperate with host applications that pre-configure logging (dictConfig, fileConfig, root handlers).
- **Idempotence**: `App.logger` is a `cached_property`, so `create_logger` runs once; subsequently mutating `app.logger` is fully in the user's control.

---

## 4. Request-Time Logging Flow

The sequence below is what `test_log_view_exception` verifies end-to-end:

```mermaid
sequenceDiagram
    participant C as FlaskClient
    participant W as WSGI environ
    participant V as View function
    participant AppF as Flask.full_dispatch_request
    participant HE as Flask.handle_exception
    participant L as logging.Logger
    participant S as wsgi_errors_stream

    C->>W: GET / (errors_stream=StringIO)
    Note over W: environ["wsgi.errors"] = StringIO
    W->>V: dispatch
    V--xAppF: raises Exception("test")
    AppF->>HE: handle_exception(e)
    Note over HE: PROPAGATE_EXCEPTIONS off<br/>(testing=False, debug=False)
    HE->>L: self.logger.error("Exception on / [GET]", exc_info=...)
    L->>L: default_handler.emit(record)
    L->>S: stream = wsgi_errors_stream
    S-->>L: request.environ["wsgi.errors"] (StringIO)
    L-->>C: "Exception on / [GET]" + traceback written to StringIO
    HE-->>C: 500 InternalServerError response
```

Out-of-request logging (e.g. `before_first_request`, CLI commands via the CLI module) resolves the same handler to `sys.stderr` instead — no configuration change required.

---

## 5. Design Notes

- **Why a proxy instead of a function call in the handler?** `logging.StreamHandler` captures its stream once at construction. Binding the *proxy* lets the single `default_handler` instance resolve the right stream at emit time, per record, across all apps and contexts.
- **Why check the whole hierarchy?** Python's logging propagation means a root-level handler configured by a host process is sufficient; adding Flask's handler anyway would produce duplicate lines. `has_level_handler` walks `propagate` chains to detect this.
- **Why `NOTSET` check with truthiness?** `logging.NOTSET == 0`, so `if app.debug and not logger.level` cleanly expresses "debug is on and the user set no level".
- **No log record filtering / no custom Logger class** — Flask deliberately does not replace Python's logging machinery; it only seeds defaults.

---

## 6. Usage Examples

```python
import logging
from flask import Flask
from flask.logging import wsgi_errors_stream, default_handler

app = Flask(__name__)

# Standard Python logging works as-is:
app.logger.info("boot complete")

# Replace the default handler with a custom one that still respects WSGI streams:
app.logger.removeHandler(default_handler)
handler = logging.StreamHandler(wsgi_errors_stream)
handler.setFormatter(logging.Formatter("%(levelname)s: %(message)s"))
app.logger.addHandler(handler)

# From logging.config.fileConfig / dictConfig:
#   [handler_hand01]
#   args=(ext://flask.logging.wsgi_errors_stream,)
```

## 7. Testing

`tests/test_logging.py` validates the module. The autouse `reset_logging` fixture snapshots and restores `logging.root` handlers/level, clears the `flask_test` app logger, and temporarily unregisters pytest's logging plugin so assertions see only Flask's configuration.

| Test | Scenario | Asserts |
|---|---|---|
| `test_logger` | Plain app | Logger named after the app, level `NOTSET`, exactly `[default_handler]` |
| `test_logger_debug` | `app.debug = True` | Level raised to `DEBUG`, default handler still attached |
| `test_existing_handler` | Root logger has a `StreamHandler` | App logger gets **no** handler (no duplication) |
| `test_wsgi_errors_stream` | Request with custom `errors_stream`, then outside a request | In-request logs go to the client-provided stream; `wsgi_errors_stream` resolves to `sys.stderr` otherwise, and to the stream inside a `test_request_context` |
| `test_has_level_handler` | Handler added/removed on root, `propagate` toggled, handler level raised | Faithfulness of the hierarchy walk (respects `propagate=False`, level comparisons) |
| `test_log_view_exception` | Unhandled view exception, `testing=False` | 500 response; `"Exception on / [GET]"` and the traceback appear in the captured `wsgi.errors` stream |

The client-side `errors_stream=` plumbing exercised by these tests is provided by the testing-support module (`EnvironBuilder`/`FlaskClient`), documented in [testing_support.md](testing_support.md).

---

## 8. Summary

`flask.logging` is a small, foundational diagnostics module implementing a "do no harm" logging strategy:

- One **context-aware stream** (`wsgi_errors_stream`) shared by every default handler,
- One **smart guard** (`has_level_handler`) preventing duplicate or missing handlers,
- One **bootstrap function** (`create_logger`) invoked lazily through `App.logger`.

It cooperates with (rather than replaces) standard logging configuration, adapts automatically between WSGI servers and plain stderr, and is fully covered by `tests/test_logging.py`.
