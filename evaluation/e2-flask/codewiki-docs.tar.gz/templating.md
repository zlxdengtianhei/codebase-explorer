# Templating Module (`flask.templating`)

> Parent module: [Request Services & Response Rendering](Request_Services___Response_Rendering.md) — siblings: [helpers](helpers.md), [sessions](sessions.md), [json-serialization](json-serialization.md)

## 1. Introduction & Purpose

The **templating module** is Flask's bridge to the [Jinja2](https://palletsprojects.com/p/jinja/) template engine. It adapts Jinja2's `Environment`/loader machinery to Flask's world so that:

- **Templates can live anywhere** — in the application's `templates/` folder *and* in the `templates/` folder of every registered [blueprint](blueprints.md), with transparent, predictable lookup precedence.
- **Templates automatically receive Flask state** — `request`, `session`, `g` (via context processors) and `config`, `url_for`, `get_flashed_messages` (via environment globals) — without any boilerplate in views.
- **Rendering is context- and signal-aware** — every render runs inside Flask's application/request [contexts](contexts.md) and emits the `before_render_template` / `template_rendered` signals.
- **Rendering integrates with responses** — a rendered string is returned by a view and converted to a `Response` by `make_response` (see [application core](application-core.md)), and generators produced by streaming templates become streaming responses.
- **Behavior is configurable** — `TEMPLATES_AUTO_RELOAD`, `EXPLAIN_TEMPLATE_LOADING`, `jinja_options`, and per-extension autoescaping (see [configuration](configuration.md)).

The module is intentionally small (`src/flask/templating.py`, ~230 lines): it composes existing Jinja2 primitives with the [Flask application core](application-core.md) rather than reimplementing them.

### Public API at a glance

| Symbol | Kind | Purpose |
|---|---|---|
| `render_template(name_or_list, **ctx)` | function | Render a template file to a `str`. A list means "first existing template wins". |
| `render_template_string(source, **ctx)` | function | Render an inline template source string to a `str`. |
| `stream_template(name_or_list, **ctx)` | function | Render as a lazy `Iterator[str]` for streaming responses (since 2.2). |
| `stream_template_string(source, **ctx)` | function | Stream-render an inline source string (since 2.2). |
| `Environment` | class | Flask-aware subclass of `jinja2.Environment`; `app.jinja_environment` default. |
| `DispatchingJinjaLoader` | class | Loader that dispatches between the app loader and all blueprint loaders. |
| `_default_template_ctx_processor` | function (private) | Injects `request`, `session`, `g` into every template context. |

Related helpers live elsewhere: `get_template_attribute` and `stream_with_context` in [helpers](helpers.md); `before_render_template` / `template_rendered` in `flask.signals`; `context_processor`, `template_filter`, `template_test`, `template_global` registration methods on the app in the [application core](application-core.md).

## 2. Architecture Overview

```mermaid
flowchart TB
    subgraph Views["View layer (app / blueprints)"]
        V["view function returns<br/>render_template(...)"]
    end

    subgraph Templating["flask/templating.py (this module)"]
        RT["render_template<br/>render_template_string"]
        ST["stream_template<br/>stream_template_string"]
        RENDER["_render / _stream<br/>(context + signals + render)"]
        ENV["Environment<br/>(extends jinja2.Environment)"]
        DJL["DispatchingJinjaLoader<br/>(extends jinja2.BaseLoader)"]
        DCP["_default_template_ctx_processor"]
    end

    subgraph AppCore["Application core (see application-core.md)"]
        APP["Flask / sansio App"]
        CJE["create_jinja_environment()"]
        GJL["create_global_jinja_loader()"]
        UTC["update_template_context()"]
        TCP["template_context_processors<br/>{None: [DCP, ...user processors]}"]
    end

    subgraph ScaffoldM["Scaffold & Blueprints"]
        JL["Scaffold.jinja_loader<br/>(FileSystemLoader on template_folder)"]
        BP["app.iter_blueprints()"]
    end

    subgraph CtxM["Contexts (see contexts.md)"]
        ACTX["AppContext → g"]
        RCTX["RequestContext → request, session"]
    end

    subgraph Support["Supporting modules"]
        SIG["signals: before_render_template,<br/>template_rendered"]
        SWC["helpers.stream_with_context"]
        DBG["debughelpers.explain_template_loading_attempts"]
    end

    V --> RT
    V --> ST
    RT --> RENDER
    ST --> RENDER
    RT -->|"app.jinja_env.get_or_select_template"| ENV
    ST -->|"app.jinja_env.get_or_select_template"| ENV
    RENDER --> UTC
    RENDER --> SIG
    ST --> SWC
    CJE -->|"instantiates"| ENV
    CJE -->|"options[loader]"| GJL
    GJL -->|"creates"| DJL
    ENV -->|"self.app"| APP
    DJL -->|"queries"| JL
    DJL -->|"iterates"| BP
    DJL -.->|"EXPLAIN_TEMPLATE_LOADING"| DBG
    UTC --> TCP
    TCP --> DCP
    DCP --> ACTX
    DCP --> RCTX
    ENV -.->|"globals: url_for, config,<br/>request, session, g"| APP
    ENV -.->|"policies: json.dumps_function"| APP
```

### Component responsibilities

| Component | Responsibility |
|---|---|
| `Environment` | One Jinja environment per app (`app.jinja_env`, lazily created by `create_jinja_environment`). Supplies the Flask-aware defaults: `DispatchingJinjaLoader`, `select_jinja_autoescape`, `auto_reload` from `TEMPLATES_AUTO_RELOAD`/`debug`, Jinja globals (`url_for`, `config`, `request`, `session`, `g`, `get_flashed_messages`) and the `json.dumps_function` policy powering the `tojson` filter (see [json-serialization](json-serialization.md)). |
| `DispatchingJinjaLoader` | The environment's loader. Resolves a template name by trying, in order, the app's `jinja_loader` and then every registered blueprint's `jinja_loader`. Supports fast path (first match) and "explained" path (log every attempt) driven by `EXPLAIN_TEMPLATE_LOADING`. |
| `_default_template_ctx_processor` | Registered as the first entry of `app.template_context_processors[None]` by `Scaffold.__init__`. Pulls `g` from the active [app context](contexts.md) and `request`/`session` from the active [request context](contexts.md) at render time — cheaper and always-current compared to static globals. |
| `render_template` / `render_template_string` | Public entry points. Fetch a `Template` from `app.jinja_env`, delegate to `_render`. |
| `_render` | `app.update_template_context(context)` → `before_render_template` signal → `template.render(context)` → `template_rendered` signal → returns `str`. |
| `stream_template` / `stream_template_string` / `_stream` | Same as above but return an iterator via `template.generate`; the iterator is wrapped in `stream_with_context` (from [helpers](helpers.md)) when a request is active so the generator can keep using `request`/`g` while the response streams. |

## 3. Render Lifecycle

```mermaid
sequenceDiagram
    autonumber
    participant V as View function
    participant RT as render_template
    participant E as app.jinja_env<br/>(Environment)
    participant L as DispatchingJinjaLoader
    participant U as update_template_context
    participant S as Signals
    participant J as Jinja2

    V->>RT: "mail.html", user=u
    RT->>RT: current_app._get_current_object()
    RT->>E: get_or_select_template("mail.html")
    E->>L: get_source(env, "mail.html")
    L->>L: try app.jinja_loader,<br/>then each blueprint.jinja_loader
    L-->>E: (source, path, uptodate)
    E-->>RT: Template
    RT->>U: update_template_context(ctx)
    U->>U: app-level processors, then<br/>blueprint processors (reversed path)
    Note over U: user-passed kwargs win:<br/>orig_ctx re-applied last
    U-->>RT: ctx + g, request, session, custom vars
    RT->>S: before_render_template.send(app, template, ctx)
    RT->>J: template.render(ctx)
    J-->>RT: str
    RT->>S: template_rendered.send(app, template, ctx)
    RT-->>V: rendered string
    Note over V: make_response() converts the string<br/>to a Response (application-core.md)
```

## 4. Template Resolution & Context Injection

**Resolution order** (`DispatchingJinjaLoader._iter_loaders`): the application's `jinja_loader` first, then the loaders of all blueprints in registration order. The first successful `get_source` wins (`_get_source_fast`); if `EXPLAIN_TEMPLATE_LOADING` is enabled, `_get_source_explained` tries *every* loader and logs a report (including hints about blueprint-relative lookups) via `explain_template_loading_attempts` from [debug helpers](application-core_debug-helpers.md).

```mermaid
flowchart TD
    A["get_source(env, name)"] --> B{"config<br/>EXPLAIN_TEMPLATE_LOADING?"}
    B -- "True" --> C["_get_source_explained<br/>try all loaders, collect attempts,<br/>log report, return first match"]
    B -- "False (default)" --> D["_get_source_fast<br/>return on first match"]
    C --> E{"any loader matched?"}
    D --> E
    E -- yes --> F["(source, filename, uptodate)"]
    E -- no --> G["raise TemplateNotFound"]
    C -.-> H["debughelpers.<br/>explain_template_loading_attempts()"]
```

**Context assembly** (`Flask.update_template_context`, [application core](application-core.md)) runs processors in this order, with explicit `render_template(**kwargs)` always taking precedence:

1. `_default_template_ctx_processor` — `g` (app context), `request`, `session` (request context; omitted if no request is active, which enables request-less rendering under `app.app_context()`).
2. App-level processors registered with `@app.context_processor` / `Blueprint.app_context_processor`.
3. Blueprint-scoped processors, walking the current request's blueprint path from outermost to innermost (`reversed(request.blueprints)`).
4. The caller's explicit keyword arguments, re-applied last so they can never be overridden.

## 5. Sub-modules

The module splits into three cohesive areas, documented in the following generated files (all links are relative to this flat documentation directory):

1. **[templating_environment_loader.md](templating_environment_loader.md) — Template Environment & Dispatching Loader**
   How the single `Environment` per app is created (`create_jinja_environment`, `jinja_options`, autoescape, auto-reload, Jinja globals and the `tojson` policy), and how `DispatchingJinjaLoader` resolves template names across the application and every blueprint, including the `EXPLAIN_TEMPLATE_LOADING` diagnostics path and custom loader substitution.
   Covered by: `test_custom_jinja_env`, `test_custom_template_loader`, `test_iterable_loader`, `test_templates_auto_reload`, `test_templates_auto_reload_debug_run`, `test_template_loader_debugging`.

2. **[templating_rendering_context.md](templating_rendering_context.md) — Rendering & Template Context**
   The four public entry points (`render_template`, `render_template_string`, `stream_template`, `stream_template_string`), the `_render`/`_stream` pipeline with `before_render_template`/`template_rendered` signals, the `_default_template_ctx_processor` context-injection chain (`g`, `request`, `session`), autoescaping behavior, and streaming with `stream_with_context`.
   Covered by: `test_context_processing`, `test_standard_context`, `test_original_win`, `test_request_less_rendering`, `test_simple_stream`, `test_escaping`, `test_no_escaping`, `test_escaping_without_template_filename`, `test_macros`.

3. **[templating_customization.md](templating_customization.md) — Jinja Customization (filters, tests, globals)**
   Extending the environment from application and blueprint code via `template_filter` / `add_template_filter`, `template_test` / `add_template_test`, and `template_global` / `add_template_global` (implemented on the app class in [application-core](application-core.md)), including naming rules and the first-request setup guard.
   Covered by: `test_template_filter*`, `test_add_template_filter*`, `test_template_test*`, `test_add_template_test*`, `test_add_template_global`.

Navigation: [templating_environment_loader.md](templating_environment_loader.md) · [templating_rendering_context.md](templating_rendering_context.md) · [templating_customization.md](templating_customization.md)

## 6. Configuration Options

| Option | Effect on this module | Default |
|---|---|---|
| `TEMPLATES_AUTO_RELOAD` | Sets `jinja_env.auto_reload`; `None` falls back to `app.debug`. Verified by `test_templates_auto_reload` / `test_templates_auto_reload_debug_run`. | `None` |
| `EXPLAIN_TEMPLATE_LOADING` | Switches `DispatchingJinjaLoader` to the verbose `_get_source_explained` path, logging every loader attempt to `app.logger`. | `False` |
| `jinja_options` | Dict merged into the environment at creation time (e.g. `autoescape`, custom extensions). Changes after first `app.jinja_env` access have no effect. | `{}` |
| `jinja_environment` | Class attribute used by `create_jinja_environment`; override with a `templating.Environment` subclass (see `test_custom_jinja_env`). | `flask.templating.Environment` |
| `template_folder` (constructor) | Root of the per-app / per-blueprint `FileSystemLoader` provided by `Scaffold.jinja_loader`. | `"templates"` (app), `None` (blueprint) |

Full config semantics are covered in [configuration](configuration.md) (Runtime_Configuration___Diagnostics).

## 7. Integration with Other Modules

- **[Application core](application-core.md)** — `Flask.create_jinja_environment` builds the `Environment`; `Flask.update_template_context` orchestrates context processors; `Flask.select_jinja_autoescape` controls autoescaping (`True` by default for `.html`, `.htm`, `.xml`, `.xhtml`, `.svg`, and always when no filename is known — see `render_template_string`); the `setupmethod` guard prevents registering filters/processors after the first request. Rendering failures surface through the standard error-handling machinery.
- **[Contexts](contexts.md)** — rendering requires at least an *application context* (`current_app`); the default context processor additionally reads the *request context*. `stream_with_context` (helpers) re-anchors the request context around a streaming generator.
- **[Blueprints](blueprints.md)** — each blueprint contributes a `jinja_loader` scoped to its own `template_folder`; `DispatchingJinjaLoader` unions them. Blueprint template resolution rules and the `EXPLAIN_TEMPLATE_LOADING` hints are exercised in the blueprint test suite.
- **[Helpers](helpers.md)** — `stream_with_context` powers streaming templates; `get_template_attribute` renders a macro/attribute out of a template (`test_macros`).
- **[Sessions](sessions.md)** — the `session` object injected into templates is the proxy from the request context (see `test_standard_context`).
- **[JSON serialization](json-serialization.md)** — `Environment` binds `policies["json.dumps_function"] = app.json.dumps`, so the Jinja `tojson` filter uses the app's JSON provider (verified by `test_tojson_filter`).
- **[Signals](contexts.md) / Testing** — `before_render_template` and `template_rendered` are asserted on in `tests/test_signals.py` (`test_before_render_template`, `test_template_rendered`), which is also the idiomatic way to unit-test that a template rendered.
- **[Debug helpers](application-core_debug-helpers.md)** — `explain_template_loading_attempts` produces the per-loader diagnostic report.
- **[Testing support](testing-support.md)** — the `app`, `app_ctx`, `req_ctx`, and `client` fixtures from [test infrastructure](test-infrastructure.md) drive `tests/test_templating.py`, including request-less rendering (`test_request_less_rendering`) and debug-run auto-reload (`test_templates_auto_reload_debug_run`).

## 8. Test Coverage Map

`tests/test_templating.py` pins down every behavior of this module:

| Behavior | Tests |
|---|---|
| Blueprint-aware template lookup, custom loaders, auto-reload, loading diagnostics | `test_custom_jinja_env`, `test_custom_template_loader`, `test_iterable_loader`, `test_templates_auto_reload`, `test_templates_auto_reload_debug_run`, `test_template_loader_debugging` |
| Context processors, injected globals, escaping, macros, streaming | `test_context_processing`, `test_standard_context`, `test_original_win`, `test_request_less_rendering`, `test_simple_stream`, `test_escaping`, `test_no_escaping`, `test_escaping_without_template_filename`, `test_macros` |
| Custom Jinja filters / tests / globals registration | `test_template_filter*`, `test_add_template_filter*`, `test_template_test*`, `test_add_template_test*`, `test_add_template_global` |

Cross-module assertions live in `tests/test_signals.py` (`test_template_rendered`, `test_before_render_template`), `tests/test_blueprints.py` (`test_context_processing`, `test_app_request_processing`, `test_template_filter*`, `test_template_test*`, `test_templates_and_static`, `test_templates_list`), and `tests/test_basic.py` (`test_static_files` for the sibling static-file loader concept).
