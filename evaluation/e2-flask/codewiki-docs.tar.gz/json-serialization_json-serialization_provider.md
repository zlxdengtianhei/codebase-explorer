# JSON Serialization Provider (`src/flask/json/provider.py`)

## 1. Introduction

The **json-serialization_provider** module implements Flask's pluggable JSON engine, introduced in Flask 2.2. It decouples *what* JSON operations exist (`dumps`, `loads`, `dump`, `load`, `response`) from *how* they are performed, by wrapping them behind a single provider object attached to every application as `app.json`.

- **`JSONProvider`** — the abstract-ish contract: a standard set of JSON operations, with a weak reference back to the owning application. Subclasses must implement at least `dumps` and `loads`; everything else has a working default.
- **`DefaultJSONProvider`** — the concrete implementation built on Python's built-in `json` module, extending serialization to dates, decimals, UUIDs, dataclasses, and HTML-safe objects via the module-level `_default` hook.
- **`_default`** — the default "unknown type" serializer consulted by `json.dumps`, defining Flask's canonical type-to-JSON conversions (e.g., `datetime` → RFC 822 HTTP date string).

Because every JSON operation in Flask routes through `current_app.json`, applications (and extensions) can swap the entire JSON layer — even for a third-party library like `ujson` or `orjson` — without touching view code. This module is the leaf of the larger [JSON Serialization](json-serialization.md) subsystem within [Request Services & Response Rendering](Request_Services___Response_Rendering.md).

---

## 2. Position in the Overall Architecture

The provider sits at the intersection of the application object ([Core Application Engine](Core_Application_Engine___Modular_Composition.md)) and every Flask feature that emits or consumes JSON: `jsonify`, request body parsing, Jinja's `tojson` filter ([Templating](templating_rendering_context.md)), and file-based JSON I/O. Sessions use the related tagging serializer instead — see [JSON Serialization Tagging](json-serialization_tag.md).

```mermaid
flowchart TB
    subgraph appmod["Core Application Engine (src/flask/sansio/app.py)"]
        App["Flask / sansio App"]
        jsonProvClass["json_provider_class = DefaultJSONProvider"]
        appJson["app.json : JSONProvider (instance)"]
    end

    subgraph provider["json-serialization_provider (this module)"]
        JSONProvider["JSONProvider (base contract)"]
        DefaultJSONProvider["DefaultJSONProvider (stdlib json)"]
        DefaultFn["_default() type hook"]
    end

    subgraph jsonapi["flask.json public API (flask/json/__init__.py)"]
        jsonify["jsonify()"]
        dumpsLoads["dumps() / loads() / dump() / load()"]
    end

    subgraph consumers["Consumers"]
        Request["request.get_json() parsing"]
        Templating["Jinja tojson filter (templating module)"]
        AppCode["View / extension code"]
    end

    subgraph external["External dependencies"]
        Stdlib["stdlib json module"]
        Werkzeug["werkzeug.http.http_date"]
        Response["Response class (werkzeug/flask)"]
    end

    jsonProvClass -->|"instantiated in App.__init__"| appJson
    appJson -->|"is a"| JSONProvider
    DefaultJSONProvider -->|"inherits"| JSONProvider
    DefaultJSONProvider -->|"default serializer"| DefaultFn

    jsonify -->|"current_app.json.response()"| JSONProvider
    dumpsLoads -->|"current_app.json.dumps/loads()"| JSONProvider
    Request -->|"current_app.json.loads()"| JSONProvider
    Templating -->|"jinja policy json.dumps_function = app.json.dumps"| JSONProvider

    AppCode --> jsonify
    AppCode --> dumpsLoads

    DefaultJSONProvider --> Stdlib
    DefaultFn --> Werkzeug
    JSONProvider -->|"response_class(...)"| Response
```

**Key wiring (from `src/flask/sansio/app.py`):**

```python
class App(Scaffold):
    json_provider_class: type[JSONProvider] = DefaultJSONProvider
    # ... in __init__:
    self.json: JSONProvider = self.json_provider_class(self)
```

The provider receives the app in its constructor and stores it as a **`weakref.proxy`** (`self._app`), so a provider never prevents the application from being garbage-collected.

---

## 3. Component Reference

### 3.1 Class Structure

```mermaid
classDiagram
    class JSONProvider {
        <<contract, versionadded 2.2>>
        +App _app  (weakref.proxy)
        +__init__(app)
        +dumps(obj, **kwargs)* str
        +loads(s, **kwargs)* Any
        +dump(obj, fp, **kwargs) None
        +load(fp, **kwargs) Any
        +response(*args, **kwargs) Response
        -_prepare_response_obj(args, kwargs) Any
    }
    class DefaultJSONProvider {
        +default: Callable = _default
        +ensure_ascii = True
        +sort_keys = True
        +compact: bool~None~ = None
        +mimetype = "application/json"
        +dumps(obj, **kwargs) str
        +loads(s, **kwargs) Any
        +response(*args, **kwargs) Response
    }
    class _default {
        <<module function>>
        date/datetime --> http_date(o)
        Decimal/UUID --> str(o)
        dataclass --> dataclasses.asdict(o)
        __html__ --> str(o.__html__())
        otherwise --> TypeError
    }
    class CustomProvider {
        <<user subclass>>
        override dumps/loads for another library
    }
    class FlaskApp {
        <<flask.Flask>>
        +json_provider_class
        +json : JSONProvider
        +debug : bool
        +response_class
    }

    JSONProvider <|-- DefaultJSONProvider : extends
    JSONProvider <|-- CustomProvider : user extension
    DefaultJSONProvider ..> _default : uses as default=
    FlaskApp o-- JSONProvider : app.json
    FlaskApp ..> DefaultJSONProvider : json_provider_class
```

### 3.2 `JSONProvider` — the base contract

| Member | Kind | Description |
|---|---|---|
| `__init__(app)` | method | Stores the app as `weakref.proxy` on `_app`. |
| `dumps(obj, **kwargs)` | **abstract** | Serialize to a `str`. Raises `NotImplementedError`. |
| `loads(s, **kwargs)` | **abstract** | Deserialize `str`/UTF-8 `bytes`. Raises `NotImplementedError`. |
| `dump(obj, fp, **kwargs)` | default | Writes `dumps(obj)` to a text file opened as UTF-8. |
| `load(fp, **kwargs)` | default | Reads the file and returns `loads(...)`. |
| `response(*args, **kwargs)` | default | Normalizes arguments via `_prepare_response_obj`, then wraps `dumps` in `self._app.response_class(..., mimetype="application/json")`. This is what [`flask.jsonify`](json-serialization.md) calls. |
| `_prepare_response_obj(args, kwargs)` | helper | Argument normalization for `response()` (see below). |

**Response argument rules (`_prepare_response_obj`):**

| Call | Serialized value |
|---|---|
| `response()` | `None` |
| `response(v)` | `v` (single positional) |
| `response(a, b, ...)` | tuple `(a, b, ...)` → JSON array |
| `response(k1=v1, k2=v2)` | dict `{k1: v1, k2: v2}` |
| `response(a, k=v)` | raises `TypeError` ("takes either args or kwargs, not both") |

### 3.3 `DefaultJSONProvider` — stdlib-based implementation

Configuration is expressed as **class attributes**, so a subclass only overrides what it needs:

| Attribute | Default | Effect |
|---|---|---|
| `default` | `staticmethod(_default)` | Applied by `json.dumps` to objects it cannot serialize. |
| `ensure_ascii` | `True` | Escapes non-ASCII characters (`"\u2603"`). Disabling improves size/performance. |
| `sort_keys` | `True` | Deterministic key ordering (caching-friendly). Keys must be strings when enabled. |
| `compact` | `None` | `None` → compact unless `app.debug`; `False` → always pretty; `True` → always compact. |
| `mimetype` | `"application/json"` | Mimetype of responses built by `response()`. |

- `dumps()` injects `default`, `ensure_ascii`, `sort_keys` as `setdefault` kwargs (callers can still override per call) and delegates to `json.dumps`.
- `loads()` delegates to `json.loads` — accepting text or UTF-8 bytes.
- `response()` applies the compact/pretty policy and **appends a trailing newline** to the payload:

```python
if (self.compact is None and self._app.debug) or self.compact is False:
    dump_args.setdefault("indent", 2)
else:
    dump_args.setdefault("separators", (",", ":"))

return self._app.response_class(
    f"{self.dumps(obj, **dump_args)}\n", mimetype=self.mimetype
)
```

```mermaid
flowchart TD
    A["DefaultJSONProvider.response(obj)"] --> B{"compact is False OR<br/>(compact is None AND app.debug)?"}
    B -- "Yes: pretty output" --> C["dump_args['indent'] = 2"]
    B -- "No: compact output" --> D["dump_args['separators'] = (',', ':')"]
    C --> E["dumps(obj, default=_default,<br/>ensure_ascii, sort_keys, **dump_args)"]
    D --> E
    E --> F["response_class(json + newline,<br/>mimetype = self.mimetype)"]
```

### 3.4 `_default` — the canonical type conversions

The fallback serializer used for any object `json.dumps` does not natively handle (and the natural extension point for custom types):

| Python type | JSON representation |
|---|---|
| `datetime.datetime` / `datetime.date` | RFC 822/1123 HTTP date string via `werkzeug.http.http_date` (e.g., `"Mon, 01 Feb 2021 07:15:00 GMT"`, aware datetimes normalized to GMT) |
| `decimal.Decimal` | string, e.g. `"0.003"` |
| `uuid.UUID` | string form |
| `@dataclasses.dataclass` instance | dict via `dataclasses.asdict` |
| object with `__html__()` (e.g. `markupsafe.Markup`) | string result of `o.__html__()` |
| anything else | raises `TypeError: Object of type <T> is not JSON serializable` |

---

## 4. Data Flows

### 4.1 Outbound: a view returning JSON

```mermaid
sequenceDiagram
    autonumber
    participant V as View function
    participant F as flask.jsonify
    participant P as app.json (DefaultJSONProvider)
    participant J as json.dumps
    participant W as werkzeug http_date
    participant R as Response

    V->>F: return jsonify(payload)
    F->>P: response(payload)  [current_app.json]
    P->>P: _prepare_response_obj(args, kwargs)
    P->>P: choose indent=2 (debug/pretty) or separators (compact)
    P->>J: dumps(obj, default=_default, ensure_ascii, sort_keys, ...)
    alt obj contains date/datetime
        J->>W: http_date(value)
        W-->>J: "Sun, 11 Mar 1973 06:30:45 GMT"
    else obj contains Decimal / UUID / dataclass / __html__
        J->>J: _default converts to str / dict
    end
    J-->>P: JSON string
    P->>R: response_class(json_string + "\n", mimetype="application/json")
    R-->>V: JSON response (mimetype "application/json")
```

### 4.2 Inbound: parsing a JSON request body

```mermaid
sequenceDiagram
    autonumber
    participant V as View function
    participant Req as flask.request.get_json()
    participant P as app.json.loads()
    participant J as json.loads

    V->>Req: get_json()
    Req->>P: loads(body_bytes_or_str)
    P->>J: json.loads(s)
    alt valid JSON
        J-->>P: Python object
        P-->>V: parsed data
    else malformed body
        J-->>Req: JSONDecodeError → 400 Bad Request
        Note over Req: Debug mode appends the detail message<br/>Failed to decode JSON object<br/>non-debug returns a generic 400
    end
```

### 4.3 Jinja `tojson` filter (template → safe JavaScript)

In `Flask.create_jinja_environment` the app registers its provider's `dumps` as Jinja's JSON policy:

```python
rv.policies["json.dumps_function"] = self.json.dumps
```

This guarantees templates and Python produce **byte-identical JSON**: the same `_default` conversions (datetimes → HTTP dates) and the same `ensure_ascii=True` escaping, which safely escapes `</script>` inside `<script>` blocks (verified by `test_tojson_filter`).

### 4.4 Standalone use without an app context

[`flask.json.dumps` / `loads`](json-serialization.md) prefer `current_app.json.*` when an application context is active, and transparently fall back to the stdlib `json` module — with `_default` still injected for `dumps` — so utilities remain usable outside request/app contexts.

---

## 5. Customization Guide

Two interchangeable mechanisms (both shown in `test_json_customization`):

**A. At class-definition time (affects all instances):**

```python
class CustomProvider(DefaultJSONProvider):
    def object_hook(self, obj):
        if len(obj) == 1 and "_foo" in obj:
            return X(obj["_foo"])
        return obj

    def loads(self, s, **kwargs):
        kwargs.setdefault("object_hook", self.object_hook)
        return super().loads(s, **kwargs)

class MyApp(Flask):
    json_provider_class = CustomProvider
```

**B. Per-instance (after app creation):**

```python
app.json = CustomProvider(app)

def default(o):
    if isinstance(o, X):
        return f"<{o.val}>"
    return DefaultJSONProvider.default(o)   # chain to Flask's conversions

app.json.default = default
```

Checklist for a fully custom provider (e.g., backed by `orjson`):

1. Subclass `JSONProvider` and implement **`dumps`** and **`loads`** (the only abstract methods).
2. Reuse/override `response()` — or override `mimetype`/`compact` attributes if subclassing `DefaultJSONProvider`.
3. Keep a `_default`-style hook so domain types (datetimes, UUIDs, dataclasses) still serialize, or define library-specific equivalents.
4. Remember the weakref app proxy: all app access goes through `self._app` (e.g., `self._app.response_class`, `self._app.debug`).

---

## 6. Design Notes

- **Weak reference by design.** `JSONProvider.__init__` stores `weakref.proxy(app)` rather than a strong reference, keeping the app/provider lifetime decoupled and avoiding reference cycles (consistent with Flask's refcount hygiene tests such as `test_app_freed_on_zero_refcount` in the application-core suite).
- **Behavior as class attributes.** `ensure_ascii`, `sort_keys`, `compact`, `mimetype`, and `default` are overridable attributes rather than constructor flags, enabling minimal one-line subclasses and runtime mutation (`app.json.ensure_ascii = False` — see `test_json_as_unicode`).
- **Single source of truth.** `jsonify`, request parsing, the Jinja `tojson` policy, and standalone `flask.json` helpers all funnel through the same instance, so output escaping and type conversion rules cannot diverge between paths.
- **Debug-aware formatting.** Pretty-printing is tied to `app.debug` (via the weakref app proxy) unless `compact` explicitly forces a mode.

---

## 7. Testing

Test coverage lives in `tests/test_json.py` (shared with the parent [json-serialization](json-serialization.md) module); round-trip and tag-related tests are in [json-serialization_tag](json-serialization_tag.md).

| Test | What it verifies |
|---|---|
| `test_jsonify_dicts` | Positional-dict and `**kwargs` produce equivalent JSON responses with `application/json` mimetype. |
| `test_jsonify_aware_datetimes` | Timezone-aware datetimes are normalized to GMT and emitted as RFC 822 strings (e.g., PST/KST offsets → `"GMT"`). |
| `test_json_customization` | End-to-end custom provider: subclassing `DefaultJSONProvider`, `object_hook` on `loads`, and a chained custom `default` for unknown types. |
| `test_tojson_filter` | Jinja's `tojson` uses `app.json.dumps` — `</script>` escaped via `ensure_ascii`, datetime rendered as an HTTP date. |
| `test_json_key_sorting` | `sort_keys = True` yields deterministic (string-sorted) key order in pretty (debug) responses. |
| `test_bad_request_debug_message` | Malformed JSON bodies yield 400; the detailed "Failed to decode JSON object" message appears **only** when `app.debug` is on. |

Complementary tests in the same file (beyond this module's core six) cover basic/UUID/Decimal serialization, `dump`/`load` to files, `ensure_ascii` toggling, and `__html__` objects (`test_html_method`).

---

## 8. Related Documentation

- [JSON Serialization (parent module)](json-serialization.md) — the `flask.json` facade (`jsonify`, `dumps`, `loads`, `dump`, `load`) that delegates to this provider.
- [JSON Serialization Tagging](json-serialization_tag.md) — `TaggedJSONSerializer` and `JSONTag` classes used by sessions for non-JSON-native cookie values.
- [Core Application Engine](Core_Application_Engine___Modular_Composition.md) — `Flask`/`App` construction that instantiates the provider (`json_provider_class`, `app.json`, `response_class`, `debug`).
- [Request Services & Response Rendering](Request_Services___Response_Rendering.md) — sibling services: helpers, sessions, and templating (whose `tojson` policy binds to `app.json.dumps`).
