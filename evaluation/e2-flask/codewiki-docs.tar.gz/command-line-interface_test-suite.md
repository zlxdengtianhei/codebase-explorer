# Command-Line Interface Test Suite (`command-line-interface_test-suite`)

## 1. Overview

The `command-line-interface_test-suite` module is the pytest verification layer for Flask's command-line interface (CLI). It validates every externally observable behavior of the `flask` command: application discovery and import resolution, `FlaskGroup` context management, the built-in `run`, `shell`, and `routes` commands, environment-file (dotenv) loading, certificate/SSL option validation, error reporting, and blueprint CLI registration.

The module consists of three files:

| File | Role |
| --- | --- |
| `tests/test_cli.py` | The primary test module: fixtures, helper classes, and ~40 test functions/parametrized cases. |
| `tests/test_apps/cliapp/factory.py` | A synthetic app-factory module used to exercise factory-based app discovery (`create_app`, `create_app2(foo, bar)`, `no_app`). |
| `tests/test_apps/helloworld/hello.py` | A minimal module-level Flask app (`app = Flask(__name__)`) used to verify the conventional `wsgi.py`/`app.py` auto-discovery path. |

The code under test lives in [command-line-interface](command-line-interface.md) (`src/flask/cli.py`); this module does **not** contain production code — its entire purpose is to pin down the CLI contract so that refactors of `src/flask/cli.py` cannot silently change user-facing behavior.

---

## 2. Architecture and Position in the System

### 2.1 Dependency view

The test suite sits at the bottom of the `Developer_Interface___Testing_Tooling` branch of the module tree. It consumes:

- **Code under test** — [command-line-interface](command-line-interface.md), specifically its sub-modules:
  - [command-line-interface_app-discovery](command-line-interface_app-discovery.md) (`ScriptInfo`, `_set_app`)
  - [command-line-interface_cli-framework](command-line-interface_cli-framework.md) (`FlaskGroup`)
  - [command-line-interface_built-in-commands](command-line-interface_built-in-commands.md) (`run_command`, `shell_command`, `routes_command`, `CertParamType`, `_validate_key`)
  - [command-line-interface_environment-config](command-line-interface_environment-config.md) (`_env_file_callback`, `_set_debug`, `_path_is_ancestor`)
- **Test support tooling** — [testing-support](testing-support.md) (`FlaskCliRunner` is used implicitly via `app.test_cli_runner()`)
- **Shared test infrastructure** — [test-infrastructure](test-infrastructure.md) (`tests/conftest.py` provides the `app`, `test_apps`, and environment-resetting fixtures)

```mermaid
flowchart LR
    subgraph SUITE["command-line-interface_test-suite"]
        TC["tests/test_cli.py<br/>(fixtures + test cases)"]
        TA["tests/test_apps/*<br/>(cliapp.factory, helloworld.hello)"]
    end

    subgraph CLI["command-line-interface (code under test)"]
        DISC["App discovery<br/>find_best_app / locate_app / prepare_import"]
        SI["ScriptInfo"]
        FG["FlaskGroup / AppGroup"]
        CMDS["run / shell / routes commands"]
        CERT["CertParamType / _validate_key"]
        ENV["load_dotenv / FLASK_SKIP_DOTENV"]
        VER["get_version"]
        WAC["with_appcontext"]
    end

    subgraph INFRA["test-infrastructure"]
        CONF["tests/conftest.py<br/>app, test_apps, env-reset fixtures"]
    end

    subgraph SUPPORT["testing-support"]
        FCR["FlaskCliRunner<br/>(app.test_cli_runner)"]
    end

    CLICK["Click framework<br/>CliRunner, click.Group, BadParameter"]
    FLASKCORE["Flask core<br/>Flask, Blueprint, current_app"]

    TC -->|"exercises"| DISC
    TC -->|"exercises"| SI
    TC -->|"exercises"| FG
    TC -->|"exercises"| CMDS
    TC -->|"exercises"| CERT
    TC -->|"exercises"| ENV
    TC -->|"exercises"| VER
    TC -->|"exercises"| WAC
    TA -->|"imported by discovery tests"| DISC
    CONF -->|"provides fixtures"| TC
    FCR -->|"used by blueprint CLI tests"| TC
    TC -->|"drives CLI in-process"| CLICK
    CLI --> CLICK
    TC --> FLASKCORE
    CLI --> FLASKCORE
```

### 2.2 Component relationship within the suite

```mermaid
flowchart TD
    subgraph test_cli["tests/test_cli.py"]
        FIX["runner fixture<br/>(CliRunner)"]
        TR["TestRoutes class<br/>(routes command tests)"]
        subgraph discovery["Discovery tests"]
            T1["test_find_best_app"]
            T2["test_prepare_import"]
            T3["test_locate_app"]
            T4["test_locate_app_raises"]
            T5["test_locate_app_suppress_raise"]
            T6["test_scriptinfo"]
        end
        subgraph group["FlaskGroup / context tests"]
            T7["test_flaskgroup_app_context"]
            T8["test_flaskgroup_debug"]
            T9["test_flaskgroup_nested"]
            T10["test_app_cli_has_app_context"]
            T11["test_with_appcontext"]
            T12["test_appgroup_app_context"]
        end
        subgraph env["Environment tests"]
            T13["test_load_dotenv"]
            T14["test_dotenv_path"]
            T15["test_dotenv_optional"]
            T16["test_disable_dotenv_from_env"]
        end
        subgraph certs["Certificate tests"]
            T17["test_run_cert_path"]
            T18["test_run_cert_adhoc"]
            T19["test_run_cert_import"]
            T20["test_run_cert_no_ssl"]
            T21["test_run_exclude_patterns"]
        end
        subgraph output["Error / output tests"]
            T22["test_no_command_echo_loading_error"]
            T23["test_help_echo_loading_error"]
            T24["test_help_echo_exception"]
        end
        T25["test_cli_blueprints"]
        T26["test_get_version"]
    end

    subgraph test_apps["tests/test_apps/"]
        FAC["cliapp/factory.py<br/>create_app, create_app2(foo, bar), no_app"]
        HELLO["helloworld/hello.py<br/>module-level app"]
    end

    FAC --> T3
    FAC --> T4
    FAC --> T5
    FAC --> T6
    HELLO --> T6
    FIX --> TR
    FIX --> T7
    FIX --> T8
    FIX --> T9
    FIX --> T11
    FIX --> T12
```

---

## 3. Test Infrastructure and Fixtures

### 3.1 The `runner` fixture

Defined at the top of `tests/test_cli.py`:

```python
@pytest.fixture
def runner():
    return CliRunner()
```

It wraps Click's `CliRunner` so every test can invoke CLI commands **in-process** — no subprocess, no real server startup. `runner.invoke(cli, [...])` returns a `Result` carrying `exit_code`, `output`/`stdout`, `stderr`, and `return_value`. Two usage patterns appear throughout:

1. **Direct invocation** — `runner.invoke(cli, args, obj=ScriptInfo(...))`, passing an explicit `ScriptInfo` as the Click context object.
2. **FlaskGroup invocation** — `runner.invoke(FlaskGroup(create_app=...), args)`, letting the group build its own `ScriptInfo` and push the app context.

Where a test must separate `stdout` from `stderr` (the error-echo tests), the suite handles a Click API change defensively:

```python
try:
    runner = CliRunner(mix_stderr=False)
except (DeprecationWarning, TypeError):
    # Click >= 8.2
    runner = CliRunner()
```

### 3.2 Shared fixtures from `tests/conftest.py`

See [test-infrastructure](test-infrastructure.md) for full details. The suite relies on:

- **`test_apps`** — places the `tests/test_apps/` directory on `sys.path` so modules such as `cliapp.factory`, `cliapp.app`, and `helloworld` can be imported by name during discovery tests.
- **`app`** — a standard `Flask("flask_test")` instance used by `test_flaskgroup_nested` (expects `current_app.name == "flask_test"`) and `test_cli_blueprints`.
- Environment hygiene — monkeypatch-based fixtures guarantee that `os.environ` / `sys.path` mutations (dotenv values, `prepare_import`'s `sys.path` side effect) are rolled back after each test.

### 3.3 In-test isolation techniques

| Technique | Where used | Purpose |
| --- | --- | --- |
| `monkeypatch.chdir(...)` | `test_scriptinfo`, dotenv tests | Emulate running the `flask` command from different project directories. |
| `monkeypatch.setitem(sys.modules, ...)` | cert tests, `test_dotenv_optional` | Simulate missing modules (`dotenv`, `ssl`, `cryptography`, arbitrary imports) without uninstalling anything. |
| `request.addfinalizer(reset_path)` | `test_prepare_import` | Restore `sys.path` because `prepare_import` inserts directories as a side effect. |
| `run_command.make_context(...)` | cert/exclude-pattern tests | Validate option parsing & conversion without invoking the actual server. |

---

## 4. Coverage Areas in Detail

### 4.1 Application discovery

These tests pin down the resolution chain `prepare_import → locate_app → find_best_app / find_app_by_string` documented in [command-line-interface_app-discovery](command-line-interface_app-discovery.md).

**`test_prepare_import`** (parametrized, 11 cases) — verifies conversion of a filesystem path into an importable dotted module name plus the `sys.path` side effect:

- `test` → `test`; `test.py` → `test` (extension stripped)
- `a/test` → `test` with `cwd/a` prepended to `sys.path`
- `test/__init__.py` / `test/__init__` → `test` (package collapse)
- Nested packages: `cliapp/inner1/__init__` → `cliapp.inner1`, `cliapp/inner1/inner2` → `cliapp.inner1.inner2` (walks up while `__init__.py` exists)
- Dotted names pass through: `test.a.b`
- Non-Python files are returned unchanged and rejected later at import time (`cliapp.message.txt`)

**`test_find_best_app`** — verifies the heuristic priority order of `find_best_app`:

1. Module attribute named `app`
2. Module attribute named `application`
3. Any *other* attribute that is a `Flask` instance (only one allowed) — e.g. `myapp`
4. `create_app()` factory (called with no args; also matched when it accepts `**kwargs`)
5. `make_app()` factory
6. Attribute **wins** over factory when both exist (`myapp` over `create_app`)

Failure modes asserted as `NoAppException`: empty module, two competing app attributes (`myapp1`/`myapp2`), and a factory with required positional args. A factory raising an internal `TypeError` is re-raised (not masked as `NoAppException`).

**`test_locate_app`** (parametrized) — module/attribute resolution against the synthetic fixture modules:

| Import name | App name | Resolved app |
| --- | --- | --- |
| `cliapp.app` | `None` | `testapp` (via `find_best_app`) |
| `cliapp.factory` | `None` | `app` (via `create_app`) |
| `cliapp.factory` | `create_app` / `create_app()` / `" create_app () "` | `app` (call expression; whitespace stripped) |
| `cliapp.factory` | `create_app2("foo", "bar")` (incl. trailing comma) | `app2_foo_bar` |

The factory-side implementations under test live in `tests/test_apps/cliapp/factory.py`:

```python
def create_app():                  # -> Flask("app")
def create_app2(foo, bar):         # -> Flask("app2_<foo>_<bar>")
def no_app():                      # returns None — drives the "no app returned" error path
```

**`test_locate_app_raises`** (parametrized, 8 cases) — every failure surfaces as `NoAppException`: nonexistent module, path-instead-of-dotted name, bad attribute, factory called with too few arguments, invalid Python identifier `create_app(`, factory returning `None` (`no_app`), an *ImportError raised inside* the target module (`cliapp.importerrorapp` — the traceback has depth > 1), and non-Python files.

**`test_locate_app_suppress_raise`** — the `raise_if_not_found=False` soft mode: a *direct* import failure returns `None` (used by the `wsgi.py`/`app.py` auto-search), while an ImportError originating **inside** the target module still raises.

**`test_scriptinfo`** — `ScriptInfo` caching and the three load strategies, in priority order:

```mermaid
flowchart TD
    A["ScriptInfo.load_app()"] --> B{"_loaded_app cached?"}
    B -->|yes| Z["return cached app<br/>(identity-stable across calls)"]
    B -->|no| C{"create_app callable?"}
    C -->|yes| D["create_app()"]
    C -->|no| E{"app_import_path set?"}
    E -->|yes| F["split on ':' → path + name"]
    F --> G["prepare_import(path)"]
    G --> H["locate_app(module, name)"]
    E -->|no| I["search wsgi.py, then app.py,<br/>in the current directory"]
    I --> G
    D --> J{"found?"}
    H --> J
    J -->|no| K["NoAppException with<br/>'--app' / FLASK_APP / wsgi.py hint"]
    J -->|yes| L{"set_debug_flag?"}
    L -->|yes| M["app.debug = get_debug_flag()"]
    L -->|no| N["return app"]
    M --> N
```

Tested variations: `module:name` strings, absolute file paths (with and without `:name`), `create_app` callables, `NoAppException` when nothing is configured, and `monkeypatch.chdir` into `test_apps/helloworld` (module-level `app` in `hello.py`, loaded through the conventional file search) and `test_apps/cliapp` (`app.py` fallback).

### 4.2 FlaskGroup behavior and app-context guarantees

These tests protect the CLI framework contract described in [command-line-interface_cli-framework](command-line-interface_cli-framework.md): since Flask 2.2, an app context is pushed automatically for commands under `FlaskGroup`/`AppGroup`/`app.cli`, so `@with_appcontext` is optional.

| Test | Behavior pinned |
| --- | --- |
| `test_flaskgroup_app_context` | A command registered on a `FlaskGroup(create_app=...)` can read `current_app.name` without any decorator. |
| `test_flaskgroup_debug` | With `set_debug_flag=True` the `FLASK_DEBUG` env var overrides the app's own `debug=True`; with `set_debug_flag=False` the factory's value is preserved (`not set_debug_flag` asserts `"False"` is echoed). |
| `test_flaskgroup_nested` | A `FlaskGroup` nested inside a plain `click.Group` (`cli flask show`) still resolves and pushes the correct app. |
| `test_app_cli_has_app_context` | Two guarantees in one: (a) Click **parameter callbacks** run inside the app context (`current_app` is available), and (b) `ctx.obj.load_app()` returns the *same* Python object as `current_app._get_current_object()`. |
| `test_appgroup_app_context` | `AppGroup` and its subgroups behave identically (nested `subgroup test2` also sees `current_app`). |
| `test_with_appcontext` | The explicit decorator loads the app from the ambient `ScriptInfo` (`obj=`) and pushes a context for a bare `click.command` that has no app wiring. |

### 4.3 Environment configuration (dotenv)

Covers `load_dotenv` semantics documented in [command-line-interface_environment-config](command-line-interface_environment-config.md). The dotenv tests are gated by `need_dotenv = pytest.mark.skipif(dotenv_not_available(), ...)` so the suite passes with or without `python-dotenv` installed.

- **`test_load_dotenv`** — precedence matrix: `.flaskenv` never overwrites `.env`; values set only in `.flaskenv` or only in `.env` land in `os.environ`; manually exported values are never clobbered; files are read as UTF-8 (asserts the non-ASCII value `火腿`); a nonexistent explicit path returns `False` (with `load_defaults=False`).
- **`test_dotenv_path`** — an explicit path is honored and does **not** change the working directory.
- **`test_dotenv_optional`** — with `sys.modules["dotenv"] = None` (module hidden), loading is a silent no-op.
- **`test_disable_dotenv_from_env`** — `FLASK_SKIP_DOTENV=1` suppresses default loading even when `.env`/`.flaskenv` exist.

### 4.4 `run` command certificate handling

These tests drive `run_command.make_context(...)` directly, exercising the option pipeline of [command-line-interface_built-in-commands](command-line-interface_built-in-commands.md) (`CertParamType` → `_validate_key`) without starting a server:

```mermaid
flowchart TD
    V["--cert value"] --> P{"is an existing file?"}
    P -->|yes| K{"--key also given?"}
    K -->|yes| T["cert = (cert_path, key_path) tuple<br/>(order-independent: --key first also OK)"]
    K -->|no| E1["BadParameter"]
    P -->|no| Q{"value == 'adhoc'?"}
    Q -->|yes| C{"cryptography installed?<br/>(simulated via sys.modules)"}
    C -->|yes| OK1["cert = 'adhoc'"]
    C -->|no| E2["BadParameter"]
    Q -->|no| I{"imports to an ssl.SSLContext?"}
    I -->|yes| OK2["cert = SSLContext instance"]
    I -->|no| E3["BadParameter<br/>(ImportError, or 'flask' module which is not a context)"]
    T -.->|"- -key with adhoc / SSLContext"| E4["BadParameter: --key not used"]
```

- **`test_run_cert_path`** — file-pair validation in both `--cert, --key` and `--key, --cert` orders; `BadParameter` when either side is missing.
- **`test_run_cert_adhoc`** — `adhoc` requires `cryptography` (simulated as missing, then present); `--key` is rejected alongside `adhoc`.
- **`test_run_cert_import`** — `"module:attr"` strings are imported; a real `ssl.SSLContext` passes through by identity; `ImportError` and non-`SSLContext` imports (e.g. the `flask` module) raise `BadParameter`; `--key` is rejected with an `SSLContext`.
- **`test_run_cert_no_ssl`** — with the `ssl` module hidden (`sys.modules["ssl"] = None`), `--cert` fails immediately with `BadParameter`.
- **`test_run_exclude_patterns`** — `--exclude-patterns` parses into a list of strings (passed on to the Werkzeug reloader).

### 4.5 `routes` command (`TestRoutes` class)

`TestRoutes` builds an app with deliberately non-alphabetical endpoints (`aaa_post`, `yyy_get_post`, plus the auto-added `static`) and invokes the command through `FlaskGroup`:

| Test | Behavior pinned |
| --- | --- |
| `test_simple` | Default table is sorted by endpoint (`aaa_post`, `static`, `yyy_get_post`); rows are matched column-by-column after skipping the two header lines. |
| `test_sort` | `-s endpoint` equals the default; `-s methods`, `-s rule`, and `-s match` (registration order via `app.url_map.iter_rules()`) each reorder rows as documented. |
| `test_all_methods` | `HEAD`/`OPTIONS` are hidden by default and shown with `--all-methods` (`GET, HEAD, OPTIONS, POST`). |
| `test_no_routes` | An app with `static_folder=None` and no rules prints `No routes were registered.` with exit code 0. |
| `test_subdomain` | When any rule declares a `subdomain`, a `Subdomain` column appears. |
| `test_host` | With `host_matching=True`, a `Host` column appears instead. |

### 4.6 Error reporting and help output

These tests define the *user-facing* failure UX of the `flask` command, exploiting `FlaskGroup.get_command`/`list_commands` behavior: built-in commands stay reachable even when the app fails to load, and the loading error is echoed without a traceback (full traceback only for non-`NoAppException` errors).

- **`test_no_command_echo_loading_error`** — `flask missing` → exit code `2`, `FLASK_APP` hint and `Usage:` both on **stderr**.
- **`test_help_echo_loading_error`** — `flask --help` → exit code `0`; the `FLASK_APP` loading error goes to **stderr** while `Usage:` goes to **stdout**.
- **`test_help_echo_exception`** — a `create_app` that raises a generic `Exception` produces `Exception: oh no` on stderr (full traceback) while `--help` still succeeds on stdout.

### 4.7 Blueprint CLI registration and version output

- **`test_cli_blueprints`** — the four blueprint CLI-group modes against the shared `app` fixture, invoked through `app.test_cli_runner()` (see [testing-support](testing-support.md)):
  1. `cli_group="customized"` → commands under `flask customized custom`
  2. default group name → `flask nested nested`
  3. `cli_group=None` → commands **merged** into the root group (`flask merged`)
  4. `cli_group` supplied at `register_blueprint(...)` time → `flask late_registration late` (registration-time option wins)
- **`test_get_version`** — with a stub Click context, `get_version` echoes `Python <ver>`, `Flask <ver>` (via `importlib.metadata.version('flask')`), and `Werkzeug <ver>`.

---

## 5. Test Support Applications (`tests/test_apps/`)

These tiny modules are *fixtures-as-data*: they exist so app-discovery logic can be tested against real import machinery rather than mocks.

### 5.1 `cliapp/factory.py`

```python
from flask import Flask

def create_app():                      # canonical no-arg factory -> Flask("app")
    return Flask("app")

def create_app2(foo, bar):             # required-args factory -> Flask("app2_<foo>_<bar>")
    return Flask("_".join(["app2", foo, bar]))

def no_app():                          # factory that yields nothing -> NoAppException path
    pass
```

- `create_app` verifies the "factory called with no arguments" path and call-expression parsing (`create_app()`, whitespace tolerance).
- `create_app2` verifies Click's argument-extraction from the app-name string (`create_app2("foo", "bar")` → app `app2_foo_bar`), including trailing-comma tolerance; calling it without arguments drives the `NoAppException` for under-supplied factories.
- `no_app` verifies that a factory returning `None` raises `NoAppException`.

### 5.2 `helloworld/hello.py`

```python
from flask import Flask

app = Flask(__name__)

@app.route("/")
def hello():
    return "Hello World!"
```

A classic module-level app. In `test_scriptinfo`, changing into the `helloworld` directory and calling `ScriptInfo()` with no configuration verifies the conventional-file discovery chain (`wsgi.py`/`app.py` search → `find_best_app` finds `app`). It also demonstrates the minimal app shape that `find_best_app` must locate.

---

## 6. End-to-End Flow Under Test

The following sequence shows what happens when a typical test invokes a command — this is the exact runtime path the suite continuously validates:

```mermaid
sequenceDiagram
    autonumber
    participant T as Test case
    participant R as CliRunner / FlaskCliRunner
    participant G as FlaskGroup
    participant SI as ScriptInfo
    participant A as Flask app (cliapp / helloworld / factory)
    participant CB as Command callback

    T->>R: invoke(cli, ["command", ...])
    R->>G: make_context() / parse_args()
    Note over G: sets FLASK_RUN_FROM_CLI=1<br/>(app.run() becomes a no-op)
    G->>G: eagerly handle --env-file / --app options
    G->>SI: ensure_object(ScriptInfo)
    SI->>A: load_app()  (cached after first call)
    A-->>SI: Flask instance
    SI-->>G: app
    G->>G: push app.app_context() via ctx.with_resource
    G->>CB: invoke callback (current_app is active)
    CB-->>R: output / exit code
    R-->>T: Result(output, stderr, exit_code, return_value)
```

Assertions then focus on `exit_code`, `output`/`stderr` text, `return_value` (with `standalone_mode=False`), or side effects in `os.environ`.

---

## 7. Test-to-Behavior Traceability Matrix

| CLI contract | Source component ([command-line-interface](command-line-interface.md)) | Verifying tests |
| --- | --- | --- |
| Path → import-name conversion + `sys.path` setup | `prepare_import` | `test_prepare_import` |
| Best-app heuristics & failure modes | `find_best_app` | `test_find_best_app` |
| `module:name` resolution, factory call parsing | `locate_app`, `find_app_by_string` | `test_locate_app`, `test_locate_app_raises`, `test_locate_app_suppress_raise` |
| Load strategies + caching + `NoAppException` hint | `ScriptInfo.load_app` | `test_scriptinfo` |
| Automatic app context for group commands | `FlaskGroup.get_command` | `test_flaskgroup_app_context`, `test_app_cli_has_app_context`, `test_appgroup_app_context`, `test_flaskgroup_nested` |
| `--debug` flag propagation control | `FlaskGroup(set_debug_flag)`, `_set_debug` | `test_flaskgroup_debug` |
| Explicit context decorator | `with_appcontext` | `test_with_appcontext` |
| `.env` / `.flaskenv` precedence & opt-outs | `load_dotenv`, `_env_file_callback` | `test_load_dotenv`, `test_dotenv_path`, `test_dotenv_optional`, `test_disable_dotenv_from_env` |
| `--cert`/`--key` validation matrix | `CertParamType`, `_validate_key` | `test_run_cert_path`, `test_run_cert_adhoc`, `test_run_cert_import`, `test_run_cert_no_ssl` |
| Reloader excludes | `run_command` | `test_run_exclude_patterns` |
| Route table rendering & sorting | `routes_command` | `TestRoutes.*` |
| Graceful failure UX (stderr vs stdout, exit codes) | `FlaskGroup.get_command` / `list_commands` | `test_no_command_echo_loading_error`, `test_help_echo_loading_error`, `test_help_echo_exception` |
| Blueprint CLI groups (custom/default/merged/late) | `Blueprint.cli`, `app.register_blueprint` | `test_cli_blueprints` (blueprint side detailed in [blueprints_test_suite](blueprints_test_suite.md)) |
| `--version` output | `get_version` | `test_get_version` |

---

## 8. Running the Tests

From the repository root:

```bash
# Entire CLI test suite
pytest tests/test_cli.py -v

# A single area, e.g. app discovery
pytest tests/test_cli.py -k "locate_app or prepare_import or find_best_app or scriptinfo"

# Certificate option validation only
pytest tests/test_cli.py -k "run_cert or exclude_patterns"

# Routes command behavior
pytest tests/test_cli.py tests/test_cli.py::TestRoutes -v
```

Notes:

- Dotenv tests auto-skip when `python-dotenv` is not installed (`need_dotenv` marker); install it to exercise the full matrix: `pip install python-dotenv`.
- Tests that simulate missing dependencies (`ssl`, `cryptography`, `dotenv`) do so via `monkeypatch.setitem(sys.modules, ...)` and require no environment changes.
- The `test_apps` fixture (from [test-infrastructure](test-infrastructure.md)) must be active for any test that imports `cliapp.*` or `helloworld`.
- `test_prepare_import` mutates `sys.path` through the production function's own side effect and restores it via a request finalizer — do not remove that finalizer.

---

## 9. Related Documentation

- [command-line-interface](command-line-interface.md) — the CLI module under test (parent module)
- [command-line-interface_app-discovery](command-line-interface_app-discovery.md) — `ScriptInfo` / `_set_app`
- [command-line-interface_cli-framework](command-line-interface_cli-framework.md) — `FlaskGroup`
- [command-line-interface_built-in-commands](command-line-interface_built-in-commands.md) — `run`, `shell`, `routes`, cert typing
- [command-line-interface_environment-config](command-line-interface_environment-config.md) — dotenv, debug flag, path helpers
- [testing-support](testing-support.md) — `FlaskCliRunner`, `FlaskClient`, `EnvironBuilder`
- [test-infrastructure](test-infrastructure.md) — shared `conftest.py` fixtures (`app`, `test_apps`, environment resets)
- [blueprints_test_suite](blueprints_test_suite.md) — blueprint registration behavior shared with `test_cli_blueprints`
