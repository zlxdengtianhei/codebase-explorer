# testing-support_cli-runner

> **Module scope:** `src/flask/testing.py::FlaskCliRunner` — the Flask-aware adapter around Click's CLI test runner.
>
> **Parent area:** [Developer Interface & Testing Tooling] — sibling modules: [testing-support_test-client](testing-support_test-client.md), [testing-support_test-suite](testing-support_test-suite.md), [test-infrastructure](test-infrastructure.md)

---

## 1. Introduction

`testing-support_cli-runner` provides a single, focused class: **`FlaskCliRunner`**. It subclasses `click.testing.CliRunner` so that tests can invoke a Flask application's CLI commands (both the built-in ones and any commands registered via `@app.cli.command()` or blueprints) inside an isolated, in-process environment.

The class solves two problems that a bare `CliRunner` cannot:

1. **App binding** — it holds a reference to the specific `Flask` application under test and defaults every invocation to that app's CLI group (`app.cli`), so tests never need to locate or import an app.
2. **Context-object injection** — it automatically passes a `flask.cli.ScriptInfo` bound to that same app as Click's `obj`. This is the same mechanism the production `flask` command uses, so commands that resolve `ctx.obj` (directly, or indirectly through `FlaskGroup`'s automatic app-context push) behave identically in tests and in production.

It is the CLI counterpart of `FlaskClient` (see [testing-support_test-client](testing-support_test-client.md)) and is typically obtained via `app.test_cli_runner()` rather than instantiated directly.

---

## 2. Architecture & Component Relationships

### 2.1 Position in the system

`FlaskCliRunner` is the bridge between the **testing toolkit** (which simulates requests and commands) and the **command-line interface machinery** (which discovers and executes commands against an app). It does not re-implement any CLI logic — it only *wires* the app under test into the standard Click execution path.

```mermaid
graph TB
    subgraph DEV["Developer_Interface___Testing_Tooling"]
        subgraph TS["testing-support"]
            CR["<b>testing-support_cli-runner</b><br/>FlaskCliRunner"]
            TC["testing-support_test-client<br/>EnvironBuilder · FlaskClient"]
            SUITE["testing-support_test-suite<br/>tests/test_testing.py"]
        end
        subgraph CLI["command-line-interface"]
            AD["app-discovery<br/>ScriptInfo"]
            FG["cli-framework<br/>FlaskGroup"]
            BC["built-in-commands<br/>run · shell · routes"]
        end
    end

    subgraph CORE["Core_Application_Engine___Modular_Composition"]
        APP["application-core_flask-app<br/>Flask (+ app.cli AppGroup)"]
    end

    subgraph CTX["contexts"]
        AC["contexts_app_context<br/>AppContext"]
    end

    CLICK["click.testing.CliRunner / Result<br/>(external: Click)"]

    APP -- "test_cli_runner() factory<br/>(test_cli_runner_class attr)" --> CR
    CR -- "extends" --> CLICK
    CR -- "default obj injection" --> AD
    CR -- "default cli = app.cli" --> APP
    FG -- "ensure_object(ScriptInfo)" --> AD
    FG -- "ctx.with_resource(app.app_context())" --> AC
    SUITE -- "covers" --> CR
    SUITE -- "covers" --> TC
```

### 2.2 Class design

```mermaid
classDiagram
    class CliRunner {
        <<click.testing>>
        +invoke(cli, args, **kwargs) Result
        +isolation() isolated filesystem/env
    }
    class FlaskCliRunner {
        +Flask app
        +__init__(app, **kwargs)
        +invoke(cli, args, **kwargs) Result
    }
    class ScriptInfo {
        <<flask.cli>>
        +create_app : Callable | None
        +app_import_path : str | None
        +load_app() Flask
    }
    class Flask {
        +cli : AppGroup
        +test_cli_runner_class
        +test_cli_runner(**kwargs) FlaskCliRunner
    }

    CliRunner <|-- FlaskCliRunner : inherits invoke plumbing
    FlaskCliRunner o-- Flask : "self.app"
    FlaskCliRunner ..> ScriptInfo : "creates default obj"
    Flask o-- FlaskCliRunner : "test_cli_runner_class (overridable)"
    ScriptInfo ..> Flask : "load_app() → same instance"
```

**Key design points**

| Aspect | Detail |
|---|---|
| Inheritance | Extends `click.testing.CliRunner`; all of Click's runner features (isolated filesystem, env var isolation, mixed stdin, output capture) work unchanged. |
| `__init__(self, app, **kwargs)` | Stores `self.app = app`, forwards all other keyword arguments (e.g. `env`, `catch_exceptions`) to `CliRunner.__init__`. |
| `invoke` override | The only behavioural override; it fills in two defaults and then delegates to `super().invoke()`. It is deliberately *thin* — see §4. |

---

## 3. How It Fits Into the Overall System

### 3.1 Creation path

`FlaskCliRunner` instances are produced by `Flask.test_cli_runner()`, which honours the `app.test_cli_runner_class` attribute for dependency injection (mirroring `test_client_class` for the HTTP client):

```mermaid
flowchart LR
    A["Test code"] --> B["app.test_cli_runner(**kwargs)"]
    B --> C{"app.test_cli_runner_class<br/>set?"}
    C -- "No" --> D["flask.testing.FlaskCliRunner"]
    C -- "Yes" --> E["custom subclass"]
    D --> F["FlaskCliRunner(app, **kwargs)"]
    E --> F
```

The customisation hook is exercised by `tests/test_testing.py::test_cli_runner_class`, which also confirms the default type is `FlaskCliRunner`.

### 3.2 Invocation flow

The sequence below traces `runner.invoke(args=["hello"])` end-to-end. It shows why the injected `ScriptInfo` matters: `FlaskGroup` (the framework behind `app.cli`) retrieves the runner's `ScriptInfo` as its context object, loads the app from it — getting back the *exact instance under test*, with no filesystem discovery or `.env` loading — and then pushes an app context so command callbacks can use `current_app` without `@with_appcontext`.

```mermaid
sequenceDiagram
    autonumber
    participant T as Test code
    participant R as FlaskCliRunner
    participant C as click.testing.CliRunner
    participant G as FlaskGroup (app.cli)
    participant S as ScriptInfo
    participant A as Flask app (under test)
    participant X as AppContext (contexts module)

    T->>A: test_cli_runner()
    A->>R: FlaskCliRunner(app, **kwargs)
    T->>R: invoke(args=["hello"])
    Note over R: cli is None → default to self.app.cli
    Note over R: "obj" not in kwargs → ScriptInfo(create_app=lambda: self.app)
    R->>C: super().invoke(app.cli, ["hello"], obj=ScriptInfo)
    C->>G: make_context / get_command(ctx, "hello")
    G->>S: ctx.ensure_object(ScriptInfo)
    G->>S: load_app()
    S-->>G: app ← create_app() → the SAME instance under test
    G->>X: ctx.with_resource(app.app_context())
    Note over X: current_app available to command callbacks
    G-->>C: command resolved from app.cli registry
    C->>C: run command callback, capture stdout/stderr/exit code
    C-->>T: click.testing.Result (output, exit_code, exception)
```

Because `ScriptInfo.load_app()` memoises (`_loaded_app`) and the runner supplies `create_app=lambda: self.app`, command execution is guaranteed to operate on the configured application — including its config, blueprints, and registered CLI commands (see [command-line-interface_app-discovery](command-line-interface_app-discovery.md) for `ScriptInfo` internals, and [command-line-interface_cli-framework](command-line-interface_cli-framework.md) for `FlaskGroup`'s discovery and context behaviour).

### 3.3 The `invoke` override — contract

```python
def invoke(self, cli=None, args=None, **kwargs):
    if cli is None:
        cli = self.app.cli
    if "obj" not in kwargs:
        kwargs["obj"] = ScriptInfo(create_app=lambda: self.app)
    return super().invoke(cli, args, **kwargs)
```

| Parameter | Default behaviour | Override |
|---|---|---|
| `cli` | Falls back to the bound app's own CLI group (`app.cli`, an `AppGroup`). | Pass any Click `Command`/`Group` object — e.g. a single `@app.cli.command` function or a sub-group — to invoke it directly without group lookup. |
| `obj` | Injects `ScriptInfo(create_app=lambda: self.app)`. | Pass your own object (e.g. a custom `ScriptInfo` with a different `create_app`) to control what commands see as `ctx.obj`. |
| `args` | Forwarded verbatim to Click. | Command name(s) and arguments as a list of strings. |
| `**kwargs` | Forwarded to `CliRunner.invoke` (e.g. `input`, `env`, `catch_exceptions`). | — |

**Return value:** a `click.testing.Result` exposing `output`, `exit_code`, `result.stdout`, `result.exception`, and (for Click ≥ 8.2) `result.return_value`.

---

## 4. Usage

### 4.1 Typical test

```python
def test_cli_invoke(app):
    @app.cli.command("hello")
    def hello_command():
        click.echo("Hello, World!")

    runner = app.test_cli_runner()

    result = runner.invoke(args=["hello"])   # by command name (resolved via app.cli)
    assert "Hello" in result.output

    result = runner.invoke(hello_command)     # by command object
    assert "Hello" in result.output
```

### 4.2 Supplying a custom context object

```python
def test_cli_custom_obj(app):
    script_info = ScriptInfo(create_app=create_app)

    runner = app.test_cli_runner()
    runner.invoke(hello_command, obj=script_info)  # explicit obj wins
```

When an explicit `obj` is given, the runner does **not** inject its own `ScriptInfo` — the provided object becomes `ctx.obj`, and `FlaskGroup` will load the app through *that* object's `load_app()`. This is useful for testing commands against an independently constructed app instance or for injecting extra data via `ScriptInfo.data`.

### 4.3 Runner-level customisation

```python
class SubRunner(FlaskCliRunner):
    pass

app.test_cli_runner_class = SubRunner
runner = app.test_cli_runner()   # returns SubRunner instance
```

This mirrors the `test_client_class` pattern documented in [testing-support_test-client](testing-support_test-client.md).

---

## 5. App Context Semantics

A common misconception is that `FlaskCliRunner` pushes contexts itself. It does not. Context lifecycle is owned by the CLI framework:

- `FlaskGroup.get_command()` pushes an app context (`ctx.with_resource(app.app_context())`) for the loaded app **unless one is already active**. Since Flask 2.2 this means commands registered on `app.cli` have `current_app` available without `@with_appcontext`.
- If a test already holds an app context for the *same* app, `FlaskGroup` detects it (`current_app._get_current_object() is not app`) and does not push a duplicate.
- Commands invoked via `@with_appcontext` (or `AppGroup` defaults) obtain the app from `ctx.obj` — i.e. the `ScriptInfo` the runner injected — reinforcing why that default injection is essential.

Consequently, a test using the runner can rely on `current_app` inside command callbacks, and teardown of contexts happens when Click's context is closed. For the context model itself, see [contexts_app_context](contexts_app_context.md); for context-related behaviour of the HTTP test client, see [testing-support_test-client](testing-support_test-client.md).

---

## 6. Testing & Verification

This module is exercised by the `testing-support_test-suite` (full details in [testing-support_test-suite](testing-support_test-suite.md)):

| Test | What it verifies |
|---|---|
| `tests/test_testing.py::test_cli_runner_class` | Factory returns `FlaskCliRunner` by default; `app.test_cli_runner_class` overrides the class. |
| `tests/test_testing.py::test_cli_invoke` | Default `cli` fallback works for both name-based and object-based invocation; output is captured. |
| `tests/test_testing.py::test_cli_custom_obj` | An explicit `obj` (`ScriptInfo`) suppresses the automatic injection and is used by the command. |
| `tests/test_cli.py::test_flaskgroup_app_context`, `test_app_cli_has_app_context` | Commands running through the app's CLI group see a pushed app context. |
| `tests/test_cli.py::test_with_appcontext`, `test_scriptinfo` | `@with_appcontext` decorator and `ScriptInfo` app loading against the same app instance. |
| `tests/test_cli.py::test_flaskgroup_debug`, `test_flaskgroup_nested` | `FlaskGroup` flags/props propagate through invocations. |

**Execution:**

```bash
pytest tests/test_testing.py -k cli
pytest tests/test_cli.py -k "app_context or scriptinfo"
```

---

## 7. Dependencies

### Internal

| Dependency | Source module | Role |
|---|---|---|
| `flask.cli.ScriptInfo` | [command-line-interface_app-discovery](command-line-interface_app-discovery.md) | Context object that resolves the app under test (`create_app=lambda: self.app`); memoises the loaded app. |
| `Flask.cli` / `FlaskGroup` | [application-core_flask-app](application-core_flask-app.md) / [command-line-interface_cli-framework](command-line-interface_cli-framework.md) | Default command registry; performs command lookup and app-context push during dispatch. |
| `flask.ctx.AppContext` | [contexts_app_context](contexts_app_context.md) | Pushed by `FlaskGroup` so commands can use `current_app`. |
| Built-in commands | [command-line-interface_built-in-commands](command-line-interface_built-in-commands.md) | `run`, `shell`, `routes` invocable through the runner (e.g. `routes_command` output is testable via `TestRoutes`). |

### External

| Dependency | Role |
|---|---|
| `click.testing.CliRunner` / `click.testing.Result` | Base runner: argument parsing, isolated environment, output/exception capture. |
| `typing` | Annotations only (`t.TYPE_CHECKING` import of `flask.Flask` avoids a circular import — `testing` is imported lazily from `app.test_cli_runner`). |

### Lazy-import note

`flask.testing` imports `flask.cli` and `flask.sessions`, while `flask.app` imports `flask.testing` **inside** `test_cli_runner()` / `test_client()` methods. This lazy-loading pattern keeps the import graph acyclic; new contributors should not move `FlaskCliRunner` imports to module level in `app.py`.

---

## 8. Related Modules

- [testing-support_test-client](testing-support_test-client.md) — `EnvironBuilder` / `FlaskClient`: the HTTP-request counterpart of this module, sharing the same app-binding pattern.
- [testing-support_test-suite](testing-support_test-suite.md) — behavioural tests for all testing-support components.
- [command-line-interface_app-discovery](command-line-interface_app-discovery.md) — `ScriptInfo` and app locating (`--app`, `FLASK_APP`, factories) that the runner bypasses via `create_app`.
- [command-line-interface_cli-framework](command-line-interface_cli-framework.md) — `FlaskGroup`, dotenv handling, and the app-context push implemented at dispatch time.
- [application-core_flask-app](application-core_flask-app.md) — the `Flask` class, `app.cli` registration, and the `test_cli_runner()` factory.
- [contexts_app_context](contexts_app_context.md) — app context push/pop semantics available to CLI commands.
- [test-infrastructure](test-infrastructure.md) — shared pytest fixtures (`app`, `app_ctx`, `client`) used by the tests above.
