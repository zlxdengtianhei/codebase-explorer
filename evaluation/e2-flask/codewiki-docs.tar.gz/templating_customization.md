# Module: templating_customization

## Introduction

`templating_customization` is the module that documents and verifies **how applications extend Flask's Jinja2 environment with their own building blocks**. It covers the three official extension points of the Jinja language:

| Extension point | Jinja syntax | Typical use |
|---|---|---|
| **Filter** | `{{ value \| my_filter }}` | Transform a value (reverse a string, format a date, …) |
| **Test** | `{% if value is boolean %}` | Boolean check on a value inside control structures |
| **Global** | `{{ get_stuff() }}` | Callable or object available in every template |

The module's *runtime surface* is a small, symmetrical registration API on the `Flask` application object (and on `Blueprint`), implemented in `flask/sansio/app.py::App`. Its *verification surface* is a family of 17 tests in `tests/test_templating.py` that prove each registration path — decorator-style and imperative-style, with default names and explicit names — actually lands in `app.jinja_env.filters`, `app.jinja_env.tests`, and `app.jinja_env.globals` and is honored during template rendering.

This module sits inside the larger [Request_Services___Response_Rendering](Request_Services___Response_Rendering.md) group, as a sibling of [templating_environment_loader](templating_environment_loader.md) (how templates are *found* and the environment is *configured*) and [templating_rendering_context](templating_rendering_context.md) (how templates are *rendered* and how *context variables* are injected). Customization is about *what the template language can do*; those siblings cover *where templates come from* and *what data they receive*.

---

## 1. Core Functionality

### 1.1 The registration API

All six methods live on `App` (the sansio base class of `Flask`, see [application-core_sansio-foundation](application-core_sansio-foundation.md)) and are guarded by the `@setupmethod` decorator:

| Decorator form | Imperative form | Jinja namespace written to | Default name |
|---|---|---|---|
| `@app.template_filter(name=None)` | `app.add_template_filter(f, name=None)` | `app.jinja_env.filters` | `f.__name__` |
| `@app.template_test(name=None)` | `app.add_template_test(f, name=None)` | `app.jinja_env.tests` | `f.__name__` |
| `@app.template_global(name=None)` | `app.add_template_global(f, name=None)` | `app.jinja_env.globals` | `f.__name__` |

Implementation contract (verified against the source):

- The **decorator is a thin wrapper**: `template_filter(name)` returns a `decorator(f)` that calls `self.add_template_filter(f, name=name)` and returns `f` unchanged — the decorated function remains fully usable from Python code.
- The **imperative form is the single mutation point**: it performs exactly one dict assignment, e.g. `self.jinja_env.filters[name or f.__name__] = f`. There is no wrapping, proxying, or copying of the callable — the tests assert *identity* (`app.jinja_env.filters["my_reverse"] == my_reverse`).
- **Name resolution** is `name or f.__name__`; an explicitly passed name replaces the function name in the template namespace (the tests register `my_reverse` as `"strrev"` / `"super_reverse"` and look it up under that name).
- Both forms are `@setupmethod`-wrapped, so registration is refused after the app has handled its first request (see §1.4).

### 1.2 Usage patterns proven by the test suite

```python
# 1) Decorator, default name (from function __name__)
@app.template_filter()
def my_reverse(s):
    return s[::-1]

# 2) Decorator, custom name
@app.template_filter("strrev")
def my_reverse(s): ...

# 3) Imperative, default name
app.add_template_filter(my_reverse)

# 4) Imperative, custom name
app.add_template_filter(my_reverse, "super_reverse")
```

Each of these styles exists in **four filter variants** (decorator/imperative × named/default) and the same for template tests. Template globals are exercised with the decorator form in an active app context, then rendered without a request via `render_template_string("{{ get_stuff() }}")`.

### 1.3 Verification levels

The tests deliberately check three distinct levels for every registration path:

1. **Registry membership** — the name exists in the correct namespace (`filters` / `tests` / `globals`).
2. **Identity** — the registered object *is* the user's function (no wrapper indirection).
3. **Behavior** — the callable produces the expected transformation when invoked through the namespace (`app.jinja_env.filters["my_reverse"]("abcd") == "dcba"`).
4. **End-to-end rendering** (subset of cases) — a view renders a real template file (`template_filter.html`, `template_test.html`) through `render_template` and the response body reflects the custom filter/test, proving the wiring survives the full loader → compile → render pipeline.

### 1.4 Lifecycle constraint: `setupmethod` guarding

Every registration method is wrapped by `setupmethod` (from `flask/sansio/scaffold.py`), which forwards to `App._check_setup_finished(f_name)`:

```python
def setupmethod(f):
    def wrapper_func(self, *args, **kwargs):
        self._check_setup_finished(f_name)
        return f(self, *args, **kwargs)
    return update_wrapper(wrapper_func, f)
```

`_check_setup_finished` raises an `AssertionError` once `app._got_first_request` is `True`. This is what makes the API safe: template namespaces are mutated *in place* on the live environment, so late registrations would apply inconsistently to already-rendered templates. All setup (filters, tests, globals — and routes, error handlers, etc.) must complete before the first request.

> Note: mutating `app.jinja_env` directly also triggers the lazy creation of the environment (§2.2). Likewise, `jinja_options` must be configured before the *first access* to `app.jinja_env`, after which they have no effect.

---

## 2. Architecture and Component Relationships

### 2.1 Component map

```mermaid
flowchart TB
    subgraph APP["Application code"]
        CB["Custom Python callables<br/>(filter / test / global)"]
        VW["View functions<br/>returning render_template(...)"]
        TPL["Template files<br/>uses &#123;&#123; v &#124; filter &#125;&#125;"]
    end

    subgraph SANSIO["flask/sansio/app.py :: App"]
        DEC["@setupmethod template_filter(name)<br/>@setupmethod template_test(name)<br/>@setupmethod template_global(name)"]
        IMP["add_template_filter / add_template_test /<br/>add_template_global  (single mutation point)"]
        JEPROP["jinja_env  (cached_property)"]
        GUARD["_check_setup_finished()<br/>AssertionError after first request"]
    end

    subgraph CONCRETE["flask/app.py :: Flask"]
        CJE["create_jinja_environment()<br/>autoescape, auto_reload,<br/>globals: url_for, config,<br/>request, session, g<br/>policy: json.dumps_function"]
    end

    subgraph TEMPL["flask/templating.py"]
        ENV["Environment(app, **options)<br/>(subclass of jinja2.Environment)"]
        NSP["env.filters / env.tests / env.globals"]
        LOAD["DispatchingJinjaLoader<br/>(app + blueprint loaders)"]
    end

    CB -->|"decorates"| DEC
    CB -->|"registers"| IMP
    DEC -->|"delegates: add_template_*(f, name)"| IMP
    DEC -.->|"guard"| GUARD
    IMP -.->|"guard"| GUARD
    IMP -->|"env.filters/tests/globals[name or f.__name__] = f"| NSP
    IMP -->|"first access triggers creation"| JEPROP
    JEPROP -->|"create_jinja_environment()"| CJE
    CJE -->|"jinja_environment(self, **jinja_options)"| ENV
    ENV --- LOAD
    ENV --- NSP
    NSP -->|"name resolution at render time"| TPL
    TPL --> VW
```

### 2.2 Environment creation flow (lazy, once)

The customization target — `app.jinja_env` — does not exist until first accessed. The registration methods themselves are typically the first accessors during app setup:

```mermaid
flowchart LR
    A["app.add_template_filter(f, name)"] --> B{"jinja_env<br/>cached?"}
    B -- "no (first access)" --> C["create_jinja_environment()"]
    C --> D["merge jinja_options<br/>autoescape = select_jinja_autoescape<br/>auto_reload = TEMPLATES_AUTO_RELOAD or debug"]
    D --> E["self.jinja_environment(self, **options)<br/>= Environment(app, ...)"]
    E --> F["env.globals += url_for,<br/>get_flashed_messages, config,<br/>request, session, g"]
    F --> G["env.policies['json.dumps_function']<br/>= app.json.dumps"]
    G --> H["cache as jinja_env"]
    B -- "yes" --> I["reuse cached environment"]
    H --> J["jinja_env.filters[name or f.__name__] = f"]
    I --> J
```

Key design points visible in `create_jinja_environment()`:

- The environment class itself is customizable: `App.jinja_environment = Environment` (class attribute). A subclass can swap in a custom `Environment` — this is verified in the sibling module's `test_custom_jinja_env` (see [templating_environment_loader](templating_environment_loader.md)).
- Built-in globals (`url_for`, `config`, `request`, `session`, `g`, `get_flashed_messages`) are installed *in addition to* any user globals; user globals registered via `template_global` are simply added to the same `env.globals` dict.
- The JSON dumping policy is wired here too — custom filters that produce JSON-oriented output interact with the policy described in [json-serialization](json-serialization.md).
- `auto_reload` derives from `TEMPLATES_AUTO_RELOAD` falling back to `debug`; configuration semantics are owned by [configuration](configuration.md).

### 2.3 Registration → render sequence

```mermaid
sequenceDiagram
    autonumber
    participant Setup as App setup code
    participant App as Flask (App)
    participant Env as Environment
    participant Loader as DispatchingJinjaLoader
    participant View as View / render_template

    Setup->>App: @app.template_filter("rev")
    App->>App: _check_setup_finished("template_filter") ✓
    App->>App: add_template_filter(f, name="rev")
    App->>Env: jinja_env (lazy create on first access)
    App->>Env: env.filters["rev"] = f  (identity kept)

    Note over App: first request → _got_first_request = True<br/>(further setup calls raise AssertionError)

    View->>View: render_template("page.html", value="abcd")
    View->>Env: get_template("page.html")
    Env->>Loader: get_source(env, "page.html")
    Loader-->>Env: (source, filename, uptodate)
    Env-->>View: compiled template
    View->>Env: render: &#123;&#123; value|rev &#125;&#125;
    Env->>Env: resolve filters["rev"] → f(value)
    Env-->>View: "dcba"
    View-->>View: Response("dcba")
```

The loader leg of the sequence (steps 7–8) is owned by the sibling module [templating_environment_loader](templating_environment_loader.md) — it is shown here only to illustrate that custom filters/tests/globals are resolved *after* template discovery, i.e., they are orthogonal to template lookup rules.

---

## 3. Interaction with Other Modules

| Interaction | Direction | Notes |
|---|---|---|
| `Scaffold` / `setupmethod` (see [application-core_sansio-foundation](application-core_sansio-foundation.md)) | consumes | All six registration methods are `@setupmethod`-guarded; the first-request lock lives on `App._check_setup_finished`. |
| `Flask` application core (see [application-core_flask-app](application-core_flask-app.md)) | consumes | `Flask.create_jinja_environment()` instantiates the environment and seeds built-in globals; `Flask.jinja_env` is the cached property the registration methods write through. |
| `Environment` / `DispatchingJinjaLoader` (see [templating_environment_loader](templating_environment_loader.md)) | target | The customization API writes into the environment's namespaces; the loader is untouched by customization. |
| `render_template` / context processors (see [templating_rendering_context](templating_rendering_context.md)) | co-mechanism | Context processors inject **variables** per render; `template_global` registers **permanent callables** on the environment. Distinct lifetimes, both used in the same test file. |
| `Blueprint` registration machinery (see [blueprints_registration_machinery](blueprints_registration_machinery.md), [blueprints_resources_and_cli](blueprints_resources_and_cli.md)) | mirrors | `Blueprint` exposes the same decorator/imperative pairs; blueprint-level registrations are deferred and applied to the app's Jinja environment when the blueprint is registered. The blueprint test suite (`tests/test_blueprints.py`: `test_template_filter`, `test_add_template_filter`, `test_template_global`, `test_template_test`, …) covers that path. |
| JSON policy (see [json-serialization](json-serialization.md)) | co-configured | `create_jinja_environment` installs `json.dumps_function`; filters/tests/globals operate in templates where `|tojson` uses this policy. |
| Test fixtures (see [test-infrastructure](test-infrastructure.md), [testing-support](testing-support.md)) | verification | Tests rely on the `app`, `client`, `app_ctx`, `req_ctx` fixtures and `app.test_client()` for the end-to-end render assertions. |

### Data-flow summary

```mermaid
flowchart LR
    subgraph Registration["Setup time (before first request)"]
        F1["Python callable f"] --> F2["name = explicit_name or f.__name__"]
        F2 --> F3["jinja_env.&lt;namespace&gt;[name] = f"]
    end
    subgraph Render["Request time"]
        R1["Template source"] --> R2["Jinja compiler<br/>resolves names from namespaces"]
        R3["Renders value|filter,<br/>value is test,<br/>global(...)"] --> R4["Response body"]
    end
    F3 -.->|"environment shared"| R2
```

---

## 4. Test Suite Map (`tests/test_templating.py`)

The module is test-only; the 17 tests form a matrix over **{filter, test, global} × {decorator, imperative} × {default name, custom name} × {registry-only, end-to-end render}**.

### Filters (8 tests)

| Test | Style | Name | E2E render |
|---|---|---|---|
| `test_template_filter` | decorator | default (`my_reverse`) | no |
| `test_template_filter_with_name` | decorator | custom (`strrev`) | no |
| `test_template_filter_with_template` | decorator | default | yes (`template_filter.html`) |
| `test_template_filter_with_name_and_template` | decorator | custom (`super_reverse`) | yes |
| `test_add_template_filter` | imperative | default | no |
| `test_add_template_filter_with_name` | imperative | custom (`strrev`) | no |
| `test_add_template_filter_with_template` | imperative | default | yes |
| `test_add_template_filter_with_name_and_template` | imperative | custom (`super_reverse`) | yes |

### Tests (8 tests)

| Test | Style | Name | E2E render |
|---|---|---|---|
| `test_template_test` | decorator | default (`boolean`) | no |
| `test_template_test_with_name` | decorator | custom (`boolean` for `is_boolean`) | no |
| `test_template_test_with_template` | decorator | default | yes (`template_test.html` renders `Success!`) |
| `test_template_test_with_name_and_template` | decorator | custom | yes |
| `test_add_template_test` | imperative | default | no |
| `test_add_template_test_with_name` | imperative | custom | no |
| `test_add_template_test_with_template` | imperative | default | yes |
| `test_add_template_test_with_name_and_template` | imperative | custom | yes |

### Globals (1 test)

| Test | Style | Name | Verification |
|---|---|---|---|
| `test_add_template_global` | decorator (`@app.template_global()`) | default (`get_stuff`) | registry membership + identity + `render_template_string("{{ get_stuff() }}") == "42"` in an app context |

### Invariants asserted across the family

- Registered callable identity is preserved (`app.jinja_env.filters["my_reverse"] is my_reverse` semantics via `==`).
- A custom name fully replaces the namespace key; the function's own name is *not* registered when a name is given.
- Custom filters/tests/globals are usable from the same environment that also carries Flask's built-ins (`request`, `g`, `session`, `config`) — several sibling tests in the same file combine both (e.g., context processors feeding values alongside custom globals).
- End-to-end cases confirm the customization survives the `DispatchingJinjaLoader` lookup and full render cycle through `app.test_client()`.

---

## 5. How This Module Fits into the Overall System

- **At setup time**, applications call the registration API (usually in the module that creates the app, or in a blueprint). The API is deliberately tiny — six methods, one dict assignment each — and is locked after the first request to keep rendering deterministic.
- **At render time**, every `render_template` / `render_template_string` / `stream_template` call (see [templating_rendering_context](templating_rendering_context.md)) resolves template syntax against the namespaces this module populates. Nothing in the render path is aware of "customization" — Jinja simply looks up names in `filters`, `tests`, and `globals`.
- **For blueprints**, the same API enables per-component template languages: a blueprint can register filters/tests/globals that become available app-wide once registered, and templates are discovered per blueprint by the dispatching loader (see [templating_environment_loader](templating_environment_loader.md), [blueprints_test_suite](blueprints_test_suite.md)).
- **For extensions**, this is also the canonical pattern: an extension receives the app and calls `app.add_template_filter(...)` etc. during initialization, exactly like application code.

### Guidance for maintainers

- Any change to `create_jinja_environment()` must keep the invariant that user registrations land on the *same* environment instance that rendering uses — the cached-property indirection (`jinja_env`) is the single source of truth.
- Keep the decorator → imperative delegation structure: the imperative methods are the only place that should touch `env.filters/tests/globals`.
- Preserve the `name or f.__name__` resolution and the "return `f` unchanged" decorator contract; the test suite asserts both.
- Remember the asymmetry in test coverage (globals tested decorator-only, without a file-based E2E case) when adding features: new extension points should be added to *both* styles here, or the matrix tests should be extended deliberately.

---

## 6. Related Documentation

- [Request_Services___Response_Rendering](Request_Services___Response_Rendering.md) — parent module group (helpers, sessions, templating, JSON).
- [templating_rendering_context](templating_rendering_context.md) — rendering functions, context processors, streaming.
- [templating_environment_loader](templating_environment_loader.md) — `Environment`, `DispatchingJinjaLoader`, auto-reload and loader debugging.
- [application-core_sansio-foundation](application-core_sansio-foundation.md) — `Scaffold`, sansio `App`, `setupmethod` and the setup lock.
- [application-core_flask-app](application-core_flask-app.md) — concrete `Flask` class and request lifecycle.
- [blueprints_registration_machinery](blueprints_registration_machinery.md) / [blueprints_resources_and_cli](blueprints_resources_and_cli.md) — blueprint-side registration, including the same template customization API.
- [json-serialization](json-serialization.md) — JSON provider and the `tojson` policy wired into the Jinja environment.
- [configuration](configuration.md) — `TEMPLATES_AUTO_RELOAD`, `EXPLAIN_TEMPLATE_LOADING` and related config keys.
- [test-infrastructure](test-infrastructure.md) / [testing-support](testing-support.md) — fixtures (`app`, `client`, `app_ctx`, `req_ctx`) and the test client used by this module's tests.
