# Helpers Module (`flask.helpers`)

## 1. Purpose and Scope

The **helpers module** (`src/flask/helpers.py`) is Flask's toolbox of user-facing utility functions that application and extension developers call from *inside view functions, templates and CLI commands*. It concentrates the small, everyday operations of web development:

- **Building responses** — `make_response`, `redirect`, `abort`
- **Generating URLs** — `url_for`
- **Streaming responses** — `stream_with_context`
- **Serving files** — `send_file`, `send_from_directory`
- **User messaging** — `flash`, `get_flashed_messages`
- **Template access from Python** — `get_template_attribute`
- **Environment & introspection flags** — `get_debug_flag`, `get_load_dotenv`, `get_root_path`, `_split_blueprint_path`

The module is intentionally a set of **thin, context-aware wrappers**: the real behaviour lives in the `Flask` application object (see [application-core](application-core.md)) or in Werkzeug. Helpers only *resolve the right delegate* for the current situation — most importantly, whether an application/request context is currently active.

- **Implementation:** `src/flask/helpers.py`
- **Tests:** `tests/test_helpers.py`
- **Parent group:** Request Services & Response Rendering (siblings: [sessions](sessions.md), [templating](templating.md), [json-serialization](json-serialization.md))

---

## 2. Architecture Overview

### 2.1 Delegation pattern

Every request-scoped helper follows the same two-step design:

1. **Resolve context** through the `LocalProxy` objects exported by `flask.globals` (`current_app`, `request`, `session`, `request_ctx`). These proxies are backed by `ContextVar`s that the context machinery in [contexts](contexts.md) pushes/pops.
2. **Delegate** to the corresponding `Flask` method (so apps and extensions can override behaviour) or fall back to the equivalent Werkzeug function when no app is bound.

```mermaid
flowchart TB
    subgraph USER["User code"]
        V["View functions / templates"]
        CLI["CLI commands"]
    end

    subgraph HELP["flask.helpers"]
        CORE["Core response helpers<br/>make_response · url_for · redirect · abort"]
        STREAM["stream_with_context"]
        FILES["send_file · send_from_directory<br/>_prepare_send_file_kwargs"]
        FLASH["flash · get_flashed_messages"]
        UTIL["get_template_attribute · get_root_path<br/>_split_blueprint_path"]
        ENVF["get_debug_flag · get_load_dotenv"]
    end

    subgraph GLOBALS["flask.globals — LocalProxy context locals"]
        CA["current_app"]
        REQ["request"]
        SESS["session"]
        RCTX["request_ctx / _cv_request"]
    end

    subgraph APP["Flask application — application-core"]
        AM["Flask.make_response"]
        AU["Flask.url_for"]
        AR["Flask.redirect"]
        AA["Flask.aborter"]
        JE["Flask.jinja_env"]
        GM["Flask.get_send_file_max_age"]
    end

    subgraph WZ["Werkzeug — fallbacks when no app is bound"]
        WR["werkzeug.utils.redirect"]
        WA["werkzeug.exceptions.abort"]
        WSF["werkzeug.utils.send_file / send_from_directory"]
    end

    SIG["flask.signals.message_flashed"]
    SESM["flask.sessions — session storage"]

    V --> CORE & STREAM & FILES & FLASH & UTIL
    CLI --> ENVF
    CORE --> CA
    STREAM --> RCTX
    FILES --> REQ & CA
    FLASH --> SESS & SIG
    UTIL --> CA
    CA --> AM & AU & AR & AA & JE & GM
    AR -. "no app context" .-> WR
    AA -. "no app context" .-> WA
    FILES --> WSF
    SESS --> SESM
```

### 2.2 Why the fallback matters

`redirect()` and `abort()` are the only helpers usable **without** an application context. They probe the `current_app` proxy truthiness and degrade gracefully to Werkzeug. All other helpers (`make_response`, `url_for`, `flash`, `send_file`, …) *require* an active context and raise `RuntimeError` (via the proxy's unbound message) when used outside one.

```mermaid
flowchart TD
    S["redirect(location, code) / abort(code)"] --> C{"current_app<br/>bound?"}
    C -->|yes| A["current_app.redirect / current_app.aborter<br/>(app + extensions can override)"]
    C -->|no| W["werkzeug.utils.redirect /<br/>werkzeug.exceptions.abort"]
```

---

## 3. Functional Areas

### 3.1 Response construction — `make_response`, `redirect`, `abort`

These are the **core components** of the module and the ones views interact with most.

| Component | Signature (simplified) | Delegates to | Notes |
|---|---|---|---|
| `make_response` | `(*args) -> Response` | `current_app.make_response` | Accepts exactly what a view may return. 0 args → `current_app.response_class()`; 1 arg → passed through; ≥2 args → passed as a **tuple** (e.g. `(body, status, headers)`). Intended for attaching headers/cookies to a value before returning it. *(since 0.6)* |
| `redirect` | `(location, code=302, Response=None) -> BaseResponse` | `current_app.redirect` **or** `werkzeug.utils.redirect` | App-aware since 2.2. The `Response` class argument is only honoured in the Werkzeug fallback path; with an app bound, `app.response_class` is used. |
| `abort` | `(code, *args, **kwargs) -> NoReturn` | `current_app.aborter` **or** `werkzeug.exceptions.abort` | Raises an `HTTPException` (never returns). Status codes must be registered in the aborter mapping; apps can swap `Flask.aborter_class` or register extra codes (e.g. a custom `code = 900` exception). |

```mermaid
sequenceDiagram
    participant V as View function
    participant H as helpers.make_response
    participant P as current_app (LocalProxy)
    participant A as Flask.make_response
    V->>H: make_response(render_template(...), 404)
    H->>P: attribute lookup (requires active app context)
    P->>A: delegate with normalized args
    A-->>V: Response object (status/headers now editable)
    Note over V: view returns the enriched Response
```

> The full normalisation rules (tuples, generator bodies, status-in-tuple, etc.) are implemented in `Flask.make_response` and documented in [application-core](application-core.md); error handling of raised `HTTPException`s is covered by the application-core error-handler machinery and [contexts](contexts.md) teardown behaviour.

### 3.2 URL generation — `url_for`

```python
url_for(endpoint, *, _anchor=None, _method=None, _scheme=None,
        _external=None, **values) -> str
```

- A thin pass-through to **`current_app.url_for`** (since 2.2), which performs the actual adapter-based URL building against the URL map. See [application-core](application-core.md) for rule matching, endpoint resolution and `handle_url_build_error` handling.
- Underscore-prefixed keyword arguments control URL *shape* (`#anchor`, HTTP `_method` selection, `_scheme`, `_external`); every other keyword fills a variable part of the rule, with leftovers appended as a query string.
- Requires an active **request or application** context; endpoint names starting with `.` are resolved relative to the current blueprint (see [blueprints](blueprints.md)).
- `_scheme` implies an external URL; passing `_external=False` together with `_scheme` raises `ValueError`.

### 3.3 Streaming responses — `stream_with_context`

Request contexts are torn down as soon as the response starts, so a generator producing a streamed response would otherwise lose access to `request`/`session`. `stream_with_context` bridges this gap by **re-pinning the request context for the lifetime of the generator**.

```mermaid
flowchart LR
    subgraph View["View — request context active"]
        A["stream_with_context(gen)<br/>(or used as @decorator)"]
        B["Wrap generator:<br/>ctx = _cv_request.get(None)<br/>RuntimeError if absent"]
        C["'with ctx:' re-pins context<br/>yield None  (dummy sentinel)<br/>next(wrapped_g) consumes sentinel"]
    end
    subgraph Server["WSGI streaming — context already popped"]
        D["Iteration continues:<br/>'yield from gen' still inside 'with ctx'"]
        E["finally: gen.close()<br/>(also for non-generator WSGI iterators)"]
    end
    A --> B --> C --> D --> E
```

Key mechanics:

- **Dual usage**: called directly with an iterator, or as a decorator around a generator function (`update_wrapper` preserves metadata).
- **Sentinel trick**: starting the wrapped generator runs it up to the dummy `None` yield — at that point the context has been pushed; the sentinel is discarded and real iteration begins.
- **Cleanup**: `finally` closes generators *and* WSGI-level iterators with a `close()` method (verified by `TestStreaming.test_streaming_with_context_and_custom_close`).
- Session writes performed while streaming are preserved (`test_stream_keeps_session`).

### 3.4 File serving — `send_file`, `send_from_directory`

Both functions funnel through `_prepare_send_file_kwargs`, which injects Flask-specific settings before delegating to Werkzeug:

```mermaid
flowchart TD
    U["send_file(path_or_file, ...) / send_from_directory(directory, path, ...)"] --> P["_prepare_send_file_kwargs<br/>max_age → current_app.get_send_file_max_age<br/>environ → request.environ<br/>USE_X_SENDFILE from app config<br/>response_class → app.response_class<br/>_root_path → app.root_path"]
    P --> W["werkzeug.utils.send_file / send_from_directory<br/>ETags, conditional & range requests,<br/>X-Sendfile, file_wrapper"]
```

| Function | Behaviour |
|---|---|
| `send_file` | Sends a path **relative to the app root** (or an open binary file object). Detects MIME type and `Last-Modified` from the path, computes ETags, supports conditional/range responses and `X-Sendfile`. **Security:** never pass client-supplied paths here. |
| `send_from_directory` | Safe directory serving: validates the client path with `werkzeug.security.safe_join` and raises 404 `NotFound` for anything outside the directory or not an existing regular file. This is what powers the static file route. |

Related configuration keys (`USE_X_SENDFILE`, `SEND_FILE_MAX_AGE_DEFAULT`) are described in [configuration](configuration.md); the static-file route that builds on `send_from_directory` is part of [application-core](application-core.md).

### 3.5 Flash messages — `flash`, `get_flashed_messages`

A two-request mechanism on top of the session (see [sessions](sessions.md)) plus the `message_flashed` blinker signal (see [signals tests](application-core.md) — `tests/test_signals.py::test_flash_signal`).

```mermaid
sequenceDiagram
    participant R1 as Request N (view)
    participant F as flash()
    participant S as session
    participant SIG as message_flashed signal
    participant R2 as Request N+1 (template)
    participant G as get_flashed_messages()
    participant RC as request_ctx.flashes

    R1->>F: flash("Saved", "info")
    F->>S: read _flashes list, append ("info", "Saved"), reassign session["_flashes"]
    F->>SIG: send(current_app, message, category) via app.ensure_sync
    Note over S: session persisted with the response
    R2->>G: get_flashed_messages(with_categories, category_filter)
    G->>S: pop("_flashes") — consumed once
    G->>RC: cache result on request_ctx for repeated calls
    G-->>R2: messages or (category, message) tuples
```

Implementation notes:

- `flash` deliberately **reassigns** the whole `_flashes` list instead of mutating it in place — in-place mutation is invisible to session backends with external storage (the code comment documents this pitfall).
- `get_flashed_messages` caches the popped list in `request_ctx.flashes`, so repeated calls in the same request return identical data; `category_filter` narrows by category, `with_categories` switches between plain messages and `(category, message)` tuples.

### 3.6 Template & introspection utilities

| Component | Purpose |
|---|---|
| `get_template_attribute(template_name, attribute)` | Loads a macro/variable exported by a template through `current_app.jinja_env` (template loading itself is documented in [templating](templating.md)). |
| `get_root_path(import_name)` *(private)* | Locates the filesystem directory of a module/package: ① `sys.modules` `__file__`, ② `importlib.util.find_spec` loader, ③ import fallback, ④ current working directory. Raises `RuntimeError` for namespace packages without file info. Avoids unconditional `__import__` so broken apps can still be introspected (see `TestNoImports`). |
| `_split_blueprint_path(name)` *(private, `@cache`)* | Expands a dotted blueprint name into all ancestors, e.g. `"a.b.c"` → `["a.b.c", "a.b", "a"]`. Used by blueprint registration to chain nested blueprints (see [blueprints](blueprints.md)). |

### 3.7 Environment flags — `get_debug_flag`, `get_load_dotenv`

| Component | Env var | Semantics |
|---|---|---|
| `get_debug_flag()` | `FLASK_DEBUG` | `True` unless unset or one of `0 / false / no` (case-insensitive). Used at app bootstrap and by the CLI to derive debug mode (see [command-line-interface](command-line-interface.md)). |
| `get_load_dotenv(default=True)` | `FLASK_SKIP_DOTENV` | Whether the CLI should load `.env`/`.flaskenv` files; returns `default` when unset. |

---

## 4. Position in the Request Lifecycle

```mermaid
sequenceDiagram
    participant C as Client / FlaskClient
    participant WSGI as WSGI stack
    participant RC as RequestContext (contexts)
    participant V as View function
    participant H as flask.helpers

    C->>WSGI: HTTP request
    WSGI->>RC: push app + request context
    RC->>V: dispatch
    V->>H: url_for / flash / send_file / make_response / abort
    H->>V: Response (or raised HTTPException)
    V->>WSGI: return response
    Note over H: stream_with_context keeps RC alive<br/>beyond response start for streaming
    WSGI->>RC: pop context → teardown callbacks
```

---

## 5. Testing Coverage (`tests/test_helpers.py`)

Tests rely on the shared fixtures `app`, `req_ctx`, `client`, `modules_tmp_path` defined in `tests/conftest.py` — see [test-infrastructure](test-infrastructure.md). End-to-end client behaviour is described in [testing-support](testing-support.md).

| Test group | Validates |
|---|---|
| `TestSendfile` | `send_file` passthrough & MIME type; `SEND_FILE_MAX_AGE_DEFAULT` and `get_send_file_max_age` overrides; `pathlib.Path`/`FakePath` (PEP 519 `__fspath__`) support; `send_from_directory` content serving. |
| `TestUrlFor` | `_anchor` escaping (`x y` → `x%20y`), `_scheme` + `_external` interplay and `ValueError` on `_external=False`, alternating schemes, `_method` selection across `MethodView` rules, `self` usable as a rule variable. |
| `TestStreaming` | `stream_with_context` as call and decorator, `close()` propagation to wrapped iterators, session visibility inside streamed generators. |
| `TestHelpers` | `get_debug_flag` truthiness table (`""`, `0`, `False`, `No`, `True`); `make_response` defaults (status 200, `text/html`) and body conversion. |
| `test_redirect_no_app` / `test_redirect_with_app` | Werkzeug fallback without app (custom status 307 preserved); app override path (`app.redirect` replaces implementation). |
| `test_abort_no_app` / `test_abort_with_app` / `test_app_aborter_class` | Werkzeug fallback and `LookupError` for unknown codes; custom `HTTPException` registered under code 900; swapping `Flask.aborter_class`. |
| `TestNoImports` | `Flask(import_name)` never imports the target module — underpins the lazy strategy in `get_root_path`. |
| `test_open_resource*` | `app.open_resource` valid modes (`r`, `rb`, `rt`), `ValueError` for write modes (`w`, `x`, `a`, `r+`), explicit `encoding` handling. |

```mermaid
flowchart LR
    subgraph Tests["tests/test_helpers.py"]
        T1["TestSendfile"]
        T2["TestUrlFor"]
        T3["TestStreaming"]
        T4["TestHelpers"]
        T5["redirect / abort tests"]
        T6["TestNoImports · open_resource tests"]
    end
    T1 --> F["send_file · send_from_directory"]
    T2 --> U["url_for"]
    T3 --> S["stream_with_context"]
    T4 --> MR["make_response · get_debug_flag"]
    T5 --> RA["redirect · abort"]
    T6 --> RP["get_root_path design · app.open_resource"]
```

---

## 6. Relationship to Other Modules

| Module | Relationship |
|---|---|
| [application-core](application-core.md) | Hosts the real implementations helpers delegate to: `Flask.make_response`, `Flask.url_for`, `Flask.redirect`, `Flask.aborter`, `Flask.jinja_env`, `Flask.get_send_file_max_age`, `Flask.open_resource`. |
| [contexts](contexts.md) | `AppContext`/`RequestContext` push/pop make the `LocalProxy` globals (`current_app`, `request`, `session`, `request_ctx`) resolvable; `stream_with_context` and the flash cache depend directly on them. |
| [sessions](sessions.md) | `flash`/`get_flashed_messages` store and consume `_flashes` through the session object. |
| [templating](templating.md) | `get_template_attribute` reads templates/macros from the Jinja `Environment`. |
| [configuration](configuration.md) | Supplies `USE_X_SENDFILE` and `SEND_FILE_MAX_AGE_DEFAULT` used by file serving. |
| [blueprints](blueprints.md) | `_split_blueprint_path` supports nested blueprint registration; `url_for` resolves `.`-prefixed endpoints. |
| [command-line-interface](command-line-interface.md) | `get_debug_flag` / `get_load_dotenv` drive CLI bootstrap and dotenv loading. |
| [testing-support](testing-support.md) | `FlaskClient`/`EnvironBuilder` exercise these helpers in tests; session transactions rely on flash semantics. |
| [json-serialization](json-serialization.md) | Sibling rendering service; commonly combined with `make_response` (e.g. `jsonify` results passed through response building). |

---

## 7. API Quick Reference

| Helper | Import | App context required | Since |
|---|---|---|---|
| `make_response(*args)` | `flask.make_response` | ✅ required | 0.6 |
| `url_for(endpoint, ...)` | `flask.url_for` | ✅ request or app | 0.9 (`_anchor`, `_method`), 0.10 (`_scheme`), 2.2 (app override) |
| `redirect(location, code=302, Response=None)` | `flask.redirect` | optional (Werkzeug fallback) | 2.2 (app override) |
| `abort(code, *args, **kwargs)` | `flask.abort` | optional (Werkzeug fallback) | 2.2 (app override) |
| `stream_with_context(gen_or_fn)` | `flask.stream_with_context` | ✅ request (inside view) | 0.9 |
| `send_file(...)`, `send_from_directory(...)` | `flask.send_file` / `flask.send_from_directory` | ✅ required | 2.0 (Werkzeug-backed) |
| `flash(message, category)`, `get_flashed_messages(...)` | `flask.flash` / `flask.get_flashed_messages` | ✅ required | 0.3 / 0.9 |
| `get_template_attribute(template, attr)` | `flask.get_template_attribute` | ✅ required | 0.2 |
| `get_debug_flag()`, `get_load_dotenv()` | `flask.helpers` | ❌ plain env lookups | 2.2 / 1.0 |
