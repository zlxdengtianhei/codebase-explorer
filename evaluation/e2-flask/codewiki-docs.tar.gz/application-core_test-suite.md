# Application Core Test Suite (`application-core_test-suite`)

> **Parent module:** [application-core](application-core.md) · **Group:** *Core Application Engine & Modular Composition*
> **Siblings:** [application-core_flask-app](application-core_flask-app.md) · [application-core_sansio-foundation](application-core_sansio-foundation.md) · [application-core_debug-helpers](application-core_debug-helpers.md) · [contexts](contexts.md) · [blueprints](blueprints.md)

---

## 1. Overview

The `application-core_test-suite` module is the **executable behavioral specification** of the Flask application core. It contains **no production code**: every component is a `pytest` test function that pins down observable, user-facing behavior of the `Flask` application object and its collaborators (contexts, sessions, error handling, views, signals, static files, and instance layout).

Where the sibling implementation modules define *how* the application engine works internally, this module defines the **contract** that must keep working:

| Aspect | Description |
|---|---|
| Module type | Test-only (pytest test modules under `tests/`) |
| Entry point | `pytest tests/` (see [test-infrastructure](test-infrastructure.md) for fixtures and `conftest.py`) |
| System under test | `Flask` ([application-core_flask-app](application-core_flask-app.md)), sans-io scaffold ([application-core_sansio-foundation](application-core_sansio-foundation.md)), debug helpers ([application-core_debug-helpers](application-core_debug-helpers.md)) |
| Indirect subjects | Contexts, blueprints, sessions, configuration, signals, views (see dependency map below) |
| Test tooling | [testing-support](testing-support.md) (`FlaskClient`, `EnvironBuilder`) and [test-infrastructure](test-infrastructure.md) (shared fixtures) |

> ℹ️ Each test file listed here also contains additional tests that belong to the parent [application-core](application-core.md) aggregation module. This module owns a curated subset of the most fundamental behaviors.

---

## 2. Position in the Architecture

This module sits as a **leaf of the application-core family**. It consumes the shared pytest fixtures from the *Developer Interface & Testing Tooling* group and drives the production modules of the *Core Application Engine* group end-to-end through the WSGI test client.

```mermaid
flowchart TB
    subgraph ACE["Core Application Engine & Modular Composition"]
        direction TB
        AC["application-core<br/>(parent aggregation)"]
        TS["★ application-core_test-suite<br/>(this module)"]
        FA["application-core_flask-app<br/>(Flask, _make_timedelta)"]
        SF["application-core_sansio-foundation<br/>(setupmethod, _make_timedelta)"]
        DH["application-core_debug-helpers<br/>(DebugFilesKeyError, FormDataRoutingRedirect)"]
        CX["contexts<br/>(AppContext, RequestContext, _AppCtxGlobals)"]
        BP["blueprints<br/>(Blueprint, BlueprintSetupState)"]
        AC --> FA
        AC --> SF
        AC --> DH
        AC --> TS
        AC --> CX
        AC --> BP
    end

    subgraph DIT["Developer Interface & Testing Tooling"]
        TST["testing-support<br/>(FlaskClient, EnvironBuilder, FlaskCliRunner)"]
        TI["test-infrastructure<br/>(conftest fixtures)"]
    end

    TS -- "instantiates per-test app" --> TI
    TS -- "drives requests through" --> TST
    TS -- "validates behavior of" --> FA
    TS -- "validates setup locking" --> SF
    TS -- "validates debug UX" --> DH
    TS -- "relies on push/pop semantics" --> CX
    TS -- "relies on handler scoping" --> BP
```

### How a test reaches the production code

```mermaid
flowchart LR
    A["pytest collects<br/>tests/"] --> B["Per-test fixtures:<br/>app → client / app_ctx / req_ctx"]
    B --> C["Test body registers routes,<br/>handlers, hooks on the app"]
    C --> D["FlaskClient sends synthetic<br/>WSGI requests"]
    D --> E["Assertions on responses,<br/>headers, cookies, signals"]
    E --> F["leak_detector teardown:<br/>assert no leaked request contexts"]
```

---

## 3. Test Module Inventory

| Test file | Coverage focus | Components owned by this module | Primary production code validated |
|---|---|---|---|
| `tests/test_basic.py` | Application primitives: sessions, flashing, static files, subdomains, error handlers, error trapping | `test_session`, `test_flashes`, `test_session_secret_key_fallbacks`, `test_static_files`, `test_static_url_path`, `test_subdomain_matching`, `test_errorhandler_precedence`, `test_trap_bad_request_key_error` | `Flask` ([application-core_flask-app](application-core_flask-app.md)), `Config` ([configuration](configuration.md)), session interface ([sessions](sessions.md)) |
| `tests/test_async.py` | Coroutine (async) support in routes, hooks and error handlers | `test_async_before_after_request`, `test_async_error_handler` | `Flask.ensure_sync` pipeline ([application-core_flask-app](application-core_flask-app.md)), blueprints |
| `tests/test_views.py` | Class-based views | `test_basic_view`, `test_method_based_view`, `test_init_once` | `flask.views.View` / `MethodView` / `as_view` |
| `tests/test_request.py` | Request limits and host trust | `test_max_content_length` | Request ↔ `Config` bridging ([configuration](configuration.md), [application-core_flask-app](application-core_flask-app.md)) |
| `tests/test_signals.py` | Blinker signal integration | `test_appcontext_signals`, `test_request_exception_signal` | `flask.signals`, contexts ([contexts](contexts.md)) |
| `tests/test_user_error_handler.py` | Error-handler registration and dispatch semantics | `test_error_handler_blueprint`, `test_default_error_handler` | `Flask.errorhandler` / `register_error_handler`, `Blueprint.errorhandler` |
| `tests/test_instance_config.py` | Instance-path resolution for installed/uninstalled apps | `test_uninstalled_module_paths` | `Flask.__init__` root/instance path logic |
| `tests/test_regression.py` | Regression pinning | `test_aborting` | `flask.abort` through the error-handling path |
| `tests/test_subclassing.py` | Subclass extension points | `test_suppressed_exception_logging` | `Flask.log_exception` hook ([logging](logging.md)) |

---

## 4. Test Infrastructure & Fixtures

All tests in this module build on the shared fixtures defined in `tests/conftest.py` (full details in [test-infrastructure](test-infrastructure.md)). The fixtures most relevant here:

| Fixture | Definition | Used for |
|---|---|---|
| `app` | `Flask("flask_test", root_path=...)` with `TESTING=True` and `SECRET_KEY="test key"` | The system under test; a fresh, exception-propagating app per test |
| `client` | `app.test_client()` | Driving full request/response cycles ([testing-support](testing-support.md)) |
| `app_ctx` | `with app.app_context() as ctx: yield ctx` | Tests that need `current_app` / `g` without a request |
| `req_ctx` | `with app.test_request_context() as ctx: yield ctx` | Tests that need a bound request (e.g. `test_flashes`) |
| `leak_detector` | Autouse teardown that pops and asserts **no leaked request contexts** | Guarantees context hygiene across the suite (pairs with [contexts](contexts.md)) |
| `modules_tmp_path`, `purge_module`, `site_packages`, `test_apps` | Filesystem scaffolding for import-based tests | `test_uninstalled_module_paths` and siblings |

Because the `app` fixture sets `TESTING=True`, exceptions raised in views propagate to the test by default; tests that exercise production error paths explicitly set `app.testing = False` or configure `PROPAGATE_EXCEPTIONS` (see `test_errorhandler_precedence` context and the `TestGenericHandlers` fixture in the same file).

---

## 5. Test-to-Production Dependency Map

```mermaid
flowchart LR
    subgraph Tests["Test modules (this module)"]
        TB["test_basic.py"]
        TA["test_async.py"]
        TV["test_views.py"]
        TQ["test_request.py"]
        TSg["test_signals.py"]
        TU["test_user_error_handler.py"]
        TIc["test_instance_config.py"]
        TRg["test_regression.py"]
        TSu["test_subclassing.py"]
    end

    subgraph Prod["Validated production code"]
        APP["flask.app :: Flask<br/>(dispatch, error handling,<br/>static, url_map)"]
        SANS["flask.sansio.scaffold<br/>:: setupmethod"]
        DBG["flask.debughelpers"]
        CTX["flask.ctx :: AppContext /<br/>RequestContext"]
        SESS["flask.sessions ::<br/>SecureCookieSession"]
        CFG["flask.config :: Config"]
        SIG["flask.signals"]
        VW["flask.views :: View /<br/>MethodView"]
        BLU["flask.blueprints :: Blueprint"]
        REQ["Request wrappers"]
        LOG["Flask.log_exception"]
    end

    TB --> APP
    TB --> SESS
    TB --> CFG
    TB --> DBG
    TA --> APP
    TA --> BLU
    TV --> VW
    TV --> APP
    TQ --> REQ
    TQ --> CFG
    TSg --> SIG
    TSg --> CTX
    TU --> APP
    TU --> BLU
    TIc --> APP
    TRg --> APP
    TSu --> LOG
```

**Documentation references (avoid duplication):**

- Dispatch pipeline, `full_dispatch_request`, `make_response` rules → [application-core_flask-app](application-core_flask-app.md)
- First-request setup locking (`@setupmethod`) → [application-core_sansio-foundation](application-core_sansio-foundation.md)
- Debug UX exceptions (`DebugFilesKeyError`, `FormDataRoutingRedirect`) → [application-core_debug-helpers](application-core_debug-helpers.md)
- Context push/pop and teardown semantics → [contexts](contexts.md)
- Blueprint registration and handler scoping → [blueprints](blueprints.md)
- Config loading sources → [configuration](configuration.md)
- Session serialization (`TaggedJSONSerializer`) → [sessions](sessions.md)
- HTTP client internals → [testing-support](testing-support.md)

---

## 6. Behavioral Contracts (Deep Dives)

### 6.1 Sessions and Flashing — `tests/test_basic.py`

| Test | Contract pinned |
|---|---|
| `test_session` | Writing to `flask.session` marks it `accessed` **and** `modified`; a plain read only marks it `accessed`. A `Set-Cookie` header is emitted only when the session was modified. |
| `test_session_secret_key_fallbacks` | **Key rotation safety:** a cookie signed with the previous `SECRET_KEY` becomes unreadable (session appears empty) unless the old keys are listed in `SECRET_KEY_FALLBACKS`. Restoring the old keys as fallbacks makes the existing session loadable again — enabling zero-downtime secret rotation. |
| `test_flashes` | `flash()` appends to the session and marks it modified; `get_flashed_messages()` returns messages **and consumes them** (the session is popped). Requires a request context (uses the `req_ctx` fixture). |

```mermaid
sequenceDiagram
    autonumber
    participant Test as test_session
    participant Client as FlaskClient (client fixture)
    participant App as Flask.full_dispatch_request
    participant View as view "set"
    participant Session as SecureCookieSession
    participant After as after_request funcs

    Test->>Client: post("/set", data={"value": "42"})
    Client->>App: synthetic WSGI environ
    App->>App: push RequestContext + AppContext (see contexts)
    App->>View: dispatch after before-request funcs
    View->>Session: session["value"] = "42"<br/>(accessed=True, modified=True)
    View-->>After: response "value set"
    Session->>Session: serialize + sign with SECRET_KEY
    After-->>Client: 200 + Set-Cookie (emitted because modified)
    App->>App: teardown funcs + pop contexts
    Client-->>Test: "value set"
    Test->>Client: get("/get")
    Note over Session: loads cookie via current and fallback keys<br/>read-only access means no new Set-Cookie
    Client-->>Test: "42"
```

Session cookie attributes (`SESSION_COOKIE_*` config), expiration, `Vary` behavior and special-type serialization are owned by the parent module and detailed in [sessions](sessions.md) / [configuration](configuration.md).

### 6.2 Static Files and URL Building — `tests/test_basic.py`

- **`test_static_files`** — the default app exposes a `/static/<filename>` route backed by the package `static/` folder; `url_for("static", filename="index.html")` round-trips to the same path.
- **`test_static_url_path`** — `static_url_path` constructor argument remounts the static route (`/foo/index.html`) and is honored by `url_for`.
- **`test_subdomain_matching`** — with `SERVER_NAME` configured and `subdomain_matching=True`, rules declared with `subdomain="<user>"` capture the leading DNS label of the request host and pass it as a URL variable (`mitsuhiko.localhost.localdomain` → `user="mitsuhiko"`). Server-name/subdomain variants (ports, host matching, mismatch warnings) are covered by the parent module.

### 6.3 Error Handling — `tests/test_basic.py`, `tests/test_user_error_handler.py`, `tests/test_regression.py`

This is the largest contract surface of the module. The verified resolution algorithm:

```mermaid
flowchart TD
    EXC["Exception raised in view or<br/>before-/after-request processor"] --> CHK{"Trap enabled?<br/>(TRAP_HTTP_EXCEPTIONS,<br/>TRAP_BAD_REQUEST_ERRORS / debug)"}
    CHK -- "yes: trap" --> PROP1["Exception propagates to the caller<br/>(test_trap_bad_request_key_error)"]
    CHK -- "no: handle" --> UH["Flask.handle_user_exception"]
    UH --> BPQ{"Blueprint-local handler registered for<br/>this exception class or one of its bases?"}
    BPQ -- "yes" --> RUN1["Run blueprint handler<br/>(test_error_handler_blueprint)"]
    BPQ -- "no" --> APPQ{"App-level handler for the class?<br/>Lookup walks the exception MRO —<br/>the most specific registered handler wins"}
    APPQ -- "yes" --> RUN2["Run app handler<br/>(test_errorhandler_precedence)"]
    APPQ -- "no" --> HTTPQ{"Is it an HTTPException?"}
    HTTPQ -- "yes" --> GEN["Generic HTTPException handler at the same<br/>level, else default status page<br/>(test_default_error_handler)"]
    HTTPQ -- "no" --> PROP2["Unhandled: 500 response +<br/>got_request_exception signal fired"]
```

**Pinned behaviors:**

- **`test_errorhandler_precedence`** — for an exception `E3(E1, E2)` with handlers registered for `E2` and the generic `Exception`: raising `E1` falls through to the `Exception` handler, while raising `E3` selects the `E2` handler. This proves handler selection is **MRO-based with most-specific-first** resolution, not registration order.
- **`test_trap_bad_request_key_error`** — parametrized matrix of trap behavior:

  | `DEBUG` | `TRAP_BAD_REQUEST_ERRORS` | Missing form key | `abort(400)` |
  |---|---|---|---|
  | off | default | Auto-converted to a `400 BadRequest`; **the key name is not leaked** in the response body | Returns a 400 response |
  | on | default | Trapped: `BadRequest` raised to the caller, description **contains the missing key** (developer ergonomics) | Returns a 400 response |
  | off | `True` | Trapped even without debug: `BadRequest` raised | `BadRequest` **raised** (no response) |

- **`test_default_error_handler`** — registering `@app.errorhandler(HTTPException)` acts as a *catch-all for unregistered HTTP errors*; more specific handlers (e.g. `Forbidden`) take precedence. Crucially, automatic slash-redirect `RequestRedirect` exceptions are **not** diverted into user handlers — `follow_redirects` still reaches the target view.
- **`test_error_handler_blueprint`** — a `500` handler registered on a `Blueprint` handles errors raised from the blueprint's views **only**; errors from app-level views use the app-level handler with the same code. Blueprint scoping rules are defined in [blueprints](blueprints.md).
- **`test_error_handler_after_processor_error`** (parent file, sibling tests) — exceptions raised inside before/after processors are routed to the `500` handler like view errors.
- **`test_aborting` (regression)** — `flask.abort()` may carry any `HTTPException`, including a constructed `redirect()`; the abort produces a real `302` with a `Location` header, and custom exception handlers in the same app continue to work for the follow-up request. This guards the regression where aborting with non-standard exceptions was broken.

### 6.4 Async Support — `tests/test_async.py`

The module guards the sync/async bridge (guarded by `pytest.importorskip("asgiref")` — the tests are skipped automatically when `asgiref` is not installed):

- **`test_async_error_handler`** — `async` view functions (`app.route`, `Blueprint.route`, `View.dispatch_request`, `MethodView.get/post`) and `async` error handlers all dispatch correctly through `ensure_sync`; a raised `AppError`/`BlueprintError` reaches the async handler and yields the mapped `412` status for both app and blueprint levels.
- **`test_async_before_after_request`** — `async def` functions registered via `@app.before_request`, `@app.after_request`, `@blueprint.before_request` and `@blueprint.after_request` run at the right point in the pipeline, side effects observed for both app and blueprint requests.

```mermaid
flowchart LR
    A["async route / hook / handler<br/>registered by the test"] --> B["Flask.ensure_sync wraps it<br/>(asgiref sync_to_async wrapper)"]
    B --> C["Sync WSGI pipeline calls the<br/>wrapped callable transparently"]
    C --> D["Response flows back through the<br/>normal after-request/teardown path"]
```

Async internals of the dispatch pipeline are documented in [application-core_flask-app](application-core_flask-app.md).

### 6.5 Class-Based Views — `tests/test_views.py`

- **`test_basic_view`** — subclassing `flask.views.View` and overriding `dispatch_request` works when bound via `Index.as_view("index")`; declared `methods = ["GET", "POST"]` produce the expected dispatching, a 405 for `PUT`, and an automatic `OPTIONS`/`Allow` header of `GET, HEAD, OPTIONS, POST`.
- **`test_method_based_view`** — `MethodView` maps HTTP verbs to same-named instance methods (`get`, `post`), including automatic `methods` inference and HEAD→GET fallback; unimplemented verbs answer `405`.
- **`test_init_once`** — the `init_every_request = False` class attribute flips `as_view` into reusing a **single instance across requests** (init counter stays at `1` across two requests), trading per-request state isolation for efficiency. With the default (`True`), a fresh instance is created per request.

Reference implementation notes for `View`/`MethodView` (decorators list, `provide_automatic_options`, multiple-inheritance `methods` merging) belong to the parent [application-core](application-core.md) module documentation.

### 6.6 Request Limits — `tests/test_request.py`

- **`test_max_content_length`** — with `MAX_CONTENT_LENGTH = 50`, posting a form body of 150 bytes aborts with `413 RequestEntityTooLarge` **before** the view runs, and a registered `@app.errorhandler(413)` converts it into a normal response. This pins the config → request bridging: `Request.max_content_length` consults the app config while inside an app context (Werkzeug defaults otherwise). The full limit matrix (`MAX_FORM_MEMORY_SIZE`, `MAX_FORM_PARTS`, `TRUSTED_HOSTS`) is owned by the parent module.

### 6.7 Signals — `tests/test_signals.py`

- **`test_appcontext_signals`** — a complete client request produces exactly one symmetric pair of `appcontext_pushed` / `appcontext_popped` signals with the app as sender (context lifecycle defined in [contexts](contexts.md)).
- **`test_request_exception_signal`** — an unhandled `ZeroDivisionError` in a view yields a `500` response **and** exactly one `got_request_exception` signal carrying the original exception. Signal ordering relative to before/after handlers (`request_started` → handlers → `request_finished`) is verified by `test_request_signals` in the parent module.

### 6.8 Instance Path Resolution — `tests/test_instance_config.py`

- **`test_uninstalled_module_paths`** — for a plain (not installed) module app imported from `modules_tmp_path/config_module_app.py`, `app.instance_path` resolves to `<module directory>/instance`. The sibling tests in this file cover installed modules/packages, prefix packages, namespace packages and explicit `instance_path` (with the absolute-path `ValueError` guard).

### 6.9 Subclassing & Logging — `tests/test_subclassing.py`

- **`test_suppressed_exception_logging`** — `Flask.log_exception` is a sanctioned override point: a subclass replacing it with a no-op still returns a standard `500 Internal Server Error` page but writes **nothing** to the WSGI error stream (captured via `test_client(errors_stream=...)`). This decouples error *presentation* from error *logging* ([logging](logging.md)).

---

## 7. Component Interaction Summary

```mermaid
flowchart TD
    subgraph Fixtures["tests/conftest.py (test-infrastructure)"]
        F1["app — Flask('flask_test',<br/>TESTING, SECRET_KEY)"]
        F2["client — app.test_client()"]
        F3["app_ctx / req_ctx"]
        F4["leak_detector (autouse)"]
    end

    subgraph Tests["This module's tests"]
        T1["Register routes/hooks/handlers<br/>on the fixture app"]
        T2["Send requests / assert<br/>status, body, headers, cookies"]
        T3["Observe signals & side effects"]
    end

    subgraph Engine["Application engine"]
        E1["full_dispatch_request<br/>(flask-app)"]
        E2["RequestContext / AppContext<br/>(contexts)"]
        E3["Blueprint scoping<br/>(blueprints)"]
        E4["Session interface<br/>(sessions)"]
        E5["Signals (blinker)"]
        E6["Error handler resolution<br/>(flask-app)"]
    end

    F1 --> T1
    F2 --> T2
    F3 --> T3
    F4 --> T2
    T1 --> E1
    T2 --> E2
    T2 --> E4
    T1 --> E3
    T3 --> E5
    T2 --> E6
    E6 --> E5
    E1 --> E2
    E1 --> E4
```

---

## 8. Running the Test Suite

```bash
# Whole module
pytest tests/

# A single contract
pytest tests/test_basic.py::test_session_secret_key_fallbacks
pytest tests/test_user_error_handler.py::test_default_error_handler
```

**Execution notes:**

1. **Optional async dependency** — `tests/test_async.py` calls `pytest.importorskip("asgiref")`; without `asgiref` those tests are skipped rather than failing.
2. **Platform-specific tests** — some parent-file tests (e.g. the CPython ref-count GC test `require_cpython_gc`) are skipped on non-CPython implementations.
3. **Isolation guarantees** — the autouse `leak_detector` fixture fails the run if any test leaves a request context pushed; `test_apps` / `modules_tmp_path` fixtures provide disposable import roots so filesystem-based tests (`test_instance_config.py`) never touch the real environment.
4. **Error-propagation mode** — the `app` fixture enables `TESTING=True` so contract violations surface as raised exceptions; production error-path tests explicitly disable it.

---

## 9. Related Documentation

| Module | Relationship |
|---|---|
| [application-core](application-core.md) | Parent aggregation module; owns the remaining tests in the same files |
| [application-core_flask-app](application-core_flask-app.md) | Primary system under test — dispatch, error handling, static routing, `run()` |
| [application-core_sansio-foundation](application-core_sansio-foundation.md) | Setup-method locking verified indirectly by every registration test |
| [application-core_debug-helpers](application-core_debug-helpers.md) | Debug UX errors (`test_enctype_debug_helper`, `test_routing_redirect_debugging` in parent file) |
| [contexts](contexts.md) | Context lifecycle the suite relies on and leak-checks against |
| [blueprints](blueprints.md) | Blueprint scoping exercised by `test_error_handler_blueprint`, async blueprint hooks |
| [configuration](configuration.md) | Config keys asserted by the suite (`SECRET_KEY_FALLBACKS`, `MAX_CONTENT_LENGTH`, `TRAP_*`) |
| [sessions](sessions.md) | Session interface and signed-cookie semantics |
| [logging](logging.md) | `log_exception` / WSGI error stream behavior |
| [testing-support](testing-support.md) | `FlaskClient`, `EnvironBuilder`, `FlaskCliRunner` used to drive the tests |
| [test-infrastructure](test-infrastructure.md) | `conftest.py` fixtures (`app`, `client`, `app_ctx`, `req_ctx`, `leak_detector`, …) |
