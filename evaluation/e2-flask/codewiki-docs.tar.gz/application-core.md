# Application Core — Flask Application Engine (Modular Composition)

## 1. Introduction & Purpose

The **application-core** module is the heart of Flask: it implements the central `Flask` application object — a WSGI application that acts as the **registry and orchestrator** for everything else in the framework. It owns:

- **WSGI entry point** (`wsgi_app` / `__call__`) — where every HTTP request enters and exits the framework.
- **The request lifecycle** — pushing contexts, dispatching to views, and finalizing responses.
- **Registration APIs** — `route`, `add_url_rule`, `before_request`, `after_request`, `teardown_request`, `errorhandler`, `template_filter`, blueprint registration, etc.
- **Error handling pipeline** — resolving exceptions to error handlers, HTTPExceptions, debug aids, and the final 500 `InternalServerError`.
- **Response construction** — `make_response` converts any legal view return value (str, bytes, dict, list, tuple, generator, WSGI callable, `Response`) into a real response.
- **URL building** — `url_for`, URL defaults injection, and build-error handling.
- **Developer tooling hooks** — development server (`run`), test client (`test_client`), CLI runner (`test_cli_runner`), shell context.
- **Debug diagnostics** — the `debughelpers` module that turns confusing runtime mistakes into actionable messages.

The module follows a deliberate **layered / sans-IO design**:

| Layer | File | Role |
|---|---|---|
| Shared, IO-free API | `src/flask/sansio/scaffold.py` (`Scaffold`, `setupmethod`) | Common behavior of apps *and* blueprints: decorator-based registration, static/template folders, root-path discovery |
| Sans-IO application | `src/flask/sansio/app.py` (`App`, `_make_timedelta`) | Application-wide state: config, URL map, JSON provider, logger, Jinja env factory, blueprint registry — no WSGI knowledge |
| Concrete WSGI app | `src/flask/app.py` (`Flask`) | WSGI protocol, request dispatch pipeline, error handling, response conversion, dev server & test tooling |
| Debug aids | `src/flask/debughelpers.py` | `DebugFilesKeyError`, `FormDataRoutingRedirect`, `UnexpectedUnicodeError`, template-loader explanations |
| Verification | `tests/` | ~200 behavioral, integration, regression, and type-check tests |

> **Composition over inheritance for extensions:** blueprints share `Scaffold` with the app, so the same decorator vocabulary works on both objects. See the [blueprints](blueprints.md) module for `Blueprint` and `BlueprintSetupState`.

---

## 2. Architecture Overview

### 2.1 Class Hierarchy

```mermaid
classDiagram
    class Scaffold {
        <<sansio/scaffold.py>>
        +view_functions
        +error_handler_spec
        +before_request_funcs
        +after_request_funcs
        +teardown_request_funcs
        +template_context_processors
        +url_value_preprocessors
        +url_default_functions
        +route(rule, **options)
        +add_url_rule(rule, endpoint, view_func)
        +before_request(f) / after_request(f)
        +teardown_request(f)
        +errorhandler(code_or_exc)
        +get() post() put() delete() patch()
        +static_folder / static_url_path / jinja_loader
    }
    class App {
        <<sansio/app.py>>
        +config: Config
        +url_map: Map
        +blueprints: dict
        +extensions: dict
        +json: JSONProvider
        +aborter: Aborter
        +debug: bool
        +logger: Logger
        +jinja_env: Environment
        +register_blueprint(bp, **options)
        +add_url_rule(...)
        +teardown_appcontext(f)
        +template_filter/test/global(...)
        +make_config() / make_aborter()
        +redirect(location, code)
        +handle_url_build_error()
    }
    class Flask {
        <<app.py>>
        +session_interface
        +request_class / response_class
        +cli: AppGroup
        +wsgi_app(environ, start_response)
        +full_dispatch_request()
        +dispatch_request()
        +preprocess_request() / process_response()
        +handle_user_exception(e)
        +handle_http_exception(e)
        +handle_exception(e)
        +make_response(rv)
        +url_for(endpoint, **values)
        +create_jinja_environment()
        +create_url_adapter(request)
        +run(host, port, debug)
        +test_client() / test_cli_runner()
        +app_context() / request_context()
        +ensure_sync(f) / async_to_sync(f)
    }
    class Blueprint {
        <<blueprints.py — separate module>>
    }
    Scaffold <|-- App : extends
    App <|-- Flask : extends
    Scaffold <|-- Blueprint
```

**Design intent**

- `Scaffold` holds the *shared registration vocabulary* so `Flask` and `Blueprint` expose identical decorators (`route`, `before_request`, `errorhandler`, ...), each writing into its own scoped registries keyed by `AppOrBlueprintKey` (`None` = app-wide).
- `App` (sans-IO) owns configuration and object factories but knows nothing about WSGI or request dispatch, keeping the core testable and reusable.
- `Flask` adds the **runtime**: the WSGI callable, the request pipeline, async bridging (`ensure_sync` / `async_to_sync` via `asgiref`), the development server, and the test tooling factories.

### 2.2 Component / Dependency Map

```mermaid
flowchart TB
    subgraph application-core
        FLASK[app.py::Flask]
        SANSIO_APP[sansio/app.py::App]
        SCAFFOLD[sansio/scaffold.py::Scaffold + setupmethod]
        DEBUG[debughelpers.py]
        TESTS[tests/ suite]
    end

    subgraph contexts [contexts module]
        CTX[ctx.py AppContext / RequestContext]
        GLOBALS[globals.py proxies]
    end

    subgraph blueprints_mod [blueprints module]
        BP[blueprints.py Blueprint]
        BSS[sansio/blueprints.py BlueprintSetupState]
    end

    subgraph config_mod [Runtime Configuration]
        CONF[config.py Config / ConfigAttribute]
        LOG[logging.py create_logger]
    end

    subgraph services [Request Services & Response Rendering]
        HELP[helpers.py make_response/redirect/url_for]
        SESS[sessions.py SessionInterface]
        TEMPL[templating.py Environment / DispatchingJinjaLoader]
        JSONM[json/provider.py JSONProvider]
    end

    subgraph devtools [Developer Interface & Testing]
        CLI[cli.py FlaskGroup / ScriptInfo]
        TESTING[testing.py FlaskClient / FlaskCliRunner]
        WRAP[wrappers.py Request / Response]
    end

    FLASK --> SANSIO_APP --> SCAFFOLD
    FLASK --> CTX
    FLASK --> GLOBALS
    FLASK --> SESS
    FLASK --> TEMPL
    FLASK --> HELP
    FLASK --> TESTING
    FLASK --> CLI
    FLASK --> WRAP
    FLASK --> DEBUG
    SANSIO_APP --> CONF
    SANSIO_APP --> LOG
    SANSIO_APP --> JSONM
    SANSIO_APP --> TEMPL
    SANSIO_APP --> BP
    DEBUG --> BP
    DEBUG --> CTX
    TESTS --> FLASK
```

### 2.3 Request Lifecycle (Happy Path)

```mermaid
sequenceDiagram
    autonumber
    participant S as WSGI Server
    participant A as Flask.wsgi_app
    participant RC as RequestContext (contexts)
    participant D as full_dispatch_request
    participant V as View Function
    participant F as finalize_request

    S->>A: __call__(environ, start_response)
    A->>RC: request_context(environ).push()
    Note over RC: pushes AppContext if needed,<br/>opens session, binds URL adapter,<br/>matches URL → url_rule / view_args
    A->>D: full_dispatch_request()
    D->>D: request_started signal
    D->>D: preprocess_request() → url_value_preprocessors, before_request funcs
    alt a before_request returned a value
        D->>F: that value short-circuits the view
    else
        D->>V: dispatch_request() → ensure_sync(view)(**view_args)
        V-->>D: return value (str/dict/tuple/Response/…)
    end
    D->>F: finalize_request(rv)
    F->>F: make_response(rv) → Response
    F->>F: process_response() → after_this_request funcs, after_request funcs (reversed), save_session
    F->>F: request_finished signal
    F-->>A: Response
    A->>S: response(environ, start_response)
    Note over A: finally: ctx.pop(error) →<br/>teardown_request funcs → request_tearing_down signal<br/>→ AppContext.pop → teardown_appcontext funcs → appcontext_tearing_down signal
```

Key implementation details in `Flask.wsgi_app`:

- `wsgi_app` (not `__call__`) is the middleware wrapping point: `app.wsgi_app = MyMiddleware(app.wsgi_app)` keeps the original app object intact.
- Teardown **always** runs in the `finally` block, even on unhandled exceptions — `should_ignore_error` can suppress the error passed to teardown handlers.
- The interactive debugger can *preserve* the app/request contexts (`werkzeug.debug.preserve_context`) for post-mortem inspection.
- The static file route is registered with a **weakref** to the app (`#3761`) so the app instance remains garbage-collectable.

### 2.4 Error Handling Pipeline

```mermaid
flowchart TD
    X[Exception during dispatch / processors] --> HUE[handle_user_exception]
    HUE -->|BadRequestKeyError & debug or TRAP_BAD_REQUEST_ERRORS| SHOW[e.show_exception = True]
    HUE -->|HTTPException and not trap_http_exception| HHE[handle_http_exception]
    HHE -->|RoutingException e.g. slash redirect| PASS[return exception untouched]
    HHE --> FH{find_error_handler<br/>code → MRO, blueprint → app scope}
    HUE -->|non-HTTP exception| FH2{find_error_handler}
    FH -->|handler found| RUN[ensure_sync handler e → response value]
    FH2 -->|handler found| RUN
    FH -->|none| RETHROW[return exception as response]
    FH2 -->|none| RAISE[re-raise original]
    RAISE --> WSGI[wsgi_app catches]
    WSGI --> HEXC[handle_exception]
    HEXC --> SIG[got_request_exception signal]
    HEXC --> PROP{PROPAGATE_EXCEPTIONS<br/>None → testing or debug}
    PROP -->|yes| RERAISE[re-raise for debugger / test client]
    PROP -->|no| LOG[log_exception]
    LOG --> ISE[InternalServerError original_exception=e]
    ISE --> H5{handler for 500 / InternalServerError?}
    H5 --> FIN[finalize_request from_error_handler=True<br/>after_request funcs still run]
    RUN --> FIN
    RETHROW --> FIN
```

Handler lookup precedence (implemented in `App._find_error_handler`): **blueprint-specific code → app code → blueprint class (by MRO) → app class**, using `(*blueprints, None)` scopes and the exception's MRO, so both `@app.errorhandler(403)` and `@app.errorhandler(ForbiddenSubclass)` behave predictably (verified in `tests/test_user_error_handler.py`).

---

## 3. Sub-modules

The application-core module is split into four documented sub-modules:

| Sub-module | Contents | Documentation |
|---|---|---|
| **Flask App Runtime** | `src/flask/app.py` — `Flask` class: WSGI entry, dispatch pipeline, error handling, response conversion, URL building, dev server, test tooling, async bridge | [application-core_flask-app.md](application-core_flask-app.md) |
| **Sans-IO Foundation** | `src/flask/sansio/app.py` (`App`, `_make_timedelta`) + `src/flask/sansio/scaffold.py` (`Scaffold`, `setupmethod`) — shared registration API, defaults, factories, resource paths, typing surface | [application-core_sansio-foundation.md](application-core_sansio-foundation.md) |
| **Debug Helpers** | `src/flask/debughelpers.py` — `DebugFilesKeyError`, `FormDataRoutingRedirect`, `UnexpectedUnicodeError`, template-loader diagnostics | [application-core_debug-helpers.md](application-core_debug-helpers.md) |
| **Verification Suite** | `tests/` — behavioral, integration, regression and type-check coverage of the whole engine | [application-core_test-suite.md](application-core_test-suite.md) |

---

## 4. Integration With Sibling Modules

The application engine delegates specialized behavior to sibling modules — see their documentation for details (avoiding duplication here):

| Concern | Where it lives | How application-core uses it |
|---|---|---|
| Contexts & context locals | [contexts.md](contexts.md) — `AppContext`, `RequestContext`, `_AppCtxGlobals`, `after_this_request`, `has_app_context` | `Flask.wsgi_app` pushes/pops `RequestContext`; `app_context()` / `request_context()` factories; `dispatch_request` reads `request_ctx`; teardown methods are invoked by `pop()` |
| Blueprints | [blueprints.md](blueprints.md) — `Blueprint`, `BlueprintSetupState` | `register_blueprint()` delegates to `Blueprint.register`, which records a `BlueprintSetupState` and copies routes/handlers into app registries using the blueprint name as scope |
| Configuration | [configuration.md](configuration.md) — `Config`, `ConfigAttribute` | `App.make_config()` creates the `Config` rooted at `root_path`/`instance_path`; `default_config` seeds `DEBUG`, `SECRET_KEY`, session cookies, limits, etc.; `debug` and `permanent_session_lifetime` are `ConfigAttribute`s (`_make_timedelta` converts ints to `timedelta`) |
| Logging | [logging.md](logging.md) — `create_logger`, `wsgi_errors_stream` | `App.logger` (cached property) delegates to `create_logger`; `log_exception` writes `Exception on {path} [{method}]` via `self.logger.error` |
| Helpers | [helpers.md](helpers.md) — `make_response`, `redirect`, `url_for`, `send_from_directory`, `get_flashed_messages` | Module-level proxies call the *app methods* (`Flask.make_response`, `App.redirect`, `Flask.url_for`); static file serving goes through `send_from_directory` with `get_send_file_max_age` |
| Sessions | [sessions.md](sessions.md) — `SessionInterface`, `SecureCookieSessionInterface`, `NullSession` | `Flask.session_interface` (default `SecureCookieSessionInterface()`); `RequestContext.push` calls `open_session`/`make_null_session`; `process_response` calls `save_session` for non-null sessions |
| Templating | [templating.md](templating.md) — `Environment`, `DispatchingJinjaLoader`, `_default_template_ctx_processor` | `create_jinja_environment()` builds the env from `jinja_options`, injects `url_for`, `get_flashed_messages`, `config`, `request`, `session`, `g`; `update_template_context` runs context processors for app + blueprint chain; `create_global_jinja_loader` returns the dispatching loader |
| JSON serialization | [json-serialization.md](json-serialization.md) — `JSONProvider`, `DefaultJSONProvider`, `TaggedJSONSerializer` | `App.json` provider instance handles dict/list view returns (`make_response` → `self.json.response(rv)`), `jsonify`, session tag round-trips, and the Jinja `tojson` filter policy |
| CLI | [command-line-interface.md](command-line-interface.md) — `FlaskGroup`, `ScriptInfo`, `run_command` | `Flask.cli` is an `AppGroup`; `run()` yields to `flask run` when `FLASK_RUN_FROM_CLI` is set; `make_shell_context` feeds `flask shell` |
| Testing support | [testing-support.md](testing-support.md) — `FlaskClient`, `FlaskCliRunner`, `EnvironBuilder` | `test_client()` / `test_cli_runner()` instantiate `test_client_class` / `test_cli_runner_class` (defaults from `testing.py`); `test_request_context` uses `EnvironBuilder` |

---

## 5. Extension Points

The engine is designed to be subclassed and customized via **overridable class attributes** and **factory methods**:

- **Object classes:** `request_class`, `response_class`, `session_interface`, `url_rule_class`, `url_map_class`, `jinja_environment`, `jinja_options`, `app_ctx_globals_class`, `config_class`, `aborter_class`, `json_provider_class`, `test_client_class`, `test_cli_runner_class`.
- **Factories:** `make_config`, `make_aborter`, `create_jinja_environment`, `create_global_jinja_loader`, `create_url_adapter`, `make_default_options_response`.
- **Pipeline hooks:** `preprocess_request`, `process_response`, `dispatch_request`, `full_dispatch_request`, `finalize_request`, `make_response`, `update_template_context`, `do_teardown_request`, `do_teardown_appcontext`.
- **Error policy:** `trap_http_exception`, `should_ignore_error`, `handle_user_exception`, `handle_http_exception`, `handle_exception`, `log_exception`, `_find_error_handler`, `handle_url_build_error` (+ `url_build_error_handlers` list).
- **Async policy:** `ensure_sync` and `async_to_sync` (install `flask[async]` / `asgiref`) — all user-supplied callables (views, before/after/teardown, error handlers, signal receivers) pass through `ensure_sync`, so sync and `async def` handlers are interchangeable (see `tests/test_async.py`).
- **Setup guard:** every registration method is wrapped in `setupmethod`, which raises `AssertionError` after the first request (`_check_setup_finished`) — late mutation is a classic source of inconsistent behavior (`test_no_setup_after_first_request`).

### 5.1 Configuration Highlights (from `default_config`)

| Key | Default | Meaning |
|---|---|---|
| `DEBUG` | `None` (from `FLASK_DEBUG` env) | Debugger + reloader + exception propagation |
| `TESTING` | `False` | Implies `PROPAGATE_EXCEPTIONS`, enables test mode |
| `SECRET_KEY` / `SECRET_KEY_FALLBACKS` | `None` | Cookie signing; fallback list supports key rotation (tested in `test_session_secret_key_fallbacks`) |
| `PERMANENT_SESSION_LIFETIME` | `timedelta(days=31)` | Accepts int seconds via `_make_timedelta` |
| `TRUSTED_HOSTS` | `None` | Host validation applied in `create_url_adapter` (`test_trusted_hosts_config`) |
| `MAX_CONTENT_LENGTH` / `MAX_FORM_MEMORY_SIZE` / `MAX_FORM_PARTS` | `None` / `500_000` / `1_000` | Request body limits surfaced on `Request` (`test_request.py`) |
| `PROPAGATE_EXCEPTIONS` | `None` → `testing or debug` | Whether unhandled exceptions re-raise instead of becoming 500s |
| `TRAP_HTTP_EXCEPTIONS` / `TRAP_BAD_REQUEST_ERRORS` | `False` / `None` | Turn HTTP errors into regular tracebacks for debugging |
| `SERVER_NAME` / `APPLICATION_ROOT` / `PREFERRED_URL_SCHEME` | `None` / `/` / `http` | URL building outside requests; subdomain/host matching (see `test_server_name_*`, `test_subdomain_*`) |
| `PROVIDE_AUTOMATIC_OPTIONS` | `True` | Automatic `OPTIONS` responses (`test_options_work`, `test_provide_automatic_options_*`) |
| `SEND_FILE_MAX_AGE_DEFAULT` / `MAX_COOKIE_SIZE` | `None` / `4093` | Static cache control and cookie size warnings |

---

## 6. Verification Suite (summary)

The `tests/` directory provides the behavioral contract of the engine (details in [application-core_test-suite.md](application-core_test-suite.md)):

- **`tests/test_basic.py`** — the largest suite: routing/dispatch, OPTIONS, request processing order, teardown, error handling & precedence, response types and `make_response` errors, JSON responses, sessions (cookies, expiration, samesite, vary, secret rotation, flashing), static files, URL generation & processors, subdomain/host matching, `run()` defaults, refcount hygiene (`test_app_freed_on_zero_refcount`).
- **`tests/test_async.py`** — async views, `MethodView`/`View` with coroutines, async before/after/error handlers (requires `asgiref`).
- **`tests/test_views.py`** — class-based views: `View`, `MethodView`, inheritance of `methods`, decorators, `provide_automatic_options`, `init_every_request`.
- **`tests/test_converters.py`** — custom Werkzeug URL converters and their access to request/session context.
- **`tests/test_request.py`** — body-size limits and trusted-host configuration.
- **`tests/test_instance_config.py`** — instance-path discovery for installed/uninstalled modules, packages and namespace packages.
- **`tests/test_user_error_handler.py`** — exact handler-dispatch semantics (class vs. code, subclass MRO, blueprint scoping, `original_exception` wrapping, generic `Exception`/`HTTPException` handlers).
- **`tests/test_signals.py`** — signal integration (`request_started/finished`, `got_request_exception`, appcontext push/pop/teardown, template & flash signals).
- **`tests/test_regression.py`**, **`tests/test_subclassing.py`** — aborting with redirects, suppressed exception logging.
- **`tests/type_check/`** — mypy-typed usage samples proving the public typing surface (route return values, error handler signatures, decorator callbacks).
- **`tests/conftest.py`** — shared fixtures (`app`, `client`, `req_ctx`, `app_ctx`, leak detector, test apps) documented under [test-infrastructure.md](test-infrastructure.md).

---

## 7. Related Documentation

- Module group: *Core Application Engine — Modular Composition* (this module), with siblings [contexts.md](contexts.md) and [blueprints.md](blueprints.md).
- *Runtime Configuration & Diagnostics*: [configuration.md](configuration.md), [logging.md](logging.md).
- *Request Services & Response Rendering*: [helpers.md](helpers.md), [sessions.md](sessions.md), [templating.md](templating.md), [json-serialization.md](json-serialization.md).
- *Developer Interface & Testing Tooling*: [command-line-interface.md](command-line-interface.md), [testing-support.md](testing-support.md), [test-infrastructure.md](test-infrastructure.md).
