# JSON Serialization Provider (`flask.json.provider`)

## 1. Overview

The **`json-serialization_provider`** module implements Flask's pluggable JSON backend, introduced in **Flask 2.2**. It lives in a single source file, [`src/flask/json/provider.py`](../repo/src/flask/json/provider.py), and defines:

- **`JSONProvider`** — an abstract *strategy* interface that standardizes every JSON operation an application can perform (`dumps`, `loads`, `dump`, `load`, `response`).
- **`DefaultJSONProvider`** — the concrete implementation built on Python's built-in [`json`](https://docs.python.org/3/library/json.html) module, which additionally understands datetimes, `UUID`s, `Decimal`s, dataclasses, and HTML-markup objects.
- **`_default`** — the fallback serializer function that teaches `json.dumps` how to handle the extra types above.

Every JSON operation in Flask routes through an instance of this class stored on the application as `app.json`. This design decouples *what* Flask does with JSON (build responses, parse request bodies, feed the Jinja `tojson` filter) from *how* serialization is performed, so an application can swap in a different JSON library (e.g. `orjson`, `ujson`) by supplying its own provider.

> **Parent context:** This module is the *provider* half of the broader `json-serialization` module group. The *tagging* half — `TaggedJSONSerializer` and its `JSONTag` classes, used for richer types in signed cookie sessions — is documented separately in [json-serialization_tag](json-serialization_tag.md).

---

## 2. Architecture

### 2.1 Component design

The module follows the **Strategy pattern**: `JSONProvider` is the interface held by the application; `DefaultJSONProvider` is the default strategy; `_default` is the type-conversion hook used by that strategy.

```mermaid
classDiagram
    direction LR

    class JSONProvider {
        <<abstract interface>>
        +_app: App (weakref.proxy)
        +dumps(obj, **kwargs)* str
        +dump(obj, fp, **kwargs)
        +loads(s, **kwargs)* Any
        +load(fp, **kwargs) Any
        +_prepare_response_obj(args, kwargs) Any
        +response(*args, **kwargs) Response
    }

    class DefaultJSONProvider {
        +default: Callable = _default
        +ensure_ascii: bool = True
        +sort_keys: bool = True
        +compact: bool | None = None
        +mimetype: str = "application/json"
        +dumps(obj, **kwargs) str
        +loads(s, **kwargs) Any
        +response(*args, **kwargs) Response
    }

    class App {
        +json: JSONProvider
        +json_provider_class: type[JSONProvider] = DefaultJSONProvider
        +response_class: type[Response]
        +debug: bool
    }

    class _default {
        <<function>>
        date/datetime --> http_date(str)
        Decimal, UUID --> str
        dataclass --> asdict()
        __html__ --> str()
        else --> TypeError
    }

    JSONProvider <|-- DefaultJSONProvider : inherits
    App *-- "1" JSONProvider : holds as app.json
    JSONProvider o-- App : weakref to _app
    DefaultJSONProvider ..> _default : uses as `default` hook
```

Key design decisions:

| Decision | Rationale |
|---|---|
| Provider stored per-app as `app.json` | Each application instance can have independent JSON behavior; no global state. |
| `weakref.proxy` to the app (`self._app`) | Prevents reference cycles (provider ↔ app) that would block garbage collection — tested by `test_app_freed_on_zero_refcount` in the app test suite (see [application-core_flask-app](application-core_flask-app.md)). |
| Only `dumps`/`loads` are abstract | A minimal custom provider (e.g. wrapping another JSON library) needs to implement just two methods; `dump`, `load`, and `response` get sensible defaults. |
| Class-level serialization knobs (`ensure_ascii`, `sort_keys`, …) | Tunable via subclassing *or* per-instance assignment (`app.json.ensure_ascii = False`). |

### 2.2 Integration map — who calls the provider

All JSON traffic in Flask converges on the single `app.json` object:

```mermaid
flowchart LR
    subgraph callers["Entry points"]
        VIEW["View returning dict / list"]
        JIFY["flask.json.jsonify()"]
        FJSON["flask.json.dumps / loads / dump / load"]
        REQ["request.get_json()"]
        JINJA["Jinja 'tojson' filter"]
    end

    subgraph module["json-serialization_provider (this module)"]
        P["app.json<br/>(JSONProvider instance)"]
        D["_default() hook"]
    end

    STDLIB["stdlib json module"]
    RESP["flask.Response<br/>mimetype application/json"]

    VIEW -- "implicit response conversion" --> JIFY
    JIFY -- "current_app.json.response()" --> P
    FJSON -- "current_app.json.* (app ctx active)" --> P
    REQ -- "via flask.json.loads" --> P
    JINJA -- "jinja_env.policies['json.dumps_function'] = app.json.dumps" --> P

    P --> D
    P -- "dumps(obj, default=_default, ...)" --> STDLIB
    P -- "response()" --> RESP
```

The delegating wrappers (`flask.json.jsonify`, `dumps`, `loads`, `dump`, `load` in `flask/json/__init__.py`) and the wiring in `Flask.__init__` / `Flask.create_jinja_environment` belong to other modules — see [Integration with the rest of Flask](#4-integration-with-the-rest-of-flask) for the exact hand-off points.

---

## 3. Core Components

### 3.1 `JSONProvider` — the strategy interface

Abstract base class every provider must derive from.

```python
def __init__(self, app: App) -> None:
    self._app: App = weakref.proxy(app)
```

The constructor accepts the application and stores it **only as a `weakref.proxy`**, so creating a provider never keeps an app alive.

| Method | Signature | Default implementation | Notes |
|---|---|---|---|
| `dumps` | `(obj, **kwargs) -> str` | ❌ `NotImplementedError` | **Must be implemented.** Serializes to a JSON string. |
| `loads` | `(s: str \| bytes, **kwargs) -> Any` | ❌ `NotImplementedError` | **Must be implemented.** Accepts text or UTF-8 bytes. |
| `dump` | `(obj, fp, **kwargs) -> None` | ✅ writes `dumps()` to the file | File should be opened in text/UTF-8 mode. |
| `load` | `(fp, **kwargs) -> Any` | ✅ reads file, calls `loads()` | Works for text or UTF-8 bytes streams. |
| `response` | `(*args, **kwargs) -> Response` | ✅ builds a response via `_prepare_response_obj` + `app.response_class(..., mimetype="application/json")` | The method invoked by `flask.json.jsonify`. |
| `_prepare_response_obj` | `(args, kwargs) -> Any` | ✅ argument normalization (private) | Raises `TypeError` if *both* positional and keyword args are given. |

`_prepare_response_obj` normalization rules (mirrored by `jsonify`'s contract):

- No args and no kwargs → serialize `None`.
- Exactly one positional arg → serialize that value as-is (dict, list, scalar…).
- Multiple positional args → serialize them as a **JSON array**.
- Keyword args → serialize them as a **JSON object (dict)**.
- Both positional and kwargs → `TypeError: app.json.response() takes either args or kwargs, not both`.

### 3.2 `_default` — the extended-type serializer

A module-level function applied to any object the underlying `json.dumps` cannot serialize. It is attached to `DefaultJSONProvider` as a static method on the `default` class attribute, so it is easy to override per-provider (see [Customization](#5-customization-guide)).

| Input type | Conversion | Example output |
|---|---|---|
| `datetime.datetime` / `datetime.date` | [`werkzeug.http.http_date`](https://werkzeug.palletsprojects.com/) → **RFC 822 / HTTP date string**; tz-aware values are normalized to GMT | `"Mon, 01 Feb 2021 07:15:00 GMT"` |
| `decimal.Decimal` | `str(o)` | `"0.003"` |
| `uuid.UUID` | `str(o)` | `"deadbeef-dead-beef-dead-beefdeadbeef"` |
| `dataclasses.dataclass` instance | `dataclasses.asdict(o)` | JSON object of the fields |
| Any object with `__html__` (e.g. `markupsafe.Markup`) | `str(o.__html__())` | `"<p>test</p>"` |
| Anything else | raises `TypeError` | `Object of type X is not JSON serializable` |

> For types beyond these (bytes, tuples, markup round-trips), Flask ships a *tagging* serializer used mainly for session storage — see [json-serialization_tag](json-serialization_tag.md).

### 3.3 `DefaultJSONProvider` — the built-in implementation

Implements all operations with the stdlib `json` module and exposes configuration as class attributes:

| Attribute | Default | Effect |
|---|---|---|
| `default` | `staticmethod(_default)` | Fallback converter for non-native types (see 3.2). |
| `ensure_ascii` | `True` | Escapes non-ASCII characters (`"\u2603"` instead of `"☃"`). Disable for smaller/faster output; fully supported per `test_json_as_unicode`. |
| `sort_keys` | `True` | Dict keys are sorted lexicographically (as **strings**) — deterministic output aids caching. Verified by `test_json_key_sorting`. |
| `compact` | `None` | Response formatting switch: `None` → follow `app.debug` (indented in debug, compact otherwise); `False` → always pretty; `True` → always compact. |
| `mimetype` | `"application/json"` | Mimetype used by `response()`; can be changed (`test_json_custom_mimetypes` exercises the request side of custom `x+json` mimetypes). |

**Behavioral specifics**

- `dumps(obj, **kwargs)` — sets `default`, `ensure_ascii`, `sort_keys` defaults from the class attributes, then delegates to `json.dumps`. Any keyword passed explicitly by the caller wins.
- `loads(s, **kwargs)` — straight delegation to `json.loads`.
- `response(*args, **kwargs)`:
  1. Normalizes args/kwargs via `_prepare_response_obj`.
  2. Chooses formatting: `indent=2` if `compact is False` **or** (`compact is None` **and** `app.debug`); otherwise compact `separators=(",", ":")`.
  3. Returns `app.response_class(json + "\n", mimetype=self.mimetype)` — note the **trailing newline**, which makes terminal output friendlier.

---

## 4. Integration with the rest of Flask

The provider is wired into the framework at four points (all implemented outside this module):

1. **Application attachment** — `Flask.__init__` (in the [sansio foundation](application-core_sansio-foundation.md)) instantiates the provider:
   ```python
   self.json: JSONProvider = self.json_provider_class(self)
   ```
   with `json_provider_class: type[JSONProvider] = DefaultJSONProvider` as a class attribute. Two ways to customize:
   - Subclass `Flask` and override `json_provider_class`, **or**
   - Assign an instance after creation: `app.json = CustomProvider(app)` (used by `test_json_customization`).

2. **`flask.json` module API** — `jsonify`, `dumps`, `loads`, `dump`, `load` in `flask/json/__init__.py` delegate to `current_app.json.*` whenever an [application context](contexts_app_context.md) is active. Outside an app context, `dumps`/`dump` fall back to stdlib `json` **with `_default` as the converter hook**, so datetime/UUID support still works in plain scripts; `loads`/`load` fall back to plain stdlib behavior.

3. **Jinja `tojson` filter** — `Flask.create_jinja_environment` sets
   ```python
   rv.policies["json.dumps_function"] = self.json.dumps
   ```
   so templates embedding data (`{{ data|tojson }}`) automatically respect the app's provider, including its `ensure_ascii` XSS-safe escaping and HTTP-date serialization (asserted by `test_tojson_filter`). See [templating_environment_loader](templating_environment_loader.md) for the environment itself.

4. **Request body parsing** — `flask.request.get_json()` parses through `flask.json` (the request's `json_module`), hence through `app.json.loads`. If decoding fails, Flask raises a `400 Bad Request`; in **debug mode** the underlying "Failed to decode JSON object" message is preserved for diagnosis, while in production a generic message is returned — exactly what `test_bad_request_debug_message` verifies.

### 4.1 End-to-end response flow

```mermaid
sequenceDiagram
    autonumber
    participant V as View
    participant J as flask.json.jsonify
    participant P as app.json (DefaultJSONProvider)
    participant S as stdlib json
    participant R as Response

    V->>J: jsonify(value={"name": "Flask"})
    J->>P: response(*args, **kwargs)
    P->>P: _prepare_response_obj()
    Note over P: kwargs → dict<br/>(or single value / list / None)
    alt app.debug or compact is False
        P->>P: dump_args["indent"] = 2
    else
        P->>P: dump_args["separators"] = (",", ":")
    end
    P->>S: dumps(obj, default=_default,<br/>ensure_ascii=True, sort_keys=True)
    S-->>P: JSON text
    P-->>R: response_class(text + "\n", mimetype="application/json")
    R-->>V: JSON response to client
```

---

## 5. Customization Guide

### 5.1 Support a new type (most common)

Subclass the default provider and extend the `default` hook — this is the pattern used in `test_json_customization`:

```python
from flask.json.provider import DefaultJSONProvider

class X:
    def __init__(self, val):
        self.val = val

def default(o):
    if isinstance(o, X):
        return f"<{o.val}>"
    return DefaultJSONProvider.default(o)   # delegate the rest

class CustomProvider(DefaultJSONProvider):
    pass

app.json = CustomProvider(app)
app.json.default = default                 # or override on the class
```

Because deserialization of custom types needs the inverse step, the same test also overrides `loads` to inject an `object_hook` that recognizes a tagged form (`{"_foo": 42}` → `X(42)`), demonstrating symmetric custom (de)serialization.

### 5.2 Use a different JSON library

Implement a minimal provider — only `dumps` and `loads` are required:

```python
import orjson
from flask.json.provider import JSONProvider

class OrjsonProvider(JSONProvider):
    def dumps(self, obj, **kwargs):
        return orjson.dumps(obj, default=kwargs.get("default")).decode()

    def loads(self, s, **kwargs):
        return orjson.loads(s)
    # dump / load / response inherit usable implementations

app = Flask(__name__)
app.json = OrjsonProvider(app)
```

### 5.3 Tune formatting per app

```python
app.json.ensure_ascii = False   # emit real UTF-8 characters
app.json.sort_keys = False      # keep insertion order, faster for huge dicts
app.json.compact = True         # never pretty-print, even in debug mode
```

---

## 6. Test Coverage

The behavior of this module is pinned by [`tests/test_json.py`](../repo/tests/test_json.py):

| Test | What it verifies |
|---|---|
| `test_jsonify_dicts` | `jsonify(dict)` and `jsonify(**kwargs)` produce equivalent `application/json` responses for nested lists/dicts. |
| `test_jsonify_aware_datetimes` | tz-aware datetimes (`FixedOffset` in PST / KST / UTC) are converted to **GMT** RFC 822 strings — the `http_date` conversion in `_default`. |
| `test_json_customization` | Swapping `app.json` for a `DefaultJSONProvider` subclass with a custom `default` and an `object_hook`-aware `loads` end-to-end (custom type round trip). |
| `test_tojson_filter` | The Jinja `tojson` filter uses the app provider's `dumps`: `</script>` is escaped, datetimes become HTTP-date strings. |
| `test_json_key_sorting` | With debug (pretty) output, keys are sorted as strings (`"0", "1", "10", "11", … "2"`), honoring `sort_keys = True`. |
| `test_bad_request_debug_message` | Failed JSON body → `400`; the raw decode message "Failed to decode JSON object" appears **only** in debug mode (integration with request parsing / `on_json_loading_failed`). |

Supporting tests in the same file cover `ensure_ascii` toggling (`test_json_as_unicode`), file-based `dump`/`load` (`test_json_dump_to_file`), basic types / arrays / UUID / `Decimal` serialization, and `__html__` objects (`test_html_method`).

---

## 7. Related Modules

| Module | Relationship |
|---|---|
| [json-serialization_tag](json-serialization_tag.md) | Sibling: `TaggedJSONSerializer` for loss-free serialization of bytes, tuples, markup, etc. (primarily secure-cookie sessions). |
| [json-serialization](json-serialization.md) | Parent module group containing this provider and the tag serializer. |
| [application-core_flask-app](application-core_flask-app.md) | `Flask` app lifecycle, responses, and the debug flag that drives pretty-printing. |
| [application-core_sansio-foundation](application-core_sansio-foundation.md) | Sansio `App` base defining `json_provider_class` and instantiating `app.json`. |
| [contexts_app_context](contexts_app_context.md) | Application context that makes `current_app` (and therefore provider delegation) available. |
| [templating_environment_loader](templating_environment_loader.md) | Jinja environment where the `tojson` filter policy is bound to `app.json.dumps`. |
