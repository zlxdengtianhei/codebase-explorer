# Flask Application Core — `application-core_flask-app`

## 1. Overview

The `application-core_flask-app` module implements **the concrete, WSGI-bound Flask application object** — the class developers instantiate (`app = Flask(__name__)`) and the central object through which every HTTP request flows.

While the sibling module [`application-core_sansio-foundation`](application-core_sansio-foundation.md) defines the framework-agnostic `App`/`Scaffold` base classes (registries, config creation, routing setup), this module provides the class `Flask` that:

- acts as the **WSGI application** (`__call__` → `wsgi_app`),
- performs the **full request lifecycle** (context push → dispatch → pre/post processing → finalization → teardown),
- **converts view return values** into proper `Response` objects (`make_response`),
- implements the **error-handling pipeline** (HTTP exceptions, user exceptions, unhandled exceptions → 500),
- bridges **synchronous and asynchronous** view code (`ensure_sync` / `async_to_sync`),
- serves **static files** and opens package/instance resources,
- integrates with **signals**, the **CLI**, the **session interface**, the **Jinja environment**, and the **test client**.

**Files in this module:**

| File | Components |
|---|---|
| `src/flask/app.py` | `Flask`, `_make_timedelta` |
| `tests/test_basic.py` | dispatching, request processing, error handling, response types, URL generation, dev server, refcount hygiene |
| `tests/test_async.py` | async route dispatch through `ensure_sync` |
| `tests/test_user_error_handler.py` | generic/default error handler dispatch semantics |
| `tests/test_signals.py` | `request_started` / `request_finished` signal ordering |
| `tests/test_regression.py` | aborting with routing exceptions |

---

## 2. Module Position & Dependencies

This module is a child of `application-core`, alongside the sansio foundation, debug helpers, and the broader test suite. It sits at the *top* of the inheritance chain and *orchestrates* every support module.

```mermaid
flowchart TB
    subgraph AC["application-core (parent)"]
        THIS["application-core_flask-app<br/>Flask, _make_timedelta"]
        SAN["application-core_sansio-foundation<br/>App / Scaffold / setupmethod"]
        DBG["application-core_debug-helpers<br/>FormDataRoutingRedirect, DebugFilesKeyError"]
        TS["application-core_test-suite<br/>cross-cutting behavioural tests"]
    end

    subgraph SUPPORT["Support modules (orchestrated by Flask)"]
        CTX["contexts<br/>AppContext / RequestContext"]
        BP["blueprints<br/>Blueprint / BlueprintSetupState"]
        CFG["configuration<br/>Config / ConfigAttribute"]
        LOG["logging<br/>create_logger / wsgi_errors_stream"]
        SES["sessions<br/>SecureCookieSessionInterface"]
        TMP["templating<br/>Environment / DispatchingJinjaLoader"]
        JS["json-serialization<br/>JSONProvider / TaggedJSONSerializer"]
        HLP["helpers<br/>url_for / redirect / send_from_directory"]
        CLI["command-line-interface<br/>FlaskGroup / AppGroup"]
        TEST["testing-support<br/>FlaskClient / FlaskCliRunner"]
        SIG["signals<br/>blinker signals"]
    end

    THIS -->|"inherits"| SAN
    THIS -->|"raise_routing_exception() imports"| DBG
    THIS -->|"app_context() / request_context()"| CTX
    THIS -->|"register_blueprint()"| BP
    THIS -->|"make_config() / default_config"| CFG
    THIS -->|"logger (cached_property)"| LOG
    THIS -->|"session_interface attribute"| SES
    THIS -->|"create_jinja_environment()"| TMP
    THIS -->|"app.json / make_response(dict|list)"| JS
    THIS -->|"url_for() / send_static_file()"| HLP
    THIS -->|"self.cli = cli.AppGroup()"| CLI
    THIS -->|"test_client() / test_cli_runner()"| TEST
    THIS -->|"request_started, request_finished,<br/>got_request_exception, teardowns"| SIG
    TS -->|"exercises"| THIS
```

Key dependency notes:

- **Inheritance**: `Flask(App)` extends [`App` from the sansio foundation](application-core_sansio-foundation.md), which in turn extends `Scaffold`. The sansio layer defines registration APIs and the config/routing plumbing; `Flask` fills in the WSGI/dispatch behaviour that requires Werkzeug-specific request/response objects.
- **Contexts**: `wsgi_app` creates and pops a [`RequestContext`](contexts.md); the request context transparently pushes an [`AppContext`](contexts.md). `Flask.app_context()` and `Flask.request_context()` are the factories.
- **Debug helpers**: `raise_routing_exception` imports `FormDataRoutingRedirect` from [`application-core_debug-helpers`](application-core_debug-helpers.md) — lazily, so debug machinery is only loaded when needed.
- **Runtime configuration**: `Flask.default_config` seeds the [`Config`](configuration.md) object; `PERMANENT_SESSION_LIFETIME` is exposed via a `ConfigAttribute` whose converter is `_make_timedelta`. The app logger is created by the [`logging`](logging.md) module.

---

## 3. Core Components

### 3.1 `Flask` (`src/flask/app.py::Flask`)

The WSGI application class and central registry. It combines the sansio registries (`view_functions`, `error_handler_spec`, `before/after_request_funcs`, …) with concrete request handling.

**Constructor parameters** (forwarded to `App`/`Scaffold`): `import_name`, `static_url_path`, `static_folder`, `static_host`, `host_matching`, `subdomain_matching`, `template_folder`, `instance_path`, `instance_relative_config`, `root_path`. The `import_name` drives resource lookup (`root_path`, `instance_path` discovery) and extension debugging — see the sansio-foundation docs for path resolution rules.

**Notable attributes set in `Flask.__init__`:**

| Attribute | Purpose |
|---|---|
| `self.cli` | A `click` `AppGroup` (from [`command-line-interface`](command-line-interface.md)), named after the app, that backs the `flask` CLI. |
| `request_class` / `response_class` | Swappable `Request`/`Response` classes (defaults: `flask.wrappers.Request/Response`). |
| `session_interface` | Defaults to `SecureCookieSessionInterface()` — see [`sessions`](sessions.md). |
| `default_config` | Immutable dict of defaults (`DEBUG`, `TESTING`, `SECRET_KEY`, `PERMANENT_SESSION_LIFETIME`, cookie options, `TRUSTED_HOSTS`, `MAX_CONTENT_LENGTH`, `TRAP_HTTP_EXCEPTIONS`, `PROPAGATE_EXCEPTIONS`, …) merged into `Config` by the sansio `make_config()`. |
| `self._got_first_request` | Guards "setup method" calls after the first request (`_check_setup_finished`). |

The constructor also registers the **static route** when `static_folder` is configured. It deliberately uses a **weakref** (`self_ref = weakref.ref(self)`) in the static view lambda to avoid a reference cycle between the app and its view function — verified by `test_app_freed_on_zero_refcount`, which asserts a `Flask` instance is collectable at zero refcount.

**Method groups:**

| Group | Methods | Notes |
|---|---|---|
| WSGI entry | `__call__`, `wsgi_app` | `wsgi_app` is separate from `__call__` so middleware can wrap `app.wsgi_app` while preserving the app object. |
| Dispatch | `full_dispatch_request`, `dispatch_request`, `preprocess_request`, `finalize_request`, `process_response` | Implements the lifecycle in §5. |
| Response | `make_response`, `make_default_options_response`, `update_template_context`, `create_jinja_environment` | See §7 and [`templating`](templating.md). |
| Errors | `handle_user_exception`, `handle_http_exception`, `handle_exception`, `log_exception`, `raise_routing_exception`, `trap_http_exception` (inherited) | See §6. |
| URLs | `url_for`, `create_url_adapter` | See §9. |
| Resources | `open_resource`, `open_instance_resource`, `send_static_file`, `get_send_file_max_age` | Read-only resource access relative to `root_path` / `instance_path`; static serving via `send_from_directory`. |
| Async | `ensure_sync`, `async_to_sync` | See §8. |
| Dev & test | `run`, `test_client`, `test_cli_runner`, `test_request_context`, `make_shell_context` | `run()` delegates to `werkzeug.serving.run_simple`, never used under `flask run` (`FLASK_RUN_FROM_CLI` guard); test factories delegate to [`testing-support`](testing-support.md). |
| Teardown | `do_teardown_request`, `do_teardown_appcontext` | Invoked by the context objects on pop; send `request_tearing_down` / `appcontext_tearing_down`. |

### 3.2 `_make_timedelta` (`src/flask/app.py::_make_timedelta`)

```python
def _make_timedelta(value: timedelta | int | None) -> timedelta | None:
    if value is None or isinstance(value, timedelta):
        return value
    return timedelta(seconds=value)
```

A tiny normalizer that lets users configure `PERMANENT_SESSION_LIFETIME` (and any future time-span option) as an `int` number of **seconds** or a `timedelta`. It is wired into the sansio `App` as the `get_converter` of the `permanent_session_lifetime` `ConfigAttribute`, so the conversion happens whenever the attribute is set from config (e.g. by [`configuration`](configuration.md) loaders such as `from_object` or `from_prefixed_env`).

---

## 4. Class Hierarchy

```mermaid
classDiagram
    class Scaffold {
        <<sansio/scaffold.py>>
        +view_functions
        +error_handler_spec
        +before_request_funcs
        +after_request_funcs
        +teardown_request_funcs
        +template_context_processors
        +url_value_preprocessors
        +url_default_functions
        +route() add_url_rule() endpoint()
        +errorhandler() register_error_handler()
        +before_request() after_request() teardown_request()
    }
    class App {
        <<sansio/app.py>>
        +config: Config
        +url_map: Map
        +blueprints
        +json: JSONProvider
        +aborter
        +debug: bool
        +register_blueprint()
        +_find_error_handler(e, blueprints)
        +trap_http_exception(e)
        +make_config() make_aborter()
        +inject_url_defaults() handle_url_build_error()
    }
    class Flask {
        <<app.py>>
        +cli: AppGroup
        +session_interface
        +request_class / response_class
        +__call__(environ, start_response)
        +wsgi_app(environ, start_response)
        +full_dispatch_request() Response
        +dispatch_request()
        +preprocess_request()
        +finalize_request(rv, from_error_handler)
        +process_response(response)
        +make_response(rv) Response
        +handle_user_exception(e)
        +handle_http_exception(e)
        +handle_exception(e) Response
        +ensure_sync(func)
        +async_to_sync(func)
        +url_for(endpoint)
        +create_url_adapter(request)
        +run(host, port, debug)
        +test_client() test_cli_runner()
    }
    Scaffold <|-- App : extends
    App <|-- Flask : extends
    Flask ..> RequestContext : creates via request_context()
    Flask ..> AppContext : creates via app_context()
```

The `@setupmethod` decorator (defined in [`sansio/scaffold.py`](application-core_sansio-foundation.md)) wraps registration APIs so that mutating the app after the first request raises an `AssertionError` (enforced via `_check_setup_finished`, tested by `test_no_setup_after_first_request`).

---

## 5. Request Lifecycle & Data Flow

Every request travels through `wsgi_app`, which brackets the dispatch between **context push** and **context pop**, guaranteeing teardown even on failure.

```mermaid
sequenceDiagram
    autonumber
    participant W as WSGI Server
    participant A as Flask (wsgi_app)
    participant RC as RequestContext
    participant AC as AppContext
    participant D as full_dispatch_request
    participant V as View / Error Handler

    W->>A: __call__(environ, start_response)
    A->>A: request_context(environ)
    A->>RC: ctx.push()
    RC->>AC: push AppContext (if none / different app)
    RC->>RC: open_session() or make_null_session()
    RC->>RC: match_request() via url_adapter
    A->>D: full_dispatch_request()
    Note over D: signal: request_started
    D->>D: preprocess_request()<br/>(url_value_preprocessors, before_request_funcs)
    alt before_request returned a value
        D->>D: that value short-circuits dispatch
    else
        D->>V: dispatch_request() → ensure_sync(view)(**view_args)
    end
    V-->>D: ResponseReturnValue (or exception → handle_user_exception)
    D->>D: finalize_request(rv)
    D->>D: make_response(rv) → Response
    D->>D: process_response(response)<br/>(ctx._after_request_functions, after_request_funcs, save_session)
    Note over D: signal: request_finished
    A-->>W: response(environ, start_response)
    A->>RC: ctx.pop(error)
    RC->>RC: do_teardown_request(exc)<br/>(teardown_request_funcs, signal request_tearing_down)
    RC->>AC: app_ctx.pop(exc)
    AC->>AC: do_teardown_appcontext(exc)<br/>(teardown_appcontext_funcs, signal appcontext_tearing_down)
```

**Behavioural guarantees covered by the test suite:**

- **Ordering** — `test_before_after_request_order` pins the exact sequence `[before1, before2, after2, after1, teardown2, teardown1]`: *before* handlers run in registration order, *after* handlers in **reverse** registration order, *teardown* handlers in reverse order during context pop.
- **Early return** — a `before_request` returning non-`None` becomes the response and skips remaining before-functions and the view (`test_request_preprocessing_early_return`).
- **`after_this_request`** — deferred response callbacks stored on the request context run before regular `after_request` functions (`test_after_request_processing`).
- **Automatic OPTIONS** — when `PROVIDE_AUTOMATIC_OPTIONS` is active and no rule matches `OPTIONS`, `dispatch_request` answers via `make_default_options_response()` with the `Allow` header computed from the URL adapter (`test_options_work`, `test_options_on_multiple_rules`, `test_provide_automatic_options_*`).
- **Routing exceptions** — if `match_request` recorded a `routing_exception`, `dispatch_request` re-raises it; in debug mode `raise_routing_exception` swaps 301/302 `RequestRedirect`s that would discard a request body for a `FormDataRoutingRedirect` assertion (see [`application-core_debug-helpers`](application-core_debug-helpers.md), `test_routing_redirect_debugging`).
- **Error in processors** — exceptions raised in before/after handlers still reach the 500 error handler (`test_error_handler_after_processor_error`), and `finalize_request` runs even for the default 500 response.
- **Teardown safety** — teardown handlers receive the *original* exception even if a sibling teardown raises (`test_teardown_request_handler_error`); `BaseException`s like `KeyboardInterrupt` are never converted to responses (`test_baseexception_error_handling`).

---

## 6. Error-Handling Pipeline

`Flask` distinguishes three exception classes and routes them through progressively more defensive handling:

```mermaid
flowchart TD
    E["Exception raised in view / processor"] --> HUE["handle_user_exception(e)"]
    HUE -->|"BadRequestKeyError and (debug or TRAP_BAD_REQUEST_ERRORS)"| SHOW["e.show_exception = True<br/>(expose missing key)"]
    SHOW --> CHK
    HUE --> CHK{"is HTTPException and<br/>not trap_http_exception(e)?"}
    CHK -->|"yes"| HHE["handle_http_exception(e)"]
    CHK -->|"no (user exception)"| F1["_find_error_handler(e, request.blueprints)"]
    HHE -->|"code is None or RoutingException<br/>(slash redirects etc.)"| PASS["return exception unchanged"]
    HHE -->|"otherwise"| F2["_find_error_handler(e, request.blueprints)"]
    F1 -->|"handler found"| CALL["ensure_sync(handler)(e)"]
    F2 -->|"handler found"| CALL
    F1 -->|"no handler"| HE["handle_exception(e)"]
    F2 -->|"no handler"| HE
    HE --> SIG["signal: got_request_exception"]
    HE --> PROP{"PROPAGATE_EXCEPTIONS<br/>(None → testing or debug)?"}
    PROP -->|"True"| RE["re-raise exception"]
    PROP -->|"False"| LOG["log_exception(exc_info)"]
    LOG --> SE["InternalServerError(original_exception=e)"]
    SE --> F3["_find_error_handler(500 / InternalServerError)"]
    F3 --> FR["finalize_request(rv, from_error_handler=True)"]
    CALL --> RESP["return value becomes response"]
    FR --> RESP
```

**Handler lookup order** (inherited `_find_error_handler`): for each of `(http code, None)` and each of `(blueprint names…, None)`, the exception class and its MRO are probed — i.e. **code-scoped blueprint handler → code-scoped app handler → class-scoped blueprint handler → class-scoped app handler**, walking the exception MRO. Consequences verified by tests:

- `test_errorhandler_precedence`: the most specific class in the MRO wins (`E3(E1, E2)` triggers the `E2` handler, not `Exception`).
- `test_error_handler_subclass` / `test_error_handler_http_subclass`: unregistered subclasses fall back to the nearest registered ancestor.
- `test_http_error_subclass_handling`: a handler registered for a subclass must **not** capture the plain parent code.
- [`TestGenericHandlers`](#14-test-coverage-map) documents the semantics of very generic handlers: `InternalServerError`/`500` handlers only ever receive `InternalServerError` (with `original_exception` set for wrapped errors); `HTTPException` handlers only receive HTTP exceptions (including 404 routing misses); a bare `Exception` handler sees everything directly.
- `test_error_handler_blueprint`: blueprint-scoped handlers shadow app-wide ones for requests the blueprint handles.

**Wrapping semantics** — `handle_exception` always logs the original traceback (`app.logger.error` via `log_exception`), then builds `InternalServerError(original_exception=e)` so 500 handlers can distinguish "direct 500 aborts" from wrapped errors (`test_user_error_handler`, `tests/test_user_error_handler.py::test_error_handler_no_match`). Handler registration validation (instance vs class, valid HTTP codes) lives in `Scaffold.register_error_handler` / `_get_exc_class_and_code`.

---

## 7. Response Conversion (`make_response`)

`Flask.make_response` converts any `ResponseReturnValue` into `self.response_class`, applying optional tuple unpacking `(body, status, headers)` (2- or 3-tuples only — anything else raises `TypeError`, see `test_response_type_errors`).

| View return value | Converted to |
|---|---|
| `str` / `bytes` / `bytearray` | Body of a new response (UTF-8 for str). |
| `dict` / `list` | Serialized via `app.json.response()` → JSON response (see [`json-serialization`](json-serialization.md)). |
| generator / iterator | Streaming response. |
| `tuple` | Unpacked into body + status + headers (all combinations of 2/3 elements). |
| `Response` instance | Returned unchanged; tuple status/headers are applied on top. |
| other Werkzeug `Response` | Coerced via `response_class.force_type`. |
| WSGI callable | Evaluated against `request.environ`, then coerced. |
| `None` | `TypeError` naming the failing endpoint (`test_response_type_errors`). |

`update_template_context` injects `request`, `session`, `g`, `config` and all template context processors (app first, then innermost→outermost blueprints, with user-passed values taking precedence) — see [`templating`](templating.md).

---

## 8. Async Support

Flask is WSGI-first; async views, before/after/teardown functions and error handlers are transparently converted:

- `ensure_sync(func)` returns `func` unchanged for plain `def`, or wraps it through `async_to_sync` for `async def`.
- `async_to_sync` uses `asgiref.sync.async_to_sync`; if `asgiref` is missing, a `RuntimeError` asks for the `async` extra.
- All internal call sites (`dispatch_request`, processors, error handlers, teardowns, signal sending via `_async_wrapper=self.ensure_sync`) pass through `ensure_sync`, so sync and async handlers interoperate uniformly.

`tests/test_async.py` verifies async routes on the app and blueprints (`test_async_route`), async before/after handlers (`test_async_before_after_request`), and async error handlers (`test_async_error_handler`).

---

## 9. URL Building & Request Matching

`create_url_adapter(request)` binds the URL map:

- **With a request**: enforces `TRUSTED_HOSTS` by re-deriving `request.host` via `get_host`, then binds to the environ. With `host_matching`, `SERVER_NAME` is ignored (real host is used); without `subdomain_matching`, the subdomain is pinned to the default so Werkzeug doesn't reject hosts. (`test_server_name_matching`, `test_trusted_hosts_config` in [`sansio-foundation` tests](application-core_sansio-foundation.md).)
- **Without a request** (app context / direct calls): requires `SERVER_NAME`, using `APPLICATION_ROOT` as script name and `PREFERRED_URL_SCHEME`.

`Flask.url_for(endpoint, *, _anchor, _method, _scheme, _external, **values)`:

- Inside a request context, uses the request's URL adapter; endpoints starting with `.` are resolved relative to the current blueprint; URLs are relative by default.
- Outside a request, URLs default to **external** and require `SERVER_NAME` + `APPLICATION_ROOT` + `PREFERRED_URL_SCHEME`.
- Applies `url_default_functions` (`inject_url_defaults`, including blueprint-path defaults — `test_url_processors`, `test_inject_blueprint_url_defaults`).
- On `BuildError`, calls `handle_url_build_error`, offering each registered `url_build_error_handlers` the `(error, endpoint, values)` including the special `_external/_anchor/_method/_scheme` values; a returned string wins, otherwise the error re-raises (`test_build_error_handler`, `test_build_error_handler_reraise`, `test_url_for_passes_special_values_to_build_error_handler`).

The `static` endpoint (`/static/<path:filename>`) is registered automatically and participates in `url_for("static", ...)` generation (`test_static_files`, `test_static_url_path*`).

---

## 10. Signals Integration

`Flask` sends blinker signals at well-defined lifecycle points; the full signal catalogue and extension use-cases are covered in the [`contexts`](contexts.md) and support-module docs. This module is responsible for:

| Signal | Sent from | Verified by |
|---|---|---|
| `request_started` | `full_dispatch_request`, **before** preprocessing | `tests/test_signals.py::test_request_signals` |
| `request_finished` | `finalize_request`, after `process_response` | `tests/test_signals.py::test_request_signals` |
| `got_request_exception` | `handle_exception`, before propagation/logging | `test_request_exception_signal` |
| `request_tearing_down` | `do_teardown_request` | `tests/test_appctx.py` / `tests/test_reqctx.py` |
| `appcontext_tearing_down` | `do_teardown_appcontext` | `test_appcontext_tearing_down_signal` |

The canonical ordering documented by `test_request_signals`:

```
request_started → before_request handlers → view → after_request handlers → request_finished
```

---

## 11. Static Files & Resources

- `send_static_file(filename)` serves from `static_folder` via `send_from_directory` with `get_send_file_max_age` (respects `SEND_FILE_MAX_AGE_DEFAULT`; `None` → conditional requests). The route is registered in `__init__` with a **weakref** to break the app↔view reference cycle (`test_app_freed_on_zero_refcount`).
- Static URL/host behaviour: `static_url_path` (explicit, trailing-slash-tolerant, empty-path, `pathlib.Path` folders) and `static_host` + `host_matching` validation (`test_static_*` tests). Requests to a `static_folder` ending in `/` must not swallow arbitrary paths (`test_static_folder_with_ending_slash`).
- `open_resource` / `open_instance_resource` open package/instance files read-only (text/binary, optional encoding since 3.1); write access is permitted only in the instance folder.

---

## 12. Configuration Surface

`Flask.default_config` provides the defaults merged into the [`Config`](configuration.md) object. Highlights most relevant to this module:

| Key | Default | Role in request handling |
|---|---|---|
| `DEBUG` | `None` (env-resolved) | Enables exception propagation, debugger hooks, `FormDataRoutingRedirect` swap, template auto-reload. |
| `TESTING` | `False` | Implies `PROPAGATE_EXCEPTIONS`. |
| `PROPAGATE_EXCEPTIONS` | `None` → `testing or debug` | Controls re-raise vs 500 in `handle_exception`. |
| `TRAP_HTTP_EXCEPTIONS` / `TRAP_BAD_REQUEST_ERRORS` | `False` / `None` | Error handling vs re-raise behaviour (§6). |
| `SERVER_NAME`, `APPLICATION_ROOT`, `PREFERRED_URL_SCHEME`, `TRUSTED_HOSTS` | `None`, `/`, `http`, `None` | URL adapter binding & building (§9); `SERVER_NAME` no longer restricts requests (3.1). |
| `PERMANENT_SESSION_LIFETIME` | `timedelta(days=31)` | Converted via `_make_timedelta`; consumed by the session interface. |
| `MAX_CONTENT_LENGTH`, `MAX_FORM_MEMORY_SIZE`, `MAX_FORM_PARTS`, `MAX_COOKIE_SIZE` | `None`, `500_000`, `1_000`, `4093` | Request/response limits (`test_max_content_length`, `test_limit_config`, `test_max_cookie_size`). |
| `PROVIDE_AUTOMATIC_OPTIONS` | `True` | Automatic OPTIONS responses (§5). |

Loading mechanisms (`from_object`, `from_pyfile`, `from_envvar`, `from_prefixed_env`, JSON/TOML) are documented in [`configuration`](configuration.md); logger behaviour in [`logging`](logging.md).

---

## 13. Development Server & Testing Integration

- **`run()`** — thin wrapper over `werkzeug.serving.run_simple` (threaded by default, reloader/debugger from `debug`). Host/port default from `SERVER_NAME` (`test_run_defaults`, `test_run_server_port`, `test_run_from_config`). Refuses to block when invoked under the `flask` CLI, and honours `.env`/`.flaskenv` loading plus the `FLASK_DEBUG` override. **Never for production.** CLI-driven serving belongs to [`command-line-interface`](command-line-interface.md).
- **`test_client()` / `test_cli_runner()`** — instantiate `test_client_class` / `test_cli_runner_class`, lazily importing `FlaskClient` / `FlaskCliRunner` from [`testing-support`](testing-support.md) when no override is set. `test_request_context()` builds a WSGI environ with `EnvironBuilder` and wraps it in a `RequestContext` for unit-style testing.

---

## 14. Test Coverage Map

| Test file (in this module) | Validates |
|---|---|
| `tests/test_basic.py::test_request_dispatching` | Method routing, 405 + `Allow` header, HEAD truncation. |
| `tests/test_basic.py::test_request_processing` / `test_before_after_request_order` | before/after/teardown ordering and response mutation. |
| `tests/test_basic.py::test_error_handling` | Code- and class-based handlers (404/500/403), `app.testing=False` paths. |
| `tests/test_basic.py::test_response_types` / `test_make_response` | Full matrix of `make_response` inputs (§7). |
| `tests/test_basic.py::test_url_generation` | Blueprint-relative and external URL building. |
| `tests/test_basic.py::test_run_defaults` | `run()` delegates to `run_simple` with mocked server. |
| `tests/test_basic.py::test_app_freed_on_zero_refcount` | Weakref-based static view avoids reference cycles (CPython GC). |
| `tests/test_async.py::test_async_route` | Async views on app, blueprint, `View`, `MethodView` through `ensure_sync`. |
| `tests/test_user_error_handler.py::TestGenericHandlers` | 500/`InternalServerError` aliasing, `original_exception` wrapping, generic `HTTPException`/`Exception` handler semantics. |
| `tests/test_signals.py::test_request_signals` | Signal ordering relative to request handlers (§10). |
| `tests/test_regression.py::test_aborting` | Raising redirects/HTTPExceptions through `flask.abort` inside views. |

Broader behavioural suites (sessions, subdomains, static files, CLI, signals beyond requests) live in [`application-core_test-suite`](application-core_test-suite.md); environment/context edge cases in [`contexts`](contexts.md); helper typing checks in [`application-core_sansio-foundation`](application-core_sansio-foundation.md).

---

## 15. Related Documentation

- [`application-core`](application-core.md) — parent module grouping.
- [`application-core_sansio-foundation`](application-core_sansio-foundation.md) — `App`/`Scaffold` base classes, registration decorators, instance-path resolution.
- [`application-core_debug-helpers`](application-core_debug-helpers.md) — debug-time diagnostics raised by this module.
- [`application-core_test-suite`](application-core_test-suite.md) — extended behavioural test coverage.
- [`contexts`](contexts.md) — `AppContext`, `RequestContext`, `g`, teardown propagation.
- [`blueprints`](blueprints.md) — blueprint registration API consumed by `register_blueprint`.
- [`configuration`](configuration.md) · [`logging`](logging.md) — config object seeded by `default_config`, app logger.
- [`helpers`](helpers.md) · [`sessions`](sessions.md) · [`templating`](templating.md) · [`json-serialization`](json-serialization.md) — request services orchestrated during dispatch.
- [`command-line-interface`](command-line-interface.md) · [`testing-support`](testing-support.md) · [`test-infrastructure`](test-infrastructure.md) — CLI group, test client/runner, shared fixtures (`app`, `client`, `req_ctx`).
