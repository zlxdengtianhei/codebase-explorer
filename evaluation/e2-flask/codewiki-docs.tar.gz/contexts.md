# Contexts Module (`flask.ctx`)

## Overview

The **contexts** module implements the heart of Flask's request-local architecture: the mechanism that makes the context proxies `request`, `session`, `g`, `current_app`, `request_ctx`, and `app_ctx` resolve to the *right* objects even when hundreds of requests are being served concurrently by the same process.

It is implemented almost entirely in a single source file, [`src/flask/ctx.py`](https://github.com/pallets/flask/blob/main/src/flask/ctx.py), and validated by two dedicated test suites, `tests/test_appctx.py` (application context) and `tests/test_reqctx.py` (request context).

Flask provides two nested context types:

| Context | Class | Created / Pushed by | Exposes via proxies |
|---|---|---|---|
| **Application context** | `AppContext` | `Flask.app_context()`, `RequestContext.push()`, CLI commands | `current_app`, `g`, `app_ctx` |
| **Request context** | `RequestContext` | `Flask.wsgi_app()` → `Flask.request_context()`, `Flask.test_request_context()` | `request`, `session`, `request_ctx` |

An application context is the outer context. A request context can only exist on top of an application context — `RequestContext.push()` transparently creates and pushes one if none (or one for a different app) is active.

## Architecture

```mermaid
graph TB
    subgraph "Context Storage Layer — flask.globals"
        CV1["_cv_app: ContextVar[AppContext]"]
        CV2["_cv_request: ContextVar[RequestContext]"]
        P1["LocalProxy proxies: current_app, g, app_ctx"]
        P2["LocalProxy proxies: request, session, request_ctx"]
        CV1 --> P1
        CV2 --> P2
    end

    subgraph "Context Implementation — flask.ctx"
        AC["AppContext<br/>app · url_adapter · g"]
        RC["RequestContext<br/>request · url_adapter · session · flashes"]
        ACG["_AppCtxGlobals<br/>(namespace object behind 'g')"]
        H1["has_app_context / has_request_context"]
        H2["after_this_request"]
        H3["copy_current_request_context"]
    end

    subgraph "Flask Application — application-core"
        WSGI["Flask.wsgi_app()"]
        FD["Flask.full_dispatch_request()"]
        PR["Flask.process_response()"]
        TR["Flask.do_teardown_request()"]
        TA["Flask.do_teardown_appcontext()"]
    end

    subgraph "Signals — flask.signals"
        S1["appcontext_pushed"]
        S2["appcontext_popped"]
        S3["request_tearing_down"]
        S4["appcontext_tearing_down"]
    end

    RC -- "ensures app ctx exists" --> AC
    AC --> CV1
    RC --> CV2
    AC -- "contains" --> ACG
    AC -- "push()" --> S1
    AC -- "pop()" --> S2
    AC -- "pop() → teardown" --> TA
    RC -- "pop() → teardown" --> TR
    WSGI -- "request_context(environ).push()" --> RC
    WSGI -- "finally: ctx.pop(error)" --> RC
    RC -- "during push: open_session, match_request" --> FD
    PR -- "runs ctx._after_request_functions" --> H2
    H3 -- "ctx.copy()" --> RC
```

### Key design decisions

1. **`contextvars` instead of threads** — Flask ≥ 2.x stores active contexts in `ContextVar` objects (`_cv_app`, `_cv_request` in `flask/globals.py`). This makes contexts correct across threads, greenlets, and `asyncio` tasks, because each execution context gets its own variable value.
2. **Proxies stay unbound until a context is pushed** — Werkzeug `LocalProxy` objects (`request`, `g`, `current_app`, …) look up the `ContextVar` lazily at attribute-access time and raise a descriptive `RuntimeError` ("Working outside of application context.") when no context is active.
3. **Reference counting via token stacks** — Each context keeps a `_cv_tokens` list of `contextvars.Token`s so the same context can be pushed multiple times (e.g. nested manual pushes, `stream_with_context`) and popped exactly the right number of times.
4. **Teardown is guaranteed** — `pop()` runs teardown handlers in a `try/finally` structure, so `teardown_request` / `teardown_appcontext` callbacks execute even when an exception propagated, and even when a teardown handler itself raises (`test_clean_pop`).

## Component Inventory

| Component | Location | Responsibility |
|---|---|---|
| `AppContext` | `src/flask/ctx.py` | Binds the application to the current execution context; owns the URL adapter for out-of-request URL building and the `g` namespace |
| `RequestContext` | `src/flask/ctx.py` | Wraps a WSGI environ + `Request`; matches URLs, opens the session, tracks deferred after-request callbacks; drives request teardown |
| `_AppCtxGlobals` | `src/flask/ctx.py` | Plain namespace object exposed as the `g` proxy, with dict-like helpers (`get`, `pop`, `setdefault`) |
| `after_this_request` | `src/flask/ctx.py` | Registers a callback (e.g. from inside a view) to run later against the response object |
| `copy_current_request_context` | `src/flask/ctx.py` | Decorator that copies the active request context so a function can run in a greenlet/other execution context |
| `has_app_context` / `has_request_context` | `src/flask/ctx.py` | Boolean predicates for defensive code that must work inside or outside contexts |
| `tests/test_appctx.py` | `tests/` | 14 tests covering app-context proxies, `g` behavior, teardown exception propagation, URL generation, context refcounting |
| `tests/test_reqctx.py` | `tests/` | 13+ tests covering context binding, teardown ordering, session opening, greenlet copying, malformed environ handling |

## Request Lifecycle — How Contexts Flow Through a Request

```mermaid
sequenceDiagram
    participant WS as WSGI Server
    participant App as Flask.wsgi_app
    participant RC as RequestContext
    participant AC as AppContext
    participant Disp as full_dispatch_request
    participant View as View Function

    WS->>App: __call__(environ, start_response)
    App->>RC: app.request_context(environ)
    Note over RC: builds Request, creates url_adapter<br/>(HTTPException stored as routing_exception)
    App->>RC: ctx.push()
    RC->>AC: no active app ctx? → app.app_context().push()
    AC->>AC: _cv_app.set(self), send appcontext_pushed
    RC->>RC: _cv_request.set(self)
    RC->>RC: session_interface.open_session() or make_null_session()
    RC->>RC: match_request() → request.url_rule, request.view_args
    App->>Disp: full_dispatch_request()
    Disp->>View: dispatch_request() → view()
    View-->>Disp: return value
    View->>RC: after_this_request(f) appends to _after_request_functions
    Disp-->>App: response
    App->>App: process_response() runs ctx._after_request_functions first
    App->>RC: finally: ctx.pop(error)
    RC->>RC: do_teardown_request(error) + request close
    RC->>RC: environ["werkzeug.request"] = None (break cycles)
    RC->>AC: app_ctx.pop(error)
    AC->>AC: do_teardown_appcontext(error), send appcontext_popped
    App-->>WS: response(environ, start_response)
```

The same `push()`/`pop()` protocol is used outside HTTP:

- **CLI**: every command registered through the `flask` CLI runs inside `with app.app_context()` (see `Developer_Interface___Testing_Tooling`, CLI module).
- **Testing**: `app.test_request_context()` builds a WSGI environ via `EnvironBuilder` and returns a `RequestContext` the test pushes manually; `tests/conftest.py` exposes `app_ctx` and `req_ctx` fixtures built on this.
- **Debug mode**: `wsgi_app` stashes the contexts in `environ["werkzeug.debug.preserve_context"]` so the interactive debugger can restore access to `request`/`g` after the request ends.

## Sub-module Documentation

The contexts module is split into two documented sub-modules (generated files in this directory):

| Sub-module | File | Source components | Test coverage |
|---|---|---|---|
| **Application Context** | [contexts_app_context.md](contexts_app_context.md) | `AppContext`, `_AppCtxGlobals`, `has_app_context` from `src/flask/ctx.py` | `tests/test_appctx.py` — 17 tests: proxy binding, `g` dict-like API, custom `app_ctx_globals_class`, teardown exception propagation (handled/unhandled/previous exceptions), URL generation rules, refcounting, clean pop |
| **Request Context** | [contexts_request_context.md](contexts_request_context.md) | `RequestContext`, `after_this_request`, `copy_current_request_context` from `src/flask/ctx.py` | `tests/test_reqctx.py` — 15 tests: manual/`with` binding, teardown on pop, session opening and custom cookie names, session errors popping contexts, malformed vs. IDNA hosts, greenlet context copying |

Read [contexts_app_context.md](contexts_app_context.md) first: the application context is the foundation that the request context documented in [contexts_request_context.md](contexts_request_context.md) builds upon.

## Relationship to Other Modules

- **`application-core`** (`src/flask/app.py`, `sansio/app.py`): the `Flask` class is the *factory and orchestrator* for contexts. `Flask.wsgi_app()` pushes/pops the request context around dispatch; `Flask.do_teardown_request()` and `Flask.do_teardown_appcontext()` are the teardown hooks invoked from `RequestContext.pop()` and `AppContext.pop()`; `Flask.create_url_adapter()` supplies the adapter each context caches; `Flask.url_for()` prefers `request_ctx.url_adapter`, then `app_ctx.url_adapter`. See the [application-core](application-core.md) documentation.
- **`Request_Services___Response_Rendering`**: `RequestContext.push()` opens the session through `app.session_interface` (see the [sessions](sessions.md) sub-module); flashing state (`ctx.flashes`) and the template context (`request`, `session`, `g` injected by `_default_template_ctx_processor`) both live on top of the active contexts.
- **`blueprints`**: blueprint-scoped `before/after/teardown_request` functions are keyed by the blueprint name recorded on `request` and consulted during dispatch/teardown. See the [blueprints](blueprints.md) documentation.
- **`Developer_Interface___Testing_Tooling`**: `FlaskClient` relies on context preservation semantics (`test_test_client_context_binding`), and the `app_ctx`/`req_ctx` pytest fixtures in `tests/conftest.py` wrap `AppContext`/`RequestContext` directly. See [testing-support](testing-support.md) and [test-infrastructure](test-infrastructure.md).
- **Signals** (`flask/signals.py`): `appcontext_pushed`, `appcontext_popped` are sent by `AppContext`; `request_tearing_down`, `appcontext_tearing_down` by the teardown paths — validated in `tests/test_signals.py`.
