# contexts_app_context Module Documentation

## 1. Introduction

`contexts_app_context` implements **Flask's Application Context** — the mechanism that binds application-specific state (the `Flask` app itself, its URL adapter, and the per-context `g` namespace) to the currently executing code. It lives in `src/flask/ctx.py` and is verified by `tests/test_appctx.py`.

The module provides three core components:

| Component | Kind | Purpose |
|---|---|---|
| `AppContext` | Class | Encapsulates application-level state; pushed/popped like a context manager |
| `_AppCtxGlobals` | Class | Plain namespace object exposed to users as the `flask.g` proxy |
| `has_app_context` | Function | Boolean check for whether an app context is currently active |

An app context is created and pushed:
- **Automatically** at the start of every request — the sibling module [contexts_request_context](contexts_request_context.md) (`RequestContext.push()`) guarantees an app context exists before request handling.
- **Automatically** when running any CLI command — see [command-line-interface](command-line-interface.md) (`@with_appcontext`, `shell_command`).
- **Manually** by user code / tests via `with app.app_context():` (factory: `Flask.app_context()` in [application-core_flask-app](application-core_flask-app.md)).

While an app context is active, the well-known proxies `current_app`, `g`, and `app_ctx` (defined in `flask.globals` via a `ContextVar` named `_cv_app`) resolve to it. This is what makes Flask's "implicit globals" work safely across threads and async tasks.

---

## 2. Architecture Overview

```mermaid
graph TB
    subgraph contexts_app_context["contexts_app_context (src/flask/ctx.py)"]
        AC["AppContext<br/>app · url_adapter · g · _cv_tokens"]
        G["_AppCtxGlobals<br/>dict-backed namespace ('g')"]
        HAC["has_app_context()<br/>reads _cv_app"]
        AC -->|"creates g = app.app_ctx_globals_class()"| G
    end

    subgraph globals["flask.globals (proxy layer)"]
        CV[("_cv_app: ContextVar[AppContext]")]
        PROXIES["current_app · g · app_ctx<br/>(unbound LocalProxy objects)"]
    end

    subgraph appcore["application-core (src/flask/app.py)"]
        FL["Flask"]
        TDF["teardown_appcontext_funcs<br/>do_teardown_appcontext(exc)"]
        URLA["create_url_adapter(None)"]
    end

    subgraph signals["flask.signals"]
        SP["appcontext_pushed"]
        ST["appcontext_tearing_down"]
        SPo["appcontext_popped"]
    end

    AC -- "push(): _cv_app.set(self)" --> CV
    AC -- "pop(): _cv_app.reset(token)" --> CV
    CV -- "backs" --> PROXIES
    HAC -- "reads" --> CV
    AC -- "factory user: app.app_context()" --> FL
    AC -- "__init__()" --> URLA
    AC -- "pop() → teardown chain" --> TDF
    TDF -- "sends" --> ST
    AC -- "push()" --> SP
    AC -- "pop()" --> SPo
```

### Dependency summary

| Direction | Dependency | Role |
|---|---|---|
| Outgoing | `flask.globals._cv_app` | `ContextVar` used to bind/unbind the context (token-based push/pop) |
| Outgoing | `flask.signals` (`appcontext_pushed`, `appcontext_popped`) | Lifecycle notification for extensions |
| Outgoing | `Flask.app_context()` / `do_teardown_appcontext` / `create_url_adapter` / `app_ctx_globals_class` | App-owned behavior invoked by the context |
| Outgoing | `werkzeug.exceptions.HTTPException` | URL-adapter creation failure handling (in `RequestContext`, sibling module) |
| Incoming | [contexts_request_context](contexts_request_context.md) | `RequestContext.push()` auto-pushes an `AppContext` when none is active; `RequestContext.pop()` pops it if it created one |
| Incoming | [command-line-interface](command-line-interface.md) | CLI commands run inside `with app.app_context()` (`@with_appcontext`) |
| Incoming | [testing-support](testing-support.md) | `FlaskClient`/fixtures (`app_ctx`, `req_ctx` in `tests/conftest.py`) rely on clean push/pop |
| Incoming | [templating](templating.md) | `g` and `current_app` are injected into Jinja environments/template context |
| Incoming | [json-serialization](json-serialization.md), [helpers](helpers.md) | `url_for` falls back to `app_ctx.url_adapter` outside requests |

---

## 3. Component Reference

### 3.1 `AppContext`

The app context contains application-specific information. It is deliberately minimal — a handle on the app plus the state that only makes sense *while* app code runs.

**Construction (`__init__(app)`):**

```python
self.app = app
self.url_adapter = app.create_url_adapter(None)
self.g: _AppCtxGlobals = app.app_ctx_globals_class()
self._cv_tokens: list[contextvars.Token[AppContext]] = []
```

| Attribute | Description |
|---|---|
| `app` | The bound `Flask` instance (what `current_app` resolves to) |
| `url_adapter` | A Werkzeug `MapAdapter` bound to `SERVER_NAME` / `APPLICATION_ROOT` / `PREFERRED_URL_SCHEME`, enabling `url_for()` **outside** a request. `None` if `SERVER_NAME` is unset |
| `g` | Fresh `_AppCtxGlobals` namespace (class configurable via `Flask.app_ctx_globals_class`) |
| `_cv_tokens` | Stack of `contextvars.Token`s, one per nested `push()` — this is how re-entrancy/nesting is tracked |

**Lifecycle methods:**

- `push()` — appends `_cv_app.set(self)`'s token and sends the `appcontext_pushed` signal (with `app.ensure_sync` as the async wrapper so async receivers work under WSGI).
- `pop(exc=_sentinel)` — runs teardown **only on the outermost pop** (`len(self._cv_tokens) == 1`): resolves `exc` from `sys.exc_info()` if not supplied, then calls `self.app.do_teardown_appcontext(exc)`. Afterwards, always resets the `ContextVar` token, asserts the popped context identity (`"Popped wrong app context"` `AssertionError` on mismatch), and sends `appcontext_popped`.
- `__enter__` / `__exit__` — makes `with app.app_context():` work; the `with`-block's exception (if any) is forwarded as `exc` to `pop()`.

### 3.2 `_AppCtxGlobals` (the object behind `flask.g`)

A plain, attribute-based namespace created once per app context. Code running during a request or CLI command can stash arbitrary data on it (e.g., a DB connection cache):

| API | Semantics | Since |
|---|---|---|
| `g.name = value` / `g.name` / `del g.name` | Attribute access backed directly by `__dict__` (missing attrs raise `AttributeError`) | — |
| `'key' in g` | Membership test | 0.10 |
| `iter(g)` | Iterate attribute *names* | 0.10 |
| `g.get(name, default=None)` | Dict-like lookup | 0.10 |
| `g.pop(name, default=_sentinel)` | Get-and-remove; optional default avoids `KeyError` | 0.11 |
| `g.setdefault(name, default=None)` | Get-or-initialize | 0.11 |
| `repr(g)` | `"<flask.g of 'appname'>"` when an app context is active | — |

It is intentionally **not** thread-local by itself — its lifetime is exactly one app context, and the `ContextVar` underneath guarantees per-thread/per-task isolation.

### 3.3 `has_app_context()`

```python
return _cv_app.get(None) is not None
```

Cheap, allocation-free check for guarding code that may run inside or outside a context (equivalently, truth-testing `current_app`). Counterpart to `has_request_context()` documented in [contexts_request_context](contexts_request_context.md).

---

## 4. Lifecycle and Data Flow

### 4.1 Push / pop sequence

```mermaid
sequenceDiagram
    autonumber
    participant Caller as Caller<br/>(view, CLI, test, RequestContext)
    participant AC as AppContext
    participant CV as _cv_app (ContextVar)
    participant App as Flask app
    participant Sig as Signals
    participant TDF as teardown_appcontext funcs

    Caller->>AC: AppContext(app)
    AC->>App: create_url_adapter(None)
    AC->>App: app_ctx_globals_class()
    Note right of AC: g namespace + url_adapter ready

    Caller->>AC: push()
    AC->>CV: token = _cv_app.set(self)
    AC-->>Sig: appcontext_pushed.send(app)
    Note over Caller: current_app / g / app_ctx now live

    Caller->>AC: pop(exc?)
    alt outermost token
        AC->>App: do_teardown_appcontext(exc)
        App->>TDF: reversed(teardown_appcontext_funcs)(exc)
        App-->>Sig: appcontext_tearing_down.send(app, exc)
    end
    AC->>CV: _cv_app.reset(token)
    AC-->>Sig: appcontext_popped.send(app)
    Note over AC: AssertionError if wrong ctx on top
```

### 4.2 State machine

```mermaid
stateDiagram-v2
    [*] --> Unbound: AppContext(app) created (not yet bound)
    Unbound --> Active: push() / __enter__
    Active --> Active: nested push() (token stacked)
    Active --> Active: code uses current_app, g, url_for
    Active --> TearingDown: outermost pop(exc)
    TearingDown --> Active: nested pop() (token reset only)
    TearingDown --> Unbound: teardown run, token reset, popped signal
    Unbound --> [*]: context discarded
```

### 4.3 Nesting & refcount behavior (verified by `test_context_refcounts`, `test_clean_pop`)

- Every `push()` adds a token; every `pop()` removes one. Teardown callbacks run **once**, when the *last* token is popped.
- `RequestContext.push()` (see [contexts_request_context](contexts_request_context.md)) pushes a *new* app context only when none is active **or** the active one belongs to a different app; otherwise it borrows the existing one. The borrowed/created context is popped during `RequestContext.pop()`.
- Teardown receives the exception active at pop time: `None` when handled (by `except` or an error handler), the exception object when unhandled and `PROPAGATE_EXCEPTIONS` propagates it (`test_app_tearing_down_with_handled_exception_by_app_handler` vs. `..._with_unhandled_exception`).
- Failures in *request* teardown do not prevent *app* teardown from running — `pop()` wraps teardown in `try/finally` around the token reset (`test_clean_pop`).

---

## 5. Interaction with the Rest of the System

### 5.1 How a request gets an app context

```mermaid
flowchart TB
    subgraph Request["Request handling (application-core_flask-app)"]
        W[WSGI environ] --> WSGI["Flask.wsgi_app()"]
        WSGI --> RCP["RequestContext.push()"]
        RCP -->|"no active AppContext for this app"| ACP["AppContext.push()"]
        RCP -->|"one already active: borrow it"| SKIP[skip creation]
        ACP --> RD["open_session, match_request, dispatch"]
        SKIP --> RD
        RD --> RESP["finalize response"]
        RESP --> RPO["RequestContext.pop()"]
        RPO -->|"pops the AppContext it created"| APO["AppContext.pop: teardown_appcontext"]
    end
```

### 5.2 URL building outside requests

`AppContext` stores a `url_adapter` created with `request=None`. `Flask.url_for()` consults `_cv_request` first and falls back to `app_ctx.url_adapter` — this is why `flask.url_for("index")` works inside `with app.app_context():` **only when `SERVER_NAME` is configured**:

- `test_basic_url_generation` — `SERVER_NAME=localhost` + `PREFERRED_URL_SCHEME=https` ⇒ `url_for("index") == "https://localhost/"`.
- `test_url_generation_requires_server_name` — app context without `SERVER_NAME` ⇒ `RuntimeError`.
- `test_url_generation_without_context_fails` — no context at all ⇒ `RuntimeError`.

The same adapter mechanism is shared with blueprint-relative URL building — see [blueprints](blueprints.md) for endpoint naming.

### 5.3 Consumers

| Consumer | How it uses the app context |
|---|---|
| [contexts_request_context](contexts_request_context.md) | Guarantees/pops the app context around each request; `after_this_request` / `copy_current_request_context` are its request-side counterparts |
| [command-line-interface](command-line-interface.md) | `@with_appcontext` decorator, `shell_command` (`make_shell_context` exposes `app` and `g`), `test_app_cli_has_app_context`, `test_flaskgroup_app_context` |
| [templating](templating.md) | Jinja globals get the `g` and `current_app` proxies; `test_custom_app_ctx_globals_class` renders `{{ g.spam }}` from a custom globals class |
| [testing-support](testing-support.md) | `FlaskClient` can preserve contexts; `tests/conftest.py` exposes `app_ctx` / `req_ctx` fixtures; `leak_detector` asserts contexts are not leaked between tests |
| [signals](../) (Runtime & Diagnostics consumers) | `appcontext_pushed` / `appcontext_tearing_down` / `appcontext_popped` are extension hook points (`test_appcontext_signals`, `test_appcontext_tearing_down_signal` in `tests/test_signals.py`) |
| Extensions (e.g., DB pools) | Idiomatic pattern: cache a connection on `g` inside an app context, close it in a `teardown_appcontext` callback |

---

## 6. Usage Patterns

```python
from flask import g, current_app, has_app_context

# 1. Explicit use outside requests / CLI
with app.app_context():
    db = connect(current_app.config["DATABASE_URL"])
    g.db = db                      # stash on the g namespace
    url = flask.url_for("index")   # needs SERVER_NAME when outside a request

# 2. Teardown hook — runs at outermost pop(), even on exceptions
@app.teardown_appcontext
def close_db(exc):
    db = g.pop("db", None)
    if db is not None:
        db.close()                 # exc is None if no exception propagated

# 3. Defensive code that works inside or outside a context
def load_settings():
    if has_app_context():
        return current_app.config["SETTINGS"]
    return default_settings
```

---

## 7. Testing Coverage (`tests/test_appctx.py`)

The test suite pins down the contract of this module:

| Test | Verified behavior |
|---|---|
| `test_app_context_provides_current_app` | `current_app` resolves to the app inside, is falsy outside |
| `test_request_context_means_app_context` | A request context implies an active app context |
| `test_app_ctx_globals_methods` | Full `g` API: `get`, `in`, `setdefault`, `pop` (with/without default), iteration, `repr` |
| `test_custom_app_ctx_globals_class` | `Flask.app_ctx_globals_class` substitution reaches templates |
| `test_app_tearing_down` (+ 3 variants) | Teardown handlers receive `None` for no/handled exceptions, the exception for unhandled ones |
| `test_basic_url_generation`, `test_url_generation_requires_server_name`, `test_url_generation_without_context_fails` | `url_adapter`-backed URL building rules |
| `test_context_refcounts` | Nested manual pushes; teardown order request → app; `werkzeug.request` ref cleanup |
| `test_clean_pop` | App teardown still runs when request teardown raises; context is fully unbound afterward |

Cross-cutting guarantees: `tests/conftest.py`'s `leak_detector` fixture ensures no context survives a test, and `tests/test_signals.py` covers the three lifecycle signals fired by `push()`/`pop()`.

---

## 8. Design Notes & Invariants

1. **Token-stack, not counter** — `_cv_tokens` stores real `contextvars.Token`s so the `ContextVar` can be restored to its *previous* value on pop (supporting heterogenous nesting of different apps' contexts).
2. **Identity assertion on pop** — `pop()` raises `AssertionError` if the top of the `ContextVar` stack isn't `self`, catching mismatched push/pop order early.
3. **Teardown-once semantics** — teardown runs only when `len(self._cv_tokens) == 1`, making nested usage cheap and side-effect-free.
4. **Exception transparency** — `pop()` defaults `exc` to `sys.exc_info()[1]`; `with`-blocks pass the active exception explicitly. Handled exceptions yield `exc=None` to teardown handlers.
5. **Async compatibility** — signals are sent with `_async_wrapper=self.app.ensure_sync`, so async signal receivers work in the WSGI (sync) dispatch path.
6. **Circular-reference hygiene** — `RequestContext.pop` clears `environ["werkzeug.request"]` so request objects don't require the GC (implemented in the sibling module; described here because it shares the pop pipeline).

For the request-side half of this mechanism (binding `request`, `session`, routing, `after_this_request`, `copy_current_request_context`), see [contexts_request_context](contexts_request_context.md); for the app object that owns the factories and teardown registries, see [application-core_flask-app](application-core_flask-app.md).
