# application-core_sansio-foundation

## 1. Overview

The `application-core_sansio-foundation` module contains the **sans-I/O foundation** of Flask's application object: `flask/sansio/scaffold.py` and `flask/sansio/app.py`. These files define the *base classes* and *registration machinery* that both the concrete `Flask` application ([application-core_flask-app](application-core_flask-app.md)) and `Blueprint` ([blueprints](blueprints.md)) are built upon.

"Sans-I/O" means these base classes deliberately contain **no request/response dispatch logic** — no WSGI entry point, no view invocation, no response conversion, no server control. They instead provide:

| Concern | Provided by | Description |
|---|---|---|
| Shared registration registry | `Scaffold` | The data structures (`view_functions`, `error_handler_spec`, `before_request_funcs`, …) and decorators (`route`, `before_request`, `errorhandler`, …) shared by apps **and** blueprints |
| Application-level composition root | `App` | Config creation, aborter/JSON provider/Jinja wiring, URL map ownership, blueprint registration, error-handler resolution, URL building hooks |
| Setup-time safety | `setupmethod` | Decorator that freezes all registration state after the first request is handled |
| Config value coercion | `_make_timedelta` | Converts `int` seconds → `datetime.timedelta` for `PERMANENT_SESSION_LIFETIME` |
| Filesystem discovery | `find_package` / `_find_package_path` | Resolve `root_path`, install prefix, and the default `instance_path` |

The concrete I/O behavior (WSGI lifecycle, dispatch, response making, dev server) is contributed by the `Flask` subclass documented in [application-core_flask-app](application-core_flask-app.md).

### Primary source components

- `src/flask/sansio/app.py` — `App` base class, `_make_timedelta`
- `src/flask/sansio/scaffold.py` — `Scaffold` base class, `setupmethod`, `find_package`, `_find_package_path`, `_endpoint_from_view_func`

---

## 2. Architecture and Component Relationships

### 2.1 Class hierarchy

`Scaffold` is the shared root; `App` adds application-only composition; `Flask` adds the WSGI/IO layer; `Blueprint` reuses `Scaffold` for scoped registration.

```mermaid
classDiagram
    class Scaffold {
        «sansio/scaffold.py»
        +import_name
        +root_path
        +view_functions : dict
        +error_handler_spec : dict
        +before_request_funcs : dict
        +after_request_funcs : dict
        +teardown_request_funcs : dict
        +template_context_processors : dict
        +url_value_preprocessors : dict
        +url_default_functions : dict
        +static_folder / static_url_path
        +jinja_loader
        +route(rule, **options)*
        +add_url_rule(...)*
        +before_request(f)
        +after_request(f)
        +teardown_request(f)
        +errorhandler(code_or_exc)
        +register_error_handler(...)
        +_check_setup_finished(f_name)*
        +_get_exc_class_and_code(exc)$
    }
    class App {
        «sansio/app.py»
        +config : Config
        +instance_path
        +aborter : Aborter
        +json : JSONProvider
        +url_map : Map
        +blueprints : dict
        +extensions : dict
        +_got_first_request : bool
        +make_config(instance_relative) Config
        +make_aborter() Aborter
        +auto_find_instance_path() str
        +add_url_rule(...)
        +register_blueprint(bp, **options)
        +teardown_appcontext(f)
        +_find_error_handler(e, blueprints)
        +trap_http_exception(e) bool
        +redirect(location, code)
        +inject_url_defaults(...)
        +handle_url_build_error(...)
    }
    class Flask {
        «flask/app.py — see application-core_flask-app»
        +default_config : ImmutableDict
        +request_class / response_class
        +session_interface
        +wsgi_app(environ, start_response)
        +full_dispatch_request() Response
        +make_response(rv) Response
        +run(...) / test_client()
        +create_jinja_environment() Environment
        +create_url_adapter(request)
    }
    class Blueprint {
        «flask/blueprints.py — see blueprints»
        +register(app, options)
        +make_setup_state(app, options, first_registration)
    }
    class BlueprintSetupState {
        «flask/sansio/blueprints.py»
        +app : App
        +add_url_rule(rule, endpoint, view_func)
    }

    Scaffold <|-- App : extends
    App <|-- Flask : adds I/O dispatch
    Scaffold <|-- Blueprint : reuses registration registry
    BlueprintSetupState o-- App : registers rules onto
    BlueprintSetupState ..> Blueprint : created by make_setup_state
```

### 2.2 Module dependency architecture

The sansio foundation is the **composition point** where pluggable services (config, logging, templating, JSON, contexts) are wired into the application object via overridable class attributes (see [§4 Customization Points](#4-customization-points)).

```mermaid
flowchart TB
    subgraph sansio["application-core_sansio-foundation (this module)"]
        SCAFFOLD["Scaffold<br/>(sansio/scaffold.py)"]
        APP["App<br/>(sansio/app.py)"]
        SETUPMETHOD["setupmethod<br/>decorator"]
        MAKETD["_make_timedelta<br/>config converter"]
        FINDPKG["find_package /<br/>_find_package_path"]
    end

    subgraph io_layer["I/O layer"]
        FLASK["Flask (flask/app.py)<br/>application-core_flask-app"]
        BP["Blueprint (flask/blueprints.py)<br/>blueprints"]
    end

    subgraph services["Wired-in services"]
        CONFIG["Config / ConfigAttribute<br/>configuration"]
        LOG["create_logger<br/>logging"]
        TMPL["Environment,<br/>DispatchingJinjaLoader<br/>templating"]
        JSON["JSONProvider,<br/>DefaultJSONProvider<br/>json-serialization"]
        CTX["_AppCtxGlobals<br/>contexts"]
    end

    subgraph ext["External frameworks"]
        WZ["Werkzeug<br/>Map, Rule, Aborter,<br/>Response, redirect"]
        JINJA["Jinja2<br/>FileSystemLoader"]
    end

    SCAFFOLD --> APP
    SETUPMETHOD --> SCAFFOLD
    MAKETD --> APP
    FINDPKG --> SCAFFOLD
    APP --> FLASK
    SCAFFOLD --> BP
    BP -->|"BlueprintSetupState"| APP

    APP --> CONFIG
    APP --> LOG
    APP --> TMPL
    APP --> JSON
    APP --> CTX
    SCAFFOLD --> TMPL
    SCAFFOLD --> JINJA
    APP --> WZ
    FLASK -->|"overrides abstract hooks<br/>create_jinja_environment, add_url_rule, _check_setup_finished"| APP
```

---

## 3. Core Components

### 3.1 `Scaffold` (`src/flask/sansio/scaffold.py`)

Common behavior shared between `flask.Flask` and `flask.Blueprint`. Its defining feature is a set of **scope-keyed registries**: every registration structure is a `dict[AppOrBlueprintKey, ...]` where the key is a blueprint name, or `None` for app-wide scope. This is what makes the *same* decorators work on both `app` and `blueprint` objects.

#### Registration registries

| Registry | Populated by | Consumed by |
|---|---|---|
| `view_functions` | `route`, `add_url_rule`, `endpoint` | `Flask.dispatch_request()` |
| `error_handler_spec` (nested `{scope: {code: {exc_class: handler}}}`) | `errorhandler`, `register_error_handler` | `App._find_error_handler()` |
| `before_request_funcs` | `before_request` | `Flask.preprocess_request()` |
| `after_request_funcs` | `after_request` | `Flask.process_response()` |
| `teardown_request_funcs` | `teardown_request` | `Flask.do_teardown_request()` |
| `template_context_processors` (pre-seeded with `_default_template_ctx_processor` under `None`) | `context_processor` | `Flask.update_template_context()` |
| `url_value_preprocessors` | `url_value_preprocessor` | `Flask.preprocess_request()` |
| `url_default_functions` | `url_defaults` | `App.inject_url_defaults()` |

#### Route registration API

- `route(rule, **options)` — decorator; extracts `endpoint` from options and delegates to `add_url_rule`.
- `get/post/put/delete/patch` — shortcuts via `_method_route` (reject mixing e.g. `app.get("/", methods=["POST"])` with `TypeError`).
- `add_url_rule(...)` — abstract in `Scaffold` (raises `NotImplementedError`); fully implemented in `App` (see [§3.3](#33-add_url_rule--route-registration-pipeline-in-app)).
- `endpoint(name)` — binds a view function to an existing rule registered without a view.

#### Error handler registration

`errorhandler` / `register_error_handler` normalize the target through the static helper `_get_exc_class_and_code`:

```mermaid
flowchart LR
    A["code_or_exception"] --> B{"is int?"}
    B -- yes --> C["lookup in werkzeug<br/>default_exceptions"]
    C -- unknown code --> ERR["ValueError: not a<br/>recognized HTTP code"]
    C -- found --> D["exc_class = HTTPException subclass<br/>code = exc_class.code"]
    B -- no --> E{"is instance?"}
    E -- yes --> TERR["TypeError: handlers can only be<br/>registered for classes"]
    E -- no --> F{"issubclass Exception?"}
    F -- no -->VERR["ValueError: not a<br/>subclass of Exception"]
    F -- yes --> G{"HTTPException?"}
    G -- yes --> D
    G -- no --> H["exc_class only,<br/>code = None"]
    D --> I["error_handler_spec scope None<br/>[code][exc_class] = handler"]
    H --> I
```

Handlers registered here always target scope `None` (app-wide); `Blueprint` writes blueprint-scoped entries into the same structure — see [blueprints](blueprints.md).

#### Static/template assets & path discovery

- `static_folder` / `static_url_path` properties resolve relative paths against `root_path`, strip trailing slashes, and derive a default URL path from the folder basename (e.g. folder `static` → prefix `/static`).
- `jinja_loader` (cached) yields a `FileSystemLoader` on `root_path/template_folder`, or `None` if no template folder is configured. For apps, this loader is combined with blueprint loaders through `DispatchingJinjaLoader` — see [templating](templating.md).
- `_find_package_path(import_name)` uses `importlib.util.find_spec` to locate the containing directory, handling regular packages, single modules, **and PEP 420 namespace packages** (picking the search location that contains the submodule).
- `find_package(import_name)` further derives the install prefix: `sys.prefix` for system installs, the virtualenv parent for `site-packages` layouts, or `None` when not installed. This tuple feeds `App.auto_find_instance_path()`.

### 3.2 `App` (`src/flask/sansio/app.py`)

The sans-I/O application base class — the central composition object. It owns configuration, pluggable component classes, the URL map, and blueprint/error-handler resolution, but delegates all request I/O to its `Flask` subclass.

#### Construction sequence

```mermaid
sequenceDiagram
    participant U as User code
    participant F as Flask(import_name, ...)
    participant A as App.__init__
    participant S as Scaffold.__init__
    participant FS as find_package

    U->>F: Flask(__name__)
    F->>A: super().__init__(...)
    A->>S: import_name, static_folder,<br/>static_url_path, template_folder, root_path
    S->>FS: get_root_path / root discovery
    S-->>A: root_path, registries initialized
    A->>A: instance_path given? must be absolute<br/>else auto_find_instance_path()
    A->>A: config = make_config(instance_relative_config)<br/>(defaults + DEBUG from env)
    A->>A: aborter = make_aborter()
    A->>A: json = json_provider_class(self)
    A->>A: url_map = url_map_class(host_matching=...)
    A->>A: initialize blueprints, extensions,<br/>url_build_error_handlers,<br/>teardown_appcontext_funcs,<br/>shell_context_processors, subdomain_matching
    A-->>F: ready (no I/O created)
    F->>F: cli group, static route registration
```

Key behaviors during construction:

- **Instance path**: `auto_find_instance_path()` returns `<package_path>/instance` for uninstalled code, or `<prefix>/var/<name>-instance` when installed under a prefix. A user-supplied `instance_path` must be absolute, otherwise `ValueError` is raised.
- **Config**: `make_config()` builds a `config_class` (`Config`) rooted at `root_path` (or `instance_path` when `instance_relative_config=True`), seeded from `default_config`, with `DEBUG` resolved from the `FLASK_DEBUG` environment variable via `get_debug_flag()` — see [configuration](configuration.md).
- **No re-registration race**: the weakref-based static view (added in `Flask.__init__`) avoids reference cycles; the sansio layer keeps `_got_first_request = False` so setup is still allowed.

#### Config-bound attributes

Several class attributes are `ConfigAttribute` bridges (see [configuration](configuration.md)) so `app.testing = True` is equivalent to `app.config["TESTING"] = True`:

- `testing` → `TESTING`
- `secret_key` → `SECRET_KEY`
- `permanent_session_lifetime` → `PERMANENT_SESSION_LIFETIME`, **with `get_converter=_make_timedelta`**

#### `_make_timedelta`

```python
def _make_timedelta(value: timedelta | int | None) -> timedelta | None:
    if value is None or isinstance(value, timedelta):
        return value
    return timedelta(seconds=value)
```

A tiny but important coercion helper: it lets applications configure session lifetime either as a `timedelta` or as a plain number of seconds (`app.config["PERMANENT_SESSION_LIFETIME"] = 3600`), with `None` passing through untouched. It is attached to the `PERMANENT_SESSION_LIFETIME` `ConfigAttribute`, so every read through the attribute — including by the session interface in [sessions](sessions.md) — is guaranteed to be a `timedelta`.

#### Pluggable class attributes (factory hooks)

| Attribute | Default | Purpose |
|---|---|---|
| `aborter_class` | `werkzeug.exceptions.Aborter` | Object behind `flask.abort`; created by `make_aborter()` |
| `jinja_environment` | `flask.templating.Environment` | Jinja environment class ([templating](templating.md)) |
| `app_ctx_globals_class` | `flask.ctx._AppCtxGlobals` | Backing class of the `g` proxy ([contexts](contexts.md)) |
| `config_class` | `flask.config.Config` | Config container ([configuration](configuration.md)) |
| `json_provider_class` | `DefaultJSONProvider` | JSON serialization strategy, instantiated as `app.json` ([json-serialization](json-serialization.md)) |
| `url_rule_class` / `url_map_class` | `werkzeug.routing.Rule` / `Map` | Routing primitives; converters can be registered on `app.url_map.converters` before routes are added |
| `test_client_class` / `test_cli_runner_class` | `None` (→ `FlaskClient` / `FlaskCliRunner`) | Testing adapters ([testing-support](testing-support.md)) |

#### `jinja_env` & template services

- `jinja_env` is a `cached_property` creating the environment once, via `create_jinja_environment()` — abstract here (`NotImplementedError`), implemented in `Flask` ([application-core_flask-app](application-core_flask-app.md)). Changing `jinja_options` afterwards has no effect.
- `create_global_jinja_loader()` returns a `DispatchingJinjaLoader(self)` that dispatches between app and blueprint template folders.
- `select_jinja_autoescape(filename)` enables autoescaping for `.html`, `.htm`, `.xml`, `.xhtml`, and `.svg`.
- `template_filter` / `add_template_filter`, `template_test` / `add_template_test`, `template_global` / `add_template_global` write directly into `self.jinja_env.filters/tests/globals` — note this *accesses* `jinja_env`, so registering a filter effectively freezes the Jinja environment.

#### `debug` property

`debug` proxies `config["DEBUG"]`; the setter also flips `jinja_env.auto_reload` when `TEMPLATES_AUTO_RELOAD` is unset. Since it drives behavior that must be settled before serving, setting it late is discouraged (the `flask run` CLI in [command-line-interface](command-line-interface.md) resolves it from the environment early).

#### `add_url_rule` — route registration pipeline (`App` override)

```mermaid
flowchart TD
    START["add_url_rule(rule, endpoint?, view_func?, ...)"] --> EP{"endpoint given?"}
    EP -- no --> EP2["endpoint = _endpoint_from_view_func<br/>(function __name__)"]
    EP -- yes --> M
    EP2 --> M{"methods in options?"}
    M -- no --> M2["methods = view_func.methods<br/>or ('GET',)"]
    M -- yes --> M3{"is str?"}
    M2 --> M4["normalize to upper-case set"]
    M3 -- yes --> TERR["TypeError: methods must be<br/>a list of strings"]
    M3 -- no --> M4
    M4 --> OPT{"provide_automatic_options<br/>resolved?"}
    OPT -- "'OPTIONS' not in methods and<br/>config PROVIDE_AUTOMATIC_OPTIONS" --> AUTO["add OPTIONS to required_methods,<br/>provide_automatic_options = True"]
    OPT -- otherwise --> NOAUTO["provide_automatic_options = False"]
    AUTO --> RULE
    NOAUTO --> RULE["rule_obj = url_rule_class(rule,<br/>methods, **options)"]
    RULE --> ADDMAP["url_map.add(rule_obj)"]
    ADDMAP --> VF{"view_func given?"}
    VF -- yes --> CONFLICT{"endpoint already mapped<br/>to different func?"}
    CONFLICT -- yes --> AERR["AssertionError: view function mapping<br/>is overwriting an existing endpoint"]
    CONFLICT -- no --> REG["view_functions[endpoint] = view_func"]
    VF -- no --> DONE["done (endpoint may be bound later<br/>via endpoint decorator)"]
    REG --> DONE
```

All of this is guarded by `@setupmethod`, so any call after the first request raises `AssertionError`.

#### Blueprint registration

`register_blueprint(blueprint, **options)` records the blueprint in `self.blueprints` (via `blueprint.register(self, options)`) and delegates rule addition to `BlueprintSetupState.add_url_rule`, which prefixes endpoints with the blueprint name (`name_prefix.name.endpoint`) and merges URL prefixes/defaults. `iter_blueprints()` iterates in registration order. Full details in [blueprints](blueprints.md).

#### Error handler resolution — `_find_error_handler`

Called by the `Flask` I/O layer's exception handling with the list of active blueprints (`request.blueprints`):

1. Iterate candidate codes: `[code, None]` when the exception has an HTTP code, else `[None]`.
2. Iterate scopes: `(*blueprint_names, None)` — most specific blueprint first, app last.
3. Within each map, walk the exception class **MRO** so subclass handlers win over base-class handlers.

This ordering implements Flask's documented precedence: blueprint handler for exact code → app handler for exact code → blueprint handler by exception class (MRO) → app handler by exception class. Behavior is validated by `test_errorhandler_precedence` and the handlers suite in [application-core_test-suite](application-core_test-suite.md).

#### URL building support

- `inject_url_defaults(endpoint, values)` — runs `url_default_functions` for `None` plus the blueprint chain derived from a dotted endpoint (works outside a request by parsing the endpoint string rather than reading `request.blueprints`).
- `handle_url_build_error(error, endpoint, values)` — consults `url_build_error_handlers`; each handler returning a non-`None` string short-circuits and is returned by `url_for`; handlers raising `BuildError` are skipped. If no handler yields a value, the `BuildError` is re-raised (preserving the active exception when applicable).
- `redirect(location, code=302)` — creates a redirect using `self.response_class`, so subclasses swapping `response_class` get consistent redirect objects; `flask.redirect` ([helpers](helpers.md)) delegates here.

#### HTTP exception trapping

`trap_http_exception(e)` decides whether an `HTTPException` bypasses error handlers (useful for debugging implicit aborts): `TRAP_HTTP_EXCEPTIONS` traps everything; `TRAP_BAD_REQUEST_ERRORS` traps `BadRequest` subclasses; when unset, `BadRequestKeyError` is trapped only in debug mode. `should_ignore_error(error)` (default: never ignore) lets the context teardown machinery suppress errors — see [contexts](contexts.md).

### 3.3 `setupmethod` (`src/flask/sansio/scaffold.py`)

The guard that enforces Flask's **"no setup after first request"** invariant:

```python
def setupmethod(f: F) -> F:
    f_name = f.__name__

    def wrapper_func(self: Scaffold, *args, **kwargs):
        self._check_setup_finished(f_name)
        return f(self, *args, **kwargs)

    return t.cast(F, update_wrapper(wrapper_func, f))
```

- `Scaffold._check_setup_finished` is abstract; `App` implements it to raise `AssertionError` when `self._got_first_request` is `True` (set by `Flask.full_dispatch_request()`), with a message explaining that changes would not apply consistently.
- Every registration entry point is wrapped: `route`, `add_url_rule`, `endpoint`, `get/post/put/delete/patch`, `before_request`, `after_request`, `teardown_request`, `context_processor`, `url_value_preprocessor`, `url_defaults`, `errorhandler`, `register_error_handler` (from `Scaffold`), plus `register_blueprint`, template filter/test/global registration, `teardown_appcontext`, and `shell_context_processor` (from `App`).
- `update_wrapper` preserves the wrapped function's name/docstring, so introspection and docs remain intact.
- `Flask.run()` resets `_got_first_request = False` after the dev server stops, allowing interactive re-setup in a shell session.

**Regression coverage:** `tests/test_basic.py::test_no_setup_after_first_request` asserts that a late `app.add_url_rule(...)` raises `AssertionError` mentioning `setup method 'add_url_rule'`.

```mermaid
stateDiagram-v2
    [*] --> Setup: App created
    Setup --> Setup: route / blueprint / handler<br/>registration allowed
    Setup --> Frozen: Flask.full_dispatch_request()<br/>sets _got_first_request = True
    Frozen --> Frozen: setupmethod calls raise<br/>AssertionError
    Frozen --> Setup: dev server shutdown<br/>(run() resets flag)
    Setup --> [*]
```

---

## 4. Customization Points

The sansio layer's class-attribute pattern is Flask's primary extension mechanism. Subclassing `Flask` and overriding any of these changes app-wide behavior without touching request code:

```python
class MyFlask(Flask):
    config_class = MyConfig                    # configuration
    jinja_environment = MyEnvironment          # templating
    json_provider_class = MyJSONProvider       # json-serialization
    app_ctx_globals_class = MyGlobals          # contexts
    url_rule_class = MyRule                    # e.g. strict routing
    test_client_class = MyClient               # testing-support

    def create_jinja_environment(self):
        env = super().create_jinja_environment()
        ...                                    # I/O-layer hook (Flask implements)
```

**Important timing constraint:** because `jinja_env` is a cached property created on first access (and template filter registration accesses it eagerly), swap class attributes *before* any template registration, and always before the first request (enforced by `setupmethod`).

---

## 5. Request-independent Data Flow: Configuration → Routing

Although dispatch lives in the I/O layer, this module owns the data those flows consume:

```mermaid
flowchart LR
    subgraph setup["Setup phase (guarded by setupmethod)"]
        C["Config<br/>configuration"] -->|"ConfigAttribute<br/>testing / secret_key /<br/>PERMANENT_SESSION_LIFETIME"| APPC["App attributes"]
        R1["route / add_url_rule"] --> UM["url_map : Map<br/>(url_rule_class rules)"]
        R1 --> VF["view_functions"]
        BP["register_blueprint<br/>blueprints"] --> UM
        BP --> VF
        EH["errorhandler /<br/>register_error_handler"] --> EHS["error_handler_spec"]
        PR["before/after/teardown_request,<br/>context_processor,<br/>url_defaults/preprocessors"] --> FUNCS["scoped func registries"]
    end
    subgraph runtime["Runtime phase (I/O layer)"]
        UM --> MATCH["Flask: URL matching<br/>(create_url_adapter, TRUSTED_HOSTS)"]
        VF --> DISPATCH["Flask: dispatch_request"]
        EHS --> RESOLVE["_find_error_handler(e,<br/>request.blueprints)"]
        FUNCS --> HOOKS["preprocess_request /<br/>process_response / teardown"]
    end
    APPC --> RUNTIMECFG["Request limits, trusted hosts,<br/>session lifetime read from config"]
    RUNTIMECFG --> MATCH
    RESOLVE --> RESP["Response or raised error"]
```

Config-driven runtime knobs exercised by this module's tests (validated against `default_config` defined in the `Flask` subclass):

- `TRUSTED_HOSTS` — host validation applied when the URL adapter is created (`test_trusted_hosts_config`: allowed exact host, allowed suffix-dot host, mismatch → `400`).
- `MAX_CONTENT_LENGTH`, `MAX_FORM_MEMORY_SIZE`, `MAX_FORM_PARTS` — request limits; `Request` reads them from the app context when active and honors per-request overrides (`test_limit_config`).

---

## 6. Interaction with Other Modules

| Related module | Relationship |
|---|---|
| [application-core_flask-app](application-core_flask-app.md) | `Flask(App)` implements the abstract hooks (`create_jinja_environment`, I/O `add_url_rule` behavior via `Flask.full_dispatch_request`, `_check_setup_finished` flag setter) and owns `default_config`, `wsgi_app`, `run`, `test_client` |
| [blueprints](blueprints.md) | `Blueprint(Scaffold)` reuses the scoped registries; `BlueprintSetupState` (also defined under `flask/sansio/`) receives the `App` instance and calls its `add_url_rule` with prefixed endpoints |
| [configuration](configuration.md) | `Config`/`ConfigAttribute` power `app.config`, `debug`, `testing`, `secret_key`, `permanent_session_lifetime` (via `_make_timedelta`) |
| [contexts](contexts.md) | `_AppCtxGlobals` is the default `app_ctx_globals_class`; app teardown functions are invoked by `AppContext.pop()` → `do_teardown_appcontext` |
| [templating](templating.md) | Supplies `Environment`, `DispatchingJinjaLoader`, and `_default_template_ctx_processor` (pre-registered in `Scaffold`) |
| [json-serialization](json-serialization.md) | `JSONProvider`/`DefaultJSONProvider` instantiated as `app.json` at construction |
| [logging](logging.md) | `create_logger(self)` backs the `logger` cached property |
| [helpers](helpers.md) | `flask.redirect`/`url_for`/`make_response` delegate to `App.redirect`/`App.url_for`/`App.handle_url_build_error` and `Flask.make_response`; `get_root_path`/`get_debug_flag`/`_split_blueprint_path` are consumed here |
| [application-core_debug-helpers](application-core_debug-helpers.md) | Debug exceptions (e.g. `FormDataRoutingRedirect`) raised by the I/O layer's `raise_routing_exception`, enabled by the `debug` property defined here |
| [testing-support](testing-support.md) | `FlaskClient`/`FlaskCliRunner` types; `test_client()` in the I/O layer instantiates `test_client_class` |
| [command-line-interface](command-line-interface.md) | `flask run`/`--debug` drive the `DEBUG` config and `debug` property; `App.cli` is declared on `Scaffold` and instantiated by `Flask` |

---

## 7. Testing Coverage

This module's tests focus on the foundation's guarantees, independent of request I/O:

| Test | File | What it verifies |
|---|---|---|
| `test_no_setup_after_first_request` | `tests/test_basic.py` | `setupmethod` freeze: late `add_url_rule` → `AssertionError` |
| `test_explicit_instance_paths` | `tests/test_instance_config.py` | Relative `instance_path` rejected; absolute accepted |
| `test_installed_package_paths` | `tests/test_instance_config.py` | Installed package → `<prefix>/var/<name>-instance` |
| `test_uninstalled_namespace_paths` | `tests/test_instance_config.py` | PEP 420 namespace packages resolve to the correct project `instance` dir |
| `test_custom_converters` | `tests/test_converters.py` | `app.url_map.converters` extension before routing; match + `url_for` round-trip |
| `test_context_available` | `tests/test_converters.py` | Converter `to_python` runs with request/session proxies available |
| `test_trusted_hosts_config` | `tests/test_request.py` | `TRUSTED_HOSTS` config → host validation (400 on mismatch) |
| `test_limit_config` | `tests/test_request.py` | `MAX_CONTENT_LENGTH`/`MAX_FORM_MEMORY_SIZE`/`MAX_FORM_PARTS` flow from config into `Request`, with override precedence |
| `hello_str`, `tuple_status` | `tests/type_check/typing_route.py` | Static typing of `route` decorator and allowed return types (`str`, `tuple[str, int]`) |
| `before_sync` | `tests/type_check/typing_app_decorators.py` | Static typing of `@app.before_request` |
| `handle_multiple` | `tests/type_check/typing_error_handler.py` | Static typing of stacked `@app.errorhandler(...)` with union handler signatures |

The type-check files are exercised by static analyzers rather than pytest, pinning the decorator/`errorhandler` overload contracts that `setupmethod`-wrapped methods present to user code.

---

## 8. Summary

`application-core_sansio-foundation` is the structural backbone of Flask:

1. **`Scaffold`** unifies app/blueprint registration through scope-keyed registries and wraps every mutator with `setupmethod`.
2. **`App`** is the composition root: it instantiates config, aborter, JSON provider, URL map, and Jinja services through overridable class attributes, resolves error handlers with blueprint/code/MRO precedence, and implements URL-building hooks — all without touching I/O.
3. **`setupmethod` + `_got_first_request`** guarantee configuration immutability at runtime, eliminating a whole class of "registered too late" bugs.
4. **`_make_timedelta`** and the `ConfigAttribute` bridges show the module's broader theme: normalize user-facing values once, at the boundary, so downstream consumers (sessions, request limits, routing) see well-typed data.

All request execution concerns are intentionally absent and are layered on by [application-core_flask-app](application-core_flask-app.md), while [blueprints](blueprints.md) demonstrates how the same foundation scales to modular, nestable route groups.
