# Test Client Infrastructure (`EnvironBuilder`, `FlaskClient`)

> **Module:** Developer Interface → Testing Tooling → `testing-support` → **`test-client`**
> **Source code:** `src/flask/testing.py`
> **Test suite:** `tests/test_testing.py` (see [testing-support_test-suite](testing-support_test-suite.md))

---

## 1. Purpose

The **test-client** module provides the two classes that make HTTP-level testing of a Flask application possible **without a running server**:

| Class | Wraps | Role |
|---|---|---|
| [`EnvironBuilder`](#3-environbuilder) | `werkzeug.test.EnvironBuilder` | Builds WSGI environments / `Request` objects using **application configuration** as defaults (`SERVER_NAME`, `APPLICATION_ROOT`, `PREFERRED_URL_SCHEME`) and the app's own **JSON provider** for payloads. |
| [`FlaskClient`](#4-flaskclient) | `werkzeug.test.Client` | The in-process "test browser". Dispatches WSGI requests directly into `Flask.wsgi_app()`, injects default client metadata, manages **context preservation** across `with` blocks, and offers `session_transaction()` for direct session manipulation. |

Both classes are created through factories on the application object — `Flask.test_client()` and `Flask.test_request_context()` — documented in [application-core](application-core.md). The sibling [`FlaskCliRunner`](testing-support_cli-runner.md) completes the testing toolkit for CLI commands.

---

## 2. Architecture

The module is an **adapter layer**: all HTTP mechanics (multipart encoding, cookie jars, redirect following, response wrapping) come from Werkzeug; Flask's contribution is *application-awareness* — configuration defaults, the context stack, the session interface, and the JSON provider.

```mermaid
classDiagram
    direction LR

    class EB_werkzeug["werkzeug.test.EnvironBuilder"] {
        +get_environ() WSGIEnvironment
        +get_request() Request
        +from_environ(environ, ...) EnvironBuilder
        +json_dumps(obj) str
        +environ_base: dict
    }
    class EnvironBuilder {
        +app: Flask
        +__init__(app, path, base_url, subdomain, url_scheme)
        +json_dumps(obj) str
    }
    class Client_werkzeug["werkzeug.test.Client"] {
        +open(request) TestResponse
        +_cookies: CookieJar
        +_add_cookies_to_wsgi(environ)
        +_update_cookies_from_response(host, path, headers)
    }
    class FlaskClient {
        +application: Flask
        +preserve_context: bool
        +_new_contexts: list
        +_context_stack: ExitStack
        +environ_base: dict
        +open(...) TestResponse
        +session_transaction() SessionMixin
        +__enter__ / __exit__
        -_copy_environ(other)
        -_request_from_builder_args(args, kwargs)
    }
    class Flask {
        +test_client() FlaskClient
        +test_request_context(...) RequestContext
        +wsgi_app(environ, start_response)
        +config
        +json: JSONProvider
        +session_interface
    }

    EB_werkzeug <|-- EnvironBuilder
    Client_werkzeug <|-- FlaskClient

    Flask ..> FlaskClient : factory "test_client()"
    Flask ..> EnvironBuilder : factory "test_request_context()"
    FlaskClient ..> EnvironBuilder : builds every request
    EnvironBuilder ..> Flask : reads config + json provider
    Flask ..> FlaskClient : "werkzeug.debug.preserve_context" handshake
```

### 2.1 Where this module sits in the testing stack

```mermaid
flowchart TB
    subgraph this["testing-support_test-client (this module)"]
        FC["FlaskClient"]
        EB["EnvironBuilder"]
    end

    APP["application-core<br/>Flask.test_client() / wsgi_app()"] --> FC
    EB --> APP
    CX["contexts<br/>AppContext / RequestContext<br/>push-pop lifecycle"] <--> FC
    SS["sessions<br/>session_interface<br/>open_session / save_session"] <--> FC
    JS["json-serialization<br/>app.json provider"] <--> EB
    TS["testing-support_test-suite<br/>tests/test_testing.py"] --> FC
    INFRA["test-infrastructure<br/>conftest.py: app / client fixtures"] --> TS
    CLI["testing-support_cli-runner<br/>FlaskCliRunner"] -.->|"same file, separate doc"| FC
```

---

## 3. EnvironBuilder

An `EnvironBuilder` takes defaults from the **application** instead of hard-coded values, so tests automatically behave like deployments configured via `app.config`.

### 3.1 Construction and base-URL derivation

```python
EnvironBuilder(app, path="/", base_url=None, subdomain=None, url_scheme=None, *args, **kwargs)
```

The constructor enforces a mutual-exclusion rule and then derives `base_url` from app configuration:

```mermaid
flowchart TD
    A["EnvironBuilder(app, path, base_url, subdomain, url_scheme)"] --> B{"base_url XOR (subdomain or url_scheme)?<br/>assert: cannot pass subdomain/url_scheme with base_url"}
    B -->|"violation"| ERR["AssertionError"]
    B -->|"base_url given"| SUPER["super().__init__(path, base_url)"]
    B -->|"no base_url"| C["http_host = SERVER_NAME or 'localhost'<br/>app_root = APPLICATION_ROOT"]
    C --> D{"subdomain given?"}
    D -->|"yes"| E["http_host = 'subdomain.http_host'"]
    D -->|"no"| F["url_scheme = PREFERRED_URL_SCHEME (if not given)"]
    E --> F
    F --> G["urlsplit(path):<br/>support full URLs inside 'path'"]
    G --> H["base_url = 'scheme://host/app_root.lstrip('/')'<br/>scheme = url.scheme or url_scheme<br/>host = url.netloc or http_host"]
    H --> I["path = url.path ('?' + query appended back)"]
    I --> SUPER
    SUPER --> DONE["self.app = app — ready to build environ"]
```

Key behaviors:

| Behavior | Detail | Config keys consumed |
|---|---|---|
| Host default | `SERVER_NAME`, else `"localhost"` | `SERVER_NAME` |
| Script root | `APPLICATION_ROOT` becomes the base-URL path segment (mapped to WSGI `SCRIPT_NAME`) | `APPLICATION_ROOT` |
| Scheme default | `PREFERRED_URL_SCHEME` unless overridden | `PREFERRED_URL_SCHEME` |
| Subdomain shortcut | Prepends `subdomain.` to the host — enables subdomain-routing tests without `base_url` bookkeeping | `SERVER_NAME` |
| Full URL in `path` | `path="/https://example.com/x?y=1"` is split; its scheme/netloc win over defaults and the query string is preserved | — |

The same builder is reused by `Flask.test_request_context()` (see [application-core_flask-app](application-core_flask-app.md)), so manual context tests (`with app.test_request_context("/"): ...`) share identical URL semantics with client-driven tests.

### 3.2 App-owned JSON serialization

`json_dumps()` overrides Werkzeug's serializer to delegate to the application:

```python
def json_dumps(self, obj, **kwargs):
    return self.app.json.dumps(obj, **kwargs)
```

A `json={"key": value}` argument on any client request is therefore serialized with the app's configured [`JSONProvider`](json-serialization.md) (indentation, key sorting, custom encoders all apply). Werkzeug calls this method internally when it builds the request body.

---

## 4. FlaskClient

`FlaskClient` is the WSGI test client returned by `app.test_client()`. It adds four Flask-specific capabilities on top of `werkzeug.test.Client`: default environ metadata, app-aware request building, context preservation, and session transactions.

### 4.1 Client state

| Attribute | Initial value | Purpose |
|---|---|---|
| `application` | the `Flask` app | Target of dispatch; source of config/JSON/session behavior. |
| `environ_base` | `{"REMOTE_ADDR": "127.0.0.1", "HTTP_USER_AGENT": "Werkzeug/<version>"}` | Merged into every request environ; mutable, so tests can spoof IPs/agents (the Werkzeug version string is resolved once via `importlib.metadata` and cached). |
| `preserve_context` | `False` | Set to `True` while inside a `with client:` block; plants the preservation hook into request environs. |
| `_new_contexts` | `[]` | Inbox for contexts handed back by `wsgi_app` during a preserved request. |
| `_context_stack` | `ExitStack()` | Holds re-entered contexts; closed to pop them. |

### 4.2 Request pipeline — `open()`

Every `client.get/post/...` convenience method funnels into `open()`, which accepts **four kinds of inputs** and normalizes them into a single `Request`:

```mermaid
flowchart TD
    A["client.open(*args, buffered=False, follow_redirects=False, **kwargs)"] --> B{"type of args[0]?"}
    B -->|"EnvironBuilder"| C["copy builder<br/>builder.environ_base =<br/>_copy_environ(builder.environ_base)"]
    B -->|"dict (raw environ)"| D["EnvironBuilder.from_environ(<br/>environ, app, environ_base=<br/>_copy_environ({}))"]
    B -->|"Request instance"| E["copy request<br/>request.environ =<br/>_copy_environ(request.environ)"]
    B -->|"str path / None"| F["_request_from_builder_args:<br/>kwargs['environ_base'] = _copy_environ(...)<br/>EnvironBuilder(application, *args, **kwargs)<br/>.get_request() (builder closed in finally)"]
    C --> G["Close previously preserved contexts<br/>_context_stack.close()"]
    D --> G
    E --> G
    F --> G
    G --> H["super().open(request)<br/>→ app.wsgi_app(environ, start_response)"]
    H --> I["response.json_module = application.json<br/>(resp.get_json() uses the app's provider)"]
    I --> J["Re-push preserved contexts:<br/>while _new_contexts:<br/>  _context_stack.enter_context(cm)"]
    J --> K["return TestResponse"]
```

`_copy_environ(other)` is the merge point: it layers `self.environ_base` under the caller's overrides, and — **only when `preserve_context` is active** — plants the handshake key:

```python
out = {**self.environ_base, **other}
if self.preserve_context:
    out["werkzeug.debug.preserve_context"] = self._new_contexts.append
```

### 4.3 Context preservation

The signature feature: inside a `with client:` block, request/app contexts survive *after* the response is returned, so tests can inspect `flask.request`, `flask.g`, and `flask.session`. The mechanism is a cooperative handshake with [`Flask.wsgi_app`](application-core_flask-app.md):

```mermaid
sequenceDiagram
    autonumber
    participant T as Test code
    participant C as FlaskClient
    participant W as Flask.wsgi_app
    participant X as RequestContext + AppContext

    T->>C: with client (__enter__)
    C->>C: preserve_context = True (nesting raises RuntimeError)

    T->>C: client.get("/")
    C->>C: _copy_environ plants<br/>environ["werkzeug.debug.preserve_context"] = _new_contexts.append
    C->>C: _context_stack.close() — drop stale contexts
    C->>W: WSGI dispatch
    W->>X: ctx.push() → dispatch → response ready
    Note over W,X: finally block (before pop)<br/>preserve_context(app_ctx) then preserve_context(req_ctx)
    W->>X: ctx.pop(error) — teardown runs, contexts handed back
    W-->>C: Response
    C->>C: re-enter popped contexts into _context_stack
    C-->>T: TestResponse

    T->>T: assert flask.g.value == 42 (context alive!)

    T->>C: leave with block (__exit__)
    C->>C: preserve_context = False<br/>_context_stack.close() → teardown already done, objects released
```

Hygiene rules enforced by the implementation:

1. **No nesting** — `__enter__` raises `RuntimeError("Cannot nest client invocations")` if `preserve_context` is already `True`.
2. **Pop-before-request** — `open()` closes the `ExitStack` *before* dispatching, so contexts cannot leak across redirects followed by `follow_redirects=True` or across successive requests in one block (contract: `test_client_pop_all_preserved`).
3. **Deferred, not duplicated, teardown** — `wsgi_app` calls the preservation hook *before* `ctx.pop(error)`, so `teardown_request`/`teardown_appcontext` still execute on time; preservation only keeps the Python objects reachable (see [contexts](contexts.md) for the push/pop lifecycle).

### 4.4 Session transactions — `session_transaction()`

A context manager to **read and mutate the session out-of-band**, as if the browser had a cookie, without a request doing it first:

```mermaid
sequenceDiagram
    autonumber
    participant T as Test code
    participant C as FlaskClient
    participant RC as test_request_context
    participant SI as app.session_interface
    participant J as Cookie jar (_cookies)

    T->>C: with client.session_transaction() as session:
    C->>C: _cookies is None? → TypeError<br/>"Cookies are disabled… use_cookies=True"
    C->>RC: app.test_request_context(*args, **kwargs)<br/>(built via EnvironBuilder)
    C->>J: _add_cookies_to_wsgi(ctx.request.environ)
    C->>SI: open_session(app, request) inside ctx
    SI-->>C: session (None → RuntimeError)
    C-->>T: yield session — test mutates it

    Note over T: with-block exits
    C->>C: null session? → return (nothing saved)
    C->>SI: save_session(app, sess, response)
    SI-->>J: Set-Cookie headers → _update_cookies_from_response
    Note over J: subsequent client requests send the updated cookie
```

Details worth knowing:

- Accepts the same arguments as `Flask.test_request_context()` (path, subdomain, …), because session backends may depend on request data ([sessions](sessions.md)).
- Works **through the real session interface**, so custom session backends are exercised honestly — `test_session_transactions_no_null_sessions` guards against misuse with `NullSession`.
- Cookie round-trip (`_add_cookies_to_wsgi` / `_update_cookies_from_response`) is delegated to the Werkzeug client's cookie jar, keeping `session_transaction()` consistent with ordinary requests (contract: `test_redirect_keep_session`).

---

## 5. End-to-end data flow

A complete view of one preserved, JSON request — how config, JSON provider, session interface and contexts cooperate:

```mermaid
flowchart LR
    subgraph test["Test code"]
        req["client.post('/x', json={'a': 1})<br/>inside 'with client:'"]
        check["resp.get_json()<br/>assert flask.g / session"]
    end

    subgraph client_mod["testing_test-client"]
        merge["_copy_environ:<br/>environ_base + preserve hook"]
        eb["EnvironBuilder<br/>app.json.dumps(payload)<br/>base_url from SERVER_NAME /<br/>APPLICATION_ROOT / PREFERRED_URL_SCHEME"]
        stack["ExitStack close → open"]
    end

    subgraph app_mod["application-core"]
        wsgi["Flask.wsgi_app"]
        ctx["ctx.push() →<br/>full_dispatch_request() →<br/>ctx.pop() + preserve hook"]
    end

    req --> merge --> eb --> stack --> wsgi --> ctx --> stack
    ctx -->|"Response"| req
    ctx -.->|"preserved contexts"| check
    eb -.->|"json_module"| check
```

---

## 6. Integration with the Rest of the System

| Dependency | Owning module | Interaction in this module |
|---|---|---|
| `Flask.test_client()`, `test_request_context()`, `wsgi_app()` | [application-core](application-core.md) | Factories instantiate these classes (honoring `app.test_client_class` overrides); `wsgi_app` is the dispatch target and the other half of the `preserve_context` handshake. |
| `AppContext` / `RequestContext` push/pop, teardown | [contexts](contexts.md) | Preservation = deferred re-entry of already-popped context objects via `ExitStack`; teardown callbacks are **not** deferred. |
| `session_interface.open_session / save_session / is_null_session`, `SessionMixin` | [sessions](sessions.md) | `session_transaction()` drives the real session backend and the client cookie jar. |
| `app.json` (`JSONProvider`, `DefaultJSONProvider`) | [json-serialization](json-serialization.md) | Request-side: `EnvironBuilder.json_dumps`. Response-side: `TestResponse.json_module`, so `resp.get_json()` matches app behavior. |
| `SERVER_NAME`, `APPLICATION_ROOT`, `PREFERRED_URL_SCHEME` | [configuration](configuration.md) | Read at build time to derive `base_url` — tests inherit deployment configuration. |
| `ScriptInfo` (used by `FlaskCliRunner`) | [command-line-interface](command-line-interface.md) | Not part of the request path; see [testing-support_cli-runner](testing-support_cli-runner.md). |
| `app` / `client` pytest fixtures | [test-infrastructure](test-infrastructure.md) | `tests/test_testing.py` consumes the shared fixtures from `tests/conftest.py`. |

---

## 7. Observable Contracts (verified by the test suite)

The behavioral guarantees locked in by [testing-support_test-suite](testing-support_test-suite.md) (`tests/test_testing.py`):

| Contract | Tests |
|---|---|
| Config-driven defaults: host, scheme, and script root derived from `SERVER_NAME` / `PREFERRED_URL_SCHEME` / `APPLICATION_ROOT` | `test_environ_defaults`, `test_environ_defaults_from_config` |
| Subdomain & scheme shortcuts; host handling for blueprints | `test_subdomain`, `test_nosubdomain`, `test_blueprint_with_subdomain`, `test_specify_url_scheme` |
| Full URL accepted as `path` | `test_path_is_url`, `test_full_url_request` |
| `environ_base` defaults present and overridable per request | `test_environ_base_default`, `test_environ_base_modified` |
| App-owned JSON on both request and response sides | `test_environbuilder_json_dumps`, `test_json_request_and_response`, `test_client_json_no_app_context` |
| Raw environ / existing environ reuse | `test_client_open_environ` |
| Context preservation semantics and strict pop-all hygiene | `test_test_client_context_binding`, `test_client_pop_all_preserved`, `test_session_transactions_keep_context` |
| Session transactions: real interface, cookie round-trip, guard rails | `test_session_transactions`, `test_session_transactions_no_null_sessions`, `test_session_transaction_needs_cookies`, `test_redirect_keep_session` |
| Client reuse is safe | `test_reuse_client` |

---

## 8. Design Notes & Edge Cases

1. **Adapter, not reimplementation.** Cookies, multipart, redirects, and response wrapping are Werkzeug's; this module only injects Flask awareness (config, contexts, sessions, JSON).
2. **Version-string caching.** `HTTP_USER_AGENT` embeds the installed Werkzeug version, resolved once through `importlib.metadata` and cached in a module global — avoiding repeated metadata lookups per request.
3. **Assertion-based misconfiguration guard.** Passing `subdomain`/`url_scheme` *together with* `base_url` fails fast with an `AssertionError`, since the two would encode contradictory host/scheme information.
4. **Preservation shares the debugger's channel.** The `werkzeug.debug.preserve_context` environ key is the same hook the interactive debugger uses, so `wsgi_app` needs no testing-specific branching ([application-core](application-core.md)).
5. **Teardown is never skipped.** Preserved contexts are popped (teardown functions, signals) before being handed to the client; only the objects remain alive. Tests that assert on DB connections etc. must account for teardown having run (`test_session_transactions_keep_context`).
6. **Null-session short circuit.** `session_transaction()` returns without saving when the opened session is a `NullSession` (secret key unset / disabled backend), mirroring production behavior where such sessions are never persisted.
