# Testing Support: Test Suite

## 1. Introduction

The `testing-support_test-suite` module contains the functional test suite (`tests/test_testing.py`) that validates Flask's testing support utilities end-to-end. While the sibling modules [testing-support_test-client](testing-support_test-client.md) and [testing-support_cli-runner](testing-support_cli-runner.md) document the *implementation* of `EnvironBuilder`, `FlaskClient`, and `FlaskCliRunner` (in `src/flask/testing.py`), this module documents the *verification* of those behaviors through pytest-based integration tests.

The test suite exercises the full request/response lifecycle against a real `Flask` application instance — via `app.test_client()`, `app.test_request_context()`, and `app.test_cli_runner()` — ensuring that:

- **WSGI environment construction** respects application configuration (`SERVER_NAME`, `APPLICATION_ROOT`, `PREFERRED_URL_SCHEME`).
- **Context lifecycle** (push/pop of app and request contexts) is correct, including preservation during debug/streaming scenarios.
- **Session semantics** survive redirects, transactions, and cookie policies.
- **JSON serialization** for requests and responses uses the app's configured JSON provider.
- **CLI invocations** run inside the correct application context with the proper `ScriptInfo` object.

## 2. Module Overview

```
Developer_Interface___Testing_Tooling
└── testing-support
    ├── testing-support_test-client      (EnvironBuilder, FlaskClient — implementation)
    ├── testing-support_cli-runner       (FlaskCliRunner — implementation)
    └── testing-support_test-suite       (tests/test_testing.py — THIS MODULE)
└── test-infrastructure                  (tests/conftest.py — shared fixtures)
```

The test suite is the consumer of both implementation modules and the shared test infrastructure. It acts as the acceptance layer: it does not test `src/flask/testing.py` classes in isolation, but rather the complete integration between the testing utilities, the application core ([application-core_flask-app](application-core_flask-app.md)), and the context machinery ([contexts_request_context](contexts_request_context.md) / [contexts_app_context](contexts_app_context.md)).

## 3. Architecture

The following diagram shows how the test suite relates to the components it exercises:

```mermaid
graph TB
    subgraph "Test Suite (this module)"
        TT["tests/test_testing.py<br/>16 test functions"]
    end

    subgraph "Test Infrastructure (test-infrastructure)"
        CF["tests/conftest.py<br/>fixtures: app, client,<br/>app_ctx, req_ctx, leak_detector"]
    end

    subgraph "Testing Support (implementation)"
        EB["EnvironBuilder<br/>(app-aware WSGI env builder)"]
        FC["FlaskClient<br/>(context-aware test client)"]
        FCR["FlaskCliRunner<br/>(CLI test runner)"]
    end

    subgraph "Application Core"
        APP["Flask<br/>test_client() / test_cli_runner() /<br/>test_request_context() / wsgi_app()"]
        CTX["RequestContext / AppContext<br/>(push, pop, teardown)"]
        CFG["Config<br/>SERVER_NAME, APPLICATION_ROOT,<br/>PREFERRED_URL_SCHEME"]
        JSON["JSONProvider<br/>app.json"]
        SI["ScriptInfo<br/>(flask.cli)"]
    end

    TT -->|uses fixtures| CF
    CF -->|provides Flask app| TT
    TT -->|exercises| EB
    TT -->|exercises| FC
    TT -->|exercises| FCR
    APP -->|instantiates| FC
    APP -->|instantiates| FCR
    APP -->|creates via test_request_context| EB
    FC -->|builds requests via| EB
    FC -->|pushes/pops| CTX
    FCR -->|injects obj| SI
    EB -->|reads defaults from| CFG
    EB -->|serializes with| JSON
    APP -->|dispatches| CTX
```

### 3.1 Component Relationships

| Test Suite Concern | Tested Component | Producing Module |
|---|---|---|
| Request environment defaults | `EnvironBuilder.__init__` | [testing-support_test-client](testing-support_test-client.md) |
| Context preservation (`with client:`) | `FlaskClient.open / __enter__ / __exit__` | [testing-support_test-client](testing-support_test-client.md) |
| Session mutation API | `FlaskClient.session_transaction` | [testing-support_test-client](testing-support_test-client.md) |
| CLI invocation with app binding | `FlaskCliRunner.invoke` | [testing-support_cli-runner](testing-support_cli-runner.md) |
| Fixtures & leak detection | `app`, `client`, `app_ctx`, `req_ctx`, `leak_detector` | [test-infrastructure](test-infrastructure.md) |

## 4. Test Coverage Map

The 16 test functions group into six behavioral areas:

```mermaid
mindmap
  root((test_testing.py))
    Environment Defaults
      test_environ_defaults_from_config
      test_environ_defaults
      test_environ_base_default
      test_environ_base_modified
    EnvironBuilder API
      test_client_open_environ
      test_path_is_url
      test_environbuilder_json_dumps
    Routing & Subdomains
      test_blueprint_with_subdomain
      test_subdomain
      test_nosubdomain
      test_full_url_request
    Sessions
      test_redirect_keep_session
      test_session_transactions
      test_session_transactions_no_null_sessions
      test_session_transaction_needs_cookies
      test_session_transactions_keep_context
    Context Lifecycle
      test_test_client_context_binding
      test_reuse_client
      test_client_pop_all_preserved
    JSON & CLI
      test_json_request_and_response
      test_client_json_no_app_context
      test_cli_runner_class
      test_cli_invoke
      test_cli_custom_obj
```

### 4.1 Environment Defaults

| Test | What It Verifies |
|---|---|
| `test_environ_defaults_from_config` | `EnvironBuilder` (via `test_request_context` and the client) composes base URLs from `SERVER_NAME` (`example.com:1234`) and `APPLICATION_ROOT` (`/foo`). |
| `test_environ_defaults` | Without configuration, defaults fall back to `http://localhost/`. |
| `test_environ_base_default` | `FlaskClient.environ_base` presets `REMOTE_ADDR=127.0.0.1` and a Werkzeug version `HTTP_USER_AGENT`. |
| `test_environ_base_modified` | Mutating `client.environ_base` before requests propagates into `request.remote_addr` and `request.user_agent`. |

### 4.2 EnvironBuilder API

| Test | What It Verifies |
|---|---|
| `test_client_open_environ` | `client.open()` accepts an `EnvironBuilder` instance or a raw WSGI environ dict, while still merging `client.environ_base`. |
| `test_path_is_url` | A full URL passed as `path` is parsed into `url_scheme` (`https`), `host` (`example.com`), and `path` (`/`). |
| `test_environbuilder_json_dumps` | `EnvironBuilder.json_dumps` delegates to `app.json`, honoring configuration like `app.json.ensure_ascii = False`. |

### 4.3 Routing & Subdomains

| Test | What It Verifies |
|---|---|
| `test_blueprint_with_subdomain` | Blueprints registered with `subdomain="xxx"` match requests made with `subdomain="xxx"`; `request.blueprint` reflects the blueprint name. |
| `test_subdomain` / `test_nosubdomain` | Subdomain and non-subdomain URL generation/matching with `SERVER_NAME` set. |
| `test_full_url_request` | `client.post("http://domain.com/action?vodka=42", data={...})` — full URLs, query-string args, and form data coexist. |

### 4.4 Sessions

| Test | What It Verifies |
|---|---|
| `test_redirect_keep_session` | Session data survives `redirect()` + `follow_redirects=True`. |
| `test_session_transactions` | `with client.session_transaction() as sess:` opens, mutates, and persists the session cookie without a view. |
| `test_session_transactions_no_null_sessions` | A `RuntimeError("Session backend did not open a session.")` is raised for null session backends. |
| `test_session_transaction_needs_cookies` | `TypeError("Cookies are disabled...")` when the client was created with `use_cookies=False`. |
| `test_session_transactions_keep_context` | An ambient `req_ctx` remains bound (same request object) across a session transaction. |

### 4.5 Context Lifecycle

| Test | What It Verifies |
|---|---|
| `test_test_client_context_binding` | Inside `with client:`, `flask.g` and `flask.request` stay accessible after the response; accessing `flask.g` outside the block raises `RuntimeError`. |
| `test_reuse_client` | A client can enter/exit `with` blocks repeatedly. |
| `test_client_pop_all_preserved` | The most subtle test: it stacks **three** request contexts — one from the `req_ctx` fixture, one pushed by the client (preserved via `werkzeug.debug.preserve_context`), and one from `stream_with_context` (preserved by the response). After closing the response, only the fixture's context (`req_ctx`) remains on `_cv_request`. |

### 4.6 JSON & CLI

| Test | What It Verifies |
|---|---|
| `test_json_request_and_response` | `client.post(..., json=...)` produces `request.is_json`; `jsonify` responses are symmetric (`rv.get_json()`). |
| `test_client_json_no_app_context` | JSON requests outside `with client:` still trigger exactly one `appcontext_popped` signal — the app context does not leak. |
| `test_cli_runner_class` | `app.test_cli_runner()` returns a `FlaskCliRunner`; `app.test_cli_runner_class` allows subclass substitution. |
| `test_cli_invoke` | `runner.invoke` works with both command *names* (via `app.cli`) and command *objects*. |
| `test_cli_custom_obj` | Passing a custom `obj=ScriptInfo(create_app=...)` to `invoke` overrides the default app-loading object. |

## 5. Data Flow

### 5.1 Test Request Flow

How a single `client.get("/")` call travels through the stack:

```mermaid
sequenceDiagram
    participant T as Test Function
    participant C as FlaskClient
    participant EB as EnvironBuilder
    participant A as Flask App (wsgi_app)
    participant RC as RequestContext
    participant V as View Function

    T->>C: client.get("/", subdomain="xxx")
    C->>C: _copy_environ() merges environ_base
    C->>EB: _request_from_builder_args()
    EB->>EB: base_url = scheme://[subdomain.]SERVER_NAME/APPLICATION_ROOT
    EB-->>C: WSGI environ + Request
    C->>C: close previously preserved contexts (_context_stack)
    C->>A: super().open(request)
    A->>RC: request_context(environ).push()
    RC->>RC: push AppContext (if needed), open session, match URL
    A->>V: full_dispatch_request() → dispatch_request()
    V-->>A: response value
    A->>A: finalize_request() → save_session
    A->>RC: ctx.pop() — teardown_request
    Note over A,RC: if "werkzeug.debug.preserve_context" in environ,<br/>app & request contexts are preserved instead
    A-->>C: TestResponse
    C->>C: re-push preserved contexts onto _context_stack
    C-->>T: response (contexts still accessible inside `with client:`)
```

### 5.2 Context Preservation Lifecycle

The `test_client_pop_all_preserved` test validates this stacking discipline:

```mermaid
flowchart TD
    A["req_ctx fixture pushes<br/>RequestContext #1"] --> B["with client:<br/>preserve_context = True"]
    B --> C["client.get('/')<br/>pushes RequestContext #2<br/>(preserved by client)"]
    C --> D["view returns stream_with_context('hello')<br/>pushes RequestContext #3<br/>(preserved by response)"]
    D --> E["request ends; #2 and #3<br/>are held, not popped"]
    E --> F["rv.close()<br/>releases #3 (stream finished)"]
    F --> G["client __exit__<br/>closes _context_stack, releases #2"]
    G --> H["assert _cv_request.get() is req_ctx<br/>only #1 remains"]
```

## 6. Component Interaction with Fixtures

The suite relies on the shared fixtures defined in [test-infrastructure](test-infrastructure.md) (`tests/conftest.py`):

| Fixture | Role in This Suite |
|---|---|
| `app` | `Flask("flask_test")` with `TESTING=True` and `SECRET_KEY="test key"` — the standard app under test. |
| `client` | `app.test_client()` — the standard client; tests such as `test_environ_base_modified` mutate its `environ_base` dict. |
| `app_ctx` | Pushed application context for tests that build URLs outside a request (e.g., `test_environ_defaults`). |
| `req_ctx` | Pushed request context, used both as a baseline (`test_session_transactions_keep_context`) and as the expected residual context (`test_client_pop_all_preserved`). |
| `leak_detector` | Autouse guard asserting no request context survives the test — critical for `test_client_pop_all_preserved`. |

Additionally, `test_client_json_no_app_context` uses the `appcontext_popped` signal (`flask.signals`) to count app-context teardowns, and `test_cli_custom_obj` exercises `flask.cli.ScriptInfo` (see [command-line-interface_app-discovery](command-line-interface_app-discovery.md)).

## 7. Key Testing Patterns

### 7.1 `with client:` for Post-Response Context Access

```python
with client:
    resp = client.get("/")
    assert flask.g.value == 42   # g is still bound after the response
# outside the block:
with pytest.raises(RuntimeError):
    flask.g.value
```

Entering the client as a context manager sets `preserve_context = True`, which makes `FlaskClient.open()` advertise `werkzeug.debug.preserve_context` in the environ. `Flask.wsgi_app` then hands the app and request contexts to the client instead of popping them; they are popped when the `with` block exits.

### 7.2 Session Transactions Without Views

```python
with client.session_transaction() as sess:
    sess["foo"] = [42]
```

`FlaskClient.session_transaction` spins up a throwaway request context, opens the session through the app's `session_interface`, yields it, then saves it back as `Set-Cookie` headers. Guard clauses raise `RuntimeError` (null session) or `TypeError` (cookies disabled), both of which are regression-tested here.

### 7.3 JSON Round-Trips Through the App's Provider

`test_environbuilder_json_dumps` and `test_json_request_and_response` confirm that all JSON paths (request body building, `jsonify`, `response.get_json`) funnel through the single `app.json` provider — the customization point documented in [json-serialization_provider](json-serialization_provider.md).

### 7.4 URL Composition From Config

`test_path_is_url`, `test_environ_defaults_from_config`, and the subdomain tests pin down the base-URL algorithm:

```
base_url = (path_scheme or PREFERRED_URL_SCHEME) + "://"
           + (path_netloc or (subdomain + "." if subdomain else "") + (SERVER_NAME or "localhost"))
           + "/" + APPLICATION_ROOT.lstrip("/")
```

This behavior is shared by `EnvironBuilder` and `Flask.test_request_context`, which is why the tests exercise both entry points.

## 8. Module Dependencies

```mermaid
graph LR
    subgraph "This Module"
        TS["tests/test_testing.py"]
    end

    TS --> TB["testing-support_test-client<br/>(EnvironBuilder, FlaskClient)"]
    TS --> TR["testing-support_cli-runner<br/>(FlaskCliRunner)"]
    TS --> TI["test-infrastructure<br/>(conftest fixtures)"]
    TS -.->|ScriptInfo for custom obj| CLI["command-line-interface<br/>app-discovery"]
    TS -.->|appcontext_popped signal| SIG["application-core<br/>signals"]
    TB --> AC["application-core_flask-app<br/>(Flask.test_client, wsgi_app)"]
    TB --> CTX["contexts_request_context<br/>(push/pop/preserve)"]
    TR --> CLI
    TS -.->|jsonify, app.json| JS["json-serialization_provider"]
```

### 8.1 External (Non-Flask) Dependencies

- **pytest** — test framework; `pytest.raises` for error-path assertions.
- **click** — command objects passed to `FlaskCliRunner.invoke` (`test_cli_invoke`).
- **Werkzeug** — `EnvironBuilder`/`FlaskClient`/`CliRunner` base classes; `test_environ_base_default` reads the installed Werkzeug version via `importlib.metadata` for the default user agent assertion.

## 9. Running and Extending the Suite

```bash
# run this module's tests
pytest tests/test_testing.py -v

# focus on a behavioral area
pytest tests/test_testing.py -k "session_transaction"
pytest tests/test_testing.py -k "environ"

# the leak detector (conftest) fails the run if any test
# leaves a request context pushed — do not disable it when
# adding context-manipulation tests
```

**Guidelines for new tests in this file:**

1. Prefer the `app`/`client`/`req_ctx` fixtures over constructing apps inline; only self-contained tests (e.g., `test_session_transactions_no_null_sessions`, `test_blueprint_with_subdomain`) create their own `Flask` instance — typically to exercise constructor options like `subdomain_matching=True`.
2. If a test manipulates contexts manually, ensure `leak_detector` still passes by popping in reverse order.
3. New client-level features belong in `FlaskClient` ([testing-support_test-client](testing-support_test-client.md)) first; add the acceptance test here, including at least one negative path (e.g., the `TypeError`/`RuntimeError` guards).
4. CLI behavior tests should pair with unit coverage in [command-line-interface_test-suite](command-line-interface_test-suite.md).

## 10. Related Documentation

- [testing-support_test-client](testing-support_test-client.md) — implementation of `EnvironBuilder` and `FlaskClient`.
- [testing-support_cli-runner](testing-support_cli-runner.md) — implementation of `FlaskCliRunner`.
- [test-infrastructure](test-infrastructure.md) — shared fixtures (`app`, `client`, `app_ctx`, `req_ctx`, `leak_detector`) and environment sanitation.
- [application-core_flask-app](application-core_flask-app.md) — `Flask.test_client`, `test_request_context`, `wsgi_app`, and request dispatch.
- [contexts_request_context](contexts_request_context.md) — request context push/pop semantics and `preserve_context` interaction.
- [contexts_app_context](contexts_app_context.md) — app context teardown and the `appcontext_popped` signal.
- [json-serialization_provider](json-serialization_provider.md) — the `app.json` provider backing `json_dumps` and `jsonify` assertions.
- [command-line-interface_app-discovery](command-line-interface_app-discovery.md) — `ScriptInfo` used by `test_cli_custom_obj`.
- [command-line-interface_test-suite](command-line-interface_test-suite.md) — CLI framework's own test suite (`tests/test_cli.py`).
