# Configuration Module (`flask.config`)

## 1. Introduction & Purpose

The **configuration** module (source: `src/flask/config.py`, tests: `tests/test_config.py`) provides Flask's central, application-wide configuration mechanism. It consists of exactly two cooperating components:

| Component | Kind | Responsibility |
|---|---|---|
| [`Config`](#31-config--the-configuration-dictionary) | `dict` subclass | Stores all key/value settings and knows **how to populate itself** from Python objects, Python files, JSON/TOML files, plain mappings, and environment variables. |
| [`ConfigAttribute[T]`](#32-configattributet--the-property-descriptor) | generic descriptor | Forwards **attribute access on the app object** to a named key inside `app.config`, optionally converting the value on read. |

Every Flask application owns exactly one `Config` instance (`app.config`). All built-in Flask behavior — debug mode, secret keys, session cookies, request size limits, routing, template reloading — reads its settings from this dictionary, so this module is the single source of truth for runtime behavior tuning. It sits inside the *Runtime Configuration & Diagnostics* domain together with the sibling [logging.md](logging.md) module (the two are peers: config controls *what* the app does, logging controls *what it reports*).

**Design principles**

1. **A dict first** — `Config` behaves exactly like a plain `dict`, so ordinary operations (`app.config["DEBUG"] = True`, `in`, `.get()`, iteration) work with no surprises.
2. **Convention: only UPPERCASE keys** — every loader imports only keys whose names are entirely uppercase. This lets a config file (or a module) keep private, lowercase helpers without polluting the configuration.
3. **Layered loading** — defaults are installed at app construction; more specific sources (objects → files → environment) are layered on top by the application developer. Later loads override earlier values.
4. **Predictable failure** — loaders raise descriptive errors for missing files/variables, and every file loader accepts `silent=True` to degrade gracefully.

---

## 2. Architecture Overview

```mermaid
flowchart TD
    subgraph APP["flask.Flask (see application-core.md)"]
        INIT["App.__init__"]
        MKC["make_config()"]
        DEFC["default_config (ImmutableDict of ~30 built-in keys)"]
        INIT --> MKC
        MKC -->|"seeds defaults"| DEFC
        MKC -->|"config_class(root_path, defaults)"| CFG
    end

    CFG["Config<br/>(dict subclass)"]
    CA["ConfigAttribute~T~<br/>(descriptor)"]

    subgraph ATTRS["App class attributes (sansio/app.py)"]
        A1["testing → TESTING"]
        A2["secret_key → SECRET_KEY"]
        A3["permanent_session_lifetime → PERMANENT_SESSION_LIFETIME"]
    end

    A1 --> CA
    A2 --> CA
    A3 --> CA
    CA -->|"obj.config[key]"| CFG

    subgraph LOAD["Loading strategies (Config methods)"]
        L1["from_object()"]
        L2["from_pyfile()"]
        L3["from_file()"]
        L4["from_mapping()"]
        L5["from_envvar()"]
        L6["from_prefixed_env()"]
    end

    L1 --> CFG
    L2 --> CFG
    L3 --> CFG
    L4 --> CFG
    L5 --> CFG
    L6 --> CFG

    subgraph CONS["Consumers of app.config"]
        C1["Routing / URL building"]
        C2["Sessions"]
        C3["Templating / Jinja"]
        C4["Error handling"]
        C5["Request & cookie limits"]
    end

    CFG --> C1
    CFG --> C2
    CFG --> C3
    CFG --> C4
    CFG --> C5
```

### 2.1 Birth of a `Config` instance

During `Flask.__init__`, `App.make_config()` instantiates the configuration:

1. Chooses the **`root_path`** the loaders resolve relative paths against:
   - `instance_relative_config=False` (default) → the app's package/module `root_path`,
   - `instance_relative_config=True` → the instance folder (`instance_path`), the recommended place for deployment-specific files that must not live inside installed code.
2. Copies `default_config` (an `ImmutableDict` of ~30 built-in keys, see §5.2) and sets `DEBUG` from the `FLASK_DEBUG` environment variable (`get_debug_flag()`).
3. Builds `self.config_class(root_path, defaults)` — the class is an overridable hook, so `Config` itself can be replaced (see `test_custom_config_class`).

### 2.2 Startup → runtime sequence

```mermaid
sequenceDiagram
    participant U as User code
    participant A as Flask app
    participant C as Config
    participant E as Environment

    U->>A: Flask(__name__, instance_relative_config=True)
    A->>A: auto_find_instance_path()
    A->>A: make_config(instance_relative_config)
    A->>C: config_class(root_path, defaults)
    Note over C: defaults = default_config + DEBUG (from FLASK_DEBUG)

    U->>C: from_object("yourapp.default_config")
    U->>C: from_envvar("YOURAPPLICATION_SETTINGS")
    C->>E: os.environ["YOURAPPLICATION_SETTINGS"]
    E-->>C: "/etc/yourapp/production.cfg"
    C->>C: from_pyfile(path) → from_object(module)

    U->>A: app.secret_key
    Note over A: ConfigAttribute descriptor intercepts
    A->>C: config["SECRET_KEY"]
    C-->>A: value (optionally via get_converter)
```

---

## 3. Core Components

### 3.1 `Config` — the configuration dictionary

```python
class Config(dict):
    def __init__(self, root_path, defaults=None)
```

A `dict` that additionally remembers the `root_path` it was created with (normally the app's `root_path` or `instance_path`), which all file-based loaders use to resolve **relative** file names. Everything else in the class is about *populating* the dict and *querying* it conveniently.

#### 3.1.1 Loading strategies

All "update" methods share the same conventions:

- **Uppercase filter** — `from_object`, `from_pyfile` (via `from_object`), and `from_mapping` copy only all-uppercase keys.
- **`silent` flag** — file-based loaders (`from_envvar`, `from_pyfile`, `from_file`) return `False` instead of raising when the file/variable is missing *and* `silent=True`.
- **Enhanced error messages** — `OSError`s are re-raised with `Unable to load configuration file (...)` prefixed to `strerror` (asserted by `test_config_missing`, `test_config_missing_file`, `test_config_from_envvar_missing`).

| Method | Source | Details |
|---|---|---|
| `from_object(obj)` | Python object or import string | Accepts a module, class, or `'pkg.module.Class'` string (imported via Werkzeug's `import_string`). Copies **all uppercase attributes** via `dir(obj)`. Classes with `@property` must be instantiated first. Intended for *defaults* (`from_object(__name__)` or dev/prod config classes), not for secrets. |
| `from_pyfile(filename, silent=False)` | Python source file | Reads the file relative to `root_path`, compiles and `exec`s it into a fresh pseudo-module (`types.ModuleType("config")` with `__file__` set), then delegates to `from_object`. Honors PEP 263 `# -*- coding: ... -*-` headers (`test_from_pyfile_weird_encoding`). `silent` tolerates `ENOENT`, `EISDIR`, `ENOTDIR`. |
| `from_envvar(variable_name, silent=False)` | env var → file path | Shortcut for `from_pyfile(os.environ[variable_name])`. Raises `RuntimeError("The environment variable 'X' is not set ...")` when the variable is unset and not silent (`test_config_from_envvar`). |
| `from_prefixed_env(prefix="FLASK", *, loads=json.loads)` | `FLASK_*` environment variables | Loads every env var starting with `FLASK_` in **sorted order**, strips the prefix, and parses each value with `loads` (default `json.loads` — so `"true"` → `True`, `"[1, 2]"` → list, `'{"k": "v"}'` → dict; parse failures silently keep the raw string). Double underscores (`__`) address **nested dicts**, creating missing intermediate dicts on the fly (`test_from_prefixed_env`, `test_from_prefixed_env_nested`). Returns `True` unconditionally. *Added in 2.1.* |
| `from_file(filename, load, silent=False, text=True)` | structured data file | Opens the file relative to `root_path` (text mode unless `text=False`, required for `tomllib.load`), hands the handle to the caller-supplied `load` callable, and feeds the resulting mapping into `from_mapping`. Example: `app.config.from_file("config.json", json.load)` or `app.config.from_file("config.toml", tomllib.load, text=False)` (`test_config_from_file_json`, `test_config_from_file_toml`). |
| `from_mapping(mapping=None, **kwargs)` | mapping / keyword args | Update-like merge that keeps only uppercase keys; accepts dicts, lists of pairs, and kwargs. Always returns `True`. Raises `TypeError` if given more than one positional mapping. |

```mermaid
flowchart TD
    START(["Wanted config source"]) --> Q{"Which source?"}
    Q -->|"Python object / 'module.Attr' string"| FO["from_object(obj)<br/>copies UPPERCASE attributes"]
    Q -->|"Python file"| FP["from_pyfile(filename)"]
    FP -->|"exec into pseudo-module"| FO
    Q -->|"env var naming a file"| FE["from_envvar(name)<br/>RuntimeError if unset"]
    FE --> FP
    Q -->|"JSON / TOML / ... file"| FF["from_file(filename, load, text)"]
    FF --> FM["from_mapping()"]
    Q -->|"dict / pairs / kwargs"| FM
    Q -->|"FLASK_* env vars"| FPE["from_prefixed_env()<br/>json values, __ nesting"]
    FO --> MERGE["app.config dict<br/>(later loads override earlier)"]
    FM --> MERGE
    FPE --> MERGE
    MERGE --> DONE(["ready for the running app"])
```

#### 3.1.2 Query helpers

- **`get_namespace(namespace, lowercase=True, trim_namespace=True)`** — extracts a *group* of related options sharing a prefix into a plain dict, e.g. `IMAGE_STORE_TYPE/PATH/BASE_URL` → `{"type": ..., "path": ..., "base_url": ...}` (`test_get_namespace`). Useful to splat a group of settings into a constructor via `**kwargs`.
- **`__repr__`** — `<Config {...}>` for readable debug output.

### 3.2 `ConfigAttribute[T]` — the property descriptor

```python
class ConfigAttribute(t.Generic[T]):
    def __init__(self, name, get_converter=None)
    def __get__(self, obj, owner=None) -> T | te.Self
    def __set__(self, obj, value) -> None
```

A small, generic **descriptor** that turns ordinary class attributes into live views of `app.config`:

- `__get__` returns `obj.config[self.__name__]`, applying the optional `get_converter` callable to the stored value; accessing it on the *class* (not an instance) returns the descriptor itself (typed via `t.overload` / `typing_extensions.Self`).
- `__set__` writes straight into `obj.config[self.__name__]`, so `app.testing = True` and `app.config["TESTING"] = True` are exactly equivalent.

Used on `App` (`src/flask/sansio/app.py`) for:

| App attribute | Config key | Converter |
|---|---|---|
| `testing: bool` | `TESTING` | — |
| `secret_key` | `SECRET_KEY` | — |
| `permanent_session_lifetime: timedelta` | `PERMANENT_SESSION_LIFETIME` | `_make_timedelta` — accepts an `int` (seconds) or `timedelta`, so `app.config["PERMANENT_SESSION_LIFETIME"] = 42` yields `timedelta(seconds=42)` (`test_session_lifetime`) |

The `debug` property on `App` is a hand-written equivalent (getter/setter on `config["DEBUG"]`) that additionally synchronizes `jinja_env.auto_reload` when `TEMPLATES_AUTO_RELOAD` is unset.

#### Class diagram

```mermaid
classDiagram
    class Config {
        +str root_path
        +from_object(obj)
        +from_pyfile(filename, silent) bool
        +from_envvar(name, silent) bool
        +from_prefixed_env(prefix, loads) bool
        +from_file(filename, load, silent, text) bool
        +from_mapping(mapping, **kwargs) bool
        +get_namespace(namespace, lowercase, trim_namespace) dict
    }
    class ConfigAttribute~T~ {
        +str __name__
        +Callable get_converter
        +__get__(obj, owner) T
        +__set__(obj, value)
    }
    class App {
        <<flask.sansio.app.App>>
        +config_class
        +Config config
        +testing bool
        +secret_key
        +permanent_session_lifetime timedelta
    }
    Config --|> dict
    App *-- Config : "self.config = make_config()"
    App ..> ConfigAttribute : "declares testing / secret_key / permanent_session_lifetime"
    ConfigAttribute ..> Config : "reads & writes obj.config[key]"
```

---

## 4. Built-in Configuration Keys

`Flask.default_config` (in `src/flask/app.py`) seeds every app with these defaults; the configuration module stores and loads them, while other modules *consume* them:

| Category | Keys (default) | Consumed by |
|---|---|---|
| Runtime mode | `DEBUG` (`None` → env), `TESTING` (`False`), `PROPAGATE_EXCEPTIONS` (`None` → falls back to `testing or debug`) | Error handling / debugger ([application-core.md](application-core.md)) |
| Security | `SECRET_KEY` (`None`), `SECRET_KEY_FALLBACKS` (`None`), `MAX_COOKIE_SIZE` (`4093`) | Sessions, cookie handling ([sessions.md](sessions.md)) |
| Sessions | `PERMANENT_SESSION_LIFETIME` (`31 days`), `SESSION_COOKIE_NAME/DOMAIN/PATH/HTTPONLY/SECURE/PARTITIONED/SAMESITE`, `SESSION_REFRESH_EACH_REQUEST` | `flask.sessions` ([sessions.md](sessions.md)) |
| Routing / URLs | `SERVER_NAME` (`None`), `APPLICATION_ROOT` (`"/"`), `PREFERRED_URL_SCHEME` (`"http"`), `TRUSTED_HOSTS` (`None`), `PROVIDE_AUTOMATIC_OPTIONS` (`True`) | `create_url_adapter`, `add_url_rule` ([application-core.md](application-core.md)) |
| Templates | `TEMPLATES_AUTO_RELOAD` (`None` → follows `DEBUG`), `EXPLAIN_TEMPLATE_LOADING` (`False`) | Jinja environment ([templating.md](templating.md)); `config` itself is also exposed as a Jinja global |
| Request limits | `MAX_CONTENT_LENGTH` (`None`), `MAX_FORM_MEMORY_SIZE` (`500_000`), `MAX_FORM_PARTS` (`1_000`) | Request parsing ([application-core.md](application-core.md)) |
| Static files | `USE_X_SENDFILE` (`False`), `SEND_FILE_MAX_AGE_DEFAULT` (`None`) | `send_file` / `get_send_file_max_age` ([helpers.md](helpers.md)) |
| Debugging aids | `TRAP_HTTP_EXCEPTIONS` (`False`), `TRAP_BAD_REQUEST_ERRORS` (`None` → traps `BadRequestKeyError` in debug mode) | `trap_http_exception`, `handle_user_exception` |

Because the values are read **live** from the dict on each use, changing a key at runtime takes effect on the next access (caveat: settings such as `DEBUG` and Jinja options should be set before the first request — see `test_no_setup_after_first_request`).

---

## 5. Integration with the Rest of the System

```mermaid
flowchart LR
    subgraph SOURCES["External sources"]
        ENVV["Environment variables<br/>FLASK_DEBUG, FLASK_*"]
        FILES["Config files<br/>*.py / *.json / *.toml"]
    end
    subgraph CFGM["configuration module"]
        CFG["Config"]
        CA["ConfigAttribute"]
    end
    subgraph OTHER["Other modules"]
        CORE["application-core<br/>(Flask, routing, errors)"]
        CLI["command-line-interface<br/>(flask run --debug, dotenv)"]
        SESS["sessions"]
        TPL["templating"]
    end
    ENVV -->|"from_prefixed_env / get_debug_flag"| CFG
    FILES -->|"from_pyfile / from_file / from_envvar"| CFG
    CFG --- CORE
    CFG --- SESS
    CFG --- TPL
    CA --- CORE
    CLI -->|"FLASK_DEBUG, .env/.flaskenv"| ENVV
```

- **[application-core.md](application-core.md)** — creates the `Config` via `make_config()`; reads `DEBUG`, `PROPAGATE_EXCEPTIONS`, `TRAP_*`, `SERVER_NAME`, `TRUSTED_HOSTS`, `PROVIDE_AUTOMATIC_OPTIONS`, etc.; declares the `ConfigAttribute`-backed properties.
- **[logging.md](logging.md)** — peer diagnostics module; logger setup is influenced by the app (debug mode), while this module stays logging-free by design.
- **[command-line-interface.md](command-line-interface.md)** — `flask run` seeds `FLASK_DEBUG` and loads `.env`/`.flaskenv` files, which feed `from_prefixed_env` and the `DEBUG` default; `test_run_from_config`/`test_run_from_*` exercise the interplay.
- **[sessions.md](sessions.md)** / **[templating.md](templating.md)** — heavy consumers of session and template keys listed in §4.

**Extension points**

1. **Custom `Config` class** — set `config_class` on a `Flask` subclass (verified by `test_custom_config_class`); typical uses are attribute-style access or per-key defaults.
2. **Custom parsers** — pass any `load(file) -> mapping` callable to `from_file` (JSON, TOML, YAML), or any `loads(str) -> Any` to `from_prefixed_env`.
3. **`get_namespace`** — bundle prefixed keys into objects/config structs for extensions.

---

## 6. Recommended Usage Patterns

The canonical dev/prod layout that the module is designed around:

```python
app = Flask(__name__, instance_relative_config=True)
app.config.from_object("yourapplication.default_config")   # sane defaults in code
app.config.from_pyfile("application.cfg", silent=True)      # optional instance overrides
app.config.from_prefixed_env()                              # 12-factor style: FLASK_SECRET_KEY=...
```

Or the environment-variable pattern for deployments:

```bash
export YOURAPPLICATION_SETTINGS=/etc/yourapp/production.cfg
```

```python
app.config.from_envvar("YOURAPPLICATION_SETTINGS")  # raises a helpful RuntimeError if unset
```

Guidelines enforced by the loaders' behavior:

- Keep **defaults** in code (`from_object`) and **secrets/environment-specifics** in files outside the package (`from_pyfile` on the instance path) — mirroring `instance_relative_config=True`.
- Remember the **uppercase-only** convention; lowercase entries in config files/modules are ignored.
- Use `silent=True` only where a missing file is *expected* (e.g., optional instance config).

---

## 7. Test Suite (`tests/test_config.py`)

The test suite maps 1:1 onto the component's contract:

| Area | Tests | What they pin down |
|---|---|---|
| Loaders | `test_config_from_pyfile`, `test_config_from_object`, `test_config_from_class`, `test_config_from_mapping`, `test_config_from_file_json`, `test_config_from_file_toml` | Uppercase filtering, inheritance-aware `dir()` scanning (base + subclass attributes), dict/list-of-pairs/kwargs inputs, `TypeError` on two positional mappings, `text=False` for TOML. |
| Environment | `test_from_prefixed_env`, `test_from_prefixed_env_custom_prefix`, `test_from_prefixed_env_nested`, `test_config_from_envvar`, `test_config_from_envvar_missing` | JSON value parsing (bool/int/float/list/dict), custom prefixes, `__` nesting incl. Windows case behavior, `RuntimeError` vs. silent return, enhanced `IOError` message. |
| Error handling | `test_config_missing`, `test_config_missing_file`, `test_config_from_pyfile_weird_encoding` | `silent=True`/`False` semantics, `"[Errno 2] Unable to load configuration file (...)"` message shape, PEP 263 encoding declarations. |
| Integration | `test_custom_config_class`, `test_session_lifetime` | `config_class` hook on `Flask` subclasses; `_make_timedelta` converter (`42` → `timedelta(seconds=42)`). |
| Querying | `test_get_namespace` | `lowercase` / `trim_namespace` flag combinations. |

Run them with `pytest tests/test_config.py`.

---

## 8. Summary

- **`Config`** is a dict plus six layered loaders (object, pyfile, envvar, prefixed-env, generic file, mapping) and one query helper (`get_namespace`); it is the single store for all app settings.
- **`ConfigAttribute[T]`** exposes individual config keys as typed app attributes (`testing`, `secret_key`, `permanent_session_lifetime`) with optional value conversion.
- The module is intentionally tiny and dependency-light (only `werkzeug.utils.import_string` and the standard library), making it easy to subclass, test in isolation, and reuse — while the rest of Flask treats `app.config` as the authoritative runtime control panel.
