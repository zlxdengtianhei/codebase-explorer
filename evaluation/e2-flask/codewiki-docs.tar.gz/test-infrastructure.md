# Test Infrastructure

## 1. Overview

The **test-infrastructure** module is defined by a single file, `tests/conftest.py`, which acts as the shared *pytest plugin* for the entire Flask test suite. Every test module in `tests/` (and the `tests/type_check/` typing tests) implicitly depends on it. The module provides five orthogonal capabilities:

| Capability | Fixtures / Helpers | Purpose |
|---|---|---|
| **Environment determinism** | `_standard_os_environ`, `_reset_os_environ` | Guarantees `os.environ` contains known Flask/Werkzeug variables at session start and is restored after every test |
| **Application scaffolding** | `app`, `app_ctx`, `req_ctx`, `client` | Ready-to-use `Flask` app, active app/request contexts, and a `FlaskClient` test client |
| **Context hygiene** | `leak_detector` | Fails the suite if any request context survives past a test (guards Flask's internal `contextvars` protocol) |
| **Import isolation** | `test_apps`, `purge_module` | Safely imports the sample apps in `tests/test_apps/` and purges cached modules afterwards |
| **Filesystem / interpreter isolation** | `modules_tmp_path`, `modules_tmp_path_prefix`, `site_packages` | Fabricates temporary `sys.path` entries, a fake `sys.prefix`, and a fake `site-packages` layout |

Because these fixtures are the substrate on which all other test modules run, this module is consumed — directly or transitively — by every subsystem test: [application-core](application-core.md), [contexts](contexts.md), [blueprints](blueprints.md), [testing-support](testing-support.md), and [command-line-interface](command-line-interface.md).

> **Source of truth:** `tests/conftest.py` (≈130 lines, no production code — only pytest fixtures).

---

## 2. Position in the System

The test infrastructure sits *between* pytest and the Flask library itself. It never implements product behavior; instead it wires Flask's public APIs (`Flask`, `app_context()`, `test_request_context()`, `test_client()`) into pytest's fixture lifecycle.

```mermaid
flowchart TB
    subgraph PY["pytest runtime"]
        PCFG["pytest config and plugins"]
    end

    subgraph CONF["tests/conftest.py (this module)"]
        ENV["Environment isolation<br/>_standard_os_environ<br/>_reset_os_environ"]
        SCAF["Application scaffolding<br/>app · app_ctx · req_ctx · client"]
        LEAK["leak_detector"]
        IMP["Import isolation<br/>test_apps · purge_module"]
        FS["Filesystem isolation<br/>modules_tmp_path<br/>modules_tmp_path_prefix · site_packages"]
    end

    subgraph FLASK["flask package (production code)"]
        FAPP["Flask<br/>app_context()<br/>test_request_context()<br/>test_client()"]
        FCTX["AppContext · RequestContext<br/>(see contexts)"]
        FGLOB["flask.globals.request_ctx"]
        FTEST["FlaskClient<br/>(see testing-support)"]
    end

    subgraph TESTS["Test modules"]
        TB["test_basic / test_appctx /<br/>test_reqctx / test_testing ..."]
        TCLI["test_cli · test_instance_config<br/>test_blueprints"]
    end

    subgraph OS["Interpreter / OS state"]
        ENVV["os.environ"]
        SYSP["sys.path"]
        SYSM["sys.modules"]
        SYSX["sys.prefix"]
    end

    PCFG --> CONF
    TB --> SCAF
    TCLI --> IMP
    TCLI --> FS
    SCAF --> FAPP
    FAPP --> FCTX
    LEAK --> FGLOB
    SCAF --> FTEST
    ENV --> ENVV
    IMP --> SYSP
    IMP --> SYSM
    FS --> SYSP
    FS --> SYSX
    FCTX --> FGLOB
```

---

## 3. Architecture

### 3.1 Fixture taxonomy

The fixtures fall along two pytest axes — **scope** (`session` vs `function`) and **activation** (`autouse` vs opt-in):

| Fixture | Scope | Autouse | Dependency chain | Layer |
|---|---|---|---|---|
| `_standard_os_environ` | `session` | ✅ | — | Environment |
| `_reset_os_environ` | `function` | ✅ | `monkeypatch`, `_standard_os_environ` | Environment |
| `leak_detector` | `function` | ✅ | `flask.globals.request_ctx` | Context hygiene |
| `app` | `function` | ❌ | `Flask(...)` | Scaffolding |
| `app_ctx` | `function` | ❌ | `app` | Scaffolding |
| `req_ctx` | `function` | ❌ | `app` | Scaffolding |
| `client` | `function` | ❌ | `app` | Scaffolding |
| `test_apps` | `function` | ❌ | `monkeypatch` | Import isolation |
| `modules_tmp_path` | `function` | ❌ | `tmp_path`, `monkeypatch` | Filesystem |
| `modules_tmp_path_prefix` | `function` | ❌ | `modules_tmp_path`, `monkeypatch` | Filesystem |
| `site_packages` | `function` | ❌ | `modules_tmp_path`, `monkeypatch` | Filesystem |
| `purge_module` | `function` | ❌ | `request` (pytest) | Import isolation |

### 3.2 Fixture dependency graph

```mermaid
flowchart TD
    subgraph AUTOUSE["autouse (run for every test)"]
        MSE["_standard_os_environ<br/><i>session scope</i>"]
        ROE["_reset_os_environ"]
        LD["leak_detector"]
    end

    subgraph OPTIN["opt-in (requested by tests)"]
        APP["app"]
        APPCTX["app_ctx"]
        REQCTX["req_ctx"]
        CLI["client"]
        TAPPS["test_apps"]
        MTP["modules_tmp_path"]
        MTPP["modules_tmp_path_prefix"]
        SP["site_packages"]
        PM["purge_module"]
    end

    MSE -- "operation list" --> ROE
    APP -- "app.app_context()" --> APPCTX
    APP -- "app.test_request_context()" --> REQCTX
    APP -- "app.test_client()" --> CLI
    MTP -- "sys.prefix patch" --> MTPP
    MTP -- "mkdir lib/pythonX.Y/site-packages" --> SP

    MP["pytest monkeypatch"] -.-> ROE
    MP2["pytest monkeypatch"] -.-> TAPPS
    MP3["pytest monkeypatch"] -.-> MTP
    TMP["pytest tmp_path"] -.-> MTP
```

Key structural points:

- **Three fixtures run for every single test** (`autouse=True`), so the entire suite inherits environment determinism and leak checking without any per-test opt-in.
- **`app` is the root of the scaffolding tree.** All context/client fixtures compose it, meaning a test requesting both `req_ctx` and `client` shares *one* `Flask` instance per test function.
- **`modules_tmp_path` is a hub** for the interpreter-layout fixtures: both `modules_tmp_path_prefix` and `site_packages` derive from it, and both patch `sys` state via `monkeypatch` (auto-undone at teardown).

---

## 4. Component Reference

### 4.1 Environment isolation — `_standard_os_environ` / `_reset_os_environ`

Flask's CLI, config loading, and dev-server behavior consult environment variables (`FLASK_APP`, `FLASK_DEBUG`, `FLASK_RUN_FROM_CLI`, `FLASK_ENV_FILE`, `WERKZEUG_RUN_MAIN`). A developer's shell can silently change test outcomes, so the module normalizes them in two phases:

**Phase 1 — session start (`_standard_os_environ`, `session` + `autouse`)**

Creates a private `monkeypatch.MonkeyPatch()` and **deletes** the five Flask/Werkzeug variables if present, recording the operations in an `out` tuple. The tuple is `yield`ed and finally `mp.undo()` restores the developer's real environment when the session ends. The yielded value is not a fixture result for tests — it is the *handoff payload* to phase 2.

**Phase 2 — after every test (`_reset_os_environ`, `function` + `autouse`)**

```python
monkeypatch._setitem.extend(_standard_os_environ)
```

This is the clever core of the design: pytest's `monkeypatch` fixture maintains an internal undo log (`_setitem`). By *appending* the session's operations to the per-test monkeypatch's log, teardown will replay "delete `FLASK_APP`, `FLASK_DEBUG`, …" after each test — undoing any pollution a test caused without cleaning up. The net effect:

```mermaid
flowchart LR
    A["Developer shell<br/>may export FLASK_APP etc."] --> B["Session start:<br/>_standard_os_environ deletes vars"]
    B --> C["Test N runs<br/>(may set env vars)"]
    C --> D["Test N teardown:<br/>_reset_os_environ re-deletes vars"]
    D --> E["Test N+1 sees<br/>clean environment"]
    E --> C
    B -. "session end" .-> F["mp.undo() restores<br/>developer's environ"]
```

**Invariant:** no test can observe or permanently leak the variables `FLASK_ENV_FILE`, `FLASK_APP`, `FLASK_DEBUG`, `FLASK_RUN_FROM_CLI`, `WERKZEUG_RUN_MAIN`.

### 4.2 Application scaffolding — `app`, `app_ctx`, `req_ctx`, `client`

#### `app`

```python
app = Flask("flask_test", root_path=os.path.dirname(__file__))
app.config.update(TESTING=True, SECRET_KEY="test key")
```

- Named `"flask_test"` with `root_path` pinned to `tests/`, so resource lookups (`static/`, `templates/`, `open_resource()`) resolve against the test directory regardless of where pytest was launched. This is what allows `test_static_files` and the template tests in [application-core](application-core.md) and [templating](templating.md) to work.
- `TESTING=True` makes unhandled exceptions **propagate** to the caller instead of converting to 500 responses (see `Flask.handle_exception` in [application-core](application-core.md)) — essential for assertion-based testing.
- `SECRET_KEY="test key"` enables `SecureCookieSessionInterface` so session tests in [sessions](sessions.md) / `test_basic.py` exercise the real signing path.

#### `app_ctx` and `req_ctx`

Context-manager fixtures that `yield` the *live context object* (`ctx`), pairing with the `__enter__`/`__exit__` protocol of `AppContext` / `RequestContext` (documented in [contexts](contexts.md)):

- `app_ctx` → `app.app_context()` → makes `current_app`, `g`, and URL building available; on exit runs `do_teardown_appcontext`.
- `req_ctx` → `app.test_request_context()` → builds a WSGI environ via `EnvironBuilder`, pushes a `RequestContext` (which implicitly pushes an app context, opens the session, and matches the URL); on exit runs `do_teardown_request` and pops the app context.

#### `client`

```python
return app.test_client()
```

Returns a `FlaskClient` (Werkzeug `Client` subclass, see [testing-support](testing-support.md)) bound to this app, with the default `environ_base` (`REMOTE_ADDR`, `HTTP_USER_AGENT`) and cookie-jar support. Unlike `app_ctx`/`req_ctx`, no context is pushed at fixture time — contexts are created per-request and only persist if the test uses the client as a context manager.

### 4.3 Context hygiene — `leak_detector`

```python
@pytest.fixture(autouse=True)
def leak_detector():
    yield
    leaks = []
    while request_ctx:
        leaks.append(request_ctx._get_current_object())
        request_ctx.pop()
    assert leaks == []
```

Runs after **every** test. It drains any surviving `RequestContext` proxies from `flask.globals` and asserts none were found. This is the enforcement mechanism for Flask's context-managed internals:

```mermaid
flowchart TD
    S["Test finished"] --> C{"request_ctx active?"}
    C -- "yes" --> P["Record context object<br/>and pop it"]
    P --> C
    C -- "no" --> A{"leaks empty?"}
    A -- "yes" --> PASS["Test passes"]
    A -- "no" --> FAIL["AssertionError:<br/>test leaked a request context"]
```

It exists because several Flask tests run the app *internally in debug mode*, where the Werkzeug debugger sets `werkzeug.debug.preserve_context` and `FlaskClient` can re-push contexts (`preserve_context` / `with client:` blocks — see [testing-support](testing-support.md)). A test that forgets to exit such a block would otherwise poison `contextvars` state for every subsequent test in the same worker. Note the teardown ordering consequence: `leak_detector` pops leaked contexts *before* pytest's `monkeypatch` undo runs, so even leaked contexts are cleaned safely.

### 4.4 Import isolation — `test_apps` / `purge_module`

`tests/test_apps/` contains deliberately broken-up sample applications used by [command-line-interface](command-line-interface.md) (`cliapp/`, `helloworld/`) and [blueprints](blueprints.md) (`blueprintapp/`):

```
tests/test_apps/
├── blueprintapp/          # app with admin/ &amp; frontend blueprints
│   └── apps/{admin,frontend}/__init__.py
├── cliapp/                # factory pattern: create_app2, app.py, multiapp.py,
│   │                      # importerrorapp.py (error paths), inner1/
│   └── factory.py
├── helloworld/hello.py    # minimal app for CLI discovery
└── subdomaintestmodule/   # static-file app for subdomain tests
```

`test_apps` performs a **prepare-and-purge** cycle:

1. **Prepare:** `monkeypatch.syspath_prepend(.../test_apps)` makes `import blueprintapp` (etc.) resolvable; `monkeypatch` guarantees the path entry is removed at teardown.
2. **Snapshot:** records `set(sys.modules.keys())` *before* the test.
3. **Purge (teardown):** pops every module added to `sys.modules` during the test.

Step 3 is what makes the fixture safe: `import app` succeeds while the path is active, and without the purge the cached module would keep resolving in unrelated later tests. This is indispensable for CLI app-discovery tests, which intentionally import the same module names under different `sys.path` layouts.

`purge_module` is the fine-grained sibling: a factory returning an `inner(name)` that registers a finalizer to `sys.modules.pop(name)` — used when a test imports a *single* known module (e.g., `helloworld.hello`) rather than a whole path region.

### 4.5 Filesystem / interpreter isolation — `modules_tmp_path`, `modules_tmp_path_prefix`, `site_packages`

These fixtures fabricate an installed-looking interpreter layout inside pytest's `tmp_path`, used chiefly by `test_instance_config.py` and CLI tests that need to "install" packages:

| Fixture | Creates / patches | Typical consumer |
|---|---|---|
| `modules_tmp_path` | `tmp_path/modules_tmp/` + prepends to `sys.path` | Any test needing an importable temp dir |
| `modules_tmp_path_prefix` | `sys.prefix` → the temp dir | Tests emulating "Flask installed in a venv" |
| `site_packages` | `modules_tmp_path/lib/python{X.Y}/site-packages/` + prepends to `sys.path` | Tests emulating installed packages (e.g. namespace-package discovery in `test_instance_config.py`) |

All three derive their effects from `monkeypatch`, so interpreter state (`sys.path`, `sys.prefix`) is restored automatically. `site_packages` builds the *real* CPython layout (`lib/python3.N/site-packages`) so that code inspecting `sys.prefix`-relative paths sees a plausible installation.

---

## 5. Test Lifecycle (Component Interaction)

The sequence below shows a representative test requesting `client` and `req_ctx`, illustrating how session setup, per-test scaffolding, and the three autouse teardowns interleave:

```mermaid
sequenceDiagram
    participant P as pytest
    participant ENV as _standard_os_environ
    participant MP as monkeypatch
    participant F as Flask app
    participant RC as RequestContext
    participant LD as leak_detector

    Note over P,ENV: once per session
    P->>ENV: session starts (autouse)
    ENV->>MP: delete FLASK_APP/FLASK_DEBUG/...<br/>record ops -> out
    ENV-->>P: yield out

    Note over P,LD: per test
    P->>P: _reset_os_environ extends<br/>per-test monkeypatch undo log with out
    P->>F: resolve `app` fixture
    F-->>P: Flask("flask_test") TESTING+SECRET_KEY
    P->>F: resolve `client` -> test_client()
    P->>F: resolve `req_ctx` -> test_request_context()
    F->>RC: push (implicit AppContext push,<br/>open session, URL match)
    RC-->>P: yield ctx

    Note over P,LD: test body runs (client.get(...) etc.)

    P->>RC: exit context -> do_teardown_request,<br/>pop app context
    LD->>LD: drain request_ctx, assert no leaks
    MP->>MP: undo (sys.path/env/sys.prefix<br/>restored incl. standard environ)
```

**Failure semantics:** if the test body raises, pytest still unwinds fixtures in reverse order, so context exits, leak detection, and monkeypatch undo all execute — the suite cannot drift into a polluted state because one test failed.

---

## 6. Data Flow Summary

```mermaid
flowchart LR
    subgraph INPUTS["Managed state at session start"]
        E1["os.environ<br/>(5 Flask/Werkzeug vars removed)"]
        SP0["sys.path<br/>(developer value)"]
        PR0["sys.prefix"]
        SM0["sys.modules"]
    end

    subgraph DURING["During a test (monkeypatched)"]
        E2["environ: standard baseline"]
        SP2["sys.path += test_apps,<br/>modules_tmp, site-packages"]
        PR2["sys.prefix = modules_tmp"]
        SM2["sys.modules grew by test imports"]
        CX["contextvars: AppContext/RequestContext<br/>pushed via fixtures"]
    end

    subgraph TEARDOWN["Automatic teardown"]
        E3["environ reset to baseline"]
        SP3["sys.path restored"]
        PR3["sys.prefix restored"]
        SM3["new modules popped"]
        CX3["contexts popped &amp; leak-asserted"]
    end

    E1 --> E2 --> E3
    SP0 --> SP2 --> SP3
    PR0 --> PR2 --> PR3
    SM0 --> SM2 --> SM3
    CX --> CX3
```

---

## 7. Usage Patterns

### 7.1 Plain app + client test (most common)

```python
def test_hello(client):
    rv = client.get("/")
    assert rv.status_code == 200
```

### 7.2 Customizing the shared app before contexts are pushed

Because every scaffolding fixture depends on `app`, a test can re-request `app` first, mutate it, and subsequent fixtures see the mutation:

```python
def test_with_route(app, client):
    @app.route("/ping")
    def ping():
        return "pong"

    assert client.get("/ping").data == b"pong"
```

### 7.3 Context-locals without a request round-trip

```python
def test_url_building(app_ctx):
    assert url_for("static", filename="test.txt") == "/static/test.txt"

def test_request_globals(req_ctx):
    assert request_ctx.app is current_app._get_current_object()
```

### 7.4 Importing a sample app (CLI / blueprint discovery tests)

```python
def test_factory_discovery(test_apps):
    from cliapp.factory import create_app2   # resolved via test_apps path
    ...
# on teardown: sys.path entry removed AND newly cached modules purged
```

### 7.5 Emulating an installed package

```python
def test_installed_package_paths(site_packages, modules_tmp_path_prefix):
    # site_packages/.../site-packages exists, sys.prefix points at modules_tmp
    ...
```

---

## 8. Relationship to Other Modules

| Module | How it consumes this infrastructure | Reference |
|---|---|---|
| **application-core** | `test_basic.py`, `test_async.py`, `test_signals.py`, … request `app`, `client`, `req_ctx`; `leak_detector` validates their context handling | [application-core](application-core.md) |
| **contexts** | `test_appctx.py` / `test_reqctx.py` use `app_ctx` and `req_ctx` to test `AppContext`/`RequestContext` push-pop and teardown semantics; `leak_detector` is the safety net for those tests | [contexts](contexts.md) |
| **blueprints** | `test_blueprints.py` uses `test_apps` to import `blueprintapp` and `app`/`client` for per-test blueprint registration | [blueprints](blueprints.md) |
| **testing-support** | `test_testing.py` exercises `FlaskClient`/`FlaskCliRunner` through the `client` fixture and `app.test_cli_runner()`; the `client` fixture *creates* `FlaskClient` instances | [testing-support](testing-support.md) |
| **command-line-interface** | `test_cli.py` relies on `test_apps` for app discovery targets, `_reset_os_environ`/`_standard_os_environ` because `ScriptInfo` and dotenv handling read `FLASK_APP`/`FLASK_ENV_FILE` | [command-line-interface](command-line-interface.md) |
| **configuration / logging / templating / sessions / JSON** | Use `app` + `client` for config reload, logger setup, rendering, and cookie-signing tests | [configuration](configuration.md), [logging](logging.md), [templating](templating.md), [sessions](sessions.md), [json-serialization](json-serialization.md) |

Cross-cutting invariant: **any module that touches `os.environ`, `sys.path`, `sys.modules`, `sys.prefix`, or Flask's context variables must do so through these fixtures** (or its own `monkeypatch`), never by mutating global state directly.

---

## 9. Extension Guidelines

When adding fixtures to `tests/conftest.py`, follow the established conventions:

1. **Never leave global state behind.** Route every mutation of `os.environ`, `sys.path`, `sys.modules`, or `sys.prefix` through `monkeypatch` (or the prepare-and-purge pattern of `test_apps`). Autouse teardowns assume this.
2. **Scope deliberately.** Only `_standard_os_environ` is session-scoped; everything else is function-scoped so tests stay order-independent under `-p xdist` and `-rf` reruns. New shared resources should be read-only or copy-on-write.
3. **Composability over configuration.** Prefer deriving from `app` (like `client`, `app_ctx`) so per-test mutations to `app` are visible to dependent fixtures — do not create a second `Flask(...)` factory that bypasses it.
4. **Autouse sparingly.** `leak_detector` and the environ pair are autouse because they are *invariants of the suite*, not conveniences. New autouse fixtures must be O(1) per test.
5. **Yield the live object.** Context fixtures yield the context (`ctx`) itself, mirroring `AppContext`/`RequestContext` context-manager semantics; consumers get teardown for free.

### Known limitations

- `_standard_os_environ` deletes variables at session start; a variable *absent* on the developer machine that a test *sets* is still cleaned by `_reset_os_environ` (the op list records deletions, and `monkeypatch` replays them), but tests that mutate `os.environ` *without* monkeypatch rely entirely on this replay covering the five known keys — new Flask env vars must be added to that tuple.
- `leak_detector` only inspects `request_ctx`; an `AppContext` leaked without a request context is not asserted (it is only implicitly popped on the next `RequestContext.pop` or process exit).
- `test_apps` purge is identity-based (`sys.modules.keys() - original_modules`); a module replaced rather than added would not be restored.
