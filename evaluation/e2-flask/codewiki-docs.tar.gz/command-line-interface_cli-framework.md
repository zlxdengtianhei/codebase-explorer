# Command-Line Interface: CLI Framework (`FlaskGroup`)

## 1. Introduction

The `command-line-interface_cli-framework` module implements **`FlaskGroup`**, the dynamic command group class at the heart of the `flask` command-line tool. While a plain Click `Group` only knows the commands explicitly registered on it, `FlaskGroup` is *context-aware*: it aggregates commands from three sources at invocation time — built-in Flask commands, third-party extensions installed as `flask.commands` entry points, and commands registered on the user's application (`app.cli` and blueprint CLI groups).

To do this safely, `FlaskGroup` defers application loading until it is actually needed (via [`ScriptInfo`](command-line-interface_app-discovery.md)), pushes an [application context](contexts_app_context.md) around app-provided commands, and degrades gracefully when no application can be found — so basic commands and help output still work in broken or incomplete projects.

> **Module position:** This is a sub-module of [Command-Line Interface](command-line-interface.md), alongside:
> - [App Discovery](command-line-interface_app-discovery.md) — `ScriptInfo`, app import/factory resolution
> - [Built-in Commands](command-line-interface_built-in-commands.md) — `run`, `shell`, `routes`, SSL/cert option types
> - [Environment Config](command-line-interface_environment-config.md) — dotenv loading, `--debug` handling
> - [Test Suite](command-line-interface_test-suite.md) — behavioral coverage for all of the above

---

## 2. Role in the Overall System

`FlaskGroup` is the **orchestrator** of the `flask` CLI. The module-level `cli` object in `src/flask/cli.py` is a `FlaskGroup` instance:

```python
cli = FlaskGroup(
    name="flask",
    help="""A general utility script for Flask applications. ...""",
)
```

It connects the Click framework to Flask's application model:

| Concern | Handled by | Related module |
|---|---|---|
| Finding / creating the `Flask` app (lazy, once) | `ScriptInfo.load_app()` | [App Discovery](command-line-interface_app-discovery.md) |
| Serving the app locally (`run`), REPL (`shell`), route listing (`routes`) | Built-in commands | [Built-in Commands](command-line-interface_built-in-commands.md) |
| Loading `.env` / `.flaskenv`, debug flag wiring | Eager options + `load_dotenv` | [Environment Config](command-line-interface_environment-config.md) |
| `current_app` availability during command execution | `ctx.with_resource(app.app_context())` | [App Context](contexts_app_context.md) |
| App-owned commands (incl. blueprint groups) | `app.cli` (`AppGroup` attached by `Flask`) | [Application Core: Flask App](application-core_flask-app.md), [Blueprints: Resources & CLI](blueprints_resources_and_cli.md) |
| CLI invocation in tests | `FlaskCliRunner` / `app.test_cli_runner()` | [Testing Support](testing-support.md) |

---

## 3. Class Hierarchy

`FlaskGroup` extends Click's group machinery through one intermediate class, `AppGroup`:

```mermaid
classDiagram
    class click_Group {
        <<Click framework>>
        +get_command(ctx, name)
        +list_commands(ctx) List~str~
        +make_context(info_name, args, parent)
        +parse_args(ctx, args)
    }
    class AppGroup {
        command and group decorators auto-wrap
        callbacks with with_appcontext
        +command(with_appcontext=True)
        +group(cls=AppGroup)
    }
    class FlaskGroup {
        +create_app: Callable
        +load_dotenv: bool
        +set_debug_flag: bool
        -_loaded_plugin_commands: bool
        +__init__(add_default_commands, create_app, add_version_option, load_dotenv, set_debug_flag)
        -_load_plugin_commands()
        +get_command(ctx, name) Command
        +list_commands(ctx) List~str~
        +make_context(info_name, args, parent)
        +parse_args(ctx, args)
    }
    class ScriptInfo {
        +app_import_path: str
        +create_app: Callable
        +load_dotenv_defaults: bool
        +load_app() Flask
    }
    class click_Command {
        <<Click framework>>
    }

    click_Group <|-- AppGroup : inherits
    AppGroup <|-- FlaskGroup : inherits
    FlaskGroup ..> ScriptInfo : creates as ctx.obj
    FlaskGroup o-- click_Command : run / shell / routes / plugins / app commands
```

Key distinctions:

- **`AppGroup`** (see [Command-Line Interface](command-line-interface.md)) only changes the `command()`/`group()` decorators so callbacks are wrapped in `with_appcontext`. It does *not* touch command lookup.
- **`FlaskGroup`** overrides the four core dispatch hooks (`__init__`, `get_command`, `list_commands`, `make_context`, `parse_args`) to add lazy app loading, plugin discovery, and context injection. As the docstring warns, it is *not to be confused with `AppGroup`* — one is a decorator convenience, the other is the dynamic dispatcher.

---

## 4. Architecture Overview

The diagram below shows how `FlaskGroup` wires together eager options, command sources, and the lazy application loader:

```mermaid
flowchart TB
    subgraph ENTRY["Module-level entry point"]
        FG["FlaskGroup 'flask'"]
    end

    subgraph EAGER["Eager options injected in __init__ (in this order)"]
        direction LR
        E1["_env_file_option -e/--env-file"]
        E2["_app_option -A/--app"]
        E3["_debug_option --debug/--no-debug"]
        E4["version_option --version"]
    end

    subgraph SOURCES["Command sources (resolved lazily)"]
        direction TB
        S1["Tier 1 - Built-in<br/>run_command / shell_command / routes_command"]
        S2["Tier 2 - Plugins<br/>importlib.metadata entry_points group 'flask.commands'"]
        S3["Tier 3 - Application<br/>app.cli (AppGroup on the Flask instance)"]
    end

    SI["ScriptInfo<br/>(lazy, cached app loader)"]
    CTX["app.app_context()<br/>pushed via ctx.with_resource"]

    FG --> EAGER
    FG -->|"add_default_commands=True"| S1
    FG -->|"_load_plugin_commands() once"| S2
    FG -->|"ctx.obj = ScriptInfo"| SI
    SI -->|"imports module / calls factory"| S3
    FG -->|"for app commands only"| CTX
    CTX --> S3

    style EAGER fill:#eef6ff,stroke:#4a86c8
    style SOURCES fill:#f2fbf2,stroke:#4a9d5b
```

Ordering matters: `--env-file` is registered **before** `--app` so environment variables from dotenv files are available while the `--app` option (and any factory function) is being processed. All option processing happens through **option callbacks** rather than a group callback, so users can define their own group callback without losing framework behavior.

---

## 5. Construction and Configuration

### 5.1 Constructor parameters

```python
FlaskGroup(
    add_default_commands: bool = True,
    create_app: Callable[..., Flask] | None = None,
    add_version_option: bool = True,
    load_dotenv: bool = True,
    set_debug_flag: bool = True,
    **extra,  # forwarded to click.Group
)
```

| Parameter | Default | Effect |
|---|---|---|
| `add_default_commands` | `True` | Registers the built-in `run`, `shell`, and `routes` commands (see [Built-in Commands](command-line-interface_built-in-commands.md)). |
| `create_app` | `None` | Callback that returns the `Flask` instance directly, **bypassing app discovery entirely**. Passed through to the `ScriptInfo` created in `make_context()`. Preferred for custom scripts and tests. |
| `add_version_option` | `True` | Adds the `--version` option, which reports the Python, Flask, and Werkzeug versions via `importlib.metadata`. |
| `load_dotenv` | `True` | Forwarded to `ScriptInfo` as `load_dotenv_defaults`; controls whether default `.flaskenv`/`.env` files are loaded during option processing (see [Environment Config](command-line-interface_environment-config.md)). |
| `set_debug_flag` | `True` | Forwarded to `ScriptInfo`; controls whether the app's `debug` attribute is set from the `FLASK_DEBUG` environment value at load time. |
| `**extra` | — | Forwarded to `click.Group`. Notably, `context_settings["auto_envvar_prefix"]` defaults to `"FLASK"`, so framework options can also be supplied as environment variables (`FLASK_APP`, `FLASK_DEBUG`, …). |

### 5.2 Eager options

Four options are injected at construction time. Each is *eager* (processed before normal argument parsing), and none is exposed to the command callback (`expose_value=False`) — they communicate purely through side effects:

| Option | Callback | Side effect |
|---|---|---|
| `-e/--env-file PATH` | `_env_file_callback` | Loads the given file (and/or defaults) into `os.environ` at the earliest possible moment. |
| `-A/--app IMPORT` | `_set_app` | Records the import path on `ctx.ensure_object(ScriptInfo)`. Eager so the app is resolvable even when `--help` is requested. |
| `--debug/--no-debug` | `_set_debug` | Writes `FLASK_DEBUG=1`/`0` to `os.environ` **unless the value came from a default** (i.e., the flag was not explicitly given), letting env-based debug configuration win. |
| `--version` | `get_version` | Prints and exits; eager flag. |

---

## 6. Runtime Behavior

### 6.1 `make_context()` — session bootstrap

Before any parsing occurs, `FlaskGroup.make_context()`:

1. **Sets `FLASK_RUN_FROM_CLI=true` in `os.environ`.** This is a safety valve: if an app module calls `app.run()` at import time (outside an `if __name__ == "__main__"` guard), the run call becomes a no-op instead of blocking the CLI with a live server during app import.
2. **Installs a `ScriptInfo` as the Click context object** (`extra["obj"]`) unless one is already provided. The `ScriptInfo` is constructed with the group's `create_app`, `set_debug_flag`, and `load_dotenv` (as `load_dotenv_defaults`) so that every downstream component agrees on how the app is created. Use `pass_script_info` to receive it in command callbacks.

### 6.2 `parse_args()` — help output with environment awareness

When the group is invoked with **no arguments** (`no_args_is_help`) or only a help flag, normal eager processing would not run. `parse_args` compensates by manually handling `_env_file_option` and `_app_option`:

```python
# Attempt to load --env-file and --app early in case they
# were given as env vars. Otherwise no_args_is_help will not
# see commands from app.cli.
_env_file_option.handle_parse_result(ctx, {}, [])
_app_option.handle_parse_result(ctx, {}, [])
```

This means `flask --help` will still load `FLASK_APP`/dotenv files and can list commands contributed by the application.

### 6.3 Command resolution — `get_command()` / `list_commands()`

Both lookups follow a two-tier strategy: built-in and plugin commands are resolved first (these work **even if no app can be loaded**), then the application is loaded and asked for the command.

```mermaid
flowchart TD
    A["get_command(ctx, name)"] --> B["_load_plugin_commands()<br/>(idempotent, once)"]
    B --> C{"Found in built-in<br/>or plugin commands?"}
    C -- Yes --> D["return command<br/>(no app load required)"]
    C -- No --> E["info = ctx.ensure_object(ScriptInfo)"]
    E --> F{"info.load_app()"}
    F -- "NoAppException" --> G["echo red error to stderr<br/>return None"]
    F -- Success --> H{"current_app active and<br/>is the same app?"}
    H -- "No" --> I["ctx.with_resource(app.app_context())"]
    H -- "Yes" --> J["app.cli.get_command(ctx, name)"]
    I --> J
    J --> K["return app command"]

    style G fill:#fdecec,stroke:#c0392b
    style D fill:#f2fbf2,stroke:#4a9d5b
```

`list_commands()` mirrors this: it starts from the built-in/plugin command set, merges `app.cli.list_commands(ctx)`, and returns the sorted union. Error handling differs by cause:

- **`NoAppException`** → a concise red message (no traceback) is printed to stderr, and the built-in/plugin list is still returned.
- **Any other exception during app load** → the full traceback is printed to stderr (the project is broken in a non-obvious way).

### 6.4 End-to-end invocation flow

The sequence below traces a typical `flask <command>` invocation that resolves to an application-provided command:

```mermaid
sequenceDiagram
    autonumber
    participant U as User shell
    participant FG as FlaskGroup
    participant CX as click.Context
    participant SI as ScriptInfo
    participant AP as Flask app
    participant CB as Command callback

    U->>FG: flask --app myapp:app <command> [args]
    FG->>FG: parse_args() - eager env-file/app handling for help cases
    FG->>CX: make_context()
    Note over CX: FLASK_RUN_FROM_CLI=true<br/>ctx.obj = ScriptInfo(create_app, ...)
    FG->>FG: _load_plugin_commands()
    FG->>CX: super().get_command(name) - built-in + plugins
    CX-->>FG: not found
    FG->>SI: load_app()
    SI->>AP: import module / call factory (cached after first call)
    Note over FG: current_app not active → ctx.with_resource(app.app_context())
    FG->>AP: app.cli.get_command(ctx, name)
    AP-->>FG: app command
    FG->>CB: invoke with current_app available
    Note over CB: teardown: app context popped via with_resource
```

### 6.5 Application context injection

For app-provided commands, `get_command()` pushes the app's context with `ctx.with_resource(app.app_context())` unless an identical app is already current. This guarantee is what lets `app.cli` commands (and even their **parameter callbacks**) use `current_app` without decorating anything — see the docs for the context primitives in [App Context](contexts_app_context.md). Two tests pin this behavior:

- `test_flaskgroup_app_context` — a command on a `FlaskGroup` reads `current_app.name`.
- `test_app_cli_has_app_context` — `current_app` is available in a *parameter callback*, and the loaded app `is` `current_app`.

By contrast, standalone Click commands (not registered on `app.cli`) still need the `@with_appcontext` decorator, as shown by `test_with_appcontext`.

---

## 7. Command Sources in Detail

| Tier | Source | Loaded when | Requires app? |
|---|---|---|---|
| **Built-in** | `run_command`, `shell_command`, `routes_command` added in `__init__` when `add_default_commands=True` | Immediately, at construction | No |
| **Plugins** | `importlib.metadata.entry_points(group="flask.commands")` | Lazily, on first `get_command`/`list_commands` call, guarded by `_loaded_plugin_commands` | No |
| **Application** | Commands registered on `app.cli` — including per-blueprint CLI groups (`cli_group`) contributed when blueprints register | Lazily, via `ScriptInfo.load_app()`; cached by `ScriptInfo` | **Yes** |

Notes:

- Blueprint commands appear as sub-groups of `app.cli` according to each blueprint's `cli_group` setting (default: blueprint name; `None` merges into the app group). Verified by `test_cli_blueprints`; see [Blueprints: Resources & CLI](blueprints_resources_and_cli.md).
- The plugin tier is how Flask extensions add `flask <plugin-command>` entry points without any user configuration.
- `AppGroup`-style registration on `app.cli` (e.g., via `@app.cli.command()`) automatically wraps callbacks in `with_appcontext`, but since `FlaskGroup` already pushes the context, that wrapper becomes a no-op check (`if not current_app`) — both paths are safe.

---

## 8. Error Handling and Graceful Degradation

`FlaskGroup` is deliberately resilient:

- **Missing/unloadable app:** `get_command` returns `None` after echoing a red `Error: ...` message; `list_commands` still yields built-in/plugin commands. The user always sees the built-in CLI surface, and the error message guides them toward `--app`/`FLASK_APP`/`wsgi.py`/`app.py` conventions (see [App Discovery](command-line-interface_app-discovery.md)).
- **Import errors inside the app module:** surfaced as `NoAppException` with the original traceback embedded ([App Discovery](command-line-interface_app-discovery.md)).
- **Unexpected exceptions during app loading:** full traceback printed to stderr in `list_commands` — the distinction (no traceback for "no app found", traceback for "app exists but is broken") keeps diagnostics actionable.
- **`--debug` ambiguity:** `_set_debug` ignores the flag when its parameter source is a *default*, so an explicit `--debug`/`--no-debug` on the command line wins, but an unset flag does not clobber `FLASK_DEBUG` from the environment.

---

## 9. Usage Patterns

### 9.1 Default `flask` CLI (most users)

No code required — the module-level `cli` group is installed as the `flask` console script. The app is discovered from `--app`, `FLASK_APP`, `wsgi.py`, or `app.py`.

### 9.2 Custom scripts (advanced)

Projects can expose their own CLI entry point based on `FlaskGroup`, supplying a factory to skip discovery:

```python
import click
from flask.cli import FlaskGroup

def create_app():
    from myapp import app
    return app

@click.group(cls=FlaskGroup, create_app=create_app)
def cli(**params):
    """Management script for my project."""

if __name__ == "__main__":
    cli()
```

This mirrors `test_flaskgroup_app_context` and is the documented pattern for [custom scripts].

### 9.3 Nesting under another group

`FlaskGroup` can be embedded as a sub-command of a larger Click group — `test_flaskgroup_nested` invokes `cli flask show` and confirms the app context still resolves:

```python
cli = click.Group("cli")
flask_group = FlaskGroup(name="flask", create_app=lambda: app)
cli.add_command(flask_group)
```

This works because `make_context` ensures a `ScriptInfo` object exists in whatever context `FlaskGroup` runs in; the group never assumes it is the root.

### 9.4 Controlling debug propagation

`set_debug_flag=False` prevents `ScriptInfo` from overwriting `app.debug` from `FLASK_DEBUG`. `test_flaskgroup_debug` shows that with `set_debug_flag=False` an app's own `app.debug = True` survives, while with the default the environment decides.

---

## 10. Testing Coverage

Behavioral guarantees for this module are exercised by the [CLI Test Suite](command-line-interface_test-suite.md). The tests most specific to `FlaskGroup` are:

| Test | Behavior verified |
|---|---|
| `test_flaskgroup_app_context` | Commands get a working app context; `current_app.name` matches the factory's app. |
| `test_flaskgroup_debug` | `set_debug_flag` controls whether `FLASK_DEBUG` overrides `app.debug`. |
| `test_flaskgroup_nested` | `FlaskGroup` works nested under a plain `click.Group`. |
| `test_app_cli_has_app_context` | `current_app` is available in parameter callbacks; loaded app `is` `current_app`. |
| `test_with_appcontext` | Standalone commands still need `@with_appcontext`; the decorator loads via `ScriptInfo`. |
| `test_cli_blueprints` | Blueprint CLI commands surface as groups under `app.cli` with custom/merged/late `cli_group` names. |
| `test_flaskgroup_*` (help/echo tests in [Test Suite](command-line-interface_test-suite.md)) | Graceful errors when no app is found; help output availability. |

---

## 11. Related Documentation

- [Command-Line Interface](command-line-interface.md) — parent module overview (`AppGroup`, `with_appcontext`, module entry point)
- [CLI: App Discovery](command-line-interface_app-discovery.md) — `ScriptInfo`, `find_best_app`, `locate_app`, `prepare_import`
- [CLI: Built-in Commands](command-line-interface_built-in-commands.md) — `run`/`shell`/`routes`, `CertParamType`, `--key` validation
- [CLI: Environment Config](command-line-interface_environment-config.md) — dotenv loading, `_set_debug`, path helpers
- [CLI: Test Suite](command-line-interface_test-suite.md) — end-to-end CLI testing, fixtures, test apps
- [Application Core: Flask App](application-core_flask-app.md) — the `Flask` object and its `app.cli` attribute
- [App Context](contexts_app_context.md) — `app_context()`, `current_app`, context push/pop semantics
- [Blueprints: Resources & CLI](blueprints_resources_and_cli.md) — blueprint `cli_group` registration
- [Testing Support](testing-support.md) — `FlaskCliRunner` used to invoke this group in tests
