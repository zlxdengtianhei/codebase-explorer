# Sessions Module (`flask.sessions`)

## 1. Overview

The **sessions** module implements Flask's mechanism for persisting user-specific data across requests — the classic "login state", "shopping cart", or "flash messages" use cases. HTTP is stateless; this module bridges that gap by encoding session data into a **cryptographically signed cookie** that is round-tripped between server and browser.

The module delivers:

| Capability | Implementation |
|---|---|
| Session data container with change tracking | `SecureCookieSession` (+ `SessionMixin`) |
| Graceful degradation when no `SECRET_KEY` is set | `NullSession` |
| Pluggable storage strategy (abstract contract) | `SessionInterface` |
| Default storage backend (itsdangerous signed cookies) | `SecureCookieSessionInterface` |
| Rich JSON payload encoding for non-JSON types | `session_json_serializer` (`TaggedJSONSerializer`) |
| FIPS-safe hashing | `_lazy_sha1` |

The module is a sibling of [helpers.md](helpers.md), [templating.md](templating.md), and [json-serialization.md](json-serialization.md) under the *Request Services & Response Rendering* layer. It depends on the application core (see [application-core.md](application-core.md)) for the `Flask` object and on the request context machinery (see [contexts.md](contexts.md)) for lifecycle integration.

---

## 2. Architecture

### 2.1 Class Hierarchy

```mermaid
classDiagram
    direction TB

    class MutableMapping {
        <<stdlib abc>>
    }
    class CallbackDict {
        <<werkzeug>>
        on_update callback
    }
    class SessionMixin {
        <<mixin>>
        +permanent : bool
        +new : bool = False
        +modified : bool = True
        +accessed : bool = True
    }
    class SecureCookieSession {
        +modified : bool = False
        +accessed : bool = False
        +__init__(initial)
        +__getitem__(key)
        +get(key, default)
        +setdefault(key, default)
    }
    class NullSession {
        -_fail()
        All mutating dunders raise RuntimeError
    }
    class SessionInterface {
        <<abstract>>
        +null_session_class
        +pickle_based : bool
        +make_null_session(app)
        +is_null_session(obj)
        +get_cookie_*(app) cookie attribute getters
        +get_expiration_time(app, session)
        +should_set_cookie(app, session)
        +open_session(app, request)*
        +save_session(app, session, response)*
    }
    class SecureCookieSessionInterface {
        +salt = "cookie-session"
        +digest_method = _lazy_sha1
        +key_derivation = "hmac"
        +serializer = session_json_serializer
        +session_class = SecureCookieSession
        +get_signing_serializer(app)
        +open_session(app, request)
        +save_session(app, session, response)
    }

    MutableMapping <|.. SessionMixin : implements
    CallbackDict --|> SecureCookieSession : extends
    SessionMixin ..|> SecureCookieSession : mixes in
    SecureCookieSession --|> NullSession : extends
    SessionInterface --|> SecureCookieSessionInterface : extends
    SecureCookieSessionInterface o-- SecureCookieSession : session_class
    SecureCookieSessionInterface o-- TaggedJSONSerializer : serializer
```

**Design intent:**

- `SecureCookieSession` is a `CallbackDict`: *any* mutation triggers an `on_update` hook that flips `modified`/`accessed`, so Flask knows whether a new cookie must be emitted.
- `NullSession` inherits from `SecureCookieSession` but overrides every mutating operation with a single `_fail()` that raises a descriptive `RuntimeError` — read-only access still works, so templates/code that merely inspect `session` do not crash.
- `SessionInterface` separates **policy** (cookie name, domain, path, expiry…) from **storage mechanics** (`open_session` / `save_session`). All policy methods read from app config with sensible defaults, so custom backends inherit them for free.

### 2.2 Integration with the Request Lifecycle

The module is stateless on the server; the session object exists only for the duration of a request, created and destroyed by the context system (see [contexts.md](contexts.md), [contexts_request_context.md](contexts_request_context.md)):

```mermaid
sequenceDiagram
    autonumber
    participant W as Flask.wsgi_app
    participant RC as RequestContext
    participant SI as SessionInterface
    participant SE as Session
    participant V as View function
    participant RS as Response

    W->>RC: push()
    RC->>RC: ensure AppContext pushed
    RC->>SI: open_session(app, request)
    SI->>SI: get_signing_serializer(app)
    alt No SECRET_KEY
        SI-->>RC: None → make_null_session() → NullSession
    else No / invalid cookie
        SI-->>RC: empty SecureCookieSession
    else Valid signed cookie
        SI->>SI: s.loads(val, max_age=lifetime)
        SI-->>RC: SecureCookieSession(data)
    end
    Note over RC,V: URL match happens AFTER session load,<br/>so custom URL converters can use the session
    W->>V: dispatch_request()
    V->>SE: session["user_id"] = 42 → modified=True, accessed=True
    W->>RS: finalize_request() → process_response()
    RS->>SI: save_session(app, session, response)
    SI->>RS: response.set_cookie(signed payload) + Vary: Cookie
    W->>RC: pop()
```

Two hooks on `Flask` drive the whole cycle:

- **Open** — `RequestContext.push()` calls `app.session_interface.open_session(app, request)`; a `None` return falls back to `make_null_session()`. This happens *before* URL matching, which is why `open_session` may call `request_ctx.match_request()` itself if endpoint info is needed while loading (see `tests/test_session_interface.py::test_open_session_with_endpoint`).
- **Save** — `Flask.process_response()` calls `session_interface.save_session(app, session, response)` at the end of every request, *skipping* the call when `is_null_session()` is true.

### 2.3 Module Dependency Graph

```mermaid
flowchart LR
    subgraph this[This module]
        SESSIONS[flask.sessions<br/>SessionInterface family]
    end

    subgraph core[Application Core]
        APP[Flask<br/>session_interface attribute]
        CTX[RequestContext<br/>push/pop hooks]
    end

    subgraph jsonmod[JSON Serialization]
        TAG[TaggedJSONSerializer<br/>json/tag.py]
    end

    subgraph external[External libraries]
        ITSD[itsdangerous<br/>URLSafeTimedSerializer]
        WZ[Werkzeug<br/>CallbackDict, Request, Response]
    end

    subgraph config[Configuration]
        CFG[Config keys:<br/>SECRET_KEY, SECRET_KEY_FALLBACKS,<br/>SESSION_COOKIE_*,<br/>PERMANENT_SESSION_LIFETIME,<br/>SESSION_REFRESH_EACH_REQUEST]
    end

    APP -->|holds default instance| SESSIONS
    CTX -->|open_session on push| SESSIONS
    SESSIONS -->|payload serialization| TAG
    SESSIONS -->|signing| ITSD
    SESSIONS -->|session dict base| WZ
    SESSIONS -->|policy lookups| CFG
```

Because the payload serializer is the same tag-based serializer used by `flask.json` (documented in [json-serialization.md](json-serialization.md)), sessions transparently support `datetime`, `UUID`, `bytes`, `tuples`, `Markup`, and nested structures.

---

## 3. Core Components

### 3.1 `SessionMixin`

A `MutableMapping` mixin that expands a plain dict with the attributes every Flask session must expose:

| Attribute | Default | Meaning |
|---|---|---|
| `permanent` | `False` | Reflects the `'_permanent'` key; when `True`, `get_expiration_time()` stamps the cookie with `PERMANENT_SESSION_LIFETIME` instead of making it a browser-session cookie. |
| `new` | `False` | Hard-coded: cookie sessions cannot reliably distinguish "new" from "empty". |
| `modified` | `True` | Set by implementations that track changes. |
| `accessed` | `True` | Set when data is read or written; drives the `Vary: Cookie` header. |

Custom backends are expected to combine it with a dict: `class Session(dict, SessionMixin): pass`.

### 3.2 `SecureCookieSession`

`CallbackDict` + `SessionMixin` — the default in-memory session object.

- The `on_update` callback flips `modified = True` and `accessed = True` on any mutation. **Only direct assignment is tracked**: mutating nested values (e.g. `session["cart"].append(...)`) requires setting `session.modified = True` manually, otherwise the cookie won't be re-issued.
- `__getitem__`, `get`, and `setdefault` also flip `accessed = True`, so even *read-only* requests get `Vary: Cookie` (lets caching proxies store per-user page variants).
- Starts with `modified = False` and `accessed = False`; a request that never touches the session yields no `Set-Cookie` and no `Vary` header.

### 3.3 `NullSession`

Fallback object created when a real session cannot be loaded (typically: no `SECRET_KEY` configured). Every mutating operation — `__setitem__`, `__delitem__`, `clear`, `pop`, `popitem`, `update`, `setdefault` — routes to `_fail()`, raising:

> `RuntimeError: The session is unavailable because no secret key was set. Set the secret_key on the application to something unique and secret.`

Reads still succeed (returning the empty mapping), so rendering and inspection code doesn't break; only *writes* tell the developer exactly what to fix. `SessionInterface.is_null_session()` uses this class for its type check, which is what prevents Flask from ever attempting to serialize a null session into the response.

### 3.4 `SessionInterface` — the extension contract

Abstract interface (added in Flask 0.8) to be subclassed when replacing cookie storage with e.g. Redis or database sessions. Only `open_session` and `save_session` are mandatory; everything else is policy with config-backed defaults:

| Method | Source of truth |
|---|---|
| `get_cookie_name` | `SESSION_COOKIE_NAME` (default `"session"`) |
| `get_cookie_domain` | `SESSION_COOKIE_DOMAIN` (`None` since 2.3 — no `SERVER_NAME` fallback) |
| `get_cookie_path` | `SESSION_COOKIE_PATH`, else `APPLICATION_ROOT` |
| `get_cookie_httponly` | `SESSION_COOKIE_HTTPONLY` (default `True`) |
| `get_cookie_secure` | `SESSION_COOKIE_SECURE` |
| `get_cookie_samesite` | `SESSION_COOKIE_SAMESITE` |
| `get_cookie_partitioned` | `SESSION_COOKIE_PARTITIONED` (3.1+, CHIPS support) |
| `get_expiration_time` | `now(utc) + PERMANENT_SESSION_LIFETIME` if `session.permanent`, else `None` (browser-session cookie) |
| `should_set_cookie` | `session.modified or (session.permanent and SESSION_REFRESH_EACH_REQUEST)` |
| `make_null_session` / `is_null_session` | instantiate / type-check against `null_session_class` |

Key semantic notes for implementers:

- `open_session` returning `None` means "not an error, but no session" → Flask builds a `NullSession`.
- **Concurrency**: multiple requests sharing one session may run in parallel; order of `open_session`/`save_session` calls is not guaranteed — synchronize access to any shared backing store yourself.
- `pickle_based = False` signals extensions how the session object may be treated.

### 3.5 `SecureCookieSessionInterface` — the default backend

Stores the entire session in a client-side cookie signed with **itsdangerous**'s `URLSafeTimedSerializer`.

Signing parameters:

```python
salt           = "cookie-session"
digest_method  = staticmethod(_lazy_sha1)   # hmac-sha1
key_derivation = "hmac"
serializer     = session_json_serializer    # TaggedJSONSerializer instance
session_class  = SecureCookieSession
```

`get_signing_serializer(app)` builds a multi-key serializer:

- If `app.secret_key` is unset → returns `None` → `open_session` returns `None` → null session.
- `SECRET_KEY_FALLBACKS` are prepended and the current `secret_key` placed **last** (itsdangerous signs with the last key but validates against all) — enabling **zero-downtime key rotation** (see `tests/test_basic.py::test_session_secret_key_fallbacks`).

**`open_session(app, request)`**

1. No signing serializer (`None`) → return `None` (→ `NullSession`).
2. No cookie value → fresh empty `SecureCookieSession`.
3. Load with `max_age = PERMANENT_SESSION_LIFETIME` seconds; a `BadSignature` (tampered, expired, or wrong key) yields a fresh empty session rather than an error — invalid cookies are silently discarded.
4. Success → `SecureCookieSession(data)` restored with tagged types (`datetime`, `UUID`, …) intact.

**`save_session(app, session, response)`** decision flow:

```mermaid
flowchart TD
    A[save_session called by process_response] --> B{session.accessed?}
    B -- yes --> C["response.vary.add('Cookie')"]
    B -- no --> D
    C --> D{"session empty?"}
    D -- "yes + modified" --> E["delete_cookie(name, …)<br/>+ Vary: Cookie"]
    D -- "yes, not modified" --> F[return — no cookie]
    D -- no --> G{"should_set_cookie?<br/>modified OR (permanent AND<br/>SESSION_REFRESH_EACH_REQUEST)"}
    G -- no --> F
    G -- yes --> H["expires = get_expiration_time<br/>val = serializer.dumps(session)"]
    H --> I["response.set_cookie(...)<br/>+ Vary: Cookie"]
```

This logic guarantees:

- Sessions that were only *read* never re-issue the cookie (bandwidth-friendly, yet `Vary: Cookie` keeps caches correct).
- Clearing the session (`session.clear()` + modified) actively deletes the browser cookie.
- Permanent sessions are refreshed on every request while `SESSION_REFRESH_EACH_REQUEST` is `True`, sliding the expiry window forward.

### 3.6 `session_json_serializer` & `_lazy_sha1`

- `session_json_serializer = TaggedJSONSerializer()` — module-level singleton shared as the payload codec; see [json-serialization.md](json-serialization.md) for the tag system (`PassDict`, `TagTuple`, `TagBytes`, `TagDateTime`, `TagUUID`, …) and how to register custom tags.
- `_lazy_sha1(string=b"")` — defers the `hashlib.sha1` attribute lookup from import time to call time. On **FIPS-hardened builds** the SHA-1 constructor may not exist, which would make the module-level default crash at import; lazy access lets the developer swap `digest_method` before the interface is ever used.

---

## 4. Session Lifecycle — End-to-End Data Flow

```mermaid
flowchart TB
    subgraph request-start["Request start (RequestContext.push)"]
        A1[WSGI environ] --> A2[Request object]
        A2 --> A3{"open_session(app, request)"}
        A3 -->|serializer None| A4[NullSession]
        A3 -->|cookie valid| A5["SecureCookieSession(data)"]
        A3 -->|no/bad cookie| A6[empty SecureCookieSession]
    end

    subgraph during-request["During request"]
        B1["flask.session proxy → ctx.session"]
        B2[View / before_request reads & writes]
        B1 --> B2
        B2 -->|"mutation"| B3["modified = True, accessed = True"]
        B2 -->|"read only"| B4["accessed = True"]
    end

    subgraph request-end["Request end (process_response)"]
        C1{"is_null_session?"} -->|yes| C2[skip saving]
        C1 -->|no| C3["save_session(app, session, response)"]
        C3 --> C4["Signed, URL-safe payload<br/>+ cookie attributes from config<br/>+ Vary: Cookie"]
    end

    A4 --> B1
    A5 --> B1
    A6 --> B1
    B2 --> C1
    C4 --> B["Browser stores cookie<br/>round-trips it on next request"]
```

---

## 5. Configuration Reference

All policy knobs live on `app.config` (see [configuration.md](configuration.md) for the `Config` object):

| Key | Default | Effect |
|---|---|---|
| `SECRET_KEY` | `None` | Signing key; `None` ⇒ null sessions. |
| `SECRET_KEY_FALLBACKS` | `None` | Old keys still accepted for validation during rotation. |
| `PERMANENT_SESSION_LIFETIME` | `timedelta(days=31)` | `max_age` for loading and `Expires` for permanent cookies. |
| `SESSION_COOKIE_NAME` | `"session"` | Cookie name. |
| `SESSION_COOKIE_DOMAIN` / `_PATH` / `_HTTPONLY` / `_SECURE` / `_SAMESITE` / `_PARTITIONED` | `None` / `None` / `True` / `False` / `None` / `False` | Standard cookie attributes (`Set-Cookie` params). |
| `SESSION_REFRESH_EACH_REQUEST` | `True` | Re-send permanent-session cookie every request. |
| `APPLICATION_ROOT` | `"/"` | Fallback for cookie path. |

Related behavioral tests: `test_session_cookie_setting`, `test_session_expiration`, `test_session_path`, `test_session_using_application_root`, `test_session_using_samesite_attribute`, `test_session_using_session_settings`, `test_session_refresh_vary`, `test_session_vary_cookie`, `test_max_cookie_size` (all in `tests/test_basic.py`).

---

## 6. Customizing Sessions

### 6.1 Swap the interface

```python
app = Flask(__name__)
app.session_interface = MyRedisSessionInterface()   # subclass SessionInterface
```

Implement `open_session`/`save_session`; inherit every cookie-attribute helper. Remember the concurrency caveat from §3.4.

### 6.2 Load endpoint info while opening

```python
class MySessionInterface(SessionInterface):
    def open_session(self, app, request):
        request_ctx.match_request()          # populate request.endpoint now
        assert request.endpoint is not None  # URL matching is available
        ...
```

Sessions open **before** automatic URL matching; `RequestContext.match_request()` can be called manually when the loader needs routing results (covered by `tests/test_session_interface.py::test_open_session_with_endpoint`, and `tests/test_reqctx.py::test_session_dynamic_cookie_name` shows the same hook used for dynamic cookie names).

### 6.3 Change session behavior flags

```python
session.permanent = True          # use PERMANENT_SESSION_LIFETIME expiry
session.modified = True           # force cookie re-issue after nested mutation
app.permanent_session_lifetime = timedelta(days=7)
```

---

## 7. Error Handling & Edge Cases

| Situation | Behavior |
|---|---|
| Missing `SECRET_KEY` | Reads OK; writes raise the descriptive `RuntimeError` from `NullSession`. |
| Tampered / expired / foreign-key cookie | `BadSignature` swallowed → treated as a fresh, empty session. |
| Session set to empty & modified | `Set-Cookie` deleted from the response instead of re-issued. |
| Unmodified, non-permanent session | No `Set-Cookie` at all. |
| Session accessed (read or write) | `Vary: Cookie` added, enabling correct proxy caching. |
| Concurrent requests, same session | No ordering guarantee between `open_session` and `save_session` — backend must synchronize. |
| FIPS environment | `_lazy_sha1` avoids import-time failure; override `digest_method` if needed. |

---

## 8. Testing

- `tests/test_session_interface.py::test_open_session_with_endpoint` verifies custom interfaces can invoke `request_ctx.match_request()` during `open_session` and see `request.endpoint` populated.
- Cookie mechanics, fallback keys, and attributes are exercised extensively in `tests/test_basic.py` (e.g. `test_session`, `test_session_secret_key_fallbacks`, `test_session_special_types`, `test_session_stored_last`).
- The test client's **session transaction** feature (`client.session_transaction()`) can inject/inspect cookie sessions without a full request cycle — see [testing-support.md](testing-support.md) (`test_session_transactions*`, `test_session_transaction_needs_cookies`, `test_redirect_keep_session` in `tests/test_testing.py`).
- Null-session guardrails are asserted by `test_session_transactions_no_null_sessions` and `tests/test_reqctx.py::test_session_error_pops_context`.

---

## 9. Related Modules

- [application-core.md](application-core.md) — `Flask` holds the `session_interface` instance and defines all session-related config defaults.
- [contexts.md](contexts.md) / [contexts_request_context.md](contexts_request_context.md) — `RequestContext.push()/pop()` trigger `open_session`/context teardown; `session` is exposed via the `flask.session` proxy.
- [json-serialization.md](json-serialization.md) — `TaggedJSONSerializer` powering the cookie payload and its extensible tag registry.
- [helpers.md](helpers.md) — `flash()`/`get_flashed_messages()` store flashes in `session` (`tests/test_basic.py::test_flashes`, `test_extended_flashing`).
- [templating.md](templating.md) — the `session` proxy is injected into Jinja template contexts.
- [configuration.md](configuration.md) — how `Config` supplies the `SESSION_*` and `SECRET_KEY*` values (including `test_session_lifetime`).
- [testing-support.md](testing-support.md) — `FlaskClient` cookie jar and session-transaction helpers used to test sessions end-to-end.
