# Blueprints: Resources & CLI (`blueprints_resources_and_cli`)

## 1. Overview

The `blueprints_resources_and_cli` module contains the **concrete, importable** `Blueprint` class in `src/flask/blueprints.py`. While the sansio base class (`flask.sansio.blueprints.Blueprint`, documented in [blueprints_registration_machinery](blueprints_registration_machinery.md)) implements the deferred-setup and registration machinery, this module's subclass supplies the parts of a blueprint that require **runtime application state**:

| Capability | Members | Purpose |
|---|---|---|
| **CLI integration** | `self.cli` (`AppGroup`) | A Click command group attached to each blueprint; its commands become sub-commands of the `flask` CLI once the app is registered. |
| **Static file serving** | `get_send_file_max_age`, `send_static_file` | The view function and cache-header logic used by the auto-registered `static` endpoint of the blueprint. |
| **Package resources** | `open_resource` | Read-only, sandboxed file access relative to the blueprint's `root_path` (data files shipped inside the blueprint package). |

Because these behaviors touch the running application (configuration, request handling, the Click CLI), they cannot live in the framework-neutral sansio layer and are therefore the defining content of this module.

## 2. Position in the Blueprint Subsystem

This module is one of three siblings under the `blueprints` subsystem:

```mermaid
flowchart LR
    subgraph blueprints["blueprints subsystem"]
        direction TB
        RM["blueprints_registration_machinery<br/>(sansio.blueprints.Blueprint,<br/>BlueprintSetupState)"]
        RC["blueprints_resources_and_cli<br/>(blueprints.Blueprint)<br/>◀ this module"]
        TS["blueprints_test_suite<br/>(test_blueprints.py, blueprintapp)"]
    end
    RC -. inherits from .-> RM
    TS -. exercises .-> RC
    TS -. exercises .-> RM
```

- **Registration machinery** ([blueprints_registration_machinery](blueprints_registration_machinery.md)) — `SansioBlueprint` records deferred setup functions and, at `register()` time, drives them via `BlueprintSetupState`. It is also responsible for mounting this module's static route and CLI group (see §5).
- **Resources & CLI** (this module) — the `flask.blueprints.Blueprint` subclass that instantiates the `AppGroup` and provides static/resource methods.
- **Test suite** ([blueprints_test_suite](blueprints_test_suite.md)) — behavioral tests, e.g. `test_templates_and_static`, `test_default_static_max_age`, `test_cli_blueprints` (in [command-line-interface](command-line-interface.md)).

## 3. Class Architecture

```mermaid
classDiagram
    class Scaffold {
        <<sansio.scaffold>>
        +root_path : str
        +static_folder : str | None
        +static_url_path : str | None
        +has_static_folder : bool
        +jinja_loader
        +route()* add_url_rule()*
        +before_request()* errorhandler()*
    }
    class SansioBlueprint {
        <<sansio.blueprints>>
        +name : str
        +url_prefix : str | None
        +subdomain : str | None
        +cli_group : str | None | sentinel
        +deferred_functions : list
        +record() record_once()
        +make_setup_state() BlueprintSetupState
        +register_blueprint() register(app, options)
    }
    class Blueprint {
        <<flask.blueprints — this module>>
        +cli : AppGroup
        +__init__(...)
        +get_send_file_max_age(filename) int | None
        +send_static_file(filename) Response
        +open_resource(resource, mode, encoding) IO
    }
    class AppGroup {
        <<flask.cli>>
        +command(with_appcontext=True)
        +group(cls=AppGroup)
    }
    class Flask {
        <<flask.app>>
        +send_static_file() get_send_file_max_age()
        +open_resource()
    }
    Scaffold <|-- SansioBlueprint : extends
    SansioBlueprint <|-- Blueprint : extends
    Blueprint *-- AppGroup : self.cli (created in __init__)
    Blueprint ..> Flask : mirrors resource methods
```

Key structural points:

1. **`Blueprint(SansioBlueprint)`** — the concrete class re-exports `BlueprintSetupState` from the sansio module for API compatibility (re-export marked with `# noqa`).
2. **`self.cli = AppGroup()`** — created eagerly in `__init__` so users can decorate commands on the blueprint *before* any app exists. The group's name is seeded with the bare blueprint name (`self.cli.name = self.name`) so the group is usable even if embedded in an external Click tool.
3. **Deliberate duplication with `Flask`** — `get_send_file_max_age` and `send_static_file` are documented as duplicates of the same methods on the `Flask` class (see [application-core](application-core.md)). This allows blueprint static handling to be self-contained instead of delegating to the app object.
4. **`open_resource` is blueprint-relative** — the counterpart of `Flask.open_resource`, resolving paths against *the blueprint's* `root_path` (its package directory), not the app's.

## 4. Runtime Dependencies

```mermaid
flowchart TB
    BP["flask.blueprints.Blueprint<br/>(this module)"]

    subgraph CLI_Layer["command-line-interface"]
        AG["cli.AppGroup"]
        WAC["cli.with_appcontext"]
        FG["cli.FlaskGroup / ScriptInfo"]
    end

    subgraph Helpers_Layer["helpers"]
        SFD["helpers.send_from_directory<br/>→ werkzeug safe_join"]
    end

    subgraph Config_Layer["configuration"]
        CFG["Config['SEND_FILE_MAX_AGE_DEFAULT']"]
    end

    subgraph Sansio_Layer["blueprints_registration_machinery"]
        SB["sansio.blueprints.Blueprint<br/>register()"]
        BSS["BlueprintSetupState.add_url_rule()"]
    end

    subgraph Ctx["contexts"]
        APPCTX["AppContext"]
    end

    BP -- "extends" --> SB
    BP -- "instantiates self.cli" --> AG
    AG -- "wraps callbacks" --> WAC
    WAC -- "pushes" --> APPCTX
    BP -- "send_static_file()" --> SFD
    BP -- "get_send_file_max_age()<br/>(via current_app)" --> CFG
    SB -- "mounts static route /<br/>attaches cli group" --> BSS
    FG -- "loads app incl. blueprints" --> SB
```

Dependency details:

- **`flask.cli.AppGroup`** — a `click.Group` whose `command()` decorator automatically wraps callbacks in `with_appcontext` (disable with `with_appcontext=False`). This means every blueprint CLI command runs with a live [application context](contexts.md), giving access to `current_app`, `g`, config, etc. Sub-groups created via `group()` default to `AppGroup` too. See [command-line-interface](command-line-interface.md) for the surrounding `FlaskGroup`/`ScriptInfo` machinery that discovers the app.
- **`flask.helpers.send_from_directory`** — secure directory-scoped file delivery; it guards against path traversal with Werkzeug's `safe_join` and raises 404 for missing files. Documented in [helpers](helpers.md).
- **`current_app.config["SEND_FILE_MAX_AGE_DEFAULT"]`** — read at request time via the [configuration](configuration.md) module; `None` (the default) signals "use conditional requests rather than a timed cache".
- **`flask.globals.current_app`** — `get_send_file_max_age` resolves configuration through the runtime app context rather than through `self`, which is why this method cannot be implemented in the sansio layer.

## 5. Integration with Registration (Runtime Wiring)

The members defined here are wired into the application by the sansio `register()` method (documented in detail in [blueprints_registration_machinery](blueprints_registration_machinery.md)). Two wiring points belong to this module's capabilities:

```mermaid
flowchart TD
    A["app.register_blueprint(bp)"] --> B["Blueprint.register(app, options)<br/>(sansio layer)"]
    B --> C{"bp.has_static_folder?"}
    C -- "yes" --> D["state.add_url_rule(<br/>'{static_url_path}/<path:filename>',<br/>endpoint='static',<br/>view_func=bp.send_static_file)"]
    C -- "no" --> E
    D --> E{"len(bp.cli.commands) > 0?"}
    E -- "no" --> Z["done"]
    E -- "yes" --> F{"resolved cli_group"}
    F -- "None" --> G["merge: app.cli.commands.update(bp.cli.commands)<br/>(commands appear flat)"]
    F -- "_sentinel (default)" --> H["bp.cli.name = full dotted bp name<br/>app.cli.add_command(bp.cli)<br/>(nested group)"]
    F -- "explicit string" --> I["bp.cli.name = cli_group<br/>app.cli.add_command(bp.cli)"]
    G --> Z
    H --> Z
    I --> Z
```

- **Static route**: registered **only if** a `static_folder` was configured. The endpoint is scoped as `"<blueprint-name>.static"`. Because `Scaffold.static_url_path` derives from the `static_folder` basename when unset, a blueprint **without a `url_prefix`** can have its static URL swallowed by the app's own `/static` route — set `url_prefix` or an explicit `static_url_path` to avoid this.
- **CLI group**: mounted only if the blueprint actually has commands. The `cli_group` constructor argument (or the `cli_group=` option at registration time) decides between a *flat merge*, a *nested group named after the dotted blueprint name* (default), or a *nested group with a custom name*.
- The `record_once` deferred pattern is used by the sansio template/filter/global registration methods so those run exactly once, at first registration.

## 6. Request-Time Data Flow: Static Files

```mermaid
sequenceDiagram
    autonumber
    participant C as Client
    participant RT as Werkzeug Router
    participant V as Blueprint.send_static_file
    participant CA as current_app.config
    participant SFD as send_from_directory (helpers)
    C->>RT: GET /{bp-static-url-path}/path/file.css
    RT->>V: dispatch, endpoint "<name>.static"
    V->>V: has_static_folder? (RuntimeError if not)
    V->>CA: SEND_FILE_MAX_AGE_DEFAULT
    CA-->>V: None | int | timedelta
    Note over V: get_send_file_max_age()<br/>timedelta → int(total_seconds)
    V->>SFD: send_from_directory(static_folder,<br/>filename, max_age)
    alt path escapes folder or file missing
        SFD-->>C: 404 NotFound (safe_join guard)
    else valid regular file
        SFD-->>C: 200 + Cache-Control/ETag headers
    end
```

Design note encoded in the code comments: `send_file` only consults the *app* for `max_age`, so `send_static_file` explicitly calls `self.get_send_file_max_age(filename)` first and passes the resolved value down.

## 7. Component Reference

### `Blueprint.__init__(name, import_name, static_folder=None, static_url_path=None, template_folder=None, url_prefix=None, subdomain=None, url_defaults=None, root_path=None, cli_group=_sentinel)`

Delegates all parameter handling to `SansioBlueprint.__init__` (validation of empty/dotted names, root-path discovery, deferred-function list — see [blueprints_registration_machinery](blueprints_registration_machinery.md)), then performs this module's two additions:

1. Creates `self.cli = AppGroup()` and sets `self.cli.name = self.name` (the comment in the code notes this keeps the group usable when adding the app's commands to another CLI tool).
2. Retains `cli_group` for the registration-time resolution shown in §5.

### `Blueprint.get_send_file_max_age(filename) -> int | None`

- Reads `SEND_FILE_MAX_AGE_DEFAULT` from `current_app.config`.
- `None` → returns `None` (browser falls back to conditional requests — usually preferable).
- `datetime.timedelta` → converted to whole seconds (`int`).
- Any other value returned as-is.
- Requires an active [app context](contexts.md); raises outside one.

### `Blueprint.send_static_file(filename) -> Response`

- Raises `RuntimeError` if `static_folder` is not configured.
- Resolves cache policy via `get_send_file_max_age`, then delegates to `send_from_directory(self.static_folder, filename, max_age=max_age)` for secure delivery.
- Installed as the view of the auto-registered `static` endpoint (§5). This is the blueprint-scoped twin of `Flask.send_static_file` in [application-core](application-core.md).

### `Blueprint.open_resource(resource, mode="rb", encoding="utf-8") -> IO`

- Opens files **for reading only** relative to the blueprint's `root_path`; modes `{"r", "rt", "rb"}` are accepted, anything else raises `ValueError("Resources can only be opened for reading.")`.
- Binary mode (`"rb"`, the default) bypasses encoding; text modes honor `encoding` (added in 3.1).
- Intended for data files bundled inside the blueprint package (schemas, seeds, prompt templates, etc.).

## 8. Usage Patterns

```python
from flask import Blueprint

bp = Blueprint("admin", __name__, url_prefix="/admin",
               static_folder="static", template_folder="templates")

# Static files: served automatically at /admin/static/<path:filename>
# Cache-Control driven by app.config["SEND_FILE_MAX_AGE_DEFAULT"]

@bp.cli.command("reindex")              # runs inside with_appcontext
def reindex():
    from flask import current_app
    current_app.logger.info("reindexing…")

# Package resource (read-only)
with bp.open_resource("data/schema.sql") as f:
    schema = f.read()

app.register_blueprint(bp)   # mounts static route + registers CLI group "admin"
```

Resulting CLI surface: `flask admin reindex` (nested group, default behavior).

## 9. Testing & Related Modules

- [blueprints_test_suite](blueprints_test_suite.md) — behavior of static templates/folders, callback order, nesting (`test_templates_and_static`, `test_default_static_max_age`, `test_nesting_url_prefixes`).
- [blueprints_registration_machinery](blueprints_registration_machinery.md) — the `register()`/`record()`/`BlueprintSetupState` machinery this module builds upon; covers blueprint renaming, dotted names, and unique-name validation.
- [command-line-interface](command-line-interface.md) — `FlaskGroup`, `ScriptInfo`, `with_appcontext`, and `test_cli_blueprints`.
- [helpers](helpers.md) — `send_from_directory`, `send_file`, and `test_open_resource` / `TestSendfile` coverage.
- [application-core](application-core.md) — the `Flask` class whose `send_static_file` / `get_send_file_max_age` / `open_resource` this class mirrors.
- [configuration](configuration.md) — `Config` loading and `SEND_FILE_MAX_AGE_DEFAULT` semantics.
- [contexts](contexts.md) — the app/request contexts that `AppGroup` commands and `current_app` depend on.
- [templating](templating.md) — how blueprint `template_folder` and `jinja_loader` feed the app's `DispatchingJinjaLoader` search path.

## 10. Design Notes

1. **Sansio split** — Everything not requiring runtime app state (deferral, recording, registration) lives in `flask.sansio.blueprints`; this module holds only what needs `current_app`/Click. This keeps the sansio layer reusable for alternative async/sync front-ends.
2. **Eager CLI group, lazy mounting** — `AppGroup` is created at blueprint construction so command decorators work at import time; actual attachment to `app.cli` happens once, during `register()`.
3. **Security posture** — file serving goes exclusively through `send_from_directory` (traversal-safe, 404 on miss), and `open_resource` is hard-limited to read-only modes.
4. **Cache-policy convention** — `None` max-age means conditional-request caching instead of a fixed TTL; `timedelta` values are normalized to integer seconds so `Cache-Control` headers are always well-formed.
