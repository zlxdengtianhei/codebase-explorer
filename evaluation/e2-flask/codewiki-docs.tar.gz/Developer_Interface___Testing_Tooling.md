# Developer Interface & Testing Tooling

## Purpose

The `Developer_Interface___Testing_Tooling` module groups everything a Flask developer touches outside of application code: the **command-line interface** used to run, discover, and manage Flask apps, and the **testing support** utilities used to exercise apps and CLI commands without a live server. It also contains the project's **test infrastructure** — the `tests/` suite that verifies the framework's own behavior. Together, these components form the primary feedback loop between the developer and a Flask application.

## Architecture

The module consists of three components. `cli.py` provides the Click-based `flask` command group; `testing.py` layers Flask-aware subclasses on top of Werkzeug/Click test primitives; and `tests/` hosts the conftest fixtures and test modules that exercise both.

```mermaid
flowchart LR
    subgraph CLI["command-line-interface — src/flask/cli.py"]
        EC[Environment Config<br/>FLASK_APP, dotenv] --> AD[App Discovery<br/>module / factory detection]
        AD --> CF[CLI Framework<br/>Click group, AppGroup, ScriptInfo,<br/>with_appcontext]
        CF --> BC[Built-in Commands<br/>run, shell, routes, ...]
    end

    subgraph TS["testing-support — src/flask/testing.py"]
        TC[FlaskClient<br/>Werkzeug test client subclass]
        CR[FlaskCliRunner<br/>Click CliRunner subclass]
    end

    TI["test-infrastructure — tests/<br/>fixtures + test modules"]

    CR -. invokes commands through .-> CF
    TC -. sends requests to .-> WSGI[Flask App / WSGI callable]
    TI -. exercises .-> CLI
    TI -. exercises .-> TS
```

### Runtime interaction

The two developer entry points converge on the loaded application: the CLI resolves the app via discovery machinery before running any command, while `FlaskClient` dispatches simulated requests straight into the WSGI app — pushing the usual request/app contexts (see `Request_Services___Response_Rendering` and `Core_Application_Engine___Modular_Composition`) just like a real server would.

```mermaid
sequenceDiagram
    participant Dev as Developer / Test code
    participant FC as FlaskClient
    participant App as Flask App (WSGI)
    participant Ctx as Request / App Contexts
    Dev->>FC: client.get("/path")
    FC->>App: open() via Werkzeug test client
    App->>Ctx: push request & app context
    Ctx-->>App: dispatch to view
    App-->>FC: Response
    FC-->>Dev: Response (with context preservation / cookies)
```

## Core Components

| Component | Location | Documentation |
|---|---|---|
| Command-Line Interface | `src/flask/cli.py` | [command-line-interface](command-line-interface.md) — app discovery, the Click-based CLI framework, built-in commands, environment configuration, and its test suite. |
| Testing Support | `src/flask/testing.py` | [testing-support](testing-support.md) — `FlaskClient` for HTTP-level testing, `FlaskCliRunner` for CLI testing, and related test coverage. |
| Test Infrastructure | `tests/` | [test-infrastructure](test-infrastructure.md) — shared fixtures, conftest setup, and the organization of the framework's own test suite. |