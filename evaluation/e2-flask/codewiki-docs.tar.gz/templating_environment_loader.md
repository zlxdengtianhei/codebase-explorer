# templating_environment_loader

## Introduction

The **`templating_environment_loader`** module implements the bridge between Flask applications and Jinja2's template loading machinery. It provides two tightly coupled components in `src/flask/templating.py`:

| Component | Base class | Responsibility |
|---|---|---|
| `Environment` | `jinja2.Environment` | Flask-aware Jinja environment; binds itself to an app and installs the global template loader |
| `DispatchingJinjaLoader` | `jinja2.BaseLoader` | Resolves template names across the **application** and **all registered blueprints**, with optional diagnostic tracing |

Together they answer two fundamental questions for every `render_template()` call:

1. *Which Jinja environment* should compile and execute the template? (created lazily, configured by `jinja_options`, autoescaping, and auto-reload settings)
2. *Where* does the template file live when an app and multiple blueprints each own their own `templates/` folder?

> **Scope note:** This module only covers environment creation and template *lookup*. The rendering pipeline itself (context processors, signals, `render_template` / `stream_template`) is documented in [templating](templating.md) and [templating_rendering_context](templating_rendering_context.md). Registering custom filters/tests/globals is covered in [templating_customization](templating_customization.md).

---

## Core Components

### `Environment`

```python
class Environment(BaseEnvironment):
    def __init__(self, app: App, **options: t.Any) -> None:
        if "loader" not in options:
            options["loader"] = app.create_global_jinja_loader()
        BaseEnvironment.__init__(self, **options)
        self.app = app
```

- Extends `jinja2.Environment` with "knowledge of how Flask's blueprint works".
- **Loader injection:** if the caller does not pass a `loader` option, the default global loader — a `DispatchingJinjaLoader` created by `app.create_global_jinja_loader()` — is installed automatically.
- **Back-reference:** stores the owning application on `self.app`, so tooling and extensions can navigate from the environment back to `current_app`.
- **Replaceable:** `App.jinja_environment` is a class attribute pointing to `Environment`. Subclassing it and assigning the subclass to a `Flask` subclass swaps the environment for every instance (verified by `test_custom_jinja_env`).

### `DispatchingJinjaLoader`

A `jinja2.BaseLoader` that multiplexes template lookups over every `Scaffold`-derived object (the app plus all blueprints). Its API surface:

| Method | Behavior |
|---|---|
| `get_source(environment, template)` | Entry point. Delegates to `_get_source_explained` when `config["EXPLAIN_TEMPLATE_LOADING"]` is truthy, otherwise to `_get_source_fast`. Returns the Jinja loader triple `(source, filename, uptodate_callable)` or raises `jinja2.TemplateNotFound`. |
| `_get_source_fast(...)` | Iterates `_iter_loaders()` and returns on the **first** loader that finds the template; `TemplateNotFound` from one loader is swallowed and the next loader is tried. This is the production hot path. |
| `_get_source_explained(...)` | Queries **every** loader, collecting per-loader results, then forwards the attempt list to `explain_template_loading_attempts()` in `debughelpers` for a detailed log report. Returns the first successful result or raises `TemplateNotFound`. Importantly it never short-circuits: even after a match is found it keeps probing the remaining loaders so the diagnostic report is complete. |
| `_iter_loaders(template)` | Yields `(scaffold, loader)` pairs: first `(app, app.jinja_loader)` if present, then `(blueprint, blueprint.jinja_loader)` for each blueprint from `app.iter_blueprints()` (registration order). |
| `list_templates()` | Unions `list_templates()` of all available loaders into a `set` and returns the deduplicated list. Because it uses a set, ordering is not guaranteed. |

Where the per-object loaders come from — `Scaffold.jinja_loader` (shared by `Flask` and `Blueprint`) is a cached property that returns a `jinja2.FileSystemLoader` rooted at `os.path.join(root_path, template_folder)` when a `template_folder` was configured, and `None` otherwise. Loaders that are `None` are simply skipped by the dispatcher.

---

## Architecture and Component Relationships

```mermaid
graph TD
    subgraph MOD["templating_environment_loader (src/flask/templating.py)"]
        ENV["Environment<br/>(jinja2.Environment subclass)"]
        DJL["DispatchingJinjaLoader<br/>(jinja2.BaseLoader subclass)"]
    end

    subgraph APPCORE["application-core"]
        FLASK["Flask / App"]
        SCAFFOLD["Scaffold<br/>(sansio/scaffold.py)"]
        BLUEPRINT["Blueprint<br/>(blueprints.py)"]
        DEBUGH["explain_template_loading_attempts<br/>(debughelpers.py)"]
    end

    JINJA2["jinja2 library<br/>(BaseEnvironment / BaseLoader / FileSystemLoader)"]

    FLASK -- "class attr: jinja_environment = Environment" --> ENV
    ENV -- "self.app back-reference" --> FLASK
    FLASK -- "create_global_jinja_loader()" --> DJL
    ENV -- "default options['loader']" --> DJL
    DJL -- "reads app.jinja_loader" --> SCAFFOLD
    DJL -- "reads bp.jinja_loader via iter_blueprints()" --> BLUEPRINT
    BLUEPRINT -- "inherits jinja_loader property" --> SCAFFOLD
    SCAFFOLD -- "FileSystemLoader(root_path/template_folder)" --> JINJA2
    ENV -- "extends" --> JINJA2
    DJL -- "imports on demand for diagnostics" --> DEBUGH
    DEBUGH -- "app.logger.info(report)" --> FLASK
```

Key relationships:

- **Ownership is one-directional:** the app owns the environment (via `app.jinja_env`), the environment owns the dispatcher (its loader), and the dispatcher reads loaders from the app and its blueprints. Blueprints never own or share the environment itself — they only contribute loaders.
- **Late binding:** `debughelpers.explain_template_loading_attempts` is imported *inside* `_get_source_explained`, keeping the loader free of a static dependency on the debug module. See [application-core_debug-helpers](application-core_debug-helpers.md).
- **Blueprint awareness without coupling:** the dispatcher only relies on the `Scaffold` interface (`jinja_loader`) and `app.iter_blueprints()`, so nested blueprint hierarchies work transparently. Registration mechanics are described in [blueprints](blueprints.md).

---

## Environment Creation Flow

`app.jinja_env` is a cached property: the environment is constructed **once, lazily**, on first access (typically the first `render_template` call or the first `add_template_filter` call — both filter/test/global registration helpers touch `jinja_env` immediately). Changing `jinja_options` after that first access has no effect.

```mermaid
flowchart TD
    A["First access to app.jinja_env"] --> B["Flask.create_jinja_environment()"]
    B --> C["copy app.jinja_options"]
    C --> D{"'autoescape' in options?"}
    D -- "no" --> E["autoescape = app.select_jinja_autoescape<br/>(on for .html/.htm/.xml/.xhtml/.svg)"]
    D -- "yes" --> F["keep caller value"]
    C --> G{"'auto_reload' in options?"}
    G -- "no" --> H{"config TEMPLATES_AUTO_RELOAD set?"}
    H -- "not None" --> I["auto_reload = config value"]
    H -- "None" --> J["auto_reload = app.debug"]
    G -- "yes" --> K["keep caller value"]
    E --> L["jinja_environment(self, **options)<br/>i.e. Environment(app, ...)"]
    I --> L
    J --> L
    K --> L
    L --> M{"'loader' in options?"}
    M -- "no" --> N["options['loader'] =<br/>app.create_global_jinja_loader()"]
    N --> O["DispatchingJinjaLoader(app)"]
    M -- "yes" --> P["caller-supplied loader"]
    O --> Q["BaseEnvironment.__init__(**options)"]
    P --> Q
    Q --> R["env.app = app"]
    R --> S["env.globals += url_for, get_flashed_messages,<br/>config, request, session, g"]
    S --> T["env.policies['json.dumps_function'] = app.json.dumps"]
```

Additional runtime nuance: the `App.debug` property setter also touches `jinja_env.auto_reload` — if `TEMPLATES_AUTO_RELOAD` is still `None` at the moment debug mode is toggled, the environment's auto-reload flag is updated to the new debug value. This is why `test_templates_auto_reload_debug_run` observes auto-reload flipping after `app.run(debug=True)`.

### Auto-reload decision matrix

| `DEBUG` | `TEMPLATES_AUTO_RELOAD` | `jinja_env.auto_reload` |
|---|---|---|
| `False` | `None` (default) | `False` |
| `False` | `False` | `False` |
| `False` | `True` | `True` |
| `True` | `None` (default) | `True` |
| `True` | `False` | `False` (explicit config wins over debug) |
| `True` | `True` | `True` |

Both `TEMPLATES_AUTO_RELOAD` and `EXPLAIN_TEMPLATE_LOADING` are ordinary config keys; loading them from files/environment variables is covered by [configuration](configuration.md).

---

## Template Lookup Flow

The sequence below shows what happens when rendering code (e.g. `render_template(["a.html", "b.html"])`) asks the environment for a template.

```mermaid
sequenceDiagram
    autonumber
    participant V as View / render_template
    participant E as Environment (jinja_env)
    participant D as DispatchingJinjaLoader
    participant AL as App loader (Scaffold.jinja_loader)
    participant BL as Blueprint loaders
    participant X as debughelpers

    V->>E: get_or_select_template(name_or_list)
    Note over E: For a list, first template that exists wins<br/>(test_iterable_loader)
    E->>D: get_source(environment, template)
    alt EXPLAIN_TEMPLATE_LOADING enabled
        D->>AL: get_source(...) → record attempt
        D->>BL: get_source(...) → record attempts (every loader, no short-circuit)
        D->>X: explain_template_loading_attempts(app, template, attempts)
        X->>X: app.logger.info("Locating template ... 1: trying loader of application ...")
    else Default fast path
        D->>D: _get_source_fast(template)
        loop _iter_loaders: app first, then blueprints in registration order
            D->>AL: get_source(...)
            AL-->>D: triple (source, path, uptodate) — return immediately
            Note over D: TemplateNotFound → try next loader
        end
    end
    D-->>E: triple or TemplateNotFound
    E-->>V: compiled Template (rendered by the pipeline in templating_rendering_context)
```

### Search-order semantics

1. **Application templates first** — `app.jinja_loader` (`templates/` next to the app package by default).
2. **Blueprint templates next**, in the order the blueprints were registered with `register_blueprint()`.
3. **First match wins** on the fast path; because blueprint names never prefix template names in the loader (unlike endpoints), a template named `form.html` in both the app and a blueprint resolves to the app's copy. The recommended convention to avoid shadowing is blueprint-specific subfolders (see the linked guidance emitted by the diagnostics reporter).
4. If nothing matches, `TemplateNotFound` propagates from Jinja and surfaces as a 500 through standard error handling (see [application-core](application-core.md)).

### Diagnostics: `EXPLAIN_TEMPLATE_LOADING`

Setting `app.config["EXPLAIN_TEMPLATE_LOADING"] = True` switches the dispatcher to the "explained" path, which produces a log record on `app.logger` describing, for each loader tried: the owning object (`application 'name'` / `blueprint 'name' (import_name)`), a dump of the loader's configuration, and the outcome (`found ('path')` / `no match`). When the search fails or is ambiguous, and the lookup originated from a blueprint endpoint, the report adds actionable hints including a link to the blueprint-templates documentation. `test_template_loader_debugging` asserts the exact shape of this report end-to-end through the test client, raising `TemplateNotFound("missing_template.html")` after the log is emitted.

---

## Extension and Customization Points

Flask deliberately exposes three seams in this layer:

1. **Swap the whole environment** — subclass `flask.templating.Environment` and set it as `jinja_environment` on a `Flask` subclass. The subclass receives the app as its first constructor argument and inherits the automatic loader injection.

    ```python
    class CustomEnvironment(flask.templating.Environment):
        ...

    class CustomFlask(flask.Flask):
        jinja_environment = CustomEnvironment
    ```

2. **Replace the global loader** — override `create_global_jinja_loader()` on a `Flask` subclass to return any `jinja2.BaseLoader` (e.g. a `DictLoader`). The environment will pass it to Jinja unchanged. `test_custom_template_loader` demonstrates this by serving every `index.html` request from an in-memory dictionary. The upstream docstring discourages this in favor of option 3, but it remains a supported hook.

3. **Per-object template folders** — the most common approach: pass `template_folder=` to `Flask(...)` / `Blueprint(...)` (or rely on the `"templates"` default for apps). Each `Scaffold` derives its own `FileSystemLoader` and the dispatcher stitches them together. This is how app/blueprint template isolation works, and it is the mechanism the loader-diagnostics tooling reasons about.

Options 1 and 3 compose: a custom environment still gets the dispatching loader unless the subclass explicitly passes its own `loader=` option to `super().__init__`.

---

## Interaction with the Rest of the System

```mermaid
flowchart LR
    subgraph CONTEXT["contexts"]
        CTX["RequestContext / AppContext<br/>(request, session, g proxies)"]
    end
    subgraph THIS["templating_environment_loader"]
        ENV2["Environment"]
        LOAD["DispatchingJinjaLoader"]
    end
    subgraph RENDER["templating_rendering_context"]
        RT["render_template / stream_template"]
    end
    subgraph CUSTOM["templating_customization"]
        FL["filters / tests / globals"]
    end
    BP2["Blueprints (blueprints)"] -- "iter_blueprints()" --> LOAD
    RT -- "app.jinja_env.get_or_select_template()" --> ENV2
    ENV2 -- "delegates lookup" --> LOAD
    FL -- "register via jinja_env.* at import time<br/>(triggers env creation)" --> ENV2
    CTX -. "context injected at render time,<br/>not by the loader" .-> RT
```

- **Lazy creation timing matters:** `add_template_filter` / `add_template_test` / `add_template_global` write directly into `app.jinja_env.*`, so *any* of these registrations — not just rendering — materializes the environment. After the first request, `_check_setup_finished` blocks further setup-method calls, but direct `jinja_env` mutation remains possible (discouraged).
- **Context vs. source separation:** the loader only supplies template *source*. Runtime variables (`request`, `session`, `g`, `config`, context-processor values) are injected by the rendering pipeline via `app.update_template_context`, not during loading. Context plumbing is detailed in [contexts](contexts.md) and [templating_rendering_context](templating_rendering_context.md).
- **`list_templates()`** is what backs tooling that enumerates available templates; note its set-based deduplication means results are unordered and app/blueprint duplicates collapse to one entry.

---

## Testing Coverage

The behavior of this module is pinned by six focused tests in `tests/test_templating.py`:

| Test | What it verifies |
|---|---|
| `test_custom_jinja_env` | Subclassing `Environment` and installing it via `Flask.jinja_environment`; `app.jinja_env` is an instance of the custom class. |
| `test_custom_template_loader` | Overriding `create_global_jinja_loader()` with a `DictLoader`; rendering bypasses the filesystem entirely. |
| `test_iterable_loader` | `get_or_select_template` with a candidate list — the first *existing* template in the list is rendered, earlier missing names are skipped. |
| `test_templates_auto_reload` | Full matrix of `DEBUG` × `TEMPLATES_AUTO_RELOAD` combinations and the resulting `jinja_env.auto_reload`. |
| `test_templates_auto_reload_debug_run` | `app.run(debug=True)` (with `run_simple` mocked) flips `auto_reload` on; a plain `app.run()` leaves it off. |
| `test_template_loader_debugging` | `EXPLAIN_TEMPLATE_LOADING` produces the full multi-loader diagnostic report (app + `admin` + `frontend` blueprint loaders from the `blueprintapp` test app) and raises `TemplateNotFound` for the missing template. |

Related integration tests live in the sibling module docs: [blueprints_test_suite](blueprints.md) exercises `test_templates_and_static` / `test_templates_list` (per-blueprint loader wiring), and the shared fixtures (`app`, `app_ctx`, `req_ctx`, `test_apps`) are provided by the [test-infrastructure](application-core_test-suite.md) layer.

---

## Summary

`templating_environment_loader` is the mechanism that makes Flask's "templates folder per package" convention work under a single Jinja environment. `Environment` lazily binds a Flask app to Jinja with sensible defaults (autoescaping, auto-reload tied to debug/config) and a blueprint-aware default loader; `DispatchingJinjaLoader` implements a deterministic app-first, blueprint-ordered search over per-package `FileSystemLoader`s, with an opt-in tracing mode for debugging "template not found" problems. Both components are designed to be replaced — via `jinja_environment`, `create_global_jinja_loader()`, or plain `template_folder` configuration — making this one of Flask's most extensible seams.
