# Tagged JSON Serializer (`flask.json.tag`)

## 1. Overview

The **json-serialization_tag** module implements Flask's **Tagged JSON** scheme: a compact, **lossless**, and **extensible** serialization format for Python objects that have no native JSON representation (`tuple`, `bytes`, `uuid.UUID`, `datetime.datetime`, `markupsafe.Markup`, …). The companion HTTP-facing provider ([json-serialization_provider](json-serialization_provider.md)) converts exotic types *one-way* into plain JSON values, permanently losing their type. This module instead wraps such values in **single-key tagged dicts** — e.g. `(1, 2, 3)` becomes `{" t": [1, 2, 3]}` — so that deserialization can reconstruct the **exact original type**.

| Capability | Implementation |
|---|---|
| Tag protocol (check / to_json / to_python) | `JSONTag` abstract base class |
| 8 built-in type tags | `TagDict`, `PassDict`, `TagTuple`, `PassList`, `TagBytes`, `TagMarkup`, `TagUUID`, `TagDateTime` |
| Tag registry, ordering, and recursion | `TaggedJSONSerializer` |
| Primary consumer | `session_json_serializer` → `SecureCookieSessionInterface` → itsdangerous signed cookies (see [sessions.md](sessions.md)) |

The module lives in `src/flask/json/tag.py`; its behavioral contract is pinned by `tests/test_json_tag.py`. It is the "storage-facing" half of the JSON subsystem described in the parent [json-serialization](json-serialization.md) documentation.

---

## 2. Core Components

### 2.1 `JSONTag` — the tag protocol

```python
class JSONTag:
    __slots__ = ("serializer",)
    key: str = ""          # tag marker; "" = intermediate/restructuring tag only

    def __init__(self, serializer: TaggedJSONSerializer) -> None: ...
    def check(self, value: t.Any) -> bool: ...      # does this tag apply?
    def to_json(self, value: t.Any) -> t.Any: ...   # Python -> JSON-safe value
    def to_python(self, value: t.Any) -> t.Any: ... # tagged JSON -> Python
    def tag(self, value: t.Any) -> dict[str, t.Any]:
        return {self.key: self.to_json(value)}      # wrap in the tag structure
```

Design points:

- **Four-method contract.** Subclasses implement `check`, `to_json`, `to_python`; `tag` is the shared template method that wraps the converted value in the `{key: ...}` envelope. `test_tag_interface` asserts that the three abstract methods raise `NotImplementedError` on the base class.
- **Serializer back-reference.** Every tag is instantiated *by* the serializer (`tag_class(serializer)`) and holds it in `self.serializer`, so tags can recursively call `self.serializer.tag(...)` on nested values.
- **`__slots__` everywhere.** Both the tags and the serializer define `__slots__` — session data is serialized on every request, so per-instance memory overhead is deliberately minimized.
- **Empty `key` semantics.** Tags with `key = ""` (the `PassDict` / `PassList` pass-throughs) participate only in the *check order*; they never appear in the key → tag registry and never emit a wrapper dict (`tag` is aliased to `to_json`).

### 2.2 Built-in tag catalog

Registration order (which is also the `check` order) is defined by `TaggedJSONSerializer.default_tags`:

| # | Tag class | Key | Matches (`check`) | JSON form (`to_json`) | Restored as (`to_python`) |
|---|---|---|---|---|---|
| 1 | `TagDict` | `" di"` | dict with **exactly one key** that is a registered tag key | `{key + "__": serializer.tag(value)}` (key escaped with `__` suffix) | original dict, suffix stripped |
| 2 | `PassDict` | *(none)* | any `dict` | `{k: serializer.tag(v)}` — values tagged recursively, keys left alone | *(transparent — no wrapper)* |
| 3 | `TagTuple` | `" t"` | `tuple` | `{" t": [tag(item), ...]}` | `tuple` |
| 4 | `PassList` | *(none)* | any `list` | `[tag(item), ...]` | *(transparent)* |
| 5 | `TagBytes` | `" b"` | `bytes` | `{" b": base64 string (ascii)}` | `bytes` |
| 6 | `TagMarkup` | `" m"` | **any object** with a callable `__html__` (duck-typed, e.g. `Markup`) | `{" m": str(value.__html__())}` | `markupsafe.Markup` (always) |
| 7 | `TagUUID` | `" u"` | `uuid.UUID` | `{" u": uuid.hex}` | `UUID` |
| 8 | `TagDateTime` | `" d"` | `datetime.datetime` | `{" d": http_date(dt)}` (RFC 822) | `parse_date(...)` — Werkzeug |

Notes:

- `TagBytes` uses `base64.b64encode(...).decode("ascii")` — the only encoding-safe way to carry binary data through JSON text.
- `TagDateTime` delegates to Werkzeug's `http_date`/`parse_date`; HTTP dates have **second** resolution, which is why the round-trip test normalizes `microsecond=0` before comparing.
- `TagMarkup` is intentionally duck-typed: it matches *anything* exposing `__html__`, but deserialization always yields a `Markup` instance (the original class is not preserved).
- All tag keys start with a **space** (`" t"`, `" di"`, …), making accidental collision with ordinary session keys extremely unlikely; the one case that can still occur (a single-key dict *whose only key is a tag key*) is defused by `TagDict`'s escaping (§4.3).

### 2.3 `TaggedJSONSerializer` — the registry and engine

```python
class TaggedJSONSerializer:
    __slots__ = ("tags", "order")
    default_tags = [TagDict, PassDict, TagTuple, PassList,
                    TagBytes, TagMarkup, TagUUID, TagDateTime]

    def __init__(self):
        self.tags: dict[str, JSONTag] = {}   # tag key -> bound tag instance
        self.order: list[JSONTag] = []       # check sequence (first match wins)

    def register(tag_class, force=False, index=None) -> None
    def tag(value) -> t.Any                  # Python -> tagged, JSON-safe structure
    def untag(value: dict) -> t.Any          # single tagged node -> Python
    def _untag_scan(value) -> t.Any          # recursive untagging walk (private)
    def dumps(value) -> str                  # tag + compact JSON
    def loads(value) -> t.Any                # parse + recursive untag
```

**Registration machinery (`register`):**

- Instantiates the tag bound to this serializer; all tags (keyed or not) are inserted into `self.order`.
- Keyed tags are also stored in `self.tags`; a duplicate key raises `KeyError` unless `force=True` (which overwrites the registry entry).
- `index=None` appends to the end of the check order; any other value performs `list.insert(index, tag)` — negative indices are valid (`index=-1` inserts *before* the last tag). Ordering matters because checks are `isinstance`/duck-type predicates and more specific tags must be tested first (e.g. `TagDict` before `PassDict`).

**Dispatch (`tag`):** iterates `self.order` and applies the **first** tag whose `check(value)` is `True`; values matching no tag pass through unchanged (ints, strings, bools, `None`).

**Undo (`untag` / `_untag_scan`):** a value is considered "tagged" only if it is a dict with **exactly one key** that is present in `self.tags`; in that case `to_python` is called. `_untag_scan` walks the parsed structure — untagging every dict item recursively, *then* the dict itself, and recursing through lists — so tags nested arbitrarily deep are restored.

---

## 3. Architecture

### 3.1 Class structure

```mermaid
classDiagram
    direction TB

    class TaggedJSONSerializer {
        +dict~str, JSONTag~ tags
        +list~JSONTag~ order
        +default_tags : list
        +register(tag_class, force, index)
        +tag(value) Any
        +untag(value) Any
        -_untag_scan(value) Any
        +dumps(value) str
        +loads(value) Any
    }

    class JSONTag {
        <<abstract>>
        +str key
        +TaggedJSONSerializer serializer
        +check(value) bool
        +to_json(value) Any
        +to_python(value) Any
        +tag(value) dict
    }

    class TagDict {
        key = " di"
        escapes key with `__` suffix
    }
    class PassDict {
        key = "" — transparent
        tag = to_json
    }
    class TagTuple {
        key = " t"
    }
    class PassList {
        key = "" — transparent
        tag = to_json
    }
    class TagBytes {
        key = " b" — base64
    }
    class TagMarkup {
        key = " m" — duck-typed __html__
    }
    class TagUUID {
        key = " u" — hex
    }
    class TagDateTime {
        key = " d" — HTTP date
    }

    JSONTag <|-- TagDict
    JSONTag <|-- PassDict
    JSONTag <|-- TagTuple
    JSONTag <|-- PassList
    JSONTag <|-- TagBytes
    JSONTag <|-- TagMarkup
    JSONTag <|-- TagUUID
    JSONTag <|-- TagDateTime

    TaggedJSONSerializer o-- JSONTag : order — check sequence, first match wins
    TaggedJSONSerializer o-- JSONTag : tags — key registry for untagging
    JSONTag --> TaggedJSONSerializer : serializer back-reference for recursion
```

### 3.2 Position in the overall system

```mermaid
graph TD
    subgraph "flask.json.tag (this module)"
        TJS["TaggedJSONSerializer"]
        TAGS["JSONTag + 8 built-in tags"]
        TJS -->|"default_tags registered in __init__"| TAGS
    end

    subgraph "flask.json"
        FDUMPS["dumps() / loads()"]
        PROVIDER["app.json — JSONProvider<br/>(json-serialization_provider)"]
        FDUMPS -->|"delegates when app context active"| PROVIDER
    end

    subgraph "flask.sessions (sessions)"
        SJI["session_json_serializer<br/>= TaggedJSONSerializer()"]
        SCSSI["SecureCookieSessionInterface<br/>.serializer = session_json_serializer"]
        SJI --> SCSSI
    end

    ITSD["itsdangerous.URLSafeTimedSerializer<br/>(signing / timestamping)"]
    COOKIE[("Signed session cookie")]

    SCSSI -->|"get_signing_serializer(...)"| ITSD
    ITSD -->|"intermediate serializer.dumps / .loads"| TJS
    TJS -->|"dumps / loads"| FDUMPS
    ITSD --> COOKIE
```

The serializer depends on the **provider** only indirectly: `dumps`/`loads` in `tag.py` are `flask.json.dumps`/`flask.json.loads`, which route through `current_app.json` (the `JSONProvider`) when an application context is active, and fall back to the stdlib `_default` converter otherwise. Consequently, provider settings such as `ensure_ascii`/`sort_keys` affect tagged output produced inside an app context.

---

## 4. Serialization Pipeline

### 4.1 Write path (`dumps`)

```mermaid
flowchart TD
    A["TaggedJSONSerializer.dumps(value)"] --> B["tag(value)"]
    B --> C{"next tag in order:<br/>tag.check(value)?"}
    C -- "match" --> D["tag.tag(value)<br/>= {key: to_json(value)}<br/>to_json recurses into children<br/>via self.serializer.tag(...)"]
    C -- "no match" --> E["value unchanged<br/>(int, str, bool, None)"]
    D --> F["flask.json.dumps(obj, separators=(',', ':'))<br/>compact JSON string"]
    E --> F
    F --> G["itsdangerous: compress + sign<br/>→ cookie / storage payload"]
```

- Tagging is **one dispatch at the top** plus **recursive tagging of children** performed inside the container tags' `to_json` implementations (`TagDict`, `PassDict`, `TagTuple`, `PassList`).
- Dict **keys are never tagged** — JSON objects require string keys — only values are.
- Output is deliberately **compact** (`separators=(",", ":")`) because the result is destined for size-limited storage (cookies), not for humans.

### 4.2 Read path (`loads`)

```mermaid
flowchart TD
    A["TaggedJSONSerializer.loads(value)"] --> B["flask.json.loads → parsed structure"]
    B --> C["_untag_scan(parsed)"]
    C --> D{"dict?"}
    D -- "yes" --> E["untag each value recursively"]
    E --> F["untag(dict itself):<br/>len == 1 AND key in self.tags<br/>? tag.to_python(value[key])<br/>: return as-is"]
    D -- "no" --> G{"list?"}
    G -- "yes" --> H["scan each item recursively"]
    G -- "no" --> I["return as-is (scalar)"]
    F --> J["Python structure with<br/>original types restored"]
    H --> J
    I --> J
```

### 4.3 Ambiguity handling — the `__` escaping

A single-key dict whose only key *is* a registered tag key (e.g. `{" di": " di"}`) is genuinely ambiguous: without extra care, the untagging walk could not distinguish a *user's* dict from a *tag envelope*. `TagDict` resolves this by renaming the offending key with a `__` suffix during `to_json`, which prevents the reconstructed inner dict from being mistaken for a tag envelope on the way back:

| Step | Value |
|---|---|
| Original (user data) | `{" di": " di"}` |
| `tag()` — `TagDict` matches (len 1, `" di"` ∈ tags) | `{" di": {" di__": " di"}}` |
| JSON on the wire (compact) | `{" di":{" di__":" di"}}` |
| `loads()` scan — inner `{" di__": ...}`: key `" di__"` ∉ tags → untouched | `{" di__": " di"}` (inner) |
| Outer untag: key `" di"` ∈ tags → `TagDict.to_python` strips `__` | `{" di": " di"}` ✓ |

`tests/test_json_tag.py::test_dump_load_unchanged` pins this behavior with the adversarial payloads `{" t": (1, 2, 3)}`, `{" t__": b"a"}`, and `{" di": " di"}`. Note that multi-key dicts containing tag-like keys (e.g. `{" t": 1, "x": 2}`) need no escaping: `untag` only ever dispatches on *single-key* dicts, so such dicts are returned untouched.

### 4.4 End-to-end session round trip

```mermaid
sequenceDiagram
    participant App as Flask request teardown
    participant SI as SecureCookieSessionInterface
    participant ITS as itsdangerous.URLSafeTimedSerializer
    participant TJS as TaggedJSONSerializer
    participant T as JSONTag implementations
    participant C as Browser cookie

    Note over App,C: save_session — write path
    App->>SI: save_session(app, session, response)
    SI->>ITS: dumps(dict(session))
    ITS->>TJS: dumps(data)
    TJS->>T: tag(value) — first matching tag per node
    T-->>TJS: tagged, JSON-safe structure
    TJS-->>ITS: compact JSON string
    ITS-->>SI: signed URL-safe token
    SI->>C: response.set_cookie(name, token)

    Note over App,C: open_session — read path
    C->>SI: request cookie value
    SI->>ITS: loads(val, max_age=...)
    ITS->>TJS: loads(json_string)
    TJS->>T: _untag_scan — to_python per tagged node
    T-->>TJS: original Python types restored
    TJS-->>SI: session data dict → SecureCookieSession
```

Confidentiality/integrity is **not** this module's concern — the signing, key derivation (`hmac`, `_lazy_sha1`), and expiry handling live in the session layer ([sessions.md](sessions.md)).

---

## 5. Extending the serializer

New types are supported by subclassing `JSONTag` and registering the class:

```python
from collections import OrderedDict
from flask.json.tag import JSONTag

class TagOrderedDict(JSONTag):
    __slots__ = ()
    key = " od"

    def check(self, value):
        return isinstance(value, OrderedDict)

    def to_json(self, value):
        return [[k, self.serializer.tag(v)] for k, v in value.items()]

    def to_python(self, value):
        return OrderedDict(value)

app.session_interface.serializer.register(TagOrderedDict, index=0)
```

Rules of the extension protocol (exercised by `test_custom_tag` and `test_tag_order`):

1. **Unique key.** Prefer a space-prefixed key (`" od"`) to avoid collisions with user data. Registering a duplicate key raises `KeyError`; pass `force=True` to deliberately replace an existing tag (`test_duplicate_tag`).
2. **Mind the check order.** Checks are `isinstance`-based, so a tag for a *subclass* of an already-tagged type must be checked **first** — `OrderedDict` is a `dict`, hence `index=0` puts it ahead of `TagDict`/`PassDict`. `index=-1` inserts before the last tag; omitting `index` appends.
3. **Recurse through the serializer.** Inside `to_json`, convert nested values with `self.serializer.tag(...)` so inner exotic types are handled too.
4. **Round-trip fidelity in `to_python`.** It receives the converted payload *after the tag envelope has been removed*; `test_dump_load_unchanged` asserts exact equality after a `dumps → loads` cycle.

---

## 6. Testing

`tests/test_json_tag.py` specifies the module's contract:

| Test | Guarantee |
|---|---|
| `test_dump_load_unchanged` | Parametrized round-trip over the tricky cases: tag-keyed dicts (`{" t": (1, 2, 3)}`), pre-escaped keys (`{" t__": b"a"}`), the self-referential `{" di": " di"}`, nested tuples, top-level tuples, tuples inside lists, `bytes`, `Markup`, `UUID`, and tz-aware `datetime` (microsecond-stripped) — all survive `dumps → loads` with exact equality. |
| `test_duplicate_tag` | Re-registering an existing key raises `KeyError`; `force=True, index=0` replaces both the `tags` registry entry and the head of the check `order`. |
| `test_custom_tag` | The documented extension protocol works end-to-end, including `serializer.tag(...)` recursion inside a custom `to_json`. |
| `test_tag_interface` | `JSONTag.check` / `to_json` / `to_python` are abstract — they raise `NotImplementedError`. |
| `test_tag_order` | `register(index=-1)` inserts before the last tag; `register(index=None)` appends to the end. |

---

## 7. Design Notes & Limitations

- **Lossless by design, but not universally.** `TagMarkup` accepts any `__html__` object yet always restores a plain `Markup`; `TagDateTime` loses sub-second precision (HTTP-date resolution). These are conscious trade-offs for session data.
- **`untag` is deliberately conservative** — only single-key dicts with a *registered* key are transformed; everything else (including unrecognized or multi-key dicts) passes through untouched. This makes the format forward-compatible: payloads written by older versions that lack a newer tag are still readable.
- **One format, two consumers.** `dumps`/`loads` reuse `flask.json.dumps`/`loads`, so provider configuration leaks into tagged output only when an app context is active. The provider ([json-serialization_provider](json-serialization_provider.md)) answers *HTTP* JSON concerns (mimetypes, pretty-printing); this module answers *storage* JSON concerns (compactness, type fidelity) — see the parent [json-serialization](json-serialization.md) overview for the split.
- **No standalone security.** The tagged format is plain JSON; tamper protection comes entirely from the itsdangerous signature applied above it in the session layer.
- **First-match dispatch is order-sensitive.** `TaggedJSONSerializer.default_tags` orders `TagDict` before `PassDict` (special case before general case); any custom tag for a subclass of an existing tagged type must respect the same invariant via `index`.
