# Blueprints Test Suite (`blueprints_test_suite`)

## 1. Introduction

`blueprints_test_suite` is the leaf test module of the **blueprints** subsystem inside *Core_Application_Engine — Modular Composition*. It is the behavioral contract for Flask's Blueprint API: it pins down how blueprints are **constructed**, **registered**, **nested**, how they contribute **URLs, endpoints and request callbacks** to an application, and how they provide **templates and static files**.

The module consists of three artifacts:

| Artifact | Role |
| --- | --- |
| `tests/test_blueprints.py` | The main test suite (~45 tests; the 25 tests scoped to this module cover nesting, naming, URL handling, scoped callbacks/error handlers, and resources) |
| `tests/test_apps/blueprintapp/apps/admin/__init__.py` | Fixture blueprint (`admin`) with template **and** static folders, used for integration tests |
| `tests/test_apps/blueprintapp/apps/frontend/__init__.py` | Fixture blueprint (`frontend`) with a template folder, mounted at the application root |

Unlike the machinery modules it depends on — [blueprints_registration_machinery](blueprints_registration_machinery.md) (the sans-io `Blueprint`/`BlueprintSetupState` implementation) and [blueprints_resources_and_cli](blueprints_resources_and_cli.md) (the concrete `Blueprint` with resources and CLI) — this module contains **no production code**. It exists to verify that the deferred-registration machinery produces the runtime behavior users rely on.

---

## 2. Position in the System

```mermaid
graph TB
    subgraph core["Core_Application_Engine — Modular Composition"]
        subgraph bpSub["blueprints subsystem"]
            REG["blueprints_registration_machinery<br/>sansio/Blueprint: deferred functions,<br/>register(), name validation<br/>sansio/BlueprintSetupState: URL &amp;<br/>endpoint namespacing"]
            RES["blueprints_resources_and_cli<br/>flask/blueprints.Blueprint:<br/>static files, open_resource, CLI group"]
            TS["<b>blueprints_test_suite</b><br/>(this module)<br/>tests/test_blueprints.py<br/>tests/test_apps/blueprintapp"]
        end
    end
    TI["test-infrastructure<br/>tests/conftest.py<br/>(app, client, test_apps, app_ctx, req_ctx)"]
    CTX["contexts<br/>AppContext / RequestContext / g"]
    TPL["templating<br/>DispatchingJinjaLoader, Environment"]
    AC["application-core<br/>Flask (url_map, view_functions,<br/>before/after/teardown funcs)"]

    TS -->|"exercises public API"| RES
    RES -->|"extends / delegates to"| REG
    TS -.->|"pytest fixtures"| TI
    TS -.->|"dispatch, g, teardown"| CTX
    TS -.->|"template resolution"| TPL
    TS -.->|"routing &amp; callback registries"| AC
```

Solid arrows are the primary contract under test; dashed arrows are runtime services the tests drive indirectly. For the internals of the registration machinery itself see [blueprints_registration_machinery](blueprints_registration_machinery.md); for the `Flask` application object see [application-core](application-core.md).

---

## 3. Component Inventory

### 3.1 `tests/test_blueprints.py`

Every test follows the same pattern: build one or more `flask.Blueprint` objects, attach views/callbacks/handlers with decorators, register them on the `app` fixture, then assert on observable behavior through the `client` fixture (both from [test-infrastructure](test-infrastructure.md)). Some tests also use `app.test_request_context()` to verify `url_for` behavior.

### 3.2 Fixture application: `blueprintapp`

`tests/test_apps/blueprintapp/__init__.py` creates the integration target imported by the resource tests:

```python
app = Flask(__name__)
app.config["DEBUG"] = True
from blueprintapp.apps.admin import admin
from blueprintapp.apps.frontend import frontend

app.register_blueprint(admin)
app.register_blueprint(frontend)
```

The [test_apps](test-infrastructure.md) conftest fixture prepends `tests/test_apps` to `sys.path` (and scrubs `sys.modules` afterwards) so tests can simply do `from blueprintapp import app`.

**`admin` blueprint** — demonstrates a fully configured, prefixed blueprint:

| Aspect | Value |
| --- | --- |
| Name / prefix | `"admin"`, `url_prefix="/admin"` |
| `template_folder` | `"templates"` → template namespace `admin/` |
| `static_folder` | `"static"` → served at `/admin/static/...` (`test.txt`, `css/test.css`) |
| `index` (`/`) | renders `admin/index.html` → *"Hello from the Admin"* |
| `index2` (`/index2`) | renders `./admin/index.html` — exercises explicit relative-name normalization |

**`frontend` blueprint** — deliberately minimal:

| Aspect | Value |
| --- | --- |
| Name / prefix | `"frontend"`, **no** `url_prefix` → its `/` route serves the application root |
| `template_folder` | `"templates"` → template namespace `frontend/` |
| `index` (`/`) | renders `frontend/index.html` → *"Hello from the Frontend"* |
| `missing_template` (`/missing`) | renders a non-existent template (raises `TemplateNotFound`) |

---

## 4. Test Coverage Map

```mermaid
mindmap
  root(("blueprints_test_suite"))
    Construction validation
      test_dotted_name_not_allowed
      test_empty_name_not_allowed
    Registration and naming
      test_unique_blueprint_names
      test_self_registration
      test_blueprint_renaming
    Nesting
      test_nested_blueprint
      test_nested_callback_order
      test_nesting_url_prefixes
      test_nesting_subdomains
      test_child_and_parent_subdomain
    URL handling
      test_blueprint_prefix_slash
      test_blueprint_url_defaults
      test_blueprint_url_processors
      test_app_url_processors
      test_endpoint_decorator
      test_route_decorator_custom_endpoint
    Scoped error handling
      test_blueprint_specific_error_handling
      test_blueprint_app_error_handling
    Request lifecycle
      test_request_processing
      test_app_request_processing
    Templates and static
      test_context_processing
      test_template_global
      test_templates_and_static
      test_default_static_max_age
      test_templates_list
```

---

## 5. Verified Behaviors in Detail

### 5.1 Construction validation

The sans-io `Blueprint.__init__` (see [blueprints_registration_machinery](blueprints_registration_machinery.md)) rejects invalid names eagerly, *before* any app exists:

| Test | Input | Expected |
| --- | --- | --- |
| `test_dotted_name_not_allowed` | `Blueprint("app.ui", __name__)` | `ValueError` — dots are reserved as the endpoint namespace separator |
| `test_empty_name_not_allowed` | `Blueprint("", __name__)` | `ValueError` — a name is mandatory |

These invariants matter because registration later composes dotted endpoint names (`name.endpoint`, `parent.child.endpoint`); a dotted blueprint name would make `url_for` targets ambiguous.

### 5.2 Registration identity and naming

`Flask.register_blueprint(bp, **options)` → `Blueprint.register(app, options)` enforces identity rules tracked in `app.blueprints` (keyed by registration name):

| Test | Scenario | Result |
| --- | --- | --- |
| `test_unique_blueprint_names` | same object, same name | `ValueError` |
| | same object, `name="again"` | OK (registerable multiple times) |
| | different object, same name | `ValueError` |
| | different object, `name="alt"` | OK |
| `test_self_registration` | `bp.register_blueprint(bp)` | `ValueError` — a blueprint cannot nest inside itself |
| `test_blueprint_renaming` | one `bp` registered at `/a` and again as `name="alt"` at `/b`; nested `bp2` registered with `name="sub"` | Endpoints become `bp.index`, `alt.index`, `bp.sub.index2`, `alt.sub.index2`; the bp-scoped 403 handler works under **both** registrations |

`test_blueprint_renaming` is the key proof that each `register()` call replays the blueprint's deferred functions against its own `BlueprintSetupState`, so a blueprint instance can legally live at multiple locations — with per-registration error handlers and namespacing.

```mermaid
sequenceDiagram
    autonumber
    participant T as Test
    participant App as Flask app
    participant BP as Blueprint
    participant SS as BlueprintSetupState

    T->>BP: Blueprint("bp", __name__, url_prefix=...)
    Note over BP: decorators only *record* deferred functions
    T->>BP: @bp.route / @bp.errorhandler / ...
    T->>App: register_blueprint(bp, options)
    App->>BP: register(app, options)
    BP->>BP: name = name_prefix + name<br/>reject duplicates in app.blueprints
    BP->>SS: make_setup_state(app, options, first_registration)
    BP->>SS: add static rule (if static_folder)
    BP->>App: _merge_blueprint_funcs(app, name)<br/>(bp-scoped callbacks keyed by name)
    loop each deferred function
        BP->>SS: deferred(state)
        SS->>App: add_url_rule(rule, "name.endpoint", view, defaults)
    end
    loop each nested blueprint (self._blueprints)
        BP->>BP: compose url_prefix / subdomain / name_prefix
        BP->>App: nested.register(app, bp_options)
    end
```

Steps 6 and 9–12 are exactly what `test_unique_blueprint_names`, `test_route_decorator_custom_endpoint` and `test_nesting_url_prefixes` observe from the outside.

### 5.3 Nesting

`Blueprint.register_blueprint(child, **options)` only *queues* the child; the composition happens inside `register()`:

- **URL prefixes** (`test_nesting_url_prefixes`, parametrized over 4 combinations): the effective child prefix is taken from `register_blueprint(url_prefix=...)` if given, else the child's own `url_prefix`; it is joined onto the parent's effective prefix with exactly one `/`. Init-time and registration-time configuration are therefore equivalent.
- **Subdomains** (`test_nesting_subdomains`): a subdomain on the parent registration covers the whole subtree — `child` at `parent(subdomain="api")` matches `api.example.test`.
- **Subdomain stacking** (`test_child_and_parent_subdomain`): child `subdomain="api"` + parent `subdomain="parent"` compose to `api.parent.example.test` (dot-joined, child first); the bare `parent.example.test` host is a 404. These tests enable `app.subdomain_matching` and `SERVER_NAME`.
- **Error-handler resolution** (`test_nested_blueprint`): handlers are looked up innermost-first along the nesting chain with fallback — `/parent/no` hits the parent's 403 handler; `/parent/child/no` *also* hits the parent's (child has none); `/parent/child/grandchild/no` hits the grandchild's handler even though the parent also has one.

### 5.4 Callback scoping and ordering

Blueprint decorators come in two flavors. The bp-scoped variants are recorded on the blueprint and merged into the app **keyed by the blueprint's registration name**; the `app_*` variants are appended under the app-wide `None` key via `record_once`:

| Blueprint decorator | Effective scope | Stored under |
| --- | --- | --- |
| `before_request` / `after_request` / `teardown_request` | views dispatched to this blueprint | `<name>` |
| `before_app_request` / `after_app_request` / `teardown_app_request` | every request | `None` |
| `context_processor` / `app_context_processor` | templates of this blueprint / all templates | `<name>` / `None` |
| `url_defaults` / `url_value_preprocessor` + `app_*` variants | URL building & matching | `<name>` / `None` |
| `errorhandler` / `app_errorhandler` | exceptions of this blueprint / all requests | `<name>` / `None` |
| `route`, `add_url_rule`, `endpoint` | always bp-scoped, endpoint namespaced | n/a |
| `app_template_filter` / `app_template_test` / `app_template_global` | Jinja environment (app-wide) | n/a (`record_once`) |

`test_nested_callback_order` pins the execution order for a view on `child` (nested under `parent`):

```mermaid
flowchart LR
    A["GET /a"] --> B["before_request<br/>app_1, app_2"]
    B --> C["before_request<br/>parent_1, parent_2"]
    C --> D["before_request<br/>child_1, child_2"]
    D --> E["view (returns g.seen)"]
    E --> F["after_request<br/>innermost → outermost"]
    F --> G["response sent"]
    G --> H["teardown_request<br/>reverse of before_request:<br/>child_2, child_1, parent_2,<br/>parent_1, app_2, app_1"]
```

The teardown assertions use `g.seen.pop()` to prove strict reverse ordering (see [contexts_request_context](contexts_request_context.md) for when teardown fires). The same test also proves **context-processor precedence**: `render_template_string("{{ key }}")` resolves to `child`'s value because processors run outermost→innermost and later assignments win.

Two more lifecycle tests complete the picture:

- `test_request_processing` — bp-scoped `before_request` → view → `after_request` (response body becomes `"request|after"`) → `teardown_request`, and that this fires *only* for blueprint views.
- `test_app_request_processing` — the `*_app_request` trio fires on **every** request (asserted across two consecutive requests), even when the route belongs to the app.

### 5.5 URL handling

- `test_blueprint_prefix_slash` (11 parametrized cases): `BlueprintSetupState.add_url_rule` normalizes `url_prefix`/rule joins to exactly one slash — e.g. `"/foo/" + "//bar"` → `/foo/bar`; an empty rule inherits the prefix; `"/"` + `""` → `/`.
- `test_blueprint_url_defaults`: the *same* blueprint instance is registered twice (`url_prefix="/1"` and `name="test2"`, `url_prefix="/2"`) with per-registration `url_defaults`; both views resolve defaults correctly per instance (setup state merges blueprint-level defaults with registration options).
- `test_blueprint_url_processors`: `bp.url_defaults` + `bp.url_value_preprocessor` implement a `/<lang_code>` prefix pattern (pop `lang_code` into `g`, re-inject it when building URLs) — active **only** for blueprint views.
- `test_app_url_processors`: `bp.app_url_defaults` / `bp.app_url_value_preprocessor` perform the same trick app-wide, for app-level routes.
- `test_route_decorator_custom_endpoint`: custom endpoint names are namespaced by **blueprint name, not prefix** — the views report `bp.foo`, `bp.bar`, `bp.123`, `bp.bar_foo` regardless of `url_prefix="/py"`.
- `test_endpoint_decorator`: `bp.endpoint("bar")` supplies the view function for an endpoint that already exists as a bare rule on the app's url map (`Rule("/foo", endpoint="bar")`); the blueprint does **not** create a namespaced rule, so `/bp_prefix/bar` is a 404 while `/foo` serves the blueprint view.

### 5.6 Scoped error handling

- `test_blueprint_specific_error_handling`: three blueprints register `errorhandler(403)`; only requests dispatched to `frontend` / `backend` get their own handlers, the handler-less `sideend` falls back to the app-level handler.
- `test_blueprint_app_error_handling`: `errors.app_errorhandler(403)` becomes an app-wide handler — it covers both an app route (`/forbidden`) and a route of an entirely different blueprint (`/nope`).

For the dispatch-side resolution algorithm, see [application-core_test-suite](application-core_test-suite.md) (e.g. `test_errorhandler_precedence`).

### 5.7 Templates and static files

The resource tests are the module's integration layer, run against `blueprintapp`:

- `test_templates_and_static` — asserts the full resource surface:
  - blueprint template folders are namespaced: `/` → *"Hello from the Frontend"*, `/admin/`, `/admin/index2` (incl. `./admin/index.html` normalization);
  - blueprint static routes: `/admin/static/test.txt` and `/admin/static/css/test.css`;
  - `SEND_FILE_MAX_AGE_DEFAULT` drives the `Cache-Control: max-age` of static responses (with save/restore of the config value);
  - `url_for("admin.static", filename="test.txt")` → `/admin/static/test.txt`;
  - a missing template raises `TemplateNotFound` carrying the requested name;
  - app-level (non-blueprint) templates resolve from the app's own template folder (`nested/nested.txt`).
- `test_templates_list` — `app.jinja_env.list_templates()` returns exactly `["admin/index.html", "frontend/index.html"]`, proving blueprint templates are exposed under their `<blueprint_name>/` namespace.
- `test_default_static_max_age` — a `Blueprint` subclass overriding `get_send_file_max_age()` (returning `100`) takes precedence over `SEND_FILE_MAX_AGE_DEFAULT` when serving via `blueprint.send_static_file()`.
- `test_context_processing` — `app_context_processor` (app-wide, key `notanswer`) vs `context_processor` (bp-scoped, key `answer`): the app page sees only `43`; the blueprint page sees both.
- `test_template_global` — `bp.app_template_global` installs `get_answer` into the Jinja environment **at registration time** (guarded by `record_once`), usable from any template.

Template names flow through the dispatching loader as follows:

```mermaid
flowchart TB
    V["render_template('admin/index.html')"] --> D{"DispatchingJinjaLoader<br/>(see templating)"}
    D -->|"name starts with 'admin/'"| BA["admin's FileSystemLoader<br/>apps/admin/templates"]
    D -->|"name starts with 'frontend/'"| BF["frontend's FileSystemLoader<br/>apps/frontend/templates"]
    D -->|"other names"| A["app template folder"]
    BA --> R["'Hello from the Admin'"]
    BF --> R2["'Hello from the Frontend'"]
    A --> R3["app-owned templates<br/>(e.g. nested/nested.txt)"]
```

---

## 6. Fixtures and Dependencies

| Fixture / dependency | Source | Used by |
| --- | --- | --- |
| `app`, `client`, `app_ctx`, `req_ctx`, `test_apps` | [test-infrastructure](test-infrastructure.md) (`tests/conftest.py`) | nearly every test |
| `flask.Blueprint`, `flask.Flask` | [blueprints_resources_and_cli](blueprints_resources_and_cli.md) / [application-core](application-core.md) | all tests |
| Deferred registration, `BlueprintSetupState` | [blueprints_registration_machinery](blueprints_registration_machinery.md) | exercised implicitly by every registration |
| `flask.g`, request/app contexts | [contexts_app_context](contexts_app_context.md), [contexts_request_context](contexts_request_context.md) | URL-processor and callback-order tests |
| `render_template`, `jinja_env` | [templating](templating.md) | resource and context-processor tests |
| `werkzeug` (`Rule`, `parse_cache_control_header`), `jinja2.TemplateNotFound`, `pytest` | external | endpoint/static tests |

To run the suite: `pytest tests/test_blueprints.py` (the `blueprintapp`-based tests require the `test_apps` fixture, which handles `sys.path` and module-cache hygiene automatically).

---

## 7. Invariants Guarded by This Suite

1. **Names**: a blueprint name is non-empty and dot-free; endpoint names and view-function names passed to `add_url_rule` are dot-free (dots belong to the framework's namespace separator).
2. **Namespacing**: registered endpoints are `"<name>.<endpoint>"` (plus a name prefix per nesting level); static endpoints become `"<name>.static"`; templates are exposed under `"<name>/"`.
3. **Identity**: `(blueprint object, registration name)` pairs must be unique; self-nesting is rejected; `name=` opt-in enables legal multi-registration.
4. **Prefix/subdomain composition**: exactly-one-slash URL joining; child subdomains are dot-prepended onto the parent's; init-time and registration-time settings are equivalent.
5. **Scoping**: bp-scoped callbacks are keyed by registration name and fire only for that blueprint's views; `app_*` / `app_`-prefixed registrations go under the `None` key and use `record_once` so re-registration does not duplicate them.
6. **Ordering**: before-request runs app → outer blueprint → inner blueprint; teardown runs in exact reverse; innermost context processors win.
7. **Resources**: blueprint template folders and static routes coexist with app-owned ones without collisions; static cache headers respect config and per-blueprint overrides.

---

## 8. Related Modules

- [blueprints](blueprints.md) — parent subsystem overview
- [blueprints_registration_machinery](blueprints_registration_machinery.md) — the sans-io `Blueprint` / `BlueprintSetupState` implementation these tests validate
- [blueprints_resources_and_cli](blueprints_resources_and_cli.md) — concrete `Blueprint` (static files, `open_resource`, CLI group)
- [application-core](application-core.md), [application-core_flask-app](application-core_flask-app.md) — the `Flask` object and request dispatch
- [application-core_test-suite](application-core_test-suite.md) — app-level tests incl. error-handler precedence and routing
- [contexts_app_context](contexts_app_context.md) / [contexts_request_context](contexts_request_context.md) — context lifecycle underpinning callback ordering
- [templating](templating.md) — Jinja environment, dispatching loader, filters/tests/globals
- [test-infrastructure](test-infrastructure.md) — conftest fixtures (`app`, `client`, `test_apps`) used throughout
