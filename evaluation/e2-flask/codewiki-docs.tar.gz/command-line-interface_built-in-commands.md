# Command Line Interface — Built-in Commands

## 1. Introduction

The `command-line-interface_built-in-commands` module implements the three commands that ship with the `flask` CLI out of the box:

| Command | Implementation | Purpose |
|---|---|---|
| `flask run` | `run_command` | Starts a Werkzeug-based local development server for the located Flask app. |
| `flask shell` | `shell_command` | Opens an interactive Python shell with the app and its context preloaded. |
| `flask routes` | `routes_command` | Prints a formatted table of all registered URL rules (endpoints, methods, domains). |

Two supporting pieces belong exclusively to this module:

- **`CertParamType`** — a Click parameter type for the `flask run --cert` option that accepts a certificate file, the string `"adhoc"`, or an import path resolving to an `ssl.SSLContext`.
- **`_validate_key`** — the option callback for `flask run --key` that enforces the legal `--cert`/`--key` combinations and rewrites `cert` into a `(cert, key)` tuple.

These commands are registered automatically by [`FlaskGroup`](command-line-interface_cli-framework.md) as the *default commands*, meaning every `flask` installation exposes them without any app-specific code. All three commands operate on the application resolved by the discovery machinery ([`ScriptInfo`](command-line-interface_app-discovery.md)) and run inside the application context ([contexts](contexts.md)).

> **Design principle:** `flask run` is for development only. It delegates serving to `werkzeug.serving.run_simple` and offers no production-grade stability, security, or performance guarantees.

---

## 2. Architecture

The built-in commands sit at the leaf of the CLI framework. [`FlaskGroup`](command-line-interface_cli-framework.md) (the root `flask` group) adds them via `add_command()` when constructed with `add_default_commands=True`. During dispatch they reach back into the app-discovery and environment-config layers, and finally into the application core and Werkzeug.

```mermaid
flowchart TB
    subgraph CLI["flask cli (src/flask/cli.py)"]
        FG["FlaskGroup<br/>(cli framework)"] -->|add_command<br/>default commands| RC["run_command<br/>'flask run'"]
        FG --> SH["shell_command<br/>'flask shell'"]
        FG --> RTS["routes_command<br/>'flask routes'"]

        subgraph SUPPORT["run-command support types"]
            CPT["CertParamType<br/>--cert value conversion"]
            VK["_validate_key<br/>--key callback"]
            SPT["SeparatedPathType<br/>--extra-files / --exclude-patterns"]
            BANNER["show_server_banner"]
        end

        RC --- CPT
        RC --- VK
        RC --- SPT
        RC --- BANNER
    end

    subgraph DISCOVERY["App Discovery (sibling module)"]
        SI["ScriptInfo.load_app()"]
        WAC["with_appcontext"]
    end

    subgraph ENVCFG["Environment Config (sibling module)"]
        DBG["_debug_option / _set_debug<br/>sets FLASK_DEBUG"]
    end

    subgraph CORE["Application Core"]
        APP["Flask instance"]
        MSC["Flask.make_shell_context()"]
        UMAP["Flask.url_map"]
        APPTIMER["Flask.run() no-op guard<br/>FLASK_RUN_FROM_CLI"]
    end

    subgraph WERK["Werkzeug"]
        RS["run_simple()"]
        RELOAD["is_running_from_reloader()"]
        IS["import_string()"]
    end

    subgraph CTX["Contexts module"]
        AC["AppContext<br/>(current_app proxy)"]
    end

    RC -->|loads app| SI
    SH -->|"@with_appcontext"| WAC
    RTS -->|"@with_appcontext"| WAC
    WAC --> SI
    RC --> DBG
    SI --> APP
    WAC -->|pushes| AC
    AC -->|resolves| APP
    SH --> MSC
    RTS --> UMAP
    RC --> RS
    RC --> RELOAD
    RC -->|serves| APP
    CPT --> IS
    APP -.->|"guards stray app.run"| APPTIMER
```

### 2.1 Component roles

| Component | Kind | Responsibility |
|---|---|---|
| `run_command` | `click.Command` | Load the app via `ScriptInfo`, resolve debug/reloader/debugger flags, and hand the WSGI callable to `run_simple`. |
| `shell_command` | `click.Command` | Build the shell namespace (`app`, `g`, processors, `PYTHONSTARTUP`) and enter `code.interact` inside the app context. |
| `routes_command` | `click.Command` | Enumerate `current_app.url_map.iter_rules()`, sort and render an aligned ASCII table. |
| `CertParamType` | `click.ParamType` | Convert `--cert` to a path, `"adhoc"`, or an `ssl.SSLContext` object. |
| `_validate_key` | callback | Cross-validate `--cert`/`--key`; mutate `ctx.params["cert"]` into a pair. |
| `show_server_banner` | helper | One-time "Serving Flask app … / Debug mode: …" output, suppressed under the reloader. |
| `SeparatedPathType` | `click.Path` subclass | Accept OS-path-separator-separated lists for `--extra-files` / `--exclude-patterns`. |

---

## 3. Command Reference

### 3.1 `flask run` — `run_command`

```
flask run [OPTIONS]
```

Starts a local development server. The reloader and debugger are enabled by default with the `--debug` option.

**Options**

| Option | Default | Description |
|---|---|---|
| `--host`, `-h` | `127.0.0.1` | Interface to bind to. |
| `--port`, `-p` | `5000` | Port to bind to. |
| `--debug/--no-debug` | *(inherits env)* | Shared `_debug_option`; sets `FLASK_DEBUG` early via `_set_debug` (see [environment-config](command-line-interface_environment-config.md)). Injected at position 0 of the command's params. |
| `--cert` | — | `CertParamType()`: certificate **file path**, `"adhoc"`, or import path to an `ssl.SSLContext`. Processed eagerly (before `--key`). |
| `--key` | — | Key file; validated by `_validate_key`, not exposed to the function body. |
| `--reload/--no-reload` | `None` → `debug` | Enable the code reloader. |
| `--debugger/--no-debugger` | `None` → `debug` | Enable the interactive debugger. |
| `--with-threads/--without-threads` | `True` | Multithreaded request handling. |
| `--extra-files` | `None` | Additional files that trigger reload, separated by `os.path.pathsep`. |
| `--exclude-patterns` | `None` | fnmatch patterns excluded from reload triggering. |

**Execution semantics**

1. `@pass_script_info` injects the shared [`ScriptInfo`](command-line-interface_app-discovery.md) object.
2. `info.load_app()` imports/factories the app. On failure:
   - **Not under the reloader:** the exception is re-raised immediately — the command fails fast.
   - **Under the reloader:** the traceback is printed at once, but a placeholder WSGI app is installed that re-raises the saved error on the first request. This lets the Werkzeug reloader parent stay alive so the debugger (or server) surfaces the error in-process.
3. `debug = get_debug_flag()` reads `FLASK_DEBUG` (see [Runtime_Configuration](Runtime_Configuration___Diagnostics.md) / [helpers](Request_Services___Response_Rendering.md)).
4. `reload` and `debugger` fall back to `debug` when not explicitly provided.
5. `show_server_banner()` prints app/debug info once (skipped by reloader children).
6. Werkzeug's `run_simple()` binds the socket with the resolved options.

**Environment variables**

| Variable | Effect |
|---|---|
| `FLASK_RUN_FROM_CLI` | Set to `"true"` by `FlaskGroup.make_context()` **before** the app is imported. Causes `Flask.run()` to become a warned no-op, so an unguarded `app.run()` at import time cannot block the CLI. |
| `FLASK_DEBUG` | Source of truth for `get_debug_flag()`; set by `--debug/--no-debug`, honored by `ScriptInfo.load_app()` when syncing `app.debug`. |

### 3.2 `flask shell` — `shell_command`

```
flask shell
```

Runs an interactive Python shell inside the application context — useful for management snippets without manual bootstrap.

The command is wrapped in `@with_appcontext`, which loads the app through `ScriptInfo` and pushes `app.app_context()` as a Click context resource so `current_app` is usable in every callback.

**Namespace construction order**

1. **Banner:** `Python <ver> on <platform>` / `App: <import_name>` / `Instance: <instance_path>`.
2. **`PYTHONSTARTUP`:** if set, the startup file is `eval`'d into the context dict (standard interpreter behavior).
3. **App shell context:** `current_app.make_shell_context()` — provides `app` and `g` plus everything returned by registered `@app.shell_context_processor` functions (see [application-core](application-core.md)).
4. **Completion:** Python's `sys.__interactivehook__` runs (readline history/tab-completion); the `rlcompleter` is pointed at the shell context instead of `flask.__main__.__dict__`.
5. `code.interact(banner=…, local=ctx)` enters the REPL.

### 3.3 `flask routes` — `routes_command`

```
flask routes [OPTIONS]
```

Lists every registered route. Requires the app context (via `@with_appcontext`).

| Option | Default | Description |
|---|---|---|
| `--sort`, `-s` | `endpoint` | One of `endpoint`, `methods`, `domain`, `rule`, `match`. `match` shows the order Flask dispatches requests. |
| `--all-methods` | off | Include `HEAD` and `OPTIONS` columns (filtered by default). |

**Rendering logic**

- `rules = list(current_app.url_map.iter_rules())`; prints `No routes were registered.` when empty.
- If `url_map.host_matching` is enabled a **Host** column is emitted; otherwise a **Subdomain** column appears whenever any rule declares a subdomain.
- Rows are sorted with `operator.itemgetter` (unknown sort keys are silently ignored → insertion order).
- Column widths are computed from the widest cell; a dashed separator row is inserted after the header.

---

## 4. TLS Options: `CertParamType` and `_validate_key`

`flask run` supports HTTPS in three ways, negotiated by `--cert` and `--key`:

| `--cert` value | `--key` | Result |
|---|---|---|
| Existing certificate file path | **required** key file | `cert = (cert_path, key_path)` tuple passed to `run_simple(ssl_context=…)`. |
| `adhoc` | must be omitted | Ad-hoc TLS with a generated cert. Requires the `cryptography` package. |
| Import string, e.g. `mymodule:context` | must be omitted | The import must resolve to an `ssl.SSLContext` instance. |

`CertParamType.convert()` resolution order:

```mermaid
flowchart TD
    A["--cert value"] --> B{"ssl module<br/>available?"}
    B -- no --> ERR1["BadParameter:<br/>'requires Python compiled with SSL support'"]
    B -- yes --> C{"Valid existing file?<br/>(click.Path: exists,<br/>no dir, resolve)"}
    C -- yes --> R1["return path str"]
    C -- no --> D{"lower() == 'adhoc'?"}
    D -- yes --> E{"cryptography<br/>installed?"}
    E -- no --> ERR2["BadParameter:<br/>'requires cryptography library'"]
    E -- yes --> R2["return 'adhoc'"]
    D -- no --> F["import_string(value, silent=True)"]
    F --> G{"isinstance<br/>ssl.SSLContext?"}
    G -- yes --> R3["return SSLContext"]
    G -- no --> ERR3["raise original<br/>BadParameter"]
```

`_validate_key` runs **after** `--cert` (which is eager) and enforces the cross-constraints:

```mermaid
flowchart TD
    A["--key value provided?"] -- yes --> B{"cert == 'adhoc'?"}
    B -- yes --> E1["BadParameter:<br/>'--key' is not used"]
    B -- no --> C{"cert is SSLContext?"}
    C -- yes --> E2["BadParameter:<br/>'--key' is not used"]
    C -- no --> D{"cert present?"}
    D -- no --> E3["BadParameter:<br/>'--cert' must also be specified"]
    D -- yes --> OK1["ctx.params['cert'] = (cert, key)"]

    A -- no --> F{"cert present and NOT<br/>(adhoc or SSLContext)?"}
    F -- yes --> E4["BadParameter:<br/>'Required when using --cert'"]
    F -- no --> OK2["pass through"]
```

---

## 5. Process Flows

### 5.1 `flask run` end-to-end

```mermaid
sequenceDiagram
    autonumber
    participant U as User shell
    participant FG as FlaskGroup
    participant RC as run_command
    participant SI as ScriptInfo
    participant APP as Flask app
    participant WZ as werkzeug run_simple

    U->>FG: flask --app hello run --debug
    FG->>FG: make_context sets FLASK_RUN_FROM_CLI=true
    FG->>FG: --env-file / --app / --debug<br/>(env-config module)
    Note over APP: import side effects run here,<br/>any app.run() call is a warned no-op
    FG->>RC: invoke (pass_script_info)
    RC->>SI: load_app()
    SI->>APP: locate/import, set app.debug from FLASK_DEBUG
    APP-->>SI: app instance
    SI-->>RC: app instance

    alt app load failed & reloader parent
        RC->>RC: print traceback now, install<br/>error-raising placeholder WSGI app
    else app load failed (normal)
        RC->>U: re-raise → command fails
    end

    RC->>RC: debug = get_debug_flag()<br/>reload/debugger default to debug
    RC->>U: show_server_banner() *(skipped in reloader child)*
    RC->>WZ: run_simple(host, port, app,<br/>use_reloader, use_debugger,<br/>threaded, ssl_context,<br/>extra_files, exclude_patterns)
    WZ-->>U: serves requests until Ctrl-C
```

### 5.2 `flask shell` and `flask routes` context acquisition

Both commands share the `@with_appcontext` acquisition path:

```mermaid
flowchart TD
    A["click dispatches 'flask shell' / 'flask routes'"] --> B{"current_app<br/>already active?"}
    B -- yes --> E["invoke callback directly"]
    B -- no --> C["ctx.ensure_object(ScriptInfo).load_app()"]
    C --> D["ctx.with_resource(app.app_context())<br/>→ AppContext pushed (contexts module)"]
    D --> E

    E --> F{"Which command?"}
    F -- shell --> G["banner → PYTHONSTARTUP →<br/>app.make_shell_context() →<br/>readline completer → code.interact()"]
    F -- routes --> H["url_map.iter_rules() →<br/>build rows/columns → sort →<br/>echo aligned table"]
```

---

## 6. Interaction with Other Modules

| Dependency | Provided by | How it is used here |
|---|---|---|
| `ScriptInfo.load_app()` | [command-line-interface_app-discovery](command-line-interface_app-discovery.md) | `run_command` calls it explicitly; `with_appcontext` calls it for `shell`/`routes`. |
| `with_appcontext`, `pass_script_info` | cli-framework / discovery modules | Context guarantees for `shell_command` and `routes_command`. |
| `FlaskGroup` | [command-line-interface_cli-framework](command-line-interface_cli-framework.md) | Registers the three commands as defaults; sets `FLASK_RUN_FROM_CLI`; merges app-provided commands at dispatch time. |
| `_debug_option` / `_set_debug` | [command-line-interface_environment-config](command-line-interface_environment-config.md) | Injected into `run_command.params[0]` so `flask run --debug` works, syncing `FLASK_DEBUG` with the group-level flag. |
| `AppContext` / `current_app` | [contexts](contexts.md) | `routes_command` reads `current_app.url_map`; `shell_command` reads `current_app.make_shell_context()` etc. |
| `Flask.make_shell_context`, `Flask.url_map`, `Flask.run` | [application-core](application-core.md) | Shell namespace source, route enumeration, and the `FLASK_RUN_FROM_CLI` no-op guard, respectively. |
| `get_debug_flag()` | helpers ([Request_Services](Request_Services___Response_Rendering.md)) | `run_command` reads `FLASK_DEBUG` to derive reloader/debugger defaults. |
| `run_simple`, `is_running_from_reloader`, `import_string` | Werkzeug (external) | Server bootstrap, reloader detection, `SSLContext` import in `CertParamType`. |

Outbound data flow summary:

```mermaid
flowchart LR
    CLI_ARGS["CLI args + env vars<br/>(FLASK_APP, FLASK_DEBUG, FLASK_RUN_FROM_CLI)"] --> CMDS["built-in commands"]
    CMDS -->|"app instance request"| SI["ScriptInfo (discovery)"]
    SI -->|"imports"| APP["Flask app (application-core)"]
    APP -->|"url_map / shell ctx / app_context"| CMDS
    CMDS -->|"host, port, app, ssl, reload"| SERVER["werkzeug run_simple"]
    CMDS -->|"route table text / REPL banner"| STDOUT["stdout (click.echo)"]
```

---

## 7. Testing Coverage

Behavior is exercised by [command-line-interface_test-suite](command-line-interface_test-suite.md) (`tests/test_cli.py`) and the core suite (`tests/test_basic.py`):

| Area | Tests |
|---|---|
| `CertParamType` | `test_run_cert_adhoc`, `test_run_cert_import`, `test_run_cert_path`, `test_run_cert_no_ssl` |
| Server startup / ports | `test_run_defaults`, `test_run_server_port`, `test_run_from_config`, `test_run_exclude_patterns` |
| `flask routes` | `TestRoutes` class (sorting, all-methods, empty map) |
| App context wrapper | `test_with_appcontext`, `test_flaskgroup_app_context`, `test_app_cli_has_app_context` |
| `app.run()` no-op guard | `test_run_from_config` (relies on `FLASK_RUN_FROM_CLI` set by `FlaskGroup.make_context`) |

---

## 8. Related Documentation

- [command-line-interface_cli-framework](command-line-interface_cli-framework.md) — `FlaskGroup`, plugin command loading, dispatch order.
- [command-line-interface_app-discovery](command-line-interface_app-discovery.md) — `ScriptInfo`, `locate_app`, factory/variable resolution rules.
- [command-line-interface_environment-config](command-line-interface_environment-config.md) — `--env-file`, `--debug`, `.env`/`.flaskenv` loading.
- [application-core](application-core.md) — the `Flask` object these commands operate on.
- [contexts](contexts.md) — app/request contexts and the `current_app` proxy.
- [Runtime_Configuration___Diagnostics](Runtime_Configuration___Diagnostics.md) — configuration and logging consumed at startup.
