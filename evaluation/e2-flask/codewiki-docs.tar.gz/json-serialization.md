# JSON Serialization Module

## Overview

The **json-serialization** module is Flask's complete JSON subsystem. It answers two distinct problems:

1. **HTTP JSON handling** — how a Flask application serializes Python objects into JSON responses (and parses JSON request bodies) in a way that applications can customize. This is solved by the **JSON provider** system (`src/flask/json/provider.py`).
2. **Lossless JSON round-tripping** — how data types that have no native JSON representation (tuples, bytes, UUIDs, datetimes, Markup, etc.) survive a serialize → deserialize cycle, primarily so session data can be stored in signed cookies. This is solved by the **tagged JSON serializer** (`src/flask/json/tag.py`).

| Concern | Entry point used by app code | Implementation |
|---|---|---|
| JSON responses (`jsonify`, returning `dict`/`list` from views) | `flask.json.jsonify` → `app.json.response()` | `JSONProvider` / `DefaultJSONProvider` |
| Standalone dumps/loads (`flask.json.dumps`, `flask.json.loads`) | `flask.json.dumps/loads` → `app.json.dumps()/loads()` | `JSONProvider` / `DefaultJSONProvider` |
| Jinja `tojson` filter | `jinja_env.policies["json.dumps_function"]` → `app.json.dumps` | `DefaultJSONProvider.dumps` |
| Signed cookie sessions | `SecureCookieSessionInterface` (`session_json_serializer`) | `TaggedJSONSerializer` + `JSONTag` subclasses |

The module is part of the **Request Services & Response Rendering** group, sitting alongside [helpers](helpers.md), [sessions](sessions.md), and [templating](templating.md), and is orchestrated by the application core ([application-core](application-core.md)).

## Architecture

### Component relationships

```mermaid
graph TD
    subgraph "flask.json package (__init__.py)"
        JSONIFY["jsonify()"]
        DUMPS["dumps()"]
        LOADS["loads()"]
        DUMPF["dump() / load()"]
    end

    subgraph "json-serialization module"
        subgraph "provider.py"
            JP["JSONProvider<br/>(abstract base)"]
            DEFAULT["_default()<br/>(type fallbacks)"]
            DJP["DefaultJSONProvider<br/>(built-in json library)"]
        end
        subgraph "tag.py"
            TJS["TaggedJSONSerializer"]
            BASETAG["JSONTag<br/>(base)"]
            TAGS["TagDict / PassDict / TagTuple / PassList<br/>TagBytes / TagMarkup / TagUUID / TagDateTime"]
        end
    end

    APP["Flask / App (application-core)"]
    RESP["Response object"]
    SESSION["SecureCookieSessionInterface<br/>(sessions module)"]
    JINJA["Jinja Environment<br/>(templating module)"]
    REQ["request.get_json()"]

    APP -->|"self.json = json_provider_class(self)"| JP
    JP -->|subclass| DJP
    DJP -->|"default = staticmethod(_default)"| DEFAULT
    BASETAG -->|extended by| TAGS
    TAGS -->|registered in| TJS

    JSONIFY -->|"current_app.json.response()"| JP
    DUMPS -->|"current_app.json.dumps()"| JP
    LOADS -->|"current_app.json.loads()"| JP
    DUMPF --> JP
    DJP -->|"response_class(..., mimetype='application/json')"| RESP
    TJS -->|"dumps/loads via flask.json"| DUMPS
    TJS --> SESSION
    JINJA -->|"tojson policy: app.json.dumps"| JP
    REQ -->|"parses body via app.json.loads path"| JP
```

### Key design decisions

- **Weakref to the app.** `JSONProvider.__init__` stores the application as a `weakref.proxy` (`_app`). The provider needs app state (e.g. `response_class`, `debug`) without creating reference cycles or preventing app garbage collection (see `test_app_freed_on_zero_refcount` in the application-core test suite).
- **Strategy pattern for the JSON library.** All public functions in `flask.json` delegate to `current_app.json`. Swapping `app.json` for a provider built on `orjson`, `ujson`, etc. changes behavior everywhere JSON is touched, with no Flask code changes.
- **Tags, not `default` hooks, for round-tripping.** `DefaultJSONProvider.default` (via `_default`) is one-way: it converts exotic types to plain JSON types and the original type is lost on load. `TaggedJSONSerializer` wraps values in single-key dicts (e.g. `" t": [1, 2, 3]`) so `loads` can reconstruct the exact type. This matters for sessions, where a stored `tuple` must not come back as a `list`.
- **Separation of concerns.** The provider handles *HTTP-facing* JSON (mimetypes, debug pretty-printing, response objects); the tag serializer handles *storage-facing* JSON (compact, lossless). They share only the underlying `flask.json.dumps`/`loads` functions.

## Sub-modules

### [JSON Provider System](json-serialization_json-serialization_provider.md)

`src/flask/json/provider.py` — the pluggable strategy for all of Flask's HTTP JSON operations.

- **`JSONProvider`** — abstract base defining `dumps`, `dump`, `loads`, `load`, and `response`. Subclasses must implement at least `dumps` and `loads`.
- **`DefaultJSONProvider`** — default implementation over Python's built-in `json` module, with tunable attributes (`default`, `ensure_ascii`, `sort_keys`, `compact`, `mimetype`) and debug-aware pretty-printing in `response()`.
- **`_default`** — the fallback serializer that converts `datetime`/`date` to RFC 822 HTTP dates, `Decimal`/`UUID` to strings, dataclasses to dicts, and `Markup`-like objects via `__html__`.

Detailed docs: [json-serialization_json-serialization_provider.md](json-serialization_json-serialization_provider.md)

### [Tagged JSON Serializer](json-serialization_tag.md)

`src/flask/json/tag.py` — lossless, compact, extensible tagging system for non-standard JSON types.

- **`TaggedJSONSerializer`** — walks values, applies the first matching tag, and recursively un-tags on load. Used as the intermediate serializer for signed cookie sessions.
- **`JSONTag`** — base class implementing the `check` / `to_json` / `to_python` protocol.
- **Built-in tags** — `TagDict`, `PassDict`, `TagTuple`, `PassList`, `TagBytes`, `TagMarkup`, `TagUUID`, `TagDateTime`.

Detailed docs: [json-serialization_tag.md](json-serialization_tag.md)

## Data flows

### JSON response rendering (provider path)

```mermaid
sequenceDiagram
    participant V as View function
    participant A as Flask (make_response / jsonify)
    participant P as app.json (DefaultJSONProvider)
    participant J as json.dumps
    participant R as Response

    V->>A: return {"name": "Flask"} (or jsonify(...))
    A->>P: response(obj)
    P->>P: _prepare_response_obj(args|kwargs)
    P->>P: debug or compact is False ? indent=2 : separators=(",", ":")
    P->>J: dumps(obj, default=_default, ensure_ascii, sort_keys)
    J-->>P: JSON string
    P-->>R: response_class(string + "\n", mimetype="application/json")
    R-->>V: JSON response sent to client
```

Note that `make_response` in the application core calls `self.json.response(rv)` whenever a view returns a `dict` or `list`, so automatic JSON responses go through the same provider as explicit `jsonify` calls.

### Session serialization (tag path)

```mermaid
sequenceDiagram
    participant S as Session data
    participant T as TaggedJSONSerializer
    participant FJ as flask.json.dumps/loads
    participant D as itsdangerous URLSafeTimedSerializer

    Note over S,D: save_session
    S->>T: dumps(dict(session))
    T->>T: tag(): wrap tuples, bytes, UUIDs,<br/>datetimes, Markup in tagged dicts
    T->>FJ: dumps(tagged, separators=(",", ":"))
    FJ->>D: compact JSON string → signed cookie value

    Note over S,D: open_session
    D->>FJ: verify signature, return JSON string
    FJ->>T: loads(value)
    T->>T: _untag_scan(): reconstruct original types
    T-->>S: SecureCookieSession with identical data
```

### Type conversion in the provider (`_default`)

```mermaid
flowchart LR
    O["Object json can't serialize"] --> D{"isinstance datetime.date?"}
    D -- yes --> H["RFC 822 / HTTP date string<br/>http_date(o)"]
    D -- no --> U{"Decimal or UUID?"}
    U -- yes --> S["str(o)"]
    U -- no --> DC{"dataclass?"}
    DC -- yes --> AS["dataclasses.asdict(o)"]
    DC -- no --> M{"has __html__?"}
    M -- yes --> HM["str(o.__html__())"]
    M -- no --> ERR["raise TypeError<br/>'not JSON serializable'"]
```

## How the module fits into the overall system

- **Application core ([application-core](application-core.md))**: `App.__init__` instantiates the provider (`self.json = self.json_provider_class(self)`); `App.make_response` converts `dict`/`list` view returns via `self.json.response()`; `App.create_jinja_environment` wires `app.json.dumps` into the Jinja `json.dumps_function` policy, which powers the `tojson` filter.
- **Sessions ([sessions](sessions.md))**: `SecureCookieSessionInterface` uses the module-level `session_json_serializer` (a `TaggedJSONSerializer`) as the payload serializer for `itsdangerous.URLSafeTimedSerializer`. `TagDict` ensures keys colliding with tag keys are escaped, and round-trip fidelity is verified by `tests/test_json_tag.py::test_dump_load_unchanged`.
- **Templating ([templating](templating.md))**: the `tojson` filter renders templates' embedded data using the app's provider — verified in `tests/test_json.py::test_tojson_filter`, including `<script>` escaping (`\u003c/script\u003e`) and HTTP-date datetimes.
- **Request parsing**: `request.get_json()` relies on the JSON decode path; malformed bodies yield `BadRequest` (400) whose debug message behavior is covered by `test_bad_request_debug_message`.
- **Testing tooling ([testing-support](testing-support.md))**: `EnvironBuilder` serializes the `json=` kwarg to build JSON request bodies; `FlaskClient` exposes `response.json`.

## Customization guide (summary)

| Goal | Mechanism |
|---|---|
| Serialize a custom type in responses | Subclass `DefaultJSONProvider`, override `dumps`/`default` (see `test_json_customization`) |
| Use a different JSON library | Implement `JSONProvider.dumps`/`loads`; set `app.json_provider_class` or `app.json` |
| Change response mimetype / pretty-printing | Override `DefaultJSONProvider.mimetype` / `compact` |
| Store extra types in the session | Create a `JSONTag` subclass and `serializer.register(TagOrderedDict, index=0)` |
| Change key sorting / ASCII escaping | Set `app.json.sort_keys` / `app.json.ensure_ascii` |

Full examples live in the sub-module docs: [provider customization](json-serialization_json-serialization_provider.md) and [custom tags](json-serialization_tag.md).

## Test coverage

- `tests/test_json.py` — jsonify (dicts, lists, kwargs), basic types, datetimes (naive & aware), UUIDs, Decimal, key sorting, `ensure_ascii`, file dump/load, custom providers, mimetype handling, bad requests, `tojson` filter integration, `__html__` objects.
- `tests/test_json_tag.py` — round-trip fidelity for all tagged types, custom tag registration, duplicate-key protection (`force=True`), tag ordering (`index`), and the `JSONTag` interface contract.
