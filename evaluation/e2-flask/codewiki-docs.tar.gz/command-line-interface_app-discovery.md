# Command-Line Interface — App Discovery (`command-line-interface_app-discovery`)

> **Scope:** `src/flask/cli.py` — core components `ScriptInfo` and `_set_app`
> **Parent module:** [command-line-interface](command-line-interface.md)
> **Grandparent module:** [Developer_Interface___Testing_Tooling](Developer_Interface___Testing_Tooling.md)

## 1. Introduction

App discovery is the mechanism that turns user intent — a command such as
`flask --app "myapp:create_app('dev')" run`, the `FLASK_APP` environment
variable, or a conventional project layout — into a **live `Flask`
application instance** that CLI commands can operate on.

This module owns the two central pieces of that mechanism:

| Component | Location | Responsibility |
|---|---|---|
| `ScriptInfo` | `src/flask/cli.py` | A click *pass-object* holder that remembers where the app lives and lazily loads it **once**, caching the result. |
| `_set_app` | `src/flask/cli.py` | The callback behind the eager `-A/--app` click option; it records the `module:name` import path into `ScriptInfo`. |

The actual import mechanics (`prepare_import`, `locate_app`, `find_best_app`,
`find_app_by_string`) live in the parent [command-line-interface](command-line-interface.md)
module and are summarized here only insofar as `ScriptInfo.load_app()` drives
them. Everything above the option layer (the `FlaskGroup` itself) is covered by
[command-line-interface_cli-framework](command-line-interface_cli-framework.md).

### Why "lazy" discovery matters

The app is **not** loaded when parsing arguments. It is loaded on demand the
first time a command (or `with_appcontext`) needs it. This design means:

- `flask --help`, `flask --version` and plugin command listing work even when
  no app can be found or the app raises during import.
- A broken app produces a clean, targeted error message instead of preventing
  the whole CLI from starting.
- The app is loaded exactly once per CLI invocation and shared by all
  subsequent lookups (idempotent, cached).

## 2. Architecture

```mermaid
flowchart TB
    subgraph CLI["flask CLI (command-line-interface)"]
        FG["FlaskGroup<br/>(cli-framework)"]
        subgraph EAGER["Eager click options"]
            ENV["-e/--env-file<br/>_env_file_callback<br/>(environment-config)"]
            APP["-A/--app option<br/>callback: _set_app<br/>(this module)"]
            DBG["--debug/--no-debug<br/>_set_debug<br/>(environment-config)"]
        end
        SI["ScriptInfo<br/>click pass-object<br/>(this module)"]
        subgraph HELPERS["Resolution helpers (parent module)"]
            PI["prepare_import"]
            LA["locate_app"]
            FBA["find_best_app"]
            FABS["find_app_by_string"]
        end
    end

    APPX["Flask application<br/>(application-core_flask-app)"]
    ENVV["Environment<br/>FLASK_APP · FLASK_DEBUG<br/>FLASK_SKIP_DOTENV"]

    ENVV -->|"auto_envvar_prefix=FLASK"| EAGER
    FG -->|"make_context(): obj = ScriptInfo"| SI
    APP -->|"info.app_import_path = value"| SI
    SI --> PI --> LA
    LA --> FBA & FABS
    FBA & FABS --> APPX
    SI -->|"app.debug = get_debug_flag()"| APPX
```

**Data flow at a glance:**

1. Sources of truth — the `--app` CLI flag and the `FLASK_APP` environment
   variable (both handled by the same click option) feed `_set_app`.
2. `_set_app` writes `ScriptInfo.app_import_path`.
3. On first `load_app()` call, `ScriptInfo` invokes the resolution helpers,
   which import the target module and pick (or build) the `Flask` instance.
4. The resulting app is cached and optionally configured
   (`app.debug = get_debug_flag()`), then handed to whichever command or
   context requested it.

## 3. Core Components

### 3.1 `ScriptInfo`

```python
class ScriptInfo:
    def __init__(
        self,
        app_import_path: str | None = None,
        create_app: t.Callable[..., Flask] | None = None,
        set_debug_flag: bool = True,
        load_dotenv_defaults: bool = True,
    ) -> None: ...
    def load_app(self) -> Flask: ...
```

A helper object that "deals with Flask applications". It is normally created
implicitly by [`FlaskGroup`](command-line-interface_cli-framework.md) and
attached as the click context object; users can also create one manually and
pass it via click's object pipeline (`pass_script_info`).

#### Attributes

| Attribute | Type | Purpose |
|---|---|---|
| `app_import_path` | `str \| None` | The import path for the app, either `'module'` or `'module:name'`. Set by `_set_app` (from `--app` / `FLASK_APP`) or programmatically. |
| `create_app` | `Callable[..., Flask] \| None` | An application factory callable. When set, it **takes precedence** over import-path discovery. Used by `FlaskGroup(create_app=...)` and by tests / embedding code. |
| `data` | `dict` | Free-form scratch space for associating arbitrary data with this script info. |
| `set_debug_flag` | `bool` | Whether `load_app()` should apply `app.debug = get_debug_flag()` after loading (reads the `FLASK_DEBUG` environment variable; default `False`). |
| `load_dotenv_defaults` | `bool` | Whether default `.flaskenv` / `.env` files should be loaded during CLI processing. `ScriptInfo` itself loads nothing — this is a reference consumed by the environment handling described in [command-line-interface_environment-config](command-line-interface_environment-config.md). Initialized through `get_load_dotenv()`, i.e. it honors `FLASK_SKIP_DOTENV`. |
| `_loaded_app` | `Flask \| None` *(private)* | One-shot cache. Any call after the first successful load returns this instance. |

#### `ScriptInfo.load_app()` — resolution order

`load_app()` is the single entry point every consumer uses
(`with_appcontext`, `run_command`, `FlaskGroup.get_command`,
`FlaskCliRunner`, …). Its decision logic:

```mermaid
flowchart TD
    S["ScriptInfo.load_app()"] --> C1{"_loaded_app cached?"}
    C1 -- "yes" --> R1["return cached app<br/>(no further work)"]
    C1 -- "no" --> C2{"create_app callable set?"}
    C2 -- "yes" --> R2["app = create_app()"]
    C2 -- "no" --> C3{"app_import_path set?<br/>(--app / FLASK_APP)"}
    C3 -- "yes" --> S1["split 'path:name'<br/>(regex ':&#40;?!&#91;/\\\\&#93;' → colon not starting<br/>a Windows path, maxsplit=1)<br/>prepare_import(path)<br/>locate_app(import_name, name)"]
    C3 -- "no" --> S2["convention scan:<br/>locate_app('wsgi.py', raise_if_not_found=False)<br/>then locate_app('app.py', …)"]
    S1 --> C4{"a Flask instance was obtained?"}
    S2 --> C4
    C4 -- "no" --> ERR["raise NoAppException:<br/>'Could not locate a Flask application…'<br/>(suggests --app / FLASK_APP / wsgi.py / app.py)"]
    C4 -- "yes" --> DBG{"set_debug_flag?"}
    DBG -- "yes" --> D1["app.debug = get_debug_flag()<br/>(FLASK_DEBUG env var; descriptor update<br/>refreshes dependent config values)"]
    DBG -- "no" --> CACHE
    D1 --> CACHE["cache in _loaded_app"] --> R3["return app"]
```

Key behaviors:

- **Idempotent & memoized.** Repeated calls return the identical app object,
  which is what guarantees one app per CLI invocation (relevant for
  `test_flaskgroup_app_context` and the leak detector in
  [command-line-interface_test-suite](command-line-interface_test-suite.md)).
- **Conventional fallback.** With no explicit source, `wsgi.py` and then
  `app.py` in the current directory are tried with
  `raise_if_not_found=False`, so a missing file is not an error — only *no
  app found anywhere* is.
- **Debug flag propagation.** Assignment goes through the `Flask.debug`
  descriptor so dependent values (`app.config["DEBUG"]`, `PROPAGATE_EXCEPTIONS`,
  `TRAP_HTTP_EXCEPTIONS`, jinja auto-reload) repopulate consistently — the
  same flag owned by [application-core_flask-app](application-core_flask-app.md).

### 3.2 `_set_app` and the `-A/--app` option

```python
def _set_app(ctx: click.Context, param: click.Option, value: str | None) -> str | None:
    if value is None:
        return None
    info = ctx.ensure_object(ScriptInfo)
    info.app_import_path = value
    return value
```

`_set_app` is bound to the `_app_option` click option:

| Option property | Value | Why |
|---|---|---|
| names | `-A`, `--app` | short/long forms documented in the `flask` command help |
| `metavar` | `IMPORT` | value shape: `'module:name'` |
| `is_eager=True` | yes | the app import path is captured **before** `--help` and other callbacks run, so `flask --app x --help` can already list app-provided commands |
| `expose_value=False` | yes | the value is consumed by the callback; commands never receive it as a parameter |
| `callback=_set_app` | yes | stores the value on `ScriptInfo` |

Two integration notes:

- **Environment variable.** `FlaskGroup` sets
  `context_settings["auto_envvar_prefix"] = "FLASK"`, so click resolves the
  option from the `FLASK_APP` environment variable automatically — there is
  no separate code path. Explicit `--app` on the command line wins over the
  environment variable (click precedence).
- **Early processing without arguments.** Because `no_args_is_help` bypasses
  eager parameter processing, `FlaskGroup.parse_args` manually invokes
  `_env_file_option.handle_parse_result` and `_app_option.handle_parse_result`
  when it detects a bare `--help`, so `FLASK_APP` is still honored.

## 4. Application Specification Formats

The `--app` / `FLASK_APP` value is resolved by the parent module's helpers;
the accepted shapes (summarized — details in
[command-line-interface](command-line-interface.md)):

| Specification | Example | Resolution |
|---|---|---|
| plain module | `--app myapp` | `find_best_app` — prefers attributes `app`, `application`; else the single `Flask` instance; else the `create_app` / `make_app` factory called with no arguments |
| attribute | `--app myapp:app` | attribute lookup on the imported module; must be a `Flask` instance |
| factory call | `--app "myapp:create_app('dev')"` | `find_app_by_string` parses the expression with `ast`; only a *simple name* call with *literal* arguments is allowed; the factory must return a `Flask` instance |
| file path | `--app hello.py`, `--app src/app.py` | `prepare_import` converts the path to a dotted module name and inserts the package root at the front of `sys.path`; `__init__.py` maps to its package |

Interaction with factories that raise `TypeError`: `_called_with_wrong_args`
walks the traceback to distinguish *wrong arguments passed by the CLI* (→
`NoAppException` hinting at `module:factory(args)`) from an error raised
*inside* a factory that was called correctly (→ the original exception is
re-raised). This preserves genuine application bugs for the error handling
described in §6.

## 5. End-to-End Discovery Flow

```mermaid
sequenceDiagram
    participant user as Developer
    participant group as FlaskGroup
    participant info as ScriptInfo
    participant helpers as discovery helpers
    participant app as Flask application

    user->>group: invoke flask run with app option
    group->>group: create ScriptInfo as ctx obj
    group->>user: dispatch command
    user->>info: load_app on first use
    info->>info: check cache, read import path
    info->>helpers: prepare_import and locate_app
    helpers->>app: import module, resolve instance
    info->>app: apply debug flag from environment
    info->>user: return cached instance
    user->>app: serve or introspect
```

Consumers that request the app through `ScriptInfo`:

- `with_appcontext` — pushes `app.app_context()` around arbitrary commands.
- `run_command`, `shell_command`, `routes_command` — see
  [command-line-interface_built-in-commands](command-line-interface_built-in-commands.md).
- `FlaskGroup.get_command` / `list_commands` — to enumerate commands the app
  registers on `app.cli`.
- `FlaskCliRunner` ([testing-support](testing-support.md)) — passes a custom
  `ScriptInfo` so tests drive the CLI against a pre-built app.

## 6. Error Handling & Diagnostics

All discovery failures raise `NoAppException(click.UsageError)`; the message
is always actionable:

| Situation | Raised by | Message behavior |
|---|---|---|
| No source at all (no `--app`, no `FLASK_APP`, no `wsgi.py`/`app.py`) | `ScriptInfo.load_app` | tells the user all three options for locating the app |
| Module not importable (no `tb_next` in traceback) | `locate_app` | `Could not import '…'.` |
| `ImportError` raised **inside** the target module (traceback depth > 1) | `locate_app` | wraps and shows the full original traceback — the real bug is surfaced, not hidden |
| Multiple `Flask` instances / failed no-arg factory call in a plain module | `find_best_app` | suggests `module:name` / `module:factory(args)` |
| Unparseable or non-literal `module:name` expression, missing attribute, factory raising `TypeError` on given args, non-`Flask` result | `find_app_by_string` | targeted hint naming the module and expression |

`FlaskGroup` (see
[command-line-interface_cli-framework](command-line-interface_cli-framework.md))
catches `NoAppException` when *listing* commands and prints the message to
stderr in red **without** a traceback, then continues with built-in/plugin
commands; any *other* exception during app load prints the full traceback.
This is why discovery errors degrade gracefully instead of breaking `flask
--help`.

## 7. Configuration & Environment Interaction

| Environment variable | Effect on discovery |
|---|---|
| `FLASK_APP` | Read by click (auto envvar) as the default value of `--app`; processed through `_set_app` exactly like a CLI flag. |
| `FLASK_DEBUG` | Not read during parsing; applied in `load_app()` via `get_debug_flag()` when `set_debug_flag=True`. `_set_debug` (environment-config module) writes this variable eagerly so factory functions can observe debug mode *during* import. |
| `FLASK_SKIP_DOTENV` | Read once in `ScriptInfo.__init__` via `get_load_dotenv()` to initialize `load_dotenv_defaults`. |
| `FLASK_RUN_FROM_CLI` | Set by `FlaskGroup.make_context` before any import happens, so a stray `app.run(...)` at import time becomes a no-op. |

Environment-file handling (`.env`, `.flaskenv`, `--env-file`) belongs to the
sibling module [command-line-interface_environment-config](command-line-interface_environment-config.md).

## 8. Component Interaction Summary

```mermaid
classDiagram
    direction LR
    class ScriptInfo {
        +app_import_path : str | None
        +create_app : Callable | None
        +data : dict
        +set_debug_flag : bool
        +load_dotenv_defaults : bool
        -_loaded_app : Flask | None
        +load_app() Flask
    }
    class NoAppException {
        <<click.UsageError>>
        discovery/load failure
    }
    class FlaskGroup {
        <<AppGroup>>
        make_context(): creates ScriptInfo as obj
        parse_args(): eagerly applies --env-file/--app
    }
    class pass_script_info {
        <<click decorator>>
        make_pass_decorator(ScriptInfo, ensure=True)
    }
    class with_appcontext {
        <<decorator>>
        ctx.ensure_object(ScriptInfo).load_app()
        pushes app.app_context()
    }
    class Flask {
        <<application-core_flask-app>>
    }

    FlaskGroup *-- "creates ctx.obj" ScriptInfo
    pass_script_info ..> ScriptInfo
    with_appcontext ..> ScriptInfo : load_app()
    ScriptInfo --> Flask : produces (cached)
    ScriptInfo ..> NoAppException : raises on failure
```

## 9. Dependencies

**Internal (Flask):**

- `flask.helpers.get_debug_flag` — reads `FLASK_DEBUG` for the post-load
  debug assignment.
- `flask.helpers.get_load_dotenv` — normalizes the `FLASK_SKIP_DOTENV` env
  var into `load_dotenv_defaults`.
- `flask.Flask` (`application-core_flask-app` /
  [application-core_sansio-foundation](application-core_sansio-foundation.md))
  — the produced artifact; imported lazily inside helpers to avoid circular
  imports.
- `flask.globals.current_app` — used by `with_appcontext` to skip re-pushing
  a context that is already active.

**Parent-module helpers** (documented in
[command-line-interface](command-line-interface.md), consumed by
`ScriptInfo.load_app()`): `prepare_import`, `locate_app`, `find_best_app`,
`find_app_by_string`, `_called_with_wrong_args`.

**External:** `click` (options, groups, pass objects, `UsageError`) and the
Python standard library (`ast`, `inspect`, `re`, `sys`, `os`, `traceback`).

## 10. Testing

Behavioral coverage for discovery lives in the sibling
[command-line-interface_test-suite](command-line-interface_test-suite.md),
which exercises this module via fixtures in `tests/conftest.py` and the sample
projects `tests/test_apps/cliapp/` (factory `create_app2`, decoy `no_app`) and
`tests/test_apps/helloworld/hello.py`. Relevant test groups:

| Test | Verifies |
|---|---|
| `test_scriptinfo` | `ScriptInfo` construction and caching semantics |
| `test_find_best_app` | convention-based attribute/factory resolution |
| `test_locate_app`, `test_locate_app_raises`, `test_locate_app_suppress_raise` | import resolution, error raising, and `raise_if_not_found=False` suppression used by the `wsgi.py`/`app.py` fallback |
| `test_prepare_import` | file-path → module-name conversion and `sys.path` insertion |
| `test_locate_app_suppress_raise` / `test_help_echo_loading_error` | graceful `NoAppException` messaging |

## 11. Related Documentation

- [command-line-interface](command-line-interface.md) — parent module: import/`ast` resolution helpers and the `flask` entry point.
- [command-line-interface_cli-framework](command-line-interface_cli-framework.md) — `FlaskGroup`: option wiring, plugin command loading, context creation.
- [command-line-interface_environment-config](command-line-interface_environment-config.md) — `--debug`, `--env-file`, dotenv loading.
- [command-line-interface_built-in-commands](command-line-interface_built-in-commands.md) — `run`, `shell`, `routes` commands that consume `ScriptInfo`.
- [application-core_flask-app](application-core_flask-app.md) — the `Flask` application class produced by discovery.
- [testing-support](testing-support.md) — `FlaskCliRunner` programmatic CLI invocation with custom `ScriptInfo`.
