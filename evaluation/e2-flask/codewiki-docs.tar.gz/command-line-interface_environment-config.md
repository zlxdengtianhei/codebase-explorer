# Command-Line Interface: Environment Config (`--env-file`, `.env`/`.flaskenv`, `--debug`)

## 1. Introduction

The `command-line-interface_environment-config` module is the part of `flask.cli` that controls **how the `flask` command acquires its runtime environment** before any application code runs. It owns three core pieces inside `src/flask/cli.py`:

| Component | Kind | Responsibility |
|---|---|---|
| `_env_file_callback` (+ `_env_file_option`) | eager Click option callback | Triggers loading of `.flaskenv`, `.env`, and an explicit `--env-file` into `os.environ` |
| `_set_debug` (+ `_debug_option`) | eager Click option callback | Translates an explicit `--debug/--no-debug` flag into the `FLASK_DEBUG` environment variable |
| `_path_is_ancestor` | private utility | Separator-aware check of whether one filesystem path is an ancestor of another |

The defining design decision of this module is that the CLI communicates its configuration **through the process environment (`os.environ`) instead of mutating objects directly**. This guarantees that:

1. **Values are visible as early as possible** — including *during* `import` of the app module or execution of an app factory function (before `ScriptInfo` can attach any attributes to the app instance).
2. **A single precedence model applies everywhere** — real environment variables always win, then dotenv files in a well-defined order.
3. **Sub-processes inherit configuration** — e.g. Werkzeug's reloader child process is spawned with the same environment.

> **Module position:** This is a sub-module of [Command-Line Interface](command-line-interface.md), alongside:
> - [CLI Framework](command-line-interface_cli-framework.md) — `FlaskGroup`, which registers the eager options implemented here
> - [App Discovery](command-line-interface_app-discovery.md) — `ScriptInfo`, the consumer of `load_dotenv_defaults` and `FLASK_DEBUG`
> - [Built-in Commands](command-line-interface_built-in-commands.md) — `run`, which derives `--reload`/`--debugger` defaults from the debug flag

---

## 2. Role in the Overall System

`FlaskGroup` (see [CLI Framework](command-line-interface_cli-framework.md)) constructs its parameter list as:

```python
# Processing is done with option callbacks instead of a group
# callback. This allows users to make a custom group callback
# without losing the behavior. --env-file must come first so
# that it is eagerly evaluated before --app.
params.extend((_env_file_option, _app_option, _debug_option))
```

The environment-config module therefore sits at the **front of the CLI startup pipeline**: everything that happens later (app discovery, debug-mode resolution, dev-server defaults, and even the app's own configuration loading) reads from the environment state that this module establishes.

| Concern | Handled by this module | Consumed by |
|---|---|---|
| `.flaskenv` / `.env` / `--env-file` loading | `load_dotenv`, `_env_file_callback` | Everything reading `os.environ` afterwards |
| Explicit debug-mode override | `_set_debug` → `FLASK_DEBUG` | `ScriptInfo.load_app()`, `run_command`, app factories |
| Opt-out of default dotenv files | `get_load_dotenv()` honoring `FLASK_SKIP_DOTENV` | `ScriptInfo.load_dotenv_defaults` |
| Path ancestry checks | `_path_is_ancestor` (internal utility) | Path-handling logic in `flask.cli` |

### Architecture Overview

```mermaid
flowchart TB
    subgraph OPTIONS["Eager options registered on FlaskGroup (evaluated in this order)"]
        direction LR
        ENVFILE["_env_file_option<br/>-e / --env-file"]
        APPOPT["_app_option<br/>-A / --app"]
        DEBUGOPT["_debug_option<br/>--debug / --no-debug"]
    end

    ENVFILE -->|"callback"| ECB["_env_file_callback"]
    APPOPT -->|"callback"| SETAPP["_set_app"]
    DEBUGOPT -->|"callback"| SETDBG["_set_debug"]

    ECB -->|"value or defaults wanted"| LD["load_dotenv()"]
    LD --> PD["python-dotenv<br/>(optional dependency)"]
    PD --> FILES[".flaskenv, .env,<br/>explicit env file"]
    FILES -->|"set keys not already<br/>present, UTF-8"| ENV["os.environ"]

    SETDBG -->|"FLASK_DEBUG = 1 / 0<br/>(only if flag given)"| ENV

    subgraph HELPERS["flask.helpers"]
        GLD["get_load_dotenv()<br/>reads FLASK_SKIP_DOTENV"]
        GDF["get_debug_flag()<br/>reads FLASK_DEBUG"]
    end

    ENV --> GDF
    GLD -->|"load_dotenv_defaults"| SI["ScriptInfo (ctx.obj)"]
    GDF -->|"app.debug = ...<br/>when set_debug_flag"| SI

    ENV -.->|"visible during factory<br/>import / execution"| FACT["App factory functions"]
    ENV -.->|"config sources"| CFG["App Configuration"]

    SI --> APP["Loaded Flask application"]
```

---

## 3. The Environment Processing Pipeline

Because all three options are **eager** Click options and are registered in the order `env-file → app → debug`, Click evaluates their callbacks in a strict sequence during argument parsing — *before* any command callback runs.

```mermaid
sequenceDiagram
    autonumber
    participant U as User shell
    participant FG as FlaskGroup
    participant SI as ScriptInfo (ctx.obj)
    participant CB as _env_file_callback
    participant LD as load_dotenv
    participant PD as python-dotenv
    participant ENV as os.environ
    participant DBG as _set_debug
    participant CMD as command callback

    U->>FG: flask --env-file prod.env --debug run
    FG->>SI: make_context() creates ScriptInfo
    Note over SI: load_dotenv_defaults resolved by<br/>get_load_dotenv() honoring FLASK_SKIP_DOTENV
    FG->>CB: eager processing of --env-file (first)
    CB->>LD: load_dotenv("prod.env", load_defaults=...)
    LD->>PD: read .flaskenv, .env, then prod.env (UTF-8)
    PD->>ENV: set only keys not already present
    FG->>DBG: eager processing of --debug
    DBG->>ENV: FLASK_DEBUG = "1" (flag was explicit)
    FG->>CMD: dispatch "run"
    CMD->>SI: load_app()
    Note over SI: app.debug = get_debug_flag() → True<br/>also visible to the factory during import
    CMD->>CMD: uses environment-derived values
```

Two extra details of this pipeline matter for correctness:

- **Ordering guarantee.** The comment in `FlaskGroup.__init__` — *"--env-file must come first so that it is eagerly evaluated before --app"* — means an app can set `FLASK_APP` inside its `.env` file and the CLI will still find the app.
- **Help / no-args mode.** `FlaskGroup.parse_args` manually invokes `_env_file_option.handle_parse_result(...)` and `_app_option.handle_parse_result(...)` when the user passes no arguments or only `--help`. Without this, dotenv files would not be loaded and app-provided commands would be invisible in help listings when the options were given via environment variables (`FLASK_APP`, `FLASK_ENV_FILE`) rather than on the command line.

> **Tip — environment-variable equivalents.** `FlaskGroup` sets `auto_envvar_prefix = "FLASK"`, so every option can also be supplied as an env var: `-e/--env-file` ⇔ `FLASK_ENV_FILE`, `-A/--app` ⇔ `FLASK_APP`, and `--debug` values resolve through `FLASK_DEBUG`. The test fixtures reset all of these (`FLASK_ENV_FILE`, `FLASK_APP`, `FLASK_DEBUG`, `FLASK_RUN_FROM_CLI`, `WERKZEUG_RUN_MAIN`) between tests to keep runs hermetic.

---

## 4. Dotenv Loading

### 4.1 `_env_file_callback` — the trigger

The callback is attached to the eager `-e/--env-file` option (`click.Path(exists=True, dir_okay=False)`) and implements the module's *policy* for when to load files:

```mermaid
flowchart TD
    START["--env-file option parsed (eager)"] --> IMP{"import dotenv<br/>succeeds?"}
    IMP -->|"no, and an explicit<br/>value was passed"| BAD["raise click.BadParameter<br/>'python-dotenv must be installed to load an env file.'"]
    IMP -->|"no, no value given"| TIP["continue — load_dotenv later prints a<br/>'Tip: There are .env files present' hint"]
    IMP -->|"yes"| WANT{"value passed OR<br/>ScriptInfo.load_dotenv_defaults is True?"}
    WANT -->|"yes"| DO["load_dotenv(value,<br/>load_defaults=load_dotenv_defaults)"]
    WANT -->|"no (FLASK_SKIP_DOTENV<br/>set and no -e)"| SKIP["skip loading entirely"]
```

Note the deliberate asymmetry: a **missing `python-dotenv` is only a hard error when the user explicitly asked for a file** (`flask --env-file x`). When no value was passed, the CLI degrades gracefully (a yellow tip on stderr) so that a project containing `.env`/`.flaskenv` files still starts without the optional dependency.

### 4.2 `load_dotenv` — the loader

`load_dotenv(path=None, load_defaults=True)` is the public function that performs the actual work. It is a **no-op if `python-dotenv` is not installed** (returning `False`), and its merge semantics define the module's precedence contract:

1. If `load_defaults` is true, search (with `dotenv.find_dotenv(..., usecwd=True)`) for **`.flaskenv`** then **`.env`** and merge their values (UTF-8 encoded).
2. If an explicit `path` was given **and exists**, merge it on top of the defaults.
3. For every merged key, write `os.environ[key] = value` **only if the key is not already set** in `os.environ`, and only if the value is not `None`.

```mermaid
flowchart LR
    F1["1. .flaskenv<br/>shared defaults (committable)"] --> MERGE{"dict merge<br/>(later wins)"}
    F2["2. .env<br/>local overrides (git-ignored)"] --> MERGE
    F3["3. --env-file / FLASK_ENV_FILE<br/>explicit path"] --> MERGE
    MERGE --> OUT["merged values"]
    OUT --> CHECK{"key already in<br/>os.environ?"}
    CHECK -->|"yes, or value is None"| SKIPD["skipped — real environment wins"]
    CHECK -->|"no"| SET["os.environ[key] = value"]
```

**Effective precedence (highest → lowest):** already-set environment variables → explicit `--env-file` path → `.env` → `.flaskenv`.

Behavioral notes:

- **The working directory is never changed** while loading (this changed in Flask 2.0; files are read in place with `encoding="utf-8"`).
- Returns `True` if at least one environment variable was loaded from any file; a non-existent explicit path with `load_defaults=False` returns `False` without error.
- Values are also merged *between* the default files: `.env` overrides duplicate keys from `.flaskenv`, which is why the canonical layout is "shared defaults in `.flaskenv`, personal overrides in `.env`".
- `FLASK_SKIP_DOTENV` (resolved by `get_load_dotenv()` in `flask.helpers`) disables step 1 only — an explicit `--env-file` still loads. Falsy values (`0`, `false`, `no`, case-insensitive) *enable* loading; anything else (including `1`) disables it.

Example project layout:

```ini
# .flaskenv — safe to commit: defaults shared by the team
FLASK_APP=wsgi.py

# .env — local, git-ignored: developer-specific overrides
FLASK_DEBUG=1
DATABASE_URL=sqlite:///dev.db
```

```console
$ flask --env-file settings/prod.env --app wsgi:app run   # file vars override .env/.flaskenv
```

---

## 5. Debug Flag Wiring

### 5.1 `_set_debug` — write to the environment, not to the app

The `--debug/--no-debug` flag is exposed by an eager option whose callback is `_set_debug`. Its subtlety lies in *when* it acts:

```mermaid
flowchart TD
    P["--debug / --no-debug parsed"] --> SRC{"ctx.get_parameter_source()<br/>is DEFAULT or DEFAULT_MAP?"}
    SRC -->|"yes — flag not given on<br/>command line"| KEEP["return None:<br/>leave FLASK_DEBUG untouched so .env /<br/>FLASK_DEBUG from the environment decide"]
    SRC -->|"no — flag was explicit"| WRITE["os.environ['FLASK_DEBUG'] = '1' (--debug)<br/>or '0' (--no-debug)"]
    KEEP --> LATER["later: ScriptInfo.load_app() →<br/>app.debug = get_debug_flag()"]
    WRITE --> LATER
    LATER --> RC["run_command: debug decides<br/>--reload / --debugger defaults"]
```

The `ParameterSource` check is essential: without it, merely *not passing* `--debug` would write `FLASK_DEBUG=0` into the environment, silently overriding debug mode requested by the app's `.env` file or shell environment. When the flag *is* given, the callback writes `FLASK_DEBUG` **immediately** — "so that it can be accessed early during a factory function" — because app factories frequently inspect debug mode while they execute, long before `ScriptInfo` could set `app.debug`.

### 5.2 Consumption points and precedence

| Consumer | How it uses the flag |
|---|---|
| `ScriptInfo.load_app()` | `app.debug = get_debug_flag()` when `set_debug_flag=True` (default) — overrides what the factory set |
| App factory functions | May call `get_debug_flag()` during import/creation |
| `run_command` (see [Built-in Commands](command-line-interface_built-in-commands.md)) | `debug` becomes the default for the reloader and debugger (`--reload`, `--debugger`) |
| App configuration | Other config values may be derived from `app.debug` (see [Configuration](configuration.md)) |

The precedence consequence is captured by `test_flaskgroup_debug`: a factory that sets `app.debug = True` **still ends up with `app.debug == False`** under a default `FlaskGroup`, because the CLI re-resolves debug from the environment after loading. Passing `set_debug_flag=False` (or setting `FLASK_DEBUG=1`) lets the factory's choice survive. So, in effect:

```console
$ flask --app wsgi run            # FLASK_DEBUG (env or dotenv files) decides
$ flask --app wsgi --debug run    # forces FLASK_DEBUG=1, overrides factory
$ flask --app wsgi --no-debug run # forces FLASK_DEBUG=0, overrides factory
```

---

## 6. `_path_is_ancestor` — Path Utility

```python
def _path_is_ancestor(path: str, other: str) -> bool:
    """Take ``other`` and remove the length of ``path`` from it. Then join it
    to ``path``. If it is the original value, ``path`` is an ancestor of
    ``other``."""
    return os.path.join(path, other[len(path) :].lstrip(os.sep)) == other
```

This is a small, **pure string computation** (no filesystem I/O) used to decide whether `other` lies at or below the directory `path`:

| `path` | `other` | Result | Why |
|---|---|---|---|
| `/home/app` | `/home/app/static/x.css` | `True` | stripping the prefix and re-joining reproduces `other` |
| `/home/app` | `/home/app` | `True` | a path is considered its own ancestor |
| `/home/app` | `/home/application` | `False` | `lstrip(os.sep)` prevents the shared-prefix false positive `…/application` |
| `/home/app` | `/srv/data` | `False` | remainder does not rejoin to `other` |

It is a **private** helper of `flask.cli` (underscore prefix, not part of the public API) available to the CLI's path-handling logic when reasoning about env-file or app-path locations relative to the working directory; the current option-processing callbacks do not call it directly.

---

## 7. Environment Variables and Files Reference

### Environment variables

| Variable | Direction | Effect |
|---|---|---|
| `FLASK_DEBUG` | written by `_set_debug` (`1`/`0`), read by `get_debug_flag()` | Forces debug mode when the `--debug/--no-debug` flag is explicit; otherwise left alone so other sources can decide |
| `FLASK_SKIP_DOTENV` | read by `get_load_dotenv()` | Set to anything other than `0`/`false`/`no` to disable loading default `.flaskenv`/`.env` files |
| `FLASK_ENV_FILE` | read via Click's `auto_envvar_prefix="FLASK"` | Environment-variable form of `-e/--env-file` |
| `FLASK_APP` | read by `ScriptInfo` (see [App Discovery](command-line-interface_app-discovery.md)) | May itself be provided inside a dotenv file, thanks to the `env-file → app` eager ordering |
| `FLASK_RUN_FROM_CLI` | set by `FlaskGroup.make_context` (see [CLI Framework](command-line-interface_cli-framework.md)) | Makes `app.run()` a no-op during CLI imports |

### Environment files

| File | Typical role | Precedence within files |
|---|---|---|
| `.flaskenv` | Team-shared defaults, safe to commit | Lowest |
| `.env` | Local, git-ignored overrides | Middle (overrides `.flaskenv`) |
| `--env-file` / `FLASK_ENV_FILE` path | Explicit, per-invocation file | Highest (overrides both defaults) |

Real environment variables outrank all files, and no loaded value ever overwrites an existing variable.

---

## 8. Dependencies

```mermaid
flowchart LR
    subgraph THIS["environment-config (src/flask/cli.py)"]
        ECB["_env_file_callback"]
        SD["_set_debug"]
        PIA["_path_is_ancestor"]
        LDO["load_dotenv"]
        EO["_env_file_option / _debug_option"]
    end

    CLICK["Click<br/>Option, ParameterSource,<br/>BadParameter, Path"]
    PD["python-dotenv<br/>(optional)"]
    HLP["flask.helpers<br/>get_load_dotenv, get_debug_flag"]
    ENV["os.environ"]

    EO --> ECB
    EO --> SD
    ECB --> CLICK
    ECB --> PD
    ECB --> LDO
    LDO --> PD
    LDO --> CLICK
    LDO -->|"set missing keys"| ENV
    SD --> CLICK
    SD -->|"FLASK_DEBUG"| ENV
    HLP --> ENV
    LDO -.->|"default-file opt-out"| HLP

    FG["FlaskGroup — CLI Framework"] -->|"registers options,<br/>creates ScriptInfo"| THIS
    SI["ScriptInfo — App Discovery"] -->|"load_dotenv_defaults,<br/>get_debug_flag"| THIS
    RUNC["run_command — Built-in Commands"] -->|"debug → reload/debugger"| ENV
```

Dependency summary:

- **Click** — option plumbing, parameter-source introspection (`ParameterSource`), error reporting (`BadParameter`).
- **python-dotenv** — *optional*. All dotenv behavior silently degrades to a no-op (with an informational tip) when it is absent.
- **`flask.helpers`** — `get_load_dotenv` / `get_debug_flag` are the single readers of `FLASK_SKIP_DOTENV` / `FLASK_DEBUG`; the CLI module only writes those variables, never interprets them directly.
- **Dependents** — `FlaskGroup` registers the options and seeds `ScriptInfo.load_dotenv_defaults`; `ScriptInfo.load_app` and `run_command` consume the resulting environment state.

---

## 9. Testing

The behavior is covered by `tests/test_cli.py` (dotenv tests are skipped when `python-dotenv` is missing, via the `need_dotenv` marker). Fixtures live under `tests/test_apps/` (`.flaskenv`, `.env` defining `FOO`, `BAR`, `SPAM`, `HAM`) and `tests/conftest.py` resets `FLASK_ENV_FILE`, `FLASK_APP`, `FLASK_DEBUG`, `FLASK_RUN_FROM_CLI`, and `WERKZEUG_RUN_MAIN` after every test for hermeticity.

| Test | What it verifies |
|---|---|
| `test_load_dotenv` | Full precedence chain: `os.environ` (`EGGS`) is never overwritten; `.env` beats `.flaskenv` (`FOO == "env"`); values unique to each file load (`BAR`, `SPAM`); UTF-8 decoding (`HAM == "火腿"`); the working directory is unchanged; a non-existent path with `load_defaults=False` returns `False` |
| `test_dotenv_path` | An explicit `.flaskenv` path loads even outside that directory; cwd unchanged |
| `test_dotenv_optional` | With `dotenv` unavailable, `load_dotenv()` neither raises nor sets variables |
| `test_disable_dotenv_from_env` | Invoking a `FlaskGroup` with `FLASK_SKIP_DOTENV=1` set skips default file loading |
| `test_flaskgroup_debug` | With `set_debug_flag=True` the environment-derived debug value overrides the factory's `app.debug = True`; with `set_debug_flag=False` the factory value survives |

---

## 10. Related Documentation

- [Command-Line Interface](command-line-interface.md) — overview of the `flask` CLI
- [CLI Framework](command-line-interface_cli-framework.md) — `FlaskGroup` / `AppGroup`, command aggregation, `ctx.obj` creation
- [App Discovery](command-line-interface_app-discovery.md) — `ScriptInfo.load_app()`, `FLASK_APP` handling, where `app.debug` is finalized
- [Built-in Commands](command-line-interface_built-in-commands.md) — `run` / `shell` / `routes`, which consume the configured environment
- [Configuration](configuration.md) — how the loaded environment can feed `Config` sources (e.g. `from_prefixed_env`)
- [Helpers](helpers.md) — request-side helpers sharing the `flask.helpers` home of `get_debug_flag` / `get_load_dotenv`
