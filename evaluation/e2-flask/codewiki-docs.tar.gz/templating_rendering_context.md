# Templating Rendering Context (`templating_rendering_context`)

---

## 1. Introduction

`templating_rendering_context` is the **rendering and context-injection layer** of Flask's template subsystem. It lives in `src/flask/templating.py` (within the `Request_Services___Response_Rendering` module group) and provides:

- The **public rendering API** used by virtually every Flask application:
  - `render_template` — render a template file to a string.
  - `render_template_string` — render an ad-hoc source string.
  - `stream_template` / `stream_template_string` — render lazily as an iterator of strings for streaming responses.
- The **default template context processor** (`_default_template_ctx_processor`), which injects the request-scoped objects `request`, `session`, and `g` into every rendered template.
- The **rendering orchestration internals** `_render` and `_stream`, which assemble the final template context, emit the `before_render_template` / `template_rendered` signals, and hand the context to Jinja.

The module is intentionally thin: it does **not** own template *lookup* (handled by `Environment` / `DispatchingJinjaLoader`, see [templating_environment_loader](templating_environment_loader.md)), template *customization* (filters, tests, globals, see [templating_customization](templating_customization.md)), or context *lifetime* (`AppContext` / `RequestContext`, see [contexts](contexts.md)). Its job is to bind these pieces together at render time.

| Concern | Owner module |
|---|---|
| Template lookup, blueprint-aware loading, `EXPLAIN_TEMPLATE_LOADING` | [templating_environment_loader](templating_environment_loader.md) |
| Filters / tests / globals registration | [templating_customization](templating_customization.md) |
| `AppContext` / `RequestContext` push/pop, `g` | [contexts](contexts.md) |
| `update_template_context`, `create_jinja_environment`, `make_response` | [application-core](application-core.md) |
| Blueprint-scoped context processors | [blueprints](blueprints.md) |
| `stream_with_context`, `get_template_attribute` | [helpers](helpers.md) |

---

## 2. Component Reference

### Source: `src/flask/templating.py`

| Component | Kind | Responsibility |
|---|---|---|
| `render_template(template_name_or_list, **context)` | Public API | Resolves the template (a name, a `Template`, or a list where the first existing entry wins) via `app.jinja_env.get_or_select_template`, then renders it through `_render`. Returns a `str`. |
| `render_template_string(source, **context)` | Public API | Compiles `source` with `app.jinja_env.from_string` and renders it through `_render`. Returns a `str`. |
| `stream_template(template_name_or_list, **context)` | Public API (since 2.2) | Same resolution as `render_template`, rendered lazily through `_stream`. Returns `Iterator[str]`, suitable as a streaming view return value. |
| `stream_template_string(source, **context)` | Public API (since 2.2) | Same as `stream_template` for an ad-hoc source string. |
| `_default_template_ctx_processor()` | Internal | Returns `{"g": appctx.g}` when an app context is active and `{"request": reqctx.request, "session": reqctx.session}` when a request context is active. Registered by default for every app and blueprint. |
| `_render(app, template, context)` | Internal | Merges context processors, sends `before_render_template`, calls `template.render(context)`, sends `template_rendered`, returns the string. |
| `_stream(app, template, context)` | Internal | Same context/signal setup, but renders via `template.generate(context)`; wraps the iterator in `stream_with_context` when a request context is active. |

### Tests: `tests/test_templating.py`

`test_context_processing`, `test_standard_context`, `test_original_win`, `test_request_less_rendering`, `test_simple_stream`, `test_escaping`, `test_no_escaping`, `test_escaping_without_template_filename`, `test_macros` — see [§11 Test Coverage](#11-test-coverage).

---

## 3. Architecture

The module sits at the intersection of Flask's context machinery (`_cv_app` / `_cv_request` context variables), the Jinja environment, and the app's context-processor registry:

```mermaid
flowchart TB
    subgraph MOD["templating_rendering_context - src/flask/templating.py"]
        API["render_template<br/>render_template_string<br/>stream_template<br/>stream_template_string"]
        RENDER["_render"]
        STREAM["_stream"]
        DEFCTX["_default_template_ctx_processor"]
    end

    subgraph GLOB["src/flask/globals.py"]
        CA["current_app proxy"]
        CV["_cv_app / _cv_request contextvars"]
    end

    subgraph APP["src/flask/app.py - Flask"]
        JENV["jinja_env"]
        UTC["update_template_context"]
        ESYNC["ensure_sync"]
        CJE["create_jinja_environment"]
    end

    subgraph SCP["src/flask/sansio/scaffold.py - Scaffold"]
        TCP["template_context_processors<br/>defaultdict with None: [default processor]"]
    end

    subgraph SUP["Supporting modules"]
        SIG["signals: before_render_template,<br/>template_rendered"]
        SWC["helpers: stream_with_context"]
        ENV["templating_environment_loader:<br/>Environment, DispatchingJinjaLoader"]
        CTX["contexts: AppContext, RequestContext"]
        RESP["application-core: make_response"]
    end

    API -->|"resolve app"| CA
    API -->|"get_or_select_template / from_string"| JENV
    API --> RENDER
    API --> STREAM
    RENDER -->|"merge context"| UTC
    RENDER -->|"signals"| SIG
    STREAM --> UTC
    STREAM -->|"keep ctx alive"| SWC
    STREAM --> SIG
    DEFCTX -->|"read g / request / session"| CV
    UTC -->|"iterate scopes"| TCP
    TCP -->|"contains by default"| DEFCTX
    SCP -.->|"imports default processor"| MOD
    JENV -->|"loader chain"| ENV
    ENV -->|"pushed by"| CTX
    JENV -->|"globals, autoescape, auto_reload"| CJE
    STREAM -->|"iterator of str"| RESP
    CA -->|"backed by"| CV
```

Key structural facts:

- `Scaffold.__init__` seeds `template_context_processors` with `{None: [_default_template_ctx_processor]}` (imported from this module), so **every** app and blueprint automatically injects `g` / `request` / `session`.
- `Flask.create_jinja_environment` (in [application-core](application-core.md)) also installs `request`, `session`, and `g` **proxies** as Jinja globals "for efficiency reasons … for imported templates" — the context processor supplies the *concrete* objects for directly rendered templates.
- Rendering functions capture `current_app._get_current_object()` (the real app, not the proxy) so the app reference remains valid while a streaming iterator is consumed after the view returns.

---

## 4. Rendering Pipeline

The four public entry points share one pipeline; only the template acquisition (file vs. string) and the output mode (eager string vs. lazy iterator) differ.

```mermaid
sequenceDiagram
    autonumber
    participant View as View function
    participant API as render_template / render_template_string
    participant App as Flask app (current_app)
    participant JE as jinja_env (Environment)
    participant DJL as DispatchingJinjaLoader
    participant UTC as update_template_context
    participant CP as Context processors
    participant Sig as signals
    participant T as Jinja Template

    View->>API: render_template("page.html", user=u)
    API->>App: current_app._get_current_object()
    API->>JE: get_or_select_template("page.html")
    JE->>DJL: get_source(env, name)
    DJL-->>JE: template source (app, then blueprint loaders)
    API->>UTC: update_template_context(context)
    UTC->>CP: run app-scope then blueprint-scope processors
    CP-->>UTC: request, session, g, custom injected values
    UTC-->>API: context merged (explicit kwargs win)
    API->>Sig: before_render_template.send(app, template=..., context=...)
    API->>T: template.render(context)
    T-->>API: rendered string
    API->>Sig: template_rendered.send(app, template=..., context=...)
    API-->>View: str
```

Narrative:

1. **App resolution** — every entry point requires an active [application context](contexts.md); `current_app._get_current_object()` raises a `RuntimeError` ("Working outside of application context") otherwise. A *request* context is optional (see [§9](#9-contexts-and-request-less-rendering)).
2. **Template acquisition** — file-based calls use `get_or_select_template`, which renders the *first existing* template when a list is given (exercised by `test_iterable_loader` in the parent [templating](templating.md) module); string-based calls use `from_string`. Lookup itself is delegated to `Environment` / `DispatchingJinjaLoader` — see [templating_environment_loader](templating_environment_loader.md).
3. **Context assembly** — `Flask.update_template_context` mutates the passed dict in place (see [§5](#5-template-context-assembly)).
4. **Signals** — `before_render_template` is sent *after* context assembly, so receivers observe the fully merged context; `template_rendered` is sent after a successful render. Both are sent with the app as sender and are async-safe (`_async_wrapper=app.ensure_sync`).
5. **Render** — `template.render(context)` for the eager API; the resulting string is returned directly to the view (and typically converted by `make_response` — see [application-core](application-core.md)).

---

## 5. Template Context Assembly

`Flask.update_template_context` (implemented in [application-core](application-core.md)) defines *which* variables Jinja sees and *in what order* they may be overridden:

```mermaid
flowchart TD
    A["context = explicit keyword arguments<br/>passed to render_template"] --> B["Snapshot originals:<br/>orig_ctx = context.copy()"]
    B --> C{"request context active?"}
    C -- "no" --> D["names = (None,)<br/>app scope only"]
    C -- "yes" --> E["names = (None, *reversed(request.blueprints))<br/>app scope, then outermost to innermost blueprint"]
    D --> F["For each scope with registered processors:<br/>context.update(ensure_sync(func)())"]
    E --> F
    F --> G["Later processors override keys of earlier ones"]
    G --> H["context.update(orig_ctx)<br/>explicit kwargs reapplied: 'original win'"]
    H --> I["Final context handed to Jinja"]
```

**Composition of the final context:**

| Layer | Source | Notes |
|---|---|---|
| `g` | `_default_template_ctx_processor` (app scope) | `AppContext.g` instance; type customizable via `app.app_ctx_globals_class` — see [contexts](contexts.md). |
| `request`, `session` | `_default_template_ctx_processor` (app scope) | Concrete objects from the active `RequestContext`; omitted entirely when no request context is active. |
| Custom app-level values | functions registered with `@app.context_processor` | Run after the default processor for the `None` scope, so they *may* override `g`/`request`/`session` keys. |
| Custom blueprint values | `@bp.context_processor` | Only run when the template is rendered from a view belonging to that blueprint (`request.blueprints` chain, outermost → innermost). Use `@bp.app_context_processor` to affect all templates — see [blueprints](blueprints.md). |
| Explicit `**context` kwargs | caller of `render_template*` | **Highest priority.** Re-applied last via the `orig_ctx` snapshot. |

**Precedence rules, distilled:**

1. Within processor execution, *later* registrations override *earlier* ones (dict `update` semantics).
2. Blueprint processors run after the app-level ones, innermost blueprint last.
3. Explicit keyword arguments always win — verified by `test_original_win`, where `render_template_string("{{ config }}", config=42)` renders `42` even though `config` is a Jinja global installed by `create_jinja_environment` (Jinja template context takes precedence over environment globals).

`test_context_processing` shows rules 1–3 working together: a view rendering `context_template.html` with `value=23` while an `@app.context_processor` injects `injected_value=42` produces `<p>23|42`.

---

## 6. Streaming Rendering

`stream_template` / `stream_template_string` return an **iterator of strings** instead of a fully rendered string. Jinja pulls chunks lazily, which keeps memory flat for large pages and lets the server start sending bytes before rendering finishes.

```mermaid
flowchart TD
    A["stream_template('page.html', **ctx)"] --> B["template = jinja_env.get_or_select_template(...)"]
    B --> C["_stream: update_template_context<br/>+ before_render_template signal"]
    C --> D["define generate():<br/>yield from template.generate(context)<br/>then send template_rendered"]
    D --> E{"request context active?"}
    E -- "yes" --> F["wrap iterator in stream_with_context<br/>(re-pins the RequestContext during consumption)"]
    E -- "no" --> G["return the raw generator"]
    F --> H["View returns iterator<br/>make_response builds a streaming Response"]
    G --> H
    H --> I["template_rendered fires only after<br/>the response body is fully consumed"]
```

The interaction with [helpers](helpers.md) `stream_with_context` is the subtle part:

- WSGI servers normally pop the [request context](contexts.md) as soon as the response starts, so a naive streaming template could no longer access `request` / `session` / `g` mid-render.
- `_stream` detects an active request (`if request:`) and wraps its generator with `stream_with_context`, which *re-pushes* the original `RequestContext` (`with ctx:` inside its generator) for the duration of consumption, then releases it.
- Consequently, **`template_rendered` is deferred**: it is sent as the last step of the wrapped `generate()`, i.e. after the final chunk is consumed — not when the view returns.
- `test_simple_stream` (`stream_template_string("{{ config }}", config=42)` → `b"42"`) covers the basic path; the request-context-preserving path is exercised by `stream_with_context` tests in [helpers](helpers.md) and `TestGreenletContextCopying` in [contexts](contexts.md).

---

## 7. Signal Integration

The module emits two Blinker signals (defined in `src/flask/signals.py`), both with the `Flask` app as sender and `template` / `context` keyword arguments, and both async-receiver-safe via `_async_wrapper=app.ensure_sync`:

| Signal | When | Typical use |
|---|---|---|
| `before_render_template` | After `update_template_context`, before Jinja renders | Inspect / log the *final* merged context; late context mutation by receivers is possible (the dict is shared). |
| `template_rendered` | After `template.render` (or after stream generation completes) | Recording rendered contexts — Flask's own test tooling and `tests/test_signals.py::test_template_rendered` / `test_before_render_template` connect to these signals to assert on rendering behavior. |

Rendering outside of an app context raises before any signal is sent; signals are therefore guaranteed to fire only for successfully initiated renders.

---

## 8. Autoescaping Behavior

Autoescaping is configured once, when the Jinja environment is created (`Flask.create_jinja_environment` wires `autoescape=app.select_jinja_autoescape`; see [application-core](application-core.md)), but its effects are visible through this module's API and pinned by its tests:

| Call | Autoescape? | Rationale |
|---|---|---|
| `render_template("page.html", ...)` | Yes | Filename extension `.html` / `.htm` / `.xhtml` / `.xml`. |
| `render_template("mail.txt", ...)` | No | Non-HTML extension. |
| `render_template_string("{{ foo }}", ...)` | Yes | No filename → escape by default, since ad-hoc strings are usually HTML fragments. |

`test_escaping` and `test_no_escaping` verify both directions for `.html` and `.txt` templates (including that `markupsafe.Markup` values stay unescaped), while `test_escaping_without_template_filename` pins the "string source escapes, `.txt` file does not" asymmetry in a single view-independent test.

---

## 9. Contexts and Request-less Rendering

The default context processor reads the active contexts *directly* through the `contextvars` `_cv_app` / `_cv_request` (rather than the thread-local-style proxies) for efficiency:

- **Request-scoped rendering** (inside a view or `test_request_context`): context gains `request`, `session`, and `g`; blueprint-scoped processors run along `request.blueprints`.
- **Request-less rendering** (only an [app context](contexts.md) active, e.g. in tests, CLI tasks, or emails): `g` and `config` (a Jinja global) are available; `request` / `session` are silently absent — there is no error, the template simply must not reference them. `test_request_less_rendering` demonstrates this by rendering `"Hello {{ config.WORLD_NAME }} {{ foo }}"` under only an `app_ctx`.

This layering keeps rendering requirements minimal — an app context is the *only* hard requirement — while request data is injected opportunistically. Context push/pop semantics themselves are documented in [contexts](contexts.md); the request lifecycle that invokes rendering is documented in [application-core](application-core.md).

---

## 10. Configuration

Two config keys influence rendering behavior; both are owned by the environment/loader layer but are triggered from these call paths:

| Key | Effect | Covered by |
|---|---|---|
| `TEMPLATES_AUTO_RELOAD` | Whether Jinja reloads changed templates; `None` (default) follows `app.debug`. | `test_templates_auto_reload`, `test_templates_auto_reload_debug_run` in [templating](templating.md) |
| `EXPLAIN_TEMPLATE_LOADING` | When `True`, failed/successful lookups via the `DispatchingJinjaLoader` log every attempted loader, for debugging "where is my template" problems. | `test_template_loader_debugging` in [templating_environment_loader](templating_environment_loader.md) |

---

## 11. Test Coverage

`tests/test_templating.py` pins the behavioral contract of this module:

| Test | Behavior verified |
|---|---|
| `test_context_processing` | `@app.context_processor` values are merged with explicit kwargs in real request rendering (`<p>23|42`). |
| `test_standard_context` | The default processor exposes `request`, `g`, `session`, and the `config` global together in one template. |
| `test_original_win` | Explicit kwargs override Jinja globals such as `config` (context beats global). |
| `test_request_less_rendering` | Rendering with an app context but no request context works; `config` and processor values are available. |
| `test_simple_stream` | `stream_template_string` renders through the streaming path (`{{ config }}` → `42`). |
| `test_escaping` | `.html` templates autoescape plain strings; `Markup` and `|safe` remain raw. |
| `test_no_escaping` | `.txt` templates do not autoescape; only explicitly piped-through HTML is escaped. |
| `test_escaping_without_template_filename` | `render_template_string` escapes by default; `render_template("mail.txt", ...)` does not. |
| `test_macros` | `flask.get_template_attribute` (`_macro.html::hello`, from [helpers](helpers.md)) reuses compiled macros within an active request context. |

Related coverage elsewhere: context lifetime tests in [contexts](contexts.md) (`test_app_context_provides_current_app`, `TestGreenletContextCopying`), environment/loader tests in [templating_environment_loader](templating_environment_loader.md), and customization tests in [templating_customization](templating_customization.md).

---

## 12. Usage Examples

```python
from flask import render_template, render_template_string, stream_template

# Standard view rendering — context processors add g/request/session automatically.
@app.route("/user/<int:id>")
def user(id):
    return render_template("user.html", user=load_user(id))

# List of candidate names: the first template that exists is rendered.
return render_template(["brand/survey.html", "survey.html"], form=form)

# Ad-hoc snippet (autoescaped), e.g. inside a CLI task with an app context.
with app.app_context():
    html = render_template_string("<b>{{ name }}</b>", name="<x>")  # "&lt;x&gt;"

# Streaming a large page; request context stays alive during consumption.
@app.route("/report")
def report():
    rows = iter_rows()  # e.g. a DB cursor
    return stream_template("report.html", rows=rows)
```

Registering extra context at various scopes (see [blueprints](blueprints.md) for `app_*` variants):

```python
@app.context_processor
def inject_locale():
    return {"locale": get_locale()}          # every render of this app

@bp.context_processor
def inject_cart():
    return {"cart": current_cart()}          # only renders from bp's views
```

---

## 13. Design Notes & Extension Points

- **Lazy, explicit app capture.** All four entry points do `current_app._get_current_object()` so the streaming generator holds the real app object; a bare proxy could dangle once the app context pops mid-stream.
- **Context mutation is in-place.** `update_template_context` mutates the caller's dict; `_render`/`_stream` therefore always pass a dict they own. Receivers of `before_render_template` can observe (and alter) the very dict Jinja will see.
- **Async support is uniform.** Context processors are invoked through `app.ensure_sync`, and signals pass `_async_wrapper=app.ensure_sync`, so `async def` processors and receivers work in both eager and streaming paths.
- **Extending the default context.** Subclass `Flask` and override `update_template_context`, replace `jinja_environment`, or register an app-level `context_processor` (which runs *after* the default processor and can shadow `g`/`request`/`session`). The default processor itself can be replaced by mutating `app.template_context_processors[None]`, though the decorated `context_processor` API is the supported route.
- **Error surface.** Template resolution failures raise `jinja2.TemplateNotFound` (wrapped selection semantics in [templating_environment_loader](templating_environment_loader.md)); absence of an app context raises `RuntimeError` before lookup; absence of a request context is *not* an error — only the relevant context values are omitted.
